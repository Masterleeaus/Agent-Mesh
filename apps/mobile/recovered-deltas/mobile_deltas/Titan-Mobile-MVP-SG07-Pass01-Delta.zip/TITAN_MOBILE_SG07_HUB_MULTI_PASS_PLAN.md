# TZ-ROADMAP-47-SG-07 — Titan Hub Mobile Projection

Parent: Titan-Mobile-MVP-Pass60.zip

## Pass 1 — canonical customer workforce projection — COMPLETE
Project Titan Hub as a customer-authorised window into the same canonical workforce. Preserve canonical `agent_id`, `company_id`/actor binding, customer-safe capability boundaries and exactly three home staff cards. Hub presentation never creates a Hub-specific agent or authority.

## Pass 2 — booking / status / messaging convergence
Bind canonical customer-care, booking/access and follow-up capabilities to service status, booking, reschedule and messaging flows without exposing internal topology or control artifacts.

## Pass 3 — commercial convergence
Bind quote/revenue/accounts capabilities to quote decisions, add-ons, invoices and payment intents. Consequential mutation remains Command Bus governed.

## Pass 4 — privacy and checkpoint
Adversarially verify customer-owned data boundaries, internal-agent shielding, cross-company isolation, offline authority contraction and Hub parity. Produce cumulative checkpoint/delta.
