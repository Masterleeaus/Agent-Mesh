# TZ-ROADMAP-47-SG-08 — Offline deterministic runtime convergence
Parent: Titan-Mobile-MVP-SG07-CHECKPOINT-Pass04.zip

## Pass 1 — provenance + reconnect authority gate — COMPLETE
Converged required offline provenance around existing queue/replay infrastructure: company_id, actor_id, device_id, canonical agent_id, capability_id, contracted authority, approval state, Signal origins, evidence refs, revisions and idempotency. Reconnect is explicitly Command Bus/server-authority revalidated; Signal publication follows accepted mutation only.

## Pass 2 — deterministic conflict/revision convergence — COMPLETE
Added a deterministic replay planner in front of transport execution, ordered by queue sequence/creation/id; duplicate idempotency keys, open conflicts, invalid replay contracts, non-monotonic target revisions and invalid revision dependencies fail closed before transport. Added queue-integrity auditing for duplicate sequences and target revision regressions and focused tests.

## Pass 3 — lifecycle/background reconnect convergence
Bind background lifecycle and connectivity transitions to bounded replay/reconciliation without autonomous consequential execution.

## Pass 4 — adversarial checkpoint
Verify cross-company/actor/device isolation, replay idempotency, stale authority/approval rejection, evidence continuity and deterministic conflict handling; produce cumulative checkpoint.
