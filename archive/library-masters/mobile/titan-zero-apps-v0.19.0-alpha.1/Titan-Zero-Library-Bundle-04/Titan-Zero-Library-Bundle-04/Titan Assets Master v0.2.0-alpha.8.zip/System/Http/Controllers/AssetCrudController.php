<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetCrudService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetDocumentService;use App\Extensions\TitanAssets\System\Domains\Assets\AssetMediaService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetQueryService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetCrudController extends Controller
{
    public function __construct(private AssetCrudService $assets,private AssetQueryService $query,private AssetDocumentService $documents,private AssetMediaService $media){}
    public function show(Request$r,string$type,string$asset){$row=$this->assets->show((int)$r->user()->id,$type,$asset);$timeline=$this->query->timeline((int)$r->user()->id,$type,$asset);$docs=$this->documents->list((int)$r->user()->id,$type,$asset);return$r->expectsJson()?response()->json(['asset'=>$row,'timeline'=>$timeline,'documents'=>$docs]):view('titan-assets::assets.show',compact('row','timeline','docs','type'));}
    public function update(Request$r,string$type,string$asset){$data=$r->validate($this->rules($type,false));$row=$this->assets->update((int)$r->user()->id,$type,$asset,$data);return$this->respond($r,$row,'Asset updated.');}
    public function destroy(Request$r,string$type,string$asset){$this->assets->delete((int)$r->user()->id,$type,$asset);return$r->expectsJson()?response()->json(['deleted'=>true]):back()->with('success','Asset deleted.');}
    public function retire(Request$r,string$type,string$asset){$row=$this->assets->retire((int)$r->user()->id,$type,$asset,$r->validate(['retired_on'=>'nullable|date','notes'=>'nullable|string|max:2000']));return$this->respond($r,$row,'Asset retired.');}
    public function writeOff(Request$r,string$type,string$asset){$data=$r->validate(['written_off_on'=>'nullable|date','written_off_reason'=>'nullable|string|max:5000','notes'=>'nullable|string|max:5000']);$row=$this->assets->writeOff((int)$r->user()->id,$type,$asset,$data);return$this->respond($r,$row,'Asset written off.');}
    public function sell(Request$r,string$type,string$asset){$row=$this->assets->sell((int)$r->user()->id,$type,$asset,$r->validate(['sold_on'=>'nullable|date','value_minor'=>'nullable|integer|min:0','notes'=>'nullable|string|max:2000']));return$this->respond($r,$row,'Asset sold.');}
    public function document(Request$r,string$type,string$asset){$d=$r->validate(['file'=>'required|file|max:20480','name'=>'nullable|string|max:180','document_type'=>'nullable|string|max:60']);$row=$this->documents->upload((int)$r->user()->id,$type,$asset,$d['file'],$d);return$this->respond($r,$row,'Document uploaded.');}
    public function deleteDocument(Request$r,string$document){$this->documents->delete((int)$r->user()->id,$document);return$r->expectsJson()?response()->json(['deleted'=>true]):back()->with('success','Document removed.');}
    public function image(Request$r,string$type,string$asset){$d=$r->validate(['image'=>'required|image|max:10240']);$row=$this->media->uploadImage((int)$r->user()->id,$type,$asset,$d['image']);return$this->respond($r,$row,'Asset image updated.');}
    public function deleteImage(Request$r,string$type,string$asset){$row=$this->media->deleteImage((int)$r->user()->id,$type,$asset);return$this->respond($r,$row,'Asset image removed.');}
    private function rules(string$type,bool$create=true):array{$base=['name'=>'sometimes|string|max:180','description'=>'nullable|string','image_path'=>'nullable|string|max:500','asset_type_public_id'=>'nullable|string|max:26','category_public_id'=>'nullable|string|max:26','customer_public_id'=>'nullable|string|max:26','owned_by_user_id'=>'nullable|integer|min:1','location_name'=>'nullable|string|max:180','location_public_id'=>'nullable|string|max:26','condition_status'=>'nullable|string|max:40','qr_token'=>'nullable|string|max:120','written_off_on'=>'nullable|date','written_off_reason'=>'nullable|string|max:5000','status'=>'nullable|string|max:40','acquired_on'=>'nullable|date','acquisition_cost_minor'=>'nullable|integer|min:0','current_value_minor'=>'nullable|integer|min:0','warranty_expires_on'=>'nullable|date','metadata'=>'nullable|array'];if($type==='vehicle')$base+=['registration'=>'sometimes|string|max:40','vin'=>'nullable|string|max:80','make'=>'nullable|string|max:100','model'=>'nullable|string|max:100','year'=>'nullable|integer|min:1900|max:2100','registration_expires_on'=>'nullable|date','next_service_on'=>'nullable|date','next_service_odometer_km'=>'nullable|integer|min:0','odometer_km'=>'nullable|integer|min:0','notes'=>'nullable|string'];else$base+=['asset_tag'=>'sometimes|string|max:100','serial_number'=>'nullable|string|max:160'];if($type==='equipment')$base+=['equipment_type'=>'nullable|string|max:100','manufacturer'=>'nullable|string|max:120','model'=>'nullable|string|max:120','next_service_on'=>'nullable|date'];return$base;}
    private function respond(Request$r,array$row,string$msg){return$r->expectsJson()?response()->json($row):back()->with('success',$msg);}
}
