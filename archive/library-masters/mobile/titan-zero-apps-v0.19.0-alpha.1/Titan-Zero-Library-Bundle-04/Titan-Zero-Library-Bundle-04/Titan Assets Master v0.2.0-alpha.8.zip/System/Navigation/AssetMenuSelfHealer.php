<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Navigation;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

final class AssetMenuSelfHealer
{
    private const SCHEMA_VERSION = 'titan-assets-menu-0.2.0-alpha.2';
    private const CACHE_KEY = 'titan_assets_menu_schema_version';
    private const HOST_MENU_CACHE_KEYS = ['dynamic_menu_key', 'dynamic_menu_key_active', 'navbar_cache_registry'];
    private const LEGACY_ASSET_KEYS = ['crm_tools', 'crm_equipment', 'crm_fleet', 'crm_maintenance', 'crm_customer_assets'];

    public function heal(bool $force = false): void
    {
        try {
            if (! Schema::hasTable('menus')) {
                return;
            }
            // Titan registers extension providers before running their migrations. Do not mutate
            // navigation during that pre-migration provider boot; the menu migration calls us
            // after the domain schema exists, and subsequent boots self-heal normally.
            if (! $force && ! Schema::hasTable('titan_asset_settings')) {
                return;
            }

            $columns = array_flip(Schema::getColumnListing('menus'));
            if (! isset($columns['key'])) {
                return;
            }

            $changed = false;
            $changed = $this->repairLockerParent($columns) || $changed;

            $parent = (array) config('titan-assets-navigation.parent', []);
            if (! $this->routeExists((string) ($parent['route'] ?? ''))) {
                return;
            }
            [$parentId, $parentChanged] = $this->upsert(
                $parent,
                null,
                $columns,
                'titan-assets'
            );
            $changed = $parentChanged || $changed;
            if ($parentId <= 0) {
                return;
            }

            $canonicalIds = [$parentId];
            foreach ((array) config('titan-assets-navigation.items', []) as $item) {
                if (! is_array($item) || ! $this->routeExists((string) ($item['route'] ?? ''))) {
                    continue;
                }
                [$id, $itemChanged] = $this->upsert($item, $parentId, $columns, 'titan-assets');
                if ($id > 0) {
                    $canonicalIds[] = $id;
                    $changed = $this->deactivateRouteDuplicates((string) $item['route'], [$parentId, $id], $columns) || $changed;
                }
                $changed = $itemChanged || $changed;
            }

            // Keep the live CRM menu rows (IDs 377/495/496/497/498 in the supplied DB dump)
            // by adopting their stable keys rather than inserting parallel rows.
            if (isset($columns['is_active'])) {
                $adopted = DB::table('menus')->whereIn('key', self::LEGACY_ASSET_KEYS)->where('parent_id', '!=', $parentId)->count();
                if ($adopted > 0) {
                    DB::table('menus')->whereIn('key', self::LEGACY_ASSET_KEYS)->update($this->filtered([
                        'parent_id' => $parentId,
                        'is_active' => 1,
                        'updated_at' => now(),
                    ], $columns));
                    $changed = true;
                }
            }

            $versionChanged = Cache::get(self::CACHE_KEY) !== self::SCHEMA_VERSION;
            if ($force || $changed || $versionChanged) {
                $this->regenerate();
                Cache::forever(self::CACHE_KEY, self::SCHEMA_VERSION);
            }
        } catch (\Throwable) {
            // Menu repair is fail-open: asset routes and data remain usable even if host navigation drifts.
        }
    }

    /** @param array<string,int> $columns */
    private function repairLockerParent(array $columns): bool
    {
        $row = DB::table('menus')->where('key', 'ext_crm_gear')->first();
        if (! $row) {
            return false;
        }
        $updates = $this->filtered([
            'label' => 'Inventory & Supplies',
            'is_active' => 1,
            'updated_at' => now(),
        ], $columns);
        foreach ($updates as $field => $value) {
            if (($row->{$field} ?? null) != $value) {
                DB::table('menus')->where('id', $row->id)->update($updates);
                return true;
            }
        }
        return false;
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns @return array{0:int,1:bool} */
    private function upsert(array $item, ?int $parentId, array $columns, string $extension): array
    {
        $key = trim((string) ($item['key'] ?? ''));
        $route = trim((string) ($item['route'] ?? ''));
        if ($key === '' || $route === '') {
            return [0, false];
        }

        $query = DB::table('menus')->where('key', $key);
        $existing = $query->first();
        if (! $existing) {
            // A previous version may have created the same Titan Assets route under a different key.
            $existing = DB::table('menus')->where('route', $route)->orderBy('id')->first();
        }

        $values = $this->filtered([
            'parent_id' => $parentId,
            'menu_group_id' => null,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => (string) ($item['label'] ?? $key),
            'icon' => (string) ($item['icon'] ?? 'tabler-folders'),
            'svg' => null,
            'order' => (int) ($item['order'] ?? 50),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => $extension,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 1,
            'updated_at' => now(),
        ], $columns);

        if ($existing) {
            $changed = false;
            foreach ($values as $field => $value) {
                if (($existing->{$field} ?? null) != $value) {
                    $changed = true;
                    break;
                }
            }
            if ($changed) {
                DB::table('menus')->where('id', $existing->id)->update($values);
            }
            return [(int) $existing->id, $changed];
        }

        $insert = $values;
        if (isset($columns['created_at'])) {
            $insert['created_at'] = now();
        }
        DB::table('menus')->insert($insert);
        return [(int) DB::table('menus')->where('key', $key)->value('id'), true];
    }

    /** @param array<string,int> $columns */
    private function deactivateRouteDuplicates(string $route, array $protectedIds, array $columns): bool
    {
        if (! isset($columns['is_active'])) {
            return false;
        }
        $ids = DB::table('menus')->where('route', $route)->whereNotIn('id', $protectedIds)->pluck('id');
        if ($ids->isEmpty()) {
            return false;
        }
        DB::table('menus')->whereIn('id', $ids)->update($this->filtered([
            'is_active' => 0,
            'updated_at' => now(),
        ], $columns));
        return true;
    }

    private function routeExists(string $route): bool
    {
        return $route !== '' && Route::has($route);
    }

    /** @param array<string,mixed> $values @param array<string,int> $columns @return array<string,mixed> */
    private function filtered(array $values, array $columns): array
    {
        return array_intersect_key($values, $columns);
    }

    private function regenerate(): void
    {
        foreach (self::HOST_MENU_CACHE_KEYS as $key) {
            Cache::forget($key);
        }
        try {
            if (class_exists(\App\Services\Common\MenuService::class)) {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) {
                    $service->regenerate();
                }
            }
        } catch (\Throwable) {
            foreach (self::HOST_MENU_CACHE_KEYS as $key) {
                Cache::forget($key);
            }
        }
    }
}
