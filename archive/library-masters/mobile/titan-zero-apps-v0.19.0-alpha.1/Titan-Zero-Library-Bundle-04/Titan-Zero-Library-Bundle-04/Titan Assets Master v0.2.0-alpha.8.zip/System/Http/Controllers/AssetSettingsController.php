<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetSettingsService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetSettingsController extends Controller
{
    public function __construct(private AssetSettingsService $settings) {}

    public function show(Request $request)
    {
        return response()->json($this->settings->get((int) $request->user()->id));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'asset_code_prefix' => 'nullable|string|max:30',
            'allocation_code_prefix' => 'nullable|string|max:30',
            'revoke_code_prefix' => 'nullable|string|max:30',
            'maintenance_code_prefix' => 'nullable|string|max:30',
            'notify_sent_for_maintenance' => 'nullable|boolean',
            'notify_assigned_for_maintenance' => 'nullable|boolean',
            'maintenance_recipient_user_ids' => 'nullable|array',
            'maintenance_recipient_user_ids.*' => 'integer|min:1',
            'send_for_maintenance_subject' => 'nullable|string|max:255',
            'send_for_maintenance_body' => 'nullable|string|max:10000',
            'assigned_for_maintenance_subject' => 'nullable|string|max:255',
            'assigned_for_maintenance_body' => 'nullable|string|max:10000',
            'metadata' => 'nullable|array',
            'maintenance_recipient_user_ids_csv' => 'nullable|string|max:1000',
        ]);
        if (array_key_exists('maintenance_recipient_user_ids_csv', $data)) {
            $data['maintenance_recipient_user_ids'] = array_values(array_unique(array_filter(array_map(
                static fn (string $value): int => (int) trim($value),
                explode(',', (string) $data['maintenance_recipient_user_ids_csv'])
            ), static fn (int $value): bool => $value > 0)));
            unset($data['maintenance_recipient_user_ids_csv']);
        }
        $row = $this->settings->update((int) $request->user()->id, $data);
        return $request->expectsJson() ? response()->json($row) : back()->with('success', 'Asset settings updated.');
    }
}
