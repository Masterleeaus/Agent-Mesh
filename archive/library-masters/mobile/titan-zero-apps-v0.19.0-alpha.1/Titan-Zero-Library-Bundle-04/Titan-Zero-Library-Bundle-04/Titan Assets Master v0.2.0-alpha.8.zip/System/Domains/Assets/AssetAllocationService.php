<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetAllocationService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets,private AssetSettingsService $settings,private AssetReferenceGuard $references){}
    public function list(int $userId):array{return$this->companies->query('titan_asset_allocations',$userId)->orderByDesc('allocated_at')->get()->map(fn($r)=>(array)$r)->all();}
    public function create(int $userId,string $type,string $asset,array $data):array
    {
        if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$this->references->assertUser($userId,isset($data['receiver_user_id'])?(int)$data['receiver_user_id']:null);$qty=max(1,(int)($data['quantity']??1));$id=(string)Str::ulid();
        $row=$this->companies->stamp('titan_asset_allocations',$userId,['public_id'=>$id,'subject_type'=>$type,'subject_public_id'=>$asset,'ref_no'=>$data['ref_no']??$this->settings->nextReference($userId,'allocation'),'quantity'=>$qty,'revoked_quantity'=>0,'receiver_user_id'=>$data['receiver_user_id']??null,'provider_user_id'=>$userId,'allocated_at'=>$data['allocated_at']??now(),'allocated_upto'=>$data['allocated_upto']??null,'status'=>'active','reason'=>$data['reason']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
        $this->db->table('titan_asset_allocations')->insert($row);$this->assets->update($userId,$type,$asset,$this->assignmentPatch($type,$data['receiver_user_id']??null,'allocated'));$this->assets->lifecycleEvent($userId,$type,$asset,'allocated',['metadata'=>['allocation_public_id'=>$id,'ref_no'=>$row['ref_no']]]);return$this->get($userId,$id);
    }
    public function update(int $userId,string $id,array $data):array{$this->get($userId,$id);if(array_key_exists('receiver_user_id',$data))$this->references->assertUser($userId,$data['receiver_user_id']===null?null:(int)$data['receiver_user_id']);$allowed=array_intersect_key($data,array_flip(['receiver_user_id','allocated_at','allocated_upto','reason','metadata']));if(isset($allowed['metadata'])&&is_array($allowed['metadata']))$allowed['metadata']=json_encode($allowed['metadata']);$allowed['updated_at']=now();$this->companies->query('titan_asset_allocations',$userId)->where('public_id',$id)->update($allowed);return$this->get($userId,$id);}
    public function revoke(int $userId,string $id,array $data=[]):array
    {
        $row=$this->get($userId,$id);$remain=max(0,(int)$row['quantity']-(int)$row['revoked_quantity']);$qty=min($remain,max(1,(int)($data['quantity']??$remain)));$revoked=(int)$row['revoked_quantity']+$qty;$status=$revoked>=(int)$row['quantity']?'revoked':'partially_revoked';
        $this->companies->query('titan_asset_allocations',$userId)->where('public_id',$id)->update(['revoked_quantity'=>$revoked,'status'=>$status,'reason'=>$data['reason']??$row['reason'],'updated_at'=>now()]);
        if($status==='revoked')$this->assets->update($userId,$row['subject_type'],$row['subject_public_id'],$this->assignmentPatch($row['subject_type'],null,'available'));
        $this->assets->lifecycleEvent($userId,$row['subject_type'],$row['subject_public_id'],'allocation_revoked',['metadata'=>['allocation_public_id'=>$id,'quantity'=>$qty,'ref_no'=>$data['ref_no']??$this->settings->nextReference($userId,'revoke')]]);return$this->get($userId,$id);
    }
    public function delete(int $userId,string $id):void{$row=$this->get($userId,$id);$this->companies->query('titan_asset_allocations',$userId)->where('public_id',$id)->delete();if(in_array((string)$row['status'],['active','partially_revoked'],true))$this->assets->update($userId,$row['subject_type'],$row['subject_public_id'],$this->assignmentPatch($row['subject_type'],null,'available'));$this->assets->lifecycleEvent($userId,$row['subject_type'],$row['subject_public_id'],'allocation_deleted',['metadata'=>['allocation_public_id'=>$id]]);}
    public function get(int $userId,string $id):array{$row=$this->companies->query('titan_asset_allocations',$userId)->where('public_id',$id)->first();if(!$row)throw new InvalidArgumentException('Allocation not found.');return(array)$row;}
    private function assignmentPatch(string$type,?int$user,string$status):array{return match($type){'tool'=>['custodian_user_id'=>$user,'status'=>$status==='allocated'?'checked_out':$status],'equipment'=>['assigned_user_id'=>$user,'status'=>$status==='allocated'?'active':$status],'vehicle'=>['assigned_user_id'=>$user,'status'=>$status==='allocated'?'active':$status],default=>[]};}
}
