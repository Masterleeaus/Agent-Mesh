<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class EquipmentCheckService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetReferenceGuard $references){}
    public function list(int$userId,?string$register=null):array{$q=$this->companies->query('titan_asset_equipment_checks',$userId);if($register)$q->where('register_public_id',$register);return$q->orderByDesc('checked_at')->limit(500)->get()->map(fn($r)=>(array)$r)->all();}
    public function record(int$userId,string$register,string$event,array$data=[]):array{$this->references->assertWorkOrder($userId,$data['work_order_public_id']??null);if(!in_array($event,['check_in','check_out'],true))throw new InvalidArgumentException('Invalid equipment check event.');if(!$this->companies->query('titan_asset_location_registers',$userId)->where('public_id',$register)->exists())throw new InvalidArgumentException('Location register entry not found.');$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_equipment_checks',$userId,['public_id'=>$id,'register_public_id'=>$register,'work_order_public_id'=>$data['work_order_public_id']??null,'checked_by_user_id'=>$userId,'event_type'=>$event,'notes'=>$data['notes']??null,'checked_at'=>$data['checked_at']??now(),'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_equipment_checks')->insert($row);return(array)$this->companies->query('titan_asset_equipment_checks',$userId)->where('public_id',$id)->first();}
}
