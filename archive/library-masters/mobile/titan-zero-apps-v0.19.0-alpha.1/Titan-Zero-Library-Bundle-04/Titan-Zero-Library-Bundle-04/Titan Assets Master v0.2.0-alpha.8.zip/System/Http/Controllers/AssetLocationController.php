<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetLocationRegisterService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetLocationController extends Controller
{
    public function __construct(private AssetLocationRegisterService $locations) {}

    public function index(Request $request)
    {
        return response()->json($this->locations->list((int) $request->user()->id, $request->query('location_public_id')));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'location_public_id' => 'required|string|max:26',
            'subject_type' => 'required|in:tool,equipment,vehicle',
            'subject_public_id' => 'required|string|max:26',
            'notes' => 'nullable|string|max:2000',
        ]);
        $row = $this->locations->register((int) $request->user()->id, $data['location_public_id'], $data['subject_type'], $data['subject_public_id'], $data);
        return $request->expectsJson() ? response()->json($row, 201) : back()->with('success', 'Asset added to location register.');
    }

    public function destroy(Request $request, string $register)
    {
        $this->locations->remove((int) $request->user()->id, $register);
        return $request->expectsJson() ? response()->json(['deleted' => true]) : back()->with('success', 'Location register entry removed.');
    }
}
