<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class FleetService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets){}
    public function get(int$userId,string$id):array{return$this->assets->get($userId,'vehicle',$id);}
    public function assign(int$userId,string$id,int$assignedUserId):array{$row=$this->get($userId,$id);$this->companies->query('crm_locker_fleet_vehicles',$userId)->where('public_id',$id)->update(['assigned_user_id'=>$assignedUserId,'assigned_at'=>now(),'updated_at'=>now()]);$this->assets->lifecycleEvent($userId,'vehicle',$id,'assigned',['metadata'=>['assigned_user_id'=>$assignedUserId]]);return$this->get($userId,$id);}
    public function unassign(int$userId,string$id):array{$this->get($userId,$id);$this->companies->query('crm_locker_fleet_vehicles',$userId)->where('public_id',$id)->update(['assigned_user_id'=>null,'assigned_at'=>null,'updated_at'=>now()]);$this->assets->lifecycleEvent($userId,'vehicle',$id,'unassigned');return$this->get($userId,$id);}
    public function updateOdometer(int$userId,string$id,int$km,array$data=[]):array{$r=$this->get($userId,$id);if($km<(int)($r['odometer_km']??0))throw new InvalidArgumentException('Odometer cannot move backwards.');$this->companies->query('crm_locker_fleet_vehicles',$userId)->where('public_id',$id)->update(['odometer_km'=>$km,'last_odometer_at'=>$data['occurred_at']??now(),'updated_at'=>now()]);$this->assets->lifecycleEvent($userId,'vehicle',$id,'odometer_updated',['metadata'=>['odometer_km'=>$km]]);return$this->get($userId,$id);}
    public function updateStatus(int$userId,string$id,string$status,array$data=[]):array{if(!in_array($status,['active','in_service','out_of_service','retired','sold'],true))throw new InvalidArgumentException('Invalid vehicle status.');$patch=['status'=>$status,'updated_at'=>now()];if($status==='retired')$patch['retired_on']=$data['retired_on']??now()->toDateString();if($status==='sold')$patch['sold_on']=$data['sold_on']??now()->toDateString();$this->companies->query('crm_locker_fleet_vehicles',$userId)->where('public_id',$id)->update($patch);$this->assets->lifecycleEvent($userId,'vehicle',$id,'status_'.$status,['metadata'=>$data]);return$this->get($userId,$id);}
    public function alerts(int$userId,int$days=30):array{$cutoff=now()->addDays($days)->toDateString();$vehicles=$this->companies->query('crm_locker_fleet_vehicles',$userId)->whereNull('deleted_at')->get()->map(fn($r)=>(array)$r)->all();return array_values(array_filter($vehicles,function(array$v)use($cutoff){$odo=(int)($v['odometer_km']??0);$serviceOdo=(int)($v['next_service_odometer_km']??0);return(($v['registration_expires_on']??null)&&$v['registration_expires_on']<=$cutoff)||(($v['next_service_on']??null)&&$v['next_service_on']<=$cutoff)||($serviceOdo>0&&$odo>=max(0,$serviceOdo-500));}));}
    public function report(int$userId):array{$rows=$this->assets->list($userId,'vehicle');$alerts=$this->alerts($userId,60);$alertIds=array_fill_keys(array_column($alerts,'public_id'),true);return['vehicles'=>array_map(fn(array$v)=>$v+['service_due'=>isset($alertIds[$v['public_id']])],$rows),'active'=>count(array_filter($rows,fn($v)=>($v['status']??'')==='active')),'out_of_service'=>count(array_filter($rows,fn($v)=>in_array(($v['status']??''),['out_of_service','in_service'],true))),'alerts'=>count($alerts)];}
}
