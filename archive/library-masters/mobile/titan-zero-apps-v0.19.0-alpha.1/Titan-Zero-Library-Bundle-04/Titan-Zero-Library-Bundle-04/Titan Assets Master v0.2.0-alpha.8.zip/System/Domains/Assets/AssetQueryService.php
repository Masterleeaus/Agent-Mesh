<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;

final class AssetQueryService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private RepairService $repairs,private AssetValuationService $valuation){}
    public function overview(int$userId):array
    {
        $count=fn(string$t)=>$this->companies->query($t,$userId)->when(Schema::hasColumn($t,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->count();
        return['tools'=>$count('crm_locker_tools'),'equipment'=>$count('crm_locker_equipment'),'vehicles'=>$count('crm_locker_fleet_vehicles'),'maintenance_due'=>$this->companies->query('crm_locker_maintenance_records',$userId)->whereIn('status',['scheduled','due','overdue'])->count(),'open_repairs'=>$this->companies->query('titan_asset_repairs',$userId)->whereNotIn('status',['completed','cancelled'])->count(),'warranties_expiring'=>$this->companies->query('titan_asset_warranties',$userId)->whereNotNull('expires_on')->whereBetween('expires_on',[now()->toDateString(),now()->addDays(30)->toDateString()])->count(),'active_allocations'=>$this->companies->query('titan_asset_allocations',$userId)->whereIn('status',['active','partially_revoked'])->count()];
    }
    public function customerAssets(int$userId):array
    {
        $out=[];foreach(['tool'=>'crm_locker_tools','equipment'=>'crm_locker_equipment','vehicle'=>'crm_locker_fleet_vehicles']as$type=>$table){if(!Schema::hasColumn($table,'customer_public_id'))continue;foreach($this->companies->query($table,$userId)->whereNotNull('customer_public_id')->when(Schema::hasColumn($table,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->get()as$r)$out[]=array_merge(['subject_type'=>$type],(array)$r);}return$out;
    }
    public function timeline(int$userId,string$type,string$id):array{return$this->companies->query('crm_locker_asset_events',$userId)->where('subject_type',$type)->where('subject_public_id',$id)->orderByDesc('occurred_at')->get()->map(fn($r)=>(array)$r)->all();}
    public function scan(int$userId,string$token):?array
    {
        $token=trim($token);if($token==='')return null;foreach(['tool'=>'crm_locker_tools','equipment'=>'crm_locker_equipment','vehicle'=>'crm_locker_fleet_vehicles']as$type=>$table){$q=$this->companies->query($table,$userId);$q->where(function($x)use($token,$type){$x->where('public_id',$token)->orWhere('qr_token',$token);if($type==='vehicle')$x->orWhere('registration',$token)->orWhere('vin',$token);else$x->orWhere('asset_tag',$token)->orWhere('serial_number',$token);});$r=$q->first();if($r)return['subject_type'=>$type,'asset'=>(array)$r,'timeline'=>$this->timeline($userId,$type,(string)$r->public_id)];}return null;
    }
    public function downtime(int$userId):array{return$this->repairs->downtimeSummary($userId);}
    public function assetHistory(int$userId):array{return$this->companies->query('crm_locker_asset_events',$userId)->orderByDesc('occurred_at')->limit(1000)->get()->map(fn($r)=>(array)$r)->all();}
    public function lifecycleReport(int$userId):array
    {
        $rows=[];foreach(['tool'=>'crm_locker_tools','equipment'=>'crm_locker_equipment','vehicle'=>'crm_locker_fleet_vehicles']as$type=>$table){foreach($this->companies->query($table,$userId)->when(Schema::hasColumn($table,'deleted_at'),fn($q)=>$q->whereNull('deleted_at'))->get()as$r){$a=(array)$r;$rows[]=$a+['subject_type'=>$type,'valuation'=>$this->valuation->value($userId,$type,(string)$a['public_id'])];}}return$rows;
    }
}
