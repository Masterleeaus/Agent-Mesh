<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;

final class AssetSettingsService
{
    public function __construct(private ConnectionInterface $db, private AssetCompanyContext $companies) {}

    public function get(int $userId): array
    {
        $companyId = $this->companies->id($userId);
        $row = $this->db->table('titan_asset_settings')->where('company_id', $companyId)->first();
        if (! $row) {
            $this->db->table('titan_asset_settings')->insert([
                'company_id' => $companyId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $row = $this->db->table('titan_asset_settings')->where('company_id', $companyId)->first();
        }
        $result = (array) $row;
        foreach (['maintenance_recipient_user_ids', 'metadata'] as $key) {
            if (isset($result[$key]) && is_string($result[$key])) {
                $result[$key] = json_decode($result[$key], true) ?: [];
            }
        }
        return $result;
    }

    public function update(int $userId, array $data): array
    {
        $this->get($userId);
        $allowed = array_intersect_key($data, array_flip([
            'asset_code_prefix',
            'allocation_code_prefix',
            'revoke_code_prefix',
            'maintenance_code_prefix',
            'notify_sent_for_maintenance',
            'notify_assigned_for_maintenance',
            'maintenance_recipient_user_ids',
            'send_for_maintenance_subject',
            'send_for_maintenance_body',
            'assigned_for_maintenance_subject',
            'assigned_for_maintenance_body',
            'metadata',
        ]));
        foreach (['maintenance_recipient_user_ids', 'metadata'] as $key) {
            if (isset($allowed[$key]) && is_array($allowed[$key])) {
                $allowed[$key] = json_encode($allowed[$key]);
            }
        }
        $allowed['updated_at'] = now();
        $this->db->table('titan_asset_settings')->where('company_id', $this->companies->id($userId))->update($allowed);
        return $this->get($userId);
    }

    public function nextReference(int $userId, string $kind): string
    {
        $settings = $this->get($userId);
        $prefix = match ($kind) {
            'allocation' => $settings['allocation_code_prefix'] ?? 'ALLOC',
            'revoke' => $settings['revoke_code_prefix'] ?? 'REVOKE',
            'maintenance' => $settings['maintenance_code_prefix'] ?? 'MAINT',
            default => $settings['asset_code_prefix'] ?? 'AST',
        };
        return strtoupper(trim((string) $prefix) ?: 'AST') . '-' . now()->format('YmdHis') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
    }
}
