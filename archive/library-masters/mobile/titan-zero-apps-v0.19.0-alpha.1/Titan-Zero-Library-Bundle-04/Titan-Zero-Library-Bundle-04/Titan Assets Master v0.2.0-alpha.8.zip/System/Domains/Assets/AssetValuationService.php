<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Carbon\CarbonImmutable;

final class AssetValuationService
{
    public function __construct(private AssetRegisterService $assets){}
    public function value(int$userId,string$type,string$id,?string$asOf=null):array
    {
        $row=$this->assets->get($userId,$type,$id);$cost=(int)($row['acquisition_cost_minor']??0);$salvage=(int)($row['salvage_value_minor']??0);$life=(int)($row['useful_life_months']??0);$method=(string)($row['depreciation_method']??'none');$acquired=$row['acquired_on']??null;$date=CarbonImmutable::parse($asOf??'now');$months=0;
        if($acquired)$months=max(0,CarbonImmutable::parse($acquired)->diffInMonths($date));$current=$cost;
        if($method==='straight_line'&&$life>0){$depreciable=max(0,$cost-$salvage);$current=max($salvage,(int)round($cost-($depreciable*min($life,$months)/$life)));}
        elseif($method==='none'&&isset($row['current_value_minor']))$current=(int)$row['current_value_minor'];
        return['subject_type'=>$type,'subject_public_id'=>$id,'method'=>$method,'acquisition_cost_minor'=>$cost,'salvage_value_minor'=>$salvage,'useful_life_months'=>$life,'months_elapsed'=>$months,'current_value_minor'=>$current,'as_of'=>$date->toDateString()];
    }
    public function refresh(int$userId,string$type,string$id,?string$asOf=null):array{$v=$this->value($userId,$type,$id,$asOf);$this->assets->update($userId,$type,$id,['current_value_minor'=>$v['current_value_minor']]);$this->assets->lifecycleEvent($userId,$type,$id,'valuation_refreshed',['value_minor'=>$v['current_value_minor'],'metadata'=>$v]);return$v;}
}
