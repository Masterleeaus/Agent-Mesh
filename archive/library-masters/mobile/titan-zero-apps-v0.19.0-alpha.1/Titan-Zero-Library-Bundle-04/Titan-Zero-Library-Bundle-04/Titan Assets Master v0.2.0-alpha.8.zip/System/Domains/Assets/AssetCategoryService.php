<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetCategoryService
{
    public function __construct(private ConnectionInterface $db, private AssetCompanyContext $companies) {}

    public function list(int $userId): array
    {
        return $this->companies->query('titan_asset_categories', $userId)
            ->orderBy('name')
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }

    public function get(int $userId, string $publicId): array
    {
        $row = $this->companies->query('titan_asset_categories', $userId)->where('public_id', $publicId)->first();
        if (! $row) {
            throw new InvalidArgumentException('Asset category not found.');
        }
        return (array) $row;
    }

    public function create(int $userId, array $data): array
    {
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new InvalidArgumentException('Asset category name is required.');
        }
        if ($this->companies->query('titan_asset_categories', $userId)->where('name', $name)->exists()) {
            throw new InvalidArgumentException('Asset category already exists.');
        }
        $publicId = (string) Str::ulid();
        $row = $this->companies->stamp('titan_asset_categories', $userId, [
            'public_id' => $publicId,
            'name' => $name,
            'code' => isset($data['code']) ? trim((string) $data['code']) ?: null : null,
            'parent_public_id' => $data['parent_public_id'] ?? null,
            'description' => $data['description'] ?? null,
            'active' => (bool) ($data['active'] ?? $data['is_active'] ?? true),
            'added_by_user_id' => $userId,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->db->table('titan_asset_categories')->insert($row);
        return $this->get($userId, $publicId);
    }

    public function update(int $userId, string $publicId, array $data): array
    {
        $this->get($userId, $publicId);
        $allowed = array_intersect_key($data, array_flip(['name', 'code', 'parent_public_id', 'description', 'active', 'is_active']));
        if (array_key_exists('is_active', $allowed)) {
            $allowed['active'] = (bool) $allowed['is_active'];
            unset($allowed['is_active']);
        }
        if (isset($allowed['code'])) {
            $allowed['code'] = trim((string) $allowed['code']) ?: null;
        }
        if (isset($allowed['name'])) {
            $allowed['name'] = trim((string) $allowed['name']);
            if ($allowed['name'] === '') {
                throw new InvalidArgumentException('Asset category name is required.');
            }
        }
        $allowed['updated_at'] = now();
        $this->companies->query('titan_asset_categories', $userId)->where('public_id', $publicId)->update($allowed);
        return $this->get($userId, $publicId);
    }

    public function delete(int $userId, string $publicId): void
    {
        $this->get($userId, $publicId);
        $this->companies->query('titan_asset_categories', $userId)->where('public_id', $publicId)->delete();
    }
}
