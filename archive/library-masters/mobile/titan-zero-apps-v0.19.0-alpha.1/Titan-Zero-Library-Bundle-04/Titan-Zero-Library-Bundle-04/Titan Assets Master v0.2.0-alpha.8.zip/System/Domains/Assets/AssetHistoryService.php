<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetHistoryService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets){}
    public function list(int $userId,?string$type=null,?string$asset=null):array{$q=$this->companies->query('titan_asset_lending_history',$userId);if($type)$q->where('subject_type',$type);if($asset)$q->where('subject_public_id',$asset);return$q->orderByDesc('issued_at')->get()->map(fn($r)=>(array)$r)->all();}
    public function issue(int$userId,string$type,string$asset,array$data):array
    {
        if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_lending_history',$userId,['public_id'=>$id,'subject_type'=>$type,'subject_public_id'=>$asset,'borrower_user_id'=>$data['borrower_user_id']??$userId,'lender_user_id'=>$userId,'returner_user_id'=>null,'issued_at'=>$data['issued_at']??now(),'due_at'=>$data['due_at']??null,'returned_at'=>null,'notes'=>$data['notes']??null,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_lending_history')->insert($row);$this->assets->update($userId,$type,$asset,$this->assignmentPatch($type,(int)$row['borrower_user_id'],'lent'));$this->assets->lifecycleEvent($userId,$type,$asset,'issued',['metadata'=>['history_public_id'=>$id,'borrower_user_id'=>$row['borrower_user_id']]]);return$this->get($userId,$id);
    }
    public function returnAsset(int$userId,string$id,array$data=[]):array{$row=$this->get($userId,$id);if($row['returned_at'])throw new InvalidArgumentException('Asset is already returned.');$this->companies->query('titan_asset_lending_history',$userId)->where('public_id',$id)->update(['returner_user_id'=>$userId,'returned_at'=>$data['returned_at']??now(),'notes'=>$data['notes']??$row['notes'],'updated_at'=>now()]);$this->assets->update($userId,$row['subject_type'],$row['subject_public_id'],$this->assignmentPatch($row['subject_type'],null,'available'));$this->assets->lifecycleEvent($userId,$row['subject_type'],$row['subject_public_id'],'returned',['metadata'=>['history_public_id'=>$id]]);return$this->get($userId,$id);}
    public function update(int$userId,string$id,array$data):array{$this->get($userId,$id);$row=array_intersect_key($data,array_flip(['borrower_user_id','issued_at','due_at','notes']));$row['updated_at']=now();$this->companies->query('titan_asset_lending_history',$userId)->where('public_id',$id)->update($row);return$this->get($userId,$id);}
    public function delete(int$userId,string$id):void{$row=$this->get($userId,$id);$this->companies->query('titan_asset_lending_history',$userId)->where('public_id',$id)->delete();if(empty($row['returned_at']))$this->assets->update($userId,$row['subject_type'],$row['subject_public_id'],$this->assignmentPatch($row['subject_type'],null,'available'));$this->assets->lifecycleEvent($userId,$row['subject_type'],$row['subject_public_id'],'lending_history_deleted',['metadata'=>['history_public_id'=>$id]]);}
    public function get(int$userId,string$id):array{$r=$this->companies->query('titan_asset_lending_history',$userId)->where('public_id',$id)->first();if(!$r)throw new InvalidArgumentException('Asset history record not found.');return(array)$r;}
    private function assignmentPatch(string$type,?int$user,string$status):array{return match($type){'tool'=>['custodian_user_id'=>$user,'status'=>$status==='lent'?'checked_out':$status],'equipment'=>['assigned_user_id'=>$user,'status'=>$status==='lent'?'lent':$status],'vehicle'=>['assigned_user_id'=>$user],default=>[]};}
}
