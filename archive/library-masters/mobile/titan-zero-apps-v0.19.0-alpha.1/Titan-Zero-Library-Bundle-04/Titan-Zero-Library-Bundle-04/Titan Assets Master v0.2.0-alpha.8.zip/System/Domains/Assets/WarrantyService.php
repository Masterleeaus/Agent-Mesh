<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WarrantyService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets,private WarrantyProfileService $profiles){}
    public function list(int$userId):array{return array_map(fn(array$r)=>$r+['computed_status'=>$this->warrantyStatus($r)],$this->companies->query('titan_asset_warranties',$userId)->orderBy('expires_on')->get()->map(fn($r)=>(array)$r)->all());}
    public function get(int$userId,string$id):array{$r=$this->companies->query('titan_asset_warranties',$userId)->where('public_id',$id)->first();if(!$r)throw new InvalidArgumentException('Warranty not found.');$a=(array)$r;$a['computed_status']=$this->warrantyStatus($a);return$a;}
    public function create(int$userId,string$type,string$asset,array$data):array
    {
        if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$start=$data['starts_on']??$data['warranty_start']??null;$end=$data['expires_on']??$data['warranty_end']??null;$profile=$data['profile_public_id']??null;if($profile&&$start&&!$end)$end=$this->profiles->compute($userId,$profile,(string)$start);$id=(string)Str::ulid();
        $row=$this->companies->stamp('titan_asset_warranties',$userId,['public_id'=>$id,'subject_type'=>$type,'subject_public_id'=>$asset,'provider_name'=>$data['provider_name']??$data['supplier']??null,'policy_number'=>$data['policy_number']??$data['warranty_number']??null,'starts_on'=>$start,'expires_on'=>$end,'status'=>$data['status']??'active','coverage_notes'=>$data['coverage_notes']??$data['notes']??null,'profile_public_id'=>$profile,'supplier_name'=>$data['supplier_name']??$data['supplier']??null,'warranty_number'=>$data['warranty_number']??$data['policy_number']??null,'claim_reference'=>$data['claim_reference']??null,'claimed_at'=>$data['claimed_at']??null,'additional_cost_minor'=>isset($data['additional_cost_minor'])?max(0,(int)$data['additional_cost_minor']):0,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_by_user_id'=>$userId,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_warranties')->insert($row);$this->assets->update($userId,$type,$asset,['warranty_expires_on'=>$end]);$this->assets->lifecycleEvent($userId,$type,$asset,'warranty_registered',['metadata'=>['warranty_public_id'=>$id,'expires_on'=>$end]]);return$this->get($userId,$id);
    }
    public function update(int$userId,string$id,array$data):array{$r=$this->get($userId,$id);$allowed=array_intersect_key($data,array_flip(['provider_name','policy_number','starts_on','expires_on','status','coverage_notes','profile_public_id','supplier_name','warranty_number','claim_reference','claimed_at','additional_cost_minor','metadata']));if(isset($allowed['metadata'])&&is_array($allowed['metadata']))$allowed['metadata']=json_encode($allowed['metadata']);if(isset($allowed['profile_public_id'])&&($allowed['starts_on']??$r['starts_on'])&&!isset($allowed['expires_on']))$allowed['expires_on']=$this->profiles->compute($userId,$allowed['profile_public_id'],(string)($allowed['starts_on']??$r['starts_on']));$allowed['updated_at']=now();$this->companies->query('titan_asset_warranties',$userId)->where('public_id',$id)->update($allowed);if(array_key_exists('expires_on',$allowed))$this->assets->update($userId,$r['subject_type'],$r['subject_public_id'],['warranty_expires_on'=>$allowed['expires_on']]);return$this->get($userId,$id);}
    public function setStatus(int$userId,string$id,string$status):array{return$this->update($userId,$id,['status'=>$status,'claimed_at'=>$status==='claimed'?now():null]);}
    public function delete(int$userId,string$id):void{$r=$this->get($userId,$id);$this->companies->query('titan_asset_warranties',$userId)->where('public_id',$id)->delete();$this->assets->lifecycleEvent($userId,$r['subject_type'],$r['subject_public_id'],'warranty_deleted',['metadata'=>['warranty_public_id'=>$id]]);}
    public function warrantyStatus(array$warranty,int$expiringDays=14):string{$end=$warranty['expires_on']??null;if(!$end)return(string)($warranty['status']??'active');$today=CarbonImmutable::today();$expires=CarbonImmutable::parse($end);if($expires->lt($today))return'expired';if($today->diffInDays($expires)<=$expiringDays)return'expiring_soon';return(string)($warranty['status']??'active');}
}
