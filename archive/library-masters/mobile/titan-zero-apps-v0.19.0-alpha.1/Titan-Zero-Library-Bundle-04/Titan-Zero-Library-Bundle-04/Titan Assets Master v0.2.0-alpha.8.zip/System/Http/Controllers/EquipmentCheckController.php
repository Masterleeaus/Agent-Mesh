<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\EquipmentCheckService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class EquipmentCheckController extends Controller
{
    public function __construct(private EquipmentCheckService $checks) {}

    public function index(Request $request)
    {
        return response()->json($this->checks->list((int) $request->user()->id, $request->query('register_public_id')));
    }

    public function store(Request $request, string $register)
    {
        $data = $request->validate([
            'event_type' => 'required|in:check_in,check_out',
            'work_order_public_id' => 'nullable|string|max:26',
            'notes' => 'nullable|string|max:2000',
            'checked_at' => 'nullable|date',
        ]);
        $row = $this->checks->record((int) $request->user()->id, $register, $data['event_type'], $data);
        return $request->expectsJson() ? response()->json($row, 201) : back()->with('success', 'Equipment check recorded.');
    }
}
