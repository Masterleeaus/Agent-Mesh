<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class PremisesLinkService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets){}
    public function list(int$userId):array{return$this->companies->query('titan_asset_premises_links',$userId)->orderByDesc('created_at')->get()->map(fn($r)=>(array)$r)->all();}
    public function link(int$userId,string$type,string$asset,string$premise,array$data=[]):array{if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$existing=$this->companies->query('titan_asset_premises_links',$userId)->where('subject_type',$type)->where('subject_public_id',$asset)->where('premise_public_id',$premise)->first();if($existing)return(array)$existing;$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_premises_links',$userId,['public_id'=>$id,'subject_type'=>$type,'subject_public_id'=>$asset,'premise_public_id'=>$premise,'relationship'=>$data['relationship']??'located_at','notes'=>$data['notes']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_by_user_id'=>$userId,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_premises_links')->insert($row);$this->assets->lifecycleEvent($userId,$type,$asset,'premises_linked',['metadata'=>['premise_public_id'=>$premise]]);return(array)$this->companies->query('titan_asset_premises_links',$userId)->where('public_id',$id)->first();}
    public function unlink(int$userId,string$id):void{$r=$this->companies->query('titan_asset_premises_links',$userId)->where('public_id',$id)->first();if(!$r)throw new InvalidArgumentException('Premises link not found.');$this->companies->query('titan_asset_premises_links',$userId)->where('public_id',$id)->delete();$this->assets->lifecycleEvent($userId,$r->subject_type,$r->subject_public_id,'premises_unlinked',['metadata'=>['premise_public_id'=>$r->premise_public_id]]);}
}
