<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetLocationRegisterService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets,private AssetReferenceGuard $references){}
    public function list(int$userId,?string$location=null):array{$q=$this->companies->query('titan_asset_location_registers',$userId);if($location)$q->where('location_public_id',$location);return$q->orderBy('location_public_id')->get()->map(fn($r)=>(array)$r)->all();}
    public function register(int$userId,string$location,string$type,string$asset,array$data=[]):array{$this->references->assertServiceLocation($userId,$location);if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$existing=$this->companies->query('titan_asset_location_registers',$userId)->where('location_public_id',$location)->where('subject_type',$type)->where('subject_public_id',$asset)->first();if($existing){$this->companies->query('titan_asset_location_registers',$userId)->where('id',$existing->id)->update(['active'=>true,'notes'=>$data['notes']??$existing->notes,'updated_at'=>now()]);return(array)$this->companies->query('titan_asset_location_registers',$userId)->where('id',$existing->id)->first();}$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_location_registers',$userId,['public_id'=>$id,'location_public_id'=>$location,'subject_type'=>$type,'subject_public_id'=>$asset,'notes'=>$data['notes']??null,'active'=>true,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_location_registers')->insert($row);$this->assets->update($userId,$type,$asset,['location_public_id'=>$location]);$this->assets->lifecycleEvent($userId,$type,$asset,'location_registered',['location_public_id'=>$location]);return(array)$this->companies->query('titan_asset_location_registers',$userId)->where('public_id',$id)->first();}
    public function remove(int$userId,string$id):void{$row=$this->companies->query('titan_asset_location_registers',$userId)->where('public_id',$id)->first();if(!$row)throw new InvalidArgumentException('Location register entry not found.');$this->companies->query('titan_asset_location_registers',$userId)->where('public_id',$id)->delete();$this->assets->lifecycleEvent($userId,$row->subject_type,$row->subject_public_id,'location_unregistered',['location_public_id'=>$row->location_public_id]);}
}
