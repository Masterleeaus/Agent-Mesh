<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetTypeService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies){}
    public function list(int $userId):array{return$this->companies->query('titan_asset_types',$userId)->orderBy('applies_to')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();}
    public function create(int $userId,array $data):array{$name=trim((string)($data['name']??''));if($name==='')throw new InvalidArgumentException('Asset type name is required.');$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_types',$userId,['public_id'=>$id,'name'=>$name,'applies_to'=>$data['applies_to']??'equipment','description'=>$data['description']??null,'active'=>(bool)($data['active']??true),'added_by_user_id'=>$userId,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_types')->insert($row);return$this->get($userId,$id);}
    public function update(int $userId,string $id,array $data):array{$this->get($userId,$id);$row=array_intersect_key($data,array_flip(['name','applies_to','description','active']));$row['updated_at']=now();$this->companies->query('titan_asset_types',$userId)->where('public_id',$id)->update($row);return$this->get($userId,$id);}
    public function delete(int $userId,string $id):void{$this->companies->query('titan_asset_types',$userId)->where('public_id',$id)->delete();}
    public function get(int $userId,string $id):array{$row=$this->companies->query('titan_asset_types',$userId)->where('public_id',$id)->first();if(!$row)throw new InvalidArgumentException('Asset type not found.');return(array)$row;}
}
