<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\WarrantyProfileService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class WarrantyProfileController extends Controller
{
    public function __construct(private WarrantyProfileService $profiles) {}

    public function store(Request $request)
    {
        $row = $this->profiles->create((int) $request->user()->id, $request->validate($this->rules()));
        return $this->respond($request, $row, 'Warranty profile created.', 201);
    }

    public function update(Request $request, string $profile)
    {
        $row = $this->profiles->update((int) $request->user()->id, $profile, $request->validate($this->rules(false)));
        return $this->respond($request, $row, 'Warranty profile updated.');
    }

    public function destroy(Request $request, string $profile)
    {
        $this->profiles->delete((int) $request->user()->id, $profile);
        return $request->expectsJson() ? response()->json(['deleted' => true]) : back()->with('success', 'Warranty profile deleted.');
    }

    public function compute(Request $request, string $profile)
    {
        $data = $request->validate(['starts_on' => 'required|date']);
        return response()->json(['expires_on' => $this->profiles->compute((int) $request->user()->id, $profile, $data['starts_on'])]);
    }

    private function rules(bool $create = true): array
    {
        return [
            'name' => ($create ? 'required' : 'sometimes') . '|string|max:180',
            'equipment_category' => 'nullable|string|max:120',
            'warranty_duration' => ($create ? 'required' : 'sometimes') . '|integer|min:1',
            'warranty_type' => 'nullable|in:day,week,month,year',
            'notes' => 'nullable|string|max:2000',
            'active' => 'nullable|boolean',
        ];
    }

    private function respond(Request $request, array $row, string $message, int $status = 200)
    {
        return $request->expectsJson() ? response()->json($row, $status) : back()->with('success', $message);
    }
}
