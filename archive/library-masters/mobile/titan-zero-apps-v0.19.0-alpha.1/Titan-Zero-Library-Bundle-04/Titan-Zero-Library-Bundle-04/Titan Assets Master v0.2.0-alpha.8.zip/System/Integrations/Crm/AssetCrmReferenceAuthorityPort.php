<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Integrations\Crm;

interface AssetCrmReferenceAuthorityPort
{
    public function assertWorkOrderAccessible(int $companyId,int $actorUserId,string $publicId): void;
    public function assertServiceLocationAccessible(int $companyId,int $actorUserId,string $publicId): void;
}
