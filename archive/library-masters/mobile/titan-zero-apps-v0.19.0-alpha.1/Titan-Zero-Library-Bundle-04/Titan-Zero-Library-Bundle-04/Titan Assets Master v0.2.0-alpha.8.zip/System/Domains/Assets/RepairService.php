<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RepairService
{
    private const STAGES = ['open', 'new', 'approved', 'in_progress', 'awaiting_parts', 'completed', 'cancelled'];

    public function __construct(
        private ConnectionInterface $db,
        private AssetCompanyContext $companies,
        private AssetRegisterService $assets,
        private AssetReferenceGuard $references,
    ) {}

    public function list(int $userId): array
    {
        return $this->companies->query('titan_asset_repairs', $userId)
            ->orderByDesc('reported_at')
            ->get()
            ->map(fn ($row) => $this->decorate((array) $row))
            ->all();
    }

    public function get(int $userId, string $id): array
    {
        $row = $this->companies->query('titan_asset_repairs', $userId)->where('public_id', $id)->first();
        if (! $row) {
            throw new InvalidArgumentException('Repair not found.');
        }
        return $this->decorate((array) $row);
    }

    public function create(int $userId, string $type, string $asset, array $data): array
    {
        if (! $this->assets->exists($userId, $type, $asset)) {
            throw new InvalidArgumentException('Asset not found.');
        }

        $this->assertForeignReferences($userId,$data);
        $status = (string) ($data['status'] ?? 'open');
        if (! in_array($status, self::STAGES, true)) {
            throw new InvalidArgumentException('Invalid repair stage.');
        }

        $id = (string) Str::ulid();
        $underWarranty = $this->isUnderWarranty($userId, $type, $asset, $data['reported_at'] ?? now());
        $partsCost = $this->minor($data['parts_cost_minor'] ?? null);
        $labourCost = $this->minor($data['labour_cost_minor'] ?? null);
        $actualCost = $this->minor($data['actual_cost_minor'] ?? null);
        if ($actualCost === null && ($partsCost !== null || $labourCost !== null)) {
            $actualCost = ($partsCost ?? 0) + ($labourCost ?? 0);
        }

        $row = $this->companies->stamp('titan_asset_repairs', $userId, [
            'public_id' => $id,
            'subject_type' => $type,
            'subject_public_id' => $asset,
            'repair_template_public_id' => $data['repair_template_public_id'] ?? null,
            'repair_type' => $data['repair_type'] ?? 'repair',
            'priority' => $data['priority'] ?? 'normal',
            'status' => $status,
            'summary' => trim((string) ($data['summary'] ?? $data['name'] ?? 'Repair')),
            'details' => $data['details'] ?? $data['description'] ?? null,
            'supplier_public_id' => $data['supplier_public_id'] ?? null,
            'estimated_cost_minor' => $this->minor($data['estimated_cost_minor'] ?? null),
            'actual_cost_minor' => $actualCost,
            'parts_cost_minor' => $partsCost,
            'labour_cost_minor' => $labourCost,
            'repair_count' => max(1, (int) ($data['repair_count'] ?? 1)),
            'currency' => strtoupper((string) ($data['currency'] ?? 'AUD')),
            'reported_at' => $data['reported_at'] ?? now(),
            'scheduled_for' => $data['scheduled_for'] ?? null,
            'completed_at' => $data['completed_at'] ?? null,
            'reported_by_user_id' => $data['reported_by_user_id'] ?? $userId,
            'assigned_to_user_id' => $data['assigned_to_user_id'] ?? null,
            'location_public_id' => $data['location_public_id'] ?? null,
            'work_order_public_id' => $data['work_order_public_id'] ?? null,
            'root_cause' => $data['root_cause'] ?? null,
            'parts_used' => $data['parts_used'] ?? null,
            'under_warranty' => array_key_exists('under_warranty', $data) ? (bool) $data['under_warranty'] : $underWarranty,
            'downtime_started_at' => $data['downtime_started_at'] ?? ($data['reported_at'] ?? now()),
            'downtime_ended_at' => $data['downtime_ended_at'] ?? null,
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata'], JSON_UNESCAPED_SLASHES) : null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->db->table('titan_asset_repairs')->insert($row);
        $this->assets->update($userId, $type, $asset, ['status' => 'under-maintenance']);
        $this->assets->lifecycleEvent($userId, $type, $asset, 'repair_opened', [
            'metadata' => [
                'repair_public_id' => $id,
                'under_warranty' => (bool) $row['under_warranty'],
                'parts_cost_minor' => $partsCost,
                'labour_cost_minor' => $labourCost,
            ],
        ]);

        return $this->get($userId, $id);
    }

    public function update(int $userId, string $id, array $data): array
    {
        $existing = $this->get($userId, $id);
        $this->assertForeignReferences($userId,$data);
        $allowed = array_intersect_key($data, array_flip([
            'repair_template_public_id', 'repair_type', 'priority', 'status', 'summary', 'details',
            'supplier_public_id', 'estimated_cost_minor', 'actual_cost_minor', 'parts_cost_minor',
            'labour_cost_minor', 'repair_count', 'currency', 'scheduled_for', 'completed_at',
            'assigned_to_user_id', 'location_public_id', 'work_order_public_id', 'root_cause',
            'parts_used', 'under_warranty', 'downtime_started_at', 'downtime_ended_at', 'metadata',
        ]));

        if (isset($allowed['status']) && ! in_array((string) $allowed['status'], self::STAGES, true)) {
            throw new InvalidArgumentException('Invalid repair stage.');
        }
        foreach (['estimated_cost_minor', 'actual_cost_minor', 'parts_cost_minor', 'labour_cost_minor'] as $field) {
            if (array_key_exists($field, $allowed)) {
                $allowed[$field] = $this->minor($allowed[$field]);
            }
        }
        if (array_key_exists('repair_count', $allowed)) {
            $allowed['repair_count'] = max(1, (int) $allowed['repair_count']);
        }
        if (array_key_exists('currency', $allowed)) {
            $allowed['currency'] = strtoupper((string) $allowed['currency']);
        }
        if (array_key_exists('under_warranty', $allowed)) {
            $allowed['under_warranty'] = (bool) $allowed['under_warranty'];
        }
        if (isset($allowed['metadata']) && is_array($allowed['metadata'])) {
            $allowed['metadata'] = json_encode($allowed['metadata'], JSON_UNESCAPED_SLASHES);
        }

        $parts = array_key_exists('parts_cost_minor', $allowed) ? $allowed['parts_cost_minor'] : ($existing['parts_cost_minor'] ?? null);
        $labour = array_key_exists('labour_cost_minor', $allowed) ? $allowed['labour_cost_minor'] : ($existing['labour_cost_minor'] ?? null);
        if (! array_key_exists('actual_cost_minor', $allowed) && ($parts !== null || $labour !== null)) {
            $allowed['actual_cost_minor'] = (int) ($parts ?? 0) + (int) ($labour ?? 0);
        }
        $allowed['updated_at'] = now();

        $this->companies->query('titan_asset_repairs', $userId)->where('public_id', $id)->update($allowed);
        return $this->get($userId, $id);
    }

    public function setStatus(int $userId, string $id, string $status, array $data = []): array
    {
        if (! in_array($status, self::STAGES, true)) {
            throw new InvalidArgumentException('Invalid repair stage.');
        }
        $row = $this->get($userId, $id);
        $patch = ['status' => $status];
        if ($status === 'completed') {
            $patch['completed_at'] = $data['completed_at'] ?? now();
            $patch['downtime_ended_at'] = $data['downtime_ended_at'] ?? $patch['completed_at'];
        }
        $updated = $this->update($userId, $id, $patch + $data);
        if ($status === 'completed') {
            $this->assets->update($userId, $row['subject_type'], $row['subject_public_id'], ['status' => 'available']);
        }
        $this->assets->lifecycleEvent($userId, $row['subject_type'], $row['subject_public_id'], 'repair_' . $status, [
            'metadata' => ['repair_public_id' => $id],
        ]);
        return $updated;
    }

    public function delete(int $userId, string $id): void
    {
        $row = $this->get($userId, $id);
        $this->companies->query('titan_asset_repairs', $userId)->where('public_id', $id)->delete();
        $stillOpen = $this->companies->query('titan_asset_repairs', $userId)
            ->where('subject_type', $row['subject_type'])
            ->where('subject_public_id', $row['subject_public_id'])
            ->whereNotIn('status', ['completed', 'cancelled'])
            ->exists();
        if (! $stillOpen) {
            $this->assets->update($userId, $row['subject_type'], $row['subject_public_id'], ['status' => 'available']);
        }
        $this->assets->lifecycleEvent($userId, $row['subject_type'], $row['subject_public_id'], 'repair_deleted', [
            'metadata' => ['repair_public_id' => $id],
        ]);
    }

    public function downtime(int $userId): array
    {
        return array_map(function (array $row): array {
            $start = $row['downtime_started_at'] ?? $row['reported_at'] ?? null;
            $end = $row['downtime_ended_at'] ?? $row['completed_at'] ?? now();
            if ($start) {
                $from = CarbonImmutable::parse($start);
                $to = CarbonImmutable::parse($end);
                $row['downtime_hours'] = $from->diffInHours($to);
                $row['downtime_days'] = $from->diffInDays($to);
            } else {
                $row['downtime_hours'] = null;
                $row['downtime_days'] = null;
            }
            return $row;
        }, $this->list($userId));
    }

    public function downtimeSummary(int $userId): array
    {
        $groups = [];
        foreach ($this->downtime($userId) as $row) {
            $key = ($row['subject_type'] ?? '') . ':' . ($row['subject_public_id'] ?? '');
            $groups[$key] ??= [
                'subject_type' => $row['subject_type'] ?? null,
                'subject_public_id' => $row['subject_public_id'] ?? null,
                'repair_count' => 0,
                'open_repairs' => 0,
                'total_hours' => 0,
                'total_days' => 0,
                'total_cost_minor' => 0,
            ];
            $groups[$key]['repair_count']++;
            $groups[$key]['total_hours'] += (int) ($row['downtime_hours'] ?? 0);
            $groups[$key]['total_days'] += (int) ($row['downtime_days'] ?? 0);
            $groups[$key]['total_cost_minor'] += (int) ($row['actual_cost_minor'] ?? 0);
            if (! in_array($row['status'] ?? '', ['completed', 'cancelled'], true)) {
                $groups[$key]['open_repairs']++;
            }
        }
        $rows = array_values($groups);
        usort($rows, static fn (array $a, array $b): int => $b['total_hours'] <=> $a['total_hours']);
        return $rows;
    }

    private function decorate(array $row): array
    {
        $row['computed_total_cost_minor'] = (int) ($row['actual_cost_minor'] ?? (($row['parts_cost_minor'] ?? 0) + ($row['labour_cost_minor'] ?? 0)));
        return $row;
    }

    private function assertForeignReferences(int $userId,array $data): void
    {
        if(array_key_exists('assigned_to_user_id',$data))$this->references->assertUser($userId,$data['assigned_to_user_id']===null?null:(int)$data['assigned_to_user_id']);
        if(array_key_exists('reported_by_user_id',$data))$this->references->assertUser($userId,$data['reported_by_user_id']===null?null:(int)$data['reported_by_user_id']);
        $this->references->assertServiceLocation($userId,$data['location_public_id']??null);
        $this->references->assertWorkOrder($userId,$data['work_order_public_id']??null);
    }

    private function minor(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        return max(0, (int) $value);
    }

    private function isUnderWarranty(int $userId, string $type, string $asset, mixed $when): bool
    {
        $date = CarbonImmutable::parse($when)->toDateString();
        return $this->companies->query('titan_asset_warranties', $userId)
            ->where('subject_type', $type)
            ->where('subject_public_id', $asset)
            ->where(function ($query) use ($date): void {
                $query->whereNull('starts_on')->orWhere('starts_on', '<=', $date);
            })
            ->where(function ($query) use ($date): void {
                $query->whereNull('expires_on')->orWhere('expires_on', '>=', $date);
            })
            ->whereIn('status', ['active', 'expiring_soon'])
            ->exists();
    }
}
