<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetRegisterService
{
    public function __construct(
        private ConnectionInterface $db,
        private AssetCompanyContext $companies,
        private AssetSettingsService $settings,
    ) {}

    public function list(int $userId, string $type): array
    {
        $table = $this->table($type);
        $order = $type === 'vehicle' ? 'registration' : 'name';
        return $this->companies->query($table, $userId)
            ->when(Schema::hasColumn($table, 'deleted_at'), fn ($q) => $q->whereNull('deleted_at'))
            ->orderBy($order)
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }

    public function get(int $userId, string $type, string $publicId): array
    {
        $table = $this->table($type);
        $row = $this->companies->query($table, $userId)
            ->where('public_id', $publicId)
            ->when(Schema::hasColumn($table, 'deleted_at'), fn ($q) => $q->whereNull('deleted_at'))
            ->first();
        if (! $row) {
            throw new InvalidArgumentException('Asset not found.');
        }
        return (array) $row;
    }

    public function createTool(int $userId, array $data): array
    {
        return $this->create($userId, 'tool', $data, [
            'inventory_item_public_id' => $data['inventory_item_public_id'] ?? null,
            'asset_tag' => $this->tag($userId, $data),
            'name' => $this->name($data),
            'serial_number' => $data['serial_number'] ?? null,
            'status' => $data['status'] ?? 'available',
            'custodian_user_id' => $data['custodian_user_id'] ?? null,
            'location_public_id' => $data['location_public_id'] ?? null,
            'acquired_on' => $data['acquired_on'] ?? null,
            'acquisition_cost_minor' => $data['acquisition_cost_minor'] ?? null,
            'current_value_minor' => $data['current_value_minor'] ?? $data['acquisition_cost_minor'] ?? null,
            'warranty_expires_on' => $data['warranty_expires_on'] ?? null,
            'retired_on' => $data['retired_on'] ?? null,
        ]);
    }

    public function createEquipment(int $userId, array $data): array
    {
        return $this->create($userId, 'equipment', $data, [
            'asset_tag' => $this->tag($userId, $data),
            'equipment_type' => $data['equipment_type'] ?? null,
            'name' => $this->name($data),
            'manufacturer' => $data['manufacturer'] ?? null,
            'model' => $data['model'] ?? null,
            'serial_number' => $data['serial_number'] ?? null,
            'status' => $data['status'] ?? 'active',
            'assigned_user_id' => $data['assigned_user_id'] ?? null,
            'location_public_id' => $data['location_public_id'] ?? null,
            'acquired_on' => $data['acquired_on'] ?? null,
            'acquisition_cost_minor' => $data['acquisition_cost_minor'] ?? null,
            'current_value_minor' => $data['current_value_minor'] ?? $data['acquisition_cost_minor'] ?? null,
            'depreciation_method' => $data['depreciation_method'] ?? 'none',
            'useful_life_months' => $data['useful_life_months'] ?? null,
            'salvage_value_minor' => $data['salvage_value_minor'] ?? null,
            'warranty_expires_on' => $data['warranty_expires_on'] ?? null,
            'next_service_on' => $data['next_service_on'] ?? null,
            'retired_on' => $data['retired_on'] ?? null,
            'sold_on' => $data['sold_on'] ?? null,
        ]);
    }

    public function createVehicle(int $userId, array $data): array
    {
        $registration = trim((string) ($data['registration'] ?? ''));
        if ($registration === '') {
            throw new InvalidArgumentException('Vehicle registration is required.');
        }
        return $this->create($userId, 'vehicle', $data, [
            'registration' => $registration,
            'vin' => $data['vin'] ?? null,
            'make' => $data['make'] ?? null,
            'model' => $data['model'] ?? null,
            'year' => $data['year'] ?? null,
            'status' => $data['status'] ?? 'active',
            'assigned_user_id' => $data['assigned_user_id'] ?? null,
            'odometer_km' => $data['odometer_km'] ?? null,
            'acquired_on' => $data['acquired_on'] ?? null,
            'acquisition_cost_minor' => $data['acquisition_cost_minor'] ?? null,
            'current_value_minor' => $data['current_value_minor'] ?? $data['acquisition_cost_minor'] ?? null,
            'depreciation_method' => $data['depreciation_method'] ?? 'none',
            'useful_life_months' => $data['useful_life_months'] ?? null,
            'salvage_value_minor' => $data['salvage_value_minor'] ?? null,
            'registration_expires_on' => $data['registration_expires_on'] ?? null,
            'warranty_expires_on' => $data['warranty_expires_on'] ?? null,
            'next_service_on' => $data['next_service_on'] ?? null,
            'retired_on' => $data['retired_on'] ?? null,
            'sold_on' => $data['sold_on'] ?? null,
        ]);
    }

    public function update(int $userId, string $type, string $publicId, array $data): array
    {
        $table = $this->table($type);
        $this->get($userId, $type, $publicId);
        $allowed = $this->allowedColumns($table, $data);
        unset($allowed['public_id'], $allowed['company_id'], $allowed['company_id'], $allowed['created_at'], $allowed['deleted_at']);
        if (isset($allowed['metadata']) && is_array($allowed['metadata'])) {
            $allowed['metadata'] = json_encode($allowed['metadata']);
        }
        $allowed['updated_at'] = now();
        $this->companies->query($table, $userId)->where('public_id', $publicId)->update($allowed);
        $this->lifecycleEvent($userId, $type, $publicId, 'updated', ['metadata' => ['fields' => array_keys($allowed)]]);
        return $this->get($userId, $type, $publicId);
    }

    public function retire(int $userId, string $type, string $publicId, ?string $date = null, array $metadata = []): array
    {
        $row = $this->update($userId, $type, $publicId, [
            'status' => 'retired',
            'retired_on' => $date ?? now()->toDateString(),
            'metadata' => $metadata,
        ]);
        $this->lifecycleEvent($userId, $type, $publicId, 'retired', ['metadata' => $metadata]);
        return $row;
    }

    public function writeOff(int $userId, string $type, string $publicId, ?string $date = null, ?string $reason = null): array
    {
        $row = $this->update($userId, $type, $publicId, [
            'status' => 'written_off',
            'written_off_on' => $date ?? now()->toDateString(),
            'written_off_reason' => $reason,
            'current_value_minor' => 0,
        ]);
        $this->lifecycleEvent($userId, $type, $publicId, 'written_off', ['metadata' => ['reason' => $reason]]);
        return $row;
    }

    public function sell(int $userId, string $type, string $publicId, ?string $date = null, ?int $valueMinor = null, array $metadata = []): array
    {
        $row = $this->update($userId, $type, $publicId, [
            'status' => 'sold',
            'sold_on' => $date ?? now()->toDateString(),
            'current_value_minor' => $valueMinor,
            'metadata' => $metadata,
        ]);
        $this->lifecycleEvent($userId, $type, $publicId, 'sold', ['value_minor' => $valueMinor, 'metadata' => $metadata]);
        return $row;
    }

    public function delete(int $userId, string $type, string $publicId): void
    {
        $table = $this->table($type);
        $this->get($userId, $type, $publicId);
        $query = $this->companies->query($table, $userId)->where('public_id', $publicId);
        if (Schema::hasColumn($table, 'deleted_at')) {
            $query->update(['deleted_at' => now(), 'updated_at' => now()]);
        } else {
            $query->delete();
        }
        $this->lifecycleEvent($userId, $type, $publicId, 'deleted');
    }

    public function exists(int $userId, string $type, string $subjectPublicId): bool
    {
        $table = $this->table($type);
        return $this->companies->query($table, $userId)
            ->where('public_id', $subjectPublicId)
            ->when(Schema::hasColumn($table, 'deleted_at'), fn ($q) => $q->whereNull('deleted_at'))
            ->exists();
    }

    public function lifecycleEvent(int $userId, string $type, string $subjectPublicId, string $eventType, array $data = []): array
    {
        if (! $this->exists($userId, $type, $subjectPublicId) && $eventType !== 'deleted') {
            throw new InvalidArgumentException('Asset not found.');
        }
        $publicId = (string) Str::ulid();
        $row = $this->companies->stamp('crm_locker_asset_events', $userId, [
            'public_id' => $publicId,
            'subject_type' => $type,
            'subject_public_id' => $subjectPublicId,
            'event_type' => $eventType,
            'occurred_at' => $data['occurred_at'] ?? now(),
            'actor_user_id' => CrmCompanyScope::actorUserId($userId),
            'location_public_id' => $data['location_public_id'] ?? null,
            'value_minor' => $data['value_minor'] ?? null,
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->db->table('crm_locker_asset_events')->insert($row);
        return (array) $this->companies->query('crm_locker_asset_events', $userId)->where('public_id', $publicId)->first();
    }

    private function create(int $userId, string $type, array $source, array $row): array
    {
        $table = $this->table($type);
        $unique = $type === 'vehicle' ? ['registration' => $row['registration']] : ['asset_tag' => $row['asset_tag']];
        $query = $this->companies->query($table, $userId);
        foreach ($unique as $column => $value) {
            $query->where($column, $value);
        }
        if (Schema::hasColumn($table, 'deleted_at')) {
            $query->whereNull('deleted_at');
        }
        if ($query->exists()) {
            throw new InvalidArgumentException('Asset identifier already exists.');
        }

        $publicId = (string) Str::ulid();
        $extra = [
            'description' => $source['description'] ?? null,
            'image_path' => $source['image_path'] ?? null,
            'asset_type_public_id' => $source['asset_type_public_id'] ?? null,
            'category_public_id' => $source['category_public_id'] ?? null,
            'customer_public_id' => $source['customer_public_id'] ?? null,
            'owned_by_user_id' => $source['owned_by_user_id'] ?? null,
            'location_name' => $source['location_name'] ?? null,
            'condition_status' => $source['condition_status'] ?? 'good',
            'qr_token' => $source['qr_token'] ?? ('ASSET-' . $publicId),
            'written_off_on' => $source['written_off_on'] ?? null,
            'written_off_reason' => $source['written_off_reason'] ?? null,
            'name' => $type === 'vehicle'
                ? ($source['name'] ?? trim(($row['make'] ?? '') . ' ' . ($row['model'] ?? '')))
                : ($row['name'] ?? null),
        ];
        $row = array_merge($row, $this->allowedColumns($table, $extra));
        $row += [
            'public_id' => $publicId,
            'metadata' => isset($source['metadata']) ? json_encode($source['metadata']) : null,
            'created_at' => now(),
            'updated_at' => now(),
        ];
        $row = $this->companies->stamp($table, $userId, $row);
        $this->db->table($table)->insert($this->allowedColumns($table, $row));
        $this->lifecycleEvent($userId, $type, $publicId, 'acquired', [
            'value_minor' => $row['acquisition_cost_minor'] ?? null,
            'location_public_id' => $row['location_public_id'] ?? null,
        ]);
        return $this->get($userId, $type, $publicId);
    }

    private function allowedColumns(string $table, array $data): array
    {
        return array_intersect_key($data, array_flip(Schema::getColumnListing($table)));
    }

    public function table(string $type): string
    {
        return match ($type) {
            'tool' => 'crm_locker_tools',
            'equipment' => 'crm_locker_equipment',
            'vehicle' => 'crm_locker_fleet_vehicles',
            default => throw new InvalidArgumentException('Unknown asset type.'),
        };
    }

    private function tag(int $userId, array $data): string
    {
        $value = trim((string) ($data['asset_tag'] ?? ''));
        return $value !== '' ? $value : $this->settings->nextReference($userId, 'asset');
    }

    private function name(array $data): string
    {
        $value = trim((string) ($data['name'] ?? ''));
        if ($value === '') {
            throw new InvalidArgumentException('Asset name is required.');
        }
        return $value;
    }
}
