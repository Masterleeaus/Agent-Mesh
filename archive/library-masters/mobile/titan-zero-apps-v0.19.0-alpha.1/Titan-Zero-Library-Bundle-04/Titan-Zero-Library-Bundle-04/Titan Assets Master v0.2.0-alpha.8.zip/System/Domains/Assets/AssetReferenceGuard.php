<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use App\Extensions\TitanAssets\System\Integrations\Crm\AssetCrmReferenceAuthorityPort;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/** Validates foreign provider/user references inside the active company_id boundary. */
final class AssetReferenceGuard
{
    public function __construct(private ConnectionInterface $db, private AssetCompanyContext $companies, private AssetCrmReferenceAuthorityPort $crm) {}

    public function assertUser(int $actorUserId, ?int $referencedUserId): void
    {
        if ($referencedUserId === null) return;
        $companyId=$this->companies->id($actorUserId);
        if ($referencedUserId < 1 || ! $this->tableHas('users','company_id') || ! $this->db->table('users')->where('id',$referencedUserId)->where('company_id',$companyId)->exists()) {
            throw new InvalidArgumentException('Referenced user does not belong to the active company.');
        }
    }

    public function assertServiceLocation(int $actorUserId, ?string $publicId): void
    {
        $publicId=trim((string)$publicId); if($publicId==='') return;
        $this->crm->assertServiceLocationAccessible($this->companies->id($actorUserId),$actorUserId,$publicId);
    }

    public function assertWorkOrder(int $actorUserId, ?string $publicId): void
    {
        $publicId=trim((string)$publicId); if($publicId==='') return;
        $this->crm->assertWorkOrderAccessible($this->companies->id($actorUserId),$actorUserId,$publicId);
    }

    private function tableHas(string $table,string $column): bool
    {
        try { $schema=$this->db->getSchemaBuilder(); return $schema->hasTable($table)&&$schema->hasColumn($table,$column); }
        catch (\Throwable) { return false; }
    }
}
