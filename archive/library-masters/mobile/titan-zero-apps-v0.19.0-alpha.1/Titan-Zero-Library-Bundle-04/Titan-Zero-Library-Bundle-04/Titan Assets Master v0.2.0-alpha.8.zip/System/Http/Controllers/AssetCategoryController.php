<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetCategoryService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetCategoryController extends Controller
{
    public function __construct(private AssetCategoryService $categories) {}

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:120',
            'code' => 'nullable|string|max:80',
            'parent_public_id' => 'nullable|string|max:26',
            'description' => 'nullable|string|max:2000',
            'active' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
        ]);
        $row = $this->categories->create((int) $request->user()->id, $data);
        return $request->expectsJson() ? response()->json($row, 201) : back()->with('success', 'Asset category created.');
    }

    public function update(Request $request, string $category)
    {
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:120',
            'code' => 'nullable|string|max:80',
            'parent_public_id' => 'nullable|string|max:26',
            'description' => 'nullable|string|max:2000',
            'active' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
        ]);
        $row = $this->categories->update((int) $request->user()->id, $category, $data);
        return $request->expectsJson() ? response()->json($row) : back()->with('success', 'Asset category updated.');
    }

    public function destroy(Request $request, string $category)
    {
        $this->categories->delete((int) $request->user()->id, $category);
        return $request->expectsJson() ? response()->json(['deleted' => true]) : back()->with('success', 'Asset category deleted.');
    }
}
