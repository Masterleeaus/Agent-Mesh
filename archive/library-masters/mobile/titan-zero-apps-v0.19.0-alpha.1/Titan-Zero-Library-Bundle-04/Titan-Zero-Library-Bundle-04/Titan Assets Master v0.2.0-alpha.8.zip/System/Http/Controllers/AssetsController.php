<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetAllocationService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetCategoryService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetHistoryService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetLocationRegisterService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetQueryService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetRegisterService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetSettingsService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetTypeService;
use App\Extensions\TitanAssets\System\Domains\Assets\FleetService;
use App\Extensions\TitanAssets\System\Domains\Assets\EquipmentCheckService;
use App\Extensions\TitanAssets\System\Domains\Assets\MaintenanceService;
use App\Extensions\TitanAssets\System\Domains\Assets\MileageService;
use App\Extensions\TitanAssets\System\Domains\Assets\PremisesLinkService;
use App\Extensions\TitanAssets\System\Domains\Assets\RepairService;
use App\Extensions\TitanAssets\System\Domains\Assets\RepairTemplateService;
use App\Extensions\TitanAssets\System\Domains\Assets\ToolCustodyService;
use App\Extensions\TitanAssets\System\Domains\Assets\WarrantyProfileService;
use App\Extensions\TitanAssets\System\Domains\Assets\WarrantyService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetsController extends Controller
{
    public function __construct(
        private AssetQueryService $query,
        private AssetRegisterService $assets,
        private AssetTypeService $assetTypes,
        private AssetCategoryService $assetCategories,
        private AssetAllocationService $allocations,
        private AssetHistoryService $history,
        private AssetSettingsService $settings,
        private AssetLocationRegisterService $locations,
        private EquipmentCheckService $checks,
        private ToolCustodyService $tools,
        private FleetService $fleet,
        private MaintenanceService $maintenance,
        private RepairService $repairs,
        private RepairTemplateService $repairTemplates,
        private WarrantyService $warranties,
        private WarrantyProfileService $warrantyProfiles,
        private MileageService $mileage,
        private PremisesLinkService $premises,
    ) {}

    public function index(Request $request)
    {
        return view('titan-assets::assets.index', $this->pageData($request, (string) ($request->route('section') ?: 'overview')));
    }

    public function scan(Request $request)
    {
        $data = $this->pageData($request, 'scan');
        $q = trim((string) $request->query('q', ''));
        $data['scanQuery'] = $q;
        $data['scanResult'] = $q !== '' ? $this->query->scan((int) $request->user()->id, $q) : null;
        return view('titan-assets::assets.index', $data);
    }

    public function overview(Request $request)
    {
        return response()->json($this->pageData($request, 'overview'));
    }

    public function createAsset(Request $request, string $type)
    {
        $common = [
            'description' => 'nullable|string|max:5000', 'image_path' => 'nullable|string|max:500',
            'asset_type_public_id' => 'nullable|string|max:26', 'category_public_id' => 'nullable|string|max:26', 'customer_public_id' => 'nullable|string|max:26',
            'owned_by_user_id' => 'nullable|integer|min:1', 'location_name' => 'nullable|string|max:180',
            'condition_status' => 'nullable|string|max:40', 'qr_token' => 'nullable|string|max:120', 'written_off_on' => 'nullable|date', 'written_off_reason' => 'nullable|string|max:5000', 'status' => 'nullable|string|max:40',
            'acquired_on' => 'nullable|date', 'acquisition_cost_minor' => 'nullable|integer|min:0',
            'current_value_minor' => 'nullable|integer|min:0', 'warranty_expires_on' => 'nullable|date',
            'retired_on' => 'nullable|date', 'metadata' => 'nullable|array',
        ];
        $rules = match ($type) {
            'tool' => $common + ['asset_tag' => 'nullable|string|max:100', 'name' => 'required|string|max:180', 'inventory_item_public_id' => 'nullable|string|max:26', 'serial_number' => 'nullable|string|max:160', 'custodian_user_id' => 'nullable|integer|min:1', 'location_public_id' => 'nullable|string|max:26'],
            'equipment' => $common + ['asset_tag' => 'nullable|string|max:100', 'name' => 'required|string|max:180', 'equipment_type' => 'nullable|string|max:100', 'manufacturer' => 'nullable|string|max:120', 'model' => 'nullable|string|max:120', 'serial_number' => 'nullable|string|max:160', 'assigned_user_id' => 'nullable|integer|min:1', 'location_public_id' => 'nullable|string|max:26', 'depreciation_method' => 'nullable|in:none,straight_line', 'useful_life_months' => 'nullable|integer|min:1', 'salvage_value_minor' => 'nullable|integer|min:0', 'next_service_on' => 'nullable|date', 'sold_on' => 'nullable|date'],
            'vehicle' => $common + ['name' => 'nullable|string|max:180', 'registration' => 'required|string|max:40', 'vin' => 'nullable|string|max:80', 'make' => 'nullable|string|max:100', 'model' => 'nullable|string|max:100', 'year' => 'nullable|integer|min:1900|max:2100', 'assigned_user_id' => 'nullable|integer|min:1', 'odometer_km' => 'nullable|integer|min:0', 'depreciation_method' => 'nullable|in:none,straight_line', 'useful_life_months' => 'nullable|integer|min:1', 'salvage_value_minor' => 'nullable|integer|min:0', 'registration_expires_on' => 'nullable|date', 'next_service_on' => 'nullable|date', 'next_service_odometer_km' => 'nullable|integer|min:0', 'sold_on' => 'nullable|date', 'notes' => 'nullable|string|max:5000'],
            default => abort(404),
        };
        $data = $request->validate($rules);
        $row = match ($type) {
            'tool' => $this->assets->createTool((int) $request->user()->id, $data),
            'equipment' => $this->assets->createEquipment((int) $request->user()->id, $data),
            'vehicle' => $this->assets->createVehicle((int) $request->user()->id, $data),
        };
        return $this->respond($request, $row, ucfirst($type) . ' created.');
    }

    public function checkoutTool(Request $request, string $tool)
    {
        $data = $request->validate(['custodian_user_id' => 'required|integer|min:1', 'location_public_id' => 'nullable|string|max:26', 'due_back_at' => 'nullable|date', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->tools->checkout((int) $request->user()->id, $tool, (int) $data['custodian_user_id'], $data), 'Tool checked out.', 200);
    }

    public function returnTool(Request $request, string $tool)
    {
        return $this->respond($request, $this->tools->returnTool((int) $request->user()->id, $tool, $request->validate(['location_public_id' => 'nullable|string|max:26', 'notes' => 'nullable|string|max:2000'])), 'Tool returned.', 200);
    }

    public function damageTool(Request $request, string $tool)
    {
        return $this->respond($request, $this->tools->markDamaged((int) $request->user()->id, $tool, $request->validate(['notes' => 'nullable|string|max:2000'])), 'Tool marked damaged.', 200);
    }

    public function lostTool(Request $request, string $tool)
    {
        return $this->respond($request, $this->tools->markLost((int) $request->user()->id, $tool, $request->validate(['notes' => 'nullable|string|max:2000'])), 'Tool marked lost.', 200);
    }

    public function assignFleet(Request $request, string $vehicle)
    {
        $data = $request->validate(['assigned_user_id' => 'required|integer|min:1']);
        return $this->respond($request, $this->fleet->assign((int) $request->user()->id, $vehicle, (int) $data['assigned_user_id']), 'Vehicle assigned.', 200);
    }

    public function unassignFleet(Request $request, string $vehicle)
    {
        return $this->respond($request, $this->fleet->unassign((int) $request->user()->id, $vehicle), 'Vehicle unassigned.', 200);
    }

    public function updateFleetOdometer(Request $request, string $vehicle)
    {
        $data = $request->validate(['odometer_km' => 'required|integer|min:0', 'occurred_at' => 'nullable|date']);
        return $this->respond($request, $this->fleet->updateOdometer((int) $request->user()->id, $vehicle, (int) $data['odometer_km'], $data), 'Odometer updated.', 200);
    }

    public function updateFleetStatus(Request $request, string $vehicle)
    {
        $data = $request->validate(['status' => 'required|in:active,in_service,out_of_service,retired,sold', 'retired_on' => 'nullable|date', 'sold_on' => 'nullable|date', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->fleet->updateStatus((int) $request->user()->id, $vehicle, $data['status'], $data), 'Vehicle status updated.', 200);
    }

    public function scheduleMaintenance(Request $request, string $type, string $asset)
    {
        $row = $this->maintenance->schedule((int) $request->user()->id, $type, $asset, $request->validate($this->maintenanceRules(true)));
        return $this->respond($request, $row, 'Maintenance scheduled.');
    }

    public function updateMaintenance(Request $request, string $maintenance)
    {
        return $this->respond($request, $this->maintenance->update((int) $request->user()->id, $maintenance, $request->validate($this->maintenanceRules(false))), 'Maintenance updated.', 200);
    }

    public function completeMaintenance(Request $request, string $maintenance)
    {
        $row = $this->maintenance->complete((int) $request->user()->id, $maintenance, $request->validate(['completed_on' => 'nullable|date', 'odometer_km' => 'nullable|integer|min:0', 'cost_minor' => 'nullable|integer|min:0', 'notes' => 'nullable|string|max:5000', 'maintenance_note' => 'nullable|string|max:5000', 'next_due_on' => 'nullable|date', 'next_due_odometer_km' => 'nullable|integer|min:0']));
        return $this->respond($request, $row, 'Maintenance completed.', 200);
    }

    public function cancelMaintenance(Request $request, string $maintenance)
    {
        $data = $request->validate(['reason' => 'nullable|string|max:255']);
        return $this->respond($request, $this->maintenance->cancel((int) $request->user()->id, $maintenance, $data['reason'] ?? null), 'Maintenance cancelled.', 200);
    }

    public function deleteMaintenance(Request $request, string $maintenance)
    {
        $this->maintenance->delete((int) $request->user()->id, $maintenance);
        return $this->deleted($request, 'Maintenance record deleted.');
    }

    public function createRepair(Request $request)
    {
        $data = $request->validate($this->repairRules(true));
        return $this->respond($request, $this->repairs->create((int) $request->user()->id, $data['subject_type'], $data['subject_public_id'], $data), 'Repair opened.');
    }

    public function updateRepair(Request $request, string $repair)
    {
        return $this->respond($request, $this->repairs->update((int) $request->user()->id, $repair, $request->validate($this->repairRules(false))), 'Repair updated.', 200);
    }

    public function setRepairStatus(Request $request, string $repair)
    {
        $data = $request->validate(['status' => 'required|in:open,new,approved,in_progress,awaiting_parts,completed,cancelled', 'completed_at' => 'nullable|date', 'downtime_ended_at' => 'nullable|date', 'actual_cost_minor' => 'nullable|integer|min:0', 'root_cause' => 'nullable|string|max:5000', 'parts_used' => 'nullable|string|max:5000']);
        return $this->respond($request, $this->repairs->setStatus((int) $request->user()->id, $repair, $data['status'], $data), 'Repair updated.', 200);
    }

    public function deleteRepair(Request $request, string $repair)
    {
        $this->repairs->delete((int) $request->user()->id, $repair);
        return $this->deleted($request, 'Repair deleted.');
    }

    public function createRepairTemplate(Request $request)
    {
        return $this->respond($request, $this->repairTemplates->create((int) $request->user()->id, $request->validate($this->repairTemplateRules(true))), 'Repair template created.');
    }

    public function updateRepairTemplate(Request $request, string $template)
    {
        return $this->respond($request, $this->repairTemplates->update((int) $request->user()->id, $template, $request->validate($this->repairTemplateRules(false))), 'Repair template updated.', 200);
    }

    public function deleteRepairTemplate(Request $request, string $template)
    {
        $this->repairTemplates->delete((int) $request->user()->id, $template);
        return $this->deleted($request, 'Repair template deleted.');
    }

    public function createWarranty(Request $request)
    {
        $data = $request->validate($this->warrantyRules(true));
        return $this->respond($request, $this->warranties->create((int) $request->user()->id, $data['subject_type'], $data['subject_public_id'], $data), 'Warranty registered.');
    }

    public function updateWarranty(Request $request, string $warranty)
    {
        return $this->respond($request, $this->warranties->update((int) $request->user()->id, $warranty, $request->validate($this->warrantyRules(false))), 'Warranty updated.', 200);
    }

    public function setWarrantyStatus(Request $request, string $warranty)
    {
        $data = $request->validate(['status' => 'required|in:active,claimed,expired,void']);
        return $this->respond($request, $this->warranties->setStatus((int) $request->user()->id, $warranty, $data['status']), 'Warranty updated.', 200);
    }

    public function deleteWarranty(Request $request, string $warranty)
    {
        $this->warranties->delete((int) $request->user()->id, $warranty);
        return $this->deleted($request, 'Warranty deleted.');
    }

    public function logMileage(Request $request, string $vehicle)
    {
        $data = $request->validate(['odometer_km' => 'required|integer|min:0', 'odometer_start' => 'nullable|integer|min:0', 'odometer_end' => 'nullable|integer|min:0', 'km_driven' => 'nullable|integer|min:0', 'distance_km' => 'nullable|integer|min:0', 'purpose' => 'nullable|string|max:180', 'work_order_public_id' => 'nullable|string|max:26', 'occurred_at' => 'nullable|date', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->mileage->log((int) $request->user()->id, $vehicle, (int) $data['odometer_km'], $data), 'Mileage logged.');
    }

    public function deleteMileage(Request $request, string $mileage)
    {
        $this->mileage->delete((int) $request->user()->id, $mileage);
        return $this->deleted($request, 'Mileage log deleted.');
    }

    public function linkPremises(Request $request)
    {
        $data = $request->validate(['subject_type' => 'required|in:tool,equipment,vehicle', 'subject_public_id' => 'required|string|max:26', 'premise_public_id' => 'required|string|max:26', 'relationship' => 'nullable|string|max:60', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->premises->link((int) $request->user()->id, $data['subject_type'], $data['subject_public_id'], $data['premise_public_id'], $data), 'Premises link saved.');
    }

    public function unlinkPremises(Request $request, string $link)
    {
        $this->premises->unlink((int) $request->user()->id, $link);
        return $this->deleted($request, 'Premises link removed.');
    }

    private function pageData(Request $request, string $section): array
    {
        $userId = (int) $request->user()->id;
        return [
            'activeSection' => $section,
            'metrics' => $this->query->overview($userId),
            'tools' => $this->assets->list($userId, 'tool'),
            'equipment' => $this->assets->list($userId, 'equipment'),
            'vehicles' => $this->assets->list($userId, 'vehicle'),
            'assetTypes' => $this->assetTypes->list($userId),
            'assetCategories' => $this->assetCategories->list($userId),
            'customerAssets' => $this->query->customerAssets($userId),
            'allocations' => $this->allocations->list($userId),
            'lendingHistory' => $this->history->list($userId),
            'maintenance' => $this->maintenance->list($userId),
            'maintenanceDue' => $this->maintenance->due($userId, 30),
            'fleetAlerts' => $this->fleet->alerts($userId, 30),
            'fleetReport' => $this->fleet->report($userId),
            'repairs' => $this->repairs->list($userId),
            'repairTemplates' => $this->repairTemplates->list($userId),
            'downtime' => $this->query->downtime($userId),
            'warranties' => $this->warranties->list($userId),
            'warrantyProfiles' => $this->warrantyProfiles->list($userId),
            'mileageLogs' => $this->mileage->list($userId),
            'locationRegisters' => $this->locations->list($userId),
            'equipmentChecks' => $this->checks->list($userId),
            'premisesLinks' => $this->premises->list($userId),
            'lifecycleReport' => $this->query->lifecycleReport($userId),
            'assetHistory' => $this->query->assetHistory($userId),
            'settings' => $this->settings->get($userId),
            'scanQuery' => '',
            'scanResult' => null,
        ];
    }

    private function maintenanceRules(bool $create): array
    {
        return [
            'scheduled_for' => ($create ? 'required' : 'sometimes') . '|date', 'maintenance_type' => 'nullable|string|max:80',
            'status' => 'nullable|in:scheduled,due,overdue,in_progress,completed,cancelled', 'priority' => 'nullable|in:low,normal,high,urgent', 'assigned_to_user_id' => 'nullable|integer|min:1', 'reference_no' => 'nullable|string|max:120', 'odometer_km' => 'nullable|integer|min:0',
            'cost_minor' => 'nullable|integer|min:0', 'currency' => 'nullable|string|size:3', 'supplier_public_id' => 'nullable|string|max:26',
            'notes' => 'nullable|string|max:5000', 'maintenance_note' => 'nullable|string|max:5000', 'next_due_on' => 'nullable|date', 'next_due_odometer_km' => 'nullable|integer|min:0', 'metadata' => 'nullable|array',
        ];
    }

    private function repairRules(bool $create): array
    {
        return [
            'subject_type' => ($create ? 'required' : 'sometimes') . '|in:tool,equipment,vehicle',
            'subject_public_id' => ($create ? 'required' : 'sometimes') . '|string|max:26',
            'repair_template_public_id' => 'nullable|string|max:26', 'repair_type' => 'nullable|string|max:80',
            'priority' => 'nullable|in:low,normal,high,urgent', 'status' => 'nullable|in:open,new,approved,in_progress,awaiting_parts,completed,cancelled',
            'summary' => ($create ? 'required' : 'sometimes') . '|string|max:255', 'details' => 'nullable|string|max:10000',
            'supplier_public_id' => 'nullable|string|max:26', 'assigned_to_user_id' => 'nullable|integer|min:1',
            'location_public_id' => 'nullable|string|max:26', 'work_order_public_id' => 'nullable|string|max:26',
            'estimated_cost_minor' => 'nullable|integer|min:0', 'actual_cost_minor' => 'nullable|integer|min:0', 'parts_cost_minor' => 'nullable|integer|min:0', 'labour_cost_minor' => 'nullable|integer|min:0', 'repair_count' => 'nullable|integer|min:1', 'currency' => 'nullable|string|size:3',
            'reported_at' => 'nullable|date', 'scheduled_for' => 'nullable|date', 'completed_at' => 'nullable|date',
            'root_cause' => 'nullable|string|max:10000', 'parts_used' => 'nullable|string|max:10000', 'under_warranty' => 'nullable|boolean',
            'downtime_started_at' => 'nullable|date', 'downtime_ended_at' => 'nullable|date', 'metadata' => 'nullable|array',
        ];
    }

    private function repairTemplateRules(bool $create): array
    {
        return [
            'name' => ($create ? 'required' : 'sometimes') . '|string|max:180', 'subject_type' => 'nullable|in:tool,equipment,vehicle',
            'repair_type' => 'nullable|string|max:80', 'default_priority' => 'nullable|in:low,normal,high,urgent',
            'instructions' => 'nullable|string|max:10000', 'estimated_minutes' => 'nullable|integer|min:1',
            'equipment_category' => 'nullable|string|max:120', 'standard_parts' => 'nullable|string|max:10000',
            'estimated_hours' => 'nullable|numeric|min:0', 'active' => 'nullable|boolean', 'metadata' => 'nullable|array',
        ];
    }

    private function warrantyRules(bool $create): array
    {
        return [
            'subject_type' => ($create ? 'required' : 'sometimes') . '|in:tool,equipment,vehicle',
            'subject_public_id' => ($create ? 'required' : 'sometimes') . '|string|max:26',
            'profile_public_id' => 'nullable|string|max:26', 'provider_name' => 'nullable|string|max:180',
            'supplier_name' => 'nullable|string|max:180', 'policy_number' => 'nullable|string|max:160',
            'warranty_number' => 'nullable|string|max:160', 'starts_on' => 'nullable|date', 'expires_on' => 'nullable|date',
            'status' => 'nullable|in:active,claimed,expired,void', 'coverage_notes' => 'nullable|string|max:10000',
            'claim_reference' => 'nullable|string|max:160', 'claimed_at' => 'nullable|date', 'additional_cost_minor' => 'nullable|integer|min:0', 'metadata' => 'nullable|array',
        ];
    }

    private function respond(Request $request, array $row, string $message, int $status = 201)
    {
        return $request->expectsJson() ? response()->json($row, $status) : back()->with('success', $message);
    }

    private function deleted(Request $request, string $message)
    {
        return $request->expectsJson() ? response()->json(['deleted' => true]) : back()->with('success', $message);
    }
}
