<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WarrantyProfileService
{
    private const TYPES=['day','week','month','year'];
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies){}
    public function list(int$userId):array{return$this->companies->query('titan_asset_warranty_profiles',$userId)->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();}
    public function get(int$userId,string$id):array{$r=$this->companies->query('titan_asset_warranty_profiles',$userId)->where('public_id',$id)->first();if(!$r)throw new InvalidArgumentException('Warranty profile not found.');return(array)$r;}
    public function create(int$userId,array$data):array{$name=trim((string)($data['name']??''));$type=(string)($data['warranty_type']??'month');$duration=(int)($data['warranty_duration']??0);if($name===''||$duration<=0||!in_array($type,self::TYPES,true))throw new InvalidArgumentException('Invalid warranty profile.');$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_warranty_profiles',$userId,['public_id'=>$id,'name'=>$name,'equipment_category'=>$data['equipment_category']??null,'warranty_duration'=>$duration,'warranty_type'=>$type,'notes'=>$data['notes']??null,'active'=>(bool)($data['active']??true),'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_warranty_profiles')->insert($row);return$this->get($userId,$id);}
    public function update(int$userId,string$id,array$data):array{$this->get($userId,$id);$row=array_intersect_key($data,array_flip(['name','equipment_category','warranty_duration','warranty_type','notes','active']));if(isset($row['warranty_type'])&&!in_array($row['warranty_type'],self::TYPES,true))throw new InvalidArgumentException('Invalid warranty type.');$row['updated_at']=now();$this->companies->query('titan_asset_warranty_profiles',$userId)->where('public_id',$id)->update($row);return$this->get($userId,$id);}
    public function delete(int$userId,string$id):void{$this->get($userId,$id);$this->companies->query('titan_asset_warranty_profiles',$userId)->where('public_id',$id)->delete();}
    public function compute(int$userId,string$id,string$startDate):string{$p=$this->get($userId,$id);$date=CarbonImmutable::parse($startDate);return match($p['warranty_type']){'week'=>$date->addWeeks((int)$p['warranty_duration'])->toDateString(),'month'=>$date->addMonths((int)$p['warranty_duration'])->toDateString(),'year'=>$date->addYears((int)$p['warranty_duration'])->toDateString(),default=>$date->addDays((int)$p['warranty_duration'])->toDateString()};}
}
