<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

final class AssetMediaService
{
    public function __construct(private AssetCompanyContext $companies, private AssetRegisterService $assets) {}

    public function uploadImage(int $userId, string $type, string $asset, UploadedFile $file): array
    {
        $row = $this->assets->get($userId, $type, $asset);
        $previous = (string) ($row['image_path'] ?? '');
        $companyId = $this->companies->id($userId);
        $path = $file->store("titan-assets/{$companyId}/{$type}/{$asset}/images", 'local');
        if ($previous !== '') {
            Storage::disk('local')->delete($previous);
        }
        $updated = $this->assets->update($userId, $type, $asset, ['image_path' => $path]);
        $this->assets->lifecycleEvent($userId, $type, $asset, 'image_updated', ['metadata' => ['image_path' => $path]]);
        return $updated;
    }

    public function deleteImage(int $userId, string $type, string $asset): array
    {
        $row = $this->assets->get($userId, $type, $asset);
        $path = (string) ($row['image_path'] ?? '');
        if ($path !== '') {
            Storage::disk('local')->delete($path);
        }
        $updated = $this->assets->update($userId, $type, $asset, ['image_path' => null]);
        $this->assets->lifecycleEvent($userId, $type, $asset, 'image_removed');
        return $updated;
    }
}
