<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AssetDocumentService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private AssetRegisterService $assets){}
    public function list(int$userId,string$type,string$asset):array{return$this->companies->query('titan_asset_documents',$userId)->where('subject_type',$type)->where('subject_public_id',$asset)->orderByDesc('created_at')->get()->map(fn($r)=>(array)$r)->all();}
    public function upload(int$userId,string$type,string$asset,UploadedFile$file,array$data=[]):array{if(!$this->assets->exists($userId,$type,$asset))throw new InvalidArgumentException('Asset not found.');$company=$this->companies->id($userId);$path=$file->store("titan-assets/{$company}/{$type}/{$asset}",'local');$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_documents',$userId,['public_id'=>$id,'subject_type'=>$type,'subject_public_id'=>$asset,'document_type'=>$data['document_type']??'file','name'=>$data['name']??$file->getClientOriginalName(),'storage_disk'=>'local','storage_path'=>$path,'mime_type'=>$file->getMimeType(),'size_bytes'=>$file->getSize(),'uploaded_by_user_id'=>$userId,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_documents')->insert($row);$this->assets->lifecycleEvent($userId,$type,$asset,'document_uploaded',['metadata'=>['document_public_id'=>$id,'name'=>$row['name']]]);return(array)$this->companies->query('titan_asset_documents',$userId)->where('public_id',$id)->first();}
    public function delete(int$userId,string$id):void{$row=$this->companies->query('titan_asset_documents',$userId)->where('public_id',$id)->first();if(!$row)throw new InvalidArgumentException('Document not found.');Storage::disk($row->storage_disk?:'local')->delete($row->storage_path);$this->companies->query('titan_asset_documents',$userId)->where('public_id',$id)->delete();}
}
