<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetQueryService;
use App\Extensions\TitanAssets\System\Domains\Assets\FleetService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

final class AssetReportsController extends Controller
{
    public function __construct(private AssetQueryService $query, private FleetService $fleet) {}

    public function report(Request $request)
    {
        $userId = (int) $request->user()->id;
        return response()->json([
            'overview' => $this->query->overview($userId),
            'lifecycle' => $this->query->lifecycleReport($userId),
            'downtime' => $this->query->downtime($userId),
            'history' => $this->query->assetHistory($userId),
            'fleet' => $this->fleet->report($userId),
        ]);
    }
}
