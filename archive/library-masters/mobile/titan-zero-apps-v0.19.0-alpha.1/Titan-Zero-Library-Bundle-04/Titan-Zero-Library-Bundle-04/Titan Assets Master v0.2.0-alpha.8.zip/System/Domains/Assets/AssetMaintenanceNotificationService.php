<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

final class AssetMaintenanceNotificationService
{
    public function __construct(
        private ConnectionInterface $db,
        private AssetCompanyContext $companies,
        private AssetSettingsService $settings,
        private CrmCompanyContextResolver $crmCompanies,
    ) {}

    public function sentForMaintenance(int $userId, array $maintenance, array $asset): void
    {
        $settings = $this->settings->get($userId);
        if (! (bool) ($settings['notify_sent_for_maintenance'] ?? false)) {
            return;
        }
        $recipientIds = array_values(array_unique(array_filter(array_map('intval', (array) ($settings['maintenance_recipient_user_ids'] ?? [])))));
        $this->deliver(
            $userId,
            'send_for_maintenance',
            $recipientIds,
            (string) ($settings['send_for_maintenance_subject'] ?? 'Asset {asset_code} sent for maintenance'),
            (string) ($settings['send_for_maintenance_body'] ?? 'Asset {asset_code} has been sent for maintenance. Maintenance reference: {maintenance_id}. Status: {status}. Priority: {priority}. Details: {details}.'),
            $maintenance,
            $asset,
        );
    }

    public function assignedForMaintenance(int $userId, array $maintenance, array $asset): void
    {
        $settings = $this->settings->get($userId);
        if (! (bool) ($settings['notify_assigned_for_maintenance'] ?? false)) {
            return;
        }
        $recipientIds = [];
        $assigned = (int) ($maintenance['assigned_to_user_id'] ?? 0);
        if ($assigned > 0) {
            $recipientIds[] = $assigned;
        }
        $recipientIds = array_values(array_unique(array_merge(
            $recipientIds,
            array_filter(array_map('intval', (array) ($settings['maintenance_recipient_user_ids'] ?? [])))
        )));
        $this->deliver(
            $userId,
            'assigned_for_maintenance',
            $recipientIds,
            (string) ($settings['assigned_for_maintenance_subject'] ?? 'Asset {asset_code} assigned for maintenance'),
            (string) ($settings['assigned_for_maintenance_body'] ?? 'Asset {asset_code} has been assigned for maintenance. Maintenance reference: {maintenance_id}. Status: {status}. Priority: {priority}. Details: {details}.'),
            $maintenance,
            $asset,
        );
    }

    private function deliver(int $userId, string $event, array $recipientIds, string $subject, string $body, array $maintenance, array $asset): void
    {
        if ($recipientIds === []) {
            return;
        }
        $companyId = $this->companies->id($userId);
        $model = config('auth.providers.users.model');
        if (! is_string($model) || ! class_exists($model)) {
            return;
        }

        $tokens = [
            '{asset_code}' => (string) ($asset['asset_tag'] ?? $asset['registration'] ?? $asset['public_id'] ?? ''),
            '{asset_name}' => (string) ($asset['name'] ?? trim(($asset['make'] ?? '') . ' ' . ($asset['model'] ?? ''))),
            '{maintenance_id}' => (string) ($maintenance['reference_no'] ?? $maintenance['public_id'] ?? ''),
            '{status}' => (string) ($maintenance['status'] ?? ''),
            '{priority}' => (string) ($maintenance['priority'] ?? 'normal'),
            '{details}' => (string) ($maintenance['notes'] ?? ''),
        ];
        $subject = strtr($subject, $tokens);
        $body = strtr($body, $tokens);

        foreach ($recipientIds as $recipientId) {
            if ($recipientId <= 0 || ! $this->crmCompanies->actorBelongsToCompany($recipientId, $companyId)) {
                continue;
            }
            $user = $model::query()->find($recipientId);
            $email = is_object($user) ? trim((string) ($user->email ?? '')) : '';
            if ($email === '') {
                continue;
            }

            $logId = (string) Str::ulid();
            $log = $this->companies->stamp('titan_asset_notifications', $userId, [
                'public_id' => $logId,
                'event_type' => $event,
                'subject_type' => (string) ($maintenance['subject_type'] ?? ''),
                'subject_public_id' => (string) ($maintenance['subject_public_id'] ?? ''),
                'maintenance_public_id' => (string) ($maintenance['public_id'] ?? ''),
                'recipient_user_id' => $recipientId,
                'channel' => 'email',
                'recipient' => $email,
                'status' => 'pending',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->db->table('titan_asset_notifications')->insert($log);

            try {
                Mail::html(nl2br(e($body)), static function ($message) use ($email, $subject): void {
                    $message->to($email)->subject($subject);
                });
                $this->companies->query('titan_asset_notifications', $userId)->where('public_id', $logId)->update([
                    'status' => 'sent', 'sent_at' => now(), 'updated_at' => now(),
                ]);
            } catch (\Throwable $e) {
                $this->companies->query('titan_asset_notifications', $userId)->where('public_id', $logId)->update([
                    'status' => 'failed', 'error_message' => mb_substr($e->getMessage(), 0, 1000), 'updated_at' => now(),
                ]);
                Log::warning('Titan Assets maintenance notification failed', [
                    'event' => $event,
                    'maintenance_public_id' => $maintenance['public_id'] ?? null,
                    'recipient_user_id' => $recipientId,
                    'error' => $e->getMessage(),
                ]);
            }
        }
    }
}
