<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Integrations\Crm;

use RuntimeException;

/** Provider boundary adapter: CRM references are authorised through governed CRM reads, not CRM tables/models. */
final class CrmAssetReferenceAuthorityAdapter implements AssetCrmReferenceAuthorityPort
{
    private const EXECUTOR='App\\Extensions\\Crm\\System\\Capabilities\\CrmCapabilityExecutor';

    public function assertWorkOrderAccessible(int $companyId,int $actorUserId,string $publicId): void
    {
        $this->assertCanonical($companyId,$actorUserId,'crm.work_order.read',$publicId);
    }

    public function assertServiceLocationAccessible(int $companyId,int $actorUserId,string $publicId): void
    {
        $this->assertCanonical($companyId,$actorUserId,'crm.location.read',$publicId);
    }

    private function assertCanonical(int $companyId,int $actorUserId,string $capability,string $publicId): void
    {
        if($companyId<1||$actorUserId<1||trim($publicId)==='')throw new RuntimeException('Canonical company, actor and CRM public reference are required.');
        if(!class_exists(self::EXECUTOR)||!app()->bound(self::EXECUTOR))throw new RuntimeException('CRM reference authority is unavailable.');
        $result=app(self::EXECUTOR)->execute($capability,['public_id'=>$publicId]);
        if((int)($result['company_id']??0)!==$companyId||($result['status']??null)!=='ok')throw new RuntimeException('CRM reference is not authorised inside the active company_id.');
    }
}
