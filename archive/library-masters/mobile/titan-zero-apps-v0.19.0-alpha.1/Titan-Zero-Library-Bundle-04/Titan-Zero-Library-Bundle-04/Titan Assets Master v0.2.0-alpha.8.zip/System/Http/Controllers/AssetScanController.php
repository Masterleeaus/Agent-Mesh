<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Http\Controllers;

use App\Extensions\TitanAssets\System\Domains\Assets\AssetAllocationService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetHistoryService;
use App\Extensions\TitanAssets\System\Domains\Assets\AssetRegisterService;
use App\Extensions\TitanAssets\System\Domains\Assets\MaintenanceService;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class AssetScanController extends Controller
{
    public function __construct(
        private AssetHistoryService $history,
        private AssetAllocationService $allocations,
        private AssetRegisterService $assets,
        private MaintenanceService $maintenance,
    ) {}

    public function issue(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'borrower_user_id' => 'required|integer|min:1',
            'due_at' => 'nullable|date',
            'notes' => 'nullable|string|max:2000',
        ]);
        return $this->respond($request, $this->history->issue((int) $request->user()->id, $type, $asset, $data), 'Asset issued.');
    }

    public function returnAsset(Request $request, string $type, string $asset)
    {
        $userId = (int) $request->user()->id;
        $open = array_values(array_filter(
            $this->history->list($userId, $type, $asset),
            static fn(array $row): bool => empty($row['returned_at'])
        ));
        if ($open === []) {
            throw new InvalidArgumentException('No open lending record exists for this asset.');
        }
        $data = $request->validate(['returned_at' => 'nullable|date', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->history->returnAsset($userId, (string) $open[0]['public_id'], $data), 'Asset returned.', 200);
    }

    public function report(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'condition' => 'required|in:damaged,lost,out_of_service,needs_attention',
            'notes' => 'nullable|string|max:2000',
        ]);
        $status = match ($data['condition']) {
            'out_of_service' => 'out_of_service',
            'lost' => 'lost',
            default => 'damaged',
        };
        $row = $this->assets->update((int) $request->user()->id, $type, $asset, [
            'condition_status' => $data['condition'],
            'status' => $status,
        ]);
        $this->assets->lifecycleEvent((int) $request->user()->id, $type, $asset, 'condition_reported', ['metadata' => $data]);
        return $this->respond($request, $row, 'Asset condition reported.', 200);
    }

    public function maintenance(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'scheduled_for' => 'required|date',
            'maintenance_type' => 'nullable|string|max:80',
            'priority' => 'nullable|in:low,normal,high,urgent',
            'notes' => 'nullable|string|max:2000',
        ]);
        return $this->respond($request, $this->maintenance->schedule((int) $request->user()->id, $type, $asset, $data), 'Asset sent to maintenance.');
    }

    public function completeMaintenance(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'completed_on' => 'nullable|date',
            'odometer_km' => 'nullable|integer|min:0',
            'cost_minor' => 'nullable|integer|min:0',
            'next_due_on' => 'nullable|date',
            'next_due_odometer_km' => 'nullable|integer|min:0',
            'maintenance_note' => 'nullable|string|max:5000',
            'notes' => 'nullable|string|max:5000',
        ]);
        return $this->respond($request, $this->maintenance->completeForAsset((int) $request->user()->id, $type, $asset, $data), 'Maintenance completed.', 200);
    }

    public function allocate(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'receiver_user_id' => 'nullable|integer|min:1',
            'quantity' => 'nullable|integer|min:1',
            'allocated_at' => 'nullable|date',
            'allocated_upto' => 'nullable|date',
            'reason' => 'nullable|string|max:2000',
        ]);
        return $this->respond($request, $this->allocations->create((int) $request->user()->id, $type, $asset, $data), 'Asset allocated.');
    }

    public function revoke(Request $request, string $type, string $asset)
    {
        $data = $request->validate([
            'allocation_public_id' => 'nullable|string|max:26',
            'quantity' => 'nullable|integer|min:1',
            'reason' => 'nullable|string|max:2000',
        ]);
        $userId = (int) $request->user()->id;
        $id = (string) ($data['allocation_public_id'] ?? '');
        if ($id === '') {
            foreach ($this->allocations->list($userId) as $allocation) {
                if (($allocation['subject_type'] ?? null) === $type && ($allocation['subject_public_id'] ?? null) === $asset && in_array(($allocation['status'] ?? ''), ['active', 'partially_revoked'], true)) {
                    $id = (string) $allocation['public_id'];
                    break;
                }
            }
        }
        if ($id === '') {
            throw new InvalidArgumentException('No active allocation exists for this asset.');
        }
        return $this->respond($request, $this->allocations->revoke($userId, $id, $data), 'Allocation revoked.', 200);
    }

    private function respond(Request $request, array $row, string $message, int $status = 201)
    {
        return $request->expectsJson() ? response()->json($row, $status) : back()->with('success', $message);
    }
}
