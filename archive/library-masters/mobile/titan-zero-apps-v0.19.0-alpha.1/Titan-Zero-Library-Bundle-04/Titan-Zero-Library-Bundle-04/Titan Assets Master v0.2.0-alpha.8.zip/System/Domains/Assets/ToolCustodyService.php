<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use InvalidArgumentException;

final class ToolCustodyService
{
    public function __construct(private AssetCompanyContext $companies,private AssetRegisterService $assets,private AssetHistoryService $history){}
    public function checkout(int$userId,string$id,int$custodian,array$data=[]):array{$this->assets->get($userId,'tool',$id);$this->history->issue($userId,'tool',$id,['borrower_user_id'=>$custodian,'due_at'=>$data['due_back_at']??null,'notes'=>$data['notes']??null]);return$this->assets->get($userId,'tool',$id);}
    public function returnTool(int$userId,string$id,array$data=[]):array{$open=array_values(array_filter($this->history->list($userId,'tool',$id),fn($r)=>empty($r['returned_at'])));if($open)$this->history->returnAsset($userId,$open[0]['public_id'],['notes'=>$data['notes']??null]);else$this->assets->update($userId,'tool',$id,['custodian_user_id'=>null,'status'=>'available','location_public_id'=>$data['location_public_id']??null]);return$this->assets->get($userId,'tool',$id);}
    public function markDamaged(int$userId,string$id,array$data=[]):array{return$this->mark($userId,$id,'damaged',$data);}
    public function markLost(int$userId,string$id,array$data=[]):array{return$this->mark($userId,$id,'lost',$data);}
    private function mark(int$userId,string$id,string$status,array$data):array{$this->assets->get($userId,'tool',$id);$row=$this->assets->update($userId,'tool',$id,['status'=>$status,'condition_status'=>$status]);$this->assets->lifecycleEvent($userId,'tool',$id,$status,['metadata'=>$data]);return$row;}
}
