<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class MaintenanceService
{
    public function __construct(
        private ConnectionInterface $db,
        private AssetCompanyContext $companies,
        private AssetRegisterService $assets,
        private AssetSettingsService $settings,
        private AssetMaintenanceNotificationService $notifications,
    ) {}

    public function list(int $userId): array
    {
        return $this->companies->query('crm_locker_maintenance_records', $userId)
            ->orderByDesc('scheduled_for')
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }

    public function get(int $userId, string $publicId): array
    {
        $row = $this->companies->query('crm_locker_maintenance_records', $userId)->where('public_id', $publicId)->first();
        if (! $row) {
            throw new InvalidArgumentException('Maintenance record not found.');
        }
        return (array) $row;
    }

    public function upcoming(int $userId, int $days = 30): array
    {
        return $this->due($userId, $days);
    }

    public function due(int $userId, int $days = 30): array
    {
        $today = now()->toDateString();
        $until = now()->addDays(max(1, $days))->toDateString();
        return $this->companies->query('crm_locker_maintenance_records', $userId)
            ->whereIn('status', ['scheduled', 'due', 'overdue', 'in_progress'])
            ->whereNotNull('scheduled_for')
            ->where('scheduled_for', '<=', $until)
            ->orderBy('scheduled_for')
            ->get()
            ->map(function ($row) use ($today): array {
                $data = (array) $row;
                $data['overdue'] = (string) ($row->scheduled_for ?? '') < $today && ! in_array((string) ($row->status ?? ''), ['completed', 'cancelled'], true);
                return $data;
            })
            ->all();
    }

    public function schedule(int $userId, string $type, string $asset, array $data): array
    {
        $scheduled = $data['scheduled_for'] ?? null;
        if (! $scheduled) {
            throw new InvalidArgumentException('Maintenance scheduled date is required.');
        }
        $assetRow = $this->assets->get($userId, $type, $asset);
        $publicId = (string) Str::ulid();
        $row = $this->companies->stamp('crm_locker_maintenance_records', $userId, [
            'public_id' => $publicId,
            'reference_no' => $data['reference_no'] ?? $this->settings->nextReference($userId, 'maintenance'),
            'subject_type' => $type,
            'subject_public_id' => $asset,
            'maintenance_type' => $data['maintenance_type'] ?? 'service',
            'status' => $data['status'] ?? 'scheduled',
            'priority' => $data['priority'] ?? 'normal',
            'assigned_to_user_id' => $data['assigned_to_user_id'] ?? null,
            'scheduled_for' => $scheduled,
            'completed_on' => $data['completed_on'] ?? null,
            'odometer_km' => $data['odometer_km'] ?? null,
            'cost_minor' => $data['cost_minor'] ?? null,
            'currency' => strtoupper((string) ($data['currency'] ?? 'AUD')),
            'supplier_public_id' => $data['supplier_public_id'] ?? null,
            'notes' => $data['notes'] ?? $data['details'] ?? null,
            'maintenance_note' => $data['maintenance_note'] ?? null,
            'next_due_on' => $data['next_due_on'] ?? null,
            'next_due_odometer_km' => $data['next_due_odometer_km'] ?? null,
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null,
            'created_by_user_id' => $userId,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->db->table('crm_locker_maintenance_records')->insert($row);
        $this->assets->update($userId, $type, $asset, ['status' => 'under-maintenance']);
        $this->assets->lifecycleEvent($userId, $type, $asset, 'maintenance_scheduled', [
            'metadata' => [
                'maintenance_public_id' => $publicId,
                'reference_no' => $row['reference_no'] ?? null,
                'priority' => $row['priority'] ?? null,
                'assigned_to_user_id' => $row['assigned_to_user_id'] ?? null,
            ],
        ]);
        $created = $this->get($userId, $publicId);
        $this->notifications->sentForMaintenance($userId, $created, $assetRow);
        if (! empty($created['assigned_to_user_id'])) {
            $this->notifications->assignedForMaintenance($userId, $created, $assetRow);
        }
        return $created;
    }

    public function update(int $userId, string $publicId, array $data): array
    {
        $before = $this->get($userId, $publicId);
        $allowed = array_intersect_key($data, array_flip([
            'reference_no', 'maintenance_type', 'status', 'priority', 'assigned_to_user_id', 'scheduled_for',
            'completed_on', 'odometer_km', 'cost_minor', 'currency', 'supplier_public_id', 'notes',
            'maintenance_note', 'next_due_on', 'next_due_odometer_km', 'metadata',
        ]));
        if (isset($allowed['priority']) && ! in_array((string) $allowed['priority'], ['low', 'normal', 'high', 'urgent'], true)) {
            throw new InvalidArgumentException('Invalid maintenance priority.');
        }
        if (isset($allowed['metadata']) && is_array($allowed['metadata'])) {
            $allowed['metadata'] = json_encode($allowed['metadata']);
        }
        $allowed['updated_at'] = now();
        $this->companies->query('crm_locker_maintenance_records', $userId)->where('public_id', $publicId)->update($allowed);
        $updated = $this->get($userId, $publicId);
        if (($before['assigned_to_user_id'] ?? null) !== ($updated['assigned_to_user_id'] ?? null) && ! empty($updated['assigned_to_user_id'])) {
            $assetRow = $this->assets->get($userId, (string) $updated['subject_type'], (string) $updated['subject_public_id']);
            $this->notifications->assignedForMaintenance($userId, $updated, $assetRow);
        }
        return $updated;
    }

    public function complete(int $userId, string $publicId, array $data = []): array
    {
        $record = $this->get($userId, $publicId);
        if (($record['status'] ?? null) === 'cancelled') {
            throw new InvalidArgumentException('Cancelled maintenance cannot be completed.');
        }
        $row = $this->update($userId, $publicId, [
            'status' => 'completed',
            'completed_on' => $data['completed_on'] ?? now()->toDateString(),
            'cost_minor' => $data['cost_minor'] ?? $record['cost_minor'],
            'odometer_km' => $data['odometer_km'] ?? $record['odometer_km'],
            'next_due_on' => $data['next_due_on'] ?? $record['next_due_on'],
            'next_due_odometer_km' => $data['next_due_odometer_km'] ?? $record['next_due_odometer_km'],
            'notes' => $data['notes'] ?? $record['notes'],
            'maintenance_note' => $data['maintenance_note'] ?? $record['maintenance_note'] ?? null,
        ]);
        $this->assets->update($userId, (string) $record['subject_type'], (string) $record['subject_public_id'], [
            'status' => 'available',
            'next_service_on' => $row['next_due_on'] ?? null,
            'next_service_odometer_km' => $row['next_due_odometer_km'] ?? null,
            'odometer_km' => $row['odometer_km'] ?? null,
            'last_service_date' => $row['completed_on'] ?? null,
        ]);
        $this->assets->lifecycleEvent($userId, (string) $record['subject_type'], (string) $record['subject_public_id'], 'maintenance_completed', [
            'value_minor' => $row['cost_minor'] ?? null,
            'metadata' => ['maintenance_public_id' => $publicId, 'reference_no' => $row['reference_no'] ?? null],
        ]);
        return $row;
    }

    public function completeForAsset(int $userId, string $type, string $asset, array $data = []): array
    {
        $row = $this->companies->query('crm_locker_maintenance_records', $userId)
            ->where('subject_type', $type)
            ->where('subject_public_id', $asset)
            ->whereNotIn('status', ['completed', 'cancelled'])
            ->orderByDesc('created_at')
            ->first();
        if (! $row) {
            throw new InvalidArgumentException('No open maintenance record exists for this asset.');
        }
        return $this->complete($userId, (string) $row->public_id, $data);
    }

    public function cancel(int $userId, string $publicId, ?string $reason = null): array
    {
        $record = $this->get($userId, $publicId);
        if (($record['status'] ?? null) === 'completed') {
            throw new InvalidArgumentException('Completed maintenance cannot be cancelled.');
        }
        $this->companies->query('crm_locker_maintenance_records', $userId)->where('public_id', $publicId)->update([
            'status' => 'cancelled',
            'cancelled_at' => now(),
            'cancel_reason' => $reason,
            'updated_at' => now(),
        ]);
        $this->assets->lifecycleEvent($userId, (string) $record['subject_type'], (string) $record['subject_public_id'], 'maintenance_cancelled', [
            'metadata' => ['maintenance_public_id' => $publicId, 'reason' => $reason],
        ]);
        return $this->get($userId, $publicId);
    }

    public function delete(int $userId, string $publicId): void
    {
        $record = $this->get($userId, $publicId);
        $this->companies->query('crm_locker_maintenance_records', $userId)->where('public_id', $publicId)->delete();
        $stillOpen = $this->companies->query('crm_locker_maintenance_records', $userId)
            ->where('subject_type', $record['subject_type'])
            ->where('subject_public_id', $record['subject_public_id'])
            ->whereNotIn('status', ['completed', 'cancelled'])
            ->exists();
        if (! $stillOpen) {
            $this->assets->update($userId, (string) $record['subject_type'], (string) $record['subject_public_id'], ['status' => 'available']);
        }
        $this->assets->lifecycleEvent($userId, (string) $record['subject_type'], (string) $record['subject_public_id'], 'maintenance_deleted', [
            'metadata' => ['maintenance_public_id' => $publicId],
        ]);
    }
}
