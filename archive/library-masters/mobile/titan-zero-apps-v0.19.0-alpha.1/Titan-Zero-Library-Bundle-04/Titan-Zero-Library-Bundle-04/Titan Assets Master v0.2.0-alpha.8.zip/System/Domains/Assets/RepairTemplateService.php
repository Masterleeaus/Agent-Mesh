<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RepairTemplateService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies){}
    public function list(int$userId,bool$activeOnly=false):array{$q=$this->companies->query('titan_asset_repair_templates',$userId);if($activeOnly)$q->where('active',true);return$q->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();}
    public function get(int$userId,string$id):array{$r=$this->companies->query('titan_asset_repair_templates',$userId)->where('public_id',$id)->first();if(!$r)throw new InvalidArgumentException('Repair template not found.');return(array)$r;}
    public function create(int$userId,array$data):array{$name=trim((string)($data['name']??''));if($name==='')throw new InvalidArgumentException('Repair template name is required.');$id=(string)Str::ulid();$hours=$data['estimated_hours']??(isset($data['estimated_minutes'])?round(((int)$data['estimated_minutes'])/60,2):null);$row=$this->companies->stamp('titan_asset_repair_templates',$userId,['public_id'=>$id,'name'=>$name,'subject_type'=>$data['subject_type']??null,'repair_type'=>$data['repair_type']??'repair','default_priority'=>$data['default_priority']??'normal','instructions'=>$data['instructions']??$data['description']??null,'estimated_minutes'=>$data['estimated_minutes']??($hours!==null?(int)round($hours*60):null),'equipment_category'=>$data['equipment_category']??null,'standard_parts'=>$data['standard_parts']??null,'estimated_hours'=>$hours,'active'=>(bool)($data['active']??true),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_by_user_id'=>$userId,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_repair_templates')->insert($row);return$this->get($userId,$id);}
    public function update(int$userId,string$id,array$data):array{$this->get($userId,$id);$allowed=array_intersect_key($data,array_flip(['name','subject_type','repair_type','default_priority','instructions','estimated_minutes','equipment_category','standard_parts','estimated_hours','active','metadata']));if(isset($allowed['metadata'])&&is_array($allowed['metadata']))$allowed['metadata']=json_encode($allowed['metadata']);if(isset($allowed['estimated_hours'])&&!isset($allowed['estimated_minutes']))$allowed['estimated_minutes']=(int)round(((float)$allowed['estimated_hours'])*60);$allowed['updated_at']=now();$this->companies->query('titan_asset_repair_templates',$userId)->where('public_id',$id)->update($allowed);return$this->get($userId,$id);}
    public function delete(int$userId,string$id):void{$this->get($userId,$id);$this->companies->query('titan_asset_repair_templates',$userId)->where('public_id',$id)->delete();}
}
