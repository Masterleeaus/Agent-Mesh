<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanAssets\System\Navigation\AssetMenuSelfHealer;
use App\Extensions\TitanAssets\System\Integrations\Crm\{AssetCrmReferenceAuthorityPort,CrmAssetReferenceAuthorityAdapter};
use Illuminate\Support\ServiceProvider;

final class TitanAssetsServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanAssets\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanAssets\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

        $this->mergeConfigFrom(__DIR__ . '/../config/navigation.php', 'titan-assets-navigation');
        $this->app->singleton(AssetCrmReferenceAuthorityPort::class, CrmAssetReferenceAuthorityAdapter::class);

        foreach ([
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetCompanyContext::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetReferenceGuard::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetRegisterService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetCrudService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetTypeService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetCategoryService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetSettingsService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetMaintenanceNotificationService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetAllocationService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetHistoryService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetValuationService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetLocationRegisterService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\EquipmentCheckService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetDocumentService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetMediaService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\ToolCustodyService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\FleetService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\MaintenanceService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\AssetQueryService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\WarrantyProfileService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\WarrantyService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\RepairTemplateService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\RepairService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\MileageService::class,
            \App\Extensions\TitanAssets\System\Domains\Assets\PremisesLinkService::class,
            AssetMenuSelfHealer::class,
        ] as $service) {
            $this->app->singleton($service);
        }
    }

    public function boot(AssetMenuSelfHealer $menu): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-assets');
        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        if (is_file(__DIR__ . '/../routes/api.php')) {
            $this->loadRoutesFrom(__DIR__ . '/../routes/api.php');
        }
        $menu->heal();
    }

    public function registerKey(): string
    {
        return 'titan-assets';
    }

    public static function uninstall(): void
    {
        // Preserve asset, custody, lifecycle, warranty and maintenance history.
    }
}
