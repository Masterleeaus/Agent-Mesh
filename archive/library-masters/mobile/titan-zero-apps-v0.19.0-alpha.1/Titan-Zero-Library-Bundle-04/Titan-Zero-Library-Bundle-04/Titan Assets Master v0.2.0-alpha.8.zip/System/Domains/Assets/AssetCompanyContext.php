<?php

declare(strict_types=1);

namespace App\Extensions\TitanAssets\System\Domains\Assets;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\Schema;
use RuntimeException;

final class AssetCompanyContext
{
    public function __construct(private ConnectionInterface $db) {}

    public function id(int $userId): int
    {
        $id = (int) CrmCompanyScope::companyId($userId);
        if ($id <= 0) throw new RuntimeException('Titan Assets company context is unavailable.');
        return $id;
    }

    public function column(string $table): string
    {
        if (Schema::hasColumn($table, 'company_id')) return 'company_id';
        throw new RuntimeException("{$table} has no company boundary column.");
    }

    public function query(string $table, int $userId): Builder
    {
        return $this->db->table($table)->where($this->column($table), $this->id($userId));
    }

    public function stamp(string $table, int $userId, array $row): array
    {
        $companyId = $this->id($userId);
        if (Schema::hasColumn($table, 'company_id')) $row['company_id'] = $companyId;
        return $row;
    }
}
