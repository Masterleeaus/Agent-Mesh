<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class MileageService
{
    public function __construct(private ConnectionInterface $db,private AssetCompanyContext $companies,private FleetService $fleet,private AssetReferenceGuard $references){}
    public function list(int$userId):array{return$this->companies->query('titan_asset_vehicle_mileage_logs',$userId)->orderByDesc('occurred_at')->limit(500)->get()->map(fn($r)=>(array)$r)->all();}
    public function log(int$userId,string$vehicle,int$odometerKm,array$data=[]):array
    {
        $this->references->assertWorkOrder($userId,$data['work_order_public_id']??null);
        $current=$this->fleet->get($userId,$vehicle);$start=(int)($data['odometer_start']??$current['odometer_km']??0);$end=(int)($data['odometer_end']??$odometerKm);if($end<$start)throw new InvalidArgumentException('Odometer end cannot be less than start.');$km=(int)($data['km_driven']??$data['distance_km']??($end-$start));$this->fleet->updateOdometer($userId,$vehicle,$end,$data);$id=(string)Str::ulid();$row=$this->companies->stamp('titan_asset_vehicle_mileage_logs',$userId,['public_id'=>$id,'vehicle_public_id'=>$vehicle,'odometer_km'=>$end,'distance_km'=>$km,'purpose'=>$data['purpose']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'occurred_at'=>$data['occurred_at']??$data['log_date']??now(),'actor_user_id'=>$userId,'odometer_start'=>$start,'odometer_end'=>$end,'km_driven'=>$km,'notes'=>$data['notes']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('titan_asset_vehicle_mileage_logs')->insert($row);return(array)$this->companies->query('titan_asset_vehicle_mileage_logs',$userId)->where('public_id',$id)->first();
    }
    public function delete(int$userId,string$id):void{if(!$this->companies->query('titan_asset_vehicle_mileage_logs',$userId)->where('public_id',$id)->exists())throw new InvalidArgumentException('Mileage log not found.');$this->companies->query('titan_asset_vehicle_mileage_logs',$userId)->where('public_id',$id)->delete();}
}
