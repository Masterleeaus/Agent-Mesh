<?php

declare(strict_types=1);
namespace App\Extensions\TitanAssets\System\Domains\Assets;

final class AssetCrudService
{
    public function __construct(private AssetRegisterService $assets) {}
    public function show(int $userId,string $type,string $publicId):array{return $this->assets->get($userId,$type,$publicId);}
    public function update(int $userId,string $type,string $publicId,array $data):array{return $this->assets->update($userId,$type,$publicId,$data);}
    public function delete(int $userId,string $type,string $publicId):void{$this->assets->delete($userId,$type,$publicId);}
    public function retire(int $userId,string $type,string $publicId,array $data=[]):array{return $this->assets->retire($userId,$type,$publicId,$data['retired_on']??null,$data);}
    public function writeOff(int $userId,string $type,string $publicId,array $data=[]):array{return $this->assets->writeOff($userId,$type,$publicId,$data['written_off_on']??null,$data['written_off_reason']??$data['notes']??null);}
    public function sell(int $userId,string $type,string $publicId,array $data=[]):array{return $this->assets->sell($userId,$type,$publicId,$data['sold_on']??null,isset($data['value_minor'])?(int)$data['value_minor']:null,$data);}
}
