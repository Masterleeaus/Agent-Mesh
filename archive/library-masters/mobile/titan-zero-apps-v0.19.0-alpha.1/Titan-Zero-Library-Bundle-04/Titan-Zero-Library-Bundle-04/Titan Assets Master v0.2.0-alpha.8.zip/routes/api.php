<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetAllocationController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetCategoryController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetCrudController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetHistoryController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetLocationController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetReportsController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetScanController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetSettingsController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetTypeController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetsController;
use App\Extensions\TitanAssets\System\Http\Controllers\EquipmentCheckController;
use App\Extensions\TitanAssets\System\Http\Controllers\WarrantyProfileController;
use Illuminate\Support\Facades\Route;

$view = EnsureCrmPermission::class . ':crm.locker.view';
$manage = EnsureCrmPermission::class . ':crm.locker.assets.manage';
$fleet = EnsureCrmPermission::class . ':crm.locker.fleet.manage';

Route::middleware(config('crm.api_middleware', ['api', 'auth:api']))->prefix('api/titan-assets')->group(function () use ($view, $manage, $fleet): void {
    Route::get('/overview', [AssetsController::class, 'overview'])->middleware($view)->name('api.titan-assets.overview');
    Route::get('/reports', [AssetReportsController::class, 'report'])->middleware($view)->name('api.titan-assets.reports');

    Route::post('/assets/{type}', [AssetsController::class, 'createAsset'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.assets.store');
    Route::get('/assets/{type}/{asset}', [AssetCrudController::class, 'show'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($view)->name('api.titan-assets.assets.show');
    Route::match(['put', 'patch'], '/assets/{type}/{asset}', [AssetCrudController::class, 'update'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.assets.update');
    Route::delete('/assets/{type}/{asset}', [AssetCrudController::class, 'destroy'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.assets.destroy');
    Route::post('/assets/{type}/{asset}/write-off', [AssetCrudController::class, 'writeOff'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.assets.write-off');

    Route::post('/asset-types', [AssetTypeController::class, 'store'])->middleware($manage)->name('api.titan-assets.asset-types.store');
    Route::patch('/asset-types/{type}', [AssetTypeController::class, 'update'])->middleware($manage)->name('api.titan-assets.asset-types.update');
    Route::delete('/asset-types/{type}', [AssetTypeController::class, 'destroy'])->middleware($manage)->name('api.titan-assets.asset-types.destroy');
    Route::post('/asset-categories', [AssetCategoryController::class, 'store'])->middleware($manage)->name('api.titan-assets.asset-categories.store');
    Route::patch('/asset-categories/{category}', [AssetCategoryController::class, 'update'])->middleware($manage)->name('api.titan-assets.asset-categories.update');
    Route::delete('/asset-categories/{category}', [AssetCategoryController::class, 'destroy'])->middleware($manage)->name('api.titan-assets.asset-categories.destroy');

    Route::post('/history/issue', [AssetHistoryController::class, 'issue'])->middleware($manage)->name('api.titan-assets.history.issue');
    Route::post('/history/{history}/return', [AssetHistoryController::class, 'returnAsset'])->middleware($manage)->name('api.titan-assets.history.return');
    Route::delete('/history/{history}', [AssetHistoryController::class, 'destroy'])->middleware($manage)->name('api.titan-assets.history.destroy');

    Route::post('/allocations', [AssetAllocationController::class, 'store'])->middleware($manage)->name('api.titan-assets.allocations.store');
    Route::post('/allocations/{allocation}/revoke', [AssetAllocationController::class, 'revoke'])->middleware($manage)->name('api.titan-assets.allocations.revoke');
    Route::delete('/allocations/{allocation}', [AssetAllocationController::class, 'destroy'])->middleware($manage)->name('api.titan-assets.allocations.destroy');

    Route::post('/tools/{tool}/checkout', [AssetsController::class, 'checkoutTool'])->middleware($manage)->name('api.titan-assets.tools.checkout');
    Route::post('/tools/{tool}/return', [AssetsController::class, 'returnTool'])->middleware($manage)->name('api.titan-assets.tools.return');
    Route::post('/fleet/{vehicle}/assign', [AssetsController::class, 'assignFleet'])->middleware($fleet)->name('api.titan-assets.fleet.assign');
    Route::post('/fleet/{vehicle}/odometer', [AssetsController::class, 'updateFleetOdometer'])->middleware($fleet)->name('api.titan-assets.fleet.odometer');
    Route::post('/fleet/{vehicle}/mileage', [AssetsController::class, 'logMileage'])->middleware($fleet)->name('api.titan-assets.mileage.store');
    Route::delete('/mileage/{mileage}', [AssetsController::class, 'deleteMileage'])->middleware($fleet)->name('api.titan-assets.mileage.destroy');

    Route::post('/assets/{type}/{asset}/maintenance', [AssetsController::class, 'scheduleMaintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.maintenance.store');
    Route::patch('/maintenance/{maintenance}', [AssetsController::class, 'updateMaintenance'])->middleware($manage)->name('api.titan-assets.maintenance.update');
    Route::post('/maintenance/{maintenance}/complete', [AssetsController::class, 'completeMaintenance'])->middleware($manage)->name('api.titan-assets.maintenance.complete');
    Route::delete('/maintenance/{maintenance}', [AssetsController::class, 'deleteMaintenance'])->middleware($manage)->name('api.titan-assets.maintenance.destroy');

    Route::post('/repairs', [AssetsController::class, 'createRepair'])->middleware($manage)->name('api.titan-assets.repairs.store');
    Route::patch('/repairs/{repair}', [AssetsController::class, 'updateRepair'])->middleware($manage)->name('api.titan-assets.repairs.update');
    Route::post('/repairs/{repair}/status', [AssetsController::class, 'setRepairStatus'])->middleware($manage)->name('api.titan-assets.repairs.status');
    Route::delete('/repairs/{repair}', [AssetsController::class, 'deleteRepair'])->middleware($manage)->name('api.titan-assets.repairs.destroy');

    Route::post('/repair-templates', [AssetsController::class, 'createRepairTemplate'])->middleware($manage)->name('api.titan-assets.repair-templates.store');
    Route::patch('/repair-templates/{template}', [AssetsController::class, 'updateRepairTemplate'])->middleware($manage)->name('api.titan-assets.repair-templates.update');
    Route::delete('/repair-templates/{template}', [AssetsController::class, 'deleteRepairTemplate'])->middleware($manage)->name('api.titan-assets.repair-templates.destroy');

    Route::post('/warranties', [AssetsController::class, 'createWarranty'])->middleware($manage)->name('api.titan-assets.warranties.store');
    Route::patch('/warranties/{warranty}', [AssetsController::class, 'updateWarranty'])->middleware($manage)->name('api.titan-assets.warranties.update');
    Route::delete('/warranties/{warranty}', [AssetsController::class, 'deleteWarranty'])->middleware($manage)->name('api.titan-assets.warranties.destroy');
    Route::post('/warranty-profiles', [WarrantyProfileController::class, 'store'])->middleware($manage)->name('api.titan-assets.warranty-profiles.store');
    Route::post('/warranty-profiles/{profile}/compute', [WarrantyProfileController::class, 'compute'])->middleware($manage)->name('api.titan-assets.warranty-profiles.compute');

    Route::get('/location-register', [AssetLocationController::class, 'index'])->middleware($view)->name('api.titan-assets.location-register.index');
    Route::post('/location-register', [AssetLocationController::class, 'store'])->middleware($manage)->name('api.titan-assets.location-register.store');
    Route::post('/equipment-checks/{register}', [EquipmentCheckController::class, 'store'])->middleware($manage)->name('api.titan-assets.equipment-checks.store');

    Route::post('/premises-links', [AssetsController::class, 'linkPremises'])->middleware($manage)->name('api.titan-assets.premises.store');
    Route::delete('/premises-links/{link}', [AssetsController::class, 'unlinkPremises'])->middleware($manage)->name('api.titan-assets.premises.destroy');

    Route::post('/scan/{type}/{asset}/issue', [AssetScanController::class, 'issue'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.issue');
    Route::post('/scan/{type}/{asset}/return', [AssetScanController::class, 'returnAsset'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.return');
    Route::post('/scan/{type}/{asset}/report', [AssetScanController::class, 'report'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.report');
    Route::post('/scan/{type}/{asset}/maintenance', [AssetScanController::class, 'maintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.maintenance');
    Route::post('/scan/{type}/{asset}/maintenance/complete', [AssetScanController::class, 'completeMaintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.maintenance.complete');
    Route::post('/scan/{type}/{asset}/allocate', [AssetScanController::class, 'allocate'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.allocate');
    Route::post('/scan/{type}/{asset}/revoke', [AssetScanController::class, 'revoke'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($manage)->name('api.titan-assets.scan.revoke');

    Route::get('/settings', [AssetSettingsController::class, 'show'])->middleware($view)->name('api.titan-assets.settings.show');
    Route::put('/settings', [AssetSettingsController::class, 'update'])->middleware($manage)->name('api.titan-assets.settings.update');
});
