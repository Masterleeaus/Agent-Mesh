<?php

declare(strict_types=1);

use App\Extensions\Crm\System\Http\Middleware\EnsureCrmHostEnabled;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetAllocationController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetCategoryController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetCrudController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetHistoryController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetLocationController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetReportsController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetScanController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetSettingsController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetTypeController;
use App\Extensions\TitanAssets\System\Http\Controllers\AssetsController;
use App\Extensions\TitanAssets\System\Http\Controllers\EquipmentCheckController;
use App\Extensions\TitanAssets\System\Http\Controllers\WarrantyProfileController;
use App\Http\Middleware\CheckTemplateTypeAndPlan;
use Illuminate\Support\Facades\Route;

$viewPermission = EnsureCrmPermission::class . ':crm.locker.view';
$assetPermission = EnsureCrmPermission::class . ':crm.locker.assets.manage';
$fleetPermission = EnsureCrmPermission::class . ':crm.locker.fleet.manage';

Route::middleware(array_merge(config('crm.middleware', ['web', 'auth']), [EnsureCrmHostEnabled::class, CheckTemplateTypeAndPlan::class]))
    ->prefix('dashboard/user/assets')
    ->group(function () use ($viewPermission, $assetPermission, $fleetPermission): void {
        $sections = [
            '' => ['overview', 'titan-assets.overview'],
            'register' => ['register', 'titan-assets.register'],
            'asset-types' => ['asset-types', 'titan-assets.asset-types'],
            'asset-categories' => ['asset-categories', 'titan-assets.asset-categories'],
            'tools' => ['tools', 'titan-assets.tools'],
            'equipment' => ['equipment', 'titan-assets.equipment'],
            'fleet' => ['fleet', 'titan-assets.fleet'],
            'customer-assets' => ['customer-assets', 'titan-assets.customer-assets'],
            'custody' => ['custody', 'titan-assets.custody'],
            'allocations' => ['allocations', 'titan-assets.allocations'],
            'history' => ['history', 'titan-assets.history'],
            'maintenance' => ['maintenance', 'titan-assets.maintenance'],
            'repairs' => ['repairs', 'titan-assets.repairs'],
            'repair-templates' => ['repair-templates', 'titan-assets.repair-templates'],
            'downtime' => ['downtime', 'titan-assets.downtime'],
            'warranties' => ['warranties', 'titan-assets.warranties'],
            'warranty-profiles' => ['warranty-profiles', 'titan-assets.warranty-profiles'],
            'mileage' => ['mileage', 'titan-assets.mileage'],
            'location-register' => ['location-register', 'titan-assets.location-register'],
            'equipment-checks' => ['equipment-checks', 'titan-assets.equipment-checks'],
            'premises' => ['premises', 'titan-assets.premises'],
            'lifecycle' => ['lifecycle', 'titan-assets.lifecycle'],
            'reports' => ['reports', 'titan-assets.reports'],
            'settings' => ['settings', 'titan-assets.settings'],
        ];
        foreach ($sections as $path => [$section, $name]) {
            Route::get($path === '' ? '/' : '/' . $path, [AssetsController::class, 'index'])
                ->defaults('section', $section)->middleware($viewPermission)->name($name);
        }
        Route::get('/scan', [AssetsController::class, 'scan'])->middleware($viewPermission)->name('titan-assets.scan');
        Route::get('/reports/data', [AssetReportsController::class, 'report'])->middleware($viewPermission)->name('titan-assets.reports.data');
        Route::get('/settings/data', [AssetSettingsController::class, 'show'])->middleware($viewPermission)->name('titan-assets.settings.data');
        Route::get('/location-register/data', [AssetLocationController::class, 'index'])->middleware($viewPermission)->name('titan-assets.location-register.data');
        Route::get('/equipment-checks/data', [EquipmentCheckController::class, 'index'])->middleware($viewPermission)->name('titan-assets.equipment-checks.data');

        Route::post('/assets/{type}', [AssetsController::class, 'createAsset'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.store');
        Route::get('/assets/{type}/{asset}', [AssetCrudController::class, 'show'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($viewPermission)->name('titan-assets.assets.show');
        Route::match(['put', 'patch'], '/assets/{type}/{asset}', [AssetCrudController::class, 'update'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.update');
        Route::delete('/assets/{type}/{asset}', [AssetCrudController::class, 'destroy'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.destroy');
        Route::post('/assets/{type}/{asset}/retire', [AssetCrudController::class, 'retire'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.retire');
        Route::post('/assets/{type}/{asset}/write-off', [AssetCrudController::class, 'writeOff'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.write-off');
        Route::post('/assets/{type}/{asset}/sell', [AssetCrudController::class, 'sell'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.sell');
        Route::post('/assets/{type}/{asset}/documents', [AssetCrudController::class, 'document'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.documents.store');
        Route::post('/assets/{type}/{asset}/image', [AssetCrudController::class, 'image'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.image.store');
        Route::delete('/assets/{type}/{asset}/image', [AssetCrudController::class, 'deleteImage'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.assets.image.destroy');
        Route::delete('/documents/{document}', [AssetCrudController::class, 'deleteDocument'])->middleware($assetPermission)->name('titan-assets.documents.destroy');

        Route::post('/asset-types', [AssetTypeController::class, 'store'])->middleware($assetPermission)->name('titan-assets.asset-types.store');
        Route::match(['put', 'patch'], '/asset-types/{type}', [AssetTypeController::class, 'update'])->middleware($assetPermission)->name('titan-assets.asset-types.update');
        Route::delete('/asset-types/{type}', [AssetTypeController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.asset-types.destroy');

        Route::post('/asset-categories', [AssetCategoryController::class, 'store'])->middleware($assetPermission)->name('titan-assets.asset-categories.store');
        Route::match(['put', 'patch'], '/asset-categories/{category}', [AssetCategoryController::class, 'update'])->middleware($assetPermission)->name('titan-assets.asset-categories.update');
        Route::delete('/asset-categories/{category}', [AssetCategoryController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.asset-categories.destroy');

        Route::post('/history/issue', [AssetHistoryController::class, 'issue'])->middleware($assetPermission)->name('titan-assets.history.issue');
        Route::match(['put', 'patch'], '/history/{history}', [AssetHistoryController::class, 'update'])->middleware($assetPermission)->name('titan-assets.history.update');
        Route::post('/history/{history}/return', [AssetHistoryController::class, 'returnAsset'])->middleware($assetPermission)->name('titan-assets.history.return');
        Route::delete('/history/{history}', [AssetHistoryController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.history.destroy');

        Route::post('/allocations', [AssetAllocationController::class, 'store'])->middleware($assetPermission)->name('titan-assets.allocations.store');
        Route::match(['put', 'patch'], '/allocations/{allocation}', [AssetAllocationController::class, 'update'])->middleware($assetPermission)->name('titan-assets.allocations.update');
        Route::post('/allocations/{allocation}/revoke', [AssetAllocationController::class, 'revoke'])->middleware($assetPermission)->name('titan-assets.allocations.revoke');
        Route::delete('/allocations/{allocation}', [AssetAllocationController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.allocations.destroy');

        Route::post('/tools/{tool}/checkout', [AssetsController::class, 'checkoutTool'])->middleware($assetPermission)->name('titan-assets.tools.checkout');
        Route::post('/tools/{tool}/return', [AssetsController::class, 'returnTool'])->middleware($assetPermission)->name('titan-assets.tools.return');
        Route::post('/tools/{tool}/damage', [AssetsController::class, 'damageTool'])->middleware($assetPermission)->name('titan-assets.tools.damage');
        Route::post('/tools/{tool}/lost', [AssetsController::class, 'lostTool'])->middleware($assetPermission)->name('titan-assets.tools.lost');

        Route::post('/fleet/{vehicle}/assign', [AssetsController::class, 'assignFleet'])->middleware($fleetPermission)->name('titan-assets.fleet.assign');
        Route::post('/fleet/{vehicle}/unassign', [AssetsController::class, 'unassignFleet'])->middleware($fleetPermission)->name('titan-assets.fleet.unassign');
        Route::post('/fleet/{vehicle}/odometer', [AssetsController::class, 'updateFleetOdometer'])->middleware($fleetPermission)->name('titan-assets.fleet.odometer');
        Route::post('/fleet/{vehicle}/status', [AssetsController::class, 'updateFleetStatus'])->middleware($fleetPermission)->name('titan-assets.fleet.status');

        Route::post('/assets/{type}/{asset}/maintenance', [AssetsController::class, 'scheduleMaintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.maintenance.store');
        Route::match(['put', 'patch'], '/maintenance/{maintenance}', [AssetsController::class, 'updateMaintenance'])->middleware($assetPermission)->name('titan-assets.maintenance.update');
        Route::post('/maintenance/{maintenance}/complete', [AssetsController::class, 'completeMaintenance'])->middleware($assetPermission)->name('titan-assets.maintenance.complete');
        Route::post('/maintenance/{maintenance}/cancel', [AssetsController::class, 'cancelMaintenance'])->middleware($assetPermission)->name('titan-assets.maintenance.cancel');
        Route::delete('/maintenance/{maintenance}', [AssetsController::class, 'deleteMaintenance'])->middleware($assetPermission)->name('titan-assets.maintenance.destroy');

        Route::post('/repairs', [AssetsController::class, 'createRepair'])->middleware($assetPermission)->name('titan-assets.repairs.store');
        Route::match(['put', 'patch'], '/repairs/{repair}', [AssetsController::class, 'updateRepair'])->middleware($assetPermission)->name('titan-assets.repairs.update');
        Route::post('/repairs/{repair}/status', [AssetsController::class, 'setRepairStatus'])->middleware($assetPermission)->name('titan-assets.repairs.status');
        Route::delete('/repairs/{repair}', [AssetsController::class, 'deleteRepair'])->middleware($assetPermission)->name('titan-assets.repairs.destroy');

        Route::post('/repair-templates', [AssetsController::class, 'createRepairTemplate'])->middleware($assetPermission)->name('titan-assets.repair-templates.store');
        Route::match(['put', 'patch'], '/repair-templates/{template}', [AssetsController::class, 'updateRepairTemplate'])->middleware($assetPermission)->name('titan-assets.repair-templates.update');
        Route::delete('/repair-templates/{template}', [AssetsController::class, 'deleteRepairTemplate'])->middleware($assetPermission)->name('titan-assets.repair-templates.destroy');

        Route::post('/warranties', [AssetsController::class, 'createWarranty'])->middleware($assetPermission)->name('titan-assets.warranties.store');
        Route::match(['put', 'patch'], '/warranties/{warranty}', [AssetsController::class, 'updateWarranty'])->middleware($assetPermission)->name('titan-assets.warranties.update');
        Route::post('/warranties/{warranty}/status', [AssetsController::class, 'setWarrantyStatus'])->middleware($assetPermission)->name('titan-assets.warranties.status');
        Route::delete('/warranties/{warranty}', [AssetsController::class, 'deleteWarranty'])->middleware($assetPermission)->name('titan-assets.warranties.destroy');

        Route::post('/warranty-profiles', [WarrantyProfileController::class, 'store'])->middleware($assetPermission)->name('titan-assets.warranty-profiles.store');
        Route::match(['put', 'patch'], '/warranty-profiles/{profile}', [WarrantyProfileController::class, 'update'])->middleware($assetPermission)->name('titan-assets.warranty-profiles.update');
        Route::delete('/warranty-profiles/{profile}', [WarrantyProfileController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.warranty-profiles.destroy');
        Route::post('/warranty-profiles/{profile}/compute', [WarrantyProfileController::class, 'compute'])->middleware($assetPermission)->name('titan-assets.warranty-profiles.compute');

        Route::post('/fleet/{vehicle}/mileage', [AssetsController::class, 'logMileage'])->middleware($fleetPermission)->name('titan-assets.mileage.store');
        Route::delete('/mileage/{mileage}', [AssetsController::class, 'deleteMileage'])->middleware($fleetPermission)->name('titan-assets.mileage.destroy');

        Route::post('/location-register', [AssetLocationController::class, 'store'])->middleware($assetPermission)->name('titan-assets.location-register.store');
        Route::delete('/location-register/{register}', [AssetLocationController::class, 'destroy'])->middleware($assetPermission)->name('titan-assets.location-register.destroy');
        Route::post('/equipment-checks/{register}', [EquipmentCheckController::class, 'store'])->middleware($assetPermission)->name('titan-assets.equipment-checks.store');

        Route::post('/premises-links', [AssetsController::class, 'linkPremises'])->middleware($assetPermission)->name('titan-assets.premises.store');
        Route::delete('/premises-links/{link}', [AssetsController::class, 'unlinkPremises'])->middleware($assetPermission)->name('titan-assets.premises.destroy');

        Route::post('/scan/{type}/{asset}/issue', [AssetScanController::class, 'issue'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.issue');
        Route::post('/scan/{type}/{asset}/return', [AssetScanController::class, 'returnAsset'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.return');
        Route::post('/scan/{type}/{asset}/report', [AssetScanController::class, 'report'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.report');
        Route::post('/scan/{type}/{asset}/maintenance', [AssetScanController::class, 'maintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.maintenance');
        Route::post('/scan/{type}/{asset}/maintenance/complete', [AssetScanController::class, 'completeMaintenance'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.maintenance.complete');
        Route::post('/scan/{type}/{asset}/allocate', [AssetScanController::class, 'allocate'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.allocate');
        Route::post('/scan/{type}/{asset}/revoke', [AssetScanController::class, 'revoke'])->whereIn('type', ['tool', 'equipment', 'vehicle'])->middleware($assetPermission)->name('titan-assets.scan.revoke');

        Route::put('/settings', [AssetSettingsController::class, 'update'])->middleware($assetPermission)->name('titan-assets.settings.update');
    });
