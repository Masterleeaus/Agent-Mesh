#!/usr/bin/env python3
import json, pathlib, re, sys
root=pathlib.Path(__file__).resolve().parents[2]
errors=[]
def need_file(rel):
    if not (root/rel).is_file(): errors.append('missing file: '+rel)
def need_text(rel, needles):
    p=root/rel
    if not p.is_file(): errors.append('missing file: '+rel); return
    text=p.read_text(errors='ignore')
    for n in needles:
        if n not in text: errors.append(f'{rel}: missing {n}')

m=json.loads((root/'extension.json').read_text())
deps=m.get('dependencies')
if not isinstance(deps,list) or not deps or not all(isinstance(d,dict) and d.get('slug') and d.get('version') for d in deps):
    errors.append('Installer 1.7.8 dependency objects missing')
if not isinstance(m.get('optional_dependencies'),list): errors.append('optional_dependencies must be array')
if m.get('version')!='0.2.0-alpha.2': errors.append('version not 0.2.0-alpha.2')

# Donor-parity domain units.
for rel in [
'System/Domains/Assets/AssetCompanyContext.php',
'System/Domains/Assets/AssetTypeService.php',
'System/Domains/Assets/AssetCategoryService.php',
'System/Domains/Assets/AssetCrudService.php',
'System/Domains/Assets/AssetAllocationService.php',
'System/Domains/Assets/AssetHistoryService.php',
'System/Domains/Assets/AssetSettingsService.php',
'System/Domains/Assets/AssetValuationService.php',
'System/Domains/Assets/AssetLocationRegisterService.php',
'System/Domains/Assets/EquipmentCheckService.php',
'System/Domains/Assets/AssetDocumentService.php',
'System/Domains/Assets/AssetMediaService.php',
'System/Domains/Assets/AssetMaintenanceNotificationService.php',
'System/Http/Controllers/AssetCrudController.php',
'System/Http/Controllers/AssetTypeController.php',
'System/Http/Controllers/AssetCategoryController.php',
'System/Http/Controllers/AssetAllocationController.php',
'System/Http/Controllers/AssetHistoryController.php',
'System/Http/Controllers/AssetScanController.php',
'System/Http/Controllers/AssetSettingsController.php',
'System/Http/Controllers/AssetReportsController.php',
'System/Http/Controllers/AssetLocationController.php',
'System/Http/Controllers/EquipmentCheckController.php',
'database/migrations/2026_08_18_233000_expand_titan_assets_full_feature_domain.php',
'resources/views/assets/show.blade.php',
'resources/views/assets/forms.blade.php',
'resources/views/assets/reports.blade.php',
]: need_file(rel)

need_text('routes/web.php',[
"titan-assets.asset-types", "titan-assets.asset-categories", "titan-assets.allocations", "titan-assets.history",
"titan-assets.downtime", "titan-assets.warranty-profiles", "titan-assets.location-register",
"titan-assets.equipment-checks", "titan-assets.lifecycle", "titan-assets.reports",
"titan-assets.assets.update", "titan-assets.assets.destroy", "titan-assets.assets.image.store", "titan-assets.assets.image.destroy", "titan-assets.repairs.update",
"titan-assets.repairs.destroy", "titan-assets.repair-templates.update", "titan-assets.repair-templates.destroy",
"titan-assets.warranties.update", "titan-assets.warranties.destroy", "titan-assets.mileage.destroy",
"titan-assets.warranty-profiles.compute", "titan-assets.scan.issue", "titan-assets.scan.return",
"titan-assets.scan.report", "titan-assets.scan.maintenance", "titan-assets.scan.maintenance.complete", "titan-assets.scan.allocate", "titan-assets.scan.revoke",
])
need_text('config/navigation.php',[
'Asset Types','Asset Categories','Allocations','Asset History','Downtime','Warranty Profiles','Location Register','Equipment Checks','Lifecycle & Valuation','Reports'
])
need_text('database/migrations/2026_08_18_233000_expand_titan_assets_full_feature_domain.php',[
"titan_asset_types", "titan_asset_categories", "titan_asset_allocations", "titan_asset_lending_history", "titan_asset_settings",
"titan_asset_warranty_profiles", "titan_asset_location_registers", "titan_asset_equipment_checks",
"titan_asset_documents", "company_id"
])
need_text('System/Domains/Assets/RepairService.php',['assigned_to_user_id','root_cause','parts_used','under_warranty','awaiting_parts'])
need_text('System/Domains/Assets/RepairTemplateService.php',['equipment_category','standard_parts','estimated_hours'])
need_text('System/Domains/Assets/WarrantyService.php',['profile_public_id','warrantyStatus'])
need_text('System/Domains/Assets/MileageService.php',['odometer_start','odometer_end','km_driven'])
need_text('System/Domains/Assets/AssetQueryService.php',['downtime','assetHistory','lifecycleReport'])
need_text('System/Navigation/AssetMenuSelfHealer.php',["titan-assets-menu-0.2.0-alpha.2",'MenuService'])

need_text('System/Domains/Assets/AssetRegisterService.php',['nextReference','qr_token','written_off_reason'])
need_text('System/Domains/Assets/MaintenanceService.php',['priority','assigned_to_user_id','reference_no','AssetMaintenanceNotificationService'])
need_text('System/Domains/Assets/AssetMaintenanceNotificationService.php',['send_for_maintenance_subject','assigned_for_maintenance_subject','Mail::'])
need_text('System/Http/Controllers/AssetScanController.php',['completeMaintenance'])
need_text('database/migrations/2026_08_18_233000_expand_titan_assets_full_feature_domain.php',['qr_token','written_off_reason','priority','assigned_to_user_id','reference_no','send_for_maintenance_subject','titan_asset_categories'])
need_text('resources/views/assets/forms.blade.php',['notify_sent_for_maintenance','send_for_maintenance_subject','assigned_for_maintenance_subject'])


if errors:
    print('FEATURE PARITY FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('FEATURE PARITY PASS')
