<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=[];
$guard=$root.'/System/Domains/Assets/AssetReferenceGuard.php';
if(!is_file($guard))$fail[]='AssetReferenceGuard missing';
$port=$root.'/System/Integrations/Crm/AssetCrmReferenceAuthorityPort.php';$adapter=$root.'/System/Integrations/Crm/CrmAssetReferenceAuthorityAdapter.php';
if(!is_file($port)||!is_file($adapter))$fail[]='CRM reference authority port/adapter missing';
$guardSource=(string)@file_get_contents($guard);if(str_contains($guardSource,'crm_work_orders')||str_contains($guardSource,'crm_service_locations'))$fail[]='Asset guard bypasses CRM authority port with direct CRM tables';
$alloc=(string)@file_get_contents($root.'/System/Domains/Assets/AssetAllocationService.php');
$loc=(string)@file_get_contents($root.'/System/Domains/Assets/AssetLocationRegisterService.php');
$check=(string)@file_get_contents($root.'/System/Domains/Assets/EquipmentCheckService.php');
$mileage=(string)@file_get_contents($root.'/System/Domains/Assets/MileageService.php');
$repair=(string)@file_get_contents($root.'/System/Domains/Assets/RepairService.php');
foreach ([[$alloc,'assertUser'],[$loc,'assertServiceLocation'],[$check,'assertWorkOrder'],[$mileage,'assertWorkOrder'],[$repair,'assertUser'],[$repair,'assertServiceLocation'],[$repair,'assertWorkOrder']] as [$src,$needle]) if(!str_contains($src,$needle))$fail[]="missing {$needle} integration";
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);} echo "Agent2 Pass11 Assets foreign-reference guard PASS\n";
