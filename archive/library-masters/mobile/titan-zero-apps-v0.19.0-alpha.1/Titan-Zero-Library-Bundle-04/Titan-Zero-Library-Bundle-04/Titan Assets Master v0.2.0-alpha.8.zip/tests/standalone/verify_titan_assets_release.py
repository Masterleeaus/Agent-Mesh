#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('root', nargs='?', default=str(Path(__file__).resolve().parents[2]))
parser.add_argument('--sql', default='/mnt/data/admin_titan_1787056710(1).sql')
args = parser.parse_args()
root = Path(args.root).resolve()
sql_path = Path(args.sql)
errors: list[str] = []


def fail(msg: str) -> None:
    errors.append(msg)


def read(rel: str) -> str:
    p = root / rel
    if not p.is_file():
        fail(f'missing file: {rel}')
        return ''
    return p.read_text(errors='replace')


def load_json(rel: str):
    try:
        return json.loads(read(rel))
    except Exception as exc:
        fail(f'json parse {rel}: {exc}')
        return {}

# ---- exact Installer 1.7.8 root manifest contract ----
m = load_json('extension.json')
expected = {
    'schema': 'titan-extension-v1',
    'slug': 'titan-assets',
    'name': 'Titan Assets',
    'version': '0.2.0-alpha.2',
    'folder': 'TitanAssets',
    'provider': 'App\\Extensions\\TitanAssets\\System\\TitanAssetsServiceProvider',
    'migrations': True,
}
for key, value in expected.items():
    if m.get(key) != value:
        fail(f'manifest {key}: expected {value!r}, got {m.get(key)!r}')

deps = m.get('dependencies')
if not isinstance(deps, list) or deps != [{'slug': 'crm', 'version': '>=1.3.0-alpha.17'}]:
    fail('Installer 1.7.8 dependencies must be [{"slug":"crm","version":">=1.3.0-alpha.17"}]')
if m.get('optional_dependencies') != []:
    fail('optional_dependencies must be an empty array for Installer 1.7.8')
req = m.get('requires') or {}
for key, value in {'php': '>=8.2', 'magicai': '>=10.91', 'titan_platform': '>=1.0'}.items():
    if req.get(key) != value:
        fail(f'requires.{key} mismatch')

# Root-manifest hashes cover every regular packaged file except the manifest itself.
actual_files = sorted(
    p.relative_to(root).as_posix()
    for p in root.rglob('*')
    if p.is_file() and p.name != 'extension.json'
)
integrity = m.get('integrity')
if not isinstance(integrity, dict):
    fail('manifest integrity must be a direct path=>sha256 map')
    integrity = {}
if sorted(integrity) != actual_files:
    missing = sorted(set(actual_files) - set(integrity))
    extra = sorted(set(integrity) - set(actual_files))
    if missing: fail('integrity missing: ' + ', '.join(missing[:20]))
    if extra: fail('integrity extra: ' + ', '.join(extra[:20]))
for rel in actual_files:
    want = integrity.get(rel)
    got = 'sha256:' + hashlib.sha256((root / rel).read_bytes()).hexdigest()
    if want != got:
        fail(f'integrity mismatch: {rel}')

# ---- provider identity / install-time safety ----
provider_rel = 'System/TitanAssetsServiceProvider.php'
provider = read(provider_rel)
for marker in [
    'namespace App\\Extensions\\TitanAssets\\System;',
    'class TitanAssetsServiceProvider extends ServiceProvider',
    "loadRoutesFrom(__DIR__ . '/../routes/web.php')",
    "loadRoutesFrom(__DIR__ . '/../routes/api.php')",
    "loadMigrationsFrom(__DIR__ . '/../database/migrations')",
    "loadViewsFrom(__DIR__ . '/../resources/views', 'titan-assets')",
]:
    if marker not in provider:
        fail('provider marker missing: ' + marker)

# ---- feature surface / donor parity ----
required_files = [
    'System/Domains/Assets/AssetCompanyContext.php',
    'System/Domains/Assets/AssetRegisterService.php',
    'System/Domains/Assets/AssetCrudService.php',
    'System/Domains/Assets/AssetTypeService.php',
    'System/Domains/Assets/AssetCategoryService.php',
    'System/Domains/Assets/AssetMediaService.php',
    'System/Domains/Assets/AssetDocumentService.php',
    'System/Domains/Assets/AssetHistoryService.php',
    'System/Domains/Assets/AssetAllocationService.php',
    'System/Domains/Assets/AssetSettingsService.php',
    'System/Domains/Assets/AssetMaintenanceNotificationService.php',
    'System/Domains/Assets/AssetValuationService.php',
    'System/Domains/Assets/AssetLocationRegisterService.php',
    'System/Domains/Assets/EquipmentCheckService.php',
    'System/Domains/Assets/ToolCustodyService.php',
    'System/Domains/Assets/FleetService.php',
    'System/Domains/Assets/MileageService.php',
    'System/Domains/Assets/MaintenanceService.php',
    'System/Domains/Assets/RepairService.php',
    'System/Domains/Assets/RepairTemplateService.php',
    'System/Domains/Assets/WarrantyService.php',
    'System/Domains/Assets/WarrantyProfileService.php',
    'System/Domains/Assets/PremisesLinkService.php',
    'System/Domains/Assets/AssetQueryService.php',
    'resources/views/assets/index.blade.php',
    'resources/views/assets/show.blade.php',
    'resources/views/assets/forms.blade.php',
    'resources/views/assets/reports.blade.php',
    'docs/DONOR-FEATURE-COVERAGE.md',
    'docs/DONOR-ASSET-SURFACE-INVENTORY.json',
]
for rel in required_files:
    if not (root / rel).is_file(): fail('feature file missing: ' + rel)

feature_markers = {
    'System/Domains/Assets/AssetRegisterService.php': ['nextReference', 'qr_token', 'written_off_reason', 'depreciation'],
    'System/Domains/Assets/AssetAllocationService.php': ['revoke', 'quantity'],
    'System/Domains/Assets/AssetHistoryService.php': ['returnAsset', 'issued_at'],
    'System/Domains/Assets/MaintenanceService.php': ['priority', 'assigned_to_user_id', 'reference_no', 'AssetMaintenanceNotificationService'],
    'System/Domains/Assets/AssetMaintenanceNotificationService.php': ['send_for_maintenance_subject', 'assigned_for_maintenance_subject', 'Mail::'],
    'System/Domains/Assets/RepairService.php': ['assigned_to_user_id', 'root_cause', 'parts_used', 'parts_cost_minor', 'labour_cost_minor', 'under_warranty', 'awaiting_parts', 'downtimeSummary'],
    'System/Domains/Assets/RepairTemplateService.php': ['equipment_category', 'standard_parts', 'estimated_hours'],
    'System/Domains/Assets/WarrantyService.php': ['profile_public_id', 'warrantyStatus', 'additional_cost_minor'],
    'System/Domains/Assets/WarrantyProfileService.php': ['compute'],
    'System/Domains/Assets/MileageService.php': ['odometer_start', 'odometer_end', 'km_driven'],
    'System/Domains/Assets/AssetQueryService.php': ['downtime', 'assetHistory', 'lifecycleReport', 'qr_token'],
}
for rel, markers in feature_markers.items():
    txt = read(rel)
    for marker in markers:
        if marker not in txt: fail(f'{rel} missing feature marker {marker}')

# ---- routes must be named uniquely and point to real controller methods ----
route_text = read('routes/web.php') + '\n' + read('routes/api.php')
explicit_route_names = re.findall(r"->name\(['\"]([^'\"]+)['\"]\)", route_text)
dynamic_route_names = re.findall(r"['\"](titan-assets\.[a-z0-9_.-]+)['\"]", read('routes/web.php'))
route_names = explicit_route_names + [n for n in dynamic_route_names if n not in explicit_route_names]
dups = sorted({n for n in explicit_route_names if explicit_route_names.count(n) > 1})
if dups:
    fail('duplicate route names: ' + ', '.join(dups))
required_routes = [
    'titan-assets.overview', 'titan-assets.register', 'titan-assets.asset-types', 'titan-assets.asset-categories',
    'titan-assets.tools', 'titan-assets.equipment', 'titan-assets.fleet', 'titan-assets.customer-assets',
    'titan-assets.custody', 'titan-assets.allocations', 'titan-assets.history', 'titan-assets.maintenance',
    'titan-assets.repairs', 'titan-assets.repair-templates', 'titan-assets.downtime', 'titan-assets.warranties',
    'titan-assets.warranty-profiles', 'titan-assets.mileage', 'titan-assets.location-register',
    'titan-assets.equipment-checks', 'titan-assets.premises', 'titan-assets.lifecycle', 'titan-assets.reports',
    'titan-assets.scan', 'titan-assets.settings', 'titan-assets.scan.issue', 'titan-assets.scan.return',
    'titan-assets.scan.report', 'titan-assets.scan.maintenance', 'titan-assets.scan.maintenance.complete',
    'titan-assets.scan.allocate', 'titan-assets.scan.revoke',
]
for name in required_routes:
    if name not in route_names:
        fail('required route missing: ' + name)

imports = dict(re.findall(r'use\s+App\\Extensions\\TitanAssets\\System\\Http\\Controllers\\(\w+);', route_text)) if False else {}
# Resolve [Controller::class, 'method'] declarations against local controllers.
for controller, method in re.findall(r'\[(\w+)::class,\s*[\'\"](\w+)[\'\"]\]', route_text):
    p = root / 'System/Http/Controllers' / f'{controller}.php'
    if not p.is_file():
        fail(f'route controller missing: {controller}')
        continue
    source = p.read_text(errors='replace')
    if not re.search(rf'public\s+function\s+{re.escape(method)}\s*\(', source):
        fail(f'route method missing: {controller}::{method}')

# ---- menu self-healing must match live DB adoption strategy ----
nav = read('config/navigation.php')
menu_routes = re.findall(r"'route'\s*=>\s*'([^']+)'", nav)
menu_keys = re.findall(r"'key'\s*=>\s*'([^']+)'", nav)
if len(menu_keys) != 26:  # parent + 25 children
    fail(f'navigation expected 26 stable keys including parent, found {len(menu_keys)}')
for route in menu_routes:
    if route not in route_names:
        fail('navigation points at missing route: ' + route)
for key in ['titan_assets', 'crm_tools', 'crm_equipment', 'crm_fleet', 'crm_maintenance', 'crm_customer_assets']:
    if key not in menu_keys:
        fail('navigation/adoption key missing: ' + key)
healer = read('System/Navigation/AssetMenuSelfHealer.php')
for marker in [
    "SCHEMA_VERSION = 'titan-assets-menu-0.2.0-alpha.2'",
    "! $force && ! Schema::hasTable('titan_asset_settings')",
    'Route::has($route)',
    'MenuService::class',
    'method_exists($service, \'regenerate\')',
    '$service->regenerate()',
    'Cache::forever(self::CACHE_KEY, self::SCHEMA_VERSION)',
    'catch (\\Throwable)',
    'deactivateRouteDuplicates((string) $item[\'route\'], [$parentId, $id]',
]:
    if marker not in healer:
        fail('self-heal marker missing: ' + marker)

# ---- migration safety / live DB compatibility ----
migrations = sorted((root / 'database/migrations').glob('*.php'))
if len(migrations) != 4:
    fail(f'expected 4 Assets migrations, found {len(migrations)}')
for p in migrations:
    txt = p.read_text(errors='replace')
    if 'function down' not in txt:
        fail('migration missing down(): ' + p.name)

fresh_core = read('database/migrations/2026_08_18_230000_ensure_titan_assets_core_tables.php')
fresh_ext = read('database/migrations/2026_08_18_230100_create_titan_asset_extension_tables.php')
if 'company_id' not in fresh_core or 'company_id' not in fresh_ext:
    fail('fresh Assets migrations must use company_id')
for rel, txt in [
    ('230000', fresh_core), ('230100', fresh_ext)
]:
    # Fresh table creation must not create new company_id columns.
    if re.search(r"(?:unsignedBigInteger|bigInteger|integer|string|uuid)\(['\"]company_id['\"]", txt):
        fail(f'fresh migration {rel} creates legacy company_id')

all_production_php = '\n'.join(
    p.read_text(errors='replace')
    for p in root.rglob('*.php')
    if 'tests/' not in p.relative_to(root).as_posix()
)
for bad in ['namespace Modules\\', 'use Modules\\', 'module_path(', 'FSMCore', 'SystemCore', 'Worksuite']:
    if bad in all_production_php:
        fail('donor runtime leak: ' + bad)
for table in ['crm_locker_tools', 'crm_locker_equipment', 'crm_locker_fleet_vehicles', 'crm_locker_maintenance_records', 'crm_locker_asset_events']:
    if table not in all_production_php:
        fail('legacy asset table compatibility missing: ' + table)
for badop in [r'dropIfExists\([\'\"]crm_locker_', r'->drop\([\'\"]crm_locker_', r'->rename\([\'\"]crm_locker_']:
    if re.search(badop, all_production_php):
        fail('destructive legacy asset operation: ' + badop)

if sql_path.is_file():
    sql = sql_path.read_text(errors='replace')
    for p in migrations:
        if p.stem in sql:
            fail('migration basename already recorded in supplied live DB dump: ' + p.stem)
    live_keys = {'crm_customer_assets':'377','crm_tools':'495','crm_equipment':'496','crm_fleet':'497','crm_maintenance':'498','ext_crm_gear':'371'}
    for key, ident in live_keys.items():
        # Verify the supplied dump really contains the expected pre-existing row/key evidence.
        if key not in sql:
            fail('supplied DB dump missing expected menu key: ' + key)
else:
    fail('supplied SQL dump not found for migration/menu collision verification')

# ---- syntax and JSON gates ----
php_files = sorted(root.rglob('*.php'))
for p in php_files:
    proc = subprocess.run(['php', '-l', str(p)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if proc.returncode != 0:
        fail('PHP lint: ' + p.relative_to(root).as_posix() + ' :: ' + proc.stdout.strip())
json_files = sorted(root.rglob('*.json'))
for p in json_files:
    try:
        json.loads(p.read_text())
    except Exception as exc:
        fail(f'JSON parse {p.relative_to(root).as_posix()}: {exc}')

if errors:
    print(f'FAIL Titan Assets release contract: {len(errors)} error(s)')
    for err in errors:
        print(' - ' + err)
    sys.exit(1)

print('PASS Titan Assets release contract')
print(f'files={len(actual_files)+1} php={len(php_files)} json={len(json_files)} routes={len(route_names)} menu_keys={len(menu_keys)} migrations={len(migrations)}')
