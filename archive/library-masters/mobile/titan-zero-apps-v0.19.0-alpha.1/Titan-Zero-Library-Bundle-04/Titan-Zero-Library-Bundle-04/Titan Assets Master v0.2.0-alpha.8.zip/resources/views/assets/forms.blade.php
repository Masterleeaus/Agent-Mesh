@php
    $assetOptions = collect($tools ?? [])->map(fn($r) => ['type'=>'tool','id'=>$r['public_id'],'label'=>$r['name'] ?? $r['asset_tag']])
        ->concat(collect($equipment ?? [])->map(fn($r) => ['type'=>'equipment','id'=>$r['public_id'],'label'=>$r['name'] ?? $r['asset_tag']]))
        ->concat(collect($vehicles ?? [])->map(fn($r) => ['type'=>'vehicle','id'=>$r['public_id'],'label'=>$r['name'] ?? $r['registration']]))->values();
@endphp

@if(in_array($activeSection, ['register','tools','equipment','fleet'], true))
<div class="card mb-5">
    <div class="card-header"><h3 class="card-title">Add {{ $activeSection === 'fleet' ? 'Vehicle' : ucfirst(rtrim($activeSection, 's')) }}</h3></div>
    <div class="card-body">
        @php $createType = $activeSection === 'fleet' ? 'vehicle' : ($activeSection === 'equipment' ? 'equipment' : 'tool'); @endphp
        <form method="POST" action="{{ route('titan-assets.assets.store', ['type'=>$createType]) }}" class="row g-3">
            @csrf
            @if($createType === 'vehicle')
                <div class="col-md-4"><label class="form-label">Registration</label><input class="form-control" name="registration" required></div>
                <div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name"></div>
                <div class="col-md-4"><label class="form-label">VIN</label><input class="form-control" name="vin"></div>
                <div class="col-md-4"><label class="form-label">Make</label><input class="form-control" name="make"></div>
                <div class="col-md-4"><label class="form-label">Model</label><input class="form-control" name="model"></div>
                <div class="col-md-4"><label class="form-label">Year</label><input class="form-control" type="number" name="year"></div>
            @else
                <div class="col-md-4"><label class="form-label">Asset Tag</label><input class="form-control" name="asset_tag" placeholder="Auto-generated if blank"></div>
                <div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
                <div class="col-md-4"><label class="form-label">Serial Number</label><input class="form-control" name="serial_number"></div>
                @if($createType === 'equipment')
                    <div class="col-md-4"><label class="form-label">Equipment Type</label><input class="form-control" name="equipment_type"></div>
                    <div class="col-md-4"><label class="form-label">Manufacturer</label><input class="form-control" name="manufacturer"></div>
                    <div class="col-md-4"><label class="form-label">Model</label><input class="form-control" name="model"></div>
                @endif
            @endif
            <div class="col-md-4"><label class="form-label">Asset Type</label><select class="form-select" name="asset_type_public_id"><option value="">None</option>@foreach($assetTypes ?? [] as $t)@if(($t['applies_to'] ?? '') === $createType || ($t['applies_to'] ?? '') === 'all')<option value="{{ $t['public_id'] }}">{{ $t['name'] }}</option>@endif @endforeach</select></div>
            <div class="col-md-4"><label class="form-label">Category</label><select class="form-select" name="category_public_id"><option value="">None</option>@foreach($assetCategories ?? [] as $c)<option value="{{ $c['public_id'] }}">{{ $c['name'] }}</option>@endforeach</select></div>
            <div class="col-md-4"><label class="form-label">Condition</label><select class="form-select" name="condition_status"><option value="good" selected>Good</option><option value="fair">Fair</option><option value="poor">Poor</option><option value="damaged">Damaged</option><option value="lost">Lost</option><option value="non-functional">Non-functional</option></select></div>
            <div class="col-md-4"><label class="form-label">QR Token</label><input class="form-control" name="qr_token" placeholder="Auto-generated if blank"></div>
            <div class="col-md-4"><label class="form-label">Location</label><input class="form-control" name="location_name"></div>
            <div class="col-md-4"><label class="form-label">Acquired</label><input class="form-control" type="date" name="acquired_on"></div>
            <div class="col-md-4"><label class="form-label">Cost (minor units)</label><input class="form-control" type="number" min="0" name="acquisition_cost_minor"></div>
            <div class="col-md-4"><label class="form-label">Depreciation</label><select class="form-select" name="depreciation_method"><option value="none">None</option><option value="straight_line">Straight line</option></select></div>
            <div class="col-md-4"><label class="form-label">Useful Life Months</label><input class="form-control" type="number" min="1" name="useful_life_months"></div>
            <div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="2"></textarea></div>
            <div class="col-12"><button class="btn btn-primary">Create Asset</button></div>
        </form>
    </div>
</div>
@endif

@if($activeSection === 'asset-types')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Create Asset Type</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.asset-types.store') }}" class="row g-3">@csrf
<div class="col-md-5"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
<div class="col-md-3"><label class="form-label">Applies To</label><select class="form-select" name="applies_to"><option>tool</option><option selected>equipment</option><option>vehicle</option></select></div>
<div class="col-md-4"><label class="form-label">Description</label><input class="form-control" name="description"></div>
<div class="col-12"><button class="btn btn-primary">Create Type</button></div></form></div></div>
@endif

@if($activeSection === 'asset-categories')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Create Asset Category</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.asset-categories.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
<div class="col-md-3"><label class="form-label">Code</label><input class="form-control" name="code"></div>
<div class="col-md-3"><label class="form-label">Parent Category</label><select class="form-select" name="parent_public_id"><option value="">None</option>@foreach($assetCategories ?? [] as $c)<option value="{{ $c['public_id'] }}">{{ $c['name'] }}</option>@endforeach</select></div>
<div class="col-md-2"><label class="form-label">Active</label><select class="form-select" name="is_active"><option value="1" selected>Yes</option><option value="0">No</option></select></div>
<div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary">Create Category</button></div></form></div></div>
@endif

@if(in_array($activeSection, ['custody','history'], true))
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Issue Asset</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.history.issue') }}" class="row g-3">@csrf
<div class="col-md-5"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-3"><label class="form-label">Borrower User ID</label><input class="form-control" type="number" min="1" name="borrower_user_id"></div>
<div class="col-md-4"><label class="form-label">Due At</label><input class="form-control" type="datetime-local" name="due_at"></div>
<div class="col-12"><button class="btn btn-primary">Issue Asset</button></div></form></div></div>
@endif

@if($activeSection === 'allocations')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Allocate Asset</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.allocations.store') }}" class="row g-3">@csrf
<div class="col-md-5"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-3"><label class="form-label">Receiver User ID</label><input class="form-control" type="number" min="1" name="receiver_user_id"></div>
<div class="col-md-2"><label class="form-label">Quantity</label><input class="form-control" type="number" min="1" value="1" name="quantity"></div>
<div class="col-md-2"><label class="form-label">Until</label><input class="form-control" type="date" name="allocated_upto"></div>
<div class="col-12"><button class="btn btn-primary">Allocate</button></div></form></div></div>
@endif

@if($activeSection === 'repairs')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Open Repair</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.repairs.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-5"><label class="form-label">Summary</label><input class="form-control" name="summary" required></div>
<div class="col-md-3"><label class="form-label">Priority</label><select class="form-select" name="priority"><option>low</option><option selected>normal</option><option>high</option><option>urgent</option></select></div>
<div class="col-md-4"><label class="form-label">Assigned User ID</label><input class="form-control" type="number" name="assigned_to_user_id"></div>
<div class="col-md-4"><label class="form-label">Work Order</label><input class="form-control" name="work_order_public_id"></div>
<div class="col-md-4"><label class="form-label">Scheduled</label><input class="form-control" type="date" name="scheduled_for"></div>
<div class="col-md-4"><label class="form-label">Repair Template</label><select class="form-select" name="repair_template_public_id"><option value="">None</option>@foreach($repairTemplates ?? [] as $t)<option value="{{ $t['public_id'] }}">{{ $t['name'] }}</option>@endforeach</select></div>
<div class="col-md-4"><label class="form-label">Parts Cost</label><input class="form-control" type="number" min="0" name="parts_cost_minor"></div>
<div class="col-md-4"><label class="form-label">Labour Cost</label><input class="form-control" type="number" min="0" name="labour_cost_minor"></div>
<div class="col-md-6"><label class="form-label">Root Cause</label><textarea class="form-control" name="root_cause" rows="2"></textarea></div>
<div class="col-md-6"><label class="form-label">Parts Used</label><textarea class="form-control" name="parts_used" rows="2"></textarea></div>
<div class="col-12"><label class="form-label">Details</label><textarea class="form-control" name="details" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary">Open Repair</button></div></form></div></div>
@endif

@if($activeSection === 'repair-templates')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Create Repair Template</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.repair-templates.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
<div class="col-md-4"><label class="form-label">Equipment Category</label><input class="form-control" name="equipment_category"></div>
<div class="col-md-4"><label class="form-label">Estimated Hours</label><input class="form-control" type="number" step="0.25" min="0" name="estimated_hours"></div>
<div class="col-12"><label class="form-label">Standard Parts</label><textarea class="form-control" name="standard_parts" rows="2"></textarea></div>
<div class="col-12"><label class="form-label">Instructions</label><textarea class="form-control" name="instructions" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary">Create Template</button></div></form></div></div>
@endif

@if($activeSection === 'warranty-profiles')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Create Warranty Profile</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.warranty-profiles.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name" required></div>
<div class="col-md-3"><label class="form-label">Duration</label><input class="form-control" type="number" min="1" name="warranty_duration" required></div>
<div class="col-md-2"><label class="form-label">Unit</label><select class="form-select" name="warranty_type"><option>day</option><option>week</option><option selected>month</option><option>year</option></select></div>
<div class="col-md-3"><label class="form-label">Category</label><input class="form-control" name="equipment_category"></div>
<div class="col-12"><button class="btn btn-primary">Create Profile</button></div></form></div></div>
@endif

@if($activeSection === 'location-register')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Register Asset at Location</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.location-register.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Location Public ID</label><input class="form-control" name="location_public_id" required></div>
<div class="col-md-5"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-3"><label class="form-label">Notes</label><input class="form-control" name="notes"></div>
<div class="col-12"><button class="btn btn-primary">Register</button></div></form></div></div>
@endif

@if($activeSection === 'settings')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Asset Settings</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.settings.update') }}" class="row g-3">@csrf @method('PUT')
<div class="col-md-3"><label class="form-label">Asset Prefix</label><input class="form-control" name="asset_code_prefix" value="{{ $settings['asset_code_prefix'] ?? 'AST' }}"></div>
<div class="col-md-3"><label class="form-label">Allocation Prefix</label><input class="form-control" name="allocation_code_prefix" value="{{ $settings['allocation_code_prefix'] ?? 'ALLOC' }}"></div>
<div class="col-md-3"><label class="form-label">Revoke Prefix</label><input class="form-control" name="revoke_code_prefix" value="{{ $settings['revoke_code_prefix'] ?? 'REVOKE' }}"></div>
<div class="col-md-3"><label class="form-label">Maintenance Prefix</label><input class="form-control" name="maintenance_code_prefix" value="{{ $settings['maintenance_code_prefix'] ?? 'MAINT' }}"></div>
<div class="col-md-3"><label class="form-label">Sent for Maintenance Alerts</label><select class="form-select" name="notify_sent_for_maintenance"><option value="0" @selected(!($settings['notify_sent_for_maintenance'] ?? false))>Off</option><option value="1" @selected($settings['notify_sent_for_maintenance'] ?? false)>On</option></select></div>
<div class="col-md-3"><label class="form-label">Assignment Alerts</label><select class="form-select" name="notify_assigned_for_maintenance"><option value="0" @selected(!($settings['notify_assigned_for_maintenance'] ?? false))>Off</option><option value="1" @selected($settings['notify_assigned_for_maintenance'] ?? false)>On</option></select></div>
<div class="col-md-6"><label class="form-label">Maintenance Recipient User IDs</label><input class="form-control" name="maintenance_recipient_user_ids_csv" value="{{ implode(',', $settings['maintenance_recipient_user_ids'] ?? []) }}" placeholder="e.g. 4,8,12"><div class="form-hint">Company membership is revalidated before any email is sent.</div></div>
<div class="col-md-6"><label class="form-label">Sent Subject</label><input class="form-control" name="send_for_maintenance_subject" value="{{ $settings['send_for_maintenance_subject'] ?? 'Asset {asset_code} sent for maintenance' }}"></div>
<div class="col-12"><label class="form-label">Sent Body</label><textarea class="form-control" name="send_for_maintenance_body" rows="3">{{ $settings['send_for_maintenance_body'] ?? 'Asset {asset_code} has been sent for maintenance. Maintenance reference: {maintenance_id}. Status: {status}. Priority: {priority}. Details: {details}.' }}</textarea></div>
<div class="col-md-6"><label class="form-label">Assigned Subject</label><input class="form-control" name="assigned_for_maintenance_subject" value="{{ $settings['assigned_for_maintenance_subject'] ?? 'Asset {asset_code} assigned for maintenance' }}"></div>
<div class="col-12"><label class="form-label">Assigned Body</label><textarea class="form-control" name="assigned_for_maintenance_body" rows="3">{{ $settings['assigned_for_maintenance_body'] ?? 'Asset {asset_code} has been assigned for maintenance. Maintenance reference: {maintenance_id}. Status: {status}. Priority: {priority}. Details: {details}.' }}</textarea></div>
<div class="col-12"><button class="btn btn-primary">Save Settings</button></div></form></div></div>
@endif

@if($activeSection === 'maintenance')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Schedule Maintenance</h3></div><div class="card-body">
<form method="POST" id="maintenance-form" class="row g-3" onsubmit="this.action=this.dataset.base.replace('__TYPE__',this.subject_type.value).replace('__ASSET__',this.subject_public_id.value)" data-base="{{ url('dashboard/user/assets/assets/__TYPE__/__ASSET__/maintenance') }}">@csrf
<div class="col-md-4"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-3"><label class="form-label">Scheduled For</label><input class="form-control" type="date" name="scheduled_for" required></div>
<div class="col-md-3"><label class="form-label">Maintenance Type</label><input class="form-control" name="maintenance_type" value="service"></div>
<div class="col-md-2"><label class="form-label">Priority</label><select class="form-select" name="priority"><option>low</option><option selected>normal</option><option>high</option><option>urgent</option></select></div>
<div class="col-md-3"><label class="form-label">Assigned User ID</label><input class="form-control" type="number" min="1" name="assigned_to_user_id"></div>
<div class="col-md-3"><label class="form-label">Reference</label><input class="form-control" name="reference_no" placeholder="Auto-generated if blank"></div>
<div class="col-md-2"><label class="form-label">Cost</label><input class="form-control" type="number" min="0" name="cost_minor"></div>
<div class="col-md-4"><label class="form-label">Next Due Date</label><input class="form-control" type="date" name="next_due_on"></div>
<div class="col-md-4"><label class="form-label">Next Due Odometer</label><input class="form-control" type="number" min="0" name="next_due_odometer_km"></div>
<div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes" rows="2"></textarea></div>
<div class="col-12"><label class="form-label">Maintenance Note</label><textarea class="form-control" name="maintenance_note" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary">Schedule</button></div></form></div></div>
@endif

@if($activeSection === 'warranties')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Register Warranty</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.warranties.store') }}" class="row g-3">@csrf
<div class="col-md-4"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-4"><label class="form-label">Warranty Profile</label><select class="form-select" name="profile_public_id"><option value="">Custom</option>@foreach($warrantyProfiles ?? [] as $p)<option value="{{ $p['public_id'] }}">{{ $p['name'] }}</option>@endforeach</select></div>
<div class="col-md-4"><label class="form-label">Provider / Supplier</label><input class="form-control" name="provider_name"></div>
<div class="col-md-3"><label class="form-label">Warranty Number</label><input class="form-control" name="warranty_number"></div>
<div class="col-md-3"><label class="form-label">Starts</label><input class="form-control" type="date" name="starts_on"></div>
<div class="col-md-3"><label class="form-label">Expires</label><input class="form-control" type="date" name="expires_on"></div>
<div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status"><option selected>active</option><option>claimed</option><option>expired</option><option>void</option></select></div>
<div class="col-md-4"><label class="form-label">Additional Cost</label><input class="form-control" type="number" min="0" name="additional_cost_minor"></div>
<div class="col-md-4"><label class="form-label">Claim Reference</label><input class="form-control" name="claim_reference"></div>
<div class="col-md-4"><label class="form-label">Claimed At</label><input class="form-control" type="date" name="claimed_at"></div>
<div class="col-12"><label class="form-label">Coverage / Notes</label><textarea class="form-control" name="coverage_notes" rows="2"></textarea></div>
<div class="col-12"><button class="btn btn-primary">Register Warranty</button></div></form></div></div>
@endif

@if($activeSection === 'mileage')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Log Mileage</h3></div><div class="card-body">
<form method="POST" id="mileage-form" class="row g-3" onsubmit="this.action=this.dataset.base.replace('__VEHICLE__',this.vehicle_public_id.value)" data-base="{{ url('dashboard/user/assets/fleet/__VEHICLE__/mileage') }}">@csrf
<div class="col-md-4"><label class="form-label">Vehicle</label><select class="form-select" name="vehicle_public_id" required><option value="">Select vehicle</option>@foreach($vehicles ?? [] as $v)<option value="{{ $v['public_id'] }}">{{ $v['registration'] ?? $v['name'] ?? $v['public_id'] }}</option>@endforeach</select></div>
<div class="col-md-2"><label class="form-label">Start Odometer</label><input class="form-control" type="number" min="0" name="odometer_start"></div>
<div class="col-md-2"><label class="form-label">End Odometer</label><input class="form-control" type="number" min="0" name="odometer_end" required></div>
<div class="col-md-2"><label class="form-label">KM Driven</label><input class="form-control" type="number" min="0" name="km_driven"></div>
<div class="col-md-2"><label class="form-label">Occurred</label><input class="form-control" type="date" name="occurred_at"></div>
<div class="col-md-6"><label class="form-label">Purpose</label><input class="form-control" name="purpose"></div>
<div class="col-md-6"><label class="form-label">Work Order</label><input class="form-control" name="work_order_public_id"></div>
<div class="col-12"><button class="btn btn-primary">Log Mileage</button></div></form></div></div>
@endif

@if($activeSection === 'equipment-checks')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Equipment Check In / Out</h3></div><div class="card-body">
<form method="POST" id="equipment-check-form" class="row g-3" onsubmit="this.action=this.dataset.base.replace('__REGISTER__',this.register_public_id.value)" data-base="{{ url('dashboard/user/assets/equipment-checks/__REGISTER__') }}">@csrf
<div class="col-md-4"><label class="form-label">Location Register Entry</label><select class="form-select" name="register_public_id" required><option value="">Select entry</option>@foreach($locationRegisters ?? [] as $r)<option value="{{ $r['public_id'] }}">{{ $r['location_public_id'] }} — {{ $r['subject_type'] }} / {{ $r['subject_public_id'] }}</option>@endforeach</select></div>
<div class="col-md-3"><label class="form-label">Event</label><select class="form-select" name="event_type"><option value="check_out">Check Out</option><option value="check_in">Check In</option></select></div>
<div class="col-md-3"><label class="form-label">Work Order</label><input class="form-control" name="work_order_public_id"></div>
<div class="col-md-2"><label class="form-label">Checked At</label><input class="form-control" type="datetime-local" name="checked_at"></div>
<div class="col-12"><label class="form-label">Notes</label><input class="form-control" name="notes"></div>
<div class="col-12"><button class="btn btn-primary">Record Check</button></div></form></div></div>
@endif

@if($activeSection === 'premises')
<div class="card mb-5"><div class="card-header"><h3 class="card-title">Link Asset to Premises</h3></div><div class="card-body">
<form method="POST" action="{{ route('titan-assets.premises.store') }}" class="row g-3">@csrf
<div class="col-md-5"><label class="form-label">Asset</label><select class="form-select" name="subject_public_id" required onchange="this.form.subject_type.value=this.options[this.selectedIndex].dataset.type"><option value="">Select asset</option>@foreach($assetOptions as $a)<option value="{{ $a['id'] }}" data-type="{{ $a['type'] }}">{{ ucfirst($a['type']) }} — {{ $a['label'] }}</option>@endforeach</select><input type="hidden" name="subject_type"></div>
<div class="col-md-4"><label class="form-label">Premises Public ID</label><input class="form-control" name="premise_public_id" required></div>
<div class="col-md-3"><label class="form-label">Relationship</label><input class="form-control" name="relationship" value="located_at"></div>
<div class="col-12"><label class="form-label">Notes</label><input class="form-control" name="notes"></div>
<div class="col-12"><button class="btn btn-primary">Link Premises</button></div></form></div></div>
@endif
