@extends('panel.layout.app')
@section('title', 'Assets')

@section('content')
@php
    $navigation = collect(config('titan-assets-navigation.items', []));
    $title = $navigation->firstWhere('route', request()->route()?->getName())['label'] ?? 'Assets';
    $assetRows = collect($tools ?? [])->map(fn($r)=>$r+['subject_type'=>'tool'])
        ->concat(collect($equipment ?? [])->map(fn($r)=>$r+['subject_type'=>'equipment']))
        ->concat(collect($vehicles ?? [])->map(fn($r)=>$r+['subject_type'=>'vehicle']))->values();
@endphp
<div class="container-xl py-5">
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-5">
        <div>
            <h1 class="page-title mb-1">Assets</h1>
            <div class="text-muted">Tools, equipment, fleet, custody, maintenance, repairs, warranties and lifecycle intelligence.</div>
        </div>
        <a class="btn btn-primary" href="{{ route('titan-assets.scan') }}">QR / Scan</a>
    </div>

    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger"><strong>Unable to save.</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif

    <div class="row g-3 mb-5">
        @foreach([
            ['Tools',$metrics['tools'] ?? 0],['Equipment',$metrics['equipment'] ?? 0],['Vehicles',$metrics['vehicles'] ?? 0],
            ['Maintenance Due',$metrics['maintenance_due'] ?? 0],['Open Repairs',$metrics['open_repairs'] ?? 0],['Active Allocations',$metrics['active_allocations'] ?? 0]
        ] as [$label,$value])
        <div class="col-6 col-md-4 col-xl-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">{{ $label }}</div><div class="h2 mb-0">{{ $value }}</div></div></div></div>
        @endforeach
    </div>

    <div class="card mb-5"><div class="card-body py-2"><div class="d-flex flex-wrap gap-2">
        @foreach($navigation as $item)
            <a href="{{ route($item['route']) }}" class="btn btn-sm {{ request()->routeIs($item['route']) ? 'btn-primary' : 'btn-outline-secondary' }}">{{ $item['label'] }}</a>
        @endforeach
    </div></div></div>

    <div class="d-flex align-items-center justify-content-between mb-3"><h2 class="h3 mb-0">{{ $title }}</h2><span class="badge bg-blue-lt">Authoritative Asset Domain</span></div>

    @include('titan-assets::assets.forms')

    @if($activeSection === 'overview')
        <div class="row g-4 mb-5">
            <div class="col-lg-6"><div class="card h-100"><div class="card-header"><h3 class="card-title">Upcoming Maintenance</h3></div><div class="card-body">@forelse($maintenanceDue as $row)<div class="d-flex justify-content-between border-bottom py-2"><span>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</span><span class="text-muted">{{ $row['scheduled_for'] ?? '' }}</span></div>@empty<div class="text-muted">Nothing due in the next 30 days.</div>@endforelse</div></div></div>
            <div class="col-lg-6"><div class="card h-100"><div class="card-header"><h3 class="card-title">Fleet Alerts</h3></div><div class="card-body">@forelse($fleetAlerts as $row)<div class="d-flex justify-content-between border-bottom py-2"><span>{{ $row['registration'] ?? $row['name'] ?? 'Vehicle' }}</span><span class="text-muted">{{ $row['next_service_on'] ?? $row['registration_expires_on'] ?? 'Attention' }}</span></div>@empty<div class="text-muted">No fleet alerts.</div>@endforelse</div></div></div>
        </div>
        @include('titan-assets::assets.reports')
    @endif

    @if(in_array($activeSection, ['register','tools','equipment','fleet'], true))
        @php
            $rows = $activeSection === 'tools' ? collect($tools) : ($activeSection === 'equipment' ? collect($equipment) : ($activeSection === 'fleet' ? collect($vehicles) : $assetRows));
        @endphp
        <div class="card"><div class="table-responsive"><table class="table card-table table-vcenter"><thead><tr><th>Type</th><th>Asset</th><th>Identifier</th><th>Status</th><th>Location</th><th>Value</th><th></th></tr></thead><tbody>
        @forelse($rows as $row)<tr><td>{{ ucfirst($row['subject_type'] ?? ($activeSection === 'fleet' ? 'vehicle' : rtrim($activeSection,'s'))) }}</td><td><strong>{{ $row['name'] ?? trim(($row['make'] ?? '').' '.($row['model'] ?? '')) }}</strong><div class="text-muted small">{{ $row['serial_number'] ?? $row['vin'] ?? '' }}</div></td><td>{{ $row['asset_tag'] ?? $row['registration'] ?? '' }}</td><td><span class="badge bg-secondary-lt">{{ $row['status'] ?? '' }}</span></td><td>{{ $row['location_name'] ?? $row['location_public_id'] ?? '' }}</td><td>{{ $row['current_value_minor'] ?? '' }}</td><td>@if(!empty($row['public_id']))<a class="btn btn-sm btn-outline-primary" href="{{ route('titan-assets.assets.show',['type'=>$row['subject_type'] ?? ($activeSection === 'fleet' ? 'vehicle' : rtrim($activeSection,'s')),'asset'=>$row['public_id']]) }}">Open</a>@endif</td></tr>@empty<tr><td colspan="7" class="text-muted">No assets.</td></tr>@endforelse
        </tbody></table></div></div>
    @endif

    @if($activeSection === 'asset-types')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Name</th><th>Applies To</th><th>Description</th><th>Active</th></tr></thead><tbody>@forelse($assetTypes as $row)<tr><td>{{ $row['name'] ?? '' }}</td><td>{{ $row['applies_to'] ?? '' }}</td><td>{{ $row['description'] ?? '' }}</td><td>{{ !empty($row['active']) ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No asset types.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'asset-categories')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Name</th><th>Code</th><th>Parent</th><th>Description</th><th>Active</th></tr></thead><tbody>@forelse($assetCategories as $row)<tr><td>{{ $row['name'] ?? '' }}</td><td>{{ $row['code'] ?? '' }}</td><td>{{ $row['parent_public_id'] ?? '' }}</td><td>{{ $row['description'] ?? '' }}</td><td>{{ !empty($row['is_active'] ?? $row['active'] ?? true) ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="5" class="text-muted">No asset categories.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'customer-assets')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Customer</th><th>Type</th><th>Asset</th><th>Status</th></tr></thead><tbody>@forelse($customerAssets as $row)<tr><td>{{ $row['customer_public_id'] ?? '' }}</td><td>{{ ucfirst($row['subject_type'] ?? '') }}</td><td>{{ $row['name'] ?? $row['asset_tag'] ?? $row['registration'] ?? '' }}</td><td>{{ $row['status'] ?? '' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No customer-owned assets.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if(in_array($activeSection, ['custody','history'], true))
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Asset</th><th>Borrower</th><th>Issued</th><th>Due</th><th>Returned</th><th></th></tr></thead><tbody>@forelse($lendingHistory as $row)<tr><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['borrower_user_id'] ?? '' }}</td><td>{{ $row['issued_at'] ?? '' }}</td><td>{{ $row['due_at'] ?? '' }}</td><td>{{ $row['returned_at'] ?? 'Open' }}</td><td>@if(empty($row['returned_at']))<form method="POST" action="{{ route('titan-assets.history.return',$row['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-primary">Return</button></form>@endif</td></tr>@empty<tr><td colspan="6" class="text-muted">No custody history.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'allocations')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Reference</th><th>Asset</th><th>Receiver</th><th>Quantity</th><th>Status</th><th>Until</th><th></th></tr></thead><tbody>@forelse($allocations as $row)<tr><td>{{ $row['ref_no'] ?? '' }}</td><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['receiver_user_id'] ?? '' }}</td><td>{{ $row['quantity'] ?? 1 }}</td><td>{{ $row['status'] ?? '' }}</td><td>{{ $row['allocated_upto'] ?? '' }}</td><td>@if(in_array($row['status'] ?? '',['active','partially_revoked'],true))<form method="POST" action="{{ route('titan-assets.allocations.revoke',$row['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-danger">Revoke</button></form>@endif</td></tr>@empty<tr><td colspan="7" class="text-muted">No allocations.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'maintenance')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Reference</th><th>Asset</th><th>Type</th><th>Priority</th><th>Assigned</th><th>Status</th><th>Scheduled</th><th>Cost</th><th></th></tr></thead><tbody>@forelse($maintenance as $row)<tr><td>{{ $row['reference_no'] ?? $row['public_id'] ?? '' }}</td><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['maintenance_type'] ?? '' }}</td><td>{{ $row['priority'] ?? 'normal' }}</td><td>{{ $row['assigned_to_user_id'] ?? '' }}</td><td>{{ $row['status'] ?? '' }}</td><td>{{ $row['scheduled_for'] ?? '' }}</td><td>{{ $row['cost_minor'] ?? '' }}</td><td>@if(!in_array($row['status'] ?? '',['completed','cancelled'],true))<form method="POST" action="{{ route('titan-assets.maintenance.complete',$row['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-primary">Complete</button></form>@endif</td></tr>@empty<tr><td colspan="9" class="text-muted">No maintenance records.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'repairs')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Asset</th><th>Summary</th><th>Priority</th><th>Status</th><th>Assigned</th><th>Parts</th><th>Labour</th><th>Total</th><th>Warranty</th><th>Reported</th></tr></thead><tbody>@forelse($repairs as $row)<tr><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['summary'] ?? '' }}@if(!empty($row['root_cause']))<div class="text-muted small">{{ $row['root_cause'] }}</div>@endif</td><td>{{ $row['priority'] ?? '' }}</td><td>{{ $row['status'] ?? '' }}</td><td>{{ $row['assigned_to_user_id'] ?? '' }}</td><td>{{ $row['parts_cost_minor'] ?? 0 }}</td><td>{{ $row['labour_cost_minor'] ?? 0 }}</td><td>{{ $row['computed_total_cost_minor'] ?? $row['actual_cost_minor'] ?? 0 }}</td><td>{{ !empty($row['under_warranty']) ? 'Yes' : 'No' }}</td><td>{{ $row['reported_at'] ?? '' }}</td></tr>@empty<tr><td colspan="10" class="text-muted">No repairs.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'repair-templates')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Name</th><th>Category</th><th>Type</th><th>Hours</th><th>Standard Parts</th><th>Active</th></tr></thead><tbody>@forelse($repairTemplates as $row)<tr><td>{{ $row['name'] ?? '' }}</td><td>{{ $row['equipment_category'] ?? '' }}</td><td>{{ $row['repair_type'] ?? '' }}</td><td>{{ $row['estimated_hours'] ?? '' }}</td><td>{{ $row['standard_parts'] ?? '' }}</td><td>{{ !empty($row['active']) ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="6" class="text-muted">No repair templates.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'downtime')
        @include('titan-assets::assets.reports')
    @endif

    @if($activeSection === 'warranties')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Asset</th><th>Provider</th><th>Number</th><th>Starts</th><th>Expires</th><th>Status</th><th>Claim</th><th>Additional Cost</th></tr></thead><tbody>@forelse($warranties as $row)<tr><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['provider_name'] ?? $row['supplier_name'] ?? '' }}</td><td>{{ $row['warranty_number'] ?? $row['policy_number'] ?? '' }}</td><td>{{ $row['starts_on'] ?? '' }}</td><td>{{ $row['expires_on'] ?? '' }}</td><td>{{ $row['computed_status'] ?? $row['status'] ?? '' }}</td><td>{{ $row['claim_reference'] ?? '' }}</td><td>{{ $row['additional_cost_minor'] ?? 0 }}</td></tr>@empty<tr><td colspan="8" class="text-muted">No warranties.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'warranty-profiles')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Name</th><th>Category</th><th>Duration</th><th>Unit</th><th>Active</th></tr></thead><tbody>@forelse($warrantyProfiles as $row)<tr><td>{{ $row['name'] ?? '' }}</td><td>{{ $row['equipment_category'] ?? '' }}</td><td>{{ $row['warranty_duration'] ?? '' }}</td><td>{{ $row['warranty_type'] ?? '' }}</td><td>{{ !empty($row['active']) ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="5" class="text-muted">No warranty profiles.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'mileage')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Vehicle</th><th>Start</th><th>End</th><th>KM</th><th>Purpose</th><th>Work Order</th><th>Date</th></tr></thead><tbody>@forelse($mileageLogs as $row)<tr><td>{{ $row['vehicle_public_id'] ?? '' }}</td><td>{{ $row['odometer_start'] ?? '' }}</td><td>{{ $row['odometer_end'] ?? $row['odometer_km'] ?? '' }}</td><td>{{ $row['km_driven'] ?? $row['distance_km'] ?? '' }}</td><td>{{ $row['purpose'] ?? '' }}</td><td>{{ $row['work_order_public_id'] ?? '' }}</td><td>{{ $row['occurred_at'] ?? '' }}</td></tr>@empty<tr><td colspan="7" class="text-muted">No mileage logs.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'location-register')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Location</th><th>Asset</th><th>Type</th><th>Active</th><th>Notes</th></tr></thead><tbody>@forelse($locationRegisters as $row)<tr><td>{{ $row['location_public_id'] ?? '' }}</td><td>{{ $row['subject_public_id'] ?? '' }}</td><td>{{ ucfirst($row['subject_type'] ?? '') }}</td><td>{{ !empty($row['active']) ? 'Yes' : 'No' }}</td><td>{{ $row['notes'] ?? '' }}</td></tr>@empty<tr><td colspan="5" class="text-muted">No location register entries.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'equipment-checks')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Register</th><th>Event</th><th>Work Order</th><th>User</th><th>Checked</th><th>Notes</th></tr></thead><tbody>@forelse($equipmentChecks as $row)<tr><td>{{ $row['register_public_id'] ?? '' }}</td><td>{{ str_replace('_',' ',ucfirst($row['event_type'] ?? '')) }}</td><td>{{ $row['work_order_public_id'] ?? '' }}</td><td>{{ $row['checked_by_user_id'] ?? '' }}</td><td>{{ $row['checked_at'] ?? '' }}</td><td>{{ $row['notes'] ?? '' }}</td></tr>@empty<tr><td colspan="6" class="text-muted">No equipment checks.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if($activeSection === 'premises')
        <div class="card"><div class="table-responsive"><table class="table card-table"><thead><tr><th>Asset</th><th>Premises</th><th>Relationship</th><th>Notes</th></tr></thead><tbody>@forelse($premisesLinks as $row)<tr><td>{{ ucfirst($row['subject_type'] ?? '') }} · {{ $row['subject_public_id'] ?? '' }}</td><td>{{ $row['premise_public_id'] ?? '' }}</td><td>{{ $row['relationship'] ?? '' }}</td><td>{{ $row['notes'] ?? '' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No premises links.</td></tr>@endforelse</tbody></table></div></div>
    @endif

    @if(in_array($activeSection, ['lifecycle','reports'], true))
        @include('titan-assets::assets.reports')
    @endif

    @if($activeSection === 'scan')
        <div class="card mb-4"><div class="card-body"><form method="GET" action="{{ route('titan-assets.scan') }}" class="d-flex gap-2"><input class="form-control" name="q" value="{{ $scanQuery }}" placeholder="Scan or enter asset tag, registration, VIN, serial or public ID" autofocus><button class="btn btn-primary">Find Asset</button></form></div></div>
        @if($scanQuery !== '')
            @if($scanResult)
                @php $scanned = $scanResult['asset']; $stype = $scanResult['subject_type']; @endphp
                <div class="card"><div class="card-header"><h3 class="card-title">{{ $scanned['name'] ?? $scanned['asset_tag'] ?? $scanned['registration'] ?? 'Asset' }}</h3></div><div class="card-body">
<div class="row g-3 mb-4"><div class="col-md-3"><span class="text-muted">Type</span><div>{{ ucfirst($stype) }}</div></div><div class="col-md-3"><span class="text-muted">Status</span><div>{{ $scanned['status'] ?? '' }}</div></div><div class="col-md-3"><span class="text-muted">Location</span><div>{{ $scanned['location_name'] ?? $scanned['location_public_id'] ?? '' }}</div></div><div class="col-md-3"><a class="btn btn-outline-primary" href="{{ route('titan-assets.assets.show',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">Open Full Record</a></div></div>
<div class="d-flex flex-wrap gap-2">
<form method="POST" action="{{ route('titan-assets.scan.issue',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<input type="hidden" name="issued_to_user_id" value="{{ auth()->id() }}"><button class="btn btn-sm btn-outline-primary">Issue</button></form>
<form method="POST" action="{{ route('titan-assets.scan.return',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<button class="btn btn-sm btn-outline-primary">Return</button></form>
<form method="POST" action="{{ route('titan-assets.scan.report',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<input type="hidden" name="status" value="damaged"><button class="btn btn-sm btn-outline-danger">Report Damage</button></form>
<form method="POST" action="{{ route('titan-assets.scan.maintenance',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<input type="hidden" name="reason" value="Sent to maintenance from QR / Scan"><button class="btn btn-sm btn-outline-warning">Send to Maintenance</button></form>
<form method="POST" action="{{ route('titan-assets.scan.maintenance.complete',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<button class="btn btn-sm btn-outline-success">Complete Maintenance</button></form>
<form method="POST" action="{{ route('titan-assets.scan.allocate',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<input type="hidden" name="allocated_to_user_id" value="{{ auth()->id() }}"><button class="btn btn-sm btn-outline-primary">Allocate</button></form>
<form method="POST" action="{{ route('titan-assets.scan.revoke',['type'=>$stype,'asset'=>$scanned['public_id']]) }}">@csrf<button class="btn btn-sm btn-outline-secondary">Revoke</button></form>
</div></div></div>
            @else
                <div class="alert alert-warning">No asset matched that scan value.</div>
            @endif
        @endif
    @endif

    @if($activeSection === 'settings')
        <div class="card"><div class="card-body text-muted">Settings are company-scoped. Prefixes and maintenance notification preferences are stored by company and repaired automatically on upgrade.</div></div>
    @endif
</div>
@endsection
