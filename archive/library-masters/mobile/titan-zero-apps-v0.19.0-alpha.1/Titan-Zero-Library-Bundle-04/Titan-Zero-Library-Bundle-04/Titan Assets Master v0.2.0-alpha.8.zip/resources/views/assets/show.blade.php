@extends('panel.layout.app')
@section('title', 'Asset Details')
@section('content')
<div class="container-xl py-5">
    <div class="d-flex align-items-start justify-content-between mb-4">
        <div><h1 class="page-title mb-1">{{ $row['name'] ?? $row['asset_tag'] ?? $row['registration'] ?? 'Asset' }}</h1><div class="text-muted">{{ ucfirst($type) }} · {{ $row['public_id'] ?? '' }}</div></div>
        <a href="{{ route('titan-assets.register') }}" class="btn btn-outline-secondary">Back to Assets</a>
    </div>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card mb-4"><div class="card-header"><h3 class="card-title">Asset Details</h3></div><div class="card-body"><dl class="row mb-0">@foreach($row as $key=>$value)@if(!in_array($key,['metadata'],true))<dt class="col-sm-4 text-muted">{{ ucwords(str_replace('_',' ',$key)) }}</dt><dd class="col-sm-8">{{ is_scalar($value) || $value === null ? $value : json_encode($value) }}</dd>@endif @endforeach</dl></div></div>
            <div class="card"><div class="card-header"><h3 class="card-title">Edit Asset</h3></div><div class="card-body">
                <form method="POST" action="{{ route('titan-assets.assets.update',['type'=>$type,'asset'=>$row['public_id']]) }}" class="row g-3">@csrf @method('PATCH')
                    <div class="col-md-6"><label class="form-label">Name</label><input class="form-control" name="name" value="{{ $row['name'] ?? '' }}"></div>
                    @if($type === 'vehicle')<div class="col-md-6"><label class="form-label">Registration</label><input class="form-control" name="registration" value="{{ $row['registration'] ?? '' }}"></div>@else<div class="col-md-6"><label class="form-label">Asset Tag</label><input class="form-control" name="asset_tag" value="{{ $row['asset_tag'] ?? '' }}"></div>@endif
                    <div class="col-md-4"><label class="form-label">Status</label><input class="form-control" name="status" value="{{ $row['status'] ?? '' }}"></div>
                    <div class="col-md-4"><label class="form-label">Condition</label><input class="form-control" name="condition_status" value="{{ $row['condition_status'] ?? '' }}"></div>
                    <div class="col-md-4"><label class="form-label">Location</label><input class="form-control" name="location_name" value="{{ $row['location_name'] ?? '' }}"></div>
                    <div class="col-md-6"><label class="form-label">QR Token</label><input class="form-control" name="qr_token" value="{{ $row['qr_token'] ?? '' }}"></div>
                    <div class="col-md-6"><label class="form-label">Current Value</label><input class="form-control" type="number" min="0" name="current_value_minor" value="{{ $row['current_value_minor'] ?? '' }}"></div>
                    <div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="3">{{ $row['description'] ?? '' }}</textarea></div>
                    <div class="col-12"><button class="btn btn-primary">Save Asset</button></div>
                </form>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card mb-4"><div class="card-header"><h3 class="card-title">Asset Image</h3></div><div class="card-body">
                @if(!empty($row['image_path']))<div class="text-muted small mb-2">Stored image: {{ $row['image_path'] }}</div><form method="POST" action="{{ route('titan-assets.assets.image.destroy',['type'=>$type,'asset'=>$row['public_id']]) }}" class="mb-3">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Remove Image</button></form>@endif
                <form method="POST" enctype="multipart/form-data" action="{{ route('titan-assets.assets.image.store',['type'=>$type,'asset'=>$row['public_id']]) }}">@csrf<input class="form-control mb-2" type="file" accept="image/*" name="image" required><button class="btn btn-primary">Upload Image</button></form>
            </div></div>
            <div class="card mb-4"><div class="card-header"><h3 class="card-title">Documents</h3></div><div class="card-body">
                <form method="POST" enctype="multipart/form-data" action="{{ route('titan-assets.documents.store',['type'=>$type,'asset'=>$row['public_id']]) }}" class="mb-3">@csrf<input class="form-control mb-2" type="file" name="file" required><button class="btn btn-primary">Upload</button></form>
                @forelse($docs as $doc)<div class="d-flex justify-content-between border-top py-2"><span>{{ $doc['name'] ?? 'Document' }}</span><form method="POST" action="{{ route('titan-assets.documents.destroy',$doc['public_id']) }}">@csrf @method('DELETE')<button class="btn btn-sm btn-outline-danger">Delete</button></form></div>@empty<div class="text-muted">No documents.</div>@endforelse
            </div></div>
            <div class="card"><div class="card-header"><h3 class="card-title">Lifecycle Actions</h3></div><div class="card-body d-grid gap-3">
                <form method="POST" action="{{ route('titan-assets.assets.retire',['type'=>$type,'asset'=>$row['public_id']]) }}">@csrf<div class="input-group"><input type="date" class="form-control" name="retired_on"><button class="btn btn-outline-secondary">Retire</button></div></form>
                <form method="POST" action="{{ route('titan-assets.assets.write-off',['type'=>$type,'asset'=>$row['public_id']]) }}">@csrf<input class="form-control mb-2" name="written_off_reason" placeholder="Write-off reason"><button class="btn btn-outline-warning w-100">Write Off</button></form>
                <form method="POST" action="{{ route('titan-assets.assets.sell',['type'=>$type,'asset'=>$row['public_id']]) }}">@csrf<div class="input-group"><input type="number" min="0" class="form-control" name="value_minor" placeholder="Sale value"><button class="btn btn-outline-primary">Mark Sold</button></div></form>
                <form method="POST" action="{{ route('titan-assets.assets.destroy',['type'=>$type,'asset'=>$row['public_id']]) }}" onsubmit="return confirm('Remove this asset from active records? Historical events are preserved.');">@csrf @method('DELETE')<button class="btn btn-outline-danger w-100">Remove Asset</button></form>
            </div></div>
        </div>
    </div>
    <div class="card mt-4"><div class="card-header"><h3 class="card-title">Lifecycle Timeline</h3></div><div class="table-responsive"><table class="table card-table"><thead><tr><th>Time</th><th>Event</th><th>Actor</th><th>Location</th></tr></thead><tbody>@forelse($timeline as $event)<tr><td>{{ $event['occurred_at'] ?? '' }}</td><td>{{ $event['event_type'] ?? '' }}</td><td>{{ $event['actor_user_id'] ?? '' }}</td><td>{{ $event['location_public_id'] ?? '' }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No lifecycle events.</td></tr>@endforelse</tbody></table></div></div>
</div>
@endsection
