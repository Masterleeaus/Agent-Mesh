<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if(!Schema::hasTable('crm_locker_tools')) Schema::create('crm_locker_tools',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->char('inventory_item_public_id',26)->nullable()->index();$t->string('asset_tag',100);$t->string('name',180);$t->string('serial_number',160)->nullable()->index();$t->string('status',40)->default('available')->index();$t->unsignedBigInteger('custodian_user_id')->nullable()->index();$t->char('location_public_id',26)->nullable()->index();$t->date('acquired_on')->nullable();$t->bigInteger('acquisition_cost_minor')->nullable();$t->bigInteger('current_value_minor')->nullable();$t->date('warranty_expires_on')->nullable()->index();$t->date('retired_on')->nullable();$t->json('metadata')->nullable();$t->softDeletes();$t->timestamps();$t->dateTime('due_back_at')->nullable()->index();$t->dateTime('checked_out_at')->nullable()->index();$t->unique(['company_id','asset_tag'],'crm_locker_tool_asset_tag_unique');
        });
        if(!Schema::hasTable('crm_locker_equipment')) Schema::create('crm_locker_equipment',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('asset_tag',100);$t->string('equipment_type',100)->nullable()->index();$t->string('name',180);$t->string('manufacturer',120)->nullable();$t->string('model',120)->nullable();$t->string('serial_number',160)->nullable()->index();$t->string('status',40)->default('active')->index();$t->unsignedBigInteger('assigned_user_id')->nullable()->index();$t->char('location_public_id',26)->nullable()->index();$t->date('acquired_on')->nullable();$t->bigInteger('acquisition_cost_minor')->nullable();$t->bigInteger('current_value_minor')->nullable();$t->string('depreciation_method',40)->default('none');$t->unsignedInteger('useful_life_months')->nullable();$t->bigInteger('salvage_value_minor')->nullable();$t->date('warranty_expires_on')->nullable()->index();$t->date('next_service_on')->nullable()->index();$t->date('retired_on')->nullable();$t->date('sold_on')->nullable();$t->json('metadata')->nullable();$t->softDeletes();$t->timestamps();$t->unique(['company_id','asset_tag'],'crm_locker_equipment_asset_tag_unique');
        });
        if(!Schema::hasTable('crm_locker_fleet_vehicles')) Schema::create('crm_locker_fleet_vehicles',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('registration',40);$t->string('vin',80)->nullable()->index();$t->string('make',100)->nullable();$t->string('model',100)->nullable();$t->unsignedSmallInteger('year')->nullable();$t->string('status',40)->default('active')->index();$t->unsignedBigInteger('assigned_user_id')->nullable()->index();$t->unsignedBigInteger('odometer_km')->nullable();$t->date('acquired_on')->nullable();$t->bigInteger('acquisition_cost_minor')->nullable();$t->bigInteger('current_value_minor')->nullable();$t->string('depreciation_method',40)->default('none');$t->unsignedInteger('useful_life_months')->nullable();$t->bigInteger('salvage_value_minor')->nullable();$t->date('registration_expires_on')->nullable()->index();$t->date('warranty_expires_on')->nullable()->index();$t->date('next_service_on')->nullable()->index();$t->date('retired_on')->nullable();$t->date('sold_on')->nullable();$t->json('metadata')->nullable();$t->softDeletes();$t->timestamps();$t->dateTime('assigned_at')->nullable()->index();$t->dateTime('last_odometer_at')->nullable()->index();$t->unsignedBigInteger('next_service_odometer_km')->nullable()->index();$t->unique(['company_id','registration'],'crm_locker_vehicle_registration_unique');
        });
        if(!Schema::hasTable('crm_locker_maintenance_records')) Schema::create('crm_locker_maintenance_records',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('subject_type',40)->index();$t->char('subject_public_id',26)->index();$t->string('maintenance_type',80)->default('service')->index();$t->string('status',40)->default('scheduled')->index();$t->date('scheduled_for')->nullable()->index();$t->date('completed_on')->nullable()->index();$t->unsignedBigInteger('odometer_km')->nullable();$t->bigInteger('cost_minor')->nullable();$t->char('currency',3)->default('AUD');$t->char('supplier_public_id',26)->nullable()->index();$t->text('notes')->nullable();$t->json('metadata')->nullable();$t->unsignedBigInteger('created_by_user_id')->nullable()->index();$t->timestamps();$t->date('next_due_on')->nullable()->index();$t->unsignedBigInteger('next_due_odometer_km')->nullable()->index();$t->dateTime('cancelled_at')->nullable()->index();$t->string('cancel_reason',255)->nullable();$t->index(['company_id','subject_type','subject_public_id'],'crm_locker_maintenance_subject');
        });
        if(!Schema::hasTable('crm_locker_asset_events')) Schema::create('crm_locker_asset_events',function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('subject_type',40)->index();$t->char('subject_public_id',26)->index();$t->string('event_type',60)->index();$t->dateTime('occurred_at')->index();$t->unsignedBigInteger('actor_user_id')->nullable()->index();$t->char('location_public_id',26)->nullable()->index();$t->bigInteger('value_minor')->nullable();$t->json('metadata')->nullable();$t->timestamps();$t->index(['company_id','subject_type','subject_public_id','occurred_at'],'crm_locker_asset_event_timeline');
        });
        $this->addMissingColumns();
    }
    private function addMissingColumns():void
    {
        $columns=[
            'crm_locker_tools'=>['due_back_at'=>fn(Blueprint $t)=>$t->dateTime('due_back_at')->nullable()->index(),'checked_out_at'=>fn(Blueprint $t)=>$t->dateTime('checked_out_at')->nullable()->index()],
            'crm_locker_fleet_vehicles'=>['assigned_at'=>fn(Blueprint $t)=>$t->dateTime('assigned_at')->nullable()->index(),'last_odometer_at'=>fn(Blueprint $t)=>$t->dateTime('last_odometer_at')->nullable()->index(),'next_service_odometer_km'=>fn(Blueprint $t)=>$t->unsignedBigInteger('next_service_odometer_km')->nullable()->index()],
            'crm_locker_maintenance_records'=>['next_due_on'=>fn(Blueprint $t)=>$t->date('next_due_on')->nullable()->index(),'next_due_odometer_km'=>fn(Blueprint $t)=>$t->unsignedBigInteger('next_due_odometer_km')->nullable()->index(),'cancelled_at'=>fn(Blueprint $t)=>$t->dateTime('cancelled_at')->nullable()->index(),'cancel_reason'=>fn(Blueprint $t)=>$t->string('cancel_reason',255)->nullable()],
        ];
        foreach($columns as$table=>$defs){if(!Schema::hasTable($table))continue;foreach($defs as$column=>$add){if(!Schema::hasColumn($table,$column))Schema::table($table,$add);}}
    }
    public function down():void{/* Existing and migrated asset data is intentionally preserved. */}
};
