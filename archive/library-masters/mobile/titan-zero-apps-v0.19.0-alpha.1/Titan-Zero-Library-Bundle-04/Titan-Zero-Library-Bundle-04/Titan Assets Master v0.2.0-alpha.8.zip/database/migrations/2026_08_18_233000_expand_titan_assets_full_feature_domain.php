<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        $this->canonicalizeCompanyBoundary();
        $this->extendAssetTables();
        $this->extendMaintenance();
        $this->extendFeatureTables();
        $this->createDomainTables();
        $this->extendSettings();
    }

    private function canonicalizeCompanyBoundary(): void
    {
        $tables = [
            'crm_locker_tools',
            'crm_locker_equipment',
            'crm_locker_fleet_vehicles',
            'crm_locker_maintenance_records',
            'crm_locker_asset_events',
            'titan_asset_repair_templates',
            'titan_asset_repairs',
            'titan_asset_warranties',
            'titan_asset_vehicle_mileage_logs',
            'titan_asset_premises_links',
        ];

        foreach ($tables as $table) {
            if (! Schema::hasTable($table)) {
                continue;
            }
            if (! Schema::hasColumn($table, 'company_id')) {
                Schema::table($table, fn (Blueprint $t) => $t->unsignedBigInteger('company_id')->nullable()->index());
            }
        }
    }

    private function extendAssetTables(): void
    {
        foreach (['crm_locker_tools', 'crm_locker_equipment', 'crm_locker_fleet_vehicles'] as $table) {
            if (! Schema::hasTable($table)) {
                continue;
            }
            $defs = [
                'description' => fn (Blueprint $t) => $t->text('description')->nullable(),
                'image_path' => fn (Blueprint $t) => $t->string('image_path', 500)->nullable(),
                'asset_type_public_id' => fn (Blueprint $t) => $t->char('asset_type_public_id', 26)->nullable()->index(),
                'category_public_id' => fn (Blueprint $t) => $t->char('category_public_id', 26)->nullable()->index(),
                'customer_public_id' => fn (Blueprint $t) => $t->char('customer_public_id', 26)->nullable()->index(),
                'owned_by_user_id' => fn (Blueprint $t) => $t->unsignedBigInteger('owned_by_user_id')->nullable()->index(),
                'location_name' => fn (Blueprint $t) => $t->string('location_name', 180)->nullable(),
                'condition_status' => fn (Blueprint $t) => $t->string('condition_status', 40)->nullable()->index(),
                'qr_token' => fn (Blueprint $t) => $t->string('qr_token', 120)->nullable()->index(),
                'written_off_on' => fn (Blueprint $t) => $t->date('written_off_on')->nullable()->index(),
                'written_off_reason' => fn (Blueprint $t) => $t->text('written_off_reason')->nullable(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn($table, $column)) {
                    Schema::table($table, $add);
                }
            }
        }

        if (Schema::hasTable('crm_locker_fleet_vehicles')) {
            $table = 'crm_locker_fleet_vehicles';
            $defs = [
                'name' => fn (Blueprint $t) => $t->string('name', 180)->nullable(),
                'notes' => fn (Blueprint $t) => $t->text('notes')->nullable(),
                'last_service_date' => fn (Blueprint $t) => $t->date('last_service_date')->nullable()->index(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn($table, $column)) {
                    Schema::table($table, $add);
                }
            }
        }
    }

    private function extendMaintenance(): void
    {
        if (! Schema::hasTable('crm_locker_maintenance_records')) {
            return;
        }
        $defs = [
            'reference_no' => fn (Blueprint $t) => $t->string('reference_no', 120)->nullable()->index(),
            'priority' => fn (Blueprint $t) => $t->string('priority', 30)->default('normal')->index(),
            'assigned_to_user_id' => fn (Blueprint $t) => $t->unsignedBigInteger('assigned_to_user_id')->nullable()->index(),
            'maintenance_note' => fn (Blueprint $t) => $t->text('maintenance_note')->nullable(),
        ];
        foreach ($defs as $column => $add) {
            if (! Schema::hasColumn('crm_locker_maintenance_records', $column)) {
                Schema::table('crm_locker_maintenance_records', $add);
            }
        }
    }

    private function extendFeatureTables(): void
    {
        if (Schema::hasTable('titan_asset_repairs')) {
            $defs = [
                'assigned_to_user_id' => fn (Blueprint $t) => $t->unsignedBigInteger('assigned_to_user_id')->nullable()->index(),
                'location_public_id' => fn (Blueprint $t) => $t->char('location_public_id', 26)->nullable()->index(),
                'work_order_public_id' => fn (Blueprint $t) => $t->char('work_order_public_id', 26)->nullable()->index(),
                'root_cause' => fn (Blueprint $t) => $t->text('root_cause')->nullable(),
                'parts_used' => fn (Blueprint $t) => $t->text('parts_used')->nullable(),
                'parts_cost_minor' => fn (Blueprint $t) => $t->bigInteger('parts_cost_minor')->nullable(),
                'labour_cost_minor' => fn (Blueprint $t) => $t->bigInteger('labour_cost_minor')->nullable(),
                'repair_count' => fn (Blueprint $t) => $t->unsignedInteger('repair_count')->default(1),
                'under_warranty' => fn (Blueprint $t) => $t->boolean('under_warranty')->default(false)->index(),
                'downtime_started_at' => fn (Blueprint $t) => $t->dateTime('downtime_started_at')->nullable()->index(),
                'downtime_ended_at' => fn (Blueprint $t) => $t->dateTime('downtime_ended_at')->nullable()->index(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn('titan_asset_repairs', $column)) {
                    Schema::table('titan_asset_repairs', $add);
                }
            }
        }

        if (Schema::hasTable('titan_asset_repair_templates')) {
            $defs = [
                'equipment_category' => fn (Blueprint $t) => $t->string('equipment_category', 120)->nullable()->index(),
                'standard_parts' => fn (Blueprint $t) => $t->text('standard_parts')->nullable(),
                'estimated_hours' => fn (Blueprint $t) => $t->decimal('estimated_hours', 8, 2)->nullable(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn('titan_asset_repair_templates', $column)) {
                    Schema::table('titan_asset_repair_templates', $add);
                }
            }
        }

        if (Schema::hasTable('titan_asset_warranties')) {
            $defs = [
                'profile_public_id' => fn (Blueprint $t) => $t->char('profile_public_id', 26)->nullable()->index(),
                'supplier_name' => fn (Blueprint $t) => $t->string('supplier_name', 180)->nullable(),
                'warranty_number' => fn (Blueprint $t) => $t->string('warranty_number', 160)->nullable()->index(),
                'claim_reference' => fn (Blueprint $t) => $t->string('claim_reference', 160)->nullable(),
                'claimed_at' => fn (Blueprint $t) => $t->dateTime('claimed_at')->nullable(),
                'additional_cost_minor' => fn (Blueprint $t) => $t->bigInteger('additional_cost_minor')->nullable(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn('titan_asset_warranties', $column)) {
                    Schema::table('titan_asset_warranties', $add);
                }
            }
        }

        if (Schema::hasTable('titan_asset_vehicle_mileage_logs')) {
            $defs = [
                'odometer_start' => fn (Blueprint $t) => $t->unsignedBigInteger('odometer_start')->nullable(),
                'odometer_end' => fn (Blueprint $t) => $t->unsignedBigInteger('odometer_end')->nullable(),
                'km_driven' => fn (Blueprint $t) => $t->unsignedInteger('km_driven')->nullable(),
                'notes' => fn (Blueprint $t) => $t->text('notes')->nullable(),
            ];
            foreach ($defs as $column => $add) {
                if (! Schema::hasColumn('titan_asset_vehicle_mileage_logs', $column)) {
                    Schema::table('titan_asset_vehicle_mileage_logs', $add);
                }
            }
        }
    }

    private function createDomainTables(): void
    {
        if (! Schema::hasTable('titan_asset_types')) {
            Schema::create('titan_asset_types', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('name', 120);
                $t->string('applies_to', 40)->default('equipment')->index();
                $t->text('description')->nullable();
                $t->boolean('active')->default(true)->index();
                $t->unsignedBigInteger('added_by_user_id')->nullable()->index();
                $t->timestamps();
                $t->unique(['company_id', 'name', 'applies_to'], 'titan_asset_type_name_unique');
            });
        }

        if (! Schema::hasTable('titan_asset_categories')) {
            Schema::create('titan_asset_categories', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('name', 120);
                $t->string('code', 80)->nullable()->index();
                $t->char('parent_public_id', 26)->nullable()->index();
                $t->text('description')->nullable();
                $t->boolean('active')->default(true)->index();
                $t->unsignedBigInteger('added_by_user_id')->nullable()->index();
                $t->timestamps();
                $t->unique(['company_id', 'name'], 'titan_asset_category_name_unique');
            });
        }

        if (! Schema::hasTable('titan_asset_allocations')) {
            Schema::create('titan_asset_allocations', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('subject_type', 40)->index();
                $t->char('subject_public_id', 26)->index();
                $t->string('ref_no', 120)->index();
                $t->unsignedInteger('quantity')->default(1);
                $t->unsignedInteger('revoked_quantity')->default(0);
                $t->unsignedBigInteger('receiver_user_id')->nullable()->index();
                $t->unsignedBigInteger('provider_user_id')->nullable()->index();
                $t->dateTime('allocated_at')->index();
                $t->dateTime('allocated_upto')->nullable()->index();
                $t->string('status', 40)->default('active')->index();
                $t->text('reason')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->index(['company_id', 'subject_type', 'subject_public_id', 'status'], 'titan_asset_alloc_subject');
            });
        }

        if (! Schema::hasTable('titan_asset_lending_history')) {
            Schema::create('titan_asset_lending_history', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('subject_type', 40)->index();
                $t->char('subject_public_id', 26)->index();
                $t->unsignedBigInteger('borrower_user_id')->nullable()->index();
                $t->unsignedBigInteger('lender_user_id')->nullable()->index();
                $t->unsignedBigInteger('returner_user_id')->nullable()->index();
                $t->dateTime('issued_at')->index();
                $t->dateTime('due_at')->nullable()->index();
                $t->dateTime('returned_at')->nullable()->index();
                $t->text('notes')->nullable();
                $t->timestamps();
                $t->index(['company_id', 'subject_type', 'subject_public_id', 'returned_at'], 'titan_asset_lending_open');
            });
        }

        if (! Schema::hasTable('titan_asset_settings')) {
            Schema::create('titan_asset_settings', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('company_id')->unique();
                $t->string('asset_code_prefix', 30)->default('AST');
                $t->string('allocation_code_prefix', 30)->default('ALLOC');
                $t->string('revoke_code_prefix', 30)->default('REVOKE');
                $t->string('maintenance_code_prefix', 30)->default('MAINT');
                $t->boolean('notify_sent_for_maintenance')->default(false);
                $t->boolean('notify_assigned_for_maintenance')->default(false);
                $t->json('maintenance_recipient_user_ids')->nullable();
                $t->string('send_for_maintenance_subject', 255)->nullable();
                $t->text('send_for_maintenance_body')->nullable();
                $t->string('assigned_for_maintenance_subject', 255)->nullable();
                $t->text('assigned_for_maintenance_body')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
            });
        }

        if (! Schema::hasTable('titan_asset_warranty_profiles')) {
            Schema::create('titan_asset_warranty_profiles', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('name', 180);
                $t->string('equipment_category', 120)->nullable()->index();
                $t->unsignedInteger('warranty_duration');
                $t->string('warranty_type', 20)->default('month');
                $t->text('notes')->nullable();
                $t->boolean('active')->default(true)->index();
                $t->timestamps();
                $t->unique(['company_id', 'name'], 'titan_asset_warranty_profile_name_unique');
            });
        }

        if (! Schema::hasTable('titan_asset_location_registers')) {
            Schema::create('titan_asset_location_registers', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('location_public_id', 26)->index();
                $t->string('subject_type', 40)->default('equipment')->index();
                $t->char('subject_public_id', 26)->index();
                $t->text('notes')->nullable();
                $t->boolean('active')->default(true)->index();
                $t->timestamps();
                $t->unique(['company_id', 'location_public_id', 'subject_type', 'subject_public_id'], 'titan_asset_location_register_unique');
            });
        }

        if (! Schema::hasTable('titan_asset_equipment_checks')) {
            Schema::create('titan_asset_equipment_checks', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('register_public_id', 26)->index();
                $t->char('work_order_public_id', 26)->nullable()->index();
                $t->unsignedBigInteger('checked_by_user_id')->nullable()->index();
                $t->string('event_type', 20)->index();
                $t->text('notes')->nullable();
                $t->dateTime('checked_at')->index();
                $t->timestamps();
            });
        }

        if (! Schema::hasTable('titan_asset_documents')) {
            Schema::create('titan_asset_documents', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('subject_type', 40)->index();
                $t->char('subject_public_id', 26)->index();
                $t->string('document_type', 60)->default('file')->index();
                $t->string('name', 180);
                $t->string('storage_disk', 40)->default('local');
                $t->string('storage_path', 500);
                $t->string('mime_type', 120)->nullable();
                $t->unsignedBigInteger('size_bytes')->nullable();
                $t->unsignedBigInteger('uploaded_by_user_id')->nullable()->index();
                $t->timestamps();
                $t->index(['company_id', 'subject_type', 'subject_public_id'], 'titan_asset_document_subject');
            });
        }

        if (! Schema::hasTable('titan_asset_notifications')) {
            Schema::create('titan_asset_notifications', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('event_type', 80)->index();
                $t->string('subject_type', 40)->nullable()->index();
                $t->char('subject_public_id', 26)->nullable()->index();
                $t->char('maintenance_public_id', 26)->nullable()->index();
                $t->unsignedBigInteger('recipient_user_id')->nullable()->index();
                $t->string('channel', 30)->default('email');
                $t->string('recipient', 255)->nullable();
                $t->string('status', 30)->default('pending')->index();
                $t->dateTime('sent_at')->nullable()->index();
                $t->text('error_message')->nullable();
                $t->timestamps();
            });
        }
    }

    private function extendSettings(): void
    {
        if (! Schema::hasTable('titan_asset_settings')) {
            return;
        }
        $defs = [
            'send_for_maintenance_subject' => fn (Blueprint $t) => $t->string('send_for_maintenance_subject', 255)->nullable(),
            'send_for_maintenance_body' => fn (Blueprint $t) => $t->text('send_for_maintenance_body')->nullable(),
            'assigned_for_maintenance_subject' => fn (Blueprint $t) => $t->string('assigned_for_maintenance_subject', 255)->nullable(),
            'assigned_for_maintenance_body' => fn (Blueprint $t) => $t->text('assigned_for_maintenance_body')->nullable(),
        ];
        foreach ($defs as $column => $add) {
            if (! Schema::hasColumn('titan_asset_settings', $column)) {
                Schema::table('titan_asset_settings', $add);
            }
        }
    }

    public function down(): void
    {
        // Asset history and adopted Locker data are deliberately preserved on rollback/uninstall.
    }
};
