<?php

declare(strict_types=1);

use App\Extensions\TitanAssets\System\Navigation\AssetMenuSelfHealer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;

return new class extends Migration
{
    public function up(): void
    {
        Cache::forget('titan_assets_menu_schema_version');
        try {
            app(AssetMenuSelfHealer::class)->heal(true);
        } catch (\Throwable) {
            // Menu repair is deliberately non-fatal; normal boot will self-heal again.
        }
    }

    public function down(): void
    {
        // Preserve menu ownership so rollback never strands installed asset data behind missing navigation.
    }
};
