<nav class="mb-6 flex flex-wrap gap-2 text-sm" aria-label="{{ __('People') }}">
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.index') }}">{{ __('Overview') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.directory.index') }}">{{ __('Directory') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.organisation.index') }}">{{ __('Organisation') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.leave.index') }}">{{ __('Leave & Absence') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.holidays.index') }}">{{ __('Holidays') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.lifecycle.index') }}">{{ __('Lifecycle') }}</a>
    <a class="rounded-lg border px-3 py-2" href="{{ route('dashboard.user.titan-people.profile.show') }}">{{ __('My Profile') }}</a>
</nav>
