@extends('panel.layout.app')
@section('title', __('People'))
@section('content')
<div class="container-xl py-6">
    @include('titan-people::partials.nav')
    <div class="mb-6"><h1 class="mb-2 text-2xl font-semibold">{{ __('People') }}</h1><p class="text-muted">{{ __('Tenant-scoped workforce identity, employment, organisation and leave facts.') }}</p></div>
    <div class="grid gap-4 md:grid-cols-4">
        <div class="rounded-xl border p-4"><div class="text-sm text-muted">{{ __('Workers') }}</div><div class="mt-2 text-2xl font-semibold">{{ $summary['workers'] }}</div></div>
        <div class="rounded-xl border p-4"><div class="text-sm text-muted">{{ __('Active') }}</div><div class="mt-2 text-2xl font-semibold">{{ $summary['active_workers'] }}</div></div>
        <div class="rounded-xl border p-4"><div class="text-sm text-muted">{{ __('Departments') }}</div><div class="mt-2 text-2xl font-semibold">{{ $summary['departments'] }}</div></div>
        <div class="rounded-xl border p-4"><div class="text-sm text-muted">{{ __('Pending leave') }}</div><div class="mt-2 text-2xl font-semibold">{{ $summary['pending_leave'] }}</div></div>
    </div>
</div>
@endsection
