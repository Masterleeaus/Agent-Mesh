@extends('panel.layout.app')
@section('title', __('Holidays'))
@section('content')
<div class="container-xl py-6">@include('titan-people::partials.nav')<h1 class="mb-4 text-2xl font-semibold">{{ __('Holidays') }}</h1><div class="grid gap-3">@forelse($holidays as $x)<article class="rounded-xl border p-4"><h2 class="font-semibold">{{ $x->name }}</h2><p class="text-sm text-muted">{{ $x->starts_on?->toDateString() }} – {{ $x->ends_on?->toDateString() }} · {{ $x->timezone }}</p></article>@empty<p class="rounded-xl border p-6 text-muted">{{ __('No holidays are configured for this company.') }}</p>@endforelse</div><div class="mt-4">{{ $holidays->links() }}</div></div>
@endsection
