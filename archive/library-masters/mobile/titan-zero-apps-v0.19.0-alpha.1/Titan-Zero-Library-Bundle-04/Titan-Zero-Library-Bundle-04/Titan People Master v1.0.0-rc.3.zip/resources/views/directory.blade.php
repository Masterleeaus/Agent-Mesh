@extends('panel.layout.app')
@section('title', __('People Directory'))
@section('content')
<div class="container-xl py-6">@include('titan-people::partials.nav')<h1 class="mb-4 text-2xl font-semibold">{{ __('People Directory') }}</h1>
<div class="overflow-x-auto rounded-xl border"><table class="w-full text-sm"><thead><tr class="border-b"><th class="p-3 text-left">{{ __('Person') }}</th><th class="p-3 text-left">{{ __('Employee #') }}</th><th class="p-3 text-left">{{ __('Work email') }}</th><th class="p-3 text-left">{{ __('Status') }}</th></tr></thead><tbody>
@forelse($workers as $worker)<tr class="border-b"><td class="p-3"><a class="font-medium underline" href="{{ route('dashboard.user.titan-people.people.show', $worker->public_id) }}">{{ $worker->preferred_name ?: ($worker->legal_name ?: $worker->public_id) }}</a></td><td class="p-3">{{ $worker->employee_number ?: '—' }}</td><td class="p-3">{{ $worker->work_email ?: '—' }}</td><td class="p-3">{{ ucfirst($worker->employment_status) }}</td></tr>@empty<tr><td colspan="4" class="p-6 text-center text-muted">{{ __('No People worker records are available for this company.') }}</td></tr>@endforelse
</tbody></table></div><div class="mt-4">{{ $workers->links() }}</div></div>
@endsection
