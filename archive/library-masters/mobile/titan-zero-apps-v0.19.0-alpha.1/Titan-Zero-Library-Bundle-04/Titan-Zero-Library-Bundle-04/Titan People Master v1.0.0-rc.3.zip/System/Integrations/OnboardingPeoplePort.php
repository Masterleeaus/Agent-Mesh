<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface OnboardingPeoplePort{public function submitAcknowledgement(int $companyId,string $workerRef,array $facts,array $context):array;}
