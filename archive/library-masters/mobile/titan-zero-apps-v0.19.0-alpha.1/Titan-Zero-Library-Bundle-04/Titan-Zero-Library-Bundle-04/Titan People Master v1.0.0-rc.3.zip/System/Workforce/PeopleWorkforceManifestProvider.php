<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Workforce;

use RuntimeException;

final class PeopleWorkforceManifestProvider
{
    public function __construct(private readonly string $path = __DIR__.'/../../resources/workforce/workforce-manifest.json') {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        $json = @file_get_contents($this->path);
        if (! is_string($json)) throw new RuntimeException('Titan People Workforce manifest is unavailable.');
        $decoded = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new RuntimeException('Titan People Workforce manifest is invalid.');
        return $decoded;
    }
}
