<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Navigation;

final class PeopleNavigation
{
    /** @return list<array<string,mixed>> */
    public static function user(): array
    {
        $common = ['route_slug'=>null,'svg'=>null,'is_active'=>true,'params'=>[],'type'=>'item','badge'=>null,'extension'=>null,'show_condition'=>true,'is_admin'=>false];
        $child = $common + ['parent_key'=>'titan_people'];
        return [
            $common + ['parent_key'=>null,'key'=>'titan_people','route'=>'dashboard.user.titan-people.index','label'=>'People','icon'=>'tabler-users','order'=>13,'active_condition'=>['dashboard.user.titan-people.*'],'data-name'=>'titan-people'],
            $child + ['key'=>'titan_people_overview','route'=>'dashboard.user.titan-people.index','label'=>'Overview','icon'=>'tabler-layout-dashboard','order'=>1,'active_condition'=>['dashboard.user.titan-people.index'],'data-name'=>'titan-people-overview'],
            $child + ['key'=>'titan_people_directory','route'=>'dashboard.user.titan-people.directory.index','label'=>'People Directory','icon'=>'tabler-address-book','order'=>2,'active_condition'=>['dashboard.user.titan-people.directory.*','dashboard.user.titan-people.people.*'],'data-name'=>'titan-people-directory'],
            $child + ['key'=>'titan_people_organisation','route'=>'dashboard.user.titan-people.organisation.index','label'=>'Organisation','icon'=>'tabler-sitemap','order'=>3,'active_condition'=>['dashboard.user.titan-people.organisation.*'],'data-name'=>'titan-people-organisation'],
            $child + ['key'=>'titan_people_leave','route'=>'dashboard.user.titan-people.leave.index','label'=>'Leave & Absence','icon'=>'tabler-calendar-event','order'=>4,'active_condition'=>['dashboard.user.titan-people.leave.*'],'data-name'=>'titan-people-leave'],
            $child + ['key'=>'titan_people_holidays','route'=>'dashboard.user.titan-people.holidays.index','label'=>'Holidays','icon'=>'tabler-calendar-star','order'=>5,'active_condition'=>['dashboard.user.titan-people.holidays.*'],'data-name'=>'titan-people-holidays'],
            $child + ['key'=>'titan_people_lifecycle','route'=>'dashboard.user.titan-people.lifecycle.index','label'=>'Lifecycle','icon'=>'tabler-history','order'=>6,'active_condition'=>['dashboard.user.titan-people.lifecycle.*'],'data-name'=>'titan-people-lifecycle'],
            $child + ['key'=>'titan_people_profile','route'=>'dashboard.user.titan-people.profile.show','label'=>'My Profile','icon'=>'tabler-user-circle','order'=>7,'active_condition'=>['dashboard.user.titan-people.profile.*'],'data-name'=>'titan-people-profile'],
        ];
    }
}
