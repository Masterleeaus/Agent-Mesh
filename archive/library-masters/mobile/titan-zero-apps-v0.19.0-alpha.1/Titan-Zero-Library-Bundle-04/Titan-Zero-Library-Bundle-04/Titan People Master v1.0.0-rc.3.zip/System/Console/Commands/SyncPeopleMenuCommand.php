<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Console\Commands;

use App\Extensions\TitanPeople\System\Navigation\PeopleMenuRegistrar;
use Illuminate\Console\Command;

final class SyncPeopleMenuCommand extends Command
{
    protected $signature = 'titan-people:host-sync {--force : Regenerate menu cache even when rows are unchanged}';
    protected $description = 'Synchronise Titan People navigation with the host menu table.';

    public function handle(PeopleMenuRegistrar $registrar): int
    {
        $result = $registrar->syncHostMenu((bool) $this->option('force'));
        $this->line(json_encode($result, JSON_UNESCAPED_SLASHES));
        return ($result['available'] ?? false) ? self::SUCCESS : self::INVALID;
    }
}
