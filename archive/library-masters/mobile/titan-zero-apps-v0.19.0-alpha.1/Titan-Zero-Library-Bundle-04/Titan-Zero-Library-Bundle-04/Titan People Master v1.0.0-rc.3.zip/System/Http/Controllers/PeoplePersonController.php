<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Http\Controllers;
use App\Http\Controllers\Controller;use App\Extensions\TitanPeople\System\Authorization\TitanHostAuthorizationAdapter;use App\Extensions\TitanPeople\System\Http\Support\PeopleRequestContext;use App\Extensions\TitanPeople\System\Management\WorkerManagementPolicy;use App\Extensions\TitanPeople\System\Management\WorkerManagementService;use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;use Illuminate\Contracts\View\View;use Illuminate\Http\RedirectResponse;use Illuminate\Http\Request;
final class PeoplePersonController extends Controller
{
    public function __construct(private readonly PeopleReadRepository $people,private readonly TitanHostAuthorizationAdapter $authorization,private readonly WorkerManagementPolicy $policy,private readonly WorkerManagementService $service){}
    public function show(Request $request,string $workerPublicId):View{$c=PeopleRequestContext::get($request);$canManage=$this->authorization->allows($request->user(),'titan-people.manage',(array)config('titan-people.delegated_admin_permissions',[]));return view('titan-people::person',['person'=>$this->people->workerByPublicId($c->companyId,$workerPublicId),'canManage'=>$canManage]);}
    public function update(Request $request,string $workerPublicId):RedirectResponse{$c=PeopleRequestContext::get($request);$this->policy->filter($request->except(['_token','_method']));$data=$request->validate(['employee_number'=>'nullable|string|max:100','preferred_name'=>'nullable|string|max:191','legal_name'=>'nullable|string|max:191','work_email'=>'nullable|email|max:191','phone'=>'nullable|string|max:80']);$this->service->update($c->companyId,$workerPublicId,$data);return redirect()->route('dashboard.user.titan-people.people.show',$workerPublicId)->with('status',__('Person updated.'));}
}
