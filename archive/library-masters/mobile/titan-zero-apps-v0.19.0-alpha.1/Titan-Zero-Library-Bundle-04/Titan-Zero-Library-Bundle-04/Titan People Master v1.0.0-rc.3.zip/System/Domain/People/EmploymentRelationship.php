<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

use DateTimeImmutable;
use DomainException;

final readonly class EmploymentRelationship
{
    public function __construct(
        public int $companyId,
        public int $workerId,
        public string $employmentType,
        public DateTimeImmutable $startsOn,
        public ?DateTimeImmutable $endsOn = null,
    ) {
        if ($companyId <= 0 || $workerId <= 0 || $employmentType === '') {
            throw new DomainException('Employment relationship is incomplete.');
        }
        if ($endsOn !== null && $endsOn < $startsOn) {
            throw new DomainException('Employment relationship end cannot precede start.');
        }
    }
}
