<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

use Throwable;

final readonly class PeopleOutboxDispatcher
{
    public function __construct(
        private PeopleOutboxDeliveryStore $store,
        private PeopleSignalDeliveryPort $delivery
    ) {}

    public function dispatch(int $limit = 100): int
    {
        $published = 0;
        foreach ($this->store->pending(max(1, min($limit, 250))) as $event) {
            try {
                $receipt = $this->delivery->publish($event);
                if (trim($receipt) === '') {
                    throw new \RuntimeException('Signal delivery returned no receipt.');
                }
                $this->store->markPublished($event->companyId, $event->eventId, $receipt);
                $published++;
            } catch (Throwable $e) {
                $this->store->markFailed($event->companyId, $event->eventId, substr($e->getMessage(), 0, 1000));
            }
        }
        return $published;
    }
}
