<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Console\Commands;

use App\Extensions\TitanPeople\System\Signals\PeopleOutboxDispatcher;
use Illuminate\Console\Command;

final class DispatchPeopleOutboxCommand extends Command
{
    protected $signature = 'titan-people:dispatch-outbox {--limit=}';
    protected $description = 'Dispatch pending Titan People Signal outbox facts through the configured host delivery port.';

    public function handle(PeopleOutboxDispatcher $dispatcher): int
    {
        $configured = (int) config('titan-people.outbox_dispatch_batch', 100);
        $requested = $this->option('limit');
        $limit = $requested === null ? $configured : (int) $requested;
        $published = $dispatcher->dispatch(max(1, min($limit, 250)));
        $this->info("Titan People outbox published {$published} event(s).");
        return self::SUCCESS;
    }
}
