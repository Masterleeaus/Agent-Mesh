<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class PeopleDocumentRevision extends Model
{
    protected $table = 'titan_people_document_revisions';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['document_id', 'revision', 'storage_path', 'sha256', 'mime_type', 'byte_size', 'original_name', 'created_by_worker_id'];
}
