<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class Worker extends Model
{
    protected $table = 'titan_people_workers';

    protected $fillable = [
        'public_id',
        'external_subject',
        'employee_number',
        'preferred_name',
        'legal_name',
        'work_email',
        'personal_email',
        'phone',
        'employment_status',
    ];

    protected $casts = [
        'company_id' => 'integer',
    ];
}
