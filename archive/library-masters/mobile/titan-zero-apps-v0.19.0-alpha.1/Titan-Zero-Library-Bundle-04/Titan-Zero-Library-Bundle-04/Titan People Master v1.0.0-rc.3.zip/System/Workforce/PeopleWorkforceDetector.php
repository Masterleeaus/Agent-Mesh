<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce;
final class PeopleWorkforceDetector
{
    /** @param array<string,mixed> $snapshot @return list<PeopleWorkforceProposal> */
    public function detect(array $snapshot):array
    {
        $worker=(string)($snapshot['worker_ref']??'unknown');$out=[];
        $add=static function(array &$out,string $code,string $severity,string $summary,string $worker):void{$out[]=new PeopleWorkforceProposal($code,$worker,$severity,$summary,true,false);};
        if(($snapshot['profile_complete']??true)!==true)$add($out,'people.record.incomplete','medium','Worker record is incomplete.',$worker);
        if((int)($snapshot['pending_lifecycle_actions']??0)>0)$add($out,'people.lifecycle.pending','high','Lifecycle action requires review.',$worker);
        if(($snapshot['employment_status']??null)==='probation'&&(int)($snapshot['probation_review_due_days']??1)<=0)$add($out,'people.probation.review_overdue','medium','Probation review is due or overdue.',$worker);
        if(abs((float)($snapshot['leave_balance_delta']??0))>0.0001)$add($out,'people.leave.balance_anomaly','high','Leave balance does not reconcile.',$worker);
        if((int)($snapshot['leave_decision_overdue_days']??0)>0)$add($out,'people.leave.decision_overdue','high','Leave decision is overdue.',$worker);
        if(($snapshot['policy_acknowledgement_gap']??false)===true)$add($out,'people.policy.ack_gap','medium','Policy acknowledgement is missing.',$worker);
        if(($snapshot['people_document_expired']??false)===true)$add($out,'people.document.expired','medium','People-owned document is expired.',$worker);
        return $out;
    }
}
