<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Leave;
use DomainException;
final class LeaveLedger{private array $entries=[];private array $keys=[];public function __construct(private readonly int $companyId,private readonly int $workerId,private readonly string $leaveTypeKey){if($companyId<=0||$workerId<=0||$leaveTypeKey==='')throw new DomainException('Leave ledger identity is incomplete.');}
public function append(string $type,float $amount,string $effectiveDate,string $idempotencyKey):void{if(isset($this->keys[$idempotencyKey]))return;if(!in_array($type,['accrual','initial','adjustment','approved_consumption','cancellation_reversal','comp_off_award'],true))throw new DomainException('Unsupported leave ledger entry.');if($idempotencyKey===''||$effectiveDate==='')throw new DomainException('Leave ledger metadata incomplete.');$this->entries[]=['type'=>$type,'amount'=>$amount,'effective_date'=>$effectiveDate,'idempotency_key'=>$idempotencyKey];$this->keys[$idempotencyKey]=true;}
public function balance():float{return round(array_sum(array_column($this->entries,'amount')),4);}
public function reconcileCachedBalance(float $cached):float{$actual=$this->balance();if(abs($actual-$cached)>0.0001)throw new DomainException('Cached leave balance does not reconcile to append-only ledger.');return $actual;}
public function entries():array{return $this->entries;}}
