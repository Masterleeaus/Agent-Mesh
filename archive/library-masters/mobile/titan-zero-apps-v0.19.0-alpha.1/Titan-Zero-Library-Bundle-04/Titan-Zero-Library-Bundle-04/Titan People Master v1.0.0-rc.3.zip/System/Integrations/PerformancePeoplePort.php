<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface PerformancePeoplePort{public function workerOrganisationReference(int $companyId,string $workerRef):array;}
