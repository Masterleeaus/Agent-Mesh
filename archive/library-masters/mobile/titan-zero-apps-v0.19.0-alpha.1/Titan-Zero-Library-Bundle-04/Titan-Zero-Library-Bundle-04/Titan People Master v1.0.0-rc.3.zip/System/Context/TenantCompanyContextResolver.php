<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Context;

use RuntimeException;

/**
 * Resolves tenant authority only from trusted/authenticated host context.
 * Caller request payload fields are deliberately ignored as authority.
 */
final class TenantCompanyContextResolver
{
    /** @param array<string,mixed> $trustedContext */
    public function resolve(array $trustedContext): int
    {
        $value = $trustedContext['company_id'] ?? null;
        if (! is_int($value) && ! (is_string($value) && ctype_digit($value))) {
            throw new RuntimeException('Authenticated Titan company_id context is missing.');
        }

        $companyId = (int) $value;
        if ($companyId <= 0) {
            throw new RuntimeException('Authenticated Titan company_id context is invalid.');
        }

        return $companyId;
    }
}
