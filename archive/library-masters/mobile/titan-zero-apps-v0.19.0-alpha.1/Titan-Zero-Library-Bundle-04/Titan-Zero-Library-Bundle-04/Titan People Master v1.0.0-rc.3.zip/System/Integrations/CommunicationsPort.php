<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface CommunicationsPort{public function requestNotification(int $companyId,array $request,array $context):array;}
