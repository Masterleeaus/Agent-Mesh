<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Workforce;

final class PeopleWorkforceWizardRegistry
{
    /** @return list<array<string,mixed>> */
    public function all(): array { return []; }
}
