<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Authorization;

final class PeopleAuthorization
{
    /** @param array<string,mixed> $actor */
    public function allows(array $actor, string $permission): bool
    {
        if (($actor['is_super_admin'] ?? false) === true) return true;
        $permissions = $actor['permissions'] ?? [];
        return is_array($permissions) && in_array($permission, $permissions, true);
    }
}
