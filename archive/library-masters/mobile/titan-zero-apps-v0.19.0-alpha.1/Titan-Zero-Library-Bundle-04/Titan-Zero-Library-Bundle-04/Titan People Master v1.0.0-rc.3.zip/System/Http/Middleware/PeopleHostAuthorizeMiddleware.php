<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Http\Middleware;

use App\Extensions\TitanPeople\System\Authorization\TitanHostAuthorizationAdapter;
use App\Extensions\TitanPeople\System\Context\PeopleExecutionContext;
use App\Extensions\TitanPeople\System\Context\TenantCompanyContextResolver;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class PeopleHostAuthorizeMiddleware
{
    public const CONTEXT_ATTRIBUTE = 'titan_people.execution_context';

    public function __construct(
        private readonly TitanHostAuthorizationAdapter $authorization,
        private readonly TenantCompanyContextResolver $tenantResolver,
    ) {}

    public function handle(Request $request, Closure $next, string $permission = 'titan-people.view'): Response
    {
        $user = $request->user();
        if (! is_object($user)) abort(401);

        $companyId = $this->tenantResolver->resolve([
            'company_id' => $this->trustedCompanyId($request, $user),
        ]);

        $delegated = (array) config('titan-people.delegated_admin_permissions', []);
        if (! $this->authorization->allows($user, $permission, $delegated)) abort(403);
        $subject = method_exists($user, 'getAuthIdentifier') ? $user->getAuthIdentifier() : ($user->id ?? null);
        if ($subject === null || (string) $subject === '') abort(401);

        $traceId = trim((string) $request->headers->get('X-Trace-Id', '')) ?: (string) Str::uuid();
        $correlationId = trim((string) $request->headers->get('X-Correlation-Id', '')) ?: $traceId;
        $causationId = trim((string) $request->headers->get('X-Causation-Id', '')) ?: null;

        $request->attributes->set(self::CONTEXT_ATTRIBUTE, new PeopleExecutionContext(
            $companyId,
            is_int($subject) ? $subject : (string) $subject,
            $traceId,
            $correlationId,
            $causationId,
        ));

        return $next($request);
    }

    private function trustedCompanyId(Request $request, object $user): int|string|null
    {
        $attribute = $request->attributes->get('company_id');
        if (is_int($attribute) || (is_string($attribute) && ctype_digit($attribute))) return $attribute;

        foreach ((array) config('titan-people.trusted_tenant_user_attributes', ['company_id']) as $key) {
            if (! is_string($key) || $key === '') continue;
            $value = $user->{$key} ?? null;
            if (is_int($value) || (is_string($value) && ctype_digit($value))) return $value;
        }

        return null;
    }
}
