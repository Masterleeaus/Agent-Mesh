<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class EmergencyContact extends Model
{
    protected $table = 'titan_people_emergency_contacts';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['worker_id', 'name', 'relationship', 'phone', 'email', 'priority'];
}
