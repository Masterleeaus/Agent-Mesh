<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce\Ports;
interface AutonomyPort { /** @param array<string,mixed> $proposal @return array<string,mixed> */ public function authority(array $proposal): array; }
