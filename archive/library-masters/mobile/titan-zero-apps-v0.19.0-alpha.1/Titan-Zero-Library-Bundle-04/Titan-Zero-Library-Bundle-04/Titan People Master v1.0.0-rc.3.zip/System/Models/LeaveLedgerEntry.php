<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class LeaveLedgerEntry extends Model
{
    protected $table = 'titan_people_leave_ledger';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['worker_id', 'leave_type_id', 'entry_type', 'units', 'effective_date', 'idempotency_key', 'source_type', 'source_id', 'recorded_by_worker_id', 'trace_id', 'correlation_id', 'causation_id'];
    protected $casts = ['effective_date' => 'date', 'units' => 'decimal:4'];
}
