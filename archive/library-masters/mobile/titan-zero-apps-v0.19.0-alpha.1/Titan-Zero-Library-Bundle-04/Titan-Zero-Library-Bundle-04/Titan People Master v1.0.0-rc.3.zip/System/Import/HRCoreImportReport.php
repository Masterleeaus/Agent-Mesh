<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Import;

final readonly class HRCoreImportReport
{
    /**
     * @param array<string,int> $importedCounts
     * @param list<string> $excludedSlices
     * @param list<string> $conflicts
     */
    public function __construct(
        public int $companyId,
        public string $idempotencyKey,
        public array $importedCounts,
        public array $excludedSlices,
        public array $conflicts,
    ) {}
}
