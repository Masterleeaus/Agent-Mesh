<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

use DateTimeImmutable;
use DomainException;

final class EmploymentHistory
{
    /** @var list<EmploymentEvent> */
    private array $events = [];
    /** @var array<string,true> */
    private array $eventIds = [];

    public function __construct(
        private readonly int $companyId,
        private readonly int $workerId,
    ) {}

    public function append(EmploymentEvent $event): void
    {
        if ($event->companyId !== $this->companyId || $event->workerId !== $this->workerId) {
            throw new DomainException('Employment history event is outside the tenant/worker boundary.');
        }
        if (isset($this->eventIds[$event->eventId])) {
            throw new DomainException('Employment lifecycle event IDs are immutable and unique.');
        }
        $last = $this->events[array_key_last($this->events)] ?? null;
        if ($last !== null && $event->effectiveAt < $last->effectiveAt) {
            throw new DomainException('Employment lifecycle events must be appended in effective-date order.');
        }
        $this->events[] = $event;
        $this->eventIds[$event->eventId] = true;
    }

    public function stateAt(DateTimeImmutable $at): ?string
    {
        $state = null;
        foreach ($this->events as $event) {
            if ($event->effectiveAt > $at) break;
            $state = $event->state;
        }
        return $state;
    }

    /** @return list<EmploymentEvent> */
    public function events(): array
    {
        return $this->events;
    }
}
