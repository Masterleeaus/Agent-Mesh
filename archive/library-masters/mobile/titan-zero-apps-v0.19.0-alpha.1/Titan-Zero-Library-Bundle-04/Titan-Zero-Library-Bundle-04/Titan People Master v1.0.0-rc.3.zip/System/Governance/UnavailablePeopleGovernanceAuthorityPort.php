<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Governance;
use App\Extensions\TitanPeople\System\Contracts\PeopleGovernanceAuthorityPort;
final class UnavailablePeopleGovernanceAuthorityPort implements PeopleGovernanceAuthorityPort{public function authorize(string $capability,array $context):array{return ['available'=>false,'allowed'=>false,'receipt_id'=>null];}}
