<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\SelfService;

final class SelfServiceProfilePolicy
{
    private const EDITABLE = ['personal_email','personal_phone','home_address','emergency_contacts','timezone','locale'];

    /** @return list<string> */
    public function editableFields(): array { return self::EDITABLE; }
    public function canEdit(string $field): bool { return in_array($field, self::EDITABLE, true); }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public function filter(array $input): array
    {
        return array_intersect_key($input, array_fill_keys(self::EDITABLE, true));
    }
}
