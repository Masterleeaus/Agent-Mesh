<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Holidays;
use DomainException;
final class HolidayCalendar{private array $holidays=[];public function __construct(private readonly int $companyId){if($companyId<=0)throw new DomainException('Tenant is required.');}
public function add(string $id,string $date,string $name,?int $teamId,?int $locationId,?int $workerId):void{$this->holidays[]=['id'=>$id,'date'=>$date,'name'=>$name,'team_id'=>$teamId,'location_id'=>$locationId,'worker_id'=>$workerId];}
public function applicableTo(int $companyId,int $workerId,?int $teamId,?int $locationId,string $from,string $to):array{if($companyId!==$this->companyId)throw new DomainException('Cross-tenant holiday access denied.');return array_values(array_filter($this->holidays,fn($h)=>$h['date']>=$from&&$h['date']<=$to&&($h['worker_id']===null||$h['worker_id']===$workerId)&&($h['team_id']===null||$h['team_id']===$teamId)&&($h['location_id']===null||$h['location_id']===$locationId)));}
public function absenceReadModel(array $rows,bool $canViewPrivateReason):array{return array_map(function(array $r)use($canViewPrivateReason){if(!$canViewPrivateReason)unset($r['private_reason']);return $r;},$rows);}}
