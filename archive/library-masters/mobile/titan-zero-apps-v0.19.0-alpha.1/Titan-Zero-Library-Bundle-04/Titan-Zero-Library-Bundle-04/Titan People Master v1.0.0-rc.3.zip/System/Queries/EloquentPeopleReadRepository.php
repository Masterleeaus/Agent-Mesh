<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Queries;

use App\Extensions\TitanPeople\System\Models\DepartmentRecord;
use App\Extensions\TitanPeople\System\Models\EmergencyContact;
use App\Extensions\TitanPeople\System\Models\EmploymentEventRecord;
use App\Extensions\TitanPeople\System\Models\EmploymentRelationshipRecord;
use App\Extensions\TitanPeople\System\Models\Holiday;
use App\Extensions\TitanPeople\System\Models\LeaveRequestRecord;
use App\Extensions\TitanPeople\System\Models\PositionRecord;
use App\Extensions\TitanPeople\System\Models\ReportingLineRecord;
use App\Extensions\TitanPeople\System\Models\TeamRecord;
use App\Extensions\TitanPeople\System\Models\Worker;
use App\Extensions\TitanPeople\System\Models\WorkerProfile;
use Illuminate\Database\Eloquent\ModelNotFoundException;

final class EloquentPeopleReadRepository implements PeopleReadRepository
{
    public function overview(int $companyId): array
    {
        return [
            'workers' => Worker::query()->where('company_id', $companyId)->count(),
            'active_workers' => Worker::query()->where('company_id', $companyId)->where('employment_status', 'active')->count(),
            'departments' => DepartmentRecord::query()->where('company_id', $companyId)->where('is_active', true)->count(),
            'pending_leave' => LeaveRequestRecord::query()->where('company_id', $companyId)->whereIn('state', ['submitted','pending'])->count(),
        ];
    }

    public function paginateWorkers(int $companyId, int $perPage): mixed
    {
        return Worker::query()
            ->where('company_id', $companyId)
            ->orderByRaw('COALESCE(preferred_name, legal_name, employee_number, public_id) asc')
            ->paginate($perPage, ['public_id','employee_number','preferred_name','legal_name','work_email','employment_status']);
    }

    public function workerByPublicId(int $companyId, string $publicId): array
    {
        $worker = Worker::query()
            ->where('company_id', $companyId)
            ->where('public_id', $publicId)
            ->first(['id','public_id','employee_number','preferred_name','legal_name','work_email','personal_email','phone','employment_status']);
        if ($worker === null) throw (new ModelNotFoundException())->setModel(Worker::class, [$publicId]);

        $relationship = EmploymentRelationshipRecord::query()
            ->where('company_id', $companyId)
            ->where('worker_id', (int) $worker->getKey())
            ->orderByDesc('starts_on')
            ->limit(1)
            ->first();
        $profile = WorkerProfile::query()->where('company_id', $companyId)->where('worker_id', (int) $worker->getKey())->first();
        return ['worker'=>$worker,'relationship'=>$relationship,'profile'=>$profile];
    }

    public function organisation(int $companyId): array
    {
        return [
            'departments' => DepartmentRecord::query()->where('company_id', $companyId)->orderBy('name')->limit(250)->get(['public_id','parent_id','name','is_active']),
            'positions' => PositionRecord::query()->where('company_id', $companyId)->orderBy('name')->limit(500)->get(['public_id','department_id','name','is_active']),
            'teams' => TeamRecord::query()->where('company_id', $companyId)->orderBy('name')->limit(250)->get(['public_id','name','is_active']),
            'reporting_lines' => ReportingLineRecord::query()->where('company_id', $companyId)->whereNull('effective_to')->orderBy('manager_worker_id')->limit(1000)->get(['manager_worker_id','report_worker_id','effective_from']),
        ];
    }

    public function paginateLeave(int $companyId, int $perPage): mixed
    {
        return LeaveRequestRecord::query()->where('company_id', $companyId)->orderByDesc('starts_at')->paginate($perPage, ['public_id','worker_id','leave_type_id','state','starts_at','ends_at','requested_units','reason']);
    }

    public function paginateHolidays(int $companyId, int $perPage): mixed
    {
        return Holiday::query()->where('company_id', $companyId)->where('active', true)->orderBy('starts_on')->paginate($perPage, ['public_id','name','starts_on','ends_on','team_id','location_id','worker_id','timezone']);
    }

    public function paginateLifecycle(int $companyId, int $perPage): mixed
    {
        return EmploymentEventRecord::query()->where('company_id', $companyId)->orderByDesc('effective_at')->paginate($perPage, ['event_id','worker_id','action','state','effective_at','reason','entity_version']);
    }

    public function profile(int $companyId, int $workerId): array
    {
        $worker = Worker::query()->where('company_id', $companyId)->whereKey($workerId)->firstOrFail(['id','public_id','employee_number','preferred_name','legal_name','work_email','personal_email','phone','employment_status']);
        $profile = WorkerProfile::query()->where('company_id', $companyId)->where('worker_id', $workerId)->first();
        $contacts = EmergencyContact::query()->where('company_id', $companyId)->where('worker_id', $workerId)->orderBy('priority')->limit(10)->get(['name','relationship','phone','email','priority']);
        return ['worker'=>$worker,'profile'=>$profile,'emergency_contacts'=>$contacts];
    }
}
