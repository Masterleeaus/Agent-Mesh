<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

final class PeopleSignalSanitizer
{
    private const ALLOWED = [
        'worker_ref', 'employment_status', 'event_ref', 'relationship_ref', 'department_ref', 'position_ref',
        'team_ref', 'leave_request_ref', 'leave_type_ref', 'leave_state', 'effective_at', 'effective_date',
        'action', 'reason_code', 'document_ref', 'document_type', 'document_state', 'expires_on',
        'policy_ref', 'acknowledgement_state', 'source_ref', 'source_version', 'changed_fields',
    ];

    /** @param array<string,mixed> $payload @return array<string,mixed> */
    public function sanitize(array $payload): array
    {
        $safe = [];
        foreach (self::ALLOWED as $key) {
            if (! array_key_exists($key, $payload)) continue;
            $value = $payload[$key];
            if (is_scalar($value) || $value === null) $safe[$key] = $value;
            elseif ($key === 'changed_fields' && is_array($value)) {
                $safe[$key] = array_values(array_filter($value, static fn($v): bool => is_string($v) && preg_match('/^[a-z0-9_.-]{1,80}$/', $v) === 1));
            }
        }
        return $safe;
    }
}
