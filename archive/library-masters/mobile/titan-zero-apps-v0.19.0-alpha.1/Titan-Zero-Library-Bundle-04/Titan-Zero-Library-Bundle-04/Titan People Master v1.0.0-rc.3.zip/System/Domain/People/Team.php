<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

final readonly class Team
{
    public function __construct(
        public int $companyId,
        public string $publicId,
        public string $name,
    ) {}
}
