<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Documents;
use DomainException;
final readonly class PeopleDocumentPolicy{public function __construct(private int $maxBytes,private array $allowedMimeTypes){if($maxBytes<=0)throw new DomainException('Invalid document size limit.');}
public function validateUpload(string $fileName,string $mimeType,int $size):void{if($fileName===''||str_contains($fileName,'..')||str_contains($fileName,'/')||str_contains($fileName,'\\')||str_contains($fileName,"\0"))throw new DomainException('Unsafe document filename.');if(!in_array(strtolower($mimeType),$this->allowedMimeTypes,true))throw new DomainException('Document MIME type is not allowed.');if($size<=0||$size>$this->maxBytes)throw new DomainException('Document size is not allowed.');}
public function storagePath(int $companyId,int $workerId,string $documentId,int $revision):string{if($companyId<=0||$workerId<=0||$revision<=0||!preg_match('/^[A-Za-z0-9_-]+$/',$documentId))throw new DomainException('Invalid document storage identity.');return "private/titan-people/{$companyId}/workers/{$workerId}/documents/{$documentId}/revisions/{$revision}";}
public function assertDownloadAllowed(int $contextTenantCompanyId,int $documentTenantCompanyId,int $workerId):void{if($contextTenantCompanyId<=0||$workerId<=0||$contextTenantCompanyId!==$documentTenantCompanyId)throw new DomainException('Document access denied.');}
public function validateContentType(string $claimedMimeType,string $contents):void{$mime=strtolower($claimedMimeType);$matches=match($mime){'application/pdf'=>str_starts_with($contents,'%PDF-'),'image/jpeg'=>str_starts_with($contents,"\xFF\xD8\xFF"),'image/png'=>str_starts_with($contents,"\x89PNG\r\n\x1A\n"),default=>false};if(!$matches)throw new DomainException('Document content does not match declared MIME type.');}
public function sha256(string $contents):string{return hash('sha256',$contents);}}
