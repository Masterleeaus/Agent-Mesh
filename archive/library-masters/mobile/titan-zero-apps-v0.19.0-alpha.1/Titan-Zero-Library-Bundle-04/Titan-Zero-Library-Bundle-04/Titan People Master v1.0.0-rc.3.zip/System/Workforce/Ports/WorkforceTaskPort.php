<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce\Ports;
interface WorkforceTaskPort { /** @param array<string,mixed> $task */ public function create(array $task): string; }
