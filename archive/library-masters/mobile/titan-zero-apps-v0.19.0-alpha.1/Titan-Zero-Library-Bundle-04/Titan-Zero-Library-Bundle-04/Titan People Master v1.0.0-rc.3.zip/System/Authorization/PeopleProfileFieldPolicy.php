<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Authorization;
final class PeopleProfileFieldPolicy{private const SENSITIVE=['date_of_birth','personal_email','personal_phone','home_address','emergency_contacts'];public function canView(string $field,bool $self,bool $manageSensitive):bool{return !in_array($field,self::SENSITIVE,true)||$self||$manageSensitive;}public function canEdit(string $field,bool $self,bool $manageSensitive):bool{return $self?in_array($field,['personal_email','personal_phone','home_address','emergency_contacts'],true):$manageSensitive;}}
