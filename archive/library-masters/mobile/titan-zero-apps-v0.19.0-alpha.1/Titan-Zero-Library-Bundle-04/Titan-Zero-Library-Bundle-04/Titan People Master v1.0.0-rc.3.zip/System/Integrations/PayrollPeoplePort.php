<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface PayrollPeoplePort{public function employmentFacts(int $companyId,string $workerRef):array;}
