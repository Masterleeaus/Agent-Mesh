<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Models;
use Illuminate\Database\Eloquent\Model;
final class LeaveBalanceRecord extends Model{protected $table='titan_people_leave_balances';protected $guarded=['id','company_id'];protected $fillable=['worker_id','leave_type_id','cached_units','ledger_watermark_id'];protected $casts=['cached_units'=>'decimal:4','ledger_watermark_id'=>'integer'];}
