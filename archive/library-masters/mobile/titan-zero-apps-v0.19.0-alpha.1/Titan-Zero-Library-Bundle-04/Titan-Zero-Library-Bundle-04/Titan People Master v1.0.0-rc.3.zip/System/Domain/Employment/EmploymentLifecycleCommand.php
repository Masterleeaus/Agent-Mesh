<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Employment;
use DomainException;
final readonly class EmploymentLifecycleCommand{public function __construct(public int $companyId,public int $workerId,public int $actorWorkerId,public string $action,public string $effectiveAt,public string $reason,public string $idempotencyKey,public string $traceId,public string $correlationId,public string $causationId,public int $expectedVersion){foreach([$companyId,$workerId,$actorWorkerId] as $id)if($id<=0)throw new DomainException('Tenant, worker and actor are required.');foreach([$action,$effectiveAt,$reason,$idempotencyKey,$traceId,$correlationId,$causationId] as $v)if(trim($v)==='')throw new DomainException('Lifecycle command metadata is incomplete.');if($expectedVersion<0)throw new DomainException('Expected version cannot be negative.');}}
