<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Http\Controllers;
use App\Http\Controllers\Controller;use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;use App\Extensions\TitanPeople\System\Http\Support\PeopleRequestContext;use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;use App\Extensions\TitanPeople\System\SelfService\SelfServiceProfileService;use Illuminate\Contracts\View\View;use Illuminate\Http\RedirectResponse;use Illuminate\Http\Request;
final class PeopleMyProfileController extends Controller
{
    public function __construct(private readonly PeopleIdentityPort $identity,private readonly PeopleReadRepository $people,private readonly SelfServiceProfileService $service){}
    public function show(Request $request):View{$c=PeopleRequestContext::get($request);$id=$this->identity->resolveWorker($c->companyId,$c->actorSubject);return view('titan-people::profile',['profileData'=>$this->people->profile($c->companyId,$id->workerId)]);}
    public function update(Request $request):RedirectResponse{$c=PeopleRequestContext::get($request);$data=$request->validate(['personal_email'=>'nullable|email|max:191','personal_phone'=>'nullable|string|max:80','timezone'=>'nullable|string|max:80','locale'=>'nullable|string|max:20','home_address'=>'nullable|array','home_address.line1'=>'nullable|string|max:191','home_address.line2'=>'nullable|string|max:191','home_address.city'=>'nullable|string|max:120','home_address.region'=>'nullable|string|max:120','home_address.postcode'=>'nullable|string|max:30','home_address.country'=>'nullable|string|max:120','emergency_contacts'=>'nullable|array|max:10','emergency_contacts.*.name'=>'required_with:emergency_contacts|string|max:191','emergency_contacts.*.relationship'=>'nullable|string|max:120','emergency_contacts.*.phone'=>'required_with:emergency_contacts|string|max:80','emergency_contacts.*.email'=>'nullable|email|max:191']);$this->service->update($c->companyId,$c->actorSubject,$data);return redirect()->route('dashboard.user.titan-people.profile.show')->with('status',__('Profile updated.'));}
}
