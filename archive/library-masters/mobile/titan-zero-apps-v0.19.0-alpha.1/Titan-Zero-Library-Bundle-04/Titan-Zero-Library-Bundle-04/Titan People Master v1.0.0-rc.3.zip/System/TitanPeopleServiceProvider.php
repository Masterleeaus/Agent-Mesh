<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanPeople\System\Console\Commands\DispatchPeopleOutboxCommand;
use App\Extensions\TitanPeople\System\Console\Commands\SyncPeopleMenuCommand;
use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;
use App\Extensions\TitanPeople\System\Contracts\PeopleCommandBusPort;
use App\Extensions\TitanPeople\System\Contracts\PeopleGovernanceAuthorityPort;
use App\Extensions\TitanPeople\System\Domain\Documents\LaravelPrivatePeopleDocumentStorage;
use App\Extensions\TitanPeople\System\Domain\Documents\PeopleDocumentStoragePort;
use App\Extensions\TitanPeople\System\Domain\Employment\DatabaseEmploymentLifecycleStore;
use App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommandService;
use App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleStore;
use App\Extensions\TitanPeople\System\Governance\GovernedPeopleCommandExecutor;
use App\Extensions\TitanPeople\System\Governance\UnavailablePeopleCommandBusPort;
use App\Extensions\TitanPeople\System\Governance\UnavailablePeopleGovernanceAuthorityPort;
use App\Extensions\TitanPeople\System\Identity\DatabasePeopleIdentityPort;
use App\Extensions\TitanPeople\System\Integrations\CommunicationsPort;
use App\Extensions\TitanPeople\System\Integrations\CredentialsPeoplePort;
use App\Extensions\TitanPeople\System\Integrations\OnboardingPeoplePort;
use App\Extensions\TitanPeople\System\Integrations\PayrollPeoplePort;
use App\Extensions\TitanPeople\System\Integrations\PeopleIntegrationGateway;
use App\Extensions\TitanPeople\System\Integrations\PerformancePeoplePort;
use App\Extensions\TitanPeople\System\Integrations\RecruitPeopleIngressPort;
use App\Extensions\TitanPeople\System\Integrations\TimeAttendancePeoplePort;
use App\Extensions\TitanPeople\System\Integrations\UnavailableCommunicationsPort;
use App\Extensions\TitanPeople\System\Signals\DatabasePeopleSignalOutbox;
use App\Extensions\TitanPeople\System\Signals\DatabasePeopleOutboxDeliveryStore;
use App\Extensions\TitanPeople\System\Signals\PeopleOutboxDeliveryStore;
use App\Extensions\TitanPeople\System\Signals\PeopleOutboxDispatcher;
use App\Extensions\TitanPeople\System\Signals\PeopleSignalDeliveryPort;
use App\Extensions\TitanPeople\System\Signals\UnavailablePeopleSignalDeliveryPort;
use App\Extensions\TitanPeople\System\Signals\PeopleChangeEventEmitter;
use App\Extensions\TitanPeople\System\Signals\PeopleSignalOutbox;
use App\Extensions\TitanPeople\System\Signals\PeopleSignalSanitizer;
use App\Extensions\TitanPeople\System\Signals\RewindPeopleSourceContributor;
use App\Extensions\TitanPeople\System\Workforce\PeopleProactiveResponsibilityPlanner;
use App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceDetector;
use App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceProposalService;
use App\Extensions\TitanPeople\System\Workforce\UnavailableWorkforceTaskPort;
use App\Extensions\TitanPeople\System\Workforce\Ports\WorkforceTaskPort;
use App\Extensions\TitanPeople\System\Navigation\PeopleMenuRegistrar;
use App\Extensions\TitanPeople\System\Queries\EloquentPeopleReadRepository;
use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;
use App\Extensions\TitanPeople\System\SelfService\SelfServiceProfilePolicy;
use App\Extensions\TitanPeople\System\SelfService\SelfServiceProfileService;
use App\Extensions\TitanPeople\System\Management\WorkerManagementPolicy;
use App\Extensions\TitanPeople\System\Management\WorkerManagementService;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanPeopleServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanPeople\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanPeople\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

        $this->mergeConfigFrom(__DIR__.'/../config/people.php', 'titan-people');
        if (! (bool) config('titan-people.enabled', true)) return;

        $this->app->singleton(PeopleIdentityPort::class, DatabasePeopleIdentityPort::class);
        $this->app->alias(PeopleIdentityPort::class, 'titan.people.identity');
        $this->app->bind(EmploymentLifecycleStore::class, DatabaseEmploymentLifecycleStore::class);
        $this->app->singleton(PeopleSignalSanitizer::class);
        $this->app->bind(PeopleSignalOutbox::class, DatabasePeopleSignalOutbox::class);
        $this->app->bind(PeopleOutboxDeliveryStore::class, DatabasePeopleOutboxDeliveryStore::class);
        if (! $this->app->bound(PeopleSignalDeliveryPort::class)) $this->app->singleton(PeopleSignalDeliveryPort::class, UnavailablePeopleSignalDeliveryPort::class);
        $this->app->bind(PeopleOutboxDispatcher::class, static fn ($app) => new PeopleOutboxDispatcher($app->make(PeopleOutboxDeliveryStore::class), $app->make(PeopleSignalDeliveryPort::class)));
        $this->app->bind(PeopleChangeEventEmitter::class, static fn ($app) => new PeopleChangeEventEmitter($app->make(PeopleSignalOutbox::class), $app->make(PeopleSignalSanitizer::class)));
        $this->app->bind(RewindPeopleSourceContributor::class, static fn ($app) => new RewindPeopleSourceContributor($app->make(PeopleSignalSanitizer::class)));
        $this->app->bind(EmploymentLifecycleCommandService::class, static fn ($app) => new EmploymentLifecycleCommandService($app->make(EmploymentLifecycleStore::class), $app->make(PeopleChangeEventEmitter::class)));
        $this->app->singleton(PeopleDocumentStoragePort::class, static fn ($app) => new LaravelPrivatePeopleDocumentStorage($app->make('filesystem'), (string) config('titan-people.private_document_disk', 'local')));
        if (! $this->app->bound(PeopleCommandBusPort::class)) $this->app->singleton(PeopleCommandBusPort::class, UnavailablePeopleCommandBusPort::class);
        if (! $this->app->bound(PeopleGovernanceAuthorityPort::class)) $this->app->singleton(PeopleGovernanceAuthorityPort::class, UnavailablePeopleGovernanceAuthorityPort::class);
        $this->app->bind(GovernedPeopleCommandExecutor::class, static fn ($app) => new GovernedPeopleCommandExecutor($app->make(PeopleCommandBusPort::class), $app->make(PeopleGovernanceAuthorityPort::class)));
        $this->app->bind(PeopleReadRepository::class, EloquentPeopleReadRepository::class);
        $this->app->singleton(PeopleIntegrationGateway::class);
        $this->app->bind(TimeAttendancePeoplePort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        $this->app->bind(PayrollPeoplePort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        $this->app->bind(CredentialsPeoplePort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        $this->app->bind(RecruitPeopleIngressPort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        $this->app->bind(PerformancePeoplePort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        $this->app->bind(OnboardingPeoplePort::class, static fn ($app) => $app->make(PeopleIntegrationGateway::class));
        if (! $this->app->bound(CommunicationsPort::class)) $this->app->singleton(CommunicationsPort::class, UnavailableCommunicationsPort::class);
        $this->app->singleton(PeopleWorkforceDetector::class);
        $this->app->singleton(PeopleProactiveResponsibilityPlanner::class);
        if (! $this->app->bound(WorkforceTaskPort::class)) $this->app->singleton(WorkforceTaskPort::class, UnavailableWorkforceTaskPort::class);
        $this->app->bind(PeopleWorkforceProposalService::class, static fn ($app) => new PeopleWorkforceProposalService($app->make(WorkforceTaskPort::class), $app->make(GovernedPeopleCommandExecutor::class), $app->make(PeopleProactiveResponsibilityPlanner::class)));
        $this->app->singleton(SelfServiceProfilePolicy::class);
        $this->app->bind(SelfServiceProfileService::class, static fn ($app) => new SelfServiceProfileService($app->make(PeopleIdentityPort::class), $app->make(SelfServiceProfilePolicy::class)));
        $this->app->singleton(WorkerManagementPolicy::class);
        $this->app->bind(WorkerManagementService::class, static fn ($app) => new WorkerManagementService($app->make(WorkerManagementPolicy::class)));
        $this->app->singleton(PeopleMenuRegistrar::class);
        $this->app->singleton('titan.people.workforce-manifest', static fn (): array => json_decode((string) file_get_contents(__DIR__.'/../resources/workforce/workforce-manifest.json'), true, 512, JSON_THROW_ON_ERROR));
    }

    public function boot(): void
    {
        if (! (bool) config('titan-people.enabled', true)) return;

        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'titan-people');
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->loadRoutesFrom(__DIR__.'/../routes/api.php');
        $this->publishes([__DIR__.'/../config/people.php' => config_path('titan-people.php')], 'titan-people-config');

        $this->app->booted(function (): void {
            $menu = $this->app->make(PeopleMenuRegistrar::class);
            $menu->registerContributions();
            $menu->syncHostMenu();
        });

        if ($this->app->runningInConsole()) {
            $this->commands([SyncPeopleMenuCommand::class, DispatchPeopleOutboxCommand::class]);
            if ((bool) config('titan-people.outbox_dispatch_enabled', true)) {
                $this->app->afterResolving(Schedule::class, function (Schedule $schedule): void {
                    $schedule->command('titan-people:dispatch-outbox')
                        ->everyMinute()
                        ->withoutOverlapping(5)
                        ->onOneServer();
                });
            }
        }
    }

    public function registerKey(): string
    {
        return 'titan-people';
    }

    public static function uninstall(): void
    {
        File::delete(config_path('titan-people.php'));
        // People data is retained by default for HR/legal continuity.
    }
}
