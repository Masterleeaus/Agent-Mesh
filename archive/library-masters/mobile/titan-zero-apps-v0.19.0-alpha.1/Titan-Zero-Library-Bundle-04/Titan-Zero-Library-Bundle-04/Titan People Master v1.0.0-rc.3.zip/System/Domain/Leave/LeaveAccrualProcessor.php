<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Leave;
use DateTimeImmutable;use DateTimeZone;
final class LeaveAccrualProcessor{public function effectiveDate(DateTimeImmutable $instant,DateTimeZone $tenantTimezone):string{return $instant->setTimezone($tenantTimezone)->format('Y-m-d');}public function accrue(LeaveLedger $ledger,float $amount,string $effectiveDate,string $idempotencyKey):void{$ledger->append('accrual',$amount,$effectiveDate,$idempotencyKey);}}
