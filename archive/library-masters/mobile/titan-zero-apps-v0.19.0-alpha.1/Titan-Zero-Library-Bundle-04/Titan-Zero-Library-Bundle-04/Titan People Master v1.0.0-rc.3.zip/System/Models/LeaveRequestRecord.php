<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class LeaveRequestRecord extends Model
{
    protected $table = 'titan_people_leave_requests';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['worker_id', 'leave_type_id', 'public_id', 'state', 'starts_at', 'ends_at', 'requested_units', 'reason', 'submitted_by_worker_id', 'decided_by_worker_id', 'decision_reason', 'version'];
    protected $casts = ['starts_at' => 'datetime', 'ends_at' => 'datetime', 'requested_units' => 'decimal:4'];
}
