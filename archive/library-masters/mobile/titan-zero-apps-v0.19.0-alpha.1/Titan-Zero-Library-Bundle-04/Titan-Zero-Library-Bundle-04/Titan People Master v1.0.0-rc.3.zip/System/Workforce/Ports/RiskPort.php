<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce\Ports;
interface RiskPort { /** @param array<string,mixed> $proposal @return array<string,mixed> */ public function evaluate(array $proposal): array; }
