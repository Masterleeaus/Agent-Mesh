<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Queries;

interface PeopleReadRepository
{
    public function overview(int $companyId): array;
    public function paginateWorkers(int $companyId, int $perPage): mixed;
    public function workerByPublicId(int $companyId, string $publicId): array;
    public function organisation(int $companyId): array;
    public function paginateLeave(int $companyId, int $perPage): mixed;
    public function paginateHolidays(int $companyId, int $perPage): mixed;
    public function paginateLifecycle(int $companyId, int $perPage): mixed;
    public function profile(int $companyId, int $workerId): array;
}
