<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Documents;
interface PeopleDocumentStoragePort{public function putPrivate(string $path,string $contents):void;public function readPrivate(string $path):string;public function exists(string $path):bool;}
