<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class LeaveType extends Model
{
    protected $table = 'titan_people_leave_types';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['key', 'name', 'unit', 'accrual_policy_json', 'approval_policy_json', 'active'];
    protected $casts = ['accrual_policy_json' => 'array', 'approval_policy_json' => 'array', 'active' => 'boolean'];
}
