<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Signals;
use DomainException;
final class UnavailablePeopleSignalDeliveryPort implements PeopleSignalDeliveryPort{public function publish(PeopleOutboxEvent $event):string{throw new DomainException('Titan Signal delivery port is unavailable.');}}
