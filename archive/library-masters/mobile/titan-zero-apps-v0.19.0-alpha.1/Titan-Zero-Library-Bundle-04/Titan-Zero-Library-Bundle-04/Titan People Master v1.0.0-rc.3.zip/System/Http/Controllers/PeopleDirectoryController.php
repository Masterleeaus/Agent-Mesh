<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Http\Controllers;
use App\Http\Controllers\Controller;use App\Extensions\TitanPeople\System\Http\Support\PeoplePagination;use App\Extensions\TitanPeople\System\Http\Support\PeopleRequestContext;use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;use Illuminate\Contracts\View\View;use Illuminate\Http\Request;
final class PeopleDirectoryController extends Controller{public function __construct(private readonly PeopleReadRepository $people,private readonly PeoplePagination $pagination){}public function __invoke(Request $request):View{$c=PeopleRequestContext::get($request);return view('titan-people::directory',['workers'=>$this->people->paginateWorkers($c->companyId,$this->pagination->limit($request->query('per_page')))]);}}
