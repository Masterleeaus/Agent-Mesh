<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface RecruitPeopleIngressPort{public function requestWorkerCreation(int $companyId,array $hiredCandidateFacts,array $context):array;}
