<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Governance;
use App\Extensions\TitanPeople\System\Contracts\PeopleCommandBusPort;use RuntimeException;
final class UnavailablePeopleCommandBusPort implements PeopleCommandBusPort{public function dispatch(string $capability,array $payload,array $context):array{throw new RuntimeException('Titan Command Bus provider is unavailable.');}}
