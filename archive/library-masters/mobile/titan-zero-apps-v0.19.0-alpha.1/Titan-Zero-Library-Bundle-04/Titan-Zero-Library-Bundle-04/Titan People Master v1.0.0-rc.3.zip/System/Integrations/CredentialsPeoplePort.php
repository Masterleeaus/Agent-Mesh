<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface CredentialsPeoplePort{public function workerIdentity(int $companyId,string $workerRef):array;}
