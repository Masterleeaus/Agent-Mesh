<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Contracts;

interface PeopleIdentityPort
{
    public function resolveWorker(int $companyId, string|int $subject): WorkerIdentity;
}
