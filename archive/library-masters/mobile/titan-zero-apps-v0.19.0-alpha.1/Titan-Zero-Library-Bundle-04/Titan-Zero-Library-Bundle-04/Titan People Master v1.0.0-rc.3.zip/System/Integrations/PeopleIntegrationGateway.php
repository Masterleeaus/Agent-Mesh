<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Integrations;
use App\Extensions\TitanPeople\System\Governance\GovernedPeopleCommandExecutor;use App\Extensions\TitanPeople\System\Queries\PeopleReadRepository;
final readonly class PeopleIntegrationGateway implements TimeAttendancePeoplePort,PayrollPeoplePort,CredentialsPeoplePort,RecruitPeopleIngressPort,PerformancePeoplePort,OnboardingPeoplePort
{
    public function __construct(private PeopleReadRepository $read,private GovernedPeopleCommandExecutor $commands){}
    public function workerEligibility(int $companyId,string $workerRef):array{$row=$this->read->workerByPublicId($companyId,$workerRef);$worker=$row['worker'];return ['worker_ref'=>(string)$worker->public_id,'employment_status'=>(string)$worker->employment_status,'eligible'=>in_array((string)$worker->employment_status,['active','probation','leave'],true)];}
    public function employmentFacts(int $companyId,string $workerRef):array{$row=$this->read->workerByPublicId($companyId,$workerRef);$w=$row['worker'];$r=$row['relationship'];return ['worker_ref'=>(string)$w->public_id,'employment_status'=>(string)$w->employment_status,'employee_number'=>(string)$w->employee_number,'relationship_ref'=>$r?->public_id,'employment_type'=>$r?->employment_type,'starts_on'=>$r?->starts_on,'ends_on'=>$r?->ends_on];}
    public function workerIdentity(int $companyId,string $workerRef):array{$row=$this->read->workerByPublicId($companyId,$workerRef);$w=$row['worker'];return ['worker_ref'=>(string)$w->public_id,'employee_number'=>(string)$w->employee_number,'employment_status'=>(string)$w->employment_status];}
    public function workerOrganisationReference(int $companyId,string $workerRef):array{$this->read->workerByPublicId($companyId,$workerRef);return ['worker_ref'=>$workerRef,'company_id'=>$companyId];}
    public function requestWorkerCreation(int $companyId,array $hiredCandidateFacts,array $context):array{$context['company_id']=$companyId;return $this->commands->execute('people.worker.create.from-hire',$hiredCandidateFacts,$context,true);}
    public function submitAcknowledgement(int $companyId,string $workerRef,array $facts,array $context):array{$context['company_id']=$companyId;return $this->commands->execute('people.policy.acknowledge',['worker_ref'=>$workerRef,'facts'=>$facts],$context,true);}
}
