<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Models;use Illuminate\Database\Eloquent\Model;final class EmploymentRelationshipRecord extends Model{protected $table='titan_people_employment_relationships';protected $guarded=['id','company_id'];protected $casts=['starts_on'=>'date','ends_on'=>'date'];}
