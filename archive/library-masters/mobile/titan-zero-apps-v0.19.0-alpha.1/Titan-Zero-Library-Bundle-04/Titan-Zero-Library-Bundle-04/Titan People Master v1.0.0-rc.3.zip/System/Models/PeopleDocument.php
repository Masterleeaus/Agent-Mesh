<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class PeopleDocument extends Model
{
    protected $table = 'titan_people_documents';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['worker_id', 'public_id', 'category', 'title', 'classification', 'current_revision', 'created_by_worker_id'];
}
