<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Employment;
final readonly class EmploymentLifecycleResult{public function __construct(public string $eventId,public string $state,public int $version,public string $idempotencyKey){}}
