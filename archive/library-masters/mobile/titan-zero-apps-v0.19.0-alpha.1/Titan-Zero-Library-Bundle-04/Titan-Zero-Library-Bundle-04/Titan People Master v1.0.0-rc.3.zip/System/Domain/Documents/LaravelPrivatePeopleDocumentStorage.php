<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\Documents;

use Illuminate\Contracts\Filesystem\Factory as FilesystemFactory;
use RuntimeException;

final readonly class LaravelPrivatePeopleDocumentStorage implements PeopleDocumentStoragePort
{
    private const ROOT = 'private/titan-people/';

    public function __construct(private FilesystemFactory $filesystems, private string $disk) {}

    private function disk()
    {
        return $this->filesystems->disk($this->disk);
    }

    private function assertOwnedPath(string $path): void
    {
        if (
            $path === '' ||
            str_contains($path, '..') ||
            str_starts_with($path, '/') ||
            str_contains($path, '\\') ||
            str_contains($path, "\0") ||
            ! str_starts_with($path, self::ROOT)
        ) {
            throw new RuntimeException('Unsafe private document path.');
        }
    }

    public function putPrivate(string $path, string $contents): void
    {
        $this->assertOwnedPath($path);
        if (! $this->disk()->put($path, $contents, ['visibility' => 'private'])) {
            throw new RuntimeException('Private document write failed.');
        }
    }

    public function readPrivate(string $path): string
    {
        $this->assertOwnedPath($path);
        $value = $this->disk()->get($path);
        if (! is_string($value)) {
            throw new RuntimeException('Private document read failed.');
        }
        return $value;
    }

    public function exists(string $path): bool
    {
        $this->assertOwnedPath($path);
        return $this->disk()->exists($path);
    }
}
