<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class Holiday extends Model
{
    protected $table = 'titan_people_holidays';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['public_id', 'name', 'starts_on', 'ends_on', 'team_id', 'location_id', 'worker_id', 'timezone', 'active'];
    protected $casts = ['starts_on' => 'date', 'ends_on' => 'date', 'active' => 'boolean'];
}
