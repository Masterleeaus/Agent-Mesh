<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Http\Support;

use App\Extensions\TitanPeople\System\Context\PeopleExecutionContext;
use App\Extensions\TitanPeople\System\Http\Middleware\PeopleHostAuthorizeMiddleware;
use Illuminate\Http\Request;
use RuntimeException;

final class PeopleRequestContext
{
    public static function get(Request $request): PeopleExecutionContext
    {
        $context = $request->attributes->get(PeopleHostAuthorizeMiddleware::CONTEXT_ATTRIBUTE);
        if (! $context instanceof PeopleExecutionContext) {
            throw new RuntimeException('Titan People authenticated execution context is unavailable.');
        }
        return $context;
    }
}
