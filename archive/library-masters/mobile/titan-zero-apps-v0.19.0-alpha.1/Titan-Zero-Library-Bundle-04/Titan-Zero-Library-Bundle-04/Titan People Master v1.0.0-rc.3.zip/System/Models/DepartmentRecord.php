<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Models;use Illuminate\Database\Eloquent\Model;final class DepartmentRecord extends Model{protected $table='titan_people_departments';protected $guarded=['id','company_id'];}
