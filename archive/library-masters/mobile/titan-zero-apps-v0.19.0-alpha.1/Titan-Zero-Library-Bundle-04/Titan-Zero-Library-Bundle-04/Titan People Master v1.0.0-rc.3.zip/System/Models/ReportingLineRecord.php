<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Models;use Illuminate\Database\Eloquent\Model;final class ReportingLineRecord extends Model{protected $table='titan_people_reporting_lines';protected $guarded=['id','company_id'];protected $casts=['effective_from'=>'immutable_datetime','effective_to'=>'immutable_datetime'];}
