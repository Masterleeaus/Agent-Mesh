<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Governance;
final readonly class GovernanceDecision{public function __construct(public bool $allowed,public string $executionReceiptId,public int $autonomyAuthority,public int $riskScore,public int $assuranceScore){}}
