<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce;
use App\Extensions\TitanPeople\System\Governance\GovernedPeopleCommandExecutor;use App\Extensions\TitanPeople\System\Workforce\Ports\WorkforceTaskPort;use DomainException;
final readonly class PeopleWorkforceProposalService
{
    public function __construct(private WorkforceTaskPort $tasks,private GovernedPeopleCommandExecutor $executor,private PeopleProactiveResponsibilityPlanner $planner){}
    public function createTask(int $companyId,PeopleWorkforceProposal $finding,string $bucket):string{return $this->tasks->create($this->planner->plan($companyId,$finding,$bucket));}
    /** @param array<string,mixed> $payload @param array<string,mixed> $context */
    public function executeApproved(string $capability,array $payload,array $context):array
    {
        if(($context['actor_type']??'')==='ai'||trim((string)($context['approved_by_actor_ref']??''))==='')throw new DomainException('People Workforce proposals require independent human approval.');
        return $this->executor->execute($capability,$payload,$context,true);
    }
}
