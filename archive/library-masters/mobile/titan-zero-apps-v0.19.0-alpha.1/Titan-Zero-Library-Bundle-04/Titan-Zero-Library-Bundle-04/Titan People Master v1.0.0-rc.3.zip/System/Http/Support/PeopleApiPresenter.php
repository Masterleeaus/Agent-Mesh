<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Http\Support;
final class PeopleApiPresenter
{
    /** @return array<string,mixed> */
    public function page(mixed $paginator,callable $map):array{return ['data'=>array_map($map,$paginator->items()),'meta'=>['current_page'=>$paginator->currentPage(),'per_page'=>$paginator->perPage(),'last_page'=>$paginator->lastPage(),'total'=>$paginator->total()]];}
    public function worker(object $w):array{return ['id'=>(string)$w->public_id,'employee_number'=>$w->employee_number,'preferred_name'=>$w->preferred_name,'legal_name'=>$w->legal_name,'work_email'=>$w->work_email,'employment_status'=>$w->employment_status];}
}
