<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Authorization;

/** MagicAI-compatible authorization. Super Admin is the only unconditional platform bypass. */
final class TitanHostAuthorizationAdapter
{
    /** @param list<string> $delegatedAdminPermissions */
    public function allows(object $user, string $permission, array $delegatedAdminPermissions = []): bool
    {
        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) return true;
        if (method_exists($user, 'can') && $user->can($permission)) return true;
        if (method_exists($user, 'checkPermission') && $user->checkPermission($permission)) return true;
        if (method_exists($user, 'hasPermissionTo') && $user->hasPermissionTo($permission)) return true;
        if (method_exists($user, 'isAdmin') && $user->isAdmin()) return in_array($permission, $delegatedAdminPermissions, true);
        return false;
    }
}
