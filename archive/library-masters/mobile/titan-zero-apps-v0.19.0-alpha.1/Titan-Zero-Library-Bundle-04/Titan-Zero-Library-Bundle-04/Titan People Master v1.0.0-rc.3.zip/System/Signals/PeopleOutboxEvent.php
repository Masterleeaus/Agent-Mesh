<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Signals;

use DomainException;

final readonly class PeopleOutboxEvent
{
    /** @param array<string,mixed> $payload */
    private function __construct(
        public string $eventId,
        public int $companyId,
        public string $eventType,
        public string $aggregateRef,
        public array $payload,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $idempotencyKey,
        public string $occurredAt,
    ) {}

    /** @param array<string,mixed> $payload */
    public static function make(int $companyId, string $eventType, string $aggregateRef, array $payload, string $traceId, string $correlationId, string $causationId, string $idempotencyKey, ?string $occurredAt = null): self
    {
        foreach ([$eventType,$aggregateRef,$traceId,$correlationId,$causationId,$idempotencyKey] as $value) {
            if (trim($value) === '') throw new DomainException('People outbox event context is incomplete.');
        }
        if ($companyId <= 0) throw new DomainException('People outbox event tenant is invalid.');
        $seed = hash('sha256', $companyId.'|'.$eventType.'|'.$aggregateRef.'|'.$idempotencyKey);
        return new self(substr($seed,0,32), $companyId, $eventType, $aggregateRef, $payload, $traceId, $correlationId, $causationId, $idempotencyKey, $occurredAt ?? gmdate('c'));
    }
}
