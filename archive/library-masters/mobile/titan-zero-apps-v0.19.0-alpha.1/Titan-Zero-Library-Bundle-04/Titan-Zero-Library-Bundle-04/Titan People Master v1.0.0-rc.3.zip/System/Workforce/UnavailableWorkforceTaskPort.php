<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce;
use App\Extensions\TitanPeople\System\Workforce\Ports\WorkforceTaskPort;use DomainException;
final class UnavailableWorkforceTaskPort implements WorkforceTaskPort{public function create(array $task):string{throw new DomainException('Titan AI Workforce task runtime is unavailable.');}}
