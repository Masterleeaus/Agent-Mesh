<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Contracts;
interface PeopleCommandBusPort{public function dispatch(string $capability,array $payload,array $context): array;}
