<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class PeopleMenuRegistrar
{
    private const MENU_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function registerContributions(): void
    {
        $items = PeopleNavigation::user();
        if ($this->registerWith(self::MENU_REGISTRY, [
            [$items],
            ['titan-people', $items],
            ['navigation.user', 'titan-people', $items],
        ])) return;

        $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.user', 'titan-people', $items],
            ['navigation.user', $items],
            [$items],
        ]);
    }

    /** @return array{available:bool,changed:bool,regenerated:bool,reason:?string} */
    public function syncHostMenu(bool $forceRegenerate = false): array
    {
        if (! Schema::hasTable('menus')) {
            return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menus_table_unavailable'];
        }

        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (! isset($columns['key'])) {
                return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menus_key_column_unavailable'];
            }

            $changed = false;
            foreach (PeopleNavigation::user() as $definition) {
                $parentId = null;
                $parentKey = trim((string) ($definition['parent_key'] ?? ''));
                if ($parentKey !== '') {
                    $parentId = DB::table('menus')->where('key', $parentKey)->value('id');
                    if ($parentId === null) continue;
                }
                $changed = $this->upsertDefinition($definition, $columns, $parentId !== null ? (int) $parentId : null) || $changed;
            }

            $regenerated = ($changed || $forceRegenerate) ? $this->regenerateMenuCache() : false;
            return ['available' => true, 'changed' => $changed, 'regenerated' => $regenerated, 'reason' => null];
        } catch (\Throwable) {
            return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menu_sync_failed'];
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsertDefinition(array $definition, array $columns, ?int $parentId): bool
    {
        $key = (string) ($definition['key'] ?? '');
        if ($key === '') return false;

        $existing = DB::table('menus')->where('key', $key)->first();
        $now = now();
        $vendor = array_intersect_key([
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $definition['icon'] ?? null,
            'svg' => $definition['svg'] ?? null,
            'params' => json_encode($definition['params'] ?? [], JSON_UNESCAPED_SLASHES),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            'extension' => null,
            'updated_at' => $now,
        ], $columns);

        if ($existing !== null) {
            $needsUpdate = false;
            foreach ($vendor as $column => $value) {
                if ($column === 'updated_at') continue;
                if ((string) ($existing->{$column} ?? null) !== (string) $value) {
                    $needsUpdate = true;
                    break;
                }
            }
            if (! $needsUpdate) return false;
            DB::table('menus')->where('key', $key)->update($vendor);
            return true;
        }

        $insert = array_intersect_key([
            'key' => $key,
            'order' => (int) ($definition['order'] ?? 13),
            'is_active' => 1,
            'created_at' => $now,
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ] + $vendor, $columns);
        DB::table('menus')->insert($insert);
        return true;
    }

    /** @param list<array<int,mixed>> $argumentSets */
    private function registerWith(string $class, array $argumentSets): bool
    {
        if (! class_exists($class)) return false;
        try { $registry = app($class); } catch (\Throwable) { return false; }
        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) continue;
            foreach ($argumentSets as $arguments) {
                try { $registry->{$method}(...$arguments); return true; } catch (\Throwable) {}
            }
        }
        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class = self::MENU_SERVICE;
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) return false;
        try { app($class)->regenerate(); return true; } catch (\Throwable) {
            try { $class::regenerate(); return true; } catch (\Throwable) { return false; }
        }
    }
}
