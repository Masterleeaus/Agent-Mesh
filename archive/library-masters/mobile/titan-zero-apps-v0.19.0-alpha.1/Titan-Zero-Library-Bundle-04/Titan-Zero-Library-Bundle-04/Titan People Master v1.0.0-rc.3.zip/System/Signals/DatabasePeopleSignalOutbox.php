<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Signals;
use App\Extensions\TitanPeople\System\Models\PeopleSignalOutboxRecord;
final class DatabasePeopleSignalOutbox implements PeopleSignalOutbox
{
    public function append(PeopleOutboxEvent $event): string
    {
        $existing=PeopleSignalOutboxRecord::query()->where('company_id',$event->companyId)->where('idempotency_key',$event->idempotencyKey)->first();
        if($existing!==null)return (string)$existing->event_id;
        $row=new PeopleSignalOutboxRecord();
        foreach([
            'company_id'=>$event->companyId,'event_id'=>$event->eventId,'event_type'=>$event->eventType,
            'aggregate_ref'=>$event->aggregateRef,'payload'=>$event->payload,'trace_id'=>$event->traceId,
            'correlation_id'=>$event->correlationId,'causation_id'=>$event->causationId,'idempotency_key'=>$event->idempotencyKey,
            'occurred_at'=>$event->occurredAt,'attempts'=>0
        ] as $key=>$value)$row->setAttribute($key,$value);
        $row->save();
        return $event->eventId;
    }
}
