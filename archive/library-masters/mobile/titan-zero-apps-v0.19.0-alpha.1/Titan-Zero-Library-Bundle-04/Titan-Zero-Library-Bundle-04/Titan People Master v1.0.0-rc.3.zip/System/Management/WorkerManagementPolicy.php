<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Management;
use InvalidArgumentException;
final class WorkerManagementPolicy
{
    private const EDITABLE=['employee_number','preferred_name','legal_name','work_email','phone'];
    private const COMMAND_ONLY=['employment_status','department_id','position_id','team_id','manager_worker_id','authority','leave_balance','leave_ledger'];
    private const FORBIDDEN=['company_id','worker_id','password','avatar'];
    /** @param array<string,mixed> $input */
    public function filter(array $input): array
    {
        foreach(self::COMMAND_ONLY as $field) if(array_key_exists($field,$input)) throw new InvalidArgumentException("{$field} requires an authorized People management command.");
        foreach(self::FORBIDDEN as $field) if(array_key_exists($field,$input)) throw new InvalidArgumentException("{$field} is not writable through Titan People.");
        return array_intersect_key($input,array_fill_keys(self::EDITABLE,true));
    }
}
