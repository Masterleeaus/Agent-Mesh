<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkerProfile extends Model
{
    protected $table = 'titan_people_worker_profiles';
    protected $guarded = ['id', 'company_id'];
    protected $fillable = ['worker_id', 'date_of_birth', 'personal_phone', 'home_address_json', 'timezone', 'locale'];
    protected $casts = ['date_of_birth' => 'date', 'home_address_json' => 'array'];
}
