<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Models;
use Illuminate\Database\Eloquent\Model;
final class EmploymentEventRecord extends Model{protected $table='titan_people_employment_events';protected $guarded=['id','company_id'];protected $fillable=['worker_id','event_id','action','state','effective_at','reason','recorded_by_worker_id','idempotency_key','entity_version','trace_id','correlation_id','causation_id'];protected $casts=['effective_at'=>'immutable_datetime','entity_version'=>'integer'];}
