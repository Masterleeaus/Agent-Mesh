<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Domain\Leave;
use DomainException;
final class LeaveRequest{private string $state='draft';private ?int $submittedBy=null;public function __construct(private readonly int $companyId,private readonly int $workerId,private readonly string $leaveTypeKey){if($companyId<=0||$workerId<=0||$leaveTypeKey==='')throw new DomainException('Leave request identity incomplete.');}
public function submit(int $actorWorkerId):void{if($this->state!=='draft')throw new DomainException('Only draft leave may be submitted.');$this->state='submitted';$this->submittedBy=$actorWorkerId;}
public function approve(int $actorWorkerId):void{if($this->state!=='submitted')throw new DomainException('Only submitted leave may be approved.');if($actorWorkerId===$this->workerId)throw new DomainException('Workers cannot approve their own leave.');$this->state='approved';}
public function reject(int $actorWorkerId):void{if($this->state!=='submitted')throw new DomainException('Only submitted leave may be rejected.');if($actorWorkerId===$this->workerId)throw new DomainException('Workers cannot reject their own governed request.');$this->state='rejected';}
public function cancel(int $actorWorkerId):void{if(!in_array($this->state,['submitted','approved'],true))throw new DomainException('Leave request cannot be cancelled in current state.');$this->state='cancelled';}
public function state():string{return $this->state;}}
