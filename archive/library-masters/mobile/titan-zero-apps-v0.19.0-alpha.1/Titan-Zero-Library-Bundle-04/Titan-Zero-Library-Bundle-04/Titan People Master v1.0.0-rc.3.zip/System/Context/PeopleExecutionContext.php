<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Context;

use InvalidArgumentException;

final readonly class PeopleExecutionContext
{
    public function __construct(
        public int $companyId,
        public string|int $actorSubject,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId = null,
    ) {
        if ($companyId <= 0) {
            throw new InvalidArgumentException('company_id must be a positive authenticated tenant identifier.');
        }
        if ((string) $actorSubject === '') {
            throw new InvalidArgumentException('actor subject is required.');
        }
        if ($traceId === '' || $correlationId === '') {
            throw new InvalidArgumentException('trace_id and correlation_id are required.');
        }
    }
}
