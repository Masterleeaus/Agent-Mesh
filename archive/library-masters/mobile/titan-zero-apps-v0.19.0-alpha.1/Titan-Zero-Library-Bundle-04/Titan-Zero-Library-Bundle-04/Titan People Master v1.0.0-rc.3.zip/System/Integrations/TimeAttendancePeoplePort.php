<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;interface TimeAttendancePeoplePort{public function workerEligibility(int $companyId,string $workerRef):array;}
