<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Contracts;
interface PeopleGovernanceAuthorityPort{public function authorize(string $capability,array $context): array;}
