<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

use DateTimeImmutable;
use DomainException;

final readonly class EmploymentEvent
{
    private const STATES = ['pending', 'active', 'probation', 'suspended', 'leave', 'terminated', 'ended'];

    public function __construct(
        public int $companyId,
        public int $workerId,
        public string $state,
        public DateTimeImmutable $effectiveAt,
        public string $eventId,
        public ?string $reason = null,
    ) {
        if ($companyId <= 0 || $workerId <= 0 || $eventId === '') {
            throw new DomainException('Employment event is incomplete.');
        }
        if (! in_array($state, self::STATES, true)) {
            throw new DomainException('Unsupported employment state.');
        }
    }
}
