<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce;
final readonly class PeopleWorkforceProposal
{
    public function __construct(public string $code,public string $workerRef,public string $severity,public string $summary,public bool $requiresHumanReview=true,public bool $autoMutate=false){}
}
