<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Signals;
interface PeopleSignalDeliveryPort{public function publish(PeopleOutboxEvent $event):string;}
