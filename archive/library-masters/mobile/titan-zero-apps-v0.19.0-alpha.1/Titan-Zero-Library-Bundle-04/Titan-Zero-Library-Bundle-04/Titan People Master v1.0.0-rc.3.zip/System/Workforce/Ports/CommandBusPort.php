<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce\Ports;
interface CommandBusPort { /** @param array<string,mixed> $command @return array<string,mixed> */ public function dispatch(array $command): array; }
