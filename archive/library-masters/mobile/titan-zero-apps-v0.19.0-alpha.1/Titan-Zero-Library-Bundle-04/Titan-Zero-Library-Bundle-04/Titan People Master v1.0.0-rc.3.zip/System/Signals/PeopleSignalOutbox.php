<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Signals;
interface PeopleSignalOutbox { public function append(PeopleOutboxEvent $event): string; }
