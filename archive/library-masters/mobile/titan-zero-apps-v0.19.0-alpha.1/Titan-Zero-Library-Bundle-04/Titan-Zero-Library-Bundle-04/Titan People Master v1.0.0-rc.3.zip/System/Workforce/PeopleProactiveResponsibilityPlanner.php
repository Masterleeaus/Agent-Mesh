<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Workforce;
final class PeopleProactiveResponsibilityPlanner
{
    /** @return array<string,mixed> */
    public function plan(int $companyId,PeopleWorkforceProposal $finding,string $bucket):array
    {
        $key=hash('sha256',$companyId.'|'.$finding->code.'|'.$finding->workerRef.'|'.$bucket);
        return ['company_id'=>$companyId,'finding_code'=>$finding->code,'worker_ref'=>$finding->workerRef,'summary'=>$finding->summary,'severity'=>$finding->severity,'idempotency_key'=>$key,'requires_human_review'=>true,'auto_execute_business_mutation'=>false,'escalation_target'=>in_array($finding->severity,['high','critical'],true)?'manager':'specialist'];
    }
}
