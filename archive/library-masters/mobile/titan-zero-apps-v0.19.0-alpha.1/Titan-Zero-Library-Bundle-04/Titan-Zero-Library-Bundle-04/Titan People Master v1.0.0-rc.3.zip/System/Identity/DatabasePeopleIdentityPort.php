<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Identity;

use App\Extensions\TitanPeople\System\Contracts\PeopleIdentityPort;
use App\Extensions\TitanPeople\System\Contracts\WorkerIdentity;
use App\Extensions\TitanPeople\System\Models\Worker;
use RuntimeException;

final class DatabasePeopleIdentityPort implements PeopleIdentityPort
{
    public function resolveWorker(int $companyId, string|int $subject): WorkerIdentity
    {
        if ($companyId <= 0 || (string) $subject === '') {
            throw new RuntimeException('Tenant and subject are required for worker resolution.');
        }

        $rows = Worker::query()
            ->where('company_id', $companyId)
            ->where('external_subject', (string) $subject)
            ->limit(2)
            ->get(['id', 'company_id', 'external_subject', 'public_id']);

        if ($rows->count() !== 1) {
            throw new RuntimeException('Worker identity resolution failed closed.');
        }

        /** @var Worker $worker */
        $worker = $rows->first();

        return new WorkerIdentity(
            workerId: (int) $worker->getKey(),
            companyId: (int) $worker->getAttribute('company_id'),
            subject: (string) $worker->getAttribute('external_subject'),
            publicId: (string) $worker->getAttribute('public_id'),
        );
    }
}
