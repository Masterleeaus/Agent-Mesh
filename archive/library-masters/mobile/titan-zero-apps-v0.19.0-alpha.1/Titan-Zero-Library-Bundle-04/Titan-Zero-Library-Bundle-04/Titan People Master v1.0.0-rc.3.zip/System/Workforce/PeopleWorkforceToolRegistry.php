<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Workforce;

final class PeopleWorkforceToolRegistry
{
    /** @param array<string,mixed> $manifest */
    public function __construct(private readonly array $manifest) {}

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        $tools = $this->manifest['tools'] ?? [];
        return is_array($tools) ? array_values(array_filter($tools, 'is_array')) : [];
    }
}
