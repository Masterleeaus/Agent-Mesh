<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Domain\People;

use DomainException;

final class OrganisationGraph
{
    /** @var array<int,list<int>> */
    private array $edges = [];

    public function __construct(private readonly int $companyId)
    {
        if ($companyId <= 0) {
            throw new DomainException('Organisation graph requires a tenant.');
        }
    }

    public function add(ReportingLine $line): void
    {
        if ($line->companyId !== $this->companyId) {
            throw new DomainException('Cross-tenant reporting lines are forbidden.');
        }

        $this->edges[$line->managerWorkerId] ??= [];
        if (in_array($line->reportWorkerId, $this->edges[$line->managerWorkerId], true)) {
            return;
        }

        $this->edges[$line->managerWorkerId][] = $line->reportWorkerId;
        if ($this->reaches($line->reportWorkerId, $line->managerWorkerId)) {
            array_pop($this->edges[$line->managerWorkerId]);
            throw new DomainException('Reporting line would create a management cycle.');
        }
    }

    private function reaches(int $from, int $target, array $visited = []): bool
    {
        if ($from === $target) return true;
        if (isset($visited[$from])) return false;
        $visited[$from] = true;
        foreach ($this->edges[$from] ?? [] as $next) {
            if ($this->reaches($next, $target, $visited)) return true;
        }
        return false;
    }
}
