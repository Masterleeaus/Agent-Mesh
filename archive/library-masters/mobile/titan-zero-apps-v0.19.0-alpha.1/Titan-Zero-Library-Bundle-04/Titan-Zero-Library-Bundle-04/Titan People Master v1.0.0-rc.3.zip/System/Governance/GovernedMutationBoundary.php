<?php
declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Governance;
use DomainException;
final class GovernedMutationBoundary{public function authorize(string $actorType,bool $externalGovernanceRequired,?GovernanceDecision $decision):string{if($actorType==='ai'||$externalGovernanceRequired){if($decision===null||!$decision->allowed||trim($decision->executionReceiptId)==='')throw new DomainException('Authoritative governance execution receipt is required.');return $decision->executionReceiptId;}return 'human-policy';}}
