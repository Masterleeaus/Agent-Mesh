<?php

declare(strict_types=1);
namespace App\Extensions\TitanPeople\System\Signals;
final readonly class PeopleChangeEventEmitter
{
    public function __construct(private PeopleSignalOutbox $outbox,private PeopleSignalSanitizer $sanitizer){}
    /** @param array<string,mixed> $facts @param array<string,mixed> $context */
    public function emit(int $companyId,string $eventType,string $aggregateRef,array $facts,array $context):string
    {
        $event=PeopleOutboxEvent::make($companyId,$eventType,$aggregateRef,$this->sanitizer->sanitize($facts),(string)($context['trace_id']??''),(string)($context['correlation_id']??''),(string)($context['causation_id']??''),(string)($context['idempotency_key']??''),$context['occurred_at']??null);
        return $this->outbox->append($event);
    }
}
