<?php
declare(strict_types=1);namespace App\Extensions\TitanPeople\System\Integrations;use DomainException;final class UnavailableCommunicationsPort implements CommunicationsPort{public function requestNotification(int $companyId,array $request,array $context):array{throw new DomainException('Titan Communications port is unavailable.');}}
