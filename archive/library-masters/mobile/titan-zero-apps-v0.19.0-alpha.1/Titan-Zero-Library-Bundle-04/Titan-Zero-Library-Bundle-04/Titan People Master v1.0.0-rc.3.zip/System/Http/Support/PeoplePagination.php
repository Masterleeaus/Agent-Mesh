<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Http\Support;

final class PeoplePagination
{
    public const DEFAULT_LIMIT = 25;
    public const MAX_LIMIT = 100;

    public function limit(int|string|null $requested): int
    {
        if ($requested === null || $requested === '') return self::DEFAULT_LIMIT;
        $value = (int) $requested;
        if ($value < 1) return 1;
        return min(self::MAX_LIMIT, $value);
    }
}
