<?php

declare(strict_types=1);

namespace App\Extensions\TitanPeople\System\Workforce;

final class PeopleWorkforceWorkflowRouter
{
    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        return [
            ['id'=>'people.lifecycle.review','interaction_workflow'=>'titan.interaction.people.lifecycle-review.v1'],
            ['id'=>'people.leave.review','interaction_workflow'=>'titan.interaction.people.leave-review.v1'],
            ['id'=>'people.records.remediation','interaction_workflow'=>'titan.interaction.people.records-remediation.v1'],
        ];
    }
}
