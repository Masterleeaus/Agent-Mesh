<?php

declare(strict_types=1);

return [
    'enabled' => env('TITAN_PEOPLE_ENABLED', true),
    'tenant_key' => 'company_id',
    'private_document_disk' => env('TITAN_PEOPLE_PRIVATE_DISK', 'local'),
    'outbox_dispatch_batch' => (int) env('TITAN_PEOPLE_OUTBOX_BATCH', 100),
    'outbox_dispatch_enabled' => env('TITAN_PEOPLE_OUTBOX_DISPATCH_ENABLED', true),
    'legacy_import_enabled' => env('TITAN_PEOPLE_LEGACY_IMPORT_ENABLED', false),
    'trusted_tenant_user_attributes' => ['company_id'],
    'delegated_admin_permissions' => [
        'titan-people.view',
    ],
];
