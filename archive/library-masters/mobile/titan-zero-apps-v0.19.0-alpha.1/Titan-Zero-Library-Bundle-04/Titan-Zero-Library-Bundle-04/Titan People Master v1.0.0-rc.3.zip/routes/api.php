<?php

declare(strict_types=1);

use App\Extensions\TitanPeople\System\Http\Controllers\PeopleApiController;
use App\Extensions\TitanPeople\System\Http\Middleware\PeopleHostAuthorizeMiddleware;
use Illuminate\Support\Facades\Route;

Route::middleware(['api', 'auth', PeopleHostAuthorizeMiddleware::class.':titan-people.view'])
    ->prefix('api/v1/titan-people')
    ->name('api.v1.titan-people.')
    ->group(function (): void {
        Route::get('/people', [PeopleApiController::class, 'directory'])->name('people.index');
        Route::get('/people/{workerPublicId}', [PeopleApiController::class, 'worker'])->name('people.show');
        Route::get('/organisation', [PeopleApiController::class, 'organisation'])->name('organisation');
        Route::get('/leave', [PeopleApiController::class, 'leave'])->name('leave');
        Route::get('/holidays', [PeopleApiController::class, 'holidays'])->name('holidays');
        Route::get('/lifecycle', [PeopleApiController::class, 'lifecycle'])->name('lifecycle');
        Route::get('/me', [PeopleApiController::class, 'me'])->name('me.show');
        Route::patch('/me', [PeopleApiController::class, 'updateMe'])->name('me.update');
    });
