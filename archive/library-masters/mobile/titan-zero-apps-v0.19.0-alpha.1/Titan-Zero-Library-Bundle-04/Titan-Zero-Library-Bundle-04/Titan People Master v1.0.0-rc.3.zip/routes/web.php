<?php

declare(strict_types=1);

use App\Extensions\TitanPeople\System\Http\Controllers\PeopleDirectoryController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleHolidayController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleLeaveController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleLifecycleController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleMyProfileController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleOrganisationController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeopleOverviewController;
use App\Extensions\TitanPeople\System\Http\Controllers\PeoplePersonController;
use App\Extensions\TitanPeople\System\Http\Middleware\PeopleHostAuthorizeMiddleware;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth', PeopleHostAuthorizeMiddleware::class.':titan-people.view'])
    ->prefix('dashboard/user/titan-people')
    ->name('dashboard.user.titan-people.')
    ->group(function (): void {
        Route::get('/', PeopleOverviewController::class)->name('index');
        Route::get('/directory', PeopleDirectoryController::class)->name('directory.index');
        Route::get('/directory/{workerPublicId}', [PeoplePersonController::class, 'show'])->name('people.show');
        Route::patch('/directory/{workerPublicId}', [PeoplePersonController::class, 'update'])
            ->middleware(PeopleHostAuthorizeMiddleware::class.':titan-people.manage')
            ->name('people.update');
        Route::get('/organisation', PeopleOrganisationController::class)->name('organisation.index');
        Route::get('/leave', PeopleLeaveController::class)->name('leave.index');
        Route::get('/holidays', PeopleHolidayController::class)->name('holidays.index');
        Route::get('/lifecycle', PeopleLifecycleController::class)->name('lifecycle.index');
        Route::get('/my-profile', [PeopleMyProfileController::class, 'show'])->name('profile.show');
        Route::patch('/my-profile', [PeopleMyProfileController::class, 'update'])->name('profile.update');
    });
