<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t=new TitanPeopleTest(); $root=dirname(__DIR__,2);
$f='System/Domain/Employment/EmploymentLifecycleCommandService.php';
$t->assert(is_file($root.'/'.$f),'missing lifecycle command service');
if(is_file($root.'/'.$f)){require_once $root.'/System/Domain/People/EmploymentEvent.php';require_once $root.'/System/Domain/People/EmploymentHistory.php';require_once $root.'/System/Domain/Employment/EmploymentLifecycleCommand.php';require_once $root.'/System/Domain/Employment/EmploymentLifecycleResult.php';require_once $root.'/'.$f;
$svc=new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommandService();
$cmd=new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommand(7,55,9,'terminate','2026-08-22T00:00:00+00:00','reason','idem-1','trace-1','corr-1','cause-1',0);
$r=$svc->execute($cmd);$t->same('terminated',$r->state,'terminate maps to terminated');$t->same(1,$r->version,'version increments');$t->same($r->eventId,$svc->execute($cmd)->eventId,'idempotent command returns same receipt');
try{$svc->execute(new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommand(7,55,9,'reinstate','2026-08-23T00:00:00+00:00','reason','idem-2','trace-2','corr-2','cause-2',0));$t->assert(false,'stale version must fail');}catch(DomainException){$t->assert(true,'stale rejected');}
try{$svc->execute(new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommand(7,55,9,'terminate','2026-08-24T00:00:00+00:00','reason','idem-3','trace-3','corr-3','cause-3',1));$t->assert(false,'double termination must fail');}catch(DomainException){$t->assert(true,'double termination rejected');}}
$t->finish('Pass2 employment lifecycle commands');
