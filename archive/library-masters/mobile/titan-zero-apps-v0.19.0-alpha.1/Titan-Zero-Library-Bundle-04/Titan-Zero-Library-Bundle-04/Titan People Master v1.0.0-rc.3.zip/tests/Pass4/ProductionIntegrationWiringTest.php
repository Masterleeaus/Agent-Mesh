<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t=new TitanPeopleTest();$root=dirname(__DIR__,2);
$provider=(string)file_get_contents($root.'/System/TitanPeopleServiceProvider.php');
foreach([
 'PeopleSignalOutbox::class','DatabasePeopleSignalOutbox::class','PeopleSignalSanitizer::class','PeopleChangeEventEmitter::class','PeopleOutboxDeliveryStore::class','DatabasePeopleOutboxDeliveryStore::class','PeopleSignalDeliveryPort::class','UnavailablePeopleSignalDeliveryPort::class','PeopleOutboxDispatcher::class',
 'TimeAttendancePeoplePort::class','PayrollPeoplePort::class','CredentialsPeoplePort::class','RecruitPeopleIngressPort::class','PerformancePeoplePort::class','OnboardingPeoplePort::class',
 'CommunicationsPort::class','PeopleIntegrationGateway::class','PeopleWorkforceDetector::class','PeopleProactiveResponsibilityPlanner::class','PeopleWorkforceProposalService::class'
] as $needle)$t->contains($needle,$provider,"provider must wire {$needle}");
$t->contains('new EmploymentLifecycleCommandService($app->make(EmploymentLifecycleStore::class), $app->make(PeopleChangeEventEmitter::class))',$provider,'lifecycle service must receive outbox emitter');
$t->finish('Pass4 production integration wiring');
