<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
require_once $root.'/System/Navigation/PeopleNavigation.php';
$items = App\Extensions\TitanPeople\System\Navigation\PeopleNavigation::user();
$t->same(8, count($items), 'People navigation has parent plus seven real children');
$expected = [
    'titan_people_overview' => 'dashboard.user.titan-people.index',
    'titan_people_directory' => 'dashboard.user.titan-people.directory.index',
    'titan_people_organisation' => 'dashboard.user.titan-people.organisation.index',
    'titan_people_leave' => 'dashboard.user.titan-people.leave.index',
    'titan_people_holidays' => 'dashboard.user.titan-people.holidays.index',
    'titan_people_lifecycle' => 'dashboard.user.titan-people.lifecycle.index',
    'titan_people_profile' => 'dashboard.user.titan-people.profile.show',
];
$byKey=[]; foreach($items as $item) $byKey[$item['key']]=$item;
foreach($expected as $key=>$route){$t->same($route,$byKey[$key]['route']??null,"route {$key}");$t->same('titan_people',$byKey[$key]['parent_key']??null,"parent {$key}");}
$registrar=(string)file_get_contents($root.'/System/Navigation/PeopleMenuRegistrar.php');
$t->contains('parent_id', $registrar, 'menu sync resolves parent id');
$t->contains('regenerateMenuCache', $registrar, 'menu sync regenerates cache');
$command=(string)file_get_contents($root.'/System/Console/Commands/SyncPeopleMenuCommand.php');
$t->contains('titan-people:host-sync', $command, 'host sync repair command retained');
$t->finish('Pass3 navigation completion');
