<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
foreach (['System/Http/Middleware/PeopleHostAuthorizeMiddleware.php','System/Queries/PeopleReadRepository.php','System/Queries/EloquentPeopleReadRepository.php'] as $file) {
    $t->assert(is_file($root.'/'.$file), "missing {$file}");
}
$middleware = is_file($root.'/System/Http/Middleware/PeopleHostAuthorizeMiddleware.php') ? (string) file_get_contents($root.'/System/Http/Middleware/PeopleHostAuthorizeMiddleware.php') : '';
foreach (['TitanHostAuthorizationAdapter','TenantCompanyContextResolver','PeopleExecutionContext'] as $needle) $t->contains($needle, $middleware, 'host middleware boundary');
$repo = is_file($root.'/System/Queries/EloquentPeopleReadRepository.php') ? (string) file_get_contents($root.'/System/Queries/EloquentPeopleReadRepository.php') : '';
$t->contains("where('company_id',", $repo, 'read repository tenant scopes queries');
$t->contains("where('public_id',", $repo, 'worker lookup uses opaque public id');
$t->contains('paginate(', $repo, 'directory collections are bounded');
$t->assert(!preg_match('/->get\(\s*\)/', $repo), 'no unbounded bare get() in People read repository');
$t->finish('Pass3 authorization and IDOR boundary');
