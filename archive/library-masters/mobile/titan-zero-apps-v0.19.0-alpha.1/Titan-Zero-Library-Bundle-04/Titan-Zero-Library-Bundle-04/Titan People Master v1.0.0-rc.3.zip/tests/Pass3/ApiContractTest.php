<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$routes = (string) file_get_contents($root.'/routes/api.php');
$t->contains("prefix('api/v1/titan-people')", $routes, 'versioned People API prefix');
$t->assert(!str_contains($routes, 'auth:sanctum'), 'Pass3 API must not assume Sanctum');
$t->assert(!str_contains($routes, 'auth:api'), 'Pass3 API must not use generic auth:api');
$t->contains('PeopleHostAuthorizeMiddleware', $routes, 'API uses exact host authorization adapter middleware');
$t->contains('PeopleApiController', $routes, 'People API controller wired');
$t->assert(!preg_match('/\{(?:worker|id)\}/', $routes), 'API must not expose internal worker IDs in routes');
$pagination = $root.'/System/Http/Support/PeoplePagination.php';
$t->assert(is_file($pagination), 'missing bounded pagination helper');
if (is_file($pagination)) {
    require_once $pagination;
    $p = new App\Extensions\TitanPeople\System\Http\Support\PeoplePagination();
    $t->same(25, $p->limit(null), 'default page size');
    $t->same(100, $p->limit(1000), 'maximum page size');
    $t->same(1, $p->limit(0), 'minimum page size');
}
$t->finish('Pass3 API contracts');
