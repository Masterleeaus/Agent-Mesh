<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Signals/PeopleSignalSanitizer.php',
    'System/Signals/PeopleOutboxEvent.php',
    'System/Signals/RewindPeopleSourceContributor.php',
    'database/migrations/2026_08_22_000014_create_titan_people_signal_outbox.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (array_reduce($files, fn(bool $ok,string $f): bool => $ok && is_file($root.'/'.$f), true)) {
    require_once $root.'/System/Signals/PeopleSignalSanitizer.php';
    require_once $root.'/System/Signals/PeopleOutboxEvent.php';
    require_once $root.'/System/Signals/RewindPeopleSourceContributor.php';
    $sanitizer = new App\Extensions\TitanPeople\System\Signals\PeopleSignalSanitizer();
    $payload = $sanitizer->sanitize([
        'worker_ref' => 'wrk_123',
        'employment_status' => 'probation',
        'event_ref' => 'evt_456',
        'full_name' => 'Private Person',
        'email' => 'private@example.com',
        'phone' => '0400000000',
        'document_contents' => 'SECRET',
        'emergency_contact' => ['name' => 'Private'],
        'bank_account' => '123',
    ]);
    $t->same('wrk_123', $payload['worker_ref'] ?? null, 'worker reference retained');
    $t->same('probation', $payload['employment_status'] ?? null, 'status retained');
    foreach (['full_name','email','phone','document_contents','emergency_contact','bank_account'] as $forbidden) {
        $t->assert(!array_key_exists($forbidden, $payload), "privacy payload must remove {$forbidden}");
    }
    $event = App\Extensions\TitanPeople\System\Signals\PeopleOutboxEvent::make(
        companyId: 9,
        eventType: 'people.employment.changed',
        aggregateRef: 'wrk_123',
        payload: $payload,
        traceId: 'trace-1',
        correlationId: 'corr-1',
        causationId: 'cause-1',
        idempotencyKey: 'idem-1',
    );
    $t->same(9, $event->companyId, 'tenant preserved');
    $t->same('corr-1', $event->correlationId, 'correlation preserved');
    $rewind = (new App\Extensions\TitanPeople\System\Signals\RewindPeopleSourceContributor($sanitizer))->contribute($event);
    $t->same('people.employment.changed', $rewind['fact_type'] ?? null, 'rewind fact type');
    $t->assert(!isset($rewind['document_contents']), 'rewind never copies private document bytes');
    $t->same('wrk_123', $rewind['aggregate_ref'] ?? null, 'rewind keeps source reference');
}

$migration=(string)file_get_contents($root.'/database/migrations/2026_08_22_000014_create_titan_people_signal_outbox.php');
$t->contains('delivery_receipt_id',$migration,'outbox migration must persist external delivery receipt');
$deliveryStore=(string)file_get_contents($root.'/System/Signals/DatabasePeopleOutboxDeliveryStore.php');
$t->contains("'delivery_receipt_id' => \$receiptId",$deliveryStore,'production delivery store must persist external receipt id');
$t->assert(!str_contains($deliveryStore,"where('attempts','<',8)"),'unpublished outbox rows must remain replayable regardless of prior transient failures');

$t->finish('Pass4 Signal and Rewind privacy');
