<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t=new TitanPeopleTest();$root=dirname(__DIR__,2);
foreach([
 'System/Signals/PeopleSignalOutbox.php','System/Signals/PeopleSignalSanitizer.php','System/Signals/PeopleOutboxEvent.php','System/Signals/PeopleChangeEventEmitter.php',
 'System/Domain/Employment/EmploymentLifecycleCommand.php','System/Domain/Employment/EmploymentLifecycleResult.php','System/Domain/Employment/EmploymentLifecycleStore.php','System/Domain/Employment/EmploymentLifecycleCommandService.php'
] as $f) require_once $root.'/'.$f;
final class InMemoryPeopleOutbox implements App\Extensions\TitanPeople\System\Signals\PeopleSignalOutbox{public array $events=[];public function append(App\Extensions\TitanPeople\System\Signals\PeopleOutboxEvent $event):string{$this->events[]=$event;return $event->eventId;}}
$outbox=new InMemoryPeopleOutbox();
$emitter=new App\Extensions\TitanPeople\System\Signals\PeopleChangeEventEmitter($outbox,new App\Extensions\TitanPeople\System\Signals\PeopleSignalSanitizer());
$svc=new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommandService(null,$emitter);
$cmd=new App\Extensions\TitanPeople\System\Domain\Employment\EmploymentLifecycleCommand(7,55,9,'probation','2026-08-22T00:00:00+00:00','review','idem-e1','trace-e1','corr-e1','cause-e1',0);
$r=$svc->execute($cmd);
$t->same(1,count($outbox->events),'lifecycle command must append one outbox fact');
$event=$outbox->events[0]??null;
$t->same('people.employment.lifecycle.changed.v1',$event?->eventType,'lifecycle Signal event type');
$t->same('corr-e1',$event?->correlationId,'lifecycle correlation carried');
$t->same('probation',$event?->payload['employment_status']??null,'lifecycle state included');
$t->assert(!isset($event?->payload['reason']),'free-text lifecycle reason must not enter Signal payload');
$t->same($r->eventId,$event?->payload['event_ref']??null,'authoritative event reference included');
$t->finish('Pass4 lifecycle change emission wiring');
