<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Workforce/PeopleProactiveResponsibilityPlanner.php',
    'System/Workforce/PeopleWorkforceProposal.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (array_reduce($files, fn(bool $ok,string $f): bool => $ok && is_file($root.'/'.$f), true)) {
    require_once $root.'/System/Workforce/PeopleWorkforceProposal.php';
    require_once $root.'/System/Workforce/PeopleProactiveResponsibilityPlanner.php';
    $planner = new App\Extensions\TitanPeople\System\Workforce\PeopleProactiveResponsibilityPlanner();
    $finding = new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceProposal(
        code: 'people.leave.decision_overdue', workerRef: 'wrk_1', severity: 'high', summary: 'Leave decision overdue', requiresHumanReview: true, autoMutate: false
    );
    $one = $planner->plan(7, $finding, '2026-08-22');
    $two = $planner->plan(7, $finding, '2026-08-22');
    $t->same($one['idempotency_key'] ?? null, $two['idempotency_key'] ?? null, 'same condition/day must be idempotent');
    $t->same('manager', $one['escalation_target'] ?? null, 'high severity escalates to manager');
    $t->same(false, $one['auto_execute_business_mutation'] ?? null, 'proactive task cannot silently mutate business state');
    $t->same(7, $one['company_id'] ?? null, 'tenant preserved');
}
$t->finish('Pass4 proactive responsibilities');
