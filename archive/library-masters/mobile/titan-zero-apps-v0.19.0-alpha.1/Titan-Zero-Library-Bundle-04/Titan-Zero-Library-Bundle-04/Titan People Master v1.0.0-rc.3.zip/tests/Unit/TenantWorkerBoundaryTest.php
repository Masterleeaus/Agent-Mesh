<?php

declare(strict_types=1);

require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Context/PeopleExecutionContext.php',
    'System/Context/TenantCompanyContextResolver.php',
    'System/Contracts/PeopleIdentityPort.php',
    'System/Contracts/WorkerIdentity.php',
    'tests/Support/InMemoryPeopleIdentityPort.php',
    'System/Models/Worker.php',
];
foreach ($files as $file) {
    $t->assert(is_file($root.'/'.$file), "missing {$file}");
}
$runtimeFiles = array_values(array_filter($files, static fn (string $file): bool => $file !== 'System/Models/Worker.php'));
if (array_reduce($files, fn(bool $carry, string $file): bool => $carry && is_file($root.'/'.$file), true)) {
    foreach ($runtimeFiles as $file) require_once $root.'/'.$file;

    $port = new TitanPeopleTests\Support\InMemoryPeopleIdentityPort([
        new App\Extensions\TitanPeople\System\Contracts\WorkerIdentity(101, 1, 'host-user:7', 'worker-a'),
        new App\Extensions\TitanPeople\System\Contracts\WorkerIdentity(202, 2, 'host-user:7', 'worker-b'),
    ]);
    $a = $port->resolveWorker(1, 'host-user:7');
    $b = $port->resolveWorker(2, 'host-user:7');
    $t->same(101, $a->workerId, 'tenant A worker resolution');
    $t->same(202, $b->workerId, 'tenant B worker resolution');
    $t->assert($a->workerId !== $b->workerId, 'same subject must remain tenant isolated');

    try {
        $port->resolveWorker(3, 'host-user:7');
        $t->assert(false, 'missing tenant worker must fail closed');
    } catch (RuntimeException) {
        $t->assert(true, 'missing tenant failed closed');
    }

    $resolver = new App\Extensions\TitanPeople\System\Context\TenantCompanyContextResolver();
    try {
        $resolver->resolve([]);
        $t->assert(false, 'missing authenticated tenant context must fail closed');
    } catch (RuntimeException) {
        $t->assert(true, 'tenant context failed closed');
    }
    $t->same(9, $resolver->resolve(['company_id' => 9]), 'trusted authenticated tenant context');
    try {
        $resolver->resolve(['tenant_id' => 9]);
        $t->assert(false, 'legacy tenant_id must not be canonical authority');
    } catch (RuntimeException) {
        $t->assert(true, 'legacy tenant id rejected');
    }
}

$t->finish('tenant worker boundary');
