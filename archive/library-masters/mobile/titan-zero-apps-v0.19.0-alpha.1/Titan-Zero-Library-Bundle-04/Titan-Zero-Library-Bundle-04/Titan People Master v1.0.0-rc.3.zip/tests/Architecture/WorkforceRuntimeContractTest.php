<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Context/PeopleExecutionContext.php',
    'System/Workforce/PeopleWorkforceManifestProvider.php',
    'System/Workforce/PeopleWorkforceExecutionContext.php',
    'System/Workforce/PeopleWorkforceToolRegistry.php',
    'System/Workforce/PeopleWorkforceWorkflowRouter.php',
    'System/Workforce/PeopleWorkforceWizardRegistry.php',
    'System/Workforce/Ports/CommandBusPort.php',
    'System/Workforce/Ports/RiskPort.php',
    'System/Workforce/Ports/AssurancePort.php',
    'System/Workforce/Ports/AutonomyPort.php',
    'System/Workforce/Ports/WorkforceTaskPort.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (array_reduce($files, fn(bool $ok,string $f): bool => $ok && is_file($root.'/'.$f), true)) {
    foreach ($files as $file) require_once $root.'/'.$file;
    $provider = new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceManifestProvider($root.'/resources/workforce/workforce-manifest.json');
    $manifest = $provider->all();
    $t->same('2.0', $manifest['schema_version'] ?? null, 'manifest provider must return v2.0');

    $registry = new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceToolRegistry($manifest);
    $originalReadTools = ['people.worker.read','people.leave.read','people.lifecycle.read','people.records.read'];
    foreach ($registry->all() as $tool) {
        if (in_array($tool['id'] ?? '', $originalReadTools, true)) {
            $t->same(false, $tool['writes_state'] ?? null, 'original People read tools must remain read-only');
            $t->same('local_read', $tool['execution'] ?? null, 'original People read tools remain local reads');
        } elseif (($tool['writes_state'] ?? false) === true) {
            $t->same('command_bus', $tool['execution'] ?? null, 'later state-changing tools must use Command Bus');
        }
    }

    $ctx = new App\Extensions\TitanPeople\System\Context\PeopleExecutionContext(12, 'host-user:2', 'trace', 'corr');
    $wf = new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceExecutionContext($ctx);
    $t->same(12, $wf->companyId(), 'workforce execution context tenant');
    foreach ((new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceWorkflowRouter())->all() as $workflow) {
        $t->assert(trim((string)($workflow['id'] ?? '')) !== '', 'workforce workflow id required');
        $t->assert(trim((string)($workflow['interaction_workflow'] ?? '')) !== '', 'interaction workflow reference required');
    }
    $t->same([], (new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceWizardRegistry())->all(), 'People has no workforce wizards yet');
}
$t->finish('Workforce runtime reference integrity');
