<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Workforce/PeopleWorkforceDetector.php',
    'System/Workforce/PeopleWorkforceProposal.php',
    'System/Workforce/PeopleWorkforceProposalService.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (array_reduce($files, fn(bool $ok,string $f): bool => $ok && is_file($root.'/'.$f), true)) {
    require_once $root.'/System/Workforce/PeopleWorkforceProposal.php';
    require_once $root.'/System/Workforce/PeopleWorkforceDetector.php';
    $detector = new App\Extensions\TitanPeople\System\Workforce\PeopleWorkforceDetector();
    $findings = $detector->detect([
        'worker_ref' => 'wrk_1',
        'profile_complete' => false,
        'employment_status' => 'probation',
        'probation_review_due_days' => -2,
        'pending_lifecycle_actions' => 1,
        'leave_balance_delta' => 2.5,
        'leave_decision_overdue_days' => 4,
        'policy_acknowledgement_gap' => true,
        'people_document_expired' => true,
    ]);
    $codes = array_map(fn($f) => $f->code, $findings);
    foreach ([
        'people.record.incomplete',
        'people.lifecycle.pending',
        'people.probation.review_overdue',
        'people.leave.balance_anomaly',
        'people.leave.decision_overdue',
        'people.policy.ack_gap',
        'people.document.expired',
    ] as $code) $t->assert(in_array($code, $codes, true), "missing detector {$code}");
    foreach ($findings as $finding) {
        $t->same(false, $finding->autoMutate, "detector {$finding->code} must never auto-mutate");
        $t->assert($finding->requiresHumanReview, "detector {$finding->code} requires review");
    }
    $manifest = json_decode((string) file_get_contents($root.'/resources/workforce/workforce-manifest.json'), true, 512, JSON_THROW_ON_ERROR);
    $tools = $manifest['tools'] ?? [];
    $stateTools = array_values(array_filter($tools, fn(array $tool): bool => ($tool['writes_state'] ?? false) === true));
    $t->assert($stateTools !== [], 'Pass4 must define governed state-changing proposal tools');
    foreach ($stateTools as $tool) {
        $t->same('command_bus', $tool['execution'] ?? null, 'state-changing Workforce tools must use Command Bus');
        $t->assert(($tool['self_approval'] ?? false) === false, 'state-changing Workforce tools must not self-approve');
    }
}
$t->finish('Pass4 governed Workforce tools');
