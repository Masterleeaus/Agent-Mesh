<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Navigation/PeopleNavigation.php',
    'System/Navigation/PeopleMenuRegistrar.php',
    'System/Authorization/PeopleAuthorization.php',
    'routes/web.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (is_file($root.'/System/Navigation/PeopleNavigation.php')) {
    require_once $root.'/System/Navigation/PeopleNavigation.php';
    $items = App\Extensions\TitanPeople\System\Navigation\PeopleNavigation::user();
    $t->assert(count($items) >= 2, 'navigation must retain People parent + implemented overview');
    $t->assert(array_key_exists('parent_key', $items[0]), 'People parent must declare parent_key');
    $t->same(null, $items[0]['parent_key'], 'People parent must be top-level');
    $t->same('titan_people', $items[1]['parent_key'] ?? null, 'overview must be nested under People');
    $t->same('dashboard.user.titan-people.index', $items[1]['route'] ?? null, 'overview route');
}
if (is_file($root.'/System/Authorization/PeopleAuthorization.php')) {
    require_once $root.'/System/Authorization/PeopleAuthorization.php';
    $auth = new App\Extensions\TitanPeople\System\Authorization\PeopleAuthorization();
    $t->same(false, $auth->allows([], 'titan-people.view'), 'authorization must deny by default');
    $t->same(true, $auth->allows(['permissions' => ['titan-people.view']], 'titan-people.view'), 'explicit permission grants');
}
$registrar = is_file($root.'/System/Navigation/PeopleMenuRegistrar.php') ? (string) file_get_contents($root.'/System/Navigation/PeopleMenuRegistrar.php') : '';
foreach (['MenuContributionRegistry','ContributionRegistry','MenuService','Schema::hasTable','parent_id','order','is_active'] as $needle) {
    $t->contains($needle, $registrar, 'menu registrar host compatibility');
}
$routes = is_file($root.'/routes/web.php') ? (string) file_get_contents($root.'/routes/web.php') : '';
$t->contains("->name('index')", $routes, 'overview route name');
$t->assert(!preg_match('/Route::get\([^\n]+(?:delete|remove|terminate|suspend|approve|reject)/i', $routes), 'no state-changing GET route');
$t->finish('navigation and authorization baseline');
