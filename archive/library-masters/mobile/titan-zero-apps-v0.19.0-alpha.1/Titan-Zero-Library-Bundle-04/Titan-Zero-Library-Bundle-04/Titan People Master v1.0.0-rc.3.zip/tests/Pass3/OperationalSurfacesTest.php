<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$routes = (string) file_get_contents($root.'/routes/web.php');
$expected = [
    'index' => 'PeopleOverviewController',
    'directory.index' => 'PeopleDirectoryController',
    'people.show' => 'PeoplePersonController',
    'organisation.index' => 'PeopleOrganisationController',
    'leave.index' => 'PeopleLeaveController',
    'holidays.index' => 'PeopleHolidayController',
    'lifecycle.index' => 'PeopleLifecycleController',
    'profile.show' => 'PeopleMyProfileController',
];
foreach ($expected as $name => $controller) {
    $t->contains($controller, $routes, "route controller {$controller}");
    $t->contains("->name('{$name}')", $routes, "route name {$name}");
}
foreach (['overview','directory','person','organisation','leave/index','holidays','lifecycle','profile'] as $view) {
    $file = $root.'/resources/views/'.$view.'.blade.php';
    $t->assert(is_file($file), "missing operational view {$view}");
    if (is_file($file)) {
        $body = (string) file_get_contents($file);
        $t->assert(trim($body) !== '', "empty operational view {$view}");
        $t->assert(!preg_match('/coming soon|not implemented/i', $body), "placeholder content in {$view}");
    }
}
$t->assert(!preg_match('/Route::get\([^\n]+(?:update|delete|remove|terminate|suspend|approve|reject)/i', $routes), 'no state-changing GET routes');
$t->finish('Pass3 operational browser surfaces');
