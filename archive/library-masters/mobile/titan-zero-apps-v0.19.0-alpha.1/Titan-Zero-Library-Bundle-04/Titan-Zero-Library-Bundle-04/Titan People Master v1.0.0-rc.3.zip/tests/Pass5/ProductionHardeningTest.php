<?php
declare(strict_types=1);
require __DIR__.'/../bootstrap.php';

use App\Extensions\TitanPeople\System\Domain\Documents\LaravelPrivatePeopleDocumentStorage;
use App\Extensions\TitanPeople\System\Signals\DatabasePeopleOutboxDeliveryStore;

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root.'/System/TitanPeopleServiceProvider.php');
$storage = file_get_contents($root.'/System/Domain/Documents/LaravelPrivatePeopleDocumentStorage.php');
$outbox = file_get_contents($root.'/System/Signals/DatabasePeopleOutboxDeliveryStore.php');
$config = file_get_contents($root.'/config/people.php');
$upgrade = file_get_contents($root.'/docs/UPGRADE.md');
$uninstall = file_get_contents($root.'/docs/UNINSTALL.md');
$ops = file_get_contents($root.'/docs/OPERATIONS.md');

$assert = static function (bool $ok, string $message): void {
    if (!$ok) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
};

$migrationText = implode("\n", array_map(static fn (string $file): string => (string) file_get_contents($file), glob($root.'/database/migrations/*.php') ?: []));
$assert(str_contains($migrationText, "unique(['company_id','idempotency_key']"), 'outbox idempotency uniqueness must be tenant scoped');
$assert(str_contains($migrationText, "index(['company_id','published_at','id']"), 'outbox delivery scan must have tenant/published/id index');
$assert(str_contains($migrationText, "unique(['company_id','document_id','revision']"), 'document revisions must be tenant/document/revision unique');
$assert(str_contains($migrationText, "unique(['company_id','worker_id','idempotency_key']"), 'employment lifecycle idempotency must be tenant/worker scoped');

$assert(str_contains($provider, 'withoutOverlapping'), 'outbox dispatch schedule must prevent overlapping workers');
$assert(str_contains($provider, 'onOneServer'), 'outbox dispatch schedule must be single-server safe');
$assert(str_contains($provider, 'titan-people:dispatch-outbox'), 'production outbox dispatch command must be registered');
$assert(str_contains($storage, 'private/titan-people/'), 'private document storage must reject paths outside Titan People prefix');
$assert(str_contains($outbox, "where('company_id'"), 'outbox delivery mutations must include tenant scope');
$assert(str_contains($config, 'outbox_dispatch_batch'), 'bounded outbox dispatch batch must be configurable');
$assert(str_contains($upgrade, '0.1.0-alpha.4') && str_contains($upgrade, '1.0.0-rc.2'), 'upgrade doc must describe alpha.4 to rc.1');
$assert(str_contains($uninstall, 'retain') && str_contains($uninstall, 'configuration'), 'uninstall retention/config cleanup must be explicit');
$assert(str_contains($ops, 'outbox') && str_contains($ops, 'health'), 'operations runbook must include outbox health');

echo "PASS ProductionHardeningTest\n";
