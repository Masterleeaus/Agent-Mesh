<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t=new TitanPeopleTest();$root=dirname(__DIR__,2);
$files=['System/Signals/PeopleSignalDeliveryPort.php','System/Signals/PeopleOutboxDeliveryStore.php','System/Signals/PeopleOutboxDispatcher.php','System/Signals/PeopleSignalSanitizer.php','System/Signals/PeopleOutboxEvent.php'];
foreach($files as $f)$t->assert(is_file($root.'/'.$f),"missing {$f}");
if(array_reduce($files,fn(bool $ok,string $f):bool=>$ok&&is_file($root.'/'.$f),true)){
 foreach($files as $f)require_once $root.'/'.$f;
 final class Pass4DeliveryPort implements App\Extensions\TitanPeople\System\Signals\PeopleSignalDeliveryPort{public array $sent=[];public bool $fail=false;public function publish(App\Extensions\TitanPeople\System\Signals\PeopleOutboxEvent $event):string{if($this->fail)throw new RuntimeException('down');$this->sent[]=$event;return 'receipt-1';}}
 final class Pass4DeliveryStore implements App\Extensions\TitanPeople\System\Signals\PeopleOutboxDeliveryStore{public array $published=[];public array $failed=[];public function pending(int $limit):array{return $this->events??[];}public array $events=[];public function markPublished(int $companyId,string $eventId,string $receiptId):void{$this->published[$eventId]=[$companyId,$receiptId];}public function markFailed(int $companyId,string $eventId,string $error):void{$this->failed[$eventId]=[$companyId,$error];}}
 $event=App\Extensions\TitanPeople\System\Signals\PeopleOutboxEvent::make(3,'people.worker.changed.v1','wrk_public',['worker_ref'=>'wrk_public'],'t','c','cause','idem','2026-08-22T00:00:00+00:00');
 $store=new Pass4DeliveryStore();$store->events=[$event];$port=new Pass4DeliveryPort();$dispatcher=new App\Extensions\TitanPeople\System\Signals\PeopleOutboxDispatcher($store,$port);
 $t->same(1,$dispatcher->dispatch(25),'one event delivered');$t->same([3,'receipt-1'],$store->published[$event->eventId]??null,'tenant-scoped delivery receipt persisted');
 $store2=new Pass4DeliveryStore();$store2->events=[$event];$port2=new Pass4DeliveryPort();$port2->fail=true;$dispatcher2=new App\Extensions\TitanPeople\System\Signals\PeopleOutboxDispatcher($store2,$port2);
 $t->same(0,$dispatcher2->dispatch(25),'failed delivery not counted as published');$t->assert(isset($store2->failed[$event->eventId]),'failed delivery state persisted');
}
$t->finish('Pass4 durable outbox delivery');
