<?php

declare(strict_types=1);

require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);

foreach (['extension.json','extension.manifest.json','System/TitanPeopleServiceProvider.php','config/people.php','routes/web.php','routes/api.php'] as $path) {
    $t->assert(is_file($root.'/'.$path), "missing {$path}");
}

$manifestPath = $root.'/extension.manifest.json';
$manifest = is_file($manifestPath) ? json_decode((string) file_get_contents($manifestPath), true) : null;
$t->assert(is_array($manifest), 'extension.manifest.json must be valid JSON');
if (is_array($manifest)) {
    $t->same('2.2', $manifest['schema_version'] ?? null, 'manifest schema version');
    $t->same('titan-people', $manifest['key'] ?? null, 'manifest key');
    $t->same('TitanPeople', $manifest['folder'] ?? null, 'manifest folder');
    $t->same('App\\Extensions\\TitanPeople\\System\\TitanPeopleServiceProvider', $manifest['provider'] ?? null, 'manifest provider');
    $t->same('business-domain', $manifest['architecture']['profile'] ?? null, 'primary profile');
    $mods = $manifest['architecture']['modifiers'] ?? [];
    sort($mods);
    $expected = ['autonomy-aware','communications-consumer','regulated','rewind-source-contributor','workforce-aware'];
    sort($expected);
    $t->same($expected, $mods, 'architecture modifiers');
    $t->same('titan.production.core.v1', $manifest['architecture']['production_core'] ?? null, 'production core inheritance');
    $t->same('company_id', $manifest['data']['tenant_key'] ?? null, 'tenant key');
    $t->same(true, $manifest['workforce']['enabled'] ?? null, 'workforce enabled');
    $t->same('extension', $manifest['workforce']['source_of_truth'] ?? null, 'workforce source');
    $t->same('titan.workforce.manifest.v2', $manifest['workforce']['discovery_contract'] ?? null, 'workforce discovery contract');
    $t->same(false, $manifest['workforce']['direct_domain_writes'] ?? null, 'workforce direct writes');
    $t->same(true, $manifest['workforce']['state_writes_via_command_bus'] ?? null, 'workforce command bus');
    $t->same(false, $manifest['workforce']['auto_activate'] ?? null, 'workforce auto activation');
}

$providerPath = $root.'/System/TitanPeopleServiceProvider.php';
$provider = is_file($providerPath) ? (string) file_get_contents($providerPath) : '';
$t->contains('namespace App\\Extensions\\TitanPeople\\System;', $provider, 'provider namespace');
$t->contains('final class TitanPeopleServiceProvider', $provider, 'provider class');

$t->finish('Titan People Blueprint shell contract');
