<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$path = $root.'/resources/workforce/workforce-manifest.json';
$t->assert(is_file($path), 'missing Workforce Manifest 2.0');
$m = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
$t->assert(is_array($m), 'workforce manifest must be valid JSON');
if (is_array($m)) {
    $t->same('2.0', $m['schema_version'] ?? null, 'workforce schema version');
    $t->same('titan-ai-workforce', $m['ownership']['source_of_truth'] ?? null, 'workforce definition ownership');
    $t->same(true, $m['ownership']['central_workforce_owns_definitions'] ?? null, 'central workforce must own definitions');
    $t->same(false, $m['ownership']['auto_seed_staff'] ?? null, 'roles must not auto activate');
    $t->same(true, $m['runtime']['fail_closed'] ?? null, 'workforce runtime must fail closed');
    $t->same(true, $m['runtime']['execution_receipt_required'] ?? null, 'write execution receipts required');
    $roles = $m['roles'] ?? [];
    $names = array_column($roles, 'name');
    foreach (['People Manager','Leave & Absence Specialist','Employee Lifecycle Specialist','Workforce Records Specialist'] as $name) {
        $t->assert(in_array($name, $names, true), "missing role {$name}");
    }
    foreach ($roles as $role) {
        $desired = $role['autonomy']['desired']['score'] ?? 101;
        $initial = $role['autonomy']['initial_earned_ceiling']['score'] ?? 101;
        $t->assert(is_int($desired) && $desired >= 0 && $desired <= 100, 'role desired autonomy score must be 0..100');
        $t->assert(is_int($initial) && $initial >= 0 && $initial <= 100, 'role initial autonomy ceiling must be 0..100');
        $t->same('titan_autonomy', $role['autonomy']['effective_authority']['source'] ?? null, 'effective authority source');
    }
    foreach (($m['tools'] ?? []) as $tool) {
        if (($tool['mode'] ?? '') === 'write') {
            $t->same('command_bus', $tool['execution'] ?? null, 'workforce writes must use command bus');
        }
    }
}
$t->finish('Workforce Manifest 2.0 semantic baseline');
