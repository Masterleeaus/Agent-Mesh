<?php

declare(strict_types=1);

final class TitanPeopleTest
{
    /** @var list<string> */
    private array $failures = [];

    public function assert(bool $condition, string $message): void
    {
        if (! $condition) {
            $this->failures[] = $message;
        }
    }

    public function same(mixed $expected, mixed $actual, string $message): void
    {
        $this->assert($expected === $actual, $message.' expected='.var_export($expected, true).' actual='.var_export($actual, true));
    }

    public function contains(string $needle, string $haystack, string $message): void
    {
        $this->assert(str_contains($haystack, $needle), $message.' missing='.$needle);
    }

    public function finish(string $label): never
    {
        if ($this->failures !== []) {
            foreach ($this->failures as $failure) {
                fwrite(STDERR, "FAIL: {$failure}\n");
            }
            exit(1);
        }

        fwrite(STDOUT, "PASS: {$label}\n");
        exit(0);
    }
}
