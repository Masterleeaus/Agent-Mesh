<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$ports = [
    'System/Integrations/TimeAttendancePeoplePort.php',
    'System/Integrations/PayrollPeoplePort.php',
    'System/Integrations/CredentialsPeoplePort.php',
    'System/Integrations/RecruitPeopleIngressPort.php',
    'System/Integrations/PerformancePeoplePort.php',
    'System/Integrations/OnboardingPeoplePort.php',
    'System/Integrations/CommunicationsPort.php',
    'System/Integrations/PeopleIntegrationGateway.php',
];
foreach ($ports as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
$dir = $root.'/System/Integrations';
if (is_dir($dir)) {
    $forbidden = [
        'attendance_logs','attendances','shifts','shift_assignments','pay_runs','payroll_runs','payroll_bank_accounts','bank_accounts',
        'credentials_private','credential_evidence','recruit_candidates','performance_reviews','onboarding_private','communications_messages'
    ];
    foreach (glob($dir.'/*.php') ?: [] as $file) {
        $body = strtolower((string) file_get_contents($file));
        foreach ($forbidden as $needle) $t->assert(!str_contains($body, $needle), basename($file)." must not access peer private table {$needle}");
    }
}
$t->finish('Pass4 cross-extension ports');
