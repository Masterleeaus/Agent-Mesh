<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Domain/People/ReportingLine.php',
    'System/Domain/People/OrganisationGraph.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (is_file($root.'/'.$files[0]) && is_file($root.'/'.$files[1])) {
    foreach ($files as $file) require_once $root.'/'.$file;
    $graph = new App\Extensions\TitanPeople\System\Domain\People\OrganisationGraph(7);
    $graph->add(new App\Extensions\TitanPeople\System\Domain\People\ReportingLine(7, 1, 2));
    $graph->add(new App\Extensions\TitanPeople\System\Domain\People\ReportingLine(7, 2, 3));
    try {
        $graph->add(new App\Extensions\TitanPeople\System\Domain\People\ReportingLine(7, 3, 1));
        $t->assert(false, 'reporting cycle must be rejected');
    } catch (DomainException) {
        $t->assert(true, 'reporting cycle rejected');
    }
    try {
        $graph->add(new App\Extensions\TitanPeople\System\Domain\People\ReportingLine(8, 4, 5));
        $t->assert(false, 'cross-tenant reporting line must be rejected');
    } catch (DomainException) {
        $t->assert(true, 'cross-tenant reporting line rejected');
    }
}
$t->finish('tenant reporting-line graph');
