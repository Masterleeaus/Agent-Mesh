<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$migrations = glob($root.'/database/migrations/*.php') ?: [];
$t->assert(count($migrations) >= 7, 'Pass 1 must create worker + organisation/employment migrations');
$forbidden = ['users','attendances','attendance_breaks','attendance_logs','attendance_regularizations','shifts','expense_requests','expense_types','bank_accounts'];
foreach ($migrations as $file) {
    $src = (string) file_get_contents($file);
    $t->contains('company_id', $src, basename($file).' must be tenant scoped');
    foreach ($forbidden as $table) {
        $t->assert(!preg_match("/(Schema::table|Schema::create)\\(['\"]".preg_quote($table, '/')."['\"]/", $src), basename($file)." must not mutate forbidden table {$table}");
    }
}
$t->finish('People migration ownership boundary');
