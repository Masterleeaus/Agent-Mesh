<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$files = [
    'System/Domain/People/EmploymentEvent.php',
    'System/Domain/People/EmploymentRelationship.php',
    'System/Domain/People/EmploymentHistory.php',
];
foreach ($files as $file) $t->assert(is_file($root.'/'.$file), "missing {$file}");
if (array_reduce($files, fn(bool $ok, string $f): bool => $ok && is_file($root.'/'.$f), true)) {
    foreach ($files as $file) require_once $root.'/'.$file;
    $history = new App\Extensions\TitanPeople\System\Domain\People\EmploymentHistory(4, 55);
    $first = new App\Extensions\TitanPeople\System\Domain\People\EmploymentEvent(4, 55, 'active', new DateTimeImmutable('2026-01-01'), 'evt-1');
    $history->append($first);
    $history->append(new App\Extensions\TitanPeople\System\Domain\People\EmploymentEvent(4, 55, 'suspended', new DateTimeImmutable('2026-06-01'), 'evt-2'));
    $t->same('suspended', $history->stateAt(new DateTimeImmutable('2026-08-01')), 'effective-dated state');
    $t->same('active', $history->stateAt(new DateTimeImmutable('2026-03-01')), 'historical effective state');
    try {
        $history->append(new App\Extensions\TitanPeople\System\Domain\People\EmploymentEvent(4, 55, 'active', new DateTimeImmutable('2026-02-01'), 'evt-3'));
        $t->assert(false, 'out-of-order lifecycle history must be rejected');
    } catch (DomainException) {
        $t->assert(true, 'out-of-order lifecycle event rejected');
    }
    try {
        $history->append(new App\Extensions\TitanPeople\System\Domain\People\EmploymentEvent(4, 55, 'terminated', new DateTimeImmutable('2026-07-01'), 'evt-2'));
        $t->assert(false, 'duplicate event id must be rejected');
    } catch (DomainException) {
        $t->assert(true, 'duplicate event id rejected');
    }
}
$t->finish('employment lifecycle history');
