<?php

declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t = new TitanPeopleTest();
$root = dirname(__DIR__, 2);
$file = $root.'/System/SelfService/SelfServiceProfilePolicy.php';
$t->assert(is_file($file), 'missing self-service profile policy');
if (is_file($file)) {
    require_once $file;
    $policy = new App\Extensions\TitanPeople\System\SelfService\SelfServiceProfilePolicy();
    $t->same(['personal_email','personal_phone','home_address','emergency_contacts','timezone','locale'], $policy->editableFields(), 'self-service allowlist');
    $t->same(true, $policy->canEdit('personal_email'), 'personal email self edit');
    foreach (['employment_status','department_id','manager_worker_id','authority','leave_balance','password','avatar','company_id','worker_id'] as $field) {
        $t->same(false, $policy->canEdit($field), "protected self-service field {$field}");
    }
    $filtered = $policy->filter(['personal_email'=>'a@example.test','employment_status'=>'terminated','worker_id'=>999,'timezone'=>'Australia/Melbourne']);
    $t->same(['personal_email'=>'a@example.test','timezone'=>'Australia/Melbourne'], $filtered, 'self-service filter strips protected fields');
}
$service = $root.'/System/SelfService/SelfServiceProfileService.php';
$t->assert(is_file($service), 'missing self-service service');
if (is_file($service)) {
    $src = (string) file_get_contents($service);
    $t->contains('PeopleIdentityPort', $src, 'self-service derives worker through identity port');
    $t->assert(!str_contains($src, "input('worker_id')"), 'self-service must not trust caller worker id');
    $t->assert(!str_contains($src, "input('company_id')"), 'self-service must not trust caller tenant id');
}
$t->finish('Pass3 self-service boundary');
