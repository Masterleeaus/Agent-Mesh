<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=[];$assert=function(bool $ok,string $m)use(&$fail){if(!$ok)$fail[]=$m;};
$resolver=(string)file_get_contents($root.'/System/Context/TenantCompanyContextResolver.php');
$middleware=(string)file_get_contents($root.'/System/Http/Middleware/PeopleHostAuthorizeMiddleware.php');
$assert(str_contains($resolver,"['company_id']"),'People resolver must consume canonical company_id.');
$assert(!str_contains($resolver,'authenticated_company_id'),'People resolver must not invent authenticated_company_id as a second context key.');
$assert(str_contains($middleware,"'company_id' => \$this->trustedCompanyId"),'People middleware must pass company_id unchanged into resolver.');
$companyPos=strpos($middleware,'$companyId = $this->tenantResolver->resolve');
$authPos=strpos($middleware,'$this->authorization->allows');
$assert($companyPos!==false&&$authPos!==false&&$companyPos<$authPos,'company_id must be established before authorization.');
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "Agent2 Pass12 canonical company context PASS\n";
