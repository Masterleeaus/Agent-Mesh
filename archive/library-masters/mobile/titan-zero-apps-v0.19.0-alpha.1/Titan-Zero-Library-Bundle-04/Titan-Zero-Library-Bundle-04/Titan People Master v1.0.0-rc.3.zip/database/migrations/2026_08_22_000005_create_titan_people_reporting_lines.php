<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_reporting_lines')) return;
        Schema::create('titan_people_reporting_lines', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('manager_worker_id');
            $table->unsignedBigInteger('report_worker_id');
            $table->dateTime('effective_from');
            $table->dateTime('effective_to')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'manager_worker_id', 'report_worker_id', 'effective_from'], 'tp_reporting_line_uq');
            $table->index(['company_id', 'report_worker_id', 'effective_to'], 'tp_reporting_report_idx');
            $table->index(['company_id', 'manager_worker_id', 'effective_to'], 'tp_reporting_manager_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_reporting_lines'); }
};
