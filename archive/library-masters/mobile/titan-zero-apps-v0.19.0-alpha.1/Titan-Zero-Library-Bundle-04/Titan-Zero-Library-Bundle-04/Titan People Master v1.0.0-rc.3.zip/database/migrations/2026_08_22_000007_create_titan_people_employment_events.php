<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_employment_events')) return;
        Schema::create('titan_people_employment_events', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('worker_id');
            $table->uuid('event_id');
            $table->string('state', 40);
            $table->dateTime('effective_at');
            $table->string('reason', 500)->nullable();
            $table->unsignedBigInteger('recorded_by_worker_id')->nullable();
            $table->string('trace_id', 100)->nullable();
            $table->string('correlation_id', 100)->nullable();
            $table->string('causation_id', 100)->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'event_id'], 'tp_employment_event_uq');
            $table->index(['company_id', 'worker_id', 'effective_at'], 'tp_employment_event_worker_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_employment_events'); }
};
