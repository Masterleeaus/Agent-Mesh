<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_workers')) return;
        Schema::create('titan_people_workers', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->uuid('public_id');
            $table->string('external_subject', 191);
            $table->string('employee_number', 100)->nullable();
            $table->string('preferred_name')->nullable();
            $table->string('legal_name')->nullable();
            $table->string('work_email')->nullable();
            $table->string('personal_email')->nullable();
            $table->string('phone')->nullable();
            $table->string('employment_status', 40)->default('pending');
            $table->timestamps();
            $table->softDeletes();

            $table->unique(['company_id', 'external_subject'], 'tp_workers_tenant_subject_uq');
            $table->unique(['company_id', 'public_id'], 'tp_workers_tenant_public_uq');
            $table->index(['company_id', 'employment_status'], 'tp_workers_tenant_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_people_workers');
    }
};
