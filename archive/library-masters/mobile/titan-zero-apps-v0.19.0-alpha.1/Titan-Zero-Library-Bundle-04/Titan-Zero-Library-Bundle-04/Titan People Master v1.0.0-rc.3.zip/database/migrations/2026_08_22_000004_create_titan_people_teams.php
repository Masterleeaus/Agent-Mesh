<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_teams')) return;
        Schema::create('titan_people_teams', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->uuid('public_id');
            $table->string('name');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'public_id'], 'tp_team_tenant_public_uq');
            $table->index(['company_id', 'name'], 'tp_team_tenant_name_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_teams'); }
};
