<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_positions')) return;
        Schema::create('titan_people_positions', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->uuid('public_id');
            $table->unsignedBigInteger('department_id')->nullable();
            $table->string('name');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['company_id', 'public_id'], 'tp_pos_tenant_public_uq');
            $table->index(['company_id', 'department_id'], 'tp_pos_tenant_dept_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_positions'); }
};
