<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_people_employment_relationships')) return;
        Schema::create('titan_people_employment_relationships', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('worker_id');
            $table->string('employment_type', 50);
            $table->date('starts_on');
            $table->date('ends_on')->nullable();
            $table->unsignedBigInteger('department_id')->nullable();
            $table->unsignedBigInteger('position_id')->nullable();
            $table->unsignedBigInteger('team_id')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'worker_id', 'starts_on'], 'tp_employment_worker_idx');
            $table->index(['company_id', 'department_id'], 'tp_employment_dept_idx');
        });
    }

    public function down(): void { Schema::dropIfExists('titan_people_employment_relationships'); }
};
