<?php
declare(strict_types=1);
use App\Extensions\TitanPayroll\System\Http\Controllers\PayrollWorkspaceController;
use App\Extensions\TitanPayroll\System\Http\Middleware\ResolvePayrollCompany;
use Illuminate\Support\Facades\Route;
Route::middleware(['web','auth',ResolvePayrollCompany::class])->prefix('dashboard/user/titan-payroll')->group(function():void{
 Route::get('/',[PayrollWorkspaceController::class,'overview'])->name('dashboard.user.titan-payroll.index');
 Route::get('/runs',[PayrollWorkspaceController::class,'runs'])->name('dashboard.user.titan-payroll.runs.index');
 Route::get('/time-inputs',[PayrollWorkspaceController::class,'timeInputs'])->name('dashboard.user.titan-payroll.time-inputs.index');
 Route::get('/payslips',[PayrollWorkspaceController::class,'payslips'])->name('dashboard.user.titan-payroll.payslips.index');
 Route::get('/approvals',[PayrollWorkspaceController::class,'approvals'])->name('dashboard.user.titan-payroll.approvals.index');
 Route::get('/reconciliation',[PayrollWorkspaceController::class,'reconciliation'])->name('dashboard.user.titan-payroll.reconciliation.index');
 Route::get('/reports',[PayrollWorkspaceController::class,'reports'])->name('dashboard.user.titan-payroll.reports.index');
 Route::get('/settings',[PayrollWorkspaceController::class,'settings'])->name('dashboard.user.titan-payroll.settings.index');
});
