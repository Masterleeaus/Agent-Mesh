<?php

declare(strict_types=1);
use App\Extensions\TitanPayroll\System\Http\Controllers\{PayrollMutationController,PayrollSelfServiceController};
use App\Extensions\TitanPayroll\System\Http\Middleware\ResolvePayrollCompany;
use Illuminate\Support\Facades\Route;
Route::middleware(['api','auth',ResolvePayrollCompany::class])->prefix('api/titan-payroll')->group(function():void{
    Route::post('/runs/prepare',[PayrollMutationController::class,'prepare']);
    Route::post('/runs/{run}/submit',[PayrollMutationController::class,'submit']);
    Route::post('/runs/{run}/approve',[PayrollMutationController::class,'approve']);
    Route::post('/runs/{run}/reject',[PayrollMutationController::class,'reject']);
    Route::post('/runs/{run}/finalize',[PayrollMutationController::class,'finalize']);
    Route::post('/periods/lock',[PayrollMutationController::class,'lock']);
    Route::post('/periods/unlock',[PayrollMutationController::class,'unlock']);
    Route::post('/adjustments',[PayrollMutationController::class,'adjustment']);
    Route::get('/self/payslips',[PayrollSelfServiceController::class,'index']);
    Route::post('/payslips/{payslip}/resend',[PayrollMutationController::class,'resendPayslip']);
    Route::post('/payslips/{payslip}/acknowledge',[PayrollMutationController::class,'acknowledgePayslip']);
    Route::patch('/employee/preferences',[PayrollMutationController::class,'updatePreference']);
});
