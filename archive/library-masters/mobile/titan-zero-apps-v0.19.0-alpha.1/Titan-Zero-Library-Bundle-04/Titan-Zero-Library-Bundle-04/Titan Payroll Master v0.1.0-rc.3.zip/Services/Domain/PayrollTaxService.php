<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Domain;
use App\Extensions\TitanPayroll\Contracts\Services\PayrollTaxServiceContract;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollTaxBand;
use App\Extensions\TitanPayroll\System\Compliance\{PayrollRuleSet,PayrollRuleSetRegistry};
class PayrollTaxService implements PayrollTaxServiceContract
{
    public function __construct(private readonly ?PayrollRuleSetRegistry $ruleSets=null){}
    public function estimate(float $taxableIncome,string $country='AU',array $context=[]):array
    {
        if(($context['require_versioned_rules']??false)===true||isset($context['effective_date'])){
            if(!$this->ruleSets)throw new \RuntimeException('Versioned payroll rule registry is unavailable.');
            $date=(string)($context['effective_date']??date('Y-m-d'));$set=$this->ruleSets->resolve($country,$date);$result=$this->estimateFromBands($taxableIncome,(array)($set->rules['bands']??[]),$country);$result['rule']=$set->explain();return $result;
        }
        return $this->estimateFromBands($taxableIncome,(array)config("payroll.tax.bands.$country",[]),$country)+['rule'=>['classification'=>'legacy_configured_validation','legal_certification'=>false]];
    }
    private function estimateFromBands(float $taxableIncome,array $configured,string $country):array
    {
        $bands=array_map(fn($band)=>new PayrollTaxBand((float)$band['from'],$band['to']===null?null:(float)$band['to'],(float)$band['rate'],(float)($band['base']??0),(string)($band['label']??'')),$configured);$match=null;foreach($bands as $band){if($band->applies($taxableIncome)){$match=$band;break;}}
        if(!$match)return ['country'=>$country,'taxable_income'=>round($taxableIncome,2),'tax'=>0.0,'band'=>null,'warnings'=>['No effective configured tax band.'],'legal_certification'=>false];
        $tax=$match->base+max(0,$taxableIncome-$match->from)*$match->rate;return ['country'=>$country,'taxable_income'=>round($taxableIncome,2),'tax'=>round($tax,2),'effective_rate'=>$taxableIncome>0?round($tax/$taxableIncome,4):0,'band'=>$match->label,'legal_certification'=>false];
    }
}
