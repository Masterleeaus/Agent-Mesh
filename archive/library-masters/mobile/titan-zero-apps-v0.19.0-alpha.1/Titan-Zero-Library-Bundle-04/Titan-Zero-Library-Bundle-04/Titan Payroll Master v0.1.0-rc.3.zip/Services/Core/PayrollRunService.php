<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Core;
use Carbon\CarbonInterface;
use Illuminate\Support\Collection;
use App\Extensions\TitanPayroll\Contracts\Repositories\PayrollWorkerInputRepositoryContract;
use App\Extensions\TitanPayroll\Contracts\Services\{PayrollCalculationServiceContract,PayrollRunServiceContract};
use App\Extensions\TitanPayroll\Support\DTOs\PayrollRunResult;
final class PayrollRunService implements PayrollRunServiceContract
{
    public function __construct(private readonly PayrollCalculationServiceContract $calculator,private readonly PayrollWorkerInputRepositoryContract $workers){}
    public function preview(int $companyId,CarbonInterface $from,CarbonInterface $to,?array $userIds=null):Collection
    {
        $inputs=$this->workers->inputsForPeriod($companyId,$from,$to,$userIds);return collect($inputs)->map(fn($input)=>$this->calculator->calculate($input)->toArray());
    }
    public function run(int $companyId,CarbonInterface $from,CarbonInterface $to,?array $userIds=null,array $options=[]):PayrollRunResult
    {
        throw new \LogicException('Direct payroll-run mutation is disabled. Use PayrollCommandBusGateway with a canonical ext_titan_payroll_runs record.');
    }
}
