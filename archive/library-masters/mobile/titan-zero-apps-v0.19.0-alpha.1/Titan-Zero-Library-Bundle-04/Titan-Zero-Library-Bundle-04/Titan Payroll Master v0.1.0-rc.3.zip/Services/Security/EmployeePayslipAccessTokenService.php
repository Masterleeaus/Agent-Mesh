<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Security;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use App\Extensions\TitanPayroll\Contracts\Services\EmployeePayslipAccessTokenServiceContract;
use App\Extensions\TitanPayroll\System\Security\PayrollPayslipAccessPolicy;
final class EmployeePayslipAccessTokenService implements EmployeePayslipAccessTokenServiceContract
{
    public function issue(int $employeeId,int|string $payslipId,array $claims=[]):array
    {
        $tenant=(int)($claims['company_id']??0);if($tenant<1)throw new \InvalidArgumentException('company_id is required for payslip grants.');$expiresAt=now()->addMinutes((int)config('payroll.features.ess_token_ttl_minutes',60));$payload=['jti'=>(string)Str::uuid(),'company_id'=>$tenant,'employee_id'=>$employeeId,'payslip_id'=>(string)$payslipId,'claims'=>array_diff_key($claims,['company_id'=>true]),'expires_at'=>$expiresAt->toIso8601String()];return ['token'=>Crypt::encryptString(json_encode($payload,JSON_THROW_ON_ERROR)),'expires_at'=>$payload['expires_at']];
    }
    public function validate(string $token,int|string $payslipId,?int $employeeId=null,?int $companyId=null):array
    {
        try{$payload=json_decode(Crypt::decryptString($token),true,512,JSON_THROW_ON_ERROR);}catch(\Throwable){return ['valid'=>false,'reason'=>'Invalid token.'];}
        try{
            if($employeeId!==null&&$companyId!==null)(new PayrollPayslipAccessPolicy())->assertGrant($payload,$companyId,$employeeId,$payslipId,new \DateTimeImmutable('now'));
            else {if(($payload['payslip_id']??null)!==(string)$payslipId)throw new \DomainException('Token does not match payslip.');if(now()->greaterThanOrEqualTo($payload['expires_at']??now()->subMinute()))throw new \DomainException('Token expired.');}
        }catch(\Throwable $e){return ['valid'=>false,'reason'=>$e->getMessage()];}
        return ['valid'=>true,'payload'=>$payload];
    }
}
