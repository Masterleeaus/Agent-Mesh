<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Domain;
use App\Extensions\TitanPayroll\Contracts\Services\PayrollComplianceServiceContract;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationResult;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollComplianceReport;
use App\Extensions\TitanPayroll\System\Compliance\PayrollRuleSetRegistry;
class PayrollComplianceService implements PayrollComplianceServiceContract
{
    public function __construct(private readonly ?PayrollRuleSetRegistry $ruleSets=null){}
    public function inspect(PayrollCalculationResult $result,array $context=[]):PayrollComplianceReport
    {
        $violations=[];$warnings=[];$minimumNet=(float)config('payroll.compliance.minimum_net_pay',0);$ratioLimit=(float)config('payroll.compliance.maximum_net_to_gross_ratio',1.25);
        if($result->netPay<$minimumNet)$violations[]=['code'=>'MIN_NET_PAY','message'=>'Net pay is below configured minimum.','amount'=>$result->netPay];
        if($result->grossPay>0&&($result->netPay/$result->grossPay)>$ratioLimit)$violations[]=['code'=>'NET_GROSS_RATIO','message'=>'Net pay exceeds configured net/gross ratio.','ratio'=>round($result->netPay/$result->grossPay,4)];
        if(($context['employee_identifier']??null)===null&&(bool)config('payroll.compliance.require_employee_identifier',true))$warnings[]=['code'=>'MISSING_EMPLOYEE_IDENTIFIER','message'=>'Employee identifier was not supplied for compliance export.'];
        foreach($result->lines as $line)if(($line['code']??'')==='OT'&&(float)($line['hours']??0)>(float)config('payroll.compliance.warn_overtime_hours_above',20))$warnings[]=['code'=>'HIGH_OVERTIME','message'=>'Overtime hours exceed warning threshold.'];
        $metadata=['checked_at'=>now()->toISOString(),'classification'=>'configured_validation','legal_certification'=>false];
        if(($context['require_versioned_rules']??false)===true){if(!$this->ruleSets)throw new \RuntimeException('Versioned payroll rule registry is unavailable.');$jurisdiction=strtoupper(trim((string)($context['jurisdiction']??'')));$date=trim((string)($context['effective_date']??''));if($jurisdiction===''||$date==='')throw new \InvalidArgumentException('Versioned compliance validation requires jurisdiction and effective_date.');$metadata['rule']=$this->ruleSets->resolve($jurisdiction,$date)->explain();}
        return new PayrollComplianceReport(empty($violations),$violations,$warnings,$metadata);
    }
}
