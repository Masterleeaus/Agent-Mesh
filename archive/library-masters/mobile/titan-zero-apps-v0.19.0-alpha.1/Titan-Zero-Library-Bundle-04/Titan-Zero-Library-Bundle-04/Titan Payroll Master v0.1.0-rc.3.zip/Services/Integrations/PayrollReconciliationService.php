<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Integrations;
use App\Extensions\TitanPayroll\Contracts\Services\PayrollReconciliationServiceContract;
use App\Extensions\TitanPayroll\System\Domain\PayrollReconciliationRecord;
class PayrollReconciliationService implements PayrollReconciliationServiceContract
{
    public function reconcile(array $expected,array $actual):array
    {
        $r=$this->reconcileBound(0,0,'legacy',$expected,$actual);
        return ['matched'=>$r['matched'],'missing'=>$r['missing'],'variance'=>array_map(fn(array $x)=>['key'=>$x['key'],'expected'=>$x['expected'],'actual'=>$x['actual'],'delta'=>$x['delta']],$r['mismatched']),'summary'=>['matched'=>count($r['matched']),'missing'=>count($r['missing']),'variance'=>count($r['mismatched'])]];
    }
    public function reconcileBound(int $companyId,int $payrollRunId,string $sourceRevision,array $expected,array $actual):array
    {
        if($companyId<0||$payrollRunId<0||trim($sourceRevision)==='')throw new \InvalidArgumentException('Reconciliation provenance is required.');
        $actualGroups=[];foreach($actual as $row){$key=$this->key($row);$actualGroups[$key][]=$row;}
        $matched=[];$missing=[];$mismatched=[];$duplicate=[];$proposals=[];$seen=[];
        foreach($expected as $row){$key=$this->key($row);$seen[$key]=true;$group=$actualGroups[$key]??[];
            if($group===[]){$missing[]=$row;$proposals[]=$this->proposal('missing',$key);continue;}
            if(count($group)>1){$duplicate[]=['key'=>$key,'records'=>$group];$proposals[]=$this->proposal('duplicate',$key);}
            $actualRow=$group[0];$a=$this->amount($actualRow);$e=$this->amount($row);$delta=round($a-$e,2);
            if($delta===0.0)$matched[]=$row+['matched_amount'=>$a]; else {$mismatched[]=['key'=>$key,'expected'=>$row,'actual'=>$actualRow,'delta'=>$delta];$proposals[]=$this->proposal('mismatch',$key,['delta'=>$delta]);}
        }
        $unresolved=[];foreach($actualGroups as $key=>$group){$key=(string)$key;if(!isset($seen[$key])){foreach($group as $row)$unresolved[]=['key'=>$key,'actual'=>$row,'reason'=>'unexpected_actual'];$proposals[]=$this->proposal('unexpected_actual',$key);}}
        usort($proposals,fn($a,$b)=>strcmp($a['proposal_id'],$b['proposal_id']));
        $record=['company_id'=>$companyId,'payroll_run_id'=>$payrollRunId,'source_revision'=>$sourceRevision,'matched'=>$matched,'missing'=>$missing,'mismatched'=>$mismatched,'duplicate'=>$duplicate,'unresolved'=>$unresolved,'resolution_proposals'=>$proposals,'summary'=>['matched'=>count($matched),'missing'=>count($missing),'mismatched'=>count($mismatched),'duplicate'=>count($duplicate),'unresolved'=>count($unresolved)]];
        return $record;
    }
    private function key(array $row):string{return (string)($row['employee_id']??$row['user_id']??$row['worker_ref']??'');}
    private function amount(array $row):float{return (float)($row['amount']??$row['net_pay']??0);}
    private function proposal(string $type,string $key,array $meta=[]):array{return ['proposal_id'=>hash('sha256',$type.'|'.$key.'|'.json_encode($meta,JSON_PRESERVE_ZERO_FRACTION)),'type'=>$type,'key'=>$key,'status'=>'proposed','auto_correct'=>false,'requires_governed_resolution'=>true]+$meta;}
}
