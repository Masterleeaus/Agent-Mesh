<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Domain;
use Illuminate\Support\Facades\DB;
use App\Extensions\TitanPayroll\Contracts\Services\PayrollRunGuardServiceContract;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollRunGuardResult;
final class PayrollRunGuardService implements PayrollRunGuardServiceContract
{
    public function inspect(array $payload):PayrollRunGuardResult
    {
        $errors=[];$warnings=[];$tenant=(int)($payload['company_id']??0);$from=$payload['period_from']??$payload['start_date']??null;$to=$payload['period_to']??$payload['end_date']??null;if($tenant<1)$errors[]='Missing canonical company_id for payroll run guard.';if(!$from||!$to)$errors[]='Missing period_from/period_to for payroll run guard.';if($from&&$to&&$from>$to)$errors[]='Payroll period start date must be before end date.';$duplicates=0;
        if($tenant&&$from&&$to&&DB::getSchemaBuilder()->hasTable('ext_titan_payroll_runs')){$duplicates=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('period_from',$from)->where('period_to',$to)->whereIn('status',['draft','prepared','pending_approval','approved','finalized'])->count();if($duplicates>0)$warnings[]='A payroll run already exists for this tenant and period.';}
        if($tenant&&$from&&$to&&DB::getSchemaBuilder()->hasTable('ext_titan_payroll_period_locks')){$locked=DB::table('ext_titan_payroll_period_locks')->where('company_id',$tenant)->where('status','locked')->where('period_from','<=',$to)->where('period_to','>=',$from)->exists();if($locked)$errors[]='Payroll period overlaps an active lock.';}
        if(($payload['employee_count']??1)<=0)$warnings[]='No employees were supplied for this payroll run.';return new PayrollRunGuardResult(empty($errors),$errors,$warnings,['duplicate_count'=>$duplicates,'company_id'=>$tenant,'period_from'=>$from,'period_to'=>$to]);
    }
    public function assertCanFinalize(int|string $runId,array $context=[]):PayrollRunGuardResult
    {
        $tenant=(int)($context['company_id']??0);if($tenant<1)return new PayrollRunGuardResult(false,['Missing canonical company_id.']);if(!DB::getSchemaBuilder()->hasTable('ext_titan_payroll_runs'))return new PayrollRunGuardResult(false,['ext_titan_payroll_runs table is missing.']);$run=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$runId)->first();if(!$run)return new PayrollRunGuardResult(false,['Payroll run not found.']);$errors=[];$warnings=[];if((string)$run->status==='finalized')$errors[]='Payroll run is already finalized.';if((string)$run->status!=='approved')$errors[]='Payroll run must be approved before finalization.';if(empty($run->snapshot)||empty($run->calculation_version)||empty($run->config_version)||empty($run->source_revision))$errors[]='Payroll run is missing immutable calculation/config/source revision evidence.';return new PayrollRunGuardResult(empty($errors),$errors,$warnings,['run_id'=>$runId,'company_id'=>$tenant,'status'=>$run->status]);
    }
}
