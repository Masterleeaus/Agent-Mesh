<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Services\Forecasting;
use App\Extensions\TitanPayroll\System\Forecasting\PayrollScenario;
class PayrollForecastService
{
    public function projectMonthlyCost(float $currentMonthlyNet,float $growthRate=0.0,int $months=12):array{return $this->scenario(0,$currentMonthlyNet,$growthRate,$months,[])['projection'];}
    public function scenario(int $companyId,float $currentMonthlyNet,float $growthRate=0.0,int $months=12,array $assumptions=[]):array
    { if($months<1||$months>60)throw new \InvalidArgumentException('Payroll forecast horizon must be between 1 and 60 months.');if($currentMonthlyNet<0)throw new \InvalidArgumentException('Base payroll cannot be negative.');ksort($assumptions);$forecast=[];$running=$currentMonthlyNet;for($month=1;$month<=$months;$month++){$running*=(1+$growthRate);$forecast[]=['month'=>$month,'projected_net_payroll'=>round($running,2)];}return (new PayrollScenario($companyId,$currentMonthlyNet,$growthRate,$months,$assumptions,$forecast))->toArray(); }
}
