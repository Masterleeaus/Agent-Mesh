<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\Services\Domain;

use App\Extensions\TitanPayroll\Contracts\Services\CleanerShiftReconciliationServiceContract;
use InvalidArgumentException;

final class CleanerShiftReconciliationService implements CleanerShiftReconciliationServiceContract
{
    public function reconcile(array $rosteredShifts, array $approvedTimeEntries, array $context = []): array
    {
        $tenant = (int) ($context['company_id'] ?? 0);
        $runId = (int) ($context['payroll_run_id'] ?? 0);
        $sourceRevision = trim((string) ($context['source_revision'] ?? ''));
        if ($tenant < 1 || $runId < 1 || $sourceRevision === '') {
            throw new InvalidArgumentException('Cleaner shift reconciliation requires company_id, payroll_run_id and source_revision.');
        }

        return $this->compare($rosteredShifts, $approvedTimeEntries) + [
            'provenance' => [
                'company_id' => $tenant,
                'payroll_run_id' => $runId,
                'source_revision' => $sourceRevision,
                'source' => 'approved_time_attendance_evidence',
            ],
        ];
    }

    /** Preserve the deterministic donor comparison for non-authoritative previews/tests. */
    public function compare(array $rosteredShifts, array $approvedTimeEntries): array
    {
        $issues = [];
        $approvedByShift = [];

        foreach ($approvedTimeEntries as $entry) {
            $shiftId = $entry['shift_id'] ?? null;
            if ($shiftId !== null && $shiftId !== '') {
                $approvedByShift[(string) $shiftId] = $entry;
            }
        }

        foreach ($rosteredShifts as $shift) {
            $shiftId = $shift['id'] ?? null;
            $key = $shiftId === null ? '' : (string) $shiftId;
            if ($key === '' || !isset($approvedByShift[$key])) {
                $issues[] = [
                    'shift_id' => $shiftId,
                    'type' => 'missing_time_entry',
                    'message' => 'Rostered cleaner shift has no approved time entry.',
                ];
                continue;
            }

            $expected = (float) ($shift['hours'] ?? 0);
            $actual = (float) ($approvedByShift[$key]['hours'] ?? 0);
            if (abs($expected - $actual) >= 0.25) {
                $issues[] = [
                    'shift_id' => $shiftId,
                    'type' => 'hours_variance',
                    'expected_hours' => $expected,
                    'actual_hours' => $actual,
                ];
            }
        }

        return ['passed' => $issues === [], 'issues' => $issues];
    }
}
