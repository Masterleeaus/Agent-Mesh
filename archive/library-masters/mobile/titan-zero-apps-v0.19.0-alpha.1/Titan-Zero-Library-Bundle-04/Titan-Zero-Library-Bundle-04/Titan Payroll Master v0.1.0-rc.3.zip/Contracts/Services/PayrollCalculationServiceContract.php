<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

use App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationResult;

interface PayrollCalculationServiceContract
{
    public function calculate(PayrollCalculationInput $input): PayrollCalculationResult;
}
