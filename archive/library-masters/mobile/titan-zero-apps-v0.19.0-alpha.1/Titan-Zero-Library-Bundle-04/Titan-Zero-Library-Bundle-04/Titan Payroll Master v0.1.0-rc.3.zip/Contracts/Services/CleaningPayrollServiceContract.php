<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

use App\Extensions\TitanPayroll\Support\DTOs\CleaningPayrollInput;
use App\Extensions\TitanPayroll\Support\DTOs\CleaningPayrollResult;

interface CleaningPayrollServiceContract
{
    public function calculate(CleaningPayrollInput $input): CleaningPayrollResult;

    public function inspectRosterVariance(CleaningPayrollInput $input): array;
}
