<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

use App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationResult;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollComplianceReport;

interface PayrollComplianceServiceContract
{
    public function inspect(PayrollCalculationResult $result, array $context = []): PayrollComplianceReport;
}
