<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\Contracts\Services;

interface CleanerShiftReconciliationServiceContract
{
    /**
     * Reconcile rostered shifts against approved Time Attendance evidence.
     *
     * @param array<int,array<string,mixed>> $rosteredShifts
     * @param array<int,array<string,mixed>> $approvedTimeEntries
     * @param array{company_id:int,payroll_run_id:int,source_revision:string} $context
     * @return array<string,mixed>
     */
    public function reconcile(array $rosteredShifts, array $approvedTimeEntries, array $context = []): array;
}
