<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

interface PayrollTaxServiceContract
{
    public function estimate(float $taxableIncome, string $country = 'AU', array $context = []): array;
}
