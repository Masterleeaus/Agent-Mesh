<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

interface PayrollVarianceServiceContract
{
    public function compare(array $currentRun, ?array $previousRun = null, array $options = []): array;
}
