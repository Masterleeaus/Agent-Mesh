<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Contracts\Repositories;
use Carbon\CarbonInterface;
interface PayrollWorkerInputRepositoryContract
{
    /** @return array<int,\App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput> */
    public function inputsForPeriod(int $companyId, CarbonInterface $from, CarbonInterface $to, ?array $workerIds = null): array;
}
