<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

use App\Extensions\TitanPayroll\Support\DTOs\PayrollRunGuardResult;

interface PayrollRunGuardServiceContract
{
    public function inspect(array $payload): PayrollRunGuardResult;
    public function assertCanFinalize(int|string $runId, array $context = []): PayrollRunGuardResult;
}
