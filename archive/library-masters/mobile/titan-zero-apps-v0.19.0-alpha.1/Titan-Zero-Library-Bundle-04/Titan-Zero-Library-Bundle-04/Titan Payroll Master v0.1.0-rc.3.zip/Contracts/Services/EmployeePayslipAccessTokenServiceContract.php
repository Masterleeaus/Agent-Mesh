<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Contracts\Services;
interface EmployeePayslipAccessTokenServiceContract
{
    public function issue(int $employeeId,int|string $payslipId,array $claims=[]):array;
    public function validate(string $token,int|string $payslipId,?int $employeeId=null,?int $companyId=null):array;
}
