<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

interface PayrollReconciliationServiceContract
{
    public function reconcile(array $expected, array $actual): array;
}
