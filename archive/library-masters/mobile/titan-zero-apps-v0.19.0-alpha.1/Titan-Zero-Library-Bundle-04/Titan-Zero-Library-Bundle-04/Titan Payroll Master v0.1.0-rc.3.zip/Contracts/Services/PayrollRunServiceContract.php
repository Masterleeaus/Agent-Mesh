<?php

namespace App\Extensions\TitanPayroll\Contracts\Services;

use Carbon\CarbonInterface;
use Illuminate\Support\Collection;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollRunResult;

interface PayrollRunServiceContract
{
    public function preview(int $companyId, CarbonInterface $from, CarbonInterface $to, ?array $userIds = null): Collection;
    public function run(int $companyId, CarbonInterface $from, CarbonInterface $to, ?array $userIds = null, array $options = []): PayrollRunResult;
}
