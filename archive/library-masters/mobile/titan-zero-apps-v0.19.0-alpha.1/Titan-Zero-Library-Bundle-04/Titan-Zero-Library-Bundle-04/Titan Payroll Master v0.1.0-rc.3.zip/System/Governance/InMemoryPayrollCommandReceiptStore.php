<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class InMemoryPayrollCommandReceiptStore implements PayrollCommandReceiptStorePort
{
    private array $items=[];
    public function replay(string $key):?array{return isset($this->items[$key])?array_replace($this->items[$key],['replayed'=>true]):null;}
    public function reserve(string $key,array $processingReceipt):bool{if(isset($this->items[$key]))return false;$this->items[$key]=$processingReceipt;return true;}
    public function store(string $key,array $receipt):void{$this->items[$key]=$receipt;}
}
