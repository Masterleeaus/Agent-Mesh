<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Domain;

final class PayrollCalculationSnapshot
{
    private function __construct(private array $data) {}

    public static function fromCalculation(
        int $companyId,
        string $workerRef,
        string $periodFrom,
        string $periodTo,
        string $calculationVersion,
        string $configVersion,
        string $sourceRevision,
        array $result,
    ): self {
        if ($companyId < 1 || $workerRef === '' || $periodFrom === '' || $periodTo === '') {
            throw new \InvalidArgumentException('A tenant, worker and payroll period are required.');
        }

        $data = [
            'company_id' => $companyId,
            'worker_ref' => $workerRef,
            'period_from' => $periodFrom,
            'period_to' => $periodTo,
            'calculation_version' => $calculationVersion,
            'config_version' => $configVersion,
            'source_revision' => $sourceRevision,
            'gross_pay' => round((float) ($result['gross_pay'] ?? 0), 2),
            'net_pay' => round((float) ($result['net_pay'] ?? 0), 2),
            'total_earnings' => round((float) ($result['total_earnings'] ?? ($result['gross_pay'] ?? 0)), 2),
            'total_deductions' => round((float) ($result['total_deductions'] ?? 0), 2),
            'total_taxes' => round((float) ($result['total_taxes'] ?? 0), 2),
            'total_reimbursements' => round((float) ($result['total_reimbursements'] ?? 0), 2),
            'lines' => array_values((array) ($result['lines'] ?? [])),
            'warnings' => array_values((array) ($result['warnings'] ?? [])),
        ];
        $data['snapshot_hash'] = self::hash($data);

        return new self($data);
    }

    public static function fromArray(array $data): self
    {
        $hash = (string) ($data['snapshot_hash'] ?? '');
        unset($data['snapshot_hash']);
        $computed = self::hash($data);
        if ($hash !== '' && ! hash_equals($hash, $computed)) {
            throw new \DomainException('Payroll calculation snapshot integrity check failed.');
        }
        $data['snapshot_hash'] = $computed;
        return new self($data);
    }

    public function toArray(): array { return $this->data; }

    private static function hash(array $payload): string
    {
        self::ksortRecursive($payload);
        return hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR));
    }

    private static function ksortRecursive(array &$value): void
    {
        if (! array_is_list($value)) ksort($value);
        foreach ($value as &$item) if (is_array($item)) self::ksortRecursive($item);
    }
}
