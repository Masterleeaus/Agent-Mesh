<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Integrations\TimeAttendance;

use App\Extensions\TitanPayroll\System\Contracts\TimeAttendancePayrollInputPort;

final class ConfiguredTimeAttendancePayrollInputAdapter implements TimeAttendancePayrollInputPort
{
    public const HOST_BINDING = 'titan.time-attendance.payroll-input';

    public function __construct(private readonly ?object $provider = null) {}

    public function available(): bool { return $this->resolveProvider() !== null; }

    public function approvedInputs(int $companyId, string $periodFrom, string $periodTo, array $workerRefs = [], bool $required = true): array
    {
        if ($companyId < 1) throw new \InvalidArgumentException('company_id is required.');
        if ($periodFrom === '' || $periodTo === '' || $periodFrom > $periodTo) throw new \InvalidArgumentException('A valid payroll period is required.');

        $provider = $this->resolveProvider();
        if ($provider === null) {
            return (new NullTimeAttendancePayrollInputAdapter())->approvedInputs($companyId,$periodFrom,$periodTo,$workerRefs,$required);
        }

        if (! method_exists($provider, 'approvedPayrollInputs')) {
            throw new \RuntimeException('Configured Time Attendance payroll input provider does not implement approvedPayrollInputs().');
        }
        $result = $provider->approvedPayrollInputs($companyId,$periodFrom,$periodTo,$workerRefs);
        if (! is_array($result)) throw new \RuntimeException('Time Attendance payroll input provider returned an invalid payload.');

        $allowedWorkers = array_fill_keys(array_map('strval',$workerRefs),true);
        $entries=[];
        foreach ((array)($result['entries']??[]) as $entry) {
            if (! is_array($entry) || ($entry['approved']??false)!==true) continue;
            $worker=(string)($entry['worker_ref']??''); $date=(string)($entry['work_date']??$entry['occurred_at']??'');
            if ($worker==='' || ($allowedWorkers!==[] && !isset($allowedWorkers[$worker]))) continue;
            $day=substr($date,0,10); if($day<$periodFrom||$day>$periodTo) continue;
            $entries[]=$entry;
        }
        return [
            'available'=>true,'required'=>$required,'source'=>'titan-time-attendance',
            'source_revision'=>isset($result['source_revision'])?(string)$result['source_revision']:null,'entries'=>$entries,
        ];
    }

    private function resolveProvider(): ?object
    {
        if ($this->provider !== null) return $this->provider;
        if (function_exists('app')) {
            try { $app=app(); if (method_exists($app,'bound') && $app->bound(self::HOST_BINDING)) { $resolved=$app->make(self::HOST_BINDING); return is_object($resolved)?$resolved:null; } } catch (\Throwable) {}
        }
        return null;
    }
}
