<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Health;
use App\Extensions\TitanPayroll\System\Contracts\TimeAttendancePayrollInputPort;
use App\Extensions\TitanPayroll\System\Governance\{PayrollAssurancePort,PayrollCommandBusPort,PayrollRiskPort};
use Illuminate\Support\Facades\DB;
final class PayrollRuntimeHealthProbe
{
    public function __construct(
        private readonly PayrollHealth $health,
        private readonly PayrollCommandBusPort $commandBus,
        private readonly PayrollRiskPort $risk,
        private readonly PayrollAssurancePort $assurance,
        private readonly TimeAttendancePayrollInputPort $timeAttendance,
    ){}
    public function liveness():array{return $this->health->liveness();}
    public function readiness():array
    {
        return $this->health->readiness([
            'database'=>$this->databaseAvailable(),
            'queue'=>$this->hostBindingAvailable('queue'),
            'command_bus'=>$this->commandBus->available(),
            'risk'=>$this->risk->available(),
            'assurance'=>$this->assurance->available(),
            'autonomy'=>$this->hostBindingAvailable('titan.autonomy.payroll'),
            'time_attendance'=>$this->timeAttendance->available(),
        ]);
    }
    private function databaseAvailable():bool{try{DB::connection()->getPdo();return true;}catch(\Throwable){return false;}}
    private function hostBindingAvailable(string $binding):bool
    {
        if(!function_exists('app'))return false;
        try{$app=app();return method_exists($app,'bound')&&$app->bound($binding);}catch(\Throwable){return false;}
    }
}
