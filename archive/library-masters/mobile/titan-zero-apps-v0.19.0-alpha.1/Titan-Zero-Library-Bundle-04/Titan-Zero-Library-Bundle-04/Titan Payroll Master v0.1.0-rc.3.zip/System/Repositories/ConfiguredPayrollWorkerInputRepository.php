<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Repositories;
use App\Extensions\TitanPayroll\Contracts\Repositories\PayrollWorkerInputRepositoryContract;
use App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput;
use Carbon\CarbonInterface;
final class ConfiguredPayrollWorkerInputRepository implements PayrollWorkerInputRepositoryContract
{
    public const HOST_BINDING='titan.payroll.worker-inputs';
    public function inputsForPeriod(int $companyId, CarbonInterface $from, CarbonInterface $to, ?array $workerIds=null):array
    {
        $provider=null;if(function_exists('app')){try{$app=app();if(method_exists($app,'bound')&&$app->bound(self::HOST_BINDING))$provider=$app->make(self::HOST_BINDING);}catch(\Throwable){}}
        if(!is_object($provider)||!method_exists($provider,'payrollInputs'))throw new \RuntimeException('No approved Titan worker/pay-rate input provider is available.');
        $rows=$provider->payrollInputs($companyId,$from->toDateString(),$to->toDateString(),$workerIds??[]);if(!is_array($rows))throw new \RuntimeException('Payroll worker input provider returned an invalid payload.');
        $out=[];foreach($rows as $row){if(!is_array($row))continue;$workerId=(int)($row['user_id']??$row['worker_id']??0);if($workerId<1)continue;$out[]=new PayrollCalculationInput(companyId:$companyId,userId:$workerId,from:$from,to:$to,baseSalary:(float)($row['base_salary']??0),hourlyRate:(float)($row['hourly_rate']??0),regularHours:(float)($row['regular_hours']??0),overtimeHours:(float)($row['overtime_hours']??0),earnings:(array)($row['earnings']??[]),deductions:(array)($row['deductions']??[]),reimbursements:(array)($row['reimbursements']??[]),taxes:(array)($row['taxes']??[]),metadata:(array)($row['metadata']??[]));}
        return $out;
    }
}
