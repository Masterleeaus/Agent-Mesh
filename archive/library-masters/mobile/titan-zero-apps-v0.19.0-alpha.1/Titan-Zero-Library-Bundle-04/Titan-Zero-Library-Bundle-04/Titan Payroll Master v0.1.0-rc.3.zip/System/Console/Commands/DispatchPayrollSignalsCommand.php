<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Console\Commands;
use App\Extensions\TitanPayroll\System\Signals\PayrollSignalDispatcher;
use Illuminate\Console\Command;
final class DispatchPayrollSignalsCommand extends Command
{
    protected $signature='titan-payroll:dispatch-signals {--limit=100}';
    protected $description='Deliver pending privacy-minimized Titan Payroll signal outbox records.';
    public function handle(PayrollSignalDispatcher $dispatcher):int{$result=$dispatcher->dispatchPending((int)$this->option('limit'));$this->line(json_encode($result,JSON_UNESCAPED_SLASHES));return self::SUCCESS;}
}
