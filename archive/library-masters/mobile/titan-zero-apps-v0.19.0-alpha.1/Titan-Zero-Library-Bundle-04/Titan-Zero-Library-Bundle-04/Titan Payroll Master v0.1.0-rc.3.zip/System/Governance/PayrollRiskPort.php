<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
interface PayrollRiskPort
{
    public function available(): bool;
    /** @return array{allowed:bool,decision_id?:string,reason?:string} */
    public function assess(PayrollCommandRequest $request): array;
}
