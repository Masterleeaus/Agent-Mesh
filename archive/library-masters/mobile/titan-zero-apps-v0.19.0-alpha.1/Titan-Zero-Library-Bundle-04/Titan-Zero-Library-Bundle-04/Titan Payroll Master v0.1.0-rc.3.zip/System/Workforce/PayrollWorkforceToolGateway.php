<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
use App\Extensions\TitanPayroll\System\Governance\PayrollCommandBusGateway;
use App\Extensions\TitanPayroll\System\Workforce\Decision\PayrollWorkforceDecisionGate;
final class PayrollWorkforceToolGateway
{
    public function __construct(private readonly PayrollCommandBusGateway $commands,private readonly PayrollWorkforceDecisionGate $decisions,private readonly array $readers=[]){ }
    public function execute(PayrollWorkforceExecutionContext $ctx,array $tool,array $input,object $actor):array
    { if(isset($input['company_id'])&&(int)$input['company_id']!==$ctx->companyId)return ['status'=>'blocked','reason'=>'cross_tenant_object'];$decision=$this->decisions->decide($ctx,$tool);if(!($decision['allowed']??false))return ['status'=>'blocked']+$decision;if(($tool['writes_state']??false)===true){$input['idempotency_key']=(string)($input['idempotency_key']??hash('sha256',$ctx->traceId.'|'.$tool['id']));return $this->commands->request((string)$tool['capability'],$input,$actor,'payroll_workforce','ai_workforce');}$reader=$this->readers[$tool['id']]??null;if(!is_callable($reader))return ['status'=>'unavailable','executed'=>false,'reason'=>'scoped_reader_unavailable'];return ['status'=>'read','executed'=>true,'result'=>$reader($ctx,$input)]; }
}
