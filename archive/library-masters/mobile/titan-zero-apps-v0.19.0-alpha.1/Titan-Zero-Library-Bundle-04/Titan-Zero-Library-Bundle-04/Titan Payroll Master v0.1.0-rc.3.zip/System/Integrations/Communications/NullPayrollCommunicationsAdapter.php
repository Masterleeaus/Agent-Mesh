<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Communications;
use App\Extensions\TitanPayroll\System\Contracts\PayrollCommunicationsPort;
final class NullPayrollCommunicationsAdapter implements PayrollCommunicationsPort
{ public function available():bool{return false;} public function deliverPayslip(array $envelope):array{return ['status'=>'unavailable','delivered'=>false,'provider_receipt'=>null,'message'=>'Titan Communications provider is unavailable.'];} }
