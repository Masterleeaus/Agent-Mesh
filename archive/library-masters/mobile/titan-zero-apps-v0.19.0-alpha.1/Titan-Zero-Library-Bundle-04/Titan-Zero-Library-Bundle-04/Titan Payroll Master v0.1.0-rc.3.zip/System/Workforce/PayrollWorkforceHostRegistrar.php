<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollWorkforceHostRegistrar
{
    public const HOST_BINDINGS=['titan.workforce.manifest-registry','titan.workforce.extension-registry'];
    public function register():array
    {
        $manifest=PayrollWorkforceManifest::load();(new PayrollWorkforceManifestValidator())->validate($manifest,(string)config('payroll.version','0.1.0-rc.3'));
        if(!function_exists('app'))return ['registered'=>false,'reason'=>'host_container_unavailable'];
        foreach(self::HOST_BINDINGS as $binding){try{$app=app();if(!method_exists($app,'bound')||!$app->bound($binding))continue;$registry=$app->make($binding);foreach(['registerManifest','register','contribute'] as $method){if(!is_object($registry)||!method_exists($registry,$method))continue;$registry->{$method}('titan-payroll',$manifest);return ['registered'=>true,'binding'=>$binding,'method'=>$method];}}catch(\Throwable){}}
        return ['registered'=>false,'reason'=>'workforce_registry_unavailable'];
    }
}
