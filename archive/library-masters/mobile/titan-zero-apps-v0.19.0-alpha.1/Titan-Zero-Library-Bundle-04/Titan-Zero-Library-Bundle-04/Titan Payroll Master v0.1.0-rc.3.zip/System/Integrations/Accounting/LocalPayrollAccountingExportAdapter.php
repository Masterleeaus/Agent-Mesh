<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Accounting;
use App\Extensions\TitanPayroll\System\Contracts\PayrollAccountingExportPort;
final class LocalPayrollAccountingExportAdapter implements PayrollAccountingExportPort
{
    public function available():bool{return true;}
    public function export(array $journal):array
    {
        $rows=[['reference','account','debit','credit','currency','memo']];foreach((array)($journal['lines']??[]) as $line)$rows[]=[(string)($journal['reference']??''),(string)($line['account']??''),number_format((float)($line['debit']??0),2,'.',''),number_format((float)($line['credit']??0),2,'.',''),(string)($journal['currency']??''),(string)($line['memo']??'')];
        $csv=implode("\n",array_map(fn(array $r)=>implode(',',array_map([$this,'escape'],$r)),$rows))."\n";
        return ['status'=>'exported','exported'=>true,'transmitted'=>false,'format'=>'csv','content'=>$csv,'message'=>'Accounting journal exported locally; no external ledger transmission occurred.'];
    }
    private function escape(mixed $v):string{$v=(string)$v;return '"'.str_replace('"','""',$v).'"';}
}
