<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce\Decision;
use App\Extensions\TitanPayroll\System\Workforce\PayrollWorkforceExecutionContext;
final class PayrollWorkforceDecisionGate
{
    public function decide(PayrollWorkforceExecutionContext $ctx,array $tool):array
    { $roles=(array)($tool['roles']??[]);if($roles&&!in_array($ctx->roleId,$roles,true))return ['allowed'=>false,'reason'=>'role_not_allowed'];$required=(int)($tool['minimum_authority_score']??0);if($ctx->effectiveAuthorityScore<$required)return ['allowed'=>false,'reason'=>'insufficient_effective_authority'];if(($tool['writes_state']??false)===true&&($tool['requires_human_approval']??false)===true&&!$ctx->humanApproved)return ['allowed'=>false,'reason'=>'human_approval_required'];return ['allowed'=>true,'execution'=>($tool['writes_state']??false)?'command_bus':'scoped_read','company_id'=>$ctx->companyId,'trace_id'=>$ctx->traceId]; }
    public function assertObjectTenant(PayrollWorkforceExecutionContext $ctx,int $objectCompanyId):bool{return $ctx->companyId===$objectCompanyId;}
}
