<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Console\Commands;

use App\Extensions\TitanPayroll\System\Navigation\PayrollMenuRegistrar;
use Illuminate\Console\Command;

final class PayrollHostSyncCommand extends Command
{
    protected $signature='titan-payroll:host-sync {--force-menu-regenerate}';
    protected $description='Synchronise Titan Payroll host navigation compatibility state.';
    public function handle(PayrollMenuRegistrar $menus): int
    {
        $this->line(json_encode($menus->syncHostMenu((bool)$this->option('force-menu-regenerate')), JSON_UNESCAPED_SLASHES));
        return self::SUCCESS;
    }
}
