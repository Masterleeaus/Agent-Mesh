<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Payments;
use App\Extensions\TitanPayroll\System\Contracts\PayrollPaymentInstructionPort;
final class LocalPayrollPaymentInstructionPreparationAdapter implements PayrollPaymentInstructionPort
{
    public function available():bool{return false;}
    public function transmit(array $instructions):array
    {
        $rows=[['worker_ref','amount','currency','reference']];foreach((array)($instructions['instructions']??[]) as $row)$rows[]=[(string)($row['worker_ref']??''),number_format((float)($row['amount']??0),2,'.',''),(string)($row['currency']??''),(string)($row['reference']??'')];
        $csv=implode("\n",array_map(fn(array $r)=>implode(',',array_map([$this,'escape'],$r)),$rows))."\n";
        return ['status'=>'prepared','prepared'=>true,'transmitted'=>false,'paid'=>false,'format'=>'csv','content'=>$csv,'message'=>'Payment instructions prepared locally. No payment provider transmission occurred.'];
    }
    private function escape(mixed $v):string{$v=(string)$v;return '"'.str_replace('"','""',$v).'"';}
}
