<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Integrations\TimeAttendance;

use App\Extensions\TitanPayroll\System\Contracts\TimeAttendancePayrollInputPort;

final class NullTimeAttendancePayrollInputAdapter implements TimeAttendancePayrollInputPort
{
    public function available(): bool { return false; }

    public function approvedInputs(int $companyId, string $periodFrom, string $periodTo, array $workerRefs = [], bool $required = true): array
    {
        if ($required) {
            throw new \RuntimeException('Titan Payroll requires authoritative approved time evidence, but Titan Time Attendance has no callable payroll-input port available.');
        }
        return ['available'=>false,'required'=>false,'source'=>'titan-time-attendance','source_revision'=>null,'entries'=>[]];
    }
}
