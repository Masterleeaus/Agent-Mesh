<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Accounting;
use App\Extensions\TitanPayroll\System\Contracts\PayrollAccountingExportPort;
final class NullPayrollAccountingExportAdapter implements PayrollAccountingExportPort{public function available():bool{return false;}public function export(array $journal):array{return ['status'=>'prepared','exported'=>true,'transmitted'=>false,'message'=>'Accounting adapter unavailable; local export only.','payload'=>$journal];}}
