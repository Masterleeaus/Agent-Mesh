<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Domain;
final class PayrollRunFinalizer
{
    public function __construct(private readonly PayrollRunLifecycle $lifecycle){}
    public function finalize(array $run,array $snapshot,int $companyId):array
    {
        if((int)($run['company_id']??0)!==$companyId)throw new \DomainException('Payroll run tenant mismatch.');
        $status=(string)($run['status']??'');$next=$this->lifecycle->transition($status,'finalized');
        foreach(['calculation_version','config_version','source_revision'] as $field)if(trim((string)($snapshot[$field]??''))==='')throw new \DomainException("Finalization requires {$field}.");
        $frozen=$snapshot;$frozen['company_id']=$companyId;$frozen['run_id']=$run['id']??null;self::ksortRecursive($frozen);$hash=hash('sha256',json_encode($frozen,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));
        return array_replace($run,['status'=>$next,'finalized_snapshot'=>$frozen,'finalized_snapshot_hash'=>$hash]);
    }
    private static function ksortRecursive(array &$value):void{if(!array_is_list($value))ksort($value);foreach($value as &$item)if(is_array($item))self::ksortRecursive($item);}
}
