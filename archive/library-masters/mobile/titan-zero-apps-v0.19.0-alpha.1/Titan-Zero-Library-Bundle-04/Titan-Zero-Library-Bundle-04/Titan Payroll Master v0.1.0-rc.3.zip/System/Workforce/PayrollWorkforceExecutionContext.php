<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollWorkforceExecutionContext
{
    public function __construct(public readonly int $companyId,public readonly int $actorUserId,public readonly string $roleId,public readonly string $traceId,public readonly string $actorType='ai_workforce',public readonly int $effectiveAuthorityScore=0,public readonly bool $humanApproved=false){}
    public function companyId(): int { return $this->companyId; }
    public function canonicalContext(): array { return ['company_id'=>$this->companyId,'actor_user_id'=>$this->actorUserId,'role_id'=>$this->roleId,'trace_id'=>$this->traceId]; }
}
