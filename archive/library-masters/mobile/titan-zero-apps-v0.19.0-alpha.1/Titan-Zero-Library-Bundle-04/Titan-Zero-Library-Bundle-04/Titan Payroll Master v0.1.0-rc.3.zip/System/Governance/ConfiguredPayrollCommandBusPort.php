<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;

final class ConfiguredPayrollCommandBusPort implements PayrollCommandBusPort
{
    public const HOST_BINDING='titan.command-bus.payroll';
    public function __construct(private readonly ?object $provider=null) {}
    public function available():bool{return $this->resolveProvider()!==null;}
    public function dispatch(PayrollCommandRequest $request):array
    {
        $provider=$this->resolveProvider();
        if($provider===null)return (new DeferredPayrollCommandBusPort())->dispatch($request);
        if(!method_exists($provider,'dispatchPayrollCommand'))throw new \RuntimeException('Configured Titan Command Bus payroll adapter is incompatible.');
        $result=$provider->dispatchPayrollCommand([
            'capability'=>$request->capability,
            'company_id'=>$request->companyId,
            'actor_user_id'=>$request->actorUserId,
            'actor_type'=>$request->actorType,
            'source'=>$request->source,
            'idempotency_key'=>$request->idempotencyKey,
            'input'=>$request->input,
        ]);
        if(!is_array($result)||!isset($result['status']))throw new \RuntimeException('Titan Command Bus returned an invalid payroll result.');
        return $result;
    }
    private function resolveProvider():?object
    {
        if($this->provider!==null)return $this->provider;
        if(function_exists('app')){
            try{$app=app();if(method_exists($app,'bound')&&$app->bound(self::HOST_BINDING)){$v=$app->make(self::HOST_BINDING);return is_object($v)?$v:null;}}catch(\Throwable){}
        }
        return null;
    }
}
