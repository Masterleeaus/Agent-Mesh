<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollWorkforceWizardRegistry
{
    private array $wizards=[];
    public function __construct(?string $path=null){$path=$path??dirname(__DIR__,2).'/resources/workforce/wizards.json';$data=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);foreach((array)($data['wizards']??[]) as $w)$this->wizards[(string)$w['id']]=$w;}
    public function wizard(string $id):array{if(!isset($this->wizards[$id]))throw new \InvalidArgumentException("Unknown Payroll Workforce wizard: {$id}");return $this->wizards[$id];}
    public function all():array{return array_values($this->wizards);}
}
