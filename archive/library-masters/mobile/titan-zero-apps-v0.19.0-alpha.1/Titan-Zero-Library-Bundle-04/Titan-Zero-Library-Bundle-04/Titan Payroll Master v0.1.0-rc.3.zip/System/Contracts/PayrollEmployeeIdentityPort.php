<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Contracts;

interface PayrollEmployeeIdentityPort
{
    /** @return list<string> Canonical payroll worker references belonging to this actor inside company_id. */
    public function workerRefsForActor(int $companyId, int $actorUserId): array;
}
