<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Contracts;

interface TimeAttendancePayrollInputPort
{
    public function available(): bool;

    /** @return array{available:bool,required:bool,source:string,source_revision:?string,entries:array<int,array<string,mixed>>} */
    public function approvedInputs(int $companyId, string $periodFrom, string $periodTo, array $workerRefs = [], bool $required = true): array;
}
