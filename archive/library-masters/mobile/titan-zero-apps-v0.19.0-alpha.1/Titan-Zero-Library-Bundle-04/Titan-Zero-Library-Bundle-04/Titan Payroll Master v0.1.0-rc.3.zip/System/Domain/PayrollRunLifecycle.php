<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Domain;
final class PayrollRunLifecycle
{
    private const NEXT=['draft'=>['prepared','cancelled'],'prepared'=>['pending_approval','cancelled'],'pending_approval'=>['approved','rejected','cancelled'],'rejected'=>['prepared','cancelled'],'approved'=>['finalized','cancelled'],'finalized'=>[],'cancelled'=>[]];
    public function transition(string $from,string $to):string{if(!isset(self::NEXT[$from])||!in_array($to,self::NEXT[$from],true))throw new \DomainException("Invalid payroll run transition {$from} -> {$to}.");return $to;}
    public function correctionRequiresAdjustment(string $status):bool{return $status==='finalized';}
}
