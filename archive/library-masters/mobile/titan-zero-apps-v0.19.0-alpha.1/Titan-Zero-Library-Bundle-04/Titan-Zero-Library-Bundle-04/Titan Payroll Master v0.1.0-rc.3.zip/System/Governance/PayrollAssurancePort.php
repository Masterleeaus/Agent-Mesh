<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
interface PayrollAssurancePort
{
    public function available(): bool;
    /** @return array{allowed:bool,decision_id?:string,reason?:string} */
    public function verify(PayrollCommandRequest $request): array;
}
