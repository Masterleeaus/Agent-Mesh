<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
use Illuminate\Support\Facades\DB;
final class DatabasePayrollCommandReceiptStore implements PayrollCommandReceiptStorePort
{
    public function replay(string $key):?array
    {
        $row=DB::table('ext_titan_payroll_command_receipts')->where('receipt_key',$key)->first();
        if(!$row)return null;
        $result=json_decode((string)($row->result_json??'[]'),true)?:[];
        return array_replace($result,['replayed'=>true]);
    }
    public function reserve(string $key,array $processingReceipt):bool
    {
        return DB::table('ext_titan_payroll_command_receipts')->insertOrIgnore([
            'receipt_key'=>$key,'company_id'=>(int)($processingReceipt['company_id']??0),
            'capability'=>(string)($processingReceipt['capability']??''),'idempotency_key'=>(string)($processingReceipt['idempotency_key']??''),
            'status'=>'processing','result_json'=>json_encode($processingReceipt,JSON_UNESCAPED_SLASHES),'created_at'=>now(),'updated_at'=>now(),
        ])===1;
    }
    public function store(string $key,array $receipt):void
    {
        DB::table('ext_titan_payroll_command_receipts')->where('receipt_key',$key)->update([
            'status'=>(string)($receipt['status']??'executed'),'result_json'=>json_encode($receipt,JSON_UNESCAPED_SLASHES),'updated_at'=>now(),
        ]);
    }
}
