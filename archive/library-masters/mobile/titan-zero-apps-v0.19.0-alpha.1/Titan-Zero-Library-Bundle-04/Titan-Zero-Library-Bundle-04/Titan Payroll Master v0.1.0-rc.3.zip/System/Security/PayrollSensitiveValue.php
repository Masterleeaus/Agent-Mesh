<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Security;
final class PayrollSensitiveValue
{
    private const DENY=['bank_account','account_number','routing_number','bsb','iban','swift','tax_identifier','tax_file_number','tfn','ssn','document_html','payslip_html','raw_payslip','secret','api_key','token'];
    public static function redact(array $payload):array
    {
        $out=[];
        foreach($payload as $k=>$v){
            $key=strtolower((string)$k);
            if(self::isSensitiveKey($key)){$out[$k]='[REDACTED]';continue;}
            $out[$k]=is_array($v)?self::redact($v):$v;
        }
        return $out;
    }
    public static function mask(string $value):string{if($value==='')return '';return str_repeat('*',max(strlen($value)-4,0)).substr($value,-4);}
    public static function encrypt(string $value):string{if(!class_exists('Illuminate\\Support\\Facades\\Crypt'))throw new \RuntimeException('Host encryption service unavailable.');return \Illuminate\Support\Facades\Crypt::encryptString($value);}
    public static function decrypt(string $value):string{if(!class_exists('Illuminate\\Support\\Facades\\Crypt'))throw new \RuntimeException('Host encryption service unavailable.');return \Illuminate\Support\Facades\Crypt::decryptString($value);}
    private static function isSensitiveKey(string $key):bool
    {
        if(in_array($key,self::DENY,true))return true;
        $normalized=preg_replace('/[^a-z0-9]+/','_',$key)??$key;
        return preg_match('/(?:^|_)(?:bank_(?:account|routing)|account_number|routing_number|bsb|iban|swift|tfn|ssn|secret|api_(?:key|token)|auth_token|access_token)(?:_|$)/',$normalized)===1
            || preg_match('/(?:^|_)tax_(?:file_)?(?:identifier|number)(?:_|$)/',$normalized)===1
            || preg_match('/(?:^|_)(?:document|payslip)_(?:html|raw)(?:_|$)/',$normalized)===1
            || str_contains($normalized,'bank_account_number')
            || str_contains($normalized,'tax_file_number')
            || str_contains($normalized,'api_token');
    }
}
