<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Services;
use App\Extensions\TitanPayroll\Services\Integrations\PayrollReconciliationService;
use Illuminate\Support\Facades\DB;
final class PayrollReconciliationCoordinator
{
    public function __construct(private readonly PayrollReconciliationService $reconciliation,private readonly PayrollSignalOutboxService $signals){}
    public function reconcileAndRecord(int $companyId,int $payrollRunId,string $sourceRevision,array $expected,array $actual,string $idempotencyKey):array
    {
        if($companyId<=0||$payrollRunId<=0||trim($idempotencyKey)==='')throw new \InvalidArgumentException('Tenant, payroll run and idempotency key are required.');
        return DB::transaction(function()use($companyId,$payrollRunId,$sourceRevision,$expected,$actual,$idempotencyKey):array{
            $run=DB::table('ext_titan_payroll_runs')->where('company_id',$companyId)->where('id',$payrollRunId)->first(['id']);if(!$run)throw new \DomainException('Tenant-scoped payroll run not found.');
            $result=$this->reconciliation->reconcileBound($companyId,$payrollRunId,$sourceRevision,$expected,$actual);$hash=hash('sha256',json_encode($result,JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR));$now=now();
            DB::table('ext_titan_payroll_reconciliations')->updateOrInsert(['company_id'=>$companyId,'payroll_run_id'=>$payrollRunId,'source_revision'=>$sourceRevision,'result_hash'=>$hash],['status'=>'completed','summary'=>json_encode($result['summary'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),'completed_at'=>$now,'updated_at'=>$now,'created_at'=>$now]);
            $record=DB::table('ext_titan_payroll_reconciliations')->where('company_id',$companyId)->where('payroll_run_id',$payrollRunId)->where('source_revision',$sourceRevision)->where('result_hash',$hash)->first(['id']);$result['reconciliation_id']=(int)($record->id??0);$result['result_hash']=$hash;
            $safe=['run_id'=>$payrollRunId,'reconciliation_id'=>$result['reconciliation_id'],'source_revision'=>$sourceRevision,'source_hash'=>$hash,'status'=>'completed','summary'=>$result['summary']];$this->signals->enqueue($companyId,'payroll.reconciliation.completed',$idempotencyKey,$safe);
            if(array_sum([$result['summary']['missing'],$result['summary']['mismatched'],$result['summary']['duplicate'],$result['summary']['unresolved']])>0)$this->signals->enqueue($companyId,'payroll.variance.detected',$idempotencyKey.':variance',$safe);
            return $result;
        });
    }
}
