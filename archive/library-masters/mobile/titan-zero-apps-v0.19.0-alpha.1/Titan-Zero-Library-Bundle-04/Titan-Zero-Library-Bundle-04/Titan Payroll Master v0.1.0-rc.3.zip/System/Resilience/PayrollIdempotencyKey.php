<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Resilience;
final class PayrollIdempotencyKey{public static function forRun(int $companyId,string $periodKey,string $operation,string $clientKey):string{if($companyId<1||$periodKey===''||$operation===''||$clientKey==='')throw new \InvalidArgumentException('Complete idempotency identity is required.');return hash('sha256',implode('|',[$companyId,$periodKey,$operation,$clientKey]));}}
