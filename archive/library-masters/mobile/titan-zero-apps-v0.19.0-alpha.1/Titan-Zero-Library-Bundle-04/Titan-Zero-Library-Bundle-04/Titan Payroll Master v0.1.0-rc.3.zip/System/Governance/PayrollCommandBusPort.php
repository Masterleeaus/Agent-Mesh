<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
interface PayrollCommandBusPort { public function available(): bool; public function dispatch(PayrollCommandRequest $request): array; }
