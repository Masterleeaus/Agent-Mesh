<?php
namespace App\Extensions\TitanPayroll\System\Observability;
final class PayrollLogContext { public static function make(int $companyId,?string $trace=null,?string $correlation=null,?string $causation=null): array { return ['extension_key'=>'titan-payroll','company_id'=>$companyId,'trace_id'=>$trace,'correlation_id'=>$correlation,'causation_id'=>$causation]; } }
