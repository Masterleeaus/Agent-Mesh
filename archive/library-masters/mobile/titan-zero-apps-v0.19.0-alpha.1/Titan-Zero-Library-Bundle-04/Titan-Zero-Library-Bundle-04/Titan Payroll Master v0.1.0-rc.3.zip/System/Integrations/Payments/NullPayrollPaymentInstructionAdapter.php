<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Payments;
use App\Extensions\TitanPayroll\System\Contracts\PayrollPaymentInstructionPort;
final class NullPayrollPaymentInstructionAdapter implements PayrollPaymentInstructionPort{public function available():bool{return false;}public function transmit(array $instructions):array{return ['status'=>'prepared','prepared'=>true,'transmitted'=>false,'paid'=>false,'message'=>'Payment adapter unavailable; instructions prepared only.'];}}
