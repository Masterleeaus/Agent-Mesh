<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Communications;
use App\Extensions\TitanPayroll\System\Contracts\PayrollCommunicationsPort;
final class ConfiguredPayrollCommunicationsAdapter implements PayrollCommunicationsPort
{
    public const HOST_BINDING='titan.communications.payroll';
    public function available():bool{return $this->provider()!==null;}
    public function deliverPayslip(array $envelope):array
    {
        $provider=$this->provider();if(!$provider)return (new NullPayrollCommunicationsAdapter())->deliverPayslip($envelope);if(!method_exists($provider,'deliverPayslip'))throw new \RuntimeException('Configured Titan Communications payroll adapter is incompatible.');$result=$provider->deliverPayslip($envelope);if(!is_array($result)||empty($result['status']))throw new \RuntimeException('Titan Communications returned an invalid payslip delivery result.');return $result;
    }
    private function provider():?object{if(!function_exists('app'))return null;try{$app=app();if(method_exists($app,'bound')&&$app->bound(self::HOST_BINDING)){$v=$app->make(self::HOST_BINDING);return is_object($v)?$v:null;}}catch(\Throwable){}return null;}
}
