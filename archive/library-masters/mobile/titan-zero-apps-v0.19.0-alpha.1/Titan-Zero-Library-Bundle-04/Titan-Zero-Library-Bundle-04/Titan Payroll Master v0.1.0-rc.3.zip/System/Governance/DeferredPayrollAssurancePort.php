<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class DeferredPayrollAssurancePort implements PayrollAssurancePort
{
    public function available(): bool { return false; }
    public function verify(PayrollCommandRequest $request): array { return ['allowed'=>false,'reason'=>'Titan Assurance governance is unavailable.']; }
}
