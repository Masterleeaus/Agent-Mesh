<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Integrations\Rewind;
final class PayrollRewindRecordProjector
{
    public const CONTRACT_VERSION='1.0';
    public function project(array $record):array
    { return array_filter(['contract_version'=>self::CONTRACT_VERSION,'company_id'=>(int)($record['company_id']??0),'event_type'=>$record['event_type']??null,'sequence'=>$record['sequence']??null,'run_id'=>$record['run_id']??$record['payroll_run_id']??null,'version'=>$record['version']??null,'status'=>$record['status']??null,'source_revision'=>$record['source_revision']??null,'source_hash'=>$record['source_hash']??$record['finalized_snapshot_hash']??null,'decision_metadata'=>$this->decision($record['decision']??$record['governance']??[])],fn($v)=>$v!==null); }
    private function decision(array $d):array{return array_filter(['risk_decision_id'=>$d['risk_decision_id']??null,'assurance_decision_id'=>$d['assurance_decision_id']??null,'command_receipt_id'=>$d['command_receipt_id']??null],fn($v)=>$v!==null);}
}
