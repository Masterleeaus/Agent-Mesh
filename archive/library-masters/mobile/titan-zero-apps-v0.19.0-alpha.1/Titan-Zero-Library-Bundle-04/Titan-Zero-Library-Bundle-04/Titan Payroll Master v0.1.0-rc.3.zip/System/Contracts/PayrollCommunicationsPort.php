<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Contracts;
interface PayrollCommunicationsPort
{
    public function available():bool;
    /** @return array{status:string,receipt_ref?:string,message?:string} */
    public function deliverPayslip(array $envelope):array;
}
