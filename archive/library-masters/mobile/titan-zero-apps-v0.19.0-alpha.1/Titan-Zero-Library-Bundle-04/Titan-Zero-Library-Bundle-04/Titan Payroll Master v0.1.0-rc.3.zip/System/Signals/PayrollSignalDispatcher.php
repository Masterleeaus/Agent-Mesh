<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Signals;
use Illuminate\Support\Facades\DB;
final class PayrollSignalDispatcher
{
    public const HOST_BINDING='titan.signal.publisher';
    public function dispatchPending(int $limit=100):array
    {
        $limit=max(1,min($limit,500));$provider=$this->provider();
        if(!$provider)return ['status'=>'signal_unavailable','processed'=>0,'delivered'=>0];
        $rows=DB::table('ext_titan_payroll_signal_outbox')->where('status','pending')->where(function($q){$q->whereNull('available_at')->orWhere('available_at','<=',now());})->orderBy('id')->limit($limit)->get();
        $processed=0;$delivered=0;
        foreach($rows as $row){$processed++;$payload=json_decode((string)$row->payload,true)?:[];
            try{
                if(!method_exists($provider,'publish'))throw new \RuntimeException('signal_provider_incompatible');
                $receipt=$provider->publish((string)$row->signal,$payload,['company_id'=>(int)$row->company_id,'schema_version'=>(string)$row->schema_version,'idempotency_key'=>(string)$row->idempotency_key]);
                $ok=is_array($receipt)?(bool)($receipt['delivered']??$receipt['published']??false):$receipt===true;
                if($ok){DB::table('ext_titan_payroll_signal_outbox')->where('id',$row->id)->where('status','pending')->update(['status'=>'delivered','delivered_at'=>now(),'updated_at'=>now()]);$delivered++;continue;}
                $this->fail((int)$row->id,(int)$row->attempts);
            }catch(\Throwable){$this->fail((int)$row->id,(int)$row->attempts);}
        }
        return ['status'=>'processed','processed'=>$processed,'delivered'=>$delivered];
    }
    private function fail(int $id,int $attempts):void{$attempts++;DB::table('ext_titan_payroll_signal_outbox')->where('id',$id)->where('status','pending')->update(['attempts'=>$attempts,'status'=>$attempts>=3?'attention_required':'pending','available_at'=>now()->addMinutes(min(60,2**$attempts)),'updated_at'=>now()]);}
    private function provider():?object{if(!function_exists('app'))return null;try{$app=app();if(method_exists($app,'bound')&&$app->bound(self::HOST_BINDING)){$p=$app->make(self::HOST_BINDING);return is_object($p)?$p:null;}}catch(\Throwable){}return null;}
}
