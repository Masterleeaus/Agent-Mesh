<?php
namespace App\Extensions\TitanPayroll\System\Authorization;
final class PayrollHostAuthorization { public function allows(object $user,string $ability): bool { if(method_exists($user,'isSuperAdmin') && $user->isSuperAdmin()) return true; foreach(['can','checkPermission','hasPermissionTo'] as $m){ if(method_exists($user,$m) && $user->{$m}($ability)) return true; } return method_exists($user,'isAdmin') && $user->isAdmin() && in_array($ability,['payroll.view','payroll.manage'],true); } }
