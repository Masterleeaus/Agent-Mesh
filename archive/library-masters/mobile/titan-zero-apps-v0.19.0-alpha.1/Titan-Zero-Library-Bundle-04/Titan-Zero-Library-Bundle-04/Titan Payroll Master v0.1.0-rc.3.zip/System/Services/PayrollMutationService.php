<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Services;
use App\Extensions\TitanPayroll\System\Contracts\TimeAttendancePayrollInputPort;
use App\Extensions\TitanPayroll\System\Domain\{PayrollRunFinalizer,PayrollRunLifecycle};
use App\Extensions\TitanPayroll\System\Security\{PayrollPayslipAccessPolicy,PayrollSensitiveValue};
use Illuminate\Support\Facades\DB;
final class PayrollMutationService
{
    public function __construct(private readonly TimeAttendancePayrollInputPort $timeInputs,private readonly PayrollRunLifecycle $lifecycle,private readonly PayrollRunFinalizer $finalizer,private readonly PayrollPayslipAccessPolicy $payslipAccess,private readonly PayrollSignalOutboxService $signals){}
    public function handle(string $capability,array $input,int $companyId,int $actorUserId):array
    {
        return DB::transaction(function() use($capability,$input,$companyId,$actorUserId):array {
        $result=match($capability){
            'payroll.run.prepare'=>$this->prepare($input,$companyId),
            'payroll.run.submit'=>$this->transition($input,$companyId,$actorUserId,'prepared','pending_approval','submitted_at'),
            'payroll.run.approve'=>$this->transition($input,$companyId,$actorUserId,'pending_approval','approved','approved_at'),
            'payroll.run.reject'=>$this->reject($input,$companyId,$actorUserId),
            'payroll.run.finalize'=>$this->finalize($input,$companyId),
            'payroll.period.lock'=>$this->lockPeriod($input,$companyId,$actorUserId),
            'payroll.period.unlock'=>$this->unlockPeriod($input,$companyId,$actorUserId),
            'payroll.adjustment.create'=>$this->createAdjustment($input,$companyId,$actorUserId),
            'payroll.reconciliation.propose-resolution'=>$this->proposeReconciliationResolution($input,$companyId,$actorUserId),
            'payroll.payslip.resend'=>$this->requestPayslipResend($input,$companyId),
            'payroll.payslip.acknowledge'=>$this->acknowledgePayslip($input,$companyId,$actorUserId),
            'payroll.employee.preference.update'=>$this->updatePreference($input,$companyId,$actorUserId),
            default=>throw new \InvalidArgumentException("Unsupported Payroll mutation: {$capability}"),
        };
        $signal=$this->signalFor($capability);if($signal!==null){$idem=(string)($input['idempotency_key']??'');$payload=array_intersect_key($result,array_flip(['run_id','status','version','finalized_snapshot_hash','lock_id','period_from','period_to']));$payload['actor_user_id']=$actorUserId;$this->signals->enqueue($companyId,$signal,$idem,$payload);}
        return $result;
        });
    }
    private function signalFor(string $capability):?string{return ['payroll.run.prepare'=>'payroll.run.prepared','payroll.run.submit'=>'payroll.run.submitted','payroll.run.approve'=>'payroll.run.approved','payroll.run.reject'=>'payroll.run.rejected','payroll.run.finalize'=>'payroll.run.finalized','payroll.period.lock'=>'payroll.period.locked','payroll.period.unlock'=>'payroll.period.unlocked'][$capability]??null;}
    private function prepare(array $input,int $tenant):array
    {
        $id=$this->positiveId($input,'run_id');$observed=$this->run($tenant,$id);$required=(bool)($input['requires_time_attendance']??false);
        $workers=DB::table('ext_titan_payroll_run_items')->where('company_id',$tenant)->where('payroll_run_id',$id)->pluck('worker_ref')->map(fn($v)=>(string)$v)->all();
        $time=$this->timeInputs->approvedInputs($tenant,(string)$observed->period_from,(string)$observed->period_to,$workers,$required);
        return DB::transaction(function()use($tenant,$id,$observed,$time,$required):array{
            $run=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->lockForUpdate()->first();if(!$run)throw new \DomainException('Payroll run not found.');
            if((int)$run->version!==(int)$observed->version)throw new \DomainException('Payroll run changed while preparing. Retry with a new idempotency key.');
            $next=$this->lifecycle->transition((string)$run->status,'prepared');$snapshot=json_decode((string)($run->snapshot??''),true)?:[];
            foreach(['calculation_version','config_version'] as $field)if(trim((string)($snapshot[$field]??$run->{$field}??''))==='')throw new \DomainException("Prepared payroll snapshot is missing {$field}.");
            $source=(string)($time['source_revision']??$snapshot['source_revision']??$run->source_revision??'');if($required&&$source==='')throw new \DomainException('Approved time input is missing a stable source revision.');if(!$required&&$source==='')$source='salary-policy:no-time-required';
            $snapshot['calculation_version']=(string)($snapshot['calculation_version']??$run->calculation_version);$snapshot['config_version']=(string)($snapshot['config_version']??$run->config_version);$snapshot['source_revision']=$source;$snapshot['time_input_required']=$required;$snapshot['approved_time_entry_count']=count((array)($time['entries']??[]));
            DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->where('version',(int)$run->version)->update(['status'=>$next,'calculation_version'=>$snapshot['calculation_version'],'config_version'=>$snapshot['config_version'],'source_revision'=>$source,'snapshot'=>json_encode($snapshot,JSON_UNESCAPED_SLASHES),'prepared_at'=>now(),'version'=>(int)$run->version+1,'updated_at'=>now()]);
            return ['run_id'=>$id,'status'=>$next,'version'=>(int)$run->version+1,'time_input'=>['required'=>$required,'available'=>(bool)($time['available']??false),'entry_count'=>count((array)($time['entries']??[])),'source_revision'=>$source]];
        });
    }
    private function transition(array $input,int $tenant,int $actor,string $from,string $to,string $timestamp):array
    {
        $id=$this->positiveId($input,'run_id');return DB::transaction(function()use($id,$tenant,$actor,$from,$to,$timestamp,$input):array{
            $run=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->lockForUpdate()->first();if(!$run)throw new \DomainException('Payroll run not found.');if((string)$run->status!==$from)throw new \DomainException("Payroll run must be {$from} before {$to}.");$next=$this->lifecycle->transition((string)$run->status,$to);
            DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->where('version',(int)$run->version)->update(['status'=>$next,$timestamp=>now(),'version'=>(int)$run->version+1,'updated_at'=>now()]);
            DB::table('ext_titan_payroll_run_approvals')->updateOrInsert(['company_id'=>$tenant,'payroll_run_id'=>$id,'step'=>'finance_review'],['status'=>$next,'actor_user_id'=>$actor,'comment'=>isset($input['comment'])?substr((string)$input['comment'],0,2000):null,'acted_at'=>now(),'updated_at'=>now(),'created_at'=>now()]);
            return ['run_id'=>$id,'status'=>$next,'version'=>(int)$run->version+1];
        });
    }
    private function reject(array $input,int $tenant,int $actor):array
    {
        $reason=trim((string)($input['comment']??$input['reason']??''));if($reason==='')throw new \InvalidArgumentException('A rejection reason is required.');$input['comment']=$reason;return $this->transition($input,$tenant,$actor,'pending_approval','rejected','updated_at');
    }
    private function finalize(array $input,int $tenant):array
    {
        $id=$this->positiveId($input,'run_id');return DB::transaction(function()use($id,$tenant):array{
            $row=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->lockForUpdate()->first();if(!$row)throw new \DomainException('Payroll run not found.');$snapshot=json_decode((string)($row->snapshot??''),true)?:[];$run=(array)$row;
            $done=$this->finalizer->finalize($run,$snapshot,$tenant);$updated=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->where('version',(int)$row->version)->update(['status'=>'finalized','snapshot'=>json_encode($done['finalized_snapshot'],JSON_UNESCAPED_SLASHES),'finalized_snapshot_hash'=>$done['finalized_snapshot_hash'],'finalized_at'=>now(),'version'=>(int)$row->version+1,'updated_at'=>now()]);if($updated!==1)throw new \DomainException('Payroll finalization lost a concurrency race.');
            $payslipCount=0;
            DB::table('ext_titan_payroll_run_items')
                ->where('company_id',$tenant)
                ->where('payroll_run_id',$id)
                ->orderBy('id')
                ->chunkById(500,function($items)use($tenant,$id,&$payslipCount):void{
                    foreach($items as $item){
                        $calc=json_decode((string)($item->calculation_snapshot??''),true)?:[];
                        DB::table('ext_titan_payroll_payslips')->updateOrInsert(
                            ['company_id'=>$tenant,'payroll_run_id'=>$id,'worker_ref'=>(string)$item->worker_ref],
                            ['status'=>'finalized','gross_pay'=>(float)($calc['gross_pay']??0),'net_pay'=>(float)($calc['net_pay']??0),'currency'=>isset($calc['currency'])?(string)$calc['currency']:null,'document_ref'=>null,'document_hash'=>null,'access_version'=>1,'updated_at'=>now(),'created_at'=>now()]
                        );
                        $payslipCount++;
                    }
                },'id');
            return ['run_id'=>$id,'status'=>'finalized','version'=>(int)$row->version+1,'finalized_snapshot_hash'=>$done['finalized_snapshot_hash'],'payslip_count'=>$payslipCount];
        });
    }
    private function lockPeriod(array $input,int $tenant,int $actor):array
    {
        [$from,$to]=$this->period($input);return DB::transaction(function()use($tenant,$actor,$from,$to):array{
            $overlap=DB::table('ext_titan_payroll_period_locks')->where('company_id',$tenant)->where('status','locked')->where('period_from','<=',$to)->where('period_to','>=',$from)->lockForUpdate()->first();if($overlap)throw new \DomainException('Payroll period overlaps an active lock.');
            $id=DB::table('ext_titan_payroll_period_locks')->insertGetId(['company_id'=>$tenant,'period_from'=>$from,'period_to'=>$to,'status'=>'locked','version'=>1,'locked_by'=>$actor,'locked_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);return ['lock_id'=>$id,'status'=>'locked','period_from'=>$from,'period_to'=>$to,'version'=>1];
        });
    }
    private function unlockPeriod(array $input,int $tenant,int $actor):array
    {
        [$from,$to]=$this->period($input);$reason=trim((string)($input['reason']??''));if(strlen($reason)<5)throw new \InvalidArgumentException('A meaningful unlock reason is required.');return DB::transaction(function()use($tenant,$actor,$from,$to,$reason):array{
            $lock=DB::table('ext_titan_payroll_period_locks')->where('company_id',$tenant)->where('period_from',$from)->where('period_to',$to)->where('status','locked')->lockForUpdate()->first();if(!$lock)throw new \DomainException('Active payroll period lock not found.');DB::table('ext_titan_payroll_period_locks')->where('id',$lock->id)->where('version',(int)$lock->version)->update(['status'=>'unlocked','unlocked_by'=>$actor,'unlocked_at'=>now(),'unlock_reason'=>$reason,'version'=>(int)$lock->version+1,'updated_at'=>now()]);return ['lock_id'=>(int)$lock->id,'status'=>'unlocked','version'=>(int)$lock->version+1];
        });
    }
    private function createAdjustment(array $input,int $tenant,int $actor):array
    {
        $runId=$this->positiveId($input,'run_id');$worker=trim((string)($input['worker_ref']??''));$amount=(float)($input['amount']??0);$direction=(string)($input['direction']??'credit');$reasonCode=trim((string)($input['reason_code']??''));if($worker===''||$amount<=0||!in_array($direction,['credit','debit'],true)||$reasonCode==='')throw new \InvalidArgumentException('Adjustment requires worker_ref, positive amount, credit/debit direction and reason_code.');
        $run=$this->run($tenant,$runId);if((string)$run->status!=='finalized')throw new \DomainException('Adjustments are only used to correct finalized payroll runs.');if(!DB::table('ext_titan_payroll_run_items')->where('company_id',$tenant)->where('payroll_run_id',$runId)->where('worker_ref',$worker)->exists())throw new \DomainException('Adjustment worker is not part of the finalized payroll run.');$id=DB::table('ext_titan_payroll_adjustments')->insertGetId(['company_id'=>$tenant,'payroll_run_id'=>$runId,'worker_ref'=>$worker,'amount'=>$amount,'direction'=>$direction,'reason_code'=>$reasonCode,'reason'=>isset($input['reason'])?substr((string)$input['reason'],0,2000):null,'status'=>'pending','idempotency_key'=>(string)$input['idempotency_key'],'created_by'=>$actor,'created_at'=>now(),'updated_at'=>now()]);return ['adjustment_id'=>$id,'status'=>'pending','payroll_run_id'=>$runId];
    }

    private function proposeReconciliationResolution(array $input,int $tenant,int $actor):array
    {
        $runId=$this->positiveId($input,'run_id');$recordId=$this->positiveId($input,'reconciliation_id');$type=trim((string)($input['resolution_type']??''));$reason=trim((string)($input['reason']??''));
        if($type===''||$reason==='')throw new \InvalidArgumentException('Reconciliation resolution proposal requires resolution_type and reason.');
        $record=DB::table('ext_titan_payroll_reconciliations')->where('company_id',$tenant)->where('id',$recordId)->where('payroll_run_id',$runId)->first();if(!$record)throw new \DomainException('Tenant-scoped payroll reconciliation record not found.');
        $proposalId=DB::table('ext_titan_payroll_reconciliation_proposals')->insertGetId(['company_id'=>$tenant,'payroll_run_id'=>$runId,'reconciliation_id'=>$recordId,'resolution_type'=>$type,'reason'=>$reason,'status'=>'proposed','created_by'=>$actor,'idempotency_key'=>(string)$input['idempotency_key'],'created_at'=>now(),'updated_at'=>now()]);
        return ['proposal_id'=>$proposalId,'status'=>'proposed','auto_correct'=>false,'payroll_run_id'=>$runId,'reconciliation_id'=>$recordId];
    }
    private function requestPayslipResend(array $input,int $tenant):array
    {
        $runId=isset($input['run_id'])?(int)$input['run_id']:null;$payslipId=$this->positiveId($input,'payslip_id');$payslip=DB::table('ext_titan_payroll_payslips')->where('company_id',$tenant)->where('id',$payslipId)->first();if(!$payslip)throw new \DomainException('Payslip not found.');if($runId&&$runId!==(int)$payslip->payroll_run_id)throw new \DomainException('Payslip does not belong to the supplied payroll run.');$runId=(int)$payslip->payroll_run_id;$id=DB::table('ext_titan_payroll_delivery_receipts')->insertGetId(['company_id'=>$tenant,'payroll_run_id'=>$runId,'channel'=>'payslip','provider_state'=>'pending_communications','external_receipt_ref'=>null,'idempotency_key'=>(string)$input['idempotency_key'],'created_at'=>now(),'updated_at'=>now()]);return ['delivery_receipt_id'=>$id,'provider_state'=>'pending_communications','delivered'=>false];
    }
    private function acknowledgePayslip(array $input,int $tenant,int $actor):array
    {
        $id=$this->positiveId($input,'payslip_id');return DB::transaction(function()use($id,$tenant,$actor):array{$row=DB::table('ext_titan_payroll_payslips')->where('company_id',$tenant)->where('id',$id)->lockForUpdate()->first();if(!$row)throw new \DomainException('Payslip not found.');$this->payslipAccess->assertRecordAccess($tenant,$actor,$row);if(!empty($row->acknowledged_at))return ['payslip_id'=>$id,'status'=>'acknowledged','already_acknowledged'=>true];DB::table('ext_titan_payroll_payslips')->where('company_id',$tenant)->where('id',$id)->update(['status'=>'acknowledged','acknowledged_by'=>$actor,'acknowledged_at'=>now(),'access_version'=>(int)$row->access_version+1,'updated_at'=>now()]);return ['payslip_id'=>$id,'status'=>'acknowledged','already_acknowledged'=>false];});
    }
    private function updatePreference(array $input,int $tenant,int $actor):array
    {
        $key=trim((string)($input['preference_key']??''));if($key===''||!array_key_exists('value',$input))throw new \InvalidArgumentException('preference_key and value are required.');$worker='user:'.$actor;$encrypted=PayrollSensitiveValue::encrypt(json_encode($input['value'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));return DB::transaction(function()use($tenant,$worker,$key,$encrypted):array{$q=DB::table('ext_titan_payroll_employee_preferences')->where('company_id',$tenant)->where('worker_ref',$worker)->where('preference_key',$key);$row=$q->lockForUpdate()->first();if($row){$version=(int)$row->version+1;$q->update(['encrypted_value'=>$encrypted,'version'=>$version,'updated_at'=>now()]);}else{$version=1;DB::table('ext_titan_payroll_employee_preferences')->insert(['company_id'=>$tenant,'worker_ref'=>$worker,'preference_key'=>$key,'encrypted_value'=>$encrypted,'version'=>$version,'created_at'=>now(),'updated_at'=>now()]);}return ['worker_ref'=>$worker,'preference_key'=>$key,'updated'=>true,'version'=>$version];});
    }
    private function run(int $tenant,int $id):object{$run=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->where('id',$id)->first();if(!$run)throw new \DomainException('Payroll run not found.');return $run;}
    private function positiveId(array $input,string $key):int{$id=(int)($input[$key]??0);if($id<1)throw new \InvalidArgumentException("{$key} is required.");return $id;}
    private function period(array $input):array{$from=(string)($input['period_from']??'');$to=(string)($input['period_to']??'');if($from===''||$to===''||$from>$to)throw new \InvalidArgumentException('Valid period_from and period_to are required.');return [$from,$to];}
}
