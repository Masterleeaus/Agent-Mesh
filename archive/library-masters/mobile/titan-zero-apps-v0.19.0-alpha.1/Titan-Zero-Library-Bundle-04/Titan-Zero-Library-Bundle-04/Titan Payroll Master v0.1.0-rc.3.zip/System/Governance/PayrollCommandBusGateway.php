<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
use App\Extensions\TitanPayroll\System\Authorization\PayrollHostAuthorization;
use App\Extensions\TitanPayroll\System\Support\{PayrollCapabilityCatalog,PayrollCompanyContext};
final class PayrollCommandBusGateway
{
    private readonly PayrollRiskPort $risk;
    private readonly PayrollAssurancePort $assurance;
    public function __construct(
        private readonly PayrollCommandBusPort $port,
        private readonly PayrollCapabilityExecutor $executor,
        private readonly PayrollCommandReceiptStorePort $receipts,
        private readonly PayrollHostAuthorization $authorization,
        private readonly array $humanSources=['payroll_web','payroll_api'],
        private readonly bool $allowLocalHumanMutations=true,
        ?PayrollRiskPort $risk=null,
        ?PayrollAssurancePort $assurance=null,
    ) {
        $this->risk=$risk??new DeferredPayrollRiskPort();
        $this->assurance=$assurance??new DeferredPayrollAssurancePort();
    }
    public function request(string $capability,array $input,object $user,string $source='payroll_web',string $actorType='human'):array
    {
        $d=PayrollCapabilityCatalog::definition($capability);
        if(($d['mode']??'read')!=='write')throw new \InvalidArgumentException('PayrollCommandBusGateway accepts governed writes only.');
        if(!$this->authorization->allows($user,(string)$d['permission']))throw new \RuntimeException('Payroll capability denied.');
        $tenant=PayrollCompanyContext::id($user);$actorId=(int)(method_exists($user,'getKey')?$user->getKey():($user->id??0));
        $idem=trim((string)($input['idempotency_key']??''));if(($d['idempotent']??false)&&$idem==='')throw new \InvalidArgumentException('Idempotency key is required for this Payroll write.');
        unset($input['company_id']);
        $request=new PayrollCommandRequest($capability,$input,$tenant,$actorId,$source,$actorType,$idem,$d);$key=$request->receiptKey();
        if(($replay=$this->receipts->replay($key))!==null)return $replay;
        $processing=['status'=>'processing','executed'=>false,'capability'=>$request->capability,'company_id'=>$tenant,'idempotency_key'=>$idem,'replayed'=>false];
        if(!$this->receipts->reserve($key,$processing))return $this->receipts->replay($key)??$processing;

        $human=$actorType==='human'&&in_array($source,$this->humanSources,true);
        $localFallback=!$this->port->available()&&$this->allowLocalHumanMutations&&$human;
        try {
            if(!$this->port->available()&&!$localFallback){
                $result=$this->port->dispatch($request);
                $receipt=$this->envelope($request,$result,false,[]);$this->receipts->store($key,$receipt);return $receipt;
            }
            $governance=$this->governanceEvidence($request);
            $result=$this->port->available()?$this->port->dispatch($request):$this->executor->execute($request);
            $receipt=$this->envelope($request,$result,$localFallback,$governance);$this->receipts->store($key,$receipt);return $receipt;
        } catch (\Throwable $e) {
            $failed=['status'=>'attention_required','executed'=>false,'capability'=>$request->capability,'company_id'=>$tenant,'idempotency_key'=>$idem,'reason'=>'Payroll command execution or governance failed.','failure_type'=>(new \ReflectionClass($e))->getShortName(),'replayed'=>false];
            $this->receipts->store($key,$failed);throw $e;
        }
    }
    private function governanceEvidence(PayrollCommandRequest $request):array
    {
        if(!in_array(strtoupper((string)($request->definition['risk']??'LOW')),['HIGH','CRITICAL'],true))return ['required'=>false];
        if(!$this->risk->available()||!$this->assurance->available())throw new \RuntimeException('Required payroll governance is unavailable.');
        $risk=$this->risk->assess($request);if(($risk['allowed']??false)!==true)throw new \RuntimeException('Payroll governance denied by Risk.');
        $assurance=$this->assurance->verify($request);if(($assurance['allowed']??false)!==true)throw new \RuntimeException('Payroll governance denied by Assurance.');
        return ['required'=>true,'risk_decision_id'=>$risk['decision_id']??null,'assurance_decision_id'=>$assurance['decision_id']??null];
    }
    private function envelope(PayrollCommandRequest $r,array $result,bool $local,array $governance):array
    {
        $executed=$local?true:(bool)($result['executed']??(($result['status']??'')==='executed'));
        $status=$local?'executed':(string)($result['status']??($executed?'executed':'attention_required'));
        return ['status'=>$status,'executed'=>$executed,'local_fallback'=>$local,'capability'=>$r->capability,'company_id'=>$r->companyId,'idempotency_key'=>$r->idempotencyKey,'governance'=>$governance,'result'=>$result,'replayed'=>false];
    }
}
