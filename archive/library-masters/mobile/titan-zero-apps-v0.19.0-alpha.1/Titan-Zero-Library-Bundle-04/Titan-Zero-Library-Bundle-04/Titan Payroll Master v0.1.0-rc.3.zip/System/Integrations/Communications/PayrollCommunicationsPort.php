<?php
namespace App\Extensions\TitanPayroll\System\Integrations\Communications;
interface PayrollCommunicationsPort { public function deliverPayslip(int $companyId,string $workerRef,string $documentRef,string $channel): array; }
