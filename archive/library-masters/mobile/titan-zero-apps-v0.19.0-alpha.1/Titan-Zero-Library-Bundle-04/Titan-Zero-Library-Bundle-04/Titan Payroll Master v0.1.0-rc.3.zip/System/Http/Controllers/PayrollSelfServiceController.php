<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Http\Controllers;
use App\Extensions\TitanPayroll\System\Services\PayrollSelfServiceReadService;
use Illuminate\Http\{JsonResponse,Request};
use Illuminate\Routing\Controller;
final class PayrollSelfServiceController extends Controller
{
    public function index(Request $request,PayrollSelfServiceReadService $service):JsonResponse{return response()->json($service->payslipsForActor($request->user(),(int)$request->query('limit',12)));}
}
