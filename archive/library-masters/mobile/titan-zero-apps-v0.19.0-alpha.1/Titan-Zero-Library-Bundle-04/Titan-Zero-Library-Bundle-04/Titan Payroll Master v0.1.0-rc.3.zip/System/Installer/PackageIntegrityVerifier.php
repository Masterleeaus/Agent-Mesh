<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Installer;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use FilesystemIterator;

final class PackageIntegrityVerifier
{
    private const ROOT_KEYS = ['schema','slug','folder','provider','version','integrity'];
    private const PROVIDER = 'App\\Extensions\\TitanPayroll\\System\\TitanPayrollServiceProvider';
    private const FORBIDDEN_BASENAMES = ['.DS_Store','Thumbs.db','.env','.env.local','id_rsa','id_ed25519'];
    private const FORBIDDEN_SUFFIXES = ['.tmp','.swp','.swo','.bak','.orig','.pem','.p12','.pfx','.key'];

    /** @return array{ok:bool,verified_files:int,errors:list<string>} */
    public function verifyDirectory(string $root): array
    {
        $root = rtrim($root, DIRECTORY_SEPARATOR);
        $errors = [];
        if (!is_dir($root)) {
            return ['ok'=>false,'verified_files'=>0,'errors'=>['Package root is not a directory.']];
        }

        $manifestPath = $root.'/extension.json';
        if (!is_file($manifestPath) || is_link($manifestPath)) {
            return ['ok'=>false,'verified_files'=>0,'errors'=>['extension.json is missing or is a symlink.']];
        }
        try {
            $manifest = json_decode((string) file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);
        } catch (\Throwable) {
            return ['ok'=>false,'verified_files'=>0,'errors'=>['extension.json is not valid JSON.']];
        }
        if (!is_array($manifest)) {
            return ['ok'=>false,'verified_files'=>0,'errors'=>['extension.json must be a JSON object.']];
        }
        $keys = array_keys($manifest);
        sort($keys); $expected = self::ROOT_KEYS; sort($expected);
        if ($keys !== $expected) $errors[] = 'extension.json does not use the strict Installer 1.7.8 Step-10 root shape.';
        if (($manifest['folder'] ?? null) !== 'TitanPayroll') $errors[] = 'extension folder must be TitanPayroll.';
        if (($manifest['provider'] ?? null) !== self::PROVIDER) $errors[] = 'extension provider does not match TitanPayrollServiceProvider.';

        $providerPath = $root.'/System/TitanPayrollServiceProvider.php';
        if (!is_file($providerPath) || is_link($providerPath)) $errors[] = 'Provider file is missing or casing is incorrect.';

        $declared = $manifest['integrity']['files'] ?? null;
        if (!is_array($declared) || $declared === []) {
            $errors[] = 'extension.json integrity.files is missing or empty.';
            return ['ok'=>false,'verified_files'=>0,'errors'=>$errors];
        }

        $actual = [];
        $caseMap = [];
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $file) {
            $path = $file->getPathname();
            $rel = str_replace('\\','/',substr($path, strlen($root)+1));
            if ($rel === 'extension.json') continue;
            if ($file->isLink() || is_link($path)) { $errors[] = "Symlink is forbidden: {$rel}"; continue; }
            if (!$file->isFile()) continue;
            if (!$this->safePath($rel)) { $errors[] = "Unsafe package path: {$rel}"; continue; }
            if ($this->forbiddenArtifact($rel)) $errors[] = "Forbidden package artifact: {$rel}";
            $lower = strtolower($rel);
            if (isset($caseMap[$lower]) && $caseMap[$lower] !== $rel) $errors[] = "Case-colliding paths: {$caseMap[$lower]} and {$rel}";
            $caseMap[$lower] = $rel;
            $actual[$rel] = hash_file('sha256', $path);
        }

        foreach ($declared as $rel=>$hash) {
            if (!is_string($rel) || !$this->safePath($rel) || $rel === 'extension.json') { $errors[] = 'Invalid integrity path entry.'; continue; }
            if (!is_string($hash) || preg_match('/^[a-f0-9]{64}$/D',$hash)!==1) { $errors[] = "Invalid integrity hash: {$rel}"; continue; }
            if (!isset($actual[$rel])) { $errors[] = "Integrity file missing: {$rel}"; continue; }
            if (!hash_equals($hash,$actual[$rel])) $errors[] = "Integrity mismatch: {$rel}";
        }
        foreach (array_diff(array_keys($actual), array_keys($declared)) as $rel) $errors[] = "Undeclared package file: {$rel}";

        return ['ok'=>$errors===[],'verified_files'=>count($actual),'errors'=>array_values(array_unique($errors))];
    }

    private function safePath(string $rel): bool
    {
        if ($rel==='' || str_starts_with($rel,'/') || str_contains($rel,"\0")) return false;
        $parts = explode('/',$rel);
        foreach ($parts as $part) if ($part==='' || $part==='.' || $part==='..') return false;
        return !preg_match('/^[A-Za-z]:[\\\\\/]/',$rel);
    }

    private function forbiddenArtifact(string $rel): bool
    {
        $base = basename($rel);
        if (in_array($base,self::FORBIDDEN_BASENAMES,true)) return true;
        if ($base === '.gitkeep' || str_starts_with($rel,'.git/')) return true;
        foreach (self::FORBIDDEN_SUFFIXES as $suffix) if (str_ends_with(strtolower($base),$suffix)) return true;
        return false;
    }
}
