<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Http\Controllers;
use App\Extensions\TitanPayroll\System\Governance\PayrollCommandBusGateway;
use Illuminate\Http\{JsonResponse,Request};
use Illuminate\Routing\Controller;
final class PayrollMutationController extends Controller
{
    public function __construct(private readonly PayrollCommandBusGateway $gateway){}
    public function prepare(Request $r):JsonResponse{return $this->run($r,'payroll.run.prepare');}
    public function submit(Request $r):JsonResponse{return $this->run($r,'payroll.run.submit');}
    public function approve(Request $r):JsonResponse{return $this->run($r,'payroll.run.approve');}
    public function reject(Request $r):JsonResponse{return $this->run($r,'payroll.run.reject');}
    public function finalize(Request $r):JsonResponse{return $this->run($r,'payroll.run.finalize');}
    public function lock(Request $r):JsonResponse{return $this->run($r,'payroll.period.lock');}
    public function unlock(Request $r):JsonResponse{return $this->run($r,'payroll.period.unlock');}
    public function adjustment(Request $r):JsonResponse{return $this->run($r,'payroll.adjustment.create');}
    public function resendPayslip(Request $r):JsonResponse{return $this->run($r,'payroll.payslip.resend');}
    public function acknowledgePayslip(Request $r):JsonResponse{return $this->run($r,'payroll.payslip.acknowledge');}
    public function updatePreference(Request $r):JsonResponse{return $this->run($r,'payroll.employee.preference.update');}
    private function run(Request $request,string $capability):JsonResponse
    {
        $actor=$request->user();abort_if(!$actor,401,'Authentication required.');
        $idempotency=trim((string)($request->header('Idempotency-Key')?:$request->input('idempotency_key','')));abort_if($idempotency==='',422,'Idempotency-Key is required.');
        $input=$request->except(['company_id','user_id','employee_id']); if($request->route('run')!==null)$input['run_id']=(int)$request->route('run'); if($request->route('payslip')!==null)$input['payslip_id']=(int)$request->route('payslip'); $input['idempotency_key']=$idempotency;
        return response()->json($this->gateway->request($capability,$input,$actor,'payroll_api','human'));
    }
}
