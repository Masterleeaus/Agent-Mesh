<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
use App\Extensions\TitanPayroll\Services\Forecasting\PayrollForecastService;
use App\Extensions\TitanPayroll\System\Compliance\PayrollRuleSetRegistry;
use Illuminate\Support\Facades\DB;
final class PayrollWorkforceReadService
{
    public function __construct(private readonly PayrollForecastService $forecast,private readonly PayrollRuleSetRegistry $rules){}
    public function runs(PayrollWorkforceExecutionContext $ctx,array $input):array
    {
        $q=DB::table('ext_titan_payroll_runs')->where('company_id',$ctx->companyId)->select(['id','period_key','period_from','period_to','status','calculation_version','config_version','source_revision','version','finalized_snapshot_hash','prepared_at','submitted_at','approved_at','finalized_at']);if(isset($input['run_id']))$q->where('id',(int)$input['run_id']);$rows=$q->orderByDesc('id')->limit(min(100,max(1,(int)($input['limit']??25))))->get();return ['company_id'=>$ctx->companyId,'runs'=>array_map(fn($r)=>(array)$r,$rows->all())];
    }
    public function reconciliation(PayrollWorkforceExecutionContext $ctx,array $input):array
    {
        $q=DB::table('ext_titan_payroll_reconciliations')->where('company_id',$ctx->companyId)->select(['id','payroll_run_id','source_revision','status','result_hash','summary','completed_at']);if(isset($input['run_id']))$q->where('payroll_run_id',(int)$input['run_id']);$rows=$q->orderByDesc('id')->limit(50)->get();return ['company_id'=>$ctx->companyId,'reconciliations'=>array_map(function($r){$a=(array)$r;if(isset($a['summary'])&&is_string($a['summary']))$a['summary']=json_decode($a['summary'],true)?:[];return $a;},$rows->all())];
    }
    public function compliance(PayrollWorkforceExecutionContext $ctx,array $input):array
    {
        $jurisdiction=strtoupper(trim((string)($input['jurisdiction']??'')));$date=trim((string)($input['effective_date']??''));if($jurisdiction===''||$date==='')return ['company_id'=>$ctx->companyId,'status'=>'needs_rule_context','legal_certification'=>false];$set=$this->rules->resolve($jurisdiction,$date);return ['company_id'=>$ctx->companyId,'status'=>'configured_validation_available','rule'=>$set->explain(),'legal_certification'=>false];
    }
    public function forecast(PayrollWorkforceExecutionContext $ctx,array $input):array
    {
        $runId=(int)($input['run_id']??0);if($runId<1)throw new \InvalidArgumentException('Forecast requires a canonical payroll run id.');$run=DB::table('ext_titan_payroll_runs')->where('company_id',$ctx->companyId)->where('id',$runId)->first(['id','snapshot','finalized_snapshot_hash','status']);if(!$run)throw new \DomainException('Tenant-scoped payroll run not found.');$snapshot=json_decode((string)($run->snapshot??''),true)?:[];$base=(float)($snapshot['net_total']??$snapshot['net_payroll_total']??0);if($base<=0)throw new \DomainException('Payroll run has no deterministic net-payroll total for forecasting.');return $this->forecast->scenario($ctx->companyId,$base,(float)($input['growth_rate']??0),(int)($input['months']??12),['basis'=>'canonical_payroll_run','run_id'=>$runId,'run_status'=>(string)$run->status,'source_hash'=>(string)($run->finalized_snapshot_hash??'')]);
    }
}
