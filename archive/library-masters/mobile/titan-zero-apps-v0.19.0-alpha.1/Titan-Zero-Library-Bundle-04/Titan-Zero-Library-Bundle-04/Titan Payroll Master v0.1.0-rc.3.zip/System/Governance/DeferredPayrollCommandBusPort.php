<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class DeferredPayrollCommandBusPort implements PayrollCommandBusPort
{
    public function available(): bool{return false;}
    public function dispatch(PayrollCommandRequest $request): array{return ['status'=>'blocked_dependency','executed'=>false,'capability'=>$request->capability,'company_id'=>$request->companyId,'idempotency_key'=>$request->idempotencyKey,'reason'=>'Titan Command Bus is unavailable.'];}
}
