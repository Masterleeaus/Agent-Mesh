<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Identity;

use App\Extensions\TitanPayroll\System\Contracts\PayrollEmployeeIdentityPort;
use Illuminate\Contracts\Foundation\Application;

final class ConfiguredPayrollEmployeeIdentityPort implements PayrollEmployeeIdentityPort
{
    private const PEOPLE_IDENTITY_ALIAS = 'titan.people.identity';

    public function __construct(private readonly Application $app) {}

    public function workerRefsForActor(int $companyId, int $actorUserId): array
    {
        if ($companyId < 1 || $actorUserId < 1) throw new \InvalidArgumentException('Canonical company and actor are required.');

        // A platform-user reference is intrinsically tied to the authenticated actor.
        $refs = ['user:'.$actorUserId];

        // A People worker ID is a separate namespace. Resolve it explicitly through
        // the owning provider's public identity alias; never infer worker:<user_id>.
        if (! $this->app->bound(self::PEOPLE_IDENTITY_ALIAS)) return $refs;
        try {
            $identity = $this->app->make(self::PEOPLE_IDENTITY_ALIAS);
            if (! is_object($identity) || ! method_exists($identity, 'resolveWorker')) return $refs;
            $worker = $identity->resolveWorker($companyId, $actorUserId);
            $workerCompanyId = (int) ($worker->companyId ?? 0);
            $workerId = (int) ($worker->workerId ?? 0);
            if ($workerCompanyId === $companyId && $workerId > 0) $refs[] = 'worker:'.$workerId;
        } catch (\Throwable) {
            // Fail closed for the People namespace while preserving the authenticated user reference.
        }
        return array_values(array_unique($refs));
    }
}
