<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class PayrollMenuRegistrar
{
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function registerContributions(): void
    {
        $items = PayrollNavigation::items();
        if ($this->registerWith(self::USER_REGISTRY, [[$items], ['titan-payroll',$items], ['navigation.user','titan-payroll',$items]])) return;
        $this->registerWith(self::CONTRIBUTION_REGISTRY, [['navigation.user','titan-payroll',$items], ['navigation.user',$items], [$items]]);
    }

    public function syncHostMenu(bool $forceRegenerate = false): array
    {
        if (!Schema::hasTable('menus')) return ['available'=>false,'changed'=>false,'regenerated'=>false,'reason'=>'menus_table_unavailable'];
        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (!isset($columns['key'])) return ['available'=>false,'changed'=>false,'regenerated'=>false,'reason'=>'menus_key_column_unavailable'];
            $changed = false;
            $parentId = null;
            foreach (PayrollNavigation::items() as $definition) {
                $key = (string)$definition['key'];
                if ($key !== 'titan-payroll' && $parentId === null) $parentId = DB::table('menus')->where('key','titan-payroll')->value('id');
                $existing = DB::table('menus')->where('key',$key)->first();
                $payload = array_intersect_key([
                    'parent_id'=>$key==='titan-payroll'?null:$parentId,
                    'route'=>$definition['route'] ?? null,
                    'label'=>$definition['label'] ?? $key,
                    'type'=>'item','updated_at'=>now(),
                ], $columns);
                if ($existing) {
                    $needs = false;
                    foreach ($payload as $col=>$val) { if ($col==='updated_at') continue; if ((string)($existing->{$col}??null)!==(string)$val) { $needs=true; break; } }
                    if ($needs) { DB::table('menus')->where('key',$key)->update($payload); $changed=true; }
                    if ($key==='titan-payroll') $parentId=$existing->id ?? $parentId;
                    continue;
                }
                $insert = array_intersect_key(array_merge([
                    'key'=>$key,'order'=>(int)($definition['order'] ?? 31),'is_active'=>1,'created_at'=>now(),
                    'custom_menu'=>0,'bolt_menu'=>0,'letter_icon'=>0,
                ],$payload),$columns);
                DB::table('menus')->insert($insert); $changed=true;
                if ($key==='titan-payroll') $parentId=DB::table('menus')->where('key',$key)->value('id');
            }
            $regenerated = false;
            if ($changed || $forceRegenerate) $regenerated = $this->regenerateMenuCache();
            return ['available'=>true,'changed'=>$changed,'regenerated'=>$regenerated,'reason'=>null];
        } catch (\Throwable) {
            return ['available'=>false,'changed'=>false,'regenerated'=>false,'reason'=>'menu_sync_failed'];
        }
    }

    private function registerWith(string $class, array $argumentSets): bool
    {
        if (!class_exists($class)) return false;
        try { $registry = app($class); } catch (\Throwable) { return false; }
        foreach (['register','contribute','add'] as $method) {
            if (!method_exists($registry,$method)) continue;
            foreach ($argumentSets as $args) { try { $registry->{$method}(...$args); return true; } catch (\Throwable) {} }
        }
        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class=self::MENU_SERVICE;
        if (!class_exists($class) || !method_exists($class,'regenerate')) return false;
        try { app($class)->regenerate(); return true; } catch (\Throwable) {
            try { $class::regenerate(); return true; } catch (\Throwable) { return false; }
        }
    }
}
