<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Domain;
final class PayrollReconciliationRecord
{
    public function __construct(
        public readonly int $companyId,
        public readonly int $payrollRunId,
        public readonly string $sourceRevision,
        public readonly array $matched,
        public readonly array $missing,
        public readonly array $mismatched,
        public readonly array $duplicate,
        public readonly array $unresolved,
        public readonly array $resolutionProposals,
    ) {}
    public function toArray(): array
    {
        return [
            'company_id'=>$this->companyId,'payroll_run_id'=>$this->payrollRunId,'source_revision'=>$this->sourceRevision,
            'matched'=>$this->matched,'missing'=>$this->missing,'mismatched'=>$this->mismatched,'duplicate'=>$this->duplicate,'unresolved'=>$this->unresolved,
            'resolution_proposals'=>$this->resolutionProposals,
            'summary'=>['matched'=>count($this->matched),'missing'=>count($this->missing),'mismatched'=>count($this->mismatched),'duplicate'=>count($this->duplicate),'unresolved'=>count($this->unresolved)],
        ];
    }
}
