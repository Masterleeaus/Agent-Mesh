<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Support;

final class PayrollCapabilityCatalog
{
    public static function definitions(): array
    {
        return [
            'payroll.run.read'=>self::d('read','payroll.view','LOW',false,false,'read'),
            'payroll.run.prepare'=>self::d('write','payroll.manage','HIGH',false,true,'payroll.run.prepare'),
            'payroll.run.submit'=>self::d('write','payroll.manage','HIGH',true,true,'payroll.run.submit'),
            'payroll.run.approve'=>self::d('write','payroll.approve','CRITICAL',true,true,'payroll.run.approve'),
            'payroll.run.reject'=>self::d('write','payroll.approve','HIGH',true,true,'payroll.run.reject'),
            'payroll.run.finalize'=>self::d('write','payroll.finalize','CRITICAL',true,true,'payroll.run.finalize'),
            'payroll.period.lock'=>self::d('write','payroll.manage','HIGH',true,true,'payroll.period.lock'),
            'payroll.period.unlock'=>self::d('write','payroll.manage','CRITICAL',true,true,'payroll.period.unlock'),
            'payroll.adjustment.create'=>self::d('write','payroll.adjust','CRITICAL',true,true,'payroll.adjustment.create'),
            'payroll.reconciliation.propose-resolution'=>self::d('write','payroll.adjust','HIGH',true,true,'payroll.reconciliation.propose-resolution'),
            'payroll.payslip.resend'=>self::d('write','payroll.manage','HIGH',false,true,'payroll.payslip.resend'),
            'payroll.payslip.acknowledge'=>self::d('write','payroll.self-service','LOW',false,true,'payroll.payslip.acknowledge'),
            'payroll.employee.preference.update'=>self::d('write','payroll.self-service','HIGH',false,true,'payroll.employee.preference.update'),
        ];
    }
    public static function definition(string $capability): array
    {
        $d=self::definitions()[$capability]??null; if($d===null)throw new \InvalidArgumentException("Unknown Titan Payroll capability: {$capability}"); return ['id'=>$capability]+$d;
    }
    private static function d(string $mode,string $permission,string $risk,bool $approval,bool $idempotent,string $handler): array
    { return compact('mode','permission','risk','handler')+['human_approval'=>$approval,'idempotent'=>$idempotent,'command_bus_required'=>$mode==='write']; }
}
