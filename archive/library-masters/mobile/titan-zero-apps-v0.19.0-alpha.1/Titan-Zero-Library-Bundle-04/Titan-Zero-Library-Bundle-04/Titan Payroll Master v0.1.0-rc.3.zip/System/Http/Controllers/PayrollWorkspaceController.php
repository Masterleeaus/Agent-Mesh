<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Http\Controllers;
use App\Extensions\TitanPayroll\System\Support\PayrollCompanyContext;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
final class PayrollWorkspaceController extends Controller
{
    public function overview():View{return $this->view('overview');}
    public function runs():View{return $this->view('runs');}
    public function timeInputs():View{return $this->view('time-inputs');}
    public function payslips():View{return $this->view('payslips');}
    public function approvals():View{return $this->view('approvals');}
    public function reconciliation():View{return $this->view('reconciliation');}
    public function reports():View{return $this->view('reports');}
    public function settings():View{return $this->view('settings');}
    private function view(string $section):View
    {
        $user=request()->user();$tenant=PayrollCompanyContext::id($user);$limit=50;
        $runs=DB::table('ext_titan_payroll_runs')->where('company_id',$tenant)->orderByDesc('id')->limit($limit)->get(['id','period_key','period_from','period_to','status','version','prepared_at','submitted_at','approved_at','finalized_at']);
        $payslips=DB::table('ext_titan_payroll_payslips')->where('company_id',$tenant)->orderByDesc('id')->limit($limit)->get(['id','payroll_run_id','worker_ref','status','gross_pay','net_pay','currency','acknowledged_at','created_at']);
        $approvals=DB::table('ext_titan_payroll_run_approvals')->where('company_id',$tenant)->orderByDesc('id')->limit($limit)->get();
        $reconciliations=DB::table('ext_titan_payroll_reconciliations')->where('company_id',$tenant)->orderByDesc('id')->limit($limit)->get(['id','payroll_run_id','source_revision','status','summary','completed_at']);
        $locks=DB::table('ext_titan_payroll_period_locks')->where('company_id',$tenant)->orderByDesc('id')->limit($limit)->get();
        $signalAttention=DB::table('ext_titan_payroll_signal_outbox')->where('company_id',$tenant)->where('status','attention_required')->count();
        $governance=['command_bus'=>'required_for_ai_writes','risk_assurance'=>'fail_closed_for_high_critical'];
        $blockers=['unresolved'=>$reconciliations->where('status','!=','completed')->count(),'time_attendance'=>'required_for_hourly','signal_attention'=>$signalAttention];
        $provenance=['tenant_key'=>'company_id','company_id'=>$tenant,'source'=>'actor_context','calculation'=>'deterministic'];
        return view('titan-payroll::workspaces.'.$section,compact('section','tenant','runs','payslips','approvals','reconciliations','locks','governance','blockers','provenance'));
    }
}
