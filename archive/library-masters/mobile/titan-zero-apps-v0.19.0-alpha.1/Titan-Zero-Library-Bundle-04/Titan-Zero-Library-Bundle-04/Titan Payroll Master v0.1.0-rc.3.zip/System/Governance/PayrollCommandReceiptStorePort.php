<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
interface PayrollCommandReceiptStorePort
{
    public function replay(string $key): ?array;
    public function reserve(string $key,array $processingReceipt): bool;
    public function store(string $key,array $receipt): void;
}
