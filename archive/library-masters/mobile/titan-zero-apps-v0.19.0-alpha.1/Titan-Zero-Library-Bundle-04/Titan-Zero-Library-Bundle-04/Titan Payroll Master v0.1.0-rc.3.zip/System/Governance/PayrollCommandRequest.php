<?php

declare(strict_types=1);

namespace App\Extensions\TitanPayroll\System\Governance;

final class PayrollCommandRequest
{
    public function __construct(
        public readonly string $capability, public readonly array $input, public readonly int $companyId,
        public readonly int $actorUserId, public readonly string $source, public readonly string $actorType,
        public readonly string $idempotencyKey, public readonly array $definition,
    ) {}
    public function receiptKey(): string { return hash('sha256',$this->companyId.'|'.$this->capability.'|'.$this->idempotencyKey); }
}
