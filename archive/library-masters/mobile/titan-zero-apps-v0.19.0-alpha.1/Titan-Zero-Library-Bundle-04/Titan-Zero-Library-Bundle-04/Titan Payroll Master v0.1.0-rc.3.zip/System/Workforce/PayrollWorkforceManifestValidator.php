<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
use RuntimeException;
final class PayrollWorkforceManifestValidator
{
    public function validate(array $m,?string $extensionVersion=null):void
    {
        if(($m['schema_version']??null)!=='2.0')throw new RuntimeException('Workforce schema 2.0 required');
        if($extensionVersion!==null&&($m['extension']['version']??null)!==$extensionVersion)throw new RuntimeException('Workforce extensionVersion mismatch');
        $roles=[];foreach($m['roles']??[] as $r){$id=(string)($r['role_id']??'');if($id===''||isset($roles[$id]))throw new RuntimeException('Duplicate or missing role');$roles[$id]=1;if(($r['status']??null)!=='available_definition')throw new RuntimeException('Role cannot auto-activate');}
        $capabilities=[];foreach($m['capabilities']??[] as $c){$name=(string)($c['name']??'');if($name===''||isset($capabilities[$name]))throw new RuntimeException('Duplicate or missing capabilities');$capabilities[$name]=1;}
        $tools=[];foreach($m['tools']??[] as $t){$id=(string)($t['id']??'');if($id===''||isset($tools[$id]))throw new RuntimeException('Duplicate tool');$tools[$id]=$t;if(!isset($capabilities[(string)($t['capability']??'')]))throw new RuntimeException('Tool references unknown capabilities');if(($t['writes_state']??false)&&($t['execution']??null)!=='command_bus')throw new RuntimeException('Writes require Command Bus');}
        foreach($m['roles']??[] as $r)foreach($r['tools']??[] as $id)if(!isset($tools[$id]))throw new RuntimeException('Unknown tool '.$id);
        $workflows=json_decode((string)file_get_contents(dirname(__DIR__,2).'/resources/workforce/workflows.json'),true,512,JSON_THROW_ON_ERROR)['workflows']??[];$workflowIds=[];
        foreach($workflows as $w){$workflowIds[(string)$w['id']]=1;foreach($w['steps']??[] as $step)if(!isset($tools[$step]))throw new RuntimeException('workflows reference unknown tool '.$step);}
        $wizards=json_decode((string)file_get_contents(dirname(__DIR__,2).'/resources/workforce/wizards.json'),true,512,JSON_THROW_ON_ERROR)['wizards']??[];$wizardIds=[];foreach($wizards as $w)$wizardIds[(string)$w['id']]=1;
        foreach($m['roles']??[] as $r){foreach($r['workflows']??[] as $id)if(!isset($workflowIds[$id]))throw new RuntimeException('Unknown workflows '.$id);foreach($r['wizards']??[] as $id)if(!isset($wizardIds[$id]))throw new RuntimeException('Unknown wizards '.$id);}
    }
}
