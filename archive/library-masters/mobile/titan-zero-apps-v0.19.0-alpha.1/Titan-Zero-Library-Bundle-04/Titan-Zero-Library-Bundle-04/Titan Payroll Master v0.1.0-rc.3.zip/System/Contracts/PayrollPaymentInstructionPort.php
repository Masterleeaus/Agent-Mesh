<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Contracts;
interface PayrollPaymentInstructionPort{public function available():bool;public function transmit(array $instructions):array;}
