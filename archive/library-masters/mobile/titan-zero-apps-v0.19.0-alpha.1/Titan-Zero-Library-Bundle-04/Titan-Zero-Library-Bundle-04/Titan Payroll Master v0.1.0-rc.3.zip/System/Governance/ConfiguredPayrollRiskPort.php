<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class ConfiguredPayrollRiskPort implements PayrollRiskPort
{
    public const HOST_BINDING='titan.risk.payroll';
    public function __construct(private readonly ?object $provider=null) {}
    public function available(): bool { return $this->resolveProvider()!==null; }
    public function assess(PayrollCommandRequest $request): array
    {
        $provider=$this->resolveProvider();
        if($provider===null)return (new DeferredPayrollRiskPort())->assess($request);
        if(!method_exists($provider,'assessPayrollCommand'))throw new \RuntimeException('Configured Titan Risk payroll adapter is incompatible.');
        $result=$provider->assessPayrollCommand($this->context($request));
        if(is_bool($result))$result=['allowed'=>$result];
        if(!is_array($result)||!array_key_exists('allowed',$result))throw new \RuntimeException('Titan Risk returned an invalid payroll decision.');
        return ['allowed'=>(bool)$result['allowed'],'decision_id'=>isset($result['decision_id'])?(string)$result['decision_id']:null,'reason'=>isset($result['reason'])?(string)$result['reason']:null];
    }
    private function context(PayrollCommandRequest $r):array{return ['capability'=>$r->capability,'company_id'=>$r->companyId,'actor_user_id'=>$r->actorUserId,'actor_type'=>$r->actorType,'source'=>$r->source,'idempotency_key'=>$r->idempotencyKey,'risk'=>(string)($r->definition['risk']??'HIGH'),'input_keys'=>array_values(array_map('strval',array_keys($r->input)))];}
    private function resolveProvider():?object{if($this->provider!==null)return $this->provider;if(function_exists('app')){try{$app=app();if(method_exists($app,'bound')&&$app->bound(self::HOST_BINDING)){$v=$app->make(self::HOST_BINDING);return is_object($v)?$v:null;}}catch(\Throwable){}}return null;}
}
