<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class PayrollCapabilityExecutor
{
    private array $handlers=[];
    public function register(string $capability, callable $handler):void{$this->handlers[$capability]=$handler;}
    public function execute(PayrollCommandRequest $request):array
    {
        $handler=$this->handlers[$request->capability]??null;if(!$handler)throw new \RuntimeException("No local Payroll handler registered for {$request->capability}.");
        $result=$handler($request->input,$request->companyId,$request->actorUserId,$request);
        if(!is_array($result))throw new \RuntimeException('Payroll capability handlers must return arrays.');return $result;
    }
}
