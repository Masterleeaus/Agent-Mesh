<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Health;
final class PayrollHealth
{
    public function liveness():array{return ['status'=>'HEALTHY'];}
    public function readiness(array $deps=[]):array
    {
        $expected=['database','queue','command_bus','risk','assurance','autonomy','time_attendance'];$checks=[];foreach($expected as $name)$checks[$name]=(bool)($deps[$name]??false);$missing=array_keys(array_filter($checks,fn($ok)=>!$ok));
        $status=!$checks['database']?'BLOCKED':($missing!==[]?'DEGRADED':'HEALTHY');$ai=($checks['command_bus']&&$checks['risk']&&$checks['assurance']&&$checks['autonomy'])?'AVAILABLE':'BLOCKED';
        return ['status'=>$status,'ai_writes'=>$ai,'dependencies'=>$missing,'checks'=>$checks,'time_attendance'=>['available'=>$checks['time_attendance'],'hourly_payroll'=>$checks['time_attendance']?'AVAILABLE':'BLOCKED','salaried_payroll'=>'AVAILABLE_IF_POLICY_ALLOWS_NO_TIME_INPUT']];
    }
}
