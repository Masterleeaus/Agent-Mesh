<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Compliance;
final class PayrollRuleSetRegistry
{
    /** @var PayrollRuleSet[] */ private array $sets=[];
    public function __construct(array $sets=[]){foreach($sets as $s)if($s instanceof PayrollRuleSet)$this->sets[]=$s;}
    public function register(PayrollRuleSet $set):void{$this->sets[]=$set;}
    public function resolve(string $jurisdiction,string $effectiveDate):PayrollRuleSet
    { $matches=array_values(array_filter($this->sets,fn(PayrollRuleSet $s)=>strtoupper($s->jurisdiction)===strtoupper($jurisdiction)&&$s->effectiveOn($effectiveDate))); if($matches===[])throw new \RuntimeException("No effective payroll rule set for {$jurisdiction} on {$effectiveDate}."); usort($matches,fn($a,$b)=>strcmp($b->effectiveFrom,$a->effectiveFrom)?:strcmp($b->version,$a->version));return $matches[0]; }
}
