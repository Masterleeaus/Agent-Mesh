<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Services;
use App\Extensions\TitanPayroll\System\Contracts\PayrollEmployeeIdentityPort;
use App\Extensions\TitanPayroll\System\Support\PayrollCompanyContext;
use Illuminate\Support\Facades\DB;
final class PayrollSelfServiceReadService
{
    public function __construct(private readonly PayrollEmployeeIdentityPort $identity) {}
    public function payslipsForActor(object $user,int $limit=12):array
    {
        $tenant=PayrollCompanyContext::id($user);$actorId=(int)(method_exists($user,'getKey')?$user->getKey():($user->id??0));if($actorId<1)throw new \RuntimeException('Authenticated employee identity is required.');$limit=max(1,min($limit,50));$refs=$this->identity->workerRefsForActor($tenant,$actorId);
        $rows=DB::table('ext_titan_payroll_payslips')->where('company_id',$tenant)->whereIn('worker_ref',$refs)->orderByDesc('created_at')->limit($limit)->get();
        return ['company_id'=>$tenant,'items'=>$rows->map(fn($r)=>['id'=>(int)$r->id,'payroll_run_id'=>(int)$r->payroll_run_id,'worker_ref'=>(string)$r->worker_ref,'status'=>(string)$r->status,'gross_pay'=>(float)$r->gross_pay,'net_pay'=>(float)$r->net_pay,'currency'=>$r->currency,'document_available'=>!empty($r->document_ref),'acknowledged_at'=>$r->acknowledged_at??null,'created_at'=>$r->created_at??null])->all()];
    }
}
