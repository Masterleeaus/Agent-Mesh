<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Resilience;
final class PayrollConcurrencyPolicy
{
    public function requiresUniqueReservation(string $operation):bool{return in_array($operation,['prepare','finalize','lock','adjustment','payslip_delivery'],true);}
    public function nextVersion(int $current):int{return $current+1;}
    public function assertExpectedVersion(int $actual,int $expected):void{if($actual!==$expected)throw new \DomainException('Payroll record version conflict.');}
}
