<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Contracts;
interface PayrollAccountingExportPort{public function available():bool;public function export(array $journal):array;}
