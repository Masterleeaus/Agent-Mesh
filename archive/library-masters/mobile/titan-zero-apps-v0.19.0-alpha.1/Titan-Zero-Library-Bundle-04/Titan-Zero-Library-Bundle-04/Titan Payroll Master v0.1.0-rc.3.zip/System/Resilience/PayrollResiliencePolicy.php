<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Resilience;
final class PayrollResiliencePolicy
{
    public function __construct(private readonly int $maxAttempts=3){if($maxAttempts<1)throw new \InvalidArgumentException('maxAttempts must be positive.');}
    public function classify(string $failure):string{return in_array($failure,['timeout','connection','deadlock','rate_limit','temporary_provider'],true)?'retryable':'permanent';}
    public function nextState(string $failure,int $attempt):string{return $this->classify($failure)==='retryable'&&$attempt<$this->maxAttempts?'RETRY_SCHEDULED':'ATTENTION_REQUIRED';}
    public function maxAttempts():int{return $this->maxAttempts;}
    public function queueFailurePolicy():array{return ['dead_letter'=>true,'terminal_state'=>'ATTENTION_REQUIRED','reconcile_required'=>true,'duplicate_side_effects_forbidden'=>true];}
}
