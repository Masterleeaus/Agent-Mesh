<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Compliance;
final class PayrollRuleSet
{
    public function __construct(public readonly string $jurisdiction,public readonly string $version,public readonly string $effectiveFrom,public readonly ?string $effectiveTo,public readonly array $rules){}
    public function effectiveOn(string $date):bool{return $date>=$this->effectiveFrom&&($this->effectiveTo===null||$date<=$this->effectiveTo);}
    public function explain():array{return ['jurisdiction'=>$this->jurisdiction,'rule_version'=>$this->version,'effective_from'=>$this->effectiveFrom,'effective_to'=>$this->effectiveTo,'classification'=>'configured_validation_rule_set','legal_certification'=>false];}
}
