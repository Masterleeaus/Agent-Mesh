<?php
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollToolRegistry { public static function tools(): array { return PayrollWorkforceManifest::load()['tools'] ?? []; } }
