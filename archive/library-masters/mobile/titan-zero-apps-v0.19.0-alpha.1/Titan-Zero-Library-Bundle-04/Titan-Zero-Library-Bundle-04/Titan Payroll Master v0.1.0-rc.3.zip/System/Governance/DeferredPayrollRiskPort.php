<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Governance;
final class DeferredPayrollRiskPort implements PayrollRiskPort
{
    public function available(): bool { return false; }
    public function assess(PayrollCommandRequest $request): array { return ['allowed'=>false,'reason'=>'Titan Risk governance is unavailable.']; }
}
