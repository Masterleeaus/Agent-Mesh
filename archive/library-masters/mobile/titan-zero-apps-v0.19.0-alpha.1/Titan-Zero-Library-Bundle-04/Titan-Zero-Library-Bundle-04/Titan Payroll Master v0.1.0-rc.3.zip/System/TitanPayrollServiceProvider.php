<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System;
use App\Extensions\TitanPayroll\System\Authorization\PayrollHostAuthorization;
use App\Extensions\TitanPayroll\System\Compliance\{PayrollRuleSet,PayrollRuleSetRegistry};
use App\Extensions\TitanPayroll\System\Integrations\Accounting\LocalPayrollAccountingExportAdapter;
use App\Extensions\TitanPayroll\System\Integrations\Payments\LocalPayrollPaymentInstructionPreparationAdapter;
use App\Extensions\TitanPayroll\System\Integrations\Rewind\PayrollRewindIntegration;
use App\Extensions\TitanPayroll\System\Services\{PayrollSignalOutboxService,PayrollReconciliationCoordinator};
use App\Extensions\TitanPayroll\Services\Integrations\PayrollReconciliationService;
use App\Extensions\TitanPayroll\System\Workforce\Decision\PayrollWorkforceDecisionGate;
use App\Extensions\TitanPayroll\System\Workforce\{PayrollWorkforceToolGateway,PayrollWorkforceReadService,PayrollWorkforceWorkflowRouter,PayrollWorkforceWizardRegistry,PayrollWorkforceHostRegistrar};
use App\Extensions\TitanPayroll\System\Signals\PayrollSignalDispatcher;
use App\Extensions\TitanPayroll\System\Console\Commands\DispatchPayrollSignalsCommand;
use App\Extensions\TitanPayroll\Services\Forecasting\PayrollForecastService;
use App\Extensions\TitanPayroll\System\Console\Commands\PayrollHostSyncCommand;
use App\Extensions\TitanPayroll\System\Contracts\{PayrollCommunicationsPort,TimeAttendancePayrollInputPort,PayrollAccountingExportPort,PayrollPaymentInstructionPort,PayrollEmployeeIdentityPort};
use App\Extensions\TitanPayroll\Contracts\Repositories\PayrollWorkerInputRepositoryContract;
use App\Extensions\TitanPayroll\Contracts\Services\{PayrollCalculationServiceContract,PayrollRunGuardServiceContract,PayrollRunServiceContract,PayrollComplianceServiceContract,PayrollTaxServiceContract,PayrollReconciliationServiceContract};
use App\Extensions\TitanPayroll\Services\Core\{PayrollCalculationService,PayrollRunService};
use App\Extensions\TitanPayroll\Services\Domain\{PayrollRunGuardService,PayrollComplianceService,PayrollTaxService};
use App\Extensions\TitanPayroll\System\Repositories\ConfiguredPayrollWorkerInputRepository;
use App\Extensions\TitanPayroll\System\Domain\{PayrollRunFinalizer,PayrollRunLifecycle};
use App\Extensions\TitanPayroll\System\Governance\{DatabasePayrollCommandReceiptStore,ConfiguredPayrollCommandBusPort,PayrollCapabilityExecutor,PayrollCommandBusGateway,PayrollCommandBusPort,PayrollCommandReceiptStorePort,PayrollRiskPort,PayrollAssurancePort,ConfiguredPayrollRiskPort,ConfiguredPayrollAssurancePort};
use App\Extensions\TitanPayroll\System\Integrations\TimeAttendance\ConfiguredTimeAttendancePayrollInputAdapter;
use App\Extensions\TitanPayroll\System\Integrations\Communications\ConfiguredPayrollCommunicationsAdapter;
use App\Extensions\TitanPayroll\System\Navigation\PayrollMenuRegistrar;
use App\Extensions\TitanPayroll\System\Services\{PayrollMutationService,PayrollSelfServiceReadService};
use App\Extensions\TitanPayroll\System\Security\PayrollPayslipAccessPolicy;
use App\Extensions\TitanPayroll\System\Identity\ConfiguredPayrollEmployeeIdentityPort;
use App\Extensions\TitanPayroll\System\Health\{PayrollHealth,PayrollRuntimeHealthProbe};
use App\Extensions\TitanPayroll\Contracts\Services\EmployeePayslipAccessTokenServiceContract;
use App\Extensions\TitanPayroll\Contracts\Services\{CleanerShiftReconciliationServiceContract,CleaningPayrollServiceContract,CleaningPayrollSettingsServiceContract,PayrollVarianceServiceContract};
use App\Extensions\TitanPayroll\Services\Domain\{CleanerShiftReconciliationService,CleaningPayrollService,CleaningPayrollSettingsService};
use App\Extensions\TitanPayroll\Services\Analytics\PayrollVarianceService;
use App\Extensions\TitanPayroll\Services\Security\EmployeePayslipAccessTokenService;
use Illuminate\Support\ServiceProvider;
final class TitanPayrollServiceProvider extends ServiceProvider
{
    public function register():void
    {
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanPayroll\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanPayroll\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

        $this->mergeConfigFrom(__DIR__.'/../config/payroll.php','payroll');
        $this->mergeConfigFrom(__DIR__.'/../config/features.php','payroll.features');
        $this->mergeConfigFrom(__DIR__.'/../config/compliance.php','payroll.compliance');
        $this->mergeConfigFrom(__DIR__.'/../config/tax.php','payroll.tax');
        $this->mergeConfigFrom(__DIR__.'/../config/cleaning.php','payroll.cleaning');
        $this->mergeConfigFrom(__DIR__.'/../config/notifications.php','payroll.notifications');
        $this->mergeConfigFrom(__DIR__.'/../config/rules.php','titan-payroll-rules');$this->app->singleton(PayrollEmployeeIdentityPort::class,ConfiguredPayrollEmployeeIdentityPort::class);$this->app->singleton(PayrollMenuRegistrar::class);$this->app->singleton(PayrollHostAuthorization::class);$this->app->singleton(PayrollPayslipAccessPolicy::class);$this->app->bind(EmployeePayslipAccessTokenServiceContract::class,EmployeePayslipAccessTokenService::class);
        $this->app->singleton(TimeAttendancePayrollInputPort::class,fn()=>new ConfiguredTimeAttendancePayrollInputAdapter());$this->app->singleton(PayrollCommunicationsPort::class,ConfiguredPayrollCommunicationsAdapter::class);$this->app->singleton(PayrollAccountingExportPort::class,LocalPayrollAccountingExportAdapter::class);$this->app->singleton(PayrollPaymentInstructionPort::class,LocalPayrollPaymentInstructionPreparationAdapter::class);$this->app->singleton(PayrollRewindIntegration::class);$this->app->singleton(PayrollSignalOutboxService::class);$this->app->singleton(PayrollReconciliationService::class);$this->app->singleton(PayrollReconciliationCoordinator::class);$this->app->singleton(PayrollWorkforceDecisionGate::class);$this->app->singleton(PayrollWorkforceHostRegistrar::class);$this->app->singleton(PayrollSignalDispatcher::class);
        $this->app->singleton(PayrollWorkerInputRepositoryContract::class,ConfiguredPayrollWorkerInputRepository::class);$this->app->bind(PayrollCalculationServiceContract::class,PayrollCalculationService::class);$this->app->bind(PayrollRunServiceContract::class,PayrollRunService::class);$this->app->bind(PayrollRunGuardServiceContract::class,PayrollRunGuardService::class);$this->app->bind(PayrollComplianceServiceContract::class,PayrollComplianceService::class);$this->app->bind(PayrollTaxServiceContract::class,PayrollTaxService::class);$this->app->bind(PayrollReconciliationServiceContract::class,PayrollReconciliationService::class);
        $this->app->bind(CleanerShiftReconciliationServiceContract::class,CleanerShiftReconciliationService::class);$this->app->bind(CleaningPayrollServiceContract::class,CleaningPayrollService::class);$this->app->bind(CleaningPayrollSettingsServiceContract::class,CleaningPayrollSettingsService::class);$this->app->bind(PayrollVarianceServiceContract::class,PayrollVarianceService::class);
        $this->app->singleton(PayrollCommandBusPort::class,ConfiguredPayrollCommandBusPort::class);$this->app->singleton(PayrollCommandReceiptStorePort::class,DatabasePayrollCommandReceiptStore::class);$this->app->singleton(PayrollRiskPort::class,ConfiguredPayrollRiskPort::class);$this->app->singleton(PayrollAssurancePort::class,ConfiguredPayrollAssurancePort::class);
        $this->app->singleton(PayrollRuleSetRegistry::class,function(){ $sets=[];foreach((array)config('titan-payroll-rules.sets',[]) as $row){if(!is_array($row))continue;$sets[]=new PayrollRuleSet((string)($row['jurisdiction']??''),(string)($row['version']??''),(string)($row['effective_from']??''),isset($row['effective_to'])?(string)$row['effective_to']:null,(array)($row['rules']??[]));}return new PayrollRuleSetRegistry($sets);});$this->app->singleton(PayrollForecastService::class);$this->app->singleton(PayrollWorkforceReadService::class);$this->app->singleton(PayrollWorkforceWorkflowRouter::class);$this->app->singleton(PayrollWorkforceWizardRegistry::class);$this->app->singleton(PayrollRunLifecycle::class);$this->app->singleton(PayrollRunFinalizer::class);$this->app->singleton(PayrollMutationService::class);$this->app->singleton(PayrollSelfServiceReadService::class);$this->app->singleton(PayrollHealth::class);$this->app->singleton(PayrollRuntimeHealthProbe::class);
        $this->app->singleton(PayrollCapabilityExecutor::class,function($app){$executor=new PayrollCapabilityExecutor();$mutations=$app->make(PayrollMutationService::class);foreach(array_keys(\App\Extensions\TitanPayroll\System\Support\PayrollCapabilityCatalog::definitions()) as $capability){if($capability==='payroll.run.read')continue;$executor->register($capability,fn(array $input,int $tenant,int $actor)=>$mutations->handle($capability,$input,$tenant,$actor));}return $executor;});
        $this->app->singleton(PayrollCommandBusGateway::class,fn($app)=>new PayrollCommandBusGateway($app->make(PayrollCommandBusPort::class),$app->make(PayrollCapabilityExecutor::class),$app->make(PayrollCommandReceiptStorePort::class),$app->make(PayrollHostAuthorization::class),(array)config('payroll.governance.local_human_sources',['payroll_web','payroll_api']),(bool)config('payroll.governance.allow_local_human_mutations',true),$app->make(PayrollRiskPort::class),$app->make(PayrollAssurancePort::class)));
        $this->app->singleton(PayrollWorkforceToolGateway::class,function($app){$reads=$app->make(PayrollWorkforceReadService::class);return new PayrollWorkforceToolGateway($app->make(PayrollCommandBusGateway::class),$app->make(PayrollWorkforceDecisionGate::class),['payroll.runs.read'=>fn($ctx,$input)=>$reads->runs($ctx,$input),'payroll.reconciliation.read'=>fn($ctx,$input)=>$reads->reconciliation($ctx,$input),'payroll.compliance.read'=>fn($ctx,$input)=>$reads->compliance($ctx,$input),'payroll.forecast.read'=>fn($ctx,$input)=>$reads->forecast($ctx,$input)]);});
    }
    public function boot(PayrollMenuRegistrar $menus,PayrollWorkforceHostRegistrar $workforce):void
    {
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');$this->loadViewsFrom(__DIR__.'/../resources/views','titan-payroll');$this->loadRoutesFrom(__DIR__.'/../routes/web.php');$this->loadRoutesFrom(__DIR__.'/../routes/api.php');$menus->registerContributions();$workforce->register();if($this->app->runningInConsole())$this->commands([PayrollHostSyncCommand::class,DispatchPayrollSignalsCommand::class]);
    }
}
