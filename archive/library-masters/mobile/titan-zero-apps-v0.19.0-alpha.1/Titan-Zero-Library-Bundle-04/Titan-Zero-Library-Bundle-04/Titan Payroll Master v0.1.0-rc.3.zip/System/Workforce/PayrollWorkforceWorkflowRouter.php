<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollWorkforceWorkflowRouter
{
    private array $workflows=[];
    public function __construct(?string $path=null){$path=$path??dirname(__DIR__,2).'/resources/workforce/workflows.json';$data=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);foreach((array)($data['workflows']??[]) as $w)$this->workflows[(string)$w['id']]=$w;}
    public function workflow(string $id):array{if(!isset($this->workflows[$id]))throw new \InvalidArgumentException("Unknown Payroll Workforce workflow: {$id}");return $this->workflows[$id];}
    public function all():array{return array_values($this->workflows);}
}
