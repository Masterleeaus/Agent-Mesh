<?php
declare(strict_types=1);
namespace App\Extensions\TitanPayroll\System\Services;
use Illuminate\Support\Facades\DB;
final class PayrollSignalOutboxService
{
    public const ALLOWED_SIGNALS=[
        'payroll.run.prepared','payroll.run.submitted','payroll.run.approved','payroll.run.rejected','payroll.run.finalized',
        'payroll.variance.detected','payroll.reconciliation.completed','payroll.payslip.delivery.failed','payroll.period.locked','payroll.period.unlocked',
    ];
    private const DENY=['bank_account','bank_account_number','account_number','routing_number','bsb','tax_id','tax_identifier','tax_file_number','employee_tax_file_number','payslip','payslip_document','document_body','raw_document','secret','token','api_key'];
    public function prepare(int $companyId,string $signal,string $idempotencyKey,array $payload):array
    {
        if($companyId<=0||trim($idempotencyKey)==='')throw new \InvalidArgumentException('Tenant and idempotency key are required for Payroll Signals.');
        if(!in_array($signal,self::ALLOWED_SIGNALS,true))throw new \InvalidArgumentException('Unsupported Payroll Signal family.');
        $safe=$this->sanitize($payload);ksort($safe);
        return ['outbox_key'=>hash('sha256',$companyId.'|'.$signal.'|'.$idempotencyKey),'company_id'=>$companyId,'signal'=>$signal,'schema_version'=>'1.0','idempotency_key'=>$idempotencyKey,'payload'=>$safe,'status'=>'pending','attempts'=>0];
    }
    public function enqueue(int $companyId,string $signal,string $idempotencyKey,array $payload):array
    {
        $record=$this->prepare($companyId,$signal,$idempotencyKey,$payload);$now=now();
        DB::table('ext_titan_payroll_signal_outbox')->updateOrInsert(
            ['outbox_key'=>$record['outbox_key']],
            ['company_id'=>$companyId,'signal'=>$signal,'schema_version'=>'1.0','idempotency_key'=>$idempotencyKey,'payload'=>json_encode($record['payload'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),'status'=>'pending','available_at'=>$now,'updated_at'=>$now,'created_at'=>$now]
        );
        return $record;
    }
    public function sanitize(array $payload):array
    {
        $out=[];foreach($payload as $k=>$v){$n=strtolower((string)$k);$blocked=false;foreach(self::DENY as $deny)if($n===$deny||str_contains($n,$deny)){$blocked=true;break;}if($blocked)continue;$out[$k]=is_array($v)?$this->sanitize($v):$v;}return $out;
    }
    public function retry(array $record,int $maxAttempts=3):array{$attempts=(int)($record['attempts']??0)+1;$record['attempts']=$attempts;$record['status']=$attempts>=$maxAttempts?'attention_required':'pending';return $record;}
}
