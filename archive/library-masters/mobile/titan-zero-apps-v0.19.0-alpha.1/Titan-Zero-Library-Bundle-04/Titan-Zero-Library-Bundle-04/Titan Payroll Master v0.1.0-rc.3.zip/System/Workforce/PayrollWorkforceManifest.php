<?php
namespace App\Extensions\TitanPayroll\System\Workforce;
final class PayrollWorkforceManifest { public static function path(): string { return dirname(__DIR__,2).'/resources/workforce/workforce-manifest.json'; } public static function load(): array { return json_decode((string)file_get_contents(self::path()),true,512,JSON_THROW_ON_ERROR); } }
