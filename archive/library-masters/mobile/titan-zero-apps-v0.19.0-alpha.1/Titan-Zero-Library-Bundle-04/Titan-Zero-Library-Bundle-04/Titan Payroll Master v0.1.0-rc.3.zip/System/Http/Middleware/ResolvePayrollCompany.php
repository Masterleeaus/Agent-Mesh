<?php
namespace App\Extensions\TitanPayroll\System\Http\Middleware;
use App\Extensions\TitanPayroll\System\Support\PayrollCompanyContext; use Closure;
final class ResolvePayrollCompany { public function handle($request, Closure $next){ $user=$request->user(); if(!$user) abort(401); $request->attributes->set('company_id', PayrollCompanyContext::id($user)); return $next($request); } }
