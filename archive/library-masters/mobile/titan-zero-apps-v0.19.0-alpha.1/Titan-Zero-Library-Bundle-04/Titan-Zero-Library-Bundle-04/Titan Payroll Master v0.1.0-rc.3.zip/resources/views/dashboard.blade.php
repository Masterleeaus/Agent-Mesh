<section><h1>Titan Payroll</h1><p>Tenant-scoped payroll operations.</p></section>
