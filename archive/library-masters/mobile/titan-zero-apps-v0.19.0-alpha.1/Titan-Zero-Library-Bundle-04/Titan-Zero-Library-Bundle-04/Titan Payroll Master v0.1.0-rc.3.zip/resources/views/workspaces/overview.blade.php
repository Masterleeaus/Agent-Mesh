@include('titan-payroll::workspaces._shell')
<h2>Operational summary</h2><dl><dt>Recent runs</dt><dd>{{ $runs->count() }}</dd><dt>Payslips</dt><dd>{{ $payslips->count() }}</dd><dt>Unresolved reconciliation</dt><dd>{{ $blockers['unresolved'] }}</dd></dl>
<p>Tenant {{ $tenant }} · calculation provenance is deterministic and tenant-scoped.</p>