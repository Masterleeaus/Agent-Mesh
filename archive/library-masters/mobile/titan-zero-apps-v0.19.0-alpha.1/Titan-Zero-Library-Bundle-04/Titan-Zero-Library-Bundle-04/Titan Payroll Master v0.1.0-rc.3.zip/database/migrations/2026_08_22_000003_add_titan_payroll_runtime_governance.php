<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_titan_payroll_runs', function(Blueprint $t):void {
            $t->date('period_from')->nullable()->after('period_key');
            $t->date('period_to')->nullable()->after('period_from');
            $t->string('config_version',64)->nullable()->after('calculation_version');
            $t->string('source_revision',128)->nullable()->after('config_version');
            $t->unsignedInteger('version')->default(1)->after('status');
            $t->string('finalized_snapshot_hash',64)->nullable()->after('snapshot');
            $t->dateTime('prepared_at',6)->nullable();$t->dateTime('submitted_at',6)->nullable();$t->dateTime('approved_at',6)->nullable();$t->dateTime('finalized_at',6)->nullable();
            $t->index(['company_id','period_from','period_to'],'tpr_tenant_period_idx');$t->unique(['company_id','period_key'],'tpr_tenant_period_key_uq');
        });
        Schema::create('ext_titan_payroll_run_approvals', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('payroll_run_id')->index();$t->string('step',48)->default('finance_review');$t->string('status',24);$t->unsignedBigInteger('actor_user_id')->nullable();$t->text('comment')->nullable();$t->dateTime('acted_at',6)->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','payroll_run_id','step'],'tpa_tenant_run_step_uq');
        });
        Schema::create('ext_titan_payroll_command_receipts', function(Blueprint $t):void {
            $t->id();$t->string('receipt_key',64)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('capability',96);$t->string('idempotency_key',128);$t->string('status',32);$t->longText('result_json')->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','capability','idempotency_key'],'tpc_tenant_cap_idem_uq');
        });
        Schema::create('ext_titan_payroll_period_locks', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->date('period_from');$t->date('period_to');$t->string('status',24)->default('locked');$t->unsignedInteger('version')->default(1);$t->unsignedBigInteger('locked_by')->nullable();$t->dateTime('locked_at',6)->nullable();$t->unsignedBigInteger('unlocked_by')->nullable();$t->dateTime('unlocked_at',6)->nullable();$t->text('unlock_reason')->nullable();$t->json('metadata')->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','period_from','period_to'],'tpl_tenant_period_uq');$t->index(['company_id','period_from','period_to','status'],'tpl_tenant_period_status_idx');
        });
        Schema::create('ext_titan_payroll_adjustments', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('payroll_run_id')->index();$t->string('worker_ref',128);$t->decimal('amount',14,2);$t->string('direction',16);$t->string('reason_code',64);$t->text('reason')->nullable();$t->string('status',24)->default('pending');$t->string('idempotency_key',128);$t->unsignedBigInteger('created_by')->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','idempotency_key'],'tpadj_tenant_idem_uq');
        });
        Schema::create('ext_titan_payroll_payslips', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('payroll_run_id')->index();$t->string('worker_ref',128);$t->string('status',24)->default('finalized');$t->decimal('gross_pay',14,2)->default(0);$t->decimal('net_pay',14,2)->default(0);$t->string('currency',8)->nullable();$t->string('document_ref',191)->nullable();$t->string('document_hash',64)->nullable();$t->unsignedInteger('access_version')->default(1);$t->unsignedBigInteger('acknowledged_by')->nullable();$t->dateTime('acknowledged_at',6)->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','payroll_run_id','worker_ref'],'tpps_tenant_run_worker_uq');
        });
        Schema::create('ext_titan_payroll_employee_preferences', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->string('worker_ref',128);$t->string('preference_key',64);$t->longText('encrypted_value');$t->unsignedInteger('version')->default(1);$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();$t->unique(['company_id','worker_ref','preference_key'],'tpep_tenant_worker_key_uq');
        });
        Schema::table('ext_titan_payroll_delivery_receipts', function(Blueprint $t):void {
            $t->string('idempotency_key',128)->nullable()->after('external_receipt_ref');$t->unique(['company_id','idempotency_key'],'tpdr_tenant_idem_uq');
        });
    }
    public function down(): void
    {
        Schema::table('ext_titan_payroll_delivery_receipts', function(Blueprint $t):void {$t->dropUnique('tpdr_tenant_idem_uq');$t->dropColumn('idempotency_key');});
        Schema::dropIfExists('ext_titan_payroll_employee_preferences');Schema::dropIfExists('ext_titan_payroll_payslips');Schema::dropIfExists('ext_titan_payroll_adjustments');Schema::dropIfExists('ext_titan_payroll_period_locks');Schema::dropIfExists('ext_titan_payroll_command_receipts');Schema::dropIfExists('ext_titan_payroll_run_approvals');
        Schema::table('ext_titan_payroll_runs', function(Blueprint $t):void {$t->dropUnique('tpr_tenant_period_key_uq');$t->dropIndex('tpr_tenant_period_idx');$t->dropColumn(['period_from','period_to','config_version','source_revision','version','finalized_snapshot_hash','prepared_at','submitted_at','approved_at','finalized_at']);});
    }
};
