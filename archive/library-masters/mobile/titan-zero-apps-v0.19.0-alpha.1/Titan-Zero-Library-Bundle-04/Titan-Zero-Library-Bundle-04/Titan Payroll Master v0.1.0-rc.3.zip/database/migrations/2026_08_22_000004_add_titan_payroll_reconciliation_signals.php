<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('ext_titan_payroll_reconciliations', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('payroll_run_id')->index();$t->string('source_revision',128);$t->string('status',32)->default('completed');$t->string('result_hash',64);$t->json('summary');$t->dateTime('completed_at',6);$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();
            $t->unique(['company_id','payroll_run_id','source_revision','result_hash'],'tprec_tenant_run_source_hash_uq');
        });
        Schema::create('ext_titan_payroll_reconciliation_proposals', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('payroll_run_id')->index();$t->unsignedBigInteger('reconciliation_id')->index();$t->string('resolution_type',64);$t->text('reason');$t->string('status',24)->default('proposed');$t->unsignedBigInteger('created_by')->nullable();$t->string('idempotency_key',128);$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();
            $t->unique(['company_id','idempotency_key'],'tprecp_tenant_idem_uq');
        });
        Schema::create('ext_titan_payroll_signal_outbox', function(Blueprint $t):void {
            $t->id();$t->unsignedBigInteger('company_id')->index();$t->string('outbox_key',64)->unique();$t->string('signal',96);$t->string('schema_version',16)->default('1.0');$t->string('idempotency_key',128);$t->json('payload');$t->string('status',32)->default('pending');$t->unsignedInteger('attempts')->default(0);$t->dateTime('available_at',6)->nullable();$t->dateTime('delivered_at',6)->nullable();$t->dateTime('created_at',6)->nullable();$t->dateTime('updated_at',6)->nullable();
            $t->unique(['company_id','signal','idempotency_key'],'tpsig_tenant_signal_idem_uq');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('ext_titan_payroll_signal_outbox');Schema::dropIfExists('ext_titan_payroll_reconciliation_proposals');Schema::dropIfExists('ext_titan_payroll_reconciliations');
    }
};
