<?php

declare(strict_types=1);
namespace App\Extensions\TitanPayroll\Support\DTOs;
use App\Extensions\TitanPayroll\System\Security\PayrollSensitiveValue;
final class PayslipDocument
{
    public readonly int $userId;
    public readonly string $periodFrom;
    public readonly string $periodTo;
    public readonly string $html;
    public readonly array $payload;
    public readonly ?string $storagePath;
    public readonly ?int $salarySlipId;
    public readonly ?float $gross;
    public readonly ?float $net;
    public readonly ?string $currency;
    public readonly ?string $downloadUrl;
    public readonly array $meta;
    public readonly ?int $companyId;

    /**
     * Compatibility constructor for the preserved donor's two historic positional shapes
     * plus Titan's explicit named-argument shape.
     */
    public function __construct(mixed ...$args)
    {
        if(array_is_list($args)){
            if(isset($args[1])&&is_int($args[1])){
                $data=[
                    'salarySlipId'=>$args[0]??null,'userId'=>$args[1]??null,'periodFrom'=>$args[2]??null,'periodTo'=>$args[3]??null,
                    'gross'=>$args[4]??null,'net'=>$args[5]??null,'currency'=>$args[6]??null,'storagePath'=>$args[7]??null,
                    'downloadUrl'=>$args[8]??null,'meta'=>$args[9]??[],'companyId'=>$args[10]??null,'html'=>'','payload'=>[],
                ];
            }else{
                $data=[
                    'userId'=>$args[0]??null,'periodFrom'=>$args[1]??null,'periodTo'=>$args[2]??null,'html'=>$args[3]??'',
                    'payload'=>$args[4]??[],'storagePath'=>$args[5]??null,'salarySlipId'=>$args[6]??null,'gross'=>$args[7]??null,
                    'net'=>$args[8]??null,'currency'=>$args[9]??null,'downloadUrl'=>$args[10]??null,'meta'=>$args[11]??[],
                    'companyId'=>$args[12]??null,
                ];
            }
        }else{
            $data=$args;
            $data['salarySlipId']=$data['salarySlipId']??$data['salary_slip_id']??null;
            $data['companyId']=$data['companyId']??$data['company_id']??null;
        }
        $userId=(int)($data['userId']??0);$from=(string)($data['periodFrom']??'');$to=(string)($data['periodTo']??'');
        if($userId<1||$from===''||$to==='')throw new \InvalidArgumentException('PayslipDocument requires userId, periodFrom and periodTo.');
        $this->userId=$userId;$this->periodFrom=$from;$this->periodTo=$to;$this->html=(string)($data['html']??'');
        $this->payload=is_array($data['payload']??null)?$data['payload']:[];$this->storagePath=isset($data['storagePath'])?(string)$data['storagePath']:null;
        $this->salarySlipId=isset($data['salarySlipId'])?(int)$data['salarySlipId']:null;$this->gross=isset($data['gross'])?(float)$data['gross']:null;
        $this->net=isset($data['net'])?(float)$data['net']:null;$this->currency=isset($data['currency'])?(string)$data['currency']:null;
        $this->downloadUrl=isset($data['downloadUrl'])?(string)$data['downloadUrl']:null;$this->meta=is_array($data['meta']??null)?$data['meta']:[];
        $this->companyId=isset($data['companyId'])?(int)$data['companyId']:null;
    }
    public function toArray():array
    {
        return [
            'company_id'=>$this->companyId,'salary_slip_id'=>$this->salarySlipId,'user_id'=>$this->userId,
            'period_from'=>$this->periodFrom,'period_to'=>$this->periodTo,'gross'=>$this->gross,'net'=>$this->net,'currency'=>$this->currency,
            'document_hash'=>hash('sha256',$this->html),'document_available'=>$this->storagePath!==null||$this->downloadUrl!==null,
            'payload'=>PayrollSensitiveValue::redact($this->payload),'meta'=>PayrollSensitiveValue::redact($this->meta),
        ];
    }
}
