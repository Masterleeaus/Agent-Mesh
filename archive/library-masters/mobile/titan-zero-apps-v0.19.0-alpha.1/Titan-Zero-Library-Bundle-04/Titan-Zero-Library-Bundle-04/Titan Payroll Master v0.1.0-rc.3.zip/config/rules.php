<?php
return [
    // Versioned jurisdiction rules are supplied by reviewed configuration or a host rule provider.
    // Empty by default so a requested versioned rule fails closed instead of inventing statutory facts.
    'sets' => [],
    'classification' => 'configured_validation_rule_set',
    'legal_certification' => false,
];
