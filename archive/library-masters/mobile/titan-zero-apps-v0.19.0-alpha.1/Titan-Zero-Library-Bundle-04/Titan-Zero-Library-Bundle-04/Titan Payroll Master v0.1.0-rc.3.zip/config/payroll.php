<?php
return [
    'version'=>'0.1.0-rc.3',
    'enabled'=>env('TITAN_PAYROLL_ENABLED',true),
    'kill_switch'=>env('TITAN_PAYROLL_KILL_SWITCH',false),
    'rollout'=>env('TITAN_PAYROLL_ROLLOUT','INTERNAL'),
    'governance'=>[
        'allow_local_human_mutations'=>env('TITAN_PAYROLL_LOCAL_HUMAN_MUTATIONS',true),
        'local_human_sources'=>['payroll_web','payroll_api'],
    ],
    'time_attendance'=>['required_for_hourly'=>true],
    'resilience'=>['max_attempts'=>3,'terminal_state'=>'ATTENTION_REQUIRED'],
];
