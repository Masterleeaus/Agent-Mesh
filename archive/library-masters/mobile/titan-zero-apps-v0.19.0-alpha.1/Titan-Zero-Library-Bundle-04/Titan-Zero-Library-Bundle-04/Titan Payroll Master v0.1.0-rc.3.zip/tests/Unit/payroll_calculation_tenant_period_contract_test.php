<?php
declare(strict_types=1);
namespace Carbon { interface CarbonInterface {} }
namespace App\Extensions\TitanPayroll\Contracts\Services { interface PayrollCalculationServiceContract { public function calculate(\App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput $input): \App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationResult; } }
namespace {
$root=dirname(__DIR__,2);
require_once $root.'/Support/DTOs/PayrollCalculationInput.php';
require_once $root.'/Support/DTOs/PayrollCalculationResult.php';
require_once $root.'/Services/Core/PayrollCalculationService.php';
$from=new class implements \Carbon\CarbonInterface { public function toDateString(): string { return '2026-08-01'; } };
$to=new class implements \Carbon\CarbonInterface { public function toDateString(): string { return '2026-08-14'; } };
$input=new \App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput(companyId:42,userId:7,from:$from,to:$to,baseSalary:2000,metadata:['config_version'=>'cfg-2']);
if(!property_exists($input,'companyId')||$input->companyId!==42){fwrite(STDERR,"missing canonical tenant alias\n");exit(1);}
$result=(new \App\Extensions\TitanPayroll\Services\Core\PayrollCalculationService())->calculate($input);
if(($result->companyId??null)!==42){fwrite(STDERR,"missing result tenant\n");exit(1);}
if(($result->periodFrom??null)!=='2026-08-01'||($result->periodTo??null)!=='2026-08-14'){fwrite(STDERR,"missing result period\n");exit(1);}
$a=$result->toArray();
if(($a['company_id']??null)!==42||($a['period_from']??null)!=='2026-08-01'||($a['period_to']??null)!=='2026-08-14'){fwrite(STDERR,"missing serialized canonical context\n");exit(1);}
echo "PASS payroll calculation tenant/period contract\n";
}
