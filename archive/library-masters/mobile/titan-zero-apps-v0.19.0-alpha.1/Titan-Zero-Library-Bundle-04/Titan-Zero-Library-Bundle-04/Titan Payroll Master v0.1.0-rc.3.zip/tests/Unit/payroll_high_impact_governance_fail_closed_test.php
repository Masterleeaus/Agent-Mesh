<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach([
'System/Support/PayrollCompanyContext.php','System/Support/PayrollCapabilityCatalog.php','System/Authorization/PayrollHostAuthorization.php',
'System/Governance/PayrollCommandRequest.php','System/Governance/PayrollCommandBusPort.php','System/Governance/DeferredPayrollCommandBusPort.php',
'System/Governance/PayrollCommandReceiptStorePort.php','System/Governance/InMemoryPayrollCommandReceiptStore.php','System/Governance/PayrollCapabilityExecutor.php',
'System/Governance/PayrollRiskPort.php','System/Governance/PayrollAssurancePort.php','System/Governance/DeferredPayrollRiskPort.php','System/Governance/DeferredPayrollAssurancePort.php','System/Governance/PayrollCommandBusGateway.php'
] as $f)require_once $root.'/'.$f;
use App\Extensions\TitanPayroll\System\Governance\{PayrollCommandBusGateway,DeferredPayrollCommandBusPort,InMemoryPayrollCommandReceiptStore,PayrollCapabilityExecutor};
use App\Extensions\TitanPayroll\System\Authorization\PayrollHostAuthorization;
$actor=new class{public int $id=7;public int $company_id=42;public function can($a){return str_starts_with($a,'payroll.');}};
$exec=new PayrollCapabilityExecutor();$exec->register('payroll.run.prepare',fn()=>['prepared'=>true]);
$gateway=new PayrollCommandBusGateway(new DeferredPayrollCommandBusPort(),$exec,new InMemoryPayrollCommandReceiptStore(),new PayrollHostAuthorization(),['payroll_web'],true);
try{
    $gateway->request('payroll.run.prepare',['idempotency_key'=>'governance-required','run_id'=>9],$actor,'payroll_web','human');
    fwrite(STDERR,"high-impact payroll write executed without Risk + Assurance\n");exit(1);
}catch(RuntimeException $e){
    if(!str_contains(strtolower($e->getMessage()),'governance')){fwrite(STDERR,"unexpected fail-closed reason: {$e->getMessage()}\n");exit(1);}
}
echo "PASS high-impact payroll governance fail-closed\n";
