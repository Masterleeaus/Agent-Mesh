<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Security/PayrollPayslipAccessPolicy.php';
use App\Extensions\TitanPayroll\System\Security\PayrollPayslipAccessPolicy;
$p=new PayrollPayslipAccessPolicy();$record=['id'=>55,'company_id'=>42,'worker_ref'=>'user:7'];$p->assertRecordAccess(42,7,$record);
try{$p->assertRecordAccess(42,8,$record);exit(1);}catch(DomainException){}
try{$p->assertRecordAccess(41,7,$record);exit(1);}catch(DomainException){}
$claims=['jti'=>'x1','employee_id'=>7,'payslip_id'=>'55','company_id'=>42,'expires_at'=>'2026-08-22T10:00:00+10:00'];$p->assertGrant($claims,42,7,55,new DateTimeImmutable('2026-08-22T09:00:00+10:00'));
try{$p->assertGrant($claims,42,7,55,new DateTimeImmutable('2026-08-22T11:00:00+10:00'));exit(1);}catch(DomainException){}
echo "PASS payroll payslip access policy\n";
