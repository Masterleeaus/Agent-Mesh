<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
$errors=[];
foreach(glob($root.'/database/migrations/*.php')?:[] as $file){
    $src=(string)file_get_contents($file);$rel=basename($file);
    if(str_contains($src,'->timestamps()'))$errors[]="{$rel}: timestamps() is not microsecond-explicit";
    if(preg_match('/->timestamp\s*\(/',$src))$errors[]="{$rel}: timestamp() is not allowed for new RC timestamps";
    if(preg_match_all('/Schema::create\(\'([^\']+)\'\s*,\s*function\(Blueprint \$t\)(?::void)?\s*\{(.*?)\}\);/s',$src,$m,PREG_SET_ORDER)){
        foreach($m as $create){
            [$all,$table,$body]=$create;
            if(!str_starts_with($table,'ext_titan_payroll_'))$errors[]="{$rel}: creates non-Payroll table {$table}";
            if(!str_contains($body,"'company_id'")||!preg_match("/company_id'\\)->index\\(\\)/",$body))$errors[]="{$rel}: {$table} lacks indexed company_id";
        }
    }
    if(preg_match_all("/Schema::table\\('([^']+)'/",$src,$m))foreach($m[1] as $table)if(!str_starts_with($table,'ext_titan_payroll_'))$errors[]="{$rel}: mutates host table {$table}";
}
if($errors){fwrite(STDERR,"FAIL payroll_pass4_migration_precision_and_tenancy_test\n - ".implode("\n - ",$errors)."\n");exit(1);}echo "PASS payroll_pass4_migration_precision_and_tenancy_test\n";
