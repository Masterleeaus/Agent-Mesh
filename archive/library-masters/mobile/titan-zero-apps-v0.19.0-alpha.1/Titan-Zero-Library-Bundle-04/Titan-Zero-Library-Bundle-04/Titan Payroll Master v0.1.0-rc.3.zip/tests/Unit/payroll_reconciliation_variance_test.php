<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/Contracts/Services/PayrollReconciliationServiceContract.php';
require_once $root.'/System/Domain/PayrollReconciliationRecord.php';
require_once $root.'/Services/Integrations/PayrollReconciliationService.php';
$svc=new \App\Extensions\TitanPayroll\Services\Integrations\PayrollReconciliationService();
$expected=[['employee_id'=>'e1','amount'=>100],['employee_id'=>'e2','amount'=>50],['employee_id'=>'e3','amount'=>75]];
$actual=[['employee_id'=>'e1','amount'=>100],['employee_id'=>'e2','amount'=>55],['employee_id'=>'e2','amount'=>55],['employee_id'=>'e4','amount'=>20]];
$a=$svc->reconcileBound(7,42,'ta-rev-9',$expected,$actual);$b=$svc->reconcileBound(7,42,'ta-rev-9',$expected,$actual);
if($a!==$b) exit(1);
if(($a['company_id']??0)!==7||($a['payroll_run_id']??0)!==42||($a['source_revision']??'')!=='ta-rev-9') exit(2);
if(count($a['missing']??[])!==1||count($a['mismatched']??[])!==1||count($a['duplicate']??[])!==1||count($a['unresolved']??[])!==1) exit(3);
foreach($a['resolution_proposals']??[] as $p){ if(($p['status']??'')!=='proposed'||($p['auto_correct']??true)!==false) exit(4); }
$coord=$root.'/System/Services/PayrollReconciliationCoordinator.php';if(!is_file($coord))exit(5);$src=file_get_contents($coord);foreach(['ext_titan_payroll_reconciliations','payroll.reconciliation.completed','payroll.variance.detected','PayrollSignalOutboxService'] as $n)if(!str_contains($src,$n))exit(6);echo "PASS payroll reconciliation variance\n";
