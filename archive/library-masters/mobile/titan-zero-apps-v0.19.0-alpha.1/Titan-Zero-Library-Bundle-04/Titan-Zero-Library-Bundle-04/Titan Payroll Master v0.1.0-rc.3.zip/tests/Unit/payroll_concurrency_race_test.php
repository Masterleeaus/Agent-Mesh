<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Resilience/PayrollIdempotencyKey.php';require_once $root.'/System/Resilience/PayrollConcurrencyPolicy.php';
use App\Extensions\TitanPayroll\System\Resilience\{PayrollIdempotencyKey,PayrollConcurrencyPolicy};
$k1=PayrollIdempotencyKey::forRun(42,'2026-08-A','prepare','client-1');$k2=PayrollIdempotencyKey::forRun(42,'2026-08-A','prepare','client-1');if($k1!==$k2||strlen($k1)!==64)exit(1);
$p=new PayrollConcurrencyPolicy();if(!$p->requiresUniqueReservation('prepare')||!$p->requiresUniqueReservation('finalize')||!$p->requiresUniqueReservation('lock'))exit(1);
if($p->nextVersion(4)!==5)exit(1);try{$p->assertExpectedVersion(5,4);exit(1);}catch(DomainException){}
echo "PASS payroll concurrency race policy\n";
