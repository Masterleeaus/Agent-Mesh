<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/Security/PayrollSensitiveValue.php';
require_once $root.'/Support/DTOs/PayslipDocument.php';
use App\Extensions\TitanPayroll\Support\DTOs\PayslipDocument;
$legacy=new PayslipDocument(10,'2026-05-01','2026-05-31','<h1>Payslip</h1>',['net_pay'=>1000]);
if($legacy->userId!==10||$legacy->periodFrom!=='2026-05-01'||$legacy->net!==null)exit(1);
$expanded=new PayslipDocument(1,10,'2026-05-01','2026-05-31',1000,900,'AUD','payslips/1.pdf','https://example.test/payslip.pdf');
if($expanded->salarySlipId!==1||$expanded->userId!==10||$expanded->gross!==1000.0||$expanded->net!==900.0||$expanded->downloadUrl!=='https://example.test/payslip.pdf'){fwrite(STDERR,"expanded donor constructor mapping failed\n");exit(1);}
$named=new PayslipDocument(salarySlipId:55,userId:7,periodFrom:'2026-08-01',periodTo:'2026-08-14',gross:1200,net:1000,currency:'AUD',storagePath:'secure/55.pdf',companyId:42);
if($named->salarySlipId!==55||$named->companyId!==42||$named->userId!==7){fwrite(STDERR,"named constructor mapping failed\n");exit(1);}
echo "PASS payroll payslip constructor compatibility\n";
