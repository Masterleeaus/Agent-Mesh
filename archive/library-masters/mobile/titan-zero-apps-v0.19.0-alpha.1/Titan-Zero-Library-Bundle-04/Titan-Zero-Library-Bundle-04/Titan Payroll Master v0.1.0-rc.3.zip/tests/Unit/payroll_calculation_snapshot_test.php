<?php
declare(strict_types=1);
require_once dirname(__DIR__,2).'/System/Domain/PayrollCalculationSnapshot.php';
use App\Extensions\TitanPayroll\System\Domain\PayrollCalculationSnapshot;
$s = PayrollCalculationSnapshot::fromCalculation(
    companyId: 42,
    workerRef: 'worker:7',
    periodFrom: '2026-08-01',
    periodTo: '2026-08-14',
    calculationVersion: 'calc-v1',
    configVersion: 'cfg-abc',
    sourceRevision: 'time-rev-9',
    result: ['gross_pay'=>1200.125,'net_pay'=>1000.2,'lines'=>[['code'=>'BASE','amount'=>1200.125]]]
);
$a=$s->toArray();
if($a['company_id']!==42||$a['worker_ref']!=='worker:7')exit(1);
if($a['gross_pay']!==1200.13||$a['net_pay']!==1000.2)exit(1);
if($a['calculation_version']!=='calc-v1'||$a['config_version']!=='cfg-abc'||$a['source_revision']!=='time-rev-9')exit(1);
if(strlen($a['snapshot_hash'])!==64)exit(1);
if($a['snapshot_hash']!==PayrollCalculationSnapshot::fromArray($a)->toArray()['snapshot_hash'])exit(1);
echo "PASS payroll calculation snapshot\n";
