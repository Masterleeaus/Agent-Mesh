<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$mutation = file_get_contents($root.'/System/Services/PayrollMutationService.php');
$workforce = file_get_contents($root.'/System/Workforce/PayrollWorkforceReadService.php');
$selfService = file_get_contents($root.'/System/Services/PayrollSelfServiceReadService.php');
$rewind = file_get_contents($root.'/System/Integrations/Rewind/PayrollRewindIntegration.php');

$fail = [];
if (!str_contains($mutation, "->chunkById(500")) {
    $fail[] = 'finalized run-item materialization must be bounded with chunkById(500)';
}
if (!preg_match('/->limit\([^;]+\)->get\(\)/s', $workforce)) {
    $fail[] = 'Workforce read paths must bound collections before get()';
}
if (!preg_match('/->limit\([^;]+\)->get\(\)/s', $selfService)) {
    $fail[] = 'employee self-service reads must bound collections before get()';
}
if (!preg_match('/->limit\(500\)\s*->get\(/s', $rewind)) {
    $fail[] = 'Rewind facts source must enforce its 500-row page bound';
}

if ($fail !== []) {
    fwrite(STDERR, "FAIL payroll_pass4_bounded_runtime_query_contract_test\n - ".implode("\n - ", $fail)."\n");
    exit(1);
}

echo "PASS payroll_pass4_bounded_runtime_query_contract_test\n";
