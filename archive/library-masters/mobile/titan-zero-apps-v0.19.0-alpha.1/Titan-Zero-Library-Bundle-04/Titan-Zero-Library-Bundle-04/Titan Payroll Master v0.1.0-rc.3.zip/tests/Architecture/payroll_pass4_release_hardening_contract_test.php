<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$requiredDocs = [
    'docs/README.md',
    'docs/architecture/ARCHITECTURE.md',
    'docs/architecture/DATA-OWNERSHIP.md',
    'docs/architecture/TIME-ATTENDANCE-BOUNDARY.md',
    'docs/security/SECURITY-TENANCY-PRIVACY.md',
    'docs/workforce/AI-WORKFORCE.md',
    'docs/integrations/PLATFORM-INTEGRATIONS.md',
    'docs/installer/TITAN-INSTALLER-1.7.8.md',
    'docs/installer/UPGRADE-ROLLBACK-UNINSTALL.md',
    'docs/operations/PAYROLL-RUNBOOK.md',
    'docs/operations/PAYSLIP-DELIVERY.md',
    'docs/operations/RECONCILIATION.md',
    'docs/releases/PASS1-BUILD-REPORT.md',
    'docs/releases/PASS2-BUILD-REPORT.md',
    'docs/releases/PASS3-BUILD-REPORT.md',
    'docs/releases/PASS4-RC-REPORT.md',
    'docs/audits/PASS4-DRIFT-DEAD-CODE-AUDIT.md',
    'docs/audits/PASS4-SECURITY-AUDIT.md',
    'System/Installer/PackageIntegrityVerifier.php',
    'bin/verify-release.php',
];
foreach ($requiredDocs as $path) {
    if (!is_file($root.'/'.$path)) {
        $errors[] = "missing {$path}";
    }
}

$version = trim((string) @file_get_contents($root.'/version.txt'));
if ($version !== '0.1.0-rc.3') {
    $errors[] = "version must be 0.1.0-rc.3, got {$version}";
}

$forbiddenDirs = ['Filament', 'GraphQL', 'Providers'];
foreach ($forbiddenDirs as $dir) {
    if (is_dir($root.'/'.$dir)) {
        $errors[] = "dormant runtime scaffold retained: {$dir}";
    }
}

$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $file) {
    if (!$file->isFile()) {
        continue;
    }
    $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    if (basename($rel) === '.gitkeep' || str_ends_with($rel, '.tmp')) {
        $errors[] = "junk scaffold retained: {$rel}";
    }
    if (!str_ends_with($rel, '.php')) {
        continue;
    }
    if (str_starts_with($rel, 'docs/reference/') || str_starts_with($rel, 'tests/')) {
        continue;
    }
    $source = (string) file_get_contents($file->getPathname());
    foreach (['module_path(', 'envato_item_id', 'parent_envato_id', 'Modules\\Payroll'] as $needle) {
        if (str_contains($source, $needle)) {
            $errors[] = "legacy donor coupling {$needle} in {$rel}";
        }
    }
}

foreach (['PASS-01-REPORT.md','PASS-02-REPORT.md','PASS-03-REPORT.md','SCAFFOLD_REPORT.md','PAYROLL_FIX_PASS44.md','PAYROLL_FIX_PASS45.md','PAYROLL_DEEP_FIX_PASS46.md','PAYROLL_SQLITE_FIX_PASS47.md','PAYROLL_DEEP_FIX_PASS48.md'] as $loose) {
    if (is_file($root.'/'.$loose)) {
        $errors[] = "loose root report retained: {$loose}";
    }
}

$manifest = json_decode((string) @file_get_contents($root.'/extension.json'), true);
if (!is_array($manifest)) {
    $errors[] = 'extension.json invalid';
} else {
    $allowed = ['schema','slug','folder','provider','version','integrity'];
    if (array_diff(array_keys($manifest), $allowed) || array_diff($allowed, array_keys($manifest))) {
        $errors[] = 'extension.json keys are not strict Step-10 shape';
    }
    if (($manifest['provider'] ?? null) !== 'App\\Extensions\\TitanPayroll\\System\\TitanPayrollServiceProvider') {
        $errors[] = 'provider mismatch';
    }
}

if ($errors) {
    fwrite(STDERR, implode("\n", $errors)."\n");
    exit(1);
}

echo "PASS payroll pass4 release hardening contract\n";
