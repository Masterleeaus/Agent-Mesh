<?php
declare(strict_types=1);$root=dirname(__DIR__,2);
require_once $root.'/System/Compliance/PayrollRuleSet.php';require_once $root.'/System/Compliance/PayrollRuleSetRegistry.php';
use App\Extensions\TitanPayroll\System\Compliance\{PayrollRuleSet,PayrollRuleSetRegistry};
$r=new PayrollRuleSetRegistry([new PayrollRuleSet('AU','2026.1','2026-07-01','2027-06-30',['bands'=>[['from'=>0,'to'=>null,'rate'=>0.2,'base'=>0,'label'=>'configured-test']]])]);
$s=$r->resolve('AU','2026-08-22');if($s->version!=='2026.1'||$s->jurisdiction!=='AU')exit(1);
$failed=false;try{$r->resolve('ZZ','2026-08-22');}catch(RuntimeException $e){$failed=str_contains($e->getMessage(),'No effective payroll rule set');}if(!$failed)exit(2);
if(($s->explain()['classification']??'')!=='configured_validation_rule_set'||($s->explain()['legal_certification']??true)!==false)exit(3);
echo "PASS payroll rule version\n";
