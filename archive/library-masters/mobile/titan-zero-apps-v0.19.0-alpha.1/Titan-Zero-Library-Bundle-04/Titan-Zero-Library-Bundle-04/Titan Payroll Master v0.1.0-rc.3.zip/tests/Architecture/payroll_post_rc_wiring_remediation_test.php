<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=[];
$wm=json_decode((string)file_get_contents($root.'/resources/workforce/workforce-manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(($wm['extension']['version']??'')!=='0.1.0-rc.3')$fail[]='workforce_version';
$provider=(string)file_get_contents($root.'/System/TitanPayrollServiceProvider.php');
foreach(['PayrollWorkforceHostRegistrar','PayrollSignalDispatcher'] as $n)if(!str_contains($provider,$n))$fail[]='provider_'.$n;
if(!is_file($root.'/System/Workforce/PayrollWorkforceHostRegistrar.php'))$fail[]='workforce_host_registrar';
if(!is_file($root.'/System/Signals/PayrollSignalDispatcher.php'))$fail[]='signal_dispatcher';
if(is_file($root.'/System/Integrations/Rewind/PayrollRewindSourceAdapter.php'))$fail[]='dead_rewind_adapter';
if(is_file($root.'/System/Support/PayrollScope.php'))$fail[]='dead_payroll_scope';
if(is_file($root.'/System/Models/PayrollSignalOutbox.php'))$fail[]='dead_signal_model';
foreach(['overview','runs','time-inputs','payslips','approvals','reconciliation','reports','settings'] as $view){$src=(string)file_get_contents($root.'/resources/views/workspaces/'.$view.'.blade.php');if(trim($src)==="@include('titan-payroll::workspaces._shell')")$fail[]='placeholder_'.$view;}
$validator=(string)file_get_contents($root.'/System/Workforce/PayrollWorkforceManifestValidator.php');
foreach(['extensionVersion','workflows','wizards','capabilities'] as $n)if(!str_contains($validator,$n))$fail[]='validator_'.$n;
if($fail){fwrite(STDERR,'FAIL '.implode(',',$fail).PHP_EOL);exit(1);}echo "PASS post-RC wiring remediation\n";
