<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Security/PayrollSensitiveValue.php';require_once $root.'/Support/DTOs/PayslipDocument.php';require_once $root.'/Support/DTOs/PayslipDeliveryResult.php';
use App\Extensions\TitanPayroll\Support\DTOs\{PayslipDocument,PayslipDeliveryResult};
$d=new PayslipDocument(salarySlipId:55,userId:7,periodFrom:'2026-08-01',periodTo:'2026-08-14',gross:1200,net:1000,currency:'AUD',storagePath:'secure/55.pdf',downloadUrl:null,meta:['tax_identifier'=>'999','safe'=>'ok'],html:'<h1>private payslip</h1>',payload:['bank_account'=>'1234','net_pay'=>1000],companyId:42);
$a=$d->toArray();$j=json_encode($a);foreach(['private payslip','1234','999'] as $secret)if(str_contains($j,$secret))exit(1);if(($a['company_id']??0)!==42||($a['salary_slip_id']??0)!==55||($a['gross']??0)!==1200.0||($a['net']??0)!==1000.0||strlen((string)($a['document_hash']??''))!==64)exit(1);
$r=new PayslipDeliveryResult(userId:7,status:'failed',message:'x',metadata:['receipt'=>'r1']);if($r->error!=='x'||$r->meta['receipt']!=='r1')exit(1);
echo "PASS payroll payslip DTO privacy\n";
