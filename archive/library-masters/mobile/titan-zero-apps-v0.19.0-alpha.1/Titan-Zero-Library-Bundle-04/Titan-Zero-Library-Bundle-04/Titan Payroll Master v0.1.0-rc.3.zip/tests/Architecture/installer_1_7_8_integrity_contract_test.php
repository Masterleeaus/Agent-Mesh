<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$classFile = $root.'/System/Installer/PackageIntegrityVerifier.php';
if (!is_file($classFile)) {
    $errors[] = 'missing PackageIntegrityVerifier';
}
$bin = $root.'/bin/verify-release.php';
if (!is_file($bin)) {
    $errors[] = 'missing bin/verify-release.php';
}
foreach (['PACKAGE-FILES.sha256','SBOM.cdx.json','BUILD-PROVENANCE.json'] as $artifact) {
    if (!is_file($root.'/'.$artifact)) {
        $errors[] = "missing {$artifact}";
    }
}
$manifest = json_decode((string)file_get_contents($root.'/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$allowed = ['schema','slug','folder','provider','version','integrity'];
if (array_diff(array_keys($manifest), $allowed) || array_diff($allowed, array_keys($manifest))) {
    $errors[] = 'root installer manifest has non-Step10 keys';
}
if (($manifest['folder'] ?? null) !== 'TitanPayroll') {
    $errors[] = 'folder mismatch';
}
if (($manifest['provider'] ?? null) !== 'App\\Extensions\\TitanPayroll\\System\\TitanPayrollServiceProvider') {
    $errors[] = 'provider mismatch';
}
foreach (($manifest['integrity']['files'] ?? []) as $path => $hash) {
    if ($path === 'extension.json' || !preg_match('/^[a-f0-9]{64}$/', (string)$hash)) {
        $errors[] = "invalid integrity entry {$path}";
        break;
    }
}
if ($errors) {
    fwrite(STDERR, implode("\n", $errors)."\n");
    exit(1);
}
require_once $classFile;
$verifier = new App\Extensions\TitanPayroll\System\Installer\PackageIntegrityVerifier();
$result = $verifier->verifyDirectory($root);
if (($result['ok'] ?? false) !== true || ($result['verified_files'] ?? 0) < 1) {
    fwrite(STDERR, 'directory integrity verification failed: '.json_encode($result)."\n");
    exit(1);
}
echo "PASS installer 1.7.8 integrity contract\n";
