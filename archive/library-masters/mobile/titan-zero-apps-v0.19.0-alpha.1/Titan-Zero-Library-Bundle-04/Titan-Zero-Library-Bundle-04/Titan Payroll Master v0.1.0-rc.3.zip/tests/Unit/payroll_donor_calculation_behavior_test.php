<?php
declare(strict_types=1);
namespace Carbon { interface CarbonInterface {} }
namespace App\Extensions\TitanPayroll\Contracts\Services { interface PayrollCalculationServiceContract { public function calculate(\App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput $input): \App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationResult; } }
namespace { $root=dirname(__DIR__,2);require_once $root.'/Support/DTOs/PayrollCalculationInput.php';require_once $root.'/Support/DTOs/PayrollCalculationResult.php';require_once $root.'/Services/Core/PayrollCalculationService.php';
$from=new class implements \Carbon\CarbonInterface{};$to=new class implements \Carbon\CarbonInterface{};
$input=new \App\Extensions\TitanPayroll\Support\DTOs\PayrollCalculationInput(companyId:42,userId:7,from:$from,to:$to,hourlyRate:30,regularHours:38,overtimeHours:2,earnings:[['amount'=>50]],deductions:[['amount'=>100]],taxes:[['amount'=>200]],reimbursements:[['amount'=>25]],metadata:['config_version'=>'cfg1']);
$svc=new \App\Extensions\TitanPayroll\Services\Core\PayrollCalculationService();$a=$svc->calculate($input)->toArray();$b=$svc->calculate($input)->toArray();
if($a!==$b)exit(1);if($a['gross_pay']!==1280.0||$a['net_pay']!==1005.0)exit(1);if(($a['lines'][0]['code']??'')!=='BASE'||($a['lines'][1]['code']??'')!=='OT')exit(1);if(($a['metadata']['config_version']??'')!=='cfg1')exit(1);echo "PASS donor payroll calculation behavior\n"; }
