<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach(['System/Governance/PayrollCommandRequest.php','System/Governance/PayrollCommandBusPort.php','System/Governance/DeferredPayrollCommandBusPort.php','System/Governance/ConfiguredPayrollCommandBusPort.php'] as $f)require_once $root.'/'.$f;
use App\Extensions\TitanPayroll\System\Governance\{ConfiguredPayrollCommandBusPort,PayrollCommandRequest};
$seen=[];$provider=new class($seen){public array $seen=[];public function __construct(&$seen){$this->seen=&$seen;}public function dispatchPayrollCommand(array $e):array{$this->seen=$e;return ['status'=>'executed','executed'=>true,'receipt_id'=>'host-1'];}};
$port=new ConfiguredPayrollCommandBusPort($provider);if(!$port->available())exit(1);
$r=new PayrollCommandRequest('payroll.run.prepare',['run_id'=>9],42,7,'workforce','ai','idem-1',['risk'=>'HIGH']);$out=$port->dispatch($r);
if(($out['status']??'')!=='executed'||($provider->seen['company_id']??0)!==42||isset($provider->seen['company_id']))exit(1);
echo "PASS configured payroll command bus port\n";
