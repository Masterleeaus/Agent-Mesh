<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$provider=(string)file_get_contents($root.'/System/TitanPayrollServiceProvider.php');
$expected=[
    "config/payroll.php','payroll'",
    "config/features.php','payroll.features'",
    "config/compliance.php','payroll.compliance'",
    "config/tax.php','payroll.tax'",
    "config/cleaning.php','payroll.cleaning'",
    "config/notifications.php','payroll.notifications'",
    "config/rules.php','titan-payroll-rules'",
];
foreach($expected as $needle){if(!str_contains($provider,$needle)){fwrite(STDERR,"missing config merge {$needle}\n");exit(1);}}
echo "PASS payroll config wiring\n";
