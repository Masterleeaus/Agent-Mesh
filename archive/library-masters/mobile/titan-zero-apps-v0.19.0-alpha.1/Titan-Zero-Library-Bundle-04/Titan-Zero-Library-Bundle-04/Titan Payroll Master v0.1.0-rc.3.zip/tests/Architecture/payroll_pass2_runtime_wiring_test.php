<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$required=[
'database/migrations/2026_08_22_000003_add_titan_payroll_runtime_governance.php',
'System/Services/PayrollMutationService.php',
'System/Governance/DatabasePayrollCommandReceiptStore.php',
'System/Contracts/TimeAttendancePayrollInputPort.php',
'routes/api.php',
];
foreach($required as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"missing {$f}\n");exit(1);}}
$m=file_get_contents($root.'/'.$required[0]);foreach(['ext_titan_payroll_command_receipts','ext_titan_payroll_period_locks','ext_titan_payroll_adjustments','ext_titan_payroll_employee_preferences','company_id','idempotency_key','version','finalized_snapshot_hash'] as $n)if(!str_contains($m,$n)){fwrite(STDERR,"migration missing {$n}\n");exit(1);}
$p=file_get_contents($root.'/System/TitanPayrollServiceProvider.php');foreach(['routes/api.php','PayrollCommandBusGateway','TimeAttendancePayrollInputPort','PayrollMutationService','DatabasePayrollCommandReceiptStore','PayrollRiskPort','PayrollAssurancePort','ConfiguredPayrollRiskPort','ConfiguredPayrollAssurancePort','ConfiguredPayrollCommandBusPort','PayrollRuntimeHealthProbe'] as $n)if(!str_contains($p,$n)){fwrite(STDERR,"provider missing {$n}\n");exit(1);}
$s=file_get_contents($root.'/System/Services/PayrollMutationService.php');foreach(['lockForUpdate','company_id','PayrollRunFinalizer','approvedInputs','ext_titan_payroll_adjustments','pending_communications','PayrollSensitiveValue::encrypt'] as $n)if(!str_contains($s,$n)){fwrite(STDERR,"mutation runtime missing {$n}\n");exit(1);}
if(preg_match('/(?:company_id|company_id)\s*=>\s*\$input/i',$s))exit(1);

$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);$manifestText=json_encode($manifest);if(str_contains($manifestText,'example-workforce-domain')){fwrite(STDERR,"placeholder route remains in manifest\n");exit(1);}if(($manifest['routes'][0]['prefix']??'')!=='dashboard/user/titan-payroll'){fwrite(STDERR,"manifest user route mismatch\n");exit(1);}foreach(['database','queue','command_bus','risk','assurance','autonomy','time_attendance'] as $dep)if(!in_array($dep,$manifest['health']['dependency_checks']??[],true)){fwrite(STDERR,"health dependency missing {$dep}\n");exit(1);}
echo "PASS payroll pass2 runtime wiring\n";
