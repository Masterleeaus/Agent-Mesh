<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Domain/PayrollRunLifecycle.php';require_once $root.'/System/Domain/PayrollRunFinalizer.php';
use App\Extensions\TitanPayroll\System\Domain\{PayrollRunLifecycle,PayrollRunFinalizer};
$l=new PayrollRunLifecycle();$state='draft';foreach(['prepared','pending_approval','approved','finalized'] as $next){$state=$l->transition($state,$next);}if($state!=='finalized')exit(1);
try{$l->transition('finalized','approved');exit(1);}catch(DomainException){}
try{$l->transition('rejected','finalized');exit(1);}catch(DomainException){}
$f=new PayrollRunFinalizer($l);$run=['id'=>9,'company_id'=>42,'status'=>'approved','period_key'=>'2026-08-A'];$snapshot=['calculation_version'=>'calc1','config_version'=>'cfg1','source_revision'=>'time1','gross_pay'=>100,'net_pay'=>90];$done=$f->finalize($run,$snapshot,42);
if($done['status']!=='finalized'||empty($done['finalized_snapshot_hash'])||$done['finalized_snapshot']['config_version']!=='cfg1')exit(1);
try{$f->finalize($done,$snapshot,42);exit(1);}catch(DomainException){}
try{$f->finalize($run,$snapshot,41);exit(1);}catch(DomainException){}
if(!$l->correctionRequiresAdjustment('finalized'))exit(1);
echo "PASS payroll run lifecycle\n";
