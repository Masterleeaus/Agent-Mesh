<?php
declare(strict_types=1);
require_once dirname(__DIR__,2).'/System/Contracts/PayrollEmployeeIdentityPort.php';
require_once dirname(__DIR__,2).'/System/Security/PayrollPayslipAccessPolicy.php';
use App\Extensions\TitanPayroll\System\Contracts\PayrollEmployeeIdentityPort;
use App\Extensions\TitanPayroll\System\Security\PayrollPayslipAccessPolicy;
$identity=new class implements PayrollEmployeeIdentityPort {
    public function workerRefsForActor(int $companyId,int $actorUserId):array{return ['user:'.$actorUserId,'worker:9001'];}
};
$policy=new PayrollPayslipAccessPolicy($identity);
$policy->assertRecordAccess(7,42,['company_id'=>7,'worker_ref'=>'user:42']);
$policy->assertRecordAccess(7,42,['company_id'=>7,'worker_ref'=>'worker:9001']);
foreach ([['company_id'=>7,'worker_ref'=>'worker:42'],['company_id'=>8,'worker_ref'=>'user:42']] as $record) {
    try {$policy->assertRecordAccess(7,42,$record);fwrite(STDERR,"unexpected payslip authorization\n");exit(1);} catch (DomainException) {}
}
echo "Agent2 Pass12 payslip identity policy PASS\n";
