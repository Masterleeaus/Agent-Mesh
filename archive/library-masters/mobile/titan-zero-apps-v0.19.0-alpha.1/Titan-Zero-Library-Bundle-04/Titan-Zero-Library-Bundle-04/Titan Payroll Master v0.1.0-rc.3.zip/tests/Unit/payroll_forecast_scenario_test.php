<?php
declare(strict_types=1);$root=dirname(__DIR__,2);require_once $root.'/System/Forecasting/PayrollScenario.php';require_once $root.'/Services/Forecasting/PayrollForecastService.php';
use App\Extensions\TitanPayroll\Services\Forecasting\PayrollForecastService;
$svc=new PayrollForecastService();$a=$svc->scenario(7,10000,0.01,3,['basis'=>'finalized_run','currency'=>'AUD']);$b=$svc->scenario(7,10000,0.01,3,['currency'=>'AUD','basis'=>'finalized_run']);if($a!==$b)exit(1);if(count($a['projection'])!==3||($a['assumptions']['growth_rate']??null)!==0.01||($a['promise']??true)!==false)exit(2);$failed=false;try{$svc->scenario(7,10000,0.01,61,[]);}catch(InvalidArgumentException){$failed=true;}if(!$failed)exit(3);echo "PASS payroll forecast scenario\n";
