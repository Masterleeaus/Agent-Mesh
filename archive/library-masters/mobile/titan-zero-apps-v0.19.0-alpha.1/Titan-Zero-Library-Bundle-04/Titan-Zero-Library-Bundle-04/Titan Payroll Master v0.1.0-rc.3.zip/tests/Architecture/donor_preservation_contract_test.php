<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$inv=$root.'/docs/architecture/DONOR-INVENTORY.json';$map=$root.'/docs/architecture/DONOR-CONVERSION-MAP.md';
if(!is_file($inv)||!is_file($map))exit(1);$data=json_decode((string)file_get_contents($inv),true,512,JSON_THROW_ON_ERROR);if(count($data)<700)exit(1);$tops=[];foreach(array_keys($data) as $p){$tops[explode('/',$p,2)[0]]=1;}$text=(string)file_get_contents($map);foreach(array_keys($tops) as $t){if(!str_contains($text,'`'.$t.'`')){fwrite(STDERR,"Missing disposition {$t}\n");exit(1);}}echo "PASS donor preservation contract\n";
