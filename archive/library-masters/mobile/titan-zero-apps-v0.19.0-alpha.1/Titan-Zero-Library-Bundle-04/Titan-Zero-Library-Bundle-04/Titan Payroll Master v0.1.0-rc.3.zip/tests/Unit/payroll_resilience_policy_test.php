<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Resilience/PayrollResiliencePolicy.php';
use App\Extensions\TitanPayroll\System\Resilience\PayrollResiliencePolicy;
$p=new PayrollResiliencePolicy(3);
if($p->classify('timeout')!=='retryable'||$p->classify('validation')!=='permanent')exit(1);
if($p->nextState('timeout',1)!=='RETRY_SCHEDULED'||$p->nextState('timeout',3)!=='ATTENTION_REQUIRED'||$p->nextState('validation',1)!=='ATTENTION_REQUIRED')exit(1);
if($p->maxAttempts()!==3||$p->queueFailurePolicy()['dead_letter']!==true)exit(1);
echo "PASS payroll resilience policy\n";
