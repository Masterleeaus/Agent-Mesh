<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);require_once $root.'/System/Security/PayrollSensitiveValue.php';
use App\Extensions\TitanPayroll\System\Security\PayrollSensitiveValue;
$clean=PayrollSensitiveValue::redact(['employee_id'=>7,'bank_account'=>'12345678','routing_number'=>'062000','tax_identifier'=>'999','nested'=>['bsb'=>'123-456','gross'=>1000],'document_html'=>'secret']);
$encoded=json_encode($clean);
foreach(['12345678','062000','999','123-456','secret'] as $secret)if(str_contains($encoded,$secret))exit(1);
if(($clean['employee_id']??null)!==7||($clean['nested']['gross']??null)!==1000)exit(1);
if(PayrollSensitiveValue::mask('12345678')!=='****5678')exit(1);
$variants=PayrollSensitiveValue::redact(['bank_account_number'=>'12345678','employee_tax_file_number'=>'999999999','provider_api_token'=>'secret','safe_reference'=>'ok']);
foreach(['bank_account_number','employee_tax_file_number','provider_api_token'] as $k)if(($variants[$k]??'')!=='[REDACTED]'){fwrite(STDERR,"variant not redacted: {$k}\n");exit(1);}
echo "PASS payroll sensitive value\n";
