<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/Contracts/TimeAttendancePayrollInputPort.php';
require_once $root.'/System/Integrations/TimeAttendance/NullTimeAttendancePayrollInputAdapter.php';
use App\Extensions\TitanPayroll\System\Integrations\TimeAttendance\NullTimeAttendancePayrollInputAdapter;
$p=new NullTimeAttendancePayrollInputAdapter();
if($p->available())exit(1);
$salaried=$p->approvedInputs(42,'2026-08-01','2026-08-14',['worker:7'],false);
if(($salaried['available']??true)!==false||($salaried['required']??true)!==false||($salaried['entries']??null)!==[])exit(1);
try{$p->approvedInputs(42,'2026-08-01','2026-08-14',['worker:7'],true);exit(1);}catch(RuntimeException $e){if(!str_contains($e->getMessage(),'authoritative approved time'))exit(1);}
$src=file_get_contents($root.'/System/Integrations/TimeAttendance/ConfiguredTimeAttendancePayrollInputAdapter.php');
if(preg_match('/DB::|->table\(|TimeEntry::|time_entries/i',$src))exit(1);
echo "PASS time attendance payroll input port\n";
