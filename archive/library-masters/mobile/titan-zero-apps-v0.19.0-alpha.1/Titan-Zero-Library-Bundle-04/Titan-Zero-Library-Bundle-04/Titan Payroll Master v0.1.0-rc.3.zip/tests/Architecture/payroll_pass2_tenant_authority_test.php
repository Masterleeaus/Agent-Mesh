<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = [
    'System/Http/Controllers/PayrollMutationController.php',
    'System/Http/Controllers/PayrollSelfServiceController.php',
    'System/Http/Middleware/ResolvePayrollCompany.php',
    'System/Support/PayrollCompanyContext.php',
    'Services/Core/PayrollRunService.php',
    'Services/Domain/PayrollRunGuardService.php',
];
foreach ($files as $file) {
    if (!is_file($root.'/'.$file)) {
        fwrite(STDERR, "missing canonical tenant-authority file {$file}\n");
        exit(1);
    }
    $source = (string) file_get_contents($root.'/'.$file);
    if (preg_match('/request->validate\([^;]*company_id/s', $source)) {
        fwrite(STDERR, "request company authority in {$file}\n");
        exit(1);
    }
    if (str_contains($source, 'company()->id') || str_contains($source, "function_exists('company')")) {
        fwrite(STDERR, "legacy company authority in {$file}\n");
        exit(1);
    }
}

$mutation = (string) file_get_contents($root.'/System/Http/Controllers/PayrollMutationController.php');
foreach (['PayrollCommandBusGateway', "except(['company_id','user_id','employee_id'])", '$request->user()'] as $needle) {
    if (!str_contains($mutation, $needle)) {
        fwrite(STDERR, "canonical mutation authority missing {$needle}\n");
        exit(1);
    }
}

$context = (string) file_get_contents($root.'/System/Support/PayrollCompanyContext.php');
foreach (['company_id', 'authorised actor context', 'assertMatches'] as $needle) {
    if (!str_contains($context, $needle)) {
        fwrite(STDERR, "company context missing {$needle}\n");
        exit(1);
    }
}

$run = (string) file_get_contents($root.'/Services/Core/PayrollRunService.php');
if (str_contains($run, 'App\\Models\\User') || preg_match("/where\\(['\"]company_id/", $run)) {
    fwrite(STDERR, "direct worker-master query remains\n");
    exit(1);
}
if (!str_contains($run, 'PayrollWorkerInputRepositoryContract')) exit(1);

$guard = (string) file_get_contents($root.'/Services/Domain/PayrollRunGuardService.php');
foreach (['company_id','ext_titan_payroll_runs','ext_titan_payroll_period_locks'] as $needle) {
    if (!str_contains($guard, $needle)) {
        fwrite(STDERR, "guard missing {$needle}\n");
        exit(1);
    }
}

echo "PASS payroll pass2 tenant authority\n";
