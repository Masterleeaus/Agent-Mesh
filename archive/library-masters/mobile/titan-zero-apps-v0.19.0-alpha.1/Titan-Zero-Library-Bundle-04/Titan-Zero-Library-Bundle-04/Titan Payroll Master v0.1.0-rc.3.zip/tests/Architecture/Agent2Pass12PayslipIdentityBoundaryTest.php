<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=[];$assert=function(bool $ok,string $m)use(&$fail){if(!$ok)$fail[]=$m;};
$policy=(string)file_get_contents($root.'/System/Security/PayrollPayslipAccessPolicy.php');
$self=(string)file_get_contents($root.'/System/Services/PayrollSelfServiceReadService.php');
$provider=(string)file_get_contents($root.'/System/TitanPayrollServiceProvider.php');
$assert(!str_contains($policy,"'worker:'.\$actorUserId"),'Payslip policy must not equate People worker id with platform user id.');
$assert(!str_contains($self,"'worker:'.\$actorId"),'Self-service read must not equate People worker id with platform user id.');
$assert(str_contains($policy,'PayrollEmployeeIdentityPort'),'Payslip policy must consume explicit employee identity port.');
$assert(str_contains($self,'PayrollEmployeeIdentityPort'),'Self-service read must consume explicit employee identity port.');
$assert(str_contains($provider,'ConfiguredPayrollEmployeeIdentityPort'),'Payroll service provider must bind the employee identity adapter.');
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "Agent2 Pass12 payslip identity boundary PASS\n";
