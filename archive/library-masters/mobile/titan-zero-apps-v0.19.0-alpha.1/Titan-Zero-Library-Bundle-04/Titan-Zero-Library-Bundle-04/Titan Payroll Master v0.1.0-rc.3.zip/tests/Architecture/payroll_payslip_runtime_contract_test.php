<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$migration = (string) file_get_contents($root.'/database/migrations/2026_08_22_000003_add_titan_payroll_runtime_governance.php');
foreach (['ext_titan_payroll_payslips','worker_ref','document_hash','access_version'] as $needle) {
    if (!str_contains($migration, $needle)) {
        fwrite(STDERR, "missing {$needle}\n");
        exit(1);
    }
}
$mutation = (string) file_get_contents($root.'/System/Services/PayrollMutationService.php');
foreach (['ext_titan_payroll_payslips','finalized_snapshot_hash','pending_communications'] as $needle) {
    if (!str_contains($mutation, $needle)) exit(1);
}
$token = (string) file_get_contents($root.'/Services/Security/EmployeePayslipAccessTokenService.php');
foreach (['company_id','employee_id','expires_at'] as $needle) {
    if (!str_contains($token, $needle)) {
        fwrite(STDERR, "token missing {$needle}\n");
        exit(1);
    }
}
$self = (string) file_get_contents($root.'/System/Services/PayrollSelfServiceReadService.php');
foreach (['PayrollCompanyContext::id($user)', "method_exists(\$user,'getKey')", "where('company_id',\$tenant)", 'limit($limit)'] as $needle) {
    if (!str_contains($self, $needle)) {
        fwrite(STDERR, "self-service actor/tenant guard missing {$needle}\n");
        exit(1);
    }
}
if (str_contains($self, "input('employee_id')") || str_contains($self, "query('employee_id')")) {
    fwrite(STDERR, "employee identity remains caller-controlled\n");
    exit(1);
}
echo "PASS payroll payslip runtime contract\n";
