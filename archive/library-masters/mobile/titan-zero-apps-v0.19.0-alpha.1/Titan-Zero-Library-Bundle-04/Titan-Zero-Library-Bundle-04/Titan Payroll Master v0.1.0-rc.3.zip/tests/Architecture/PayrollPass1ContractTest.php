<?php

declare(strict_types=1);
// Host PHPUnit wrapper intentionally contains no host boot assumptions; standalone gates are the authoritative Pass 1 checks.
final class PayrollPass1ContractTest {}
