<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once $root.'/Contracts/Services/CleanerShiftReconciliationServiceContract.php';
require_once $root.'/Services/Domain/CleanerShiftReconciliationService.php';

$service = new App\Extensions\TitanPayroll\Services\Domain\CleanerShiftReconciliationService();
if (!$service instanceof App\Extensions\TitanPayroll\Contracts\Services\CleanerShiftReconciliationServiceContract) {
    fwrite(STDERR, "cleaner shift reconciliation is not behind its Titan contract\n");
    exit(1);
}
$result = $service->reconcile(
    [['id'=>10,'hours'=>4.0]],
    [],
    ['company_id'=>7,'payroll_run_id'=>11,'source_revision'=>'ta:42']
);
if (($result['passed'] ?? true) !== false || ($result['issues'][0]['type'] ?? '') !== 'missing_time_entry') exit(2);
foreach (['company_id'=>7,'payroll_run_id'=>11,'source_revision'=>'ta:42'] as $key=>$value) {
    if (($result['provenance'][$key] ?? null) !== $value) {
        fwrite(STDERR, "missing cleaner reconciliation provenance {$key}\n");
        exit(3);
    }
}
$provider = (string) file_get_contents($root.'/System/TitanPayrollServiceProvider.php');
foreach (['CleanerShiftReconciliationServiceContract','CleaningPayrollServiceContract','CleaningPayrollSettingsServiceContract','PayrollVarianceServiceContract'] as $needle) {
    if (!str_contains($provider, $needle)) {
        fwrite(STDERR, "provider does not preserve donor contract {$needle}\n");
        exit(4);
    }
}
$input = (string) file_get_contents($root.'/Support/DTOs/CleaningPayrollInput.php');
$resultDto = (string) file_get_contents($root.'/Support/DTOs/CleaningPayrollResult.php');
if (!str_contains($input, 'companyId') || !str_contains($resultDto, 'company_id')) {
    fwrite(STDERR, "cleaning payroll DTOs are not canonical tenant-aware\n");
    exit(5);
}
echo "PASS donor cleaning payroll preservation\n";
