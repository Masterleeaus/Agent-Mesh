<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach([
'System/Support/PayrollCompanyContext.php','System/Support/PayrollCapabilityCatalog.php','System/Authorization/PayrollHostAuthorization.php',
'System/Governance/PayrollCommandRequest.php','System/Governance/PayrollCommandBusPort.php','System/Governance/DeferredPayrollCommandBusPort.php',
'System/Governance/PayrollCommandReceiptStorePort.php','System/Governance/InMemoryPayrollCommandReceiptStore.php','System/Governance/PayrollCapabilityExecutor.php',
'System/Governance/PayrollRiskPort.php','System/Governance/PayrollAssurancePort.php','System/Governance/DeferredPayrollRiskPort.php','System/Governance/DeferredPayrollAssurancePort.php','System/Governance/PayrollCommandBusGateway.php'
] as $f)require_once $root.'/'.$f;
use App\Extensions\TitanPayroll\System\Governance\{PayrollCommandBusGateway,DeferredPayrollCommandBusPort,InMemoryPayrollCommandReceiptStore,PayrollCapabilityExecutor,PayrollRiskPort,PayrollAssurancePort,PayrollCommandRequest};
use App\Extensions\TitanPayroll\System\Authorization\PayrollHostAuthorization;
$actor=new class{public int $id=7;public int $company_id=42;public function can($a){return str_starts_with($a,'payroll.');}};
$exec=new PayrollCapabilityExecutor();$calls=0;$exec->register('payroll.run.prepare',function(array $input,int $tenant)use(&$calls){$calls++;return ['company_id'=>$tenant,'prepared'=>true,'input'=>$input];});
$store=new InMemoryPayrollCommandReceiptStore();
$risk=new class implements PayrollRiskPort{public function available():bool{return true;}public function assess(PayrollCommandRequest $request):array{return ['allowed'=>true,'decision_id'=>'risk-ok'];}};
$assurance=new class implements PayrollAssurancePort{public function available():bool{return true;}public function verify(PayrollCommandRequest $request):array{return ['allowed'=>true,'decision_id'=>'assurance-ok'];}};
$g=new PayrollCommandBusGateway(new DeferredPayrollCommandBusPort(),$exec,$store,new PayrollHostAuthorization(),['payroll_web'],true,$risk,$assurance);
try{$g->request('payroll.run.read',[],$actor);exit(1);}catch(InvalidArgumentException){}
$r1=$g->request('payroll.run.prepare',['idempotency_key'=>'idem-1','run_id'=>9],$actor,'payroll_web','human');
$r2=$g->request('payroll.run.prepare',['idempotency_key'=>'idem-1','run_id'=>9],$actor,'payroll_web','human');
if(($r1['executed']??false)!==true||($r1['company_id']??0)!==42||($r2['replayed']??false)!==true||$calls!==1)exit(1);
if(($r1['governance']['risk_decision_id']??'')!=='risk-ok'||($r1['governance']['assurance_decision_id']??'')!=='assurance-ok')exit(1);
$ai=$g->request('payroll.run.prepare',['idempotency_key'=>'idem-ai','run_id'=>10],$actor,'workforce','ai');
if(($ai['executed']??true)!==false||($ai['status']??'')!=='blocked_dependency')exit(1);

$busyKey=hash('sha256','42|payroll.run.prepare|busy-1');
if(!$store->reserve($busyKey,['status'=>'processing','executed'=>false,'company_id'=>42,'capability'=>'payroll.run.prepare','idempotency_key'=>'busy-1']))exit(1);
$busy=$g->request('payroll.run.prepare',['idempotency_key'=>'busy-1','run_id'=>11],$actor,'payroll_web','human');
if(($busy['status']??'')!=='processing'||($busy['executed']??true)!==false||$calls!==1)exit(1);
echo "PASS payroll command gateway\n";
