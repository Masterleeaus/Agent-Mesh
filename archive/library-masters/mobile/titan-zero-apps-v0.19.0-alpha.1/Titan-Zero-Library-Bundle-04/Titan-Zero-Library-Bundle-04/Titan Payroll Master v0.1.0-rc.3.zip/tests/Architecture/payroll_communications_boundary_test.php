<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
foreach ([
    'System/Contracts/PayrollCommunicationsPort.php',
    'System/Integrations/Communications/ConfiguredPayrollCommunicationsAdapter.php',
    'System/Integrations/Communications/NullPayrollCommunicationsAdapter.php',
] as $file) {
    if (!is_file($root.'/'.$file)) {
        fwrite(STDERR, "missing {$file}\n");
        exit(1);
    }
}
$adapter = (string) file_get_contents($root.'/System/Integrations/Communications/ConfiguredPayrollCommunicationsAdapter.php');
foreach (['PayrollCommunicationsPort','titan.communications.payroll'] as $needle) {
    if (!str_contains($adapter, $needle)) {
        fwrite(STDERR, "communications adapter missing {$needle}\n");
        exit(1);
    }
}
$null = (string) file_get_contents($root.'/System/Integrations/Communications/NullPayrollCommunicationsAdapter.php');
if (!str_contains($null, "'status'=>'unavailable'") || !str_contains($null, "'delivered'=>false")) { fwrite(STDERR, "explicit provider-unavailable state missing\n"); exit(1); }
$manifest = json_decode((string)file_get_contents($root.'/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
if (($manifest['communications']['role'] ?? null) !== 'consumer' || ($manifest['communications']['direct_provider_side_effects'] ?? true) !== false) exit(1);

foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)) as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') continue;
    $rel = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    if (str_starts_with($rel, 'docs/reference/') || str_starts_with($rel, 'tests/')) continue;
    $code = (string) file_get_contents($file->getPathname());
    if (str_contains($code, '->notify(') || str_contains($code, 'Notification::') || str_contains($code, 'Mail::')) {
        fwrite(STDERR, "direct communications provider side effect: {$rel}\n");
        exit(1);
    }
}
echo "PASS payroll communications boundary\n";
