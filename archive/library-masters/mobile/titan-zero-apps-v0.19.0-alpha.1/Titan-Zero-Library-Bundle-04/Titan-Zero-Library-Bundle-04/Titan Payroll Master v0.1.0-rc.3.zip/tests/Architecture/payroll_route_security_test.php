<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$api=$root.'/routes/api.php';if(!is_file($api)){fwrite(STDERR,"missing routes/api.php\n");exit(1);} $s=file_get_contents($api)."\n".file_get_contents($root.'/routes/web.php');
if(preg_match('/Route::get\([^\n]*(prepare|submit|approve|reject|finalize|lock|unlock|resend|update|delete|destroy|remove)/i',$s))exit(1);
foreach(['auth','ResolvePayrollCompany','PayrollMutationController'] as $needle)if(!str_contains($s,$needle))exit(1);
$controller=$root.'/System/Http/Controllers/PayrollMutationController.php';if(!is_file($controller))exit(1);$c=file_get_contents($controller);
if(!str_contains($c,'PayrollCommandBusGateway'))exit(1);
if(preg_match('/->save\(|::create\(|::update\(|DB::table/i',$c))exit(1);
echo "PASS payroll route security\n";
