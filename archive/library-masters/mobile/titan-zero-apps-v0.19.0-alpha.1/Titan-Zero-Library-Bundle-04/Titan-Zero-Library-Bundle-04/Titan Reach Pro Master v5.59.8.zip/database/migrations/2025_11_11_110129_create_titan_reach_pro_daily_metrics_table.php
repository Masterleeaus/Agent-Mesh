<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_pro_post_daily_metrics')) {
            Schema::create('titan_reach_pro_post_daily_metrics', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('titan_reach_post_id');
                        $table->unsignedBigInteger('titan_reach_platform_id')->nullable();
                        $table->string('platform')->nullable();
                        $table->string('post_identifier')->nullable();
                        $table->date('date');
                        $table->unsignedBigInteger('like_count')->default(0);
                        $table->unsignedBigInteger('comment_count')->default(0);
                        $table->unsignedBigInteger('share_count')->default(0);
                        $table->unsignedBigInteger('view_count')->default(0);
                        $table->json('last_totals')->nullable();
                        $table->timestamps();
            
                        $table->unique(['titan_reach_post_id', 'date'], 'titan_reach_flow_post_daily_metrics_post_date_unique');
                        $table->index('titan_reach_post_id', 'idx_titan_reach_post_id_e1fbd310');
                        $table->index('titan_reach_platform_id', 'idx_titan_reach_platform_i_e5e8f863');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_post_daily_metrics');
    }
};
