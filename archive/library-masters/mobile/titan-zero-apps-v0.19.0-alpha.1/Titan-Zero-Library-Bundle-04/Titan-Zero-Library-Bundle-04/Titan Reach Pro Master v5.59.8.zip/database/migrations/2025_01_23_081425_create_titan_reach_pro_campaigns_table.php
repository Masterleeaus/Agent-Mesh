<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_pro_campaigns')) {
            Schema::create('titan_reach_pro_campaigns', function (Blueprint $table) {
                        $table->id();
                        $table->bigInteger('user_id')->nullable();
                        $table->string('name')->nullable();
                        $table->text('target_audience')->nullable();
                        $table->timestamps();
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_campaigns');
    }
};
