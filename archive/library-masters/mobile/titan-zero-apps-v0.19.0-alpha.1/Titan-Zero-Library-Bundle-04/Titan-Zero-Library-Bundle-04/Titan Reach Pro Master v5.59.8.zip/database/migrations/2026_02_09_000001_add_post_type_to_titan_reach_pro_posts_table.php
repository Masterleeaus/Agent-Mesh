<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_pro_posts', 'post_type')) {
                $table->string('post_type')->default('post')->after('titan_reach_platform');
            }
        });
    }

    public function down(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            $table->dropColumn('post_type');
        });
    }
};
