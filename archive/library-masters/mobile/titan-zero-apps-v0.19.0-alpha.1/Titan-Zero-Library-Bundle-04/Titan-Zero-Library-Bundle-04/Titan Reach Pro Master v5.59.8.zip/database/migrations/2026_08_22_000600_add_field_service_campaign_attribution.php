<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_pro_campaigns')) {
            Schema::table('titan_reach_pro_campaigns', function (Blueprint $table) {
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'company_id')) {
                    $table->unsignedBigInteger('company_id')->nullable()->index('idx_company_id_83a9858c')->after('user_id');
                }
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'field_service_objective')) {
                    $table->string('field_service_objective', 80)->nullable()->index('idx_field_service_objectiv_72f6c04d')->after('target_audience');
                }
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'conversion_goal')) {
                    $table->string('conversion_goal', 80)->nullable()->after('field_service_objective');
                }
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'attribution_key')) {
                    $table->string('attribution_key', 120)->nullable()->unique('uq_attribution_key_5a98578e')->after('conversion_goal');
                }
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'field_service_source_context')) {
                    $table->json('field_service_source_context')->nullable()->after('attribution_key');
                }
                if (! Schema::hasColumn('titan_reach_pro_campaigns', 'conversion_summary')) {
                    $table->json('conversion_summary')->nullable()->after('field_service_source_context');
                }
            });
        }

        if (Schema::hasTable('titan_reach_pro_posts')) {
            Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
                if (! Schema::hasColumn('titan_reach_pro_posts', 'field_service_campaign_objective')) {
                    $table->string('field_service_campaign_objective', 80)->nullable()->index('idx_field_service_campaign_5601dcbd')->after('campaign_id');
                }
                if (! Schema::hasColumn('titan_reach_pro_posts', 'attribution_key')) {
                    $table->string('attribution_key', 120)->nullable()->index('idx_attribution_key_787d11b5')->after('field_service_campaign_objective');
                }
                if (! Schema::hasColumn('titan_reach_pro_posts', 'attribution_source')) {
                    $table->string('attribution_source', 80)->nullable()->after('attribution_key');
                }
                if (! Schema::hasColumn('titan_reach_pro_posts', 'conversion_summary')) {
                    $table->json('conversion_summary')->nullable()->after('attribution_source');
                }
            });
        }

        if (! Schema::hasTable('titan_reach_pro_field_service_conversion_events')) {
            Schema::create('titan_reach_pro_field_service_conversion_events', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index('idx_company_id_06dd3a28');
                $table->unsignedBigInteger('user_id')->nullable()->index('idx_user_id_99024b18');
                $table->unsignedBigInteger('campaign_id')->nullable()->index('idx_campaign_id_42ab7a02');
                $table->unsignedBigInteger('post_id')->nullable()->index('idx_post_id_3480f911');
                $table->string('attribution_key', 120)->nullable()->index('idx_attribution_key_bb504739');
                $table->string('event_type', 40)->index('idx_event_type_c392582b');
                $table->string('source', 80)->nullable()->index('idx_source_5e88f1ab');
                $table->decimal('value', 12, 2)->nullable();
                $table->string('currency', 8)->nullable();
                $table->string('dedupe_key', 160)->nullable()->unique('uq_dedupe_key_bd094843');
                $table->json('metadata')->nullable();
                $table->timestamp('occurred_at')->nullable()->index('idx_occurred_at_51ab4744');
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_field_service_conversion_events');
    }
};
