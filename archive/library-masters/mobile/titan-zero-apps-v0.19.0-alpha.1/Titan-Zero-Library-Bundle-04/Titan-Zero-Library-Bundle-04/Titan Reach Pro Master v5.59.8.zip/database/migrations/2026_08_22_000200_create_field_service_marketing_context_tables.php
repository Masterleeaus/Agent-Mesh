<?php

use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_pro_field_service_marketing_profiles')) {
            Schema::create('titan_reach_pro_field_service_marketing_profiles', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->unique('uq_company_id_1b933864');
                $table->string('business_name')->nullable();
                $table->string('vertical')->nullable();
                $table->json('hours')->nullable();
                $table->boolean('emergency_available')->default(false);
                $table->json('contact_channels')->nullable();
                $table->string('quote_url', 500)->nullable();
                $table->string('booking_url', 500)->nullable();
                $table->string('review_url', 500)->nullable();
                $table->json('licence_trust_statements')->nullable();
                $table->json('seasonal_services')->nullable();
                $table->text('brand_voice')->nullable();
                $table->json('privacy_defaults')->nullable();
                $table->unsignedTinyInteger('completeness_score')->default(0);
                $table->json('missing_fields')->nullable();
                $table->timestamps();
                $table->index('company_id', 'idx_company_id_bb713b9a');
            });
        }

        if (! Schema::hasTable('titan_reach_pro_field_service_services')) {
            Schema::create('titan_reach_pro_field_service_services', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('profile_id');
                $table->unsignedBigInteger('company_id');
                $table->string('name');
                $table->text('description')->nullable();
                $table->boolean('active')->default(true);
                $table->unsignedInteger('sort_order')->default(0);
                $table->timestamps();
                $table->index(['company_id', 'active', 'sort_order'], 'titan_reach_flow_field_services_company_active_sort_idx');
                $table->index(['profile_id', 'sort_order'], 'titan_reach_flow_field_services_profile_sort_idx');
            });
        }

        if (! Schema::hasTable('titan_reach_pro_field_service_service_areas')) {
            Schema::create('titan_reach_pro_field_service_service_areas', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('profile_id');
                $table->unsignedBigInteger('company_id');
                $table->string('name');
                $table->string('state')->nullable();
                $table->string('country')->nullable();
                $table->boolean('active')->default(true);
                $table->unsignedInteger('sort_order')->default(0);
                $table->timestamps();
                $table->index(['company_id', 'active', 'sort_order'], 'titan_reach_flow_field_areas_company_active_sort_idx');
                $table->index(['profile_id', 'sort_order'], 'titan_reach_flow_field_areas_profile_sort_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_field_service_service_areas');
        Schema::dropIfExists('titan_reach_pro_field_service_services');
        Schema::dropIfExists('titan_reach_pro_field_service_marketing_profiles');
    }
};
