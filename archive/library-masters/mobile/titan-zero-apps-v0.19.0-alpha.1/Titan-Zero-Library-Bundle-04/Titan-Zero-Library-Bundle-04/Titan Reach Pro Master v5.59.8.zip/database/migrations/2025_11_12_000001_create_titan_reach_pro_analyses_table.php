<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_pro_analyses')) {
            return;
        }

        Schema::create('titan_reach_pro_analyses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->index('idx_user_id_11f638a0');
            $table->string('type');
            $table->bigInteger('agent_id')->nullable();
            $table->text('summary')->nullable();
            $table->longText('report_text');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('read_at')->nullable();
        });

    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_analyses');
    }
};
