<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_pro_posts', 'field_service_media_privacy_acknowledged')) {
                $table->boolean('field_service_media_privacy_acknowledged')->default(false)->after('images');
            }
            if (! Schema::hasColumn('titan_reach_pro_posts', 'field_service_media_customer_consent')) {
                $table->boolean('field_service_media_customer_consent')->default(false)->after('field_service_media_privacy_acknowledged');
            }
            if (! Schema::hasColumn('titan_reach_pro_posts', 'field_service_media_privacy_report')) {
                $table->json('field_service_media_privacy_report')->nullable()->after('field_service_media_customer_consent');
            }
        });
    }

    public function down(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            foreach ([
                'field_service_media_privacy_report',
                'field_service_media_customer_consent',
                'field_service_media_privacy_acknowledged',
            ] as $column) {
                if (Schema::hasColumn('titan_reach_pro_posts', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
