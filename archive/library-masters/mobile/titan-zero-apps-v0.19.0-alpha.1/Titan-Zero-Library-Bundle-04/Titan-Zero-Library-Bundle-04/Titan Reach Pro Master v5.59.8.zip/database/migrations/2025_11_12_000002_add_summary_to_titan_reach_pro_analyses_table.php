<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_reach_pro_analyses', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_pro_analyses', 'summary')) {
                $table->text('summary')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_pro_analyses');
    }
};
