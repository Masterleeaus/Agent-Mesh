<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            if (Schema::hasColumn('titan_reach_pro_posts', 'titan_reach_platform')) {
                return;
            }

            $table->string('titan_reach_platform')
                ->nullable()
                ->after('titan_reach_platform_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('titan_reach_pro_posts', function (Blueprint $table) {
            $table->dropColumn('titan_reach_platform');
        });
    }
};
