<?php

declare(strict_types=1);

return ['workspace' => 'field_home_services_social_marketing', 'module' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'role' => 'Authoritative publisher', 'route' => 'dashboard.user.titan-reach.field-service-workspace', 'permissions' => ['field_service_marketing.view', 'field_service_marketing.manage_context', 'field_service_marketing.create_content', 'field_service_marketing.manage_campaigns', 'field_service_marketing.manage_automations', 'field_service_marketing.view_leads', 'field_service_marketing.publish']];
