<?php

declare(strict_types=1);

return [
    'phase' => 'phase_4_live_install_production',
    'step' => 34,
    'module_key' => 'field_marketing_hub',
    'purpose' => 'diagnostics_driven_hotfix_intake',
    'non_mutating' => true,
    'release_decisions' => [
        'advance',
        'hold',
        'hotfix_required',
    ],
    'hotfix_targets' => [
        'manifest_schema_hotfix',
        'migration_database_hotfix',
        'route_registration_hotfix',
        'view_blade_hotfix',
        'class_autoload_hotfix',
        'permission_cache_storage_hotfix',
        'webhook_callback_security_hotfix',
        'unknown_live_failure_hotfix',
    ],
    'redaction_keys' => [
        'token',
        'secret',
        'signature',
        'password',
        'authorization',
        'cookie',
        'customer_name',
        'customer_handle',
        'contact_value',
        'external_customer_id',
        'raw_webhook_body',
        'message_body',
        'comment_text',
        'stack_trace',
        'trace',
        'exception_trace',
        'sql',
        'query',
        'bindings',
    ],
    'safety' => [
        'preserve_company_boundary' => true,
        'do_not_store_raw_stack_traces' => true,
        'do_not_store_sql_bindings' => true,
        'do_not_mutate_installed_extensions' => true,
    ],
];
