<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'module' => 'google_business_profile_reputation',
    'extension_role' => 'field_marketing_hub',
    'requires_company_id' => true,
    'safe_defaults' => [
        'auto_reply_reviews' => false,
        'auto_publish_posts' => false,
        'auto_upload_photos' => false,
        'invent_licences' => false,
        'invent_prices' => false,
        'invent_emergency_service' => false,
        'invent_service_areas' => false,
    ],
    'destinations' => [
        'google_business_profile' => [
            'supports_posts' => true,
            'supports_photos' => true,
            'supports_reviews' => true,
            'supports_review_replies' => true,
            'supports_location_discovery' => true,
            'supports_account_discovery' => true,
            'supports_performance_signals' => true,
            'requires_oauth' => true,
            'requires_location_correlation' => true,
            'requires_human_approval_for_replies' => true,
        ],
    ],
    'review_risk_terms' => [
        'injury', 'unsafe', 'electric shock', 'gas leak', 'fire', 'flooding',
        'no power', 'break in', 'locked out', 'mould', 'complaint', 'refund',
    ],
];
