<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'mode' => 'dry_run',
    'requires_company_id' => true,
    'module' => 'field_marketing_hub',
    'checks' => [
        'context_resolved',
        'growth_signal_selected',
        'ai_provider_ready_or_safe_fallback',
        'privacy_guardrails_present',
        'draft_plan_created',
        'publish_governance_respected',
        'event_emission_ready',
        'standalone_fallback_ready',
    ],
    'blocked_without' => [
        'company_id',
        'context_resolution',
        'privacy_guardrails',
    ],
    'redacted_fields' => [
        'token',
        'secret',
        'signature',
        'customer_name',
        'customer_handle',
        'external_customer_id',
        'contact_value',
        'raw_webhook_body',
        'message_body',
        'comment_text',
    ],
    'forbidden_inferences' => [
        'prices',
        'licences',
        'emergency_availability',
        'service_areas',
        'customer_names',
        'exact_addresses',
        'faces',
        'vehicle_plates',
        'private_job_details',
    ],
];
