<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach',
    'module_slug' => 'field_marketing_hub',
    'module_label' => 'Field Marketing Hub',
    'route_names' => [
        'dashboard.user.titan-reach.field-service-workspace',
        'dashboard.user.titan-reach.index',
        'dashboard.user.titan-reach.post.index',
        'dashboard.user.titan-reach.post.create',
        'dashboard.user.titan-reach.campaign.index',
        'dashboard.user.titan-reach.field-service-profile.edit',
        'dashboard.user.titan-reach.field-service-template.preview'
    ],
    'view_paths' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/index.blade.php',
        'resources/views/post/create.blade.php',
        'resources/views/post/index.blade.php',
        'resources/views/campaign/index.blade.php',
        'resources/views/field-service-profile.blade.php'
    ],
    'controller_paths' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/TitanReachController.php',
        'System/Http/Controllers/TitanReachPostController.php',
        'System/Http/Controllers/TitanReachCampaignController.php',
        'System/Http/Controllers/FieldServiceMarketingProfileController.php'
    ],
    'safe_route_resolution' => true,
    'safe_blade_includes' => true,
    'missing_module_mode' => 'disabled_link',
    'fallback_url_mode' => 'url_path',
    'permission' => 'field_service_marketing.view',
    'company_scoped' => true,
];
