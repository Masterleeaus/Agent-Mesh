<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach',
    'module_slug' => 'field_marketing_hub',
    'module_name' => 'Field Marketing Hub',
    'version' => '5.58',
    'runtime_smoke_ready' => true,
    'route_names' => [
        'dashboard.user.titan-reach.field-service-workspace',
        'dashboard.user.titan-reach.index',
        'dashboard.user.titan-reach.post.index',
        'dashboard.user.titan-reach.post.create',
        'dashboard.user.titan-reach.campaign.generate',
        'dashboard.user.titan-reach.field-service-profile.edit',
        'dashboard.user.titan-reach.field-service-template.preview'
    ],
    'route_prefixes' => [
        'dashboard/user/titan-reach',
        'titan-reach/oauth'
    ],
    'views' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/index.blade.php',
        'resources/views/post/create.blade.php',
        'resources/views/field-service-profile.blade.php'
    ],
    'controllers' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/TitanReachController.php',
        'System/Http/Controllers/TitanReachPostController.php',
        'System/Http/Controllers/FieldServiceMarketingProfileController.php'
    ],
    'navigation_modules' => [
        'field_marketing_hub',
        'local_growth_agent',
        'lead_review_automation',
        'campaign_playbooks'
    ],
    'checks' => [
        'route_registration',
        'view_resolution',
        'controller_presence',
        'config_registration',
        'workspace_navigation',
        'permission_gate',
        'standalone_fallback'
    ]
];
