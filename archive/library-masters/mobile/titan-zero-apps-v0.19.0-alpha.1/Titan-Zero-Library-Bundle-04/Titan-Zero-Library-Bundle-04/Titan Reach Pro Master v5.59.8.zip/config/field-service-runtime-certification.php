<?php

return [
    'step' => 24,
    'status' => 'runtime-ready',
    'module' => 'field_marketing_hub',
    'certification' => [
        'requires_company_id' => true,
        'standalone_safe' => true,
        'security_controls_locked' => true,
        'privacy_controls_locked' => true,
        'publish_governance_locked' => true,
        'webhooks_fail_closed' => true,
        'titan_integrations_optional' => true,
        'demo_data_marked_demo_only' => true,
    ],
    'gates' => [
        'archive_path_safety',
        'manifest_json_parse',
        'bom_free_manifest',
        'php_lint',
        'runtime_readiness',
        'route_menu_smoke',
        'lead_flow_simulation',
        'publish_governance',
        'titan_hooks_optional',
        'commercial_limits_safe',
        'demo_showcase_safe',
    ],
];
