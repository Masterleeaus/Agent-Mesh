<?php

return [
    'enabled' => true,
    'activation' => [
        'default_mode' => 'draft_only',
        'require_human_approval' => true,
        'allow_automatic_activation' => false,
        'allow_automatic_budget_increase' => false,
    ],
    'budget' => [
        'default_daily_ceiling_minor' => 0,
        'default_campaign_ceiling_minor' => 0,
        'currency' => 'AUD',
    ],
    'channels' => [
        'meta_ads' => [
            'enabled' => true,
            'requires_ad_account' => true,
            'requires_payment_profile' => true,
            'supports_draft' => true,
            'supports_activation' => true,
        ],
        'google_local_services_ads' => [
            'enabled' => true,
            'requires_business_verification' => true,
            'requires_category_eligibility' => true,
            'requires_service_area_match' => true,
            'supports_draft' => true,
            'supports_activation' => false,
        ],
    ],
    'safety' => [
        'never_invent_licence' => true,
        'never_invent_price' => true,
        'never_invent_emergency_service' => true,
        'never_expand_service_area' => true,
        'redact_customer_data' => true,
    ],
];
