@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Reach Accounts'))
@section('titlebar_actions', '')
@section('titlebar_subtitle', __('You can connect and manage multiple Titan Reach accounts from here.'))

@section('content')
    <div class="py-10">
        @include('titan-reach::platforms.platform-statistics', ['items' => $userPlatforms])
        @include('titan-reach::platforms.platform-cards', ['platforms' => $platforms])
        @include('titan-reach::platforms.platform-table', ['items' => $userPlatforms])
    </div>
@endsection
