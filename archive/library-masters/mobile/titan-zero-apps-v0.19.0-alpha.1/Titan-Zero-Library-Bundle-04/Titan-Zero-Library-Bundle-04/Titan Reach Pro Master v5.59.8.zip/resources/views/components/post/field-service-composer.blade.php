@php
    $templates = $fieldServiceTemplates['templates'] ?? [];
    $services = $fieldServiceTemplates['services'] ?? [];
    $areas = $fieldServiceTemplates['service_areas'] ?? [];
    $guardrails = $fieldServiceTemplates['guardrails'] ?? [];
@endphp

<div class="rounded-2xl border border-input-border bg-heading-foreground/[0.03] p-4">
    <div class="mb-4 flex items-start justify-between gap-3">
        <div>
            <p class="mb-1 text-sm font-semibold text-heading-foreground">
                @lang('Field-service content composer')
            </p>
            <p class="mb-0 text-2xs text-heading-foreground/60">
                @lang('Use only configured services, service areas and contact links. The composer never invents licences, prices, emergency service or customer details.')
            </p>
        </div>
        <span class="rounded-full bg-primary/10 px-3 py-1 text-[11px] font-semibold text-primary">
            {{ (int) ($fieldServiceContext?->completenessScore ?? 0) }}% @lang('ready')
        </span>
    </div>

    <div class="grid grid-cols-1 gap-3 md:grid-cols-2">
        <x-forms.input
            class:label="text-heading-foreground"
            type="select"
            size="lg"
            name="field_service_template"
            label="{{ __('Template') }}"
            x-model="fieldServiceTemplate"
        >
            @foreach ($templates as $key => $template)
                <option value="{{ $key }}">
                    {{ $template['label'] }}
                </option>
            @endforeach
        </x-forms.input>

        <x-forms.input
            class:label="text-heading-foreground"
            type="select"
            size="lg"
            name="field_service_cta"
            label="{{ __('Call to action') }}"
            x-model="fieldServiceCta"
        >
            <option value="quote">@lang('Request quote')</option>
            <option value="booking">@lang('Book')</option>
            <option value="contact">@lang('Contact')</option>
            <option value="review">@lang('Review')</option>
        </x-forms.input>

        <x-forms.input
            class:label="text-heading-foreground"
            type="select"
            size="lg"
            name="field_service_service"
            label="{{ __('Service') }}"
            x-model="fieldServiceService"
        >
            <option value="">@lang('Use first active service')</option>
            @foreach ($services as $service)
                <option value="{{ $service['name'] }}">
                    {{ $service['name'] }}
                </option>
            @endforeach
        </x-forms.input>

        <x-forms.input
            class:label="text-heading-foreground"
            type="select"
            size="lg"
            name="field_service_area"
            label="{{ __('Service area') }}"
            x-model="fieldServiceArea"
        >
            <option value="">@lang('Use first active area')</option>
            @foreach ($areas as $area)
                <option value="{{ $area['name'] }}">
                    {{ $area['name'] }}
                </option>
            @endforeach
        </x-forms.input>
    </div>

    <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
        <x-forms.input
            class:label="text-heading-foreground text-2xs"
            type="checkbox"
            name="field_service_privacy_acknowledged"
            label="{{ __('I have consent and have checked job-site media for faces, plates, addresses and customer details') }}"
            switcher
            x-model="fieldServicePrivacyAcknowledged"
        />
        <input type="hidden" name="field_service_media_privacy_acknowledged" :value="fieldServicePrivacyAcknowledged ? '1' : ''">
        <input type="hidden" name="field_service_media_customer_consent" :value="fieldServicePrivacyAcknowledged ? '1' : '0'">

        <x-button
            class="text-2xs font-semibold"
            type="button"
            variant="secondary"
            @click.prevent="applyFieldServiceTemplate"
            ::disabled="fieldServiceGenerating"
        >
            <span x-show="!fieldServiceGenerating">@lang('Use template')</span>
            <span x-show="fieldServiceGenerating" x-cloak>@lang('Preparing...')</span>
        </x-button>
    </div>

    <ul class="mt-4 list-disc space-y-1 ps-5 text-[11px] leading-relaxed text-heading-foreground/60">
        @foreach ($guardrails as $guardrail)
            <li>{{ $guardrail }}</li>
        @endforeach
    </ul>
</div>
