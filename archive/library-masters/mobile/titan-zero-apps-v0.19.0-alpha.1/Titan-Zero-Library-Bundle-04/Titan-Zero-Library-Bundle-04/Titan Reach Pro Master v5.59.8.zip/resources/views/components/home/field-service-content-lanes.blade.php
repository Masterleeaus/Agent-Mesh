@php
    $lanes = $fieldMarketingHub['content_lanes'] ?? [];
@endphp

<div class="lqd-field-service-content-lanes">
    <div class="mb-7 flex flex-wrap items-center justify-between gap-4">
        <div>
            <h3 class="m-0">@lang('Field-service content lanes')</h3>
            <p class="m-0 mt-1 text-sm text-heading-foreground/60">@lang('Reusable local marketing prompts grounded in the shared field-service context.')</p>
        </div>
        <x-button
            class="text-2xs"
            variant="link"
            href="{{ route('dashboard.user.titan-reach.post.create') }}"
        >
            @lang('Create post')
            <x-tabler-chevron-right class="size-4" />
        </x-button>
    </div>

    <div class="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
        @foreach ($lanes as $lane)
            <x-card
                class="text-heading-foreground transition-transform hover:-translate-y-1 hover:shadow-lg hover:shadow-black/5"
                class:body="flex h-full flex-col gap-4"
            >
                <div>
                    <h4 class="mb-2 text-base font-semibold">{{ $lane['title'] }}</h4>
                    <p class="m-0 text-sm leading-6 text-heading-foreground/65">{{ $lane['description'] }}</p>
                </div>
                <div class="mt-auto rounded-xl bg-heading-foreground/[0.03] p-3 text-xs leading-5 text-heading-foreground/70">
                    {{ $lane['prompt'] }}
                </div>
                <div class="text-2xs font-medium uppercase tracking-wide text-heading-foreground/45">
                    @lang('Guardrail'): {{ $lane['guardrail'] }}
                </div>
            </x-card>
        @endforeach
    </div>
</div>
