<div
    class="lqd-titan-reach-post-content w-full"
    id="lqd-titan-reach-post-content"
>
    @if (isset($post))
        @include('titan-reach::components.post.post-content', [
            'post' => $post,
            'prev_post_id' => $post->prev_post_id ?? null,
            'next_post_id' => $next_post_id ?? null,
        ])
    @else
        <h3>
            @lang('404 Not Found')
        </h3>
    @endif
</div>
