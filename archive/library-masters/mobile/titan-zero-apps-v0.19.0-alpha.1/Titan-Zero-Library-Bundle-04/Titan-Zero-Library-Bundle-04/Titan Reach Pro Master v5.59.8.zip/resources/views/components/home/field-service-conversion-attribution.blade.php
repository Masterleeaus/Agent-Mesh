<section class="rounded-2xl border border-border bg-background p-6 shadow-sm">
    <div class="mb-4 flex items-start justify-between gap-4">
        <div>
            <h2 class="text-lg font-semibold text-heading-foreground">{{ __('Field-service conversion attribution') }}</h2>
            <p class="text-sm text-heading-foreground/70">
                {{ __('Campaigns can now carry quote, booking, lead, review and revenue attribution without requiring CRM or job extensions.') }}
            </p>
        </div>
        <a class="text-sm font-semibold text-primary" href="{{ route('dashboard.user.titan-reach.campaign.index') }}">
            {{ __('Manage campaigns') }}
        </a>
    </div>

    <div class="grid grid-cols-1 gap-3 md:grid-cols-4">
        @foreach (['quote_requests' => __('Quote requests'), 'bookings' => __('Bookings'), 'reviews' => __('Reviews'), 'local_awareness' => __('Local awareness')] as $key => $label)
            <div class="rounded-xl bg-heading-foreground/[0.03] p-4">
                <div class="text-sm font-semibold text-heading-foreground">{{ $label }}</div>
                <div class="mt-1 text-xs text-heading-foreground/60">{{ __('Safe standalone attribution key:') }} {{ $key }}</div>
            </div>
        @endforeach
    </div>
</section>
