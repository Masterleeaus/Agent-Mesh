@extends('panel.layout.app')
@section('title', __('Field-Service Marketing Context'))
@section('titlebar_subtitle', __('Company-scoped services, areas, contact channels and privacy defaults used by social marketing agents and automations.'))

@section('content')
    <div class="py-6">
        <form method="POST" action="{{ route('dashboard.user.titan-reach.field-service-profile.update') }}" class="space-y-6">
            @csrf
            @method('PATCH')

            <div class="card p-6">
                <h3 class="mb-4 text-lg font-semibold">{{ __('Business profile') }}</h3>
                <div class="grid gap-4 md:grid-cols-2">
                    <div>
                        <label class="form-label">{{ __('Business name') }}</label>
                        <input name="business_name" class="form-control" value="{{ old('business_name', $context['business_name'] ?? '') }}">
                    </div>
                    <div>
                        <label class="form-label">{{ __('Vertical') }}</label>
                        <input name="vertical" class="form-control" placeholder="{{ __('Cleaning, plumbing, electrical...') }}" value="{{ old('vertical', $context['vertical'] ?? '') }}">
                    </div>
                    <div>
                        <label class="form-label">{{ __('Vertical starter packs') }}</label>
                        <select name="vertical_pack_preview" class="form-control" onchange="if(this.value){document.querySelector('[name=vertical]').value=this.options[this.selectedIndex].text}">
                            <option value="">{{ __('Choose a starter pack label') }}</option>
                            @foreach (($verticalPacks ?? []) as $slug => $pack)
                                <option value="{{ $slug }}">{{ $pack['label'] ?? $slug }}</option>
                            @endforeach
                        </select>
                        <p class="mt-2 text-muted">{{ __('Starter packs suggest safe services, seasonal themes, CTAs and automation keywords. They do not assert licences, prices, emergency availability or coverage.') }}</p>
                    </div>

                </div>
            </div>

            <div class="card p-6">
                <h3 class="mb-4 text-lg font-semibold">{{ __('Services and areas') }}</h3>
                <p class="text-muted mb-4">{{ __('One item per line. These are factual capabilities only; do not list licences, coverage or emergency services unless they are true.') }}</p>
                <div class="grid gap-4 md:grid-cols-2">
                    <div>
                        <label class="form-label">{{ __('Services') }}</label>
                        <textarea name="services_text" class="form-control" rows="8">{{ collect($context['services'] ?? [])->pluck('name')->implode("\n") }}</textarea>
                    </div>
                    <div>
                        <label class="form-label">{{ __('Service areas') }}</label>
                        <textarea name="service_areas_text" class="form-control" rows="8">{{ collect($context['service_areas'] ?? [])->pluck('name')->implode("\n") }}</textarea>
                    </div>
                </div>
            </div>

            <div class="card p-6">
                <h3 class="mb-4 text-lg font-semibold">{{ __('Contact and conversion') }}</h3>
                <div class="grid gap-4 md:grid-cols-3">
                    <div><label class="form-label">{{ __('Quote URL') }}</label><input type="url" name="quote_url" class="form-control" value="{{ old('quote_url', $context['quote_url'] ?? '') }}"></div>
                    <div><label class="form-label">{{ __('Booking URL') }}</label><input type="url" name="booking_url" class="form-control" value="{{ old('booking_url', $context['booking_url'] ?? '') }}"></div>
                    <div><label class="form-label">{{ __('Review URL') }}</label><input type="url" name="review_url" class="form-control" value="{{ old('review_url', $context['review_url'] ?? '') }}"></div>
                </div>
                <label class="form-check mt-4">
                    <input type="hidden" name="emergency_available" value="0">
                    <input type="checkbox" name="emergency_available" value="1" class="form-check-input" @checked(old('emergency_available', $context['emergency_available'] ?? false))>
                    <span class="form-check-label">{{ __('Emergency/after-hours service is genuinely available') }}</span>
                </label>
            </div>

            <div class="card p-6">
                <h3 class="mb-4 text-lg font-semibold">{{ __('Trust, voice and privacy') }}</h3>
                <div class="grid gap-4 md:grid-cols-2">
                    <div>
                        <label class="form-label">{{ __('Licence/trust statements') }}</label>
                        <textarea name="licence_trust_statements_text" class="form-control" rows="5" placeholder="{{ __('Only facts you can verify.') }}">{{ collect($context['licence_trust_statements'] ?? [])->implode("\n") }}</textarea>
                    </div>
                    <div>
                        <label class="form-label">{{ __('Brand voice') }}</label>
                        <textarea name="brand_voice" class="form-control" rows="5">{{ old('brand_voice', $context['brand_voice'] ?? '') }}</textarea>
                    </div>
                </div>
                <p class="mt-4 text-muted">{{ __('Privacy defaults are conservative: no customer names, exact addresses, faces, plates or before/after media unless explicitly enabled. Job-site media is sanitized before publishing.') }}</p>
                @php($privacyDefaults = $context['privacy_defaults'] ?? [])
                @foreach ([
                    'strip_exif' => __('Strip EXIF metadata from uploaded job images'),
                    'strip_gps' => __('Strip GPS/location metadata from uploaded job images'),
                    'require_media_consent' => __('Require media/privacy acknowledgement before job-media upload'),
                    'require_human_review' => __('Require human review before publishing job-site content'),
                ] as $key => $label)
                    <label class="form-check mt-2">
                        <input type="hidden" name="privacy_defaults[{{ $key }}]" value="0">
                        <input type="checkbox" name="privacy_defaults[{{ $key }}]" value="1" class="form-check-input" @checked((bool) ($privacyDefaults[$key] ?? true))>
                        <span class="form-check-label">{{ $label }}</span>
                    </label>
                @endforeach
                @foreach ([
                    'include_customer_names' => __('Allow customer names in marketing content'),
                    'include_exact_addresses' => __('Allow exact street addresses in marketing content'),
                    'include_faces' => __('Allow identifiable faces in marketing media'),
                    'include_vehicle_plates' => __('Allow vehicle plates in marketing media'),
                    'include_before_after_media' => __('Allow before/after media after consent'),
                    'allow_ai_to_identify_people' => __('Allow AI prompts to identify people'),
                    'allow_ai_to_infer_location' => __('Allow AI prompts to infer exact location'),
                ] as $key => $label)
                    <label class="form-check mt-2">
                        <input type="hidden" name="privacy_defaults[{{ $key }}]" value="0">
                        <input type="checkbox" name="privacy_defaults[{{ $key }}]" value="1" class="form-check-input" @checked((bool) ($privacyDefaults[$key] ?? false))>
                        <span class="form-check-label">{{ $label }}</span>
                    </label>
                @endforeach
                <div class="mt-3">{{ __('Completeness score:') }} <strong>{{ $context['completeness_score'] ?? 0 }}%</strong></div>
            </div>

            <button class="btn btn-primary" type="submit">{{ __('Save field-service context') }}</button>
        </form>
    </div>
@endsection
