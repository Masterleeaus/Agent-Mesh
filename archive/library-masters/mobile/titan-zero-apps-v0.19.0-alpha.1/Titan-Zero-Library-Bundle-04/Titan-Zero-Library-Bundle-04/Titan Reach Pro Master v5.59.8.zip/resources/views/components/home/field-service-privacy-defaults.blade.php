@php
    $privacy = $fieldMarketingHub['privacy_defaults'] ?? [];
    $labels = [
        'include_customer_names' => __('Customer names'),
        'include_exact_addresses' => __('Exact addresses'),
        'include_faces' => __('Faces'),
        'include_vehicle_plates' => __('Vehicle plates'),
        'include_before_after_media' => __('Before/after media'),
        'strip_exif' => __('Strip EXIF'),
        'strip_gps' => __('Strip GPS'),
        'require_media_consent' => __('Require media consent'),
        'allow_ai_to_identify_people' => __('AI may identify people'),
        'allow_ai_to_infer_location' => __('AI may infer location'),
        'require_human_review' => __('Human review required'),
    ];
@endphp

<x-card class="border border-heading-foreground/10" class:body="p-6">
    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
            <h3 class="m-0 text-lg font-semibold">@lang('Publishing privacy defaults')</h3>
            <p class="m-0 mt-1 text-sm text-heading-foreground/60">@lang('These defaults protect job-site content before it reaches AI drafting or publishing.')</p>
        </div>
        <x-button
            class="text-2xs"
            variant="ghost-shadow"
            href="{{ route('dashboard.user.titan-reach.field-service-profile.edit') }}"
        >
            @lang('Change defaults')
        </x-button>
    </div>

    <div class="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
        @foreach ($labels as $key => $label)
            @php $enabled = (bool) ($privacy[$key] ?? false); @endphp
            <div class="flex items-center justify-between rounded-xl bg-heading-foreground/[0.03] px-4 py-3 text-sm">
                <span>{{ $label }}</span>
                <span class="rounded-full px-2 py-1 text-2xs font-semibold {{ $enabled ? 'bg-primary/10 text-primary' : 'bg-red-500/10 text-red-500' }}">
                    {{ $enabled ? __('Allowed') : __('Blocked') }}
                </span>
            </div>
        @endforeach
    </div>
</x-card>
