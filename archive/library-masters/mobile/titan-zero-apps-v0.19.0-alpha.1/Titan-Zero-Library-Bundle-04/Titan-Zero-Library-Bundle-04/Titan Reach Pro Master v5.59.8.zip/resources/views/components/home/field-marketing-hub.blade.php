@php
    $hub = $fieldMarketingHub ?? [];
    $context = $fieldServiceContext ?? null;
    $readiness = (int) ($hub['readiness_score'] ?? 0);
    $services = $hub['services'] ?? [];
    $areas = $hub['service_areas'] ?? [];
    $cta = $hub['primary_cta'] ?? ['label' => __('Add quote or booking link'), 'url' => null, 'type' => 'missing'];
@endphp

<x-card
    class="overflow-hidden border border-heading-foreground/10"
    class:body="p-0"
>
    <div class="grid grid-cols-1 gap-0 lg:grid-cols-[1.3fr_0.7fr]">
        <div class="p-7 lg:p-9">
            <div class="mb-5 flex flex-wrap items-center gap-3">
                <span class="rounded-full bg-primary/10 px-3 py-1 text-2xs font-semibold uppercase tracking-wide text-primary">
                    @lang('Field Marketing Hub')
                </span>
                <span class="rounded-full bg-heading-foreground/5 px-3 py-1 text-2xs font-medium text-heading-foreground/70">
                    {{ $hub['vertical_label'] ?? __('Field & home services') }}
                </span>
            </div>

            <h2 class="mb-3 text-2xl font-semibold text-heading-foreground">
                {{ $hub['business_label'] ?? __('Your field-service business') }}
            </h2>

            <p class="mb-6 max-w-3xl text-sm leading-6 text-heading-foreground/70">
                @lang('Plan local posts around your real services, real service areas, configured booking paths and strict privacy defaults. The hub will not invent licences, prices, emergency availability or geographic coverage.')
            </p>

            <div class="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div class="rounded-xl bg-heading-foreground/[0.03] p-4">
                    <div class="text-2xs font-semibold uppercase tracking-wide text-heading-foreground/50">@lang('Profile readiness')</div>
                    <div class="mt-2 text-3xl font-semibold text-heading-foreground">{{ $readiness }}%</div>
                    <div class="mt-1 text-xs text-heading-foreground/60">{{ $hub['readiness_status'] ?? __('Complete your field-service profile first') }}</div>
                </div>
                <div class="rounded-xl bg-heading-foreground/[0.03] p-4">
                    <div class="text-2xs font-semibold uppercase tracking-wide text-heading-foreground/50">@lang('Active services')</div>
                    <div class="mt-2 text-3xl font-semibold text-heading-foreground">{{ count($services) }}</div>
                    <div class="mt-1 truncate text-xs text-heading-foreground/60">{{ implode(', ', array_slice($services, 0, 3)) ?: __('No services configured') }}</div>
                </div>
                <div class="rounded-xl bg-heading-foreground/[0.03] p-4">
                    <div class="text-2xs font-semibold uppercase tracking-wide text-heading-foreground/50">@lang('Service areas')</div>
                    <div class="mt-2 text-3xl font-semibold text-heading-foreground">{{ count($areas) }}</div>
                    <div class="mt-1 truncate text-xs text-heading-foreground/60">{{ implode(', ', array_slice($areas, 0, 3)) ?: __('No areas configured') }}</div>
                </div>
            </div>
        </div>

        <div class="flex flex-col justify-between border-t border-heading-foreground/10 bg-heading-foreground/[0.02] p-7 lg:border-s lg:border-t-0 lg:p-9">
            <div>
                <h3 class="mb-3 text-base font-semibold text-heading-foreground">@lang('Next safest action')</h3>
                @foreach (($hub['recommended_actions'] ?? []) as $action)
                    <div class="mb-3 rounded-xl border border-heading-foreground/10 bg-background p-4 last:mb-0">
                        <div class="text-sm font-semibold text-heading-foreground">{{ $action['title'] }}</div>
                        <div class="mt-1 text-xs leading-5 text-heading-foreground/65">{{ $action['body'] }}</div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6 flex flex-wrap gap-3">
                <x-button
                    href="{{ route('dashboard.user.titan-reach.field-service-profile.edit') }}"
                    variant="ghost-shadow"
                >
                    @lang('Edit profile')
                </x-button>
                @if (!empty($cta['url']))
                    <x-button href="{{ $cta['url'] }}" target="_blank">
                        {{ $cta['label'] }}
                    </x-button>
                @else
                    <x-button href="{{ route('dashboard.user.titan-reach.field-service-profile.edit') }}">
                        {{ $cta['label'] }}
                    </x-button>
                @endif
            </div>
        </div>
    </div>
</x-card>
