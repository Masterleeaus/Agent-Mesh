<?php
declare(strict_types=1);
namespace App\Extensions\TitanReachPro\Tests;
use PHPUnit\Framework\TestCase;
final class TitanZeroClosedLoopIntegrationStaticTest extends TestCase {
    public function test_bridge_uses_real_titan_zero_provider_boundaries(): void {
        $src=file_get_contents(__DIR__.'/../System/Support/TitanZeroClosedLoopBridge.php');
        self::assertStringContainsString('CrmCommandBusGateway',$src);
        self::assertStringContainsString('CrmCompanyContextResolver',$src);
        self::assertStringContainsString('CapacityForecastService',$src);
        self::assertStringContainsString('FieldSignalPort',$src);
        self::assertStringContainsString('MessagingToolGateway',$src);
        self::assertStringContainsString("'crm.lead.create'",$src);
        self::assertStringContainsString("'crm.activity.create'",$src);
        self::assertStringContainsString("'type']='system'",$src);
        self::assertStringNotContainsString("'activity_type'=>'titan_reach_conversion'",$src);
        self::assertStringNotContainsString("dispatchGoverned($companyId,'titan.field.capacity.forecast'",$src);
    }
}
