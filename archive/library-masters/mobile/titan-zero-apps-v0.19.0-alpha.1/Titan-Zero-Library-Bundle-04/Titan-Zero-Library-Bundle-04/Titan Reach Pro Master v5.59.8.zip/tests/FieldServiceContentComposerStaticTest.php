<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldServiceContentComposerStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function testComposerCatalogContainsRequiredFieldServiceTemplatesAndGuardrails(): void
    {
        $catalog = file_get_contents($this->root . '/System/Services/FieldService/FieldServiceContentTemplateCatalog.php');

        foreach ([
            'completed_job',
            'before_after',
            'seasonal_reminder',
            'service_spotlight',
            'neighbourhood_availability',
            'maintenance_tip',
            'review_request',
            'emergency_availability',
            'schedule_opening',
            'recurring_service',
        ] as $template) {
            self::assertStringContainsString("'{$template}'", $catalog);
        }

        foreach (['Do not invent licences', 'exact street addresses', 'customer names', 'vehicle plates', 'emergency availability'] as $guardrail) {
            self::assertStringContainsString($guardrail, $catalog);
        }
    }

    public function testComposerPreviewRouteIsPostAndCsrfProtectedInsideAuthenticatedDashboardGroup(): void
    {
        $provider = file_get_contents($this->root . '/System/TitanReachProServiceProvider.php');

        self::assertStringContainsString("->post('field-service-template/preview'", $provider);
        self::assertStringContainsString("'middleware' => ['web', 'auth']", $provider);
        self::assertStringContainsString('FieldServiceContentTemplateController::class', $provider);
    }

    public function testCreatePostViewIncludesPrivacyAcknowledgementAndComposerVariables(): void
    {
        $view = file_get_contents($this->root . '/resources/views/post/create.blade.php');

        self::assertStringContainsString('field-service content composer', strtolower($view));
        self::assertStringContainsString('fieldServicePrivacyAcknowledged', $view);
        self::assertStringContainsString('applyFieldServiceTemplate', $view);
        self::assertStringContainsString('dashboard.user.titan-reach.field-service-template.preview', $view);
    }

    public function testPostRequestAllowsComposerMetadataWithoutPersistingUnsafeClaims(): void
    {
        $request = file_get_contents($this->root . '/System/Http/Requests/TitanReachPostStoreRequest.php');

        foreach (['field_service_template', 'field_service_service', 'field_service_area', 'field_service_cta', 'field_service_privacy_acknowledged'] as $field) {
            self::assertStringContainsString($field, $request);
        }
    }
}
