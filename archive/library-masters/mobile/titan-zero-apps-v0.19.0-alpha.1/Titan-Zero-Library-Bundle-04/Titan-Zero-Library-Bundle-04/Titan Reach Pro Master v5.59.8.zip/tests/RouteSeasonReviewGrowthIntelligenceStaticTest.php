<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\Tests;

use PHPUnit\Framework\TestCase;

final class RouteSeasonReviewGrowthIntelligenceStaticTest extends TestCase
{
    public function test_step_42_contract_is_present(): void
    {
        $root = dirname(__DIR__);
        self::assertFileExists($root . '/config/titan-reach-growth-intelligence.php');
        self::assertFileExists($root . '/System/Support/TitanReachGrowthIntelligenceBridge.php');
        $provider = file_get_contents($root . '/System/TitanReachProServiceProvider.php');
        self::assertIsString($provider);
        self::assertStringContainsString('titan-reach-growth-intelligence.php', $provider);
    }
}
