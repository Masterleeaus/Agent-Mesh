<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;
use App\Extensions\TitanReachCampaignsPro\System\Support\EndToEndLeadFlowSimulation;

final class EndToEndLeadFlowSimulationStaticTest extends TestCase
{
    public function testLeadFlowSimulationRequiresCompanyCorrelationAndRedactsSensitiveData(): void
    {
        $report = EndToEndLeadFlowSimulation::report(dirname(__DIR__));

        $this->assertTrue($report['ok']);
        $this->assertSame('field_marketing_hub', $report['module_slug']);
        $this->assertTrue($report['simulation']['ok']);
        $this->assertSame(1001, $report['simulation']['company_id']);
        $this->assertSame('REDACTED', $report['simulation']['redacted_input']['customer_name']);
        $this->assertSame('REDACTED', $report['simulation']['redacted_input']['raw_webhook_body']);
        $this->assertContains('field_service.lead_captured', $report['simulation']['events']);
        $this->assertContains('field_service.conversion_recorded', $report['simulation']['events']);
        $this->assertContains('field_service.review_opportunity', $report['simulation']['events']);
    }

    public function testLeadFlowSimulationFailsClosedWithoutCompanyId(): void
    {
        $simulation = EndToEndLeadFlowSimulation::simulate(['company_id' => null]);

        $this->assertFalse($simulation['ok']);
        $this->assertNotEmpty($simulation['failed']);
    }
}
