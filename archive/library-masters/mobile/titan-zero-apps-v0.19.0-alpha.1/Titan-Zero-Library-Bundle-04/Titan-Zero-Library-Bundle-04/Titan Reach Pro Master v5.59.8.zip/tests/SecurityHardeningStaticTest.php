<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class SecurityHardeningStaticTest extends TestCase
{
    private function read(string $path): string
    {
        return file_get_contents(dirname(__DIR__) . '/' . $path) ?: '';
    }

    public function test_webhooks_fail_closed_and_are_not_session_routes(): void
    {
        $facebook = $this->read('System/Http/Controllers/Oauth/FacebookController.php');
        $instagram = $this->read('System/Http/Controllers/Oauth/InstagramController.php');
        $provider = $this->read('System/TitanReachProServiceProvider.php');

        self::assertStringNotContainsString("default-password", $facebook . $instagram . $this->read('System/Enums/PlatformEnum.php'));
        self::assertStringContainsString('Webhook not configured', $facebook . $instagram);
        self::assertStringContainsString('verifyHubSignature', $facebook . $instagram);
        self::assertStringContainsString("'middleware' => ['throttle:60,1']", $provider);
        self::assertStringContainsString("name('titan-reach.oauth.webhook.instagram')", $provider);
        self::assertStringNotContainsString("->any('titan-reach/webhook", $provider);
    }

    public function test_mutating_routes_require_mutating_http_verbs_and_owner_checks(): void
    {
        $provider = $this->read('System/TitanReachProServiceProvider.php');
        $post = $this->read('System/Http/Controllers/TitanReachPostController.php');
        $campaign = $this->read('System/Http/Controllers/TitanReachCampaignController.php');
        $platform = $this->read('System/Http/Controllers/TitanReachPlatformController.php');

        self::assertStringContainsString("->delete('post/{post}'", $provider);
        self::assertStringContainsString("->delete('platforms/{platform}'", $provider);
        self::assertStringContainsString("->delete('campaign/{campaign}'", $provider);
        self::assertStringContainsString("where('user_id', Auth::id())->findOrFail", $post);
        self::assertStringContainsString("abort_unless((int) $post->user_id === (int) Auth::id(), 404)", $post);
        self::assertStringContainsString("abort_unless((int) $campaign->user_id === (int) Auth::id(), 404)", $campaign);
        self::assertStringContainsString("abort_unless((int) $platform->user_id === (int) Auth::id(), 404)", $platform);
    }
}
