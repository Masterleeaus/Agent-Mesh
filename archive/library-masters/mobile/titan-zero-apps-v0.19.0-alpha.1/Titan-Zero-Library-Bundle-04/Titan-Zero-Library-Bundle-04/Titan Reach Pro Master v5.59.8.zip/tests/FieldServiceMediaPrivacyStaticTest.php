<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldServiceMediaPrivacyStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function test_uploaded_job_images_are_sanitized_and_svg_is_blocked(): void
    {
        $controller = file_get_contents($this->root . '/System/Http/Controllers/TitanReachUploadController.php');
        $sanitizer = file_get_contents($this->root . '/System/Services/FieldService/FieldServiceMediaSanitizer.php');

        self::assertStringContainsString('FieldServiceMediaSanitizer', $controller);
        self::assertStringContainsString('mimes:jpeg,png,jpg,webp', $controller);
        self::assertStringNotContainsString('svg', $controller);
        self::assertStringContainsString('imagecreatefromjpeg', $sanitizer);
        self::assertStringContainsString('strip_exif', $sanitizer);
        self::assertStringContainsString('strip_gps', $sanitizer);
    }

    public function test_media_privacy_acknowledgement_and_consent_are_persistable(): void
    {
        $migration = file_get_contents($this->root . '/database/migrations/2026_08_22_000500_add_field_service_media_privacy_to_titan_reach_pro_posts_table.php');
        $model = file_get_contents($this->root . '/System/Models/TitanReachPost.php');
        $request = file_get_contents($this->root . '/System/Http/Requests/TitanReachPostStoreRequest.php');

        self::assertStringContainsString('field_service_media_privacy_acknowledged', $migration);
        self::assertStringContainsString('field_service_media_customer_consent', $migration);
        self::assertStringContainsString('field_service_media_privacy_report', $migration);
        self::assertStringContainsString('field_service_media_privacy_acknowledged', $model);
        self::assertStringContainsString('field_service_media_customer_consent', $request);
    }

    public function test_ai_guardrails_never_identify_customer_or_location_from_media(): void
    {
        $policy = file_get_contents($this->root . '/System/Support/FieldServiceMediaPrivacyPolicy.php');
        $catalog = file_get_contents($this->root . '/System/Services/FieldService/FieldServiceContentTemplateCatalog.php');

        self::assertStringContainsString('allow_ai_to_identify_people', $policy);
        self::assertStringContainsString('allow_ai_to_infer_location', $policy);
        self::assertStringContainsString('customer names', $catalog);
        self::assertStringContainsString('vehicle plates', $catalog);
    }
}
