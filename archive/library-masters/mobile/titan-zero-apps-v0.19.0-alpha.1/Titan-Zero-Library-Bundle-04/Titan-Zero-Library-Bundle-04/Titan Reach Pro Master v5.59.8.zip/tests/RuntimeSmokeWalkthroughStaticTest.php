<?php

declare(strict_types=1);

use App\Extensions\TitanReachPro\System\Support\RuntimeSmokeWalkthrough;
use PHPUnit\Framework\TestCase;

final class RuntimeSmokeWalkthroughStaticTest extends TestCase
{
    public function testSmokeManifestIsRuntimeReady(): void
    {
        $manifest = RuntimeSmokeWalkthrough::manifest();

        self::assertSame('titan-reach', $manifest['extension_key']);
        self::assertSame('field_marketing_hub', $manifest['module_slug']);
        self::assertSame('5.29', $manifest['version']);
        self::assertContains('field_service_marketing.view', [$manifest['permission_required']]);
        self::assertTrue($manifest['company_scoped']);
        self::assertTrue($manifest['standalone_safe']);
        self::assertNotEmpty($manifest['route_names']);
        self::assertNotEmpty($manifest['views']);
    }

    public function testRouteViewControllerAndConfigSmokeDependenciesExist(): void
    {
        $root = dirname(__DIR__);
        $report = RuntimeSmokeWalkthrough::report($root);

        self::assertTrue($report['ok'], json_encode($report, JSON_PRETTY_PRINT));
    }

    public function testProviderRegistersRuntimeSmokeConfigAndRoutes(): void
    {
        $root = dirname(__DIR__);
        $provider = (string) file_get_contents($root . '/System/TitanReachProServiceProvider.php');

        self::assertStringContainsString('field-service-runtime-smoke.php', $provider);
        self::assertStringContainsString('field-service-workspace', $provider);
        foreach (RuntimeSmokeWalkthrough::routePrefixes() as $prefix) {
            self::assertStringContainsString($prefix, $provider);
        }
    }
}
