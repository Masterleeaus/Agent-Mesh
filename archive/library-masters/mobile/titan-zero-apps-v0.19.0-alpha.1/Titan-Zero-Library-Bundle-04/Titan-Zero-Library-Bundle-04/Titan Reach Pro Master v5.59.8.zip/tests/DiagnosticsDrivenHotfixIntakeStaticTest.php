<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support\Tests;

use App\Extensions\TitanReachPro\System\Support\DiagnosticsDrivenHotfixIntake;
use PHPUnit\Framework\TestCase;

final class DiagnosticsDrivenHotfixIntakeStaticTest extends TestCase
{
    public function testIntakeClassifiesMigrationFailureAndRedactsSensitiveFields(): void
    {
        $intake = new DiagnosticsDrivenHotfixIntake(['module_key' => 'field_marketing_hub']);
        $result = $intake->intake([
            'install_id' => 'install-demo-001',
            'package_sha256' => str_repeat('a', 64),
            'failed_stage' => 'database_migration',
            'failure_type' => 'migration',
            'redacted_error_summary' => 'Column already exists during replay.',
            'observed_at' => '2026-08-24T02:28:00+10:00',
            'stack_trace' => 'private trace',
            'token' => 'secret-token',
        ]);

        self::assertSame('hotfix_candidate_ready', $result['status']);
        self::assertSame('migration_database_hotfix', $result['hotfix_target']);
        self::assertSame('[redacted]', $result['redacted_diagnostic']['stack_trace']);
        self::assertSame('[redacted]', $result['redacted_diagnostic']['token']);
        self::assertTrue($result['non_mutating']);
    }
}
