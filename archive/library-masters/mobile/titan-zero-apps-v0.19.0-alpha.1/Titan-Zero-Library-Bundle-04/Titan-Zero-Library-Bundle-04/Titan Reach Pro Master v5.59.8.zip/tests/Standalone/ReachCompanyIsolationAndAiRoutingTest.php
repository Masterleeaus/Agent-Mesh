<?php
$root = dirname(__DIR__, 2);
$fail = static function (string $message): never { fwrite(STDERR, $message."\n"); exit(1); };

$companyContext = @file_get_contents($root.'/System/Support/ReachCompanyContext.php');
if ($companyContext === false) $fail('Missing ReachCompanyContext.');
foreach (['company_id', 'current_company_id'] as $required) if (!str_contains($companyContext, $required)) $fail("Company context missing $required support.");
if (str_contains($companyContext, 'tenant_company_id')) $fail('Canonical company context must not accept tenant_company_id.');

$postController = file_get_contents($root.'/System/Http/Controllers/TitanReachPostController.php');
foreach (['->where(\'company_id\', $companyId)', 'ReachCompanyContext'] as $required) if (!str_contains($postController, $required)) $fail("Post controller missing company isolation marker: $required");

$mainController = file_get_contents($root.'/System/Http/Controllers/TitanReachController.php');
if (substr_count($mainController, '->where(\'company_id\', $companyId)') < 3) $fail('Reach dashboard projections are not consistently company scoped.');

$calendar = file_get_contents($root.'/System/Http/Controllers/TitanReachCalendarController.php');
if (!str_contains($calendar, '->where(\'company_id\', $companyId)')) $fail('Calendar is not company scoped.');

$campaign = file_get_contents($root.'/System/Http/Controllers/TitanReachCampaignController.php');
foreach (['ReachAiClient', '->where(\'company_id\', $companyId)'] as $required) if (!str_contains($campaign, $required)) $fail("Campaign controller missing: $required");
foreach (['AiCompletionService', 'defaultWordModel()', 'Entity::driver'] as $forbidden) if (str_contains($campaign, $forbidden)) $fail("Campaign canonical path still directly selects AI backend: $forbidden");

$common = file_get_contents($root.'/System/Http/Controllers/Common/TitanReachCampaignCommonController.php');
foreach (['ReachAiClient', '->where(\'company_id\', $companyId)'] as $required) if (!str_contains($common, $required)) $fail("Campaign common controller missing: $required");
foreach (['AiCompletionService', 'defaultWordModel()', 'Entity::driver'] as $forbidden) if (str_contains($common, $forbidden)) $fail("Campaign common canonical path still directly selects AI backend: $forbidden");

$publisher = file_get_contents($root.'/System/Console/Commands/PublishedCommand.php');
if (!str_contains($publisher, "->whereNotNull('company_id')")) $fail('Scheduled publisher still executes unscoped legacy posts.');

$ai = @file_get_contents($root.'/System/Services/Ai/ReachAiClient.php');
if ($ai === false) $fail('Missing ReachAiClient.');
if (!str_contains($ai, "titan.ai.chat-provider")) $fail('Reach AI adapter does not prefer canonical host routing.');
if (str_contains($ai, 'AiCompletionService')) $fail('Canonical Reach AI adapter directly imports legacy AI implementation.');

$legacy = @file_get_contents($root.'/System/Compatibility/Ai/LegacyReachAiClient.php');
if ($legacy === false || !str_contains($legacy, 'AiCompletionService')) $fail('Legacy AI fallback is not isolated in compatibility code.');

$video = file_get_contents($root.'/System/Http/Controllers/TitanReachVideoController.php');
foreach (['ReachVideoGenerationClient', 'ReachCompanyContext', '\'_company_\' . $companyId'] as $required) if (!str_contains($video, $required)) $fail("Video controller missing company/backend isolation marker: $required");
foreach (['EntityEnum::VEO_2', 'GoogleVeo2Service', 'Entity::driver'] as $forbidden) if (str_contains($video, $forbidden)) $fail("Video canonical controller still directly selects legacy backend: $forbidden");

$legacyVideo = file_get_contents($root.'/System/Compatibility/Ai/LegacyVeoVideoClient.php');
if (!str_contains($legacyVideo, 'EntityEnum::VEO_2') || !str_contains($legacyVideo, 'GoogleVeo2Service')) $fail('Historical Veo implementation is not isolated in compatibility code.');

echo "PASS Reach company isolation + AI routing\n";
