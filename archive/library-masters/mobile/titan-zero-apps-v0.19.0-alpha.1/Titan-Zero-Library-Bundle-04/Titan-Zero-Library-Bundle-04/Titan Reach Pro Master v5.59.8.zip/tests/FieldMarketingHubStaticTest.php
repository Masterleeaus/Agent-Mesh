<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldMarketingHubStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function testDashboardResolvesSharedFieldServiceContext(): void
    {
        $controller = file_get_contents($this->root . '/System/Http/Controllers/TitanReachController.php');

        self::assertStringContainsString('FieldServiceContextProvider $fieldServiceContextProvider', $controller);
        self::assertStringContainsString('$fieldServiceContextProvider->resolve(userId: auth()->id())', $controller);
        self::assertStringContainsString('FieldMarketingHubSummary $fieldMarketingHubSummary', $controller);
        self::assertStringContainsString("compact('posts', 'platforms', 'posts_stats', 'platforms_published_posts', 'fieldServiceContext', 'fieldMarketingHub')", $controller);
    }

    public function testHubSurfaceUsesFieldServiceLanguageAndSafeActions(): void
    {
        $index = file_get_contents($this->root . '/resources/views/index.blade.php');
        $hub = file_get_contents($this->root . '/resources/views/components/home/field-marketing-hub.blade.php');
        $lanes = file_get_contents($this->root . '/resources/views/components/home/field-service-content-lanes.blade.php');

        self::assertStringContainsString("__('Field Marketing Hub')", $index);
        self::assertStringContainsString('components.home.field-marketing-hub', $index);
        self::assertStringContainsString('Profile readiness', $hub);
        self::assertStringContainsString('The hub will not invent licences, prices, emergency availability or geographic coverage.', $hub);
        self::assertStringContainsString('Field-service content lanes', $lanes);
        self::assertStringContainsString('Guardrail', $lanes);
    }

    public function testSummaryServiceDoesNotInventUnsafeMarketingClaims(): void
    {
        $summary = file_get_contents($this->root . '/System/Services/FieldService/FieldMarketingHubSummary.php');

        self::assertStringContainsString('Add quote or booking link', $summary);
        self::assertStringContainsString('Only use licence, insurance or warranty claims explicitly saved in the profile.', $summary);
        self::assertStringContainsString('Only mention configured service areas.', $summary);
        self::assertStringContainsString('No exact address, customer name, face or vehicle plate.', $summary);
        self::assertStringNotContainsString('emergencyAvailable: true', $summary);
    }
}
