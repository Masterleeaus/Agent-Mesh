<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\Tests;

use App\Extensions\TitanReachPro\System\Support\TitanReachReputationBridge;

final class GoogleBusinessProfileReputationStaticTest
{
    public function testBridgeRequiresCompanyContext(): void
    {
        $bridge = new TitanReachReputationBridge();
        $result = $bridge->summarizeReadiness([]);

        assert($result['ready'] === false);
        assert($result['blocked_by'] === 'missing_company_id');
    }
}
