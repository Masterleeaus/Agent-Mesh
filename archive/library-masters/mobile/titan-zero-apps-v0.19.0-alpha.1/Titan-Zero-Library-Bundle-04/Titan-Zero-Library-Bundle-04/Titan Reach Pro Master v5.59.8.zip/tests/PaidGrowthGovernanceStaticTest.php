<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    'config/titan-reach-paid-growth.php',
    'System/Services/PaidGrowth/PaidGrowthChannelCatalog.php',
    'System/Services/PaidGrowth/PaidGrowthGovernanceService.php',
    'System/Services/PaidGrowth/MetaAdsGovernanceService.php',
    'System/Services/PaidGrowth/GoogleLocalServicesAdsGovernanceService.php',
    'System/Support/TitanReachPaidGrowthBridge.php',
    'System/Http/Controllers/PaidGrowthGovernanceController.php',
];
foreach ($required as $file) {
    if (!is_file($root.'/'.$file)) { fwrite(STDERR, "Missing $file\n"); exit(1); }
}
$code = file_get_contents($root.'/System/Services/PaidGrowth/PaidGrowthGovernanceService.php');
foreach (['automatic_activation_forbidden','automatic_budget_increase_forbidden','company_id_required','daily_budget_exceeds_ceiling','campaign_budget_exceeds_ceiling'] as $token) {
    if (!str_contains($code, $token)) { fwrite(STDERR, "Missing governance token $token\n"); exit(1); }
}
echo "Paid growth governance static gate PASS\n";
