<?php

use PHPUnit\Framework\TestCase;

final class FieldServiceAttributionStaticTest extends TestCase
{
    public function test_attribution_models_services_routes_and_migrations_are_present(): void
    {
        $root = dirname(__DIR__);

        $this->assertFileExists($root . '/System/Models/FieldServiceConversionEvent.php');
        $this->assertFileExists($root . '/System/Services/FieldService/FieldServiceAttributionService.php');
        $this->assertFileExists($root . '/System/Services/FieldService/FieldServiceCampaignObjectiveCatalog.php');
        $this->assertFileExists($root . '/System/Http/Controllers/FieldServiceConversionController.php');
        $this->assertFileExists($root . '/database/migrations/2026_08_22_000600_add_field_service_campaign_attribution.php');

        $provider = file_get_contents($root . '/System/TitanReachProServiceProvider.php');
        $this->assertStringContainsString('field-service-conversion', $provider);
        $this->assertStringContainsString('FieldServiceConversionController::class', $provider);

        $migration = file_get_contents($root . '/database/migrations/2026_08_22_000600_add_field_service_campaign_attribution.php');
        $this->assertStringContainsString('company_id', $migration);
        $this->assertStringContainsString('attribution_key', $migration);
        $this->assertStringContainsString('titan_reach_pro_field_service_conversion_events', $migration);
    }

    public function test_campaign_delete_uses_delete_form_not_get_link(): void
    {
        $view = file_get_contents(dirname(__DIR__) . '/resources/views/campaign/index.blade.php');

        $this->assertStringContainsString("@method('DELETE')", $view);
        $this->assertStringContainsString('@csrf', $view);
        $this->assertStringNotContainsString("href=\"{{ LaravelLocalization::localizeUrl(route('dashboard.user.titan-reach.campaign.destroy'", $view);
    }

    public function test_conversion_metadata_redacts_sensitive_fields(): void
    {
        $service = file_get_contents(dirname(__DIR__) . '/System/Services/FieldService/FieldServiceAttributionService.php');

        foreach (['access_token', 'refresh_token', 'customer_email', 'customer_phone', 'address'] as $field) {
            $this->assertStringContainsString($field, $service);
        }

        $this->assertStringContainsString('[redacted]', $service);
    }
}
