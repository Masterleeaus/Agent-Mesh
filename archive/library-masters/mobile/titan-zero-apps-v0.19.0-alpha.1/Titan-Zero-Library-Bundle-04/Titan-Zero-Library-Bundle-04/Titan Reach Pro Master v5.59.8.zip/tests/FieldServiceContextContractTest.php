<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\Tests;

use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use PHPUnit\Framework\TestCase;

final class FieldServiceContextContractTest extends TestCase
{
    public function testSafeDefaultDoesNotInventOperationalClaims(): void
    {
        $context = FieldServiceContext::safeDefault(123)->toArray();

        self::assertSame(123, $context['company_id']);
        self::assertSame([], $context['services']);
        self::assertSame([], $context['service_areas']);
        self::assertFalse($context['emergency_available']);
        self::assertNull($context['quote_url']);
        self::assertNull($context['booking_url']);
        self::assertSame([], $context['licence_trust_statements']);
        self::assertTrue($context['privacy_defaults']['require_human_review']);
    }

    public function testCompletenessRequiresRealServicesAreasAndContacts(): void
    {
        [$score, $missing] = FieldServiceContext::calculateCompleteness([
            'business_name' => 'Example Plumbing',
            'vertical' => 'Plumbing',
            'services' => [],
            'service_areas' => [],
            'contact_channels' => [],
            'privacy_defaults' => FieldServiceContext::defaultPrivacy(),
        ]);

        self::assertLessThan(100, $score);
        self::assertContains('services', $missing);
        self::assertContains('service_areas', $missing);
        self::assertContains('contact_channels', $missing);
    }
}
