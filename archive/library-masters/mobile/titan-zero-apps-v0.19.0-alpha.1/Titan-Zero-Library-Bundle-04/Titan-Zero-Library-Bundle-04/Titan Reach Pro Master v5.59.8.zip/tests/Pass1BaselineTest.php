<?php
declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class Pass1BaselineTest extends TestCase
{
    public function testManifestIsBomFreeValidJson(): void
    {
        $root = dirname(__DIR__);
        $raw = file_get_contents($root . '/extension.json');
        self::assertNotFalse($raw);
        self::assertFalse(str_starts_with($raw, "\xEF\xBB\xBF"));
        $manifest = json_decode($raw, true, flags: JSON_THROW_ON_ERROR);
        self::assertSame('Titan Reach Pro', $manifest['name']);
        self::assertSame('extension', $manifest['type']);
    }

    public function testServiceProviderExists(): void
    {
        $providers = glob(dirname(__DIR__) . '/System/*ServiceProvider.php');
        self::assertIsArray($providers);
        self::assertNotEmpty($providers);
    }
}
