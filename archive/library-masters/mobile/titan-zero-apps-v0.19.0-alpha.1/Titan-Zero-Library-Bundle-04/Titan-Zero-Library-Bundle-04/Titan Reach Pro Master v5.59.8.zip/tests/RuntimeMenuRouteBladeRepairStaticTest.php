<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;
use App\Extensions\TitanReachPro\System\Support\RuntimeMenuRouteBladeRepair;

final class RuntimeMenuRouteBladeRepairStaticTest extends TestCase
{
    public function test_runtime_repair_manifest_is_company_scoped_and_safe(): void
    {
        $manifest = RuntimeMenuRouteBladeRepair::manifest();
        self::assertSame('field_marketing_hub', $manifest['module_slug']);
        self::assertTrue($manifest['company_scoped']);
        self::assertTrue($manifest['safe_route_resolution']);
        self::assertSame('disabled_link', $manifest['missing_module_mode']);
    }

    public function test_runtime_repair_files_exist(): void
    {
        $root = dirname(__DIR__);
        $checks = RuntimeMenuRouteBladeRepair::filesystemChecks($root);
        foreach ($checks as $check) {
            self::assertTrue($check['ok'], $check['path'] . ' should exist');
        }
    }

    public function test_navigation_disables_missing_routes(): void
    {
        $resolved = RuntimeMenuRouteBladeRepair::resolvedNavigation(['dashboard.user.titan-reach.field-service-workspace']);
        self::assertSame('route', $resolved[0]['mode']);
        self::assertSame('disabled_link', $resolved[1]['mode']);
    }
}
