<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach (['/config/titan-reach-distribution.php','/System/Services/Distribution/UnifiedReachDestination.php','/System/Services/Distribution/UnifiedReachDistributionItem.php','/System/Services/Distribution/UnifiedReachDistributionDecision.php','/System/Services/Distribution/UnifiedReachDestinationCatalog.php','/System/Services/Distribution/UnifiedReachDistributionEngine.php','/System/Services/Distribution/UnifiedReachDistributionBridge.php'] as $path) { if (! is_file($root . $path)) { fwrite(STDERR, "Missing distribution engine file: {$path}\n"); exit(1); } }
$config = require $root . '/config/titan-reach-distribution.php';
foreach (['facebook_page','instagram_business','google_business_profile','meta_ads','google_local_services_ads','nextdoor','gumtree','facebook_marketplace','apple_business_connect','bing_places','directories'] as $channel) { if (! isset($config['destinations'][$channel])) { fwrite(STDERR, "Missing critical distribution channel: {$channel}\n"); exit(1); } }
$engine = file_get_contents($root . '/System/Services/Distribution/UnifiedReachDistributionEngine.php');
foreach (['company_id_required','price_claim_requires_explicit_authorisation','licence_claim_requires_configured_evidence','emergency_claim_requires_configured_availability','budget_or_paid_distribution_requires_owner_approval','assisted_distribution_manual_completion_required'] as $needle) { if (! str_contains($engine, $needle)) { fwrite(STDERR, "Engine missing safety rule: {$needle}\n"); exit(1); } }
$provider = file_get_contents($root . '/System/TitanReachProServiceProvider.php');
foreach (['titan-reach-distribution','titan-reach.distribution.engine','titan-reach.distribution.bridge'] as $needle) { if (! str_contains($provider, $needle)) { fwrite(STDERR, "Provider missing distribution registration: {$needle}\n"); exit(1); } }
echo "Titan Reach Pro distribution engine static gate PASS\n";
