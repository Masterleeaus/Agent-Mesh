<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

class SharedFieldServiceAutomationPresetEmitter
{
    /**
     * Return field-service automation preset intent without coupling this extension
     * to Titan Reach Flow. If the automation extension is installed it may
     * consume this shape; otherwise callers receive a safe local fallback.
     *
     * @return array<string, mixed>
     */
    public function presets(?int $companyId = null, ?int $userId = null): array
    {
        if (app()->bound('titan-reach-flow.field-service.presets')) {
            $builder = app('titan-reach-flow.field-service.presets');
            if (is_object($builder) && method_exists($builder, 'presets')) {
                return $builder->presets($companyId, $userId);
            }
        }

        return [
            'context' => ['company_id' => $companyId, 'standalone_fallback' => true],
            'presets' => [
                'quote_request' => ['label' => 'Quote or price request', 'trigger_keywords' => ['quote', 'price', 'cost']],
                'availability_request' => ['label' => 'Availability or booking request', 'trigger_keywords' => ['available', 'booking']],
                'review_request' => ['label' => 'Positive comment to review', 'trigger_keywords' => ['great', 'thanks']],
                'complaint_handoff' => ['label' => 'Complaint or problem handoff', 'trigger_keywords' => ['complaint', 'problem']],
            ],
            'guardrails' => ['do_not_invent_prices', 'do_not_invent_licences', 'human_review_for_complaints'],
        ];
    }
}
