<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Http\Requests\TitanReachPostStoreRequest;
use App\Extensions\TitanReachPro\System\Http\Requests\TitanReachPostUpdateRequest;
use App\Extensions\TitanReachPro\System\Models\TitanReachCampaign;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use App\Extensions\TitanReachPro\System\Services\Publisher\Contracts\BasePublisherService;
use App\Extensions\TitanReachPro\System\Services\Publisher\PublisherDriver;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceContentTemplateCatalog;
use App\Extensions\TitanReachPro\System\Services\TitanReachShareService;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use App\Models\Company;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TitanReachPostController extends Controller
{
    public function __construct(
        public TitanReachShareService $service,
        private readonly ReachCompanyContext $companyContext,
    ) {}

    public function index(Request $request)
    {
        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        $listOnly = $request->listOnly;
        $filter = $request->filter ?? 'all';
        $sort = $request->sort ?? 'created_at';
        $sortAscDesc = $request->sortAscDesc ?? 'desc';
        $platforms = PlatformEnum::all();

        if ($sort === 'platform') {
            $sort = 'titan_reach_platform_id';
        }

        $posts = TitanReachPost::query()
            ->where('user_id', Auth::id())
            ->where('company_id', $companyId)
            ->orderBy($sort, $sortAscDesc)
            ->paginate(10);

        if ($listOnly) {
            return view('titan-reach::post.index', compact('posts', 'platforms'))->render();
        }

        return view('titan-reach::post.index', compact('posts', 'platforms'));
    }

    public function show(Request $request, string $id)
    {
        $filter = $request->filter ?? 'all';
        $sort = $request->sort ?? 'created_at';
        $sortAscDesc = $request->sortAscDesc ?? 'desc';

        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        $post = TitanReachPost::query()->where('user_id', Auth::id())->where('company_id', $companyId)->findOrFail($id);
        $prev_post_id = TitanReachPost::where('id', '<', $id)
            ->orderBy('id', 'asc')
            ->max('id');
        $next_post_id = TitanReachPost::where('id', '>', $id)
            ->orderBy('id', 'desc')
            ->min('id');

        return view('titan-reach::post.show', compact('post', 'prev_post_id', 'next_post_id'))->render();
    }

    public function create(Request $request)
    {
        $this->service->setRequest($request);

        $currentPlatform = $this->service->setRequest($request)->selectedPlatform();

        $userPlatforms = TitanReachPlatform::query()
            ->where('user_id', Auth::id())
            ->connected()
            ->get();

        $companies = Company::query()->where('user_id', Auth::id())->get();
        $selectedCompanyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        $fieldServiceContext = app(FieldServiceContextProvider::class)->resolve($selectedCompanyId ? (int) $selectedCompanyId : null, Auth::id());
        $fieldServiceTemplates = app(FieldServiceContentTemplateCatalog::class)->options($fieldServiceContext);

        return view('titan-reach::post.create', [
            'companies'              => $companies,
            'campaigns'              => TitanReachCampaign::query()->where('user_id', Auth::id())->where('company_id', $selectedCompanyId)->get(),
            'platforms'              => PlatformEnum::all(),
            'currentPlatform'        => $currentPlatform,
            'userPlatforms'          => $userPlatforms,
            'prefillVideo'           => $request->get('prefill_video'),
            'prefillContent'         => $request->get('prefill_content'),
            'fieldServiceContext'    => $fieldServiceContext,
            'fieldServiceTemplates'  => $fieldServiceTemplates,
        ]);
    }

    public function edit(TitanReachPost $post)
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());
        abort_unless((int) $post->user_id === (int) Auth::id() && (int) $post->company_id === $companyId, 404);
        $userPlatforms = TitanReachPlatform::query()
            ->where('platform', $post->titan_reach_platform)
            ->where('user_id', Auth::id())
            ->connected()
            ->get();

        return view('titan-reach::post.edit', [
            'companies'       => Company::query()->where('user_id', Auth::id())->get(),
            'campaigns'       => TitanReachCampaign::query()->where('user_id', Auth::id())->where('company_id', $companyId)->get(),
            'platforms'       => PlatformEnum::all(),
            'currentPlatform' => $post->titan_reach_platform,
            'editingPost'     => $post,
            'userPlatforms'   => $userPlatforms,
        ]);
    }

    public function duplicate(Request $request, TitanReachPost $post)
    {
        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        abort_unless((int) $post->user_id === (int) Auth::id() && (int) $post->company_id === $companyId, 404);
        $request->validate([
            'platform_id' => ['required', 'integer'],
        ]);

        $targetPlatform = TitanReachPlatform::query()->where('user_id', Auth::id())->findOrFail($request->platform_id);

        $replicate = $post->replicate();

        $replicate->status = 'draft';

        $replicate->titan_reach_platform_id = $targetPlatform->id;

        $replicate->save();

        return response()->json([
            'redirect' => route('dashboard.user.titan-reach.post.edit', $replicate->id),
            'status'   => 'success',
            'message'  => 'Post duplicated successfully',
        ]);
    }

    public function store(TitanReachPostStoreRequest $request): JsonResponse
    {
        if (Helper::appIsDemo()) {
            return response()->json([
                'status'  => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        $validated = $request->validated();
        $validated['company_id'] = $this->companyContext->resolve(isset($validated['company_id']) ? (int) $validated['company_id'] : null, Auth::id());
        $validated['user_id'] = Auth::id();

        $posts = $this->service->storeBulk($validated);

        if ($request->get('post_now')) {
            foreach ($posts as $post) {
                $driver = app(PublisherDriver::class)->setPost($post)
                    ->getDriver();

                if ($driver instanceof BasePublisherService) {
                    $driver->publish();
                }
            }
        }

        return response()->json(['status' => 'success', 'message' => trans('Post created successfully')]);
    }

    public function update(TitanReachPostUpdateRequest $request, TitanReachPost $post): JsonResponse
    {
        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        abort_unless((int) $post->user_id === (int) Auth::id() && (int) $post->company_id === $companyId, 404);
        if (Helper::appIsDemo()) {
            return response()->json([
                'status'  => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        $validated = $request->validated();
        $validated['company_id'] = $companyId;
        $validated['user_id'] = Auth::id();

        $this->service->update($post, $validated);

        if ($request->get('post_now')) {
            app(PublisherDriver::class)->setPost($post)
                ->getDriver()
                ->publish();
        }

        return response()->json(['status' => 'success', 'message' => trans('Post updated successfully')]);
    }

    public function destroy(TitanReachPost $post): RedirectResponse
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());
        if (Helper::appIsDemo()) {
            return back()->with([
                'type'    => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        if ($post->user_id != Auth::id() || (int) $post->company_id !== $companyId) {
            return back()->with([
                'type'    => 'error',
                'message' => trans('You are not authorized to delete this post'),
            ]);
        }

        $post->delete();

        return back()->with([
            'type'    => 'success',
            'message' => trans('Post deleted successfully'),
        ]);
    }
}
