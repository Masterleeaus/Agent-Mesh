<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\LocalPresence;

final class LocalPresenceHealthEngine
{
    public function assess(array $context): array
    {
        if (empty($context['company_id'])) return ['status'=>'blocked','reason'=>'company_id_required'];
        $checks = [
            'business_name' => !empty($context['business_name']),
            'phone' => !empty($context['phone']) || !empty($context['contact_channels']['phone']),
            'website' => !empty($context['website_url']),
            'services' => !empty($context['services']),
            'service_areas' => !empty($context['service_areas']),
            'hours' => !empty($context['hours']),
            'google_business_profile' => !empty($context['presence']['google_business_profile']),
            'apple_business_connect' => !empty($context['presence']['apple_business_connect']),
            'bing_places' => !empty($context['presence']['bing_places']),
            'reviews' => !empty($context['reputation']['review_count']),
            'photos' => !empty($context['presence']['photo_count']),
            'local_landing_pages' => !empty($context['local_landing_pages']),
        ];
        $passed = count(array_filter($checks));
        $score = (int) round(($passed / count($checks)) * 100);
        $gaps=[]; foreach($checks as $k=>$v) if(!$v) $gaps[]=$k;
        return ['status'=>'ok','company_id'=>$context['company_id'],'score'=>$score,'checks'=>$checks,'gaps'=>$gaps,'recommendations'=>$this->recommend($gaps)];
    }
    private function recommend(array $gaps): array
    {
        $map=[
            'google_business_profile'=>'Complete or connect Google Business Profile.',
            'apple_business_connect'=>'Create or verify Apple Business Connect presence.',
            'bing_places'=>'Create or verify Bing Places presence.',
            'reviews'=>'Build a governed review-request flywheel.',
            'photos'=>'Add consent-cleared field-service photos.',
            'local_landing_pages'=>'Create service-area landing pages only for configured coverage.',
            'service_areas'=>'Configure real service areas before local promotion.',
            'services'=>'Configure the actual service catalogue.',
        ];
        $out=[]; foreach($gaps as $g) if(isset($map[$g])) $out[]=$map[$g]; return $out;
    }
}
