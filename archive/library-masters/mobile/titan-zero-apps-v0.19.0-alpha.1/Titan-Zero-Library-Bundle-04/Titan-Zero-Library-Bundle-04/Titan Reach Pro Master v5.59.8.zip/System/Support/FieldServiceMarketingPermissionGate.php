<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use Illuminate\Support\Facades\Gate;

class FieldServiceMarketingPermissionGate
{
    public const PERMISSIONS = [
        'field_service_marketing.view',
        'field_service_marketing.manage_context',
        'field_service_marketing.create_content',
        'field_service_marketing.manage_campaigns',
        'field_service_marketing.manage_automations',
        'field_service_marketing.view_leads',
        'field_service_marketing.publish',
    ];

    public function abilityFor(string $action): string
    {
        return match ($action) {
            'context' => 'field_service_marketing.manage_context',
            'content' => 'field_service_marketing.create_content',
            'campaigns' => 'field_service_marketing.manage_campaigns',
            'titan_reach_campaign_automations' => 'field_service_marketing.manage_automations',
            'leads' => 'field_service_marketing.view_leads',
            'publish' => 'field_service_marketing.publish',
            default => 'field_service_marketing.view',
        };
    }

    public function allows(?object $user, string $action, ?int $companyId = null): bool
    {
        if (! $user) {
            return false;
        }

        $ability = $this->abilityFor($action);

        if (method_exists($user, 'can') && $user->can($ability)) {
            return true;
        }

        if (class_exists(Gate::class) && Gate::forUser($user)->allows($ability, [$companyId])) {
            return true;
        }

        return method_exists($user, 'isAdmin') && (bool) $user->isAdmin();
    }

    public function snapshot(?object $user, ?int $companyId = null): array
    {
        $actions = ['view', 'context', 'content', 'campaigns', 'titan_reach_campaign_automations', 'leads', 'publish'];

        return array_reduce($actions, function (array $carry, string $action) use ($user, $companyId): array {
            $carry[$action] = $this->allows($user, $action, $companyId);

            return $carry;
        }, []);
    }
}
