<?php

namespace App\Extensions\TitanReachPro\System\Models;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Enums\PostTypeEnum;
use App\Extensions\TitanReachPro\System\Enums\StatusEnum;
use App\Extensions\TitanReachAgent\System\Models\TitanReachAgentPost;
use App\Helpers\Classes\MarketplaceHelper;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TitanReachPost extends Model
{
    protected $table = 'titan_reach_pro_posts';

    protected $fillable = [
        'agent_id',
        'titan_reach_agent_post_id',
        'user_id',
        'post_id',
        'company_id',
        'campaign_id',
        'field_service_campaign_objective',
        'attribution_key',
        'attribution_source',
        'conversion_summary',
        'titan_reach_platform_id',
        'titan_reach_platform',
        'post_type',
        'is_personalized_content',
        'tone',
        'content',
        'link',
        'image',
        'images',
        'field_service_media_privacy_acknowledged',
        'field_service_media_customer_consent',
        'field_service_media_privacy_report',
        'video',
        'is_repeated',
        'has_replicate',
        'repeat_period',
        'repeat_start_date',
        'repeat_time',
        'status',
        'scheduled_at',
        'posted_at',
        'hashtags',
        'post_metrics',
        'post_engagement_count',
        'post_engagement_rate',
        'post_metric_at',
    ];

    protected $casts = [
        'titan_reach_platform'      => PlatformEnum::class,
        'post_type'                  => PostTypeEnum::class,
        'has_replicate'              => 'boolean',
        'status'                     => StatusEnum::class,
        'scheduled_at'               => 'datetime',
        'repeat_start_date'          => 'datetime:Y-m-d',
        'posted_at'                  => 'datetime',
        'hashtags'                   => 'json',
        'post_metrics'               => 'json',
        'conversion_summary'        => 'array',
        'images'                     => 'json',
        'field_service_media_privacy_acknowledged' => 'boolean',
        'field_service_media_customer_consent' => 'boolean',
        'field_service_media_privacy_report' => 'array',
        'titan_reach_agent_post_id' => 'integer',
    ];

    protected $appends = [
        'link',
    ];

    public function images(): Attribute
    {
        return Attribute::make(
            get: function ($value) {
                if (is_null($value) || $value === '' || $value === 'null') {
                    return null;
                }

                if (is_string($value)) {
                    $decoded = json_decode($value, true);

                    if (is_array($decoded)) {
                        return $decoded;
                    }

                    return [$value];
                }

                return is_array($value) ? $value : [$value];
            },
            set: function ($value) {
                if (is_null($value)) {
                    return null;
                }

                return is_string($value) ? $value : json_encode($value);
            },
        );
    }

    public function hasMultipleImages(): bool
    {
        return is_array($this->images) && count($this->images) > 1;
    }

    public function getPlatformEnum()
    {
        if ($this->titan_reach_platform) {
            return $this->titan_reach_platform;
        }

        if ($this->platform?->platform) {
            return PlatformEnum::from($this->platform->platform);
        }

        return null;
    }

    public function link(): Attribute
    {
        $status = $this->status;

        $platform = $this->titan_reach_platform;

        if ($status !== StatusEnum::published || is_null($this->post_id)) {
            return Attribute::make(function () {
                return null;
            });
        }

        $link = match ($platform) {
            //            PlatformEnum::facebook  => "https://www.facebook.com/share/p/{$this->post_id}",
            PlatformEnum::x              => "https://x.com/i/web/status/{$this->post_id}",
            PlatformEnum::linkedin       => "https://www.linkedin.com/feed/update/urn:li:activity:{$this->post_id}",
            PlatformEnum::youtube        => "https://www.youtube.com/watch?v={$this->post_id}",
            PlatformEnum::youtube_shorts => "https://www.youtube.com/shorts/{$this->post_id}",
            //            PlatformEnum::instagram => "https://www.instagram.com/p/{$this->post_id}",
            default                 => null,
        };

        return Attribute::make(function () use ($link) {
            return $link;
        });
    }

    public function platform(): BelongsTo
    {
        return $this->belongsTo(TitanReachPlatform::class, 'titan_reach_platform_id', 'id');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(TitanReachSharedLog::class, 'titan_reach_post_id');
    }

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(TitanReachCampaign::class, 'campaign_id');
    }

    public function conversionEvents(): HasMany
    {
        return $this->hasMany(FieldServiceConversionEvent::class, 'post_id');
    }

    public function agent(): BelongsTo
    {
        return $this->belongsTo('App\Extensions\TitanReachAgent\System\Models\TitanReachAgent', 'agent_id');
    }

    public function agentPost(): BelongsTo
    {
        return $this->belongsTo('App\Extensions\TitanReachAgent\System\Models\TitanReachAgentPost', 'titan_reach_agent_post_id');
    }

    public function agentPostPublished(?string $platformPostId = null): void
    {
        if ($this->titan_reach_agent_post_id && MarketplaceHelper::isRegistered('titan-reach-agent')) {
            $agentPost = TitanReachAgentPost::query()
                ->where('id', $this->post->titan_reach_agent_post_id)
                ->first();

            if ($agentPost) {
                $agentPost->markAsPublished($platformPostId);
            }
        }
    }

    public function agentPostFailed(string $errorMessage): void
    {
        if ($this->titan_reach_agent_post_id && MarketplaceHelper::isRegistered('titan-reach-agent')) {
            $agentPost = TitanReachAgentPost::query()
                ->where('id', $this->post->titan_reach_agent_post_id)
                ->first();

            if ($agentPost) {
                $agentPost->markAsFailed($errorMessage);
            }
        }
    }
}
