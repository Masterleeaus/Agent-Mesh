<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\DTO;

final class FieldServiceAreaItem
{
    public function __construct(
        public readonly ?int $id,
        public readonly string $name,
        public readonly ?string $state,
        public readonly ?string $country,
        public readonly bool $active,
        public readonly int $sortOrder,
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            isset($data['id']) ? (int) $data['id'] : null,
            trim((string) ($data['name'] ?? '')),
            isset($data['state']) && $data['state'] !== '' ? trim((string) $data['state']) : null,
            isset($data['country']) && $data['country'] !== '' ? trim((string) $data['country']) : null,
            (bool) ($data['active'] ?? true),
            (int) ($data['sort_order'] ?? $data['sortOrder'] ?? 0),
        );
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'name'       => $this->name,
            'state'      => $this->state,
            'country'    => $this->country,
            'active'     => $this->active,
            'sort_order' => $this->sortOrder,
        ];
    }
}
