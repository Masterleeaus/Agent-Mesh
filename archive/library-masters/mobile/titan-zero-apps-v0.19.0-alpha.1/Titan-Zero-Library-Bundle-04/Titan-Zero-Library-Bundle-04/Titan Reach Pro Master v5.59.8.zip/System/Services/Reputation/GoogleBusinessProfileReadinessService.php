<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Reputation;

final class GoogleBusinessProfileReadinessService
{
    /** @param array<string,mixed> $context @return array<string,mixed> */
    public function evaluate(array $context): array
    {
        if (empty($context['company_id'])) {
            return ['ready' => false, 'blocked_by' => 'missing_company_id'];
        }

        $missing = [];
        foreach (['business_name', 'services', 'service_areas'] as $field) {
            if (empty($context[$field])) {
                $missing[] = $field;
            }
        }

        return [
            'ready' => $missing === [],
            'blocked_by' => $missing === [] ? null : 'incomplete_field_service_context',
            'missing' => $missing,
            'capabilities' => ['posts', 'photos', 'reviews', 'review_replies', 'performance_signals'],
            'approval_required' => ['review_replies', 'claim_changes', 'paid_promotions'],
        ];
    }
}
