<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\Traits;

use App\Models\SettingTwo;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use InvalidArgumentException;

trait HasSaveImage
{
    public static function downloadImageToStorage($url = null, $filename = null)
    {
        if (! is_string($url) || trim($url) === '') {
            return null;
        }

        $url = trim($url);
        $parts = parse_url($url);
        if (! is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])) {
            throw new InvalidArgumentException('Remote image URL must use HTTPS.');
        }

        $host = strtolower(rtrim((string) $parts['host'], '.'));
        if ($host === 'localhost' || str_ends_with($host, '.localhost')) {
            throw new InvalidArgumentException('Local image hosts are not permitted.');
        }

        $records = dns_get_record($host, DNS_A | DNS_AAAA) ?: [];
        if ($records === []) {
            throw new InvalidArgumentException('Remote image host could not be resolved.');
        }
        foreach ($records as $record) {
            $ip = $record['ip'] ?? $record['ipv6'] ?? null;
            if (! is_string($ip) || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
                throw new InvalidArgumentException('Private or reserved image hosts are not permitted.');
            }
        }

        $response = Http::timeout(15)
            ->connectTimeout(5)
            ->withOptions(['allow_redirects' => false])
            ->get($url);

        if (! $response->successful()) {
            return null;
        }

        $contentType = strtolower((string) $response->header('Content-Type'));
        if (! str_starts_with($contentType, 'image/')) {
            throw new InvalidArgumentException('Remote resource is not an image.');
        }

        $fileContent = $response->body();
        if (strlen($fileContent) > 15 * 1024 * 1024) {
            throw new InvalidArgumentException('Remote image exceeds the 15 MiB limit.');
        }

        $filename = uniqid('image_', true) . '.jpg';
        $imageStorage = SettingTwo::getCache()?->ai_image_storage;

        if ($imageStorage === 'r2') {
            Storage::disk('r2')->put($filename, $fileContent);
            return Storage::disk('r2')->url($filename);
        }
        if ($imageStorage === 's3') {
            Storage::disk('s3')->put($filename, $fileContent);
            return Storage::disk('s3')->url($filename);
        }

        Storage::disk('thumbs')->put($filename, $fileContent);
        return Storage::disk('public')->put($filename, $fileContent)
            ? '/uploads/' . $filename
            : 'error';
    }
}
