<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceMediaSanitizer;
use App\Extensions\TitanReachPro\System\Support\FieldServiceMediaPrivacyPolicy;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use RuntimeException;

class TitanReachUploadController extends Controller
{
    public function __construct(
        private readonly FieldServiceMediaSanitizer $mediaSanitizer,
        private readonly FieldServiceContextProvider $fieldServiceContextProvider,
    ) {}

    public function image(Request $request): JsonResponse
    {
        //        if (Helper::appIsDemo()) {
        //            return response()->json([
        //                'type'    => 'error',
        //                'message' => trans('This feature is disabled in demo mode.'),
        //            ], 400);
        //        }

        $request->validate([
            'upload_image' => 'required|image|mimes:jpeg,png,jpg,webp|max:8192',
            'company_id'   => 'sometimes|nullable|integer',
            'field_service_media_privacy_acknowledged' => 'sometimes|accepted',
            'field_service_media_customer_consent'     => 'sometimes|boolean',
        ]);

        $companyId = $request->integer('company_id') ?: null;
        $context = $this->fieldServiceContextProvider->forCompany($companyId, Auth::id());
        $policy = FieldServiceMediaPrivacyPolicy::fromContext($context);

        if (FieldServiceMediaPrivacyPolicy::acknowledgementRequiredFor($context)
            && ! $request->boolean('field_service_media_privacy_acknowledged')) {
            return response()->json([
                'type'    => 'error',
                'message' => trans('Confirm the field-service media privacy check before uploading job-site images.'),
            ], 422);
        }

        try {
            $result = $this->mediaSanitizer->storeSanitizedImage($request->file('upload_image'), $companyId, $policy);
        } catch (RuntimeException $exception) {
            return response()->json([
                'type'    => 'error',
                'message' => $exception->getMessage(),
            ], 422);
        }

        return response()->json([
            'image_path'     => $result['path'],
            'url'            => $result['url'],
            'privacy_report' => [
                'metadata_stripped' => $result['metadata_stripped'],
                'gps_stripped'      => $result['gps_stripped'],
                'policy'            => $result['privacy_policy'],
            ],
        ]);
    }

    public function video(Request $request): JsonResponse
    {
        if (Helper::appIsDemo()) {
            return response()->json([
                'type'    => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ], 400);
        }

        $request->validate(['upload_video' => 'required']);

        $path = $request->file('upload_video')?->store('titan-reach', 'public');

        return response()->json([
            'video_path' => '/uploads/' . $path,
            'url'        => url('uploads/' . $path),
        ]);
    }
}
