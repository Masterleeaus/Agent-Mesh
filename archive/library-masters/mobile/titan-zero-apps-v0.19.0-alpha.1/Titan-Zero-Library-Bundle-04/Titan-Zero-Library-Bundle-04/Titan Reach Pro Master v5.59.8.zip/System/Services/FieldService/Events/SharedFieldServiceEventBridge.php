<?php

namespace App\Extensions\TitanReachPro\System\Services\FieldService\Events;

use Throwable;

class SharedFieldServiceEventBridge
{
    /** @param array<string, mixed> $payload @param array<string, mixed> $metadata @return array<string, mixed> */
    public function emit(string $eventType, int|string|null $companyId, array $payload = [], array $metadata = []): array
    {
        if ((string) ($companyId ?? '') === '') {
            return ['status' => 'rejected', 'reason' => 'missing_company_id', 'event_type' => $eventType];
        }

        if (! FieldServiceEventCatalog::isKnown($eventType)) {
            return ['status' => 'rejected', 'reason' => 'unknown_event_type', 'event_type' => $eventType];
        }

        // Prefer the Field Marketing Hub event bus when it is installed; this keeps Titan Reach Pro
        // as the coordination authority without coupling consumers to its database tables.
        if (class_exists('App\Extensions\TitanReachPro\System\Services\FieldService\Events\FieldServiceEventBus')) {
            try {
                $bus = app('App\Extensions\TitanReachPro\System\Services\FieldService\Events\FieldServiceEventBus');
                return $bus->publishArray($eventType, $companyId, 'titan-reach-pro', $payload, $metadata);
            } catch (Throwable $exception) {
                // Fall through to local standalone handling.
            }
        }

        $local = new FieldServiceEventBus();
        return $local->publishArray($eventType, $companyId, 'titan-reach-pro', $payload, $metadata);
    }
}
