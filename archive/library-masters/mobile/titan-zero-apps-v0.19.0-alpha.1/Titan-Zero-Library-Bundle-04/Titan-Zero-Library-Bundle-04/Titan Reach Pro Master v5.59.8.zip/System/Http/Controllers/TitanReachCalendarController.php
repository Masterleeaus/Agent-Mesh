<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use App\Helpers\Classes\Helper;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class TitanReachCalendarController extends Controller
{
    public function __invoke(ReachCompanyContext $companyContext)
    {
        $companyId = $companyContext->resolve(userId: Auth::id());
        $appIsNotDemo = Helper::appIsNotDemo();
        $items = TitanReachPost::query()
            ->where('user_id', Auth::id())
            ->where('company_id', $companyId)
            ->when($appIsNotDemo, function ($query) {
                $query->whereBetween('scheduled_at', [
                    now()->startOfMonth()->toDateString(),
                    now()->endOfMonth()->toDateString(),
                ]);
            })
            ->get();

        if (! $appIsNotDemo) {
            $day = 1;
            $daysInMonth = now()->daysInMonth;

            foreach ($items as $item) {
                $item->scheduled_at = now()->startOfMonth()
                    ->addDays(($day % $daysInMonth))
                    ->setTime(12, 0, 0);

                $item->posted_at = $item->scheduled_at->copy()->addHour();

                $day++;
            }
        }

        return view('titan-reach::calendar', [
            'items' => $items,
        ]);
    }
}
