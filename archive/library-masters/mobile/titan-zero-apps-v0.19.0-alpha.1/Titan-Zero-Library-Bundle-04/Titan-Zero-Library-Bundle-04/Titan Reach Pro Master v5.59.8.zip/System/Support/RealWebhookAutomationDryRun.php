<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

/**
 * Deterministic dry-run harness for webhook and automation execution paths.
 *
 * This class intentionally performs no network calls and sends no provider messages.
 * It is safe for installer/runtime probes because it only classifies a supplied payload
 * and returns the decisions that a real webhook processor should make.
 */
final class RealWebhookAutomationDryRun
{
    /** @var array<int, string> */
    private array $sensitiveKeys = [
        'token', 'access_token', 'refresh_token', 'secret', 'signature', 'authorization',
        'customer_name', 'customer_handle', 'customer_external_id', 'contact_value',
        'raw_body', 'body', 'message', 'comment_text', 'text', 'email', 'phone',
    ];

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function simulate(array $payload): array
    {
        $companyId = $payload['company_id'] ?? null;
        $platform = strtolower((string) ($payload['platform'] ?? 'unknown'));
        $event = strtolower((string) ($payload['event'] ?? 'comment'));
        $signatureVerified = (bool) ($payload['signature_verified'] ?? false);
        $replayFresh = (bool) ($payload['replay_fresh'] ?? false);
        $dryRun = (bool) ($payload['dry_run'] ?? true);

        $failures = [];
        if ($companyId === null || $companyId === '' || $companyId === 0) {
            $failures[] = 'missing_company_id';
        }
        if (!$signatureVerified) {
            $failures[] = 'unsigned_or_unverified_webhook';
        }
        if (!$replayFresh) {
            $failures[] = 'replay_or_stale_webhook';
        }
        if (!$dryRun) {
            $failures[] = 'dry_run_required_for_probe';
        }

        $matchedTrigger = $this->matchTrigger((string) ($payload['message'] ?? $payload['comment_text'] ?? ''));
        $wouldCaptureLead = $matchedTrigger !== 'none' && $failures === [];

        return [
            'status' => $failures === [] ? 'dry_run_passed' : 'dry_run_blocked',
            'extension' => 'Field Marketing Hub',
            'company_id' => $companyId,
            'platform' => $platform,
            'event' => $event,
            'trigger' => $matchedTrigger,
            'would_capture_lead' => $wouldCaptureLead,
            'would_send_provider_message' => false,
            'would_publish_content' => false,
            'would_record_attribution' => $wouldCaptureLead,
            'would_emit_event' => $wouldCaptureLead,
            'failures' => $failures,
            'redacted_payload' => $this->redact($payload),
        ];
    }

    public function matchTrigger(string $message): string
    {
        $message = strtolower($message);
        if (str_contains($message, 'quote') || str_contains($message, 'price') || str_contains($message, 'cost')) {
            return 'quote_request';
        }
        if (str_contains($message, 'book') || str_contains($message, 'available') || str_contains($message, 'availability')) {
            return 'booking_request';
        }
        if (str_contains($message, 'emergency') || str_contains($message, 'urgent')) {
            return 'emergency_handoff';
        }
        if (str_contains($message, 'review') || str_contains($message, 'thanks') || str_contains($message, 'great job')) {
            return 'review_opportunity';
        }
        if (str_contains($message, 'complaint') || str_contains($message, 'problem') || str_contains($message, 'not happy')) {
            return 'complaint_handoff';
        }

        return 'none';
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function redact(array $payload): array
    {
        $redacted = [];
        foreach ($payload as $key => $value) {
            $lower = strtolower((string) $key);
            if (in_array($lower, $this->sensitiveKeys, true) || str_contains($lower, 'token') || str_contains($lower, 'secret') || str_contains($lower, 'signature')) {
                $redacted[$key] = '[redacted]';
                continue;
            }
            if (is_array($value)) {
                $redacted[$key] = $this->redact($value);
                continue;
            }
            $redacted[$key] = $value;
        }

        return $redacted;
    }

    /**
     * @return array<string, mixed>
     */
    public function checklist(): array
    {
        return [
            'step' => 28,
            'extension' => 'Field Marketing Hub',
            'dry_run_only' => true,
            'requires_company_id' => true,
            'requires_signature_verification' => true,
            'requires_replay_protection' => true,
            'sends_provider_messages' => false,
            'publishes_content' => false,
            'covered_flow' => [
                'webhook_received',
                'signature_verified',
                'replay_checked',
                'automation_trigger_matched',
                'social_lead_capture_decision',
                'attribution_event_decision',
                'workspace_visibility_decision',
            ],
        ];
    }
}
