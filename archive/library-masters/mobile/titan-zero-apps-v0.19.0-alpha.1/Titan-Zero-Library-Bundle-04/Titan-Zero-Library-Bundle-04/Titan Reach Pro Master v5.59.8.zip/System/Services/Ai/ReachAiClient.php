<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Ai;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/**
 * Provider-local adapter to Titan's canonical intelligence route.
 *
 * Reach does not select a model/vendor here. The host binding owns backend choice.
 * A compatibility fallback may be registered separately for legacy installations.
 */
final class ReachAiClient
{
    public const HOST_PROVIDER_BINDING = 'titan.ai.chat-provider';
    public const LEGACY_FALLBACK_BINDING = 'titan-reach-pro.ai.legacy-fallback';

    public function __construct(private readonly Container $container) {}

    public function complete(string $systemPrompt, string $userPrompt, array $context = []): string
    {
        $messages = [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user', 'content' => $userPrompt],
        ];

        return $this->completeMessages($messages, $context);
    }

    public function completeUserOnly(string $userPrompt, array $context = []): string
    {
        return $this->completeMessages([
            ['role' => 'user', 'content' => $userPrompt],
        ], $context);
    }

    private function completeMessages(array $messages, array $context): string
    {
        if ($this->container->bound(self::HOST_PROVIDER_BINDING)) {
            try {
                $result = $this->invoke($this->container->make(self::HOST_PROVIDER_BINDING), $messages, $context);
                $content = $this->content($result);
                if ($content !== null) {
                    return $content;
                }
            } catch (Throwable) {
                // Preserve legacy installations through the explicit compatibility path below.
            }
        }

        if ($this->container->bound(self::LEGACY_FALLBACK_BINDING)) {
            $fallback = $this->container->make(self::LEGACY_FALLBACK_BINDING);
            if ($fallback instanceof LegacyReachAiFallback) {
                return $fallback->completeMessages($messages, $context);
            }
        }

        throw new RuntimeException('No governed Titan AI route is available for Reach content generation.');
    }

    private function invoke(mixed $provider, array $messages, array $context): mixed
    {
        if (is_object($provider) && method_exists($provider, 'complete')) {
            return $provider->complete($messages, ['context' => $context, 'capability_id' => 'reach.content.generate']);
        }

        if (is_callable($provider)) {
            return $provider($messages, ['context' => $context, 'capability_id' => 'reach.content.generate']);
        }

        throw new RuntimeException('The configured Titan AI route does not expose a supported completion contract.');
    }

    private function content(mixed $result): ?string
    {
        if (is_string($result) && $result !== '') {
            return $result;
        }

        if (is_array($result)) {
            foreach (['content', 'text', 'output'] as $key) {
                if (isset($result[$key]) && is_string($result[$key]) && $result[$key] !== '') {
                    return $result[$key];
                }
            }
        }

        if (is_object($result)) {
            if (isset($result->success) && $result->success === false) {
                return null;
            }
            foreach (['content', 'text', 'output'] as $key) {
                if (isset($result->{$key}) && is_string($result->{$key}) && $result->{$key} !== '') {
                    return $result->{$key};
                }
            }
        }

        return null;
    }
}
