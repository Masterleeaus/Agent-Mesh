<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDistributionDecision
{
    public function __construct(public readonly string $destination, public readonly string $status, public readonly array $reasons, public readonly bool $approvalRequired, public readonly bool $assisted, public readonly bool $paid) {}
    public function toArray(): array { return ['destination' => $this->destination, 'status' => $this->status, 'reasons' => $this->reasons, 'approval_required' => $this->approvalRequired, 'assisted' => $this->assisted, 'paid' => $this->paid]; }
}
