<?php

namespace App\Extensions\TitanReachPro\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FieldServiceConversionEvent extends Model
{
    protected $table = 'titan_reach_pro_field_service_conversion_events';

    protected $fillable = [
        'company_id',
        'user_id',
        'campaign_id',
        'post_id',
        'attribution_key',
        'event_type',
        'source',
        'value',
        'currency',
        'dedupe_key',
        'metadata',
        'occurred_at',
    ];

    protected $casts = [
        'metadata' => 'array',
        'occurred_at' => 'datetime',
        'value' => 'decimal:2',
    ];

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(TitanReachCampaign::class, 'campaign_id');
    }

    public function post(): BelongsTo
    {
        return $this->belongsTo(TitanReachPost::class, 'post_id');
    }
}
