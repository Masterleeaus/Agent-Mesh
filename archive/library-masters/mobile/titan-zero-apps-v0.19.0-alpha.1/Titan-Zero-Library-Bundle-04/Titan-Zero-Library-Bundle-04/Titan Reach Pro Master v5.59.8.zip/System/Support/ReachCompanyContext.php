<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use App\Models\Company;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Auth\Authenticatable;

final class ReachCompanyContext
{
    public function resolve(?int $requestedCompanyId = null, ?int $userId = null): int
    {
        $user = auth()->user();
        $userId ??= $user?->getAuthIdentifier();

        if (! $userId) {
            throw new AuthorizationException('A company-scoped Reach operation requires an authenticated user.');
        }

        $activeCompanyId = $this->activeCompanyId($user);

        if ($requestedCompanyId !== null && $requestedCompanyId > 0) {
            if ($activeCompanyId !== null && $activeCompanyId !== $requestedCompanyId) {
                throw new AuthorizationException('Requested company does not match the active company context.');
            }

            if ($activeCompanyId === $requestedCompanyId || $this->userOwnsCompany((int) $userId, $requestedCompanyId)) {
                return $requestedCompanyId;
            }

            throw new AuthorizationException('Requested company is not available to the authenticated user.');
        }

        if ($activeCompanyId !== null) {
            return $activeCompanyId;
        }

        $owned = Company::query()
            ->where('user_id', $userId)
            ->orderBy('id')
            ->limit(2)
            ->pluck('id')
            ->map(static fn ($id) => (int) $id)
            ->all();

        if (count($owned) === 1) {
            return $owned[0];
        }

        throw new AuthorizationException('Reach requires an unambiguous company_id context.');
    }

    private function activeCompanyId(?Authenticatable $user): ?int
    {
        if (! $user) {
            return null;
        }

        foreach (['company_id', 'current_company_id'] as $field) {
            $value = $user->{$field} ?? null;
            if (is_numeric($value) && (int) $value > 0) {
                return (int) $value;
            }
        }

        return null;
    }

    private function userOwnsCompany(int $userId, int $companyId): bool
    {
        return Company::query()
            ->whereKey($companyId)
            ->where('user_id', $userId)
            ->exists();
    }
}
