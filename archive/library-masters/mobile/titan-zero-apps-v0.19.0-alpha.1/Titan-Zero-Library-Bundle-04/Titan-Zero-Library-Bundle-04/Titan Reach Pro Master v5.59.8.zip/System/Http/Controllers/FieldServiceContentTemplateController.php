<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceContentTemplateCatalog;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FieldServiceContentTemplateController extends Controller
{
    public function preview(
        Request $request,
        FieldServiceContextProvider $contextProvider,
        FieldServiceContentTemplateCatalog $catalog,
    ): JsonResponse {
        $data = $request->validate([
            'company_id' => ['sometimes', 'nullable', 'integer'],
            'template' => ['required', 'string', 'max:80'],
            'service' => ['sometimes', 'nullable', 'string', 'max:160'],
            'service_area' => ['sometimes', 'nullable', 'string', 'max:160'],
            'cta' => ['sometimes', 'nullable', 'in:quote,booking,review,contact'],
        ]);

        $context = $contextProvider->resolve($data['company_id'] ?? null, Auth::id());
        $rendered = $catalog->render(
            (string) $data['template'],
            $context,
            $data['service'] ?? null,
            $data['service_area'] ?? null,
            $data['cta'] ?? 'quote',
        );

        return response()->json([
            'status' => ($rendered['disabled'] ?? false) ? 'disabled' : 'success',
            'content' => $rendered['content'],
            'guardrails' => $rendered['guardrails'],
            'privacy_level' => $rendered['privacy_level'] ?? null,
            'reason' => $rendered['reason'] ?? null,
        ]);
    }
}
