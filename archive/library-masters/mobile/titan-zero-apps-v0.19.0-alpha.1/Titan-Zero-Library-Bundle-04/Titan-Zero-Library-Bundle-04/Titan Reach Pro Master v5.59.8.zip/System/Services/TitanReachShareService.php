<?php

namespace App\Extensions\TitanReachPro\System\Services;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use Exception;
use Illuminate\Http\Request;

class TitanReachShareService
{
    public Request $request;

    public PlatformEnum $platform;

    public function storeBulk($data)
    {
        $selectedUserPlatforms = $data['selectedUserPlatforms'];

        $posts = [];

        foreach ($selectedUserPlatforms as $selectedUserPlatform) {
            $created = array_merge($data, [
                'titan_reach_platform_id' => $selectedUserPlatform,
            ]);

            $posts[] = TitanReachPost::query()->create($created)->getKey();
        }

        return TitanReachPost::query()->whereIn('id', $posts)->get();
    }

    public function store($data)
    {
        return TitanReachPost::query()->create($data);
    }

    public function update(TitanReachPost $post, array $data): void
    {
        $post->update($data);
    }

    public function selectedPlatform(): PlatformEnum
    {
        try {
            if ($this->request->get('platform') && in_array($this->request->get('platform'), PlatformEnum::toArray(), true)) {
                return PlatformEnum::from($this->request->get('platform'));
            }

            return PlatformEnum::facebook;
        } catch (Exception $e) {
            return PlatformEnum::facebook;
        }
    }

    public function setRequest(Request $request): self
    {
        $this->request = $request;

        return $this;
    }

    public function setPlatform(TitanReachPlatform $platform): self
    {
        $this->platform = $platform;

        return $this;
    }
}
