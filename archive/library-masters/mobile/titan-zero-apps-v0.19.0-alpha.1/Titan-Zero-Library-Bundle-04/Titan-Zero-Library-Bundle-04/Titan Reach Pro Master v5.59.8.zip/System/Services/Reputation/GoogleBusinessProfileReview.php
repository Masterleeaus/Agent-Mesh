<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Reputation;

final class GoogleBusinessProfileReview
{
    public function __construct(
        public readonly string $reviewId,
        public readonly int $rating,
        public readonly bool $requiresHumanReview,
        public readonly array $riskFlags = [],
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'review_id' => $this->reviewId,
            'rating' => $this->rating,
            'requires_human_review' => $this->requiresHumanReview,
            'risk_flags' => $this->riskFlags,
        ];
    }
}
