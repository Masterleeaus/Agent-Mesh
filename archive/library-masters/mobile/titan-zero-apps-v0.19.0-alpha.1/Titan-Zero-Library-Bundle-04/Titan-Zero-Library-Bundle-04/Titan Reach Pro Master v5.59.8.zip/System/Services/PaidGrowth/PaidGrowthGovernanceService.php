<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\PaidGrowth;

final class PaidGrowthGovernanceService
{
    public function __construct(private readonly PaidGrowthChannelCatalog $channels) {}

    public function evaluate(array $input): PaidGrowthDecision
    {
        $reasons = [];
        $requirements = [];
        $channel = (string)($input['channel'] ?? '');
        $definition = $this->channels->get($channel);
        $companyId = (int)($input['company_id'] ?? 0);

        if ($companyId <= 0) $reasons[] = 'company_id_required';
        if (! $definition) $reasons[] = 'unsupported_paid_channel';
        if ($definition) {
            foreach ($definition['requires'] as $requirement) {
                if (! $this->truthy($input[$requirement] ?? false)) $requirements[] = $requirement;
            }
        }

        $daily = max(0, (int)($input['daily_budget_minor'] ?? 0));
        $campaign = max(0, (int)($input['campaign_budget_minor'] ?? 0));
        $dailyCeiling = max(0, (int)($input['daily_budget_ceiling_minor'] ?? 0));
        $campaignCeiling = max(0, (int)($input['campaign_budget_ceiling_minor'] ?? 0));
        if ($daily <= 0 || $campaign <= 0) $requirements[] = 'budget_ceiling';
        if ($dailyCeiling <= 0 || $campaignCeiling <= 0) $requirements[] = 'budget_ceiling';
        if ($dailyCeiling > 0 && $daily > $dailyCeiling) $reasons[] = 'daily_budget_exceeds_ceiling';
        if ($campaignCeiling > 0 && $campaign > $campaignCeiling) $reasons[] = 'campaign_budget_exceeds_ceiling';
        if (($input['automatic_activation'] ?? false) === true) $reasons[] = 'automatic_activation_forbidden';
        if (($input['automatic_budget_increase'] ?? false) === true) $reasons[] = 'automatic_budget_increase_forbidden';
        if (($input['claims_unverified_licence'] ?? false) === true) $reasons[] = 'unverified_licence_claim';
        if (($input['claims_unapproved_price'] ?? false) === true) $reasons[] = 'unapproved_price_claim';
        if (($input['claims_unconfigured_emergency'] ?? false) === true) $reasons[] = 'unconfigured_emergency_claim';
        if (($input['claims_outside_service_area'] ?? false) === true) $reasons[] = 'outside_service_area_claim';

        $requirements = array_values(array_unique($requirements));
        $reasons = array_values(array_unique($reasons));
        $ready = $companyId > 0 && $definition && !$reasons && !$requirements;
        $state = $ready ? 'approval_ready' : 'blocked';

        return new PaidGrowthDecision(
            $ready,
            $state,
            $reasons,
            $requirements,
            $this->sanitize($input),
        );
    }

    private function truthy(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOL) || $value === 1 || $value === '1';
    }

    private function sanitize(array $input): array
    {
        $deny = ['token','access_token','secret','signature','customer_name','customer_email','customer_phone','raw_payload','authorization'];
        foreach ($deny as $key) unset($input[$key]);
        $input['automatic_activation'] = false;
        $input['automatic_budget_increase'] = false;
        return $input;
    }
}
