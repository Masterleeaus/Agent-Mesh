<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

final class LiveInstallerDiagnostics
{
    /**
     * Build a redacted diagnostic summary suitable for installer failure reports.
     *
     * @param array<string, mixed> $diagnostic
     * @return array<string, mixed>
     */
    public static function summarize(array $diagnostic): array
    {
        return [
            'module' => config('field-service-live-installer-diagnostics.' . self::class . '.module', 'Field Marketing Hub'),
            'phase' => 'phase_3_step_25',
            'stage' => self::stringValue($diagnostic['stage'] ?? 'unknown'),
            'status' => self::stringValue($diagnostic['status'] ?? 'unknown'),
            'install_id' => self::stringValue($diagnostic['install_id'] ?? 'unknown'),
            'installer_build' => self::stringValue($diagnostic['installer_build'] ?? 'unknown'),
            'php_version' => self::stringValue($diagnostic['php_version'] ?? PHP_VERSION),
            'package_sha256' => self::stringValue($diagnostic['package_sha256'] ?? 'unknown'),
            'checks' => self::normalizeChecks($diagnostic['checks'] ?? []),
            'events' => self::redact($diagnostic['events'] ?? []),
            'next_action' => self::classifyNextAction($diagnostic),
        ];
    }

    /**
     * @return list<string>
     */
    public static function requiredChecks(): array
    {
        return [
            'extension_json_parseable',
            'service_provider_loadable',
            'config_registered',
            'migrations_discoverable',
            'routes_discoverable',
            'views_discoverable',
            'support_classes_autoloadable',
            'company_id_runtime_context_available',
        ];
    }

    /**
     * @param array<string, mixed> $diagnostic
     */
    public static function classifyNextAction(array $diagnostic): string
    {
        $stage = strtolower(self::stringValue($diagnostic['stage'] ?? ''));
        $message = strtolower(self::stringValue($diagnostic['message'] ?? ''));

        if (str_contains($message, 'manifest') || str_contains($stage, 'validat')) {
            return 'check_manifest_shape_and_installer_build';
        }

        if (str_contains($message, 'class') || str_contains($message, 'autoload')) {
            return 'refresh_autoload_and_verify_namespace_paths';
        }

        if (str_contains($message, 'migration') || str_contains($stage, 'migrat')) {
            return 'inspect_migration_order_and_duplicate_table_guards';
        }

        if (str_contains($message, 'view') || str_contains($message, 'blade')) {
            return 'verify_view_namespace_and_installed_resources';
        }

        if (str_contains($message, 'route')) {
            return 'inspect_route_prefixes_names_and_method_collisions';
        }

        return 'collect_live_log_and_retry_after_targeted_hotfix';
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    public static function redact($value)
    {
        if (is_array($value)) {
            $redacted = [];
            foreach ($value as $key => $item) {
                $keyString = is_string($key) ? strtolower($key) : (string) $key;
                if (self::isSensitiveKey($keyString)) {
                    $redacted[$key] = '[redacted]';
                    continue;
                }
                $redacted[$key] = self::redact($item);
            }
            return $redacted;
        }

        if (is_string($value) && strlen($value) > 240) {
            return substr($value, 0, 120) . '…[truncated]';
        }

        return $value;
    }

    private static function isSensitiveKey(string $key): bool
    {
        foreach ([
            'token', 'access_token', 'refresh_token', 'secret', 'password', 'authorization',
            'signature', 'webhook_secret', 'api_key', 'client_secret', 'customer_name',
            'customer_handle', 'contact_value', 'raw_body', 'payload', 'message_body',
        ] as $needle) {
            if (str_contains($key, $needle)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param mixed $checks
     * @return array<string, string>
     */
    private static function normalizeChecks($checks): array
    {
        $normalized = [];
        foreach (self::requiredChecks() as $check) {
            $normalized[$check] = 'unknown';
        }

        if (! is_array($checks)) {
            return $normalized;
        }

        foreach ($checks as $check => $result) {
            if (is_int($check)) {
                $normalized[self::stringValue($result)] = 'reported';
                continue;
            }
            $normalized[(string) $check] = self::stringValue($result);
        }

        return $normalized;
    }

    /**
     * @param mixed $value
     */
    private static function stringValue($value): string
    {
        if (is_scalar($value) || $value === null) {
            return (string) $value;
        }

        return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: 'unserializable';
    }
}
