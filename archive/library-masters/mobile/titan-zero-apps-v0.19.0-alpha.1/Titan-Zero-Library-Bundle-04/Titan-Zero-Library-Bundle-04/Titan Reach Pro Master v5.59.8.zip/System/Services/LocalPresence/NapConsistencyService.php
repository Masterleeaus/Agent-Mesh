<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachPro\System\Services\LocalPresence;
final class NapConsistencyService
{
    public function compare(array $canonical, array $profiles): array
    {
        $fields=['business_name','phone','website_url']; $m=[];
        foreach($profiles as $channel=>$profile) foreach($fields as $f) if(isset($canonical[$f],$profile[$f]) && trim((string)$canonical[$f])!==trim((string)$profile[$f])) $m[]=['channel'=>$channel,'field'=>$f];
        return ['consistent'=>count($m)===0,'mismatches'=>$m];
    }
}
