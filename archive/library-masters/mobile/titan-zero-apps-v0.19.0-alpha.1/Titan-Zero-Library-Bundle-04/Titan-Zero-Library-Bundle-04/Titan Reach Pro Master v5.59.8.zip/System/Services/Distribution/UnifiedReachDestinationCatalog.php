<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDestinationCatalog
{
    public function all(): array
    {
        $configured = function_exists('config') ? config('titan-reach-distribution.destinations', []) : [];
        if (! is_array($configured) || $configured === []) { $configured = require dirname(__DIR__, 3) . '/config/titan-reach-distribution.php'; $configured = $configured['destinations'] ?? []; }
        $destinations = [];
        foreach ($configured as $key => $destination) { $destinations[(string) $key] = UnifiedReachDestination::fromArray((string) $key, (array) $destination); }
        return $destinations;
    }
}
