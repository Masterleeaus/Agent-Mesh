<?php

namespace App\Extensions\TitanReachPro\System\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TitanReachCampaign extends Model
{
    protected $table = 'titan_reach_pro_campaigns';

    protected $fillable = [
        'user_id',
        'company_id',
        'name',
        'target_audience',
        'field_service_objective',
        'conversion_goal',
        'attribution_key',
        'field_service_source_context',
        'conversion_summary',
    ];

    protected $casts = [
        'field_service_source_context' => 'array',
        'conversion_summary' => 'array',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function conversionEvents(): HasMany
    {
        return $this->hasMany(FieldServiceConversionEvent::class, 'campaign_id');
    }
}
