<?php

namespace App\Extensions\TitanReachPro\System\Models;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TitanReachPostDailyMetric extends Model
{
    protected $table = 'titan_reach_pro_post_daily_metrics';

    protected $fillable = [
        'titan_reach_post_id',
        'agent_id',
        'titan_reach_platform_id',
        'platform',
        'post_identifier',
        'date',
        'like_count',
        'comment_count',
        'share_count',
        'view_count',
        'last_totals',
    ];

    protected $casts = [
        'date'        => 'date',
        'last_totals' => 'array',
    ];

    public function agent(): BelongsTo
    {
        return $this->belongsTo(TitanReachAgent::class, 'agent_id');
    }

    public function platform(): BelongsTo
    {
        return $this->belongsTo(TitanReachPlatform::class, 'titan_reach_platform_id');
    }

    public function post(): BelongsTo
    {
        return $this->belongsTo(TitanReachPost::class, 'titan_reach_post_id');
    }
}
