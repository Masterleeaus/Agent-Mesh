<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers\Common;

use App\Extensions\TitanReachPro\System\Models\TitanReachCampaign;
use App\Extensions\TitanReachPro\System\Services\Ai\ReachAiClient;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TitanReachCampaignCommonController extends Controller
{
    public function __construct(private readonly ReachCompanyContext $companyContext, private readonly ReachAiClient $ai) {}
    public function __invoke()
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());
        return response()->json([
            'data' => TitanReachCampaign::query()
                ->select('id', 'name', 'target_audience')
                ->where('user_id', Auth::id())->where('company_id', $companyId)->get(),
        ]);
    }

    public function generate(Request $request)
    {
        try {
            $campaign_name = $request->campaign_name ?? 'any';

            $companyId = $this->companyContext->resolve(userId: Auth::id());
            $response = $this->ai->completeUserOnly(
                "Generate only a list of target audience attributes, including demographics, interests, and pain points, for the purpose of $campaign_name campaign. Must result as array json data only. Result format is [attribute1, attribute2, ..., attributen]. Ensure that the result does not contain backticks (\`) or the string \"```json\".",
                ['company_id' => $companyId],
            );

            return response()->json(['result' => $response]);
        } catch (Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 500);
        }
    }
}
