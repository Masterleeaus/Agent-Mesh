<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\PaidGrowth;

final class PaidGrowthChannelCatalog
{
    public function all(): array
    {
        return [
            'meta_ads' => [
                'label' => 'Meta Ads',
                'objectives' => ['lead_generation', 'messages', 'traffic', 'awareness'],
                'activation' => 'governed',
                'requires' => ['ad_account', 'payment_profile', 'human_approval', 'budget_ceiling'],
            ],
            'google_local_services_ads' => [
                'label' => 'Google Local Services Ads',
                'objectives' => ['qualified_leads', 'calls', 'bookings'],
                'activation' => 'assisted_governed',
                'requires' => ['business_verification', 'category_eligibility', 'service_area_match', 'human_approval', 'budget_ceiling'],
            ],
        ];
    }

    public function get(string $channel): ?array
    {
        return $this->all()[$channel] ?? null;
    }
}
