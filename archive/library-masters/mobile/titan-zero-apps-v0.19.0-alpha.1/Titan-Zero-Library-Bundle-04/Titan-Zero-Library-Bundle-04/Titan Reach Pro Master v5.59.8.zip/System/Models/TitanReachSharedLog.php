<?php

namespace App\Extensions\TitanReachPro\System\Models;

use App\Extensions\TitanReachPro\System\Enums\LogStatusEnum;
use Illuminate\Database\Eloquent\Model;

class TitanReachSharedLog extends Model
{
    public $timestamps = false;

    protected $table = 'titan_reach_pro_shared_logs';

    protected $fillable = [
        'titan_reach_post_id',
        'response',
        'status',
        'created_at',
    ];

    protected $casts = [
        'response'   => 'json',
        'created_at' => 'datetime',
        'status'     => LogStatusEnum::class,
    ];
}
