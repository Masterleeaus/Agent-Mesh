<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Models\TitanReachCampaign;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceAttributionService;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class FieldServiceConversionController extends Controller
{
    public function __construct(private readonly FieldServiceAttributionService $attribution)
    {
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'event_type' => ['required', 'string', Rule::in(['lead', 'quote', 'booking', 'review', 'revenue'])],
            'campaign_id' => ['nullable', 'integer'],
            'post_id' => ['nullable', 'integer'],
            'company_id' => ['nullable', 'integer'],
            'attribution_key' => ['nullable', 'string', 'max:120'],
            'source' => ['nullable', 'string', 'max:80'],
            'value' => ['nullable', 'numeric', 'min:0'],
            'currency' => ['nullable', 'string', 'max:8'],
            'dedupe_key' => ['nullable', 'string', 'max:160'],
            'metadata' => ['nullable', 'array'],
        ]);

        if (! empty($data['campaign_id'])) {
            $campaign = TitanReachCampaign::query()
                ->where('id', $data['campaign_id'])
                ->where('user_id', Auth::id())
                ->firstOrFail();
            $data['company_id'] = $data['company_id'] ?? $campaign->company_id;
            $data['attribution_key'] = $data['attribution_key'] ?? $campaign->attribution_key;
        }

        if (! empty($data['post_id'])) {
            $post = TitanReachPost::query()
                ->where('id', $data['post_id'])
                ->where('user_id', Auth::id())
                ->firstOrFail();
            $data['company_id'] = $data['company_id'] ?? $post->company_id;
            $data['campaign_id'] = $data['campaign_id'] ?? $post->campaign_id;
            $data['attribution_key'] = $data['attribution_key'] ?? $post->attribution_key;
        }

        $event = $this->attribution->recordEvent($data + ['user_id' => Auth::id()]);

        if ($event->campaign) {
            $this->attribution->summarizeCampaign($event->campaign);
        }

        return response()->json([
            'status' => 'success',
            'event_id' => $event->id,
        ]);
    }
}
