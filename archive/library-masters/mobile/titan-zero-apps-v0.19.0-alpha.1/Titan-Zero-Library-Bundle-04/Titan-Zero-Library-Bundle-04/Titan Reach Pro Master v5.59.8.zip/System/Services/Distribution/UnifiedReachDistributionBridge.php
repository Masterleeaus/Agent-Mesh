<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDistributionBridge
{
    public function resolve(array $item): array
    {
        $engine = function_exists('app') && app()->bound('titan-reach.distribution.engine') ? app('titan-reach.distribution.engine') : new UnifiedReachDistributionEngine();
        return array_map(static fn (UnifiedReachDistributionDecision $decision): array => $decision->toArray(), $engine->plan($item));
    }
}
