<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachPro\System\Support;
use App\Extensions\TitanReachPro\System\Services\LocalPresence\LocalPresenceHealthEngine;
final class TitanReachLocalPresenceBridge
{
    public function __construct(private readonly LocalPresenceHealthEngine $engine) {}
    public function assess(array $context): array { return $this->engine->assess($context); }
}
