<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class TitanReachPlatformController extends Controller
{
    public function __invoke()
    {
        return view('titan-reach::platforms', [
            'platforms'     => PlatformEnum::all(),
            'userPlatforms' => TitanReachPlatform::query()
                ->when(request('active') === 'on', function ($query) {
                    return $query->where('expires_at', '>', now());
                })
                ->when(request('inactive') === 'on', function ($query) {
                    return $query->where('expires_at', '<', now());
                })
                ->when(request('search'), function ($query, $search) {
                    return $query->where('credentials', 'like', "%{$search}%");
                })
                ->where('user_id', Auth::id())->get(),
        ]);
    }

    public function disconnect(TitanReachPlatform $platform): ?RedirectResponse
    {
        abort_unless((int) $platform->user_id === (int) Auth::id(), 404);
        if (Helper::appIsDemo()) {
            return back()->with([
                'type'    => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        try {
            $platform->delete();

            return back()->with([
                'type'    => 'success',
                'message' => trans('Platform has been disconnected.'),
            ]);
        } catch (Exception $exception) {
            return back()->with([
                'type'    => 'error',
                'message' => $exception->getMessage(),
            ]);
        }
    }
}
