<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\Traits;

trait HasBackRoute
{
    public function setBackCacheRoute(): void
    {
        if (request()->has('extension') && request('extension') === 'titan-reach-pro') {
            cache()->remember('redirect_back_route', 60, function () {
                return 'dashboard.user.titan-reach.agent.accounts';
            });
        }
    }

    public function getBackCacheRoute(): string
    {
        if (cache()->has('redirect_back_route')) {
            cache()->forget('redirect_back_route');

            return 'dashboard.user.titan-reach.agent.accounts';
        }

        return 'dashboard.user.titan-reach.platforms';
    }
}
