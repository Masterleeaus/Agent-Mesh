<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Ai;

interface LegacyReachVideoFallback
{
    public function generate(string $prompt, int $companyId): array;
    public function status(string $requestId, int $companyId): array;
}
