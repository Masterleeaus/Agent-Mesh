<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use App\Extensions\TitanReachPro\System\Services\LocalDistribution\AssistedDistributionPlanner;

final class TitanReachLocalDistributionBridge
{
    public const POLICY = ['company_id_required','assisted','manual_completion'];
    public function __construct(private readonly AssistedDistributionPlanner $planner) {}
    public function plan(array $payload): array { return $this->planner->plan($payload); }
    public function health(array $payload): array { return $this->planner->presenceHealth($payload); }
}
