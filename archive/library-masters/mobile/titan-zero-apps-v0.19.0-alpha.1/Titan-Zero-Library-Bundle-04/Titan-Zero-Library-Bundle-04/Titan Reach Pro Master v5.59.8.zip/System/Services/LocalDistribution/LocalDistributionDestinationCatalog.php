<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\LocalDistribution;

final class LocalDistributionDestinationCatalog
{
    public function all(): array
    {
        $configured = function_exists('config') ? config('titan-reach-local-distribution.destinations', []) : [];
        if (!is_array($configured) || $configured === []) {
            $cfg = require dirname(__DIR__, 3).'/config/titan-reach-local-distribution.php';
            $configured = $cfg['destinations'] ?? [];
        }
        return $configured;
    }

    public function get(string $destination): ?array
    {
        return $this->all()[$destination] ?? null;
    }
}
