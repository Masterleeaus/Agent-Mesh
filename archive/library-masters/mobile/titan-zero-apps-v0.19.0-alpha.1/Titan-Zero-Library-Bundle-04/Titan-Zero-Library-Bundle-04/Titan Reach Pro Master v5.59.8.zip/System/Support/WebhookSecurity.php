<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class WebhookSecurity
{
    public static function configuredSecret(?string $secret): ?string
    {
        $secret = is_string($secret) ? trim($secret) : '';
        if ($secret === '' || in_array($secret, ['default-password', 'changeme', 'secret'], true)) {
            return null;
        }
        return $secret;
    }

    public static function verifyHubSignature(Request $request, ?string $secret, string $platform): bool
    {
        $secret = self::configuredSecret($secret);
        if ($secret === null) {
            Log::warning("{$platform} webhook disabled: missing signing secret");
            return false;
        }
        $signature = (string) $request->header('X-Hub-Signature-256', '');
        if ($signature === '') {
            Log::warning("{$platform} webhook rejected: missing signature");
            return false;
        }
        $expected = 'sha256=' . hash_hmac('sha256', $request->getContent(), $secret);
        if (! hash_equals($expected, $signature)) {
            Log::warning("{$platform} webhook rejected: invalid signature");
            return false;
        }
        return self::rejectReplay($platform, hash('sha256', $signature . '|' . $request->getContent()));
    }

    public static function rejectReplay(string $platform, string $fingerprint): bool
    {
        $key = 'titan_reach_webhook_replay:' . $platform . ':' . $fingerprint;
        if (! Cache::add($key, true, now()->addSeconds((int) config('titan-reach.webhooks.replay_window_seconds', 300)))) {
            Log::warning("{$platform} webhook rejected: replay detected");
            return false;
        }
        return true;
    }
}
