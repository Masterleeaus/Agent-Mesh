<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers\Common;

use App\Extensions\TitanReachPro\System\Http\Resources\Company\CompanyResource;
use App\Http\Controllers\Controller;
use App\Models\Company;
use Illuminate\Support\Facades\Auth;

class TitanReachCompanyCommonController extends Controller
{
    public function __invoke()
    {
        return CompanyResource::collection(
            Company::query()
                ->where('user_id', Auth::id())
                ->with('products')
                ->get()
        );
    }
}
