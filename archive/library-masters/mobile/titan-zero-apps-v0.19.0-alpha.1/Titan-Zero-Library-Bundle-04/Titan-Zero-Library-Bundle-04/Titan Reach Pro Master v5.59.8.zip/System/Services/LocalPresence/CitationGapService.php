<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachPro\System\Services\LocalPresence;
final class CitationGapService
{
    public function gaps(array $configured): array
    {
        $targets=['google_business_profile','apple_business_connect','bing_places','hipages','oneflare','yellow_pages_au','true_local'];
        return array_values(array_diff($targets, array_keys(array_filter($configured))));
    }
}
