<?php

namespace App\Extensions\TitanReachPro\System\Services\Publisher;

use App\Extensions\TitanReachPro\System\Helpers\Tiktok;
use App\Extensions\TitanReachPro\System\Services\Publisher\Contracts\BasePublisherService;
use Illuminate\Http\Client\Response;

class TiktokService extends BasePublisherService
{
    public function handle(): Response
    {
        $media = $this->post->video;

        $message = $this->post->content;

        $tiktok = new Tiktok;

        $tiktok->setToken($this->accessToken);

        $postData = [
            'post_info' => [
                'title'                    => str($message)->limit(150)->toString(),
                'privacy_level'            => $options['privacy_level'] ?? config('titan-reach.tiktok.options.privacy_level'),
                'disable_duet'             => $options['disable_duet'] ?? config('titan-reach.tiktok.options.disable_duet'),
                'disable_comment'          => $options['disable_comment'] ?? config('titan-reach.tiktok.options.disable_comment'),
                'disable_stitch'           => $options['disable_stitch'] ?? config('titan-reach.tiktok.options.disable_stitch'),
                'video_cover_timestamp_ms' => $options['video_cover_timestamp_ms'] ?? config('titan-reach.tiktok.options.video_cover_timestamp_ms'),
            ],
            'source_info' => [
                'source'    => 'PULL_FROM_URL',
                'video_url' => url($media),
            ],
        ];

        return $tiktok->postVideo($postData);
    }
}
