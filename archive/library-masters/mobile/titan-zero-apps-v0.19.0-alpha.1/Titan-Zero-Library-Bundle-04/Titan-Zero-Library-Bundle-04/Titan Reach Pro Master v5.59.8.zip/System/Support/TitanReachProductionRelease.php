<?php

namespace App\Extensions\TitanReachPro\System\Support;

final class TitanReachProductionRelease
{
    public function summary(): array
    {
        return [
            'release' => 'step-44-production',
            'company_boundary' => 'company_id',
            'host_bridge' => TitanZeroClosedLoopBridge::class,
            'legacy_placeholder_integrations_removed' => true,
        ];
    }
}
