<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\DTO;

final class FieldServiceContext
{
    /** @param FieldServiceServiceItem[] $services @param FieldServiceAreaItem[] $serviceAreas */
    public function __construct(
        public readonly ?int $companyId,
        public readonly ?int $profileId,
        public readonly ?string $businessName,
        public readonly ?string $vertical,
        public readonly array $services = [],
        public readonly array $serviceAreas = [],
        public readonly array $hours = [],
        public readonly bool $emergencyAvailable = false,
        public readonly array $contactChannels = [],
        public readonly ?string $quoteUrl = null,
        public readonly ?string $bookingUrl = null,
        public readonly ?string $reviewUrl = null,
        public readonly array $licenceTrustStatements = [],
        public readonly array $seasonalServices = [],
        public readonly ?string $brandVoice = null,
        public readonly array $privacyDefaults = [],
        public readonly int $completenessScore = 0,
        public readonly array $missingFields = [],
        public readonly bool $standaloneFallback = false,
    ) {}

    public static function safeDefault(?int $companyId = null): self
    {
        return new self(
            companyId: $companyId,
            profileId: null,
            businessName: null,
            vertical: null,
            services: [],
            serviceAreas: [],
            hours: [],
            emergencyAvailable: false,
            contactChannels: [],
            quoteUrl: null,
            bookingUrl: null,
            reviewUrl: null,
            licenceTrustStatements: [],
            seasonalServices: [],
            brandVoice: 'Clear, practical and helpful. Avoid claims that have not been explicitly supplied.',
            privacyDefaults: self::defaultPrivacy(),
            completenessScore: 0,
            missingFields: ['business_name', 'vertical', 'services', 'service_areas', 'contact_channels'],
            standaloneFallback: true,
        );
    }

    public static function defaultPrivacy(): array
    {
        return [
            'include_customer_names'     => false,
            'include_exact_addresses'    => false,
            'include_faces'              => false,
            'include_vehicle_plates'     => false,
            'include_before_after_media' => false,
            'strip_exif'                 => true,
            'strip_gps'                  => true,
            'require_media_consent'      => true,
            'allow_ai_to_identify_people' => false,
            'allow_ai_to_infer_location' => false,
            'require_human_review'       => true,
        ];
    }

    public static function calculateCompleteness(array $data): array
    {
        $checks = [
            'business_name'     => self::isFilled($data['business_name'] ?? null),
            'vertical'          => self::isFilled($data['vertical'] ?? null),
            'services'          => count($data['services'] ?? []) > 0,
            'service_areas'     => count($data['service_areas'] ?? []) > 0,
            'hours'             => count(array_filter($data['hours'] ?? [])) > 0,
            'contact_channels'  => count(array_filter($data['contact_channels'] ?? [])) > 0,
            'quote_or_booking'  => self::isFilled($data['quote_url'] ?? null) || self::isFilled($data['booking_url'] ?? null),
            'brand_voice'       => self::isFilled($data['brand_voice'] ?? null),
            'privacy_defaults'  => count($data['privacy_defaults'] ?? []) > 0,
            'licence_or_trust'  => count(array_filter($data['licence_trust_statements'] ?? [])) > 0,
        ];

        $complete = count(array_filter($checks));
        $total = count($checks);
        $missing = array_keys(array_filter($checks, static fn (bool $passed): bool => ! $passed));

        return [(int) round(($complete / max(1, $total)) * 100), $missing];
    }

    private static function isFilled(mixed $value): bool
    {
        if ($value === null) {
            return false;
        }

        if (is_string($value)) {
            return trim($value) !== '';
        }

        if (is_array($value)) {
            return count(array_filter($value)) > 0;
        }

        return true;
    }

    public function toArray(): array
    {
        return [
            'company_id'                  => $this->companyId,
            'profile_id'                  => $this->profileId,
            'business_name'               => $this->businessName,
            'vertical'                    => $this->vertical,
            'services'                    => array_map(static fn ($service) => $service instanceof FieldServiceServiceItem ? $service->toArray() : $service, $this->services),
            'service_areas'               => array_map(static fn ($area) => $area instanceof FieldServiceAreaItem ? $area->toArray() : $area, $this->serviceAreas),
            'hours'                       => $this->hours,
            'emergency_available'         => $this->emergencyAvailable,
            'contact_channels'            => $this->contactChannels,
            'quote_url'                   => $this->quoteUrl,
            'booking_url'                 => $this->bookingUrl,
            'review_url'                  => $this->reviewUrl,
            'licence_trust_statements'    => $this->licenceTrustStatements,
            'seasonal_services'           => $this->seasonalServices,
            'brand_voice'                 => $this->brandVoice,
            'privacy_defaults'            => $this->privacyDefaults,
            'completeness_score'          => $this->completenessScore,
            'missing_fields'              => $this->missingFields,
            'standalone_fallback'         => $this->standaloneFallback,
        ];
    }
}
