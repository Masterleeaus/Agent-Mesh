<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDestination
{
    public function __construct(public readonly string $key, public readonly string $mode, public readonly string $priority, public readonly array $contentTypes, public readonly array $capabilities, public readonly bool $approvalRequired = true, public readonly bool $budgetApprovalRequired = false, public readonly bool $verificationRequired = false) {}

    public static function fromArray(string $key, array $data): self
    {
        return new self($key, (string) ($data['mode'] ?? 'assisted'), (string) ($data['priority'] ?? 'normal'), array_values($data['content'] ?? []), array_values($data['capabilities'] ?? []), (bool) ($data['approval_required'] ?? true), (bool) ($data['budget_approval_required'] ?? false), (bool) ($data['verification_required'] ?? false));
    }

    public function supportsContentType(string $contentType): bool { return in_array($contentType, $this->contentTypes, true); }
    public function toArray(): array { return ['key' => $this->key, 'mode' => $this->mode, 'priority' => $this->priority, 'content_types' => $this->contentTypes, 'capabilities' => $this->capabilities, 'approval_required' => $this->approvalRequired, 'budget_approval_required' => $this->budgetApprovalRequired, 'verification_required' => $this->verificationRequired]; }
}
