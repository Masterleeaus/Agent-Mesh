<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\PaidGrowth;

final class GoogleLocalServicesAdsGovernanceService
{
    public function __construct(private readonly PaidGrowthGovernanceService $governance) {}

    public function review(array $input): PaidGrowthDecision
    {
        $input['channel'] = 'google_local_services_ads';
        return $this->governance->evaluate($input);
    }
}
