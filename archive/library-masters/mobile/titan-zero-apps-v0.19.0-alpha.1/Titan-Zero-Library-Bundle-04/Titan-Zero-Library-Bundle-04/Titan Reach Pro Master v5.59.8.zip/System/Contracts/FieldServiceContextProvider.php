<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Contracts;

use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;

interface FieldServiceContextProvider
{
    /**
     * Resolve normalized field/home-service marketing context for one company.
     * Implementations must fail safe: missing data stays null/empty and must not
     * invent licences, prices, emergency service, geographic coverage, or trust claims.
     */
    public function resolve(?int $companyId = null, ?int $userId = null): FieldServiceContext;
}
