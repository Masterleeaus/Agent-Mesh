<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Reputation;

final class ReputationGovernanceService
{
    private const RISK_TERMS = [
        'injury', 'unsafe', 'electric shock', 'gas leak', 'fire', 'flooding',
        'no power', 'break in', 'locked out', 'mould', 'complaint', 'refund',
    ];

    /** @return array<string,mixed> */
    public function classifyReview(string $body, int $rating): array
    {
        $lower = mb_strtolower($body);
        $flags = [];
        foreach (self::RISK_TERMS as $term) {
            if (str_contains($lower, $term)) {
                $flags[] = $term;
            }
        }

        return [
            'rating' => $rating,
            'risk_flags' => array_values(array_unique($flags)),
            'requires_human_review' => $rating <= 3 || $flags !== [],
            'reply_auto_approved' => false,
            'redacted_summary' => $this->redact($body),
        ];
    }

    private function redact(string $value): string
    {
        $value = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[redacted-email]', $value) ?? $value;
        $value = preg_replace('/\+?\d[\d\s().-]{7,}\d/', '[redacted-phone]', $value) ?? $value;
        return mb_substr($value, 0, 240);
    }
}
