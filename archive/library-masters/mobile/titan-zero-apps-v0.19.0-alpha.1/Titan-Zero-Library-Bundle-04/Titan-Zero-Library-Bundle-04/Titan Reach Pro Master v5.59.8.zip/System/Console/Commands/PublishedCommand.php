<?php

namespace App\Extensions\TitanReachPro\System\Console\Commands;

use App\Extensions\TitanReachPro\System\Enums\StatusEnum;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use App\Extensions\TitanReachPro\System\Services\Publisher\Contracts\BasePublisherService;
use App\Extensions\TitanReachPro\System\Services\Publisher\PublisherDriver;
use Illuminate\Console\Command;

class PublishedCommand extends Command
{
    protected $signature = 'app:titan-reach-published-command';

    protected $description = 'Publish scheduled Titan Reach posts';

    public function handle(): void
    {
        $posts = TitanReachPost::query()
            ->with('platform')
            ->whereNotNull('company_id')
            ->where('status', StatusEnum::scheduled->value)
            ->where('scheduled_at', '<', now())
            ->get();

        $service = app(PublisherDriver::class);

        foreach ($posts as $post) {
            $driver = $service
                ->setPost($post)
                ->getDriver();

            if ($driver instanceof BasePublisherService) {
                $driver->publish();
            }
        }
    }
}
