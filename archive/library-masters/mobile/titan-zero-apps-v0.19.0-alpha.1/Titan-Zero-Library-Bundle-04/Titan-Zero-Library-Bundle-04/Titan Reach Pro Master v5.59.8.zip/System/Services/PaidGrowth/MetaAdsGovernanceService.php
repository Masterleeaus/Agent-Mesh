<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\PaidGrowth;

final class MetaAdsGovernanceService
{
    public function __construct(private readonly PaidGrowthGovernanceService $governance) {}

    public function review(array $input): PaidGrowthDecision
    {
        $input['channel'] = 'meta_ads';
        return $this->governance->evaluate($input);
    }
}
