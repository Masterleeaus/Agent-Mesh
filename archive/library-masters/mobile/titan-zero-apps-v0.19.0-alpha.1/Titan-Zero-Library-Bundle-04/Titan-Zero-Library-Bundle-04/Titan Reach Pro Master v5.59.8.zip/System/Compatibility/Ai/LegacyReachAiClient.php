<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Compatibility\Ai;

use App\Extensions\TitanReachPro\System\Services\Ai\LegacyReachAiFallback;
use App\Services\Ai\AiCompletionService;

/** Compatibility-only bridge for hosts that have not yet registered canonical Titan AI routing. */
final class LegacyReachAiClient implements LegacyReachAiFallback
{
    public function __construct(private readonly AiCompletionService $ai) {}

    public function completeMessages(array $messages, array $context = []): string
    {
        $system = '';
        $user = '';
        foreach ($messages as $message) {
            if (($message['role'] ?? null) === 'system') {
                $system .= ($system === '' ? '' : "\n") . (string) ($message['content'] ?? '');
            } elseif (($message['role'] ?? null) === 'user') {
                $user .= ($user === '' ? '' : "\n") . (string) ($message['content'] ?? '');
            }
        }

        return $system !== ''
            ? $this->ai->complete($system, $user)
            : $this->ai->completeUserOnly($user);
    }
}
