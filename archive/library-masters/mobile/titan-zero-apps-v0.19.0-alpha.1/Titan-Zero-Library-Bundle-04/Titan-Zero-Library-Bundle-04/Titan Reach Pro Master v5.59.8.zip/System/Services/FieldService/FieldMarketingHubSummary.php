<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\DTO\FieldServiceAreaItem;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceServiceItem;
use Illuminate\Support\Collection;

final class FieldMarketingHubSummary
{
    /**
     * @param Collection<int, mixed>|array<int, mixed> $recentPosts
     * @param array<int, mixed> $platforms
     * @return array<string, mixed>
     */
    public function build(FieldServiceContext $context, Collection|array $recentPosts = [], array $platforms = []): array
    {
        $services = $this->serviceNames($context);
        $areas = $this->areaNames($context);
        $recentCount = $recentPosts instanceof Collection ? $recentPosts->count() : count($recentPosts);

        return [
            'business_label'       => $context->businessName ?: __('Your field-service business'),
            'vertical_label'       => $context->vertical ?: __('Field & home services'),
            'readiness_score'      => $context->completenessScore,
            'readiness_status'     => $this->readinessStatus($context->completenessScore),
            'missing_fields'       => $context->missingFields,
            'safe_to_publish'      => $context->completenessScore >= 70 && ! $context->standaloneFallback,
            'standalone_fallback'  => $context->standaloneFallback,
            'services'             => $services,
            'service_areas'        => $areas,
            'primary_cta'          => $this->primaryCta($context),
            'privacy_defaults'     => $context->privacyDefaults,
            'active_platforms'     => count($platforms),
            'recent_post_count'    => $recentCount,
            'recommended_actions'  => $this->recommendedActions($context, $services, $areas),
            'content_lanes'        => $this->contentLanes($context, $services, $areas),
        ];
    }

    private function readinessStatus(int $score): string
    {
        return match (true) {
            $score >= 85 => __('Ready to publish local campaigns'),
            $score >= 70 => __('Ready with review safeguards'),
            $score >= 40 => __('Profile needs more service detail'),
            default      => __('Complete your field-service profile first'),
        };
    }

    /** @return array<int, string> */
    private function serviceNames(FieldServiceContext $context): array
    {
        return array_values(array_filter(array_map(
            static fn ($service): ?string => $service instanceof FieldServiceServiceItem ? $service->name : ($service['name'] ?? null),
            $context->services,
        )));
    }

    /** @return array<int, string> */
    private function areaNames(FieldServiceContext $context): array
    {
        return array_values(array_filter(array_map(
            static fn ($area): ?string => $area instanceof FieldServiceAreaItem ? $area->name : ($area['name'] ?? null),
            $context->serviceAreas,
        )));
    }

    /** @return array<string, string|null> */
    private function primaryCta(FieldServiceContext $context): array
    {
        if ($context->quoteUrl) {
            return ['label' => __('Request a quote'), 'url' => $context->quoteUrl, 'type' => 'quote'];
        }

        if ($context->bookingUrl) {
            return ['label' => __('Book a service'), 'url' => $context->bookingUrl, 'type' => 'booking'];
        }

        $phone = $context->contactChannels['phone'] ?? $context->contactChannels['mobile'] ?? null;
        if ($phone) {
            return ['label' => __('Call the business'), 'url' => 'tel:' . preg_replace('/[^0-9+]/', '', (string) $phone), 'type' => 'phone'];
        }

        return ['label' => __('Add quote or booking link'), 'url' => null, 'type' => 'missing'];
    }

    /** @param array<int, string> $services @param array<int, string> $areas @return array<int, array<string, string>> */
    private function recommendedActions(FieldServiceContext $context, array $services, array $areas): array
    {
        $actions = [];

        if ($context->standaloneFallback || $context->completenessScore < 70) {
            $actions[] = [
                'title' => __('Complete marketing context'),
                'body'  => __('Add your services, service areas, hours and quote/booking path before letting AI draft local posts.'),
                'type'  => 'profile',
            ];
        }

        if ($services === []) {
            $actions[] = [
                'title' => __('Add service catalogue'),
                'body'  => __('List your active services so captions do not invent work you do not offer.'),
                'type'  => 'services',
            ];
        }

        if ($areas === []) {
            $actions[] = [
                'title' => __('Add service areas'),
                'body'  => __('Add suburbs or regions before creating local availability posts.'),
                'type'  => 'areas',
            ];
        }

        if (($context->privacyDefaults['require_human_review'] ?? true) === true) {
            $actions[] = [
                'title' => __('Review job-site media'),
                'body'  => __('Customer names, exact addresses, faces and plates stay excluded unless you explicitly allow them.'),
                'type'  => 'privacy',
            ];
        }

        if ($actions === []) {
            $actions[] = [
                'title' => __('Schedule a local campaign'),
                'body'  => __('Use your active services and areas to create quote-focused posts for the week ahead.'),
                'type'  => 'campaign',
            ];
        }

        return array_slice($actions, 0, 4);
    }

    /** @param array<int, string> $services @param array<int, string> $areas @return array<int, array<string, mixed>> */
    private function contentLanes(FieldServiceContext $context, array $services, array $areas): array
    {
        $service = $services[0] ?? __('your core service');
        $area = $areas[0] ?? __('your service area');

        return [
            [
                'title'       => __('Completed job'),
                'description' => __('Show completed work without exposing exact customer details.'),
                'prompt'      => __('Draft a completed :service job post for :area with a quote CTA.', ['service' => $service, 'area' => $area]),
                'guardrail'   => __('No exact address, customer name, face or vehicle plate.'),
            ],
            [
                'title'       => __('Seasonal reminder'),
                'description' => __('Turn upcoming weather or seasonal demand into practical maintenance content.'),
                'prompt'      => __('Draft a seasonal maintenance reminder for :service customers in :area.', ['service' => $service, 'area' => $area]),
                'guardrail'   => __('Do not claim discounts, prices or emergency availability unless configured.'),
            ],
            [
                'title'       => __('Local availability'),
                'description' => __('Fill route gaps with area-specific availability posts.'),
                'prompt'      => __('Draft a local availability post for :area that invites quote requests.', ['area' => $area]),
                'guardrail'   => __('Only mention configured service areas.'),
            ],
            [
                'title'       => __('Trust builder'),
                'description' => __('Use supplied licence/trust statements without inventing credentials.'),
                'prompt'      => __('Draft a trust-building post for :business.', ['business' => $context->businessName ?: __('the business')]),
                'guardrail'   => __('Only use licence, insurance or warranty claims explicitly saved in the profile.'),
            ],
        ];
    }
}
