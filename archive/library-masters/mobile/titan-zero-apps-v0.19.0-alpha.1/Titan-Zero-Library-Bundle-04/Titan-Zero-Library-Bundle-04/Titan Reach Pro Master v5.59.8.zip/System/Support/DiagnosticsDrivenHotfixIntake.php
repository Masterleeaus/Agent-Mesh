<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

/**
 * Non-mutating intake helper for live installer diagnostics.
 *
 * This class turns redacted live install evidence into a precise hotfix target
 * without logging raw payloads, customer data, credentials, or stack traces.
 */
final class DiagnosticsDrivenHotfixIntake
{
    public const REQUIRED_DIAGNOSTIC_FIELDS = [
        'install_id',
        'package_sha256',
        'failed_stage',
        'failure_type',
        'redacted_error_summary',
        'observed_at',
    ];

    public const HOTFIX_TARGETS = [
        'manifest' => 'manifest_schema_hotfix',
        'schema' => 'manifest_schema_hotfix',
        'migration' => 'migration_database_hotfix',
        'database' => 'migration_database_hotfix',
        'route' => 'route_registration_hotfix',
        'blade' => 'view_blade_hotfix',
        'view' => 'view_blade_hotfix',
        'class' => 'class_autoload_hotfix',
        'autoload' => 'class_autoload_hotfix',
        'permission' => 'permission_cache_storage_hotfix',
        'cache' => 'permission_cache_storage_hotfix',
        'storage' => 'permission_cache_storage_hotfix',
        'webhook' => 'webhook_callback_security_hotfix',
        'callback' => 'webhook_callback_security_hotfix',
        'security' => 'webhook_callback_security_hotfix',
    ];

    /** @var array<string, mixed> */
    private array $config;

    /** @param array<string, mixed>|null $config */
    public function __construct(?array $config = null)
    {
        $this->config = $config ?? (function_exists('config') ? (array) config('field-service-hotfix-intake.' . self::class, []) : []);
    }

    /** @param array<string, mixed> $diagnostic @return array<string, mixed> */
    public function intake(array $diagnostic): array
    {
        $missing = $this->missingFields($diagnostic);
        $redacted = $this->redact($diagnostic);
        $failureType = strtolower((string) ($diagnostic['failure_type'] ?? 'unknown'));
        $failedStage = strtolower((string) ($diagnostic['failed_stage'] ?? 'unknown'));
        $status = strtolower((string) ($diagnostic['installer_status'] ?? $diagnostic['status'] ?? 'failed'));
        $target = $this->targetFor($failureType, $failedStage);

        return [
            'status' => $missing !== [] ? 'blocked_missing_diagnostics' : ($status === 'passed' || $status === 'success' ? 'no_hotfix_needed' : 'hotfix_candidate_ready'),
            'phase' => $this->config['phase'] ?? 'phase_4_live_install_production',
            'step' => $this->config['step'] ?? 34,
            'module_key' => $this->config['module_key'] ?? 'field_marketing_hub',
            'install_id' => (string) ($diagnostic['install_id'] ?? ''),
            'package_sha256' => (string) ($diagnostic['package_sha256'] ?? ''),
            'failed_stage' => (string) ($diagnostic['failed_stage'] ?? ''),
            'failure_type' => (string) ($diagnostic['failure_type'] ?? ''),
            'missing_diagnostics' => $missing,
            'hotfix_target' => $missing !== [] ? 'collect_missing_diagnostics' : $target,
            'release_decision' => $missing !== [] ? 'hold' : ($status === 'passed' || $status === 'success' ? 'advance' : 'hotfix_required'),
            'redacted_diagnostic' => $redacted,
            'non_mutating' => true,
            'preserve_company_boundary' => true,
            'raw_stack_traces_allowed' => false,
        ];
    }

    /** @param array<string, mixed> $diagnostic @return array<int, string> */
    private function missingFields(array $diagnostic): array
    {
        $missing = [];
        foreach (self::REQUIRED_DIAGNOSTIC_FIELDS as $field) {
            if (!array_key_exists($field, $diagnostic) || $diagnostic[$field] === null || $diagnostic[$field] === '') {
                $missing[] = $field;
            }
        }
        return $missing;
    }

    private function targetFor(string $failureType, string $failedStage): string
    {
        $combined = $failureType . ' ' . $failedStage;
        foreach (self::HOTFIX_TARGETS as $needle => $target) {
            if (str_contains($combined, $needle)) {
                return $target;
            }
        }
        return 'unknown_live_failure_hotfix';
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    private function redact(array $payload): array
    {
        $blocked = array_map('strtolower', (array) ($this->config['redaction_keys'] ?? [
            'token', 'secret', 'signature', 'password', 'authorization', 'cookie',
            'customer_name', 'customer_handle', 'contact_value', 'external_customer_id',
            'raw_webhook_body', 'message_body', 'comment_text', 'stack_trace', 'trace',
            'exception_trace', 'sql', 'query', 'bindings',
        ]));
        $redacted = [];
        foreach ($payload as $key => $value) {
            $normalised = strtolower((string) $key);
            if (in_array($normalised, $blocked, true)) {
                $redacted[$key] = '[redacted]';
                continue;
            }
            $redacted[$key] = is_array($value) ? $this->redact($value) : $value;
        }
        return $redacted;
    }
}
