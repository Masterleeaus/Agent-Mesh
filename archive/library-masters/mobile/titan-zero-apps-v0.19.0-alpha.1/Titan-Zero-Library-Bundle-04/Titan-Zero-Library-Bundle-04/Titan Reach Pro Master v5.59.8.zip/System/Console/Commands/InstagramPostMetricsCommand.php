<?php

namespace App\Extensions\TitanReachPro\System\Console\Commands;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Helpers\Instagram;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use Exception;
use Illuminate\Console\Command;

class InstagramPostMetricsCommand extends Command
{
    protected $signature = 'app:titan-reach-instagram-post-metrics';

    protected $description = 'Post metrics for Instagram posts';

    public function handle(): void
    {
        $posts = TitanReachPost::query()
            ->where('titan_reach_platform', PlatformEnum::instagram->value)
            ->with('platform')
            ->where('post_metric_at', '<', now())
            ->get();

        foreach ($posts as $post) {
            try {

                /**
                 * @var TitanReachPlatform $platform
                 */
                $platform = $post->platform;

                if ($platform && $platform->isConnected()) {
                    $x = new Instagram(accessToken: $platform->credentials['access_token']);

                    $json = $x->getPostAnalytics($post['post_id']);

                    if ($json->successful()) {
                        $data = $json->json();
                    } else {
                        $data = [];
                    }

                    if (is_array($data) && isset($data['like_count'])) {
                        $post->update([
                            'post_metrics'   => [
                                'like_count'    => $data['like_count'] ?? 0,
                                'comment_count' => $data['comments_count'] ?? 0,
                            ],
                            'post_metric_at' => now()->addMinutes(15),
                        ]);
                    }
                }
            } catch (Exception $exception) {
            }
        }
    }
}
