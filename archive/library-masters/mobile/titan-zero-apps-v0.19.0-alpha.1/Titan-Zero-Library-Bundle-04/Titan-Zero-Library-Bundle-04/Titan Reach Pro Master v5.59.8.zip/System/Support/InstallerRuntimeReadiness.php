<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

/**
 * Static installer/runtime readiness checks for MagicAI/Titan extension uploads.
 *
 * This class intentionally avoids framework dependencies so it can be exercised
 * during pre-install ZIP validation as well as inside PHPUnit after install.
 */
final class InstallerRuntimeReadiness
{
    public const EXTENSION_KEY = 'titan-reach';
    public const MODULE_SLUG = 'field_marketing_hub';
    public const MODULE_NAME = 'Field Marketing Hub';
    public const VERSION = '5.29';

    /**
     * @return array<string, mixed>
     */
    public static function manifest(): array
    {
        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'module_name' => self::MODULE_NAME,
            'version' => self::VERSION,
            'requires_company_id' => true,
            'standalone_safe' => true,
            'public_webhooks_fail_closed' => true,
            'publishing_authority' => self::MODULE_SLUG === 'field_marketing_hub',
        ];
    }

    /**
     * @param string $extensionRoot absolute path to the extension root.
     * @return array<int, array<string, string|bool>>
     */
    public static function filesystemChecks(string $extensionRoot): array
    {
        $root = rtrim($extensionRoot, DIRECTORY_SEPARATOR);
        $required = [
            'extension.json',
            'README.md',
            'System',
            'config/field-service-production.php',
            'config/field-service-workspace.php',
            'config/field-service-events.php',
            'resources/views/field-service-workspace.blade.php',
            'docs/FIELD_SERVICE_FINAL_RELEASE.md',
        ];

        return array_map(static function (string $path) use ($root): array {
            $absolute = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);

            return [
                'path' => $path,
                'ok' => file_exists($absolute),
                'message' => file_exists($absolute) ? 'present' : 'missing required runtime file',
            ];
        }, $required);
    }

    /**
     * @param array<string, mixed> $manifest
     * @return array<int, string>
     */
    public static function manifestErrors(array $manifest): array
    {
        $errors = [];
        foreach (['name', 'type', 'version', 'description', 'support_telegram'] as $field) {
            if (! array_key_exists($field, $manifest) || trim((string) $manifest[$field]) === '') {
                $errors[] = 'extension.json missing ' . $field;
            }
        }

        if (($manifest['type'] ?? null) !== 'extension') {
            $errors[] = 'extension.json type must be extension';
        }

        if ((string) ($manifest['version'] ?? '') !== self::VERSION) {
            $errors[] = 'extension.json version mismatch for ' . self::VERSION;
        }

        return $errors;
    }

    /**
     * @return array<string, mixed>
     */
    public static function installTrialReport(string $extensionRoot, array $manifest): array
    {
        $filesystem = self::filesystemChecks($extensionRoot);
        $manifestErrors = self::manifestErrors($manifest);
        $missing = array_values(array_filter($filesystem, static fn (array $row): bool => ! (bool) $row['ok']));

        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'version' => self::VERSION,
            'filesystem' => $filesystem,
            'manifest_errors' => $manifestErrors,
            'ok' => $missing === [] && $manifestErrors === [],
        ];
    }
}
