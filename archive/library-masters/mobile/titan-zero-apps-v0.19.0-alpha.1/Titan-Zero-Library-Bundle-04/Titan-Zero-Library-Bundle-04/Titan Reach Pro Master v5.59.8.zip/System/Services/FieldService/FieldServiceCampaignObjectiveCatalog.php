<?php

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

class FieldServiceCampaignObjectiveCatalog
{
    public const QUOTE_REQUESTS = 'quote_requests';
    public const BOOKINGS = 'bookings';
    public const EMERGENCY_LEADS = 'emergency_leads';
    public const REVIEWS = 'reviews';
    public const RECURRING_MAINTENANCE = 'recurring_maintenance';
    public const REACTIVATION = 'reactivation';
    public const LOCAL_AWARENESS = 'local_awareness';

    public function all(): array
    {
        return [
            self::QUOTE_REQUESTS => ['label' => 'Quote requests', 'conversion_goal' => 'quote'],
            self::BOOKINGS => ['label' => 'Bookings', 'conversion_goal' => 'booking'],
            self::EMERGENCY_LEADS => ['label' => 'Emergency leads', 'conversion_goal' => 'lead'],
            self::REVIEWS => ['label' => 'Review generation', 'conversion_goal' => 'review'],
            self::RECURRING_MAINTENANCE => ['label' => 'Recurring maintenance', 'conversion_goal' => 'booking'],
            self::REACTIVATION => ['label' => 'Customer reactivation', 'conversion_goal' => 'lead'],
            self::LOCAL_AWARENESS => ['label' => 'Local awareness', 'conversion_goal' => 'engagement'],
        ];
    }

    public function keys(): array
    {
        return array_keys($this->all());
    }

    public function defaultGoalFor(?string $objective): string
    {
        return $this->all()[$objective]['conversion_goal'] ?? 'lead';
    }
}
