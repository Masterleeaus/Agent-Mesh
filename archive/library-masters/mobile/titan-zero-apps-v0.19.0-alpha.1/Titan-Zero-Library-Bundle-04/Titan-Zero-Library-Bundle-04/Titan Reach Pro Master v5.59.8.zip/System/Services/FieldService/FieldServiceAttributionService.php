<?php

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\Models\FieldServiceConversionEvent;
use App\Extensions\TitanReachPro\System\Models\TitanReachCampaign;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class FieldServiceAttributionService
{
    public function attributionKey(string $prefix = 'fsm'): string
    {
        return $prefix . '_' . Str::lower(Str::random(32));
    }

    public function ensureCampaignAttribution(TitanReachCampaign $campaign): TitanReachCampaign
    {
        if (! $campaign->attribution_key) {
            $campaign->forceFill(['attribution_key' => $this->attributionKey('fsc')])->save();
        }

        return $campaign;
    }

    public function preparePostAttribution(TitanReachPost $post, ?TitanReachCampaign $campaign = null, string $source = 'social_post'): TitanReachPost
    {
        $campaign ??= $post->campaign;

        $post->forceFill([
            'attribution_key' => $post->attribution_key ?: $this->attributionKey('fsp'),
            'attribution_source' => $source,
            'field_service_campaign_objective' => $post->field_service_campaign_objective ?: $campaign?->field_service_objective,
        ])->save();

        return $post;
    }

    public function recordEvent(array $payload): FieldServiceConversionEvent
    {
        $eventType = (string) Arr::get($payload, 'event_type', 'lead');
        $dedupeKey = Arr::get($payload, 'dedupe_key');

        $data = [
            'company_id' => Arr::get($payload, 'company_id'),
            'user_id' => Arr::get($payload, 'user_id', Auth::id()),
            'campaign_id' => Arr::get($payload, 'campaign_id'),
            'post_id' => Arr::get($payload, 'post_id'),
            'attribution_key' => Arr::get($payload, 'attribution_key'),
            'event_type' => $eventType,
            'source' => Arr::get($payload, 'source', 'standalone'),
            'value' => Arr::get($payload, 'value'),
            'currency' => Arr::get($payload, 'currency'),
            'dedupe_key' => $dedupeKey,
            'metadata' => $this->safeMetadata((array) Arr::get($payload, 'metadata', [])),
            'occurred_at' => Arr::get($payload, 'occurred_at', now()),
        ];

        if ($dedupeKey) {
            return FieldServiceConversionEvent::query()->firstOrCreate(['dedupe_key' => $dedupeKey], $data);
        }

        return FieldServiceConversionEvent::query()->create($data);
    }

    public function summarizeCampaign(TitanReachCampaign $campaign): array
    {
        $events = $campaign->conversionEvents()->get();
        $summary = [
            'leads' => $events->where('event_type', 'lead')->count(),
            'quotes' => $events->where('event_type', 'quote')->count(),
            'bookings' => $events->where('event_type', 'booking')->count(),
            'reviews' => $events->where('event_type', 'review')->count(),
            'revenue' => (float) $events->where('event_type', 'revenue')->sum('value'),
            'last_event_at' => optional($events->sortByDesc('occurred_at')->first()?->occurred_at)->toIso8601String(),
        ];

        $campaign->forceFill(['conversion_summary' => $summary])->save();

        return $summary;
    }

    private function safeMetadata(array $metadata): array
    {
        $blocked = ['token', 'access_token', 'refresh_token', 'password', 'secret', 'customer_email', 'customer_phone', 'address'];

        foreach ($blocked as $key) {
            if (array_key_exists($key, $metadata)) {
                $metadata[$key] = '[redacted]';
            }
        }

        return $metadata;
    }
}
