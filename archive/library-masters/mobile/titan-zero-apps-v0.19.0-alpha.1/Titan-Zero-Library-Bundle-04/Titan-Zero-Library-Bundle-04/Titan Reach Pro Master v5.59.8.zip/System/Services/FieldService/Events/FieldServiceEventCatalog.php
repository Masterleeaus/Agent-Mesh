<?php

namespace App\Extensions\TitanReachPro\System\Services\FieldService\Events;

final class FieldServiceEventCatalog
{
    public const CONTENT_DRAFT_PROPOSED = 'field_service.content_draft_proposed';
    public const PUBLISH_REQUESTED = 'field_service.publish_requested';
    public const POST_PUBLISHED = 'field_service.post_published';
    public const LEAD_CAPTURED = 'field_service.lead_captured';
    public const REVIEW_OPPORTUNITY = 'field_service.review_opportunity';
    public const CAMPAIGN_PLAN_READY = 'field_service.campaign_plan_ready';
    public const CONVERSION_RECORDED = 'field_service.conversion_recorded';

    /** @return array<int, string> */
    public static function all(): array
    {
        return [
            self::CONTENT_DRAFT_PROPOSED,
            self::PUBLISH_REQUESTED,
            self::POST_PUBLISHED,
            self::LEAD_CAPTURED,
            self::REVIEW_OPPORTUNITY,
            self::CAMPAIGN_PLAN_READY,
            self::CONVERSION_RECORDED,
        ];
    }

    public static function isKnown(string $eventType): bool
    {
        return in_array($eventType, self::all(), true);
    }
}
