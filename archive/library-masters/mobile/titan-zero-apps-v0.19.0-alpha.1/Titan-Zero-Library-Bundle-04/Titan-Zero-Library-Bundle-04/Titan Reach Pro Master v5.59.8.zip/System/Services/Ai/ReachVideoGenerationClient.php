<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Ai;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

final class ReachVideoGenerationClient
{
    public const HOST_PROVIDER_BINDING = 'titan.ai.video-provider';
    public const LEGACY_FALLBACK_BINDING = 'titan-reach-pro.video.legacy-fallback';

    public function __construct(private readonly Container $container) {}

    public function generate(string $prompt, int $companyId): array
    {
        if ($this->container->bound(self::HOST_PROVIDER_BINDING)) {
            try {
                $provider = $this->container->make(self::HOST_PROVIDER_BINDING);
                $result = is_object($provider) && method_exists($provider, 'generate')
                    ? $provider->generate($prompt, ['company_id' => $companyId, 'capability_id' => 'reach.video.generate'])
                    : (is_callable($provider) ? $provider($prompt, ['company_id' => $companyId, 'capability_id' => 'reach.video.generate']) : null);
                if (is_array($result)) {
                    return $result;
                }
            } catch (Throwable) {
                // Compatibility fallback below preserves existing installations.
            }
        }

        if ($this->container->bound(self::LEGACY_FALLBACK_BINDING)) {
            $fallback = $this->container->make(self::LEGACY_FALLBACK_BINDING);
            if ($fallback instanceof LegacyReachVideoFallback) {
                return $fallback->generate($prompt, $companyId);
            }
        }

        throw new RuntimeException('No governed Titan video-generation route is available.');
    }

    public function status(string $requestId, int $companyId): array
    {
        if ($this->container->bound(self::LEGACY_FALLBACK_BINDING)) {
            $fallback = $this->container->make(self::LEGACY_FALLBACK_BINDING);
            if ($fallback instanceof LegacyReachVideoFallback) {
                return $fallback->status($requestId, $companyId);
            }
        }

        throw new RuntimeException('No compatible video status route is available.');
    }
}
