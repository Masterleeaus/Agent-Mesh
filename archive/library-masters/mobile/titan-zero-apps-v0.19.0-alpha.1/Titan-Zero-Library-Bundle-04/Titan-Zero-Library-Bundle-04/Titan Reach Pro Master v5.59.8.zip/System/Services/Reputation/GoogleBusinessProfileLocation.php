<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Reputation;

final class GoogleBusinessProfileLocation
{
    public function __construct(
        public readonly string $locationId,
        public readonly string $displayName,
        public readonly bool $verified,
        public readonly array $serviceAreas = [],
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'location_id' => $this->locationId,
            'display_name' => $this->displayName,
            'verified' => $this->verified,
            'service_areas' => $this->serviceAreas,
        ];
    }
}
