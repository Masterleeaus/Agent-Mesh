<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\LocalDistribution;

final class AssistedDistributionPlanner
{
    public function __construct(private readonly LocalDistributionDestinationCatalog $catalog) {}

    public function plan(array $input): array
    {
        $companyId=(int)($input['company_id'] ?? 0);
        if ($companyId <= 0) return ['allowed'=>false,'state'=>'blocked','reasons'=>['company_id_required']];
        $destination=(string)($input['destination'] ?? '');
        $def=$this->catalog->get($destination);
        if (!$def) return ['allowed'=>false,'state'=>'blocked','reasons'=>['unsupported_destination']];
        $reasons=[];
        foreach (['claims_unverified_licence'=>'unverified_licence_claim','claims_unapproved_price'=>'unapproved_price_claim','claims_unconfigured_emergency'=>'unconfigured_emergency_claim','claims_outside_service_area'=>'outside_service_area_claim','contains_customer_identity'=>'customer_identity_requires_review'] as $key=>$reason) {
            if (($input[$key] ?? false) === true) $reasons[]=$reason;
        }
        $mode=(string)($def['mode'] ?? 'assisted');
        $ownerAction=in_array($mode,['assisted','directory_assisted','marketplace_assisted','local_presence','optional_commerce'],true);
        if (($input['request_direct_publish'] ?? false) === true && $ownerAction) $reasons[]='direct_publish_not_supported';
        $fields=array_filter([
            'business_name'=>(string)($input['business_name'] ?? ''),
            'headline'=>(string)($input['headline'] ?? ''),
            'description'=>(string)($input['description'] ?? ''),
            'service'=>(string)($input['service'] ?? ''),
            'service_area'=>(string)($input['service_area'] ?? ''),
            'quote_url'=>(string)($input['quote_url'] ?? ''),
            'booking_url'=>(string)($input['booking_url'] ?? ''),
            'phone'=>(string)($input['phone'] ?? ''),
        ], static fn($v)=>$v!=='');
        $requirements=['manual_completion'];
        if ($mode==='local_presence') $requirements[]='verify_business_profile';
        if ($ownerAction) $requirements[]='owner_action';
        return [
            'allowed'=>$reasons===[],
            'state'=>$reasons===[] ? 'assisted_package_ready' : 'blocked',
            'reasons'=>array_values(array_unique($reasons)),
            'package'=>(new AssistedDistributionPackage($destination,$mode,$fields,array_values(array_unique($requirements)),$ownerAction))->toArray(),
        ];
    }

    public function presenceHealth(array $input): array
    {
        $destination=(string)($input['destination'] ?? '');
        $def=$this->catalog->get($destination);
        if (!$def) return ['status'=>'unsupported'];
        $checks=['business_name','phone','website_or_booking_url','service_area'];
        $present=0;
        foreach ($checks as $check) if (!empty($input[$check])) $present++;
        return ['destination'=>$destination,'status'=>$present===count($checks)?'ready':'incomplete','score'=>(int)round(($present/count($checks))*100),'missing'=>array_values(array_filter($checks,fn($c)=>empty($input[$c])))];
    }
}
