<?php

namespace App\Extensions\TitanReachPro\System\Models;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TitanReachAnalysis extends Model
{
    protected $table = 'titan_reach_pro_analyses';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'type',
        'agent_id',
        'summary',
        'report_text',
        'created_at',
        'read_at',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'read_at'    => 'datetime',
    ];

    public function agent(): BelongsTo
    {
        return $this->belongsTo(TitanReachAgent::class, 'agent_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopeUnread($query)
    {
        return $query->whereNull('read_at');
    }

    public function markAsRead(): self
    {
        if (! $this->read_at) {
            $this->update(['read_at' => now()]);
        }

        return $this;
    }
}
