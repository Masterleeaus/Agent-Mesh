<?php

namespace App\Extensions\TitanReachPro\System\Console\Commands;

use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Services\Token\XRefreshAccessToken;
use Exception;
use Illuminate\Console\Command;

class XRefreshTokenCommand extends Command
{
    protected $signature = 'app:titan-reach-x-refresh';

    protected $description = 'Refresh token for X (formerly Twitter)';

    public function handle(): void
    {
        $tokens = TitanReachPlatform::query()
            ->where('platform', 'x')
            ->where('expires_at', '<', now()->subMinutes(10)->format('Y-m-d h:i:s'))
            ->get();

        $service = app(XRefreshAccessToken::class);

        foreach ($tokens as $token) {
            try {
                $service->setPlatform($token)->generate();

            } catch (Exception $exception) {

            }
        }
    }
}
