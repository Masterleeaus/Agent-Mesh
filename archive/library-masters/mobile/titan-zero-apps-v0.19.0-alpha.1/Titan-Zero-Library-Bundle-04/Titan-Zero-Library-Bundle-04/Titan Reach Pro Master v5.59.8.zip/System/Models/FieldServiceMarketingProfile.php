<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class FieldServiceMarketingProfile extends Model
{
    protected $table = 'titan_reach_pro_field_service_marketing_profiles';

    protected $fillable = [
        'company_id',
        'business_name',
        'vertical',
        'hours',
        'emergency_available',
        'contact_channels',
        'quote_url',
        'booking_url',
        'review_url',
        'licence_trust_statements',
        'seasonal_services',
        'brand_voice',
        'privacy_defaults',
        'completeness_score',
        'missing_fields',
    ];

    protected $casts = [
        'company_id'               => 'integer',
        'hours'                    => 'array',
        'emergency_available'      => 'boolean',
        'contact_channels'         => 'array',
        'licence_trust_statements' => 'array',
        'seasonal_services'        => 'array',
        'privacy_defaults'         => 'array',
        'completeness_score'       => 'integer',
        'missing_fields'           => 'array',
    ];

    public function services(): HasMany
    {
        return $this->hasMany(FieldServiceService::class, 'profile_id')->orderBy('sort_order')->orderBy('id');
    }

    public function serviceAreas(): HasMany
    {
        return $this->hasMany(FieldServiceServiceArea::class, 'profile_id')->orderBy('sort_order')->orderBy('id');
    }
}
