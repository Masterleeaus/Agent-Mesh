<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\PaidGrowth;

final class PaidGrowthDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly string $state,
        public readonly array $reasons = [],
        public readonly array $requirements = [],
        public readonly array $safePayload = [],
    ) {}

    public function toArray(): array
    {
        return [
            'allowed' => $this->allowed,
            'state' => $this->state,
            'reasons' => array_values(array_unique($this->reasons)),
            'requirements' => array_values(array_unique($this->requirements)),
            'payload' => $this->safePayload,
        ];
    }
}
