<?php

namespace App\Extensions\TitanReachPro\System\Enums;

enum LogStatusEnum: string
{
    case success = 'success';

    case expired = 'expired';

    case failed = 'failed';
}
