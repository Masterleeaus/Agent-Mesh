<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceAreaItem;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceServiceItem;
use App\Extensions\TitanReachPro\System\Models\FieldServiceMarketingProfile;
use Illuminate\Support\Facades\Schema;

class LocalFieldServiceContextProvider implements FieldServiceContextProvider
{
    public function resolve(?int $companyId = null, ?int $userId = null): FieldServiceContext
    {
        $companyId ??= $this->resolveCompanyId($userId);

        if (! $companyId || ! Schema::hasTable('titan_reach_pro_field_service_marketing_profiles')) {
            return FieldServiceContext::safeDefault($companyId);
        }

        $profile = FieldServiceMarketingProfile::query()
            ->with(['services', 'serviceAreas'])
            ->where('company_id', $companyId)
            ->first();

        if (! $profile) {
            return FieldServiceContext::safeDefault($companyId);
        }

        $services = $profile->services
            ->where('active', true)
            ->values()
            ->map(static fn ($service) => FieldServiceServiceItem::fromArray($service->toArray()))
            ->all();

        $areas = $profile->serviceAreas
            ->where('active', true)
            ->values()
            ->map(static fn ($area) => FieldServiceAreaItem::fromArray($area->toArray()))
            ->all();

        $data = [
            'business_name'            => $profile->business_name,
            'vertical'                 => $profile->vertical,
            'services'                 => $services,
            'service_areas'            => $areas,
            'hours'                    => $profile->hours ?: [],
            'contact_channels'         => $profile->contact_channels ?: [],
            'quote_url'                => $profile->quote_url,
            'booking_url'              => $profile->booking_url,
            'brand_voice'              => $profile->brand_voice,
            'privacy_defaults'         => $profile->privacy_defaults ?: [],
            'licence_trust_statements' => $profile->licence_trust_statements ?: [],
        ];

        [$score, $missing] = FieldServiceContext::calculateCompleteness($data);

        return new FieldServiceContext(
            companyId: $companyId,
            profileId: (int) $profile->id,
            businessName: $profile->business_name,
            vertical: $profile->vertical,
            services: $services,
            serviceAreas: $areas,
            hours: $profile->hours ?: [],
            emergencyAvailable: (bool) $profile->emergency_available,
            contactChannels: $profile->contact_channels ?: [],
            quoteUrl: $profile->quote_url,
            bookingUrl: $profile->booking_url,
            reviewUrl: $profile->review_url,
            licenceTrustStatements: $profile->licence_trust_statements ?: [],
            seasonalServices: $profile->seasonal_services ?: [],
            brandVoice: $profile->brand_voice ?: FieldServiceContext::safeDefault($companyId)->brandVoice,
            privacyDefaults: array_replace(FieldServiceContext::defaultPrivacy(), $profile->privacy_defaults ?: []),
            completenessScore: $score,
            missingFields: $missing,
            standaloneFallback: false,
        );
    }

    private function resolveCompanyId(?int $userId): ?int
    {
        $user = auth()->user();

        if (! $user && $userId && class_exists('App\\Models\\User')) {
            $user = app('App\\Models\\User')::query()->find($userId);
        }

        if (! $user) {
            return null;
        }

        foreach (['company_id', 'current_company_id'] as $field) {
            if (isset($user->{$field}) && $user->{$field}) {
                return (int) $user->{$field};
            }
        }

        return null;
    }
}
