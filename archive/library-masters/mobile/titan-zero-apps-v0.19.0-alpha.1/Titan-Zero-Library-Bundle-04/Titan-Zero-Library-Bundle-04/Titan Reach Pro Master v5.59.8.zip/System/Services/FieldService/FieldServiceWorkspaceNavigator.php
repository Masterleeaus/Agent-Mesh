<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\Support\FieldServiceMarketingPermissionGate;

class FieldServiceWorkspaceNavigator
{
    public function __construct(private readonly FieldServiceMarketingPermissionGate $permissions)
    {
    }

    public function module(): array
    {
        return [
            'key' => 'field_marketing_hub',
            'label' => 'Field Marketing Hub',
            'role' => 'Authoritative publisher',
            'workspace' => 'field_home_services_social_marketing',
        ];
    }

    public function links(?object $user = null, ?int $companyId = null): array
    {
        $links = [['label' => 'Create Post', 'path' => '/dashboard/user/titan-reach/post/create', 'action' => 'content'], ['label' => 'Campaigns', 'path' => '/dashboard/user/titan-reach/campaign', 'action' => 'campaigns'], ['label' => 'Calendar', 'path' => '/dashboard/user/titan-reach/calendar', 'action' => 'view'], ['label' => 'Marketing Context', 'path' => '/dashboard/user/titan-reach/field-service-profile', 'action' => 'context']];

        return array_map(function (array $link) use ($user, $companyId): array {
            $link['enabled'] = $this->permissions->allows($user, $link['action'], $companyId);
            $link['permission'] = $this->permissions->abilityFor($link['action']);

            return $link;
        }, $links);
    }

    public function crossExtensionLinks(): array
    {
        return [
            ['module' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'binding' => 'titan-reach.field-service.context'],
            ['module' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'binding' => 'titan-reach-agent.field-service.context'],
            ['module' => 'lead_review_automation', 'label' => 'Lead & Review Automation', 'binding' => 'titan-reach-flow.field-service.context'],
            ['module' => 'campaign_playbooks', 'label' => 'Campaign Playbooks', 'binding' => 'titan-reach-campaigns.field-service.context'],
        ];
    }
}
