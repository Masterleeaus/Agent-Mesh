<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

final class TitanReachDistributionBridge
{
    public function plan(array $item): array
    {
        if (($item['company_id'] ?? '') === '') { return [['destination'=>'all','status'=>'blocked','reasons'=>['company_id_required'],'approval_required'=>true,'assisted'=>false,'paid'=>false]]; }
        if (function_exists('app') && app()->bound('titan-reach.distribution.bridge')) { return app('titan-reach.distribution.bridge')->resolve($item); }
        return [['destination'=>'titan_reach_pro','status'=>'local_engine_available','reasons'=>['titan_reach_pro_distribution_engine_available'],'approval_required'=>true,'assisted'=>true,'paid'=>false]];
    }
}
