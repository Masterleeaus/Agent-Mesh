<?php

namespace App\Extensions\TitanReachPro\System\Console\Commands;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Helpers\Facebook;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use Exception;
use Illuminate\Console\Command;

class FacebookPostMetricsCommand extends Command
{
    protected $signature = 'app:titan-reach-facebook-post-metrics';

    protected $description = 'Post metrics for Facebook posts';

    public function handle(): void
    {
        $posts = TitanReachPost::query()
            ->where('titan_reach_platform', PlatformEnum::facebook->value)
            ->with('platform')
            ->where('post_metric_at', '<', now())
            ->get();

        foreach ($posts as $post) {
            try {

                /**
                 * @var TitanReachPlatform $platform
                 */
                $platform = $post->platform;

                if ($platform && $platform->isConnected()) {
                    $x = new Facebook(accessToken: $platform->credentials['access_token']);

                    $json = $x->getPostAnalytics($post['post_id']);

                    if ($json->successful()) {
                        $data = $json->json();
                    } else {
                        $data = [];
                    }

                    if (is_array($data) && isset($data['likes'])) {
                        $post->update([
                            'post_metrics'   => [
                                'like_count'    => $data['likes']['summary']['total_count'] ?? 0,
                                'comment_count' => $data['comments']['summary']['total_count'] ?? 0,
                                'share_count'   => $data['shares']['count'] ?? 0,
                                'view_count'    => $data['views']['summary']['total_count'] ?? 0,
                            ],
                            'post_metric_at' => now()->addMinutes(15),
                        ]);
                    }
                }
            } catch (Exception $exception) {

            }
        }
    }
}
