<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use App\Extensions\TitanReachPro\System\Services\PaidGrowth\PaidGrowthGovernanceService;

final class TitanReachPaidGrowthBridge
{
    public function __construct(private readonly PaidGrowthGovernanceService $governance) {}

    public function review(array $payload): array
    {
        return $this->governance->evaluate($payload)->toArray();
    }
}
