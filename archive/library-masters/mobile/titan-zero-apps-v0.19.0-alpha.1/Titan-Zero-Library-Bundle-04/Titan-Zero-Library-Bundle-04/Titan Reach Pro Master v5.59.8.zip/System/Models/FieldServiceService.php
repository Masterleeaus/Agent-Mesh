<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FieldServiceService extends Model
{
    protected $table = 'titan_reach_pro_field_service_services';

    protected $fillable = ['profile_id', 'company_id', 'name', 'description', 'active', 'sort_order'];

    protected $casts = [
        'profile_id' => 'integer',
        'company_id' => 'integer',
        'active'     => 'boolean',
        'sort_order' => 'integer',
    ];

    public function profile(): BelongsTo
    {
        return $this->belongsTo(FieldServiceMarketingProfile::class, 'profile_id');
    }
}
