<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDistributionEngine
{
    public function __construct(private readonly ?UnifiedReachDestinationCatalog $catalog = null) {}
    public function plan(UnifiedReachDistributionItem|array $item): array
    {
        $item = is_array($item) ? UnifiedReachDistributionItem::fromArray($item) : $item;
        if ($item->companyId === '') { return [new UnifiedReachDistributionDecision('all', 'blocked', ['company_id_required'], true, false, false)]; }
        $decisions = [];
        foreach (($this->catalog ?? new UnifiedReachDestinationCatalog())->all() as $destination) { $decisions[] = $this->decide($destination, $item); }
        return $decisions;
    }
    private function decide(UnifiedReachDestination $destination, UnifiedReachDistributionItem $item): UnifiedReachDistributionDecision
    {
        $status = 'eligible'; $reasons = [];
        if (! $destination->supportsContentType($item->contentType) && count(array_intersect($destination->contentTypes, $item->mediaTypes)) === 0) { $status = 'not_applicable'; $reasons[] = 'unsupported_content_type'; }
        foreach (['containsPriceClaim' => 'price_claim_requires_explicit_authorisation', 'containsLicenceClaim' => 'licence_claim_requires_configured_evidence', 'containsEmergencyClaim' => 'emergency_claim_requires_configured_availability', 'containsCustomerIdentity' => 'customer_identity_requires_consent', 'containsExactAddress' => 'exact_address_blocked', 'containsFacesOrPlates' => 'faces_or_plates_require_review'] as $property => $reason) { if ($item->{$property}) { $status = 'review_required'; $reasons[] = $reason; } }
        if ($destination->budgetApprovalRequired || $item->paidSpendRequested) { $status = 'approval_required'; $reasons[] = 'budget_or_paid_distribution_requires_owner_approval'; }
        if ($destination->verificationRequired) { $reasons[] = 'destination_verification_or_readiness_required'; }
        if ($destination->mode === 'assisted' || str_contains($destination->mode, 'assisted')) { $reasons[] = 'assisted_distribution_manual_completion_required'; }
        if ($reasons === []) { $reasons[] = 'ready_for_governed_distribution'; }
        return new UnifiedReachDistributionDecision($destination->key, $status, array_values(array_unique($reasons)), $destination->approvalRequired || $status !== 'eligible', $destination->mode === 'assisted' || str_contains($destination->mode, 'assisted'), str_contains($destination->mode, 'paid'));
    }
}
