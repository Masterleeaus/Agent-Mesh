<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System;

use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanReachPro\System\Http\Controllers\Common\DemoDataController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Common\TitanReachCampaignCommonController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Common\TitanReachCompanyCommonController;
use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\Services\Ai\ReachAiClient;
use App\Extensions\TitanReachPro\System\Services\Ai\ReachVideoGenerationClient;
use App\Extensions\TitanReachPro\System\Compatibility\Ai\LegacyVeoVideoClient;
use App\Extensions\TitanReachPro\System\Compatibility\Ai\LegacyReachAiClient;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Extensions\TitanReachPro\System\Http\Controllers\FieldServiceMarketingProfileController;
use App\Extensions\TitanReachPro\System\Http\Controllers\FieldServiceConversionController;
use App\Extensions\TitanReachPro\System\Http\Controllers\FieldServiceContentTemplateController;
use App\Extensions\TitanReachPro\System\Http\Controllers\ImageStatusController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\FacebookController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\InstagramController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\LinkedinController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\TiktokController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\XController;
use App\Extensions\TitanReachPro\System\Http\Controllers\Oauth\YoutubeController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachCalendarController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachCampaignController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachPlatformController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachPostController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachSettingController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachUploadController;
use App\Extensions\TitanReachPro\System\Http\Controllers\TitanReachVideoController;
use App\Extensions\TitanReachPro\System\Http\Controllers\FieldServiceWorkspaceController;
use App\Extensions\TitanReachPro\System\Http\Controllers\PaidGrowthGovernanceController;
use App\Extensions\TitanReachPro\System\Navigation\TitanReachMenuInstaller;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use App\Extensions\TitanReachPro\System\Services\FieldService\LocalFieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\Services\FieldService\CampaignPlaybookHandoffReceiver;
use Illuminate\Support\ServiceProvider;

class TitanReachProServiceProvider extends ServiceProvider implements UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-reach-pro', \App\Extensions\TitanReachPro\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton(ReachCompanyContext::class);
        $this->app->singleton(ReachAiClient::class);
        $this->app->singleton(ReachVideoGenerationClient::class);
        $this->app->singleton(LegacyVeoVideoClient::class);
        $this->app->alias(LegacyVeoVideoClient::class, ReachVideoGenerationClient::LEGACY_FALLBACK_BINDING);
        $this->app->singleton(LegacyReachAiClient::class);
        $this->app->alias(LegacyReachAiClient::class, ReachAiClient::LEGACY_FALLBACK_BINDING);
        $this->app->singleton('field-service.live-install-evidence.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\LiveInstallerEvidenceCapture::class);
        $this->app->singleton('field-service.commercial.enforcement-upgrade-ux.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\CommercialTierEnforcementUpgradeUX::class);
        $this->app->singleton('field-service.local-growth-operational-trial.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\LocalGrowthAgentOperationalTrial::class);
        $this->app->singleton('field-service.hub-workflow-trial.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\FieldMarketingHubWorkflowTrial::class);
        $this->app->singleton('field-service.webhook-dry-run.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\RealWebhookAutomationDryRun::class);
        $this->app->singleton('field-service.migration-compatibility.titan_reach_pro', \App\Extensions\TitanReachPro\System\Support\DatabaseMigrationUpgradeCompatibility::class);
        $this->app->singleton('field-service.runtime-repair.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\RuntimeMenuRouteBladeRepair::class);
        $this->app->singleton('field-service.commercial.plan-limits.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\FieldServiceCommercialPlanLimits::class);
        $this->app->singleton('field-service.workspace.navigator.field_marketing_hub', \App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceWorkspaceNavigator::class);
        $this->app->singleton('field-service.workspace.health.field_marketing_hub', \App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceWorkspaceHealth::class);
        $this->registerConfig();
        $this->app->singleton(\App\Extensions\TitanReachPro\System\Services\PaidGrowth\PaidGrowthChannelCatalog::class);
        $this->app->singleton(\App\Extensions\TitanReachPro\System\Services\PaidGrowth\PaidGrowthGovernanceService::class);
        $this->app->singleton('titan-reach.paid-growth', \App\Extensions\TitanReachPro\System\Support\TitanReachPaidGrowthBridge::class);

        $this->app->singleton(FieldServiceContextProvider::class, LocalFieldServiceContextProvider::class);
        $this->app->alias(FieldServiceContextProvider::class, 'titan-reach.field-service.context');
        $this->app->singleton('titan-reach.field-service.campaign-playbook-handoff', CampaignPlaybookHandoffReceiver::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->registerMigrations()
            ->publishAssets()
            ->registerComponents()
            ->registerCommand();

        $this->app->booted(static function (): void { TitanReachMenuInstaller::healIfNeeded(); });
    }

    public function registerCommand(): static
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                Console\Commands\PublishedCommand::class,
                Console\Commands\XRefreshTokenCommand::class,
                Console\Commands\XPostMetricsCommand::class,
                Console\Commands\FacebookPostMetricsCommand::class,
                Console\Commands\InstagramPostMetricsCommand::class,
                Console\Commands\TitanReachDailyMetricsCommand::class,
                Console\Commands\TitanReachFollowersSyncCommand::class,
            ]);

            $this->app->booted(function () {
                $schedule = $this->app->make(Schedule::class);
                $schedule->command('app:titan-reach-published-command')->everyTwoMinutes()->withoutOverlapping(5);
                $schedule->command('app:titan-reach-x-refresh')->everyThreeMinutes()->withoutOverlapping(8);
                $schedule->command('app:titan-reach-facebook-post-metrics')->everyThreeMinutes()->withoutOverlapping(8);
                $schedule->command('app:titan-reach-instagram-post-metrics')->everyThreeMinutes()->withoutOverlapping(8);
                $schedule->command('app:titan-reach-daily-metrics')->hourly()->withoutOverlapping(30);
                $schedule->command('app:titan-reach-sync-followers')->hourly()->withoutOverlapping(30);
            });
        }

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-webhook-dry-run.php', 'field-service-webhook-dry-run.' . self::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-final-customer-release.php', 'field-service-final-customer-release.' . self::class);
        $this->app->singleton('field-service-final-customer-release.' . self::class, fn () => new \App\Extensions\TitanReachPro\System\Support\FinalCustomerReleaseCandidate());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-inbox.php', 'titan-reach-inbox.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-paid-growth.php', 'titan-reach-paid-growth.' . self::class);
        $this->app->singleton('titan-reach.inbox.bridge.' . self::class, \App\Extensions\TitanReachPro\System\Support\TitanReachInboxBridge::class);
        return $this;
    }

    public function registerComponents(): static
    {
        //        $this->loadViewComponentsAs('example', []);

        return $this;
    }

    public function publishAssets(): static
    {
        $this->publishes([
            __DIR__ . '/../resources/assets' => public_path('vendor/titan-reach'),
        ], 'extension');

        return $this;
    }

    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-titan-zero-closed-loop.php', 'titan-reach-titan-zero-closed-loop.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-production-release.php', 'titan-reach-production-release.' . self::class);
        $this->app->singleton('titan-reach.production-release.' . self::class, \App\Extensions\TitanReachPro\System\Support\TitanReachProductionRelease::class);
        $this->app->singleton('titan-reach.titan-zero.closed-loop.' . self::class, \App\Extensions\TitanReachPro\System\Support\TitanZeroClosedLoopBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-presence.php', 'titan-reach-local-presence.' . self::class);
        $this->app->singleton(\App\Extensions\TitanReachPro\System\Services\LocalPresence\LocalPresenceHealthEngine::class);
        $this->app->alias(\App\Extensions\TitanReachPro\System\Services\LocalPresence\LocalPresenceHealthEngine::class, 'titan-reach.local-presence.engine');
        $this->app->singleton('titan-reach.local-presence.bridge.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\TitanReachLocalPresenceBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-reputation.php', 'titan-reach-reputation.' . self::class);
        $this->app->singleton('titan-reach.reputation.bridge.field_marketing_hub', \App\Extensions\TitanReachPro\System\Support\TitanReachReputationBridge::class);
        $this->app->singleton('titan-reach.reputation.engine', \App\Extensions\TitanReachPro\System\Services\Reputation\GoogleBusinessProfileReputationEngine::class);
        $this->app->singleton('titan-reach.google-business-profile.readiness', \App\Extensions\TitanReachPro\System\Services\Reputation\GoogleBusinessProfileReadinessService::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-distribution.php', 'titan-reach-distribution');
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-distribution.php', 'titan-reach-local-distribution');
        $this->app->singleton(\App\Extensions\TitanReachPro\System\Services\LocalDistribution\LocalDistributionDestinationCatalog::class);
        $this->app->singleton(\App\Extensions\TitanReachPro\System\Services\LocalDistribution\AssistedDistributionPlanner::class);
        $this->app->singleton('titan-reach.local-distribution', \App\Extensions\TitanReachPro\System\Support\TitanReachLocalDistributionBridge::class);
        $this->app->singleton('titan-reach.distribution.bridge.titan_reach_pro', \App\Extensions\TitanReachPro\System\Support\TitanReachDistributionBridge::class);
        $this->app->singleton('titan-reach.distribution.catalog', \App\Extensions\TitanReachPro\System\Services\Distribution\UnifiedReachDestinationCatalog::class);
        $this->app->singleton('titan-reach.distribution.engine', \App\Extensions\TitanReachPro\System\Services\Distribution\UnifiedReachDistributionEngine::class);
        $this->app->singleton('titan-reach.distribution.bridge', \App\Extensions\TitanReachPro\System\Services\Distribution\UnifiedReachDistributionBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach.php', 'titan-reach');
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-events.php', 'field-service-events.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-workspace.php', 'field-service-workspace.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-production.php', 'field-service-production.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime.php', 'field-service-runtime.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-smoke.php', 'field-service-runtime-smoke.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-lead-flow-simulation.php', 'field-service-lead-flow-simulation.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-publish-governance.php', 'field-service-publish-governance.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial.php', 'field-service-commercial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-demo-showcase.php', 'field-service-demo-showcase.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-certification.php', 'field-service-runtime-certification.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-installer-diagnostics.php', 'field-service-live-installer-diagnostics.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-repair.php', 'field-service-runtime-repair.' . self::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-migration-compatibility.php', 'field-service-migration-compatibility.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hub-workflow-trial.php', 'field-service-hub-workflow-trial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial-enforcement.php', 'field-service-commercial-enforcement.' . self::class);



        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-install-evidence.php', 'field-service-live-install-evidence.' . self::class);
        $this->app->singleton('field-service-live-install-evidence.' . self::class, fn () => new \App\Extensions\TitanReachPro\System\Support\LiveInstallerEvidenceCapture());

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hotfix-intake.php', 'field-service-hotfix-intake.' . self::class);
        $this->app->singleton('field-service-hotfix-intake.' . self::class, fn () => new \App\Extensions\TitanReachPro\System\Support\DiagnosticsDrivenHotfixIntake());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-growth-intelligence.php', 'titan-reach-growth-intelligence.' . self::class);
        $this->app->singleton('titan-reach.growth-intelligence.bridge.' . self::class, \App\Extensions\TitanReachPro\System\Support\TitanReachGrowthIntelligenceBridge::class);
        return $this;
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'titan-reach');

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], 'titan-reach');

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }

    private function registerRoutes(): static
    {
        $this->router()
            ->group([
                'middleware' => ['web', 'auth'],

            ], function (Router $router) {

                $router->get('tiktok/verify', [TiktokController::class, 'verify'])->name('tiktok.verify');

                $router->get('titan-reach-demo-data', DemoDataController::class)->name('demo-data');


                $router->group([
                    'prefix'     => 'titan-reach/oauth',
                ], function (Router $router) {
                    $router->get('redirect/tiktok', [TiktokController::class, 'redirect'])->name('titan-reach.oauth.connect.tiktok');
                    $router->get('callback/tiktok', [TiktokController::class, 'callback'])->name('titan-reach.oauth.callback.tiktok');

                    $router->get('redirect/instagram', [InstagramController::class, 'redirect'])->name('titan-reach.oauth.connect.instagram');
                    $router->get('callback/instagram', [InstagramController::class, 'callback'])->name('titan-reach.oauth.callback.instagram');

                    $router->get('redirect/x', [XController::class, 'redirect'])->name('titan-reach.oauth.connect.x');
                    $router->get('callback/x', [XController::class, 'callback'])->name('titan-reach.oauth.callback.x');

                    $router->get('redirect/facebook', [FacebookController::class, 'redirect'])->name('titan-reach.oauth.connect.facebook');
                    $router->get('callback/facebook', [FacebookController::class, 'callback'])->name('titan-reach.oauth.callback.facebook');

                    $router->get('redirect/linkedin', [LinkedinController::class, 'redirect'])->name('titan-reach.oauth.connect.linkedin');
                    $router->get('callback/linkedin', [LinkedinController::class, 'callback'])->name('titan-reach.oauth.callback.linkedin');

                    $router->get('redirect/youtube', [YoutubeController::class, 'redirectYoutube'])->name('titan-reach.oauth.connect.youtube');
                    $router->get('callback/youtube', [YoutubeController::class, 'callbackYoutube'])->name('titan-reach.oauth.callback.youtube');

                    $router->get('redirect/youtube-shorts', [YoutubeController::class, 'redirectYoutubeShorts'])->name('titan-reach.oauth.connect.youtube-shorts');
                    $router->get('callback/youtube-shorts', [YoutubeController::class, 'callbackYoutubeShorts'])->name('titan-reach.oauth.callback.youtube-shorts');
                });

                $router
                    ->name('dashboard.user.titan-reach.')
                    ->prefix('dashboard/user/titan-reach')
                    ->group(function (Router $router) {
                        $router->get('field-service-workspace', FieldServiceWorkspaceController::class)->name('field-service-workspace');

                        $router->get('post', [TitanReachPostController::class, 'index'])->name('post.index');
                        $router->get('post/create', [TitanReachPostController::class, 'create'])->name('post.create');
                        $router->get('post/{post}/edit', [TitanReachPostController::class, 'edit'])->name('post.edit');
                        $router->post('post/{post}/update', [TitanReachPostController::class, 'update'])->name('post.update');
                        $router->get('post/{id}', [TitanReachPostController::class, 'show'])->name('post.show');
                        $router->post('post', [TitanReachPostController::class, 'store'])->name('post.store');
                        $router->post('post/{post}/duplicate', [TitanReachPostController::class, 'duplicate'])->name('post.duplicate');
                        $router->delete('post/{post}', [TitanReachPostController::class, 'destroy'])->name('post.delete');
                        $router->post('upload/image', [TitanReachUploadController::class, 'image'])->name('upload.image');
                        $router->post('upload/video', [TitanReachUploadController::class, 'video'])->name('upload.video');

                        $router->get('', TitanReachController::class)->name('index');
                        $router->get('field-service-profile', [FieldServiceMarketingProfileController::class, 'edit'])->name('field-service-profile.edit');
                        $router->patch('field-service-profile', [FieldServiceMarketingProfileController::class, 'update'])->name('field-service-profile.update');
                        $router->post('field-service-template/preview', [FieldServiceContentTemplateController::class, 'preview'])->name('field-service-template.preview');
                        $router->post('field-service-conversion', [FieldServiceConversionController::class, 'store'])->name('field-service-conversion.store');
                        $router->get('platforms', TitanReachPlatformController::class)->name('platforms');
                        $router->delete('platforms/{platform}', [TitanReachPlatformController::class, 'disconnect'])->name('platforms.disconnect');
                        $router->post('campaign/generate', [TitanReachCampaignController::class, 'generate'])->name('campaign.generate');
                        $router->any('image/get-status', ImageStatusController::class)->name('image.get.status');

                        $router->delete('campaign/{campaign}', [TitanReachCampaignController::class, 'destroy'])->name('campaign.destroy');
                        $router->resource('campaign', TitanReachCampaignController::class)->only('index', 'store');
                        $router->post('paid-growth/review', PaidGrowthGovernanceController::class)->name('paid-growth.review');

                        $router->get('calendar', TitanReachCalendarController::class)->name('calendar');

                        $router->post('video/generate', TitanReachVideoController::class)->name('video.generate');

                        $router->get('video/status', [TitanReachVideoController::class, 'status'])->name('video.status');
                    });

                $router
                    ->name('dashboard.user.titan-reach.common.')
                    ->prefix('dashboard/user/titan-reach/common')
                    ->group(function (Router $router) {
                        $router->get('companies', TitanReachCompanyCommonController::class)->name('companies');
                        $router->post('campaigns', TitanReachCampaignCommonController::class)->name('campaigns');
                        $router->get('generate-content', [TitanReachCampaignCommonController::class, 'generate'])->name('campaigns.generate.content');
                    });

                $router->post(
                    'genContent', [TitanReachCampaignCommonController::class, 'generate']
                )
                    ->name('dashboard.user.automation.campaign.genContent')
                    ->prefix('dashboard/user/automation/campaign');

                $router
                    ->middleware('admin')
                    ->prefix('dashboard/admin/titan-reach/setting')
                    ->name('dashboard.admin.titan-reach.setting.')
                    ->controller(TitanReachSettingController::class)
                    ->group(function () {
                        Route::get('', 'index')->name('index');
                        Route::post('{platform}/update', 'update')->name('update');
                    });

            });



        $this->router()
            ->group([
                'middleware' => ['throttle:60,1'],
            ], function (Router $router) {
                $router->match(['GET', 'POST'], 'titan-reach/webhook/instagram', [InstagramController::class, 'webhook'])->name('titan-reach.oauth.webhook.instagram');
                $router->match(['GET', 'POST'], 'titan-reach/webhook/facebook', [FacebookController::class, 'webhook'])->name('titan-reach.oauth.webhook.facebook');
            });

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    public static function uninstall(): void
    {
        // No extension-owned host state requires destructive uninstall work.
    }
}
