<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Services\Ai\ReachVideoGenerationClient;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TitanReachVideoController extends Controller
{
    public function __construct(
        private readonly ReachCompanyContext $companyContext,
        private readonly ReachVideoGenerationClient $video,
    ) {}

    public function __invoke(Request $request): JsonResponse
    {
        $request->validate(['prompt' => 'required', 'company_id' => 'sometimes|nullable|integer']);
        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());

        try {
            $generate = $this->video->generate((string) $request->get('prompt'), $companyId);
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage(), 'status' => 'error'], 422);
        }

        if (($generate['status'] ?? null) === 'IN_QUEUE' && ! empty($generate['request_id'])) {
            session([$this->sessionKey($companyId) => (string) $generate['request_id']]);
            session()->save();
            return response()->json(['status' => 'success', 'message' => trans('Video is generating...')]);
        }

        return response()->json(['message' => 'Video could not be generated.', 'status' => 'error'], 422);
    }

    public function status(Request $request): JsonResponse
    {
        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        $videoId = session($this->sessionKey($companyId));

        if (! $videoId) {
            return response()->json(['success' => false, 'message' => __('Video ID not found.'), 'status' => 'not_found'], 404);
        }

        try {
            $status = $this->video->status((string) $videoId, $companyId);
        } catch (Exception $e) {
            return response()->json(['message' => trans('Video is not completed.'), 'status' => 'error'], 422);
        }

        if (($status['status'] ?? null) === 'COMPLETED' && ! empty($status['video_path'])) {
            return response()->json(['status' => 'COMPLETED', 'video_path' => $status['video_path']]);
        }

        if (($status['status'] ?? null) === 'IN_PROGRESS') {
            return response()->json(['status' => 'IN_PROGRESS', 'message' => trans('Video is processing..')]);
        }

        return response()->json(['message' => trans('Video is not completed.'), 'status' => 'ERROR'], 422);
    }

    private function sessionKey(int $companyId): string
    {
        return 'video_id_' . Auth::id() . '_company_' . $companyId;
    }
}
