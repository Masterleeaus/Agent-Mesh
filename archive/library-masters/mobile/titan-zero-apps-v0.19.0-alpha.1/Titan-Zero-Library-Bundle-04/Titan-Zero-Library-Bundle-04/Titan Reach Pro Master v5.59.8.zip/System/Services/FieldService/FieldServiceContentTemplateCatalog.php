<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\DTO\FieldServiceAreaItem;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceServiceItem;
use App\Extensions\TitanReachPro\System\Support\FieldServiceMediaPrivacyPolicy;

class FieldServiceContentTemplateCatalog
{
    /**
     * Templates are intentionally conservative. They expose field/home-service
     * content lanes without inventing unsupported service areas, emergency
     * availability, prices, licences, or customer details.
     */
    public function all(): array
    {
        return [
            'completed_job' => [
                'label' => 'Completed job',
                'description' => 'A safe local job-completion update without exact addresses or customer names.',
                'requires_service' => true,
                'requires_area' => true,
                'privacy_level' => 'job_safe',
            ],
            'before_after' => [
                'label' => 'Before & after',
                'description' => 'A consent-gated transformation post for approved worksite media.',
                'requires_service' => true,
                'requires_area' => true,
                'privacy_level' => 'media_consent_required',
            ],
            'seasonal_reminder' => [
                'label' => 'Seasonal reminder',
                'description' => 'A seasonal maintenance nudge based only on configured services.',
                'requires_service' => true,
                'requires_area' => false,
                'privacy_level' => 'public_safe',
            ],
            'service_spotlight' => [
                'label' => 'Service spotlight',
                'description' => 'A practical explanation of one active service.',
                'requires_service' => true,
                'requires_area' => false,
                'privacy_level' => 'public_safe',
            ],
            'neighbourhood_availability' => [
                'label' => 'Neighbourhood availability',
                'description' => 'A local availability post for an explicitly configured service area.',
                'requires_service' => true,
                'requires_area' => true,
                'privacy_level' => 'public_safe',
            ],
            'maintenance_tip' => [
                'label' => 'Maintenance tip',
                'description' => 'A helpful, non-diagnostic maintenance tip that avoids guarantees.',
                'requires_service' => true,
                'requires_area' => false,
                'privacy_level' => 'public_safe',
            ],
            'review_request' => [
                'label' => 'Review request',
                'description' => 'A polite review CTA; only includes review URL when configured.',
                'requires_service' => false,
                'requires_area' => false,
                'privacy_level' => 'public_safe',
            ],
            'emergency_availability' => [
                'label' => 'Emergency availability',
                'description' => 'Shown only when emergency availability is explicitly enabled.',
                'requires_service' => true,
                'requires_area' => false,
                'privacy_level' => 'high_claim_sensitivity',
            ],
            'schedule_opening' => [
                'label' => 'Schedule opening',
                'description' => 'A safe post to fill calendar gaps without promising unconfirmed times.',
                'requires_service' => true,
                'requires_area' => true,
                'privacy_level' => 'public_safe',
            ],
            'recurring_service' => [
                'label' => 'Recurring service reminder',
                'description' => 'A reminder for repeat maintenance/service plans without invented pricing.',
                'requires_service' => true,
                'requires_area' => false,
                'privacy_level' => 'public_safe',
            ],
        ];
    }

    public function options(FieldServiceContext $context): array
    {
        $services = array_map(static fn (FieldServiceServiceItem $item): array => $item->toArray(), $context->services);
        $areas = array_map(static fn (FieldServiceAreaItem $item): array => $item->toArray(), $context->serviceAreas);

        return [
            'templates' => $this->all(),
            'services' => $services,
            'service_areas' => $areas,
            'guardrails' => $this->guardrails($context),
            'emergency_enabled' => $context->emergencyAvailable,
            'review_url_configured' => filled($context->reviewUrl),
            'quote_url_configured' => filled($context->quoteUrl),
            'booking_url_configured' => filled($context->bookingUrl),
        ];
    }

    public function render(string $templateKey, FieldServiceContext $context, ?string $serviceName = null, ?string $areaName = null, ?string $cta = null): array
    {
        $templates = $this->all();
        if (! isset($templates[$templateKey])) {
            $templateKey = 'service_spotlight';
        }

        $serviceName = $this->safePick($serviceName, $this->serviceNames($context));
        $areaName = $this->safePick($areaName, $this->areaNames($context));
        $businessName = $context->businessName ?: 'our local team';
        $vertical = $context->vertical ?: 'home service';
        $ctaLine = $this->ctaLine($context, $cta);
        $trustLine = $this->trustLine($context);

        if ($templateKey === 'emergency_availability' && ! $context->emergencyAvailable) {
            return [
                'content' => 'Emergency availability is not enabled in the field-service profile, so this template is disabled until it is explicitly configured.',
                'disabled' => true,
                'reason' => 'emergency_not_configured',
                'guardrails' => $this->guardrails($context),
            ];
        }

        if ($templates[$templateKey]['requires_service'] && ! $serviceName) {
            return $this->missing('service', $context);
        }

        if ($templates[$templateKey]['requires_area'] && ! $areaName) {
            return $this->missing('service area', $context);
        }

        $content = match ($templateKey) {
            'completed_job' => "Another {$serviceName} job completed in {$areaName}. {$businessName} helps local {$vertical} customers keep work moving with practical, tidy service and clear communication. {$ctaLine}",
            'before_after' => "Before-and-after from a recent {$serviceName} job in {$areaName}. Shared only with approval and without customer names or exact addresses. {$ctaLine}",
            'seasonal_reminder' => "Seasonal reminder: now is a good time to check whether your {$serviceName} needs attention before small issues become bigger jobs. {$businessName} can help with practical advice and service. {$ctaLine}",
            'service_spotlight' => "Service spotlight: {$serviceName}. {$businessName} supports local {$vertical} customers with clear communication, careful work and no unsupported claims. {$ctaLine}",
            'neighbourhood_availability' => "We service {$areaName} for {$serviceName}. If you are nearby and need a reliable local {$vertical} team, {$businessName} can help. {$ctaLine}",
            'maintenance_tip' => "Maintenance tip for {$serviceName}: keep an eye on early warning signs and book help before the issue becomes disruptive. {$businessName} can inspect, advise and help you plan the next step. {$ctaLine}",
            'review_request' => "Happy with the service from {$businessName}? A quick review helps local customers choose with more confidence." . ($context->reviewUrl ? " Review here: {$context->reviewUrl}" : ''),
            'emergency_availability' => "Need urgent help with {$serviceName}? {$businessName} has emergency availability configured. Use the contact details in our profile so the team can triage your request quickly. {$ctaLine}",
            'schedule_opening' => "We have room to help with {$serviceName} in {$areaName}. If this has been sitting on your list, now is a good time to request a quote or booking. {$ctaLine}",
            'recurring_service' => "Recurring {$serviceName} helps keep your property easier to manage over time. {$businessName} can help you plan a practical service rhythm without guesswork. {$ctaLine}",
            default => "{$businessName} can help with {$serviceName}. {$ctaLine}",
        };

        if ($trustLine !== '') {
            $content .= ' ' . $trustLine;
        }

        return [
            'content' => trim(preg_replace('/\s+/', ' ', $content)),
            'disabled' => false,
            'template' => $templateKey,
            'privacy_level' => $templates[$templateKey]['privacy_level'],
            'guardrails' => $this->guardrails($context),
        ];
    }

    public function guardrails(FieldServiceContext $context): array
    {
        $privacy = $context->privacyDefaults ?: FieldServiceContext::defaultPrivacy();

        return [
            'Do not invent licences, insurance, certifications, prices, discounts, emergency availability, or service areas.',
            'Do not include exact street addresses, customer names, faces, vehicle plates, or private job details unless the business has explicit permission.',
            'Only mention emergency service when emergency availability is explicitly enabled.',
            'Only mention quote, booking, or review links when those URLs are configured.',
            ($privacy['require_human_review'] ?? true) ? 'Human review is required before publishing job-site or customer-adjacent content.' : 'Human review is still recommended for job-site or customer-adjacent content.',
            FieldServiceMediaPrivacyPolicy::promptGuardrails($context),
        ];
    }

    private function missing(string $what, FieldServiceContext $context): array
    {
        return [
            'content' => "Add at least one active {$what} to the Field Service Marketing Profile before using this template.",
            'disabled' => true,
            'reason' => 'missing_' . str_replace(' ', '_', $what),
            'guardrails' => $this->guardrails($context),
        ];
    }

    private function serviceNames(FieldServiceContext $context): array
    {
        return array_values(array_filter(array_map(static fn (FieldServiceServiceItem $service): ?string => $service->name, $context->services)));
    }

    private function areaNames(FieldServiceContext $context): array
    {
        return array_values(array_filter(array_map(static fn (FieldServiceAreaItem $area): ?string => $area->name, $context->serviceAreas)));
    }

    private function safePick(?string $requested, array $allowed): ?string
    {
        $requested = is_string($requested) ? trim($requested) : null;
        if ($requested !== '' && in_array($requested, $allowed, true)) {
            return $requested;
        }

        return $allowed[0] ?? null;
    }

    private function ctaLine(FieldServiceContext $context, ?string $cta): string
    {
        return match ($cta) {
            'booking' => $context->bookingUrl ? "Book here: {$context->bookingUrl}" : 'Message us to check availability.',
            'review' => $context->reviewUrl ? "Review us here: {$context->reviewUrl}" : 'Your feedback helps local customers choose with confidence.',
            'contact' => 'Contact us through the configured business channels to discuss the job.',
            default => $context->quoteUrl ? "Request a quote: {$context->quoteUrl}" : 'Message us to request a quote.',
        };
    }

    private function trustLine(FieldServiceContext $context): string
    {
        $statements = array_values(array_filter($context->licenceTrustStatements));
        if ($statements === []) {
            return '';
        }

        return $statements[0];
    }
}
