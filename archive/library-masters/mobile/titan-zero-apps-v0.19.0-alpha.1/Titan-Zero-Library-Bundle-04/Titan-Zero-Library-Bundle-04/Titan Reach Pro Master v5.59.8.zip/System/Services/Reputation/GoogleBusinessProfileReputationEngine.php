<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Reputation;

final class GoogleBusinessProfileReputationEngine
{
    public function __construct(
        private readonly GoogleBusinessProfileReadinessService $readiness = new GoogleBusinessProfileReadinessService(),
        private readonly ReputationGovernanceService $governance = new ReputationGovernanceService(),
    ) {
    }

    /** @param array<string,mixed> $context @return array<string,mixed> */
    public function plan(array $context): array
    {
        $readiness = $this->readiness->evaluate($context);

        return [
            'destination' => 'google_business_profile',
            'readiness' => $readiness,
            'actions' => [
                'sync_locations',
                'prepare_local_post',
                'prepare_photo_upload',
                'review_reply_queue',
                'performance_signal_sync',
            ],
            'safety' => [
                'human_approval_required_for_review_replies' => true,
                'no_customer_identity_in_public_posts' => true,
                'no_invented_licence_price_or_emergency_claims' => true,
            ],
        ];
    }

    /** @return array<string,mixed> */
    public function classifyReviewForReply(string $body, int $rating): array
    {
        return $this->governance->classifyReview($body, $rating);
    }
}
