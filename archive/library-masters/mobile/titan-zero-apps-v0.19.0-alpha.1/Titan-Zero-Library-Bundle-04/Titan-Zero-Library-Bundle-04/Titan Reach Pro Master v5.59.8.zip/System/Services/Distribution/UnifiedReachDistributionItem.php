<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Distribution;

final class UnifiedReachDistributionItem
{
    public function __construct(public readonly string $companyId, public readonly string $objective, public readonly string $contentType, public readonly array $mediaTypes = [], public readonly array $services = [], public readonly array $serviceAreas = [], public readonly bool $containsPriceClaim = false, public readonly bool $containsLicenceClaim = false, public readonly bool $containsEmergencyClaim = false, public readonly bool $containsCustomerIdentity = false, public readonly bool $containsExactAddress = false, public readonly bool $containsFacesOrPlates = false, public readonly bool $paidSpendRequested = false) {}
    public static function fromArray(array $data): self { return new self((string) ($data['company_id'] ?? ''), (string) ($data['objective'] ?? 'local_awareness'), (string) ($data['content_type'] ?? 'text'), array_values($data['media_types'] ?? []), array_values($data['services'] ?? []), array_values($data['service_areas'] ?? []), (bool) ($data['contains_price_claim'] ?? false), (bool) ($data['contains_licence_claim'] ?? false), (bool) ($data['contains_emergency_claim'] ?? false), (bool) ($data['contains_customer_identity'] ?? false), (bool) ($data['contains_exact_address'] ?? false), (bool) ($data['contains_faces_or_plates'] ?? false), (bool) ($data['paid_spend_requested'] ?? false)); }
}
