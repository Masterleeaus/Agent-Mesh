<?php

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Models\TitanReachCampaign;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceAttributionService;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceCampaignObjectiveCatalog;
use App\Extensions\TitanReachPro\System\Services\Ai\ReachAiClient;
use App\Extensions\TitanReachPro\System\Support\ReachCompanyContext;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use App\Models\Company;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class TitanReachCampaignController extends Controller
{
    public function __construct(
        private readonly ReachCompanyContext $companyContext,
        private readonly ReachAiClient $ai,
        private readonly FieldServiceAttributionService $attributionService = new FieldServiceAttributionService(),
        private readonly FieldServiceCampaignObjectiveCatalog $objectiveCatalog = new FieldServiceCampaignObjectiveCatalog(),
    ) {
    }

    public function index(): View
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());

        return view('titan-reach::campaign.index', [
            'items' => TitanReachCampaign::query()->where('user_id', Auth::id())->where('company_id', $companyId)->get(),
            'fieldServiceObjectives' => $this->objectiveCatalog->all(),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        if (Helper::appIsDemo()) {
            return response()->json([
                'type'    => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        $request->validate([
            'cam_name'            => 'required|string',
            'cam_target'          => 'required|string',
            'field_service_objective' => ['nullable', 'string', 'in:' . implode(',', $this->objectiveCatalog->keys())],
            'conversion_goal' => ['nullable', 'string', 'max:80'],
            'company_id' => ['nullable', 'integer'],
        ]);

        $companyId = $this->companyContext->resolve($request->integer('company_id') ?: null, Auth::id());
        $campaign = TitanReachCampaign::query()->create([
            'user_id'         => Auth::id(),
            'company_id'      => $companyId,
            'name'            => $request->get('cam_name'),
            'target_audience' => $request->get('cam_target'),
            'field_service_objective' => $request->get('field_service_objective'),
            'conversion_goal' => $request->get('conversion_goal') ?: $this->objectiveCatalog->defaultGoalFor($request->get('field_service_objective')),
            'field_service_source_context' => [
                'source' => 'field_marketing_hub',
                'standalone_safe' => true,
            ],
        ]);

        $this->attributionService->ensureCampaignAttribution($campaign);

        return response()->json([
            'status'  => 'success',
            'message' => trans('Campaign created successfully'),
        ]);
    }

    public function destroy(TitanReachCampaign $campaign): RedirectResponse
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());
        abort_unless((int) $campaign->user_id === (int) Auth::id() && (int) $campaign->company_id === $companyId, 404);

        $campaign->delete();

        return back()->with(['message' => trans('Deleted Successfully'), 'type' => 'success']);
    }

    public function generate(Request $request): JsonResponse
    {
        $request->validate(['platform' => 'required|string']);

        if (Helper::appIsDemo()) {
            return response()->json([
                'type'    => 'error',
                'message' => trans('This feature is disabled in demo mode.'),
            ]);
        }

        try {
            $response = match ((bool) $request->get('is_personalized_content')) {
                true  => $this->hasPersonalizedContent($request),
                false => $this->hasNotPersonalizedContent($request),
            };


            return response()->json([
                'result' => $response,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'type'    => 'error',
            ], 500);
        }
    }

    private function hasPersonalizedContent(Request $request): string
    {
        $platform = $request->get('platform');

        $limit = config('titan-reach.' . $platform . '.requirements.text.limit');

        $companyId = $this->companyContext->resolve($request->integer('selected_company') ?: null, Auth::id());
        $company = Company::query()->where('user_id', Auth::id())->findOrFail($companyId);

        $product = $company?->products()->where('id', $request->get('selected_product'))->first();

        $campaign = TitanReachCampaign::query()->where('company_id', $companyId)->where('user_id', Auth::id())->find($request->get('campaign_id'));

        $limit = (int) $limit;
        $platform = ucfirst($platform);
        $tone = $request['tone'];
        $content = $request['content'];

        $brandTone = $company?->tone ?? 'brand tone';
        $brandDesc = $company?->description ?? 'brand description';
        $productDesc = $product?->description ?? 'product description';
        $campaignName = $campaign?->name ?? 'campaign';

        $systemPrompt = "You are a Titan Reach content creator. Generate engaging and attention-grabbing content that does not exceed {$limit} characters under any circumstances for {$platform}, including emojis.";

        $userPrompt = <<<EOT
		Create an engaging {$platform}-style post using the following input: "{$content}".
		The post should be {$tone} and optimized for engagement.
		Strictly keep it within {$limit} characters including emojis and punctuation.
		Include relevant hashtags, emojis, and a strong call to action.
		Ensure the post aligns with the brand’s {$brandTone}, {$brandDesc}, and {$productDesc}.
		The post should also resonate with the target audience for the {$campaignName} campaign.
		EOT;

        return $this->ai->complete($systemPrompt, $userPrompt, ['company_id' => $companyId]);
    }

    private function hasNotPersonalizedContent(Request $request): string
    {
        $platform = $request->get('platform');

        $limit = config('titan-reach.' . $platform . '.requirements.text.limit');

        $limit = (int) $limit;
        $platform = ucfirst($platform);
        $tone = $request->get('tone');
        $userContent = $request['content'];

        $systemPrompt = "You are a Titan Reach content creator. Generate engaging and attention-grabbing content that does not exceed {$limit} characters under any circumstances for {$platform}, including emojis.";

        $userPrompt = "Create an engaging {$platform}-style post using the following input: '{$userContent}'. "
            . "The post should be {$tone} and optimized for engagement. "
            . "Keep it within {$limit} characters including emojis. Make sure not to exceed under any circumstances"
            . 'Include relevant hashtags, emojis, and a strong call to action.';

        $companyId = $this->companyContext->resolve(userId: Auth::id());
        return $this->ai->complete($systemPrompt, $userPrompt, ['company_id' => $companyId]);
    }

    protected function chatCreate(?string $campaignName = null, $isSelectedCampaign = false): string
    {
        $companyId = $this->companyContext->resolve(userId: Auth::id());
        return $this->ai->completeUserOnly(
            "Generate only a list of target audience attributes, including demographics, interests, and pain points, for the purpose of $campaignName campaign. Must result as array json data only. Result format is [attribute1, attribute2, ..., attributen]. Ensure that the result does not contain backticks (\`) or the string \"```json\".",
            ['company_id' => $companyId],
        );
    }
}
