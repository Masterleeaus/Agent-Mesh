<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

use App\Extensions\TitanReachPro\System\Support\FieldServiceMediaPrivacyPolicy;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Sanitizes job-site images before they are made available for social publishing.
 *
 * The sanitizer is deliberately conservative: SVG and non-raster uploads are
 * rejected for job media, GPS/EXIF is stripped by re-encoding where possible,
 * and a metadata report is returned so callers can persist/audit the decision.
 */
final class FieldServiceMediaSanitizer
{
    private const ALLOWED_MIME_TYPES = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    public function storeSanitizedImage(UploadedFile $file, ?int $companyId = null, array $policy = []): array
    {
        $policy = array_replace(FieldServiceMediaPrivacyPolicy::defaults(), $policy);
        $mime = (string) $file->getMimeType();

        if (! isset(self::ALLOWED_MIME_TYPES[$mime])) {
            throw new RuntimeException(__('Only JPEG, PNG and WebP job-site images are accepted for field-service publishing. SVG/GIF uploads are blocked because they cannot be safely privacy-sanitized here.'));
        }

        $extension = self::ALLOWED_MIME_TYPES[$mime];
        $directory = trim('titan-reach/job-media/' . ($companyId ?: 'unassigned'), '/');
        $filename = Str::uuid()->toString() . '.' . $extension;
        $path = $directory . '/' . $filename;

        $bytes = file_get_contents($file->getRealPath());
        if ($bytes === false || $bytes === '') {
            throw new RuntimeException(__('Uploaded image could not be read.'));
        }

        $sanitizedBytes = $policy['strip_exif'] || $policy['strip_gps']
            ? $this->reencodeRasterImage($file->getRealPath(), $mime)
            : $bytes;

        Storage::disk('public')->put($path, $sanitizedBytes);

        return [
            'path'              => '/uploads/' . $path,
            'url'               => url('uploads/' . $path),
            'company_id'        => $companyId,
            'mime_type'         => $mime,
            'metadata_stripped' => (bool) ($policy['strip_exif'] || $policy['strip_gps']),
            'gps_stripped'      => (bool) ($policy['strip_gps'] ?? true),
            'privacy_policy'    => $policy,
        ];
    }

    private function reencodeRasterImage(string $sourcePath, string $mime): string
    {
        if (! function_exists('imagecreatetruecolor')) {
            throw new RuntimeException(__('GD is required to strip metadata from field-service job media.'));
        }

        $image = match ($mime) {
            'image/jpeg' => function_exists('imagecreatefromjpeg') ? imagecreatefromjpeg($sourcePath) : false,
            'image/png'  => function_exists('imagecreatefrompng') ? imagecreatefrompng($sourcePath) : false,
            'image/webp' => function_exists('imagecreatefromwebp') ? imagecreatefromwebp($sourcePath) : false,
            default      => false,
        };

        if (! $image) {
            throw new RuntimeException(__('Unable to decode uploaded image for privacy sanitization.'));
        }

        ob_start();
        try {
            match ($mime) {
                'image/jpeg' => imagejpeg($image, null, 90),
                'image/png'  => imagepng($image, null, 6),
                'image/webp' => imagewebp($image, null, 90),
                default      => throw new RuntimeException(__('Unsupported image type.')),
            };
            $output = ob_get_clean();
        } finally {
            imagedestroy($image);
        }

        if (! is_string($output) || $output === '') {
            throw new RuntimeException(__('Unable to re-encode uploaded image for privacy sanitization.'));
        }

        return $output;
    }
}
