<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Extensions\TitanReachPro\System\Services\LocalDistribution\AssistedDistributionPlanner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class LocalDistributionController extends Controller
{
    public function plan(Request $request, AssistedDistributionPlanner $planner): JsonResponse
    {
        $data=$request->validate([
            'company_id'=>['required','integer','min:1'],
            'destination'=>['required','string','max:80'],
            'business_name'=>['nullable','string','max:160'],
            'headline'=>['nullable','string','max:180'],
            'description'=>['nullable','string','max:3000'],
            'service'=>['nullable','string','max:160'],
            'service_area'=>['nullable','string','max:160'],
            'quote_url'=>['nullable','url','max:2048'],
            'booking_url'=>['nullable','url','max:2048'],
            'phone'=>['nullable','string','max:80'],
            'request_direct_publish'=>['sometimes','boolean'],
            'claims_unverified_licence'=>['sometimes','boolean'],
            'claims_unapproved_price'=>['sometimes','boolean'],
            'claims_unconfigured_emergency'=>['sometimes','boolean'],
            'claims_outside_service_area'=>['sometimes','boolean'],
            'contains_customer_identity'=>['sometimes','boolean'],
        ]);
        return response()->json($planner->plan($data));
    }
}
