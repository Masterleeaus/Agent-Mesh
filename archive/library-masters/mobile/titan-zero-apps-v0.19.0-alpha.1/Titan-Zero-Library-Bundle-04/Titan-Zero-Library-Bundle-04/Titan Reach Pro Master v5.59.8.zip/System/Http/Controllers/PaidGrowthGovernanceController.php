<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Extensions\TitanReachPro\System\Services\PaidGrowth\PaidGrowthGovernanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class PaidGrowthGovernanceController extends Controller
{
    public function __invoke(Request $request, PaidGrowthGovernanceService $governance): JsonResponse
    {
        $data = $request->validate([
            'company_id' => ['required','integer','min:1'],
            'channel' => ['required','string','in:meta_ads,google_local_services_ads'],
            'objective' => ['nullable','string','max:80'],
            'daily_budget_minor' => ['required','integer','min:1'],
            'campaign_budget_minor' => ['required','integer','min:1'],
            'daily_budget_ceiling_minor' => ['required','integer','min:1'],
            'campaign_budget_ceiling_minor' => ['required','integer','min:1'],
            'ad_account' => ['sometimes','boolean'],
            'payment_profile' => ['sometimes','boolean'],
            'business_verification' => ['sometimes','boolean'],
            'category_eligibility' => ['sometimes','boolean'],
            'service_area_match' => ['sometimes','boolean'],
            'human_approval' => ['sometimes','boolean'],
            'budget_ceiling' => ['sometimes','boolean'],
            'automatic_activation' => ['sometimes','boolean'],
            'automatic_budget_increase' => ['sometimes','boolean'],
            'claims_unverified_licence' => ['sometimes','boolean'],
            'claims_unapproved_price' => ['sometimes','boolean'],
            'claims_unconfigured_emergency' => ['sometimes','boolean'],
            'claims_outside_service_area' => ['sometimes','boolean'],
        ]);

        return response()->json($governance->evaluate($data)->toArray());
    }
}
