<?php

namespace App\Extensions\TitanReachPro\System\Services\Publisher;

use App\Extensions\TitanReachPro\System\Enums\LogStatusEnum;
use App\Extensions\TitanReachPro\System\Enums\PostTypeEnum;
use App\Extensions\TitanReachPro\System\Enums\StatusEnum;
use App\Extensions\TitanReachPro\System\Helpers\Instagram;
use App\Extensions\TitanReachPro\System\Models\TitanReachSharedLog;
use App\Extensions\TitanReachPro\System\Services\Publisher\Contracts\BasePublisherService;

class InstagramService extends BasePublisherService
{
    public function handle()
    {
        $images = $this->post->images ?? [];
        $media = $this->post->image;

        $message = $this->post->content;

        $instagram = new Instagram;

        $instagram->setToken($this->accessToken);

        if (! $media && empty($images)) {

            $this->post->update([
                'status' => StatusEnum::failed,
            ]);

            TitanReachSharedLog::query()->create([
                'titan_reach_post_id' => $this->post->id,
                'response'             => [
                    'message' => 'Media not found.',
                ],
                'status'     => LogStatusEnum::failed,
                'created_at' => now(),
            ]);

            return false;
        }

        if ($this->post->post_type === PostTypeEnum::Story) {
            return $instagram->publishStory($this->platformId, url($media));
        }

        if (count($images) > 1) {
            $imageUrls = array_map(fn ($img) => url($img), $images);

            return $instagram->publishCarouselPost($this->platformId, $imageUrls, 'image', $message);
        }

        $postData = [
            'image_url' => url($media),
            'caption'   => $message,
        ];

        return $instagram->publishSingleMediaPost($this->platformId, $postData);
    }
}
