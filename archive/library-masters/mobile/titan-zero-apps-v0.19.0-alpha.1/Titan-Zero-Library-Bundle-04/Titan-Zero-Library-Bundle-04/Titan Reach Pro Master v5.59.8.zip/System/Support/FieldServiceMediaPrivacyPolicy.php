<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Support;

use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;

/**
 * Central privacy guardrails for field/home-service job media.
 *
 * This class intentionally defaults to denial. It never infers customer consent,
 * usable faces, exact addresses, vehicle plates, licence/trust claims, emergency
 * availability, or service-area permission from an uploaded file or prompt.
 */
final class FieldServiceMediaPrivacyPolicy
{
    public const SAFE_DEFAULTS = [
        'strip_exif'                  => true,
        'strip_gps'                   => true,
        'require_media_consent'       => true,
        'include_customer_names'      => false,
        'include_exact_addresses'     => false,
        'include_faces'               => false,
        'include_vehicle_plates'      => false,
        'include_before_after_media'  => false,
        'allow_ai_to_identify_people' => false,
        'allow_ai_to_infer_location'  => false,
    ];

    public static function defaults(): array
    {
        return self::SAFE_DEFAULTS;
    }

    public static function fromContext(?FieldServiceContext $context): array
    {
        $configured = $context?->privacyDefaults ?? [];

        return array_replace(self::SAFE_DEFAULTS, array_intersect_key((array) $configured, self::SAFE_DEFAULTS));
    }

    public static function acknowledgementRequiredFor(?FieldServiceContext $context): bool
    {
        $policy = self::fromContext($context);

        return (bool) ($policy['require_media_consent'] ?? true);
    }

    public static function promptGuardrails(?FieldServiceContext $context = null): string
    {
        $policy = self::fromContext($context);
        $blocked = [];

        if (! $policy['include_customer_names']) {
            $blocked[] = 'customer names';
        }
        if (! $policy['include_exact_addresses']) {
            $blocked[] = 'exact street addresses';
        }
        if (! $policy['include_faces']) {
            $blocked[] = 'faces or biometric descriptions';
        }
        if (! $policy['include_vehicle_plates']) {
            $blocked[] = 'vehicle registration plates';
        }

        return 'Field-service media privacy: strip EXIF/GPS metadata; do not identify people, addresses, plates, or private customer details. Blocked by default: ' . implode(', ', $blocked) . '.';
    }
}
