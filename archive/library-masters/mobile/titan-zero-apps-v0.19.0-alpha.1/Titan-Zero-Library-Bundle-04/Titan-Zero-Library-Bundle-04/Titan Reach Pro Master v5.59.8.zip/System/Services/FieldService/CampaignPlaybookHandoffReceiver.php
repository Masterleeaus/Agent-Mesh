<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\FieldService;

final class CampaignPlaybookHandoffReceiver
{
    /**
     * Accepts planned campaign content from the legacy Campaign Playbooks extension.
     * This receiver intentionally does not auto-publish. It normalizes the payload so
     * Titan Reach Pro / Field Marketing Hub remains the only publishing authority.
     */
    public function normalize(array $payload): array
    {
        return [
            'source_extension' => $payload['source_extension'] ?? 'titan-reach-campaigns',
            'event' => 'CampaignPlanReady',
            'company_id' => isset($payload['company_id']) ? (int) $payload['company_id'] : null,
            'playbook_item_id' => $payload['playbook_item_id'] ?? null,
            'headline' => trim((string) ($payload['headline'] ?? '')),
            'brief' => trim((string) ($payload['brief'] ?? '')),
            'cta' => trim((string) ($payload['cta'] ?? '')),
            'content_lane' => $payload['content_lane'] ?? 'campaign_playbook',
            'status' => 'draft_ready_for_review',
            'publishing_authority' => 'field_marketing_hub',
            'auto_publish' => false,
        ];
    }
}
