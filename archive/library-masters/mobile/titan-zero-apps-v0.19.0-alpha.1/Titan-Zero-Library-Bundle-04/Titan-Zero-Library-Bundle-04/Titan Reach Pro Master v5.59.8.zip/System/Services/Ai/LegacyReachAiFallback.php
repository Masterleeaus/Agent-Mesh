<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\Ai;

interface LegacyReachAiFallback
{
    public function completeMessages(array $messages, array $context = []): string;
}
