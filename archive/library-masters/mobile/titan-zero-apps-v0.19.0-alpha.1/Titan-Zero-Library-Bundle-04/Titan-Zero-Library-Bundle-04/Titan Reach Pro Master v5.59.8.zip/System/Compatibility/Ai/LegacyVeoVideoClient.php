<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Compatibility\Ai;

use App\Domains\Entity\Enums\EntityEnum;
use App\Domains\Entity\Facades\Entity;
use App\Extensions\TitanReachPro\System\Services\Ai\LegacyReachVideoFallback;
use App\Extensions\TitanReachPro\System\Services\Generator\GoogleVeo2Service;

/** Compatibility-only implementation for the historical direct Veo integration. */
final class LegacyVeoVideoClient implements LegacyReachVideoFallback
{
    public function generate(string $prompt, int $companyId): array
    {
        $driver = Entity::driver(EntityEnum::VEO_2)->inputVideoCount(1)->calculateCredit();
        $driver->redirectIfNoCreditBalance();
        $driver->decreaseCredit();

        $response = GoogleVeo2Service::generate($prompt);

        return [
            'status' => $response->json('status'),
            'request_id' => $response->json('request_id'),
        ];
    }

    public function status(string $requestId, int $companyId): array
    {
        $response = GoogleVeo2Service::status($requestId);
        $status = $response->json('status');
        if ($status !== 'COMPLETED') {
            return ['status' => $status];
        }

        $content = GoogleVeo2Service::content($requestId);
        $video = $content->json('video.url');

        return [
            'status' => 'COMPLETED',
            'video_path' => $video ? GoogleVeo2Service::downloadAndSaveVideoFromUrl($video) : null,
        ];
    }
}
