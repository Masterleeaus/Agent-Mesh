<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Http\Controllers;

use App\Extensions\TitanReachPro\System\Contracts\FieldServiceContextProvider;
use App\Extensions\TitanReachPro\System\DTO\FieldServiceContext;
use App\Extensions\TitanReachPro\System\Models\FieldServiceMarketingProfile;
use App\Extensions\TitanReachPro\System\Models\FieldServiceService;
use App\Extensions\TitanReachPro\System\Models\FieldServiceServiceArea;
use App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceVerticalPackCatalog;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FieldServiceMarketingProfileController extends Controller
{
    public function edit(FieldServiceContextProvider $provider, FieldServiceVerticalPackCatalog $verticalPacks)
    {
        $companyId = $this->companyId();
        $context = $provider->resolve($companyId, auth()->id());

        return view('titan-reach::field-service-profile', [
            'context' => $context->toArray(),
            'verticalPacks' => $verticalPacks->all(),
        ]);
    }

    public function update(Request $request, FieldServiceContextProvider $provider): RedirectResponse
    {
        $companyId = $this->companyId();
        abort_if(! $companyId, 422, __('A company context is required before configuring field-service marketing.'));

        $validated = $request->validate([
            'business_name'                => ['nullable', 'string', 'max:190'],
            'vertical'                     => ['nullable', 'string', 'max:120'],
            'hours'                        => ['nullable', 'array'],
            'emergency_available'          => ['nullable', 'boolean'],
            'contact_channels'             => ['nullable', 'array'],
            'quote_url'                    => ['nullable', 'url', 'max:500'],
            'booking_url'                  => ['nullable', 'url', 'max:500'],
            'review_url'                   => ['nullable', 'url', 'max:500'],
            'licence_trust_statements'     => ['nullable', 'array'],
            'seasonal_services'            => ['nullable', 'array'],
            'brand_voice'                  => ['nullable', 'string', 'max:1200'],
            'privacy_defaults'             => ['nullable', 'array'],
            'services_text'                => ['nullable', 'string', 'max:5000'],
            'service_areas_text'           => ['nullable', 'string', 'max:5000'],
            'licence_trust_statements_text'=> ['nullable', 'string', 'max:5000'],
            'services'                     => ['nullable', 'array'],
            'services.*.name'              => ['nullable', 'string', 'max:190'],
            'services.*.description'       => ['nullable', 'string', 'max:1000'],
            'services.*.active'            => ['nullable', 'boolean'],
            'service_areas'                => ['nullable', 'array'],
            'service_areas.*.name'         => ['nullable', 'string', 'max:190'],
            'service_areas.*.state'        => ['nullable', 'string', 'max:80'],
            'service_areas.*.country'      => ['nullable', 'string', 'max:80'],
            'service_areas.*.active'       => ['nullable', 'boolean'],
        ]);

        DB::transaction(function () use ($companyId, $validated): void {
            $services = array_values(array_filter($validated['services'] ?? [], static fn ($item): bool => filled($item['name'] ?? null)));
            if (isset($validated['services_text'])) {
                $services = $this->linesToNamedItems($validated['services_text']);
            }

            $areas = array_values(array_filter($validated['service_areas'] ?? [], static fn ($item): bool => filled($item['name'] ?? null)));
            if (isset($validated['service_areas_text'])) {
                $areas = $this->linesToNamedItems($validated['service_areas_text']);
            }

            $licenceTrustStatements = array_values(array_filter($validated['licence_trust_statements'] ?? []));
            if (isset($validated['licence_trust_statements_text'])) {
                $licenceTrustStatements = array_map(static fn ($item): string => $item['name'], $this->linesToNamedItems($validated['licence_trust_statements_text']));
            }

            [$score, $missing] = FieldServiceContext::calculateCompleteness([
                ...$validated,
                'services'      => $services,
                'service_areas' => $areas,
            ]);

            $profile = FieldServiceMarketingProfile::query()->updateOrCreate(
                ['company_id' => $companyId],
                [
                    'business_name'             => $validated['business_name'] ?? null,
                    'vertical'                  => $validated['vertical'] ?? null,
                    'hours'                     => $validated['hours'] ?? [],
                    'emergency_available'       => (bool) ($validated['emergency_available'] ?? false),
                    'contact_channels'          => $validated['contact_channels'] ?? [],
                    'quote_url'                 => $validated['quote_url'] ?? null,
                    'booking_url'               => $validated['booking_url'] ?? null,
                    'review_url'                => $validated['review_url'] ?? null,
                    'licence_trust_statements'  => $licenceTrustStatements,
                    'seasonal_services'         => array_values(array_filter($validated['seasonal_services'] ?? [])),
                    'brand_voice'               => $validated['brand_voice'] ?? null,
                    'privacy_defaults'          => $this->normalisePrivacyDefaults($validated['privacy_defaults'] ?? []),
                    'completeness_score'        => $score,
                    'missing_fields'            => $missing,
                ]
            );

            FieldServiceService::query()->where('company_id', $companyId)->where('profile_id', $profile->id)->delete();
            foreach ($services as $index => $service) {
                FieldServiceService::query()->create([
                    'profile_id'  => $profile->id,
                    'company_id'  => $companyId,
                    'name'        => trim((string) $service['name']),
                    'description' => $service['description'] ?? null,
                    'active'      => (bool) ($service['active'] ?? true),
                    'sort_order'  => $index + 1,
                ]);
            }

            FieldServiceServiceArea::query()->where('company_id', $companyId)->where('profile_id', $profile->id)->delete();
            foreach ($areas as $index => $area) {
                FieldServiceServiceArea::query()->create([
                    'profile_id'  => $profile->id,
                    'company_id'  => $companyId,
                    'name'        => trim((string) $area['name']),
                    'state'       => $area['state'] ?? null,
                    'country'     => $area['country'] ?? null,
                    'active'      => (bool) ($area['active'] ?? true),
                    'sort_order'  => $index + 1,
                ]);
            }
        });

        return back()->with(['message' => __('Field-service marketing context saved.')]);
    }

    private function linesToNamedItems(?string $text): array
    {
        $lines = preg_split('/\r\n|\r|\n/', (string) $text) ?: [];

        return array_values(array_map(
            static fn (string $line): array => ['name' => trim($line), 'active' => true],
            array_filter($lines, static fn (string $line): bool => filled(trim($line)))
        ));
    }


    private function normalisePrivacyDefaults(array $input): array
    {
        $defaults = FieldServiceContext::defaultPrivacy();
        $allowed = array_intersect_key($input, $defaults);

        foreach ($allowed as $key => $value) {
            $allowed[$key] = filter_var($value, FILTER_VALIDATE_BOOLEAN);
        }

        return array_replace($defaults, $allowed);
    }

    private function companyId(): ?int
    {
        $user = auth()->user();
        if (! $user) {
            return null;
        }

        foreach (['company_id', 'current_company_id'] as $field) {
            if (isset($user->{$field}) && $user->{$field}) {
                return (int) $user->{$field};
            }
        }

        return null;
    }
}
