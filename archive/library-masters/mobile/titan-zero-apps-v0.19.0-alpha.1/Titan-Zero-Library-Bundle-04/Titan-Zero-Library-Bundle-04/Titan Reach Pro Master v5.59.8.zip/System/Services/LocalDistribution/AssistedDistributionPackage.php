<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachPro\System\Services\LocalDistribution;

final class AssistedDistributionPackage
{
    public function __construct(
        public readonly string $destination,
        public readonly string $mode,
        public readonly array $fields,
        public readonly array $requirements,
        public readonly bool $ownerActionRequired,
    ) {}

    public function toArray(): array
    {
        return [
            'destination'=>$this->destination,
            'mode'=>$this->mode,
            'fields'=>$this->fields,
            'requirements'=>$this->requirements,
            'owner_action_required'=>$this->ownerActionRequired,
        ];
    }
}
