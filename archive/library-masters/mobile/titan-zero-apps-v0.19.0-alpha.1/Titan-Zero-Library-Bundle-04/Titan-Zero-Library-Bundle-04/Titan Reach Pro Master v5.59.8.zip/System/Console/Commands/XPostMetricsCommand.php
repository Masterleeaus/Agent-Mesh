<?php

namespace App\Extensions\TitanReachPro\System\Console\Commands;

use App\Extensions\TitanReachPro\System\Enums\PlatformEnum;
use App\Extensions\TitanReachPro\System\Helpers\X;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use Exception;
use Illuminate\Console\Command;

class XPostMetricsCommand extends Command
{
    protected $signature = 'app:titan-reach-x-post-metrics';

    protected $description = 'Post metrics for X (formerly Twitter)';

    public function handle(): void
    {
        $posts = TitanReachPost::query()
            ->where('titan_reach_platform', PlatformEnum::x->value)
            ->with('platform')
            ->where('post_metric_at', '<', now())
            ->get();

        foreach ($posts as $post) {
            try {

                /**
                 * @var TitanReachPlatform $platform
                 */
                $platform = $post->platform;

                if ($platform && $platform->isConnected()) {
                    $x = new X(accessToken: $platform->credentials['access_token']);

                    $json = $x->getTweet($post['post_id']);

                    if (is_array($json) && isset($json['retweet_count'])) {
                        $post->update([
                            'post_metrics'   => $json,
                            'post_metric_at' => now()->addMinutes(15),
                        ]);
                    }
                }
            } catch (Exception $exception) {

            }
        }
    }
}
