<?php

namespace App\Extensions\TitanReachPro\System\Services\Publisher;

use App\Extensions\TitanReachPro\System\Models\TitanReachPost;
use App\Extensions\TitanReachPro\System\Services\Publisher\Contracts\BasePublisherService;

class PublisherDriver
{
    public TitanReachPost $post;

    public function setPost(TitanReachPost $post): self
    {
        $this->post = $post;

        return $this;
    }

    public function getPost(): TitanReachPost
    {
        return $this->post;
    }

    public function getDriver(): ?BasePublisherService
    {
        if ($this->post->platform) {

            $driver = match ($this->post->platform?->platform ?: 'default') {
                'instagram'      => app(InstagramService::class),
                'facebook'       => app(FacebookService::class),
                'linkedin'       => app(LinkedinService::class),
                'x'              => app(XService::class),
                'tiktok'         => app(TiktokService::class),
                'youtube'        => app(YoutubeService::class),
                'youtube-shorts' => app(YoutubeService::class),
                default          => null,
            };

            if ($driver instanceof BasePublisherService) {
                $driver
                    ->setPost($this->post)
                    ->setPlatform($this->post->platform);
            }

            return $driver;
        }

        return null;
    }
}
