<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ChartOfAccountsService
{
    public function __construct(private ConnectionInterface $db, private LedgerCompanyContext $companyContext) {}

    public function ensureDefaults(int $userId): void
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);

        foreach (ChartOfAccountCatalog::australianSmeDefaults() as $position => $account) {
            $byCode = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('code', $account['code'])->first();
            $bySystemKey = $account['system_key'] === null ? null : $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('system_key', $account['system_key'])->first();

            if ($account['system_key'] !== null && ($byCode || $bySystemKey)) {
                $same = $byCode && $bySystemKey
                    ? ((string) $byCode->public_id === (string) $bySystemKey->public_id)
                    : ($byCode ? (string) ($byCode->system_key ?? '') === $account['system_key'] : (string) ($bySystemKey->code ?? '') === $account['code']);
                if (! $same) {
                    throw new InvalidArgumentException('Required system account conflict for ' . $account['system_key'] . ' (' . $account['code'] . ').');
                }
                continue;
            }

            if ($byCode) continue;

            $this->db->table('titan_ledger_accounts')->insertOrIgnore([
                'public_id' => (string) Str::ulid(),
                'company_id' => $companyId,
                'code' => $account['code'],
                'name' => $account['name'],
                'type' => $account['type'],
                'subtype' => $account['subtype'],
                'normal_balance' => $account['normal_balance'],
                'tax_code' => $account['tax_code'],
                'system_key' => $account['system_key'],
                'parent_public_id' => null,
                'is_system_account' => $account['system_key'] !== null,
                'is_protected' => $account['is_protected'],
                'is_active' => true,
                'sort_order' => ($position + 1) * 10,
                'created_by_user_id' => $actor,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            if ($account['system_key'] !== null) {
                $created = $this->db->table('titan_ledger_accounts')
                    ->where('company_id', $companyId)
                    ->where('code', $account['code'])
                    ->where('system_key', $account['system_key'])
                    ->exists();
                if (! $created) {
                    throw new InvalidArgumentException('Required system account conflict for ' . $account['system_key'] . ' (' . $account['code'] . ').');
                }
            }
        }
    }

    public function all(int $userId, bool $activeOnly = true): array
    {
        $this->ensureDefaults($userId);
        $q = $this->db->table('titan_ledger_accounts')->where('company_id', $this->companyContext->companyId($userId));
        if ($activeOnly) $q->where('is_active', true);
        return $q->orderBy('code')->limit(10000)->get()->map(fn ($row) => (array) $row)->all();
    }

    public function findByCode(int $userId, string $code): ?array
    {
        $this->ensureDefaults($userId);
        $row = $this->db->table('titan_ledger_accounts')
            ->where('company_id', $this->companyContext->companyId($userId))
            ->where('code', trim($code))->first();
        return $row ? (array) $row : null;
    }

    public function findSystemAccount(int $userId, string $systemKey): ?array
    {
        $this->ensureDefaults($userId);
        $row = $this->db->table('titan_ledger_accounts')
            ->where('company_id', $this->companyContext->companyId($userId))
            ->where('system_key', trim($systemKey))->first();
        return $row ? (array) $row : null;
    }

    public function create(int $userId, array $data): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $code = trim((string) ($data['code'] ?? ''));
        $name = trim((string) ($data['name'] ?? ''));
        $type = trim((string) ($data['type'] ?? ''));
        if ($code === '' || $name === '') throw new InvalidArgumentException('Account code and name are required.');
        if (! in_array($type, ChartOfAccountCatalog::types(), true)) throw new InvalidArgumentException('Unsupported account type.');
        if ($this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('code', $code)->exists()) {
            throw new InvalidArgumentException('Account code already exists for this company.');
        }

        $parentPublicId = $this->validatedParent($companyId, $data['parent_public_id'] ?? null);
        $publicId = (string) Str::ulid();
        $this->db->table('titan_ledger_accounts')->insert([
            'public_id' => $publicId,
            'company_id' => $companyId,
            'code' => $code,
            'name' => $name,
            'type' => $type,
            'subtype' => $this->nullableString($data['subtype'] ?? null),
            'normal_balance' => ChartOfAccountCatalog::normalBalanceFor($type),
            'tax_code' => $this->nullableString($data['tax_code'] ?? null),
            'system_key' => null,
            'parent_public_id' => $parentPublicId,
            'is_system_account' => false,
            'is_protected' => false,
            'is_active' => (bool) ($data['is_active'] ?? true),
            'sort_order' => (int) ($data['sort_order'] ?? 1000),
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null,
            'created_by_user_id' => $this->companyContext->actorUserId($userId),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return (array) $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', $publicId)->first();
    }

    public function update(int $userId, string $publicId, array $data): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $row = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', $publicId)->first();
        if (! $row) throw new InvalidArgumentException('Ledger account not found.');

        if ((bool) $row->is_protected) {
            foreach (['code','type','subtype','normal_balance','tax_code','system_key','parent_public_id','is_system_account','is_protected'] as $field) {
                if (array_key_exists($field, $data)) throw new InvalidArgumentException("Protected system account field cannot be changed: {$field}.");
            }
            if (array_key_exists('is_active', $data) && ! (bool) $data['is_active']) {
                throw new InvalidArgumentException('Protected system accounts cannot be deactivated.');
            }
        }

        $updates = ['updated_at' => now()];

        if (array_key_exists('code', $data)) {
            $code = trim((string) $data['code']);
            if ($code === '') throw new InvalidArgumentException('Account code is required.');
            $duplicate = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('code', $code)->where('public_id', '<>', $publicId)->exists();
            if ($duplicate) throw new InvalidArgumentException('Account code already exists for this company.');
            $updates['code'] = $code;
        }

        if (array_key_exists('type', $data)) {
            $type = trim((string) $data['type']);
            if (! in_array($type, ChartOfAccountCatalog::types(), true)) throw new InvalidArgumentException('Unsupported account type.');
            $updates['type'] = $type;
            $updates['normal_balance'] = ChartOfAccountCatalog::normalBalanceFor($type);
        }

        if (array_key_exists('name', $data)) {
            $name = trim((string) $data['name']);
            if ($name === '') throw new InvalidArgumentException('Account name is required.');
            $updates['name'] = $name;
        }
        foreach (['subtype','tax_code'] as $field) {
            if (array_key_exists($field, $data)) $updates[$field] = $this->nullableString($data[$field]);
        }
        if (array_key_exists('parent_public_id', $data)) $updates['parent_public_id'] = $this->validatedParent($companyId, $data['parent_public_id'], $publicId);
        if (array_key_exists('is_active', $data)) $updates['is_active'] = (bool) $data['is_active'];
        if (array_key_exists('sort_order', $data)) $updates['sort_order'] = (int) $data['sort_order'];
        if (array_key_exists('metadata', $data)) $updates['metadata'] = $data['metadata'] === null ? null : json_encode($data['metadata']);

        $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', $publicId)->update($updates);
        return (array) $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', $publicId)->first();
    }

    private function validatedParent(int $companyId, mixed $parentPublicId, ?string $childPublicId = null): ?string
    {
        $parentPublicId = $this->nullableString($parentPublicId);
        if ($parentPublicId === null) return null;
        if ($childPublicId !== null && $parentPublicId === $childPublicId) throw new InvalidArgumentException('Account hierarchy cycle detected.');

        $parent = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', $parentPublicId)->first();
        if (! $parent) throw new InvalidArgumentException('Parent ledger account was not found in this company.');

        if ($childPublicId !== null) {
            $visited = [];
            $cursor = $parent;
            while ($cursor && $cursor->parent_public_id !== null) {
                $cursorId = (string) $cursor->public_id;
                if (isset($visited[$cursorId])) throw new InvalidArgumentException('Account hierarchy cycle detected.');
                $visited[$cursorId] = true;
                if ((string) $cursor->parent_public_id === $childPublicId) throw new InvalidArgumentException('Account hierarchy cycle detected.');
                $cursor = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->where('public_id', (string) $cursor->parent_public_id)->first();
            }
        }

        return $parentPublicId;
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
