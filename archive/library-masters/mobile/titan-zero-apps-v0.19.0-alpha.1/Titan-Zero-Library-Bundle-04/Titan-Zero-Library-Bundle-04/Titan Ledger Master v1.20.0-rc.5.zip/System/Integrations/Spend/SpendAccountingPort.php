<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Integrations\Spend;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
final class SpendAccountingPort
{
    public function __construct(private LedgerCommandSubmissionService $commands){}
    public function supplierBillPosted(int $actorUserId,array $fact,array $context=[]): array{$n=SpendAccountingFact::bill($fact);return $this->submit($actorUserId,'ledger.payable.bill.post',$n,$context);}
    public function supplierCreditPosted(int $actorUserId,array $fact,array $context=[]): array{$n=SpendAccountingFact::creditNote($fact);return $this->submit($actorUserId,'ledger.payable.credit_note.post',$n,$context);}
    public function supplierPaymentPosted(int $actorUserId,array $fact,array $context=[]): array{$n=SpendAccountingFact::payment($fact);return $this->submit($actorUserId,'ledger.payable.payment.post',$n,$context);}
    public function spendActualPosted(int $actorUserId,array $fact,array $context=[]): array{$n=SpendAccountingFact::actual($fact);return $this->submit($actorUserId,'ledger.spend.actual.post',$n,$context);}
    private function submit(int $actor,string $command,array $fact,array $context): array{$id='spend-ledger:'.substr(hash('sha256',$command.'|'.$fact['source_event_id'].'|'.SpendAccountingFact::hash($fact)),0,48);return $this->commands->submit($actor,$command,$id,(string)$fact['document_public_id'],$fact,$context,(string)($fact['source_extension']??'titan-budgeting'));}
}
