<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Receivables;

use InvalidArgumentException;

final class ReceivableBalanceCalculator
{
    /** @return array{invoice_minor:int,credits_minor:int,payments_minor:int,refunds_minor:int,net_applied_minor:int,outstanding_minor:int,receivable_credit_minor:int,customer_credit_minor:int} */
    public static function calculate(int $invoiceMinor,int $creditsMinor,int $paymentsMinor,int $refundsMinor,int $overpaymentsMinor,int $overpaymentRefundsMinor): array
    {
        foreach (compact('invoiceMinor','creditsMinor','paymentsMinor','refundsMinor','overpaymentsMinor','overpaymentRefundsMinor') as $name=>$value) {
            if ($value < 0) throw new InvalidArgumentException('Receivable balance inputs cannot be negative: '.$name.'.');
        }
        if ($creditsMinor > $invoiceMinor) throw new InvalidArgumentException('Receivable credits cannot exceed invoice total.');
        if ($refundsMinor > $paymentsMinor) throw new InvalidArgumentException('Receivable refunds cannot exceed allocated payments.');
        if ($overpaymentRefundsMinor > $overpaymentsMinor) throw new InvalidArgumentException('Overpayment refunds cannot exceed customer overpayments.');
        $netInvoice=$invoiceMinor-$creditsMinor;
        $netApplied=$paymentsMinor-$refundsMinor;
        $outstanding=max(0,$netInvoice-$netApplied);
        $receivableCredit=max(0,$netApplied-$netInvoice);
        return [
            'invoice_minor'=>$invoiceMinor,
            'credits_minor'=>$creditsMinor,
            'payments_minor'=>$paymentsMinor,
            'refunds_minor'=>$refundsMinor,
            'net_applied_minor'=>$netApplied,
            'outstanding_minor'=>$outstanding,
            'receivable_credit_minor'=>$receivableCredit,
            'customer_credit_minor'=>$receivableCredit+($overpaymentsMinor-$overpaymentRefundsMinor),
        ];
    }
}
