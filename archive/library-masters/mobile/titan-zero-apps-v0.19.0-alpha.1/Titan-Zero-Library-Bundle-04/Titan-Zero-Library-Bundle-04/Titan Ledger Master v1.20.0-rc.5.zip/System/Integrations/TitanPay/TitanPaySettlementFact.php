<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\TitanPay;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final class TitanPaySettlementFact
{
    private const RAILS=['payid','bank_transfer','cash','stripe','paypal'];
    private const FEE_FREE_RAILS=['payid','bank_transfer','cash'];

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function payment(array $input): array
    {
        $paymentId=self::requiredId($input,'payment_public_id');
        $invoiceId=self::requiredId($input,'invoice_public_id');
        $gross=self::positiveMinor($input,'gross_amount_minor');
        $fee=self::nonNegativeMinor($input,'fee_minor');
        $net=self::nonNegativeMinor($input,'net_amount_minor');
        if($fee>$gross || $gross-$fee!==$net) throw new InvalidArgumentException('Titan Pay settlement gross/fee/net arithmetic does not balance.');
        $rail=self::rail($input);
        self::assertFeePolicy($rail,$fee,'settlement');
        return self::base($input,'payment',$paymentId,$paymentId,$invoiceId,$rail)+[
            'gross_amount_minor'=>$gross,
            'fee_minor'=>$fee,
            'net_amount_minor'=>$net,
        ];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function refund(array $input): array
    {
        $refundId=self::requiredId($input,'refund_public_id');
        $paymentId=self::requiredId($input,'original_payment_public_id');
        $invoiceId=self::requiredId($input,'invoice_public_id');
        $amount=self::positiveMinor($input,'refund_amount_minor');
        $fee=self::nonNegativeMinor($input,'refund_fee_minor');
        $rail=self::rail($input);
        self::assertFeePolicy($rail,$fee,'refund');
        return self::base($input,'refund',$refundId,$paymentId,$invoiceId,$rail)+[
            'original_payment_public_id'=>$paymentId,
            'refund_amount_minor'=>$amount,
            'refund_fee_minor'=>$fee,
        ];
    }

    /** @param array<string,mixed> $fact */
    public static function hash(array $fact): string { return hash('sha256',self::canonicalJson($fact)); }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private static function base(array $input,string $type,string $settlementId,string $paymentId,string $invoiceId,string $rail): array
    {
        $currency=strtoupper(trim((string)($input['currency']??'')));
        if(!preg_match('/^[A-Z]{3}$/',$currency)) throw new InvalidArgumentException('Titan Pay settlement currency must be ISO-4217 style.');
        $settledAt=trim((string)($input['settled_at']??''));
        if($settledAt==='') throw new InvalidArgumentException('Titan Pay settlement settled_at is required.');
        try{$date=new DateTimeImmutable($settledAt);}catch(\Throwable){throw new InvalidArgumentException('Titan Pay settlement settled_at is invalid.');}
        $sourceEventId=trim((string)($input['source_event_id']??''));
        if($sourceEventId===''||strlen($sourceEventId)>120) throw new InvalidArgumentException('Titan Pay settlement source_event_id is required.');
        $sourceVersion=max(1,(int)($input['source_version']??1));
        $providerReference=self::nullableBounded($input['provider_reference']??null,191,'provider_reference');
        return [
            'settlement_type'=>$type,
            'settlement_public_id'=>$settlementId,
            'payment_public_id'=>$paymentId,
            'invoice_public_id'=>$invoiceId,
            'rail'=>$rail,
            'currency'=>$currency,
            'settled_at'=>$date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'entry_date'=>$date->format('Y-m-d'),
            'source_event_id'=>$sourceEventId,
            'source_version'=>$sourceVersion,
            'provider_reference'=>$providerReference,
            'funds_account_public_id'=>self::nullableBounded($input['funds_account_public_id']??null,26,'funds_account_public_id'),
        ];
    }

    /** @param array<string,mixed> $input */
    private static function requiredId(array $input,string $key): string
    {
        $v=trim((string)($input[$key]??''));
        if($v===''||strlen($v)>100) throw new InvalidArgumentException($key.' is required and must be at most 100 characters.');
        return $v;
    }

    /** @param array<string,mixed> $input */
    private static function positiveMinor(array $input,string $key): int
    {
        $v=self::integerMinor($input,$key); if($v<1) throw new InvalidArgumentException($key.' must be positive.'); return $v;
    }

    /** @param array<string,mixed> $input */
    private static function nonNegativeMinor(array $input,string $key): int
    {
        $v=self::integerMinor($input,$key); if($v<0) throw new InvalidArgumentException($key.' must not be negative.'); return $v;
    }

    /** @param array<string,mixed> $input */
    private static function integerMinor(array $input,string $key): int
    {
        if(!array_key_exists($key,$input)||filter_var($input[$key],FILTER_VALIDATE_INT)===false) throw new InvalidArgumentException($key.' must be an integer minor-unit amount.');
        return (int)$input[$key];
    }

    /** @param array<string,mixed> $input */
    private static function rail(array $input): string
    {
        $rail=strtolower(trim((string)($input['rail']??'')));
        if(!in_array($rail,self::RAILS,true)) throw new InvalidArgumentException('Unsupported Titan Pay settlement rail.');
        return $rail;
    }

    private static function assertFeePolicy(string $rail,int $fee,string $kind): void
    {
        if(in_array($rail,self::FEE_FREE_RAILS,true)&&$fee!==0) throw new InvalidArgumentException('Titan Pay '.$rail.' '.$kind.' facts must be fee-free.');
    }

    private static function nullableBounded(mixed $value,int $max,string $field): ?string
    {
        if($value===null) return null; $v=trim((string)$value); if($v==='') return null; if(strlen($v)>$max) throw new InvalidArgumentException($field.' is too long.'); return $v;
    }

    private static function canonicalJson(array $value): string { return (string)json_encode(self::canonicalize($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); }
    private static function canonicalize(mixed $value): mixed { if(!is_array($value)) return $value; if(array_is_list($value)) return array_map([self::class,'canonicalize'],$value); ksort($value,SORT_STRING); foreach($value as $k=>$v)$value[$k]=self::canonicalize($v); return $value; }
}
