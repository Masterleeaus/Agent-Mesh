<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Http\Controllers;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankReconciliationService;
use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class ReconciliationController extends Controller
{
    public function __construct(private BankReconciliationService $reconciliation){}
    public function statements(Request $request){return response()->json(['data'=>$this->reconciliation->statements((int)$request->user()->id,200)]);}
    public function sessions(Request $request){return response()->json(['data'=>$this->reconciliation->sessions((int)$request->user()->id,200)]);}
    public function transactions(Request $request,string $statement){return response()->json(['data'=>$this->reconciliation->transactions((int)$request->user()->id,$statement,500)]);}
    public function groups(Request $request){return response()->json(['data'=>$this->reconciliation->groups((int)$request->user()->id,200)]);}
    public function suggestions(Request $request,string $statement){return response()->json(['data'=>$this->reconciliation->advancedSuggestions((int)$request->user()->id,$statement,100)]);}
}
