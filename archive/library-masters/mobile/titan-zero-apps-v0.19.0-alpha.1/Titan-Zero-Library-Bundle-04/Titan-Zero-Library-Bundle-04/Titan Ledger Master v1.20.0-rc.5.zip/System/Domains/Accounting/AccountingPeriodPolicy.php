<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use InvalidArgumentException;

final class AccountingPeriodPolicy
{
    private const LOCK_STATES = ['open', 'soft_locked', 'hard_locked'];
    private const PRIOR_PERIOD_TYPES = ['adjustment', 'correction', 'reversal', 'year_end_close', 'year_end_reopen'];

    public function assertPostingAllowed(
        string $lockState,
        string $journalType,
        bool $priorPeriodAdjustment,
        ?string $overrideReason,
    ): void {
        if (! in_array($lockState, self::LOCK_STATES, true)) {
            throw new InvalidArgumentException('Unknown accounting period lock state: ' . $lockState . '.');
        }

        if ($lockState === 'open') return;

        if ($lockState === 'hard_locked') {
            throw new InvalidArgumentException('Accounting period is hard-locked and must be explicitly reopened before posting.');
        }

        if (! $priorPeriodAdjustment) {
            throw new InvalidArgumentException('Accounting period is soft-locked; posting requires an explicit prior-period adjustment workflow.');
        }
        if (! in_array($journalType, self::PRIOR_PERIOD_TYPES, true)) {
            throw new InvalidArgumentException('Soft-locked periods accept only governed adjustment, correction, or reversal journals, plus year-end close or year-end reopen journals.');
        }
        if (trim((string) $overrideReason) === '') {
            throw new InvalidArgumentException('Soft-locked period posting requires an override reason.');
        }
    }
}
