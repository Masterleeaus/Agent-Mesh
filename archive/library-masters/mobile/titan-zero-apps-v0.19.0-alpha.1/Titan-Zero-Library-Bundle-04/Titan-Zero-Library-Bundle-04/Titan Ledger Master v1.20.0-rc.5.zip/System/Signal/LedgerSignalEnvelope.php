<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

use InvalidArgumentException;

final class LedgerSignalEnvelope
{
    /** @param array<string,mixed> $command @param array<string,mixed> $result @return array<string,mixed> */
    public static function fromAppliedCommand(array $command, array $result, string $domainReceiptReference, string $writeFingerprint, string $occurredAt): array
    {
        $commandName = trim((string) ($command['command_name'] ?? ''));
        $definition = LedgerFinancialEventCatalog::forCommand($commandName);
        if ($definition === null) throw new InvalidArgumentException('Unsupported Ledger financial event command.');

        $commandId = self::required($command, 'command_id', 191);
        $companyId = (int) ($command['company_id'] ?? 0);
        $actorId = (int) ($command['actor_user_id'] ?? 0);
        if ($companyId < 1 || $actorId < 1) throw new InvalidArgumentException('Signal company and actor context must be positive.');
        $domainReceiptReference = trim($domainReceiptReference);
        if ($domainReceiptReference === '' || strlen($domainReceiptReference) > 191) throw new InvalidArgumentException('domain_receipt_reference is required.');
        $writeFingerprint = trim($writeFingerprint);
        if ($writeFingerprint === '' || strlen($writeFingerprint) > 191) throw new InvalidArgumentException('write_fingerprint is required.');
        if (trim($occurredAt) === '') throw new InvalidArgumentException('occurred_at is required.');

        $traceId = self::lineage($command['trace_id'] ?? null) ?? $commandId;
        $correlationId = self::lineage($command['correlation_id'] ?? null) ?? $traceId;
        $causationId = self::lineage($command['causation_id'] ?? null) ?? $commandId;
        $subjectPublicId = self::subjectPublicId($command, $result);
        $payload = self::safePayload($result, $definition['safe_result_fields']);
        $payload['outcome'] = 'applied';
        $payloadHash = hash('sha256', self::canonicalJson($payload));

        $identityBasis = [
            'source_extension' => 'titan-ledger',
            'event_type' => $definition['event_type'],
            'schema_version' => $definition['schema_version'],
            'company_id' => $companyId,
            'command_id' => $commandId,
            'domain_receipt_reference' => $domainReceiptReference,
            'subject_public_id' => $subjectPublicId,
        ];
        $eventId = hash('sha256', self::canonicalJson($identityBasis));

        return [
            'signal_id' => $eventId,
            'event_id' => $eventId,
            'event_type' => $definition['event_type'],
            'schema_version' => $definition['schema_version'],
            'source_extension' => 'titan-ledger',
            'source_capability' => 'ledger.financial_events',
            'company_id' => $companyId,
            'actor_user_id' => $actorId,
            'caller_extension' => self::nullable($command['caller_extension'] ?? null, 100),
            'command_id' => $commandId,
            'command_name' => $commandName,
            'governance_reference' => self::nullable($command['governance_reference'] ?? null, 191),
            'risk_reference' => self::nullable($command['risk_reference'] ?? null, 191),
            'risk_class' => self::nullable($command['risk_class'] ?? null, 30),
            'risk_score' => isset($command['risk_score']) ? (float) $command['risk_score'] : null,
            'risk_ruleset_version' => self::nullable($command['risk_ruleset_version'] ?? null, 100),
            'assurance_reference' => self::nullable($command['assurance_reference'] ?? null, 191),
            'assurance_class' => self::nullable($command['assurance_class'] ?? null, 30),
            'assurance_score' => isset($command['assurance_score']) ? (float) $command['assurance_score'] : null,
            'assurance_ruleset_version' => self::nullable($command['assurance_ruleset_version'] ?? null, 100),
            'domain_receipt_reference' => $domainReceiptReference,
            'write_fingerprint' => $writeFingerprint,
            'subject_type' => $definition['subject_type'],
            'subject_public_id' => $subjectPublicId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'occurred_at' => $occurredAt,
            'payload_hash' => $payloadHash,
            'payload' => $payload,
        ];
    }

    /** @param array<string,mixed> $result @param array<int,string> $allowed */
    private static function safePayload(array $result, array $allowed): array
    {
        $payload = [];
        foreach ($allowed as $field) {
            if (!array_key_exists($field, $result)) continue;
            $value = $result[$field];
            if (is_bool($value) || is_int($value) || is_float($value) || is_string($value) || $value === null) {
                $payload[$field] = $value;
            }
        }
        return $payload;
    }

    /** @param array<string,mixed> $command @param array<string,mixed> $result */
    private static function subjectPublicId(array $command, array $result): ?string
    {
        foreach (['public_id','journal_public_id','account_public_id','financial_year_public_id','period_public_id'] as $key) {
            if (isset($result[$key]) && is_scalar($result[$key])) return self::nullable($result[$key], 191);
        }
        return self::nullable($command['target_public_id'] ?? null, 191);
    }

    /** @param array<string,mixed> $array */
    private static function required(array $array, string $key, int $max): string
    {
        $value = trim((string) ($array[$key] ?? ''));
        if ($value === '' || strlen($value) > $max) throw new InvalidArgumentException($key . ' is required.');
        return $value;
    }

    private static function lineage(mixed $value): ?string
    {
        return self::nullable($value, 120);
    }

    private static function nullable(mixed $value, int $max): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        if ($value === '') return null;
        if (strlen($value) > $max) throw new InvalidArgumentException('Signal field exceeds maximum length.');
        return $value;
    }

    /** @param array<string,mixed> $value */
    private static function canonicalJson(array $value): string
    {
        return (string) json_encode(self::canonicalize($value), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) return array_map([self::class, 'canonicalize'], $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = self::canonicalize($item);
        return $value;
    }
}
