<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodService;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\Http\Support\LedgerCommandHttpContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class AccountingPeriodController extends Controller
{
    public function __construct(private AccountingPeriodService $periods, private LedgerCommandSubmissionService $commands) {}

    public function financialYears(Request $request) { return response()->json(['data' => $this->periods->allYears((int) $request->user()->id)]); }
    public function accountingPeriods(Request $request) { $data=$request->validate(['financial_year'=>'nullable|string|size:26']); return response()->json(['data'=>$this->periods->allPeriods((int)$request->user()->id,$data['financial_year']??null)]); }

    public function createFinancialYear(Request $request)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','label'=>'required|string|max:40','starts_on'=>'required|date','ends_on'=>'required|date|after_or_equal:starts_on','metadata'=>'nullable|array']);
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.financial_year.create',$commandId,null,$data,LedgerCommandHttpContext::lineage($request,$data)),201);
    }

    public function transitionPeriod(Request $request, string $period)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','lock_state'=>'required|in:open,soft_locked,hard_locked']+$this->reasonRules());
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.accounting_period.transition',$commandId,$period,$data,LedgerCommandHttpContext::lineage($request,$data)));
    }

    public function prepareFinancialYearClose(Request $request, string $financialYear)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','trace_id'=>'nullable|string|max:120','correlation_id'=>'nullable|string|max:120','causation_id'=>'nullable|string|max:120']);
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.financial_year.close.prepare',$commandId,$financialYear,$data,LedgerCommandHttpContext::lineage($request,$data)));
    }

    public function closeFinancialYear(Request $request, string $financialYear) { return $this->yearTransition($request,$financialYear,'ledger.financial_year.close'); }
    public function reopenFinancialYear(Request $request, string $financialYear) { return $this->yearTransition($request,$financialYear,'ledger.financial_year.reopen'); }

    private function yearTransition(Request $request,string $financialYear,string $commandName)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','close_snapshot_public_id'=>'nullable|string|size:26']+$this->reasonRules());
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,$commandName,$commandId,$financialYear,$data,LedgerCommandHttpContext::lineage($request,$data)));
    }

    private function reasonRules(): array
    {
        return ['reason'=>'required|string|max:500','trace_id'=>'nullable|string|max:120','correlation_id'=>'nullable|string|max:120','causation_id'=>'nullable|string|max:120','metadata'=>'nullable|array'];
    }
}
