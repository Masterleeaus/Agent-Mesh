<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Payables;

use DateTimeImmutable;
use InvalidArgumentException;

final class PayableAgingPolicy
{
    /** @return array{bucket:string,days_past_due:?int,is_overdue:bool} */
    public static function classify(?string $dueDate,string $asOfDate,int $outstandingMinor): array
    {
        if($outstandingMinor<=0) return ['bucket'=>'settled','days_past_due'=>0,'is_overdue'=>false];
        if($dueDate===null||trim($dueDate)==='') return ['bucket'=>'unknown_due_date','days_past_due'=>null,'is_overdue'=>false];
        try{$due=new DateTimeImmutable($dueDate);$asOf=new DateTimeImmutable($asOfDate);}catch(\Throwable){throw new InvalidArgumentException('Payable aging date is invalid.');}
        $days=(int)$due->diff($asOf)->format('%r%a');
        if($days<=0) return ['bucket'=>'current','days_past_due'=>0,'is_overdue'=>false];
        $bucket=$days<=30?'1-30':($days<=60?'31-60':($days<=90?'61-90':'91+'));
        return ['bucket'=>$bucket,'days_past_due'=>$days,'is_overdue'=>true];
    }
}
