<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use InvalidArgumentException;

final class YearEndCloseCalculator
{
    private const TEMPORARY_TYPES = ['revenue','other_income','cost_of_sales','expense','other_expense'];

    /**
     * @param array<int,array<string,mixed>> $rows
     * @return array{lines:array<int,array<string,mixed>>,net_profit_minor:int,debit_total_minor:int,credit_total_minor:int,temporary_account_count:int}
     */
    public function build(array $rows, string $retainedEarningsAccountPublicId): array
    {
        $retainedEarningsAccountPublicId = trim($retainedEarningsAccountPublicId);
        if ($retainedEarningsAccountPublicId === '') throw new InvalidArgumentException('Retained Earnings account is required for year-end close.');

        $lines = [];
        $netProfit = 0;
        foreach ($rows as $row) {
            $type = (string)($row['type'] ?? '');
            if (! in_array($type, self::TEMPORARY_TYPES, true)) continue;
            $accountId = trim((string)($row['public_id'] ?? ''));
            if ($accountId === '') throw new InvalidArgumentException('Temporary account public_id is required.');
            $debit = (int)($row['debit_minor'] ?? 0);
            $credit = (int)($row['credit_minor'] ?? 0);
            $netDebit = $debit - $credit;
            if ($netDebit === 0) continue;

            if (in_array($type, ['revenue','other_income'], true)) {
                $profitContribution = -$netDebit;
            } else {
                $profitContribution = -$netDebit;
            }
            $netProfit += $profitContribution;

            $lines[] = [
                'account_public_id' => $accountId,
                'description' => 'Year-end close: ' . trim((string)($row['code'] ?? '')) . ' ' . trim((string)($row['name'] ?? '')),
                'debit_minor' => max(0, -$netDebit),
                'credit_minor' => max(0, $netDebit),
                'tax_code' => 'bas_excluded',
                'tax_amount_minor' => 0,
                'metadata' => ['year_end_close' => true],
            ];
        }

        if ($netProfit !== 0) {
            $lines[] = [
                'account_public_id' => $retainedEarningsAccountPublicId,
                'description' => 'Year-end transfer to Retained Earnings',
                'debit_minor' => $netProfit < 0 ? abs($netProfit) : 0,
                'credit_minor' => $netProfit > 0 ? $netProfit : 0,
                'tax_code' => 'bas_excluded',
                'tax_amount_minor' => 0,
                'metadata' => ['year_end_close' => true, 'retained_earnings_transfer' => true],
            ];
        }

        $debits = array_sum(array_map(static fn(array $line): int => (int)$line['debit_minor'], $lines));
        $credits = array_sum(array_map(static fn(array $line): int => (int)$line['credit_minor'], $lines));
        if ($debits !== $credits) throw new InvalidArgumentException('Year-end close calculation did not balance.');

        return [
            'lines' => $lines,
            'net_profit_minor' => $netProfit,
            'debit_total_minor' => $debits,
            'credit_total_minor' => $credits,
            'temporary_account_count' => max(0, count($lines) - ($netProfit !== 0 ? 1 : 0)),
        ];
    }
}
