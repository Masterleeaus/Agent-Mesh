<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Bookkeeping;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

final class BookkeepingReportService
{
    public function __construct(private ConnectionInterface $db, private BookkeepingSummaryCalculator $summary, private LedgerCompanyContext $companyContext) {}

    public function overview(int $userId, ?string $from=null, ?string $to=null): array
    {
        [$from,$to]=$this->range($from,$to);
        $companyId=$this->companyContext->companyId($userId);
        $manual=$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->whereNull('deleted_at')->whereBetween('transaction_date',[$from,$to]);
        $manualIncomeInc=(int)(clone $manual)->where('type','income')->sum('amount_inc_gst_minor');
        $manualExpenseInc=(int)(clone $manual)->where('type','expense')->sum('amount_inc_gst_minor');
        $manualIncomeGst=(int)(clone $manual)->where('type','income')->sum('gst_minor');
        $manualExpenseGst=(int)(clone $manual)->where('type','expense')->sum('gst_minor');

        $invoiceSubtotal=$invoiceTax=$invoiceTotal=$creditSubtotal=$creditTax=$creditTotal=0;
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_crm_invoice_postings')){
            $facts=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->whereBetween('issued_at',[$from.' 00:00:00',$to.' 23:59:59'])->limit(10000)->get();
            foreach($facts as $fact){
                if((string)$fact->document_type==='invoice'){
                    $invoiceSubtotal+=(int)$fact->subtotal_minor; $invoiceTax+=(int)$fact->tax_minor; $invoiceTotal+=(int)$fact->total_minor;
                } elseif((string)$fact->document_type==='credit_note'){
                    $creditSubtotal+=(int)$fact->subtotal_minor; $creditTax+=(int)$fact->tax_minor; $creditTotal+=(int)$fact->total_minor;
                }
            }
        }

        $settlementCashIn=$settlementCashOut=$merchantFees=$settledReceivables=$paymentOverpayments=$paymentRefunds=0;
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_payment_settlements')){
            $settlements=$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->whereBetween('settled_at',[$from.' 00:00:00',$to.' 23:59:59'])->limit(10000)->get();
            foreach($settlements as $settlement){
                $merchantFees+=(int)$settlement->fee_minor;
                if((string)$settlement->settlement_type==='payment'){
                    $settlementCashIn+=(int)$settlement->cash_movement_minor;
                    $settledReceivables+=(int)$settlement->allocation_minor;
                    $paymentOverpayments+=(int)$settlement->overpayment_minor;
                } elseif((string)$settlement->settlement_type==='refund'){
                    $settlementCashOut+=(int)$settlement->cash_movement_minor;
                    $paymentRefunds+=(int)$settlement->gross_amount_minor;
                }
            }
        }

        $bankingCashIn=$bankingCashOut=$bankingFees=0;
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_banking_movements')){
            $moves=$this->db->table('titan_ledger_banking_movements')->where('company_id',$companyId)->whereBetween('occurred_at',[$from.' 00:00:00',$to.' 23:59:59'])->limit(10000)->get();
            foreach($moves as $move){$type=(string)$move->movement_type;$fee=(int)$move->fee_minor;$bankingFees+=$fee;if($type==='clearing_settlement')$bankingCashIn+=(int)$move->amount_minor;elseif($type==='credit_card_payment')$bankingCashOut+=(int)$move->amount_minor+$fee;elseif($type==='internal_transfer')$bankingCashOut+=$fee;}
        }

        $supplierBillSubtotal=$supplierBillGst=$supplierCreditSubtotal=$supplierCreditGst=$spendActualSubtotal=$spendActualGst=$supplierCashOut=$spendCashOut=$spendFees=0;
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_spend_postings')){
            $spendRows=$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->whereBetween('occurred_at',[$from.' 00:00:00',$to.' 23:59:59'])->limit(10000)->get();
            foreach($spendRows as $spend){
                $type=(string)$spend->posting_type;
                if($type==='supplier_bill'){$supplierBillSubtotal+=(int)$spend->subtotal_minor;$supplierBillGst+=(int)$spend->gst_minor;}
                elseif($type==='supplier_credit'){$supplierCreditSubtotal+=(int)$spend->subtotal_minor;$supplierCreditGst+=(int)$spend->gst_minor;}
                elseif($type==='supplier_payment'){$spendFees+=(int)$spend->fee_minor;if((string)$spend->rail!=='card')$supplierCashOut+=(int)$spend->amount_minor+(int)$spend->fee_minor;}
                elseif($type==='spend_actual'){$spendActualSubtotal+=(int)$spend->subtotal_minor;$spendActualGst+=(int)$spend->gst_minor;$spendFees+=(int)$spend->fee_minor;if((string)$spend->rail!=='card')$spendCashOut+=(int)$spend->total_minor+(int)$spend->fee_minor;}
            }
        }

        $manualSummary=$this->summary->summarize($manualIncomeInc,$manualIncomeGst,$manualExpenseInc,$manualExpenseGst,0,0,0,0);
        $netInvoiceRevenue=$invoiceSubtotal-$creditSubtotal;
        $netInvoiceTax=$invoiceTax-$creditTax;
        $manualSummary['income_minor']+=$netInvoiceRevenue;
        $manualSummary['profit_minor']+=$netInvoiceRevenue;
        $manualSummary['gst_collected_minor']+=$netInvoiceTax;
        $manualSummary['net_gst_minor']+=$netInvoiceTax;
        $manualSummary['invoice_revenue_minor']=$invoiceSubtotal;
        $manualSummary['credit_note_revenue_minor']=$creditSubtotal;
        $manualSummary['receivables_movement_minor']=$invoiceTotal-$creditTotal;
        $manualSummary['expense_minor']+=$merchantFees;
        $manualSummary['profit_minor']-=$merchantFees;
        $manualSummary['cash_in_minor']+=$settlementCashIn+$bankingCashIn;
        $manualSummary['cash_out_minor']+=$settlementCashOut+$bankingCashOut;
        $manualSummary['expense_minor']+=$bankingFees;
        $manualSummary['profit_minor']-=$bankingFees;
        $manualSummary['net_cash_movement_minor']=$manualSummary['cash_in_minor']-$manualSummary['cash_out_minor'];
        $manualSummary['gross_cash_in_minor']=$manualSummary['cash_in_minor'];
        $manualSummary['refunds_minor']+=$paymentRefunds;
        $manualSummary['merchant_fees_minor']=$merchantFees;
        $manualSummary['settled_receivables_minor']=$settledReceivables;
        $manualSummary['customer_overpayments_minor']=$paymentOverpayments;
        $manualSummary['payment_refunds_minor']=$paymentRefunds;
        $netSupplierExpense=$supplierBillSubtotal-$supplierCreditSubtotal+$spendActualSubtotal+$spendFees;
        $netSupplierGst=$supplierBillGst-$supplierCreditGst+$spendActualGst;
        $manualSummary['expense_minor']+=$netSupplierExpense;
        $manualSummary['profit_minor']-=$netSupplierExpense;
        $manualSummary['gst_paid_minor']+=$netSupplierGst;
        $manualSummary['net_gst_minor']-=$netSupplierGst;
        $manualSummary['cash_out_minor']+=$supplierCashOut+$spendCashOut;
        $manualSummary['net_cash_movement_minor']=$manualSummary['cash_in_minor']-$manualSummary['cash_out_minor'];
        $manualSummary['supplier_bill_expense_minor']=$supplierBillSubtotal;
        $manualSummary['supplier_credit_expense_minor']=$supplierCreditSubtotal;
        $manualSummary['spend_actual_expense_minor']=$spendActualSubtotal;
        $manualSummary['supplier_spend_fees_minor']=$spendFees;
        $manualSummary['supplier_cash_out_minor']=$supplierCashOut;
        $manualSummary['spend_actual_cash_out_minor']=$spendCashOut;
        $manualSummary['banking_cash_in_minor']=$bankingCashIn;
        $manualSummary['banking_cash_out_minor']=$bankingCashOut;
        $manualSummary['banking_fees_minor']=$bankingFees;
        $manualSummary['cash_scope']='manual_bookkeeping_plus_titan_pay_plus_ledger_spend_plus_multi_account_banking_evidence';

        return ['from'=>$from,'to'=>$to,'currency'=>config('crm.settings.defaults.default_currency','AUD')]+$manualSummary;
    }

    public function profitAndLoss(int $userId, ?string $from=null, ?string $to=null): array
    {
        $summary=$this->overview($userId,$from,$to);
        $companyId=$this->companyContext->companyId($userId);
        $q=$this->db->table('crm_bookkeeping_transactions as t')
            ->leftJoin('crm_bookkeeping_categories as c',function($j){$j->on('c.public_id','=','t.category_public_id')->on('c.company_id','=','t.company_id');})
            ->where('t.company_id',$companyId)->whereNull('t.deleted_at')->whereBetween('t.transaction_date',[$summary['from'],$summary['to']])
            ->selectRaw("t.type, COALESCE(c.name, 'Uncategorised') as category, SUM(t.amount_ex_gst_minor) as total_minor")
            ->groupBy('t.type','c.name')->orderBy('t.type')->orderBy('c.name')->limit(10000)->get();
        $breakdown=['income'=>[],'expense'=>[]];
        foreach($q as $r) $breakdown[(string)$r->type][]=['category'=>(string)$r->category,'total_minor'=>(int)$r->total_minor];
        $netCrmInvoiceRevenue=(int)$summary['invoice_revenue_minor']-(int)$summary['credit_note_revenue_minor'];
        if($netCrmInvoiceRevenue!==0) $breakdown['income'][]=['category'=>'CRM invoice revenue','total_minor'=>$netCrmInvoiceRevenue];
        if((int)($summary['merchant_fees_minor']??0)!==0) $breakdown['expense'][]=['category'=>'Bank and Merchant Fees','total_minor'=>(int)$summary['merchant_fees_minor']];
        $netSupplierExpense=(int)($summary['supplier_bill_expense_minor']??0)-(int)($summary['supplier_credit_expense_minor']??0)+(int)($summary['spend_actual_expense_minor']??0);
        if($netSupplierExpense!==0) $breakdown['expense'][]=['category'=>'Supplier bills and spend','total_minor'=>$netSupplierExpense];
        if((int)($summary['supplier_spend_fees_minor']??0)!==0) $breakdown['expense'][]=['category'=>'Supplier payment and spend fees','total_minor'=>(int)$summary['supplier_spend_fees_minor']];
        $summary['categories']=$breakdown;
        return $summary;
    }

    public function financialYearRange(?int $yearEnding=null): array
    {
        $now=Carbon::now('Australia/Melbourne');
        $yearEnding=$yearEnding??($now->month>=7?$now->year+1:$now->year);
        return [($yearEnding-1).'-07-01',$yearEnding.'-06-30'];
    }

    private function range(?string $from,?string $to): array
    {
        $now=Carbon::now((string)config('crm.bookkeeping.reporting_timezone','Australia/Melbourne'));
        $from=$from?:$now->copy()->startOfMonth()->toDateString();
        $to=$to?:$now->toDateString();
        return [$from,$to];
    }
}
