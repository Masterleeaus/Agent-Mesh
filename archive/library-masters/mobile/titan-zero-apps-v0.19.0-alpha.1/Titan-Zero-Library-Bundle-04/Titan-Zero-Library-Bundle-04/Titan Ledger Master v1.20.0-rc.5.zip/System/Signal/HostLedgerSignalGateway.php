<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

final class HostLedgerSignalGateway implements LedgerSignalGatewayContract
{
    public const HOST_BINDING = 'titan.signal.publisher.v1';

    public function __construct(private Container $container, private LedgerSignalGatewayContract $fallback) {}

    public function available(): bool
    {
        if (!$this->container->bound(self::HOST_BINDING)) return false;
        try {
            $publisher = $this->container->make(self::HOST_BINDING);
            return is_object($publisher) && method_exists($publisher, 'publish');
        } catch (Throwable) {
            return false;
        }
    }

    public function publish(array $envelope): array
    {
        if (!$this->container->bound(self::HOST_BINDING)) return $this->fallback->publish($envelope);
        $publisher = $this->container->make(self::HOST_BINDING);
        if (!is_object($publisher) || !method_exists($publisher, 'publish')) return $this->fallback->publish($envelope);

        $result = $publisher->publish($envelope);
        if ($result === false) throw new RuntimeException('Titan Signal publisher rejected Ledger event.');
        if ($result === null || $result === true) return ['accepted' => true, 'signal_id' => $envelope['signal_id'] ?? null];
        if (!is_array($result)) throw new RuntimeException('Titan Signal publisher returned an unsupported receipt.');
        if (($result['accepted'] ?? true) !== true) throw new RuntimeException('Titan Signal publisher did not accept Ledger event.');
        return $result + ['accepted' => true, 'signal_id' => $envelope['signal_id'] ?? null];
    }
}
