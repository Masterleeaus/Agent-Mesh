<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Banking;

use DateTimeImmutable;
use InvalidArgumentException;

final class MultiAccountBankingFact
{
    public static function transfer(array $p): array{return self::base($p,'internal_transfer')+['source_account_public_id'=>self::id($p,'source_account_public_id'),'destination_account_public_id'=>self::id($p,'destination_account_public_id'),'amount_minor'=>self::positive($p,'amount_minor'),'fee_minor'=>self::nonNegative($p,'fee_minor')];}
    public static function clearing(array $p): array{return self::base($p,'clearing_settlement')+['source_account_public_id'=>self::id($p,'clearing_account_public_id'),'destination_account_public_id'=>self::id($p,'bank_account_public_id'),'amount_minor'=>self::positive($p,'amount_minor'),'fee_minor'=>0];}
    public static function cardPayment(array $p): array{return self::base($p,'credit_card_payment')+['source_account_public_id'=>self::id($p,'bank_account_public_id'),'destination_account_public_id'=>self::id($p,'credit_card_account_public_id'),'amount_minor'=>self::positive($p,'amount_minor'),'fee_minor'=>self::nonNegative($p,'fee_minor')];}
    public static function hash(array $fact): string{return hash('sha256',self::json($fact));}
    private static function base(array $p,string $type): array{$id=self::id($p,'movement_public_id');$currency=strtoupper(trim((string)($p['currency']??'')));if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Banking movement currency must be ISO-4217 style.');$occurred=trim((string)($p['occurred_at']??''));if($occurred==='')throw new InvalidArgumentException('Banking movement occurred_at is required.');try{$d=new DateTimeImmutable($occurred);}catch(\Throwable){throw new InvalidArgumentException('Banking movement occurred_at is invalid.');}$event=self::id($p,'source_event_id',120);return ['movement_type'=>$type,'movement_public_id'=>$id,'currency'=>$currency,'occurred_at'=>$d->format('Y-m-d H:i:s'),'entry_date'=>$d->format('Y-m-d'),'source_event_id'=>$event,'source_version'=>max(1,(int)($p['source_version']??1)),'reference_hash'=>self::hashReference($p['reference']??null)];}
    private static function id(array $p,string $k,int $max=100): string{$v=trim((string)($p[$k]??''));if($v===''||strlen($v)>$max)throw new InvalidArgumentException($k.' is required.');return $v;}
    private static function positive(array $p,string $k): int{$v=self::integer($p,$k);if($v<1)throw new InvalidArgumentException($k.' must be positive.');return $v;}
    private static function nonNegative(array $p,string $k): int{$v=self::integer($p,$k);if($v<0)throw new InvalidArgumentException($k.' must not be negative.');return $v;}
    private static function integer(array $p,string $k): int{if(!array_key_exists($k,$p)||filter_var($p[$k],FILTER_VALIDATE_INT)===false)throw new InvalidArgumentException($k.' must be integer minor units.');return (int)$p[$k];}
    private static function hashReference(mixed $v): ?string{$v=trim((string)($v??''));return $v===''?null:hash('sha256',strtolower(preg_replace('/\s+/',' ',$v)??$v));}
    private static function json(array $v): string{ksort($v,SORT_STRING);return (string)json_encode($v,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
}
