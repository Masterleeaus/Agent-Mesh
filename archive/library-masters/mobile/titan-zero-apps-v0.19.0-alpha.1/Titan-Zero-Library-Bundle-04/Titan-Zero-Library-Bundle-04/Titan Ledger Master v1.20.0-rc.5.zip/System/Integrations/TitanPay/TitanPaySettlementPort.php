<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\TitanPay;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;

final class TitanPaySettlementPort
{
    public function __construct(private LedgerCommandSubmissionService $commands) {}
    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    public function paymentSettled(int $actorUserId,array $fact,array $context=[]): array { $n=TitanPaySettlementFact::payment($fact); return $this->submit($actorUserId,'ledger.payment.settlement.post',$n,$context); }
    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    public function paymentRefunded(int $actorUserId,array $fact,array $context=[]): array { $n=TitanPaySettlementFact::refund($fact); return $this->submit($actorUserId,'ledger.payment.refund.post',$n,$context); }
    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    private function submit(int $actorUserId,string $command,array $fact,array $context): array { $commandId='titan-pay-ledger:'.substr(hash('sha256',$command.'|'.$fact['source_event_id'].'|'.TitanPaySettlementFact::hash($fact)),0,48); return $this->commands->submit($actorUserId,$command,$commandId,(string)$fact['settlement_public_id'],$fact,$context,'titan-pay'); }
}
