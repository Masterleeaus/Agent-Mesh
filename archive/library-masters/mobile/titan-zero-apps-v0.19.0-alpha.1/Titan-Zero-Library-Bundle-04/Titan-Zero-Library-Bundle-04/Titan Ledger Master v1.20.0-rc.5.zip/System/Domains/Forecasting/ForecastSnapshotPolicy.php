<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

use DateTimeImmutable;
use InvalidArgumentException;

final class ForecastSnapshotPolicy
{
    public function supports(string $type): bool{return in_array($type,['cashflow_forecast','profitability_pack','cashflow_profitability_pack'],true);}
    public function assertPrepareAllowed(string $type,string $currency,string $asOf,int $horizonDays): void
    {
        if(!$this->supports($type))throw new InvalidArgumentException('Unsupported forecast snapshot type.');
        if(strtoupper($currency)!=='AUD')throw new InvalidArgumentException('Forecast snapshot finalization currently requires AUD-normalized Ledger evidence.');
        try{new DateTimeImmutable($asOf);}catch(\Throwable){throw new InvalidArgumentException('Forecast as_of date is invalid.');}
        if($horizonDays<1||$horizonDays>366)throw new InvalidArgumentException('Forecast horizon must be between 1 and 366 days.');
    }
    public function canFinalize(array $snapshot): bool{return ($snapshot['status']??null)==='prepared'&&preg_match('/^[a-f0-9]{64}$/',(string)($snapshot['source_fingerprint']??''))===1&&preg_match('/^[a-f0-9]{64}$/',(string)($snapshot['forecast_hash']??''))===1&&(int)($snapshot['evidence_coverage_bps']??-1)>=0&&(int)($snapshot['evidence_coverage_bps']??10001)<=10000;}
    public function assertFinalizeAllowed(array $snapshot,string $currentFingerprint): void{if(!$this->canFinalize($snapshot))throw new InvalidArgumentException('Forecast snapshot is not eligible for finalization.');if(!hash_equals((string)$snapshot['source_fingerprint'],$currentFingerprint))throw new InvalidArgumentException('Forecast snapshot source evidence changed after preparation. Prepare a new version.');}
}
