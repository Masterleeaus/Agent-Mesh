<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Bookkeeping;

use InvalidArgumentException;

final class BookkeepingGstCalculator
{
    /** @return array{amount_ex_gst_minor:int,gst_minor:int,amount_inc_gst_minor:int,gst_rate_bps:int,gst_treatment:string} */
    public function calculate(int $amountMinor, string $treatment, int $gstRateBps = 1000): array
    {
        if ($amountMinor < 0) throw new InvalidArgumentException('Bookkeeping amount cannot be negative.');
        if ($gstRateBps < 0 || $gstRateBps > 10000) throw new InvalidArgumentException('GST rate must be between 0 and 10000 basis points.');
        if (! in_array($treatment, ['inclusive','exclusive','gst_free'], true)) throw new InvalidArgumentException('Invalid GST treatment.');

        if ($treatment === 'gst_free' || $gstRateBps === 0) {
            return [
                'amount_ex_gst_minor' => $amountMinor,
                'gst_minor' => 0,
                'amount_inc_gst_minor' => $amountMinor,
                'gst_rate_bps' => $gstRateBps,
                'gst_treatment' => 'gst_free',
            ];
        }

        if ($treatment === 'inclusive') {
            $gst = (int) round($amountMinor * $gstRateBps / (10000 + $gstRateBps), 0, PHP_ROUND_HALF_UP);
            $exclusive = $amountMinor - $gst;
            return [
                'amount_ex_gst_minor' => $exclusive,
                'gst_minor' => $gst,
                'amount_inc_gst_minor' => $amountMinor,
                'gst_rate_bps' => $gstRateBps,
                'gst_treatment' => 'inclusive',
            ];
        }

        $gst = (int) round($amountMinor * $gstRateBps / 10000, 0, PHP_ROUND_HALF_UP);
        return [
            'amount_ex_gst_minor' => $amountMinor,
            'gst_minor' => $gst,
            'amount_inc_gst_minor' => $amountMinor + $gst,
            'gst_rate_bps' => $gstRateBps,
            'gst_treatment' => 'exclusive',
        ];
    }
    /** @return array{amount_ex_gst_minor:int,gst_minor:int,amount_inc_gst_minor:int,gst_rate_bps:int,gst_treatment:string} */
    public function calculateUpdate(
        int $storedExclusiveMinor,
        int $storedGstMinor,
        int $storedInclusiveMinor,
        string $storedTreatment,
        int $storedRateBps,
        array $changes,
    ): array {
        $definitionChanged = array_key_exists('gst_treatment', $changes) || array_key_exists('gst_rate_bps', $changes);
        if ($definitionChanged && ! array_key_exists('amount_minor', $changes)) {
            throw new InvalidArgumentException('Bookkeeping amount is required when changing GST treatment or rate.');
        }

        if (! array_key_exists('amount_minor', $changes)) {
            return [
                'amount_ex_gst_minor' => $storedExclusiveMinor,
                'gst_minor' => $storedGstMinor,
                'amount_inc_gst_minor' => $storedInclusiveMinor,
                'gst_rate_bps' => $storedRateBps,
                'gst_treatment' => $storedTreatment,
            ];
        }

        $amountMinor = (int) $changes['amount_minor'];
        if ($amountMinor < 1) throw new InvalidArgumentException('Bookkeeping amount must be positive.');

        return $this->calculate(
            $amountMinor,
            (string) ($changes['gst_treatment'] ?? $storedTreatment),
            (int) ($changes['gst_rate_bps'] ?? $storedRateBps),
        );
    }

}
