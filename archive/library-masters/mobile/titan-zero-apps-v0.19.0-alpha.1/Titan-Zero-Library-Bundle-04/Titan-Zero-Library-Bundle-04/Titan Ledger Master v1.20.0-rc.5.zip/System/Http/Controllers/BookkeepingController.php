<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Bookkeeping\{BookkeepingCategoryService,BookkeepingReportService,BookkeepingTransactionService};
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\Http\Support\LedgerCommandHttpContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class BookkeepingController extends Controller
{
    public function __construct(private BookkeepingCategoryService $categories,private BookkeepingTransactionService $transactions,private BookkeepingReportService $reports,private LedgerCommandSubmissionService $commands) {}

    public function index(Request $request) { $userId=(int)$request->user()->id;$from=$request->string('from')->toString()?:null;$to=$request->string('to')->toString()?:null; return view('titan-ledger::bookkeeping.index',['summary'=>$this->reports->overview($userId,$from,$to),'pnl'=>$this->reports->profitAndLoss($userId,$from,$to),'categories'=>$this->categories->all($userId),'transactions'=>$this->transactions->search($userId,['from'=>$from,'to'=>$to],100)]); }
    public function overview(Request $request){$u=(int)$request->user()->id;return response()->json($this->reports->overview($u,$request->string('from')->toString()?:null,$request->string('to')->toString()?:null));}
    public function profitAndLoss(Request $request){$u=(int)$request->user()->id;return response()->json($this->reports->profitAndLoss($u,$request->string('from')->toString()?:null,$request->string('to')->toString()?:null));}
    public function transactions(Request $request){return response()->json(['data'=>$this->transactions->search((int)$request->user()->id,$request->only(['type','category_public_id','work_order_public_id','source_domain','currency','from','to']),$request->integer('limit',200))]);}
    public function categories(Request $request){return response()->json(['data'=>$this->categories->all((int)$request->user()->id,$request->string('type')->toString()?:null)]);}

    public function storeTransaction(Request $request)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','type'=>'required|in:income,expense','description'=>'required|string|max:255','amount_minor'=>'nullable|integer|min:1','amount'=>'nullable|numeric|min:0.01','transaction_date'=>'nullable|date','category_public_id'=>'nullable|string|max:26','work_order_public_id'=>'nullable|string|max:26','company_public_id'=>'nullable|string|max:26','contact_public_id'=>'nullable|string|max:26','gst_treatment'=>'nullable|in:inclusive,exclusive,gst_free','gst_rate_bps'=>'nullable|integer|min:0|max:10000','currency'=>'nullable|string|size:3','payee_name'=>'nullable|string|max:190','reference'=>'nullable|string|max:160','payment_method'=>'nullable|string|max:80','notes'=>'nullable|string']);
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']); $data['amount_minor']=$this->minor($data);
        $row=$this->commands->submit((int)$request->user()->id,'ledger.bookkeeping.transaction.create',$commandId,null,$data,LedgerCommandHttpContext::lineage($request,$data)); return $this->respond($request,$row,'Bookkeeping transaction saved.');
    }
    public function updateTransaction(Request $request,string $transaction)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','type'=>'nullable|in:income,expense','description'=>'nullable|string|max:255','amount_minor'=>'nullable|integer|min:1','amount'=>'nullable|numeric|min:0.01','transaction_date'=>'nullable|date','category_public_id'=>'nullable|string|max:26','gst_treatment'=>'nullable|in:inclusive,exclusive,gst_free','gst_rate_bps'=>'nullable|integer|min:0|max:10000','payee_name'=>'nullable|string|max:190','reference'=>'nullable|string|max:160','payment_method'=>'nullable|string|max:80','notes'=>'nullable|string']);
        $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']); if(isset($data['amount'])&&!isset($data['amount_minor']))$data['amount_minor']=(int)round((float)$data['amount']*100);
        $row=$this->commands->submit((int)$request->user()->id,'ledger.bookkeeping.transaction.update',$commandId,$transaction,$data,LedgerCommandHttpContext::lineage($request,$data)); return $this->respond($request,$row,'Bookkeeping transaction updated.');
    }
    public function deleteTransaction(Request $request,string $transaction)
    {
        $commandId=LedgerCommandHttpContext::commandId($request); $row=$this->commands->submit((int)$request->user()->id,'ledger.bookkeeping.transaction.delete',$commandId,$transaction); if($request->expectsJson())return response()->json($row); return back()->with('success','Bookkeeping transaction deleted.');
    }
    public function storeCategory(Request $request)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','type'=>'required|in:income,expense','name'=>'required|string|max:180','description'=>'nullable|string','sort_order'=>'nullable|integer|min:0']); $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        $row=$this->commands->submit((int)$request->user()->id,'ledger.bookkeeping.category.create',$commandId,null,$data); return $this->respond($request,$row,'Bookkeeping category created.');
    }

    private function minor(array $data):int{if(isset($data['amount_minor']))return(int)$data['amount_minor'];return(int)round((float)($data['amount']??0)*100);}
    private function respond(Request $request,array $row,string $message){if($request->expectsJson())return response()->json($row,201);return back()->with('success',$message);}
}
