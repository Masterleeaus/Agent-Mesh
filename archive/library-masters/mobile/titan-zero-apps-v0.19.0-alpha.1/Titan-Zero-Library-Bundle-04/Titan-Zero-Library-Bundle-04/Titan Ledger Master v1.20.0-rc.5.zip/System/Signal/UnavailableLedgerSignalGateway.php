<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

use RuntimeException;

final class UnavailableLedgerSignalGateway implements LedgerSignalGatewayContract
{
    public function available(): bool { return false; }

    public function publish(array $envelope): array
    {
        throw new RuntimeException('Titan Signal publisher is unavailable; Ledger Signal delivery fails closed and remains queued in the durable outbox.');
    }
}
