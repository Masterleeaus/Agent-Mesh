<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use InvalidArgumentException;

final class GstAdjustmentCalculator
{
    /** @param array<string,mixed> $base @param array<int,array<string,mixed>> $adjustments @return array<string,mixed> */
    public static function apply(array $base,array $adjustments,string $reportingMethod='simpler_bas'): array
    {
        if(!in_array($reportingMethod,['simpler_bas','full_bas'],true))throw new InvalidArgumentException('Unsupported GST reporting method.');
        $out=$base+[
            'g2_export_sales_minor'=>0,'g3_gst_free_sales_minor'=>0,'g10_capital_purchases_minor'=>0,'g11_noncapital_purchases_minor'=>0,
            'approved_adjustment_count'=>0,'pending_adjustment_count'=>0,'rejected_adjustment_count'=>0,'accountant_review_complete'=>true,
        ];
        $out['reporting_method']=$reportingMethod;$tokens=[];
        foreach($adjustments as $row){
            $status=strtolower(trim((string)($row['review_status']??'pending')));$tokens[]=self::sourceToken($row);
            if($status==='pending'){ $out['pending_adjustment_count']++; continue; }
            if($status==='rejected'){ $out['rejected_adjustment_count']++; continue; }
            if($status!=='approved')throw new InvalidArgumentException('GST adjustment review status is invalid.');
            $out['approved_adjustment_count']++;
            $type=(string)($row['adjustment_type']??'');$gross=(int)($row['gross_amount_minor']??0);$gst=(int)($row['gst_amount_minor']??0);
            switch($type){
                case 'bad_debt_writeoff': $out['g1_total_sales_minor']-=$gross;$out['one_a_gst_on_sales_minor']-=$gst;break;
                case 'bad_debt_recovery': $out['g1_total_sales_minor']+=$gross;$out['one_a_gst_on_sales_minor']+=$gst;break;
                case 'mixed_acquisition':
                    $bps=(int)($row['claimable_percent_bps']??0);if($bps<0||$bps>10000)throw new InvalidArgumentException('Mixed acquisition claimable percent is invalid.');
                    $claimable=(int)round($gst*$bps/10000,0,PHP_ROUND_HALF_UP);$out['one_b_gst_on_purchases_minor']+=($claimable-$gst);break;
                case 'export_sales_classification': $out['g2_export_sales_minor']+=$gross;break;
                case 'gst_free_sales_classification': $out['g3_gst_free_sales_minor']+=$gross;break;
                case 'capital_purchase_classification': $out['g10_capital_purchases_minor']+=$gross;break;
                case 'noncapital_purchase_classification': $out['g11_noncapital_purchases_minor']+=$gross;break;
                case 'input_taxed_adjustment': $out['one_b_gst_on_purchases_minor']+=(int)($row['one_b_delta_minor']??-$gst);break;
                case 'other_gst_adjustment':
                    foreach(['g1_total_sales_minor'=>'g1_delta_minor','one_a_gst_on_sales_minor'=>'one_a_delta_minor','one_b_gst_on_purchases_minor'=>'one_b_delta_minor','g2_export_sales_minor'=>'g2_delta_minor','g3_gst_free_sales_minor'=>'g3_delta_minor','g10_capital_purchases_minor'=>'g10_delta_minor','g11_noncapital_purchases_minor'=>'g11_delta_minor','total_purchases_minor'=>'purchases_delta_minor'] as $dst=>$src)$out[$dst]+=(int)($row[$src]??0);
                    break;
                default: throw new InvalidArgumentException('Unsupported GST adjustment type.');
            }
        }
        sort($tokens,SORT_STRING);$out['net_gst_payable_minor']=$out['one_a_gst_on_sales_minor']-$out['one_b_gst_on_purchases_minor'];
        $review=is_array($base['review_reasons']??null)?$base['review_reasons']:[];
        if($out['pending_adjustment_count']>0)$review[]='pending_gst_adjustments_require_review';
        foreach(['g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','total_purchases_minor','g2_export_sales_minor','g3_gst_free_sales_minor','g10_capital_purchases_minor','g11_noncapital_purchases_minor'] as $field)if((int)$out[$field]<0)$review[]='negative_bas_label_requires_review';
        if($reportingMethod==='full_bas'){
            if($out['g2_export_sales_minor']+$out['g3_gst_free_sales_minor']>$out['g1_total_sales_minor'])$review[]='full_bas_sales_classification_exceeds_g1';
            if($out['g10_capital_purchases_minor']+$out['g11_noncapital_purchases_minor']!==$out['total_purchases_minor'])$review[]='full_bas_purchase_classification_incomplete';
        }
        $review=array_values(array_unique($review));$out['accountant_review_complete']=$out['pending_adjustment_count']===0;$out['review_reasons']=$review;$out['lodgement_ready']=$review===[];
        $out['adjustment_source_fingerprint']=hash('sha256',implode('|',$tokens));
        $out['source_fingerprint']=hash('sha256',(string)($base['source_fingerprint']??'').'|'.$reportingMethod.'|'.$out['adjustment_source_fingerprint']);
        return $out;
    }

    private static function sourceToken(array $row): string
    {
        $hash=strtolower(trim((string)($row['fact_hash']??'')));if(!preg_match('/^[a-f0-9]{64}$/',$hash))$hash=hash('sha256',json_encode($row,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        return $hash.':'.strtolower((string)($row['review_status']??'pending')).':'.strtolower((string)($row['review_public_id']??'none'));
    }
}
