<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Certification;

use Illuminate\Database\ConnectionInterface;
use RuntimeException;

final class LedgerProductionDatabaseHardener
{
    private const REPAIR_MIGRATIONS = [
        '2026_08_20_000003_create_titan_ledger_journals.php',
        '2026_08_20_000004_create_titan_ledger_financial_periods.php',
        '2026_08_20_000005_create_titan_ledger_command_receipts.php',
        '2026_08_20_000006_create_titan_ledger_signal_outbox.php',
        '2026_08_20_000007_add_titan_ledger_governance_evidence.php',
        '2026_08_20_000008_create_titan_ledger_crm_invoice_postings.php',
        '2026_08_20_000009_create_titan_ledger_payment_settlements.php',
        '2026_08_20_000010_create_titan_ledger_receivables.php',
        '2026_08_20_000011_create_titan_ledger_payables_and_spend.php',
        '2026_08_20_000012_create_titan_ledger_bank_reconciliation.php',
        '2026_08_20_000013_create_titan_ledger_gst_tax_snapshots.php',
        '2026_08_20_000014_create_titan_ledger_financial_report_snapshots.php',
        '2026_08_20_000015_create_titan_ledger_forecast_snapshots.php',
    ];

    public function __construct(private ConnectionInterface $db) {}

    public function repair(bool $includeFiscalClose = true): array
    {
        if ($this->db->getDriverName() !== 'mysql') {
            throw new RuntimeException('Titan Ledger production hardening requires MySQL.');
        }

        $migrationRoot = dirname(__DIR__, 2) . '/database/migrations';
        $replayed = [];
        $repairMigrations = self::REPAIR_MIGRATIONS;
        if ($includeFiscalClose) { $repairMigrations[] = '2026_08_21_000017_create_titan_ledger_financial_year_closes.php'; $repairMigrations[] = '2026_08_21_000018_create_titan_ledger_gst_adjustments.php'; $repairMigrations[] = '2026_08_21_000019_create_titan_ledger_multi_account_banking.php'; $repairMigrations[] = '2026_08_21_000020_create_titan_ledger_advanced_reconciliation.php'; }
        foreach ($repairMigrations as $filename) {
            $path = $migrationRoot . '/' . $filename;
            if (! is_file($path)) throw new RuntimeException('Titan Ledger hardening migration source is missing: ' . $filename);
            $migration = require $path;
            if (! is_object($migration) || ! method_exists($migration, 'up')) throw new RuntimeException('Titan Ledger hardening could not load migration: ' . $filename);
            $migration->up();
            $replayed[] = $filename;
        }

        $this->markFinancialEvidenceRetained();
        $present = $this->presentTriggers();
        $requiredTriggers = ProductionTriggerCatalog::names();
        if (! $includeFiscalClose) $requiredTriggers = array_values(array_diff($requiredTriggers, ['tl_fy_close_guard_update','tl_fy_close_no_delete','tl_fy_close_event_no_update','tl_fy_close_event_no_delete']));
        $missing = array_values(array_diff($requiredTriggers, $present));
        if ($missing !== []) throw new RuntimeException('Titan Ledger trigger self-heal incomplete: ' . implode(', ', $missing));

        return [
            'driver' => 'mysql',
            'migration_repairs' => count($replayed),
            'required_triggers' => count($requiredTriggers),
            'present_triggers' => count(array_intersect($requiredTriggers, $present)),
            'ownership_policy' => 'retain_financial_evidence',
            'status' => 'PASS',
        ];
    }

    private function markFinancialEvidenceRetained(): void
    {
        $schema = $this->db->getSchemaBuilder();
        if (! $schema->hasTable('titan_ledger_schema_ownership')) {
            throw new RuntimeException('Titan Ledger schema ownership registry is missing.');
        }

        $rows = $this->db->table('titan_ledger_schema_ownership')->where('owner_extension', 'titan-ledger')->limit(10000)->get();
        foreach ($rows as $row) {
            $mode = (string) ($row->ownership_mode ?? 'legacy_unknown');
            if (! str_starts_with($mode, 'retain_')) $mode = 'retain_' . $mode;
            $this->db->table('titan_ledger_schema_ownership')->where('id', $row->id)->update([
                'ownership_mode' => substr($mode, 0, 30),
                'updated_at' => now(),
            ]);
        }
    }

    private function presentTriggers(): array
    {
        return array_map(
            static fn ($row): string => (string) ($row->TRIGGER_NAME ?? $row->trigger_name ?? ''),
            $this->db->select('SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()')
        );
    }
}
