<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use DateInterval;
use DateTimeImmutable;
use InvalidArgumentException;

final class FinancialYearCalendar
{
    public function australianYearForDate(string $date): array
    {
        $d = $this->date($date);
        $year = (int) $d->format('Y');
        $month = (int) $d->format('n');
        $endYear = $month >= 7 ? $year + 1 : $year;
        return [
            'label' => 'FY' . $endYear,
            'starts_on' => sprintf('%04d-07-01', $endYear - 1),
            'ends_on' => sprintf('%04d-06-30', $endYear),
        ];
    }

    public function monthlyPeriods(string $startsOn, string $endsOn): array
    {
        $start = $this->date($startsOn);
        $end = $this->date($endsOn);
        if ($start > $end) throw new InvalidArgumentException('Financial year start date must not be after its end date.');

        $periods = [];
        $cursor = $start;
        $sequence = 1;
        while ($cursor <= $end) {
            $monthEnd = $cursor->modify('last day of this month');
            if ($monthEnd > $end) $monthEnd = $end;
            $periods[] = [
                'sequence' => $sequence++,
                'label' => $cursor->format('M Y'),
                'starts_on' => $cursor->format('Y-m-d'),
                'ends_on' => $monthEnd->format('Y-m-d'),
            ];
            $cursor = $monthEnd->add(new DateInterval('P1D'));
        }
        return $periods;
    }

    private function date(string $date): DateTimeImmutable
    {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', trim($date));
        $errors = DateTimeImmutable::getLastErrors();
        if (! $parsed || (is_array($errors) && (($errors['warning_count'] ?? 0) > 0 || ($errors['error_count'] ?? 0) > 0))) {
            throw new InvalidArgumentException('Expected a valid YYYY-MM-DD date.');
        }
        return $parsed;
    }
}
