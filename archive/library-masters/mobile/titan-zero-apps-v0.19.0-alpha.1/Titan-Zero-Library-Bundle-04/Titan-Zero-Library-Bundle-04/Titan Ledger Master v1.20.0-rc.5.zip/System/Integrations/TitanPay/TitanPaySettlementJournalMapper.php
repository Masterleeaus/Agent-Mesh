<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\TitanPay;

use InvalidArgumentException;

final class TitanPaySettlementJournalMapper
{
    /** @param array<string,mixed> $fact @param array<string,string> $accounts @return array<int,array<string,mixed>> */
    public static function paymentLines(array $fact,array $accounts,int $allocationMinor,int $overpaymentMinor): array
    {
        $gross=(int)($fact['gross_amount_minor']??0); $fee=(int)($fact['fee_minor']??0); $net=(int)($fact['net_amount_minor']??0);
        if($allocationMinor<0||$overpaymentMinor<0||$allocationMinor+$overpaymentMinor!==$gross||$net+$fee!==$gross) throw new InvalidArgumentException('Titan Pay payment allocation does not balance.');
        self::requireAccounts($accounts,['bank','accounts_receivable','customer_overpayments','merchant_fees']);
        $lines=[];
        if($net>0)$lines[]=self::line($accounts['bank'],'Titan Pay cash settlement',$net,0,'bas_excluded');
        if($fee>0)$lines[]=self::line($accounts['merchant_fees'],'Titan Pay merchant fee',$fee,0,'gst_free');
        if($allocationMinor>0)$lines[]=self::line($accounts['accounts_receivable'],'Accounts receivable settlement',0,$allocationMinor,'bas_excluded');
        if($overpaymentMinor>0)$lines[]=self::line($accounts['customer_overpayments'],'Customer credit / overpayment',0,$overpaymentMinor,'bas_excluded');
        return $lines;
    }

    /** @param array<string,mixed> $fact @param array<string,string> $accounts @return array<int,array<string,mixed>> */
    public static function refundLines(array $fact,array $accounts,int $overpaymentRefundMinor,int $allocationRefundMinor): array
    {
        $amount=(int)($fact['refund_amount_minor']??0); $fee=(int)($fact['refund_fee_minor']??0);
        if($overpaymentRefundMinor<0||$allocationRefundMinor<0||$overpaymentRefundMinor+$allocationRefundMinor!==$amount) throw new InvalidArgumentException('Titan Pay refund allocation does not balance.');
        self::requireAccounts($accounts,['bank','accounts_receivable','customer_overpayments','merchant_fees']);
        $lines=[];
        if($overpaymentRefundMinor>0)$lines[]=self::line($accounts['customer_overpayments'],'Refund customer overpayment',$overpaymentRefundMinor,0,'bas_excluded');
        if($allocationRefundMinor>0)$lines[]=self::line($accounts['accounts_receivable'],'Refund reopens receivable',$allocationRefundMinor,0,'bas_excluded');
        if($fee>0)$lines[]=self::line($accounts['merchant_fees'],'Titan Pay refund fee',$fee,0,'gst_free');
        $lines[]=self::line($accounts['bank'],'Titan Pay customer refund',0,$amount+$fee,'bas_excluded');
        return $lines;
    }

    /** @param array<string,string> $accounts @param array<int,string> $keys */
    private static function requireAccounts(array $accounts,array $keys): void { foreach($keys as $key) if(trim((string)($accounts[$key]??''))==='') throw new InvalidArgumentException('Required Ledger system account unavailable: '.$key.'.'); }
    /** @return array<string,mixed> */
    private static function line(string $account,string $description,int $debit,int $credit,string $taxCode): array { return ['account_public_id'=>$account,'description'=>$description,'debit_minor'=>$debit,'credit_minor'=>$credit,'tax_code'=>$taxCode,'tax_amount_minor'=>0,'metadata'=>null]; }
}
