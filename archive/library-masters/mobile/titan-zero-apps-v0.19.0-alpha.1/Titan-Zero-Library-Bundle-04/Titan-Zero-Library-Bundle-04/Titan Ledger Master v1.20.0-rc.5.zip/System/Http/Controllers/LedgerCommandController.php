<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class LedgerCommandController extends Controller
{
    public function __construct(private LedgerCommandSubmissionService $commands) {}

    public function execute(Request $request)
    {
        $data = $request->validate([
            'command_id' => 'required|string|max:191',
            'command_name' => 'required|string|max:120',
            'target_public_id' => 'nullable|string|max:191',
            'payload' => 'nullable|array',
            'trace_id' => 'nullable|string|max:120',
            'correlation_id' => 'nullable|string|max:120',
            'causation_id' => 'nullable|string|max:120',
        ]);

        return response()->json($this->commands->submit(
            (int) $request->user()->id,
            $data['command_name'],
            $data['command_id'],
            $data['target_public_id'] ?? null,
            $data['payload'] ?? [],
            [
                'trace_id' => $data['trace_id'] ?? null,
                'correlation_id' => $data['correlation_id'] ?? null,
                'causation_id' => $data['causation_id'] ?? null,
            ],
            'titan-ledger-api',
        ));
    }
}
