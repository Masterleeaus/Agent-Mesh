<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

use DateTimeImmutable;

final class TransferRecognition
{
    /** @param array<string,mixed> $a @param array<string,mixed> $b @return array<string,mixed> */
    public static function pair(array $a,array $b): array
    {
        $aa=(int)($a['amount_minor']??0);$bb=(int)($b['amount_minor']??0);$acctA=trim((string)($a['account_public_id']??''));$acctB=trim((string)($b['account_public_id']??''));
        if($acctA===''||$acctB===''||$acctA===$acctB||$aa===0||$aa+$bb!==0)return ['status'=>'unmatched'];
        try{$da=new DateTimeImmutable((string)($a['posted_on']??''));$db=new DateTimeImmutable((string)($b['posted_on']??''));}catch(\Throwable){return ['status'=>'unmatched'];}
        $days=(int)$da->diff($db)->days;if($days>3)return ['status'=>'unmatched'];
        $out=$aa<0?$a:$b;$in=$aa>0?$a:$b;$score=90+($days===0?20:($days===1?15:10));
        $ra=$a['reference_hash']??null;$rb=$b['reference_hash']??null;if(is_string($ra)&&$ra!==''&&is_string($rb)&&$rb!==''&&hash_equals($ra,$rb))$score+=20;
        return ['status'=>'suggested','source_transaction_public_id'=>(string)$out['transaction_public_id'],'destination_transaction_public_id'=>(string)$in['transaction_public_id'],'source_account_public_id'=>(string)$out['account_public_id'],'destination_account_public_id'=>(string)$in['account_public_id'],'amount_minor'=>abs((int)$out['amount_minor']),'score'=>$score,'date_distance_days'=>$days];
    }
}
