<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

final class ForecastVarianceCalculator
{
    /** @param array<int,array<string,mixed>> $schedule @param array<string,mixed> $actual */
    public function compare(array $schedule,string $through,array $actual): array
    {
        $expectedIn=0;$expectedOut=0;
        foreach($schedule as $row){$date=(string)($row['date']??'');if($date===''||$date>$through)continue;$expectedIn+=(int)($row['inflow_minor']??0);$expectedOut+=(int)($row['outflow_minor']??0);}
        $actualIn=(int)($actual['inflow_minor']??0);$actualOut=(int)($actual['outflow_minor']??0);$expectedNet=$expectedIn-$expectedOut;$actualNet=(int)($actual['net_cashflow_minor']??($actualIn-$actualOut));
        return ['through'=>$through,'expected_inflows_minor'=>$expectedIn,'actual_inflows_minor'=>$actualIn,'inflow_variance_minor'=>$actualIn-$expectedIn,'expected_outflows_minor'=>$expectedOut,'actual_outflows_minor'=>$actualOut,'outflow_variance_minor'=>$actualOut-$expectedOut,'expected_net_cashflow_minor'=>$expectedNet,'actual_net_cashflow_minor'=>$actualNet,'net_cashflow_variance_minor'=>$actualNet-$expectedNet];
    }
}
