<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Integrations\Banking;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
final class BankReconciliationPort
{
    public function __construct(private LedgerCommandSubmissionService $commands){}
    public function statementImported(int $actorUserId,array $fact,array $context=[]): array{$n=BankStatementFact::statement($fact);$id='bank-ledger:'.substr(hash('sha256','statement|'.$n['source_event_id'].'|'.BankStatementFact::hash($n)),0,48);return $this->commands->submit($actorUserId,'ledger.bank.statement.import',$id,(string)$n['statement_public_id'],$n,$context,(string)$n['source_extension']);}
    public function match(int $actorUserId,string $transactionPublicId,string $candidatePublicId,?string $reasonCode=null,array $context=[]): array{$payload=['candidate_public_id'=>$candidatePublicId,'reason_code'=>$reasonCode];$id='bank-match:'.substr(hash('sha256',$transactionPublicId.'|'.$candidatePublicId.'|'.json_encode($context)),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.match',$id,$transactionPublicId,$payload,$context,'titan-bank-reconciliation');}
    public function rejectMatch(int $actorUserId,string $transactionPublicId,string $candidatePublicId,string $reasonCode,array $context=[]): array{$payload=['candidate_public_id'=>$candidatePublicId,'reason_code'=>$reasonCode];$id='bank-reject:'.substr(hash('sha256',$transactionPublicId.'|'.$candidatePublicId.'|'.$reasonCode),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.reject_match',$id,$transactionPublicId,$payload,$context,'titan-bank-reconciliation');}
    public function close(int $actorUserId,string $sessionPublicId,string $reasonCode,array $context=[]): array{$payload=['reason_code'=>$reasonCode];$id='bank-close:'.substr(hash('sha256',$sessionPublicId.'|'.$reasonCode),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.close',$id,$sessionPublicId,$payload,$context,'titan-bank-reconciliation');}
}
