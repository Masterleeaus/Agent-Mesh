<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

final class FinancialYearCloseChecklist
{
    /** @param array<string,mixed> $evidence */
    public function evaluate(array $evidence): array
    {
        $blockers = [];
        if (($evidence['year_status'] ?? null) !== 'open') $blockers[] = 'financial_year_not_open';
        if ((int)($evidence['period_count'] ?? 0) < 1) $blockers[] = 'accounting_periods_missing';
        if ((int)($evidence['open_period_count'] ?? 0) > 0) $blockers[] = 'accounting_periods_not_soft_locked';
        if ((int)($evidence['hard_locked_period_count'] ?? 0) > 0) $blockers[] = 'accounting_periods_hard_locked';
        if ((int)($evidence['unposted_journal_count'] ?? 0) > 0) $blockers[] = 'unposted_journals_present';
        if ((int)($evidence['trial_balance_difference_minor'] ?? 0) !== 0) $blockers[] = 'trial_balance_unbalanced';
        if ((int)($evidence['unreconciled_bank_session_count'] ?? 0) > 0) $blockers[] = 'bank_reconciliation_open';
        if ((int)($evidence['draft_gst_snapshot_count'] ?? 0) > 0) $blockers[] = 'gst_snapshot_unfinalized';
        if (strtoupper((string)($evidence['currency'] ?? '')) !== 'AUD') $blockers[] = 'currency_not_aud_normalized';
        if (!preg_match('/^[a-f0-9]{64}$/', (string)($evidence['source_fingerprint'] ?? ''))) $blockers[] = 'source_fingerprint_missing';

        return [
            'ready' => $blockers === [],
            'blocking_count' => count($blockers),
            'blocking_codes' => $blockers,
            'evidence' => $evidence,
        ];
    }
}
