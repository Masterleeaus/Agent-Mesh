<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Reporting;

use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementService;
use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotService;

final class FinancialReportingReadPort
{
    public function __construct(private FinancialStatementService $reports, private FinancialReportSnapshotService $snapshots) {}
    public function trialBalance(int $userId,string $asOf,string $currency='AUD'): array{return $this->reports->trialBalance($userId,$asOf,$currency);}
    public function profitLoss(int $userId,string $from,string $to,string $currency='AUD'): array{return $this->reports->profitLoss($userId,$from,$to,$currency);}
    public function balanceSheet(int $userId,string $asOf,string $currency='AUD'): array{return $this->reports->balanceSheet($userId,$asOf,$currency);}
    public function retainedEarnings(int $userId,string $from,string $to,string $currency='AUD'): array{return $this->reports->retainedEarnings($userId,$from,$to,$currency);}
    public function managementPack(int $userId,string $from,string $to,string $currency='AUD'): array{return $this->reports->managementPack($userId,$from,$to,$currency);}
    public function accountDrilldown(int $userId,string $accountPublicId,string $from,string $to,string $currency='AUD',int $limit=200): array{return $this->reports->accountDrilldown($userId,$accountPublicId,$from,$to,$currency,$limit);}
    public function snapshots(int $userId,int $limit=200): array{return $this->snapshots->all($userId,$limit);}
}
