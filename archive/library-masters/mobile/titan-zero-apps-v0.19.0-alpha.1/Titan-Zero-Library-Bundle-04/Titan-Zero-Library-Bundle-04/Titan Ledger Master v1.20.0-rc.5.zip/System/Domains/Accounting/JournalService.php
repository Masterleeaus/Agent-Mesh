<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class JournalService
{
    private const EDITABLE_STATUSES = ['draft', 'validated'];
    private const USER_JOURNAL_TYPES = ['general', 'adjustment', 'opening_balance', 'accrual', 'import'];

    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private ChartOfAccountsService $accounts,
        private JournalEntryValidator $validator,
        private AccountingPeriodService $periods,
    ) {}

    public function all(int $userId, array $filters = []): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $q = $this->db->table('titan_ledger_journals')->where('company_id', $companyId);
        if (! empty($filters['status'])) $q->where('status', (string) $filters['status']);
        if (! empty($filters['journal_type'])) $q->where('journal_type', (string) $filters['journal_type']);
        if (! empty($filters['date_from'])) $q->whereDate('entry_date', '>=', (string) $filters['date_from']);
        if (! empty($filters['date_to'])) $q->whereDate('entry_date', '<=', (string) $filters['date_to']);
        return $q->orderByDesc('entry_date')->orderByDesc('id')->limit(500)->get()->map(fn ($row) => (array) $row)->all();
    }

    public function show(int $userId, string $publicId): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $journal = $this->journalForCompany($companyId, $publicId);
        $data = (array) $journal;
        $data['lines'] = $this->linesFor($companyId, $publicId);
        return $data;
    }

    public function createDraft(int $userId, array $data): array
    {
        $journalType = trim((string) ($data['journal_type'] ?? 'general'));
        if (in_array($journalType, ['reversal', 'correction'], true)) {
            throw new InvalidArgumentException('Reversal and correction journals must use their dedicated governed creation methods.');
        }
        if (! in_array($journalType, self::USER_JOURNAL_TYPES, true)) {
            throw new InvalidArgumentException('Unsupported journal type.');
        }

        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $this->accounts->ensureDefaults($userId);
        $publicId = (string) Str::ulid();

        return $this->db->transaction(function () use ($data, $journalType, $companyId, $actor, $publicId): array {
            $this->db->table('titan_ledger_journals')->insert($this->headerInsert(
                publicId: $publicId,
                companyId: $companyId,
                actor: $actor,
                journalType: $journalType,
                data: $data,
            ));

            if (array_key_exists('lines', $data)) {
                $this->storeLines($companyId, $publicId, $data['lines'], requireBalanced: false);
            }

            return $this->showForCompany($companyId, $publicId);
        });
    }

    public function replaceDraftLines(int $userId, string $publicId, array $lines): array
    {
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->transaction(function () use ($companyId, $publicId, $lines): array {
            $journal = $this->lockedJournal($companyId, $publicId);
            $this->assertMutable($journal);
            $this->storeLines($companyId, $publicId, $lines, requireBalanced: false);
            $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $publicId)->update([
                'status' => 'draft',
                'validated_at' => null,
                'validated_by_user_id' => null,
                'debit_total_minor' => null,
                'credit_total_minor' => null,
                'payload_hash' => null,
                'lock_version' => ((int) $journal->lock_version) + 1,
                'updated_at' => now(),
            ]);
            return $this->showForCompany($companyId, $publicId);
        });
    }

    public function validateDraft(int $userId, string $publicId): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        return $this->db->transaction(function () use ($companyId, $actor, $publicId): array {
            $journal = $this->lockedJournal($companyId, $publicId);
            $this->assertMutable($journal);
            $lines = $this->linesFor($companyId, $publicId);
            $validation = $this->validator->validate($lines, true);
            $this->assertAccounts($companyId, $validation['normalized_lines'], allowInactiveAccounts: false);
            $payloadHash = $this->payloadHash($journal, $validation['normalized_lines']);

            $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $publicId)->update([
                'status' => 'validated',
                'validated_at' => now(),
                'validated_by_user_id' => $actor,
                'debit_total_minor' => $validation['debit_total_minor'],
                'credit_total_minor' => $validation['credit_total_minor'],
                'payload_hash' => $payloadHash,
                'lock_version' => ((int) $journal->lock_version) + 1,
                'updated_at' => now(),
            ]);
            return $this->showForCompany($companyId, $publicId);
        });
    }

    public function post(int $userId, string $publicId, string $operationId): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $operationId = $this->requiredOperationId($operationId);

        return $this->db->transaction(function () use ($companyId, $actor, $publicId, $operationId): array {
            $journal = $this->lockedJournal($companyId, $publicId);
            return $this->postLocked($companyId, $actor, $journal, $operationId, allowInactiveAccounts: false);
        });
    }

    public function reverse(int $userId, string $publicId, string $operationId, array $data = []): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $operationId = $this->requiredOperationId($operationId);

        return $this->db->transaction(function () use ($companyId, $actor, $publicId, $operationId, $data): array {
            $collision = $this->journalByPostingOperation($companyId, $operationId);
            if ($collision) {
                if ((string) ($collision->reversal_of_public_id ?? '') === $publicId && (string) $collision->status === 'posted') {
                    return $this->showForCompany($companyId, (string) $collision->public_id);
                }
                throw new InvalidArgumentException('Idempotency key collision: posting operation already belongs to another journal.');
            }

            $original = $this->lockedJournal($companyId, $publicId);
            if ((string) $original->status !== 'posted') throw new InvalidArgumentException('Only posted journals can be reversed.');

            $existingReversal = $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('reversal_of_public_id', $publicId)->first();
            if ($existingReversal) throw new InvalidArgumentException('Journal already has a reversal.');

            $originalLines = $this->linesFor($companyId, $publicId);
            $reversedLines = array_map(static fn (array $line): array => [
                'account_public_id' => (string) $line['account_public_id'],
                'description' => $line['description'] ?? null,
                'debit_minor' => (int) $line['credit_minor'],
                'credit_minor' => (int) $line['debit_minor'],
                'tax_code' => $line['tax_code'] ?? null,
                'tax_amount_minor' => -((int) ($line['tax_amount_minor'] ?? 0)),
                'metadata' => ['reverses_line_public_id' => $line['public_id'] ?? null],
            ], $originalLines);

            $validation = $this->validator->validate($reversedLines, true);
            $this->assertAccounts($companyId, $validation['normalized_lines'], allowInactiveAccounts: true);
            $reversalId = (string) Str::ulid();
            $entryDate = trim((string) ($data['entry_date'] ?? '')) ?: now()->toDateString();

            $headerData = [
                'entry_date' => $entryDate,
                'memo' => $data['memo'] ?? ('Reversal of ' . ((string) ($original->journal_number ?? $original->public_id))),
                'currency' => (string) $original->currency,
                'source_extension' => 'titan-ledger',
                'source_type' => 'journal.reversal',
                'source_public_id' => $publicId,
                'trace_id' => $data['trace_id'] ?? $original->trace_id,
                'correlation_id' => $data['correlation_id'] ?? $original->correlation_id,
                'causation_id' => $data['causation_id'] ?? $original->source_event_id,
                'prior_period_adjustment' => (bool) ($data['prior_period_adjustment'] ?? false),
                'period_override_reason' => $data['period_override_reason'] ?? null,
                'metadata' => ['reversal_reason' => $data['reason'] ?? null],
            ];
            $insert = $this->headerInsert($reversalId, $companyId, $actor, 'reversal', $headerData);
            $insert['reversal_of_public_id'] = $publicId;
            $insert['status'] = 'validated';
            $insert['validated_at'] = now();
            $insert['validated_by_user_id'] = $actor;
            $insert['debit_total_minor'] = $validation['debit_total_minor'];
            $insert['credit_total_minor'] = $validation['credit_total_minor'];
            $this->db->table('titan_ledger_journals')->insert($insert);
            $this->insertNormalizedLines($companyId, $reversalId, $validation['normalized_lines']);

            $reversal = $this->lockedJournal($companyId, $reversalId);
            $hash = $this->payloadHash($reversal, $validation['normalized_lines']);
            $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $reversalId)->update(['payload_hash' => $hash, 'updated_at' => now()]);
            $reversal = $this->lockedJournal($companyId, $reversalId);

            return $this->postLocked($companyId, $actor, $reversal, $operationId, allowInactiveAccounts: true);
        });
    }

    public function createCorrectionDraft(int $userId, string $publicId, array $data): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $this->accounts->ensureDefaults($userId);

        return $this->db->transaction(function () use ($companyId, $actor, $publicId, $data): array {
            $original = $this->lockedJournal($companyId, $publicId);
            if ((string) $original->status !== 'posted') throw new InvalidArgumentException('Corrections can only be linked to posted journals.');
            if (empty($data['lines']) || ! is_array($data['lines'])) throw new InvalidArgumentException('Correction journal lines are required.');

            $correctionId = (string) Str::ulid();
            $correctionData = array_merge($data, [
                'currency' => (string) $original->currency,
                'source_extension' => 'titan-ledger',
                'source_type' => 'journal.correction',
                'source_public_id' => $publicId,
                'correlation_id' => $original->correlation_id,
                'causation_id' => $original->source_event_id,
            ]);
            $insert = $this->headerInsert($correctionId, $companyId, $actor, 'correction', $correctionData);
            $insert['correction_of_public_id'] = $publicId;
            $this->db->table('titan_ledger_journals')->insert($insert);
            $this->storeLines($companyId, $correctionId, $data['lines'], requireBalanced: false);
            return $this->showForCompany($companyId, $correctionId);
        });
    }

    public function postAuthoritativeSourceJournal(
        int $userId,
        string $journalType,
        array $data,
        array $lines,
        string $operationId,
        ?string $correctionOfPublicId = null,
    ): array {
        if (! in_array($journalType, ['invoice','credit_note','payment','refund','supplier_bill','supplier_credit','supplier_payment','spend_actual','year_end_close','year_end_reopen','banking_transfer','clearing_settlement','credit_card_payment','bank_reconciliation_adjustment'], true)) {
            throw new InvalidArgumentException('Unsupported authoritative source journal type.');
        }
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $operationId = $this->requiredOperationId($operationId);
        $this->accounts->ensureDefaults($userId);

        return $this->db->transaction(function () use ($companyId, $actor, $journalType, $data, $lines, $operationId, $correctionOfPublicId): array {
            $collision = $this->journalByPostingOperation($companyId, $operationId);
            if ($collision) {
                if ((string) $collision->status === 'posted'
                    && (string) ($collision->source_extension ?? '') === (string) ($data['source_extension'] ?? '')
                    && (string) ($collision->source_public_id ?? '') === (string) ($data['source_public_id'] ?? '')
                    && (string) $collision->journal_type === $journalType) {
                    return $this->showForCompany($companyId, (string) $collision->public_id);
                }
                throw new InvalidArgumentException('Idempotency key collision: posting operation already belongs to another journal.');
            }

            if ($correctionOfPublicId !== null) {
                $original = $this->lockedJournal($companyId, $correctionOfPublicId);
                if ((string) $original->status !== 'posted') throw new InvalidArgumentException('Source correction requires a posted original journal.');
            }

            $validation = $this->validator->validate($lines, true);
            $this->assertAccounts($companyId, $validation['normalized_lines'], allowInactiveAccounts: false);
            $publicId = (string) Str::ulid();
            $insert = $this->headerInsert($publicId, $companyId, $actor, $journalType, $data);
            $insert['status'] = 'validated';
            $insert['validated_at'] = now();
            $insert['validated_by_user_id'] = $actor;
            $insert['debit_total_minor'] = $validation['debit_total_minor'];
            $insert['credit_total_minor'] = $validation['credit_total_minor'];
            $insert['correction_of_public_id'] = $correctionOfPublicId;
            $this->db->table('titan_ledger_journals')->insert($insert);
            $this->insertNormalizedLines($companyId, $publicId, $validation['normalized_lines']);

            $journal = $this->lockedJournal($companyId, $publicId);
            $hash = $this->payloadHash($journal, $validation['normalized_lines']);
            $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $publicId)->update(['payload_hash'=>$hash,'updated_at'=>now()]);
            $journal = $this->lockedJournal($companyId, $publicId);
            return $this->postLocked($companyId, $actor, $journal, $operationId, allowInactiveAccounts: false);
        });
    }

    private function postLocked(int $companyId, int $actor, object $journal, string $operationId, bool $allowInactiveAccounts): array
    {
        $collision = $this->journalByPostingOperation($companyId, $operationId);
        if ($collision) {
            if ((string) $collision->public_id === (string) $journal->public_id && (string) $collision->status === 'posted') {
                return $this->showForCompany($companyId, (string) $journal->public_id);
            }
            throw new InvalidArgumentException('Idempotency key collision: posting operation already belongs to another journal.');
        }

        if ((string) $journal->status === 'posted') {
            if ((string) ($journal->posting_operation_id ?? '') === $operationId) return $this->showForCompany($companyId, (string) $journal->public_id);
            throw new InvalidArgumentException('Journal already posted under a different operation id.');
        }
        if ((string) $journal->status !== 'validated') throw new InvalidArgumentException('Journal must be validated before posting.');

        $lines = $this->linesFor($companyId, (string) $journal->public_id);
        $validation = $this->validator->validate($lines, true);
        $this->assertAccounts($companyId, $validation['normalized_lines'], allowInactiveAccounts: $allowInactiveAccounts);
        $payloadHash = $this->payloadHash($journal, $validation['normalized_lines']);
        if (! hash_equals((string) ($journal->payload_hash ?? ''), $payloadHash)) {
            throw new InvalidArgumentException('Validated journal payload changed; revalidate before posting.');
        }

        $periodContext = $this->periods->assertPostingAllowed(
            $actor,
            (string) $journal->entry_date,
            (string) $journal->journal_type,
            (bool) ($journal->prior_period_adjustment ?? false),
            $journal->period_override_reason === null ? null : (string) $journal->period_override_reason,
        );
        $financialYear = $periodContext['financial_year'];
        $accountingPeriod = $periodContext['period'];

        $journalNumber = $journal->journal_number ?: ('JRN-' . strtoupper((string) $journal->public_id));
        $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', (string) $journal->public_id)->update([
            'journal_number' => $journalNumber,
            'status' => 'posted',
            'financial_year_public_id' => (string) $financialYear['public_id'],
            'accounting_period_public_id' => (string) $accountingPeriod['public_id'],
            'period_lock_state_at_post' => (string) $accountingPeriod['lock_state'],
            'posting_operation_id' => $operationId,
            'posted_at' => now(),
            'posted_by_user_id' => $actor,
            'debit_total_minor' => $validation['debit_total_minor'],
            'credit_total_minor' => $validation['credit_total_minor'],
            'lock_version' => ((int) $journal->lock_version) + 1,
            'updated_at' => now(),
        ]);

        return $this->showForCompany($companyId, (string) $journal->public_id);
    }

    private function storeLines(int $companyId, string $journalPublicId, array $lines, bool $requireBalanced): void
    {
        $validation = $this->validator->validate($lines, $requireBalanced);
        $this->assertAccounts($companyId, $validation['normalized_lines'], allowInactiveAccounts: false);
        $this->db->table('titan_ledger_journal_lines')->where('company_id', $companyId)->where('journal_public_id', $journalPublicId)->delete();
        $this->insertNormalizedLines($companyId, $journalPublicId, $validation['normalized_lines']);
    }

    private function insertNormalizedLines(int $companyId, string $journalPublicId, array $lines): void
    {
        foreach ($lines as $line) {
            $this->db->table('titan_ledger_journal_lines')->insert([
                'public_id' => (string) Str::ulid(),
                'company_id' => $companyId,
                'journal_public_id' => $journalPublicId,
                'line_no' => (int) $line['line_no'],
                'account_public_id' => (string) $line['account_public_id'],
                'description' => $line['description'],
                'debit_minor' => (int) $line['debit_minor'],
                'credit_minor' => (int) $line['credit_minor'],
                'tax_code' => $line['tax_code'],
                'tax_amount_minor' => (int) $line['tax_amount_minor'],
                'metadata' => $line['metadata'] === null ? null : json_encode($line['metadata'], JSON_THROW_ON_ERROR),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    private function assertAccounts(int $companyId, array $lines, bool $allowInactiveAccounts): void
    {
        $accountIds = array_values(array_unique(array_map(static fn (array $line): string => (string) $line['account_public_id'], $lines)));
        $accounts = $this->db->table('titan_ledger_accounts')->where('company_id', $companyId)->whereIn('public_id', $accountIds)->get()->keyBy('public_id');
        foreach ($accountIds as $accountId) {
            $account = $accounts->get($accountId);
            if (! $account) throw new InvalidArgumentException('Journal references an account outside this company or an unknown account: ' . $accountId . '.');
            if (! $allowInactiveAccounts && ! (bool) $account->is_active) throw new InvalidArgumentException('Journal references an inactive account: ' . $accountId . '.');
        }
    }

    private function assertMutable(object $journal): void
    {
        if ((string) $journal->status === 'posted') throw new InvalidArgumentException('Journal is immutable after posting.');
        if (! in_array((string) $journal->status, self::EDITABLE_STATUSES, true)) throw new InvalidArgumentException('Journal is not editable in its current state.');
    }

    private function lockedJournal(int $companyId, string $publicId): object
    {
        $journal = $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $publicId)->lockForUpdate()->first();
        if (! $journal) throw new InvalidArgumentException('Ledger journal not found.');
        return $journal;
    }

    private function journalForCompany(int $companyId, string $publicId): object
    {
        $journal = $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('public_id', $publicId)->first();
        if (! $journal) throw new InvalidArgumentException('Ledger journal not found.');
        return $journal;
    }

    private function journalByPostingOperation(int $companyId, string $operationId): ?object
    {
        return $this->db->table('titan_ledger_journals')->where('company_id', $companyId)->where('posting_operation_id', $operationId)->first();
    }

    private function linesFor(int $companyId, string $journalPublicId): array
    {
        return $this->db->table('titan_ledger_journal_lines')->where('company_id', $companyId)->where('journal_public_id', $journalPublicId)->orderBy('line_no')->limit(10000)->get()->map(fn ($row) => (array) $row)->all();
    }

    private function showForCompany(int $companyId, string $publicId): array
    {
        $journal = $this->journalForCompany($companyId, $publicId);
        $data = (array) $journal;
        $data['lines'] = $this->linesFor($companyId, $publicId);
        return $data;
    }

    private function payloadHash(object $journal, array $normalizedLines): string
    {
        $payload = [
            'journal_type' => (string) $journal->journal_type,
            'entry_date' => (string) $journal->entry_date,
            'currency' => (string) $journal->currency,
            'memo' => $journal->memo === null ? null : (string) $journal->memo,
            'source_extension' => $journal->source_extension === null ? null : (string) $journal->source_extension,
            'source_type' => $journal->source_type === null ? null : (string) $journal->source_type,
            'source_public_id' => $journal->source_public_id === null ? null : (string) $journal->source_public_id,
            'source_event_id' => $journal->source_event_id === null ? null : (string) $journal->source_event_id,
            'source_operation_id' => $journal->source_operation_id === null ? null : (string) $journal->source_operation_id,
            'trace_id' => $journal->trace_id === null ? null : (string) $journal->trace_id,
            'correlation_id' => $journal->correlation_id === null ? null : (string) $journal->correlation_id,
            'causation_id' => $journal->causation_id === null ? null : (string) $journal->causation_id,
            'metadata' => is_string($journal->metadata ?? null) ? json_decode((string) $journal->metadata, true) : ($journal->metadata ?? null),
            'reversal_of_public_id' => $journal->reversal_of_public_id === null ? null : (string) $journal->reversal_of_public_id,
            'correction_of_public_id' => $journal->correction_of_public_id === null ? null : (string) $journal->correction_of_public_id,
            'prior_period_adjustment' => (bool) ($journal->prior_period_adjustment ?? false),
            'period_override_reason' => $journal->period_override_reason === null ? null : (string) $journal->period_override_reason,
            'lines' => array_map(static fn (array $line): array => [
                'line_no' => (int) $line['line_no'],
                'account_public_id' => (string) $line['account_public_id'],
                'description' => $line['description'],
                'debit_minor' => (int) $line['debit_minor'],
                'credit_minor' => (int) $line['credit_minor'],
                'tax_code' => $line['tax_code'],
                'tax_amount_minor' => (int) $line['tax_amount_minor'],
                'metadata' => is_string($line['metadata'] ?? null) ? json_decode((string) $line['metadata'], true) : ($line['metadata'] ?? null),
            ], $normalizedLines),
        ];
        return hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private function headerInsert(string $publicId, int $companyId, int $actor, string $journalType, array $data): array
    {
        return [
            'public_id' => $publicId,
            'company_id' => $companyId,
            'journal_number' => null,
            'journal_type' => $journalType,
            'status' => 'draft',
            'entry_date' => trim((string) ($data['entry_date'] ?? '')) ?: now()->toDateString(),
            'currency' => strtoupper(trim((string) ($data['currency'] ?? 'AUD'))),
            'memo' => $this->nullableString($data['memo'] ?? null),
            'source_extension' => $this->nullableString($data['source_extension'] ?? null),
            'source_type' => $this->nullableString($data['source_type'] ?? null),
            'source_public_id' => $this->nullableString($data['source_public_id'] ?? null),
            'source_event_id' => $this->nullableString($data['source_event_id'] ?? null),
            'source_operation_id' => $this->nullableString($data['source_operation_id'] ?? null),
            'trace_id' => $this->nullableString($data['trace_id'] ?? null),
            'correlation_id' => $this->nullableString($data['correlation_id'] ?? null),
            'causation_id' => $this->nullableString($data['causation_id'] ?? null),
            'reversal_of_public_id' => null,
            'correction_of_public_id' => null,
            'posting_operation_id' => null,
            'financial_year_public_id' => null,
            'accounting_period_public_id' => null,
            'prior_period_adjustment' => (bool) ($data['prior_period_adjustment'] ?? false),
            'period_override_reason' => $this->nullableString($data['period_override_reason'] ?? null),
            'period_lock_state_at_post' => null,
            'payload_hash' => null,
            'lock_version' => 0,
            'created_by_user_id' => $actor,
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata'], JSON_THROW_ON_ERROR) : null,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }

    private function requiredOperationId(string $operationId): string
    {
        $operationId = trim($operationId);
        if ($operationId === '' || strlen($operationId) > 191) throw new InvalidArgumentException('A posting operation id is required and must be at most 191 characters.');
        return $operationId;
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
