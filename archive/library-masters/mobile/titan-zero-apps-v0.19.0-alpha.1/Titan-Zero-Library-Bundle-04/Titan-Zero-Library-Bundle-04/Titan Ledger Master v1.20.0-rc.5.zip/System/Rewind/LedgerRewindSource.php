<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Rewind;

use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class LedgerRewindSource
{
    public function __construct(private ConnectionInterface $db) {}
    public function sourceKey(): string { return 'titan-ledger.rewind-source'; }
    public function watermark(int $companyId, string $traceId): array
    {
        $this->assertScope($companyId,$traceId);
        $receipt=$this->db->table('titan_ledger_command_receipts')->where('company_id',$companyId)->where('trace_id',$traceId)->selectRaw('MAX(id) max_id, MAX(completed_at) observed_through')->first();
        $signal=$this->db->table('titan_ledger_signal_outbox')->where('company_id',$companyId)->where('trace_id',$traceId)->selectRaw('MAX(id) max_id, MAX(occurred_at) observed_through')->first();
        $through=max((string)($receipt->observed_through??''),(string)($signal->observed_through??''));
        return ['source_key'=>$this->sourceKey(),'company_id'=>$companyId,'trace_id'=>$traceId,'receipt_cursor'=>(int)($receipt->max_id??0),'signal_cursor'=>(int)($signal->max_id??0),'observed_through'=>$through!==''?$through:null,'completeness'=>'COMPLETE','supports_as_of'=>true,'authenticity'=>'sha256-canonical-json-v1','write_policy'=>'read-only'];
    }
    public function records(int $companyId, string $traceId, ?string $asOf=null): iterable
    {
        $this->assertScope($companyId,$traceId);
        $receipts=$this->db->table('titan_ledger_command_receipts')->where('company_id',$companyId)->where('trace_id',$traceId)->whereIn('status',['applied','failed','denied'])->when($asOf,fn($q)=>$q->where('completed_at','<=',$asOf))->orderBy('completed_at')->orderBy('id')->cursor()->getIterator();
        $signals=$this->db->table('titan_ledger_signal_outbox')->where('company_id',$companyId)->where('trace_id',$traceId)->when($asOf,fn($q)=>$q->where('occurred_at','<=',$asOf))->orderBy('occurred_at')->orderBy('id')->cursor()->getIterator();
        $receipts->rewind(); $signals->rewind();
        while($receipts->valid()||$signals->valid()){
            $r=$receipts->valid()?(array)$receipts->current():null; $s=$signals->valid()?(array)$signals->current():null;
            if($s===null||($r!==null&&$this->sortKey($r,'completed_at','r') <= $this->sortKey($s,'occurred_at','s'))){ yield LedgerRewindProjector::receipt($r); $receipts->next(); }
            else { yield LedgerRewindProjector::signal($s); $signals->next(); }
        }
    }
    private function sortKey(array $r,string $time,string $kind): string { return (string)($r[$time]??'').'|'.$kind.'|'.str_pad((string)($r['id']??0),20,'0',STR_PAD_LEFT); }
    private function assertScope(int $companyId,string $traceId): void { if($companyId<1)throw new InvalidArgumentException('Rewind company_id is required.'); $traceId=trim($traceId); if($traceId===''||strlen($traceId)>120)throw new InvalidArgumentException('Rewind trace_id is required.'); }
}
