<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Crm;

use InvalidArgumentException;

final class CrmInvoiceJournalMapper
{
    /** @param array<string,mixed> $fact @param array<string,string> $accounts @return array<int,array<string,mixed>> */
    public static function issuedLines(array $fact, array $accounts): array
    {
        self::assertAccounts($fact, $accounts);
        $lines=[self::line($accounts['accounts_receivable'], (int)$fact['total_minor'], 0, 'bas_excluded', 0, 'CRM invoice receivable')];
        foreach ($fact['revenue_splits'] as $split) $lines[]=self::line($accounts[$split['system_key']],0,(int)$split['amount_minor'],'gst_on_sales',0,'CRM invoice revenue');
        if ((int)$fact['tax_minor'] > 0) $lines[]=self::line($accounts['gst_payable'],0,(int)$fact['tax_minor'],'gst_on_sales',(int)$fact['tax_minor'],'CRM invoice GST');
        return $lines;
    }

    /** @param array<string,mixed> $fact @param array<string,string> $accounts @return array<int,array<string,mixed>> */
    public static function creditNoteLines(array $fact, array $accounts): array
    {
        self::assertAccounts($fact, $accounts);
        $lines=[];
        foreach ($fact['revenue_splits'] as $split) $lines[]=self::line($accounts[$split['system_key']],(int)$split['amount_minor'],0,'gst_on_sales',0,'CRM credit revenue correction');
        if ((int)$fact['tax_minor'] > 0) $lines[]=self::line($accounts['gst_payable'],(int)$fact['tax_minor'],0,'gst_on_sales',-((int)$fact['tax_minor']),'CRM credit GST correction');
        $lines[]=self::line($accounts['accounts_receivable'],0,(int)$fact['total_minor'],'bas_excluded',0,'CRM credit receivable correction');
        return $lines;
    }

    /** @param array<string,mixed> $fact @param array<string,string> $accounts */
    private static function assertAccounts(array $fact, array $accounts): void
    {
        foreach (['accounts_receivable','gst_payable'] as $key) if (empty($accounts[$key])) throw new InvalidArgumentException("Required Ledger system account missing: {$key}.");
        foreach ($fact['revenue_splits'] ?? [] as $split) if (empty($accounts[$split['system_key']])) throw new InvalidArgumentException('Required Ledger revenue account missing.');
    }

    /** @return array<string,mixed> */
    private static function line(string $account, int $debit, int $credit, string $taxCode, int $taxAmount, string $description): array
    {
        return ['account_public_id'=>$account,'description'=>$description,'debit_minor'=>$debit,'credit_minor'=>$credit,'tax_code'=>$taxCode,'tax_amount_minor'=>$taxAmount,'metadata'=>null];
    }
}
