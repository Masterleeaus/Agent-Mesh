<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

final class HostLedgerAssuranceGateway implements LedgerAssuranceGatewayContract
{
    private const BINDINGS = ['titan.assurance.gateway.titan-ledger','titan.assurance.gateway'];
    public function __construct(private Container $app, private LedgerAssuranceGatewayContract $fallback) {}
    public function available(): bool { foreach (self::BINDINGS as $b) { if (!$this->app->bound($b)) continue; try { $candidate=$this->app->make($b); } catch (Throwable) { continue; } if ($candidate===$this) continue; if ($candidate instanceof LedgerAssuranceGatewayContract) return true; if (is_object($candidate) && (method_exists($candidate,'verify') || method_exists($candidate,'evaluate'))) return true; if (is_callable($candidate)) return true; } return false; }
    public function verify(array $evidence): array
    {
        foreach (self::BINDINGS as $binding) {
            if (!$this->app->bound($binding)) continue;
            try { $candidate=$this->app->make($binding); } catch (Throwable) { continue; }
            if ($candidate === $this) continue;
            if ($candidate instanceof LedgerAssuranceGatewayContract) return $candidate->verify($evidence);
            if (is_object($candidate) && method_exists($candidate,'verify')) $result=$candidate->verify($evidence);
            elseif (is_object($candidate) && method_exists($candidate,'evaluate')) $result=$candidate->evaluate($evidence);
            elseif (is_callable($candidate)) $result=$candidate($evidence);
            else continue;
            if (!is_array($result)) throw new RuntimeException('Titan Assurance returned an invalid Ledger decision.');
            return $result;
        }
        return $this->fallback->verify($evidence);
    }
}
