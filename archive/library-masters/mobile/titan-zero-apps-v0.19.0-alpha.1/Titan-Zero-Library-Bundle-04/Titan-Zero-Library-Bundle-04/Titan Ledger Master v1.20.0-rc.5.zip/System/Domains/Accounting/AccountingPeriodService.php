<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use DateTimeImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AccountingPeriodService
{
    private const LOCK_STATES = ['open', 'soft_locked', 'hard_locked'];

    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private FinancialYearCalendar $calendar,
        private AccountingPeriodPolicy $policy,
    ) {}

    public function allYears(int $userId): array
    {
        return $this->db->table('titan_ledger_financial_years')
            ->where('company_id', $this->companyContext->companyId($userId))
            ->orderByDesc('starts_on')->limit(10000)->get()->map(fn ($row) => (array) $row)->all();
    }

    public function allPeriods(int $userId, ?string $financialYearPublicId = null): array
    {
        $q = $this->db->table('titan_ledger_accounting_periods')->where('company_id', $this->companyContext->companyId($userId));
        if ($financialYearPublicId !== null && trim($financialYearPublicId) !== '') $q->where('financial_year_public_id', trim($financialYearPublicId));
        return $q->orderByDesc('starts_on')->limit(10000)->get()->map(fn ($row) => (array) $row)->all();
    }

    public function createFinancialYear(int $userId, array $data): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $label = trim((string) ($data['label'] ?? ''));
        $startsOn = $this->date((string) ($data['starts_on'] ?? ''));
        $endsOn = $this->date((string) ($data['ends_on'] ?? ''));
        if ($label === '') throw new InvalidArgumentException('Financial year label is required.');
        if ($startsOn > $endsOn) throw new InvalidArgumentException('Financial year start date must not be after end date.');

        return $this->db->transaction(function () use ($companyId, $actor, $label, $startsOn, $endsOn, $data): array {
            $overlap = $this->db->table('titan_ledger_financial_years')
                ->where('company_id', $companyId)
                ->whereDate('starts_on', '<=', $endsOn->format('Y-m-d'))
                ->whereDate('ends_on', '>=', $startsOn->format('Y-m-d'))
                ->lockForUpdate()->first();
            if ($overlap) throw new InvalidArgumentException('Financial year overlaps an existing financial year.');

            $publicId = (string) Str::ulid();
            $this->db->table('titan_ledger_financial_years')->insert([
                'public_id' => $publicId,
                'company_id' => $companyId,
                'label' => $label,
                'starts_on' => $startsOn->format('Y-m-d'),
                'ends_on' => $endsOn->format('Y-m-d'),
                'calendar_type' => 'custom',
                'status' => 'open',
                'lock_version' => 0,
                'created_by_user_id' => $actor,
                'metadata' => isset($data['metadata']) ? json_encode($data['metadata'], JSON_THROW_ON_ERROR) : null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            $this->createPeriods($companyId, $publicId, $startsOn->format('Y-m-d'), $endsOn->format('Y-m-d'));
            return $this->yearForCompany($companyId, $publicId);
        });
    }

    public function ensureDefaultCoverageForDate(int $userId, string $date): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $date = $this->date($date)->format('Y-m-d');

        $existing = $this->periodCovering($companyId, $date, false);
        if ($existing) return $this->periodBundle($companyId, $existing);

        $fy = $this->calendar->australianYearForDate($date);
        return $this->db->transaction(function () use ($companyId, $actor, $date, $fy): array {
            $period = $this->periodCovering($companyId, $date, true);
            if ($period) return $this->periodBundle($companyId, $period);

            $year = $this->db->table('titan_ledger_financial_years')
                ->where('company_id', $companyId)
                ->whereDate('starts_on', '<=', $date)
                ->whereDate('ends_on', '>=', $date)
                ->lockForUpdate()->first();

            if (! $year) {
                $yearId = (string) Str::ulid();
                $this->db->table('titan_ledger_financial_years')->insertOrIgnore([
                    'public_id' => $yearId,
                    'company_id' => $companyId,
                    'label' => $fy['label'],
                    'starts_on' => $fy['starts_on'],
                    'ends_on' => $fy['ends_on'],
                    'calendar_type' => 'australian',
                    'status' => 'open',
                    'lock_version' => 0,
                    'created_by_user_id' => $actor,
                    'metadata' => json_encode(['provisioned_by' => 'journal_posting'], JSON_THROW_ON_ERROR),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
                $year = $this->db->table('titan_ledger_financial_years')
                    ->where('company_id', $companyId)
                    ->whereDate('starts_on', '<=', $date)
                    ->whereDate('ends_on', '>=', $date)
                    ->lockForUpdate()->first();
                if (! $year) throw new InvalidArgumentException('Unable to provision a financial year for journal date.');
            }

            $this->createPeriods($companyId, (string) $year->public_id, (string) $year->starts_on, (string) $year->ends_on);
            $period = $this->periodCovering($companyId, $date, true);
            if (! $period) throw new InvalidArgumentException('Unable to provision an accounting period for journal date.');
            return $this->periodBundle($companyId, $period);
        });
    }

    public function assertPostingAllowed(
        int $userId,
        string $entryDate,
        string $journalType,
        bool $priorPeriodAdjustment,
        ?string $overrideReason,
    ): array {
        $companyId = $this->companyContext->companyId($userId);
        $coverage = $this->ensureDefaultCoverageForDate($userId, $entryDate);
        $period = $this->db->table('titan_ledger_accounting_periods')
            ->where('company_id', $companyId)
            ->where('public_id', $coverage['period']['public_id'])
            ->lockForUpdate()->first();
        if (! $period) throw new InvalidArgumentException('Accounting period was not found while preparing to post.');

        $this->policy->assertPostingAllowed((string) $period->lock_state, $journalType, $priorPeriodAdjustment, $overrideReason);
        $year = $this->db->table('titan_ledger_financial_years')
            ->where('company_id', $companyId)
            ->where('public_id', (string) $period->financial_year_public_id)
            ->lockForUpdate()->first();
        if (! $year) throw new InvalidArgumentException('Financial year was not found while preparing to post.');
        if ((string) $year->status !== 'open') throw new InvalidArgumentException('Financial year is closed and must be reopened before posting.');

        return ['financial_year' => (array) $year, 'period' => (array) $period];
    }

    public function transitionPeriod(int $userId, string $periodPublicId, string $toState, string $reason, array $context = []): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $toState = trim($toState);
        $reason = trim($reason);
        if (! in_array($toState, self::LOCK_STATES, true)) throw new InvalidArgumentException('Unsupported accounting period lock state.');
        if ($reason === '') throw new InvalidArgumentException('A reason is required to change accounting period lock state.');

        return $this->db->transaction(function () use ($companyId, $actor, $periodPublicId, $toState, $reason, $context): array {
            $period = $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('public_id', $periodPublicId)->lockForUpdate()->first();
            if (! $period) throw new InvalidArgumentException('Accounting period not found.');
            $fromState = (string) $period->lock_state;
            if ($fromState === $toState) return (array) $period;

            $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('public_id', $periodPublicId)->update([
                'lock_state' => $toState,
                'lock_version' => ((int) $period->lock_version) + 1,
                'locked_by_user_id' => $actor,
                'locked_at' => now(),
                'lock_reason' => $reason,
                'updated_at' => now(),
            ]);
            $this->recordLockEvent($companyId, $actor, $period, $fromState, $toState, $reason, $context);
            return (array) $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('public_id', $periodPublicId)->first();
        });
    }

    public function closeFinancialYear(int $userId, string $yearPublicId, string $reason, array $context = []): array
    {
        return $this->setFinancialYearClosedState($userId, $yearPublicId, true, $reason, $context);
    }

    public function reopenFinancialYear(int $userId, string $yearPublicId, string $reason, array $context = []): array
    {
        return $this->setFinancialYearClosedState($userId, $yearPublicId, false, $reason, $context);
    }

    private function setFinancialYearClosedState(int $userId, string $yearPublicId, bool $close, string $reason, array $context): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $reason = trim($reason);
        if ($reason === '') throw new InvalidArgumentException('A reason is required to close or reopen a financial year.');

        return $this->db->transaction(function () use ($companyId, $actor, $yearPublicId, $close, $reason, $context): array {
            $year = $this->db->table('titan_ledger_financial_years')->where('company_id', $companyId)->where('public_id', $yearPublicId)->lockForUpdate()->first();
            if (! $year) throw new InvalidArgumentException('Financial year not found.');
            $targetYearStatus = $close ? 'closed' : 'open';
            if ((string) $year->status === $targetYearStatus) return $this->yearForCompany($companyId, $yearPublicId);

            $periods = $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('financial_year_public_id', $yearPublicId)->orderBy('period_no')->lockForUpdate()->limit(10000)->get();
            $targetPeriodState = $close ? 'hard_locked' : 'soft_locked';
            foreach ($periods as $period) {
                $fromState = (string) $period->lock_state;
                if ($fromState === $targetPeriodState) continue;
                $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('public_id', (string) $period->public_id)->update([
                    'lock_state' => $targetPeriodState,
                    'lock_version' => ((int) $period->lock_version) + 1,
                    'locked_by_user_id' => $actor,
                    'locked_at' => now(),
                    'lock_reason' => $reason,
                    'updated_at' => now(),
                ]);
                $this->recordLockEvent($companyId, $actor, $period, $fromState, $targetPeriodState, $reason, array_merge($context, ['financial_year_transition' => $targetYearStatus]));
            }

            $this->db->table('titan_ledger_financial_years')->where('company_id', $companyId)->where('public_id', $yearPublicId)->update([
                'status' => $targetYearStatus,
                'lock_version' => ((int) $year->lock_version) + 1,
                'closed_by_user_id' => $close ? $actor : null,
                'closed_at' => $close ? now() : null,
                'updated_at' => now(),
            ]);
            return $this->yearForCompany($companyId, $yearPublicId);
        });
    }

    private function createPeriods(int $companyId, string $yearPublicId, string $startsOn, string $endsOn): void
    {
        foreach ($this->calendar->monthlyPeriods($startsOn, $endsOn) as $period) {
            $this->db->table('titan_ledger_accounting_periods')->insertOrIgnore([
                'public_id' => (string) Str::ulid(),
                'company_id' => $companyId,
                'financial_year_public_id' => $yearPublicId,
                'period_no' => $period['sequence'],
                'label' => $period['label'],
                'starts_on' => $period['starts_on'],
                'ends_on' => $period['ends_on'],
                'lock_state' => 'open',
                'lock_version' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    private function periodCovering(int $companyId, string $date, bool $lock): ?object
    {
        $q = $this->db->table('titan_ledger_accounting_periods')
            ->where('company_id', $companyId)
            ->whereDate('starts_on', '<=', $date)
            ->whereDate('ends_on', '>=', $date);
        if ($lock) $q->lockForUpdate();
        return $q->first();
    }

    private function periodBundle(int $companyId, object $period): array
    {
        $year = $this->db->table('titan_ledger_financial_years')->where('company_id', $companyId)->where('public_id', (string) $period->financial_year_public_id)->first();
        if (! $year) throw new InvalidArgumentException('Financial year not found for accounting period.');
        return ['financial_year' => (array) $year, 'period' => (array) $period];
    }

    private function yearForCompany(int $companyId, string $publicId): array
    {
        $year = $this->db->table('titan_ledger_financial_years')->where('company_id', $companyId)->where('public_id', $publicId)->first();
        if (! $year) throw new InvalidArgumentException('Financial year not found.');
        $data = (array) $year;
        $data['periods'] = $this->db->table('titan_ledger_accounting_periods')->where('company_id', $companyId)->where('financial_year_public_id', $publicId)->orderBy('period_no')->limit(10000)->get()->map(fn ($row) => (array) $row)->all();
        return $data;
    }

    private function recordLockEvent(int $companyId, int $actor, object $period, string $fromState, string $toState, string $reason, array $context): void
    {
        $this->db->table('titan_ledger_period_lock_events')->insert([
            'public_id' => (string) Str::ulid(),
            'company_id' => $companyId,
            'financial_year_public_id' => (string) $period->financial_year_public_id,
            'period_public_id' => (string) $period->public_id,
            'from_state' => $fromState,
            'to_state' => $toState,
            'reason' => $reason,
            'actor_user_id' => $actor,
            'trace_id' => $this->nullableString($context['trace_id'] ?? null),
            'correlation_id' => $this->nullableString($context['correlation_id'] ?? null),
            'causation_id' => $this->nullableString($context['causation_id'] ?? null),
            'metadata' => isset($context['metadata']) ? json_encode($context['metadata'], JSON_THROW_ON_ERROR) : (isset($context['financial_year_transition']) ? json_encode(['financial_year_transition' => $context['financial_year_transition']], JSON_THROW_ON_ERROR) : null),
            'created_at' => now(),
        ]);
    }

    private function date(string $date): DateTimeImmutable
    {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', trim($date));
        $errors = DateTimeImmutable::getLastErrors();
        if (! $parsed || (is_array($errors) && (($errors['warning_count'] ?? 0) > 0 || ($errors['error_count'] ?? 0) > 0))) {
            throw new InvalidArgumentException('Expected a valid YYYY-MM-DD date.');
        }
        return $parsed;
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
