<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reporting;

use InvalidArgumentException;

final class FinancialReportSnapshotPolicy
{
    public function supports(string $reportType): bool
    {
        return in_array($reportType, ['trial_balance','profit_loss','balance_sheet','management_pack'], true);
    }

    public function assertPrepareAllowed(string $reportType, string $currency, string $periodStart, string $periodEnd): void
    {
        if (!$this->supports($reportType)) throw new InvalidArgumentException('Unsupported financial report snapshot type.');
        if (strtoupper($currency) !== 'AUD') throw new InvalidArgumentException('Finalizable financial report snapshots currently require AUD-normalized journals.');
        (new ComparativePeriodResolver())->resolve($periodStart, $periodEnd);
    }

    /** @param array<string,mixed> $snapshot */
    public function canFinalize(array $snapshot): bool
    {
        return ($snapshot['status'] ?? null) === 'prepared'
            && ($snapshot['balanced'] ?? false) === true
            && ($snapshot['complete'] ?? false) === true
            && preg_match('/^[a-f0-9]{64}$/', (string) ($snapshot['source_fingerprint'] ?? '')) === 1;
    }

    /** @param array<string,mixed> $snapshot */
    public function assertFinalizeAllowed(array $snapshot, string $currentSourceFingerprint): void
    {
        if (!$this->canFinalize($snapshot)) throw new InvalidArgumentException('Financial report snapshot is not eligible for finalization.');
        if (!hash_equals((string) $snapshot['source_fingerprint'], $currentSourceFingerprint)) {
            throw new InvalidArgumentException('Financial report source changed after preparation; prepare a new snapshot.');
        }
    }
}
