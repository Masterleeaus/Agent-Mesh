<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\Http\Support\LedgerCommandHttpContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class ChartOfAccountsController extends Controller
{
    public function __construct(private ChartOfAccountsService $accounts, private LedgerCommandSubmissionService $commands) {}

    public function index(Request $request)
    {
        return response()->json(['data' => $this->accounts->all((int) $request->user()->id, ! $request->boolean('include_inactive'))]);
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules(true));
        $commandId = LedgerCommandHttpContext::commandId($request);
        unset($data['command_id']);
        return response()->json($this->commands->submit((int) $request->user()->id, 'ledger.account.create', $commandId, null, $data, LedgerCommandHttpContext::lineage($request, $data)), 201);
    }

    public function update(Request $request, string $account)
    {
        $data = $request->validate($this->rules(false));
        $commandId = LedgerCommandHttpContext::commandId($request);
        unset($data['command_id']);
        return response()->json($this->commands->submit((int) $request->user()->id, 'ledger.account.update', $commandId, $account, $data, LedgerCommandHttpContext::lineage($request, $data)));
    }

    private function rules(bool $creating): array
    {
        return [
            'command_id' => 'nullable|string|max:191',
            'code' => ($creating ? 'required' : 'nullable') . '|string|max:20',
            'name' => ($creating ? 'required' : 'nullable') . '|string|max:191',
            'type' => ($creating ? 'required' : 'nullable') . '|in:asset,liability,equity,revenue,cost_of_sales,expense,other_income,other_expense',
            'subtype' => 'nullable|string|max:60',
            'tax_code' => 'nullable|string|max:40',
            'parent_public_id' => 'nullable|string|size:26',
            'is_active' => 'nullable|boolean',
            'sort_order' => 'nullable|integer|min:0',
            'metadata' => 'nullable|array',
        ];
    }
}
