<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GstTaxLedgerService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext,private GstSnapshotPolicy $policy,private GstTaxAdjustmentService $adjustments){}

    public function preview(int $userId,string $periodStart,string $periodEnd,string $reportingMethod='simpler_bas',string $accountingBasis='accrual'): array
    {
        $this->policy->assertPrepareAllowed($reportingMethod,$accountingBasis,$periodStart,$periodEnd);$companyId=$this->companyContext->companyId($userId);
        return $this->calculateCompanyPeriod($companyId,$periodStart,$periodEnd,$reportingMethod)+['period_start'=>$periodStart,'period_end'=>$periodEnd];
    }

    public function prepare(int $userId,string $periodKey,array $payload,string $operationId,array $command,?string $supersedes=null,?string $supersessionReason=null): array
    {
        $periodKey=$this->periodKey($periodKey);$start=(string)($payload['period_start']??'');$end=(string)($payload['period_end']??'');$method=(string)($payload['reporting_method']??'simpler_bas');$basis=(string)($payload['accounting_basis']??'accrual');$this->policy->assertPrepareAllowed($method,$basis,$start,$end);$companyId=$this->companyContext->companyId($userId);
        return $this->db->transaction(function()use($userId,$companyId,$periodKey,$start,$end,$method,$basis,$operationId,$command,$supersedes,$supersessionReason){
            $existing=$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('operation_id',$operationId)->lockForUpdate()->first();if($existing)return $this->resultWithDetail((array)$existing);
            if($supersedes!==null){$old=$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('public_id',$supersedes)->lockForUpdate()->first();if(!$old||(string)$old->status!=='finalized')throw new InvalidArgumentException('GST supersession requires a finalized prior snapshot.');if((string)$old->period_key!==$periodKey)throw new InvalidArgumentException('GST supersession period key mismatch.');}
            $calc=$this->calculateCompanyPeriod($companyId,$start,$end,$method);$version=(int)$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('period_key',$periodKey)->max('version')+1;$row=$this->row($userId,$companyId,$periodKey,$version,$start,$end,$method,$basis,$calc,$operationId,$command,$supersedes,$supersessionReason);$this->db->table('titan_ledger_gst_tax_snapshots')->insert($row);$this->insertDetail($companyId,(string)$row['public_id'],$calc);return $this->resultWithDetail($row);
        });
    }

    public function finalize(int $userId,string $snapshotPublicId,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);return $this->db->transaction(function()use($userId,$companyId,$snapshotPublicId,$operationId){$row=$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->lockForUpdate()->first();if(!$row)throw new InvalidArgumentException('GST snapshot not found.');if((string)$row->finalize_operation_id===$operationId&&$row->status==='finalized')return $this->resultWithDetail((array)$row);$current=$this->calculateCompanyPeriod($companyId,(string)$row->period_start,(string)$row->period_end,(string)$row->reporting_method);$this->policy->assertFinalizeAllowed((array)$row,(string)$row->source_fingerprint,(string)$current['source_fingerprint']);$actor=$this->companyContext->actorUserId($userId);$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->update(['status'=>'finalized','finalized_by_user_id'=>$actor,'finalized_at'=>now(),'finalize_operation_id'=>$operationId,'updated_at'=>now()]);$fresh=(array)$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->first();return $this->resultWithDetail($fresh);});
    }

    public function supersede(int $userId,string $snapshotPublicId,array $payload,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$old=$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->first();if(!$old||(string)$old->status!=='finalized')throw new InvalidArgumentException('Only a finalized GST snapshot can be superseded.');$reason=trim((string)($payload['reason_code']??''));if($reason===''||strlen($reason)>80)throw new InvalidArgumentException('GST supersession requires a bounded reason_code.');$replacement=['period_start'=>(string)$old->period_start,'period_end'=>(string)$old->period_end,'reporting_method'=>(string)$old->reporting_method,'accounting_basis'=>(string)$old->accounting_basis];return $this->prepare($userId,(string)$old->period_key,$replacement,$operationId,$command,$snapshotPublicId,$reason);
    }

    public function amend(int $userId,string $snapshotPublicId,array $payload,string $operationId,array $command): array
    {
        $payload['reason_code']=$payload['reason_code']??$payload['amendment_reason_code']??null;return $this->supersede($userId,$snapshotPublicId,$payload,$operationId,$command);
    }

    public function all(int $userId,int $limit=200): array{$companyId=$this->companyContext->companyId($userId);return $this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->orderByDesc('period_end')->orderByDesc('version')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>$this->resultWithDetail((array)$r))->all();}

    private function calculateCompanyPeriod(int $companyId,string $start,string $end,string $reportingMethod='simpler_bas'): array
    {
        $invoices=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->whereDate('issued_at','>=',$start)->whereDate('issued_at','<=',$end)->orderBy('id')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();
        $spend=$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->whereDate('occurred_at','>=',$start)->whereDate('occurred_at','<=',$end)->orderBy('id')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();
        $base=GstBasCalculator::calculate($invoices,$spend);return GstAdjustmentCalculator::apply($base,$this->adjustments->forPeriod($companyId,$start,$end),$reportingMethod);
    }

    private function row(int $userId,int $companyId,string $periodKey,int $version,string $start,string $end,string $method,string $basis,array $calc,string $op,array $command,?string $supersedes,?string $supersessionReason): array
    {
        $hashPayload=['period_key'=>$periodKey,'version'=>$version,'period_start'=>$start,'period_end'=>$end,'reporting_method'=>$method,'accounting_basis'=>$basis,'g1'=>$calc['g1_total_sales_minor'],'g2'=>$calc['g2_export_sales_minor'],'g3'=>$calc['g3_gst_free_sales_minor'],'g10'=>$calc['g10_capital_purchases_minor'],'g11'=>$calc['g11_noncapital_purchases_minor'],'1a'=>$calc['one_a_gst_on_sales_minor'],'1b'=>$calc['one_b_gst_on_purchases_minor'],'purchases'=>$calc['total_purchases_minor'],'net'=>$calc['net_gst_payable_minor'],'source_fingerprint'=>$calc['source_fingerprint'],'supersedes'=>$supersedes];$snapshotHash=hash('sha256',json_encode($hashPayload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        return ['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'period_key'=>$periodKey,'version'=>$version,'period_start'=>$start,'period_end'=>$end,'reporting_method'=>$method,'accounting_basis'=>$basis,'currency'=>'AUD','status'=>'prepared','g1_total_sales_minor'=>$calc['g1_total_sales_minor'],'one_a_gst_on_sales_minor'=>$calc['one_a_gst_on_sales_minor'],'one_b_gst_on_purchases_minor'=>$calc['one_b_gst_on_purchases_minor'],'total_purchases_minor'=>$calc['total_purchases_minor'],'net_gst_payable_minor'=>$calc['net_gst_payable_minor'],'invoice_source_count'=>$calc['invoice_source_count'],'spend_source_count'=>$calc['spend_source_count'],'source_fingerprint'=>$calc['source_fingerprint'],'snapshot_hash'=>$snapshotHash,'lodgement_ready'=>$calc['lodgement_ready'],'review_reasons'=>json_encode($calc['review_reasons']),'supersedes_public_id'=>$supersedes,'supersession_reason_code'=>$supersessionReason,'operation_id'=>$op,'finalize_operation_id'=>null,'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'prepared_by_user_id'=>$this->companyContext->actorUserId($userId),'finalized_by_user_id'=>null,'prepared_at'=>now(),'finalized_at'=>null,'created_at'=>now(),'updated_at'=>now()];
    }

    private function insertDetail(int $companyId,string $snapshot,array $calc): void
    {
        $detail=['company_id'=>$companyId,'snapshot_public_id'=>$snapshot,'g2_export_sales_minor'=>$calc['g2_export_sales_minor'],'g3_gst_free_sales_minor'=>$calc['g3_gst_free_sales_minor'],'g10_capital_purchases_minor'=>$calc['g10_capital_purchases_minor'],'g11_noncapital_purchases_minor'=>$calc['g11_noncapital_purchases_minor'],'approved_adjustment_count'=>$calc['approved_adjustment_count'],'pending_adjustment_count'=>$calc['pending_adjustment_count'],'rejected_adjustment_count'=>$calc['rejected_adjustment_count'],'accountant_review_complete'=>$calc['accountant_review_complete'],'adjustment_source_fingerprint'=>$calc['adjustment_source_fingerprint'],'evidence_hash'=>hash('sha256',json_encode([$snapshot,$calc['source_fingerprint'],$calc['g2_export_sales_minor'],$calc['g3_gst_free_sales_minor'],$calc['g10_capital_purchases_minor'],$calc['g11_noncapital_purchases_minor'],$calc['approved_adjustment_count'],$calc['pending_adjustment_count']],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'created_at'=>now()];$this->db->table('titan_ledger_gst_snapshot_details')->insert($detail);
    }

    private function resultWithDetail(array $row): array
    {
        $out=$this->result($row);$companyId=(int)($row['company_id']??0);$public=(string)($row['public_id']??'');if($companyId>0&&$public!==''){$d=$this->db->table('titan_ledger_gst_snapshot_details')->where('company_id',$companyId)->where('snapshot_public_id',$public)->first();if($d)$out+=array_intersect_key((array)$d,array_flip(['g2_export_sales_minor','g3_gst_free_sales_minor','g10_capital_purchases_minor','g11_noncapital_purchases_minor','approved_adjustment_count','pending_adjustment_count','rejected_adjustment_count','accountant_review_complete','adjustment_source_fingerprint','evidence_hash']));}return $out;
    }

    private function periodKey(string $key): string{$key=trim($key);if(!preg_match('/^[A-Za-z0-9._:-]{1,80}$/',$key))throw new InvalidArgumentException('GST period key is invalid.');return $key;}
    private function result(array $row): array{$out=array_intersect_key($row,array_flip(['public_id','period_key','version','period_start','period_end','reporting_method','accounting_basis','currency','status','g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','total_purchases_minor','net_gst_payable_minor','invoice_source_count','spend_source_count','source_fingerprint','snapshot_hash','lodgement_ready','review_reasons','supersedes_public_id','supersession_reason_code','prepared_at','finalized_at']));if(isset($out['review_reasons'])&&is_string($out['review_reasons']))$out['review_reasons']=json_decode($out['review_reasons'],true)?:[];return $out;}
}
