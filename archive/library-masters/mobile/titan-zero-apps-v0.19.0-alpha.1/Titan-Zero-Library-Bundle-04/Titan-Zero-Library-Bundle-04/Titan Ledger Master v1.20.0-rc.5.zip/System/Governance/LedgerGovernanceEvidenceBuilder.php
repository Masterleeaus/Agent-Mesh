<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

final class LedgerGovernanceEvidenceBuilder
{
    /** @param array<string,mixed> $command */
    public static function build(array $command): array
    {
        $payload=is_array($command['payload']??null)?$command['payload']:[];
        $lines=is_array($payload['lines']??null)?$payload['lines']:[];
        $name=(string)($command['command_name']??'');
        return array_filter([
            'contract'=>'titan-ledger.governance-evidence.v1',
            'company_id'=>(int)($command['company_id']??0),
            'actor_user_id'=>(int)($command['actor_user_id']??0),
            'command_id'=>(string)($command['command_id']??''),
            'command_name'=>$name,
            'command_version'=>(int)($command['command_version']??1),
            'caller_extension'=>(string)($command['caller_extension']??''),
            'target_public_id'=>$command['target_public_id']??null,
            'governance_reference'=>$command['governance_reference']??null,
            'trace_id'=>$command['trace_id']??null,
            'correlation_id'=>$command['correlation_id']??null,
            'causation_id'=>$command['causation_id']??null,
            'facts'=>[
                'line_count'=>count($lines),
                'has_target'=>!empty($command['target_public_id']),
                'has_operation_id'=>isset($payload['operation_id']) && trim((string)$payload['operation_id'])!=='',
                'requested_lock_state'=>isset($payload['lock_state'])?substr((string)$payload['lock_state'],0,30):null,
                'financial_total_minor'=>(str_starts_with($name,'ledger.crm.') && isset($payload['total_minor']))?(int)$payload['total_minor']:((str_starts_with($name,'ledger.payment.') && isset($payload['gross_amount_minor']))?(int)$payload['gross_amount_minor']:((str_starts_with($name,'ledger.payment.') && isset($payload['refund_amount_minor']))?(int)$payload['refund_amount_minor']:(((str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.')) && isset($payload['total_minor']))?(int)$payload['total_minor']:(((str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.')) && isset($payload['amount_minor']))?(int)$payload['amount_minor']:null)))),
                'financial_tax_minor'=>(str_starts_with($name,'ledger.crm.') && isset($payload['tax_minor']))?(int)$payload['tax_minor']:(((str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.'))&&isset($payload['gst_minor']))?(int)$payload['gst_minor']:null),
                'currency'=>(str_starts_with($name,'ledger.crm.') || str_starts_with($name,'ledger.payment.') || str_starts_with($name,'ledger.payable.') || str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.')) && isset($payload['currency'])?substr((string)$payload['currency'],0,3):null,
                'revenue_split_count'=>str_starts_with($name,'ledger.crm.') && is_array($payload['revenue_splits']??null)?count($payload['revenue_splits']):null,
                'payment_rail'=>str_starts_with($name,'ledger.payment.') && isset($payload['rail'])?substr((string)$payload['rail'],0,30):null,
                'payment_fee_minor'=>(str_starts_with($name,'ledger.payment.')||str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.'))?(int)($payload['fee_minor']??$payload['refund_fee_minor']??0):null,
                'spend_account_split_count'=>(str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.'))&&is_array($payload['account_splits']??null)?count($payload['account_splits']):null,
                'spend_rail'=>(str_starts_with($name,'ledger.payable.')||str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.'))&&isset($payload['rail'])?substr((string)$payload['rail'],0,30):null,
                'bank_statement_transaction_count'=>$name==='ledger.bank.statement.import'&&is_array($payload['transactions']??null)?count($payload['transactions']):null,
                'bank_statement_movement_minor'=>$name==='ledger.bank.statement.import'&&isset($payload['movement_minor'])?(int)$payload['movement_minor']:null,
                'bank_reconciliation_candidate'=>$name==='ledger.bank.reconciliation.match'&&isset($payload['candidate_public_id'])?'present':null,
                'bank_reconciliation_group_bank_count'=>$name==='ledger.bank.reconciliation.group_match'&&is_array($payload['bank_transaction_public_ids']??null)?count($payload['bank_transaction_public_ids']):null,
                'bank_reconciliation_group_candidate_count'=>$name==='ledger.bank.reconciliation.group_match'&&is_array($payload['candidate_public_ids']??null)?count($payload['candidate_public_ids']):null,
                'bank_reconciliation_adjustment_type'=>$name==='ledger.bank.reconciliation.adjustment.post'&&isset($payload['adjustment_type'])?substr((string)$payload['adjustment_type'],0,30):null,
                'banking_amount_minor'=>str_starts_with($name,'ledger.banking.')&&isset($payload['amount_minor'])?(int)$payload['amount_minor']:null,
                'banking_fee_minor'=>str_starts_with($name,'ledger.banking.')&&isset($payload['fee_minor'])?(int)$payload['fee_minor']:null,
                'banking_currency'=>str_starts_with($name,'ledger.banking.')&&isset($payload['currency'])?substr(strtoupper((string)$payload['currency']),0,3):null,
                'tax_period_start'=>str_starts_with($name,'ledger.tax.gst_')&&isset($payload['period_start'])?substr((string)$payload['period_start'],0,10):null,
                'tax_period_end'=>str_starts_with($name,'ledger.tax.gst_')&&isset($payload['period_end'])?substr((string)$payload['period_end'],0,10):null,
                'tax_reporting_method'=>str_starts_with($name,'ledger.tax.gst_')&&isset($payload['reporting_method'])?substr((string)$payload['reporting_method'],0,30):null,
                'forecast_snapshot_type'=>str_starts_with($name,'ledger.forecast.snapshot.')&&isset($payload['snapshot_type'])?substr((string)$payload['snapshot_type'],0,40):null,
                'forecast_horizon_days'=>str_starts_with($name,'ledger.forecast.snapshot.')&&isset($payload['horizon_days'])?(int)$payload['horizon_days']:null,
                'forecast_currency'=>str_starts_with($name,'ledger.forecast.snapshot.')&&isset($payload['currency'])?substr(strtoupper((string)$payload['currency']),0,3):null,
                'collection_state'=>str_starts_with($name,'ledger.receivable.')&&isset($payload['collection_state'])?substr((string)$payload['collection_state'],0,30):null,
                'follow_up_channel'=>$name==='ledger.receivable.follow_up.record'&&isset($payload['channel'])?substr((string)$payload['channel'],0,20):null,
                'follow_up_outcome'=>$name==='ledger.receivable.follow_up.record'&&isset($payload['outcome'])?substr((string)$payload['outcome'],0,30):null,
            ],
            'controls'=>[
                'tenant_boundary'=>'company_id',
                'command_bus_only'=>true,
                'double_entry'=>str_starts_with($name,'ledger.journal.') || str_starts_with($name,'ledger.crm.') || str_starts_with($name,'ledger.payment.') || str_starts_with($name,'ledger.payable.') || str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.') || $name==='ledger.bank.reconciliation.adjustment.post',
                'period_lock'=>in_array($name,['ledger.journal.post','ledger.journal.reverse','ledger.financial_year.close.prepare','ledger.financial_year.close','ledger.financial_year.reopen','ledger.accounting_period.transition','ledger.crm.invoice.post','ledger.crm.credit_note.post','ledger.payment.settlement.post','ledger.payment.refund.post','ledger.payable.bill.post','ledger.payable.credit_note.post','ledger.payable.payment.post','ledger.spend.actual.post','ledger.banking.transfer.post','ledger.banking.clearing.settle','ledger.banking.credit_card.payment.post','ledger.bank.reconciliation.adjustment.post'],true),
                'immutable_posting'=>str_starts_with($name,'ledger.journal.') || str_starts_with($name,'ledger.crm.') || str_starts_with($name,'ledger.payment.') || str_starts_with($name,'ledger.payable.') || str_starts_with($name,'ledger.spend.') || str_starts_with($name,'ledger.banking.') || $name==='ledger.bank.reconciliation.adjustment.post',
                'bank_statement_import_is_evidence_only'=>str_starts_with($name,'ledger.bank.')?true:null,
                'tax_snapshot_is_evidence_only'=>str_starts_with($name,'ledger.tax.gst_')?true:null,
                'ato_lodgement_authority'=>str_starts_with($name,'ledger.tax.gst_')?false:null,
                'forecast_accounting_mutation_authority'=>str_starts_with($name,'ledger.forecast.snapshot.')?false:null,
                'forecast_confidence_semantics'=>str_starts_with($name,'ledger.forecast.snapshot.')?'evidence_coverage_only':null,
                'authoritative_writer'=>'titan-ledger',
            ],
        ], static fn($v)=>$v!==null);
    }
}
