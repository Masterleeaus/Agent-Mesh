<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Crm;

use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableProjectionService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class CrmInvoiceAccountingService
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private ChartOfAccountsService $accounts,
        private JournalService $journals,
        private ReceivableProjectionService $receivables,
    ) {}

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function postInvoice(int $userId, string $targetPublicId, array $payload, string $operationId, array $command): array
    {
        $fact=CrmInvoiceFact::issued($payload);
        $this->assertTarget($targetPublicId,$fact);
        return $this->post($userId,$fact,$operationId,$command,null);
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function postCreditNote(int $userId, string $targetPublicId, array $payload, string $operationId, array $command): array
    {
        $fact=CrmInvoiceFact::creditNote($payload);
        $this->assertTarget($targetPublicId,$fact);
        $companyId=$this->companyContext->companyId($userId);
        $original=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','invoice')->where('document_public_id',$fact['invoice_public_id'])->first();
        if(!$original) throw new InvalidArgumentException('CRM credit note cannot post before its original invoice is posted to Titan Ledger.');
        if((string)$original->currency !== (string)$fact['currency']) throw new InvalidArgumentException('CRM credit note currency must match its original invoice.');
        return $this->post($userId,$fact,$operationId,$command,(string)$original->journal_public_id);
    }

    public function all(int $userId, int $limit=200): array
    {
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->orderByDesc('issued_at')->orderByDesc('id')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>(array)$r)->all();
    }

    /** @param array<string,mixed> $fact @param array<string,mixed> $command */
    private function post(int $userId, array $fact, string $operationId, array $command, ?string $correctionOf): array
    {
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->transaction(function() use($userId,$companyId,$fact,$operationId,$command,$correctionOf): array {
            $existing=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type',$fact['document_type'])->where('document_public_id',$fact['document_public_id'])->lockForUpdate()->first();
            $factHash=CrmInvoiceFact::hash($fact);
            if($existing){
                if(!hash_equals((string)$existing->fact_hash,$factHash)) throw new InvalidArgumentException('CRM document fact changed after Ledger posting; submit a credit/correction instead.');
                if(!hash_equals((string)$existing->posting_operation_id,$operationId)) throw new InvalidArgumentException('CRM document fact is already posted under a different governed operation.');
                return $this->result((array)$existing);
            }

            $accountIds=$this->accountIds($userId,$fact);
            $lines=$fact['document_type']==='invoice' ? CrmInvoiceJournalMapper::issuedLines($fact,$accountIds) : CrmInvoiceJournalMapper::creditNoteLines($fact,$accountIds);
            $journal=$this->journals->postAuthoritativeSourceJournal(
                $userId,
                $fact['document_type']==='invoice'?'invoice':'credit_note',
                [
                    'entry_date'=>$fact['entry_date'],
                    'currency'=>$fact['currency'],
                    'source_extension'=>'titan-crm',
                    'source_type'=>$fact['document_type']==='invoice'?'crm.invoice.issued':'crm.credit_note.issued',
                    'source_public_id'=>$fact['document_public_id'],
                    'source_event_id'=>$fact['source_event_id'],
                    'source_operation_id'=>$operationId,
                    'trace_id'=>$command['trace_id']??null,
                    'correlation_id'=>$command['correlation_id']??null,
                    'causation_id'=>$command['causation_id']??null,
                    'metadata'=>['source_version'=>$fact['source_version'],'invoice_public_id'=>$fact['invoice_public_id']],
                ],
                $lines,
                $operationId,
                $correctionOf,
            );

            $row=[
                'public_id'=>(string)Str::ulid(), 'company_id'=>$companyId,
                'document_type'=>$fact['document_type'],'document_public_id'=>$fact['document_public_id'],'invoice_public_id'=>$fact['invoice_public_id'],'invoice_number'=>$fact['invoice_number']??null,
                'source_event_id'=>$fact['source_event_id'],'source_version'=>$fact['source_version'],'fact_hash'=>$factHash,
                'currency'=>$fact['currency'],'subtotal_minor'=>$fact['subtotal_minor'],'tax_minor'=>$fact['tax_minor'],'total_minor'=>$fact['total_minor'],
                'issued_at'=>$fact['issued_at'],'due_at'=>$fact['due_at']??null,'journal_public_id'=>$journal['public_id'],'posting_operation_id'=>$operationId,
                'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now(),
            ];
            $this->db->table('titan_ledger_crm_invoice_postings')->insert($row);
            $this->receivables->refresh($companyId,(string)$fact['invoice_public_id']);
            return $this->result($row);
        });
    }

    /** @param array<string,mixed> $fact @return array<string,string> */
    private function accountIds(int $userId, array $fact): array
    {
        $keys=['accounts_receivable','gst_payable'];
        foreach($fact['revenue_splits'] as $split) $keys[]=(string)$split['system_key'];
        $ids=[];
        foreach(array_values(array_unique($keys)) as $key){
            $account=$this->accounts->findSystemAccount($userId,$key);
            if(!$account || empty($account['public_id'])) throw new InvalidArgumentException('Required Ledger system account unavailable: '.$key.'.');
            $ids[$key]=(string)$account['public_id'];
        }
        return $ids;
    }

    /** @param array<string,mixed> $fact */
    private function assertTarget(string $target, array $fact): void
    {
        if(trim($target)==='' || !hash_equals((string)$fact['document_public_id'],trim($target))) throw new InvalidArgumentException('CRM invoice command target does not match document_public_id.');
    }

    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function result(array $row): array
    {
        return array_intersect_key($row,array_flip(['public_id','document_type','document_public_id','invoice_public_id','invoice_number','journal_public_id','currency','subtotal_minor','tax_minor','total_minor','issued_at','due_at','source_event_id']));
    }
}
