<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Bookkeeping;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class BookkeepingCategoryService
{
    private const DEFAULTS = [
        'income' => ['Sales','Service Income','Product Income','Booking/Hire Income','Other Income'],
        'expense' => ['Advertising & Marketing','Bank & Merchant Fees','Cleaning & Supplies','Contractors','Equipment & Tools','Fuel & Vehicle','Insurance','Office Expenses','Rent','Repairs & Maintenance','Software & Subscriptions','Telephone & Internet','Travel','Utilities','Wages & Staff Costs','Other Expenses'],
    ];

    public function __construct(private ConnectionInterface $db, private LedgerCompanyContext $companyContext) {}

    public function ensureDefaults(int $userId): void
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        foreach (self::DEFAULTS as $type => $names) {
            foreach ($names as $position => $name) {
                $slug = Str::slug($name);
                $exists = $this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('type',$type)->where('slug',$slug)->exists();
                if ($exists) continue;
                $this->db->table('crm_bookkeeping_categories')->insert([
                    'public_id'=>(string) Str::ulid(), 'company_id'=>$companyId, 'type'=>$type, 'name'=>$name, 'slug'=>$slug,
                    'is_system_default'=>true, 'is_active'=>true, 'sort_order'=>$position + 1, 'created_by_user_id'=>$actor,
                    'created_at'=>now(), 'updated_at'=>now(),
                ]);
            }
        }
    }

    public function all(int $userId, ?string $type = null, bool $activeOnly = true): array
    {
        $this->ensureDefaults($userId);
        $q=$this->db->table('crm_bookkeeping_categories')->where('company_id',$this->companyContext->companyId($userId));
        if ($type !== null) $q->where('type',$this->type($type));
        if ($activeOnly) $q->where('is_active',true);
        return $q->orderBy('type')->orderBy('sort_order')->orderBy('name')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();
    }

    public function create(int $userId, array $data): array
    {
        $companyId=$this->companyContext->companyId($userId); $type=$this->type((string)($data['type']??''));
        $name=trim((string)($data['name']??'')); if($name==='')throw new InvalidArgumentException('Bookkeeping category name is required.');
        $slug=Str::slug((string)($data['slug']??$name)); if($slug==='')throw new InvalidArgumentException('Bookkeeping category slug is required.');
        if($this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('type',$type)->where('slug',$slug)->exists())throw new InvalidArgumentException('Bookkeeping category already exists.');
        $publicId=(string)Str::ulid();
        $this->db->table('crm_bookkeeping_categories')->insert([
            'public_id'=>$publicId,'company_id'=>$companyId,'type'=>$type,'name'=>$name,'slug'=>$slug,'description'=>$data['description']??null,
            'is_system_default'=>false,'is_active'=>(bool)($data['is_active']??true),'sort_order'=>(int)($data['sort_order']??100),
            'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('public_id',$publicId)->first();
    }

    public function update(int $userId,string $publicId,array $data): array
    {
        $companyId=$this->companyContext->companyId($userId); $row=$this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('public_id',$publicId)->first();
        if(!$row)throw new InvalidArgumentException('Bookkeeping category not found.');
        $updates=['updated_at'=>now()];
        foreach(['name','description'] as $f)if(array_key_exists($f,$data))$updates[$f]=$data[$f];
        if(array_key_exists('is_active',$data))$updates['is_active']=(bool)$data['is_active'];
        if(array_key_exists('sort_order',$data))$updates['sort_order']=(int)$data['sort_order'];
        $this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('public_id',$publicId)->update($updates);
        return (array)$this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('public_id',$publicId)->first();
    }

    private function type(string $type): string
    {
        if(!in_array($type,['income','expense'],true))throw new InvalidArgumentException('Bookkeeping category type must be income or expense.');
        return $type;
    }
}
