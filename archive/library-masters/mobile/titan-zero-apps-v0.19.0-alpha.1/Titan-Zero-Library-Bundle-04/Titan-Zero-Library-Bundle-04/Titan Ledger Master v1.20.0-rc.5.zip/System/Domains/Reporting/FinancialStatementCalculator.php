<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reporting;

final class FinancialStatementCalculator
{
    /** @param array<int,array<string,mixed>> $rows */
    public function trialBalance(array $rows): array
    {
        $totalDebit = 0;
        $totalCredit = 0;
        $accounts = [];
        foreach ($rows as $row) {
            $debit = (int) ($row['debit_minor'] ?? 0);
            $credit = (int) ($row['credit_minor'] ?? 0);
            $totalDebit += $debit;
            $totalCredit += $credit;
            $net = $debit - $credit;
            $accounts[] = [
                'public_id' => (string) ($row['public_id'] ?? ''),
                'code' => (string) ($row['code'] ?? ''),
                'name' => (string) ($row['name'] ?? ''),
                'type' => (string) ($row['type'] ?? ''),
                'normal_balance' => (string) ($row['normal_balance'] ?? ''),
                'debit_minor' => $debit,
                'credit_minor' => $credit,
                'net_debit_minor' => $net,
                'balance_debit_minor' => max(0, $net),
                'balance_credit_minor' => max(0, -$net),
            ];
        }
        $difference = $totalDebit - $totalCredit;
        return [
            'accounts' => $accounts,
            'total_debit_minor' => $totalDebit,
            'total_credit_minor' => $totalCredit,
            'difference_minor' => $difference,
            'balanced' => $difference === 0,
        ];
    }

    /** @param array<int,array<string,mixed>> $rows */
    public function profitAndLoss(array $rows): array
    {
        $sections = [
            'revenue' => 0,
            'other_income' => 0,
            'cost_of_sales' => 0,
            'expense' => 0,
            'other_expense' => 0,
        ];
        $accounts = [];
        foreach ($rows as $row) {
            $type = (string) ($row['type'] ?? '');
            if (!array_key_exists($type, $sections)) continue;
            $debit = (int) ($row['debit_minor'] ?? 0);
            $credit = (int) ($row['credit_minor'] ?? 0);
            $amount = in_array($type, ['revenue','other_income'], true) ? $credit - $debit : $debit - $credit;
            $sections[$type] += $amount;
            $accounts[] = [
                'public_id' => (string) ($row['public_id'] ?? ''),
                'code' => (string) ($row['code'] ?? ''),
                'name' => (string) ($row['name'] ?? ''),
                'type' => $type,
                'amount_minor' => $amount,
            ];
        }
        $income = $sections['revenue'] + $sections['other_income'];
        $expenses = $sections['cost_of_sales'] + $sections['expense'] + $sections['other_expense'];
        return [
            'accounts' => $accounts,
            'revenue_minor' => $sections['revenue'],
            'other_income_minor' => $sections['other_income'],
            'total_income_minor' => $income,
            'cost_of_sales_minor' => $sections['cost_of_sales'],
            'gross_profit_minor' => $income - $sections['cost_of_sales'],
            'operating_expenses_minor' => $sections['expense'],
            'other_expenses_minor' => $sections['other_expense'],
            'total_expenses_minor' => $expenses,
            'net_profit_minor' => $income - $expenses,
        ];
    }

    /** @param array<int,array<string,mixed>> $rows */
    public function balanceSheet(array $rows): array
    {
        $assets = 0;
        $liabilities = 0;
        $equity = 0;
        $statementAccounts = [];
        foreach ($rows as $row) {
            $type = (string) ($row['type'] ?? '');
            $debit = (int) ($row['debit_minor'] ?? 0);
            $credit = (int) ($row['credit_minor'] ?? 0);
            $amount = null;
            if ($type === 'asset') { $amount = $debit - $credit; $assets += $amount; }
            elseif ($type === 'liability') { $amount = $credit - $debit; $liabilities += $amount; }
            elseif ($type === 'equity') { $amount = $credit - $debit; $equity += $amount; }
            if ($amount !== null) {
                $statementAccounts[] = [
                    'public_id' => (string) ($row['public_id'] ?? ''),
                    'code' => (string) ($row['code'] ?? ''),
                    'name' => (string) ($row['name'] ?? ''),
                    'type' => $type,
                    'amount_minor' => $amount,
                ];
            }
        }
        $unclosed = $this->profitAndLoss($rows)['net_profit_minor'];
        $right = $liabilities + $equity + $unclosed;
        $difference = $assets - $right;
        return [
            'accounts' => $statementAccounts,
            'assets_minor' => $assets,
            'liabilities_minor' => $liabilities,
            'equity_accounts_minor' => $equity,
            'unclosed_earnings_minor' => $unclosed,
            'liabilities_and_equity_minor' => $right,
            'difference_minor' => $difference,
            'balanced' => $difference === 0,
        ];
    }

    public function retainedEarningsRollForward(int $openingRetainedEarningsMinor, int $retainedEarningsMovementsMinor, int $currentPeriodProfitMinor): array
    {
        $accountClosing = $openingRetainedEarningsMinor + $retainedEarningsMovementsMinor;
        return [
            'opening_retained_earnings_minor' => $openingRetainedEarningsMinor,
            'retained_earnings_account_movement_minor' => $retainedEarningsMovementsMinor,
            'retained_earnings_account_closing_minor' => $accountClosing,
            'current_period_profit_minor' => $currentPeriodProfitMinor,
            'closing_equity_after_current_profit_minor' => $accountClosing + $currentPeriodProfitMinor,
        ];
    }
}
