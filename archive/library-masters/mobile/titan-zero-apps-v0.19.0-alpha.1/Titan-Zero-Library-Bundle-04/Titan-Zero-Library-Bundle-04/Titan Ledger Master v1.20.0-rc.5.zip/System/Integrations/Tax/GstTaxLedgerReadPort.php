<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Integrations\Tax;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxLedgerService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxAdjustmentService;
final class GstTaxLedgerReadPort
{
    public function __construct(private GstTaxLedgerService $ledger,private GstTaxAdjustmentService $adjustments){}
    public function preview(int $actorUserId,string $periodStart,string $periodEnd,string $reportingMethod='simpler_bas',string $accountingBasis='accrual'): array{return $this->ledger->preview($actorUserId,$periodStart,$periodEnd,$reportingMethod,$accountingBasis);}
    public function snapshots(int $actorUserId,int $limit=200): array{return $this->ledger->all($actorUserId,$limit);}
    public function adjustments(int $actorUserId,int $limit=500): array{return $this->adjustments->all($actorUserId,$limit);}
}
