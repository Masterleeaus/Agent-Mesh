<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integration\TitanApps;

/**
 * Provider-owned semantic contributions for the public Titan Apps boundary.
 *
 * This adapter intentionally contains no Interface Runtime, Interaction Engine or Builder
 * implementation and grants no execution authority. Actions remain capability intents.
 */
final class TitanAppsContributionProvider
{
    public const OWNER_EXTENSION = 'titan-ledger';
    public const REGISTRY_KEY = 'titan-apps.interface-contributions.' . self::OWNER_EXTENSION;

    /** @return array<int,array<string,mixed>> */
    public function contributions(): array
    {
        return [['contribution_id' => 'ledger.summary', 'owner_extension' => 'titan-ledger', 'supported_surfaces' => ['zero'], 'variants' => ['LedgerSummary'], 'projection_ids' => ['ledger.summary.read'], 'action_ids' => [], 'capability_ids' => ['ledger.summary.read'], 'permissions' => ['ledger.summary.read'], 'sensitivity' => 'restricted_financial', 'risk_classification' => 'read_only', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability'], ['contribution_id' => 'ledger.close-status', 'owner_extension' => 'titan-ledger', 'supported_surfaces' => ['zero'], 'variants' => ['FinancialCloseStatus'], 'projection_ids' => ['ledger.close.status.read'], 'action_ids' => ['ledger.close.finalize'], 'capability_ids' => ['ledger.close.status.read', 'ledger.close.finalize'], 'permissions' => ['ledger.close.status.read', 'ledger.close.finalize'], 'sensitivity' => 'restricted_financial', 'risk_classification' => 'governed', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability']];
    }

    /** @return array<string,mixed> */
    public function contractDescriptor(): array
    {
        return [
            'owner_extension' => self::OWNER_EXTENSION,
            'supported_surfaces' => $this->supportedSurfaces(),
            'canonical_app_boundary' => ['zero', 'go', 'hub'],
            'canonical_surfaces_only' => true,
            'interface_runtime' => 'public_contract_only',
            'interaction_engine' => 'public_contract_only',
            'builder' => 'contribution_registration_only',
            'package_location_independent' => true,
            'authority' => 'none',
        ];
    }
    /** @return array<int,string> */
    private function supportedSurfaces(): array
    {
        $surfaces = [];
        foreach ($this->contributions() as $contribution) {
            foreach (($contribution['supported_surfaces'] ?? []) as $surface) {
                if (is_string($surface) && ! in_array($surface, $surfaces, true)) {
                    $surfaces[] = $surface;
                }
            }
        }

        return $surfaces;
    }

}
