<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Banking;

use InvalidArgumentException;

final class MultiAccountBankingJournalMapper
{
    /** @return array<int,array<string,mixed>> */
    public static function internalTransfer(string $source,string $destination,string $feeAccount,int $amountMinor,int $feeMinor): array
    {
        self::positive($amountMinor,'Transfer amount');self::nonNegative($feeMinor,'Transfer fee');self::different($source,$destination);
        $lines=[self::line($destination,'Internal transfer received',$amountMinor,0)];
        if($feeMinor>0)$lines[]=self::line($feeAccount,'Internal transfer fee',$feeMinor,0,'gst_free');
        $lines[]=self::line($source,'Internal transfer sent',0,$amountMinor+$feeMinor);
        return $lines;
    }

    /** @return array<int,array<string,mixed>> */
    public static function clearingSettlement(string $clearing,string $bank,int $amountMinor): array
    {
        self::positive($amountMinor,'Clearing settlement amount');self::different($clearing,$bank);
        return [self::line($bank,'Merchant clearing payout',$amountMinor,0),self::line($clearing,'Merchant clearing released',0,$amountMinor)];
    }

    /** @return array<int,array<string,mixed>> */
    public static function creditCardPayment(string $bank,string $card,int $amountMinor,int $feeMinor,string $feeAccount): array
    {
        self::positive($amountMinor,'Credit card payment amount');self::nonNegative($feeMinor,'Credit card payment fee');self::different($bank,$card);
        $lines=[self::line($card,'Credit card liability payment',$amountMinor,0)];
        if($feeMinor>0)$lines[]=self::line($feeAccount,'Credit card payment fee',$feeMinor,0,'gst_free');
        $lines[]=self::line($bank,'Credit card payment cash out',0,$amountMinor+$feeMinor);
        return $lines;
    }

    private static function different(string $a,string $b): void{if(trim($a)===''||trim($b)===''||hash_equals(trim($a),trim($b)))throw new InvalidArgumentException('Banking movement requires distinct source and destination accounts.');}
    private static function positive(int $v,string $label): void{if($v<1)throw new InvalidArgumentException($label.' must be positive.');}
    private static function nonNegative(int $v,string $label): void{if($v<0)throw new InvalidArgumentException($label.' must not be negative.');}
    /** @return array<string,mixed> */
    private static function line(string $account,string $description,int $debit,int $credit,string $tax='bas_excluded'): array{return ['account_public_id'=>$account,'description'=>$description,'debit_minor'=>$debit,'credit_minor'=>$credit,'tax_code'=>$tax,'tax_amount_minor'=>0,'metadata'=>null];}
}
