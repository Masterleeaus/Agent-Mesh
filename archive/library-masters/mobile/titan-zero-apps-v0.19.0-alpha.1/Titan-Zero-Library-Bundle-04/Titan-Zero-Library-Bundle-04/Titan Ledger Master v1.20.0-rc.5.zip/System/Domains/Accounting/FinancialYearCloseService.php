<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class FinancialYearCloseService
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private AccountingPeriodService $periods,
        private JournalService $journals,
        private YearEndCloseCalculator $calculator,
        private FinancialYearCloseChecklist $checklist,
    ) {}

    public function preview(int $userId, string $yearPublicId): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $year = $this->year($companyId, $yearPublicId, false);
        return $this->buildPreview($companyId, (array)$year);
    }

    public function prepare(int $userId, string $yearPublicId, array $payload, string $operationId, array $command): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        return $this->db->transaction(function() use($companyId,$actor,$yearPublicId,$operationId,$command): array {
            $existing=$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('prepare_operation_id',$operationId)->lockForUpdate()->first();
            if($existing) return $this->result((array)$existing);
            $year=$this->year($companyId,$yearPublicId,true);
            $preview=$this->buildPreview($companyId,(array)$year);
            if(($preview['checklist']['ready']??false)!==true) throw new InvalidArgumentException('Financial year close checklist blocked: '.implode(',', $preview['checklist']['blocking_codes']??[]));

            $version=(int)$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('financial_year_public_id',$yearPublicId)->max('version')+1;
            $prior=$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('financial_year_public_id',$yearPublicId)->where('status','closed')->orderByDesc('version')->first();
            $publicId=(string)Str::ulid();
            $closePayload=$this->canonical([
                'schema_version'=>1,
                'financial_year_public_id'=>$yearPublicId,
                'starts_on'=>(string)$year->starts_on,
                'ends_on'=>(string)$year->ends_on,
                'currency'=>'AUD',
                'net_profit_minor'=>(int)$preview['close']['net_profit_minor'],
                'debit_total_minor'=>(int)$preview['close']['debit_total_minor'],
                'credit_total_minor'=>(int)$preview['close']['credit_total_minor'],
                'temporary_account_count'=>(int)$preview['close']['temporary_account_count'],
                'lines'=>$preview['close']['lines'],
            ]);
            $encoded=json_encode($closePayload,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
            $row=[
                'public_id'=>$publicId,'company_id'=>$companyId,'financial_year_public_id'=>$yearPublicId,'version'=>$version,'status'=>'prepared',
                'currency'=>'AUD','net_profit_minor'=>(int)$preview['close']['net_profit_minor'],'close_journal_public_id'=>null,
                'source_fingerprint'=>(string)$preview['source_fingerprint'],'checklist_json'=>json_encode($preview['checklist'],JSON_THROW_ON_ERROR),
                'close_payload_json'=>$encoded,'close_hash'=>hash('sha256',$encoded),'supersedes_public_id'=>$prior?->public_id,
                'prepare_operation_id'=>$operationId,'close_operation_id'=>null,'reopen_operation_id'=>null,
                'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                'prepared_by_user_id'=>$actor,'closed_by_user_id'=>null,'prepared_at'=>now(),'closed_at'=>null,'created_at'=>now(),'updated_at'=>now(),
            ];
            $this->db->table('titan_ledger_financial_year_closes')->insert($row);
            return $this->result($row);
        });
    }

    public function close(int $userId, string $yearPublicId, array $payload, string $operationId, array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$actor=$this->companyContext->actorUserId($userId);
        $reason=trim((string)($payload['reason']??'')); if($reason==='') throw new InvalidArgumentException('Financial year close requires a reason.');
        return $this->db->transaction(function() use($userId,$companyId,$actor,$yearPublicId,$payload,$operationId,$command,$reason): array {
            $byOp=$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('close_operation_id',$operationId)->lockForUpdate()->first();
            if($byOp) return $this->result((array)$byOp);
            $year=$this->year($companyId,$yearPublicId,true);
            if((string)$year->status!=='open') throw new InvalidArgumentException('Financial year must be open before close execution.');
            $snapshotId=trim((string)($payload['close_snapshot_public_id']??''));
            $q=$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('financial_year_public_id',$yearPublicId)->where('status','prepared');
            if($snapshotId!=='') $q->where('public_id',$snapshotId);
            $snapshot=$q->orderByDesc('version')->lockForUpdate()->first();
            if(!$snapshot) throw new InvalidArgumentException('A prepared financial-year close snapshot is required.');

            $preview=$this->buildPreview($companyId,(array)$year);
            if(($preview['checklist']['ready']??false)!==true) throw new InvalidArgumentException('Financial year close checklist is no longer ready.');
            if(!hash_equals((string)$snapshot->source_fingerprint,(string)$preview['source_fingerprint'])) throw new InvalidArgumentException('Financial year close source evidence changed after preparation. Prepare again.');
            $stored=json_decode((string)$snapshot->close_payload_json,true,512,JSON_THROW_ON_ERROR);
            $current=$this->canonical([
                'schema_version'=>1,'financial_year_public_id'=>$yearPublicId,'starts_on'=>(string)$year->starts_on,'ends_on'=>(string)$year->ends_on,'currency'=>'AUD',
                'net_profit_minor'=>(int)$preview['close']['net_profit_minor'],'debit_total_minor'=>(int)$preview['close']['debit_total_minor'],'credit_total_minor'=>(int)$preview['close']['credit_total_minor'],
                'temporary_account_count'=>(int)$preview['close']['temporary_account_count'],'lines'=>$preview['close']['lines'],
            ]);
            $currentEncoded=json_encode($current,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
            if(!hash_equals((string)$snapshot->close_hash,hash('sha256',$currentEncoded)) || $stored!==$current) throw new InvalidArgumentException('Financial year close calculation changed after preparation. Prepare again.');

            $journalPublicId=null;
            if(($current['lines']??[])!==[]) {
                $journal=$this->journals->postAuthoritativeSourceJournal($userId,'year_end_close',[
                    'entry_date'=>(string)$year->ends_on,'memo'=>'Financial year close '.(string)$year->label,'currency'=>'AUD',
                    'source_extension'=>'titan-ledger','source_type'=>'financial_year.close','source_public_id'=>$yearPublicId,'source_event_id'=>(string)$snapshot->public_id,
                    'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                    'prior_period_adjustment'=>true,'period_override_reason'=>$reason,'metadata'=>['financial_year_close_public_id'=>(string)$snapshot->public_id],
                ],$current['lines'],'financial-year-close-journal:'.(string)$snapshot->public_id);
                $journalPublicId=(string)$journal['public_id'];
            }
            $this->periods->closeFinancialYear($userId,$yearPublicId,$reason,$this->context($command,'closed'));
            $this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('public_id',(string)$snapshot->public_id)->update([
                'status'=>'closed','close_journal_public_id'=>$journalPublicId,'close_operation_id'=>$operationId,'closed_by_user_id'=>$actor,'closed_at'=>now(),'updated_at'=>now(),
            ]);
            return $this->result((array)$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('public_id',(string)$snapshot->public_id)->first());
        });
    }

    public function reopen(int $userId, string $yearPublicId, array $payload, string $operationId, array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$actor=$this->companyContext->actorUserId($userId);
        $reason=trim((string)($payload['reason']??''));if($reason==='')throw new InvalidArgumentException('Financial year reopen requires a reason.');
        return $this->db->transaction(function() use($userId,$companyId,$actor,$yearPublicId,$operationId,$command,$reason): array {
            $existing=$this->db->table('titan_ledger_financial_year_close_events')->where('company_id',$companyId)->where('operation_id',$operationId)->lockForUpdate()->first();
            if($existing) return $this->reopenResult((array)$existing);
            $year=$this->year($companyId,$yearPublicId,true);
            if((string)$year->status!=='closed') throw new InvalidArgumentException('Only a closed financial year can be reopened.');
            $close=$this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->where('financial_year_public_id',$yearPublicId)->where('status','closed')->orderByDesc('version')->lockForUpdate()->first();
            if(!$close) throw new InvalidArgumentException('Closed financial year evidence is missing.');

            $this->periods->reopenFinancialYear($userId,$yearPublicId,$reason,$this->context($command,'reopened'));
            $reopenJournalId=null;
            if($close->close_journal_public_id!==null) {
                $original=$this->journals->show($userId,(string)$close->close_journal_public_id);
                $lines=[]; foreach(($original['lines']??[]) as $line) $lines[]=[
                    'account_public_id'=>(string)$line['account_public_id'],'description'=>'Reopen prior year-end close',
                    'debit_minor'=>(int)$line['credit_minor'],'credit_minor'=>(int)$line['debit_minor'],'tax_code'=>'bas_excluded','tax_amount_minor'=>0,
                    'metadata'=>['reopens_year_end_close'=>(string)$close->public_id],
                ];
                $journal=$this->journals->postAuthoritativeSourceJournal($userId,'year_end_reopen',[
                    'entry_date'=>(string)$year->ends_on,'memo'=>'Reopen financial year '.(string)$year->label,'currency'=>'AUD',
                    'source_extension'=>'titan-ledger','source_type'=>'financial_year.reopen','source_public_id'=>$yearPublicId,'source_event_id'=>$operationId,
                    'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                    'prior_period_adjustment'=>true,'period_override_reason'=>$reason,'metadata'=>['reopens_close_public_id'=>(string)$close->public_id],
                ],$lines,'financial-year-reopen-journal:'.$operationId,(string)$close->close_journal_public_id);
                $reopenJournalId=(string)$journal['public_id'];
            }
            $event=[
                'public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'financial_year_public_id'=>$yearPublicId,'close_public_id'=>(string)$close->public_id,
                'event_type'=>'reopened','reason'=>$reason,'reopen_journal_public_id'=>$reopenJournalId,'operation_id'=>$operationId,'actor_user_id'=>$actor,
                'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'created_at'=>now(),
            ];
            $this->db->table('titan_ledger_financial_year_close_events')->insert($event);
            return $this->reopenResult($event);
        });
    }

    public function all(int $userId, int $limit=200): array
    {
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->table('titan_ledger_financial_year_closes')->where('company_id',$companyId)->orderByDesc('created_at')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>$this->result((array)$r))->all();
    }

    private function buildPreview(int $companyId, array $year): array
    {
        $yearId=(string)$year['public_id'];$start=(string)$year['starts_on'];$end=(string)$year['ends_on'];
        $rows=$this->nominalRows($companyId,$start,$end);
        $retained=$this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->where('system_key','retained_earnings')->first();
        if(!$retained) throw new InvalidArgumentException('Protected Retained Earnings account is missing.');
        $close=$this->calculator->build($rows,(string)$retained->public_id);
        $evidence=[
            'year_status'=>(string)$year['status'],'period_count'=>(int)$this->db->table('titan_ledger_accounting_periods')->where('company_id',$companyId)->where('financial_year_public_id',$yearId)->count(),
            'open_period_count'=>(int)$this->db->table('titan_ledger_accounting_periods')->where('company_id',$companyId)->where('financial_year_public_id',$yearId)->where('lock_state','open')->count(),
            'hard_locked_period_count'=>(int)$this->db->table('titan_ledger_accounting_periods')->where('company_id',$companyId)->where('financial_year_public_id',$yearId)->where('lock_state','hard_locked')->count(),
            'unposted_journal_count'=>(int)$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->whereBetween('entry_date',[$start,$end])->whereIn('status',['draft','validated'])->count(),
            'trial_balance_difference_minor'=>$this->trialBalanceDifference($companyId,$start,$end),
            'unreconciled_bank_session_count'=>$this->openReconciliationCount($companyId,$start,$end),
            'draft_gst_snapshot_count'=>$this->draftGstCount($companyId,$start,$end),
            'currency'=>$this->currencyState($companyId,$start,$end),'source_fingerprint'=>$this->sourceFingerprint($companyId,$start,$end),
        ];
        return ['financial_year'=>$year,'checklist'=>$this->checklist->evaluate($evidence),'close'=>$close,'source_fingerprint'=>$evidence['source_fingerprint']];
    }

    private function nominalRows(int $companyId,string $start,string $end): array
    {
        return $this->db->table('titan_ledger_journal_lines as l')->join('titan_ledger_journals as j',fn($join)=>$join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id'))
            ->join('titan_ledger_accounts as a',fn($join)=>$join->on('a.public_id','=','l.account_public_id')->on('a.company_id','=','l.company_id'))
            ->where('l.company_id',$companyId)->where('j.status','posted')->where('j.currency','AUD')->whereBetween('j.entry_date',[$start,$end])
            ->whereNotIn('j.journal_type',['year_end_close','year_end_reopen'])->whereIn('a.type',['revenue','other_income','cost_of_sales','expense','other_expense'])
            ->select(['a.public_id','a.code','a.name','a.type'])->selectRaw('SUM(l.debit_minor) as debit_minor, SUM(l.credit_minor) as credit_minor')
            ->groupBy('a.public_id','a.code','a.name','a.type')->orderBy('a.code')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();
    }

    private function trialBalanceDifference(int $companyId,string $start,string $end): int
    {
        $row=$this->db->table('titan_ledger_journal_lines as l')->join('titan_ledger_journals as j',fn($join)=>$join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id'))
            ->where('l.company_id',$companyId)->where('j.status','posted')->whereBetween('j.entry_date',[$start,$end])->selectRaw('COALESCE(SUM(l.debit_minor),0) as d, COALESCE(SUM(l.credit_minor),0) as c')->first();
        return (int)($row->d??0)-(int)($row->c??0);
    }

    private function openReconciliationCount(int $companyId,string $start,string $end): int
    {
        if(!$this->db->getSchemaBuilder()->hasTable('titan_ledger_reconciliation_sessions')) return 0;
        return (int)$this->db->table('titan_ledger_reconciliation_sessions as s')->join('titan_ledger_bank_statements as b',fn($join)=>$join->on('b.public_id','=','s.statement_public_id')->on('b.company_id','=','s.company_id'))
            ->where('s.company_id',$companyId)->where('s.status','open')->where('b.period_start','<=',$end)->where('b.period_end','>=',$start)->count();
    }

    private function draftGstCount(int $companyId,string $start,string $end): int
    {
        if(!$this->db->getSchemaBuilder()->hasTable('titan_ledger_gst_tax_snapshots')) return 0;
        return (int)$this->db->table('titan_ledger_gst_tax_snapshots')->where('company_id',$companyId)->where('status','prepared')->where('period_start','<=',$end)->where('period_end','>=',$start)->count();
    }

    private function currencyState(int $companyId,string $start,string $end): string
    {
        $currencies=$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->whereBetween('entry_date',[$start,$end])->distinct()->pluck('currency')->map(fn($v)=>strtoupper((string)$v))->all();
        if($currencies===[]) return 'AUD';
        return count($currencies)===1&&$currencies[0]==='AUD'?'AUD':'MIXED';
    }

    private function sourceFingerprint(int $companyId,string $start,string $end): string
    {
        $parts=[];
        foreach($this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->whereBetween('entry_date',[$start,$end])->whereNotIn('journal_type',['year_end_close','year_end_reopen'])->orderBy('public_id')->get(['public_id','payload_hash','currency','entry_date']) as $row){
            $parts[]='J|'.$row->public_id.'|'.($row->payload_hash??'').'|'.$row->currency.'|'.$row->entry_date;
        }
        foreach($this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->orderBy('public_id')->get(['public_id','code','type','subtype','normal_balance','system_key','is_active']) as $row){
            $parts[]='A|'.implode('|',[(string)$row->public_id,(string)$row->code,(string)$row->type,(string)$row->subtype,(string)$row->normal_balance,(string)$row->system_key,(int)$row->is_active]);
        }
        return hash('sha256',implode("\n",$parts));
    }

    private function year(int $companyId,string $publicId,bool $lock): object
    {
        $q=$this->db->table('titan_ledger_financial_years')->where('company_id',$companyId)->where('public_id',$publicId);if($lock)$q->lockForUpdate();
        $year=$q->first();if(!$year)throw new InvalidArgumentException('Financial year not found.');return $year;
    }

    private function context(array $command,string $transition): array{return ['trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'financial_year_transition'=>$transition];}
    private function canonical(mixed $value): mixed {if(!is_array($value))return $value;if(array_is_list($value))return array_map(fn($v)=>$this->canonical($v),$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=$this->canonical($v);return $value;}
    private function result(array $row): array {$keys=['public_id','financial_year_public_id','version','status','currency','net_profit_minor','close_journal_public_id','source_fingerprint','checklist_json','close_hash','supersedes_public_id','prepared_at','closed_at'];$out=array_intersect_key($row,array_flip($keys));if(isset($out['checklist_json'])&&is_string($out['checklist_json']))$out['checklist']=json_decode($out['checklist_json'],true)?:[];unset($out['checklist_json']);return $out;}
    private function reopenResult(array $row): array {return array_intersect_key($row,array_flip(['public_id','financial_year_public_id','close_public_id','event_type','reason','reopen_journal_public_id','operation_id','created_at']));}
}
