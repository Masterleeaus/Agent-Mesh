<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use InvalidArgumentException;

final class GstBasCalculator
{
    /** @param array<int,array<string,mixed>> $invoices @param array<int,array<string,mixed>> $spend @return array<string,mixed> */
    public static function calculate(array $invoices,array $spend): array
    {
        $g1=0;$oneA=0;$purchases=0;$oneB=0;$invoiceCount=0;$spendCount=0;$source=[];
        foreach($invoices as $row){self::assertAud($row);$type=(string)($row['document_type']??'');if(!in_array($type,['invoice','credit_note'],true))continue;$sign=$type==='invoice'?1:-1;$g1+=$sign*(int)($row['total_minor']??0);$oneA+=$sign*(int)($row['tax_minor']??0);$invoiceCount++;$source[]=self::sourceToken('crm',$row);}
        foreach($spend as $row){self::assertAud($row);$type=(string)($row['posting_type']??'');if(!in_array($type,['supplier_bill','supplier_credit','spend_actual'],true))continue;$sign=$type==='supplier_credit'?-1:1;$purchases+=$sign*(int)($row['total_minor']??0);$oneB+=$sign*(int)($row['gst_minor']??0);$spendCount++;$source[]=self::sourceToken('spend',$row);}
        sort($source,SORT_STRING);
        $review=[];if($g1<0||$oneA<0||$purchases<0||$oneB<0)$review[]='negative_bas_label_requires_review';
        return [
            'reporting_method'=>'simpler_bas','accounting_basis'=>'accrual','currency'=>'AUD',
            'g1_total_sales_minor'=>$g1,'one_a_gst_on_sales_minor'=>$oneA,'one_b_gst_on_purchases_minor'=>$oneB,
            'total_purchases_minor'=>$purchases,'net_gst_payable_minor'=>$oneA-$oneB,
            'invoice_source_count'=>$invoiceCount,'spend_source_count'=>$spendCount,'source_fingerprint'=>hash('sha256',implode('|',$source)),
            'lodgement_ready'=>$review===[],'review_reasons'=>$review,
        ];
    }

    private static function assertAud(array $row): void
    {
        $currency=strtoupper(trim((string)($row['currency']??'')));if($currency!=='AUD')throw new InvalidArgumentException('GST tax ledger requires AUD-normalized source evidence before BAS preparation.');
    }

    private static function sourceToken(string $source,array $row): string
    {
        $hash=strtolower(trim((string)($row['fact_hash']??'')));if(!preg_match('/^[a-f0-9]{64}$/',$hash))$hash=hash('sha256',json_encode($row,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));return $source.':'.$hash;
    }
}
