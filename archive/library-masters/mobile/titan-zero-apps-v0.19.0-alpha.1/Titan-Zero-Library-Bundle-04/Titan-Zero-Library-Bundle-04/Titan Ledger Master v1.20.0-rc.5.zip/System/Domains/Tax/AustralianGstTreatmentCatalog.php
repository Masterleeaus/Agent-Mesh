<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

final class AustralianGstTreatmentCatalog
{
    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        return [
            'gst_on_sales'=>['label'=>'GST on sales','default_rate_bps'=>1000,'bas_label'=>'1A','taxable'=>true,'claimable'=>false],
            'gst_on_purchases'=>['label'=>'GST on purchases','default_rate_bps'=>1000,'bas_label'=>'1B','taxable'=>true,'claimable'=>true],
            'gst_free'=>['label'=>'GST-free','default_rate_bps'=>0,'bas_label'=>null,'taxable'=>false,'claimable'=>false],
            'input_taxed'=>['label'=>'Input taxed','default_rate_bps'=>0,'bas_label'=>null,'taxable'=>false,'claimable'=>false],
            'bas_excluded'=>['label'=>'BAS excluded','default_rate_bps'=>0,'bas_label'=>null,'taxable'=>false,'claimable'=>false],
        ];
    }

    public static function supports(string $code): bool { return isset(self::all()[$code]); }
}
