<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Bookkeeping;

final class BookkeepingSummaryCalculator
{
    public function summarize(
        int $manualIncomeInc,
        int $manualIncomeGst,
        int $manualExpenseInc,
        int $manualExpenseGst,
        int $paymentIncomeInc,
        int $paymentIncomeGst,
        int $refundInc,
        int $refundGst,
    ): array {
        $manualIncomeEx = $manualIncomeInc - $manualIncomeGst;
        $manualExpenseEx = $manualExpenseInc - $manualExpenseGst;
        $paymentIncomeEx = $paymentIncomeInc - $paymentIncomeGst;
        $refundEx = $refundInc - $refundGst;

        $incomeEx = $manualIncomeEx + $paymentIncomeEx - $refundEx;
        $expenseEx = $manualExpenseEx;
        $gstCollected = $manualIncomeGst + $paymentIncomeGst - $refundGst;
        $cashIn = $manualIncomeInc + $paymentIncomeInc;
        $cashOut = $manualExpenseInc + $refundInc;

        return [
            'income_minor' => $incomeEx,
            'expense_minor' => $expenseEx,
            'profit_minor' => $incomeEx - $expenseEx,
            'gst_collected_minor' => $gstCollected,
            'gst_paid_minor' => $manualExpenseGst,
            'net_gst_minor' => $gstCollected - $manualExpenseGst,
            'cash_in_minor' => $cashIn,
            'cash_out_minor' => $cashOut,
            'net_cash_movement_minor' => $cashIn - $cashOut,
            'gross_cash_in_minor' => $cashIn,
            'refunds_minor' => $refundInc,
        ];
    }
}
