<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementService;
use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class FinancialReportingController extends Controller
{
    public function __construct(private FinancialStatementService $reports, private FinancialReportSnapshotService $snapshots) {}
    public function trialBalance(Request $r){return response()->json($this->reports->trialBalance((int)$r->user()->id,(string)$r->query('as_of',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function profitLoss(Request $r){return response()->json($this->reports->profitLoss((int)$r->user()->id,(string)$r->query('from',now()->startOfMonth()->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function balanceSheet(Request $r){return response()->json($this->reports->balanceSheet((int)$r->user()->id,(string)$r->query('as_of',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function retainedEarnings(Request $r){return response()->json($this->reports->retainedEarnings((int)$r->user()->id,(string)$r->query('from',now()->startOfMonth()->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function managementPack(Request $r){return response()->json($this->reports->managementPack((int)$r->user()->id,(string)$r->query('from',now()->startOfMonth()->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function drilldown(Request $r,string $account){return response()->json($this->reports->accountDrilldown((int)$r->user()->id,$account,(string)$r->query('from',now()->startOfMonth()->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD'),(int)$r->query('limit',200)));}
    public function snapshots(Request $r){return response()->json(['data'=>$this->snapshots->all((int)$r->user()->id,(int)$r->query('limit',200))]);}
}
