<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class ForecastingController extends Controller
{
    public function __construct(private CashflowForecastService $cashflow,private ProfitabilityService $profitability,private ForecastSnapshotService $snapshots){}
    public function actual(Request $r){return response()->json($this->cashflow->actualCashflow((int)$r->user()->id,(string)$r->query('from',now()->subDays(30)->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function forecast(Request $r){return response()->json($this->cashflow->forecast((int)$r->user()->id,(string)$r->query('as_of',now()->toDateString()),(int)$r->query('horizon_days',90),(string)$r->query('currency','AUD')));}
    public function profitability(Request $r){return response()->json($this->profitability->pack((int)$r->user()->id,(string)$r->query('from',now()->startOfMonth()->toDateString()),(string)$r->query('to',now()->toDateString()),(string)$r->query('currency','AUD')));}
    public function snapshots(Request $r){return response()->json(['data'=>$this->snapshots->all((int)$r->user()->id,(int)$r->query('limit',200))]);}
    public function variance(Request $r,string $snapshot){return response()->json($this->snapshots->variance((int)$r->user()->id,$snapshot,(string)$r->query('through',now()->toDateString())));}
}
