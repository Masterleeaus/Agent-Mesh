<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class LedgerDomainReceiptService
{
    private const TABLE = 'titan_ledger_command_receipts';

    public function __construct(private ConnectionInterface $db, private LedgerCompanyContext $companyContext) {}


    public function all(int $userId, int $limit = 100): array
    {
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->table(self::TABLE)
            ->where('company_id', $companyId)
            ->orderByDesc('id')
            ->limit(max(1, min($limit, 500)))
            ->limit(10000)->get()
            ->map(static fn ($row) => (array) $row)
            ->all();
    }

    /** @param array<string,mixed> $command */
    public function begin(array $command): array
    {
        $companyId = (int) $command['company_id'];
        $commandId = (string) $command['command_id'];
        $requestHash = $this->requestHash($command);
        $existing = $this->find($companyId, $commandId);
        if ($existing !== null) return $this->replay($existing, $requestHash);

        $publicId = (string) Str::ulid();
        try {
            $this->db->table(self::TABLE)->insert([
                'public_id' => $publicId,
                'company_id' => $companyId,
                'command_id' => $commandId,
                'command_name' => (string) $command['command_name'],
                'command_version' => (int) ($command['command_version'] ?? 1),
                'caller_extension' => (string) ($command['caller_extension'] ?? 'unknown'),
                'actor_user_id' => (int) $command['actor_user_id'],
                'target_public_id' => $command['target_public_id'] ?? null,
                'governance_reference' => (string) $command['governance_reference'],
                'risk_reference' => $command['risk_reference'] ?? null,
                'risk_class' => $command['risk_class'] ?? null,
                'risk_score' => $command['risk_score'] ?? null,
                'risk_ruleset_version' => $command['risk_ruleset_version'] ?? null,
                'assurance_reference' => $command['assurance_reference'] ?? null,
                'assurance_class' => $command['assurance_class'] ?? null,
                'assurance_score' => $command['assurance_score'] ?? null,
                'assurance_ruleset_version' => $command['assurance_ruleset_version'] ?? null,
                'trace_id' => $command['trace_id'] ?? null,
                'correlation_id' => $command['correlation_id'] ?? null,
                'causation_id' => $command['causation_id'] ?? null,
                'request_hash' => $requestHash,
                'status' => 'started',
                'started_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } catch (QueryException $e) {
            $race = $this->find($companyId, $commandId);
            if ($race !== null) return $this->replay($race, $requestHash);
            throw $e;
        }

        return ['mode' => 'new', 'public_id' => $publicId, 'request_hash' => $requestHash];
    }

    /** @param array<string,mixed> $result */
    public function apply(int $companyId, string $commandId, string $publicId, array $result): array
    {
        $writeFingerprint = hash('sha256', $this->canonicalJson($result));
        $updated = $this->db->table(self::TABLE)
            ->where('company_id', $companyId)
            ->where('command_id', $commandId)
            ->where('status', 'started')
            ->update([
                'status' => 'applied',
                'result_public_id' => $this->resultPublicId($result),
                'result_payload' => json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                'write_fingerprint' => $writeFingerprint,
                'write_verified' => true,
                'completed_at' => now(),
                'updated_at' => now(),
            ]);
        if ($updated !== 1) throw new InvalidArgumentException('Titan Ledger command receipt could not transition to applied.');

        $row = $this->find($companyId, $commandId);
        if ($row === null) throw new InvalidArgumentException('Titan Ledger applied receipt could not be reloaded.');
        return array_filter([
            'status' => 'applied',
            'adapter' => 'titan-ledger.v1',
            'domain_receipt_reference' => $publicId,
            'write_verified' => true,
            'write_fingerprint' => $writeFingerprint,
            'governance_reference' => (string) $row->governance_reference,
            'risk_reference' => $row->risk_reference ?? null,
            'risk_class' => $row->risk_class ?? null,
            'risk_score' => isset($row->risk_score) ? (float) $row->risk_score : null,
            'risk_ruleset_version' => $row->risk_ruleset_version ?? null,
            'assurance_reference' => $row->assurance_reference ?? null,
            'assurance_class' => $row->assurance_class ?? null,
            'assurance_score' => isset($row->assurance_score) ? (float) $row->assurance_score : null,
            'assurance_ruleset_version' => $row->assurance_ruleset_version ?? null,
            'result' => $result,
        ], static fn ($value) => $value !== null);
    }

    public function fail(int $companyId, string $commandId, string $errorCode): void
    {
        $updated = $this->db->table(self::TABLE)
            ->where('company_id', $companyId)
            ->where('command_id', $commandId)
            ->where('status', 'started')
            ->update([
                'status' => 'failed',
                'error_code' => substr($errorCode, 0, 120),
                'error_message_redacted' => 'Titan Ledger authoritative execution did not apply.',
                'completed_at' => now(),
                'updated_at' => now(),
            ]);
        if ($updated !== 1) throw new InvalidArgumentException('Titan Ledger command failure receipt could not be persisted.');
    }

    private function find(int $companyId, string $commandId): ?object
    {
        return $this->db->table(self::TABLE)->where('company_id', $companyId)->where('command_id', $commandId)->first();
    }

    private function replay(object $receipt, string $requestHash): array
    {
        if (! hash_equals((string) $receipt->request_hash, $requestHash)) {
            throw new InvalidArgumentException('Titan Ledger domain idempotency collision.');
        }
        if ((string) $receipt->status !== 'applied') {
            throw new InvalidArgumentException('Titan Ledger domain receipt exists but is not replayable.');
        }
        $result = json_decode((string) ($receipt->result_payload ?? 'null'), true);
        if (! is_array($result)) throw new InvalidArgumentException('Titan Ledger domain receipt result is unavailable.');
        return [
            'mode' => 'replay',
            'receipt' => [
                'status' => 'applied',
                'adapter' => 'titan-ledger.v1',
                'domain_receipt_reference' => (string) $receipt->public_id,
                'write_verified' => (bool) $receipt->write_verified,
                'write_fingerprint' => (string) $receipt->write_fingerprint,
                'governance_reference' => (string) $receipt->governance_reference,
                'risk_reference' => $receipt->risk_reference ?? null,
                'risk_class' => $receipt->risk_class ?? null,
                'risk_score' => isset($receipt->risk_score) ? (float) $receipt->risk_score : null,
                'risk_ruleset_version' => $receipt->risk_ruleset_version ?? null,
                'assurance_reference' => $receipt->assurance_reference ?? null,
                'assurance_class' => $receipt->assurance_class ?? null,
                'assurance_score' => isset($receipt->assurance_score) ? (float) $receipt->assurance_score : null,
                'assurance_ruleset_version' => $receipt->assurance_ruleset_version ?? null,
                'result' => $result,
                'replayed' => true,
            ],
        ];
    }

    /** @param array<string,mixed> $command */
    private function requestHash(array $command): string
    {
        $bounded = [
            'command_id' => $command['command_id'] ?? null,
            'command_name' => $command['command_name'] ?? null,
            'command_version' => $command['command_version'] ?? 1,
            'company_id' => $command['company_id'] ?? null,
            'actor_user_id' => $command['actor_user_id'] ?? null,
            'caller_extension' => $command['caller_extension'] ?? null,
            'target_public_id' => $command['target_public_id'] ?? null,
            'payload' => $command['payload'] ?? [],
            'governance_reference' => $command['governance_reference'] ?? null,
            'submission_hash' => $command['submission_hash'] ?? null,
            'trace_id' => $command['trace_id'] ?? null,
            'correlation_id' => $command['correlation_id'] ?? null,
            'causation_id' => $command['causation_id'] ?? null,
        ];
        return hash('sha256', $this->canonicalJson($bounded));
    }

    private function canonicalJson(array $value): string
    {
        $canonical = $this->canonicalize($value);
        return (string) json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn ($item) => $this->canonicalize($item), $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }

    private function resultPublicId(array $result): ?string
    {
        foreach (['public_id', 'journal_public_id', 'account_public_id', 'financial_year_public_id', 'period_public_id'] as $key) {
            if (isset($result[$key]) && is_scalar($result[$key])) return substr((string) $result[$key], 0, 191);
        }
        return null;
    }
}
