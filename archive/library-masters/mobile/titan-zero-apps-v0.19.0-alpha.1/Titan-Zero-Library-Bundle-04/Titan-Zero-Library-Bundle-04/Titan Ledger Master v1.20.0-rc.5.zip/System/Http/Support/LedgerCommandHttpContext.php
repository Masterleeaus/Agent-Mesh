<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Support;

use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class LedgerCommandHttpContext
{
    public static function commandId(Request $request, ?string $legacyOperationId = null): string
    {
        foreach ([$request->input('command_id'), $request->header('X-Titan-Command-Id'), $request->header('Idempotency-Key'), $legacyOperationId] as $candidate) {
            $value = trim((string) ($candidate ?? ''));
            if ($value !== '') return substr($value, 0, 191);
        }
        if ($request->expectsJson()) throw new \InvalidArgumentException('command_id or Idempotency-Key is required for Titan Ledger API mutations.');
        return 'legacy-web:' . (string) Str::uuid();
    }

    public static function lineage(Request $request, array $payload = []): array
    {
        return array_filter([
            'trace_id' => $payload['trace_id'] ?? $request->header('X-Titan-Trace-Id'),
            'correlation_id' => $payload['correlation_id'] ?? $request->header('X-Titan-Correlation-Id'),
            'causation_id' => $payload['causation_id'] ?? $request->header('X-Titan-Causation-Id'),
        ], static fn ($value) => $value !== null && $value !== '');
    }
}
