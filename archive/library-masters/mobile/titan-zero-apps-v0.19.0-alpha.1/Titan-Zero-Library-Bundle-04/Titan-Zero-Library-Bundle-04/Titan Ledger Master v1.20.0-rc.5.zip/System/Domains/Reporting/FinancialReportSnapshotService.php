<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reporting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class FinancialReportSnapshotService
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private FinancialStatementService $reports,
        private FinancialReportSnapshotPolicy $policy,
    ) {}

    public function prepare(int $userId, string $snapshotKey, array $payload, string $operationId, array $command, ?string $supersedes=null, ?string $supersessionReason=null): array
    {
        $snapshotKey = $this->snapshotKey($snapshotKey);
        $type = (string)($payload['report_type'] ?? 'management_pack');
        $start = (string)($payload['period_start'] ?? '');
        $end = (string)($payload['period_end'] ?? '');
        $currency = strtoupper((string)($payload['currency'] ?? 'AUD'));
        $this->policy->assertPrepareAllowed($type,$currency,$start,$end);
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->transaction(function() use($userId,$companyId,$snapshotKey,$type,$start,$end,$currency,$operationId,$command,$supersedes,$supersessionReason): array {
            $existing = $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('operation_id',$operationId)->lockForUpdate()->first();
            if ($existing) return $this->result((array)$existing);
            if ($supersedes !== null) {
                $old = $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('public_id',$supersedes)->lockForUpdate()->first();
                if (!$old || (string)$old->status !== 'finalized') throw new InvalidArgumentException('Financial report supersession requires a finalized prior snapshot.');
                if ((string)$old->snapshot_key !== $snapshotKey) throw new InvalidArgumentException('Financial report supersession snapshot key mismatch.');
            }
            $envelope = $this->buildEnvelope($userId,$type,$start,$end,$currency);
            $version = (int)$this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('snapshot_key',$snapshotKey)->max('version') + 1;
            $canonical = $this->canonical($envelope['payload']);
            $row = [
                'public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'snapshot_key'=>$snapshotKey,'version'=>$version,
                'report_type'=>$type,'period_start'=>$start,'period_end'=>$end,'currency'=>$currency,'status'=>'prepared',
                'balanced'=>$envelope['balanced'],'complete'=>$envelope['complete'],'source_fingerprint'=>$envelope['source_fingerprint'],
                'report_payload'=>json_encode($canonical,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                'report_hash'=>hash('sha256',json_encode($canonical,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
                'supersedes_public_id'=>$supersedes,'supersession_reason_code'=>$supersessionReason,
                'operation_id'=>$operationId,'finalize_operation_id'=>null,
                'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                'prepared_by_user_id'=>$this->companyContext->actorUserId($userId),'finalized_by_user_id'=>null,
                'prepared_at'=>now(),'finalized_at'=>null,'created_at'=>now(),'updated_at'=>now(),
            ];
            $this->db->table('titan_ledger_financial_report_snapshots')->insert($row);
            return $this->result($row);
        });
    }

    public function finalize(int $userId, string $snapshotPublicId, string $operationId, array $command): array
    {
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->transaction(function() use($userId,$companyId,$snapshotPublicId,$operationId): array {
            $row = $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->lockForUpdate()->first();
            if (!$row) throw new InvalidArgumentException('Financial report snapshot not found.');
            if ((string)$row->status === 'finalized' && (string)$row->finalize_operation_id === $operationId) return $this->result((array)$row);
            $current = $this->buildEnvelope($userId,(string)$row->report_type,(string)$row->period_start,(string)$row->period_end,(string)$row->currency);
            $snapshot = (array)$row;
            $snapshot['balanced'] = (bool)$row->balanced;
            $snapshot['complete'] = (bool)$row->complete;
            $this->policy->assertFinalizeAllowed($snapshot,(string)$current['source_fingerprint']);
            $actor = $this->companyContext->actorUserId($userId);
            $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->update([
                'status'=>'finalized','finalize_operation_id'=>$operationId,'finalized_by_user_id'=>$actor,'finalized_at'=>now(),'updated_at'=>now(),
            ]);
            return $this->result((array)$this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->first());
        });
    }

    public function supersede(int $userId, string $snapshotPublicId, array $payload, string $operationId, array $command): array
    {
        $companyId = $this->companyContext->companyId($userId);
        $old = $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)->where('public_id',$snapshotPublicId)->first();
        if (!$old || (string)$old->status !== 'finalized') throw new InvalidArgumentException('Only a finalized financial report snapshot can be superseded.');
        $reason = trim((string)($payload['reason_code'] ?? ''));
        if ($reason === '' || strlen($reason) > 80) throw new InvalidArgumentException('Financial report supersession requires a bounded reason_code.');
        return $this->prepare($userId,(string)$old->snapshot_key,[
            'report_type'=>(string)$old->report_type,'period_start'=>(string)$old->period_start,'period_end'=>(string)$old->period_end,'currency'=>(string)$old->currency,
        ],$operationId,$command,$snapshotPublicId,$reason);
    }

    public function all(int $userId, int $limit=200): array
    {
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->table('titan_ledger_financial_report_snapshots')->where('company_id',$companyId)
            ->orderByDesc('period_end')->orderByDesc('version')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>$this->result((array)$r))->all();
    }

    private function buildEnvelope(int $userId, string $type, string $start, string $end, string $currency): array
    {
        $report = match($type) {
            'trial_balance' => $this->reports->trialBalance($userId,$end,$currency),
            'profit_loss' => $this->reports->profitLoss($userId,$start,$end,$currency),
            'balance_sheet' => $this->reports->balanceSheet($userId,$end,$currency),
            'management_pack' => $this->reports->managementPack($userId,$start,$end,$currency),
            default => throw new InvalidArgumentException('Unsupported financial report snapshot type.'),
        };
        $tb = $type === 'trial_balance' ? $report : $this->reports->trialBalance($userId,$end,$currency);
        $balanced = ($tb['balanced'] ?? false) === true && ($type !== 'balance_sheet' || ($report['balanced'] ?? false) === true) && ($type !== 'management_pack' || ($report['balanced'] ?? false) === true);
        $complete = ($tb['complete'] ?? false) === true && ($report['complete'] ?? false) === true;
        $source = $type === 'management_pack' ? (string)$report['source_fingerprint'] : hash('sha256',(string)$report['source_fingerprint'].'|'.(string)$tb['source_fingerprint']);
        return ['payload'=>$report,'balanced'=>$balanced,'complete'=>$complete,'source_fingerprint'=>$source];
    }

    private function snapshotKey(string $value): string
    {
        $value = trim($value);
        if (!preg_match('/^[A-Za-z0-9._:-]{1,80}$/',$value)) throw new InvalidArgumentException('Financial report snapshot key is invalid.');
        return $value;
    }

    private function canonical(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn($v)=>$this->canonical($v),$value);
        ksort($value,SORT_STRING);
        foreach($value as $k=>$v) $value[$k]=$this->canonical($v);
        return $value;
    }

    private function result(array $row): array
    {
        $keys=['public_id','snapshot_key','version','report_type','period_start','period_end','currency','status','balanced','complete','source_fingerprint','report_hash','report_payload','supersedes_public_id','supersession_reason_code','prepared_at','finalized_at'];
        $out=array_intersect_key($row,array_flip($keys));
        if(isset($out['report_payload'])&&is_string($out['report_payload']))$out['report_payload']=json_decode($out['report_payload'],true)?:[];
        $out['balanced']=(bool)($out['balanced']??false);$out['complete']=(bool)($out['complete']??false);
        return $out;
    }
}
