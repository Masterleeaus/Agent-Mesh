<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Receivables;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ReceivableCollectionService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext,private ReceivableProjectionService $projection) {}

    public function all(int $userId,int $limit=500): array
    {
        $companyId=$this->companyContext->companyId($userId);$this->projection->refreshAll($companyId,$limit);
        return $this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->orderByDesc('is_overdue')->orderByDesc('days_past_due')->orderBy('due_at')->limit(max(1,min($limit,1000)))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function agingSummary(int $userId): array
    {
        $rows=$this->all($userId,1000);$summary=['current'=>0,'1_30'=>0,'31_60'=>0,'61_90'=>0,'91_plus'=>0,'unknown_due_date'=>0,'settled'=>0,'total_outstanding_minor'=>0,'customer_credit_minor'=>0,'open_invoices'=>0];
        foreach($rows as $row){$bucket=(string)$row['aging_bucket'];if(isset($summary[$bucket]))$summary[$bucket]+=(int)$row['outstanding_minor'];$summary['total_outstanding_minor']+=(int)$row['outstanding_minor'];$summary['customer_credit_minor']+=(int)$row['customer_credit_minor'];if((int)$row['outstanding_minor']>0)$summary['open_invoices']++;}
        return $summary;
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function transition(int $userId,string $invoicePublicId,array $payload,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$actor=$this->companyContext->actorUserId($userId);$to=trim((string)($payload['collection_state']??''));
        if(!in_array($to,ReceivableCollectionPolicy::states(),true))throw new InvalidArgumentException('Unknown receivable collection state.');
        $reason=$this->reasonCode($payload['reason_code']??null);$next=$this->optionalTimestamp($payload['next_action_at']??null);
        return $this->db->transaction(function() use($companyId,$actor,$invoicePublicId,$to,$reason,$next,$operationId,$command): array {
            $this->projection->refresh($companyId,$invoicePublicId);$row=$this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->where('invoice_public_id',$invoicePublicId)->lockForUpdate()->first();
            if(!$row)throw new InvalidArgumentException('Receivable not found.');$replay=$this->eventByOperation($companyId,$operationId);if($replay){$this->assertReplayEvent($replay,$invoicePublicId,'state_transition');return $this->result($row,$replay);}
            if((int)$row->outstanding_minor===0)throw new InvalidArgumentException('Settled receivables cannot enter collections.');
            ReceivableCollectionPolicy::assertTransition((string)$row->collection_state,$to);$event=$this->eventRow($companyId,$row,'state_transition',(string)$row->collection_state,$to,$reason,null,null,$next,null,$operationId,$actor,$command);
            $this->db->table('titan_ledger_collection_events')->insert($event);$this->db->table('titan_ledger_receivables')->where('id',$row->id)->update(['collection_state'=>$to,'next_action_at'=>$next,'last_action_at'=>now(),'last_action_type'=>'state_transition','updated_at'=>now()]);
            $row=$this->db->table('titan_ledger_receivables')->where('id',$row->id)->first();return $this->result($row,(object)$event);
        });
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function recordFollowUp(int $userId,string $invoicePublicId,array $payload,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$actor=$this->companyContext->actorUserId($userId);$channel=trim((string)($payload['channel']??''));$outcome=trim((string)($payload['outcome']??''));
        if(!in_array($channel,['phone','sms','email','portal','manual'],true))throw new InvalidArgumentException('Unsupported collection follow-up channel.');
        if(!in_array($outcome,['sent','contacted','no_response','promise_to_pay','dispute','paid_elsewhere','failed'],true))throw new InvalidArgumentException('Unsupported collection follow-up outcome.');
        $reason=$this->reasonCode($payload['reason_code']??'follow_up');$next=$this->optionalTimestamp($payload['next_action_at']??null);$promise=$this->optionalMinor($payload['promised_amount_minor']??null);
        return $this->db->transaction(function() use($companyId,$actor,$invoicePublicId,$channel,$outcome,$reason,$next,$promise,$operationId,$command): array {
            $this->projection->refresh($companyId,$invoicePublicId);$row=$this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->where('invoice_public_id',$invoicePublicId)->lockForUpdate()->first();if(!$row)throw new InvalidArgumentException('Receivable not found.');
            $replay=$this->eventByOperation($companyId,$operationId);if($replay){$this->assertReplayEvent($replay,$invoicePublicId,'follow_up');return $this->result($row,$replay);}if((int)$row->outstanding_minor===0)throw new InvalidArgumentException('Settled receivables do not require collection follow-up.');
            if($outcome==='promise_to_pay'&&($promise===null||$promise<1||$promise>(int)$row->outstanding_minor))throw new InvalidArgumentException('Promise-to-pay amount must be positive and no more than outstanding receivable.');
            $event=$this->eventRow($companyId,$row,'follow_up',(string)$row->collection_state,(string)$row->collection_state,$reason,$channel,$outcome,$next,$promise,$operationId,$actor,$command);$this->db->table('titan_ledger_collection_events')->insert($event);
            $this->db->table('titan_ledger_receivables')->where('id',$row->id)->update(['next_action_at'=>$next,'last_action_at'=>now(),'last_action_type'=>'follow_up','updated_at'=>now()]);$row=$this->db->table('titan_ledger_receivables')->where('id',$row->id)->first();return $this->result($row,(object)$event);
        });
    }

    private function eventByOperation(int $companyId,string $operationId): ?object{return $this->db->table('titan_ledger_collection_events')->where('company_id',$companyId)->where('operation_id',$operationId)->first();}
    private function assertReplayEvent(object $event,string $invoicePublicId,string $type): void{if(!hash_equals((string)$event->invoice_public_id,$invoicePublicId)||!hash_equals((string)$event->event_type,$type))throw new InvalidArgumentException('Collection operation id collision.');}
    private function reasonCode(mixed $value): string{$v=trim((string)$value);if(!preg_match('/^[a-z0-9][a-z0-9._-]{0,79}$/',$v))throw new InvalidArgumentException('Collection reason_code must be a bounded machine-readable code.');return $v;}
    private function optionalTimestamp(mixed $value): ?string{if($value===null||trim((string)$value)==='')return null;try{$d=new DateTimeImmutable((string)$value);}catch(\Throwable){throw new InvalidArgumentException('Invalid next_action_at.');}return $d->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');}
    private function optionalMinor(mixed $value): ?int{if($value===null||$value==='')return null;if(filter_var($value,FILTER_VALIDATE_INT)===false||(int)$value<0)throw new InvalidArgumentException('promised_amount_minor must be a non-negative integer.');return (int)$value;}
    /** @param array<string,mixed> $command @return array<string,mixed> */
    private function eventRow(int $companyId,object $row,string $type,string $from,string $to,string $reason,?string $channel,?string $outcome,?string $next,?int $promise,string $operationId,int $actor,array $command): array{return ['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'receivable_public_id'=>(string)$row->public_id,'invoice_public_id'=>(string)$row->invoice_public_id,'event_type'=>$type,'from_state'=>$from,'to_state'=>$to,'channel'=>$channel,'outcome'=>$outcome,'reason_code'=>$reason,'next_action_at'=>$next,'promised_amount_minor'=>$promise,'command_id'=>(string)($command['command_id']??$operationId),'operation_id'=>$operationId,'actor_user_id'=>$actor,'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'created_at'=>now()];}
    /** @return array<string,mixed> */
    private function result(object $row,object $event): array{return ['public_id'=>(string)$row->public_id,'invoice_public_id'=>(string)$row->invoice_public_id,'currency'=>(string)$row->currency,'outstanding_minor'=>(int)$row->outstanding_minor,'receivable_credit_minor'=>(int)$row->receivable_credit_minor,'customer_credit_minor'=>(int)$row->customer_credit_minor,'aging_bucket'=>(string)$row->aging_bucket,'days_past_due'=>$row->days_past_due===null?null:(int)$row->days_past_due,'collection_state'=>(string)$row->collection_state,'collection_event_public_id'=>(string)$event->public_id,'collection_event_type'=>(string)$event->event_type,'next_action_at'=>$row->next_action_at??null];}
}
