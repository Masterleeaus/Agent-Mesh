<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Crm;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;

final class CrmInvoiceAccountingPort
{
    public function __construct(private LedgerCommandSubmissionService $commands) {}

    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    public function invoiceIssued(int $actorUserId, array $fact, array $context=[]): array
    {
        $normalized=CrmInvoiceFact::issued($fact);
        return $this->submit($actorUserId,'ledger.crm.invoice.post',$normalized,$context);
    }

    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    public function creditNoteIssued(int $actorUserId, array $fact, array $context=[]): array
    {
        $normalized=CrmInvoiceFact::creditNote($fact);
        return $this->submit($actorUserId,'ledger.crm.credit_note.post',$normalized,$context);
    }

    /** @param array<string,mixed> $fact @param array<string,mixed> $context */
    private function submit(int $actorUserId, string $command, array $fact, array $context): array
    {
        $commandId='crm-ledger:'.substr(hash('sha256',$command.'|'.$fact['source_event_id'].'|'.CrmInvoiceFact::hash($fact)),0,48);
        return $this->commands->submit($actorUserId,$command,$commandId,(string)$fact['document_public_id'],$fact,$context,'titan-crm');
    }
}
