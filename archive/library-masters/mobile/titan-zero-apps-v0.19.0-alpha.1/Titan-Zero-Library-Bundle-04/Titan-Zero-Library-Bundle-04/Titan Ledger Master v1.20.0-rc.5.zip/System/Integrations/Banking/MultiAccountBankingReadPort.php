<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Integrations\Banking;
use App\Extensions\TitanLedger\System\Domains\Banking\FinancialAccountRegistryService;
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingService;
final class MultiAccountBankingReadPort{public function __construct(private FinancialAccountRegistryService $accounts,private MultiAccountBankingService $banking){}public function accounts(int $userId): array{return $this->accounts->all($userId);}public function movements(int $userId,int $limit=200): array{return $this->banking->movements($userId,$limit);}}
