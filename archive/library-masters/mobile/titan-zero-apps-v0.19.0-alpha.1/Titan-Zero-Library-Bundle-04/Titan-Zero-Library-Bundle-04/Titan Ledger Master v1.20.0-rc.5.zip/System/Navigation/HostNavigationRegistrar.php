<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Navigation;

use ReflectionMethod;
use Throwable;

final class HostNavigationRegistrar
{
    public function register(): void
    {
        $this->registerUser();
        $this->registerAdmin();
    }

    private function registerUser(): void
    {
        $class = 'App\\Support\\Extensions\\MenuContributionRegistry';
        if (! class_exists($class)) return;
        try {
            $registry = app($class);
            $this->invoke($registry, TitanLedgerNavigation::user(), 'navigation.user');
        } catch (Throwable) {
        }
    }

    private function registerAdmin(): void
    {
        $class = 'App\\Support\\Extensions\\ContributionRegistry';
        if (! class_exists($class)) return;
        try {
            $registry = app($class);
            $this->invoke($registry, TitanLedgerNavigation::admin(), 'navigation.admin');
        } catch (Throwable) {
        }
    }

    private function invoke(object $registry, array $definition, string $channel): void
    {
        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) continue;
            $count = (new ReflectionMethod($registry, $method))->getNumberOfRequiredParameters();
            try {
                if ($count <= 1) $registry->{$method}($definition);
                elseif ($count === 2) $registry->{$method}('titan-ledger', $definition);
                else $registry->{$method}($channel, 'titan-ledger', $definition);
                return;
            } catch (Throwable) {
            }
        }
    }
}
