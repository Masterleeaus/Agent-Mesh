<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

final class HostLedgerRiskGateway implements LedgerRiskGatewayContract
{
    private const BINDINGS = ['titan.risk.gateway.titan-ledger','titan.risk.gateway'];
    public function __construct(private Container $app, private LedgerRiskGatewayContract $fallback) {}
    public function available(): bool { foreach (self::BINDINGS as $b) { if (!$this->app->bound($b)) continue; try { $candidate=$this->app->make($b); } catch (Throwable) { continue; } if ($candidate===$this) continue; if ($candidate instanceof LedgerRiskGatewayContract) return true; if (is_object($candidate) && method_exists($candidate,'evaluate')) return true; if (is_callable($candidate)) return true; } return false; }
    public function evaluate(array $evidence): array
    {
        foreach (self::BINDINGS as $binding) {
            if (!$this->app->bound($binding)) continue;
            try { $candidate=$this->app->make($binding); } catch (Throwable) { continue; }
            if ($candidate === $this) continue;
            if ($candidate instanceof LedgerRiskGatewayContract) return $candidate->evaluate($evidence);
            if (is_object($candidate) && method_exists($candidate,'evaluate')) $result=$candidate->evaluate($evidence);
            elseif (is_callable($candidate)) $result=$candidate($evidence);
            else continue;
            if (!is_array($result)) throw new RuntimeException('Titan Risk returned an invalid Ledger decision.');
            return $result;
        }
        return $this->fallback->evaluate($evidence);
    }
}
