<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Http\Controllers;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxLedgerService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxAdjustmentService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
final class TaxLedgerController extends Controller
{
    public function __construct(private GstTaxLedgerService $tax,private GstTaxAdjustmentService $adjustments){}
    public function preview(Request $r){$d=$r->validate(['period_start'=>'required|date_format:Y-m-d','period_end'=>'required|date_format:Y-m-d','reporting_method'=>'sometimes|in:simpler_bas,full_bas','accounting_basis'=>'sometimes|in:accrual']);return response()->json(['data'=>$this->tax->preview((int)$r->user()->id,$d['period_start'],$d['period_end'],(string)($d['reporting_method']??'simpler_bas'),(string)($d['accounting_basis']??'accrual'))]);}
    public function snapshots(Request $r){return response()->json(['data'=>$this->tax->all((int)$r->user()->id,200)]);}
    public function adjustments(Request $r){return response()->json(['data'=>$this->adjustments->all((int)$r->user()->id,500)]);}
}
