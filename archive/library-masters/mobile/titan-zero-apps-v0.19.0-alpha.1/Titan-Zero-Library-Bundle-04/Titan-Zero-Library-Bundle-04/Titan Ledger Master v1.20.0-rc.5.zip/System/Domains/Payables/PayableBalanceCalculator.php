<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Payables;

use InvalidArgumentException;

final class PayableBalanceCalculator
{
    /** @return array{outstanding_minor:int,payable_credit_minor:int,supplier_prepayment_minor:int} */
    public static function calculate(int $billTotalMinor,int $creditsMinor,int $paymentsMinor,int $supplierPrepaymentMinor=0): array
    {
        foreach(['bill total'=>$billTotalMinor,'credits'=>$creditsMinor,'payments'=>$paymentsMinor,'supplier prepayment'=>$supplierPrepaymentMinor] as $label=>$value) {
            if($value<0) throw new InvalidArgumentException($label.' must not be negative.');
        }
        $net=$billTotalMinor-$creditsMinor-$paymentsMinor;
        return [
            'outstanding_minor'=>max(0,$net),
            'payable_credit_minor'=>max(0,-$net),
            'supplier_prepayment_minor'=>$supplierPrepaymentMinor,
        ];
    }
}
