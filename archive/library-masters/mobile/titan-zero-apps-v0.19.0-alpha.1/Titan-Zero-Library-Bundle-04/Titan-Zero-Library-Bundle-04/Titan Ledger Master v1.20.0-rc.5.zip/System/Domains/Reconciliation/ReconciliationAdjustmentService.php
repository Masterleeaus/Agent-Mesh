<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use InvalidArgumentException;

final class ReconciliationAdjustmentService
{
    public function __construct(private ChartOfAccountsService $accounts,private JournalService $journals,private BankReconciliationService $reconciliation){}

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function post(int $userId,string $transactionPublicId,array $payload,string $operationId,array $command): array
    {
        $type=strtolower(trim((string)($payload['adjustment_type']??'')));if(!in_array($type,['bank_fee','interest_income','interest_expense'],true))throw new InvalidArgumentException('Unsupported bank reconciliation adjustment type.');
        $reason=trim((string)($payload['reason_code']??''));if($reason===''||strlen($reason)>80)throw new InvalidArgumentException('reason_code is required for reconciliation adjustments.');
        $tx=$this->reconciliation->transactionForAdjustment($userId,$transactionPublicId);$hint=(string)($tx['classification_hint']??'unknown');if($hint!=='unknown'&&$hint!==$type)throw new InvalidArgumentException('Reconciliation adjustment type conflicts with immutable bank classification hint.');
        $fee=$this->accounts->findSystemAccount($userId,'merchant_fees');$income=$this->accounts->findByCode($userId,'8000');$expense=$this->accounts->findByCode($userId,'9000');if(!$fee||!$income||!$expense)throw new InvalidArgumentException('Required bank fee/interest Ledger accounts are unavailable.');
        $accountIds=['bank'=>(string)$tx['account_public_id'],'bank_fees'=>(string)$fee['public_id'],'interest_income'=>(string)$income['public_id'],'interest_expense'=>(string)$expense['public_id']];$lines=ReconciliationAdjustmentJournalMapper::map($type,(int)$tx['amount_minor'],$accountIds);
        $journal=$this->journals->postAuthoritativeSourceJournal($userId,'bank_reconciliation_adjustment',['entry_date'=>(string)$tx['posted_on'],'currency'=>(string)$tx['currency'],'source_extension'=>'titan-ledger','source_type'=>'bank_reconciliation.'.$type,'source_public_id'=>$transactionPublicId,'source_event_id'=>'reconciliation-adjustment:'.$transactionPublicId,'source_operation_id'=>$operationId,'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'metadata'=>['reason_code'=>$reason,'classification_hint'=>$hint,'reference_hash'=>$tx['reference_hash']??null]],$lines,$operationId,null);
        $candidateId=null;foreach(($journal['lines']??[]) as $line){if((string)($line['account_public_id']??'')===(string)$tx['account_public_id']){$candidateId=(string)$line['public_id'];break;}}if($candidateId===null)throw new InvalidArgumentException('Reconciliation adjustment bank journal line could not be identified.');
        $match=$this->reconciliation->matchTransaction($userId,$transactionPublicId,['candidate_public_id'=>$candidateId,'reason_code'=>'adjustment_'.$type],'recon-adjust-match:'.substr(hash('sha256',$operationId),0,48),$command);
        return ['public_id'=>(string)$journal['public_id'],'transaction_public_id'=>$transactionPublicId,'adjustment_type'=>$type,'currency'=>(string)$tx['currency'],'amount_minor'=>(int)$tx['amount_minor'],'journal_public_id'=>(string)$journal['public_id'],'candidate_public_id'=>$candidateId,'match_event_public_id'=>$match['public_id'],'match_state'=>'matched','reason_code'=>$reason,'occurred_at'=>(string)$tx['posted_at']];
    }
}
