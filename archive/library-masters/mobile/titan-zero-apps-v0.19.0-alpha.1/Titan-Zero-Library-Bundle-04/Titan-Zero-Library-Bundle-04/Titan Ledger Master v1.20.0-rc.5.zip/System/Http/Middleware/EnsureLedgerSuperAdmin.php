<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

final class EnsureLedgerSuperAdmin
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if (! $user) abort(403);
        if (method_exists($user, 'isSuperAdmin') && (bool) $user->isSuperAdmin()) return $next($request);
        foreach (['is_super_admin', 'super_admin'] as $field) {
            if (isset($user->{$field}) && (bool) $user->{$field}) return $next($request);
        }
        abort(403);
    }
}
