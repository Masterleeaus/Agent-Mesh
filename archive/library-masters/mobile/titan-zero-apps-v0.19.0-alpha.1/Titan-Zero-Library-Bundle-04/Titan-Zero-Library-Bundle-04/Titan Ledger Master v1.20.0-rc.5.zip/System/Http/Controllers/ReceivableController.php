<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableCollectionService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class ReceivableController extends Controller
{
    public function __construct(private ReceivableCollectionService $receivables) {}
    public function index(Request $request){return response()->json(['data'=>$this->receivables->all((int)$request->user()->id,(int)$request->integer('limit',500))]);}
    public function aging(Request $request){return response()->json(['data'=>$this->receivables->agingSummary((int)$request->user()->id)]);}
}
