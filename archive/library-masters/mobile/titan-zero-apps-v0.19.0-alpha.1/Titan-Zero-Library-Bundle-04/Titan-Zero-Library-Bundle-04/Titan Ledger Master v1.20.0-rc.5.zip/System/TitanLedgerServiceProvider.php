<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandAdapter;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandBusGatewayContract;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandDefinitionRegistry;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\CommandBus\LedgerDomainReceiptService;
use App\Extensions\TitanLedger\System\CommandBus\HostLedgerCommandBusGateway;
use App\Extensions\TitanLedger\System\CommandBus\UnavailableLedgerCommandBusGateway;
use App\Extensions\TitanLedger\System\Console\SyncLedgerHostCommand;
use App\Extensions\TitanLedger\System\Console\DrainLedgerSignalsCommand;
use App\Extensions\TitanLedger\System\Signal\LedgerFinancialEventCatalog;
use App\Extensions\TitanLedger\System\Signal\LedgerSignalGatewayContract;
use App\Extensions\TitanLedger\System\Signal\LedgerSignalOutboxService;
use App\Extensions\TitanLedger\System\Signal\HostLedgerSignalGateway;
use App\Extensions\TitanLedger\System\Signal\UnavailableLedgerSignalGateway;
use App\Extensions\TitanLedger\System\Governance\LedgerRiskGatewayContract;
use App\Extensions\TitanLedger\System\Governance\HostLedgerRiskGateway;
use App\Extensions\TitanLedger\System\Governance\UnavailableLedgerRiskGateway;
use App\Extensions\TitanLedger\System\Governance\LedgerAssuranceGatewayContract;
use App\Extensions\TitanLedger\System\Governance\HostLedgerAssuranceGateway;
use App\Extensions\TitanLedger\System\Governance\UnavailableLedgerAssuranceGateway;
use App\Extensions\TitanLedger\System\Governance\LedgerGovernanceEvidenceService;
use App\Extensions\TitanLedger\System\Rewind\LedgerRewindSource;
use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceAccountingService;
use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceAccountingPort;
use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementService;
use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementPort;
use App\Extensions\TitanLedger\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanLedger\System\Navigation\MenuSyncService;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableProjectionService;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableCollectionService;
use App\Extensions\TitanLedger\System\Domains\Payables\PayableProjectionService;
use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingService;
use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingPort;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankReconciliationService;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\ReconciliationAdjustmentService;
use App\Extensions\TitanLedger\System\Integrations\Banking\BankReconciliationPort;
use App\Extensions\TitanLedger\System\Integrations\Banking\AdvancedReconciliationPort;
use App\Extensions\TitanLedger\System\Domains\Tax\GstSnapshotPolicy;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxLedgerService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstAdjustmentPolicy;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxAdjustmentService;
use App\Extensions\TitanLedger\System\Integrations\Tax\GstTaxLedgerReadPort;
use App\Extensions\TitanLedger\System\Integrations\Reporting\FinancialReportingReadPort;
use App\Extensions\TitanLedger\System\Integrations\Forecasting\CashflowForecastingReadPort;
use App\Extensions\TitanLedger\System\Integrations\Accounting\FinancialYearCloseReadPort;
use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseService;
use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseChecklist;
use App\Extensions\TitanLedger\System\Domains\Accounting\YearEndCloseCalculator;
use App\Extensions\TitanLedger\System\Domains\Banking\FinancialAccountRegistryService;
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingService;
use App\Extensions\TitanLedger\System\Integrations\Banking\MultiAccountBankingReadPort;
use App\Extensions\TitanLedger\System\Certification\LedgerProductionCertificationService;
use App\Extensions\TitanLedger\System\Certification\LedgerProductionDatabaseHardener;
use App\Extensions\TitanLedger\System\Console\CertifyLedgerProductionCommand;
use Illuminate\Support\ServiceProvider;
use Throwable;

final class TitanLedgerServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-ledger', \App\Extensions\TitanLedger\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        foreach ([
            \App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCalendar::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodPolicy::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodService::class,
            YearEndCloseCalculator::class,
            FinancialYearCloseChecklist::class,
            FinancialYearCloseService::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\JournalEntryValidator::class,
            \App\Extensions\TitanLedger\System\Domains\Accounting\JournalService::class,
            \App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingCategoryService::class,
            \App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingGstCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingReportService::class,
            \App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingSummaryCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingTransactionService::class,
            LedgerDomainReceiptService::class,
            LedgerGovernanceEvidenceService::class,
            LedgerRewindSource::class,
            CrmInvoiceAccountingService::class,
            CrmInvoiceAccountingPort::class,
            TitanPaySettlementService::class,
            TitanPaySettlementPort::class,
            ReceivableProjectionService::class,
            ReceivableCollectionService::class,
            PayableProjectionService::class,
            SpendAccountingService::class,
            SpendAccountingPort::class,
            BankReconciliationService::class,
            ReconciliationAdjustmentService::class,
            BankReconciliationPort::class,
            AdvancedReconciliationPort::class,
            FinancialAccountRegistryService::class,
            MultiAccountBankingService::class,
            MultiAccountBankingReadPort::class,
            GstSnapshotPolicy::class,
            GstAdjustmentPolicy::class,
            GstTaxAdjustmentService::class,
            GstTaxLedgerService::class,
            GstTaxLedgerReadPort::class,
            \App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Reporting\ComparativePeriodResolver::class,
            \App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementService::class,
            \App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotPolicy::class,
            \App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotService::class,
            FinancialReportingReadPort::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastService::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityService::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotPolicy::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastVarianceCalculator::class,
            \App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotService::class,
            CashflowForecastingReadPort::class,
            FinancialYearCloseReadPort::class,
            LedgerProductionCertificationService::class,
            LedgerProductionDatabaseHardener::class,
            LedgerCommandAdapter::class,
            LedgerCommandSubmissionService::class,
            LedgerSignalOutboxService::class,
            MenuSyncService::class,
            HostNavigationRegistrar::class,
        ] as $service) $this->app->singleton($service);

        $this->app->singleton(LedgerCommandBusGatewayContract::class, fn ($app): LedgerCommandBusGatewayContract =>
            new HostLedgerCommandBusGateway($app, new UnavailableLedgerCommandBusGateway())
        );

        $this->app->singleton(LedgerSignalGatewayContract::class, fn ($app): LedgerSignalGatewayContract =>
            new HostLedgerSignalGateway($app, new UnavailableLedgerSignalGateway())
        );

        $this->app->singleton(LedgerRiskGatewayContract::class, fn ($app): LedgerRiskGatewayContract =>
            new HostLedgerRiskGateway($app, new UnavailableLedgerRiskGateway())
        );

        $this->app->singleton(LedgerAssuranceGatewayContract::class, fn ($app): LedgerAssuranceGatewayContract =>
            new HostLedgerAssuranceGateway($app, new UnavailableLedgerAssuranceGateway())
        );

        $this->app->singleton('titan.command-bus.domain-adapter.titan-ledger', fn ($app) => $app->make(LedgerCommandAdapter::class));
        $this->app->singleton('titan.command-bus.command-definitions.titan-ledger', fn () => LedgerCommandDefinitionRegistry::all());
        $this->app->singleton('titan.signal.event-definitions.titan-ledger', fn () => LedgerFinancialEventCatalog::all());
        $this->app->singleton('titan.ledger.rewind-source', fn ($app) => $app->make(LedgerRewindSource::class));
        $this->app->singleton('titan.ledger.crm-invoice-accounting.v1', fn ($app) => $app->make(CrmInvoiceAccountingPort::class));
        $this->app->singleton('titan.ledger.payment-settlement.v1', fn ($app) => $app->make(TitanPaySettlementPort::class));
        $this->app->singleton('titan.ledger.zeropay-settlement.v1', fn ($app) => $app->make(TitanPaySettlementPort::class));
        $this->app->singleton('titan.ledger.receivables.v1', fn ($app) => $app->make(ReceivableCollectionService::class));
        $this->app->singleton('titan.ledger.spend-accounting.v1', fn ($app) => $app->make(SpendAccountingPort::class));
        $this->app->singleton('titan.ledger.payables.v1', fn ($app) => $app->make(PayableProjectionService::class));
        $this->app->singleton('titan.ledger.bank-reconciliation.v1', fn ($app) => $app->make(BankReconciliationPort::class));
        $this->app->singleton('titan.ledger.advanced-reconciliation.v1', fn ($app) => $app->make(AdvancedReconciliationPort::class));
        $this->app->singleton('titan.ledger.multi-account-banking.v1', fn ($app) => $app->make(MultiAccountBankingReadPort::class));
        $this->app->singleton('titan.ledger.gst-tax-ledger.v1', fn ($app) => $app->make(GstTaxLedgerReadPort::class));
        $this->app->singleton('titan.ledger.financial-reporting.v1', fn ($app) => $app->make(FinancialReportingReadPort::class));
        $this->app->singleton('titan.ledger.cashflow-forecasting.v1', fn ($app) => $app->make(CashflowForecastingReadPort::class));
        $this->app->singleton('titan.ledger.financial-year-close.v1', fn ($app) => $app->make(FinancialYearCloseReadPort::class));
        $this->app->singleton('titan.ledger.production-certification.v1', fn ($app) => $app->make(LedgerProductionCertificationService::class));
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-ledger');
        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        if (is_file(__DIR__ . '/../routes/api.php')) $this->loadRoutesFrom(__DIR__ . '/../routes/api.php');
        if ($this->app->runningInConsole()) $this->commands([SyncLedgerHostCommand::class, DrainLedgerSignalsCommand::class, CertifyLedgerProductionCommand::class]);

        $this->app->booted(function (): void {
            try { $this->app->make(HostNavigationRegistrar::class)->register(); } catch (Throwable) {}
            try { $this->app->make(MenuSyncService::class)->sync(false); } catch (Throwable) {}
            try { $this->registerRewindSource(); } catch (Throwable) {}
        });
    }

    private function registerRewindSource(): void
    {
        $adapterContract = 'App\\Support\\Extensions\\RewindSourceAdapter';
        $registryClass = 'App\\Support\\Extensions\\RewindSourceRegistry';
        if (!interface_exists($adapterContract) || !class_exists($registryClass)) return;
        $source = $this->app->make(LedgerRewindSource::class);
        $adapter = new class($source) implements \App\Support\Extensions\RewindSourceAdapter {
            public function __construct(private LedgerRewindSource $source) {}
            public function sourceKey(): string { return $this->source->sourceKey(); }
            public function watermark(int $companyId, string $traceId): array { return $this->source->watermark($companyId, $traceId); }
            public function records(int $companyId, string $traceId, ?string $asOf = null): iterable { return $this->source->records($companyId, $traceId, $asOf); }
        };
        $registry = $this->app->make($registryClass);
        if (is_object($registry) && method_exists($registry, 'register')) $registry->register($adapter);
    }

    public function registerKey(): string { return 'titan-ledger'; }
    public static function uninstall(): void { /* Financial and command-receipt evidence is retained by default. */ }
}
