<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reporting;

use DateTimeImmutable;
use InvalidArgumentException;

final class ComparativePeriodResolver
{
    public function resolve(string $from, string $to): array
    {
        $start = $this->date($from);
        $end = $this->date($to);
        if ($start > $end) throw new InvalidArgumentException('Financial reporting period start must not be after period end.');
        $days = (int) $start->diff($end)->days + 1;
        $previousEnd = $start->modify('-1 day');
        $previousStart = $previousEnd->modify('-' . ($days - 1) . ' days');
        return [
            'current' => ['from'=>$start->format('Y-m-d'),'to'=>$end->format('Y-m-d')],
            'previous_period' => ['from'=>$previousStart->format('Y-m-d'),'to'=>$previousEnd->format('Y-m-d')],
            'prior_year' => ['from'=>$this->priorYear($start)->format('Y-m-d'),'to'=>$this->priorYear($end)->format('Y-m-d')],
        ];
    }

    private function priorYear(DateTimeImmutable $date): DateTimeImmutable
    {
        $year=(int)$date->format('Y')-1;$month=(int)$date->format('n');$day=(int)$date->format('j');
        $last=(int)(new DateTimeImmutable(sprintf('%04d-%02d-01',$year,$month)))->modify('last day of this month')->format('j');
        return $date->setDate($year,$month,min($day,$last));
    }

    private function date(string $value): DateTimeImmutable
    {
        $d = DateTimeImmutable::createFromFormat('!Y-m-d', trim($value));
        $errors = DateTimeImmutable::getLastErrors();
        if (!$d || (is_array($errors) && (($errors['warning_count'] ?? 0) > 0 || ($errors['error_count'] ?? 0) > 0))) {
            throw new InvalidArgumentException('Financial reporting dates must use YYYY-MM-DD.');
        }
        return $d;
    }
}
