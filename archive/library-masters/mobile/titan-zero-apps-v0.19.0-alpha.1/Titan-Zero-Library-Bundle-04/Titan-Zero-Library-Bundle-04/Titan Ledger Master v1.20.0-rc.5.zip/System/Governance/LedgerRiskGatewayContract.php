<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

interface LedgerRiskGatewayContract
{
    /** @param array<string,mixed> $evidence */
    public function evaluate(array $evidence): array;
    public function available(): bool;
}
