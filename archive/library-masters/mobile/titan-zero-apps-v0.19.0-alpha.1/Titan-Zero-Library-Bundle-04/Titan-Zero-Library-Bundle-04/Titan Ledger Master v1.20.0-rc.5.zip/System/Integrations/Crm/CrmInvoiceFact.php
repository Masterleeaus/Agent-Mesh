<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Crm;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final class CrmInvoiceFact
{
    private const REVENUE_SYSTEM_KEYS = ['service_revenue','sales_revenue'];

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function issued(array $input): array
    {
        $invoiceId = self::requiredId($input, 'invoice_public_id');
        return self::normalize($input, 'invoice', $invoiceId, $invoiceId);
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function creditNote(array $input): array
    {
        $creditId = self::requiredId($input, 'credit_note_public_id');
        $invoiceId = self::requiredId($input, 'invoice_public_id');
        return self::normalize($input, 'credit_note', $creditId, $invoiceId);
    }

    /** @param array<string,mixed> $fact */
    public static function hash(array $fact): string
    {
        return hash('sha256', self::canonicalJson($fact));
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private static function normalize(array $input, string $type, string $documentId, string $invoiceId): array
    {
        $subtotal = self::minor($input, 'subtotal_minor');
        $tax = self::minor($input, 'tax_minor');
        $total = self::minor($input, 'total_minor');
        if ($total < 1) throw new InvalidArgumentException('CRM invoice accounting fact total_minor must be positive.');
        if ($subtotal + $tax !== $total) throw new InvalidArgumentException('CRM invoice accounting fact arithmetic does not balance.');

        $currency = strtoupper(trim((string)($input['currency'] ?? '')));
        if (!preg_match('/^[A-Z]{3}$/', $currency)) throw new InvalidArgumentException('CRM invoice accounting fact currency must be ISO-4217 style.');
        $issuedAt = trim((string)($input['issued_at'] ?? ''));
        if ($issuedAt === '') throw new InvalidArgumentException('CRM invoice accounting fact issued_at is required.');
        try { $date = new DateTimeImmutable($issuedAt); } catch (\Throwable) { throw new InvalidArgumentException('CRM invoice accounting fact issued_at is invalid.'); }

        $dueAt = null;
        if (isset($input['due_at']) && trim((string)$input['due_at']) !== '') {
            try { $due = new DateTimeImmutable((string)$input['due_at']); } catch (\Throwable) { throw new InvalidArgumentException('CRM invoice accounting fact due_at is invalid.'); }
            if ($due->format('Y-m-d') < $date->format('Y-m-d')) throw new InvalidArgumentException('CRM invoice accounting fact due_at cannot precede issued_at.');
            $dueAt = $due->format('Y-m-d');
        }

        $sourceEventId = trim((string)($input['source_event_id'] ?? ''));
        if ($sourceEventId === '' || strlen($sourceEventId) > 120) throw new InvalidArgumentException('CRM invoice accounting fact source_event_id is required.');
        $sourceVersion = max(1, (int)($input['source_version'] ?? 1));

        $splits = $input['revenue_splits'] ?? null;
        if ($splits === null) $splits = [['system_key'=>'service_revenue','amount_minor'=>$subtotal]];
        if (!is_array($splits) || $splits === []) throw new InvalidArgumentException('CRM invoice accounting fact revenue_splits are required.');
        $normalizedSplits = [];
        foreach ($splits as $split) {
            if (!is_array($split)) throw new InvalidArgumentException('CRM invoice accounting revenue split must be an object.');
            $key = trim((string)($split['system_key'] ?? ''));
            if (!in_array($key, self::REVENUE_SYSTEM_KEYS, true)) throw new InvalidArgumentException('Unsupported CRM invoice revenue system account.');
            $amount = self::minor($split, 'amount_minor');
            if ($amount < 1) throw new InvalidArgumentException('CRM invoice revenue split amount must be positive.');
            $normalizedSplits[] = ['system_key'=>$key,'amount_minor'=>$amount];
        }
        if (array_sum(array_column($normalizedSplits, 'amount_minor')) !== $subtotal) {
            throw new InvalidArgumentException('CRM invoice revenue splits must equal subtotal_minor.');
        }

        return array_filter([
            'contract' => 'titan-ledger.crm-invoice-accounting.v1',
            'document_type' => $type,
            'document_public_id' => $documentId,
            'invoice_public_id' => $invoiceId,
            'invoice_number' => self::optionalText($input['invoice_number'] ?? null, 100),
            'entry_date' => $date->format('Y-m-d'),
            'issued_at' => $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'due_at' => $dueAt,
            'currency' => $currency,
            'subtotal_minor' => $subtotal,
            'tax_minor' => $tax,
            'total_minor' => $total,
            'revenue_splits' => $normalizedSplits,
            'source_event_id' => $sourceEventId,
            'source_version' => $sourceVersion,
        ], static fn($value) => $value !== null);
    }

    /** @param array<string,mixed> $input */
    private static function minor(array $input, string $key): int
    {
        if (!array_key_exists($key, $input) || filter_var($input[$key], FILTER_VALIDATE_INT) === false) {
            throw new InvalidArgumentException("CRM invoice accounting fact {$key} must be an integer minor-unit amount.");
        }
        $value = (int)$input[$key];
        if ($value < 0) throw new InvalidArgumentException("CRM invoice accounting fact {$key} cannot be negative.");
        return $value;
    }

    /** @param array<string,mixed> $input */
    private static function requiredId(array $input, string $key): string
    {
        $value = trim((string)($input[$key] ?? ''));
        if ($value === '' || strlen($value) > 100) throw new InvalidArgumentException("CRM invoice accounting fact {$key} is required.");
        return $value;
    }

    private static function optionalText(mixed $value, int $max): ?string
    {
        if ($value === null) return null;
        $value = trim((string)$value);
        if ($value === '') return null;
        if (strlen($value) > $max) throw new InvalidArgumentException('CRM invoice accounting fact text field is too long.');
        return $value;
    }

    private static function canonicalJson(array $value): string
    {
        $value = self::canonicalize($value);
        return (string)json_encode($value, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) return array_map([self::class,'canonicalize'], $value);
        ksort($value, SORT_STRING);
        foreach ($value as $k=>$v) $value[$k]=self::canonicalize($v);
        return $value;
    }
}
