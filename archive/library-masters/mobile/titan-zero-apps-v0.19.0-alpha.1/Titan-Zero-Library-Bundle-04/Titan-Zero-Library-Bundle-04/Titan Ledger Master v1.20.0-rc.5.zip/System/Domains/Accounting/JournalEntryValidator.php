<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

use InvalidArgumentException;

final class JournalEntryValidator
{
    public function validate(array $lines, bool $requireBalanced = true): array
    {
        if (count($lines) < 2) {
            throw new InvalidArgumentException('A journal requires at least two lines.');
        }

        $normalized = [];
        $debitTotal = 0;
        $creditTotal = 0;

        foreach (array_values($lines) as $index => $line) {
            if (! is_array($line)) {
                throw new InvalidArgumentException('Each journal line must be an object/array.');
            }

            $accountPublicId = trim((string) ($line['account_public_id'] ?? ''));
            if (strlen($accountPublicId) !== 26) {
                throw new InvalidArgumentException('Each journal line requires a 26-character account_public_id.');
            }

            $debit = $this->minorAmount($line['debit_minor'] ?? 0, 'debit_minor');
            $credit = $this->minorAmount($line['credit_minor'] ?? 0, 'credit_minor');

            if ($debit < 0 || $credit < 0) {
                throw new InvalidArgumentException('Journal line amounts must be non-negative integer minor units.');
            }
            if (($debit > 0 && $credit > 0) || ($debit === 0 && $credit === 0)) {
                throw new InvalidArgumentException('Each journal line must post a positive amount to exactly one side: debit or credit.');
            }

            if ($debit > PHP_INT_MAX - $debitTotal || $credit > PHP_INT_MAX - $creditTotal) {
                throw new InvalidArgumentException('Journal totals exceed supported integer minor-unit range.');
            }
            $debitTotal += $debit;
            $creditTotal += $credit;

            $normalized[] = [
                'line_no' => $index + 1,
                'account_public_id' => $accountPublicId,
                'description' => $this->nullableString($line['description'] ?? null),
                'debit_minor' => $debit,
                'credit_minor' => $credit,
                'tax_code' => $this->nullableString($line['tax_code'] ?? null),
                'tax_amount_minor' => $this->signedMinorAmount($line['tax_amount_minor'] ?? 0, 'tax_amount_minor'),
                'metadata' => $line['metadata'] ?? null,
            ];
        }

        if ($requireBalanced && $debitTotal !== $creditTotal) {
            throw new InvalidArgumentException("Journal must balance: debit total {$debitTotal} does not equal credit total {$creditTotal}.");
        }
        if ($requireBalanced && $debitTotal === 0) {
            throw new InvalidArgumentException('A posted journal must have a positive amount.');
        }

        return [
            'line_count' => count($normalized),
            'debit_total_minor' => $debitTotal,
            'credit_total_minor' => $creditTotal,
            'normalized_lines' => $normalized,
        ];
    }

    private function minorAmount(mixed $value, string $field): int
    {
        if (is_int($value)) return $value;
        if (is_string($value) && preg_match('/^-?\d+$/D', $value) === 1) {
            $int = filter_var($value, FILTER_VALIDATE_INT);
            if ($int !== false) return (int) $int;
        }
        throw new InvalidArgumentException("{$field} must be an integer minor-unit amount.");
    }

    private function signedMinorAmount(mixed $value, string $field): int
    {
        return $this->minorAmount($value, $field);
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
