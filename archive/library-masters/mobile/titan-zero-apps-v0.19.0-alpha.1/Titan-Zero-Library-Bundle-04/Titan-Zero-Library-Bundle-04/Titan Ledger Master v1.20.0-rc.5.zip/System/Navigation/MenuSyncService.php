<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Navigation;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class MenuSyncService
{
    public function __construct(private ConnectionInterface $db) {}

    public function sync(bool $force = false): array
    {
        $report = ['supported' => false, 'changed' => false, 'user' => null, 'admin' => null, 'regenerated' => false];
        if (! Schema::hasTable('menus')) return $report;
        foreach (['id', 'parent_id', 'key', 'route', 'label'] as $column) if (! Schema::hasColumn('menus', $column)) return $report;
        $report['supported'] = true;

        try {
            $report['user'] = $this->syncTree(TitanLedgerNavigation::user(), false);
            if (Schema::hasColumn('menus', 'is_admin')) $report['admin'] = $this->syncTree(TitanLedgerNavigation::admin(), true);
            else $report['admin'] = ['supported' => false, 'reason' => 'menus.is_admin is absent; admin registry contribution remains authoritative'];
            $report['changed'] = (bool) (($report['user']['changed'] ?? false) || ($report['admin']['changed'] ?? false));
            if ($report['changed'] || $force) $report['regenerated'] = $this->regenerate();
        } catch (Throwable $e) {
            $report['error'] = get_class($e);
        }
        return $report;
    }

    public function inspect(): array
    {
        $report = [
            'menus_table' => Schema::hasTable('menus'),
            'has_parent_id' => Schema::hasTable('menus') && Schema::hasColumn('menus', 'parent_id'),
            'has_is_admin' => Schema::hasTable('menus') && Schema::hasColumn('menus', 'is_admin'),
            'user_tree' => TitanLedgerNavigation::user(),
            'admin_tree' => TitanLedgerNavigation::admin(),
        ];
        if (! $report['menus_table']) return $report;
        $keys = array_merge(
            [TitanLedgerNavigation::user()['key']], array_column(TitanLedgerNavigation::user()['children'], 'key'),
            [TitanLedgerNavigation::admin()['key']], array_column(TitanLedgerNavigation::admin()['children'], 'key'),
        );
        $rows = $this->db->table('menus')->whereIn('key', $keys)->orderBy('id')->get();
        $report['rows'] = array_map(static fn ($row) => (array) $row, $rows->all());
        $report['duplicate_keys'] = $this->duplicateKeys($report['rows']);
        return $report;
    }

    private function syncTree(array $tree, bool $admin): array
    {
        $changed = false;
        $parent = $this->upsert($tree, null, $admin, $changed);
        $parentId = (int) $parent->id;
        foreach ($tree['children'] as $child) $this->upsert($child, $parentId, $admin, $changed);
        return ['supported' => true, 'changed' => $changed, 'parent_id' => $parentId, 'children' => count($tree['children'])];
    }

    private function upsert(array $item, ?int $parentId, bool $admin, bool &$changed): object
    {
        $rows = $this->db->table('menus')->where('key', $item['key'])->orderBy('id')->limit(10000)->get();
        $row = $rows->first();
        $routeActive = Route::has((string) $item['route']);
        $structural = $this->filtered([
            'parent_id' => $parentId,
            'route' => $item['route'],
            'route_slug' => null,
            'label' => $item['label'],
            'icon' => $item['icon'],
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => null,
            'is_admin' => $admin ? 1 : 0,
            'updated_at' => now(),
        ]);

        if ($row === null) {
            $insert = $structural + $this->filtered([
                'key' => $item['key'],
                'order' => $item['order'],
                'is_active' => $routeActive ? 1 : 0,
                'created_at' => now(),
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'letter_icon' => 0,
            ]);
            $id = $this->db->table('menus')->insertGetId($insert);
            $changed = true;
            return $this->db->table('menus')->where('id', $id)->first();
        }

        $updates = [];
        foreach ($structural as $key => $value) {
            if ($key === 'updated_at') continue;
            if ((string) ($row->{$key} ?? '') !== (string) ($value ?? '')) $updates[$key] = $value;
        }
        if (! $routeActive && property_exists($row, 'is_active') && (int) $row->is_active !== 0) $updates['is_active'] = 0;
        if ($updates !== []) {
            $updates['updated_at'] = now();
            $this->db->table('menus')->where('id', $row->id)->update($updates);
            $changed = true;
            $row = $this->db->table('menus')->where('id', $row->id)->first();
        }
        return $row;
    }

    private function filtered(array $values): array
    {
        $result = [];
        foreach ($values as $key => $value) if (Schema::hasColumn('menus', $key)) $result[$key] = $value;
        return $result;
    }

    private function regenerate(): bool
    {
        $class = 'App\\Services\\Common\\MenuService';
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) return false;
        try {
            app($class)->regenerate();
            return true;
        } catch (Throwable) {
            try {
                $class::regenerate();
                return true;
            } catch (Throwable) {
                return false;
            }
        }
    }

    private function duplicateKeys(array $rows): array
    {
        $counts = [];
        foreach ($rows as $row) $counts[(string) ($row['key'] ?? '')] = ($counts[(string) ($row['key'] ?? '')] ?? 0) + 1;
        return array_keys(array_filter($counts, static fn (int $count) => $count > 1));
    }
}
