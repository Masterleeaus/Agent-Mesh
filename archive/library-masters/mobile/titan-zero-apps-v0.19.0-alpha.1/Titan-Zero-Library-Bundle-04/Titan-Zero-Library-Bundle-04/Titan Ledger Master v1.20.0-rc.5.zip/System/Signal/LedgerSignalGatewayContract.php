<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

interface LedgerSignalGatewayContract
{
    public function available(): bool;

    /** @param array<string,mixed> $envelope */
    public function publish(array $envelope): array;
}
