<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

final class ProfitabilityCalculator
{
    /** @param array<int,array<string,mixed>> $rows */
    public function summary(array $rows): array
    {
        $revenue=0;$direct=0;$operating=0;
        foreach($rows as $row){$amount=(int)($row['amount_minor']??0);switch((string)($row['type']??'')){case 'revenue':case 'other_income':$revenue+=$amount;break;case 'cost_of_sales':$direct+=$amount;break;case 'expense':case 'other_expense':$operating+=$amount;break;}}
        $gross=$revenue-$direct;$net=$gross-$operating;
        return ['revenue_minor'=>$revenue,'direct_cost_minor'=>$direct,'gross_profit_minor'=>$gross,'gross_margin_bps'=>$this->margin($gross,$revenue),'operating_expense_minor'=>$operating,'net_profit_minor'=>$net,'net_margin_bps'=>$this->margin($net,$revenue)];
    }
    private function margin(int $value,int $revenue): ?int{return $revenue===0?null:(int)round(($value/$revenue)*10000);}
}
