<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

use InvalidArgumentException;

final class LedgerExternalDecisionNormalizer
{
    public static function risk(array $decision): array
    {
        if (($decision['allowed']??false)!==true) throw new InvalidArgumentException('Titan Risk denied Ledger execution.');
        $reference=self::reference($decision,'Titan Risk');
        $class=strtoupper(trim((string)($decision['risk_class']??'')));
        if (!in_array($class,['LOW','MEDIUM','HIGH','CRITICAL'],true)) throw new InvalidArgumentException('Titan Risk decision class is invalid.');
        return array_filter(['risk_reference'=>$reference,'risk_class'=>$class,'risk_score'=>self::score($decision['score']??null),'risk_ruleset_version'=>self::version($decision['ruleset_version']??null)],static fn($v)=>$v!==null);
    }
    public static function assurance(array $decision): array
    {
        if (($decision['allowed']??false)!==true) throw new InvalidArgumentException('Titan Assurance denied Ledger execution.');
        $reference=self::reference($decision,'Titan Assurance');
        $class=strtoupper(trim((string)($decision['assurance_class']??$decision['class']??'')));
        if ($class==='' || !preg_match('/^[A-Z][A-Z0-9_-]{0,29}$/',$class)) throw new InvalidArgumentException('Titan Assurance decision class is invalid.');
        return array_filter(['assurance_reference'=>$reference,'assurance_class'=>$class,'assurance_score'=>self::score($decision['score']??null),'assurance_ruleset_version'=>self::version($decision['ruleset_version']??null)],static fn($v)=>$v!==null);
    }
    private static function reference(array $d,string $engine): string { $r=trim((string)($d['decision_reference']??'')); if($r===''||strlen($r)>191) throw new InvalidArgumentException($engine.' durable decision reference is required.'); return $r; }
    private static function score(mixed $v): ?float { if($v===null||$v==='')return null; if(!is_numeric($v))throw new InvalidArgumentException('External decision score is invalid.'); $f=(float)$v; if($f<0||$f>1)throw new InvalidArgumentException('External decision score must be between 0 and 1.'); return $f; }
    private static function version(mixed $v): ?string { if($v===null)return null; $s=trim((string)$v); if($s==='')return null; if(strlen($s)>100)throw new InvalidArgumentException('External decision ruleset version is too long.'); return $s; }
}
