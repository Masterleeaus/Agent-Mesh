<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Http\Controllers;
use App\Extensions\TitanLedger\System\Domains\Payables\PayableProjectionService;
use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class PayableController extends Controller
{
    public function __construct(private PayableProjectionService $payables){}
    public function index(Request $request){return response()->json(['data'=>$this->payables->all((int)$request->user()->id,200)]);}
    public function aging(Request $request){return response()->json(['data'=>$this->payables->agingSummary((int)$request->user()->id)]);}
}
