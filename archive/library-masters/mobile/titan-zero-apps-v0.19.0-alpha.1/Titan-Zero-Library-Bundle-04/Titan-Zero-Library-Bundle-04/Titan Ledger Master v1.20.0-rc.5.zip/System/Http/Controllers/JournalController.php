<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\Http\Support\LedgerCommandHttpContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class JournalController extends Controller
{
    public function __construct(private JournalService $journals, private LedgerCommandSubmissionService $commands) {}

    public function index(Request $request) { $filters=$request->validate(['status'=>'nullable|in:draft,validated,posted','journal_type'=>'nullable|string|max:30','date_from'=>'nullable|date','date_to'=>'nullable|date']); return response()->json(['data'=>$this->journals->all((int)$request->user()->id,$filters)]); }
    public function show(Request $request,string $journal) { return response()->json($this->journals->show((int)$request->user()->id,$journal)); }

    public function store(Request $request)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191']+$this->journalRules(true)); $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.create',$commandId,null,$data,LedgerCommandHttpContext::lineage($request,$data)),201);
    }
    public function replaceLines(Request $request,string $journal)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','lines'=>'required|array|min:2']+$this->lineRules()); $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.lines.replace',$commandId,$journal,$data,LedgerCommandHttpContext::lineage($request,$data)));
    }
    public function validate(Request $request,string $journal)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191']); $commandId=LedgerCommandHttpContext::commandId($request); return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.validate',$commandId,$journal));
    }
    public function post(Request $request,string $journal)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','operation_id'=>'nullable|string|max:191']); $commandId=LedgerCommandHttpContext::commandId($request,$data['operation_id']??null);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.post',$commandId,$journal,array_filter(['operation_id'=>$data['operation_id']??null],fn($v)=>$v!==null)));
    }
    public function reverse(Request $request,string $journal)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191','operation_id'=>'nullable|string|max:191','entry_date'=>'nullable|date','memo'=>'nullable|string|max:500','reason'=>'nullable|string|max:500','prior_period_adjustment'=>'nullable|boolean','period_override_reason'=>'nullable|string|max:500','trace_id'=>'nullable|string|max:120','correlation_id'=>'nullable|string|max:120','causation_id'=>'nullable|string|max:120']);
        $commandId=LedgerCommandHttpContext::commandId($request,$data['operation_id']??null); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.reverse',$commandId,$journal,$data,LedgerCommandHttpContext::lineage($request,$data)),201);
    }
    public function correction(Request $request,string $journal)
    {
        $data=$request->validate(['command_id'=>'nullable|string|max:191']+$this->journalRules(false)); $commandId=LedgerCommandHttpContext::commandId($request); unset($data['command_id']);
        return response()->json($this->commands->submit((int)$request->user()->id,'ledger.journal.correction.create',$commandId,$journal,$data,LedgerCommandHttpContext::lineage($request,$data)),201);
    }

    private function journalRules(bool $allowType): array
    {
        $rules=['entry_date'=>'required|date','currency'=>'nullable|string|size:3','memo'=>'nullable|string|max:500','source_extension'=>'nullable|string|max:100','source_type'=>'nullable|string|max:100','source_public_id'=>'nullable|string|max:100','source_event_id'=>'nullable|string|max:120','source_operation_id'=>'nullable|string|max:191','trace_id'=>'nullable|string|max:120','correlation_id'=>'nullable|string|max:120','causation_id'=>'nullable|string|max:120','metadata'=>'nullable|array','prior_period_adjustment'=>'nullable|boolean','period_override_reason'=>'nullable|string|max:500','lines'=>'required|array|min:2']+$this->lineRules();
        if($allowType)$rules['journal_type']='nullable|in:general,adjustment,opening_balance,accrual,import'; return $rules;
    }
    private function lineRules(): array { return ['lines.*.account_public_id'=>'required|string|size:26','lines.*.description'=>'nullable|string|max:255','lines.*.debit_minor'=>'required|integer|min:0','lines.*.credit_minor'=>'required|integer|min:0','lines.*.tax_code'=>'nullable|string|max:40','lines.*.tax_amount_minor'=>'nullable|integer','lines.*.metadata'=>'nullable|array']; }
}
