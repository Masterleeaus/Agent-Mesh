<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

final class LedgerFinancialEventCatalog
{
    /** @return array<string,array{event_type:string,schema_version:int,subject_type:string,safe_result_fields:array<int,string>}> */
    public static function all(): array
    {
        return [
            'ledger.account.create' => self::definition('ledger.account.created', 'ledger_account', ['public_id','code','type','subtype','normal_balance','is_active']),
            'ledger.account.update' => self::definition('ledger.account.updated', 'ledger_account', ['public_id','code','type','subtype','normal_balance','is_active']),
            'ledger.journal.create' => self::definition('ledger.journal.created', 'ledger_journal', ['public_id','journal_type','status','entry_date']),
            'ledger.journal.lines.replace' => self::definition('ledger.journal.lines_replaced', 'ledger_journal', ['public_id','journal_type','status','entry_date','lock_version']),
            'ledger.journal.validate' => self::definition('ledger.journal.validated', 'ledger_journal', ['public_id','journal_type','status','entry_date','debit_total_minor','credit_total_minor']),
            'ledger.journal.post' => self::definition('ledger.journal.posted', 'ledger_journal', ['public_id','journal_type','status','entry_date','debit_total_minor','credit_total_minor','financial_year_public_id','accounting_period_public_id']),
            'ledger.journal.reverse' => self::definition('ledger.journal.reversed', 'ledger_journal', ['public_id','journal_type','status','entry_date','reversal_of_public_id','debit_total_minor','credit_total_minor']),
            'ledger.journal.correction.create' => self::definition('ledger.journal.correction_created', 'ledger_journal', ['public_id','journal_type','status','entry_date','correction_of_public_id']),
            'ledger.financial_year.create' => self::definition('ledger.financial_year.created', 'ledger_financial_year', ['public_id','label','starts_on','ends_on','is_closed']),
            'ledger.financial_year.close.prepare' => self::definition('ledger.financial_year.close_prepared', 'ledger_financial_year_close', ['public_id','financial_year_public_id','version','status','currency','net_profit_minor','source_fingerprint','close_hash','supersedes_public_id','prepared_at']),
            'ledger.financial_year.close' => self::definition('ledger.financial_year.closed', 'ledger_financial_year_close', ['public_id','financial_year_public_id','version','status','currency','net_profit_minor','close_journal_public_id','source_fingerprint','close_hash','closed_at']),
            'ledger.financial_year.reopen' => self::definition('ledger.financial_year.reopened', 'ledger_financial_year_close', ['public_id','financial_year_public_id','close_public_id','event_type','reason','reopen_journal_public_id','created_at']),
            'ledger.accounting_period.transition' => self::definition('ledger.accounting_period.transitioned', 'ledger_accounting_period', ['public_id','period_number','starts_on','ends_on','lock_state']),
            'ledger.bookkeeping.transaction.create' => self::definition('ledger.bookkeeping.transaction.created', 'bookkeeping_transaction', ['public_id','type','transaction_date','amount_inc_gst_minor','gst_minor']),
            'ledger.bookkeeping.transaction.update' => self::definition('ledger.bookkeeping.transaction.updated', 'bookkeeping_transaction', ['public_id','type','transaction_date','amount_inc_gst_minor','gst_minor']),
            'ledger.bookkeeping.transaction.delete' => self::definition('ledger.bookkeeping.transaction.deleted', 'bookkeeping_transaction', ['public_id','deleted']),
            'ledger.bookkeeping.category.create' => self::definition('ledger.bookkeeping.category.created', 'bookkeeping_category', ['public_id','name','type','is_active']),
            'ledger.crm.invoice.post' => self::definition('ledger.crm.invoice.posted', 'crm_invoice_accounting', ['public_id','document_type','document_public_id','invoice_public_id','journal_public_id','currency','subtotal_minor','tax_minor','total_minor','issued_at']),
            'ledger.crm.credit_note.post' => self::definition('ledger.crm.credit_note.posted', 'crm_invoice_accounting', ['public_id','document_type','document_public_id','invoice_public_id','journal_public_id','currency','subtotal_minor','tax_minor','total_minor','issued_at']),
            'ledger.payment.settlement.post' => self::definition('ledger.payment.settlement.posted', 'payment_settlement', ['public_id','settlement_type','settlement_public_id','payment_public_id','invoice_public_id','rail','currency','gross_amount_minor','fee_minor','cash_movement_minor','allocation_minor','overpayment_minor','journal_public_id','settled_at']),
            'ledger.payment.refund.post' => self::definition('ledger.payment.refund.posted', 'payment_settlement', ['public_id','settlement_type','settlement_public_id','payment_public_id','invoice_public_id','rail','currency','gross_amount_minor','fee_minor','cash_movement_minor','allocation_minor','overpayment_minor','journal_public_id','settled_at']),
            'ledger.receivable.collection.transition' => self::definition('ledger.receivable.collection.transitioned', 'receivable', ['public_id','invoice_public_id','currency','outstanding_minor','receivable_credit_minor','customer_credit_minor','aging_bucket','days_past_due','collection_state','collection_event_public_id','collection_event_type','next_action_at']),
            'ledger.receivable.follow_up.record' => self::definition('ledger.receivable.follow_up.recorded', 'receivable', ['public_id','invoice_public_id','currency','outstanding_minor','receivable_credit_minor','customer_credit_minor','aging_bucket','days_past_due','collection_state','collection_event_public_id','collection_event_type','next_action_at']),
            'ledger.payable.bill.post' => self::definition('ledger.payable.bill.posted', 'payable_spend', ['public_id','posting_type','document_public_id','bill_public_id','supplier_public_id','currency','subtotal_minor','gst_minor','total_minor','due_at','journal_public_id','occurred_at']),
            'ledger.payable.credit_note.post' => self::definition('ledger.payable.credit_note.posted', 'payable_spend', ['public_id','posting_type','document_public_id','bill_public_id','supplier_public_id','currency','subtotal_minor','gst_minor','total_minor','journal_public_id','occurred_at']),
            'ledger.payable.payment.post' => self::definition('ledger.payable.payment.posted', 'payable_spend', ['public_id','posting_type','document_public_id','bill_public_id','supplier_public_id','currency','amount_minor','fee_minor','ap_allocation_minor','prepayment_minor','rail','journal_public_id','occurred_at']),
            'ledger.spend.actual.post' => self::definition('ledger.spend.actual.posted', 'payable_spend', ['public_id','posting_type','document_public_id','supplier_public_id','currency','subtotal_minor','gst_minor','total_minor','fee_minor','rail','journal_public_id','occurred_at']),
            'ledger.bank.statement.import' => self::definition('ledger.bank.statement.imported', 'bank_statement', ['public_id','statement_public_id','account_public_id','currency','period_start','period_end','opening_balance_minor','closing_balance_minor','movement_minor','transaction_count','session_public_id','imported_at']),
            'ledger.bank.reconciliation.match' => self::definition('ledger.bank.reconciliation.matched', 'bank_reconciliation', ['public_id','session_public_id','transaction_public_id','candidate_public_id','journal_public_id','match_state','score']),
            'ledger.bank.reconciliation.reject_match' => self::definition('ledger.bank.reconciliation.match_rejected', 'bank_reconciliation', ['public_id','session_public_id','transaction_public_id','candidate_public_id','journal_public_id','match_state','reason_code']),
            'ledger.bank.reconciliation.close' => self::definition('ledger.bank.reconciliation.closed', 'bank_reconciliation', ['public_id','session_public_id','statement_public_id','account_public_id','currency','status','closing_proof_hash','ledger_opening_balance_minor','ledger_closing_balance_minor','statement_closing_balance_minor','unmatched_count','closed_at']),
            'ledger.bank.reconciliation.group_match' => self::definition('ledger.bank.reconciliation.group_matched', 'bank_reconciliation_group', ['public_id','group_public_id','session_public_id','group_type','bank_transaction_count','candidate_count','bank_total_minor','ledger_total_minor','score','match_state']),
            'ledger.bank.reconciliation.group_reject' => self::definition('ledger.bank.reconciliation.group_rejected', 'bank_reconciliation_group', ['public_id','group_public_id','session_public_id','group_type','match_state','reason_code']),
            'ledger.bank.reconciliation.adjustment.post' => self::definition('ledger.bank.reconciliation.adjustment_posted', 'bank_reconciliation_adjustment', ['public_id','transaction_public_id','adjustment_type','currency','amount_minor','journal_public_id','candidate_public_id','match_event_public_id','match_state','reason_code','occurred_at']),
            'ledger.banking.account.register' => self::definition('ledger.banking.account.registered', 'financial_account', ['public_id','account_public_id','kind','currency','label']),
            'ledger.banking.transfer.post' => self::definition('ledger.banking.transfer.posted', 'banking_movement', ['public_id','movement_type','movement_public_id','source_account_public_id','destination_account_public_id','currency','amount_minor','fee_minor','journal_public_id','occurred_at']),
            'ledger.banking.clearing.settle' => self::definition('ledger.banking.clearing.settled', 'banking_movement', ['public_id','movement_type','movement_public_id','source_account_public_id','destination_account_public_id','currency','amount_minor','journal_public_id','occurred_at']),
            'ledger.banking.credit_card.payment.post' => self::definition('ledger.banking.credit_card.payment_posted', 'banking_movement', ['public_id','movement_type','movement_public_id','source_account_public_id','destination_account_public_id','currency','amount_minor','fee_minor','journal_public_id','occurred_at']),
            'ledger.tax.gst_snapshot.prepare' => self::definition('ledger.tax.gst_snapshot.prepared', 'gst_tax_snapshot', ['public_id','period_key','version','period_start','period_end','reporting_method','accounting_basis','currency','status','g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','net_gst_payable_minor','source_fingerprint','snapshot_hash','lodgement_ready','supersedes_public_id','prepared_at']),
            'ledger.tax.gst_snapshot.finalize' => self::definition('ledger.tax.gst_snapshot.finalized', 'gst_tax_snapshot', ['public_id','period_key','version','status','g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','net_gst_payable_minor','snapshot_hash','lodgement_ready','finalized_at']),
            'ledger.tax.gst_snapshot.supersede' => self::definition('ledger.tax.gst_snapshot.superseded', 'gst_tax_snapshot', ['public_id','period_key','version','status','snapshot_hash','supersedes_public_id','supersession_reason_code','lodgement_ready','prepared_at']),
            'ledger.tax.gst_adjustment.record' => self::definition('ledger.tax.gst_adjustment.recorded', 'gst_tax_adjustment', ['public_id','period_key','adjustment_type','effective_date','gross_amount_minor','gst_amount_minor','journal_public_id','reason_code','fact_hash','review_status']),
            'ledger.tax.gst_adjustment.review' => self::definition('ledger.tax.gst_adjustment.reviewed', 'gst_tax_adjustment_review', ['public_id','adjustment_public_id','decision','reason_code','reviewed_by_user_id','reviewed_at']),
            'ledger.tax.gst_snapshot.amend' => self::definition('ledger.tax.gst_snapshot.amended', 'gst_tax_snapshot', ['public_id','period_key','version','status','snapshot_hash','supersedes_public_id','supersession_reason_code','lodgement_ready','prepared_at']),
            'ledger.reporting.snapshot.prepare' => self::definition('ledger.reporting.snapshot.prepared', 'financial_report_snapshot', ['public_id','snapshot_key','version','report_type','period_start','period_end','currency','status','balanced','complete','source_fingerprint','report_hash','supersedes_public_id','prepared_at']),
            'ledger.reporting.snapshot.finalize' => self::definition('ledger.reporting.snapshot.finalized', 'financial_report_snapshot', ['public_id','snapshot_key','version','report_type','period_start','period_end','currency','status','balanced','complete','source_fingerprint','report_hash','finalized_at']),
            'ledger.reporting.snapshot.supersede' => self::definition('ledger.reporting.snapshot.superseded', 'financial_report_snapshot', ['public_id','snapshot_key','version','report_type','period_start','period_end','currency','status','balanced','complete','source_fingerprint','report_hash','supersedes_public_id','supersession_reason_code','prepared_at']),
            'ledger.forecast.snapshot.prepare' => self::definition('ledger.forecast.snapshot.prepared', 'forecast_snapshot', ['public_id','snapshot_key','version','snapshot_type','as_of_date','horizon_days','currency','status','evidence_coverage_bps','confidence_band','complete','source_fingerprint','forecast_hash','supersedes_public_id','prepared_at']),
            'ledger.forecast.snapshot.finalize' => self::definition('ledger.forecast.snapshot.finalized', 'forecast_snapshot', ['public_id','snapshot_key','version','snapshot_type','as_of_date','horizon_days','currency','status','evidence_coverage_bps','confidence_band','complete','source_fingerprint','forecast_hash','finalized_at']),
            'ledger.forecast.snapshot.supersede' => self::definition('ledger.forecast.snapshot.superseded', 'forecast_snapshot', ['public_id','snapshot_key','version','snapshot_type','as_of_date','horizon_days','currency','status','evidence_coverage_bps','confidence_band','complete','source_fingerprint','forecast_hash','supersedes_public_id','supersession_reason_code','prepared_at']),
        ];
    }

    /** @return array{event_type:string,schema_version:int,subject_type:string,safe_result_fields:array<int,string>}|null */
    public static function forCommand(string $commandName): ?array
    {
        return self::all()[$commandName] ?? null;
    }

    /** @return array{event_type:string,schema_version:int,subject_type:string,safe_result_fields:array<int,string>} */
    private static function definition(string $eventType, string $subjectType, array $safeResultFields): array
    {
        return [
            'event_type' => $eventType,
            'schema_version' => 1,
            'subject_type' => $subjectType,
            'safe_result_fields' => $safeResultFields,
        ];
    }
}
