<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Banking;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class FinancialAccountRegistryService
{
    private const KINDS=['bank','credit_card','clearing'];
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext){}
    public function register(int $userId,string $accountPublicId,array $payload,string $operationId): array{$companyId=$this->companyContext->companyId($userId);$kind=strtolower(trim((string)($payload['kind']??'')));if(!in_array($kind,self::KINDS,true))throw new InvalidArgumentException('Unsupported financial account kind.');$currency=strtoupper(trim((string)($payload['currency']??'AUD')));if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Financial account currency must be ISO-4217 style.');return $this->db->transaction(function()use($companyId,$userId,$accountPublicId,$kind,$currency,$operationId,$payload){$account=$this->ledgerAccount($companyId,$accountPublicId,true);$this->assertCompatible($account,$kind);$existing=$this->db->table('titan_ledger_financial_accounts')->where('company_id',$companyId)->where('account_public_id',$accountPublicId)->lockForUpdate()->first();if($existing){if((string)$existing->kind!==$kind||(string)$existing->currency!==$currency)throw new InvalidArgumentException('Financial account is already registered with different immutable classification.');return (array)$existing;}$row=['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'account_public_id'=>$accountPublicId,'kind'=>$kind,'currency'=>$currency,'label'=>$this->nullable($payload['label']??null,120),'external_reference_hash'=>$this->hashReference($payload['external_reference']??null),'registration_operation_id'=>$operationId,'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now()];$this->db->table('titan_ledger_financial_accounts')->insert($row);return $row;});}
    public function all(int $userId): array{$companyId=$this->companyContext->companyId($userId);return $this->db->table('titan_ledger_financial_accounts')->where('company_id',$companyId)->orderBy('kind')->orderBy('id')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();}
    public function requireKind(int $companyId,string $accountPublicId,array $allowed,bool $lock=false): object{$q=$this->db->table('titan_ledger_financial_accounts')->where('company_id',$companyId)->where('account_public_id',$accountPublicId);if($lock)$q->lockForUpdate();$row=$q->first();if(!$row||!in_array((string)$row->kind,$allowed,true))throw new InvalidArgumentException('Financial account is not registered for required kind: '.implode('|',$allowed).'.');return $row;}
    public function assertLedgerAccountCurrency(int $companyId,string $accountPublicId,string $currency): void{$r=$this->requireKind($companyId,$accountPublicId,['bank','credit_card','clearing']);if((string)$r->currency!==$currency)throw new InvalidArgumentException('Financial account currency does not match movement currency.');}
    private function ledgerAccount(int $companyId,string $id,bool $lock): object{$q=$this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->where('public_id',$id);if($lock)$q->lockForUpdate();$row=$q->first();if(!$row||(bool)$row->is_active!==true)throw new InvalidArgumentException('Financial Ledger account not found or inactive.');return $row;}
    private function assertCompatible(object $a,string $kind): void{if($kind==='credit_card'&&((string)$a->type!=='liability'||(string)$a->subtype!=='credit_card'))throw new InvalidArgumentException('Credit-card registry entries require an active credit_card liability account.');if(in_array($kind,['bank','clearing'],true)&&(string)$a->type!=='asset')throw new InvalidArgumentException('Bank and clearing registry entries require active asset accounts.');}
    private function nullable(mixed $v,int $max): ?string{$v=trim((string)($v??''));if($v==='')return null;if(strlen($v)>$max)throw new InvalidArgumentException('Financial account label too long.');return $v;}
    private function hashReference(mixed $v): ?string{$v=trim((string)($v??''));return $v===''?null:hash('sha256',strtolower(preg_replace('/\s+/',' ',$v)??$v));}
}
