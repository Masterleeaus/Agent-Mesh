<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

use DateTimeImmutable;

final class ReconciliationMatcher
{
    /** @param array<string,mixed> $transaction @param array<int,array<string,mixed>> $candidates @return array<string,mixed> */
    public static function match(array $transaction,array $candidates): array
    {
        $scored=[];$amount=(int)($transaction['amount_minor']??0);$posted=(string)($transaction['posted_on']??'');$ref=$transaction['reference_hash']??null;
        foreach($candidates as $candidate){
            if((int)($candidate['amount_minor']??PHP_INT_MIN)!==$amount)continue;
            $candidateId=trim((string)($candidate['candidate_public_id']??''));if($candidateId==='')continue;
            $score=50;$candidateDate=(string)($candidate['occurred_on']??'');$days=self::daysBetween($posted,$candidateDate);
            if($days===0)$score+=30;elseif($days<=1)$score+=20;elseif($days<=3)$score+=10;else continue;
            $candidateRef=$candidate['reference_hash']??null;if(is_string($ref)&&$ref!==''&&is_string($candidateRef)&&$candidateRef!==''&&hash_equals($ref,$candidateRef))$score+=50;
            if($score<70)continue;
            $scored[]=['candidate_public_id'=>$candidateId,'source_type'=>(string)($candidate['source_type']??'journal'),'score'=>$score];
        }
        if($scored===[])return ['status'=>'unmatched','candidate_public_id'=>null,'candidate_public_ids'=>[],'score'=>0];
        usort($scored,fn($a,$b)=>$b['score']<=>$a['score']?:strcmp($a['candidate_public_id'],$b['candidate_public_id']));$top=$scored[0]['score'];$topRows=array_values(array_filter($scored,fn($r)=>$r['score']===$top));
        if(count($topRows)>1)return ['status'=>'ambiguous','candidate_public_id'=>null,'candidate_public_ids'=>array_column($topRows,'candidate_public_id'),'score'=>$top];
        return ['status'=>'suggested','candidate_public_id'=>$topRows[0]['candidate_public_id'],'candidate_public_ids'=>[$topRows[0]['candidate_public_id']],'source_type'=>$topRows[0]['source_type'],'score'=>$top];
    }
    private static function daysBetween(string $a,string $b): int{try{$da=new DateTimeImmutable($a);$db=new DateTimeImmutable($b);}catch(\Throwable){return PHP_INT_MAX;}return (int)$da->diff($db)->days;}
}
