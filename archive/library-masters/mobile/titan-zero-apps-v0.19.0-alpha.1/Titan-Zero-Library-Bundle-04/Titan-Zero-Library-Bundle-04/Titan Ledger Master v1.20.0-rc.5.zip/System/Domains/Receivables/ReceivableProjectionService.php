<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Receivables;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ReceivableProjectionService
{
    public function __construct(private ConnectionInterface $db) {}

    /** @return array<string,mixed> */
    public function refresh(int $companyId,string $invoicePublicId,?string $asOfDate=null): array
    {
        if($companyId<1||trim($invoicePublicId)==='') throw new InvalidArgumentException('Receivable projection requires company and invoice identity.');
        $invoice=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','invoice')->where('document_public_id',$invoicePublicId)->first();
        if(!$invoice) throw new InvalidArgumentException('Receivable projection requires a posted CRM invoice.');
        $credits=(int)$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','credit_note')->where('invoice_public_id',$invoicePublicId)->sum('total_minor');
        $payments=$refunds=$overpayments=$overpaymentRefunds=0;
        $settlements=$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('invoice_public_id',$invoicePublicId)->limit(10000)->get();
        foreach($settlements as $s){
            if((string)$s->settlement_type==='payment'){$payments+=(int)$s->allocation_minor;$overpayments+=(int)$s->overpayment_minor;}
            elseif((string)$s->settlement_type==='refund'){$refunds+=(int)$s->allocation_minor;$overpaymentRefunds+=(int)$s->overpayment_minor;}
        }
        $balance=ReceivableBalanceCalculator::calculate((int)$invoice->total_minor,$credits,$payments,$refunds,$overpayments,$overpaymentRefunds);
        $asOfDate=$asOfDate?:Carbon::now('Australia/Melbourne')->toDateString();
        $aging=ReceivableAgingPolicy::classify(isset($invoice->due_at)&&$invoice->due_at!==null?(string)$invoice->due_at:null,$asOfDate,$balance['outstanding_minor']);
        $existing=$this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->where('invoice_public_id',$invoicePublicId)->first();
        $projectionHash=hash('sha256',json_encode([$invoicePublicId,(int)$invoice->total_minor,$credits,$payments,$refunds,$overpayments,$overpaymentRefunds,$invoice->due_at??null,$asOfDate],JSON_THROW_ON_ERROR));
        $row=[
            'company_id'=>$companyId,'invoice_public_id'=>$invoicePublicId,'invoice_number'=>$invoice->invoice_number??null,'currency'=>(string)$invoice->currency,
            'issued_at'=>$invoice->issued_at,'due_at'=>$invoice->due_at??null,'invoice_total_minor'=>(int)$invoice->total_minor,'credits_minor'=>$credits,
            'payments_minor'=>$payments,'refunds_minor'=>$refunds,'outstanding_minor'=>$balance['outstanding_minor'],'receivable_credit_minor'=>$balance['receivable_credit_minor'],'customer_credit_minor'=>$balance['customer_credit_minor'],
            'financial_state'=>$balance['outstanding_minor']===0?'settled':'open','aging_bucket'=>$aging['bucket'],'days_past_due'=>$aging['days_past_due'],'is_overdue'=>$aging['is_overdue']?1:0,
            'projection_hash'=>$projectionHash,'updated_at'=>now(),
        ];
        if($existing){$this->db->table('titan_ledger_receivables')->where('id',$existing->id)->update($row);$row['public_id']=(string)$existing->public_id;$row['collection_state']=(string)$existing->collection_state;$row['next_action_at']=$existing->next_action_at??null;$row['last_action_at']=$existing->last_action_at??null;$row['last_action_type']=$existing->last_action_type??null;}
        else{$row['public_id']=(string)Str::ulid();$row['collection_state']='normal';$row['created_at']=now();$this->db->table('titan_ledger_receivables')->insert($row);}
        return $row;
    }

    public function refreshAll(int $companyId,int $limit=1000): void
    {
        $ids=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','invoice')->orderBy('id')->limit(max(1,min($limit,5000)))->pluck('document_public_id');
        foreach($ids as $id)$this->refresh($companyId,(string)$id);
    }
}
