<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Signal;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Schema;
use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use InvalidArgumentException;
use Throwable;

final class LedgerSignalOutboxService
{
    private const TABLE = 'titan_ledger_signal_outbox';

    public function __construct(private ConnectionInterface $db, private LedgerSignalGatewayContract $gateway, private LedgerCompanyContext $companyContext) {}

    /** @param array<string,mixed> $command @param array<string,mixed> $result @param array<string,mixed> $domainReceipt */
    public function recordApplied(array $command, array $result, array $domainReceipt): array
    {
        $reference = trim((string) ($domainReceipt['domain_receipt_reference'] ?? ''));
        $fingerprint = trim((string) ($domainReceipt['write_fingerprint'] ?? ''));
        if ($reference === '' || $fingerprint === '' || ($domainReceipt['write_verified'] ?? false) !== true) {
            throw new InvalidArgumentException('Verified Ledger domain receipt is required before emitting a financial event.');
        }

        $envelope = LedgerSignalEnvelope::fromAppliedCommand($command, $result, $reference, $fingerprint, now()->toAtomString());
        $encoded = json_encode($envelope, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        try {
            $this->db->table(self::TABLE)->insert([
                'signal_id' => $envelope['signal_id'],
                'event_type' => $envelope['event_type'],
                'schema_version' => $envelope['schema_version'],
                'company_id' => $envelope['company_id'],
                'actor_user_id' => $envelope['actor_user_id'],
                'command_id' => $envelope['command_id'],
                'domain_receipt_reference' => $reference,
                'risk_reference' => $envelope['risk_reference'] ?? null,
                'risk_class' => $envelope['risk_class'] ?? null,
                'risk_score' => $envelope['risk_score'] ?? null,
                'risk_ruleset_version' => $envelope['risk_ruleset_version'] ?? null,
                'assurance_reference' => $envelope['assurance_reference'] ?? null,
                'assurance_class' => $envelope['assurance_class'] ?? null,
                'assurance_score' => $envelope['assurance_score'] ?? null,
                'assurance_ruleset_version' => $envelope['assurance_ruleset_version'] ?? null,
                'subject_type' => $envelope['subject_type'],
                'subject_public_id' => $envelope['subject_public_id'],
                'trace_id' => $envelope['trace_id'],
                'correlation_id' => $envelope['correlation_id'],
                'causation_id' => $envelope['causation_id'],
                'payload_hash' => $envelope['payload_hash'],
                'envelope_json' => $encoded,
                'status' => 'pending',
                'attempt_count' => 0,
                'next_attempt_at' => now(),
                'occurred_at' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } catch (QueryException $e) {
            $existing = $this->db->table(self::TABLE)->where('signal_id', $envelope['signal_id'])->first();
            if (!$existing || !hash_equals((string)$existing->payload_hash, (string)$envelope['payload_hash'])) throw $e;
        }

        return $envelope;
    }

    /** @return array<int,array<string,mixed>> */
    public function all(int $userId, int $limit = 200): array
    {
        if (!Schema::hasTable(self::TABLE)) return [];
        $companyId = $this->companyContext->companyId($userId);
        return $this->db->table(self::TABLE)
            ->where('company_id', $companyId)
            ->orderByDesc('id')
            ->limit(max(1, min($limit, 500)))
            ->limit(10000)->get()
            ->map(static fn ($row) => (array) $row)
            ->all();
    }

    public function deliverSignal(string $signalId): bool
    {
        $signalId = trim($signalId);
        if ($signalId === '' || !$this->gateway->available()) return false;
        $row = $this->db->table(self::TABLE)->where('signal_id', $signalId)->first();
        if (!$row) return false;
        if ((string)$row->status === 'delivered') return true;
        if (!in_array((string)$row->status, ['pending','retry'], true)) return false;
        try {
            return $this->deliverRow((array)$row);
        } catch (Throwable $e) {
            $this->markRetry((array)$row, class_basename($e));
            return false;
        }
    }

    /** @return array{attempted:int,delivered:int,failed:int,pending:int,gateway_available:bool} */
    public function drain(int $limit = 100): array
    {
        $limit = max(1, min($limit, 500));
        if (!$this->gateway->available()) {
            return ['attempted'=>0,'delivered'=>0,'failed'=>0,'pending'=>$this->pendingCount(),'gateway_available'=>false];
        }

        $rows = $this->db->table(self::TABLE)
            ->whereIn('status', ['pending','retry'])
            ->where(function ($q): void { $q->whereNull('next_attempt_at')->orWhere('next_attempt_at', '<=', now()); })
            ->orderBy('id')
            ->limit($limit)
            ->limit(10000)->get();

        $attempted = $delivered = $failed = 0;
        foreach ($rows as $row) {
            $attempted++;
            try {
                if ($this->deliverRow((array)$row)) $delivered++;
            } catch (Throwable $e) {
                $failed++;
                $this->markRetry((array)$row, class_basename($e));
            }
        }
        return ['attempted'=>$attempted,'delivered'=>$delivered,'failed'=>$failed,'pending'=>$this->pendingCount(),'gateway_available'=>true];
    }

    public function pendingCount(): int
    {
        if (!Schema::hasTable(self::TABLE)) return 0;
        return (int)$this->db->table(self::TABLE)->whereIn('status', ['pending','retry'])->count();
    }

    /** @return array<string,mixed> */
    public function diagnostics(): array
    {
        if (!Schema::hasTable(self::TABLE)) return ['gateway_available'=>$this->gateway->available(),'pending'=>0,'failed_terminal'=>0,'delivered'=>0,'outbox_ready'=>false];
        return [
            'outbox_ready' => true,
            'gateway_available' => $this->gateway->available(),
            'pending' => $this->pendingCount(),
            'failed_terminal' => (int)$this->db->table(self::TABLE)->where('status', 'failed')->count(),
            'delivered' => (int)$this->db->table(self::TABLE)->where('status', 'delivered')->count(),
        ];
    }

    /** @param array<string,mixed> $row */
    private function deliverRow(array $row): bool
    {
        $id = (int)($row['id'] ?? 0);
        if ($id < 1) throw new InvalidArgumentException('Signal outbox row id is invalid.');

        $claimed = $this->db->table(self::TABLE)
            ->where('id', $id)
            ->whereIn('status', ['pending','retry'])
            ->update(['status'=>'delivering','attempt_count'=>((int)($row['attempt_count'] ?? 0))+1,'last_attempt_at'=>now(),'updated_at'=>now()]);
        if ($claimed !== 1) return false;

        $envelope = json_decode((string)($row['envelope_json'] ?? ''), true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($envelope) || !hash_equals((string)$row['payload_hash'], (string)($envelope['payload_hash'] ?? ''))) {
            $this->db->table(self::TABLE)->where('id', $id)->where('status','delivering')->update([
                'status'=>'failed','last_error_code'=>'PAYLOAD_INTEGRITY_FAILURE','next_attempt_at'=>null,'updated_at'=>now(),
            ]);
            throw new InvalidArgumentException('Ledger Signal outbox payload integrity failure.');
        }

        $receipt = $this->gateway->publish($envelope);
        $receiptJson = json_encode($receipt, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $updated = $this->db->table(self::TABLE)->where('id', $id)->where('status','delivering')->update([
            'status'=>'delivered','delivery_receipt_json'=>$receiptJson,'delivered_at'=>now(),'next_attempt_at'=>null,'last_error_code'=>null,'updated_at'=>now(),
        ]);
        if ($updated !== 1) throw new InvalidArgumentException('Ledger Signal outbox could not transition to delivered.');
        return true;
    }

    /** @param array<string,mixed> $row */
    private function markRetry(array $row, string $errorCode): void
    {
        $attempts = ((int)($row['attempt_count'] ?? 0)) + 1;
        $terminal = $attempts >= 10;
        $delaySeconds = min(3600, 30 * (2 ** min(7, max(0, $attempts - 1))));
        $this->db->table(self::TABLE)->where('id', (int)$row['id'])->where('status','delivering')->update([
            'status' => $terminal ? 'failed' : 'retry',
            'last_error_code' => substr($errorCode, 0, 120),
            'next_attempt_at' => $terminal ? null : now()->addSeconds($delaySeconds),
            'updated_at' => now(),
        ]);
    }
}
