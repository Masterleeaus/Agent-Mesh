<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

use DateTimeImmutable;
use InvalidArgumentException;

final class CashflowForecastCalculator
{
    /** @param array<int,array<string,mixed>> $rows @return array<int,array<string,int|string>> */
    public function journalMovements(array $rows): array
    {
        $out=[];
        foreach($rows as $row){
            $net=(int)($row['debit_minor']??0)-(int)($row['credit_minor']??0);
            $out[]=['occurred_on'=>(string)($row['occurred_on']??''),'inflow_minor'=>$net>0?$net:0,'outflow_minor'=>$net<0?abs($net):0];
        }
        return $out;
    }

    /** @param array<int,array<string,mixed>> $rows */
    public function actual(array $rows): array
    {
        $in=0;$out=0;
        foreach($rows as $row){$i=max(0,(int)($row['inflow_minor']??0));$o=max(0,(int)($row['outflow_minor']??0));$in+=$i;$out+=$o;}
        return ['inflow_minor'=>$in,'outflow_minor'=>$out,'net_cashflow_minor'=>$in-$out];
    }

    /**
     * @param array<int,array<string,mixed>> $receivables
     * @param array<int,array<string,mixed>> $payables
     */
    public function forecast(int $openingCashMinor,array $receivables,array $payables,string $asOf,int $horizonDays=90): array
    {
        if($horizonDays<1||$horizonDays>366)throw new InvalidArgumentException('Forecast horizon must be between 1 and 366 days.');
        $start=new DateTimeImmutable($asOf);$end=$start->modify('+'.$horizonDays.' days');
        $in=0;$out=0;$excludedIn=0;$excludedOut=0;$known=0;$total=0;$schedule=[];
        foreach($receivables as $row){$amount=max(0,(int)($row['outstanding_minor']??0));if($amount===0)continue;$total+=$amount;$date=$this->dateOrNull($row['due_at']??null);if($date===null||$date>$end){$excludedIn+=$amount;continue;}$known+=$amount;$in+=$amount;$effective=$date<$start?$start:$date;$key=$effective->format('Y-m-d');$schedule[$key]['inflow_minor']=($schedule[$key]['inflow_minor']??0)+$amount;}
        foreach($payables as $row){$amount=max(0,(int)($row['outstanding_minor']??0));if($amount===0)continue;$total+=$amount;$date=$this->dateOrNull($row['due_at']??null);if($date===null||$date>$end){$excludedOut+=$amount;continue;}$known+=$amount;$out+=$amount;$effective=$date<$start?$start:$date;$key=$effective->format('Y-m-d');$schedule[$key]['outflow_minor']=($schedule[$key]['outflow_minor']??0)+$amount;}
        ksort($schedule,SORT_STRING);$running=$openingCashMinor;$minimum=$running;$timeline=[];
        foreach($schedule as $date=>$flow){$fi=(int)($flow['inflow_minor']??0);$fo=(int)($flow['outflow_minor']??0);$running+=$fi-$fo;$minimum=min($minimum,$running);$timeline[]=['date'=>$date,'inflow_minor'=>$fi,'outflow_minor'=>$fo,'closing_cash_minor'=>$running];}
        $coverage=$total===0?10000:(int)round(($known/$total)*10000);
        return [
            'as_of'=>$start->format('Y-m-d'),'horizon_days'=>$horizonDays,'horizon_end'=>$end->format('Y-m-d'),
            'opening_cash_minor'=>$openingCashMinor,'expected_inflows_minor'=>$in,'expected_outflows_minor'=>$out,
            'closing_cash_minor'=>$openingCashMinor+$in-$out,'minimum_projected_cash_minor'=>$minimum,
            'excluded_receivables_minor'=>$excludedIn,'excluded_payables_minor'=>$excludedOut,
            'evidence_coverage_bps'=>$coverage,'confidence_band'=>$this->band($coverage),'schedule'=>$timeline,
            'forecast_semantics'=>'nominal_due_date_schedule_not_probability_weighted',
        ];
    }

    public function runway(int $openingCashMinor,int $trailingNetCashflowMinor,int $trailingDays): array
    {
        if($trailingDays<1)throw new InvalidArgumentException('Trailing days must be positive.');
        if($trailingNetCashflowMinor>=0)return ['basis'=>'trailing_net_cash_movement','trailing_days'=>$trailingDays,'average_daily_burn_minor'=>0,'runway_days'=>null];
        $burn=(int)ceil(abs($trailingNetCashflowMinor)/$trailingDays);
        return ['basis'=>'trailing_net_cash_movement','trailing_days'=>$trailingDays,'average_daily_burn_minor'=>$burn,'runway_days'=>$burn===0?null:(int)floor(max(0,$openingCashMinor)/$burn)];
    }

    private function band(int $bps): string{return $bps>=9000?'HIGH':($bps>=7000?'MEDIUM':($bps>=5000?'MODERATE':'LOW'));}
    private function dateOrNull(mixed $value): ?DateTimeImmutable{if(!is_string($value)||trim($value)==='')return null;try{return new DateTimeImmutable(substr(trim($value),0,10));}catch(\Throwable){return null;}}
}
