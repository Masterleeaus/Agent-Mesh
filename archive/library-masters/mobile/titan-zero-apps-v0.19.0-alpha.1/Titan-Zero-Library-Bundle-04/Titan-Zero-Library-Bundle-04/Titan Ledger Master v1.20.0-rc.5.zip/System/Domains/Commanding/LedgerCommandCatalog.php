<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Commanding;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandDefinitionRegistry;

if (! class_exists(LedgerCommandDefinitionRegistry::class, false)) {
    require_once dirname(__DIR__, 2) . '/CommandBus/LedgerCommandDefinitionRegistry.php';
}

final class LedgerCommandCatalog
{
    public static function permissions(): array
    {
        $permissions = [];
        foreach (LedgerCommandDefinitionRegistry::all() as $name => $definition) $permissions[$name] = (string) $definition['permission'];
        return $permissions;
    }

    public static function permissionFor(string $commandName): ?string
    {
        return self::permissions()[$commandName] ?? null;
    }

    public static function supports(string $commandName): bool
    {
        return LedgerCommandDefinitionRegistry::supports($commandName);
    }
}
