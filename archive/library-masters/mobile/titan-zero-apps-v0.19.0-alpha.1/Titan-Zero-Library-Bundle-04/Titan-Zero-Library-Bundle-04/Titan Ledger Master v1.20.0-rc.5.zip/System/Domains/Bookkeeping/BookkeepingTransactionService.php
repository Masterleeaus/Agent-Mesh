<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Bookkeeping;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class BookkeepingTransactionService
{
    public function __construct(private ConnectionInterface $db, private BookkeepingGstCalculator $gst, private LedgerCompanyContext $companyContext) {}

    public function search(int $userId,array $filters=[],int $limit=200): array
    {
        $q=$this->db->table('crm_bookkeeping_transactions')->where('company_id',$this->companyContext->companyId($userId))->whereNull('deleted_at');
        foreach(['type','category_public_id','work_order_public_id','source_domain','currency'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]);
        if(!empty($filters['from']))$q->whereDate('transaction_date','>=',$filters['from']); if(!empty($filters['to']))$q->whereDate('transaction_date','<=',$filters['to']);
        return $q->orderByDesc('transaction_date')->orderByDesc('id')->limit(min(max($limit,1),500))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function create(int $userId,array $data): array
    {
        $type=$this->type((string)($data['type']??'')); $description=trim((string)($data['description']??'')); if($description==='')throw new InvalidArgumentException('Bookkeeping description is required.');
        $amount=(int)($data['amount_minor']??0); if($amount<1)throw new InvalidArgumentException('Bookkeeping amount must be positive.');
        $treatment=(string)($data['gst_treatment']??'gst_free'); $calc=$this->gst->calculate($amount,$treatment,(int)($data['gst_rate_bps']??1000));
        $data['source_domain']='manual'; return $this->persist($userId,$data,$type,$description,$calc);
    }

    public function upsertSource(int $userId,string $sourceDomain,string $sourceType,string $sourcePublicId,?string $sourceEventId,array $data): array
    {
        $sourceDomain=trim($sourceDomain);$sourceType=trim($sourceType);$sourcePublicId=trim($sourcePublicId);
        if($sourceDomain===''||$sourceType===''||$sourcePublicId==='')throw new InvalidArgumentException('Source domain, type and public id are required.');
        $sourceKey=$sourceDomain.':'.($sourceEventId!==null&&$sourceEventId!==''?'event:'.$sourceEventId:$sourceType.':'.$sourcePublicId);
        $companyId=$this->companyContext->companyId($userId);
        if($existing=$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('source_key',$sourceKey)->whereNull('deleted_at')->first())return (array)$existing;
        $type=$this->type((string)($data['type']??''));$description=trim((string)($data['description']??''));if($description==='')throw new InvalidArgumentException('Bookkeeping description is required.');
        $amount=(int)($data['amount_minor']??0);if($amount<1)throw new InvalidArgumentException('Bookkeeping amount must be positive.');
        $calc=$this->gst->calculate($amount,(string)($data['gst_treatment']??'gst_free'),(int)($data['gst_rate_bps']??1000));
        return $this->persist($userId,$data+['source_domain'=>$sourceDomain,'source_type'=>$sourceType,'source_public_id'=>$sourcePublicId,'source_event_id'=>$sourceEventId,'source_key'=>$sourceKey],$type,$description,$calc);
    }

    public function updateManual(int $userId,string $publicId,array $data): array
    {
        $companyId=$this->companyContext->companyId($userId);$row=$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$row)throw new InvalidArgumentException('Bookkeeping transaction not found.'); if((string)$row->source_domain!=='manual')throw new InvalidArgumentException('Domain-derived bookkeeping entries cannot be edited manually.');
        $type=$this->type((string)($data['type']??$row->type));$description=trim((string)($data['description']??$row->description)); if($description==='')throw new InvalidArgumentException('Bookkeeping description is required.');

        // Metadata-only edits preserve exact stored money; GST-definition changes require an explicit new amount.
        $calc=$this->gst->calculateUpdate((int)$row->amount_ex_gst_minor,(int)$row->gst_minor,(int)$row->amount_inc_gst_minor,(string)$row->gst_treatment,(int)$row->gst_rate_bps,$data);

        $category=$data['category_public_id']??$row->category_public_id;$this->assertCategory($companyId,$type,$category);
        $updates=['type'=>$type,'description'=>$description,'category_public_id'=>$category,'transaction_date'=>$data['transaction_date']??$row->transaction_date,'payee_name'=>$data['payee_name']??$row->payee_name,'reference'=>$data['reference']??$row->reference,'payment_method'=>$data['payment_method']??$row->payment_method,'notes'=>$data['notes']??$row->notes,'amount_ex_gst_minor'=>$calc['amount_ex_gst_minor'],'gst_minor'=>$calc['gst_minor'],'amount_inc_gst_minor'=>$calc['amount_inc_gst_minor'],'gst_treatment'=>$calc['gst_treatment'],'gst_rate_bps'=>$calc['gst_rate_bps'],'updated_at'=>now()];
        $this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->update($updates);
        return (array)$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->first();
    }

    public function deleteManual(int $userId,string $publicId): void
    {
        $companyId=$this->companyContext->companyId($userId);$row=$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$row)throw new InvalidArgumentException('Bookkeeping transaction not found.'); if((string)$row->source_domain!=='manual')throw new InvalidArgumentException('Domain-derived bookkeeping entries cannot be deleted manually.');
        $this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->update(['deleted_at'=>now(),'updated_at'=>now()]);
    }

    private function persist(int $userId,array $data,string $type,string $description,array $calc): array
    {
        $companyId=$this->companyContext->companyId($userId);$category=$data['category_public_id']??null;$this->assertCategory($companyId,$type,$category);$publicId=(string)Str::ulid();
        $this->db->table('crm_bookkeeping_transactions')->insert([
            'public_id'=>$publicId,'company_id'=>$companyId,'type'=>$type,'category_public_id'=>$category,'transaction_date'=>$data['transaction_date']??now()->toDateString(),
            'work_order_public_id'=>$data['work_order_public_id']??null,'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'document_public_id'=>$data['document_public_id']??null,
            'payee_name'=>$data['payee_name']??null,'description'=>$description,'reference'=>$data['reference']??null,'amount_ex_gst_minor'=>$calc['amount_ex_gst_minor'],'gst_minor'=>$calc['gst_minor'],'amount_inc_gst_minor'=>$calc['amount_inc_gst_minor'],'gst_treatment'=>$calc['gst_treatment'],'gst_rate_bps'=>$calc['gst_rate_bps'],
            'currency'=>strtoupper((string)($data['currency']??config('crm.settings.defaults.default_currency','AUD'))),'payment_method'=>$data['payment_method']??null,'source_domain'=>$data['source_domain']??'manual','source_type'=>$data['source_type']??null,'source_public_id'=>$data['source_public_id']??null,'source_event_id'=>$data['source_event_id']??null,'source_key'=>$data['source_key']??null,
            'notes'=>$data['notes']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_bookkeeping_transactions')->where('company_id',$companyId)->where('public_id',$publicId)->first();
    }

    private function assertCategory(int $companyId,string $type,mixed $category): void
    {
        if($category===null||$category==='')return; if(!$this->db->table('crm_bookkeeping_categories')->where('company_id',$companyId)->where('public_id',$category)->where('type',$type)->where('is_active',true)->exists())throw new InvalidArgumentException('Bookkeeping category does not belong to this company/type.');
    }
    private function type(string $type):string{if(!in_array($type,['income','expense'],true))throw new InvalidArgumentException('Bookkeeping type must be income or expense.');return$type;}
}
