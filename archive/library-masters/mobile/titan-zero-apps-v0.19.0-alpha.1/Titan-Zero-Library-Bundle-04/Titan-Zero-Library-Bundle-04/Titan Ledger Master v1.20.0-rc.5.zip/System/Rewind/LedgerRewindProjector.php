<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Rewind;

final class LedgerRewindProjector
{
    public static function receipt(array $row): array
    {
        return self::finish(array_filter([
            'event_id'=>'tlr-receipt-'.(string)($row['public_id']??$row['id']??''), 'event_type'=>'ledger.command.'.strtolower((string)($row['status']??'observed')),
            'source'=>'titan-ledger.command-receipts','source_id'=>(string)($row['public_id']??''),'company_id'=>(int)($row['company_id']??0),
            'command_id'=>$row['command_id']??null,'command_name'=>$row['command_name']??null,'governance_reference'=>$row['governance_reference']??null,
            'risk_reference'=>$row['risk_reference']??null,'risk_class'=>$row['risk_class']??null,'assurance_reference'=>$row['assurance_reference']??null,'assurance_class'=>$row['assurance_class']??null,
            'domain_receipt_reference'=>$row['public_id']??null,'write_fingerprint'=>$row['write_fingerprint']??null,'write_verified'=>(bool)($row['write_verified']??false),
            'trace_id'=>$row['trace_id']??null,'correlation_id'=>$row['correlation_id']??null,'causation_id'=>$row['causation_id']??null,'occurred_at'=>$row['completed_at']??$row['created_at']??null,
            'authority_neutral'=>true,'write_policy'=>'read-only'
        ],static fn($v)=>$v!==null));
    }
    public static function signal(array $row): array
    {
        return self::finish(array_filter([
            'event_id'=>(string)($row['signal_id']??''),'event_type'=>$row['event_type']??'ledger.signal.observed','source'=>'titan-ledger.signal-outbox','source_id'=>(string)($row['signal_id']??''),
            'company_id'=>(int)($row['company_id']??0),'command_id'=>$row['command_id']??null,'command_name'=>$row['command_name']??null,'governance_reference'=>$row['governance_reference']??null,
            'risk_reference'=>$row['risk_reference']??null,'risk_class'=>$row['risk_class']??null,'assurance_reference'=>$row['assurance_reference']??null,'assurance_class'=>$row['assurance_class']??null,
            'domain_receipt_reference'=>$row['domain_receipt_reference']??null,'write_fingerprint'=>$row['write_fingerprint']??null,'subject_type'=>$row['subject_type']??null,'subject_public_id'=>$row['subject_public_id']??null,
            'trace_id'=>$row['trace_id']??null,'correlation_id'=>$row['correlation_id']??null,'causation_id'=>$row['causation_id']??null,'occurred_at'=>$row['occurred_at']??null,
            'authority_neutral'=>true,'write_policy'=>'read-only'
        ],static fn($v)=>$v!==null));
    }
    private static function finish(array $event): array { $event['source_record_hash']=hash('sha256',self::canonicalJson($event)); return $event; }
    private static function canonicalJson(array $v): string { return (string)json_encode(self::canonicalize($v),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); }
    private static function canonicalize(mixed $v): mixed { if(!is_array($v))return $v; if(array_is_list($v))return array_map([self::class,'canonicalize'],$v); ksort($v,SORT_STRING); foreach($v as $k=>$x)$v[$k]=self::canonicalize($x); return $v; }
}
