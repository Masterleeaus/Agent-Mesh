<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

use InvalidArgumentException;

final class ReconciliationAdjustmentJournalMapper
{
    /** @param array<string,string> $accounts @return array<int,array<string,mixed>> */
    public static function map(string $type,int $amountMinor,array $accounts): array
    {
        foreach(['bank','bank_fees','interest_income','interest_expense'] as $k)if(trim((string)($accounts[$k]??''))==='')throw new InvalidArgumentException('Required reconciliation adjustment account missing: '.$k.'.');
        return match($type){
            'bank_fee'=>self::negative($amountMinor,$accounts['bank_fees'],$accounts['bank'],'Bank fee'),
            'interest_expense'=>self::negative($amountMinor,$accounts['interest_expense'],$accounts['bank'],'Bank interest expense'),
            'interest_income'=>self::positive($amountMinor,$accounts['bank'],$accounts['interest_income'],'Bank interest income'),
            default=>throw new InvalidArgumentException('Unsupported reconciliation adjustment type.'),
        };
    }
    private static function negative(int $amount,string $debit,string $credit,string $label): array{if($amount>=0)throw new InvalidArgumentException($label.' requires a negative bank transaction.');$v=abs($amount);return [self::line($debit,$label,$v,0),self::line($credit,$label.' bank movement',0,$v)];}
    private static function positive(int $amount,string $debit,string $credit,string $label): array{if($amount<=0)throw new InvalidArgumentException($label.' requires a positive bank transaction.');return [self::line($debit,$label.' bank movement',$amount,0),self::line($credit,$label,0,$amount)];}
    private static function line(string $account,string $description,int $debit,int $credit): array{return ['account_public_id'=>$account,'description'=>$description,'debit_minor'=>$debit,'credit_minor'=>$credit,'tax_code'=>'gst_free','tax_amount_minor'=>0];}
}
