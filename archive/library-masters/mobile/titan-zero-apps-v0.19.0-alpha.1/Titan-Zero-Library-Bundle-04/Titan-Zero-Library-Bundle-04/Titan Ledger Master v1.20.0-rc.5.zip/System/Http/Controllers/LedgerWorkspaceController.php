<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandDefinitionRegistry;
use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\CommandBus\LedgerDomainReceiptService;
use App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodService;
use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseService;
use App\Extensions\TitanLedger\System\Navigation\MenuSyncService;
use App\Extensions\TitanLedger\System\Signal\LedgerFinancialEventCatalog;
use App\Extensions\TitanLedger\System\Signal\LedgerSignalOutboxService;
use App\Extensions\TitanLedger\System\Governance\LedgerGovernanceEvidenceService;
use App\Extensions\TitanLedger\System\Rewind\LedgerRewindSource;
use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceAccountingService;
use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementService;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableCollectionService;
use App\Extensions\TitanLedger\System\Domains\Payables\PayableProjectionService;
use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingService;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankReconciliationService;
use App\Extensions\TitanLedger\System\Domains\Banking\FinancialAccountRegistryService;
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxLedgerService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxAdjustmentService;
use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementService;
use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotService;
use App\Extensions\TitanLedger\System\Certification\LedgerProductionCertificationService;
use App\Extensions\TitanLedger\System\Certification\ProductionTriggerCatalog;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Schema;

final class LedgerWorkspaceController extends Controller
{
    public function __construct(
        private JournalService $journals,
        private ChartOfAccountsService $accounts,
        private AccountingPeriodService $periods,
        private FinancialYearCloseService $yearClose,
        private LedgerDomainReceiptService $receipts,
        private LedgerCommandSubmissionService $commands,
        private LedgerSignalOutboxService $signals,
        private LedgerGovernanceEvidenceService $governance,
        private LedgerRewindSource $rewind,
        private CrmInvoiceAccountingService $crmInvoices,
        private TitanPaySettlementService $payments,
        private ReceivableCollectionService $receivables,
        private PayableProjectionService $payables,
        private SpendAccountingService $spend,
        private BankReconciliationService $reconciliation,
        private FinancialAccountRegistryService $financialAccounts,
        private MultiAccountBankingService $banking,
        private GstTaxLedgerService $tax,
        private GstTaxAdjustmentService $taxAdjustments,
        private FinancialStatementService $reports,
        private FinancialReportSnapshotService $reportSnapshots,
        private CashflowForecastService $cashflow,
        private ProfitabilityService $profitability,
        private ForecastSnapshotService $forecastSnapshots,
        private MenuSyncService $menus,
        private LedgerProductionCertificationService $productionCertification,
    ) {}

    public function overview(Request $request)
    {
        $userId = (int) $request->user()->id;
        return $this->view('Titan Ledger Overview', 'Authoritative accounting, period controls and governed mutation readiness.', [
            ['label' => 'Accounts', 'value' => count($this->accounts->all($userId, false))],
            ['label' => 'Journals', 'value' => count($this->journals->all($userId))],
            ['label' => 'Financial Years', 'value' => count($this->periods->allYears($userId))],
            ['label' => 'Command Bus', 'value' => $this->commands->commandBusReady() ? 'Bound' : 'Unavailable'],
            ['label' => 'Signal Outbox', 'value' => $this->signals->pendingCount()],
        ]);
    }

    public function accounts(Request $request) { return $this->table('Chart of Accounts', 'Canonical company-scoped account catalogue.', $this->accounts->all((int) $request->user()->id, false), ['code','name','type','subtype','normal_balance','is_active']); }
    public function journals(Request $request) { return $this->table('Journals', 'Draft, validated and immutable posted journal entries.', $this->journals->all((int) $request->user()->id), ['public_id','entry_date','journal_type','status','memo']); }
    public function financialYears(Request $request) { return $this->table('Financial Years', 'Fiscal years and close state.', $this->periods->allYears((int) $request->user()->id), ['public_id','label','starts_on','ends_on','status','closed_at']); }
    public function yearEndClose(Request $request) { return $this->table('Year-End Close', 'Prepared and completed fiscal closes with immutable retained-earnings transfer evidence.', $this->yearClose->all((int)$request->user()->id,200), ['financial_year_public_id','version','status','currency','net_profit_minor','close_journal_public_id','source_fingerprint','prepared_at','closed_at']); }
    public function accountingPeriods(Request $request) { return $this->table('Accounting Periods', 'Open, soft-locked and hard-locked posting periods.', $this->periods->allPeriods((int) $request->user()->id), ['public_id','period_number','starts_on','ends_on','lock_state']); }
    public function commandReceipts(Request $request) { return $this->table('Command Receipts', 'Ledger-owned immutable authoritative domain execution evidence.', $this->receipts->all((int) $request->user()->id, 200), ['command_id','command_name','status','governance_reference','write_verified','completed_at']); }
    public function financialEvents(Request $request) { return $this->table('Financial Events', 'Durable company-scoped Ledger event outbox and Signal delivery state.', $this->signals->all((int) $request->user()->id, 200), ['signal_id','event_type','subject_type','subject_public_id','status','attempt_count','occurred_at','delivered_at']); }
    public function governanceEvidence(Request $request) { return $this->table('Governance Evidence', 'Immutable Risk and Assurance decision references attached to governed Ledger executions.', $this->receipts->all((int) $request->user()->id, 200), ['command_id','command_name','governance_reference','risk_reference','risk_class','assurance_reference','assurance_class','status','completed_at']); }
    public function invoiceAccounting(Request $request) { return $this->table('Invoice Accounting', 'CRM invoice and credit-note facts posted into immutable Ledger journals.', $this->crmInvoices->all((int)$request->user()->id,200), ['document_type','document_public_id','invoice_public_id','currency','subtotal_minor','tax_minor','total_minor','journal_public_id','issued_at']); }
    public function paymentSettlements(Request $request) { return $this->table('Payment Settlements', 'Titan Pay settlement and refund facts posted into immutable Ledger journals.', $this->payments->all((int)$request->user()->id,200), ['settlement_type','settlement_public_id','invoice_public_id','rail','currency','gross_amount_minor','fee_minor','cash_movement_minor','allocation_minor','overpayment_minor','journal_public_id','settled_at']); }
    public function payables(Request $request) { return $this->table('Payables', 'Supplier bill balances, aging, credits, payments and prepayments derived only from immutable Ledger spend evidence.', $this->payables->all((int)$request->user()->id,500), ['bill_public_id','supplier_public_id','currency','bill_total_minor','credits_minor','payments_minor','outstanding_minor','payable_credit_minor','supplier_prepayment_minor','due_at','aging_bucket','days_past_due','financial_state']); }
    public function receivables(Request $request) { return $this->table('Receivables', 'Invoice-level outstanding balances, aging and governed collection state derived only from Ledger accounting evidence.', $this->receivables->all((int)$request->user()->id,500), ['invoice_number','invoice_public_id','currency','invoice_total_minor','credits_minor','payments_minor','refunds_minor','outstanding_minor','receivable_credit_minor','customer_credit_minor','due_at','aging_bucket','days_past_due','collection_state','next_action_at']); }
    public function bankReconciliation(Request $request) { return $this->table('Bank Reconciliation', 'Imported bank statements, reconciliation sessions and statement-level balance evidence.', $this->reconciliation->statements((int)$request->user()->id,200), ['statement_public_id','account_public_id','currency','period_start','period_end','opening_balance_minor','closing_balance_minor','movement_minor','transaction_count','imported_at']); }
    public function bankingAccounts(Request $request) { return $this->table('Banking Accounts', 'Registered bank, credit-card and clearing accounts used by governed transfers, payouts and reconciliation.', $this->financialAccounts->all((int)$request->user()->id), ['account_public_id','kind','currency','label','created_at']); }
    public function reconciliationAutomation(Request $request) { return $this->table('Reconciliation Automation', 'Immutable group matches, split reconciliation and deterministic automation evidence.', $this->reconciliation->groups((int)$request->user()->id,200), ['public_id','session_public_id','group_type','bank_total_minor','ledger_total_minor','score','active','created_at']); }
    public function gstBas(Request $request) { return $this->table('GST and BAS', 'Versioned Simpler/Full BAS GST evidence prepared from immutable Ledger postings plus approved tax adjustments.', $this->tax->all((int)$request->user()->id,200), ['period_key','version','period_start','period_end','reporting_method','status','g1_total_sales_minor','g2_export_sales_minor','g3_gst_free_sales_minor','g10_capital_purchases_minor','g11_noncapital_purchases_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','net_gst_payable_minor','approved_adjustment_count','pending_adjustment_count','lodgement_ready','finalized_at']); }
    public function gstAdjustments(Request $request) { return $this->table('GST Adjustments', 'Immutable GST adjustment facts with append-only accountant review evidence. Pending adjustments block BAS finalization.', $this->taxAdjustments->all((int)$request->user()->id,500), ['period_key','adjustment_type','effective_date','gross_amount_minor','gst_amount_minor','claimable_percent_bps','journal_public_id','reason_code','review_status','created_at']); }
    public function financialReports(Request $request)
    {
        $userId=(int)$request->user()->id;$from=now()->startOfMonth()->toDateString();$to=now()->toDateString();$pack=$this->reports->managementPack($userId,$from,$to,'AUD');
        return $this->view('Financial Reports', 'Trial Balance, Profit and Loss, Balance Sheet, retained earnings, comparatives and account drill-down derived only from posted journals.', [
            ['label'=>'Period','value'=>$from.' to '.$to],
            ['label'=>'Revenue (minor)','value'=>$pack['profit_loss']['revenue_minor']],
            ['label'=>'Net Profit (minor)','value'=>$pack['profit_loss']['net_profit_minor']],
            ['label'=>'Assets (minor)','value'=>$pack['balance_sheet']['assets_minor']],
            ['label'=>'Liabilities and Equity (minor)','value'=>$pack['balance_sheet']['liabilities_and_equity_minor']],
            ['label'=>'Trial Balance','value'=>$pack['trial_balance']['balanced']?'Balanced':'Out of balance'],
            ['label'=>'Currency Completeness','value'=>$pack['complete']?'Complete':'FX normalization required'],
            ['label'=>'Report Snapshots','value'=>count($this->reportSnapshots->all($userId,200))],
        ]);
    }

    public function cashflowForecasts(Request $request)
    {
        $userId=(int)$request->user()->id;$asOf=now()->toDateString();$from=now()->startOfMonth()->toDateString();$forecast=$this->cashflow->forecast($userId,$asOf,90,'AUD');$profit=$this->profitability->pack($userId,$from,$asOf,'AUD');
        return $this->view('Cashflow & Forecasts', 'Advisory cashflow, due-date forecast, runway and profitability evidence. Forecasts never create accounting transactions.', [
            ['label'=>'Opening Cash (minor)','value'=>$forecast['opening_cash_minor']],
            ['label'=>'90-day Expected Inflows (minor)','value'=>$forecast['expected_inflows_minor']],
            ['label'=>'90-day Expected Outflows (minor)','value'=>$forecast['expected_outflows_minor']],
            ['label'=>'Projected Closing Cash (minor)','value'=>$forecast['closing_cash_minor']],
            ['label'=>'Evidence Coverage','value'=>$forecast['evidence_coverage_bps'].' bps / '.$forecast['confidence_band']],
            ['label'=>'Cash Runway','value'=>$forecast['runway']['runway_days']===null?'No finite burn-based runway':$forecast['runway']['runway_days'].' days'],
            ['label'=>'Gross Margin','value'=>$profit['gross_margin_bps']===null?'N/A':$profit['gross_margin_bps'].' bps'],
            ['label'=>'Net Margin','value'=>$profit['net_margin_bps']===null?'N/A':$profit['net_margin_bps'].' bps'],
            ['label'=>'Forecast Snapshots','value'=>count($this->forecastSnapshots->all($userId,200))],
        ]);
    }

    public function diagnostics(Request $request)
    {
        return $this->view('Diagnostics', 'Ledger readiness and dependency status.', [
            ['label' => 'Command Definitions', 'value' => count(LedgerCommandDefinitionRegistry::all())],
            ['label' => 'Command Bus Gateway', 'value' => $this->commands->commandBusReady() ? 'Bound' : 'Unavailable'],
            ['label' => 'Receipt Table', 'value' => Schema::hasTable('titan_ledger_command_receipts') ? 'Ready' : 'Missing'],
            ['label' => 'Signal Gateway', 'value' => ($this->signals->diagnostics()['gateway_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Pending Signals', 'value' => $this->signals->pendingCount()],
            ['label' => 'Accounting Periods', 'value' => count($this->periods->allPeriods((int) $request->user()->id))],
        ]);
    }

    public function adminOverview()
    {
        return $this->view('Titan Ledger Administration', 'System-level Ledger integration status without exposing cross-company financial records.', [
            ['label' => 'Commands', 'value' => count(LedgerCommandDefinitionRegistry::all())],
            ['label' => 'Command Bus', 'value' => $this->commands->commandBusReady() ? 'Bound' : 'Unavailable'],
            ['label' => 'Signal Outbox', 'value' => $this->signals->pendingCount()],
            ['label' => 'Menus Table', 'value' => Schema::hasTable('menus') ? 'Detected' : 'Unavailable'],
            ['label' => 'Receipt Table', 'value' => Schema::hasTable('titan_ledger_command_receipts') ? 'Ready' : 'Missing'],
            ['label' => 'Signal Outbox', 'value' => Schema::hasTable('titan_ledger_signal_outbox') ? 'Ready' : 'Missing'],
        ]);
    }

    public function commandAuthority()
    {
        $rows = [];
        foreach (LedgerCommandDefinitionRegistry::all() as $name => $definition) $rows[] = ['command' => $name] + $definition;
        return $this->table('Command Authority', 'Mutating capabilities owned by Titan Ledger and accepted only after Titan Command Bus governance.', $rows, ['command','permission','target_required','receipt_required','idempotency']);
    }


    public function signalFabric()
    {
        $diagnostics = Schema::hasTable('titan_ledger_signal_outbox') ? $this->signals->diagnostics() : ['gateway_available'=>false,'pending'=>0,'failed_terminal'=>0,'delivered'=>0];
        return $this->view('Signal Fabric', 'Ledger financial event contracts, durable outbox and Titan Signal bridge readiness.', [
            ['label' => 'Event Definitions', 'value' => count(LedgerFinancialEventCatalog::all())],
            ['label' => 'Signal Gateway', 'value' => ($diagnostics['gateway_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Pending', 'value' => $diagnostics['pending'] ?? 0],
            ['label' => 'Delivered', 'value' => $diagnostics['delivered'] ?? 0],
            ['label' => 'Terminal Failures', 'value' => $diagnostics['failed_terminal'] ?? 0],
        ]);
    }


    public function riskAssurance()
    {
        $d = $this->governance->diagnostics();
        return $this->view('Risk and Assurance', 'External governance adapters gate Ledger mutations without transferring accounting authority.', [
            ['label' => 'Titan Risk Gateway', 'value' => ($d['risk_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Titan Assurance Gateway', 'value' => ($d['assurance_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Mutation Policy', 'value' => 'Fail closed'],
            ['label' => 'Decision Evidence', 'value' => Schema::hasColumn('titan_ledger_command_receipts','risk_reference') ? 'Ready' : 'Migration required'],
        ]);
    }

    public function rewindIntegration()
    {
        return $this->view('Rewind Integration', 'Read-only forensic source contribution for reconstructing Ledger command and Signal evidence.', [
            ['label' => 'Source Key', 'value' => $this->rewind->sourceKey()],
            ['label' => 'Authority', 'value' => 'Read only'],
            ['label' => 'Historical As Of', 'value' => 'Supported'],
            ['label' => 'Command Receipts', 'value' => Schema::hasTable('titan_ledger_command_receipts') ? 'Ready' : 'Missing'],
            ['label' => 'Signal Outbox', 'value' => Schema::hasTable('titan_ledger_signal_outbox') ? 'Ready' : 'Missing'],
        ]);
    }

    public function crmInvoiceAdapter()
    {
        return $this->view('CRM Invoice Adapter', 'Contract-driven CRM invoice accounting handoff through Command Bus into Titan Ledger.', [
            ['label'=>'Port Binding','value'=>'titan.ledger.crm-invoice-accounting.v1'],
            ['label'=>'Invoice Authority','value'=>'Titan CRM'],
            ['label'=>'Accounting Authority','value'=>'Titan Ledger'],
            ['label'=>'Direct CRM Table Reads','value'=>'None'],
            ['label'=>'Posting Evidence','value'=>Schema::hasTable('titan_ledger_crm_invoice_postings')?'Ready':'Migration required'],
        ]);
    }

    public function titanPayAdapter()
    {
        return $this->view('Titan Pay Adapter', 'Contract-driven settlement accounting for Titan Pay and legacy ZeroPay-compatible producers.', [
            ['label'=>'Port Binding','value'=>'titan.ledger.payment-settlement.v1'],
            ['label'=>'Legacy Alias','value'=>'titan.ledger.zeropay-settlement.v1'],
            ['label'=>'Settlement Authority','value'=>'Titan Pay'],
            ['label'=>'Accounting Authority','value'=>'Titan Ledger'],
            ['label'=>'Supported Rails','value'=>'PayID / Bank Transfer / Cash / Stripe / PayPal'],
            ['label'=>'Posting Evidence','value'=>Schema::hasTable('titan_ledger_payment_settlements')?'Ready':'Migration required'],
        ]);
    }

    public function arCollections()
    {
        return $this->view('AR and Collections', 'System-level receivables and collections readiness without exposing cross-company financial records.', [
            ['label'=>'Receivables Read Model','value'=>Schema::hasTable('titan_ledger_receivables')?'Ready':'Migration required'],
            ['label'=>'Collection Events','value'=>Schema::hasTable('titan_ledger_collection_events')?'Ready':'Migration required'],
            ['label'=>'Collection Commands','value'=>2],
            ['label'=>'Aging Buckets','value'=>7],
            ['label'=>'Outbound Communications','value'=>'External authority only'],
            ['label'=>'Tenant Boundary','value'=>'company_id'],
        ]);
    }


    public function apSpendAdapter()
    {
        return $this->view('AP and Spend Adapter', 'Contract-driven supplier bill and spend accounting without importing Budgeting or purchasing storage.', [
            ['label'=>'Port Binding','value'=>'titan.ledger.spend-accounting.v1'],
            ['label'=>'Spend Approval Authority','value'=>'External'],
            ['label'=>'Accounting Authority','value'=>'Titan Ledger'],
            ['label'=>'Spend Posting Evidence','value'=>Schema::hasTable('titan_ledger_spend_postings')?'Ready':'Migration required'],
            ['label'=>'Payables Projection','value'=>Schema::hasTable('titan_ledger_payables')?'Ready':'Migration required'],
            ['label'=>'Direct Budget/Purchasing Reads','value'=>'None'],
        ]);
    }

    public function bankingReconciliation()
    {
        return $this->view('Banking and Reconciliation', 'System-level bank statement and reconciliation readiness without exposing cross-company bank data.', [
            ['label'=>'Port Binding','value'=>'titan.ledger.bank-reconciliation.v1'],
            ['label'=>'Statement Evidence','value'=>Schema::hasTable('titan_ledger_bank_statements')?'Ready':'Migration required'],
            ['label'=>'Bank Transactions','value'=>Schema::hasTable('titan_ledger_bank_transactions')?'Ready':'Migration required'],
            ['label'=>'Reconciliation Sessions','value'=>Schema::hasTable('titan_ledger_reconciliation_sessions')?'Ready':'Migration required'],
            ['label'=>'Match Evidence','value'=>Schema::hasTable('titan_ledger_reconciliation_match_events')?'Ready':'Migration required'],
            ['label'=>'Statement Import Mutation','value'=>'Evidence only; no journal created'],
            ['label'=>'Close Requirement','value'=>'All transactions matched + opening/closing Ledger balance proof'],
        ]);
    }

    public function multiAccountBanking()
    {
        return $this->view('Multi-Account Banking', 'Multi-bank, credit-card and merchant clearing readiness. Ledger records accounting consequences and does not initiate provider payments.', [
            ['label'=>'Read Port','value'=>'titan.ledger.multi-account-banking.v1'],
            ['label'=>'Financial Account Registry','value'=>Schema::hasTable('titan_ledger_financial_accounts')?'Ready':'Migration required'],
            ['label'=>'Banking Movement Evidence','value'=>Schema::hasTable('titan_ledger_banking_movements')?'Ready':'Migration required'],
            ['label'=>'Supported Kinds','value'=>'bank / credit_card / clearing'],
            ['label'=>'Credit Card Reconciliation','value'=>'Signed Ledger balance convention'],
            ['label'=>'Clearing Settlement','value'=>'Provider capture -> clearing -> bank payout'],
            ['label'=>'Payment Initiation Authority','value'=>'None'],
        ]);
    }

    public function advancedReconciliation()
    {
        return $this->view('Advanced Reconciliation', 'Split and grouped matching, duplicate statement protection, transfer recognition and governed bank adjustment readiness.', [
            ['label'=>'Port Binding','value'=>'titan.ledger.advanced-reconciliation.v1'],
            ['label'=>'Group Evidence','value'=>Schema::hasTable('titan_ledger_reconciliation_groups')?'Ready':'Migration required'],
            ['label'=>'Active Member Index','value'=>Schema::hasTable('titan_ledger_reconciliation_active_members')?'Ready':'Migration required'],
            ['label'=>'Duplicate Statement Fingerprint','value'=>Schema::hasColumn('titan_ledger_bank_statements','statement_fingerprint')?'Ready':'Migration required'],
            ['label'=>'Bounded Classification Hint','value'=>Schema::hasColumn('titan_ledger_bank_transactions','classification_hint')?'Ready':'Migration required'],
            ['label'=>'Many-to-Many','value'=>'Not allowed; deterministic one-to-many / many-to-one only'],
        ]);
    }

    public function gstTaxLedger()
    {
        return $this->view('GST Tax Ledger', 'System-level Australian GST evidence readiness. Titan Ledger prepares evidence but is not an ATO lodgement authority.', [
            ['label'=>'Read Port','value'=>'titan.ledger.gst-tax-ledger.v1'],
            ['label'=>'Reporting Methods','value'=>'Simpler BAS / Full BAS'],
            ['label'=>'Supported Basis','value'=>'Accrual'],
            ['label'=>'BAS Labels','value'=>'G1 / G2 / G3 / G10 / G11 / 1A / 1B'],
            ['label'=>'GST Snapshot Evidence','value'=>Schema::hasTable('titan_ledger_gst_tax_snapshots')?'Ready':'Migration required'],
            ['label'=>'GST Adjustment Evidence','value'=>Schema::hasTable('titan_ledger_gst_adjustments')?'Ready':'Migration required'],
            ['label'=>'Accountant Review Evidence','value'=>Schema::hasTable('titan_ledger_gst_adjustment_reviews')?'Ready':'Migration required'],
            ['label'=>'ATO Lodgement Authority','value'=>'None'],
        ]);
    }

    public function financialReporting()
    {
        return $this->view('Financial Reporting', 'System-level statement engine and immutable report-evidence readiness without exposing cross-company financial rows.', [
            ['label'=>'Read Port','value'=>'titan.ledger.financial-reporting.v1'],
            ['label'=>'Journal Source','value'=>'Posted journals only'],
            ['label'=>'Trial Balance','value'=>'Ready'],
            ['label'=>'Profit and Loss','value'=>'Ready'],
            ['label'=>'Balance Sheet','value'=>'Ready'],
            ['label'=>'Comparatives','value'=>'Previous period / prior year'],
            ['label'=>'Report Snapshots','value'=>Schema::hasTable('titan_ledger_financial_report_snapshots')?'Ready':'Migration required'],
            ['label'=>'Finalizable Currency','value'=>'AUD complete evidence'],
        ]);
    }

    public function forecastingProfitability()
    {
        return $this->view('Forecasting & Profitability', 'System-level advisory forecasting readiness without exposing cross-company financial rows or granting accounting authority.', [
            ['label'=>'Read Port','value'=>'titan.ledger.cashflow-forecasting.v1'],
            ['label'=>'Cash Source','value'=>'Posted Ledger cash accounts'],
            ['label'=>'Working Capital Source','value'=>'Ledger AR/AP projections'],
            ['label'=>'Forecast Semantics','value'=>'Nominal due-date schedule; not probability weighted'],
            ['label'=>'Confidence Meaning','value'=>'Evidence coverage only'],
            ['label'=>'Profitability Source','value'=>'Posted journal/account classifications'],
            ['label'=>'Customer/Job Profitability','value'=>'Foundation only; requires authoritative dimension mapping'],
            ['label'=>'Forecast Snapshots','value'=>Schema::hasTable('titan_ledger_forecast_snapshots')?'Ready':'Migration required'],
            ['label'=>'Accounting Mutation Authority','value'=>'None'],
        ]);
    }


    public function fiscalCloseControl()
    {
        return $this->view('Fiscal Close Control', 'Governed fiscal-year close preparation, retained-earnings transfer, reopen lineage and immutable close evidence.', [
            ['label'=>'Read Port','value'=>'titan.ledger.financial-year-close.v1'],
            ['label'=>'Close Evidence','value'=>Schema::hasTable('titan_ledger_financial_year_closes')?'Ready':'Migration required'],
            ['label'=>'Reopen Evidence','value'=>Schema::hasTable('titan_ledger_financial_year_close_events')?'Ready':'Migration required'],
            ['label'=>'Closing Journal','value'=>'year_end_close'],
            ['label'=>'Reopen Journal','value'=>'year_end_reopen'],
            ['label'=>'Mutation Authority','value'=>'Command Bus + Risk + Assurance'],
        ]);
    }

    public function productionCertification()
    {
        $report = $this->productionCertification->certify();
        $checks = $report['checks'] ?? [];
        $failed = count(array_filter($checks, static fn (array $check): bool => ($check['status'] ?? 'FAIL') === 'FAIL'));
        $warnings = count(array_filter($checks, static fn (array $check): bool => ($check['status'] ?? '') === 'WARN'));
        return $this->view('Production Certification', 'Live-host certification for MySQL schema, immutability triggers, tenancy, authority gateways, Signal/Rewind and route/menu readiness.', [
            ['label'=>'Certification Status','value'=>$report['status'] ?? 'FAIL'],
            ['label'=>'Host Certified','value'=>($report['host_certified'] ?? false) ? 'Yes' : 'No'],
            ['label'=>'Required Failures','value'=>$failed],
            ['label'=>'Optional Warnings','value'=>$warnings],
            ['label'=>'Required MySQL Triggers','value'=>count(ProductionTriggerCatalog::names())],
            ['label'=>'Tenant Boundary','value'=>'company_id'],
            ['label'=>'Repair Command','value'=>'php artisan titan-ledger:production-certify --repair'],
        ]);
    }

    public function menuDiagnostics()
    {
        $report = $this->menus->inspect();
        return $this->view('Menu Diagnostics', 'Self-healing parent and child navigation diagnostics.', [
            ['label' => 'Menus Table', 'value' => ($report['menus_table'] ?? false) ? 'Detected' : 'Unavailable'],
            ['label' => 'Admin Column', 'value' => ($report['has_is_admin'] ?? false) ? 'Detected' : 'Registry only'],
            ['label' => 'Duplicate Ledger Keys', 'value' => count($report['duplicate_keys'] ?? [])],
            ['label' => 'User Children', 'value' => count($report['user_tree']['children'] ?? [])],
            ['label' => 'Admin Children', 'value' => count($report['admin_tree']['children'] ?? [])],
        ]);
    }

    public function systemDiagnostics()
    {
        return $this->view('System Diagnostics', 'Database and integration readiness without exposing company financial data.', [
            ['label' => 'Accounts Table', 'value' => Schema::hasTable('titan_ledger_accounts') ? 'Ready' : 'Missing'],
            ['label' => 'Journals Table', 'value' => Schema::hasTable('titan_ledger_journals') ? 'Ready' : 'Missing'],
            ['label' => 'Periods Table', 'value' => Schema::hasTable('titan_ledger_accounting_periods') ? 'Ready' : 'Missing'],
            ['label' => 'Command Receipts', 'value' => Schema::hasTable('titan_ledger_command_receipts') ? 'Ready' : 'Missing'],
            ['label' => 'Signal Outbox', 'value' => Schema::hasTable('titan_ledger_signal_outbox') ? 'Ready' : 'Missing'],
            ['label' => 'Signal Gateway', 'value' => ($this->signals->diagnostics()['gateway_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Titan Risk', 'value' => ($this->governance->diagnostics()['risk_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Titan Assurance', 'value' => ($this->governance->diagnostics()['assurance_available'] ?? false) ? 'Bound' : 'Unavailable'],
            ['label' => 'Rewind Source', 'value' => $this->rewind->sourceKey()],
            ['label' => 'CRM Invoice Adapter', 'value' => Schema::hasTable('titan_ledger_crm_invoice_postings') ? 'Ready' : 'Missing'],
            ['label' => 'Titan Pay Adapter', 'value' => Schema::hasTable('titan_ledger_payment_settlements') ? 'Ready' : 'Missing'],
            ['label' => 'Receivables', 'value' => Schema::hasTable('titan_ledger_receivables') ? 'Ready' : 'Missing'],
            ['label' => 'Collection Events', 'value' => Schema::hasTable('titan_ledger_collection_events') ? 'Ready' : 'Missing'],
            ['label' => 'Spend Postings', 'value' => Schema::hasTable('titan_ledger_spend_postings') ? 'Ready' : 'Missing'],
            ['label' => 'Payables', 'value' => Schema::hasTable('titan_ledger_payables') ? 'Ready' : 'Missing'],
            ['label' => 'Bank Statements', 'value' => Schema::hasTable('titan_ledger_bank_statements') ? 'Ready' : 'Missing'],
            ['label' => 'Reconciliation Sessions', 'value' => Schema::hasTable('titan_ledger_reconciliation_sessions') ? 'Ready' : 'Missing'],
            ['label' => 'Financial Accounts', 'value' => Schema::hasTable('titan_ledger_financial_accounts') ? 'Ready' : 'Missing'],
            ['label' => 'Banking Movements', 'value' => Schema::hasTable('titan_ledger_banking_movements') ? 'Ready' : 'Missing'],
            ['label' => 'GST Tax Snapshots', 'value' => Schema::hasTable('titan_ledger_gst_tax_snapshots') ? 'Ready' : 'Missing'],
            ['label' => 'Financial Report Snapshots', 'value' => Schema::hasTable('titan_ledger_financial_report_snapshots') ? 'Ready' : 'Missing'],
            ['label' => 'Forecast Snapshots', 'value' => Schema::hasTable('titan_ledger_forecast_snapshots') ? 'Ready' : 'Missing'],
            ['label' => 'Command Bus', 'value' => $this->commands->commandBusReady() ? 'Bound' : 'Unavailable'],
            ['label' => 'Signal Outbox', 'value' => $this->signals->pendingCount()],
        ]);
    }

    private function table(string $title, string $subtitle, array $rows, array $columns)
    {
        return view('titan-ledger::workspace.index', compact('title','subtitle','rows','columns') + ['cards' => []]);
    }

    private function view(string $title, string $subtitle, array $cards)
    {
        return view('titan-ledger::workspace.index', compact('title','subtitle','cards') + ['rows' => [], 'columns' => []]);
    }
}
