<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

use App\Extensions\TitanLedger\System\Domains\Commanding\LedgerCommandEnvelope;
use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use InvalidArgumentException;

final class LedgerCommandSubmissionService
{
    public function __construct(
        private LedgerCompanyContext $companyContext,
        private LedgerCommandBusGatewayContract $bus,
    ) {}

    public function submit(
        int $userId,
        string $commandName,
        string $commandId,
        ?string $targetPublicId,
        array $payload = [],
        array $context = [],
        string $callerExtension = 'titan-ledger-http',
    ): array {
        $definition = LedgerCommandDefinitionRegistry::definition($commandName);
        if ($definition === null) throw new InvalidArgumentException('Unsupported Titan Ledger command.');
        if (($definition['target_required'] ?? false) && ($targetPublicId === null || trim($targetPublicId) === '')) {
            throw new InvalidArgumentException('target_public_id is required for this Titan Ledger command.');
        }

        $companyId = $this->companyContext->companyId($userId);
        $actor = $this->companyContext->actorUserId($userId);
        $envelope = LedgerCommandEnvelope::normalize([
            'command_id' => $commandId,
            'command_name' => $commandName,
            'command_version' => 1,
            'caller_extension' => $callerExtension,
            'target_public_id' => $targetPublicId,
            'payload' => $payload,
            'trace_id' => $context['trace_id'] ?? null,
            'correlation_id' => $context['correlation_id'] ?? null,
            'causation_id' => $context['causation_id'] ?? null,
        ], $companyId, $actor);

        $envelope['submission_hash'] = $envelope['request_hash'];
        $envelope['domain'] = 'titan-ledger';
        $envelope['required_permission'] = (string) $definition['permission'];
        $envelope['receipt_required'] = true;
        $envelope['adapter_binding'] = (string) $definition['adapter_binding'];
        $envelope['governance_required'] = true;

        return $this->bus->dispatch($envelope);
    }

    public function commandBusReady(): bool
    {
        return $this->bus->available();
    }
}
