<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Commanding;

use InvalidArgumentException;

final class LedgerCommandEnvelope
{
    public static function normalize(array $input, int $resolvedCompanyId, int $resolvedActorUserId): array
    {
        if ($resolvedCompanyId < 1) throw new InvalidArgumentException('Resolved company_id must be positive.');
        if ($resolvedActorUserId < 1) throw new InvalidArgumentException('Resolved actor_user_id must be positive.');

        if (array_key_exists('company_id', $input) && (int) $input['company_id'] !== $resolvedCompanyId) {
            throw new InvalidArgumentException('Command company_id does not match the canonical company context.');
        }
        if (array_key_exists('actor_user_id', $input) && (int) $input['actor_user_id'] !== $resolvedActorUserId) {
            throw new InvalidArgumentException('Command actor_user_id does not match the canonical actor context.');
        }

        $commandId = trim((string) ($input['command_id'] ?? ''));
        if ($commandId === '' || strlen($commandId) > 191) throw new InvalidArgumentException('command_id is required and must be at most 191 characters.');

        $commandName = trim((string) ($input['command_name'] ?? ''));
        if (! LedgerCommandCatalog::supports($commandName)) throw new InvalidArgumentException('Unsupported Titan Ledger command.');

        $commandVersion = (int) ($input['command_version'] ?? 1);
        if ($commandVersion !== 1) throw new InvalidArgumentException('Unsupported Titan Ledger command version.');

        $callerExtension = trim((string) ($input['caller_extension'] ?? ''));
        if ($callerExtension === '' || strlen($callerExtension) > 100 || ! preg_match('/^[a-z0-9][a-z0-9._-]*$/', $callerExtension)) {
            throw new InvalidArgumentException('caller_extension must be a canonical extension identifier.');
        }

        $target = isset($input['target_public_id']) ? trim((string) $input['target_public_id']) : null;
        if ($target === '') $target = null;
        if ($target !== null && strlen($target) > 191) throw new InvalidArgumentException('target_public_id is too long.');

        $payload = $input['payload'] ?? [];
        if (! is_array($payload)) throw new InvalidArgumentException('Command payload must be an array.');

        $normalized = [
            'command_id' => $commandId,
            'command_name' => $commandName,
            'command_version' => $commandVersion,
            'company_id' => $resolvedCompanyId,
            'actor_user_id' => $resolvedActorUserId,
            'caller_extension' => $callerExtension,
            'target_public_id' => $target,
            'payload' => $payload,
            'trace_id' => self::lineage($input, 'trace_id'),
            'correlation_id' => self::lineage($input, 'correlation_id'),
            'causation_id' => self::lineage($input, 'causation_id'),
        ];
        $normalized['request_hash'] = hash('sha256', self::canonicalJson($normalized));
        return $normalized;
    }

    private static function lineage(array $input, string $key): ?string
    {
        if (! isset($input[$key]) || $input[$key] === '') return null;
        $value = trim((string) $input[$key]);
        if ($value === '' || strlen($value) > 120) throw new InvalidArgumentException($key . ' must be at most 120 characters.');
        return $value;
    }

    private static function canonicalJson(array $value): string
    {
        $canonical = self::canonicalize($value);
        return (string) json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map([self::class, 'canonicalize'], $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = self::canonicalize($item);
        return $value;
    }
}
