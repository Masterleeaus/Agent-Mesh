<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\TitanPay;

use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableProjectionService;
use App\Extensions\TitanLedger\System\Domains\Banking\FinancialAccountRegistryService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class TitanPaySettlementService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext,private ChartOfAccountsService $accounts,private JournalService $journals,private ReceivableProjectionService $receivables,private FinancialAccountRegistryService $financialAccounts) {}

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function postPayment(int $userId,string $targetPublicId,array $payload,string $operationId,array $command): array
    {
        $fact=TitanPaySettlementFact::payment($payload); $this->assertTarget($targetPublicId,$fact);
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->transaction(function() use($userId,$companyId,$fact,$operationId,$command): array {
            $existing=$this->existingSettlement($companyId,'payment',$fact['settlement_public_id'],true); $factHash=TitanPaySettlementFact::hash($fact);
            if($existing) return $this->assertReplay($existing,$factHash,$operationId);
            $invoice=$this->invoicePosting($companyId,$fact['invoice_public_id'],true);
            if((string)$invoice->currency!==$fact['currency']) throw new InvalidArgumentException('Titan Pay settlement currency must match the posted CRM invoice.');
            $outstanding=$this->invoiceOutstanding($companyId,$fact['invoice_public_id']);
            $allocation=min((int)$fact['gross_amount_minor'],$outstanding); $overpayment=(int)$fact['gross_amount_minor']-$allocation;
            $accountIds=$this->accountIds($userId); $fundsAccount=$this->paymentFundsAccount($companyId,$fact,$accountIds['bank']); $accountIds['bank']=$fundsAccount;
            $lines=TitanPaySettlementJournalMapper::paymentLines($fact,$accountIds,$allocation,$overpayment);
            $journal=$this->journals->postAuthoritativeSourceJournal($userId,'payment',[
                'entry_date'=>$fact['entry_date'],'currency'=>$fact['currency'],'source_extension'=>'titan-pay','source_type'=>'payment.settled',
                'source_public_id'=>$fact['settlement_public_id'],'source_event_id'=>$fact['source_event_id'],'source_operation_id'=>$operationId,
                'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                'metadata'=>['source_version'=>$fact['source_version'],'invoice_public_id'=>$fact['invoice_public_id'],'rail'=>$fact['rail']],
            ],$lines,$operationId,null);
            $cashMovement=$this->isClearingAccount($companyId,$fundsAccount)?0:(int)$fact['net_amount_minor'];
            $row=$this->row($companyId,$fact,$factHash,$operationId,$journal['public_id'],$allocation,$overpayment,(int)$fact['gross_amount_minor'],(int)$fact['fee_minor'],$cashMovement,$userId,$fundsAccount);
            $this->db->table('titan_ledger_payment_settlements')->insert($row); $this->receivables->refresh($companyId,(string)$fact['invoice_public_id']); return $this->result($row);
        });
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $command */
    public function postRefund(int $userId,string $targetPublicId,array $payload,string $operationId,array $command): array
    {
        $fact=TitanPaySettlementFact::refund($payload); $this->assertTarget($targetPublicId,$fact);
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->transaction(function() use($userId,$companyId,$fact,$operationId,$command): array {
            $existing=$this->existingSettlement($companyId,'refund',$fact['settlement_public_id'],true); $factHash=TitanPaySettlementFact::hash($fact);
            if($existing) return $this->assertReplay($existing,$factHash,$operationId);
            $payment=$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('settlement_type','payment')->where('settlement_public_id',$fact['payment_public_id'])->lockForUpdate()->first();
            if(!$payment) throw new InvalidArgumentException('Titan Pay refund cannot post before its original payment is posted to Titan Ledger.');
            if((string)$payment->invoice_public_id!==$fact['invoice_public_id']) throw new InvalidArgumentException('Titan Pay refund invoice does not match the original payment.');
            if((string)$payment->currency!==$fact['currency']||(string)$payment->rail!==$fact['rail']) throw new InvalidArgumentException('Titan Pay refund currency and rail must match the original payment.');
            $this->invoicePosting($companyId,$fact['invoice_public_id'],true); // serialize refunds with new payments on the same receivable
            $prior=$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('settlement_type','refund')->where('payment_public_id',$fact['payment_public_id'])->lockForUpdate()->limit(10000)->get();
            $alreadyRefunded=0;$overpaymentAlreadyRefunded=0;$allocationAlreadyRefunded=0;
            foreach($prior as $r){$alreadyRefunded+=(int)$r->gross_amount_minor;$overpaymentAlreadyRefunded+=(int)$r->overpayment_minor;$allocationAlreadyRefunded+=(int)$r->allocation_minor;}
            $amount=(int)$fact['refund_amount_minor'];
            if($alreadyRefunded+$amount>(int)$payment->gross_amount_minor) throw new InvalidArgumentException('Titan Pay refund exceeds the unrefunded original payment amount.');
            $availableOverpayment=max(0,(int)$payment->overpayment_minor-$overpaymentAlreadyRefunded); $overpaymentRefund=min($amount,$availableOverpayment); $allocationRefund=$amount-$overpaymentRefund;
            if($allocationAlreadyRefunded+$allocationRefund>(int)$payment->allocation_minor) throw new InvalidArgumentException('Titan Pay refund exceeds the original receivable allocation.');
            $accountIds=$this->accountIds($userId); $fundsAccount=(string)($payment->funds_account_public_id??$accountIds['bank']); if($fundsAccount==='')$fundsAccount=$accountIds['bank']; $requestedFunds=trim((string)($fact['funds_account_public_id']??'')); if($requestedFunds!==''&&!hash_equals($fundsAccount,$requestedFunds))throw new InvalidArgumentException('Titan Pay refund funds account must match the original payment.'); $accountIds['bank']=$fundsAccount; $lines=TitanPaySettlementJournalMapper::refundLines($fact,$accountIds,$overpaymentRefund,$allocationRefund);
            $journal=$this->journals->postAuthoritativeSourceJournal($userId,'refund',[
                'entry_date'=>$fact['entry_date'],'currency'=>$fact['currency'],'source_extension'=>'titan-pay','source_type'=>'payment.refunded',
                'source_public_id'=>$fact['settlement_public_id'],'source_event_id'=>$fact['source_event_id'],'source_operation_id'=>$operationId,
                'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,
                'metadata'=>['source_version'=>$fact['source_version'],'invoice_public_id'=>$fact['invoice_public_id'],'rail'=>$fact['rail'],'original_payment_public_id'=>$fact['payment_public_id']],
            ],$lines,$operationId,(string)$payment->journal_public_id);
            $cashMovement=$this->isClearingAccount($companyId,$fundsAccount)?0:$amount+(int)$fact['refund_fee_minor'];
            $row=$this->row($companyId,$fact,$factHash,$operationId,$journal['public_id'],$allocationRefund,$overpaymentRefund,$amount,(int)$fact['refund_fee_minor'],$cashMovement,$userId,$fundsAccount);
            $this->db->table('titan_ledger_payment_settlements')->insert($row); $this->receivables->refresh($companyId,(string)$fact['invoice_public_id']); return $this->result($row);
        });
    }

    public function all(int $userId,int $limit=200): array
    {
        $companyId=$this->companyContext->companyId($userId);
        return $this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->orderByDesc('settled_at')->orderByDesc('id')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>(array)$r)->all();
    }

    private function invoiceOutstanding(int $companyId,string $invoicePublicId): int
    {
        $invoice=$this->invoicePosting($companyId,$invoicePublicId,true);
        $credits=(int)$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','credit_note')->where('invoice_public_id',$invoicePublicId)->sum('total_minor');
        $paid=(int)$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('settlement_type','payment')->where('invoice_public_id',$invoicePublicId)->sum('allocation_minor');
        $refunded=(int)$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('settlement_type','refund')->where('invoice_public_id',$invoicePublicId)->sum('allocation_minor');
        return max(0,(int)$invoice->total_minor-$credits-$paid+$refunded);
    }

    private function invoicePosting(int $companyId,string $invoicePublicId,bool $lock): object
    {
        $q=$this->db->table('titan_ledger_crm_invoice_postings')->where('company_id',$companyId)->where('document_type','invoice')->where('document_public_id',$invoicePublicId); if($lock)$q->lockForUpdate(); $row=$q->first();
        if(!$row) throw new InvalidArgumentException('Titan Pay settlement requires the CRM invoice to be posted to Titan Ledger first.'); return $row;
    }

    /** @return array<string,string> */
    private function accountIds(int $userId): array
    {
        $ids=[]; foreach(['bank','accounts_receivable','customer_overpayments','merchant_fees'] as $key){$a=$this->accounts->findSystemAccount($userId,$key);if(!$a||empty($a['public_id'])) throw new InvalidArgumentException('Required Ledger system account unavailable: '.$key.'.');$ids[$key]=(string)$a['public_id'];} return $ids;
    }


    private function paymentFundsAccount(int $companyId,array $fact,string $default): string
    {
        $requested=trim((string)($fact['funds_account_public_id']??''));
        if($requested==='') return $default;
        $registered=$this->financialAccounts->requireKind($companyId,$requested,['bank','clearing']);
        if((string)$registered->currency!==(string)$fact['currency']) throw new InvalidArgumentException('Titan Pay funds account currency does not match settlement currency.');
        if((string)$registered->kind==='clearing'&&!in_array((string)$fact['rail'],['stripe','paypal'],true)) throw new InvalidArgumentException('Only card/provider rails may settle into payment clearing.');
        return $requested;
    }

    private function isClearingAccount(int $companyId,string $accountPublicId): bool
    {
        try{return (string)$this->financialAccounts->requireKind($companyId,$accountPublicId,['bank','clearing'])->kind==='clearing';}catch(InvalidArgumentException){return false;}
    }

    private function existingSettlement(int $companyId,string $type,string $id,bool $lock): ?object { $q=$this->db->table('titan_ledger_payment_settlements')->where('company_id',$companyId)->where('settlement_type',$type)->where('settlement_public_id',$id);if($lock)$q->lockForUpdate();return $q->first(); }
    /** @return array<string,mixed> */
    private function assertReplay(object $existing,string $factHash,string $operationId): array { if(!hash_equals((string)$existing->fact_hash,$factHash)) throw new InvalidArgumentException('Titan Pay settlement fact changed after Ledger posting.'); if(!hash_equals((string)$existing->posting_operation_id,$operationId)) throw new InvalidArgumentException('Titan Pay settlement is already posted under a different governed operation.'); return $this->result((array)$existing); }
    /** @param array<string,mixed> $fact @return array<string,mixed> */
    private function row(int $companyId,array $fact,string $factHash,string $operationId,string $journalPublicId,int $allocation,int $overpayment,int $gross,int $fee,int $cashMovement,int $userId,string $fundsAccountPublicId): array { return [
        'public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'settlement_type'=>$fact['settlement_type'],'settlement_public_id'=>$fact['settlement_public_id'],'payment_public_id'=>$fact['payment_public_id'],'invoice_public_id'=>$fact['invoice_public_id'],
        'source_event_id'=>$fact['source_event_id'],'source_version'=>$fact['source_version'],'fact_hash'=>$factHash,'rail'=>$fact['rail'],'provider_reference'=>$fact['provider_reference'],'currency'=>$fact['currency'],'funds_account_public_id'=>$fundsAccountPublicId,
        'gross_amount_minor'=>$gross,'fee_minor'=>$fee,'cash_movement_minor'=>$cashMovement,'allocation_minor'=>$allocation,'overpayment_minor'=>$overpayment,'settled_at'=>$fact['settled_at'],'journal_public_id'=>$journalPublicId,'posting_operation_id'=>$operationId,
        'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now(),
    ]; }
    /** @param array<string,mixed> $fact */
    private function assertTarget(string $target,array $fact): void { if(trim($target)===''||!hash_equals((string)$fact['settlement_public_id'],trim($target))) throw new InvalidArgumentException('Titan Pay command target does not match settlement_public_id.'); }
    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function result(array $row): array { return array_intersect_key($row,array_flip(['public_id','settlement_type','settlement_public_id','payment_public_id','invoice_public_id','rail','currency','funds_account_public_id','gross_amount_minor','fee_minor','cash_movement_minor','allocation_minor','overpayment_minor','journal_public_id','source_event_id','settled_at'])); }
}
