<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Payables;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class PayableProjectionService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext){}

    public function refresh(int $companyId,string $billPublicId): ?array
    {
        $bill=$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->where('posting_type','supplier_bill')->where('document_public_id',$billPublicId)->first();
        if(!$bill)return null;
        $credits=(int)$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->where('posting_type','supplier_credit')->where('bill_public_id',$billPublicId)->sum('total_minor');
        $payments=(int)$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->where('posting_type','supplier_payment')->where('bill_public_id',$billPublicId)->sum('ap_allocation_minor');
        $prepayments=(int)$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->where('posting_type','supplier_payment')->where('bill_public_id',$billPublicId)->sum('prepayment_minor');
        $balance=PayableBalanceCalculator::calculate((int)$bill->total_minor,$credits,$payments,$prepayments);
        $aging=PayableAgingPolicy::classify($bill->due_at===null?null:(string)$bill->due_at,now('UTC')->toDateString(),$balance['outstanding_minor']);
        $financialState=$balance['outstanding_minor']>0?($payments>0||$credits>0?'partial':'open'):($balance['payable_credit_minor']>0?'credit':'settled');
        $payload=['bill_total_minor'=>(int)$bill->total_minor,'credits_minor'=>$credits,'payments_minor'=>$payments,'outstanding_minor'=>$balance['outstanding_minor'],'payable_credit_minor'=>$balance['payable_credit_minor'],'supplier_prepayment_minor'=>$balance['supplier_prepayment_minor'],'aging_bucket'=>$aging['bucket'],'days_past_due'=>$aging['days_past_due'],'financial_state'=>$financialState];
        $hash=hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
        $existing=$this->db->table('titan_ledger_payables')->where('company_id',$companyId)->where('bill_public_id',$billPublicId)->first();
        $row=['supplier_public_id'=>$bill->supplier_public_id,'currency'=>$bill->currency,'issued_at'=>$bill->occurred_at,'due_at'=>$bill->due_at,'bill_total_minor'=>(int)$bill->total_minor,'credits_minor'=>$credits,'payments_minor'=>$payments,'outstanding_minor'=>$balance['outstanding_minor'],'payable_credit_minor'=>$balance['payable_credit_minor'],'supplier_prepayment_minor'=>$balance['supplier_prepayment_minor'],'financial_state'=>$financialState,'aging_bucket'=>$aging['bucket'],'days_past_due'=>$aging['days_past_due'],'is_overdue'=>$aging['is_overdue'],'projection_hash'=>$hash,'updated_at'=>now()];
        if($existing)$this->db->table('titan_ledger_payables')->where('company_id',$companyId)->where('bill_public_id',$billPublicId)->update($row);else{$row+=['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'bill_public_id'=>$billPublicId,'created_at'=>now()];$this->db->table('titan_ledger_payables')->insert($row);}
        $saved=$this->db->table('titan_ledger_payables')->where('company_id',$companyId)->where('bill_public_id',$billPublicId)->first();return $saved?(array)$saved:null;
    }

    public function all(int $userId,int $limit=200): array
    {
        $companyId=$this->companyContext->companyId($userId);
        $ids=$this->db->table('titan_ledger_spend_postings')->where('company_id',$companyId)->where('posting_type','supplier_bill')->orderByDesc('occurred_at')->limit(max(1,min($limit,500)))->pluck('document_public_id');
        foreach($ids as $id)$this->refresh($companyId,(string)$id);
        return $this->db->table('titan_ledger_payables')->where('company_id',$companyId)->orderByDesc('is_overdue')->orderByDesc('outstanding_minor')->limit(max(1,min($limit,500)))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function agingSummary(int $userId): array
    {
        $rows=$this->all($userId,500);$summary=['current'=>0,'1-30'=>0,'31-60'=>0,'61-90'=>0,'91+'=>0,'unknown_due_date'=>0,'settled'=>0,'total_outstanding_minor'=>0,'supplier_credit_minor'=>0,'supplier_prepayment_minor'=>0];
        foreach($rows as $r){$bucket=(string)$r['aging_bucket'];if(isset($summary[$bucket]))$summary[$bucket]+=(int)$r['outstanding_minor'];$summary['total_outstanding_minor']+=(int)$r['outstanding_minor'];$summary['supplier_credit_minor']+=(int)$r['payable_credit_minor'];$summary['supplier_prepayment_minor']+=(int)$r['supplier_prepayment_minor'];}
        return $summary;
    }
}
