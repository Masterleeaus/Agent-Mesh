<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Http\Controllers;
use App\Extensions\TitanLedger\System\Domains\Banking\FinancialAccountRegistryService;
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
final class MultiAccountBankingController extends Controller
{
    public function __construct(private FinancialAccountRegistryService $accounts,private MultiAccountBankingService $banking){}
    public function accounts(Request $request){return response()->json(['data'=>$this->accounts->all((int)$request->user()->id)]);}
    public function movements(Request $request){return response()->json(['data'=>$this->banking->movements((int)$request->user()->id,(int)$request->integer('limit',200))]);}
}
