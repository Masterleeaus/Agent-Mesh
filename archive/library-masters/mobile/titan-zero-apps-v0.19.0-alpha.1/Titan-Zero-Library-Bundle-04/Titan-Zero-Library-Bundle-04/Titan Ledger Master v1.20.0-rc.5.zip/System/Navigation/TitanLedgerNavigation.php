<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Navigation;

final class TitanLedgerNavigation
{
    public static function user(): array
    {
        return [
            'key' => 'titan_ledger_parent',
            'label' => 'Titan Ledger',
            'icon' => 'tabler-report-money',
            'route' => 'dashboard.user.titan-ledger.overview',
            'order' => 520,
            'children' => [
                ['key'=>'titan_ledger_overview','label'=>'Overview','route'=>'dashboard.user.titan-ledger.overview','icon'=>'tabler-dashboard','order'=>10],
                ['key'=>'titan_ledger_bookkeeping','label'=>'Bookkeeping','route'=>'dashboard.user.titan-ledger.bookkeeping','icon'=>'tabler-receipt','order'=>20],
                ['key'=>'titan_ledger_accounts','label'=>'Chart of Accounts','route'=>'dashboard.user.titan-ledger.accounts','icon'=>'tabler-list-details','order'=>30],
                ['key'=>'titan_ledger_journals','label'=>'Journals','route'=>'dashboard.user.titan-ledger.journals','icon'=>'tabler-book-2','order'=>40],
                ['key'=>'titan_ledger_financial_years','label'=>'Financial Years','route'=>'dashboard.user.titan-ledger.financial-years','icon'=>'tabler-calendar','order'=>50],
                ['key'=>'titan_ledger_year_end_close','label'=>'Year-End Close','route'=>'dashboard.user.titan-ledger.year-end-close','icon'=>'tabler-calendar-check','order'=>55],
                ['key'=>'titan_ledger_accounting_periods','label'=>'Accounting Periods','route'=>'dashboard.user.titan-ledger.accounting-periods','icon'=>'tabler-lock','order'=>60],
                ['key'=>'titan_ledger_command_receipts','label'=>'Command Receipts','route'=>'dashboard.user.titan-ledger.command-receipts','icon'=>'tabler-file-check','order'=>70],
                ['key'=>'titan_ledger_financial_events','label'=>'Financial Events','route'=>'dashboard.user.titan-ledger.financial-events','icon'=>'tabler-activity','order'=>80],
                ['key'=>'titan_ledger_governance_evidence','label'=>'Governance Evidence','route'=>'dashboard.user.titan-ledger.governance-evidence','icon'=>'tabler-shield-check','order'=>90],
                ['key'=>'titan_ledger_invoice_accounting','label'=>'Invoice Accounting','route'=>'dashboard.user.titan-ledger.invoice-accounting','icon'=>'tabler-file-invoice','order'=>100],
                ['key'=>'titan_ledger_payment_settlements','label'=>'Payment Settlements','route'=>'dashboard.user.titan-ledger.payment-settlements','icon'=>'tabler-credit-card-pay','order'=>110],
                ['key'=>'titan_ledger_receivables','label'=>'Receivables','route'=>'dashboard.user.titan-ledger.receivables','icon'=>'tabler-cash-banknote','order'=>120],
                ['key'=>'titan_ledger_payables','label'=>'Payables','route'=>'dashboard.user.titan-ledger.payables','icon'=>'tabler-file-dollar','order'=>130],
                ['key'=>'titan_ledger_bank_reconciliation','label'=>'Bank Reconciliation','route'=>'dashboard.user.titan-ledger.bank-reconciliation','icon'=>'tabler-building-bank','order'=>140],
                ['key'=>'titan_ledger_banking_accounts','label'=>'Banking Accounts','route'=>'dashboard.user.titan-ledger.banking-accounts','icon'=>'tabler-building-bank','order'=>145],
                ['key'=>'titan_ledger_reconciliation_automation','label'=>'Reconciliation Automation','route'=>'dashboard.user.titan-ledger.reconciliation-automation','icon'=>'tabler-wand','order'=>147],
                ['key'=>'titan_ledger_gst_bas','label'=>'GST and BAS','route'=>'dashboard.user.titan-ledger.gst-bas','icon'=>'tabler-receipt-tax','order'=>150],
                ['key'=>'titan_ledger_gst_adjustments','label'=>'GST Adjustments','route'=>'dashboard.user.titan-ledger.gst-adjustments','icon'=>'tabler-adjustments','order'=>155],
                ['key'=>'titan_ledger_financial_reports','label'=>'Financial Reports','route'=>'dashboard.user.titan-ledger.financial-reports','icon'=>'tabler-chart-bar','order'=>160],
                ['key'=>'titan_ledger_cashflow_forecasts','label'=>'Cashflow and Forecasts','route'=>'dashboard.user.titan-ledger.cashflow-forecasts','icon'=>'tabler-chart-line','order'=>170],
                ['key'=>'titan_ledger_diagnostics','label'=>'Diagnostics','route'=>'dashboard.user.titan-ledger.diagnostics','icon'=>'tabler-stethoscope','order'=>180],
            ],
        ];
    }

    public static function admin(): array
    {
        return [
            'key' => 'titan_ledger_admin_parent',
            'label' => 'Titan Ledger',
            'icon' => 'tabler-report-money',
            'route' => 'dashboard.admin.titan-ledger.overview',
            'order' => 520,
            'children' => [
                ['key'=>'titan_ledger_admin_overview','label'=>'Overview','route'=>'dashboard.admin.titan-ledger.overview','icon'=>'tabler-dashboard','order'=>10],
                ['key'=>'titan_ledger_command_authority','label'=>'Command Authority','route'=>'dashboard.admin.titan-ledger.command-authority','icon'=>'tabler-shield-check','order'=>20],
                ['key'=>'titan_ledger_signal_fabric','label'=>'Signal Fabric','route'=>'dashboard.admin.titan-ledger.signal-fabric','icon'=>'tabler-activity-heartbeat','order'=>30],
                ['key'=>'titan_ledger_risk_assurance','label'=>'Risk and Assurance','route'=>'dashboard.admin.titan-ledger.risk-assurance','icon'=>'tabler-shield-half-filled','order'=>40],
                ['key'=>'titan_ledger_rewind_integration','label'=>'Rewind Integration','route'=>'dashboard.admin.titan-ledger.rewind-integration','icon'=>'tabler-history','order'=>50],
                ['key'=>'titan_ledger_crm_invoice_adapter','label'=>'CRM Invoice Adapter','route'=>'dashboard.admin.titan-ledger.crm-invoice-adapter','icon'=>'tabler-file-invoice','order'=>60],
                ['key'=>'titan_ledger_titan_pay_adapter','label'=>'Titan Pay Adapter','route'=>'dashboard.admin.titan-ledger.titan-pay-adapter','icon'=>'tabler-credit-card-pay','order'=>70],
                ['key'=>'titan_ledger_ar_collections','label'=>'AR and Collections','route'=>'dashboard.admin.titan-ledger.ar-collections','icon'=>'tabler-report-money','order'=>80],
                ['key'=>'titan_ledger_ap_spend_adapter','label'=>'AP and Spend Adapter','route'=>'dashboard.admin.titan-ledger.ap-spend-adapter','icon'=>'tabler-receipt-tax','order'=>90],
                ['key'=>'titan_ledger_banking_reconciliation','label'=>'Banking and Reconciliation','route'=>'dashboard.admin.titan-ledger.banking-reconciliation','icon'=>'tabler-building-bank','order'=>100],
                ['key'=>'titan_ledger_multi_account_banking','label'=>'Multi-Account Banking','route'=>'dashboard.admin.titan-ledger.multi-account-banking','icon'=>'tabler-arrows-exchange','order'=>105],
                ['key'=>'titan_ledger_advanced_reconciliation','label'=>'Advanced Reconciliation','route'=>'dashboard.admin.titan-ledger.advanced-reconciliation','icon'=>'tabler-arrows-join','order'=>107],
                ['key'=>'titan_ledger_gst_tax_ledger','label'=>'GST Tax Ledger','route'=>'dashboard.admin.titan-ledger.gst-tax-ledger','icon'=>'tabler-receipt-tax','order'=>110],
                ['key'=>'titan_ledger_advanced_gst_control','label'=>'Advanced GST Control','route'=>'dashboard.admin.titan-ledger.advanced-gst-control','icon'=>'tabler-adjustments-check','order'=>115],
                ['key'=>'titan_ledger_financial_reporting','label'=>'Financial Reporting','route'=>'dashboard.admin.titan-ledger.financial-reporting','icon'=>'tabler-chart-bar','order'=>120],
                ['key'=>'titan_ledger_forecasting_profitability','label'=>'Forecasting and Profitability','route'=>'dashboard.admin.titan-ledger.forecasting-profitability','icon'=>'tabler-chart-line','order'=>130],
                ['key'=>'titan_ledger_fiscal_close_control','label'=>'Fiscal Close Control','route'=>'dashboard.admin.titan-ledger.fiscal-close-control','icon'=>'tabler-calendar-check','order'=>135],
                ['key'=>'titan_ledger_production_certification','label'=>'Production Certification','route'=>'dashboard.admin.titan-ledger.production-certification','icon'=>'tabler-certificate','order'=>140],
                ['key'=>'titan_ledger_menu_diagnostics','label'=>'Menu Diagnostics','route'=>'dashboard.admin.titan-ledger.menu-diagnostics','icon'=>'tabler-sitemap','order'=>150],
                ['key'=>'titan_ledger_system_diagnostics','label'=>'System Diagnostics','route'=>'dashboard.admin.titan-ledger.system-diagnostics','icon'=>'tabler-tool','order'=>160],
            ],
        ];
    }
}
