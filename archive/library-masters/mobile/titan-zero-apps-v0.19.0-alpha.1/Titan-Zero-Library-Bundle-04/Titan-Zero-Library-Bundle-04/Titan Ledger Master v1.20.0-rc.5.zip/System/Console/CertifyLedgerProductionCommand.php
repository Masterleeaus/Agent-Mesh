<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Console;

use App\Extensions\TitanLedger\System\Certification\LedgerProductionCertificationService;
use App\Extensions\TitanLedger\System\Certification\LedgerProductionDatabaseHardener;
use Illuminate\Console\Command;
use Throwable;

final class CertifyLedgerProductionCommand extends Command
{
    protected $signature = 'titan-ledger:production-certify {--repair : Re-run idempotent schema/trigger hardening before certification} {--json= : Write the machine-readable certification report to this path}';
    protected $description = 'Certify Titan Ledger production readiness against the live Laravel/MySQL host.';

    public function handle(LedgerProductionCertificationService $certification, LedgerProductionDatabaseHardener $hardener): int
    {
        try {
            if ((bool) $this->option('repair')) $hardener->repair();
            $report = $certification->certify();
        } catch (Throwable $e) {
            $report = ['schema_version'=>1,'extension'=>'titan-ledger','version'=>'1.16.0-rc.1','status'=>'FAIL','host_certified'=>false,'error'=>$e->getMessage()];
        }

        $json = (string) json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $path = trim((string) ($this->option('json') ?? ''));
        if ($path !== '') {
            if (@file_put_contents($path, $json . PHP_EOL) === false) {
                $this->error('Unable to write certification report: ' . $path);
                return self::FAILURE;
            }
        }
        $this->line($json);
        return ($report['status'] ?? 'FAIL') === 'PASS' ? self::SUCCESS : self::FAILURE;
    }
}
