<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Console;

use App\Extensions\TitanLedger\System\Signal\LedgerSignalOutboxService;
use Illuminate\Console\Command;

final class DrainLedgerSignalsCommand extends Command
{
    protected $signature = 'titan-ledger:signal-drain {--limit=100 : Maximum pending events to attempt}';
    protected $description = 'Deliver pending Titan Ledger financial events to the bound Titan Signal publisher.';

    public function handle(LedgerSignalOutboxService $outbox): int
    {
        $report = $outbox->drain((int)$this->option('limit'));
        $this->line(json_encode($report, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        return ($report['gateway_available'] ?? false) ? self::SUCCESS : self::FAILURE;
    }
}
