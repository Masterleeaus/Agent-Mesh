<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

use RuntimeException;

final class UnavailableLedgerCommandBusGateway implements LedgerCommandBusGatewayContract
{
    public function dispatch(array $command): array
    {
        throw new RuntimeException('Titan Command Bus gateway is unavailable. Titan Ledger mutations fail closed.');
    }
    public function available(): bool { return false; }
}
