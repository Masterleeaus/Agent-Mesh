<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Spend;

use InvalidArgumentException;

final class SpendAccountingJournalMapper
{
    public static function billLines(array $fact,array $accounts,array $splits): array
    {
        self::requireAccounts($accounts,['accounts_payable','gst_receivable']);$subtotal=(int)$fact['subtotal_minor'];$gst=(int)$fact['gst_minor'];$total=(int)$fact['total_minor'];self::assertSplitTotal($splits,$subtotal);$lines=self::debitSplits($splits);if($gst>0)$lines[]=self::line($accounts['gst_receivable'],'GST receivable on supplier bill',$gst,0,'bas_excluded');$lines[]=self::line($accounts['accounts_payable'],'Supplier bill payable',0,$total,'bas_excluded');return $lines;
    }
    public static function creditLines(array $fact,array $accounts,array $splits): array
    {
        self::requireAccounts($accounts,['accounts_payable','gst_receivable']);$subtotal=(int)$fact['subtotal_minor'];$gst=(int)$fact['gst_minor'];$total=(int)$fact['total_minor'];self::assertSplitTotal($splits,$subtotal);$lines=[self::line($accounts['accounts_payable'],'Supplier credit reduces payable',$total,0,'bas_excluded')];foreach($splits as $split)$lines[]=self::line((string)$split['account_public_id'],'Supplier credit allocation',0,(int)$split['amount_minor'],'bas_excluded');if($gst>0)$lines[]=self::line($accounts['gst_receivable'],'Reverse GST receivable on supplier credit',0,$gst,'bas_excluded');return $lines;
    }
    public static function paymentLines(array $fact,array $accounts,int $apAllocationMinor,int $prepaymentMinor): array
    {
        self::requireAccounts($accounts,['accounts_payable','supplier_prepayments','merchant_fees','bank','cash_on_hand','credit_card_payable']);$amount=(int)$fact['amount_minor'];$fee=(int)$fact['fee_minor'];if($apAllocationMinor<0||$prepaymentMinor<0||$apAllocationMinor+$prepaymentMinor!==$amount)throw new InvalidArgumentException('Supplier payment allocation does not balance.');$lines=[];if($apAllocationMinor>0)$lines[]=self::line($accounts['accounts_payable'],'Supplier payable settlement',$apAllocationMinor,0,'bas_excluded');if($prepaymentMinor>0)$lines[]=self::line($accounts['supplier_prepayments'],'Supplier prepayment',$prepaymentMinor,0,'bas_excluded');if($fee>0)$lines[]=self::line($accounts['merchant_fees'],'Supplier payment fee',$fee,0,'gst_free');$lines[]=self::line(self::fundingAccount((string)$fact['rail'],$accounts),'Supplier payment funding',0,$amount+$fee,'bas_excluded');return $lines;
    }
    public static function actualLines(array $fact,array $accounts,array $splits): array
    {
        self::requireAccounts($accounts,['gst_receivable','merchant_fees','bank','cash_on_hand','credit_card_payable']);$subtotal=(int)$fact['subtotal_minor'];$gst=(int)$fact['gst_minor'];$fee=(int)$fact['fee_minor'];self::assertSplitTotal($splits,$subtotal);$lines=self::debitSplits($splits);if($gst>0)$lines[]=self::line($accounts['gst_receivable'],'GST receivable on spend',$gst,0,'bas_excluded');if($fee>0)$lines[]=self::line($accounts['merchant_fees'],'Spend funding fee',$fee,0,'gst_free');$lines[]=self::line(self::fundingAccount((string)$fact['rail'],$accounts),'Spend funding',0,(int)$fact['total_minor']+$fee,'bas_excluded');return $lines;
    }
    private static function fundingAccount(string $rail,array $accounts): string{return $rail==='cash'?$accounts['cash_on_hand']:($rail==='card'?$accounts['credit_card_payable']:$accounts['bank']);}
    private static function debitSplits(array $splits): array{$lines=[];foreach($splits as $split)$lines[]=self::line((string)$split['account_public_id'],'Spend allocation',(int)$split['amount_minor'],0,'bas_excluded');return $lines;}
    private static function assertSplitTotal(array $splits,int $subtotal): void{$sum=0;foreach($splits as $s){if(empty($s['account_public_id'])||(int)($s['amount_minor']??0)<1)throw new InvalidArgumentException('Resolved spend split is invalid.');$sum+=(int)$s['amount_minor'];}if($sum!==$subtotal)throw new InvalidArgumentException('Resolved spend splits do not equal subtotal.');}
    private static function requireAccounts(array $accounts,array $keys): void{foreach($keys as $key)if(trim((string)($accounts[$key]??''))==='')throw new InvalidArgumentException('Required Ledger system account unavailable: '.$key.'.');}
    private static function line(string $account,string $description,int $debit,int $credit,string $taxCode): array{return ['account_public_id'=>$account,'description'=>$description,'debit_minor'=>$debit,'credit_minor'=>$credit,'tax_code'=>$taxCode,'tax_amount_minor'=>0,'metadata'=>null];}
}
