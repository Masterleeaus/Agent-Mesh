<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

use RuntimeException;

final class UnavailableLedgerRiskGateway implements LedgerRiskGatewayContract
{
    public function evaluate(array $evidence): array { throw new RuntimeException('Titan Risk gateway is unavailable. Titan Ledger mutations fail closed.'); }
    public function available(): bool { return false; }
}
