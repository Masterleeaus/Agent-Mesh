<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use InvalidArgumentException;

final class GstSnapshotPolicy
{
    public function assertPrepareAllowed(string $reportingMethod,string $accountingBasis,string $start,string $end): void
    {
        if(!in_array($reportingMethod,['simpler_bas','full_bas'],true))throw new InvalidArgumentException('GST reporting method must be simpler_bas or full_bas.');
        if($accountingBasis!=='accrual')throw new InvalidArgumentException('Cash-basis GST finalization is unavailable until payment-level GST allocation evidence is implemented.');
        $s=\DateTimeImmutable::createFromFormat('!Y-m-d',$start);$e=\DateTimeImmutable::createFromFormat('!Y-m-d',$end);
        if(!$s||$s->format('Y-m-d')!==$start||!$e||$e->format('Y-m-d')!==$end||$s>$e)throw new InvalidArgumentException('GST period dates are invalid.');
    }

    public function assertFinalizeAllowed(array $snapshot,string $storedSourceFingerprint,string $currentSourceFingerprint): void
    {
        if((string)($snapshot['status']??'')!=='prepared')throw new InvalidArgumentException('Only a prepared GST snapshot can be finalized.');
        if(!(bool)($snapshot['lodgement_ready']??false))throw new InvalidArgumentException('GST snapshot requires review before finalization.');
        if(!hash_equals($storedSourceFingerprint,$currentSourceFingerprint))throw new InvalidArgumentException('GST source evidence changed after preparation; prepare a new snapshot.');
    }
}
