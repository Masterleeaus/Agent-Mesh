<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

interface LedgerAssuranceGatewayContract
{
    /** @param array<string,mixed> $evidence */
    public function verify(array $evidence): array;
    public function available(): bool;
}
