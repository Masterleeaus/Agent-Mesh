<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Banking;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final class BankStatementFact
{
    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function statement(array $input): array
    {
        $statementId=self::id($input,'statement_public_id',100);
        $accountId=self::id($input,'account_public_id',100);
        $currency=strtoupper(trim((string)($input['currency']??'')));
        if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Bank statement currency must be ISO-4217 style.');
        $start=self::date($input['period_start']??null,'period_start');
        $end=self::date($input['period_end']??null,'period_end');
        if($start>$end)throw new InvalidArgumentException('Bank statement period_start must not be after period_end.');
        $opening=self::integer($input,'opening_balance_minor');$closing=self::integer($input,'closing_balance_minor');
        $sourceEvent=self::id($input,'source_event_id',120);$sourceVersion=max(1,(int)($input['source_version']??1));
        $sourceExtension=trim((string)($input['source_extension']??'bank-feed'))?:'bank-feed';if(strlen($sourceExtension)>100)throw new InvalidArgumentException('source_extension is too long.');
        $rows=$input['transactions']??null;if(!is_array($rows))throw new InvalidArgumentException('Bank statement transactions are required.');
        $transactions=[];$seen=[];$movement=0;
        foreach($rows as $row){
            if(!is_array($row))throw new InvalidArgumentException('Bank statement transactions must contain objects.');
            $txId=self::id($row,'transaction_public_id',100);if(isset($seen[$txId]))throw new InvalidArgumentException('Bank statement transaction_public_id values must be unique.');$seen[$txId]=true;
            $posted=self::instant($row['posted_at']??null,'posted_at');$postedOn=substr($posted,0,10);if($postedOn<$start||$postedOn>$end)throw new InvalidArgumentException('Bank statement transaction date must fall inside the statement period.');
            $amount=self::integer($row,'amount_minor');if($amount===0)throw new InvalidArgumentException('Bank statement transaction amount_minor must be non-zero.');
            $movement+=$amount;
            $reference=trim((string)($row['reference']??''));if(strlen($reference)>500)throw new InvalidArgumentException('Bank statement transaction reference is too long.');
            $referenceHash=$reference===''?null:hash('sha256',strtolower(preg_replace('/\s+/',' ',$reference)??$reference));
            $classification=strtolower(trim((string)($row['classification_hint']??'unknown')));
            if(!in_array($classification,['unknown','bank_fee','interest_income','interest_expense','transfer'],true))throw new InvalidArgumentException('Bank statement classification_hint is unsupported.');
            $transactions[]=['transaction_public_id'=>$txId,'posted_at'=>$posted,'posted_on'=>$postedOn,'amount_minor'=>$amount,'reference_hash'=>$referenceHash,'classification_hint'=>$classification];
        }
        if($opening+$movement!==$closing)throw new InvalidArgumentException('Bank statement opening balance plus transaction movement does not reconcile to closing balance.');
        return [
            'statement_public_id'=>$statementId,'account_public_id'=>$accountId,'currency'=>$currency,'period_start'=>$start,'period_end'=>$end,
            'opening_balance_minor'=>$opening,'closing_balance_minor'=>$closing,'movement_minor'=>$movement,'transaction_count'=>count($transactions),
            'source_event_id'=>$sourceEvent,'source_version'=>$sourceVersion,'source_extension'=>$sourceExtension,'transactions'=>$transactions,
        ];
    }

    /** @param array<string,mixed> $fact */
    public static function hash(array $fact): string{return hash('sha256',self::canonicalJson($fact));}
    private static function id(array $a,string $k,int $max): string{$v=trim((string)($a[$k]??''));if($v===''||strlen($v)>$max)throw new InvalidArgumentException($k.' is required.');return $v;}
    private static function integer(array $a,string $k): int{if(!array_key_exists($k,$a)||filter_var($a[$k],FILTER_VALIDATE_INT)===false)throw new InvalidArgumentException($k.' must be an integer minor-unit amount.');return (int)$a[$k];}
    private static function date(mixed $v,string $k): string{try{$d=new DateTimeImmutable((string)$v);}catch(\Throwable){throw new InvalidArgumentException($k.' is invalid.');}return $d->format('Y-m-d');}
    private static function instant(mixed $v,string $k): string{try{$d=new DateTimeImmutable((string)$v);}catch(\Throwable){throw new InvalidArgumentException($k.' is invalid.');}return $d->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');}
    private static function canonicalJson(array $v): string{return (string)json_encode(self::canonicalize($v),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}private static function canonicalize(mixed $v): mixed{if(!is_array($v))return $v;if(array_is_list($v))return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
}
