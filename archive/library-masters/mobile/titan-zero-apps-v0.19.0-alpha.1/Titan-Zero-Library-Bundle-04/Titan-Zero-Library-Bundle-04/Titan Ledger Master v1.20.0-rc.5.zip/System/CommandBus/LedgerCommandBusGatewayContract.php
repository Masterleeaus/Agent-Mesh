<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

interface LedgerCommandBusGatewayContract
{
    /** @param array<string,mixed> $command */
    public function dispatch(array $command): array;
    public function available(): bool;
}
