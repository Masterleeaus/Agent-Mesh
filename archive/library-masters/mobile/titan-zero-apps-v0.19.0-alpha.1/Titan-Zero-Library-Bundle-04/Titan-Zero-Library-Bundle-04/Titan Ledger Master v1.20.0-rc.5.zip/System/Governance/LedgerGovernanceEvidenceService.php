<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

final class LedgerGovernanceEvidenceService
{
    public function __construct(private LedgerRiskGatewayContract $risk, private LedgerAssuranceGatewayContract $assurance) {}
    /** @param array<string,mixed> $command */
    public function evaluate(array $command): array
    {
        $bounded=LedgerGovernanceEvidenceBuilder::build($command);
        $risk=LedgerExternalDecisionNormalizer::risk($this->risk->evaluate($bounded));
        $assuranceInput=$bounded+['risk'=>$risk];
        $assurance=LedgerExternalDecisionNormalizer::assurance($this->assurance->verify($assuranceInput));
        return $risk+$assurance;
    }
    public function diagnostics(): array { return ['risk_available'=>$this->risk->available(),'assurance_available'=>$this->assurance->available()]; }
}
