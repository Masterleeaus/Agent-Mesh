<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

final class ReconciliationBalanceVerifier
{
    /** @param array<int,array<string,mixed>> $transactions @param array<int,string> $matchedTransactionIds @return array<string,mixed> */
    public static function verify(int $openingBalanceMinor,int $closingBalanceMinor,array $transactions,array $matchedTransactionIds): array
    {
        $matched=array_fill_keys($matchedTransactionIds,true);$movement=0;$reconciled=0;$unmatched=0;
        foreach($transactions as $tx){$amount=(int)($tx['amount_minor']??0);$movement+=$amount;$id=(string)($tx['transaction_public_id']??'');if($id!==''&&isset($matched[$id]))$reconciled+=$amount;else$unmatched++;}
        $computed=$openingBalanceMinor+$movement;$unreconciled=$movement-$reconciled;
        return ['statement_balanced'=>$computed===$closingBalanceMinor,'fully_reconciled'=>$computed===$closingBalanceMinor&&$unmatched===0,'opening_balance_minor'=>$openingBalanceMinor,'statement_movement_minor'=>$movement,'reconciled_movement_minor'=>$reconciled,'unreconciled_movement_minor'=>$unreconciled,'computed_closing_balance_minor'=>$computed,'statement_closing_balance_minor'=>$closingBalanceMinor,'unmatched_count'=>$unmatched];
    }
}
