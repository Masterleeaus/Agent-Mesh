<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Http\Controllers;

use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class FinancialYearCloseController extends Controller
{
    public function __construct(private FinancialYearCloseService $service) {}
    public function preview(Request $request,string $financialYear){return response()->json($this->service->preview((int)$request->user()->id,$financialYear));}
    public function index(Request $request){return response()->json(['data'=>$this->service->all((int)$request->user()->id,(int)$request->query('limit',200))]);}
}
