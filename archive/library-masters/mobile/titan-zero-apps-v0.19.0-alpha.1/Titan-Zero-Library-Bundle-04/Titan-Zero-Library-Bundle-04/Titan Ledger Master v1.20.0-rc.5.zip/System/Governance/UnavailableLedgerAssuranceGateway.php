<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Governance;

use RuntimeException;

final class UnavailableLedgerAssuranceGateway implements LedgerAssuranceGatewayContract
{
    public function verify(array $evidence): array { throw new RuntimeException('Titan Assurance gateway is unavailable. Titan Ledger mutations fail closed.'); }
    public function available(): bool { return false; }
}
