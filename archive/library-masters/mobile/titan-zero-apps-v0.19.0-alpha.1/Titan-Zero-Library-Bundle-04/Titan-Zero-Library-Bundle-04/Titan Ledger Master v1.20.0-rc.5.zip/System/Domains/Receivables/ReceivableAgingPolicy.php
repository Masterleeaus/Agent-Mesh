<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Receivables;

use DateTimeImmutable;
use InvalidArgumentException;

final class ReceivableAgingPolicy
{
    /** @return array{bucket:string,days_past_due:?int,is_overdue:bool,due_date_known:bool} */
    public static function classify(?string $dueDate,string $asOfDate,int $outstandingMinor): array
    {
        if ($outstandingMinor < 0) throw new InvalidArgumentException('Receivable outstanding amount cannot be negative.');
        if ($outstandingMinor === 0) return ['bucket'=>'settled','days_past_due'=>0,'is_overdue'=>false,'due_date_known'=>$dueDate!==null && trim($dueDate)!==''];
        if ($dueDate === null || trim($dueDate)==='') return ['bucket'=>'unknown_due_date','days_past_due'=>null,'is_overdue'=>false,'due_date_known'=>false];
        try { $due=new DateTimeImmutable($dueDate); $asOf=new DateTimeImmutable($asOfDate); }
        catch (\Throwable) { throw new InvalidArgumentException('Receivable aging dates are invalid.'); }
        $due=$due->setTime(0,0); $asOf=$asOf->setTime(0,0);
        if ($asOf <= $due) return ['bucket'=>'current','days_past_due'=>0,'is_overdue'=>false,'due_date_known'=>true];
        $days=(int)$due->diff($asOf)->format('%a');
        $bucket=$days<=30?'1_30':($days<=60?'31_60':($days<=90?'61_90':'91_plus'));
        return ['bucket'=>$bucket,'days_past_due'=>$days,'is_overdue'=>true,'due_date_known'=>true];
    }
}
