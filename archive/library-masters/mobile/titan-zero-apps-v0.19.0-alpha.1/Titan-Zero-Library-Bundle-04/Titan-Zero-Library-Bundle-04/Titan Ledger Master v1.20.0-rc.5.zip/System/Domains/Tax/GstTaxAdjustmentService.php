<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GstTaxAdjustmentService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext,private GstAdjustmentPolicy $policy){}

    public function record(int $userId,string $periodKey,array $payload,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$periodKey=$this->periodKey($periodKey);$n=$this->policy->normalizeRecord($payload);
        return $this->db->transaction(function()use($userId,$companyId,$periodKey,$n,$operationId,$command){
            $existing=$this->db->table('titan_ledger_gst_adjustments')->where('company_id',$companyId)->where('operation_id',$operationId)->first();if($existing)return $this->result((array)$existing);
            if($n['journal_public_id']!==null){$journal=$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('public_id',$n['journal_public_id'])->where('status','posted')->first();if(!$journal)throw new InvalidArgumentException('GST financial adjustment journal must exist, belong to the company and be posted.');}
            $hashPayload=$n+['company_id'=>$companyId,'period_key'=>$periodKey];$factHash=hash('sha256',json_encode($hashPayload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));$row=['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'period_key'=>$periodKey]+$n+['fact_hash'=>$factHash,'operation_id'=>$operationId,'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'created_by_user_id'=>$this->companyContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now()];
            $this->db->table('titan_ledger_gst_adjustments')->insert($row);$row['review_status']='pending';$row['review_public_id']=null;return $this->result($row);
        });
    }

    public function review(int $userId,string $adjustmentPublicId,array $payload,string $operationId,array $command): array
    {
        $companyId=$this->companyContext->companyId($userId);$n=$this->policy->normalizeReview($payload);
        return $this->db->transaction(function()use($userId,$companyId,$adjustmentPublicId,$n,$operationId,$command){
            $adj=$this->db->table('titan_ledger_gst_adjustments')->where('company_id',$companyId)->where('public_id',$adjustmentPublicId)->lockForUpdate()->first();if(!$adj)throw new InvalidArgumentException('GST adjustment not found.');
            $existing=$this->db->table('titan_ledger_gst_adjustment_reviews')->where('company_id',$companyId)->where('operation_id',$operationId)->first();if($existing)return $this->reviewResult((array)$existing);
            $row=['public_id'=>(string)Str::ulid(),'company_id'=>$companyId,'adjustment_public_id'=>$adjustmentPublicId,'decision'=>$n['decision'],'reason_code'=>$n['reason_code'],'operation_id'=>$operationId,'trace_id'=>$command['trace_id']??null,'correlation_id'=>$command['correlation_id']??null,'causation_id'=>$command['causation_id']??null,'reviewed_by_user_id'=>$this->companyContext->actorUserId($userId),'reviewed_at'=>now(),'created_at'=>now()];$this->db->table('titan_ledger_gst_adjustment_reviews')->insert($row);return $this->reviewResult($row);
        });
    }

    public function all(int $userId,int $limit=500): array
    {
        $companyId=$this->companyContext->companyId($userId);$rows=$this->db->table('titan_ledger_gst_adjustments')->where('company_id',$companyId)->orderByDesc('effective_date')->orderByDesc('id')->limit(max(1,min($limit,1000)))->get()->map(fn($r)=>(array)$r)->all();
        return array_map(fn(array $row)=>$this->result($row),$this->attachLatestReviews($companyId,$rows));
    }

    /** @return array<int,array<string,mixed>> */
    public function forPeriod(int $companyId,string $start,string $end): array
    {
        $rows=$this->db->table('titan_ledger_gst_adjustments')->where('company_id',$companyId)->whereDate('effective_date','>=',$start)->whereDate('effective_date','<=',$end)->orderBy('id')->limit(5000)->get()->map(fn($r)=>(array)$r)->all();
        return $this->attachLatestReviews($companyId,$rows);
    }

    /** @param array<int,array<string,mixed>> $rows @return array<int,array<string,mixed>> */
    private function attachLatestReviews(int $companyId,array $rows): array
    {
        $ids=array_values(array_filter(array_map(fn(array $r)=>(string)($r['public_id']??''),$rows)));if($ids===[])return $rows;
        $reviews=$this->db->table('titan_ledger_gst_adjustment_reviews')->where('company_id',$companyId)->whereIn('adjustment_public_id',$ids)->orderByDesc('id')->get();$latest=[];
        foreach($reviews as $review){$id=(string)$review->adjustment_public_id;if(!isset($latest[$id]))$latest[$id]=$review;}
        foreach($rows as &$row){$review=$latest[(string)$row['public_id']]??null;$row['review_status']=$review?(string)$review->decision:'pending';$row['review_public_id']=$review?(string)$review->public_id:null;}unset($row);return $rows;
    }

    private function periodKey(string $k): string{$k=trim($k);if(!preg_match('/^[A-Za-z0-9._:-]{1,80}$/',$k))throw new InvalidArgumentException('GST adjustment period key is invalid.');return $k;}
    private function result(array $r): array{return array_intersect_key($r,array_flip(['public_id','period_key','adjustment_type','effective_date','gross_amount_minor','gst_amount_minor','claimable_percent_bps','journal_public_id','reference_public_id','reason_code','g1_delta_minor','one_a_delta_minor','one_b_delta_minor','g2_delta_minor','g3_delta_minor','g10_delta_minor','g11_delta_minor','purchases_delta_minor','fact_hash','review_status','review_public_id','created_at']));}
    private function reviewResult(array $r): array{return array_intersect_key($r,array_flip(['public_id','adjustment_public_id','decision','reason_code','reviewed_by_user_id','reviewed_at']));}
}
