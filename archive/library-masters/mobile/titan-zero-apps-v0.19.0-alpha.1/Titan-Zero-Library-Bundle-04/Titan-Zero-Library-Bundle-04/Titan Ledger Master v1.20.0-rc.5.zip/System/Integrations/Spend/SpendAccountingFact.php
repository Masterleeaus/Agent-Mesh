<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Spend;

use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final class SpendAccountingFact
{
    private const RAILS=['payid','bank_transfer','cash','card','paypal','direct_debit'];

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function bill(array $input): array
    {
        $bill=self::requiredId($input,'bill_public_id');
        $base=self::documentBase($input,'supplier_bill',$bill,null,'issued_at');
        return $base+self::purchaseAmounts($input)+['bill_public_id'=>$bill,'account_splits'=>self::splits($input)];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function creditNote(array $input): array
    {
        $credit=self::requiredId($input,'credit_public_id');$bill=self::requiredId($input,'original_bill_public_id');
        $base=self::documentBase($input,'supplier_credit',$credit,$bill,'issued_at');
        return $base+self::purchaseAmounts($input)+['credit_public_id'=>$credit,'original_bill_public_id'=>$bill,'account_splits'=>self::splits($input)];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function payment(array $input): array
    {
        $payment=self::requiredId($input,'payment_public_id');$bill=self::requiredId($input,'bill_public_id');
        $amount=self::positiveMinor($input,'amount_minor');$fee=self::nonNegativeMinor($input,'fee_minor');$rail=self::rail($input);
        $base=self::common($input,'paid_at');
        return $base+['payment_type'=>'supplier_payment','document_public_id'=>$payment,'payment_public_id'=>$payment,'bill_public_id'=>$bill,'supplier_public_id'=>self::requiredId($input,'supplier_public_id'),'rail'=>$rail,'amount_minor'=>$amount,'fee_minor'=>$fee,'funding_movement_minor'=>$amount+$fee];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    public static function actual(array $input): array
    {
        $spend=self::requiredId($input,'spend_public_id');$base=self::common($input,'spent_at');$amounts=self::purchaseAmounts($input);$fee=self::nonNegativeMinor($input,'fee_minor');
        return $base+$amounts+['spend_type'=>'actual','document_public_id'=>$spend,'spend_public_id'=>$spend,'supplier_public_id'=>self::nullableId($input,'supplier_public_id'),'rail'=>self::rail($input),'fee_minor'=>$fee,'funding_movement_minor'=>$amounts['total_minor']+$fee,'account_splits'=>self::splits($input)];
    }

    /** @param array<string,mixed> $fact */
    public static function hash(array $fact): string { return hash('sha256',self::canonicalJson($fact)); }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private static function documentBase(array $input,string $type,string $documentId,?string $billId,string $dateField): array
    {
        $base=self::common($input,$dateField);
        return $base+['document_type'=>$type,'document_public_id'=>$documentId,'bill_public_id'=>$billId??$documentId,'supplier_public_id'=>self::requiredId($input,'supplier_public_id'),'due_at'=>self::nullableDate($input['due_at']??null)];
    }

    /** @param array<string,mixed> $input @return array<string,mixed> */
    private static function common(array $input,string $dateField): array
    {
        $currency=strtoupper(trim((string)($input['currency']??'')));if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Spend fact currency must be ISO-4217 style.');
        $raw=trim((string)($input[$dateField]??''));if($raw==='')throw new InvalidArgumentException($dateField.' is required.');try{$dt=new DateTimeImmutable($raw);}catch(\Throwable){throw new InvalidArgumentException($dateField.' is invalid.');}
        $event=trim((string)($input['source_event_id']??''));if($event===''||strlen($event)>120)throw new InvalidArgumentException('source_event_id is required.');
        return ['currency'=>$currency,'occurred_at'=>$dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),'entry_date'=>$dt->format('Y-m-d'),'source_event_id'=>$event,'source_version'=>max(1,(int)($input['source_version']??1)),'source_extension'=>trim((string)($input['source_extension']??'titan-budgeting'))?:'titan-budgeting'];
    }

    /** @param array<string,mixed> $input @return array{subtotal_minor:int,gst_minor:int,total_minor:int} */
    private static function purchaseAmounts(array $input): array
    {
        $subtotal=self::positiveMinor($input,'subtotal_minor');$gst=self::nonNegativeMinor($input,'gst_minor');$total=self::positiveMinor($input,'total_minor');if($subtotal+$gst!==$total)throw new InvalidArgumentException('Spend subtotal/GST/total arithmetic does not balance.');return ['subtotal_minor'=>$subtotal,'gst_minor'=>$gst,'total_minor'=>$total];
    }

    /** @param array<string,mixed> $input @return array<int,array{account_code:string,amount_minor:int}> */
    private static function splits(array $input): array
    {
        $rows=$input['account_splits']??null;if(!is_array($rows)||$rows===[])throw new InvalidArgumentException('account_splits are required.');$out=[];$sum=0;
        foreach($rows as $row){if(!is_array($row))throw new InvalidArgumentException('account_splits must contain objects.');$code=trim((string)($row['account_code']??''));if($code===''||strlen($code)>30)throw new InvalidArgumentException('Each spend account split requires account_code.');if(filter_var($row['amount_minor']??null,FILTER_VALIDATE_INT)===false||(int)$row['amount_minor']<1)throw new InvalidArgumentException('Each spend account split requires a positive integer amount_minor.');$amount=(int)$row['amount_minor'];$sum+=$amount;$out[]=['account_code'=>$code,'amount_minor'=>$amount];}
        $subtotal=self::positiveMinor($input,'subtotal_minor');if($sum!==$subtotal)throw new InvalidArgumentException('Spend account splits must equal subtotal_minor.');return $out;
    }

    /** @param array<string,mixed> $input */
    private static function rail(array $input): string{$rail=strtolower(trim((string)($input['rail']??'')));if(!in_array($rail,self::RAILS,true))throw new InvalidArgumentException('Unsupported spend funding rail.');return $rail;}
    /** @param array<string,mixed> $input */
    private static function requiredId(array $input,string $key): string{$v=trim((string)($input[$key]??''));if($v===''||strlen($v)>100)throw new InvalidArgumentException($key.' is required and must be at most 100 characters.');return $v;}
    /** @param array<string,mixed> $input */
    private static function nullableId(array $input,string $key): ?string{$v=trim((string)($input[$key]??''));if($v==='')return null;if(strlen($v)>100)throw new InvalidArgumentException($key.' must be at most 100 characters.');return $v;}
    /** @param array<string,mixed> $input */
    private static function positiveMinor(array $input,string $key): int{$v=self::integerMinor($input,$key);if($v<1)throw new InvalidArgumentException($key.' must be positive.');return $v;}
    /** @param array<string,mixed> $input */
    private static function nonNegativeMinor(array $input,string $key): int{$v=self::integerMinor($input,$key);if($v<0)throw new InvalidArgumentException($key.' must not be negative.');return $v;}
    /** @param array<string,mixed> $input */
    private static function integerMinor(array $input,string $key): int{if(!array_key_exists($key,$input)||filter_var($input[$key],FILTER_VALIDATE_INT)===false)throw new InvalidArgumentException($key.' must be an integer minor-unit amount.');return (int)$input[$key];}
    private static function nullableDate(mixed $value): ?string{if($value===null||trim((string)$value)==='')return null;try{return (new DateTimeImmutable((string)$value))->format('Y-m-d');}catch(\Throwable){throw new InvalidArgumentException('due_at is invalid.');}}
    private static function canonicalJson(array $value): string{return (string)json_encode(self::canonicalize($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}private static function canonicalize(mixed $value): mixed{if(!is_array($value))return $value;if(array_is_list($value))return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}
}
