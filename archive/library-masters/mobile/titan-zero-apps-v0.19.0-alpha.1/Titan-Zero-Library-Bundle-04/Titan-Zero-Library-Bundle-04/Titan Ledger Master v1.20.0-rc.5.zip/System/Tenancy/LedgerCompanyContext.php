<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Tenancy;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use RuntimeException;

final class LedgerCompanyContext
{
    public function companyId(int $userId): int
    {
        $companyId = null;

        if (is_callable([CrmCompanyScope::class, 'companyId'])) {
            $companyId = (int) CrmCompanyScope::companyId($userId);
        } elseif (is_callable([CrmCompanyScope::class, 'companyId'])) {
            // Compatibility only for CRM generations that exposed the old resolver name.
            $companyId = (int) CrmCompanyScope::companyId($userId);
        }

        if (! is_int($companyId) || $companyId < 1) {
            throw new RuntimeException('Titan Ledger could not resolve a valid canonical company_id.');
        }

        return $companyId;
    }

    public function actorUserId(int $userId): int
    {
        if (is_callable([CrmCompanyScope::class, 'actorUserId'])) {
            $actorUserId = (int) CrmCompanyScope::actorUserId($userId);
            if ($actorUserId > 0) return $actorUserId;
        }

        if ($userId < 1) throw new RuntimeException('Titan Ledger could not resolve a valid actor user id.');

        return $userId;
    }
}
