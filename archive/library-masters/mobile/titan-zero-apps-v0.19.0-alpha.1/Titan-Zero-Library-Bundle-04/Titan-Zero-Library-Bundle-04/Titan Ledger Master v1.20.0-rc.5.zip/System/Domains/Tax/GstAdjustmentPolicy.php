<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Tax;

use InvalidArgumentException;

final class GstAdjustmentPolicy
{
    private const TYPES=['bad_debt_writeoff','bad_debt_recovery','mixed_acquisition','input_taxed_adjustment','export_sales_classification','gst_free_sales_classification','capital_purchase_classification','noncapital_purchase_classification','other_gst_adjustment'];
    private const CLASSIFICATION=['export_sales_classification','gst_free_sales_classification','capital_purchase_classification','noncapital_purchase_classification'];

    /** @return array<string,mixed> */
    public function normalizeRecord(array $input): array
    {
        $type=trim((string)($input['adjustment_type']??''));if(!in_array($type,self::TYPES,true))throw new InvalidArgumentException('GST adjustment type is invalid.');
        $effective=(string)($input['effective_date']??'');$d=\DateTimeImmutable::createFromFormat('!Y-m-d',$effective);if(!$d||$d->format('Y-m-d')!==$effective)throw new InvalidArgumentException('GST adjustment effective_date is invalid.');
        $gross=$this->nonNegative($input,'gross_amount_minor');$gst=$this->nonNegative($input,'gst_amount_minor');$bps=(int)($input['claimable_percent_bps']??0);if($type==='mixed_acquisition'&&($gst<1||$bps<0||$bps>10000))throw new InvalidArgumentException('Mixed acquisition requires GST amount and claimable percent.');
        if(in_array($type,['bad_debt_writeoff','bad_debt_recovery'],true)&&($gross<1||$gst<0))throw new InvalidArgumentException('Bad-debt adjustment requires gross amount.');
        if(in_array($type,self::CLASSIFICATION,true)&&$gross<1)throw new InvalidArgumentException('BAS classification requires a positive gross amount.');
        $journal=$this->nullableId($input['journal_public_id']??null,26);$financialImpact=in_array($type,['bad_debt_writeoff','bad_debt_recovery','mixed_acquisition','input_taxed_adjustment'],true)||$this->hasTaxDelta($input);
        if($financialImpact&&$journal===null)throw new InvalidArgumentException('GST financial adjustment requires a posted Ledger journal reference.');
        $reason=trim((string)($input['reason_code']??''));if($reason===''||strlen($reason)>80||!preg_match('/^[a-z0-9._:-]+$/i',$reason))throw new InvalidArgumentException('GST adjustment requires a bounded reason_code.');
        $reference=$this->nullableId($input['reference_public_id']??null,120);
        $out=['adjustment_type'=>$type,'effective_date'=>$effective,'gross_amount_minor'=>$gross,'gst_amount_minor'=>$gst,'claimable_percent_bps'=>$bps,'journal_public_id'=>$journal,'reference_public_id'=>$reference,'reason_code'=>$reason];
        foreach(['g1_delta_minor','one_a_delta_minor','one_b_delta_minor','g2_delta_minor','g3_delta_minor','g10_delta_minor','g11_delta_minor','purchases_delta_minor'] as $k)$out[$k]=$this->signed($input,$k);
        if($type==='other_gst_adjustment'&&!$this->hasAnyDelta($out))throw new InvalidArgumentException('Other GST adjustment requires at least one non-zero BAS delta.');
        return $out;
    }

    /** @return array{decision:string,reason_code:string} */
    public function normalizeReview(array $input): array
    {
        $decision=strtolower(trim((string)($input['decision']??'')));if(!in_array($decision,['approved','rejected'],true))throw new InvalidArgumentException('GST adjustment review decision must be approved or rejected.');
        $reason=trim((string)($input['reason_code']??''));if($reason===''||strlen($reason)>80||!preg_match('/^[a-z0-9._:-]+$/i',$reason))throw new InvalidArgumentException('GST adjustment review requires a bounded reason_code.');
        return ['decision'=>$decision,'reason_code'=>$reason];
    }

    private function nonNegative(array $i,string $k): int{$v=$i[$k]??0;if(!is_int($v)||$v<0)throw new InvalidArgumentException($k.' must be a non-negative integer minor-unit amount.');return $v;}
    private function signed(array $i,string $k): int{$v=$i[$k]??0;if(!is_int($v))throw new InvalidArgumentException($k.' must be an integer minor-unit amount.');return $v;}
    private function nullableId(mixed $v,int $max): ?string{if($v===null||$v==='')return null;$s=trim((string)$v);if($s===''||strlen($s)>$max)throw new InvalidArgumentException('GST adjustment reference is invalid.');return $s;}
    private function hasTaxDelta(array $i): bool{return ((int)($i['one_a_delta_minor']??0)!==0)||((int)($i['one_b_delta_minor']??0)!==0);}
    private function hasAnyDelta(array $i): bool{foreach(['g1_delta_minor','one_a_delta_minor','one_b_delta_minor','g2_delta_minor','g3_delta_minor','g10_delta_minor','g11_delta_minor','purchases_delta_minor'] as $k)if((int)($i[$k]??0)!==0)return true;return false;}
}
