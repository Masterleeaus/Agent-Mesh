<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Receivables;

use InvalidArgumentException;

final class ReceivableCollectionPolicy
{
    private const TRANSITIONS=[
        'normal'=>['attention'],
        'attention'=>['normal','dunning','disputed','hold'],
        'dunning'=>['normal','promise_to_pay','disputed','hold','collections'],
        'promise_to_pay'=>['dunning','disputed','hold','collections'],
        'disputed'=>['hold','dunning','normal'],
        'hold'=>['dunning','normal'],
        'collections'=>['dunning','hold','closed'],
        'closed'=>[],
    ];

    public static function allows(string $from,string $to): bool
    {
        return isset(self::TRANSITIONS[$from]) && in_array($to,self::TRANSITIONS[$from],true);
    }

    public static function assertTransition(string $from,string $to): void
    {
        if (!self::allows($from,$to)) throw new InvalidArgumentException("Invalid receivable collection transition: {$from} -> {$to}.");
    }

    /** @return array<int,string> */
    public static function states(): array { return array_keys(self::TRANSITIONS); }
}
