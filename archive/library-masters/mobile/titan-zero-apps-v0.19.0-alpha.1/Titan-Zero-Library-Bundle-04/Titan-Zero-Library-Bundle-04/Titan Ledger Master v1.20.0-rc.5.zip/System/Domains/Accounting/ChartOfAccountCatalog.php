<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Accounting;

final class ChartOfAccountCatalog
{
    public static function types(): array
    {
        return ['asset','liability','equity','revenue','cost_of_sales','expense','other_income','other_expense'];
    }

    public static function normalBalanceFor(string $type): string
    {
        return in_array($type, ['asset','cost_of_sales','expense','other_expense'], true) ? 'debit' : 'credit';
    }

    public static function australianSmeDefaults(): array
    {
        return [
            self::account('1000','Business Bank Account','asset','cash','bank','bas_excluded',true),
            self::account('1010','Cash on Hand','asset','cash','cash_on_hand','bas_excluded',true),
            self::account('1020','Payment Clearing','asset','clearing','payment_clearing','bas_excluded',true),
            self::account('1100','Accounts Receivable','asset','accounts_receivable','accounts_receivable','bas_excluded',true),
            self::account('1200','GST Receivable','asset','tax_receivable','gst_receivable','bas_excluded',true),
            self::account('1300','Inventory','asset','inventory',null,'gst_on_purchases',false),
            self::account('1400','Prepayments','asset','prepayment',null,'bas_excluded',false),
            self::account('1410','Supplier Deposits and Prepayments','asset','prepayment','supplier_prepayments','bas_excluded',true),
            self::account('1500','Plant and Equipment','asset','fixed_asset',null,'gst_on_purchases',false),
            self::account('1590','Accumulated Depreciation','asset','contra_asset',null,'bas_excluded',false),
            self::account('2000','Accounts Payable','liability','accounts_payable','accounts_payable','bas_excluded',true),
            self::account('2100','GST Payable','liability','tax_payable','gst_payable','bas_excluded',true),
            self::account('2150','Customer Credits and Overpayments','liability','customer_credit','customer_overpayments','bas_excluded',true),
            self::account('2200','PAYG Withholding Payable','liability','payroll_liability',null,'bas_excluded',false),
            self::account('2300','Superannuation Payable','liability','payroll_liability',null,'bas_excluded',false),
            self::account('2400','Credit Card Payable','liability','credit_card','credit_card_payable','bas_excluded',true),
            self::account('2500','Business Loans','liability','loan',null,'bas_excluded',false),
            self::account('3000','Owner Equity','equity','owner_equity','owner_equity','bas_excluded',true),
            self::account('3100','Retained Earnings','equity','retained_earnings','retained_earnings','bas_excluded',true),
            self::account('4000','Sales Revenue','revenue','sales','sales_revenue','gst_on_sales',true),
            self::account('4100','Service Revenue','revenue','services','service_revenue','gst_on_sales',true),
            self::account('4900','Other Revenue','revenue','other_revenue',null,'gst_on_sales',false),
            self::account('5000','Cost of Sales','cost_of_sales','direct_costs','cost_of_sales','gst_on_purchases',true),
            self::account('5100','Materials and Supplies','cost_of_sales','materials',null,'gst_on_purchases',false),
            self::account('5200','Subcontractor Costs','cost_of_sales','subcontractors',null,'gst_on_purchases',false),
            self::account('6000','Wages and Salaries','expense','payroll','wages_expense','bas_excluded',true),
            self::account('6100','Superannuation Expense','expense','payroll',null,'bas_excluded',false),
            self::account('6200','Advertising and Marketing','expense','operating',null,'gst_on_purchases',false),
            self::account('6300','Bank and Merchant Fees','expense','operating','merchant_fees','gst_free',true),
            self::account('6400','Fuel and Vehicle','expense','operating',null,'gst_on_purchases',false),
            self::account('6500','Insurance','expense','operating',null,'gst_on_purchases',false),
            self::account('6600','Office Expenses','expense','operating',null,'gst_on_purchases',false),
            self::account('6700','Rent','expense','occupancy',null,'gst_on_purchases',false),
            self::account('6800','Repairs and Maintenance','expense','operating',null,'gst_on_purchases',false),
            self::account('6900','Software and Subscriptions','expense','operating',null,'gst_on_purchases',false),
            self::account('7000','Telephone and Internet','expense','operating',null,'gst_on_purchases',false),
            self::account('7100','Travel','expense','operating',null,'gst_on_purchases',false),
            self::account('7200','Utilities','expense','operating',null,'gst_on_purchases',false),
            self::account('7900','Other Operating Expenses','expense','operating',null,'gst_on_purchases',false),
            self::account('8000','Interest Income','other_income','finance_income',null,'gst_free',false),
            self::account('9000','Interest Expense','other_expense','finance_cost',null,'gst_free',false),
        ];
    }

    private static function account(string $code, string $name, string $type, string $subtype, ?string $systemKey, string $taxCode, bool $protected): array
    {
        return [
            'code' => $code,
            'name' => $name,
            'type' => $type,
            'subtype' => $subtype,
            'normal_balance' => self::normalBalanceFor($type),
            'system_key' => $systemKey,
            'tax_code' => $taxCode,
            'is_protected' => $protected,
        ];
    }
}
