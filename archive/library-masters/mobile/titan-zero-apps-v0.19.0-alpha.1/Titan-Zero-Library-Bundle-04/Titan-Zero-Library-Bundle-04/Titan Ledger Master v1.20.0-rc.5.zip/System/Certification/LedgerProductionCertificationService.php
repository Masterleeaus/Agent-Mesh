<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Certification;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandBusGatewayContract;
use App\Extensions\TitanLedger\System\Governance\LedgerAssuranceGatewayContract;
use App\Extensions\TitanLedger\System\Governance\LedgerRiskGatewayContract;
use App\Extensions\TitanLedger\System\Navigation\TitanLedgerNavigation;
use App\Extensions\TitanLedger\System\Navigation\MenuSyncService;
use App\Extensions\TitanLedger\System\Rewind\LedgerRewindSource;
use App\Extensions\TitanLedger\System\Signal\LedgerSignalGatewayContract;
use Illuminate\Contracts\Container\Container;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Routing\Router;
use Throwable;

final class LedgerProductionCertificationService
{
    private const REQUIRED_TABLES = [
        'crm_bookkeeping_transactions','crm_bookkeeping_categories','titan_ledger_schema_ownership','titan_ledger_accounts',
        'titan_ledger_journals','titan_ledger_journal_lines','titan_ledger_financial_years','titan_ledger_accounting_periods','titan_ledger_period_lock_events',
        'titan_ledger_command_receipts','titan_ledger_signal_outbox','titan_ledger_crm_invoice_postings','titan_ledger_payment_settlements',
        'titan_ledger_receivables','titan_ledger_collection_events','titan_ledger_spend_postings','titan_ledger_payables',
        'titan_ledger_bank_statements','titan_ledger_bank_transactions','titan_ledger_reconciliation_sessions','titan_ledger_reconciliation_match_events',
        'titan_ledger_gst_tax_snapshots','titan_ledger_gst_adjustments','titan_ledger_gst_adjustment_reviews','titan_ledger_gst_snapshot_details','titan_ledger_financial_report_snapshots','titan_ledger_forecast_snapshots','titan_ledger_financial_year_closes','titan_ledger_financial_year_close_events','titan_ledger_financial_accounts','titan_ledger_banking_movements','titan_ledger_reconciliation_groups','titan_ledger_reconciliation_group_events','titan_ledger_reconciliation_group_bank_members','titan_ledger_reconciliation_group_ledger_members','titan_ledger_reconciliation_active_members',
    ];

    private const TENANT_TABLES = [
        'crm_bookkeeping_transactions','crm_bookkeeping_categories','titan_ledger_accounts','titan_ledger_journals','titan_ledger_journal_lines',
        'titan_ledger_financial_years','titan_ledger_accounting_periods','titan_ledger_period_lock_events','titan_ledger_command_receipts','titan_ledger_signal_outbox',
        'titan_ledger_crm_invoice_postings','titan_ledger_payment_settlements','titan_ledger_receivables','titan_ledger_collection_events','titan_ledger_spend_postings','titan_ledger_payables',
        'titan_ledger_bank_statements','titan_ledger_bank_transactions','titan_ledger_reconciliation_sessions','titan_ledger_reconciliation_match_events',
        'titan_ledger_gst_tax_snapshots','titan_ledger_gst_adjustments','titan_ledger_gst_adjustment_reviews','titan_ledger_gst_snapshot_details','titan_ledger_financial_report_snapshots','titan_ledger_forecast_snapshots','titan_ledger_financial_year_closes','titan_ledger_financial_year_close_events','titan_ledger_financial_accounts','titan_ledger_banking_movements','titan_ledger_reconciliation_groups','titan_ledger_reconciliation_group_events','titan_ledger_reconciliation_group_bank_members','titan_ledger_reconciliation_group_ledger_members','titan_ledger_reconciliation_active_members',
    ];

    public function __construct(
        private ConnectionInterface $db,
        private Container $app,
        private Router $router,
        private LedgerCommandBusGatewayContract $commandBus,
        private LedgerRiskGatewayContract $risk,
        private LedgerAssuranceGatewayContract $assurance,
        private LedgerSignalGatewayContract $signal,
        private LedgerRewindSource $rewind,
        private MenuSyncService $menus,
    ) {}

    public function certify(): array
    {
        $checks = [];
        $driver = $this->db->getDriverName();
        $checks['database_driver'] = $this->check($driver === 'mysql', ['actual' => $driver, 'required' => 'mysql']);
        $checks['php_runtime'] = $this->check(PHP_VERSION_ID >= 80200, ['actual' => PHP_VERSION, 'required' => '>=8.2']);
        $laravelVersion = method_exists($this->app, 'version') ? (string) $this->app->version() : 'unknown';
        $checks['laravel_runtime'] = $this->check(preg_match('/^10\./', $laravelVersion) === 1, ['actual' => $laravelVersion, 'required' => '^10.0']);

        $schema = $this->db->getSchemaBuilder();
        $missingTables = array_values(array_filter(self::REQUIRED_TABLES, static fn (string $table): bool => ! $schema->hasTable($table)));
        $checks['schema_tables'] = $this->check($missingTables === [], ['required' => count(self::REQUIRED_TABLES), 'missing' => $missingTables]);

        $tenantFailures = [];
        foreach (self::TENANT_TABLES as $table) {
            if (! $schema->hasTable($table) || ! $schema->hasColumn($table, 'company_id')) $tenantFailures[] = $table;
        }
        $checks['tenant_boundary'] = $this->check($tenantFailures === [], ['canonical_key' => 'company_id', 'missing_company_id' => $tenantFailures]);

        $multiAccountColumns = [];
        if (! $schema->hasTable('titan_ledger_payment_settlements') || ! $schema->hasColumn('titan_ledger_payment_settlements','funds_account_public_id')) $multiAccountColumns[] = 'titan_ledger_payment_settlements.funds_account_public_id';
        $checks['multi_account_schema'] = $this->check($multiAccountColumns === [], ['missing_columns' => $multiAccountColumns]);

        $advancedReconciliationColumns = [];
        if (! $schema->hasTable('titan_ledger_bank_statements') || ! $schema->hasColumn('titan_ledger_bank_statements','statement_fingerprint')) $advancedReconciliationColumns[] = 'titan_ledger_bank_statements.statement_fingerprint';
        if (! $schema->hasTable('titan_ledger_bank_transactions') || ! $schema->hasColumn('titan_ledger_bank_transactions','classification_hint')) $advancedReconciliationColumns[] = 'titan_ledger_bank_transactions.classification_hint';
        $checks['advanced_reconciliation_schema'] = $this->check($advancedReconciliationColumns === [], ['missing_columns' => $advancedReconciliationColumns]);

        $ownershipFailures = [];
        if ($schema->hasTable('titan_ledger_schema_ownership')) {
            $ownedRows = $this->db->table('titan_ledger_schema_ownership')->where('owner_extension','titan-ledger')->limit(10000)->get();
            $owned = [];
            foreach ($ownedRows as $row) {
                $table = (string) ($row->table_name ?? '');
                if ($table !== '') $owned[$table] = (string) ($row->ownership_mode ?? '');
            }
            foreach (array_diff(self::REQUIRED_TABLES, ['titan_ledger_schema_ownership']) as $table) {
                if (! isset($owned[$table]) || ! str_starts_with($owned[$table], 'retain_')) $ownershipFailures[] = $table;
            }
        } else $ownershipFailures[] = 'titan_ledger_schema_ownership';
        $checks['rollback_retention'] = $this->check($ownershipFailures === [], ['missing_or_non_retained' => $ownershipFailures]);
        $requiredMigrations=['2026_08_21_000016_harden_titan_ledger_production','2026_08_21_000017_create_titan_ledger_financial_year_closes','2026_08_21_000018_create_titan_ledger_gst_adjustments','2026_08_21_000019_create_titan_ledger_multi_account_banking','2026_08_21_000020_create_titan_ledger_advanced_reconciliation'];
        $missingMigrations=[];
        if(!$schema->hasTable('migrations')) $missingMigrations=$requiredMigrations; else foreach($requiredMigrations as $migration) if(!$this->db->table('migrations')->where('migration',$migration)->exists()) $missingMigrations[]=$migration;
        $checks['installer_upgrade_migration'] = $this->check($missingMigrations===[], ['required'=>$requiredMigrations,'missing'=>$missingMigrations]);

        $triggerNames = [];
        if ($driver === 'mysql') {
            try {
                $triggerNames = array_map(static fn ($row): string => (string) ($row->TRIGGER_NAME ?? $row->trigger_name ?? ''), $this->db->select('SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()'));
            } catch (Throwable $e) {
                $checks['mysql_triggers'] = $this->check(false, ['error' => $e->getMessage()]);
            }
        }
        if (! isset($checks['mysql_triggers'])) {
            $missingTriggers = array_values(array_diff(ProductionTriggerCatalog::names(), $triggerNames));
            $checks['mysql_triggers'] = $this->check($driver === 'mysql' && $missingTriggers === [], ['required' => count(ProductionTriggerCatalog::names()), 'present' => count(array_intersect(ProductionTriggerCatalog::names(), $triggerNames)), 'missing' => $missingTriggers]);
        }

        $checks['command_bus'] = $this->check($this->safeAvailable(fn (): bool => $this->commandBus->available()), ['required' => true]);
        $checks['risk'] = $this->check($this->safeAvailable(fn (): bool => $this->risk->available()), ['required' => true]);
        $checks['assurance'] = $this->check($this->safeAvailable(fn (): bool => $this->assurance->available()), ['required' => true]);
        $checks['signal_outbox'] = $this->check($schema->hasTable('titan_ledger_signal_outbox'), ['required' => true]);
        $checks['signal_publisher'] = $this->warning($this->safeAvailable(fn (): bool => $this->signal->available()), ['required_for_financial_commit' => false]);
        $checks['rewind_source'] = $this->check($this->rewind->sourceKey() === 'titan-ledger.rewind-source' && $this->app->bound('titan.ledger.rewind-source'), ['write_policy' => 'read-only']);

        $requiredRoutes = array_merge(
            array_column(TitanLedgerNavigation::user()['children'], 'route'),
            array_column(TitanLedgerNavigation::admin()['children'], 'route')
        );
        $missingRoutes = array_values(array_filter($requiredRoutes, fn (string $name): bool => ! $this->router->getRoutes()->hasNamedRoute($name)));
        $checks['routes'] = $this->check($missingRoutes === [], ['required' => count($requiredRoutes), 'missing' => $missingRoutes]);
        $menuInspection = $this->menus->inspect();
        $registrySupported = class_exists('App\Support\Extensions\MenuContributionRegistry') || class_exists('App\Support\Extensions\ContributionRegistry');
        $tableSupported = (bool) ($menuInspection['menus_table'] ?? false) && (bool) ($menuInspection['has_parent_id'] ?? false);
        $duplicates = $menuInspection['duplicate_keys'] ?? [];
        $menuReady = count(TitanLedgerNavigation::user()['children']) === 22 && count(TitanLedgerNavigation::admin()['children']) === 20 && ($registrySupported || $tableSupported) && $duplicates === [];
        $checks['menus'] = $this->check($menuReady, ['user_children' => count(TitanLedgerNavigation::user()['children']), 'admin_children' => count(TitanLedgerNavigation::admin()['children']), 'registry_supported' => $registrySupported, 'menus_table_supported' => $tableSupported, 'duplicate_keys' => $duplicates]);

        $requiredFailures = array_keys(array_filter($checks, static fn (array $check): bool => ($check['severity'] ?? 'required') === 'required' && ($check['status'] ?? 'FAIL') !== 'PASS'));
        return [
            'schema_version' => 1,
            'extension' => 'titan-ledger',
            'version' => '1.20.0-rc.5',
            'certified_at' => now()->toIso8601String(),
            'status' => $requiredFailures === [] ? 'PASS' : 'FAIL',
            'host_certified' => $requiredFailures === [],
            'required_failures' => $requiredFailures,
            'checks' => $checks,
        ];
    }

    private function safeAvailable(callable $probe): bool { try { return $probe() === true; } catch (Throwable) { return false; } }
    private function check(bool $pass, array $evidence = []): array { return ['status' => $pass ? 'PASS' : 'FAIL', 'severity' => 'required', 'evidence' => $evidence]; }
    private function warning(bool $pass, array $evidence = []): array { return ['status' => $pass ? 'PASS' : 'WARN', 'severity' => 'optional', 'evidence' => $evidence]; }
}
