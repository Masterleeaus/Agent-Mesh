<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Accounting;

use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseService;

final class FinancialYearCloseReadPort
{
    public function __construct(private FinancialYearCloseService $service) {}
    public function preview(int $userId,string $financialYearPublicId): array{return $this->service->preview($userId,$financialYearPublicId);}
    public function closes(int $userId,int $limit=200): array{return $this->service->all($userId,$limit);}
}
