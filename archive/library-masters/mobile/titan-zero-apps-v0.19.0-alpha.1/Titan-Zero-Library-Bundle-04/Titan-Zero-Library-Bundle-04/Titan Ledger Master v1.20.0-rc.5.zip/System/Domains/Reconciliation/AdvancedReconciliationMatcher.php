<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

use DateTimeImmutable;

final class AdvancedReconciliationMatcher
{
    /** @param array<int,array<string,mixed>> $bankTransactions @param array<int,array<string,mixed>> $candidates @return array<string,mixed> */
    public static function matchGroup(array $bankTransactions,array $candidates): array
    {
        if($bankTransactions===[]||$candidates===[])return self::unmatched();
        if(count($bankTransactions)>1&&count($candidates)>1)return self::unmatched();
        $bankTotal=array_sum(array_map(static fn($r)=>(int)($r['amount_minor']??0),$bankTransactions));
        $ledgerTotal=array_sum(array_map(static fn($r)=>(int)($r['amount_minor']??0),$candidates));
        if($bankTotal===0||$bankTotal!==$ledgerTotal)return self::unmatched();
        foreach($bankTransactions as $r)if(trim((string)($r['transaction_public_id']??''))==='')return self::unmatched();
        foreach($candidates as $r)if(trim((string)($r['candidate_public_id']??''))==='')return self::unmatched();
        $bankDates=array_map(static fn($r)=>(string)($r['posted_on']??''),$bankTransactions);
        $ledgerDates=array_map(static fn($r)=>(string)($r['occurred_on']??''),$candidates);
        $maxDays=0;foreach($bankDates as $a)foreach($ledgerDates as $b)$maxDays=max($maxDays,self::daysBetween($a,$b));
        if($maxDays>3)return self::unmatched();
        $groupType=count($bankTransactions)===1?(count($candidates)===1?'one_to_one':'one_to_many'):'many_to_one';
        $score=80+($maxDays===0?20:($maxDays<=1?15:10));
        $bankRefs=array_values(array_filter(array_map(static fn($r)=>is_string($r['reference_hash']??null)?(string)$r['reference_hash']:null,$bankTransactions)));
        $ledgerRefs=array_values(array_filter(array_map(static fn($r)=>is_string($r['reference_hash']??null)?(string)$r['reference_hash']:null,$candidates)));
        if($bankRefs!==[]&&$ledgerRefs!==[]&&count(array_intersect($bankRefs,$ledgerRefs))>0)$score+=20;
        return ['status'=>'suggested','group_type'=>$groupType,'bank_total_minor'=>$bankTotal,'ledger_total_minor'=>$ledgerTotal,'score'=>$score,'max_date_distance_days'=>$maxDays,'bank_transaction_public_ids'=>array_values(array_map(static fn($r)=>(string)$r['transaction_public_id'],$bankTransactions)),'candidate_public_ids'=>array_values(array_map(static fn($r)=>(string)$r['candidate_public_id'],$candidates))];
    }
    private static function unmatched(): array{return ['status'=>'unmatched','group_type'=>null,'bank_total_minor'=>0,'ledger_total_minor'=>0,'score'=>0,'bank_transaction_public_ids'=>[],'candidate_public_ids'=>[]];}
    private static function daysBetween(string $a,string $b): int{try{$da=new DateTimeImmutable($a);$db=new DateTimeImmutable($b);}catch(\Throwable){return PHP_INT_MAX;}return (int)$da->diff($db)->days;}
}
