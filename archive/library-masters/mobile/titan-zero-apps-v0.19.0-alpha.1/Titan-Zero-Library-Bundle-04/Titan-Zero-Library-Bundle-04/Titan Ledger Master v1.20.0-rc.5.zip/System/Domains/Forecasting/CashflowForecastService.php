<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use DateTimeImmutable;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class CashflowForecastService
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private CashflowForecastCalculator $calculator,
    ) {}

    public function actualCashflow(int $userId,string $from,string $to,string $currency='AUD'): array
    {
        [$from,$to]=$this->range($from,$to);$currency=$this->currency($currency);$companyId=$this->companyContext->companyId($userId);
        $journalRows=$this->db->table('titan_ledger_journal_lines as l')
            ->join('titan_ledger_journals as j',fn($join)=>$join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id'))
            ->join('titan_ledger_accounts as a',fn($join)=>$join->on('a.public_id','=','l.account_public_id')->on('a.company_id','=','l.company_id'))
            ->where('l.company_id',$companyId)->where('j.status','posted')->where('j.currency',$currency)->whereBetween('j.entry_date',[$from,$to])
            ->whereIn('l.account_public_id',$this->cashAccountIds($companyId,$currency))
            ->select(['j.entry_date','j.public_id'])->selectRaw('SUM(l.debit_minor) as debit_minor, SUM(l.credit_minor) as credit_minor')
            ->groupBy('j.entry_date','j.public_id')->orderBy('j.entry_date')->orderBy('j.public_id')->limit(10000)->get()->map(fn($r)=>['occurred_on'=>(string)$r->entry_date,'debit_minor'=>(int)$r->debit_minor,'credit_minor'=>(int)$r->credit_minor])->all();
        $rows=$this->calculator->journalMovements($journalRows);
        $summary=$this->calculator->actual($rows);$foreign=$this->foreignCurrencyCount($companyId,$from,$to,$currency);
        return $summary+['period_start'=>$from,'period_end'=>$to,'currency'=>$currency,'complete'=>$foreign===0,'foreign_currency_journal_count'=>$foreign,'daily'=>$rows,'source_fingerprint'=>$this->sourceFingerprint($companyId,$from,$to,$currency)];
    }

    public function forecast(int $userId,string $asOf,int $horizonDays=90,string $currency='AUD'): array
    {
        $asOf=$this->date($asOf);$currency=$this->currency($currency);$companyId=$this->companyContext->companyId($userId);
        $opening=$this->cashBalance($companyId,$asOf,$currency);
        $receivables=$this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->where('currency',$currency)->where('outstanding_minor','>',0)->orderBy('public_id')->get(['public_id','due_at','outstanding_minor'])->map(fn($r)=>(array)$r)->all();
        $payables=$this->db->table('titan_ledger_payables')->where('company_id',$companyId)->where('currency',$currency)->where('outstanding_minor','>',0)->orderBy('public_id')->get(['public_id','due_at','outstanding_minor'])->map(fn($r)=>(array)$r)->all();
        $forecast=$this->calculator->forecast($opening,$receivables,$payables,$asOf,$horizonDays);
        $trailingFrom=(new DateTimeImmutable($asOf))->modify('-30 days')->format('Y-m-d');$actual=$this->actualCashflow($userId,$trailingFrom,$asOf,$currency);$runway=$this->calculator->runway($opening,(int)$actual['net_cashflow_minor'],30);
        $unknown=(int)$forecast['excluded_receivables_minor']+(int)$forecast['excluded_payables_minor'];$foreign=$this->foreignCurrencyCount($companyId,null,$asOf,$currency);
        return $forecast+['currency'=>$currency,'runway'=>$runway,'trailing_30_day_net_cashflow_minor'=>$actual['net_cashflow_minor'],'complete'=>$unknown===0&&$foreign===0,'foreign_currency_journal_count'=>$foreign,'source_fingerprint'=>$this->sourceFingerprint($companyId,null,$asOf,$currency,true)];
    }

    private function cashBalance(int $companyId,string $asOf,string $currency): int
    {
        $row=$this->db->table('titan_ledger_journal_lines as l')->join('titan_ledger_journals as j',fn($join)=>$join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id'))->join('titan_ledger_accounts as a',fn($join)=>$join->on('a.public_id','=','l.account_public_id')->on('a.company_id','=','l.company_id'))->where('l.company_id',$companyId)->where('j.status','posted')->where('j.currency',$currency)->where('j.entry_date','<=',$asOf)->whereIn('l.account_public_id',$this->cashAccountIds($companyId,$currency))->selectRaw('COALESCE(SUM(l.debit_minor),0) as debits, COALESCE(SUM(l.credit_minor),0) as credits')->first();
        return (int)($row->debits??0)-(int)($row->credits??0);
    }


    /** @return array<int,string> */
    private function cashAccountIds(int $companyId,string $currency): array
    {
        $ids=$this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->where('system_key','cash_on_hand')->where('is_active',true)->pluck('public_id')->map(fn($v)=>(string)$v)->all();
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_financial_accounts')){
            $registered=$this->db->table('titan_ledger_financial_accounts')->where('company_id',$companyId)->where('kind','bank')->where('currency',$currency)->pluck('account_public_id')->map(fn($v)=>(string)$v)->all();
            $ids=array_values(array_unique(array_merge($ids,$registered)));
        }
        if($ids===[]){$fallback=$this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->where('system_key','bank')->where('is_active',true)->value('public_id');if($fallback)$ids[]=(string)$fallback;}
        return $ids;
    }

    private function foreignCurrencyCount(int $companyId,?string $from,string $to,string $currency): int{$q=$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency','<>',$currency)->where('entry_date','<=',$to);if($from!==null)$q->where('entry_date','>=',$from);return (int)$q->count();}

    private function sourceFingerprint(int $companyId,?string $from,string $to,string $currency,bool $includeWorkingCapital=false): string
    {
        $ctx=hash_init('sha256');$q=$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency',$currency)->where('entry_date','<=',$to);if($from!==null)$q->where('entry_date','>=',$from);foreach($q->orderBy('public_id')->cursor() as $r)hash_update($ctx,'journal|'.(string)$r->public_id.'|'.(string)($r->payload_hash??'').'|'.(string)$r->entry_date."\n");
        foreach($this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->orderBy('public_id')->cursor() as $a)hash_update($ctx,'account|'.implode('|',[(string)$a->public_id,(string)$a->code,(string)$a->type,(string)($a->subtype??''),(string)($a->system_key??''),(string)(int)$a->is_active])."\n");
        if($this->db->getSchemaBuilder()->hasTable('titan_ledger_financial_accounts'))foreach($this->db->table('titan_ledger_financial_accounts')->where('company_id',$companyId)->orderBy('public_id')->cursor() as $a)hash_update($ctx,'financial_account|'.implode('|',[(string)$a->account_public_id,(string)$a->kind,(string)$a->currency])."\n");
        if($includeWorkingCapital){foreach($this->db->table('titan_ledger_receivables')->where('company_id',$companyId)->where('currency',$currency)->orderBy('public_id')->cursor() as $r)hash_update($ctx,'ar|'.implode('|',[(string)$r->public_id,(string)$r->invoice_public_id,(string)($r->due_at??''),(string)$r->outstanding_minor,(string)($r->projection_hash??'')])."\n");foreach($this->db->table('titan_ledger_payables')->where('company_id',$companyId)->where('currency',$currency)->orderBy('public_id')->cursor() as $r)hash_update($ctx,'ap|'.implode('|',[(string)$r->public_id,(string)$r->bill_public_id,(string)($r->due_at??''),(string)$r->outstanding_minor,(string)($r->projection_hash??'')])."\n");}
        return hash_final($ctx);
    }

    private function range(string $from,string $to): array{$f=$this->date($from);$t=$this->date($to);if($f>$t)throw new InvalidArgumentException('Cashflow period start must not exceed end.');return[$f,$t];}
    private function date(string $v): string{try{return(new DateTimeImmutable($v))->format('Y-m-d');}catch(\Throwable){throw new InvalidArgumentException('Cashflow date is invalid.');}}
    private function currency(string $v): string{$v=strtoupper(trim($v));if(!preg_match('/^[A-Z]{3}$/',$v))throw new InvalidArgumentException('Cashflow currency must be a 3-letter code.');return$v;}
}
