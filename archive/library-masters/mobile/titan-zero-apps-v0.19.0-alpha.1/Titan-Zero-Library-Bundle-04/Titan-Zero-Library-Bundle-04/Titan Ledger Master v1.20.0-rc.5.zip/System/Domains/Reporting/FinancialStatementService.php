<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reporting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use DateTimeImmutable;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class FinancialStatementService
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private FinancialStatementCalculator $calculator,
        private ComparativePeriodResolver $comparisons,
    ) {}

    public function trialBalance(int $userId, string $asOf, string $currency='AUD'): array
    {
        $asOf = $this->date($asOf);
        $currency = $this->currency($currency);
        $companyId = $this->companyContext->companyId($userId);
        $rows = $this->aggregateRows($companyId, null, $asOf, $currency);
        $foreign = $this->foreignCurrencyCount($companyId, null, $asOf, $currency);
        return $this->calculator->trialBalance($rows) + [
            'report_type'=>'trial_balance','as_of'=>$asOf,'currency'=>$currency,
            'complete'=>$foreign===0,'foreign_currency_journal_count'=>$foreign,
            'source_fingerprint'=>$this->sourceFingerprint($companyId, null, $asOf, $currency),
        ];
    }

    public function profitLoss(int $userId, string $from, string $to, string $currency='AUD'): array
    {
        [$from,$to] = $this->range($from,$to);
        $currency = $this->currency($currency);
        $companyId = $this->companyContext->companyId($userId);
        $rows = $this->aggregateRows($companyId, $from, $to, $currency, true);
        $foreign = $this->foreignCurrencyCount($companyId, $from, $to, $currency);
        return $this->calculator->profitAndLoss($rows) + [
            'report_type'=>'profit_loss','period_start'=>$from,'period_end'=>$to,'currency'=>$currency,
            'complete'=>$foreign===0,'foreign_currency_journal_count'=>$foreign,
            'source_fingerprint'=>$this->sourceFingerprint($companyId, $from, $to, $currency, true),
        ];
    }

    public function balanceSheet(int $userId, string $asOf, string $currency='AUD'): array
    {
        $asOf = $this->date($asOf);
        $currency = $this->currency($currency);
        $companyId = $this->companyContext->companyId($userId);
        $rows = $this->aggregateRows($companyId, null, $asOf, $currency);
        $foreign = $this->foreignCurrencyCount($companyId, null, $asOf, $currency);
        $tb = $this->calculator->trialBalance($rows);
        $bs = $this->calculator->balanceSheet($rows);
        return $bs + [
            'report_type'=>'balance_sheet','as_of'=>$asOf,'currency'=>$currency,
            'trial_balance_balanced'=>$tb['balanced'],'complete'=>$foreign===0,
            'foreign_currency_journal_count'=>$foreign,
            'source_fingerprint'=>$this->sourceFingerprint($companyId, null, $asOf, $currency),
        ];
    }

    public function retainedEarnings(int $userId, string $from, string $to, string $currency='AUD'): array
    {
        [$from,$to] = $this->range($from,$to);
        $currency = $this->currency($currency);
        $companyId = $this->companyContext->companyId($userId);
        $openingDate = (new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d');
        $openingRows = $this->aggregateRows($companyId, null, $openingDate, $currency);
        $periodRows = $this->aggregateRows($companyId, $from, $to, $currency);
        $profitRows = $this->aggregateRows($companyId, $from, $to, $currency, true);
        $opening = $this->retainedEarningsBalance($openingRows);
        $movement = $this->retainedEarningsBalance($periodRows);
        $historicalProfit = $this->calculator->profitAndLoss($profitRows)['net_profit_minor'];
        $closeCount = (int)$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency',$currency)->whereBetween('entry_date',[$from,$to])->where('journal_type','year_end_close')->count();
        $reopenCount = (int)$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency',$currency)->whereBetween('entry_date',[$from,$to])->where('journal_type','year_end_reopen')->count();
        $earningsClosed = $closeCount > $reopenCount;
        $profitForEquityRollForward = $earningsClosed ? 0 : $historicalProfit;
        $foreign = $this->foreignCurrencyCount($companyId, $from, $to, $currency) + $this->foreignCurrencyCount($companyId, null, $openingDate, $currency);
        return $this->calculator->retainedEarningsRollForward($opening, $movement, $profitForEquityRollForward) + [
            'historical_period_profit_minor'=>$historicalProfit,'earnings_closed'=>$earningsClosed,
            'report_type'=>'retained_earnings_roll_forward','period_start'=>$from,'period_end'=>$to,'currency'=>$currency,
            'complete'=>$foreign===0,'foreign_currency_journal_count'=>$foreign,
            'source_fingerprint'=>$this->sourceFingerprint($companyId, null, $to, $currency),
        ];
    }

    public function managementPack(int $userId, string $from, string $to, string $currency='AUD'): array
    {
        [$from,$to] = $this->range($from,$to);
        $periods = $this->comparisons->resolve($from,$to);
        $tb = $this->trialBalance($userId,$to,$currency);
        $pl = $this->profitLoss($userId,$from,$to,$currency);
        $bs = $this->balanceSheet($userId,$to,$currency);
        $re = $this->retainedEarnings($userId,$from,$to,$currency);
        $previous = $this->profitLoss($userId,$periods['previous_period']['from'],$periods['previous_period']['to'],$currency);
        $priorYear = $this->profitLoss($userId,$periods['prior_year']['from'],$periods['prior_year']['to'],$currency);
        $complete = $tb['complete'] && $pl['complete'] && $bs['complete'] && $re['complete'] && $previous['complete'] && $priorYear['complete'];
        $balanced = $tb['balanced'] && $bs['balanced'];
        $fingerprint = hash('sha256', implode('|', [
            $tb['source_fingerprint'],$pl['source_fingerprint'],$bs['source_fingerprint'],$re['source_fingerprint'],$previous['source_fingerprint'],$priorYear['source_fingerprint']
        ]));
        return [
            'report_type'=>'management_pack','period_start'=>$from,'period_end'=>$to,'currency'=>$this->currency($currency),
            'trial_balance'=>$tb,'profit_loss'=>$pl,'balance_sheet'=>$bs,'retained_earnings'=>$re,
            'comparatives'=>['previous_period'=>$previous,'prior_year'=>$priorYear],
            'variance'=>[
                'revenue_vs_previous_period_minor'=>$pl['revenue_minor']-$previous['revenue_minor'],
                'net_profit_vs_previous_period_minor'=>$pl['net_profit_minor']-$previous['net_profit_minor'],
                'revenue_vs_prior_year_minor'=>$pl['revenue_minor']-$priorYear['revenue_minor'],
                'net_profit_vs_prior_year_minor'=>$pl['net_profit_minor']-$priorYear['net_profit_minor'],
            ],
            'balanced'=>$balanced,'complete'=>$complete,'source_fingerprint'=>$fingerprint,
        ];
    }

    public function accountDrilldown(int $userId, string $accountPublicId, string $from, string $to, string $currency='AUD', int $limit=200): array
    {
        [$from,$to] = $this->range($from,$to);
        $currency = $this->currency($currency);
        $companyId = $this->companyContext->companyId($userId);
        $limit = max(1,min($limit,200));
        $account = $this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->where('public_id',$accountPublicId)->first();
        if (!$account) throw new InvalidArgumentException('Ledger account not found.');
        $rows = $this->db->table('titan_ledger_journal_lines as l')
            ->join('titan_ledger_journals as j', function($join): void {
                $join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id');
            })
            ->where('l.company_id',$companyId)->where('l.account_public_id',$accountPublicId)
            ->where('j.status','posted')->where('j.currency',$currency)
            ->whereBetween('j.entry_date',[$from,$to])
            ->orderByDesc('j.entry_date')->orderByDesc('l.id')->limit($limit)
            ->get(['j.public_id as journal_public_id','j.entry_date','j.journal_type','j.journal_number','j.source_extension','j.source_type','j.source_public_id','l.public_id as line_public_id','l.description','l.debit_minor','l.credit_minor','l.tax_code','l.tax_amount_minor'])
            ->map(fn($r)=>array_merge((array)$r,['net_debit_minor'=>(int)$r->debit_minor-(int)$r->credit_minor]))->all();
        return [
            'account'=>['public_id'=>(string)$account->public_id,'code'=>(string)$account->code,'name'=>(string)$account->name,'type'=>(string)$account->type],
            'period_start'=>$from,'period_end'=>$to,'currency'=>$currency,'rows'=>$rows,'limit'=>$limit,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function aggregateRows(int $companyId, ?string $from, string $to, string $currency, bool $excludeCloseMechanics=false): array
    {
        $q = $this->db->table('titan_ledger_journal_lines as l')
            ->join('titan_ledger_journals as j', function($join): void {
                $join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id');
            })
            ->join('titan_ledger_accounts as a', function($join): void {
                $join->on('a.public_id','=','l.account_public_id')->on('a.company_id','=','l.company_id');
            })
            ->where('l.company_id',$companyId)->where('j.status','posted')->where('j.currency',$currency)->where('j.entry_date','<=',$to);
        if ($from !== null) $q->where('j.entry_date','>=',$from);
        if ($excludeCloseMechanics) $q->whereNotIn('j.journal_type',['year_end_close','year_end_reopen']);
        return $q->select(['a.public_id','a.code','a.name','a.type','a.normal_balance','a.system_key'])
            ->selectRaw('SUM(l.debit_minor) as debit_minor, SUM(l.credit_minor) as credit_minor')
            ->groupBy('a.public_id','a.code','a.name','a.type','a.normal_balance','a.system_key')
            ->orderBy('a.code')->limit(10000)->get()->map(fn($r)=>(array)$r)->all();
    }

    /** @param array<int,array<string,mixed>> $rows */
    private function retainedEarningsBalance(array $rows): int
    {
        foreach ($rows as $row) if (($row['system_key'] ?? null) === 'retained_earnings') return (int)$row['credit_minor']-(int)$row['debit_minor'];
        return 0;
    }

    private function foreignCurrencyCount(int $companyId, ?string $from, string $to, string $currency): int
    {
        $q = $this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency','<>',$currency)->where('entry_date','<=',$to);
        if ($from !== null) $q->where('entry_date','>=',$from);
        return (int)$q->count();
    }

    private function sourceFingerprint(int $companyId, ?string $from, string $to, string $currency, bool $excludeCloseMechanics=false): string
    {
        $q = $this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency',$currency)->where('entry_date','<=',$to);
        if ($from !== null) $q->where('entry_date','>=',$from);
        if ($excludeCloseMechanics) $q->whereNotIn('journal_type',['year_end_close','year_end_reopen']);
        $ctx = hash_init('sha256');
        foreach ($q->orderBy('public_id')->cursor() as $row) {
            hash_update($ctx, 'journal|' . (string)$row->public_id . '|' . (string)($row->payload_hash ?? '') . '|' . (string)$row->entry_date . "\n");
        }
        foreach ($this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->orderBy('public_id')->cursor() as $account) {
            hash_update($ctx, 'account|' . implode('|', [
                (string)$account->public_id,(string)$account->code,(string)$account->name,(string)$account->type,(string)($account->subtype ?? ''),(string)$account->normal_balance,(string)($account->system_key ?? ''),(string)(int)$account->is_active,
            ]) . "\n");
        }
        return hash_final($ctx);
    }

    /** @return array{0:string,1:string} */
    private function range(string $from, string $to): array
    {
        $periods = $this->comparisons->resolve($from,$to);
        return [$periods['current']['from'],$periods['current']['to']];
    }

    private function date(string $value): string
    {
        $periods = $this->comparisons->resolve($value,$value);
        return $periods['current']['from'];
    }

    private function currency(string $value): string
    {
        $value = strtoupper(trim($value));
        if (!preg_match('/^[A-Z]{3}$/',$value)) throw new InvalidArgumentException('Financial report currency must be a 3-letter code.');
        return $value;
    }
}
