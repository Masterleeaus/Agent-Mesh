<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Reconciliation;

final class BankStatementDuplicatePolicy
{
    /** @param array<string,mixed> $fact */
    public static function fingerprint(array $fact): string
    {
        $transactions=[];foreach(($fact['transactions']??[]) as $tx){if(!is_array($tx))continue;$transactions[]=['posted_on'=>(string)($tx['posted_on']??''),'amount_minor'=>(int)($tx['amount_minor']??0),'reference_hash'=>$tx['reference_hash']??null];}
        usort($transactions,static fn($a,$b)=>[$a['posted_on'],$a['amount_minor'],(string)$a['reference_hash']]<=>[$b['posted_on'],$b['amount_minor'],(string)$b['reference_hash']]);
        $payload=['account_public_id'=>(string)($fact['account_public_id']??''),'currency'=>(string)($fact['currency']??''),'period_start'=>(string)($fact['period_start']??''),'period_end'=>(string)($fact['period_end']??''),'opening_balance_minor'=>(int)($fact['opening_balance_minor']??0),'closing_balance_minor'=>(int)($fact['closing_balance_minor']??0),'movement_minor'=>(int)($fact['movement_minor']??0),'transactions'=>$transactions];
        return hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
