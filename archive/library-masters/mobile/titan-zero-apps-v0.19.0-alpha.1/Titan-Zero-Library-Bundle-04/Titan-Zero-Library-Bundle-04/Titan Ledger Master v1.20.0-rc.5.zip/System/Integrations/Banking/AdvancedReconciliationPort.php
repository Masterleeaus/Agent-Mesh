<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Banking;

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandSubmissionService;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankReconciliationService;

final class AdvancedReconciliationPort
{
    public function __construct(private LedgerCommandSubmissionService $commands,private BankReconciliationService $reconciliation){}
    public function groups(int $actorUserId,int $limit=200): array{return $this->reconciliation->groups($actorUserId,$limit);}
    public function suggestions(int $actorUserId,string $statementPublicId,int $limit=100): array{return $this->reconciliation->advancedSuggestions($actorUserId,$statementPublicId,$limit);}
    public function matchGroup(int $actorUserId,string $sessionPublicId,array $bankTransactionPublicIds,array $candidatePublicIds,?string $reasonCode=null,array $context=[]): array{$payload=['bank_transaction_public_ids'=>$bankTransactionPublicIds,'candidate_public_ids'=>$candidatePublicIds,'reason_code'=>$reasonCode];$id='recon-group:'.substr(hash('sha256',$sessionPublicId.'|'.json_encode($payload)),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.group_match',$id,$sessionPublicId,$payload,$context,'titan-bank-reconciliation');}
    public function rejectGroup(int $actorUserId,string $groupPublicId,string $reasonCode,array $context=[]): array{$payload=['reason_code'=>$reasonCode];$id='recon-group-reject:'.substr(hash('sha256',$groupPublicId.'|'.$reasonCode),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.group_reject',$id,$groupPublicId,$payload,$context,'titan-bank-reconciliation');}
    public function postAdjustment(int $actorUserId,string $transactionPublicId,string $adjustmentType,string $reasonCode,array $context=[]): array{$payload=['adjustment_type'=>$adjustmentType,'reason_code'=>$reasonCode];$id='recon-adjust:'.substr(hash('sha256',$transactionPublicId.'|'.$adjustmentType.'|'.$reasonCode),0,48);return $this->commands->submit($actorUserId,'ledger.bank.reconciliation.adjustment.post',$id,$transactionPublicId,$payload,$context,'titan-bank-reconciliation');}
}
