<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Console;

use App\Extensions\TitanLedger\System\Navigation\MenuSyncService;
use Illuminate\Console\Command;

final class SyncLedgerHostCommand extends Command
{
    protected $signature = 'titan-ledger:host-sync {--force : Force menu cache regeneration}';
    protected $description = 'Repair Titan Ledger host navigation without changing financial data.';

    public function handle(MenuSyncService $menus): int
    {
        $report = $menus->sync((bool) $this->option('force'));
        $this->line((string) json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return ($report['supported'] ?? false) ? self::SUCCESS : self::FAILURE;
    }
}
