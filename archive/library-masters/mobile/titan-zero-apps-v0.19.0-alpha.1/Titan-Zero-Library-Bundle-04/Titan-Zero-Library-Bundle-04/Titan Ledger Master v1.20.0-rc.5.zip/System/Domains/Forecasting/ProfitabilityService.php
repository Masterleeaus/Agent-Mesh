<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Domains\Forecasting;

use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use DateTimeImmutable;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class ProfitabilityService
{
    public function __construct(private ConnectionInterface $db,private LedgerCompanyContext $companyContext,private ProfitabilityCalculator $calculator){}

    public function pack(int $userId,string $from,string $to,string $currency='AUD'): array
    {
        [$from,$to]=$this->range($from,$to);$currency=$this->currency($currency);$companyId=$this->companyContext->companyId($userId);
        $raw=$this->db->table('titan_ledger_journal_lines as l')->join('titan_ledger_journals as j',fn($join)=>$join->on('j.public_id','=','l.journal_public_id')->on('j.company_id','=','l.company_id'))->join('titan_ledger_accounts as a',fn($join)=>$join->on('a.public_id','=','l.account_public_id')->on('a.company_id','=','l.company_id'))->where('l.company_id',$companyId)->where('j.status','posted')->where('j.currency',$currency)->whereBetween('j.entry_date',[$from,$to])->whereIn('a.type',['revenue','other_income','cost_of_sales','expense','other_expense'])->select(['a.type','a.subtype'])->selectRaw('SUM(l.debit_minor) as debit_minor, SUM(l.credit_minor) as credit_minor')->groupBy('a.type','a.subtype')->orderBy('a.type')->orderBy('a.subtype')->get()->map(function($r){$type=(string)$r->type;$amount=in_array($type,['revenue','other_income'],true)?(int)$r->credit_minor-(int)$r->debit_minor:(int)$r->debit_minor-(int)$r->credit_minor;return['type'=>$type,'subtype'=>(string)($r->subtype??''),'amount_minor'=>$amount];})->all();
        $summary=$this->calculator->summary($raw);$categories=[];foreach($raw as $r){$k=$r['type'].':'.($r['subtype']!==''?$r['subtype']:'uncategorized');$categories[$k]=($categories[$k]??0)+(int)$r['amount_minor'];}ksort($categories,SORT_STRING);
        $foreign=(int)$this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency','<>',$currency)->whereBetween('entry_date',[$from,$to])->count();
        return $summary+['period_start'=>$from,'period_end'=>$to,'currency'=>$currency,'categories'=>$categories,'complete'=>$foreign===0,'foreign_currency_journal_count'=>$foreign,'dimension_foundation'=>['customer_job_profitability_ready'=>false,'reason'=>'customer/job attribution requires an authoritative external dimension mapping from journal source references'],'source_fingerprint'=>$this->sourceFingerprint($companyId,$from,$to,$currency)];
    }

    private function sourceFingerprint(int $companyId,string $from,string $to,string $currency): string{$ctx=hash_init('sha256');foreach($this->db->table('titan_ledger_journals')->where('company_id',$companyId)->where('status','posted')->where('currency',$currency)->whereBetween('entry_date',[$from,$to])->orderBy('public_id')->cursor() as $r)hash_update($ctx,'journal|'.(string)$r->public_id.'|'.(string)($r->payload_hash??'').'|'.(string)$r->entry_date."\n");foreach($this->db->table('titan_ledger_accounts')->where('company_id',$companyId)->orderBy('public_id')->cursor() as $a)hash_update($ctx,'account|'.implode('|',[(string)$a->public_id,(string)$a->code,(string)$a->type,(string)($a->subtype??''),(string)($a->system_key??''),(string)(int)$a->is_active])."\n");return hash_final($ctx);}
    private function range(string $from,string $to): array{$f=$this->date($from);$t=$this->date($to);if($f>$t)throw new InvalidArgumentException('Profitability period start must not exceed end.');return[$f,$t];}
    private function date(string $v): string{try{return(new DateTimeImmutable($v))->format('Y-m-d');}catch(\Throwable){throw new InvalidArgumentException('Profitability date is invalid.');}}
    private function currency(string $v): string{$v=strtoupper(trim($v));if(!preg_match('/^[A-Z]{3}$/',$v))throw new InvalidArgumentException('Profitability currency must be a 3-letter code.');return$v;}
}
