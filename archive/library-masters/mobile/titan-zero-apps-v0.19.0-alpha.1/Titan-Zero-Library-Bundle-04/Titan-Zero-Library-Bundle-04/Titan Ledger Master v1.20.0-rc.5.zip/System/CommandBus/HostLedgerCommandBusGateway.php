<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

use Illuminate\Contracts\Container\Container;
use RuntimeException;

final class HostLedgerCommandBusGateway implements LedgerCommandBusGatewayContract
{
    private const BINDINGS = ['titan.command-bus.gateway.titan-ledger', 'titan.command-bus.gateway'];

    public function __construct(private Container $app, private UnavailableLedgerCommandBusGateway $fallback) {}

    public function dispatch(array $command): array
    {
        foreach (self::BINDINGS as $binding) {
            if (! $this->app->bound($binding)) continue;
            $candidate = $this->app->make($binding);
            if ($candidate === $this) continue;
            if ($candidate instanceof LedgerCommandBusGatewayContract) return $candidate->dispatch($command);
            if (is_object($candidate) && method_exists($candidate, 'dispatch')) {
                $result = $candidate->dispatch($command);
                if (! is_array($result)) throw new RuntimeException('Titan Command Bus returned an invalid Ledger response.');
                return $result;
            }
            if (is_callable($candidate)) {
                $result = $candidate($command);
                if (! is_array($result)) throw new RuntimeException('Titan Command Bus returned an invalid Ledger response.');
                return $result;
            }
        }
        return $this->fallback->dispatch($command);
    }

    public function available(): bool
    {
        foreach (self::BINDINGS as $binding) {
            if (! $this->app->bound($binding)) continue;
            try { $candidate = $this->app->make($binding); } catch (\Throwable) { continue; }
            if ($candidate === $this) continue;
            if ($candidate instanceof LedgerCommandBusGatewayContract) return true;
            if (is_object($candidate) && method_exists($candidate, 'dispatch')) return true;
            if (is_callable($candidate)) return true;
        }
        return false;
    }
}
