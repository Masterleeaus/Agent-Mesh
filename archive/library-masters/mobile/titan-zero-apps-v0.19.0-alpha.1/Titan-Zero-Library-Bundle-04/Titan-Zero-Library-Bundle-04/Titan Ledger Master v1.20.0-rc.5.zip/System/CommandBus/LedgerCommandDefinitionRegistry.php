<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

final class LedgerCommandDefinitionRegistry
{
    /** @return array<string,array<string,mixed>> */
    public static function all(): array
    {
        $manage = 'crm.bookkeeping.manage';
        $category = 'crm.bookkeeping.categories.manage';

        return [
            'ledger.account.create' => self::buildDefinition($manage, false),
            'ledger.account.update' => self::buildDefinition($manage, true),
            'ledger.journal.create' => self::buildDefinition($manage, false),
            'ledger.journal.lines.replace' => self::buildDefinition($manage, true),
            'ledger.journal.validate' => self::buildDefinition($manage, true),
            'ledger.journal.post' => self::buildDefinition($manage, true),
            'ledger.journal.reverse' => self::buildDefinition($manage, true),
            'ledger.journal.correction.create' => self::buildDefinition($manage, true),
            'ledger.financial_year.create' => self::buildDefinition($manage, false),
            'ledger.financial_year.close.prepare' => self::buildDefinition($manage, true),
            'ledger.financial_year.close' => self::buildDefinition($manage, true),
            'ledger.financial_year.reopen' => self::buildDefinition($manage, true),
            'ledger.accounting_period.transition' => self::buildDefinition($manage, true),
            'ledger.bookkeeping.transaction.create' => self::buildDefinition($manage, false),
            'ledger.bookkeeping.transaction.update' => self::buildDefinition($manage, true),
            'ledger.bookkeeping.transaction.delete' => self::buildDefinition($manage, true),
            'ledger.bookkeeping.category.create' => self::buildDefinition($category, false),
            'ledger.crm.invoice.post' => self::buildDefinition($manage, true),
            'ledger.crm.credit_note.post' => self::buildDefinition($manage, true),
            'ledger.payment.settlement.post' => self::buildDefinition($manage, true),
            'ledger.payment.refund.post' => self::buildDefinition($manage, true),
            'ledger.receivable.collection.transition' => self::buildDefinition($manage, true),
            'ledger.receivable.follow_up.record' => self::buildDefinition($manage, true),
            'ledger.payable.bill.post' => self::buildDefinition($manage, true),
            'ledger.payable.credit_note.post' => self::buildDefinition($manage, true),
            'ledger.payable.payment.post' => self::buildDefinition($manage, true),
            'ledger.spend.actual.post' => self::buildDefinition($manage, true),
            'ledger.bank.statement.import' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.match' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.reject_match' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.close' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.group_match' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.group_reject' => self::buildDefinition($manage, true),
            'ledger.bank.reconciliation.adjustment.post' => self::buildDefinition($manage, true),
            'ledger.banking.account.register' => self::buildDefinition($manage, true),
            'ledger.banking.transfer.post' => self::buildDefinition($manage, true),
            'ledger.banking.clearing.settle' => self::buildDefinition($manage, true),
            'ledger.banking.credit_card.payment.post' => self::buildDefinition($manage, true),
            'ledger.tax.gst_snapshot.prepare' => self::buildDefinition($manage, true),
            'ledger.tax.gst_snapshot.finalize' => self::buildDefinition($manage, true),
            'ledger.tax.gst_snapshot.supersede' => self::buildDefinition($manage, true),
            'ledger.tax.gst_adjustment.record' => self::buildDefinition($manage, true),
            'ledger.tax.gst_adjustment.review' => self::buildDefinition($manage, true),
            'ledger.tax.gst_snapshot.amend' => self::buildDefinition($manage, true),
            'ledger.reporting.snapshot.prepare' => self::buildDefinition($manage, true),
            'ledger.reporting.snapshot.finalize' => self::buildDefinition($manage, true),
            'ledger.reporting.snapshot.supersede' => self::buildDefinition($manage, true),
            'ledger.forecast.snapshot.prepare' => self::buildDefinition($manage, true),
            'ledger.forecast.snapshot.finalize' => self::buildDefinition($manage, true),
            'ledger.forecast.snapshot.supersede' => self::buildDefinition($manage, true),
        ];
    }

    public static function supports(string $commandName): bool
    {
        return isset(self::all()[$commandName]);
    }

    /** @return array<string,mixed>|null */
    public static function definition(string $commandName): ?array
    {
        return self::all()[$commandName] ?? null;
    }

    /** @return array<string,mixed> */
    private static function buildDefinition(string $permission, bool $targetRequired): array
    {
        return [
            'owner' => 'titan-ledger',
            'version' => 1,
            'mutation' => true,
            'permission' => $permission,
            'target_required' => $targetRequired,
            'receipt_required' => true,
            'idempotency' => 'company_command_id',
            'adapter_binding' => 'titan.command-bus.domain-adapter.titan-ledger',
        ];
    }
}
