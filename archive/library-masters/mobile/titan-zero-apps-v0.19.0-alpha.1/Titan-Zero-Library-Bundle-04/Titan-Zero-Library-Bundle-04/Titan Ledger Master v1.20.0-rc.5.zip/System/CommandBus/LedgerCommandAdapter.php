<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\CommandBus;

use App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodService;
use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseService;
use App\Extensions\TitanLedger\System\Domains\Accounting\ChartOfAccountsService;
use App\Extensions\TitanLedger\System\Domains\Accounting\JournalService;
use App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingCategoryService;
use App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingTransactionService;
use App\Extensions\TitanLedger\System\Tenancy\LedgerCompanyContext;
use App\Extensions\TitanLedger\System\Governance\LedgerGovernanceEvidenceService;
use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceAccountingService;
use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementService;
use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingService;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankReconciliationService;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\ReconciliationAdjustmentService;
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxLedgerService;
use App\Extensions\TitanLedger\System\Domains\Tax\GstTaxAdjustmentService;
use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotService;
use App\Extensions\TitanLedger\System\Signal\LedgerSignalOutboxService;
use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableCollectionService;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;
use Throwable;

final class LedgerCommandAdapter
{
    public function __construct(
        private ConnectionInterface $db,
        private LedgerCompanyContext $companyContext,
        private LedgerDomainReceiptService $receipts,
        private LedgerGovernanceEvidenceService $governance,
        private JournalService $journals,
        private ChartOfAccountsService $accounts,
        private AccountingPeriodService $periods,
        private FinancialYearCloseService $yearClose,
        private BookkeepingTransactionService $transactions,
        private BookkeepingCategoryService $categories,
        private CrmInvoiceAccountingService $crmInvoices,
        private TitanPaySettlementService $payments,
        private ReceivableCollectionService $receivables,
        private SpendAccountingService $spend,
        private BankReconciliationService $reconciliation,
        private ReconciliationAdjustmentService $reconciliationAdjustments,
        private MultiAccountBankingService $banking,
        private GstTaxLedgerService $tax,
        private GstTaxAdjustmentService $taxAdjustments,
        private FinancialReportSnapshotService $reportSnapshots,
        private ForecastSnapshotService $forecastSnapshots,
        private LedgerSignalOutboxService $signals,
    ) {}

    /** @param array<string,mixed> $trustedCommand */
    public function execute(array $trustedCommand): array
    {
        $command = $this->normalizeTrustedCommand($trustedCommand);
        $companyId = (int) $command['company_id'];
        $actor = (int) $command['actor_user_id'];
        $resolvedCompanyId = $this->companyContext->companyId($actor);
        $resolvedActor = $this->companyContext->actorUserId($actor);
        if ($resolvedCompanyId !== $companyId || $resolvedActor !== $actor) {
            throw new InvalidArgumentException('Titan Ledger rejected Command Bus trusted-context mismatch.');
        }

        $command = $command + $this->governance->evaluate($command);

        $begin = $this->receipts->begin($command);
        if (($begin['mode'] ?? null) === 'replay') return $begin['receipt'];

        try {
            $execution = $this->db->transaction(function () use ($command, $companyId, $actor, $begin): array {
                $result = $this->dispatchLocal($actor, $command);
                $receipt = $this->receipts->apply($companyId, (string) $command['command_id'], (string) $begin['public_id'], $result);
                if (($receipt['write_verified'] ?? false) !== true || empty($receipt['domain_receipt_reference']) || empty($receipt['write_fingerprint'])) {
                    throw new InvalidArgumentException('Titan Ledger requires a verified authoritative domain_receipt_reference before financial event emission.');
                }
                $event = $this->signals->recordApplied($command, $result, $receipt);
                return ['receipt' => $receipt, 'signal_id' => (string) $event['signal_id']];
            });
            try { $this->signals->deliverSignal((string) $execution['signal_id']); } catch (Throwable) {}
            return $execution['receipt'];
        } catch (Throwable $e) {
            $this->receipts->fail($companyId, (string) $command['command_id'], class_basename($e));
            throw $e;
        }
    }

    /** @param array<string,mixed> $command */
    private function dispatchLocal(int $userId, array $command): array
    {
        $name = (string) $command['command_name'];
        $target = isset($command['target_public_id']) && $command['target_public_id'] !== null ? (string) $command['target_public_id'] : null;
        $payload = is_array($command['payload'] ?? null) ? $command['payload'] : [];
        $commandId = (string) $command['command_id'];

        return match ($name) {
            'ledger.bookkeeping.transaction.create' => $this->transactions->create($userId, $payload),
            'ledger.bookkeeping.transaction.update' => $this->transactions->updateManual($userId, $this->requiredTarget($target), $payload),
            'ledger.bookkeeping.transaction.delete' => $this->deleteBookkeepingTransaction($userId, $this->requiredTarget($target)),
            'ledger.bookkeeping.category.create' => $this->categories->create($userId, $payload),
            'ledger.account.create' => $this->accounts->create($userId, $payload),
            'ledger.account.update' => $this->accounts->update($userId, $this->requiredTarget($target), $payload),
            'ledger.journal.create' => $this->journals->createDraft($userId, $payload),
            'ledger.journal.lines.replace' => $this->journals->replaceDraftLines($userId, $this->requiredTarget($target), $payload['lines'] ?? []),
            'ledger.journal.validate' => $this->journals->validateDraft($userId, $this->requiredTarget($target)),
            'ledger.journal.post' => $this->journals->post($userId, $this->requiredTarget($target), $this->postingOperation($payload, $commandId)),
            'ledger.journal.reverse' => $this->journals->reverse($userId, $this->requiredTarget($target), $this->postingOperation($payload, $commandId), $this->withoutOperationId($payload)),
            'ledger.journal.correction.create' => $this->journals->createCorrectionDraft($userId, $this->requiredTarget($target), $payload),
            'ledger.financial_year.create' => $this->periods->createFinancialYear($userId, $payload),
            'ledger.financial_year.close.prepare' => $this->yearClose->prepare($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.financial_year.close' => $this->yearClose->close($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.financial_year.reopen' => $this->yearClose->reopen($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.accounting_period.transition' => $this->periods->transitionPeriod($userId, $this->requiredTarget($target), (string) ($payload['lock_state'] ?? ''), $this->requiredReason($payload), $this->context($command, $payload)),
            'ledger.crm.invoice.post' => $this->crmInvoices->postInvoice($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.crm.credit_note.post' => $this->crmInvoices->postCreditNote($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.payment.settlement.post' => $this->payments->postPayment($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.payment.refund.post' => $this->payments->postRefund($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.receivable.collection.transition' => $this->receivables->transition($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.receivable.follow_up.record' => $this->receivables->recordFollowUp($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.payable.bill.post' => $this->spend->postBill($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.payable.credit_note.post' => $this->spend->postCreditNote($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.payable.payment.post' => $this->spend->postPayment($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.spend.actual.post' => $this->spend->postActual($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.statement.import' => $this->reconciliation->importStatement($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.match' => $this->reconciliation->matchTransaction($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.reject_match' => $this->reconciliation->rejectMatch($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.close' => $this->reconciliation->closeSession($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.group_match' => $this->reconciliation->matchGroup($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.group_reject' => $this->reconciliation->rejectGroup($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.bank.reconciliation.adjustment.post' => $this->reconciliationAdjustments->post($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.banking.account.register' => $this->banking->registerAccount($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.banking.transfer.post' => $this->banking->postTransfer($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.banking.clearing.settle' => $this->banking->settleClearing($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.banking.credit_card.payment.post' => $this->banking->payCreditCard($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_snapshot.prepare' => $this->tax->prepare($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_snapshot.finalize' => $this->tax->finalize($userId, $this->requiredTarget($target), $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_snapshot.supersede' => $this->tax->supersede($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_adjustment.record' => $this->taxAdjustments->record($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_adjustment.review' => $this->taxAdjustments->review($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.tax.gst_snapshot.amend' => $this->tax->amend($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.reporting.snapshot.prepare' => $this->reportSnapshots->prepare($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.reporting.snapshot.finalize' => $this->reportSnapshots->finalize($userId, $this->requiredTarget($target), $this->postingOperation($payload, $commandId), $command),
            'ledger.reporting.snapshot.supersede' => $this->reportSnapshots->supersede($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.forecast.snapshot.prepare' => $this->forecastSnapshots->prepare($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            'ledger.forecast.snapshot.finalize' => $this->forecastSnapshots->finalize($userId, $this->requiredTarget($target), $this->postingOperation($payload, $commandId), $command),
            'ledger.forecast.snapshot.supersede' => $this->forecastSnapshots->supersede($userId, $this->requiredTarget($target), $payload, $this->postingOperation($payload, $commandId), $command),
            default => throw new InvalidArgumentException('Unsupported Titan Ledger command.'),
        };
    }

    /** @param array<string,mixed> $input */
    private function normalizeTrustedCommand(array $input): array
    {
        $name = trim((string) ($input['command_name'] ?? ''));
        $definition = LedgerCommandDefinitionRegistry::definition($name);
        if ($definition === null) throw new InvalidArgumentException('Unsupported Titan Ledger command.');

        $commandId = trim((string) ($input['command_id'] ?? ''));
        if ($commandId === '' || strlen($commandId) > 191) throw new InvalidArgumentException('Trusted command_id is required.');
        $trustedVersion = (int) ($input['command_version'] ?? 0);
        if ($trustedVersion !== 1) throw new InvalidArgumentException('Trusted command_version must be 1.');
        $companyId = (int) ($input['company_id'] ?? 0);
        $actor = (int) ($input['actor_user_id'] ?? 0);
        if ($companyId < 1 || $actor < 1) throw new InvalidArgumentException('Trusted company and actor context is required.');
        $governanceReference = trim((string) ($input['governance_reference'] ?? ''));
        if ($governanceReference === '' || strlen($governanceReference) > 191) throw new InvalidArgumentException('Fresh governance decision reference is required.');
        $caller = trim((string) ($input['caller_extension'] ?? ''));
        if ($caller === '' || strlen($caller) > 100) throw new InvalidArgumentException('caller_extension is required.');
        $target = isset($input['target_public_id']) ? trim((string) $input['target_public_id']) : null;
        if ($target === '') $target = null;
        if (($definition['target_required'] ?? false) && $target === null) throw new InvalidArgumentException('target_public_id is required for this command.');
        $payload = $input['payload'] ?? [];
        if (! is_array($payload)) throw new InvalidArgumentException('Command payload must be an array.');
        $submissionHash = trim((string) ($input['submission_hash'] ?? ''));
        if (! preg_match('/^[a-f0-9]{64}$/', $submissionHash)) throw new InvalidArgumentException('Trusted submission_hash is required.');
        $recomputedSubmissionHash = \App\Extensions\TitanLedger\System\Domains\Commanding\LedgerCommandEnvelope::normalize([
            'command_id'=>$commandId,
            'command_name'=>$name,
            'command_version'=>1,
            'caller_extension'=>$caller,
            'target_public_id'=>$target,
            'payload'=>$payload,
            'trace_id'=>$input['trace_id']??null,
            'correlation_id'=>$input['correlation_id']??null,
            'causation_id'=>$input['causation_id']??null,
        ], $companyId, $actor)['request_hash'];
        if (! hash_equals($submissionHash, $recomputedSubmissionHash)) {
            throw new InvalidArgumentException('Titan Ledger rejected mutated Command Bus submission payload.');
        }

        return [
            'command_id' => $commandId,
            'command_name' => $name,
            'command_version' => 1,
            'company_id' => $companyId,
            'actor_user_id' => $actor,
            'caller_extension' => $caller,
            'target_public_id' => $target,
            'payload' => $payload,
            'governance_reference' => $governanceReference,
            'submission_hash' => $submissionHash,
            'trace_id' => $this->lineage($input, 'trace_id'),
            'correlation_id' => $this->lineage($input, 'correlation_id'),
            'causation_id' => $this->lineage($input, 'causation_id'),
        ];
    }

    private function deleteBookkeepingTransaction(int $userId, string $publicId): array
    {
        $this->transactions->deleteManual($userId, $publicId);
        return ['deleted' => true, 'public_id' => $publicId];
    }

    private function requiredTarget(?string $target): string
    {
        if ($target === null || trim($target) === '') throw new InvalidArgumentException('Command target_public_id is required.');
        return $target;
    }

    private function requiredReason(array $payload): string
    {
        $reason = trim((string) ($payload['reason'] ?? ''));
        if ($reason === '') throw new InvalidArgumentException('Command reason is required.');
        return $reason;
    }

    private function postingOperation(array $payload, string $commandId): string
    {
        $operationId = trim((string) ($payload['operation_id'] ?? ''));
        if ($operationId !== '' && $operationId !== $commandId) throw new InvalidArgumentException('operation_id must match command_id.');
        return $commandId;
    }

    private function withoutOperationId(array $payload): array
    {
        unset($payload['operation_id']);
        return $payload;
    }

    private function context(array $command, array $payload): array
    {
        return array_filter([
            'trace_id' => $command['trace_id'] ?? null,
            'correlation_id' => $command['correlation_id'] ?? null,
            'causation_id' => $command['causation_id'] ?? null,
            'metadata' => $payload['metadata'] ?? null,
        ], static fn ($value) => $value !== null);
    }

    private function lineage(array $input, string $key): ?string
    {
        if (! isset($input[$key]) || $input[$key] === '') return null;
        $value = trim((string) $input[$key]);
        if ($value === '' || strlen($value) > 120) throw new InvalidArgumentException($key . ' is too long.');
        return $value;
    }
}
