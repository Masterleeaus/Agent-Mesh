<?php

declare(strict_types=1);

namespace App\Extensions\TitanLedger\System\Integrations\Forecasting;

use App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityService;
use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotService;

final class CashflowForecastingReadPort
{
    public function __construct(private CashflowForecastService $cashflow,private ProfitabilityService $profitability,private ForecastSnapshotService $snapshots){}
    public function actualCashflow(int $userId,string $from,string $to,string $currency='AUD'):array{return$this->cashflow->actualCashflow($userId,$from,$to,$currency);}
    public function forecast(int $userId,string $asOf,int $horizonDays=90,string $currency='AUD'):array{return$this->cashflow->forecast($userId,$asOf,$horizonDays,$currency);}
    public function profitability(int $userId,string $from,string $to,string $currency='AUD'):array{return$this->profitability->pack($userId,$from,$to,$currency);}
    public function snapshots(int $userId,int $limit=200):array{return$this->snapshots->all($userId,$limit);}
    public function variance(int $userId,string $snapshotPublicId,string $through):array{return$this->snapshots->variance($userId,$snapshotPublicId,$through);}
}
