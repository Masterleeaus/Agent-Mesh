<?php

declare(strict_types=1);
namespace App\Extensions\TitanLedger\System\Domains\Banking;
use InvalidArgumentException;
final class ClearingBalancePolicy
{
    public static function assertPayout(int $availableMinor,int $payoutMinor): void
    {
        if($payoutMinor<1)throw new InvalidArgumentException('Clearing payout amount must be positive.');
        if($availableMinor<$payoutMinor)throw new InvalidArgumentException('Clearing payout exceeds the available clearing balance.');
    }
}
