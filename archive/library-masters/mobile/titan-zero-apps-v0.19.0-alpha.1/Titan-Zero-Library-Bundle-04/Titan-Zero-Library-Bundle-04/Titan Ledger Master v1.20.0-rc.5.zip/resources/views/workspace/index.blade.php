@extends('panel.layout.app')
@section('title', $title)
@section('content')
<div class="container-fluid py-4">
    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
        <div><h1 class="h3 mb-1">{{ $title }}</h1><p class="text-muted mb-0">{{ $subtitle }}</p></div>
        <span class="badge bg-secondary-lt">Titan Ledger</span>
    </div>
    @if(!empty($cards))
        <div class="row g-3 mb-4">
            @foreach($cards as $card)
                <div class="col-sm-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small mb-2">{{ $card['label'] }}</div><div class="h3 mb-0">{{ $card['value'] }}</div></div></div></div>
            @endforeach
        </div>
    @endif
    @if(!empty($columns))
        <div class="card"><div class="card-header"><strong>{{ $title }}</strong></div><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr>@foreach($columns as $column)<th>{{ ucwords(str_replace('_',' ',$column)) }}</th>@endforeach</tr></thead><tbody>
        @forelse($rows as $row)<tr>@foreach($columns as $column)<td>@php($value = is_array($row) ? ($row[$column] ?? null) : ($row->{$column} ?? null))@if(is_bool($value)){{ $value ? 'Yes' : 'No' }}@elseif(is_array($value)){{ json_encode($value) }}@else{{ $value ?? '—' }}@endif</td>@endforeach</tr>@empty<tr><td colspan="{{ count($columns) }}" class="text-muted">No records to display.</td></tr>@endforelse
        </tbody></table></div></div>
    @endif
</div>
@endsection
