@extends('panel.layout.app')
@section('title','Bookkeeping')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Bookkeeping','subtitle'=>'Income, expenses, GST, profit and cash movement for this Titan business.','surface'=>'money','journey'=>'new-bookkeeping-transaction'])
@include('crm::finance-assistants.context-links',['financeSurface'=>'money'])
@if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
<div class="row g-3 mb-4">@foreach(['Income'=>'income_minor','Expenses'=>'expense_minor','Profit / Loss'=>'profit_minor','Net GST'=>'net_gst_minor'] as $label=>$key)<div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">{{ $label }}</div><div class="fs-2 fw-bold">${{ number_format(($summary[$key] ?? 0)/100,2) }}</div></div></div></div>@endforeach</div>
<div class="card"><div class="card-header"><strong>Recent bookkeeping</strong></div><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Source</th><th class="text-end">GST</th><th class="text-end">Total</th></tr></thead><tbody>@forelse($transactions as $row)<tr><td>{{ $row['transaction_date'] }}</td><td>{{ ucfirst($row['type']) }}</td><td>{{ $row['description'] }}</td><td>{{ $row['source_domain'] }}</td><td class="text-end">${{ number_format(($row['gst_minor'] ?? 0)/100,2) }}</td><td class="text-end">${{ number_format(($row['amount_inc_gst_minor'] ?? 0)/100,2) }}</td></tr>@empty<tr><td colspan="6" class="text-muted">No bookkeeping entries yet.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
