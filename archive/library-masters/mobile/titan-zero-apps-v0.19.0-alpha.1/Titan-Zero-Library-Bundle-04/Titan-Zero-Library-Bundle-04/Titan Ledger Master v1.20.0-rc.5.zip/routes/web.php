<?php

declare(strict_types=1);

use App\Extensions\TitanLedger\System\Http\Controllers\BookkeepingController;
use App\Extensions\TitanLedger\System\Http\Controllers\LedgerWorkspaceController;
use App\Extensions\TitanLedger\System\Http\Middleware\EnsureLedgerSuperAdmin;
use App\Http\Middleware\CheckTemplateTypeAndPlan;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmHostEnabled;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use Illuminate\Support\Facades\Route;

$crmMiddleware = array_merge(config('crm.middleware', ['web','auth']), [EnsureCrmHostEnabled::class, CheckTemplateTypeAndPlan::class]);

Route::middleware($crmMiddleware)
    ->prefix('dashboard/user/crm')
    ->name('dashboard.user.crm.')
    ->group(function (): void {
        Route::get('/bookkeeping', [BookkeepingController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.index');
        Route::post('/bookkeeping/transactions', [BookkeepingController::class, 'storeTransaction'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.transactions.store');
        Route::patch('/bookkeeping/transactions/{transaction}', [BookkeepingController::class, 'updateTransaction'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.transactions.update');
        Route::delete('/bookkeeping/transactions/{transaction}', [BookkeepingController::class, 'deleteTransaction'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.transactions.delete');
        Route::post('/bookkeeping/categories', [BookkeepingController::class, 'storeCategory'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.categories.manage')->name('bookkeeping.categories.store');
    });

Route::middleware($crmMiddleware)
    ->prefix('dashboard/user/titan-ledger')
    ->name('dashboard.user.titan-ledger.')
    ->group(function (): void {
        Route::get('/', [LedgerWorkspaceController::class, 'overview'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('overview');
        Route::get('/bookkeeping', [BookkeepingController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping');
        Route::get('/chart-of-accounts', [LedgerWorkspaceController::class, 'accounts'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('accounts');
        Route::get('/journals', [LedgerWorkspaceController::class, 'journals'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('journals');
        Route::get('/financial-years', [LedgerWorkspaceController::class, 'financialYears'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('financial-years');
        Route::get('/year-end-close', [LedgerWorkspaceController::class, 'yearEndClose'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('year-end-close');
        Route::get('/accounting-periods', [LedgerWorkspaceController::class, 'accountingPeriods'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('accounting-periods');
        Route::get('/command-receipts', [LedgerWorkspaceController::class, 'commandReceipts'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('command-receipts');
        Route::get('/financial-events', [LedgerWorkspaceController::class, 'financialEvents'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('financial-events');
        Route::get('/governance-evidence', [LedgerWorkspaceController::class, 'governanceEvidence'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('governance-evidence');
        Route::get('/invoice-accounting', [LedgerWorkspaceController::class, 'invoiceAccounting'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('invoice-accounting');
        Route::get('/payment-settlements', [LedgerWorkspaceController::class, 'paymentSettlements'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('payment-settlements');
        Route::get('/payables', [LedgerWorkspaceController::class, 'payables'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('payables');
        Route::get('/receivables', [LedgerWorkspaceController::class, 'receivables'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('receivables');
        Route::get('/bank-reconciliation', [LedgerWorkspaceController::class, 'bankReconciliation'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bank-reconciliation');
        Route::get('/banking-accounts', [LedgerWorkspaceController::class, 'bankingAccounts'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('banking-accounts');
        Route::get('/reconciliation-automation', [LedgerWorkspaceController::class, 'reconciliationAutomation'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('reconciliation-automation');
        Route::get('/gst-bas', [LedgerWorkspaceController::class, 'gstBas'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('gst-bas');
        Route::get('/gst-adjustments', [LedgerWorkspaceController::class, 'gstAdjustments'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('gst-adjustments');
        Route::get('/financial-reports', [LedgerWorkspaceController::class, 'financialReports'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('financial-reports');
        Route::get('/cashflow-forecasts', [LedgerWorkspaceController::class, 'cashflowForecasts'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('cashflow-forecasts');
        Route::get('/diagnostics', [LedgerWorkspaceController::class, 'diagnostics'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('diagnostics');
    });

Route::middleware(['web', 'auth', EnsureLedgerSuperAdmin::class])
    ->prefix('dashboard/admin/titan-ledger')
    ->name('dashboard.admin.titan-ledger.')
    ->group(function (): void {
        Route::get('/', [LedgerWorkspaceController::class, 'adminOverview'])->name('overview');
        Route::get('/command-authority', [LedgerWorkspaceController::class, 'commandAuthority'])->name('command-authority');
        Route::get('/signal-fabric', [LedgerWorkspaceController::class, 'signalFabric'])->name('signal-fabric');
        Route::get('/risk-assurance', [LedgerWorkspaceController::class, 'riskAssurance'])->name('risk-assurance');
        Route::get('/rewind-integration', [LedgerWorkspaceController::class, 'rewindIntegration'])->name('rewind-integration');
        Route::get('/crm-invoice-adapter', [LedgerWorkspaceController::class, 'crmInvoiceAdapter'])->name('crm-invoice-adapter');
        Route::get('/titan-pay-adapter', [LedgerWorkspaceController::class, 'titanPayAdapter'])->name('titan-pay-adapter');
        Route::get('/ar-collections', [LedgerWorkspaceController::class, 'arCollections'])->name('ar-collections');
        Route::get('/ap-spend-adapter', [LedgerWorkspaceController::class, 'apSpendAdapter'])->name('ap-spend-adapter');
        Route::get('/banking-reconciliation', [LedgerWorkspaceController::class, 'bankingReconciliation'])->name('banking-reconciliation');
        Route::get('/multi-account-banking', [LedgerWorkspaceController::class, 'multiAccountBanking'])->name('multi-account-banking');
        Route::get('/advanced-reconciliation', [LedgerWorkspaceController::class, 'advancedReconciliation'])->name('advanced-reconciliation');
        Route::get('/gst-tax-ledger', [LedgerWorkspaceController::class, 'gstTaxLedger'])->name('gst-tax-ledger');
        Route::get('/advanced-gst-control', [LedgerWorkspaceController::class, 'gstTaxLedger'])->name('advanced-gst-control');
        Route::get('/financial-reporting', [LedgerWorkspaceController::class, 'financialReporting'])->name('financial-reporting');
        Route::get('/forecasting-profitability', [LedgerWorkspaceController::class, 'forecastingProfitability'])->name('forecasting-profitability');
        Route::get('/fiscal-close-control', [LedgerWorkspaceController::class, 'fiscalCloseControl'])->name('fiscal-close-control');
        Route::get('/production-certification', [LedgerWorkspaceController::class, 'productionCertification'])->name('production-certification');
        Route::get('/menu-diagnostics', [LedgerWorkspaceController::class, 'menuDiagnostics'])->name('menu-diagnostics');
        Route::get('/system-diagnostics', [LedgerWorkspaceController::class, 'systemDiagnostics'])->name('system-diagnostics');
    });
