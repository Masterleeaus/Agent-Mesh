<?php

declare(strict_types=1);

use App\Extensions\TitanLedger\System\Http\Controllers\BookkeepingController;
use App\Extensions\TitanLedger\System\Http\Controllers\AccountingPeriodController;
use App\Extensions\TitanLedger\System\Http\Controllers\ChartOfAccountsController;
use App\Extensions\TitanLedger\System\Http\Controllers\JournalController;
use App\Extensions\TitanLedger\System\Http\Controllers\LedgerCommandController;
use App\Extensions\TitanLedger\System\Http\Controllers\ReceivableController;
use App\Extensions\TitanLedger\System\Http\Controllers\PayableController;
use App\Extensions\TitanLedger\System\Http\Controllers\ReconciliationController;
use App\Extensions\TitanLedger\System\Http\Controllers\TaxLedgerController;
use App\Extensions\TitanLedger\System\Http\Controllers\FinancialReportingController;
use App\Extensions\TitanLedger\System\Http\Controllers\ForecastingController;
use App\Extensions\TitanLedger\System\Http\Controllers\FinancialYearCloseController;
use App\Extensions\TitanLedger\System\Http\Controllers\MultiAccountBankingController;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use Illuminate\Support\Facades\Route;

Route::middleware(config('crm.api_middleware', ['api', 'auth:api']))
    ->prefix('api/crm')
    ->name('api.crm.')
    ->group(function (): void {
        Route::post('/bookkeeping/commands', [LedgerCommandController::class, 'execute'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.commands.execute');
        Route::get('/bookkeeping/overview', [BookkeepingController::class, 'overview'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.overview');
        Route::get('/bookkeeping/pnl', [BookkeepingController::class, 'profitAndLoss'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.pnl');
        Route::get('/bookkeeping/transactions', [BookkeepingController::class, 'transactions'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.transactions');
        Route::post('/bookkeeping/transactions', [BookkeepingController::class, 'storeTransaction'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.transactions.store');
        Route::get('/bookkeeping/categories', [BookkeepingController::class, 'categories'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.categories');
        Route::post('/bookkeeping/categories', [BookkeepingController::class, 'storeCategory'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.categories.manage')->name('bookkeeping.categories.store');
        Route::get('/bookkeeping/accounts', [ChartOfAccountsController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.accounts');
        Route::post('/bookkeeping/accounts', [ChartOfAccountsController::class, 'store'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.accounts.store');
        Route::patch('/bookkeeping/accounts/{account}', [ChartOfAccountsController::class, 'update'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.accounts.update');
        Route::get('/bookkeeping/journals', [JournalController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.journals');
        Route::post('/bookkeeping/journals', [JournalController::class, 'store'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.store');
        Route::get('/bookkeeping/journals/{journal}', [JournalController::class, 'show'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.journals.show');
        Route::put('/bookkeeping/journals/{journal}/lines', [JournalController::class, 'replaceLines'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.lines.replace');
        Route::post('/bookkeeping/journals/{journal}/validate', [JournalController::class, 'validate'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.validate');
        Route::post('/bookkeeping/journals/{journal}/post', [JournalController::class, 'post'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.post');
        Route::post('/bookkeeping/journals/{journal}/reverse', [JournalController::class, 'reverse'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.reverse');
        Route::post('/bookkeeping/journals/{journal}/corrections', [JournalController::class, 'correction'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.journals.corrections.store');
        Route::get('/bookkeeping/financial-years', [AccountingPeriodController::class, 'financialYears'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.financial-years');
        Route::post('/bookkeeping/financial-years', [AccountingPeriodController::class, 'createFinancialYear'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.financial-years.store');
        Route::post('/bookkeeping/financial-years/{financialYear}/close/prepare', [AccountingPeriodController::class, 'prepareFinancialYearClose'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.financial-years.close.prepare');
        Route::get('/bookkeeping/financial-years/{financialYear}/close-preview', [FinancialYearCloseController::class, 'preview'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.financial-years.close-preview');
        Route::get('/bookkeeping/financial-year-closes', [FinancialYearCloseController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.financial-year-closes');
        Route::post('/bookkeeping/financial-years/{financialYear}/close', [AccountingPeriodController::class, 'closeFinancialYear'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.financial-years.close');
        Route::post('/bookkeeping/financial-years/{financialYear}/reopen', [AccountingPeriodController::class, 'reopenFinancialYear'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.financial-years.reopen');
        Route::get('/bookkeeping/payables', [PayableController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.payables');
        Route::get('/bookkeeping/payables/aging', [PayableController::class, 'aging'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.payables.aging');
        Route::get('/bookkeeping/bank-statements', [ReconciliationController::class, 'statements'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.bank-statements');
        Route::get('/bookkeeping/reconciliation-sessions', [ReconciliationController::class, 'sessions'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.reconciliation-sessions');
        Route::get('/bookkeeping/reconciliation-groups', [ReconciliationController::class, 'groups'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.reconciliation-groups');
        Route::get('/bookkeeping/banking/accounts', [MultiAccountBankingController::class, 'accounts'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.banking.accounts');
        Route::get('/bookkeeping/banking/movements', [MultiAccountBankingController::class, 'movements'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.banking.movements');
        Route::get('/bookkeeping/gst/preview', [TaxLedgerController::class, 'preview'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.gst.preview');
        Route::get('/bookkeeping/gst/snapshots', [TaxLedgerController::class, 'snapshots'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.gst.snapshots');
        Route::get('/bookkeeping/gst/adjustments', [TaxLedgerController::class, 'adjustments'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.gst.adjustments');
        Route::get('/bookkeeping/reports/trial-balance', [FinancialReportingController::class, 'trialBalance'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.trial-balance');
        Route::get('/bookkeeping/reports/profit-loss', [FinancialReportingController::class, 'profitLoss'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.profit-loss');
        Route::get('/bookkeeping/reports/balance-sheet', [FinancialReportingController::class, 'balanceSheet'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.balance-sheet');
        Route::get('/bookkeeping/reports/retained-earnings', [FinancialReportingController::class, 'retainedEarnings'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.retained-earnings');
        Route::get('/bookkeeping/reports/management-pack', [FinancialReportingController::class, 'managementPack'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.management-pack');
        Route::get('/bookkeeping/reports/accounts/{account}/drilldown', [FinancialReportingController::class, 'drilldown'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.account-drilldown');
        Route::get('/bookkeeping/reports/snapshots', [FinancialReportingController::class, 'snapshots'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.reports.snapshots');
        Route::get('/bookkeeping/forecasting/actual-cashflow', [ForecastingController::class, 'actual'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.forecasting.actual-cashflow');
        Route::get('/bookkeeping/forecasting/cashflow', [ForecastingController::class, 'forecast'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.forecasting.cashflow');
        Route::get('/bookkeeping/forecasting/profitability', [ForecastingController::class, 'profitability'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.forecasting.profitability');
        Route::get('/bookkeeping/forecasting/snapshots', [ForecastingController::class, 'snapshots'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.forecasting.snapshots');
        Route::get('/bookkeeping/forecasting/snapshots/{snapshot}/variance', [ForecastingController::class, 'variance'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.forecasting.snapshots.variance');
        Route::get('/bookkeeping/bank-statements/{statement}/transactions', [ReconciliationController::class, 'transactions'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.bank-statements.transactions');
        Route::get('/bookkeeping/bank-statements/{statement}/reconciliation-suggestions', [ReconciliationController::class, 'suggestions'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.bank-statements.reconciliation-suggestions');
        Route::get('/bookkeeping/receivables', [ReceivableController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.receivables');
        Route::get('/bookkeeping/receivables/aging', [ReceivableController::class, 'aging'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.reports.view')->name('bookkeeping.receivables.aging');
        Route::get('/bookkeeping/accounting-periods', [AccountingPeriodController::class, 'accountingPeriods'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.view')->name('bookkeeping.accounting-periods');
        Route::post('/bookkeeping/accounting-periods/{period}/lock-state', [AccountingPeriodController::class, 'transitionPeriod'])->middleware(EnsureCrmPermission::class . ':crm.bookkeeping.manage')->name('bookkeeping.accounting-periods.lock-state');
    });
