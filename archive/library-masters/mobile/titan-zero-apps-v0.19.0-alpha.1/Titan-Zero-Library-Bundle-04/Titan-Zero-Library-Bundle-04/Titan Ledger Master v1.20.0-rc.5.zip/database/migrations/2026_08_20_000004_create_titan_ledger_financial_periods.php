<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER = 'titan-ledger';
    private const YEARS = 'titan_ledger_financial_years';
    private const PERIODS = 'titan_ledger_accounting_periods';
    private const EVENTS = 'titan_ledger_period_lock_events';
    private const JOURNALS = 'titan_ledger_journals';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();

        $yearsExisted = Schema::hasTable(self::YEARS);
        if (! $yearsExisted) {
            Schema::create(self::YEARS, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('label', 40);
                $t->date('starts_on')->index();
                $t->date('ends_on')->index();
                $t->string('calendar_type', 30)->default('australian');
                $t->string('status', 20)->default('open')->index();
                $t->unsignedInteger('lock_version')->default(0);
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->unsignedBigInteger('closed_by_user_id')->nullable()->index();
                $t->timestamp('closed_at')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id', 'label'], 'titan_ledger_fy_company_label_unique');
                $t->unique(['company_id', 'starts_on', 'ends_on'], 'titan_ledger_fy_company_dates_unique');
            });
        } else {
            $this->assertShape(self::YEARS, ['public_id','company_id','label','starts_on','ends_on','calendar_type','status','lock_version']);
        }
        $this->recordOwnership(self::YEARS, $yearsExisted ? 'adopted' : 'created');

        $periodsExisted = Schema::hasTable(self::PERIODS);
        if (! $periodsExisted) {
            Schema::create(self::PERIODS, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('financial_year_public_id', 26)->index();
                $t->unsignedSmallInteger('period_no');
                $t->string('label', 50);
                $t->date('starts_on')->index();
                $t->date('ends_on')->index();
                $t->string('lock_state', 20)->default('open')->index();
                $t->unsignedInteger('lock_version')->default(0);
                $t->unsignedBigInteger('locked_by_user_id')->nullable()->index();
                $t->timestamp('locked_at')->nullable();
                $t->string('lock_reason', 500)->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','financial_year_public_id','period_no'], 'titan_ledger_period_company_fy_number_unique');
                $t->unique(['company_id','starts_on','ends_on'], 'titan_ledger_period_company_dates_unique');
                $t->index(['company_id','lock_state','starts_on','ends_on'], 'titan_ledger_period_company_lock_dates');
            });
        } else {
            $this->assertShape(self::PERIODS, ['public_id','company_id','financial_year_public_id','period_no','starts_on','ends_on','lock_state','lock_version']);
        }
        $this->recordOwnership(self::PERIODS, $periodsExisted ? 'adopted' : 'created');

        $eventsExisted = Schema::hasTable(self::EVENTS);
        if (! $eventsExisted) {
            Schema::create(self::EVENTS, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('financial_year_public_id', 26)->index();
                $t->char('period_public_id', 26)->index();
                $t->string('from_state', 20);
                $t->string('to_state', 20);
                $t->string('reason', 500);
                $t->unsignedBigInteger('actor_user_id')->nullable()->index();
                $t->string('trace_id', 120)->nullable()->index();
                $t->string('correlation_id', 120)->nullable()->index();
                $t->string('causation_id', 120)->nullable()->index();
                $t->json('metadata')->nullable();
                $t->timestamp('created_at')->useCurrent();
                $t->index(['company_id','period_public_id','created_at'], 'titan_ledger_period_event_lookup');
            });
        } else {
            $this->assertShape(self::EVENTS, ['public_id','company_id','financial_year_public_id','period_public_id','from_state','to_state','reason','actor_user_id','created_at']);
        }
        $this->recordOwnership(self::EVENTS, $eventsExisted ? 'adopted' : 'created');

        if (! Schema::hasTable(self::JOURNALS)) {
            throw new RuntimeException('Titan Ledger Pass 4 requires the Pass 3 journal table.');
        }
        Schema::table(self::JOURNALS, function (Blueprint $t): void {
            if (! Schema::hasColumn(self::JOURNALS, 'financial_year_public_id')) $t->char('financial_year_public_id', 26)->nullable()->index();
            if (! Schema::hasColumn(self::JOURNALS, 'accounting_period_public_id')) $t->char('accounting_period_public_id', 26)->nullable()->index();
            if (! Schema::hasColumn(self::JOURNALS, 'prior_period_adjustment')) $t->boolean('prior_period_adjustment')->default(false)->index();
            if (! Schema::hasColumn(self::JOURNALS, 'period_override_reason')) $t->string('period_override_reason', 500)->nullable();
            if (! Schema::hasColumn(self::JOURNALS, 'period_lock_state_at_post')) $t->string('period_lock_state_at_post', 20)->nullable();
        });

        $this->installAuditTriggers();
        $this->installPostingGuardTrigger();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function installPostingGuardTrigger(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        $this->dropPostingGuardTrigger();
        DB::unprepared("CREATE TRIGGER titan_ledger_journal_period_guard_before_post BEFORE UPDATE ON titan_ledger_journals FOR EACH ROW
            BEGIN
                DECLARE period_state VARCHAR(20);
                DECLARE period_start DATE;
                DECLARE period_end DATE;
                IF OLD.status <> 'posted' AND NEW.status = 'posted' THEN
                    IF NEW.accounting_period_public_id IS NULL OR NEW.financial_year_public_id IS NULL THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posting requires accounting period attribution';
                    END IF;
                    SELECT lock_state, starts_on, ends_on INTO period_state, period_start, period_end
                    FROM titan_ledger_accounting_periods
                    WHERE company_id = NEW.company_id AND public_id = NEW.accounting_period_public_id
                    LIMIT 1;
                    IF period_state IS NULL OR NEW.entry_date < period_start OR NEW.entry_date > period_end THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger accounting period does not cover journal entry date';
                    END IF;
                    IF period_state = 'hard_locked' THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger accounting period is hard-locked';
                    END IF;
                    IF period_state = 'soft_locked' AND (
                        NEW.prior_period_adjustment = 0 OR
                        NEW.period_override_reason IS NULL OR TRIM(NEW.period_override_reason) = '' OR
                        NEW.journal_type NOT IN ('adjustment','correction','reversal','year_end_close','year_end_reopen')
                    ) THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger soft-locked period requires governed prior-period adjustment';
                    END IF;
                END IF;
            END");
    }

    private function dropPostingGuardTrigger(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        DB::unprepared('DROP TRIGGER IF EXISTS `titan_ledger_journal_period_guard_before_post`');
    }

    private function installAuditTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        $this->dropAuditTriggers();
        DB::unprepared("CREATE TRIGGER titan_ledger_period_event_no_update BEFORE UPDATE ON titan_ledger_period_lock_events FOR EACH ROW
            BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger period lock events are immutable'; END");
        DB::unprepared("CREATE TRIGGER titan_ledger_period_event_no_delete BEFORE DELETE ON titan_ledger_period_lock_events FOR EACH ROW
            BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger period lock events cannot be deleted'; END");
    }

    private function dropAuditTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        foreach (['titan_ledger_period_event_no_update','titan_ledger_period_event_no_delete'] as $trigger) {
            DB::unprepared('DROP TRIGGER IF EXISTS `' . $trigger . '`');
        }
    }

    private function assertShape(string $table, array $columns): void
    {
        foreach ($columns as $column) {
            if (! Schema::hasColumn($table, $column)) {
                throw new RuntimeException('Titan Ledger refused to adopt incompatible ' . $table . ': missing ' . $column . '.');
            }
        }
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function (Blueprint $t): void {
            $t->id();
            $t->string('table_name', 190)->unique();
            $t->string('owner_extension', 100)->index();
            $t->string('ownership_mode', 30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }

    private function recordOwnership(string $table, string $mode): void
    {
        DB::table('titan_ledger_schema_ownership')->updateOrInsert(
            ['table_name' => $table],
            [
                'owner_extension' => self::OWNER,
                'ownership_mode' => $mode,
                'first_seen_at' => now(),
                'metadata' => json_encode(['migration' => '2026_08_20_000004_create_titan_ledger_financial_periods', 'uninstall_policy' => 'retain']),
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
};
