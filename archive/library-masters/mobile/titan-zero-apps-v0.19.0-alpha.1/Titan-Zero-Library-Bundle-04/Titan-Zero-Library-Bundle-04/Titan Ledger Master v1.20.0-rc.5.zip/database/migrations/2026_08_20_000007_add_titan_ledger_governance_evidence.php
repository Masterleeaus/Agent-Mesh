<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const COLUMNS=['risk_reference','risk_class','risk_score','risk_ruleset_version','assurance_reference','assurance_class','assurance_score','assurance_ruleset_version'];
    public function up(): void
    {
        foreach(['titan_ledger_command_receipts','titan_ledger_signal_outbox'] as $table){
            if(!Schema::hasTable($table)) throw new RuntimeException('Titan Ledger governance evidence requires '.$table.'.');
            Schema::table($table,function(Blueprint $t) use($table): void {
                if(!Schema::hasColumn($table,'risk_reference')) $t->string('risk_reference',191)->nullable()->index();
                if(!Schema::hasColumn($table,'risk_class')) $t->string('risk_class',30)->nullable()->index();
                if(!Schema::hasColumn($table,'risk_score')) $t->decimal('risk_score',6,5)->nullable();
                if(!Schema::hasColumn($table,'risk_ruleset_version')) $t->string('risk_ruleset_version',100)->nullable();
                if(!Schema::hasColumn($table,'assurance_reference')) $t->string('assurance_reference',191)->nullable()->index();
                if(!Schema::hasColumn($table,'assurance_class')) $t->string('assurance_class',30)->nullable()->index();
                if(!Schema::hasColumn($table,'assurance_score')) $t->decimal('assurance_score',6,5)->nullable();
                if(!Schema::hasColumn($table,'assurance_ruleset_version')) $t->string('assurance_ruleset_version',100)->nullable();
            });
        }
        $this->installTriggers();
    }
    public function down(): void {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql') return;
        $this->dropTriggers();
        DB::unprepared("CREATE TRIGGER titan_ledger_governance_receipt_guard BEFORE UPDATE ON titan_ledger_command_receipts FOR EACH ROW BEGIN IF NOT (NEW.risk_reference <=> OLD.risk_reference) OR NOT (NEW.risk_class <=> OLD.risk_class) OR NOT (NEW.risk_score <=> OLD.risk_score) OR NOT (NEW.risk_ruleset_version <=> OLD.risk_ruleset_version) OR NOT (NEW.assurance_reference <=> OLD.assurance_reference) OR NOT (NEW.assurance_class <=> OLD.assurance_class) OR NOT (NEW.assurance_score <=> OLD.assurance_score) OR NOT (NEW.assurance_ruleset_version <=> OLD.assurance_ruleset_version) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger external governance evidence is immutable'; END IF; END");
        DB::unprepared("CREATE TRIGGER titan_ledger_governance_signal_guard BEFORE UPDATE ON titan_ledger_signal_outbox FOR EACH ROW BEGIN IF NOT (NEW.risk_reference <=> OLD.risk_reference) OR NOT (NEW.risk_class <=> OLD.risk_class) OR NOT (NEW.risk_score <=> OLD.risk_score) OR NOT (NEW.risk_ruleset_version <=> OLD.risk_ruleset_version) OR NOT (NEW.assurance_reference <=> OLD.assurance_reference) OR NOT (NEW.assurance_class <=> OLD.assurance_class) OR NOT (NEW.assurance_score <=> OLD.assurance_score) OR NOT (NEW.assurance_ruleset_version <=> OLD.assurance_ruleset_version) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger Signal governance evidence is immutable'; END IF; END");
    }
    private function dropTriggers(): void { if(DB::connection()->getDriverName()!=='mysql')return; DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_governance_receipt_guard'); DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_governance_signal_guard'); }
};
