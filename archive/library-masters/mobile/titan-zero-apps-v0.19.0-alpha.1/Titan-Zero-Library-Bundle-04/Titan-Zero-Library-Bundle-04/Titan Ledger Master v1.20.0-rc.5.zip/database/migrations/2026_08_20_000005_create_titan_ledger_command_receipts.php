<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER = 'titan-ledger';
    private const TABLE = 'titan_ledger_command_receipts';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();
        $existed = Schema::hasTable(self::TABLE);

        if (! $existed) {
            Schema::create(self::TABLE, function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->char('public_id', 26)->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('command_id', 191);
                $table->string('command_name', 120)->index();
                $table->unsignedSmallInteger('command_version')->default(1);
                $table->string('caller_extension', 100)->index();
                $table->unsignedBigInteger('actor_user_id')->index();
                $table->string('target_public_id', 191)->nullable()->index();
                $table->string('governance_reference', 191)->index();
                $table->string('trace_id', 120)->nullable()->index();
                $table->string('correlation_id', 120)->nullable()->index();
                $table->string('causation_id', 120)->nullable()->index();
                $table->char('request_hash', 64);
                $table->string('status', 30)->default('started')->index();
                $table->string('result_public_id', 191)->nullable()->index();
                $table->longText('result_payload')->nullable();
                $table->char('write_fingerprint', 64)->nullable();
                $table->boolean('write_verified')->default(false);
                $table->string('error_code', 120)->nullable();
                $table->string('error_message_redacted', 255)->nullable();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'command_id'], 'tl_receipt_company_command_unique');
                $table->index(['company_id','command_name','status'], 'tl_receipt_company_name_status');
            });
        } else {
            foreach ([
                'public_id','company_id','command_id','command_name','command_version','caller_extension','actor_user_id',
                'target_public_id','governance_reference','trace_id','correlation_id','causation_id','request_hash','status',
                'result_public_id','result_payload','write_fingerprint','write_verified','error_code','error_message_redacted',
                'started_at','completed_at','created_at','updated_at',
            ] as $column) {
                if (! Schema::hasColumn(self::TABLE, $column)) {
                    throw new RuntimeException('Titan Ledger refused to adopt incompatible command receipts: missing ' . $column . '.');
                }
            }
        }

        DB::table('titan_ledger_schema_ownership')->updateOrInsert(
            ['table_name' => self::TABLE],
            [
                'owner_extension' => self::OWNER,
                'ownership_mode' => $existed ? 'adopted' : 'created',
                'first_seen_at' => now(),
                'metadata' => json_encode(['migration'=>'2026_08_20_000005_create_titan_ledger_command_receipts','uninstall_policy'=>'retain']),
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        $this->installTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function installTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        $this->dropTriggers();
        DB::unprepared("CREATE TRIGGER titan_ledger_command_receipts_guard_insert BEFORE INSERT ON titan_ledger_command_receipts FOR EACH ROW BEGIN IF NEW.status <> 'started' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger command receipts must begin in started state'; END IF; END");
        DB::unprepared("CREATE TRIGGER titan_ledger_command_receipts_guard_update BEFORE UPDATE ON titan_ledger_command_receipts FOR EACH ROW BEGIN IF OLD.status IN ('applied','failed','denied') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger command receipts are immutable after completion'; END IF; IF NEW.status NOT IN ('applied','failed','denied') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger command receipt status transition is invalid'; END IF; IF NOT (NEW.public_id <=> OLD.public_id) OR NOT (NEW.company_id <=> OLD.company_id) OR NOT (NEW.command_id <=> OLD.command_id) OR NOT (NEW.command_name <=> OLD.command_name) OR NOT (NEW.command_version <=> OLD.command_version) OR NOT (NEW.caller_extension <=> OLD.caller_extension) OR NOT (NEW.actor_user_id <=> OLD.actor_user_id) OR NOT (NEW.target_public_id <=> OLD.target_public_id) OR NOT (NEW.governance_reference <=> OLD.governance_reference) OR NOT (NEW.trace_id <=> OLD.trace_id) OR NOT (NEW.correlation_id <=> OLD.correlation_id) OR NOT (NEW.causation_id <=> OLD.causation_id) OR NOT (NEW.request_hash <=> OLD.request_hash) OR NOT (NEW.started_at <=> OLD.started_at) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger command receipt identity is immutable'; END IF; IF NEW.status = 'applied' AND (NEW.write_verified <> 1 OR NEW.write_fingerprint IS NULL OR NEW.result_payload IS NULL OR NEW.completed_at IS NULL) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger applied receipt evidence is incomplete'; END IF; IF NEW.status IN ('failed','denied') AND NEW.completed_at IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger failed or denied receipt must be completed'; END IF; END");
        DB::unprepared("CREATE TRIGGER titan_ledger_command_receipts_guard_delete BEFORE DELETE ON titan_ledger_command_receipts FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger command receipts cannot be deleted'; END");
    }

    private function dropTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        foreach (['titan_ledger_command_receipts_guard_insert','titan_ledger_command_receipts_guard_update','titan_ledger_command_receipts_guard_delete'] as $trigger) {
            DB::unprepared('DROP TRIGGER IF EXISTS `' . $trigger . '`');
        }
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function (Blueprint $t): void {
            $t->id();
            $t->string('table_name', 190)->unique();
            $t->string('owner_extension', 100)->index();
            $t->string('ownership_mode', 30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }
};
