<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER = 'titan-ledger';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();

        $categoriesExisted=Schema::hasTable('crm_bookkeeping_categories');
        if (! $categoriesExisted) {
            Schema::create('crm_bookkeeping_categories', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('type', 20)->index();
                $t->string('name', 180);
                $t->string('slug', 140);
                $t->text('description')->nullable();
                $t->boolean('is_system_default')->default(false)->index();
                $t->boolean('is_active')->default(true)->index();
                $t->unsignedInteger('sort_order')->default(0);
                $t->json('metadata')->nullable();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->timestamps();
                $t->unique(['company_id','type','slug'], 'crm_bookkeeping_category_unique');
                $t->index(['company_id','type','is_active'], 'crm_bookkeeping_category_list');
            });
        }
        $this->recordOwnership('crm_bookkeeping_categories',$categoriesExisted?'adopted':'created');

        $transactionsExisted=Schema::hasTable('crm_bookkeeping_transactions');
        if (! $transactionsExisted) {
            Schema::create('crm_bookkeeping_transactions', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('type', 20)->index();
                $t->char('category_public_id', 26)->nullable()->index();
                $t->date('transaction_date')->index();
                $t->char('work_order_public_id', 26)->nullable()->index();
                $t->char('company_public_id', 26)->nullable()->index();
                $t->char('contact_public_id', 26)->nullable()->index();
                $t->char('document_public_id', 26)->nullable()->index();
                $t->string('payee_name', 190)->nullable()->index();
                $t->string('description', 255);
                $t->string('reference', 160)->nullable()->index();
                $t->bigInteger('amount_ex_gst_minor')->default(0);
                $t->bigInteger('gst_minor')->default(0);
                $t->bigInteger('amount_inc_gst_minor')->default(0);
                $t->string('gst_treatment', 30)->default('gst_free')->index();
                $t->unsignedInteger('gst_rate_bps')->default(1000);
                $t->char('currency', 3)->default('AUD')->index();
                $t->string('payment_method', 80)->nullable()->index();
                $t->string('source_domain', 60)->default('manual')->index();
                $t->string('source_type', 80)->nullable()->index();
                $t->char('source_public_id', 26)->nullable()->index();
                $t->string('source_event_id', 190)->nullable()->index();
                $t->string('source_key', 160)->nullable();
                $t->text('notes')->nullable();
                $t->json('metadata')->nullable();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->softDeletes();
                $t->timestamps();
                $t->unique(['company_id','source_key'], 'crm_bookkeeping_source_unique');
                $t->index(['company_id','transaction_date','type'], 'crm_bookkeeping_period_type');
            });
        }
        $this->recordOwnership('crm_bookkeeping_transactions',$transactionsExisted?'adopted':'created');
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function(Blueprint $t): void {
            $t->id();
            $t->string('table_name',190)->unique();
            $t->string('owner_extension',100)->index();
            $t->string('ownership_mode',30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }

    private function recordOwnership(string $table,string $mode): void
    {
        DB::table('titan_ledger_schema_ownership')->updateOrInsert(
            ['table_name'=>$table],
            ['owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_09_000015_add_crm_simple_bookkeeping']),'created_at'=>now(),'updated_at'=>now()]
        );
    }
};
