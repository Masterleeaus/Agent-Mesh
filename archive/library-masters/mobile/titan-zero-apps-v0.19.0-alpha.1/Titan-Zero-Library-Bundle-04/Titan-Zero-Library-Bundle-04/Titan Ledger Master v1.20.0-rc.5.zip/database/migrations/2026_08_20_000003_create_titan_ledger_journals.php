<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER = 'titan-ledger';
    private const JOURNALS = 'titan_ledger_journals';
    private const LINES = 'titan_ledger_journal_lines';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();

        $journalsExisted = Schema::hasTable(self::JOURNALS);
        if (! $journalsExisted) {
            Schema::create(self::JOURNALS, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('journal_number', 40)->nullable();
                $t->string('journal_type', 30)->default('general')->index();
                $t->string('status', 20)->default('draft')->index();
                $t->date('entry_date')->index();
                $t->string('currency', 3)->default('AUD');
                $t->string('memo', 500)->nullable();
                $t->unsignedBigInteger('debit_total_minor')->nullable();
                $t->unsignedBigInteger('credit_total_minor')->nullable();

                $t->string('source_extension', 100)->nullable()->index();
                $t->string('source_type', 100)->nullable();
                $t->string('source_public_id', 100)->nullable();
                $t->string('source_event_id', 120)->nullable()->index();
                $t->string('source_operation_id', 191)->nullable();
                $t->string('trace_id', 120)->nullable()->index();
                $t->string('correlation_id', 120)->nullable()->index();
                $t->string('causation_id', 120)->nullable()->index();

                $t->char('reversal_of_public_id', 26)->nullable()->index();
                $t->char('correction_of_public_id', 26)->nullable()->index();
                $t->string('posting_operation_id', 191)->nullable();
                $t->char('payload_hash', 64)->nullable();
                $t->unsignedInteger('lock_version')->default(0);

                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->unsignedBigInteger('validated_by_user_id')->nullable()->index();
                $t->unsignedBigInteger('posted_by_user_id')->nullable()->index();
                $t->timestamp('validated_at')->nullable();
                $t->timestamp('posted_at')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();

                $t->unique(['company_id','journal_number'], 'titan_ledger_journal_company_number_unique');
                $t->unique(['company_id','posting_operation_id'], 'titan_ledger_journal_company_post_operation_unique');
                $t->unique(['company_id','reversal_of_public_id'], 'titan_ledger_journal_one_reversal_unique');
                $t->index(['company_id','status','entry_date'], 'titan_ledger_journal_company_status_date');
                $t->index(['company_id','source_extension','source_public_id'], 'titan_ledger_journal_source_lookup');
            });
        } else {
            $this->assertJournalShape();
        }
        $this->recordOwnership(self::JOURNALS, $journalsExisted ? 'adopted' : 'created');

        $linesExisted = Schema::hasTable(self::LINES);
        if (! $linesExisted) {
            Schema::create(self::LINES, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('journal_public_id', 26)->index();
                $t->unsignedInteger('line_no');
                $t->char('account_public_id', 26)->index();
                $t->string('description', 255)->nullable();
                $t->unsignedBigInteger('debit_minor')->default(0);
                $t->unsignedBigInteger('credit_minor')->default(0);
                $t->string('tax_code', 40)->nullable()->index();
                $t->bigInteger('tax_amount_minor')->default(0);
                $t->json('metadata')->nullable();
                $t->timestamps();

                $t->unique(['company_id','journal_public_id','line_no'], 'titan_ledger_journal_line_number_unique');
                $t->index(['company_id','account_public_id'], 'titan_ledger_journal_line_account_lookup');
            });
        } else {
            $this->assertLineShape();
        }
        $this->recordOwnership(self::LINES, $linesExisted ? 'adopted' : 'created');
        $this->installImmutabilityTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }


    private function installImmutabilityTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;

        $this->dropImmutabilityTriggers();

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_no_direct_post_insert BEFORE INSERT ON titan_ledger_journals FOR EACH ROW
            BEGIN
                IF NEW.status = 'posted' THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger journals must transition through validation before posting';
                END IF;
            END");

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_posted_no_update BEFORE UPDATE ON titan_ledger_journals FOR EACH ROW
            BEGIN
                IF OLD.status = 'posted' THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posted journal headers are immutable';
                END IF;
            END");

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_posted_no_delete BEFORE DELETE ON titan_ledger_journals FOR EACH ROW
            BEGIN
                IF OLD.status = 'posted' THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posted journal headers cannot be deleted';
                END IF;
            END");

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_line_no_insert_after_post BEFORE INSERT ON titan_ledger_journal_lines FOR EACH ROW
            BEGIN
                IF EXISTS (
                    SELECT 1 FROM titan_ledger_journals
                    WHERE company_id = NEW.company_id AND public_id = NEW.journal_public_id AND status = 'posted'
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posted journal lines are immutable';
                END IF;
            END");

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_line_no_update_after_post BEFORE UPDATE ON titan_ledger_journal_lines FOR EACH ROW
            BEGIN
                IF EXISTS (
                    SELECT 1 FROM titan_ledger_journals
                    WHERE company_id = OLD.company_id AND public_id = OLD.journal_public_id AND status = 'posted'
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posted journal lines are immutable';
                END IF;
            END");

        DB::unprepared("CREATE TRIGGER titan_ledger_journal_line_no_delete_after_post BEFORE DELETE ON titan_ledger_journal_lines FOR EACH ROW
            BEGIN
                IF EXISTS (
                    SELECT 1 FROM titan_ledger_journals
                    WHERE company_id = OLD.company_id AND public_id = OLD.journal_public_id AND status = 'posted'
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posted journal lines are immutable';
                END IF;
            END");
    }

    private function dropImmutabilityTriggers(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') return;
        foreach ([
            'titan_ledger_journal_no_direct_post_insert',
            'titan_ledger_journal_posted_no_update',
            'titan_ledger_journal_posted_no_delete',
            'titan_ledger_journal_line_no_insert_after_post',
            'titan_ledger_journal_line_no_update_after_post',
            'titan_ledger_journal_line_no_delete_after_post',
        ] as $trigger) {
            DB::unprepared('DROP TRIGGER IF EXISTS `' . $trigger . '`');
        }
    }

    private function assertJournalShape(): void
    {
        foreach (['public_id','company_id','journal_number','journal_type','status','entry_date','currency','debit_total_minor','credit_total_minor','source_extension','source_event_id','trace_id','correlation_id','causation_id','reversal_of_public_id','correction_of_public_id','posting_operation_id','payload_hash','lock_version','posted_at'] as $column) {
            if (! Schema::hasColumn(self::JOURNALS, $column)) {
                throw new \RuntimeException('Titan Ledger refused to adopt incompatible journal headers: missing ' . $column . '.');
            }
        }
    }

    private function assertLineShape(): void
    {
        foreach (['public_id','company_id','journal_public_id','line_no','account_public_id','debit_minor','credit_minor','tax_code','tax_amount_minor'] as $column) {
            if (! Schema::hasColumn(self::LINES, $column)) {
                throw new \RuntimeException('Titan Ledger refused to adopt incompatible journal lines: missing ' . $column . '.');
            }
        }
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function (Blueprint $t): void {
            $t->id();
            $t->string('table_name', 190)->unique();
            $t->string('owner_extension', 100)->index();
            $t->string('ownership_mode', 30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }

    private function recordOwnership(string $table, string $mode): void
    {
        DB::table('titan_ledger_schema_ownership')->updateOrInsert(
            ['table_name' => $table],
            [
                'owner_extension' => self::OWNER,
                'ownership_mode' => $mode,
                'first_seen_at' => now(),
                'metadata' => json_encode(['migration' => '2026_08_20_000003_create_titan_ledger_journals', 'uninstall_policy' => 'retain']),
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
};
