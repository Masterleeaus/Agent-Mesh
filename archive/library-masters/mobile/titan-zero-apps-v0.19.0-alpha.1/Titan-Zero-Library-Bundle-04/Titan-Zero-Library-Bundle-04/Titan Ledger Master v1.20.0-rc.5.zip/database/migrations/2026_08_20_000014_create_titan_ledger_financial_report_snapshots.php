<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    private const TABLE='titan_ledger_financial_report_snapshots';

    public function up(): void
    {
        $this->ensureRegistry();$existed=Schema::hasTable(self::TABLE);
        if(!$existed){Schema::create(self::TABLE,function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();
            $t->string('snapshot_key',80);$t->unsignedInteger('version');$t->string('report_type',30)->index();
            $t->date('period_start')->index();$t->date('period_end')->index();$t->string('currency',3)->default('AUD');$t->string('status',20)->default('prepared')->index();
            $t->boolean('balanced')->default(false);$t->boolean('complete')->default(false);$t->char('source_fingerprint',64);$t->longText('report_payload');$t->char('report_hash',64)->index();
            $t->char('supersedes_public_id',26)->nullable()->index();$t->string('supersession_reason_code',80)->nullable();
            $t->string('operation_id',191);$t->string('finalize_operation_id',191)->nullable();
            $t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();
            $t->unsignedBigInteger('prepared_by_user_id')->nullable();$t->unsignedBigInteger('finalized_by_user_id')->nullable();$t->timestamp('prepared_at');$t->timestamp('finalized_at')->nullable();$t->timestamps();
            $t->unique(['company_id','snapshot_key','version'],'tl_report_snapshot_version_uq');$t->unique(['company_id','operation_id'],'tl_report_snapshot_operation_uq');$t->unique(['company_id','finalize_operation_id'],'tl_report_snapshot_finalize_uq');$t->index(['company_id','period_end','report_type','status'],'tl_report_snapshot_lookup');
        });}else{$this->assertShape();}
        $this->own($existed);$this->installTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;$this->dropTriggers();
        DB::unprepared("CREATE TRIGGER tl_report_snapshot_no_final_insert BEFORE INSERT ON titan_ledger_financial_report_snapshots FOR EACH ROW BEGIN IF NEW.status <> 'prepared' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial report snapshots must be prepared before finalization'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_report_snapshot_guard_update BEFORE UPDATE ON titan_ledger_financial_report_snapshots FOR EACH ROW BEGIN IF OLD.status='finalized' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger finalized financial report snapshots are immutable'; END IF; IF NOT (OLD.status='prepared' AND NEW.status='finalized') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial report snapshot allows only prepared to finalized transition'; END IF; IF NOT (OLD.snapshot_key <=> NEW.snapshot_key) OR NOT (OLD.version <=> NEW.version) OR NOT (OLD.report_type <=> NEW.report_type) OR NOT (OLD.period_start <=> NEW.period_start) OR NOT (OLD.period_end <=> NEW.period_end) OR NOT (OLD.currency <=> NEW.currency) OR NOT (OLD.balanced <=> NEW.balanced) OR NOT (OLD.complete <=> NEW.complete) OR NOT (OLD.source_fingerprint <=> NEW.source_fingerprint) OR NOT (OLD.report_payload <=> NEW.report_payload) OR NOT (OLD.report_hash <=> NEW.report_hash) OR NOT (OLD.supersedes_public_id <=> NEW.supersedes_public_id) OR NOT (OLD.supersession_reason_code <=> NEW.supersession_reason_code) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial report snapshot evidence fields are immutable'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_report_snapshot_no_delete BEFORE DELETE ON titan_ledger_financial_report_snapshots FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial report snapshot evidence cannot be deleted'; END");
    }

    private function dropTriggers(): void{if(DB::connection()->getDriverName()!=='mysql')return;foreach(['tl_report_snapshot_no_final_insert','tl_report_snapshot_guard_update','tl_report_snapshot_no_delete'] as $tr)DB::unprepared('DROP TRIGGER IF EXISTS `'.$tr.'`');}
    private function assertShape(): void{foreach(['public_id','company_id','snapshot_key','version','report_type','period_start','period_end','currency','status','balanced','complete','source_fingerprint','report_payload','report_hash','supersedes_public_id','supersession_reason_code','operation_id'] as $c)if(!Schema::hasColumn(self::TABLE,$c))throw new RuntimeException('Titan Ledger refused to adopt incompatible financial report snapshot table: missing '.$c.'.');}
    private function ensureRegistry(): void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $b):void{$b->id();$b->string('table_name',190)->unique();$b->string('owner_extension',100)->index();$b->string('ownership_mode',30)->index();$b->timestamp('first_seen_at')->nullable();$b->json('metadata')->nullable();$b->timestamps();});}
    private function own(bool $existed): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>self::TABLE],['owner_extension'=>self::OWNER,'ownership_mode'=>$existed?'adopted':'created','first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000014_create_titan_ledger_financial_report_snapshots','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
};
