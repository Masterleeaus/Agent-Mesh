<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER = 'titan-ledger';
    private const TABLE = 'titan_ledger_accounts';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();
        $existed = Schema::hasTable(self::TABLE);

        if (! $existed) {
            Schema::create(self::TABLE, function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->string('code', 20);
                $t->string('name', 191);
                $t->string('type', 30)->index();
                $t->string('subtype', 60)->nullable()->index();
                $t->string('normal_balance', 10)->index();
                $t->string('tax_code', 40)->nullable()->index();
                $t->string('system_key', 80)->nullable();
                $t->char('parent_public_id', 26)->nullable()->index();
                $t->boolean('is_system_account')->default(false)->index();
                $t->boolean('is_protected')->default(false)->index();
                $t->boolean('is_active')->default(true)->index();
                $t->unsignedInteger('sort_order')->default(0);
                $t->json('metadata')->nullable();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->timestamps();
                $t->unique(['company_id','code'], 'titan_ledger_account_company_code_unique');
                $t->unique(['company_id','system_key'], 'titan_ledger_account_company_system_unique');
                $t->index(['company_id','type','is_active'], 'titan_ledger_account_company_type_list');
                $t->index(['company_id','parent_public_id'], 'titan_ledger_account_parent_list');
            });
        } else {
            $this->assertCanonicalShape();
        }

        $this->recordOwnership($existed ? 'adopted' : 'created');
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function assertCanonicalShape(): void
    {
        foreach (['public_id','company_id','code','name','type','subtype','normal_balance','tax_code','system_key','parent_public_id','is_system_account','is_protected','is_active'] as $column) {
            if (! Schema::hasColumn(self::TABLE, $column)) {
                throw new \RuntimeException('Titan Ledger refused to adopt an incompatible titan_ledger_accounts table: missing ' . $column . '.');
            }
        }
    }

    private function ensureOwnershipRegistry(): void
    {
        if (Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership', function (Blueprint $t): void {
            $t->id();
            $t->string('table_name', 190)->unique();
            $t->string('owner_extension', 100)->index();
            $t->string('ownership_mode', 30)->index();
            $t->timestamp('first_seen_at')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
        });
    }

    private function recordOwnership(string $mode): void
    {
        DB::table('titan_ledger_schema_ownership')->updateOrInsert(
            ['table_name' => self::TABLE],
            [
                'owner_extension' => self::OWNER,
                'ownership_mode' => $mode,
                'first_seen_at' => now(),
                'metadata' => json_encode(['migration' => '2026_08_19_000002_create_titan_ledger_chart_of_accounts', 'uninstall_policy' => 'retain']),
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
};
