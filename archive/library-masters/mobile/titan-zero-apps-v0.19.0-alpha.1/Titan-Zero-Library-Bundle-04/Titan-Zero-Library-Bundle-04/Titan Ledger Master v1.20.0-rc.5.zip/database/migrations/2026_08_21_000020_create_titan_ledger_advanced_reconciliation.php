<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';

    public function up(): void
    {
        $this->ensureRegistry();
        if(!Schema::hasTable('titan_ledger_bank_statements')||!Schema::hasTable('titan_ledger_bank_transactions')) throw new RuntimeException('Titan Ledger bank reconciliation tables must exist before advanced reconciliation migration.');
        if(!Schema::hasColumn('titan_ledger_bank_statements','statement_fingerprint')) Schema::table('titan_ledger_bank_statements',function(Blueprint $b): void{$b->char('statement_fingerprint',64)->nullable()->after('fact_hash')->index();});
        if(!Schema::hasColumn('titan_ledger_bank_transactions','classification_hint')) Schema::table('titan_ledger_bank_transactions',function(Blueprint $b): void{$b->string('classification_hint',30)->default('unknown')->after('reference_hash')->index();});
        $this->backfillStatementFingerprints();
        if(!$this->indexExists('titan_ledger_bank_statements','tl_bank_statement_fingerprint_uq')) Schema::table('titan_ledger_bank_statements',function(Blueprint $b): void{$b->unique(['company_id','account_public_id','statement_fingerprint'],'tl_bank_statement_fingerprint_uq');});
        $this->groups();$this->groupEvents();$this->bankMembers();$this->ledgerMembers();$this->activeMembers();$this->installTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function groups(): void
    {
        $t='titan_ledger_reconciliation_groups';$ex=Schema::hasTable($t);
        if(!$ex)Schema::create($t,function(Blueprint $b): void{$b->id();$b->char('public_id',26)->unique();$b->unsignedBigInteger('company_id')->index();$b->char('session_public_id',26)->index();$b->string('group_type',30)->index();$b->bigInteger('bank_total_minor');$b->bigInteger('ledger_total_minor');$b->unsignedSmallInteger('score')->default(0);$b->string('reason_code',80)->nullable();$b->string('operation_id',191);$b->unsignedBigInteger('actor_user_id')->nullable()->index();$b->string('trace_id',120)->nullable()->index();$b->string('correlation_id',120)->nullable()->index();$b->string('causation_id',120)->nullable()->index();$b->timestamp('created_at');$b->unique(['company_id','operation_id'],'tl_recon_group_company_op_uq');$b->index(['company_id','session_public_id','id'],'tl_recon_group_session_idx');});
        else $this->assertShape($t,['public_id','company_id','session_public_id','group_type','bank_total_minor','ledger_total_minor','score','operation_id']);$this->own($t,$ex);
    }
    private function groupEvents(): void
    {
        $t='titan_ledger_reconciliation_group_events';$ex=Schema::hasTable($t);
        if(!$ex)Schema::create($t,function(Blueprint $b): void{$b->id();$b->char('public_id',26)->unique();$b->unsignedBigInteger('company_id')->index();$b->char('group_public_id',26)->index();$b->string('event_type',20)->index();$b->string('reason_code',80)->nullable();$b->string('operation_id',191);$b->unsignedBigInteger('actor_user_id')->nullable()->index();$b->string('trace_id',120)->nullable()->index();$b->string('correlation_id',120)->nullable()->index();$b->string('causation_id',120)->nullable()->index();$b->timestamp('created_at');$b->unique(['company_id','operation_id'],'tl_recon_group_evt_company_op_uq');$b->index(['company_id','group_public_id','id'],'tl_recon_group_evt_group_idx');});
        else $this->assertShape($t,['public_id','company_id','group_public_id','event_type','operation_id']);$this->own($t,$ex);
    }
    private function bankMembers(): void
    {
        $t='titan_ledger_reconciliation_group_bank_members';$ex=Schema::hasTable($t);
        if(!$ex)Schema::create($t,function(Blueprint $b): void{$b->id();$b->unsignedBigInteger('company_id')->index();$b->char('group_public_id',26)->index();$b->char('bank_transaction_record_public_id',26)->index();$b->string('transaction_public_id',100)->index();$b->bigInteger('amount_minor');$b->timestamp('created_at');$b->unique(['company_id','group_public_id','bank_transaction_record_public_id'],'tl_recon_group_bank_member_uq');});
        else $this->assertShape($t,['company_id','group_public_id','bank_transaction_record_public_id','transaction_public_id','amount_minor']);$this->own($t,$ex);
    }
    private function ledgerMembers(): void
    {
        $t='titan_ledger_reconciliation_group_ledger_members';$ex=Schema::hasTable($t);
        if(!$ex)Schema::create($t,function(Blueprint $b): void{$b->id();$b->unsignedBigInteger('company_id')->index();$b->char('group_public_id',26)->index();$b->char('candidate_line_public_id',26)->index();$b->char('journal_public_id',26)->index();$b->bigInteger('amount_minor');$b->timestamp('created_at');$b->unique(['company_id','group_public_id','candidate_line_public_id'],'tl_recon_group_ledger_member_uq');});
        else $this->assertShape($t,['company_id','group_public_id','candidate_line_public_id','journal_public_id','amount_minor']);$this->own($t,$ex);
    }
    private function activeMembers(): void
    {
        $t='titan_ledger_reconciliation_active_members';$ex=Schema::hasTable($t);
        if(!$ex)Schema::create($t,function(Blueprint $b): void{$b->id();$b->unsignedBigInteger('company_id')->index();$b->char('group_public_id',26)->index();$b->string('member_type',30)->index();$b->string('member_public_id',100);$b->timestamp('created_at');$b->unique(['company_id','member_type','member_public_id'],'tl_recon_active_member_uq');$b->index(['company_id','group_public_id'],'tl_recon_active_group_idx');});
        else $this->assertShape($t,['company_id','group_public_id','member_type','member_public_id']);$this->own($t,$ex);
    }

    private function backfillStatementFingerprints(): void
    {
        $rows=DB::table('titan_ledger_bank_statements')->whereNull('statement_fingerprint')->orderBy('id')->get();
        $seen=[];
        foreach($rows as $row){$txs=DB::table('titan_ledger_bank_transactions')->where('company_id',$row->company_id)->where('statement_record_public_id',$row->public_id)->orderBy('posted_on')->orderBy('id')->get();$transactions=[];foreach($txs as $tx)$transactions[]=['posted_on'=>(string)$tx->posted_on,'amount_minor'=>(int)$tx->amount_minor,'reference_hash'=>$tx->reference_hash===null?null:(string)$tx->reference_hash];usort($transactions,static fn(array $a,array $b): int=>[$a['posted_on'],$a['amount_minor'],(string)$a['reference_hash']]<=>[$b['posted_on'],$b['amount_minor'],(string)$b['reference_hash']]);$payload=['account_public_id'=>(string)$row->account_public_id,'currency'=>(string)$row->currency,'period_start'=>(string)$row->period_start,'period_end'=>(string)$row->period_end,'opening_balance_minor'=>(int)$row->opening_balance_minor,'closing_balance_minor'=>(int)$row->closing_balance_minor,'movement_minor'=>(int)$row->movement_minor,'transactions'=>$transactions];$fingerprint=hash('sha256',(string)json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));$key=$row->company_id.'|'.$row->account_public_id.'|'.$fingerprint;if(isset($seen[$key]))throw new RuntimeException('Titan Ledger detected duplicate historical bank statement evidence during advanced reconciliation upgrade.');$seen[$key]=true;DB::table('titan_ledger_bank_statements')->where('id',$row->id)->update(['statement_fingerprint'=>$fingerprint]);}
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;
        $names=['tl_recon_group_no_update','tl_recon_group_no_delete','tl_recon_group_event_no_update','tl_recon_group_event_no_delete','tl_recon_group_bank_no_update','tl_recon_group_bank_no_delete','tl_recon_group_ledger_no_update','tl_recon_group_ledger_no_delete'];foreach($names as $n)DB::unprepared('DROP TRIGGER IF EXISTS `'.$n.'`');
        DB::unprepared("CREATE TRIGGER tl_recon_group_no_update BEFORE UPDATE ON titan_ledger_reconciliation_groups FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation group evidence is immutable'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_no_delete BEFORE DELETE ON titan_ledger_reconciliation_groups FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation group evidence cannot be deleted'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_event_no_update BEFORE UPDATE ON titan_ledger_reconciliation_group_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation group event is immutable'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_event_no_delete BEFORE DELETE ON titan_ledger_reconciliation_group_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation group event cannot be deleted'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_bank_no_update BEFORE UPDATE ON titan_ledger_reconciliation_group_bank_members FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation bank group member is immutable'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_bank_no_delete BEFORE DELETE ON titan_ledger_reconciliation_group_bank_members FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation bank group member cannot be deleted'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_ledger_no_update BEFORE UPDATE ON titan_ledger_reconciliation_group_ledger_members FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation ledger group member is immutable'; END");
        DB::unprepared("CREATE TRIGGER tl_recon_group_ledger_no_delete BEFORE DELETE ON titan_ledger_reconciliation_group_ledger_members FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger reconciliation ledger group member cannot be deleted'; END");
    }

    private function indexExists(string $table,string $index): bool{if(DB::connection()->getDriverName()!=='mysql')return false;$rows=DB::select('SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1',[$table,$index]);return $rows!==[];}
    private function assertShape(string $t,array $cols): void{foreach($cols as $c)if(!Schema::hasColumn($t,$c))throw new RuntimeException('Titan Ledger refused to adopt incompatible '.$t.': missing '.$c.'.');}
    private function ensureRegistry(): void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $b): void{$b->id();$b->string('table_name',190)->unique();$b->string('owner_extension',100)->index();$b->string('ownership_mode',30)->index();$b->timestamp('first_seen_at')->nullable();$b->json('metadata')->nullable();$b->timestamps();});}
    private function own(string $table,bool $existed): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>$table],['owner_extension'=>self::OWNER,'ownership_mode'=>$existed?'adopted':'created','first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_21_000020_create_titan_ledger_advanced_reconciliation','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
};
