<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    private const CLOSES='titan_ledger_financial_year_closes';
    private const EVENTS='titan_ledger_financial_year_close_events';

    public function up(): void
    {
        if(!Schema::hasTable('titan_ledger_schema_ownership')) throw new RuntimeException('Titan Ledger schema ownership registry is required.');
        $closesExisted=Schema::hasTable(self::CLOSES);
        if(!$closesExisted){Schema::create(self::CLOSES,function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->char('financial_year_public_id',26)->index();$t->unsignedInteger('version');
            $t->string('status',20)->default('prepared')->index();$t->char('currency',3)->default('AUD');$t->bigInteger('net_profit_minor')->default(0);$t->char('close_journal_public_id',26)->nullable()->index();
            $t->char('source_fingerprint',64);$t->json('checklist_json');$t->json('close_payload_json');$t->char('close_hash',64);$t->char('supersedes_public_id',26)->nullable()->index();
            $t->string('prepare_operation_id',191)->unique();$t->string('close_operation_id',191)->nullable()->unique();$t->string('reopen_operation_id',191)->nullable();
            $t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();
            $t->unsignedBigInteger('prepared_by_user_id')->nullable()->index();$t->unsignedBigInteger('closed_by_user_id')->nullable()->index();$t->timestamp('prepared_at')->nullable();$t->timestamp('closed_at')->nullable();$t->timestamps();
            $t->unique(['company_id','financial_year_public_id','version'],'tl_fy_close_company_year_version');
        });}else{$this->assertShape(self::CLOSES,['public_id','company_id','financial_year_public_id','version','status','source_fingerprint','checklist_json','close_payload_json','close_hash','supersedes_public_id']);}
        $this->recordOwnership(self::CLOSES,$closesExisted?'adopted':'created');

        $eventsExisted=Schema::hasTable(self::EVENTS);
        if(!$eventsExisted){Schema::create(self::EVENTS,function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->char('financial_year_public_id',26)->index();$t->char('close_public_id',26)->index();
            $t->string('event_type',30)->index();$t->string('reason',500);$t->char('reopen_journal_public_id',26)->nullable()->index();$t->string('operation_id',191)->unique();$t->unsignedBigInteger('actor_user_id')->nullable()->index();
            $t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();$t->timestamp('created_at')->useCurrent();
        });}else{$this->assertShape(self::EVENTS,['public_id','company_id','financial_year_public_id','close_public_id','event_type','reason','operation_id','created_at']);}
        $this->recordOwnership(self::EVENTS,$eventsExisted?'adopted':'created');
        $this->installTriggers();
        $this->installYearEndPostingGuard();
    }

    public function down(): void
    {
        // Deliberately non-destructive: financial-year close and reopen evidence is retained.
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;
        foreach(['tl_fy_close_guard_update','tl_fy_close_no_delete','tl_fy_close_event_no_update','tl_fy_close_event_no_delete'] as $trigger)DB::unprepared('DROP TRIGGER IF EXISTS `'.$trigger.'`');
        DB::unprepared("CREATE TRIGGER tl_fy_close_guard_update BEFORE UPDATE ON titan_ledger_financial_year_closes FOR EACH ROW BEGIN
            IF OLD.status = 'closed' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger closed financial-year evidence is immutable'; END IF;
            IF NOT (OLD.status = 'prepared' AND NEW.status = 'closed') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial-year close permits only prepared to closed transition'; END IF;
            IF OLD.company_id <> NEW.company_id OR OLD.financial_year_public_id <> NEW.financial_year_public_id OR OLD.version <> NEW.version OR OLD.source_fingerprint <> NEW.source_fingerprint OR OLD.close_hash <> NEW.close_hash OR OLD.prepare_operation_id <> NEW.prepare_operation_id THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial-year close identity/evidence is immutable'; END IF;
        END");
        DB::unprepared("CREATE TRIGGER tl_fy_close_no_delete BEFORE DELETE ON titan_ledger_financial_year_closes FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial-year close evidence cannot be deleted'; END");
        DB::unprepared("CREATE TRIGGER tl_fy_close_event_no_update BEFORE UPDATE ON titan_ledger_financial_year_close_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial-year close events are immutable'; END");
        DB::unprepared("CREATE TRIGGER tl_fy_close_event_no_delete BEFORE DELETE ON titan_ledger_financial_year_close_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger financial-year close events cannot be deleted'; END");
    }


    private function installYearEndPostingGuard(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;
        DB::unprepared('DROP TRIGGER IF EXISTS `titan_ledger_journal_period_guard_before_post`');
        DB::unprepared("CREATE TRIGGER titan_ledger_journal_period_guard_before_post BEFORE UPDATE ON titan_ledger_journals FOR EACH ROW
            BEGIN
                DECLARE period_state VARCHAR(20);
                DECLARE period_start DATE;
                DECLARE period_end DATE;
                IF OLD.status <> 'posted' AND NEW.status = 'posted' THEN
                    IF NEW.accounting_period_public_id IS NULL OR NEW.financial_year_public_id IS NULL THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger posting requires accounting period attribution';
                    END IF;
                    SELECT lock_state, starts_on, ends_on INTO period_state, period_start, period_end
                    FROM titan_ledger_accounting_periods WHERE company_id = NEW.company_id AND public_id = NEW.accounting_period_public_id LIMIT 1;
                    IF period_state IS NULL OR NEW.entry_date < period_start OR NEW.entry_date > period_end THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger accounting period does not cover journal entry date';
                    END IF;
                    IF period_state = 'hard_locked' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger accounting period is hard-locked'; END IF;
                    IF period_state = 'soft_locked' AND (
                        NEW.prior_period_adjustment = 0 OR NEW.period_override_reason IS NULL OR TRIM(NEW.period_override_reason) = '' OR
                        NEW.journal_type NOT IN ('adjustment','correction','reversal','year_end_close','year_end_reopen')
                    ) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger soft-locked period requires governed prior-period adjustment'; END IF;
                END IF;
            END");
    }

    private function assertShape(string $table,array $columns): void{foreach($columns as $column)if(!Schema::hasColumn($table,$column))throw new RuntimeException('Titan Ledger refused incompatible adopted '.$table.': missing '.$column);}
    private function recordOwnership(string $table,string $mode): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>$table],['owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_21_000017_create_titan_ledger_financial_year_closes','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
};
