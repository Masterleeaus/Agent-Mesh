<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    public function up(): void
    {
        $this->ensureRegistry();
        if(Schema::hasTable('titan_ledger_crm_invoice_postings')){
            $addInvoiceNumber=!Schema::hasColumn('titan_ledger_crm_invoice_postings','invoice_number');
            $addDueAt=!Schema::hasColumn('titan_ledger_crm_invoice_postings','due_at');
            if($addInvoiceNumber||$addDueAt)Schema::table('titan_ledger_crm_invoice_postings',function(Blueprint $t) use($addInvoiceNumber,$addDueAt): void {
                if($addInvoiceNumber)$t->string('invoice_number',100)->nullable()->after('invoice_public_id');
                if($addDueAt)$t->date('due_at')->nullable()->after('issued_at');
            });
        }
        $this->createReceivables();$this->createEvents();$this->installTriggers();
    }
    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
    private function createReceivables(): void
    {
        $table='titan_ledger_receivables';$existed=Schema::hasTable($table);
        if(!$existed)Schema::create($table,function(Blueprint $t): void {$t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('invoice_public_id',100);$t->string('invoice_number',100)->nullable();$t->string('currency',3);$t->timestamp('issued_at');$t->date('due_at')->nullable()->index();$t->unsignedBigInteger('invoice_total_minor');$t->unsignedBigInteger('credits_minor')->default(0);$t->unsignedBigInteger('payments_minor')->default(0);$t->unsignedBigInteger('refunds_minor')->default(0);$t->unsignedBigInteger('outstanding_minor')->default(0)->index();$t->unsignedBigInteger('receivable_credit_minor')->default(0);$t->unsignedBigInteger('customer_credit_minor')->default(0);$t->string('financial_state',20)->default('open')->index();$t->string('aging_bucket',30)->default('unknown_due_date')->index();$t->unsignedInteger('days_past_due')->nullable();$t->boolean('is_overdue')->default(false)->index();$t->string('collection_state',30)->default('normal')->index();$t->timestamp('next_action_at')->nullable()->index();$t->timestamp('last_action_at')->nullable();$t->string('last_action_type',30)->nullable();$t->char('projection_hash',64);$t->timestamps();$t->unique(['company_id','invoice_public_id'],'titan_ledger_receivable_invoice_unique');});
        else $this->assertShape($table,['public_id','company_id','invoice_public_id','currency','invoice_total_minor','outstanding_minor','receivable_credit_minor','collection_state','projection_hash']);$this->record($table,$existed?'adopted':'created');
    }
    private function createEvents(): void
    {
        $table='titan_ledger_collection_events';$existed=Schema::hasTable($table);
        if(!$existed)Schema::create($table,function(Blueprint $t): void {$t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->char('receivable_public_id',26)->index();$t->string('invoice_public_id',100)->index();$t->string('event_type',30)->index();$t->string('from_state',30);$t->string('to_state',30);$t->string('channel',20)->nullable();$t->string('outcome',30)->nullable();$t->string('reason_code',80);$t->timestamp('next_action_at')->nullable();$t->unsignedBigInteger('promised_amount_minor')->nullable();$t->string('command_id',191);$t->string('operation_id',191);$t->unsignedBigInteger('actor_user_id')->nullable()->index();$t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();$t->timestamp('created_at')->useCurrent();$t->unique(['company_id','operation_id'],'titan_ledger_collection_operation_unique');});
        else $this->assertShape($table,['public_id','company_id','receivable_public_id','invoice_public_id','event_type','operation_id','reason_code']);$this->record($table,$existed?'adopted':'created');
    }
    private function assertShape(string $table,array $columns): void{foreach($columns as $c)if(!Schema::hasColumn($table,$c))throw new RuntimeException('Titan Ledger refused incompatible receivables table '.$table.': missing '.$c.'.');}
    private function ensureRegistry(): void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $t): void{$t->id();$t->string('table_name',190)->unique();$t->string('owner_extension',100)->index();$t->string('ownership_mode',30)->index();$t->timestamp('first_seen_at')->nullable();$t->json('metadata')->nullable();$t->timestamps();});}
    private function record(string $table,string $mode): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>$table],['owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000010_create_titan_ledger_receivables','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
    private function installTriggers(): void{if(DB::connection()->getDriverName()!=='mysql'||!Schema::hasTable('titan_ledger_collection_events'))return;$this->dropTriggers();DB::unprepared("CREATE TRIGGER titan_ledger_collection_event_no_update BEFORE UPDATE ON titan_ledger_collection_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger collection events are immutable'; END");DB::unprepared("CREATE TRIGGER titan_ledger_collection_event_no_delete BEFORE DELETE ON titan_ledger_collection_events FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger collection events cannot be deleted'; END");}
    private function dropTriggers(): void{if(DB::connection()->getDriverName()!=='mysql')return;DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_collection_event_no_update');DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_collection_event_no_delete');}
};
