<?php

declare(strict_types=1);

use App\Extensions\TitanLedger\System\Certification\LedgerProductionDatabaseHardener;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (DB::connection()->getDriverName() !== 'mysql') throw new \RuntimeException('Titan Ledger production certification requires MySQL.');
        foreach (['titan_ledger_journals','titan_ledger_command_receipts','titan_ledger_signal_outbox','titan_ledger_schema_ownership'] as $table) {
            if (! Schema::hasTable($table)) throw new \RuntimeException('Titan Ledger production hardening requires prior migration table: '.$table);
        }
        foreach (['titan_ledger_journals','titan_ledger_command_receipts','titan_ledger_signal_outbox'] as $table) {
            if (! Schema::hasColumn($table,'company_id')) throw new \RuntimeException('Titan Ledger canonical company_id boundary missing on '.$table);
        }
        app(LedgerProductionDatabaseHardener::class)->repair(false);
        DB::table('titan_ledger_schema_ownership')->where('owner_extension','titan-ledger')->where('ownership_mode','not like','retain_%')->orderBy('id')->chunkById(100,function($rows): void {
            foreach ($rows as $row) DB::table('titan_ledger_schema_ownership')->where('id',$row->id)->update(['ownership_mode'=>substr('retain_'.($row->ownership_mode??'legacy_unknown'),0,30),'updated_at'=>now()]);
        });
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
};
