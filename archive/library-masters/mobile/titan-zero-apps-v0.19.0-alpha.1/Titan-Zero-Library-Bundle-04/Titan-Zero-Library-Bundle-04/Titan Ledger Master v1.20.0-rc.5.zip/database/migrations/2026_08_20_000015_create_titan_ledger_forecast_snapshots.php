<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    private const TABLE='titan_ledger_forecast_snapshots';

    public function up(): void
    {
        $this->ensureRegistry();$existed=Schema::hasTable(self::TABLE);
        if(!$existed){Schema::create(self::TABLE,function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();
            $t->string('snapshot_key',80);$t->unsignedInteger('version');$t->string('snapshot_type',40)->index();
            $t->date('as_of_date')->index();$t->unsignedInteger('horizon_days');$t->string('currency',3)->default('AUD');$t->string('status',20)->default('prepared')->index();
            $t->unsignedSmallInteger('evidence_coverage_bps')->default(0);$t->string('confidence_band',20)->default('LOW');$t->boolean('complete')->default(false);
            $t->char('source_fingerprint',64);$t->longText('forecast_payload');$t->char('forecast_hash',64)->index();
            $t->char('supersedes_public_id',26)->nullable()->index();$t->string('supersession_reason_code',80)->nullable();
            $t->string('operation_id',191);$t->string('finalize_operation_id',191)->nullable();
            $t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();
            $t->unsignedBigInteger('prepared_by_user_id')->nullable();$t->unsignedBigInteger('finalized_by_user_id')->nullable();$t->timestamp('prepared_at');$t->timestamp('finalized_at')->nullable();$t->timestamps();
            $t->unique(['company_id','snapshot_key','version'],'tl_forecast_snapshot_version_uq');$t->unique(['company_id','operation_id'],'tl_forecast_snapshot_operation_uq');$t->unique(['company_id','finalize_operation_id'],'tl_forecast_snapshot_finalize_uq');$t->index(['company_id','as_of_date','snapshot_type','status'],'tl_forecast_snapshot_lookup');
        });}else{$this->assertShape();}
        $this->own($existed);$this->installTriggers();
    }

    public function down(): void{
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;$this->dropTriggers();
        DB::unprepared("CREATE TRIGGER tl_forecast_snapshot_no_final_insert BEFORE INSERT ON titan_ledger_forecast_snapshots FOR EACH ROW BEGIN IF NEW.status <> 'prepared' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger forecast snapshots must be prepared before finalization'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_forecast_snapshot_guard_update BEFORE UPDATE ON titan_ledger_forecast_snapshots FOR EACH ROW BEGIN IF OLD.status='finalized' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger finalized forecast snapshots are immutable'; END IF; IF NOT (OLD.status='prepared' AND NEW.status='finalized') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger forecast snapshot allows only prepared to finalized transition'; END IF; IF NOT (OLD.snapshot_key <=> NEW.snapshot_key) OR NOT (OLD.version <=> NEW.version) OR NOT (OLD.snapshot_type <=> NEW.snapshot_type) OR NOT (OLD.as_of_date <=> NEW.as_of_date) OR NOT (OLD.horizon_days <=> NEW.horizon_days) OR NOT (OLD.currency <=> NEW.currency) OR NOT (OLD.evidence_coverage_bps <=> NEW.evidence_coverage_bps) OR NOT (OLD.confidence_band <=> NEW.confidence_band) OR NOT (OLD.complete <=> NEW.complete) OR NOT (OLD.source_fingerprint <=> NEW.source_fingerprint) OR NOT (OLD.forecast_payload <=> NEW.forecast_payload) OR NOT (OLD.forecast_hash <=> NEW.forecast_hash) OR NOT (OLD.supersedes_public_id <=> NEW.supersedes_public_id) OR NOT (OLD.supersession_reason_code <=> NEW.supersession_reason_code) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger forecast snapshot evidence fields are immutable'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_forecast_snapshot_no_delete BEFORE DELETE ON titan_ledger_forecast_snapshots FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger forecast snapshot evidence cannot be deleted'; END");
    }
    private function dropTriggers():void{if(DB::connection()->getDriverName()!=='mysql')return;foreach(['tl_forecast_snapshot_no_final_insert','tl_forecast_snapshot_guard_update','tl_forecast_snapshot_no_delete'] as $tr)DB::unprepared('DROP TRIGGER IF EXISTS `'.$tr.'`');}
    private function assertShape():void{foreach(['public_id','company_id','snapshot_key','version','snapshot_type','as_of_date','horizon_days','currency','status','evidence_coverage_bps','confidence_band','complete','source_fingerprint','forecast_payload','forecast_hash','supersedes_public_id','supersession_reason_code','operation_id'] as $c)if(!Schema::hasColumn(self::TABLE,$c))throw new RuntimeException('Titan Ledger refused to adopt incompatible forecast snapshot table: missing '.$c.'.');}
    private function ensureRegistry():void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $b):void{$b->id();$b->string('table_name',190)->unique();$b->string('owner_extension',100)->index();$b->string('ownership_mode',30)->index();$b->timestamp('first_seen_at')->nullable();$b->json('metadata')->nullable();$b->timestamps();});}
    private function own(bool $existed):void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>self::TABLE],['owner_extension'=>self::OWNER,'ownership_mode'=>$existed?'adopted':'created','first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000015_create_titan_ledger_forecast_snapshots','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
};
