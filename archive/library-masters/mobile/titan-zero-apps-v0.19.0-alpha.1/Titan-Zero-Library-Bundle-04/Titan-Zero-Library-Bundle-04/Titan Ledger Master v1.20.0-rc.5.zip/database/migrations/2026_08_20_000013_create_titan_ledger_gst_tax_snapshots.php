<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    private const TABLE='titan_ledger_gst_tax_snapshots';

    public function up(): void
    {
        $this->ensureRegistry();$existed=Schema::hasTable(self::TABLE);
        if(!$existed){Schema::create(self::TABLE,function(Blueprint $t):void{
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();
            $t->string('period_key',80);$t->unsignedInteger('version');$t->date('period_start')->index();$t->date('period_end')->index();
            $t->string('reporting_method',30)->default('simpler_bas');$t->string('accounting_basis',20)->default('accrual');$t->string('currency',3)->default('AUD');$t->string('status',20)->default('prepared')->index();
            $t->bigInteger('g1_total_sales_minor');$t->bigInteger('one_a_gst_on_sales_minor');$t->bigInteger('one_b_gst_on_purchases_minor');$t->bigInteger('total_purchases_minor');$t->bigInteger('net_gst_payable_minor');
            $t->unsignedInteger('invoice_source_count')->default(0);$t->unsignedInteger('spend_source_count')->default(0);$t->char('source_fingerprint',64);$t->char('snapshot_hash',64)->index();$t->boolean('lodgement_ready')->default(false);$t->json('review_reasons')->nullable();
            $t->char('supersedes_public_id',26)->nullable()->index();$t->string('supersession_reason_code',80)->nullable();$t->string('operation_id',191);$t->string('finalize_operation_id',191)->nullable();
            $t->string('trace_id',120)->nullable()->index();$t->string('correlation_id',120)->nullable()->index();$t->string('causation_id',120)->nullable()->index();
            $t->unsignedBigInteger('prepared_by_user_id')->nullable();$t->unsignedBigInteger('finalized_by_user_id')->nullable();$t->timestamp('prepared_at');$t->timestamp('finalized_at')->nullable();$t->timestamps();
            $t->unique(['company_id','period_key','version'],'tl_gst_period_version_uq');$t->unique(['company_id','operation_id'],'tl_gst_operation_uq');$t->unique(['company_id','finalize_operation_id'],'tl_gst_finalize_operation_uq');$t->index(['company_id','period_end','status'],'tl_gst_period_status_lookup');
        });}else{$this->assertShape();}
        $this->own($existed);$this->installTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql')return;$this->dropTriggers();
        DB::unprepared("CREATE TRIGGER tl_gst_snapshot_no_final_insert BEFORE INSERT ON titan_ledger_gst_tax_snapshots FOR EACH ROW BEGIN IF NEW.status <> 'prepared' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger GST snapshots must be prepared before finalization'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_gst_snapshot_guard_update BEFORE UPDATE ON titan_ledger_gst_tax_snapshots FOR EACH ROW BEGIN IF OLD.status='finalized' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger finalized GST snapshots are immutable'; END IF; IF NOT (OLD.status='prepared' AND NEW.status='finalized') THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger GST snapshot allows only prepared to finalized transition'; END IF; IF NOT (OLD.period_key <=> NEW.period_key) OR NOT (OLD.version <=> NEW.version) OR NOT (OLD.period_start <=> NEW.period_start) OR NOT (OLD.period_end <=> NEW.period_end) OR NOT (OLD.g1_total_sales_minor <=> NEW.g1_total_sales_minor) OR NOT (OLD.one_a_gst_on_sales_minor <=> NEW.one_a_gst_on_sales_minor) OR NOT (OLD.one_b_gst_on_purchases_minor <=> NEW.one_b_gst_on_purchases_minor) OR NOT (OLD.total_purchases_minor <=> NEW.total_purchases_minor) OR NOT (OLD.net_gst_payable_minor <=> NEW.net_gst_payable_minor) OR NOT (OLD.source_fingerprint <=> NEW.source_fingerprint) OR NOT (OLD.snapshot_hash <=> NEW.snapshot_hash) OR NOT (OLD.supersedes_public_id <=> NEW.supersedes_public_id) OR NOT (OLD.supersession_reason_code <=> NEW.supersession_reason_code) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger GST snapshot evidence fields are immutable'; END IF; END");
        DB::unprepared("CREATE TRIGGER tl_gst_snapshot_no_delete BEFORE DELETE ON titan_ledger_gst_tax_snapshots FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger GST snapshot evidence cannot be deleted'; END");
    }
    private function dropTriggers(): void{if(DB::connection()->getDriverName()!=='mysql')return;foreach(['tl_gst_snapshot_no_final_insert','tl_gst_snapshot_guard_update','tl_gst_snapshot_no_delete'] as $tr)DB::unprepared('DROP TRIGGER IF EXISTS `'.$tr.'`');}
    private function assertShape(): void{foreach(['public_id','company_id','period_key','version','period_start','period_end','reporting_method','accounting_basis','currency','status','g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','total_purchases_minor','net_gst_payable_minor','source_fingerprint','snapshot_hash','lodgement_ready','supersedes_public_id','supersession_reason_code','operation_id'] as $c)if(!Schema::hasColumn(self::TABLE,$c))throw new RuntimeException('Titan Ledger refused to adopt incompatible GST tax snapshot table: missing '.$c.'.');}
    private function ensureRegistry(): void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $b):void{$b->id();$b->string('table_name',190)->unique();$b->string('owner_extension',100)->index();$b->string('ownership_mode',30)->index();$b->timestamp('first_seen_at')->nullable();$b->json('metadata')->nullable();$b->timestamps();});}
    private function own(bool $existed): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>self::TABLE],['owner_extension'=>self::OWNER,'ownership_mode'=>$existed?'adopted':'created','first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000013_create_titan_ledger_gst_tax_snapshots','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
};
