<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    public function up(): void
    {
        $this->ensureRegistry();$this->createSpendPostings();$this->createPayables();$this->installTriggers();
    }
    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
    private function createSpendPostings(): void
    {
        $table='titan_ledger_spend_postings';$existed=Schema::hasTable($table);
        if(!$existed)Schema::create($table,function(Blueprint $t): void{$t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('posting_type',30)->index();$t->string('document_public_id',100);$t->string('bill_public_id',100)->nullable()->index();$t->string('supplier_public_id',100)->nullable()->index();$t->string('source_event_id',120);$t->unsignedInteger('source_version')->default(1);$t->char('fact_hash',64);$t->string('currency',3);$t->unsignedBigInteger('subtotal_minor')->default(0);$t->unsignedBigInteger('gst_minor')->default(0);$t->unsignedBigInteger('total_minor')->default(0);$t->unsignedBigInteger('amount_minor')->default(0);$t->unsignedBigInteger('fee_minor')->default(0);$t->unsignedBigInteger('ap_allocation_minor')->default(0);$t->unsignedBigInteger('prepayment_minor')->default(0);$t->string('rail',30)->nullable()->index();$t->date('due_at')->nullable()->index();$t->timestamp('occurred_at')->index();$t->char('journal_public_id',26)->index();$t->string('posting_operation_id',191);$t->unsignedBigInteger('created_by_user_id')->nullable()->index();$t->timestamps();$t->unique(['company_id','posting_type','document_public_id'],'titan_ledger_spend_document_unique');$t->unique(['company_id','source_event_id'],'titan_ledger_spend_event_unique');$t->unique(['company_id','posting_operation_id'],'titan_ledger_spend_operation_unique');});
        else $this->assertShape($table,['public_id','company_id','posting_type','document_public_id','bill_public_id','supplier_public_id','source_event_id','fact_hash','currency','journal_public_id','posting_operation_id']);$this->record($table,$existed?'adopted':'created');
    }
    private function createPayables(): void
    {
        $table='titan_ledger_payables';$existed=Schema::hasTable($table);
        if(!$existed)Schema::create($table,function(Blueprint $t): void{$t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('bill_public_id',100);$t->string('supplier_public_id',100)->index();$t->string('currency',3);$t->timestamp('issued_at');$t->date('due_at')->nullable()->index();$t->unsignedBigInteger('bill_total_minor');$t->unsignedBigInteger('credits_minor')->default(0);$t->unsignedBigInteger('payments_minor')->default(0);$t->unsignedBigInteger('outstanding_minor')->default(0)->index();$t->unsignedBigInteger('payable_credit_minor')->default(0);$t->unsignedBigInteger('supplier_prepayment_minor')->default(0);$t->string('financial_state',20)->default('open')->index();$t->string('aging_bucket',30)->default('unknown_due_date')->index();$t->unsignedInteger('days_past_due')->nullable();$t->boolean('is_overdue')->default(false)->index();$t->char('projection_hash',64);$t->timestamps();$t->unique(['company_id','bill_public_id'],'titan_ledger_payable_bill_unique');});
        else $this->assertShape($table,['public_id','company_id','bill_public_id','supplier_public_id','currency','bill_total_minor','outstanding_minor','payable_credit_minor','supplier_prepayment_minor','projection_hash']);$this->record($table,$existed?'adopted':'created');
    }
    private function assertShape(string $table,array $columns): void{foreach($columns as $c)if(!Schema::hasColumn($table,$c))throw new RuntimeException('Titan Ledger refused incompatible payables/spend table '.$table.': missing '.$c.'.');}
    private function ensureRegistry(): void{if(Schema::hasTable('titan_ledger_schema_ownership'))return;Schema::create('titan_ledger_schema_ownership',function(Blueprint $t): void{$t->id();$t->string('table_name',190)->unique();$t->string('owner_extension',100)->index();$t->string('ownership_mode',30)->index();$t->timestamp('first_seen_at')->nullable();$t->json('metadata')->nullable();$t->timestamps();});}
    private function record(string $table,string $mode): void{DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>$table],['owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000011_create_titan_ledger_payables_and_spend','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]);}
    private function installTriggers(): void{if(DB::connection()->getDriverName()!=='mysql'||!Schema::hasTable('titan_ledger_spend_postings'))return;$this->dropTriggers();DB::unprepared("CREATE TRIGGER titan_ledger_spend_posting_no_update BEFORE UPDATE ON titan_ledger_spend_postings FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger spend posting evidence is immutable'; END");DB::unprepared("CREATE TRIGGER titan_ledger_spend_posting_no_delete BEFORE DELETE ON titan_ledger_spend_postings FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger spend posting evidence cannot be deleted'; END");}
    private function dropTriggers(): void{if(DB::connection()->getDriverName()!=='mysql')return;DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_spend_posting_no_update');DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_spend_posting_no_delete');}
};
