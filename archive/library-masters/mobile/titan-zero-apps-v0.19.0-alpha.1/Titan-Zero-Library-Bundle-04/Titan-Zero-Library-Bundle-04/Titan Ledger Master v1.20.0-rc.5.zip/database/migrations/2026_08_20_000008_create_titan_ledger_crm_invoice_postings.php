<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger';
    private const TABLE='titan_ledger_crm_invoice_postings';

    public function up(): void
    {
        $this->ensureOwnershipRegistry();
        $existed=Schema::hasTable(self::TABLE);
        if(!$existed){
            Schema::create(self::TABLE,function(Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index();
                $t->string('document_type',20)->index(); $t->string('document_public_id',100); $t->string('invoice_public_id',100)->index();
                $t->string('source_event_id',120); $t->unsignedInteger('source_version')->default(1); $t->char('fact_hash',64);
                $t->string('currency',3); $t->unsignedBigInteger('subtotal_minor'); $t->unsignedBigInteger('tax_minor'); $t->unsignedBigInteger('total_minor');
                $t->timestamp('issued_at'); $t->char('journal_public_id',26)->index(); $t->string('posting_operation_id',191);
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index(); $t->timestamps();
                $t->unique(['company_id','document_type','document_public_id'],'titan_ledger_crm_document_unique');
                $t->unique(['company_id','source_event_id'],'titan_ledger_crm_event_unique');
                $t->unique(['company_id','posting_operation_id'],'titan_ledger_crm_operation_unique');
            });
        } else {
            $this->assertShape();
        }
        $this->recordOwnership($existed?'adopted':'created');
        $this->installTriggers();
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }

    private function assertShape(): void
    {
        foreach(['public_id','company_id','document_type','document_public_id','invoice_public_id','source_event_id','source_version','fact_hash','currency','subtotal_minor','tax_minor','total_minor','issued_at','journal_public_id','posting_operation_id'] as $column){
            if(!Schema::hasColumn(self::TABLE,$column)) throw new RuntimeException('Titan Ledger refused to adopt incompatible CRM invoice posting evidence table: missing '.$column.'.');
        }
    }

    private function ensureOwnershipRegistry(): void
    {
        if(Schema::hasTable('titan_ledger_schema_ownership')) return;
        Schema::create('titan_ledger_schema_ownership',function(Blueprint $t): void {
            $t->id(); $t->string('table_name',190)->unique(); $t->string('owner_extension',100)->index(); $t->string('ownership_mode',30)->index(); $t->timestamp('first_seen_at')->nullable(); $t->json('metadata')->nullable(); $t->timestamps();
        });
    }

    private function recordOwnership(string $mode): void
    {
        DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>self::TABLE],[
            'owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),
            'metadata'=>json_encode(['migration'=>'2026_08_20_000008_create_titan_ledger_crm_invoice_postings','uninstall_policy'=>'retain']),
            'created_at'=>now(),'updated_at'=>now(),
        ]);
    }

    private function installTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql' || !Schema::hasTable(self::TABLE)) return;
        $this->dropTriggers();
        DB::unprepared("CREATE TRIGGER titan_ledger_crm_posting_no_update BEFORE UPDATE ON titan_ledger_crm_invoice_postings FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger CRM invoice posting evidence is immutable'; END");
        DB::unprepared("CREATE TRIGGER titan_ledger_crm_posting_no_delete BEFORE DELETE ON titan_ledger_crm_invoice_postings FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger CRM invoice posting evidence cannot be deleted'; END");
    }

    private function dropTriggers(): void
    {
        if(DB::connection()->getDriverName()!=='mysql') return;
        DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_crm_posting_no_update');
        DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_crm_posting_no_delete');
    }
};
