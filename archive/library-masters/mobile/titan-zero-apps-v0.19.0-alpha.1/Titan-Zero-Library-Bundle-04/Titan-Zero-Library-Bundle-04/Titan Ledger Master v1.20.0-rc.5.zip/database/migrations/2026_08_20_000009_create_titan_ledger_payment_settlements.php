<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const OWNER='titan-ledger'; private const TABLE='titan_ledger_payment_settlements';
    public function up(): void
    {
        $this->ensureOwnershipRegistry(); $existed=Schema::hasTable(self::TABLE);
        if(!$existed){ Schema::create(self::TABLE,function(Blueprint $t): void {
            $t->id();$t->char('public_id',26)->unique();$t->unsignedBigInteger('company_id')->index();$t->string('settlement_type',20)->index();$t->string('settlement_public_id',100);$t->string('payment_public_id',100)->index();$t->string('invoice_public_id',100)->index();
            $t->string('source_event_id',120);$t->unsignedInteger('source_version')->default(1);$t->char('fact_hash',64);$t->string('rail',30)->index();$t->string('provider_reference',191)->nullable()->index();$t->string('currency',3);
            $t->unsignedBigInteger('gross_amount_minor');$t->unsignedBigInteger('fee_minor')->default(0);$t->unsignedBigInteger('cash_movement_minor');$t->unsignedBigInteger('allocation_minor')->default(0);$t->unsignedBigInteger('overpayment_minor')->default(0);
            $t->timestamp('settled_at');$t->char('journal_public_id',26)->index();$t->string('posting_operation_id',191);$t->unsignedBigInteger('created_by_user_id')->nullable()->index();$t->timestamps();
            $t->unique(['company_id','settlement_type','settlement_public_id'],'titan_ledger_payment_settlement_unique');$t->unique(['company_id','source_event_id'],'titan_ledger_payment_event_unique');$t->unique(['company_id','posting_operation_id'],'titan_ledger_payment_operation_unique');
        }); } else $this->assertShape();
        $this->recordOwnership($existed?'adopted':'created');$this->installTriggers();
    }
    public function down(): void {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
    private function assertShape(): void { foreach(['public_id','company_id','settlement_type','settlement_public_id','payment_public_id','invoice_public_id','source_event_id','source_version','fact_hash','rail','currency','gross_amount_minor','fee_minor','cash_movement_minor','allocation_minor','overpayment_minor','settled_at','journal_public_id','posting_operation_id'] as $c) if(!Schema::hasColumn(self::TABLE,$c)) throw new RuntimeException('Titan Ledger refused to adopt incompatible payment settlement evidence table: missing '.$c.'.'); }
    private function ensureOwnershipRegistry(): void { if(Schema::hasTable('titan_ledger_schema_ownership'))return; Schema::create('titan_ledger_schema_ownership',function(Blueprint $t): void {$t->id();$t->string('table_name',190)->unique();$t->string('owner_extension',100)->index();$t->string('ownership_mode',30)->index();$t->timestamp('first_seen_at')->nullable();$t->json('metadata')->nullable();$t->timestamps();}); }
    private function recordOwnership(string $mode): void { DB::table('titan_ledger_schema_ownership')->updateOrInsert(['table_name'=>self::TABLE],['owner_extension'=>self::OWNER,'ownership_mode'=>$mode,'first_seen_at'=>now(),'metadata'=>json_encode(['migration'=>'2026_08_20_000009_create_titan_ledger_payment_settlements','uninstall_policy'=>'retain']),'created_at'=>now(),'updated_at'=>now()]); }
    private function installTriggers(): void { if(DB::connection()->getDriverName()!=='mysql'||!Schema::hasTable(self::TABLE))return;$this->dropTriggers();DB::unprepared("CREATE TRIGGER titan_ledger_payment_settlement_no_update BEFORE UPDATE ON titan_ledger_payment_settlements FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger payment settlement evidence is immutable'; END");DB::unprepared("CREATE TRIGGER titan_ledger_payment_settlement_no_delete BEFORE DELETE ON titan_ledger_payment_settlements FOR EACH ROW BEGIN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger payment settlement evidence cannot be deleted'; END"); }
    private function dropTriggers(): void { if(DB::connection()->getDriverName()!=='mysql')return;DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_payment_settlement_no_update');DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_payment_settlement_no_delete'); }
};
