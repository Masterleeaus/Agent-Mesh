<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_ledger_signal_outbox')) {
            Schema::create('titan_ledger_signal_outbox', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->char('signal_id', 64)->unique('tl_signal_outbox_signal_unique');
                $table->string('event_type', 120)->index();
                $table->unsignedSmallInteger('schema_version')->default(1);
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('actor_user_id')->nullable()->index();
                $table->string('command_id', 191);
                $table->string('domain_receipt_reference', 191)->index();
                $table->string('subject_type', 80);
                $table->string('subject_public_id', 191)->nullable()->index();
                $table->string('trace_id', 120)->index();
                $table->string('correlation_id', 120)->index();
                $table->string('causation_id', 120)->index();
                $table->char('payload_hash', 64);
                $table->longText('envelope_json');
                $table->string('status', 20)->default('pending')->index();
                $table->unsignedSmallInteger('attempt_count')->default(0);
                $table->timestamp('next_attempt_at')->nullable()->index();
                $table->timestamp('last_attempt_at')->nullable();
                $table->string('last_error_code', 120)->nullable();
                $table->longText('delivery_receipt_json')->nullable();
                $table->timestamp('occurred_at');
                $table->timestamp('delivered_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id','command_id','event_type'], 'tl_signal_company_command_event_unique');
            });
        }

        if (DB::getDriverName() === 'mysql') {
            DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_signal_outbox_guard_update');
            DB::unprepared("CREATE TRIGGER titan_ledger_signal_outbox_guard_update BEFORE UPDATE ON titan_ledger_signal_outbox FOR EACH ROW BEGIN
                IF NOT (NEW.signal_id <=> OLD.signal_id) OR NOT (NEW.event_type <=> OLD.event_type) OR NOT (NEW.schema_version <=> OLD.schema_version)
                   OR NOT (NEW.company_id <=> OLD.company_id) OR NOT (NEW.actor_user_id <=> OLD.actor_user_id)
                   OR NOT (NEW.command_id <=> OLD.command_id) OR NOT (NEW.domain_receipt_reference <=> OLD.domain_receipt_reference)
                   OR NOT (NEW.subject_type <=> OLD.subject_type) OR NOT (NEW.subject_public_id <=> OLD.subject_public_id)
                   OR NOT (NEW.trace_id <=> OLD.trace_id) OR NOT (NEW.correlation_id <=> OLD.correlation_id)
                   OR NOT (NEW.causation_id <=> OLD.causation_id) OR NOT (NEW.payload_hash <=> OLD.payload_hash)
                   OR NOT (NEW.envelope_json <=> OLD.envelope_json) OR NOT (NEW.occurred_at <=> OLD.occurred_at) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger Signal event identity/payload is immutable';
                END IF;
                IF OLD.status = 'delivered' AND (NOT (NEW.status <=> OLD.status) OR NOT (NEW.delivery_receipt_json <=> OLD.delivery_receipt_json) OR NOT (NEW.delivered_at <=> OLD.delivered_at)) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Delivered Titan Ledger Signal event is immutable';
                END IF;
                IF OLD.status = 'failed' AND NOT (NEW.status <=> OLD.status) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Failed Titan Ledger Signal event is terminal';
                END IF;
                IF NOT (NEW.status <=> OLD.status) AND NOT (
                    (OLD.status IN ('pending','retry') AND NEW.status = 'delivering') OR
                    (OLD.status = 'delivering' AND NEW.status IN ('delivered','retry','failed'))
                ) THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid Titan Ledger Signal delivery state transition';
                END IF;
                IF NEW.attempt_count < OLD.attempt_count THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger Signal attempt count cannot decrease';
                END IF;
            END");
            DB::unprepared('DROP TRIGGER IF EXISTS titan_ledger_signal_outbox_guard_delete');
            DB::unprepared("CREATE TRIGGER titan_ledger_signal_outbox_guard_delete BEFORE DELETE ON titan_ledger_signal_outbox FOR EACH ROW BEGIN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Titan Ledger Signal outbox evidence is retained';
            END");
        }
    }

    public function down(): void
    {
        /* Deliberately non-destructive: Titan Ledger retains financial and forensic evidence on rollback/uninstall. */
    }
};
