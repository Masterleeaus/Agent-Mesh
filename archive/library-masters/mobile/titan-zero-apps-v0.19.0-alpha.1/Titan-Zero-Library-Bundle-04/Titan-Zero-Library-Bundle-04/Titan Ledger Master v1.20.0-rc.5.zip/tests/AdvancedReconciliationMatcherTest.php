<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Domains/Reconciliation/AdvancedReconciliationMatcher.php';
require_once __DIR__.'/../System/Domains/Reconciliation/TransferRecognition.php';

use App\Extensions\TitanLedger\System\Domains\Reconciliation\AdvancedReconciliationMatcher;
use App\Extensions\TitanLedger\System\Domains\Reconciliation\TransferRecognition;

function failAdvanced(string $m): never { fwrite(STDERR,"FAIL: $m\n"); exit(1); }

$split = AdvancedReconciliationMatcher::matchGroup(
    [['transaction_public_id'=>'bank-100','posted_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>hash('sha256','batch-1')]],
    [
        ['candidate_public_id'=>'line-60','occurred_on'=>'2026-08-10','amount_minor'=>6000,'reference_hash'=>hash('sha256','batch-1')],
        ['candidate_public_id'=>'line-40','occurred_on'=>'2026-08-11','amount_minor'=>4000,'reference_hash'=>hash('sha256','batch-1')],
    ]
);
if (($split['status']??'') !== 'suggested' || ($split['group_type']??'') !== 'one_to_many' || ($split['bank_total_minor']??0)!==10000 || ($split['ledger_total_minor']??0)!==10000) failAdvanced('one-to-many split match failed');

$many = AdvancedReconciliationMatcher::matchGroup(
    [
        ['transaction_public_id'=>'bank-60','posted_on'=>'2026-08-10','amount_minor'=>6000,'reference_hash'=>null],
        ['transaction_public_id'=>'bank-40','posted_on'=>'2026-08-11','amount_minor'=>4000,'reference_hash'=>null],
    ],
    [['candidate_public_id'=>'line-100','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>null]]
);
if (($many['status']??'') !== 'suggested' || ($many['group_type']??'') !== 'many_to_one') failAdvanced('many-to-one match failed');

$bad = AdvancedReconciliationMatcher::matchGroup(
    [['transaction_public_id'=>'bank-x','posted_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>null]],
    [['candidate_public_id'=>'line-x','occurred_on'=>'2026-08-10','amount_minor'=>9999,'reference_hash'=>null]]
);
if (($bad['status']??'') !== 'unmatched') failAdvanced('unequal totals must not match');

$tooFar = AdvancedReconciliationMatcher::matchGroup(
    [['transaction_public_id'=>'bank-far','posted_on'=>'2026-08-01','amount_minor'=>10000,'reference_hash'=>null]],
    [['candidate_public_id'=>'line-far','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>null]]
);
if (($tooFar['status']??'') !== 'unmatched') failAdvanced('group outside date bound must not match');

$pair = TransferRecognition::pair(
    ['transaction_public_id'=>'bank-out','account_public_id'=>'BANK-A','posted_on'=>'2026-08-10','amount_minor'=>-25000,'reference_hash'=>hash('sha256','transfer-42')],
    ['transaction_public_id'=>'bank-in','account_public_id'=>'BANK-B','posted_on'=>'2026-08-11','amount_minor'=>25000,'reference_hash'=>hash('sha256','transfer-42')]
);
if (($pair['status']??'')!=='suggested' || ($pair['amount_minor']??0)!==25000 || ($pair['source_transaction_public_id']??'')!=='bank-out') failAdvanced('transfer pair recognition failed');

$sameAccount = TransferRecognition::pair(
    ['transaction_public_id'=>'a','account_public_id'=>'BANK-A','posted_on'=>'2026-08-10','amount_minor'=>-100,'reference_hash'=>null],
    ['transaction_public_id'=>'b','account_public_id'=>'BANK-A','posted_on'=>'2026-08-10','amount_minor'=>100,'reference_hash'=>null]
);
if (($sameAccount['status']??'')!=='unmatched') failAdvanced('same-account movement must not be recognized as internal transfer');

echo "Advanced reconciliation matcher: PASS\n";
