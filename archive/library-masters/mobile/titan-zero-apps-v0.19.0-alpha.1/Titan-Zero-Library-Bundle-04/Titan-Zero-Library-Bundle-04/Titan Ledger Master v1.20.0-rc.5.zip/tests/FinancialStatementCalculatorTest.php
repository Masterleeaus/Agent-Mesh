<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Reporting/FinancialStatementCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementCalculator;

$calc = new FinancialStatementCalculator();

$rows = [
    ['public_id'=>'a1','code'=>'1000','name'=>'Bank','type'=>'asset','normal_balance'=>'debit','debit_minor'=>150000,'credit_minor'=>20000],
    ['public_id'=>'a2','code'=>'1100','name'=>'Accounts Receivable','type'=>'asset','normal_balance'=>'debit','debit_minor'=>55000,'credit_minor'=>25000],
    ['public_id'=>'a3','code'=>'2000','name'=>'Accounts Payable','type'=>'liability','normal_balance'=>'credit','debit_minor'=>10000,'credit_minor'=>30000],
    ['public_id'=>'a4','code'=>'3000','name'=>'Owner Equity','type'=>'equity','normal_balance'=>'credit','debit_minor'=>0,'credit_minor'=>70000],
    ['public_id'=>'a5','code'=>'3100','name'=>'Retained Earnings','type'=>'equity','normal_balance'=>'credit','debit_minor'=>0,'credit_minor'=>10000],
    ['public_id'=>'a6','code'=>'4000','name'=>'Sales Revenue','type'=>'revenue','normal_balance'=>'credit','debit_minor'=>5000,'credit_minor'=>100000],
    ['public_id'=>'a7','code'=>'5000','name'=>'Cost of Sales','type'=>'cost_of_sales','normal_balance'=>'debit','debit_minor'=>20000,'credit_minor'=>0],
    ['public_id'=>'a8','code'=>'6000','name'=>'Operating Expense','type'=>'expense','normal_balance'=>'debit','debit_minor'=>25000,'credit_minor'=>0],
];

$tb = $calc->trialBalance($rows);
if ($tb['total_debit_minor'] !== 265000 || $tb['total_credit_minor'] !== 255000) {
    fwrite(STDERR, "FAIL: trial balance raw totals unexpected\n"); exit(1);
}
if ($tb['difference_minor'] !== 10000 || $tb['balanced'] !== false) {
    fwrite(STDERR, "FAIL: unbalanced trial balance must be explicit\n"); exit(1);
}

$balancedRows = $rows;
$balancedRows[3]['credit_minor'] += 10000;
$tb2 = $calc->trialBalance($balancedRows);
if ($tb2['balanced'] !== true || $tb2['difference_minor'] !== 0) {
    fwrite(STDERR, "FAIL: balanced trial balance not recognized\n"); exit(1);
}

$pl = $calc->profitAndLoss($rows);
if ($pl['revenue_minor'] !== 95000 || $pl['cost_of_sales_minor'] !== 20000 || $pl['operating_expenses_minor'] !== 25000 || $pl['net_profit_minor'] !== 50000) {
    fwrite(STDERR, "FAIL: P&L classification or sign normalization incorrect\n"); exit(1);
}

$bs = $calc->balanceSheet($balancedRows);
if ($bs['assets_minor'] !== 160000 || $bs['liabilities_minor'] !== 20000 || $bs['equity_accounts_minor'] !== 90000 || $bs['unclosed_earnings_minor'] !== 50000) {
    fwrite(STDERR, "FAIL: balance sheet components incorrect\n"); exit(1);
}
if ($bs['liabilities_and_equity_minor'] !== 160000 || $bs['balanced'] !== true || $bs['difference_minor'] !== 0) {
    fwrite(STDERR, "FAIL: balance sheet must include unclosed earnings and balance\n"); exit(1);
}

echo "Financial statement calculator: PASS\n";
