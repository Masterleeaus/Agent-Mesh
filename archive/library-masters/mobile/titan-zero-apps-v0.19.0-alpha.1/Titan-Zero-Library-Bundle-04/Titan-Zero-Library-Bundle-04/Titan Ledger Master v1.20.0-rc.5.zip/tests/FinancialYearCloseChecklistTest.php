<?php

declare(strict_types=1);
require_once __DIR__ . '/../System/Domains/Accounting/FinancialYearCloseChecklist.php';
use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCloseChecklist;

$check = new FinancialYearCloseChecklist();
$ready = $check->evaluate([
    'year_status'=>'open','period_count'=>12,'open_period_count'=>0,'unposted_journal_count'=>0,'trial_balance_difference_minor'=>0,
    'unreconciled_bank_session_count'=>0,'draft_gst_snapshot_count'=>0,'currency'=>'AUD','source_fingerprint'=>str_repeat('a',64),
]);
if ($ready['ready'] !== true || $ready['blocking_count'] !== 0) { fwrite(STDERR,"FAIL ready checklist\n"); exit(1); }
$blocked = $check->evaluate([
    'year_status'=>'open','period_count'=>12,'open_period_count'=>2,'unposted_journal_count'=>1,'trial_balance_difference_minor'=>1,
    'unreconciled_bank_session_count'=>1,'draft_gst_snapshot_count'=>1,'currency'=>'AUD','source_fingerprint'=>str_repeat('b',64),
]);
if ($blocked['ready'] !== false || $blocked['blocking_count'] < 5) { fwrite(STDERR,"FAIL blocked checklist\n"); exit(1); }
if (!in_array('trial_balance_unbalanced',$blocked['blocking_codes'],true)) { fwrite(STDERR,"FAIL missing TB blocker\n"); exit(1); }

echo "Financial-year close checklist: PASS\n";
