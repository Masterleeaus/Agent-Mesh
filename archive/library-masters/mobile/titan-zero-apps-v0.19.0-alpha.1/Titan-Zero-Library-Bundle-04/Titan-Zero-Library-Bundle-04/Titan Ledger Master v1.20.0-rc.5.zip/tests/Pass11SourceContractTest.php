<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
'System/Integrations/Spend/SpendAccountingFact.php','System/Integrations/Spend/SpendAccountingJournalMapper.php','System/Integrations/Spend/SpendAccountingService.php','System/Integrations/Spend/SpendAccountingPort.php','System/Domains/Payables/PayableProjectionService.php','System/Http/Controllers/PayableController.php','database/migrations/2026_08_20_000011_create_titan_ledger_payables_and_spend.php','resources/payables/payables-contract.v1.json'] as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';foreach(['ledger.payable.bill.post','ledger.payable.credit_note.post','ledger.payable.payment.post','ledger.spend.actual.post'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';foreach(['ledger.payable.bill.posted','ledger.payable.credit_note.posted','ledger.payable.payment.posted','ledger.spend.actual.posted'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';if(!str_contains($provider,'titan.ledger.spend-accounting.v1'))$errors[]='spend port binding missing';
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';foreach(['Payables','AP and Spend Adapter'] as $n)if(!str_contains($nav,$n))$errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<11)$errors[]='extension pass not advanced';if(version_compare((string)($ext['version']??'0'),'1.11.0-alpha.12','<'))$errors[]='version earlier than Pass 11';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['command_bus']['command_count']??0)<26)$errors[]='command count earlier than Pass 11';if(($rich['signal']['event_count']??0)<26)$errors[]='event count earlier than Pass 11';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Pass 11 source contract: PASS\n";
