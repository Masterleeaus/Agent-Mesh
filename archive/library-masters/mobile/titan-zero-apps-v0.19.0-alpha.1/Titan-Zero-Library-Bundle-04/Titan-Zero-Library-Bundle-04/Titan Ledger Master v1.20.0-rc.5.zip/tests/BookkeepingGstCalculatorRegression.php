<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Domains/Bookkeeping/BookkeepingGstCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Bookkeeping\BookkeepingGstCalculator;
$gst=new BookkeepingGstCalculator();
$cases=[
    ['exclusive',10000,1000,['amount_ex_gst_minor'=>10000,'gst_minor'=>1000,'amount_inc_gst_minor'=>11000,'gst_rate_bps'=>1000,'gst_treatment'=>'exclusive']],
    ['inclusive',11000,1000,['amount_ex_gst_minor'=>10000,'gst_minor'=>1000,'amount_inc_gst_minor'=>11000,'gst_rate_bps'=>1000,'gst_treatment'=>'inclusive']],
    ['gst_free',10000,1000,['amount_ex_gst_minor'=>10000,'gst_minor'=>0,'amount_inc_gst_minor'=>10000,'gst_rate_bps'=>1000,'gst_treatment'=>'gst_free']],
];
foreach($cases as [$treatment,$amount,$rate,$expected]){
    $actual=$gst->calculate($amount,$treatment,$rate);
    if($actual!==$expected){fwrite(STDERR,"FAIL GST {$treatment}: ".json_encode($actual)."\n");exit(1);}
}

$stored=$gst->calculateUpdate(10000,1000,11000,'exclusive',1000,['description'=>'metadata only']);
$expected=['amount_ex_gst_minor'=>10000,'gst_minor'=>1000,'amount_inc_gst_minor'=>11000,'gst_rate_bps'=>1000,'gst_treatment'=>'exclusive'];
if($stored!==$expected){fwrite(STDERR,'FAIL exclusive GST metadata update compounded value: '.json_encode($stored)."\n");exit(1);}

try{
    $gst->calculateUpdate(10000,1000,11000,'exclusive',1000,['gst_treatment'=>'inclusive']);
    fwrite(STDERR,"FAIL GST definition change without amount was accepted\n");exit(1);
}catch(InvalidArgumentException $e){
    if(!str_contains($e->getMessage(),'amount is required')){fwrite(STDERR,"FAIL unexpected GST mutation guard message\n");exit(1);}
}

$changed=$gst->calculateUpdate(10000,1000,11000,'exclusive',1000,['amount_minor'=>20000]);
if($changed['amount_inc_gst_minor']!==22000||$changed['gst_minor']!==2000){fwrite(STDERR,"FAIL explicit amount update did not recalculate GST\n");exit(1);}

echo "PASS GST calculator and manual-update regression\n";
