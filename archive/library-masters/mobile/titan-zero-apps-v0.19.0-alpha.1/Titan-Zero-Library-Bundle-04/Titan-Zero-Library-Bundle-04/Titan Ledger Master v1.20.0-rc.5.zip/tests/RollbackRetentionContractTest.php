<?php

declare(strict_types=1);

$root=dirname(__DIR__);$errors=[];
function methodBody(string $src,string $signature): ?string{
    $pos=strpos($src,$signature);if($pos===false)return null;$open=strpos($src,'{',$pos);if($open===false)return null;$depth=0;$len=strlen($src);
    for($i=$open;$i<$len;$i++){
        $ch=$src[$i];if($ch==='{')$depth++;elseif($ch==='}'){$depth--;if($depth===0)return substr($src,$open+1,$i-$open-1);}
    }
    return null;
}
foreach(glob($root.'/database/migrations/*.php')?:[] as $file){
    $src=(string)file_get_contents($file);$body=methodBody($src,'public function down(): void');if($body===null)continue;
    foreach(['dropIfExists','dropColumn','DROP TRIGGER','renameColumn','Schema::drop'] as $needle)if(str_contains($body,$needle))$errors[]=basename($file).' destructive down contains '.$needle;
}
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Rollback retention contract: PASS\n";
