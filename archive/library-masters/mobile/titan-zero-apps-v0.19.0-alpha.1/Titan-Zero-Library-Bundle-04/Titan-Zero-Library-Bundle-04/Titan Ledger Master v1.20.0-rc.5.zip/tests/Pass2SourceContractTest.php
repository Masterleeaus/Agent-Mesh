<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$errors = [];
$read = static function (string $path) use ($root, &$errors): string {
    $full = $root . '/' . $path;
    if (! is_file($full)) {
        $errors[] = "missing {$path}";
        return '';
    }
    return (string) file_get_contents($full);
};

$migration = $read('database/migrations/2026_08_19_000002_create_titan_ledger_chart_of_accounts.php');
$service = $read('System/Domains/Accounting/ChartOfAccountsService.php');
$provider = $read('System/TitanLedgerServiceProvider.php');
$controller = $read('System/Http/Controllers/ChartOfAccountsController.php');
$apiRoutes = $read('routes/api.php');
$manifestRaw = $read('extension.manifest.json');
$capabilitiesRaw = $read('CAPABILITIES.json');

if ($migration !== '') {
    foreach (['titan_ledger_accounts','public_id','company_id','system_key','parent_public_id','normal_balance','tax_code','is_system_account','is_protected','is_active'] as $needle) {
        if (! str_contains($migration, $needle)) $errors[] = "COA migration missing {$needle}";
    }
    if (! str_contains($migration, "unique(['company_id','code']")) $errors[] = 'COA migration lacks company-scoped code uniqueness';
    if (! str_contains($migration, "unique(['company_id','system_key']")) $errors[] = 'COA migration lacks company-scoped system-key uniqueness';
    if (! str_contains($migration, 'titan_ledger_schema_ownership')) $errors[] = 'COA migration lacks schema ownership registration';
    if (! str_contains($migration, 'Deliberately non-destructive')) $errors[] = 'COA rollback is not non-destructive';
    if (str_contains($migration, "Schema::create('chart_of_accounts'")) $errors[] = 'ambiguous global chart_of_accounts table must not be created';
    if (str_contains($migration, "Schema::create('acc_coa'")) $errors[] = 'legacy acc_coa table must not be created';
}

if ($service !== '') {
    foreach (['ensureDefaults','all','create','update','findByCode','findSystemAccount','company_id','is_protected','insertOrIgnore','Required system account conflict','Account hierarchy cycle detected'] as $needle) {
        if (! str_contains($service, $needle)) $errors[] = "ChartOfAccountsService missing {$needle}";
    }
}

if ($service !== '' && (! str_contains($service, "'subtype','normal_balance','tax_code','system_key','parent_public_id'") || ! str_contains($service, "'is_system_account','is_protected'"))) $errors[] = 'protected system-account structural fields are not locked';
if (! str_contains($provider, 'ChartOfAccountsService::class')) $errors[] = 'COA service is not registered';
if ($controller !== '') {
    foreach (['function index','function store','function update','ChartOfAccountsService'] as $needle) {
        if (! str_contains($controller, $needle)) $errors[] = "COA controller missing {$needle}";
    }
}
if (! str_contains($apiRoutes, '/bookkeeping/accounts')) $errors[] = 'COA API routes are missing';

if ($manifestRaw !== '') {
    $manifest = json_decode($manifestRaw, true, 512, JSON_THROW_ON_ERROR);
    if ((int) ($manifest['cumulative_pass'] ?? ($manifest['upgrade']['pass'] ?? 0)) < 2) $errors[] = 'manifest upgrade pass is earlier than Pass 2';
    if ((int) ($manifest['titan_architecture']['convergence_pass'] ?? 0) < 2) $errors[] = 'architecture convergence pass is earlier than Pass 2';
    if (! in_array('ledger.chart_of_accounts', $manifest['capabilities'] ?? [], true)) $errors[] = 'manifest lacks ledger.chart_of_accounts capability';
}

if ($capabilitiesRaw !== '') {
    $caps = json_decode($capabilitiesRaw, true, 512, JSON_THROW_ON_ERROR);
    if (! in_array('ledger.chart_of_accounts', $caps['capabilities'] ?? [], true)) $errors[] = 'CAPABILITIES lacks ledger.chart_of_accounts';
}

if ($errors) {
    fwrite(STDERR, "FAIL Pass 2 source contracts\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "PASS Pass 2 source contracts\n";
