<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Receivables/ReceivableBalanceCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableBalanceCalculator;

$cases = [
    ['invoice'=>11000,'credits'=>0,'payments'=>0,'refunds'=>0,'overpayments'=>0,'overpayment_refunds'=>0,'outstanding'=>11000,'receivable_credit'=>0,'customer_credit'=>0],
    ['invoice'=>11000,'credits'=>1000,'payments'=>4000,'refunds'=>0,'overpayments'=>0,'overpayment_refunds'=>0,'outstanding'=>6000,'receivable_credit'=>0,'customer_credit'=>0],
    ['invoice'=>11000,'credits'=>1000,'payments'=>10000,'refunds'=>2500,'overpayments'=>0,'overpayment_refunds'=>0,'outstanding'=>2500,'receivable_credit'=>0,'customer_credit'=>0],
    ['invoice'=>11000,'credits'=>0,'payments'=>11000,'refunds'=>0,'overpayments'=>2500,'overpayment_refunds'=>500,'outstanding'=>0,'receivable_credit'=>0,'customer_credit'=>2000],
    ['invoice'=>11000,'credits'=>2000,'payments'=>11000,'refunds'=>0,'overpayments'=>0,'overpayment_refunds'=>0,'outstanding'=>0,'receivable_credit'=>2000,'customer_credit'=>2000],
];
foreach ($cases as $i => $case) {
    $result = ReceivableBalanceCalculator::calculate(
        $case['invoice'], $case['credits'], $case['payments'], $case['refunds'], $case['overpayments'], $case['overpayment_refunds']
    );
    if ($result['outstanding_minor'] !== $case['outstanding']) {
        fwrite(STDERR, "Case {$i} outstanding mismatch\n"); exit(1);
    }
    if ($result['receivable_credit_minor'] !== $case['receivable_credit']) { fwrite(STDERR, "Case {$i} receivable credit mismatch\n"); exit(1); }
    if ($result['customer_credit_minor'] !== $case['customer_credit']) {
        fwrite(STDERR, "Case {$i} customer credit mismatch\n"); exit(1);
    }
}

foreach ([
    [-1,0,0,0,0,0], [100,101,0,0,0,0], [100,0,0,101,0,0], [100,0,0,0,0,1],
] as $bad) {
    try {
        ReceivableBalanceCalculator::calculate(...$bad);
        fwrite(STDERR, "Expected invalid receivable balance input to fail\n"); exit(1);
    } catch (InvalidArgumentException) {}
}

echo "Receivable balance calculator: PASS\n";
