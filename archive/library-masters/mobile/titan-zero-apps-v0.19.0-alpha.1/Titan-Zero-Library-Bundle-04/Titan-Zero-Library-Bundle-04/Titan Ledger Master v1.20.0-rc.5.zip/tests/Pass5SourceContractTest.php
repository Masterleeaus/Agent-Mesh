<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$mustExist = [
    'System/CommandBus/LedgerCommandDefinitionRegistry.php',
    'System/CommandBus/LedgerCommandAdapter.php',
    'System/CommandBus/LedgerCommandBusGatewayContract.php',
    'System/CommandBus/UnavailableLedgerCommandBusGateway.php',
    'System/CommandBus/LedgerDomainReceiptService.php',
    'System/Navigation/TitanLedgerNavigation.php',
    'System/Navigation/HostNavigationRegistrar.php',
    'System/Navigation/MenuSyncService.php',
    'System/Console/SyncLedgerHostCommand.php',
    'System/Http/Controllers/LedgerWorkspaceController.php',
    'System/Http/Middleware/EnsureLedgerSuperAdmin.php',
    'database/migrations/2026_08_20_000005_create_titan_ledger_command_receipts.php',
    'resources/views/workspace/index.blade.php',
];
foreach ($mustExist as $path) {
    if (!is_file($root . '/' . $path)) { fwrite(STDERR, "Missing Pass 5 file: {$path}\n"); exit(1); }
}

$web = file_get_contents($root . '/routes/web.php');

$workspace = file_get_contents($root . '/System/Http/Controllers/LedgerWorkspaceController.php');
foreach (['overview','accounts','journals','financialYears','accountingPeriods','commandReceipts','diagnostics','adminOverview','commandAuthority','menuDiagnostics','systemDiagnostics'] as $method) {
    if (!preg_match('/function\s+' . preg_quote($method, '/') . '\s*\(/', $workspace)) { fwrite(STDERR, "Workspace controller missing method: {$method}\n"); exit(1); }
}

foreach ([
    'dashboard.user.titan-ledger.',
    'dashboard.admin.titan-ledger.',
    'EnsureLedgerSuperAdmin',
] as $needle) {
    if (!str_contains($web, $needle)) { fwrite(STDERR, "Missing web route contract: {$needle}\n"); exit(1); }
}

$provider = file_get_contents($root . '/System/TitanLedgerServiceProvider.php');
foreach (['LedgerCommandBusGatewayContract', 'UnavailableLedgerCommandBusGateway', 'HostNavigationRegistrar', 'SyncLedgerHostCommand'] as $needle) {
    if (!str_contains($provider, $needle)) { fwrite(STDERR, "Provider missing Pass 5 binding: {$needle}\n"); exit(1); }
}

$manifest = json_decode(file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
if (($manifest['cumulative_pass'] ?? ($manifest['upgrade']['pass'] ?? 0)) < 5) { fwrite(STDERR, "Manifest upgrade pass is below 5\n"); exit(1); }
if (($manifest['titan_architecture']['command_execution'] ?? '') !== 'titan_command_bus_only') { fwrite(STDERR, "Command execution is not command-bus-only\n"); exit(1); }

$rootManifest = json_decode(file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$deps=$rootManifest['dependencies']??[];$depSlugs=[];foreach($deps as $k=>$v){if(is_array($v)&&isset($v['slug']))$depSlugs[]=(string)$v['slug'];elseif(is_string($k))$depSlugs[]=$k;}if(!in_array('titan-command-bus',$depSlugs,true)){fwrite(STDERR, "Titan Command Bus is not a required dependency\n"); exit(1);}

$submission = file_get_contents($root . '/System/CommandBus/LedgerCommandSubmissionService.php');
if (str_contains($submission, 'dispatchLocal(') || str_contains($submission, 'LocalLedgerCommandBridge')) { fwrite(STDERR, "Local command execution bypass remains\n"); exit(1); }
if (!str_contains($submission, '$this->bus->dispatch($envelope)')) { fwrite(STDERR, "Ledger mutation submission does not dispatch to Titan Command Bus\n"); exit(1); }

$api = file_get_contents($root . '/routes/api.php');
if (!str_contains($api, 'LedgerCommandController')) { fwrite(STDERR, "Mutating API routes are not command-submission routes\n"); exit(1); }

echo "Pass 5 source contract: PASS\n";
