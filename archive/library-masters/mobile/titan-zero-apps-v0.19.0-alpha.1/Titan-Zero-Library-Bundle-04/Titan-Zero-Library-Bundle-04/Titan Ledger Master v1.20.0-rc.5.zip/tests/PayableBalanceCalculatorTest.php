<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Payables/PayableBalanceCalculator.php';
use App\Extensions\TitanLedger\System\Domains\Payables\PayableBalanceCalculator;
$r=PayableBalanceCalculator::calculate(11000,2200,5000,500);
if($r!==['outstanding_minor'=>3800,'payable_credit_minor'=>0,'supplier_prepayment_minor'=>500]) exit(1);
$r=PayableBalanceCalculator::calculate(11000,11000,1000,0);
if($r['outstanding_minor']!==0||$r['payable_credit_minor']!==1000) exit(1);
echo "Payable balance calculator: PASS\n";
