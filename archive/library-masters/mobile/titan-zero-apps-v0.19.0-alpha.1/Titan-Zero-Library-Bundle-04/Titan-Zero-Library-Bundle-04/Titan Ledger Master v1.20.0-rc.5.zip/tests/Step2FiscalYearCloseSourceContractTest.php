<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Accounting/YearEndCloseCalculator.php',
 'System/Domains/Accounting/FinancialYearCloseChecklist.php',
 'System/Domains/Accounting/FinancialYearCloseService.php',
 'System/Integrations/Accounting/FinancialYearCloseReadPort.php',
 'System/Http/Controllers/FinancialYearCloseController.php',
 'database/migrations/2026_08_21_000017_create_titan_ledger_financial_year_closes.php',
 'resources/accounting/financial-year-close-contract.v1.json'
] as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.financial_year.close.prepare','ledger.financial_year.close','ledger.financial_year.reopen'] as $n) if(!str_contains($defs,$n)) $errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';
foreach(['ledger.financial_year.close_prepared','ledger.financial_year.closed','ledger.financial_year.reopened'] as $n) if(!str_contains($events,$n)) $errors[]='signal missing '.$n;
$journal=@file_get_contents($root.'/System/Domains/Accounting/JournalService.php')?:'';
if(!str_contains($journal,"'year_end_close'")) $errors[]='year_end_close journal type missing';
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';
if(!str_contains($provider,'titan.ledger.financial-year-close.v1')) $errors[]='close read port binding missing';
$mig=@file_get_contents($root.'/database/migrations/2026_08_21_000017_create_titan_ledger_financial_year_closes.php')?:'';
foreach(['titan_ledger_financial_year_closes','source_fingerprint','close_journal_public_id','checklist_json','close_hash','supersedes_public_id'] as $n) if(!str_contains($mig,$n)) $errors[]='migration missing '.$n;
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';
if(!str_contains($nav,'Year-End Close')) $errors[]='user close navigation missing';
if(!str_contains($nav,'Fiscal Close Control')) $errors[]='admin close navigation missing';
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);
if(version_compare((string)($ext['version']??'0'),'1.17.0-rc.2','<')) $errors[]='version predates Step2';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Step 2 fiscal-year close source contract: PASS\n";
