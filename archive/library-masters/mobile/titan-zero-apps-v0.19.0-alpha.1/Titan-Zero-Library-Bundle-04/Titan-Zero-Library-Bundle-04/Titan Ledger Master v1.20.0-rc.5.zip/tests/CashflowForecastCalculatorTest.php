<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Forecasting/CashflowForecastCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Forecasting\CashflowForecastCalculator;

$calc = new CashflowForecastCalculator();


$journalCash = $calc->journalMovements([
    ['occurred_on'=>'2026-08-04','debit_minor'=>100000,'credit_minor'=>100500],
    ['occurred_on'=>'2026-08-04','debit_minor'=>25000,'credit_minor'=>0],
]);
if ($journalCash !== [
    ['occurred_on'=>'2026-08-04','inflow_minor'=>0,'outflow_minor'=>500],
    ['occurred_on'=>'2026-08-04','inflow_minor'=>25000,'outflow_minor'=>0],
]) {
    fwrite(STDERR, "FAIL: per-journal net cash classification must exclude internal-transfer principal\n"); exit(1);
}

$actual = $calc->actual([
    ['occurred_on'=>'2026-08-01','inflow_minor'=>120000,'outflow_minor'=>0],
    ['occurred_on'=>'2026-08-02','inflow_minor'=>0,'outflow_minor'=>45000],
    ['occurred_on'=>'2026-08-03','inflow_minor'=>30000,'outflow_minor'=>10000],
]);
if ($actual['inflow_minor'] !== 150000 || $actual['outflow_minor'] !== 55000 || $actual['net_cashflow_minor'] !== 95000) {
    fwrite(STDERR, "FAIL: actual cashflow aggregation incorrect\n"); exit(1);
}

$forecast = $calc->forecast(
    200000,
    [
        ['public_id'=>'ar1','due_at'=>'2026-08-25','outstanding_minor'=>100000],
        ['public_id'=>'ar2','due_at'=>null,'outstanding_minor'=>50000],
        ['public_id'=>'ar3','due_at'=>'2026-11-30','outstanding_minor'=>90000],
    ],
    [
        ['public_id'=>'ap1','due_at'=>'2026-08-28','outstanding_minor'=>40000],
        ['public_id'=>'ap2','due_at'=>null,'outstanding_minor'=>10000],
    ],
    '2026-08-21',
    60,
);
if ($forecast['expected_inflows_minor'] !== 100000 || $forecast['expected_outflows_minor'] !== 40000 || $forecast['closing_cash_minor'] !== 260000) {
    fwrite(STDERR, "FAIL: horizon forecast totals incorrect\n"); exit(1);
}
if ($forecast['excluded_receivables_minor'] !== 140000 || $forecast['excluded_payables_minor'] !== 10000) {
    fwrite(STDERR, "FAIL: excluded unknown/out-of-horizon evidence incorrect\n"); exit(1);
}
if ($forecast['evidence_coverage_bps'] !== 4828 || $forecast['confidence_band'] !== 'LOW') {
    fwrite(STDERR, "FAIL: deterministic evidence coverage/confidence incorrect\n"); exit(1);
}

$runway = $calc->runway(300000, -90000, 30);
if ($runway['average_daily_burn_minor'] !== 3000 || $runway['runway_days'] !== 100) {
    fwrite(STDERR, "FAIL: cash runway calculation incorrect\n"); exit(1);
}
$positive = $calc->runway(300000, 10000, 30);
if ($positive['runway_days'] !== null || $positive['average_daily_burn_minor'] !== 0) {
    fwrite(STDERR, "FAIL: positive cashflow must not invent finite runway\n"); exit(1);
}

echo "Cashflow forecast calculator: PASS\n";
