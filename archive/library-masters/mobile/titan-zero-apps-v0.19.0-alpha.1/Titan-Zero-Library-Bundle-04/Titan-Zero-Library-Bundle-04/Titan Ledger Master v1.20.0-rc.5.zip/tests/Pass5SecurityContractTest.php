<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$errors = [];
if (is_file($root . '/System/Domains/Commanding/LocalLedgerCommandBridge.php')) $errors[] = 'local command bridge still packaged';
if (is_file($root . '/System/Domains/Commanding/LedgerCommandBridgeContract.php')) $errors[] = 'local bridge contract still packaged';

$submission = file_get_contents($root . '/System/CommandBus/LedgerCommandSubmissionService.php');
if (!str_contains($submission, '$this->bus->dispatch($envelope)')) $errors[] = 'request submission does not dispatch to external Command Bus';
foreach (['JournalService', 'ChartOfAccountsService', 'AccountingPeriodService', 'BookkeepingTransactionService'] as $forbidden) if (str_contains($submission, $forbidden)) $errors[] = 'request submission imports domain service ' . $forbidden;

$unavailable = file_get_contents($root . '/System/CommandBus/UnavailableLedgerCommandBusGateway.php');
if (!str_contains($unavailable, 'fail closed') && !str_contains($unavailable, 'fails closed')) $errors[] = 'unavailable gateway does not clearly fail closed';

$adapter = file_get_contents($root . '/System/CommandBus/LedgerCommandAdapter.php');
foreach (['governance_reference', 'trusted-context mismatch', 'LedgerDomainReceiptService'] as $needle) if (!str_contains(strtolower($adapter), strtolower($needle))) $errors[] = 'adapter missing security evidence: ' . $needle;
$receipts = file_get_contents($root . '/System/CommandBus/LedgerDomainReceiptService.php');
foreach (['write_verified', 'write_fingerprint', 'domain_receipt_reference'] as $needle) if (!str_contains($receipts, $needle)) $errors[] = 'receipt service missing ' . $needle;

$migration = file_get_contents($root . '/database/migrations/2026_08_20_000005_create_titan_ledger_command_receipts.php');

foreach (['submission_hash', 'mutated Command Bus submission payload', 'command_version'] as $needle) if (!str_contains($adapter, $needle)) $errors[] = 'adapter missing trusted-submission guard: ' . $needle;
foreach (['result_payload','write_fingerprint','completed_at','started_at'] as $needle) if (!str_contains($migration, "'" . $needle . "'")) $errors[] = 'receipt adoption contract missing column: ' . $needle;
if (!str_contains($migration, "NEW.status NOT IN ('applied','failed','denied')")) $errors[] = 'receipt trigger does not constrain completion transitions';
if (!str_contains($migration, 'NEW.caller_extension <=> OLD.caller_extension') || !str_contains($migration, 'NEW.target_public_id <=> OLD.target_public_id')) $errors[] = 'receipt trigger does not protect full command identity';
foreach (['tl_receipt_company_command_unique', 'write_verified', 'governance_reference', 'guard_update', 'guard_delete'] as $needle) if (!str_contains($migration, $needle)) $errors[] = 'receipt migration missing ' . $needle;

$http = file_get_contents($root . '/System/Http/Support/LedgerCommandHttpContext.php');
if (!str_contains($http, 'expectsJson()') || !str_contains($http, 'Idempotency-Key is required')) $errors[] = 'JSON mutation idempotency is not caller-owned';

$admin = file_get_contents($root . '/System/Http/Middleware/EnsureLedgerSuperAdmin.php');
if (str_contains($admin, "isAdmin()")) $errors[] = 'ordinary admin is accepted as super admin';

if ($errors) { foreach ($errors as $e) fwrite(STDERR, "FAIL: {$e}\n"); exit(1); }
echo "Pass 5 security contract: PASS\n";
