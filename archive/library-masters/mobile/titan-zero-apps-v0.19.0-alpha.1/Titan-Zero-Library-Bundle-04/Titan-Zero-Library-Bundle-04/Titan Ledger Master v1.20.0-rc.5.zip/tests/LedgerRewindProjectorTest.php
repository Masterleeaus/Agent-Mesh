<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Rewind/LedgerRewindProjector.php';

use App\Extensions\TitanLedger\System\Rewind\LedgerRewindProjector;

$receipt = [
    'id'=>12,'public_id'=>'receipt-1','company_id'=>9,'command_id'=>'cmd-1','command_name'=>'ledger.journal.post',
    'governance_reference'=>'gov-1','risk_reference'=>'risk-1','risk_class'=>'HIGH','assurance_reference'=>'assure-1','assurance_class'=>'PASS',
    'trace_id'=>'trace-1','correlation_id'=>'corr-1','causation_id'=>'cause-1','write_fingerprint'=>str_repeat('a',64),'write_verified'=>1,
    'status'=>'applied','completed_at'=>'2026-08-20 10:00:00','result_payload'=>'{"memo":"must not export"}',
];
$event = LedgerRewindProjector::receipt($receipt);
if (($event['event_type'] ?? null) !== 'ledger.command.applied') throw new RuntimeException('Receipt event type wrong.');
if (($event['risk_reference'] ?? null) !== 'risk-1' || ($event['assurance_reference'] ?? null) !== 'assure-1') throw new RuntimeException('Governance evidence absent.');
if (($event['authority_neutral'] ?? null) !== true || ($event['write_policy'] ?? null) !== 'read-only') throw new RuntimeException('Rewind authority boundary missing.');
if (!preg_match('/^[a-f0-9]{64}$/', (string)($event['source_record_hash'] ?? ''))) throw new RuntimeException('Source hash missing.');
if (str_contains(json_encode($event, JSON_THROW_ON_ERROR), 'must not export')) throw new RuntimeException('Raw receipt payload leaked.');

$signal = LedgerRewindProjector::signal([
    'id'=>22,'signal_id'=>'sig-1','company_id'=>9,'event_type'=>'ledger.journal.posted','subject_type'=>'journal','subject_public_id'=>'journal-1',
    'command_id'=>'cmd-1','command_name'=>'ledger.journal.post','governance_reference'=>'gov-1','risk_reference'=>'risk-1','risk_class'=>'HIGH',
    'assurance_reference'=>'assure-1','assurance_class'=>'PASS','domain_receipt_reference'=>'receipt-1','write_fingerprint'=>str_repeat('a',64),
    'trace_id'=>'trace-1','correlation_id'=>'corr-1','causation_id'=>'cause-1','occurred_at'=>'2026-08-20 10:00:01','payload'=>'{"memo":"never"}'
]);
if (($signal['event_type'] ?? null) !== 'ledger.journal.posted' || ($signal['event_id'] ?? null) !== 'sig-1') throw new RuntimeException('Signal projection failed.');
if (str_contains(json_encode($signal, JSON_THROW_ON_ERROR), 'never')) throw new RuntimeException('Raw Signal payload leaked.');

echo "Ledger Rewind projector contract: PASS\n";
