<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Forecasting/ProfitabilityCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Forecasting\ProfitabilityCalculator;

$calc = new ProfitabilityCalculator();
$summary = $calc->summary([
    ['type'=>'revenue','amount_minor'=>250000],
    ['type'=>'other_income','amount_minor'=>10000],
    ['type'=>'cost_of_sales','amount_minor'=>80000],
    ['type'=>'expense','amount_minor'=>90000],
    ['type'=>'other_expense','amount_minor'=>5000],
]);
if ($summary['revenue_minor'] !== 260000 || $summary['direct_cost_minor'] !== 80000 || $summary['gross_profit_minor'] !== 180000) {
    fwrite(STDERR, "FAIL: gross profitability incorrect\n"); exit(1);
}
if ($summary['operating_expense_minor'] !== 95000 || $summary['net_profit_minor'] !== 85000) {
    fwrite(STDERR, "FAIL: net profitability incorrect\n"); exit(1);
}
if ($summary['gross_margin_bps'] !== 6923 || $summary['net_margin_bps'] !== 3269) {
    fwrite(STDERR, "FAIL: margin basis points incorrect\n"); exit(1);
}
$zero = $calc->summary([['type'=>'expense','amount_minor'=>1000]]);
if ($zero['gross_margin_bps'] !== null || $zero['net_margin_bps'] !== null) {
    fwrite(STDERR, "FAIL: zero revenue must not divide by zero or invent margin\n"); exit(1);
}

echo "Profitability calculator: PASS\n";
