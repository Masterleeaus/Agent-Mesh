<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Forecasting/ForecastSnapshotPolicy.php';

use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastSnapshotPolicy;

$p = new ForecastSnapshotPolicy();
foreach (['cashflow_forecast','profitability_pack','cashflow_profitability_pack'] as $type) {
    if (!$p->supports($type)) { fwrite(STDERR, "FAIL: expected forecast snapshot type unsupported: $type\n"); exit(1); }
}
if ($p->supports('journal_post')) { fwrite(STDERR, "FAIL: forecasting must not expose accounting mutation\n"); exit(1); }
$p->assertPrepareAllowed('cashflow_forecast','AUD','2026-08-21',90);
$ok = ['status'=>'prepared','source_fingerprint'=>str_repeat('a',64),'forecast_hash'=>str_repeat('b',64),'evidence_coverage_bps'=>6500];
if (!$p->canFinalize($ok)) { fwrite(STDERR, "FAIL: advisory forecast evidence should be finalizable\n"); exit(1); }
$bad=$ok;$bad['status']='finalized';if($p->canFinalize($bad)){fwrite(STDERR,"FAIL: finalized snapshot cannot finalize again\n");exit(1);}
$bad=$ok;$bad['source_fingerprint']='bad';if($p->canFinalize($bad)){fwrite(STDERR,"FAIL: malformed source fingerprint accepted\n");exit(1);}

try { $p->assertPrepareAllowed('cashflow_forecast','USD','2026-08-21',90); fwrite(STDERR,"FAIL: unsupported consolidated FX forecast accepted\n"); exit(1); } catch (InvalidArgumentException) {}
try { $p->assertPrepareAllowed('cashflow_forecast','AUD','2026-08-21',0); fwrite(STDERR,"FAIL: zero forecast horizon accepted\n"); exit(1); } catch (InvalidArgumentException) {}

echo "Forecast snapshot policy: PASS\n";
