<?php

declare(strict_types=1);

require_once dirname(__DIR__).'/System/Certification/ProductionTriggerCatalog.php';

use App\Extensions\TitanLedger\System\Certification\ProductionTriggerCatalog;

$names=ProductionTriggerCatalog::names();
if(count($names)<63){fwrite(STDERR,'FAIL: expected 63 production triggers, got '.count($names)."\n");exit(1);} 
if(count(array_unique($names))!==count($names)){fwrite(STDERR,"FAIL: duplicate trigger names\n");exit(1);} 
foreach([
 'titan_ledger_journal_no_direct_post_insert','titan_ledger_journal_period_guard_before_post','titan_ledger_command_receipts_guard_update','titan_ledger_signal_outbox_guard_update','titan_ledger_governance_receipt_guard','titan_ledger_crm_posting_no_update','titan_ledger_payment_settlement_no_update','titan_ledger_collection_event_no_update','titan_ledger_spend_posting_no_update','tl_bank_statements_no_update','tl_recon_session_guard_update','tl_gst_snapshot_guard_update','tl_report_snapshot_guard_update','tl_forecast_snapshot_guard_update','tl_fy_close_guard_update','tl_fy_close_no_delete','tl_fy_close_event_no_update','tl_fy_close_event_no_delete'
] as $required){if(!in_array($required,$names,true)){fwrite(STDERR,'FAIL: missing trigger '.$required."\n");exit(1);}}

$migrationSource='';
foreach(glob(dirname(__DIR__).'/database/migrations/*.php')?:[] as $migration){$migrationSource.="\n".file_get_contents($migration);}
foreach($names as $name){if(!str_contains($migrationSource,$name)){fwrite(STDERR,'FAIL: catalog trigger absent from migration sources '.$name."\n");exit(1);}}
echo "Production trigger catalog: PASS (".count($names)." triggers)\n";
