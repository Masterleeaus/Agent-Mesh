<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Signal/LedgerFinancialEventCatalog.php';
require_once __DIR__ . '/../System/Signal/LedgerSignalEnvelope.php';

use App\Extensions\TitanLedger\System\Signal\LedgerSignalEnvelope;

$command = [
    'command_id' => 'cmd-100',
    'command_name' => 'ledger.journal.post',
    'command_version' => 1,
    'company_id' => 44,
    'actor_user_id' => 9,
    'caller_extension' => 'titan-ledger-http',
    'target_public_id' => 'journal-abc',
    'governance_reference' => 'gov-1',
    'risk_reference' => 'risk-1',
    'risk_class' => 'HIGH',
    'risk_score' => 0.81,
    'assurance_reference' => 'assure-1',
    'assurance_class' => 'PASS',
    'assurance_score' => 0.94,
    'trace_id' => null,
    'correlation_id' => null,
    'causation_id' => null,
];
$result = [
    'public_id' => 'journal-abc',
    'journal_type' => 'general',
    'status' => 'posted',
    'entry_date' => '2026-08-20',
    'memo' => 'PRIVATE MEMO MUST NOT LEAK',
    'metadata' => ['bank_account' => 'SECRET'],
];

$a = LedgerSignalEnvelope::fromAppliedCommand($command, $result, 'receipt-1', 'fp-1', '2026-08-20T06:00:00+00:00');
$b = LedgerSignalEnvelope::fromAppliedCommand($command, array_reverse($result, true), 'receipt-1', 'fp-1', '2026-08-20T06:00:00+00:00');

foreach (['signal_id','event_id','event_type','schema_version','company_id','actor_user_id','source_extension','command_id','domain_receipt_reference','trace_id','correlation_id','causation_id','occurred_at','payload_hash','payload'] as $key) {
    if (!array_key_exists($key, $a)) { fwrite(STDERR, "Missing signal field: {$key}\n"); exit(1); }
}
if ($a['event_type'] !== 'ledger.journal.posted' || $a['company_id'] !== 44 || $a['source_extension'] !== 'titan-ledger') {
    fwrite(STDERR, "Signal identity/context incorrect\n"); exit(1);
}
if ($a['trace_id'] !== 'cmd-100' || $a['correlation_id'] !== 'cmd-100' || $a['causation_id'] !== 'cmd-100') {
    fwrite(STDERR, "Root-command lineage fallback incorrect\n"); exit(1);
}
if (($a['risk_reference'] ?? null) !== 'risk-1' || ($a['risk_class'] ?? null) !== 'HIGH' || ($a['assurance_reference'] ?? null) !== 'assure-1' || ($a['assurance_class'] ?? null) !== 'PASS') {
    fwrite(STDERR, "Risk/Assurance evidence not propagated to Signal\n"); exit(1);
}
if (!hash_equals($a['signal_id'], $b['signal_id']) || !hash_equals($a['payload_hash'], $b['payload_hash'])) {
    fwrite(STDERR, "Signal id/payload hash not deterministic\n"); exit(1);
}
$encoded = json_encode($a, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if (str_contains((string)$encoded, 'PRIVATE MEMO') || str_contains((string)$encoded, 'SECRET')) {
    fwrite(STDERR, "Unbounded financial/private payload leaked into Signal\n"); exit(1);
}
if (($a['payload']['status'] ?? null) !== 'posted' || ($a['payload']['journal_type'] ?? null) !== 'general') {
    fwrite(STDERR, "Safe journal summary missing\n"); exit(1);
}

$commandWithLineage = array_replace($command, ['trace_id'=>'trace-x','correlation_id'=>'corr-x','causation_id'=>'cause-x']);
$c = LedgerSignalEnvelope::fromAppliedCommand($commandWithLineage, $result, 'receipt-1', 'fp-1', '2026-08-20T06:00:00+00:00');
if ($c['trace_id'] !== 'trace-x' || $c['correlation_id'] !== 'corr-x' || $c['causation_id'] !== 'cause-x') {
    fwrite(STDERR, "Provided lineage was not preserved\n"); exit(1);
}

try {
    LedgerSignalEnvelope::fromAppliedCommand(array_replace($command, ['company_id'=>0]), $result, 'receipt-1', 'fp-1', '2026-08-20T06:00:00+00:00');
    fwrite(STDERR, "Invalid company context accepted\n"); exit(1);
} catch (InvalidArgumentException) {}

echo "Ledger Signal envelope: PASS\n";
