<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/CommandBus/LedgerCommandDefinitionRegistry.php';
require_once __DIR__ . '/../System/Domains/Commanding/LedgerCommandCatalog.php';
require_once __DIR__ . '/../System/Domains/Commanding/LedgerCommandEnvelope.php';

use App\Extensions\TitanLedger\System\Domains\Commanding\LedgerCommandEnvelope;

$base = [
    'command_id' => 'cmd-123',
    'command_name' => 'ledger.account.create',
    'caller_extension' => 'titan-ledger-http',
    'payload' => ['name' => 'Example', 'code' => '1010'],
    'trace_id' => 'trace-1',
];
$a = LedgerCommandEnvelope::normalize($base, 44, 9);
$b = LedgerCommandEnvelope::normalize(array_replace($base, ['payload' => ['code' => '1010', 'name' => 'Example']]), 44, 9);
if ($a['company_id'] !== 44 || $a['actor_user_id'] !== 9) { fwrite(STDERR, "Trusted context not injected\n"); exit(1); }
if (!hash_equals($a['request_hash'], $b['request_hash'])) { fwrite(STDERR, "Canonical request hash is unstable\n"); exit(1); }

$cases = [
    array_replace($base, ['company_id' => 45]),
    array_replace($base, ['actor_user_id' => 10]),
    array_merge($base, ['command_name' => 'ledger.not.real']),
];
foreach ($cases as $case) {
    try { LedgerCommandEnvelope::normalize($case, 44, 9); fwrite(STDERR, "Spoof/unknown command was accepted\n"); exit(1); }
    catch (InvalidArgumentException) {}
}

echo "Ledger command envelope: PASS\n";
