<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Domains/Reconciliation/BankStatementDuplicatePolicy.php';

use App\Extensions\TitanLedger\System\Domains\Reconciliation\BankStatementDuplicatePolicy;

function failDup(string $m): never { fwrite(STDERR,"FAIL: $m\n"); exit(1); }

$base=[
 'statement_public_id'=>'stmt-a','account_public_id'=>'BANK','currency'=>'AUD','period_start'=>'2026-08-01','period_end'=>'2026-08-31',
 'opening_balance_minor'=>100000,'closing_balance_minor'=>105000,'movement_minor'=>5000,'transaction_count'=>2,'source_event_id'=>'evt-a','source_version'=>1,'source_extension'=>'bank-feed',
 'transactions'=>[
  ['transaction_public_id'=>'t1','posted_at'=>'2026-08-10 00:00:00','posted_on'=>'2026-08-10','amount_minor'=>7000,'reference_hash'=>hash('sha256','a'),'classification_hint'=>'unknown'],
  ['transaction_public_id'=>'t2','posted_at'=>'2026-08-11 00:00:00','posted_on'=>'2026-08-11','amount_minor'=>-2000,'reference_hash'=>hash('sha256','b'),'classification_hint'=>'bank_fee'],
 ],
];
$copy=$base;$copy['statement_public_id']='stmt-b';$copy['source_event_id']='evt-b';foreach($copy['transactions'] as &$tx){$tx['transaction_public_id']='copy-'.$tx['transaction_public_id'];}unset($tx);
if(BankStatementDuplicatePolicy::fingerprint($base)!==BankStatementDuplicatePolicy::fingerprint($copy))failDup('statement fingerprint must ignore provider/statement/transaction identities');
$changed=$copy;$changed['transactions'][1]['amount_minor']=-1999;$changed['closing_balance_minor']=105001;$changed['movement_minor']=5001;
if(BankStatementDuplicatePolicy::fingerprint($base)===BankStatementDuplicatePolicy::fingerprint($changed))failDup('economic statement changes must change fingerprint');
echo "Bank statement duplicate policy: PASS\n";
