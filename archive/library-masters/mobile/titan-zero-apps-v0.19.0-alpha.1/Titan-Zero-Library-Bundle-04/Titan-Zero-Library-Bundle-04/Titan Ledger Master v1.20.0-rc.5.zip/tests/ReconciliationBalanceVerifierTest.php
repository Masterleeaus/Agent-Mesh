<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Reconciliation/ReconciliationBalanceVerifier.php';
use App\Extensions\TitanLedger\System\Domains\Reconciliation\ReconciliationBalanceVerifier;
function failBalance(string $m): never { fwrite(STDERR,"FAIL: $m\n"); exit(1); }
$r=ReconciliationBalanceVerifier::verify(100000,115000,[['transaction_public_id'=>'a','amount_minor'=>20000],['transaction_public_id'=>'b','amount_minor'=>-5000]],['a','b']);
if(!$r['statement_balanced']||!$r['fully_reconciled']||$r['unreconciled_movement_minor']!==0||$r['computed_closing_balance_minor']!==115000)failBalance('full reconciliation failed');
$r2=ReconciliationBalanceVerifier::verify(100000,115000,[['transaction_public_id'=>'a','amount_minor'=>20000],['transaction_public_id'=>'b','amount_minor'=>-5000]],['a']);
if($r2['fully_reconciled']||$r2['unmatched_count']!==1||$r2['unreconciled_movement_minor']!==-5000)failBalance('partial reconciliation not detected');
echo "Reconciliation balance verifier: PASS\n";
