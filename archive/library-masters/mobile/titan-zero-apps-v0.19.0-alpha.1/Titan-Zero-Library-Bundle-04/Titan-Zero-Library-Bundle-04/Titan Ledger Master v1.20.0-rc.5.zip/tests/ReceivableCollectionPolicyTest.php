<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Receivables/ReceivableCollectionPolicy.php';

use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableCollectionPolicy;

$allowed = [
    ['normal','attention'], ['attention','dunning'], ['dunning','promise_to_pay'], ['promise_to_pay','dunning'],
    ['dunning','disputed'], ['disputed','hold'], ['hold','dunning'], ['dunning','collections'], ['collections','closed'],
    ['attention','normal'], ['dunning','normal'],
];
foreach ($allowed as [$from,$to]) if (!ReceivableCollectionPolicy::allows($from,$to)) { fwrite(STDERR,"Expected {$from} -> {$to} allowed\n"); exit(1); }
foreach ([['normal','collections'],['closed','dunning'],['normal','closed'],['hold','collections']] as [$from,$to]) {
    if (ReceivableCollectionPolicy::allows($from,$to)) { fwrite(STDERR,"Expected {$from} -> {$to} denied\n"); exit(1); }
}

try { ReceivableCollectionPolicy::assertTransition('normal','collections'); fwrite(STDERR,"Expected invalid transition to fail\n"); exit(1); } catch (InvalidArgumentException) {}

echo "Receivable collection policy: PASS\n";
