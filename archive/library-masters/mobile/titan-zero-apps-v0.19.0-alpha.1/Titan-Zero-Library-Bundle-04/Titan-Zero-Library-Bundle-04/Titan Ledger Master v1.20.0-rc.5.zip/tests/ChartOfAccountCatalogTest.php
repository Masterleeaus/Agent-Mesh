<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$catalogFile = $root . '/System/Domains/Accounting/ChartOfAccountCatalog.php';
$errors = [];

if (! is_file($catalogFile)) {
    $errors[] = 'ChartOfAccountCatalog production class is missing';
} else {
    require_once $catalogFile;

    $class = 'App\\Extensions\\TitanLedger\\System\\Domains\\Accounting\\ChartOfAccountCatalog';
    if (! class_exists($class)) {
        $errors[] = 'ChartOfAccountCatalog class is not loadable';
    } else {
        $types = $class::types();
        $expectedTypes = ['asset','liability','equity','revenue','cost_of_sales','expense','other_income','other_expense'];
        if ($types !== $expectedTypes) {
            $errors[] = 'canonical account type taxonomy does not match Pass 2 contract';
        }

        $defaults = $class::australianSmeDefaults();
        if (count($defaults) < 20) {
            $errors[] = 'Australian SME baseline is too small';
        }

        $codes = [];
        $systemKeys = [];
        foreach ($defaults as $account) {
            foreach (['code','name','type','subtype','normal_balance','system_key','is_protected'] as $field) {
                if (! array_key_exists($field, $account)) {
                    $errors[] = "default account is missing {$field}";
                    break 2;
                }
            }
            if (isset($codes[$account['code']])) {
                $errors[] = 'duplicate default account code: ' . $account['code'];
                break;
            }
            $codes[$account['code']] = true;
            if ($account['system_key'] !== null) {
                if (isset($systemKeys[$account['system_key']])) {
                    $errors[] = 'duplicate default system key: ' . $account['system_key'];
                    break;
                }
                $systemKeys[$account['system_key']] = true;
            }

            $expectedNormal = in_array($account['type'], ['asset','cost_of_sales','expense','other_expense'], true) ? 'debit' : 'credit';
            if ($account['normal_balance'] !== $expectedNormal) {
                $errors[] = "invalid normal balance for {$account['code']}";
                break;
            }
        }

        foreach (['bank','accounts_receivable','gst_receivable','accounts_payable','gst_payable','retained_earnings','sales_revenue','service_revenue','cost_of_sales','wages_expense','merchant_fees','cash_on_hand','supplier_prepayments','credit_card_payable'] as $requiredKey) {
            if (! isset($systemKeys[$requiredKey])) {
                $errors[] = 'missing required system account: ' . $requiredKey;
            }
        }
    }
}

if ($errors) {
    fwrite(STDERR, "FAIL Chart of Account catalog\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "PASS Chart of Account catalog\n";
