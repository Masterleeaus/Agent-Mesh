<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Reporting/FinancialReportSnapshotPolicy.php';

use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialReportSnapshotPolicy;

$p = new FinancialReportSnapshotPolicy();
foreach (['trial_balance','profit_loss','balance_sheet','management_pack'] as $type) {
    if (!$p->supports($type)) { fwrite(STDERR, "FAIL unsupported expected report type: $type\n"); exit(1); }
}
if ($p->supports('ato_lodgement')) { fwrite(STDERR, "FAIL authority leak\n"); exit(1); }
if (!$p->canFinalize(['status'=>'prepared','balanced'=>true,'complete'=>true,'source_fingerprint'=>str_repeat('a',64)])) { fwrite(STDERR, "FAIL valid snapshot refused\n"); exit(1); }
if ($p->canFinalize(['status'=>'prepared','balanced'=>false,'complete'=>true,'source_fingerprint'=>str_repeat('a',64)])) { fwrite(STDERR, "FAIL unbalanced snapshot finalized\n"); exit(1); }
if ($p->canFinalize(['status'=>'prepared','balanced'=>true,'complete'=>false,'source_fingerprint'=>str_repeat('a',64)])) { fwrite(STDERR, "FAIL incomplete snapshot finalized\n"); exit(1); }
if ($p->canFinalize(['status'=>'finalized','balanced'=>true,'complete'=>true,'source_fingerprint'=>str_repeat('a',64)])) { fwrite(STDERR, "FAIL finalized snapshot finalized again\n"); exit(1); }

echo "Financial report snapshot policy: PASS\n";
