<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/System/Domains/Accounting/AccountingPeriodPolicy.php';

use App\Extensions\TitanLedger\System\Domains\Accounting\AccountingPeriodPolicy;
$policy = new AccountingPeriodPolicy();

$policy->assertPostingAllowed('open', 'general', false, null);

$expectFailure = static function (callable $fn, string $contains): void {
    try {
        $fn();
    } catch (InvalidArgumentException $e) {
        if (! str_contains($e->getMessage(), $contains)) {
            fwrite(STDERR, "Unexpected failure: {$e->getMessage()}\n");
            exit(1);
        }
        return;
    }
    fwrite(STDERR, "Expected failure containing '{$contains}'.\n");
    exit(1);
};

$expectFailure(fn () => $policy->assertPostingAllowed('soft_locked', 'general', false, null), 'soft-locked');
$expectFailure(fn () => $policy->assertPostingAllowed('soft_locked', 'adjustment', true, null), 'override reason');
$expectFailure(fn () => $policy->assertPostingAllowed('soft_locked', 'general', true, 'Late adjustment'), 'adjustment, correction, or reversal');
$policy->assertPostingAllowed('soft_locked', 'adjustment', true, 'Approved prior-period adjustment');
$policy->assertPostingAllowed('soft_locked', 'correction', true, 'Correction to posted journal');
$policy->assertPostingAllowed('soft_locked', 'reversal', true, 'Reverse incorrect journal');
$expectFailure(fn () => $policy->assertPostingAllowed('hard_locked', 'reversal', true, 'Attempted override'), 'hard-locked');
$expectFailure(fn () => $policy->assertPostingAllowed('unexpected', 'general', false, null), 'Unknown accounting period lock state');

echo "PASS AccountingPeriodPolicy\n";
