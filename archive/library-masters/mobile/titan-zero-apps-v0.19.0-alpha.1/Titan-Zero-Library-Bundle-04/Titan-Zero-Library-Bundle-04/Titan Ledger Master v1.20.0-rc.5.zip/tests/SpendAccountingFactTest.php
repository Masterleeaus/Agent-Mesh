<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Integrations/Spend/SpendAccountingFact.php';

use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingFact;

$bill=SpendAccountingFact::bill([
 'bill_public_id'=>'BILL-1','supplier_public_id'=>'SUP-1','source_event_id'=>'evt-bill-1','currency'=>'AUD','issued_at'=>'2026-08-20T10:00:00+10:00','due_at'=>'2026-09-20',
 'subtotal_minor'=>10000,'gst_minor'=>1000,'total_minor'=>11000,
 'account_splits'=>[['account_code'=>'6900','amount_minor'=>6000],['account_code'=>'5100','amount_minor'=>4000]],
]);
if($bill['total_minor']!==11000||$bill['entry_date']!=='2026-08-20'||count($bill['account_splits'])!==2) exit(1);

$failed=false;try{SpendAccountingFact::bill(['bill_public_id'=>'B','supplier_public_id'=>'S','source_event_id'=>'e','currency'=>'AUD','issued_at'=>'2026-08-20','subtotal_minor'=>10000,'gst_minor'=>1000,'total_minor'=>11000,'account_splits'=>[['account_code'=>'6900','amount_minor'=>9999]]]);}catch(InvalidArgumentException){$failed=true;}if(!$failed) exit(1);

$credit=SpendAccountingFact::creditNote(['credit_public_id'=>'CR-1','original_bill_public_id'=>'BILL-1','supplier_public_id'=>'SUP-1','source_event_id'=>'evt-cr-1','currency'=>'AUD','issued_at'=>'2026-08-21','subtotal_minor'=>2000,'gst_minor'=>200,'total_minor'=>2200,'account_splits'=>[['account_code'=>'6900','amount_minor'=>2000]]]);
if($credit['document_type']!=='supplier_credit'||$credit['original_bill_public_id']!=='BILL-1') exit(1);

$payment=SpendAccountingFact::payment(['payment_public_id'=>'PAY-1','bill_public_id'=>'BILL-1','supplier_public_id'=>'SUP-1','source_event_id'=>'evt-pay-1','currency'=>'AUD','paid_at'=>'2026-08-22','rail'=>'bank_transfer','amount_minor'=>5000,'fee_minor'=>0]);
if($payment['payment_type']!=='supplier_payment'||$payment['amount_minor']!==5000) exit(1);

$actual=SpendAccountingFact::actual(['spend_public_id'=>'SP-1','supplier_public_id'=>'SUP-1','source_event_id'=>'evt-sp-1','currency'=>'AUD','spent_at'=>'2026-08-23','rail'=>'card','subtotal_minor'=>3000,'gst_minor'=>300,'total_minor'=>3300,'fee_minor'=>25,'account_splits'=>[['account_code'=>'6600','amount_minor'=>3000]]]);
if($actual['spend_type']!=='actual'||$actual['funding_movement_minor']!==3325) exit(1);

echo "Spend accounting fact: PASS\n";
