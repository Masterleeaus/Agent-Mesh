<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Signal/LedgerFinancialEventCatalog.php';

use App\Extensions\TitanLedger\System\Signal\LedgerFinancialEventCatalog;

$expected = [
    'ledger.account.create' => 'ledger.account.created',
    'ledger.account.update' => 'ledger.account.updated',
    'ledger.journal.create' => 'ledger.journal.created',
    'ledger.journal.lines.replace' => 'ledger.journal.lines_replaced',
    'ledger.journal.validate' => 'ledger.journal.validated',
    'ledger.journal.post' => 'ledger.journal.posted',
    'ledger.journal.reverse' => 'ledger.journal.reversed',
    'ledger.journal.correction.create' => 'ledger.journal.correction_created',
    'ledger.financial_year.create' => 'ledger.financial_year.created',
    'ledger.financial_year.close.prepare' => 'ledger.financial_year.close_prepared',
    'ledger.financial_year.close' => 'ledger.financial_year.closed',
    'ledger.financial_year.reopen' => 'ledger.financial_year.reopened',
    'ledger.accounting_period.transition' => 'ledger.accounting_period.transitioned',
    'ledger.bookkeeping.transaction.create' => 'ledger.bookkeeping.transaction.created',
    'ledger.bookkeeping.transaction.update' => 'ledger.bookkeeping.transaction.updated',
    'ledger.bookkeeping.transaction.delete' => 'ledger.bookkeeping.transaction.deleted',
    'ledger.bookkeeping.category.create' => 'ledger.bookkeeping.category.created',
    'ledger.crm.invoice.post' => 'ledger.crm.invoice.posted',
    'ledger.crm.credit_note.post' => 'ledger.crm.credit_note.posted',
    'ledger.payment.settlement.post' => 'ledger.payment.settlement.posted',
    'ledger.payment.refund.post' => 'ledger.payment.refund.posted',
    'ledger.receivable.collection.transition' => 'ledger.receivable.collection.transitioned',
    'ledger.receivable.follow_up.record' => 'ledger.receivable.follow_up.recorded',
    'ledger.payable.bill.post' => 'ledger.payable.bill.posted',
    'ledger.payable.credit_note.post' => 'ledger.payable.credit_note.posted',
    'ledger.payable.payment.post' => 'ledger.payable.payment.posted',
    'ledger.spend.actual.post' => 'ledger.spend.actual.posted',
    'ledger.bank.statement.import' => 'ledger.bank.statement.imported',
    'ledger.bank.reconciliation.match' => 'ledger.bank.reconciliation.matched',
    'ledger.bank.reconciliation.reject_match' => 'ledger.bank.reconciliation.match_rejected',
    'ledger.bank.reconciliation.close' => 'ledger.bank.reconciliation.closed',
    'ledger.bank.reconciliation.group_match' => 'ledger.bank.reconciliation.group_matched',
    'ledger.bank.reconciliation.group_reject' => 'ledger.bank.reconciliation.group_rejected',
    'ledger.bank.reconciliation.adjustment.post' => 'ledger.bank.reconciliation.adjustment_posted',
    'ledger.banking.account.register' => 'ledger.banking.account.registered',
    'ledger.banking.transfer.post' => 'ledger.banking.transfer.posted',
    'ledger.banking.clearing.settle' => 'ledger.banking.clearing.settled',
    'ledger.banking.credit_card.payment.post' => 'ledger.banking.credit_card.payment_posted',
    'ledger.tax.gst_snapshot.prepare' => 'ledger.tax.gst_snapshot.prepared',
    'ledger.tax.gst_snapshot.finalize' => 'ledger.tax.gst_snapshot.finalized',
    'ledger.tax.gst_snapshot.supersede' => 'ledger.tax.gst_snapshot.superseded',
    'ledger.tax.gst_adjustment.record' => 'ledger.tax.gst_adjustment.recorded',
    'ledger.tax.gst_adjustment.review' => 'ledger.tax.gst_adjustment.reviewed',
    'ledger.tax.gst_snapshot.amend' => 'ledger.tax.gst_snapshot.amended',
    'ledger.reporting.snapshot.prepare' => 'ledger.reporting.snapshot.prepared',
    'ledger.reporting.snapshot.finalize' => 'ledger.reporting.snapshot.finalized',
    'ledger.reporting.snapshot.supersede' => 'ledger.reporting.snapshot.superseded',
    'ledger.forecast.snapshot.prepare' => 'ledger.forecast.snapshot.prepared',
    'ledger.forecast.snapshot.finalize' => 'ledger.forecast.snapshot.finalized',
    'ledger.forecast.snapshot.supersede' => 'ledger.forecast.snapshot.superseded',
];

$all = LedgerFinancialEventCatalog::all();
if (count($all) !== count($expected)) {
    fwrite(STDERR, 'Unexpected event definition count: ' . count($all) . "\n");
    exit(1);
}
foreach ($expected as $command => $eventType) {
    $definition = LedgerFinancialEventCatalog::forCommand($command);
    if (($definition['event_type'] ?? null) !== $eventType) {
        fwrite(STDERR, "Wrong event mapping for {$command}\n");
        exit(1);
    }
    if (($definition['schema_version'] ?? null) !== 1 || empty($definition['subject_type'])) {
        fwrite(STDERR, "Incomplete event definition for {$command}\n");
        exit(1);
    }
}

if (LedgerFinancialEventCatalog::forCommand('ledger.not-real') !== null) {
    fwrite(STDERR, "Unknown command unexpectedly has event mapping\n");
    exit(1);
}

echo "Ledger financial event catalog: PASS (".count($all)." command events)\n";
