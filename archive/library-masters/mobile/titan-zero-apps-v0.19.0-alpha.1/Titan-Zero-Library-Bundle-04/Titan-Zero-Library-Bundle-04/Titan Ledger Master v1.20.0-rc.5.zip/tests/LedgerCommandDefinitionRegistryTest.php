<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/CommandBus/LedgerCommandDefinitionRegistry.php';

use App\Extensions\TitanLedger\System\CommandBus\LedgerCommandDefinitionRegistry;

$definitions = LedgerCommandDefinitionRegistry::all();
$expected = [
    'ledger.account.create',
    'ledger.account.update',
    'ledger.journal.create',
    'ledger.journal.lines.replace',
    'ledger.journal.validate',
    'ledger.journal.post',
    'ledger.journal.reverse',
    'ledger.journal.correction.create',
    'ledger.financial_year.create',
    'ledger.financial_year.close.prepare',
    'ledger.financial_year.close',
    'ledger.financial_year.reopen',
    'ledger.accounting_period.transition',
    'ledger.bookkeeping.transaction.create',
    'ledger.bookkeeping.transaction.update',
    'ledger.bookkeeping.transaction.delete',
    'ledger.bookkeeping.category.create',
    'ledger.crm.invoice.post',
    'ledger.crm.credit_note.post',
    'ledger.payment.settlement.post',
    'ledger.payment.refund.post',
    'ledger.receivable.collection.transition',
    'ledger.receivable.follow_up.record',
    'ledger.payable.bill.post',
    'ledger.payable.credit_note.post',
    'ledger.payable.payment.post',
    'ledger.spend.actual.post',
    'ledger.bank.statement.import',
    'ledger.bank.reconciliation.match',
    'ledger.bank.reconciliation.reject_match',
    'ledger.bank.reconciliation.close',
    'ledger.bank.reconciliation.group_match',
    'ledger.bank.reconciliation.group_reject',
    'ledger.bank.reconciliation.adjustment.post',
    'ledger.banking.account.register',
    'ledger.banking.transfer.post',
    'ledger.banking.clearing.settle',
    'ledger.banking.credit_card.payment.post',
    'ledger.tax.gst_snapshot.prepare',
    'ledger.tax.gst_snapshot.finalize',
    'ledger.tax.gst_snapshot.supersede',
    'ledger.tax.gst_adjustment.record',
    'ledger.tax.gst_adjustment.review',
    'ledger.tax.gst_snapshot.amend',
    'ledger.reporting.snapshot.prepare',
    'ledger.reporting.snapshot.finalize',
    'ledger.reporting.snapshot.supersede',
    'ledger.forecast.snapshot.prepare',
    'ledger.forecast.snapshot.finalize',
    'ledger.forecast.snapshot.supersede',
];

foreach ($expected as $name) {
    if (!isset($definitions[$name])) {
        fwrite(STDERR, "Missing command definition: {$name}\n");
        exit(1);
    }
    $definition = $definitions[$name];
    if (($definition['owner'] ?? null) !== 'titan-ledger' || ($definition['mutation'] ?? null) !== true || ($definition['receipt_required'] ?? null) !== true) {
        fwrite(STDERR, "Invalid mutation authority metadata: {$name}\n");
        exit(1);
    }
}

if (count($definitions) !== count($expected)) {
    fwrite(STDERR, "Unexpected command count: " . count($definitions) . "\n");
    exit(1);
}

echo "Ledger command definition registry: PASS (" . count($definitions) . " commands)\n";
