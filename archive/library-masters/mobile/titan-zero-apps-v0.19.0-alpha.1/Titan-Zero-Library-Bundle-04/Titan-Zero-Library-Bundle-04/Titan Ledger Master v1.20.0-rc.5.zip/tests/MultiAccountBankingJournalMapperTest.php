<?php

declare(strict_types=1);
$root=dirname(__DIR__);
require_once $root.'/System/Domains/Banking/MultiAccountBankingJournalMapper.php';
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingJournalMapper;
$errors=[];
$transfer=MultiAccountBankingJournalMapper::internalTransfer('BANK-A','BANK-B','FEE',100000,250);
$d=array_sum(array_column($transfer,'debit_minor'));$c=array_sum(array_column($transfer,'credit_minor'));
if($d!==100250||$c!==100250)$errors[]='internal transfer not balanced';
$by=[];foreach($transfer as $line)$by[$line['account_public_id']]=$line;
if(($by['BANK-B']['debit_minor']??0)!==100000||($by['BANK-A']['credit_minor']??0)!==100250||($by['FEE']['debit_minor']??0)!==250)$errors[]='internal transfer mapping wrong';
$clear=MultiAccountBankingJournalMapper::clearingSettlement('CLEAR','BANK-B',97500);
if(array_sum(array_column($clear,'debit_minor'))!==97500||array_sum(array_column($clear,'credit_minor'))!==97500)$errors[]='clearing settlement not balanced';
$card=MultiAccountBankingJournalMapper::creditCardPayment('BANK-A','CARD',50000,0,'FEE');
$cb=[];foreach($card as $line)$cb[$line['account_public_id']]=$line;
if(($cb['CARD']['debit_minor']??0)!==50000||($cb['BANK-A']['credit_minor']??0)!==50000)$errors[]='credit card payment mapping wrong';
try{MultiAccountBankingJournalMapper::internalTransfer('SAME','SAME','FEE',100,0);$errors[]='same-account transfer accepted';}catch(InvalidArgumentException){}
if($errors){fwrite(STDERR,"FAIL multi-account banking mapper\n - ".implode("\n - ",$errors)."\n");exit(1);}echo "PASS multi-account banking mapper\n";
