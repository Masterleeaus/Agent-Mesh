<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Tax/AustralianGstTreatmentCatalog.php','System/Domains/Tax/GstBasCalculator.php','System/Domains/Tax/GstSnapshotPolicy.php','System/Domains/Tax/GstTaxLedgerService.php','System/Integrations/Tax/GstTaxLedgerReadPort.php','System/Http/Controllers/TaxLedgerController.php','database/migrations/2026_08_20_000013_create_titan_ledger_gst_tax_snapshots.php','resources/tax/gst-tax-ledger-contract.v1.json'
] as $p)if(!is_file($root.'/'.$p))$errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';foreach(['ledger.tax.gst_snapshot.prepare','ledger.tax.gst_snapshot.finalize','ledger.tax.gst_snapshot.supersede'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';foreach(['ledger.tax.gst_snapshot.prepared','ledger.tax.gst_snapshot.finalized','ledger.tax.gst_snapshot.superseded'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$svc=@file_get_contents($root.'/System/Domains/Tax/GstTaxLedgerService.php')?:'';foreach(['titan_ledger_crm_invoice_postings','titan_ledger_spend_postings','titan_ledger_gst_tax_snapshots'] as $n)if(!str_contains($svc,$n))$errors[]='tax ledger source missing '.$n;foreach(['ato.gov.au','Http::','curl_','GuzzleHttp'] as $n)if(str_contains($svc,$n))$errors[]='tax ledger must not lodge/call ATO: '.$n;
$mig=@file_get_contents($root.'/database/migrations/2026_08_20_000013_create_titan_ledger_gst_tax_snapshots.php')?:'';foreach(['g1_total_sales_minor','one_a_gst_on_sales_minor','one_b_gst_on_purchases_minor','snapshot_hash','supersedes_public_id'] as $n)if(!str_contains($mig,$n))$errors[]='migration missing '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';if(!str_contains($provider,'titan.ledger.gst-tax-ledger.v1'))$errors[]='GST tax ledger read port binding missing';
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';foreach(['GST and BAS','GST Tax Ledger'] as $n)if(!str_contains($nav,$n))$errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<13)$errors[]='extension pass not advanced';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['command_bus']['command_count']??0)<33)$errors[]='command count below Pass 13 floor';if(($rich['signal']['event_count']??0)<33)$errors[]='event count below Pass 13 floor';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Pass 13 source contract: PASS\n";
