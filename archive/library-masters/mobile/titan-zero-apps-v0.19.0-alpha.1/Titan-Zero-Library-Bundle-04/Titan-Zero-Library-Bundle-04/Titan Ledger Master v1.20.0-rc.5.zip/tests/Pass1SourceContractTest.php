<?php

declare(strict_types=1);

$root=dirname(__DIR__);$errors=[];
$read=static fn(string $p):string=>(string)file_get_contents($root.'/'.$p);

$transaction=$read('System/Domains/Bookkeeping/BookkeepingTransactionService.php');
$category=$read('System/Domains/Bookkeeping/BookkeepingCategoryService.php');
$report=$read('System/Domains/Bookkeeping/BookkeepingReportService.php');
$baseMigration=$read('database/migrations/2026_08_09_000015_add_crm_simple_bookkeeping.php');
$manifest=json_decode($read('extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$extension=json_decode($read('extension.json'),true,512,JSON_THROW_ON_ERROR);

if(($manifest['data']['tenant_key']??null)!=='company_id')$errors[]='manifest tenant key is not company_id';
if(($extension['tenant_requirements']['canonical_key']??null)!=='company_id')$errors[]='extension canonical tenant key is not company_id';
foreach(['System/Domains/Bookkeeping/BookkeepingTransactionService.php'=>$transaction,'System/Domains/Bookkeeping/BookkeepingCategoryService.php'=>$category] as $file=>$source){
    if(str_contains($source,('tenant'.'_company_id')))$errors[]="retired tenant column leaked into {$file}";
}
if(!str_contains($transaction,'calculateUpdate'))$errors[]='manual update does not delegate to GST-safe update policy';
if(str_contains($transaction,"\$data['amount_minor']??\$row->amount_inc_gst_minor"))$errors[]='old exclusive-GST compounding fallback remains';
if(!str_contains($transaction,'Metadata-only edits preserve exact stored money'))$errors[]='metadata-only monetary preservation contract missing';
if(str_contains($baseMigration,('tenant'.'_company_id'))||!str_contains($baseMigration,'company_id'))$errors[]='fresh-install migration must create canonical company_id';
if(!str_contains($baseMigration,'titan_ledger_schema_ownership')||!str_contains($baseMigration,'Deliberately non-destructive'))$errors[]='non-destructive rollback retention contract missing';
$legacyExternalReads=str_contains($report,'crm_payment_allocations')||str_contains($report,'crm_payments')||str_contains($report,'crm_invoices')||str_contains($report,'crm_pay_refunds');
if($legacyExternalReads && !str_contains($report,"company_id")) $errors[]='CRM report company boundary resolver missing';
if(!$legacyExternalReads && !str_contains($report,'titan_ledger_crm_invoice_postings')) $errors[]='report must use Ledger-owned invoice posting evidence after CRM table decoupling';

if($errors){fwrite(STDERR,"FAIL Pass 1 source contracts\n - ".implode("\n - ",$errors)."\n");exit(1);}echo "PASS Pass 1 source contracts\n";
