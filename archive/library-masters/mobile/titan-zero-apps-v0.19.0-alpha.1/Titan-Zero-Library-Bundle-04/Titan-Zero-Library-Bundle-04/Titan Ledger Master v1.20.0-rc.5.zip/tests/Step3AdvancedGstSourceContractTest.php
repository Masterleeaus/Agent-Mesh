<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Tax/GstAdjustmentCalculator.php','System/Domains/Tax/GstAdjustmentPolicy.php','System/Domains/Tax/GstTaxAdjustmentService.php',
 'database/migrations/2026_08_21_000018_create_titan_ledger_gst_adjustments.php','resources/tax/advanced-gst-bas-contract.v2.json','tests/Installer176ManifestContractTest.php'
] as $p)if(!is_file($root.'/'.$p))$errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';foreach(['ledger.tax.gst_adjustment.record','ledger.tax.gst_adjustment.review','ledger.tax.gst_snapshot.amend'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';foreach(['ledger.tax.gst_adjustment.recorded','ledger.tax.gst_adjustment.reviewed','ledger.tax.gst_snapshot.amended'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$m=json_decode((string)@file_get_contents($root.'/extension.json'),true);$deps=$m['dependencies']??null;if(!is_array($deps)||!array_is_list($deps))$errors[]='Installer 1.7.6 dependencies must be list';else foreach($deps as $d)if(!is_array($d)||empty($d['slug']))$errors[]='dependency slug missing';
if(version_compare((string)($m['version']??'0'),'1.18.0-rc.3','<'))$errors[]='version earlier than 1.18.0-rc.3';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['upgrade']['pass']??0)<3)$errors[]='upgrade pass earlier than 3';if(($rich['command_bus']['command_count']??0)<43)$errors[]='command count below 43';if(($rich['signal']['event_count']??0)<43)$errors[]='event count below 43';
$svc=(@file_get_contents($root.'/System/Domains/Tax/GstTaxLedgerService.php')?:'').(@file_get_contents($root.'/System/Domains/Tax/GstTaxAdjustmentService.php')?:'').(@file_get_contents($root.'/System/Domains/Tax/GstSnapshotPolicy.php')?:'');foreach(['titan_ledger_gst_adjustments','titan_ledger_gst_adjustment_reviews','full_bas'] as $n)if(!str_contains($svc,$n))$errors[]='tax service missing '.$n;
foreach(['ato.gov.au','Http::','curl_','GuzzleHttp'] as $n)if(str_contains($svc,$n))$errors[]='ATO/network authority leak '.$n;
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Step 3 advanced GST source contract: PASS\n";
