<?php

declare(strict_types=1);

$root=dirname(__DIR__); $errors=[];
$required=[
 'System/Domains/Receivables/ReceivableBalanceCalculator.php',
 'System/Domains/Receivables/ReceivableAgingPolicy.php',
 'System/Domains/Receivables/ReceivableCollectionPolicy.php',
 'System/Domains/Receivables/ReceivableProjectionService.php',
 'System/Domains/Receivables/ReceivableCollectionService.php',
 'database/migrations/2026_08_20_000010_create_titan_ledger_receivables.php',
 'resources/receivables/receivables-contract.v1.json',
];
foreach($required as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.receivable.collection.transition','ledger.receivable.follow_up.record'] as $n) if(!str_contains($defs,$n)) $errors[]='command missing '.$n;
$adapter=@file_get_contents($root.'/System/CommandBus/LedgerCommandAdapter.php')?:'';
foreach(['ReceivableCollectionService','ledger.receivable.collection.transition','ledger.receivable.follow_up.record'] as $n) if(!str_contains($adapter,$n)) $errors[]='adapter missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';
foreach(['ledger.receivable.collection.transitioned','ledger.receivable.follow_up.recorded'] as $n) if(!str_contains($events,$n)) $errors[]='signal missing '.$n;
$crm=@file_get_contents($root.'/System/Integrations/Crm/CrmInvoiceAccountingService.php')?:'';
$pay=@file_get_contents($root.'/System/Integrations/TitanPay/TitanPaySettlementService.php')?:'';
foreach([$crm,$pay] as $i=>$src) if(!str_contains($src,'ReceivableProjectionService')) $errors[]='projection refresh missing from '.($i===0?'CRM':'Titan Pay').' posting path';
$fact=@file_get_contents($root.'/System/Integrations/Crm/CrmInvoiceFact.php')?:'';
if(!str_contains($fact,"'due_at'")) $errors[]='CRM invoice fact due_at support missing';
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';
foreach(['Receivables','AR and Collections'] as $n) if(!str_contains($nav,$n)) $errors[]='navigation missing '.$n;
$routes=@file_get_contents($root.'/routes/web.php')?:'';
foreach(['receivables','ar-collections'] as $n) if(!str_contains($routes,$n)) $errors[]='route missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);
if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<10) $errors[]='extension pass not advanced to 10';
if(version_compare((string)($ext['version']??'0'),'1.10.0-alpha.11','<')) $errors[]='version predates Pass 10';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);
if(($rich['command_bus']['command_count']??0)<22) $errors[]='command count predates Pass 10';
if(($rich['signal']['event_count']??0)<22) $errors[]='event count predates Pass 10';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);} echo "Pass 10 source contract: PASS\n";
