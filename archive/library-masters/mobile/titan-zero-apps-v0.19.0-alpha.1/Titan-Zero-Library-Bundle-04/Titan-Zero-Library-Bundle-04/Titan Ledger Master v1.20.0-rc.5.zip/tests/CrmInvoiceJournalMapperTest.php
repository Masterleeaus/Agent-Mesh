<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Integrations/Crm/CrmInvoiceJournalMapper.php';

use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceJournalMapper;

$accounts = [
    'accounts_receivable' => 'AR',
    'gst_payable' => 'GST',
    'service_revenue' => 'REV1',
    'sales_revenue' => 'REV2',
];
$fact = [
    'subtotal_minor'=>10000,'tax_minor'=>1000,'total_minor'=>11000,
    'revenue_splits'=>[['system_key'=>'service_revenue','amount_minor'=>7000],['system_key'=>'sales_revenue','amount_minor'=>3000]],
];
$issued = CrmInvoiceJournalMapper::issuedLines($fact, $accounts);
$debits = array_sum(array_column($issued,'debit_minor')); $credits = array_sum(array_column($issued,'credit_minor'));
if ($debits !== 11000 || $credits !== 11000 || count($issued) !== 4) exit(1);
$credit = CrmInvoiceJournalMapper::creditNoteLines($fact, $accounts);
$debits = array_sum(array_column($credit,'debit_minor')); $credits = array_sum(array_column($credit,'credit_minor'));
if ($debits !== 11000 || $credits !== 11000 || count($credit) !== 4) exit(1);

echo "CRM invoice journal mapper: PASS\n";
