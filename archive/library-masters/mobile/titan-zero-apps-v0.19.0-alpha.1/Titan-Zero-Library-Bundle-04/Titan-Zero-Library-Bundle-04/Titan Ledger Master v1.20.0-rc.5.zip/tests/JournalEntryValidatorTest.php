<?php

declare(strict_types=1);

$root = dirname(__DIR__);
require_once $root . '/System/Domains/Accounting/JournalEntryValidator.php';

use App\Extensions\TitanLedger\System\Domains\Accounting\JournalEntryValidator;
$validator = new JournalEntryValidator();
$failures = [];

$assertSame = static function (mixed $expected, mixed $actual, string $label) use (&$failures): void {
    if ($expected !== $actual) $failures[] = $label . ': expected ' . var_export($expected, true) . ', got ' . var_export($actual, true);
};
$assertThrows = static function (callable $fn, string $contains, string $label) use (&$failures): void {
    try {
        $fn();
        $failures[] = $label . ': expected exception';
    } catch (InvalidArgumentException $e) {
        if (! str_contains($e->getMessage(), $contains)) $failures[] = $label . ': unexpected message ' . $e->getMessage();
    }
};

$balanced = [
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => 11000, 'credit_minor' => 0],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 10000],
    ['account_public_id' => '01CCCCCCCCCCCCCCCCCCCCCCCC', 'debit_minor' => 0, 'credit_minor' => 1000],
];
$result = $validator->validate($balanced);
$assertSame(11000, $result['debit_total_minor'], 'balanced debit total');
$assertSame(11000, $result['credit_total_minor'], 'balanced credit total');
$assertSame(3, $result['line_count'], 'balanced line count');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => 10000, 'credit_minor' => 0],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 9000],
]), 'must balance', 'unbalanced journal rejected');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => 1000, 'credit_minor' => 1000],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 1000],
]), 'exactly one side', 'dual-sided line rejected');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => 0, 'credit_minor' => 0],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 0],
]), 'positive amount', 'zero-value lines rejected');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => -1000, 'credit_minor' => 0],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 1000],
]), 'non-negative', 'negative amount rejected');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '01AAAAAAAAAAAAAAAAAAAAAAAA', 'debit_minor' => 1000, 'credit_minor' => 0],
]), 'at least two lines', 'single-line journal rejected');

$assertThrows(fn () => $validator->validate([
    ['account_public_id' => '', 'debit_minor' => 1000, 'credit_minor' => 0],
    ['account_public_id' => '01BBBBBBBBBBBBBBBBBBBBBBBB', 'debit_minor' => 0, 'credit_minor' => 1000],
]), 'account_public_id', 'missing account rejected');

if ($failures) {
    fwrite(STDERR, "FAIL JournalEntryValidator\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS JournalEntryValidator\n";
