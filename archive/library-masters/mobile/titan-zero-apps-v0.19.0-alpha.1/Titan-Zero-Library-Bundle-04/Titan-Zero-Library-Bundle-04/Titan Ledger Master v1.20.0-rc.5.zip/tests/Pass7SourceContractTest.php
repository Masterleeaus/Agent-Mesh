<?php

declare(strict_types=1);

$root = dirname(__DIR__); $errors=[];
$required=[
 'System/Governance/LedgerRiskGatewayContract.php','System/Governance/HostLedgerRiskGateway.php','System/Governance/UnavailableLedgerRiskGateway.php',
 'System/Governance/LedgerAssuranceGatewayContract.php','System/Governance/HostLedgerAssuranceGateway.php','System/Governance/UnavailableLedgerAssuranceGateway.php',
 'System/Governance/LedgerGovernanceEvidenceBuilder.php','System/Governance/LedgerExternalDecisionNormalizer.php','System/Governance/LedgerGovernanceEvidenceService.php',
 'System/Rewind/LedgerRewindProjector.php','System/Rewind/LedgerRewindSource.php','resources/rewind/source-manifest.json',
 'database/migrations/2026_08_20_000007_add_titan_ledger_governance_evidence.php'
];
foreach($required as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$adapter=is_file($root.'/System/CommandBus/LedgerCommandAdapter.php')?file_get_contents($root.'/System/CommandBus/LedgerCommandAdapter.php'):'';
foreach(['LedgerGovernanceEvidenceService','evaluate'] as $n) if(!str_contains($adapter,$n)) $errors[]='adapter missing '.$n;
$receipt=is_file($root.'/System/CommandBus/LedgerDomainReceiptService.php')?file_get_contents($root.'/System/CommandBus/LedgerDomainReceiptService.php'):'';
$signal=is_file($root.'/System/Signal/LedgerSignalEnvelope.php')?file_get_contents($root.'/System/Signal/LedgerSignalEnvelope.php'):'';
foreach(['risk_reference','assurance_reference'] as $n){ if(!str_contains($receipt,$n))$errors[]='receipt persistence missing '.$n; if(!str_contains($signal,$n))$errors[]='Signal evidence missing '.$n; }
if(strpos($adapter,'->evaluate(') > strpos($adapter,'->begin(')) $errors[]='governance evaluation must occur before receipt/domain mutation path';
$provider=is_file($root.'/System/TitanLedgerServiceProvider.php')?file_get_contents($root.'/System/TitanLedgerServiceProvider.php'):'';
foreach(['LedgerRiskGatewayContract','LedgerAssuranceGatewayContract','titan.ledger.rewind-source','LedgerRewindSource','RewindSourceAdapter','RewindSourceRegistry'] as $n) if(!str_contains($provider,$n)) $errors[]='provider missing '.$n;
$mig=is_file($root.'/database/migrations/2026_08_20_000007_add_titan_ledger_governance_evidence.php')?file_get_contents($root.'/database/migrations/2026_08_20_000007_add_titan_ledger_governance_evidence.php'):'';
foreach(['risk_reference','risk_class','risk_score','assurance_reference','assurance_class','assurance_score','titan_ledger_command_receipts','titan_ledger_signal_outbox'] as $n) if(!str_contains($mig,$n)) $errors[]='migration missing '.$n;
$source=is_file($root.'/System/Rewind/LedgerRewindSource.php')?file_get_contents($root.'/System/Rewind/LedgerRewindSource.php'):'';
foreach(['sourceKey','watermark','records','company_id','trace_id','cursor'] as $n) if(!str_contains($source,$n)) $errors[]='Rewind source missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);
if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<7) $errors[]='extension pass not advanced to 7';
if(version_compare((string)($ext['version']??'0'),'1.7.0-alpha.8','<')) $errors[]='extension version predates Pass 7';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);} echo "Pass 7 source contract: PASS\n";
