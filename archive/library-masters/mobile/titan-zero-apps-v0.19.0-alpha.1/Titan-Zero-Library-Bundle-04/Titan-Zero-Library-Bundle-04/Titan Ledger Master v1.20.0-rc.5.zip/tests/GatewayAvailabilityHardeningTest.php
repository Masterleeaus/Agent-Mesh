<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/CommandBus/HostLedgerCommandBusGateway.php'=>['try','make($binding)','method_exists($candidate, \'dispatch\')'],
 'System/Governance/HostLedgerRiskGateway.php'=>['try','make($b)','method_exists($candidate,\'evaluate\')'],
 'System/Governance/HostLedgerAssuranceGateway.php'=>['try','make($b)','method_exists($candidate,\'verify\')'],
] as $path=>$needles){$src=(string)@file_get_contents($root.'/'.$path);foreach($needles as $n)if(!str_contains($src,$n))$errors[]=$path.' availability hardening missing '.$n;}
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Gateway availability hardening: PASS\n";
