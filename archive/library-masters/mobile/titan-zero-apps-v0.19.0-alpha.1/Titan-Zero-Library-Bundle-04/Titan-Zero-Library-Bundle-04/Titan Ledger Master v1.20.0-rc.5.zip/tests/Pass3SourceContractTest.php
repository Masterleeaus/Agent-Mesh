<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$errors = [];
$read = static function (string $path) use ($root, &$errors): string {
    $full = $root . '/' . $path;
    if (! is_file($full)) {
        $errors[] = "missing {$path}";
        return '';
    }
    return (string) file_get_contents($full);
};

$migration = $read('database/migrations/2026_08_20_000003_create_titan_ledger_journals.php');
$validator = $read('System/Domains/Accounting/JournalEntryValidator.php');
$service = $read('System/Domains/Accounting/JournalService.php');
$controller = $read('System/Http/Controllers/JournalController.php');
$provider = $read('System/TitanLedgerServiceProvider.php');
$routes = $read('routes/api.php');
$manifestRaw = $read('extension.manifest.json');
$extensionRaw = $read('extension.json');
$capsRaw = $read('CAPABILITIES.json');

if ($migration !== '') {
    foreach (['titan_ledger_journals','titan_ledger_journal_lines','company_id','public_id','status','journal_type','entry_date','posting_operation_id','payload_hash','source_extension','source_event_id','trace_id','correlation_id','causation_id','reversal_of_public_id','correction_of_public_id','debit_minor','credit_minor','account_public_id'] as $needle) {
        if (! str_contains($migration, $needle)) $errors[] = "journal migration missing {$needle}";
    }
    if (! str_contains($migration, "unique(['company_id','posting_operation_id']")) $errors[] = 'journal migration lacks company-scoped posting idempotency uniqueness';
    if (! str_contains($migration, "unique(['company_id','journal_public_id','line_no']")) $errors[] = 'journal line numbering is not unique within company/journal';
    if (! str_contains($migration, 'titan_ledger_schema_ownership')) $errors[] = 'journal migration lacks ownership registration';
    if (! str_contains($migration, 'Deliberately non-destructive')) $errors[] = 'journal rollback is not non-destructive';
    foreach (['installImmutabilityTriggers','BEFORE UPDATE','BEFORE DELETE','BEFORE INSERT',"SIGNAL SQLSTATE '45000'"] as $needle) {
        if (! str_contains($migration, $needle)) $errors[] = "database immutability trigger contract missing {$needle}";
    }
}

if ($validator !== '') {
    foreach (['at least two lines','exactly one side','positive amount','must balance','debit_total_minor','credit_total_minor'] as $needle) {
        if (! str_contains($validator, $needle)) $errors[] = "journal validator missing {$needle}";
    }
}

if ($service !== '') {
    foreach (['createDraft','replaceDraftLines','validateDraft','post','reverse','createCorrectionDraft','lockForUpdate','posting_operation_id','payload_hash','reversal_of_public_id','correction_of_public_id','source_extension','trace_id','correlation_id','causation_id','status','posted','validated','is_active'] as $needle) {
        if (! str_contains($service, $needle)) $errors[] = "JournalService missing {$needle}";
    }
    if (! str_contains($service, "['reversal', 'correction']")) $errors[] = 'generic draft path does not reserve reversal/correction journal types';
    if (! str_contains($service, 'allowInactiveAccounts: true')) $errors[] = 'reversal path does not explicitly permit historically used inactive accounts';
    if (! str_contains($service, "Journal is immutable after posting")) $errors[] = 'posted-journal immutability guard missing';
    if (! str_contains($service, 'Idempotency key collision')) $errors[] = 'posting idempotency collision guard missing';
    if (! str_contains($service, "'metadata' =>")) $errors[] = 'journal payload hashing does not account for metadata';
    if (! str_contains($service, "'source_type' => 'journal.correction'")) $errors[] = 'correction provenance linkage is missing';
}

if ($controller !== '') {
    foreach (['function index','function show','function store','function replaceLines','function validate','function post','function reverse','function correction'] as $needle) {
        if (! str_contains($controller, $needle)) $errors[] = "journal controller missing {$needle}";
    }
}
if (! str_contains($provider, 'JournalService::class')) $errors[] = 'JournalService is not registered';
foreach (['/bookkeeping/journals','/validate','/post','/reverse','/corrections'] as $needle) {
    if (! str_contains($routes, $needle)) $errors[] = "journal API route missing {$needle}";
}

if ($manifestRaw !== '') {
    $manifest = json_decode($manifestRaw, true, 512, JSON_THROW_ON_ERROR);
    if ((int) ($manifest['cumulative_pass'] ?? ($manifest['upgrade']['pass'] ?? 0)) < 3) $errors[] = 'manifest upgrade pass is earlier than Pass 3';
    if ((int) ($manifest['titan_architecture']['convergence_pass'] ?? 0) < 3) $errors[] = 'architecture convergence pass is earlier than Pass 3';
    foreach (['ledger.journals','ledger.double_entry','ledger.journals.reversal','ledger.journals.correction'] as $cap) {
        if (! in_array($cap, $manifest['capabilities'] ?? [], true)) $errors[] = "manifest lacks {$cap}";
    }
}
if ($extensionRaw !== '') {
    $extension = json_decode($extensionRaw, true, 512, JSON_THROW_ON_ERROR);
    if ((int) ($extension['cumulative_pass'] ?? ($extension['upgrade']['pass'] ?? 0)) < 3) $errors[] = 'extension.json upgrade pass is earlier than Pass 3';
    if (version_compare((string) ($extension['version'] ?? '0.0.0'), '1.3.0-alpha.4', '<')) $errors[] = 'extension.json version predates Pass 3';
}
if ($capsRaw !== '') {
    $caps = json_decode($capsRaw, true, 512, JSON_THROW_ON_ERROR);
    foreach (['ledger.journals','ledger.double_entry','ledger.journals.reversal','ledger.journals.correction'] as $cap) {
        if (! in_array($cap, $caps['capabilities'] ?? [], true)) $errors[] = "CAPABILITIES lacks {$cap}";
    }
}

if ($errors) {
    fwrite(STDERR, "FAIL Pass 3 source contracts\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "PASS Pass 3 source contracts\n";
