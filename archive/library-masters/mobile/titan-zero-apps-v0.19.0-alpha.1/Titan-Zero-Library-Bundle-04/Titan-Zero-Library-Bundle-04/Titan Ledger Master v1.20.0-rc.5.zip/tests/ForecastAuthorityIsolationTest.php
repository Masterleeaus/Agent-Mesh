<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach(['System/Domains/Forecasting/CashflowForecastService.php','System/Domains/Forecasting/ProfitabilityService.php','System/Integrations/Forecasting/CashflowForecastingReadPort.php','System/Http/Controllers/ForecastingController.php'] as $rel){$s=(string)file_get_contents($root.'/'.$rel);foreach(['JournalService','LedgerCommandSubmissionService','Crm\\','TitanPay\\','SpendAccountingService'] as $bad)if(str_contains($s,$bad))$errors[]=$rel.' authority leak '.$bad;}
$s=(string)file_get_contents($root.'/System/Domains/Forecasting/ForecastSnapshotService.php');if(str_contains($s,"table('titan_ledger_journals')->insert")||str_contains($s,"table('titan_ledger_journal_lines')->insert"))$errors[]='forecast snapshot service writes accounting tables';
$contract=json_decode((string)file_get_contents($root.'/resources/forecasting/cashflow-forecasting-contract.v1.json'),true);if(($contract['forecast_semantics']['accounting_mutation']??null)!==false)$errors[]='forecast contract grants accounting mutation';if(($contract['forecast_semantics']['confidence_meaning']??'')!=='evidence-coverage-not-payment-probability')$errors[]='forecast confidence semantics drift';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Forecast authority isolation: PASS\n";
