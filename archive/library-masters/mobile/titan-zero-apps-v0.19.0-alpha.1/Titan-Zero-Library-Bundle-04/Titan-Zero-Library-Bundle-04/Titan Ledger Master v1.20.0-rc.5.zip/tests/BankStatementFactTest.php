<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Integrations/Banking/BankStatementFact.php';

use App\Extensions\TitanLedger\System\Integrations\Banking\BankStatementFact;

function failTest(string $message): never { fwrite(STDERR,"FAIL: $message\n"); exit(1); }
function expectInvalid(callable $fn,string $contains): void { try{$fn();failTest('expected invalid: '.$contains);}catch(InvalidArgumentException $e){if(!str_contains($e->getMessage(),$contains))failTest('unexpected error: '.$e->getMessage());} }

$fact=BankStatementFact::statement([
 'statement_public_id'=>'stmt-001','account_public_id'=>'acct-bank','currency'=>'AUD','period_start'=>'2026-08-01','period_end'=>'2026-08-03',
 'opening_balance_minor'=>100000,'closing_balance_minor'=>115000,'source_event_id'=>'bank-feed-001','source_version'=>1,'source_extension'=>'bank-feed',
 'transactions'=>[
  ['transaction_public_id'=>'btx-1','posted_at'=>'2026-08-01T10:00:00+10:00','amount_minor'=>20000,'reference'=>'PAY-ABC-001'],
  ['transaction_public_id'=>'btx-2','posted_at'=>'2026-08-02T12:30:00+10:00','amount_minor'=>-5000,'reference'=>'SUP-XYZ-002'],
 ],
]);
if($fact['statement_public_id']!=='stmt-001'||$fact['movement_minor']!==15000||count($fact['transactions'])!==2)failTest('normalized statement mismatch');
if(($fact['transactions'][0]['reference_hash']??'')!==hash('sha256','pay-abc-001'))failTest('reference hash mismatch');
if(isset($fact['transactions'][0]['reference']))failTest('raw bank reference must not persist in normalized fact');
if(BankStatementFact::hash($fact)!==BankStatementFact::hash($fact))failTest('fact hash not deterministic');
expectInvalid(fn()=>BankStatementFact::statement([
 'statement_public_id'=>'bad','account_public_id'=>'acct-bank','currency'=>'AUD','period_start'=>'2026-08-01','period_end'=>'2026-08-02','opening_balance_minor'=>0,'closing_balance_minor'=>100,'source_event_id'=>'evt',
 'transactions'=>[['transaction_public_id'=>'x','posted_at'=>'2026-08-01','amount_minor'=>50]],
]),'does not reconcile');
expectInvalid(fn()=>BankStatementFact::statement([
 'statement_public_id'=>'missing-date','account_public_id'=>'acct-bank','currency'=>'AUD','period_start'=>'','period_end'=>'2026-08-02','opening_balance_minor'=>0,'closing_balance_minor'=>0,'source_event_id'=>'evt-date','transactions'=>[],
]),'period_start');
expectInvalid(fn()=>BankStatementFact::statement([
 'statement_public_id'=>'dup','account_public_id'=>'acct-bank','currency'=>'AUD','period_start'=>'2026-08-01','period_end'=>'2026-08-02','opening_balance_minor'=>0,'closing_balance_minor'=>100,'source_event_id'=>'evt2',
 'transactions'=>[['transaction_public_id'=>'x','posted_at'=>'2026-08-01','amount_minor'=>50],['transaction_public_id'=>'x','posted_at'=>'2026-08-02','amount_minor'=>50]],
]),'unique');
expectInvalid(fn()=>BankStatementFact::statement([
 'statement_public_id'=>'bad-class','account_public_id'=>'acct-bank','currency'=>'AUD','period_start'=>'2026-08-01','period_end'=>'2026-08-01','opening_balance_minor'=>0,'closing_balance_minor'=>100,'source_event_id'=>'evt-class',
 'transactions'=>[['transaction_public_id'=>'class-x','posted_at'=>'2026-08-01','amount_minor'=>100,'classification_hint'=>'mystery']],
]),'classification_hint');
echo "Bank statement fact: PASS\n";
