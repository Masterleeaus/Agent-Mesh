<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Domains/Reconciliation/ReconciliationMatcher.php';

use App\Extensions\TitanLedger\System\Domains\Reconciliation\ReconciliationMatcher;

function failMatch(string $m): never { fwrite(STDERR,"FAIL: $m\n"); exit(1); }
$tx=['transaction_public_id'=>'bank-1','posted_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>hash('sha256','pay-1')];
$candidates=[
 ['candidate_public_id'=>'ledger-a','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>hash('sha256','pay-1'),'source_type'=>'payment'],
 ['candidate_public_id'=>'ledger-b','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>hash('sha256','different'),'source_type'=>'payment'],
];
$r=ReconciliationMatcher::match($tx,$candidates);
if($r['status']!=='suggested'||$r['candidate_public_id']!=='ledger-a'||$r['score']!==130)failMatch('exact reference candidate not selected');
$amb=ReconciliationMatcher::match($tx,[
 ['candidate_public_id'=>'a','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>null,'source_type'=>'journal'],
 ['candidate_public_id'=>'b','occurred_on'=>'2026-08-10','amount_minor'=>10000,'reference_hash'=>null,'source_type'=>'journal'],
]);
if($amb['status']!=='ambiguous'||count($amb['candidate_public_ids'])!==2)failMatch('tie must be ambiguous');
$none=ReconciliationMatcher::match($tx,[['candidate_public_id'=>'x','occurred_on'=>'2026-08-10','amount_minor'=>9999,'reference_hash'=>hash('sha256','pay-1'),'source_type'=>'payment']]);
if($none['status']!=='unmatched')failMatch('different amount must not match');
echo "Reconciliation matcher: PASS\n";
