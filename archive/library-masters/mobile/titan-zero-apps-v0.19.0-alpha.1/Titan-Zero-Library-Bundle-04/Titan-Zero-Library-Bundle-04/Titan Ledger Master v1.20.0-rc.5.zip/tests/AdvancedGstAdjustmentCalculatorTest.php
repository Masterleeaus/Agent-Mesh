<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Tax/GstBasCalculator.php';
require_once __DIR__.'/../System/Domains/Tax/GstAdjustmentCalculator.php';
use App\Extensions\TitanLedger\System\Domains\Tax\GstBasCalculator;
use App\Extensions\TitanLedger\System\Domains\Tax\GstAdjustmentCalculator;

$base=GstBasCalculator::calculate(
 [['document_type'=>'invoice','currency'=>'AUD','total_minor'=>110000,'tax_minor'=>10000,'fact_hash'=>str_repeat('a',64)]],
 [['posting_type'=>'supplier_bill','currency'=>'AUD','total_minor'=>55000,'gst_minor'=>5000,'fact_hash'=>str_repeat('b',64)]]
);
$adjustments=[
 ['adjustment_type'=>'bad_debt_writeoff','review_status'=>'approved','gross_amount_minor'=>11000,'gst_amount_minor'=>1000,'fact_hash'=>str_repeat('c',64)],
 ['adjustment_type'=>'mixed_acquisition','review_status'=>'approved','gst_amount_minor'=>1000,'claimable_percent_bps'=>5000,'fact_hash'=>str_repeat('d',64)],
 ['adjustment_type'=>'export_sales_classification','review_status'=>'approved','gross_amount_minor'=>20000,'fact_hash'=>str_repeat('e',64)],
 ['adjustment_type'=>'capital_purchase_classification','review_status'=>'approved','gross_amount_minor'=>15000,'fact_hash'=>str_repeat('f',64)],
 ['adjustment_type'=>'noncapital_purchase_classification','review_status'=>'approved','gross_amount_minor'=>40000,'fact_hash'=>str_repeat('1',64)],
];
$r=GstAdjustmentCalculator::apply($base,$adjustments,'full_bas');
$expect=['g1_total_sales_minor'=>99000,'one_a_gst_on_sales_minor'=>9000,'one_b_gst_on_purchases_minor'=>4500,'g2_export_sales_minor'=>20000,'g10_capital_purchases_minor'=>15000,'g11_noncapital_purchases_minor'=>40000,'net_gst_payable_minor'=>4500,'approved_adjustment_count'=>5,'pending_adjustment_count'=>0];
foreach($expect as $k=>$v)if(($r[$k]??null)!==$v){fwrite(STDERR,"$k expected $v got ".var_export($r[$k]??null,true)."\n");exit(1);}
if(($r['lodgement_ready']??null)!==true){fwrite(STDERR,"Expected complete full BAS evidence to be lodgement-ready\n");exit(1);}
$pending=GstAdjustmentCalculator::apply($base,[['adjustment_type'=>'other_gst_adjustment','review_status'=>'pending','one_a_delta_minor'=>100,'fact_hash'=>str_repeat('2',64)]],'simpler_bas');
if(($pending['lodgement_ready']??true)!==false||!in_array('pending_gst_adjustments_require_review',$pending['review_reasons']??[],true)){fwrite(STDERR,"Pending adjustment must block finalization\n");exit(1);}
echo "Advanced GST adjustment calculator: PASS\n";
