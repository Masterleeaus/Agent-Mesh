<?php

declare(strict_types=1);
$src=(string)file_get_contents(dirname(__DIR__).'/System/Domains/Reporting/FinancialStatementService.php');
$errors=[];
if(!str_contains($src,'aggregateRows($companyId, $from, $to, $currency, true)'))$errors[]='profit and loss does not request close-mechanics exclusion';
if(!str_contains($src,"whereNotIn('j.journal_type',['year_end_close','year_end_reopen'])"))$errors[]='aggregate rows does not exclude close/reopen mechanics';
if(!str_contains($src,"whereNotIn('journal_type',['year_end_close','year_end_reopen'])"))$errors[]='report source fingerprint does not exclude close/reopen mechanics';
if(!str_contains($src,"'historical_period_profit_minor'=>\$historicalProfit"))$errors[]='retained earnings roll-forward does not retain historical period profit';
if(!str_contains($src,'$earningsClosed ? 0 : $historicalProfit'))$errors[]='closed earnings are double-counted in retained-earnings roll-forward';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Fiscal-close reporting continuity: PASS\n";
