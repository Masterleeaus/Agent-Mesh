<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Reconciliation/AdvancedReconciliationMatcher.php',
 'System/Domains/Reconciliation/BankStatementDuplicatePolicy.php',
 'System/Domains/Reconciliation/TransferRecognition.php',
 'System/Domains/Reconciliation/ReconciliationAdjustmentJournalMapper.php',
 'System/Domains/Reconciliation/ReconciliationAdjustmentService.php',
 'database/migrations/2026_08_21_000020_create_titan_ledger_advanced_reconciliation.php',
 'resources/banking/advanced-reconciliation-contract.v1.json',
] as $p) if(!is_file($root.'/'.$p))$errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.bank.reconciliation.group_match','ledger.bank.reconciliation.group_reject','ledger.bank.reconciliation.adjustment.post'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';
foreach(['ledger.bank.reconciliation.group_matched','ledger.bank.reconciliation.group_rejected','ledger.bank.reconciliation.adjustment_posted'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$svc=@file_get_contents($root.'/System/Domains/Reconciliation/BankReconciliationService.php')?:'';
foreach(['matchGroup','rejectGroup','statement_fingerprint','titan_ledger_reconciliation_active_members'] as $needle)if(!str_contains($svc,$needle))$errors[]='reconciliation service missing '.$needle;
if(str_contains($svc,'postAuthoritativeSourceJournal'))$errors[]='bank reconciliation evidence service must not post journals directly';
$fact=@file_get_contents($root.'/System/Integrations/Banking/BankStatementFact.php')?:'';
foreach(['classification_hint','bank_fee','interest_income','interest_expense','transfer'] as $needle)if(!str_contains($fact,$needle))$errors[]='bank statement fact missing bounded classifier '.$needle;
$mig=@file_get_contents($root.'/database/migrations/2026_08_21_000020_create_titan_ledger_advanced_reconciliation.php')?:'';
foreach(['statement_fingerprint','classification_hint','titan_ledger_reconciliation_groups','titan_ledger_reconciliation_group_events','titan_ledger_reconciliation_group_bank_members','titan_ledger_reconciliation_group_ledger_members','titan_ledger_reconciliation_active_members'] as $needle)if(!str_contains($mig,$needle))$errors[]='advanced reconciliation migration missing '.$needle;
if(!str_contains($mig,'Deliberately non-destructive')&&!str_contains($mig,'deliberately non-destructive'))$errors[]='advanced reconciliation down() must be retained/non-destructive';
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';if(!str_contains($provider,'titan.ledger.advanced-reconciliation.v1'))$errors[]='advanced reconciliation public binding missing';
$cert=@file_get_contents($root.'/System/Certification/LedgerProductionCertificationService.php')?:'';foreach(['statement_fingerprint','classification_hint','advanced_reconciliation_schema'] as $n)if(!str_contains($cert,$n))$errors[]='production certification missing '.$n;
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';foreach(['Reconciliation Automation','Advanced Reconciliation'] as $n)if(!str_contains($nav,$n))$errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);if(version_compare((string)($ext['version']??'0'),'1.20.0-rc.5','<'))$errors[]='version not advanced to Step 5';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['upgrade']['pass']??0)<5)$errors[]='new-plan step not advanced';if(($rich['command_bus']['command_count']??0)<50)$errors[]='command count not advanced';if(($rich['signal']['event_count']??0)<50)$errors[]='event count not advanced';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Step 5 advanced reconciliation source contract: PASS\n";
