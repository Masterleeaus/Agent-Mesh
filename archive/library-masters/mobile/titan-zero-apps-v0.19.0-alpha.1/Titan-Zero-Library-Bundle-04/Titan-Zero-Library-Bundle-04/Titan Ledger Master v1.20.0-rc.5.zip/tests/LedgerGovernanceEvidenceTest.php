<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Governance/LedgerGovernanceEvidenceBuilder.php';
require_once __DIR__ . '/../System/Governance/LedgerExternalDecisionNormalizer.php';

use App\Extensions\TitanLedger\System\Governance\LedgerGovernanceEvidenceBuilder;
use App\Extensions\TitanLedger\System\Governance\LedgerExternalDecisionNormalizer;

$command = [
    'command_id' => 'cmd-1',
    'command_name' => 'ledger.journal.post',
    'command_version' => 1,
    'company_id' => 9,
    'actor_user_id' => 4,
    'caller_extension' => 'crm',
    'target_public_id' => 'journal-1',
    'governance_reference' => 'gov-1',
    'trace_id' => 'trace-1',
    'correlation_id' => 'corr-1',
    'causation_id' => 'cause-1',
    'payload' => [
        'operation_id' => 'cmd-1',
        'memo' => 'PRIVATE MEMO MUST NOT LEAK',
        'metadata' => ['secret_note' => 'NOPE'],
        'lines' => [
            ['account_public_id'=>'a','debit_minor'=>1000,'credit_minor'=>0],
            ['account_public_id'=>'b','debit_minor'=>0,'credit_minor'=>1000],
        ],
    ],
];

$evidence = LedgerGovernanceEvidenceBuilder::build($command);
if (($evidence['company_id'] ?? null) !== 9 || ($evidence['command_name'] ?? null) !== 'ledger.journal.post') throw new RuntimeException('Bounded governance identity missing.');
if (($evidence['controls']['tenant_boundary'] ?? null) !== 'company_id') throw new RuntimeException('Canonical tenant control missing.');
if (($evidence['controls']['double_entry'] ?? null) !== true || ($evidence['controls']['period_lock'] ?? null) !== true) throw new RuntimeException('Journal controls missing.');
$encoded = json_encode($evidence, JSON_THROW_ON_ERROR);
if (str_contains($encoded, 'PRIVATE MEMO') || str_contains($encoded, 'secret_note')) throw new RuntimeException('Free-form payload leaked into governance evidence.');

$risk = LedgerExternalDecisionNormalizer::risk(['allowed'=>true,'decision_reference'=>'risk-123','risk_class'=>'HIGH','score'=>0.81,'ruleset_version'=>'risk-v4']);
if ($risk['risk_reference'] !== 'risk-123' || $risk['risk_class'] !== 'HIGH' || abs($risk['risk_score'] - 0.81) > 0.00001) throw new RuntimeException('Risk normalization failed.');

$assurance = LedgerExternalDecisionNormalizer::assurance(['allowed'=>true,'decision_reference'=>'assure-7','assurance_class'=>'PASS','score'=>0.94,'ruleset_version'=>'assure-v2']);
if ($assurance['assurance_reference'] !== 'assure-7' || $assurance['assurance_class'] !== 'PASS') throw new RuntimeException('Assurance normalization failed.');

foreach ([
    fn()=>LedgerExternalDecisionNormalizer::risk(['allowed'=>true,'risk_class'=>'LOW']),
    fn()=>LedgerExternalDecisionNormalizer::risk(['allowed'=>false,'decision_reference'=>'risk-deny','risk_class'=>'CRITICAL']),
    fn()=>LedgerExternalDecisionNormalizer::assurance(['allowed'=>false,'decision_reference'=>'assure-deny','assurance_class'=>'BLOCK']),
] as $bad) {
    try { $bad(); throw new RuntimeException('Invalid/denied external decision was accepted.'); } catch (InvalidArgumentException) {}
}

echo "Ledger governance evidence/decision contract: PASS\n";
