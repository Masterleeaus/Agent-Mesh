<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Accounting/YearEndCloseCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Accounting\YearEndCloseCalculator;

$calc = new YearEndCloseCalculator();
$rows = [
    ['public_id'=>'rev-sales','code'=>'4000','name'=>'Sales Revenue','type'=>'revenue','debit_minor'=>5000,'credit_minor'=>105000],
    ['public_id'=>'rev-other','code'=>'8000','name'=>'Interest Income','type'=>'other_income','debit_minor'=>0,'credit_minor'=>10000],
    ['public_id'=>'cos','code'=>'5000','name'=>'Cost of Sales','type'=>'cost_of_sales','debit_minor'=>40000,'credit_minor'=>2000],
    ['public_id'=>'exp','code'=>'6000','name'=>'Wages','type'=>'expense','debit_minor'=>30000,'credit_minor'=>0],
    ['public_id'=>'other-exp','code'=>'9000','name'=>'Interest Expense','type'=>'other_expense','debit_minor'=>5000,'credit_minor'=>0],
    ['public_id'=>'asset','code'=>'1000','name'=>'Bank','type'=>'asset','debit_minor'=>50000,'credit_minor'=>5000],
];
$result = $calc->build($rows, 'retained');
if ($result['net_profit_minor'] !== 37000) { fwrite(STDERR, "FAIL net profit\n"); exit(1); }
if ($result['debit_total_minor'] !== 110000 || $result['credit_total_minor'] !== 110000) { fwrite(STDERR, "FAIL close balance\n"); exit(1); }
if (count($result['lines']) !== 6) { fwrite(STDERR, "FAIL close lines\n"); exit(1); }
$last = $result['lines'][5];
if ($last['account_public_id'] !== 'retained' || $last['debit_minor'] !== 0 || $last['credit_minor'] !== 37000) { fwrite(STDERR, "FAIL retained earnings profit line\n"); exit(1); }
foreach ($result['lines'] as $line) {
    if ($line['account_public_id'] === 'asset') { fwrite(STDERR, "FAIL permanent account included\n"); exit(1); }
}

$loss = $calc->build([
    ['public_id'=>'rev','code'=>'4000','name'=>'Revenue','type'=>'revenue','debit_minor'=>0,'credit_minor'=>10000],
    ['public_id'=>'exp','code'=>'6000','name'=>'Expense','type'=>'expense','debit_minor'=>25000,'credit_minor'=>0],
], 'retained');
if ($loss['net_profit_minor'] !== -15000) { fwrite(STDERR, "FAIL loss amount\n"); exit(1); }
$last = $loss['lines'][2];
if ($last['debit_minor'] !== 15000 || $last['credit_minor'] !== 0) { fwrite(STDERR, "FAIL retained earnings loss line\n"); exit(1); }

echo "Year-end close calculator: PASS\n";
