<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Tax/AustralianGstTreatmentCatalog.php';
use App\Extensions\TitanLedger\System\Domains\Tax\AustralianGstTreatmentCatalog;

$all=AustralianGstTreatmentCatalog::all();
$expected=['gst_on_sales','gst_on_purchases','gst_free','input_taxed','bas_excluded'];
foreach($expected as $code){if(!isset($all[$code])){fwrite(STDERR,"Missing GST code: $code\n");exit(1);}}
if(($all['gst_on_sales']['default_rate_bps']??null)!==1000){fwrite(STDERR,"GST sales rate must be 10%\n");exit(1);}
if(($all['gst_on_purchases']['bas_label']??null)!=='1B'){fwrite(STDERR,"GST purchases must map to 1B\n");exit(1);}
if(($all['input_taxed']['claimable']??null)!==false){fwrite(STDERR,"Input taxed must not be claimable\n");exit(1);}
echo "Australian GST treatment catalog: PASS\n";
