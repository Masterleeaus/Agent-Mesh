<?php

declare(strict_types=1);

$root=dirname(__DIR__); $errors=[];
$required=[
 'System/Integrations/Crm/CrmInvoiceFact.php',
 'System/Integrations/Crm/CrmInvoiceJournalMapper.php',
 'System/Integrations/Crm/CrmInvoiceAccountingService.php',
 'System/Integrations/Crm/CrmInvoiceAccountingPort.php',
 'database/migrations/2026_08_20_000008_create_titan_ledger_crm_invoice_postings.php',
 'resources/crm/invoice-accounting-contract.v1.json'
];
foreach($required as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.crm.invoice.post','ledger.crm.credit_note.post'] as $n) if(!str_contains($defs,$n)) $errors[]='command missing '.$n;
$adapter=@file_get_contents($root.'/System/CommandBus/LedgerCommandAdapter.php')?:'';
foreach(['CrmInvoiceAccountingService','ledger.crm.invoice.post','ledger.crm.credit_note.post'] as $n) if(!str_contains($adapter,$n)) $errors[]='adapter missing '.$n;
$journal=@file_get_contents($root.'/System/Domains/Accounting/JournalService.php')?:'';
if(!str_contains($journal,'postAuthoritativeSourceJournal')) $errors[]='journal source-posting primitive missing';
$report=@file_get_contents($root.'/System/Domains/Bookkeeping/BookkeepingReportService.php')?:'';
foreach(['crm_payment_allocations','crm_payments','crm_invoices','crm_pay_refunds'] as $n) if(str_contains($report,$n)) $errors[]='direct CRM table coupling remains '.$n;
$migration=@file_get_contents($root.'/database/migrations/2026_08_20_000008_create_titan_ledger_crm_invoice_postings.php')?:'';
foreach(['recordOwnership','ownership_mode','assertShape'] as $n) if(!str_contains($migration,$n)) $errors[]='posting migration adoption safety missing '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';
foreach(['titan.ledger.crm-invoice-accounting.v1','CrmInvoiceAccountingPort'] as $n) if(!str_contains($provider,$n)) $errors[]='provider missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);
if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<8) $errors[]='extension pass not advanced to 8';
if(version_compare((string)($ext['version']??'0'),'1.8.0-alpha.9','<')) $errors[]='extension version predates Pass 8';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);} echo "Pass 8 source contract: PASS\n";
