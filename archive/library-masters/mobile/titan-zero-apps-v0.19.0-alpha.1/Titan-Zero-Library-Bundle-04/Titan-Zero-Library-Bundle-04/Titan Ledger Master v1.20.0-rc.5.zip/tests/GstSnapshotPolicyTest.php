<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Tax/GstSnapshotPolicy.php';
use App\Extensions\TitanLedger\System\Domains\Tax\GstSnapshotPolicy;

$p=new GstSnapshotPolicy();
$p->assertPrepareAllowed('simpler_bas','accrual','2026-07-01','2026-09-30');
$p->assertPrepareAllowed('full_bas','accrual','2026-07-01','2026-09-30');
foreach([['invalid','accrual'],['simpler_bas','cash']] as [$m,$b]){try{$p->assertPrepareAllowed($m,$b,'2026-07-01','2026-09-30');fwrite(STDERR,"Unsupported method/basis accepted\n");exit(1);}catch(InvalidArgumentException){}}
try{$p->assertPrepareAllowed('simpler_bas','accrual','2026-09-30','2026-07-01');fwrite(STDERR,"Reversed period accepted\n");exit(1);}catch(InvalidArgumentException){}
$p->assertFinalizeAllowed(['status'=>'prepared','lodgement_ready'=>1],str_repeat('a',64),str_repeat('a',64));
try{$p->assertFinalizeAllowed(['status'=>'prepared','lodgement_ready'=>0],str_repeat('a',64),str_repeat('a',64));fwrite(STDERR,"Review-required snapshot finalized\n");exit(1);}catch(InvalidArgumentException){}
try{$p->assertFinalizeAllowed(['status'=>'prepared','lodgement_ready'=>1],str_repeat('a',64),str_repeat('b',64));fwrite(STDERR,"Drifted snapshot finalized\n");exit(1);}catch(InvalidArgumentException){}
echo "GST snapshot policy: PASS\n";
