<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Navigation/TitanLedgerNavigation.php';

use App\Extensions\TitanLedger\System\Navigation\TitanLedgerNavigation;

$user = TitanLedgerNavigation::user();
$admin = TitanLedgerNavigation::admin();

$expectedUserRoutes = [
    'dashboard.user.titan-ledger.overview',
    'dashboard.user.titan-ledger.bookkeeping',
    'dashboard.user.titan-ledger.accounts',
    'dashboard.user.titan-ledger.journals',
    'dashboard.user.titan-ledger.financial-years',
    'dashboard.user.titan-ledger.year-end-close',
    'dashboard.user.titan-ledger.accounting-periods',
    'dashboard.user.titan-ledger.command-receipts',
    'dashboard.user.titan-ledger.financial-events',
    'dashboard.user.titan-ledger.governance-evidence',
    'dashboard.user.titan-ledger.invoice-accounting',
    'dashboard.user.titan-ledger.payment-settlements',
    'dashboard.user.titan-ledger.receivables',
    'dashboard.user.titan-ledger.payables',
    'dashboard.user.titan-ledger.bank-reconciliation',
    'dashboard.user.titan-ledger.banking-accounts',
    'dashboard.user.titan-ledger.reconciliation-automation',
    'dashboard.user.titan-ledger.gst-bas',
    'dashboard.user.titan-ledger.gst-adjustments',
    'dashboard.user.titan-ledger.financial-reports',
    'dashboard.user.titan-ledger.cashflow-forecasts',
    'dashboard.user.titan-ledger.diagnostics',
];
$expectedAdminRoutes = [
    'dashboard.admin.titan-ledger.overview',
    'dashboard.admin.titan-ledger.command-authority',
    'dashboard.admin.titan-ledger.signal-fabric',
    'dashboard.admin.titan-ledger.risk-assurance',
    'dashboard.admin.titan-ledger.rewind-integration',
    'dashboard.admin.titan-ledger.crm-invoice-adapter',
    'dashboard.admin.titan-ledger.titan-pay-adapter',
    'dashboard.admin.titan-ledger.ar-collections',
    'dashboard.admin.titan-ledger.ap-spend-adapter',
    'dashboard.admin.titan-ledger.banking-reconciliation',
    'dashboard.admin.titan-ledger.multi-account-banking',
    'dashboard.admin.titan-ledger.advanced-reconciliation',
    'dashboard.admin.titan-ledger.gst-tax-ledger',
    'dashboard.admin.titan-ledger.advanced-gst-control',
    'dashboard.admin.titan-ledger.financial-reporting',
    'dashboard.admin.titan-ledger.forecasting-profitability',
    'dashboard.admin.titan-ledger.fiscal-close-control',
    'dashboard.admin.titan-ledger.production-certification',
    'dashboard.admin.titan-ledger.menu-diagnostics',
    'dashboard.admin.titan-ledger.system-diagnostics',
];

foreach ([['user', $user, $expectedUserRoutes], ['admin', $admin, $expectedAdminRoutes]] as [$surface, $tree, $routes]) {
    if (($tree['key'] ?? '') !== 'titan_ledger_' . ($surface === 'user' ? 'parent' : 'admin_parent')) {
        fwrite(STDERR, "Invalid {$surface} parent key\n"); exit(1);
    }
    $children = $tree['children'] ?? [];
    $actualRoutes = array_column($children, 'route');
    if ($actualRoutes !== $routes) { fwrite(STDERR, "{$surface} routes differ from contract\n"); exit(1); }
    foreach ($children as $item) {
        if (str_contains((string)($item['label'] ?? ''), '&')) { fwrite(STDERR, "Ampersand found in menu label\n"); exit(1); }
        if (empty($item['key']) || empty($item['route']) || empty($item['label'])) { fwrite(STDERR, "Incomplete {$surface} menu definition\n"); exit(1); }
    }
}

echo "Titan Ledger navigation contract: PASS (22 user + 20 admin children)\n";
