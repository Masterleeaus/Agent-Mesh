<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$errors = [];
$required = [
    'System/Signal/LedgerFinancialEventCatalog.php',
    'System/Signal/LedgerSignalEnvelope.php',
    'System/Signal/LedgerSignalOutboxService.php',
    'System/Signal/LedgerSignalGatewayContract.php',
    'System/Signal/HostLedgerSignalGateway.php',
    'System/Signal/UnavailableLedgerSignalGateway.php',
    'System/Console/DrainLedgerSignalsCommand.php',
    'database/migrations/2026_08_20_000006_create_titan_ledger_signal_outbox.php',
];
foreach ($required as $path) if (!is_file($root . '/' . $path)) $errors[] = 'missing ' . $path;

if (is_file($root . '/System/CommandBus/LedgerCommandAdapter.php')) {
    $adapter = file_get_contents($root . '/System/CommandBus/LedgerCommandAdapter.php');
    foreach (['LedgerSignalOutboxService', 'recordApplied', 'domain_receipt_reference'] as $needle) if (!str_contains($adapter, $needle)) $errors[] = 'command adapter missing Signal outbox integration: ' . $needle;
}

if (is_file($root . '/database/migrations/2026_08_20_000006_create_titan_ledger_signal_outbox.php')) {
    $migration = file_get_contents($root . '/database/migrations/2026_08_20_000006_create_titan_ledger_signal_outbox.php');
    foreach (['titan_ledger_signal_outbox','signal_id','event_type','payload_hash','trace_id','correlation_id','causation_id','domain_receipt_reference','attempt_count','next_attempt_at','delivered_at'] as $needle) if (!str_contains($migration, $needle)) $errors[] = 'signal migration missing ' . $needle;
    if (!str_contains($migration, 'unique')) $errors[] = 'signal outbox lacks uniqueness/idempotency constraint';
}

$provider = is_file($root . '/System/TitanLedgerServiceProvider.php') ? file_get_contents($root . '/System/TitanLedgerServiceProvider.php') : '';
foreach (['LedgerSignalGatewayContract','HostLedgerSignalGateway','DrainLedgerSignalsCommand'] as $needle) if (!str_contains($provider, $needle)) $errors[] = 'provider missing Signal integration: ' . $needle;

$ext = json_decode((string)file_get_contents($root . '/extension.json'), true);
if (($ext['cumulative_pass'] ?? ($ext['upgrade']['pass'] ?? 0)) < 6) $errors[] = 'extension upgrade pass not advanced to 6';
if (version_compare((string)($ext['version'] ?? '0'), '1.6.0-alpha.7', '<')) $errors[] = 'extension version predates Pass 6';

if ($errors) { foreach ($errors as $e) fwrite(STDERR, "FAIL: {$e}\n"); exit(1); }
echo "Pass 6 source contract: PASS\n";
