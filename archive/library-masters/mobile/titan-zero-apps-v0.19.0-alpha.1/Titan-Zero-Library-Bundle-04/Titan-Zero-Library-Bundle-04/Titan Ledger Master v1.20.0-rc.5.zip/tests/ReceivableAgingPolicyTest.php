<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Receivables/ReceivableAgingPolicy.php';

use App\Extensions\TitanLedger\System\Domains\Receivables\ReceivableAgingPolicy;

$asOf = '2026-08-20';
$cases = [
    ['due'=>'2026-08-25','outstanding'=>100,'bucket'=>'current','days'=>0,'overdue'=>false],
    ['due'=>'2026-08-20','outstanding'=>100,'bucket'=>'current','days'=>0,'overdue'=>false],
    ['due'=>'2026-08-19','outstanding'=>100,'bucket'=>'1_30','days'=>1,'overdue'=>true],
    ['due'=>'2026-07-20','outstanding'=>100,'bucket'=>'31_60','days'=>31,'overdue'=>true],
    ['due'=>'2026-06-20','outstanding'=>100,'bucket'=>'61_90','days'=>61,'overdue'=>true],
    ['due'=>'2026-05-20','outstanding'=>100,'bucket'=>'91_plus','days'=>92,'overdue'=>true],
    ['due'=>null,'outstanding'=>100,'bucket'=>'unknown_due_date','days'=>null,'overdue'=>false],
    ['due'=>'2026-01-01','outstanding'=>0,'bucket'=>'settled','days'=>0,'overdue'=>false],
];
foreach ($cases as $i => $case) {
    $result = ReceivableAgingPolicy::classify($case['due'], $asOf, $case['outstanding']);
    foreach (['bucket','days_past_due','is_overdue'] as $key) {
        $expected = $key === 'bucket' ? $case['bucket'] : ($key === 'days_past_due' ? $case['days'] : $case['overdue']);
        if ($result[$key] !== $expected) { fwrite(STDERR, "Aging case {$i} {$key} mismatch\n"); exit(1); }
    }
}

echo "Receivable aging policy: PASS\n";
