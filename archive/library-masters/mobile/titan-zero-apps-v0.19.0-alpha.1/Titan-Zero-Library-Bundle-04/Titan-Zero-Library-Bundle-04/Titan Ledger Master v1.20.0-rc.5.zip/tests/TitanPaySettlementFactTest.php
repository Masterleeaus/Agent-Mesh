<?php

declare(strict_types=1);

$root=dirname(__DIR__);
require_once $root.'/System/Integrations/TitanPay/TitanPaySettlementFact.php';

use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementFact;

$errors=[];
try {
    $fact=TitanPaySettlementFact::payment([
        'payment_public_id'=>'PAY-1','invoice_public_id'=>'INV-1','rail'=>'stripe',
        'gross_amount_minor'=>11000,'fee_minor'=>350,'net_amount_minor'=>10650,
        'currency'=>'aud','settled_at'=>'2026-08-20T08:00:00+10:00','source_event_id'=>'pay.evt.1','source_version'=>2,'funds_account_public_id'=>'01M0CLEARINGACCOUNT1234567',
    ]);
    if($fact['rail']!=='stripe'||$fact['currency']!=='AUD'||$fact['gross_amount_minor']!==11000||$fact['fee_minor']!==350||$fact['net_amount_minor']!==10650||$fact['funds_account_public_id']!=='01M0CLEARINGACCOUNT1234567') $errors[]='payment fact normalization failed';
    $free=TitanPaySettlementFact::payment([
        'payment_public_id'=>'PAY-2','invoice_public_id'=>'INV-1','rail'=>'payid',
        'gross_amount_minor'=>5000,'fee_minor'=>0,'net_amount_minor'=>5000,
        'currency'=>'AUD','settled_at'=>'2026-08-20 09:00:00','source_event_id'=>'pay.evt.2',
    ]);
    if($free['rail']!=='payid') $errors[]='PayID fact failed';
    try { TitanPaySettlementFact::payment([
        'payment_public_id'=>'PAY-BAD','invoice_public_id'=>'INV-1','rail'=>'cash',
        'gross_amount_minor'=>1000,'fee_minor'=>1,'net_amount_minor'=>999,
        'currency'=>'AUD','settled_at'=>'2026-08-20','source_event_id'=>'bad.1',
    ]); $errors[]='cash fee was accepted'; } catch (InvalidArgumentException) {}
    try { TitanPaySettlementFact::payment([
        'payment_public_id'=>'PAY-BAD2','invoice_public_id'=>'INV-1','rail'=>'paypal',
        'gross_amount_minor'=>1000,'fee_minor'=>50,'net_amount_minor'=>1000,
        'currency'=>'AUD','settled_at'=>'2026-08-20','source_event_id'=>'bad.2',
    ]); $errors[]='invalid gross/fee/net arithmetic accepted'; } catch (InvalidArgumentException) {}
    $refund=TitanPaySettlementFact::refund([
        'refund_public_id'=>'REF-1','original_payment_public_id'=>'PAY-1','invoice_public_id'=>'INV-1','rail'=>'stripe',
        'refund_amount_minor'=>4000,'refund_fee_minor'=>75,'currency'=>'AUD','settled_at'=>'2026-08-21T10:00:00+10:00','source_event_id'=>'refund.evt.1',
    ]);
    if($refund['refund_amount_minor']!==4000||$refund['refund_fee_minor']!==75||$refund['original_payment_public_id']!=='PAY-1') $errors[]='refund fact normalization failed';
} catch(Throwable $e){$errors[]=$e::class.': '.$e->getMessage();}

if($errors){fwrite(STDERR,"FAIL Titan Pay settlement facts\n - ".implode("\n - ",$errors)."\n");exit(1);} echo "PASS Titan Pay settlement facts\n";
