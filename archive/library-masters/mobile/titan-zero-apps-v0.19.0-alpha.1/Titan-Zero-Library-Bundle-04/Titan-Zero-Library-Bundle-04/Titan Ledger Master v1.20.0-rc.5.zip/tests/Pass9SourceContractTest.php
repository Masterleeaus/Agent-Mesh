<?php

declare(strict_types=1);

$root=dirname(__DIR__); $errors=[];
$required=[
 'System/Integrations/TitanPay/TitanPaySettlementFact.php',
 'System/Integrations/TitanPay/TitanPaySettlementJournalMapper.php',
 'System/Integrations/TitanPay/TitanPaySettlementService.php',
 'System/Integrations/TitanPay/TitanPaySettlementPort.php',
 'database/migrations/2026_08_20_000009_create_titan_ledger_payment_settlements.php',
 'resources/titan-pay/settlement-accounting-contract.v1.json'
];
foreach($required as $p) if(!is_file($root.'/'.$p)) $errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.payment.settlement.post','ledger.payment.refund.post'] as $n) if(!str_contains($defs,$n)) $errors[]='command missing '.$n;
$adapter=@file_get_contents($root.'/System/CommandBus/LedgerCommandAdapter.php')?:'';
foreach(['TitanPaySettlementService','ledger.payment.settlement.post','ledger.payment.refund.post'] as $n) if(!str_contains($adapter,$n)) $errors[]='adapter missing '.$n;
$journal=@file_get_contents($root.'/System/Domains/Accounting/JournalService.php')?:'';
foreach(["'payment'","'refund'"] as $n) if(!str_contains($journal,$n)) $errors[]='authoritative journal type missing '.$n;
$coa=@file_get_contents($root.'/System/Domains/Accounting/ChartOfAccountCatalog.php')?:'';
if(!str_contains($coa,'customer_overpayments')) $errors[]='customer overpayments control account missing';
$report=@file_get_contents($root.'/System/Domains/Bookkeeping/BookkeepingReportService.php')?:'';
if(!str_contains($report,'titan_ledger_payment_settlements')) $errors[]='bookkeeping cash scope not sourced from Ledger settlement evidence';
foreach(['zeropay_transactions','zeropay_sessions','crm_payments','crm_payment_allocations'] as $n) if(str_contains($report,$n)) $errors[]='direct payment-domain table coupling remains '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';
foreach(['titan.ledger.payment-settlement.v1','TitanPaySettlementPort'] as $n) if(!str_contains($provider,$n)) $errors[]='provider missing '.$n;
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';
foreach(['Payment Settlements','Titan Pay Adapter'] as $n) if(!str_contains($nav,$n)) $errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);
if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<9) $errors[]='extension pass not advanced to 9';
if(version_compare(preg_replace('/-.*/','',(string)($ext['version']??'0.0.0')),'1.9.0','<')) $errors[]='artifact version is earlier than Pass 9';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);} echo "Pass 9 source contract: PASS\n";
