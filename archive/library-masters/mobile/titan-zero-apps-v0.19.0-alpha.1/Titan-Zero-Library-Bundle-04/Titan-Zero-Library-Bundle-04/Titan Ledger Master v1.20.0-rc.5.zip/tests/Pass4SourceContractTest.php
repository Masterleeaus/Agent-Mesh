<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$requiredFiles = [
    'System/Domains/Accounting/AccountingPeriodPolicy.php',
    'System/Domains/Accounting/FinancialYearCalendar.php',
    'System/Domains/Accounting/AccountingPeriodService.php',
    'System/Http/Controllers/AccountingPeriodController.php',
    'database/migrations/2026_08_20_000004_create_titan_ledger_financial_periods.php',
    'bin/verify-pass4.php',
];
foreach ($requiredFiles as $file) {
    if (! is_file($root . '/' . $file)) {
        fwrite(STDERR, "Missing Pass 4 file: {$file}\n");
        exit(1);
    }
}

$journal = file_get_contents($root . '/System/Domains/Accounting/JournalService.php');
foreach ([
    'AccountingPeriodService $periods',
    'assertPostingAllowed',
    "'accounting_period_public_id'",
    "'financial_year_public_id'",
    "'prior_period_adjustment'",
    "'period_override_reason'",
] as $needle) {
    if (! str_contains($journal, $needle)) {
        fwrite(STDERR, "JournalService missing Pass 4 contract: {$needle}\n");
        exit(1);
    }
}

$migration = file_get_contents($root . '/database/migrations/2026_08_20_000004_create_titan_ledger_financial_periods.php');
foreach (['titan_ledger_financial_years', 'titan_ledger_accounting_periods', 'titan_ledger_period_lock_events', 'soft_locked', 'hard_locked'] as $needle) {
    if (! str_contains($migration, $needle)) {
        fwrite(STDERR, "Period migration missing contract: {$needle}\n");
        exit(1);
    }
}

$routes = file_get_contents($root . '/routes/api.php');
foreach (['AccountingPeriodController', '/bookkeeping/financial-years', '/bookkeeping/accounting-periods'] as $needle) {
    if (! str_contains($routes, $needle)) {
        fwrite(STDERR, "Routes missing Pass 4 contract: {$needle}\n");
        exit(1);
    }
}

$extension = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
if ((int) ($extension['cumulative_pass'] ?? ($extension['upgrade']['pass'] ?? 0)) < 4) {
    fwrite(STDERR, "extension.json must declare Pass 4.\n");
    exit(1);
}
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach (['ledger.financial_years', 'ledger.accounting_periods', 'ledger.period_locks'] as $capability) {
    if (! in_array($capability, $manifest['capabilities'] ?? [], true)) {
        fwrite(STDERR, "Manifest missing capability {$capability}.\n");
        exit(1);
    }
}

echo "PASS Titan Ledger Pass 4 source contracts\n";
