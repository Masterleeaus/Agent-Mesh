<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Forecasting/ForecastVarianceCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Forecasting\ForecastVarianceCalculator;

$c=new ForecastVarianceCalculator();
$r=$c->compare([
 ['date'=>'2026-08-25','inflow_minor'=>100000,'outflow_minor'=>0],
 ['date'=>'2026-08-28','inflow_minor'=>0,'outflow_minor'=>40000],
 ['date'=>'2026-09-10','inflow_minor'=>50000,'outflow_minor'=>10000],
], '2026-08-30', ['inflow_minor'=>90000,'outflow_minor'=>45000,'net_cashflow_minor'=>45000]);
if($r['expected_inflows_minor']!==100000||$r['expected_outflows_minor']!==40000){fwrite(STDERR,"FAIL: expected through-date flow wrong\n");exit(1);}
if($r['inflow_variance_minor']!==-10000||$r['outflow_variance_minor']!==5000||$r['net_cashflow_variance_minor']!==-15000){fwrite(STDERR,"FAIL: forecast vs actual variance wrong\n");exit(1);}
echo "Forecast variance calculator: PASS\n";
