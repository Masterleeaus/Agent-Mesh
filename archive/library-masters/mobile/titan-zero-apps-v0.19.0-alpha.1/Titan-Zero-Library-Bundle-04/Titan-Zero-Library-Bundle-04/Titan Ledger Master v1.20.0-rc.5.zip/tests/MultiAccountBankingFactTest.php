<?php

declare(strict_types=1);
$root=dirname(__DIR__);require_once $root.'/System/Domains/Banking/MultiAccountBankingFact.php';
use App\Extensions\TitanLedger\System\Domains\Banking\MultiAccountBankingFact;
$errors=[];
try{$fact=MultiAccountBankingFact::transfer(['movement_public_id'=>'MOVE-1','source_account_public_id'=>'BANK-A','destination_account_public_id'=>'BANK-B','currency'=>'aud','amount_minor'=>10000,'fee_minor'=>100,'occurred_at'=>'2026-08-21T10:00:00+10:00','source_event_id'=>'evt.move.1','reference'=>' Payout  ABC 123 ']);if($fact['currency']!=='AUD'||$fact['amount_minor']!==10000||strlen((string)$fact['reference_hash'])!==64)$errors[]='transfer fact normalization failed';}catch(Throwable $e){$errors[]=$e->getMessage();}
try{MultiAccountBankingFact::transfer(['movement_public_id'=>'MOVE-2','source_account_public_id'=>'BANK-A','destination_account_public_id'=>'BANK-B','currency'=>'AUD','amount_minor'=>100,'fee_minor'=>0,'occurred_at'=>'','source_event_id'=>'evt.move.2']);$errors[]='empty occurred_at accepted';}catch(InvalidArgumentException){}
if($errors){fwrite(STDERR,"FAIL multi-account banking fact\n - ".implode("\n - ",$errors)."\n");exit(1);}echo "PASS multi-account banking fact\n";
