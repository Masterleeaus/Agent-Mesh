<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Payables/PayableAgingPolicy.php';
use App\Extensions\TitanLedger\System\Domains\Payables\PayableAgingPolicy;
if(PayableAgingPolicy::classify('2026-08-20','2026-08-20',100)!==['bucket'=>'current','days_past_due'=>0,'is_overdue'=>false]) exit(1);
if(PayableAgingPolicy::classify('2026-07-01','2026-08-20',100)['bucket']!=='31-60') exit(1);
if(PayableAgingPolicy::classify(null,'2026-08-20',100)['bucket']!=='unknown_due_date') exit(1);
if(PayableAgingPolicy::classify('2026-07-01','2026-08-20',0)['bucket']!=='settled') exit(1);
echo "Payable aging policy: PASS\n";
