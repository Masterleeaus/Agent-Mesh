<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Integrations/Crm/CrmInvoiceFact.php';

use App\Extensions\TitanLedger\System\Integrations\Crm\CrmInvoiceFact;

$issued = CrmInvoiceFact::issued([
    'invoice_public_id' => 'INV01',
    'invoice_number' => 'INV-1001',
    'issued_at' => '2026-08-20T10:00:00+10:00',
    'due_at' => '2026-09-03',
    'currency' => 'aud',
    'subtotal_minor' => 10000,
    'tax_minor' => 1000,
    'total_minor' => 11000,
    'revenue_splits' => [
        ['system_key' => 'service_revenue', 'amount_minor' => 7000],
        ['system_key' => 'sales_revenue', 'amount_minor' => 3000],
    ],
    'source_event_id' => 'crm.invoice.issued:INV01:v3',
    'source_version' => 3,
]);
if ($issued['currency'] !== 'AUD' || $issued['subtotal_minor'] !== 10000 || count($issued['revenue_splits']) !== 2 || ($issued['due_at']??null)!=='2026-09-03') exit(1);
if (array_sum(array_column($issued['revenue_splits'], 'amount_minor')) !== 10000) exit(1);

$credit = CrmInvoiceFact::creditNote([
    'credit_note_public_id' => 'CR01',
    'invoice_public_id' => 'INV01',
    'issued_at' => '2026-08-21',
    'currency' => 'AUD',
    'subtotal_minor' => 2000,
    'tax_minor' => 200,
    'total_minor' => 2200,
    'revenue_splits' => [['system_key' => 'service_revenue', 'amount_minor' => 2000]],
    'source_event_id' => 'crm.credit_note.issued:CR01',
]);
if ($credit['document_public_id'] !== 'CR01' || $credit['invoice_public_id'] !== 'INV01' || $credit['total_minor'] !== 2200) exit(1);

$bad = false;
try { CrmInvoiceFact::issued(['invoice_public_id'=>'X','issued_at'=>'2026-08-20','currency'=>'AUD','subtotal_minor'=>100,'tax_minor'=>10,'total_minor'=>999]); }
catch (InvalidArgumentException) { $bad = true; }
if (!$bad) { fwrite(STDERR, "Expected arithmetic mismatch rejection\n"); exit(1); }

$bad = false;
try { CrmInvoiceFact::issued(['invoice_public_id'=>'X','issued_at'=>'2026-08-20','currency'=>'AUD','subtotal_minor'=>100,'tax_minor'=>10,'total_minor'=>110,'revenue_splits'=>[['system_key'=>'accounts_receivable','amount_minor'=>100]]]); }
catch (InvalidArgumentException) { $bad = true; }
if (!$bad) { fwrite(STDERR, "Expected non-revenue system key rejection\n"); exit(1); }

$bad = false;
try { CrmInvoiceFact::issued(['invoice_public_id'=>'X','issued_at'=>'2026-08-20','due_at'=>'2026-08-19','currency'=>'AUD','subtotal_minor'=>100,'tax_minor'=>10,'total_minor'=>110,'source_event_id'=>'x']); }
catch (InvalidArgumentException) { $bad = true; }
if (!$bad) { fwrite(STDERR, "Expected due date before issue rejection\n"); exit(1); }

echo "CRM invoice fact contract: PASS\n";
