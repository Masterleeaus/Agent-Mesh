<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Domains/Reconciliation/ReconciliationAdjustmentJournalMapper.php';

use App\Extensions\TitanLedger\System\Domains\Reconciliation\ReconciliationAdjustmentJournalMapper;

function failAdj(string $m): never { fwrite(STDERR,"FAIL: $m\n"); exit(1); }
function sumSide(array $lines,string $k): int { return array_sum(array_map(fn($l)=>(int)($l[$k]??0),$lines)); }

$accounts=['bank'=>'BANK','bank_fees'=>'FEE','interest_income'=>'INT-IN','interest_expense'=>'INT-EXP'];
$fee=ReconciliationAdjustmentJournalMapper::map('bank_fee',-1250,$accounts);
if(sumSide($fee,'debit_minor')!==1250||sumSide($fee,'credit_minor')!==1250||$fee[0]['account_public_id']!=='FEE')failAdj('bank fee journal mismatch');
$income=ReconciliationAdjustmentJournalMapper::map('interest_income',875,$accounts);
if(sumSide($income,'debit_minor')!==875||sumSide($income,'credit_minor')!==875||$income[0]['account_public_id']!=='BANK')failAdj('interest income journal mismatch');
$expense=ReconciliationAdjustmentJournalMapper::map('interest_expense',-300,$accounts);
if(sumSide($expense,'debit_minor')!==300||sumSide($expense,'credit_minor')!==300||$expense[0]['account_public_id']!=='INT-EXP')failAdj('interest expense journal mismatch');
try{ReconciliationAdjustmentJournalMapper::map('bank_fee',1250,$accounts);failAdj('positive bank fee must fail');}catch(\InvalidArgumentException $e){}
try{ReconciliationAdjustmentJournalMapper::map('interest_income',-1,$accounts);failAdj('negative interest income must fail');}catch(\InvalidArgumentException $e){}
echo "Reconciliation adjustment mapper: PASS\n";
