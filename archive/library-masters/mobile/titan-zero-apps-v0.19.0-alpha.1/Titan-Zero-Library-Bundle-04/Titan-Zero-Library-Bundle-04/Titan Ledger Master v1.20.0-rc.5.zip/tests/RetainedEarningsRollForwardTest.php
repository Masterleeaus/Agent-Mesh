<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Reporting/FinancialStatementCalculator.php';

use App\Extensions\TitanLedger\System\Domains\Reporting\FinancialStatementCalculator;

$calc = new FinancialStatementCalculator();
$result = $calc->retainedEarningsRollForward(
    openingRetainedEarningsMinor: 125000,
    retainedEarningsMovementsMinor: -10000,
    currentPeriodProfitMinor: 42000,
);

if ($result['opening_retained_earnings_minor'] !== 125000) { fwrite(STDERR, "FAIL opening\n"); exit(1); }
if ($result['retained_earnings_account_movement_minor'] !== -10000) { fwrite(STDERR, "FAIL movement\n"); exit(1); }
if ($result['retained_earnings_account_closing_minor'] !== 115000) { fwrite(STDERR, "FAIL account closing\n"); exit(1); }
if ($result['current_period_profit_minor'] !== 42000) { fwrite(STDERR, "FAIL profit\n"); exit(1); }
if ($result['closing_equity_after_current_profit_minor'] !== 157000) { fwrite(STDERR, "FAIL roll-forward\n"); exit(1); }

echo "Retained earnings roll-forward: PASS\n";
