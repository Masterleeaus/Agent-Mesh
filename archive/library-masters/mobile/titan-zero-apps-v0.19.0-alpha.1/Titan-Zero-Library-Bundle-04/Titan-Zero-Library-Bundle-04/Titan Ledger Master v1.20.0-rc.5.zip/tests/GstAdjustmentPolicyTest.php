<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Tax/GstAdjustmentPolicy.php';
use App\Extensions\TitanLedger\System\Domains\Tax\GstAdjustmentPolicy;
$p=new GstAdjustmentPolicy();
$n=$p->normalizeRecord(['adjustment_type'=>'export_sales_classification','effective_date'=>'2026-08-21','gross_amount_minor'=>10000,'gst_amount_minor'=>0,'claimable_percent_bps'=>0,'reason_code'=>'export.classification']);
if($n['gross_amount_minor']!==10000||$n['journal_public_id']!==null)exit(1);
try{$p->normalizeRecord(['adjustment_type'=>'bad_debt_writeoff','effective_date'=>'2026-08-21','gross_amount_minor'=>11000,'gst_amount_minor'=>1000,'reason_code'=>'bad.debt']);fwrite(STDERR,"financial GST adjustment without journal should fail\n");exit(1);}catch(InvalidArgumentException){}
$r=$p->normalizeReview(['decision'=>'approved','reason_code'=>'accountant.reviewed']);if($r['decision']!=='approved')exit(1);
try{$p->normalizeReview(['decision'=>'maybe','reason_code'=>'x']);exit(1);}catch(InvalidArgumentException){}
echo "GST adjustment policy: PASS\n";
