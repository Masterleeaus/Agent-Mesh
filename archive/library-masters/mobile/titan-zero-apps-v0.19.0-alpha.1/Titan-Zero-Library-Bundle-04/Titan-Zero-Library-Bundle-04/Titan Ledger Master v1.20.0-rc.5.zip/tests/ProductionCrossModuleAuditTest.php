<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];

// Canonical tenant boundary: legacy resolver names are allowed only in the compatibility adapter.
$allowedLegacy=['System/Tenancy/LedgerCompanyContext.php','System/TitanLedgerServiceProvider.php'];
$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System'));
foreach($it as $file){
    if(!$file->isFile()||$file->getExtension()!=='php')continue;
    $rel=str_replace($root.'/','',$file->getPathname());$src=(string)file_get_contents($file->getPathname());
    if(str_contains($src,'company_id'))$errors[]='legacy tenant column used in runtime source '.$rel;
    if(str_contains($src,'companyId')&&!in_array($rel,$allowedLegacy,true))$errors[]='legacy tenant resolver leaked outside compatibility boundary '.$rel;
}

// No direct reads of provider-private finance storage.
$runtime='';foreach($it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System')) as $file){if($file->isFile()&&$file->getExtension()==='php')$runtime.="\n".file_get_contents($file->getPathname());}
foreach(['crm_invoices','crm_payments','crm_payment_allocations','zeropay_transactions','zeropay_sessions','stripe_','paypal_','budget_'] as $needle)if(str_contains(strtolower($runtime),$needle))$errors[]='private external finance storage coupling detected: '.$needle;

// State-changing HTTP actions must not use GET. Read-only resource pages may contain nouns such as "close".
foreach(['routes/web.php','routes/api.php'] as $routeFile){
    $src=(string)file_get_contents($root.'/'.$routeFile);
    foreach(preg_split('/\R/',$src) as $line){
        if(!str_contains($line,'Route::get('))continue;
        $uri='';$action='';
        if(preg_match('/Route::get\(\s*[\'\"]([^\'\"]+)/',$line,$m))$uri=$m[1];
        if(preg_match('/::class,\s*[\'\"]([^\'\"]+)[\'\"]/', $line,$m))$action=$m[1];
        $mutatingAction=(bool)preg_match('/^(store|update|destroy|delete|post|reverse|createCorrection|closeFinancialYear|reopenFinancialYear|transition|execute|setLockState|prepareFinancialYearClose)$/i',$action);
        $mutatingUri=(bool)preg_match('#/(post|reverse|reopen|transition|execute|lock-state)(?:/|$)#i',$uri);
        if($mutatingAction||$mutatingUri)$errors[]='GET mutation route detected '.$routeFile.': '.trim($line);
    }
}

// Authority isolation remains explicit.
$submission=(string)file_get_contents($root.'/System/CommandBus/LedgerCommandSubmissionService.php');foreach(['JournalService','CrmInvoiceAccountingService','TitanPaySettlementService','SpendAccountingService'] as $n)if(str_contains($submission,$n))$errors[]='Command Bus submission directly imports domain writer '.$n;
$forecast=(string)file_get_contents($root.'/System/Domains/Forecasting/ForecastSnapshotService.php');if(str_contains($forecast,'JournalService'))$errors[]='forecast snapshot gained journal authority';

if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Production cross-module audit: PASS\n";
