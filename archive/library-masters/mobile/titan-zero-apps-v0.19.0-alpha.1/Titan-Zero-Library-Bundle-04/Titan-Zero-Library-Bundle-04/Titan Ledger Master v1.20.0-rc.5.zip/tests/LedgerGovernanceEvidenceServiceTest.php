<?php

declare(strict_types=1);

require_once __DIR__.'/../System/Governance/LedgerRiskGatewayContract.php';
require_once __DIR__.'/../System/Governance/LedgerAssuranceGatewayContract.php';
require_once __DIR__.'/../System/Governance/LedgerGovernanceEvidenceBuilder.php';
require_once __DIR__.'/../System/Governance/LedgerExternalDecisionNormalizer.php';
require_once __DIR__.'/../System/Governance/LedgerGovernanceEvidenceService.php';

use App\Extensions\TitanLedger\System\Governance\LedgerRiskGatewayContract;
use App\Extensions\TitanLedger\System\Governance\LedgerAssuranceGatewayContract;
use App\Extensions\TitanLedger\System\Governance\LedgerGovernanceEvidenceService;

final class RiskFake implements LedgerRiskGatewayContract { public int $calls=0; public function __construct(private bool $allow=true){} public function evaluate(array $evidence): array {$this->calls++; return ['allowed'=>$this->allow,'decision_reference'=>'risk-ref','risk_class'=>$this->allow?'HIGH':'CRITICAL','score'=>0.8];} public function available(): bool{return true;} }
final class AssuranceFake implements LedgerAssuranceGatewayContract { public int $calls=0; public function verify(array $evidence): array {$this->calls++; if(($evidence['risk']['risk_reference']??null)!=='risk-ref') throw new RuntimeException('Risk evidence was not forwarded to Assurance.'); return ['allowed'=>true,'decision_reference'=>'assure-ref','assurance_class'=>'PASS','score'=>0.95];} public function available(): bool{return true;} }
$command=['command_id'=>'cmd','command_name'=>'ledger.journal.post','command_version'=>1,'company_id'=>1,'actor_user_id'=>2,'caller_extension'=>'crm','target_public_id'=>'j','governance_reference'=>'gov','payload'=>[]];
$r=new RiskFake(); $a=new AssuranceFake(); $service=new LedgerGovernanceEvidenceService($r,$a); $e=$service->evaluate($command);
if(($e['risk_reference']??null)!=='risk-ref'||($e['assurance_reference']??null)!=='assure-ref'||$r->calls!==1||$a->calls!==1) throw new RuntimeException('Governance chain failed.');
$r2=new RiskFake(false); $a2=new AssuranceFake(); $service2=new LedgerGovernanceEvidenceService($r2,$a2);
try{$service2->evaluate($command);throw new RuntimeException('Risk denial was accepted.');}catch(InvalidArgumentException){}
if($a2->calls!==0) throw new RuntimeException('Assurance ran after Risk denial.');
echo "Ledger Risk -> Assurance fail-closed chain: PASS\n";
