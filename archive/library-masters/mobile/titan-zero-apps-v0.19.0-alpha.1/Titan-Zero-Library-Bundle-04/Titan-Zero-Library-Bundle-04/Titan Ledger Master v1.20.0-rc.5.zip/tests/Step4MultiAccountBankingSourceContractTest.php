<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Banking/FinancialAccountRegistryService.php',
 'System/Domains/Banking/MultiAccountBankingFact.php',
 'System/Domains/Banking/MultiAccountBankingJournalMapper.php',
 'System/Domains/Banking/ClearingBalancePolicy.php',
 'System/Domains/Banking/MultiAccountBankingService.php',
 'System/Integrations/Banking/MultiAccountBankingReadPort.php',
 'database/migrations/2026_08_21_000019_create_titan_ledger_multi_account_banking.php',
 'resources/banking/multi-account-banking-contract.v1.json'
] as $p)if(!is_file($root.'/'.$p))$errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';
foreach(['ledger.banking.account.register','ledger.banking.transfer.post','ledger.banking.clearing.settle','ledger.banking.credit_card.payment.post'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';
foreach(['ledger.banking.account.registered','ledger.banking.transfer.posted','ledger.banking.clearing.settled','ledger.banking.credit_card.payment_posted'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';if(!str_contains($provider,'titan.ledger.multi-account-banking.v1'))$errors[]='multi-account banking binding missing';
$recon=@file_get_contents($root.'/System/Domains/Reconciliation/BankReconciliationService.php')?:'';if(!str_contains($recon,"'credit_card'"))$errors[]='credit card reconciliation policy missing';
$pay=@file_get_contents($root.'/System/Integrations/TitanPay/TitanPaySettlementService.php')?:'';if(!str_contains($pay,'funds_account_public_id'))$errors[]='Titan Pay clearing destination support missing';if(!str_contains($pay,'Only card/provider rails may settle into payment clearing'))$errors[]='clearing rail restriction missing';if(!str_contains($pay,'refund funds account must match the original payment'))$errors[]='refund funds-account continuity missing';
$cash=@file_get_contents($root.'/System/Domains/Forecasting/CashflowForecastService.php')?:'';if(!str_contains($cash,'titan_ledger_financial_accounts')||!str_contains($cash,"where('kind','bank')"))$errors[]='cashflow is not multi-bank aware';
$banking=@file_get_contents($root.'/System/Domains/Banking/MultiAccountBankingService.php')?:'';if(!str_contains($banking,'ClearingBalancePolicy::assertPayout'))$errors[]='clearing available-balance guard missing';
$cert=@file_get_contents($root.'/System/Certification/LedgerProductionCertificationService.php')?:'';if(!str_contains($cert,"hasColumn('titan_ledger_payment_settlements','funds_account_public_id')"))$errors[]='production certification does not verify funds_account_public_id';
$mig=@file_get_contents($root.'/database/migrations/2026_08_21_000019_create_titan_ledger_multi_account_banking.php')?:'';foreach(['titan_ledger_financial_accounts','titan_ledger_banking_movements','funds_account_public_id'] as $n)if(!str_contains($mig,$n))$errors[]='migration contract missing '.$n;
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';foreach(['Banking Accounts','Multi-Account Banking'] as $n)if(!str_contains($nav,$n))$errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);if(version_compare((string)($ext['version']??'0'),'1.19.0-rc.4','<'))$errors[]='version not advanced to Step 4';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['command_bus']['command_count']??0)<47)$errors[]='command count earlier than Step 4';if(($rich['signal']['event_count']??0)<47)$errors[]='event count earlier than Step 4';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "PASS Step 4 multi-account banking source contract\n";
