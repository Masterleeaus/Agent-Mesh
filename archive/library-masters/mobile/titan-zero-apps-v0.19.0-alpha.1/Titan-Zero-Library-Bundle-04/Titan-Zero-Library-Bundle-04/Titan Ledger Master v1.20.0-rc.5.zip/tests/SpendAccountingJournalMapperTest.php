<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Integrations/Spend/SpendAccountingJournalMapper.php';
use App\Extensions\TitanLedger\System\Integrations\Spend\SpendAccountingJournalMapper;

$accounts=['accounts_payable'=>'AP','gst_receivable'=>'GST','bank'=>'BANK','cash_on_hand'=>'CASH','supplier_prepayments'=>'PRE','merchant_fees'=>'FEE','credit_card_payable'=>'CARD'];
$splits=[['account_public_id'=>'EXP1','amount_minor'=>6000],['account_public_id'=>'EXP2','amount_minor'=>4000]];
$bill=SpendAccountingJournalMapper::billLines(['subtotal_minor'=>10000,'gst_minor'=>1000,'total_minor'=>11000],$accounts,$splits);
$debit=array_sum(array_column($bill,'debit_minor'));$credit=array_sum(array_column($bill,'credit_minor'));if($debit!==11000||$credit!==11000) exit(1);
$creditLines=SpendAccountingJournalMapper::creditLines(['subtotal_minor'=>2000,'gst_minor'=>200,'total_minor'=>2200],$accounts,[['account_public_id'=>'EXP1','amount_minor'=>2000]]);if(array_sum(array_column($creditLines,'debit_minor'))!==2200||array_sum(array_column($creditLines,'credit_minor'))!==2200) exit(1);
$pay=SpendAccountingJournalMapper::paymentLines(['amount_minor'=>5000,'fee_minor'=>25,'rail'=>'bank_transfer'],$accounts,4500,500);if(array_sum(array_column($pay,'debit_minor'))!==5025||array_sum(array_column($pay,'credit_minor'))!==5025) exit(1);
$actual=SpendAccountingJournalMapper::actualLines(['subtotal_minor'=>3000,'gst_minor'=>300,'total_minor'=>3300,'fee_minor'=>25,'rail'=>'card'],$accounts,[['account_public_id'=>'EXP1','amount_minor'=>3000]]);if(array_sum(array_column($actual,'debit_minor'))!==3325||array_sum(array_column($actual,'credit_minor'))!==3325) exit(1);
echo "Spend accounting journal mapper: PASS\n";
