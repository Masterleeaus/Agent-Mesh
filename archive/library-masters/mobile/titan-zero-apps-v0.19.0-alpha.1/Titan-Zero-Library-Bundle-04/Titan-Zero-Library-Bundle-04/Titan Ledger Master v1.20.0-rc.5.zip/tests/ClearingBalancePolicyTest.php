<?php

declare(strict_types=1);
$root=dirname(__DIR__);require_once $root.'/System/Domains/Banking/ClearingBalancePolicy.php';
use App\Extensions\TitanLedger\System\Domains\Banking\ClearingBalancePolicy;
$errors=[];
try{ClearingBalancePolicy::assertPayout(5000,5000);}catch(Throwable $e){$errors[]='exact clearing payout rejected';}
try{ClearingBalancePolicy::assertPayout(4999,5000);$errors[]='clearing overdraft accepted';}catch(InvalidArgumentException){}
if($errors){fwrite(STDERR,"FAIL clearing balance policy\n - ".implode("\n - ",$errors)."\n");exit(1);}echo "PASS clearing balance policy\n";
