<?php

declare(strict_types=1);
$root=dirname(__DIR__);$errors=[];
foreach([
 'System/Domains/Reporting/FinancialStatementCalculator.php','System/Domains/Reporting/ComparativePeriodResolver.php','System/Domains/Reporting/FinancialStatementService.php','System/Domains/Reporting/FinancialReportSnapshotPolicy.php','System/Domains/Reporting/FinancialReportSnapshotService.php','System/Integrations/Reporting/FinancialReportingReadPort.php','System/Http/Controllers/FinancialReportingController.php','database/migrations/2026_08_20_000014_create_titan_ledger_financial_report_snapshots.php','resources/reporting/financial-reporting-contract.v1.json'
] as $p)if(!is_file($root.'/'.$p))$errors[]='missing '.$p;
$defs=@file_get_contents($root.'/System/CommandBus/LedgerCommandDefinitionRegistry.php')?:'';foreach(['ledger.reporting.snapshot.prepare','ledger.reporting.snapshot.finalize','ledger.reporting.snapshot.supersede'] as $n)if(!str_contains($defs,$n))$errors[]='command missing '.$n;
$events=@file_get_contents($root.'/System/Signal/LedgerFinancialEventCatalog.php')?:'';foreach(['ledger.reporting.snapshot.prepared','ledger.reporting.snapshot.finalized','ledger.reporting.snapshot.superseded'] as $n)if(!str_contains($events,$n))$errors[]='signal missing '.$n;
$svc=@file_get_contents($root.'/System/Domains/Reporting/FinancialStatementService.php')?:'';foreach(['titan_ledger_journals','titan_ledger_journal_lines','titan_ledger_accounts'] as $n)if(!str_contains($svc,$n))$errors[]='reporting source missing '.$n;foreach(['crm_','zeropay_','titan_ledger_crm_invoice_postings','titan_ledger_payment_settlements','titan_ledger_spend_postings'] as $n)if(str_contains($svc,$n))$errors[]='financial statements must derive from posted journals only: '.$n;
$provider=@file_get_contents($root.'/System/TitanLedgerServiceProvider.php')?:'';if(!str_contains($provider,'titan.ledger.financial-reporting.v1'))$errors[]='financial reporting read port binding missing';
$mig=@file_get_contents($root.'/database/migrations/2026_08_20_000014_create_titan_ledger_financial_report_snapshots.php')?:'';foreach(['report_type','report_payload','source_fingerprint','report_hash','supersedes_public_id'] as $n)if(!str_contains($mig,$n))$errors[]='snapshot migration missing '.$n;
$nav=@file_get_contents($root.'/System/Navigation/TitanLedgerNavigation.php')?:'';foreach(['Financial Reports','Financial Reporting'] as $n)if(!str_contains($nav,$n))$errors[]='navigation missing '.$n;
$ext=json_decode((string)@file_get_contents($root.'/extension.json'),true);if(($ext['cumulative_pass']??($ext['upgrade']['pass']??0))<14)$errors[]='extension pass not advanced';if(version_compare((string)($ext['version']??'0'),'1.14.0-alpha.15','<'))$errors[]='version predates Pass 14';
$rich=json_decode((string)@file_get_contents($root.'/extension.manifest.json'),true);if(($rich['command_bus']['command_count']??0)<36)$errors[]='command count below Pass 14 floor';if(($rich['signal']['event_count']??0)<36)$errors[]='event count below Pass 14 floor';
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Pass 14 source contract: PASS\n";
