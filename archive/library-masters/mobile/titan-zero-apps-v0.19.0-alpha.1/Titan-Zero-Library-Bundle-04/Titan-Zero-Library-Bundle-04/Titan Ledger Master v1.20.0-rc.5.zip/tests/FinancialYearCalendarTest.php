<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/System/Domains/Accounting/FinancialYearCalendar.php';

use App\Extensions\TitanLedger\System\Domains\Accounting\FinancialYearCalendar;

$calendar = new FinancialYearCalendar();

$fy = $calendar->australianYearForDate('2026-08-20');
if ($fy['label'] !== 'FY2027' || $fy['starts_on'] !== '2026-07-01' || $fy['ends_on'] !== '2027-06-30') {
    fwrite(STDERR, 'Australian financial year boundary calculation failed.\n');
    exit(1);
}

$fy = $calendar->australianYearForDate('2027-06-30');
if ($fy['label'] !== 'FY2027' || $fy['starts_on'] !== '2026-07-01' || $fy['ends_on'] !== '2027-06-30') {
    fwrite(STDERR, 'Australian financial year end-date calculation failed.\n');
    exit(1);
}

$periods = $calendar->monthlyPeriods('2026-07-01', '2027-06-30');
if (count($periods) !== 12) {
    fwrite(STDERR, 'Expected 12 monthly periods.\n');
    exit(1);
}
if ($periods[0]['starts_on'] !== '2026-07-01' || $periods[0]['ends_on'] !== '2026-07-31') {
    fwrite(STDERR, 'First monthly period is incorrect.\n');
    exit(1);
}
if ($periods[11]['starts_on'] !== '2027-06-01' || $periods[11]['ends_on'] !== '2027-06-30') {
    fwrite(STDERR, 'Final monthly period is incorrect.\n');
    exit(1);
}


$custom = $calendar->monthlyPeriods('2026-07-15', '2026-09-14');
if ($custom[0]['starts_on'] !== '2026-07-15' || $custom[0]['ends_on'] !== '2026-07-31') {
    fwrite(STDERR, 'Custom financial year first partial period is incorrect.\n');
    exit(1);
}
if ($custom[2]['starts_on'] !== '2026-09-01' || $custom[2]['ends_on'] !== '2026-09-14') {
    fwrite(STDERR, 'Custom financial year final partial period is incorrect.\n');
    exit(1);
}

echo "PASS FinancialYearCalendar\n";
