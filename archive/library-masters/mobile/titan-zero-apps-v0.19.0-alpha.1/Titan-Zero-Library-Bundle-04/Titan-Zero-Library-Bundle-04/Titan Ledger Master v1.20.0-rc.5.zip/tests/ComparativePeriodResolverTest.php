<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Domains/Reporting/ComparativePeriodResolver.php';

use App\Extensions\TitanLedger\System\Domains\Reporting\ComparativePeriodResolver;

$r = new ComparativePeriodResolver();
$periods = $r->resolve('2026-07-01', '2026-07-31');
if ($periods['current'] !== ['from'=>'2026-07-01','to'=>'2026-07-31']) { fwrite(STDERR, "FAIL current\n"); exit(1); }
if ($periods['previous_period'] !== ['from'=>'2026-05-31','to'=>'2026-06-30']) { fwrite(STDERR, "FAIL previous period\n"); exit(1); }
if ($periods['prior_year'] !== ['from'=>'2025-07-01','to'=>'2025-07-31']) { fwrite(STDERR, "FAIL prior year\n"); exit(1); }

try { $r->resolve('2026-08-01','2026-07-31'); fwrite(STDERR, "FAIL invalid range accepted\n"); exit(1); }
catch (InvalidArgumentException) {}

echo "Comparative period resolver: PASS\n";
