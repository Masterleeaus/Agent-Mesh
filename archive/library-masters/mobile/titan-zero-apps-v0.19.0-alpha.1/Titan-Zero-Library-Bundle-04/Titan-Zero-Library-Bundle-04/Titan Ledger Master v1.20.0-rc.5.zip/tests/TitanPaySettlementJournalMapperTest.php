<?php

declare(strict_types=1);

$root=dirname(__DIR__);
require_once $root.'/System/Integrations/TitanPay/TitanPaySettlementJournalMapper.php';

use App\Extensions\TitanLedger\System\Integrations\TitanPay\TitanPaySettlementJournalMapper;

$errors=[];
$ids=['bank'=>'A-BANK','accounts_receivable'=>'A-AR','customer_overpayments'=>'A-OVER','merchant_fees'=>'A-FEE'];
$lines=TitanPaySettlementJournalMapper::paymentLines([
    'gross_amount_minor'=>12000,'fee_minor'=>300,'net_amount_minor'=>11700,'rail'=>'stripe'
],$ids,10000,2000);
$debit=array_sum(array_column($lines,'debit_minor')); $credit=array_sum(array_column($lines,'credit_minor'));
if($debit!==12000||$credit!==12000) $errors[]='payment journal is not balanced';
$by=[]; foreach($lines as $line)$by[$line['account_public_id']]=$line;
if(($by['A-BANK']['debit_minor']??0)!==11700) $errors[]='net cash debit wrong';
if(($by['A-FEE']['debit_minor']??0)!==300) $errors[]='merchant fee debit wrong';
if(($by['A-AR']['credit_minor']??0)!==10000) $errors[]='AR allocation credit wrong';
if(($by['A-OVER']['credit_minor']??0)!==2000) $errors[]='overpayment liability credit wrong';
$refund=TitanPaySettlementJournalMapper::refundLines([
    'refund_amount_minor'=>2500,'refund_fee_minor'=>50,'rail'=>'stripe'
],$ids,500,2000);
$d=array_sum(array_column($refund,'debit_minor')); $c=array_sum(array_column($refund,'credit_minor'));
if($d!==2550||$c!==2550) $errors[]='refund journal is not balanced';
$rb=[]; foreach($refund as $line)$rb[$line['account_public_id']]=$line;
if(($rb['A-OVER']['debit_minor']??0)!==500||($rb['A-AR']['debit_minor']??0)!==2000||($rb['A-FEE']['debit_minor']??0)!==50||($rb['A-BANK']['credit_minor']??0)!==2550) $errors[]='refund mapping wrong';
if($errors){fwrite(STDERR,"FAIL Titan Pay settlement mapper\n - ".implode("\n - ",$errors)."\n");exit(1);} echo "PASS Titan Pay settlement mapper\n";
