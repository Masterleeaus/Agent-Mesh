<?php

declare(strict_types=1);
require_once __DIR__.'/../System/Domains/Tax/GstBasCalculator.php';
use App\Extensions\TitanLedger\System\Domains\Tax\GstBasCalculator;

$invoices=[
 ['document_type'=>'invoice','currency'=>'AUD','total_minor'=>110000,'tax_minor'=>10000,'fact_hash'=>str_repeat('a',64)],
 ['document_type'=>'invoice','currency'=>'AUD','total_minor'=>55000,'tax_minor'=>5000,'fact_hash'=>str_repeat('b',64)],
 ['document_type'=>'credit_note','currency'=>'AUD','total_minor'=>22000,'tax_minor'=>2000,'fact_hash'=>str_repeat('c',64)],
];
$spend=[
 ['posting_type'=>'supplier_bill','currency'=>'AUD','total_minor'=>66000,'gst_minor'=>6000,'fact_hash'=>str_repeat('d',64)],
 ['posting_type'=>'spend_actual','currency'=>'AUD','total_minor'=>33000,'gst_minor'=>3000,'fact_hash'=>str_repeat('e',64)],
 ['posting_type'=>'supplier_credit','currency'=>'AUD','total_minor'=>11000,'gst_minor'=>1000,'fact_hash'=>str_repeat('f',64)],
 ['posting_type'=>'supplier_payment','currency'=>'AUD','amount_minor'=>55000,'gst_minor'=>0,'fact_hash'=>str_repeat('0',64)],
];
$r=GstBasCalculator::calculate($invoices,$spend);
$expected=['g1_total_sales_minor'=>143000,'one_a_gst_on_sales_minor'=>13000,'one_b_gst_on_purchases_minor'=>8000,'total_purchases_minor'=>88000,'net_gst_payable_minor'=>5000,'invoice_source_count'=>3,'spend_source_count'=>3];
foreach($expected as $k=>$v){if(($r[$k]??null)!==$v){fwrite(STDERR,"$k expected $v got ".var_export($r[$k]??null,true)."\n");exit(1);}}
if(($r['lodgement_ready']??null)!==true){fwrite(STDERR,"Expected BAS result to be lodgement-ready\n");exit(1);}
try{GstBasCalculator::calculate([['document_type'=>'invoice','currency'=>'USD','total_minor'=>100,'tax_minor'=>9,'fact_hash'=>str_repeat('1',64)]],[]);fwrite(STDERR,"Non-AUD GST evidence should fail closed\n");exit(1);}catch(InvalidArgumentException){}
$r=GstBasCalculator::calculate([['document_type'=>'credit_note','currency'=>'AUD','total_minor'=>1000,'tax_minor'=>91,'fact_hash'=>str_repeat('2',64)]],[]);
if(($r['lodgement_ready']??true)!==false || !in_array('negative_bas_label_requires_review',$r['review_reasons']??[],true)){fwrite(STDERR,"Negative BAS labels must require review\n");exit(1);}
echo "GST BAS calculator: PASS\n";
