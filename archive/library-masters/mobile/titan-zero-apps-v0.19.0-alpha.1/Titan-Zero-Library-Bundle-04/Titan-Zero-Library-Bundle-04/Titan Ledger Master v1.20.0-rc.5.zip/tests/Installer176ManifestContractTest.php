<?php

declare(strict_types=1);
$root=dirname(__DIR__);$m=json_decode((string)file_get_contents($root.'/extension.json'),true);$errors=[];
$deps=$m['dependencies']??null;
if(!is_array($deps)||array_is_list($deps)===false)$errors[]='dependencies must be a JSON list for Installer 1.7.6';
if(is_array($deps))foreach($deps as $i=>$dep){if(!is_array($dep)||trim((string)($dep['slug']??''))==='')$errors[]="dependency[$i] missing slug";if(trim((string)($dep['version']??''))==='')$errors[]="dependency[$i] missing version";}
$slugs=[];if(is_array($deps))foreach($deps as $dep)if(is_array($dep)&&isset($dep['slug']))$slugs[]=$dep['slug'];
foreach(['crm','titan-command-bus'] as $required)if(!in_array($required,$slugs,true))$errors[]='required dependency missing '.$required;
if($errors){foreach($errors as $e)fwrite(STDERR,"FAIL: $e\n");exit(1);}echo "Installer 1.7.6 manifest contract: PASS\n";
