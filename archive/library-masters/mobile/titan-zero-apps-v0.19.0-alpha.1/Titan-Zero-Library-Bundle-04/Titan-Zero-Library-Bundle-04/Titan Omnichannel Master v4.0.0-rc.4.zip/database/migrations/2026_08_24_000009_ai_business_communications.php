<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{
if(!Schema::hasTable('ext_omni_ai_runs'))Schema::create('ext_omni_ai_runs',function(Blueprint$t){$t->id();$t->unsignedBigInteger('company_id');$t->string('conversation_id',190);$t->string('message_id',190)->nullable();$t->string('mode',40);$t->string('status',30)->default('prepared');$t->decimal('confidence',5,4)->default(0);$t->text('summary')->nullable();$t->text('draft')->nullable();$t->json('facts_used')->nullable();$t->json('unknowns')->nullable();$t->json('proposed_actions')->nullable();$t->json('handoff_reasons')->nullable();$t->string('idempotency_key',190);$t->timestamps();$t->unique(['company_id','idempotency_key']);$t->index(['company_id','conversation_id','created_at']);});
}public function down():void{Schema::dropIfExists('ext_omni_ai_runs');}};
