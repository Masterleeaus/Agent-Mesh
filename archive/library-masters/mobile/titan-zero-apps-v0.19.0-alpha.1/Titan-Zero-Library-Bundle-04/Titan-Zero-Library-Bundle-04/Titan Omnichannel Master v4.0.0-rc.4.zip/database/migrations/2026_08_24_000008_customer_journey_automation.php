<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{public function up():void{
if(!Schema::hasTable('ext_omni_journey_automations'))Schema::create('ext_omni_journey_automations',function(Blueprint$t){$t->id();$t->unsignedBigInteger('company_id');$t->string('conversation_id',190);$t->string('journey_key',100);$t->string('trigger_key',120);$t->string('state',30)->default('pending');$t->timestamp('due_at')->nullable()->index();$t->unsignedInteger('attempts')->default(0);$t->string('idempotency_key',190);$t->json('payload')->nullable();$t->json('channel_plan')->nullable();$t->timestamp('executed_at')->nullable();$t->timestamps();$t->unique(['company_id','idempotency_key']);$t->index(['company_id','state','due_at']);});
}public function down():void{Schema::dropIfExists('ext_omni_journey_automations');}};
