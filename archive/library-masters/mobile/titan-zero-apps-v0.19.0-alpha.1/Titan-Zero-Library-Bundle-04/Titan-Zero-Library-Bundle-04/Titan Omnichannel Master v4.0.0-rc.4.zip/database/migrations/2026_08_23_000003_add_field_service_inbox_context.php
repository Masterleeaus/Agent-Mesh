<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration {public function up():void{
Schema::table('ext_omni_conversations',function(Blueprint$t){
foreach([['journey_stage','enquiry'],['priority','normal'],['operating_state','unassigned']] as[$n,$d])if(!Schema::hasColumn('ext_omni_conversations',$n))$t->string($n,40)->default($d)->index();
if(!Schema::hasColumn('ext_omni_conversations','service_intent'))$t->string('service_intent',120)->nullable()->index();
foreach(['assigned_type','assigned_id','customer_id','site_id']as$n)if(!Schema::hasColumn('ext_omni_conversations',$n))$t->string($n,190)->nullable()->index();
if(!Schema::hasColumn('ext_omni_conversations','last_inbound_at'))$t->timestamp('last_inbound_at')->nullable()->index();
if(!Schema::hasColumn('ext_omni_conversations','last_outbound_at'))$t->timestamp('last_outbound_at')->nullable();
});
if(!Schema::hasTable('ext_omni_conversation_links'))Schema::create('ext_omni_conversation_links',function(Blueprint$t){$t->id();$t->unsignedBigInteger('company_id');$t->string('conversation_id',190);$t->string('object_type',40);$t->string('object_id',190);$t->string('relation',40)->default('related');$t->timestamps();$t->unique(['company_id','conversation_id','object_type','object_id'],'omni_conv_object_unique');$t->index(['company_id','object_type','object_id']);});
}public function down():void{Schema::dropIfExists('ext_omni_conversation_links');}};
