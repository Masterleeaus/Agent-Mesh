<?php

declare(strict_types=1);
$root=getenv('TITAN_PROVIDER_ROOT') ?: dirname(__DIR__,2);
$fail=0;$pass=0;
$check=function(bool $ok,string $message)use(&$fail,&$pass):void{if($ok){$pass++;echo "PASS $message\n";}else{$fail++;echo "FAIL $message\n";}};
$path=$root.'/resources/titan-apps/interface-contributions.json';
$check(is_file($path),'semantic interface contribution manifest exists');
$data=json_decode((string)@file_get_contents($path),true);
$check(is_array($data)&&($data['schema']??null)==='titan-apps-interface-contributions-v1','contribution manifest schema is valid');
$rows=(array)($data['contributions']??[]);
$check($rows!==[],'at least one governed semantic contribution exists');
foreach($rows as $row){
 $surfaces=(array)($row['supported_surfaces']??[]);
 $check($surfaces!==[] && array_diff($surfaces,['zero','go','hub'])===[],'contribution uses only canonical application surfaces');
 foreach(['javascript','script','component_source','executable_ui','html'] as $forbidden)$check(!array_key_exists($forbidden,(array)$row),'contribution contains no executable UI field '.$forbidden);
 $check(($row['authority']??'')==='none; actions remain governed capability intent','contribution metadata grants no authority');
}
$catalog=$root.'/System/TitanApps/ProviderInterfaceContributionCatalog.php';
$check(is_file($catalog),'provider contribution catalogue runtime adapter exists');
$catalogSource=(string)@file_get_contents($catalog);
$check(str_contains($catalogSource,"['zero','go','hub']"),'runtime catalogue rejects non-canonical app surfaces');
$serviceProviders=glob($root.'/System/*ServiceProvider.php') ?: [];
$providerSource='';foreach($serviceProviders as $sp)$providerSource.=file_get_contents($sp);
$check(str_contains($providerSource,'titan.apps.interface-contributions'),'provider registers contribution catalogue through container discovery');
$all='';foreach(['System','routes','config'] as $runtimeDir){$dir=$root.'/'.$runtimeDir;if(!is_dir($dir))continue;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $file){if($file->isFile()&&$file->getExtension()==='php')$all.=file_get_contents($file->getPathname());}}
$check(!str_contains($all,'providers/Titan-Interaction-Engine')&&!str_contains($all,'Titan-Interaction-Engine-v'),'runtime has no physical Interaction Engine package-path dependency');
if(false){foreach($rows as $row)$check(!in_array('hub',(array)($row['supported_surfaces']??[]),true),'restricted people/payroll contribution is not exposed to Hub');}

$policy=file_get_contents($root.'/System/Omnichannel/Services/TitanSurfaceAuthorityPolicy.php');
$check(str_contains($policy,"'zero'=>")&&str_contains($policy,"'go'=>")&&str_contains($policy,"'hub'=>"),'Omnichannel policy has canonical zero/go/hub surfaces');


$surfacePolicy=(string)@file_get_contents($root.'/System/Omnichannel/Services/TitanSurfaceAuthorityPolicy.php');
$pushPlanner=(string)@file_get_contents($root.'/System/Omnichannel/Services/PushNotificationPlanner.php');
$check(str_contains($surfacePolicy,"'zero','go','hub'=>\$surface"),'Omnichannel surface policy recognizes canonical surfaces first');
$check(str_contains($surfacePolicy,"'titan_bos','bos','command','owner','manager','business','onboarding'=>'zero'"),'legacy Zero aliases are compatibility normalization only');
$check(str_contains($pushPlanner,"['zero','go','hub']"),'push planner validates canonical surfaces');
$check(str_contains($pushPlanner,"'surface'=>\$canonical"),'push planner emits canonical surface identity');
$check(!str_contains($pushPlanner,"['titan_hub','titan_go','titan_bos']"),'push planner no longer treats legacy Titan app names as canonical');


require_once $root.'/System/Omnichannel/Services/TitanSurfaceAuthorityPolicy.php';
require_once $root.'/System/Omnichannel/Services/PushNotificationPlanner.php';
$surfacePolicyObject=new \App\Extensions\MarketingBot\System\Omnichannel\Services\TitanSurfaceAuthorityPolicy();
$pushPlannerObject=new \App\Extensions\MarketingBot\System\Omnichannel\Services\PushNotificationPlanner($surfacePolicyObject);
$check($surfacePolicyObject->canonicalSurface('bos')==='zero','legacy BOS compatibility resolves to canonical Zero');
$check($surfacePolicyObject->canonicalSurface('field')==='go','legacy Field compatibility resolves to canonical Go');
$check($surfacePolicyObject->canonicalSurface('customer')==='hub','legacy Customer compatibility resolves to canonical Hub');
$check(($pushPlannerObject->plan('titan_bos','Title','Body')['surface']??null)==='zero','legacy push input emits canonical Zero identity');


$canonicalGenerator=file_get_contents($root.'/System/Generators/CanonicalIntelligenceGenerator.php');
$canonicalEmbedder=file_get_contents($root.'/System/Embedders/CanonicalIntelligenceEmbedder.php');
$generatorService=file_get_contents($root.'/System/Services/Generator/GeneratorService.php');
$embeddingService=file_get_contents($root.'/System/Services/EmbedingService.php');
$knowledgeBase=file_get_contents($root.'/System/Tools/KnowledgeBase.php');
$aiConfig=file_get_contents($root.'/config/marketing-bot.php');
$check(str_contains($canonicalGenerator,"titan.apps.interaction.command-bus")&&str_contains($canonicalGenerator,"ai.omnichannel.reply.generate"),'Omnichannel generation targets governed canonical intelligence capability');
$check(str_contains($canonicalEmbedder,"titan.apps.interaction.command-bus")&&str_contains($canonicalEmbedder,"ai.embedding.generate"),'Omnichannel embeddings target governed canonical intelligence capability');
$check(!str_contains($canonicalGenerator,'api.openai.com')&&!str_contains($canonicalEmbedder,'OpenAI::client'),'canonical Omnichannel adapters do not call OpenAI directly');
$check(str_contains($generatorService,'CanonicalIntelligenceGenerator::class'),'active Omnichannel generator service defaults to canonical intelligence adapter');
$check(str_contains($embeddingService,'CanonicalIntelligenceEmbedder::class')&&str_contains($knowledgeBase,'CanonicalIntelligenceEmbedder::class'),'training and knowledge search use canonical embedding adapter');
$check(str_contains($canonicalGenerator,"config('marketing-bot.ai.allow_legacy_generation_fallback', false)"),'canonical Omnichannel generation fails closed unless legacy fallback is explicitly enabled');
$check(str_contains($canonicalEmbedder,"config('marketing-bot.ai.allow_legacy_embedding_fallback', false)"),'canonical Omnichannel embeddings fail closed unless legacy fallback is explicitly enabled');
$check(str_contains($aiConfig,"TITAN_OMNICHANNEL_ALLOW_LEGACY_AI_GENERATION_FALLBACK', false")&&str_contains($aiConfig,"TITAN_OMNICHANNEL_ALLOW_LEGACY_AI_EMBEDDING_FALLBACK', false"),'Omnichannel direct AI compatibility fallbacks default off');

echo "RESULT pass=$pass fail=$fail\n";exit($fail===0?0:1);
