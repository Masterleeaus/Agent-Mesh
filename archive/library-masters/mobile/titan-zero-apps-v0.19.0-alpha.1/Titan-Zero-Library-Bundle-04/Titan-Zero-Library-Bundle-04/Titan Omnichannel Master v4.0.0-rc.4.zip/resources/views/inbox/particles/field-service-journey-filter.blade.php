<div class="border-b px-4 py-3 xl:px-6">
    <div class="mb-2 text-[11px] font-semibold uppercase tracking-wide opacity-60">{{ __('Field Service Inbox') }}</div>
    <div class="flex flex-wrap gap-1.5 text-xs">
        @foreach([
            'new_enquiries'=>'New enquiries','leads'=>'Leads','quotes'=>'Quotes','bookings'=>'Bookings',
            'active_jobs'=>'Active jobs','urgent'=>'Urgent','unassigned'=>'Unassigned',
            'waiting_customer'=>'Waiting on customer','waiting_business'=>'Waiting on business',
            'ai_handled'=>'AI handled','human_required'=>'Human required','complaints'=>'Complaints','reviews'=>'Reviews'
        ] as $key=>$label)
            <button type="button" class="rounded-full border px-2.5 py-1 hover:bg-foreground/5" data-omni-view="{{ $key }}">{{ __($label) }}</button>
        @endforeach
    </div>
</div>