<?php

return [
    'version'              => 1.0,
    'notification_enabled' => env('MARKETING_BOT_NOTIFICATION_ENABLED', true),
    'ai' => [
        // Compatibility-only until Agent 1 exposes the governed generation/embedding capabilities on every host. Fail-closed by default; legacy direct AI requires explicit opt-in.
        'allow_legacy_generation_fallback' => (bool) env('TITAN_OMNICHANNEL_ALLOW_LEGACY_AI_GENERATION_FALLBACK', false),
        'allow_legacy_embedding_fallback' => (bool) env('TITAN_OMNICHANNEL_ALLOW_LEGACY_AI_EMBEDDING_FALLBACK', false),
    ],
];
