<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\KnowledgeAuthorityGateway;
final class FailClosedKnowledgeAuthorityGateway implements KnowledgeAuthorityGateway{public function resolve(int $companyId,string $question,array $context=[]):array{return ['resolved'=>false,'answer'=>null,'confidence'=>0.0,'sources'=>[],'reason'=>'knowledge_authority_not_connected'];}}