<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class RichContentPart{
 public const KINDS=['text','html','image','video','audio','voice_note','document','pdf','location','contact','buttons','form','template','reaction','call','public_interaction'];
 public function __construct(public string$kind,public mixed$content=null,public array$metadata=[]){if(!in_array($kind,self::KINDS,true))throw new \InvalidArgumentException('Unsupported rich content kind.');}
}