<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface VoiceReceptionProvider extends VoiceRealtimeProvider{
 public function answer(int$companyId,string$callId,array$context=[]):array;
 public function speak(int$companyId,string$callId,string$text,array$context=[]):array;
 public function voicemail(int$companyId,string$callId,array$context=[]):array;
 public function recording(int$companyId,string$callId,array$context=[]):array;
 public function callback(int$companyId,string$address,array$context=[]):array;
}