<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface BusinessKnowledgeProvider{public function retrieve(int$companyId,string$query,array$context=[]):array;}
