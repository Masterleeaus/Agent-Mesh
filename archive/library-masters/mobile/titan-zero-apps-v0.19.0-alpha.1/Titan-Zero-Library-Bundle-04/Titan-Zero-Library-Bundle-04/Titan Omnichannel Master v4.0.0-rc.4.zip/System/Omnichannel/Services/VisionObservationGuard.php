<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class VisionObservationGuard{
 public function govern(array$analysis):array{
  $confidence=(float)($analysis['confidence']??0);$observations=(array)($analysis['observations']??[]);
  return ['observations'=>$observations,'confidence'=>$confidence,'may_describe'=>$confidence>=0.5,'requires_human_review'=>$confidence<0.7||($analysis['safety_critical']??false),'may_execute_business_action'=>false,'may_confirm_diagnosis'=>false,'may_confirm_price'=>false,'may_confirm_booking'=>false];
 }}
