<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class OutboundMessage {public function __construct(public int $companyId,public string $conversationId,public string $channel,public string $provider,public string $recipientAddress,public string $body,public array $attachments=[],public array $metadata=[]){if($companyId<=0)throw new \InvalidArgumentException('company_id is required.');}}
