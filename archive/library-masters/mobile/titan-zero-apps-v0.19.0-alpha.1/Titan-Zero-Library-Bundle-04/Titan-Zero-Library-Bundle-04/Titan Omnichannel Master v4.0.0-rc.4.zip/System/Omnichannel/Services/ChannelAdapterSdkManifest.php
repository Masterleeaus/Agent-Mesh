<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class ChannelAdapterSdkManifest{public function requirements():array{return[
'contract'=>'ExternalChannelAdapter','tenant_boundary'=>'company_id','required_operations'=>['capabilities','normalize_inbound','normalize_status','send_rich'],
'security'=>['credential_reference_only','webhook_signature_or_verification','idempotent_ingress','secure_media_fetch','no_secret_logging'],
'governance'=>['communication_policy','cost_router','authority_policy','audit_provenance'],
'lifecycle'=>['register','health_check','disable','credential_rotate','uninstall']];}}