<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Enums;
enum DeliveryStatus:string {case QUEUED='queued';case SENT='sent';case DELIVERED='delivered';case READ='read';case FAILED='failed';case BOUNCED='bounced';case BLOCKED='blocked';}
