<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\Models\EmailAccount;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\NormalizedInboundMessage;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\OutboundMessage;
interface EmailProvider extends ChannelProvider{
 public function search(EmailAccount$account,string$query='',int$limit=20):array;
 public function fetch(EmailAccount$account,string$messageId):NormalizedInboundMessage;
 public function reply(EmailAccount$account,string$messageId,OutboundMessage$message):array;
 public function createDraft(EmailAccount$account,OutboundMessage$message):array;
 public function createReplyDraft(EmailAccount$account,string$messageId,OutboundMessage$message):array;
 public function attachments(EmailAccount$account,string$messageId):array;
 public function labels(EmailAccount$account):array;
 public function modifyLabels(EmailAccount$account,string$messageId,array$add=[],array$remove=[]):array;
 public function thread(EmailAccount$account,string$threadId):array;
 public function sync(EmailAccount$account,?string$cursor=null):array;
}