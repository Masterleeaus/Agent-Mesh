<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelConversation;use App\Extensions\MarketingBot\System\Omnichannel\Models\ConversationLink;
final class FieldServiceInbox {
 public const STAGES=['enquiry','lead','quote','booking','job','invoice','payment','review','complaint','resolved'];
 public const STATES=['unassigned','ai_autonomous','ai_assisted','human_owned','awaiting_approval','workflow_executing','waiting_customer','waiting_business','resolved'];
 public const OBJECTS=['customer','site','enquiry','lead','quote','booking','job','invoice','payment','review','complaint'];
 public function queue(string $view='all',?string $channel=null,?string $search=null,int $perPage=30){
  $q=OmnichannelConversation::query()->latest('updated_at');
  if($channel&&$channel!=='all')$q->where('channel',$channel);
  match($view){
   'new_enquiries'=>$q->where('journey_stage','enquiry'),
   'leads'=>$q->where('journey_stage','lead'),
   'quotes'=>$q->where('journey_stage','quote'),
   'bookings'=>$q->where('journey_stage','booking'),
   'active_jobs'=>$q->where('journey_stage','job')->where('operating_state','!=','resolved'),
   'complaints'=>$q->where('journey_stage','complaint'),
   'reviews'=>$q->where('journey_stage','review'),
   'urgent'=>$q->whereIn('priority',['urgent','emergency']),
   'unassigned'=>$q->where('operating_state','unassigned'),
   'waiting_customer'=>$q->where('operating_state','waiting_customer'),
   'waiting_business'=>$q->where('operating_state','waiting_business'),
   'ai_handled'=>$q->whereIn('operating_state',['ai_autonomous','ai_assisted']),
   'human_required'=>$q->whereIn('operating_state',['human_owned','awaiting_approval']),
   default=>null};
  if($search)$q->where(function($x)use($search){$x->where('subject','like',"%$search%")->orWhere('service_intent','like',"%$search%");});
  return $q->paginate($perPage);
 }
 public function link(OmnichannelConversation $c,string $type,string|int $id,string $relation='related'):ConversationLink {if(!in_array($type,self::OBJECTS,true))throw new \InvalidArgumentException('Unsupported field-service object link.');return ConversationLink::query()->firstOrCreate(['company_id'=>$c->company_id,'conversation_id'=>(string)$c->getKey(),'object_type'=>$type,'object_id'=>(string)$id],['relation'=>$relation]);}
 public function classify(OmnichannelConversation $c,string $stage,?string $service=null,string $priority='normal'):void {if(!in_array($stage,self::STAGES,true))throw new \InvalidArgumentException('Unsupported journey stage.');$c->update(['journey_stage'=>$stage,'service_intent'=>$service,'priority'=>$priority]);}
 public function assign(OmnichannelConversation $c,string $state,?string $type=null,string|int|null $id=null):void {if(!in_array($state,self::STATES,true))throw new \InvalidArgumentException('Unsupported operating state.');$c->update(['operating_state'=>$state,'assigned_type'=>$type,'assigned_id'=>$id===null?null:(string)$id]);}
}