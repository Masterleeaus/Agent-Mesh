<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\WorkforceExecutionGateway;
final class FailClosedWorkforceExecutionGateway implements WorkforceExecutionGateway{public function propose(int $companyId,string $responsibility,array $action,array $context=[]):array{return ['accepted'=>false,'reason'=>'workforce_gateway_not_connected'];}public function execute(int $companyId,string $proposalId,array $authority):array{return ['executed'=>false,'reason'=>'workforce_gateway_not_connected'];}}