<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelMessage;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\NormalizedInboundMessage;
final class InboundCustomerOperationsPipeline {public function __construct(private ConversationRouter$router,private FieldServiceIntentEngine$intents){}public function ingest(NormalizedInboundMessage$m):array{$message=$this->router->ingest($m);$context=$this->intents->analyze($message);return ['message'=>$message,'field_service_context'=>$context];}}
