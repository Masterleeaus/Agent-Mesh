<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class TitanFirstPartyChannelCatalog{
 public const CHANNELS=['web_chat','web_form','titan_hub','titan_go','titan_bos','in_app','pwa_push'];
 public function capabilities(string$channel):array{return match($channel){
 'web_chat','titan_hub','titan_go','titan_bos','in_app'=>['text','html','image','video','audio','voice_note','document','pdf','location','buttons','form','reaction','typing','read_receipts'],
 'web_form'=>['text','html','image','document','pdf','location','form'],
 'pwa_push'=>['text','image','buttons','delivery'],default=>throw new \InvalidArgumentException('Unknown Titan first-party channel.')};}
}