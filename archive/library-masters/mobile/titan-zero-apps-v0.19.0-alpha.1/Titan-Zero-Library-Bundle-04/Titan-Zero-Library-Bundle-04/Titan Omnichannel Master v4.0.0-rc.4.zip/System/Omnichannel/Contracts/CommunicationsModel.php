<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface CommunicationsModel{public function complete(array$messages,array$options=[]):array;}
