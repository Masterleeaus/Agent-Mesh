<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface MessagingProvider extends ChannelProvider {public function verifyWebhook(array $headers,string $rawBody,array $query=[]):bool;public function normalizeWebhook(array $payload):array;public function normalizeDeliveryReceipts(array $payload):array;}
