<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;use App\Extensions\MarketingBot\System\Omnichannel\Models\VoiceAccount;
interface VoiceProvider extends ChannelProvider {public function verifyWebhook(VoiceAccount $account,string $url,array $payload,array $headers=[]):bool;public function initiate(VoiceAccount $account,string $to,array $options=[]):array;public function fetchStatus(VoiceAccount $account,string $externalCallId):array;}
