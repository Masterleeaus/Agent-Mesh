<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\ChannelProvider;
final class ProviderRegistry {private array $providers=[];public function register(ChannelProvider $provider):void{$this->providers[$provider->key()]=$provider;}public function get(string $key):ChannelProvider{if(!isset($this->providers[$key]))throw new \OutOfBoundsException("Unknown omnichannel provider: {$key}");return $this->providers[$key];}public function all():array{return $this->providers;}}
