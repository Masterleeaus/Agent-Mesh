<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MetaPrivateConversationPolicy{
 public function route(string$surface,array$context=[]):array{
  $supported=['instagram_dm','facebook_messenger','whatsapp'];if(!in_array($surface,$supported,true))throw new \InvalidArgumentException('Not a private Meta conversation surface.');
  return ['surface'=>$surface,'canonical_conversation'=>true,'identity_resolution'=>true,'intent_engine'=>true,'workforce_authority'=>true,'outcome_intelligence'=>true,'communication_policy'=>true];
 }}
