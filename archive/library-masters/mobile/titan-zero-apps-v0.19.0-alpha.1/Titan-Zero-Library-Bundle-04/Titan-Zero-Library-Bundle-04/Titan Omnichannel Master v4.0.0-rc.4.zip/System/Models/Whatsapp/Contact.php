<?php

namespace App\Extensions\MarketingBot\System\Models\Whatsapp;

use Database\Factories\ContactFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Extensions\MarketingBot\System\Models\Concerns\CompanyScoped;

class Contact extends Model
{
    use HasFactory, CompanyScoped;

    protected static function newFactory(): ContactFactory
    {
        return ContactFactory::new();
    }

    protected $table = 'ext_contacts';

    protected $fillable = [
        'company_id',
        'user_id',
        'name',
        'status',
    ];

    public function scopeMy(Builder $builder, int $status = 1): void
    {
        $builder
            ->where('company_id', app(\App\Extensions\MarketingBot\System\Contracts\CompanyContext::class)->id())
            ->where('status', $status);
    }
}
