<?php

namespace App\Extensions\MarketingBot\System\Models\Telegram;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use App\Extensions\MarketingBot\System\Contracts\CompanyContext;

class TelegramBot extends Model
{
    protected $table = 'ext_telegram_bots';

    protected $fillable = [
        'company_id',
        'user_id',
        'access_token',
        'is_connected',
        'webhook_verified',
        'bot_id',
        'name',
        'username',
        'scopes',
    ];

    protected $hidden = ['access_token'];

    protected $casts = [
        'access_token' => 'encrypted',
        'scopes' => 'array',
    ];
    protected static function booted(): void
    {
        static::addGlobalScope('company_id', function (Builder $query): void {
            try { $id = app(CompanyContext::class)->id(); } catch (\Throwable) { $id = null; }
            if (! $id) { $query->whereRaw('1=0'); return; }
            $query->where($query->getModel()->getTable() . '.company_id', $id);
        });
        static::creating(function (Model $model): void {
            if (! (int) ($model->company_id ?? 0)) { $model->company_id = app(CompanyContext::class)->id(); }
        });
    }

}
