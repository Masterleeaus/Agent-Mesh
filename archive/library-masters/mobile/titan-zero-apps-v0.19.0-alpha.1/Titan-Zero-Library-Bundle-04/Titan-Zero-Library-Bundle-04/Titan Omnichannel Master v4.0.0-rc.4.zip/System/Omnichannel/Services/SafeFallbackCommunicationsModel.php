<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationsModel;
final class SafeFallbackCommunicationsModel implements CommunicationsModel{
 public function complete(array$messages,array$options=[]):array{
  $raw=(string)($messages[count($messages)-1]['content']??'');$d=json_decode($raw,true);$last=(string)(collect($d['messages']??[])->last()['body']??'');
  return ['summary'=>$last===''?'No customer message available.':'Customer message: '.mb_substr($last,0,500),'draft'=>'','confidence'=>0.0,'facts_used'=>[],'claims_unknown_fact'=>false,'requests_business_action'=>false,'sensitive_or_complaint'=>false];
 }}
