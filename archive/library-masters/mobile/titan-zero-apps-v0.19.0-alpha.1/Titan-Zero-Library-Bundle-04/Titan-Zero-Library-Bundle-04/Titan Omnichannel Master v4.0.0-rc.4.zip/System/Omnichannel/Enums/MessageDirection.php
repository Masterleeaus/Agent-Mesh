<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Enums;
enum MessageDirection:string {case INBOUND='inbound';case OUTBOUND='outbound';case INTERNAL='internal';}
