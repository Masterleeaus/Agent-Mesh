<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MetaWebhookNormalizer{
 public function normalize(int$companyId,string$surface,array$p):array{
  if($companyId<=0)throw new \InvalidArgumentException('company_id required.');
  $public=in_array($surface,['instagram_comment','instagram_mention','facebook_comment'],true);
  return ['company_id'=>$companyId,'surface'=>$surface,'kind'=>$public?'public_interaction':'private_message','external_id'=>(string)($p['id']??$p['message_id']??''),'author_external_id'=>$p['from']['id']??$p['sender']['id']??null,'body'=>(string)($p['message']??$p['text']??''),'media'=>(array)($p['attachments']??$p['media']??[]),'reply_to'=>$p['reply_to']??null,'raw_provenance'=>['provider'=>'meta','surface'=>$surface,'event'=>$p['event']??null]];
 }}
