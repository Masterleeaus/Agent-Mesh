<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface KnowledgeAuthorityGateway{public function resolve(int $companyId,string $question,array $context=[]):array;}