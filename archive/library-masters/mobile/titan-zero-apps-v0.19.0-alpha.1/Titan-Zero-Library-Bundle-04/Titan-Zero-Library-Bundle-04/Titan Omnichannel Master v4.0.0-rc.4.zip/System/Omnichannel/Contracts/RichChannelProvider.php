<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\ProviderCapabilitySet;
interface RichChannelProvider extends ChannelProvider,ProviderCapabilities{public function capabilitySet():ProviderCapabilitySet;}
