<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use Illuminate\Support\Facades\DB;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\FirstPartyIdentityVerifier;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelIdentity;
final class FirstPartyIdentityResolver{
 public function __construct(private FirstPartyIdentityVerifier$verifier){}
 public function anonymous(int$companyId,string$surface,string$anonymousId,?string$name=null):OmnichannelIdentity{
  if($companyId<=0||$anonymousId==='')throw new \InvalidArgumentException('company_id and anonymous ID required.');
  return OmnichannelIdentity::query()->firstOrCreate(['company_id'=>$companyId,'channel'=>$surface,'address'=>'anon:'.$anonymousId],['display_name'=>$name,'external_id'=>$anonymousId,'metadata'=>['identity_state'=>'anonymous']]);
 }
 public function linkAuthenticated(int$companyId,int$identityId,string$surface,string$principalType,string$principalId,array$proof=[]):array{
  $identity=OmnichannelIdentity::query()->where('company_id',$companyId)->findOrFail($identityId);$v=$this->verifier->verify($companyId,$surface,$principalType,$principalId,$proof);
  if(($v['verified']??false)!==true)throw new \LogicException('First-party identity link requires verified Titan principal.');
  DB::table('ext_omni_identity_links')->updateOrInsert(['company_id'=>$companyId,'identity_id'=>$identity->id,'principal_type'=>$principalType,'principal_id'=>$principalId],['verification'=>'verified','source'=>$surface,'evidence'=>json_encode($v['evidence']??[]),'updated_at'=>now(),'created_at'=>now()]);
  if($principalType==='customer_contact')$identity->forceFill(['contact_id'=>(int)$principalId,'metadata'=>array_merge((array)$identity->metadata,['identity_state'=>'identified'])])->save();
  return ['identity_id'=>$identity->id,'principal_type'=>$principalType,'principal_id'=>$principalId,'verified'=>true];
 }}
