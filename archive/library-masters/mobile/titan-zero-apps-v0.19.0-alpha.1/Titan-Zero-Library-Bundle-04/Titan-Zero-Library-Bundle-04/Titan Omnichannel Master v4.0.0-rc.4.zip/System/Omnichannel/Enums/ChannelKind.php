<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Enums;
enum ChannelKind:string {case EMAIL='email';case SMS='sms';case WHATSAPP='whatsapp';case MESSENGER='messenger';case TELEGRAM='telegram';case WEBCHAT='webchat';case VOICE='voice';case SLACK='slack';case IN_APP='in_app';}
