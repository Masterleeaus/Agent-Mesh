<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface FirstPartyIdentityVerifier{public function verify(int$companyId,string$surface,string$principalType,string$principalId,array$proof=[]):array;}
