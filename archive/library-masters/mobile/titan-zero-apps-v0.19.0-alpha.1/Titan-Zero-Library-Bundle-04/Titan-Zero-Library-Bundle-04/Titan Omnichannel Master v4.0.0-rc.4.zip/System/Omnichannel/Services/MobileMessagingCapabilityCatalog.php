<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MobileMessagingCapabilityCatalog{
 public function channel(string$c):array{return match($c){
 'rcs'=>['text','image','video','audio','document','rich_card','carousel','buttons','suggested_replies','location','delivered','read','typing'],
 'mms'=>['text','image','video','audio','document','delivered'],
 'sms'=>['text','delivered'],
 default=>throw new \InvalidArgumentException('Unsupported mobile messaging channel.')};}
}