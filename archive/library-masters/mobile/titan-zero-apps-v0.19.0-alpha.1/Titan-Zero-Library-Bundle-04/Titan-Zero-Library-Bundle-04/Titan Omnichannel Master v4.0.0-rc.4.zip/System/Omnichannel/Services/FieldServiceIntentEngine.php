<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\FieldServiceContextProvider;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\IntentClassifier;use App\Extensions\MarketingBot\System\Omnichannel\Models\FieldServiceContext;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelConversation;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelMessage;
final class FieldServiceIntentEngine {
 public function __construct(private FieldServiceContextProvider$context,private IntentClassifier$classifier,private FieldServiceInbox$inbox){}
 public function analyze(OmnichannelMessage$m):FieldServiceContext {
  $c=OmnichannelConversation::query()->where('company_id',$m->company_id)->findOrFail($m->conversation_id);
  if((int)$c->company_id!==(int)$m->company_id)throw new \LogicException('Cross-company intent analysis rejected.');
  $company=$this->context->company((int)$c->company_id);$company['services']=$this->context->services((int)$c->company_id);
  $intent=$this->classifier->classify((string)$m->body,$company,['site_id'=>$c->site_id??null,'journey_stage'=>$c->journey_stage??'enquiry']);
  $stage=match($intent->intent){'quote_request'=>'quote','booking_request','reschedule','cancellation'=>'booking','job_question','technician_eta','variation'=>'job','invoice_question'=>'invoice','payment_question'=>'payment','review'=>'review','complaint'=>'complaint',default=>'enquiry'};
  $priority=$intent->emergency?'emergency':$intent->urgency;$this->inbox->classify($c,$stage,$intent->serviceKey,$priority);
  if($intent->emergency)$this->inbox->assign($c,'human_owned','queue','emergency');
  return FieldServiceContext::query()->updateOrCreate(['company_id'=>$c->company_id,'conversation_id'=>(string)$c->getKey()],['service_key'=>$intent->serviceKey,'site_id'=>$intent->siteId,'urgency'=>$intent->urgency,'emergency'=>$intent->emergency,'intent'=>$intent->intent,'confidence'=>$intent->confidence,'requested_availability'=>$intent->requestedAvailability,'missing_fields'=>$intent->missingFields,'signals'=>$intent->signals,'source_refs'=>[['message_id'=>(string)$m->getKey(),'channel'=>$m->channel]]]);
 }
}