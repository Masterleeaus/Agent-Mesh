<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface FieldServiceContextProvider {
 /** Return factual company context only. Unknown facts must be null/empty, never invented. */
 public function company(int $companyId):array;
 public function services(int $companyId):array;
 public function sites(int $companyId,?string $customerId=null):array;
}