<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class VoiceBusinessGuard{
 public function evaluate(array$turn):array{
  $claims=(array)($turn['claims']??[]);$blocked=['price','appointment_availability','booking_confirmation','licence','service_coverage','emergency_availability','refund','discount'];
  $unknown=array_values(array_intersect($blocked,$claims));$action=(bool)($turn['business_action']??false);$authority=(bool)($turn['authority_verified']??false);
  if($unknown)return ['speak'=>false,'handoff'=>true,'reason'=>'authoritative_business_fact_required','blocked_claims'=>$unknown];
  if($action&&!$authority)return ['speak'=>false,'handoff'=>true,'reason'=>'business_action_requires_authority'];
  return ['speak'=>true,'handoff'=>false];
 }}
