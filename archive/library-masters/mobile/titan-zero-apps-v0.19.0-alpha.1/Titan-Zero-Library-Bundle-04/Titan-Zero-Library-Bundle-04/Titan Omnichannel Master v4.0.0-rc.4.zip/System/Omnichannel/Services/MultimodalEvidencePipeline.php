<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\MultimodalIntelligenceProvider;
final class MultimodalEvidencePipeline{
 public function __construct(private MultimodalArtifactCatalog$catalog,private MultimodalIntelligenceProvider$provider){}
 public function inspect(int$companyId,string$conversationId,array$artifact,array$context=[]):array{
  if($companyId<=0||$conversationId==='')throw new \InvalidArgumentException('company_id and conversation required.');$kind=(string)($artifact['kind']??'');$this->catalog->assert($kind);
  if(($artifact['secure_fetch_verified']??false)!==true)return ['accepted'=>false,'reason'=>'secure_artifact_fetch_required'];
  if(($artifact['malware_scan_passed']??false)!==true)return ['accepted'=>false,'reason'=>'artifact_security_scan_required'];
  $r=$this->provider->analyze($companyId,$conversationId,$artifact,$context+['requested_intelligence'=>$this->catalog->intelligence($kind)]);
  return ['accepted'=>true,'analysis'=>$r,'provenance'=>['channel'=>$artifact['channel']??null,'provider'=>$artifact['provider']??null,'external_message_id'=>$artifact['external_message_id']??null,'artifact_id'=>$artifact['artifact_id']??null],'business_action_authorized'=>false];
 }}
