<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\ProductionDependencyProbe;
final class FailClosedProductionDependencyProbe implements ProductionDependencyProbe{
public function probe(int $companyId):array{return ['database'=>true,'queue'=>false,'cache'=>false,'scheduler'=>false,'credential_vault'=>false,'webhook_ingress'=>false,'knowledge_authority'=>false,'workforce'=>false,'audit'=>false,'reason'=>'host_runtime_probe_not_connected'];}}
