<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class CrossCompanyBoundaryGuard{
public function assertSame(int $contextCompanyId,int ...$resourceCompanyIds):void{if($contextCompanyId<=0)throw new \LogicException('Missing company context.');foreach($resourceCompanyIds as $id)if($id!==$contextCompanyId)throw new \LogicException('Cross-company resource access rejected.');}
public function filter(int $contextCompanyId,array $records):array{return array_values(array_filter($records,fn($r)=>(int)($r['company_id']??0)===$contextCompanyId));}}
