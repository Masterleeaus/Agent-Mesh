<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\FieldServiceContextProvider;
final class SafeLocalFieldServiceContextProvider implements FieldServiceContextProvider {
 public function company(int$companyId):array{if($companyId<=0)throw new \InvalidArgumentException('company_id required.');return ['company_id'=>$companyId,'business_name'=>null,'vertical'=>null,'hours'=>[],'emergency_availability'=>null,'service_areas'=>[],'quote_url'=>null,'booking_url'=>null,'review_url'=>null,'licence_statements'=>[]];}
 public function services(int$companyId):array{if($companyId<=0)throw new \InvalidArgumentException('company_id required.');return [];}
 public function sites(int$companyId,?string$customerId=null):array{if($companyId<=0)throw new \InvalidArgumentException('company_id required.');return [];}
}