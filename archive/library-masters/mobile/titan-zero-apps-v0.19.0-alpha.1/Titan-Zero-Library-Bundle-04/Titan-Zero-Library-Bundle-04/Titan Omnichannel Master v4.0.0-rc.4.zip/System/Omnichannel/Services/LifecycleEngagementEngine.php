<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\AudienceProvider;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationPolicy;use App\Extensions\MarketingBot\System\Omnichannel\Models\EngagementProgram;use App\Extensions\MarketingBot\System\Omnichannel\Models\EngagementEnrolment;
final class LifecycleEngagementEngine{
 public function __construct(private EngagementProgramCatalog$catalog,private AudienceProvider$audience,private CommunicationPolicy$policy){}
 public function enrol(EngagementProgram$p,int$limit=500):array{
  $this->catalog->assert($p->program_type);$rows=[];$candidates=$this->audience->candidates((int)$p->company_id,(array)$p->audience_rules,$limit);
  foreach($candidates as$c){$identity=(string)($c['customer_identity_id']??'');if($identity==='')continue;$channels=(array)($p->channel_order?:['email','sms','whatsapp','messenger']);
   $d=$this->policy->evaluate((int)$p->company_id,$identity,$this->catalog->purpose($p->program_type),$channels,['quiet_hours'=>(bool)($c['quiet_hours']??false)]);
   $state=($d['allowed']??false)?'eligible':'suppressed';$reason=(string)($d['reason']??'policy_denied');$key=hash('sha256',implode('|',[$p->company_id,$p->id,$identity]));
   $rows[]=EngagementEnrolment::query()->firstOrCreate(['company_id'=>$p->company_id,'idempotency_key'=>$key],['program_id'=>$p->id,'customer_identity_id'=>$identity,'state'=>$state,'reason'=>$reason,'context'=>['channels'=>$d['channels']??[],'source'=>$c['source']??null]]);
  }return $rows;
 }
 public function legacyCampaignBoundary():array{return ['legacy_campaigns'=>'compatibility_only','canonical_runtime'=>'ext_omni_engagement_programs','direct_channel_campaign_execution'=>false];}
}