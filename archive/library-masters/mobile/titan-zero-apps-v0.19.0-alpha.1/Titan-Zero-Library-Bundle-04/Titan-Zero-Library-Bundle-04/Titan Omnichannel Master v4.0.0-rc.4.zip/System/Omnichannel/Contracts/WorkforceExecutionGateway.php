<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface WorkforceExecutionGateway{public function propose(int $companyId,string $responsibility,array $action,array $context=[]):array;public function execute(int $companyId,string $proposalId,array $authority):array;}