<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MissedCallRecoveryPlanner{
 public function plan(int$companyId,string$caller,array$context=[]):array{
  if($companyId<=0||$caller==='')throw new \InvalidArgumentException('company_id and caller required.');
  return ['create_conversation'=>true,'channel'=>'voice','event'=>'missed_call','caller'=>$caller,'attempt_callback'=>(bool)($context['callback_allowed']??false),'fallback_channels'=>['sms','rcs','whatsapp'],'requires_communication_policy'=>true,'requires_cost_router'=>true];
 }}
