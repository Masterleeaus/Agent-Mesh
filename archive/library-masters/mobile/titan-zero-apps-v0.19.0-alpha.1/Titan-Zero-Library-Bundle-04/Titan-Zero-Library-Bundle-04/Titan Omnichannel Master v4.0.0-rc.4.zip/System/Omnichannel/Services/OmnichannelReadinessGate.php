<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\ProductionDependencyProbe;
final class OmnichannelReadinessGate{
public function __construct(private ProductionDependencyProbe $probe){}
public function assess(int $companyId):array{if($companyId<=0)throw new \InvalidArgumentException('company_id required.');$p=$this->probe->probe($companyId);
$required=['database','queue','cache','scheduler','credential_vault','webhook_ingress','knowledge_authority','workforce','audit'];
$missing=[];foreach($required as $k)if(($p[$k]??false)!==true)$missing[]=$k;
return ['ready'=>count($missing)===0,'missing'=>$missing,'checks'=>$p,'fail_closed'=>true];}}
