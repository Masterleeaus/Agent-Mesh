<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class PublicToPrivateEscalation{
 public function plan(array$interaction,string$reason,array$context=[]):array{
  if(($interaction['kind']??null)!=='public_interaction')throw new \InvalidArgumentException('Escalation requires public interaction.');
  return ['action'=>'private_handoff','source_interaction_id'=>$interaction['external_id']??null,'author_external_id'=>$interaction['author_external_id']??null,'reason'=>$reason,'public_reply'=>$context['public_reply']??null,'private_message'=>$context['private_message']??null,'preserve_public_provenance'=>true,'requires_provider_permission'=>true,'requires_communication_policy'=>true];
 }}
