<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class RcsInteractionNormalizer{
 public function normalize(array$p):array{$type=(string)($p['type']??'text');if(!in_array($type,['text','suggested_reply','suggested_action','rich_card_action','location'],true))throw new \InvalidArgumentException('Unsupported RCS interaction.');return ['type'=>$type,'text'=>$p['text']??null,'action_id'=>$p['action_id']??null,'payload'=>$p['payload']??null,'external_message_id'=>$p['message_id']??null];}
}