<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\FirstPartyIdentityVerifier;
final class FailClosedFirstPartyIdentityVerifier implements FirstPartyIdentityVerifier{public function verify(int$companyId,string$surface,string$principalType,string$principalId,array$proof=[]):array{return ['verified'=>false,'reason'=>'authenticated_titan_principal_required'];}}
