<?php

namespace App\Extensions\MarketingBot\System\Models\Whatsapp;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use App\Extensions\MarketingBot\System\Contracts\CompanyContext;

class WhatsappChannel extends Model
{
    protected $table = 'ext_whatsapp_channels';

    protected $hidden = ['whatsapp_token', 'meta_access_token', 'meta_verify_token'];

    protected $casts = [
        'whatsapp_token' => 'encrypted',
        'meta_access_token' => 'encrypted',
        'meta_verify_token' => 'encrypted',
    ];

    protected $fillable = [
        'company_id',
        'user_id',
        'whatsapp_provider',
        'whatsapp_sid',
        'whatsapp_token',
        'whatsapp_phone',
        'whatsapp_sandbox_phone',
        'whatsapp_environment',
        'meta_access_token',
        'meta_phone_number_id',
        'meta_verify_token',
        'meta_waba_id',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('company_id', function (Builder $query): void {
            try { $id = app(CompanyContext::class)->id(); } catch (\Throwable) { $id = null; }
            if (! $id) { $query->whereRaw('1=0'); return; }
            $query->where($query->getModel()->getTable() . '.company_id', $id);
        });
        static::creating(function (Model $model): void {
            if (! (int) ($model->company_id ?? 0)) { $model->company_id = app(CompanyContext::class)->id(); }
        });
    }

    public function isSandbox(): bool
    {
        return $this->whatsapp_environment === 'sandbox';
    }

    public function isMeta(): bool
    {
        return $this->whatsapp_provider === 'meta';
    }

    public function isTwilio(): bool
    {
        return $this->whatsapp_provider !== 'meta';
    }
}
