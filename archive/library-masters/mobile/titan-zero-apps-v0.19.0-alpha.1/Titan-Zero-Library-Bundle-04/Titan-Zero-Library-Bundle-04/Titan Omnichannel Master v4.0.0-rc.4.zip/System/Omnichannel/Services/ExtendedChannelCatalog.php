<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class ExtendedChannelCatalog{public function definitions():array{return[
'apple_messages_for_business'=>['status'=>'provider_dependent','capabilities'=>['text','image','video','document','buttons','list_picker','time_picker','rich_links','authentication']],
'line'=>['status'=>'adapter_ready','capabilities'=>['text','image','video','audio','location','template','buttons','quick_replies']],
'wechat'=>['status'=>'adapter_ready','capabilities'=>['text','image','voice_note','video','location','template']],
'viber'=>['status'=>'adapter_ready','capabilities'=>['text','image','video','document','location','buttons']],
'signal'=>['status'=>'restricted_or_nonstandard_api','capabilities'=>['text','image','video','audio','document'],'production_claim'=>false]
];}}