<?php
declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Services\Tenancy;
use App\Extensions\MarketingBot\System\Contracts\CompanyContext;
final class AuthenticatedCompanyContext implements CompanyContext { public function id(): int { $id=(int)(auth()->user()?->company_id ?? 0); if($id<=0) throw new \LogicException('Titan Omnichannel requires company_id context.'); return $id; } }
