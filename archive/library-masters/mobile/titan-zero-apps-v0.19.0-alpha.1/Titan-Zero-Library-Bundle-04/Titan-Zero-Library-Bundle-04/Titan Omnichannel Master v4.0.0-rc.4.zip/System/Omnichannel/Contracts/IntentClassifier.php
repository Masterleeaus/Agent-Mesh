<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\FieldServiceIntent;
interface IntentClassifier {public function classify(string$text,array$companyContext=[],array$conversationContext=[]):FieldServiceIntent;}
