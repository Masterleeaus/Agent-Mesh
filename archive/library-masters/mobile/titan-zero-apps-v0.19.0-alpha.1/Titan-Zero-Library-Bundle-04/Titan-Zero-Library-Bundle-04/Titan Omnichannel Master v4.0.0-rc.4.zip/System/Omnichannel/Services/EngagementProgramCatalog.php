<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class EngagementProgramCatalog{
 public const TYPES=['seasonal_service','maintenance_reminder','dormant_customer_reactivation','service_area_campaign','cross_sell','upsell','review_reputation','win_back'];
 public function assert(string$type):void{if(!in_array($type,self::TYPES,true))throw new \InvalidArgumentException('Unsupported engagement program type.');}
 public function purpose(string$type):string{return in_array($type,['maintenance_reminder','review_reputation'],true)?'review_request':'marketing.'.$type;}
}