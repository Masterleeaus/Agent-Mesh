<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class SecretHandlingPolicy{
public function validate(array $config):array{$forbidden=['access_token','refresh_token','client_secret','api_key','password','private_key'];$found=[];foreach($forbidden as $k)if(array_key_exists($k,$config)&&$config[$k]!==null&&$config[$k]!=='')$found[]=$k;return ['accepted'=>count($found)===0,'forbidden_inline_secrets'=>$found,'credential_reference_required'=>true,'redact_logs'=>true,'rotation_supported'=>true];}}
