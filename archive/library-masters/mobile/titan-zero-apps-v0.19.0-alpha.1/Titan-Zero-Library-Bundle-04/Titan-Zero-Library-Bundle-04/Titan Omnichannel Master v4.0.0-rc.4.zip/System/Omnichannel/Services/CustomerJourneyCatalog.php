<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class CustomerJourneyCatalog{
 public const JOURNEYS=[
 'lead_response'=>['purpose'=>'transactional.lead_response','authority'=>'assist'],
 'quote_followup'=>['purpose'=>'transactional.quote_followup','authority'=>'assist'],
 'booking_confirmation'=>['purpose'=>'transactional.booking_confirmation','authority'=>'assist'],
 'booking_reminder'=>['purpose'=>'transactional.booking_reminder','authority'=>'assist'],
 'technician_on_way'=>['purpose'=>'transactional.technician_on_way','authority'=>'assist'],
 'job_update'=>['purpose'=>'transactional.job_update','authority'=>'assist'],
 'variation_approval'=>['purpose'=>'transactional.variation_approval','authority'=>'approval'],
 'job_completion'=>['purpose'=>'transactional.job_completion','authority'=>'assist'],
 'invoice_followup'=>['purpose'=>'transactional.invoice_followup','authority'=>'assist'],
 'payment_reminder'=>['purpose'=>'transactional.payment_reminder','authority'=>'assist'],
 'review_request'=>['purpose'=>'review_request','authority'=>'assist'],
 'complaint_recovery'=>['purpose'=>'transactional.complaint_recovery','authority'=>'approval'],
 'recurring_service_reminder'=>['purpose'=>'seasonal_reminder','authority'=>'assist'],
 'win_back'=>['purpose'=>'win_back','authority'=>'assist']
 ];
 public function get(string$key):array{if(!isset(self::JOURNEYS[$key]))throw new \InvalidArgumentException('Unknown customer journey.');return self::JOURNEYS[$key];}
}