<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class VoicemailIngestionPlanner{
 public function plan(int$companyId,string$callId,array$context=[]):array{return ['company_id'=>$companyId,'call_id'=>$callId,'secure_audio_fetch'=>true,'transcribe'=>true,'attach_to_conversation'=>true,'intent_analysis'=>true,'urgent_signal_review'=>true,'human_review_if_low_confidence'=>true,'retain_recording_only_per_policy'=>true];}
}