<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface MetaTransport{
 public function capabilities(string$surface):array;
 public function normalizeWebhook(int$companyId,string$surface,array$payload):array;
 public function sendPrivate(int$companyId,string$surface,string$recipientId,array$message):array;
 public function replyPublic(int$companyId,string$surface,string$interactionId,string$body):array;
}