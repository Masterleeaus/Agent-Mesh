<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MobileMessagingFallbackPlanner{
 public function plan(array$recipient,array$message):array{
  $text=(string)($message['text']??$message['fallback_text']??'');$media=(array)($message['media']??[]);$rich=(bool)($message['rich']??false);
  if(($recipient['rcs']??false)===true)return ['channel'=>'rcs','message'=>$message,'degraded'=>false];
  if($media&&($recipient['mms']??false)===true)return ['channel'=>'mms','message'=>['text'=>$text,'media'=>$media],'degraded'=>$rich,'degraded_from'=>$rich?'rcs':null];
  if($text!=='')return ['channel'=>'sms','message'=>['text'=>$text],'degraded'=>$rich||count($media)>0,'degraded_from'=>$rich?'rcs':($media?'mms':null)];
  return ['channel'=>null,'sendable'=>false,'reason'=>'no_safe_mobile_fallback'];
 }}
