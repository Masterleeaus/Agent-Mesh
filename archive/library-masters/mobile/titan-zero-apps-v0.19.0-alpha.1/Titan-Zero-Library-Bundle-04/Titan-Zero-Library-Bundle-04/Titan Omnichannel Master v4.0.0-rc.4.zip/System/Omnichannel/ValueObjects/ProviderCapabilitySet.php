<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class ProviderCapabilitySet{
 public function __construct(public string$provider,public string$channel,public array$contentKinds=['text'],public array$features=[],public array$limits=[]){}
 public function supportsContent(string$kind):bool{return in_array($kind,$this->contentKinds,true);}
 public function supportsFeature(string$feature):bool{return in_array($feature,$this->features,true);}
}