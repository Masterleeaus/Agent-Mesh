<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface MultimodalIntelligenceProvider{
 public function analyze(int$companyId,string$conversationId,array$artifact,array$context=[]):array;
}