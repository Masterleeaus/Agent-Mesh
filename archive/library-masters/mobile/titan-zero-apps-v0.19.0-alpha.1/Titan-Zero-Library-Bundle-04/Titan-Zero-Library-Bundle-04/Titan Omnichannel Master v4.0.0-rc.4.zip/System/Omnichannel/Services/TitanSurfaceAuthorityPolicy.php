<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class TitanSurfaceAuthorityPolicy{
 public function canonicalSurface(string $surface):string{return match($surface){
  'zero','go','hub'=>$surface,
  // Compatibility-only normalization until Agent 1 shared AppSurface resolver is universally injected.
  'titan_bos','bos','command','owner','manager','business','onboarding'=>'zero',
  'titan_go','field','worker'=>'go',
  'titan_hub','customer'=>'hub',
  default=>$surface};}
 public function maximumScope(string$surface,string$principalType):array{
  $surface=$this->canonicalSurface($surface);
  return match($surface){
   'zero'=>['scope'=>'authenticated_role_authorized','may_span_company'=>true],
   'go'=>['scope'=>'self_and_assigned_work','may_span_company'=>false],
   'hub'=>['scope'=>'customer_owned_and_service_related','may_span_company'=>false],
   'web_chat','web_form'=>['scope'=>'public_customer_entry','may_span_company'=>false],
   'in_app','pwa_push'=>['scope'=>'inherits_authenticated_surface','may_span_company'=>false],
   default=>throw new \InvalidArgumentException('Unknown Titan surface.')};
 }
}
