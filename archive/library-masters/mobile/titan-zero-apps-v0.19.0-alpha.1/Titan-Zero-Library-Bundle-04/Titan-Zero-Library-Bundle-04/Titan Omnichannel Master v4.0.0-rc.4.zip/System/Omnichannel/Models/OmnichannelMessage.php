<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Models;
use Illuminate\Database\Eloquent\Builder;use Illuminate\Database\Eloquent\Model;use App\Extensions\MarketingBot\System\Contracts\CompanyContext;
final class OmnichannelMessage extends Model {protected $table='ext_omni_messages';protected $guarded=[];public $incrementing=false;protected $keyType='string';protected static function booted():void {static::addGlobalScope('company_id',function(Builder $q):void {try{$id=app(CompanyContext::class)->id();}catch(\Throwable){$id=null;}if(!$id){$q->whereRaw('1=0');return;}$q->where($q->getModel()->getTable().'.company_id',$id);});static::creating(function(Model $m):void{if(!(int)($m->company_id??0)){$id=app(CompanyContext::class)->id();if(!$id)throw new \LogicException('Titan Omnichannel requires company_id context.');$m->company_id=$id;}});}}
