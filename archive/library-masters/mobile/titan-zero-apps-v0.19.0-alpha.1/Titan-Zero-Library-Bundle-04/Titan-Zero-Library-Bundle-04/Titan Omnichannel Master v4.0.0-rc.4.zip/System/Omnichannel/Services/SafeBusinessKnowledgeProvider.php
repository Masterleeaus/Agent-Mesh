<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\BusinessKnowledgeProvider;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\FieldServiceContextProvider;
final class SafeBusinessKnowledgeProvider implements BusinessKnowledgeProvider{
 public function __construct(private FieldServiceContextProvider$context){}
 public function retrieve(int$companyId,string$query,array$context=[]):array{
  if($companyId<=0)throw new \InvalidArgumentException('company_id required.');
  $company=$this->context->company($companyId);$services=$this->context->services($companyId);
  return ['facts'=>['company'=>$company,'services'=>$services],'unknowns'=>$this->unknowns($company),'provenance'=>[['source'=>'field_service_context','company_id'=>$companyId]],'query'=>$query];
 }
 private function unknowns(array$c):array{$u=[];foreach(['business_name','vertical','emergency_availability','quote_url','booking_url','review_url']as$k)if(!array_key_exists($k,$c)||$c[$k]===null||$c[$k]===[])$u[]=$k;return $u;}
}