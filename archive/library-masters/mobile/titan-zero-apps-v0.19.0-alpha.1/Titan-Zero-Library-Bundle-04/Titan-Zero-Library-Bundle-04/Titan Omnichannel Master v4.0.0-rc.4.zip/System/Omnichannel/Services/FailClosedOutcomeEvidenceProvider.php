<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\OutcomeEvidenceProvider;
final class FailClosedOutcomeEvidenceProvider implements OutcomeEvidenceProvider{public function verify(int$companyId,string$outcomeKey,?string$objectType,?string$objectId,array$evidence=[]):array{return ['verified'=>false,'reason'=>'authoritative_outcome_evidence_required','evidence'=>$evidence];}}
