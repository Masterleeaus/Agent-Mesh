<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface ProviderCapabilities{public function capabilities():array;}
