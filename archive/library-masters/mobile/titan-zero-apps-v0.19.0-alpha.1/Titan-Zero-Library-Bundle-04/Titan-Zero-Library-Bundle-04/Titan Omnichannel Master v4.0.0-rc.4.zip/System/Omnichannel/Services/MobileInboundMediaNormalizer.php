<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MobileInboundMediaNormalizer{
 public function normalize(int$companyId,string$channel,string$from,array$p):array{
  if(!in_array($channel,['sms','mms','rcs'],true))throw new \InvalidArgumentException('Unsupported mobile channel.');
  $media=[];foreach((array)($p['media']??[])as$m)$media[]=['url'=>$m['url']??null,'mime_type'=>$m['mime_type']??null,'filename'=>$m['filename']??null,'size'=>$m['size']??null,'requires_secure_fetch'=>true,'vision_candidate'=>$this->vision((string)($m['mime_type']??''))];
  return ['company_id'=>$companyId,'channel'=>$channel,'from'=>$from,'text'=>(string)($p['text']??''),'media'=>$media,'external_message_id'=>$p['id']??null,'delivery'=>$p['delivery']??null,'read'=>$p['read']??null,'provenance'=>['provider'=>$p['provider']??null,'channel'=>$channel]];
 }
 private function vision(string$mime):bool{return str_starts_with($mime,'image/')||str_starts_with($mime,'video/')||$mime==='application/pdf';}
}