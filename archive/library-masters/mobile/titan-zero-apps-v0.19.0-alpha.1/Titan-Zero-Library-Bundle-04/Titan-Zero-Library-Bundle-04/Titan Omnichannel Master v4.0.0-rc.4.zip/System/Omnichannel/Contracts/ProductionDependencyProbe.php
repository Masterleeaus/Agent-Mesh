<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface ProductionDependencyProbe{public function probe(int $companyId):array;}