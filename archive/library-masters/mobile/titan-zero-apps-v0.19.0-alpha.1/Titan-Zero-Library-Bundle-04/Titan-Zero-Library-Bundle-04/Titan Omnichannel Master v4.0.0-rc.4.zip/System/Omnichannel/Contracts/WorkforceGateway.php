<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface WorkforceGateway{
 public function resolveResponsibility(int$companyId,string$capability,array$context=[]):array;
 public function checkAuthority(int$companyId,string$actorType,string$actorId,string$capability,string$autonomy,array$context=[]):array;
 public function requestApproval(int$companyId,string$capability,array$context=[]):array;
 public function execute(int$companyId,string$capability,array$context=[]):array;
}