<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class WebFormConversationMapper{
 public function normalize(array$form):array{
  $kind=(string)($form['form_kind']??'contact');if(!in_array($kind,['contact','quote','service_request','booking_request','support'],true))throw new \InvalidArgumentException('Unsupported web form kind.');
  return ['channel'=>'web_form','intent_hint'=>$kind,'body'=>(string)($form['message']??''),'structured'=>array_intersect_key($form,array_flip(['service','site','preferred_date','preferred_time','urgency','name','email','phone'])),'attachments'=>(array)($form['attachments']??[])];
 }}
