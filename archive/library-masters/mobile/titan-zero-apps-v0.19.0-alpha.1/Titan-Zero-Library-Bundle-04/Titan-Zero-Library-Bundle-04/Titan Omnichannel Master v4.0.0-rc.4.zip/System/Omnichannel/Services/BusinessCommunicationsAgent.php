<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\BusinessKnowledgeProvider;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationsAgent;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationsModel;use App\Extensions\MarketingBot\System\Omnichannel\Models\AiCommunicationRun;use App\Extensions\MarketingBot\System\Omnichannel\Models\FieldServiceContext;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelConversation;
final class BusinessCommunicationsAgent implements CommunicationsAgent{
 public function __construct(private BusinessKnowledgeProvider$knowledge,private CommunicationsModel$model,private BusinessCommunicationsGuard$guard,private ConversationSummarizer$summarizer,private FieldServiceWorkflowRecommender$workflows){}
 public function prepare(int$companyId,string$conversationId,?string$messageId=null,string$mode='assist'):AiCommunicationRun{
  $c=OmnichannelConversation::query()->where('company_id',$companyId)->findOrFail($conversationId);if((int)$c->company_id!==$companyId)throw new \LogicException('Cross-company AI communications rejected.');
  $thread=$this->summarizer->build($companyId,$conversationId);$ctx=FieldServiceContext::query()->where('company_id',$companyId)->where('conversation_id',$conversationId)->first();
  $query=(string)collect($thread['messages'])->last()['body'];$knowledge=$this->knowledge->retrieve($companyId,$query,['conversation_id'=>$conversationId]);
  $messages=[['role'=>'system','content'=>implode("\n",$this->guard->systemRules())],['role'=>'system','content'=>json_encode(['verified_business_knowledge'=>$knowledge,'field_service_context'=>$ctx?->toArray()],JSON_UNESCAPED_SLASHES)],['role'=>'user','content'=>json_encode($thread,JSON_UNESCAPED_SLASHES)]];
  $out=$this->model->complete($messages,['mode'=>$mode]);$confidence=(float)($out['confidence']??0);$decision=$this->guard->evaluate($knowledge,$out,$confidence);
  $actions=[];if($ctx&&($rec=$this->workflows->recommend($ctx)))$actions[]=['workflow'=>$rec->workflow,'reason'=>$rec->reason,'required_fields'=>$rec->requiredFields,'requires_authority'=>$rec->requiresAuthority];
  $key=hash('sha256',implode('|',[$companyId,$conversationId,(string)$messageId,$mode]));
  return AiCommunicationRun::query()->firstOrCreate(['company_id'=>$companyId,'idempotency_key'=>$key],['conversation_id'=>$conversationId,'message_id'=>$messageId,'mode'=>$mode,'status'=>$decision['may_send']?'draft_ready':'handoff_required','confidence'=>$confidence,'summary'=>$out['summary']??null,'draft'=>$out['draft']??null,'facts_used'=>$out['facts_used']??[],'unknowns'=>$decision['unknowns'],'proposed_actions'=>$actions,'handoff_reasons'=>$decision['handoff_reasons']]);
 }
}