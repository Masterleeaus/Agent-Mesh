<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MultiAgentVerificationPolicy{
public function requirements(array $action):array{$impact=(string)($action['impact']??'low');$external=(bool)($action['external_effect']??false);$financial=(bool)($action['financial_effect']??false);$required=$financial||$external||in_array($impact,['high','critical'],true);return ['independent_check_required'=>$required,'minimum_checkers'=>$required?2:1,'same_agent_self_approval'=>false,'authority_still_required'=>true];}
}