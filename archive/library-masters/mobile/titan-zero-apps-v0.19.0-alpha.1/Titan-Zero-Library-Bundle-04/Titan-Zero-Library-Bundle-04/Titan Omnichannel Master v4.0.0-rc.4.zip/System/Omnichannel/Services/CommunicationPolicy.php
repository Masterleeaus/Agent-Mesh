<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;use App\Extensions\MarketingBot\System\Omnichannel\Models\ChannelPreference;
final class CommunicationPolicy {public function maySend(int$identityId,string$purpose):bool{$p=ChannelPreference::query()->where('identity_id',$identityId)->first();if(!$p)return $purpose==='transactional';if($p->opted_out)return false;if($purpose==='marketing')return(bool)$p->marketing_allowed;return(bool)$p->transactional_allowed;}}
