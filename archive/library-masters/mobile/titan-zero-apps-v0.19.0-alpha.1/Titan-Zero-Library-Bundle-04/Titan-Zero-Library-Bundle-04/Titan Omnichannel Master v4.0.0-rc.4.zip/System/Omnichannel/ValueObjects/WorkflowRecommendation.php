<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class WorkflowRecommendation {public function __construct(public int$companyId,public string$conversationId,public string$workflow,public string$reason,public array$requiredFields=[],public bool$requiresAuthority=true){if($companyId<=0)throw new \InvalidArgumentException('company_id required.');}}
