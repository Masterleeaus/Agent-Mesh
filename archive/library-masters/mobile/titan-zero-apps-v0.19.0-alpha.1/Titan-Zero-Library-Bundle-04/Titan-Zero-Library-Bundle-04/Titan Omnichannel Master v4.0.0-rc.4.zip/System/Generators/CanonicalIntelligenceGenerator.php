<?php

declare(strict_types=1);

namespace App\Extensions\MarketingBot\System\Generators;

use App\Extensions\MarketingBot\System\Contracts\CompanyContext;
use App\Extensions\MarketingBot\System\Generators\Contracts\Generator;
use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/** Canonical Omnichannel conversational generation adapter. */
final class CanonicalIntelligenceGenerator extends Generator
{
    public const COMMAND_BUS_ALIAS = 'titan.apps.interaction.command-bus';
    public const CAPABILITY = 'ai.omnichannel.reply.generate';

    public function __construct(
        private readonly Container $app,
        private readonly CompanyContext $company,
        private readonly OpenAIGenerator $legacy,
    ) {}

    public function generate(): string
    {
        if ($this->app->bound(self::COMMAND_BUS_ALIAS)) {
            $bus = $this->app->make(self::COMMAND_BUS_ALIAS);
            if (is_object($bus) && method_exists($bus, 'dispatchResult')) {
                try {
                    $history = [];
                    foreach ($this->histories() as $row) {
                        $history[] = ['role' => (string) $row->role, 'content' => (string) $row->message];
                    }
                    $result = $bus->dispatchResult(self::CAPABILITY, [
                        'company_id' => $this->company->id(),
                        'actor_id' => (int) $this->marketingCampaign->user_id,
                        'campaign_id' => (int) $this->marketingCampaign->id,
                        'conversation_id' => (int) $this->conversation->id,
                        'prompt' => $this->prompt,
                        'history' => $history,
                        'campaign_instruction' => (string) ($this->marketingCampaign->instruction ?? ''),
                        'requested_model' => $this->entity->value,
                        'knowledge_source' => 'titan-omnichannel.campaign-knowledge',
                        'source_extension' => 'titan-omnichannel',
                    ]);
                    $text = $this->extractText($result);
                    if ($text !== null) {
                        return $text;
                    }
                    throw new RuntimeException('Canonical Omnichannel intelligence returned no usable text.');
                } catch (Throwable $e) {
                    if (! (bool) config('marketing-bot.ai.allow_legacy_generation_fallback', false)) {
                        throw new RuntimeException('Unable to generate the Omnichannel reply through governed Titan intelligence.', previous: $e);
                    }
                }
            }
        }

        if (! (bool) config('marketing-bot.ai.allow_legacy_generation_fallback', false)) {
            throw new RuntimeException('Canonical Titan intelligence routing is unavailable for Omnichannel generation.');
        }

        return $this->legacy
            ->setConversation($this->conversation)
            ->setMarketingCampaign($this->marketingCampaign)
            ->setEntity($this->entity)
            ->setPrompt($this->prompt)
            ->generate();
    }

    private function extractText(mixed $result): ?string
    {
        $payload = is_object($result) && method_exists($result, 'toArray') ? $result->toArray() : $result;
        if (is_object($payload)) $payload = get_object_vars($payload);
        if (! is_array($payload)) return null;
        foreach (['result','data','output','capability_result'] as $key) {
            if (isset($payload[$key]) && is_array($payload[$key])) { $payload = $payload[$key]; break; }
        }
        foreach (['text','message','content','reply','result'] as $key) {
            if (isset($payload[$key]) && is_scalar($payload[$key])) {
                $text = trim((string) $payload[$key]);
                if ($text !== '') return $text;
            }
        }
        return null;
    }
}
