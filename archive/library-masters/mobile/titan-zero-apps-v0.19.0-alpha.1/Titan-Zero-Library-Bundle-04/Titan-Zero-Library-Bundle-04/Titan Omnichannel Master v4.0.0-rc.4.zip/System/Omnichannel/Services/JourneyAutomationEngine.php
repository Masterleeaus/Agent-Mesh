<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationPolicy;use App\Extensions\MarketingBot\System\Omnichannel\Models\JourneyAutomation;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelConversation;
final class JourneyAutomationEngine{
 public function __construct(private CustomerJourneyCatalog$catalog,private CommunicationPolicy$policy){}
 public function prepare(JourneyAutomation$a,array$availableChannels=['sms','whatsapp','email','messenger']):array{
  $c=OmnichannelConversation::query()->where('company_id',$a->company_id)->findOrFail($a->conversation_id);
  if((int)$c->company_id!==(int)$a->company_id)throw new \LogicException('Cross-company journey rejected.');
  $identity=(string)($c->customer_identity_id??'');if($identity==='')return $this->hold($a,'customer_identity_required');
  $j=$this->catalog->get($a->journey_key);$payload=(array)$a->payload;
  $decision=$this->policy->evaluate((int)$a->company_id,$identity,$j['purpose'],$availableChannels,['quiet_hours'=>(bool)($payload['quiet_hours']??false),'emergency'=>(bool)($payload['emergency']??false)]);
  if(!$decision['allowed'])return $this->hold($a,(string)$decision['reason']);
  if($j['authority']==='approval'&&!($payload['approved']??false))return $this->hold($a,'approval_required');
  $a->forceFill(['state'=>'ready','channel_plan'=>$decision['channels']])->save();
  return ['state'=>'ready','channels'=>$decision['channels'],'purpose'=>$j['purpose'],'authority'=>$j['authority']];
 }
 public function recordAttempt(JourneyAutomation$a,bool$success,?string$error=null):void{$attempts=(int)$a->attempts+1;$max=3;$state=$success?'completed':($attempts>=$max?'failed':'pending');$a->forceFill(['attempts'=>$attempts,'state'=>$state,'executed_at'=>$success?now():null,'payload'=>array_merge((array)$a->payload,$error?['last_error'=>$error]:[])])->save();}
 private function hold(JourneyAutomation$a,string$reason):array{$a->forceFill(['state'=>'held','payload'=>array_merge((array)$a->payload,['hold_reason'=>$reason])])->save();return ['state'=>'held','reason'=>$reason];}
}