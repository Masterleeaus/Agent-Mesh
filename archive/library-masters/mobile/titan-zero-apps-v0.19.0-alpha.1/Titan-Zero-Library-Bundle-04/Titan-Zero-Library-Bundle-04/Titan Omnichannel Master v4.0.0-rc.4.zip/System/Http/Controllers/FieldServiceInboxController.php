<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Http\Controllers;
use App\Http\Controllers\Controller;use Illuminate\Http\Request;use App\Extensions\MarketingBot\System\Omnichannel\Services\FieldServiceInbox;
final class FieldServiceInboxController extends Controller {
 public function __construct(private FieldServiceInbox $inbox){}
 public function index(Request $r){return response()->json($this->inbox->queue((string)$r->input('view','all'),$r->input('channel'),$r->input('search'),min(100,max(1,(int)$r->input('per_page',30)))));}
}