<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class ProviderFailurePolicy{
public function classify(string $failure,int $attempt):array{$retryable=in_array($failure,['timeout','rate_limit','provider_5xx','temporary_network'],true);$max=5;$retry=$retryable&&$attempt<$max;return ['retry'=>$retry,'max_attempts'=>$max,'backoff_seconds'=>$retry?min(3600,30*(2**max(0,$attempt-1))):null,'dead_letter'=>!$retry,'preserve_idempotency_key'=>true,'alert'=>!$retry];}}
