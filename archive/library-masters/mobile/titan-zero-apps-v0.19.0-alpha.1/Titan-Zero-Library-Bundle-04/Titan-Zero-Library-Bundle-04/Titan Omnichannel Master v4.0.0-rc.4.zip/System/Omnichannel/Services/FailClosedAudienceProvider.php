<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\AudienceProvider;
final class FailClosedAudienceProvider implements AudienceProvider{public function candidates(int$companyId,array$rules,int$limit=500):array{return [];}}
