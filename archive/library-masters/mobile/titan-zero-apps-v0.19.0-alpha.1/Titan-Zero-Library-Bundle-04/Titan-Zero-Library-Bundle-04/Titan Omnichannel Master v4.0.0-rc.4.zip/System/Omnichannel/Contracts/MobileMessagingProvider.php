<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface MobileMessagingProvider extends ChannelProvider,ProviderCapabilities{
 public function recipientCapabilities(int$companyId,string$address):array;
 public function sendRcs(int$companyId,string$address,array$message):array;
 public function sendMms(int$companyId,string$address,array$message):array;
 public function sendSms(int$companyId,string$address,string$body,array$context=[]):array;
}