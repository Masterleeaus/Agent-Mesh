<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class VoiceReceptionCapabilityCatalog{public function all():array{return[
'inbound_call','outbound_call','answer','realtime_transcription','realtime_speech','conversation_relay','websocket','dtmf','human_transfer','callback','voicemail','voicemail_transcription','recording','call_summary','after_call_workflow','missed_call_recovery','call_status'
];}}
