<?php
declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Contracts;
interface CompanyContext { public function id(): int; }
