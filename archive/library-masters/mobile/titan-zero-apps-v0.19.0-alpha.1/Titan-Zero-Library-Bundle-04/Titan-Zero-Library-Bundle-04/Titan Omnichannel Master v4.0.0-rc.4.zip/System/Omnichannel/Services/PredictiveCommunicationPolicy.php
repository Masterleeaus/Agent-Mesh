<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class PredictiveCommunicationPolicy{
public function evaluate(array $prediction,array $context=[]):array{$confidence=(float)($prediction['confidence']??0);$impact=(string)($prediction['impact']??'low');$customerFacing=(bool)($prediction['customer_facing']??false);$threshold=(float)($context['threshold']??0.85);
if($confidence<$threshold)return ['allowed'=>false,'reason'=>'prediction_confidence_below_threshold'];
if(in_array($impact,['high','critical'],true))return ['allowed'=>false,'reason'=>'high_impact_prediction_requires_review','review'=>true];
return ['allowed'=>!$customerFacing||($context['customer_contact_authorized']??false),'requires_communication_policy'=>$customerFacing,'requires_cost_router'=>$customerFacing,'execution_authorized'=>false];}
}