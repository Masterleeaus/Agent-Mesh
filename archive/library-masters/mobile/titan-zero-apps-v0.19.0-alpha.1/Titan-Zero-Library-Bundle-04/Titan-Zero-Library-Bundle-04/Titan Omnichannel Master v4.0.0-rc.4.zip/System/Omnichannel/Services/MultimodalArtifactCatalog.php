<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MultimodalArtifactCatalog{
 public const KINDS=['image','video','pdf','document','screenshot','camera_capture','voice_note','audio'];
 public function assert(string$kind):void{if(!in_array($kind,self::KINDS,true))throw new \InvalidArgumentException('Unsupported multimodal artifact.');}
 public function intelligence(string$kind):array{return match($kind){'image','video','screenshot','camera_capture'=>['vision'],'pdf','document'=>['document','vision_if_pages_rendered'],'voice_note','audio'=>['speech','audio'],default=>[]};}
}