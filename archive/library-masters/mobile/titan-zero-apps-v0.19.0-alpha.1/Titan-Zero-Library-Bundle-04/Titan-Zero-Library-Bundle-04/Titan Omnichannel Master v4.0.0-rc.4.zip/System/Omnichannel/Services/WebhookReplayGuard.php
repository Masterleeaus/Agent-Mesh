<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class WebhookReplayGuard{
public function evaluate(int $companyId,string $provider,string $eventId,int $occurredAt,int $now,array $seen=[]):array{
if($companyId<=0||$eventId==='')return ['accept'=>false,'reason'=>'invalid_webhook_identity'];
if(abs($now-$occurredAt)>300)return ['accept'=>false,'reason'=>'webhook_timestamp_outside_window'];
$key=hash('sha256',$companyId.'|'.$provider.'|'.$eventId);if(in_array($key,$seen,true))return ['accept'=>false,'reason'=>'webhook_replay_detected','idempotency_key'=>$key];
return ['accept'=>true,'idempotency_key'=>$key,'persist_before_dispatch'=>true];}}
