<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\KnowledgeAuthorityGateway;use App\Extensions\MarketingBot\System\Omnichannel\Contracts\WorkforceExecutionGateway;
final class OmnichannelDecisionChain{
public function __construct(private KnowledgeAuthorityGateway $knowledge,private WorkforceExecutionGateway $workforce){}
public function propose(int $companyId,string $question,string $responsibility,array $action,array $context=[]):array{
$k=$this->knowledge->resolve($companyId,$question,$context);if(($k['resolved']??false)!==true)return ['proposed'=>false,'stage'=>'knowledge','reason'=>$k['reason']??'unresolved'];
if((float)($k['confidence']??0)<(float)($context['minimum_knowledge_confidence']??0.7))return ['proposed'=>false,'stage'=>'knowledge','reason'=>'knowledge_confidence_below_threshold','knowledge'=>$k];
$proposal=$this->workforce->propose($companyId,$responsibility,$action,$context+['knowledge'=>$k]);
return ['proposed'=>(bool)($proposal['accepted']??false),'stage'=>'workforce','knowledge'=>$k,'workforce'=>$proposal,'execution_authorized'=>false];}
}