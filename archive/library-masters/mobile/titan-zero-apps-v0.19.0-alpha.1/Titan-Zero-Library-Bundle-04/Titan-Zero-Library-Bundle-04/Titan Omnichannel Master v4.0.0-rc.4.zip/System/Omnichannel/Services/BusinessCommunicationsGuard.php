<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class BusinessCommunicationsGuard{
 public const PROTECTED_FACTS=['price','licence','license','availability','service_area','emergency_availability','booking_capacity','policy'];
 public function evaluate(array$knowledge,array$modelOutput,float$confidence):array{
  $unknown=(array)($knowledge['unknowns']??[]);$reasons=[];
  if($confidence<0.70)$reasons[]='low_confidence';
  if(($modelOutput['claims_unknown_fact']??false)===true)$reasons[]='unknown_fact_claim';
  if(($modelOutput['requests_business_action']??false)===true)$reasons[]='business_action_requires_authority';
  if(($modelOutput['sensitive_or_complaint']??false)===true)$reasons[]='human_review_required';
  return ['may_send'=>count($reasons)===0,'handoff_reasons'=>$reasons,'unknowns'=>$unknown];
 }
 public function systemRules():array{return[
  'Use only supplied verified business facts.',
  'Never invent prices, licences, service coverage, emergency availability, booking capacity, policies or appointment availability.',
  'If a required fact is unknown, say it is unknown or ask for the missing information.',
  'Do not promise a booking, quote, refund, variation, discount or dispatch unless an authoritative workflow confirms it.',
  'Separate a suggested action from an executed action.',
  'Escalate emergencies, complaints, sensitive disputes, low confidence and authority-gated actions.'
 ];}
}