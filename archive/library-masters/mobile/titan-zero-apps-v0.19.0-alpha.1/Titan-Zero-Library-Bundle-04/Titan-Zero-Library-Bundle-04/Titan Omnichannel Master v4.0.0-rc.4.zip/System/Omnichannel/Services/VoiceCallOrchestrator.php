<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\VoiceReceptionProvider;
final class VoiceCallOrchestrator{
 public function __construct(private VoiceReceptionProvider$voice,private VoiceBusinessGuard$guard){}
 public function begin(int$companyId,string$callId,array$context=[]):array{
  if($companyId<=0||$callId==='')throw new \InvalidArgumentException('company_id and callId required.');
  return ['call'=>$this->voice->answer($companyId,$callId,$context),'pipeline'=>['identity','intent','knowledge','workforce_authority','conversation','outcome']];
 }
 public function respond(int$companyId,string$callId,string$text,array$turn=[]):array{
  $g=$this->guard->evaluate($turn);if(($g['speak']??false)!==true)return ['spoken'=>false,'handoff'=>true,'guard'=>$g];
  return ['spoken'=>true,'provider'=>$this->voice->speak($companyId,$callId,$text,$turn),'guard'=>$g];
 }
 public function transfer(int$companyId,string$callId,string$destination,array$context=[]):array{return $this->voice->transfer($companyId,$callId,$destination);}
 public function afterCall(int$companyId,string$callId,array$context=[]):array{return ['summary_required'=>true,'transcript_required'=>true,'workflow_review'=>true,'outcome_review'=>true,'recording_policy_check'=>true,'call'=>$this->voice->end($companyId,$callId)];}
}