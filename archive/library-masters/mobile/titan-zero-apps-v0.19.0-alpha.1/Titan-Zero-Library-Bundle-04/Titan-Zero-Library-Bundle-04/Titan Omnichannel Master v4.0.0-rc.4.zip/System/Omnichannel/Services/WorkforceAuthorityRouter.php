<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\WorkforceGateway;use App\Extensions\MarketingBot\System\Omnichannel\Models\WorkforceHandoff;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelConversation;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\WorkflowRecommendation;
final class WorkforceAuthorityRouter{
 public const AUTONOMY=['manual','assist','semi','auto','full_auto'];
 public function __construct(private WorkforceGateway$gateway){}
 public function route(WorkflowRecommendation$r,string$actorType='ai',string$actorId='omnichannel',string$autonomy='assist',array$context=[]):WorkforceHandoff{
  if(!in_array($autonomy,self::AUTONOMY,true))throw new \InvalidArgumentException('Unsupported autonomy level.');
  $c=OmnichannelConversation::query()->where('company_id',$r->companyId)->findOrFail($r->conversationId);if((int)$c->company_id!==$r->companyId)throw new \LogicException('Cross-company workforce routing rejected.');
  $resolved=$this->gateway->resolveResponsibility($r->companyId,$r->workflow,$context);$authority=$this->gateway->checkAuthority($r->companyId,$actorType,$actorId,$r->workflow,$autonomy,$context);
  $status='queued';$approval=null;$execution=null;$authorityState=(string)($authority['state']??'unverified');
  if(($authority['allowed']??false)!==true||$r->requiresAuthority){$a=$this->gateway->requestApproval($r->companyId,$r->workflow,$context+['conversation_id'=>$r->conversationId,'reason'=>$r->reason]);$approval=$a['approval_id']??null;$status=$approval?'awaiting_approval':'blocked';}
  elseif(in_array($autonomy,['semi','auto','full_auto'],true)){$e=$this->gateway->execute($r->companyId,$r->workflow,$context);$execution=$e['execution_id']??null;$status=($e['executed']??false)?'executing':'blocked';}
  $key=hash('sha256',implode('|',[$r->companyId,$r->conversationId,$r->workflow,$actorType,$actorId]));
  return WorkforceHandoff::query()->firstOrCreate(['company_id'=>$r->companyId,'idempotency_key'=>$key],['conversation_id'=>$r->conversationId,'responsibility'=>$resolved['responsibility']??'customer','capability'=>$r->workflow,'assignee_type'=>$resolved['assignee_type']??null,'assignee_id'=>$resolved['assignee_id']??null,'autonomy'=>$autonomy,'authority_state'=>$authorityState,'status'=>$status,'approval_id'=>$approval,'execution_id'=>$execution,'context'=>$context+['reason'=>$r->reason,'required_fields'=>$r->requiredFields]]);
 }
 public function recordOutcome(WorkforceHandoff$h,string$outcome,array$context=[]):void{$h->forceFill(['status'=>'completed','outcome'=>$outcome,'context'=>array_merge((array)$h->context,$context)])->save();}
}