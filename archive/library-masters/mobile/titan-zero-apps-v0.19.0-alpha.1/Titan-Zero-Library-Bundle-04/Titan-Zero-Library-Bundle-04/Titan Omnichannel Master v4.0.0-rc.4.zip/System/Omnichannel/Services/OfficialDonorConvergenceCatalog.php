<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class OfficialDonorConvergenceCatalog{public function sources():array{return[
 'ai-chat-pro-gmail'=>['restricted_mail_access','search','labels','threads'],
 'ai-chat-pro-outlook'=>['microsoft_graph','restricted_mail_access'],
 'ai-agent-gmail'=>['send','reply','draft','reply_draft','attachments','labels','threads'],
 'ai-agent-outlook'=>['graph_mail_agent'],
 'phone-call-agent'=>['twilio','elevenlabs','conversation_relay','websocket','transcripts','tags','cal.com','calendly'],
 'chatbot-whatsapp'=>['twilio_whatsapp','webhook','conversation'],
 'chatbot-telegram'=>['telegram_webhook','conversation'],
 'chatbot-voice-call'=>['elevenlabs','websocket','transcript'],
 'chatbot-customer-tag'=>['customer_tags','conversation_tags'],
 'canvas'=>['reviewed_not_transport']
];}}
