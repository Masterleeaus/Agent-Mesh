<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class NormalizedRichInboundMessage{
 public function __construct(public int$companyId,public string$channel,public string$provider,public string$externalMessageId,public string$senderAddress,public ?string$senderName,public array$parts,public array$events=[],public array$metadata=[]){if($companyId<=0)throw new \InvalidArgumentException('company_id is required.');foreach($parts as$p)if(!$p instanceof RichContentPart)throw new \InvalidArgumentException('parts must contain RichContentPart.');}
}