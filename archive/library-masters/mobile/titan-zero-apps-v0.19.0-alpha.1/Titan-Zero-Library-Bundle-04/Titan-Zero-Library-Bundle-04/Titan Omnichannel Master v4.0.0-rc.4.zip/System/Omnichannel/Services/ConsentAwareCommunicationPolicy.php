<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\CommunicationPolicy;use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelIdentity;
final class ConsentAwareCommunicationPolicy implements CommunicationPolicy{
 public function evaluate(int$companyId,string$identityId,string$purpose,array$channels,array$context=[]):array{
  $i=OmnichannelIdentity::query()->where('company_id',$companyId)->findOrFail($identityId);$m=(array)($i->metadata??[]);
  if(($m['opted_out']??false)===true)return ['allowed'=>false,'reason'=>'opted_out','channels'=>[]];
  $marketing=str_starts_with($purpose,'marketing.')||in_array($purpose,['review_request','win_back','seasonal_reminder'],true);
  if($marketing&&($m['marketing_allowed']??false)!==true)return ['allowed'=>false,'reason'=>'marketing_consent_required','channels'=>[]];
  if(!$marketing&&($m['transactional_allowed']??true)!==true)return ['allowed'=>false,'reason'=>'transactional_blocked','channels'=>[]];
  $preferred=$m['preferred_channel']??null;$ordered=$preferred&&in_array($preferred,$channels,true)?array_values(array_unique(array_merge([$preferred],$channels))):$channels;
  if(($context['quiet_hours']??false)===true&&!($context['emergency']??false))return ['allowed'=>false,'reason'=>'quiet_hours','channels'=>$ordered];
  return ['allowed'=>true,'reason'=>'allowed','channels'=>$ordered];
 }}
