<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface AudienceProvider{public function candidates(int$companyId,array$rules,int$limit=500):array;}
