<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\MultimodalIntelligenceProvider;
final class FailClosedMultimodalIntelligenceProvider implements MultimodalIntelligenceProvider{
 public function analyze(int$companyId,string$conversationId,array$artifact,array$context=[]):array{return ['analyzed'=>false,'confidence'=>0.0,'observations'=>[],'reason'=>'multimodal_provider_not_connected'];}
}