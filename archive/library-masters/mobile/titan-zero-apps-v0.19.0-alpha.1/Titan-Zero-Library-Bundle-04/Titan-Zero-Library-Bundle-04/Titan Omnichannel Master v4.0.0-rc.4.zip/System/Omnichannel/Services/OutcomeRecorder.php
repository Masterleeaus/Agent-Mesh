<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\OutcomeEvidenceProvider;use App\Extensions\MarketingBot\System\Omnichannel\Models\BusinessOutcome;
final class OutcomeRecorder{
 public function __construct(private OutcomeCatalog$catalog,private OutcomeEvidenceProvider$evidence){}
 public function record(int$companyId,string$key,?string$objectType,?string$objectId,array$context=[]):BusinessOutcome{
  if($companyId<=0)throw new \InvalidArgumentException('company_id required.');$this->catalog->assert($key);
  $v=$this->evidence->verify($companyId,$key,$objectType,$objectId,(array)($context['evidence']??[]));if(($v['verified']??false)!==true)throw new \LogicException('Outcome not verified by authoritative evidence.');
  $source=(string)($context['source_event_id']??'');if($source==='')throw new \InvalidArgumentException('source_event_id required for outcome idempotency.');
  $idk=hash('sha256',implode('|',[$companyId,$key,(string)$objectType,(string)$objectId,$source]));
  return BusinessOutcome::query()->firstOrCreate(['company_id'=>$companyId,'idempotency_key'=>$idk],['conversation_id'=>$context['conversation_id']??null,'outcome_key'=>$key,'object_type'=>$objectType,'object_id'=>$objectId,'value'=>$context['value']??null,'currency'=>$context['currency']??null,'channel'=>$context['channel']??null,'actor_type'=>$context['actor_type']??null,'actor_id'=>$context['actor_id']??null,'workflow'=>$context['workflow']??null,'automation_id'=>$context['automation_id']??null,'attribution_weight'=>$context['attribution_weight']??1,'evidence'=>$v['evidence']??[],'occurred_at'=>$context['occurred_at']??now()]);
 }}
