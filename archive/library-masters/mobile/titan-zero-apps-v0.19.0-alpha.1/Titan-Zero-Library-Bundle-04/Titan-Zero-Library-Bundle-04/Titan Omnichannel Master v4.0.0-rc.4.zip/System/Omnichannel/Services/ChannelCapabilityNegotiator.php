<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\OutboundRichMessage;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\ProviderCapabilitySet;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\RichContentPart;
final class ChannelCapabilityNegotiator{
 public function negotiate(OutboundRichMessage$m,ProviderCapabilitySet$c):array{
  $parts=[];$degraded=[];foreach($m->parts as$p){if($c->supportsContent($p->kind)){$parts[]=$p;continue;}$fallback=$this->fallback($p,$m);if($fallback){$parts[]=$fallback;$degraded[]=['from'=>$p->kind,'to'=>$fallback->kind];}else{$degraded[]=['from'=>$p->kind,'to'=>null];}}
  if(!$parts&&$c->supportsContent('text'))$parts[] = new RichContentPart('text',$m->textFallback());
  return ['sendable'=>count($parts)>0,'parts'=>$parts,'degraded'=>$degraded,'provider'=>$c->provider,'channel'=>$c->channel];
 }
 private function fallback(RichContentPart$p,OutboundRichMessage$m):?RichContentPart{
  if($p->kind==='html')return new RichContentPart('text',trim(strip_tags((string)$p->content)),['degraded_from'=>'html']);
  if(in_array($p->kind,['buttons','form','template'],true)){$t=(string)($p->metadata['fallback_text']??$m->textFallback());return $t!==''?new RichContentPart('text',$t,['degraded_from'=>$p->kind]):null;}
  if(in_array($p->kind,['image','video','audio','voice_note','document','pdf','location','contact'],true)){$url=(string)($p->metadata['fallback_url']??'');return $url!==''?new RichContentPart('text',$url,['degraded_from'=>$p->kind]):null;}
  return null;
 }}
