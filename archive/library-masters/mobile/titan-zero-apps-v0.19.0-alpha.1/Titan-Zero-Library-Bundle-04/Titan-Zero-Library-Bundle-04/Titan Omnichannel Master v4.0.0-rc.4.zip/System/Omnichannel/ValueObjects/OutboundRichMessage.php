<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class OutboundRichMessage{
 public function __construct(public int$companyId,public string$conversationId,public string$channel,public string$provider,public string$recipientAddress,public array$parts,public array$metadata=[]){if($companyId<=0)throw new \InvalidArgumentException('company_id is required.');foreach($parts as$p)if(!$p instanceof RichContentPart)throw new \InvalidArgumentException('parts must contain RichContentPart.');}
 public function textFallback():string{foreach($this->parts as$p)if($p->kind==='text')return(string)$p->content;foreach($this->parts as$p)if($p->kind==='html')return trim(strip_tags((string)$p->content));return(string)($this->metadata['fallback_text']??'');}
}