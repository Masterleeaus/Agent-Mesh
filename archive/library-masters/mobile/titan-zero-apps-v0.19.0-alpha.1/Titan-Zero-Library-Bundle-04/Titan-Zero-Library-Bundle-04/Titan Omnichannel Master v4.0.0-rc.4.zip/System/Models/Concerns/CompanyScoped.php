<?php
declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Models\Concerns;
use Illuminate\Database\Eloquent\Builder;use App\Extensions\MarketingBot\System\Contracts\CompanyContext;
trait CompanyScoped { public static function bootCompanyScoped():void { static::addGlobalScope('company_id',fn(Builder $q)=>$q->where($q->getModel()->getTable().'.company_id',app(CompanyContext::class)->id())); static::creating(function($m){if(empty($m->company_id))$m->company_id=app(CompanyContext::class)->id();}); } }
