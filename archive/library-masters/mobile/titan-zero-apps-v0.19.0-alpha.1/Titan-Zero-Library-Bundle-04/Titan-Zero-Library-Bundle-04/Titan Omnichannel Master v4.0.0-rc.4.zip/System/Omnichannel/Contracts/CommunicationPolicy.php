<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface CommunicationPolicy{public function evaluate(int$companyId,string$identityId,string$purpose,array$channels,array$context=[]):array;}
