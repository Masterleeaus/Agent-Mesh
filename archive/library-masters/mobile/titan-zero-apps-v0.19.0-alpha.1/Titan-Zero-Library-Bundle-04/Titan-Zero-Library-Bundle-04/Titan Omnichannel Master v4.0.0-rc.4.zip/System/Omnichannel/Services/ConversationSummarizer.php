<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Models\OmnichannelMessage;
final class ConversationSummarizer{public function build(int$companyId,string$conversationId,int$limit=30):array{$rows=OmnichannelMessage::query()->where('company_id',$companyId)->where('conversation_id',$conversationId)->latest('occurred_at')->limit(min(100,max(1,$limit)))->get()->reverse();return ['messages'=>$rows->map(fn($m)=>['direction'=>$m->direction,'channel'=>$m->channel,'body'=>$m->body,'at'=>(string)$m->occurred_at])->values()->all(),'count'=>$rows->count()];}}
