<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class InboxSavedViewPolicy{public function allowedFilters():array{return ['queue','owner','team','priority','channel','unread','sla_state','tag','customer','site','job','intent','outcome_state','created_range'];}}