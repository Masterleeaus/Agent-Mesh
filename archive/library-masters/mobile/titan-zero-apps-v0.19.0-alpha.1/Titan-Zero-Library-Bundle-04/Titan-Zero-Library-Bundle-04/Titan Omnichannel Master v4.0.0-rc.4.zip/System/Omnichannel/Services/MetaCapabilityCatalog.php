<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MetaCapabilityCatalog{
 public function for(string$surface):array{return match($surface){
 'instagram_dm'=>['text','image','video','audio','reaction','read_receipts'],
 'instagram_comment'=>['public_interaction','public_reply','private_handoff'],
 'instagram_mention'=>['public_interaction','private_handoff'],
 'facebook_messenger'=>['text','image','video','audio','document','buttons','template','reaction','read_receipts'],
 'facebook_comment'=>['public_interaction','public_reply','private_handoff'],
 'whatsapp'=>['text','image','video','audio','voice_note','document','location','contact','buttons','template','reaction','read_receipts'],
 default=>throw new \InvalidArgumentException('Unsupported Meta surface.')};}
}