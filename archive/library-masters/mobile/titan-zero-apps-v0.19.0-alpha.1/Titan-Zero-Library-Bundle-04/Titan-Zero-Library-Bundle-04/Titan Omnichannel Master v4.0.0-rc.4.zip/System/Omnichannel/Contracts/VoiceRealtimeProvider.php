<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
interface VoiceRealtimeProvider{public function capabilities():array;public function begin(int$companyId,string$callId,array$context=[]):array;public function ingestEvent(int$companyId,string$callId,array$event):array;public function transfer(int$companyId,string$callId,string$destination):array;public function end(int$companyId,string$callId):array;}
