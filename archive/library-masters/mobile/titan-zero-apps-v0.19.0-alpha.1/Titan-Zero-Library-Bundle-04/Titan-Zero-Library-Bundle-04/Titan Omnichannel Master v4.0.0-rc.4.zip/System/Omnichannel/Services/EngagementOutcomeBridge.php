<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class EngagementOutcomeBridge{
 public function successCriteria(string$programType):array{return match($programType){
  'review_reputation'=>['review_received'],'dormant_customer_reactivation','win_back'=>['customer_retained','revenue_recovered','booking_created'],
  'seasonal_service','maintenance_reminder','service_area_campaign','cross_sell','upsell'=>['lead_converted','quote_accepted','booking_created','revenue_recovered'],default=>[]};}
}