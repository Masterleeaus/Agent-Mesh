<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class WhatsAppRichMessagePlanner{
 public function plan(string$recipient,array$parts,array$context=[]):array{
  $allowed=['text','image','video','audio','voice_note','document','location','contact','buttons','template','reaction'];
  foreach($parts as$p)if(!in_array((string)($p['kind']??''),$allowed,true))throw new \InvalidArgumentException('Unsupported WhatsApp rich content.');
  if(($context['business_initiated']??false)&&!($context['approved_template']??false))return ['sendable'=>false,'reason'=>'approved_template_required'];
  return ['sendable'=>true,'recipient'=>$recipient,'parts'=>$parts,'reply_to'=>$context['reply_to']??null];
 }}
