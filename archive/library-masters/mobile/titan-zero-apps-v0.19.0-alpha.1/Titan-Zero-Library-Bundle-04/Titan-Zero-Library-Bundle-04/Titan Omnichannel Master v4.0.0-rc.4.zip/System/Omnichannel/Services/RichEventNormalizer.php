<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class RichEventNormalizer{
 public const EVENTS=['sent','delivered','read','failed','typing_started','typing_stopped','reaction_added','reaction_removed','call_started','call_ended','public_comment','public_mention'];
 public function normalize(string$event,array$payload=[]):array{if(!in_array($event,self::EVENTS,true))throw new \InvalidArgumentException('Unsupported channel event.');return ['event'=>$event,'external_message_id'=>$payload['external_message_id']??null,'occurred_at'=>$payload['occurred_at']??null,'payload'=>$payload];}
}