<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\WorkforceGateway;
final class FailClosedWorkforceGateway implements WorkforceGateway{
 public function resolveResponsibility(int$companyId,string$capability,array$context=[]):array{return ['resolved'=>false,'responsibility'=>$this->responsibility($capability),'assignee_type'=>null,'assignee_id'=>null,'reason'=>'workforce_gateway_not_connected'];}
 public function checkAuthority(int$companyId,string$actorType,string$actorId,string$capability,string$autonomy,array$context=[]):array{return ['allowed'=>false,'state'=>'unverified','reason'=>'authority_must_be_confirmed_by_workforce'];}
 public function requestApproval(int$companyId,string$capability,array$context=[]):array{return ['created'=>false,'approval_id'=>null,'reason'=>'approval_gateway_not_connected'];}
 public function execute(int$companyId,string$capability,array$context=[]):array{return ['executed'=>false,'execution_id'=>null,'reason'=>'execution_gateway_not_connected'];}
 private function responsibility(string$c):string{return match(true){str_starts_with($c,'finance.')=>'money',str_starts_with($c,'jobs.'),str_starts_with($c,'bookings.'),str_starts_with($c,'dispatch.')=>'work',str_starts_with($c,'quality.')=>'customer',str_starts_with($c,'people.')=>'people',str_starts_with($c,'growth.')=>'growth',str_starts_with($c,'risk.')=>'risk',default=>'customer'};}
}