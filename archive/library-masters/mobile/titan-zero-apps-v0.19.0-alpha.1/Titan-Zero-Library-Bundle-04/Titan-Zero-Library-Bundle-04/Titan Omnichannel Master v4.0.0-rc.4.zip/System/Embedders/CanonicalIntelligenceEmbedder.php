<?php

declare(strict_types=1);

namespace App\Extensions\MarketingBot\System\Embedders;

use App\Extensions\MarketingBot\System\Contracts\CompanyContext;
use App\Extensions\MarketingBot\System\Embedders\Contracts\Embedder;
use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/** Canonical Omnichannel embedding adapter; backend choice belongs to Titan intelligence. */
final class CanonicalIntelligenceEmbedder extends Embedder
{
    public const COMMAND_BUS_ALIAS = 'titan.apps.interaction.command-bus';
    public const CAPABILITY = 'ai.embedding.generate';

    public function __construct(
        private readonly Container $app,
        private readonly CompanyContext $company,
        private readonly OpenAIEmbedder $legacy,
    ) {}

    public function generate(): object
    {
        if ($this->app->bound(self::COMMAND_BUS_ALIAS)) {
            $bus = $this->app->make(self::COMMAND_BUS_ALIAS);
            if (is_object($bus) && method_exists($bus, 'dispatchResult')) {
                try {
                    $result = $bus->dispatchResult(self::CAPABILITY, [
                        'company_id' => $this->company->id(),
                        'actor_id' => (int) $this->user->id,
                        'input' => $this->input,
                        'requested_model' => $this->entity->value,
                        'purpose' => 'omnichannel_knowledge_embedding',
                        'source_extension' => 'titan-omnichannel',
                    ]);
                    $embeddings = $this->extractEmbeddings($result);
                    if ($embeddings !== null) {
                        return (object) ['embeddings' => array_map(static fn(array $row): object => (object) $row, $embeddings)];
                    }
                    throw new RuntimeException('Canonical embedding capability returned no usable vectors.');
                } catch (Throwable $e) {
                    if (! (bool) config('marketing-bot.ai.allow_legacy_embedding_fallback', false)) {
                        throw new RuntimeException('Unable to generate embeddings through governed Titan intelligence.', previous: $e);
                    }
                }
            }
        }

        if (! (bool) config('marketing-bot.ai.allow_legacy_embedding_fallback', false)) {
            throw new RuntimeException('Canonical Titan embedding routing is unavailable.');
        }

        return $this->legacy->setEntity($this->entity)->setUser($this->user)->setInput($this->input)->generate();
    }

    /** @return list<array{index:int,embedding:array}>|null */
    private function extractEmbeddings(mixed $result): ?array
    {
        $payload = is_object($result) && method_exists($result, 'toArray') ? $result->toArray() : $result;
        if (is_object($payload)) $payload = get_object_vars($payload);
        if (! is_array($payload)) return null;
        foreach (['result','data','output','capability_result'] as $key) {
            if (isset($payload[$key]) && is_array($payload[$key])) { $payload = $payload[$key]; break; }
        }
        $rows = $payload['embeddings'] ?? $payload['vectors'] ?? null;
        if (! is_array($rows) || $rows === []) return null;
        $out = [];
        foreach (array_values($rows) as $index => $row) {
            if (is_object($row)) $row = get_object_vars($row);
            $vector = is_array($row) ? ($row['embedding'] ?? $row['vector'] ?? null) : null;
            if (! is_array($vector)) return null;
            $out[] = ['index' => (int) (is_array($row) ? ($row['index'] ?? $index) : $index), 'embedding' => $vector];
        }
        return $out;
    }
}
