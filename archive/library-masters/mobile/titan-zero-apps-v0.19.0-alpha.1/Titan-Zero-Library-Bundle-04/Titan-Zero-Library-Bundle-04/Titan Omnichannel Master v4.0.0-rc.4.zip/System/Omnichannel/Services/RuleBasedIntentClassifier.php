<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Contracts\IntentClassifier;use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\FieldServiceIntent;
final class RuleBasedIntentClassifier implements IntentClassifier {
 public function classify(string$text,array$companyContext=[],array$conversationContext=[]):FieldServiceIntent {
  $s=mb_strtolower(trim($text));$intent='general_enquiry';$confidence=.45;$signals=[];
  $rules=[
   'complaint'=>['complain','unhappy','terrible','damaged','not happy','refund'],
   'cancellation'=>['cancel','call off','do not come',"don't come"],
   'reschedule'=>['reschedule','change the time','different day','move my booking'],
   'technician_eta'=>['where is','eta','how far away','when will the technician','when will the cleaner','when will the plumber'],
   'variation'=>['extra work','add this','variation','while you are there','also fix'],
   'payment_question'=>['payment','pay now','paid','payid','card payment'],
   'invoice_question'=>['invoice','receipt','tax invoice'],
   'review'=>['leave a review','review link','give feedback'],
   'booking_request'=>['book','appointment','come out','schedule a visit','available tomorrow'],
   'quote_request'=>['quote','estimate','how much','price for','cost to'],
   'job_question'=>['my job','job status','work completed','work today'],
   'service_request'=>['need someone','need a','repair','clean','service','install','fix','replace']
  ];
  foreach($rules as$k=>$terms)foreach($terms as$term)if(str_contains($s,$term)){$intent=$k;$confidence=.72;$signals[]=$term;break 2;}
  $emergencyTerms=['emergency','urgent','burst pipe','flooding','gas leak','sparking','no power','locked out','water everywhere','right now','asap'];
  $emergency=false;foreach($emergencyTerms as$t)if(str_contains($s,$t)){$emergency=true;$signals[]=$t;break;}
  if($emergency){$intent='emergency_service';$confidence=max($confidence,.86);}
  $urgency=$emergency?'emergency':((str_contains($s,'today')||str_contains($s,'urgent'))?'urgent':'normal');
  $service=null;foreach((array)($companyContext['services']??[])as$item){$name=mb_strtolower((string)($item['name']??''));$key=(string)($item['key']??$name);if($name!==''&&str_contains($s,$name)){$service=$key;$signals[]='service:'.$key;break;}}
  $missing=[];if(in_array($intent,['service_request','quote_request','booking_request','emergency_service'],true)){if(!$service)$missing[]='service';if(empty($conversationContext['site_id']))$missing[]='site';}
  return new FieldServiceIntent($intent,$urgency,$emergency,$service,$conversationContext['site_id']??null,[],$missing,$confidence,array_values(array_unique($signals)));
 }
}