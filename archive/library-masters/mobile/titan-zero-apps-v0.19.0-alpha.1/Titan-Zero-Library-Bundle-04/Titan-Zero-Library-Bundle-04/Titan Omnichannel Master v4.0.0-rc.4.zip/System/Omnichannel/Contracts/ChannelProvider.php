<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\NormalizedInboundMessage;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\OutboundMessage;
interface ChannelProvider {public function key():string; public function channelKind():string; public function normalizeInbound(array $payload):NormalizedInboundMessage; public function send(OutboundMessage $message):array;}
