<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use App\Extensions\MarketingBot\System\Omnichannel\Models\BusinessOutcome;
final class OutcomeIntelligence{
 public function scorecard(int$companyId,array$filters=[]):array{
  $q=BusinessOutcome::query()->where('company_id',$companyId);foreach(['channel','actor_type','actor_id','workflow','automation_id','outcome_key']as$f)if(isset($filters[$f]))$q->where($f,$filters[$f]);
  if(isset($filters['from']))$q->where('occurred_at','>=',$filters['from']);if(isset($filters['to']))$q->where('occurred_at','<=',$filters['to']);
  $rows=$q->get();$counts=$rows->groupBy('outcome_key')->map->count()->all();$value=(float)$rows->sum(fn($r)=>(float)($r->value??0)*(float)$r->attribution_weight);
  return ['outcomes'=>$counts,'attributed_value'=>$value,'records'=>$rows->count(),'filters'=>$filters];
 }
 public function compareBy(int$companyId,string$dimension,array$filters=[]):array{
  if(!in_array($dimension,['channel','actor_id','workflow','automation_id'],true))throw new \InvalidArgumentException('Unsupported outcome dimension.');
  $q=BusinessOutcome::query()->where('company_id',$companyId);if(isset($filters['from']))$q->where('occurred_at','>=',$filters['from']);if(isset($filters['to']))$q->where('occurred_at','<=',$filters['to']);
  return $q->get()->groupBy(fn($r)=>(string)($r->{$dimension}??'unknown'))->map(fn($g)=>['records'=>$g->count(),'attributed_value'=>(float)$g->sum(fn($r)=>(float)($r->value??0)*(float)$r->attribution_weight),'outcomes'=>$g->groupBy('outcome_key')->map->count()->all()])->all();
 }}
