<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class VoiceDonorCapabilityCatalog{public function all():array{return[
 'twilio'=>['inbound_call','outbound_call','conversation_relay','websocket','call_status','transfer','recording_hooks'],
 'elevenlabs'=>['realtime_voice_agent','websocket','transcript','voice_selection'],
 'booking_tools'=>['cal.com','calendly'],
 'canonical_rule'=>'voice providers supply transport/intelligence; bookings remain authoritative Titan booking workflows'
];}}
