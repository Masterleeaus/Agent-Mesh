<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\Models\AiCommunicationRun;
interface CommunicationsAgent{public function prepare(int$companyId,string$conversationId,?string$messageId=null,string$mode='assist'):AiCommunicationRun;}
