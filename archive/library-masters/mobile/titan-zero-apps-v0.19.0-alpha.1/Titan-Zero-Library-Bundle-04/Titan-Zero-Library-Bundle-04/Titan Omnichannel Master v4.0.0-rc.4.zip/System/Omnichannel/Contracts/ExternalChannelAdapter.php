<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Contracts;
use App\Extensions\MarketingBot\System\Omnichannel\ValueObjects\ProviderCapabilitySet;
interface ExternalChannelAdapter extends ChannelProvider,ProviderCapabilities{
public function providerKey():string;public function channelKeys():array;public function capabilitySetFor(string $channel):ProviderCapabilitySet;
public function normalizeInbound(int $companyId,string $channel,array $payload):array;public function normalizeStatus(int $companyId,string $channel,array $payload):array;
public function sendRich(int $companyId,string $channel,string $recipient,array $parts,array $context=[]):array;}