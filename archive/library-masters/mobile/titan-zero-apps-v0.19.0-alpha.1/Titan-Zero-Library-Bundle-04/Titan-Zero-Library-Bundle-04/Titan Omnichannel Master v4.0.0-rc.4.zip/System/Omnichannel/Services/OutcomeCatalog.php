<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class OutcomeCatalog{
 public const OUTCOMES=['lead_converted','quote_accepted','booking_created','job_completed','invoice_paid','complaint_resolved','cancellation_prevented','review_received','customer_retained','revenue_recovered'];
 public function assert(string$key):void{if(!in_array($key,self::OUTCOMES,true))throw new \InvalidArgumentException('Unsupported business outcome.');}
}