<?php

declare(strict_types=1);
namespace App\Extensions\MarketingBot\System\Omnichannel\ValueObjects;
final readonly class NormalizedInboundMessage {public function __construct(public int $companyId,public string $channel,public string $provider,public string $externalMessageId,public string $senderAddress,public ?string $senderName,public string $body,public array $attachments=[],public array $metadata=[]){if($companyId<=0)throw new \InvalidArgumentException('company_id is required.');}}
