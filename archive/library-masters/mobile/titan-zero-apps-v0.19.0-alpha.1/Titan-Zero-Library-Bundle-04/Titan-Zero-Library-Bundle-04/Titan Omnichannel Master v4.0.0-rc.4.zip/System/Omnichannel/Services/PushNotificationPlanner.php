<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class PushNotificationPlanner{
 public function __construct(private readonly TitanSurfaceAuthorityPolicy $surfaces=new TitanSurfaceAuthorityPolicy()){}
 public function plan(string$surface,string$title,string$body,array$actions=[],array$context=[]):array{
  $canonical=$this->surfaces->canonicalSurface($surface);
  if(!in_array($canonical,['zero','go','hub'],true))throw new \InvalidArgumentException('Push requires canonical Titan authenticated surface.');
  return ['channel'=>'pwa_push','surface'=>$canonical,'title'=>$title,'body'=>$body,'actions'=>array_slice($actions,0,3),'context'=>$context,'requires_registered_endpoint'=>true];
 }
}
