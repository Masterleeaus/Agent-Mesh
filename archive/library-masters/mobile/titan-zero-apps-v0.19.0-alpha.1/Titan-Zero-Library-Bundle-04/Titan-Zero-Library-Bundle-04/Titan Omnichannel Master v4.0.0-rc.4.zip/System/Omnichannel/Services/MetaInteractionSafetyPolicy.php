<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
final class MetaInteractionSafetyPolicy{
 public function evaluate(string$surface,array$interaction):array{
  $sensitive=(bool)($interaction['sensitive']??false);$complaint=(bool)($interaction['complaint']??false);$emergency=(bool)($interaction['emergency']??false);
  if($sensitive||$complaint||$emergency)return ['auto_public_reply'=>false,'private_handoff'=>true,'human_review'=>true];
  return ['auto_public_reply'=>false,'private_handoff'=>false,'human_review'=>false,'reason'=>'public_ai_reply_requires_explicit_policy'];
 }}
