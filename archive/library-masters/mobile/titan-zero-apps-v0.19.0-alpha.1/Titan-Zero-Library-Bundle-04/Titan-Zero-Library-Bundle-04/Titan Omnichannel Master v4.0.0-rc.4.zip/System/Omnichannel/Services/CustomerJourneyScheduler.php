<?php
declare(strict_types=1);namespace App\Extensions\MarketingBot\System\Omnichannel\Services;
use Illuminate\Support\Str;use App\Extensions\MarketingBot\System\Omnichannel\Models\JourneyAutomation;
final class CustomerJourneyScheduler{
 public function schedule(int$companyId,string$conversationId,string$journey,string$trigger,array$payload=[],?\DateTimeInterface$dueAt=null):JourneyAutomation{
  if($companyId<=0)throw new \InvalidArgumentException('company_id required.');$key=hash('sha256',implode('|',[$companyId,$conversationId,$journey,$trigger,(string)($payload['object_id']??'')]));
  return JourneyAutomation::query()->firstOrCreate(['company_id'=>$companyId,'idempotency_key'=>$key],['conversation_id'=>$conversationId,'journey_key'=>$journey,'trigger_key'=>$trigger,'state'=>'pending','due_at'=>$dueAt,'payload'=>$payload,'channel_plan'=>[]]);
 }}
