<?php
declare(strict_types=1);$r=dirname(__DIR__);$f=[];function p1($x,$l){global$f;echo($x?'PASS: ':'FAIL: ').$l."\n";if(!$x)$f[]=$l;}function tx($p){return is_file($p)?file_get_contents($p):'';}
$ctx=tx($r.'/System/Services/Tenancy/AuthenticatedCompanyContext.php');p1(str_contains($ctx,'company_id')&&str_contains($ctx,"throw new \\LogicException"),'company context fails closed');
$trait=tx($r.'/System/Models/Concerns/CompanyScoped.php');p1(str_contains($trait,"addGlobalScope('company_id'")&&str_contains($trait,"company_id',app(CompanyContext::class)->id()"),'company global scope and create ownership');
$c=tx($r.'/System/Models/MarketingConversation.php');p1(str_contains($c,'use CompanyScoped')&&str_contains($c,"'company_id'"),'conversation company scoped');
$c=tx($r.'/System/Models/Whatsapp/Contact.php');p1(str_contains($c,'CompanyScoped')&&str_contains($c,"->where('company_id'"),'contact company scoped');
$p=tx($r.'/System/Policies/MarketingConversationPolicy.php');p1(str_contains($p,'$user->company_id')&&str_contains($p,'$item->company_id')&&!str_contains($p,'$user->id === $item->user_id'),'conversation authorization uses company boundary');
$m=tx($r.'/database/migrations/2026_08_22_000001_add_company_tenancy_to_marketing_bot.php');p1(substr_count($m,"'company_id'")>=10,'additive company tenancy migration covers donor tables');
foreach(['ai-agent-whatsapp-channel.zip','ai-agent-gmail.zip','ai-agent-outlook.zip','ai-agent-slack-channel.zip','phone-call-agent.zip']as$d)p1(is_file($r.'/LegacyDonors/'.$d),'donor preserved: '.$d);
$e=json_decode(tx($r.'/extension.json'),true);p1(($e['name']??'')==='Titan Omnichannel'&&version_compare(($e['version']??'0'),'4.0.0-alpha.1','>='),'extension converted to Titan Omnichannel Pass 1');
if($f){echo'PASS1_TEST: FAIL ('.count($f).")\n";exit(1);}echo"PASS1_TEST: PASS\n";