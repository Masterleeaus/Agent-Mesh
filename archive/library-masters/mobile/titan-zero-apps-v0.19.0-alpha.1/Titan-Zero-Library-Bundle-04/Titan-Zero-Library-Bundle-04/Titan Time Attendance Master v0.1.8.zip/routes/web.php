<?php
use App\Extensions\TitanTimeAttendance\System\Http\Controllers\{AttendanceVerificationController,OfflineAttendanceController,SubmissionController,TimeEntryController,TimerController};
use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
Route::middleware(['web','auth'])->prefix('dashboard/user/titan-time-attendance')->as('dashboard.user.titan-time-attendance.')->group(function (): void {
 Route::get('/',function(Request $request,TimeAttendancePermissionService $permissions){$permissions->authorize($request->user(),'titan-time-attendance.view');return view('titan-time-attendance::dashboard');})->name('index');
 Route::get('api/entries',[TimeEntryController::class,'index'])->name('entries.index');
 Route::post('api/entries',[TimeEntryController::class,'store'])->name('entries.store');
 Route::post('api/timer/start',[TimerController::class,'start'])->name('timer.start');
 Route::post('api/timer/{timer}/stop',[TimerController::class,'stop'])->whereNumber('timer')->name('timer.stop');
 Route::post('api/submissions',[SubmissionController::class,'submit'])->name('submissions.submit');
 Route::post('api/submissions/{submission}/review',[SubmissionController::class,'review'])->whereNumber('submission')->name('submissions.review');
 Route::post('api/attendance/verify',[AttendanceVerificationController::class,'verify'])->name('attendance.verify');
 Route::post('api/attendance/offline/ingest',[OfflineAttendanceController::class,'ingest'])->name('attendance.offline.ingest');
 Route::get('api/attendance/offline',[OfflineAttendanceController::class,'index'])->name('attendance.offline.index');
});
