@extends('panel.layout.app')
@section('title', 'Titan Time & Attendance')
@section('content')
<div class="container-fluid py-6">
    <h1>Titan Time & Attendance</h1>
    <p>Time entries, timers, weekly approvals and attendance verification are owned by this extension.</p>
</div>
@endsection
