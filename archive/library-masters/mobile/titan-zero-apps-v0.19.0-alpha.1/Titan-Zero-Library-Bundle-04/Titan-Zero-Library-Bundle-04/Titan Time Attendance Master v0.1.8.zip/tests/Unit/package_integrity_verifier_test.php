<?php

declare(strict_types=1);
require_once __DIR__.'/../../System/Installer/PackageIntegrityVerifier.php';
use App\Extensions\TitanTimeAttendance\System\Installer\PackageIntegrityVerifier;
$result=(new PackageIntegrityVerifier())->verify(dirname(__DIR__,2));
if(!($result['ok']??false)){
    fwrite(STDERR,"Package integrity verifier: FAIL\n- ".implode("\n- ",$result['errors']??[])."\n");exit(1);
}
echo "Package integrity verifier: PASS\n";
