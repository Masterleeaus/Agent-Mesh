<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=[];
$guard=$root.'/System/Governance/TimeActorReferenceGuard.php';
if(!is_file($guard))$fail[]='TimeActorReferenceGuard missing';
$exec=(string)@file_get_contents($root.'/System/Governance/TimeCapabilityExecutor.php');
if(!str_contains($exec,'TimeActorReferenceGuard'))$fail[]='executor does not inject actor reference guard';
if(!str_contains($exec,'assertUserBelongsToCompany'))$fail[]='executor does not validate explicit user_id';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);} echo "Agent2 Pass11 Time foreign-reference guard PASS\n";
