<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Integrations/Rewind/TimeRewindRecordProjector.php';
use App\Extensions\TitanTimeAttendance\System\Integrations\Rewind\TimeRewindRecordProjector;

$p = new TimeRewindRecordProjector();
$trace = '11111111-1111-4111-8111-111111111111';
$signals = [[
    'company_id'=>7,'event_id'=>'22222222-2222-4222-8222-222222222222','event_type'=>'attendance.verification.failed',
    'trace_id'=>$trace,'correlation_id'=>null,'causation_id'=>null,'created_at'=>'2026-08-15T00:00:00+00:00',
    'payload'=>['verification_log_id'=>4,'user_id'=>12,'service_location_public_id'=>'01ABCDEFGHJKMNPQRSTVWXYZ12','token'=>'secret','latitude'=>-37.8,'longitude'=>144.9,'reason_code'=>'outside_geofence'],
]];
$receipts = [[
    'company_id'=>7,'command_id'=>'33333333-3333-4333-8333-333333333333','capability'=>'time.submission.review','status'=>'executed',
    'trace_id'=>$trace,'correlation_id'=>null,'causation_id'=>null,'actor_user_id'=>9,'actor_type'=>'human','risk_class'=>'HIGH',
    'human_approval_required'=>true,'source'=>'time_web','executed_at'=>'2026-08-15T00:01:00+00:00','created_at'=>'2026-08-15T00:00:59+00:00',
    'result'=>['submission'=>['id'=>55,'notes'=>'private manager note'],'decision'=>'approved'],
]];
$rows = $p->projectRows($signals,$receipts,7,$trace);
if (count($rows)!==2) { fwrite(STDERR,"Expected two Rewind records.\n"); exit(1); }
foreach ($rows as $i=>$row) {
    if (($row['sequence']??null)!==$i) { fwrite(STDERR,"Rewind sequence is not deterministic.\n"); exit(1); }
    if (($row['company_id']??null)!==7 || ($row['trace_id']??null)!==$trace) { fwrite(STDERR,"Rewind tenant/trace boundary lost.\n"); exit(1); }
    $encoded=json_encode($row,JSON_THROW_ON_ERROR);
    foreach (['secret','-37.8','144.9','private manager note'] as $forbidden) if (str_contains($encoded,$forbidden)) { fwrite(STDERR,"Sensitive raw evidence leaked to Rewind: {$forbidden}\n"); exit(1); }
}
if (($rows[0]['actor_type']??null)!=='human' || ($rows[0]['actor_id']??null)!=='12') { fwrite(STDERR,"Signal actor provenance missing from Rewind record.\n"); exit(1); }
if (($rows[0]['payload']['reason_code']??null)!=='outside_geofence') { fwrite(STDERR,"Bounded verification reason code missing from Rewind record.\n"); exit(1); }
if (($rows[1]['capability_name']??null)!=='time.submission.review') { fwrite(STDERR,"Command capability missing from Rewind record.\n"); exit(1); }
echo "Rewind record projector: PASS\n";
