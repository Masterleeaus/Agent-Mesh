<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Support/CapabilityCatalog.php';
require_once __DIR__.'/../../System/Integrations/Exports/TimePlatformExportRegistry.php';
use App\Extensions\TitanTimeAttendance\System\Integrations\Exports\TimePlatformExportRegistry;

$r = new TimePlatformExportRegistry();
$all=$r->all();
foreach(['governance','wisdom','vertical'] as $key) if(!isset($all[$key])) { fwrite(STDERR,"Missing {$key} export.\n"); exit(1); }
if (($all['governance']['source_extension']??'')!=='titan-time-attendance') { fwrite(STDERR,"Governance export lacks ownership.\n"); exit(1); }
if (!in_array('attendance.verification.failed',$all['wisdom']['observable_signals']??[],true)) { fwrite(STDERR,"Wisdom export lacks attendance outcome signal.\n"); exit(1); }
if (!in_array('geofence',$all['vertical']['verification_methods']??[],true)) { fwrite(STDERR,"Vertical export lacks verification method.\n"); exit(1); }
echo "Platform export registry: PASS\n";
