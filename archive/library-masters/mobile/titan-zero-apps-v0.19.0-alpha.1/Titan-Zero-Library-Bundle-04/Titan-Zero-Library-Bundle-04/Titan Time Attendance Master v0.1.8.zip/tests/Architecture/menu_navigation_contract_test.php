<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$provider = @file_get_contents($root.'/System/TitanTimeAttendanceServiceProvider.php') ?: '';
$routes = @file_get_contents($root.'/routes/web.php') ?: '';
$manifest = json_decode((string) @file_get_contents($root.'/extension.manifest.json'), true);

$navigationPath = $root.'/System/Navigation/TimeAttendanceNavigation.php';
$registrarPath = $root.'/System/Navigation/TimeAttendanceMenuRegistrar.php';
$syncCommandPath = $root.'/System/Console/Commands/SyncTimeAttendanceMenuCommand.php';

$assert(is_file($navigationPath), 'missing extension-owned TimeAttendanceNavigation definition');
$assert(is_file($registrarPath), 'missing MagicAI/Titan menu registrar');
$assert(is_file($syncCommandPath), 'missing explicit host-sync command for menu repair');
$assert(str_contains($provider, 'TimeAttendanceMenuRegistrar'), 'provider does not register/boot the menu registrar');
$assert(str_contains($provider, 'SyncTimeAttendanceMenuCommand'), 'provider does not register the menu host-sync command');
$assert(str_contains($routes, "->name('index')"), 'menu target route is missing');
$assert(is_array($manifest), 'sidecar manifest is invalid JSON');
$assert(str_contains((string) @file_get_contents($root.'/extension.manifest.json'), '"navigation"') && str_contains((string) @file_get_contents($root.'/extension.manifest.json'), '"user"'), 'sidecar does not advertise user navigation contribution');

if (is_file($navigationPath)) {
    require_once $navigationPath;
    $class = 'App\\Extensions\\TitanTimeAttendance\\System\\Navigation\\TimeAttendanceNavigation';
    $assert(class_exists($class), 'navigation class does not resolve');
    if (class_exists($class)) {
        $items = $class::user();
        $assert(count($items) >= 1, 'navigation has no user menu items');
        $keys = [];
        foreach ($items as $item) {
            $key = (string) ($item['key'] ?? '');
            $route = (string) ($item['route'] ?? '');
            $assert($key !== '', 'navigation item missing key');
            $assert(!isset($keys[$key]), "duplicate navigation key {$key}");
            $keys[$key] = true;
            $assert($route === 'dashboard.user.titan-time-attendance.index', "unexpected menu route {$route}");
            $assert(($item['is_admin'] ?? false) === false, 'user menu item incorrectly marked admin');
            $assert(array_key_exists('extension', $item) && $item['extension'] === null, 'time attendance menu must not be hidden behind MagicAI plan-extension filtering');
            $active = $item['active_condition'] ?? [];
            $assert(is_array($active) && in_array('dashboard.user.titan-time-attendance.*', $active, true), 'active route family missing');
        }
    }
}

if (is_file($registrarPath)) {
    $registrar = @file_get_contents($registrarPath) ?: '';
    foreach (['MenuContributionRegistry','ContributionRegistry','MenuService','menus','Schema::hasTable','getColumnListing'] as $needle) {
        $assert(str_contains($registrar, $needle), "menu registrar missing compatibility behavior: {$needle}");
    }
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan Time & Attendance menu/navigation contract\n";
