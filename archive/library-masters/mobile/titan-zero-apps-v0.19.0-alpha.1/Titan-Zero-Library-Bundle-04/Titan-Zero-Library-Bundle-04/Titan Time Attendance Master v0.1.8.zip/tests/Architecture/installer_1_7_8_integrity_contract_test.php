<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$manifest = json_decode((string) file_get_contents($root.'/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$failures = [];
$integrity = $manifest['integrity']['files'] ?? null;
if (! is_array($integrity)) {
    $failures[] = 'extension.json integrity.files must be an object/map';
} else {
    foreach ($integrity as $relative => $declared) {
        if (! is_string($declared) || preg_match('/\A[a-f0-9]{64}\z/', $declared) !== 1) {
            $failures[] = "Installer 1.7.8 requires bare SHA-256 hex for {$relative}";
            continue;
        }
        $path = $root.'/'.$relative;
        if (! is_file($path)) {
            $failures[] = "integrity file missing: {$relative}";
            continue;
        }
        $actual = hash_file('sha256', $path);
        if (! hash_equals($declared, $actual)) {
            $failures[] = "Installer 1.7.8 direct integrity comparison fails: {$relative}";
        }
    }
}

if ($failures !== []) {
    fwrite(STDERR, "Installer 1.7.8 integrity contract: FAIL\n- ".implode("\n- ", array_slice($failures, 0, 12))."\n");
    exit(1);
}

echo "Installer 1.7.8 integrity contract: PASS\n";
