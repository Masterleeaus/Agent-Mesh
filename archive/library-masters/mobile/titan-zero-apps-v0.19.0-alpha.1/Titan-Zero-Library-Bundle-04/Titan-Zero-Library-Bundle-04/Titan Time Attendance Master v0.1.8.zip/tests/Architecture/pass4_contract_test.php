<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $ok, string $message) use (&$failures): void { if (! $ok) $failures[] = $message; };
$contents = static fn(string $relative): string => (string) @file_get_contents($root . '/' . $relative);
$json = static function (string $relative) use ($root, &$failures): array {
    try { return json_decode((string) file_get_contents($root . '/' . $relative), true, 512, JSON_THROW_ON_ERROR) ?: []; }
    catch (Throwable) { $failures[] = 'invalid JSON: ' . $relative; return []; }
};

foreach ([
    'System/Integrations/Rewind/TimeRewindRecordProjector.php',
    'System/Integrations/Rewind/TimeRewindIntegration.php',
    'System/Integrations/Exports/TimePlatformExportRegistry.php',
    'System/Installer/PackageIntegrityVerifier.php',
    'tests/Unit/rewind_record_projector_test.php',
    'tests/Unit/platform_export_registry_test.php',
] as $relative) $assert(is_file($root.'/'.$relative), 'missing Pass-4 file: '.$relative);

$provider = $contents('System/TitanTimeAttendanceServiceProvider.php');
$assert(str_contains($provider, 'TimeRewindIntegration'), 'provider does not wire Rewind integration');
$assert(str_contains($provider, 'registerIfAvailable'), 'provider never attempts safe Rewind source registration');
$assert(str_contains($provider, 'TimePlatformExportRegistry'), 'provider does not expose platform exports');
$assert(str_contains($provider, "File::delete(config_path('titan-time-attendance.php'))"), 'uninstall does not remove only the published config while retaining operational data');

$rewind = $contents('System/Integrations/Rewind/TimeRewindIntegration.php');
foreach (['RewindManagerContract','RewindSourceAdapterContract','RewindEventRecord','registerSourceAdapter'] as $needle) {
    $assert(str_contains($rewind, $needle), 'Rewind integration lacks verified v0.3 contract: '.$needle);
}
$assert(str_contains($rewind, 'interface_exists') && str_contains($rewind, 'class_exists'), 'Rewind integration does not fail closed when Rewind is absent');

$projector = $contents('System/Integrations/Rewind/TimeRewindRecordProjector.php');
$assert(str_contains($projector, 'ext_titan_time_signal_outbox') || str_contains($projector, 'TimeSignalOutbox'), 'Rewind projector does not source time Signal history');
$assert(str_contains($projector, 'TimeCommandReceipt'), 'Rewind projector does not source governed command receipts');
foreach (['token','ip_address','latitude','longitude','notes','payload'] as $sensitive) {
    if ($sensitive === 'payload') continue;
    $assert(! preg_match("/['\"]".preg_quote($sensitive,'/')."['\"]\s*=>\s*\$row/", $projector), 'Rewind projector copies sensitive raw field: '.$sensitive);
}

$exports = $contents('System/Integrations/Exports/TimePlatformExportRegistry.php');
foreach (['governance','wisdom','vertical','CapabilityCatalog'] as $needle) $assert(str_contains($exports, $needle), 'platform export registry lacks '.$needle);
$assert(str_contains($exports, 'source_extension'), 'platform exports do not declare extension ownership');

$preflight = $contents('System/Installer/TimeAttendancePreflight.php');
$health = $contents('System/Health/TimeAttendanceHealthCheck.php');
foreach ([$preflight, $health] as $source) $assert(str_contains($source, 'PackageIntegrityVerifier'), 'preflight/health does not verify installed package integrity');

$routes = $contents('routes/web.php');
$assert(! str_contains($routes, 'workforce-manifest'), 'internal Workforce manifest remains exposed over authenticated user HTTP');
$assert(! is_file($root.'/System/Http/Controllers/WorkforceManifestController.php'), 'dead WorkforceManifestController remains after route removal');
$entryController = $contents('System/Http/Controllers/TimeEntryController.php');
$assert(! str_contains($entryController, "->can('titan-time-attendance.view-all')"), 'TimeEntryController bypasses extension permission service for view-all');
$assert(! str_contains($entryController, "->can('titan-time-attendance.record-others')"), 'TimeEntryController bypasses extension permission service for record-others');

$sidecar = $json('extension.manifest.json');
$assert(($sidecar['governance']['rewind'] ?? null) === 'optional', 'canonical sidecar does not declare optional Titan Rewind governance integration');
$assert(is_file($root.'/System/Integrations/Rewind/TimeRewindIntegration.php'), 'verified Rewind adapter is missing');

if ($failures !== []) {
    fwrite(STDERR, "Pass 4 architecture contract: FAIL\n- ".implode("\n- ",$failures)."\n"); exit(1);
}
echo "Pass 4 architecture contract: PASS\n";
