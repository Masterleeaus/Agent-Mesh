<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Workforce/TimeWorkforceManifestValidator.php';

use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceManifestValidator;

$path = __DIR__.'/../../resources/workforce/workforce-manifest.json';
$manifest = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);

try {
    TimeWorkforceManifestValidator::assertValid($manifest);
} catch (Throwable $e) {
    fwrite(STDERR, "Current Workforce manifest must validate: {$e->getMessage()}\n");
    exit(1);
}

$badWorkflow = $manifest;
$badWorkflow['workflows'][0]['manager'] = 'missing-manager';
$failed = false;
try { TimeWorkforceManifestValidator::assertValid($badWorkflow); } catch (RuntimeException) { $failed = true; }
if (! $failed) {
    fwrite(STDERR, "Validator accepted a workflow referencing an unknown role.\n");
    exit(1);
}

$badPrompt = $manifest;
$badPrompt['prompts'][0]['instructions'] = [];
$failed = false;
try { TimeWorkforceManifestValidator::assertValid($badPrompt); } catch (RuntimeException) { $failed = true; }
if (! $failed) {
    fwrite(STDERR, "Validator accepted a prompt without executable instructions.\n");
    exit(1);
}

echo "Workforce manifest validator: PASS\n";
