<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Wizards/TimeWizardRegistry.php';

use App\Extensions\TitanTimeAttendance\System\Wizards\TimeWizardRegistry;

$registry = new TimeWizardRegistry();
$proposal = $registry->compileProposal('time-attendance.setup', [
    'week_starts_on' => 1,
    'timer_enabled' => true,
    'approvals_enabled' => true,
    'costing_enabled' => true,
    'max_timer_minutes' => 600,
    'max_time_entry_minutes' => 720,
    'default_verification_method' => 'geofence',
    'verification_methods' => ['geofence','dynamic_qr'],
    'store_raw_location' => false,
    'offline_replay_window_minutes' => 1440,
    'offline_stuck_minutes' => 60,
]);
if (($proposal['capability'] ?? '') !== 'time.policy.update') {
    fwrite(STDERR, "Wizard did not compile to governed time.policy.update capability.\n");
    exit(1);
}
if (($proposal['input']['max_timer_minutes'] ?? null) !== 600) {
    fwrite(STDERR, "Wizard proposal lost validated policy input.\n");
    exit(1);
}

$failed = false;
try {
    $registry->compileProposal('attendance.verification-policy', [
        'default_verification_method' => 'face',
        'verification_methods' => ['face'],
        'store_raw_location' => false,
        'offline_replay_window_minutes' => 1440,
        'offline_stuck_minutes' => 60,
    ]);
} catch (InvalidArgumentException) {
    $failed = true;
}
if (! $failed) {
    fwrite(STDERR, "Wizard accepted unsupported verification method.\n");
    exit(1);
}

echo "Wizard registry contract: PASS\n";
