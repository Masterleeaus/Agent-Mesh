<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $ok, string $message) use (&$failures): void {
    if (! $ok) $failures[] = $message;
};
$contents = static fn(string $relative): string => (string) @file_get_contents($root . '/' . $relative);
$safeJson = static function (string $relative) use ($root, &$failures): array {
    $path = $root . '/' . $relative;
    if (! is_file($path)) return [];
    try { return json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR) ?: []; }
    catch (JsonException) { $failures[] = 'invalid JSON: ' . $relative; return []; }
};

$required = [
    'System/Workforce/TimeWorkforceExecutionContext.php',
    'System/Workforce/TimeWorkforceToolGateway.php',
    'System/Workforce/TimeWorkforceManifestValidator.php',
    'System/Workforce/Decision/TimeRiskPort.php',
    'System/Workforce/Decision/TimeAssurancePort.php',
    'System/Workforce/Decision/TimeAutonomyPort.php',
    'System/Workforce/Decision/DeferredTimeRiskPort.php',
    'System/Workforce/Decision/DeferredTimeAssurancePort.php',
    'System/Workforce/Decision/ConfiguredTimeAutonomyPort.php',
    'System/Workforce/Decision/TimeWorkforceDecisionGate.php',
    'System/Intelligence/AttentionFinding.php',
    'System/Intelligence/TimeAttentionDetector.php',
    'System/Services/TimeAttentionService.php',
    'System/Models/TimeAttentionFinding.php',
    'System/Workforce/Workflows/TimeWorkflowRegistry.php',
    'System/Workforce/Workflows/TimeWorkflowService.php',
    'System/Models/TimeWorkflowRun.php',
    'System/Wizards/TimeWizardRegistry.php',
    'System/Surfaces/TimeSurfaceRegistry.php',
    'resources/workforce/wizards.json',
    'resources/surfaces/surfaces.json',
    'database/migrations/2026_08_15_000006_add_ext_titan_time_attention.php',
    'database/migrations/2026_08_15_000007_add_ext_titan_time_workflow_runs.php',
];
foreach ($required as $relative) $assert(is_file($root . '/' . $relative), "missing Pass-3 file: {$relative}");

$gateway = $contents('System/Workforce/TimeWorkforceToolGateway.php');
$assert(str_contains($gateway, 'TimeCommandBusGateway'), 'Workforce write gateway does not use TimeCommandBusGateway');
$assert(str_contains($gateway, "'titan_workforce'"), 'Workforce write gateway does not identify Titan Workforce source');
$assert(! str_contains($gateway, "input['company_id']"), 'Workforce gateway accepts tenant identity from model input');
$assert(! str_contains($gateway, "input['actor_user_id']"), 'Workforce gateway accepts actor identity from model input');
$assert(str_contains($gateway, 'role_tool_not_allowed'), 'Workforce gateway does not enforce extension-owned role tool access');
$assert(str_contains($gateway, 'role_risk_ceiling_mismatch'), 'Workforce gateway does not validate trusted role risk ceiling against extension manifest');
$assert(str_contains($gateway, 'array_replace($input'), 'Workforce gateway does not override model lineage with trusted context');
$assert(str_contains($gateway, 'TimeAttendancePermissionService'), 'Workforce read gateway does not re-check actor extension permissions');
foreach (['trace_id','correlation_id','causation_id','idempotency_key','_context'] as $field) {
    $assert(str_contains($gateway, "'{$field}'"), "Workforce gateway does not explicitly reject model-supplied trusted lineage field: {$field}");
}

$context = $contents('System/Workforce/TimeWorkforceExecutionContext.php');
$assert(! str_contains($context, 'allowedCapabilities === [] ||'), 'empty trusted capability set currently grants all Workforce capabilities');
foreach (['companyId','actorUserId','roleKey','autonomyLevel','traceId','correlationId','idempotencyKey'] as $needle) {
    $assert(str_contains($context, $needle), "trusted Workforce context lacks {$needle}");
}

$decisionGate = $contents('System/Workforce/Decision/TimeWorkforceDecisionGate.php');
$assert(str_contains($decisionGate, 'pending_approval'), 'decision gate has no mandatory human approval state');
$assert(str_contains($decisionGate, 'risk_ceiling'), 'decision gate does not enforce role risk ceiling');
$assert(str_contains($decisionGate, 'TimeRiskPort') && str_contains($decisionGate, 'TimeAssurancePort') && str_contains($decisionGate, 'TimeAutonomyPort'), 'decision gate does not consume Risk/Assurance/Autonomy ports');
$assert(! str_contains(strtolower($decisionGate), 'promote'), 'decision gate contains autonomy self-promotion path');

$detector = $contents('System/Intelligence/TimeAttentionDetector.php');
foreach (['stale_submission','overdue_timer','failed_verification','offline_rejected','overlapping_time','long_time_entry'] as $needle) {
    $assert(str_contains($detector, $needle), "attention detector lacks {$needle} finding");
}
$assert(str_contains($detector, 'scan_limit') && str_contains($detector, 'limit($scanLimit)'), 'attention detector does not bound proactive scan queries');
foreach (['->save(', '->create(', '->update(', '->delete('] as $mutation) {
    $assert(! str_contains($detector, $mutation), "attention detector mutates authoritative data via {$mutation}");
}

$attentionService = $contents('System/Services/TimeAttentionService.php');
$assert(str_contains($attentionService, 'company_id') && str_contains($attentionService, 'finding_key') && str_contains($attentionService, 'source_ref'), 'attention persistence lacks tenant/idempotency dimensions');
$assert(str_contains($attentionService, "'status' => 'resolved'") && str_contains($attentionService, 'resolved_at'), 'attention findings are never resolved when the underlying condition clears');
$assert(str_contains($attentionService, "'offline-rejected:'"), 'offline attention does not reuse canonical offline-rejection deduplication identity');

$workflowRegistry = $contents('System/Workforce/Workflows/TimeWorkflowRegistry.php');
foreach (['attendance.verification.failed','time.timer.overdue','time.submission.ready_for_review','attendance.offline.rejected'] as $signal) {
    $assert(str_contains($workflowRegistry, $signal), "workflow registry lacks {$signal}");
}
$workflowService = $contents('System/Workforce/Workflows/TimeWorkflowService.php');
$assert(str_contains($workflowService, 'dedup_key') && str_contains($workflowService, 'company_id'), 'workflow service lacks tenant-scoped idempotency');

$wizards = $safeJson('resources/workforce/wizards.json');
$surfaces = $safeJson('resources/surfaces/surfaces.json');
$workforce = $safeJson('resources/workforce/workforce-manifest.json');
$sidecar = $safeJson('extension.manifest.json');

$activeCapabilities = array_fill_keys($sidecar['capabilities'] ?? [], true);
$manifestTools = [];
$manifestToolCapabilities = [];
foreach ($workforce['tools'] ?? [] as $tool) {
    $toolId = (string)($tool['tool_id'] ?? '');
    $toolCapability = (string)($tool['capability'] ?? '');
    $manifestTools[$toolId] = true;
    $manifestToolCapabilities[$toolId] = $toolCapability;
    $assert(isset($activeCapabilities[$toolCapability]), "Workforce tool references inactive capability: {$toolId} -> {$toolCapability}");
}
$assert(($manifestToolCapabilities['attendance.policy.inspect'] ?? '') === 'time.policy.read', 'attendance.policy.inspect is not least-privilege read capability');
foreach ($workforce['role_bindings'] ?? [] as $role) {
    $roleCaps = array_fill_keys($role['capabilities'] ?? [], true);
    foreach ($role['tool_access'] ?? [] as $toolId) {
        $assert(isset($manifestTools[$toolId]), 'role references undeclared tool: ' . ($role['key'] ?? '?') . ' -> ' . $toolId);
        $toolCap = $manifestToolCapabilities[$toolId] ?? '';
        $assert($toolCap === '' || isset($roleCaps[$toolCap]), 'role tool capability not granted to role: ' . ($role['key'] ?? '?') . ' -> ' . $toolId . ' / ' . $toolCap);
    }
}
foreach ($wizards['wizards'] ?? [] as $wizard) {
    $assert(($wizard['status'] ?? '') === 'active', 'Pass-3 wizard is not active: ' . ($wizard['wizard_id'] ?? '?'));
    foreach ($wizard['capabilities'] ?? [] as $capability) $assert(isset($activeCapabilities[$capability]), "wizard references inactive capability: {$capability}");
}
foreach ($surfaces['surfaces'] ?? [] as $surface) {
    foreach ($surface['tools'] ?? [] as $tool) $assert(isset($manifestTools[$tool]), "surface references undeclared tool: {$tool}");
    foreach ($surface['actions'] ?? [] as $action) {
        $capability = (string)($action['capability'] ?? '');
        $assert($capability === '' || isset($activeCapabilities[$capability]), "surface references inactive capability: {$capability}");
    }
}

$verificationService = $contents('System/Services/AttendanceVerificationService.php');
$assert(str_contains($verificationService, "hash_hmac('sha256'") && str_contains($verificationService, 'companyId'), 'IP attendance evidence is not tenant-keyed before persistence');
$assert(! str_contains($verificationService, "config('app.key','titan-time-attendance')"), 'attendance verification privacy hashing has a predictable APP_KEY fallback');
$assert(str_contains($verificationService, "throw new \\RuntimeException('Titan Time & Attendance requires a configured APP_KEY for privacy hashing.')"), 'attendance verification privacy hashing does not fail closed without APP_KEY');
$preflight = $contents('System/Installer/TimeAttendancePreflight.php');
$assert(str_contains($preflight, "'app_key'"), 'installer preflight does not verify APP_KEY required for privacy hashing');
$offlineController = $contents('System/Http/Controllers/OfflineAttendanceController.php');
$assert(str_contains($offlineController, "'device_id'=>'required|string|max:128'"), 'offline HTTP contract drops required device_id');
$assert(str_contains($offlineController, "'device_sequence'=>'required|integer|min:0'"), 'offline HTTP contract drops required device_sequence');
$offlineModel = $contents('System/Models/OfflineAttendanceEvent.php');
foreach (['device_id','device_sequence','reconciliation_status'] as $needle) $assert(str_contains($offlineModel, $needle), "offline model lacks {$needle}");
$offlineService = $contents('System/Services/OfflineAttendanceService.php');
$assert(! str_contains($offlineService, "safe['token']"), 'offline service persists raw QR token');
$assert(! str_contains($offlineService, "safe['ip_address']"), 'offline service persists raw IP address');
$assert(str_contains($offlineService, 'location_hash'), 'offline service does not minimise raw location evidence when raw storage is disabled');
$assert(str_contains($offlineService, 'AttendanceVerificationService'), 'offline presence evidence is not server-revalidated through canonical attendance verification');
$assert(str_contains($offlineService, 'Str::isUuid'), 'offline service does not validate source_event_id for non-HTTP/Workforce callers');
$assert(str_contains($offlineService, "['device_sequence'=>'device_sequence is required") || str_contains($offlineService, "['device_sequence' => 'device_sequence is required"), 'offline ingestion does not require a device sequence');
$assert(str_contains($offlineService, 'verification_log_id'), 'offline reconciliation does not retain canonical verification receipt identity');
$assert(str_contains($offlineService, "hash_hmac('sha256', \$deviceId") && str_contains($offlineService, "'device_id'=>\$deviceKey"), 'offline service stores raw device identity instead of a tenant-pseudonymous device key');
$assert(str_contains($offlineService, "hash_hmac('sha256', \$payload['ip_address']"), 'offline IP evidence is not keyed/HMAC-minimised');
$assert(substr_count($offlineService, 'Str::isUuid($sourceEventId)') === 1, 'offline service repeats source_event_id UUID validation instead of maintaining one canonical validation gate');
$assert(! str_contains($offlineService, "config('app.key', 'titan-time-attendance')"), 'offline privacy hashing has a predictable fallback when APP_KEY is unavailable');
$assert(str_contains($offlineService, "throw new \\RuntimeException('Titan Time & Attendance requires a configured APP_KEY for privacy hashing.')"), 'offline privacy hashing does not fail closed when APP_KEY is unavailable');
$migration6 = $contents('database/migrations/2026_08_15_000006_add_ext_titan_time_attention.php');
$assert(str_contains($migration6, "unique(['company_id','device_id','device_sequence']"), 'offline device sequence is not protected by a tenant-scoped unique constraint');
$assert(str_contains($migration6, "dropUnique('ext_titan_time_offline_device_seq')"), 'offline device sequence unique constraint is not rolled back correctly');

$provider = $contents('System/TitanTimeAttendanceServiceProvider.php');
$assert(str_contains($provider, 'if(!is_array($envelope))return;'), 'global titan.signal listener can type-error on non-array payloads');
foreach (['TimeWorkforceToolGateway','TimeWorkforceDecisionGate','TimeAttentionService','TimeWorkflowService','TimeWizardRegistry','TimeSurfaceRegistry'] as $needle) {
    $assert(str_contains($provider, $needle), "provider does not wire {$needle}");
}

$manifestLoader = $contents('System/Workforce/TimeAttendanceWorkforceManifest.php');
$assert(str_contains($manifestLoader, 'TimeWorkforceManifestValidator::assertValid'), 'Workforce manifest is loaded without runtime cross-reference validation');
$manifestSource = $contents('resources/workforce/workforce-manifest.json');
$assert(! str_contains(strtolower($manifestSource), 'self_promotion": true'), 'Workforce manifest permits self promotion');

foreach (['ext_titan_time_attention_findings','ext_titan_time_workflow_runs'] as $table) {
    $assert(in_array($table, $sidecar['database']['owned_tables'] ?? [], true), "sidecar does not own {$table}");
}

if ($failures !== []) {
    fwrite(STDERR, "Pass 3 architecture contract: FAIL\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "Pass 3 architecture contract: PASS\n";
