<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Domain/TimeIntervalOverlap.php';

use App\Extensions\TitanTimeAttendance\System\Domain\TimeIntervalOverlap;

$rows = [
    ['id'=>1,'user_id'=>7,'work_date'=>'2026-08-14','start_time'=>'09:00:00','end_time'=>'12:00:00'],
    ['id'=>2,'user_id'=>7,'work_date'=>'2026-08-14','start_time'=>'11:30:00','end_time'=>'13:00:00'],
    ['id'=>3,'user_id'=>7,'work_date'=>'2026-08-14','start_time'=>'13:00:00','end_time'=>'14:00:00'],
    ['id'=>4,'user_id'=>8,'work_date'=>'2026-08-14','start_time'=>'10:00:00','end_time'=>'11:00:00'],
];
$pairs = TimeIntervalOverlap::pairs($rows);
if (count($pairs) !== 1 || ($pairs[0]['left_id'] ?? null) !== 1 || ($pairs[0]['right_id'] ?? null) !== 2) {
    fwrite(STDERR, "Expected only entries 1 and 2 to overlap.\n");
    exit(1);
}
if (($pairs[0]['overlap_minutes'] ?? null) !== 30) {
    fwrite(STDERR, "Expected 30 minutes overlap.\n");
    exit(1);
}

echo "Time interval overlap: PASS\n";
