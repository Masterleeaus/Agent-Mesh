<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $ok, string $message) use (&$failures): void {
    if (! $ok) $failures[] = $message;
};
$contents = static fn(string $relative): string => (string) @file_get_contents($root . '/' . $relative);

$required = [
    'System/Governance/TimeCommandBusPort.php',
    'System/Governance/DeferredTimeCommandBusPort.php',
    'System/Governance/TimeCommandRequest.php',
    'System/Governance/TimeCommandBusGateway.php',
    'System/Governance/TimeCapabilityExecutor.php',
    'System/Governance/TimeCommandReceiptService.php',
    'System/Models/TimeCommandReceipt.php',
    'System/Integrations/Crm/CrmWorkAuthorityPort.php',
    'System/Integrations/Crm/CrmWorkAuthorityAdapter.php',
    'System/Security/TimeAttendancePermissionService.php',
    'System/Console/Commands/DeliverTimeSignalsCommand.php',
    'System/Jobs/DeliverTimeSignalsJob.php',
    'database/migrations/2026_08_15_000005_add_ext_titan_time_governance.php',
];
foreach ($required as $relative) $assert(is_file($root . '/' . $relative), "missing Pass-2 file: {$relative}");

$capabilitySource = $contents('System/Support/CapabilityCatalog.php');
foreach (['permission', 'risk', 'human_approval', 'handler'] as $needle) {
    $assert(str_contains($capabilitySource, $needle), "capability catalog lacks {$needle} metadata");
}

$companyContext = $contents('System/Support/CompanyContext.php');
$assert(! str_contains($companyContext, "'active_company_id'"), 'company context still silently falls back to active_company_id');
$assert(str_contains($companyContext, 'attribute($user, \'company_id\')'), 'company context must read canonical company_id from the authorised actor');
$assert(str_contains($companyContext, 'CrmCompanyScope'), 'company context does not adapt to the canonical CRM tenant context when CRM is installed');
$assert(! str_contains($companyContext, 'use App\\Extensions\\Crm'), 'company context hard-imports optional CRM tenancy implementation');


$preflight = $contents('System/Installer/TimeAttendancePreflight.php');
$assert(str_contains($preflight, "extension_loaded('mbstring')"), 'preflight does not declare mbstring used by signal error redaction');
$assert(str_contains($preflight, '2026_08_15_000005_add_ext_titan_time_governance.php'), 'preflight does not verify Pass-2 governance migration presence');

$provider = $contents('System/TitanTimeAttendanceServiceProvider.php');
foreach (['TimeCommandBusPort', 'DeferredTimeCommandBusPort', 'TimeCommandBusGateway', 'CrmWorkAuthorityPort', 'CrmWorkAuthorityAdapter', 'DeliverTimeSignalsCommand'] as $needle) {
    $assert(str_contains($provider, $needle), "provider does not wire {$needle}");
}

foreach (['TimeEntryController.php','TimerController.php','SubmissionController.php','AttendanceVerificationController.php','OfflineAttendanceController.php'] as $controller) {
    $source = $contents('System/Http/Controllers/' . $controller);
    $assert(str_contains($source, 'TimeCommandBusGateway'), "{$controller} does not route mutations through TimeCommandBusGateway");
}

$migration = $contents('database/migrations/2026_08_15_000005_add_ext_titan_time_governance.php');
$assert(str_contains($migration, 'ext_titan_time_command_receipts'), 'governance migration lacks command receipt table');
$assert(str_contains($migration, 'idempotency_key'), 'governance migration lacks idempotency key');
$assert(str_contains($migration, 'dedup_key'), 'governance migration lacks signal dedup key');
$assert(str_contains($migration, 'work_order_public_id'), 'governance migration lacks canonical CRM work-order public reference');
$assert(str_contains($migration, 'service_location_public_id'), 'governance migration lacks canonical CRM service-location public reference');
$assert(str_contains($migration, 'ext_titan_time_verify_location_ref'), 'governance migration relies on an over-length default MySQL index name');
$assert(str_contains($migration, '$table->dropIndex($indexName)'), 'governance rollback does not explicitly remove service-location index');
$receiptService = $contents('System/Governance/TimeCommandReceiptService.php');
$gatewaySource = $contents('System/Governance/TimeCommandBusGateway.php');
$assert(str_contains($receiptService, 'function reserve'), 'command idempotency has no pre-execution reservation');
$assert(str_contains($gatewaySource, '->reserve('), 'gateway does not reserve idempotency before local mutation');
$assert(str_contains($receiptService, 'lockForUpdate'), 'command receipt reservation does not serialize concurrent retries');


$requestSource = $contents('System/Governance/TimeCommandRequest.php');
foreach (['risk_class', 'human_approval_required', 'required_permission'] as $needle) {
    $assert(str_contains($requestSource, $needle), "command request does not carry {$needle} governance metadata");
}

$crmAdapter = $contents('System/Integrations/Crm/CrmWorkAuthorityAdapter.php');
$assert(! str_contains($crmAdapter, 'App\\Extensions\\Crm\\System\\Models'), 'CRM adapter imports CRM persistence models directly');
$assert(str_contains($crmAdapter, 'companyId'), 'CRM authority adapter does not carry tenant context');
$assert(str_contains($crmAdapter, 'workOrderPublicId'), 'CRM authority adapter does not validate canonical work-order public ids');
$assert(str_contains($crmAdapter, 'serviceLocationPublicId'), 'CRM authority adapter does not validate canonical service-location public ids');


$toolRegistry = $contents('System/Workforce/TimeAttendanceToolRegistry.php');
$assert(str_contains($toolRegistry, "work_order_public_id"), 'Workforce time tools cannot query canonical CRM work-order references');
$assert(str_contains($toolRegistry, "service_location_public_id"), 'Workforce attendance tools cannot query canonical CRM service-location references');

$workforce = json_decode($contents('resources/workforce/workforce-manifest.json'), true, 512, JSON_THROW_ON_ERROR);
foreach (($workforce['role_bindings'] ?? []) as $binding) {
    $assert(str_starts_with((string)($binding['role_definition_id']??''), 'titan.'), 'workforce binding missing canonical role id');
    $assert(($binding['authority_inherited']??null)===false, 'workforce binding must not inherit authority');
}

$sidecar = json_decode($contents('extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$assert(in_array('ext_titan_time_command_receipts', $sidecar['database']['owned_tables'] ?? [], true), 'sidecar does not own command receipts table');
$assert(($sidecar['queues']['used'] ?? false) === true, 'sidecar does not declare signal delivery queue');
$assert(!empty($sidecar['schedules'] ?? []), 'sidecar does not declare signal retry schedule');
$jobSource = $contents('System/Jobs/DeliverTimeSignalsJob.php');
$assert(str_contains($jobSource, 'ShouldQueue'), 'signal delivery job is not a real queue job');
$assert(str_contains($jobSource, 'companyId'), 'signal delivery job does not carry immutable tenant context');
$dispatcherSource = $contents('System/Governance/TimeSignalOutboxDispatcher.php');
$assert(str_contains($dispatcherSource, 'deliverTenant'), 'signal dispatcher is not tenant partitioned');
$signalService = $contents('System/Services/SignalOutboxService.php');
$assert(str_contains($signalService, 'QueryException'), 'signal deduplication does not handle insert races');
$verificationService = $contents('System/Services/AttendanceVerificationService.php');
$assert(str_contains($verificationService, '(string)$fence->service_location_public_id') && !str_contains($verificationService, '$fence->service_location_public_id!==null'), 'geofence canonical service-location binding is not fail-closed');
$assert(str_contains($verificationService, '(string)$credential->service_location_public_id') && !str_contains($verificationService, '$credential->service_location_public_id!==null'), 'QR canonical service-location binding is not fail-closed');

if ($failures !== []) {
    fwrite(STDERR, "Pass 2 architecture contract: FAIL\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "Pass 2 architecture contract: PASS\n";
