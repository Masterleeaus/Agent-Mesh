<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Governance/SignalDeliveryPolicy.php';

use App\Extensions\TitanTimeAttendance\System\Governance\SignalDeliveryPolicy;

$policy = new SignalDeliveryPolicy(maxAttempts: 4, leaseSeconds: 120);

$expected = [1 => 30, 2 => 60, 3 => 120, 4 => 240, 5 => 480];
foreach ($expected as $attempt => $seconds) {
    if ($policy->retryDelaySeconds($attempt) !== $seconds) {
        fwrite(STDERR, "Unexpected retry delay for attempt {$attempt}.\n");
        exit(1);
    }
}
if ($policy->shouldDeadLetter(3)) {
    fwrite(STDERR, "Attempt 3 must not dead-letter when maxAttempts=4.\n");
    exit(1);
}
if (! $policy->shouldDeadLetter(4)) {
    fwrite(STDERR, "Attempt 4 must dead-letter when maxAttempts=4.\n");
    exit(1);
}
if ($policy->leaseSeconds() !== 120) {
    fwrite(STDERR, "Lease seconds mismatch.\n");
    exit(1);
}
if ($policy->safeError(new RuntimeException('token=SECRET https://private.example/path')) !== 'RuntimeException') {
    fwrite(STDERR, "safeError must not persist exception message content.\n");
    exit(1);
}

echo "Signal delivery policy: PASS\n";
