<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Workforce/TimeWorkforceExecutionContext.php';
require_once __DIR__.'/../../System/Workforce/Decision/TimeRiskPort.php';
require_once __DIR__.'/../../System/Workforce/Decision/TimeAssurancePort.php';
require_once __DIR__.'/../../System/Workforce/Decision/TimeAutonomyPort.php';
require_once __DIR__.'/../../System/Workforce/Decision/ConfiguredTimeAutonomyPort.php';
require_once __DIR__.'/../../System/Workforce/Decision/TimeWorkforceDecisionGate.php';

use App\Extensions\TitanTimeAttendance\System\Workforce\Decision\{ConfiguredTimeAutonomyPort,TimeAssurancePort,TimeAutonomyPort,TimeRiskPort,TimeWorkforceDecisionGate};
use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceExecutionContext;

final class TestPrincipal { public function __construct(public int $id){} public function getKey(): int{return $this->id;} }
final class AllowRisk implements TimeRiskPort {public function available(): bool{return true;} public function evaluate(string $capability,string $riskClass,TimeWorkforceExecutionContext $context,array $input): array{return ['allowed'=>true,'reason'=>null];}}
final class AllowAssurance implements TimeAssurancePort {public function available(): bool{return true;} public function evaluate(string $capability,string $riskClass,TimeWorkforceExecutionContext $context,array $input): array{return ['allowed'=>true,'reason'=>null];}}
final class DenyRisk implements TimeRiskPort {public function available(): bool{return true;} public function evaluate(string $capability,string $riskClass,TimeWorkforceExecutionContext $context,array $input): array{return ['allowed'=>false,'reason'=>'risk_policy_blocked'];}}

$makeContext=static function(string $autonomy,string $risk='HIGH',string $mode='execute'): TimeWorkforceExecutionContext {
    return new TimeWorkforceExecutionContext(7,11,new TestPrincipal(11),'time-attendance-manager',$risk,$autonomy,['time.submission.review'],'trace','corr',null,'idem',$mode);
};
$gate=new TimeWorkforceDecisionGate(new AllowRisk(),new AllowAssurance(),new ConfiguredTimeAutonomyPort());
$definition=['risk'=>'HIGH','human_approval'=>true];

$suggest=$gate->evaluate('time.submission.review',$definition,$makeContext('Suggest'),[]);
if(($suggest['status']??'')!=='prepared'||($suggest['dispatch']??true)!==false){fwrite(STDERR,"Suggest must prepare, not dispatch.\n");exit(1);}

$semi=$gate->evaluate('time.submission.review',$definition,$makeContext('Semi-Auto'),[]);
if(($semi['status']??'')!=='pending_approval'||($semi['dispatch']??false)!==true){fwrite(STDERR,"Semi-Auto must be able to submit an approval-required command for human approval.\n");exit(1);}

$denyGate=new TimeWorkforceDecisionGate(new DenyRisk(),new AllowAssurance(),new ConfiguredTimeAutonomyPort());
$blocked=$denyGate->evaluate('time.submission.review',$definition,$makeContext('Semi-Auto'),[]);
if(($blocked['status']??'')!=='blocked'||($blocked['dispatch']??true)!==false||($blocked['reason']??'')!=='risk_policy_blocked'){fwrite(STDERR,"High-risk approval-required actions must pass Titan Risk before entering human approval.\n");exit(1);}

$medium=$gate->evaluate('attendance.verify',['risk'=>'MEDIUM','human_approval'=>false],$makeContext('Semi-Auto','MEDIUM'),[]);
if(($medium['status']??'')!=='prepared'){fwrite(STDERR,"Semi-Auto must not directly execute MEDIUM mutation under configured autonomy policy.\n");exit(1);}

echo "Workforce decision policy: PASS\n";
