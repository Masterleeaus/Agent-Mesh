<?php

declare(strict_types=1);

require_once __DIR__.'/../../System/Workforce/Workflows/TimeWorkflowRegistry.php';
require_once __DIR__.'/../../System/Workforce/Workflows/TimeWorkflowService.php';

use App\Extensions\TitanTimeAttendance\System\Workforce\Workflows\{TimeWorkflowRegistry,TimeWorkflowService};

$service = new TimeWorkflowService(new TimeWorkflowRegistry());
$result = $service->handleSignal(['event_type' => 'titan.platform.health']);
if ($result !== null) {
    fwrite(STDERR, "Unrelated Signal must be ignored.\n");
    exit(1);
}

echo "Workflow signal boundary: PASS\n";
