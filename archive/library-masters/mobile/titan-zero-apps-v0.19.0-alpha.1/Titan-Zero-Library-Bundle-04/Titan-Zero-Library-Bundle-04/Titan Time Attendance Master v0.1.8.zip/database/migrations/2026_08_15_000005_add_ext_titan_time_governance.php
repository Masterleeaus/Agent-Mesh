<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const LOCATION_INDEXES = [
        'ext_titan_time_geofences' => 'ext_titan_time_geofence_location_ref',
        'ext_titan_time_qr_credentials' => 'ext_titan_time_qr_location_ref',
        'ext_titan_time_ip_rules' => 'ext_titan_time_ip_location_ref',
        'ext_titan_time_verification_logs' => 'ext_titan_time_verify_location_ref',
    ];

    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_command_receipts')) {
            Schema::create('ext_titan_time_command_receipts', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->uuid('command_id')->unique();
                $table->string('capability', 96)->index();
                $table->string('idempotency_key', 128);
                $table->string('request_hash', 64);
                $table->unsignedBigInteger('actor_user_id')->index();
                $table->string('actor_type', 24)->default('human');
                $table->string('source', 48)->index();
                $table->string('risk_class', 16);
                $table->boolean('human_approval_required')->default(false);
                $table->string('status', 24)->index();
                $table->json('result')->nullable();
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamp('executed_at')->nullable();
                $table->timestamps();
                $table->unique(
                    ['company_id', 'capability', 'idempotency_key'],
                    'ext_titan_time_command_idempotency',
                );
            });
        }

        if (! Schema::hasColumn('ext_titan_time_signal_outbox', 'dedup_key')) {
            Schema::table('ext_titan_time_signal_outbox', function (Blueprint $table): void {
                $table->string('dedup_key', 160)->nullable()->after('event_type');
                $table->unique(['company_id', 'dedup_key'], 'ext_titan_time_signal_dedup');
            });
        }

        if (! Schema::hasColumn('ext_titan_time_entries', 'work_order_public_id')) {
            Schema::table('ext_titan_time_entries', function (Blueprint $table): void {
                $table->string('work_order_public_id', 26)->nullable()->after('work_order_id');
                $table->index('work_order_public_id', 'ext_titan_time_entry_work_ref');
            });
        }

        if (! Schema::hasColumn('ext_titan_time_timers', 'work_order_public_id')) {
            Schema::table('ext_titan_time_timers', function (Blueprint $table): void {
                $table->string('work_order_public_id', 26)->nullable()->after('work_order_id');
                $table->index('work_order_public_id', 'ext_titan_time_timer_work_ref');
            });
        }

        foreach (self::LOCATION_INDEXES as $tableName => $indexName) {
            if (! Schema::hasColumn($tableName, 'service_location_public_id')) {
                Schema::table($tableName, function (Blueprint $table) use ($indexName): void {
                    $table->string('service_location_public_id', 26)->nullable()->after('site_id');
                    $table->index('service_location_public_id', $indexName);
                });
            }
        }
    }

    public function down(): void
    {
        foreach (array_reverse(self::LOCATION_INDEXES, true) as $tableName => $indexName) {
            if (Schema::hasColumn($tableName, 'service_location_public_id')) {
                Schema::table($tableName, function (Blueprint $table) use ($indexName): void {
                    $table->dropIndex($indexName);
                    $table->dropColumn('service_location_public_id');
                });
            }
        }

        if (Schema::hasColumn('ext_titan_time_timers', 'work_order_public_id')) {
            Schema::table('ext_titan_time_timers', function (Blueprint $table): void {
                $table->dropIndex('ext_titan_time_timer_work_ref');
                $table->dropColumn('work_order_public_id');
            });
        }

        if (Schema::hasColumn('ext_titan_time_entries', 'work_order_public_id')) {
            Schema::table('ext_titan_time_entries', function (Blueprint $table): void {
                $table->dropIndex('ext_titan_time_entry_work_ref');
                $table->dropColumn('work_order_public_id');
            });
        }

        if (Schema::hasColumn('ext_titan_time_signal_outbox', 'dedup_key')) {
            Schema::table('ext_titan_time_signal_outbox', function (Blueprint $table): void {
                $table->dropUnique('ext_titan_time_signal_dedup');
                $table->dropColumn('dedup_key');
            });
        }

        Schema::dropIfExists('ext_titan_time_command_receipts');
    }
};
