<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {

        if (Schema::hasTable('ext_titan_time_entries')) {
            Schema::table('ext_titan_time_entries', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_time_entries', 'start_time')) $table->time('start_time')->nullable()->after('work_date');
                if (! Schema::hasColumn('ext_titan_time_entries', 'end_time')) $table->time('end_time')->nullable()->after('start_time');
            });
        }

        if (Schema::hasTable('ext_titan_time_policies')) {
            Schema::table('ext_titan_time_policies', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_time_policies', 'max_timer_minutes')) $table->unsignedInteger('max_timer_minutes')->default(720);
                if (! Schema::hasColumn('ext_titan_time_policies', 'max_time_entry_minutes')) $table->unsignedInteger('max_time_entry_minutes')->default(720);
                if (! Schema::hasColumn('ext_titan_time_policies', 'stale_submission_days')) $table->unsignedTinyInteger('stale_submission_days')->default(2);
                if (! Schema::hasColumn('ext_titan_time_policies', 'offline_stuck_minutes')) $table->unsignedInteger('offline_stuck_minutes')->default(60);
            });
        }

        if (Schema::hasTable('ext_titan_time_offline_events')) {
            Schema::table('ext_titan_time_offline_events', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_time_offline_events', 'device_id')) $table->string('device_id', 128)->nullable()->after('event_type');
                if (! Schema::hasColumn('ext_titan_time_offline_events', 'device_sequence')) $table->unsignedBigInteger('device_sequence')->nullable()->after('device_id');
                if (! Schema::hasColumn('ext_titan_time_offline_events', 'verification_log_id')) $table->unsignedBigInteger('verification_log_id')->nullable()->after('sync_status');
                if (! Schema::hasColumn('ext_titan_time_offline_events', 'reconciliation_status')) $table->string('reconciliation_status', 32)->default('pending_review')->after('verification_log_id');
                if (! Schema::hasColumn('ext_titan_time_offline_events', 'reconciled_at')) $table->timestamp('reconciled_at')->nullable()->after('reconciliation_status');
            });
            Schema::table('ext_titan_time_offline_events', function (Blueprint $table): void {
                $table->unique(['company_id','device_id','device_sequence'],'ext_titan_time_offline_device_seq');
                $table->index(['company_id','reconciliation_status'],'ext_titan_time_offline_reconcile');
                $table->index(['company_id','verification_log_id'],'ext_titan_time_offline_verify');
            });
        }

        Schema::create('ext_titan_time_attention_findings', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->string('finding_key', 64);
            $table->string('finding_type', 64)->index();
            $table->string('source_ref', 128);
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('assigned_role', 96)->index();
            $table->string('severity', 16)->default('LOW')->index();
            $table->string('status', 24)->default('open')->index();
            $table->string('recommended_capability', 96)->nullable();
            $table->json('evidence')->nullable();
            $table->timestamp('detected_at')->nullable()->index();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id','finding_key','source_ref'],'ext_titan_time_attention_unique');
            $table->index(['company_id','status','severity'],'ext_titan_time_attention_queue');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_attention_findings');
        if (Schema::hasTable('ext_titan_time_offline_events')) {
            Schema::table('ext_titan_time_offline_events', function (Blueprint $table): void {
                try { $table->dropUnique('ext_titan_time_offline_device_seq'); } catch (Throwable) {}
                foreach (['ext_titan_time_offline_reconcile','ext_titan_time_offline_verify'] as $index) {
                    try { $table->dropIndex($index); } catch (Throwable) {}
                }
                foreach (['device_id','device_sequence','verification_log_id','reconciliation_status','reconciled_at'] as $column) {
                    if (Schema::hasColumn('ext_titan_time_offline_events', $column)) $table->dropColumn($column);
                }
            });
        }

        if (Schema::hasTable('ext_titan_time_entries')) {
            Schema::table('ext_titan_time_entries', function (Blueprint $table): void {
                foreach (['start_time','end_time'] as $column) {
                    if (Schema::hasColumn('ext_titan_time_entries', $column)) $table->dropColumn($column);
                }
            });
        }
        if (Schema::hasTable('ext_titan_time_policies')) {
            Schema::table('ext_titan_time_policies', function (Blueprint $table): void {
                foreach (['max_timer_minutes','max_time_entry_minutes','stale_submission_days','offline_stuck_minutes'] as $column) {
                    if (Schema::hasColumn('ext_titan_time_policies', $column)) $table->dropColumn($column);
                }
            });
        }
    }
};
