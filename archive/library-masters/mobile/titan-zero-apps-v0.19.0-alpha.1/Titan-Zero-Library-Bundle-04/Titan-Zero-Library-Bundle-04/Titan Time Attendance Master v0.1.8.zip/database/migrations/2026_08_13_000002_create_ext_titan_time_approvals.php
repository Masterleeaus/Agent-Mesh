<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_submissions')) {
            Schema::create('ext_titan_time_submissions', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('user_id')->index();
                $t->date('week_start');$t->date('week_end');$t->string('status',24)->default('submitted')->index();
                $t->unsignedBigInteger('reviewed_by_user_id')->nullable()->index();$t->timestamp('submitted_at')->nullable();$t->timestamp('reviewed_at')->nullable();
                $t->text('review_notes')->nullable();$t->uuid('trace_id')->nullable()->index();$t->timestamps();
                $t->unique(['company_id','user_id','week_start'],'ext_titan_time_submission_week');
            });
        }
        if (! Schema::hasTable('ext_titan_time_submission_items')) {
            Schema::create('ext_titan_time_submission_items', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('submission_id')->index();$t->unsignedBigInteger('time_entry_id')->index();$t->timestamps();
                $t->unique(['submission_id','time_entry_id'],'ext_titan_time_submission_item');
            });
        }
        if (! Schema::hasTable('ext_titan_time_policies')) {
            Schema::create('ext_titan_time_policies', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->unique();$t->unsignedTinyInteger('week_starts_on')->default(1);$t->boolean('timer_enabled')->default(true);
                $t->boolean('approvals_enabled')->default(true);$t->boolean('costing_enabled')->default(true);$t->string('default_verification_method',32)->default('geofence');
                $t->json('verification_methods')->nullable();$t->boolean('store_raw_location')->default(false);$t->unsignedInteger('offline_replay_window_minutes')->default(1440);$t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_policies');
        Schema::dropIfExists('ext_titan_time_submission_items');
        Schema::dropIfExists('ext_titan_time_submissions');
    }
};
