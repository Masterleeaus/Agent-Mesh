<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ext_titan_time_workflow_runs', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->string('workflow_id', 96);
            $table->string('source_event_id', 64)->nullable()->index();
            $table->string('dedup_key', 191);
            $table->string('dedup_hash', 64);
            $table->string('assigned_role', 96)->index();
            $table->string('status', 24)->default('queued')->index();
            $table->json('payload')->nullable();
            $table->string('trace_id', 64)->nullable()->index();
            $table->string('correlation_id', 64)->nullable()->index();
            $table->string('causation_id', 64)->nullable()->index();
            $table->timestamps();
            $table->unique(['company_id','workflow_id','dedup_hash'],'ext_titan_time_workflow_unique');
            $table->index(['company_id','status','assigned_role'],'ext_titan_time_workflow_queue');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_workflow_runs');
    }
};
