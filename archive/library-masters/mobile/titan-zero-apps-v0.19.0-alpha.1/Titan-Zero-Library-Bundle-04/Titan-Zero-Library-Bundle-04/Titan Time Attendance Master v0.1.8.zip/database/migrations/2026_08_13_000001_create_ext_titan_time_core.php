<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_entries')) {
            Schema::create('ext_titan_time_entries', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->unsignedBigInteger('work_order_id')->nullable()->index();
                $t->unsignedBigInteger('project_id')->nullable()->index();
                $t->unsignedBigInteger('task_id')->nullable()->index();
                $t->date('work_date')->index();
                $t->unsignedInteger('minutes')->default(0);
                $t->string('type',40)->default('regular');
                $t->text('notes')->nullable();
                $t->decimal('rate_per_hour',12,2)->nullable();
                $t->decimal('overtime_multiplier',6,3)->default(1);
                $t->decimal('cost_total',14,2)->nullable();
                $t->string('source',40)->default('manual');
                $t->uuid('trace_id')->nullable()->index();
                $t->uuid('correlation_id')->nullable()->index();
                $t->uuid('causation_id')->nullable()->index();
                $t->timestamps();
                $t->index(['company_id','user_id','work_date'],'ext_titan_time_entries_tenant_user_date');
            });
        }
        if (! Schema::hasTable('ext_titan_time_timers')) {
            Schema::create('ext_titan_time_timers', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->unsignedBigInteger('work_order_id')->nullable()->index();
                $t->timestamp('started_at');
                $t->timestamp('stopped_at')->nullable();
                $t->unsignedInteger('elapsed_minutes')->nullable();
                $t->string('status',20)->default('running')->index();
                $t->string('source',40)->default('timer');
                $t->uuid('trace_id')->nullable()->index();
                $t->timestamps();
                $t->index(['company_id','user_id','status'],'ext_titan_time_timers_active');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_timers');
        Schema::dropIfExists('ext_titan_time_entries');
    }
};
