<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_offline_events')) {
            Schema::create('ext_titan_time_offline_events', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('user_id')->index();$t->uuid('source_event_id');$t->string('event_type',64)->index();
                $t->timestamp('device_recorded_at');$t->timestamp('received_at')->nullable();$t->json('payload');$t->string('payload_hash',64);$t->string('sync_status',24)->default('received')->index();
                $t->text('failure_reason')->nullable();$t->timestamps();$t->unique(['company_id','source_event_id'],'ext_titan_time_offline_idempotency');
            });
        }
        if (! Schema::hasTable('ext_titan_time_signal_outbox')) {
            Schema::create('ext_titan_time_signal_outbox', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->uuid('event_id')->unique();$t->string('event_type',96)->index();$t->json('payload');
                $t->uuid('trace_id')->nullable()->index();$t->uuid('correlation_id')->nullable()->index();$t->uuid('causation_id')->nullable()->index();$t->string('status',20)->default('pending')->index();
                $t->unsignedSmallInteger('attempts')->default(0);$t->timestamp('available_at')->nullable()->index();$t->timestamp('delivered_at')->nullable();$t->text('last_error')->nullable();$t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_signal_outbox');
        Schema::dropIfExists('ext_titan_time_offline_events');
    }
};
