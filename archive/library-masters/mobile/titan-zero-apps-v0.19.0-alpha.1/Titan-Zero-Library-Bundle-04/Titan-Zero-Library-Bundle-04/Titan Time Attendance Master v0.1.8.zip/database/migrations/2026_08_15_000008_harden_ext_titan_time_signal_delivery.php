<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_signal_outbox')) return;

        Schema::table('ext_titan_time_signal_outbox', function (Blueprint $table): void {
            if (! Schema::hasColumn('ext_titan_time_signal_outbox', 'claim_token')) {
                $table->uuid('claim_token')->nullable()->after('status');
            }
            if (! Schema::hasColumn('ext_titan_time_signal_outbox', 'claimed_at')) {
                $table->timestamp('claimed_at')->nullable()->after('claim_token');
            }
            if (! Schema::hasColumn('ext_titan_time_signal_outbox', 'lease_expires_at')) {
                $table->timestamp('lease_expires_at')->nullable()->after('claimed_at');
                $table->index('lease_expires_at', 'ext_titan_time_signal_lease_expiry');
            }
            if (! Schema::hasColumn('ext_titan_time_signal_outbox', 'dead_lettered_at')) {
                $table->timestamp('dead_lettered_at')->nullable()->after('delivered_at');
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('ext_titan_time_signal_outbox')) return;

        Schema::table('ext_titan_time_signal_outbox', function (Blueprint $table): void {
            if (Schema::hasColumn('ext_titan_time_signal_outbox', 'lease_expires_at')) {
                $table->dropIndex('ext_titan_time_signal_lease_expiry');
                $table->dropColumn('lease_expires_at');
            }
            foreach (['dead_lettered_at', 'claimed_at', 'claim_token'] as $column) {
                if (Schema::hasColumn('ext_titan_time_signal_outbox', $column)) $table->dropColumn($column);
            }
        });
    }
};
