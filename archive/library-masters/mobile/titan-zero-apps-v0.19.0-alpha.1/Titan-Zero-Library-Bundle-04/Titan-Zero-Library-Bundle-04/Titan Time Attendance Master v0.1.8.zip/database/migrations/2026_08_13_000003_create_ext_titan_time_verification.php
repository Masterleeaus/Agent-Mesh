<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_time_geofences')) {
            Schema::create('ext_titan_time_geofences', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->string('name');$t->unsignedBigInteger('site_id')->nullable()->index();
                $t->decimal('latitude',10,7);$t->decimal('longitude',10,7);$t->unsignedInteger('radius_metres')->default(100);$t->boolean('active')->default(true)->index();$t->timestamps();
                $t->index(['company_id','site_id'],'ext_titan_time_geofence_site');
            });
        }
        if (! Schema::hasTable('ext_titan_time_qr_credentials')) {
            Schema::create('ext_titan_time_qr_credentials', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('site_id')->nullable()->index();$t->string('mode',20)->default('dynamic');
                $t->string('token_hash',64)->index();$t->timestamp('valid_from')->nullable();$t->timestamp('valid_until')->nullable()->index();$t->boolean('active')->default(true)->index();$t->timestamps();
            });
        }
        if (! Schema::hasTable('ext_titan_time_ip_rules')) {
            Schema::create('ext_titan_time_ip_rules', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('site_id')->nullable()->index();$t->string('label')->nullable();$t->string('ip_address',45);
                $t->boolean('active')->default(true)->index();$t->timestamps();$t->unique(['company_id','site_id','ip_address'],'ext_titan_time_ip_rule_unique');
            });
        }
        if (! Schema::hasTable('ext_titan_time_verification_logs')) {
            Schema::create('ext_titan_time_verification_logs', function (Blueprint $t): void {
                $t->id();$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('user_id')->index();$t->unsignedBigInteger('site_id')->nullable()->index();
                $t->string('method',32)->index();$t->boolean('verified')->index();$t->string('reason_code',64)->nullable();$t->json('evidence_summary')->nullable();
                $t->string('evidence_hash',64)->nullable()->index();$t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->uuid('trace_id')->nullable()->index();$t->uuid('correlation_id')->nullable()->index();$t->uuid('causation_id')->nullable()->index();$t->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_time_verification_logs');
        Schema::dropIfExists('ext_titan_time_ip_rules');
        Schema::dropIfExists('ext_titan_time_qr_credentials');
        Schema::dropIfExists('ext_titan_time_geofences');
    }
};
