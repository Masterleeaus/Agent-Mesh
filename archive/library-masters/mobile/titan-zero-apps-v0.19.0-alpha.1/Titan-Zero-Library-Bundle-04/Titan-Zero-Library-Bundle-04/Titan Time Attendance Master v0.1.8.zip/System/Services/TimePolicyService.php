<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Services;
use App\Extensions\TitanTimeAttendance\System\Models\TimePolicy;
use Illuminate\Validation\ValidationException;
final class TimePolicyService
{
    public function __construct(private readonly SignalOutboxService $signals){}
    public function update(int $companyId,int $actorUserId,array $input,array $trace=[]): TimePolicy
    {
        $method=(string)($input['default_verification_method']??'geofence');
        $allowed=['geofence','dynamic_qr','static_qr','ip_address'];if(!in_array($method,$allowed,true))throw ValidationException::withMessages(['default_verification_method'=>'Unsupported verification method.']);
        $methods=array_values(array_unique(array_filter((array)($input['verification_methods']??[$method]),fn($v)=>in_array($v,$allowed,true))));if($methods===[])$methods=[$method];
        $values=[
            'week_starts_on'=>max(0,min(6,(int)($input['week_starts_on']??1))),
            'timer_enabled'=>(bool)($input['timer_enabled']??true),'approvals_enabled'=>(bool)($input['approvals_enabled']??true),'costing_enabled'=>(bool)($input['costing_enabled']??true),
            'default_verification_method'=>$method,'verification_methods'=>$methods,'store_raw_location'=>(bool)($input['store_raw_location']??false),
            'offline_replay_window_minutes'=>max(60,min(10080,(int)($input['offline_replay_window_minutes']??1440))),
            'max_timer_minutes'=>max(30,min(2880,(int)($input['max_timer_minutes']??720))),
            'max_time_entry_minutes'=>max(30,min(1440,(int)($input['max_time_entry_minutes']??720))),
            'stale_submission_days'=>max(0,min(14,(int)($input['stale_submission_days']??2))),
            'offline_stuck_minutes'=>max(15,min(1440,(int)($input['offline_stuck_minutes']??60))),
        ];
        $policy=TimePolicy::query()->updateOrCreate(['company_id'=>$companyId],$values);
        $this->signals->record($companyId,'time.policy.updated',['policy_id'=>$policy->getKey(),'actor_user_id'=>$actorUserId,'verification_methods'=>$methods],$trace+['dedup_key'=>isset($trace['dedup_key'])?$trace['dedup_key'].':policy':null]);
        return $policy;
    }
}
