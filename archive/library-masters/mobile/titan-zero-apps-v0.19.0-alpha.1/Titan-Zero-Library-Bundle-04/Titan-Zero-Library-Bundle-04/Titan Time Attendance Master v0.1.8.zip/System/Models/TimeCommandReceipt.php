<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

final class TimeCommandReceipt extends Model
{
    protected $table = 'ext_titan_time_command_receipts';
    protected $fillable = [
        'company_id','command_id','capability','idempotency_key','request_hash','actor_user_id','actor_type','source',
        'risk_class','human_approval_required','status','result','trace_id','correlation_id','causation_id','executed_at',
    ];
    protected $casts = ['result'=>'array','human_approval_required'=>'boolean','executed_at'=>'datetime'];
    public function scopeForCompany(Builder $query,int $companyId): Builder { return $query->where('company_id',$companyId); }
}
