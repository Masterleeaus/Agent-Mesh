<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Http\Controllers;

use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;
use App\Extensions\TitanTimeAttendance\System\Models\OfflineAttendanceEvent;
use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use App\Extensions\TitanTimeAttendance\System\Support\CompanyContext;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class OfflineAttendanceController extends Controller
{
    public function ingest(Request $request, TimeCommandBusGateway $gateway): JsonResponse
    {
        $data = $request->validate([
            'source_event_id'=>'required|uuid',
            'event_type'=>'required|string|max:64',
            'device_id'=>'required|string|max:128',
            'device_sequence'=>'required|integer|min:0',
            'device_recorded_at'=>'required|date',
            'payload'=>'nullable|array',
            'idempotency_key'=>'nullable|string|max:128',
            'trace_id'=>'nullable|uuid',
            'correlation_id'=>'nullable|uuid',
            'causation_id'=>'nullable|uuid',
        ]);

        $result = $gateway->request('attendance.offline.ingest', $data, $request->user());

        return response()->json(['data' => $result], ($result['executed'] ?? false) ? 201 : 202);
    }

    public function index(Request $request, TimeAttendancePermissionService $permissions): JsonResponse
    {
        $user = $request->user();
        $permissions->authorize($user, 'titan-time-attendance.view');
        $items = OfflineAttendanceEvent::query()
            ->forCompany(CompanyContext::id($user))
            ->where('user_id', (int) $user->getKey())
            ->latest('device_recorded_at')
            ->limit(100)
            ->get();

        return response()->json(['data' => $items]);
    }
}
