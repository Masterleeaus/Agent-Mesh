<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Console\Commands;

use App\Extensions\TitanTimeAttendance\System\Navigation\TimeAttendanceMenuRegistrar;
use Illuminate\Console\Command;

final class SyncTimeAttendanceMenuCommand extends Command
{
    protected $signature = 'titan-time-attendance:host-sync';
    protected $description = 'Synchronise Titan Time & Attendance navigation with the Titan/MagicAI host and refresh menu caches.';

    public function handle(TimeAttendanceMenuRegistrar $registrar): int
    {
        $registrar->registerContributions();
        $result = $registrar->syncHostMenu(true);

        if (! ($result['available'] ?? false)) {
            $this->warn('Titan/MagicAI menu table is not available; contribution-registry registration was still attempted.');
            return self::SUCCESS;
        }

        $this->info(($result['changed'] ?? false) ? 'Time & Attendance menu synchronised.' : 'Time & Attendance menu already current.');
        $this->line(($result['regenerated'] ?? false) ? 'MagicAI menu cache regenerated.' : 'MagicAI MenuService regeneration was not available or was unnecessary.');
        return self::SUCCESS;
    }
}
