<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use InvalidArgumentException;

/** Extension-local allowlist. Titan Shield may perform additional external inspection through Command Bus. */
final class TimeInputShield
{
    private const ALLOWED = [
        'time.entry.create'=>['user_id','work_order_id','work_order_public_id','project_id','task_id','work_date','minutes','start_time','end_time','type','notes','rate_per_hour','overtime_multiplier','idempotency_key','trace_id','correlation_id','causation_id'],
        'time.timer.start'=>['work_order_id','work_order_public_id','idempotency_key','trace_id','correlation_id','causation_id'],
        'time.timer.stop'=>['timer_id','notes','type','rate_per_hour','overtime_multiplier','idempotency_key','trace_id','correlation_id','causation_id'],
        'time.submission.submit'=>['week_start','week_end','idempotency_key','trace_id','correlation_id','causation_id'],
        'time.submission.review'=>['submission_id','decision','notes','idempotency_key','trace_id','correlation_id','causation_id'],
        'attendance.verify'=>['method','site_id','service_location_public_id','geofence_id','credential_id','latitude','longitude','token','ip_address','idempotency_key','trace_id','correlation_id','causation_id'],
        'attendance.offline.ingest'=>['source_event_id','event_type','device_id','device_sequence','device_recorded_at','payload','idempotency_key','trace_id','correlation_id','causation_id'],
        'time.policy.update'=>['week_starts_on','timer_enabled','approvals_enabled','costing_enabled','default_verification_method','verification_methods','store_raw_location','offline_replay_window_minutes','max_timer_minutes','max_time_entry_minutes','stale_submission_days','offline_stuck_minutes','idempotency_key','trace_id','correlation_id','causation_id'],
    ];

    public function clean(string $capability, array $input): array
    {
        unset($input['company_id'],$input['company_id'],$input['tenant_id'],$input['actor_user_id'],$input['actor_type'],$input['source']);
        $allowed = self::ALLOWED[$capability] ?? null;
        if ($allowed === null) throw new InvalidArgumentException("No governed input contract for {$capability}.");
        $unknown = array_diff(array_keys($input), $allowed);
        if ($unknown !== []) throw new InvalidArgumentException('Unsupported governed input fields: '.implode(', ', $unknown));
        return $input;
    }
}
