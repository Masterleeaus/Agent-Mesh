<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Intelligence;
final readonly class AttentionFinding
{
    public function __construct(public string $findingKey,public string $findingType,public string $sourceRef,public ?int $userId,public string $assignedRole,public string $severity,public ?string $recommendedCapability,public array $evidence){}
    public function toArray(): array{return ['finding_key'=>$this->findingKey,'finding_type'=>$this->findingType,'source_ref'=>$this->sourceRef,'user_id'=>$this->userId,'assigned_role'=>$this->assignedRole,'severity'=>$this->severity,'recommended_capability'=>$this->recommendedCapability,'evidence'=>$this->evidence];}
}
