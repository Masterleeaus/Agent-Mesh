<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Services;

use App\Extensions\TitanTimeAttendance\System\Models\TimeSignalOutbox;
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;

final class SignalOutboxService
{
    public function record(int $companyId, string $eventType, array $payload, array $trace = []): TimeSignalOutbox
    {
        $dedup = trim((string) ($trace['dedup_key'] ?? ''));
        $attributes = [
            'company_id' => $companyId,
            'dedup_key' => $dedup !== '' ? $dedup : null,
        ];

        if ($dedup !== '') {
            $existing = TimeSignalOutbox::query()->forCompany($companyId)->where('dedup_key', $dedup)->first();
            if ($existing) {
                return $existing;
            }
        }

        $values = [
            'event_id' => (string) Str::uuid(),
            'event_type' => $eventType,
            'payload' => $payload,
            'trace_id' => $trace['trace_id'] ?? null,
            'correlation_id' => $trace['correlation_id'] ?? null,
            'causation_id' => $trace['causation_id'] ?? null,
            'status' => 'pending',
            'attempts' => 0,
            'available_at' => now(),
        ];

        if ($dedup === '') {
            return TimeSignalOutbox::query()->create($attributes + $values);
        }

        try {
            return TimeSignalOutbox::query()->create($attributes + $values);
        } catch (QueryException) {
            return TimeSignalOutbox::query()
                ->forCompany($companyId)
                ->where('dedup_key', $dedup)
                ->firstOrFail();
        }
    }
}
