<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Governance;
use Illuminate\Support\Facades\Event;
final class LaravelEventSignalDeliveryPort implements TimeSignalDeliveryPort
{
 public function available(): bool { return true; }
 public function deliver(array $envelope): void { Event::dispatch('titan.signal',[$envelope]); }
}
