<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Workforce;

use InvalidArgumentException;

final readonly class TimeWorkforceExecutionContext
{
    /** @param list<string> $allowedCapabilities */
    public function __construct(
        public int $companyId,
        public int $actorUserId,
        public object $actorPrincipal,
        public string $roleKey,
        public string $riskCeiling,
        public string $autonomyLevel,
        public array $allowedCapabilities,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $idempotencyKey,
        public string $executionMode = 'prepare',
    ) {
        if ($companyId <= 0 || $actorUserId <= 0) throw new InvalidArgumentException('Trusted tenant and actor context are required.');
        $principalId=(int)(method_exists($actorPrincipal,'getKey')?$actorPrincipal->getKey():($actorPrincipal->id??0));
        if ($principalId !== $actorUserId) throw new InvalidArgumentException('Trusted actor principal does not match actor_user_id.');
        if (! in_array($executionMode,['prepare','execute'],true)) throw new InvalidArgumentException('executionMode must be prepare or execute.');
    }

    public function allowsCapability(string $capability): bool
    {
        return in_array($capability,$this->allowedCapabilities,true);
    }
}
