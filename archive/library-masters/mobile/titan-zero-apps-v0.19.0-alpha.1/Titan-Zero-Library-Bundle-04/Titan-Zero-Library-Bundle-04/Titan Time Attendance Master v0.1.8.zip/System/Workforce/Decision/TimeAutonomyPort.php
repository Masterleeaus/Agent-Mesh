<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Decision;
interface TimeAutonomyPort
{
    public function allows(string $autonomyLevel,string $riskClass,string $capability): bool;
}
