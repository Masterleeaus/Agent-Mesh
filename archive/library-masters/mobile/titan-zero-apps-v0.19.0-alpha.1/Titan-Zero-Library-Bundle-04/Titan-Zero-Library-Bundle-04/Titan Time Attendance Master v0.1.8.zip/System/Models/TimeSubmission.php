<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

final class TimeSubmission extends Model
{
    protected $table = 'ext_titan_time_submissions';
    protected $fillable = ['company_id','user_id','week_start','week_end','status','reviewed_by_user_id','submitted_at','reviewed_at','review_notes','trace_id'];
    protected $casts = ['week_start'=>'date','week_end'=>'date','submitted_at'=>'datetime','reviewed_at'=>'datetime'];
    public function scopeForCompany(Builder $query,int $companyId): Builder { return $query->where('company_id',$companyId); }
}
