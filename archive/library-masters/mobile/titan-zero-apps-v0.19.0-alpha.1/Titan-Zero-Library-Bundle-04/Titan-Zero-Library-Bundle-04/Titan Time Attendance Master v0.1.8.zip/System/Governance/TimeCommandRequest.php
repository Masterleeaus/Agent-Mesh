<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use Illuminate\Support\Str;

final readonly class TimeCommandRequest
{
    public function __construct(
        public string $commandId,
        public string $capability,
        public array $input,
        public int $companyId,
        public int $actorUserId,
        public string $actorType,
        public string $source,
        public string $requiredPermission,
        public string $riskClass,
        public bool $humanApprovalRequired,
        public string $traceId,
        public string $correlationId,
        public ?string $causationId,
        public string $idempotencyKey,
    ) {}

    public static function make(
        string $capability,
        array $input,
        int $companyId,
        int $actorUserId,
        string $source,
        string $actorType = 'human',
        array $governance = [],
    ): self {
        $idempotencyKey = trim((string) ($input['idempotency_key'] ?? $input['_context']['idempotency_key'] ?? ''));
        if ($idempotencyKey === '') {
            $idempotencyKey = (string) Str::uuid();
        }
        $traceId = trim((string) ($input['trace_id'] ?? $input['_context']['trace_id'] ?? '')) ?: (string) Str::uuid();
        $correlationId = trim((string) ($input['correlation_id'] ?? $input['_context']['correlation_id'] ?? '')) ?: $traceId;
        $causationId = trim((string) ($input['causation_id'] ?? $input['_context']['causation_id'] ?? '')) ?: null;

        return new self(
            commandId: (string) Str::uuid(),
            capability: $capability,
            input: $input + ['idempotency_key' => $idempotencyKey],
            companyId: $companyId,
            actorUserId: $actorUserId,
            actorType: $actorType,
            source: $source,
            requiredPermission: (string) ($governance['permission'] ?? ''),
            riskClass: (string) ($governance['risk'] ?? 'MEDIUM'),
            humanApprovalRequired: (bool) ($governance['human_approval'] ?? false),
            traceId: $traceId,
            correlationId: $correlationId,
            causationId: $causationId,
            idempotencyKey: $idempotencyKey,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'command_id' => $this->commandId,
            'capability' => $this->capability,
            'input' => $this->input,
            'company_id' => $this->companyId,
            'actor_user_id' => $this->actorUserId,
            'actor_type' => $this->actorType,
            'source' => $this->source,
            'required_permission' => $this->requiredPermission,
            'risk_class' => $this->riskClass,
            'human_approval_required' => $this->humanApprovalRequired,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'idempotency_key' => $this->idempotencyKey,
        ];
    }
}
