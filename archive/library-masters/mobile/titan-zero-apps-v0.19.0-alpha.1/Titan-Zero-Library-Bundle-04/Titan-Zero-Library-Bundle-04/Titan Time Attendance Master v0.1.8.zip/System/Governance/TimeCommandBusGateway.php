<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use App\Extensions\TitanTimeAttendance\System\Services\SignalOutboxService;
use App\Extensions\TitanTimeAttendance\System\Support\{CapabilityCatalog,CompanyContext};
use Illuminate\Support\Facades\DB;

final class TimeCommandBusGateway
{
    public function __construct(
        private readonly TimeCommandBusPort $port,
        private readonly TimeCapabilityExecutor $executor,
        private readonly TimeCommandReceiptService $receipts,
        private readonly TimeAttendancePermissionService $permissions,
        private readonly TimeInputShield $shield,
        private readonly SignalOutboxService $signals,
    ) {}

    /** @return array<string,mixed> */
    public function request(string $capability,array $input,object $user,string $source='time_web',string $actorType='human'): array
    {
        $definition=CapabilityCatalog::definition($capability);
        if(($definition['mode']??'read')!=='write')throw new \InvalidArgumentException('TimeCommandBusGateway accepts governed writes only.');
        $clean=$this->shield->clean($capability,$input);
        $this->permissions->authorize($user,(string)$definition['permission'],$clean);
        $actorId=(int)(method_exists($user,'getKey')?$user->getKey():($user->id??0));
        $request=TimeCommandRequest::make($capability,$clean,CompanyContext::id($user),$actorId,$source,$actorType,$definition);
        if(($replay=$this->receipts->replay($request))!==null && ($replay['status']??'')!=='processing')return $replay;

        if($this->port->available())return $this->port->dispatch($request);

        $humanSources=(array)config('titan-time-attendance.governance.local_human_sources',['time_web']);
        if(!(bool)config('titan-time-attendance.governance.allow_local_human_mutations',true)||!in_array($source,$humanSources,true))return $this->port->dispatch($request);

        return DB::transaction(function()use($request,$definition):array{
            $receipt=$this->receipts->reserve($request,$definition);
            if($receipt->status==='executed')return $this->receipts->envelope($receipt,true);
            if($receipt->status!=='processing')return $this->receipts->envelope($receipt,true);

            $result=$this->executor->execute($request);
            $serialised=$this->serialiseResult($result);
            $receipt=$this->receipts->complete($receipt,'executed',$serialised);
            $this->signals->record($request->companyId,'time.command.executed',[
                'receipt_id'=>$receipt->getKey(),'command_id'=>$request->commandId,'capability'=>$request->capability,'actor_user_id'=>$request->actorUserId,
                'source'=>$request->source,'risk'=>$definition['risk']??'MEDIUM','human_approval_required'=>(bool)($definition['human_approval']??false),
            ],['trace_id'=>$request->traceId,'correlation_id'=>$request->correlationId,'causation_id'=>$request->causationId,'dedup_key'=>'command:'.$request->commandId]);
            $envelope=$this->receipts->envelope($receipt,false);$envelope['result']=$result;return $envelope;
        });
    }

    private function serialiseResult(array $result): array
    {
        $out=[];foreach($result as $key=>$value){$out[$key]=(is_object($value)&&method_exists($value,'toArray'))?$value->toArray():$value;}return $out;
    }
}
