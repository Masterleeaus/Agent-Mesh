<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Workforce;

use RuntimeException;

/** Canonical provider-owned execution surfaces bound to Workforce-owned intrinsic roles. */
final class TimeAttendanceWorkforceCapabilityBinding
{
    private ?array $cache = null;

    public function all(): array
    {
        if ($this->cache !== null) return $this->cache;
        $path = dirname(__DIR__, 2) . '/resources/workforce/capability-bindings.json';
        $json = @file_get_contents($path);
        if ($json === false) throw new RuntimeException('Titan Time & Attendance Workforce capability bindings are unavailable.');
        $binding = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (($binding['schema_version'] ?? null) !== '1.0' || ($binding['ownership']['role_definitions_owned_by_provider'] ?? null) !== false) {
            throw new RuntimeException('Titan Time & Attendance Workforce capability binding contract is invalid.');
        }
        return $this->cache = $binding;
    }
}
