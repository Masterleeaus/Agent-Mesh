<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Governance;
interface TimeSignalDeliveryPort { public function available(): bool; public function deliver(array $envelope): void; }
