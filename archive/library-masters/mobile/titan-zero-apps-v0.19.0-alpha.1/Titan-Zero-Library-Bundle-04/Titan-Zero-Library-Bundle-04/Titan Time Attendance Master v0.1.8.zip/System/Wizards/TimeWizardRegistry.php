<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Wizards;

use InvalidArgumentException;
use RuntimeException;

final class TimeWizardRegistry
{
    private ?array $cache = null;

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->cache !== null) return $this->cache;
        $path = dirname(__DIR__, 2) . '/resources/workforce/wizards.json';
        $json = @file_get_contents($path);
        if ($json === false) throw new RuntimeException('Time & Attendance wizards are unavailable.');
        return $this->cache = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
    }

    /** @return array<string,mixed> */
    public function definition(string $wizardId): array
    {
        foreach ($this->all()['wizards'] ?? [] as $wizard) {
            if (($wizard['wizard_id'] ?? null) === $wizardId) return $wizard;
        }
        throw new InvalidArgumentException("Unknown Titan Time & Attendance wizard: {$wizardId}");
    }

    /**
     * Compile a deterministic proposal only. The returned capability must still execute through
     * the normal trusted Workforce/Command Bus path; this registry never mutates policy itself.
     *
     * @return array{wizard_id:string,mode:string,capability:string,human_approval_required:bool,input:array<string,mixed>}
     */
    public function compileProposal(string $wizardId, array $input): array
    {
        $wizard = $this->definition($wizardId);
        if (($wizard['status'] ?? '') !== 'active' || ($wizard['mode'] ?? '') !== 'proposal') {
            throw new InvalidArgumentException('Wizard is not available for proposal compilation.');
        }

        $allowedFields = [];
        foreach ($wizard['stages'] ?? [] as $stage) {
            foreach ($stage['fields'] ?? [] as $field) $allowedFields[(string) $field] = true;
        }
        $unknown = array_diff(array_keys($input), array_keys($allowedFields));
        if ($unknown !== []) throw new InvalidArgumentException('Unsupported wizard fields: ' . implode(', ', $unknown));

        $required = array_values((array) ($wizard['required_fields'] ?? []));
        foreach ($required as $field) {
            if (! array_key_exists($field, $input)) throw new InvalidArgumentException("Wizard field is required: {$field}");
        }

        $clean = $this->normalisePolicyInput($input);
        return [
            'wizard_id' => (string) $wizard['wizard_id'],
            'mode' => 'prepare',
            'capability' => (string) $wizard['final_capability'],
            'human_approval_required' => (bool) ($wizard['human_approval_required'] ?? true),
            'input' => $clean,
        ];
    }

    /** @return array<string,mixed> */
    private function normalisePolicyInput(array $input): array
    {
        $allowedMethods = ['geofence', 'dynamic_qr', 'static_qr', 'ip_address'];
        if (array_key_exists('default_verification_method', $input)) {
            $method = (string) $input['default_verification_method'];
            if (! in_array($method, $allowedMethods, true)) throw new InvalidArgumentException('Unsupported verification method.');
            $input['default_verification_method'] = $method;
        }
        if (array_key_exists('verification_methods', $input)) {
            $methods = array_values(array_unique(array_map('strval', (array) $input['verification_methods'])));
            if ($methods === [] || array_diff($methods, $allowedMethods) !== []) throw new InvalidArgumentException('Unsupported verification method list.');
            $input['verification_methods'] = $methods;
        }

        foreach (['timer_enabled','approvals_enabled','costing_enabled','store_raw_location'] as $field) {
            if (array_key_exists($field, $input)) $input[$field] = (bool) $input[$field];
        }
        $ranges = [
            'week_starts_on' => [0, 6],
            'offline_replay_window_minutes' => [60, 10080],
            'max_timer_minutes' => [30, 2880],
            'max_time_entry_minutes' => [30, 1440],
            'stale_submission_days' => [0, 14],
            'offline_stuck_minutes' => [15, 1440],
        ];
        foreach ($ranges as $field => [$min, $max]) {
            if (! array_key_exists($field, $input)) continue;
            $value = filter_var($input[$field], FILTER_VALIDATE_INT);
            if ($value === false || $value < $min || $value > $max) throw new InvalidArgumentException("Wizard field outside allowed range: {$field}");
            $input[$field] = $value;
        }
        return $input;
    }
}
