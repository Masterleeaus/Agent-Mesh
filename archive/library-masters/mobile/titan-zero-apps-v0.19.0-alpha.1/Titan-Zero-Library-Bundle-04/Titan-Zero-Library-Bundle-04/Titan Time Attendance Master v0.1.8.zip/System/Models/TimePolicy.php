<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

final class TimePolicy extends Model
{
    protected $table = 'ext_titan_time_policies';
    protected $fillable = ['company_id','week_starts_on','timer_enabled','approvals_enabled','costing_enabled','default_verification_method','verification_methods','store_raw_location','offline_replay_window_minutes','max_timer_minutes','max_time_entry_minutes','stale_submission_days','offline_stuck_minutes'];
    protected $casts = ['week_starts_on'=>'integer','timer_enabled'=>'boolean','approvals_enabled'=>'boolean','costing_enabled'=>'boolean','verification_methods'=>'array','store_raw_location'=>'boolean','offline_replay_window_minutes'=>'integer','max_timer_minutes'=>'integer','max_time_entry_minutes'=>'integer','stale_submission_days'=>'integer','offline_stuck_minutes'=>'integer'];
    public function scopeForCompany(Builder $query,int $companyId): Builder { return $query->where('company_id',$companyId); }
}
