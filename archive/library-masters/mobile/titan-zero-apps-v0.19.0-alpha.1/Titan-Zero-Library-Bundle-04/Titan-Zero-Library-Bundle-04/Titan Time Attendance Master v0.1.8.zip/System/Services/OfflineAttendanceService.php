<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Services;

use App\Extensions\TitanTimeAttendance\System\Models\{OfflineAttendanceEvent, TimePolicy};
use Illuminate\Database\QueryException;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;

final class OfflineAttendanceService
{
    private const EVENT_TYPES = ['attendance_check_in', 'attendance_check_out', 'timer_start', 'timer_stop', 'presence_evidence'];
    private const VERIFICATION_EVENTS = ['attendance_check_in', 'attendance_check_out', 'presence_evidence'];

    public function __construct(
        private readonly SignalOutboxService $signals,
        private readonly AttendanceVerificationService $attendance,
    ) {}

    public function ingest(int $companyId, int $userId, array $input): array
    {
        $eventType = (string) ($input['event_type'] ?? '');
        if (! in_array($eventType, self::EVENT_TYPES, true)) {
            throw ValidationException::withMessages(['event_type' => 'Unsupported offline attendance event type.']);
        }

        $sourceEventId = trim((string) ($input['source_event_id'] ?? ''));
        if ($sourceEventId === '') {
            throw ValidationException::withMessages(['source_event_id' => 'source_event_id is required.']);
        }
        if (! Str::isUuid($sourceEventId)) {
            throw ValidationException::withMessages(['source_event_id' => 'source_event_id must be a UUID.']);
        }
        $deviceId = trim((string) ($input['device_id'] ?? ''));
        if ($deviceId === '') {
            throw ValidationException::withMessages(['device_id' => 'device_id is required for offline attendance events.']);
        }
        if (mb_strlen($deviceId) > 128) {
            throw ValidationException::withMessages(['device_id' => 'device_id may not exceed 128 characters.']);
        }
        if (! array_key_exists('device_sequence', $input)) {
            throw ValidationException::withMessages(['device_sequence' => 'device_sequence is required for offline attendance events.']);
        }
        $deviceRecordedAt = trim((string) ($input['device_recorded_at'] ?? ''));
        if ($deviceRecordedAt === '') {
            throw ValidationException::withMessages(['device_recorded_at' => 'device_recorded_at is required.']);
        }

        $deviceSequence = filter_var($input['device_sequence'], FILTER_VALIDATE_INT);
        if ($deviceSequence === false || $deviceSequence < 0) {
            throw ValidationException::withMessages(['device_sequence' => 'device_sequence must be a non-negative integer.']);
        }

        $tenantHashKey = $this->tenantHashKey($companyId);
        $deviceKey = hash_hmac('sha256', $deviceId, $tenantHashKey);
        $policy = TimePolicy::query()->forCompany($companyId)->first();
        $storeRawLocation = (bool) ($policy?->store_raw_location ?? config('titan-time-attendance.verification.store_raw_location', false));
        $rawPayload = (array) ($input['payload'] ?? []);
        $payload = $this->minimisePayload($rawPayload, $storeRawLocation, $companyId);
        $payloadHash = hash('sha256', json_encode($payload, JSON_UNESCAPED_SLASHES));
        $initialStatus = in_array($eventType, self::VERIFICATION_EVENTS, true) ? 'pending_verification' : 'pending_application';

        $sequence = OfflineAttendanceEvent::query()
            ->forCompany($companyId)
            ->where('device_id', $deviceKey)
            ->where('device_sequence', $deviceSequence)
            ->first();
        if ($sequence && $sequence->source_event_id !== $sourceEventId) {
            throw ValidationException::withMessages(['device_sequence' => 'This device sequence has already been used by another offline event.']);
        }

        try {
            $event = OfflineAttendanceEvent::query()->firstOrCreate(
                ['company_id' => $companyId, 'source_event_id' => $sourceEventId],
                [
                    'user_id' => $userId,
                    'event_type' => $eventType,
                    'device_id'=>$deviceKey,
                    'device_sequence' => $deviceSequence,
                    'device_recorded_at' => $deviceRecordedAt,
                    'received_at' => now(),
                    'payload' => $payload,
                    'payload_hash' => $payloadHash,
                    'sync_status' => 'synced',
                    'reconciliation_status' => $initialStatus,
                ],
            );
        } catch (QueryException) {
            $event = OfflineAttendanceEvent::query()
                ->forCompany($companyId)
                ->where('device_id', $deviceKey)
                ->where('device_sequence', $deviceSequence)
                ->firstOrFail();
        }

        if (! $event->wasRecentlyCreated) {
            if (
                (int) $event->user_id !== $userId
                || (string) $event->event_type !== $eventType
                || (string) $event->device_id !== $deviceKey
                || (int) $event->device_sequence !== $deviceSequence
                || ! hash_equals((string) $event->payload_hash, $payloadHash)
            ) {
                throw ValidationException::withMessages(['source_event_id' => 'Offline event id or device sequence was already used for different content.']);
            }

            return [
                'event' => $event,
                'replayed' => true,
                'reconciliation_status' => (string) $event->reconciliation_status,
                'verification_log_id' => $event->verification_log_id,
            ];
        }

        if (in_array($eventType, self::VERIFICATION_EVENTS, true)) {
            $this->reconcileVerification($event, $companyId, $userId, $rawPayload, $input);
        }

        $this->signals->record($companyId, 'attendance.offline.synced', [
            'offline_event_id' => $event->getKey(),
            'source_event_id' => $sourceEventId,
            'user_id' => $userId,
            'event_type' => $eventType,
            'device_id_hash' => $deviceKey,
            'device_sequence' => $deviceSequence,
            'reconciliation_status' => $event->reconciliation_status,
            'verification_log_id' => $event->verification_log_id,
        ], array_replace($input, [
            'dedup_key' => isset($input['dedup_key']) ? $input['dedup_key'] . ':offline-sync' : 'offline:' . $sourceEventId,
        ]));

        return [
            'event' => $event,
            'replayed' => false,
            'reconciliation_status' => (string) $event->reconciliation_status,
            'verification_log_id' => $event->verification_log_id,
        ];
    }

    private function reconcileVerification(OfflineAttendanceEvent $event, int $companyId, int $userId, array $rawPayload, array $trace): void
    {
        try {
            $method = (string) ($rawPayload['method'] ?? '');
            $verification = $this->attendance->verify($companyId, $userId, $method, array_replace($rawPayload, [
                'trace_id' => $trace['trace_id'] ?? null,
                'correlation_id' => $trace['correlation_id'] ?? null,
                'causation_id' => $trace['causation_id'] ?? null,
                'dedup_key' => isset($trace['dedup_key']) ? $trace['dedup_key'] . ':offline-verify' : 'offline-verify:' . $event->source_event_id,
            ]));
            $status = $verification->verified ? 'verified_evidence' : 'rejected';
            $event->forceFill([
                'verification_log_id' => $verification->getKey(),
                'reconciliation_status' => $status,
                'reconciled_at' => now(),
                'failure_reason' => $verification->verified ? null : (string) ($verification->reason_code ?? 'verification_failed'),
            ])->save();
            if (! $verification->verified) {
                $this->signals->record($companyId, 'attendance.offline.rejected', [
                    'offline_event_id' => $event->getKey(),
                    'verification_log_id' => $verification->getKey(),
                    'reason_code' => $verification->reason_code,
                ], ['dedup_key' => 'offline-rejected:' . $event->source_event_id]);
            }
        } catch (Throwable) {
            $event->forceFill([
                'reconciliation_status' => 'rejected',
                'reconciled_at' => now(),
                'failure_reason' => 'verification_exception',
            ])->save();
            $this->signals->record($companyId, 'attendance.offline.rejected', [
                'offline_event_id' => $event->getKey(),
                'verification_log_id' => null,
                'reason_code' => 'verification_exception',
            ], ['dedup_key' => 'offline-rejected:' . $event->source_event_id]);
        }
    }

    private function minimisePayload(array $payload, bool $storeRawLocation, int $companyId): array
    {
        $safe = [];
        foreach (['site_id', 'service_location_public_id', 'method', 'geofence_id', 'credential_id', 'accuracy_metres', 'battery_level', 'charging', 'mock_location', 'gps_enabled', 'network_state'] as $key) {
            if (array_key_exists($key, $payload)) $safe[$key] = $payload[$key];
        }

        $tenantHashKey = $this->tenantHashKey($companyId);
        $hasLocation = isset($payload['latitude'], $payload['longitude']);
        if ($hasLocation && $storeRawLocation) {
            $safe['latitude'] = $payload['latitude'];
            $safe['longitude'] = $payload['longitude'];
        } elseif ($hasLocation) {
            $safe['location_hash'] = hash_hmac('sha256', sprintf('%.7F,%.7F', (float) $payload['latitude'], (float) $payload['longitude']), $tenantHashKey);
        }
        if (isset($payload['token']) && is_string($payload['token']) && $payload['token'] !== '') {
            $safe['token_hash'] = hash_hmac('sha256', $payload['token'], $tenantHashKey);
        }
        if (isset($payload['ip_address']) && is_string($payload['ip_address']) && $payload['ip_address'] !== '') {
            $safe['ip_hash'] = hash_hmac('sha256', $payload['ip_address'], $tenantHashKey);
        }

        return $safe;
    }

    private function tenantHashKey(int $companyId): string
    {
        $appKey = trim((string) config('app.key', ''));
        if ($appKey === '') {
            throw new \RuntimeException('Titan Time & Attendance requires a configured APP_KEY for privacy hashing.');
        }

        return $appKey . '|tenant:' . $companyId;
    }
}
