<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeEntry extends Model
{
 protected $table='ext_titan_time_entries';
 protected $fillable=['company_id','user_id','created_by_user_id','work_order_id','work_order_public_id','project_id','task_id','work_date','start_time','end_time','minutes','type','notes','rate_per_hour','overtime_multiplier','cost_total','source','trace_id','correlation_id','causation_id'];
 protected $casts=['work_date'=>'date','minutes'=>'integer','rate_per_hour'=>'decimal:2','overtime_multiplier'=>'decimal:3','cost_total'=>'decimal:2'];
 public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
