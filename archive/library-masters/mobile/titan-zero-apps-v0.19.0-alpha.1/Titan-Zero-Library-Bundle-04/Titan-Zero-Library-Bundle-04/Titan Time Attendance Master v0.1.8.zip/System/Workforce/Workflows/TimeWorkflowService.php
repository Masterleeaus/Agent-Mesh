<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Workflows;
use App\Extensions\TitanTimeAttendance\System\Models\TimeWorkflowRun;
use InvalidArgumentException;
final class TimeWorkflowService
{
    public function __construct(private readonly TimeWorkflowRegistry $registry){}
    public function handleSignal(array $envelope): ?TimeWorkflowRun
    {
        $definition=$this->registry->forSignal((string)($envelope['event_type']??$envelope['event']??''));if($definition===null)return null;
        $tenant=(int)($envelope['company_id']??0);if($tenant<=0)throw new InvalidArgumentException('Signal workflow requires company_id.');
        $dedup_key=trim((string)($envelope['dedup_key']??$envelope['event_id']??''));if($dedup_key==='')$dedup_key=hash('sha256',json_encode($envelope,JSON_UNESCAPED_SLASHES));$dedupHash=hash('sha256',$dedup_key);$storedDedup=mb_substr($dedup_key,0,191);
        return TimeWorkflowRun::query()->firstOrCreate(['company_id'=>$tenant,'workflow_id'=>$definition['workflow_id'],'dedup_hash'=>$dedupHash],[
            'source_event_id'=>$envelope['event_id']??null,'dedup_key'=>$storedDedup,'assigned_role'=>$definition['assigned_role'],'status'=>'queued','payload'=>$envelope['payload']??[],
            'trace_id'=>$envelope['trace_id']??null,'correlation_id'=>$envelope['correlation_id']??null,'causation_id'=>$envelope['causation_id']??null,
        ]);
    }
}
