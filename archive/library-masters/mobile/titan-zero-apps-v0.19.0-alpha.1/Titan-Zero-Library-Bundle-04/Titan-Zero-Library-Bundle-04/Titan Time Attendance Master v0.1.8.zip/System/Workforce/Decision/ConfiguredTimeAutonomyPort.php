<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Decision;
final class ConfiguredTimeAutonomyPort implements TimeAutonomyPort
{
    private const LEVELS=['Suggest'=>0,'Assist'=>1,'Semi-Auto'=>2,'Auto'=>3,'Trusted Auto'=>4];
    private const RISK_REQUIRED=['LOW'=>2,'MEDIUM'=>3,'HIGH'=>4,'CRITICAL'=>99];
    public function allows(string $autonomyLevel,string $riskClass,string $capability): bool
    {
        $level=self::LEVELS[$autonomyLevel]??0;$required=self::RISK_REQUIRED[strtoupper($riskClass)]??99;
        return $level >= $required;
    }
}
