<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

final class OfflineAttendanceEvent extends Model
{
    protected $table = 'ext_titan_time_offline_events';
    protected $fillable = ['company_id','user_id','source_event_id','event_type','device_id','device_sequence','verification_log_id','device_recorded_at','received_at','payload','payload_hash','sync_status','reconciliation_status','reconciled_at','failure_reason'];
    protected $casts = ['device_recorded_at'=>'datetime','received_at'=>'datetime','payload'=>'array','device_sequence'=>'integer','verification_log_id'=>'integer','reconciled_at'=>'datetime'];
    public function scopeForCompany(Builder $query,int $companyId): Builder { return $query->where('company_id',$companyId); }
}
