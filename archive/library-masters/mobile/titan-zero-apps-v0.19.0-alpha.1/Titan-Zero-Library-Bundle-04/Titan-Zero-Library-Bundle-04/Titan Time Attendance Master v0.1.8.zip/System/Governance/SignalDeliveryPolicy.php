<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use Throwable;

final class SignalDeliveryPolicy
{
    private int $maxAttempts;
    private int $leaseSeconds;

    public function __construct(?int $maxAttempts = null, ?int $leaseSeconds = null)
    {
        $configuredAttempts = $maxAttempts ?? (int) config('titan-time-attendance.signals.max_attempts', 8);
        $configuredLease = $leaseSeconds ?? (int) config('titan-time-attendance.signals.lease_seconds', 300);
        $this->maxAttempts = max(1, min(50, $configuredAttempts));
        $this->leaseSeconds = max(30, min(3600, $configuredLease));
    }

    public function retryDelaySeconds(int $attempt): int
    {
        return min(3600, 30 * (2 ** min(7, max(0, $attempt - 1))));
    }

    public function shouldDeadLetter(int $attempt): bool
    {
        return $attempt >= $this->maxAttempts;
    }

    public function leaseSeconds(): int
    {
        return $this->leaseSeconds;
    }

    public function maxAttempts(): int
    {
        return $this->maxAttempts;
    }

    public function safeError(Throwable $exception): string
    {
        return $exception::class;
    }
}
