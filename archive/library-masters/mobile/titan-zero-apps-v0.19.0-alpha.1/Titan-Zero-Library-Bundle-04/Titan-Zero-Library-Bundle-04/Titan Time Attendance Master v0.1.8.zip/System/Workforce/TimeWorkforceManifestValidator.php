<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Workforce;

use RuntimeException;

final class TimeWorkforceManifestValidator
{
    public static function assertValid(array $manifest): void
    {
        if (($manifest['schema'] ?? null) !== 'titan-workforce-capability-bindings' || ($manifest['schema_version'] ?? null) !== '3.0') {
            throw new RuntimeException('Titan Time & Attendance must publish Workforce capability bindings schema 3.0.');
        }
        if (($manifest['ownership']['roles'] ?? null) !== 'titan-ai-workforce' || ($manifest['ownership']['capabilities'] ?? null) !== 'titan-time-attendance') {
            throw new RuntimeException('Workforce role/capability ownership is invalid.');
        }
        if (! empty($manifest['roles']) || ! empty($manifest['role_definitions'])) {
            throw new RuntimeException('Titan Time & Attendance must not define Workforce employees.');
        }

        $capabilities = array_fill_keys($manifest['capabilities'] ?? [], true);
        $tools = [];
        foreach ($manifest['tools'] ?? [] as $tool) {
            $id = (string) ($tool['tool_id'] ?? '');
            $cap = (string) ($tool['capability'] ?? '');
            if ($id === '' || isset($tools[$id])) throw new RuntimeException('Invalid or duplicate Time & Attendance Workforce tool: ' . ($id ?: '?'));
            if (! isset($capabilities[$cap])) throw new RuntimeException("Workforce tool {$id} references inactive capability {$cap}.");
            if (($tool['tenant_context_required'] ?? false) !== true || ($tool['actor_context_required'] ?? false) !== true) throw new RuntimeException("Workforce tool {$id} must require trusted tenant and actor context.");
            $tools[$id] = $cap;
        }

        $bindings = [];
        foreach ($manifest['role_bindings'] ?? [] as $binding) {
            $id = (string) ($binding['role_definition_id'] ?? '');
            if ($id === '' || isset($bindings[$id])) throw new RuntimeException('Invalid or duplicate intrinsic role binding: ' . ($id ?: '?'));
            if (! str_starts_with($id, 'titan.')) throw new RuntimeException("Binding {$id} is not a canonical Workforce role ID.");
            if (($binding['authority_inherited'] ?? null) !== false) throw new RuntimeException("Binding {$id} must prohibit authority inheritance.");
            $bindings[$id] = $binding;
            $roleCaps = array_fill_keys($binding['capabilities'] ?? [], true);
            foreach ($roleCaps as $cap => $_) if (! isset($capabilities[$cap])) throw new RuntimeException("Binding {$id} references inactive capability {$cap}.");
            foreach ($binding['tools'] ?? [] as $toolId) {
                if (! isset($tools[$toolId])) throw new RuntimeException("Binding {$id} references unknown tool {$toolId}.");
                if (! isset($roleCaps[$tools[$toolId]])) throw new RuntimeException("Binding {$id} lacks capability {$tools[$toolId]} required by {$toolId}.");
            }
        }
        if ($bindings === []) throw new RuntimeException('At least one intrinsic Workforce role binding is required.');

        $skills = [];
        foreach ($manifest['skills'] ?? [] as $skill) {
            $id = (string) ($skill['skill_id'] ?? '');
            if ($id === '' || isset($skills[$id])) throw new RuntimeException('Invalid or duplicate Workforce skill: ' . ($id ?: '?'));
            $skills[$id] = true;
            $permitted = array_fill_keys($skill['permitted_capabilities'] ?? [], true);
            foreach ($permitted as $cap => $_) if (! isset($capabilities[$cap])) throw new RuntimeException("Skill {$id} references inactive capability {$cap}.");
            foreach ($skill['required_tools'] ?? [] as $toolId) {
                if (! isset($tools[$toolId])) throw new RuntimeException("Skill {$id} references unknown tool {$toolId}.");
                if (! isset($permitted[$tools[$toolId]])) throw new RuntimeException("Skill {$id} does not permit capability {$tools[$toolId]} required by {$toolId}.");
            }
        }

        $prompts = [];
        foreach ($manifest['prompts'] ?? [] as $prompt) {
            $id = (string) ($prompt['prompt_id'] ?? '');
            $roleId = (string) ($prompt['role_definition_id'] ?? '');
            if ($id === '' || isset($prompts[$id])) throw new RuntimeException('Invalid or duplicate Workforce prompt: ' . ($id ?: '?'));
            if (! isset($bindings[$roleId])) throw new RuntimeException("Prompt {$id} references unknown intrinsic role {$roleId}.");
            $instructions = $prompt['instructions'] ?? [];
            if (! is_array($instructions) || $instructions === [] || count(array_filter($instructions, static fn($v): bool => is_string($v) && trim($v) !== '')) !== count($instructions)) throw new RuntimeException("Prompt {$id} must contain non-empty executable instructions.");
            $prompts[$id] = true;
        }

        $workflowIds = [];
        foreach ($manifest['workflows'] ?? [] as $workflow) {
            $id = (string) ($workflow['workflow_id'] ?? '');
            if ($id === '' || isset($workflowIds[$id])) throw new RuntimeException('Invalid or duplicate Workforce workflow: ' . ($id ?: '?'));
            if (trim((string) ($workflow['trigger'] ?? '')) === '') throw new RuntimeException("Workflow {$id} has no Signal trigger.");
            foreach (array_filter(array_merge([(string) ($workflow['manager'] ?? '')], $workflow['specialists'] ?? [], $workflow['agents'] ?? [])) as $roleId) {
                if (! isset($bindings[$roleId])) throw new RuntimeException("Workflow {$id} references unknown intrinsic role {$roleId}.");
            }
            $workflowIds[$id] = true;
        }

        foreach ($manifest['wizards'] ?? [] as $wizard) foreach ($wizard['capabilities'] ?? [] as $cap) if (! isset($capabilities[$cap])) throw new RuntimeException("Wizard references inactive capability {$cap}.");
        foreach ($manifest['surfaces'] ?? [] as $surface) {
            foreach ($surface['tools'] ?? [] as $toolId) if (! isset($tools[$toolId])) throw new RuntimeException("Surface references unknown tool {$toolId}.");
            foreach ($surface['actions'] ?? [] as $action) { $cap=(string)($action['capability']??''); if ($cap!==''&&!isset($capabilities[$cap])) throw new RuntimeException("Surface references inactive capability {$cap}."); }
        }
    }
}
