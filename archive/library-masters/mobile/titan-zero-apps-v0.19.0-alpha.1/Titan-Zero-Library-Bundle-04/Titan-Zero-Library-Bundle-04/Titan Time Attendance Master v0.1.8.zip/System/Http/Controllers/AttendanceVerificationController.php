<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Http\Controllers;
use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;use App\Http\Controllers\Controller;use Illuminate\Http\JsonResponse;use Illuminate\Http\Request;
final class AttendanceVerificationController extends Controller
{
 public function verify(Request $request,TimeCommandBusGateway $gateway): JsonResponse
 {
  $d=$request->validate(['method'=>'required|in:site,geofence,dynamic_qr,static_qr,ip_address','site_id'=>'nullable|integer|min:1','service_location_public_id'=>'nullable|string|size:26','geofence_id'=>'nullable|integer|min:1','credential_id'=>'nullable|integer|min:1','latitude'=>'nullable|numeric|between:-90,90','longitude'=>'nullable|numeric|between:-180,180','token'=>'nullable|string|max:512','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid']);
  if(($d['method']??'')==='ip_address')$d['ip_address']=$request->ip();
  $r=$gateway->request('attendance.verify',$d,$request->user());
  $verification=$r['result']['verification']??null;$verified=is_object($verification)?(bool)$verification->verified:(bool)($verification['verified']??false);
  $status=($r['executed']??false)?($verified?200:422):202;return response()->json(['data'=>$r],$status);
 }
}
