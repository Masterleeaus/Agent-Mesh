<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Verification;

final class IpAddressVerifier
{
    public function verify(string $actualIp,array $allowedIps): array
    {
        $verified=filter_var($actualIp,FILTER_VALIDATE_IP)!==false && in_array($actualIp,array_values(array_filter($allowedIps,'is_string')),true);
        return ['verified'=>$verified,'reason_code'=>$verified?null:'ip_not_allowed'];
    }
}
