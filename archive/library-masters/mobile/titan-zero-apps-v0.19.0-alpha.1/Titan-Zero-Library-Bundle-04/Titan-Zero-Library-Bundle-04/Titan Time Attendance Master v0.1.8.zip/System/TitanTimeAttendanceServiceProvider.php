<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanTimeAttendance\System\Console\Commands\{DeliverTimeSignalsCommand,ScanTimeAttentionCommand,SyncTimeAttendanceMenuCommand};
use App\Extensions\TitanTimeAttendance\System\Governance\{
    DeferredTimeCommandBusPort,LaravelEventSignalDeliveryPort,TimeCapabilityExecutor,TimeCommandBusGateway,TimeCommandBusPort,
    TimeCommandReceiptService,TimeInputShield,TimeSignalDeliveryPort,TimeSignalOutboxDispatcher,SignalDeliveryPolicy
};
use App\Extensions\TitanTimeAttendance\System\Health\TimeAttendanceHealthCheck;
use App\Extensions\TitanTimeAttendance\System\Installer\{PackageIntegrityVerifier,TimeAttendancePreflight};
use App\Extensions\TitanTimeAttendance\System\Intelligence\TimeAttentionDetector;
use App\Extensions\TitanTimeAttendance\System\Navigation\TimeAttendanceMenuRegistrar;
use App\Extensions\TitanTimeAttendance\System\Integrations\Crm\{CrmWorkAuthorityAdapter,CrmWorkAuthorityPort};
use App\Extensions\TitanTimeAttendance\System\Integrations\Exports\TimePlatformExportRegistry;
use App\Extensions\TitanTimeAttendance\System\Integrations\Rewind\{TimeRewindIntegration,TimeRewindRecordProjector};
use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use App\Extensions\TitanTimeAttendance\System\Services\{AttendanceVerificationService,OfflineAttendanceService,SignalOutboxService,SubmissionService,TimeAttentionService,TimeEntryService,TimePolicyService,TimerService};
use App\Extensions\TitanTimeAttendance\System\Support\CapabilityCatalog;
use App\Extensions\TitanTimeAttendance\System\Surfaces\TimeSurfaceRegistry;
use App\Extensions\TitanTimeAttendance\System\Verification\{GeofenceVerifier,IpAddressVerifier,QrTokenVerifier};
use App\Extensions\TitanTimeAttendance\System\Wizards\TimeWizardRegistry;
use App\Extensions\TitanTimeAttendance\System\Workforce\Decision\{
    ConfiguredTimeAutonomyPort,DeferredTimeAssurancePort,DeferredTimeRiskPort,TimeAssurancePort,TimeAutonomyPort,TimeRiskPort,TimeWorkforceDecisionGate
};
use App\Extensions\TitanTimeAttendance\System\Workforce\{TimeAttendanceToolRegistry,TimeAttendanceWorkforceManifest,TimeAttendanceWorkforceCapabilityBinding,TimeWorkforceToolGateway};
use App\Extensions\TitanTimeAttendance\System\Workforce\Workflows\{TimeWorkflowRegistry,TimeWorkflowService};
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\{Event,File,Schema};
use Illuminate\Support\ServiceProvider;

final class TitanTimeAttendanceServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface,UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanTimeAttendance\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanTimeAttendance\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

        $this->mergeConfigFrom(__DIR__.'/../config/time-attendance.php','titan-time-attendance');
        if(!(bool)config('titan-time-attendance.enabled',true))return;

        if(!$this->app->bound(TimeCommandBusPort::class))$this->app->singleton(TimeCommandBusPort::class,DeferredTimeCommandBusPort::class);
        if(!$this->app->bound(TimeSignalDeliveryPort::class))$this->app->singleton(TimeSignalDeliveryPort::class,LaravelEventSignalDeliveryPort::class);
        if(!$this->app->bound(CrmWorkAuthorityPort::class))$this->app->singleton(CrmWorkAuthorityPort::class,CrmWorkAuthorityAdapter::class);
        if(!$this->app->bound(TimeRiskPort::class))$this->app->singleton(TimeRiskPort::class,DeferredTimeRiskPort::class);
        if(!$this->app->bound(TimeAssurancePort::class))$this->app->singleton(TimeAssurancePort::class,DeferredTimeAssurancePort::class);
        if(!$this->app->bound(TimeAutonomyPort::class))$this->app->singleton(TimeAutonomyPort::class,ConfiguredTimeAutonomyPort::class);

        foreach([
            TimeAttendancePreflight::class,TimeAttendanceHealthCheck::class,SignalOutboxService::class,TimeEntryService::class,TimerService::class,SubmissionService::class,TimePolicyService::class,
            GeofenceVerifier::class,IpAddressVerifier::class,QrTokenVerifier::class,AttendanceVerificationService::class,OfflineAttendanceService::class,
            TimeAttendancePermissionService::class,TimeInputShield::class,TimeCommandReceiptService::class,TimeCapabilityExecutor::class,TimeCommandBusGateway::class,
            SignalDeliveryPolicy::class,TimeSignalOutboxDispatcher::class,TimeAttendanceWorkforceManifest::class,TimeAttendanceToolRegistry::class,TimeWorkforceDecisionGate::class,TimeWorkforceToolGateway::class,
            TimeAttentionDetector::class,TimeAttentionService::class,TimeWorkflowRegistry::class,TimeWorkflowService::class,TimeWizardRegistry::class,TimeSurfaceRegistry::class,
            PackageIntegrityVerifier::class,TimeRewindRecordProjector::class,TimeRewindIntegration::class,TimePlatformExportRegistry::class,TimeAttendanceMenuRegistrar::class,
        ] as $service)$this->app->singleton($service);

        $this->app->singleton('titan.time-attendance.workforce-manifest',fn($app)=>$app->make(TimeAttendanceWorkforceManifest::class)->all());
        $this->app->singleton(TimeAttendanceWorkforceCapabilityBinding::class);
        $this->app->singleton('titan.time-attendance.workforce-capability-binding',fn($app):array=>$app->make(TimeAttendanceWorkforceCapabilityBinding::class)->all());
        $this->app->singleton('titan.time-attendance.workforce-tools',fn($app)=>$app->make(TimeWorkforceToolGateway::class));
        $this->app->singleton('titan.time-attendance.capabilities',fn()=>CapabilityCatalog::all());
        $this->app->singleton('titan.time-attendance.command-gateway',fn($app)=>$app->make(TimeCommandBusGateway::class));
        $this->app->singleton('titan.time-attendance.attention',fn($app)=>$app->make(TimeAttentionService::class));
        $this->app->singleton('titan.time-attendance.workflows',fn($app)=>$app->make(TimeWorkflowService::class));
        $this->app->singleton('titan.time-attendance.wizards',fn($app)=>$app->make(TimeWizardRegistry::class)->all());
        $this->app->singleton('titan.time-attendance.surfaces',fn($app)=>$app->make(TimeSurfaceRegistry::class)->all());
        $this->app->singleton('titan.time-attendance.health',fn($app)=>$app->make(TimeAttendanceHealthCheck::class));
        $this->app->singleton('titan.time-attendance.platform-exports',fn($app)=>$app->make(TimePlatformExportRegistry::class)->all());
    }

    public function boot(): void
    {
        if(!(bool)config('titan-time-attendance.enabled',true))return;
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadViewsFrom(__DIR__.'/../resources/views','titan-time-attendance');
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->publishes([__DIR__.'/../config/time-attendance.php'=>config_path('titan-time-attendance.php')],'titan-time-attendance-config');

        $this->app->booted(function():void{
            $this->app->make(TimeRewindIntegration::class)->registerIfAvailable();
            $menu=$this->app->make(TimeAttendanceMenuRegistrar::class);
            $menu->registerContributions();
            $menu->syncHostMenu();
        });

        Event::listen('titan.signal',function($envelope):void{
            if(!is_array($envelope))return;
            if(!Schema::hasTable('ext_titan_time_workflow_runs'))return;
            $this->app->make(TimeWorkflowService::class)->handleSignal($envelope);
        });

        if($this->app->runningInConsole()){
            $this->commands([DeliverTimeSignalsCommand::class,ScanTimeAttentionCommand::class,SyncTimeAttendanceMenuCommand::class]);
            $this->app->booted(function():void{
                $schedule=$this->app->make(Schedule::class);
                $schedule->command('titan-time-attendance:deliver-signals --limit=200')->everyMinute()->withoutOverlapping(5)->onOneServer();
                $schedule->command('titan-time-attendance:scan-attention')->everyFiveMinutes()->withoutOverlapping(10)->onOneServer();
            });
        }
    }

    public function registerKey(): string{return 'titan-time-attendance';}
    public static function uninstall(): void{File::delete(config_path('titan-time-attendance.php'));/* retain operational/audit data by default */}
}
