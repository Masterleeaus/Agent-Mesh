<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use App\Extensions\TitanTimeAttendance\System\Integrations\Crm\CrmWorkAuthorityPort;
use App\Extensions\TitanTimeAttendance\System\Services\{AttendanceVerificationService,OfflineAttendanceService,SubmissionService,TimeEntryService,TimePolicyService,TimerService};
use InvalidArgumentException;

final class TimeCapabilityExecutor
{
    public function __construct(
        private readonly TimeEntryService $entries,
        private readonly TimerService $timers,
        private readonly SubmissionService $submissions,
        private readonly AttendanceVerificationService $attendance,
        private readonly OfflineAttendanceService $offline,
        private readonly TimePolicyService $policy,
        private readonly CrmWorkAuthorityPort $crm,
        private readonly TimeActorReferenceGuard $actorReferences,
    ) {}

    /** @return array<string,mixed> */
    public function execute(TimeCommandRequest $request): array
    {
        $i=$request->input;$tenant=$request->companyId;$actor=$request->actorUserId;
        if(array_key_exists('user_id',$i))$this->actorReferences->assertUserBelongsToCompany($tenant,(int)$i['user_id']);
        $workOrderPublicId=trim((string)($i['work_order_public_id']??''));
        if ($workOrderPublicId!=='') $this->crm->assertWorkOrderAccessible($tenant,$actor,$workOrderPublicId);
        $serviceLocationPublicId=trim((string)($i['service_location_public_id']??''));
        if ($serviceLocationPublicId!=='') $this->crm->assertServiceLocationAccessible($tenant,$actor,$serviceLocationPublicId);

        $trace=['trace_id'=>$request->traceId,'correlation_id'=>$request->correlationId,'causation_id'=>$request->causationId,'dedup_key'=>$request->commandId];
        return match($request->capability){
            'time.entry.create'=>['time_entry'=>$this->entries->create($tenant,$actor,$i+$trace)],
            'time.timer.start'=>['timer'=>$this->timers->start($tenant,$actor,isset($i['work_order_id'])?(int)$i['work_order_id']:null,$workOrderPublicId?:null,$trace)],
            'time.timer.stop'=>$this->timers->stop($tenant,$actor,(int)($i['timer_id']??0),$i+$trace),
            'time.submission.submit'=>['submission'=>$this->submissions->submit($tenant,$actor,(string)($i['week_start']??''),(string)($i['week_end']??''),$trace)],
            'time.submission.review'=>['submission'=>$this->submissions->review($tenant,$actor,(int)($i['submission_id']??0),(string)($i['decision']??''),$i['notes']??null,$trace)],
            'attendance.verify'=>['verification'=>$this->attendance->verify($tenant,$actor,(string)($i['method']??''),$i+$trace)],
            'attendance.offline.ingest'=>$this->offline->ingest($tenant,$actor,$i+$trace),
            'time.policy.update'=>['policy'=>$this->policy->update($tenant,$actor,$i,$trace)],
            default=>throw new InvalidArgumentException("Capability is not a governed write operation: {$request->capability}"),
        };
    }
}
