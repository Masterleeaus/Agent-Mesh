<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Intelligence;

use App\Extensions\TitanTimeAttendance\System\Domain\TimeIntervalOverlap;
use App\Extensions\TitanTimeAttendance\System\Models\{AttendanceVerificationLog,OfflineAttendanceEvent,TimeEntry,TimePolicy,TimeSubmission,TimeTimer};

final class TimeAttentionDetector
{
    /** @return list<AttentionFinding> */
    public function detect(int $companyId, ?int $userId = null): array
    {
        $policy = TimePolicy::query()->forCompany($companyId)->first();
        $maxTimer = (int) ($policy?->max_timer_minutes ?? config('titan-time-attendance.attention.max_timer_minutes', 720));
        $maxEntry = (int) ($policy?->max_time_entry_minutes ?? config('titan-time-attendance.attention.max_time_entry_minutes', 720));
        $staleDays = (int) ($policy?->stale_submission_days ?? config('titan-time-attendance.attention.stale_submission_days', 2));
        $offlineStuck = (int) ($policy?->offline_stuck_minutes ?? config('titan-time-attendance.attention.offline_stuck_minutes', 60));
        $scanLimit = max(10, min(2000, (int) config('titan-time-attendance.attention.scan_limit', 200)));
        $findings = [];

        $timerQuery = TimeTimer::query()->forCompany($companyId)->where('status', 'running')->where('started_at', '<', now()->subMinutes($maxTimer));
        if ($userId) $timerQuery->where('user_id', $userId);
        foreach ($timerQuery->limit($scanLimit)->get() as $timer) {
            $findings[] = new AttentionFinding('overdue_timer', 'overdue_timer', 'timer:' . $timer->getKey(), (int) $timer->user_id, 'workforce-presence-agent', 'MEDIUM', 'time.timer.stop', [
                'timer_id' => $timer->getKey(), 'started_at' => $timer->started_at?->toIso8601String(), 'threshold_minutes' => $maxTimer,
            ]);
        }

        $verify = AttendanceVerificationLog::query()->forCompany($companyId)->where('verified', false)->where('created_at', '>=', now()->subDay());
        if ($userId) $verify->where('user_id', $userId);
        foreach ($verify->limit($scanLimit)->get() as $log) {
            $findings[] = new AttentionFinding('failed_verification', 'failed_verification', 'verification:' . $log->getKey(), (int) $log->user_id, 'attendance-exception-specialist', 'MEDIUM', 'attendance.verify', [
                'verification_id' => $log->getKey(), 'method' => $log->method, 'reason_code' => $log->reason_code,
            ]);
        }

        $offline = OfflineAttendanceEvent::query()->forCompany($companyId)->where(function ($query) use ($offlineStuck): void {
            $query->whereIn('reconciliation_status', ['rejected', 'failed'])
                ->orWhere(function ($pending) use ($offlineStuck): void {
                    $pending->whereIn('reconciliation_status', ['pending_application', 'pending_verification'])->where('received_at', '<', now()->subMinutes($offlineStuck));
                });
        });
        if ($userId) $offline->where('user_id', $userId);
        foreach ($offline->limit($scanLimit)->get() as $event) {
            $findings[] = new AttentionFinding('offline_rejected', 'offline_rejected', 'offline:' . $event->source_event_id, (int) $event->user_id, 'attendance-exception-specialist', 'MEDIUM', 'attendance.offline.ingest', [
                'offline_event_id' => $event->getKey(), 'source_event_id' => $event->source_event_id, 'reconciliation_status' => $event->reconciliation_status,
            ]);
        }

        $long = TimeEntry::query()->forCompany($companyId)->where('minutes', '>', $maxEntry)->where('work_date', '>=', now()->subDays(14)->toDateString());
        if ($userId) $long->where('user_id', $userId);
        foreach ($long->limit($scanLimit)->get() as $entry) {
            $findings[] = new AttentionFinding('long_time_entry', 'long_time_entry', 'entry:' . $entry->getKey(), (int) $entry->user_id, 'timesheet-auditor', 'MEDIUM', null, [
                'time_entry_id' => $entry->getKey(), 'minutes' => (int) $entry->minutes, 'threshold_minutes' => $maxEntry,
            ]);
        }

        $intervalQuery = TimeEntry::query()->forCompany($companyId)
            ->whereNotNull('start_time')->whereNotNull('end_time')
            ->where('work_date', '>=', now()->subDays(14)->toDateString())
            ->orderBy('user_id')->orderBy('work_date')->orderBy('start_time');
        if ($userId) $intervalQuery->where('user_id', $userId);
        $intervalRows = [];
        foreach ($intervalQuery->limit($scanLimit)->get(['id','user_id','work_date','start_time','end_time']) as $entry) {
            $intervalRows[] = [
                'id' => (int) $entry->getKey(),
                'user_id' => (int) $entry->user_id,
                'work_date' => $entry->work_date?->toDateString() ?? (string) $entry->work_date,
                'start_time' => (string) $entry->start_time,
                'end_time' => (string) $entry->end_time,
            ];
        }
        foreach (TimeIntervalOverlap::pairs($intervalRows) as $pair) {
            $findings[] = new AttentionFinding('overlapping_time', 'overlapping_time', 'entries:' . $pair['left_id'] . ':' . $pair['right_id'], $pair['user_id'], 'timesheet-auditor', 'HIGH', null, [
                'time_entry_ids' => [$pair['left_id'], $pair['right_id']], 'work_date' => $pair['work_date'], 'overlap_minutes' => $pair['overlap_minutes'],
            ]);
        }

        $running = TimeTimer::query()->forCompany($companyId)->where('status', 'running')->selectRaw('user_id, COUNT(*) as timer_count')->groupBy('user_id')->havingRaw('COUNT(*) > 1');
        if ($userId) $running->where('user_id', $userId);
        foreach ($running->limit($scanLimit)->get() as $row) {
            $ids = TimeTimer::query()->forCompany($companyId)->where('user_id', (int) $row->user_id)->where('status', 'running')->limit($scanLimit)->pluck('id')->all();
            $findings[] = new AttentionFinding('multiple_running_timers', 'multiple_running_timers', 'user:' . $row->user_id, (int) $row->user_id, 'workforce-presence-agent', 'HIGH', 'time.timer.stop', [
                'timer_ids' => $ids, 'timer_count' => (int) $row->timer_count,
            ]);
        }

        $weekStarts = (int) ($policy?->week_starts_on ?? config('titan-time-attendance.week_starts_on', 1));
        $weekStart = now()->startOfWeek($weekStarts)->subWeek()->startOfDay();
        $weekEnd = (clone $weekStart)->addDays(6)->endOfDay();
        if (now()->greaterThan((clone $weekEnd)->addDays($staleDays))) {
            $users = TimeEntry::query()->forCompany($companyId)->whereBetween('work_date', [$weekStart->toDateString(), $weekEnd->toDateString()]);
            if ($userId) $users->where('user_id', $userId);
            foreach ($users->distinct()->limit($scanLimit)->pluck('user_id') as $uid) {
                $exists = TimeSubmission::query()->forCompany($companyId)->where('user_id', (int) $uid)->whereDate('week_start', $weekStart->toDateString())->exists();
                if (! $exists) $findings[] = new AttentionFinding('stale_submission', 'stale_submission', 'week:' . $weekStart->toDateString() . ':user:' . $uid, (int) $uid, 'timesheet-auditor', 'MEDIUM', 'time.submission.submit', [
                    'week_start' => $weekStart->toDateString(), 'week_end' => $weekEnd->toDateString(),
                ]);
            }
        }
        return $findings;
    }
}
