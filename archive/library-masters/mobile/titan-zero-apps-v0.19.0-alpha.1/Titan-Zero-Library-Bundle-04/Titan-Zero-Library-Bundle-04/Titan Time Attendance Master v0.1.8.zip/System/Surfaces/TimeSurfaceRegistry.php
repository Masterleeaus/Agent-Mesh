<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Surfaces;
use RuntimeException;
final class TimeSurfaceRegistry
{
    private ?array $cache=null;
    public function all(): array{if($this->cache!==null)return $this->cache;$path=dirname(__DIR__,2).'/resources/surfaces/surfaces.json';$json=@file_get_contents($path);if($json===false)throw new RuntimeException('Time & Attendance surfaces are unavailable.');return $this->cache=json_decode($json,true,512,JSON_THROW_ON_ERROR);}
}
