<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use App\Extensions\TitanTimeAttendance\System\Models\TimeCommandReceipt;
use Illuminate\Database\QueryException;
use Illuminate\Validation\ValidationException;

final class TimeCommandReceiptService
{
    public function requestHash(TimeCommandRequest $request): string
    {
        $input=$request->input;
        unset($input['trace_id'],$input['correlation_id'],$input['causation_id'],$input['_context']);
        return hash('sha256',json_encode([$request->capability,$input],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }

    /** @return array<string,mixed>|null */
    public function replay(TimeCommandRequest $request): ?array
    {
        $existing=TimeCommandReceipt::query()->forCompany($request->companyId)->where('capability',$request->capability)->where('idempotency_key',$request->idempotencyKey)->first();
        if(!$existing)return null;
        $this->assertSameRequest($existing,$request);
        return $this->envelope($existing,true);
    }

    /**
     * Creates the idempotency row before domain mutation. The unique tenant+capability+key
     * constraint serialises concurrent retries; a losing writer reloads the authoritative row.
     */
    public function reserve(TimeCommandRequest $request,array $definition): TimeCommandReceipt
    {
        $attributes=['company_id'=>$request->companyId,'capability'=>$request->capability,'idempotency_key'=>$request->idempotencyKey];
        $values=[
            'command_id'=>$request->commandId,'request_hash'=>$this->requestHash($request),'actor_user_id'=>$request->actorUserId,'actor_type'=>$request->actorType,
            'source'=>$request->source,'risk_class'=>$definition['risk']??'MEDIUM','human_approval_required'=>(bool)($definition['human_approval']??false),'status'=>'processing','result'=>null,
            'trace_id'=>$request->traceId,'correlation_id'=>$request->correlationId,'causation_id'=>$request->causationId,
        ];
        try {
            TimeCommandReceipt::query()->firstOrCreate($attributes, $values);
        } catch (QueryException) {
            // A concurrent request may have won the unique tenant+capability+idempotency insert.
        }

        // Gateway calls reserve() inside a DB transaction. Locking the authoritative receipt
        // serialises concurrent retries so only one request can progress from processing to execution.
        $receipt = TimeCommandReceipt::query()
            ->forCompany($request->companyId)
            ->where('capability', $request->capability)
            ->where('idempotency_key', $request->idempotencyKey)
            ->lockForUpdate()
            ->firstOrFail();
        $this->assertSameRequest($receipt, $request);
        return $receipt;
    }

    public function complete(TimeCommandReceipt $receipt,string $status,array $result): TimeCommandReceipt
    {
        $receipt->forceFill(['status'=>$status,'result'=>$result,'executed_at'=>$status==='executed'?now():null])->save();
        return $receipt->refresh();
    }

    /** @return array<string,mixed> */
    public function envelope(TimeCommandReceipt $receipt,bool $duplicate): array
    {
        return [
            'status'=>$receipt->status,'executed'=>$receipt->status==='executed','duplicate'=>$duplicate,'capability'=>$receipt->capability,
            'command_id'=>$receipt->command_id,'receipt_id'=>$receipt->getKey(),'company_id'=>(int)$receipt->company_id,
            'trace_id'=>$receipt->trace_id,'correlation_id'=>$receipt->correlation_id,'result'=>$receipt->result??[],
        ];
    }

    private function assertSameRequest(TimeCommandReceipt $receipt,TimeCommandRequest $request): void
    {
        if(!hash_equals((string)$receipt->request_hash,$this->requestHash($request))){
            throw ValidationException::withMessages(['idempotency_key'=>'Idempotency key was already used for different command input.']);
        }
    }
}
