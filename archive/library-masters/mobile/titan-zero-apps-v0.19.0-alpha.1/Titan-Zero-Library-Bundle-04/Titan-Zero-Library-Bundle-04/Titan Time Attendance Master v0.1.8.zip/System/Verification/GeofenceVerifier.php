<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Verification;

final class GeofenceVerifier
{
    public function verify(float $actualLat,float $actualLng,float $targetLat,float $targetLng,int $radiusMetres): array
    {
        $distance=$this->distanceMetres($actualLat,$actualLng,$targetLat,$targetLng);
        return ['verified'=>$radiusMetres > 0 && $distance <= $radiusMetres,'reason_code'=>$distance <= $radiusMetres ? null : 'outside_geofence','distance_metres'=>(int)round($distance),'radius_metres'=>$radiusMetres];
    }
    public function distanceMetres(float $lat1,float $lng1,float $lat2,float $lng2): float
    {
        $earth=6371000.0; $p1=deg2rad($lat1); $p2=deg2rad($lat2); $dp=deg2rad($lat2-$lat1); $dl=deg2rad($lng2-$lng1);
        $a=sin($dp/2)**2+cos($p1)*cos($p2)*sin($dl/2)**2;
        return $earth*2*atan2(sqrt($a),sqrt(1-$a));
    }
}
