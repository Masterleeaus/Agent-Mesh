<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Services;
use App\Extensions\TitanTimeAttendance\System\Domain\TimeMath; use App\Extensions\TitanTimeAttendance\System\Models\TimeEntry;
final class TimeEntryService
{
 public function __construct(private readonly SignalOutboxService $signals) {}
 public function create(int $companyId,int $actorUserId,array $data): TimeEntry
 {
   $minutes=isset($data['minutes'])?(int)$data['minutes']:TimeMath::minutesBetween((string)$data['start_time'],(string)$data['end_time']);
   $rate=isset($data['rate_per_hour'])?(float)$data['rate_per_hour']:null;$mult=(float)($data['overtime_multiplier']??1.0);
   $entry=TimeEntry::query()->create([
     'company_id'=>$companyId,'user_id'=>(int)($data['user_id']??$actorUserId),'created_by_user_id'=>$actorUserId,
     'work_order_id'=>$data['work_order_id']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'project_id'=>$data['project_id']??null,'task_id'=>$data['task_id']??null,
     'work_date'=>$data['work_date'],'start_time'=>$data['start_time']??null,'end_time'=>$data['end_time']??null,'minutes'=>$minutes,'type'=>$data['type']??'regular','notes'=>$data['notes']??null,'rate_per_hour'=>$rate,'overtime_multiplier'=>$mult,
     'cost_total'=>$rate===null?null:TimeMath::cost($minutes,$rate,$mult),'source'=>$data['source']??'manual','trace_id'=>$data['trace_id']??null,
     'correlation_id'=>$data['correlation_id']??null,'causation_id'=>$data['causation_id']??null,
   ]);
   $this->signals->record($companyId,'time.entry.created',[
     'time_entry_id'=>$entry->getKey(),'user_id'=>$entry->user_id,'work_order_public_id'=>$entry->work_order_public_id,'minutes'=>$entry->minutes,
   ],$data+['dedup_key'=>isset($data['dedup_key'])?$data['dedup_key'].':time-entry':null]);
   return $entry;
 }
}
