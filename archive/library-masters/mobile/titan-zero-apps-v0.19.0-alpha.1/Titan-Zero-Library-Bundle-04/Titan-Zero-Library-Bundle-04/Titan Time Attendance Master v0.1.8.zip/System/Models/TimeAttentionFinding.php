<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder;use Illuminate\Database\Eloquent\Model;
final class TimeAttentionFinding extends Model
{
    protected $table='ext_titan_time_attention_findings';
    protected $fillable=['company_id','finding_key','finding_type','source_ref','user_id','assigned_role','severity','status','recommended_capability','evidence','detected_at','resolved_at'];
    protected $casts=['evidence'=>'array','detected_at'=>'datetime','resolved_at'=>'datetime'];
    public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
