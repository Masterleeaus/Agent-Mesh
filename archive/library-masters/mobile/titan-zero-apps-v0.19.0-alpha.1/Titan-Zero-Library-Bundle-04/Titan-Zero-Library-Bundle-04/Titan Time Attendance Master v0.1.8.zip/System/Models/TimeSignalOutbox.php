<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeSignalOutbox extends Model
{
 protected $table='ext_titan_time_signal_outbox';
 protected $fillable=['company_id','event_id','event_type','dedup_key','payload','trace_id','correlation_id','causation_id','status','claim_token','claimed_at','lease_expires_at','attempts','available_at','delivered_at','dead_lettered_at','last_error'];
 protected $casts=['payload'=>'array','attempts'=>'integer','claimed_at'=>'datetime','lease_expires_at'=>'datetime','available_at'=>'datetime','delivered_at'=>'datetime','dead_lettered_at'=>'datetime'];
 public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
