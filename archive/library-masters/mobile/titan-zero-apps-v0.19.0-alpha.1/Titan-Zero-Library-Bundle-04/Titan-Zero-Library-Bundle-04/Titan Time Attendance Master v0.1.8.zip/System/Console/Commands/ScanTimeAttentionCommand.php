<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Console\Commands;
use App\Extensions\TitanTimeAttendance\System\Jobs\DetectTimeAttentionJob;use Illuminate\Console\Command;use Illuminate\Support\Facades\{DB,Schema};
final class ScanTimeAttentionCommand extends Command
{
    protected $signature='titan-time-attendance:scan-attention {--tenant=}';protected $description='Dispatch tenant-partitioned Titan Time & Attendance attention scans.';
    public function handle(): int
    {
        if(!Schema::hasTable('ext_titan_time_attention_findings')){$this->warn('Titan Time & Attendance attention migration has not run.');return self::SUCCESS;}
        $tenant=(int)($this->option('tenant')??0);$ids=$tenant>0?[$tenant]:$this->tenantIds();foreach($ids as $id)DetectTimeAttentionJob::dispatch((int)$id);$this->info('Dispatched '.count($ids).' tenant attention scan(s).');return self::SUCCESS;
    }
    private function tenantIds(): array{$ids=[];foreach(['ext_titan_time_entries','ext_titan_time_timers','ext_titan_time_submissions','ext_titan_time_verification_logs','ext_titan_time_offline_events'] as $table){if(!Schema::hasTable($table))continue;foreach(DB::table($table)->distinct()->pluck('company_id') as $id)$ids[(int)$id]=true;}return array_keys($ids);}
}
