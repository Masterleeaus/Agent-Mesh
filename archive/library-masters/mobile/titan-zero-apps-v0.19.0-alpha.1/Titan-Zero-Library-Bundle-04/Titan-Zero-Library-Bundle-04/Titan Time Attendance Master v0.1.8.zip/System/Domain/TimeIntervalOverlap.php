<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Domain;

final class TimeIntervalOverlap
{
    /**
     * @param iterable<array{id:int,user_id:int,work_date:string,start_time:string,end_time:string}> $rows
     * @return list<array{left_id:int,right_id:int,user_id:int,work_date:string,overlap_minutes:int}>
     */
    public static function pairs(iterable $rows): array
    {
        $groups = [];
        foreach ($rows as $row) {
            $start = self::minuteOfDay((string) ($row['start_time'] ?? ''));
            $end = self::minuteOfDay((string) ($row['end_time'] ?? ''));
            if ($start === null || $end === null) continue;
            if ($end <= $start) $end += 1440;
            $key = (int) $row['user_id'] . '|' . (string) $row['work_date'];
            $groups[$key][] = [
                'id' => (int) $row['id'],
                'user_id' => (int) $row['user_id'],
                'work_date' => (string) $row['work_date'],
                'start' => $start,
                'end' => $end,
            ];
        }

        $pairs = [];
        foreach ($groups as $items) {
            usort($items, static fn(array $a, array $b): int => [$a['start'], $a['end'], $a['id']] <=> [$b['start'], $b['end'], $b['id']]);
            $count = count($items);
            for ($i = 0; $i < $count; $i++) {
                for ($j = $i + 1; $j < $count; $j++) {
                    if ($items[$j]['start'] >= $items[$i]['end']) break;
                    $minutes = min($items[$i]['end'], $items[$j]['end']) - max($items[$i]['start'], $items[$j]['start']);
                    if ($minutes <= 0) continue;
                    $pairs[] = [
                        'left_id' => $items[$i]['id'],
                        'right_id' => $items[$j]['id'],
                        'user_id' => $items[$i]['user_id'],
                        'work_date' => $items[$i]['work_date'],
                        'overlap_minutes' => $minutes,
                    ];
                }
            }
        }
        return $pairs;
    }

    private static function minuteOfDay(string $value): ?int
    {
        if (! preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', trim($value), $matches)) return null;
        $hour = (int) $matches[1];
        $minute = (int) $matches[2];
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) return null;
        return ($hour * 60) + $minute;
    }
}
