<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

interface TimeCommandBusPort
{
    public function available(): bool;

    /** @return array<string,mixed> */
    public function dispatch(TimeCommandRequest $request): array;
}
