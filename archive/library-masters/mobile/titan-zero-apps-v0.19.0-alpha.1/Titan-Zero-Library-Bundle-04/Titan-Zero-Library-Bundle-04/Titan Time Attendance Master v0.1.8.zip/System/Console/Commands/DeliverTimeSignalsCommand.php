<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Console\Commands;

use App\Extensions\TitanTimeAttendance\System\Jobs\DeliverTimeSignalsJob;
use App\Extensions\TitanTimeAttendance\System\Models\TimeSignalOutbox;
use Illuminate\Console\Command;

final class DeliverTimeSignalsCommand extends Command
{
    protected $signature = 'titan-time-attendance:deliver-signals {--limit=200}';
    protected $description = 'Dispatch tenant-partitioned Titan Time & Attendance signal delivery jobs, including stale lease recovery.';

    public function handle(): int
    {
        $limit = max(1, min(500, (int) $this->option('limit')));
        $now = now();
        $tenantIds = TimeSignalOutbox::query()
            ->where(function ($query) use ($now): void {
                $query->where(function ($pending) use ($now): void {
                    $pending->where('status', 'pending')
                        ->where(function ($available) use ($now): void {
                            $available->whereNull('available_at')->orWhere('available_at', '<=', $now);
                        });
                })->orWhere(function ($stale) use ($now): void {
                    $stale->where('status', 'delivering')->whereNotNull('lease_expires_at')->where('lease_expires_at', '<=', $now);
                });
            })
            ->select('company_id')
            ->distinct()
            ->orderBy('company_id')
            ->limit(500)
            ->pluck('company_id');

        foreach ($tenantIds as $companyId) DeliverTimeSignalsJob::dispatch((int) $companyId, $limit);

        $this->line(json_encode([
            'tenants_dispatched' => $tenantIds->count(),
            'queue' => 'titan-time-attendance',
            'stale_lease_recovery' => true,
        ], JSON_UNESCAPED_SLASHES));

        return self::SUCCESS;
    }
}
