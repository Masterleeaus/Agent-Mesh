<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Domain;

use InvalidArgumentException;

final class TimeMath
{
    public static function minutesBetween(string $start, string $end): int
    {
        $s=self::minutesOfDay($start); $e=self::minutesOfDay($end);
        if ($e < $s) $e += 1440;
        return $e-$s;
    }

    public static function cost(int $minutes, float $ratePerHour, float $multiplier=1.0): float
    {
        if ($minutes < 0 || $ratePerHour < 0 || $multiplier < 0) throw new InvalidArgumentException('Time/cost inputs cannot be negative.');
        return round(($minutes / 60) * $ratePerHour * $multiplier, 2);
    }

    private static function minutesOfDay(string $time): int
    {
        if (! preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $m)) throw new InvalidArgumentException('Invalid time.');
        $h=(int)$m[1]; $min=(int)$m[2];
        if ($h>23 || $min>59) throw new InvalidArgumentException('Invalid time.');
        return ($h*60)+$min;
    }
}
