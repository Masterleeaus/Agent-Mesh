<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class TimeAttendanceMenuRegistrar
{
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    /** Register request-local structural navigation without coupling to one registry signature. */
    public function registerContributions(): void
    {
        $items = TimeAttendanceNavigation::user();
        if ($this->registerWith(self::USER_REGISTRY, [
            [$items],
            ['titan-time-attendance', $items],
            ['navigation.user', 'titan-time-attendance', $items],
        ])) {
            return;
        }

        // Some Titan hosts expose only the generic contribution registry.
        $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.user', 'titan-time-attendance', $items],
            ['navigation.user', $items],
            [$items],
        ]);
    }

    /**
     * Synchronise extension-owned structural rows into MagicAI's menu table when it exists.
     * Existing administrator-controlled order/enabled state is preserved.
     */
    public function syncHostMenu(bool $forceRegenerate = false): array
    {
        if (! Schema::hasTable('menus')) {
            return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menus_table_unavailable'];
        }

        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (! isset($columns['key'])) {
                return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menus_key_column_unavailable'];
            }

            $changed = false;
            foreach (TimeAttendanceNavigation::user() as $definition) {
                $changed = $this->upsertDefinition($definition, $columns) || $changed;
            }

            $regenerated = false;
            if ($changed || $forceRegenerate) {
                $regenerated = $this->regenerateMenuCache();
            }

            return ['available' => true, 'changed' => $changed, 'regenerated' => $regenerated, 'reason' => null];
        } catch (\Throwable) {
            // Navigation compatibility must never break extension/runtime boot.
            return ['available' => false, 'changed' => false, 'regenerated' => false, 'reason' => 'menu_sync_failed'];
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsertDefinition(array $definition, array $columns): bool
    {
        $key = (string) ($definition['key'] ?? '');
        if ($key === '') return false;

        $existing = DB::table('menus')->where('key', $key)->first();
        $now = now();
        $vendor = [
            'parent_id' => null,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $definition['icon'] ?? null,
            'svg' => $definition['svg'] ?? null,
            'params' => json_encode($definition['params'] ?? [], JSON_UNESCAPED_SLASHES),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            // NULL avoids incorrectly treating this free operational surface as a MagicAI plan feature.
            'extension' => null,
            'updated_at' => $now,
        ];
        $vendor = array_intersect_key($vendor, $columns);

        if ($existing !== null) {
            $needsUpdate = false;
            foreach ($vendor as $column => $value) {
                if ($column === 'updated_at') continue;
                $current = $existing->{$column} ?? null;
                if ((string) $current !== (string) $value) {
                    $needsUpdate = true;
                    break;
                }
            }
            if (! $needsUpdate) return false;
            DB::table('menus')->where('key', $key)->update($vendor);
            return true;
        }

        $insert = array_merge([
            'key' => $key,
            'order' => (int) ($definition['order'] ?? 14),
            'is_active' => 1,
            'created_at' => $now,
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ], $vendor);
        $insert = array_intersect_key($insert, $columns);
        DB::table('menus')->insert($insert);
        return true;
    }

    /** @param list<array<int,mixed>> $argumentSets */
    private function registerWith(string $class, array $argumentSets): bool
    {
        if (! class_exists($class)) return false;

        try {
            $registry = app($class);
        } catch (\Throwable) {
            return false;
        }

        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) continue;
            foreach ($argumentSets as $arguments) {
                try {
                    $registry->{$method}(...$arguments);
                    return true;
                } catch (\Throwable) {
                    // Try the next known host signature. Navigation registration is fail-open.
                }
            }
        }

        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class = self::MENU_SERVICE;
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) return false;

        try {
            app($class)->regenerate();
            return true;
        } catch (\Throwable) {
            try {
                $class::regenerate();
                return true;
            } catch (\Throwable) {
                return false;
            }
        }
    }
}
