<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeIpRule extends Model
{
 protected $table='ext_titan_time_ip_rules';
 protected $fillable=['company_id','site_id','service_location_public_id','label','ip_address','active'];
 protected $casts=['active'=>'boolean'];
 public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
