<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Workforce;

use App\Extensions\TitanTimeAttendance\System\Domain\TimeMath;
use App\Extensions\TitanTimeAttendance\System\Models\{
    AttendanceVerificationLog,
    OfflineAttendanceEvent,
    TimeAttentionFinding,
    TimeEntry,
    TimePolicy,
    TimeSubmission,
    TimeTimer,
    TimeWorkflowRun
};
use InvalidArgumentException;

/** Bounded tenant-scoped tool catalogue. Write tools are executed only by TimeWorkforceToolGateway. */
final class TimeAttendanceToolRegistry
{
    /** @return array<string,array{mode:string,capability:string}> */
    public function definitions(): array
    {
        return [
            'time.entries.search' => ['mode'=>'read','capability'=>'time.entry.read'],
            'time.submissions.queue' => ['mode'=>'read','capability'=>'time.entry.read'],
            'time.submissions.inspect' => ['mode'=>'read','capability'=>'time.entry.read'],
            'time.costing.preview' => ['mode'=>'read','capability'=>'time.costing.calculate'],
            'attendance.exceptions.search' => ['mode'=>'read','capability'=>'attendance.verification.audit'],
            'attendance.verifications.search' => ['mode'=>'read','capability'=>'attendance.verification.audit'],
            'attendance.policy.inspect' => ['mode'=>'read','capability'=>'time.policy.read'],
            'attendance.offline.inspect' => ['mode'=>'read','capability'=>'attendance.verification.audit'],
            'time.timers.active' => ['mode'=>'read','capability'=>'time.entry.read'],
            'time.attention.search' => ['mode'=>'read','capability'=>'time.attention.read'],
            'time.workflows.inspect' => ['mode'=>'read','capability'=>'time.workflow.read'],
            'time.timer.start' => ['mode'=>'write','capability'=>'time.timer.start'],
            'time.timer.stop' => ['mode'=>'write','capability'=>'time.timer.stop'],
            'time.submission.submit' => ['mode'=>'write','capability'=>'time.submission.submit'],
            'time.submission.review' => ['mode'=>'write','capability'=>'time.submission.review'],
            'attendance.verify' => ['mode'=>'write','capability'=>'attendance.verify'],
            'attendance.offline.ingest' => ['mode'=>'write','capability'=>'attendance.offline.ingest'],
            'time.policy.update' => ['mode'=>'write','capability'=>'time.policy.update'],
        ];
    }

    /** @return array{mode:string,capability:string} */
    public function definition(string $toolId): array
    {
        $definition=$this->definitions()[$toolId]??null;
        if($definition===null)throw new InvalidArgumentException("Unknown Titan Time & Attendance tool: {$toolId}");
        return $definition;
    }

    public function invoke(string $toolId,int $companyId,int $actorUserId,array $input=[]): mixed
    {
        if($companyId<=0||$actorUserId<=0)throw new InvalidArgumentException('A resolved tenant and actor are required.');
        $definition=$this->definition($toolId);
        if($definition['mode']!=='read')throw new InvalidArgumentException("Write tool {$toolId} must execute through TimeWorkforceToolGateway.");
        return match($toolId){
            'time.entries.search'=>$this->entries($companyId,$input),
            'time.submissions.queue'=>$this->submissionQueue($companyId,$input),
            'time.submissions.inspect'=>$this->submission($companyId,$input),
            'time.costing.preview'=>$this->costing($input),
            'attendance.exceptions.search'=>$this->verifications($companyId,$input,true),
            'attendance.verifications.search'=>$this->verifications($companyId,$input,false),
            'attendance.policy.inspect'=>TimePolicy::query()->forCompany($companyId)->first(),
            'attendance.offline.inspect'=>$this->offline($companyId,$input),
            'time.timers.active'=>$this->activeTimers($companyId,$input),
            'time.attention.search'=>$this->attention($companyId,$input),
            'time.workflows.inspect'=>$this->workflows($companyId,$input),
            default=>throw new InvalidArgumentException("Unknown Titan Time & Attendance read tool: {$toolId}"),
        };
    }

    private function entries(int $companyId,array $input): mixed
    {
        $query=TimeEntry::query()->forCompany($companyId)->latest('work_date')->latest('id');
        if(isset($input['user_id']))$query->where('user_id',(int)$input['user_id']);
        if(isset($input['work_order_id']))$query->where('work_order_id',(int)$input['work_order_id']);
        if(isset($input['work_order_public_id']))$query->where('work_order_public_id',(string)$input['work_order_public_id']);
        if(isset($input['date_from']))$query->whereDate('work_date','>=',(string)$input['date_from']);
        if(isset($input['date_to']))$query->whereDate('work_date','<=',(string)$input['date_to']);
        return $query->limit($this->limit($input))->get();
    }

    private function submissionQueue(int $companyId,array $input): mixed
    {
        return TimeSubmission::query()->forCompany($companyId)->where('status',(string)($input['status']??'submitted'))->oldest('submitted_at')->limit($this->limit($input))->get();
    }

    private function submission(int $companyId,array $input): mixed
    {
        $id=(int)($input['submission_id']??0);if($id<=0)throw new InvalidArgumentException('submission_id is required.');
        return TimeSubmission::query()->forCompany($companyId)->whereKey($id)->firstOrFail();
    }

    private function costing(array $input): array
    {
        $minutes=(int)($input['minutes']??0);$rate=(float)($input['rate_per_hour']??0);$multiplier=(float)($input['multiplier']??1.0);
        return ['minutes'=>$minutes,'rate_per_hour'=>$rate,'multiplier'=>$multiplier,'cost_total'=>TimeMath::cost($minutes,$rate,$multiplier)];
    }

    private function verifications(int $companyId,array $input,bool $exceptionsOnly): mixed
    {
        $query=AttendanceVerificationLog::query()->forCompany($companyId)->latest('id');if($exceptionsOnly)$query->where('verified',false);
        if(isset($input['user_id']))$query->where('user_id',(int)$input['user_id']);if(isset($input['site_id']))$query->where('site_id',(int)$input['site_id']);
        if(isset($input['service_location_public_id']))$query->where('service_location_public_id',(string)$input['service_location_public_id']);if(isset($input['method']))$query->where('method',(string)$input['method']);
        return $query->limit($this->limit($input))->get();
    }

    private function offline(int $companyId,array $input): mixed
    {
        $query=OfflineAttendanceEvent::query()->forCompany($companyId)->latest('device_recorded_at');if(isset($input['user_id']))$query->where('user_id',(int)$input['user_id']);
        if(isset($input['sync_status']))$query->where('sync_status',(string)$input['sync_status']);if(isset($input['reconciliation_status']))$query->where('reconciliation_status',(string)$input['reconciliation_status']);
        return $query->limit($this->limit($input))->get();
    }

    private function activeTimers(int $companyId,array $input): mixed
    {
        $query=TimeTimer::query()->forCompany($companyId)->where('status','running')->oldest('started_at');if(isset($input['user_id']))$query->where('user_id',(int)$input['user_id']);
        if(isset($input['work_order_public_id']))$query->where('work_order_public_id',(string)$input['work_order_public_id']);return $query->limit($this->limit($input))->get();
    }

    private function attention(int $companyId,array $input): mixed
    {
        $query=TimeAttentionFinding::query()->forCompany($companyId)->latest('detected_at');
        if(isset($input['status']))$query->where('status',(string)$input['status']);if(isset($input['severity']))$query->where('severity',(string)$input['severity']);if(isset($input['assigned_role']))$query->where('assigned_role',(string)$input['assigned_role']);if(isset($input['user_id']))$query->where('user_id',(int)$input['user_id']);
        return $query->limit($this->limit($input))->get();
    }

    private function workflows(int $companyId,array $input): mixed
    {
        $query=TimeWorkflowRun::query()->forCompany($companyId)->latest('id');if(isset($input['status']))$query->where('status',(string)$input['status']);if(isset($input['assigned_role']))$query->where('assigned_role',(string)$input['assigned_role']);if(isset($input['workflow_id']))$query->where('workflow_id',(string)$input['workflow_id']);
        return $query->limit($this->limit($input))->get();
    }

    private function limit(array $input): int{return max(1,min(100,(int)($input['limit']??50)));}
}
