<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Governance;

use App\Extensions\TitanTimeAttendance\System\Models\TimeSignalOutbox;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

final class TimeSignalOutboxDispatcher
{
    public function __construct(
        private readonly TimeSignalDeliveryPort $delivery,
        private readonly SignalDeliveryPolicy $policy,
    ) {}

    public function deliverTenant(int $companyId, int $limit = 100): array
    {
        if ($companyId <= 0) throw new \InvalidArgumentException('A resolved company_id is required.');

        $selected = 0;
        $delivered = 0;
        $failed = 0;
        $deadLettered = 0;
        $limit = max(1, min(500, $limit));

        while ($selected < $limit) {
            $item = $this->claimNext($companyId);
            if ($item === null) break;
            $selected++;
            $claimToken = (string) $item->claim_token;

            try {
                $this->delivery->deliver([
                    'event_id' => $item->event_id,
                    'event_type' => $item->event_type,
                    'dedup_key' => $item->dedup_key,
                    'company_id' => (int) $item->company_id,
                    'payload' => $item->payload ?? [],
                    'trace_id' => $item->trace_id,
                    'correlation_id' => $item->correlation_id,
                    'causation_id' => $item->causation_id,
                    'source_extension' => 'titan-time-attendance',
                    'schema_version' => '1.0',
                    'occurred_at' => $item->created_at?->toIso8601String(),
                ]);

                if ($this->finalizeDelivered((int) $item->getKey(), $claimToken)) $delivered++;
            } catch (Throwable $exception) {
                $attempts = (int) $item->attempts;
                $dead = $this->policy->shouldDeadLetter($attempts);
                if ($this->finalizeFailure((int) $item->getKey(), $claimToken, $attempts, $dead, $exception)) {
                    $failed++;
                    if ($dead) $deadLettered++;
                }
            }
        }

        return [
            'company_id' => $companyId,
            'selected' => $selected,
            'delivered' => $delivered,
            'failed' => $failed,
            'dead_lettered' => $deadLettered,
        ];
    }

    private function claimNext(int $companyId): ?TimeSignalOutbox
    {
        return DB::transaction(function () use ($companyId): ?TimeSignalOutbox {
            $now = now();
            $item = TimeSignalOutbox::query()
                ->forCompany($companyId)
                ->where(function ($query) use ($now): void {
                    $query->where(function ($pending) use ($now): void {
                        $pending->where('status', 'pending')
                            ->where(function ($available) use ($now): void {
                                $available->whereNull('available_at')->orWhere('available_at', '<=', $now);
                            });
                    })->orWhere(function ($stale) use ($now): void {
                        $stale->where('status', 'delivering')->whereNotNull('lease_expires_at')->where('lease_expires_at', '<=', $now);
                    });
                })
                ->oldest('id')
                ->lockForUpdate()
                ->first();

            if (! $item) return null;

            $claimToken = (string) Str::uuid();
            $item->forceFill([
                'status' => 'delivering',
                'claim_token' => $claimToken,
                'claimed_at' => $now,
                'lease_expires_at' => $now->copy()->addSeconds($this->policy->leaseSeconds()),
                'attempts' => (int) $item->attempts + 1,
                'last_error' => null,
            ])->save();

            return $item->refresh();
        }, 3);
    }

    private function finalizeDelivered(int $id, string $claimToken): bool
    {
        return TimeSignalOutbox::query()
            ->whereKey($id)
            ->where('status', 'delivering')
            ->where('claim_token', $claimToken)
            ->update([
                'status' => 'delivered',
                'delivered_at' => now(),
                'claim_token' => null,
                'claimed_at' => null,
                'lease_expires_at' => null,
                'available_at' => null,
                'last_error' => null,
                'updated_at' => now(),
            ]) === 1;
    }

    private function finalizeFailure(int $id, string $claimToken, int $attempts, bool $dead, Throwable $exception): bool
    {
        $now = now();
        return TimeSignalOutbox::query()
            ->whereKey($id)
            ->where('status', 'delivering')
            ->where('claim_token', $claimToken)
            ->update([
                'status' => $dead ? 'dead_letter' : 'pending',
                'dead_lettered_at' => $dead ? $now : null,
                'available_at' => $dead ? null : $now->copy()->addSeconds($this->policy->retryDelaySeconds($attempts)),
                'claim_token' => null,
                'claimed_at' => null,
                'lease_expires_at' => null,
                'last_error' => $this->policy->safeError($exception),
                'updated_at' => $now,
            ]) === 1;
    }
}
