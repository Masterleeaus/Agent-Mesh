<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Decision;
use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceExecutionContext;
final class TimeWorkforceDecisionGate
{
    private const RANK=['LOW'=>1,'MEDIUM'=>2,'HIGH'=>3,'CRITICAL'=>4];
    public function __construct(private readonly TimeRiskPort $risk,private readonly TimeAssurancePort $assurance,private readonly TimeAutonomyPort $autonomy){}
    /** @return array{status:string,dispatch:bool,reason:?string,requires_human_approval:bool,risk:string,risk_ceiling:string} */
    public function evaluate(string $capability,array $definition,TimeWorkforceExecutionContext $context,array $input=[]): array
    {
        $risk=strtoupper((string)($definition['risk']??'MEDIUM'));$ceiling=strtoupper($context->riskCeiling);
        $base=['requires_human_approval'=>(bool)($definition['human_approval']??false),'risk'=>$risk,'risk_ceiling'=>$ceiling];
        if((self::RANK[$risk]??99)>(self::RANK[$ceiling]??0))return $base+['status'=>'blocked','dispatch'=>false,'reason'=>'role_risk_ceiling_exceeded'];
        if(in_array($context->autonomyLevel,['Suggest','Assist'],true))return $base+['status'=>'prepared','dispatch'=>false,'reason'=>'autonomy_is_advisory'];
        if(in_array($risk,['HIGH','CRITICAL'],true)){
            if(!$this->risk->available())return $base+['status'=>'blocked_dependency','dispatch'=>false,'reason'=>'titan_risk_required'];
            $decision=$this->risk->evaluate($capability,$risk,$context,$input);if(!($decision['allowed']??false))return $base+['status'=>'blocked','dispatch'=>false,'reason'=>$decision['reason']??'risk_blocked'];
            if(!$this->assurance->available())return $base+['status'=>'blocked_dependency','dispatch'=>false,'reason'=>'titan_assurance_required'];
            $assurance=$this->assurance->evaluate($capability,$risk,$context,$input);if(!($assurance['allowed']??false))return $base+['status'=>'blocked','dispatch'=>false,'reason'=>$assurance['reason']??'assurance_blocked'];
        }
        if((bool)($definition['human_approval']??false))return $base+['status'=>'pending_approval','dispatch'=>true,'reason'=>'human_approval_required'];
        if(!$this->autonomy->allows($context->autonomyLevel,$risk,$capability))return $base+['status'=>'prepared','dispatch'=>false,'reason'=>'autonomy_below_execution_threshold'];
        return $base+['status'=>'execute','dispatch'=>true,'reason'=>null];
    }
}
