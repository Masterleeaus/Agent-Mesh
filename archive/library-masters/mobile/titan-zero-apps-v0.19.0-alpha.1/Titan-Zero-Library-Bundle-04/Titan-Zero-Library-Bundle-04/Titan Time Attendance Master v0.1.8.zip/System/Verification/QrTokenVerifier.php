<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Verification;

use DateTimeImmutable;

final class QrTokenVerifier
{
    public function verify(string $token,string $expectedHash,?DateTimeImmutable $validFrom,?DateTimeImmutable $validUntil,?DateTimeImmutable $now=null): array
    {
        $now ??= new DateTimeImmutable('now');
        if ($validFrom && $now < $validFrom) return ['verified'=>false,'reason_code'=>'qr_not_yet_valid'];
        if ($validUntil && $now > $validUntil) return ['verified'=>false,'reason_code'=>'qr_expired'];
        $ok=$token!=='' && hash_equals(strtolower($expectedHash),hash('sha256',$token));
        return ['verified'=>$ok,'reason_code'=>$ok?null:'qr_invalid'];
    }
}
