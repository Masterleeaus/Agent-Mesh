<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Http\Controllers;
use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;use App\Http\Controllers\Controller;use Illuminate\Http\JsonResponse;use Illuminate\Http\Request;
final class TimerController extends Controller
{
 public function start(Request $request,TimeCommandBusGateway $gateway): JsonResponse
 {
  $d=$request->validate(['work_order_id'=>'nullable|integer|min:1','work_order_public_id'=>'nullable|string|size:26','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid']);
  $r=$gateway->request('time.timer.start',$d,$request->user());return response()->json(['data'=>$r],($r['executed']??false)?201:202);
 }
 public function stop(Request $request,int $timer,TimeCommandBusGateway $gateway): JsonResponse
 {
  $d=$request->validate(['notes'=>'nullable|string|max:5000','type'=>'nullable|string|max:40','rate_per_hour'=>'nullable|numeric|min:0','overtime_multiplier'=>'nullable|numeric|min:0|max:10','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid']);$d['timer_id']=$timer;
  $r=$gateway->request('time.timer.stop',$d,$request->user());return response()->json(['data'=>$r],($r['executed']??false)?200:202);
 }
}
