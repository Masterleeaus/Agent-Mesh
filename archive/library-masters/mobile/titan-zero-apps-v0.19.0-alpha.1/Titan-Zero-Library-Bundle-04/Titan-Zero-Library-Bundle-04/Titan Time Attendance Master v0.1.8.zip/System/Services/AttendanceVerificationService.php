<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Services;

use App\Extensions\TitanTimeAttendance\System\Models\{AttendanceVerificationLog,TimeGeofence,TimeIpRule,TimeQrCredential};
use App\Extensions\TitanTimeAttendance\System\Verification\{GeofenceVerifier,IpAddressVerifier,QrTokenVerifier};
use DateTimeImmutable;
use Illuminate\Validation\ValidationException;

final class AttendanceVerificationService
{
    public function __construct(
        private readonly GeofenceVerifier $geofence,
        private readonly IpAddressVerifier $ip,
        private readonly QrTokenVerifier $qr,
        private readonly SignalOutboxService $signals,
    ) {}

    public function verify(int $companyId,int $userId,string $method,array $evidence): AttendanceVerificationLog
    {
        $result=match($method){
            'geofence'=>$this->verifyGeofence($companyId,$evidence),
            'dynamic_qr','static_qr'=>$this->verifyQr($companyId,$method,$evidence),
            'ip_address'=>$this->verifyIp($companyId,$evidence),
            'site'=>['verified'=>false,'reason_code'=>'site_requires_strategy'],
            default=>throw ValidationException::withMessages(['method'=>'Unsupported attendance verification method.']),
        };
        $summary=$this->minimiseEvidence($companyId,$method,$evidence,$result);
        $log=AttendanceVerificationLog::query()->create([
            'company_id'=>$companyId,'user_id'=>$userId,'site_id'=>isset($evidence['site_id'])?(int)$evidence['site_id']:null,
            'service_location_public_id'=>$evidence['service_location_public_id']??null,'method'=>$method,'verified'=>(bool)$result['verified'],'reason_code'=>$result['reason_code']??null,
            'evidence_summary'=>$summary,'evidence_hash'=>hash('sha256',json_encode($summary,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
            'created_by_user_id'=>$userId,'trace_id'=>$evidence['trace_id']??null,'correlation_id'=>$evidence['correlation_id']??null,'causation_id'=>$evidence['causation_id']??null,
        ]);
        $this->signals->record($companyId,$log->verified?'attendance.verification.succeeded':'attendance.verification.failed',[
            'verification_id'=>$log->getKey(),'user_id'=>$userId,'method'=>$method,'site_id'=>$log->site_id,'service_location_public_id'=>$log->service_location_public_id,'reason_code'=>$log->reason_code,
        ],$evidence+['dedup_key'=>isset($evidence['dedup_key'])?$evidence['dedup_key'].':attendance-verification':null]);
        return $log;
    }

    private function verifyGeofence(int $companyId,array $evidence): array
    {
        $id=(int)($evidence['geofence_id']??0);
        $fence=TimeGeofence::query()->forCompany($companyId)->whereKey($id)->where('active',true)->first();
        if(!$fence)return ['verified'=>false,'reason_code'=>'geofence_unavailable'];
        if(isset($evidence['site_id'])&&$fence->site_id!==null&&(int)$fence->site_id!==(int)$evidence['site_id'])return ['verified'=>false,'reason_code'=>'site_evidence_mismatch'];
        if(isset($evidence['service_location_public_id'])&&(string)$fence->service_location_public_id!==(string)$evidence['service_location_public_id'])return ['verified'=>false,'reason_code'=>'service_location_evidence_mismatch'];
        return $this->geofence->verify((float)($evidence['latitude']??999),(float)($evidence['longitude']??999),(float)$fence->latitude,(float)$fence->longitude,(int)$fence->radius_metres);
    }

    private function verifyQr(int $companyId,string $mode,array $evidence): array
    {
        $id=(int)($evidence['credential_id']??0);
        $credential=TimeQrCredential::query()->forCompany($companyId)->whereKey($id)->where('mode',$mode==='dynamic_qr'?'dynamic':'static')->where('active',true)->first();
        if(!$credential)return ['verified'=>false,'reason_code'=>'qr_unavailable'];
        if(isset($evidence['site_id'])&&$credential->site_id!==null&&(int)$credential->site_id!==(int)$evidence['site_id'])return ['verified'=>false,'reason_code'=>'site_evidence_mismatch'];
        if(isset($evidence['service_location_public_id'])&&(string)$credential->service_location_public_id!==(string)$evidence['service_location_public_id'])return ['verified'=>false,'reason_code'=>'service_location_evidence_mismatch'];
        return $this->qr->verify((string)($evidence['token']??''),(string)$credential->token_hash,$credential->valid_from?new DateTimeImmutable($credential->valid_from->toIso8601String()):null,$credential->valid_until?new DateTimeImmutable($credential->valid_until->toIso8601String()):null);
    }

    private function verifyIp(int $companyId,array $evidence): array
    {
        $observedIp=(string)($evidence['ip_address']??'');$siteId=isset($evidence['site_id'])?(int)$evidence['site_id']:null;$location=trim((string)($evidence['service_location_public_id']??''));
        $query=TimeIpRule::query()->forCompany($companyId)->where('active',true);
        if($location!=='')$query->where(function($q)use($location):void{$q->where('service_location_public_id',$location)->orWhereNull('service_location_public_id');});
        elseif($siteId!==null)$query->where(function($q)use($siteId):void{$q->where('site_id',$siteId)->orWhereNull('site_id');});
        else $query->whereNull('site_id')->whereNull('service_location_public_id');
        $trustedIps=$query->pluck('ip_address')->all();if($trustedIps===[])return ['verified'=>false,'reason_code'=>'ip_policy_unavailable'];
        return $this->ip->verify($observedIp,$trustedIps);
    }

    private function minimiseEvidence(int $companyId,string $method,array $evidence,array $result): array
    {
        $summary=['method'=>$method,'verified'=>(bool)$result['verified'],'reason_code'=>$result['reason_code']??null];
        foreach(['site_id','geofence_id','credential_id'] as $key)if(isset($evidence[$key]))$summary[$key]=(int)$evidence[$key];
        if(isset($evidence['service_location_public_id']))$summary['service_location_public_id']=(string)$evidence['service_location_public_id'];
        if(isset($result['distance_metres']))$summary['distance_metres']=(int)$result['distance_metres'];
        if($method==='ip_address'&&isset($evidence['ip_address'])){
            $summary['ip_hash']=hash_hmac('sha256',(string)$evidence['ip_address'],$this->tenantHashKey($companyId));
        }
        return $summary;
    }

    private function tenantHashKey(int $companyId): string
    {
        $appKey = trim((string) config('app.key', ''));
        if ($appKey === '') {
            throw new \RuntimeException('Titan Time & Attendance requires a configured APP_KEY for privacy hashing.');
        }

        return $appKey . '|tenant:' . $companyId;
    }
}
