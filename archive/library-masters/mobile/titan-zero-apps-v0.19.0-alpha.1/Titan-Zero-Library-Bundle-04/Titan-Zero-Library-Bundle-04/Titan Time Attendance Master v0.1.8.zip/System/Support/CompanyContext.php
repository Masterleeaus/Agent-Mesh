<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Support;

use RuntimeException;

final class CompanyContext
{
    private const CRM_SCOPE = 'App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope';

    public static function id(object $user): int
    {
        $value = (int) self::attribute($user, 'company_id');
        if ($value > 0) {
            return $value;
        }

        // CRM is the canonical business/tenant authority when installed. Resolve through
        // its public tenancy boundary without importing CRM persistence or requiring CRM.
        if (class_exists(self::CRM_SCOPE) && function_exists('app') && app()->bound(self::CRM_SCOPE)) {
            $actorId = (int) (method_exists($user, 'getKey') ? $user->getKey() : ($user->id ?? 0));
            /** @var class-string $scope */
            $scope = self::CRM_SCOPE;
            $resolved = (int) $scope::companyId($actorId > 0 ? $actorId : null);
            if ($resolved > 0) {
                return $resolved;
            }
        }

        throw new RuntimeException('Titan Time & Attendance requires canonical company_id on the authorised actor context.');
    }

    public static function assertMatches(int $companyId, object $user): void
    {
        if ($companyId < 1 || $companyId !== self::id($user)) {
            throw new RuntimeException('Titan Time & Attendance tenant boundary mismatch.');
        }
    }

    private static function attribute(object $user, string $key): mixed
    {
        return method_exists($user, 'getAttribute') ? $user->getAttribute($key) : ($user->{$key} ?? null);
    }
}
