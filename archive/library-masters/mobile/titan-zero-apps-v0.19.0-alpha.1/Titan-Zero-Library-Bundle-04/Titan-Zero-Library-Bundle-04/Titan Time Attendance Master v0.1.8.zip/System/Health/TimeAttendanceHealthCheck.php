<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Health;

use App\Extensions\TitanTimeAttendance\System\Governance\{TimeCommandBusPort,TimeSignalDeliveryPort};
use App\Extensions\TitanTimeAttendance\System\Integrations\Crm\CrmWorkAuthorityPort;
use App\Extensions\TitanTimeAttendance\System\Integrations\Rewind\TimeRewindIntegration;
use App\Extensions\TitanTimeAttendance\System\Installer\PackageIntegrityVerifier;
use App\Extensions\TitanTimeAttendance\System\Models\TimeSignalOutbox;
use App\Extensions\TitanTimeAttendance\System\Workforce\Decision\{TimeAssurancePort,TimeRiskPort};
use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceManifestValidator;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class TimeAttendanceHealthCheck
{
    private const TABLES = [
        'ext_titan_time_entries','ext_titan_time_timers','ext_titan_time_submissions','ext_titan_time_submission_items','ext_titan_time_policies',
        'ext_titan_time_geofences','ext_titan_time_qr_credentials','ext_titan_time_ip_rules','ext_titan_time_verification_logs','ext_titan_time_offline_events',
        'ext_titan_time_signal_outbox','ext_titan_time_command_receipts','ext_titan_time_attention_findings','ext_titan_time_workflow_runs',
    ];

    public function __construct(
        private readonly TimeCommandBusPort $commandBus,
        private readonly TimeSignalDeliveryPort $signals,
        private readonly CrmWorkAuthorityPort $crm,
        private readonly TimeRiskPort $risk,
        private readonly TimeAssurancePort $assurance,
        private readonly TimeRewindIntegration $rewind,
        private readonly PackageIntegrityVerifier $integrity,
    ) {}

    public function check(): array
    {
        $missing = [];
        foreach (self::TABLES as $table) if (! Schema::hasTable($table)) $missing[] = $table;
        $integrity=$this->integrity->verify(dirname(__DIR__,2));
        $checks = [
            'enabled' => (bool) config('titan-time-attendance.enabled', true),
            'database' => $missing === [],
            'package_integrity' => $integrity['ok'],
            'workforce_manifest' => $this->workforceManifest(__DIR__ . '/../../resources/workforce/workforce-manifest.json'),
            'wizard_manifest' => $this->jsonFile(__DIR__ . '/../../resources/workforce/wizards.json'),
            'surface_manifest' => $this->jsonFile(__DIR__ . '/../../resources/surfaces/surfaces.json'),
            'extension_manifest' => $this->jsonFile(__DIR__ . '/../../extension.manifest.json'),
            'signal_delivery' => $this->signals->available(),
        ];
        $signalDeadLetters = 0;
        $signalStaleLeases = 0;
        if (($checks['database'] ?? false) && Schema::hasColumn('ext_titan_time_signal_outbox', 'lease_expires_at')) {
            $signalDeadLetters = TimeSignalOutbox::query()->where('status', 'dead_letter')->count();
            $signalStaleLeases = TimeSignalOutbox::query()->where('status', 'delivering')->whereNotNull('lease_expires_at')->where('lease_expires_at', '<=', now())->count();
        }
        return [
            'ok' => ! in_array(false, $checks, true),
            'checks' => $checks,
            'diagnostics' => [
                'signal_dead_letters' => $signalDeadLetters,
                'signal_stale_leases' => $signalStaleLeases,
            ],
            'optional_integrations' => [
                'command_bus' => $this->commandBus->available(),
                'crm_authority' => $this->crm->available(),
                'risk' => $this->risk->available(),
                'assurance' => $this->assurance->available(),
                'rewind_source_adapter' => $this->rewind->available(),
            ],
            'missing_tables' => $missing,
            'integrity_errors' => $integrity['errors'],
        ];
    }

    private function jsonFile(string $path): bool
    {
        if (! is_file($path)) return false;
        try { return is_array(json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR)); }
        catch (Throwable) { return false; }
    }

    private function workforceManifest(string $path): bool
    {
        if (! is_file($path)) return false;
        try {
            $manifest = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            if (! is_array($manifest)) return false;
            TimeWorkforceManifestValidator::assertValid($manifest);
            return true;
        } catch (Throwable) {
            return false;
        }
    }
}
