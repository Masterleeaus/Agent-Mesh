<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Decision;
use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceExecutionContext;
interface TimeRiskPort
{
    public function available(): bool;
    /** @return array{allowed:bool,reason:?string} */
    public function evaluate(string $capability,string $riskClass,TimeWorkforceExecutionContext $context,array $input): array;
}
