<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Decision;
use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceExecutionContext;
final class DeferredTimeRiskPort implements TimeRiskPort
{
    public function available(): bool{return false;}
    public function evaluate(string $capability,string $riskClass,TimeWorkforceExecutionContext $context,array $input): array{return ['allowed'=>false,'reason'=>'titan_risk_unavailable'];}
}
