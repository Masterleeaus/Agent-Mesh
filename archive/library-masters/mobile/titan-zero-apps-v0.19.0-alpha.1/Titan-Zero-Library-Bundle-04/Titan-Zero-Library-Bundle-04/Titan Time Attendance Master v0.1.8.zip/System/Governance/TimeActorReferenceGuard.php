<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Governance;

use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class TimeActorReferenceGuard
{
    public function __construct(private ConnectionInterface $db) {}
    public function assertUserBelongsToCompany(int $companyId,int $userId): void
    {
        if($companyId<1||$userId<1)throw new InvalidArgumentException('company_id and user_id must be positive.');
        try{$s=$this->db->getSchemaBuilder();$valid=$s->hasTable('users')&&$s->hasColumn('users','company_id')&&$this->db->table('users')->where('id',$userId)->where('company_id',$companyId)->exists();}
        catch(\Throwable){$valid=false;}
        if(!$valid)throw new InvalidArgumentException('Referenced time-entry user does not belong to company_id.');
    }
}
