<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Exports;

use App\Extensions\TitanTimeAttendance\System\Support\CapabilityCatalog;

final class TimePlatformExportRegistry
{
    /** @return array<string,array<string,mixed>> */
    public function all(): array{return ['governance'=>$this->governance(),'wisdom'=>$this->wisdom(),'vertical'=>$this->vertical()];}

    /** @return array<string,mixed> */
    public function governance(): array
    {
        $capabilities=[];
        foreach(CapabilityCatalog::definitions() as $id=>$definition){
            $capabilities[$id]=[
                'mode'=>$definition['mode'],'permission'=>$definition['permission'],'risk'=>$definition['risk'],
                'human_approval'=>(bool)$definition['human_approval'],'idempotent'=>(bool)$definition['idempotent'],
                'command_bus_required'=>($definition['mode']??'read')==='write',
            ];
        }
        return ['schema_version'=>1,'source_extension'=>'titan-time-attendance','tenant_key'=>'company_id','capabilities'=>$capabilities];
    }

    /** @return array<string,mixed> */
    public function wisdom(): array
    {
        return [
            'schema_version'=>1,'source_extension'=>'titan-time-attendance','tenant_key'=>'company_id',
            'observable_signals'=>[
                'time.entry.created','time.timer.started','time.timer.stopped','time.submission.submitted','time.submission.ready_for_review','time.submission.reviewed',
                'attendance.verification.succeeded','attendance.verification.failed','attendance.offline.synced','attendance.offline.rejected','time.policy.updated','time.command.executed',
            ],
            'outcome_dimensions'=>['accepted','corrected','rejected','reversed','late','duplicate','verification_failed','offline_reconciled'],
            'privacy'=>['raw_location'=>false,'raw_qr_token'=>false,'raw_ip_address'=>false,'tenant_data_training_default'=>false],
        ];
    }

    /** @return array<string,mixed> */
    public function vertical(): array
    {
        return [
            'schema_version'=>1,'source_extension'=>'titan-time-attendance','tenant_key'=>'company_id',
            'capabilities'=>array_keys(CapabilityCatalog::definitions()),
            'verification_methods'=>['geofence','dynamic_qr','static_qr','ip_address'],
            'policy_overlays'=>['week_starts_on','timer_enabled','approvals_enabled','costing_enabled','verification_method','geofence_radius_metres','store_raw_location'],
            'workforce_manifest'=>'resources/workforce/workforce-manifest.json','wizards'=>'resources/workforce/wizards.json','surfaces'=>'resources/surfaces/surfaces.json',
        ];
    }
}
