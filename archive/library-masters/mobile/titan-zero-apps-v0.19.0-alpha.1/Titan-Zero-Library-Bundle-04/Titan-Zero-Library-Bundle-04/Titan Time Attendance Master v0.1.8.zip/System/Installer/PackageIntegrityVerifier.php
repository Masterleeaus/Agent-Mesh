<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Installer;

use FilesystemIterator;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use Throwable;

final class PackageIntegrityVerifier
{
    /** @return array{ok:bool,errors:array<int,string>} */
    public function verify(?string $root = null): array
    {
        $root = $root ?: dirname(__DIR__, 2);
        $errors = [];
        $extension = $this->json($root.'/extension.json', $errors);
        $inventory = $this->json($root.'/FILE-SHA256.json', $errors);
        $all = $this->files($root);

        // FILE-SHA256 intentionally excludes both control files to avoid a recursive hash cycle.
        $expectedInventory = $all;
        unset($expectedInventory['FILE-SHA256.json'], $expectedInventory['extension.json']);

        // Titan Extension Manager 1.7.8 expects integrity.files to hash every packaged file except extension.json.
        $expectedIntegrity = $all;
        unset($expectedIntegrity['extension.json']);

        $inventoryFiles = is_array($inventory['files'] ?? null) ? $inventory['files'] : [];
        $integrity = is_array($extension['integrity']['files'] ?? null) ? $extension['integrity']['files'] : [];

        if (array_diff_key($expectedInventory, $inventoryFiles) || array_diff_key($inventoryFiles, $expectedInventory)) {
            $errors[] = 'FILE-SHA256.json file-set drift';
        }
        if (array_diff_key($expectedIntegrity, $integrity) || array_diff_key($integrity, $expectedIntegrity)) {
            $errors[] = 'extension.json integrity.files file-set drift';
        }

        $this->checkHashes($root, $inventoryFiles, $errors, 'inventory', true);
        $this->checkHashes($root, $integrity, $errors, 'integrity', false);

        return ['ok' => $errors === [], 'errors' => array_values(array_unique($errors))];
    }

    private function json(string $path, array &$errors): array
    {
        if (! is_file($path)) { $errors[] = 'missing '.basename($path); return []; }
        try {
            $value = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            return is_array($value) ? $value : [];
        } catch (Throwable) {
            $errors[] = 'invalid '.basename($path);
            return [];
        }
    }

    /** @return array<string,bool> */
    private function files(string $root): array
    {
        $files = [];
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $file) {
            if (! $file->isFile()) continue;
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            $files[$relative] = true;
        }
        return $files;
    }

    private function checkHashes(string $root, array $hashes, array &$errors, string $label, bool $prefixed): void
    {
        foreach ($hashes as $relative => $expected) {
            $path = $root.'/'.$relative;
            if (! is_file($path)) { $errors[] = "{$label} file missing: {$relative}"; continue; }
            $digest = hash_file('sha256', $path);
            $actual = $prefixed ? 'sha256:'.$digest : $digest;
            if (! is_string($expected) || ! hash_equals($expected, $actual)) $errors[] = "{$label} mismatch: {$relative}";
        }
    }
}
