<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

final class AttendanceVerificationLog extends Model
{
    protected $table = 'ext_titan_time_verification_logs';
    protected $fillable = ['company_id','user_id','site_id','service_location_public_id','method','verified','reason_code','evidence_summary','evidence_hash','created_by_user_id','trace_id','correlation_id','causation_id'];
    protected $casts = ['verified'=>'boolean','evidence_summary'=>'array'];
    public function scopeForCompany(Builder $query,int $companyId): Builder { return $query->where('company_id',$companyId); }
}
