<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeTimer extends Model
{
 protected $table='ext_titan_time_timers';
 protected $fillable=['company_id','user_id','work_order_id','work_order_public_id','started_at','stopped_at','elapsed_minutes','status','source','trace_id'];
 protected $casts=['started_at'=>'datetime','stopped_at'=>'datetime','elapsed_minutes'=>'integer'];
 public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
