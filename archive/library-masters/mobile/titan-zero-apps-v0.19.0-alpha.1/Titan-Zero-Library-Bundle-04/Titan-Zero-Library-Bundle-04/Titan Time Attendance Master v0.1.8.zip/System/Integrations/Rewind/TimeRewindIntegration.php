<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Rewind;

use Illuminate\Contracts\Container\Container;
use Throwable;

final class TimeRewindIntegration
{
    private const MANAGER_CONTRACT='App\\Extensions\\TitanRewind\\System\\Contracts\\RewindManagerContract';
    private const SOURCE_CONTRACT='App\\Extensions\\TitanRewind\\System\\Contracts\\RewindSourceAdapterContract';
    private const EVENT_RECORD='App\\Extensions\\TitanRewind\\System\\Reconstruction\\RewindEventRecord';
    private const TRACE_QUERY='App\\Extensions\\TitanRewind\\System\\Reconstruction\\RewindTraceQuery';
    private bool $registered=false;

    public function __construct(private readonly Container $app,private readonly TimeRewindRecordProjector $projector){}

    public function available(): bool
    {
        return interface_exists(self::MANAGER_CONTRACT) && interface_exists(self::SOURCE_CONTRACT) && class_exists(self::EVENT_RECORD) && class_exists(self::TRACE_QUERY) && $this->app->bound(self::MANAGER_CONTRACT);
    }

    public function registerIfAvailable(): bool
    {
        if($this->registered)return true;
        if(!$this->available())return false;
        $projector=$this->projector;
        $adapter=new class($projector) implements \App\Extensions\TitanRewind\System\Contracts\RewindSourceAdapterContract {
            public function __construct(private readonly TimeRewindRecordProjector $projector){}
            public function key(): string{return 'titan-time-attendance';}
            public function records(\App\Extensions\TitanRewind\System\Reconstruction\RewindTraceQuery $query): iterable
            {
                foreach($this->projector->records($query->companyId(),$query->traceId()) as $row){
                    yield \App\Extensions\TitanRewind\System\Reconstruction\RewindEventRecord::fromArray($row);
                }
            }
        };
        try{
            $manager=$this->app->make(self::MANAGER_CONTRACT);
            if(!method_exists($manager,'registerSourceAdapter'))return false;
            $manager->registerSourceAdapter($adapter);
            $this->registered=true;
            return true;
        }catch(Throwable){return false;}
    }
}
