<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce\Workflows;
final class TimeWorkflowRegistry
{
    public function definitions(): array{return [
        'attendance.verification.failed'=>['workflow_id'=>'attendance.exception-triage','assigned_role'=>'attendance-exception-specialist','priority'=>'high'],
        'time.timer.overdue'=>['workflow_id'=>'presence.overdue-timer','assigned_role'=>'workforce-presence-agent','priority'=>'medium'],
        'time.submission.ready_for_review'=>['workflow_id'=>'timesheet.weekly-review','assigned_role'=>'timesheet-auditor','priority'=>'high'],
        'attendance.offline.rejected'=>['workflow_id'=>'attendance.offline-recovery','assigned_role'=>'attendance-exception-specialist','priority'=>'high'],
    ];}
    public function forSignal(string $eventType): ?array{return $this->definitions()[$eventType]??null;}
}
