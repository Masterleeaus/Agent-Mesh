<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce;

use RuntimeException;

final class TimeAttendanceWorkforceManifest
{
    private ?array $cache = null;
    public function all(): array
    {
        if ($this->cache !== null) return $this->cache;
        $path = dirname(__DIR__, 2) . '/resources/workforce/workforce-manifest.json';
        $json = @file_get_contents($path);
        if ($json === false) throw new RuntimeException('Titan Time & Attendance workforce manifest is unavailable.');
        $manifest=json_decode($json,true,512,JSON_THROW_ON_ERROR);
        TimeWorkforceManifestValidator::assertValid($manifest);
        return $this->cache=$manifest;
    }
}
