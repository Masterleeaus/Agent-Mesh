<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Installer;

use App\Extensions\TitanTimeAttendance\System\Workforce\TimeWorkforceManifestValidator;
use Throwable;

final class TimeAttendancePreflight
{
    // Titan Extension Manager 1.7.8 contract: canonical installer identity + integrity.files. Config publishing is owned by the Laravel service provider, not extension.json.
    public function __construct(private readonly PackageIntegrityVerifier $integrity) {}

    public function check(): array
    {
        $root = dirname(__DIR__, 2);
        $integrity = $this->integrity->verify($root);
        $checks = [
            'php' => ['ok' => version_compare(PHP_VERSION, '8.2.0', '>='), 'actual' => PHP_VERSION, 'required' => '>=8.2'],
            'json' => ['ok' => extension_loaded('json')],
            'pdo' => ['ok' => extension_loaded('pdo')],
            'mbstring' => ['ok' => extension_loaded('mbstring')],
            'app_key' => ['ok' => trim((string) config('app.key', '')) !== ''],
            'package_integrity' => ['ok' => $integrity['ok'], 'errors' => $integrity['errors']],
            'installer_1_7_8_manifest' => ['ok' => $this->validInstallerManifest($root.'/extension.json')],
            'extension_manifest' => ['ok' => $this->validJson($root.'/extension.manifest.json')],
            'workforce_manifest' => ['ok' => $this->validWorkforceManifest($root.'/resources/workforce/workforce-manifest.json')],
            'wizard_manifest' => ['ok' => $this->validJson($root.'/resources/workforce/wizards.json')],
            'surface_manifest' => ['ok' => $this->validJson($root.'/resources/surfaces/surfaces.json')],
            'governance_migration' => ['ok' => is_file($root.'/database/migrations/2026_08_15_000005_add_ext_titan_time_governance.php')],
            'attention_migration' => ['ok' => is_file($root.'/database/migrations/2026_08_15_000006_add_ext_titan_time_attention.php')],
            'workflow_migration' => ['ok' => is_file($root.'/database/migrations/2026_08_15_000007_add_ext_titan_time_workflow_runs.php')],
            'signal_delivery_migration' => ['ok' => is_file($root.'/database/migrations/2026_08_15_000008_harden_ext_titan_time_signal_delivery.php')],
            'provider' => ['ok' => is_file($root.'/System/TitanTimeAttendanceServiceProvider.php')],
            'signal_job' => ['ok' => is_file($root.'/System/Jobs/DeliverTimeSignalsJob.php')],
            'attention_job' => ['ok' => is_file($root.'/System/Jobs/DetectTimeAttentionJob.php')],
            'workforce_gateway' => ['ok' => is_file($root.'/System/Workforce/TimeWorkforceToolGateway.php')],
            'workforce_validator' => ['ok' => is_file($root.'/System/Workforce/TimeWorkforceManifestValidator.php')],
            'wizard_registry' => ['ok' => is_file($root.'/System/Wizards/TimeWizardRegistry.php')],
            'surface_registry' => ['ok' => is_file($root.'/System/Surfaces/TimeSurfaceRegistry.php')],
            'rewind_integration' => ['ok' => is_file($root.'/System/Integrations/Rewind/TimeRewindIntegration.php')],
            'platform_exports' => ['ok' => is_file($root.'/System/Integrations/Exports/TimePlatformExportRegistry.php')],
            'release_verifier' => ['ok' => is_file($root.'/bin/verify-release.php')],
        ];
        return ['ok' => ! in_array(false, array_column($checks, 'ok'), true), 'checks' => $checks];
    }

    private function validInstallerManifest(string $path): bool
    {
        if (! is_file($path)) return false;
        try {
            $m = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            if (! is_array($m)) return false;
            return ($m['schema'] ?? '') === 'titan-extension-v1'
                && ($m['version'] ?? '') === '0.1.7'
                && ($m['folder'] ?? '') === 'TitanTimeAttendance'
                && ($m['provider'] ?? '') === 'App\\Extensions\\TitanTimeAttendance\\System\\TitanTimeAttendanceServiceProvider'
                && is_array($m['dependencies'] ?? null)
                && is_array($m['optional_dependencies'] ?? null)
                && is_array($m['integrity']['files'] ?? null);
        } catch (Throwable) {
            return false;
        }
    }

    private function validJson(string $path): bool
    {
        if (! is_file($path)) return false;
        try { return is_array(json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR)); }
        catch (Throwable) { return false; }
    }

    private function validWorkforceManifest(string $path): bool
    {
        if (! is_file($path)) return false;
        try {
            $manifest = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            if (! is_array($manifest)) return false;
            TimeWorkforceManifestValidator::assertValid($manifest);
            return true;
        } catch (Throwable) {
            return false;
        }
    }
}
