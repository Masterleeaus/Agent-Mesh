<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Security;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Support\Facades\Gate;

final class TimeAttendancePermissionService
{
    private const SELF_SERVICE = [
        'titan-time-attendance.view',
        'titan-time-attendance.record',
        'titan-time-attendance.submit',
    ];

    public function authorize(object $user,string $permission,array $input=[]): void
    {
        if (method_exists($user,'can') && $user->can($permission)) return;
        if (Gate::has($permission) && Gate::allows($permission)) return;

        if ((bool)config('titan-time-attendance.permissions.allow_authenticated_self_service',true)
            && in_array($permission,self::SELF_SERVICE,true)) {
            $actorId=(int)(method_exists($user,'getKey')?$user->getKey():($user->id??0));
            $target=isset($input['user_id'])?(int)$input['user_id']:$actorId;
            if ($actorId>0 && $target===$actorId) return;
        }
        throw new AuthorizationException("Titan Time & Attendance permission denied: {$permission}");
    }
}
