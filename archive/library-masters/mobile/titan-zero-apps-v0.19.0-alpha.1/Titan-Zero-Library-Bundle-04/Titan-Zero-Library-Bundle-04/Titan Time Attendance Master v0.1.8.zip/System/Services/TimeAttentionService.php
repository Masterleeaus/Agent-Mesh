<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Services;

use App\Extensions\TitanTimeAttendance\System\Intelligence\TimeAttentionDetector;
use App\Extensions\TitanTimeAttendance\System\Models\TimeAttentionFinding;

final class TimeAttentionService
{
    public function __construct(private readonly TimeAttentionDetector $detector, private readonly SignalOutboxService $signals) {}

    public function refreshTenant(int $companyId, ?int $userId = null): array
    {
        $saved = [];
        $activeRefs = [];

        foreach ($this->detector->detect($companyId, $userId) as $finding) {
            $data = $finding->toArray();
            $identity = $data['finding_key'] . '|' . $data['source_ref'];
            $activeRefs[$identity] = true;

            $record = TimeAttentionFinding::query()->forCompany($companyId)
                ->where('finding_key', $data['finding_key'])
                ->where('source_ref', $data['source_ref'])
                ->first();
            $created = $record === null;
            $reopened = $record !== null && $record->status === 'resolved';
            if ($created) {
                $record = new TimeAttentionFinding([
                    'company_id' => $companyId,
                    'finding_key' => $data['finding_key'],
                    'source_ref' => $data['source_ref'],
                ]);
            }
            $record->fill($data + ['status' => 'open', 'resolved_at' => null]);
            if ($created || $reopened || $record->detected_at === null) $record->detected_at = now();
            $record->save();
            $saved[] = $record;

            if ($created || $reopened) {
                $signal = match ($data['finding_type']) {
                    'overdue_timer' => 'time.timer.overdue',
                    'offline_rejected' => 'attendance.offline.rejected',
                    'stale_submission' => 'time.submission.missing',
                    'overlapping_time' => 'time.entry.overlap_detected',
                    'multiple_running_timers' => 'time.timer.overlap_detected',
                    'long_time_entry' => 'time.entry.long_duration',
                    default => null,
                };
                if ($signal !== null) {
                    $this->signals->record($companyId, $signal, [
                        'finding_id' => $record->getKey(),
                        'finding_type' => $data['finding_type'],
                        'source_ref' => $data['source_ref'],
                        'user_id' => $data['user_id'],
                    ], [
                        'dedup_key' => $data['finding_type'] === 'offline_rejected' && str_starts_with($data['source_ref'], 'offline:')
                            ? 'offline-rejected:' . substr($data['source_ref'], 8)
                            : 'attention:' . $data['finding_key'] . ':' . $data['source_ref'] . ':' . $record->detected_at?->timestamp,
                    ]);
                }
            }
        }

        $open = TimeAttentionFinding::query()->forCompany($companyId)->where('status', 'open');
        if ($userId !== null) $open->where('user_id', $userId);
        foreach ($open->limit(1000)->get() as $record) {
            $identity = $record->finding_key . '|' . $record->source_ref;
            if (isset($activeRefs[$identity])) continue;
            $record->forceFill(['status' => 'resolved', 'resolved_at' => now()])->save();
        }

        return $saved;
    }
}
