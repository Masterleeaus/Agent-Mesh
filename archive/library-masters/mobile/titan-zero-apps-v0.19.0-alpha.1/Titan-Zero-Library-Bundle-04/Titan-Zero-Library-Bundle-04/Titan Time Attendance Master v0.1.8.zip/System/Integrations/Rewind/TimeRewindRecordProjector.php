<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Rewind;

use App\Extensions\TitanTimeAttendance\System\Models\{TimeCommandReceipt,TimeSignalOutbox};

final class TimeRewindRecordProjector
{
    private const SAFE_PAYLOAD_KEYS = [
        'receipt_id','command_id','capability','timer_id','submission_id','verification_log_id','time_entry_id','policy_id','actor_user_id','user_id',
        'work_order_public_id','service_location_public_id','status','decision','reason_code','risk','human_approval_required','source_event_id','event_type',
    ];

    /** @return array<int,array<string,mixed>> */
    public function records(int $companyId,string $traceId): array
    {
        $signals=TimeSignalOutbox::query()->forCompany($companyId)->where('trace_id',$traceId)->orderBy('id')->limit(1000)->get()->map->toArray()->all();
        $receipts=TimeCommandReceipt::query()->forCompany($companyId)->where('trace_id',$traceId)->orderBy('id')->limit(1000)->get()->map->toArray()->all();
        return $this->projectRows($signals,$receipts,$companyId,$traceId);
    }

    /** @return array<int,array<string,mixed>> */
    public function projectRows(array $signals,array $receipts,int $companyId,string $traceId): array
    {
        $records=[];
        foreach($signals as $row){
            if((int)($row['company_id']??0)!==$companyId || (string)($row['trace_id']??'')!==$traceId)continue;
            $payload=is_array($row['payload']??null)?$this->safePayload($row['payload']):[];
            $record=[
                'company_id'=>$companyId,
                'event_id'=>(string)($row['event_id']??''),
                'trace_id'=>$traceId,
                'correlation_id'=>$this->nullableString($row['correlation_id']??null),
                'causation_id'=>$this->nullableString($row['causation_id']??null),
                'source_engine'=>'titan-time-attendance',
                'source_record_id'=>'signal:'.(string)($row['id']??$row['event_id']??''),
                'event_type'=>(string)($row['event_type']??'time.signal'),
                'occurred_at'=>$this->dateString($row['created_at']??$row['available_at']??null),
                'recorded_at'=>$this->dateString($row['created_at']??null),
                'actor_type'=>isset($payload['actor_user_id'])||isset($payload['user_id'])?'human':null,
                'actor_id'=>isset($payload['actor_user_id'])?(string)$payload['actor_user_id']:(isset($payload['user_id'])?(string)$payload['user_id']:null),
                'capability_name'=>$this->nullableString($payload['capability']??null),
                'risk_state'=>isset($payload['risk'])?['level'=>(string)$payload['risk']]:null,
                'governance_state'=>isset($payload['human_approval_required'])?['human_approval_required'=>(bool)$payload['human_approval_required']]:null,
                'payload'=>$payload,
                'schema_version'=>1,
            ];
            $record['source_hash']=$this->sourceHash($record);
            $records[]=$record;
        }
        foreach($receipts as $row){
            if((int)($row['company_id']??0)!==$companyId || (string)($row['trace_id']??'')!==$traceId)continue;
            $payload=$this->safeReceiptPayload($row);
            $record=[
                'company_id'=>$companyId,
                'event_id'=>(string)($row['command_id']??''),
                'trace_id'=>$traceId,
                'correlation_id'=>$this->nullableString($row['correlation_id']??null),
                'causation_id'=>$this->nullableString($row['causation_id']??null),
                'source_engine'=>'titan-time-attendance',
                'source_record_id'=>'command:'.(string)($row['id']??$row['command_id']??''),
                'event_type'=>'time.command.receipt.'.strtolower((string)($row['status']??'unknown')),
                'occurred_at'=>$this->dateString($row['executed_at']??$row['updated_at']??$row['created_at']??null),
                'recorded_at'=>$this->dateString($row['created_at']??null),
                'actor_type'=>$this->nullableString($row['actor_type']??null),
                'actor_id'=>isset($row['actor_user_id'])?(string)$row['actor_user_id']:null,
                'capability_name'=>$this->nullableString($row['capability']??null),
                'risk_state'=>isset($row['risk_class'])?['level'=>(string)$row['risk_class']]:null,
                'governance_state'=>['human_approval_required'=>(bool)($row['human_approval_required']??false),'source'=>(string)($row['source']??'')],
                'payload'=>$payload,
                'schema_version'=>1,
            ];
            $record['source_hash']=$this->sourceHash($record);
            $records[]=$record;
        }
        usort($records,static fn(array $a,array $b):int=>[$a['occurred_at'],$a['event_id']]<=>[$b['occurred_at'],$b['event_id']]);
        foreach($records as $i=>&$record)$record['sequence']=$i;
        unset($record);
        return $records;
    }

    private function safePayload(array $payload): array
    {
        $safe=[];
        foreach(self::SAFE_PAYLOAD_KEYS as $key){
            if(!array_key_exists($key,$payload) || is_array($payload[$key]) || is_object($payload[$key]))continue;
            $safe[$key]=$payload[$key];
        }
        return $safe;
    }

    private function safeReceiptPayload(array $row): array
    {
        $safe=[
            'receipt_id'=>$row['id']??null,
            'command_id'=>$row['command_id']??null,
            'capability'=>$row['capability']??null,
            'status'=>$row['status']??null,
            'risk'=>$row['risk_class']??null,
            'human_approval_required'=>(bool)($row['human_approval_required']??false),
        ];
        $result=is_array($row['result']??null)?$row['result']:[];
        foreach(['time_entry','timer','submission','verification','policy'] as $bucket){
            $value=$result[$bucket]??null;
            if(is_array($value) && isset($value['id']))$safe[$bucket.'_id']=$value['id'];
        }
        foreach(['decision','status'] as $key)if(isset($result[$key])&&!is_array($result[$key])&&!is_object($result[$key]))$safe[$key]=$result[$key];
        return array_filter($safe,static fn($v)=>$v!==null&&$v!=='');
    }

    private function sourceHash(array $record): string
    {
        $copy=$record;unset($copy['source_hash'],$copy['sequence']);
        return hash('sha256',json_encode($copy,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }

    private function nullableString(mixed $value): ?string
    {
        if($value===null)return null;$value=trim((string)$value);return $value===''?null:$value;
    }

    private function dateString(mixed $value): string
    {
        if($value instanceof \DateTimeInterface)return $value->format(DATE_ATOM);
        $text=trim((string)($value??''));
        if($text==='')return gmdate(DATE_ATOM,0);
        try{return (new \DateTimeImmutable($text))->format(DATE_ATOM);}catch(\Throwable){return gmdate(DATE_ATOM,0);}
    }
}
