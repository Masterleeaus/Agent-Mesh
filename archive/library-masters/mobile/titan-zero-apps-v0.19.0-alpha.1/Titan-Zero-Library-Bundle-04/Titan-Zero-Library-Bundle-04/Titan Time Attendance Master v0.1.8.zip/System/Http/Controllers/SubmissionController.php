<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Http\Controllers;
use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;use App\Http\Controllers\Controller;use Illuminate\Http\JsonResponse;use Illuminate\Http\Request;
final class SubmissionController extends Controller
{
 public function submit(Request $request,TimeCommandBusGateway $gateway): JsonResponse
 {
  $d=$request->validate(['week_start'=>'required|date','week_end'=>'required|date|after_or_equal:week_start','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid']);
  $r=$gateway->request('time.submission.submit',$d,$request->user());return response()->json(['data'=>$r],($r['executed']??false)?201:202);
 }
 public function review(Request $request,int $submission,TimeCommandBusGateway $gateway): JsonResponse
 {
  $d=$request->validate(['decision'=>'required|in:approved,rejected','notes'=>'nullable|string|max:5000','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid']);$d['submission_id']=$submission;
  $r=$gateway->request('time.submission.review',$d,$request->user());return response()->json(['data'=>$r],($r['executed']??false)?200:202);
 }
}
