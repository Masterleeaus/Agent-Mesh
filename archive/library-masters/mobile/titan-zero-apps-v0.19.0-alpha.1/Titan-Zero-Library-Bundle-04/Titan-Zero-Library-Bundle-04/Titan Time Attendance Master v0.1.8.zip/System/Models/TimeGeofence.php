<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Models;
use Illuminate\Database\Eloquent\Builder; use Illuminate\Database\Eloquent\Model;
final class TimeGeofence extends Model
{
 protected $table='ext_titan_time_geofences';
 protected $fillable=['company_id','name','site_id','service_location_public_id','latitude','longitude','radius_metres','active'];
 protected $casts=['latitude'=>'float','longitude'=>'float','radius_metres'=>'integer','active'=>'boolean'];
 public function scopeForCompany(Builder $query,int $companyId): Builder{return $query->where('company_id',$companyId);}
}
