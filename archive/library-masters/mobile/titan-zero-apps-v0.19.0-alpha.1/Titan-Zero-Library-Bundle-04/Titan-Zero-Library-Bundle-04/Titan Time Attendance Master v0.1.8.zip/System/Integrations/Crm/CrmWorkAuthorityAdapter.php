<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Crm;

use RuntimeException;

/**
 * Reads CRM only through its governed capability executor; never through CRM models/tables.
 * Canonical CRM references are public IDs, not caller-controlled internal database IDs.
 */
final class CrmWorkAuthorityAdapter implements CrmWorkAuthorityPort
{
    private const EXECUTOR = 'App\\Extensions\\Crm\\System\\Capabilities\\CrmCapabilityExecutor';

    public function available(): bool
    {
        return class_exists(self::EXECUTOR) && app()->bound(self::EXECUTOR);
    }

    public function assertWorkOrderAccessible(int $companyId,int $actorUserId,string $workOrderPublicId): void
    {
        $this->assertCanonical($companyId,$actorUserId,'crm.work_order.read',$workOrderPublicId,'workOrderPublicId');
    }

    public function assertServiceLocationAccessible(int $companyId,int $actorUserId,string $serviceLocationPublicId): void
    {
        $this->assertCanonical($companyId,$actorUserId,'crm.location.read',$serviceLocationPublicId,'serviceLocationPublicId');
    }

    private function assertCanonical(int $companyId,int $actorUserId,string $capability,string $publicId,string $label): void
    {
        if ($companyId < 1 || $actorUserId < 1) throw new RuntimeException('Resolved Titan tenant and actor are required for CRM authority checks.');
        if ($publicId === '') throw new RuntimeException("{$label} is required.");
        if (! $this->available()) {
            if ((bool)config('titan-time-attendance.crm.require_authority_when_reference_supplied', true)) {
                throw new RuntimeException('CRM authority is unavailable for the supplied canonical work reference.');
            }
            return;
        }
        $executor = app(self::EXECUTOR);
        $result = $executor->execute($capability,['public_id'=>$publicId]);
        $resolvedTenant = (int)($result['company_id'] ?? 0);
        if ($resolvedTenant !== $companyId) throw new RuntimeException('CRM reference escaped the active Titan company boundary.');
        if (($result['status'] ?? null) !== 'ok') throw new RuntimeException('CRM reference could not be authorised.');
    }
}
