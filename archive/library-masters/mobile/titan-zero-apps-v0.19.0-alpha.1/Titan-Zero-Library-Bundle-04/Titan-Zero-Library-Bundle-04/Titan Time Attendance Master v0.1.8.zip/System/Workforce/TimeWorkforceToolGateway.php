<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Workforce;
use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;
use App\Extensions\TitanTimeAttendance\System\Support\CapabilityCatalog;
use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use App\Extensions\TitanTimeAttendance\System\Workforce\Decision\TimeWorkforceDecisionGate;
use InvalidArgumentException;
final class TimeWorkforceToolGateway
{
    public function __construct(private readonly TimeAttendanceToolRegistry $tools,private readonly TimeAttendanceWorkforceManifest $manifest,private readonly TimeAttendancePermissionService $permissions,private readonly TimeWorkforceDecisionGate $decisionGate,private readonly TimeCommandBusGateway $commands){}
    public function invoke(string $toolId,TimeWorkforceExecutionContext $context,array $input=[]): mixed
    {
        $forbidden=array_intersect(['company_id','tenant_id','actor_user_id','actor_type','source','trace_id','correlation_id','causation_id','idempotency_key','_context'],array_keys($input));
        if($forbidden!==[])throw new InvalidArgumentException('Workforce tool input cannot supply trusted identity fields: '.implode(', ',$forbidden));
        $tool=$this->tools->definition($toolId);$capability=(string)$tool['capability'];
        $role=$this->roleDefinition($context->roleKey);
        if(!in_array($toolId,(array)($role['tool_access']??[]),true))return ['status'=>'unauthorized','reason'=>'role_tool_not_allowed','tool_id'=>$toolId,'capability'=>$capability];
        if(strtoupper((string)($role['risk_ceiling']??''))!==strtoupper($context->riskCeiling))return ['status'=>'unauthorized','reason'=>'role_risk_ceiling_mismatch','tool_id'=>$toolId,'capability'=>$capability];
        if(!in_array($capability,(array)($role['capabilities']??[]),true))return ['status'=>'unauthorized','reason'=>'role_capability_not_allowed','tool_id'=>$toolId,'capability'=>$capability];
        if(!$context->allowsCapability($capability))return ['status'=>'unauthorized','reason'=>'capability_not_granted','tool_id'=>$toolId,'capability'=>$capability];
        $definition=CapabilityCatalog::definition($capability);
        $this->permissions->authorize($context->actorPrincipal,(string)$definition['permission'],$input);
        if(($tool['mode']??'read')==='read')return $this->tools->invoke($toolId,$context->companyId,$context->actorUserId,$input);$decision=$this->decisionGate->evaluate($capability,$definition,$context,$input);
        if(!($decision['dispatch']??false)||$context->executionMode!=='execute')return ['status'=>$decision['status'],'decision'=>$decision,'tool_id'=>$toolId,'capability'=>$capability,'prepared_input'=>$input];
        $payload=array_replace($input,['trace_id'=>$context->traceId,'correlation_id'=>$context->correlationId,'causation_id'=>$context->causationId,'idempotency_key'=>$context->idempotencyKey]);
        $result=$this->commands->request($capability,$payload,$context->actorPrincipal,'titan_workforce','ai');
        return ['status'=>$decision['status'],'decision'=>$decision,'tool_id'=>$toolId,'capability'=>$capability,'command'=>$result];
    }

    private function roleDefinition(string $roleKey): array
    {
        foreach($this->manifest->all()['role_bindings']??[] as $binding){
            if(($binding['role_definition_id']??null)===$roleKey || in_array($roleKey,(array)($binding['legacy_role_keys']??[]),true)) return $binding;
        }
        throw new InvalidArgumentException("Unknown Titan Time & Attendance intrinsic Workforce role binding: {$roleKey}");
    }
}
