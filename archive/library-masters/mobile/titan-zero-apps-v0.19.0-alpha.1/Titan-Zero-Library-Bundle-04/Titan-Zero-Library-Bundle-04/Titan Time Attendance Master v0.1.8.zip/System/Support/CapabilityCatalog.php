<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Support;

use InvalidArgumentException;

final class CapabilityCatalog
{
    /** @return array<int,array<string,mixed>> */
    public static function all(): array
    {
        return array_values(self::definitions());
    }

    /** @return array<string,array<string,mixed>> */
    public static function definitions(): array
    {
        return [
            'time.entry.read' => [
                'id'=>'time.entry.read','mode'=>'read','risk'=>'LOW','permission'=>'titan-time-attendance.view','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
            'time.entry.create' => [
                'id'=>'time.entry.create','mode'=>'write','risk'=>'MEDIUM','permission'=>'titan-time-attendance.record','human_approval'=>false,'idempotent'=>true,'handler'=>'time_entry.create',
            ],
            'time.timer.start' => [
                'id'=>'time.timer.start','mode'=>'write','risk'=>'LOW','permission'=>'titan-time-attendance.record','human_approval'=>false,'idempotent'=>true,'handler'=>'timer.start',
            ],
            'time.timer.stop' => [
                'id'=>'time.timer.stop','mode'=>'write','risk'=>'MEDIUM','permission'=>'titan-time-attendance.record','human_approval'=>false,'idempotent'=>true,'handler'=>'timer.stop',
            ],
            'time.submission.submit' => [
                'id'=>'time.submission.submit','mode'=>'write','risk'=>'MEDIUM','permission'=>'titan-time-attendance.submit','human_approval'=>false,'idempotent'=>true,'handler'=>'submission.submit',
            ],
            'time.submission.review' => [
                'id'=>'time.submission.review','mode'=>'write','risk'=>'HIGH','permission'=>'titan-time-attendance.review','human_approval'=>true,'idempotent'=>true,'handler'=>'submission.review',
            ],
            'attendance.verify' => [
                'id'=>'attendance.verify','mode'=>'write','risk'=>'MEDIUM','permission'=>'titan-time-attendance.record','human_approval'=>false,'idempotent'=>true,'handler'=>'attendance.verify',
            ],
            'attendance.offline.ingest' => [
                'id'=>'attendance.offline.ingest','mode'=>'write','risk'=>'MEDIUM','permission'=>'titan-time-attendance.record','human_approval'=>false,'idempotent'=>true,'handler'=>'attendance.offline_ingest',
            ],
            'attendance.verification.audit' => [
                'id'=>'attendance.verification.audit','mode'=>'read','risk'=>'MEDIUM','permission'=>'titan-time-attendance.audit','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
            'time.costing.calculate' => [
                'id'=>'time.costing.calculate','mode'=>'read','risk'=>'LOW','permission'=>'titan-time-attendance.view','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
            'time.policy.read' => [
                'id'=>'time.policy.read','mode'=>'read','risk'=>'LOW','permission'=>'titan-time-attendance.view','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
            'time.policy.update' => [
                'id'=>'time.policy.update','mode'=>'write','risk'=>'HIGH','permission'=>'titan-time-attendance.manage-policy','human_approval'=>true,'idempotent'=>true,'handler'=>'policy.update',
            ],
            'time.attention.read' => [
                'id'=>'time.attention.read','mode'=>'read','risk'=>'LOW','permission'=>'titan-time-attendance.view','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
            'time.workflow.read' => [
                'id'=>'time.workflow.read','mode'=>'read','risk'=>'LOW','permission'=>'titan-time-attendance.view','human_approval'=>false,'idempotent'=>false,'handler'=>'read_model',
            ],
        ];
    }

    /** @return array<string,mixed> */
    public static function definition(string $capability): array
    {
        $definition = self::definitions()[$capability] ?? null;
        if ($definition === null) {
            throw new InvalidArgumentException("Unknown Titan Time & Attendance capability: {$capability}");
        }
        return $definition;
    }
}
