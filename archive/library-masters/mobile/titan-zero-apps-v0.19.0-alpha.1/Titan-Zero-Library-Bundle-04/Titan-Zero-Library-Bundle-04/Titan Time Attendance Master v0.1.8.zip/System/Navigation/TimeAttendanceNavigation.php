<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Navigation;

final class TimeAttendanceNavigation
{
    /** @return array<int,array<string,mixed>> */
    public static function user(): array
    {
        return [[
            'parent_key' => null,
            'key' => 'titan_time_attendance',
            'route' => 'dashboard.user.titan-time-attendance.index',
            'route_slug' => null,
            'label' => 'Time & Attendance',
            'icon' => 'tabler-clock-hour-4',
            'svg' => null,
            'order' => 14,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            // Time & Attendance is governed by extension permissions, not a MagicAI plan-menu flag.
            'extension' => null,
            'active_condition' => ['dashboard.user.titan-time-attendance.*'],
            'show_condition' => true,
            'is_admin' => false,
            'data-name' => 'titan-time-attendance',
        ]];
    }
}
