<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Http\Controllers;
use App\Extensions\TitanTimeAttendance\System\Governance\TimeCommandBusGateway;
use App\Extensions\TitanTimeAttendance\System\Models\TimeEntry;
use App\Extensions\TitanTimeAttendance\System\Security\TimeAttendancePermissionService;
use App\Extensions\TitanTimeAttendance\System\Support\CompanyContext;
use App\Http\Controllers\Controller;use Illuminate\Http\JsonResponse;use Illuminate\Http\Request;
final class TimeEntryController extends Controller
{
 public function index(Request $request,TimeAttendancePermissionService $permissions): JsonResponse
 {
  $user=$request->user();$permissions->authorize($user,'titan-time-attendance.view');$tenant=CompanyContext::id($user);$query=TimeEntry::query()->forCompany($tenant)->latest('work_date');
  if($request->boolean('all_users')){$permissions->authorize($user,'titan-time-attendance.view-all');}else{$query->where('user_id',$user->getKey());}
  return response()->json($query->paginate(min(100,max(1,(int)$request->integer('per_page',25)))));
 }
 public function store(Request $request,TimeCommandBusGateway $gateway,TimeAttendancePermissionService $permissions): JsonResponse
 {
  $data=$request->validate([
   'user_id'=>'nullable|integer|min:1','work_order_id'=>'nullable|integer|min:1','work_order_public_id'=>'nullable|string|size:26','project_id'=>'nullable|integer|min:1','task_id'=>'nullable|integer|min:1','work_date'=>'required|date',
   'minutes'=>'nullable|integer|min:1|max:1440','start_time'=>'required_without:minutes|date_format:H:i','end_time'=>'required_without:minutes|date_format:H:i','type'=>'nullable|string|max:40','notes'=>'nullable|string|max:5000',
   'rate_per_hour'=>'nullable|numeric|min:0','overtime_multiplier'=>'nullable|numeric|min:0|max:10','idempotency_key'=>'nullable|string|max:128','trace_id'=>'nullable|uuid','correlation_id'=>'nullable|uuid','causation_id'=>'nullable|uuid',
  ]);
  $user=$request->user();$actor=(int)$user->getKey();$target=isset($data['user_id'])?(int)$data['user_id']:$actor;if($target!==$actor)$permissions->authorize($user,'titan-time-attendance.record-others',['user_id'=>$target]);$data['user_id']=$target;
  $result=$gateway->request('time.entry.create',$data,$user);return response()->json(['data'=>$result],($result['executed']??false)?201:202);
 }
}
