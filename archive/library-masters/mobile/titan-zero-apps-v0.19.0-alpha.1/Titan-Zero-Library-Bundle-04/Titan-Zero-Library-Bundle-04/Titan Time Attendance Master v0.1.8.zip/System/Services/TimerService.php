<?php

declare(strict_types=1);
namespace App\Extensions\TitanTimeAttendance\System\Services;
use App\Extensions\TitanTimeAttendance\System\Models\TimeTimer; use Illuminate\Support\Facades\DB; use Illuminate\Validation\ValidationException;
final class TimerService
{
 public function __construct(private readonly TimeEntryService $entries,private readonly SignalOutboxService $signals) {}
 public function start(int $companyId,int $userId,?int $workOrderId=null,?string $workOrderPublicId=null,array $trace=[]): TimeTimer
 {
  $existing=TimeTimer::query()->forCompany($companyId)->where('user_id',$userId)->where('status','running')->first();
  if($existing)throw ValidationException::withMessages(['timer'=>'A timer is already running.']);
  $timer=TimeTimer::query()->create(['company_id'=>$companyId,'user_id'=>$userId,'work_order_id'=>$workOrderId,'work_order_public_id'=>$workOrderPublicId,'started_at'=>now(),'status'=>'running','source'=>'timer','trace_id'=>$trace['trace_id']??null]);
  $this->signals->record($companyId,'time.timer.started',['timer_id'=>$timer->getKey(),'user_id'=>$userId,'work_order_public_id'=>$workOrderPublicId],$trace+['dedup_key'=>isset($trace['dedup_key'])?$trace['dedup_key'].':timer-started':null]);return $timer;
 }
 public function stop(int $companyId,int $userId,int $timerId,array $data=[]): array
 {
  return DB::transaction(function()use($companyId,$userId,$timerId,$data){
   $timer=TimeTimer::query()->forCompany($companyId)->whereKey($timerId)->lockForUpdate()->firstOrFail();
   if((int)$timer->user_id!==$userId||$timer->status!=='running')throw ValidationException::withMessages(['timer'=>'Timer is not active for this user.']);
   $stoppedAt=now();$minutes=max(1,(int)$timer->started_at->diffInMinutes($stoppedAt));$timer->forceFill(['stopped_at'=>$stoppedAt,'elapsed_minutes'=>$minutes,'status'=>'stopped'])->save();
   $entry=$this->entries->create($companyId,$userId,[
     'user_id'=>$userId,'work_order_id'=>$timer->work_order_id,'work_order_public_id'=>$timer->work_order_public_id,'work_date'=>$timer->started_at->toDateString(),'start_time'=>$timer->started_at->format('H:i:s'),'end_time'=>$stoppedAt->format('H:i:s'),'minutes'=>$minutes,
     'notes'=>$data['notes']??null,'type'=>$data['type']??'regular','rate_per_hour'=>$data['rate_per_hour']??null,'overtime_multiplier'=>$data['overtime_multiplier']??1.0,'source'=>'timer',
     'trace_id'=>$data['trace_id']??null,'correlation_id'=>$data['correlation_id']??null,'causation_id'=>$data['causation_id']??null,'dedup_key'=>isset($data['dedup_key'])?$data['dedup_key'].':timer-entry':null,
   ]);
   $this->signals->record($companyId,'time.timer.stopped',['timer_id'=>$timer->getKey(),'time_entry_id'=>$entry->getKey(),'user_id'=>$userId,'minutes'=>$minutes],$data+['dedup_key'=>isset($data['dedup_key'])?$data['dedup_key'].':timer-stopped':null]);
   return ['timer'=>$timer,'time_entry'=>$entry];
  });
 }
}
