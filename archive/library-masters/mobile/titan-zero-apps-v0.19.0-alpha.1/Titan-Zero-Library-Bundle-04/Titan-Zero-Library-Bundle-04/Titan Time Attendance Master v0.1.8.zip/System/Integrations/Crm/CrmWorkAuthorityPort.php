<?php

declare(strict_types=1);

namespace App\Extensions\TitanTimeAttendance\System\Integrations\Crm;

interface CrmWorkAuthorityPort
{
    public function available(): bool;
    public function assertWorkOrderAccessible(int $companyId,int $actorUserId,string $workOrderPublicId): void;
    public function assertServiceLocationAccessible(int $companyId,int $actorUserId,string $serviceLocationPublicId): void;
}
