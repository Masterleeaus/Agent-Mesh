<?php

declare(strict_types=1);

return [
    'product_name' => 'Titan Onboarding',
    'technical_slug' => 'onboarding-pro',
    'version' => '6.0.0-rc.3',
    'compatibility_data_policy' => 'read-only-import; never delete donor data',
    'participant_grant_ttl_minutes' => 60,
    'vertical_engine' => [
        'public_contract' => null,
        'resolve_candidates_method' => 'resolveCandidatesForOnboarding',
        'required_before_nexus' => true,
    ],
    'nexus' => [
        // Set this to the host/Nexus public manager contract when Nexus is installed.
        // Onboarding fails closed as UNAVAILABLE while it is unbound.
        'public_contract' => null,
        'new_draft_method' => 'newDraft',
        'validate_draft_method' => 'validateDraft',
        'preview_draft_method' => 'previewDraft',
        'compile_draft_method' => 'compileDraft',
        'plan_provisioning_method' => 'planProvisioning',
        'execute_provisioning_method' => 'executeProvisioning',
        'verify_provisioning_method' => 'verifyProvisioning',
    ],
    'provider_actions' => [
        // Compatibility only. Caller-supplied grants are not canonical authority.
        // Keep disabled; Agent 1 Governance owns the trusted decision/receipt path.
        'legacy_self_asserted_authority_enabled' => env('TITAN_ONBOARDING_LEGACY_SELF_ASSERTED_AUTHORITY_ENABLED', false),
    ],
    'interaction_engine' => [
        'minimum_version' => '10.3.2',
        // Agent 1 owns this stable public Titan Apps Interaction contract binding.
        'public_contract' => env('TITAN_APPS_INTERACTION_CAPABILITY_ROUTER_CONTRACT', ''),
        'required' => false,
    ],
];
