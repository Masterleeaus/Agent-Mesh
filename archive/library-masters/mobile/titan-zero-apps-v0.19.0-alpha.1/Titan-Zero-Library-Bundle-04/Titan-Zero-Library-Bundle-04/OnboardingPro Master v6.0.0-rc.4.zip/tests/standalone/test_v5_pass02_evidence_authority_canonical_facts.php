<?php
$root=dirname(__DIR__,2);
$req=['System/Evidence/EvidenceAuthorityService.php','System/Evidence/CanonicalBusinessFactService.php','System/Persistence/Models/BusinessCandidateFact.php','System/Persistence/Models/CanonicalBusinessFact.php'];
foreach($req as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}}
$e=file_get_contents($root.'/System/Evidence/EvidenceAuthorityService.php');$c=file_get_contents($root.'/System/Evidence/CanonicalBusinessFactService.php');
$checks=[str_contains($e,'source_authority'),str_contains($e,'freshness'),str_contains($e,'confidence'),str_contains($e,'corroborated'),str_contains($e,'conflicts_with'),str_contains($e,'sensitivity'),str_contains($c,'owner_confirmed'),str_contains($c,'verified'),str_contains($c,'canonical'),str_contains($c,'supersedes'),str_contains($c,'company_id')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 2 evidence authority contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 2 evidence authority and canonical business facts\n";
