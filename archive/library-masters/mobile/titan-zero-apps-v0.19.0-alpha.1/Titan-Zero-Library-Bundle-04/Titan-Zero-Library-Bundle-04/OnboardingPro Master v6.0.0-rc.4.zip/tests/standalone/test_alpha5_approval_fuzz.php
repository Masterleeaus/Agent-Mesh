<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Services\ApprovalChainService;
$svc=new ApprovalChainService();
$ctx=['company_id'=>44,'required_actor_id'=>101,'subject_actor_id'=>91,'journey_version_id'=>'v2','active_journey_version_id'=>'v2','separation_of_duties'=>true];
$r=$svc->approve('apr-1',101,44,'step:licence',$ctx,new DateTimeImmutable('2026-08-11T04:00:00Z'));
foreach([
 fn()=> $svc->approve('apr-2',102,44,'step:licence',$ctx,new DateTimeImmutable('2026-08-11T04:01:00Z')),
 fn()=> $svc->approve('apr-3',101,45,'step:licence',$ctx,new DateTimeImmutable('2026-08-11T04:01:00Z')),
 fn()=> $svc->approve('apr-4',91,44,'step:licence',$ctx,new DateTimeImmutable('2026-08-11T04:01:00Z')),
 fn()=> $svc->replace($r,'approved'),
 fn()=> $svc->delete($r),
] as $i=>$fn){try{$fn();throw new RuntimeException("approval fuzz accepted $i");}catch(DomainException|LogicException){}}
$stale=$ctx;$stale['journey_version_id']='v1';try{$svc->approve('apr-5',101,44,'step:licence',$stale,new DateTimeImmutable('2026-08-11T04:02:00Z'));throw new RuntimeException('stale approval accepted');}catch(DomainException){}
echo "test_alpha5_approval_fuzz PASS\n";
