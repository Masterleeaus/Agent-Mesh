<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryProfile;
use App\Extensions\OnboardingPro\System\Discovery\ProgressiveReadinessEvaluator;

$profile=BusinessDiscoveryProfile::fromArray([
 'business_identity'=>['name'=>'Acme Clean','legal_name'=>'Acme Clean Pty Ltd'],
 'industry'=>'cleaning','services'=>['commercial_cleaning','end_of_lease'],'service_areas'=>[['type'=>'radius','value'=>'25km']],
 'jurisdiction'=>['country'=>'AU','state'=>'VIC'],'size'=>'small','staff'=>['count'=>8,'contractors'=>2],
 'operating_hours'=>['mon'=>['08:00','17:00']],'pricing_approach'=>'fixed_and_hourly','job_lifecycle'=>['lead','quote','job','invoice','payment'],
 'communication_channels'=>['email','sms'],'payment_methods'=>['bank_transfer','payid'],'equipment_assets'=>['vacuum','scrubber'],
 'compliance_requirements'=>['ohs','ndis_optional'],'privacy_preferences'=>['device_first'=>true,'external_ai'=>'consent_required'],
 'ai_provider_preferences'=>['mode'=>'byo','providers'=>['openai']],'autonomy_preferences'=>['default'=>'assist'],
 'risk_tolerance'=>['operations'=>'low','marketing'=>'medium']
]);
if($profile->industry!=='cleaning'||count($profile->services)!==2) throw new RuntimeException('profile mapping failed');
if($profile->autonomyPreferences['default']!=='assist') throw new RuntimeException('autonomy preference lost');
$ready=(new ProgressiveReadinessEvaluator())->evaluate($profile);
if(!$ready->minimumReady) throw new RuntimeException('minimum discovery should be ready');
if(!in_array('workforce', $ready->remainingDomains, true)) throw new RuntimeException('progressive setup should preserve later domains');
echo "test_business_discovery PASS\n";
