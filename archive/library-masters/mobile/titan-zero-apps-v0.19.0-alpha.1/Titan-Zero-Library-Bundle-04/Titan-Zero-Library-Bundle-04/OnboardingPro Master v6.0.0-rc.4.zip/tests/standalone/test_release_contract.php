<?php
$root = dirname(__DIR__, 2);
$fail = [];
$manifestPath = $root . '/extension.json';
$raw = file_get_contents($manifestPath);
$m = json_decode($raw, true);
if (($m['schema'] ?? null) !== 'titan-extension-v1') $fail[] = 'wrong installer schema';
if (($m['version'] ?? null) !== '6.0.0-rc.3') $fail[] = 'wrong release version';
if (($m['provider'] ?? null) !== 'App\\Extensions\\OnboardingPro\\System\\OnboardingProServiceProvider') $fail[] = 'provider identity mismatch';
foreach (['dependencies','optional_dependencies'] as $field) {
    $deps = $m[$field] ?? null;
    if (!is_array($deps) || !array_is_list($deps)) { $fail[] = "$field must be a list"; continue; }
    foreach ($deps as $dep) if (!is_array($dep) || !isset($dep['slug'],$dep['version'])) $fail[] = "$field entry must contain slug/version";
}
$actual = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if (!$file->isFile()) continue;
    $relative = str_replace('\\','/', substr($file->getPathname(), strlen($root) + 1));
    if ($relative === 'extension.json') continue;
    $actual[$relative] = 'sha256:' . hash_file('sha256', $file->getPathname());
}
ksort($actual);
$declared = $m['integrity']['files'] ?? [];
ksort($declared);
if ($declared !== $actual) {
    $missing = array_diff_key($actual, $declared);
    $extra = array_diff_key($declared, $actual);
    $mismatch = [];
    foreach ($actual as $path => $hash) if (isset($declared[$path]) && $declared[$path] !== $hash) $mismatch[] = $path;
    $fail[] = 'integrity mismatch missing=' . count($missing) . ' extra=' . count($extra) . ' changed=' . count($mismatch);
}
$providerFile = $root . '/System/OnboardingProServiceProvider.php';
if (!is_file($providerFile)) $fail[] = 'provider file missing';
if (str_contains((string) file_get_contents($providerFile), "->publishes(") && str_contains((string) file_get_contents($providerFile), "'extension'")) $fail[] = 'generic extension publish tag present';
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "release contract PASS\n";
