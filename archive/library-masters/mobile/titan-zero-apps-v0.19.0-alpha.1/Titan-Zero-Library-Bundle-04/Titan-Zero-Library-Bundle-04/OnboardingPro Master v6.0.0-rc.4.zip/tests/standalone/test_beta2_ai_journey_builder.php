<?php
$root=dirname(__DIR__,2);
$required=[
'/System/AI/JourneyDraftRequest.php','/System/AI/JourneyDraftResult.php','/System/AI/JourneyDraftValidator.php','/System/AI/JourneyDraftService.php'
];
foreach($required as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\AI\JourneyDraftRequest;
use App\Extensions\OnboardingPro\System\AI\JourneyDraftService;
$svc=new JourneyDraftService();
$r=$svc->draft(new JourneyDraftRequest(44,'commercial cleaner induction','cleaning','AU-VIC',['information','quiz'],['crm.customer.read'],'trace-1'));
if($r->status!=='DRAFT'||$r->publishable!==false)exit(2);
if(($r->definition['vertical']??null)!=='cleaning')exit(3);
if(!in_array('quiz',array_column($r->definition['steps'],'type'),true))exit(4);
if(isset($r->definition['auto_publish']))exit(5);
echo "beta2 ai journey builder PASS\n";
