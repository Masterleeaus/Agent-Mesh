<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$files=glob($root.'/database/migrations/*.php');$text='';foreach($files as $f)$text.=file_get_contents($f)."\n";
foreach(['ext_onboarding_handoffs','ext_onboarding_capability_actions'] as $table) if(!str_contains($text,$table)) throw new RuntimeException('missing '.$table);
foreach($files as $f) if(!str_contains(file_get_contents($f),'function down')) throw new RuntimeException('down missing '.basename($f));
echo "test_alpha3_migrations PASS\n";
