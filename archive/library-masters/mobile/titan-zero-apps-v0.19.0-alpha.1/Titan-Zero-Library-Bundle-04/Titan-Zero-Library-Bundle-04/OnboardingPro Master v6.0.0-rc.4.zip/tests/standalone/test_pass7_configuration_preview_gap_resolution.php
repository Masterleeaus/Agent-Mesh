<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$required=[
 'System/Discovery/Nexus/NexusConfigurationReview.php',
 'System/Discovery/Nexus/NexusConfigurationReviewService.php',
];
foreach($required as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 7 file: $f\n");exit(1);}}
$svc=file_get_contents($root.'/System/Discovery/Nexus/NexusConfigurationReviewService.php');
$controller=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
$routes=file_get_contents($root.'/routes/user.php');
$view=file_get_contents($root.'/resources/views/business-setup/index.blade.php');
$checks=[
 'service calls intent factory'=>str_contains($svc,'fromSetupState'),
 'service calls Nexus preview bridge'=>str_contains($svc,'->preview('),
 'service normalizes missing extensions'=>str_contains($svc,'missing_extensions'),
 'service normalizes credentials'=>str_contains($svc,'missing_credentials'),
 'service normalizes dependencies'=>str_contains($svc,'missing_dependencies'),
 'service normalizes compliance'=>str_contains($svc,'compliance_requirements'),
 'service normalizes follow-up questions'=>str_contains($svc,'follow_up_questions'),
 'controller exposes preview'=>str_contains($controller,'previewNexusConfiguration'),
 'route exposes preview'=>str_contains($routes,"nexus/preview"),
 'view exposes review section'=>str_contains($view,'Configuration preview'),
];
$failed=[];foreach($checks as $k=>$v)if(!$v)$failed[]=$k;
if($failed){fwrite(STDERR,"Pass 7 failed:\n - ".implode("\n - ",$failed)."\n");exit(1);}
echo "PASS: Pass 7 configuration preview and gap resolution contract\n";
