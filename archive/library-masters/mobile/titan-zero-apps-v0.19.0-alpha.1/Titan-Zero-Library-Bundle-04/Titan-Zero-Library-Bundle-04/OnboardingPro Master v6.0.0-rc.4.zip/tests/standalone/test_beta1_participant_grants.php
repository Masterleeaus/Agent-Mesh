<?php
$root=dirname(__DIR__,2);
foreach(['/System/Security/ParticipantAccessGrant.php','/System/Security/ParticipantGrantService.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Security\ParticipantGrantService;
$fail=[];
$s=new ParticipantGrantService('unit-test-secret');
$g=$s->issue(44,12,55,['welcome','evidence'],new DateTimeImmutable('2026-08-12T01:00:00Z'),new DateTimeImmutable('2026-08-12T02:00:00Z'));
if(!$s->verify($g,new DateTimeImmutable('2026-08-12T01:30:00Z'))) $fail[]='valid grant rejected';
if($s->verify($g,new DateTimeImmutable('2026-08-12T03:00:00Z'))) $fail[]='expired grant accepted';
if(!$g->allowsStep('evidence')||$g->allowsStep('manager_approval'))$fail[]='step scope failed';
$tampered=$g->withTenantCompanyId(99);
if($s->verify($tampered,new DateTimeImmutable('2026-08-12T01:30:00Z'))) $fail[]='tampered grant accepted';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "beta1 participant grants PASS\n";
