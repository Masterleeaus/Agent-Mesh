<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryProfile;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCompiler;
use App\Extensions\OnboardingPro\System\Discovery\VerticalCandidateRequest;
use App\Extensions\OnboardingPro\System\Discovery\VerticalResolution;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
$p=BusinessDiscoveryProfile::fromArray([
'business_identity'=>['name'=>'ABC Plumbing'],'industry'=>'plumbing','services'=>['residential plumbing','commercial plumbing','emergency call-outs'],'service_areas'=>['Melbourne'],'jurisdiction'=>['country'=>'AU','region'=>'VIC'],'timezone'=>'Australia/Melbourne','size'=>'Growing','staff'=>['count'=>30],
'operating_hours'=>['24_7'=>true],'pricing_approach'=>'quoted','job_lifecycle'=>['lead','quote','schedule','job','invoice'],'communication_channels'=>['sms','email'],'payment_methods'=>['card','payid'],'equipment_assets'=>['vehicles'],'compliance_requirements'=>['plumbing licence'],'privacy_preferences'=>[],'ai_provider_preferences'=>[],'autonomy_preferences'=>[],'risk_tolerance'=>[]]);
$t=new OnboardingTraceContext('tr1','co1','ca1',44,91);
$c=new BusinessDiscoveryCompiler();
if(!method_exists($c,'compileNexusProvisioningIntent'))throw new RuntimeException('compileNexusProvisioningIntent missing');
$revision=7;
$r=VerticalCandidateRequest::fromProfile($p,$revision,$t);
$v=new VerticalResolution('RESOLVED',44,$r->fingerprint(),'plumbing','1.0.0',0.98,str_repeat('b',64),[],[],['SERVICE_FAMILY_MATCH']);
$i=$c->compileNexusProvisioningIntent($p,$t,$v,$revision)->toArray();
if(($i['business_requirements']['operating_complexity']??'')!=='GROWING')throw new RuntimeException('complexity');
if(($i['vertical_reference']['vertical_id']??'')!=='plumbing')throw new RuntimeException('vertical authority');
if(!in_array('scheduling',$i['capability_requirements'],true)||!in_array('billing',$i['capability_requirements'],true))throw new RuntimeException('capability families');
if(!in_array('AU-VIC',$i['knowledge_requirements'],true))throw new RuntimeException('jurisdiction knowledge');
if(($i['trace_context']['company_id']??null)!==44)throw new RuntimeException('trace company boundary');
if(($i['company_id']??null)!==44)throw new RuntimeException('canonical company id');
echo "test_alpha5_provisioning_intent PASS\n";
