<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Domain\Evidence\EvidenceIntegrityReceipt;
use App\Extensions\OnboardingPro\System\Services\EvidenceIntegrityService;
$svc=new EvidenceIntegrityService();
$r1=$svc->capture('ev-1',44,str_repeat('a',64),null,new DateTimeImmutable('2026-08-11T03:00:00Z'));
$r2=$svc->capture('ev-2',44,str_repeat('b',64),$r1,new DateTimeImmutable('2026-08-11T03:01:00Z'));
if($r2->previousReceiptHash!==$r1->receiptHash)throw new RuntimeException('chain missing');
if(!$svc->verify($r1,str_repeat('a',64),null))throw new RuntimeException('valid evidence rejected');
if($svc->verify($r1,str_repeat('c',64),null))throw new RuntimeException('tamper undetected');
if($svc->verificationState($r1,str_repeat('c',64),null)!=='TAMPER_SUSPECTED')throw new RuntimeException('wrong tamper state');
echo "test_alpha5_evidence_integrity_chain PASS\n";
