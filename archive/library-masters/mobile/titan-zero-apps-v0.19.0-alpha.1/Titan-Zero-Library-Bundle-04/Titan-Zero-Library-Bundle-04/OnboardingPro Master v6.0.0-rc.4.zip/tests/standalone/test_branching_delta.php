<?php
$root = dirname(__DIR__, 2);
$files = [
    '/System/Domain/Rules/RuleEvaluator.php',
    '/System/Domain/Rules/PrerequisiteEvaluator.php',
    '/System/Services/DeltaJourneyPlanner.php',
];
foreach ($files as $file) {
    if (!is_file($root . $file)) { fwrite(STDERR, "missing production file: $file\n"); exit(1); }
    require_once $root . $file;
}

use App\Extensions\OnboardingPro\System\Domain\Rules\PrerequisiteEvaluator;
use App\Extensions\OnboardingPro\System\Domain\Rules\RuleEvaluator;
use App\Extensions\OnboardingPro\System\Services\DeltaJourneyPlanner;

$fail = [];
$rules = new RuleEvaluator();
$context = [
    'worker.role' => 'cleaner',
    'worker.service_types' => ['commercial','ndis'],
    'worker.drives' => false,
];
if (!$rules->evaluate('worker.role = cleaner', $context)) $fail[] = 'equals rule failed';
if (!$rules->evaluate('worker.service_types includes ndis', $context)) $fail[] = 'includes rule failed';
if (!$rules->evaluate('worker.role != electrician', $context)) $fail[] = 'not-equals rule failed';
if ($rules->evaluate('worker.drives = true', $context)) $fail[] = 'boolean equals rule failed';
if (!$rules->evaluate(['worker.role' => 'cleaner'], $context)) $fail[] = 'map condition failed';
if (!$rules->evaluate('host-derived natural language condition', $context)) $fail[] = 'unknown natural-language rule should preserve visibility';

$prereqs = new PrerequisiteEvaluator();
$unmet = $prereqs->unmet(['core','manager-approval'], ['core']);
if ($unmet !== ['manager-approval']) $fail[] = 'prerequisite evaluation mismatch';

$steps = [
    ['key' => 'core', 'conditions' => []],
    ['key' => 'ndis', 'conditions' => ['worker.service_types includes ndis'], 'prerequisites' => ['core']],
    ['key' => 'vehicle', 'conditions' => ['worker.drives = true'], 'prerequisites' => ['core']],
];
$planner = new DeltaJourneyPlanner($rules, $prereqs);
$applicable = $planner->applicableStepKeys($steps, $context);
if ($applicable !== ['core','ndis']) $fail[] = 'applicable step set mismatch';
$delta = $planner->plan($steps, $context, ['core'], ['core','ndis']);
if ($delta !== []) $fail[] = 'delta should be empty before role/context change';
$context['worker.drives'] = true;
$delta = $planner->plan($steps, $context, ['core'], ['core','ndis']);
if (count($delta) !== 1 || ($delta[0]['step_key'] ?? null) !== 'vehicle' || ($delta[0]['reason'] ?? null) !== 'newly_applicable') $fail[] = 'delta journey did not add newly applicable step';
if (($delta[0]['unmet_prerequisites'] ?? null) !== []) $fail[] = 'completed prerequisite should not block delta step';

if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "branching delta PASS\n";
