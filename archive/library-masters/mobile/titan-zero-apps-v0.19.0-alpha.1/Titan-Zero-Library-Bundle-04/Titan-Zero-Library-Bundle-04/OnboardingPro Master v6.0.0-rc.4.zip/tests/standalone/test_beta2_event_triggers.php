<?php
$root=dirname(__DIR__,2);
foreach(['/System/Automation/OnboardingTrigger.php','/System/Automation/TriggerEvaluation.php','/System/Automation/TriggerRegistry.php','/System/Automation/TriggerEvaluator.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Automation\OnboardingTrigger;
use App\Extensions\OnboardingPro\System\Automation\TriggerRegistry;
use App\Extensions\OnboardingPro\System\Automation\TriggerEvaluator;
$reg=TriggerRegistry::withDefaults();
$e=new TriggerEvaluator($reg);
$a=$e->evaluate('employee.created',44,'worker:91',['role'=>'cleaner'],'journey.employee.cleaner');
$b=$e->evaluate('employee.created',44,'worker:91',['role'=>'cleaner'],'journey.employee.cleaner');
if(!$a->matched||$a->idempotencyKey!==$b->idempotencyKey)exit(2);
if($a->companyId!==44||$a->eventType!=='employee.created')exit(3);
echo "beta2 event triggers PASS\n";
