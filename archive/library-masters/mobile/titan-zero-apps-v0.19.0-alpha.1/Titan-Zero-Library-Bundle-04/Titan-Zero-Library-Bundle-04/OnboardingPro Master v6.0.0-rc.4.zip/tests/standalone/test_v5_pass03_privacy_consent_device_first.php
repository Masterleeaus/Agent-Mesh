<?php
$root=dirname(__DIR__,2);
$req=['System/Privacy/DiscoveryConsentService.php','System/Privacy/DiscoveryExecutionPolicy.php','System/Persistence/Models/DiscoveryConsentReceipt.php'];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$c=file_get_contents($root.'/System/Privacy/DiscoveryConsentService.php');$p=file_get_contents($root.'/System/Privacy/DiscoveryExecutionPolicy.php');
$checks=[str_contains($c,'public_internet'),str_contains($c,'selected_files'),str_contains($c,'camera_vision'),str_contains($c,'connected_systems'),str_contains($c,'purpose'),str_contains($c,'revoked_at'),str_contains($c,'expires_at'),str_contains($p,'device'),str_contains($p,'byo'),str_contains($p,'customer_paid'),str_contains($p,'titan_paid'),str_contains($p,'company_id')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 3 privacy contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 3 privacy consent and device-first discovery\n";
