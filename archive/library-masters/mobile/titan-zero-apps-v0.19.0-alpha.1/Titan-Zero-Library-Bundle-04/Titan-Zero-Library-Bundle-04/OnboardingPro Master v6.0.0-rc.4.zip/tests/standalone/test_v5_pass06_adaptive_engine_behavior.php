<?php
$root=dirname(__DIR__,2);
require_once $root.'/System/Adaptive/AdaptiveQuestionCatalog.php';
require_once $root.'/System/Adaptive/BusinessKnowledgeGapResolver.php';
require_once $root.'/System/Adaptive/InformationGainScorer.php';
require_once $root.'/System/Adaptive/AdaptiveOnboardingEngine.php';

use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveQuestionCatalog;
use App\Extensions\OnboardingPro\System\Adaptive\BusinessKnowledgeGapResolver;
use App\Extensions\OnboardingPro\System\Adaptive\InformationGainScorer;
use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveOnboardingEngine;

$engine=new AdaptiveOnboardingEngine(
    new AdaptiveQuestionCatalog(),
    new BusinessKnowledgeGapResolver(),
    new InformationGainScorer()
);

$seed=['business_identity'=>['name'=>'Green Planet Cleaning']];
$first=$engine->next($seed,[],[],null,'AU','pwa');
if(($first['question']['key']??null)!=='business_services'){
    throw new RuntimeException('Expected highest-value services question first.');
}

$afterServices=$engine->applyAnswer(
    $seed,
    'business_services',
    ['services'=>['regular cleaning','end of lease cleaning']],
    'answered',
    [],[],null,'AU','chat'
);
if(($afterServices['resolved_by_answer']??0)<1){
    throw new RuntimeException('Answer should resolve at least its own knowledge gap.');
}
if(($afterServices['after']['surface']??null)!=='chat'){
    throw new RuntimeException('Surface-neutral engine failed chat surface propagation.');
}

$facts=array_merge($seed,$afterServices['derived_facts']);
$next=$engine->next($facts,['business_services'],[],null,'AU','voice');
if(($next['question']['key']??null)!=='business_location'){
    throw new RuntimeException('Jurisdiction should outrank lower-value nonblocking questions after services.');
}

$deferred=$engine->applyAnswer($facts,'business_location',null,'deferred',['business_services'],[],null,'AU','vision');
if(($deferred['answer_state']??null)!=='deferred'){
    throw new RuntimeException('Deferred state not preserved.');
}

echo "PASS: v5 Pass 6 adaptive engine behavior\n";
