<?php
$root=dirname(__DIR__,2);
foreach([
'/System/Domain/Renewals/RenewalRequirement.php',
'/System/Domain/Renewals/RenewalPlan.php',
'/System/Services/RenewalScheduler.php',
] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}

use App\Extensions\OnboardingPro\System\Domain\Renewals\RenewalRequirement;
use App\Extensions\OnboardingPro\System\Services\RenewalScheduler;

$fail=[];
$r=new RenewalRequirement('req-1',44,'worker','91','licence','ev-1',new DateTimeImmutable('2026-10-01T00:00:00Z'),60,'journey:licence-renewal');
$s=new RenewalScheduler();
$a=$s->plan($r,new DateTimeImmutable('2026-08-15T00:00:00Z'));
$b=$s->plan($r,new DateTimeImmutable('2026-08-15T00:00:00Z'));
if(!$a->due||$a->idempotencyKey!==$b->idempotencyKey)$fail[]='renewal plan not deterministic';
if($a->targetJourneyKey!=='journey:licence-renewal')$fail[]='journey target mismatch';
$c=$s->plan($r,new DateTimeImmutable('2026-06-01T00:00:00Z'));
if($c->due)$fail[]='renewal planned too early';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "renewal engine PASS\n";
