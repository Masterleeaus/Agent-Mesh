<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$files=['System/Persistence/Models/NexusApprovalRecord.php','System/Discovery/Nexus/NexusApprovalService.php','System/Discovery/Nexus/NexusProvisioningPlanService.php'];
foreach($files as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 8 file: $f\n");exit(1);}}
$a=file_get_contents($root.'/System/Discovery/Nexus/NexusApprovalService.php');
$p=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningPlanService.php');
$c=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
$r=file_get_contents($root.'/routes/user.php');
$checks=['approval fingerprints preview'=>str_contains($a,'preview_fingerprint'),'approval records actor'=>str_contains($a,'approved_by_user_id'),'approval company scoped'=>str_contains($a,'company_id'),'plan compiles draft'=>str_contains($p,'compileDraft'),'plan calls planProvisioning'=>str_contains($p,'planProvisioning'),'plan requires approval'=>str_contains($p,'approved'),'plan does not execute'=>!str_contains($p,'executeProvisioning('),'controller approval endpoint'=>str_contains($c,'approveNexusConfiguration'),'controller planning endpoint'=>str_contains($c,'planNexusProvisioning'),'routes approval'=>str_contains($r,'nexus/approve'),'routes plan'=>str_contains($r,'nexus/plan')];
$f=[];foreach($checks as $k=>$v)if(!$v)$f[]=$k;
if($f){fwrite(STDERR,"Pass 8 failed:\n - ".implode("\n - ",$f)."\n");exit(1);}
echo "PASS: Pass 8 owner approval and governed provisioning plan\n";
