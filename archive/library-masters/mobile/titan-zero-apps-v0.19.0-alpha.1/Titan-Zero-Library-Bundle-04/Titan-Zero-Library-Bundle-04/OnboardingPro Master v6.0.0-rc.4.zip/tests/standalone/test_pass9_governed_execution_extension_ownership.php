<?php
$root=dirname(__DIR__,2);
foreach(['System/Discovery/Nexus/NexusProvisioningExecutionService.php','System/Persistence/Models/NexusExecutionRecord.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 9 file: $f\n");exit(1);}}
$s=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningExecutionService.php');$g=file_get_contents($root.'/System/Discovery/Nexus/NexusRuntimeGatewayInterface.php');$c=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
$checks=[str_contains($s,'executeProvisioning'),str_contains($s,"status!=='planned'"),str_contains($s,'idempotency_key'),str_contains($s,'company_id'),str_contains($s,'authoritative_writes'),str_contains($s,'DIRECT_EXTENSION_WRITE_FORBIDDEN'),str_contains($g,'executeProvisioning'),str_contains($c,'executeNexusProvisioning')];
foreach($checks as $v)if(!$v){fwrite(STDERR,"Pass 9 contract not implemented\n");exit(1);} echo "PASS: Pass 9 governed execution and extension ownership\n";
