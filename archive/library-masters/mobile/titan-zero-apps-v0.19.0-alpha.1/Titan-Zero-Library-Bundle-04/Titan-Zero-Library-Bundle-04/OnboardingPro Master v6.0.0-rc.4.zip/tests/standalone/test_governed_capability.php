<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Domain\Capabilities\OnboardingCapabilityAction;
use App\Extensions\OnboardingPro\System\Domain\Capabilities\OnboardingCapabilityPolicy;
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\CapabilityExecutionBridge;
use App\Extensions\OnboardingPro\System\Contracts\InteractionCapabilityGatewayInterface;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
final class FakeGateway implements InteractionCapabilityGatewayInterface {public array $calls=[]; public function status(string $c,array $x):array{return ['availability'=>'available'];} public function execute(string $c,array $p,array $x):array{$this->calls[]=[$c,$p,$x];return ['status'=>'completed','provider'=>'crm','data'=>['id'=>123]];}}
$ctx=new JourneyExecutionContext(42,'enr-1','jv-1','worker-1','mgr-2','manager',['manager'],'web','corr-2');
$gateway=new FakeGateway();$bridge=new CapabilityExecutionBridge($gateway,new OnboardingCapabilityPolicy());
$action=new OnboardingCapabilityAction('crm.worker.credential.accept',['credential_id'=>88],'high','idem-1');
try{$bridge->execute($action,$ctx,[]);throw new RuntimeException('high risk ran without approval');}catch(DomainException $e){}
$r=$bridge->execute($action,$ctx,['approved'=>true,'approval_id'=>'ap-1','approved_by'=>'mgr-2']);
if($r->status!=='completed'||$r->capabilityId!=='crm.worker.credential.accept')throw new RuntimeException('receipt');
if(($gateway->calls[0][2]['company_id']??null)!==42||($gateway->calls[0][2]['idempotency_key']??'')!=='idem-1')throw new RuntimeException('trusted context');
if(($r->approvalEvidence['approval_id']??'')!=='ap-1')throw new RuntimeException('approval provenance');
echo "test_governed_capability PASS\n";
