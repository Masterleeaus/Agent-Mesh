<?php
$root=dirname(__DIR__,2);
$file=$root.'/database/migrations/2026_08_11_050500_create_ext_onboarding_trust_learning_tables.php';
if(!is_file($file)){fwrite(STDERR,"alpha4 migration missing\n");exit(1);} $s=file_get_contents($file);
$tables=[
'ext_onboarding_evidence','ext_onboarding_acknowledgements','ext_onboarding_signatures','ext_onboarding_approvals',
'ext_onboarding_followups','ext_onboarding_renewals','ext_onboarding_courses','ext_onboarding_lessons',
'ext_onboarding_assessments','ext_onboarding_attempts','ext_onboarding_practical_signoffs','ext_onboarding_certificates'
];
$fail=[];
foreach($tables as $table){if(!str_contains($s,$table))$fail[]="missing table $table";}
if(!str_contains($s,'function down'))$fail[]='down missing';
if(!str_contains($s,'company_id'))$fail[]='tenant scope missing';
if(!str_contains($s,'content_hash'))$fail[]='evidence hash missing';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "alpha4 migrations PASS\n";
