<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{
    $p='App\\Extensions\\OnboardingPro\\';
    if(str_starts_with($class,$p)){
        $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php';
        if(is_file($f)) require $f;
    }
});

$required=[
    'System/Discovery/BusinessSetupService.php',
    'System/Discovery/BusinessSetupState.php',
    'System/Http/Controllers/BusinessSetupController.php',
    'resources/views/business-setup/index.blade.php',
];
foreach($required as $rel){
    if(!is_file($root.'/'.$rel)) throw new RuntimeException("Pass 3 file missing: $rel");
}

use App\Extensions\OnboardingPro\System\Discovery\ProgressiveReadinessEvaluator;

$evaluator=new ProgressiveReadinessEvaluator();
$partial=[
    'business_identity'=>['name'=>'Acme'],
    'industry'=>'cleaning',
    'services'=>['commercial cleaning'],
    'jurisdiction'=>['country'=>'AU'],
    'size'=>'small',
    'privacy_preferences'=>['analytics'=>false],
];
$result=$evaluator->evaluatePayload($partial, []);
if(!$result->minimumReady) throw new RuntimeException('Minimum discovery should accept the complete minimum stage.');
if($result->operationalReady) throw new RuntimeException('Operational readiness must remain false while operational domains are incomplete.');
$deferred=['service_areas','operating_hours','pricing','job_lifecycle','communications'];
$deferredResult=$evaluator->evaluatePayload($partial, $deferred);
if(!$deferredResult->operationalReady) throw new RuntimeException('Explicitly deferred optional operational domains must not block operational readiness.');
foreach($deferred as $domain){
    if(in_array($domain,$deferredResult->remainingDomains,true)) throw new RuntimeException("Deferred domain remained blocking: $domain");
}

$routes=file_get_contents($root.'/routes/user.php');
foreach(['BusinessSetupController','ResolveOnboardingCompany','dashboard/onboarding','business-setup','profile','domains/{domain}/defer'] as $needle){
    if(!str_contains($routes,$needle)) throw new RuntimeException("Owner business setup route missing $needle");
}

$controller=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
foreach(['function show','function save','function defer','expected_revision','BusinessSetupService','OnboardingTraceContext'] as $needle){
    if(!str_contains($controller,$needle)) throw new RuntimeException("Business setup controller missing $needle");
}

$service=file_get_contents($root.'/System/Discovery/BusinessSetupService.php');
foreach(['BusinessDiscoveryJourneyFactory','DiscoveryProfileService','saveSection','deferDomain','expectedRevision','latest','deferred_domains'] as $needle){
    if(!str_contains($service,$needle)) throw new RuntimeException("Business setup service missing $needle");
}

$profileService=file_get_contents($root.'/System/Discovery/DiscoveryProfileService.php');
if(!str_contains($profileService,'saveProgressiveDraft')) throw new RuntimeException('Discovery profile service must persist partial/progressive drafts.');

$provider=file_get_contents($root.'/System/OnboardingProServiceProvider.php');
foreach(['BusinessSetupService','BusinessSetupController'] as $needle){
    if(!str_contains($provider,$needle)) throw new RuntimeException("Service provider missing Pass 3 wiring for $needle");
}

$view=file_get_contents($root.'/resources/views/business-setup/index.blade.php');
foreach(['Save and continue','Save for later','defer','minimum-discovery','operational-discovery','continuous-discovery'] as $needle){
    if(!str_contains($view,$needle)) throw new RuntimeException("Owner setup view missing $needle");
}

echo "test_pass3_owner_business_setup PASS\n";
