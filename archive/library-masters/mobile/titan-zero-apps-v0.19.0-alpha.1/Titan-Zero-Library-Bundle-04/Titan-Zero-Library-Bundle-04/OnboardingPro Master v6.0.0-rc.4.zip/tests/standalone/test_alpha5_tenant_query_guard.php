<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingActorContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingScope;
use App\Extensions\OnboardingPro\System\Tenancy\TenantReadGuard;
$scope=new OnboardingScope(new OnboardingCompanyContext(44,new OnboardingActorContext(91)));
$guard=new TenantReadGuard($scope);
foreach(['journey','enrolment','discovery','evidence','approval','learning','certificate','renewal'] as $domain){$q=$guard->constraints($domain,['status'=>'active']);if(($q['company_id']??null)!==44)throw new RuntimeException("tenant missing: $domain");}
try{$guard->assertRecord(['company_id'=>45,'id'=>1]);throw new RuntimeException('cross tenant record accepted');}catch(DomainException){}
$guard->assertRecord(['company_id'=>44,'id'=>1]);
echo "test_alpha5_tenant_query_guard PASS\n";
