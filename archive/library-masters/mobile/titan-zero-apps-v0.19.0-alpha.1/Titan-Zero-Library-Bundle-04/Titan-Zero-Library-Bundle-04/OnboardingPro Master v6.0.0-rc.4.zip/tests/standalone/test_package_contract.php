<?php
$root = dirname(__DIR__, 2);
$fail = [];
$raw = file_get_contents($root . '/extension.json');
if (str_starts_with($raw, "\xEF\xBB\xBF")) $fail[] = 'extension.json must not have UTF-8 BOM';
$m = json_decode($raw, true);
if (!is_array($m)) $fail[] = 'extension.json must parse';
$expected = [
    'schema' => 'titan-extension-v1',
    'slug' => 'onboarding-pro',
    'name' => 'Titan Onboarding',
    'version' => '6.0.0-rc.3',
    'folder' => 'OnboardingPro',
    'provider' => 'App\\Extensions\\OnboardingPro\\System\\OnboardingProServiceProvider',
];
foreach ($expected as $k => $v) if (($m[$k] ?? null) !== $v) $fail[] = "$k mismatch";
if (($m['migrations'] ?? null) !== true) $fail[] = 'migrations must be true';
if (!is_array($m['dependencies'] ?? null) || array_is_list($m['dependencies']) === false) $fail[] = 'dependencies must be an array';
if (!is_array($m['optional_dependencies'] ?? null) || array_is_list($m['optional_dependencies']) === false) $fail[] = 'optional_dependencies must be an array';
if (($m['requires']['php'] ?? null) !== '>=8.2') $fail[] = 'requires.php mismatch';
if (($m['requires']['magicai'] ?? null) !== '>=10.91') $fail[] = 'requires.magicai mismatch';
if (!isset($m['integrity']['files']) || !is_array($m['integrity']['files'])) $fail[] = 'integrity.files missing';
if (!is_array($m['publishes'] ?? null)) $fail[] = 'publishes must be an array';
$provider = $root . '/System/OnboardingProServiceProvider.php';
if (!is_file($provider)) $fail[] = 'provider file missing';
$text = is_file($provider) ? file_get_contents($provider) : '';
if (!str_contains($text, 'namespace App\\Extensions\\OnboardingPro\\System;')) $fail[] = 'provider namespace mismatch';
if (!preg_match('/class\s+OnboardingProServiceProvider\b/', $text)) $fail[] = 'provider class mismatch';
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "package contract PASS\n";
