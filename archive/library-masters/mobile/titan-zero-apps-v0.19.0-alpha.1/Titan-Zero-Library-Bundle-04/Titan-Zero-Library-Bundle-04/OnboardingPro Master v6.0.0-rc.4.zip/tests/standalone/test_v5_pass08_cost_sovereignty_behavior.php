<?php
$root=dirname(__DIR__,2);
require_once $root.'/System/Discovery/Nexus/NexusCostSovereigntyPolicy.php';

use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusCostSovereigntyPolicy;

$p=new NexusCostSovereigntyPolicy();

$core=$p->route(['no_external_resource'=>true]);
if(($core['execution_location']??null)!=='titan_software_core'||($core['cost_owner']??null)!=='none'||($core['blocked']??true)!==false){
    throw new RuntimeException('Core software capability must remain separate from external resource cost routing.');
}

$r=$p->route(['execution_paths'=>['device'=>true,'local'=>true,'byo'=>true,'titan_metered'=>true]]);
if(($r['execution_location']??null)!=='device') throw new RuntimeException('Device path must win canonical routing order.');

$r=$p->route(['execution_paths'=>['local'=>true,'byo'=>true,'titan_metered'=>true]]);
if(($r['execution_location']??null)!=='local') throw new RuntimeException('Local path must precede BYO/Titan-paid routes.');

$r=$p->route(['execution_paths'=>['byo'=>true,'titan_metered'=>true]]);
if(($r['execution_location']??null)!=='byo'||($r['cost_owner']??null)!=='customer') throw new RuntimeException('BYO must precede Titan-paid resource.');

$r=$p->route(['execution_paths'=>['titan_entitlement'=>true],'entitlement_active'=>false,'required_entitlement'=>'titan.system_ai.standard']);
if(($r['blocked']??false)!==true||($r['reason']??null)!=='TITAN_ENTITLEMENT_REQUIRED') throw new RuntimeException('Inactive Titan entitlement must fail closed.');

$r=$p->route(['execution_paths'=>['titan_metered'=>true],'explicit_opt_in'=>false,'metered_purchase_active'=>true]);
if(($r['blocked']??false)!==true||($r['reason']??null)!=='TITAN_METERED_EXPLICIT_OPT_IN_REQUIRED') throw new RuntimeException('Titan metered path must require explicit opt-in even if purchased.');

$r=$p->route(['execution_paths'=>['titan_metered'=>true],'explicit_opt_in'=>true,'metered_purchase_active'=>true]);
if(($r['blocked']??true)!==false||($r['execution_location']??null)!=='titan_metered') throw new RuntimeException('Explicit purchased Titan metered route should be available.');

echo "PASS: v5 Pass 8 cost sovereignty behavior\n";
