<?php
$root=dirname(__DIR__,2);$fail=[];
$f=$root.'/System/Http/Middleware/ParticipantGrantMiddleware.php';$txt=is_file($f)?file_get_contents($f):'';
foreach(['ParticipantGrantRecord','token_hash','revoked_at','expires_at'] as $needle)if(!str_contains($txt,$needle))$fail[]="participant middleware missing $needle";
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "beta1 participant revocation contract PASS\n";
