<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingDecisionReceipt;
$trace=new OnboardingTraceContext('trace-x','corr-x','cause-x',9,44);
$r=OnboardingDecisionReceipt::create('onboarding.minimum_ready',$trace,['reason_codes'=>['MINIMUM_DISCOVERY_COMPLETE'],'evidence_refs'=>['profile:abc'],'policy_version'=>'onboarding-discovery-v1']);
$a=$r->toArray();
if($a['trace_id']!=='trace-x'||$a['company_id']!==9) throw new RuntimeException('trace');
if(isset($a['chain_of_thought'])||isset($a['reasoning'])) throw new RuntimeException('hidden reasoning must not be stored');
if(($a['reason_codes'][0]??'')!=='MINIMUM_DISCOVERY_COMPLETE') throw new RuntimeException('structured rationale missing');
echo "test_signal_rewind_receipt PASS\n";
