<?php
$root = dirname(__DIR__, 2);
$files = [
    '/System/Domain/Journeys/Journey.php',
    '/System/Domain/Journeys/JourneyVersionState.php',
    '/System/Domain/Journeys/JourneyVersion.php',
    '/System/Domain/Journeys/JourneyRepository.php',
];
foreach ($files as $file) {
    if (!is_file($root . $file)) { fwrite(STDERR, "missing production file: $file\n"); exit(1); }
    require_once $root . $file;
}
require_once $root . '/System/Tenancy/OnboardingActorContext.php';
require_once $root . '/System/Tenancy/OnboardingCompanyContext.php';
require_once $root . '/System/Tenancy/OnboardingScope.php';

use App\Extensions\OnboardingPro\System\Domain\Journeys\Journey;
use App\Extensions\OnboardingPro\System\Domain\Journeys\JourneyRepository;
use App\Extensions\OnboardingPro\System\Domain\Journeys\JourneyVersion;
use App\Extensions\OnboardingPro\System\Domain\Journeys\JourneyVersionState;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingActorContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingScope;

$fail = [];
$journey = new Journey(44, 'employee-induction', 'Employee Induction', 'employee');
if ($journey->companyId !== 44 || $journey->key !== 'employee-induction') $fail[] = 'journey identity mismatch';

$draft = JourneyVersion::draft(44, 'employee-induction', 1, [
    'steps' => [['key' => 'welcome', 'type' => 'information']],
]);
if ($draft->state !== JourneyVersionState::Draft || $draft->revision !== 1) $fail[] = 'draft state mismatch';
$revised = $draft->revise(['steps' => [['key' => 'welcome', 'type' => 'information'], ['key' => 'policy', 'type' => 'document']]]);
if ($revised->revision !== 2 || $revised->contentHash === $draft->contentHash) $fail[] = 'draft revision did not change';
if (!method_exists($revised, 'reviseIfRevision')) { $fail[] = 'optimistic revision API missing'; } else {
    try { $revised->reviseIfRevision(1, ['steps' => []]); $fail[] = 'stale revision accepted'; } catch (RuntimeException) {}
    $r3 = $revised->reviseIfRevision(2, ['steps' => [['key' => 'welcome', 'type' => 'information']]]);
    if ($r3->revision !== 3) $fail[] = 'matching optimistic revision did not advance';
}
$published = $revised->publish(new DateTimeImmutable('2026-08-11T05:00:00Z'));
if ($published->state !== JourneyVersionState::Published || $published->publishedAt?->format(DATE_ATOM) !== '2026-08-11T05:00:00+00:00') $fail[] = 'publish mismatch';
try { $published->revise(['steps' => []]); $fail[] = 'published version was mutable'; } catch (LogicException) {}
$next = $published->nextDraft(['steps' => [['key' => 'welcome', 'type' => 'information']]]);
if ($next->versionNumber !== 2 || $next->state !== JourneyVersionState::Draft || $next->revision !== 1) $fail[] = 'next draft mismatch';
$superseded = $published->supersede();
if ($superseded->state !== JourneyVersionState::Superseded) $fail[] = 'supersede mismatch';

$scope = new OnboardingScope(new OnboardingCompanyContext(44, new OnboardingActorContext(91)));
$repo = new JourneyRepository($scope);
$constraints = $repo->constraints(['status' => 'published']);
if (($constraints['company_id'] ?? null) !== 44 || ($constraints['status'] ?? null) !== 'published') $fail[] = 'repository scope mismatch';

if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "journey domain PASS\n";
