<?php
$root=dirname(__DIR__,2);
$req=['System/Connections/ExistingSystemDiscoveryGatewayInterface.php','System/Connections/ExistingSystemDiscoveryService.php','System/Connections/ExistingSystemMappingService.php','System/Persistence/Models/ExistingSystemConnection.php','System/Persistence/Models/ExistingSystemMapping.php'];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$d=file_get_contents($root.'/System/Connections/ExistingSystemDiscoveryService.php');
$m=file_get_contents($root.'/System/Connections/ExistingSystemMappingService.php');
$checks=[str_contains($d,'connected_systems'),str_contains($d,'read_only'),str_contains($d,'crm'),str_contains($d,'accounting'),str_contains($d,'booking'),str_contains($d,'calendar'),str_contains($d,'field_service'),str_contains($d,'communications'),str_contains($d,'company_id'),str_contains($m,'map'),str_contains($m,'compare'),str_contains($m,'confirm'),str_contains($m,'duplicate'),str_contains($m,'conflict'),!str_contains($d,'delete('),!str_contains($d,'updateAuthoritative')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 5 read-only discovery/mapping contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 5 existing-system read-only discovery and migration mapping\n";
