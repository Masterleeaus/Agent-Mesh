<?php
$root=dirname(__DIR__,2);
foreach(['/System/Templates/VerticalPack.php','/System/Templates/VerticalPackRegistry.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Templates\VerticalPackRegistry;
$r=VerticalPackRegistry::withTitanDefaults();
foreach(['cleaning','plumbing','electrical','hvac','landscaping','pest-control','roofing','appliance-repair','ndis-home-maintenance','facilities','hospitality','real-estate'] as $slug){if(!$r->has($slug)){fwrite(STDERR,"missing $slug\n");exit(2);}}
$p=$r->get('plumbing');
if(!in_array('employee-induction',$p->journeyFamilies,true))exit(3);
echo "beta2 vertical packs PASS\n";
