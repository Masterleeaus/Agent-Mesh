<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BootstrapIntent;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
$trace=new OnboardingTraceContext('t','c','cause',5,8);
$i=BootstrapIntent::prepare('nexus','compile_business_configuration',['industry'=>'cleaning'],$trace,'idem-x');
$a=$i->toArray();
if(($a['status']??'')!=='PREPARED') throw new RuntimeException('intent must only prepare');
if(($a['direct_mutation']??true)!==false) throw new RuntimeException('direct mutation forbidden');
if(($a['target_engine']??'')!=='nexus') throw new RuntimeException('target');
if(($a['idempotency_key']??'')!=='idem-x') throw new RuntimeException('idempotency');
echo "test_bootstrap_boundary PASS\n";
