<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$mig=$root.'/database/migrations/2026_08_11_050400_create_ext_onboarding_discovery_tables.php';
if(!is_file($mig)) throw new RuntimeException('discovery migration missing');
$s=file_get_contents($mig);
foreach(['ext_onboarding_discovery_profiles','ext_onboarding_bootstrap_intents','company_id','trace_id','correlation_id','causation_id','idempotency_key','profile_hash','minimum_ready','operational_ready'] as $needle){if(!str_contains($s,$needle)) throw new RuntimeException("migration missing $needle");}
if(!str_contains($s,'function down')) throw new RuntimeException('migration down missing');
echo "test_discovery_persistence_schema PASS\n";
