<?php
$root=dirname(__DIR__,2);
foreach(['/System/Integrations/Platform/IntegrationRequest.php','/System/Integrations/Platform/PlatformIntegrationRegistry.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Integrations\Platform\PlatformIntegrationRegistry;
$r=PlatformIntegrationRegistry::withTitanDefaults();
foreach(['crm','builder','titan-ai','connect','titan-go'] as $key){$x=$r->prepare($key,44,'onboarding.bootstrap',['subject'=>'business:44'],'trace-z');if($x->status!=='PREPARED'||$x->directMutation!==false||$x->companyId!==44)exit(2);}
echo "beta2 platform integrations PASS\n";
