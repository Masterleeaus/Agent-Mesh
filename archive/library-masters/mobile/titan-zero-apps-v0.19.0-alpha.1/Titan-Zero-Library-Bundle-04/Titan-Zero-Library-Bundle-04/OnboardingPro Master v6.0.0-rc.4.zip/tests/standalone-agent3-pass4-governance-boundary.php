<?php
$root=dirname(__DIR__);
$gate=file_get_contents($root.'/System/Providers/ProviderAuthorityGate.php');
$fabric=file_get_contents($root.'/System/Providers/ProviderActionFabric.php');
$lifecycle=file_get_contents($root.'/System/Execution/InterventionExecutionLifecycleService.php');
$config=file_get_contents($root.'/config/onboarding-pro.php');
$controller=file_get_contents($root.'/System/Http/Controllers/ProviderActionController.php');
$checks=[
 str_contains($gate,'awaiting_governance'),
 str_contains($gate,'caller-supplied authority is non-authoritative'),
 str_contains($fabric,"'status'=>\$status"),
 str_contains($fabric,"'requires_approval'=>true"),
 str_contains($fabric,"'caller_authority_ignored'=>true"),
 str_contains($lifecycle,"\$a->status!=='governed'"),
 str_contains($lifecycle,'platform governance decision before execution lifecycle may start'),
 str_contains($config,'TITAN_ONBOARDING_LEGACY_SELF_ASSERTED_AUTHORITY_ENABLED'),
 str_contains($controller,"'authority'=>['nullable','array']"), // compatibility input may still arrive, but is ignored by default.
];
foreach($checks as $ok){if(!$ok){fwrite(STDERR,"FAIL: Agent 3 Pass 4 governance-boundary regression\n");exit(1);}}
echo "PASS: Agent 3 Pass 4 governance-boundary regression\n";
