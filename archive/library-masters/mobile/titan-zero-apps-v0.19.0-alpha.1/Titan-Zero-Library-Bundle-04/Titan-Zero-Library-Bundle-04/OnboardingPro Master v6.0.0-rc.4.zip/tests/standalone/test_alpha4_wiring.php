<?php
$root=dirname(__DIR__,2);$p=$root.'/System/OnboardingProServiceProvider.php';$s=file_get_contents($p);$fail=[];
foreach([
'AssuranceEvidenceAdapter','EvidenceValidationService','RenewalScheduler','LearningCompletionService','CertificateService'
] as $class){if(!str_contains($s,$class))$fail[]="provider missing $class";}
foreach([
'/System/Domain/Evidence/EvidenceRecord.php','/System/Domain/Trust/AcknowledgementReceipt.php','/System/Domain/Renewals/RenewalRequirement.php','/System/Domain/Learning/Course.php','/System/Domain/Learning/Certificate.php'
] as $f){if(!is_file($root.$f))$fail[]="missing $f";}
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "alpha4 wiring PASS\n";
