<?php
$root=dirname(__DIR__,2);
foreach(['/System/Notifications/OnboardingNotification.php','/System/Notifications/NotificationPreferenceResolver.php','/System/Notifications/OnboardingNotificationService.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Notifications\OnboardingNotificationService;
$svc=new OnboardingNotificationService();
$a=$svc->prepare(44,'participant:91','journey_reminder','Please continue','email','trace-y');
$b=$svc->prepare(44,'participant:91','journey_reminder','Please continue','email','trace-y');
if($a->idempotencyKey!==$b->idempotencyKey)exit(2);
if($a->capability!=='message.prepare'||$a->status!=='PREPARED')exit(3);
echo "beta2 notifications PASS\n";
