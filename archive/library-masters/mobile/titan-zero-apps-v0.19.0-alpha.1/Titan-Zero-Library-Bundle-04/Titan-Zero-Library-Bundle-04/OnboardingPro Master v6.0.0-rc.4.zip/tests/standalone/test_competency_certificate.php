<?php
$root=dirname(__DIR__,2);
foreach([
'/System/Domain/Learning/PracticalSignoff.php',
'/System/Domain/Learning/Certificate.php',
'/System/Services/CertificateService.php',
] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}

use App\Extensions\OnboardingPro\System\Domain\Learning\PracticalSignoff;
use App\Extensions\OnboardingPro\System\Services\CertificateService;

$fail=[];
$signoff=PracticalSignoff::record('ps-1',44,91,101,'chemical-handling','passed',['ev-photo'],new DateTimeImmutable('2026-08-11T10:20:00Z'));
$svc=new CertificateService();
$cert=$svc->issueIfEligible('cert-1',44,91,'chemical-safety-v1','v1',true,$signoff,new DateTimeImmutable('2026-08-11T10:21:00Z'),new DateTimeImmutable('2027-08-11T10:21:00Z'));
if($cert===null||$cert->subjectId!==91||$cert->expiresAt===null)$fail[]='eligible certificate not issued';
$failed=PracticalSignoff::record('ps-2',44,91,101,'chemical-handling','rework',[],new DateTimeImmutable('2026-08-11T10:22:00Z'));
if($svc->issueIfEligible('cert-2',44,91,'chemical-safety-v1','v1',true,$failed,new DateTimeImmutable('2026-08-11T10:23:00Z'))!==null)$fail[]='certificate issued without practical pass';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "competency certificate PASS\n";
