<?php
$root=dirname(__DIR__,2);
foreach(['System/Workforce/OnboardingWorkforceManifest.php','System/Events/OnboardingLifecycleEventRouter.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 11 file: $f\n");exit(1);}}
$w=file_get_contents($root.'/System/Workforce/OnboardingWorkforceManifest.php');$e=file_get_contents($root.'/System/Events/OnboardingLifecycleEventRouter.php');
$checks=[str_contains($w,'Onboarding Manager'),str_contains($w,'Setup Assistant'),str_contains($w,'Compliance Assistant'),str_contains($w,'Training Assistant'),str_contains($w,'Evidence Assistant'),str_contains($w,'Renewal Assistant'),str_contains($e,'company.created'),str_contains($e,'employee.created'),str_contains($e,'contractor.invited'),str_contains($e,'customer.service.changed'),str_contains($e,'credential.expiring'),str_contains($e,'employee.role.changed'),str_contains($e,'company_id')];
foreach($checks as $v)if(!$v){fwrite(STDERR,"Pass 11 contract not implemented\n");exit(1);}echo "PASS: Pass 11 Workforce and event integration\n";
