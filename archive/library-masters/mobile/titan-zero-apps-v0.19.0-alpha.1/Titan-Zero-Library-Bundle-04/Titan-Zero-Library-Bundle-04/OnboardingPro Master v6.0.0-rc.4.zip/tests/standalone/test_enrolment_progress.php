<?php
$root = dirname(__DIR__, 2);
$files = [
    '/System/Domain/Enrolment/EnrolmentStatus.php',
    '/System/Domain/Enrolment/StepInstanceStatus.php',
    '/System/Domain/Enrolment/EnrolmentState.php',
    '/System/Services/JourneyProgressService.php',
];
foreach ($files as $file) {
    if (!is_file($root . $file)) { fwrite(STDERR, "missing production file: $file\n"); exit(1); }
    require_once $root . $file;
}

use App\Extensions\OnboardingPro\System\Domain\Enrolment\EnrolmentState;
use App\Extensions\OnboardingPro\System\Domain\Enrolment\EnrolmentStatus;
use App\Extensions\OnboardingPro\System\Domain\Enrolment\StepInstanceStatus;
use App\Extensions\OnboardingPro\System\Services\JourneyProgressService;

$fail = [];
$service = new JourneyProgressService();
$state = $service->start(44, 'enr-001', 'journey-v1', 'participant-9', ['welcome','policy','finish']);
if ($state->status !== EnrolmentStatus::Active) $fail[] = 'enrolment did not start active';
if ($state->stepStatus('welcome') !== StepInstanceStatus::Available || $state->stepStatus('policy') !== StepInstanceStatus::Pending) $fail[] = 'initial step availability mismatch';

$state = $service->completeStep($state, 'welcome', ['viewed' => true], new DateTimeImmutable('2026-08-11T05:05:00Z'));
if ($state->stepStatus('welcome') !== StepInstanceStatus::Completed || $state->stepStatus('policy') !== StepInstanceStatus::Available) $fail[] = 'step completion did not advance';

$payload = $state->toArray();
$restored = EnrolmentState::fromArray($payload);
$serviceAfterRestart = new JourneyProgressService();
$restored = $serviceAfterRestart->completeStep($restored, 'policy', ['acknowledged' => true]);
$restored = $serviceAfterRestart->completeStep($restored, 'finish', ['done' => true]);
if ($restored->status !== EnrolmentStatus::Completed || $restored->progressPercent() !== 100) $fail[] = 'restored enrolment did not finish';
if (($restored->responses['policy']['acknowledged'] ?? null) !== true) $fail[] = 'response did not survive state transition';
try { $service->completeStep($restored, 'unknown', []); $fail[] = 'unknown step completed'; } catch (InvalidArgumentException) {}
try { $service->completeStep($restored, 'welcome', []); $fail[] = 'completed step completed twice'; } catch (LogicException) {}
try { $restored->assertCompany(45); $fail[] = 'foreign company accepted'; } catch (RuntimeException) {}

if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "enrolment progress PASS\n";
