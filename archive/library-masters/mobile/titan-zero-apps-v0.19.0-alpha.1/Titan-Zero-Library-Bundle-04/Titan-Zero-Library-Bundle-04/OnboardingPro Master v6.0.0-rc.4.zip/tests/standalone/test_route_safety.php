<?php
$root = dirname(__DIR__, 2);
$fail = [];
$files = [
    $root . '/routes/admin.php',
    $root . '/routes/user.php',
    $root . '/routes/participant.php',
    $root . '/routes/api.php',
];
foreach ($files as $f) if (!is_file($f)) $fail[] = 'missing route file: ' . basename($f);
$combined = '';
foreach ($files as $f) if (is_file($f)) $combined .= file_get_contents($f) . "\n";
if (preg_match('/->get\([^\n]*(delete|destroy|display|dismiss|submit|complete|approve|reject|save|update)/i', $combined)) $fail[] = 'mutating GET route detected';
if (!str_contains($combined, "RequireOnboardingAdmin::class")) $fail[] = 'admin middleware not wired';
if (!str_contains($combined, "ResolveOnboardingCompany::class")) $fail[] = 'company middleware not wired';
$provider = file_get_contents($root . '/System/OnboardingProServiceProvider.php');
if (str_contains($provider, "->name('onboarding-pro.banner.delete')") || str_contains($provider, "->name('onboarding-pro.survey.delete')")) $fail[] = 'legacy inline routes remain in provider';
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "route safety PASS\n";
