<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Domain\Journeys\JourneyVersion;
use App\Extensions\OnboardingPro\System\Domain\Enrolment\Enrolment;
$v1=JourneyVersion::draft(44,'worker-induction',1,['steps'=>[['key'=>'a']]])->publish(new DateTimeImmutable('2026-08-11T01:00:00Z'));
$e=new Enrolment('enr-1',44,'worker-induction','1','worker','91','active',new DateTimeImmutable('2026-08-11T01:05:00Z'));
try{$v1->revise(['steps'=>[['key'=>'b']]]);throw new RuntimeException('published mutable');}catch(LogicException){}
$v2=$v1->nextDraft(['steps'=>[['key'=>'a'],['key'=>'b']]])->publish(new DateTimeImmutable('2026-08-11T02:00:00Z'));
if($v2->versionNumber!==2)throw new RuntimeException('v2 not created');
if($e->journeyVersionId!=='1')throw new RuntimeException('existing enrolment repinned');
echo "test_alpha5_immutability_pinning PASS\n";
