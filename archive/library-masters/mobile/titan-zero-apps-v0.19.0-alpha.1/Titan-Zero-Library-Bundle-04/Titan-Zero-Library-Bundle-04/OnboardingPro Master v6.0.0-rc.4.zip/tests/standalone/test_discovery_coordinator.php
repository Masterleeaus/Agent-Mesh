<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryProfile;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCoordinator;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
$p=BusinessDiscoveryProfile::fromArray([
'business_identity'=>['name'=>'Acme'],'industry'=>'cleaning','services'=>['cleaning'],'service_areas'=>[['postcode'=>'3071']],
'jurisdiction'=>['country'=>'AU','state'=>'VIC'],'size'=>'micro','staff'=>['count'=>1],'operating_hours'=>['mon'=>['09:00','17:00']],
'pricing_approach'=>'fixed','job_lifecycle'=>['lead','job','invoice'],'communication_channels'=>['email'],'payment_methods'=>['bank_transfer'],
'equipment_assets'=>[],'compliance_requirements'=>[],'privacy_preferences'=>['device_first'=>true],'ai_provider_preferences'=>['mode'=>'byo'],
'autonomy_preferences'=>['default'=>'assist'],'risk_tolerance'=>['operations'=>'low']
]);
$t=new OnboardingTraceContext('t1','c1','cause1',7,9);
$c=new BusinessDiscoveryCoordinator();
$a=$c->prepare($p,$t)->toArray();
$b=$c->prepare($p,$t)->toArray();
if(($a['profile_hash']??'')===''||$a['profile_hash']!==$b['profile_hash']) throw new RuntimeException('deterministic profile hash');
if(count($a['bootstrap_intents']??[])!==4) throw new RuntimeException('pre-resolution discovery must prepare four non-Nexus engine intents');
$keys=array_column($a['bootstrap_intents'],'idempotency_key'); if(count(array_unique($keys))!==4) throw new RuntimeException('intent idempotency keys must be target-specific');
$targets=array_column($a['bootstrap_intents'],'target_engine'); if(in_array('nexus',$targets,true)) throw new RuntimeException('Nexus must remain gated before canonical vertical resolution');
foreach($a['bootstrap_intents'] as $i){if(($i['direct_mutation']??true)!==false||($i['status']??'')!=='PREPARED') throw new RuntimeException('bootstrap must be prepare-only');}
$events=array_column($a['signal_receipts']??[],'event_type');
foreach(['onboarding.discovery.updated','onboarding.minimum_ready','onboarding.bootstrap.prepared','onboarding.progressive_setup.recommended','onboarding.vertical_resolution.required'] as $e){if(!in_array($e,$events,true)) throw new RuntimeException("missing signal receipt $e");}
echo "test_discovery_coordinator PASS\n";
