<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Requirements\RequirementDefinition;
use App\Extensions\OnboardingPro\System\Requirements\RequirementDependencyGraph;
use App\Extensions\OnboardingPro\System\Requirements\ParticipantAchievement;
$defs=[
 new RequirementDefinition('licence',[],[],null),
 new RequirementDefinition('safety',[],[],null),
 new RequirementDefinition('ndis_training',['safety'],[],null),
];
$g=new RequirementDependencyGraph($defs);
$ach=[new ParticipantAchievement('licence','v1',new DateTimeImmutable('2026-01-01T00:00:00Z'),null),new ParticipantAchievement('safety','v1',new DateTimeImmutable('2026-01-01T00:00:00Z'),null)];
$d=$g->delta(['licence','safety','ndis_training'],$ach,new DateTimeImmutable('2026-08-11T00:00:00Z'));
if($d!==['ndis_training'])throw new RuntimeException('delta mismatch: '.json_encode($d));
if($g->unmetPrerequisites('ndis_training',$ach,new DateTimeImmutable('2026-08-11T00:00:00Z'))!==[])throw new RuntimeException('safety not recognized');
echo "test_alpha5_requirement_graph PASS\n";
