<?php
$root=dirname(__DIR__,2);
foreach([
'/System/Domain/Trust/AcknowledgementReceipt.php',
'/System/Domain/Trust/SignatureReceipt.php',
'/System/Domain/Trust/ApprovalReceipt.php',
] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}

use App\Extensions\OnboardingPro\System\Domain\Trust\AcknowledgementReceipt;
use App\Extensions\OnboardingPro\System\Domain\Trust\SignatureReceipt;
use App\Extensions\OnboardingPro\System\Domain\Trust\ApprovalReceipt;

$fail=[];
$ack=AcknowledgementReceipt::issue('ack-1',44,91,'policy:safety','v3',str_repeat('b',64),new DateTimeImmutable('2026-08-11T09:10:00Z'),['trace_id'=>'t1']);
if(!$ack->requiresRenewalFor('v4',str_repeat('c',64)))$fail[]='changed policy did not require renewal';
if($ack->requiresRenewalFor('v3',str_repeat('b',64)))$fail[]='unchanged policy incorrectly requires renewal';
try{$ack->withPolicyVersion('v4');$fail[]='acknowledgement mutable';}catch(LogicException){}

$sig=SignatureReceipt::issue('sig-1',44,91,'consent:service','v1',str_repeat('d',64),str_repeat('e',64),new DateTimeImmutable('2026-08-11T09:11:00Z'),['device_id'=>'dev1']);
if($sig->signatureHash!==str_repeat('e',64))$fail[]='signature hash missing';

$approval=ApprovalReceipt::issue('apr-1',44,101,'credential:ev-1','approved',new DateTimeImmutable('2026-08-11T09:12:00Z'),['evidence_ids'=>['ev-1']]);
if($approval->decision!=='approved'||$approval->companyId!==44)$fail[]='approval mismatch';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "trust receipts PASS\n";
