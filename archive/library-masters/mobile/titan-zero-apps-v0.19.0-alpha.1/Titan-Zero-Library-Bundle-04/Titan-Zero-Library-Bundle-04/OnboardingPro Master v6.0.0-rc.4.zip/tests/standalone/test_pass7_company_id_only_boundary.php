<?php
declare(strict_types=1);
require_once __DIR__.'/../../System/Security/ParticipantAccessGrant.php';
use App\Extensions\OnboardingPro\System\Security\ParticipantAccessGrant;
$now=new DateTimeImmutable('2026-08-31T00:00:00+00:00');
$grant=new ParticipantAccessGrant(44,1,2,['intro'],$now,$now->modify('+1 hour'),'n','s');
$canonical=$grant->withCompanyId(55);
if($canonical->companyId!==55){throw new RuntimeException('Canonical withCompanyId failed');}
$legacy=$grant->withTenantCompanyId(66);
if($legacy->companyId!==66){throw new RuntimeException('Legacy tenant_company alias did not normalize to companyId');}
echo "test_pass7_company_id_only_boundary PASS\n";
