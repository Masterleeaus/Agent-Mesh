<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Domain\Steps\StepDefinition;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepType;
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\InteractionJourneyAdapter;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
$steps=[
 new StepDefinition('welcome',StepType::Information,'worker',['title'=>'Welcome'],[],'viewed'),
 new StepDefinition('licence',StepType::Evidence,'worker',['title'=>'Licence'],[['field'=>'role','operator'=>'=','value'=>'electrician']],'evidence_accepted','high','deferred','crm.worker.credential.attach'),
];
$adapter=new InteractionJourneyAdapter();
$ctx=new JourneyExecutionContext(42,'enr-1','journey-v3','worker-7','user-9','worker',['employee'],'titan-go','corr-1','device-1');
$mapped=$adapter->map('worker-induction','Worker Induction','3.0.0',$steps,$ctx);
if(($mapped['journey']['id']??'')!=='onboarding.worker-induction') throw new RuntimeException('journey id');
if(($mapped['wizards'][0]['capability']??'')!=='onboarding.step.complete') throw new RuntimeException('completion capability');
if(($mapped['wizards'][1]['steps'][0]['conditions'][0]['operator']??'')!=='=') throw new RuntimeException('condition lost');
if(($mapped['wizards'][1]['governance']['risk_level']??'')!=='high') throw new RuntimeException('risk lost');
if(($mapped['wizards'][1]['offline']['policy']??'')!=='deferred') throw new RuntimeException('offline lost');
if(($mapped['context']['company_id']??null)!==42 || ($mapped['context']['actor_id']??'')!=='user-9') throw new RuntimeException('context');
echo "test_interaction_runtime_bridge PASS\n";
