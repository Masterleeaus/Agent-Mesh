<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Services\ParticipantAssignmentService;
use App\Extensions\OnboardingPro\System\Services\HandoffService;
$s=new ParticipantAssignmentService();
$assign=$s->assign(42,'enr-1','manager-approval','manager','user-55',['worker'=>'user-22']);
if($assign->assignedActorId!=='user-55'||$assign->actorRole!=='manager')throw new RuntimeException('assignment');
if($s->canAccess($assign,42,'user-22',['worker']))throw new RuntimeException('worker accessed manager private step');
if(!$s->canAccess($assign,42,'user-55',['manager']))throw new RuntimeException('manager denied');
try{$s->canAccess($assign,99,'user-55',['manager']);throw new RuntimeException('cross company');}catch(RuntimeException $e){}
$h=new HandoffService();$waiting=$h->request($assign,'user-55','approval','2026-08-20T09:00:00+10:00');
if($waiting->status!=='waiting'||$waiting->reason!=='approval')throw new RuntimeException('handoff');
$done=$h->complete($waiting,'user-55');if($done->status!=='completed')throw new RuntimeException('complete');
echo "test_multi_actor PASS\n";
