<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryProfile;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCompiler;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

$p=BusinessDiscoveryProfile::fromArray([
 'business_identity'=>['name'=>'Volt Co'],'industry'=>'electrical','services'=>['residential_electrical'],
 'service_areas'=>[['postcode'=>'3071']],'jurisdiction'=>['country'=>'AU','state'=>'VIC'],'size'=>'micro','staff'=>['count'=>2],
 'operating_hours'=>['mon'=>['07:00','16:00']],'pricing_approach'=>'quote','job_lifecycle'=>['lead','quote','job','invoice'],
 'communication_channels'=>['sms'],'payment_methods'=>['bank_transfer'],'equipment_assets'=>['multimeter'],
 'compliance_requirements'=>['electrical_licensing'],'privacy_preferences'=>['device_first'=>true],
 'ai_provider_preferences'=>['mode'=>'byo'],'autonomy_preferences'=>['default'=>'suggest'],'risk_tolerance'=>['operations'=>'low']
]);
$trace=new OnboardingTraceContext('trace-1','corr-1','cause-1',77,501);
$out=(new BusinessDiscoveryCompiler())->compile($p,$trace);
foreach(['vertical_candidate_request','workforce_bootstrap_intent','workflow_bootstrap_intent','knowledge_bootstrap_intent'] as $key){
 if(!isset($out[$key])) throw new RuntimeException("missing $key");
 foreach(['trace_id','correlation_id','causation_id','company_id'] as $t){if(($out[$key][$t]??null)===''||!array_key_exists($t,$out[$key])) throw new RuntimeException("missing trace $t in $key");}
}
if(isset($out['nexus_provisioning_input'])) throw new RuntimeException('legacy Nexus payload must not be emitted by generic compiler');
if(($out['workforce_bootstrap_intent']['direct_create']??true)!==false) throw new RuntimeException('workforce must be intent only');
if(($out['knowledge_bootstrap_intent']['jurisdiction']['state']??'')!=='VIC') throw new RuntimeException('knowledge bootstrap');
if(isset($out['risk_score'])||isset($out['autonomy_grant'])) throw new RuntimeException('onboarding must not calculate risk or grant autonomy');
echo "test_bootstrap_compiler PASS\n";
