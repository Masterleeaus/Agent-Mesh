<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Offline\OnboardingOfflineManifest;
use App\Extensions\OnboardingPro\System\Offline\OnboardingMutation;
use App\Extensions\OnboardingPro\System\Offline\OnboardingConflictResolver;
$manifest=OnboardingOfflineManifest::fromSteps(42,'enr-1','jv-2',[
 ['key'=>'info','offline_policy'=>'allowed'],['key'=>'photo','offline_policy'=>'deferred'],['key'=>'payment','offline_policy'=>'online_required']]);
if(!$manifest->canCompleteOffline('info')||!$manifest->canQueueOffline('photo')||$manifest->canQueueOffline('payment'))throw new RuntimeException('policy');
$m=OnboardingMutation::create(42,'enr-1','photo','response.submit',['file_hash'=>'abc'],'device-1','base-hash');
$cmd=$m->toInteractionOutboxCommand();
if(($cmd['payload']['_context']['company_id']??null)!==42||($cmd['payload']['_context']['idempotency_key']??'')!==$m->idempotencyKey)throw new RuntimeException('outbox context');
$r=new OnboardingConflictResolver();
$decision=$r->resolve(['status'=>'pending','updated_at'=>'2026-08-11T01:00:00Z'],['status'=>'completed','updated_at'=>'2026-08-11T02:00:00Z'],$m);
if($decision['winner']!=='server'||$decision['reason']!=='server_terminal_state')throw new RuntimeException('terminal server state');
$decision2=$r->resolve(['status'=>'pending','updated_at'=>'2026-08-11T03:00:00Z'],['status'=>'pending','updated_at'=>'2026-08-11T02:00:00Z'],$m);
if($decision2['winner']!=='client')throw new RuntimeException('fresh client state');
echo "test_offline_runtime PASS\n";
