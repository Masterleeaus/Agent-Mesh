<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{
    $p='App\\Extensions\\OnboardingPro\\';
    if(str_starts_with($class,$p)){
        $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php';
        if(is_file($f)) require $f;
    }
});

$required=[
    'System/Persistence/Models/DiscoveryProfileRecord.php',
    'System/Discovery/DiscoveryProfileFingerprint.php',
    'System/Discovery/DiscoveryProfileConcurrencyException.php',
    'System/Discovery/DiscoveryProfileRepository.php',
    'System/Discovery/DiscoveryProfileService.php',
];
foreach($required as $rel){ if(!is_file($root.'/'.$rel)) throw new RuntimeException("Pass 2 file missing: $rel"); }

use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileFingerprint;
$a=['business_identity'=>['name'=>'Acme','legal_name'=>'Acme Pty Ltd'],'jurisdiction'=>['state'=>'VIC','country'=>'AU'],'services'=>['cleaning']];
$b=['services'=>['cleaning'],'jurisdiction'=>['country'=>'AU','state'=>'VIC'],'business_identity'=>['legal_name'=>'Acme Pty Ltd','name'=>'Acme']];
$ha=DiscoveryProfileFingerprint::forPayload($a);
$hb=DiscoveryProfileFingerprint::forPayload($b);
if($ha!==$hb) throw new RuntimeException('Profile fingerprint must be canonical across associative-key order.');
if(!preg_match('/^[a-f0-9]{64}$/',$ha)) throw new RuntimeException('Profile fingerprint must be SHA-256 hex.');

$model=file_get_contents($root.'/System/Persistence/Models/DiscoveryProfileRecord.php');
foreach(['ext_onboarding_discovery_profiles','company_id','revision','profile_payload','remaining_domains','minimum_ready','operational_ready','updating','deleting'] as $needle){
    if(!str_contains($model,$needle)) throw new RuntimeException("Discovery profile model missing $needle");
}

$repo=file_get_contents($root.'/System/Discovery/DiscoveryProfileRepository.php');
foreach(['function latest','function findRevision','function saveRevision','DB::transaction','lockForUpdate','expectedRevision','profile_hash','company_id','updated_by_actor_id','DiscoveryProfileConcurrencyException'] as $needle){
    if(!str_contains($repo,$needle)) throw new RuntimeException("Discovery profile repository missing $needle");
}

$svc=file_get_contents($root.'/System/Discovery/DiscoveryProfileService.php');
foreach(['ProgressiveReadinessEvaluator','OnboardingTraceContext','saveDraft','trace->companyId','remainingDomains'] as $needle){
    if(!str_contains($svc,$needle)) throw new RuntimeException("Discovery profile service missing $needle");
}

$provider=file_get_contents($root.'/System/OnboardingProServiceProvider.php');
foreach(['DiscoveryProfileRepository','DiscoveryProfileService'] as $needle){
    if(!str_contains($provider,$needle)) throw new RuntimeException("Service provider missing $needle binding");
}

echo "test_pass2_durable_discovery_profiles PASS\n";
