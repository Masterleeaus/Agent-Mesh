<?php
$root=dirname(__DIR__,2);foreach(['/System/Analytics/JourneyMetricsService.php','/System/Analytics/BottleneckAnalyzer.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Analytics\JourneyMetricsService;use App\Extensions\OnboardingPro\System\Analytics\BottleneckAnalyzer;
$rows=[
 ['status'=>'completed','started_at'=>'2026-08-01T00:00:00Z','completed_at'=>'2026-08-01T01:00:00Z','step_key'=>'s1','approval_seconds'=>120,'evidence_rejected'=>false,'overdue'=>false],
 ['status'=>'completed','started_at'=>'2026-08-01T00:00:00Z','completed_at'=>'2026-08-01T03:00:00Z','step_key'=>'s2','approval_seconds'=>360,'evidence_rejected'=>true,'overdue'=>false],
 ['status'=>'active','started_at'=>'2026-08-01T00:00:00Z','completed_at'=>null,'step_key'=>'s2','approval_seconds'=>null,'evidence_rejected'=>false,'overdue'=>true],
];
$m=(new JourneyMetricsService())->summarize($rows);
$fail=[];if($m['enrolments']!==3)$fail[]='enrolment count';if(abs($m['completion_rate']-(2/3))>0.0001)$fail[]='completion rate';if($m['median_completion_seconds']!==7200)$fail[]='median duration';if($m['evidence_rejection_rate']!==1/3)$fail[]='evidence rejection';if($m['overdue_rate']!==1/3)$fail[]='overdue rate';
$b=(new BottleneckAnalyzer())->rank([['step_key'=>'a','started'=>10,'completed'=>9,'median_seconds'=>30],['step_key'=>'b','started'=>10,'completed'=>4,'median_seconds'=>300]]);if(($b[0]['step_key']??null)!=='b')$fail[]='bottleneck rank';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "final analytics PASS\n";
