<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Activation\ActivationGate;
$g=new ActivationGate();
$base=['tenant_valid'=>true,'participant_valid'=>true,'journey_valid'=>true,'duplicate_active'=>false,'prerequisites_met'=>true,'approval_required'=>false,'approval_present'=>false,'policy_allowed'=>true,'idempotency_seen'=>false,'trigger_type'=>'vertical_change','trigger_ref'=>'sig-1'];
$r=$g->evaluate($base);if($r->state!=='ACTIVE'||!in_array('VERTICAL_CHANGE',$r->reasonCodes,true))throw new RuntimeException('activation');
$x=$base;$x['duplicate_active']=true;if($g->evaluate($x)->state!=='BLOCKED_DUPLICATE')throw new RuntimeException('duplicate');
$x=$base;$x['approval_required']=true;if($g->evaluate($x)->state!=='PENDING_APPROVAL')throw new RuntimeException('approval gate');
$x=$base;$x['prerequisites_met']=false;if($g->evaluate($x)->state!=='BLOCKED_PREREQUISITE')throw new RuntimeException('prereq gate');
echo "test_alpha5_activation_gate PASS\n";
