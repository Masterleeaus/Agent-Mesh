<?php
$root=dirname(__DIR__,2);
foreach(['System/Reconfiguration/BusinessConfigurationDiffer.php','System/Reconfiguration/BusinessReconfigurationService.php','System/Persistence/Models/ReconfigurationRecord.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 12 file: $f\n");exit(1);}}
$d=file_get_contents($root.'/System/Reconfiguration/BusinessConfigurationDiffer.php');$s=file_get_contents($root.'/System/Reconfiguration/BusinessReconfigurationService.php');$c=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
$checks=[str_contains($d,'semantic_diff'),str_contains($d,'added'),str_contains($d,'removed'),str_contains($d,'changed'),str_contains($s,'impact_preview'),str_contains($s,'approval_fingerprint'),str_contains($s,'company_id'),str_contains($s,'verifyProvisioning'),str_contains($s,'history'),str_contains($c,'previewBusinessReconfiguration'),str_contains($c,'approveBusinessReconfiguration')];
foreach($checks as $v)if(!$v){fwrite(STDERR,"Pass 12 contract not implemented\n");exit(1);}echo "PASS: Pass 12 continuous business reconfiguration\n";
