<?php
$root=dirname(__DIR__,2);
$req=['System/Artifacts/BusinessArtifactIngestionService.php','System/Artifacts/ArtifactExtractionGatewayInterface.php','System/Persistence/Models/BusinessArtifactRecord.php'];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$s=file_get_contents($root.'/System/Artifacts/BusinessArtifactIngestionService.php');
$checks=[str_contains($s,'selected_files'),str_contains($s,'camera_vision'),str_contains($s,'pdf'),str_contains($s,'spreadsheet'),str_contains($s,'invoice'),str_contains($s,'certificate'),str_contains($s,'screenshot'),str_contains($s,'candidate'),str_contains($s,'EvidenceAuthorityService'),str_contains($s,'company_id')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 4 artifact/Vision contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 4 artifact and Vision business intelligence\n";
