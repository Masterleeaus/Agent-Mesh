<?php
$root=dirname(__DIR__,2);
$req=[
 'System/Discovery/Nexus/NexusProvisioningTransactionService.php',
 'System/Discovery/Nexus/NexusProvisioningRecoveryService.php',
 'System/Discovery/Nexus/NexusProvisioningReconciliationService.php',
 'System/Persistence/Models/NexusProvisioningTransaction.php',
 'System/Persistence/Models/NexusProvisioningStep.php',
];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$t=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningTransactionService.php');
$r=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningRecoveryService.php');
$c=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningReconciliationService.php');
$e=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningExecutionService.php');
$checks=[
 str_contains($t,'idempotency'),
 str_contains($t,'checkpoint'),
 str_contains($t,'company_id'),
 str_contains($t,'compensation'),
 str_contains($t,'forward_recovery'),
 str_contains($r,'expired_credentials'),
 str_contains($r,'provider_outage'),
 str_contains($r,'retryable'),
 str_contains($r,'manual_attention'),
 str_contains($c,'drift'),
 str_contains($c,'expected'),
 str_contains($c,'observed'),
 str_contains($c,'reconciliation'),
 str_contains($e,'transaction'),
];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 9 transaction/recovery/reconciliation contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 9 transactional provisioning recovery reconciliation\n";
