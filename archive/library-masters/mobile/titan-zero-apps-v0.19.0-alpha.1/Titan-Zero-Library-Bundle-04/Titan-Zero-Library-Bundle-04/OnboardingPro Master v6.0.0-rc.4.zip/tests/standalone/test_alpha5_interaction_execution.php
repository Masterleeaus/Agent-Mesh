<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\InteractionWorkflowExecutor;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
$runtime=new class{public array $calls=[];public function execute(string $workflowId,string $version,array $context,array $inputs):array{$this->calls[]=compact('workflowId','version','context','inputs');return ['execution_id'=>'ix-1','status'=>'completed','outputs'=>['captured'=>true],'evidence_refs'=>['ev-1'],'command_receipts'=>[],'pending_approvals'=>[]];}};
$ex=new InteractionWorkflowExecutor($runtime);
$t=new OnboardingTraceContext('tr-1','co-1','ca-1',44,91);
$r=$ex->execute('onboarding.discovery.capture','1.0',$t,['industry'=>'plumbing']);
if($r['status']!=='completed'||$r['execution_id']!=='ix-1')throw new RuntimeException('execution result');
if(($runtime->calls[0]['context']['company_id']??null)!==44)throw new RuntimeException('tenant context missing');
if(($runtime->calls[0]['context']['trace_id']??'')!=='tr-1')throw new RuntimeException('trace missing');
echo "test_alpha5_interaction_execution PASS\n";
