<?php
$root=dirname(__DIR__,2);
foreach(['/System/Integrations/Registration/RegistrationJourneyTrigger.php','/System/Integrations/Payments/PaymentConfirmationGateway.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Integrations\Registration\RegistrationJourneyTrigger;
use App\Extensions\OnboardingPro\System\Integrations\Payments\PaymentConfirmationGateway;
$fail=[];
$t=new RegistrationJourneyTrigger();
$p=$t->prepare(44,91,'registration:91','plan_selected',['trace_id'=>'t','correlation_id'=>'c','causation_id'=>'reg']);
if($p['status']!=='PREPARED'||$p['direct_mutation']!==false)$fail[]='registration trigger not prepare-only';
if($p['journey_key']!=='titan-business-activation-v1')$fail[]='wrong activation journey';
if(strlen($p['idempotency_key'])!==64)$fail[]='bad idempotency key';
$g=new PaymentConfirmationGateway();
$r=$g->prepare(44,'invoice:2','stripe','pi_123',['trace_id'=>'t']);
if($r['capability']!=='payment.confirm'||$r['status']!=='PREPARED'||$r['authoritative']!==false)$fail[]='payment confirmation crossed authority';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "beta1 registration activation PASS\n";
