<?php
$root=dirname(__DIR__,2);
foreach(['/System/Services/JourneyDefinitionValidator.php','/System/Services/JourneyLibraryService.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Services\JourneyDefinitionValidator;
use App\Extensions\OnboardingPro\System\Services\JourneyLibraryService;
$fail=[];
$v=new JourneyDefinitionValidator();
$valid=['key'=>'worker-induction','version'=>'1.0.0','audience'=>'employee','steps'=>[['key'=>'welcome','type'=>'information','actor'=>'participant','offline_policy'=>'allowed']]];
$res=$v->validate($valid);
if(!$res['valid']||$res['errors'])$fail[]='valid journey rejected';
$bad=$v->validate(['key'=>'x','version'=>'1.0.0','steps'=>[['key'=>'boom','type'=>'unknown','actor'=>'participant']]]);
if($bad['valid']||!in_array('unsupported_step_type:unknown',$bad['errors'],true))$fail[]='unknown step accepted';
$lib=new JourneyLibraryService();
$rows=[['key'=>'b','status'=>'draft','audience'=>'employee'],['key'=>'a','status'=>'published','audience'=>'customer'],['key'=>'c','status'=>'published','audience'=>'employee']];
$out=$lib->filter($rows,status:'published',audience:'employee');
if(count($out)!==1||$out[0]['key']!=='c')$fail[]='library filter wrong';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "beta1 journey studio PASS\n";
