<?php
$root=dirname(__DIR__,2);
foreach(['System/Discovery/Nexus/NexusProvisioningVerificationService.php','System/Persistence/Models/NexusVerificationRecord.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing Pass 10 file: $f\n");exit(1);}}
$s=file_get_contents($root.'/System/Discovery/Nexus/NexusProvisioningVerificationService.php');$g=file_get_contents($root.'/System/Discovery/Nexus/NexusRuntimeGatewayInterface.php');$c=file_get_contents($root.'/System/Http/Controllers/BusinessSetupController.php');
$checks=[str_contains($s,'verifyProvisioning'),str_contains($s,'execution_receipt'),str_contains($s,'company_id'),str_contains($s,'operational_ready'),str_contains($s,'blocking_gaps'),str_contains($s,'manual_actions'),str_contains($s,'verified_capabilities'),str_contains($g,'verifyProvisioning'),str_contains($c,'verifyNexusProvisioning')];
foreach($checks as $v)if(!$v){fwrite(STDERR,"Pass 10 contract not implemented\n");exit(1);}echo "PASS: Pass 10 provisioning verification and readiness\n";
