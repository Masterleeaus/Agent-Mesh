<?php
$root=dirname(__DIR__,2);
foreach(['/System/Services/JourneyDefinitionValidator.php','/System/Services/JourneyDraftService.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Services\JourneyDefinitionValidator;
use App\Extensions\OnboardingPro\System\Services\JourneyDraftService;
$fail=[];$svc=new JourneyDraftService(new JourneyDefinitionValidator());
$def=['key'=>'worker-induction','version'=>'1.1.0','steps'=>[['key'=>'welcome','type'=>'information','actor'=>'participant']]];
$out=$svc->prepareUpdate('draft',3,3,$def);if($out['revision']!==4||$out['definition']['key']!=='worker-induction')$fail[]='draft update failed';
try{$svc->prepareUpdate('published',3,3,$def);$fail[]='published version editable';}catch(LogicException){}
try{$svc->prepareUpdate('draft',4,3,$def);$fail[]='stale revision accepted';}catch(RuntimeException){}
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "beta1 draft service PASS\n";
