<?php
$root = dirname(__DIR__, 2);
$files = [
    '/System/Domain/Steps/StepType.php',
    '/System/Domain/Steps/StepDefinition.php',
    '/System/Domain/Steps/StepTypeRegistry.php',
];
foreach ($files as $file) {
    if (!is_file($root . $file)) { fwrite(STDERR, "missing production file: $file\n"); exit(1); }
    require_once $root . $file;
}

use App\Extensions\OnboardingPro\System\Domain\Steps\StepDefinition;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepType;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepTypeRegistry;

$fail = [];
$registry = StepTypeRegistry::withTitanDefaults();
$expected = [
    'information','form','checklist','guided_tour','announcement','document','video','survey','quiz',
    'signature','evidence','approval','payment_confirmation','booking','integration','practical_signoff','certificate','completion',
];
$actual = $registry->keys(); sort($actual); $sortedExpected = $expected; sort($sortedExpected);
if ($actual !== $sortedExpected) $fail[] = 'default step type set mismatch';

$definition = new StepDefinition(
    key: 'police-check',
    type: StepType::Evidence,
    actor: 'worker',
    config: ['allowed_mime' => ['application/pdf','image/jpeg']],
    conditions: ['worker.role = cleaner'],
    completionRule: 'evidence_accepted',
    riskLevel: 'high',
    offlinePolicy: 'deferred',
    capabilityId: null,
);
$registry->validate($definition);

try { $registry->resolve('not-real'); $fail[] = 'unknown step type resolved'; } catch (InvalidArgumentException) {}
try { $registry->register('information', ['category' => 'presentation']); $fail[] = 'duplicate step type registered'; } catch (LogicException) {}
try {
    new StepDefinition('bad', StepType::Information, 'participant', [], [], 'viewed', 'low', 'sometimes', null);
    $fail[] = 'invalid offline policy accepted';
} catch (InvalidArgumentException) {}
try {
    new StepDefinition('bad key!', StepType::Information, 'participant', [], [], 'viewed', 'low', 'allowed', null);
    $fail[] = 'invalid step key accepted';
} catch (InvalidArgumentException) {}

if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "step registry PASS\n";
