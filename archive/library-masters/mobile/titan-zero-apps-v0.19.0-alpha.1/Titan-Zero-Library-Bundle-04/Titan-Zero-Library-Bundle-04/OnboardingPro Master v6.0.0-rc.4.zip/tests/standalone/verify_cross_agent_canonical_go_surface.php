<?php
declare(strict_types=1);
$src=(string)file_get_contents(__DIR__.'/../../System/Offline/OnboardingMutation.php');
if(str_contains($src,"'source_surface'=>'titan-go'")){fwrite(STDERR,"legacy titan-go source_surface remains\n");exit(1);}
if(!str_contains($src,"'source_surface'=>'go'")){fwrite(STDERR,"canonical go source_surface missing\n");exit(1);}
echo "PASS canonical go surface\n";
