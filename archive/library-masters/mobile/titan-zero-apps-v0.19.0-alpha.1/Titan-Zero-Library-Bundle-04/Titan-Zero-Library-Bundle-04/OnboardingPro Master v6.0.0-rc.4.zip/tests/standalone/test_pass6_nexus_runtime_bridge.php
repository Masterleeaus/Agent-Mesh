<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);

$required = [
    'System/Persistence/Models/BootstrapIntentRecord.php',
    'System/Discovery/BootstrapIntentRepository.php',
    'System/Discovery/Nexus/NexusRuntimeGatewayInterface.php',
    'System/Discovery/Nexus/ConfiguredNexusRuntimeGateway.php',
    'System/Discovery/Nexus/NexusDraftBridge.php',
    'System/Discovery/Nexus/NexusIntentFactory.php',
];
foreach ($required as $file) {
    if (!is_file($root.'/'.$file)) {
        fwrite(STDERR, "Missing Pass 6 runtime file: {$file}\n");
        exit(1);
    }
}

$bridge = file_get_contents($root.'/System/Discovery/Nexus/NexusDraftBridge.php');
$repo = file_get_contents($root.'/System/Discovery/BootstrapIntentRepository.php');
$gateway = file_get_contents($root.'/System/Discovery/Nexus/ConfiguredNexusRuntimeGateway.php');
$factory = file_get_contents($root.'/System/Discovery/Nexus/NexusIntentFactory.php');
$provider = file_get_contents($root.'/System/OnboardingProServiceProvider.php');
$config = file_get_contents($root.'/config/onboarding-pro.php');

$checks = [
    'factory reconstructs vertical resolution' => str_contains($factory, 'new VerticalResolution'),
    'factory compiles canonical intent' => str_contains($factory, 'compileNexusProvisioningIntent'),
    'bridge calls newDraft' => str_contains($bridge, 'newDraft'),
    'bridge calls validateDraft' => str_contains($bridge, 'validateDraft'),
    'bridge calls previewDraft' => str_contains($bridge, 'previewDraft'),
    'bridge persists prepared intent' => str_contains($bridge, 'persistPrepared'),
    'bridge persists receipt' => str_contains($bridge, 'recordReceipt'),
    'repository scopes company' => str_contains($repo, "where('company_id'"),
    'repository uses idempotency' => str_contains($repo, 'idempotency_key'),
    'configured gateway is fail closed' => str_contains($gateway, 'NEXUS_UNAVAILABLE'),
    'provider binds runtime gateway' => str_contains($provider, 'NexusRuntimeGatewayInterface::class'),
    'provider binds bridge' => str_contains($provider, 'NexusDraftBridge::class'),
    'config exposes Nexus contract' => str_contains($config, "'nexus'"),
    'receipt is immutable' => str_contains($repo, 'receipt is immutable once recorded'),
    'bridge has no compile execution' => !str_contains($bridge, 'compileDraft(') && !str_contains($bridge, 'planProvisioning(') && !str_contains($bridge, 'executeProvisioning('),
];
$failed = [];
foreach ($checks as $label => $ok) if (!$ok) $failed[] = $label;
if ($failed !== []) {
    fwrite(STDERR, "Pass 6 contract failed:\n - ".implode("\n - ", $failed)."\n");
    exit(1);
}
echo "PASS: Pass 6 Nexus runtime bridge contract\n";
