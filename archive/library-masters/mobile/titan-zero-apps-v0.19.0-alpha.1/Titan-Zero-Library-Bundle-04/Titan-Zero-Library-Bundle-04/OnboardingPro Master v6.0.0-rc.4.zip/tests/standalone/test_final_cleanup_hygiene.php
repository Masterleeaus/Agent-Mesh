<?php
$root=dirname(__DIR__,2);$fail=[];
$rootDocs=[];foreach(new DirectoryIterator($root) as $f){if($f->isFile()&&preg_match('/\.(md|txt)$/i',$f->getFilename()))$rootDocs[]=$f->getFilename();}
if($rootDocs)$fail[]='root documentation outside docs/: '.implode(',',$rootDocs);
$admin=file_get_contents($root.'/routes/admin.php');$user=file_get_contents($root.'/routes/user.php');
foreach(['banners','surveys','introduction/customization','legacy-migration'] as $needle){if(str_contains($admin,$needle))$fail[]="legacy runtime admin route remains: $needle";}
foreach(['banner/{id}/dismiss','survey/{point}/{id}/respond'] as $needle){if(str_contains($user,$needle))$fail[]="legacy user route remains: $needle";}
foreach(['System/Models/Banner.php','System/Models/BannerUser.php','System/Models/Survey.php','System/Models/SurveyUser.php','System/Models/IntroductionStyle.php'] as $legacy){if(is_file($root.'/'.$legacy))$fail[]="legacy runtime model remains: $legacy";}
foreach(glob($root.'/resources/views/*.blade.php')?:[] as $view){$base=basename($view);if(in_array($base,['banner.blade.php','bannerCreate.blade.php','bannerEdit.blade.php','banners.blade.php','survey.blade.php','surveyCreate.blade.php','surveyEdit.blade.php','surveyResult.blade.php','surveyResultUsers.blade.php','surveys.blade.php','introduction.blade.php','introductionCustom.blade.php'],true))$fail[]="legacy runtime view remains: $base";}
$markers=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System',FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(!$f->isFile()||$f->getExtension()!=='php')continue;$txt=file_get_contents($f->getPathname());if(preg_match('/\b(TODO|FIXME|HACK|TBD)\b/i',$txt))$markers[]=$f->getPathname();}
if($markers)$fail[]='production TODO/FIXME/HACK/TBD markers remain';
foreach(glob($root.'/tests/standalone/*.php')?:[] as $test){if(basename($test)==='test_final_cleanup_hygiene.php')continue;$txt=file_get_contents($test);$needle='/' . 'mnt' . '/data/';if(str_contains($txt,$needle))$fail[]='non-portable external temp dependency in '.basename($test);}
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "final cleanup hygiene PASS\n";
