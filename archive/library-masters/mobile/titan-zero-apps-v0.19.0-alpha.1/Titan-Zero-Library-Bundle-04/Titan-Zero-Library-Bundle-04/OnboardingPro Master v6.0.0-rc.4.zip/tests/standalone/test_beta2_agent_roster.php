<?php
$root=dirname(__DIR__,2);
$classes=['SetupAssistant','EmployeeInductionAssistant','CustomerOnboardingAssistant','ComplianceAssistant','TrainingAssistant','EvidenceAssistant','RenewalAssistant'];
foreach($classes as $c){$f=$root.'/System/Agents/'.$c.'.php';if(!is_file($f)){fwrite(STDERR,"missing $c\n");exit(1);}}
echo "beta2 agent roster PASS\n";
