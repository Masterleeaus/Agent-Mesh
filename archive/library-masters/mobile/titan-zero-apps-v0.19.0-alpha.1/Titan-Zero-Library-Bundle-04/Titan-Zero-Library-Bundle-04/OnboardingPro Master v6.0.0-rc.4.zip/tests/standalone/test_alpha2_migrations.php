<?php
$root = dirname(__DIR__, 2);
$required = [
    '2026_08_11_050100_create_ext_onboarding_journey_tables.php',
    '2026_08_11_050200_create_ext_onboarding_enrolment_tables.php',
];
$fail = [];
foreach ($required as $name) {
    $file = $root . '/database/migrations/' . $name;
    if (!is_file($file)) { $fail[] = "migration missing: $name"; continue; }
    $text = file_get_contents($file);
    if (!str_contains($text, 'company_id')) $fail[] = "$name missing company_id";
    if (!preg_match('/function\s+down\s*\(/', $text)) $fail[] = "$name missing down()";
}
$joined = '';
foreach ($required as $name) if (is_file($root . '/database/migrations/' . $name)) $joined .= file_get_contents($root . '/database/migrations/' . $name);
foreach (['ext_onboarding_journeys','ext_onboarding_journey_versions','ext_onboarding_steps','ext_onboarding_step_rules','ext_onboarding_enrolments','ext_onboarding_participants','ext_onboarding_step_instances','ext_onboarding_responses'] as $table) {
    if (!str_contains($joined, "'$table'")) $fail[] = "table not declared: $table";
}
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "alpha2 migrations PASS\n";
