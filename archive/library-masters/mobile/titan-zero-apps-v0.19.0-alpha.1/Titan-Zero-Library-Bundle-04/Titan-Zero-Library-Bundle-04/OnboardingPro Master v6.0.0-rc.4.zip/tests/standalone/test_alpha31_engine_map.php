<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$ext=json_decode(file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$side=json_decode(file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(($ext['version']??'')!=='6.0.0-rc.3') throw new RuntimeException('root version');
if(($side['version']??'')!=='6.0.0-rc.3') throw new RuntimeException('sidecar version');
$mission=$side['business_discovery']??null;if(!is_array($mission)) throw new RuntimeException('business discovery manifest missing');
foreach(['vertical_engine','nexus','ai_workforce','interaction_engine','knowledge_authority','signal','rewind'] as $k){if(!isset($mission['engine_boundaries'][$k])) throw new RuntimeException("missing engine boundary $k");}
if(($mission['calculates_risk']??true)!==false||($mission['grants_autonomy']??true)!==false||($mission['direct_authoritative_mutation']??true)!==false) throw new RuntimeException('ownership boundary violated');
$owned=$side['ownership']['owned_tables']??[];
foreach(['ext_onboarding_discovery_profiles','ext_onboarding_bootstrap_intents'] as $t){if(!in_array($t,$owned,true)) throw new RuntimeException("owned table missing $t");}

$provider=file_get_contents($root.'/System/OnboardingProServiceProvider.php');
foreach(['BusinessDiscoveryCompiler::class','ProgressiveReadinessEvaluator::class','BusinessDiscoveryJourneyFactory::class','BusinessDiscoveryCoordinator::class'] as $needle){if(!str_contains($provider,$needle)) throw new RuntimeException('provider missing '.$needle);}
echo "test_alpha31_engine_map PASS\n";
