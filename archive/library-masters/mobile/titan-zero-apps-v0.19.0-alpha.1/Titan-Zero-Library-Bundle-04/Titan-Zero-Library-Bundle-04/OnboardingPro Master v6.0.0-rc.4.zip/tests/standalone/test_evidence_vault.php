<?php
$root=dirname(__DIR__,2);
foreach([
'/System/Domain/Evidence/EvidenceRecord.php',
'/System/Domain/Evidence/EvidenceClassification.php',
'/System/Services/EvidenceValidationService.php',
'/System/Services/AssuranceEvidenceAdapter.php',
] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}

use App\Extensions\OnboardingPro\System\Domain\Evidence\EvidenceRecord;
use App\Extensions\OnboardingPro\System\Domain\Evidence\EvidenceClassification;
use App\Extensions\OnboardingPro\System\Services\EvidenceValidationService;
use App\Extensions\OnboardingPro\System\Services\AssuranceEvidenceAdapter;

$fail=[];
$validator=new EvidenceValidationService(
    allowedMimeTypes:['image/jpeg','image/png','application/pdf'],
    maxBytes:10_000_000
);
try{$validator->validate('evidence.exe','application/octet-stream',100);$fail[]='unsafe mime accepted';}catch(InvalidArgumentException){}
$validator->validate('photo.jpg','image/jpeg',2048);

$record=EvidenceRecord::capture(
    evidenceId:'ev-1',companyId:44,subjectType:'worker',subjectId:'91',
    evidenceType:'licence',source:'participant_upload',capturedAt:new DateTimeImmutable('2026-08-11T09:00:00Z'),
    contentHash:str_repeat('a',64),classification:EvidenceClassification::Credential,
    provenance:['actor_id'=>91,'journey_version_id'=>7,'step_key'=>'licence'],
    confidence:1.0,authority:'participant',jurisdiction:'AU-VIC'
);
if($record->companyId!==44||$record->contentHash!==str_repeat('a',64))$fail[]='record identity mismatch';
$out=(new AssuranceEvidenceAdapter())->toEvidenceRegistryPayload($record);
foreach(['evidence_id','evidence_type','subject','source','provenance','captured_at','freshness','confidence','authority','jurisdiction','hash','verification_state'] as $k){
    if(!array_key_exists($k,$out))$fail[]="assurance field missing: $k";
}
if(isset($out['hidden_chain_of_thought']))$fail[]='hidden chain of thought leaked';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "evidence vault PASS\n";
