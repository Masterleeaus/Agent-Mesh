<?php
$root=dirname(__DIR__,2);$req=['System/Workforce/NexusWorkforceCommandBridge.php','System/Workforce/WorkforceDomainRouter.php','System/Persistence/Models/NexusWorkforceCommand.php','System/Http/Controllers/NexusWorkforceCommandController.php'];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$b=file_get_contents($root.'/System/Workforce/NexusWorkforceCommandBridge.php');$d=file_get_contents($root.'/System/Workforce/WorkforceDomainRouter.php');$r=file_get_contents($root.'/routes/user.php');
$checks=[str_contains($b,'company_id'),str_contains($b,'objective'),str_contains($b,'evidence'),str_contains($b,'authority'),str_contains($b,'DO_NOT_ACT_YET'),str_contains($b,'Nexus'),str_contains($d,'money'),str_contains($d,'work'),str_contains($d,'people'),str_contains($d,'customer'),str_contains($d,'growth'),str_contains($d,'risk'),str_contains($d,'Titan Zero'),str_contains($d,'cross_domain'),str_contains($r,'workforce/commands/dispatch'),str_contains($r,'workforce/commands/latest')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"v6 Pass 8 workforce bridge contract incomplete\n");exit(1);}echo "PASS: v6 Pass 8 nexus workforce command bridge\n";
