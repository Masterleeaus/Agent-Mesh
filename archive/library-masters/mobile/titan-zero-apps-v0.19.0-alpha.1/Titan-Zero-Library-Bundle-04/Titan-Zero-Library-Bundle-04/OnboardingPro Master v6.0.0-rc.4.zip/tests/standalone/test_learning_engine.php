<?php
$root=dirname(__DIR__,2);
foreach([
'/System/Domain/Learning/Course.php',
'/System/Domain/Learning/Assessment.php',
'/System/Domain/Learning/AssessmentAttempt.php',
'/System/Services/LearningCompletionService.php',
] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}

use App\Extensions\OnboardingPro\System\Domain\Learning\Course;
use App\Extensions\OnboardingPro\System\Domain\Learning\Assessment;
use App\Extensions\OnboardingPro\System\Domain\Learning\AssessmentAttempt;
use App\Extensions\OnboardingPro\System\Services\LearningCompletionService;

$fail=[];
$course=new Course('chemical-safety-v1',44,'Chemical Safety',['intro','ppe','quiz']);
$assessment=new Assessment('quiz',44,80,3);
$pass=new AssessmentAttempt('attempt-1',44,91,'quiz',85,1,new DateTimeImmutable('2026-08-11T10:00:00Z'));
$failAttempt=new AssessmentAttempt('attempt-2',44,91,'quiz',70,2,new DateTimeImmutable('2026-08-11T10:05:00Z'));
$svc=new LearningCompletionService();
if(!$svc->assessmentPassed($assessment,$pass))$fail[]='passing score rejected';
if($svc->assessmentPassed($assessment,$failAttempt))$fail[]='failing score accepted';
if(!$svc->courseComplete($course,['intro'=>true,'ppe'=>true,'quiz'=>true]))$fail[]='complete course rejected';
if($svc->courseComplete($course,['intro'=>true,'ppe'=>false,'quiz'=>true]))$fail[]='incomplete course accepted';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);}echo "learning engine PASS\n";
