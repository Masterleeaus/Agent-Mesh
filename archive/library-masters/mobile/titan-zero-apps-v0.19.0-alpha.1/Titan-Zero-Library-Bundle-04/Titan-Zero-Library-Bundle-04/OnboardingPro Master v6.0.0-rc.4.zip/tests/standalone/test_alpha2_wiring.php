<?php
$root = dirname(__DIR__, 2);
$fail = [];
$provider = file_get_contents($root . '/System/OnboardingProServiceProvider.php');
foreach ([
    'StepTypeRegistry::class',
    'JourneyProgressService::class',
    'RuleEvaluator::class',
    'PrerequisiteEvaluator::class',
] as $needle) if (!str_contains($provider, $needle)) $fail[] = "provider missing binding: $needle";
$config = require $root . '/config/onboarding-pro.php';
if (($config['version'] ?? null) !== '6.0.0-rc.3') $fail[] = 'config version mismatch';
$sidecar = json_decode(file_get_contents($root . '/extension.manifest.json'), true);
if (($sidecar['version'] ?? null) !== '6.0.0-rc.3') $fail[] = 'sidecar version mismatch';
if (($sidecar['runtime_boundary']['durable_journey_core_active'] ?? null) !== true) $fail[] = 'durable journey core not declared active';
$tables = $sidecar['ownership']['owned_tables'] ?? [];
foreach (['ext_onboarding_journeys','ext_onboarding_journey_versions','ext_onboarding_steps','ext_onboarding_step_rules','ext_onboarding_enrolments','ext_onboarding_participants','ext_onboarding_step_instances','ext_onboarding_responses'] as $table) {
    if (!in_array($table, $tables, true)) $fail[] = "owned table missing: $table";
}
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "alpha2 wiring PASS\n";
