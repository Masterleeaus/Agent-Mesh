<?php
$root=dirname(__DIR__,2);
$req=['System/Presence/BusinessPresenceAuditService.php','System/Presence/BusinessPresenceObservationService.php','System/Presence/BusinessOpportunityService.php','System/Persistence/Models/BusinessPresenceAudit.php','System/Persistence/Models/BusinessPresenceObservation.php','System/Persistence/Models/BusinessOpportunity.php','System/Http/Controllers/BusinessPresenceController.php'];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}
$a=file_get_contents($root.'/System/Presence/BusinessPresenceAuditService.php');
$o=file_get_contents($root.'/System/Presence/BusinessPresenceObservationService.php');
$p=file_get_contents($root.'/System/Presence/BusinessOpportunityService.php');
$r=file_get_contents($root.'/routes/user.php');
$checks=[str_contains($a,'website'),str_contains($a,'google_business'),str_contains($a,'social'),str_contains($a,'reviews'),str_contains($a,'online_booking'),str_contains($a,'quote_request'),str_contains($a,'service_coverage'),str_contains($a,'business_hours'),str_contains($a,'brand_consistency'),str_contains($a,'presence_score'),str_contains($o,'observation'),str_contains($o,'evidence'),str_contains($o,'confidence'),str_contains($p,'opportunity'),str_contains($p,'recommended_action'),str_contains($p,'observation_ids'),str_contains($p,'growth_handoff'),str_contains($a,'company_id'),str_contains($r,'presence/audit'),str_contains($r,'presence/opportunities')];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 7 business presence/opportunity contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 7 business presence and opportunity intelligence\n";
