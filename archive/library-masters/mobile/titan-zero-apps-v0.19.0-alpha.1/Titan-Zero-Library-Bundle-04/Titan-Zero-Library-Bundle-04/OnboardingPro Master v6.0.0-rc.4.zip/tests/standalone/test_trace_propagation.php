<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require $root.'/System/DTO/JourneyExecutionContext.php';
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
$ctx=new JourneyExecutionContext(42,'enr','jv','p','actor','ai_worker',['worker'],'api','corr',null,'trace','cause');
$a=$ctx->toInteractionContext('idem');
foreach(['trace_id'=>'trace','correlation_id'=>'corr','causation_id'=>'cause','company_id'=>42] as $k=>$v){if(($a[$k]??null)!==$v) throw new RuntimeException("trace context missing $k");}
$legacy=new JourneyExecutionContext(42,'enr','jv','p','actor','human',['manager'],'web','legacy-corr');
$b=$legacy->toInteractionContext();
if(($b['trace_id']??'')!=='legacy-corr'||($b['causation_id']??'')!=='legacy-corr') throw new RuntimeException('legacy trace fallback');
echo "test_trace_propagation PASS\n";
