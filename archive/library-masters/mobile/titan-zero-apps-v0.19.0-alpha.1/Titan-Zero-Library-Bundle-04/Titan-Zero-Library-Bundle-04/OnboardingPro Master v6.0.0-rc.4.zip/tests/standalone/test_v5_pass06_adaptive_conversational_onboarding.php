<?php
$root=dirname(__DIR__,2);
$req=[
 'System/Adaptive/AdaptiveQuestionCatalog.php',
 'System/Adaptive/BusinessKnowledgeGapResolver.php',
 'System/Adaptive/InformationGainScorer.php',
 'System/Adaptive/AdaptiveOnboardingEngine.php',
 'System/Adaptive/AdaptiveOnboardingRuntimeService.php',
 'System/Persistence/Models/AdaptiveQuestionState.php',
 'System/Http/Controllers/AdaptiveOnboardingController.php'
];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}

$engine=file_get_contents($root.'/System/Adaptive/AdaptiveOnboardingEngine.php');
$runtime=file_get_contents($root.'/System/Adaptive/AdaptiveOnboardingRuntimeService.php');
$catalog=file_get_contents($root.'/System/Adaptive/AdaptiveQuestionCatalog.php');
$routes=file_get_contents($root.'/routes/user.php');

$checks=[
 str_contains($engine,'information_gain'),
 str_contains($engine,'questions_remaining'),
 str_contains($engine,'resolved_by_answer'),
 str_contains($engine,'deferred'),
 str_contains($engine,'not_sure'),
 str_contains($engine,'chat'),
 str_contains($engine,'voice'),
 str_contains($engine,'vision'),
 str_contains($engine,'pwa'),
 str_contains($catalog,'blocking'),
 str_contains($catalog,'optional'),
 str_contains($catalog,'verticals'),
 str_contains($catalog,'depends_on'),
 str_contains($runtime,'CanonicalBusinessFact'),
 str_contains($runtime,'owner_confirmed'),
 str_contains($runtime,'company_id'),
 str_contains($routes,'adaptive/next'),
 str_contains($routes,'adaptive/answer'),
 str_contains($routes,'adaptive/defer')
];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 6 adaptive onboarding contract incomplete\n");exit(1);}

echo "PASS: v5 Pass 6 adaptive conversational onboarding engine\n";
