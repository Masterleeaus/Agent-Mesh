<?php
$root=dirname(__DIR__,2);
$required=[
 'System/Discovery/PublicWeb/PublicBusinessDiscoveryService.php',
 'System/Discovery/PublicWeb/BusinessIdentityResolver.php',
 'System/Persistence/Models/BusinessDiscoveryEvidence.php',
 'System/Persistence/Models/BusinessIdentityCandidate.php',
];
foreach($required as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}}
$d=file_get_contents($root.'/System/Discovery/PublicWeb/PublicBusinessDiscoveryService.php');
$i=file_get_contents($root.'/System/Discovery/PublicWeb/BusinessIdentityResolver.php');
$checks=[
 str_contains($d,'company_id'),str_contains($d,'consent'),str_contains($d,'source_type'),
 str_contains($d,'observed_at'),str_contains($d,'candidate'),
 str_contains($i,'identity_confidence'),str_contains($i,'business_name'),
 str_contains($i,'location'),str_contains($i,'phone'),str_contains($i,'domain'),
 str_contains($i,'owner_name'),str_contains($i,'same_name_collision')
];
foreach($checks as $ok){if(!$ok){fwrite(STDERR,"Pass 1 discovery contract incomplete\n");exit(1);}}
echo "PASS: v5 Pass 1 business discovery and identity resolution\n";
