<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryJourneyFactory;
$steps=(new BusinessDiscoveryJourneyFactory())->steps();
if(count($steps)<3) throw new RuntimeException('progressive journey too small');
$fields=[];foreach($steps as $s){foreach(($s->config['fields']??[]) as $f){$fields[]=$f['name']??'';}}
foreach(['business_identity','industry','services','service_areas','jurisdiction','size','staff','operating_hours','timezone','pricing_approach','job_lifecycle','communication_channels','payment_methods','equipment_assets','compliance_requirements','privacy_preferences','ai_provider_preferences','autonomy_preferences','risk_tolerance'] as $name){if(!in_array($name,$fields,true)) throw new RuntimeException("missing discovery field $name");}
$last=$steps[array_key_last($steps)];
if($last->capabilityId!=='onboarding.provisioning.prepare'||$last->offlinePolicy!=='deferred') throw new RuntimeException('provisioning prepare boundary');
if(($steps[0]->config['stage']??'')!=='minimum') throw new RuntimeException('minimum stage must come first');
echo "test_business_discovery_journey PASS\n";
