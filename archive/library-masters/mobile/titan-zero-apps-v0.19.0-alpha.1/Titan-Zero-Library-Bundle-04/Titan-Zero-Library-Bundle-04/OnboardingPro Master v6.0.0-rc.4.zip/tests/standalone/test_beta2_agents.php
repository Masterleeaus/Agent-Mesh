<?php
$root=dirname(__DIR__,2);
foreach(['/System/Agents/AgentTask.php','/System/Agents/OnboardingManager.php','/System/Agents/ComplianceAssistant.php','/System/Agents/RenewalAssistant.php'] as $f){if(!is_file($root.$f)){fwrite(STDERR,"missing $f\n");exit(1);}require_once $root.$f;}
use App\Extensions\OnboardingPro\System\Agents\OnboardingManager;
$mgr=new OnboardingManager();
$t=$mgr->planReminder(44,'enrolment:12','participant:91','evidence_missing','trace-x');
if($t->status!=='PREPARED'||$t->directMutation!==false)exit(2);
if($t->capability!=='message.prepare'||$t->companyId!==44)exit(3);
echo "beta2 agents PASS\n";
