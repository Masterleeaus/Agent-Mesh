<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
spl_autoload_register(function(string $class) use($root):void{$p='App\\Extensions\\OnboardingPro\\';if(str_starts_with($class,$p)){ $f=$root.'/'.str_replace('\\','/',substr($class,strlen($p))).'.php'; if(is_file($f)) require $f; }});
use App\Extensions\OnboardingPro\System\Offline\OfflineAuthorityPolicy;
use App\Extensions\OnboardingPro\System\Offline\OnboardingOfflineManifest;
use App\Extensions\OnboardingPro\System\Offline\OnboardingMutation;
use App\Extensions\OnboardingPro\System\Offline\OnboardingConflictResolver;
$p=new OfflineAuthorityPolicy();
if($p->effectiveCeiling(5,3,4)!==3)throw new RuntimeException('offline ceiling increased');
if($p->mayExecute(5,3,4,4))throw new RuntimeException('high risk action allowed over ceiling');
$m=OnboardingOfflineManifest::fromSteps(44,'e1','v1',[['key'=>'a','offline_policy'=>'allowed'],['key'=>'b','offline_policy'=>'deferred'],['key'=>'c','offline_policy'=>'online_required']]);
if(!$m->canCompleteOffline('a')||$m->canCompleteOffline('b')||!$m->canQueueOffline('b')||$m->canQueueOffline('c'))throw new RuntimeException('offline policies');
$mut=OnboardingMutation::create(44,'e1','a','complete',[],'d1','oldhash');
$d=(new OnboardingConflictResolver())->resolve(['status'=>'pending','updated_at'=>'2026-08-11T05:02:00Z','base_hash'=>'oldhash'],['status'=>'completed','updated_at'=>'2026-08-11T05:01:00Z','state_hash'=>'newhash'],$mut);
if($d['winner']!=='server'||$d['reason']!=='server_terminal_state'||($d['conflicted']??false)!==true)throw new RuntimeException('stale conflict not explicit');
echo "test_alpha5_offline_governance PASS\n";
