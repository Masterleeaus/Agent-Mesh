<?php
$root = dirname(__DIR__, 2);
require $root . '/System/Tenancy/OnboardingActorContext.php';
require $root . '/System/Tenancy/OnboardingCompanyContext.php';
require $root . '/System/Tenancy/OnboardingCompanyResolver.php';
require $root . '/System/Tenancy/OnboardingScope.php';

use App\Extensions\OnboardingPro\System\Tenancy\OnboardingActorContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyResolver;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingScope;

$fail = [];
$actor = new OnboardingActorContext(91, 'user', ['manager'], ['onboarding.read'], 'titan-go');
$ctx = new OnboardingCompanyContext(44, $actor);
if ($ctx->companyId !== 44 || $ctx->actor->userId !== 91) $fail[] = 'context fields mismatch';
$resolver = new OnboardingCompanyResolver();
try { $resolver->fromTrustedValues(0, 91); $fail[] = 'invalid company accepted'; } catch (InvalidArgumentException) {}
try { $resolver->fromTrustedValues(44, 0); $fail[] = 'invalid actor accepted'; } catch (InvalidArgumentException) {}
$resolved = $resolver->fromTrustedValues(44, 91, 'user', ['manager'], ['onboarding.read'], 'web');
if ($resolved->companyId !== 44) $fail[] = 'resolver failed';
$scope = new OnboardingScope($resolved);
if ($scope->assertCompany(44) !== 44) $fail[] = 'same company rejected';
try { $scope->assertCompany(45); $fail[] = 'foreign company accepted'; } catch (RuntimeException) {}
$query = $scope->constraints(['status' => 'active']);
if (($query['company_id'] ?? null) !== 44 || ($query['status'] ?? null) !== 'active') $fail[] = 'scope constraints mismatch';
if ($fail) { fwrite(STDERR, implode("\n", $fail) . "\n"); exit(1); }
echo "tenancy PASS\n";
