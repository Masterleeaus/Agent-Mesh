<?php
$root=dirname(__DIR__,2);
$req=[
 'System/Discovery/Nexus/NexusConfigurationIntelligenceService.php',
 'System/Discovery/Nexus/NexusCostSovereigntyPolicy.php',
 'System/Persistence/Models/NexusConfigurationDecision.php'
];
foreach($req as $f)if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing: $f\n");exit(1);}

$i=file_get_contents($root.'/System/Discovery/Nexus/NexusConfigurationIntelligenceService.php');
$c=file_get_contents($root.'/System/Discovery/Nexus/NexusCostSovereigntyPolicy.php');
$r=file_get_contents($root.'/System/Discovery/Nexus/NexusConfigurationReviewService.php');

$checks=[
 str_contains($i,'why'),
 str_contains($i,'dependencies'),
 str_contains($i,'authority'),
 str_contains($i,'autonomy_ceiling'),
 str_contains($i,'execution_location'),
 str_contains($i,'provider'),
 str_contains($i,'cost_owner'),
 str_contains($i,'risk'),
 str_contains($i,'reversible'),
 str_contains($i,'verification'),
 str_contains($i,'company_id'),
 str_contains($c,'device'),
 str_contains($c,'local'),
 str_contains($c,'byo'),
 str_contains($c,'customer_service'),
 str_contains($c,'titan_entitlement'),
 str_contains($c,'titan_metered'),
 str_contains($c,'explicit_opt_in'),
 str_contains($r,'configuration_intelligence')
];
foreach($checks as $ok)if(!$ok){fwrite(STDERR,"Pass 8 Nexus configuration/cost contract incomplete\n");exit(1);}
echo "PASS: v5 Pass 8 Nexus configuration intelligence and cost sovereignty\n";
