<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$provider=file_get_contents($root.'/System/OnboardingProServiceProvider.php');
foreach([
 'InteractionJourneyAdapter::class',
 'OnboardingJourneyRuntime::class',
 'OnboardingCapabilityPolicy::class',
 'ParticipantAssignmentService::class',
 'HandoffService::class',
] as $needle) if(!str_contains($provider,$needle)) throw new RuntimeException('provider missing '.$needle);
$m=json_decode(file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(($m['version']??'')!=='6.0.0-rc.3') throw new RuntimeException('sidecar version');
if(($m['runtime_boundary']['interaction_engine_active_in_alpha_3']??false)!==true) throw new RuntimeException('runtime flag');
if(($m['runtime_boundary']['interaction_engine_required']??true)!==false) throw new RuntimeException('optional runtime contract');
$c=require $root.'/config/onboarding-pro.php'; if(($c['version']??'')!=='6.0.0-rc.3') throw new RuntimeException('config version');
echo "test_alpha3_wiring PASS\n";
