<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Steps;

final class StepTypeRegistry
{
    /** @var array<string,array<string,mixed>> */
    private array $types = [];

    public static function withTitanDefaults(): self
    {
        $registry = new self();
        foreach (StepType::cases() as $type) {
            $category = match ($type) {
                StepType::Information, StepType::GuidedTour, StepType::Announcement, StepType::Document, StepType::Video => 'presentation',
                StepType::Form, StepType::Checklist, StepType::Survey => 'input',
                StepType::Quiz, StepType::PracticalSignoff, StepType::Certificate => 'learning',
                StepType::Signature, StepType::Evidence, StepType::Approval => 'trust',
                StepType::PaymentConfirmation, StepType::Booking, StepType::Integration => 'capability',
                StepType::Completion => 'lifecycle',
            };
            $registry->register($type->value, ['category' => $category]);
        }
        return $registry;
    }

    /** @param array<string,mixed> $metadata */
    public function register(string $key, array $metadata): void
    {
        if (isset($this->types[$key])) throw new \LogicException("Step type already registered: {$key}");
        if (StepType::tryFrom($key) === null) throw new \InvalidArgumentException("Unknown Titan onboarding step type: {$key}");
        $this->types[$key] = $metadata;
    }

    /** @return array<string,mixed> */
    public function resolve(string $key): array
    {
        if (!isset($this->types[$key])) throw new \InvalidArgumentException("Unknown onboarding step type: {$key}");
        return $this->types[$key];
    }

    /** @return list<string> */
    public function keys(): array
    {
        return array_keys($this->types);
    }

    public function validate(StepDefinition $definition): void
    {
        $this->resolve($definition->type->value);
        if ($definition->type === StepType::Evidence && isset($definition->config['allowed_mime']) && !is_array($definition->config['allowed_mime'])) {
            throw new \InvalidArgumentException('Evidence allowed_mime must be an array.');
        }
        if (in_array($definition->type, [StepType::PaymentConfirmation, StepType::Booking, StepType::Integration], true)
            && $definition->capabilityId !== null
            && trim($definition->capabilityId) === '') {
            throw new \InvalidArgumentException('Capability ID cannot be blank.');
        }
    }
}
