<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Security\ParticipantAccessGrant;
use Illuminate\Http\Request; use Illuminate\Routing\Controller;
final class ParticipantJourneyController extends Controller
{
    public function show(Request $request,string $grant){/** @var ParticipantAccessGrant $access */$access=$request->attributes->get('onboarding_participant_grant');return view('onboarding-pro::participant.show',['grant'=>$grant,'access'=>$access]);}
    public function completeStep(Request $request,string $grant,string $step){/** @var ParticipantAccessGrant $access */$access=$request->attributes->get('onboarding_participant_grant');abort_unless($access instanceof ParticipantAccessGrant && $access->allowsStep($step),403);return response()->json(['status'=>'PREPARED','authoritative'=>false,'step_key'=>$step,'company_id'=>$access->companyId,'enrolment_id'=>$access->enrolmentId,'participant_id'=>$access->participantId]);}
}
