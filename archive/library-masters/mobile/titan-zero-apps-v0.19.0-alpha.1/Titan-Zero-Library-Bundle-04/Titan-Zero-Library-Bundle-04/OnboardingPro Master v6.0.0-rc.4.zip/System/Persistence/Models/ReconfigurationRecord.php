<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class ReconfigurationRecord extends Model{protected $table='ext_onboarding_reconfigurations';protected $guarded=[];protected $casts=['company_id'=>'integer','from_revision'=>'integer','to_revision'=>'integer','semantic_diff'=>'array','impact_preview'=>'array','approval_snapshot'=>'array','execution_receipt'=>'array','verification_receipt'=>'array','approved_by_user_id'=>'integer','approved_at'=>'immutable_datetime'];}
