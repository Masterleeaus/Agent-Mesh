<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Workforce;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionPriority;use App\Extensions\OnboardingPro\System\Persistence\Models\NexusWorkforceCommand;
final readonly class NexusWorkforceCommandBridge
{
 public function __construct(private WorkforceDomainRouter $router){}
 public function dispatch(int $company_id,int $priorityId,array $authority=[]):NexusWorkforceCommand
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $priority=InterventionPriority::query()->where('company_id',$company_id)->whereKey($priorityId)->firstOrFail();
  if($priority->blocking||$priority->category==='DO_NOT_ACT_YET')throw new \RuntimeException('Nexus cannot dispatch a blocked or DO_NOT_ACT_YET intervention.');
  $op=BusinessOpportunity::query()->where('company_id',$company_id)->whereKey($priority->business_opportunity_id)->firstOrFail();
  $dependencies=array_values(array_filter((array)$op->dependencies,fn($v)=>is_string($v)));
  $routing=$this->router->route((string)$op->domain,$dependencies);
  $objective=['source'=>'Nexus','title'=>$op->title,'recommendation'=>$op->recommendation,'intervention'=>$op->intervention,'measurement'=>$op->measurement];
  return NexusWorkforceCommand::query()->create([
   'company_id'=>$company_id,'business_opportunity_id'=>$op->id,'intervention_priority_id'=>$priority->id,
   'objective'=>$objective,'evidence'=>$op->evidence,'authority_context'=>$authority,'routing'=>$routing,
   'status'=>'proposed','requires_approval'=>true,'dispatched_at'=>now(),
  ]);
 }
}
