<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Competition\CompetitorDiscoveryService;use App\Extensions\OnboardingPro\System\Competition\CompetitorIdentityResolutionService;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class CompetitorDiscoveryController extends Controller{
 public function __construct(private readonly CompetitorDiscoveryService $discovery,private readonly CompetitorIdentityResolutionService $identity){}
 public function discover(Request $r){$r->validate(['business'=>['required','array'],'candidates'=>['required','array']]);return response()->json($this->discovery->discover($this->companyId($r),(array)$r->input('business'),(array)$r->input('candidates')));}
 public function decision(Request $r){$r->validate(['competitor_id'=>['required','integer'],'decision'=>['required','in:confirm,not_competitor,watch,ignore']]);return response()->json($this->identity->decide($this->companyId($r),(int)$r->input('competitor_id'),(string)$r->input('decision')));}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
