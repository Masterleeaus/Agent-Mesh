<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Participants;
final readonly class Handoff
{
 public function __construct(public int $companyId,public string $enrolmentId,public string $stepKey,public string $assignedActorId,public string $reason,public string $status,public ?string $dueAt,public ?string $completedAt=null){}
}
