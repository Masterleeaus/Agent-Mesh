<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Learning;
final class ExperimentComparisonService {
 public function compare(array $a,array $b):array {
  $keys=array_unique(array_merge(array_keys((array)($a['delta']??[])),array_keys((array)($b['delta']??[]))));$delta=[];
  foreach($keys as $k)$delta[$k]=(float)($b['delta'][$k]??0)-(float)($a['delta'][$k]??0);
  $confidence=min((int)($a['confidence']??0),(int)($b['confidence']??0));
  return ['delta'=>$delta,'confidence'=>$confidence,'preferred'=>array_sum($delta)>0?'b':(array_sum($delta)<0?'a':'inconclusive')];
 }
}
