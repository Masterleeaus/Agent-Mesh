<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\InteractionEngine;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
final readonly class InteractionWorkflowExecutor
{
    public function __construct(private object $runtime){}
    public function execute(string $workflowId,string $workflowVersion,OnboardingTraceContext $trace,array $inputs):array
    {
        if(!method_exists($this->runtime,'execute'))throw new \RuntimeException('Interaction workflow runtime does not expose execute().');
        $context=$trace->toArray();
        $result=$this->runtime->execute($workflowId,$workflowVersion,$context,$inputs);
        if(!is_array($result))throw new \RuntimeException('Interaction workflow runtime returned unsupported result.');
        foreach(['execution_id','status'] as $k)if(trim((string)($result[$k]??''))==='')throw new \RuntimeException("Interaction workflow result missing $k.");
        return $result;
    }
}
