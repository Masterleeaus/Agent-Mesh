<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Security;
final class ParticipantGrantService
{
    public function __construct(private string $secret){if($secret==='')throw new \InvalidArgumentException('Participant grant secret is required.');}
    public function issue(int $companyId,int $enrolmentId,int $participantId,array $allowedSteps,\DateTimeImmutable $issuedAt,\DateTimeImmutable $expiresAt): ParticipantAccessGrant
    {
        if($companyId<=0||$enrolmentId<=0||$participantId<=0||$expiresAt<=$issuedAt)throw new \InvalidArgumentException('Invalid participant grant.');
        $steps=array_values(array_unique(array_map('strval',$allowedSteps)));sort($steps);
        $nonce=bin2hex(random_bytes(16));$sig=$this->signature($companyId,$enrolmentId,$participantId,$steps,$issuedAt,$expiresAt,$nonce);
        return new ParticipantAccessGrant($companyId,$enrolmentId,$participantId,$steps,$issuedAt,$expiresAt,$nonce,$sig);
    }
    public function verify(ParticipantAccessGrant $grant,\DateTimeImmutable $now): bool
    {
        if($now<$grant->issuedAt||$now>=$grant->expiresAt)return false;
        $expected=$this->signature($grant->companyId,$grant->enrolmentId,$grant->participantId,$grant->allowedSteps,$grant->issuedAt,$grant->expiresAt,$grant->nonce);
        return hash_equals($expected,$grant->signature);
    }
    public function encode(ParticipantAccessGrant $grant): string
    {
        $payload=['t'=>$grant->companyId,'e'=>$grant->enrolmentId,'p'=>$grant->participantId,'s'=>$grant->allowedSteps,'iat'=>$grant->issuedAt->getTimestamp(),'exp'=>$grant->expiresAt->getTimestamp(),'n'=>$grant->nonce,'sig'=>$grant->signature];
        return rtrim(strtr(base64_encode(json_encode($payload,JSON_THROW_ON_ERROR)),'+/','-_'),'=');
    }
    public function decode(string $token): ParticipantAccessGrant
    {
        $raw=base64_decode(strtr($token,'-_','+/'),true);if($raw===false)throw new \InvalidArgumentException('Invalid participant token.');
        $p=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
        return new ParticipantAccessGrant((int)$p['t'],(int)$p['e'],(int)$p['p'],array_values($p['s']??[]),(new \DateTimeImmutable())->setTimestamp((int)$p['iat']),(new \DateTimeImmutable())->setTimestamp((int)$p['exp']),(string)$p['n'],(string)$p['sig']);
    }
    private function signature(int $t,int $e,int $p,array $steps,\DateTimeImmutable $iat,\DateTimeImmutable $exp,string $nonce): string{return hash_hmac('sha256',json_encode([$t,$e,$p,array_values($steps),$iat->getTimestamp(),$exp->getTimestamp(),$nonce],JSON_THROW_ON_ERROR),$this->secret);}
}
