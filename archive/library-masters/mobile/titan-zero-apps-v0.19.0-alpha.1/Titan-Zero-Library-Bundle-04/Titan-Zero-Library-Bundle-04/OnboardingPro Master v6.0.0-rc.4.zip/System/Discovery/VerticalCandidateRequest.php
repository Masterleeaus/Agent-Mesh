<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class VerticalCandidateRequest
{
    /**
     * @param list<string> $industrySignals
     * @param list<string> $serviceFamilies
     * @param list<array<string,mixed>> $jurisdictions
     * @param list<mixed> $locations
     * @param list<string> $complianceDomains
     */
    public function __construct(
        public int $companyId,
        public int $businessProfileRevision,
        public array $businessIdentity,
        public array $industrySignals,
        public array $serviceFamilies,
        public array $jurisdictions,
        public array $locations,
        public string $operatingComplexity,
        public int $workforceSize,
        public array $businessModel,
        public array $complianceDomains,
        public array $traceContext,
    ) {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Vertical candidate request requires a positive company_id.');
        }
        if ($businessProfileRevision <= 0) {
            throw new \InvalidArgumentException('Vertical candidate request requires a positive business profile revision.');
        }
        if ($industrySignals === []) {
            throw new \InvalidArgumentException('Vertical candidate request requires at least one industry signal.');
        }
        if ($serviceFamilies === []) {
            throw new \InvalidArgumentException('Vertical candidate request requires at least one service family.');
        }
        if ($jurisdictions === []) {
            throw new \InvalidArgumentException('Vertical candidate request requires jurisdiction context.');
        }
        if (trim($operatingComplexity) === '') {
            throw new \InvalidArgumentException('Vertical candidate request requires operating complexity.');
        }
        if ($workforceSize < 0) {
            throw new \InvalidArgumentException('Vertical candidate request workforce size cannot be negative.');
        }
    }

    public static function fromProfile(BusinessDiscoveryProfile $profile, int $profileRevision, OnboardingTraceContext $trace): self
    {
        $industry = trim($profile->industry);
        $services = self::normaliseStringList($profile->services);
        $jurisdiction = self::normaliseJurisdiction($profile->jurisdiction);
        $staffCount = max(0, (int) ($profile->staff['count'] ?? count((array) ($profile->staff['roles'] ?? []))));
        $complexity = self::normaliseComplexity($profile->size, $staffCount);

        return new self(
            companyId: $trace->companyId,
            businessProfileRevision: $profileRevision,
            businessIdentity: $profile->businessIdentity,
            industrySignals: self::normaliseStringList([$industry]),
            serviceFamilies: $services,
            jurisdictions: [$jurisdiction],
            locations: array_values($profile->serviceAreas),
            operatingComplexity: $complexity,
            workforceSize: $staffCount,
            businessModel: array_filter([
                'pricing_approach' => $profile->pricingApproach !== '' ? $profile->pricingApproach : null,
                'job_lifecycle' => $profile->jobLifecycle !== [] ? array_values($profile->jobLifecycle) : null,
                'communication_channels' => $profile->communicationChannels !== [] ? array_values($profile->communicationChannels) : null,
                'payment_methods' => $profile->paymentMethods !== [] ? array_values($profile->paymentMethods) : null,
            ], static fn (mixed $value): bool => $value !== null),
            complianceDomains: self::normaliseStringList($profile->complianceRequirements),
            traceContext: $trace->toArray(),
        );
    }

    public function toArray(): array
    {
        return [
            'schema' => 'titan.vertical-candidate-request',
            'version' => '1.1',
            'company_id' => $this->companyId,
            'business_profile_version' => 'discovery-r'.$this->businessProfileRevision,
            'business_profile_revision' => $this->businessProfileRevision,
            'business_identity' => $this->businessIdentity,
            'industry_signals' => $this->industrySignals,
            'service_families' => $this->serviceFamilies,
            'jurisdictions' => $this->jurisdictions,
            'locations' => $this->locations,
            'operating_complexity' => $this->operatingComplexity,
            'workforce_size' => $this->workforceSize,
            'business_model' => $this->businessModel,
            'compliance_domains' => $this->complianceDomains,
            'trace_context' => $this->traceContext,
        ];
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode(self::canonicalise($this->toArray()), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    public static function sourceFingerprint(BusinessDiscoveryProfile $profile): string
    {
        $staffCount = max(0, (int) ($profile->staff['count'] ?? count((array) ($profile->staff['roles'] ?? []))));
        $source = [
            'business_identity' => $profile->businessIdentity,
            'industry_signals' => self::normaliseStringList([$profile->industry]),
            'service_families' => self::normaliseStringList($profile->services),
            'jurisdictions' => [self::normaliseJurisdiction($profile->jurisdiction)],
            'locations' => array_values($profile->serviceAreas),
            'operating_complexity' => self::normaliseComplexity($profile->size, $staffCount),
            'workforce_size' => $staffCount,
            'business_model' => [
                'pricing_approach' => $profile->pricingApproach,
                'job_lifecycle' => array_values($profile->jobLifecycle),
                'communication_channels' => array_values($profile->communicationChannels),
                'payment_methods' => array_values($profile->paymentMethods),
            ],
            'compliance_domains' => self::normaliseStringList($profile->complianceRequirements),
        ];

        return hash('sha256', json_encode(self::canonicalise($source), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    /** @return list<string> */
    private static function normaliseStringList(array $values): array
    {
        $result = [];
        foreach ($values as $value) {
            $value = trim((string) $value);
            if ($value !== '') {
                $result[] = $value;
            }
        }

        return array_values(array_unique($result));
    }

    /** @return array<string,mixed> */
    private static function normaliseJurisdiction(array $jurisdiction): array
    {
        $country = strtoupper(trim((string) ($jurisdiction['country'] ?? $jurisdiction['country_code'] ?? '')));
        if ($country === '') {
            throw new \InvalidArgumentException('Vertical candidate jurisdiction requires country.');
        }
        $region = strtoupper(trim((string) ($jurisdiction['region'] ?? $jurisdiction['state'] ?? '')));
        $result = ['country' => $country];
        if ($region !== '') {
            $result['region'] = $region;
        }
        foreach (['locality','postcode'] as $key) {
            $value = trim((string) ($jurisdiction[$key] ?? ''));
            if ($value !== '') {
                $result[$key] = $value;
            }
        }
        return $result;
    }

    private static function normaliseComplexity(string $size, int $staffCount): string
    {
        $complexity = strtoupper(str_replace([' ', '-'], '_', trim($size)));
        $aliases = [
            'MICRO' => 'SOLO',
            'SMALL' => 'SMALL_TEAM',
            'SMALL_BUSINESS' => 'SMALL_TEAM',
            'MEDIUM' => 'GROWING',
            'LARGE' => 'ENTERPRISE',
        ];
        $complexity = $aliases[$complexity] ?? $complexity;
        if (in_array($complexity, ['SOLO','SMALL_TEAM','GROWING','MULTI_SITE','ENTERPRISE'], true)) {
            return $complexity;
        }
        return $staffCount <= 1 ? 'SOLO' : ($staffCount <= 10 ? 'SMALL_TEAM' : ($staffCount <= 50 ? 'GROWING' : 'ENTERPRISE'));
    }

    private static function canonicalise(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(self::canonicalise(...), $value);
        }
        ksort($value);
        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalise($item);
        }
        return $value;
    }
}
