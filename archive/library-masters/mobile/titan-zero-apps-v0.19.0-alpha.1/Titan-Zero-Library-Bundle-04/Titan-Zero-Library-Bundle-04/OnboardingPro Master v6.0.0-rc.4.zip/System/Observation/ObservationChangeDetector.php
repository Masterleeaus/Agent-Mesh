<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Observation;

final class ObservationChangeDetector
{
 public function compare(mixed $previous,mixed $current,int $confidence=100):array
 {
  if($previous===null&&$current!==null)$state='new';
  elseif($previous!==null&&$current===null)$state='missing';
  elseif($this->normalise($previous)===$this->normalise($current))$state='unchanged';
  else $state='changed';
  return ['state'=>$state,'previous'=>$previous,'current'=>$current,'confidence'=>max(0,min(100,$confidence)),'meaningful'=>$state!=='unchanged'];
 }
 private function normalise(mixed $value):string{return json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION)?:'';}
}
