<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

final readonly class ProgressiveReadinessResult
{
    public function __construct(
        public bool $minimumReady,
        public bool $operationalReady,
        public array $remainingDomains,
        public array $reasonCodes,
    ) {}
}
