<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\RealityGraph\BusinessRealityGraphService;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class BusinessRealityGraphController extends Controller{
 public function __construct(private readonly BusinessRealityGraphService $graph){}
 public function show(Request $request){return response()->json($this->graph->snapshot($this->companyId($request)));}
 private function companyId(Request $request):int{$c=$request->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403,'Titan Onboarding company context unavailable.');return $c->companyId;}
}
