<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

final class DiscoveryProfileFingerprint
{
    public static function forPayload(array $payload): string
    {
        $canonical = self::canonicalize($payload);
        $json = json_encode(
            $canonical,
            JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION
        );

        return hash('sha256', $json);
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }

        if (!array_is_list($value)) {
            ksort($value, SORT_STRING);
        }

        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalize($item);
        }

        return $value;
    }
}
