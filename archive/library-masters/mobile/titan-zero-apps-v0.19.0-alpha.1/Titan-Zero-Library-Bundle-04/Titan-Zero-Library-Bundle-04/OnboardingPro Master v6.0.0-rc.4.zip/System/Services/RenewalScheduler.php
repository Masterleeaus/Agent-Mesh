<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Renewals\RenewalPlan;
use App\Extensions\OnboardingPro\System\Domain\Renewals\RenewalRequirement;
use DateTimeImmutable;

final class RenewalScheduler
{
    public function plan(RenewalRequirement $requirement, DateTimeImmutable $now): RenewalPlan
    {
        $start = $requirement->expiresAt->modify(sprintf('-%d days', max(0,$requirement->leadDays)));
        $due = $now >= $start;
        $window = $requirement->expiresAt->format('Y-m-d');
        $key = hash('sha256', implode('|', [$requirement->companyId,$requirement->requirementId,$requirement->subjectType,$requirement->subjectId,$window,$requirement->targetJourneyKey]));
        return new RenewalPlan($due,$key,$requirement->targetJourneyKey,$due?['renewal_window_open']:['renewal_not_due']);
    }
}
