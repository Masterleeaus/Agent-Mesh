<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Security;
use App\Extensions\OnboardingPro\System\Persistence\Models\ParticipantGrantRecord;
final class ParticipantGrantIssuer
{
    public function __construct(private ParticipantGrantService $grants){}
    public function issue(int $companyId,int $enrolmentId,int $participantId,array $allowedSteps,\DateTimeImmutable $issuedAt,\DateTimeImmutable $expiresAt): array
    {
        $grant=$this->grants->issue($companyId,$enrolmentId,$participantId,$allowedSteps,$issuedAt,$expiresAt);$token=$this->grants->encode($grant);$hash=hash('sha256',$token);
        ParticipantGrantRecord::query()->create(['company_id'=>$companyId,'enrolment_id'=>$enrolmentId,'participant_id'=>$participantId,'token_hash'=>$hash,'allowed_steps'=>$grant->allowedSteps,'expires_at'=>$expiresAt]);
        return ['token'=>$token,'token_hash'=>$hash,'grant'=>$grant];
    }
    public function revoke(string $token): void {ParticipantGrantRecord::query()->where('token_hash',hash('sha256',$token))->whereNull('revoked_at')->update(['revoked_at'=>now()]);}
}
