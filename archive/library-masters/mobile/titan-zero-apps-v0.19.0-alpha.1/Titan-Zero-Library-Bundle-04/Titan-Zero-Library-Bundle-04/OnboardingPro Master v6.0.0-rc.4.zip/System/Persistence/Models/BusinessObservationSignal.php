<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessObservationSignal extends Model{protected $table='ext_onboarding_observation_signals';protected $guarded=[];protected $casts=['company_id'=>'integer','observation_run_id'=>'integer','evidence'=>'array','payload'=>'array','confidence'=>'integer','observed_at'=>'immutable_datetime'];}
