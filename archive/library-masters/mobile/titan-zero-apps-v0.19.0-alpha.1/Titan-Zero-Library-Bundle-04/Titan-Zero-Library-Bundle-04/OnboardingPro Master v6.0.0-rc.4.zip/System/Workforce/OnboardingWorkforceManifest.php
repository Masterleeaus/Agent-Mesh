<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Workforce;
final class OnboardingWorkforceManifest{
 public function toArray():array{return ['schema'=>'titan.workforce-extension-manifest','version'=>'1.0','extension'=>'onboarding-pro','tenant_key'=>'company_id','roles'=>[
 ['key'=>'onboarding_manager','name'=>'Onboarding Manager','responsibilities'=>['coordinate business setup','triage setup exceptions','verify onboarding outcomes']],
 ['key'=>'setup_assistant','name'=>'Setup Assistant','responsibilities'=>['collect missing business facts','guide configuration gaps']],
 ['key'=>'compliance_assistant','name'=>'Compliance Assistant','responsibilities'=>['track compliance requirements','escalate unsupported compliance claims']],
 ['key'=>'training_assistant','name'=>'Training Assistant','responsibilities'=>['coordinate role onboarding','surface training work']],
 ['key'=>'evidence_assistant','name'=>'Evidence Assistant','responsibilities'=>['collect setup evidence','maintain verification provenance']],
 ['key'=>'renewal_assistant','name'=>'Renewal Assistant','responsibilities'=>['track credential renewal work','escalate expiry risk']],
 ]];}}
