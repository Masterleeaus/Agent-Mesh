<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Reconfiguration;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusRuntimeGatewayInterface;
use App\Extensions\OnboardingPro\System\Persistence\Models\ReconfigurationRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
final readonly class BusinessReconfigurationService{
 public function __construct(private BusinessConfigurationDiffer $differ,private NexusRuntimeGatewayInterface $gateway){}
 public function preview(int $company_id,int $fromRevision,int $toRevision,array $before,array $after,OnboardingTraceContext $trace):ReconfigurationRecord{
  if($company_id<=0||$trace->companyId!==$company_id)throw new \RuntimeException('Cross-company reconfiguration denied.');
  if($toRevision<=$fromRevision)throw new \RuntimeException('Reconfiguration requires a newer discovery revision.');
  $semantic_diff=$this->differ->semantic_diff($before,$after);if(!$semantic_diff['has_changes'])throw new \RuntimeException('No semantic business configuration changes detected.');
  $draft=$this->gateway->newDraft(['company_id'=>$company_id,'operation'=>'reconfigure_business','from_revision'=>$fromRevision,'to_revision'=>$toRevision,'semantic_diff'=>$semantic_diff]);
  $validation=$this->gateway->validateDraft($draft);$impact_preview=$this->gateway->previewDraft($draft);
  return ReconfigurationRecord::query()->create(['company_id'=>$company_id,'from_revision'=>$fromRevision,'to_revision'=>$toRevision,'status'=>'previewed','semantic_diff'=>$semantic_diff,'impact_preview'=>['draft'=>$draft,'validation'=>$validation,'preview'=>$impact_preview],'trace_id'=>$trace->traceId,'correlation_id'=>$trace->correlationId]);
 }
 public function approve(ReconfigurationRecord $record,int $userId,OnboardingTraceContext $trace):ReconfigurationRecord{
  if((int)$record->company_id!==$trace->companyId||$record->status!=='previewed'||$userId<=0)throw new \RuntimeException('Current company preview and authenticated approval are required.');
  $snapshot=['semantic_diff'=>$record->semantic_diff,'impact_preview'=>$record->impact_preview,'from_revision'=>$record->from_revision,'to_revision'=>$record->to_revision];
  $approval_fingerprint=hash('sha256',json_encode($snapshot,JSON_THROW_ON_ERROR));$record->approval_fingerprint=$approval_fingerprint;$record->approval_snapshot=$snapshot;$record->approved_by_user_id=$userId;$record->approved_at=now();$record->status='approved';$record->save();return $record->refresh();
 }
 public function executeAndVerify(ReconfigurationRecord $record,OnboardingTraceContext $trace):array{
  if((int)$record->company_id!==$trace->companyId||$record->status!=='approved')throw new \RuntimeException('Approved company reconfiguration required.');
  $impact=(array)$record->impact_preview;$draft=(array)($impact['draft']??[]);$compiled=$this->gateway->compileDraft($draft);$plan=$this->gateway->planProvisioning($compiled);
  $idempotency=hash('sha256',$record->company_id.'|'.$record->approval_fingerprint.'|reconfigure');$execution=$this->gateway->executeProvisioning($plan,$idempotency);$verification=$this->gateway->verifyProvisioning($execution);
  $record->execution_receipt=$execution;$record->verification_receipt=$verification;$record->status=(bool)($verification['operational_ready']??false)?'verified':'attention_required';$record->save();
  return ['company_id'=>(int)$record->company_id,'reconfiguration_id'=>(int)$record->id,'status'=>$record->status,'execution'=>$execution,'verification'=>$verification,'history'=>$this->history((int)$record->company_id)];
 }
 public function history(int $company_id):array{return ReconfigurationRecord::query()->where('company_id',$company_id)->orderByDesc('id')->get()->map(fn($r)=>['id'=>$r->id,'from_revision'=>$r->from_revision,'to_revision'=>$r->to_revision,'status'=>$r->status,'approved_at'=>$r->approved_at])->all();}
}
