<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Automation;
final readonly class TriggerEvaluation{public function __construct(public bool $matched,public int $companyId,public string $eventType,public string $subjectRef,public string $journeyKey,public string $idempotencyKey,public array $context){}}
