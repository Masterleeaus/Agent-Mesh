<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Automation;
final readonly class OnboardingTrigger{public function __construct(public string $eventType,public string $journeyKey,public array $requiredContext=[]){}}
