<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Competition;
final class MarketPatternService
{
 public function analyse(string $metric,mixed $businessValue,array $cohortValues,array $evidence=[]):array
 {
  $numeric=array_values(array_filter($cohortValues,'is_numeric'));$cohort=count($cohortValues);
  $prevalence=$cohort===0?0.0:count(array_filter($cohortValues,fn($v)=>(bool)$v))/$cohort;
  sort($numeric);$median=$numeric===[]?0.0:(float)$numeric[(int)floor((count($numeric)-1)/2)];
  $business=is_numeric($businessValue)?(float)$businessValue:((bool)$businessValue?1.0:0.0);
  $deviation=$business-$median;
  $confidence=min(100,(int)round(min(1,$cohort/10)*70+min(30,count($evidence)*5)));
  $meaningful=$cohort>=3 && (abs($deviation)>=0.20 || ($prevalence>=0.65 && !$business));
  return ['metric'=>$metric,'cohort_size'=>$cohort,'prevalence'=>$prevalence,'cohort_median'=>$median,'business_value'=>$business,'deviation'=>$deviation,'meaningful'=>$meaningful,'confidence'=>$confidence,'evidence'=>$evidence];
 }
}
