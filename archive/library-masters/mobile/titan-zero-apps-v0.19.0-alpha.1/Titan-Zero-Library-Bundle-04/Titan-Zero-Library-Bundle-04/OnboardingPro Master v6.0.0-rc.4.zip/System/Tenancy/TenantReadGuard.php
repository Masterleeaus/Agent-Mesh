<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Tenancy;
final readonly class TenantReadGuard
{
    private const DOMAINS=['journey','enrolment','discovery','evidence','approval','learning','certificate','renewal'];
    public function __construct(private OnboardingScope $scope){}
    public function constraints(string $domain,array $filters=[]):array
    {
        if(!in_array($domain,self::DOMAINS,true)) throw new \InvalidArgumentException('Unknown company-scoped onboarding read domain.');
        return $this->scope->constraints($filters);
    }
    public function assertRecord(array $record):void
    {
        $company=(int)($record['company_id']??0);
        try{$this->scope->assertCompany($company);}catch(\RuntimeException $e){throw new \DomainException('Cross-company onboarding record access denied.',0,$e);}
    }
}
