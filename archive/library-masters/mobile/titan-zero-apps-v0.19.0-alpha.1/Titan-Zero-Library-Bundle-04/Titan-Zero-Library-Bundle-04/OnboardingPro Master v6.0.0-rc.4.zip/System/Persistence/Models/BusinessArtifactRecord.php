<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessArtifactRecord extends Model{protected $table='ext_onboarding_business_artifacts';protected $guarded=[];protected $casts=['company_id'=>'integer','metadata'=>'array','extraction_receipt'=>'array','candidate_fact_ids'=>'array'];}
