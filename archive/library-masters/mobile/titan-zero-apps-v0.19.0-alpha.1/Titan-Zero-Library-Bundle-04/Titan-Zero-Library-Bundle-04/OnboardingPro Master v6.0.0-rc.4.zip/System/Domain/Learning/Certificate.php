<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Learning;

use DateTimeImmutable;

final readonly class Certificate
{
    public function __construct(public string $certificateId, public int $companyId, public int $subjectId, public string $courseKey, public string $courseVersion, public DateTimeImmutable $issuedAt, public ?DateTimeImmutable $expiresAt, public string $contentHash) {}
}
