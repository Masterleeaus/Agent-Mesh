<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Presence;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessPresenceAudit;

final readonly class BusinessPresenceAuditService
{
    public function __construct(
        private BusinessPresenceObservationService $observations,
        private BusinessOpportunityService $opportunities,
    ) {}

    /**
     * Runs only against evidence already collected by onboarding discovery.
     * No network lookup happens here and absent evidence remains unknown.
     *
     * @param array<string,mixed> $signals
     * @return array<string,mixed>
     */
    public function audit(int $company_id,array $signals): array
    {
        if($company_id<=0) throw new \RuntimeException('company_id required.');

        $audit=BusinessPresenceAudit::query()->create([
            'company_id'=>$company_id,
            'status'=>'running',
            'presence_score'=>0,
            'observation_ids'=>[],
            'summary'=>[],
            'methodology'=>[
                'version'=>'presence-v1',
                'type'=>'analytical_score',
                'unknown_is_not_failure'=>true,
                'recommendations_are_not_facts'=>true,
            ],
            'audited_at'=>now(),
        ]);

        $created=[];

        $this->observeBoolean($created,$company_id,$audit->id,$signals,'website','WEBSITE_PRESENT','WEBSITE_NOT_FOUND','website');
        $this->observeBoolean($created,$company_id,$audit->id,$signals,'google_business','GOOGLE_BUSINESS_PRESENT','GOOGLE_BUSINESS_NOT_FOUND','google_business');
        $this->observeSocial($created,$company_id,$audit->id,(array)($signals['social']??[]));
        $this->observeReviews($created,$company_id,$audit->id,(array)($signals['reviews']??[]));
        $this->observeBoolean($created,$company_id,$audit->id,$signals,'online_booking','ONLINE_BOOKING_PRESENT','ONLINE_BOOKING_MISSING','online_booking');
        $this->observeQuote($created,$company_id,$audit->id,(array)($signals['quote_request']??[]));
        $this->observeServiceCoverage($created,$company_id,$audit->id,(array)($signals['service_coverage']??[]));
        $this->observeHours($created,$company_id,$audit->id,(array)($signals['business_hours']??[]));
        $this->observeBrandConsistency($created,$company_id,$audit->id,(array)($signals['brand_consistency']??[]));

        $presence_score=$this->score($created);
        $audit->status='complete';
        $audit->presence_score=$presence_score;
        $audit->observation_ids=array_map(static fn($o)=>$o->id,$created);
        $audit->summary=[
            'observation_count'=>count($created),
            'presence_score'=>$presence_score,
            'score_label'=>'analytical',
            'unknown_signal_count'=>$this->unknownCount($signals),
        ];
        $audit->save();

        $opportunities=$this->opportunities->derive($company_id,$audit->id,$created);

        return [
            'company_id'=>$company_id,
            'audit_id'=>$audit->id,
            'presence_score'=>$presence_score,
            'score_type'=>'analytical',
            'observations'=>array_map(fn($o)=>[
                'id'=>$o->id,
                'code'=>$o->observation_code,
                'status'=>$o->status,
                'confidence'=>$o->confidence,
                'evidence'=>$o->evidence,
                'payload'=>$o->observation_payload,
            ],$created),
            'opportunities'=>array_map(fn($o)=>[
                'id'=>$o->id,
                'key'=>$o->opportunity_key,
                'title'=>$o->title,
                'confidence'=>$o->confidence,
                'observation_ids'=>$o->observation_ids,
                'recommended_action'=>$o->recommended_action,
                'growth_handoff'=>$o->growth_handoff,
            ],$opportunities),
        ];
    }

    /** @param list<object> $created */
    private function observeBoolean(array &$created,int $company_id,int $auditId,array $signals,string $key,string $positive,string $negative,string $label): void
    {
        if(!array_key_exists($key,$signals)||!is_array($signals[$key])) return;
        $signal=$signals[$key];
        if(!array_key_exists('present',$signal)) return;
        $present=(bool)$signal['present'];
        $evidence=(array)($signal['evidence']??[]);
        if($evidence===[]) return;
        $created[]=$this->observations->create(
            $company_id,$auditId,$present?$positive:$negative,$present?'good':'missing',
            (int)($signal['confidence']??80),$evidence,[$label=>$present]
        );
    }

    /** @param list<object> $created */
    private function observeSocial(array &$created,int $company_id,int $auditId,array $social): void
    {
        foreach($social as $channel=>$signal){
            if(!is_array($signal)||!array_key_exists('present',$signal)) continue;
            $evidence=(array)($signal['evidence']??[]);
            if($evidence===[]) continue;
            $present=(bool)$signal['present'];
            $created[]=$this->observations->create(
                $company_id,$auditId,
                $present?'SOCIAL_CHANNEL_PRESENT':'SOCIAL_CHANNEL_MISSING',
                $present?'good':'missing',
                (int)($signal['confidence']??75),
                $evidence,
                ['channel'=>(string)$channel,'present'=>$present]
            );
        }
    }

    /** @param list<object> $created */
    private function observeReviews(array &$created,int $company_id,int $auditId,array $reviews): void
    {
        if(!isset($reviews['evidence'])||!is_array($reviews['evidence'])||$reviews['evidence']===[]) return;
        $count=(int)($reviews['count']??0);
        $rating=isset($reviews['rating'])?(float)$reviews['rating']:null;
        $created[]=$this->observations->create(
            $company_id,$auditId,'REVIEWS_OBSERVED',$count>0?'good':'limited',
            (int)($reviews['confidence']??80),(array)$reviews['evidence'],
            ['count'=>$count,'rating'=>$rating]
        );
    }

    /** @param list<object> $created */
    private function observeQuote(array &$created,int $company_id,int $auditId,array $quote): void
    {
        if(!isset($quote['evidence'])||!is_array($quote['evidence'])||$quote['evidence']===[]) return;
        $visibility=(string)($quote['visibility']??'unknown');
        if($visibility==='unknown') return;
        $code=in_array($visibility,['prominent','easy'],true)?'QUOTE_REQUEST_ACCESSIBLE':'QUOTE_REQUEST_HARD_TO_FIND';
        $created[]=$this->observations->create(
            $company_id,$auditId,$code,$code==='QUOTE_REQUEST_ACCESSIBLE'?'good':'attention',
            (int)($quote['confidence']??75),(array)$quote['evidence'],['visibility'=>$visibility]
        );
    }

    /** @param list<object> $created */
    private function observeServiceCoverage(array &$created,int $company_id,int $auditId,array $coverage): void
    {
        if(!isset($coverage['evidence'])||!is_array($coverage['evidence'])||$coverage['evidence']===[]) return;
        $offered=max(0,(int)($coverage['offered']??0));$represented=max(0,(int)($coverage['represented']??0));
        if($offered<=0) return;
        $complete=$represented>=$offered;
        $created[]=$this->observations->create(
            $company_id,$auditId,$complete?'SERVICE_COVERAGE_COMPLETE':'SERVICE_COVERAGE_INCOMPLETE',
            $complete?'good':'attention',(int)($coverage['confidence']??80),(array)$coverage['evidence'],
            ['represented'=>$represented,'offered'=>$offered,'missing'=>max(0,$offered-$represented)]
        );
    }

    /** @param list<object> $created */
    private function observeHours(array &$created,int $company_id,int $auditId,array $hours): void
    {
        if(!isset($hours['evidence'])||!is_array($hours['evidence'])||$hours['evidence']===[]) return;
        if(!array_key_exists('consistent',$hours)) return;
        $consistent=(bool)$hours['consistent'];
        $created[]=$this->observations->create(
            $company_id,$auditId,$consistent?'BUSINESS_HOURS_CONSISTENT':'BUSINESS_HOURS_INCONSISTENT',
            $consistent?'good':'attention',(int)($hours['confidence']??85),(array)$hours['evidence'],
            ['consistent'=>$consistent,'variants'=>(array)($hours['variants']??[])]
        );
    }

    /** @param list<object> $created */
    private function observeBrandConsistency(array &$created,int $company_id,int $auditId,array $brand): void
    {
        if(!isset($brand['evidence'])||!is_array($brand['evidence'])||$brand['evidence']===[]) return;
        $status=(string)($brand['status']??'unknown');
        if($status==='unknown') return;
        $created[]=$this->observations->create(
            $company_id,$auditId,'BRAND_CONSISTENCY_OBSERVED',$status,
            (int)($brand['confidence']??70),(array)$brand['evidence'],['status'=>$status]
        );
    }

    /** @param list<object> $observations */
    private function score(array $observations): int
    {
        if($observations===[]) return 0;
        $weights=[
            'good'=>100,
            'limited'=>60,
            'attention'=>45,
            'missing'=>20,
        ];
        $total=0;$weight=0;
        foreach($observations as $observation){
            $confidence=max(1,(int)$observation->confidence);
            $value=$weights[(string)$observation->status]??50;
            $total+=$value*$confidence;
            $weight+=$confidence;
        }
        return $weight>0?(int)round($total/$weight):0;
    }

    private function unknownCount(array $signals): int
    {
        $expected=['website','google_business','social','reviews','online_booking','quote_request','service_coverage','business_hours','brand_consistency'];
        $unknown=0;
        foreach($expected as $key) if(!array_key_exists($key,$signals)) $unknown++;
        return $unknown;
    }
}
