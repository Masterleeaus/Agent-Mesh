<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;final class ParticipantGrantRecord extends Model{protected $table='ext_onboarding_participant_grants';protected $guarded=[];protected $casts=['allowed_steps'=>'array','expires_at'=>'immutable_datetime','revoked_at'=>'immutable_datetime'];}
