<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Evidence;
final readonly class EvidenceIntegrityReceipt
{
    public function __construct(
        public string $receiptId, public string $evidenceId, public int $companyId, public string $contentHash,
        public ?string $previousReceiptHash, public string $receiptHash, public \DateTimeImmutable $capturedAt
    ){
        foreach([$contentHash,$receiptHash] as $hash) if(!preg_match('/^[a-f0-9]{64}$/',$hash)) throw new \InvalidArgumentException('Integrity hashes must be SHA-256 hex digests.');
        if($previousReceiptHash!==null&&!preg_match('/^[a-f0-9]{64}$/',$previousReceiptHash)) throw new \InvalidArgumentException('Previous receipt hash is invalid.');
    }
}
