<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Privacy;
use App\Extensions\OnboardingPro\System\Persistence\Models\DiscoveryConsentReceipt;
final class DiscoveryConsentService{
 public const SCOPES=['public_internet','selected_files','camera_vision','connected_systems'];
 public function grant(int $company_id,int $userId,string $scope,string $purpose,array $scopeDetails=[],?\DateTimeInterface $expires_at=null):DiscoveryConsentReceipt{
  if($company_id<=0||$userId<=0||!in_array($scope,self::SCOPES,true)||trim($purpose)==='')throw new \InvalidArgumentException('Valid company, user, discovery scope and purpose required.');
  return DiscoveryConsentReceipt::query()->create(['company_id'=>$company_id,'user_id'=>$userId,'scope'=>$scope,'purpose'=>$purpose,'scope_details'=>$scopeDetails,'granted_at'=>now(),'expires_at'=>$expires_at,'revoked_at'=>null]);
 }
 public function revoke(DiscoveryConsentReceipt $receipt,int $company_id):void{if((int)$receipt->company_id!==$company_id)throw new \RuntimeException('Cross-company consent revocation denied.');$receipt->revoked_at=now();$receipt->save();}
 public function requireActive(int $company_id,string $scope,string $purpose):DiscoveryConsentReceipt{
  $q=DiscoveryConsentReceipt::query()->where('company_id',$company_id)->where('scope',$scope)->where('purpose',$purpose)->whereNull('revoked_at')->where(function($q){$q->whereNull('expires_at')->orWhere('expires_at','>',now());})->latest('id')->first();
  if(!$q)throw new \RuntimeException('Active purpose-bound discovery consent required.');return $q;
 }
}
