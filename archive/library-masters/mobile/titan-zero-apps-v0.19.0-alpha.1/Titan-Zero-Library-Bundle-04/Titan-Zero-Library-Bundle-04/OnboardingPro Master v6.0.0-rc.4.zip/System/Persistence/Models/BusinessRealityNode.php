<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessRealityNode extends Model {
 protected $table='ext_onboarding_reality_nodes';protected $guarded=[];
 protected $casts=['company_id'=>'integer','attributes'=>'array','active'=>'boolean','first_observed_at'=>'immutable_datetime','last_observed_at'=>'immutable_datetime'];
}
