<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Participants;
final readonly class ParticipantAssignment
{
 public function __construct(public int $companyId,public string $enrolmentId,public string $stepKey,public string $actorRole,public string $assignedActorId,public array $participantMap=[]){if($companyId<=0)throw new \InvalidArgumentException('Company ID required.');}
}
