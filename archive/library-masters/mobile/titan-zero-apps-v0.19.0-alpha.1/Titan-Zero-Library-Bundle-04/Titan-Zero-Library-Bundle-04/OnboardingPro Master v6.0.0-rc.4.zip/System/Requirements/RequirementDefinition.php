<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Requirements;
final readonly class RequirementDefinition
{
    public function __construct(public string $key,public array $prerequisites=[],public array $supersedes=[],public ?int $validityDays=null)
    {if($key==='')throw new \InvalidArgumentException('Requirement key required.');}
}
