<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Activation;
final readonly class ActivationDecision
{
    public function __construct(public string $state,public array $reasonCodes,public array $provenance){}
}
