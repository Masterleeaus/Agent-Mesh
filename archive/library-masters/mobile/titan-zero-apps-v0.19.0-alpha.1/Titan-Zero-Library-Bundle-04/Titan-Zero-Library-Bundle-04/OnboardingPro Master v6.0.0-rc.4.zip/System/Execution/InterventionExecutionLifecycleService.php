<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Execution;
use App\Extensions\OnboardingPro\System\Persistence\Models\ProviderActionRequest;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionExecution;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionOutcome;
final readonly class InterventionExecutionLifecycleService {
 public const PLANNED='PLANNED',RUNNING='RUNNING',MEASURING='MEASURING',SUCCEEDED='SUCCEEDED',FAILED='FAILED',ROLLED_BACK='ROLLED_BACK';
 public function __construct(private OutcomeMeasurementService $measurement,private RollbackDecisionService $rollback){}
 public function start(int $company_id,int $actionId,array $baseline,array $measurementContract,array $rollbackPlan=[]):InterventionExecution {
  $a=ProviderActionRequest::query()->where('company_id',$company_id)->whereKey($actionId)->firstOrFail();
  if($a->status==='blocked')throw new \RuntimeException('Blocked provider action cannot execute.');
  $legacy=(bool)config('onboarding-pro.provider_actions.legacy_self_asserted_authority_enabled',false);
  if($a->status!=='governed'&&!($legacy&&$a->status==='prepared')){
   throw new \RuntimeException('Provider action requires a platform governance decision before execution lifecycle may start.');
  }
  return InterventionExecution::query()->create(['company_id'=>$company_id,'provider_action_request_id'=>$a->id,'status'=>self::RUNNING,'baseline'=>$baseline,'measurement_contract'=>$measurementContract,'rollback_plan'=>$rollbackPlan,'started_at'=>now()]);
 }
 public function measure(int $company_id,int $executionId,array $observed,array $unintended=[]):InterventionOutcome {
  $e=InterventionExecution::query()->where('company_id',$company_id)->whereKey($executionId)->firstOrFail();$e->status=self::MEASURING;$e->save();
  $m=$this->measurement->measure((array)$e->baseline,$observed,(array)$e->measurement_contract);
  $reversibility=(string)($e->rollback_plan['reversibility']??'unknown');$rd=$this->rollback->decide($m['delta'],$unintended,$reversibility);
  $positive=count(array_filter($m['delta'],fn($v)=>(float)$v>0));$negative=count(array_filter($m['delta'],fn($v)=>(float)$v<0));
  $status=$rd['rollback']?self::ROLLED_BACK:($positive>$negative?self::SUCCEEDED:self::FAILED);
  $out=InterventionOutcome::query()->create(['company_id'=>$company_id,'intervention_execution_id'=>$e->id,'status'=>$status,'baseline'=>$m['baseline'],'observed'=>$m['observed'],'delta'=>$m['delta'],'confidence'=>$m['confidence'],'unintended_effects'=>$unintended,'rollback_decision'=>$rd,'knowledge'=>['lesson'=>$status===self::SUCCEEDED?'Evidence supports intervention benefit.':'Intervention should not be assumed beneficial.','retain_for_future_reasoning'=>true]]);
  $e->status=$status;$e->completed_at=now();$e->save();return $out;
 }
}
