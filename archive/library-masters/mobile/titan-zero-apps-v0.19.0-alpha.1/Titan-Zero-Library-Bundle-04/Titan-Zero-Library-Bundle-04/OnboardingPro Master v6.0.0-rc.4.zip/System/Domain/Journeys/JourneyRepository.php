<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Journeys;

use App\Extensions\OnboardingPro\System\Tenancy\OnboardingScope;

final readonly class JourneyRepository
{
    public function __construct(private OnboardingScope $scope) {}

    /** @param array<string,mixed> $filters @return array<string,mixed> */
    public function constraints(array $filters = []): array
    {
        return $this->scope->constraints($filters);
    }
}
