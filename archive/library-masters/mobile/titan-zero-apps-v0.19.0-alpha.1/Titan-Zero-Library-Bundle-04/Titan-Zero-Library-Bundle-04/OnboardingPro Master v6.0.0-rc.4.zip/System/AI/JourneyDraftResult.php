<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\AI;
final readonly class JourneyDraftResult{public function __construct(public string $status,public array $definition,public bool $publishable,public array $reasonCodes,public string $traceId){}}
