<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Connections;

use App\Extensions\OnboardingPro\System\Persistence\Models\ExistingSystemConnection;
use App\Extensions\OnboardingPro\System\Persistence\Models\ExistingSystemMapping;

final class ExistingSystemMappingService
{
    public function map(int $company_id,ExistingSystemConnection $connection,array $sourceRecord,array $targetHints=[]):ExistingSystemMapping
    {
        if($company_id<=0||(int)$connection->company_id!==$company_id) throw new \RuntimeException('Cross-company mapping denied.');
        $proposed=$this->propose($sourceRecord,$targetHints);
        $comparison=$this->compare($sourceRecord,$proposed,$targetHints);

        return ExistingSystemMapping::query()->create([
            'company_id'=>$company_id,
            'connection_id'=>$connection->id,
            'source_type'=>$connection->system_type,
            'source_record'=>$sourceRecord,
            'proposed_mapping'=>$proposed,
            'comparison'=>$comparison,
            'status'=>'proposed',
            'confirmed'=>false,
        ]);
    }

    public function compare(array $sourceRecord,array $proposedMapping,array $targetHints=[]):array
    {
        $duplicate=false;$conflict=false;$reasons=[];
        $sourceExternal=(string)($sourceRecord['external_id']??'');
        if($sourceExternal!==''&&$sourceExternal===(string)($targetHints['external_id']??'')){
            $duplicate=true;$reasons[]='EXTERNAL_ID_MATCH';
        }
        foreach(['email','phone','name'] as $field){
            $a=strtolower(trim((string)($sourceRecord[$field]??'')));
            $b=strtolower(trim((string)($targetHints[$field]??'')));
            if($a!==''&&$b!==''&&$a!==$b){$conflict=true;$reasons[]='FIELD_CONFLICT_'.strtoupper($field);}
        }
        return ['duplicate'=>$duplicate,'conflict'=>$conflict,'reason_codes'=>$reasons,'destructive_action'=>false];
    }

    public function confirm(ExistingSystemMapping $mapping,int $company_id,int $userId):ExistingSystemMapping
    {
        if((int)$mapping->company_id!==$company_id||$userId<=0) throw new \RuntimeException('Company-matched authenticated confirmation required.');
        if((bool)$mapping->confirmed) return $mapping;
        $mapping->confirmed=true;
        $mapping->confirmed_by_user_id=$userId;
        $mapping->confirmed_at=now();
        $mapping->status='confirmed_for_future_migration';
        $mapping->save();
        return $mapping->refresh();
    }

    private function propose(array $sourceRecord,array $targetHints):array
    {
        $map=[];
        foreach(['external_id','name','email','phone','address','service','role','status'] as $field){
            if(array_key_exists($field,$sourceRecord)) $map[$field]=$sourceRecord[$field];
        }
        return ['canonical_fields'=>$map,'target_domain'=>(string)($targetHints['target_domain']??'unresolved'),'mutation_allowed'=>false];
    }
}
