<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Tracing;

final readonly class OnboardingDecisionReceipt
{
    private function __construct(public string $eventType, public OnboardingTraceContext $trace, public array $payload) {}

    public static function create(string $eventType, OnboardingTraceContext $trace, array $payload): self
    {
        if (trim($eventType) === '') throw new \InvalidArgumentException('Event type is required.');
        unset($payload['chain_of_thought'], $payload['reasoning'], $payload['hidden_reasoning']);
        return new self($eventType, $trace, $payload);
    }

    public function toArray(): array
    {
        return array_merge(['event_type'=>$this->eventType], $this->trace->toArray(), $this->payload);
    }
}
