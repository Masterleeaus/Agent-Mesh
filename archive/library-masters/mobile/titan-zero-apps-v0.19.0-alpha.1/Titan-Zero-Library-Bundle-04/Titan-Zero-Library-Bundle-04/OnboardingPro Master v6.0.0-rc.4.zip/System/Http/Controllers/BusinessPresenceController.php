<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Controllers;

use App\Extensions\OnboardingPro\System\Presence\BusinessPresenceAuditService;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessPresenceAudit;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class BusinessPresenceController extends Controller
{
    public function __construct(private readonly BusinessPresenceAuditService $audits) {}

    public function audit(Request $request)
    {
        $request->validate([
            'signals'=>['required','array'],
            'signals.website'=>['nullable','array'],
            'signals.google_business'=>['nullable','array'],
            'signals.social'=>['nullable','array'],
            'signals.reviews'=>['nullable','array'],
            'signals.online_booking'=>['nullable','array'],
            'signals.quote_request'=>['nullable','array'],
            'signals.service_coverage'=>['nullable','array'],
            'signals.business_hours'=>['nullable','array'],
            'signals.brand_consistency'=>['nullable','array'],
        ]);
        $companyId=$this->companyId($request);

        return response()->json($this->audits->audit(
            $companyId,
            (array)$request->input('signals',[]),
        ));
    }

    public function opportunities(Request $request)
    {
        $companyId=$this->companyId($request);
        $audit=BusinessPresenceAudit::query()
            ->where('company_id',$companyId)
            ->where('status','complete')
            ->latest('id')
            ->first();

        if(!$audit){
            return response()->json([
                'company_id'=>$companyId,
                'audit_id'=>null,
                'observations'=>[],
                'opportunities'=>[],
                'message'=>'No completed business-presence audit exists yet.',
            ]);
        }

        $items=BusinessOpportunity::query()
            ->where('company_id',$companyId)
            ->where('audit_id',$audit->id)
            ->where('dismissed',false)
            ->orderByDesc('confidence')
            ->orderBy('id')
            ->get();

        return response()->json([
            'company_id'=>$companyId,
            'audit_id'=>$audit->id,
            'presence_score'=>$audit->presence_score,
            'score_type'=>'analytical',
            'opportunities'=>$items->map(static fn($item)=>[
                'id'=>$item->id,
                'key'=>$item->opportunity_key,
                'title'=>$item->title,
                'status'=>$item->status,
                'confidence'=>$item->confidence,
                'observation_ids'=>$item->observation_ids,
                'recommended_action'=>$item->recommended_action,
                'growth_handoff'=>$item->growth_handoff,
            ])->values(),
        ]);
    }

    private function companyId(Request $request): int
    {
        $context=$request->attributes->get('titan_onboarding_context');
        if(!$context instanceof OnboardingCompanyContext) abort(403,'Titan Onboarding company context is unavailable.');
        return $context->companyId;
    }
}
