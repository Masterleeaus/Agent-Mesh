<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\RealityGraph;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessRealityFact;
use Illuminate\Support\Facades\DB;

final class BusinessRealityFactService
{
 public const OBSERVED='OBSERVED';
 public const INFERRED='INFERRED';
 public const OWNER_CONFIRMED='OWNER_CONFIRMED';
 public const SYSTEM_CONFIRMED='SYSTEM_CONFIRMED';
 public const CONFLICTED='CONFLICTED';
 public const STALE='STALE';
 public const SUPERSEDED='SUPERSEDED';

 public function record(int $company_id,int $nodeId,string $key,mixed $value,string $state,array $source,array $evidence,int $confidence,bool $canonical=false,bool $ownerConfirmed=false):BusinessRealityFact
 {
  if($company_id<=0||$nodeId<=0)throw new \RuntimeException('company_id and node required.');
  if(!in_array($state,$this->states(),true))throw new \InvalidArgumentException('Invalid reality fact lifecycle state.');
  if($evidence===[]&&in_array($state,[self::OBSERVED,self::SYSTEM_CONFIRMED],true))throw new \RuntimeException('Observed/system-confirmed facts require evidence.');
  return BusinessRealityFact::query()->create([
   'company_id'=>$company_id,'node_id'=>$nodeId,'fact_key'=>$key,'fact_value'=>json_encode($value,JSON_THROW_ON_ERROR),
   'state'=>$state,'source'=>$source['type']??'unknown','source_ref'=>$source['ref']??null,'evidence'=>$evidence,
   'confidence'=>max(0,min(100,$confidence)),'canonical'=>$canonical,'owner_confirmed'=>$ownerConfirmed,
   'observed_at'=>now(),'verified_at'=>in_array($state,[self::OWNER_CONFIRMED,self::SYSTEM_CONFIRMED],true)?now():null,
  ]);
 }

 public function confirmByOwner(BusinessRealityFact $fact):BusinessRealityFact
 {
  $fact->state=self::OWNER_CONFIRMED;$fact->owner_confirmed=true;$fact->canonical=true;$fact->verified_at=now();$fact->save();return $fact;
 }

 public function supersede(BusinessRealityFact $old,BusinessRealityFact $replacement):void
 {
  if((int)$old->company_id!==(int)$replacement->company_id)throw new \RuntimeException('Cross-company supersession denied.');
  DB::transaction(function()use($old,$replacement){
   $old->state=self::SUPERSEDED;$old->canonical=false;$old->superseded_by_fact_id=$replacement->id;$old->superseded_at=now();$old->save();
  });
 }

 public function markStale(BusinessRealityFact $fact):void
 {
  if($fact->state===self::SUPERSEDED)return;
  $fact->state=self::STALE;$fact->canonical=false;$fact->save();
 }

 public function markConflict(BusinessRealityFact $fact,array $evidence=[]):void
 {
  $fact->state=self::CONFLICTED;$fact->canonical=false;
  if($evidence!==[])$fact->evidence=array_merge((array)$fact->evidence,$evidence);
  $fact->save();
 }

 public function states():array{return [self::OBSERVED,self::INFERRED,self::OWNER_CONFIRMED,self::SYSTEM_CONFIRMED,self::CONFLICTED,self::STALE,self::SUPERSEDED];}
}
