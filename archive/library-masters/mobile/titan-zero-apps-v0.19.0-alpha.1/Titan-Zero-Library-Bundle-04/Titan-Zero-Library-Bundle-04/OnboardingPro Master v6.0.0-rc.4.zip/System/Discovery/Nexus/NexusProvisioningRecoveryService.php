<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Persistence\Models\NexusProvisioningTransaction;

final class NexusProvisioningRecoveryService
{
    /** @return array<string,mixed> */
    public function classify(NexusProvisioningTransaction $transaction,\Throwable|string $failure): array
    {
        $message=strtolower(is_string($failure)?$failure:$failure->getMessage());
        $reason='unknown_failure'; $retryable=false; $manual_attention=false;

        if(str_contains($message,'credential')||str_contains($message,'unauthorized')||str_contains($message,'401')){
            $reason='expired_credentials'; $manual_attention=true;
        } elseif(str_contains($message,'timeout')||str_contains($message,'temporar')||str_contains($message,'503')||str_contains($message,'outage')){
            $reason='provider_outage'; $retryable=true;
        } elseif(str_contains($message,'rate limit')||str_contains($message,'429')){
            $reason='provider_rate_limit'; $retryable=true;
        } elseif(str_contains($message,'validation')||str_contains($message,'permission')){
            $reason='policy_or_validation_failure'; $manual_attention=true;
        }

        $mode=$retryable?'forward_recovery':($manual_attention?'manual_attention':'reconcile_first');
        $context=['reason'=>$reason,'retryable'=>$retryable,'manual_attention'=>$manual_attention,'mode'=>$mode];
        $transaction->recovery_context=$context;
        $transaction->recovery_mode=$mode;
        $transaction->status=$manual_attention?'needs_attention':'recoverable';
        $transaction->save();
        return $context;
    }
}
