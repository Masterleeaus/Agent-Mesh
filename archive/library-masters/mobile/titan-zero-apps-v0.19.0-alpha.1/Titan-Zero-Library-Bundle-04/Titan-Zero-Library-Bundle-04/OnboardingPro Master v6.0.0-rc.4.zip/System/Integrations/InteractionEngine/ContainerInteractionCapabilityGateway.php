<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\InteractionEngine;
use App\Extensions\OnboardingPro\System\Contracts\InteractionCapabilityGatewayInterface;
final class ContainerInteractionCapabilityGateway implements InteractionCapabilityGatewayInterface
{
    public function __construct(private readonly object $router){}
    public function status(string $capabilityId,array $context):array
    {
        if(!method_exists($this->router,'status')) throw new \RuntimeException('Interaction capability router does not expose status().');
        $ctx=$this->interactionContext($context);
        return (array)$this->router->status($capabilityId,$ctx);
    }
    public function execute(string $capabilityId,array $payload,array $context):array
    {
        if(!method_exists($this->router,'execute')) throw new \RuntimeException('Interaction capability router does not expose execute().');
        $ctx=$this->interactionContext($context);
        $result=$this->router->execute($capabilityId,$payload,$ctx);
        if(is_object($result)&&method_exists($result,'toArray')) return (array)$result->toArray();
        if(is_array($result)) return $result;
        throw new \RuntimeException('Interaction capability router returned an unsupported result.');
    }
    private function interactionContext(array $context): array
    {
        return array_merge($context, [
            'source_surface'=>'zero',
            'journey'=>'onboarding',
        ]);
    }
}
