<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Steps;

enum StepType: string
{
    case Information = 'information';
    case Form = 'form';
    case Checklist = 'checklist';
    case GuidedTour = 'guided_tour';
    case Announcement = 'announcement';
    case Document = 'document';
    case Video = 'video';
    case Survey = 'survey';
    case Quiz = 'quiz';
    case Signature = 'signature';
    case Evidence = 'evidence';
    case Approval = 'approval';
    case PaymentConfirmation = 'payment_confirmation';
    case Booking = 'booking';
    case Integration = 'integration';
    case PracticalSignoff = 'practical_signoff';
    case Certificate = 'certificate';
    case Completion = 'completion';
}
