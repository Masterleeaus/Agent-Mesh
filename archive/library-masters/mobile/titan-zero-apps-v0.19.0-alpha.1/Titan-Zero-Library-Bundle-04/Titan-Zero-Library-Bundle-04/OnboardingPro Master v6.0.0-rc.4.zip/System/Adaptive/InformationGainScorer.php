<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Adaptive;

final class InformationGainScorer
{
    /** @return array<string,mixed> */
    public function score(array $question,array $knownFacts): array
    {
        $base=max(0,(int)($question['information_gain']??0));
        $resolves=array_values((array)($question['resolves']??[]));
        $unknownResolved=0;
        foreach ($resolves as $factKey) {
            $value=$knownFacts[(string)$factKey]??null;
            if ($value===null || $value==='' || (is_array($value)&&$value===[])) $unknownResolved++;
        }

        $dependencyPenalty=(bool)($question['dependencies_met']??true) ? 0 : 1000;
        $blockingBonus=(bool)($question['blocking']??false) ? 25 : 0;
        $multiFactBonus=max(0,$unknownResolved-1)*12;
        $optionalPenalty=(bool)($question['optional']??false) ? 5 : 0;

        return [
            'question_key'=>$question['key'],
            'information_gain'=>$base,
            'unknown_facts_resolved'=>$unknownResolved,
            'score'=>$base+$blockingBonus+$multiFactBonus-$optionalPenalty-$dependencyPenalty,
        ];
    }
}
