<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Integrations\VerticalEngine;

use App\Extensions\OnboardingPro\System\Contracts\VerticalCandidateGatewayInterface;
use App\Extensions\OnboardingPro\System\Discovery\VerticalCandidateRequest;
use App\Extensions\OnboardingPro\System\Discovery\VerticalResolution;
use Throwable;

final readonly class ConfiguredVerticalCandidateGateway implements VerticalCandidateGatewayInterface
{
    public function __construct(
        private mixed $container,
        private ?string $publicContract,
        private string $resolveMethod = 'resolveCandidatesForOnboarding',
    ) {
    }

    public function resolve(VerticalCandidateRequest $request): VerticalResolution
    {
        $contract = trim((string) $this->publicContract);
        if ($contract === '') {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_NOT_CONFIGURED']);
        }
        if (!method_exists($this->container, 'bound') || !$this->container->bound($contract)) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_NOT_BOUND']);
        }

        try {
            $service = $this->container->make($contract);
        } catch (Throwable) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_RESOLUTION_FAILED']);
        }

        $method = trim($this->resolveMethod);
        if (!is_object($service) || $method === '' || !is_callable([$service, $method])) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_METHOD_UNAVAILABLE']);
        }

        try {
            $raw = $service->{$method}($request->toArray());
        } catch (Throwable) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_CALL_FAILED']);
        }
        if (!is_array($raw)) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_RESPONSE_INVALID']);
        }

        try {
            return VerticalResolution::fromEngineResponse($raw, $request);
        } catch (Throwable) {
            return VerticalResolution::unavailable($request, ['VERTICAL_ENGINE_RESPONSE_REJECTED']);
        }
    }
}
