<?php

declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class JourneyRecord extends Model { protected $table='ext_onboarding_journeys'; protected $guarded=[]; protected $casts=['company_id'=>'integer']; }
