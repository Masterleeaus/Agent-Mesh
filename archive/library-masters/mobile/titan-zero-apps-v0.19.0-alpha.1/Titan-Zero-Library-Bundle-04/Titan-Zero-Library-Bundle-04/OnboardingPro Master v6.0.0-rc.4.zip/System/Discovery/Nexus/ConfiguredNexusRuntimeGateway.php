<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use Illuminate\Contracts\Container\Container;

final readonly class ConfiguredNexusRuntimeGateway implements NexusRuntimeGatewayInterface
{
    public function __construct(
        private Container $container,
        private ?string $publicContract,
        private array $methods,
    ) {}

    public function newDraft(array $canonicalIntent): array
    {
        return $this->invoke('new_draft_method', [$canonicalIntent]);
    }

    public function validateDraft(array $draftReceipt): array
    {
        return $this->invoke('validate_draft_method', [$draftReceipt]);
    }

    public function previewDraft(array $draftReceipt): array
    {
        return $this->invoke('preview_draft_method', [$draftReceipt]);
    }

    public function compileDraft(array $draftReceipt): array
    {
        return $this->invoke('compile_draft_method', [$draftReceipt]);
    }

    public function planProvisioning(array $compiledReceipt): array
    {
        return $this->invoke('plan_provisioning_method', [$compiledReceipt]);
    }

    public function executeProvisioning(array $planReceipt, string $idempotencyKey): array
    {
        return $this->invoke('execute_provisioning_method', [$planReceipt, $idempotencyKey]);
    }

    public function verifyProvisioning(array $executionReceipt): array
    {
        return $this->invoke('verify_provisioning_method', [$executionReceipt]);
    }

    private function invoke(string $methodKey, array $arguments): array
    {
        $contract = trim((string) $this->publicContract);
        $method = trim((string) ($this->methods[$methodKey] ?? ''));
        if ($contract === '' || $method === '' || !$this->container->bound($contract)) {
            throw new \RuntimeException('NEXUS_UNAVAILABLE: configured Nexus public contract is not bound.');
        }
        $service = $this->container->make($contract);
        if (!is_object($service) || !method_exists($service, $method)) {
            throw new \RuntimeException('NEXUS_UNAVAILABLE: configured Nexus draft method is unavailable.');
        }
        $result = $service->{$method}(...$arguments);
        if (is_object($result) && method_exists($result, 'toArray')) {
            $result = $result->toArray();
        }
        if (!is_array($result)) {
            throw new \RuntimeException('NEXUS_UNAVAILABLE: Nexus draft method returned an unsupported receipt.');
        }
        return $result;
    }
}
