<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use InvalidArgumentException;

final readonly class EvidenceValidationService
{
    public function __construct(
        private array $allowedMimeTypes = ['image/jpeg', 'image/png', 'application/pdf'],
        private int $maxBytes = 10485760,
    ) {}

    public function validate(string $filename, string $mimeType, int $bytes): void
    {
        if ($filename === '' || $bytes <= 0 || $bytes > $this->maxBytes) {
            throw new InvalidArgumentException('Evidence file size or filename is invalid.');
        }
        if (!in_array(strtolower($mimeType), array_map('strtolower', $this->allowedMimeTypes), true)) {
            throw new InvalidArgumentException('Evidence MIME type is not permitted.');
        }
    }
}
