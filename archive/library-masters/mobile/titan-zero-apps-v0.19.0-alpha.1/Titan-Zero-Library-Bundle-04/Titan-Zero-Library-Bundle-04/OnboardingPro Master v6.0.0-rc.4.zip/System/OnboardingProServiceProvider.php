<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System;

use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCompiler;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCoordinator;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryJourneyFactory;
use App\Extensions\OnboardingPro\System\Discovery\BusinessSetupService;
use App\Extensions\OnboardingPro\System\Discovery\ProgressiveReadinessEvaluator;
use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileRepository;
use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileService;
use App\Extensions\OnboardingPro\System\Discovery\CanonicalVerticalResolver;
use App\Extensions\OnboardingPro\System\Discovery\BootstrapIntentRepository;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusRuntimeGatewayInterface;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\ConfiguredNexusRuntimeGateway;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusDraftBridge;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusIntentFactory;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusConfigurationReviewService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusCostSovereigntyPolicy;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusConfigurationIntelligenceService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusApprovalService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningPlanService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningExecutionService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningTransactionService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningRecoveryService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningReconciliationService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningVerificationService;
use App\Extensions\OnboardingPro\System\Readiness\OnboardingReadinessService;
use App\Extensions\OnboardingPro\System\Readiness\OnboardingProductionGateService;
use App\Extensions\OnboardingPro\System\UI\OnboardingUiContractService;
use App\Extensions\OnboardingPro\System\RealityGraph\BusinessRealityGraphService;
use App\Extensions\OnboardingPro\System\RealityGraph\BusinessRealityFactService;
use App\Extensions\OnboardingPro\System\Observation\ObservationFreshnessPolicy;
use App\Extensions\OnboardingPro\System\Observation\ObservationChangeDetector;
use App\Extensions\OnboardingPro\System\Observation\ContinuousBusinessObservationService;
use App\Extensions\OnboardingPro\System\Competition\CompetitorDiscoveryService;
use App\Extensions\OnboardingPro\System\Competition\CompetitorIdentityResolutionService;
use App\Extensions\OnboardingPro\System\Competition\MarketPatternService;
use App\Extensions\OnboardingPro\System\Competition\CompetitiveBenchmarkingService;
use App\Extensions\OnboardingPro\System\Opportunity\OpportunityEvidenceService;
use App\Extensions\OnboardingPro\System\Opportunity\OpportunityIntelligenceService;
use App\Extensions\OnboardingPro\System\Diagnostics\ConstraintDiagnosisService;
use App\Extensions\OnboardingPro\System\Diagnostics\WholeBusinessDiagnosticService;
use App\Extensions\OnboardingPro\System\Prioritisation\BusinessImpactScoringService;
use App\Extensions\OnboardingPro\System\Prioritisation\InterventionPrioritisationService;
use App\Extensions\OnboardingPro\System\Workforce\WorkforceDomainRouter;
use App\Extensions\OnboardingPro\System\Workforce\NexusWorkforceCommandBridge;
use App\Extensions\OnboardingPro\System\Providers\ProviderCapabilityRegistry;
use App\Extensions\OnboardingPro\System\Providers\ProviderAuthorityGate;
use App\Extensions\OnboardingPro\System\Providers\ProviderActionFabric;
use App\Extensions\OnboardingPro\System\Execution\OutcomeMeasurementService;
use App\Extensions\OnboardingPro\System\Execution\RollbackDecisionService;
use App\Extensions\OnboardingPro\System\Execution\InterventionExecutionLifecycleService;
use App\Extensions\OnboardingPro\System\Learning\LongitudinalStrategyMemoryService;
use App\Extensions\OnboardingPro\System\Learning\AntiRepeatDecisionService;
use App\Extensions\OnboardingPro\System\Learning\ExperimentComparisonService;
use App\Extensions\OnboardingPro\System\Convergence\NexusBoundaryPolicy;
use App\Extensions\OnboardingPro\System\Convergence\NexusExplainabilityService;
use App\Extensions\OnboardingPro\System\Convergence\NexusReassessmentService;
use App\Extensions\OnboardingPro\System\Convergence\NexusLifecycleOrchestrator;
use App\Extensions\OnboardingPro\System\Domain\Rules\PrerequisiteEvaluator;
use App\Extensions\OnboardingPro\System\Domain\Rules\RuleEvaluator;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepTypeRegistry;
use App\Extensions\OnboardingPro\System\Services\DeltaJourneyPlanner;
use App\Extensions\OnboardingPro\System\Services\JourneyProgressService;
use App\Extensions\OnboardingPro\System\Services\ParticipantAssignmentService;
use App\Extensions\OnboardingPro\System\Services\HandoffService;
use App\Extensions\OnboardingPro\System\Contracts\JourneyRuntimeInterface;
use App\Extensions\OnboardingPro\System\Contracts\InteractionCapabilityGatewayInterface;
use App\Extensions\OnboardingPro\System\Contracts\VerticalCandidateGatewayInterface;
use App\Extensions\OnboardingPro\System\Domain\Capabilities\OnboardingCapabilityPolicy;
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\InteractionJourneyAdapter;
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\OnboardingJourneyRuntime;
use App\Extensions\OnboardingPro\System\Integrations\InteractionEngine\ContainerInteractionCapabilityGateway;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyResolver;
use App\Extensions\OnboardingPro\System\Services\AssuranceEvidenceAdapter;
use App\Extensions\OnboardingPro\System\Services\EvidenceValidationService;
use App\Extensions\OnboardingPro\System\Services\RenewalScheduler;
use App\Extensions\OnboardingPro\System\Services\LearningCompletionService;
use App\Extensions\OnboardingPro\System\Services\CertificateService;
use App\Extensions\OnboardingPro\System\Activation\ActivationGate;
use App\Extensions\OnboardingPro\System\Services\EvidenceIntegrityService;
use App\Extensions\OnboardingPro\System\Services\ApprovalChainService;
use App\Extensions\OnboardingPro\System\Offline\OfflineAuthorityPolicy;
use App\Extensions\OnboardingPro\System\Integrations\Registration\RegistrationJourneyTrigger;
use App\Extensions\OnboardingPro\System\Integrations\Payments\PaymentConfirmationGateway;
use App\Extensions\OnboardingPro\System\Services\JourneyDefinitionValidator;
use App\Extensions\OnboardingPro\System\Services\JourneyLibraryService;
use App\Extensions\OnboardingPro\System\Services\JourneyDraftService;
use App\Extensions\OnboardingPro\System\Security\ParticipantGrantService;
use App\Extensions\OnboardingPro\System\Security\ParticipantGrantIssuer;
use App\Extensions\OnboardingPro\System\AI\JourneyDraftService as AIJourneyDraftService;
use App\Extensions\OnboardingPro\System\AI\JourneyDraftValidator;
use App\Extensions\OnboardingPro\System\Automation\TriggerRegistry;
use App\Extensions\OnboardingPro\System\Automation\TriggerEvaluator;
use App\Extensions\OnboardingPro\System\Agents\OnboardingManager;
use App\Extensions\OnboardingPro\System\Agents\SetupAssistant;
use App\Extensions\OnboardingPro\System\Agents\EmployeeInductionAssistant;
use App\Extensions\OnboardingPro\System\Agents\CustomerOnboardingAssistant;
use App\Extensions\OnboardingPro\System\Agents\TrainingAssistant;
use App\Extensions\OnboardingPro\System\Agents\EvidenceAssistant;
use App\Extensions\OnboardingPro\System\Agents\ComplianceAssistant;
use App\Extensions\OnboardingPro\System\Agents\RenewalAssistant;
use App\Extensions\OnboardingPro\System\Notifications\NotificationPreferenceResolver;
use App\Extensions\OnboardingPro\System\Notifications\OnboardingNotificationService;
use App\Extensions\OnboardingPro\System\Templates\VerticalPackRegistry;
use App\Extensions\OnboardingPro\System\Analytics\JourneyMetricsService;
use App\Extensions\OnboardingPro\System\Analytics\BottleneckAnalyzer;
use App\Extensions\OnboardingPro\System\Services\EvidenceStorageService;
use App\Extensions\OnboardingPro\System\Integrations\Platform\PlatformIntegrationRegistry;
use App\Extensions\OnboardingPro\System\Integrations\TitanAI\TitanAIJourneyGateway;
use App\Extensions\OnboardingPro\System\Integrations\VerticalEngine\ConfiguredVerticalCandidateGateway;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessSetupController;
use App\Extensions\OnboardingPro\System\Workforce\OnboardingWorkforceManifest;
use App\Extensions\OnboardingPro\System\Events\OnboardingLifecycleEventRouter;
use App\Extensions\OnboardingPro\System\Reconfiguration\BusinessConfigurationDiffer;
use App\Extensions\OnboardingPro\System\Reconfiguration\BusinessReconfigurationService;
use App\Extensions\OnboardingPro\System\Discovery\PublicWeb\BusinessIdentityResolver;
use App\Extensions\OnboardingPro\System\Discovery\PublicWeb\PublicBusinessDiscoveryService;
use App\Extensions\OnboardingPro\System\Evidence\EvidenceAuthorityService;
use App\Extensions\OnboardingPro\System\Evidence\CanonicalBusinessFactService;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryConsentService;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryExecutionPolicy;
use App\Extensions\OnboardingPro\System\Artifacts\ArtifactExtractionGatewayInterface;
use App\Extensions\OnboardingPro\System\Artifacts\NullArtifactExtractionGateway;
use App\Extensions\OnboardingPro\System\Artifacts\BusinessArtifactIngestionService;
use App\Extensions\OnboardingPro\System\Connections\ExistingSystemDiscoveryGatewayInterface;
use App\Extensions\OnboardingPro\System\Connections\NullExistingSystemDiscoveryGateway;
use App\Extensions\OnboardingPro\System\Connections\ExistingSystemDiscoveryService;
use App\Extensions\OnboardingPro\System\Connections\ExistingSystemMappingService;
use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveQuestionCatalog;
use App\Extensions\OnboardingPro\System\Adaptive\BusinessKnowledgeGapResolver;
use App\Extensions\OnboardingPro\System\Adaptive\InformationGainScorer;
use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveOnboardingEngine;
use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveOnboardingRuntimeService;
use App\Extensions\OnboardingPro\System\Presence\BusinessPresenceObservationService;
use App\Extensions\OnboardingPro\System\Presence\BusinessOpportunityService;
use App\Extensions\OnboardingPro\System\Presence\BusinessPresenceAuditService;
use Illuminate\Support\ServiceProvider;

/**
 * Titan Onboarding (technical extension identity: OnboardingPro).
 *
 * Release candidate: governed business discovery, journey execution, evidence/trust, learning, automation, analytics and clean upgrade lifecycle.
 * OnboardingPro owns durable discovery/journey state and prepares structured
 * bootstrap intents for Vertical Engine, Nexus, Workforce, Interaction and
 * Knowledge Authority without directly mutating authoritative domain state.
 */
final class OnboardingProServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $config = __DIR__ . '/../config/onboarding-pro.php';
        if (is_file($config)) {
            $this->mergeConfigFrom($config, 'onboarding-pro');
        }

        $this->app->singleton(OnboardingCompanyResolver::class, static fn (): OnboardingCompanyResolver => new OnboardingCompanyResolver());
        $this->app->singleton(OnboardingWorkforceManifest::class, static fn (): OnboardingWorkforceManifest => new OnboardingWorkforceManifest());
        $this->app->singleton(OnboardingLifecycleEventRouter::class, static fn (): OnboardingLifecycleEventRouter => new OnboardingLifecycleEventRouter());
        $this->app->singleton(BusinessConfigurationDiffer::class, static fn (): BusinessConfigurationDiffer => new BusinessConfigurationDiffer());
        $this->app->singleton(BusinessIdentityResolver::class, static fn (): BusinessIdentityResolver => new BusinessIdentityResolver());
        $this->app->singleton(PublicBusinessDiscoveryService::class, static fn ($app): PublicBusinessDiscoveryService => new PublicBusinessDiscoveryService($app->make(BusinessIdentityResolver::class), $app->make(DiscoveryConsentService::class)));
        $this->app->singleton(EvidenceAuthorityService::class, static fn (): EvidenceAuthorityService => new EvidenceAuthorityService());
        $this->app->singleton(CanonicalBusinessFactService::class, static fn (): CanonicalBusinessFactService => new CanonicalBusinessFactService());
        $this->app->singleton(DiscoveryConsentService::class, static fn (): DiscoveryConsentService => new DiscoveryConsentService());
        $this->app->singleton(DiscoveryExecutionPolicy::class, static fn (): DiscoveryExecutionPolicy => new DiscoveryExecutionPolicy());
        $this->app->singleton(ArtifactExtractionGatewayInterface::class, static fn (): ArtifactExtractionGatewayInterface => new NullArtifactExtractionGateway());
        $this->app->singleton(BusinessArtifactIngestionService::class, static fn ($app): BusinessArtifactIngestionService => new BusinessArtifactIngestionService($app->make(ArtifactExtractionGatewayInterface::class), $app->make(EvidenceAuthorityService::class), $app->make(DiscoveryConsentService::class), $app->make(DiscoveryExecutionPolicy::class)));
        $this->app->singleton(ExistingSystemDiscoveryGatewayInterface::class, static fn (): ExistingSystemDiscoveryGatewayInterface => new NullExistingSystemDiscoveryGateway());
        $this->app->singleton(ExistingSystemDiscoveryService::class, static fn ($app): ExistingSystemDiscoveryService => new ExistingSystemDiscoveryService(
            $app->make(ExistingSystemDiscoveryGatewayInterface::class),
            $app->make(DiscoveryConsentService::class),
            $app->make(DiscoveryExecutionPolicy::class),
            $app->make(EvidenceAuthorityService::class),
        ));
        $this->app->singleton(ExistingSystemMappingService::class, static fn (): ExistingSystemMappingService => new ExistingSystemMappingService());
        $this->app->singleton(AdaptiveQuestionCatalog::class, static fn (): AdaptiveQuestionCatalog => new AdaptiveQuestionCatalog());
        $this->app->singleton(BusinessKnowledgeGapResolver::class, static fn (): BusinessKnowledgeGapResolver => new BusinessKnowledgeGapResolver());
        $this->app->singleton(InformationGainScorer::class, static fn (): InformationGainScorer => new InformationGainScorer());
        $this->app->singleton(AdaptiveOnboardingEngine::class, static fn ($app): AdaptiveOnboardingEngine => new AdaptiveOnboardingEngine(
            $app->make(AdaptiveQuestionCatalog::class),
            $app->make(BusinessKnowledgeGapResolver::class),
            $app->make(InformationGainScorer::class),
        ));
        $this->app->singleton(AdaptiveOnboardingRuntimeService::class, static fn ($app): AdaptiveOnboardingRuntimeService => new AdaptiveOnboardingRuntimeService(
            $app->make(AdaptiveOnboardingEngine::class),
            $app->make(EvidenceAuthorityService::class),
            $app->make(CanonicalBusinessFactService::class),
            $app->make(DiscoveryProfileRepository::class),
        ));
        $this->app->singleton(BusinessPresenceObservationService::class, static fn (): BusinessPresenceObservationService => new BusinessPresenceObservationService());
        $this->app->singleton(BusinessOpportunityService::class, static fn (): BusinessOpportunityService => new BusinessOpportunityService());
        $this->app->singleton(BusinessPresenceAuditService::class, static fn ($app): BusinessPresenceAuditService => new BusinessPresenceAuditService(
            $app->make(BusinessPresenceObservationService::class),
            $app->make(BusinessOpportunityService::class),
        ));
        $this->app->singleton(BusinessReconfigurationService::class, static fn ($app): BusinessReconfigurationService => new BusinessReconfigurationService($app->make(BusinessConfigurationDiffer::class), $app->make(NexusRuntimeGatewayInterface::class)));
        $this->app->singleton(BusinessDiscoveryCompiler::class, static fn (): BusinessDiscoveryCompiler => new BusinessDiscoveryCompiler());
        $this->app->singleton(BusinessDiscoveryCoordinator::class, static fn ($app): BusinessDiscoveryCoordinator => new BusinessDiscoveryCoordinator(
            $app->make(BusinessDiscoveryCompiler::class),
            $app->make(ProgressiveReadinessEvaluator::class),
        ));
        $this->app->singleton(ProgressiveReadinessEvaluator::class, static fn (): ProgressiveReadinessEvaluator => new ProgressiveReadinessEvaluator());
        $this->app->singleton(DiscoveryProfileRepository::class, static fn (): DiscoveryProfileRepository => new DiscoveryProfileRepository());
        $this->app->singleton(DiscoveryProfileService::class, static fn ($app): DiscoveryProfileService => new DiscoveryProfileService(
            $app->make(DiscoveryProfileRepository::class),
            $app->make(ProgressiveReadinessEvaluator::class),
        ));
        $this->app->singleton(VerticalCandidateGatewayInterface::class, static fn ($app): ConfiguredVerticalCandidateGateway => new ConfiguredVerticalCandidateGateway(
            $app,
            is_string($app['config']->get('onboarding-pro.vertical_engine.public_contract')) ? $app['config']->get('onboarding-pro.vertical_engine.public_contract') : null,
            (string) $app['config']->get('onboarding-pro.vertical_engine.resolve_candidates_method', 'resolveCandidatesForOnboarding'),
        ));
        $this->app->singleton(CanonicalVerticalResolver::class, static fn ($app): CanonicalVerticalResolver => new CanonicalVerticalResolver(
            $app->make(VerticalCandidateGatewayInterface::class),
        ));
        $this->app->singleton(BootstrapIntentRepository::class, static fn (): BootstrapIntentRepository => new BootstrapIntentRepository());
        $this->app->singleton(NexusRuntimeGatewayInterface::class, static fn ($app): ConfiguredNexusRuntimeGateway => new ConfiguredNexusRuntimeGateway(
            $app,
            is_string($app['config']->get('onboarding-pro.nexus.public_contract')) ? $app['config']->get('onboarding-pro.nexus.public_contract') : null,
            [
                'new_draft_method' => (string) $app['config']->get('onboarding-pro.nexus.new_draft_method', 'newDraft'),
                'validate_draft_method' => (string) $app['config']->get('onboarding-pro.nexus.validate_draft_method', 'validateDraft'),
                'preview_draft_method' => (string) $app['config']->get('onboarding-pro.nexus.preview_draft_method', 'previewDraft'),
                'compile_draft_method' => (string) $app['config']->get('onboarding-pro.nexus.compile_draft_method', 'compileDraft'),
                'plan_provisioning_method' => (string) $app['config']->get('onboarding-pro.nexus.plan_provisioning_method', 'planProvisioning'),
                'execute_provisioning_method' => (string) $app['config']->get('onboarding-pro.nexus.execute_provisioning_method', 'executeProvisioning'),
                'verify_provisioning_method' => (string) $app['config']->get('onboarding-pro.nexus.verify_provisioning_method', 'verifyProvisioning'),
            ],
        ));
        $this->app->singleton(NexusDraftBridge::class, static fn ($app): NexusDraftBridge => new NexusDraftBridge(
            $app->make(BootstrapIntentRepository::class),
            $app->make(NexusRuntimeGatewayInterface::class),
        ));
        $this->app->singleton(NexusIntentFactory::class, static fn ($app): NexusIntentFactory => new NexusIntentFactory(
            $app->make(BusinessDiscoveryCompiler::class),
        ));
        $this->app->singleton(NexusCostSovereigntyPolicy::class, static fn (): NexusCostSovereigntyPolicy => new NexusCostSovereigntyPolicy());
        $this->app->singleton(NexusConfigurationIntelligenceService::class, static fn ($app): NexusConfigurationIntelligenceService => new NexusConfigurationIntelligenceService(
            $app->make(NexusCostSovereigntyPolicy::class),
        ));
        $this->app->singleton(NexusConfigurationReviewService::class, static fn ($app): NexusConfigurationReviewService => new NexusConfigurationReviewService(
            $app->make(NexusIntentFactory::class),
            $app->make(NexusDraftBridge::class),
            $app->make(NexusConfigurationIntelligenceService::class),
        ));
        $this->app->singleton(NexusApprovalService::class, static fn (): NexusApprovalService => new NexusApprovalService());
        $this->app->singleton(NexusProvisioningPlanService::class, static fn ($app): NexusProvisioningPlanService => new NexusProvisioningPlanService(
            $app->make(NexusRuntimeGatewayInterface::class),
        ));
        $this->app->singleton(NexusProvisioningTransactionService::class, static fn (): NexusProvisioningTransactionService => new NexusProvisioningTransactionService());
        $this->app->singleton(NexusProvisioningRecoveryService::class, static fn (): NexusProvisioningRecoveryService => new NexusProvisioningRecoveryService());
        $this->app->singleton(NexusProvisioningReconciliationService::class, static fn (): NexusProvisioningReconciliationService => new NexusProvisioningReconciliationService());
        $this->app->singleton(NexusProvisioningExecutionService::class, static fn ($app): NexusProvisioningExecutionService => new NexusProvisioningExecutionService(
            $app->make(NexusRuntimeGatewayInterface::class),
            $app->make(NexusProvisioningTransactionService::class),
            $app->make(NexusProvisioningRecoveryService::class),
        ));
        $this->app->singleton(NexusProvisioningVerificationService::class, static fn ($app): NexusProvisioningVerificationService => new NexusProvisioningVerificationService($app->make(NexusRuntimeGatewayInterface::class)));
        $this->app->singleton(BusinessDiscoveryJourneyFactory::class, static fn (): BusinessDiscoveryJourneyFactory => new BusinessDiscoveryJourneyFactory());
        $this->app->singleton(BusinessSetupService::class, static fn ($app): BusinessSetupService => new BusinessSetupService(
            $app->make(DiscoveryProfileService::class),
            $app->make(BusinessDiscoveryJourneyFactory::class),
            $app->make(ProgressiveReadinessEvaluator::class),
            $app->make(CanonicalVerticalResolver::class),
        ));
        $this->app->singleton(BusinessSetupController::class, static fn ($app): BusinessSetupController => new BusinessSetupController(
            $app->make(BusinessSetupService::class),
            $app->make(NexusConfigurationReviewService::class),
            $app->make(DiscoveryProfileService::class),
            $app->make(NexusApprovalService::class),
            $app->make(NexusProvisioningPlanService::class),
            $app->make(NexusProvisioningExecutionService::class),
            $app->make(NexusProvisioningVerificationService::class),
            $app->make(BusinessReconfigurationService::class),
        ));
        $this->app->singleton(StepTypeRegistry::class, static fn (): StepTypeRegistry => StepTypeRegistry::withTitanDefaults());
        $this->app->singleton(JourneyProgressService::class, static fn (): JourneyProgressService => new JourneyProgressService());
        $this->app->singleton(RuleEvaluator::class, static fn (): RuleEvaluator => new RuleEvaluator());
        $this->app->singleton(PrerequisiteEvaluator::class, static fn (): PrerequisiteEvaluator => new PrerequisiteEvaluator());
        $this->app->singleton(DeltaJourneyPlanner::class, static fn ($app): DeltaJourneyPlanner => new DeltaJourneyPlanner(
            $app->make(RuleEvaluator::class),
            $app->make(PrerequisiteEvaluator::class),
        ));

        $this->app->singleton(InteractionJourneyAdapter::class, static fn (): InteractionJourneyAdapter => new InteractionJourneyAdapter());
        $this->app->alias(InteractionJourneyAdapter::class, JourneyRuntimeInterface::class);
        $this->app->singleton(OnboardingJourneyRuntime::class, static function ($app): OnboardingJourneyRuntime {
            $contract=(string) config('onboarding-pro.interaction_engine.public_contract', '');
            return new OnboardingJourneyRuntime($app->make(JourneyRuntimeInterface::class), $contract!=='' && $app->bound($contract));
        });
        $this->app->singleton(OnboardingCapabilityPolicy::class, static fn (): OnboardingCapabilityPolicy => new OnboardingCapabilityPolicy());
        $this->app->singleton(ParticipantAssignmentService::class, static fn (): ParticipantAssignmentService => new ParticipantAssignmentService());
        $this->app->singleton(HandoffService::class, static fn (): HandoffService => new HandoffService());
        $this->app->singleton(AssuranceEvidenceAdapter::class, static fn (): AssuranceEvidenceAdapter => new AssuranceEvidenceAdapter());
        $this->app->singleton(EvidenceValidationService::class, static fn (): EvidenceValidationService => new EvidenceValidationService());
        $this->app->singleton(RenewalScheduler::class, static fn (): RenewalScheduler => new RenewalScheduler());
        $this->app->singleton(LearningCompletionService::class, static fn (): LearningCompletionService => new LearningCompletionService());
        $this->app->singleton(CertificateService::class, static fn (): CertificateService => new CertificateService());
        $this->app->singleton(ActivationGate::class, static fn (): ActivationGate => new ActivationGate());
        $this->app->singleton(EvidenceIntegrityService::class, static fn (): EvidenceIntegrityService => new EvidenceIntegrityService());
        $this->app->singleton(ApprovalChainService::class, static fn (): ApprovalChainService => new ApprovalChainService());
        $this->app->singleton(OfflineAuthorityPolicy::class, static fn (): OfflineAuthorityPolicy => new OfflineAuthorityPolicy());
        $this->app->singleton(RegistrationJourneyTrigger::class, static fn (): RegistrationJourneyTrigger => new RegistrationJourneyTrigger());
        $this->app->singleton(PaymentConfirmationGateway::class, static fn (): PaymentConfirmationGateway => new PaymentConfirmationGateway());
        $this->app->singleton(JourneyDefinitionValidator::class, static fn (): JourneyDefinitionValidator => new JourneyDefinitionValidator());
        $this->app->singleton(JourneyLibraryService::class, static fn (): JourneyLibraryService => new JourneyLibraryService());
        $this->app->singleton(JourneyDraftService::class, static fn ($app): JourneyDraftService => new JourneyDraftService($app->make(JourneyDefinitionValidator::class)));
        $this->app->singleton(ParticipantGrantService::class, static function (): ParticipantGrantService {
            $key=(string) config('app.key', '');
            if (str_starts_with($key, 'base64:')) { $decoded=base64_decode(substr($key,7), true); if ($decoded!==false) $key=$decoded; }
            if ($key==='') throw new \RuntimeException('Titan Onboarding participant grants require APP_KEY.');
            return new ParticipantGrantService($key);
        });
        $this->app->singleton(JourneyDraftValidator::class, static fn (): JourneyDraftValidator => new JourneyDraftValidator());
        $this->app->singleton(AIJourneyDraftService::class, static fn ($app): AIJourneyDraftService => new AIJourneyDraftService($app->make(JourneyDraftValidator::class)));
        $this->app->singleton(TriggerRegistry::class, static fn (): TriggerRegistry => TriggerRegistry::withDefaults());
        $this->app->singleton(TriggerEvaluator::class, static fn ($app): TriggerEvaluator => new TriggerEvaluator($app->make(TriggerRegistry::class)));
        $this->app->singleton(OnboardingManager::class, static fn (): OnboardingManager => new OnboardingManager());
        $this->app->singleton(SetupAssistant::class, static fn (): SetupAssistant => new SetupAssistant());
        $this->app->singleton(EmployeeInductionAssistant::class, static fn (): EmployeeInductionAssistant => new EmployeeInductionAssistant());
        $this->app->singleton(CustomerOnboardingAssistant::class, static fn (): CustomerOnboardingAssistant => new CustomerOnboardingAssistant());
        $this->app->singleton(TrainingAssistant::class, static fn (): TrainingAssistant => new TrainingAssistant());
        $this->app->singleton(EvidenceAssistant::class, static fn (): EvidenceAssistant => new EvidenceAssistant());
        $this->app->singleton(ComplianceAssistant::class, static fn (): ComplianceAssistant => new ComplianceAssistant());
        $this->app->singleton(RenewalAssistant::class, static fn (): RenewalAssistant => new RenewalAssistant());
        $this->app->singleton(NotificationPreferenceResolver::class, static fn (): NotificationPreferenceResolver => new NotificationPreferenceResolver());
        $this->app->singleton(OnboardingNotificationService::class, static fn ($app): OnboardingNotificationService => new OnboardingNotificationService($app->make(NotificationPreferenceResolver::class)));
        $this->app->singleton(VerticalPackRegistry::class, static fn (): VerticalPackRegistry => VerticalPackRegistry::withTitanDefaults());
        $this->app->singleton(PlatformIntegrationRegistry::class, static fn (): PlatformIntegrationRegistry => PlatformIntegrationRegistry::withTitanDefaults());
        $this->app->singleton(TitanAIJourneyGateway::class, static fn (): TitanAIJourneyGateway => new TitanAIJourneyGateway());
        $this->app->singleton(JourneyMetricsService::class, static fn (): JourneyMetricsService => new JourneyMetricsService());
        $this->app->singleton(BottleneckAnalyzer::class, static fn (): BottleneckAnalyzer => new BottleneckAnalyzer());
        $this->app->singleton(EvidenceStorageService::class, static fn ($app): EvidenceStorageService => new EvidenceStorageService($app->make('filesystem')));
        $this->app->singleton(ParticipantGrantIssuer::class, static fn ($app): ParticipantGrantIssuer => new ParticipantGrantIssuer($app->make(ParticipantGrantService::class)));

        $interactionRouter=(string) config('onboarding-pro.interaction_engine.public_contract', '');
        if ($interactionRouter!=='' && $this->app->bound($interactionRouter)) {
            $this->app->singleton(InteractionCapabilityGatewayInterface::class, static function ($app) use ($interactionRouter): ContainerInteractionCapabilityGateway {
                return new ContainerInteractionCapabilityGateway($app->make($interactionRouter));
            });
        }
        $this->app->singleton(OnboardingReadinessService::class, static fn (): OnboardingReadinessService => new OnboardingReadinessService());
        $this->app->singleton(OnboardingUiContractService::class, static fn (): OnboardingUiContractService => new OnboardingUiContractService());
        $this->app->singleton(OnboardingProductionGateService::class, static fn ($app): OnboardingProductionGateService => new OnboardingProductionGateService(
            $app->make(OnboardingReadinessService::class),
        ));

        $this->app->singleton(BusinessRealityGraphService::class, static fn (): BusinessRealityGraphService => new BusinessRealityGraphService());
        $this->app->singleton(BusinessRealityFactService::class, static fn (): BusinessRealityFactService => new BusinessRealityFactService());

        $this->app->singleton(ObservationFreshnessPolicy::class, static fn (): ObservationFreshnessPolicy => new ObservationFreshnessPolicy());
        $this->app->singleton(ObservationChangeDetector::class, static fn (): ObservationChangeDetector => new ObservationChangeDetector());
        $this->app->singleton(ContinuousBusinessObservationService::class, static fn ($app): ContinuousBusinessObservationService => new ContinuousBusinessObservationService(
            $app->make(ObservationFreshnessPolicy::class),
            $app->make(ObservationChangeDetector::class),
            $app->make(BusinessRealityFactService::class),
        ));

        $this->app->singleton(CompetitorDiscoveryService::class, static fn ($app): CompetitorDiscoveryService => new CompetitorDiscoveryService($app->make(BusinessRealityGraphService::class)));
        $this->app->singleton(CompetitorIdentityResolutionService::class, static fn (): CompetitorIdentityResolutionService => new CompetitorIdentityResolutionService());

        $this->app->singleton(MarketPatternService::class, static fn (): MarketPatternService => new MarketPatternService());
        $this->app->singleton(CompetitiveBenchmarkingService::class, static fn ($app): CompetitiveBenchmarkingService => new CompetitiveBenchmarkingService($app->make(MarketPatternService::class)));

        $this->app->singleton(OpportunityEvidenceService::class, static fn (): OpportunityEvidenceService => new OpportunityEvidenceService());
        $this->app->singleton(OpportunityIntelligenceService::class, static fn ($app): OpportunityIntelligenceService => new OpportunityIntelligenceService($app->make(OpportunityEvidenceService::class)));

        $this->app->singleton(ConstraintDiagnosisService::class, static fn (): ConstraintDiagnosisService => new ConstraintDiagnosisService());
        $this->app->singleton(WholeBusinessDiagnosticService::class, static fn ($app): WholeBusinessDiagnosticService => new WholeBusinessDiagnosticService($app->make(ConstraintDiagnosisService::class)));

        $this->app->singleton(BusinessImpactScoringService::class, static fn (): BusinessImpactScoringService => new BusinessImpactScoringService());
        $this->app->singleton(InterventionPrioritisationService::class, static fn ($app): InterventionPrioritisationService => new InterventionPrioritisationService($app->make(BusinessImpactScoringService::class)));

        $this->app->singleton(WorkforceDomainRouter::class, static fn (): WorkforceDomainRouter => new WorkforceDomainRouter());
        $this->app->singleton(NexusWorkforceCommandBridge::class, static fn ($app): NexusWorkforceCommandBridge => new NexusWorkforceCommandBridge($app->make(WorkforceDomainRouter::class)));

        $this->app->singleton(ProviderCapabilityRegistry::class, static fn (): ProviderCapabilityRegistry => new ProviderCapabilityRegistry());
        $this->app->singleton(ProviderAuthorityGate::class, static fn (): ProviderAuthorityGate => new ProviderAuthorityGate());
        $this->app->singleton(ProviderActionFabric::class, static fn ($app): ProviderActionFabric => new ProviderActionFabric($app->make(ProviderCapabilityRegistry::class), $app->make(ProviderAuthorityGate::class)));

        $this->app->singleton(OutcomeMeasurementService::class, static fn (): OutcomeMeasurementService => new OutcomeMeasurementService());
        $this->app->singleton(RollbackDecisionService::class, static fn (): RollbackDecisionService => new RollbackDecisionService());
        $this->app->singleton(InterventionExecutionLifecycleService::class, static fn ($app): InterventionExecutionLifecycleService => new InterventionExecutionLifecycleService($app->make(OutcomeMeasurementService::class), $app->make(RollbackDecisionService::class)));

        $this->app->singleton(LongitudinalStrategyMemoryService::class, static fn (): LongitudinalStrategyMemoryService => new LongitudinalStrategyMemoryService());
        $this->app->singleton(AntiRepeatDecisionService::class, static fn (): AntiRepeatDecisionService => new AntiRepeatDecisionService());
        $this->app->singleton(ExperimentComparisonService::class, static fn (): ExperimentComparisonService => new ExperimentComparisonService());

        $this->app->singleton(NexusBoundaryPolicy::class, static fn (): NexusBoundaryPolicy => new NexusBoundaryPolicy());
        $this->app->singleton(NexusExplainabilityService::class, static fn (): NexusExplainabilityService => new NexusExplainabilityService());
        $this->app->singleton(NexusReassessmentService::class, static fn (): NexusReassessmentService => new NexusReassessmentService());
        $this->app->singleton(NexusLifecycleOrchestrator::class, static fn ($app): NexusLifecycleOrchestrator => new NexusLifecycleOrchestrator($app->make(NexusBoundaryPolicy::class), $app->make(NexusExplainabilityService::class), $app->make(NexusReassessmentService::class)));

    }

    public function boot(): void
    {
        $this->registerTranslations();
        $this->registerViews();
        $this->registerRoutes();
        $this->registerMigrations();
    }

    private function registerTranslations(): void
    {
        $path = __DIR__ . '/../resources/lang';
        if (is_dir($path)) {
            $this->loadTranslationsFrom($path, 'onboarding-pro');
        }
    }

    private function registerViews(): void
    {
        $path = __DIR__ . '/../resources/views';
        if (is_dir($path)) {
            $this->loadViewsFrom($path, 'onboarding-pro');
        }
    }

    private function registerRoutes(): void
    {
        foreach (['admin.php', 'user.php', 'participant.php', 'api.php'] as $file) {
            $path = __DIR__ . '/../routes/' . $file;
            if (is_file($path)) {
                $this->loadRoutesFrom($path);
            }
        }
    }

    private function registerMigrations(): void
    {
        $path = __DIR__ . '/../database/migrations';
        if (is_dir($path)) {
            $this->loadMigrationsFrom($path);
        }
    }
}
