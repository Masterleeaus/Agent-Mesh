<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Learning\LongitudinalStrategyMemoryService;use App\Extensions\OnboardingPro\System\Learning\AntiRepeatDecisionService;use App\Extensions\OnboardingPro\System\Persistence\Models\StrategyMemory;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class StrategyMemoryController extends Controller{
 public function __construct(private readonly LongitudinalStrategyMemoryService $memory,private readonly AntiRepeatDecisionService $antiRepeat){}
 public function ingest(Request $r){$r->validate(['outcome_id'=>['required','integer'],'context'=>['required','array'],'ttl_days'=>['nullable','integer','min:1']]);return response()->json($this->memory->ingest($this->companyId($r),(int)$r->input('outcome_id'),(array)$r->input('context'),(int)$r->input('ttl_days',180)));}
 public function check(Request $r){$r->validate(['fingerprint'=>['required','string','size:64'],'context'=>['required','array']]);return response()->json($this->antiRepeat->decide($this->companyId($r),(string)$r->input('fingerprint'),(array)$r->input('context')));}
 public function latest(Request $r){return response()->json(StrategyMemory::query()->where('company_id',$this->companyId($r))->latest('observed_at')->limit(100)->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
