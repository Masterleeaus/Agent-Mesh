<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Renewals;

use DateTimeImmutable;

final readonly class RenewalRequirement
{
    public function __construct(
        public string $requirementId, public int $companyId, public string $subjectType,
        public string $subjectId, public string $requirementType, public string $sourceEvidenceId,
        public DateTimeImmutable $expiresAt, public int $leadDays, public string $targetJourneyKey,
    ) {}
}
