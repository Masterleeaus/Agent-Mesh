<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;

use App\Extensions\OnboardingPro\System\Readiness\OnboardingReadinessService;
use App\Extensions\OnboardingPro\System\Readiness\OnboardingProductionGateService;
use App\Extensions\OnboardingPro\System\UI\OnboardingUiContractService;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class OnboardingReadinessController extends Controller
{
 public function __construct(
  private readonly OnboardingReadinessService $readiness,
  private readonly OnboardingUiContractService $ui,
  private readonly OnboardingProductionGateService $production,
 ){}
 public function check(Request $request){return response()->json($this->readiness->check($this->companyId($request)));}
 public function uiContract(Request $request){$this->companyId($request);return response()->json($this->ui->contract());}
 public function productionGate(Request $request){
  $request->validate(['approval'=>['required','array'],'cost_sovereignty'=>['required','array']]);
  return response()->json($this->production->evaluate($this->companyId($request),(array)$request->input('approval'),(array)$request->input('cost_sovereignty')));
 }
 private function companyId(Request $request):int{
  $context=$request->attributes->get('titan_onboarding_context');
  if(!$context instanceof OnboardingCompanyContext)abort(403,'Titan Onboarding company context is unavailable.');
  return $context->companyId;
 }
}
