<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Contracts;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
interface JourneyRuntimeInterface
{
    public function map(string $journeyKey,string $name,string $version,array $steps,JourneyExecutionContext $context): array;
}
