<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

final readonly class BusinessSetupState
{
    /** @param list<string> $deferredDomains @param list<array<string,mixed>> $steps */
    public function __construct(
        public string $mode,
        public int $revision,
        public array $profile,
        public array $deferredDomains,
        public ProgressiveReadinessResult $readiness,
        public array $steps,
        public string $status,
        public ?array $verticalResolution = null,
    ) {
        if (!in_array($mode, ['first_run', 'existing_business'], true)) {
            throw new \InvalidArgumentException('Unsupported business setup mode.');
        }
        if ($revision < 0) {
            throw new \InvalidArgumentException('Business setup revision cannot be negative.');
        }
    }

    public function verticalReady(): bool
    {
        return ($this->verticalResolution['status'] ?? null) === 'RESOLVED'
            && ($this->verticalResolution['stale'] ?? true) === false
            && trim((string) ($this->verticalResolution['vertical_id'] ?? '')) !== ''
            && trim((string) ($this->verticalResolution['vertical_version'] ?? '')) !== '';
    }

    public function toArray(): array
    {
        return [
            'mode' => $this->mode,
            'revision' => $this->revision,
            'profile' => $this->profile,
            'deferred_domains' => $this->deferredDomains,
            'status' => $this->status,
            'minimum_ready' => $this->readiness->minimumReady,
            'operational_ready' => $this->readiness->operationalReady,
            'remaining_domains' => $this->readiness->remainingDomains,
            'readiness_codes' => $this->readiness->reasonCodes,
            'vertical_resolution' => $this->verticalResolution,
            'vertical_ready' => $this->verticalReady(),
            'steps' => $this->steps,
        ];
    }
}
