<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Offline;
final class OnboardingConflictResolver
{
 public function resolve(array $client,array $server,OnboardingMutation $mutation):array{
   $terminal=['completed','approved','rejected','cancelled','expired'];
   if(in_array((string)($server['status']??''),$terminal,true))return ['winner'=>'server','reason'=>'server_terminal_state','mutation_id'=>$mutation->id,'conflicted'=>true,'server_state_hash'=>$server['state_hash']??null,'client_base_hash'=>$mutation->baseHash];
   if(isset($server['state_hash']) && (string)$server['state_hash']!=='' && !hash_equals((string)$server['state_hash'],$mutation->baseHash))return ['winner'=>'server','reason'=>'base_state_mismatch','mutation_id'=>$mutation->id,'conflicted'=>true,'server_state_hash'=>$server['state_hash'],'client_base_hash'=>$mutation->baseHash];
   $ct=strtotime((string)($client['updated_at']??''))?:0;$st=strtotime((string)($server['updated_at']??''))?:0;
   if($ct>$st)return ['winner'=>'client','reason'=>'client_newer','mutation_id'=>$mutation->id,'conflicted'=>false];
   return ['winner'=>'server','reason'=>$st>$ct?'server_newer':'equal_timestamp','mutation_id'=>$mutation->id,'conflicted'=>$st>$ct];
 }
}
