<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Artifacts;
use App\Extensions\OnboardingPro\System\Evidence\EvidenceAuthorityService;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryConsentService;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryExecutionPolicy;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessArtifactRecord;
final readonly class BusinessArtifactIngestionService{
 private const TYPES=['pdf','document','spreadsheet','csv','invoice','quote','price_list','sop','policy','licence','certificate','staff_record','job_export','customer_export','screenshot','photo','camera_capture'];
 public function __construct(private ArtifactExtractionGatewayInterface $gateway,private EvidenceAuthorityService $authority,private DiscoveryConsentService $consents,private DiscoveryExecutionPolicy $executionPolicy){}
 public function ingest(int $company_id,int $userId,array $artifact,string $source='selected_files'):array{
  if($company_id<=0||$userId<=0)throw new \RuntimeException('company_id and user required.');
  if(!in_array($source,['selected_files','camera_vision'],true))throw new \RuntimeException('Artifact source must be selected_files or camera_vision.');
  $this->consents->requireActive($company_id,$source,'business_onboarding');
  $type=(string)($artifact['type']??'');if(!in_array($type,self::TYPES,true))throw new \RuntimeException('Unsupported business artifact type.');
  $execution=$this->executionPolicy->decide($company_id,'artifact_extraction',(array)($artifact['execution_capabilities']??[]));
  $record=BusinessArtifactRecord::query()->create(['company_id'=>$company_id,'user_id'=>$userId,'artifact_type'=>$type,'source_scope'=>$source,'content_fingerprint'=>(string)($artifact['fingerprint']??hash('sha256',json_encode($artifact))),'metadata'=>(array)($artifact['metadata']??[]),'status'=>'extracting']);
  $receipt=$this->gateway->extract($artifact,['company_id'=>$company_id,'execution'=>$execution,'source_scope'=>$source]);
  $ids=[];foreach((array)($receipt['facts']??[]) as $candidate){if(!isset($candidate['key']))continue;$fact=$this->authority->assess($company_id,(string)$candidate['key'],(array)($candidate['value']??[]),['source_type'=>$type,'source_reference'=>'artifact:'.$record->id,'source_authority'=>(int)($candidate['source_authority']??70),'freshness'=>(int)($candidate['freshness']??80),'confidence'=>(int)($candidate['confidence']??60),'independent_sources'=>1,'sensitivity'=>(string)($candidate['sensitivity']??'normal'),'observed_at'=>now()]);$ids[]=$fact->id;}
  $record->status='extracted';$record->extraction_receipt=$receipt;$record->candidate_fact_ids=$ids;$record->save();
  return ['company_id'=>$company_id,'artifact_id'=>$record->id,'candidate_fact_ids'=>$ids,'execution'=>$execution,'status'=>'extracted'];
 }
}
