<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Rules\PrerequisiteEvaluator;
use App\Extensions\OnboardingPro\System\Domain\Rules\RuleEvaluator;

final readonly class DeltaJourneyPlanner
{
    public function __construct(private RuleEvaluator $rules, private PrerequisiteEvaluator $prerequisites) {}

    /** @param list<array<string,mixed>> $steps @param array<string,mixed> $context @return list<string> */
    public function applicableStepKeys(array $steps, array $context): array
    {
        $keys = [];
        foreach ($steps as $step) {
            $conditions = (array) ($step['conditions'] ?? []);
            $applies = true;
            foreach ($conditions as $condition) if (!$this->rules->evaluate(is_array($condition) ? $condition : (string) $condition, $context)) { $applies = false; break; }
            if ($applies) $keys[] = (string) ($step['key'] ?? '');
        }
        return array_values(array_filter($keys, static fn (string $key): bool => $key !== ''));
    }

    /**
     * @param list<array<string,mixed>> $steps
     * @param array<string,mixed> $context
     * @param list<string> $completedStepKeys
     * @param list<string> $existingStepKeys
     * @return list<array{step_key:string,reason:string,unmet_prerequisites:list<string>}>
     */
    public function plan(array $steps, array $context, array $completedStepKeys, array $existingStepKeys): array
    {
        $applicable = array_fill_keys($this->applicableStepKeys($steps, $context), true);
        $existing = array_fill_keys($existingStepKeys, true);
        $result = [];
        foreach ($steps as $step) {
            $key = (string) ($step['key'] ?? '');
            if ($key === '' || !isset($applicable[$key]) || isset($existing[$key])) continue;
            $required = array_values(array_map('strval', (array) ($step['prerequisites'] ?? [])));
            $result[] = [
                'step_key' => $key,
                'reason' => 'newly_applicable',
                'unmet_prerequisites' => $this->prerequisites->unmet($required, $completedStepKeys),
            ];
        }
        return $result;
    }
}
