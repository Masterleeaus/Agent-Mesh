<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessRealityFact extends Model {
 protected $table='ext_onboarding_reality_facts';protected $guarded=[];
 protected $casts=['company_id'=>'integer','node_id'=>'integer','evidence'=>'array','confidence'=>'integer','canonical'=>'boolean','owner_confirmed'=>'boolean','observed_at'=>'immutable_datetime','verified_at'=>'immutable_datetime','superseded_at'=>'immutable_datetime'];
}
