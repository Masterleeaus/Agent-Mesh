<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Evidence;

enum EvidenceClassification: string
{
    case General = 'general';
    case Credential = 'credential';
    case Compliance = 'compliance';
    case Identity = 'identity';
    case Training = 'training';
    case Practical = 'practical';
}
