<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Persistence\Models\NexusProvisioningTransaction;

final class NexusProvisioningReconciliationService
{
    /** @return array<string,mixed> */
    public function reconcile(NexusProvisioningTransaction $transaction,array $expected,array $observed): array
    {
        if((int)$transaction->company_id<=0) throw new \RuntimeException('company_id required for reconciliation.');
        $expectedCapabilities=array_values(array_unique(array_map('strval',(array)($expected['capabilities']??[]))));
        $observedCapabilities=array_values(array_unique(array_map('strval',(array)($observed['capabilities']??[]))));
        $missing=array_values(array_diff($expectedCapabilities,$observedCapabilities));
        $unexpected=array_values(array_diff($observedCapabilities,$expectedCapabilities));
        $drift=$missing!==[]||$unexpected!==[];

        $reconciliation=[
            'company_id'=>(int)$transaction->company_id,
            'transaction_id'=>(int)$transaction->id,
            'drift'=>$drift,
            'expected'=>$expectedCapabilities,
            'observed'=>$observedCapabilities,
            'missing'=>$missing,
            'unexpected'=>$unexpected,
            'next_action'=>$drift?'forward_recovery':'verify',
        ];
        $transaction->checkpoint=['stage'=>'reconciliation','reconciliation'=>$reconciliation];
        $transaction->status=$drift?'recovery_required':'reconciled';
        $transaction->save();
        return $reconciliation;
    }
}
