<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Observation;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessObservationRun;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessObservationSignal;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessRealityNode;
use App\Extensions\OnboardingPro\System\RealityGraph\BusinessRealityFactService;

final readonly class ContinuousBusinessObservationService
{
 // Incremental reobserve cycles update the persistent business reality graph without unnecessary full scans.
 public function __construct(
  private ObservationFreshnessPolicy $freshness,
  private ObservationChangeDetector $changes,
  private BusinessRealityFactService $facts,
 ){}

 public function plan(int $company_id,array $requested=[]):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $sources=$requested!==[]?$requested:array_keys($this->freshness->policies());$due=[];
  foreach($sources as $source){
   $last=BusinessObservationSignal::query()->where('company_id',$company_id)->where('source_type',(string)$source)->latest('observed_at')->first();
   if($this->freshness->due((string)$source,$last?->observed_at,now()))$due[]=(string)$source;
  }
  return ['company_id'=>$company_id,'mode'=>'incremental','requested_sources'=>array_values($sources),'due_sources'=>$due,'reobserve'=>$due!==[]];
 }

 public function record(int $company_id,array $signals,array $requested=[]):BusinessObservationRun
 {
  $plan=$this->plan($company_id,$requested);
  $run=BusinessObservationRun::query()->create(['company_id'=>$company_id,'status'=>'running','requested_sources'=>$plan['requested_sources'],'due_sources'=>$plan['due_sources'],'started_at'=>now()]);
  $counts=['new'=>0,'changed'=>0,'unchanged'=>0,'missing'=>0];
  foreach($signals as $signal){
   if(!is_array($signal))continue;
   $source=(string)($signal['source_type']??'unknown');if(!in_array($source,$plan['due_sources'],true))continue;
   $nodeType=(string)($signal['node_type']??'business');$external=(string)($signal['external_key']??'primary');
   $node=BusinessRealityNode::query()->where('company_id',$company_id)->where('node_type',$nodeType)->where('external_key',$external)->first();
   if(!$node)continue;
   $key=(string)($signal['fact_key']??'presence');$previous=$signal['previous']??null;$current=$signal['current']??null;
   $change=$this->changes->compare($previous,$current,(int)($signal['confidence']??80));$counts[$change['state']]++;
   $saved=BusinessObservationSignal::query()->create(['company_id'=>$company_id,'observation_run_id'=>$run->id,'source_type'=>$source,'signal_key'=>$key,'change_state'=>$change['state'],'confidence'=>$change['confidence'],'evidence'=>(array)($signal['evidence']??[]),'payload'=>$change,'observed_at'=>now()]);
   if($change['meaningful']&&$current!==null){
    $this->facts->record($company_id,$node->id,$key,$current,BusinessRealityFactService::OBSERVED,['type'=>$source,'ref'=>'observation_signal:'.$saved->id],(array)($signal['evidence']??[]),$change['confidence'],false,false);
   }
  }
  $run->status='complete';$run->summary=$counts;$run->completed_at=now();$run->save();return $run;
 }
}
