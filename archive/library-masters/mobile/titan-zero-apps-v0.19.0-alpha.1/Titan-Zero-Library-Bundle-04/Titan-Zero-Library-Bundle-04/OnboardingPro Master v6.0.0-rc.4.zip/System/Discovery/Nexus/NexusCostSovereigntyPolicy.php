<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

final class NexusCostSovereigntyPolicy
{
    /**
     * Canonical execution priority:
     * device -> local -> byo -> customer_service -> titan_entitlement -> titan_metered.
     *
     * Titan-paid routes never become silent fallback paths.
     *
     * @param array<string,mixed> $capability
     * @return array<string,mixed>
     */
    public function route(array $capability): array
    {
        $paths=(array)($capability['execution_paths']??[]);
        if((bool)($capability['no_external_resource']??false)){
            return $this->decision('titan_software_core','none',false,false,false,false,'NO_EXTERNAL_RESOURCE');
        }
        $normalised=[
            'device'=>(bool)($paths['device']??$capability['supports_device']??false),
            'local'=>(bool)($paths['local']??$capability['supports_local']??false),
            'byo'=>(bool)($paths['byo']??$capability['supports_byo']??false),
            'customer_service'=>(bool)($paths['customer_service']??$capability['supports_customer_service']??false),
            'titan_entitlement'=>(bool)($paths['titan_entitlement']??$capability['supports_titan_entitlement']??false),
            'titan_metered'=>(bool)($paths['titan_metered']??$capability['supports_titan_metered']??false),
        ];

        if($normalised['device']){
            return $this->decision('device','customer_device',false,false,false,false,'DEVICE_FIRST');
        }
        if($normalised['local']){
            return $this->decision('local','customer',false,false,false,false,'LOCAL_FIRST');
        }
        if($normalised['byo']){
            return $this->decision('byo','customer',false,false,false,false,'BYO_PROVIDER');
        }
        if($normalised['customer_service']){
            return $this->decision('customer_service','customer',false,false,false,false,'CUSTOMER_SERVICE');
        }

        if($normalised['titan_entitlement']){
            $entitled=(bool)($capability['entitlement_active']??false);
            if($entitled){
                return $this->decision('titan_entitlement','titan',true,true,false,false,'TITAN_ENTITLEMENT_ACTIVE');
            }
            return $this->decision(
                'titan_entitlement','titan',true,true,false,true,'TITAN_ENTITLEMENT_REQUIRED',
                ['required_entitlement'=>(string)($capability['required_entitlement']??'unspecified')]
            );
        }

        if($normalised['titan_metered']){
            $explicit_opt_in=(bool)($capability['explicit_opt_in']??false);
            $purchased=(bool)($capability['metered_purchase_active']??false);
            if($explicit_opt_in&&$purchased){
                return $this->decision('titan_metered','titan',true,true,true,false,'TITAN_METERED_PURCHASED');
            }
            return $this->decision(
                'titan_metered','titan',true,true,$explicit_opt_in,true,
                $explicit_opt_in?'TITAN_METERED_PURCHASE_REQUIRED':'TITAN_METERED_EXPLICIT_OPT_IN_REQUIRED'
            );
        }

        return $this->decision('unavailable','none',false,false,false,true,'NO_PERMITTED_EXECUTION_PATH');
    }

    /** @return array<string,mixed> */
    private function decision(
        string $execution_location,
        string $cost_owner,
        bool $requires_paid_resource,
        bool $requires_entitlement,
        bool $explicit_opt_in,
        bool $blocked,
        string $reason,
        array $extra=[],
    ): array {
        return array_merge([
            'execution_location'=>$execution_location,
            'cost_owner'=>$cost_owner,
            'requires_paid_resource'=>$requires_paid_resource,
            'requires_entitlement'=>$requires_entitlement,
            'explicit_opt_in'=>$explicit_opt_in,
            'blocked'=>$blocked,
            'reason'=>$reason,
            'fallback_order'=>['device','local','byo','customer_service','titan_entitlement','titan_metered'],
        ],$extra);
    }
}
