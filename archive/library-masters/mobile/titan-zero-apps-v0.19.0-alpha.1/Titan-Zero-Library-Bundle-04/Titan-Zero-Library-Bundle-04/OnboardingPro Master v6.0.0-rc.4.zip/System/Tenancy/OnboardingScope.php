<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Tenancy;

final readonly class OnboardingScope
{
    public function __construct(public OnboardingCompanyContext $context) {}

    public function assertCompany(int $companyId): int
    {
        if ($companyId !== $this->context->companyId) {
            throw new \RuntimeException('Cross-company onboarding access denied.');
        }

        return $companyId;
    }

    /** @param array<string,mixed> $constraints @return array<string,mixed> */
    public function constraints(array $constraints = []): array
    {
        return ['company_id' => $this->context->companyId] + $constraints;
    }
}
