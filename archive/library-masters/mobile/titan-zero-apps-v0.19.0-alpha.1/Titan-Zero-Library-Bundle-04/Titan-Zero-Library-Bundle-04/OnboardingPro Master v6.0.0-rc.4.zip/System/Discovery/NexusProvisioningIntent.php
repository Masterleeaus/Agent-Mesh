<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use DateTimeZone;

final readonly class NexusProvisioningIntent
{
    /**
     * @param array<string,mixed> $verticalReference
     * @param array<string,mixed> $jurisdiction
     * @param array<string,mixed> $businessRequirements
     * @param list<string> $capabilityRequirements
     * @param list<string> $workflowRequirements
     * @param array<string,mixed> $workforceRequirements
     * @param list<string> $knowledgeRequirements
     * @param list<string> $surfaceRequirements
     * @param list<string> $integrationRequirements
     * @param list<string> $complianceRequirements
     * @param array<string,mixed> $aiPreferences
     * @param array<string,mixed> $autonomyPreferences
     * @param array<string,mixed> $riskPreferences
     * @param list<string> $configurationGaps
     * @param array<string,mixed> $traceContext
     */
    public function __construct(
        public int $companyId,
        public int $discoveryProfileRevision,
        public string $discoveryProfileVersion,
        public array $verticalReference,
        public array $jurisdiction,
        public string $timezone,
        public array $businessRequirements,
        public array $capabilityRequirements,
        public array $workflowRequirements,
        public array $workforceRequirements,
        public array $knowledgeRequirements,
        public array $surfaceRequirements,
        public array $integrationRequirements,
        public array $complianceRequirements,
        public array $aiPreferences,
        public array $autonomyPreferences,
        public array $riskPreferences,
        public array $configurationGaps,
        public array $traceContext,
    ) {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Nexus provisioning intent requires positive company_id.');
        }
        if ($discoveryProfileRevision <= 0) {
            throw new \InvalidArgumentException('Nexus provisioning intent requires positive discovery_profile_revision.');
        }
        if ($discoveryProfileVersion !== 'discovery-r'.$discoveryProfileRevision) {
            throw new \InvalidArgumentException('Nexus provisioning discovery profile version/revision mismatch.');
        }
        foreach (['vertical_id','vertical_version','resolution_request_hash'] as $key) {
            if (trim((string) ($verticalReference[$key] ?? '')) === '') {
                throw new \InvalidArgumentException("Nexus provisioning vertical_reference.$key is required.");
            }
        }
        if (preg_match('/^[0-9a-f]{64}$/', strtolower((string) $verticalReference['resolution_request_hash'])) !== 1) {
            throw new \InvalidArgumentException('Nexus provisioning vertical resolution_request_hash must be SHA-256.');
        }
        $countryCode = strtoupper(trim((string) ($jurisdiction['country_code'] ?? '')));
        if (preg_match('/^[A-Z]{2}$/', $countryCode) !== 1) {
            throw new \InvalidArgumentException('Nexus provisioning jurisdiction.country_code must be a two-letter country code.');
        }
        try {
            new DateTimeZone($timezone);
        } catch (\Throwable) {
            throw new \InvalidArgumentException('Nexus provisioning timezone must be a valid IANA timezone.');
        }
        if (($traceContext['company_id'] ?? null) !== $companyId) {
            throw new \InvalidArgumentException('Nexus provisioning trace_context company_id mismatch.');
        }
        foreach (['trace_id','correlation_id','causation_id','actor_id'] as $key) {
            if (!array_key_exists($key, $traceContext) || trim((string) $traceContext[$key]) === '') {
                throw new \InvalidArgumentException("Nexus provisioning trace_context.$key is required.");
            }
        }
        if ($businessRequirements === []) {
            throw new \InvalidArgumentException('Nexus provisioning business_requirements cannot be empty.');
        }
        if ($capabilityRequirements === []) {
            throw new \InvalidArgumentException('Nexus provisioning capability_requirements cannot be empty.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'schema' => 'titan.nexus-provisioning-intent',
            'version' => '1.1',
            'company_id' => $this->companyId,
            'discovery_profile_revision' => $this->discoveryProfileRevision,
            'discovery_profile_version' => $this->discoveryProfileVersion,
            'vertical_reference' => $this->verticalReference,
            'jurisdiction' => $this->jurisdiction,
            'timezone' => $this->timezone,
            'business_requirements' => $this->businessRequirements,
            'capability_requirements' => $this->capabilityRequirements,
            'workflow_requirements' => $this->workflowRequirements,
            'workforce_requirements' => $this->workforceRequirements,
            'knowledge_requirements' => $this->knowledgeRequirements,
            'surface_requirements' => $this->surfaceRequirements,
            'integration_requirements' => $this->integrationRequirements,
            'compliance_requirements' => $this->complianceRequirements,
            'ai_preferences' => $this->aiPreferences,
            'autonomy_preferences' => $this->autonomyPreferences,
            'risk_preferences' => $this->riskPreferences,
            'configuration_gaps' => $this->configurationGaps,
            'trace_context' => $this->traceContext,
        ];
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode(self::canonicalise($this->toArray()), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private static function canonicalise(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(self::canonicalise(...), $value);
        }
        ksort($value);
        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalise($item);
        }
        return $value;
    }
}
