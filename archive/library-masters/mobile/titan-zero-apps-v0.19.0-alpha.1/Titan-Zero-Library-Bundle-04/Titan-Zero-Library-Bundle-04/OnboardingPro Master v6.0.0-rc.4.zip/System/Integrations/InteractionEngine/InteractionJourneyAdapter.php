<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\InteractionEngine;
use App\Extensions\OnboardingPro\System\Contracts\JourneyRuntimeInterface;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepDefinition;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
final class InteractionJourneyAdapter implements JourneyRuntimeInterface
{
    public function map(string $journeyKey,string $name,string $version,array $steps,JourneyExecutionContext $context): array
    {
        if(trim($journeyKey)===''||trim($name)===''||trim($version)==='') throw new \InvalidArgumentException('Journey identity is required.');
        $wizardIds=[];$wizards=[];
        foreach(array_values($steps) as $i=>$step){
            if(!$step instanceof StepDefinition) throw new \InvalidArgumentException('Runtime mapping requires StepDefinition values.');
            $wid='onboarding.'.$journeyKey.'.'.$step->key;
            $wizardIds[]=$wid;
            $wizards[]=[
                'id'=>$wid,
                'version'=>$version,
                'name'=>(string)($step->config['title']??ucwords(str_replace(['-','_'], ' ', $step->key))),
                'capability'=>'onboarding.step.complete',
                'steps'=>[array_merge([
                    'id'=>$step->key,
                    'type'=>$step->type->value,
                    'actor'=>$step->actor,
                    'conditions'=>$step->conditions,
                    'completion_rule'=>$step->completionRule,
                    'config'=>$step->config,
                ],$step->capabilityId!==null?['capability'=>$step->capabilityId]:[])],
                'permissions'=>['required_roles'=>[]],
                'metadata'=>['onboarding'=>true,'journey_key'=>$journeyKey,'step_key'=>$step->key,'participant_id'=>$context->participantId],
                'offline'=>['policy'=>$step->offlinePolicy],
                'governance'=>['risk_level'=>$step->riskLevel,'capability_id'=>$step->capabilityId],
            ];
        }
        return [
            'journey'=>[
                'id'=>'onboarding.'.$journeyKey,
                'name'=>$name,
                'wizards'=>$wizardIds,
                'surfaces'=>['zero'],
                'prerequisites'=>[],
                'requirements'=>[],
                'metadata'=>['onboarding'=>true,'journey'=>'onboarding','legacy_source_surface'=>$context->sourceSurface,'journey_version_id'=>$context->journeyVersionId,'enrolment_id'=>$context->enrolmentId],
            ],
            'wizards'=>$wizards,
            'context'=>$context->toInteractionContext(),
        ];
    }
}
