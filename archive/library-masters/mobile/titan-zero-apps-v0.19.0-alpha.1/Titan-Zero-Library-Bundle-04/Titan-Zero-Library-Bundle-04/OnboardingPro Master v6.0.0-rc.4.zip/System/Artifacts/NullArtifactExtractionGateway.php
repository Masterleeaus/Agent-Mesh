<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Artifacts;
final class NullArtifactExtractionGateway implements ArtifactExtractionGatewayInterface{public function extract(array $artifact,array $context):array{throw new \RuntimeException('No artifact/Vision extraction provider configured.');}}
