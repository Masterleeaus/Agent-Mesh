<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Journeys;

final readonly class Journey
{
    public function __construct(
        public int $companyId,
        public string $key,
        public string $name,
        public string $audience,
    ) {
        if ($this->companyId <= 0) {
            throw new \InvalidArgumentException('Journey company ID must be positive.');
        }
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,99}$/', $this->key) !== 1) {
            throw new \InvalidArgumentException('Journey key is invalid.');
        }
        if (trim($this->name) === '') {
            throw new \InvalidArgumentException('Journey name is required.');
        }
        if (preg_match('/^[a-z][a-z0-9._-]{1,49}$/', $this->audience) !== 1) {
            throw new \InvalidArgumentException('Journey audience is invalid.');
        }
    }
}
