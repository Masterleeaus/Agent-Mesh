<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryCompiler;
use App\Extensions\OnboardingPro\System\Discovery\BusinessDiscoveryProfile;
use App\Extensions\OnboardingPro\System\Discovery\BusinessSetupState;
use App\Extensions\OnboardingPro\System\Discovery\NexusProvisioningIntent;
use App\Extensions\OnboardingPro\System\Discovery\VerticalResolution;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class NexusIntentFactory
{
    public function __construct(private BusinessDiscoveryCompiler $compiler) {}

    public function fromSetupState(BusinessSetupState $state, OnboardingTraceContext $trace): NexusProvisioningIntent
    {
        if ($state->revision <= 0 || !is_array($state->verticalResolution)
            || ($state->verticalResolution['canonical_ready'] ?? false) !== true) {
            throw new \RuntimeException('Canonical vertical resolution is required before Nexus draft preparation.');
        }

        $v = $state->verticalResolution;
        $sourceRevision = (int) ($v['source_profile_revision'] ?? 0);
        if ($sourceRevision <= 0 || $sourceRevision > $state->revision) {
            throw new \RuntimeException('Nexus draft preparation requires valid vertical resolution revision provenance.');
        }

        $resolution = new VerticalResolution(
            status: (string) ($v['status'] ?? ''),
            companyId: $trace->companyId,
            requestHash: (string) ($v['request_hash'] ?? ''),
            verticalId: isset($v['vertical_id']) ? (string) $v['vertical_id'] : null,
            verticalVersion: isset($v['vertical_version']) ? (string) $v['vertical_version'] : null,
            confidence: (float) ($v['confidence'] ?? 0.0),
            definitionHash: isset($v['definition_hash']) ? (string) $v['definition_hash'] : null,
            candidates: (array) ($v['candidates'] ?? []),
            secondaryVerticals: (array) ($v['secondary_verticals'] ?? []),
            reasonCodes: (array) ($v['reason_codes'] ?? []),
            engineReceiptId: isset($v['engine_receipt_id']) ? (string) $v['engine_receipt_id'] : null,
        );

        return $this->compiler->compileNexusProvisioningIntent(
            BusinessDiscoveryProfile::fromArray($state->profile),
            $trace,
            $resolution,
            $state->revision,
        );
    }
}
