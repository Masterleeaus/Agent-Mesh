<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Persistence\Models\BootstrapIntentRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Support\Facades\DB;

final class BootstrapIntentRepository
{
    public function persistPrepared(
        int $companyId,
        ?int $discoveryProfileId,
        BootstrapIntent $intent,
        OnboardingTraceContext $trace,
    ): BootstrapIntentRecord {
        $this->assertCompany($companyId, $trace);

        return DB::transaction(function () use ($companyId, $discoveryProfileId, $intent, $trace): BootstrapIntentRecord {
            $existing = BootstrapIntentRecord::query()
                ->where('company_id', $companyId)
                ->where('idempotency_key', $intent->idempotencyKey)
                ->lockForUpdate()
                ->first();

            if ($existing !== null) {
                if ((string) $existing->target_engine !== $intent->targetEngine
                    || (string) $existing->operation !== $intent->operation
                    || (array) $existing->payload !== $intent->payload) {
                    throw new \RuntimeException('Bootstrap intent idempotency collision detected.');
                }
                return $existing;
            }

            return BootstrapIntentRecord::query()->create([
                'company_id' => $companyId,
                'discovery_profile_id' => $discoveryProfileId,
                'target_engine' => $intent->targetEngine,
                'operation' => $intent->operation,
                'status' => 'PREPARED',
                'payload' => $intent->payload,
                'idempotency_key' => $intent->idempotencyKey,
                'trace_id' => $trace->traceId,
                'correlation_id' => $trace->correlationId,
                'causation_id' => $trace->causationId,
                'response_receipt' => null,
            ]);
        }, 3);
    }

    public function recordReceipt(
        int $companyId,
        string $idempotencyKey,
        string $status,
        array $receipt,
        OnboardingTraceContext $trace,
    ): BootstrapIntentRecord {
        $this->assertCompany($companyId, $trace);
        $status = strtoupper(trim($status));
        if (!in_array($status, ['PREVIEWED','BLOCKED','FAILED','UNAVAILABLE'], true)) {
            throw new \InvalidArgumentException('Unsupported Nexus draft bridge status.');
        }

        return DB::transaction(function () use ($companyId, $idempotencyKey, $status, $receipt): BootstrapIntentRecord {
            $record = BootstrapIntentRecord::query()
                ->where('company_id', $companyId)
                ->where('idempotency_key', $idempotencyKey)
                ->lockForUpdate()
                ->first();
            if ($record === null) {
                throw new \RuntimeException('Bootstrap intent receipt cannot be recorded before intent persistence.');
            }

            if ($record->response_receipt !== null) {
                if ((string) $record->status !== $status || (array) $record->response_receipt !== $receipt) {
                    throw new \RuntimeException('Bootstrap intent receipt is immutable once recorded.');
                }
                return $record;
            }

            $record->status = $status;
            $record->response_receipt = $receipt;
            $record->save();
            return $record->refresh();
        }, 3);
    }

    public function findByIdempotency(int $companyId, string $idempotencyKey): ?BootstrapIntentRecord
    {
        if ($companyId <= 0 || trim($idempotencyKey) === '') {
            throw new \InvalidArgumentException('Company and idempotency key are required.');
        }
        return BootstrapIntentRecord::query()
            ->where('company_id', $companyId)
            ->where('idempotency_key', $idempotencyKey)
            ->first();
    }

    private function assertCompany(int $companyId, OnboardingTraceContext $trace): void
    {
        if ($companyId <= 0 || $trace->companyId !== $companyId) {
            throw new \RuntimeException('Cross-company bootstrap intent persistence denied.');
        }
    }
}
