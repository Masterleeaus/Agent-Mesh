<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Discovery\BusinessSetupState;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class NexusConfigurationReviewService
{
    public function __construct(
        private NexusIntentFactory $intents,
        private NexusDraftBridge $bridge,
        private NexusConfigurationIntelligenceService $intelligence,
    ) {}

    public function preview(BusinessSetupState $state, int $discoveryProfileId, OnboardingTraceContext $trace): NexusConfigurationReview
    {
        $intent=$this->intents->fromSetupState($state,$trace);
        $receipt=$this->bridge->preview($intent,$discoveryProfileId,$trace);
        $preview=(array)($receipt['preview']??[]);
        $validation=(array)($receipt['validation']??[]);
        $gaps=(array)($preview['gaps']??$validation['gaps']??[]);
        $configurationIntelligence=$this->intelligence->analyse($intent,$preview,$validation);
        return new NexusConfigurationReview(
            status:(string)($receipt['status']??'UNAVAILABLE'),
            summary:(array)($preview['summary']??$preview['configuration_summary']??[]),
            missingExtensions:$this->items($preview,'missing_extensions',$gaps),
            missingCredentials:$this->items($preview,'missing_credentials',$gaps),
            missingDependencies:$this->items($preview,'missing_dependencies',$gaps),
            complianceRequirements:$this->items($preview,'compliance_requirements',$gaps),
            followUpQuestions:$this->items($preview,'follow_up_questions',$gaps),
            warnings:array_values((array)($preview['warnings']??$validation['warnings']??[])),
            configurationIntelligence:$configurationIntelligence,
            rawReceipt:array_merge($receipt,['configuration_intelligence'=>$configurationIntelligence]),
        );
    }

    private function items(array $preview,string $key,array $gaps): array
    {
        $value=$preview[$key]??$gaps[$key]??[];
        return array_values(is_array($value)?$value:[]);
    }
}
