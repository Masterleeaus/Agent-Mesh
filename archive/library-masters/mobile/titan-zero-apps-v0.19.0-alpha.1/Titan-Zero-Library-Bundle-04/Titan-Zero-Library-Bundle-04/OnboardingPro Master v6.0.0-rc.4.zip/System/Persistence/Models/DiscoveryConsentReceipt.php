<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class DiscoveryConsentReceipt extends Model{protected $table='ext_onboarding_discovery_consents';protected $guarded=[];protected $casts=['company_id'=>'integer','user_id'=>'integer','granted_at'=>'immutable_datetime','expires_at'=>'immutable_datetime','revoked_at'=>'immutable_datetime','scope_details'=>'array'];}
