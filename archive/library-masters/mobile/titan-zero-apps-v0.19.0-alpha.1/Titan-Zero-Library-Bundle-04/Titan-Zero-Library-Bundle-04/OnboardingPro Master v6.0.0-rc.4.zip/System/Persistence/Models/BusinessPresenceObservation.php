<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class BusinessPresenceObservation extends Model
{
    protected $table='ext_onboarding_presence_observations';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'audit_id'=>'integer',
        'confidence'=>'integer',
        'evidence'=>'array',
        'observation_payload'=>'array',
        'observed_at'=>'immutable_datetime',
    ];
}
