<?php

declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class StepInstanceRecord extends Model { protected $table='ext_onboarding_step_instances'; protected $guarded=[]; protected $casts=['available_at'=>'immutable_datetime','completed_at'=>'immutable_datetime']; }
