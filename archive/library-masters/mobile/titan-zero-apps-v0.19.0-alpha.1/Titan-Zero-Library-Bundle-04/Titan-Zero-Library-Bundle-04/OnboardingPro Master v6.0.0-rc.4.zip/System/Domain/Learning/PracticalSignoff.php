<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Learning;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class PracticalSignoff
{
    private function __construct(public string $signoffId,public int $companyId,public int $subjectId,public int $assessorActorId,public string $competencyKey,public string $result,public array $evidenceIds,public DateTimeImmutable $assessedAt) {}
    public static function record(string $signoffId,int $companyId,int $subjectId,int $assessorActorId,string $competencyKey,string $result,array $evidenceIds,DateTimeImmutable $assessedAt): self
    { if(!in_array($result,['passed','failed','rework'],true))throw new InvalidArgumentException('Unsupported practical signoff result.'); return new self($signoffId,$companyId,$subjectId,$assessorActorId,$competencyKey,$result,array_values(array_unique($evidenceIds)),$assessedAt); }
    public function passed(): bool { return $this->result==='passed'; }
}
