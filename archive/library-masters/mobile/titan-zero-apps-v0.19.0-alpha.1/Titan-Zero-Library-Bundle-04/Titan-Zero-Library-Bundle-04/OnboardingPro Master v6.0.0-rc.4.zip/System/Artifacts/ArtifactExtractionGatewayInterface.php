<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Artifacts;
interface ArtifactExtractionGatewayInterface{public function extract(array $artifact,array $context):array;}
