<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\InteractionEngine;
use App\Extensions\OnboardingPro\System\Contracts\JourneyRuntimeInterface;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
final class OnboardingJourneyRuntime
{
    public function __construct(private readonly JourneyRuntimeInterface $adapter, private readonly bool $publicContractAvailable=false){}
    public function prepare(string $key,string $name,string $version,array $steps,JourneyExecutionContext $context): array{return $this->adapter->map($key,$name,$version,$steps,$context);}
    public function interactionEngineAvailable(): bool{return $this->publicContractAvailable;}
}
