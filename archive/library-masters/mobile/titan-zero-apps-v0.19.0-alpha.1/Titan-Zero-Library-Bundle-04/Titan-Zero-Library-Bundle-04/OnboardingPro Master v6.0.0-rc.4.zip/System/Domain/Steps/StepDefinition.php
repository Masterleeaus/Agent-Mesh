<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Steps;

final readonly class StepDefinition
{
    /** @param array<string,mixed> $config @param list<string|array<string,mixed>> $conditions */
    public function __construct(
        public string $key,
        public StepType $type,
        public string $actor,
        public array $config,
        public array $conditions,
        public string $completionRule,
        public string $riskLevel = 'low',
        public string $offlinePolicy = 'allowed',
        public ?string $capabilityId = null,
    ) {
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,99}$/', $this->key) !== 1) throw new \InvalidArgumentException('Step key is invalid.');
        if (preg_match('/^[a-z][a-z0-9._-]{1,49}$/', $this->actor) !== 1) throw new \InvalidArgumentException('Step actor is invalid.');
        if (trim($this->completionRule) === '') throw new \InvalidArgumentException('Step completion rule is required.');
        if (!in_array($this->riskLevel, ['low','medium','high','critical'], true)) throw new \InvalidArgumentException('Step risk level is invalid.');
        if (!in_array($this->offlinePolicy, ['allowed','deferred','online_required'], true)) throw new \InvalidArgumentException('Step offline policy is invalid.');
        if ($this->capabilityId !== null && preg_match('/^[a-z0-9][a-z0-9._-]{2,149}$/', $this->capabilityId) !== 1) throw new \InvalidArgumentException('Step capability ID is invalid.');
    }
}
