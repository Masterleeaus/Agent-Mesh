<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class InterventionOutcome extends Model{protected $table='ext_onboarding_intervention_outcomes';protected $guarded=[];protected $casts=['company_id'=>'integer','intervention_execution_id'=>'integer','baseline'=>'array','observed'=>'array','delta'=>'array','confidence'=>'integer','unintended_effects'=>'array','rollback_decision'=>'array','knowledge'=>'array'];}
