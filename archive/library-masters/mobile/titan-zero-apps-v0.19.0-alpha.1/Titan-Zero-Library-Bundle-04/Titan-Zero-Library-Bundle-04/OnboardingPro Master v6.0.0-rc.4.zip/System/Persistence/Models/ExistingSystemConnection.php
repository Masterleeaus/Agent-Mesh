<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class ExistingSystemConnection extends Model
{
    protected $table='ext_onboarding_existing_system_connections';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'user_id'=>'integer',
        'connection_metadata'=>'array',
        'discovery_receipt'=>'array',
        'read_only'=>'boolean',
    ];
}
