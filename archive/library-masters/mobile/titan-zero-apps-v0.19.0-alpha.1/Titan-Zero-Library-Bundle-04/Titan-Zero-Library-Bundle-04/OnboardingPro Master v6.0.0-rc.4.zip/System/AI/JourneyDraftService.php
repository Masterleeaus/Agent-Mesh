<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\AI;
final class JourneyDraftService{
 public function __construct(private ?JourneyDraftValidator $validator=null){$this->validator??=new JourneyDraftValidator();}
 public function draft(JourneyDraftRequest $r):JourneyDraftResult{$this->validator->validate($r);$types=array_values(array_unique($r->requestedStepTypes?:['information','form','completion']));$steps=[];foreach($types as $i=>$t){$steps[]=['key'=>sprintf('draft_step_%02d',$i+1),'type'=>$t,'actor'=>'participant','configuration'=>[],'conditions'=>[],'completion_rule'=>['type'=>'explicit'],'risk'=>'low','offline_policy'=>$t==='approval'?'ONLINE_REQUIRED':'OFFLINE_PREPARE_ONLY'];}return new JourneyDraftResult('DRAFT',['schema_version'=>'1.0','goal'=>$r->goal,'vertical'=>$r->vertical,'jurisdiction'=>$r->jurisdiction,'steps'=>$steps,'requested_capabilities'=>$r->requestedCapabilities,'provenance'=>['origin'=>'titan_ai_draft','trace_id'=>$r->traceId,'human_review_required'=>true]],false,['HUMAN_REVIEW_REQUIRED'],$r->traceId);}
}
