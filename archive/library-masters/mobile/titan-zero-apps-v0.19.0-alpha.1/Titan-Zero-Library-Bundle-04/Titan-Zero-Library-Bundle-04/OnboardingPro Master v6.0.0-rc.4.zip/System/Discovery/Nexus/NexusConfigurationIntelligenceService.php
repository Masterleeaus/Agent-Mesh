<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Discovery\NexusProvisioningIntent;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusConfigurationDecision;

final readonly class NexusConfigurationIntelligenceService
{
    public function __construct(private NexusCostSovereigntyPolicy $costPolicy) {}

    /**
     * @return array<string,mixed>
     */
    public function analyse(
        NexusProvisioningIntent $intent,
        array $preview,
        array $validation=[],
    ): array {
        $payload=$intent->toArray();
        $company_id=(int)($payload['company_id']??0);
        if($company_id<=0) throw new \RuntimeException('company_id required for Nexus configuration intelligence.');

        $capabilityMetadata=$this->capabilityMetadata($preview);
        $decisions=[];
        foreach((array)$payload['capability_requirements'] as $capabilityKey){
            $key=(string)$capabilityKey;
            $metadata=(array)($capabilityMetadata[$key]??[]);
            $cost=$this->costPolicy->route($this->costDescriptor($key,$metadata,$payload));

            $why=$this->why($key,$metadata,$payload);
            $dependencies=array_values(array_unique(array_map('strval',(array)($metadata['dependencies']??$this->defaultDependencies($key)))));
            $authority=(string)($metadata['authority']??$this->defaultAuthority($key));
            $autonomy_ceiling=(string)($metadata['autonomy_ceiling']??$this->autonomyCeiling($key,(array)$payload['autonomy_preferences']));
            $provider=$this->provider($metadata,$cost);
            $risk=$this->risk($key,$metadata,(array)$payload['risk_preferences']);
            $reversible=(bool)($metadata['reversible']??true);
            $verification=$this->verification($key,$metadata);
            $blocked=(bool)$cost['blocked'] || (bool)($metadata['blocked']??false);

            $decisionPayload=[
                'capability'=>$key,
                'capability_type'=>(string)($metadata['capability_type']??'titan_software'),
                'permission_source'=>'policy_and_owner_authority',
                'why'=>$why,
                'dependencies'=>$dependencies,
                'authority'=>$authority,
                'autonomy_ceiling'=>$autonomy_ceiling,
                'execution_location'=>$cost['execution_location'],
                'provider'=>$provider,
                'cost_owner'=>$cost['cost_owner'],
                'requires_paid_resource'=>$cost['requires_paid_resource'],
                'requires_entitlement'=>$cost['requires_entitlement'],
                'explicit_opt_in'=>$cost['explicit_opt_in'],
                'risk'=>$risk,
                'reversible'=>$reversible,
                'verification'=>$verification,
                'blocked'=>$blocked,
                'cost_route_reason'=>$cost['reason'],
                'fallback_order'=>$cost['fallback_order'],
            ];

            $record=NexusConfigurationDecision::query()->updateOrCreate(
                [
                    'company_id'=>$company_id,
                    'discovery_revision'=>(int)$payload['discovery_profile_revision'],
                    'capability_key'=>$key,
                ],
                [
                    'why'=>$why,
                    'dependencies'=>$dependencies,
                    'authority'=>$authority,
                    'autonomy_ceiling'=>$autonomy_ceiling,
                    'execution_location'=>$cost['execution_location'],
                    'provider'=>$provider,
                    'cost_owner'=>$cost['cost_owner'],
                    'requires_paid_resource'=>$cost['requires_paid_resource'],
                    'requires_entitlement'=>$cost['requires_entitlement'],
                    'explicit_opt_in'=>$cost['explicit_opt_in'],
                    'risk'=>$risk,
                    'reversible'=>$reversible,
                    'verification'=>$verification,
                    'blocked'=>$blocked,
                    'decision_payload'=>$decisionPayload,
                ],
            );
            $decisionPayload['decision_id']=$record->id;
            $decisions[]=$decisionPayload;
        }

        $blocked=array_values(array_filter($decisions,static fn(array $d):bool=>(bool)$d['blocked']));
        return [
            'company_id'=>$company_id,
            'discovery_revision'=>(int)$payload['discovery_profile_revision'],
            'configuration_intelligence'=>$decisions,
            'cost_sovereignty'=>[
                'priority'=>['device','local','byo','customer_service','titan_entitlement','titan_metered'],
                'hidden_titan_fallback_allowed'=>false,
                'blocked_paid_routes'=>array_values(array_map(static fn(array $d):array=>[
                    'capability'=>$d['capability'],
                    'execution_location'=>$d['execution_location'],
                    'cost_owner'=>$d['cost_owner'],
                    'reason'=>$d['cost_route_reason'],
                ],$blocked)),
            ],
            'blocking_decisions'=>count($blocked),
            'ready_for_cost_approval'=>$blocked===[],
            'validation_status'=>(bool)($validation['valid']??$validation['is_valid']??false),
        ];
    }

    /** @return array<string,array<string,mixed>> */
    private function capabilityMetadata(array $preview): array
    {
        $items=(array)($preview['capabilities']??$preview['recommended_capabilities']??$preview['configuration_intelligence']??[]);
        $map=[];
        foreach($items as $key=>$item){
            if(is_string($item)){$map[$item]=[];continue;}
            if(!is_array($item))continue;
            $cap=(string)($item['capability']??$item['key']??(is_string($key)?$key:''));
            if($cap!=='')$map[$cap]=$item;
        }
        return $map;
    }

    /** @return array<string,mixed> */
    private function costDescriptor(string $key,array $metadata,array $intent): array
    {
        $descriptor=(array)($metadata['cost']??$metadata['resource_policy']??[]);
        if($descriptor!==[]) return array_merge($metadata,$descriptor);

        // Core Titan software configuration is non-metered by default.
        // External/AI execution must be explicitly described by Nexus metadata.
        return [
            'no_external_resource'=>true,
            'supports_device'=>false,
            'supports_local'=>false,
            'supports_byo'=>false,
            'supports_customer_service'=>false,
            'supports_titan_entitlement'=>false,
            'supports_titan_metered'=>false,
            'capability'=>$key,
            'ai_preferences'=>(array)($intent['ai_preferences']??[]),
        ];
    }

    /** @return list<string> */
    private function why(string $key,array $metadata,array $intent): array
    {
        $explicit=array_values(array_filter(array_map('strval',(array)($metadata['why']??$metadata['reason_codes']??[]))));
        if($explicit!==[])return $explicit;

        $business=(array)$intent['business_requirements'];
        return match($key){
            'customer_management'=>['Business onboarding requires governed customer records and relationships.'],
            'job_management'=>['Discovered services require an operational job lifecycle.'],
            'scheduling'=>['Operating hours and/or job workflow require scheduling capability.'],
            'billing'=>['Pricing or accepted payment methods indicate billing capability is required.'],
            'communications'=>['Discovered customer communication channels require governed routing.'],
            'asset_management'=>['Business equipment/assets were discovered during onboarding.'],
            'compliance'=>['Compliance requirements were discovered for this business and jurisdiction.'],
            default=>['Capability is required by the approved business discovery profile.'],
        };
    }

    /** @return list<string> */
    private function defaultDependencies(string $key): array
    {
        return match($key){
            'job_management'=>['customer_management'],
            'scheduling'=>['job_management'],
            'billing'=>['customer_management','job_management'],
            'communications'=>['customer_management'],
            'asset_management'=>['job_management'],
            'compliance'=>['business_profile'],
            default=>['business_profile'],
        };
    }

    private function defaultAuthority(string $key): string
    {
        return match($key){
            'customer_management'=>'Customer/CRM extension',
            'job_management','scheduling','asset_management'=>'Work/Operations owning extension',
            'billing'=>'Money/Payments owning extension',
            'communications'=>'Communications owning extension',
            'compliance'=>'Risk/Compliance owning extension',
            default=>'Owning Titan extension',
        };
    }

    private function autonomyCeiling(string $key,array $preferences): string
    {
        $requested=strtolower((string)($preferences['default']??$preferences['level']??'assist'));
        $allowed=['manual','assist','semi','auto','trusted_auto','predictive'];
        if(!in_array($requested,$allowed,true))$requested='assist';
        if(in_array($key,['billing','compliance'],true)&&in_array($requested,['trusted_auto','predictive'],true))return 'auto';
        return $requested;
    }

    /** @return array<string,mixed> */
    private function provider(array $metadata,array $cost): array
    {
        return [
            'provider_key'=>(string)($metadata['provider_key']??'titan_core'),
            'provider_type'=>(string)($metadata['provider_type']??($cost['execution_location']==='titan_software_core'?'software':'external')),
            'execution_location'=>$cost['execution_location'],
            'intelligence_source'=>(string)($metadata['intelligence_source']??'NONE'),
        ];
    }

    /** @return array<string,mixed> */
    private function risk(string $key,array $metadata,array $preferences): array
    {
        $level=(string)($metadata['risk_level']??(in_array($key,['billing','compliance'],true)?'elevated':'standard'));
        return [
            'level'=>$level,
            'approval_required'=>(bool)($metadata['approval_required']??in_array($key,['billing','compliance'],true)),
            'policy_context'=>$preferences,
        ];
    }

    /** @return array<string,mixed> */
    private function verification(string $key,array $metadata): array
    {
        return [
            'required'=>(bool)($metadata['verification_required']??true),
            'owner'=>(string)($metadata['verification_owner']??$this->defaultAuthority($key)),
            'checks'=>array_values((array)($metadata['verification_checks']??['capability_enabled','authority_owner_confirmed','dependency_state_verified'])),
        ];
    }
}
