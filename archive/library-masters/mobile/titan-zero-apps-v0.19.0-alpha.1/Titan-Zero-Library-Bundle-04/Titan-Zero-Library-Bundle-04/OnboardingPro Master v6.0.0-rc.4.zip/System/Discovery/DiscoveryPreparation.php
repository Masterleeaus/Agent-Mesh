<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

final readonly class DiscoveryPreparation
{
    /** @param list<BootstrapIntent> $bootstrapIntents @param list<array<string,mixed>> $signalReceipts */
    public function __construct(
        public string $profileHash,
        public ProgressiveReadinessResult $readiness,
        public array $bootstrapIntents,
        public array $signalReceipts,
    ) {}

    public function toArray(): array
    {
        return [
            'profile_hash'=>$this->profileHash,
            'readiness'=>[
                'minimum_ready'=>$this->readiness->minimumReady,
                'operational_ready'=>$this->readiness->operationalReady,
                'remaining_domains'=>$this->readiness->remainingDomains,
                'reason_codes'=>$this->readiness->reasonCodes,
            ],
            'bootstrap_intents'=>array_map(static fn(BootstrapIntent $i):array=>$i->toArray(),$this->bootstrapIntents),
            'signal_receipts'=>$this->signalReceipts,
        ];
    }
}
