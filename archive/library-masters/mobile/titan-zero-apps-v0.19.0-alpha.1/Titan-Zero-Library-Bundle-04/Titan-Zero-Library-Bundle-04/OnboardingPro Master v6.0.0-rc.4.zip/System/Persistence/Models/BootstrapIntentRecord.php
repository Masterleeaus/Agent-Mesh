<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class BootstrapIntentRecord extends Model
{
    protected $table = 'ext_onboarding_bootstrap_intents';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'discovery_profile_id' => 'integer',
        'payload' => 'array',
        'response_receipt' => 'array',
    ];
}
