<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\Payments;
final class PaymentConfirmationGateway
{
    public function prepare(int $companyId,string $subjectRef,string $provider,string $providerRef,array $trace): array
    {
        if($companyId<=0) throw new \InvalidArgumentException('company_id required.');
        return ['status'=>'PREPARED','authoritative'=>false,'capability'=>'payment.confirm','company_id'=>$companyId,'subject_ref'=>$subjectRef,'provider'=>$provider,'provider_ref'=>$providerRef,'trace'=>$trace,'idempotency_key'=>hash('sha256',implode('|',[$companyId,$subjectRef,$provider,$providerRef]))];
    }
}
