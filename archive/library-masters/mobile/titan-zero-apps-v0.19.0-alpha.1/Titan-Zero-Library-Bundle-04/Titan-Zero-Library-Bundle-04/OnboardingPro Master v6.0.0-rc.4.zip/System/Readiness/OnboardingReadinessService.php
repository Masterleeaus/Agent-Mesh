<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Readiness;

use App\Extensions\OnboardingPro\System\Persistence\Models\NexusVerificationRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusProvisioningTransaction;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusConfigurationDecision;

final class OnboardingReadinessService
{
 public function check(int $company_id):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $verification=NexusVerificationRecord::query()->where('company_id',$company_id)->latest('id')->first();
  $transaction=NexusProvisioningTransaction::query()->where('company_id',$company_id)->latest('id')->first();
  $decisions=NexusConfigurationDecision::query()->where('company_id',$company_id)->get();

  $required_capabilities=$decisions->map(fn($d)=>(string)$d->capability_key)->values()->all();
  $receipt=(array)($verification?->verification_receipt??[]);
  $verified=array_values(array_map('strval',(array)($receipt['verified_capabilities']??[])));
  $blocking=array_values((array)($receipt['blocking_gaps']??[]));
  $optional_improvements=array_values((array)($receipt['manual_actions']??[]));
  $unverified=array_values(array_diff($required_capabilities,$verified));
  $blockedDecisions=$decisions->filter(fn($d)=>(bool)$d->blocked)->count();
  $reconciliation=(array)($transaction?->checkpoint??[]);
  $transactionCoherent=$transaction!==null && in_array((string)$transaction->status,['completed','reconciled'],true);
  $verificationReady=$verification!==null && (bool)$verification->operational_ready && $blocking===[];

  $operationally_ready=$verificationReady && $transactionCoherent && $blockedDecisions===0 && $unverified===[];

  return [
   'company_id'=>$company_id,
   'operationally_ready'=>$operationally_ready,
   'status'=>$operationally_ready?'OPERATIONALLY_READY':'NOT_READY',
   'required_capabilities'=>[
    'total'=>count($required_capabilities),'verified'=>count(array_intersect($required_capabilities,$verified)),
    'items'=>$required_capabilities,'unverified'=>$unverified,
   ],
   'optional_improvements'=>$optional_improvements,
   'verification'=>[
    'present'=>$verification!==null,'operational_ready'=>$verificationReady,
    'blocking_gaps'=>$blocking,'verified_capabilities'=>$verified,
   ],
   'reconciliation'=>[
    'transaction_status'=>$transaction?->status,'checkpoint'=>$reconciliation,
    'coherent'=>$transactionCoherent,
   ],
   'configuration'=>['blocked_decisions'=>$blockedDecisions],
  ];
 }
}
