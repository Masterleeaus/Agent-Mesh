<?php

declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class EnrolmentRecord extends Model { protected $table='ext_onboarding_enrolments'; protected $guarded=[]; protected $casts=['started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime','expires_at'=>'immutable_datetime']; }
