<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Providers;

/**
 * Compatibility-only evaluator for historical provider-action authority hints.
 *
 * Canonical Titan execution authority belongs to the platform Governance stack.
 * Caller-supplied grants MUST NOT become execution authority. New runtime paths
 * therefore fail closed unless the explicit legacy compatibility switch is on.
 */
final class ProviderAuthorityGate {
 public const READ='READ',DRAFT='DRAFT',PROPOSE='PROPOSE',WRITE='WRITE',PUBLISH='PUBLISH',SPEND='SPEND';

 public function authorize(string $required,array $authority):array {
  if(!$this->legacySelfAssertedAuthorityEnabled()){
   return [
    'allowed'=>false,
    'required'=>$required,
    'decision'=>'awaiting_governance',
    'reason'=>'caller-supplied authority is non-authoritative; platform governance receipt required',
    'compatibility_only'=>false,
   ];
  }

  $grants=array_values(array_unique(array_map('strtoupper',(array)($authority['grants']??[]))));
  $allowed=in_array($required,$grants,true);
  if($required===self::SPEND)$allowed=$allowed && isset($authority['spend_limit']) && (float)$authority['spend_limit']>0;
  return [
   'allowed'=>$allowed,
   'required'=>$required,
   'decision'=>$allowed?'legacy_allow':'fail_closed',
   'reason'=>$allowed?'legacy self-asserted authority compatibility enabled':'required legacy authority absent; fail closed',
   'compatibility_only'=>true,
  ];
 }

 public function legacySelfAssertedAuthorityEnabled():bool {
  return (bool) config('onboarding-pro.provider_actions.legacy_self_asserted_authority_enabled',false);
 }
}
