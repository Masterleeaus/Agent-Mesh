<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Agents;
final readonly class AgentTask{public function __construct(public string $role,public int $companyId,public string $subjectRef,public string $capability,public string $status,public bool $directMutation,public array $payload,public string $idempotencyKey,public string $traceId){}}
