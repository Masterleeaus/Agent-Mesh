<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Evidence\EvidenceRecord;
use DateTimeImmutable;

final class AssuranceEvidenceAdapter
{
    public function toEvidenceRegistryPayload(EvidenceRecord $evidence, ?DateTimeImmutable $now = null): array
    {
        $now ??= new DateTimeImmutable('now');
        $ageSeconds = max(0, $now->getTimestamp() - $evidence->capturedAt->getTimestamp());
        $freshness = $evidence->expiresAt !== null && $evidence->expiresAt <= $now ? 0.0 : max(0.0, 1.0 - min(1.0, $ageSeconds / 31536000));
        return [
            'evidence_id' => $evidence->evidenceId,
            'evidence_type' => $evidence->evidenceType,
            'subject' => ['type' => $evidence->subjectType, 'id' => $evidence->subjectId, 'company_id' => $evidence->companyId],
            'source' => $evidence->source,
            'provenance' => $evidence->provenance,
            'captured_at' => $evidence->capturedAt->format(DATE_ATOM),
            'effective_at' => $evidence->effectiveAt?->format(DATE_ATOM),
            'expires_at' => $evidence->expiresAt?->format(DATE_ATOM),
            'freshness' => round($freshness, 6),
            'confidence' => $evidence->confidence,
            'authority' => $evidence->authority,
            'jurisdiction' => $evidence->jurisdiction,
            'classification' => $evidence->classification->value,
            'hash' => $evidence->contentHash,
            'verification_state' => $evidence->verificationState,
        ];
    }
}
