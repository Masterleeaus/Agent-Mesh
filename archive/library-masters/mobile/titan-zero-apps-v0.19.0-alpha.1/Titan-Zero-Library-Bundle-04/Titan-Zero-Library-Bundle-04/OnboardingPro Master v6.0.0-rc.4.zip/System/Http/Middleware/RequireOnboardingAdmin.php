<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class RequireOnboardingAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_unless($user, 401);

        $allowed = false;
        if (method_exists($user, 'isAdmin')) {
            $allowed = (bool) $user->isAdmin();
        }
        if (! $allowed && property_exists($user, 'is_admin')) {
            $allowed = (bool) $user->is_admin;
        }
        if (! $allowed) {
            $type = strtolower((string) ($user->type ?? ''));
            $role = strtolower((string) ($user->role ?? ''));
            $allowed = in_array($type, ['admin', 'super_admin', 'superadmin'], true)
                || in_array($role, ['admin', 'super_admin', 'superadmin'], true);
        }

        abort_unless($allowed, 403);

        return $next($request);
    }
}
