<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Enrolment;
final readonly class Enrolment
{
    public function __construct(
        public string $id, public int $companyId, public string $journeyKey, public string $journeyVersionId,
        public string $subjectType, public string $subjectId, public string $status, public \DateTimeImmutable $startedAt
    ){
        if($id===''||$companyId<=0||$journeyKey===''||$journeyVersionId===''||$subjectType===''||$subjectId==='') throw new \InvalidArgumentException('Enrolment identity is incomplete.');
    }
}
