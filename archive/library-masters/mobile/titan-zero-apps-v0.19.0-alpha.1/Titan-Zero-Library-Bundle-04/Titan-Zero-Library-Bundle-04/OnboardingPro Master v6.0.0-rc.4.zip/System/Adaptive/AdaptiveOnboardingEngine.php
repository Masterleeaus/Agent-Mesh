<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Adaptive;

final readonly class AdaptiveOnboardingEngine
{
    public const SURFACES=['chat','voice','vision','pwa'];

    public function __construct(
        private AdaptiveQuestionCatalog $catalog,
        private BusinessKnowledgeGapResolver $gaps,
        private InformationGainScorer $scorer,
    ) {}

    /**
     * @param array<string,mixed> $knownFacts
     * @param list<string> $answered
     * @param list<string> $deferred
     * @return array<string,mixed>
     */
    public function next(
        array $knownFacts,
        array $answered=[],
        array $deferred=[],
        ?string $vertical=null,
        ?string $countryCode=null,
        string $surface='pwa',
    ): array {
        $surface=strtolower(trim($surface));
        if (!in_array($surface,self::SURFACES,true)) throw new \InvalidArgumentException('Unsupported onboarding surface.');

        $unresolved=$this->gaps->unresolved($knownFacts,$this->catalog->all(),$answered,$deferred,$vertical,$countryCode);
        $ready=array_values(array_filter($unresolved,static fn(array $q): bool => (bool)($q['dependencies_met']??false)));

        $ranked=[];
        foreach ($ready as $question) {
            $ranked[]=['question'=>$question,'ranking'=>$this->scorer->score($question,$knownFacts)];
        }
        usort($ranked,static fn(array $a,array $b): int =>
            $b['ranking']['score'] <=> $a['ranking']['score']
            ?: strcmp((string)$a['question']['key'],(string)$b['question']['key'])
        );

        $selected=$ranked[0]??null;
        return [
            'surface'=>$surface,
            'selection_strategy'=>'information_gain',
            'supported_surfaces'=>self::SURFACES,
            'questions_remaining'=>count($unresolved),
            'askable_questions_remaining'=>count($ready),
            'deferred'=>array_values($deferred),
            'complete'=>$unresolved===[],
            'blocked_by_dependencies'=>$unresolved!==[] && $ready===[],
            'question'=>$selected===null?null:array_merge($selected['question'],[
                'ranking'=>$selected['ranking'],
            ]),
        ];
    }

    /**
     * Simulates an answer before persistence so the UI can truthfully say how
     * many related questions/facts were resolved by that answer.
     *
     * @return array<string,mixed>
     */
    public function applyAnswer(
        array $knownFacts,
        string $questionKey,
        mixed $answer,
        string $answerState='answered',
        array $answered=[],
        array $deferred=[],
        ?string $vertical=null,
        ?string $countryCode=null,
        string $surface='pwa',
    ): array {
        $question=$this->catalog->find($questionKey);
        if ($question===null) throw new \InvalidArgumentException('Unknown adaptive onboarding question.');

        $before=$this->next($knownFacts,$answered,$deferred,$vertical,$countryCode,$surface);
        if ($answerState==='deferred') {
            $deferred[]= $questionKey;
            $after=$this->next($knownFacts,$answered,array_values(array_unique($deferred)),$vertical,$countryCode,$surface);
            return ['answer_state'=>'deferred','derived_facts'=>[],'resolved_by_answer'=>0,'before'=>$before,'after'=>$after];
        }
        if ($answerState==='not_sure') {
            $answered[]= $questionKey;
            $after=$this->next($knownFacts,array_values(array_unique($answered)),$deferred,$vertical,$countryCode,$surface);
            return ['answer_state'=>'not_sure','derived_facts'=>[],'resolved_by_answer'=>0,'before'=>$before,'after'=>$after];
        }
        if ($answerState!=='answered') throw new \InvalidArgumentException('answerState must be answered, not_sure or deferred.');

        $derived=$this->deriveFacts($question,$answer);
        $simulated=array_replace($knownFacts,$derived);
        $answered[]= $questionKey;
        $after=$this->next($simulated,array_values(array_unique($answered)),$deferred,$vertical,$countryCode,$surface);

        return [
            'answer_state'=>'answered',
            'derived_facts'=>$derived,
            'resolved_by_answer'=>max(0,(int)$before['questions_remaining']-(int)$after['questions_remaining']),
            'before'=>$before,
            'after'=>$after,
        ];
    }

    /** @return array<string,mixed> */
    private function deriveFacts(array $question,mixed $answer): array
    {
        $target=(string)$question['target_fact'];
        $resolves=array_values((array)($question['resolves']??[$target]));
        $facts=[];

        if (is_array($answer)) {
            foreach ($resolves as $factKey) {
                if (array_key_exists((string)$factKey,$answer)) $facts[(string)$factKey]=$answer[(string)$factKey];
            }
        }
        if (!array_key_exists($target,$facts)) $facts[$target]=$answer;

        return $facts;
    }
}
