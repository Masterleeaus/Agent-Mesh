<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
final class JourneyLibraryService
{
    public function filter(array $rows,?string $status=null,?string $audience=null,?string $query=null): array
    {
        $out=array_values(array_filter($rows,static function(array $row)use($status,$audience,$query):bool{
            if($status!==null&&($row['status']??null)!==$status)return false;
            if($audience!==null&&($row['audience']??null)!==$audience)return false;
            if($query!==null&&$query!==''&&!str_contains(strtolower((string)($row['key']??'').' '.(string)($row['name']??'')),strtolower($query)))return false;
            return true;
        }));
        usort($out,static fn(array $a,array $b):int=>strcmp((string)($a['key']??''),(string)($b['key']??'')));
        return $out;
    }
}
