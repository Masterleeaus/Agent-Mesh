<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class BusinessOpportunity extends Model
{
    protected $table='ext_onboarding_business_opportunities';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer','audit_id'=>'integer','confidence'=>'integer',
        'observation_ids'=>'array','recommended_action'=>'array','growth_handoff'=>'array','dismissed'=>'boolean',
        'evidence'=>'array','expected_benefit'=>'array','estimated_effort'=>'array','estimated_cost'=>'array',
        'risk'=>'array','dependencies'=>'array','measurement'=>'array','intervention'=>'array','active'=>'boolean',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
