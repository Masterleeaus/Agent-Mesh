<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Notifications;
final class OnboardingNotificationService{public function __construct(private ?NotificationPreferenceResolver $prefs=null){$this->prefs??=new NotificationPreferenceResolver();}public function prepare(int $tenant,string $recipient,string $type,string $body,string $channel,string $trace):OnboardingNotification{$channel=$this->prefs->resolve($channel);$key=hash('sha256',implode('|',[$tenant,$recipient,$type,$body,$channel]));return new OnboardingNotification($tenant,$recipient,$type,$body,$channel,'message.prepare','PREPARED',$key,$trace);}}
