<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusExecutionRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusVerificationRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
final readonly class NexusProvisioningVerificationService{
 public function __construct(private NexusRuntimeGatewayInterface $gateway){}
 public function verify(NexusExecutionRecord $execution,OnboardingTraceContext $trace):array{
  if((int)$execution->company_id!==$trace->companyId)throw new \RuntimeException('Cross-company provisioning verification denied.');
  $execution_receipt=(array)$execution->execution_receipt;if($execution_receipt===[])throw new \RuntimeException('Execution receipt required for verification.');
  $result=$this->gateway->verifyProvisioning($execution_receipt);
  if(isset($result['company_id'])&&(int)$result['company_id']!==$trace->companyId)throw new \RuntimeException('Cross-company verification receipt denied.');
  $blocking_gaps=array_values((array)($result['blocking_gaps']??[]));$manual_actions=array_values((array)($result['manual_actions']??[]));$verified_capabilities=array_values((array)($result['verified_capabilities']??[]));
  $operational_ready=(bool)($result['operational_ready']??false)&&$blocking_gaps===[];
  $receipt=['schema'=>'titan.onboarding-provisioning-verification','version'=>'1.0','company_id'=>$trace->companyId,'execution_id'=>(int)$execution->id,'operational_ready'=>$operational_ready,'blocking_gaps'=>$blocking_gaps,'manual_actions'=>$manual_actions,'verified_capabilities'=>$verified_capabilities,'nexus_receipt'=>$result];
  $fingerprint=hash('sha256',json_encode($receipt,JSON_THROW_ON_ERROR));
  $existing=NexusVerificationRecord::query()->where('company_id',$trace->companyId)->where('verification_fingerprint',$fingerprint)->first();if(!$existing)NexusVerificationRecord::query()->create(['company_id'=>$trace->companyId,'execution_id'=>(int)$execution->id,'verification_fingerprint'=>$fingerprint,'operational_ready'=>$operational_ready,'verification_receipt'=>$receipt,'trace_id'=>$trace->traceId,'correlation_id'=>$trace->correlationId]);
  return $receipt;
 }
}
