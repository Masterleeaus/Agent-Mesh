<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class BusinessPresenceAudit extends Model
{
    protected $table='ext_onboarding_presence_audits';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'presence_score'=>'integer',
        'observation_ids'=>'array',
        'summary'=>'array',
        'methodology'=>'array',
        'audited_at'=>'immutable_datetime',
    ];
}
