<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Presence;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessPresenceObservation;

final class BusinessOpportunityService
{
    /**
     * Opportunities are reasoned recommendations, never observations.
     * Each recommendation retains the observations that justify it.
     *
     * @param iterable<BusinessPresenceObservation> $observations
     * @return list<BusinessOpportunity>
     */
    public function derive(int $company_id,int $auditId,iterable $observations): array
    {
        if($company_id<=0||$auditId<=0) throw new \RuntimeException('company_id and audit id required.');

        $byCode=[];
        foreach($observations as $observation){
            if((int)$observation->company_id!==$company_id||(int)$observation->audit_id!==$auditId){
                throw new \RuntimeException('Cross-company or cross-audit observation denied.');
            }
            $byCode[(string)$observation->observation_code]=$observation;
        }

        $rules=[
            'ONLINE_BOOKING_MISSING'=>[
                'opportunity'=>'online_booking',
                'title'=>'Make online booking easier',
                'recommended_action'=>['type'=>'growth_recommendation','action'=>'review_online_booking_path'],
                'growth_handoff'=>['manager'=>'growth','capability'=>'digital_presence','execution_requires_separate_approval'=>true],
            ],
            'QUOTE_REQUEST_HARD_TO_FIND'=>[
                'opportunity'=>'quote_conversion',
                'title'=>'Improve quote-request visibility',
                'recommended_action'=>['type'=>'growth_recommendation','action'=>'review_quote_request_visibility'],
                'growth_handoff'=>['manager'=>'growth','capability'=>'conversion','execution_requires_separate_approval'=>true],
            ],
            'SERVICE_COVERAGE_INCOMPLETE'=>[
                'opportunity'=>'service_coverage',
                'title'=>'Represent more current services online',
                'recommended_action'=>['type'=>'growth_recommendation','action'=>'review_missing_service_pages'],
                'growth_handoff'=>['manager'=>'growth','capability'=>'service_coverage','execution_requires_separate_approval'=>true],
            ],
            'BUSINESS_HOURS_INCONSISTENT'=>[
                'opportunity'=>'listing_consistency',
                'title'=>'Resolve inconsistent business hours',
                'recommended_action'=>['type'=>'growth_recommendation','action'=>'review_listing_hours'],
                'growth_handoff'=>['manager'=>'growth','capability'=>'listing_consistency','execution_requires_separate_approval'=>true],
            ],
            'SOCIAL_CHANNEL_MISSING'=>[
                'opportunity'=>'channel_presence',
                'title'=>'Review whether a missing social channel matters',
                'recommended_action'=>['type'=>'growth_recommendation','action'=>'assess_social_channel_fit'],
                'growth_handoff'=>['manager'=>'growth','capability'=>'channel_presence','execution_requires_separate_approval'=>true],
            ],
        ];

        $out=[];
        foreach($rules as $code=>$rule){
            $observation=$byCode[$code]??null;
            if(!$observation) continue;
            $out[]=BusinessOpportunity::query()->create([
                'company_id'=>$company_id,
                'audit_id'=>$auditId,
                'opportunity_key'=>$rule['opportunity'],
                'title'=>$rule['title'],
                'status'=>'recommended',
                'confidence'=>(int)$observation->confidence,
                'observation_ids'=>[$observation->id],
                'recommended_action'=>$rule['recommended_action'],
                'growth_handoff'=>$rule['growth_handoff'],
                'dismissed'=>false,
            ]);
        }
        return $out;
    }
}
