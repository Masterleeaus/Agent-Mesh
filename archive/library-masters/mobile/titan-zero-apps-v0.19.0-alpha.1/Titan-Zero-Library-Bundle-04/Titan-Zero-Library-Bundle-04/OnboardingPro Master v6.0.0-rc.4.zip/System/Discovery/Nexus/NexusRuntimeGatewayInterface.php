<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

interface NexusRuntimeGatewayInterface
{
    /** @return array<string,mixed> */
    public function newDraft(array $canonicalIntent): array;
    /** @return array<string,mixed> */
    public function validateDraft(array $draftReceipt): array;
    /** @return array<string,mixed> */
    public function previewDraft(array $draftReceipt): array;
    public function compileDraft(array $draftReceipt): array;
    public function planProvisioning(array $compiledReceipt): array;
    public function executeProvisioning(array $planReceipt, string $idempotencyKey): array;
    public function verifyProvisioning(array $executionReceipt): array;
}
