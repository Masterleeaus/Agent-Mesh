<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Agents;
class OnboardingManager{public function planReminder(int $tenant,string $enrolment,string $participant,string $reason,string $trace):AgentTask{$payload=['enrolment'=>$enrolment,'participant'=>$participant,'reason'=>$reason,'approval_policy'=>'capability_governed'];$key=hash('sha256',implode('|',[$tenant,$enrolment,$participant,$reason]));return new AgentTask('onboarding_manager',$tenant,$participant,'message.prepare','PREPARED',false,$payload,$key,$trace);}}
