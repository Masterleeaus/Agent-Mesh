<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Persistence\Models\DiscoveryProfileRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

final class DiscoveryProfileRepository
{
    public function latest(int $companyId): ?DiscoveryProfileRecord
    {
        $this->assertCompanyId($companyId);

        return DiscoveryProfileRecord::query()
            ->where('company_id', $companyId)
            ->orderByDesc('revision')
            ->first();
    }

    public function findRevision(int $companyId, int $revision): ?DiscoveryProfileRecord
    {
        $this->assertCompanyId($companyId);
        if ($revision <= 0) {
            throw new \InvalidArgumentException('Discovery profile revision must be positive.');
        }

        return DiscoveryProfileRecord::query()
            ->where('company_id', $companyId)
            ->where('revision', $revision)
            ->first();
    }

    public function saveRevision(
        int $companyId,
        array $profilePayload,
        string $status,
        bool $minimumReady,
        bool $operationalReady,
        array $remainingDomains,
        OnboardingTraceContext $trace,
        ?int $expectedRevision = null,
    ): DiscoveryProfileRecord {
        $this->assertCompanyId($companyId);
        if ($trace->companyId !== $companyId) {
            throw new \RuntimeException('Cross-company discovery profile persistence denied.');
        }
        if ($expectedRevision !== null && $expectedRevision < 0) {
            throw new \InvalidArgumentException('Expected discovery profile revision cannot be negative.');
        }

        $status = strtoupper(trim($status));
        if (!in_array($status, ['DISCOVERING', 'MINIMUM_READY', 'OPERATIONAL_READY'], true)) {
            throw new \InvalidArgumentException('Unsupported discovery profile status.');
        }

        $profileHash = DiscoveryProfileFingerprint::forPayload($profilePayload);
        $remainingDomains = array_values(array_unique(array_map(
            static fn (mixed $domain): string => trim((string) $domain),
            $remainingDomains,
        )));
        $remainingDomains = array_values(array_filter($remainingDomains, static fn (string $domain): bool => $domain !== ''));

        for ($attempt = 1; $attempt <= 3; $attempt++) {
            try {
                return DB::transaction(function () use (
                    $companyId,
                    $profilePayload,
                    $status,
                    $minimumReady,
                    $operationalReady,
                    $remainingDomains,
                    $trace,
                    $expectedRevision,
                    $profileHash,
                ): DiscoveryProfileRecord {
                    /** @var DiscoveryProfileRecord|null $latest */
                    $latest = DiscoveryProfileRecord::query()
                        ->where('company_id', $companyId)
                        ->orderByDesc('revision')
                        ->lockForUpdate()
                        ->first();

                    if ($latest !== null && $this->isSameState(
                        $latest,
                        $profileHash,
                        $status,
                        $minimumReady,
                        $operationalReady,
                        $remainingDomains,
                    )) {
                        return $latest;
                    }

                    $latestRevision = $latest?->revision ?? 0;
                    if ($latest !== null && $expectedRevision === null) {
                        throw new DiscoveryProfileConcurrencyException(
                            'Expected revision is required when changing an existing discovery profile.'
                        );
                    }
                    if ($expectedRevision !== null && $expectedRevision !== $latestRevision) {
                        throw new DiscoveryProfileConcurrencyException(sprintf(
                            'Discovery profile revision conflict: expected %d, latest is %d.',
                            $expectedRevision,
                            $latestRevision,
                        ));
                    }

                    return DiscoveryProfileRecord::query()->create([
                        'company_id' => $companyId,
                        'revision' => $latestRevision + 1,
                        'status' => $status,
                        'profile_payload' => $profilePayload,
                        'profile_hash' => $profileHash,
                        'minimum_ready' => $minimumReady,
                        'operational_ready' => $operationalReady,
                        'remaining_domains' => $remainingDomains,
                        'trace_id' => $trace->traceId,
                        'correlation_id' => $trace->correlationId,
                        'causation_id' => $trace->causationId,
                        'updated_by_actor_id' => (string) $trace->actorId,
                    ]);
                }, 3);
            } catch (QueryException $exception) {
                if (!$this->isUniqueConstraintViolation($exception) || $attempt === 3) {
                    throw $exception;
                }
            }
        }

        throw new \RuntimeException('Unable to persist discovery profile revision after concurrency retries.');
    }

    private function isSameState(
        DiscoveryProfileRecord $record,
        string $profileHash,
        string $status,
        bool $minimumReady,
        bool $operationalReady,
        array $remainingDomains,
    ): bool {
        return hash_equals((string) $record->profile_hash, $profileHash)
            && (string) $record->status === $status
            && (bool) $record->minimum_ready === $minimumReady
            && (bool) $record->operational_ready === $operationalReady
            && array_values((array) $record->remaining_domains) === $remainingDomains;
    }

    private function isUniqueConstraintViolation(QueryException $exception): bool
    {
        $sqlState = (string) ($exception->errorInfo[0] ?? $exception->getCode());
        if ($sqlState === '23000' || $sqlState === '23505') {
            return true;
        }

        return str_contains(strtolower($exception->getMessage()), 'duplicate')
            || str_contains(strtolower($exception->getMessage()), 'unique constraint');
    }

    private function assertCompanyId(int $companyId): void
    {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Company ID must be positive.');
        }
    }
}
