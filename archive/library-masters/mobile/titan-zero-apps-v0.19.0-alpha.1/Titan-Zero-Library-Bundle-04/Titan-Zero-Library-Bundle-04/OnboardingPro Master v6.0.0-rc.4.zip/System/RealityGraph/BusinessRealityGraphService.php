<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\RealityGraph;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessRealityNode;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessRealityEdge;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessRealityFact;

final class BusinessRealityGraphService
{
 public const NODE_TYPES=['business','location','service','price','person','customer','channel','website','listing','social_account','marketplace','competitor','service_area','review_surface','booking_route','quote_route','provider','operating_capability'];

 public function upsertNode(int $company_id,string $type,string $externalKey,array $attributes=[]):BusinessRealityNode
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  if(!in_array($type,self::NODE_TYPES,true))throw new \InvalidArgumentException('Unsupported reality node type.');
  return BusinessRealityNode::query()->updateOrCreate(
   ['company_id'=>$company_id,'node_type'=>$type,'external_key'=>$externalKey],
   ['attributes'=>$attributes,'active'=>true,'last_observed_at'=>now(),'first_observed_at'=>now()]
  );
 }

 public function connect(int $company_id,BusinessRealityNode $from,BusinessRealityNode $to,string $relationship,array $evidence=[],int $confidence=100):BusinessRealityEdge
 {
  if((int)$from->company_id!==$company_id||(int)$to->company_id!==$company_id)throw new \RuntimeException('Cross-company graph edge denied.');
  return BusinessRealityEdge::query()->updateOrCreate(
   ['company_id'=>$company_id,'from_node_id'=>$from->id,'to_node_id'=>$to->id,'relationship'=>$relationship],
   ['evidence'=>$evidence,'confidence'=>max(0,min(100,$confidence)),'active'=>true]
  );
 }

 public function snapshot(int $company_id):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  return [
   'company_id'=>$company_id,
   'nodes'=>BusinessRealityNode::query()->where('company_id',$company_id)->where('active',true)->get(),
   'edges'=>BusinessRealityEdge::query()->where('company_id',$company_id)->where('active',true)->get(),
   'facts'=>BusinessRealityFact::query()->where('company_id',$company_id)->whereNotIn('state',['SUPERSEDED'])->get(),
  ];
 }
}
