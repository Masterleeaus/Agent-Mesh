<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Competition;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessCompetitor;
use App\Extensions\OnboardingPro\System\Persistence\Models\CompetitiveBenchmarkRun;
use App\Extensions\OnboardingPro\System\Persistence\Models\CompetitiveBenchmarkMetric;

final readonly class CompetitiveBenchmarkingService
{
 public const DIMENSIONS=['website','service_representation','local_search','reviews','review_velocity','review_response','social','booking','quote','service_area','content','marketplace','advertising','trust','contact_accessibility','listing_consistency'];
 public function __construct(private MarketPatternService $patterns){}

 public function run(int $company_id,array $businessMetrics,array $competitorMetrics):CompetitiveBenchmarkRun
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $allowed=BusinessCompetitor::query()->where('company_id',$company_id)->where('ignored',false)->where('classification','!=','NOT_COMPETITOR')->pluck('id')->map(fn($v)=>(int)$v)->all();
  $cohort=array_values(array_filter($competitorMetrics,fn($row)=>is_array($row)&&in_array((int)($row['competitor_id']??0),$allowed,true)));
  $run=CompetitiveBenchmarkRun::query()->create(['company_id'=>$company_id,'status'=>'running','cohort_size'=>count($cohort),'started_at'=>now()]);
  $meaningful=0;
  foreach(self::DIMENSIONS as $metric){
   if(!array_key_exists($metric,$businessMetrics))continue;
   $values=[];$evidence=[];
   foreach($cohort as $row){if(array_key_exists($metric,$row))$values[]=$row[$metric];if(isset($row['evidence'][$metric]))$evidence[]=$row['evidence'][$metric];}
   $analysis=$this->patterns->analyse($metric,$businessMetrics[$metric],$values,$evidence);
   if($analysis['meaningful'])$meaningful++;
   CompetitiveBenchmarkMetric::query()->create([
    'company_id'=>$company_id,'benchmark_run_id'=>$run->id,'metric_key'=>$metric,
    'business_value'=>$analysis['business_value'],'cohort_median'=>$analysis['cohort_median'],
    'cohort_prevalence'=>$analysis['prevalence'],'deviation'=>$analysis['deviation'],
    'confidence'=>$analysis['confidence'],'meaningful'=>$analysis['meaningful'],'evidence'=>$analysis['evidence'],
   ]);
  }
  $run->status='complete';$run->summary=['meaningful_patterns'=>$meaningful,'principle'=>'Market prevalence is evidence, not an instruction to copy competitors.'];$run->completed_at=now();$run->save();return $run;
 }
}
