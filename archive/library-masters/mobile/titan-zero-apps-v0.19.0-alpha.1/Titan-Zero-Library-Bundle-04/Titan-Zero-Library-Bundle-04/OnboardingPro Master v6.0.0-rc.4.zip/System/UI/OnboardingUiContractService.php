<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\UI;

final class OnboardingUiContractService
{
 public function contract():array
 {
  return [
   'version'=>'5.0',
   'production_stages'=>['discover','verify','complete','configure','launch'],
   'principle'=>'Titan learns first; owner verifies second; Titan asks questions last.',
   'screens'=>[
    ['id'=>1,'key'=>'welcome','stage'=>'discover','skip_when'=>null],
    ['id'=>2,'key'=>'account','stage'=>'discover','skip_when'=>'authenticated'],
    ['id'=>3,'key'=>'meet_business','stage'=>'discover','skip_when'=>'business_identity_known'],
    ['id'=>4,'key'=>'permissions','stage'=>'discover','skip_when'=>'discovery_permissions_already_decided'],
    ['id'=>5,'key'=>'finding_business','stage'=>'discover','skip_when'=>'no_discovery_sources_authorised'],
    ['id'=>6,'key'=>'business_match','stage'=>'verify','skip_when'=>'business_identity_owner_confirmed'],
    ['id'=>7,'key'=>'offline_artifacts','stage'=>'complete','skip_when'=>'no_additional_artifacts_needed'],
    ['id'=>8,'key'=>'existing_systems','stage'=>'complete','skip_when'=>'no_existing_systems'],
    ['id'=>9,'key'=>'learning','stage'=>'discover','skip_when'=>'discovery_already_compiled'],
    ['id'=>10,'key'=>'findings','stage'=>'verify','skip_when'=>'no_findings_require_owner_review'],
    ['id'=>11,'key'=>'conflicts','stage'=>'verify','skip_when'=>'no_conflicts'],
    ['id'=>12,'key'=>'digital_presence','stage'=>'verify','skip_when'=>'presence_audit_unavailable'],
    ['id'=>13,'key'=>'remaining_questions','stage'=>'complete','skip_when'=>'no_unresolved_required_questions'],
    ['id'=>14,'key'=>'autonomy','stage'=>'configure','skip_when'=>'autonomy_policy_already_confirmed'],
    ['id'=>15,'key'=>'management_team','stage'=>'configure','skip_when'=>'management_map_unchanged'],
    ['id'=>16,'key'=>'recommended_setup','stage'=>'configure','skip_when'=>'no_configuration_recommendations'],
    ['id'=>17,'key'=>'still_needed','stage'=>'complete','skip_when'=>'no_required_blockers'],
    ['id'=>18,'key'=>'configuration_preview','stage'=>'configure','skip_when'=>null],
    ['id'=>19,'key'=>'review_approve','stage'=>'configure','skip_when'=>null],
    ['id'=>20,'key'=>'provisioning','stage'=>'launch','skip_when'=>'already_provisioned_and_reconciled'],
    ['id'=>21,'key'=>'readiness','stage'=>'launch','skip_when'=>null],
    ['id'=>22,'key'=>'ready','stage'=>'launch','skip_when'=>'not_operationally_ready'],
   ],
   'status_semantics'=>[
    'success'=>['icon'=>'check','label_required'=>true],
    'warning'=>['icon'=>'warning','label_required'=>true],
    'error'=>['icon'=>'error','label_required'=>true],
    'status_not_colour_only'=>true,
   ],
   'accessibility'=>[
    'screen_reader'=>true,'reduced_motion'=>true,'keyboard_navigation'=>true,
    'touch_target'=>['minimum_css_px'=>44],'text_scaling'=>true,'visible_focus'=>true,
    'contrast'=>'WCAG_AA_or_better',
   ],
   'permission_model'=>[
    'internet_discovery'=>'independent','business_files'=>'independent','existing_systems'=>'independent',
   ],
   'truth_model'=>['observations'=>'evidence_backed','scores'=>'analytical','recommendations'=>'reasoned_not_fact'],
  ];
 }
}
