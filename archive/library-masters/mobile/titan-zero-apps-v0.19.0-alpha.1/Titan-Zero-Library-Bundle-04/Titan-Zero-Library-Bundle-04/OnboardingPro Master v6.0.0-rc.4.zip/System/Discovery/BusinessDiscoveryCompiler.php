<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use DateTimeZone;

final class BusinessDiscoveryCompiler
{
    public function compileNexusProvisioningIntent(
        BusinessDiscoveryProfile $profile,
        OnboardingTraceContext $trace,
        VerticalResolution $verticalResolution,
        int $profileRevision,
    ): NexusProvisioningIntent {
        $gaps = $this->nexusContractGaps($profile, $trace, $verticalResolution, $profileRevision);
        if ($gaps !== []) {
            throw new \RuntimeException('Canonical Nexus provisioning contract is incomplete: '.implode(', ', $gaps));
        }

        $capabilities = $this->capabilityRequirements($profile);
        $jurisdiction = $this->canonicalJurisdiction($profile->jurisdiction);
        $jurisdictionCode = $jurisdiction['country_code'].(isset($jurisdiction['region']) ? '-'.$jurisdiction['region'] : '');
        $configurationGaps = [];
        if ($profile->serviceAreas === []) $configurationGaps[] = 'service_areas';
        if ($profile->communicationChannels === []) $configurationGaps[] = 'communication_channels';
        if ($profile->jobLifecycle === []) $configurationGaps[] = 'job_lifecycle';

        $verticalReference = array_filter([
            'vertical_id' => $verticalResolution->verticalId,
            'vertical_version' => $verticalResolution->verticalVersion,
            'definition_hash' => $verticalResolution->definitionHash,
            'resolution_request_hash' => $verticalResolution->requestHash,
            'confidence' => $verticalResolution->confidence,
            'secondary_verticals' => $verticalResolution->secondaryVerticals,
            'engine_receipt_id' => $verticalResolution->engineReceiptId,
        ], static fn (mixed $value): bool => $value !== null);

        return new NexusProvisioningIntent(
            companyId: $trace->companyId,
            discoveryProfileRevision: $profileRevision,
            discoveryProfileVersion: 'discovery-r'.$profileRevision,
            verticalReference: $verticalReference,
            jurisdiction: $jurisdiction,
            timezone: trim($profile->timezone),
            businessRequirements: [
                'business_identity' => $profile->businessIdentity,
                'industry_signal' => $profile->industry,
                'services' => array_values($profile->services),
                'service_areas' => array_values($profile->serviceAreas),
                'business_size' => $profile->size,
                'operating_complexity' => $this->operatingComplexity($profile),
                'staff' => $profile->staff,
                'operating_hours' => $profile->operatingHours,
                'pricing_approach' => $profile->pricingApproach,
                'communication_channels' => array_values($profile->communicationChannels),
                'payment_methods' => array_values($profile->paymentMethods),
                'equipment_assets' => array_values($profile->equipmentAssets),
                'privacy_preferences' => $profile->privacyPreferences,
            ],
            capabilityRequirements: $capabilities,
            workflowRequirements: $this->normaliseStringList($profile->jobLifecycle),
            workforceRequirements: [
                'staff_context' => $profile->staff,
                'responsibility_families' => array_values(array_unique(array_filter([
                    'operations',
                    in_array('scheduling', $capabilities, true) ? 'scheduling' : null,
                    in_array('billing', $capabilities, true) ? 'billing' : null,
                    in_array('communications', $capabilities, true) ? 'customer_communications' : null,
                    in_array('compliance', $capabilities, true) ? 'compliance' : null,
                ]))),
                'direct_create' => false,
            ],
            knowledgeRequirements: array_values(array_unique(array_filter([
                $jurisdictionCode,
                ...$this->normaliseStringList($profile->complianceRequirements),
            ]))),
            surfaceRequirements: ['titan-zero','titan-go','titan-hub'],
            integrationRequirements: [],
            complianceRequirements: $this->normaliseStringList($profile->complianceRequirements),
            aiPreferences: $profile->aiProviderPreferences,
            autonomyPreferences: $profile->autonomyPreferences,
            riskPreferences: $profile->riskTolerance,
            configurationGaps: $configurationGaps,
            traceContext: $trace->toArray(),
        );
    }

    /** @return list<string> */
    public function nexusContractGaps(
        BusinessDiscoveryProfile $profile,
        OnboardingTraceContext $trace,
        ?VerticalResolution $verticalResolution,
        int $profileRevision,
    ): array {
        $gaps = [];
        if ($profileRevision <= 0) $gaps[] = 'discovery_profile_revision';
        if ($verticalResolution === null || !$verticalResolution->isResolved()) {
            $gaps[] = 'canonical_vertical';
        } else {
            if ($verticalResolution->companyId !== $trace->companyId) {
                $gaps[] = 'vertical_resolution_company_id';
            }
            try {
                $expectedRequest = VerticalCandidateRequest::fromProfile($profile, $profileRevision, $trace)->fingerprint();
                if (!hash_equals($expectedRequest, $verticalResolution->requestHash)) {
                    $gaps[] = 'vertical_resolution_stale';
                }
            } catch (\Throwable) {
                $gaps[] = 'vertical_resolution_stale';
            }
            if (trim((string) $verticalResolution->verticalId) === '') $gaps[] = 'vertical_id';
            if (trim((string) $verticalResolution->verticalVersion) === '') $gaps[] = 'vertical_version';
        }
        try {
            $this->canonicalJurisdiction($profile->jurisdiction);
        } catch (\Throwable) {
            $gaps[] = 'jurisdiction';
        }
        $timezone = trim($profile->timezone);
        if ($timezone === '') {
            $gaps[] = 'timezone';
        } else {
            try {
                new DateTimeZone($timezone);
            } catch (\Throwable) {
                $gaps[] = 'timezone';
            }
        }
        return array_values(array_unique($gaps));
    }

    /**
     * Compile non-Nexus bootstrap intents. Nexus is intentionally excluded and
     * must be produced only through compileNexusProvisioningIntent().
     *
     * @return array<string,array<string,mixed>>
     */
    public function compile(BusinessDiscoveryProfile $profile, OnboardingTraceContext $trace, ?VerticalResolution $verticalResolution = null): array
    {
        $t = $trace->toArray();
        $common = [
            'industry' => $profile->industry,
            'services' => $profile->services,
            'jurisdiction' => $profile->jurisdiction,
            'business_size' => $profile->size,
        ];

        return [
            'vertical_candidate_request' => array_merge($t, $common, [
                'service_areas' => $profile->serviceAreas,
                'compliance_requirements' => $profile->complianceRequirements,
                'requested_action' => 'candidate_match',
            ]),
            'workforce_bootstrap_intent' => array_merge($t, $common, [
                'staff_context' => $profile->staff,
                'requested_output' => ['managers','specialists','action_workers','default_responsibilities'],
                'direct_create' => false,
                'authority' => 'Titan AI Workforce / Titan Nexus',
            ]),
            'workflow_bootstrap_intent' => array_merge($t, $common, [
                'job_lifecycle' => $profile->jobLifecycle,
                'requested_output' => ['wizard_ids','playbook_ids','workflow_overlays'],
                'authority' => 'Titan Interaction Engine / Titan Vertical Engine',
            ]),
            'knowledge_bootstrap_intent' => array_merge($t, [
                'jurisdiction' => $profile->jurisdiction,
                'industry' => $profile->industry,
                'services' => $profile->services,
                'compliance_domains' => $profile->complianceRequirements,
                'requested_output' => ['regulator_sources','guide_families','knowledge_scopes'],
                'authority' => 'Titan Knowledge Authority',
            ]),
        ];
    }

    /** @return list<string> */
    private function capabilityRequirements(BusinessDiscoveryProfile $profile): array
    {
        $caps = ['customer_management','job_management'];
        if ($profile->operatingHours !== []) $caps[] = 'scheduling';
        if ($profile->pricingApproach !== '' || $profile->paymentMethods !== []) $caps[] = 'billing';
        if ($profile->communicationChannels !== []) $caps[] = 'communications';
        if ($profile->equipmentAssets !== []) $caps[] = 'asset_management';
        if ($profile->complianceRequirements !== []) $caps[] = 'compliance';
        return array_values(array_unique($caps));
    }

    private function operatingComplexity(BusinessDiscoveryProfile $profile): string
    {
        $complexity = strtoupper(str_replace([' ', '-'], '_', trim($profile->size)));
        $aliases = ['MICRO'=>'SOLO','SMALL'=>'SMALL_TEAM','SMALL_BUSINESS'=>'SMALL_TEAM','MEDIUM'=>'GROWING','LARGE'=>'ENTERPRISE'];
        $complexity = $aliases[$complexity] ?? $complexity;
        if (in_array($complexity, ['SOLO','SMALL_TEAM','GROWING','MULTI_SITE','ENTERPRISE'], true)) {
            return $complexity;
        }
        $staffCount = max(0, (int) ($profile->staff['count'] ?? count((array) ($profile->staff['roles'] ?? []))));
        return $staffCount <= 1 ? 'SOLO' : ($staffCount <= 10 ? 'SMALL_TEAM' : ($staffCount <= 50 ? 'GROWING' : 'ENTERPRISE'));
    }

    /** @return array<string,string> */
    private function canonicalJurisdiction(array $jurisdiction): array
    {
        $country = strtoupper(trim((string) ($jurisdiction['country_code'] ?? $jurisdiction['country'] ?? '')));
        if (preg_match('/^[A-Z]{2}$/', $country) !== 1) {
            throw new \InvalidArgumentException('Canonical Nexus jurisdiction requires a two-letter country code.');
        }
        $result = ['country_code' => $country];
        $region = strtoupper(trim((string) ($jurisdiction['region'] ?? $jurisdiction['state'] ?? '')));
        if ($region !== '') $result['region'] = $region;
        foreach (['locality','postcode'] as $key) {
            $value = trim((string) ($jurisdiction[$key] ?? ''));
            if ($value !== '') $result[$key] = $value;
        }
        return $result;
    }

    /** @return list<string> */
    private function normaliseStringList(array $values): array
    {
        return array_values(array_unique(array_filter(array_map(
            static fn (mixed $value): string => trim((string) $value),
            $values,
        ), static fn (string $value): bool => $value !== '')));
    }
}
