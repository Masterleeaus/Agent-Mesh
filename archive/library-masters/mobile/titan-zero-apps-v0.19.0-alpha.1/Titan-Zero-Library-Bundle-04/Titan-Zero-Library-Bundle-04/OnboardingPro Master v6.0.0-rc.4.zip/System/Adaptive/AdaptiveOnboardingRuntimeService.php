<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Adaptive;

use App\Extensions\OnboardingPro\System\Evidence\EvidenceAuthorityService;
use App\Extensions\OnboardingPro\System\Evidence\CanonicalBusinessFactService;
use App\Extensions\OnboardingPro\System\Persistence\Models\AdaptiveQuestionState;
use App\Extensions\OnboardingPro\System\Persistence\Models\CanonicalBusinessFact;
use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileRepository;

final readonly class AdaptiveOnboardingRuntimeService
{
    public function __construct(
        private AdaptiveOnboardingEngine $engine,
        private EvidenceAuthorityService $evidenceAuthority,
        private CanonicalBusinessFactService $canonicalFacts,
        private DiscoveryProfileRepository $profiles,
    ) {}

    /** @return array<string,mixed> */
    public function next(int $company_id,int $userId,string $surface='pwa',?string $vertical=null,?string $countryCode=null): array
    {
        if($company_id<=0||$userId<=0) throw new \RuntimeException('company_id and authenticated user required.');

        $facts=$this->knownFacts($company_id);
        [$answered,$deferred]=$this->questionStates($company_id,$userId);

        $result=$this->engine->next($facts,$answered,$deferred,$vertical,$countryCode,$surface);
        return array_merge($result,[
            'company_id'=>$company_id,
            'known_fact_count'=>count($facts),
            'adaptive'=>true,
        ]);
    }

    /** @return array<string,mixed> */
    public function answer(
        int $company_id,
        int $userId,
        string $questionKey,
        mixed $answer,
        string $answerState='answered',
        string $surface='pwa',
        ?string $vertical=null,
        ?string $countryCode=null,
    ): array {
        if($company_id<=0||$userId<=0) throw new \RuntimeException('company_id and authenticated user required.');

        $facts=$this->knownFacts($company_id);
        [$answered,$deferred]=$this->questionStates($company_id,$userId);

        $simulation=$this->engine->applyAnswer(
            $facts,$questionKey,$answer,$answerState,$answered,$deferred,$vertical,$countryCode,$surface
        );

        if($answerState==='answered'){
            foreach((array)$simulation['derived_facts'] as $factKey=>$factValue){
                $candidate=$this->evidenceAuthority->assess(
                    $company_id,
                    (string)$factKey,
                    is_array($factValue)?$factValue:['value'=>$factValue],
                    [
                        'source_type'=>'owner_answer',
                        'source_reference'=>'adaptive_question:'.$questionKey,
                        'source_authority'=>100,
                        'freshness'=>100,
                        'confidence'=>100,
                        'independent_sources'=>1,
                        'owner_confirmed'=>true,
                        'sensitivity'=>$this->sensitivityFor((string)$factKey),
                        'observed_at'=>now(),
                    ],
                );
                $this->canonicalFacts->promote($candidate,owner_confirmed:true,verified:false);
            }
        }

        $state=AdaptiveQuestionState::query()->updateOrCreate(
            ['company_id'=>$company_id,'user_id'=>$userId,'question_key'=>$questionKey],
            [
                'status'=>$answerState,
                'surface'=>$surface,
                'answer_payload'=>$answerState==='answered'?(is_array($answer)?$answer:['value'=>$answer]):null,
                'resolved_fact_keys'=>array_keys((array)$simulation['derived_facts']),
                'resolved_by_answer'=>(int)$simulation['resolved_by_answer'],
                'answered_at'=>$answerState==='answered'||$answerState==='not_sure'?now():null,
                'deferred_at'=>$answerState==='deferred'?now():null,
            ],
        );

        return [
            'company_id'=>$company_id,
            'question_key'=>$questionKey,
            'answer_state'=>$answerState,
            'resolved_by_answer'=>(int)$simulation['resolved_by_answer'],
            'resolved_fact_keys'=>array_keys((array)$simulation['derived_facts']),
            'state_id'=>$state->id,
            'next'=>$this->next($company_id,$userId,$surface,$vertical,$countryCode),
        ];
    }

    /** @return array<string,mixed> */
    public function defer(int $company_id,int $userId,string $questionKey,string $surface='pwa',?string $vertical=null,?string $countryCode=null): array
    {
        return $this->answer($company_id,$userId,$questionKey,null,'deferred',$surface,$vertical,$countryCode);
    }

    /** @return array<string,mixed> */
    private function knownFacts(int $company_id): array
    {
        $facts=[];

        // Discovery profile is a provisional working model. It lets the adaptive
        // engine begin from information already gathered during discovery.
        $profile=$this->profiles->latest($company_id);
        if($profile!==null){
            foreach((array)$profile->profile_payload as $key=>$value){
                if($value===null || $value==='' || (is_array($value)&&$value===[])) continue;
                $facts[(string)$key]=$value;
            }
        }

        // Canonical facts always override provisional discovery data.
        $records=CanonicalBusinessFact::query()
            ->where('company_id',$company_id)
            ->where('canonical',true)
            ->orderBy('id')
            ->get();

        foreach($records as $record){
            $value=$record->fact_value;
            if(is_array($value) && array_keys($value)===['value']) $value=$value['value'];
            $facts[(string)$record->fact_key]=$value;
        }
        return $facts;
    }

    /** @return array{0:list<string>,1:list<string>} */
    private function questionStates(int $company_id,int $userId): array
    {
        $answered=[];$deferred=[];
        $states=AdaptiveQuestionState::query()
            ->where('company_id',$company_id)
            ->where('user_id',$userId)
            ->get(['question_key','status']);

        foreach($states as $state){
            if(in_array((string)$state->status,['answered','not_sure'],true)) $answered[]=(string)$state->question_key;
            if((string)$state->status==='deferred') $deferred[]=(string)$state->question_key;
        }
        return [array_values(array_unique($answered)),array_values(array_unique($deferred))];
    }

    private function sensitivityFor(string $factKey): string
    {
        return match($factKey){
            'gst_registered','tax_profile','compliance_requirements'=>'compliance',
            'payment_methods','pricing_approach'=>'financial',
            default=>'normal',
        };
    }
}
