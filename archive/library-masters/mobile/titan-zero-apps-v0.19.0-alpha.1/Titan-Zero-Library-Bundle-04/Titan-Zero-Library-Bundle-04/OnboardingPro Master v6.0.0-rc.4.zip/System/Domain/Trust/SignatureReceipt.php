<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Trust;

use DateTimeImmutable;

final readonly class SignatureReceipt
{
    private function __construct(
        public string $receiptId, public int $companyId, public int $actorId,
        public string $subjectRef, public string $documentVersion, public string $documentHash,
        public string $signatureHash, public DateTimeImmutable $signedAt, public array $provenance,
    ) {}
    public static function issue(string $receiptId,int $companyId,int $actorId,string $subjectRef,string $documentVersion,string $documentHash,string $signatureHash,DateTimeImmutable $signedAt,array $provenance=[]): self
    { return new self($receiptId,$companyId,$actorId,$subjectRef,$documentVersion,strtolower($documentHash),strtolower($signatureHash),$signedAt,$provenance); }
}
