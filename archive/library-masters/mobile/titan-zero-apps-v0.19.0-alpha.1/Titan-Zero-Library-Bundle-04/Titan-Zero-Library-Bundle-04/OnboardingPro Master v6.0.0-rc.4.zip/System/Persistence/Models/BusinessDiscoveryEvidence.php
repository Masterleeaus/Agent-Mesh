<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessDiscoveryEvidence extends Model {protected $table='ext_onboarding_discovery_evidence';protected $guarded=[];protected $casts=['company_id'=>'integer','observed_at'=>'immutable_datetime','evidence_payload'=>'array'];}
