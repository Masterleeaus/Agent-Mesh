<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class NexusProvisioningTransaction extends Model {
 protected $table='ext_onboarding_nexus_provisioning_transactions'; protected $guarded=[];
 protected $casts=['company_id'=>'integer','approval_id'=>'integer','execution_id'=>'integer','checkpoint'=>'array','failure_context'=>'array','recovery_context'=>'array','started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime'];
}
