<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class ProviderActionRequest extends Model{protected $table='ext_onboarding_provider_action_requests';protected $guarded=[];protected $casts=['company_id'=>'integer','nexus_workforce_command_id'=>'integer','payload'=>'array','evidence'=>'array','authority_context'=>'array','requires_approval'=>'boolean','prepared_at'=>'immutable_datetime'];}
