<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Activation;
final class ActivationGate
{
    public function evaluate(array $c):ActivationDecision
    {
        $trigger=strtoupper(preg_replace('/[^A-Za-z0-9]+/','_',trim((string)($c['trigger_type']??'manual'))));
        $reasons=[];
        if($trigger!=='')$reasons[]=$trigger;
        $prov=['trigger_type'=>$c['trigger_type']??'manual','trigger_ref'=>$c['trigger_ref']??null];
        if(($c['tenant_valid']??false)!==true||($c['participant_valid']??false)!==true||($c['journey_valid']??false)!==true||($c['policy_allowed']??false)!==true) return new ActivationDecision('BLOCKED_POLICY',array_merge($reasons,['POLICY_OR_IDENTITY_INVALID']),$prov);
        if(($c['idempotency_seen']??false)===true||($c['duplicate_active']??false)===true) return new ActivationDecision('BLOCKED_DUPLICATE',array_merge($reasons,['DUPLICATE_ACTIVE']),$prov);
        if(($c['prerequisites_met']??false)!==true) return new ActivationDecision('BLOCKED_PREREQUISITE',array_merge($reasons,['PREREQUISITES_UNMET']),$prov);
        if(($c['approval_required']??false)===true&&($c['approval_present']??false)!==true) return new ActivationDecision('PENDING_APPROVAL',array_merge($reasons,['APPROVAL_REQUIRED']),$prov);
        return new ActivationDecision('ACTIVE',array_merge($reasons,['ACTIVATED']),$prov);
    }
}
