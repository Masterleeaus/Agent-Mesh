<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Tenancy;

final readonly class OnboardingCompanyContext
{
    public function __construct(
        public int $companyId,
        public OnboardingActorContext $actor,
    ) {
        if ($this->companyId <= 0) {
            throw new \InvalidArgumentException('Titan Onboarding company ID must be positive.');
        }
    }
}
