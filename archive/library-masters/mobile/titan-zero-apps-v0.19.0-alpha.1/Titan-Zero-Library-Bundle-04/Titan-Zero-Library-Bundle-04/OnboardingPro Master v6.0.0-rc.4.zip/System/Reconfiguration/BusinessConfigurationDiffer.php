<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Reconfiguration;
final class BusinessConfigurationDiffer{
 public function semantic_diff(array $before,array $after):array{
  $added=[];$removed=[];$changed=[];$keys=array_unique(array_merge(array_keys($before),array_keys($after)));sort($keys);
  foreach($keys as $key){$hasBefore=array_key_exists($key,$before);$hasAfter=array_key_exists($key,$after);
   if(!$hasBefore){$added[$key]=$after[$key];continue;}if(!$hasAfter){$removed[$key]=$before[$key];continue;}
   if(is_array($before[$key])&&is_array($after[$key])){$nested=$this->semantic_diff($before[$key],$after[$key]);if($nested['has_changes'])$changed[$key]=$nested;}
   elseif($before[$key]!==$after[$key]){$changed[$key]=['before'=>$before[$key],'after'=>$after[$key]];}
  }
  return ['schema'=>'titan.onboarding-semantic-diff','version'=>'1.0','added'=>$added,'removed'=>$removed,'changed'=>$changed,'has_changes'=>$added!==[]||$removed!==[]||$changed!==[]];
 }
}
