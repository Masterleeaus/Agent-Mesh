<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class NexusApprovalRecord extends Model {
 protected $table='ext_onboarding_nexus_approvals'; protected $guarded=[];
 protected $casts=['company_id'=>'integer','discovery_revision'=>'integer','approved_by_user_id'=>'integer','preview_snapshot'=>'array','plan_receipt'=>'array','approved_at'=>'immutable_datetime'];
}
