<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Enrolment;

enum EnrolmentStatus: string
{
    case Pending = 'pending';
    case Active = 'active';
    case Blocked = 'blocked';
    case Completed = 'completed';
    case Cancelled = 'cancelled';
    case Expired = 'expired';
}
