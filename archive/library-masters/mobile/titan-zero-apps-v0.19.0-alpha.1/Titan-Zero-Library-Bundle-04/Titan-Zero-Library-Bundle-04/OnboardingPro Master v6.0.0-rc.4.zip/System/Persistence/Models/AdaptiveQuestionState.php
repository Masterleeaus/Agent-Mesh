<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class AdaptiveQuestionState extends Model
{
    protected $table='ext_onboarding_adaptive_question_states';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'user_id'=>'integer',
        'answer_payload'=>'array',
        'resolved_fact_keys'=>'array',
        'resolved_by_answer'=>'integer',
        'answered_at'=>'immutable_datetime',
        'deferred_at'=>'immutable_datetime',
    ];
}
