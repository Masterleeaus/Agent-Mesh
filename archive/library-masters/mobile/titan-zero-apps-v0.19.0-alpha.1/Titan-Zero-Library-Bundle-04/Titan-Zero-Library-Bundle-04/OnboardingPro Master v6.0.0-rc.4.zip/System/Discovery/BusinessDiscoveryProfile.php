<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

final readonly class BusinessDiscoveryProfile
{
    public function __construct(
        public array $businessIdentity,
        public string $industry,
        public array $services,
        public array $serviceAreas,
        public array $jurisdiction,
        public string $timezone,
        public string $size,
        public array $staff,
        public array $operatingHours,
        public string $pricingApproach,
        public array $jobLifecycle,
        public array $communicationChannels,
        public array $paymentMethods,
        public array $equipmentAssets,
        public array $complianceRequirements,
        public array $privacyPreferences,
        public array $aiProviderPreferences,
        public array $autonomyPreferences,
        public array $riskTolerance,
    ) {
        if (trim((string)($businessIdentity['name'] ?? '')) === '') throw new \InvalidArgumentException('Business identity name is required.');
        if (trim($industry) === '') throw new \InvalidArgumentException('Industry is required.');
        if ($services === []) throw new \InvalidArgumentException('At least one service is required.');
        if (trim((string)($jurisdiction['country'] ?? '')) === '') throw new \InvalidArgumentException('Jurisdiction country is required.');
        if (trim($size) === '') throw new \InvalidArgumentException('Business size is required.');
    }

    public static function fromArray(array $input): self
    {
        return new self(
            businessIdentity: (array)($input['business_identity'] ?? []),
            industry: trim((string)($input['industry'] ?? '')),
            services: array_values((array)($input['services'] ?? [])),
            serviceAreas: array_values((array)($input['service_areas'] ?? [])),
            jurisdiction: (array)($input['jurisdiction'] ?? []),
            timezone: trim((string)($input['timezone'] ?? '')),
            size: trim((string)($input['size'] ?? '')),
            staff: (array)($input['staff'] ?? []),
            operatingHours: (array)($input['operating_hours'] ?? []),
            pricingApproach: trim((string)($input['pricing_approach'] ?? '')),
            jobLifecycle: array_values((array)($input['job_lifecycle'] ?? [])),
            communicationChannels: array_values((array)($input['communication_channels'] ?? [])),
            paymentMethods: array_values((array)($input['payment_methods'] ?? [])),
            equipmentAssets: array_values((array)($input['equipment_assets'] ?? [])),
            complianceRequirements: array_values((array)($input['compliance_requirements'] ?? [])),
            privacyPreferences: (array)($input['privacy_preferences'] ?? []),
            aiProviderPreferences: (array)($input['ai_provider_preferences'] ?? []),
            autonomyPreferences: (array)($input['autonomy_preferences'] ?? []),
            riskTolerance: (array)($input['risk_tolerance'] ?? []),
        );
    }

    public function toArray(): array
    {
        return [
            'business_identity'=>$this->businessIdentity,
            'industry'=>$this->industry,
            'services'=>$this->services,
            'service_areas'=>$this->serviceAreas,
            'jurisdiction'=>$this->jurisdiction,
            'timezone'=>$this->timezone,
            'size'=>$this->size,
            'staff'=>$this->staff,
            'operating_hours'=>$this->operatingHours,
            'pricing_approach'=>$this->pricingApproach,
            'job_lifecycle'=>$this->jobLifecycle,
            'communication_channels'=>$this->communicationChannels,
            'payment_methods'=>$this->paymentMethods,
            'equipment_assets'=>$this->equipmentAssets,
            'compliance_requirements'=>$this->complianceRequirements,
            'privacy_preferences'=>$this->privacyPreferences,
            'ai_provider_preferences'=>$this->aiProviderPreferences,
            'autonomy_preferences'=>$this->autonomyPreferences,
            'risk_tolerance'=>$this->riskTolerance,
        ];
    }
}
