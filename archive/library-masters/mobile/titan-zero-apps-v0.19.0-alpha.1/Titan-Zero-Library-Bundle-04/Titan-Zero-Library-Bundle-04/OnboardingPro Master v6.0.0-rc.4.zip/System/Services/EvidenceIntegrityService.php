<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
use App\Extensions\OnboardingPro\System\Domain\Evidence\EvidenceIntegrityReceipt;
final class EvidenceIntegrityService
{
    public function capture(string $evidenceId,int $companyId,string $contentHash,?EvidenceIntegrityReceipt $previous,\DateTimeImmutable $capturedAt):EvidenceIntegrityReceipt
    {
        if($previous!==null&&$previous->companyId!==$companyId) throw new \DomainException('Evidence integrity chain cannot cross tenants.');
        $prev=$previous?->receiptHash;
        $payload=implode('|',[$evidenceId,$companyId,strtolower($contentHash),$prev??'', $capturedAt->format(DATE_ATOM)]);
        $receiptHash=hash('sha256',$payload);
        return new EvidenceIntegrityReceipt(substr($receiptHash,0,32),$evidenceId,$companyId,strtolower($contentHash),$prev,$receiptHash,$capturedAt);
    }
    public function verify(EvidenceIntegrityReceipt $receipt,string $currentContentHash,?string $expectedPreviousReceiptHash):bool
    {
        if(!hash_equals($receipt->contentHash,strtolower($currentContentHash))) return false;
        if($receipt->previousReceiptHash!==$expectedPreviousReceiptHash) return false;
        $payload=implode('|',[$receipt->evidenceId,$receipt->companyId,$receipt->contentHash,$receipt->previousReceiptHash??'', $receipt->capturedAt->format(DATE_ATOM)]);
        return hash_equals($receipt->receiptHash,hash('sha256',$payload));
    }
    public function verificationState(EvidenceIntegrityReceipt $receipt,string $currentContentHash,?string $expectedPreviousReceiptHash):string
    {return $this->verify($receipt,$currentContentHash,$expectedPreviousReceiptHash)?'INTEGRITY_VALID':'TAMPER_SUSPECTED';}
}
