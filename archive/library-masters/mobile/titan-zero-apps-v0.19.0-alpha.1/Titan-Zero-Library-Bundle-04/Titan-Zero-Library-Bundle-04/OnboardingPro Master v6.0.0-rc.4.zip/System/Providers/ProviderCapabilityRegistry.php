<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Providers;
final class ProviderCapabilityRegistry {
 public const CAPABILITIES=[
  'website'=>['read'=>'READ','draft'=>'DRAFT','write'=>'WRITE','publish'=>'PUBLISH'],
  'business_listing'=>['read'=>'READ','draft'=>'DRAFT','write'=>'WRITE','publish'=>'PUBLISH'],
  'reputation'=>['read'=>'READ','draft'=>'DRAFT','respond'=>'PUBLISH'],
  'social'=>['read'=>'READ','draft'=>'DRAFT','publish'=>'PUBLISH'],
  'booking'=>['read'=>'READ','draft'=>'DRAFT','write'=>'WRITE'],
  'quote'=>['read'=>'READ','draft'=>'DRAFT','write'=>'WRITE'],
  'communications'=>['read'=>'READ','draft'=>'DRAFT','send'=>'PUBLISH'],
  'advertising'=>['read'=>'READ','draft'=>'DRAFT','propose'=>'PROPOSE','publish'=>'PUBLISH','spend'=>'SPEND'],
  'marketplace'=>['read'=>'READ','draft'=>'DRAFT','publish'=>'PUBLISH'],
 ];
 public function resolve(string $providerType,string $operation):?string{return self::CAPABILITIES[$providerType][$operation]??null;}
}
