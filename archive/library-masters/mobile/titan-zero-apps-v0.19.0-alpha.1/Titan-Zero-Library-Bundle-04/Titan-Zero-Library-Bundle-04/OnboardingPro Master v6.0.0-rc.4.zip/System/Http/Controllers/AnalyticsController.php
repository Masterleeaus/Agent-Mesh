<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Analytics\JourneyMetricsService;
use App\Extensions\OnboardingPro\System\Analytics\BottleneckAnalyzer;
use App\Extensions\OnboardingPro\System\Persistence\Models\EnrolmentRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\StepInstanceRecord;
use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class AnalyticsController extends Controller
{
    public function __construct(private JourneyMetricsService $metrics,private BottleneckAnalyzer $bottlenecks){}
    public function index(Request $request){
        $tenant=(int)$request->attributes->get('company_id');
        $rows=EnrolmentRecord::query()->where('company_id',$tenant)->orderByDesc('id')->limit(5000)->get()->map(fn($r)=>['status'=>(string)$r->status,'started_at'=>$r->started_at?->toIso8601String(),'completed_at'=>$r->completed_at?->toIso8601String(),'approval_seconds'=>null,'evidence_rejected'=>false,'overdue'=>$r->expires_at?->isPast()&&$r->status!=='completed'])->all();
        $steps=StepInstanceRecord::query()->where('company_id',$tenant)->limit(10000)->get()->groupBy('step_key')->map(function($items,$key){$completed=$items->where('status','completed');$seconds=[];foreach($completed as $item){if($item->available_at&&$item->completed_at)$seconds[]=max(0,$item->completed_at->getTimestamp()-$item->available_at->getTimestamp());}sort($seconds);$n=count($seconds);$median=$n?($n%2?$seconds[intdiv($n,2)]:(int)(($seconds[$n/2-1]+$seconds[$n/2])/2)):0;return ['step_key'=>(string)$key,'started'=>$items->count(),'completed'=>$completed->count(),'median_seconds'=>$median];})->values()->all();
        return view('onboarding-pro::analytics.index',['metrics'=>$this->metrics->summarize($rows),'bottlenecks'=>$this->bottlenecks->rank($steps)]);
    }
}
