<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Competition;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessCompetitor;
use App\Extensions\OnboardingPro\System\RealityGraph\BusinessRealityGraphService;

final readonly class CompetitorDiscoveryService
{
 public const DIRECT_COMPETITOR='DIRECT_COMPETITOR';
 public const PARTIAL_OVERLAP='PARTIAL_OVERLAP';
 public const ADJACENT='ADJACENT';
 public const MARKET_LEADER='MARKET_LEADER';
 public const REFERENCE_BUSINESS='REFERENCE_BUSINESS';

 public function __construct(private BusinessRealityGraphService $graph){}

 public function discover(int $company_id,array $business,array $candidates):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $results=[];
  foreach($candidates as $candidate){
   if(!is_array($candidate)||trim((string)($candidate['name']??''))==='')continue;
   $dimensions=$this->dimensions($business,$candidate);
   $score=$this->score($dimensions);
   $classification=$this->classify($score,$dimensions,$candidate);
   $evidence=$this->evidence($dimensions,$candidate);
   $confidence=$this->confidence($dimensions,$candidate);
   $node=$this->graph->upsertNode($company_id,'competitor',(string)($candidate['external_key']??hash('sha256',strtolower((string)$candidate['name']))),[
    'name'=>(string)$candidate['name'],'classification'=>$classification,'dimensions'=>$dimensions,
   ]);
   $record=BusinessCompetitor::query()->updateOrCreate(
    ['company_id'=>$company_id,'competitor_node_id'=>$node->id],
    ['name'=>(string)$candidate['name'],'classification'=>$classification,'confidence'=>$confidence,'evidence'=>$evidence,'dimensions'=>$dimensions,'last_observed_at'=>now()]
   );
   $results[]=['id'=>$record->id,'name'=>$record->name,'classification'=>$classification,'confidence'=>$confidence,'dimensions'=>$dimensions,'evidence'=>$evidence];
  }
  usort($results,fn($a,$b)=>$b['confidence']<=>$a['confidence']);
  return ['company_id'=>$company_id,'competitors'=>$results];
 }

 private function dimensions(array $business,array $candidate):array
 {
  return [
   'geography'=>$this->overlap((array)($business['geography']??$business['service_areas']??[]),(array)($candidate['geography']??$candidate['service_areas']??[])),
   'services'=>$this->overlap((array)($business['services']??[]),(array)($candidate['services']??[])),
   'vertical'=>$this->scalarMatch($business['vertical']??null,$candidate['vertical']??null),
   'target_customer'=>$this->overlap((array)($business['target_customer']??[]),(array)($candidate['target_customer']??[])),
   'business_model'=>$this->scalarMatch($business['business_model']??null,$candidate['business_model']??null),
   'scale_similarity'=>(float)($candidate['scale_similarity']??0.5),
  ];
 }
 private function score(array $d):float{return 0.25*$d['geography']+0.30*$d['services']+0.20*$d['vertical']+0.15*$d['target_customer']+0.05*$d['business_model']+0.05*$d['scale_similarity'];}
 private function classify(float $score,array $d,array $candidate):string
 {
  if((bool)($candidate['reference_business']??false))return self::REFERENCE_BUSINESS;
  if((bool)($candidate['market_leader']??false)&&$score>=0.35)return self::MARKET_LEADER;
  if($score>=0.72)return self::DIRECT_COMPETITOR;
  if($score>=0.45)return self::PARTIAL_OVERLAP;
  return self::ADJACENT;
 }
 private function evidence(array $d,array $candidate):array{return ['dimension_matches'=>$d,'source_refs'=>array_values((array)($candidate['source_refs']??[])),'reason'=>'Classification uses geography, services, vertical, target_customer, business model and scale similarity rather than proximity alone.'];}
 private function confidence(array $d,array $candidate):int{$known=count(array_filter($d,fn($v)=>$v>0));$sources=count((array)($candidate['source_refs']??[]));return min(100,(int)round(($known/count($d))*75+min(25,$sources*5)));}
 private function scalarMatch(mixed $a,mixed $b):float{return $a!==null&&$b!==null&&strtolower(trim((string)$a))===strtolower(trim((string)$b))?1.0:0.0;}
 private function overlap(array $a,array $b):float{$a=array_unique(array_map(fn($v)=>strtolower(trim((string)$v)),$a));$b=array_unique(array_map(fn($v)=>strtolower(trim((string)$v)),$b));if($a===[]||$b===[])return 0.0;$union=array_unique(array_merge($a,$b));return count(array_intersect($a,$b))/max(1,count($union));}
}
