<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Opportunity;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;

final readonly class OpportunityIntelligenceService
{
 public const FACT='FACT';
 public const INFERENCE='INFERENCE';
 public const RECOMMENDATION='RECOMMENDATION';

 public function __construct(private OpportunityEvidenceService $evidence){}

 public function generate(int $company_id,array $candidates):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $created=[];
  foreach($candidates as $candidate){
   if(!is_array($candidate)||empty($candidate['fact']))continue;
   $compiled=$this->evidence->compile((array)($candidate['observation']??[]),(array)($candidate['benchmark']??[]),(array)($candidate['additional_evidence']??[]));
   $fact=(string)$candidate['fact'];
   $hypothesis=(string)($candidate['hypothesis']??'');
   $recommendation=(string)($candidate['recommendation']??'');
   if($hypothesis===''||$recommendation==='')continue;
   $record=BusinessOpportunity::query()->create([
    'company_id'=>$company_id,
    'domain'=>(string)($candidate['domain']??'growth'),
    'title'=>(string)($candidate['title']??'Business improvement opportunity'),
    'fact'=>$fact,'fact_type'=>self::FACT,
    'hypothesis'=>$hypothesis,'hypothesis_type'=>self::INFERENCE,
    'recommendation'=>$recommendation,'recommendation_type'=>self::RECOMMENDATION,
    'evidence'=>$compiled['evidence'],'confidence'=>$compiled['confidence'],
    'expected_benefit'=>(array)($candidate['expected_benefit']??[]),
    'estimated_effort'=>(array)($candidate['estimated_effort']??[]),
    'estimated_cost'=>(array)($candidate['estimated_cost']??[]),
    'risk'=>(array)($candidate['risk']??[]),
    'reversibility'=>(string)($candidate['reversibility']??'unknown'),
    'dependencies'=>(array)($candidate['dependencies']??[]),
    'measurement'=>(array)($candidate['measurement']??[]),
    'intervention'=>(array)($candidate['intervention']??[]),
    'status'=>'identified','active'=>true,
   ]);
   $created[]=$record;
  }
  return $created;
 }
}
