<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class CompetitiveBenchmarkRun extends Model{protected $table='ext_onboarding_competitive_benchmark_runs';protected $guarded=[];protected $casts=['company_id'=>'integer','cohort_size'=>'integer','summary'=>'array','started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime'];}
