<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
final class JourneyDraftService
{
    public function __construct(private JourneyDefinitionValidator $validator){}
    public function prepareUpdate(string $state,int $currentRevision,int $expectedRevision,array $definition): array
    {
        if($state!=='draft') throw new \LogicException('Published journey versions are immutable. Create a new draft version.');
        if($currentRevision!==$expectedRevision) throw new \RuntimeException('Journey draft revision conflict.');
        $validation=$this->validator->validate($definition);if(!$validation['valid']) throw new \InvalidArgumentException('Journey definition is invalid: '.implode(',',$validation['errors']));
        return ['revision'=>$currentRevision+1,'definition'=>$definition,'definition_hash'=>hash('sha256',json_encode($definition,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR))];
    }
}
