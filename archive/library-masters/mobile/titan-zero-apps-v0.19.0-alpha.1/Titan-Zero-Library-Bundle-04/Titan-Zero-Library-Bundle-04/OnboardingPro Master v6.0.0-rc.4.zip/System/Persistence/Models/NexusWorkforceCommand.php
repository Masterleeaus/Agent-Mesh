<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class NexusWorkforceCommand extends Model{protected $table='ext_onboarding_nexus_workforce_commands';protected $guarded=[];protected $casts=['company_id'=>'integer','business_opportunity_id'=>'integer','intervention_priority_id'=>'integer','objective'=>'array','evidence'=>'array','authority_context'=>'array','routing'=>'array','requires_approval'=>'boolean','dispatched_at'=>'immutable_datetime'];}
