<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Prioritisation;
final class BusinessImpactScoringService
{
 public function score(array $factors):array
 {
  $expected_benefit=$this->v($factors,'expected_benefit',0.5);$confidence=$this->v($factors,'confidence',0.5);
  $strategic_relevance=$this->v($factors,'strategic_relevance',0.5);$urgency=$this->v($factors,'urgency',0.5);
  $feasibility=$this->v($factors,'feasibility',0.5);$capacity_fit=$this->v($factors,'capacity_fit',0.5);
  $cost=max(.05,$this->v($factors,'cost',0.5));$risk=max(.05,$this->v($factors,'risk',0.5));$disruption=max(.05,$this->v($factors,'disruption',0.5));
  $benefit=($expected_benefit*.28)+($confidence*.18)+($strategic_relevance*.16)+($urgency*.14)+($feasibility*.12)+($capacity_fit*.12);
  $burden=($cost*.40)+($risk*.35)+($disruption*.25);
  $score=max(0,min(100,round(($benefit/(.35+$burden))*55,2)));
  return ['score'=>$score,'factors'=>compact('expected_benefit','confidence','strategic_relevance','urgency','feasibility','capacity_fit','cost','risk','disruption')];
 }
 private function v(array $f,string $k,float $default):float{$v=(float)($f[$k]??$default);if($v>1)$v/=100;return max(0,min(1,$v));}
}
