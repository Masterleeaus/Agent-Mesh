<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Diagnostics\WholeBusinessDiagnosticService;use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessDiagnosticRun;use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessConstraint;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class BusinessDiagnosticController extends Controller{
 public function __construct(private readonly WholeBusinessDiagnosticService $diagnostics){}
 public function run(Request $r){$r->validate(['domains'=>['required','array']]);$run=$this->diagnostics->run($this->companyId($r),(array)$r->input('domains'));return response()->json(['run_id'=>$run->id,'summary'=>$run->summary]);}
 public function latest(Request $r){$cid=$this->companyId($r);$run=BusinessDiagnosticRun::query()->where('company_id',$cid)->latest('id')->first();return response()->json(['run'=>$run,'constraints'=>$run?BusinessConstraint::query()->where('company_id',$cid)->where('diagnostic_run_id',$run->id)->orderByDesc('confidence')->get():[]]);}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
