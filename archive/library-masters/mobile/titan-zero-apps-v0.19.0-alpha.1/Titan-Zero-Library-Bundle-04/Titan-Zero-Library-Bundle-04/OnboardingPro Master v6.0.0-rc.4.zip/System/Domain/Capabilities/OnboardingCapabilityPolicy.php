<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Capabilities;
final class OnboardingCapabilityPolicy
{
    public function assertAllowed(OnboardingCapabilityAction $action,array $approvalEvidence): void
    {
        if(in_array($action->riskLevel,['high','critical'],true)){
            if(($approvalEvidence['approved']??false)!==true||trim((string)($approvalEvidence['approval_id']??''))==='') throw new \DomainException('High-risk onboarding capability requires explicit approval evidence.');
        }
    }
}
