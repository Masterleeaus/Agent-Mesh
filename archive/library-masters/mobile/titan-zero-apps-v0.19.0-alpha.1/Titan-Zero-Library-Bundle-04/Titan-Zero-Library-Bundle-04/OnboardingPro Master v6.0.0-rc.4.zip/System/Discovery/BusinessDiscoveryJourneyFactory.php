<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Domain\Steps\StepDefinition;
use App\Extensions\OnboardingPro\System\Domain\Steps\StepType;

final class BusinessDiscoveryJourneyFactory
{
    /** @return list<StepDefinition> */
    public function steps(): array
    {
        return [
            new StepDefinition(
                'minimum-discovery',
                StepType::Form,
                'business_owner',
                [
                    'title'=>'Start your Titan business setup',
                    'stage'=>'minimum',
                    'progressive'=>true,
                    'fields'=>[
                        ['name'=>'business_identity','type'=>'business_identity','required'=>true],
                        ['name'=>'industry','type'=>'vertical_candidate','required'=>true,'source'=>'titan_vertical_engine'],
                        ['name'=>'services','type'=>'repeatable_service','required'=>true],
                        ['name'=>'jurisdiction','type'=>'jurisdiction','required'=>true],
                        ['name'=>'size','type'=>'business_size','required'=>true],
                        ['name'=>'privacy_preferences','type'=>'privacy_preferences','required'=>true],
                    ],
                ],
                [],
                'minimum_required_fields_valid',
                'low',
                'allowed',
                null,
            ),
            new StepDefinition(
                'operational-discovery',
                StepType::Form,
                'business_owner',
                [
                    'title'=>'Configure how the business operates',
                    'stage'=>'operational',
                    'progressive'=>true,
                    'fields'=>[
                        ['name'=>'service_areas','type'=>'service_areas','required'=>false],
                        ['name'=>'staff','type'=>'workforce_shape','required'=>false],
                        ['name'=>'operating_hours','type'=>'schedule','required'=>false],
                        ['name'=>'timezone','type'=>'iana_timezone','required'=>false,'required_for'=>'titan_nexus'],
                        ['name'=>'pricing_approach','type'=>'pricing_model','required'=>false],
                        ['name'=>'job_lifecycle','type'=>'lifecycle','required'=>false],
                        ['name'=>'communication_channels','type'=>'channel_set','required'=>false],
                        ['name'=>'payment_methods','type'=>'payment_method_set','required'=>false],
                    ],
                ],
                [],
                'submitted_or_deferred',
                'low',
                'allowed',
                null,
            ),
            new StepDefinition(
                'continuous-discovery',
                StepType::Form,
                'business_owner',
                [
                    'title'=>'Continue intelligent setup',
                    'stage'=>'continuous',
                    'progressive'=>true,
                    'fields'=>[
                        ['name'=>'equipment_assets','type'=>'asset_categories','required'=>false],
                        ['name'=>'compliance_requirements','type'=>'compliance_domains','required'=>false,'source'=>'titan_vertical_engine'],
                        ['name'=>'ai_provider_preferences','type'=>'ai_provider_preferences','required'=>false],
                        ['name'=>'autonomy_preferences','type'=>'preference_only','required'=>false,'authority'=>'titan_autonomy'],
                        ['name'=>'risk_tolerance','type'=>'preference_only','required'=>false,'authority'=>'titan_risk'],
                    ],
                ],
                [],
                'submitted_or_deferred',
                'low',
                'allowed',
                null,
            ),
            new StepDefinition(
                'prepare-provisioning',
                StepType::Integration,
                'business_owner',
                [
                    'title'=>'Prepare Titan configuration',
                    'stage'=>'bootstrap',
                    'targets'=>['titan_vertical_engine','titan_nexus','titan_ai_workforce','titan_interaction_engine','titan_knowledge_authority'],
                    'direct_mutation'=>false,
                    'approval_note'=>'Consequential provisioning is executed by governed owning engines, not OnboardingPro.',
                ],
                [],
                'bootstrap_intents_prepared',
                'medium',
                'deferred',
                'onboarding.provisioning.prepare',
            ),
        ];
    }
}
