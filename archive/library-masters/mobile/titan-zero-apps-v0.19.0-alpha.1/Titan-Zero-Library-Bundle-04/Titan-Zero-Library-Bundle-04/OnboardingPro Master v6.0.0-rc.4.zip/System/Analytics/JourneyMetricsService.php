<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Analytics;
final class JourneyMetricsService
{
    /** @param array<int,array<string,mixed>> $rows */
    public function summarize(array $rows): array
    {
        $count=count($rows);$completed=0;$durations=[];$approval=[];$rejected=0;$overdue=0;
        foreach($rows as $row){
            if(($row['status']??null)==='completed'){$completed++;if(!empty($row['started_at'])&&!empty($row['completed_at'])){$a=strtotime((string)$row['started_at']);$b=strtotime((string)$row['completed_at']);if($a!==false&&$b!==false&&$b>=$a)$durations[]=$b-$a;}}
            if(isset($row['approval_seconds'])&&is_numeric($row['approval_seconds']))$approval[]=(int)$row['approval_seconds'];
            if(($row['evidence_rejected']??false)===true)$rejected++;
            if(($row['overdue']??false)===true)$overdue++;
        }
        return [
            'enrolments'=>$count,
            'completed'=>$completed,
            'completion_rate'=>$count?($completed/$count):0.0,
            'median_completion_seconds'=>$this->median($durations),
            'median_approval_seconds'=>$this->median($approval),
            'evidence_rejection_rate'=>$count?($rejected/$count):0.0,
            'overdue_rate'=>$count?($overdue/$count):0.0,
        ];
    }
    /** @param array<int,int> $values */
    private function median(array $values): int
    {if(!$values)return 0;sort($values,SORT_NUMERIC);$n=count($values);$i=intdiv($n,2);return $n%2?$values[$i]:(int)(($values[$i-1]+$values[$i])/2);}
}
