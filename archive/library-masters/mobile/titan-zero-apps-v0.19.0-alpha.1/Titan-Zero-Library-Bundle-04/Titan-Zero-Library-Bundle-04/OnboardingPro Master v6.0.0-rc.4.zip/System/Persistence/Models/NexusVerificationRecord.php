<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class NexusVerificationRecord extends Model{protected $table='ext_onboarding_nexus_verifications';protected $guarded=[];protected $casts=['company_id'=>'integer','execution_id'=>'integer','operational_ready'=>'boolean','verification_receipt'=>'array'];}
