<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Diagnostics;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessDiagnosticRun;use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessConstraint;
final readonly class WholeBusinessDiagnosticService
{
 public const DOMAINS=['growth','customer','work','money','people','risk'];
 public function __construct(private ConstraintDiagnosisService $diagnosis){}
 public function run(int $company_id,array $domainSnapshot):BusinessDiagnosticRun
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $snapshot=[];foreach(self::DOMAINS as $domain)$snapshot[$domain]=(array)($domainSnapshot[$domain]??[]);
  $run=BusinessDiagnosticRun::query()->create(['company_id'=>$company_id,'status'=>'running','domain_snapshot'=>$snapshot,'started_at'=>now()]);
  $items=$this->diagnosis->diagnose($snapshot);
  foreach($items as $item)BusinessConstraint::query()->create(['company_id'=>$company_id,'diagnostic_run_id'=>$run->id,'domain'=>$item['domain'],'constraint_key'=>$item['constraint'],'symptom'=>$item['symptom'],'evidence'=>$item['evidence'],'confidence'=>$item['confidence'],'blocking'=>$item['blocking'],'recommendations'=>$item['recommendations']]);
  $run->status='complete';$run->summary=['constraints'=>count($items),'primary_constraint'=>$items[0]['constraint']??null,'principle'=>'Diagnose the business constraint before optimising a surface metric.'];$run->completed_at=now();$run->save();return $run;
 }
}
