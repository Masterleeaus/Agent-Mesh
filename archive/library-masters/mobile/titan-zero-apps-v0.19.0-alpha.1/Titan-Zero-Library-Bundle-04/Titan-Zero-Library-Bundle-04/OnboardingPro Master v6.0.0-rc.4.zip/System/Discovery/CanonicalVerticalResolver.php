<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Contracts\VerticalCandidateGatewayInterface;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class CanonicalVerticalResolver
{
    public function __construct(private VerticalCandidateGatewayInterface $gateway)
    {
    }

    public function resolve(BusinessDiscoveryProfile $profile, int $profileRevision, OnboardingTraceContext $trace): VerticalResolution
    {
        $request = VerticalCandidateRequest::fromProfile($profile, $profileRevision, $trace);
        $resolution = $this->gateway->resolve($request);

        if ($resolution->companyId !== $trace->companyId) {
            throw new \RuntimeException('Cross-company vertical resolution denied.');
        }
        if (!hash_equals($request->fingerprint(), $resolution->requestHash)) {
            throw new \RuntimeException('Vertical resolution provenance does not match the current candidate request.');
        }

        return $resolution;
    }
}
