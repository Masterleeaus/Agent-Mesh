<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Requirements;
final readonly class ParticipantAchievement
{
    public function __construct(public string $requirementKey,public string $version,public \DateTimeImmutable $achievedAt,public ?\DateTimeImmutable $expiresAt)
    {if($requirementKey===''||$version==='')throw new \InvalidArgumentException('Achievement identity required.');}
    public function validAt(\DateTimeImmutable $at):bool{return $this->expiresAt===null||$this->expiresAt>$at;}
}
