<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Middleware;
use App\Extensions\OnboardingPro\System\Security\ParticipantGrantService;
use App\Extensions\OnboardingPro\System\Persistence\Models\ParticipantGrantRecord;
use Closure; use Illuminate\Http\Request; use Symfony\Component\HttpFoundation\Response;
final class ParticipantGrantMiddleware
{
    public function __construct(private ParticipantGrantService $grants){}
    public function handle(Request $request,Closure $next): Response
    {
        $token=(string)$request->route('grant');$tokenHash=hash('sha256',$token);
        $record=ParticipantGrantRecord::query()->where('token_hash',$tokenHash)->first();
        abort_unless($record && $record->revoked_at===null && $record->expires_at!==null && $record->expires_at->isFuture(),403);
        try{$grant=$this->grants->decode($token);}catch(\Throwable){abort(403);}
        abort_unless($this->grants->verify($grant,new \DateTimeImmutable('now')),403);
        abort_unless((int)$record->company_id===$grant->companyId && (int)$record->enrolment_id===$grant->enrolmentId && (int)$record->participant_id===$grant->participantId,403);
        $request->attributes->set('onboarding_participant_grant',$grant);
        return $next($request);
    }
}
