<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Contracts;

use App\Extensions\OnboardingPro\System\Discovery\VerticalCandidateRequest;
use App\Extensions\OnboardingPro\System\Discovery\VerticalResolution;

interface VerticalCandidateGatewayInterface
{
    public function resolve(VerticalCandidateRequest $request): VerticalResolution;
}
