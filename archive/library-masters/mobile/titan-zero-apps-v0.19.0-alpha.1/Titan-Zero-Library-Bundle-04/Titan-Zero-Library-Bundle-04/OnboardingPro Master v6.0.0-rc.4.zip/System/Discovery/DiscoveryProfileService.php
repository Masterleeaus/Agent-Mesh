<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Persistence\Models\DiscoveryProfileRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class DiscoveryProfileService
{
    public function __construct(
        private DiscoveryProfileRepository $repository,
        private ProgressiveReadinessEvaluator $readinessEvaluator,
    ) {
    }

    public function saveDraft(
        BusinessDiscoveryProfile $profile,
        OnboardingTraceContext $trace,
        ?int $expectedRevision = null,
    ): DiscoveryProfileRecord {
        if ($trace->companyId <= 0) {
            throw new \InvalidArgumentException('Trusted company context is required for discovery persistence.');
        }

        $readiness = $this->readinessEvaluator->evaluate($profile);
        $status = $readiness->operationalReady
            ? 'OPERATIONAL_READY'
            : ($readiness->minimumReady ? 'MINIMUM_READY' : 'DISCOVERING');

        return $this->repository->saveRevision(
            companyId: $trace->companyId,
            profilePayload: $profile->toArray(),
            status: $status,
            minimumReady: $readiness->minimumReady,
            operationalReady: $readiness->operationalReady,
            remainingDomains: $readiness->remainingDomains,
            trace: $trace,
            expectedRevision: $expectedRevision,
        );
    }


    /** @param list<string> $deferredDomains */
    public function saveProgressiveDraft(
        array $profilePayload,
        OnboardingTraceContext $trace,
        ?int $expectedRevision = null,
        array $deferredDomains = [],
        array $onboardingMetadata = [],
    ): DiscoveryProfileRecord {
        if ($trace->companyId <= 0) {
            throw new \InvalidArgumentException('Trusted company context is required for discovery persistence.');
        }

        $deferredDomains = array_values(array_unique(array_filter(array_map(
            static fn (mixed $domain): string => trim((string) $domain),
            $deferredDomains,
        ), static fn (string $domain): bool => $domain !== '')));
        $readiness = $this->readinessEvaluator->evaluatePayload($profilePayload, $deferredDomains);
        $status = $readiness->operationalReady
            ? 'OPERATIONAL_READY'
            : ($readiness->minimumReady ? 'MINIMUM_READY' : 'DISCOVERING');

        $storedPayload = $profilePayload;
        unset($onboardingMetadata['deferred_domains']);
        $storedPayload['_onboarding'] = array_merge($onboardingMetadata, ['deferred_domains' => $deferredDomains]);

        return $this->repository->saveRevision(
            companyId: $trace->companyId,
            profilePayload: $storedPayload,
            status: $status,
            minimumReady: $readiness->minimumReady,
            operationalReady: $readiness->operationalReady,
            remainingDomains: $readiness->remainingDomains,
            trace: $trace,
            expectedRevision: $expectedRevision,
        );
    }

    public function latest(int $companyId): ?DiscoveryProfileRecord
    {
        return $this->repository->latest($companyId);
    }

    public function findRevision(int $companyId, int $revision): ?DiscoveryProfileRecord
    {
        return $this->repository->findRevision($companyId, $revision);
    }
}
