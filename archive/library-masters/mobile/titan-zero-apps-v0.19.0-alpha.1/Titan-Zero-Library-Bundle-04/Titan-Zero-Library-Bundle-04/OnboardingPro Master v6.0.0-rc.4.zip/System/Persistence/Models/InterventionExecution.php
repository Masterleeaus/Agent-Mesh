<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class InterventionExecution extends Model{protected $table='ext_onboarding_intervention_executions';protected $guarded=[];protected $casts=['company_id'=>'integer','provider_action_request_id'=>'integer','baseline'=>'array','measurement_contract'=>'array','rollback_plan'=>'array','started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime'];}
