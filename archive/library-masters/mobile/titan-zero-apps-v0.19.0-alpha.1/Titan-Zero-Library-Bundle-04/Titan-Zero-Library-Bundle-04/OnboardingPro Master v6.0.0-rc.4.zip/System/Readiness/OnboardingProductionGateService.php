<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Readiness;

final readonly class OnboardingProductionGateService
{
 public function __construct(private OnboardingReadinessService $readiness){}
 public function evaluate(int $company_id,array $approval=[],array $cost_sovereignty=[]):array
 {
  $state=$this->readiness->check($company_id);
  $approvalValid=(bool)($approval['approved']??false)&&(bool)($approval['fingerprint_valid']??false);
  $costValid=(bool)($cost_sovereignty['hidden_titan_fallback_allowed']??true)===false
    && count((array)($cost_sovereignty['blocked_paid_routes']??[]))===0;
  $fail_closed=!$approvalValid||!$costValid||!(bool)$state['operationally_ready'];
  return [
   'company_id'=>$company_id,'production_ready'=>!$fail_closed,'fail_closed'=>$fail_closed,
   'approval'=>['valid'=>$approvalValid],
   'cost_sovereignty'=>['valid'=>$costValid,'state'=>$cost_sovereignty],
   'readiness'=>$state,
  ];
 }
}
