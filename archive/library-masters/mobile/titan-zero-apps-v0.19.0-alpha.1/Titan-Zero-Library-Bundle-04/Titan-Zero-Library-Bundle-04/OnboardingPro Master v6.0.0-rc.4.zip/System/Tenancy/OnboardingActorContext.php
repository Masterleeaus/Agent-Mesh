<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Tenancy;

final readonly class OnboardingActorContext
{
    /** @param list<string> $roles @param list<string> $permissions */
    public function __construct(
        public int $userId,
        public string $actorType = 'user',
        public array $roles = [],
        public array $permissions = [],
        public string $sourceSurface = 'web',
    ) {
        if ($this->userId <= 0) {
            throw new \InvalidArgumentException('Onboarding actor user ID must be positive.');
        }
    }
}
