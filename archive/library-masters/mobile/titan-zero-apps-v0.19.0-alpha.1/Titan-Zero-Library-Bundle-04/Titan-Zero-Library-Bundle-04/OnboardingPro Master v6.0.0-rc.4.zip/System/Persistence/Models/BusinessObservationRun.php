<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessObservationRun extends Model{protected $table='ext_onboarding_observation_runs';protected $guarded=[];protected $casts=['company_id'=>'integer','requested_sources'=>'array','due_sources'=>'array','summary'=>'array','started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime'];}
