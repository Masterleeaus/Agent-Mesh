<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Tracing;

final readonly class OnboardingTraceContext
{
    public function __construct(
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public int $companyId,
        public int|string $actorId,
    ) {
        foreach (['traceId'=>$traceId,'correlationId'=>$correlationId,'causationId'=>$causationId] as $name=>$value) {
            if (trim($value) === '') throw new \InvalidArgumentException("$name is required.");
        }
        if ($companyId <= 0) throw new \InvalidArgumentException('companyId must be positive.');
        if ((string)$actorId === '' || (string)$actorId === '0') throw new \InvalidArgumentException('actorId is required.');
    }

    public function toArray(): array
    {
        return [
            'trace_id'=>$this->traceId,
            'correlation_id'=>$this->correlationId,
            'causation_id'=>$this->causationId,
            'company_id'=>$this->companyId,
            'actor_id'=>$this->actorId,
        ];
    }
}
