<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

final class ProgressiveReadinessEvaluator
{
    public function evaluate(BusinessDiscoveryProfile $profile): ProgressiveReadinessResult
    {
        return $this->evaluatePayload($profile->toArray());
    }

    /** @param list<string> $deferredDomains */
    public function evaluatePayload(array $payload, array $deferredDomains = []): ProgressiveReadinessResult
    {
        $deferred = array_fill_keys(array_values(array_unique(array_map(
            static fn (mixed $value): string => trim((string) $value),
            $deferredDomains,
        ))), true);

        $minimumReady = trim((string) (($payload['business_identity']['name'] ?? ''))) !== ''
            && trim((string) ($payload['industry'] ?? '')) !== ''
            && array_values((array) ($payload['services'] ?? [])) !== []
            && trim((string) (($payload['jurisdiction']['country'] ?? ''))) !== ''
            && trim((string) ($payload['size'] ?? '')) !== ''
            && (array) ($payload['privacy_preferences'] ?? []) !== [];

        $remaining = [];
        $checks = [
            'workforce' => (array) (($payload['staff']['roles'] ?? [])),
            'service_areas' => array_values((array) ($payload['service_areas'] ?? [])),
            'operating_hours' => (array) ($payload['operating_hours'] ?? []),
            'pricing' => trim((string) ($payload['pricing_approach'] ?? '')),
            'job_lifecycle' => array_values((array) ($payload['job_lifecycle'] ?? [])),
            'communications' => array_values((array) ($payload['communication_channels'] ?? [])),
            'payments' => array_values((array) ($payload['payment_methods'] ?? [])),
            'compliance' => array_values((array) ($payload['compliance_requirements'] ?? [])),
            'ai_provider' => (array) ($payload['ai_provider_preferences'] ?? []),
            'autonomy_preferences' => (array) ($payload['autonomy_preferences'] ?? []),
            'risk_tolerance' => (array) ($payload['risk_tolerance'] ?? []),
        ];

        foreach ($checks as $domain => $value) {
            $empty = is_string($value) ? $value === '' : $value === [];
            if ($empty && !isset($deferred[$domain])) {
                $remaining[] = $domain;
            }
        }

        $operationalBlocking = ['service_areas','operating_hours','pricing','job_lifecycle','communications'];
        $operationalReady = $minimumReady && array_intersect($remaining, $operationalBlocking) === [];

        $codes = [];
        if ($minimumReady) $codes[] = 'MINIMUM_DISCOVERY_COMPLETE';
        if ($operationalReady) $codes[] = 'OPERATIONAL_DISCOVERY_COMPLETE';
        if ($remaining !== []) $codes[] = 'PROGRESSIVE_SETUP_REMAINS';
        if ($deferred !== []) $codes[] = 'OPTIONAL_DISCOVERY_DEFERRED';

        return new ProgressiveReadinessResult($minimumReady, $operationalReady, $remaining, $codes);
    }
}
