<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessRealityEdge extends Model {
 protected $table='ext_onboarding_reality_edges';protected $guarded=[];
 protected $casts=['company_id'=>'integer','from_node_id'=>'integer','to_node_id'=>'integer','evidence'=>'array','confidence'=>'integer','active'=>'boolean'];
}
