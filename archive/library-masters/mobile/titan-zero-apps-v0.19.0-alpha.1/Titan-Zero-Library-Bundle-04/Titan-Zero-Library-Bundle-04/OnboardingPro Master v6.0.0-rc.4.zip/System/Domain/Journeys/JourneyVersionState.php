<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Journeys;

enum JourneyVersionState: string
{
    case Draft = 'draft';
    case Published = 'published';
    case Superseded = 'superseded';
    case Archived = 'archived';
}
