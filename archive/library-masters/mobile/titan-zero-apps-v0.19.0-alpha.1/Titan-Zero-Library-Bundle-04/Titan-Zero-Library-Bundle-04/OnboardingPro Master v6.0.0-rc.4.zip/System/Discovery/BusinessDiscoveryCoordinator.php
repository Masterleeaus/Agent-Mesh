<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Tracing\OnboardingDecisionReceipt;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final class BusinessDiscoveryCoordinator
{
    public function __construct(
        private readonly BusinessDiscoveryCompiler $compiler = new BusinessDiscoveryCompiler(),
        private readonly ProgressiveReadinessEvaluator $readinessEvaluator = new ProgressiveReadinessEvaluator(),
    ) {
    }

    public function prepare(
        BusinessDiscoveryProfile $profile,
        OnboardingTraceContext $trace,
        ?VerticalResolution $verticalResolution = null,
        int $profileRevision = 1,
    ): DiscoveryPreparation {
        $profileHash = $this->hash($profile->toArray());
        $readiness = $this->readinessEvaluator->evaluate($profile);
        $compiled = $this->compiler->compile($profile, $trace, $verticalResolution);

        $map = [
            'vertical_candidate_request' => ['vertical_engine', 'candidate_match'],
            'workforce_bootstrap_intent' => ['ai_workforce', 'prepare_workforce_bootstrap'],
            'workflow_bootstrap_intent' => ['interaction_engine', 'resolve_workflow_bootstrap'],
            'knowledge_bootstrap_intent' => ['knowledge_authority', 'prepare_knowledge_scope'],
        ];

        $intents = [];
        $signals = [];
        foreach ($map as $key => [$target, $operation]) {
            $payload = (array) $compiled[$key];
            foreach (['trace_id','correlation_id','causation_id','company_id','actor_id'] as $ctxKey) {
                unset($payload[$ctxKey]);
            }
            $idem = hash('sha256', $trace->companyId.'|'.$profileHash.'|'.$target.'|'.$operation);
            $intent = BootstrapIntent::prepare($target, $operation, $payload, $trace, $idem);
            $intents[] = $intent;
            $signals[] = OnboardingDecisionReceipt::create('onboarding.bootstrap.prepared', $trace, [
                'target_engine' => $target,
                'operation' => $operation,
                'idempotency_key' => $idem,
                'receipt_reference' => 'bootstrap:'.$idem,
                'reason_codes' => ['DISCOVERY_BOOTSTRAP_PREPARED'],
                'evidence_refs' => ['discovery-profile:'.$profileHash],
                'policy_version' => 'onboarding-discovery-v2',
            ])->toArray();
        }

        if ($verticalResolution?->isResolved() === true) {
            $nexusGaps = $this->compiler->nexusContractGaps($profile, $trace, $verticalResolution, $profileRevision);
            if ($nexusGaps === []) {
                $nexusIntent = $this->compiler->compileNexusProvisioningIntent($profile, $trace, $verticalResolution, $profileRevision);
                $payload = $nexusIntent->toArray();
                $operation = 'compile_business_configuration';
                $idem = hash('sha256', $trace->companyId.'|'.$profileHash.'|nexus|'.$operation.'|'.$nexusIntent->fingerprint());
                $intents[] = BootstrapIntent::prepare('nexus', $operation, $payload, $trace, $idem);
                $signals[] = OnboardingDecisionReceipt::create('onboarding.bootstrap.prepared', $trace, [
                    'target_engine' => 'nexus',
                    'operation' => $operation,
                    'idempotency_key' => $idem,
                    'receipt_reference' => 'bootstrap:'.$idem,
                    'reason_codes' => ['CANONICAL_NEXUS_INTENT_PREPARED'],
                    'evidence_refs' => ['discovery-profile:'.$profileHash, 'vertical-resolution:'.$verticalResolution->requestHash],
                    'policy_version' => 'onboarding-nexus-contract-v1.1',
                ])->toArray();
            } else {
                $signals[] = OnboardingDecisionReceipt::create('onboarding.nexus_contract.incomplete', $trace, [
                    'missing_requirements' => $nexusGaps,
                    'profile_revision' => $profileRevision,
                    'reason_codes' => ['NEXUS_CONTRACT_INCOMPLETE'],
                    'evidence_refs' => ['discovery-profile:'.$profileHash],
                    'policy_version' => 'onboarding-nexus-contract-v1.1',
                ])->toArray();
            }
        }

        if ($verticalResolution === null) {
            $signals[] = OnboardingDecisionReceipt::create('onboarding.vertical_resolution.required', $trace, [
                'reason_codes' => ['CANONICAL_VERTICAL_REQUIRED_BEFORE_NEXUS'],
                'evidence_refs' => ['discovery-profile:'.$profileHash],
                'policy_version' => 'onboarding-vertical-resolution-v1',
            ])->toArray();
        } elseif (!$verticalResolution->isResolved()) {
            $signals[] = OnboardingDecisionReceipt::create(
                $verticalResolution->status === 'AMBIGUOUS' ? 'onboarding.vertical_resolution.ambiguous' : 'onboarding.vertical_resolution.unavailable',
                $trace,
                [
                    'request_hash' => $verticalResolution->requestHash,
                    'confidence' => $verticalResolution->confidence,
                    'candidates' => $verticalResolution->candidates,
                    'reason_codes' => $verticalResolution->reasonCodes,
                    'policy_version' => 'onboarding-vertical-resolution-v1',
                ],
            )->toArray();
        } else {
            $signals[] = OnboardingDecisionReceipt::create('onboarding.vertical_resolution.resolved', $trace, [
                'vertical_id' => $verticalResolution->verticalId,
                'vertical_version' => $verticalResolution->verticalVersion,
                'definition_hash' => $verticalResolution->definitionHash,
                'request_hash' => $verticalResolution->requestHash,
                'confidence' => $verticalResolution->confidence,
                'reason_codes' => $verticalResolution->reasonCodes,
                'policy_version' => 'onboarding-vertical-resolution-v1',
            ])->toArray();
        }

        $signals[] = OnboardingDecisionReceipt::create('onboarding.discovery.updated', $trace, [
            'profile_revision' => $profileRevision,
            'profile_hash' => $profileHash,
            'changed_domains' => array_keys($profile->toArray()),
            'reason_codes' => ['DISCOVERY_PROFILE_COMPILED'],
            'evidence_refs' => ['discovery-profile:'.$profileHash],
            'policy_version' => 'onboarding-discovery-v2',
        ])->toArray();
        if ($readiness->minimumReady) {
            $signals[] = OnboardingDecisionReceipt::create('onboarding.minimum_ready', $trace, [
                'profile_revision' => $profileRevision,
                'profile_hash' => $profileHash,
                'remaining_domains' => $readiness->remainingDomains,
                'reason_codes' => $readiness->reasonCodes,
                'evidence_refs' => ['discovery-profile:'.$profileHash],
                'policy_version' => 'onboarding-discovery-v2',
            ])->toArray();
        }
        if ($readiness->remainingDomains !== []) {
            $signals[] = OnboardingDecisionReceipt::create('onboarding.progressive_setup.recommended', $trace, [
                'remaining_domains' => $readiness->remainingDomains,
                'recommended_journey_ids' => array_map(static fn (string $d): string => 'onboarding.progressive.'.$d, $readiness->remainingDomains),
                'reason_codes' => ['PROGRESSIVE_SETUP_REMAINS'],
                'evidence_refs' => ['discovery-profile:'.$profileHash],
                'policy_version' => 'onboarding-discovery-v2',
            ])->toArray();
        }

        return new DiscoveryPreparation($profileHash, $readiness, $intents, $signals);
    }

    private function hash(array $data): string
    {
        $normalise = function (mixed $value) use (&$normalise): mixed {
            if (!is_array($value)) {
                return $value;
            }
            if (array_is_list($value)) {
                return array_map($normalise, $value);
            }
            ksort($value);
            foreach ($value as $key => $item) {
                $value[$key] = $normalise($item);
            }
            return $value;
        };

        return hash('sha256', json_encode($normalise($data), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }
}
