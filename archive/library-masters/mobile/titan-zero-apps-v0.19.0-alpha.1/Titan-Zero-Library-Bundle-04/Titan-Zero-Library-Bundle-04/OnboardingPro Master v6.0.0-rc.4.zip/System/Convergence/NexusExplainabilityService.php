<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Convergence;
final class NexusExplainabilityService {
 public function explain(string $decision,array $evidence,int $confidence,array $alternatives=[]):array {
  return ['decision'=>$decision,'why'=>$this->why($evidence,$confidence),'evidence'=>$evidence,'confidence'=>max(0,min(100,$confidence)),'alternatives'=>$alternatives,'epistemic_state'=>$confidence>=80?'strong':($confidence>=55?'provisional':'uncertain')];
 }
 private function why(array $evidence,int $confidence):string{return $evidence===[]?'No supporting evidence is currently retained.':"Decision is supported by retained evidence at {$confidence}% confidence.";}
}
