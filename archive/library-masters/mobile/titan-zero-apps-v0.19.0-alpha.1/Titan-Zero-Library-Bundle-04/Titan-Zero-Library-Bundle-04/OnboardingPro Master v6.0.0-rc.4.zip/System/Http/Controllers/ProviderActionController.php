<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Providers\ProviderActionFabric;use App\Extensions\OnboardingPro\System\Persistence\Models\ProviderActionRequest;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class ProviderActionController extends Controller{
 public function __construct(private readonly ProviderActionFabric $fabric){}
 public function prepare(Request $r){$r->validate(['command_id'=>['required','integer'],'provider_type'=>['required','string'],'operation'=>['required','string'],'payload'=>['nullable','array'],'authority'=>['nullable','array'],'idempotency_key'=>['required','string']]);return response()->json($this->fabric->prepare($this->companyId($r),(int)$r->input('command_id'),(string)$r->input('provider_type'),(string)$r->input('operation'),(array)$r->input('payload',[]),(array)$r->input('authority',[]),(string)$r->input('idempotency_key')));}
 public function latest(Request $r){return response()->json(ProviderActionRequest::query()->where('company_id',$this->companyId($r))->latest('id')->limit(50)->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
