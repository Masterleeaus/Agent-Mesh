<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class BusinessConstraint extends Model{protected $table='ext_onboarding_business_constraints';protected $guarded=[];protected $casts=['company_id'=>'integer','diagnostic_run_id'=>'integer','evidence'=>'array','confidence'=>'integer','blocking'=>'boolean','recommendations'=>'array'];}
