<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class BusinessSetupService
{
    private const DEFERABLE_DOMAINS = [
        'workforce',
        'service_areas',
        'operating_hours',
        'pricing',
        'job_lifecycle',
        'communications',
        'payments',
        'compliance',
        'ai_provider',
        'autonomy_preferences',
        'risk_tolerance',
    ];

    public function __construct(
        private DiscoveryProfileService $profiles,
        private BusinessDiscoveryJourneyFactory $journeyFactory,
        private ProgressiveReadinessEvaluator $readinessEvaluator,
        private CanonicalVerticalResolver $verticalResolver,
    ) {
    }

    public function state(int $companyId): BusinessSetupState
    {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Trusted company context is required for business setup.');
        }

        $latest = $this->profiles->latest($companyId);
        $stored = (array) ($latest?->profile_payload ?? []);
        $metadata = (array) ($stored['_onboarding'] ?? []);
        unset($stored['_onboarding']);
        $deferred = $this->normaliseDeferredDomains((array) ($metadata['deferred_domains'] ?? []));
        $readiness = $this->readinessEvaluator->evaluatePayload($stored, $deferred);
        $verticalResolution = $this->verticalResolutionState($metadata, $stored, $readiness);

        return new BusinessSetupState(
            mode: $latest === null ? 'first_run' : 'existing_business',
            revision: (int) ($latest?->revision ?? 0),
            profile: $stored,
            deferredDomains: $deferred,
            readiness: $readiness,
            steps: $this->stepSummaries(),
            status: (string) ($latest?->status ?? 'DISCOVERING'),
            verticalResolution: $verticalResolution,
        );
    }

    public function saveSection(
        string $section,
        array $input,
        OnboardingTraceContext $trace,
        ?int $expectedRevision = null,
    ): BusinessSetupState {
        $fields = $this->sectionFields($section);
        if ($fields === []) {
            throw new \InvalidArgumentException('Unknown or non-editable business setup section.');
        }

        $current = $this->state($trace->companyId);
        $next = $current->profile;
        foreach ($fields as $field) {
            if (array_key_exists($field, $input)) {
                $next[$field] = $input[$field];
            }
        }

        $record = $this->profiles->saveProgressiveDraft(
            profilePayload: $next,
            trace: $trace,
            expectedRevision: $expectedRevision,
            deferredDomains: $current->deferredDomains,
            onboardingMetadata: $this->preservedMetadata($current),
        );

        return $this->state((int) $record->company_id);
    }

    public function deferDomain(
        string $domain,
        OnboardingTraceContext $trace,
        ?int $expectedRevision = null,
    ): BusinessSetupState {
        $domain = trim($domain);
        if (!in_array($domain, self::DEFERABLE_DOMAINS, true)) {
            throw new \InvalidArgumentException('This business setup domain cannot be deferred.');
        }

        $current = $this->state($trace->companyId);
        $deferred = $this->normaliseDeferredDomains([...$current->deferredDomains, $domain]);
        $this->profiles->saveProgressiveDraft(
            profilePayload: $current->profile,
            trace: $trace,
            expectedRevision: $expectedRevision,
            deferredDomains: $deferred,
            onboardingMetadata: $this->preservedMetadata($current),
        );

        return $this->state($trace->companyId);
    }

    public function resolveVertical(OnboardingTraceContext $trace, ?int $expectedRevision = null): BusinessSetupState
    {
        $current = $this->state($trace->companyId);
        if (!$current->readiness->minimumReady || $current->revision <= 0) {
            throw new \InvalidArgumentException('Complete and save business essentials before resolving the canonical vertical.');
        }

        $profile = BusinessDiscoveryProfile::fromArray($current->profile);
        $resolution = $this->verticalResolver->resolve($profile, $current->revision, $trace);
        $verticalMetadata = $resolution->toArray();
        $verticalMetadata['source_inputs_hash'] = VerticalCandidateRequest::sourceFingerprint($profile);
        $verticalMetadata['source_profile_revision'] = $current->revision;

        $record = $this->profiles->saveProgressiveDraft(
            profilePayload: $current->profile,
            trace: $trace,
            expectedRevision: $expectedRevision,
            deferredDomains: $current->deferredDomains,
            onboardingMetadata: ['vertical_resolution' => $verticalMetadata],
        );

        return $this->state((int) $record->company_id);
    }

    /** @return list<string> */
    private function sectionFields(string $section): array
    {
        foreach ($this->journeyFactory->steps() as $step) {
            if ($step->key !== $section) {
                continue;
            }

            $fields = [];
            foreach ((array) ($step->config['fields'] ?? []) as $definition) {
                $name = trim((string) ($definition['name'] ?? ''));
                if ($name !== '') {
                    $fields[] = $name;
                }
            }

            return array_values(array_unique($fields));
        }

        return [];
    }

    /** @return list<array<string,mixed>> */
    private function stepSummaries(): array
    {
        $summaries = [];
        foreach ($this->journeyFactory->steps() as $step) {
            $summaries[] = [
                'key' => $step->key,
                'title' => (string) ($step->config['title'] ?? $step->key),
                'stage' => (string) ($step->config['stage'] ?? ''),
                'type' => $step->type->value,
                'fields' => array_values((array) ($step->config['fields'] ?? [])),
                'completion_rule' => $step->completionRule,
            ];
        }

        return $summaries;
    }

    /** @return list<string> */
    private function normaliseDeferredDomains(array $domains): array
    {
        $domains = array_values(array_unique(array_map(
            static fn (mixed $value): string => trim((string) $value),
            $domains,
        )));

        return array_values(array_filter(
            $domains,
            static fn (string $domain): bool => in_array($domain, self::DEFERABLE_DOMAINS, true),
        ));
    }

    private function verticalResolutionState(array $metadata, array $profilePayload, ProgressiveReadinessResult $readiness): ?array
    {
        $resolution = $metadata['vertical_resolution'] ?? null;
        if (!is_array($resolution)) {
            return null;
        }

        $resolution['stale'] = true;
        $resolution['canonical_ready'] = false;
        if (!$readiness->minimumReady) {
            return $resolution;
        }

        try {
            $profile = BusinessDiscoveryProfile::fromArray($profilePayload);
            $currentHash = VerticalCandidateRequest::sourceFingerprint($profile);
            $storedHash = strtolower(trim((string) ($resolution['source_inputs_hash'] ?? '')));
            $resolution['stale'] = $storedHash === '' || !hash_equals($storedHash, $currentHash);
            $resolution['canonical_ready'] = ($resolution['status'] ?? null) === 'RESOLVED'
                && $resolution['stale'] === false
                && trim((string) ($resolution['vertical_id'] ?? '')) !== ''
                && trim((string) ($resolution['vertical_version'] ?? '')) !== '';
        } catch (\Throwable) {
            $resolution['stale'] = true;
            $resolution['canonical_ready'] = false;
        }

        return $resolution;
    }

    private function preservedMetadata(BusinessSetupState $state): array
    {
        if (!is_array($state->verticalResolution)) {
            return [];
        }
        $vertical = $state->verticalResolution;
        unset($vertical['stale'], $vertical['canonical_ready']);
        return ['vertical_resolution' => $vertical];
    }
}
