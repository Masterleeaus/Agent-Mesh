<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Competition\CompetitiveBenchmarkingService;use App\Extensions\OnboardingPro\System\Persistence\Models\CompetitiveBenchmarkRun;use App\Extensions\OnboardingPro\System\Persistence\Models\CompetitiveBenchmarkMetric;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class CompetitiveBenchmarkController extends Controller{
 public function __construct(private readonly CompetitiveBenchmarkingService $benchmarks){}
 public function run(Request $r){$r->validate(['business_metrics'=>['required','array'],'competitor_metrics'=>['required','array']]);$run=$this->benchmarks->run($this->companyId($r),(array)$r->input('business_metrics'),(array)$r->input('competitor_metrics'));return response()->json(['run_id'=>$run->id,'summary'=>$run->summary]);}
 public function latest(Request $r){$cid=$this->companyId($r);$run=CompetitiveBenchmarkRun::query()->where('company_id',$cid)->latest('id')->first();return response()->json(['run'=>$run,'metrics'=>$run?CompetitiveBenchmarkMetric::query()->where('company_id',$cid)->where('benchmark_run_id',$run->id)->get():[]]);}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
