<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\TitanAI;
use App\Extensions\OnboardingPro\System\AI\JourneyDraftRequest;
final class TitanAIJourneyGateway{
 public function prepare(JourneyDraftRequest $request):array{return ['target'=>'titan-ai','operation'=>'onboarding.journey.draft.generate','status'=>'PREPARED','direct_mutation'=>false,'company_id'=>$request->companyId,'trace_id'=>$request->traceId,'payload'=>['goal'=>$request->goal,'vertical'=>$request->vertical,'jurisdiction'=>$request->jurisdiction,'requested_step_types'=>$request->requestedStepTypes,'requested_capabilities'=>$request->requestedCapabilities,'output_schema'=>'OnboardingJourneyDraft/v1','publish_policy'=>'HUMAN_REVIEW_REQUIRED'],'idempotency_key'=>hash('sha256',implode('|',[$request->companyId,$request->goal,$request->vertical,$request->jurisdiction,$request->traceId]))];}
}
