<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

final readonly class VerticalResolution
{
    /** @param list<array<string,mixed>> $candidates @param list<array<string,mixed>> $secondaryVerticals @param list<string> $reasonCodes */
    public function __construct(
        public string $status,
        public int $companyId,
        public string $requestHash,
        public ?string $verticalId,
        public ?string $verticalVersion,
        public float $confidence,
        public ?string $definitionHash,
        public array $candidates,
        public array $secondaryVerticals,
        public array $reasonCodes,
        public ?string $engineReceiptId = null,
    ) {
        if (!in_array($status, ['RESOLVED','AMBIGUOUS','UNAVAILABLE'], true)) {
            throw new \InvalidArgumentException('Unsupported vertical resolution status.');
        }
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Vertical resolution requires positive company_id.');
        }
        if (preg_match('/^[0-9a-f]{64}$/', strtolower($requestHash)) !== 1) {
            throw new \InvalidArgumentException('Vertical resolution request_hash must be a SHA-256 hex digest.');
        }
        if ($confidence < 0.0 || $confidence > 1.0) {
            throw new \InvalidArgumentException('Vertical resolution confidence must be between 0 and 1.');
        }
        if ($status === 'RESOLVED') {
            if (trim((string) $verticalId) === '' || trim((string) $verticalVersion) === '') {
                throw new \InvalidArgumentException('Resolved vertical requires canonical vertical_id and vertical_version.');
            }
        } elseif ($verticalId !== null || $verticalVersion !== null) {
            throw new \InvalidArgumentException('Non-resolved vertical response cannot silently nominate canonical authority.');
        }
        if ($definitionHash !== null && preg_match('/^[0-9a-f]{64}$/', strtolower($definitionHash)) !== 1) {
            throw new \InvalidArgumentException('Vertical definition_hash must be a SHA-256 hex digest.');
        }
    }

    public static function fromEngineResponse(array $response, VerticalCandidateRequest $request): self
    {
        $companyId = (int) ($response['company_id'] ?? 0);
        if ($companyId !== $request->companyId) {
            throw new \RuntimeException('Titan Vertical Engine response company_id mismatch.');
        }
        $requestHash = strtolower(trim((string) ($response['request_hash'] ?? '')));
        if (!hash_equals($request->fingerprint(), $requestHash)) {
            throw new \RuntimeException('Titan Vertical Engine response request_hash mismatch.');
        }

        $status = strtoupper(trim((string) ($response['status'] ?? '')));
        $verticalId = self::nullableToken($response['vertical_id'] ?? null);
        $verticalVersion = self::nullableToken($response['vertical_version'] ?? null);
        $confidence = (float) ($response['confidence'] ?? 0.0);
        $definitionHash = self::nullableToken($response['definition_hash'] ?? null);
        $candidates = self::normaliseCandidates((array) ($response['candidates'] ?? []));
        $secondary = self::normaliseCandidates((array) ($response['secondary_verticals'] ?? []), false);
        $reasons = array_values(array_unique(array_filter(array_map(
            static fn (mixed $value): string => strtoupper(trim((string) $value)),
            (array) ($response['reason_codes'] ?? []),
        ), static fn (string $value): bool => $value !== '')));
        $receipt = self::nullableToken($response['engine_receipt_id'] ?? null);

        return new self(
            status: $status,
            companyId: $companyId,
            requestHash: $requestHash,
            verticalId: $verticalId,
            verticalVersion: $verticalVersion,
            confidence: $confidence,
            definitionHash: $definitionHash,
            candidates: $candidates,
            secondaryVerticals: $secondary,
            reasonCodes: $reasons,
            engineReceiptId: $receipt,
        );
    }

    public static function unavailable(VerticalCandidateRequest $request, array $reasonCodes): self
    {
        return new self(
            status: 'UNAVAILABLE',
            companyId: $request->companyId,
            requestHash: $request->fingerprint(),
            verticalId: null,
            verticalVersion: null,
            confidence: 0.0,
            definitionHash: null,
            candidates: [],
            secondaryVerticals: [],
            reasonCodes: array_values(array_unique(array_filter(array_map(
                static fn (mixed $value): string => strtoupper(trim((string) $value)),
                $reasonCodes,
            ), static fn (string $value): bool => $value !== ''))),
        );
    }

    public function isResolved(): bool
    {
        return $this->status === 'RESOLVED';
    }

    public function toArray(): array
    {
        return array_filter([
            'status' => $this->status,
            'company_id' => $this->companyId,
            'request_hash' => $this->requestHash,
            'vertical_id' => $this->verticalId,
            'vertical_version' => $this->verticalVersion,
            'confidence' => $this->confidence,
            'definition_hash' => $this->definitionHash,
            'candidates' => $this->candidates,
            'secondary_verticals' => $this->secondaryVerticals,
            'reason_codes' => $this->reasonCodes,
            'engine_receipt_id' => $this->engineReceiptId,
        ], static fn (mixed $value): bool => $value !== null);
    }

    /** @return list<array<string,mixed>> */
    private static function normaliseCandidates(array $candidates, bool $scoreRequired = true): array
    {
        $result = [];
        foreach ($candidates as $candidate) {
            if (!is_array($candidate)) {
                throw new \InvalidArgumentException('Vertical candidate entries must be objects.');
            }
            $id = trim((string) ($candidate['vertical_id'] ?? ''));
            $version = trim((string) ($candidate['vertical_version'] ?? ''));
            if ($id === '' || $version === '') {
                throw new \InvalidArgumentException('Vertical candidate entries require vertical_id and vertical_version.');
            }
            $normalised = ['vertical_id' => $id, 'vertical_version' => $version];
            if (array_key_exists('score', $candidate)) {
                $score = (float) $candidate['score'];
                if ($score < 0.0 || $score > 1.0) {
                    throw new \InvalidArgumentException('Vertical candidate score must be between 0 and 1.');
                }
                $normalised['score'] = $score;
            } elseif ($scoreRequired) {
                throw new \InvalidArgumentException('Vertical candidate entries require score.');
            }
            $result[] = $normalised;
        }
        return $result;
    }

    private static function nullableToken(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
