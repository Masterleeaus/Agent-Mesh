<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Controllers;

use App\Extensions\OnboardingPro\System\Adaptive\AdaptiveOnboardingRuntimeService;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class AdaptiveOnboardingController extends Controller
{
    public function __construct(private readonly AdaptiveOnboardingRuntimeService $runtime) {}

    public function next(Request $request)
    {
        $request->validate([
            'surface'=>['nullable','in:chat,voice,vision,pwa'],
            'vertical'=>['nullable','string','max:100'],
            'country_code'=>['nullable','string','size:2'],
        ]);
        [$companyId,$userId]=$this->identity($request);

        return response()->json($this->runtime->next(
            $companyId,
            $userId,
            (string)$request->input('surface','pwa'),
            $request->filled('vertical')?(string)$request->input('vertical'):null,
            $request->filled('country_code')?strtoupper((string)$request->input('country_code')):null,
        ));
    }

    public function answer(Request $request)
    {
        $request->validate([
            'question_key'=>['required','string','max:100'],
            'answer_state'=>['nullable','in:answered,not_sure'],
            'answer'=>['nullable'],
            'surface'=>['nullable','in:chat,voice,vision,pwa'],
            'vertical'=>['nullable','string','max:100'],
            'country_code'=>['nullable','string','size:2'],
        ]);
        [$companyId,$userId]=$this->identity($request);
        $state=(string)$request->input('answer_state','answered');

        return response()->json($this->runtime->answer(
            $companyId,
            $userId,
            (string)$request->input('question_key'),
            $request->input('answer'),
            $state,
            (string)$request->input('surface','pwa'),
            $request->filled('vertical')?(string)$request->input('vertical'):null,
            $request->filled('country_code')?strtoupper((string)$request->input('country_code')):null,
        ));
    }

    public function defer(Request $request)
    {
        $request->validate([
            'question_key'=>['required','string','max:100'],
            'surface'=>['nullable','in:chat,voice,vision,pwa'],
            'vertical'=>['nullable','string','max:100'],
            'country_code'=>['nullable','string','size:2'],
        ]);
        [$companyId,$userId]=$this->identity($request);

        return response()->json($this->runtime->defer(
            $companyId,
            $userId,
            (string)$request->input('question_key'),
            (string)$request->input('surface','pwa'),
            $request->filled('vertical')?(string)$request->input('vertical'):null,
            $request->filled('country_code')?strtoupper((string)$request->input('country_code')):null,
        ));
    }

    /** @return array{0:int,1:int} */
    private function identity(Request $request): array
    {
        $context=$request->attributes->get('titan_onboarding_context');
        if(!$context instanceof OnboardingCompanyContext) abort(403,'Titan Onboarding company context is unavailable.');
        $user=$request->user();
        if(!$user || (int)$user->getAuthIdentifier()<=0) abort(401);
        return [$context->companyId,(int)$user->getAuthIdentifier()];
    }
}
