<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessCompetitor extends Model{protected $table='ext_onboarding_business_competitors';protected $guarded=[];protected $casts=['company_id'=>'integer','competitor_node_id'=>'integer','confidence'=>'integer','evidence'=>'array','dimensions'=>'array','owner_confirmed'=>'boolean','watched'=>'boolean','ignored'=>'boolean','last_observed_at'=>'immutable_datetime'];}
