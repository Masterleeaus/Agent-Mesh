<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Tenancy;

final class OnboardingCompanyResolver
{
    /** @param list<string> $roles @param list<string> $permissions */
    public function fromTrustedValues(
        int $companyId,
        int $userId,
        string $actorType = 'user',
        array $roles = [],
        array $permissions = [],
        string $sourceSurface = 'web',
    ): OnboardingCompanyContext {
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('Trusted company context is missing or invalid.');
        }
        if ($userId <= 0) {
            throw new \InvalidArgumentException('Trusted actor context is missing or invalid.');
        }

        return new OnboardingCompanyContext(
            $companyId,
            new OnboardingActorContext($userId, $actorType, array_values($roles), array_values($permissions), $sourceSurface),
        );
    }

    public function resolveFromUser(object $user, string $sourceSurface = 'web'): OnboardingCompanyContext
    {
        $userId = (int) ($user->id ?? 0);
        $companyId = (int) ($user->company_id ?? 0);

        // company_id is the sole authoritative company boundary. Do not synthesize
        // company identity from team_id or user_id: missing company context fails closed.

        $roles = [];
        foreach (['role', 'type'] as $field) {
            $value = $user->{$field} ?? null;
            if (is_string($value) && $value !== '') {
                $roles[] = $value;
            }
        }

        return $this->fromTrustedValues($companyId, $userId, 'user', array_values(array_unique($roles)), [], $sourceSurface);
    }
}
