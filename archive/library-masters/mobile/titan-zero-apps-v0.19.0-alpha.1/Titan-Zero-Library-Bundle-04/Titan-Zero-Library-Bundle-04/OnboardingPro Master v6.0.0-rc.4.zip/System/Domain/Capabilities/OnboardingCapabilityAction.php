<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Capabilities;
final readonly class OnboardingCapabilityAction
{
    public function __construct(public string $capabilityId,public array $payload,public string $riskLevel,public string $idempotencyKey)
    {
        if(preg_match('/^[a-z0-9][a-z0-9._-]{2,149}$/',$capabilityId)!==1) throw new \InvalidArgumentException('Capability ID is invalid.');
        if(!in_array($riskLevel,['low','medium','high','critical'],true)) throw new \InvalidArgumentException('Capability risk level is invalid.');
        if(trim($idempotencyKey)==='') throw new \InvalidArgumentException('Capability action requires idempotency key.');
    }
}
