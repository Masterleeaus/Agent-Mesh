<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\DTO;
final readonly class JourneyExecutionContext
{
    public function __construct(
        public int $companyId,
        public string $enrolmentId,
        public string $journeyVersionId,
        public string $participantId,
        public string $actorId,
        public string $actorType,
        public array $roles,
        public string $sourceSurface,
        public string $correlationId,
        public ?string $deviceId=null,
        public ?string $traceId=null,
        public ?string $causationId=null,
    ) {
        if($companyId<=0) throw new \InvalidArgumentException('Journey execution requires a positive company ID.');
        foreach([$enrolmentId,$journeyVersionId,$participantId,$actorId,$actorType,$sourceSurface,$correlationId] as $v) if(trim($v)==='') throw new \InvalidArgumentException('Journey execution context is incomplete.');
    }
    public function toInteractionContext(?string $idempotencyKey=null): array
    {
        $traceId=trim((string)$this->traceId)!==''?(string)$this->traceId:$this->correlationId;
        $causationId=trim((string)$this->causationId)!==''?(string)$this->causationId:$this->correlationId;
        return [
            'company_id'=>$this->companyId,
            'actor_id'=>$this->actorId,
            'actor_type'=>$this->actorType,
            'roles'=>array_values(array_map('strval',$this->roles)),
            'source_surface'=>'zero',
            'journey'=>'onboarding',
            'legacy_source_surface'=>$this->sourceSurface,
            'trace_id'=>$traceId,
            'correlation_id'=>$this->correlationId,
            'causation_id'=>$causationId,
            'interaction_id'=>'onboarding:'.$this->enrolmentId,
            'wizard_id'=>'onboarding:'.$this->journeyVersionId,
            'session_id'=>$this->enrolmentId,
            'device_id'=>$this->deviceId,
            'idempotency_key'=>$idempotencyKey,
            'onboarding_enrolment_id'=>$this->enrolmentId,
            'onboarding_participant_id'=>$this->participantId,
        ];
    }
}
