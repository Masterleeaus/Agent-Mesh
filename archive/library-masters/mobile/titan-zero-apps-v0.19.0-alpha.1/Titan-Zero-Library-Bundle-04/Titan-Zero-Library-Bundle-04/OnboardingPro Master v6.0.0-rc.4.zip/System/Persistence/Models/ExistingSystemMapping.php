<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class ExistingSystemMapping extends Model
{
    protected $table='ext_onboarding_existing_system_mappings';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'connection_id'=>'integer',
        'source_record'=>'array',
        'proposed_mapping'=>'array',
        'comparison'=>'array',
        'confirmed'=>'boolean',
        'confirmed_by_user_id'=>'integer',
        'confirmed_at'=>'immutable_datetime',
    ];
}
