<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Persistence\Models\NexusApprovalRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusProvisioningTransaction;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusProvisioningStep;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Support\Facades\DB;

final class NexusProvisioningTransactionService
{
    public function begin(NexusApprovalRecord $approval,array $plan,string $idempotency,OnboardingTraceContext $trace): NexusProvisioningTransaction
    {
        if((int)$approval->company_id!==$trace->companyId) throw new \RuntimeException('Cross-company provisioning transaction denied.');
        if(trim($idempotency)==='') throw new \RuntimeException('Provisioning idempotency key required.');

        return DB::transaction(function()use($approval,$plan,$idempotency,$trace){
            $existing=NexusProvisioningTransaction::query()
                ->where('company_id',$trace->companyId)->where('idempotency_key',$idempotency)->first();
            if($existing)return $existing;

            $tx=NexusProvisioningTransaction::query()->create([
                'company_id'=>$trace->companyId,'approval_id'=>(int)$approval->id,'idempotency_key'=>$idempotency,
                'status'=>'prepared','checkpoint'=>['stage'=>'prepared','completed_steps'=>[]],
                'recovery_mode'=>'forward_recovery','started_at'=>now(),
                'trace_id'=>$trace->traceId,'correlation_id'=>$trace->correlationId,
            ]);
            foreach($this->steps($plan) as $sequence=>$payload){
                NexusProvisioningStep::query()->create([
                    'company_id'=>$trace->companyId,'transaction_id'=>$tx->id,'sequence'=>$sequence+1,
                    'step_key'=>(string)($payload['step_key']??$payload['key']??'step_'.($sequence+1)),
                    'status'=>'pending','attempts'=>0,'step_payload'=>$payload,
                    'checkpoint'=>['prepared'=>true],
                    'compensation'=>(array)($payload['compensation']??[]),
                ]);
            }
            return $tx;
        },3);
    }

    public function checkpoint(NexusProvisioningTransaction $transaction,string $stage,array $context=[]): void
    {
        $transaction->checkpoint=['stage'=>$stage,'at'=>now()->toIso8601String(),'context'=>$context];
        $transaction->status=$stage;
        if($stage==='completed')$transaction->completed_at=now();
        $transaction->save();
    }

    public function fail(NexusProvisioningTransaction $transaction,\Throwable $error): void
    {
        $transaction->status='interrupted';
        $transaction->failure_context=[
            'error_class'=>$error::class,'message'=>$error->getMessage(),'at'=>now()->toIso8601String(),
            'compensation_available'=>NexusProvisioningStep::query()->where('transaction_id',$transaction->id)->whereNotNull('compensation')->exists(),
            'forward_recovery'=>true,
        ];
        $transaction->save();
    }

    /** @return list<array<string,mixed>> */
    private function steps(array $plan): array
    {
        $steps=(array)($plan['steps']??$plan['operations']??[]);
        if($steps===[]) return [['step_key'=>'nexus_atomic_execution','payload'=>$plan,'compensation'=>[]]];
        return array_values(array_filter($steps,'is_array'));
    }
}
