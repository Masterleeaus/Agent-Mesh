<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class StrategyMemory extends Model{protected $table='ext_onboarding_strategy_memories';protected $guarded=[];protected $casts=['company_id'=>'integer','intervention_outcome_id'=>'integer','context'=>'array','evidence'=>'array','delta'=>'array','confidence'=>'integer','harm'=>'boolean','applicability'=>'array','observed_at'=>'immutable_datetime','expires_at'=>'immutable_datetime'];}
