<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Notifications;
final readonly class OnboardingNotification{public function __construct(public int $companyId,public string $recipientRef,public string $type,public string $body,public string $channel,public string $capability,public string $status,public string $idempotencyKey,public string $traceId){}}
