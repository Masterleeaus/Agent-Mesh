<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\PublicWeb;
final class BusinessIdentityResolver {
 public function resolve(array $seed,array $sources):array {
  $business_name=trim((string)($seed['business_name']??''));$owner_name=trim((string)($seed['owner_name']??''));$location=trim((string)($seed['location']??''));
  $out=[];
  foreach($sources as $source){
   $score=0;$signals=[];
   foreach(['business_name'=>35,'location'=>20,'phone'=>15,'domain'=>20,'owner_name'=>10] as $key=>$weight){
    $a=strtolower(trim((string)($seed[$key]??'')));$b=strtolower(trim((string)($source[$key]??'')));
    if($a!==''&&$b!==''&&($a===$b||str_contains($b,$a)||str_contains($a,$b))){$score+=$weight;$signals[]=$key;}
   }
   $out[]=['candidate'=>$source,'identity_confidence'=>min(100,$score),'matched_signals'=>$signals,'same_name_collision'=>false];
  }
  $names=[];foreach($out as $k=>$row){$n=strtolower(trim((string)($row['candidate']['business_name']??'')));if($n!=='')$names[$n][]=$k;}
  foreach($names as $idxs)if(count($idxs)>1)foreach($idxs as $k)$out[$k]['same_name_collision']=true;
  usort($out,fn($a,$b)=>$b['identity_confidence']<=>$a['identity_confidence']);return $out;
 }
}
