<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
final class JourneyDefinitionValidator
{
    private const TYPES=['information','form','checklist','guided_tour','announcement','document','video','survey','quiz','signature','evidence','approval','payment_confirmation','booking','integration','practical_signoff','certificate','completion'];
    public function validate(array $definition): array
    {
        $errors=[];
        if(!isset($definition['key'])||!is_string($definition['key'])||trim($definition['key'])==='')$errors[]='journey_key_required';
        if(!isset($definition['version'])||!is_string($definition['version'])||preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/',$definition['version'])!==1)$errors[]='semantic_version_required';
        if(!isset($definition['steps'])||!is_array($definition['steps'])||$definition['steps']===[])$errors[]='steps_required';
        $keys=[];
        foreach(($definition['steps']??[]) as $step){
            if(!is_array($step)){ $errors[]='step_must_be_object';continue; }
            $key=(string)($step['key']??'');$type=(string)($step['type']??'');$actor=(string)($step['actor']??'');
            if($key===''||isset($keys[$key]))$errors[]=$key===''?'step_key_required':'duplicate_step_key:'.$key; else $keys[$key]=true;
            if(!in_array($type,self::TYPES,true))$errors[]='unsupported_step_type:'.$type;
            if($actor==='')$errors[]='step_actor_required:'.$key;
            if(isset($step['offline_policy'])&&!in_array($step['offline_policy'],['allowed','deferred','online_required'],true))$errors[]='invalid_offline_policy:'.$key;
        }
        return ['valid'=>$errors===[],'errors'=>array_values(array_unique($errors))];
    }
}
