<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\Platform;
final readonly class IntegrationRequest{public function __construct(public string $target,public int $companyId,public string $operation,public array $payload,public string $status,public bool $directMutation,public string $idempotencyKey,public string $traceId){}}
