<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class InterventionPriority extends Model{protected $table='ext_onboarding_intervention_priorities';protected $guarded=[];protected $casts=['company_id'=>'integer','business_opportunity_id'=>'integer','score'=>'float','factors'=>'array','blocking'=>'boolean','rationale'=>'array','active'=>'boolean'];}
