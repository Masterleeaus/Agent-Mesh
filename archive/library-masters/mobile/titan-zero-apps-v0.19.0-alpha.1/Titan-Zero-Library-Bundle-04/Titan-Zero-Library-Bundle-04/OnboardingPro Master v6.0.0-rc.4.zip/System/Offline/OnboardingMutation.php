<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Offline;
final readonly class OnboardingMutation
{
 public function __construct(public string $id,public int $companyId,public string $enrolmentId,public string $stepKey,public string $type,public array $payload,public string $deviceId,public string $baseHash,public string $idempotencyKey,public string $createdAt){}
 public static function create(int $companyId,string $enrolmentId,string $stepKey,string $type,array $payload,string $deviceId,string $baseHash):self{$seed=implode('|',[$companyId,$enrolmentId,$stepKey,$type,$deviceId,$baseHash,json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)]);$key=hash('sha256',$seed);return new self(substr($key,0,32),$companyId,$enrolmentId,$stepKey,$type,$payload,$deviceId,$baseHash,$key,gmdate(DATE_ATOM));}
 public function toInteractionOutboxCommand():array{return ['id'=>$this->id,'type'=>'onboarding.offline.mutation','payload'=>array_merge($this->payload,['_context'=>['company_id'=>$this->companyId,'actor_id'=>'device:'.$this->deviceId,'actor_type'=>'device','source_surface'=>'go','correlation_id'=>$this->id,'interaction_id'=>'onboarding:'.$this->enrolmentId,'session_id'=>$this->enrolmentId,'device_id'=>$this->deviceId,'idempotency_key'=>$this->idempotencyKey],'onboarding'=>['enrolment_id'=>$this->enrolmentId,'step_key'=>$this->stepKey,'mutation_type'=>$this->type,'base_hash'=>$this->baseHash]]),'metadata'=>['company_id'=>$this->companyId,'idempotency_key'=>$this->idempotencyKey,'queued_at'=>$this->createdAt]];}
}
