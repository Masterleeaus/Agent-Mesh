<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Controllers;

use App\Extensions\OnboardingPro\System\Persistence\Models\JourneyRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\JourneyVersionRecord;
use App\Extensions\OnboardingPro\System\Services\JourneyDefinitionValidator;
use App\Extensions\OnboardingPro\System\Services\JourneyDraftService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class JourneyAdminController extends Controller
{
    public function __construct(
        private JourneyDefinitionValidator $validator,
        private JourneyDraftService $drafts,
    ) {}

    public function index(Request $request)
    {
        $companyId = (int) $request->attributes->get('company_id');
        $rows = JourneyRecord::query()
            ->where('company_id', $companyId)
            ->orderBy('key')
            ->paginate(25);

        return view('onboarding-pro::journeys.index', ['journeys' => $rows]);
    }

    public function show(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        $row = JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);

        return view('onboarding-pro::journeys.show', ['journey' => $row]);
    }

    public function versions(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        $row = JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);
        $versions = JourneyVersionRecord::query()
            ->where('company_id', $companyId)
            ->where('journey_id', $row->id)
            ->orderByDesc('version')
            ->get();

        return view('onboarding-pro::journeys.versions', compact('row', 'versions'));
    }

    public function builder(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        $row = JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);
        $version = JourneyVersionRecord::query()
            ->where('company_id', $companyId)
            ->where('journey_id', $row->id)
            ->where('state', 'draft')
            ->latest('id')
            ->first();

        return view('onboarding-pro::builder.index', ['journey' => $row, 'version' => $version]);
    }

    public function saveDraft(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        $row = JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);
        $version = JourneyVersionRecord::query()
            ->where('company_id', $companyId)
            ->where('journey_id', $row->id)
            ->where('state', 'draft')
            ->latest('id')
            ->firstOrFail();
        $currentRevision = (int) ($version->revision ?? 0);
        $prepared = $this->drafts->prepareUpdate(
            (string) $version->state,
            $currentRevision,
            (int) $request->input('revision'),
            (array) $request->input('definition', []),
        );
        $version->forceFill([
            'definition' => $prepared['definition'],
            'revision' => $prepared['revision'],
            'content_hash' => $prepared['definition_hash'],
        ])->save();

        return response()->json([
            'status' => 'saved',
            'revision' => $prepared['revision'],
            'content_hash' => $prepared['definition_hash'],
        ]);
    }

    public function preview(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);
        $definition = (array) $request->input('definition', []);
        $result = $this->validator->validate($definition);

        return response()->json([
            'validation' => $result,
            'preview' => $result['valid'] ? $definition : null,
        ], $result['valid'] ? 200 : 422);
    }

    public function validateDefinition(Request $request, int $journey)
    {
        $companyId = (int) $request->attributes->get('company_id');
        JourneyRecord::query()
            ->where('company_id', $companyId)
            ->findOrFail($journey);
        $result = $this->validator->validate((array) $request->input('definition', []));

        return response()->json($result, $result['valid'] ? 200 : 422);
    }
}
