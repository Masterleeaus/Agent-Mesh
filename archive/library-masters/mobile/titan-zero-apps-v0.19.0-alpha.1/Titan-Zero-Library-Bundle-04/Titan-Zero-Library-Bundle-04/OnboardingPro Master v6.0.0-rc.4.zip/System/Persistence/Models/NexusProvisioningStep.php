<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class NexusProvisioningStep extends Model {
 protected $table='ext_onboarding_nexus_provisioning_steps'; protected $guarded=[];
 protected $casts=['company_id'=>'integer','transaction_id'=>'integer','sequence'=>'integer','attempts'=>'integer','step_payload'=>'array','checkpoint'=>'array','compensation'=>'array','last_error'=>'array'];
}
