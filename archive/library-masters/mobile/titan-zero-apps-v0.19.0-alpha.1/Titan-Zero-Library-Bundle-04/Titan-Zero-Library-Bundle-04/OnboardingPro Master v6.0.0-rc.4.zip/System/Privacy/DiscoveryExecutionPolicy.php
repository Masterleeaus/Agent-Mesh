<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Privacy;
final class DiscoveryExecutionPolicy{
 public function decide(int $company_id,string $workload,array $capabilities):array{
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $device=(bool)($capabilities['device']??false);$byo=(bool)($capabilities['byo']??false);$customer_paid=(bool)($capabilities['customer_paid']??false);$titan_paid=(bool)($capabilities['titan_paid']??false);
  if($device)return ['company_id'=>$company_id,'workload'=>$workload,'execution'=>'device','cost_owner'=>'customer_device'];
  if($byo)return ['company_id'=>$company_id,'workload'=>$workload,'execution'=>'byo','cost_owner'=>'customer'];
  if($customer_paid)return ['company_id'=>$company_id,'workload'=>$workload,'execution'=>'customer_paid','cost_owner'=>'customer'];
  if($titan_paid&&($capabilities['explicit_titan_opt_in']??false))return ['company_id'=>$company_id,'workload'=>$workload,'execution'=>'titan_paid','cost_owner'=>'titan'];
  throw new \RuntimeException('No permitted device-first/customer-owned execution path; Titan-paid execution requires explicit opt-in.');
 }
}
