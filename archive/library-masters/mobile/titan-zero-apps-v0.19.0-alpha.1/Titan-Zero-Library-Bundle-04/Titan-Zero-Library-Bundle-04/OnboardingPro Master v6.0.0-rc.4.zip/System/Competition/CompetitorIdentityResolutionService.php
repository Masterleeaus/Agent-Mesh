<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Competition;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessCompetitor;
final class CompetitorIdentityResolutionService
{
 public function decide(int $company_id,int $competitorId,string $decision):BusinessCompetitor
 {
  $record=BusinessCompetitor::query()->where('company_id',$company_id)->whereKey($competitorId)->firstOrFail();
  $allowed=['confirm','not_competitor','watch','ignore'];if(!in_array($decision,$allowed,true))throw new \InvalidArgumentException('Unsupported competitor decision.');
  if($decision==='confirm'){$record->owner_confirmed=true;$record->ignored=false;}
  elseif($decision==='not_competitor'){$record->classification='NOT_COMPETITOR';$record->owner_confirmed=true;$record->watched=false;}
  elseif($decision==='watch'){$record->watched=true;$record->ignored=false;}
  elseif($decision==='ignore'){$record->ignored=true;$record->watched=false;}
  $record->owner_decision=$decision;$record->save();return $record;
 }
}
