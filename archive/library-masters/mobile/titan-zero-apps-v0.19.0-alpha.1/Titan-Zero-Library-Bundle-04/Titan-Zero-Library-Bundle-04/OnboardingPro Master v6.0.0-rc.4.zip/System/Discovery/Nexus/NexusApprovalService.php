<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusApprovalRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Support\Facades\DB;
final class NexusApprovalService {
 public function approve(NexusConfigurationReview $review,int $revision,OnboardingTraceContext $trace): NexusApprovalRecord {
  if(!$review->readyForApproval()) throw new \RuntimeException('Configuration preview is not ready for approval.');
  if($trace->actorUserId===null||$trace->actorUserId<=0) throw new \RuntimeException('Owner approval requires an authenticated actor.');
  $snapshot=$review->toArray(); $fingerprint=hash('sha256',json_encode($snapshot,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
  return DB::transaction(function()use($trace,$revision,$snapshot,$fingerprint){
   $existing=NexusApprovalRecord::query()->where('company_id',$trace->companyId)->where('preview_fingerprint',$fingerprint)->first();
   if($existing)return $existing;
   return NexusApprovalRecord::query()->create(['company_id'=>$trace->companyId,'discovery_revision'=>$revision,'status'=>'approved','preview_fingerprint'=>$fingerprint,'preview_snapshot'=>$snapshot,'approved_by_user_id'=>$trace->actorUserId,'approved_at'=>now(),'trace_id'=>$trace->traceId,'correlation_id'=>$trace->correlationId]);
  },3);
 }
}
