<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Opportunity\OpportunityIntelligenceService;use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class BusinessOpportunityController extends Controller{
 public function __construct(private readonly OpportunityIntelligenceService $opportunities){}
 public function generate(Request $r){$r->validate(['candidates'=>['required','array']]);$items=$this->opportunities->generate($this->companyId($r),(array)$r->input('candidates'));return response()->json(['created'=>count($items),'opportunities'=>$items]);}
 public function latest(Request $r){return response()->json(BusinessOpportunity::query()->where('company_id',$this->companyId($r))->where('active',true)->latest('id')->limit(50)->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
