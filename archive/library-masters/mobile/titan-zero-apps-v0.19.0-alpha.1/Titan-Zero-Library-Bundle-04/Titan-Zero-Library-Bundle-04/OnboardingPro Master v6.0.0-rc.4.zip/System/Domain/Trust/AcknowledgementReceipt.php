<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Trust;

use DateTimeImmutable;
use LogicException;

final readonly class AcknowledgementReceipt
{
    private function __construct(
        public string $receiptId, public int $companyId, public int $actorId,
        public string $subjectRef, public string $policyVersion, public string $contentHash,
        public DateTimeImmutable $acknowledgedAt, public array $provenance,
    ) {}

    public static function issue(string $receiptId,int $companyId,int $actorId,string $subjectRef,string $policyVersion,string $contentHash,DateTimeImmutable $acknowledgedAt,array $provenance=[]): self
    { return new self($receiptId,$companyId,$actorId,$subjectRef,$policyVersion,strtolower($contentHash),$acknowledgedAt,$provenance); }

    public function requiresRenewalFor(string $policyVersion,string $contentHash): bool
    { return $this->policyVersion !== $policyVersion || !hash_equals($this->contentHash, strtolower($contentHash)); }

    public function withPolicyVersion(string $version): never
    { throw new LogicException('Acknowledgement receipts are immutable.'); }
}
