<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Enrolment;

final readonly class EnrolmentState
{
    /** @param array<string,StepInstanceStatus> $steps @param array<string,array<string,mixed>> $responses @param array<string,string> $completedAt */
    public function __construct(
        public int $companyId,
        public string $enrolmentId,
        public string $journeyVersionId,
        public string $participantId,
        public EnrolmentStatus $status,
        public array $steps,
        public array $responses = [],
        public array $completedAt = [],
    ) {
        if ($this->companyId <= 0) throw new \InvalidArgumentException('Enrolment company ID must be positive.');
        foreach ([$this->enrolmentId, $this->journeyVersionId, $this->participantId] as $value) if (trim($value) === '') throw new \InvalidArgumentException('Enrolment identifiers are required.');
        foreach ($this->steps as $key => $status) {
            if (!is_string($key) || !$status instanceof StepInstanceStatus) throw new \InvalidArgumentException('Invalid step state.');
        }
    }

    public function stepStatus(string $key): StepInstanceStatus
    {
        if (!isset($this->steps[$key])) throw new \InvalidArgumentException("Unknown enrolment step: {$key}");
        return $this->steps[$key];
    }

    public function assertCompany(int $companyId): void
    {
        if ($companyId !== $this->companyId) throw new \RuntimeException('Cross-company enrolment access denied.');
    }

    public function progressPercent(): int
    {
        $total = count($this->steps);
        if ($total === 0) return 100;
        $done = 0;
        foreach ($this->steps as $status) if (in_array($status, [StepInstanceStatus::Completed, StepInstanceStatus::Skipped], true)) $done++;
        return (int) round(($done / $total) * 100);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'enrolment_id' => $this->enrolmentId,
            'journey_version_id' => $this->journeyVersionId,
            'participant_id' => $this->participantId,
            'status' => $this->status->value,
            'steps' => array_map(static fn (StepInstanceStatus $s): string => $s->value, $this->steps),
            'responses' => $this->responses,
            'completed_at' => $this->completedAt,
        ];
    }

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        $steps = [];
        foreach ((array) ($payload['steps'] ?? []) as $key => $status) $steps[(string) $key] = StepInstanceStatus::from((string) $status);
        return new self(
            (int) ($payload['company_id'] ?? 0),
            (string) ($payload['enrolment_id'] ?? ''),
            (string) ($payload['journey_version_id'] ?? ''),
            (string) ($payload['participant_id'] ?? ''),
            EnrolmentStatus::from((string) ($payload['status'] ?? 'pending')),
            $steps,
            (array) ($payload['responses'] ?? []),
            (array) ($payload['completed_at'] ?? []),
        );
    }
}
