<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Journeys;

final readonly class JourneyVersion
{
    /** @param array<string,mixed> $definition */
    public function __construct(
        public int $companyId,
        public string $journeyKey,
        public int $versionNumber,
        public JourneyVersionState $state,
        public array $definition,
        public int $revision,
        public string $contentHash,
        public ?\DateTimeImmutable $publishedAt = null,
    ) {
        if ($this->companyId <= 0) throw new \InvalidArgumentException('Journey version company ID must be positive.');
        if ($this->versionNumber <= 0) throw new \InvalidArgumentException('Journey version number must be positive.');
        if ($this->revision <= 0) throw new \InvalidArgumentException('Journey revision must be positive.');
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,99}$/', $this->journeyKey) !== 1) throw new \InvalidArgumentException('Journey key is invalid.');
        if (!preg_match('/^[a-f0-9]{64}$/', $this->contentHash)) throw new \InvalidArgumentException('Journey content hash is invalid.');
        if ($this->state === JourneyVersionState::Published && $this->publishedAt === null) throw new \InvalidArgumentException('Published journey version requires publishedAt.');
    }

    /** @param array<string,mixed> $definition */
    public static function draft(int $companyId, string $journeyKey, int $versionNumber, array $definition): self
    {
        return new self($companyId, $journeyKey, $versionNumber, JourneyVersionState::Draft, $definition, 1, self::hash($definition));
    }

    /** @param array<string,mixed> $definition */
    public function revise(array $definition): self
    {
        if ($this->state !== JourneyVersionState::Draft) {
            throw new \LogicException('Only draft journey versions can be revised.');
        }
        return new self($this->companyId, $this->journeyKey, $this->versionNumber, JourneyVersionState::Draft, $definition, $this->revision + 1, self::hash($definition));
    }

    /** @param array<string,mixed> $definition */
    public function reviseIfRevision(int $expectedRevision, array $definition): self
    {
        if ($expectedRevision !== $this->revision) {
            throw new \RuntimeException('Journey draft revision conflict.');
        }
        return $this->revise($definition);
    }

    public function publish(?\DateTimeImmutable $at = null): self
    {
        if ($this->state !== JourneyVersionState::Draft) {
            throw new \LogicException('Only draft journey versions can be published.');
        }
        return new self($this->companyId, $this->journeyKey, $this->versionNumber, JourneyVersionState::Published, $this->definition, $this->revision, $this->contentHash, $at ?? new \DateTimeImmutable('now', new \DateTimeZone('UTC')));
    }

    /** @param array<string,mixed> $definition */
    public function nextDraft(array $definition): self
    {
        if (!in_array($this->state, [JourneyVersionState::Published, JourneyVersionState::Superseded], true)) {
            throw new \LogicException('A new draft can only branch from a published or superseded version.');
        }
        return self::draft($this->companyId, $this->journeyKey, $this->versionNumber + 1, $definition);
    }

    public function supersede(): self
    {
        if ($this->state !== JourneyVersionState::Published) {
            throw new \LogicException('Only a published journey version can be superseded.');
        }
        return new self($this->companyId, $this->journeyKey, $this->versionNumber, JourneyVersionState::Superseded, $this->definition, $this->revision, $this->contentHash, $this->publishedAt);
    }

    /** @param array<string,mixed> $definition */
    private static function hash(array $definition): string
    {
        $normalized = self::normalize($definition);
        return hash('sha256', json_encode($normalized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private static function normalize(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) return array_map(self::normalize(...), $value);
        ksort($value);
        foreach ($value as $key => $item) $value[$key] = self::normalize($item);
        return $value;
    }
}
