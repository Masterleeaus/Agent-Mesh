<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusApprovalRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
final readonly class NexusProvisioningPlanService {
 public function __construct(private NexusRuntimeGatewayInterface $gateway){}
 public function plan(NexusApprovalRecord $approval,OnboardingTraceContext $trace): array {
  if((int)$approval->company_id!==$trace->companyId||$approval->status!=='approved') throw new \RuntimeException('A company-matched approved preview is required before planning.');
  $snapshot=(array)$approval->preview_snapshot;
  $raw=(array)($snapshot['raw_receipt']??[]);
  if($raw===[]) throw new \RuntimeException('Approved preview snapshot lacks Nexus provenance.');
  $draft=(array)($raw['draft']??[]);
  $compiled=$this->gateway->compileDraft($draft);
  $plan=$this->gateway->planProvisioning($compiled);
  if(isset($plan['company_id'])&&(int)$plan['company_id']!==$trace->companyId) throw new \RuntimeException('Cross-company Nexus provisioning plan denied.');
  $receipt=['schema'=>'titan.onboarding-nexus-plan-receipt','version'=>'1.0','company_id'=>$trace->companyId,'approval_id'=>(int)$approval->id,'approval_fingerprint'=>(string)$approval->preview_fingerprint,'compiled'=>$compiled,'plan'=>$plan,'status'=>'PLANNED'];
  $approval->plan_receipt=$receipt; $approval->status='planned'; $approval->save();
  return $receipt;
 }
}
