<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Controllers;

use App\Extensions\OnboardingPro\System\Discovery\BusinessSetupService;
use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileConcurrencyException;
use App\Extensions\OnboardingPro\System\Discovery\DiscoveryProfileService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusConfigurationReviewService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusConfigurationReview;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusApprovalService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningPlanService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningExecutionService;
use App\Extensions\OnboardingPro\System\Discovery\Nexus\NexusProvisioningVerificationService;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusExecutionRecord;
use App\Extensions\OnboardingPro\System\Reconfiguration\BusinessReconfigurationService;
use App\Extensions\OnboardingPro\System\Persistence\Models\ReconfigurationRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusApprovalRecord;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;

final class BusinessSetupController extends Controller
{
    public function __construct(
        private BusinessSetupService $setup,
        private ?NexusConfigurationReviewService $nexusReview = null,
        private ?DiscoveryProfileService $profiles = null,
        private ?NexusApprovalService $nexusApproval = null,
        private ?NexusProvisioningPlanService $nexusPlan = null,
        private ?NexusProvisioningExecutionService $nexusExecution = null,
        private ?NexusProvisioningVerificationService $nexusVerification = null,
        private ?BusinessReconfigurationService $reconfiguration = null,
    ) {
    }

    public function show(Request $request)
    {
        $context = $this->context($request);
        $state = $this->setup->state($context->companyId);

        return view('onboarding-pro::business-setup.index', [
            'setup' => $state,
            'profile' => $state->profile,
        ]);
    }

    public function save(Request $request)
    {
        $request->validate([
            'section' => ['required', 'string', 'max:100'],
            'expected_revision' => ['nullable', 'integer', 'min:0'],
            'profile' => ['array'],
            'intent' => ['nullable', 'in:continue,later'],
        ]);

        $context = $this->context($request);
        $section = trim((string) $request->input('section', ''));
        $expectedRevision = $this->expectedRevision($request);
        $profile = $this->normaliseProfileInput((array) $request->input('profile', []));

        try {
            $state = $this->setup->saveSection(
                section: $section,
                input: $profile,
                trace: $this->trace($request, $context),
                expectedRevision: $expectedRevision,
            );
        } catch (DiscoveryProfileConcurrencyException $exception) {
            if ($request->expectsJson()) {
                return response()->json([
                    'status' => 'conflict',
                    'message' => 'Business setup changed in another session. Reload the latest revision before saving.',
                ], 409);
            }

            return redirect()->route('dashboard.onboarding.business-setup')
                ->withErrors(['setup' => 'Business setup changed in another session. Reload the page before saving again.']);
        }

        if ($request->expectsJson()) {
            return response()->json(['status' => 'saved', 'setup' => $state->toArray()]);
        }

        $destination = route('dashboard.onboarding.business-setup');
        if ((string) $request->input('intent', 'later') === 'continue') {
            $next = $this->nextSection($section);
            if ($next !== null) {
                $destination .= '#'.$next;
            }
        }

        return redirect()->to($destination)->with('status', 'Business setup saved.');
    }

    public function resolveVertical(Request $request)
    {
        $request->validate(['expected_revision' => ['nullable', 'integer', 'min:0']]);
        $context = $this->context($request);

        try {
            $state = $this->setup->resolveVertical(
                trace: $this->trace($request, $context),
                expectedRevision: $this->expectedRevision($request),
            );
        } catch (DiscoveryProfileConcurrencyException) {
            if ($request->expectsJson()) {
                return response()->json(['status' => 'conflict'], 409);
            }
            return redirect()->route('dashboard.onboarding.business-setup')
                ->withErrors(['setup' => 'Business setup changed in another session. Reload before resolving the business type.']);
        } catch (\InvalidArgumentException $exception) {
            if ($request->expectsJson()) {
                return response()->json(['status' => 'invalid', 'message' => $exception->getMessage()], 422);
            }
            return redirect()->route('dashboard.onboarding.business-setup')
                ->withErrors(['setup' => $exception->getMessage()]);
        }

        $vertical = (array) ($state->verticalResolution ?? []);
        $status = (string) ($vertical['status'] ?? 'UNAVAILABLE');
        if ($request->expectsJson()) {
            return response()->json([
                'status' => strtolower($status),
                'vertical_resolution' => $vertical,
                'setup' => $state->toArray(),
            ]);
        }

        $message = match ($status) {
            'RESOLVED' => 'Business type resolved by Titan Vertical Engine.',
            'AMBIGUOUS' => 'Titan found multiple close business-type matches. Review the candidates before provisioning.',
            default => 'Titan Vertical Engine is unavailable or not configured. Nexus provisioning remains blocked.',
        };

        return redirect()->route('dashboard.onboarding.business-setup')->with('status', $message);
    }

    public function previewNexusConfiguration(Request $request)
    {
        $context = $this->context($request);
        $state = $this->setup->state($context->companyId);
        if ($this->nexusReview === null || $this->profiles === null) {
            abort(503, 'Nexus configuration review is unavailable.');
        }
        $profile = $this->profiles->findRevision($context->companyId, $state->revision);
        if ($profile === null) {
            abort(409, 'Saved discovery profile is required before Nexus preview.');
        }
        try {
            $review = $this->nexusReview->preview($state, (int)$profile->id, $this->trace($request,$context));
        } catch (\RuntimeException $exception) {
            if ($request->expectsJson()) {
                return response()->json(['status'=>'blocked','message'=>$exception->getMessage()],422);
            }
            return redirect()->route('dashboard.onboarding.business-setup')->withErrors(['setup'=>$exception->getMessage()]);
        }
        if ($request->expectsJson()) {
            return response()->json(['status'=>'reviewed','configuration_review'=>$review->toArray()]);
        }
        return redirect()->route('dashboard.onboarding.business-setup')
            ->with('nexus_configuration_review',$review->toArray())
            ->with('status','Nexus configuration preview refreshed.');
    }

    public function approveNexusConfiguration(Request $request)
    {
        $context=$this->context($request); $state=$this->setup->state($context->companyId);
        $data=(array)$request->session()->get('nexus_configuration_review',[]);
        if($data===[]||$this->nexusApproval===null) abort(409,'Generate a current configuration preview before approval.');
        $review=new NexusConfigurationReview((string)($data['status']??''),(array)($data['summary']??[]),(array)($data['missing_extensions']??[]),(array)($data['missing_credentials']??[]),(array)($data['missing_dependencies']??[]),(array)($data['compliance_requirements']??[]),(array)($data['follow_up_questions']??[]),(array)($data['warnings']??[]),(array)($data['configuration_intelligence']??[]),(array)($data['raw_receipt']??[]));
        $approval=$this->nexusApproval->approve($review,$state->revision,$this->trace($request,$context));
        return redirect()->route('dashboard.onboarding.business-setup')->with('nexus_approval_id',(int)$approval->id)->with('status','Configuration approved. Provisioning may now be planned.');
    }

    public function planNexusProvisioning(Request $request)
    {
        $context=$this->context($request); $id=(int)$request->input('approval_id',0);
        $approval=NexusApprovalRecord::query()->where('company_id',$context->companyId)->whereKey($id)->firstOrFail();
        if($this->nexusPlan===null) abort(503,'Nexus provisioning planner unavailable.');
        $receipt=$this->nexusPlan->plan($approval,$this->trace($request,$context));
        return redirect()->route('dashboard.onboarding.business-setup')->with('nexus_plan_receipt',$receipt)->with('status','Governed provisioning plan prepared. Nothing has been executed.');
    }

    public function executeNexusProvisioning(Request $request)
    {
        $context=$this->context($request);$id=(int)$request->input('approval_id',0);
        $approval=NexusApprovalRecord::query()->where('company_id',$context->companyId)->whereKey($id)->firstOrFail();
        if($this->nexusExecution===null) abort(503,'Nexus governed execution unavailable.');
        $receipt=$this->nexusExecution->execute($approval,$this->trace($request,$context));
        $execution=NexusExecutionRecord::query()->where('company_id',$context->companyId)->latest('id')->first();
        return redirect()->route('dashboard.onboarding.business-setup')->with('nexus_execution_receipt',$receipt)->with('nexus_execution_id',$execution?->id)->with('status','Approved provisioning plan executed through Nexus governance.');
    }

    public function verifyNexusProvisioning(Request $request)
    {
        $context=$this->context($request);$id=(int)$request->input('execution_id',0);
        $execution=NexusExecutionRecord::query()->where('company_id',$context->companyId)->whereKey($id)->firstOrFail();
        if($this->nexusVerification===null)abort(503,'Provisioning verification unavailable.');
        $receipt=$this->nexusVerification->verify($execution,$this->trace($request,$context));
        return redirect()->route('dashboard.onboarding.business-setup')->with('nexus_verification_receipt',$receipt)->with('status',($receipt['operational_ready']??false)?'Business environment verified operational.':'Provisioning verified with remaining actions or gaps.');
    }

    public function previewBusinessReconfiguration(Request $request)
    {
        $context=$this->context($request);if($this->reconfiguration===null)abort(503,'Business reconfiguration unavailable.');
        $before=(array)$request->input('before',[]);$after=(array)$request->input('after',[]);$from=(int)$request->input('from_revision',0);$to=(int)$request->input('to_revision',0);
        $record=$this->reconfiguration->preview($context->companyId,$from,$to,$before,$after,$this->trace($request,$context));
        return response()->json(['status'=>'previewed','reconfiguration_id'=>$record->id,'semantic_diff'=>$record->semantic_diff,'impact_preview'=>$record->impact_preview]);
    }

    public function approveBusinessReconfiguration(Request $request)
    {
        $context=$this->context($request);$id=(int)$request->input('reconfiguration_id',0);
        $record=ReconfigurationRecord::query()->where('company_id',$context->companyId)->whereKey($id)->firstOrFail();
        $approved=$this->reconfiguration?->approve($record,(int)auth()->id(),$this->trace($request,$context));if(!$approved)abort(503);
        return response()->json(['status'=>'approved','reconfiguration_id'=>$approved->id,'approval_fingerprint'=>$approved->approval_fingerprint]);
    }

    public function executeBusinessReconfiguration(Request $request)
    {
        $context=$this->context($request);$id=(int)$request->input('reconfiguration_id',0);
        $record=ReconfigurationRecord::query()->where('company_id',$context->companyId)->whereKey($id)->firstOrFail();
        if($this->reconfiguration===null)abort(503);return response()->json($this->reconfiguration->executeAndVerify($record,$this->trace($request,$context)));
    }

    public function defer(Request $request, string $domain)
    {
        $request->validate(['expected_revision' => ['nullable', 'integer', 'min:0']]);
        $context = $this->context($request);

        try {
            $state = $this->setup->deferDomain(
                domain: $domain,
                trace: $this->trace($request, $context),
                expectedRevision: $this->expectedRevision($request),
            );
        } catch (DiscoveryProfileConcurrencyException) {
            if ($request->expectsJson()) {
                return response()->json(['status' => 'conflict'], 409);
            }
            return redirect()->route('dashboard.onboarding.business-setup')
                ->withErrors(['setup' => 'Business setup changed in another session. Reload before deferring this item.']);
        } catch (\InvalidArgumentException $exception) {
            abort(422, $exception->getMessage());
        }

        if ($request->expectsJson()) {
            return response()->json(['status' => 'deferred', 'domain' => $domain, 'setup' => $state->toArray()]);
        }

        return redirect()->route('dashboard.onboarding.business-setup')
            ->with('status', 'Optional setup item deferred.');
    }

    private function context(Request $request): OnboardingCompanyContext
    {
        $context = $request->attributes->get('titan_onboarding_context');
        if (!$context instanceof OnboardingCompanyContext) {
            abort(403, 'Titan Onboarding company context is unavailable.');
        }

        return $context;
    }

    private function expectedRevision(Request $request): ?int
    {
        if (!$request->has('expected_revision')) {
            return null;
        }

        $revision = (int) $request->input('expected_revision');
        if ($revision < 0) {
            abort(422, 'Expected revision cannot be negative.');
        }

        return $revision;
    }

    private function trace(Request $request, OnboardingCompanyContext $context): OnboardingTraceContext
    {
        $traceId = trim((string) $request->header('X-Titan-Trace-Id', '')) ?: (string) Str::uuid();
        $correlationId = trim((string) $request->header('X-Titan-Correlation-Id', '')) ?: $traceId;
        $causationId = trim((string) $request->header('X-Titan-Causation-Id', '')) ?: $traceId;

        return new OnboardingTraceContext(
            $traceId,
            $correlationId,
            $causationId,
            $context->companyId,
            $context->actor->userId,
        );
    }

    private function normaliseProfileInput(array $profile): array
    {
        foreach (['services','service_areas','job_lifecycle','communication_channels','payment_methods','equipment_assets','compliance_requirements'] as $field) {
            if (isset($profile[$field]) && is_string($profile[$field])) {
                $profile[$field] = $this->listFromText($profile[$field]);
            }
        }

        if (isset($profile['staff_roles']) && is_string($profile['staff_roles'])) {
            $profile['staff'] = ['roles' => $this->listFromText($profile['staff_roles'])];
            unset($profile['staff_roles']);
        }
        if (isset($profile['operating_hours_text']) && is_string($profile['operating_hours_text'])) {
            $profile['operating_hours'] = ['summary' => trim($profile['operating_hours_text'])];
            unset($profile['operating_hours_text']);
        }
        foreach (['ai_provider_preferences','autonomy_preferences','risk_tolerance'] as $field) {
            if (isset($profile[$field]) && is_string($profile[$field])) {
                $value = trim($profile[$field]);
                $profile[$field] = $value === '' ? [] : ['summary' => $value];
            }
        }
        if (isset($profile['privacy_preferences']) && is_string($profile['privacy_preferences'])) {
            $value = trim($profile['privacy_preferences']);
            $profile['privacy_preferences'] = $value === '' ? [] : ['summary' => $value];
        }

        return $profile;
    }

    private function nextSection(string $section): ?string
    {
        return match ($section) {
            'minimum-discovery' => 'operational-discovery',
            'operational-discovery' => 'continuous-discovery',
            default => null,
        };
    }

    /** @return list<string> */
    private function listFromText(string $value): array
    {
        return array_values(array_filter(array_map(
            static fn (string $item): string => trim($item),
            preg_split('/[\r\n,]+/', $value) ?: [],
        ), static fn (string $item): bool => $item !== ''));
    }
}
