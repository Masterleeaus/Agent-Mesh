<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Enrolment;

enum StepInstanceStatus: string
{
    case Pending = 'pending';
    case Available = 'available';
    case InProgress = 'in_progress';
    case Completed = 'completed';
    case Skipped = 'skipped';
    case Blocked = 'blocked';
}
