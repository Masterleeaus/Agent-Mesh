<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Connections;

interface ExistingSystemDiscoveryGatewayInterface
{
    /** @return array<string,mixed> */
    public function read(array $connection, array $context): array;
}
