<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Offline;
final readonly class OnboardingOfflineManifest
{
 public function __construct(public int $companyId,public string $enrolmentId,public string $journeyVersionId,public array $stepPolicies){}
 public static function fromSteps(int $companyId,string $enrolmentId,string $journeyVersionId,array $steps):self{$p=[];foreach($steps as $s){$k=(string)($s['key']??'');$v=(string)($s['offline_policy']??'online_required');if($k==='')throw new \InvalidArgumentException('Offline step key required.');if(!in_array($v,['allowed','deferred','online_required'],true))throw new \InvalidArgumentException('Invalid offline policy.');$p[$k]=$v;}return new self($companyId,$enrolmentId,$journeyVersionId,$p);}
 public function canCompleteOffline(string $stepKey):bool{return ($this->stepPolicies[$stepKey]??'online_required')==='allowed';}
 public function canQueueOffline(string $stepKey):bool{return in_array(($this->stepPolicies[$stepKey]??'online_required'),['allowed','deferred'],true);}
}
