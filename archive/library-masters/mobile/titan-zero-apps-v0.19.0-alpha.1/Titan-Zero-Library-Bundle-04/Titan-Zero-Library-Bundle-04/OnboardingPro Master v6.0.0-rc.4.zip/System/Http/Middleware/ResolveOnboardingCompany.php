<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Http\Middleware;

use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyResolver;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class ResolveOnboardingCompany
{
    public function __construct(private readonly OnboardingCompanyResolver $resolver) {}

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_unless($user, 401);

        try {
            $context = $this->resolver->resolveFromUser($user, (string) $request->attributes->get('titan_surface', 'web'));
        } catch (\InvalidArgumentException) {
            abort(403, 'Titan Onboarding company context is unavailable.');
        }

        $request->attributes->set('titan_onboarding_context', $context);
        $request->attributes->set('company_id', $context->companyId);

        return $next($request);
    }
}
