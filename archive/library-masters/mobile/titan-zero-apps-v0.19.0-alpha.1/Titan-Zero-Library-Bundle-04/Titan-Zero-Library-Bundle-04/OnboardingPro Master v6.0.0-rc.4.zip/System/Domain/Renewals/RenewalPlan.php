<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Renewals;

final readonly class RenewalPlan
{
    public function __construct(public bool $due, public string $idempotencyKey, public string $targetJourneyKey, public array $reasonCodes) {}
}
