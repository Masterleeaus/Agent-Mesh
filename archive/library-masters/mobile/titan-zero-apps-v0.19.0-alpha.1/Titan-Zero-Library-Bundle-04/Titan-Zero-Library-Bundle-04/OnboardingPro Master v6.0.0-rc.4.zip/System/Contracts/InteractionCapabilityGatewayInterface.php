<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Contracts;
interface InteractionCapabilityGatewayInterface
{
    public function status(string $capabilityId,array $context): array;
    public function execute(string $capabilityId,array $payload,array $context): array;
}
