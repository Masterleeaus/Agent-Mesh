<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Evidence;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class EvidenceRecord
{
    public function __construct(
        public string $evidenceId,
        public int $companyId,
        public string $subjectType,
        public string $subjectId,
        public string $evidenceType,
        public string $source,
        public DateTimeImmutable $capturedAt,
        public string $contentHash,
        public EvidenceClassification $classification,
        public array $provenance,
        public float $confidence,
        public string $authority,
        public ?string $jurisdiction,
        public ?DateTimeImmutable $effectiveAt = null,
        public ?DateTimeImmutable $expiresAt = null,
        public string $verificationState = 'unverified',
    ) {
        if ($companyId <= 0 || $evidenceId === '' || $subjectType === '' || $subjectId === '' || $evidenceType === '') {
            throw new InvalidArgumentException('Evidence identity and company context are required.');
        }
        if (!preg_match('/^[a-f0-9]{64}$/i', $contentHash)) {
            throw new InvalidArgumentException('Evidence content hash must be a SHA-256 hex digest.');
        }
        if ($confidence < 0.0 || $confidence > 1.0) {
            throw new InvalidArgumentException('Evidence confidence must be between 0 and 1.');
        }
    }

    public static function capture(
        string $evidenceId,
        int $companyId,
        string $subjectType,
        string $subjectId,
        string $evidenceType,
        string $source,
        DateTimeImmutable $capturedAt,
        string $contentHash,
        EvidenceClassification $classification,
        array $provenance,
        float $confidence,
        string $authority,
        ?string $jurisdiction = null,
        ?DateTimeImmutable $effectiveAt = null,
        ?DateTimeImmutable $expiresAt = null,
        string $verificationState = 'unverified',
    ): self {
        return new self($evidenceId, $companyId, $subjectType, $subjectId, $evidenceType, $source, $capturedAt, strtolower($contentHash), $classification, $provenance, $confidence, $authority, $jurisdiction, $effectiveAt, $expiresAt, $verificationState);
    }
}
