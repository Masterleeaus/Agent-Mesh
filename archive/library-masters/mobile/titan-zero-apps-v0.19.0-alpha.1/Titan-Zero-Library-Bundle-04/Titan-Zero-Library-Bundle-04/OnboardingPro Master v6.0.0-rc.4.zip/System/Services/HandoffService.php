<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
use App\Extensions\OnboardingPro\System\Domain\Participants\Handoff;
use App\Extensions\OnboardingPro\System\Domain\Participants\ParticipantAssignment;
final class HandoffService
{
 public function request(ParticipantAssignment $a,string $actorId,string $reason,?string $dueAt=null):Handoff{if($actorId!==$a->assignedActorId)throw new \RuntimeException('Only the assigned actor can receive this handoff.');return new Handoff($a->companyId,$a->enrolmentId,$a->stepKey,$actorId,$reason,'waiting',$dueAt);}
 public function complete(Handoff $h,string $actorId):Handoff{if($actorId!==$h->assignedActorId)throw new \RuntimeException('Only the assigned actor can complete this handoff.');return new Handoff($h->companyId,$h->enrolmentId,$h->stepKey,$h->assignedActorId,$h->reason,'completed',$h->dueAt,gmdate(DATE_ATOM));}
}
