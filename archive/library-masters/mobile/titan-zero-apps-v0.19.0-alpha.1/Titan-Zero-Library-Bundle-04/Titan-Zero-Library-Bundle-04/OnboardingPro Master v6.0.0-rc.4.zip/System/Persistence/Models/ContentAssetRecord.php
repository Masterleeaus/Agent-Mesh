<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;final class ContentAssetRecord extends Model{protected $table='ext_onboarding_content_assets';protected $guarded=[];protected $casts=['content'=>'array'];}
