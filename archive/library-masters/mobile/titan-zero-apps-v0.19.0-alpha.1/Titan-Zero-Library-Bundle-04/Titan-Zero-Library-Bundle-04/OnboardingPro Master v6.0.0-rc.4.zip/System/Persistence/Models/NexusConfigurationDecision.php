<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class NexusConfigurationDecision extends Model
{
    protected $table='ext_onboarding_nexus_configuration_decisions';
    protected $guarded=[];
    protected $casts=[
        'company_id'=>'integer',
        'discovery_revision'=>'integer',
        'dependencies'=>'array',
        'why'=>'array',
        'provider'=>'array',
        'risk'=>'array',
        'verification'=>'array',
        'reversible'=>'boolean',
        'requires_paid_resource'=>'boolean',
        'requires_entitlement'=>'boolean',
        'explicit_opt_in'=>'boolean',
        'blocked'=>'boolean',
        'decision_payload'=>'array',
    ];
}
