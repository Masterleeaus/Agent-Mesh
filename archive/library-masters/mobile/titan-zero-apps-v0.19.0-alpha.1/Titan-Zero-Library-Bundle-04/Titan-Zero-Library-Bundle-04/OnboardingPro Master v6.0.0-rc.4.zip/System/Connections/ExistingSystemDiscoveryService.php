<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Connections;

use App\Extensions\OnboardingPro\System\Privacy\DiscoveryConsentService;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryExecutionPolicy;
use App\Extensions\OnboardingPro\System\Evidence\EvidenceAuthorityService;
use App\Extensions\OnboardingPro\System\Persistence\Models\ExistingSystemConnection;

final readonly class ExistingSystemDiscoveryService
{
    private const SYSTEM_TYPES=['crm','accounting','booking','scheduling','calendar','email','cloud_storage','field_service','communications','customer_database','spreadsheet_export','other'];

    public function __construct(
        private ExistingSystemDiscoveryGatewayInterface $gateway,
        private DiscoveryConsentService $consents,
        private DiscoveryExecutionPolicy $executionPolicy,
        private EvidenceAuthorityService $evidenceAuthority,
    ) {}

    public function discover(int $company_id,int $userId,array $connection):array
    {
        if($company_id<=0||$userId<=0) throw new \RuntimeException('company_id and authenticated user required.');
        $this->consents->requireActive($company_id,'connected_systems','business_onboarding');

        $systemType=(string)($connection['system_type']??'');
        if(!in_array($systemType,self::SYSTEM_TYPES,true)) throw new \RuntimeException('Unsupported existing-system type.');

        $read_only=true;
        if(($connection['requested_mode']??'read_only')!=='read_only') {
            throw new \RuntimeException('Existing-system onboarding discovery is read_only only.');
        }

        $execution=$this->executionPolicy->decide($company_id,'existing_system_discovery',(array)($connection['execution_capabilities']??[]));
        $record=ExistingSystemConnection::query()->create([
            'company_id'=>$company_id,
            'user_id'=>$userId,
            'system_type'=>$systemType,
            'provider_key'=>(string)($connection['provider_key']??$systemType),
            'status'=>'reading',
            'read_only'=>$read_only,
            'connection_metadata'=>(array)($connection['metadata']??[]),
        ]);

        $receipt=$this->gateway->read($connection,[
            'company_id'=>$company_id,
            'mode'=>'read_only',
            'execution'=>$execution,
        ]);

        $candidateFactIds=[];
        foreach((array)($receipt['facts']??[]) as $fact){
            if(!is_array($fact)||trim((string)($fact['key']??''))==='') continue;
            $candidate=$this->evidenceAuthority->assess(
                $company_id,
                (string)$fact['key'],
                (array)($fact['value']??[]),
                [
                    'source_type'=>'connected_system:'.$systemType,
                    'source_reference'=>'connection:'.$record->id,
                    'source_authority'=>(int)($fact['source_authority']??80),
                    'freshness'=>(int)($fact['freshness']??90),
                    'confidence'=>(int)($fact['confidence']??75),
                    'independent_sources'=>1,
                    'sensitivity'=>(string)($fact['sensitivity']??'normal'),
                    'observed_at'=>now(),
                ],
            );
            $candidateFactIds[]=$candidate->id;
        }

        $record->status='discovered';
        $record->discovery_receipt=$receipt;
        $record->save();

        return [
            'company_id'=>$company_id,
            'connection_id'=>$record->id,
            'system_type'=>$systemType,
            'mode'=>'read_only',
            'candidate_fact_ids'=>$candidateFactIds,
            'records'=>(array)($receipt['records']??[]),
            'execution'=>$execution,
        ];
    }
}
