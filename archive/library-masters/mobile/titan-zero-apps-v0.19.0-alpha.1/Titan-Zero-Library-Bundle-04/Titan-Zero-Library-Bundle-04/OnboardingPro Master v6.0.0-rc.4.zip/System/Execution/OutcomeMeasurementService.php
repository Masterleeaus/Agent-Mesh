<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Execution;
final class OutcomeMeasurementService {
 public function measure(array $baseline,array $observed,array $measurement):array {
  $delta=[];$matched=0;
  foreach($measurement as $metric){$k=is_string($metric)?$metric:(string)($metric['key']??'');if($k!==''&&isset($baseline[$k],$observed[$k])&&is_numeric($baseline[$k])&&is_numeric($observed[$k])){$delta[$k]=(float)$observed[$k]-(float)$baseline[$k];$matched++;}}
  $confidence=count($measurement)===0?0:(int)round(($matched/count($measurement))*100);
  return compact('baseline','observed','delta','confidence','measurement');
 }
}
