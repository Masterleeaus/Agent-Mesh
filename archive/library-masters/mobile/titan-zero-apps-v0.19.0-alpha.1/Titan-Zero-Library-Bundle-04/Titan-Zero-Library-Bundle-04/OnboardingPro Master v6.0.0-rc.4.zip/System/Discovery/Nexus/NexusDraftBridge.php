<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

use App\Extensions\OnboardingPro\System\Discovery\BootstrapIntent;
use App\Extensions\OnboardingPro\System\Discovery\BootstrapIntentRepository;
use App\Extensions\OnboardingPro\System\Discovery\NexusProvisioningIntent;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class NexusDraftBridge
{
    public function __construct(
        private BootstrapIntentRepository $intents,
        private NexusRuntimeGatewayInterface $gateway,
    ) {}

    /** @return array<string,mixed> */
    public function preview(
        NexusProvisioningIntent $canonicalIntent,
        int $discoveryProfileId,
        OnboardingTraceContext $trace,
    ): array {
        $payload = $canonicalIntent->toArray();
        if ((int) ($payload['company_id'] ?? 0) !== $trace->companyId) {
            throw new \RuntimeException('Cross-company Nexus draft bridge denied.');
        }

        $operation = 'preview_business_configuration';
        $idempotencyKey = hash('sha256', $trace->companyId.'|'.$canonicalIntent->fingerprint().'|nexus|'.$operation);
        $bootstrap = BootstrapIntent::prepare('nexus', $operation, $payload, $trace, $idempotencyKey);
        $record = $this->intents->persistPrepared($trace->companyId, $discoveryProfileId, $bootstrap, $trace);

        if ($record->response_receipt !== null) {
            return (array) $record->response_receipt;
        }

        try {
            $draft = $this->gateway->newDraft($payload);
            $this->assertCompanyReceipt($draft, $trace->companyId, 'newDraft');
            $validation = $this->gateway->validateDraft($draft);
            $this->assertCompanyReceipt($validation, $trace->companyId, 'validateDraft');
            $preview = $this->gateway->previewDraft($draft);
            $this->assertCompanyReceipt($preview, $trace->companyId, 'previewDraft');

            $valid = (bool) ($validation['valid'] ?? $validation['is_valid'] ?? false);
            $status = $valid ? 'PREVIEWED' : 'BLOCKED';
            $receipt = [
                'schema' => 'titan.onboarding-nexus-draft-receipt',
                'version' => '1.0',
                'company_id' => $trace->companyId,
                'intent_fingerprint' => $canonicalIntent->fingerprint(),
                'draft' => $draft,
                'validation' => $validation,
                'preview' => $preview,
                'status' => $status,
            ];
            $this->intents->recordReceipt($trace->companyId, $idempotencyKey, $status, $receipt, $trace);
            return $receipt;
        } catch (\Throwable $e) {
            $unavailable = str_contains($e->getMessage(), 'NEXUS_UNAVAILABLE');
            $status = $unavailable ? 'UNAVAILABLE' : 'FAILED';
            $receipt = [
                'schema' => 'titan.onboarding-nexus-draft-receipt',
                'version' => '1.0',
                'company_id' => $trace->companyId,
                'intent_fingerprint' => $canonicalIntent->fingerprint(),
                'status' => $status,
                'reason_codes' => [$unavailable ? 'NEXUS_RUNTIME_UNAVAILABLE' : 'NEXUS_DRAFT_BRIDGE_FAILED'],
                'error_class' => $e::class,
            ];
            $this->intents->recordReceipt($trace->companyId, $idempotencyKey, $status, $receipt, $trace);
            if (!$unavailable) {
                throw $e;
            }
            return $receipt;
        }
    }

    private function assertCompanyReceipt(array $receipt, int $companyId, string $stage): void
    {
        if (array_key_exists('company_id', $receipt) && (int) $receipt['company_id'] !== $companyId) {
            throw new \RuntimeException("Cross-company Nexus {$stage} receipt denied.");
        }
    }
}
