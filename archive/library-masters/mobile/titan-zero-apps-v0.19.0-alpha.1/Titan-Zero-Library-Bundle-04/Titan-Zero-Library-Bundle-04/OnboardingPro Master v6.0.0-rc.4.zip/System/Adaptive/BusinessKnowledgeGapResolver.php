<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Adaptive;

final class BusinessKnowledgeGapResolver
{
    /**
     * @param array<string,mixed> $knownFacts
     * @param list<array<string,mixed>> $questions
     * @param list<string> $answered
     * @param list<string> $deferred
     * @return list<array<string,mixed>>
     */
    public function unresolved(
        array $knownFacts,
        array $questions,
        array $answered=[],
        array $deferred=[],
        ?string $vertical=null,
        ?string $countryCode=null,
    ): array {
        $answeredSet=array_fill_keys($answered,true);
        $deferredSet=array_fill_keys($deferred,true);
        $gaps=[];

        foreach ($questions as $question) {
            $key=(string)$question['key'];
            if (isset($answeredSet[$key]) || isset($deferredSet[$key])) continue;
            if (!$this->appliesToVertical($question,$vertical)) continue;
            if (!$this->appliesToJurisdiction($question,$countryCode)) continue;

            $resolved=true;
            foreach ((array)($question['resolves']??[]) as $factKey) {
                if (!$this->hasFact($knownFacts,(string)$factKey)) {
                    $resolved=false;
                    break;
                }
            }
            if ($resolved) continue;

            $dependenciesMet=true;
            foreach ((array)($question['depends_on']??[]) as $dependency) {
                if (!$this->hasFact($knownFacts,(string)$dependency)) {
                    $dependenciesMet=false;
                    break;
                }
            }

            $q=$question;
            $q['dependencies_met']=$dependenciesMet;
            $q['missing_dependencies']=array_values(array_filter(
                (array)($question['depends_on']??[]),
                fn(mixed $dependency): bool => !$this->hasFact($knownFacts,(string)$dependency),
            ));
            $gaps[]=$q;
        }
        return $gaps;
    }

    public function hasFact(array $knownFacts,string $key): bool
    {
        if (!array_key_exists($key,$knownFacts)) return false;
        $value=$knownFacts[$key];
        if ($value===null || $value==='') return false;
        if (is_array($value) && $value===[]) return false;
        return true;
    }

    private function appliesToVertical(array $question,?string $vertical): bool
    {
        $verticals=array_values((array)($question['verticals']??[]));
        if ($verticals===[]) return true;
        if ($vertical===null || trim($vertical)==='') return false;
        return in_array(strtolower(trim($vertical)),array_map(
            static fn(mixed $v): string => strtolower(trim((string)$v)),
            $verticals,
        ),true);
    }

    private function appliesToJurisdiction(array $question,?string $countryCode): bool
    {
        $jurisdictions=array_values((array)($question['jurisdictions']??[]));
        if ($jurisdictions===[]) return true;
        if ($countryCode===null || trim($countryCode)==='') return false;
        return in_array(strtoupper(trim($countryCode)),array_map(
            static fn(mixed $v): string => strtoupper(trim((string)$v)),
            $jurisdictions,
        ),true);
    }
}
