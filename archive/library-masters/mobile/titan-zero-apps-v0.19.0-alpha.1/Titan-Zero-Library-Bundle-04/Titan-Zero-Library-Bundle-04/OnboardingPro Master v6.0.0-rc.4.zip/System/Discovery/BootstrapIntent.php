<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery;

use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;

final readonly class BootstrapIntent
{
    private function __construct(
        public string $targetEngine,
        public string $operation,
        public array $payload,
        public OnboardingTraceContext $trace,
        public string $idempotencyKey,
        public string $status,
    ) {}

    public static function prepare(string $targetEngine, string $operation, array $payload, OnboardingTraceContext $trace, string $idempotencyKey): self
    {
        if (trim($targetEngine)==='' || trim($operation)==='' || trim($idempotencyKey)==='') throw new \InvalidArgumentException('Bootstrap intent target, operation and idempotency key are required.');
        return new self($targetEngine,$operation,$payload,$trace,$idempotencyKey,'PREPARED');
    }

    public function toArray(): array
    {
        return array_merge($this->trace->toArray(),[
            'target_engine'=>$this->targetEngine,
            'operation'=>$this->operation,
            'payload'=>$this->payload,
            'idempotency_key'=>$this->idempotencyKey,
            'status'=>$this->status,
            'direct_mutation'=>false,
        ]);
    }
}
