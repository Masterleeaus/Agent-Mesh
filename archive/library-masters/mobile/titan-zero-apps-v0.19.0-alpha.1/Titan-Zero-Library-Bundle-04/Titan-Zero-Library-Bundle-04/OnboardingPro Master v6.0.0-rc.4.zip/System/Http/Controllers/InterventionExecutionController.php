<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Execution\InterventionExecutionLifecycleService;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionExecution;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class InterventionExecutionController extends Controller{
 public function __construct(private readonly InterventionExecutionLifecycleService $lifecycle){}
 public function start(Request $r){$r->validate(['action_id'=>['required','integer'],'baseline'=>['required','array'],'measurement'=>['required','array'],'rollback'=>['nullable','array']]);return response()->json($this->lifecycle->start($this->companyId($r),(int)$r->input('action_id'),(array)$r->input('baseline'),(array)$r->input('measurement'),(array)$r->input('rollback',[])));}
 public function measure(Request $r){$r->validate(['execution_id'=>['required','integer'],'observed'=>['required','array'],'unintended'=>['nullable','array']]);return response()->json($this->lifecycle->measure($this->companyId($r),(int)$r->input('execution_id'),(array)$r->input('observed'),(array)$r->input('unintended',[])));}
 public function latest(Request $r){return response()->json(InterventionExecution::query()->where('company_id',$this->companyId($r))->latest('id')->limit(50)->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
