<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Providers;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusWorkforceCommand;
use App\Extensions\OnboardingPro\System\Persistence\Models\ProviderActionRequest;
final readonly class ProviderActionFabric {
 public function __construct(private ProviderCapabilityRegistry $registry,private ProviderAuthorityGate $gate){}
 public function prepare(int $company_id,int $commandId,string $providerType,string $operation,array $payload,array $authority,string $idempotency):ProviderActionRequest {
  if($company_id<=0||trim($idempotency)==='')throw new \RuntimeException('company_id and idempotency required.');
  $command=NexusWorkforceCommand::query()->where('company_id',$company_id)->whereKey($commandId)->firstOrFail();
  $required=$this->registry->resolve($providerType,$operation);if(!$required)throw new \InvalidArgumentException('Unknown provider capability.');
  $decision=$this->gate->authorize($required,$authority);
  $legacy=$this->gate->legacySelfAssertedAuthorityEnabled();
  $status=$legacy?($decision['allowed']?'prepared':'blocked'):'awaiting_governance';
  $authorityContext=$legacy?$authority:[
   'authority_source'=>'platform_governance_required',
   'caller_authority_ignored'=>true,
   'required_authority'=>$required,
  ];
  return ProviderActionRequest::query()->firstOrCreate(['company_id'=>$company_id,'idempotency_key'=>$idempotency],[
   'nexus_workforce_command_id'=>$command->id,'provider_type'=>$providerType,'operation'=>$operation,'required_authority'=>$required,
   'payload'=>$payload,'evidence'=>$command->evidence,'authority_context'=>$authorityContext,'status'=>$status,
   'requires_approval'=>true,'prepared_at'=>now()
  ]);
 }
}
