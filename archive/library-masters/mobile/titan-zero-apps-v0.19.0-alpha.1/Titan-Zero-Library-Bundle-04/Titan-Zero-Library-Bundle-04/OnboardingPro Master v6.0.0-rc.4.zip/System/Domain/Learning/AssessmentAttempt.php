<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Learning;

use DateTimeImmutable;

final readonly class AssessmentAttempt
{
    public function __construct(public string $attemptId, public int $companyId, public int $subjectId, public string $assessmentKey, public int $score, public int $attemptNumber, public DateTimeImmutable $completedAt) {}
}
