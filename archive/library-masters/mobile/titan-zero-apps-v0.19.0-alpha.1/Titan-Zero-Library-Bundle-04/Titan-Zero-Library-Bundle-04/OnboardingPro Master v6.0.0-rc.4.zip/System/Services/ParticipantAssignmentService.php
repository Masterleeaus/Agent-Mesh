<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
use App\Extensions\OnboardingPro\System\Domain\Participants\ParticipantAssignment;
final class ParticipantAssignmentService
{
 public function assign(int $companyId,string $enrolmentId,string $stepKey,string $actorRole,string $actorId,array $participantMap=[]):ParticipantAssignment{return new ParticipantAssignment($companyId,$enrolmentId,$stepKey,$actorRole,$actorId,$participantMap);}
 public function canAccess(ParticipantAssignment $a,int $companyId,string $actorId,array $roles):bool{if($companyId!==$a->companyId)throw new \RuntimeException('Cross-company participant access denied.');return $actorId===$a->assignedActorId&&in_array($a->actorRole,$roles,true);}
}
