<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Connections;

final class NullExistingSystemDiscoveryGateway implements ExistingSystemDiscoveryGatewayInterface
{
    public function read(array $connection, array $context): array
    {
        throw new \RuntimeException('No read-only existing-system discovery provider configured.');
    }
}
