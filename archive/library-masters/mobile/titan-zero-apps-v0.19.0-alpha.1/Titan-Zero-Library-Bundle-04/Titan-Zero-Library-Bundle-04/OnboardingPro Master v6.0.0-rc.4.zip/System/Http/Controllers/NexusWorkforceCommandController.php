<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Workforce\NexusWorkforceCommandBridge;use App\Extensions\OnboardingPro\System\Persistence\Models\NexusWorkforceCommand;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class NexusWorkforceCommandController extends Controller{
 public function __construct(private readonly NexusWorkforceCommandBridge $bridge){}
 public function dispatch(Request $r){$r->validate(['priority_id'=>['required','integer'],'authority'=>['nullable','array']]);return response()->json($this->bridge->dispatch($this->companyId($r),(int)$r->input('priority_id'),(array)$r->input('authority',[])));}
 public function latest(Request $r){return response()->json(NexusWorkforceCommand::query()->where('company_id',$this->companyId($r))->latest('id')->limit(50)->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
