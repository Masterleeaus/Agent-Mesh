<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Learning\Certificate;
use App\Extensions\OnboardingPro\System\Domain\Learning\PracticalSignoff;
use DateTimeImmutable;

final class CertificateService
{
    public function issueIfEligible(string $certificateId,int $companyId,int $subjectId,string $courseKey,string $courseVersion,bool $theoryPassed,PracticalSignoff $practical,DateTimeImmutable $issuedAt,?DateTimeImmutable $expiresAt=null): ?Certificate
    {
        if(!$theoryPassed||!$practical->passed()||$practical->companyId!==$companyId||$practical->subjectId!==$subjectId)return null;
        $hash=hash('sha256',implode('|',[$certificateId,$companyId,$subjectId,$courseKey,$courseVersion,$issuedAt->format(DATE_ATOM),$expiresAt?->format(DATE_ATOM)??'']));
        return new Certificate($certificateId,$companyId,$subjectId,$courseKey,$courseVersion,$issuedAt,$expiresAt,$hash);
    }
}
