<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;use Illuminate\Database\Eloquent\Model;
final class BusinessDiagnosticRun extends Model{protected $table='ext_onboarding_business_diagnostic_runs';protected $guarded=[];protected $casts=['company_id'=>'integer','domain_snapshot'=>'array','summary'=>'array','started_at'=>'immutable_datetime','completed_at'=>'immutable_datetime'];}
