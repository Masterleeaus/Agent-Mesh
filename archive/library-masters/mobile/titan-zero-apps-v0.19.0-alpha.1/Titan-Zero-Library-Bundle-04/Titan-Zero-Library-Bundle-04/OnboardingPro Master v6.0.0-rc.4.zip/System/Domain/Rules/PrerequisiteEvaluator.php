<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Rules;

final class PrerequisiteEvaluator
{
    /** @param list<string> $required @param list<string> $completed @return list<string> */
    public function unmet(array $required, array $completed): array
    {
        $completedLookup = array_fill_keys($completed, true);
        $unmet = [];
        foreach ($required as $key) if (!isset($completedLookup[$key])) $unmet[] = $key;
        return $unmet;
    }
}
