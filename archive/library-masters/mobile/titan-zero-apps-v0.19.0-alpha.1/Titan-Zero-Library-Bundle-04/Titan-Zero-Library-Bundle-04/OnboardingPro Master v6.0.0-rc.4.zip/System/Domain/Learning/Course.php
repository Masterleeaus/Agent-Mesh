<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Learning;

final readonly class Course
{
    public function __construct(public string $courseKey, public int $companyId, public string $title, public array $requiredUnitKeys) {}
}
