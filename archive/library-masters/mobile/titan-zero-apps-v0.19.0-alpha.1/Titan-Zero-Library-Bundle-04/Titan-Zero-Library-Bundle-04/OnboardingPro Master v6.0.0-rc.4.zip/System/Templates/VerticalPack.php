<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Templates;
final readonly class VerticalPack{public function __construct(public string $slug,public array $journeyFamilies,public array $requirementFamilies,public array $capabilityHints=[]){}}
