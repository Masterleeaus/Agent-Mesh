<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;

final readonly class NexusConfigurationReview
{
    public function __construct(
        public string $status,
        public array $summary,
        public array $missingExtensions,
        public array $missingCredentials,
        public array $missingDependencies,
        public array $complianceRequirements,
        public array $followUpQuestions,
        public array $warnings,
        public array $configurationIntelligence,
        public array $rawReceipt,
    ) {}

    public function readyForApproval(): bool
    {
        return $this->status === 'PREVIEWED'
            && $this->missingExtensions === []
            && $this->missingCredentials === []
            && $this->missingDependencies === []
            && $this->followUpQuestions === []
            && (bool)($this->configurationIntelligence['ready_for_cost_approval'] ?? false);
    }

    public function toArray(): array
    {
        return [
            'status'=>$this->status,
            'summary'=>$this->summary,
            'missing_extensions'=>$this->missingExtensions,
            'missing_credentials'=>$this->missingCredentials,
            'missing_dependencies'=>$this->missingDependencies,
            'compliance_requirements'=>$this->complianceRequirements,
            'follow_up_questions'=>$this->followUpQuestions,
            'warnings'=>$this->warnings,
            'configuration_intelligence'=>$this->configurationIntelligence,
            'ready_for_approval'=>$this->readyForApproval(),
            'raw_receipt'=>$this->rawReceipt,
        ];
    }
}
