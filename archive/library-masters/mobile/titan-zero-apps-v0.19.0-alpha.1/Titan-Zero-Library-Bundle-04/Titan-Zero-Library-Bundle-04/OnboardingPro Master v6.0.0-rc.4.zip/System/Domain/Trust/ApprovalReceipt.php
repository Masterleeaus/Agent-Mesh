<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Trust;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class ApprovalReceipt
{
    private function __construct(
        public string $receiptId, public int $companyId, public int $approverActorId,
        public string $subjectRef, public string $decision, public DateTimeImmutable $decidedAt, public array $provenance,
    ) {}
    public static function issue(string $receiptId,int $companyId,int $approverActorId,string $subjectRef,string $decision,DateTimeImmutable $decidedAt,array $provenance=[]): self
    {
        if (!in_array($decision,['approved','rejected','revision_required'],true)) throw new InvalidArgumentException('Unsupported approval decision.');
        return new self($receiptId,$companyId,$approverActorId,$subjectRef,$decision,$decidedAt,$provenance);
    }
}
