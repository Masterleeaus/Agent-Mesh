<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Diagnostics;
final class ConstraintDiagnosisService
{
 public function diagnose(array $domains):array
 {
  $growth=(array)($domains['growth']??[]);$customer=(array)($domains['customer']??[]);$work=(array)($domains['work']??[]);$money=(array)($domains['money']??[]);$people=(array)($domains['people']??[]);$risk=(array)($domains['risk']??[]);
  $constraints=[];
  $leads=(float)($growth['lead_sufficiency']??0);$visibility=(float)($growth['visibility_health']??0);
  $quote_conversion=(float)($customer['quote_conversion']??1);$retention=(float)($customer['retention']??1);
  $capacity=(float)($work['capacity_utilisation']??0);$margin=(float)($money['gross_margin_health']??1);
  if($leads>=0.7&&$quote_conversion<0.5)$constraints[]=$this->item('customer','quote_conversion','Low revenue/growth may be a conversion symptom rather than a visibility constraint.',90,['lead_sufficiency'=>$leads,'quote_conversion'=>$quote_conversion],['do_not_increase_advertising'=>true,'focus'=>'quote journey']);
  if($capacity>=0.9)$constraints[]=$this->item('work','capacity','Demand growth may exceed reliable delivery capacity.',88,['capacity_utilisation'=>$capacity],['do_not_increase_advertising'=>true,'focus'=>'capacity/scheduling/people']);
  if($visibility<0.45&&$leads<0.5&&$capacity<0.85)$constraints[]=$this->item('growth','visibility','Weak visibility is consistent with insufficient lead flow.',78,['visibility'=>$visibility,'lead_sufficiency'=>$leads],['focus'=>'visibility/acquisition']);
  if($retention<0.5)$constraints[]=$this->item('customer','retention','Customer retention is weak and may be constraining lifetime value.',80,['retention'=>$retention],['focus'=>'retention/service recovery']);
  if($margin<0.45)$constraints[]=$this->item('money','margin','Margin weakness can make additional volume economically harmful.',92,['margin'=>$margin],['do_not_increase_advertising'=>true,'focus'=>'pricing/cost/mix']);
  if((float)($people['staffing_capacity']??1)<0.5)$constraints[]=$this->item('people','staffing_capacity','People capacity is below current operating requirement.',82,['staffing_capacity'=>$people['staffing_capacity']??null],['focus'=>'staffing/skills']);
  if((float)($risk['operational_risk']??0)>0.7)$constraints[]=$this->item('risk','operational_risk','Material operational risk should be reduced before accelerating growth.',90,['operational_risk'=>$risk['operational_risk']??null],['focus'=>'risk mitigation']);
  usort($constraints,fn($a,$b)=>$b['confidence']<=>$a['confidence']);return $constraints;
 }
 private function item(string $domain,string $constraint,string $symptom,int $confidence,array $evidence,array $recommendations):array{return compact('domain','constraint','symptom','confidence','evidence','recommendations')+['blocking'=>($recommendations['do_not_increase_advertising']??false)];}
}
