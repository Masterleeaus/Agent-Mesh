<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Persistence\Models;

use Illuminate\Database\Eloquent\Model;

final class DiscoveryProfileRecord extends Model
{
    protected $table = 'ext_onboarding_discovery_profiles';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'revision' => 'integer',
        'profile_payload' => 'array',
        'minimum_ready' => 'boolean',
        'operational_ready' => 'boolean',
        'remaining_domains' => 'array',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new \LogicException('Discovery profile revisions are immutable; create a new revision instead.');
        });

        static::deleting(static function (): never {
            throw new \LogicException('Discovery profile revisions are immutable and cannot be deleted through runtime persistence.');
        });
    }
}
