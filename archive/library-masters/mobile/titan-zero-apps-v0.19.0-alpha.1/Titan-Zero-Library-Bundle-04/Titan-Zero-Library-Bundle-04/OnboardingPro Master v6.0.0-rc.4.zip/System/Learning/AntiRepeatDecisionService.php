<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Learning;
use App\Extensions\OnboardingPro\System\Persistence\Models\StrategyMemory;
final class AntiRepeatDecisionService {
 public const BLOCK_REPEAT='BLOCK_REPEAT',ALLOW_RETEST='ALLOW_RETEST',ALLOW='ALLOW';
 public function decide(int $company_id,string $fingerprint,array $context):array {
  $m=StrategyMemory::query()->where('company_id',$company_id)->where('intervention_fingerprint',$fingerprint)->latest('observed_at')->first();
  if(!$m)return ['decision'=>self::ALLOW,'reason'=>'No prior matching intervention memory.'];
  $stale=$m->expires_at && $m->expires_at->isPast();$context_changed=$this->contextChanged((array)$m->context,$context);
  if($m->harm&&!$stale&&!$context_changed)return ['decision'=>self::BLOCK_REPEAT,'reason'=>'Prior matching intervention produced harm in materially similar context.','memory_id'=>$m->id];
  if($m->outcome==='failed'&&!$stale&&!$context_changed)return ['decision'=>self::BLOCK_REPEAT,'reason'=>'Prior matching intervention failed in materially similar context.','memory_id'=>$m->id];
  if($stale||$context_changed)return ['decision'=>self::ALLOW_RETEST,'reason'=>$stale?'Prior evidence is stale.':'Business context_changed; controlled retest may be valid.','memory_id'=>$m->id];
  return ['decision'=>self::ALLOW,'reason'=>'Prior evidence does not prohibit this intervention.','memory_id'=>$m->id];
 }
 private function contextChanged(array $a,array $b):bool{foreach(['vertical','service_mix','capacity_band','margin_band','market_band'] as $k)if(isset($a[$k],$b[$k])&&(string)$a[$k]!== (string)$b[$k])return true;return false;}
}
