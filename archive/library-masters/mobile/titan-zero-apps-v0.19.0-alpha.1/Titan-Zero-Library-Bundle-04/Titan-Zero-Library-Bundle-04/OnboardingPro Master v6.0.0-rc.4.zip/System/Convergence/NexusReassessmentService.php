<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Convergence;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessDiagnosticRun;
final class NexusReassessmentService {
 public function reassess(int $company_id,int $cooldownHours=24):array {
  $last=BusinessDiagnosticRun::query()->where('company_id',$company_id)->latest('completed_at')->first();
  $cooldown=max(1,$cooldownHours);
  if($last&&$last->completed_at&&$last->completed_at->gt(now()->subHours($cooldown)))return ['due'=>false,'reason'=>'cooldown','cooldown_hours'=>$cooldown,'last_run_id'=>$last->id];
  return ['due'=>true,'reason'=>'new reassessment permitted','cooldown_hours'=>$cooldown,'last_run_id'=>$last?->id];
 }
}
