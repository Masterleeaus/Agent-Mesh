<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Requirements;
final class RequirementDependencyGraph
{
    /** @var array<string,RequirementDefinition> */ private array $defs=[];
    public function __construct(array $definitions){foreach($definitions as $d){if(!$d instanceof RequirementDefinition)throw new \InvalidArgumentException('RequirementDefinition expected.');if(isset($this->defs[$d->key]))throw new \InvalidArgumentException('Duplicate requirement key.');$this->defs[$d->key]=$d;}}
    public function delta(array $applicable,array $achievements,\DateTimeImmutable $at):array
    {
        $valid=$this->validAchievementKeys($achievements,$at);$out=[];
        foreach($applicable as $key){$key=(string)$key;if(isset($valid[$key]))continue;$def=$this->defs[$key]??null;if(!$def)throw new \InvalidArgumentException("Unknown requirement: $key");$superseded=false;foreach($def->supersedes as $old)if(isset($valid[(string)$old])){$superseded=false;break;}if(!$superseded)$out[]=$key;}
        return $out;
    }
    public function unmetPrerequisites(string $key,array $achievements,\DateTimeImmutable $at):array
    {
        $def=$this->defs[$key]??throw new \InvalidArgumentException("Unknown requirement: $key");$valid=$this->validAchievementKeys($achievements,$at);$out=[];foreach($def->prerequisites as $r)if(!isset($valid[(string)$r]))$out[]=(string)$r;return $out;
    }
    private function validAchievementKeys(array $achievements,\DateTimeImmutable $at):array{$r=[];foreach($achievements as $a){if(!$a instanceof ParticipantAchievement)throw new \InvalidArgumentException('ParticipantAchievement expected.');if($a->validAt($at))$r[$a->requirementKey]=true;}return $r;}
}
