<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class NexusExecutionRecord extends Model {protected $table='ext_onboarding_nexus_executions';protected $guarded=[];protected $casts=['company_id'=>'integer','approval_id'=>'integer','execution_receipt'=>'array'];}
