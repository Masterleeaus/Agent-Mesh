<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessCandidateFact extends Model{protected $table='ext_onboarding_candidate_facts';protected $guarded=[];protected $casts=['company_id'=>'integer','confidence'=>'integer','source_authority'=>'integer','freshness'=>'integer','owner_confirmed'=>'boolean','corroborated'=>'boolean','fact_value'=>'array','conflicts_with'=>'array','observed_at'=>'immutable_datetime'];}
