<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Learning;
use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionOutcome;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionExecution;use App\Extensions\OnboardingPro\System\Persistence\Models\ProviderActionRequest;use App\Extensions\OnboardingPro\System\Persistence\Models\StrategyMemory;
final class LongitudinalStrategyMemoryService {
 public function ingest(int $company_id,int $outcomeId,array $context,int $ttlDays=180):StrategyMemory {
  $out=InterventionOutcome::query()->where('company_id',$company_id)->whereKey($outcomeId)->firstOrFail();
  $execution=InterventionExecution::query()->where('company_id',$company_id)->whereKey($out->intervention_execution_id)->firstOrFail();
  $action=ProviderActionRequest::query()->where('company_id',$company_id)->whereKey($execution->provider_action_request_id)->firstOrFail();
  $fingerprint=hash('sha256',implode('|',[$action->provider_type,$action->operation,json_encode($action->payload,JSON_UNESCAPED_SLASHES)]));
  $harm=(bool)(($out->rollback_decision['harm_signals']??0)>0||count((array)$out->unintended_effects)>0);
  $outcome=strtolower((string)$out->status)==='succeeded'?'succeeded':($harm?'harm':'failed');
  return StrategyMemory::query()->create(['company_id'=>$company_id,'intervention_outcome_id'=>$out->id,'intervention_fingerprint'=>$fingerprint,'outcome'=>$outcome,'context'=>$context,'evidence'=>['provider_action_id'=>$action->id,'execution_id'=>$execution->id],'delta'=>$out->delta,'confidence'=>$out->confidence,'harm'=>$harm,'applicability'=>['context_sensitive'=>true,'ttl_days'=>$ttlDays],'observed_at'=>now(),'expires_at'=>now()->addDays(max(1,$ttlDays))]);
 }
}
