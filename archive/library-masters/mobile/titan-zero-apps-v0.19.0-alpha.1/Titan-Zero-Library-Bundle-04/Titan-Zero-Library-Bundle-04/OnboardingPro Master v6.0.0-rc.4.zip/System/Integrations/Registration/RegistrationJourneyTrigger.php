<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\Registration;
final class RegistrationJourneyTrigger
{
    public function prepare(int $companyId,int $actorId,string $registrationRef,string $reason,array $trace): array
    {
        if($companyId<=0||$actorId<=0) throw new \InvalidArgumentException('Trusted company and actor required.');
        $key=hash('sha256',implode('|',[$companyId,$actorId,$registrationRef,$reason,'titan-business-activation-v1']));
        return ['status'=>'PREPARED','direct_mutation'=>false,'journey_key'=>'titan-business-activation-v1','trigger_type'=>'registration','trigger_ref'=>$registrationRef,'reason'=>$reason,'company_id'=>$companyId,'actor_id'=>$actorId,'trace'=>$trace,'idempotency_key'=>$key];
    }
}
