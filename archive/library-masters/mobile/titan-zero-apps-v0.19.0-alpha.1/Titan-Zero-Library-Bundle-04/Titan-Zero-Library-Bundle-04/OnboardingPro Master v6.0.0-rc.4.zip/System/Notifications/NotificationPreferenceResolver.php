<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Notifications;
final class NotificationPreferenceResolver{public function resolve(string $requested,array $allowed=['in_app','email','sms','whatsapp']):string{return in_array($requested,$allowed,true)?$requested:'in_app';}}
