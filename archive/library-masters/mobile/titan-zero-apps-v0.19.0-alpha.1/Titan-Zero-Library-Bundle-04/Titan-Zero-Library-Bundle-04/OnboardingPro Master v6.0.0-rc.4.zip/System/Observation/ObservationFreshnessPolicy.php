<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Observation;

final class ObservationFreshnessPolicy
{
 /** Sensible defaults; callers may configure less frequent schedules. */
 public function policies():array{return [
  'website'=>['ttl_hours'=>168,'priority'=>'normal'],
  'business_listing'=>['ttl_hours'=>168,'priority'=>'normal'],
  'reviews'=>['ttl_hours'=>168,'priority'=>'normal'],
  'social'=>['ttl_hours'=>168,'priority'=>'normal'],
  'competitor'=>['ttl_hours'=>336,'priority'=>'low'],
  'booking'=>['ttl_hours'=>168,'priority'=>'normal'],
  'quote_route'=>['ttl_hours'=>168,'priority'=>'normal'],
  'provider'=>['ttl_hours'=>24,'priority'=>'operational'],
  'marketplace'=>['ttl_hours'=>168,'priority'=>'normal'],
  'advertising_presence'=>['ttl_hours'=>168,'priority'=>'normal'],
 ];}

 public function due(string $source,?\DateTimeInterface $lastObservedAt,\DateTimeInterface $now):bool
 {
  $ttl=(int)($this->policies()[$source]['ttl_hours']??168);
  if($lastObservedAt===null)return true;
  return ($now->getTimestamp()-$lastObservedAt->getTimestamp())>=($ttl*3600);
 }
}
