<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\AI;
final readonly class JourneyDraftRequest{public function __construct(public int $companyId,public string $goal,public string $vertical,public string $jurisdiction,public array $requestedStepTypes,public array $requestedCapabilities,public string $traceId){}}
