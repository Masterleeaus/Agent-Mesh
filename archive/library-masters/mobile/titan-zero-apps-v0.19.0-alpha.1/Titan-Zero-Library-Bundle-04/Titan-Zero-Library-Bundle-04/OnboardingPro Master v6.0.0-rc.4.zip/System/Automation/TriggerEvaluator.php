<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Automation;
final class TriggerEvaluator{public function __construct(private TriggerRegistry $registry){}public function evaluate(string $event,int $tenant,string $subject,array $context,string $journey):TriggerEvaluation{$matched=$tenant>0&&$this->registry->supports($event)&&$subject!==''&&$journey!=='';$key=hash('sha256',implode('|',[$tenant,$event,$subject,$journey,json_encode($context,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)]));return new TriggerEvaluation($matched,$tenant,$event,$subject,$journey,$key,$context);}}
