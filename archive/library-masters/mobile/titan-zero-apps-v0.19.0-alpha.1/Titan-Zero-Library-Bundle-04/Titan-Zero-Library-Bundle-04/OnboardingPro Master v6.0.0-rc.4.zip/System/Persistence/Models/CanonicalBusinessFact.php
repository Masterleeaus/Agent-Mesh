<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class CanonicalBusinessFact extends Model{protected $table='ext_onboarding_canonical_facts';protected $guarded=[];protected $casts=['company_id'=>'integer','fact_value'=>'array','owner_confirmed'=>'boolean','verified'=>'boolean','canonical'=>'boolean','supersedes'=>'integer','evidence_ids'=>'array'];}
