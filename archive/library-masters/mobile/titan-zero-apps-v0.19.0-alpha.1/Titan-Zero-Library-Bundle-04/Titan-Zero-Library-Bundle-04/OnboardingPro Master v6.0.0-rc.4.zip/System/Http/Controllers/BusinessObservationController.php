<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Observation\ContinuousBusinessObservationService;
use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;
use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class BusinessObservationController extends Controller{
 public function __construct(private readonly ContinuousBusinessObservationService $observations){}
 public function status(Request $request){return response()->json($this->observations->plan($this->companyId($request),(array)$request->input('sources',[])));}
 public function run(Request $request){$request->validate(['signals'=>['required','array'],'sources'=>['nullable','array']]);$run=$this->observations->record($this->companyId($request),(array)$request->input('signals'),(array)$request->input('sources',[]));return response()->json(['run_id'=>$run->id,'status'=>$run->status,'summary'=>$run->summary]);}
 private function companyId(Request $request):int{$c=$request->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403,'Titan Onboarding company context unavailable.');return $c->companyId;}
}
