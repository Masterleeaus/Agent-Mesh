<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Enrolment\EnrolmentState;
use App\Extensions\OnboardingPro\System\Domain\Enrolment\EnrolmentStatus;
use App\Extensions\OnboardingPro\System\Domain\Enrolment\StepInstanceStatus;

final class JourneyProgressService
{
    /** @param list<string> $stepKeys */
    public function start(int $companyId, string $enrolmentId, string $journeyVersionId, string $participantId, array $stepKeys): EnrolmentState
    {
        if ($stepKeys === []) throw new \InvalidArgumentException('An enrolment requires at least one step.');
        $steps = [];
        foreach (array_values(array_unique($stepKeys)) as $index => $key) {
            if (trim($key) === '') throw new \InvalidArgumentException('Step keys cannot be blank.');
            $steps[$key] = $index === 0 ? StepInstanceStatus::Available : StepInstanceStatus::Pending;
        }
        return new EnrolmentState($companyId, $enrolmentId, $journeyVersionId, $participantId, EnrolmentStatus::Active, $steps);
    }

    /** @param array<string,mixed> $response */
    public function completeStep(EnrolmentState $state, string $stepKey, array $response, ?\DateTimeImmutable $at = null): EnrolmentState
    {
        $current = $state->stepStatus($stepKey);
        if ($current === StepInstanceStatus::Completed || $current === StepInstanceStatus::Skipped) throw new \LogicException("Step already terminal: {$stepKey}");
        if (!in_array($current, [StepInstanceStatus::Available, StepInstanceStatus::InProgress], true)) throw new \LogicException("Step is not available: {$stepKey}");

        $steps = $state->steps;
        $steps[$stepKey] = StepInstanceStatus::Completed;
        $keys = array_keys($steps);
        $position = array_search($stepKey, $keys, true);
        if ($position !== false) {
            for ($i = $position + 1, $count = count($keys); $i < $count; $i++) {
                if ($steps[$keys[$i]] === StepInstanceStatus::Pending) {
                    $steps[$keys[$i]] = StepInstanceStatus::Available;
                    break;
                }
            }
        }

        $responses = $state->responses;
        $responses[$stepKey] = $response;
        $completedAt = $state->completedAt;
        $completedAt[$stepKey] = ($at ?? new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format(DATE_ATOM);
        $terminal = true;
        foreach ($steps as $status) if (!in_array($status, [StepInstanceStatus::Completed, StepInstanceStatus::Skipped], true)) { $terminal = false; break; }

        return new EnrolmentState(
            $state->companyId,
            $state->enrolmentId,
            $state->journeyVersionId,
            $state->participantId,
            $terminal ? EnrolmentStatus::Completed : EnrolmentStatus::Active,
            $steps,
            $responses,
            $completedAt,
        );
    }
}
