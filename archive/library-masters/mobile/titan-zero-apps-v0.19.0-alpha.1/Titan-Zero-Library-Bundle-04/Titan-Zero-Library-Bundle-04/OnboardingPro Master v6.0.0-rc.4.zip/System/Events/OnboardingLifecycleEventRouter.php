<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Events;
final class OnboardingLifecycleEventRouter{
 public function route(string $event,array $payload):array{
  $companyId=(int)($payload['company_id']??0);if($companyId<=0)throw new \RuntimeException('company_id is required for onboarding lifecycle events.');
  $map=[
   'company.created'=>['journey'=>'business_setup','responsibility'=>'onboarding_manager','action'=>'start'],
   'employee.created'=>['journey'=>'staff_onboarding','responsibility'=>'training_assistant','action'=>'start'],
   'contractor.invited'=>['journey'=>'contractor_onboarding','responsibility'=>'training_assistant','action'=>'start'],
   'customer.service.changed'=>['journey'=>'business_rediscovery','responsibility'=>'setup_assistant','action'=>'reassess'],
   'credential.expiring'=>['journey'=>'credential_renewal','responsibility'=>'renewal_assistant','action'=>'start'],
   'employee.role.changed'=>['journey'=>'role_transition','responsibility'=>'training_assistant','action'=>'reassess'],
  ];
  if(!isset($map[$event]))return [];
  return $map[$event]+['company_id'=>$companyId,'source_event'=>$event,'subject_id'=>$payload['subject_id']??null,'correlation_id'=>$payload['correlation_id']??null];
 }
 public function supportedEvents():array{return ['company.created','employee.created','contractor.invited','customer.service.changed','credential.expiring','employee.role.changed'];}
}
