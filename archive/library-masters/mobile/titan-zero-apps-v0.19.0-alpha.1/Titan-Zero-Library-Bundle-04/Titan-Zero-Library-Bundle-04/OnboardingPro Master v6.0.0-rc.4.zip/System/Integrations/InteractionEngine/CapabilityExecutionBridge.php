<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Integrations\InteractionEngine;
use App\Extensions\OnboardingPro\System\Contracts\InteractionCapabilityGatewayInterface;
use App\Extensions\OnboardingPro\System\Domain\Capabilities\CapabilityActionReceipt;
use App\Extensions\OnboardingPro\System\Domain\Capabilities\OnboardingCapabilityAction;
use App\Extensions\OnboardingPro\System\Domain\Capabilities\OnboardingCapabilityPolicy;
use App\Extensions\OnboardingPro\System\DTO\JourneyExecutionContext;
final class CapabilityExecutionBridge
{
    public function __construct(private readonly InteractionCapabilityGatewayInterface $gateway,private readonly OnboardingCapabilityPolicy $policy){}
    public function execute(OnboardingCapabilityAction $action,JourneyExecutionContext $ctx,array $approvalEvidence=[]): CapabilityActionReceipt
    {
        $this->policy->assertAllowed($action,$approvalEvidence);
        $context=$ctx->toInteractionContext($action->idempotencyKey);
        $status=$this->gateway->status($action->capabilityId,$context);
        if(($status['availability']??'unavailable')!=='available') throw new \RuntimeException('Onboarding capability is unavailable for the active company.');
        $payload=$action->payload;
        $payload['_context']=$context;
        if($approvalEvidence!==[]) $payload['_approval']=$approvalEvidence;
        $r=$this->gateway->execute($action->capabilityId,$payload,$context);
        return new CapabilityActionReceipt((string)($r['status']??'failed'),$action->capabilityId,(string)($r['provider']??'unknown'),$action->idempotencyKey,$r,$approvalEvidence,gmdate(DATE_ATOM));
    }
}
