<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\PublicWeb;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessDiscoveryEvidence;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessIdentityCandidate;
use App\Extensions\OnboardingPro\System\Privacy\DiscoveryConsentService;
final readonly class PublicBusinessDiscoveryService {
 public function __construct(private BusinessIdentityResolver $resolver, private ?DiscoveryConsentService $consents=null){}
 public function discover(int $company_id,array $seed,array $publicSources,array $consent):array {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  if(($consent['public_internet_discovery']??false)!==true)throw new \RuntimeException('Explicit public internet discovery consent required.');
  if($this->consents!==null)$this->consents->requireActive($company_id,'public_internet',(string)($consent['purpose']??'business_onboarding'));
  $candidates=$this->resolver->resolve($seed,$publicSources);
  foreach($publicSources as $source)BusinessDiscoveryEvidence::query()->create([
   'company_id'=>$company_id,'source_type'=>(string)($source['source_type']??'public_web'),
   'source_reference'=>(string)($source['source_reference']??''),'observed_at'=>$source['observed_at']??now(),
   'evidence_payload'=>$source,'consent_scope'=>'public_internet_discovery'
  ]);
  foreach($candidates as $candidate)BusinessIdentityCandidate::query()->create([
   'company_id'=>$company_id,'identity_confidence'=>$candidate['identity_confidence'],
   'same_name_collision'=>$candidate['same_name_collision'],'candidate_payload'=>$candidate
  ]);
  return ['company_id'=>$company_id,'candidate_count'=>count($candidates),'candidates'=>$candidates,'consent'=>'public_internet_discovery'];
 }
}
