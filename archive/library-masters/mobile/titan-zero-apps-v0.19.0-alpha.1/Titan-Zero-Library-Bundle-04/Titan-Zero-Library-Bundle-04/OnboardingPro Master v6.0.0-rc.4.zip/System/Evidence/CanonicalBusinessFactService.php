<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Evidence;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessCandidateFact;
use App\Extensions\OnboardingPro\System\Persistence\Models\CanonicalBusinessFact;
final class CanonicalBusinessFactService{
 public function promote(BusinessCandidateFact $candidate,bool $owner_confirmed=false,bool $verified=false):CanonicalBusinessFact{
  $company_id=(int)$candidate->company_id;if($company_id<=0)throw new \RuntimeException('company_id required.');
  if((array)$candidate->conflicts_with!==[]&&!$owner_confirmed&&!$verified)throw new \RuntimeException('Conflicting evidence requires owner confirmation or verification.');
  $sensitive=in_array((string)$candidate->sensitivity,['sensitive','compliance','financial'],true);
  if($sensitive&&!$verified&&!$owner_confirmed)throw new \RuntimeException('Sensitive fact requires confirmation or verification.');
  if(!$verified&&!$owner_confirmed&&(int)$candidate->confidence<80)throw new \RuntimeException('Insufficient authority to promote candidate fact.');
  $previous=CanonicalBusinessFact::query()->where('company_id',$company_id)->where('fact_key',$candidate->fact_key)->where('canonical',true)->latest('id')->first();
  if($previous){$previous->canonical=false;$previous->save();}
  return CanonicalBusinessFact::query()->create(['company_id'=>$company_id,'fact_key'=>$candidate->fact_key,'fact_value'=>$candidate->fact_value,'owner_confirmed'=>$owner_confirmed,'verified'=>$verified,'canonical'=>true,'supersedes'=>$previous?->id,'evidence_ids'=>[$candidate->id],'verification_status'=>$verified?'verified':($owner_confirmed?'owner_confirmed':'corroborated')]);
 }
}
