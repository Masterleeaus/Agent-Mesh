<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Agents;
final class EvidenceAssistant extends OnboardingManager{}
