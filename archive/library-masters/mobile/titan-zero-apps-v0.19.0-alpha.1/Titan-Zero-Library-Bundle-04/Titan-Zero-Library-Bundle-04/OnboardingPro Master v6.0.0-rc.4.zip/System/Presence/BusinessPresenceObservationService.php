<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Presence;

use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessPresenceObservation;

final class BusinessPresenceObservationService
{
    public function create(
        int $company_id,
        int $auditId,
        string $observation,
        string $status,
        int $confidence,
        array $evidence=[],
        array $payload=[],
    ): BusinessPresenceObservation {
        if($company_id<=0||$auditId<=0) throw new \RuntimeException('company_id and audit id required.');
        if(trim($observation)==='') throw new \InvalidArgumentException('Observation code required.');
        if($evidence===[]) throw new \RuntimeException('Presence observations require supporting evidence.');

        return BusinessPresenceObservation::query()->create([
            'company_id'=>$company_id,
            'audit_id'=>$auditId,
            'observation_code'=>$observation,
            'status'=>$status,
            'confidence'=>max(0,min(100,$confidence)),
            'evidence'=>$evidence,
            'observation_payload'=>$payload,
            'observed_at'=>now(),
        ]);
    }
}
