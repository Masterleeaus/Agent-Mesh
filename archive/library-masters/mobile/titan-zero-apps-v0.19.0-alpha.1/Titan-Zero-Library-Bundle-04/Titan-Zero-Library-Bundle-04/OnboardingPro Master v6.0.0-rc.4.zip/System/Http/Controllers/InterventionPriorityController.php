<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Prioritisation\InterventionPrioritisationService;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionPriority;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class InterventionPriorityController extends Controller{
 public function __construct(private readonly InterventionPrioritisationService $priorities){}
 public function run(Request $r){$items=$this->priorities->run($this->companyId($r),(array)$r->input('factors',[]));return response()->json(['count'=>count($items),'priorities'=>$items]);}
 public function latest(Request $r){return response()->json(InterventionPriority::query()->where('company_id',$this->companyId($r))->where('active',true)->orderBy('blocking')->orderByDesc('score')->get());}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
