<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Learning;

final readonly class Assessment
{
    public function __construct(public string $assessmentKey, public int $companyId, public int $passingScore, public int $maxAttempts) {}
}
