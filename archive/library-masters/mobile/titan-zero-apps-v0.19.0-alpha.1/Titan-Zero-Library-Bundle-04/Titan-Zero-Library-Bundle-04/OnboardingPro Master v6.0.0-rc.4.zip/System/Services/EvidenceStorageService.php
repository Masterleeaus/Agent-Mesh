<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use RuntimeException;

final readonly class EvidenceStorageService
{
    public function __construct(private object $filesystem) {}

    public function privatePath(int $companyId, string $evidenceId, string $filename): string
    {
        if ($companyId <= 0 || $evidenceId === '') throw new RuntimeException('Company and evidence ID are required.');
        $safe = preg_replace('/[^A-Za-z0-9._-]+/', '-', basename($filename)) ?: 'evidence.bin';
        return sprintf('titan/onboarding/%d/evidence/%s/%s', $companyId, $evidenceId, $safe);
    }
}
