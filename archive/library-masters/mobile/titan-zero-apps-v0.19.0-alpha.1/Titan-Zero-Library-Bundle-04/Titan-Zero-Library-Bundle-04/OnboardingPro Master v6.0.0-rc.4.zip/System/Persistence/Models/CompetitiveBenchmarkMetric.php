<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class CompetitiveBenchmarkMetric extends Model{protected $table='ext_onboarding_competitive_benchmark_metrics';protected $guarded=[];protected $casts=['company_id'=>'integer','benchmark_run_id'=>'integer','business_value'=>'float','cohort_median'=>'float','cohort_prevalence'=>'float','deviation'=>'float','confidence'=>'integer','meaningful'=>'boolean','evidence'=>'array'];}
