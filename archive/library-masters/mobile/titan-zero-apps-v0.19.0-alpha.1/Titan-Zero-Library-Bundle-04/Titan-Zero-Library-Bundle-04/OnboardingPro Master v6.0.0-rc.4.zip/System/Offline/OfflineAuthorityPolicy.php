<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Offline;
final class OfflineAuthorityPolicy
{
    public function effectiveCeiling(int $onlineAuthority,int $workflowOfflineCeiling,int $capabilityOfflineCeiling):int
    {return min($onlineAuthority,$workflowOfflineCeiling,$capabilityOfflineCeiling);}
    public function mayExecute(int $onlineAuthority,int $workflowOfflineCeiling,int $capabilityOfflineCeiling,int $requiredAuthority):bool
    {return $requiredAuthority <= $this->effectiveCeiling($onlineAuthority,$workflowOfflineCeiling,$capabilityOfflineCeiling);}
}
