<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Discovery\Nexus;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusApprovalRecord;
use App\Extensions\OnboardingPro\System\Persistence\Models\NexusExecutionRecord;
use App\Extensions\OnboardingPro\System\Tracing\OnboardingTraceContext;
use Illuminate\Support\Facades\DB;
final readonly class NexusProvisioningExecutionService {
 public function __construct(
  private NexusRuntimeGatewayInterface $gateway,
  private NexusProvisioningTransactionService $transaction,
  private NexusProvisioningRecoveryService $recovery,
 ){}
 public function execute(NexusApprovalRecord $approval,OnboardingTraceContext $trace): array {
  if((int)$approval->company_id!==$trace->companyId||$approval->status!=='planned') throw new \RuntimeException('A company-matched planned approval is required before execution.');
  $plan=(array)$approval->plan_receipt;if($plan===[])throw new \RuntimeException('Governed provisioning plan is missing.');
  $authoritative_writes=(array)($plan['plan']['authoritative_writes']??[]);
  foreach($authoritative_writes as $write){if(is_array($write)&&(($write['mode']??'')==='direct'))throw new \RuntimeException('DIRECT_EXTENSION_WRITE_FORBIDDEN: extension-owned domains must be changed through their public capability/command boundary.');}
  $idempotency_key=hash('sha256',$trace->companyId.'|'.(string)$approval->preview_fingerprint.'|'.hash('sha256',json_encode($plan,JSON_THROW_ON_ERROR)));
  $existing=NexusExecutionRecord::query()->where('company_id',$trace->companyId)->where('idempotency_key',$idempotency_key)->first();if($existing)return (array)$existing->execution_receipt;

  $tx=$this->transaction->begin($approval,(array)($plan['plan']??[]),$idempotency_key,$trace);
  try{
   $this->transaction->checkpoint($tx,'executing',['idempotency_key'=>$idempotency_key]);
   $receipt=$this->gateway->executeProvisioning((array)($plan['plan']??[]),$idempotency_key);
   if(isset($receipt['company_id'])&&(int)$receipt['company_id']!==$trace->companyId)throw new \RuntimeException('Cross-company Nexus execution receipt denied.');
   $result=DB::transaction(function()use($approval,$trace,$idempotency_key,$receipt,$tx){
    $record=NexusExecutionRecord::query()->create(['company_id'=>$trace->companyId,'approval_id'=>(int)$approval->id,'idempotency_key'=>$idempotency_key,'status'=>(string)($receipt['status']??'EXECUTED'),'execution_receipt'=>$receipt,'trace_id'=>$trace->traceId,'correlation_id'=>$trace->correlationId]);
    $approval->status='executed';$approval->save();$tx->execution_id=$record->id;$tx->save();return $receipt;
   },3);
   $this->transaction->checkpoint($tx,'completed',['execution_status'=>(string)($receipt['status']??'EXECUTED')]);
   return $result;
  }catch(\Throwable $error){
   $this->transaction->fail($tx,$error);
   $this->recovery->classify($tx,$error);
   throw $error;
  }
 }
}
