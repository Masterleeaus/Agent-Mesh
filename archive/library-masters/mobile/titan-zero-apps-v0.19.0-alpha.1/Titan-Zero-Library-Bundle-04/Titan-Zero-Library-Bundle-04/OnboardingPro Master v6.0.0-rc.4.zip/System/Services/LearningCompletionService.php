<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Services;

use App\Extensions\OnboardingPro\System\Domain\Learning\Assessment;
use App\Extensions\OnboardingPro\System\Domain\Learning\AssessmentAttempt;
use App\Extensions\OnboardingPro\System\Domain\Learning\Course;

final class LearningCompletionService
{
    public function assessmentPassed(Assessment $assessment, AssessmentAttempt $attempt): bool
    { return $assessment->companyId === $attempt->companyId && $assessment->assessmentKey === $attempt->assessmentKey && $attempt->attemptNumber <= $assessment->maxAttempts && $attempt->score >= $assessment->passingScore; }
    public function courseComplete(Course $course, array $completionByUnitKey): bool
    { foreach($course->requiredUnitKeys as $key){ if(($completionByUnitKey[$key]??false)!==true)return false; } return true; }
}
