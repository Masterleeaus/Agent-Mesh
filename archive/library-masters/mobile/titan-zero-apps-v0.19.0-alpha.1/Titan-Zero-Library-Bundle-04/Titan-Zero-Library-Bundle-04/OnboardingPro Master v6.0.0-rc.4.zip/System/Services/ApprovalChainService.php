<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Services;
use App\Extensions\OnboardingPro\System\Domain\Trust\ApprovalReceipt;
final class ApprovalChainService
{
    public function approve(string $receiptId,int $actorId,int $companyId,string $subjectRef,array $context,\DateTimeImmutable $at):ApprovalReceipt
    {
        if($companyId!==(int)($context['company_id']??0)) throw new \DomainException('Approval company mismatch.');
        if($actorId!==(int)($context['required_actor_id']??0)) throw new \DomainException('Approval actor is not authorized for this step.');
        if(($context['separation_of_duties']??false)===true && $actorId===(int)($context['subject_actor_id']??-1)) throw new \DomainException('Self-approval is prohibited by separation of duties.');
        if((string)($context['journey_version_id']??'')!==(string)($context['active_journey_version_id']??'')) throw new \DomainException('Approval references a stale journey version.');
        if(($context['authority_revoked']??false)===true) throw new \DomainException('Approver authority has been revoked.');
        return ApprovalReceipt::issue($receiptId,$companyId,$actorId,$subjectRef,'approved',$at,$context);
    }
    public function delete(ApprovalReceipt $receipt):never{throw new \LogicException('Approval receipts are append-only and cannot be deleted.');}
    public function replace(ApprovalReceipt $receipt,string $decision):never{throw new \LogicException('Approval receipts are immutable; append a superseding decision receipt instead.');}
}
