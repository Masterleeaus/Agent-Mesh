<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Analytics;
final class BottleneckAnalyzer
{
    /** @param array<int,array<string,mixed>> $steps */
    public function rank(array $steps): array
    {
        foreach($steps as &$s){$started=max(1,(int)($s['started']??0));$completed=max(0,(int)($s['completed']??0));$drop=max(0.0,1-($completed/$started));$duration=max(0,(int)($s['median_seconds']??0));$s['bottleneck_score']=round(($drop*1000)+log(1+$duration),6);}unset($s);
        usort($steps,static fn(array $a,array $b):int=>($b['bottleneck_score']<=>$a['bottleneck_score'])?:strcmp((string)($a['step_key']??''),(string)($b['step_key']??'')));
        return $steps;
    }
}
