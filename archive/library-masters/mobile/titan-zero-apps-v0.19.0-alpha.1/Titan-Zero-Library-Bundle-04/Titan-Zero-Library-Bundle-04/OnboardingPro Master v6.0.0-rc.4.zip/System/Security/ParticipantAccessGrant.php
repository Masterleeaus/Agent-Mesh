<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Security;
final readonly class ParticipantAccessGrant
{
    public function __construct(public int $companyId,public int $enrolmentId,public int $participantId,public array $allowedSteps,public \DateTimeImmutable $issuedAt,public \DateTimeImmutable $expiresAt,public string $nonce,public string $signature){}
    public function allowsStep(string $key): bool {return in_array($key,$this->allowedSteps,true);}
    public function withCompanyId(int $companyId): self{return new self($companyId,$this->enrolmentId,$this->participantId,$this->allowedSteps,$this->issuedAt,$this->expiresAt,$this->nonce,$this->signature);}
    /** @deprecated Compatibility alias. Canonical company boundary is company_id. */
    public function withTenantCompanyId(int $companyId): self{return $this->withCompanyId($companyId);}
}
