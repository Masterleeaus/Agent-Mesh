<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Domain\Rules;

/**
 * Compatibility evaluator for the explicit condition forms used by Titan
 * Interaction Engine 10.3.x: exact map conditions plus `=`, `!=`, `includes`.
 * Unknown natural-language conditions preserve visibility, matching the host
 * BranchConditionEvaluator fail-open presentation behaviour; governed actions
 * still require capability policy at execution time.
 */
final class RuleEvaluator
{
    /** @param array<string,mixed>|string|null $condition @param array<string,mixed> $context */
    public function evaluate(array|string|null $condition, array $context): bool
    {
        if ($condition === null || $condition === '' || $condition === []) return true;
        if (is_array($condition)) {
            foreach ($condition as $key => $expected) if (($context[$key] ?? null) !== $expected) return false;
            return true;
        }

        $condition = trim($condition);
        if (preg_match('/^([A-Za-z0-9_.]+)\s*!=\s*(.+)$/', $condition, $m) === 1) return !$this->equals($context[$m[1]] ?? null, trim($m[2]));
        if (preg_match('/^([A-Za-z0-9_.]+)\s*=\s*(.+)$/', $condition, $m) === 1) return $this->equals($context[$m[1]] ?? null, trim($m[2]));
        if (preg_match('/^([A-Za-z0-9_.]+)\s+includes\s+(.+)$/i', $condition, $m) === 1) return $this->includes($context[$m[1]] ?? null, trim($m[2]));
        return true;
    }

    private function equals(mixed $actual, string $expected): bool
    {
        if (is_bool($actual)) return $actual === $this->truthy($expected);
        if (is_int($actual) || is_float($actual)) return (string) $actual === trim($expected);
        return strtolower(trim((string) $actual)) === strtolower(trim($expected));
    }

    private function includes(mixed $actual, string $needle): bool
    {
        $values = is_array($actual) ? $actual : [$actual];
        $needle = strtolower(trim($needle));
        foreach ($values as $value) {
            $value = strtolower(trim((string) $value));
            if ($value === $needle || str_contains($value, $needle)) return true;
        }
        return false;
    }

    private function truthy(mixed $value): bool
    {
        if (is_bool($value)) return $value;
        if (is_int($value) || is_float($value)) return $value != 0;
        return in_array(strtolower(trim((string) $value)), ['1','true','yes','on','enabled'], true);
    }
}
