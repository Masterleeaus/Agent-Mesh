<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Domain\Capabilities;
final readonly class CapabilityActionReceipt
{
    public function __construct(public string $status,public string $capabilityId,public string $provider,public string $idempotencyKey,public array $result,public array $approvalEvidence,public string $executedAt){}
}
