<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Evidence;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessCandidateFact;
final class EvidenceAuthorityService{
 public function assess(int $company_id,string $key,array $value,array $evidence):BusinessCandidateFact{
  if($company_id<=0||$key==='')throw new \RuntimeException('company_id and fact key required.');
  $source_authority=max(0,min(100,(int)($evidence['source_authority']??40)));
  $freshness=max(0,min(100,(int)($evidence['freshness']??50)));
  $confidence=max(0,min(100,(int)($evidence['confidence']??50)));
  $independent=max(1,(int)($evidence['independent_sources']??1));
  $corroborated=$independent>=2;
  if($corroborated)$confidence=min(100,$confidence+10);
  $conflicts_with=array_values((array)($evidence['conflicts_with']??[]));
  $sensitivity=(string)($evidence['sensitivity']??'normal');
  return BusinessCandidateFact::query()->create(['company_id'=>$company_id,'fact_key'=>$key,'fact_value'=>$value,'source_type'=>(string)($evidence['source_type']??'unknown'),'source_reference'=>(string)($evidence['source_reference']??''),'source_authority'=>$source_authority,'freshness'=>$freshness,'confidence'=>$confidence,'corroborated'=>$corroborated,'owner_confirmed'=>(bool)($evidence['owner_confirmed']??false),'verification_status'=>$corroborated?'corroborated':'candidate','sensitivity'=>$sensitivity,'conflicts_with'=>$conflicts_with,'observed_at'=>$evidence['observed_at']??now()]);
 }
}
