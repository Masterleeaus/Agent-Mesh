<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Opportunity;
final class OpportunityEvidenceService
{
 public function compile(array $observation=[],array $benchmark=[],array $additional=[]):array
 {
  $evidence=['observation'=>$observation,'benchmark'=>$benchmark,'additional'=>$additional];
  $signals=0;$quality=0;
  foreach($evidence as $group){if($group!==[]){$signals++;$quality+=(int)($group['confidence']??70);}}
  $confidence=$signals===0?0:(int)round($quality/$signals);
  return ['evidence'=>$evidence,'confidence'=>max(0,min(100,$confidence)),'signal_groups'=>$signals];
 }
}
