<?php
declare(strict_types=1);namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\Convergence\NexusLifecycleOrchestrator;use App\Extensions\OnboardingPro\System\Convergence\NexusReassessmentService;use App\Extensions\OnboardingPro\System\Tenancy\OnboardingCompanyContext;use Illuminate\Http\Request;use Illuminate\Routing\Controller;
final class NexusLifecycleController extends Controller{
 public function __construct(private readonly NexusLifecycleOrchestrator $lifecycle,private readonly NexusReassessmentService $reassessment){}
 public function status(Request $r){return response()->json($this->lifecycle->status($this->companyId($r)));}
 public function reassess(Request $r){return response()->json($this->reassessment->reassess($this->companyId($r),(int)$r->input('cooldown_hours',24)));}
 private function companyId(Request $r):int{$c=$r->attributes->get('titan_onboarding_context');if(!$c instanceof OnboardingCompanyContext)abort(403);return $c->companyId;}
}
