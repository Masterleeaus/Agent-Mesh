<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Http\Controllers;
use App\Extensions\OnboardingPro\System\AI\JourneyDraftRequest;
use App\Extensions\OnboardingPro\System\Integrations\TitanAI\TitanAIJourneyGateway;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
final class AIJourneyBuilderController{
 public function prepare(Request $request,TitanAIJourneyGateway $gateway):JsonResponse{$data=$request->validate(['goal'=>'required|string|max:2000','vertical'=>'nullable|string|max:120','jurisdiction'=>'nullable|string|max:120','step_types'=>'array','step_types.*'=>'string','capabilities'=>'array','capabilities.*'=>'string']);$tenant=(int)($request->attributes->get('company_id')??0);if($tenant<1)abort(403);$trace=(string)($request->header('X-Titan-Trace-Id')?:bin2hex(random_bytes(16)));$dto=new JourneyDraftRequest($tenant,$data['goal'],(string)($data['vertical']??''),(string)($data['jurisdiction']??''),array_values($data['step_types']??[]),array_values($data['capabilities']??[]),$trace);return response()->json($gateway->prepare($dto),202);}
}
