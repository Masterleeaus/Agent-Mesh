<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Execution;
final class RollbackDecisionService {
 public function decide(array $delta,array $unintended,string $reversibility):array {
  $harm=count(array_filter($delta,fn($v)=>is_numeric($v)&&(float)$v<0));$unintendedCount=count($unintended);
  $rollback=($harm>0||$unintendedCount>0)&&strtolower($reversibility)!=='irreversible';
  return ['rollback'=>$rollback,'harm_signals'=>$harm,'unintended_effects'=>$unintended,'reversibility'=>$reversibility,'reason'=>$rollback?'Observed harm/unintended effects and intervention is reversible.':'No governed rollback trigger.'];
 }
}
