<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Prioritisation;
use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessOpportunity;use App\Extensions\OnboardingPro\System\Persistence\Models\BusinessConstraint;use App\Extensions\OnboardingPro\System\Persistence\Models\InterventionPriority;
final readonly class InterventionPrioritisationService
{
 public const CRITICAL='CRITICAL';public const HIGH_VALUE='HIGH_VALUE';public const QUICK_WIN='QUICK_WIN';public const STRATEGIC='STRATEGIC';public const EXPERIMENTAL='EXPERIMENTAL';public const LOW_PRIORITY='LOW_PRIORITY';public const DO_NOT_ACT_YET='DO_NOT_ACT_YET';
 public function __construct(private BusinessImpactScoringService $impact){}
 public function run(int $company_id,array $factorOverrides=[]):array
 {
  if($company_id<=0)throw new \RuntimeException('company_id required.');
  $blocking=BusinessConstraint::query()->where('company_id',$company_id)->where('blocking',true)->orderByDesc('confidence')->get();
  $opportunities=BusinessOpportunity::query()->where('company_id',$company_id)->where('active',true)->get();$out=[];
  foreach($opportunities as $op){
   $f=(array)($factorOverrides[$op->id]??[]);
   $f['confidence']=$f['confidence']??((int)$op->confidence/100);
   $f['expected_benefit']=$f['expected_benefit']??$this->scalar((array)$op->expected_benefit,.5);
   $f['cost']=$f['cost']??$this->scalar((array)$op->estimated_cost,.5);
   $f['risk']=$f['risk']??$this->scalar((array)$op->risk,.5);
   $block=$this->blocked($op,$blocking);
   $scored=$this->impact->score($f);$category=$block?self::DO_NOT_ACT_YET:$this->category($scored['score'],$scored['factors']);
   $record=InterventionPriority::query()->updateOrCreate(['company_id'=>$company_id,'business_opportunity_id'=>$op->id],['category'=>$category,'score'=>$scored['score'],'factors'=>$scored['factors'],'blocking'=>$block,'rationale'=>['blocking_constraints'=>$block?$blocking->pluck('constraint_key')->values()->all():[],'principle'=>'Opportunity does not imply action.'],'active'=>true]);
   $out[]=$record;
  }
  usort($out,fn($a,$b)=>($a->blocking<=>$b->blocking)?:($b->score<=>$a->score));return $out;
 }
 private function blocked(BusinessOpportunity $op,$constraints):bool{foreach($constraints as $c){if(in_array($c->constraint_key,['capacity','margin','operational_risk'],true))return true;if($c->constraint_key==='quote_conversion'&&$op->domain==='growth')return true;}return false;}
 private function category(float $score,array $f):string{if($score>=85)return self::CRITICAL;if($score>=70)return self::HIGH_VALUE;if($score>=58&&$f['cost']<=.35&&$f['risk']<=.35)return self::QUICK_WIN;if($score>=52)return self::STRATEGIC;if($score>=38)return self::EXPERIMENTAL;return self::LOW_PRIORITY;}
 private function scalar(array $v,float $default):float{foreach(['score','value','level','normalized'] as $k)if(isset($v[$k])&&is_numeric($v[$k]))return max(0,min(1,(float)$v[$k]>1?(float)$v[$k]/100:(float)$v[$k]));return $default;}
}
