<?php

declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class JourneyVersionRecord extends Model { protected $table='ext_onboarding_journey_versions'; protected $guarded=[]; protected $casts=['definition'=>'array','published_at'=>'immutable_datetime']; }
