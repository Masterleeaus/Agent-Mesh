<?php
declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Adaptive;

final class AdaptiveQuestionCatalog
{
    /**
     * Each definition is surface-neutral. Chat, voice, vision and PWA renderers
     * can present the same governed question in their own interaction style.
     *
     * @return list<array<string,mixed>>
     */
    public function all(): array
    {
        return [
            [
                'key'=>'business_services',
                'prompt'=>'Which services does your business currently provide?',
                'target_fact'=>'services',
                'resolves'=>['services'],
                'depends_on'=>['business_identity'],
                'blocking'=>true,
                'optional'=>false,
                'information_gain'=>100,
                'verticals'=>[],
            ],
            [
                'key'=>'business_location',
                'prompt'=>'Which country and region is the business based in?',
                'target_fact'=>'jurisdiction',
                'resolves'=>['jurisdiction'],
                'depends_on'=>['business_identity'],
                'blocking'=>true,
                'optional'=>false,
                'information_gain'=>95,
                'verticals'=>[],
            ],
            [
                'key'=>'service_areas',
                'prompt'=>'Where do you currently provide those services?',
                'target_fact'=>'service_areas',
                'resolves'=>['service_areas'],
                'depends_on'=>['services'],
                'blocking'=>true,
                'optional'=>false,
                'information_gain'=>90,
                'verticals'=>[],
            ],
            [
                'key'=>'operating_hours',
                'prompt'=>'When is your business normally available for work?',
                'target_fact'=>'operating_hours',
                'resolves'=>['operating_hours'],
                'depends_on'=>['services'],
                'blocking'=>true,
                'optional'=>false,
                'information_gain'=>80,
                'verticals'=>[],
            ],
            [
                'key'=>'team_structure',
                'prompt'=>'Do you work alone, use employees, contractors, or a mix?',
                'target_fact'=>'workforce_type',
                'resolves'=>['workforce_type','staff'],
                'depends_on'=>['business_identity'],
                'blocking'=>false,
                'optional'=>false,
                'information_gain'=>85,
                'verticals'=>[],
            ],
            [
                'key'=>'pricing_model',
                'prompt'=>'How do you normally price your work?',
                'target_fact'=>'pricing_approach',
                'resolves'=>['pricing_approach'],
                'depends_on'=>['services'],
                'blocking'=>false,
                'optional'=>false,
                'information_gain'=>65,
                'verticals'=>[],
            ],
            [
                'key'=>'payment_methods',
                'prompt'=>'Which payment methods do you currently accept?',
                'target_fact'=>'payment_methods',
                'resolves'=>['payment_methods'],
                'depends_on'=>['pricing_approach'],
                'blocking'=>false,
                'optional'=>true,
                'information_gain'=>45,
                'verticals'=>[],
            ],
            [
                'key'=>'communication_channels',
                'prompt'=>'Which channels should customers use to contact the business?',
                'target_fact'=>'communication_channels',
                'resolves'=>['communication_channels'],
                'depends_on'=>['business_identity'],
                'blocking'=>false,
                'optional'=>true,
                'information_gain'=>55,
                'verticals'=>[],
            ],
            [
                'key'=>'emergency_service',
                'prompt'=>'Do you offer emergency or after-hours service?',
                'target_fact'=>'emergency_service',
                'resolves'=>['emergency_service','after_hours_policy'],
                'depends_on'=>['services','operating_hours'],
                'blocking'=>false,
                'optional'=>true,
                'information_gain'=>50,
                'verticals'=>['plumbing','electrical','hvac','locksmith-security','appliance-equipment-repair'],
            ],
            [
                'key'=>'gst_registration',
                'prompt'=>'Is this business registered for GST?',
                'target_fact'=>'gst_registered',
                'resolves'=>['gst_registered','tax_profile'],
                'depends_on'=>['jurisdiction'],
                'blocking'=>false,
                'optional'=>false,
                'information_gain'=>70,
                'verticals'=>[],
                'jurisdictions'=>['AU'],
            ],
            [
                'key'=>'compliance_credentials',
                'prompt'=>'Which licences, insurance policies or certifications does the business rely on?',
                'target_fact'=>'compliance_requirements',
                'resolves'=>['compliance_requirements'],
                'depends_on'=>['services','jurisdiction'],
                'blocking'=>false,
                'optional'=>true,
                'information_gain'=>60,
                'verticals'=>[],
            ],
            [
                'key'=>'autonomy_default',
                'prompt'=>'How much routine work should Titan handle by default?',
                'target_fact'=>'autonomy_preferences',
                'resolves'=>['autonomy_preferences'],
                'depends_on'=>['services'],
                'blocking'=>false,
                'optional'=>true,
                'information_gain'=>35,
                'verticals'=>[],
            ],
        ];
    }

    public function find(string $key): ?array
    {
        foreach ($this->all() as $question) {
            if ($question['key'] === $key) return $question;
        }
        return null;
    }
}
