<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Automation;
final class TriggerRegistry{private array $types;public function __construct(array $types){$this->types=array_fill_keys($types,true);}public static function withDefaults():self{return new self(['company.created','employee.created','contractor.invited','customer.quote.accepted','job.site.created','asset.registered','credential.expiring','employee.role.changed','customer.service.changed']);}public function supports(string $event):bool{return isset($this->types[$event]);}}
