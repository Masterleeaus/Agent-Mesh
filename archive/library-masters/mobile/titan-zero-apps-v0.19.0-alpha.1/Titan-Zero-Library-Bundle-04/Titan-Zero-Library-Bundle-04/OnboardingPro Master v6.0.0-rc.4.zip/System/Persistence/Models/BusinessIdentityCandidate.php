<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\Persistence\Models;
use Illuminate\Database\Eloquent\Model;
final class BusinessIdentityCandidate extends Model {protected $table='ext_onboarding_identity_candidates';protected $guarded=[];protected $casts=['company_id'=>'integer','identity_confidence'=>'integer','same_name_collision'=>'boolean','candidate_payload'=>'array'];}
