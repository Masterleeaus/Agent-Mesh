<?php

declare(strict_types=1);

namespace App\Extensions\OnboardingPro\System\Discovery;

final class DiscoveryProfileConcurrencyException extends \RuntimeException
{
}
