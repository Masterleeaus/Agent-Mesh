<?php
declare(strict_types=1);
namespace App\Extensions\OnboardingPro\System\AI;
final class JourneyDraftValidator{
 private const TYPES=['information','form','checklist','guided_tour','announcement','document','video','survey','quiz','signature','evidence','approval','payment_confirmation','booking','integration','practical_signoff','certificate','completion'];
 public function validate(JourneyDraftRequest $r):void{if($r->companyId<1||trim($r->goal)==='')throw new \InvalidArgumentException('Company and goal are required.');foreach($r->requestedStepTypes as $t){if(!in_array($t,self::TYPES,true))throw new \InvalidArgumentException('Unknown step type: '.$t);}foreach($r->requestedCapabilities as $c){if(!preg_match('/^[a-z0-9][a-z0-9._-]+$/',$c))throw new \InvalidArgumentException('Invalid capability ID.');}}
}
