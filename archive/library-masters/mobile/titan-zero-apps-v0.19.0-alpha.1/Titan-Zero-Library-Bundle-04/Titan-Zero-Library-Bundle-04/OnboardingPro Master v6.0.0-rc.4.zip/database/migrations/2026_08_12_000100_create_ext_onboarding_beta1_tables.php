<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {  if(!Schema::hasTable('ext_onboarding_content_assets')) Schema::create('ext_onboarding_content_assets',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eoca_company_idx');$t->string('content_key',150);$t->string('content_type',64);$t->string('source_donor',64)->nullable();$t->string('source_id',128)->nullable();$t->json('content');$t->string('status',32)->default('draft');$t->unsignedInteger('version')->default(1);$t->timestamps();$t->unique(['company_id','content_key','version'],'eoca_key_ver_uq');});
  if(!Schema::hasTable('ext_onboarding_participant_grants')) Schema::create('ext_onboarding_participant_grants',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eopg_company_idx');$t->unsignedBigInteger('enrolment_id')->index('eopg_enrol_idx');$t->unsignedBigInteger('participant_id')->index('eopg_part_idx');$t->char('token_hash',64)->unique('eopg_token_uq');$t->json('allowed_steps');$t->timestamp('expires_at');$t->timestamp('revoked_at')->nullable();$t->timestamps();});
 }
 public function down(): void {Schema::dropIfExists('ext_onboarding_participant_grants');Schema::dropIfExists('ext_onboarding_content_assets');}
};
