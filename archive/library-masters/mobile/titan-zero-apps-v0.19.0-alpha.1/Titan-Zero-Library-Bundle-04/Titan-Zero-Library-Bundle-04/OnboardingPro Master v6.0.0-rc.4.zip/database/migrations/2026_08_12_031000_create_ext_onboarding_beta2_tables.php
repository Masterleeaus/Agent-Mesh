<?php
declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{
  Schema::create('ext_onboarding_content_drafts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eocd_tenant_idx');$t->string('draft_type',64);$t->string('status',32)->default('DRAFT');$t->json('definition');$t->string('content_hash',64);$t->string('trace_id',128)->nullable();$t->timestamps();$t->unique(['company_id','content_hash'],'eocd_tenant_hash_uq');});
  Schema::create('ext_onboarding_trigger_receipts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eotr_tenant_idx');$t->string('event_type',128);$t->string('subject_ref',191);$t->string('journey_key',191);$t->string('idempotency_key',64);$t->json('context')->nullable();$t->timestamps();$t->unique(['company_id','idempotency_key'],'eotr_tenant_idem_uq');});
  Schema::create('ext_onboarding_agent_tasks',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eoat_tenant_idx');$t->string('role',96);$t->string('subject_ref',191);$t->string('capability',191);$t->string('status',32)->default('PREPARED');$t->string('idempotency_key',64);$t->string('trace_id',128)->nullable();$t->json('payload')->nullable();$t->timestamps();$t->unique(['company_id','idempotency_key'],'eoat_tenant_idem_uq');});
  Schema::create('ext_onboarding_notification_receipts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eonr_tenant_idx');$t->string('recipient_ref',191);$t->string('notification_type',96);$t->string('channel',64);$t->string('status',32)->default('PREPARED');$t->string('idempotency_key',64);$t->string('trace_id',128)->nullable();$t->timestamps();$t->unique(['company_id','idempotency_key'],'eonr_tenant_idem_uq');});
 }
 public function down():void{Schema::dropIfExists('ext_onboarding_notification_receipts');Schema::dropIfExists('ext_onboarding_agent_tasks');Schema::dropIfExists('ext_onboarding_trigger_receipts');Schema::dropIfExists('ext_onboarding_content_drafts');}
};
