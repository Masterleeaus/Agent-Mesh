<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('ext_onboarding_journeys')) {
            Schema::create('ext_onboarding_journeys', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->string('journey_key', 100);
                $table->string('name', 190);
                $table->string('audience', 50);
                $table->string('status', 30)->default('draft');
                $table->string('vertical_key', 80)->nullable();
                $table->unsignedBigInteger('created_by_user_id')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id','journey_key'], 'onb_journey_company_key_uq');
                $table->index(['company_id','status'], 'onb_journey_company_status_ix');
            });
        }

        if (!Schema::hasTable('ext_onboarding_journey_versions')) {
            Schema::create('ext_onboarding_journey_versions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('journey_id');
                $table->unsignedInteger('version_number');
                $table->unsignedInteger('revision')->default(1);
                $table->string('state', 30)->default('draft');
                $table->char('content_hash', 64);
                $table->json('definition');
                $table->timestamp('published_at')->nullable();
                $table->unsignedBigInteger('published_by_user_id')->nullable();
                $table->timestamps();
                $table->unique(['company_id','journey_id','version_number'], 'onb_jver_company_journey_ver_uq');
                $table->index(['company_id','state'], 'onb_jver_company_state_ix');
            });
        }

        if (!Schema::hasTable('ext_onboarding_steps')) {
            Schema::create('ext_onboarding_steps', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('journey_version_id');
                $table->string('step_key', 100);
                $table->string('step_type', 50);
                $table->string('actor', 50)->default('participant');
                $table->unsignedInteger('position')->default(0);
                $table->string('risk_level', 20)->default('low');
                $table->string('offline_policy', 30)->default('allowed');
                $table->string('capability_id', 150)->nullable();
                $table->string('completion_rule', 120);
                $table->json('config')->nullable();
                $table->timestamps();
                $table->unique(['company_id','journey_version_id','step_key'], 'onb_step_company_ver_key_uq');
                $table->index(['company_id','journey_version_id','position'], 'onb_step_company_ver_pos_ix');
            });
        }

        if (!Schema::hasTable('ext_onboarding_step_rules')) {
            Schema::create('ext_onboarding_step_rules', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('step_id');
                $table->string('rule_type', 40);
                $table->text('expression');
                $table->unsignedInteger('priority')->default(0);
                $table->timestamps();
                $table->index(['company_id','step_id','rule_type'], 'onb_rule_company_step_type_ix');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_step_rules');
        Schema::dropIfExists('ext_onboarding_steps');
        Schema::dropIfExists('ext_onboarding_journey_versions');
        Schema::dropIfExists('ext_onboarding_journeys');
    }
};
