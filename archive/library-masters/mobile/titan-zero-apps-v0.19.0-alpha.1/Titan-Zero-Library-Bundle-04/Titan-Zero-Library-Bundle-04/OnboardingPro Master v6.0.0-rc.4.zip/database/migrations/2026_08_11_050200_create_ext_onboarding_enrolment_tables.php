<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('ext_onboarding_enrolments')) {
            Schema::create('ext_onboarding_enrolments', function (Blueprint $table): void {
                $table->id();
                $table->uuid('public_id')->unique('onb_enrol_public_uq');
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('journey_version_id');
                $table->string('subject_type', 80);
                $table->string('subject_id', 120);
                $table->string('status', 30)->default('pending');
                $table->timestamp('started_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamp('expires_at')->nullable();
                $table->string('trigger_key', 120)->nullable();
                $table->string('idempotency_key', 190)->nullable();
                $table->timestamps();
                $table->index(['company_id','status'], 'onb_enrol_company_status_ix');
                $table->index(['company_id','subject_type','subject_id'], 'onb_enrol_company_subject_ix');
                $table->unique(['company_id','idempotency_key'], 'onb_enrol_company_idem_uq');
            });
        }

        if (!Schema::hasTable('ext_onboarding_participants')) {
            Schema::create('ext_onboarding_participants', function (Blueprint $table): void {
                $table->id();
                $table->uuid('public_id')->unique('onb_part_public_uq');
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('enrolment_id');
                $table->string('actor_type', 50);
                $table->string('actor_id', 120)->nullable();
                $table->string('role_key', 60);
                $table->string('status', 30)->default('active');
                $table->timestamps();
                $table->index(['company_id','enrolment_id'], 'onb_part_company_enrol_ix');
            });
        }

        if (!Schema::hasTable('ext_onboarding_step_instances')) {
            Schema::create('ext_onboarding_step_instances', function (Blueprint $table): void {
                $table->id();
                $table->uuid('public_id')->unique('onb_sinst_public_uq');
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('enrolment_id');
                $table->unsignedBigInteger('participant_id')->nullable();
                $table->unsignedBigInteger('journey_step_id');
                $table->string('step_key', 100);
                $table->string('status', 30)->default('pending');
                $table->string('include_reason', 190)->nullable();
                $table->string('skip_reason', 190)->nullable();
                $table->unsignedInteger('attempt_count')->default(0);
                $table->timestamp('available_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id','enrolment_id','step_key'], 'onb_sinst_company_enrol_key_uq');
                $table->index(['company_id','status'], 'onb_sinst_company_status_ix');
            });
        }

        if (!Schema::hasTable('ext_onboarding_responses')) {
            Schema::create('ext_onboarding_responses', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id');
                $table->unsignedBigInteger('enrolment_id');
                $table->unsignedBigInteger('step_instance_id');
                $table->unsignedBigInteger('participant_id')->nullable();
                $table->unsignedInteger('attempt_number')->default(1);
                $table->json('response_payload')->nullable();
                $table->char('response_hash', 64)->nullable();
                $table->timestamps();
                $table->index(['company_id','enrolment_id','step_instance_id'], 'onb_resp_company_enrol_step_ix');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_responses');
        Schema::dropIfExists('ext_onboarding_step_instances');
        Schema::dropIfExists('ext_onboarding_participants');
        Schema::dropIfExists('ext_onboarding_enrolments');
    }
};
