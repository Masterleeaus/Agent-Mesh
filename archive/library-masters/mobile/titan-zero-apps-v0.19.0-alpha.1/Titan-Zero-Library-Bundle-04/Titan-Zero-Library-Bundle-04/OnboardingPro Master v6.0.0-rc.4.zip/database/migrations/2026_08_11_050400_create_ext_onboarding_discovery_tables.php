<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('ext_onboarding_discovery_profiles')) {
            Schema::create('ext_onboarding_discovery_profiles', function (Blueprint $t): void {
                $t->bigIncrements('id');
                $t->unsignedBigInteger('company_id');
                $t->unsignedInteger('revision')->default(1);
                $t->string('status',32)->default('DISCOVERING');
                $t->json('profile_payload');
                $t->char('profile_hash',64);
                $t->boolean('minimum_ready')->default(false);
                $t->boolean('operational_ready')->default(false);
                $t->json('remaining_domains')->nullable();
                $t->string('trace_id',100);
                $t->string('correlation_id',100);
                $t->string('causation_id',100);
                $t->string('updated_by_actor_id',100);
                $t->timestamps();
                $t->unique(['company_id','revision'],'onb_disc_company_revision_uq');
                $t->index(['company_id','status'],'onb_disc_company_status_idx');
                $t->index(['company_id','profile_hash'],'onb_disc_company_hash_idx');
            });
        }
        if (!Schema::hasTable('ext_onboarding_bootstrap_intents')) {
            Schema::create('ext_onboarding_bootstrap_intents', function (Blueprint $t): void {
                $t->bigIncrements('id');
                $t->unsignedBigInteger('company_id');
                $t->unsignedBigInteger('discovery_profile_id')->nullable();
                $t->string('target_engine',80);
                $t->string('operation',120);
                $t->string('status',32)->default('PREPARED');
                $t->json('payload');
                $t->string('idempotency_key',128);
                $t->string('trace_id',100);
                $t->string('correlation_id',100);
                $t->string('causation_id',100);
                $t->json('response_receipt')->nullable();
                $t->timestamps();
                $t->unique(['company_id','idempotency_key'],'onb_boot_company_idem_uq');
                $t->index(['company_id','target_engine','status'],'onb_boot_company_target_idx');
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_bootstrap_intents');
        Schema::dropIfExists('ext_onboarding_discovery_profiles');
    }
};
