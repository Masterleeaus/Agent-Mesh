<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void{
  Schema::create('ext_onboarding_evidence_integrity_receipts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eoir_company_idx');$t->string('receipt_id',64);$t->string('evidence_id',64);$t->char('content_hash',64);$t->char('previous_receipt_hash',64)->nullable();$t->char('receipt_hash',64);$t->timestamp('captured_at');$t->timestamps();$t->unique(['company_id','receipt_id'],'eoir_company_receipt_uq');});
  Schema::create('ext_onboarding_requirements',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eor_company_idx');$t->string('requirement_key',120);$t->string('vertical',80)->nullable();$t->string('jurisdiction',80)->nullable();$t->json('prerequisites')->nullable();$t->json('supersedes')->nullable();$t->json('satisfaction_rule')->nullable();$t->unsignedInteger('validity_days')->nullable();$t->timestamps();$t->unique(['company_id','requirement_key'],'eor_company_key_uq');});
  Schema::create('ext_onboarding_participant_achievements',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eopa_company_idx');$t->string('participant_ref',120);$t->string('requirement_key',120);$t->string('version',80);$t->timestamp('achieved_at');$t->timestamp('expires_at')->nullable();$t->json('evidence_refs')->nullable();$t->timestamps();$t->index(['company_id','participant_ref'],'eopa_company_part_idx');});
  Schema::create('ext_onboarding_activation_receipts',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id')->index('eoar_company_idx');$t->string('enrolment_ref',120);$t->string('decision',48);$t->json('reason_codes');$t->string('trace_id',120)->nullable();$t->string('correlation_id',120)->nullable();$t->string('causation_id',120)->nullable();$t->string('trigger_type',80)->nullable();$t->string('trigger_ref',160)->nullable();$t->timestamps();$t->index(['company_id','enrolment_ref'],'eoar_company_enr_idx');});
 }
 public function down():void{Schema::dropIfExists('ext_onboarding_activation_receipts');Schema::dropIfExists('ext_onboarding_participant_achievements');Schema::dropIfExists('ext_onboarding_requirements');Schema::dropIfExists('ext_onboarding_evidence_integrity_receipts');}
};
