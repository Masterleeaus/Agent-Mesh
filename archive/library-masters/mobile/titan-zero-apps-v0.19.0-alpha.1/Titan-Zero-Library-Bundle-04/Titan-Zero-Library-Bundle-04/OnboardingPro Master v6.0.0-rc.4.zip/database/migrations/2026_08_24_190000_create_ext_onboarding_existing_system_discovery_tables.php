<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('ext_onboarding_existing_system_connections')){
            Schema::create('ext_onboarding_existing_system_connections',function(Blueprint $t){
                $t->id();
                $t->unsignedBigInteger('company_id');
                $t->unsignedBigInteger('user_id');
                $t->string('system_type',64);
                $t->string('provider_key',100);
                $t->string('status',32);
                $t->boolean('read_only')->default(true);
                $t->json('connection_metadata')->nullable();
                $t->json('discovery_receipt')->nullable();
                $t->timestamps();
                $t->index(['company_id','system_type','status']);
            });
        }
        if(!Schema::hasTable('ext_onboarding_existing_system_mappings')){
            Schema::create('ext_onboarding_existing_system_mappings',function(Blueprint $t){
                $t->id();
                $t->unsignedBigInteger('company_id');
                $t->unsignedBigInteger('connection_id');
                $t->string('source_type',64);
                $t->json('source_record');
                $t->json('proposed_mapping');
                $t->json('comparison');
                $t->string('status',40);
                $t->boolean('confirmed')->default(false);
                $t->unsignedBigInteger('confirmed_by_user_id')->nullable();
                $t->timestamp('confirmed_at')->nullable();
                $t->timestamps();
                $t->index(['company_id','connection_id']);
                $t->index(['company_id','status']);
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_existing_system_mappings');
        Schema::dropIfExists('ext_onboarding_existing_system_connections');
    }
};
