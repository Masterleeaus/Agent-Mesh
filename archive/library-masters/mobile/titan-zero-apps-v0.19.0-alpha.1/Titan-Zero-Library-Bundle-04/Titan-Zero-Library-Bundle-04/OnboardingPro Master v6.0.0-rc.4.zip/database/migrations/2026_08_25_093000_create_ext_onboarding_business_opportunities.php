<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_onboarding_business_opportunities')) {
            Schema::create('ext_onboarding_business_opportunities', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('audit_id')->nullable()->index();
                $t->string('opportunity_key',100)->nullable();
                $t->string('domain',64)->nullable()->index();
                $t->string('title');
                $t->text('fact')->nullable();
                $t->string('fact_type',20)->nullable();
                $t->text('hypothesis')->nullable();
                $t->string('hypothesis_type',20)->nullable();
                $t->text('recommendation')->nullable();
                $t->string('recommendation_type',20)->nullable();
                $t->json('evidence')->nullable();
                $t->unsignedTinyInteger('confidence')->default(0);
                $t->json('observation_ids')->nullable();
                $t->json('recommended_action')->nullable();
                $t->json('growth_handoff')->nullable();
                $t->json('expected_benefit')->nullable();
                $t->json('estimated_effort')->nullable();
                $t->json('estimated_cost')->nullable();
                $t->json('risk')->nullable();
                $t->string('reversibility',40)->default('unknown');
                $t->json('dependencies')->nullable();
                $t->json('measurement')->nullable();
                $t->json('intervention')->nullable();
                $t->string('status',40)->default('identified')->index();
                $t->boolean('dismissed')->default(false);
                $t->boolean('active')->default(true)->index();
                $t->timestamps();
                $t->index(['company_id','active','status']);
            });
            return;
        }

        // v5 presence intelligence created this table first. Converge it in place for Nexus v6.
        Schema::table('ext_onboarding_business_opportunities', function (Blueprint $t): void {
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','domain')) $t->string('domain',64)->nullable()->index();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','fact')) $t->text('fact')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','fact_type')) $t->string('fact_type',20)->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','hypothesis')) $t->text('hypothesis')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','hypothesis_type')) $t->string('hypothesis_type',20)->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','recommendation')) $t->text('recommendation')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','recommendation_type')) $t->string('recommendation_type',20)->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','evidence')) $t->json('evidence')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','expected_benefit')) $t->json('expected_benefit')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','estimated_effort')) $t->json('estimated_effort')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','estimated_cost')) $t->json('estimated_cost')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','risk')) $t->json('risk')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','reversibility')) $t->string('reversibility',40)->default('unknown');
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','dependencies')) $t->json('dependencies')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','measurement')) $t->json('measurement')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','intervention')) $t->json('intervention')->nullable();
            if (! Schema::hasColumn('ext_onboarding_business_opportunities','active')) $t->boolean('active')->default(true)->index();
        });

        // Old v5 presence fields were mandatory; Nexus opportunities do not necessarily have an audit.
        Schema::table('ext_onboarding_business_opportunities', function (Blueprint $t): void {
            if (Schema::hasColumn('ext_onboarding_business_opportunities','audit_id')) $t->unsignedBigInteger('audit_id')->nullable()->change();
            if (Schema::hasColumn('ext_onboarding_business_opportunities','opportunity_key')) $t->string('opportunity_key',100)->nullable()->change();
            if (Schema::hasColumn('ext_onboarding_business_opportunities','observation_ids')) $t->json('observation_ids')->nullable()->change();
            if (Schema::hasColumn('ext_onboarding_business_opportunities','recommended_action')) $t->json('recommended_action')->nullable()->change();
        });
    }

    public function down(): void
    {
        // Preserve the shared v5 presence table. Only remove Nexus v6 additive columns.
        if (! Schema::hasTable('ext_onboarding_business_opportunities')) return;
        $columns=[
            'domain','fact','fact_type','hypothesis','hypothesis_type','recommendation','recommendation_type',
            'evidence','expected_benefit','estimated_effort','estimated_cost','risk','reversibility',
            'dependencies','measurement','intervention','active'
        ];
        $drop=array_values(array_filter($columns,fn(string $c): bool => Schema::hasColumn('ext_onboarding_business_opportunities',$c)));
        if($drop!==[]) Schema::table('ext_onboarding_business_opportunities',fn(Blueprint $t)=>$t->dropColumn($drop));
    }
};
