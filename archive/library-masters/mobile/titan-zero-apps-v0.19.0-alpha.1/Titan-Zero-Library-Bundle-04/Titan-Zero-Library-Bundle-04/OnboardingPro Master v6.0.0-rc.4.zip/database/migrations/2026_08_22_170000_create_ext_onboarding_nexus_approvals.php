<?php
declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void { if(Schema::hasTable('ext_onboarding_nexus_approvals'))return; Schema::create('ext_onboarding_nexus_approvals',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->unsignedBigInteger('discovery_revision');$t->string('status',32);$t->char('preview_fingerprint',64);$t->json('preview_snapshot');$t->unsignedBigInteger('approved_by_user_id');$t->timestamp('approved_at');$t->json('plan_receipt')->nullable();$t->string('trace_id',128);$t->string('correlation_id',128);$t->timestamps();$t->unique(['company_id','preview_fingerprint'],'onboarding_nexus_approval_unique');$t->index(['company_id','status']);});}
 public function down():void {Schema::dropIfExists('ext_onboarding_nexus_approvals');}
};
