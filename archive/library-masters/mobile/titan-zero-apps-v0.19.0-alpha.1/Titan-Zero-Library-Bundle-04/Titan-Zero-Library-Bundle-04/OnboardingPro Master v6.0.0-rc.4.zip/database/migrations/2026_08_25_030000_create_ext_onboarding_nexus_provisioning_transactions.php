<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void{
  if(!Schema::hasTable('ext_onboarding_nexus_provisioning_transactions'))Schema::create('ext_onboarding_nexus_provisioning_transactions',function(Blueprint $t){
   $t->id();$t->unsignedBigInteger('company_id');$t->unsignedBigInteger('approval_id');$t->unsignedBigInteger('execution_id')->nullable();
   $t->string('idempotency_key',64);$t->string('status',40);$t->string('recovery_mode',40)->nullable();
   $t->json('checkpoint')->nullable();$t->json('failure_context')->nullable();$t->json('recovery_context')->nullable();
   $t->string('trace_id',80)->nullable();$t->string('correlation_id',80)->nullable();$t->timestamp('started_at')->nullable();$t->timestamp('completed_at')->nullable();$t->timestamps();
   $t->unique(['company_id','idempotency_key'],'ext_onboarding_nexus_tx_idempotency');$t->index(['company_id','status']);
  });
  if(!Schema::hasTable('ext_onboarding_nexus_provisioning_steps'))Schema::create('ext_onboarding_nexus_provisioning_steps',function(Blueprint $t){
   $t->id();$t->unsignedBigInteger('company_id');$t->unsignedBigInteger('transaction_id');$t->unsignedInteger('sequence');$t->string('step_key',160);
   $t->string('status',40);$t->unsignedInteger('attempts')->default(0);$t->json('step_payload');$t->json('checkpoint')->nullable();$t->json('compensation')->nullable();$t->json('last_error')->nullable();$t->timestamps();
   $t->unique(['transaction_id','sequence'],'ext_onboarding_nexus_tx_step_seq');$t->index(['company_id','transaction_id','status']);
  });
 }
 public function down():void{Schema::dropIfExists('ext_onboarding_nexus_provisioning_steps');Schema::dropIfExists('ext_onboarding_nexus_provisioning_transactions');}
};
