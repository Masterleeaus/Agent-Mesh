<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{
  if(!Schema::hasTable('ext_onboarding_discovery_evidence'))Schema::create('ext_onboarding_discovery_evidence',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->string('source_type',64);$t->text('source_reference')->nullable();$t->timestamp('observed_at');$t->json('evidence_payload');$t->string('consent_scope',64);$t->timestamps();$t->index(['company_id','source_type']);});
  if(!Schema::hasTable('ext_onboarding_identity_candidates'))Schema::create('ext_onboarding_identity_candidates',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->unsignedTinyInteger('identity_confidence');$t->boolean('same_name_collision')->default(false);$t->json('candidate_payload');$t->timestamps();$t->index(['company_id','identity_confidence']);});
 }
 public function down():void{Schema::dropIfExists('ext_onboarding_identity_candidates');Schema::dropIfExists('ext_onboarding_discovery_evidence');}
};
