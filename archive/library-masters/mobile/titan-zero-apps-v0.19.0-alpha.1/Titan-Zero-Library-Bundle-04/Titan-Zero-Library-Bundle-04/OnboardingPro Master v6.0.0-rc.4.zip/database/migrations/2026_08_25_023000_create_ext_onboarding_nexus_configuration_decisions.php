<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(Schema::hasTable('ext_onboarding_nexus_configuration_decisions')) return;
        Schema::create('ext_onboarding_nexus_configuration_decisions',function(Blueprint $t){
            $t->id();
            $t->unsignedBigInteger('company_id');
            $t->unsignedBigInteger('discovery_revision');
            $t->string('capability_key',128);
            $t->json('why');
            $t->json('dependencies');
            $t->string('authority',160);
            $t->string('autonomy_ceiling',40);
            $t->string('execution_location',64);
            $t->json('provider');
            $t->string('cost_owner',64);
            $t->boolean('requires_paid_resource')->default(false);
            $t->boolean('requires_entitlement')->default(false);
            $t->boolean('explicit_opt_in')->default(false);
            $t->json('risk');
            $t->boolean('reversible')->default(true);
            $t->json('verification');
            $t->boolean('blocked')->default(false);
            $t->json('decision_payload');
            $t->timestamps();
            $t->unique(['company_id','discovery_revision','capability_key'],'ext_onboarding_nexus_decision_unique');
            $t->index(['company_id','blocked']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_nexus_configuration_decisions');
    }
};
