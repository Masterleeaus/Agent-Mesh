<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('ext_onboarding_presence_audits')){
            Schema::create('ext_onboarding_presence_audits',function(Blueprint $t){
                $t->id();
                $t->unsignedBigInteger('company_id');
                $t->string('status',32);
                $t->unsignedTinyInteger('presence_score')->default(0);
                $t->json('observation_ids')->nullable();
                $t->json('summary')->nullable();
                $t->json('methodology')->nullable();
                $t->timestamp('audited_at');
                $t->timestamps();
                $t->index(['company_id','audited_at']);
            });
        }

        if(!Schema::hasTable('ext_onboarding_presence_observations')){
            Schema::create('ext_onboarding_presence_observations',function(Blueprint $t){
                $t->id();
                $t->unsignedBigInteger('company_id');
                $t->unsignedBigInteger('audit_id');
                $t->string('observation_code',100);
                $t->string('status',32);
                $t->unsignedTinyInteger('confidence')->default(0);
                $t->json('evidence');
                $t->json('observation_payload')->nullable();
                $t->timestamp('observed_at');
                $t->timestamps();
                $t->index(['company_id','audit_id']);
                $t->index(['company_id','observation_code']);
            });
        }

        if(!Schema::hasTable('ext_onboarding_business_opportunities')){
            Schema::create('ext_onboarding_business_opportunities',function(Blueprint $t){
                $t->id();
                $t->unsignedBigInteger('company_id');
                $t->unsignedBigInteger('audit_id');
                $t->string('opportunity_key',100);
                $t->string('title',255);
                $t->string('status',32);
                $t->unsignedTinyInteger('confidence')->default(0);
                $t->json('observation_ids');
                $t->json('recommended_action');
                $t->json('growth_handoff')->nullable();
                $t->boolean('dismissed')->default(false);
                $t->timestamps();
                $t->index(['company_id','audit_id']);
                $t->index(['company_id','status']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_business_opportunities');
        Schema::dropIfExists('ext_onboarding_presence_observations');
        Schema::dropIfExists('ext_onboarding_presence_audits');
    }
};
