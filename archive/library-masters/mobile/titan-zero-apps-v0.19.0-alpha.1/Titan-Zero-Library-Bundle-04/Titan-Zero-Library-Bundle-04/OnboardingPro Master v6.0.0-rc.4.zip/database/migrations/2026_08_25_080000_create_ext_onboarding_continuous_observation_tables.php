<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{
  if(!Schema::hasTable('ext_onboarding_observation_runs'))Schema::create('ext_onboarding_observation_runs',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->string('status',32);$t->json('requested_sources')->nullable();$t->json('due_sources')->nullable();$t->json('summary')->nullable();$t->timestamp('started_at')->nullable();$t->timestamp('completed_at')->nullable();$t->timestamps();$t->index(['company_id','status']);});
  if(!Schema::hasTable('ext_onboarding_observation_signals'))Schema::create('ext_onboarding_observation_signals',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->unsignedBigInteger('observation_run_id');$t->string('source_type',80);$t->string('signal_key',160);$t->string('change_state',32);$t->unsignedTinyInteger('confidence')->default(0);$t->json('evidence')->nullable();$t->json('payload')->nullable();$t->timestamp('observed_at');$t->timestamps();$t->index(['company_id','source_type','observed_at'],'obs_signal_freshness');$t->index(['company_id','change_state']);});
 }
 public function down():void{Schema::dropIfExists('ext_onboarding_observation_signals');Schema::dropIfExists('ext_onboarding_observation_runs');}
};
