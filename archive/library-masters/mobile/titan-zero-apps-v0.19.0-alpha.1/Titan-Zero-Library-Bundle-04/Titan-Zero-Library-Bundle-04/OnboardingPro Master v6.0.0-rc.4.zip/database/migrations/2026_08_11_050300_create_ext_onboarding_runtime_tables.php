<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('ext_onboarding_handoffs')) {
            Schema::create('ext_onboarding_handoffs', function (Blueprint $t): void {
                $t->bigIncrements('id');
                $t->unsignedBigInteger('company_id');
                $t->string('enrolment_id',64);
                $t->string('step_key',100);
                $t->string('assigned_actor_id',100);
                $t->string('reason',50);
                $t->string('status',30)->default('waiting');
                $t->timestamp('due_at')->nullable();
                $t->timestamp('completed_at')->nullable();
                $t->timestamps();
                $t->index(['company_id','enrolment_id'],'onb_handoff_company_enrol_idx');
                $t->index(['company_id','assigned_actor_id','status'],'onb_handoff_actor_status_idx');
            });
        }
        if (!Schema::hasTable('ext_onboarding_capability_actions')) {
            Schema::create('ext_onboarding_capability_actions', function (Blueprint $t): void {
                $t->bigIncrements('id');
                $t->unsignedBigInteger('company_id');
                $t->string('enrolment_id',64);
                $t->string('participant_id',100);
                $t->string('capability_id',150);
                $t->string('risk_level',20);
                $t->string('status',40);
                $t->string('provider',80)->nullable();
                $t->string('idempotency_key',128);
                $t->json('approval_evidence')->nullable();
                $t->json('result')->nullable();
                $t->timestamp('executed_at')->nullable();
                $t->timestamps();
                $t->unique(['company_id','idempotency_key'],'onb_cap_company_idem_uq');
                $t->index(['company_id','enrolment_id'],'onb_cap_company_enrol_idx');
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_capability_actions');
        Schema::dropIfExists('ext_onboarding_handoffs');
    }
};
