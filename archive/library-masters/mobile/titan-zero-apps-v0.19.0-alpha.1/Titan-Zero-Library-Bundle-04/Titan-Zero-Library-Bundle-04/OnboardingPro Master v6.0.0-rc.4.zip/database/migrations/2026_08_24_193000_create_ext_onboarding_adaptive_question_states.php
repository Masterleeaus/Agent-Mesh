<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(Schema::hasTable('ext_onboarding_adaptive_question_states')) return;
        Schema::create('ext_onboarding_adaptive_question_states',function(Blueprint $t){
            $t->id();
            $t->unsignedBigInteger('company_id');
            $t->unsignedBigInteger('user_id');
            $t->string('question_key',100);
            $t->string('status',24);
            $t->string('surface',24)->default('pwa');
            $t->json('answer_payload')->nullable();
            $t->json('resolved_fact_keys')->nullable();
            $t->unsignedSmallInteger('resolved_by_answer')->default(0);
            $t->timestamp('answered_at')->nullable();
            $t->timestamp('deferred_at')->nullable();
            $t->timestamps();
            $t->unique(['company_id','user_id','question_key'],'ext_onboarding_adaptive_state_unique');
            $t->index(['company_id','user_id','status'],'ext_onboarding_adaptive_state_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_onboarding_adaptive_question_states');
    }
};
