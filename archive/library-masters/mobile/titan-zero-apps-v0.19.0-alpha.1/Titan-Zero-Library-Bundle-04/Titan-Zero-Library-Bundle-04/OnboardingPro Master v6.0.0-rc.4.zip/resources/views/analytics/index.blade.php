@extends('panel.layout.app')
@section('title', __('Titan Onboarding — Analytics'))
@section('content')
<div class="container-fluid py-6"><div class="mb-6"><h1 class="text-2xl font-semibold">{{ __('Onboarding Analytics') }}</h1><p class="text-sm opacity-70">{{ __('Measured journey health for the active business context.') }}</p></div>
<div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
@foreach(['enrolments'=>'Enrolments','completed'=>'Completed','completion_rate'=>'Completion rate','overdue_rate'=>'Overdue rate'] as $key=>$label)<div class="rounded-xl border p-4"><div class="text-xs opacity-60">{{ __($label) }}</div><div class="mt-2 text-2xl font-semibold">@if(str_contains($key,'rate')){{ number_format(($metrics[$key]??0)*100,1) }}%@else{{ $metrics[$key]??0 }}@endif</div></div>@endforeach
</div><div class="mt-6 rounded-xl border p-4"><h2 class="font-semibold">{{ __('Top bottlenecks') }}</h2><div class="mt-3 grid gap-2">@forelse(array_slice($bottlenecks,0,8) as $row)<div class="flex justify-between text-sm"><span>{{ $row['step_key'] }}</span><span>{{ number_format($row['bottleneck_score'],2) }}</span></div>@empty<div class="text-sm opacity-60">{{ __('No journey-step data yet.') }}</div>@endforelse</div></div></div>
@endsection
