@extends('panel.layout.app')
@section('title', 'Titan Onboarding — AI Journey Draft')
@section('content')
<div class="py-10">
  <div class="container xl:max-w-6xl">
    <div class="rounded-xl border bg-background p-6 shadow-sm">
      <h1 class="mb-2 text-2xl font-semibold">AI Journey Draft</h1>
      <p class="mb-6 text-sm opacity-70">Prepare a governed TitanAI draft request. Generated content remains a draft until human review and publication.</p>
      <form method="POST" action="{{ route('dashboard.admin.onboarding-pro.journeys.ai.prepare') }}" class="space-y-4">
        @csrf
        <textarea name="goal" class="form-control" rows="6" required placeholder="Describe the onboarding journey you need..."></textarea>
        <div class="grid gap-4 md:grid-cols-2"><input class="form-control" name="vertical" placeholder="Vertical"><input class="form-control" name="jurisdiction" placeholder="Jurisdiction"></div>
        <button class="btn btn-primary" type="submit">Prepare TitanAI draft</button>
      </form>
    </div>
  </div>
</div>
@endsection
