@extends('panel.layout.app')
@section('title', __('Titan Onboarding — Journey Library'))
@section('content')
<div class="container-fluid py-6"><div class="flex items-center justify-between gap-4 mb-6"><div><h1 class="text-2xl font-semibold">{{ __('Journey Library') }}</h1><p class="text-sm opacity-70">{{ __('Drafts, published versions and reusable onboarding journeys.') }}</p></div></div>
<div class="grid gap-3">@forelse($journeys as $journey)<a class="rounded-xl border p-4 block" href="{{ route('dashboard.admin.onboarding-pro.journeys.show',$journey->id) }}"><strong>{{ $journey->name ?? $journey->key }}</strong><div class="text-xs opacity-70">{{ $journey->key }}</div></a>@empty<div class="rounded-xl border p-6">{{ __('No journeys yet.') }}</div>@endforelse</div><div class="mt-5">{{ $journeys->links() }}</div></div>
@endsection
