@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-6 max-w-5xl">
    <div class="mb-6">
        <p class="text-xs uppercase tracking-wide opacity-60">{{ __('Titan Onboarding') }}</p>
        <h1 class="text-3xl font-semibold">{{ $setup->mode === 'first_run' ? __('Set up your business') : __('Business setup') }}</h1>
        <p class="mt-2 opacity-70">{{ __('Tell Titan how your business works. You can save at any time and return later.') }}</p>
        <div class="mt-3 text-sm">
            <span>{{ __('Revision') }} {{ $setup->revision }}</span>
            <span class="mx-2">•</span>
            <span>{{ $setup->readiness->minimumReady ? __('Minimum setup ready') : __('Setup in progress') }}</span>
        </div>
    </div>

    @if(session('status'))
        <div class="rounded-xl border p-3 mb-5">{{ session('status') }}</div>
    @endif
    @if($errors->any())
        <div class="rounded-xl border p-3 mb-5">{{ $errors->first() }}</div>
    @endif

    <section id="minimum-discovery" class="rounded-2xl border p-5 mb-5">
        <h2 class="text-xl font-semibold">{{ __('1. Business essentials') }}</h2>
        <form method="POST" action="{{ route('dashboard.onboarding.business-setup.profile') }}" class="grid gap-4 mt-4">
            @csrf @method('PATCH')
            <input type="hidden" name="section" value="minimum-discovery">
            <input type="hidden" name="expected_revision" value="{{ $setup->revision }}">
            <label>{{ __('Business name') }}<input class="form-control" name="profile[business_identity][name]" value="{{ data_get($profile,'business_identity.name','') }}"></label>
            <label>{{ __('Industry / business type') }}<input class="form-control" name="profile[industry]" value="{{ data_get($profile,'industry','') }}"></label>
            <label>{{ __('Services') }}<textarea class="form-control" name="profile[services]">{{ implode(', ',(array)data_get($profile,'services',[])) }}</textarea></label>
            <label>{{ __('Country') }}<input class="form-control" name="profile[jurisdiction][country]" value="{{ data_get($profile,'jurisdiction.country','') }}"></label>
            <label>{{ __('Business size') }}<input class="form-control" name="profile[size]" value="{{ data_get($profile,'size','') }}"></label>
            <label>{{ __('Privacy preferences') }}<input class="form-control" name="profile[privacy_preferences]" value="{{ data_get($profile,'privacy_preferences.summary','') }}"></label>
            <div class="flex gap-3"><button class="btn btn-primary" type="submit" name="intent" value="continue">{{ __('Save and continue') }}</button><button class="btn" type="submit" name="intent" value="later">{{ __('Save for later') }}</button></div>
        </form>
    </section>

    <section id="vertical-resolution" class="rounded-2xl border p-5 mb-5">
        <h2 class="text-xl font-semibold">{{ __('Business type resolution') }}</h2>
        @php($vertical = (array)($setup->verticalResolution ?? []))
        @if(!$setup->readiness->minimumReady)
            <p class="mt-2 opacity-70">{{ __('Complete and save Business essentials before Titan resolves the canonical business vertical.') }}</p>
        @elseif(($vertical['status'] ?? null) === 'RESOLVED' && !($vertical['stale'] ?? true))
            <p class="mt-2">{{ __('Resolved by Titan Vertical Engine:') }} <strong>{{ $vertical['vertical_id'] }}</strong> <span class="opacity-70">v{{ $vertical['vertical_version'] }}</span></p>
            <p class="mt-1 text-sm opacity-70">{{ __('Confidence') }}: {{ number_format(((float)($vertical['confidence'] ?? 0))*100, 1) }}%</p>
            @if(!empty($vertical['secondary_verticals']))
                <p class="mt-1 text-sm opacity-70">{{ __('Additional compatible verticals were retained for hybrid/multi-service configuration.') }}</p>
            @endif
        @elseif(($vertical['status'] ?? null) === 'AMBIGUOUS' && !($vertical['stale'] ?? true))
            <p class="mt-2">{{ __('Titan found multiple close matches and has not selected one silently.') }}</p>
            @if(!empty($vertical['candidates']))
                <ul class="mt-2 text-sm">
                    @foreach($vertical['candidates'] as $candidate)
                        <li>{{ data_get($candidate,'vertical_id') }} v{{ data_get($candidate,'vertical_version') }} — {{ number_format(((float)data_get($candidate,'score',0))*100, 1) }}%</li>
                    @endforeach
                </ul>
            @endif
        @elseif(($vertical['stale'] ?? false) === true)
            <p class="mt-2">{{ __('Business details changed after the last vertical resolution. Resolve again before Nexus provisioning.') }}</p>
        @elseif(($vertical['status'] ?? null) === 'UNAVAILABLE')
            <p class="mt-2">{{ __('Titan Vertical Engine is currently unavailable or not configured. Nexus provisioning remains blocked.') }}</p>
        @else
            <p class="mt-2 opacity-70">{{ __('Resolve your business type through Titan Vertical Engine before configuration is sent to Nexus.') }}</p>
        @endif
        @if($setup->readiness->minimumReady)
            <form method="POST" action="{{ route('dashboard.onboarding.business-setup.vertical.resolve') }}" class="mt-4">
                @csrf
                <input type="hidden" name="expected_revision" value="{{ $setup->revision }}">
                <button class="btn btn-primary" type="submit">{{ __('Resolve business type') }}</button>
            </form>
        @endif
    </section>

    <section id="operational-discovery" class="rounded-2xl border p-5 mb-5">
        <h2 class="text-xl font-semibold">{{ __('2. How your business operates') }}</h2>
        <form method="POST" action="{{ route('dashboard.onboarding.business-setup.profile') }}" class="grid gap-4 mt-4">
            @csrf @method('PATCH')
            <input type="hidden" name="section" value="operational-discovery">
            <input type="hidden" name="expected_revision" value="{{ $setup->revision }}">
            <label>{{ __('Service areas') }}<textarea class="form-control" name="profile[service_areas]">{{ implode(', ',(array)data_get($profile,'service_areas',[])) }}</textarea></label>
            <label>{{ __('Staff roles') }}<textarea class="form-control" name="profile[staff_roles]">{{ implode(', ',(array)data_get($profile,'staff.roles',[])) }}</textarea></label>
            <label>{{ __('Operating hours') }}<input class="form-control" name="profile[operating_hours_text]" value="{{ data_get($profile,'operating_hours.summary','') }}"></label>
            <label>{{ __('Timezone') }}<input class="form-control" name="profile[timezone]" value="{{ data_get($profile,'timezone','') }}" placeholder="Australia/Melbourne"></label>
            <label>{{ __('Pricing approach') }}<input class="form-control" name="profile[pricing_approach]" value="{{ data_get($profile,'pricing_approach','') }}"></label>
            <label>{{ __('Job lifecycle') }}<textarea class="form-control" name="profile[job_lifecycle]">{{ implode(', ',(array)data_get($profile,'job_lifecycle',[])) }}</textarea></label>
            <label>{{ __('Communication channels') }}<textarea class="form-control" name="profile[communication_channels]">{{ implode(', ',(array)data_get($profile,'communication_channels',[])) }}</textarea></label>
            <label>{{ __('Payment methods') }}<textarea class="form-control" name="profile[payment_methods]">{{ implode(', ',(array)data_get($profile,'payment_methods',[])) }}</textarea></label>
            <div class="flex gap-3"><button class="btn btn-primary" type="submit" name="intent" value="continue">{{ __('Save and continue') }}</button><button class="btn" type="submit" name="intent" value="later">{{ __('Save for later') }}</button></div>
        </form>
        <div class="mt-4 flex flex-wrap gap-2">
            @foreach(['service_areas','operating_hours','pricing','job_lifecycle','communications','payments'] as $domain)
                <form method="POST" action="{{ route('dashboard.onboarding.business-setup.domain.defer',$domain) }}">@csrf<input type="hidden" name="expected_revision" value="{{ $setup->revision }}"><button class="btn btn-sm" type="submit">{{ __('defer') }} {{ str_replace('_',' ',$domain) }}</button></form>
            @endforeach
        </div>
    </section>

    <section id="continuous-discovery" class="rounded-2xl border p-5 mb-5">
        <h2 class="text-xl font-semibold">{{ __('3. Intelligent setup') }}</h2>
        <form method="POST" action="{{ route('dashboard.onboarding.business-setup.profile') }}" class="grid gap-4 mt-4">
            @csrf @method('PATCH')
            <input type="hidden" name="section" value="continuous-discovery">
            <input type="hidden" name="expected_revision" value="{{ $setup->revision }}">
            <label>{{ __('Equipment / asset categories') }}<textarea class="form-control" name="profile[equipment_assets]">{{ implode(', ',(array)data_get($profile,'equipment_assets',[])) }}</textarea></label>
            <label>{{ __('Compliance requirements') }}<textarea class="form-control" name="profile[compliance_requirements]">{{ implode(', ',(array)data_get($profile,'compliance_requirements',[])) }}</textarea></label>
            <label>{{ __('AI provider preferences') }}<input class="form-control" name="profile[ai_provider_preferences]" value="{{ data_get($profile,'ai_provider_preferences.summary','') }}"></label>
            <label>{{ __('Automation / autonomy preferences') }}<input class="form-control" name="profile[autonomy_preferences]" value="{{ data_get($profile,'autonomy_preferences.summary','') }}"></label>
            <label>{{ __('Risk tolerance') }}<input class="form-control" name="profile[risk_tolerance]" value="{{ data_get($profile,'risk_tolerance.summary','') }}"></label>
            <div class="flex gap-3"><button class="btn btn-primary" type="submit" name="intent" value="continue">{{ __('Save and continue') }}</button><button class="btn" type="submit" name="intent" value="later">{{ __('Save for later') }}</button></div>
        </form>
    </section>

    <section id="configuration-preview" class="rounded-2xl border p-5 mb-5">
        <h2 class="text-xl font-semibold">{{ __('Configuration preview') }}</h2>
        <p class="mt-2 opacity-70">{{ __('Ask Nexus to validate and preview the proposed business configuration before anything is applied.') }}</p>
        @php($review = (array) session('nexus_configuration_review', []))
        @if(!$setup->verticalReady())
            <p class="mt-3">{{ __('Resolve the canonical business type before generating a Nexus preview.') }}</p>
        @else
            <form method="POST" action="{{ route('dashboard.onboarding.business-setup.nexus.preview') }}" class="mt-4">
                @csrf
                <button class="btn btn-primary" type="submit">{{ __('Generate configuration preview') }}</button>
            </form>
        @endif
        @if($review !== [])
            <div class="mt-5 grid gap-3">
                <p><strong>{{ __('Nexus status') }}:</strong> {{ data_get($review,'status','UNAVAILABLE') }}</p>
                @foreach([
                    'missing_extensions' => __('Missing extensions'),
                    'missing_credentials' => __('Credentials required'),
                    'missing_dependencies' => __('Missing dependencies'),
                    'compliance_requirements' => __('Compliance requirements'),
                    'follow_up_questions' => __('Questions to resolve'),
                    'warnings' => __('Warnings'),
                ] as $key => $label)
                    @if((array)data_get($review,$key,[]) !== [])
                        <div><strong>{{ $label }}</strong><ul class="list-disc ml-5 mt-1">@foreach((array)data_get($review,$key,[]) as $item)<li>{{ is_scalar($item) ? $item : json_encode($item) }}</li>@endforeach</ul></div>
                    @endif
                @endforeach
                @if(data_get($review,'ready_for_approval',false))
                    <p class="font-semibold">{{ __('No blocking configuration gaps remain. Review carefully before approval.') }}</p>
                    <form method="POST" action="{{ route('dashboard.onboarding.business-setup.nexus.approve') }}">@csrf<button class="btn btn-primary" type="submit">{{ __('Approve configuration') }}</button></form>
                @endif
                @if(session('nexus_approval_id'))
                    <form method="POST" action="{{ route('dashboard.onboarding.business-setup.nexus.plan') }}" class="mt-3">@csrf<input type="hidden" name="approval_id" value="{{ session('nexus_approval_id') }}"><button class="btn btn-primary" type="submit">{{ __('Prepare governed provisioning plan') }}</button></form>
                @endif
            </div>
        @endif
            @if(session('nexus_plan_receipt'))
            <div class="mt-4 rounded-xl border p-4">
                <strong>{{ __('Governed plan ready') }}</strong>
                <p>{{ __('Execution will be sent through Nexus. Extension-owned data must be changed through public capability/command boundaries.') }}</p>
                <form method="POST" action="{{ route('dashboard.onboarding.business-setup.nexus.execute') }}" class="mt-3">@csrf<input type="hidden" name="approval_id" value="{{ data_get(session('nexus_plan_receipt'),'approval_id') }}"><button class="btn btn-primary" type="submit">{{ __('Execute approved plan') }}</button></form>
            </div>
        @endif
        @if(session('nexus_execution_id'))
            <form method="POST" action="{{ route('dashboard.onboarding.business-setup.nexus.verify') }}" class="mt-4">@csrf<input type="hidden" name="execution_id" value="{{ session('nexus_execution_id') }}"><button class="btn btn-primary" type="submit">{{ __('Verify business readiness') }}</button></form>
        @endif
        @if(session('nexus_verification_receipt'))
            <div class="mt-4 rounded-xl border p-4"><strong>{{ data_get(session('nexus_verification_receipt'),'operational_ready') ? __('Operationally ready') : __('Remaining setup work') }}</strong>
            @foreach((array)data_get(session('nexus_verification_receipt'),'blocking_gaps',[]) as $gap)<p>⚠ {{ is_scalar($gap)?$gap:json_encode($gap) }}</p>@endforeach
            @foreach((array)data_get(session('nexus_verification_receipt'),'manual_actions',[]) as $action)<p>• {{ is_scalar($action)?$action:json_encode($action) }}</p>@endforeach</div>
        @endif
</section>

    <div class="rounded-2xl border p-5">
        <h2 class="text-lg font-semibold">{{ __('Setup readiness') }}</h2>
        <p class="mt-2">{{ $setup->readiness->minimumReady ? __('Minimum business discovery is complete.') : __('Complete the business essentials to continue.') }}</p>
        <p class="mt-1">{{ $setup->readiness->operationalReady ? __('Operational discovery is ready.') : __('You can keep configuring the remaining operational areas over time.') }}</p>
        @if($setup->readiness->remainingDomains !== [])
            <p class="mt-3 text-sm opacity-70">{{ __('Remaining:') }} {{ implode(', ', $setup->readiness->remainingDomains) }}</p>
        @endif
    </div>
</div>
@endsection
