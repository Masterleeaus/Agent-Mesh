@extends('panel.layout.app')
@section('title', __('Journey Versions'))
@section('content')<div class="container-fluid py-6"><h1 class="text-2xl font-semibold">{{ __('Journey Versions') }}</h1><div class="mt-5 grid gap-2">@foreach($versions as $version)<div class="rounded-xl border p-4"><strong>{{ $version->version }}</strong><span class="ml-3 text-xs opacity-70">{{ $version->state }}</span></div>@endforeach</div></div>@endsection
