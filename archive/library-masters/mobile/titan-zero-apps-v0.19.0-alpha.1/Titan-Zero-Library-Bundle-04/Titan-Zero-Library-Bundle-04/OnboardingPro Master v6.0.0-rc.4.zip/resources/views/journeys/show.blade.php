@extends('panel.layout.app')
@section('title', __('Titan Onboarding Journey'))
@section('content')<div class="container-fluid py-6"><h1 class="text-2xl font-semibold">{{ $journey->name ?? $journey->key }}</h1><p class="opacity-70">{{ $journey->key }}</p><div class="flex gap-3 mt-6"><a class="btn btn-primary" href="{{ route('dashboard.admin.onboarding-pro.journeys.builder',$journey->id) }}">{{ __('Open Builder') }}</a><a class="btn" href="{{ route('dashboard.admin.onboarding-pro.journeys.versions',$journey->id) }}">{{ __('Versions') }}</a></div></div>@endsection
