@extends('panel.layout.app')
@section('title', __('Titan Onboarding — Journey Builder'))
@section('content')
<div class="container-fluid py-6" x-data="titanJourneyBuilder()">
  <div class="mb-6 flex items-start justify-between gap-4">
    <div><h1 class="text-2xl font-semibold">{{ __('Journey Builder') }}</h1><p class="text-sm opacity-70">{{ $journey->name ?? $journey->key }} · {{ __('Published versions are immutable; this editor saves drafts only.') }}</p></div>
    <div class="flex gap-2"><button class="btn" @click="validate">{{ __('Validate') }}</button><button class="btn" @click="preview">{{ __('Preview') }}</button><button class="btn btn-primary" @click="save">{{ __('Save draft') }}</button></div>
  </div>
  <div class="grid lg:grid-cols-4 gap-4">
    <aside class="rounded-xl border p-4"><h2 class="font-semibold mb-3">{{ __('Step palette') }}</h2><div class="grid gap-2 text-sm">@foreach(['information','form','checklist','guided_tour','announcement','document','video','survey','quiz','signature','evidence','approval','payment_confirmation','booking','integration','practical_signoff','certificate','completion'] as $type)<button type="button" class="text-left rounded-lg border px-3 py-2" @click="addStep('{{ $type }}')">+ {{ $type }}</button>@endforeach</div></aside>
    <main class="lg:col-span-3 space-y-4">
      <div class="rounded-xl border p-4"><div class="flex justify-between"><h2 class="font-semibold">{{ __('Structured definition') }}</h2><span class="text-xs opacity-60" x-text="status"></span></div><textarea x-model="json" class="form-control mt-3 font-mono text-xs" rows="26"></textarea></div>
      <div class="rounded-xl border p-4" x-show="errors.length"><h3 class="font-semibold">{{ __('Validation') }}</h3><ul class="mt-2 text-sm list-disc pl-5"><template x-for="e in errors"><li x-text="e"></li></template></ul></div>
      <div class="rounded-xl border p-4" x-show="previewData"><h3 class="font-semibold">{{ __('Runtime preview') }}</h3><pre class="mt-3 overflow-auto text-xs" x-text="JSON.stringify(previewData,null,2)"></pre></div>
    </main>
  </div>
</div>
<script>
function titanJourneyBuilder(){
 const initial=@json($version?->definition ?? ['key'=>$journey->journey_key ?? $journey->key,'version'=>'1.0.0','audience'=>$journey->audience ?? 'participant','steps'=>[]]);
 return {json:JSON.stringify(initial,null,2),revision:@json((int)($version?->revision ?? 1)),errors:[],previewData:null,status:'',
 definition(){try{return JSON.parse(this.json)}catch(e){this.errors=[e.message];return null}},
 addStep(type){const d=this.definition();if(!d)return;d.steps=d.steps||[];const key=type+'-'+String(d.steps.length+1);d.steps.push({key,type,actor:'participant',completion_rule:'completed',risk_level:'low',offline_policy:'allowed',config:{}});this.json=JSON.stringify(d,null,2)},
 async call(url,method){const d=this.definition();if(!d)return null;const r=await fetch(url,{method,headers:{'Content-Type':'application/json','X-CSRF-TOKEN':'{{ csrf_token() }}','Accept':'application/json'},body:JSON.stringify({definition:d,revision:this.revision})});const out=await r.json();this.errors=out.errors||out.validation?.errors||[];if(!r.ok)throw new Error(this.errors.join(', ')||'Request failed');return out},
 async validate(){this.status='validating';try{const out=await this.call('{{ route('dashboard.admin.onboarding-pro.journeys.builder.validate',$journey->id) }}','POST');this.status=out.valid?'valid':'invalid'}catch(e){this.status='invalid'}},
 async preview(){this.status='previewing';try{const out=await this.call('{{ route('dashboard.admin.onboarding-pro.journeys.builder.preview',$journey->id) }}','POST');this.previewData=out.preview;this.status='preview ready'}catch(e){this.status='preview blocked'}},
 async save(){this.status='saving';try{const out=await this.call('{{ route('dashboard.admin.onboarding-pro.journeys.builder.save',$journey->id) }}','PUT');this.revision=out.revision;this.status='saved revision '+out.revision}catch(e){this.status='save failed'}}};}
</script>
@endsection
