<?php

declare(strict_types=1);

use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessSetupController;
use App\Extensions\OnboardingPro\System\Http\Controllers\AdaptiveOnboardingController;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessPresenceController;
use App\Extensions\OnboardingPro\System\Http\Controllers\OnboardingReadinessController;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessRealityGraphController;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessObservationController;
use App\Extensions\OnboardingPro\System\Http\Controllers\CompetitorDiscoveryController;
use App\Extensions\OnboardingPro\System\Http\Controllers\CompetitiveBenchmarkController;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessOpportunityController;
use App\Extensions\OnboardingPro\System\Http\Controllers\BusinessDiagnosticController;
use App\Extensions\OnboardingPro\System\Http\Controllers\InterventionPriorityController;
use App\Extensions\OnboardingPro\System\Http\Controllers\NexusWorkforceCommandController;
use App\Extensions\OnboardingPro\System\Http\Controllers\ProviderActionController;
use App\Extensions\OnboardingPro\System\Http\Controllers\InterventionExecutionController;
use App\Extensions\OnboardingPro\System\Http\Controllers\StrategyMemoryController;
use App\Extensions\OnboardingPro\System\Http\Controllers\NexusLifecycleController;
use App\Extensions\OnboardingPro\System\Http\Middleware\ResolveOnboardingCompany;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'auth', ResolveOnboardingCompany::class])
    ->prefix('dashboard/onboarding')
    ->as('dashboard.onboarding.')
    ->group(function (): void {
        Route::get('/', [BusinessSetupController::class, 'show'])->name('business-setup');
        Route::get('start', [BusinessSetupController::class, 'show'])->name('business-setup.start');
        Route::patch('profile', [BusinessSetupController::class, 'save'])->name('business-setup.profile');
        Route::post('vertical/resolve', [BusinessSetupController::class, 'resolveVertical'])->name('business-setup.vertical.resolve');
        Route::post('nexus/preview', [BusinessSetupController::class, 'previewNexusConfiguration'])->name('business-setup.nexus.preview');
        Route::post('nexus/approve', [BusinessSetupController::class, 'approveNexusConfiguration'])->name('business-setup.nexus.approve');
        Route::post('nexus/plan', [BusinessSetupController::class, 'planNexusProvisioning'])->name('business-setup.nexus.plan');
        Route::post('nexus/execute', [BusinessSetupController::class, 'executeNexusProvisioning'])->name('business-setup.nexus.execute');
        Route::post('nexus/verify', [BusinessSetupController::class, 'verifyNexusProvisioning'])->name('business-setup.nexus.verify');
        Route::post('reconfiguration/preview', [BusinessSetupController::class, 'previewBusinessReconfiguration'])->name('business-setup.reconfiguration.preview');
        Route::post('reconfiguration/approve', [BusinessSetupController::class, 'approveBusinessReconfiguration'])->name('business-setup.reconfiguration.approve');
        Route::post('reconfiguration/execute', [BusinessSetupController::class, 'executeBusinessReconfiguration'])->name('business-setup.reconfiguration.execute');
        Route::post('domains/{domain}/defer', [BusinessSetupController::class, 'defer'])->name('business-setup.domain.defer');
        Route::get('adaptive/next', [AdaptiveOnboardingController::class, 'next'])->name('business-setup.adaptive.next');
        Route::post('adaptive/answer', [AdaptiveOnboardingController::class, 'answer'])->name('business-setup.adaptive.answer');
        Route::post('adaptive/defer', [AdaptiveOnboardingController::class, 'defer'])->name('business-setup.adaptive.defer');
        Route::post('presence/audit', [BusinessPresenceController::class, 'audit'])->name('business-setup.presence.audit');
        Route::get('presence/opportunities', [BusinessPresenceController::class, 'opportunities'])->name('business-setup.presence.opportunities');
        Route::get('readiness/check', [OnboardingReadinessController::class, 'check'])->name('business-setup.readiness.check');
        Route::get('ui/contract', [OnboardingReadinessController::class, 'uiContract'])->name('business-setup.ui.contract');
        Route::get('reality-graph', [BusinessRealityGraphController::class, 'show'])->name('business-setup.reality-graph');
        Route::get('observation/status', [BusinessObservationController::class, 'status'])->name('business-setup.observation.status');
        Route::post('observation/run', [BusinessObservationController::class, 'run'])->name('business-setup.observation.run');
        Route::post('competitors/discover', [CompetitorDiscoveryController::class, 'discover'])->name('business-setup.competitors.discover');
        Route::post('competitors/decision', [CompetitorDiscoveryController::class, 'decision'])->name('business-setup.competitors.decision');
        Route::post('benchmarks/run', [CompetitiveBenchmarkController::class, 'run'])->name('business-setup.benchmarks.run');
        Route::get('benchmarks/latest', [CompetitiveBenchmarkController::class, 'latest'])->name('business-setup.benchmarks.latest');
        Route::post('opportunities/generate', [BusinessOpportunityController::class, 'generate'])->name('business-setup.opportunities.generate');
        Route::get('opportunities/latest', [BusinessOpportunityController::class, 'latest'])->name('business-setup.opportunities.latest');
        Route::post('diagnostics/run', [BusinessDiagnosticController::class, 'run'])->name('business-setup.diagnostics.run');
        Route::get('diagnostics/latest', [BusinessDiagnosticController::class, 'latest'])->name('business-setup.diagnostics.latest');
        Route::post('priorities/run', [InterventionPriorityController::class, 'run'])->name('business-setup.priorities.run');
        Route::get('priorities/latest', [InterventionPriorityController::class, 'latest'])->name('business-setup.priorities.latest');
        Route::post('workforce/commands/dispatch', [NexusWorkforceCommandController::class, 'dispatch'])->name('business-setup.workforce.commands.dispatch');
        Route::get('workforce/commands/latest', [NexusWorkforceCommandController::class, 'latest'])->name('business-setup.workforce.commands.latest');
        Route::post('providers/actions/prepare', [ProviderActionController::class, 'prepare'])->name('business-setup.providers.actions.prepare');
        Route::get('providers/actions/latest', [ProviderActionController::class, 'latest'])->name('business-setup.providers.actions.latest');
        Route::post('executions/start', [InterventionExecutionController::class, 'start'])->name('business-setup.executions.start');
        Route::post('executions/measure', [InterventionExecutionController::class, 'measure'])->name('business-setup.executions.measure');
        Route::get('executions/latest', [InterventionExecutionController::class, 'latest'])->name('business-setup.executions.latest');
        Route::post('strategy-memory/ingest', [StrategyMemoryController::class, 'ingest'])->name('business-setup.strategy-memory.ingest');
        Route::post('strategy-memory/check', [StrategyMemoryController::class, 'check'])->name('business-setup.strategy-memory.check');
        Route::get('strategy-memory/latest', [StrategyMemoryController::class, 'latest'])->name('business-setup.strategy-memory.latest');
        Route::get('nexus/lifecycle/status', [NexusLifecycleController::class, 'status'])->name('business-setup.nexus.lifecycle.status');
        Route::post('nexus/reassess', [NexusLifecycleController::class, 'reassess'])->name('business-setup.nexus.reassess');
        Route::post('readiness/production-gate', [OnboardingReadinessController::class, 'productionGate'])->name('business-setup.readiness.production-gate');
    });
