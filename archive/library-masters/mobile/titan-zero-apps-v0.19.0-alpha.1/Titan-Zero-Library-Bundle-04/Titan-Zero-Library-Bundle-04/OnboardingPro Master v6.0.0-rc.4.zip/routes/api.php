<?php
declare(strict_types=1);
// No unauthenticated/public API is registered by Titan Onboarding.
// Cross-engine operations use versioned governed contracts and Titan capability execution.
