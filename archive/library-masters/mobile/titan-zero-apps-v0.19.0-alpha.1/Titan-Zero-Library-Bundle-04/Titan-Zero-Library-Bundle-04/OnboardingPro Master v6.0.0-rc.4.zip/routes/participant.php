<?php
declare(strict_types=1);
use App\Extensions\OnboardingPro\System\Http\Controllers\ParticipantJourneyController;
use App\Extensions\OnboardingPro\System\Http\Middleware\ParticipantGrantMiddleware;
use Illuminate\Support\Facades\Route;
Route::middleware(['web',ParticipantGrantMiddleware::class])->prefix('onboarding/participant')->as('onboarding.participant.')->group(function():void{
 Route::get('{grant}',[ParticipantJourneyController::class,'show'])->name('show');
 Route::post('{grant}/steps/{step}/complete',[ParticipantJourneyController::class,'completeStep'])->name('step.complete');
});
