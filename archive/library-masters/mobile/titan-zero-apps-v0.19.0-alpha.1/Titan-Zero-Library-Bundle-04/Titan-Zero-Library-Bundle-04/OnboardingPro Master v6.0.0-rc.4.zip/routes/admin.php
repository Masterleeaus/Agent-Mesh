<?php
declare(strict_types=1);
use App\Extensions\OnboardingPro\System\Http\Controllers\JourneyAdminController;
use App\Extensions\OnboardingPro\System\Http\Controllers\AIJourneyBuilderController;
use App\Extensions\OnboardingPro\System\Http\Controllers\AnalyticsController;
use App\Extensions\OnboardingPro\System\Http\Middleware\RequireOnboardingAdmin;
use App\Extensions\OnboardingPro\System\Http\Middleware\ResolveOnboardingCompany;
use Illuminate\Support\Facades\Route;
Route::middleware(['web','auth',RequireOnboardingAdmin::class,ResolveOnboardingCompany::class])->prefix('dashboard/admin/onboarding-pro')->as('dashboard.admin.onboarding-pro.')->group(function():void{
 Route::get('/',[JourneyAdminController::class,'index'])->name('index');
 Route::get('journeys',[JourneyAdminController::class,'index'])->name('journeys.index');
 Route::get('journeys/ai-builder',fn()=>view('onboarding-pro::journeys.ai-builder'))->name('journeys.ai-builder');
 Route::post('journeys/ai-builder/prepare',[AIJourneyBuilderController::class,'prepare'])->name('journeys.ai.prepare');
 Route::get('journeys/{journey}',[JourneyAdminController::class,'show'])->name('journeys.show');
 Route::get('journeys/{journey}/versions',[JourneyAdminController::class,'versions'])->name('journeys.versions');
 Route::get('journeys/{journey}/builder',[JourneyAdminController::class,'builder'])->name('journeys.builder');
 Route::post('journeys/{journey}/builder/validate',[JourneyAdminController::class,'validateDefinition'])->name('journeys.builder.validate');
 Route::put('journeys/{journey}/builder',[JourneyAdminController::class,'saveDraft'])->name('journeys.builder.save');
 Route::post('journeys/{journey}/builder/preview',[JourneyAdminController::class,'preview'])->name('journeys.builder.preview');
 Route::get('analytics',[AnalyticsController::class,'index'])->name('analytics.index');
});
