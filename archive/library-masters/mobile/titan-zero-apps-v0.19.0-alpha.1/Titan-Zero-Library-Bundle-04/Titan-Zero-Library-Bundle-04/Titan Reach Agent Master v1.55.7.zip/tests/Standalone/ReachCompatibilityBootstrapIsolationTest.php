<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$provider = file_get_contents($root.'/System/TitanReachAgentServiceProvider.php');
$registrar = file_get_contents($root.'/System/Compatibility/LegacyCompatibilityRegistrar.php');
$fail = static function (string $message): never { fwrite(STDERR, $message."\n"); exit(1); };

foreach (['App\\Models\\Chatbot\\Chatbot', 'OpenAiChatCompletionProvider', 'EloquentLegacyChatbotCatalogue', 'TitanReachAgentChatController'] as $forbidden) {
    if (str_contains($provider, $forbidden)) $fail('Canonical provider bootstrap contains legacy concrete dependency: '.$forbidden);
}
if (!str_contains($provider, 'LegacyCompatibilityRegistrar::register($this->app)')) $fail('Compatibility registrar is not invoked by canonical bootstrap.');
if (!str_contains($provider, 'LegacyCompatibilityRegistrar::registerUserChatRoutes($router)')) $fail('Legacy chat route is not delegated to the compatibility registrar.');
if (!str_contains($registrar, 'TitanReachAgentChatController::class')) $fail('Legacy chat controller route is not owned by the compatibility registrar.');
if (!str_contains($registrar, "->name('chat.index')")) $fail('Compatibility registrar did not preserve the legacy chat route name.');
if (!str_contains($registrar, "class_exists(\\App\\Models\\Chatbot\\Chatbot::class)")) $fail('Compatibility registrar does not dynamically discover legacy Chatbot availability.');
if (str_contains($registrar, 'providers/Titan-') || str_contains($registrar, 'extensions/Titan-') || str_contains($registrar, '.zip')) $fail('Compatibility registrar depends on a physical package path.');

echo "Reach compatibility bootstrap isolation: PASS\n";
