<?php
$root = dirname(__DIR__, 2);
$fail = static function (string $message): never { fwrite(STDERR, $message.PHP_EOL); exit(1); };
$service = file_get_contents($root.'/System/Services/VideoGenerationService.php');
$host = file_get_contents($root.'/System/Services/Video/HostRoutedVideoGenerationClient.php');
$compat = file_get_contents($root.'/System/Compatibility/Video/LegacyReachProVeoVideoClient.php');
$provider = file_get_contents($root.'/System/TitanReachAgentServiceProvider.php');
foreach (['GoogleVeo2Service', 'ApiHelper', 'TitanReachPro'] as $forbidden) if (str_contains($service, $forbidden)) $fail("Canonical video service leaks legacy implementation: $forbidden");
if (!str_contains($host, "titan.ai.video-provider")) $fail('Canonical Reach video client does not prefer host/public video routing.');
if (!str_contains($compat, 'GoogleVeo2Service')) $fail('Legacy Reach Pro Veo compatibility implementation is not isolated.');
if (!str_contains($provider, 'VideoGenerationClient::class, HostRoutedVideoGenerationClient::class')) $fail('Canonical video client is not runtime-registered.');
echo "CanonicalVideoRoutingIsolationTest OK\n";
