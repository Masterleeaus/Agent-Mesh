<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$controller = file_get_contents($root.'/System/Http/Controllers/TitanReachAgentChatController.php');
$compat = file_get_contents($root.'/System/Compatibility/Ai/LegacyOpenAiChatRuntime.php');
$provider = file_get_contents($root.'/System/TitanReachAgentServiceProvider.php');
$registrar = file_get_contents($root.'/System/Compatibility/LegacyCompatibilityRegistrar.php');
$fail = static function (string $message): never { fwrite(STDERR, $message."\n"); exit(1); };

if (str_contains($controller, 'ApiHelper') || str_contains($controller, "config(['openai.api_key'")) {
    $fail('Canonical Reach chat controller still owns concrete OpenAI credential setup.');
}
if (! str_contains($controller, 'LegacyOpenAiChatRuntime')) {
    $fail('Reach chat controller does not route legacy AI bootstrap through compatibility boundary.');
}
if (! str_contains($compat, "legacy_frontend_openai_key_passthrough', false")) {
    $fail('Legacy frontend OpenAI credential passthrough does not fail closed by default.');
}
if (! str_contains($compat, 'ApiHelper::setOpenAiKey()')) {
    $fail('Legacy OpenAI credential access is not confined to the compatibility bridge.');
}
if (str_contains($provider, 'LegacyOpenAiChatRuntime')) {
    $fail('Canonical Reach service provider still imports the concrete legacy OpenAI runtime.');
}
if (! str_contains($registrar, 'singleton(LegacyOpenAiChatRuntime::class)')) {
    $fail('Legacy AI compatibility runtime is not registered inside the compatibility registrar.');
}

echo "Reach legacy AI credential isolation: PASS\n";
