<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\Tests;

use App\Extensions\TitanReachAgent\System\Services\FieldService\SharedFieldServiceContextResolver;
use PHPUnit\Framework\TestCase;

final class FieldServiceContextAdapterTest extends TestCase
{
    public function testStandaloneFallbackNeverInventsLicencesEmergencyOrCoverage(): void
    {
        $context = (new SharedFieldServiceContextResolver())->resolve(456, null);

        self::assertSame(456, $context['company_id']);
        self::assertSame([], $context['services']);
        self::assertSame([], $context['service_areas']);
        self::assertFalse($context['emergency_available']);
        self::assertSame([], $context['licence_trust_statements']);
        self::assertTrue($context['standalone_fallback']);
    }
}
