<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldServiceAgentMediaPrivacyStaticTest extends TestCase
{
    public function test_agent_generation_prompts_include_field_service_media_privacy_guardrails(): void
    {
        $root = dirname(__DIR__);
        $postGeneration = file_get_contents($root . '/System/Services/PostGenerationService.php');
        $imageGeneration = file_get_contents($root . '/System/Services/ImageGenerationService.php');

        self::assertStringContainsString('never invent customer names', $postGeneration);
        self::assertStringContainsString('do not identify people', strtolower($postGeneration));
        self::assertStringContainsString('no faces', $imageGeneration);
        self::assertStringContainsString('no exact address', $imageGeneration);
        self::assertStringContainsString('no licence plate', $imageGeneration);
    }
}
