<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$controller = file_get_contents($root . '/System/Http/Controllers/TitanReachAgentChatController.php');
$manager = file_get_contents($root . '/System/Services/Ai/AiProviderManager.php');
$serviceProvider = file_get_contents($root . '/System/TitanReachAgentServiceProvider.php');
$compatRegistrar = file_get_contents($root . '/System/Compatibility/LegacyCompatibilityRegistrar.php');
$adapter = file_get_contents($root . '/System/Compatibility/Chatbot/EloquentLegacyChatbotCatalogue.php');

$fail = static function (string $message): never {
    fwrite(STDERR, $message . "\n");
    exit(1);
};

if (str_contains($controller, 'App\\Models\\Chatbot\\Chatbot') || str_contains($controller, 'Chatbot::query()')) {
    $fail('Canonical Reach chat controller still directly depends on the legacy Chatbot model.');
}
if (!str_contains($controller, 'ChatbotCatalogue')) {
    $fail('Reach chat controller does not use the compatibility catalogue boundary.');
}
if (!str_contains($adapter, 'App\\Models\\Chatbot\\Chatbot')) {
    $fail('Legacy Chatbot dependency is not confined to the compatibility adapter.');
}
if (str_contains($manager, 'OpenAiChatCompletionProvider::class')) {
    $fail('Canonical Reach AI manager still selects a concrete OpenAI provider implementation.');
}
if (!str_contains($manager, "HOST_PROVIDER_BINDING = 'titan.ai.chat-provider'")) {
    $fail('Canonical host AI routing binding is missing.');
}
if (!str_contains($manager, "LEGACY_FALLBACK_BINDING = 'titan-reach-agent.ai.legacy-fallback-provider'")) {
    $fail('Legacy AI fallback is not explicitly isolated.');
}
if (str_contains($serviceProvider, 'OpenAiChatCompletionProvider') || str_contains($serviceProvider, 'EloquentLegacyChatbotCatalogue')) {
    $fail('Canonical Reach service provider still imports concrete legacy AI/Chatbot implementations.');
}
if (!str_contains($serviceProvider, 'LegacyCompatibilityRegistrar::register($this->app)')) {
    $fail('Canonical Reach service provider does not delegate legacy registration to the compatibility boundary.');
}
if (!str_contains($compatRegistrar, 'AiProviderManager::LEGACY_FALLBACK_BINDING')) {
    $fail('Legacy AI fallback binding is not registered inside the compatibility registrar.');
}
if (!str_contains($compatRegistrar, 'ChatbotCatalogue::class, $catalogue')) {
    $fail('Legacy Chatbot compatibility catalogue is not registered inside the compatibility registrar.');
}
if (!str_contains($compatRegistrar, 'UnavailableLegacyChatbotCatalogue')) {
    $fail('Legacy Chatbot registration does not fail closed when the historical model is absent.');
}

fwrite(STDOUT, "Reach compatibility isolation OK\n");
