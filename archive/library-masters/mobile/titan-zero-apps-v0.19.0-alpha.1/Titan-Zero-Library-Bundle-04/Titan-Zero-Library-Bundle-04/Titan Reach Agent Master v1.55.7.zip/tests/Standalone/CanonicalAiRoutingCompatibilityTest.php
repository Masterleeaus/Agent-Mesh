<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$manager = file_get_contents($root . '/System/Services/Ai/AiProviderManager.php');
$canonical = file_get_contents($root . '/System/Services/Analysis/AnalysisClient.php');
$legacy = file_get_contents($root . '/System/Services/Analysis/OpenAiAnalysisClient.php');

if (!str_contains($manager, "HOST_PROVIDER_BINDING = 'titan.ai.chat-provider'")) {
    fwrite(STDERR, "Host AI routing binding missing\n"); exit(1);
}
$hostPos = strpos($manager, 'bound(self::HOST_PROVIDER_BINDING)');
$legacyPos = strpos($manager, 'bound(self::LEGACY_FALLBACK_BINDING)');
if ($hostPos === false || $legacyPos === false || $hostPos > $legacyPos) {
    fwrite(STDERR, "Legacy AI fallback precedes canonical host routing\n"); exit(1);
}
if (str_contains($manager, 'OpenAiChatCompletionProvider::class')) {
    fwrite(STDERR, "Canonical AI manager names provider-specific OpenAI implementation\n"); exit(1);
}
if (str_contains($canonical, 'Http::') || str_contains($canonical, 'api.openai.com')) {
    fwrite(STDERR, "Canonical analysis client performs direct provider transport\n"); exit(1);
}
if (!str_contains($legacy, 'class OpenAiAnalysisClient extends AnalysisClient')) {
    fwrite(STDERR, "Legacy analysis compatibility alias missing\n"); exit(1);
}
foreach (glob($root . '/System/Console/Commands/*.php') as $command) {
    $source = file_get_contents($command);
    if (str_contains($source, 'Services\\Analysis\\OpenAiAnalysisClient')) {
        fwrite(STDERR, "Canonical command still depends on provider-specific analysis client: $command\n"); exit(1);
    }
}

fwrite(STDOUT, "Canonical AI routing compatibility OK\n");
