<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

class LocalGrowthAgentStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function test_local_growth_profile_and_recommendation_services_exist(): void
    {
        $this->assertFileExists($this->root . '/System/Services/FieldService/LocalGrowthAgentProfile.php');
        $this->assertFileExists($this->root . '/System/Services/FieldService/LocalGrowthRecommendationService.php');
    }

    public function test_agent_model_contains_field_service_growth_fields(): void
    {
        $model = file_get_contents($this->root . '/System/Models/TitanReachAgent.php');
        foreach (['field_service_vertical', 'field_service_services', 'field_service_areas', 'field_service_growth_goals', 'field_service_content_mix', 'field_service_strategy'] as $field) {
            $this->assertStringContainsString($field, $model);
        }
    }

    public function test_generation_prompt_has_local_growth_and_no_invention_rules(): void
    {
        $service = file_get_contents($this->root . '/System/Services/PostGenerationService.php');
        foreach (['Local Growth Agent', 'quote requests', 'bookings', 'reviews', 'Never invent service areas', 'emergency availability'] as $needle) {
            $this->assertStringContainsString($needle, $service);
        }
    }

    public function test_create_wizard_collects_field_service_strategy_inputs(): void
    {
        $view = file_get_contents($this->root . '/resources/views/create/index.blade.php') . file_get_contents($this->root . '/resources/views/create/create-step-2.blade.php');
        foreach (['field_service_vertical', 'field_service_services', 'field_service_areas', 'field_service_growth_goals', 'field_service_content_mix'] as $needle) {
            $this->assertStringContainsString($needle, $view);
        }
    }
}
