<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Tests;

use App\Extensions\TitanReachAgent\System\Support\LiveInstallerDiagnostics;
use PHPUnit\Framework\TestCase;

final class LiveInstallerDiagnosticsStaticTest extends TestCase
{
    public function testRequiredChecksCoverInstallRuntimeFailures(): void
    {
        $checks = LiveInstallerDiagnostics::requiredChecks();

        self::assertContains('extension_json_parseable', $checks);
        self::assertContains('service_provider_loadable', $checks);
        self::assertContains('config_registered', $checks);
        self::assertContains('migrations_discoverable', $checks);
        self::assertContains('routes_discoverable', $checks);
        self::assertContains('views_discoverable', $checks);
        self::assertContains('company_id_runtime_context_available', $checks);
    }

    public function testDiagnosticsAreRedacted(): void
    {
        $summary = LiveInstallerDiagnostics::summarize([
            'stage' => 'migrating',
            'events' => [
                'access_token' => 'secret-token',
                'message_body' => 'private customer message',
                'safe' => 'visible',
            ],
        ]);

        self::assertSame('[redacted]', $summary['events']['access_token']);
        self::assertSame('[redacted]', $summary['events']['message_body']);
        self::assertSame('visible', $summary['events']['safe']);
    }
}
