<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class SecurityHardeningStaticTest extends TestCase
{
    private function read(string $path): string
    {
        return file_get_contents(dirname(__DIR__) . '/' . $path) ?: '';
    }

    public function test_scraper_blocks_ssrf_and_enforces_tls_limits(): void
    {
        $scraper = $this->read('System/Services/WebScrapingService.php');

        self::assertStringContainsString("'verify'          => true", $scraper);
        self::assertStringContainsString('FILTER_FLAG_NO_PRIV_RANGE', $scraper);
        self::assertStringContainsString('FILTER_FLAG_NO_RES_RANGE', $scraper);
        self::assertStringContainsString('169.254.169.254', $scraper);
        self::assertStringContainsString('metadata.google.internal', $scraper);
        self::assertStringContainsString('on_redirect', $scraper);
        self::assertStringContainsString('maxBodyBytes', $scraper);
        self::assertStringContainsString("Only HTTP(S) URLs are allowed", $scraper);
        self::assertStringNotContainsString("'verify'          => false", $scraper);
    }

    public function test_fal_callbacks_require_non_guessable_state_and_company_correlation(): void
    {
        $controller = $this->read('System/Http/Controllers/TitanReachAgentController.php');
        $image = $this->read('System/Services/ImageGenerationService.php');
        $migration = $this->read('database/migrations/2026_02_20_000010_add_security_state_to_agent_posts.php');
        $provider = $this->read('System/TitanReachAgentServiceProvider.php');

        self::assertStringContainsString('bin2hex(random_bytes(32))', $image);
        self::assertStringContainsString('image_callback_state', $controller . $migration);
        self::assertStringContainsString("->where('image_callback_state', $", $controller);
        self::assertStringContainsString("->where('company_id', $", $controller);
        self::assertStringContainsString("'middleware' => ['throttle:60,1']", $provider);
        self::assertStringNotContainsString('Log::info(\'Fal.ai webhook received\', $request->all())', $controller);
    }
}
