<?php

$root = dirname(__DIR__, 2);
$fail = static function (string $message): never { fwrite(STDERR, $message . PHP_EOL); exit(1); };

$canonicalFiles = [
    $root . '/System/Services/Analysis/AnalysisClient.php',
    $root . '/System/Services/Analysis/AnalysisRecorder.php',
    $root . '/System/Services/TargetAudienceService.php',
    $root . '/System/Services/PostGenerationService.php',
    $root . '/System/Services/ImageGenerationService.php',
];

foreach ($canonicalFiles as $file) {
    $code = file_get_contents($file);
    foreach (["services.openai", 'EntityEnum::GPT_', 'OpenAiAnalysisClient', 'OpenAiChatCompletionProvider', 'api.openai.com'] as $forbidden) {
        if (str_contains($code, $forbidden)) {
            $fail(basename($file) . ' still contains backend-specific canonical AI selection: ' . $forbidden);
        }
    }
    if (! str_contains($code, 'AiProviderManager::class')) {
        $fail(basename($file) . ' does not route shared language generation through AiProviderManager.');
    }
}

$post = file_get_contents($root . '/System/Services/PostGenerationService.php');
if (! str_contains($post, "\$result->provider === 'openai'")) {
    $fail('Legacy direct credit accounting is not confined to the legacy OpenAI fallback result.');
}
if (! str_contains($post, "config('titan-reach-agent.ai.content_model'")) {
    $fail('Post generation does not use the backend-neutral model hint.');
}

$config = file_get_contents($root . '/config/titan-reach-agent.php');
foreach (['analysis_model', 'summary_model', 'content_model', 'audience_model', 'image_prompt_model'] as $key) {
    if (! str_contains($config, "'{$key}'")) {
        $fail('Backend-neutral Reach model hint configuration is missing: ' . $key);
    }
}

$provider = file_get_contents($root . '/System/TitanReachAgentServiceProvider.php');
if (! str_contains($provider, "config/titan-reach-agent.php")) {
    $fail('Backend-neutral Reach configuration is not registered.');
}

echo "canonical-ai-routing-neutrality: ok\n";
