<?php

it('contains final runtime certification controls', function () {
    $certification = new \App\Extensions\TitanReachAgent\System\Support\FinalRuntimeCertification();
    $summary = $certification->summary();

    expect($summary['step'])->toBe('24');
    expect($summary['status'])->toBe('runtime-ready');
    expect($summary['requires_company_id'])->toBeTrue();
    expect($summary['standalone_safe'])->toBeTrue();
    expect($summary['security_controls_locked'])->toBeTrue();
    expect($summary['privacy_controls_locked'])->toBeTrue();
    expect($summary['publish_governance_locked'])->toBeTrue();
    expect($summary['webhooks_fail_closed'])->toBeTrue();
    expect($summary['demo_data_marked_demo_only'])->toBeTrue();
    expect($summary['titan_integrations_optional'])->toBeTrue();
    expect($certification->certificationGates())->toContain('lead_flow_simulation');
    expect($certification->certificationGates())->toContain('publish_governance');
});
