<?php

use PHPUnit\Framework\TestCase;

final class FieldServiceAttributionAdapterStaticTest extends TestCase
{
    public function test_agent_adapter_can_emit_or_fallback_without_hard_dependency(): void
    {
        $root = dirname(__DIR__);
        $adapter = $root . '/System/Services/FieldService/SharedFieldServiceAttributionEmitter.php';

        $this->assertFileExists($adapter);
        $source = file_get_contents($adapter);
        $this->assertStringContainsString('FieldServiceAttributionService', $source);
        $this->assertStringContainsString('class_exists', $source);
        $this->assertStringContainsString('standalone', $source);
        $this->assertStringContainsString('standalone_safe', $source);
    }
}
