<?php

namespace Tests;

use PHPUnit\Framework\TestCase;

class LocalGrowthIntelligenceStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function test_local_growth_intelligence_service_and_signal_dto_exist(): void
    {
        $this->assertFileExists($this->root . '/System/Services/FieldService/LocalGrowthIntelligenceService.php');
        $this->assertFileExists($this->root . '/System/Services/FieldService/Dto/LocalGrowthSignal.php');
    }

    public function test_intelligence_service_uses_only_configured_context_signals(): void
    {
        $service = file_get_contents($this->root . '/System/Services/FieldService/LocalGrowthIntelligenceService.php');

        foreach (['configured service area', 'configured services', 'Do not invent missing business facts', 'profile_gap', 'local_availability', 'seasonal_demand', 'content_gap'] as $needle) {
            $this->assertStringContainsString($needle, $service);
        }
    }

    public function test_post_generation_prompt_consumes_local_growth_intelligence(): void
    {
        $service = file_get_contents($this->root . '/System/Services/PostGenerationService.php');

        foreach (['LocalGrowthIntelligenceService', 'Local Growth Intelligence Signals', 'local_growth_signal', 'local_growth_signals_considered'] as $needle) {
            $this->assertStringContainsString($needle, $service);
        }
    }

    public function test_dashboard_exposes_local_growth_intelligence_panel(): void
    {
        $controller = file_get_contents($this->root . '/System/Http/Controllers/TitanReachAgentController.php');
        $dashboard = file_get_contents($this->root . '/resources/views/dashboard/index.blade.php');
        $partial = file_get_contents($this->root . '/resources/views/dashboard/local-growth-intelligence.blade.php');

        $this->assertStringContainsString('local_growth_signals', $controller);
        $this->assertStringContainsString('dashboard.local-growth-intelligence', $dashboard);
        $this->assertStringContainsString('Local Growth Intelligence', $partial);
    }

    public function test_schema_tracks_local_growth_intelligence_without_private_customer_data(): void
    {
        $migration = file_get_contents($this->root . '/database/migrations/2026_02_24_000030_add_local_growth_intelligence_fields.php');
        $model = file_get_contents($this->root . '/System/Models/TitanReachAgent.php');
        $postModel = file_get_contents($this->root . '/System/Models/TitanReachAgentPost.php');

        foreach (['local_growth_intelligence', 'local_growth_signal_scores', 'local_growth_recommendation_state'] as $needle) {
            $this->assertStringContainsString($needle, $migration);
            $this->assertStringContainsString($needle, $model);
        }

        $this->assertStringContainsString('local_growth_signal', $migration);
        $this->assertStringContainsString('local_growth_signal', $postModel);
        $this->assertStringNotContainsString('customer_name', $migration);
        $this->assertStringNotContainsString('exact_address', $migration);
    }
}
