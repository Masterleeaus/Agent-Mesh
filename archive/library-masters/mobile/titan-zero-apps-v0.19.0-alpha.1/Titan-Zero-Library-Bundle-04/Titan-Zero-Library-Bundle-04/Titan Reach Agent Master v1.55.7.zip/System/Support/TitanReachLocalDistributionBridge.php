<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

final class TitanReachLocalDistributionBridge
{
    public const POLICY = ['company_id_required','assisted','manual_completion'];

    public function plan(array $payload): array
    {
        if ((int)($payload['company_id'] ?? 0) <= 0) return ['allowed'=>false,'state'=>'blocked','reasons'=>['company_id_required']];
        if (function_exists('app') && app()->bound('titan-reach.local-distribution')) {
            return app('titan-reach.local-distribution')->plan($payload);
        }
        return ['allowed'=>true,'state'=>'standalone_assisted','reasons'=>[], 'requirements'=>['manual_completion','assisted']];
    }
}
