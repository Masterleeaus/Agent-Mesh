<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Navigation;

final class TitanReachMenuDefinition
{
    public static function root(): array
    {
        return [
            'key' => 'ext_titan_reach',
            'label' => 'Marketing & Advertising',
            'route' => null,
            'icon' => 'tabler-speakerphone',
            'order' => 8,
        ];
    }

    public static function item(): array
    {
        return [
            'key' => 'titan_reach_agent',
            'label' => 'Growth Agent',
            'route' => 'dashboard.user.titan-reach.agent.index',
            'route_slug' => '/dashboard/user/titan-reach/agent',
            'icon' => 'tabler-sparkles',
            'order' => 2,
        ];
    }
}
