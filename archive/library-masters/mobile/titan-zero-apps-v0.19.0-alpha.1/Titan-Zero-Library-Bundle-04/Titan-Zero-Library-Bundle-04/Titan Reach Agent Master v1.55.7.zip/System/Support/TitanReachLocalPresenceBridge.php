<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

final class TitanReachLocalPresenceBridge
{
    public function assess(array $context): array
    {
        $companyId = $context['company_id'] ?? null;
        if (!$companyId) return ['status' => 'blocked', 'reason' => 'company_id_required'];
        if (app()->bound('titan-reach.local-presence.engine')) {
            return app('titan-reach.local-presence.engine')->assess($context);
        }
        return ['status' => 'standalone_safe', 'company_id' => $companyId, 'score' => null, 'gaps' => []];
    }
}
