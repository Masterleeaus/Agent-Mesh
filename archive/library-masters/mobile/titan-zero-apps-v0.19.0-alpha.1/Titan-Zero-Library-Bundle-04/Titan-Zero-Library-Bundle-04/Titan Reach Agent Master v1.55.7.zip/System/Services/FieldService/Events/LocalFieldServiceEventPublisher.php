<?php

namespace App\Extensions\TitanReachAgent\System\Services\FieldService\Events;

use App\Extensions\TitanReachAgent\System\Contracts\FieldService\FieldServiceEventPublisher;

class LocalFieldServiceEventPublisher implements FieldServiceEventPublisher
{
    public function __construct(private readonly FieldServiceEventBus $bus = new FieldServiceEventBus()) {}

    /** @param array<string, mixed> $payload @param array<string, mixed> $metadata @return array<string, mixed> */
    public function publish(string $eventType, int|string $companyId, string $sourceExtension, array $payload = [], array $metadata = []): array
    {
        return $this->bus->publishArray($eventType, $companyId, $sourceExtension, $payload, $metadata);
    }
}
