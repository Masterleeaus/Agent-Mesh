<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\FieldService;

use App\Extensions\TitanReachAgent\System\Support\FieldServiceMarketingPermissionGate;

class FieldServiceWorkspaceNavigator
{
    public function __construct(private readonly FieldServiceMarketingPermissionGate $permissions)
    {
    }

    public function module(): array
    {
        return [
            'key' => 'local_growth_agent',
            'label' => 'Local Growth Agent',
            'role' => 'Growth intelligence and content proposer',
            'workspace' => 'field_home_services_social_marketing',
        ];
    }

    public function links(?object $user = null, ?int $companyId = null): array
    {
        $links = [['label' => 'Agents', 'path' => '/dashboard/user/titan-reach/agent/agents', 'action' => 'view'], ['label' => 'Posts', 'path' => '/dashboard/user/titan-reach/agent/posts', 'action' => 'content'], ['label' => 'Analytics', 'path' => '/dashboard/user/titan-reach/agent/analytics', 'action' => 'view'], ['label' => 'Calendar', 'path' => '/dashboard/user/titan-reach/agent/calendar', 'action' => 'view']];

        return array_map(function (array $link) use ($user, $companyId): array {
            $link['enabled'] = $this->permissions->allows($user, $link['action'], $companyId);
            $link['permission'] = $this->permissions->abilityFor($link['action']);

            return $link;
        }, $links);
    }

    public function crossExtensionLinks(): array
    {
        return [
            ['module' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'binding' => 'titan-reach.field-service.context'],
            ['module' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'binding' => 'titan-reach-agent.field-service.context'],
            ['module' => 'lead_review_automation', 'label' => 'Lead & Review Automation', 'binding' => 'titan-reach-flow.field-service.context'],
            ['module' => 'campaign_playbooks', 'label' => 'Campaign Playbooks', 'binding' => 'titan-reach-campaigns.field-service.context'],
        ];
    }
}
