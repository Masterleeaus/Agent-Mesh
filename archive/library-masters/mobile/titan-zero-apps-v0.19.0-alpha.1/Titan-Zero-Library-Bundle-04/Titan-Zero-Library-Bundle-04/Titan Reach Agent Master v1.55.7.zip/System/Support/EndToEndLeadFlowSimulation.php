<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

/**
 * Deterministic end-to-end lead-flow simulation for field/home-service social marketing.
 *
 * This class intentionally avoids framework/database calls. It lets installer,
 * static and post-install smoke checks prove the integration contract exists:
 * social engagement -> automation trigger -> social lead -> attribution event -> workspace visibility.
 */
final class EndToEndLeadFlowSimulation
{
    public const EXTENSION_KEY = 'titan-reach-agent';
    public const MODULE_SLUG = 'local_growth_agent';
    public const MODULE_NAME = 'Local Growth Agent';
    public const VERSION = '1.26';

    /** @return array<string, mixed> */
    public static function scenario(): array
    {
        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'module_name' => self::MODULE_NAME,
            'version' => self::VERSION,
            'role' => 'growth recommendation and attribution participant',
            'company_scoped' => true,
            'standalone_safe' => true,
            'scenario' => 'field_service_quote_request',
            'steps' => self::steps(),
            'required_events' => self::requiredEvents(),
            'redacted_fields' => self::redactedFields(),
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public static function steps(): array
    {
        return [
            ['key' => 'engagement_received', 'requires_company_id' => true, 'produces' => ['source_platform', 'source_post_id', 'redacted_customer_ref']],
            ['key' => 'automation_trigger_matched', 'requires_company_id' => true, 'produces' => ['matched_keyword', 'service_interest', 'urgency']],
            ['key' => 'social_lead_captured', 'requires_company_id' => true, 'produces' => ['social_lead_id', 'lead_status', 'consent_status']],
            ['key' => 'attribution_recorded', 'requires_company_id' => true, 'produces' => ['attribution_key', 'conversion_goal']],
            ['key' => 'event_published', 'requires_company_id' => true, 'produces' => self::requiredEvents()],
            ['key' => 'workspace_visible', 'requires_company_id' => true, 'produces' => ['lead_review_automation_panel', 'field_marketing_hub_summary']],
        ];
    }

    /** @return array<int, string> */
    public static function requiredEvents(): array
    {
        return ['field_service.lead_captured', 'field_service.conversion_recorded', 'field_service.review_opportunity'];
    }

    /** @return array<int, string> */
    public static function redactedFields(): array
    {
        return ['customer_name', 'customer_handle', 'customer_external_id', 'contact_value', 'raw_webhook_body', 'token', 'secret', 'signature'];
    }

    /** @return array<string, mixed> */
    public static function sampleInput(): array
    {
        return [
            'company_id' => 1001,
            'platform' => 'facebook',
            'message' => 'Can I get a quote for gutter cleaning this week?',
            'service_interest' => 'gutter cleaning',
            'service_area' => 'configured_service_area',
            'customer_name' => 'REDACTED',
            'customer_handle' => 'REDACTED',
            'raw_webhook_body' => 'REDACTED',
        ];
    }

    /** @param array<string, mixed> $input @return array<string, mixed> */
    public static function simulate(array $input = []): array
    {
        $payload = array_replace(self::sampleInput(), $input);
        $companyId = $payload['company_id'] ?? null;
        $hasCompany = is_int($companyId) || (is_string($companyId) && $companyId !== '');
        $failed = [];

        if (! $hasCompany) {
            $failed[] = 'company_id is required for tenant-correlated lead flow simulation';
        }

        $redacted = self::redact($payload);

        return [
            'ok' => $failed === [],
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'company_id' => $companyId,
            'failed' => $failed,
            'redacted_input' => $redacted,
            'steps' => self::steps(),
            'events' => self::requiredEvents(),
            'workspace_visible' => $failed === [],
            'standalone_safe' => true,
        ];
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    public static function redact(array $payload): array
    {
        foreach (self::redactedFields() as $field) {
            if (array_key_exists($field, $payload)) {
                $payload[$field] = 'REDACTED';
            }
        }

        return $payload;
    }

    /** @param string $extensionRoot absolute extension root path. @return array<string, mixed> */
    public static function report(string $extensionRoot): array
    {
        $root = rtrim($extensionRoot, DIRECTORY_SEPARATOR);
        $required = [
            'config/field-service-lead-flow-simulation.php',
            'System/Support/EndToEndLeadFlowSimulation.php',
            'tests/EndToEndLeadFlowSimulationStaticTest.php',
            'docs/STEP19_END_TO_END_LEAD_FLOW_SIMULATION.md',
        ];
        $filesystem = [];
        foreach ($required as $path) {
            $absolute = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);
            $filesystem[] = ['path' => $path, 'ok' => file_exists($absolute), 'message' => file_exists($absolute) ? 'present' : 'missing lead-flow simulation dependency'];
        }
        $providerSource = self::providerSource($extensionRoot);
        $source = [
            ['name' => 'lead-flow config registered', 'ok' => str_contains($providerSource, 'field-service-lead-flow-simulation.php'), 'message' => 'service provider must merge field-service-lead-flow-simulation.php'],
            ['name' => 'company correlation present', 'ok' => str_contains((string) file_get_contents(__FILE__), 'company_id'), 'message' => 'simulation must require company_id'],
            ['name' => 'sensitive fields redacted', 'ok' => str_contains((string) file_get_contents(__FILE__), 'raw_webhook_body') && str_contains((string) file_get_contents(__FILE__), 'REDACTED'), 'message' => 'simulation must redact webhook/customer data'],
        ];
        $failedFilesystem = array_values(array_filter($filesystem, static fn (array $row): bool => ! (bool) $row['ok']));
        $failedSource = array_values(array_filter($source, static fn (array $row): bool => ! (bool) $row['ok']));

        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'version' => self::VERSION,
            'scenario' => self::scenario(),
            'filesystem' => $filesystem,
            'source' => $source,
            'simulation' => self::simulate(),
            'ok' => $failedFilesystem === [] && $failedSource === [] && self::simulate()['ok'] === true,
        ];
    }

    private static function providerSource(string $extensionRoot): string
    {
        foreach (['System/TitanReachProServiceProvider.php', 'System/TitanReachAgentServiceProvider.php', 'System/TitanReachFlowServiceProvider.php', 'System/TitanReachCampaignsServiceProvider.php'] as $provider) {
            $path = rtrim($extensionRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $provider);
            if (is_file($path)) {
                return (string) file_get_contents($path);
            }
        }

        return '';
    }
}
