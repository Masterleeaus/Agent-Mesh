<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanReachAgent\System\Console\Commands\CheckPendingImagesCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\CheckPendingVideosCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\GenerateAgentPostsCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\PostMetricsAnalyzerCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\PostPerformanceAdvisorCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\RegeneratePostImagesCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\SeedDemoDataCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\TrendFinderCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\UpdateAverageMetricsCommand;
use App\Extensions\TitanReachAgent\System\Console\Commands\WeeklySocialTrendsCommand;
use App\Extensions\TitanReachAgent\System\Http\Controllers\TitanReachAgentAnalysisController;
use App\Extensions\TitanReachAgent\System\Http\Controllers\TitanReachAgentChatSettingsController;
use App\Extensions\TitanReachAgent\System\Http\Controllers\TitanReachAgentController;
use App\Extensions\TitanReachAgent\System\Http\Controllers\TitanReachAgentPostController;
use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Extensions\TitanReachAgent\System\Policies\TitanReachAgentPolicy;
use App\Extensions\TitanReachAgent\System\Http\Controllers\FieldServiceWorkspaceController;
use App\Extensions\TitanReachAgent\System\Navigation\TitanReachMenuInstaller;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use App\Extensions\TitanReachAgent\System\Services\FieldService\SharedFieldServiceContextResolver;
use App\Extensions\TitanReachAgent\System\Services\Ai\AiProviderManager;
use App\Extensions\TitanReachAgent\System\Services\Ai\NullChatCompletionProvider;
use App\Extensions\TitanReachAgent\System\Compatibility\LegacyCompatibilityRegistrar;
use App\Extensions\TitanReachAgent\System\Services\Video\VideoGenerationClient;
use App\Extensions\TitanReachAgent\System\Services\Video\HostRoutedVideoGenerationClient;

class TitanReachAgentServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-reach-agent', \App\Extensions\TitanReachAgent\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton('field-service.live-install-evidence.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\LiveInstallerEvidenceCapture::class);
        $this->app->singleton('field-service.commercial.enforcement-upgrade-ux.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\CommercialTierEnforcementUpgradeUX::class);
        $this->app->singleton('field-service.local-growth-operational-trial.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\LocalGrowthAgentOperationalTrial::class);
        $this->app->singleton('field-service.hub-workflow-trial.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\FieldMarketingHubWorkflowTrial::class);
        $this->app->singleton('field-service.webhook-dry-run.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\RealWebhookAutomationDryRun::class);
        $this->app->singleton('field-service.migration-compatibility.titan_reach_agent', \App\Extensions\TitanReachAgent\System\Support\DatabaseMigrationUpgradeCompatibility::class);
        $this->app->singleton('field-service.runtime-repair.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\RuntimeMenuRouteBladeRepair::class);
        $this->app->singleton('field-service.commercial.plan-limits.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\FieldServiceCommercialPlanLimits::class);
        $this->registerConfig();
        $this->app->singleton('field-service.workspace.navigator.local_growth_agent', \App\Extensions\TitanReachAgent\System\Services\FieldService\FieldServiceWorkspaceNavigator::class);
        $this->app->singleton('field-service.workspace.health.local_growth_agent', \App\Extensions\TitanReachAgent\System\Services\FieldService\FieldServiceWorkspaceHealth::class);
        $this->app->singleton('titan-reach-agent.field-service.context', SharedFieldServiceContextResolver::class);
        $this->app->singleton(AiProviderManager::class);
        $this->app->singleton(NullChatCompletionProvider::class);
        $this->app->singleton(VideoGenerationClient::class, HostRoutedVideoGenerationClient::class);
        LegacyCompatibilityRegistrar::register($this->app);
    }


    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-agent.php', 'titan-reach-agent');
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-titan-zero-closed-loop.php', 'titan-reach-titan-zero-closed-loop.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-production-release.php', 'titan-reach-production-release.' . self::class);
        $this->app->singleton('titan-reach.production-release.' . self::class, \App\Extensions\TitanReachAgent\System\Support\TitanReachProductionRelease::class);
        $this->app->singleton('titan-reach.titan-zero.closed-loop.' . self::class, \App\Extensions\TitanReachAgent\System\Support\TitanZeroClosedLoopBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-presence.php', 'titan-reach-local-presence.' . self::class);
        $this->app->singleton('titan-reach.local-presence.bridge.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\TitanReachLocalPresenceBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-paid-growth.php', 'titan-reach-paid-growth.' . self::class);
        $this->app->singleton('titan-reach.paid-growth.bridge.' . self::class, \App\Extensions\TitanReachAgent\System\Support\TitanReachPaidGrowthBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-reputation.php', 'titan-reach-reputation.' . self::class);
        $this->app->singleton('titan-reach.reputation.bridge.local_growth_agent', \App\Extensions\TitanReachAgent\System\Support\TitanReachReputationBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-distribution.php', 'titan-reach-distribution');
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-distribution.php', 'titan-reach-local-distribution.' . self::class);
        $this->app->singleton('titan-reach.distribution.bridge.titan_reach_agent', \App\Extensions\TitanReachAgent\System\Support\TitanReachDistributionBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-events.php', 'field-service-events.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-workspace.php', 'field-service-workspace.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-production.php', 'field-service-production.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime.php', 'field-service-runtime.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-smoke.php', 'field-service-runtime-smoke.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-lead-flow-simulation.php', 'field-service-lead-flow-simulation.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-publish-governance.php', 'field-service-publish-governance.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial.php', 'field-service-commercial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-demo-showcase.php', 'field-service-demo-showcase.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-certification.php', 'field-service-runtime-certification.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-installer-diagnostics.php', 'field-service-live-installer-diagnostics.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-repair.php', 'field-service-runtime-repair.' . self::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-webhook-dry-run.php', 'field-service-webhook-dry-run.' . self::class);

                $this->mergeConfigFrom(__DIR__ . '/../config/field-service-local-growth-operational-trial.php', 'field-service-local-growth-operational-trial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial-enforcement.php', 'field-service-commercial-enforcement.' . self::class);


        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-final-customer-release.php', 'field-service-final-customer-release.' . self::class);
        $this->app->singleton('field-service-final-customer-release.' . self::class, fn () => new \App\Extensions\TitanReachAgent\System\Support\FinalCustomerReleaseCandidate());
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-install-evidence.php', 'field-service-live-install-evidence.' . self::class);
        $this->app->singleton('field-service-live-install-evidence.' . self::class, fn () => new \App\Extensions\TitanReachAgent\System\Support\LiveInstallerEvidenceCapture());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-inbox.php', 'titan-reach-inbox.' . self::class);
        $this->app->singleton('titan-reach.inbox.bridge.' . self::class, \App\Extensions\TitanReachAgent\System\Support\TitanReachInboxBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-growth-intelligence.php', 'titan-reach-growth-intelligence.' . self::class);
        $this->app->singleton('titan-reach.growth-intelligence', \App\Extensions\TitanReachAgent\System\Support\RouteSeasonReviewGrowthIntelligence::class);
        $this->app->singleton('titan-reach.growth-intelligence.bridge.' . self::class, \App\Extensions\TitanReachAgent\System\Support\TitanReachGrowthIntelligenceBridge::class);
        return $this;
    }

    public function boot(Kernel $kernel): void
    {
        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->registerMigrations()
            ->registerPolicies()
            ->registerCommands()
            ->publishAssets();
        $this->app->booted(static function (): void { TitanReachMenuInstaller::healIfNeeded(); });
    }

    protected function registerCommands(): static
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                GenerateAgentPostsCommand::class,
                CheckPendingImagesCommand::class,
                CheckPendingVideosCommand::class,
                PostMetricsAnalyzerCommand::class,
                TrendFinderCommand::class,
                PostPerformanceAdvisorCommand::class,
                WeeklySocialTrendsCommand::class,
                SeedDemoDataCommand::class,
                UpdateAverageMetricsCommand::class,
                RegeneratePostImagesCommand::class,
            ]);

            // exec('php artisan titan-reach-agent:generate-posts 1');
            // Schedule tasks
            $this->app->booted(function () {
                $schedule = $this->app->make(Schedule::class);
                $schedule->command('titan-reach-agent:generate-posts')->everyTwoMinutes()->withoutOverlapping(5);
                $schedule->command('titan-reach-agent:check-pending-images')->everyFiveMinutes()->withoutOverlapping(10);
                $schedule->command('titan-reach-agent:check-pending-videos')->everyFiveMinutes()->withoutOverlapping(10);
                $schedule->command('titan-reach-agent:post-metrics-analyzer')->cron('10 1 */3 * *')->withoutOverlapping(120);
                $schedule->command('titan-reach-agent:post-performance-advisor')->cron('25 1 */3 * *')->withoutOverlapping(120);
                $schedule->command('titan-reach-agent:trend-finder')->cron('40 1 */3 * *')->withoutOverlapping(120);
                $schedule->command('titan-reach-agent:weekly-social-trends')->cron('0 2 */3 * *')->withoutOverlapping(180);
            });
        }

        return $this;
    }

    protected function registerPolicies(): static
    {
        Gate::policy(TitanReachAgent::class, TitanReachAgentPolicy::class);

        return $this;
    }

    public function publishAssets(): static
    {
        $this->publishes([
            __DIR__ . '/../resources/assets/images' => public_path('vendor/titan-reach-agent/images'),
            __DIR__ . '/../resources/assets/videos' => public_path('vendor/titan-reach-agent/videos'),
        ], 'extension');

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-migration-compatibility.php', 'field-service-migration-compatibility.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hub-workflow-trial.php', 'field-service-hub-workflow-trial.' . self::class);



        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hotfix-intake.php', 'field-service-hotfix-intake.' . self::class);
        $this->app->singleton('field-service-hotfix-intake.' . self::class, fn () => new \App\Extensions\TitanReachAgent\System\Support\DiagnosticsDrivenHotfixIntake());
        return $this;
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', $this->registerKey());

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], $this->registerKey());

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }

    private function registerRoutes(): static
    {

        $this->router()
            ->group([
                'middleware' => ['web', 'auth'],
            ], function (Router $router) {
                $router
                    ->name('dashboard.user.titan-reach.agent.')
                    ->prefix('dashboard/user/titan-reach/agent')
                    ->group(function (Router $router) {

                        LegacyCompatibilityRegistrar::registerUserChatRoutes($router);
                        // Main CRUD routes
                                                $router->get('field-service-workspace', FieldServiceWorkspaceController::class)->name('field-service-workspace');
                        Route::get('', [TitanReachAgentController::class, 'index'])->name('index');
                        Route::get('post-items', [TitanReachAgentController::class, 'postItems'])->name('post-items');
                        Route::get('create', [TitanReachAgentController::class, 'create'])->name('create');
                        Route::get('agents', [TitanReachAgentController::class, 'agents'])->name('agents');
                        Route::get('calendar', [TitanReachAgentController::class, 'calendar'])->name('calendar');
                        Route::get('posts', [TitanReachAgentController::class, 'posts'])->name('posts');
                        Route::get('analytics', [TitanReachAgentController::class, 'analytics'])->name('analytics');
                        Route::get('accounts', [TitanReachAgentController::class, 'accounts'])->name('accounts');
                        Route::post('', [TitanReachAgentController::class, 'store'])->name('store');
                        Route::get('{agent}/edit', [TitanReachAgentController::class, 'edit'])->name('edit');
                        Route::put('{agent}', [TitanReachAgentController::class, 'update'])->name('update');
                        Route::delete('{agent}', [TitanReachAgentController::class, 'destroy'])->name('destroy');

                        // Wizard AJAX endpoints
                        Route::post('scrape-website', [TitanReachAgentController::class, 'scrapeWebsite'])->name('scrape-website');
                        Route::post('generate-targets', [TitanReachAgentController::class, 'generateTargets'])->name('generate-targets');
                        Route::post('preview-post', [TitanReachAgentController::class, 'previewPost'])->name('preview-post');

                        // Post management
                        Route::post('{agent}/generate-posts', [TitanReachAgentController::class, 'generatePosts'])->name('generate-posts');
                        Route::post('posts/{post}/approve', [TitanReachAgentController::class, 'approvePost'])->name('posts.approve');
                        Route::post('{agent}/approve-bulk', [TitanReachAgentController::class, 'approveBulk'])->name('approve-bulk');
                        Route::delete('posts/{post}/reject', [TitanReachAgentController::class, 'rejectPost'])->name('posts.reject');
                        Route::post('posts/{post}/duplicate', [TitanReachAgentController::class, 'duplicatePost'])->name('posts.duplicate');

                        Route::get('video/status', [TitanReachAgentController::class, 'getVideoStatus'])->name('video.status');
                        Route::get('image/status', [TitanReachAgentController::class, 'getImageStatus'])->name('image.status');

                        // Analyses
                        Route::get('analyses', [TitanReachAgentAnalysisController::class, 'index'])->name('analyses.index');
                        Route::get('analyses/{analysis}', [TitanReachAgentAnalysisController::class, 'show'])->name('analyses.show');
                        Route::post('analyses/{analysis}/read', [TitanReachAgentAnalysisController::class, 'markAsRead'])->name('analyses.mark-read');
                        Route::delete('analyses/{analysis}', [TitanReachAgentAnalysisController::class, 'destroy'])->name('analyses.destroy');
                        Route::delete('analyses', [TitanReachAgentAnalysisController::class, 'clearAll'])->name('analyses.clear-all');

                        // API endpoints
                        Route::get('api/pending-count', [TitanReachAgentController::class, 'getPendingCount'])->name('api.pending-count');
                        Route::get('api/posts', [TitanReachAgentController::class, 'getPosts'])->name('api.posts');
                        Route::post('api/posts', [TitanReachAgentController::class, 'storePost'])->name('api.posts.store');
                        Route::post('api/upload-image', [TitanReachAgentController::class, 'uploadImage'])->name('api.upload-image');
                        Route::put('api/posts/{post}', [TitanReachAgentController::class, 'updatePost'])->name('api.posts.update');
                        Route::post('api/posts/generate-content', [TitanReachAgentController::class, 'generatePostContent'])->name('api.posts.generate-content');
                        Route::post('api/posts/{post}/regenerate', [TitanReachAgentPostController::class, 'regenerateContent'])->name('api.posts.regenerate');
                        Route::post('api/posts/generate-image', [TitanReachAgentController::class, 'generatePostImage'])->name('api.posts.generate-image');
                        Route::get('api/generation-status', [TitanReachAgentController::class, 'getGenerationStatus'])->name('api.generation-status');
                    });
            });

        $this->router()
            ->group([
                'middleware' => ['web', 'auth'],
            ], function (Router $router) {
                $router
                    ->prefix('dashboard/admin/titan-reach/agent/chat')
                    ->name('dashboard.admin.titan-reach.agent.chat.')
                    ->middleware('admin')
                    ->group(function (Router $router) {
                        $router->get('settings', [TitanReachAgentChatSettingsController::class, 'index'])->name('settings');
                        $router->post('settings', [TitanReachAgentChatSettingsController::class, 'update'])->name('settings.update');
                    });
            });

        // Fal.ai webhook (no auth required)
        $this->router()
            ->group([
                'middleware' => ['api'],
            ], function (Router $router) {
                Route::post('titan-reach-agent/fal-webhook', [TitanReachAgentController::class, 'falWebhook'])->name('dashboard.user.titan-reach.agent.fal-webhook');
            });

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    public static function uninstall(): void {}

    public function registerKey(): string
    {
        return 'titan-reach-agent';
    }
}
