<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility\Chatbot;

/** Fail-closed legacy catalogue when the historical Chatbot package is absent. */
final class UnavailableLegacyChatbotCatalogue implements ChatbotCatalogue
{
    public function all(): iterable
    {
        return [];
    }
}
