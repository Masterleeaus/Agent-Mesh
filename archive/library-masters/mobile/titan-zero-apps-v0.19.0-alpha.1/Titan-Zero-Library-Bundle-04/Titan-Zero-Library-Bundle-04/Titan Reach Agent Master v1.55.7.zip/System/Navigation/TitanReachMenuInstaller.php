<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class TitanReachMenuInstaller
{
    public static function healIfNeeded(): void
    {
        try { self::sync(); } catch (\Throwable) { /* navigation may never block boot */ }
    }

    public static function sync(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) return;
        $columns = array_flip(Schema::getColumnListing('menus'));
        $root = TitanReachMenuDefinition::root();
        $parent = DB::table('menus')->where('key', $root['key'])->first();
        if (! $parent && Schema::hasColumn('menus', 'label')) {
            $q = DB::table('menus')->where('label', $root['label']);
            if (Schema::hasColumn('menus', 'parent_id')) $q->whereNull('parent_id');
            $parent = $q->first();
            if ($parent && Schema::hasColumn('menus', 'key')) {
                DB::table('menus')->where('id', $parent->id)->update(['key' => $root['key']]);
                $parent = DB::table('menus')->where('id', $parent->id)->first();
            }
        }
        if (! $parent) {
            DB::table('menus')->insert(self::data($root, null, $columns, true));
            $parent = DB::table('menus')->where('key', $root['key'])->first();
        } else {
            $data=self::data($root, null, $columns, false);
            unset($data['key']);
            DB::table('menus')->where('id', $parent->id)->update($data);
        }
        if (! $parent) return;
        $item = TitanReachMenuDefinition::item();
        $existing = DB::table('menus')->where('key', $item['key'])->first();
        if (! $existing && Schema::hasColumn('menus','route')) {
            $existing = DB::table('menus')->where('route', $item['route'])->whereNotNull('parent_id')->first();
        }
        $data=self::data($item, $parent->id, $columns, $existing === null);
        if ($existing) { unset($data['key']); DB::table('menus')->where('id',$existing->id)->update($data); }
        else { DB::table('menus')->insert($data); }
        self::regenerate();
    }

    private static function data(array $item, mixed $parentId, array $columns, bool $includeKey): array
    {
        $data=[
            'key'=>$item['key'], 'parent_id'=>$parentId, 'route'=>$item['route'], 'route_slug'=>$item['route_slug'] ?? null,
            'label'=>$item['label'], 'icon'=>$item['icon'], 'svg'=>null, 'order'=>(int)$item['order'],
            'is_active'=>1, 'params'=>'[]', 'type'=>'item', 'badge'=>null, 'extension'=>'1',
            'bolt_menu'=>0, 'bolt_background'=>null, 'bolt_foreground'=>null, 'letter_icon'=>0,
            'letter_icon_bg'=>null, 'custom_menu'=>0, 'updated_at'=>now(), 'created_at'=>now(),
        ];
        if (! $includeKey) unset($data['key'],$data['created_at']);
        return array_intersect_key($data,$columns);
    }

    private static function regenerate(): void
    {
        if (! class_exists(\App\Services\Common\MenuService::class)) return;
        try { $s=app(\App\Services\Common\MenuService::class); if (method_exists($s,'regenerate')) $s->regenerate(); } catch (\Throwable) {}
    }
}
