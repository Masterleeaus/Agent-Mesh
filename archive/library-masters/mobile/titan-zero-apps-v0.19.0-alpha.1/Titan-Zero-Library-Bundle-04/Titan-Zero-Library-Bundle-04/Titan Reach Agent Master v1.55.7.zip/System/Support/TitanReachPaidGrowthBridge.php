<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

final class TitanReachPaidGrowthBridge
{
    public function review(array $payload): array
    {
        $payload['automatic_activation'] = false;
        $payload['automatic_budget_increase'] = false;
        if ((int)($payload['company_id'] ?? 0) <= 0) {
            return ['allowed' => false, 'state' => 'blocked', 'reasons' => ['company_id_required'], 'requirements' => []];
        }
        if (app()->bound('titan-reach.paid-growth')) {
            return app('titan-reach.paid-growth')->review($payload);
        }
        return ['allowed' => false, 'state' => 'pro_required', 'reasons' => ['paid_growth_authority_unavailable'], 'requirements' => ['titan_reach_pro']];
    }
}
