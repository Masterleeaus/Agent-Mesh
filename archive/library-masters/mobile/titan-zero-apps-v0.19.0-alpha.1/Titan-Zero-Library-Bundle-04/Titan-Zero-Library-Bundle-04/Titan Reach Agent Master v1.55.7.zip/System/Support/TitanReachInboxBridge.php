<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachAgent\System\Support;
final class TitanReachInboxBridge
{
    public function ingest(array $payload): array
    {
        if (($payload['company_id'] ?? null) === null) return ['accepted'=>false,'blocked_by'=>'missing_company_id','safe_fallback'=>true];
        if (app()->bound('titan-reach.inbox')) return app('titan-reach.inbox')->ingest($payload);
        return ['accepted'=>false,'blocked_by'=>'titan_reach_flow_not_installed','safe_fallback'=>true,'source'=>'local_growth_agent'];
    }
}
