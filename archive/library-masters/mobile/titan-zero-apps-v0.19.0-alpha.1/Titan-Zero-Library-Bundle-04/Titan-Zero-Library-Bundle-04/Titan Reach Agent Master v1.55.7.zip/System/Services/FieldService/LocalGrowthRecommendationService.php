<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\FieldService;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;

class LocalGrowthRecommendationService
{
    public function recommendationsFor(TitanReachAgent $agent): array
    {
        $profile = app(LocalGrowthAgentProfile::class)->fromAgent($agent);
        $recommendations = [];

        if (empty($profile['services'])) {
            $recommendations[] = ['priority' => 'high', 'type' => 'profile', 'message' => 'Add active services so generated posts can target real work you perform.'];
        }

        if (empty($profile['service_areas'])) {
            $recommendations[] = ['priority' => 'high', 'type' => 'local', 'message' => 'Add service areas/suburbs before publishing local availability posts.'];
        }

        if (empty($profile['quote_url']) && empty($profile['booking_url'])) {
            $recommendations[] = ['priority' => 'medium', 'type' => 'conversion', 'message' => 'Add a quote or booking link so posts can convert enquiries.'];
        }

        if (empty($profile['review_url'])) {
            $recommendations[] = ['priority' => 'medium', 'type' => 'trust', 'message' => 'Add a review link to support testimonial and review-request campaigns.'];
        }

        if (empty($profile['growth_goals'])) {
            $recommendations[] = ['priority' => 'medium', 'type' => 'strategy', 'message' => 'Choose at least one growth goal such as quotes, bookings, reviews, recurring maintenance or reactivation.'];
        }

        $intelligenceSignals = app(LocalGrowthIntelligenceService::class)->signalsFor($agent);

        foreach ($intelligenceSignals as $signal) {
            if (($signal['type'] ?? '') === 'ready') {
                continue;
            }

            $recommendations[] = [
                'priority' => $signal['priority'] ?? 'medium',
                'type' => 'intelligence:' . ($signal['type'] ?? 'signal'),
                'message' => $signal['message'] ?? 'Use the latest local growth signal when planning content.',
                'recommended_post_type' => $signal['recommended_post_type'] ?? null,
                'context' => $signal['context'] ?? [],
            ];
        }

        return $recommendations ?: [[
            'priority' => 'ready',
            'type' => 'strategy',
            'message' => 'Local Growth Agent has enough context and signal coverage to generate safe field-service marketing posts.',
        ]];
    }
}
