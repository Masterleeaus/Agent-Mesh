<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\FieldService;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Extensions\TitanReachAgent\System\Models\TitanReachAgentPost;
use App\Extensions\TitanReachAgent\System\Services\FieldService\Dto\LocalGrowthSignal;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

class LocalGrowthIntelligenceService
{
    /**
     * Build deterministic local-growth signals from configured company context,
     * recent agent activity and safe conversion summaries. This service never
     * infers unavailable services, suburbs, licences, emergency support, exact
     * addresses or customer identity.
     */
    public function signalsFor(TitanReachAgent $agent): array
    {
        $profile = app(LocalGrowthAgentProfile::class)->fromAgent($agent);
        $signals = [];

        $services = $this->list($profile['services'] ?? []);
        $areas = $this->list($profile['service_areas'] ?? []);
        $goals = $this->list($profile['growth_goals'] ?? []);
        $contentMix = $this->list($profile['content_mix'] ?? []);
        $strategy = is_array($agent->field_service_strategy ?? null) ? $agent->field_service_strategy : [];

        if (empty($services)) {
            $signals[] = LocalGrowthSignal::make('profile_gap', 'high', 'Add active services before the agent recommends service-specific campaigns.', null, [], 100);
        }

        if (empty($areas)) {
            $signals[] = LocalGrowthSignal::make('local_gap', 'high', 'Add service areas before using local availability or neighbourhood content.', null, [], 95);
        }

        if (! empty($services) && ! empty($areas)) {
            $signals[] = LocalGrowthSignal::make(
                'local_availability',
                $this->goalPriority($goals, ['bookings', 'quote_requests', 'emergency_leads']),
                'Create availability content pairing a real service with a configured service area.',
                'local_availability',
                ['services' => $this->sample($services), 'service_areas' => $this->sample($areas)],
                82
            );
        }

        if ($this->isSeasonalWindow()) {
            $signals[] = LocalGrowthSignal::make(
                'seasonal_demand',
                'medium',
                'Use seasonal maintenance reminders for configured services that naturally fit the current month.',
                'maintenance_reminder',
                ['month' => Carbon::now()->format('F'), 'services' => $this->sample($services)],
                72
            );
        }

        if (empty($profile['review_url'])) {
            $signals[] = LocalGrowthSignal::make('trust_gap', 'medium', 'Add a review URL before running review-request workflows.', null, [], 65);
        } else {
            $signals[] = LocalGrowthSignal::make('review_builder', 'medium', 'Use a review-builder post to increase trust and route satisfied customers to the configured review URL.', 'review_builder', ['review_url_available' => true], 68);
        }

        if (! empty($strategy['quiet_days']) || in_array('fill_schedule_gaps', $goals, true)) {
            $signals[] = LocalGrowthSignal::make('schedule_gap', 'high', 'Promote controlled schedule openings without inventing discounts or emergency urgency.', 'local_availability', ['quiet_days' => $this->list($strategy['quiet_days'] ?? [])], 88);
        }

        if (in_array('recurring_maintenance', $goals, true)) {
            $signals[] = LocalGrowthSignal::make('recurring_maintenance', 'medium', 'Create recurring maintenance reminders tied only to configured services.', 'maintenance_reminder', ['services' => $this->sample($services)], 70);
        }

        if (in_array('customer_reactivation', $goals, true) || in_array('reactivation', $contentMix, true)) {
            $signals[] = LocalGrowthSignal::make('reactivation', 'medium', 'Invite previous customers to book follow-up work without naming private customer records.', 'reactivation', [], 67);
        }

        $verticalPack = $profile['vertical_pack'] ?? app(FieldServiceVerticalPackCatalog::class)->safeDefault();
        if (! empty($verticalPack['seasonal_themes']) && ! empty($verticalPack['safe_content_lanes'])) {
            $signals[] = LocalGrowthSignal::make(
                'vertical_pack_signal',
                'medium',
                'Use the configured vertical pack for safe seasonal themes and content lanes without adding unsupported claims.',
                $verticalPack['safe_content_lanes'][0] ?? 'service_spotlight',
                ['vertical' => $verticalPack['label'] ?? 'Custom field/home service', 'themes' => array_slice($verticalPack['seasonal_themes'], 0, 3)],
                66
            );
        }

        $coverageSignal = $this->contentCoverageSignal($agent, $contentMix);
        if ($coverageSignal) {
            $signals[] = $coverageSignal;
        }

        if (empty($signals)) {
            $signals[] = LocalGrowthSignal::make('ready', 'ready', 'The Local Growth Agent has enough context to create safe field-service growth content.', 'completed_job', [], 50);
        }

        return collect($signals)
            ->map(fn (LocalGrowthSignal $signal) => $signal->toArray())
            ->sortByDesc(fn (array $signal) => (int) ($signal['score'] ?? 0))
            ->values()
            ->all();
    }

    public function promptBlock(TitanReachAgent $agent): string
    {
        $signals = array_slice($this->signalsFor($agent), 0, 5);

        if (empty($signals)) {
            return '';
        }

        $lines = ['Local Growth Intelligence Signals:'];

        foreach ($signals as $signal) {
            $postType = $signal['recommended_post_type'] ? ' Suggested post type: ' . $signal['recommended_post_type'] . '.' : '';
            $lines[] = '- [' . strtoupper((string) $signal['priority']) . '] ' . $signal['message'] . $postType;
        }

        $lines[] = 'Use these signals only when they match configured services and service areas. Do not invent missing business facts.';

        return implode("\n", $lines);
    }

    private function contentCoverageSignal(TitanReachAgent $agent, array $contentMix): ?LocalGrowthSignal
    {
        if (! $agent->exists || empty($contentMix)) {
            return null;
        }

        $recentTypes = TitanReachAgentPost::query()
            ->where('agent_id', $agent->id)
            ->where('created_at', '>=', now()->subDays(45))
            ->pluck('ai_metadata')
            ->map(function ($metadata) {
                if (is_string($metadata)) {
                    $decoded = json_decode($metadata, true);
                    return is_array($decoded) ? ($decoded['post_type'] ?? null) : null;
                }

                return is_array($metadata) ? ($metadata['post_type'] ?? null) : null;
            })
            ->filter()
            ->unique()
            ->values()
            ->all();

        $missing = collect($contentMix)
            ->filter(fn ($type) => is_string($type) && $type !== '')
            ->reject(fn ($type) => in_array($type, $recentTypes, true))
            ->values()
            ->all();

        if (empty($missing)) {
            return null;
        }

        return LocalGrowthSignal::make(
            'content_gap',
            'medium',
            'Rotate into an unused content lane from the configured content mix: ' . implode(', ', array_slice($missing, 0, 3)) . '.',
            $missing[0] ?? null,
            ['missing_post_types' => array_slice($missing, 0, 5)],
            64
        );
    }

    private function goalPriority(array $goals, array $matches): string
    {
        foreach ($matches as $match) {
            if (in_array($match, $goals, true)) {
                return 'high';
            }
        }

        return 'medium';
    }

    private function isSeasonalWindow(): bool
    {
        return in_array((int) Carbon::now()->format('n'), [2, 3, 4, 5, 8, 9, 10, 11], true);
    }

    private function list($value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return collect($value)
            ->map(function ($item) {
                if (is_string($item)) {
                    return trim($item);
                }

                if (is_array($item)) {
                    return trim((string) ($item['name'] ?? $item['label'] ?? $item['service'] ?? $item['area'] ?? $item['type'] ?? ''));
                }

                return '';
            })
            ->filter()
            ->map(fn ($item) => Str::of($item)->squish()->toString())
            ->unique()
            ->values()
            ->all();
    }

    private function sample(array $items, int $limit = 3): array
    {
        return array_values(array_slice($items, 0, $limit));
    }
}
