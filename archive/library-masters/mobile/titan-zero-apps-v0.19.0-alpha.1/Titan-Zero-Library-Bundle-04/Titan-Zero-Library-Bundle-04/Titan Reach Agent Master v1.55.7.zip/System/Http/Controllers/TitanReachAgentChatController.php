<?php

namespace App\Extensions\TitanReachAgent\System\Http\Controllers;

use App\Domains\Entity\Models\Entity;
use App\Extensions\TitanReachPro\System\Models\TitanReachAnalysis;
use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Helpers\Classes\Helper;
use App\Http\Controllers\Controller;
use App\Extensions\TitanReachAgent\System\Compatibility\Chatbot\ChatbotCatalogue;
use App\Extensions\TitanReachAgent\System\Compatibility\Ai\LegacyOpenAiChatRuntime;
use App\Models\OpenaiGeneratorChatCategory;
use App\Models\Setting;
use App\Models\SettingTwo;
use App\Models\UserOpenaiChat;
use App\Models\UserOpenaiChatMessage;
use App\Services\Bedrock\BedrockRuntimeService;
use App\Services\GatewaySelector;
use Exception;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use JsonException;
use Random\RandomException;

class TitanReachAgentChatController extends Controller
{
    protected $client;

    protected $settings;

    protected $settings_two;

    protected BedrockRuntimeService $bedrockService;

    public function __construct(
        BedrockRuntimeService $bedrockService,
        private readonly ChatbotCatalogue $chatbotCatalogue,
        private readonly LegacyOpenAiChatRuntime $legacyOpenAiRuntime,
    )
    {
        $this->bedrockService = $bedrockService;
        $this->settings = Setting::getCache();
        $this->settings_two = SettingTwo::getCache();
        $this->legacyOpenAiRuntime->configureServerKey();
    }

    /**
     * @throws RandomException
     * @throws JsonException
     * @throws GuzzleException
     */
    public function index($id = null)
    {
        $gateway = $this->resolveSubscriptionGateway();
        $isPaid = $this->hasActivePaidSubscription($gateway);
        $category = $this->firstOpenaiGeneratorChatCategory();

        $defaultScreen = setting('ai_chat_pro_default_screen', 'new');
        $query = $this->openai(request())
            ->where('openai_chat_category_id', $category?->id)
            ->where('is_chatbot', 0);
        [$list, $chat] = $this->buildChatListAndActive($query, $category, $defaultScreen);

        [$apikeyPart1, $apikeyPart2, $apikeyPart3] = $this->prepareApiKeyParts();
        [$apiSearch, $apiSearchId] = $this->prepareSearchConfig();
        [$lastThreeMessage, $chat_completions, $category] = $this->prepareChatContext($chat, $category);

        $aiList = OpenaiGeneratorChatCategory::where('slug', '<>', 'ai_vision')->where('slug', '<>', 'ai_pdf')->get();
        $chatbots = $this->chatbotCatalogue->all();
        $models = Entity::planModels();
        $apiUrl = base64_encode((string) config('titan-reach-agent.ai.chat_completions_url', ''));
        $tempChat = false;
        $generators = $this->availableGenerators();
        $agents = TitanReachAgent::query()->where('user_id', Auth::id())->get();
        $defaultAgent = null;
        if ($id) {
            $defaultAgent = $agents->firstWhere('id', (int) $id);
        }
        if (! $defaultAgent) {
            $defaultAgent = $agents->first();
        }

        if (! $defaultAgent) {
            return redirect()->route('dashboard.user.titan-reach.agent.create')
                ->with([
                    'message' => __('Please create a Titan Reach Agent first.'),
                    'type'    => 'info',
                ]);
        }

        $platforms = TitanReachPlatform::query()
            ->where('user_id', Auth::id())
            ->get();

        $analysis = TitanReachAnalysis::query()->where('id', request('analysis'))->where('user_id', Auth::id())->first();

        if (request('analysis') && $analysis) {

            $analysis->update(['read_at' => now()]);
            $chat = $this->openai(request())
                ->where('titan_reach_analysis_id', $analysis->id)
                ->first();

            if (! $chat) {
                $chat = $this->startNewChat($category, $analysis, false);

                $message = new UserOpenaiChatMessage;
                $message->user_openai_chat_id = $chat->id;
                $message->user_id = Auth::id();
                $message->output = 'Analysis Report Reset';
                $message->response = null;
                $message->credits = 0;
                $message->words = 0;
                $message->save();

                $this->createInitialChatMessage($chat, $category, $analysis);
            }

            $list->prepend($chat);

        }

        return view('titan-reach-agent::chat.index', compact(
            'generators',
            'category',
            'apiSearch',
            'chatbots',
            'apiSearchId',
            'list',
            'chat',
            'aiList',
            'apikeyPart1',
            'apikeyPart2',
            'apikeyPart3',
            'tempChat',
            'apiUrl',
            'lastThreeMessage',
            'chat_completions',
            'models',
            'agents',
            'defaultAgent',
            'platforms'
        ));
    }

    protected function openai(Request $request): Builder
    {
        $team = $request->user()?->getAttribute('team');
        $myCreatedTeam = $request->user()?->getAttribute('myCreatedTeam');

        return UserOpenaiChat::query()
            ->where('chat_type', 'titan-reach-agent')
            ->where(function (Builder $query) use ($team, $myCreatedTeam) {
                $query->where('user_id', auth()?->id())
                    ->when($team || $myCreatedTeam, function ($query) use ($team, $myCreatedTeam) {
                        if ($team && $team?->is_shared) {
                            $query->orWhere('team_id', $team->id);
                        }
                        if ($myCreatedTeam) {
                            $query->orWhere('team_id', $myCreatedTeam->id);
                        }
                    });
            });
    }

    private function firstOpenaiGeneratorChatCategory()
    {
        $userGenerator = OpenaiGeneratorChatCategory::query()
            ->whereNotIn('slug', ['ai_vision', 'ai_webchat', 'ai_pdf'])
            ->where('role', 'default')
            ->when(Auth::user()?->isUser(), function ($query) {
                $query->where(function ($query) {
                    $query->whereNull('user_id')
                        ->orWhere('user_id', Auth::id());
                });
            })
            ->first();

        if ($userGenerator) {
            return $userGenerator;
        }

        return OpenaiGeneratorChatCategory::query()
            ->whereNotIn('slug', ['ai_vision', 'ai_webchat', 'ai_pdf'])
            ->where('role', 'default')
            ->firstOr(function () {
                return OpenaiGeneratorChatCategory::query()
                    ->whereNotIn('slug', ['ai_vision', 'ai_webchat', 'ai_pdf'])
                    ->first();
            });
    }

    private function startNewChat($category, $analysis = null, bool $createInitialMessage = true)
    {
        Helper::clearEmptyConversations();

        $chat = new UserOpenaiChat;
        $chat->user_id = Auth::id();
        $chat->openai_chat_category_id = $category?->id;

        $chat->chat_type = 'titan-reach-agent';

        if ($analysis) {
            $chat->titan_reach_analysis_id = $analysis->id;
        }
        $chat->title = $analysis ? Str::limit($analysis->summary, 30) : $category->name . ' Chat';
        $chat->total_credits = 0;
        $chat->total_words = 0;
        $chat->save();
        $chat->refresh();

        if ($createInitialMessage) {
            $this->createInitialChatMessage($chat, $category, $analysis);
        }

        return $chat;
    }

    private function createInitialChatMessage(UserOpenaiChat $chat, $category, $analysis = null, ?string $prefix = null): void
    {
        $message = new UserOpenaiChatMessage;
        $message->user_openai_chat_id = $chat->id;
        $message->user_id = Auth::id();
        $message->response = 'First Initiation';
        if ($category->role == 'default') {
            $output = $analysis ? $analysis->report_text : __('Hi! I am') . ' ' . $category->name . __(', and I\'m here to answer all your questions');
        } else {
            $output = $analysis ? $analysis->report_text : __('Hi! I am') . ' ' . $category->human_name . __(', and I\'m') . ' ' . $category->role . '. ' . $category->helps_with;
        }

        if ($prefix !== null) {
            $output = trim($prefix . ' ' . $output);
        }

        $message->output = $output;
        $message->hash = Str::random(256);
        $message->credits = 0;
        $message->words = 0;
        $message->save();
    }

    private function resolveSubscriptionGateway(): ?string
    {
        $activeSubscription = getCurrentActiveSubscription();
        if ($activeSubscription !== null) {
            return $activeSubscription->paid_with;
        }

        $activeYokkasaSubscription = getCurrentActiveSubscriptionYokkasa();

        return $activeYokkasaSubscription?->paid_with;
    }

    private function hasActivePaidSubscription(?string $gateway): bool
    {
        if (! $gateway) {
            return false;
        }

        try {
            return GatewaySelector::selectGateway($gateway)::getSubscriptionStatus();
        } catch (Exception $e) {
            return false;
        }
    }

    private function buildChatListAndActive(Builder $query, $category, string $defaultScreen): array
    {
        switch ($defaultScreen) {
            case 'pinned':
                $list = $query->orderBy('is_pinned', 'desc')
                    ->orderBy('updated_at', 'desc')
                    ->get();
                $chat = $list->first(fn ($c) => $c->is_pinned) ?? $list->first();

                break;

            case 'new':
                $chat = $this->startNewChat($category);
                $list = $query->orderBy('is_pinned', 'desc')
                    ->orderBy('updated_at', 'desc')
                    ->get();

                break;

            case 'last':
            default:
                $list = $query->orderBy('updated_at', 'desc')->get();
                $chat = $list->first();

                break;
        }

        return [$list, $chat];
    }

    private function prepareApiKeyParts(): array
    {
        $frontendStreamingRequested = $this->settings_two->openai_default_stream_server === 'frontend'
            || (bool) setting('realtime_voice_chat', 0);

        return $this->legacyOpenAiRuntime->frontendKeyParts($frontendStreamingRequested);
    }

    private function prepareSearchConfig(): array
    {
        return [
            base64_encode('https://google.serper.dev/search'),
            base64_encode($this->settings_two->serper_api_key),
        ];
    }

    private function prepareChatContext($chat, $category): array
    {
        $lastThreeMessage = null;
        $chatCompletions = null;

        if ($chat !== null) {
            $lastThreeMessageQuery = $chat->messages()
                ->whereNot('input', null)
                ->orderBy('created_at', 'desc')
                ->take(2);
            $lastThreeMessage = $lastThreeMessageQuery->get()->reverse();
            $category = OpenaiGeneratorChatCategory::where('id', $chat->openai_chat_category_id)->first();
            $chatCompletions = str_replace(["\r", "\n"], '', $category->chat_completions);

            if ($chatCompletions) {
                $chatCompletions = json_decode($chatCompletions, true, 512, JSON_THROW_ON_ERROR);
            }
        }

        return [$lastThreeMessage, $chatCompletions, $category];
    }

    private function availableGenerators()
    {
        return OpenaiGeneratorChatCategory::query()
            ->whereNotIn('slug', ['ai_vision', 'ai_webchat', 'ai_pdf'])
            ->when(Auth::user()?->isUser(), function ($query) {
                $query->where(function ($query) {
                    $query->whereNull('user_id')->orWhere('user_id', Auth::id());
                });
            })
            ->get();
    }
}
