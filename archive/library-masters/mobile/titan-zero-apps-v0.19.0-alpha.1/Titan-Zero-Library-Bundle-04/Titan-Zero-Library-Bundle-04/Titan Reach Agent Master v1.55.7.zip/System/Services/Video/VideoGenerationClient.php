<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\Video;

interface VideoGenerationClient
{
    public function generate(string $prompt, array $options = []): array;

    public function status(string $requestId): array;
}
