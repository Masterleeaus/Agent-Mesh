<?php

namespace App\Extensions\TitanReachAgent\System\Services\Ai\Dto;

class ChatCompletionResult
{
    public function __construct(
        public readonly bool $success,
        public readonly ?string $content = null,
        public readonly ?string $error = null,
        public readonly ?string $provider = null,
        public readonly ?int $status = null,
        public readonly array $metadata = [],
    ) {}

    public static function success(string $content, string $provider, array $metadata = []): self
    {
        return new self(true, $content, null, $provider, null, $metadata);
    }

    public static function failure(string $error, ?string $provider = null, ?int $status = null, array $metadata = []): self
    {
        return new self(false, null, $error, $provider, $status, $metadata);
    }
}
