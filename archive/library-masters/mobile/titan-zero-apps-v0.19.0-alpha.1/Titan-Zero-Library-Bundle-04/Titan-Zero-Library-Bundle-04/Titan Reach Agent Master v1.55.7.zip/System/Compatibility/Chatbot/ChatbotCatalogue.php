<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility\Chatbot;

/**
 * Compatibility-only boundary for the legacy Chatbot selector used by the historical
 * Reach chat surface. New Reach runtime must not use this contract as a canonical
 * application identity or capability boundary.
 */
interface ChatbotCatalogue
{
    /** @return iterable<int, mixed> */
    public function all(): iterable;
}
