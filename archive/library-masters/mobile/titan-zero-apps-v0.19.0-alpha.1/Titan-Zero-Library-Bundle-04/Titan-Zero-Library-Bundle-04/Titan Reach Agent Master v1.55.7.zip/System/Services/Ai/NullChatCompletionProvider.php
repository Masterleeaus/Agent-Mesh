<?php

namespace App\Extensions\TitanReachAgent\System\Services\Ai;

use App\Extensions\TitanReachAgent\System\Services\Ai\Contracts\ChatCompletionProvider;
use App\Extensions\TitanReachAgent\System\Services\Ai\Dto\ChatCompletionResult;

class NullChatCompletionProvider implements ChatCompletionProvider
{
    public function name(): string
    {
        return 'none';
    }

    public function configured(): bool
    {
        return false;
    }

    public function complete(array $messages, array $options = []): ChatCompletionResult
    {
        return ChatCompletionResult::failure('No AI provider is configured.', $this->name());
    }
}
