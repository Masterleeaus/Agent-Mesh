<?php

namespace App\Extensions\TitanReachAgent\System\Services;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Facades\Log;
use Symfony\Component\DomCrawler\Crawler;

class WebScrapingService
{
    protected Client $client;

    protected int $maxPages = 3;

    protected int $timeout = 8;

    protected int $maxBodyBytes = 524288;

    public function __construct()
    {
        $this->client = new Client([
            'timeout'         => $this->timeout,
            'connect_timeout' => 5,
            'allow_redirects' => [
                'max'             => 3,
                'strict'          => true,
                'referer'         => false,
                'track_redirects' => true,
                'on_redirect'     => function ($request, $response, $uri): void {
                    $this->assertSafeUrl((string) $uri);
                },
            ],
            'verify'          => true,
            'http_errors'     => false,
            'headers'         => [
                'User-Agent' => 'Titan-TitanReachAgent-SafeScraper/1.0',
                'Accept'     => 'text/html,application/xhtml+xml',
            ],
        ]);
    }

    public function scrapeWebsite(string $url): array
    {
        try {
            $url = $this->normalizeAndValidateUrl($url);
            $baseUrl = $this->getBaseUrl($url);
            $scrapedPages = [];

            $mainPageContent = $this->scrapePage($url);
            if ($mainPageContent) {
                $scrapedPages[] = $mainPageContent;
                $internalLinks = $this->extractInternalLinks($url, $mainPageContent['html'], $baseUrl);
                foreach (array_slice($internalLinks, 0, $this->maxPages - 1) as $link) {
                    $safeLink = $this->normalizeAndValidateUrl($link);
                    $pageContent = $this->scrapePage($safeLink);
                    if ($pageContent) {
                        $scrapedPages[] = $pageContent;
                    }
                }
            }

            return [
                'success'      => true,
                'base_url'     => $baseUrl,
                'pages_count'  => count($scrapedPages),
                'pages'        => $scrapedPages,
                'summary'      => $this->generateSummary($scrapedPages),
            ];
        } catch (Exception $e) {
            Log::warning('WebScrapingService blocked or failed request', ['error' => $e->getMessage()]);
            return ['success' => false, 'error' => $e->getMessage(), 'pages' => []];
        }
    }

    protected function scrapePage(string $url): ?array
    {
        try {
            $url = $this->normalizeAndValidateUrl($url);
            $response = $this->client->get($url, [
                'stream' => true,
                'on_headers' => function ($response) use ($url): void {
                    $location = $response->getHeaderLine('Location');
                    if ($location !== '') {
                        $this->assertSafeUrl($this->makeAbsoluteUrl($location, $url));
                    }
                    $contentLength = (int) $response->getHeaderLine('Content-Length');
                    if ($contentLength > $this->maxBodyBytes) {
                        throw new Exception('Response body too large');
                    }
                },
            ]);

            $effectiveUrl = $response->getHeaderLine('X-Guzzle-Effective-Url') ?: $url;
            $this->assertSafeUrl($effectiveUrl);

            $body = $response->getBody();
            $html = '';
            while (! $body->eof() && strlen($html) <= $this->maxBodyBytes) {
                $html .= $body->read(8192);
            }
            if (strlen($html) > $this->maxBodyBytes) {
                throw new Exception('Response body too large');
            }

            $crawler = new Crawler($html);
            $title = $crawler->filter('title')->count() > 0 ? $crawler->filter('title')->text() : '';
            $metaDescription = $crawler->filter('meta[name="description"]')->count() > 0 ? $crawler->filter('meta[name="description"]')->attr('content') : '';

            return [
                'url'              => $url,
                'title'            => trim($title),
                'meta_description' => trim((string) $metaDescription),
                'headings'         => $this->extractHeadings($crawler),
                'content'          => $this->extractMainContent($crawler),
                'html'             => $html,
            ];
        } catch (GuzzleException|Exception $e) {
            Log::warning('Failed to scrape page', ['url' => $this->redactUrl($url), 'error' => $e->getMessage()]);
            return null;
        }
    }

    protected function extractMainContent(Crawler $crawler): string
    {
        foreach (['main', 'article', '[role="main"]', '.content', '#content', '.main-content', '#main-content', 'body'] as $selector) {
            try {
                if ($crawler->filter($selector)->count() > 0) {
                    $content = trim((string) preg_replace('/\s+/', ' ', $crawler->filter($selector)->first()->text()));
                    if (strlen($content) > 100) {
                        return substr($content, 0, 5000);
                    }
                }
            } catch (Exception) {
                continue;
            }
        }
        return '';
    }

    protected function extractHeadings(Crawler $crawler): array
    {
        $headings = [];
        foreach (['h1', 'h2', 'h3'] as $tag) {
            $crawler->filter($tag)->each(function (Crawler $node) use (&$headings, $tag): void {
                $text = trim($node->text());
                if ($text !== '') {
                    $headings[] = ['tag' => $tag, 'text' => substr($text, 0, 200)];
                }
            });
        }
        return array_slice($headings, 0, 20);
    }

    protected function extractInternalLinks(string $url, string $html, string $baseUrl): array
    {
        $crawler = new Crawler($html, $url);
        $links = [];
        $crawler->filter('a[href]')->each(function (Crawler $node) use (&$links, $baseUrl): void {
            $href = trim((string) $node->attr('href'));
            if ($href === '' || str_starts_with($href, '#') || str_starts_with($href, 'mailto:') || str_starts_with($href, 'tel:')) {
                return;
            }
            $absoluteUrl = $this->makeAbsoluteUrl($href, $baseUrl);
            if ($this->isInternalLink($absoluteUrl, $baseUrl)) {
                try {
                    $links[] = $this->normalizeAndValidateUrl($absoluteUrl);
                } catch (Exception) {
                    return;
                }
            }
        });
        return array_values(array_unique($links));
    }

    protected function makeAbsoluteUrl(string $url, string $baseUrl): string
    {
        if (parse_url($url, PHP_URL_SCHEME) !== null) {
            return $url;
        }
        $base = parse_url($baseUrl);
        $baseScheme = $base['scheme'] ?? 'https';
        $baseHost = $base['host'] ?? '';
        $basePath = $base['path'] ?? '/';
        if (str_starts_with($url, '//')) {
            return $baseScheme . ':' . $url;
        }
        if (str_starts_with($url, '/')) {
            return "{$baseScheme}://{$baseHost}{$url}";
        }
        $basePath = substr($basePath, 0, (int) strrpos($basePath, '/') + 1);
        return "{$baseScheme}://{$baseHost}{$basePath}{$url}";
    }

    protected function isInternalLink(string $url, string $baseUrl): bool
    {
        return parse_url($url, PHP_URL_HOST) === parse_url($baseUrl, PHP_URL_HOST);
    }

    protected function getBaseUrl(string $url): string
    {
        $parsed = parse_url($this->normalizeAndValidateUrl($url));
        return ($parsed['scheme'] ?? 'https') . '://' . ($parsed['host'] ?? '');
    }

    protected function normalizeAndValidateUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            throw new Exception('URL is required');
        }
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        $this->assertSafeUrl($url);
        return $url;
    }

    protected function assertSafeUrl(string $url): void
    {
        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = (string) ($parts['host'] ?? '');
        if (! in_array($scheme, ['http', 'https'], true) || $host === '') {
            throw new Exception('Only HTTP(S) URLs are allowed');
        }
        if ($this->isUnsafeHostLiteral($host)) {
            throw new Exception('Private, loopback, link-local, reserved and metadata hosts are blocked');
        }
        $records = @dns_get_record($host, DNS_A + DNS_AAAA);
        if ($records === false || $records === []) {
            throw new Exception('Unable to resolve host');
        }
        foreach ($records as $record) {
            $ip = $record['ip'] ?? $record['ipv6'] ?? null;
            if ($ip === null || ! $this->isPublicIp($ip)) {
                throw new Exception('Resolved host is not public');
            }
        }
    }

    protected function isUnsafeHostLiteral(string $host): bool
    {
        $trimmed = trim($host, '[]');
        if (strtolower($trimmed) === 'localhost' || str_ends_with(strtolower($trimmed), '.localhost') || strtolower($trimmed) === 'metadata.google.internal') {
            return true;
        }
        if (filter_var($trimmed, FILTER_VALIDATE_IP)) {
            return ! $this->isPublicIp($trimmed);
        }
        return false;
    }

    protected function isPublicIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false
            && ! in_array($ip, ['169.254.169.254'], true);
    }

    protected function redactUrl(string $url): string
    {
        $parts = parse_url($url);
        return ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '[invalid]') . ($parts['path'] ?? '');
    }

    protected function generateSummary(array $pages): string
    {
        $allContent = [];
        foreach ($pages as $page) {
            if (! empty($page['meta_description'])) {
                $allContent[] = $page['meta_description'];
            }
            if (! empty($page['title'])) {
                $allContent[] = $page['title'];
            }
        }
        return implode(' | ', array_slice($allContent, 0, 5));
    }

    public function setMaxPages(int $maxPages): self
    {
        $this->maxPages = max(1, min(5, $maxPages));
        return $this;
    }

    public function setTimeout(int $timeout): self
    {
        $this->timeout = max(2, min(10, $timeout));
        $this->client = new Client(['timeout' => $this->timeout, 'connect_timeout' => 5, 'allow_redirects' => false, 'verify' => true]);
        return $this;
    }
}
