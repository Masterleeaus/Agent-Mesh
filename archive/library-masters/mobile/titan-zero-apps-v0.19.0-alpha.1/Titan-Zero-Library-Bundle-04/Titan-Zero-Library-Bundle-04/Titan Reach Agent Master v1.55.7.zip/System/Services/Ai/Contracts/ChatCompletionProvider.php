<?php

namespace App\Extensions\TitanReachAgent\System\Services\Ai\Contracts;

use App\Extensions\TitanReachAgent\System\Services\Ai\Dto\ChatCompletionResult;

interface ChatCompletionProvider
{
    /**
     * @param array<int, array{role:string, content:string}> $messages
     * @param array<string, mixed> $options
     */
    public function complete(array $messages, array $options = []): ChatCompletionResult;

    public function configured(): bool;

    public function name(): string;
}
