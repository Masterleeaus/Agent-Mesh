<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\FieldService\Dto;

final class LocalGrowthSignal
{
    public function __construct(
        public readonly string $type,
        public readonly string $priority,
        public readonly string $message,
        public readonly ?string $recommendedPostType = null,
        public readonly array $context = [],
        public readonly int $score = 0,
    ) {}

    public static function make(
        string $type,
        string $priority,
        string $message,
        ?string $recommendedPostType = null,
        array $context = [],
        int $score = 0,
    ): self {
        return new self($type, $priority, $message, $recommendedPostType, $context, $score);
    }

    public function toArray(): array
    {
        return [
            'type' => $this->type,
            'priority' => $this->priority,
            'message' => $this->message,
            'recommended_post_type' => $this->recommendedPostType,
            'context' => $this->context,
            'score' => $this->score,
        ];
    }
}
