<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

final class RouteSeasonReviewGrowthIntelligence
{
    /**
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    public function recommend(array $context): array
    {
        $companyId = (string) ($context['company_id'] ?? '');
        if ($companyId === '') {
            return ['status' => 'blocked', 'reason' => 'company_id_required', 'recommendations' => []];
        }

        $serviceAreas = array_values(array_filter((array) ($context['service_areas'] ?? []), 'is_string'));
        $services = array_values(array_filter((array) ($context['services'] ?? []), 'is_string'));
        $jobs = (array) ($context['jobs'] ?? []);
        $openSlots = max(0, (int) ($context['open_slots'] ?? 0));
        $completedJobs = max(0, (int) ($context['completed_jobs'] ?? 0));
        $reviewUrl = trim((string) ($context['review_url'] ?? ''));
        $month = max(1, min(12, (int) ($context['month'] ?? (int) date('n'))));
        $presenceScore = max(0, min(100, (int) ($context['presence_health_score'] ?? 100)));

        $signals = [];
        $areaCounts = [];
        foreach ($jobs as $job) {
            if (!is_array($job)) continue;
            $area = trim((string) ($job['service_area'] ?? ''));
            if ($area === '' || !in_array($area, $serviceAreas, true)) continue;
            $areaCounts[$area] = ($areaCounts[$area] ?? 0) + 1;
        }
        arsort($areaCounts);
        $topArea = array_key_first($areaCounts);
        if ($topArea !== null && ($areaCounts[$topArea] ?? 0) >= 2) {
            $signals[] = $this->signal('route_density', 92, 'Fill route density in ' . $topArea, [
                'service_area' => $topArea,
                'job_count' => $areaCounts[$topArea],
                'cta' => 'Promote available nearby service capacity',
            ]);
        }

        if ($openSlots > 0 && $serviceAreas !== []) {
            $signals[] = $this->signal('schedule_gap', min(90, 55 + ($openSlots * 7)), 'Fill upcoming schedule capacity', [
                'open_slots' => $openSlots,
                'service_areas' => array_slice($serviceAreas, 0, 3),
                'cta' => 'Create local availability campaign',
            ]);
        }

        $seasonal = $this->seasonalMatches($month, $services);
        if ($seasonal !== []) {
            $signals[] = $this->signal('seasonal_service', 70, 'Promote configured seasonal services', [
                'month' => $month,
                'services' => $seasonal,
                'cta' => 'Create maintenance reminder campaign',
            ]);
        }

        if ($completedJobs > 0 && $reviewUrl !== '') {
            $signals[] = $this->signal('review_flywheel', min(95, 60 + min($completedJobs, 7) * 5), 'Activate completed-job review flywheel', [
                'completed_jobs' => $completedJobs,
                'cta' => 'Request review only from eligible completed jobs',
                'review_url_configured' => true,
            ]);
        }

        if ($presenceScore < 80) {
            $signals[] = $this->signal('presence_gap', 100 - $presenceScore, 'Improve local presence before increasing spend', [
                'presence_health_score' => $presenceScore,
                'cta' => 'Resolve local SEO/citation gaps',
            ]);
        }

        usort($signals, static fn (array $a, array $b): int => $b['score'] <=> $a['score']);

        return [
            'status' => 'ready',
            'company_id' => $companyId,
            'recommendations' => $signals,
            'next_best_action' => $signals[0] ?? null,
            'governance' => [
                'auto_publish' => false,
                'auto_message_customers' => false,
                'configured_services_only' => true,
                'configured_service_areas_only' => true,
            ],
        ];
    }

    /** @return array<string,mixed> */
    private function signal(string $type, int $score, string $title, array $evidence): array
    {
        return ['type' => $type, 'score' => max(0, min(100, $score)), 'title' => $title, 'evidence' => $evidence];
    }

    /** @param list<string> $services @return list<string> */
    private function seasonalMatches(int $month, array $services): array
    {
        $patterns = [
            1 => ['air conditioning', 'pool', 'pest', 'gardening', 'lawn'],
            2 => ['air conditioning', 'pool', 'pest'],
            3 => ['gutter', 'roof', 'heating', 'pest'],
            4 => ['gutter', 'heating', 'roof'],
            5 => ['heating', 'gutter', 'roof'],
            6 => ['heating', 'electrical', 'plumbing'],
            7 => ['heating', 'electrical', 'plumbing'],
            8 => ['heating', 'garden', 'pest'],
            9 => ['garden', 'lawn', 'pest', 'air conditioning'],
            10 => ['garden', 'lawn', 'air conditioning', 'pool'],
            11 => ['air conditioning', 'pool', 'pest', 'garden'],
            12 => ['air conditioning', 'pool', 'cleaning'],
        ];
        $needles = $patterns[$month] ?? [];
        return array_values(array_filter($services, static function (string $service) use ($needles): bool {
            $hay = strtolower($service);
            foreach ($needles as $needle) if (str_contains($hay, $needle)) return true;
            return false;
        }));
    }
}
