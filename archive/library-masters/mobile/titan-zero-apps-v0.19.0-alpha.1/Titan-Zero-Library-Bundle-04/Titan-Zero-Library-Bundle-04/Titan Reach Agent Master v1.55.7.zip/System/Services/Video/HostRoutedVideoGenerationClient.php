<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Services\Video;

use Illuminate\Contracts\Container\Container;
use RuntimeException;

final class HostRoutedVideoGenerationClient implements VideoGenerationClient
{
    public const HOST_BINDING = 'titan.ai.video-provider';
    public const LEGACY_FALLBACK_BINDING = 'titan-reach-agent.video.legacy-fallback';

    public function __construct(private readonly Container $container) {}

    public function generate(string $prompt, array $options = []): array
    {
        return $this->invoke('generate', [$prompt, $options]);
    }

    public function status(string $requestId): array
    {
        return $this->invoke('status', [$requestId]);
    }

    private function invoke(string $method, array $arguments): array
    {
        foreach ([self::HOST_BINDING, self::LEGACY_FALLBACK_BINDING] as $binding) {
            if (! $this->container->bound($binding)) {
                continue;
            }

            $provider = $this->container->make($binding);
            if (is_object($provider) && method_exists($provider, $method)) {
                $result = $provider->{$method}(...$arguments);
                if (is_array($result)) {
                    return $result;
                }
            }
        }

        throw new RuntimeException('No governed video-generation provider is available.');
    }
}
