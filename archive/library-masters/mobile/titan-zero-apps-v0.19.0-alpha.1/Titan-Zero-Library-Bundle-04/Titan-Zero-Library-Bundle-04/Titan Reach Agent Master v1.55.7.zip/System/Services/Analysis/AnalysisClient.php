<?php

namespace App\Extensions\TitanReachAgent\System\Services\Analysis;

use App\Extensions\TitanReachAgent\System\Services\Ai\AiProviderManager;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Backend-neutral analysis client.
 *
 * Model/backend selection is delegated to the host-aware AiProviderManager. The legacy
 * OpenAI-specific client remains as a compatibility adapter for existing callers only.
 */
class AnalysisClient
{
    public function generateReport(
        array $messages,
        float $temperature = 0.4,
        int $maxTokens = 900
    ): array {
        try {
            $options = [
                'temperature' => $temperature,
                'max_tokens'  => $maxTokens,
                'timeout'     => 60,
            ];

            $model = trim((string) config('titan-reach-agent.ai.analysis_model', ''));
            if ($model !== '') {
                $options['model'] = $model;
            }

            $result = app(AiProviderManager::class)->complete($messages, $options);

            if (! $result->success || trim((string) $result->content) === '') {
                Log::warning('AI analysis request failed', [
                    'provider' => $result->provider,
                    'error'    => $result->error,
                    'status'   => $result->status,
                ]);

                return [
                    'success' => false,
                    'error'   => $result->error ?: 'AI provider returned an empty response.',
                ];
            }

            return [
                'success' => true,
                'content' => trim((string) $result->content),
            ];
        } catch (Throwable $exception) {
            Log::error('AI analysis request crashed', [
                'message' => $exception->getMessage(),
            ]);

            return [
                'success' => false,
                'error'   => $exception->getMessage(),
            ];
        }
    }
}
