<?php

namespace App\Extensions\TitanReachAgent\System\Services\Analysis;

use App\Actions\Notify;
use App\Extensions\TitanReachPro\System\Models\TitanReachAnalysis;
use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Extensions\TitanReachAgent\System\Services\Ai\AiProviderManager;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class AnalysisRecorder
{
    public function recordForAgent(string $type, TitanReachAgent $agent, string $reportText): TitanReachAnalysis
    {

        $analysis = TitanReachAnalysis::create([
            'user_id'    => $agent->user_id,
            'type'       => $type,
            'agent_id'   => $agent->id,
            'summary'    => $this->generateSummary($type, $reportText),
            'report_text'=> $reportText,
            'created_at' => now(),
            'read_at'    => null,
        ]);

        $this->notifyUser($analysis, $agent);

        return $analysis;
    }

    public function generateSummary(string $type, string $reportText): string
    {
        $cleanReport = trim(preg_replace('!\s+!', ' ', strip_tags($reportText)));

        if ($cleanReport === '') {
            return '';
        }

        $prompt = <<<PROMPT
Summarize the following {$type} analysis into two short, action-focused sentences (max 7 total words). Write in English, no bullet points, no titles.

Report:
{$cleanReport}
PROMPT;

        try {
            $options = [
                'temperature' => 0.3,
                'max_tokens'  => 20,
                'timeout'     => 20,
            ];

            $model = trim((string) config('titan-reach-agent.ai.summary_model', ''));
            if ($model !== '') {
                $options['model'] = $model;
            }

            $result = app(AiProviderManager::class)->complete([
                [
                    'role'    => 'system',
                    'content' => 'You create concise, upbeat two-sentence summaries for Titan Reach performance notifications.',
                ],
                [
                    'role'    => 'user',
                    'content' => $prompt,
                ],
            ], $options);

            $content = trim((string) $result->content);

            if ($result->success && $content !== '') {
                return Str::limit($content, 500);
            }
        } catch (Throwable $exception) {
            Log::warning('Failed to summarize Titan Reach analysis', [
                'type'    => $type,
                'message' => $exception->getMessage(),
            ]);
        }

        return Str::limit($cleanReport, 220);
    }

    protected function notifyUser(TitanReachAnalysis $analysis, TitanReachAgent $agent): void
    {
        $user = $agent->user;

        if (! $user) {
            return;
        }

        try {
            $title = Str::headline(str_replace('_', ' ', $analysis->type)) . ' ready';
            $message = Str::limit(
                preg_replace('!\s+!', ' ', strip_tags($analysis->report_text)),
                180
            );

            $link = '#';

            if (function_exists('route')) {
                try {
                    $link = route('dashboard.user.titan-reach.agent.chat.index', $agent->id) . '?analysis=' . $analysis->id;
                } catch (Throwable $routeException) {
                    Log::notice('Unable to build analysis notification link', [
                        'analysis_id' => $analysis->id,
                        'message'     => $routeException->getMessage(),
                    ]);
                }
            }

            Notify::to($user, $title, $message, $link);
        } catch (Throwable $exception) {
            Log::warning('Failed to send Titan Reach analysis notification', [
                'analysis_id' => $analysis->id,
                'agent_id'    => $agent->id,
                'message'     => $exception->getMessage(),
            ]);
        }
    }
}
