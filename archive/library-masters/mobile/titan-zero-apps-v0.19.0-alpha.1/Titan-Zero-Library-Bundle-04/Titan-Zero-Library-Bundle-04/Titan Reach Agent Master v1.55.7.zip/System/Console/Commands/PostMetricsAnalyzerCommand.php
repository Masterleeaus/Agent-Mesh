<?php

namespace App\Extensions\TitanReachAgent\System\Console\Commands;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;
use App\Extensions\TitanReachAgent\System\Services\Analysis\AgentInsightsService;
use App\Extensions\TitanReachAgent\System\Services\Analysis\AnalysisRecorder;
use App\Extensions\TitanReachAgent\System\Services\Analysis\AnalysisClient;

class PostMetricsAnalyzerCommand extends AbstractAgentAnalysisCommand
{
    protected $signature = 'titan-reach-agent:post-metrics-analyzer
                            {--agent= : Limit the analysis to a single agent ID}';

    protected $description = 'Analyze recent post metrics for every active agent and store an AI-routed summary.';

    public function __construct(
        AnalysisClient $analysisClient,
        AnalysisRecorder $analysisRecorder,
        protected AgentInsightsService $insightsService
    ) {
        parent::__construct($analysisClient, $analysisRecorder);
    }

    protected function analysisType(): string
    {
        return 'post_metrics_analyzer';
    }

    protected function buildMessages(TitanReachAgent $agent): array
    {
        $snapshot = $this->insightsService->buildMetricsSnapshot($agent);

        $context = [
            'analysis'         => 'post_metrics_overview',
            'agent'            => [
                'id'       => $agent->id,
                'name'     => $agent->name,
                'language' => $this->responseLanguage($agent),
            ],
            'generated_at'     => now()->toAtomString(),
            'metrics_snapshot' => $snapshot,
        ];

        $content = <<<PROMPT
			You are a Titan Reach performance analyst. Based on the following metrics snapshot:
			- Summarize overall performance (max two sentences)
			- Highlight the best and weakest posts with the reasons
			- Recommend two quick actions for the upcoming days

			Respond in {$this->responseLanguage($agent)} using bullet points.

			Dataset:
			{$this->encodeContext($context)}
		PROMPT;

        return [
            [
                'role'    => 'system',
                'content' => 'You are an experienced Titan Reach analyst who turns raw metrics into concise, actionable summaries.',
            ],
            [
                'role'    => 'user',
                'content' => $content,
            ],
        ];
    }
}
