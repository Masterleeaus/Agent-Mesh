<?php

namespace App\Extensions\TitanReachAgent\System\Console\Commands;

use App\Extensions\TitanReachAgent\System\Database\Seeders\TitanReachAgentDemoSeeder;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Console\Command\Command as CommandAlias;

class SeedDemoDataCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'titan-reach-agent:seed-demo-data';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seed demo agents and posts for Titan Reach Agent extension';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting Titan Reach Agent demo data seeding...');
        $this->newLine();

        Log::info('titan-reach-agent:seed-demo-data started');

        $seeder = new TitanReachAgentDemoSeeder;
        $seeder->setCommand($this);
        $seeder->run();

        $this->newLine();
        $this->info('✅ Demo data seeding completed!');
        Log::info('titan-reach-agent:seed-demo-data finished');

        return CommandAlias::SUCCESS;
    }
}
