<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

final class FinalCustomerReleaseCandidate
{
    public const REQUIRED_GATES = [
        'zip_integrity',
        'manifest_parse',
        'php_lint',
        'runtime_readiness',
        'migration_compatibility',
        'webhook_dry_run',
        'field_marketing_hub_workflow_trial',
        'local_growth_agent_operational_trial',
        'commercial_tier_enforcement',
        'safety_controls_locked',
    ];

    public const LOCKED_SAFETY_CONTROLS = [
        'company_id_required',
        'webhooks_fail_closed',
        'callback_correlation_required',
        'ssrf_protection_enabled',
        'payload_redaction_enabled',
        'media_privacy_enabled',
        'publish_governance_enabled',
        'commercial_tiers_do_not_disable_safety',
        'demo_data_marked_demo_only',
    ];

    /** @var array<string, mixed> */
    private array $config;

    /** @param array<string, mixed>|null $config */
    public function __construct(?array $config = null)
    {
        $this->config = $config ?? (function_exists('config') ? (array) config('field-service-final-customer-release.' . self::class, []) : []);
    }

    /** @param array<string, mixed> $runtime @return array<string, mixed> */
    public function certify(array $runtime = []): array
    {
        $missing = [];
        foreach (self::REQUIRED_GATES as $gate) {
            if (array_key_exists($gate, $runtime) && $runtime[$gate] !== true) {
                $missing[] = $gate;
            }
        }
        if (empty($runtime['company_id'])) {
            $missing[] = 'company_id_required';
        }
        $status = $missing === [] ? 'release_candidate_ready' : 'release_candidate_blocked';
        return [
            'status' => $status,
            'release_stage' => $this->config['release_stage'] ?? 'final_customer_release_candidate',
            'release_candidate' => $this->config['release_candidate'] ?? 'RC1',
            'customer_ready' => $status === 'release_candidate_ready',
            'requires_live_install_trial' => true,
            'missing_or_failed_gates' => array_values(array_unique($missing)),
            'locked_safety_controls' => self::LOCKED_SAFETY_CONTROLS,
            'customer_install_notes' => $this->config['customer_install_notes'] ?? [],
            'summary' => $this->redact($runtime),
        ];
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    private function redact(array $payload): array
    {
        $blocked = ['token', 'secret', 'signature', 'password', 'raw_webhook_body', 'customer_name', 'customer_handle', 'contact_value', 'external_customer_id'];
        $redacted = [];
        foreach ($payload as $key => $value) {
            $normalised = strtolower((string) $key);
            if (in_array($normalised, $blocked, true)) {
                $redacted[$key] = '[redacted]';
                continue;
            }
            $redacted[$key] = is_array($value) ? $this->redact($value) : $value;
        }
        return $redacted;
    }
}
