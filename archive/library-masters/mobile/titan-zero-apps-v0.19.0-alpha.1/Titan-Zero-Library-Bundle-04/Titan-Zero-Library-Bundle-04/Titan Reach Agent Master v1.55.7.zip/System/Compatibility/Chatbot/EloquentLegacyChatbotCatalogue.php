<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility\Chatbot;

use App\Models\Chatbot\Chatbot;

/**
 * Compatibility adapter retained for the existing Reach chat view.
 *
 * The Chatbot model is intentionally confined here so canonical Reach controllers,
 * capabilities and Titan Apps contributions do not depend on legacy Chatbot identity.
 * Agent 1 can replace this binding with the shared Interaction/App identity catalogue
 * when that public contract is available.
 */
final class EloquentLegacyChatbotCatalogue implements ChatbotCatalogue
{
    public function all(): iterable
    {
        return Chatbot::query()->get();
    }
}
