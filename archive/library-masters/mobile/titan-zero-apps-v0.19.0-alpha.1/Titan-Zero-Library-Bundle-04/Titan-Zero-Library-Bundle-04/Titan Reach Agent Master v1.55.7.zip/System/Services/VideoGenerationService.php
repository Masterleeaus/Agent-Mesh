<?php

namespace App\Extensions\TitanReachAgent\System\Services;

use App\Extensions\TitanReachAgent\System\Services\Video\VideoGenerationClient;
use Exception;
use Illuminate\Support\Facades\Log;

class VideoGenerationService
{
    public function __construct(private readonly VideoGenerationClient $client) {}

    public function generateVideoForPost(string $postContent, array $options = []): array
    {
        try {
            $platform = strtolower($options['platform'] ?? '');
            $prompt = $this->buildPrompt($postContent, $platform);
            $result = $this->client->generate($prompt, [
                'aspect_ratio' => $this->aspectRatioForPlatform($platform),
                'duration' => $this->durationForPlatform($platform),
                'platform' => $platform,
            ]);
            $result['prompt'] = $prompt;
            $result['platform'] = $platform;
            return $result;
        } catch (Exception $e) {
            Log::error('VideoGenerationService error', ['error' => $e->getMessage()]);
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function checkStatus(string $requestId): array
    {
        try {
            return $this->client->status($requestId);
        } catch (Exception $e) {
            Log::error('VideoGenerationService checkStatus error', ['error' => $e->getMessage()]);
            return ['success' => false, 'status' => 'failed'];
        }
    }

    protected function buildPrompt(string $content, string $platform): string
    {
        $audience = $platform === 'youtube-shorts'
            ? 'Create a dynamic vertical video optimized for YouTube Shorts'
            : 'Create a cinematic horizontal video tailored for the main YouTube feed';
        return <<<PROMPT
{$audience}. Keep it tightly synced to the following message:
"{$content}"

Focus on storytelling visuals, scene transitions, and pacing that matches {$platform} best practices. Avoid on-screen text.
PROMPT;
    }

    protected function aspectRatioForPlatform(string $platform): string { return $platform === 'youtube' ? '16:9' : '9:16'; }
    protected function durationForPlatform(string $platform): string { return $platform === 'youtube' ? '12s' : '8s'; }
}
