<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachAgent\System\Support;
final class PaidGrowthRecommendationService { public function recommend(array $context): array { return ['company_id'=>(int)($context['company_id']??0),'recommendation_only'=>true,'channels'=>['meta_ads','google_local_services_ads'],'requires_governance'=>true,'automatic_activation'=>false]; } }
