<?php

namespace App\Extensions\TitanReachAgent\System\Services\Ai;

use App\Extensions\TitanReachAgent\System\Services\Ai\Contracts\ChatCompletionProvider;
use App\Extensions\TitanReachAgent\System\Services\Ai\Dto\ChatCompletionResult;
use Illuminate\Contracts\Container\Container;
use Throwable;

class AiProviderManager
{
    public const HOST_PROVIDER_BINDING = 'titan.ai.chat-provider';
    public const LEGACY_FALLBACK_BINDING = 'titan-reach-agent.ai.legacy-fallback-provider';

    public function __construct(private readonly Container $container) {}

    public function provider(): ChatCompletionProvider
    {
        if ($this->container->bound(self::HOST_PROVIDER_BINDING)) {
            $provider = $this->container->make(self::HOST_PROVIDER_BINDING);
            if ($provider instanceof ChatCompletionProvider) {
                return $provider;
            }
        }

        // Compatibility-only fallback. The canonical path above is owned by the host
        // intelligence router; Reach does not choose a concrete backend itself.
        if ($this->container->bound(self::LEGACY_FALLBACK_BINDING)) {
            try {
                $provider = $this->container->make(self::LEGACY_FALLBACK_BINDING);
                if ($provider instanceof ChatCompletionProvider && $provider->configured()) {
                    return $provider;
                }
            } catch (Throwable $exception) {
                // Fall through to the deterministic unavailable provider.
            }
        }

        return $this->container->make(NullChatCompletionProvider::class);
    }

    /**
     * @param array<int, array{role:string, content:string}> $messages
     * @param array<string, mixed> $options
     */
    public function complete(array $messages, array $options = []): ChatCompletionResult
    {
        return $this->provider()->complete($messages, $options);
    }
}
