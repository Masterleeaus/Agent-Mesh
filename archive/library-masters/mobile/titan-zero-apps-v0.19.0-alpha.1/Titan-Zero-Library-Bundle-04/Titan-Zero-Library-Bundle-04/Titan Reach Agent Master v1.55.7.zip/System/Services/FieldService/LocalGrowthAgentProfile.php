<?php

namespace App\Extensions\TitanReachAgent\System\Services\FieldService;

use App\Extensions\TitanReachAgent\System\Models\TitanReachAgent;

class LocalGrowthAgentProfile
{
    public function fromAgent(TitanReachAgent $agent): array
    {
        $context = app(SharedFieldServiceContextResolver::class)->resolve($agent->company_id ?? null, $agent->user_id ?? null);

        $services = $this->normalizeList($agent->field_service_services ?? data_get($context, 'services', []));
        $areas = $this->normalizeList($agent->field_service_areas ?? data_get($context, 'service_areas', []));
        $growthGoals = $this->normalizeList($agent->field_service_growth_goals ?? $agent->goals ?? []);
        $contentMix = $this->normalizeList($agent->field_service_content_mix ?? $agent->post_types ?? []);

        return [
            'business_name' => data_get($context, 'business_name'),
            'vertical' => $agent->field_service_vertical ?: data_get($context, 'vertical'),
            'services' => $services,
            'service_areas' => $areas,
            'growth_goals' => $growthGoals,
            'content_mix' => $contentMix,
            'strategy' => $agent->field_service_strategy ?? [],
            'quote_url' => data_get($context, 'quote_url'),
            'booking_url' => data_get($context, 'booking_url'),
            'review_url' => data_get($context, 'review_url'),
            'emergency_available' => (bool) data_get($context, 'emergency_available', false),
            'privacy_defaults' => data_get($context, 'privacy_defaults', []),
            'vertical_pack' => app(FieldServiceVerticalPackCatalog::class)->resolve((string) ($agent->field_service_vertical ?: data_get($context, 'vertical', ''))),
        ];
    }

    public function promptBlock(TitanReachAgent $agent): string
    {
        $profile = $this->fromAgent($agent);
        $lines = ['Field/Home-Service Local Growth Context:'];
        foreach ([
            'Business' => $profile['business_name'],
            'Vertical' => $profile['vertical'],
            'Services' => implode(', ', $profile['services']),
            'Service Areas' => implode(', ', $profile['service_areas']),
            'Growth Goals' => implode(', ', $profile['growth_goals']),
            'Content Mix' => implode(', ', $profile['content_mix']),
        ] as $label => $value) {
            if (is_string($value) && trim($value) !== '') {
                $lines[] = $label . ': ' . trim($value);
            }
        }
        if (! empty($profile['quote_url'])) { $lines[] = 'Quote URL available.'; }
        if (! empty($profile['booking_url'])) { $lines[] = 'Booking URL available.'; }
        if (! empty($profile['review_url'])) { $lines[] = 'Review URL available.'; }
        if (! empty($profile['vertical_pack']['safe_content_lanes'])) { $lines[] = 'Vertical Pack Safe Lanes: ' . implode(', ', array_slice($profile['vertical_pack']['safe_content_lanes'], 0, 5)); }
        if (! empty($profile['vertical_pack']['privacy_warnings'])) { $lines[] = 'Vertical Pack Privacy Warning: ' . $profile['vertical_pack']['privacy_warnings'][0]; }
        if ($profile['emergency_available']) { $lines[] = 'Emergency service is explicitly configured.'; }
        $lines[] = 'Never invent service areas, licences, prices, emergency availability, exact addresses, customer names, faces or vehicle plates.';
        return implode("
", $lines);
    }

    private function normalizeList($value): array
    {
        if (! is_array($value)) { return []; }
        return collect($value)->map(function ($item) {
            if (is_string($item)) { return trim($item); }
            if (is_array($item)) { return trim((string) ($item['name'] ?? $item['label'] ?? $item['service'] ?? $item['area'] ?? '')); }
            return '';
        })->filter()->values()->all();
    }
}
