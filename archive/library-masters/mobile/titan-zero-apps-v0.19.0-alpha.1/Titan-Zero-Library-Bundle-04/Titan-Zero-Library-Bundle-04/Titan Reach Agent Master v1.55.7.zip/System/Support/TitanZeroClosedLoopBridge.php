<?php
declare(strict_types=1);
namespace App\Extensions\TitanReachAgent\System\Support;

use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Str;

/**
 * Titan Reach bridge to the canonical Titan Zero provider boundaries.
 *
 * Important: this bridge does not assume every domain is a root Command Bus
 * capability. CRM is entered through CrmCommandBusGateway, Titan Field reads
 * through CapacityForecastService, Field signals through FieldSignalPort, and
 * customer messaging through Titan Connect's MessagingToolGateway. The root
 * Titan Command Bus remains available only for capabilities with a registered
 * CommandAdapter.
 */
final class TitanZeroClosedLoopBridge
{
    private const ROOT_COMMAND_BUS='App\\Extensions\\TitanCommandBus\\System\\Contracts\\CommandBusContract';
    private const ROOT_COMMAND_CONTEXT='App\\Extensions\\TitanCommandBus\\System\\DTO\\CommandContext';
    private const ROOT_COMMAND_REQUEST='App\\Extensions\\TitanCommandBus\\System\\DTO\\CommandRequest';

    private const CRM_GATEWAY='App\\Extensions\\Crm\\System\\Governance\\CrmCommandBusGateway';
    private const CRM_SCOPE='App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope';
    private const CRM_CONTEXT_RESOLVER='App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyContextResolver';

    private const FIELD_TENANT='App\\Extensions\\TitanField\\System\\Contracts\\FieldTenantContext';
    private const FIELD_SIGNAL='App\\Extensions\\TitanField\\System\\Contracts\\FieldSignalPort';
    private const FIELD_CAPACITY='App\\Extensions\\TitanField\\System\\Domains\\FieldServices\\Forecasting\\CapacityForecastService';

    private const CONNECT='App\\Extensions\\TitanConnect\\System\\Contracts\\MessagingToolGateway';

    public function __construct(private readonly Container $app) {}

    public function health(): array
    {
        return [
            'company_boundary'=>'company_id',
            'organisation_owner'=>'titan-ai-workforce',
            'root_command_bus'=>$this->available(self::ROOT_COMMAND_BUS),
            'crm'=>$this->available(self::CRM_GATEWAY) && $this->available(self::CRM_SCOPE) && $this->available(self::CRM_CONTEXT_RESOLVER),
            'field'=>$this->available(self::FIELD_TENANT) && $this->available(self::FIELD_SIGNAL) && $this->available(self::FIELD_CAPACITY),
            'connect'=>$this->available(self::CONNECT),
            'hard_dependency'=>false,
        ];
    }

    /** Dispatch a capability only when Titan Command Bus has a registered adapter. */
    public function dispatchGoverned(int $companyId,string $capability,array $payload,array $context=[]): array
    {
        if($companyId<1)return ['status'=>'blocked','reason'=>'company_id_required'];
        if(!$this->available(self::ROOT_COMMAND_BUS)||!class_exists(self::ROOT_COMMAND_CONTEXT)||!class_exists(self::ROOT_COMMAND_REQUEST))return ['status'=>'unavailable','reason'=>'titan_command_bus_not_installed'];
        $cc=self::ROOT_COMMAND_CONTEXT;$rc=self::ROOT_COMMAND_REQUEST;
        $actorType=trim((string)($context['actor_type']??'system'))?:'system';
        $serviceId=trim((string)($context['service_id']??'titan-reach'))?:'titan-reach';
        try {
            $ctx=$cc::forCompany($companyId,$actorType,$context['actor_id']??null,$serviceId);
            $req=new $rc(
                capability:$capability,
                payload:$this->sanitize($payload),
                idempotencyKey:$this->id($context['idempotency_key']??null),
                traceId:$this->id($context['trace_id']??null),
                correlationId:$this->id($context['correlation_id']??null),
                causationId:$this->id($context['causation_id']??null),
                rootCausationId:$this->id($context['root_causation_id']??($context['causation_id']??null)),
                expectedEntityVersion:$context['expected_entity_version']??null,
                preparedOffline:(bool)($context['prepared_offline']??false),
            );
            $receipt=$this->app->make(self::ROOT_COMMAND_BUS)->dispatch($ctx,$req);
            return method_exists($receipt,'toArray')?$receipt->toArray():['status'=>'accepted'];
        } catch(\Throwable $e) {
            return ['status'=>'blocked','reason'=>'governed_command_rejected','error_class'=>$e::class];
        }
    }

    public function createCrmLead(int $companyId,array $payload,array $context=[]): array
    {
        return $this->crmRequest($companyId,'crm.lead.create',$payload,$context);
    }

    public function recordConversion(int $companyId,array $payload,array $context=[]): array
    {
        $subjectType=trim((string)($payload['subject_type']??''));
        $subjectId=trim((string)($payload['subject_public_id']??''));
        if($subjectType===''||$subjectId==='')return ['status'=>'blocked','reason'=>'crm_conversion_subject_required'];
        $input=$payload;
        unset($input['activity_type']);
        $input['type']=trim((string)($input['type']??'system'))?:'system';
        $input['title']=trim((string)($input['title']??'Titan Reach conversion'))?:'Titan Reach conversion';
        $metadata=(array)($input['metadata']??[]);
        $metadata['source']='titan_reach';
        $input['metadata']=$metadata;
        return $this->crmRequest($companyId,'crm.activity.create',$input,$context);
    }

    public function requestFieldCapacity(int $companyId,int $userId,string $from,int $days=14): array
    {
        if($companyId<1||$userId<1)return ['status'=>'blocked','reason'=>$companyId<1?'company_id_required':'user_id_required'];
        if(!$this->available(self::FIELD_TENANT)||!$this->available(self::FIELD_CAPACITY))return ['status'=>'unavailable','reason'=>'titan_field_not_installed'];
        try {
            $tenant=(int)$this->app->make(self::FIELD_TENANT)->companyId($userId);
            if($tenant!==$companyId)return ['status'=>'blocked','reason'=>'company_mismatch'];
            return ['status'=>'ok','data'=>$this->app->make(self::FIELD_CAPACITY)->forecast($userId,$from,$days)];
        } catch(\Throwable $e) {
            return ['status'=>'blocked','reason'=>'field_capacity_rejected','error_class'=>$e::class];
        }
    }

    public function emitFieldSignal(int $userId,int $companyId,string $eventName,array $payload,array $context=[]): array
    {
        if($companyId<1||$userId<1)return ['status'=>'blocked','reason'=>$companyId<1?'company_id_required':'user_id_required'];
        if(!$this->available(self::FIELD_TENANT)||!$this->available(self::FIELD_SIGNAL))return ['status'=>'unavailable','reason'=>'titan_field_not_installed'];
        try {
            if((int)$this->app->make(self::FIELD_TENANT)->companyId($userId)!==$companyId)return ['status'=>'blocked','reason'=>'company_mismatch'];
            return $this->app->make(self::FIELD_SIGNAL)->record(
                $userId,
                isset($context['actor_user_id'])?(int)$context['actor_user_id']:null,
                $eventName,
                'titan_reach',
                isset($context['subject_public_id'])?(string)$context['subject_public_id']:null,
                $this->sanitize($payload),
                $context,
            );
        } catch(\Throwable $e) {
            return ['status'=>'blocked','reason'=>'field_signal_rejected','error_class'=>$e::class];
        }
    }

    public function sendExternalMessage(int $companyId,int $actorId,string $connectionUuid,string $threadUuid,string $recipient,string $body,?string $idempotencyKey=null): array
    {
        if($companyId<1||$actorId<1||!$this->available(self::CONNECT))return ['status'=>'unavailable','reason'=>$companyId<1?'company_id_required':($actorId<1?'actor_id_required':'titan_connect_not_installed')];
        if($connectionUuid===''||$threadUuid===''||$recipient===''||trim($body)==='')return ['status'=>'blocked','reason'=>'explicit_message_context_required'];
        try {
            return $this->app->make(self::CONNECT)->externalSend($companyId,$actorId,$connectionUuid,$threadUuid,$recipient,$body,$idempotencyKey?:((string)Str::uuid()));
        } catch(\Throwable $e) {
            return ['status'=>'blocked','reason'=>'titan_connect_rejected','error_class'=>$e::class];
        }
    }

    private function crmRequest(int $companyId,string $capability,array $payload,array $context): array
    {
        if($companyId<1)return ['status'=>'blocked','reason'=>'company_id_required'];
        if(!$this->available(self::CRM_GATEWAY)||!$this->available(self::CRM_SCOPE)||!$this->available(self::CRM_CONTEXT_RESOLVER))return ['status'=>'unavailable','reason'=>'titan_crm_not_installed'];
        $actorId=isset($context['actor_id'])?(int)$context['actor_id']:(isset($context['actor_user_id'])?(int)$context['actor_user_id']:null);
        $actorType=trim((string)($context['actor_type']??($actorId?'user':'system')))?:'system';
        try {
            $resolver=$this->app->make(self::CRM_CONTEXT_RESOLVER);
            $crmContext=$resolver->fromTrustedPlatform(
                companyId:$companyId,
                actorUserId:$actorId?:null,
                actorType:$actorType,
                roles:array_values(array_map('strval',(array)($context['roles']??[]))),
                permissions:array_values(array_map('strval',(array)($context['permissions']??[]))),
                sourceSurface:'titan_reach',
                correlationId:$this->id($context['correlation_id']??null),
                membershipVerified:(bool)($context['membership_verified']??($actorId!==null)),
                traceId:$this->id($context['trace_id']??null),
                causationId:isset($context['causation_id'])?$this->id($context['causation_id']):null,
            );
            return $this->app->make(self::CRM_SCOPE)->runWith($crmContext,fn()=> $this->app->make(self::CRM_GATEWAY)->request($capability,$this->sanitize($payload),'titan_reach'));
        } catch(\Throwable $e) {
            return ['status'=>'blocked','reason'=>'crm_command_rejected','error_class'=>$e::class];
        }
    }

    private function available(string $abstract): bool
    {
        return (interface_exists($abstract)||class_exists($abstract)) && $this->app->bound($abstract);
    }

    private function id(mixed $value): string
    {
        $value=trim((string)$value);
        return substr($value!==''?$value:(string)Str::uuid(),0,191);
    }

    private function sanitize(array $payload): array
    {
        foreach(['token','access_token','refresh_token','secret','password','signature','raw_webhook_body','authorization','cookie'] as $key)if(array_key_exists($key,$payload))$payload[$key]='[REDACTED]';
        unset($payload['company_id'],$payload['tenant_company_id'],$payload['tenant_id']);
        $payload['integration_source']='titan_reach';
        return $payload;
    }
}
