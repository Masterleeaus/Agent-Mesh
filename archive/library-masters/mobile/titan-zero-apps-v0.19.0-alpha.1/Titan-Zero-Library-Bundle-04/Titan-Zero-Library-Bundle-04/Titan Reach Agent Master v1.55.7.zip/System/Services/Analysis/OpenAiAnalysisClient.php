<?php

namespace App\Extensions\TitanReachAgent\System\Services\Analysis;

/**
 * @deprecated Compatibility alias for callers compiled against the former provider-specific
 * analysis client. Canonical runtime code should depend on AnalysisClient.
 */
class OpenAiAnalysisClient extends AnalysisClient
{
}
