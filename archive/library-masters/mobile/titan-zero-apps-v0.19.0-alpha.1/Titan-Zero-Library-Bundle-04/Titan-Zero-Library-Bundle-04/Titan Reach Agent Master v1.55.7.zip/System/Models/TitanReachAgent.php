<?php

namespace App\Extensions\TitanReachAgent\System\Models;

use App\Extensions\TitanReachPro\System\Models\TitanReachPlatform;
use App\Models\User;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class TitanReachAgent extends Model
{
    use SoftDeletes;

    protected $table = 'titan_reach_agents';

    protected $fillable = [
        'user_id',
        'company_id',
        'name',
        'platform_ids',
        'site_url',
        'site_description',
        'field_service_vertical',
        'field_service_services',
        'field_service_areas',
        'scraped_content',
        'target_audience',
        'post_types',
        'tone',
        'cta_templates',
        'categories',
        'goals',
        'field_service_growth_goals',
        'field_service_content_mix',
        'field_service_strategy',
        'local_growth_intelligence',
        'local_growth_signal_scores',
        'local_growth_recommendation_state',
        'branding_description',
        'creativity',
        'hashtag_count',
        'approximate_words',
        'language',
        'schedule_days',
        'schedule_times',
        'daily_post_count',
        'reserved_post_day',
        'start_train_post_count',
        'has_image',
        'publishing_type',
        'is_active',
        'settings',
        'post_generation_status',
        'average_impressions',
        'average_engagement',
    ];

    protected $casts = [
        'platform_ids'            => 'array',
        'scraped_content'         => 'array',
        'target_audience'         => 'array',
        'post_types'              => 'array',
        'cta_templates'           => 'array',
        'categories'              => 'array',
        'goals'                   => 'array',
        'field_service_services'  => 'array',
        'field_service_areas'     => 'array',
        'field_service_growth_goals' => 'array',
        'field_service_content_mix' => 'array',
        'field_service_strategy'  => 'array',
        'local_growth_intelligence' => 'array',
        'local_growth_signal_scores' => 'array',
        'local_growth_recommendation_state' => 'array',
        'schedule_days'           => 'array',
        'schedule_times'          => 'array',
        'settings'                => 'array',
        'post_generation_status'  => 'array',
        'has_image'               => 'boolean',
        'is_active'               => 'boolean',
        'hashtag_count'           => 'integer',
        'approximate_words'       => 'integer',
        'daily_post_count'        => 'integer',
        'reserved_post_day'       => 'integer',
        'start_train_post_count'  => 'integer',
        'average_impressions'     => 'float',
        'average_engagement'      => 'float',
    ];

    // Relationships

    public function image(): Attribute
    {
        return Attribute::make(
            get: fn () => asset('vendor/titan-reach-agent/images/agent-default.png'),
        );
    }

    public function imageUrl(): Attribute
    {
        return Attribute::make(
            get: fn () => asset('vendor/titan-reach-agent/images/agent-default.png'),
        );
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function posts(): HasMany
    {
        return $this->hasMany(TitanReachAgentPost::class, 'agent_id');
    }

    public function platforms()
    {
        return TitanReachPlatform::whereIn('id', $this->platform_ids ?? [])->get();
    }

    // Helper Methods

    public function isActive(): bool
    {
        return $this->is_active;
    }

    public function hasSiteUrl(): bool
    {
        return ! empty($this->site_url);
    }

    public function hasTargetAudience(): bool
    {
        return ! empty($this->target_audience);
    }

    public function getScheduledDays(): array
    {
        return $this->schedule_days ?? [];
    }

    public function getScheduledTimes(): array
    {
        return $this->schedule_times ?? [];
    }


    public function fieldServiceSummary(): array
    {
        return [
            'vertical' => $this->field_service_vertical,
            'services' => $this->field_service_services ?? [],
            'areas' => $this->field_service_areas ?? [],
            'growth_goals' => $this->field_service_growth_goals ?? [],
            'content_mix' => $this->field_service_content_mix ?? [],
            'strategy' => $this->field_service_strategy ?? [],
            'intelligence' => $this->local_growth_intelligence ?? [],
            'signal_scores' => $this->local_growth_signal_scores ?? [],
        ];
    }

    public function canGeneratePosts(): bool
    {
        return $this->is_active
            && ! empty($this->platform_ids)
            && ! empty($this->target_audience)
            && ! empty($this->schedule_days)
            && ! empty($this->schedule_times);
    }

    // Scopes

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }
}
