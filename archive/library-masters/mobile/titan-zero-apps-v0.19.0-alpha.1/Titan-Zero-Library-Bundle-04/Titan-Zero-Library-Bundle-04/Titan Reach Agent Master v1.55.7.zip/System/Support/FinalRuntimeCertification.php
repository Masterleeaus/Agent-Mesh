<?php

namespace App\Extensions\TitanReachAgent\System\Support;

class FinalRuntimeCertification
{
    public const STEP = '24';
    public const CERTIFICATION_STATUS = 'runtime-ready';

    /**
     * Return a deterministic final-certification summary that can be used by installer smoke tests.
     *
     * @return array<string, mixed>
     */
    public function summary(): array
    {
        return [
            'module' => 'local_growth_agent',
            'step' => self::STEP,
            'status' => self::CERTIFICATION_STATUS,
            'requires_company_id' => true,
            'standalone_safe' => true,
            'security_controls_locked' => true,
            'privacy_controls_locked' => true,
            'publish_governance_locked' => true,
            'webhooks_fail_closed' => true,
            'demo_data_marked_demo_only' => true,
            'titan_integrations_optional' => true,
        ];
    }

    /**
     * @return list<string>
     */
    public function certificationGates(): array
    {
        return [
            'archive_path_safety',
            'manifest_json_parse',
            'bom_free_manifest',
            'php_lint',
            'runtime_readiness',
            'route_menu_smoke',
            'lead_flow_simulation',
            'publish_governance',
            'titan_hooks_optional',
            'commercial_limits_safe',
            'demo_showcase_safe',
        ];
    }
}
