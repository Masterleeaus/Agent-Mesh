<?php

namespace App\Extensions\TitanReachAgent\System\Services\Ai;

use App\Domains\Entity\Enums\EntityEnum;
use App\Extensions\TitanReachAgent\System\Services\Ai\Contracts\ChatCompletionProvider;
use App\Extensions\TitanReachAgent\System\Services\Ai\Dto\ChatCompletionResult;
use App\Helpers\Classes\ApiHelper;
use App\Helpers\Classes\OpenAiParamHelper;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

class OpenAiChatCompletionProvider implements ChatCompletionProvider
{
    public function name(): string
    {
        return 'openai';
    }

    public function configured(): bool
    {
        try {
            return (string) ApiHelper::setOpenAiKey() !== '';
        } catch (Throwable $exception) {
            return false;
        }
    }

    public function complete(array $messages, array $options = []): ChatCompletionResult
    {
        try {
            $apiKey = ApiHelper::setOpenAiKey();
            if (! is_string($apiKey) || trim($apiKey) === '') {
                return ChatCompletionResult::failure('AI provider is not configured.', $this->name());
            }

            $payload = OpenAiParamHelper::sanitizeChatParams([
                'model'       => $options['model'] ?? config('services.openai.chat_model', EntityEnum::GPT_5_MINI->value),
                'messages'    => $messages,
                'temperature' => $options['temperature'] ?? 0.7,
                'max_tokens'  => $options['max_tokens'] ?? 900,
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type'  => 'application/json',
            ])->timeout((int) ($options['timeout'] ?? 60))
              ->post('https://api.openai.com/v1/chat/completions', $payload);

            if ($response->failed()) {
                Log::warning('AI provider request failed', [
                    'provider' => $this->name(),
                    'status' => $response->status(),
                    'model' => $payload['model'] ?? null,
                ]);

                return ChatCompletionResult::failure('AI provider returned a non-success status.', $this->name(), $response->status());
            }

            $content = trim((string) data_get($response->json(), 'choices.0.message.content', ''));
            if ($content === '') {
                return ChatCompletionResult::failure('AI provider returned an empty response.', $this->name(), $response->status());
            }

            return ChatCompletionResult::success($content, $this->name(), [
                'model' => $payload['model'] ?? null,
            ]);
        } catch (Throwable $exception) {
            Log::error('AI provider request crashed', [
                'provider' => $this->name(),
                'message' => $exception->getMessage(),
            ]);

            return ChatCompletionResult::failure($exception->getMessage(), $this->name());
        }
    }
}
