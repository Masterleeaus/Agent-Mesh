<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Support;

/**
 * Deterministic publish-governance helper for field/home-service marketing.
 *
 * This class keeps draft creation, publish requests and external publishing as
 * separate states. It is intentionally framework-light so it can be reused by
 * the four social extensions without creating hard database dependencies.
 */
class PublishFlowGovernance
{
    public const STATE_DRAFT = 'draft';
    public const STATE_REVIEW_REQUIRED = 'review_required';
    public const STATE_APPROVED = 'approved';
    public const STATE_PUBLISH_REQUESTED = 'publish_requested';
    public const STATE_PUBLISHED = 'published';
    public const STATE_REJECTED = 'rejected';
    public const STATE_BLOCKED = 'blocked';

    /**
     * @return array<int, string>
     */
    public function states(): array
    {
        return [
            self::STATE_DRAFT,
            self::STATE_REVIEW_REQUIRED,
            self::STATE_APPROVED,
            self::STATE_PUBLISH_REQUESTED,
            self::STATE_PUBLISHED,
            self::STATE_REJECTED,
            self::STATE_BLOCKED,
        ];
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function evaluateDraft(array $context): array
    {
        $reasons = [];

        if (empty($context['company_id'])) {
            $reasons[] = 'company_id_required';
        }

        if (!empty($context['uses_job_media']) && empty($context['media_privacy_acknowledged'])) {
            $reasons[] = 'media_privacy_acknowledgement_required';
        }

        if (!empty($context['mentions_emergency']) && empty($context['emergency_available'])) {
            $reasons[] = 'emergency_claim_not_configured';
        }

        if (!empty($context['mentions_price']) && empty($context['price_explicitly_authorised'])) {
            $reasons[] = 'price_claim_not_authorised';
        }

        if (!empty($context['mentions_licence']) && empty($context['licence_statement_configured'])) {
            $reasons[] = 'licence_claim_not_configured';
        }

        $state = $reasons === [] ? self::STATE_DRAFT : self::STATE_REVIEW_REQUIRED;

        return [
            'state' => $state,
            'can_request_publish' => $state === self::STATE_DRAFT || $state === self::STATE_APPROVED,
            'requires_human_review' => $state === self::STATE_REVIEW_REQUIRED,
            'reasons' => $reasons,
        ];
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function requestPublish(array $context): array
    {
        $draft = $this->evaluateDraft($context);

        if (!empty($context['requires_approval']) && empty($context['approved_by_actor_id'])) {
            return [
                'state' => self::STATE_BLOCKED,
                'can_publish' => false,
                'reasons' => array_values(array_unique(array_merge($draft['reasons'], ['approval_required']))),
            ];
        }

        if (!$draft['can_request_publish']) {
            return [
                'state' => self::STATE_BLOCKED,
                'can_publish' => false,
                'reasons' => $draft['reasons'],
            ];
        }

        return [
            'state' => self::STATE_PUBLISH_REQUESTED,
            'can_publish' => true,
            'reasons' => [],
        ];
    }
}
