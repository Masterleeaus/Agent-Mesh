<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility\Ai;

use App\Helpers\Classes\ApiHelper;

/**
 * Compatibility-only bridge for the historical Reach chat runtime.
 *
 * Canonical Reach intelligence is backend-neutral. This class exists solely for
 * installations still using the legacy OpenAI chat surface. Frontend credential
 * passthrough is disabled by default and must be explicitly opted into.
 */
final class LegacyOpenAiChatRuntime
{
    public function configureServerKey(): void
    {
        config(['openai.api_key' => $this->apiKey()]);
    }

    /** @return array{0:string,1:string,2:string} */
    public function frontendKeyParts(bool $frontendStreamingRequested): array
    {
        if (! $frontendStreamingRequested || ! (bool) config('titan-reach-agent.ai.legacy_frontend_openai_key_passthrough', false)) {
            return $this->opaquePlaceholders();
        }

        $apiKey = $this->apiKey();
        if ($apiKey === '') {
            return $this->opaquePlaceholders();
        }

        $len = max(strlen($apiKey), 6);
        $first = random_int(1, $len - 5);
        $second = random_int(1, $len - $first - 3);

        return [
            base64_encode(substr($apiKey, 0, $first)),
            base64_encode(substr($apiKey, $first, $second)),
            base64_encode(substr($apiKey, $first + $second)),
        ];
    }

    private function apiKey(): string
    {
        return (string) ApiHelper::setOpenAiKey();
    }

    /** @return array{0:string,1:string,2:string} */
    private function opaquePlaceholders(): array
    {
        return [
            base64_encode((string) random_int(1, 100)),
            base64_encode((string) random_int(1, 100)),
            base64_encode((string) random_int(1, 100)),
        ];
    }
}
