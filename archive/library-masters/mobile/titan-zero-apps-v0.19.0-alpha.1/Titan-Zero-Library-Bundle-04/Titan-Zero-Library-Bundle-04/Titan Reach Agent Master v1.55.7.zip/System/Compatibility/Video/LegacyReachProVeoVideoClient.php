<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility\Video;

use App\Extensions\TitanReachAgent\System\Services\Video\VideoGenerationClient;
use App\Extensions\TitanReachPro\System\Services\Generator\GoogleVeo2Service;
use App\Helpers\Classes\ApiHelper;

/** Compatibility-only bridge for installations still relying on Reach Pro's Veo implementation. */
final class LegacyReachProVeoVideoClient implements VideoGenerationClient
{
    public function generate(string $prompt, array $options = []): array
    {
        ApiHelper::setFalAIKey();
        $response = GoogleVeo2Service::generate($prompt, $options);
        if ($response->failed()) {
            return ['success' => false, 'status' => 'failed'];
        }

        $status = strtoupper((string) $response->json('status', 'IN_QUEUE'));
        $videoUrl = $response->json('video.url');
        $storedPath = $videoUrl ? GoogleVeo2Service::downloadAndSaveVideoFromUrl($videoUrl) : null;

        return [
            'success' => true,
            'request_id' => $response->json('request_id'),
            'status' => $storedPath ? 'completed' : $this->normalizeStatus($status),
            'video_url' => $storedPath,
        ];
    }

    public function status(string $requestId): array
    {
        ApiHelper::setFalAIKey();
        $response = GoogleVeo2Service::status($requestId);
        if ($response->failed()) {
            return ['success' => false, 'status' => 'failed'];
        }

        $status = strtoupper((string) $response->json('status', 'IN_QUEUE'));
        if ($status !== 'COMPLETED') {
            return ['success' => true, 'status' => $this->normalizeStatus($status)];
        }

        $content = GoogleVeo2Service::content($requestId);
        if ($content->failed()) {
            return ['success' => false, 'status' => 'failed'];
        }

        $videoUrl = $content->json('video.url');
        $storedPath = $videoUrl ? GoogleVeo2Service::downloadAndSaveVideoFromUrl($videoUrl) : null;
        return $storedPath
            ? ['success' => true, 'status' => 'completed', 'video_url' => $storedPath]
            : ['success' => false, 'status' => 'failed'];
    }

    private function normalizeStatus(string $status): string
    {
        return match ($status) {
            'COMPLETED' => 'completed',
            'IN_PROGRESS' => 'generating',
            default => 'pending',
        };
    }
}
