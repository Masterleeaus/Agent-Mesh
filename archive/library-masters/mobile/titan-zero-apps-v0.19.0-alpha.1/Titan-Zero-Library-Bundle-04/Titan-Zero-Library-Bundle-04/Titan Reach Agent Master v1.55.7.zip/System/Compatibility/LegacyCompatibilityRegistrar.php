<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachAgent\System\Compatibility;

use App\Extensions\TitanReachAgent\System\Compatibility\Ai\LegacyOpenAiChatRuntime;
use App\Extensions\TitanReachAgent\System\Compatibility\Chatbot\ChatbotCatalogue;
use App\Extensions\TitanReachAgent\System\Compatibility\Chatbot\EloquentLegacyChatbotCatalogue;
use App\Extensions\TitanReachAgent\System\Compatibility\Chatbot\UnavailableLegacyChatbotCatalogue;
use App\Extensions\TitanReachAgent\System\Services\Ai\AiProviderManager;
use App\Extensions\TitanReachAgent\System\Services\Ai\OpenAiChatCompletionProvider;
use App\Extensions\TitanReachAgent\System\Compatibility\Video\LegacyReachProVeoVideoClient;
use App\Extensions\TitanReachAgent\System\Services\Video\HostRoutedVideoGenerationClient;
use Illuminate\Contracts\Container\Container;
use Illuminate\Routing\Router;

/**
 * Registers legacy Reach integrations behind one explicit compatibility boundary.
 *
 * Canonical Titan Reach bootstrap remains application- and backend-neutral. These
 * bindings exist only for historical Chatbot/OpenAI callers and can be removed as
 * one unit when Agent 1 supplies the canonical successor contracts.
 */
final class LegacyCompatibilityRegistrar
{
    /**
     * Register the historical Reach chat UI route without exposing its legacy
     * controller class to the canonical Reach service-provider bootstrap.
     *
     * The route name and URL remain unchanged for compatibility callers.
     */
    public static function registerUserChatRoutes(Router $router): void
    {
        $router->get('chat/{id?}', [\App\Extensions\TitanReachAgent\System\Http\Controllers\TitanReachAgentChatController::class, 'index'])
            ->name('chat.index');
    }

    public static function register(Container $container): void
    {
        $container->singleton(OpenAiChatCompletionProvider::class);
        $container->alias(OpenAiChatCompletionProvider::class, AiProviderManager::LEGACY_FALLBACK_BINDING);
        $container->singleton(LegacyOpenAiChatRuntime::class);
        $container->singleton(LegacyReachProVeoVideoClient::class);
        $container->alias(LegacyReachProVeoVideoClient::class, HostRoutedVideoGenerationClient::LEGACY_FALLBACK_BINDING);

        $catalogue = class_exists(\App\Models\Chatbot\Chatbot::class)
            ? EloquentLegacyChatbotCatalogue::class
            : UnavailableLegacyChatbotCatalogue::class;

        $container->singleton(ChatbotCatalogue::class, $catalogue);
    }
}
