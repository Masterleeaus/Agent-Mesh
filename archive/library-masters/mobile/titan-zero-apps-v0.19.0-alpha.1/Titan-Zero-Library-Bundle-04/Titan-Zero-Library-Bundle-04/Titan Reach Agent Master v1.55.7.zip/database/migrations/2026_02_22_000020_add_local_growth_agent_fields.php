<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_agents')) {
            return;
        }

        Schema::table('titan_reach_agents', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_vertical')) {
                $table->string('field_service_vertical')->nullable()->after('site_description');
            }
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_services')) {
                $table->json('field_service_services')->nullable()->after('field_service_vertical');
            }
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_areas')) {
                $table->json('field_service_areas')->nullable()->after('field_service_services');
            }
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_growth_goals')) {
                $table->json('field_service_growth_goals')->nullable()->after('goals');
            }
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_content_mix')) {
                $table->json('field_service_content_mix')->nullable()->after('field_service_growth_goals');
            }
            if (! Schema::hasColumn('titan_reach_agents', 'field_service_strategy')) {
                $table->json('field_service_strategy')->nullable()->after('field_service_content_mix');
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_reach_agents')) {
            return;
        }

        Schema::table('titan_reach_agents', function (Blueprint $table) {
            foreach ([
                'field_service_strategy',
                'field_service_content_mix',
                'field_service_growth_goals',
                'field_service_areas',
                'field_service_services',
                'field_service_vertical',
            ] as $column) {
                if (Schema::hasColumn('titan_reach_agents', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
