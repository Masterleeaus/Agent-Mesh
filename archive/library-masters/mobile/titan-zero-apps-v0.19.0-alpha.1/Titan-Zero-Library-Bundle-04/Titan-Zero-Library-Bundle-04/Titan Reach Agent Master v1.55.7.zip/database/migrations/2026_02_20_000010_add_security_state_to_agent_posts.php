<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_agents') && ! Schema::hasColumn('titan_reach_agents', 'company_id')) {
            Schema::table('titan_reach_agents', function (Blueprint $table): void {
                $table->unsignedBigInteger('company_id')->nullable()->after('user_id')->index('idx_company_id_d524c1e1');
            });
        }

        if (Schema::hasTable('titan_reach_agent_posts')) {
            Schema::table('titan_reach_agent_posts', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_reach_agent_posts', 'company_id')) {
                    $table->unsignedBigInteger('company_id')->nullable()->after('agent_id')->index('idx_company_id_bb814beb');
                }
                if (! Schema::hasColumn('titan_reach_agent_posts', 'image_callback_state')) {
                    $table->string('image_callback_state', 128)->nullable()->after('image_request_id')->index('idx_image_callback_state_7ad4be02');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_reach_agent_posts')) {
            Schema::table('titan_reach_agent_posts', function (Blueprint $table): void {
                if (Schema::hasColumn('titan_reach_agent_posts', 'image_callback_state')) {
                    $table->dropColumn('image_callback_state');
                }
                if (Schema::hasColumn('titan_reach_agent_posts', 'company_id')) {
                    $table->dropColumn('company_id');
                }
            });
        }

        if (Schema::hasTable('titan_reach_agents') && Schema::hasColumn('titan_reach_agents', 'company_id')) {
            Schema::table('titan_reach_agents', function (Blueprint $table): void {
                $table->dropColumn('company_id');
            });
        }
    }
};
