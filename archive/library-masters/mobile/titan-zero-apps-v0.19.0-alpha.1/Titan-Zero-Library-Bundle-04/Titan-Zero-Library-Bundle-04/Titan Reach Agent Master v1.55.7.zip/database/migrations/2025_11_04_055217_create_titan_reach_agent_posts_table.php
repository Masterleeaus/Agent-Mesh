<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        if (Schema::hasTable('titan_reach_agent_posts')) {
            return;
        }

        Schema::create('titan_reach_agent_posts', function (Blueprint $table) {
            $table->id();
            // Soft references only: scoped extension installs must not require
            // another extension table or create rollback-blocking FK constraints.
            $table->unsignedBigInteger('agent_id');
            $table->unsignedBigInteger('platform_id');

            // Post Content
            $table->text('content');
            $table->json('media_urls')->nullable(); // Array of image/video URLs
            $table->string('post_type')->nullable(); // 'carousel', 'single_image', 'text', 'video'

            // Scheduling & Status
            $table->enum('status', [
                'draft',
                'pending_approval',
                'approved',
                'scheduled',
                'published',
                'failed',
            ])->default('draft');
            $table->timestamp('scheduled_at')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamp('approved_at')->nullable();

            // AI Metadata
            $table->json('ai_metadata')->nullable(); // AI generation details, prompts, etc.
            $table->json('hashtags')->nullable(); // Generated hashtags
            $table->text('error_message')->nullable(); // For failed posts

            // Publishing Details
            $table->string('platform_post_id')->nullable(); // ID from Titan Reach platform
            $table->json('platform_response')->nullable(); // Response from platform API

            $table->timestamps();
            $table->softDeletes();

            // Indexes for better performance
            $table->index(['agent_id', 'status'], 'idx_agent_id_status_e1ea7fb2');
            $table->index(['scheduled_at', 'status'], 'idx_scheduled_at_status_096d7026');
            $table->index('platform_id', 'idx_platform_id_8cefe9fb');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('titan_reach_agent_posts');
    }
};
