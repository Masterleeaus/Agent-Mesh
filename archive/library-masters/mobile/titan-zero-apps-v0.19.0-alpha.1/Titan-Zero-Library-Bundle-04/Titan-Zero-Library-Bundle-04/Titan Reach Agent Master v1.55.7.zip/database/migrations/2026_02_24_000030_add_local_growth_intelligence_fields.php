<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_reach_agents', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_agents', 'local_growth_intelligence')) {
                $table->json('local_growth_intelligence')->nullable()->after('field_service_strategy');
            }

            if (! Schema::hasColumn('titan_reach_agents', 'local_growth_signal_scores')) {
                $table->json('local_growth_signal_scores')->nullable()->after('local_growth_intelligence');
            }

            if (! Schema::hasColumn('titan_reach_agents', 'local_growth_recommendation_state')) {
                $table->json('local_growth_recommendation_state')->nullable()->after('local_growth_signal_scores');
            }
        });

        Schema::table('titan_reach_agent_posts', function (Blueprint $table) {
            if (! Schema::hasColumn('titan_reach_agent_posts', 'local_growth_signal')) {
                $table->json('local_growth_signal')->nullable()->after('ai_metadata');
            }
        });
    }

    public function down(): void
    {
        Schema::table('titan_reach_agent_posts', function (Blueprint $table) {
            if (Schema::hasColumn('titan_reach_agent_posts', 'local_growth_signal')) {
                $table->dropColumn('local_growth_signal');
            }
        });

        Schema::table('titan_reach_agents', function (Blueprint $table) {
            foreach (['local_growth_recommendation_state', 'local_growth_signal_scores', 'local_growth_intelligence'] as $column) {
                if (Schema::hasColumn('titan_reach_agents', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
