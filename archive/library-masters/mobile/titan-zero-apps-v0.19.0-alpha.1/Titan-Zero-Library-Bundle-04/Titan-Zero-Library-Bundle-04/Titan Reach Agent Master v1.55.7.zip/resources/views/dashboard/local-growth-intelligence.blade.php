@if (!empty($local_growth_signals))
    <div class="mb-6 rounded-3xl border border-blue-100 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/5">
        <div class="mb-4 flex items-start justify-between gap-4">
            <div>
                <h3 class="mb-1 text-lg font-semibold text-heading-foreground">
                    {{ __('Local Growth Intelligence') }}
                </h3>
                <p class="text-sm text-foreground/70">
                    {{ __('Signals are built only from configured services, service areas, goals, reviews, conversion hints and schedule context. No customer identity, exact address or unconfigured claim is inferred.') }}
                </p>
            </div>
            <span class="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700 dark:bg-blue-500/10 dark:text-blue-200">
                {{ __('Field service') }}
            </span>
        </div>

        <div class="grid gap-3 lg:grid-cols-3">
            @foreach (array_slice($local_growth_signals, 0, 6) as $signal)
                <div class="rounded-2xl border border-foreground/10 p-4">
                    <div class="mb-2 flex items-center justify-between gap-2">
                        <span class="text-xs font-semibold uppercase tracking-wide text-foreground/60">
                            {{ str_replace('_', ' ', $signal['type'] ?? 'signal') }}
                        </span>
                        <span class="rounded-full bg-foreground/5 px-2 py-1 text-[11px] font-semibold uppercase text-foreground/70">
                            {{ $signal['priority'] ?? 'medium' }}
                        </span>
                    </div>
                    <p class="mb-3 text-sm text-foreground/80">
                        {{ $signal['message'] ?? __('Use the latest local growth signal when planning content.') }}
                    </p>
                    @if (!empty($signal['recommended_post_type']))
                        <span class="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-200">
                            {{ __('Try: :type', ['type' => str_replace('_', ' ', $signal['recommended_post_type'])]) }}
                        </span>
                    @endif
                </div>
            @endforeach
        </div>
    </div>
@endif
