<div class="grid grid-cols-1 gap-6 lg:grid-cols-2">
    @include('titan-reach-agent::analytics.charts.published-posts', ['chartData' => $publishedChartData, 'months' => $publishedMonths])
    @include('titan-reach-agent::analytics.charts.engagement-rate', ['chartData' => $engagementChartData, 'months' => $engagementMonths])
    @include('titan-reach-agent::analytics.charts.impressions', ['chartData' => $impressionsChartData, 'months' => $impressionsMonths])
    @include('titan-reach-agent::analytics.charts.audience-growth', ['chartData' => $audienceChartData, 'months' => $audienceMonths])
</div>
