@php
    $theme = get_theme();
@endphp

@extends('panel.layout.app', ['disable_tblr' => true, 'disable_tblr' => true, 'layout_wide' => true])
@section('title', __('AI Agents'))
@section('titlebar_subtitle', __('Manage your AI-powered Titan Reach posting agents'))
@section('titlebar_actions')
    @include('titan-reach-agent::components.titlebar-actions')
@endsection

@push('after-body-open')
    <script>
        (() => {
            localStorage.setItem('lqdNavbarShrinked', true);
            document.body.classList.add("navbar-shrinked");
        })();
    </script>
@endpush

@section('content')
    <div @class(['px-5', 'py-5' => $theme !== 'titan-reach-agent-dashboard'])>
        @include('titan-reach-agent::agents.banner', ['determineAgentOfMonth' => $determineAgentOfMonth])
        @include('titan-reach-agent::agents.agents-grid', ['agents' => $agents, 'platforms' => $platforms])
    </div>
@endsection
