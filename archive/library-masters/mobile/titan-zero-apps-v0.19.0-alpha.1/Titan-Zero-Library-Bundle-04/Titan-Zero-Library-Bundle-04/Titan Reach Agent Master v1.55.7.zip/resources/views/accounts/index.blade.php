@php
    $theme = get_theme();
@endphp

@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Reach Accounts'))
@section('titlebar_subtitle', __('You can connect and manage multiple Titan Reach accounts from here.'))
@section('titlebar_actions')
    @include('titan-reach-agent::components.titlebar-actions')
@endsection

@section('content')
    <div @class(['px-5', 'py-5' => $theme !== 'titan-reach-agent-dashboard'])>
        @include('titan-reach-agent::accounts.banner')
        @include('titan-reach-agent::accounts.platform-cards', ['platforms' => $platforms])
        @include('titan-reach-agent::accounts.platforms-table', ['platforms' => $userPlatforms])
    </div>
@endsection
