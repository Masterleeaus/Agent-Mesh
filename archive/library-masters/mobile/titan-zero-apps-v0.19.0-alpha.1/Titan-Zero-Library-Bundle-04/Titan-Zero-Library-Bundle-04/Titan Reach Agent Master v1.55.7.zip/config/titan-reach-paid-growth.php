<?php

return [
    'role' => 'local_growth_agent',
    'mode' => 'recommendation',
    'activation_authority' => false,
    'automatic_spend' => false,
    'pro_binding' => 'titan-reach.paid-growth',
];
