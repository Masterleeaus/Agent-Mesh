<?php

return [
    'ai' => [
        // Optional backend-neutral model hints. Empty means the host intelligence
        // router selects its own appropriate model/backend.
        'analysis_model' => env('TITAN_REACH_ANALYSIS_MODEL'),
        'summary_model' => env('TITAN_REACH_SUMMARY_MODEL'),
        'content_model' => env('TITAN_REACH_CONTENT_MODEL'),
        'audience_model' => env('TITAN_REACH_AUDIENCE_MODEL'),
        'image_prompt_model' => env('TITAN_REACH_IMAGE_PROMPT_MODEL'),
    ],
];
