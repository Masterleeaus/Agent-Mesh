<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-agent',
    'module_slug' => 'local_growth_agent',
    'module_label' => 'Local Growth Agent',
    'route_names' => [
        'dashboard.user.titan-reach.agent.field-service-workspace',
        'dashboard.user.titan-reach.agent.index',
        'dashboard.user.titan-reach.agent.create',
        'dashboard.user.titan-reach.agent.agents',
        'dashboard.user.titan-reach.agent.posts',
        'dashboard.user.titan-reach.agent.analytics',
        'dashboard.user.titan-reach.agent.api.posts.generate-content'
    ],
    'view_paths' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/dashboard/index.blade.php',
        'resources/views/agents/index.blade.php',
        'resources/views/create/index.blade.php',
        'resources/views/posts/index.blade.php',
        'resources/views/analytics/index.blade.php'
    ],
    'controller_paths' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/TitanReachAgentController.php',
        'System/Http/Controllers/TitanReachAgentPostController.php',
        'System/Http/Controllers/TitanReachAgentAnalysisController.php'
    ],
    'safe_route_resolution' => true,
    'safe_blade_includes' => true,
    'missing_module_mode' => 'disabled_link',
    'fallback_url_mode' => 'url_path',
    'permission' => 'field_service_marketing.view',
    'company_scoped' => true,
];
