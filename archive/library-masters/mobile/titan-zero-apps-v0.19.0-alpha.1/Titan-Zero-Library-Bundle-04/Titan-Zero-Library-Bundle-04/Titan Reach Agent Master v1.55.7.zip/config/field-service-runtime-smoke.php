<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-agent',
    'module_slug' => 'local_growth_agent',
    'module_name' => 'Local Growth Agent',
    'version' => '1.54',
    'runtime_smoke_ready' => true,
    'route_names' => [
        'dashboard.user.titan-reach.agent.field-service-workspace',
        'dashboard.user.titan-reach.agent.index',
        'dashboard.user.titan-reach.agent.create',
        'dashboard.user.titan-reach.agent.agents',
        'dashboard.user.titan-reach.agent.posts',
        'dashboard.user.titan-reach.agent.analytics',
        'dashboard.user.titan-reach.agent.api.posts.generate-content'
    ],
    'route_prefixes' => [
        'dashboard/user/titan-reach/agent'
    ],
    'views' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/dashboard/index.blade.php',
        'resources/views/agents/index.blade.php',
        'resources/views/create/index.blade.php',
        'resources/views/posts/index.blade.php'
    ],
    'controllers' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/TitanReachAgentController.php',
        'System/Http/Controllers/TitanReachAgentPostController.php'
    ],
    'navigation_modules' => [
        'field_marketing_hub',
        'local_growth_agent',
        'lead_review_automation',
        'campaign_playbooks'
    ],
    'checks' => [
        'route_registration',
        'view_resolution',
        'controller_presence',
        'config_registration',
        'workspace_navigation',
        'permission_gate',
        'standalone_fallback'
    ]
];
