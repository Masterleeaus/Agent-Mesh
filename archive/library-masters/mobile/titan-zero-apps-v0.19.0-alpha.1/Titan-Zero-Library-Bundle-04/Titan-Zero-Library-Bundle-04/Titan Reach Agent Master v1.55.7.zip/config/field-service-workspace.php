<?php

declare(strict_types=1);

return ['workspace' => 'field_home_services_social_marketing', 'module' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'role' => 'Growth intelligence and content proposer', 'route' => 'dashboard.user.titan-reach.agent.field-service-workspace', 'permissions' => ['field_service_marketing.view', 'field_service_marketing.manage_context', 'field_service_marketing.create_content', 'field_service_marketing.manage_campaigns', 'field_service_marketing.manage_automations', 'field_service_marketing.view_leads', 'field_service_marketing.publish']];
