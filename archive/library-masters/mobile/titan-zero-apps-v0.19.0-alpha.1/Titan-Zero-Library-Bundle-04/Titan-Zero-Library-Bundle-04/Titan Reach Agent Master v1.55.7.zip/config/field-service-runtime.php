<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-agent',
    'module_slug' => 'local_growth_agent',
    'module_name' => 'Local Growth Agent',
    'version' => '1.54',
    'phase' => 'phase-2-runtime-commercialization',
    'step' => 17,
    'installer_runtime_trial' => [
        'enabled' => true,
        'requires_company_id' => true,
        'standalone_safe' => true,
        'fail_closed_public_surfaces' => true,
        'validate_manifest_before_install' => true,
        'validate_migrations_before_install' => true,
        'validate_views_before_install' => true,
        'validate_routes_before_install' => true,
    ],
    'health_checks' => [
        'manifest_json' => true,
        'service_provider_boot' => true,
        'route_registration' => true,
        'migration_discovery' => true,
        'view_discovery' => true,
        'config_registration' => true,
    ],
];
