<?php
namespace Titan\CrmMaster;

final class RevenueJourney
{
    private const STAGES=['lead','opportunity','quote','booking','job','invoice','payment','repeat_referral'];

    public function create(string $companyId,string $seedRef,array $provenance=[]): array
    {
        if(trim($companyId)==='') throw new \InvalidArgumentException('company_id-required');
        $id='rj_'.substr(hash('sha256',$companyId.'|'.$seedRef),0,32);
        $now=gmdate('c');
        return [
            'revenue_journey_id'=>$id,
            'company_id'=>$companyId,
            'current_stage'=>'lead',
            'entity_links'=>['lead'=>$seedRef],
            'event_revision'=>1,
            'created_at'=>$now,
            'updated_at'=>$now,
            'superseded_by'=>null,
            'provenance'=>$provenance
        ];
    }

    public function advance(array $journey,string $stage,string $entityRef): array
    {
        if(!in_array($stage,self::STAGES,true)) throw new \InvalidArgumentException('invalid-revenue-stage');
        $current=array_search($journey['current_stage'],self::STAGES,true);
        $next=array_search($stage,self::STAGES,true);
        if($current===false || $next===false) throw new \InvalidArgumentException('invalid-revenue-stage');
        if($next<$current) throw new \RuntimeException('non-monotonic-revenue-progression-forbidden');
        $journey['current_stage']=$stage;
        $journey['entity_links'][$stage]=$entityRef;
        $journey['event_revision']=(int)$journey['event_revision']+1;
        $journey['updated_at']=gmdate('c');
        return $journey;
    }

    public function event(array $journey,string $eventType,string $stage,string $entityRef,string $idempotencyKey,string $correlationId,?string $causationId=null,array $provenance=[]): array
    {
        if(trim($idempotencyKey)==='') throw new \InvalidArgumentException('idempotency-key-required');
        return [
            'event_id'=>'rje_'.substr(hash('sha256',$journey['company_id'].'|'.$journey['revenue_journey_id'].'|'.$idempotencyKey),0,32),
            'company_id'=>$journey['company_id'],
            'revenue_journey_id'=>$journey['revenue_journey_id'],
            'event_type'=>$eventType,
            'stage'=>$stage,
            'entity_ref'=>$entityRef,
            'idempotency_key'=>$idempotencyKey,
            'occurred_at'=>gmdate('c'),
            'causation_id'=>$causationId,
            'correlation_id'=>$correlationId,
            'provenance'=>$provenance
        ];
    }
}
