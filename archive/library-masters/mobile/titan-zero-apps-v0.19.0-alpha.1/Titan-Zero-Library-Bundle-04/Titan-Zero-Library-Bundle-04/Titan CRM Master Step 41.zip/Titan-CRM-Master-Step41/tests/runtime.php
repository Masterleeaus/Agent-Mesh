<?php
spl_autoload_register(function($class){
    $p='Titan\\CrmMaster\\';
    if(!str_starts_with($class,$p)) return;
    $f=dirname(__DIR__).'/runtime/'.substr($class,strlen($p)).'.php';
    if(is_file($f)) require $f;
});
use Titan\CrmMaster\CompanyContext;
use Titan\CrmMaster\RevenueJourney;
use Titan\CrmMaster\CanonicalCustomerRegistry;
use Titan\CrmMaster\CrmAuthorityGuard;
use Titan\CrmMaster\LegacyCrmMigrationAdapter;

$ctx=new CompanyContext();
if($ctx->canonical(['company_id'=>'c1'])!=='c1') throw new RuntimeException('company');
try{$ctx->canonical(['company_id'=>'c1','tenant_company_id'=>'legacy']);throw new RuntimeException('legacy accepted');}
catch(InvalidArgumentException $e){if($e->getMessage()!=='legacy-tenant-boundary-forbidden')throw $e;}
if($ctx->canonical(['tenant_company_id'=>'c1'],true)!=='c1') throw new RuntimeException('migration normalization');

$rj=new RevenueJourney();
$j=$rj->create('c1','lead1',[['source'=>'test']]);
$j=$rj->advance($j,'opportunity','opp1');
$j=$rj->advance($j,'quote','q1');
if($j['current_stage']!=='quote' || $j['event_revision']!==3) throw new RuntimeException('journey');
try{$rj->advance($j,'lead','lead1');throw new RuntimeException('backwards accepted');}
catch(RuntimeException $e){if($e->getMessage()!=='non-monotonic-revenue-progression-forbidden')throw $e;}
$ev=$rj->event($j,'quote.prepared','quote','q1','idem1','corr1');
if($ev['revenue_journey_id']!==$j['revenue_journey_id']) throw new RuntimeException('event');

$customers=new CanonicalCustomerRegistry();
$c=$customers->create('c1','cust1','Acme');
$link=$customers->linkExternal('c1','magicai_crm','legacy-company-9','cust1','rev1');
if($link['canonical_ref']!=='cust1') throw new RuntimeException('external link');
try{$customers->create('c1','cust1','Duplicate');throw new RuntimeException('duplicate customer accepted');}
catch(RuntimeException $e){if($e->getMessage()!=='duplicate-canonical-customer')throw $e;}

$guard=new CrmAuthorityGuard();
$good=$guard->validateWrite([
 'capability'=>'crm.lead.create','permission'=>'crm.lead.create','risk'=>'low',
 'confirmation_required'=>false,'idempotency_key'=>'i1','payload'=>[],'provider_grants_authority'=>false
],['company_id'=>'c1']);
if(!$good['valid']) throw new RuntimeException('write guard');
try{$guard->assertNoDualMaster(['customer'=>['master','master']]);throw new RuntimeException('dual master accepted');}
catch(RuntimeException $e){if(!str_starts_with($e->getMessage(),'dual-master-crm-forbidden'))throw $e;}

$legacy=(new LegacyCrmMigrationAdapter())->customer(['id'=>12,'name'=>'Legacy Co'],'c1','magicai_crm');
if($legacy['company_id']!=='c1' || $legacy['display_name']!=='Legacy Co') throw new RuntimeException('legacy migration');

echo "PASS company context\n";
echo "PASS controlled legacy tenancy normalization\n";
echo "PASS revenue journey progression\n";
echo "PASS revenue journey event correlation\n";
echo "PASS canonical customer uniqueness\n";
echo "PASS external CRM mapping\n";
echo "PASS governed write guard\n";
echo "PASS dual-master rejection\n";
echo "PASS legacy customer migration\n";
