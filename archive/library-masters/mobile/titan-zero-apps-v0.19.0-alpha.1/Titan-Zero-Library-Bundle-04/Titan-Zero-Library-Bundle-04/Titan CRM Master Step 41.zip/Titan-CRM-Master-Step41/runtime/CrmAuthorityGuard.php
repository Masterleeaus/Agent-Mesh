<?php
namespace Titan\CrmMaster;

final class CrmAuthorityGuard
{
    public function validateWrite(array $action,array $context): array
    {
        $errors=[];
        if(trim((string)($context['company_id']??''))==='') $errors[]='company_id-required';
        if(($action['provider_grants_authority']??false)!==false) $errors[]='provider-authority-forbidden';
        foreach(['capability','permission','risk','confirmation_required','idempotency_key','payload'] as $f) {
            if(!array_key_exists($f,$action)) $errors[]='missing:'.$f;
        }
        if(empty($action['idempotency_key']??null)) $errors[]='idempotency-key-required';
        return ['valid'=>$errors===[],'errors'=>$errors];
    }

    public function assertNoDualMaster(array $authorities): void
    {
        foreach($authorities as $entity=>$owners) {
            $masters=array_values(array_filter((array)$owners,fn($v)=>$v==='master'));
            if(count($masters)>1) throw new \RuntimeException('dual-master-crm-forbidden:'.$entity);
        }
    }
}
