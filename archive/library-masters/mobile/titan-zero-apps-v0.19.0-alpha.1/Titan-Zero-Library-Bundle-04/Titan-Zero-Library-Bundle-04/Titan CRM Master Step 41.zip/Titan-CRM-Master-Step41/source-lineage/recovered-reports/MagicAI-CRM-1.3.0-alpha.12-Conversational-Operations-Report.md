# MagicAI CRM 1.3.0-alpha.12 — Conversational Operations

## Release

- Version: `1.3.0-alpha.12`
- Base: CRM `1.3.0-alpha.11`
- Interaction Engine: `>=10.3.1 <11.0`
- Package: `MagicAI-CRM-1.3.0-alpha.12-Titan-Installer-Ready.zip`
- SHA-256: `8d4d22e6076a6b4a07cf611fe94aae83f11d42b86b20b20194ebbb8abb831be2`
- Diff from alpha.11: **45 files added, 21 modified, 0 removed**

## What alpha.12 adds

Alpha.11 made Interaction Engine the primary CRM creation experience. Alpha.12 extends that model to records that already exist, so Titan Zero can continue operating the business conversationally after creation.

### Context-aware record actions

Existing record pages now expose typed Interaction Engine actions for:

- customers
- contacts
- leads
- opportunities
- jobs
- quotes
- invoices
- purchase orders
- stock transfers
- tools
- fleet
- maintenance

Examples include:

- update customer/contact/lead
- convert a lead
- update/move/win/lose an opportunity
- update/assign/reschedule/cancel a job
- add job time
- accept or transition a quote
- transition an invoice
- record invoice payment
- submit/approve/cancel a purchase order
- dispatch/receive/cancel a stock transfer
- checkout/return/damage/lose a tool
- assign/unassign a vehicle
- update odometer/status
- complete/cancel maintenance

The current record public ID is carried into the action journey, so conversational phrases such as “reschedule this job” or “mark this vehicle serviced” are resolved against the page context.

## Governed capability adapters

New update/lifecycle capabilities reuse the existing CRM repositories and services:

- `crm.contact.update`
- `crm.lead.update`
- `crm.lead.convert`
- `crm.deal.update`
- `crm.deal.move`
- `crm.deal.win`
- `crm.deal.lose`
- `crm.quote.transition`
- `crm.invoice.transition`

No duplicate mutation subsystem was introduced.

## Real autonomous Interaction execution

Alpha.12 replaces the alpha.11 autonomous-execution placeholder.

For capabilities explicitly permitted by CRM's authority policy:

`validated Interaction session → CommandMapper → trusted _context/idempotency metadata → CommandBus → CRM governed capability`

AI still cannot mint or bypass approvals.

Approval-required actions return `approval_required` and remain human-approved.

Human-approved Interaction Engine execution was also hardened to attach the trusted `_context` and idempotency information CommandBus requires.

## Explicit multi-step business chains

Titan Zero now supports exactly five predefined business chains:

1. **Customer → Job**
2. **Job → Quote**
3. **Complete Job → Invoice**
4. **Purchase Order → Goods Receipt**
5. **Maintenance → Fleet Status**

The chain layer is deliberately not an unrestricted AI planner.

Only whitelisted CRM public IDs and workflow context are handed from one completed journey to the next. Tenant/user identity cannot be injected as wizard prefill.

## Preview-first conversational bulk operations

Titan Zero can preview controlled bulk work against an explicit selection of **1–100 records**.

Supported resources remain the existing CRM bulk-service matrix:

- leads
- opportunities/deals
- tasks
- contacts
- companies/customers

Supported actions remain:

- archive
- set status where supported
- set owner where supported

Preview:

- validates tenant ownership
- verifies the exact selected public IDs
- validates action arguments
- reports matched count
- reports proposed changes
- performs **no mutation**

Execution:

- requires `confirmed=true`
- revalidates the exact selection
- uses `CrmBulkActionService`
- writes through the existing tenant-scoped audited path

`CrmInteractionBulkPlanner` has no direct database-write path.

## TitanAI tools added

- `crm.interaction.chain.plan`
- `crm.interaction.chain.continue`
- `crm.interaction.bulk.preview`
- `crm.interaction.bulk.execute`

These sit alongside the alpha.11 Interaction tools for resolve/start/answer/execute.

## Safety boundaries retained

- CRM remains system of record.
- `tenant_company_id` remains tenancy.
- account/customer `company_id` is not tenancy.
- AI cannot use `ApprovalSigner`.
- chains are explicit templates, not open-ended planning.
- bulk operations require explicit record selection and confirmation.
- bulk planner does not write directly to the database.
- WorkCore runtime dependency: **none**.
- standalone Financial Engine runtime dependency: **none**.
- 17 deterministic Financial Assistants remain authoritative for money arithmetic.
- Titan Hub / Titan Go / Titan BOS integration is preserved.
- alpha.8 icon safety, alpha.9 route recovery, alpha.10 menu completeness and alpha.11 Interaction-first UI are preserved.

## Fresh installer certification

The exact downloadable ZIP was freshly extracted and certified.

- ZIP files: **641**
- PHP lint: **478 / 478 PASS**
- JSON/manifests/wizards: **97 / 97 PASS**
- migrations: **24**
- reversible migrations: **24 / 24**
- production integrity hashes: **639**
- exact inventory entries: **640**
- unsafe archive paths: **0**
- junk paths: **0**
- case collisions: **0**
- outer wrapper: **0**
- compressed ZIP test: **PASS**
- active WorkCore runtime references: **0**
- chain `ApprovalSigner` references: **0**
- bulk-planner direct DB writes: **0**

Regression gates:

- provider install-stage safety: **PASS**
- MySQL required-time compatibility: **PASS**
- MySQL identifier-length protection: **PASS**
- migration restartability/recovery: **PASS**
- Locker purchasing/stock control: **PASS**
- alpha.8 menu icon compatibility: **PASS**
- alpha.9 route-cache/menu-link recovery: **PASS**
- alpha.10 menu completeness: **PASS**
- all alpha.11 Interaction-first gates: **PASS**
- alpha.12 record actions: **PASS**
- alpha.12 action capability adapters: **PASS**
- alpha.12 contextual actions: **PASS**
- alpha.12 autonomous execution: **PASS**
- alpha.12 explicit chains: **PASS**
- alpha.12 bulk interactions: **PASS**
- Titan Mobile clean identities: **PASS**
- Financial Assistant deterministic kernel: **17 / 17 PASS**
- package integrity master verifier: **PASS**

## Runtime boundary

The package is statically and installer-contract certified. The remaining proof point is the live Titan Zero/MagicAI + Interaction Engine container, database and theme runtime. A live host error should be handled at its exact failing stage without manually deleting CRM business data.

## SHA-256

`8d4d22e6076a6b4a07cf611fe94aae83f11d42b86b20b20194ebbb8abb831be2`
