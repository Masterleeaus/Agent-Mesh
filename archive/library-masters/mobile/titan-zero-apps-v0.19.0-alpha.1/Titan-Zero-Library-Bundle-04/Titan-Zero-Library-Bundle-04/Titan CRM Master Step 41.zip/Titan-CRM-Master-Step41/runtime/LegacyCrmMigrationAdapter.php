<?php
namespace Titan\CrmMaster;

final class LegacyCrmMigrationAdapter
{
    public function customer(array $legacy,string $canonicalCompanyId,string $sourceSystem): array
    {
        if(trim($canonicalCompanyId)==='') throw new \InvalidArgumentException('company_id-required');
        $externalId=(string)($legacy['id']??$legacy['uuid']??'');
        if($externalId==='') throw new \InvalidArgumentException('legacy-record-id-required');

        return [
            'customer_id'=>'cust_'.substr(hash('sha256',$canonicalCompanyId.'|'.$sourceSystem.'|'.$externalId),0,32),
            'company_id'=>$canonicalCompanyId,
            'customer_type'=>($legacy['type']??'organisation')==='individual'?'individual':'organisation',
            'display_name'=>(string)($legacy['name']??$legacy['display_name']??'Imported customer'),
            'status'=>'active',
            'version'=>1,
            'provenance'=>[['source_system'=>$sourceSystem,'external_id'=>$externalId]],
            'legacy_external_links'=>[['source_system'=>$sourceSystem,'external_id'=>$externalId]]
        ];
    }
}
