<?php
namespace Titan\CrmMaster;

final class CompanyContext
{
    private const LEGACY=['tenant_company_id','tenant_id','organisation_id','organization_id','account_id','business_id'];

    public function canonical(array $context,bool $migrationMode=false): string
    {
        $companyId=trim((string)($context['company_id']??''));
        if($companyId!=='') {
            foreach(self::LEGACY as $legacy) {
                if(array_key_exists($legacy,$context) && !$migrationMode) {
                    throw new \InvalidArgumentException('legacy-tenant-boundary-forbidden');
                }
            }
            return $companyId;
        }

        if($migrationMode) {
            foreach(self::LEGACY as $legacy) {
                $v=trim((string)($context[$legacy]??''));
                if($v!=='') return $v;
            }
        }

        throw new \InvalidArgumentException('company_id-required');
    }
}
