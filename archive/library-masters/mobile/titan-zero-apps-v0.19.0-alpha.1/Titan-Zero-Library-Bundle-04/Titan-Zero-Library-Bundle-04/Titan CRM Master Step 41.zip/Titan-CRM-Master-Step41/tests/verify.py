from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
a=json.loads((r/'policies/crm-authority.json').read_text())
assert a['company_boundary']=='company_id'
assert a['authority_rules']['one_customer_truth'] is True
assert a['authority_rules']['one_revenue_journey_truth'] is True
assert a['authority_rules']['dual_master_crm_forbidden'] is True
assert a['revenue_journey']['id']=='revenue_journey_id'
assert a['revenue_journey']['stages']==['lead','opportunity','quote','booking','job','invoice','payment','repeat_referral']
c=json.loads((r/'mappings/compatibility-adapters.json').read_text())
assert c['tenant_boundary']['canonical']=='company_id'
assert 'tenant_company_id' in c['tenant_boundary']['legacy_inputs']
for p in (r/'contracts').glob('*.json'): json.loads(p.read_text())
reports=list((r/'source-lineage/recovered-reports').glob('*.md'))
assert len(reports)>=5
print('PASS single CRM authority')
print('PASS company_id-only tenancy')
print('PASS canonical customer truth')
print('PASS durable revenue_journey_id')
print('PASS dual-master prohibition')
print('PASS legacy CRM compatibility normalization')
print('PASS recovered CRM lineage evidence')
