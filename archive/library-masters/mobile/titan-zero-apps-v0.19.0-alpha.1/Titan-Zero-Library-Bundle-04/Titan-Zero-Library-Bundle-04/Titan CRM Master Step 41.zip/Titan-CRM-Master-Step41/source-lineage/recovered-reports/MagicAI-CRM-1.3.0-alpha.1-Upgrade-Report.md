# MagicAI CRM 1.3.0-alpha.1 — Upgrade Report

## Release

- **Package:** `MagicAI-CRM-1.3.0-alpha.1-Titan-Installer-Ready.zip`
- **Base:** MagicAI CRM 1.2.2 Titan Installer Ready
- **Release type:** CRM 1.3 Phase 1 alpha
- **SHA-256:** `3f232da20c22cf8a810b30db68c7c466a9eef4d2b023514ef9b5e3b2a8c24ad4`
- **ZIP bytes:** 548,762
- **Archive files:** 403
- **Package structure:** flat Titan extension root; no outer `Crm/` wrapper

## Architectural decision implemented

Titan Pay and Titan Locker are now implemented as **internal CRM domain families**, not separate installable extensions.

CRM remains the authoritative shared business graph for:
- Titan business tenancy through `tenant_company_id`
- customers/contacts
- work orders/jobs
- customer assets and job materials
- products/services
- estimates/invoices
- payments and allocations

CRM `company_id` / customer-company identifiers remain customer/account relationships and are not repurposed as tenancy.

## Phase 1 implemented

### Simple Bookkeeping

- tenant-scoped income/expense categories
- manual income and expense records
- GST-inclusive / GST-exclusive / GST-free calculations
- Australian 10% GST default
- GST-exclusive cash-basis P&L
- GST-inclusive cash movement reporting
- GST collected / GST paid / net GST
- CRM payment allocations recognized as authoritative sales receipts
- completed Pay refunds reduce revenue/GST correctly
- July–June Australian financial-year helper
- manual/source-linked idempotency support

### Titan Pay

- payment-rail preferences and ordering
- Cash, PayID, bank transfer and card rail foundations
- invoice-bound payment intents
- secure payment-link token storage using SHA-256 hashes; raw token returned only at creation
- Titan Collect cases/events
- promise-to-pay fields
- accounts-receivable aging buckets
- job billing service that projects CRM work-order services and Locker materials into draft invoices
- schema foundations for deposits
- schema foundations for payment plans/installments
- schema foundations for refunds and disputes
- schema foundations for receipts

Existing CRM invoices, payments and payment allocations remain authoritative.

### Titan Locker

- inventory and consumables
- parts/materials/products item types
- SKU, barcode and QR metadata
- cost and sale prices
- costing-method metadata
- warehouse, van, site and worker/technician stock locations
- stock receipt
- stock adjustment
- stock transfer
- stock consumption
- stock disposal
- immutable movement ledger
- negative-stock protection
- item-level DB locking around negative stock operations
- job consumption linked to existing CRM work orders and work-order materials
- suppliers
- stock-allocation schema
- reorder-rule schema
- tools
- equipment
- fleet vehicles
- maintenance schedules/history
- asset lifecycle events
- acquisition/current-value metadata
- warranty/registration/service dates
- depreciation metadata foundations

## Cross-domain job financial loop

Implemented foundation:

`Titan Go job → Locker stock consumption → CRM work-order material → Pay draft invoice → CRM payment/allocation → Bookkeeping/reporting`

Job billing source keys prevent the same service/material from being projected to the invoice twice. Locker caller-provided idempotency keys prevent duplicate field mutations without collapsing legitimate repeated consumptions.

## New persistence

Four additive migrations were added: `000015` through `000018`.

They create **24 new company-tenant-scoped tables** across Bookkeeping, Pay and Locker, then add guarded cross-domain columns to existing work-order materials, invoices, sales-document lines and products.

All 18 CRM migrations have reversible `down()` methods.

## Capability and UI/API integration

- **24 new governed capabilities** declared and bound through the existing CRM capability registry.
- New focused permission families for Bookkeeping, Pay and Locker.
- New owner/manager CRM pages:
  - Bookkeeping
  - Titan Pay
  - Titan Locker
- New internal API routes for Bookkeeping, Pay and Locker operations.
- New domain provider: `CrmFinanceLockerServiceProvider`.
- TitanAI / Command-style callers can use the same company-scoped governed capability layer rather than bypassing CRM authorization.

## MySQL/Titan installer hardening

The CRM 1.2.2 MySQL fix remains active.

Additional 1.3 safeguards:
- all newly created business tables use `tenant_company_id`
- new table creation is guarded for restart safety
- cross-domain alterations check table/column existence
- no new required implicit-default `TIMESTAMP` columns
- indexed `source_key` columns reduced to 160 characters for safer MySQL/MariaDB index compatibility
- stock deductions serialize by inventory item before checking availability
- Locker asset API validates per-asset payloads before service execution

## Fresh package verification

The final ZIP was extracted into a new directory and verified from the extracted bytes.

- Titan installer/integrity verifier: **PASS**
- required-time MySQL compatibility: **PASS**
- migration 000008 restartability: **PASS**
- CRM 1.3 domain contract: **PASS**
- GST calculator: **PASS**
- P&L/cash/GST summary calculator: **PASS**
- CRM 1.3 migration safety: **PASS**
- capability declaration/binding parity: **PASS — 24/24**
- PHP lint: **348/348 PASS**
- JSON parse: **17/17 PASS**
- migrations: **18 total / 18 reversible**
- archive unsafe paths: **0**
- archive junk paths: **0**
- archive case collisions: **0**
- outer `Crm/` wrapper: **0**
- compressed ZIP data integrity: **PASS**
- active WorkCore / `tz_*` runtime-reference files: **0**

## Diff from CRM 1.2.2

- **35 files added**
- **15 files modified**
- **0 files removed**

## Intentionally remaining for later CRM 1.3 slices

The following are not claimed complete in alpha.1:
- live ZeroPay provider orchestration
- public Titan Hub checkout/payment completion flow
- automatic deposit application
- payment-plan collection engine
- full refund/dispute provider workflows
- receipt generation/delivery workflow
- Locker allocation/reservation service
- purchasing/reorder suggestion workflow
- tool checkout/return/custody workflow
- detailed fleet assignment workflows
- authoritative FIFO/LIFO/weighted-average cost-layer engine
- depreciation calculation/posting engine
- full bookkeeping attachments/receipt capture UI

These remain inside CRM architecture; they are not planned as separate Pay/Locker extensions.

## Runtime note

This package has been source-, migration-, integrity- and archive-certified. It has **not** been executed against the live `titanzero.io` MySQL/Laravel host from this environment. Installing the alpha package on the host is the live runtime/migration confirmation step.
