---
title: "WorkCore Business Network and MagicAI 11 — Combined Integration Deep Scan"
scan_number: 21
date: "2026-08-09"
status: "Completed"
magicai_source: "MagicAI 11.00 supplied server package"
workcore_repository: "Masterleeaus/workcore-extensions"
workcore_ref: "main"
workcore_commit: "64d05e1a7a1071bf61c1f252d359fbd712da39f5"
repository_target: "Masterleeaus/Documents"
repository_path: "workcore/magicai-integration/21-workcore-business-network-and-magicai-integration-deep-scan.md"
supersedes_workcore_ref: "e56389a87db869915a96b7adca1bb12237895d50"
---

# Scan 21 — WorkCore Business Network + MagicAI 11 Integration

## Executive conclusion

`WorkCoreBusinessNetwork` is now the correct front-office business-data authority for Titan Zero inside MagicAI.

At current WorkCore `main` commit:

```text
64d05e1a7a1071bf61c1f252d359fbd712da39f5
```

the Business Network add-on activates ten parent-owned runtime modules:

```text
crm
catalogue
support
knowledge
reviews
territories
intelligence
expansion
wizards
ai
```

The canonical Business Network package contains **448 tracked files**.

The integration direction is now explicit in the WorkCore repository:

> WorkCore replaces MagicAI CRM and Sales operational record authority.  
> MagicAI remains the host for authentication, SaaS subscriptions, AI providers, AI Chat, AI Agents, Marketplace, themes and platform administration.

This is stronger and clearer than the provisional bridge architecture in the earlier MagicAI-only CRM scans.

After cutover:

```text
MagicAI CRM/Sales
    → migration source / legacy read-only system
    → not a permanent second authority

WorkCore Business Network
    → customers
    → contacts
    → leads
    → opportunities
    → pipelines
    → CRM activities
    → support
    → knowledge
    → reviews
    → territories

WorkCore Commercial
    → quotes
    → invoices
    → payments
    → receivables

MagicAI
    → authentication
    → SaaS plans
    → AI provider execution
    → AI Chat / AI Agent UX
    → Marketplace and theme shell
```

## Major result from repository evolution

Between Scan 20 and this scan, WorkCore `main` advanced from:

```text
e56389a87db869915a96b7adca1bb12237895d50
```

to:

```text
64d05e1a7a1071bf61c1f252d359fbd712da39f5
```

through merged PR #4:

```text
Harden WorkCore CRM replacement foundation
```

That merge resolves several blockers recorded in Scans 13, 18 and 20:

- Invalid `WorkCoreAccessLevel::Manage` → fixed to `All`
- Native MagicAI API auth → now defaults to `auth:api`
- Arbitrary confirmation strings → replaced by signed, payload-bound, expiring one-time grants
- Confirmation consumption → moved inside the business transaction
- Missing-tenant reads → hardened to fail closed
- Company entitlement projection → implemented
- MagicAI plan feature flags → implemented
- Entitlement refresh and revisioning → implemented
- Native WorkCore navigation/workspace shell → implemented
- WorkCore AI module reachability → Business Network explicitly loads `ai`

Those prior documents require revision and are being updated alongside this scan.

---

# 1. Native extension identity

```text
Folder:
WorkCoreBusinessNetwork

Manifest key:
workcore-business-network

MagicAI provider-map key:
workcore_business_network

Provider:
App\Extensions\WorkCoreBusinessNetwork\System\WorkCoreBusinessNetworkServiceProvider

Version:
0.1.1

Parent:
WorkCore ^0.1
```

Compatibility:

```text
MagicAI >= 11.0
Laravel ^10.0
PHP ^8.2
```

The add-on:

- owns activation
- owns no migrations
- owns no operational tables directly
- retains data on disable/uninstall
- requires the parent WorkCore runtime

---

# 2. Activated capabilities

The Business Network manifest exposes:

```text
workcore.crm
workcore.catalogue
workcore.support
workcore.knowledge
workcore.reviews
workcore.territories
workcore.intelligence
workcore.expansion
workcore.wizards
workcore.ai
```

The provider loads exactly the matching runtime module keys.

This package is therefore broader than a CRM replacement.

It is the front-office, knowledge and intelligence layer for Titan Zero.

---

# 3. Package transparency limitation

The add-on manifest declares:

```text
permissions: []
routes: []
queues.used: false
schedules: []
webhooks: []
external_hosts: []
database migrations: false
owned tables: []
```

That accurately describes the tiny add-on wrapper but **not the effective runtime it activates**.

The ten loaded modules contribute:

- many permissions
- API and web routes
- business actions
- read models
- AI tools
- scheduled/reconciliation behaviour through the parent
- database use
- potentially provider integrations

## Required improvement

Generate transitive/effective manifest fields:

```text
effective_capabilities
effective_permissions
effective_routes
effective_actions
effective_read_models
effective_ai_tools
effective_tables
effective_schedules
effective_queues
effective_external_hosts
```

Marketplace preflight and security review should evaluate the effective runtime, not only the activation wrapper.

---

# 4. CRM is now the WorkCore authority

The current WorkCore upgrade plan explicitly states:

```text
WorkCore is the only CRM authority after cutover.
MagicAI CRM and Sales must not remain parallel record owners.
Existing MagicAI CRM data is imported once.
Permanent two-way synchronization is prohibited.
```

This supersedes Scan 09's earlier provisional "MagicAI CRM bridge mode" as the preferred final state.

## Final CRM authority

```text
MagicAI user
    = platform account/login identity

WorkCore Company
    = operating tenant business

WorkCore Customer
    = customer organisation or individual

WorkCore Contact
    = person associated with a customer/prospect

WorkCore Lead
    = unconverted prospect

WorkCore Opportunity
    = qualified commercial opportunity
```

A MagicAI CRM Company migrates to:

```text
WorkCore Customer
```

never:

```text
WorkCore Company
```

---

# 5. CRM governed write surface

`WorkCRMServiceProvider` registers **13 governed business actions**:

```text
workcore.customer.create
workcore.contact.create
workcore.contact.set_primary
workcore.lead.create
workcore.lead.update
workcore.lead.convert
workcore.sales_pipeline.create
workcore.opportunity.create
workcore.opportunity.update
workcore.opportunity.move
workcore.opportunity.mark_won
workcore.opportunity.mark_lost
workcore.crm_activity.create
```

Each action declares:

```text
risk
confirmation requirement
capability
permission
handler
```

This is the correct integration surface for:

- MagicAI UI
- MagicAI AI Agent
- Chatbot capture
- channel automation
- migration/import
- WorkCore wizards

No external integration should update CRM tables directly.

---

# 6. CRM read surface

The CRM provider registers **7 read models**:

```text
workcore.customer.search
workcore.lead.search
workcore.sales_pipeline.list
workcore.sales_pipeline.board
workcore.opportunity.search
workcore.crm.forecast
workcore.crm_activity.list
```

This creates a stable tenant-aware query boundary.

MagicAI dashboard widgets and AI context should consume these read models instead of querying WorkCore Eloquent models directly.

---

# 7. CRM API

The CRM module contains routes for:

- customers
- contacts
- leads
- lead options
- lead conversion
- sales pipelines
- pipeline boards
- forecast
- opportunities
- opportunity stage movement
- won/lost closure
- CRM activities

The current route file contains **22 route declarations**.

The routes are loaded only when:

```text
workcore.crm.routes_enabled = true
```

## MagicAI authentication rule

PR #4 hardened the native MagicAI package to use Passport-compatible:

```text
auth:api
```

for the native parent API profile.

Any module-specific middleware profile must be tested in the real MagicAI fixture to ensure it does not independently retain `auth:sanctum`.

The final requirement remains:

```text
api
auth:api
workcore.tenant
workcore.api
```

for authenticated WorkCore API endpoints inside MagicAI.

---

# 8. CRM parity still incomplete

The current repository's own upgrade plan lists remaining CRM parity work.

## Customers and contacts still need product completion for

- individual vs organisation customers
- contact roles
- communication preferences
- tags
- segments
- richer status/lifecycle
- files
- duplicate merge
- retention
- anonymisation

## Leads still need

- qualification score
- richer source attribution
- ownership/territory workflow
- complete status history
- follow-up automation
- robust duplicate handling
- conversion rollback policy

## Opportunities still need

- stale detection
- richer won/lost reason taxonomy
- opportunity-to-quote
- opportunity-to-work-order conversion
- complete commercial snapshot linkage

The underlying governed core is real, but "CRM replacement complete" is not yet justified.

---

# 9. CRM AI tool surface

`CRMToolRegistry` exposes **12 AI tools**.

## Reads

```text
crm_search_customers
crm_search_leads
crm_list_sales_pipelines
crm_view_pipeline_board
crm_search_opportunities
crm_get_forecast
crm_list_activities
```

## Writes

```text
crm_create_customer
crm_create_lead
crm_create_opportunity
crm_move_opportunity
crm_record_activity
```

## Deliberately not exposed directly to AI

The registry does not expose:

```text
lead conversion
contact creation
set primary contact
pipeline creation
opportunity update
mark opportunity won
mark opportunity lost
```

This is a sensible conservative boundary.

Higher-consequence transitions remain available as governed actions for deliberate UI/API workflows without automatically becoming agent tools.

---

# 10. MagicAI CRM Assistant replacement

MagicAI core contains a CRM Assistant host contract, but the paid CRM implementation is absent from the supplied MagicAI package.

The final architecture should not connect the MagicAI CRM Assistant to a second CRM datastore.

Recommended route:

```text
MagicAI AI Chat / AI Agent UI
→ WorkCore tool catalogue
→ CRMToolRegistry
→ WorkCore read model or governed action
→ WorkCore result
→ MagicAI renders the response
```

## Do not retain

```text
CrmAssistantChatService
→ direct paid CRM record access
```

as an operational authority after cutover.

The MagicAI assistant label/UX can remain, but its data and actions should be WorkCore-backed.

---

# 11. Catalogue module

`WorkCatalogueServiceProvider` registers:

## Governed writes

```text
workcore.service_category.create
workcore.service.create
workcore.job_template.create
```

## Read models

```text
workcore.service.search
workcore.service_variant.list
workcore.service_faq.list
```

The Catalogue AI registry exposes **3 read-only tools**:

```text
catalogue_search_services
catalogue_list_service_variants
catalogue_list_service_faqs
```

No Catalogue creation action is exposed as an AI tool.

This is a good initial policy.

## MagicAI integration

WorkCore Catalogue should power:

- quotes
- job templates
- booking/service selection
- chatbot service answers
- AI proposal scope
- website/landing-page product/service context

MagicAI should not create another operational service catalogue.

---

# 12. Support module

The Support module registers governed actions for:

```text
support queue create
ticket create
ticket message add
ticket assign
ticket status change
ticket → work order conversion
```

It registers:

```text
workcore.support_ticket.search
```

as its read model.

## AI tools

Support exposes:

```text
support_search_tickets
support_create_ticket
support_add_message
support_assign_ticket
support_change_status
```

It deliberately does **not** expose:

```text
support_ticket.convert_to_work_order
```

to AI.

That is appropriate because converting a support issue into operational work can create labour, scheduling and commercial consequences.

## MagicAI integration

MagicAI channels can become intake/delivery surfaces:

```text
email
chatbot
WhatsApp
Messenger
Telegram
voice
```

but WorkCore should own:

```text
ticket
status
assignment
customer linkage
conversion to work
audit
```

---

# 13. Knowledge Base module

The Knowledge module registers governed actions for:

```text
category create
article create
article update
article publication status
article from support ticket
feedback record
```

Read model:

```text
workcore.knowledge.article.search
```

AI tools:

```text
knowledge_search_articles
knowledge_create_article
knowledge_update_article
knowledge_change_article_status
```

## Important governance point

AI can draft and update knowledge, but publication remains a governed WorkCore state transition.

MagicAI AI Chat may present article suggestions, but article authority stays in WorkCore.

---

# 14. Reviews and retention lifecycle

The Reviews module registers governed actions for:

```text
review request
review record
review publish
service recovery
rebooking request
```

Read model:

```text
workcore.review.search
```

Its AI tool registry is currently empty.

That is a conservative default.

## Confirmed current defect

`EloquentReviewRepository::refs()` still resolves contacts using:

```text
tz_contacts
```

The WorkCore CRM contact table is:

```text
tz_customer_contacts
```

Therefore review workflows containing `contact_public_id` remain broken.

## Required fix

Replace:

```text
tz_contacts
```

with:

```text
tz_customer_contacts
```

and add a cross-module schema-contract test.

---

# 15. Territories

The Territories module supports:

## Writes

```text
region create
district create
branch create
territory create
territory assign
```

## Reads

```text
territory search
territory match
```

It includes:

```text
GeoJSON polygon handling
centroid calculation
point-in-polygon matching
```

Its AI registry currently exposes no tools.

## MagicAI integration

Territories should provide operational geography for:

- lead assignment
- service eligibility
- dispatch
- branch selection
- field teams
- quoting/travel rules

MagicAI Maps or external maps should remain visualization/geocoding adapters, not territory authority.

---

# 16. Intelligence

Business Network activates a substantial intelligence kernel.

Confirmed services include:

- secret scanning
- Australian identifier detection
- content safety
- strict proposal schema validation
- evidence chain
- observation/recommendation persistence
- knowledge ingestion
- chunking
- lexical relevance
- reciprocal-rank fusion
- freshness policy
- retention policy
- domain intelligence context
- domain-specific metric adapters

Domain adapters exist for:

```text
CRM
Operations
Finance
Workforce
Premises/assets
Compliance/quality
Supply
```

## Architecture rule

Intelligence produces:

```text
evidence
observations
recommendations
bounded proposals
```

It does not become a raw database-write bypass.

---

# 17. Expansion

The Expansion module supports:

- capability gap analysis
- adaptive domains
- adaptive features
- adaptive records
- compatibility validation
- simulation
- versioning
- rollback
- kill switch
- reviewed native-module specifications

The root WorkCore capability metadata explicitly describes runtime code generation as disabled.

## Safety model

Expansion can activate only bounded declarative structures and approved action steps.

High-risk activation and rollback actions require governed confirmation.

Default model gateway is null until deliberately wired.

This should remain separate from MagicAI's general code-generation ability.

---

# 18. Wizards

The Wizards module registers **8 governed writes**:

```text
wizard definition create
wizard definition publish
wizard run start
wizard answer save
wizard section approve
wizard run pause
wizard run resume
wizard run complete
```

and **3 read models**:

```text
wizard list
wizard run
wizard next question
```

The AI registry exposes only:

```text
list definitions
get run
get next question
start run
save answer
```

It does not expose:

```text
publish
section approval
complete
```

directly to AI.

This is an appropriate human-governance boundary for onboarding/setup workflows.

---

# 19. Native AI module is now reachable

Scan 13 reported that the WorkCore AI module was defined but never loaded.

That finding is superseded on current `main`.

`WorkCoreBusinessNetworkServiceProvider` explicitly loads:

```text
ai
```

The AI provider now binds:

- model profiles
- provider profiles
- tool catalogue
- rate limits
- budget guard
- circuit breaker
- conversations
- memory
- approvals
- agent profiles
- orchestration runs
- tool runs
- agent orchestrator

## Remaining AI blockers

The current AI path is still not ready to replace MagicAI's provider runtime.

### Credentials

Default:

```text
NullCredentialResolver
```

No production MagicAI/Titan Vault credential adapter is bound.

### Provider breadth

WorkCore native model runtime remains primarily OpenAI-compatible/local.

MagicAI already owns a much broader provider and model catalogue.

### Dedicated AI route authentication

`workcore_ai.orchestration.middleware` still defaults to:

```text
api
auth
workcore.tenant
workcore.api
```

not:

```text
auth:api
```

The parent native middleware override does not automatically prove this separately configured AI route group is Passport-safe.

### Recommended final model

```text
WorkCore:
policy + company + tools + approval + memory + audit

MagicAI:
provider/model execution

Bridge:
MagicAIEntityProvider
```

---

# 20. AI tool registry activation problem

`workcore_ai.php` references tool registries across all WorkCore add-ons.

Business Network can be installed without:

```text
Commercial
Work Operations
Property Operations
Workforce Assurance
```

Yet its AI configuration names registries for those packages.

## Required rule

`NativeToolCatalogue` must load registries only when:

```text
class exists
module is loaded
capability is registered
company is entitled
actor is permitted
```

A missing optional package must never break Business Network AI boot.

---

# 21. Signed confirmation security is now implemented

PR #4 replaced the old arbitrary confirmation string.

Native WorkCore now:

- signs confirmation grants
- binds company
- binds actor
- binds action
- binds payload hash
- binds idempotency key
- applies expiry
- stores one-time nonce
- verifies before transaction
- consumes nonce inside the action transaction
- disables legacy plain human tokens for the native MagicAI package

This resolves the corresponding P0 finding from Scan 20.

## Remaining policy work

Still define:

- separation of duties
- who may approve which risk levels
- approval UI in MagicAI
- device/MFA assurance for critical actions
- executor identity for resumed AI approvals

---

# 22. Permission P0 is fixed

Current native permission resolver maps:

```text
owner/admin → WorkCoreAccessLevel::All
```

instead of the nonexistent:

```text
Manage
```

This resolves Scan 20's permission-runtime blocker.

Operational-role semantics still require full end-to-end tests.

---

# 23. Fail-closed tenancy is hardened

Current repository baseline states tenant-owned Eloquent reads now fail closed without active tenant context.

PR #4 also added an explicitly scoped, audited privileged cross-company execution context for genuine platform administration/migration work.

This is the correct architecture.

Do not restore generic:

```text
withoutGlobalScope
```

escape paths.

---

# 24. Native MagicAI plan entitlements

The parent now adds seven feature flags to MagicAI plans:

```text
ext_workcore_core
ext_workcore_operations
ext_workcore_workforce
ext_workcore_resources
ext_workcore_commercial
ext_workcore_offline
ext_workcore_ai_actions
```

All default to:

```text
false
```

This is a safe migration default.

## Business Network plan mapping

`ext_workcore_core` grants:

```text
workcore.crm
workcore.catalogue
workcore.support
workcore.knowledge
workcore.reviews
workcore.territories
```

`ext_workcore_ai_actions` grants:

```text
workcore.ai
workcore.intelligence
workcore.wizards
workcore.expansion
```

This cleanly separates ordinary front-office functions from AI/action-heavy capabilities.

---

# 25. Critical MagicAI subscription-schema mismatch

The current WorkCore native configuration defaults to:

```text
subscriptions table: subscriptions
status column: status
valid from column: starts_at
valid until column: ends_at
```

The supplied MagicAI 11 migration actually defines:

```text
user_id
plan_id
name
stripe_id
stripe_status
stripe_price
quantity
trial_ends_at
ends_at
created_at
updated_at
```

It does **not** define:

```text
status
starts_at
```

`MagicAIEffectiveSubscriptionResolver` uses the configured status column directly in:

```text
whereIn(status column, active statuses)
```

and reads the configured validity columns.

## Consequence

With default configuration against the supplied MagicAI 11 schema, entitlement reconciliation can issue SQL against nonexistent columns.

That can prevent:

- WorkCore capability projection
- menu visibility
- route capability checks
- governed actions
- AI tool availability

## Severity

**Critical host-integration blocker**

## Required correction

The native MagicAI profile must ship correct defaults for the actual MagicAI version.

At minimum:

```text
WORKCORE_MAGICAI_SUBSCRIPTION_STATUS_COLUMN=stripe_status
```

For valid-from:

- use a real MagicAI column, or
- make valid-from explicitly nullable/optional instead of pretending `starts_at` exists.

Add a real MagicAI subscription-schema fixture test.

---

# 26. Subscription ownership model limitation

The resolver determines a WorkCore company's subscription from:

```text
tz_companies.owner_user_id
→ MagicAI subscriptions.user_id
```

This is a workable first projection but assumes:

```text
company entitlement = owner's platform subscription
```

It requires product rules for:

- ownership transfer
- team billing
- account manager billing
- reseller billing
- one owner controlling several operating companies
- one subscription covering multiple companies
- suspended company with active owner subscription

The entitlement projection should eventually use an explicit billing-account link rather than owner identity alone.

---

# 27. Entitlement reconciliation

Current parent runtime includes:

```text
EffectiveSubscriptionSnapshot
MagicAIEffectiveSubscriptionResolver
WorkCorePlanEntitlementAdapter
ProjectedCompanyEntitlementResolver
CompanyEntitlementRefreshService
workcore:refresh-entitlements
```

Scheduled reconciliation can run every five minutes by default and uses:

```text
withoutOverlapping
onOneServer
```

This is substantially stronger than the earlier host-only plan integration.

## Remaining integration requirement

MagicAI's boot-time queue/scheduler anti-patterns from earlier scans must still be removed.

Entitlement reconciliation assumes the Laravel scheduler is operated normally.

---

# 28. Native MagicAI WorkCore navigation

The parent now defines five stable workspaces:

```text
CRM
Operations
Workforce
Resources
Commercial
```

## Business Network surfaces

### CRM

```text
Customers
Contacts
Leads
Pipelines
Opportunities
Activities
CRM Reports
```

### Resources contribution

```text
Knowledge Base
```

### Operations contribution

```text
Map and Territories
```

### Commercial contribution

```text
Service Catalogue
```

This replaces the earlier assumption that WorkCore still needed an initial menu adapter.

---

# 29. MagicAI menu synchronization

`MagicAIMenuSynchronizer` now:

1. Reads WorkCore workspace definitions.
2. Upserts WorkCore roots and child menu items into MagicAI's `menus`.
3. Preserves administrator-controlled existing order and enabled state.
4. Updates WorkCore-owned route/label/icon metadata.
5. Disables retired WorkCore menu keys.
6. Calls MagicAI `MenuService::regenerate()` when available.

This directly solves the old `firstOrCreate` menu-upgrade weakness for WorkCore-owned menu definitions.

## Remaining cache requirement

MagicAI's global menu caching still needs WorkCore company and entitlement revision in the effective cache key or reliable invalidation on company/entitlement switch.

---

# 30. Entitlement-aware workspace routing

Native WorkCore routes use:

```text
web
auth
workcore.tenant
workcore.workspace-capability
```

Each workspace/section declares required WorkCore capabilities.

`WorkCoreWorkspaceManifest` shows only sections where:

```text
capability registered
AND
company entitlement allows capability
```

It exposes:

```text
company ID
entitlement revision
visible workspaces
visible sections
```

This is the correct server-side navigation gate.

---

# 31. Workspace UI is still a structural shell

The current Blade workspace displays:

```text
title
description
navigation
company context
capability labels
"foundation ready" notice
```

It does not yet implement functional:

- customer table
- contact table
- lead table
- pipeline Kanban
- opportunity details
- activity timeline
- forms
- filters
- bulk actions
- CRM reports

## Conclusion

```text
navigation: implemented
route gating: implemented
entitlement visibility: implemented
functional CRM workspace UI: incomplete
```

The repo's older baseline saying "navigation incomplete" is therefore stale; the accurate statement is that **workspace product surfaces are incomplete**.

---

# 32. MagicAI legacy CRM menu cutover

MagicAI core currently defines legacy CRM and Sales roots such as:

```text
ext_crm_dropdown
crm_contacts
crm_companies
crm_deals
crm_projects
crm_tasks
crm_calendar
crm_reports

ext_sales_dropdown
crm_sales_invoices
crm_sales_payments
crm_sales_proposals
crm_sales_estimates
```

After WorkCore replacement:

1. Install WorkCore menus.
2. Complete WorkCore workspaces.
3. Migrate legacy records.
4. Put legacy CRM/Sales into read-only mode.
5. Disable legacy menu roots.
6. Redirect compatible URLs.
7. Preserve rollback window.
8. Remove legacy providers later.
9. Remove legacy schema only in a separately approved release.

Do not show both operational CRMs indefinitely.

---

# 33. CRM project/task/calendar replacement

The WorkCore upgrade plan maps generic CRM concepts to operational concepts:

| MagicAI CRM | WorkCore |
|---|---|
| Project | Work order, contract or recurring service |
| Task | Work-order task/checklist/corrective action |
| Milestone | Work-order/service stage |
| Calendar event | Appointment |
| Assignment | Dispatch assignment |
| Timesheet | Time entry/attendance evidence |
| Project file | Work-order/premises/customer document |
| Discussion | Activity timeline/operational conversation |

This is the right direction for service businesses.

Do not rebuild generic CRM Projects/Tasks as duplicate entities unless a vertical genuinely requires them.

---

# 34. One-time legacy CRM importer

The final cutover requires a one-time migration engine.

Required mapping:

```text
MagicAI CRM Company → WorkCore Customer
MagicAI Contact → WorkCore Contact
MagicAI Lead → WorkCore Lead
MagicAI Deal → WorkCore Opportunity
MagicAI Pipeline → WorkCore Sales Pipeline
MagicAI Activity → WorkCore CRM Activity
MagicAI Project → WorkCore Work Order/Contract
MagicAI Task → WorkCore Task/Activity
MagicAI Event → WorkCore Appointment
MagicAI Product → WorkCore Catalogue Item
MagicAI Proposal/Estimate → WorkCore Quote
MagicAI Invoice → WorkCore Invoice
MagicAI Payment → WorkCore Payment Allocation
```

## Current status

**Not implemented.**

This remains a major cutover blocker for existing MagicAI CRM customers.

---

# 35. External source mapping

The importer needs durable source mapping:

```text
source system
source workspace
source table/type
source ID
source version/checksum
WorkCore company
WorkCore type
WorkCore public ID
migration status
last reconciled at
conflict
```

Every source record must end in:

```text
imported
deliberately skipped
or
reconciliation required
```

No silent loss.

---

# 36. Contact capture

MagicAI's core `ContactCapturedEvent` remains inadequate for WorkCore:

- no WorkCore company
- no event ID
- no external record mapping
- no idempotency key
- no consent
- no correlation
- no core dispatcher

The final channel integration should bypass that weak v1 contract or version it.

Recommended:

```text
business.contact.captured.v2
→ WorkCore company
→ WorkCore lead/customer resolution
→ idempotency
→ consent/preference
→ governed action
```

---

# 37. MagicAI AI Chat integration

MagicAI should remain the user-facing chat surface after the host security defects from Scan 14 are corrected.

WorkCore Business Network should contribute:

```text
CRM tools
Catalogue tools
Support tools
Knowledge tools
Wizard tools
Intelligence context
```

MagicAI should not query WorkCore tables directly.

## Execution chain

```text
MagicAI chat/agent
→ WorkCore tool catalogue
→ NativeAiAccessGate
→ company entitlement
→ actor permission
→ read model or action
→ confirmation where required
→ audit/event
→ structured result
→ MagicAI renders
```

---

# 38. MagicAI AI Agent integration

The host already has optional AI Agent provider contracts.

The recommended WorkCore adapter exposes WorkCore's filtered tool catalogue to MagicAI AI Agents.

Do not install a parallel `ai-agent-tool-crm` that writes to a second CRM.

Preferred:

```text
ai-agent-tool-workcore
```

or a host adapter exposed by the parent WorkCore extension.

It should surface only tools valid for:

```text
active company
loaded module
plan entitlement
actor permission
agent allowlist
risk policy
```

---

# 39. Tool exposure remains intentionally incomplete

Business Network has many governed actions that are **not** AI tools.

Examples:

- lead conversion
- opportunity won/lost
- support → work order
- review publication
- service recovery
- territory mutation
- wizard publication/completion
- adaptive feature activation

This is not a defect.

It is a useful safety boundary.

Agent autonomy should expand deliberately after business workflows and approval UX are proven.

---

# 40. Knowledge and prompt-injection boundary

WorkCore Intelligence contains stronger safety infrastructure than MagicAI's generic PDF/chat retrieval:

- secret scanner
- identifier detector
- retention policy
- controlled knowledge ingestion
- evidence chains
- strict structured-proposal validation

However, retrieved knowledge still needs a clear model-context trust label.

Recommended hierarchy:

```text
platform safety
→ company policy
→ WorkCore permission/action policy
→ agent instructions
→ verified WorkCore records
→ knowledge evidence
→ user input
→ external/untrusted content
```

Knowledge content must not change tool authorization.

---

# 41. Reviews defect and AI gap

Reviews has a mature governed lifecycle but:

- contact references still use wrong table
- AI registry is empty
- automatic post-job review request workflow is not proven
- consent/suppression model remains incomplete

Recommended staged release:

```text
Phase 1:
manual review request and service recovery

Phase 2:
completion-driven review automation

Phase 3:
safe AI summary/recommendation tools
```

---

# 42. Territories AI gap

Territories has strong operational actions/read models but no AI tools.

Useful safe initial tools could be read-only:

```text
territory_search
territory_match_address
territory_get_branch
```

Do not initially expose territory mutation to general agents.

---

# 43. Business Network authority matrix

| Capability | MagicAI | WorkCore Business Network | Final authority |
|---|---|---|---|
| Login/user identity | Yes | Consumes identity | MagicAI |
| SaaS subscription | Yes | Projects entitlement | MagicAI |
| CRM customer | Legacy/optional | Yes | WorkCore |
| Contact | Legacy/optional | Yes | WorkCore |
| Lead | Legacy/optional | Yes | WorkCore |
| Pipeline/deal | Legacy/optional | Yes | WorkCore |
| CRM activities | Legacy/optional | Yes | WorkCore |
| Service catalogue | Host donor only | Yes | WorkCore |
| Support ticket | Channels may capture | Yes | WorkCore |
| Knowledge article | AI Chat may render | Yes | WorkCore |
| Reviews/rebooking | Channels deliver | Yes | WorkCore |
| Territories | Maps visualize | Yes | WorkCore |
| Intelligence evidence | AI supplies inference | Yes | WorkCore |
| Wizards | Host UI renders | Yes | WorkCore |
| AI model/provider | Yes | Policy/orchestration | MagicAI provider layer |
| AI business tools | Host invokes | Yes | WorkCore governance |

---

# 44. Current blockers

## Critical

1. **MagicAI subscription resolver defaults do not match supplied MagicAI 11 schema**
   - expects `status`
   - MagicAI has `stripe_status`
   - expects `starts_at`
   - MagicAI has no `starts_at`

2. **MagicAI host queue boot logic remains incompatible with WorkCore**
   - rewrites queue names
   - runs worker during request boot

3. **MagicAI dashboard-wide CSRF exemption remains unsafe**

4. **Reviews contact reference uses nonexistent `tz_contacts`**

## High

5. WorkCore native AI uses `NullCredentialResolver`.
6. WorkCore AI dedicated route middleware still uses generic `auth`.
7. WorkCore AI provider path does not yet use MagicAI's broad model/entity catalogue.
8. Functional CRM workspace UI is incomplete.
9. One-time CRM importer is not implemented.
10. Complete duplicate/merge/customer-preference lifecycle is unfinished.
11. AI tool exposure for Reviews/Territories is absent.
12. Effective add-on manifest contributions are not generated.
13. Real multi-company MagicAI E2E CRM workflow remains unproven.
14. MagicAI chat ownership/realtime key vulnerabilities from Scan 14 must be fixed before attaching WorkCore data.

## Medium

15. Explicit billing-account/company link should replace owner-user subscription assumption.
16. MagicAI menu caches need company/entitlement revision-aware invalidation.
17. Contact capture v2 is not implemented.
18. CRM workspace reports are structural only.
19. Legacy URL redirect/read-only cutover is not implemented.
20. Communication consent/preferences require completion.

---

# 45. Required integration work

## WorkCore

1. Fix MagicAI subscription-schema defaults.
2. Add live MagicAI subscription fixture.
3. Fix `tz_contacts`.
4. Finish CRM customer/contact lifecycle.
5. Finish opportunity → quote/work workflow.
6. Build functional workspace components.
7. Build one-time CRM importer.
8. Bind MagicAI AI provider/credential adapter.
9. Make native AI API middleware Passport-aware.
10. Add optional-registry filtering.
11. Add effective manifest generation.
12. Add read-only Reviews/Territories AI tools later.

## MagicAI

13. Remove queue rewriting/boot worker.
14. Restore CSRF.
15. Harden AI Chat ownership/document retrieval/realtime credentials.
16. Register WorkCore provider map.
17. Run WorkCore menu sync.
18. Configure WorkCore entitlement projection.
19. Disable legacy CRM/Sales only after migration parity.
20. Provide notification/channel adapters.
21. Provide private storage/provider adapters.
22. Expose filtered WorkCore tools to AI Agent.

---

# 46. Required end-to-end tests

## Entitlement

- Real MagicAI 11 subscription row resolves successfully.
- `stripe_status` maps correctly.
- Trial subscription works.
- Lifetime plan works.
- Expired subscription denies Business Network.
- Plan feature change increments entitlement revision.
- Disabled `ext_workcore_core` hides CRM workspace and denies actions.
- Disabled `ext_workcore_ai_actions` removes AI/intelligence/wizard capabilities.

## CRM

- Create customer.
- Create contact.
- Create lead.
- Convert lead once.
- Create opportunity.
- Move opportunity.
- Mark won with signed confirmation.
- Record activity.
- Cross-company IDs are rejected.
- Replay uses idempotency.
- Owner/admin permission path works.

## MagicAI UI

- Menu sync creates CRM workspace.
- Admin custom order remains unchanged after sync.
- Entitlement removal hides sections.
- Company switch changes manifest.
- CRM workspace never shows another company's data.
- Legacy CRM root can be disabled cleanly.

## AI Agent

- CRM reads return current company only.
- AI cannot call non-exposed won/lost transition.
- AI mutation requires correct WorkCore permission.
- High-risk tool requires signed approval.
- Tool result records action audit.
- AI cannot use an uninstalled optional package registry.
- No provider credential reaches browser.

## Reviews

- Contact-linked review uses `tz_customer_contacts`.
- Review publication requires signed approval.
- Low review creates service recovery only when policy permits.
- Rebooking remains company scoped.

## Migration

- Legacy CRM Company imports as WorkCore Customer.
- Tenant Company is never converted to customer.
- Duplicate source mapping is idempotent.
- Financial totals reconcile.
- Migration rerun is safe.
- Ambiguous record goes to reconciliation.

---

# 47. Revisions to earlier scans

Current WorkCore `main` supersedes these earlier statements.

## Scan 13

Old:

```text
WorkCore AI module is defined but never loaded.
AI config path is broken.
```

Current:

```text
Business Network explicitly loads ai.
Current AI provider resolves its config from canonical WorkCore Config.
```

Still open:

```text
NullCredentialResolver
generic AI route auth
limited provider breadth
MagicAI provider adapter
privacy/cost hardening
```

## Scan 18

Resolve:

```text
undefined Manage
native WorkCore Passport mismatch
arbitrary confirmation
fail-open tenant reads
```

Add:

```text
MagicAI subscription schema mismatch
Reviews contact table defect
AI route-specific auth mismatch
functional workspace incompleteness
```

## Scan 20

Resolve:

```text
permission enum blocker
confirmation blocker
parent native API middleware blocker
no menu adapter
```

Add current-main revision noting:

```text
signed approvals
plan entitlement projection
workspace catalogue
menu synchronizer
entitlement scheduler
```

The MagicAI host queue and CSRF findings remain open.

---

# 48. Decisions established by Scan 21

1. WorkCore Business Network is the final CRM authority.
2. MagicAI CRM/Sales become migration sources, not permanent peers.
3. Business Network owns front-office business records.
4. MagicAI remains platform identity, subscription and AI-provider authority.
5. CRM AI tools remain a deliberately restricted subset of governed actions.
6. Catalogue remains WorkCore authority for operational services.
7. Support channels may be MagicAI-facing, but tickets are WorkCore records.
8. Knowledge authority stays WorkCore even when MagicAI renders AI answers.
9. Reviews and Territories remain WorkCore, with AI exposure conservative.
10. Intelligence remains evidence/recommendation infrastructure.
11. Expansion remains bounded/declarative; no arbitrary runtime code generation.
12. WorkCore native AI is now reachable through Business Network.
13. WorkCore AI should still execute models through a MagicAI adapter.
14. Native MagicAI WorkCore navigation is implemented structurally.
15. Functional CRM workspaces remain incomplete.
16. MagicAI subscription-schema defaults must be fixed before entitlement rollout.
17. The one-time legacy CRM importer is mandatory before cutover.
18. `tz_contacts` must be fixed before review workflows launch.

---

# 49. Next combined scan

```text
22-workcore-commercial-and-magicai-integration-deep-scan.md
```

It should scan current WorkCore `main` and MagicAI together for:

- quotes and estimates
- invoices
- payments
- receivables
- collections
- GST
- ledger
- reconciliation
- payroll
- inventory
- supply/procurement
- Titan Vault
- trust accounting
- MagicAI SaaS billing boundary
- payment provider reuse
- WorkCore Commercial workspace
- AI tools
- current Finance production-readiness defects
- completion-to-invoice integration

---

# Evidence sources

## WorkCore current main

```text
native-extensions/WorkCoreBusinessNetwork/extension.manifest.json
native-extensions/WorkCoreBusinessNetwork/System/WorkCoreBusinessNetworkServiceProvider.php
packages/workcore-business-network/files.sha256.json
packages/workcore-business-network/src/Domains/WorkCore/Providers/BusinessNetworkServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/CRM/Providers/WorkCRMServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/CRM/routes/api.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/CRM/AI/CRMToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Catalogue/Providers/WorkCatalogueServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Catalogue/AI/CatalogueToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Support/Providers/WorkSupportServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Support/AI/SupportToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/KnowledgeBase/Providers/WorkKnowledgeBaseServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Knowledge/AI/KnowledgeToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Reviews/Providers/WorkReviewsServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Reviews/Repositories/EloquentReviewRepository.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Reviews/AI/ReviewsToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Territories/Providers/WorkTerritoriesServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Territories/AI/TerritoriesToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Wizards/Providers/WorkWizardsServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Modules/Wizards/AI/WizardsToolRegistry.php
packages/workcore-business-network/src/Domains/WorkCore/System/Intelligence/Providers/WorkCoreIntelligenceServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/Expansion/Providers/WorkExpansionServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/AI/Providers/WorkCoreAIServiceProvider.php
packages/workcore-business-network/src/Domains/WorkCore/System/AI/routes/api.php
packages/workcore-shared-foundation/src/Domains/WorkCore/Config/workcore_ai.php
native-extensions/WorkCore/System/WorkCoreServiceProvider.php
native-extensions/WorkCore/config/workcore-native.php
native-extensions/WorkCore/System/Entitlements/MagicAIEffectiveSubscriptionResolver.php
native-extensions/WorkCore/System/Navigation/WorkCoreWorkspaceCatalogue.php
native-extensions/WorkCore/System/Navigation/WorkCoreWorkspaceManifest.php
native-extensions/WorkCore/System/Navigation/MagicAIMenuSynchronizer.php
native-extensions/WorkCore/System/Navigation/workspaces.php
native-extensions/WorkCore/routes/user.php
native-extensions/WorkCore/resources/views/workspace.blade.php
native-extensions/WorkCore/database/migrations/2026_08_03_020000_add_workcore_entitlements_to_magicai_plans.php
WORKCORE-MAGICAI-CRM-REPLACEMENT-UPGRADE-PLAN.md
docs/upgrade-baseline/known-defects.md
```

## MagicAI 11 host

```text
app/Domains/Marketplace/MarketplaceServiceProvider.php
app/Services/Common/MenuService.php
app/Http/Middleware/CheckTemplateTypeAndPlan.php
app/Providers/AppServiceProvider.php
app/Http/Middleware/VerifyCsrfToken.php
database/migrations/2019_05_03_000002_create_subscriptions_table.php
app/Models/Subscriptions.php
```

---

# Evidence limitations

This was a static repository and host-package scan.

It did not:

- run a real MagicAI subscription entitlement projection
- execute Business Network routes with Passport
- render functional CRM datasets in the workspace shell
- run MagicAI AI Agent against WorkCore tools
- migrate a live paid-CRM database
- call a live AI provider
- execute channel notifications
- perform real multi-company concurrency tests

Where the current repository's integration plan describes future parity work, that work is labelled incomplete rather than assumed implemented.
