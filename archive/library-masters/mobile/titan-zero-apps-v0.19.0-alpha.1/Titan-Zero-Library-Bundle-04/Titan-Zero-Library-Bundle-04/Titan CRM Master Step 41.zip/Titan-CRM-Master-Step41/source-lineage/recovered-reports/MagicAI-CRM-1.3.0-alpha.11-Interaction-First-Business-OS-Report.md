# MagicAI CRM 1.3.0-alpha.11 — Interaction-First Business OS

## Release

- Version: `1.3.0-alpha.11`
- Base: CRM `1.3.0-alpha.10`
- Interaction Engine compatibility: `>=10.3.1 <11.0`
- Package: `MagicAI-CRM-1.3.0-alpha.11-Titan-Installer-Ready.zip`
- SHA-256: `f43038e09be2547cd8a0e49bc17cab8d94a1c9258aedd9e88828beb4ae3dca6c`
- Diff from alpha.10: **76 files added, 66 modified, 0 removed**

## Core UX change

Titan Interaction Engine is now the primary structured interaction layer for CRM create workflows.

Internal CRM pages use a common pattern:

**Page title / context → Titan Zero AI command bar → New action → list/manage content**

Default inline create forms have been removed from the major list/manage pages. Creation starts through the Interaction Engine or conversational AI. Mature direct-entry forms remain as Advanced fallback where useful.

## Conversational operation

A user can now type requests such as:

- Add a customer
- Create a job for this customer tomorrow
- Prepare a quote at the normal margin
- Create an invoice
- Add a supplier
- Receive stock
- Create a vehicle
- Schedule maintenance
- Add a custom field
- Create a webhook

The CRM conversational layer resolves the intent to an Interaction Engine journey, starts a session, carries safe page/record context forward and helps fill the workflow.

AI does not directly bypass CRM services and does not self-approve approval-required actions.

## Authority

Supported modes:

- `assist`
- `approval`
- `autonomous`

Autonomous execution is restricted by an explicit allowlist.

High-consequence actions remain approval-gated by default, including jobs, quotes, estimates, invoices, payments, bookkeeping transactions, purchase orders, goods receipts, stock counts and stock transfers.

## CRM-owned primary Interaction journeys

CRM now owns contract-correct Interaction Engine definitions for:

- New Customer
- New Job
- New Quote
- New Invoice

This avoids payload drift between generic donor wizards and CRM's real service contracts.

Quotes and invoices continue to use CRM deterministic line calculations and Financial Assistant arithmetic.

## Journey coverage

Interaction journeys now cover:

### Customers
- New Customer
- New Contact
- Customer Hub access
- Support case
- Record sharing

### Leads
- New Lead
- New Opportunity
- New Pipeline
- New Quote
- New Estimate

### Work
- New Job
- Service Request
- Project
- Task
- Service
- Service Location
- Recurring Work
- Form
- Service Area
- Customer Asset

### Crew
- Calendar Event
- Appointment
- Dispatch Assignment
- Time Entry

### Money
- Invoice
- Payment
- Bookkeeping Transaction

### Gear
- Inventory Item
- Stock Location
- Stock Reservation
- Reorder Rule
- Supplier
- Purchase Order
- Goods Receipt
- Stock Count
- Stock Transfer
- Tool
- Equipment
- Vehicle
- Maintenance
- Receive Stock
- Transfer Stock

### Automate and Settings
- Automation
- API Key
- Webhook
- Tag
- Custom Field

## Context-aware record pages

Customer, Contact, Lead, Opportunity, Job and financial-document detail pages now keep the Titan Zero AI bar and pass safe public-ID context into newly started journeys.

Prefill is restricted to fields actually declared by the target wizard. Tenant/user identity values cannot be supplied through page prefill and are resolved from trusted CRM tenancy instead.

## Public/output boundary

The internal CRM Interaction shell is deliberately not injected into:

- Customer-facing Customer Hub public pages
- generated sales PDFs
- generated sales email output

This keeps business-only AI/governance controls out of customer/output surfaces.

## Preserved architecture

- CRM remains system of record.
- `tenant_company_id` remains tenancy.
- CRM `company_id` remains customer/account relationship data.
- WorkCore runtime dependency: **none**
- standalone Titan Financial Engine runtime dependency: **none**
- Titan Hub / Titan Go / Titan BOS integration preserved
- 17 deterministic Financial Assistants preserved
- alpha.10 menu completeness preserved
- alpha.9 route-cache repair preserved
- alpha.8 icon safety preserved
- Pay, Bookkeeping and Gear/Locker functionality preserved

## Fresh-extraction certification

The exact downloadable ZIP was extracted into a clean directory and verified.

Results:

- ZIP files: **596**
- PHP lint: **469 / 469 PASS**
- JSON definitions/manifests: **64 / 64 PASS**
- migrations: **24**
- reversible migrations: **24 / 24**
- production integrity hashes: **594**
- exact file inventory entries: **595**
- unsafe archive paths: **0**
- junk paths: **0**
- case collisions: **0**
- outer wrapper: **0**
- ZIP compressed-data test: **PASS**

Regression chain:

- provider install-stage safety: **PASS**
- MySQL time-column compatibility: **PASS**
- MySQL identifier-length protection: **PASS**
- migration restartability/recovery: **PASS**
- Locker purchasing and stock-control gates: **PASS**
- alpha.8 icon compatibility: **PASS**
- alpha.9 route-cache/menu-link recovery: **PASS**
- alpha.10 menu completeness: **PASS**
- alpha.11 Interaction contract: **PASS**
- shared UI shell: **PASS**
- conversational AI boundary: **PASS**
- New-action coverage: **PASS**
- domain capability coverage: **PASS**
- Advanced fallback: **PASS**
- authority policy: **PASS**
- Customer/Job/Quote/Invoice contract alignment: **PASS**
- business journey coverage: **PASS**
- context prefill safety: **PASS**
- menu-page consistency: **PASS**
- detail-page consistency: **PASS**
- auxiliary journeys: **PASS**
- internal shell coverage: **PASS**
- Titan Mobile clean identities: **PASS**
- Financial Assistant deterministic kernel: **17 / 17 PASS**
- package integrity master verifier: **PASS**

## Runtime certification boundary

Static/package verification cannot prove the exact live MagicAI database, provider cache, Interaction Engine registration state, theme rendering or PHP container state on `titanzero.io`.

Install alpha.11 over alpha.10. If the live Titan Extension Manager or Laravel runtime reports a host-specific error, use that exact error/stage as the next repair point rather than altering CRM business data manually.

## SHA-256

`f43038e09be2547cd8a0e49bc17cab8d94a1c9258aedd9e88828beb4ae3dca6c`
