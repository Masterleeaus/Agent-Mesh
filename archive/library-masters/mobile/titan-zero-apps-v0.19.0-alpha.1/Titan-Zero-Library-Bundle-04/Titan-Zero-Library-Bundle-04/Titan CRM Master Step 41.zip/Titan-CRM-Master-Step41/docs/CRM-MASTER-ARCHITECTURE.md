# Titan CRM Master — Step 41

## Canonical decision

Titan now has one CRM authority: **Titan CRM Master**.

Historical MagicAI CRM, WorkCore CRM and RealCRM implementations are donors, migration sources, compatibility layers or projections after convergence. They are not parallel masters.

## Tenant boundary

`company_id` is the only canonical tenant/company boundary.

Historical MagicAI CRM `tenant_company_id` is accepted only in controlled migration/compatibility input and normalized to `company_id` before authorization, data access, projection, execution, queues, audit or domain mutation.

Historical CRM `company_id` values that represented a customer company/account must not be confused with Titan's tenant `company_id`. Those become canonical customer records or external links.

## One customer truth

Canonical graph:
- Customer
- Contact
- Lead
- Opportunity
- Pipeline
- CRM Activity
- Revenue Journey

External CRM customer/company/contact/deal IDs are stored in external-record links with source revision and authority mode.

## Revenue authority

Every meaningful sales lifecycle uses durable `revenue_journey_id` scoped by `company_id`:

lead → opportunity → quote → booking → job → invoice → payment → repeat/referral.

Events are idempotent, correlated and provenance-bearing. Journey progression is monotonic except through an explicit corrective/rewind process.

## Finance boundary

CRM owns sales/customer/revenue context. It does not silently become a second general ledger or payment processor.

Invoices/payments can be linked/projected into CRM, but authoritative payment capture, reconciliation, ledger consequences and financial settlement remain with the appropriate financial/payment authority.

The useful deterministic finance calculators recovered from MagicAI CRM remain read-only calculation capabilities. Applying a result requires an independent governed write.

## Recovered MagicAI CRM capabilities

The recovered 1.3 lineage contributes:
- rich customer/contact/work/lead/opportunity UI;
- Titan Hub/customer access;
- quotes/estimates and job context;
- Pay/Locker/bookkeeping integration patterns;
- deterministic financial calculation kernel;
- contextual Financial AI;
- Interaction Engine journeys;
- mobile/owner/worker/customer surface integration;
- stable terminology Customers / Leads / Opportunities / Quotes / Jobs / Customer Hub.

These features are retained as CRM Master modules, not as a separate CRM database authority.

## Recovered WorkCore CRM capabilities

The governed WorkCore lineage contributes:
- 13 governed write actions;
- 7 tenant-aware read models;
- lead conversion;
- pipeline/opportunity lifecycle;
- forecasts and activity timeline;
- duplicate detection;
- integration-safe read/write boundaries.

The `workcore.*` capability names remain compatibility aliases where needed, but canonical names are `crm.*`.

## AI and Interaction Engine

Interaction Engine may start/guide CRM journeys and AI may recommend or prepare actions.

Neither can:
- inject tenant identity;
- bypass permission;
- self-approve approval-required mutations;
- directly update CRM tables;
- invent authoritative financial calculations.

## External integrations

HubSpot, Shopify, channels, forms, lead sources and imported CRMs integrate through:
1. canonical provider/integration contracts;
2. external record links;
3. governed CRM capabilities;
4. canonical events/receipts.

No connector writes CRM tables directly.

## Migration rule

Historical systems are converged with:
- source ID/revision preservation;
- deterministic canonical mapping;
- idempotent imports;
- duplicate review;
- field-authority decisions;
- no last-write-wins dual-master sync;
- durable audit/provenance.
