<?php
namespace Titan\CrmMaster;

final class CanonicalCustomerRegistry
{
    private array $customers=[];
    private array $externalLinks=[];

    public function create(string $companyId,string $customerId,string $displayName,string $type='organisation'): array
    {
        if(trim($companyId)==='') throw new \InvalidArgumentException('company_id-required');
        $key=$companyId.'|'.$customerId;
        if(isset($this->customers[$key])) throw new \RuntimeException('duplicate-canonical-customer');
        $record=[
            'customer_id'=>$customerId,'company_id'=>$companyId,'customer_type'=>$type,
            'display_name'=>$displayName,'status'=>'active','version'=>1,'provenance'=>[],
            'legacy_external_links'=>[]
        ];
        $this->customers[$key]=$record;
        return $record;
    }

    public function linkExternal(string $companyId,string $system,string $externalId,string $canonicalCustomerId,string $sourceRevision): array
    {
        $key=$companyId.'|'.$system.'|customer|'.$externalId;
        if(isset($this->externalLinks[$key]) && $this->externalLinks[$key]['canonical_ref']!==$canonicalCustomerId) {
            throw new \RuntimeException('external-customer-link-conflict');
        }
        return $this->externalLinks[$key]=[
            'link_id'=>'ext_'.substr(hash('sha256',$key),0,32),
            'company_id'=>$companyId,'source_system'=>$system,'record_type'=>'customer',
            'external_id'=>$externalId,'canonical_ref'=>$canonicalCustomerId,
            'authority_mode'=>'import_source','source_revision'=>$sourceRevision,
            'last_payload_hash'=>null,'sync_direction'=>'inbound_import'
        ];
    }
}
