<section><h1>Bookings</h1><p>Manage service requests, scope readiness, requested windows, quote state and downstream handoff status.</p></section>
