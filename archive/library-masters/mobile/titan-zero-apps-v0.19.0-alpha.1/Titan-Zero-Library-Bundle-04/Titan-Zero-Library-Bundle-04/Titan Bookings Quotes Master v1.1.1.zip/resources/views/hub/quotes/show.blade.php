<section><h1>Quote</h1><p>Review scope, line items, taxes, total, validity and terms before accepting or rejecting this quote.</p></section>
