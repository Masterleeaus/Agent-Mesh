<section><h1>Quotes</h1><p>Track drafts, sent quotes, acceptance, rejection, expiry, revisions and conversion.</p></section>
