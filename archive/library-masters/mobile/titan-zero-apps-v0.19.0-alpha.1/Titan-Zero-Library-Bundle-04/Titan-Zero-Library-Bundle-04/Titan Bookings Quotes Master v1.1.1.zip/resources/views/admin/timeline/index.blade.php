<section><h1>Commercial Timeline</h1><p>Follow booking, quote, acceptance, handoff and variation facts without duplicating peer-system records.</p></section>
