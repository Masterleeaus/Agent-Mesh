<section><h1>Quote Builder</h1><p>Build a versioned quote from service scope and deterministic line pricing. Sent versions remain immutable.</p></section>
