<section><h1>Bookings</h1><p>Request a service and choose preferred service windows. Confirmation follows availability and commercial approval.</p></section>
