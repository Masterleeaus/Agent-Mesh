<section><h1>Bookings & Quotes Settings</h1><p>Configure commercial defaults, quote validity, numbering and integration behavior within platform authority.</p></section>
