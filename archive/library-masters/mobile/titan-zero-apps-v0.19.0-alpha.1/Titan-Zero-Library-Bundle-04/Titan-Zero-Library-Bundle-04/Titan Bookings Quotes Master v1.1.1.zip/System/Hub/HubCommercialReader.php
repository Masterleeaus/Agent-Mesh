<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Hub;
interface HubCommercialReader{public function quote(int $companyId,string $quoteRef):?array;public function booking(int $companyId,string $bookingRef):?array;public function variation(int $companyId,string $variationRef):?array;}
