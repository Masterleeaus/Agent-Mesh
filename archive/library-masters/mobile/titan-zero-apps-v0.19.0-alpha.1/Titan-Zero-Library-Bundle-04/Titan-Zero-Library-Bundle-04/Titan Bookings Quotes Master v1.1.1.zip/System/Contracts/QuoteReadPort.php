<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface QuoteReadPort{public function find(int $companyId,string $quoteRef):?array;public function page(int $companyId,int $limit=25,?string $cursor=null):array;}
