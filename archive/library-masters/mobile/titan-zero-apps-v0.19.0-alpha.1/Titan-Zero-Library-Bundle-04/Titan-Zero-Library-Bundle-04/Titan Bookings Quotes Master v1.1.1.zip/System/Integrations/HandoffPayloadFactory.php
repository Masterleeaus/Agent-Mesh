<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
final class HandoffPayloadFactory{
 public function scheduling(int $companyId,string $bookingRef,array $windows,array $requirements):array{return ['company_id'=>$companyId,'booking_ref'=>$bookingRef,'requested_windows'=>$windows,'requirements'=>$requirements];}
 public function job(int $companyId,string $bookingRef,array $requirements):array{return ['company_id'=>$companyId,'booking_ref'=>$bookingRef,'job_requirements'=>$requirements];}
 public function invoice(int $companyId,string $quoteRef,array $snapshot):array{return ['company_id'=>$companyId,'quote_ref'=>$quoteRef,'commercial_snapshot'=>$snapshot];}
 public function payment(int $companyId,string $commercialRef,array $amount):array{return ['company_id'=>$companyId,'commercial_ref'=>$commercialRef,'amount'=>$amount];}
}
