<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface BookingReminderPort{public function schedule(int $companyId,string $bookingRef,array $leadMinutes=[1440,120]):array;public function cancel(int $companyId,string $bookingRef):void;}
