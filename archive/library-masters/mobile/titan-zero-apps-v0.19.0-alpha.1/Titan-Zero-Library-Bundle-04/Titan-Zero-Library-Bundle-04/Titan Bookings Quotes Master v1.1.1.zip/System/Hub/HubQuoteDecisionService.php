<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Hub;
use RuntimeException;
final class HubQuoteDecisionService{
 private array $receipts=[];
 public function __construct(private readonly HubAccessPolicy $policy){}
 public function decide(HubActor $actor,string $quoteRef,string $decision,string $idempotencyKey):array{
  if(isset($this->receipts[$actor->companyId][$idempotencyKey]))return $this->receipts[$actor->companyId][$idempotencyKey];
  $q=$this->policy->quote($actor,$quoteRef);if(!$q)throw new RuntimeException('quote unavailable');
  if(($q['status']??null)!=='sent')throw new RuntimeException('quote not actionable');
  if(!in_array($decision,['accept','reject'],true))throw new RuntimeException('invalid decision');
  $until=$q['valid_until']??null;if($until!==null&&strtotime((string)$until)!==false&&strtotime((string)$until)<time())throw new RuntimeException('quote expired');
  if(trim($idempotencyKey)==='')throw new RuntimeException('idempotency key required');
  return $this->receipts[$actor->companyId][$idempotencyKey]=['company_id'=>$actor->companyId,'customer_ref'=>$actor->customerRef,'actor_ref'=>$actor->actorRef,'quote_ref'=>$quoteRef,'quote_version'=>(int)($q['version']??0),'decision'=>$decision,'idempotency_key'=>$idempotencyKey];
 }
}
