<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\{BookingAvailabilityPort,WorkerSchedulePort};use App\Extensions\TitanBookingsQuotes\System\Domain\Bookings\{AvailabilityEngine,CapacityPolicy};use Illuminate\Support\Facades\DB;use RuntimeException;
final readonly class DatabaseBookingAvailabilityPort implements BookingAvailabilityPort{
 public function __construct(private WorkerSchedulePort $workers,private AvailabilityEngine $engine,private CapacityPolicy $capacity){}
 public function slots(int $companyId,array $r):array{
  $duration=(int)($r['duration_minutes']??60);$step=(int)($r['step_minutes']??30);$before=(int)($r['buffer_before_minutes']??0);$after=(int)($r['buffer_after_minutes']??0);$working=(array)($r['working_windows']??[]);if(!$working)throw new RuntimeException('working windows required');
  $workerRefs=(array)($r['worker_refs']??[]);if(!$workerRefs&&isset($r['booking']))$workerRefs=$this->workers->eligibleWorkers($companyId,(array)$r['booking']);$out=[];
  foreach($workerRefs as $worker){$busy=[];foreach($working as $ww){$date=substr((string)$ww['start'],0,10);$busy=array_merge($busy,$this->workers->existingWindows($companyId,(string)$worker,$date));}$slots=$this->engine->slots($working,$busy,$duration,$step,$before,$after);foreach($slots as $slot)$out[]=$slot+['worker_ref'=>(string)$worker];}
  usort($out,fn($a,$b)=>strcmp($a['start'],$b['start'])?:strcmp($a['worker_ref'],$b['worker_ref']));return $out;
 }
 public function assertAssignable(int $companyId,string $bookingRef,string $workerRef):void{$b=DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('public_id',$bookingRef)->first();if(!$b)throw new RuntimeException('booking not found');if(!$b->starts_at||!$b->ends_at)throw new RuntimeException('booking has no confirmed schedule window');$date=substr((string)$b->starts_at,0,10);$this->capacity->assert(['date'=>$date,'start'=>(string)$b->starts_at,'end'=>(string)$b->ends_at],$this->workers->existingWindows($companyId,$workerRef,$date),$this->workers->capacityPolicy($companyId,$workerRef));}
}