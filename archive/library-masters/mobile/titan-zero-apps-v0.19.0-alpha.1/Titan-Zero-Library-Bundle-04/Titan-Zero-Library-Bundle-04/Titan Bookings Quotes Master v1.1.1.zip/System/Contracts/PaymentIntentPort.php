<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface PaymentIntentPort{public function request(int $companyId,string $commercialRef,array $amountSnapshot,string $idempotencyKey):array;}
