<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Admin;
use Illuminate\Http\Request;final class CommercialTimelineController{public function index(Request $r){return view('titan-bookings-quotes::admin.timeline.index');}}
