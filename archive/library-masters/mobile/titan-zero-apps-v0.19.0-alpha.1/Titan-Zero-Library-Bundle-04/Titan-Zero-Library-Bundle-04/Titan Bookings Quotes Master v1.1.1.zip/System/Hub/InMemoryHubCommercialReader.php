<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Hub;
final class InMemoryHubCommercialReader implements HubCommercialReader{
 public function __construct(private array $quotes=[],private array $bookings=[],private array $variations=[]){}
 private function find(array $rows,int $companyId,string $ref):?array{foreach($rows as $r)if((int)$r['company_id']===$companyId&&($r['public_id']??'')===$ref)return $r;return null;}
 public function quote(int $companyId,string $quoteRef):?array{return $this->find($this->quotes,$companyId,$quoteRef);}
 public function booking(int $companyId,string $bookingRef):?array{return $this->find($this->bookings,$companyId,$bookingRef);}
 public function variation(int $companyId,string $variationRef):?array{return $this->find($this->variations,$companyId,$variationRef);}
}
