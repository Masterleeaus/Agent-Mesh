<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
use RuntimeException;
final readonly class QuoteLifecycleService{
 public function __construct(private QuoteStore $store){}
 private static function fingerprint(string $action,array $payload):string{$normalize=function($v)use(&$normalize){if(is_array($v)){if(!array_is_list($v))ksort($v);foreach($v as $k=>$x)$v[$k]=$normalize($x);}return $v;};unset($payload['idempotency_key']);return hash('sha256',$action.'|'.json_encode($normalize($payload),JSON_THROW_ON_ERROR|JSON_PRESERVE_ZERO_FRACTION));}
 public function execute(QuoteCommand $c):array{
  if(trim($c->idempotencyKey)==='')throw new RuntimeException('idempotency key required');
  if($r=$this->store->receipt($c->companyId,$c->idempotencyKey)){if(isset($r['_request_hash'])&&$r['_request_hash']!==null&&$r['_request_hash']!==self::fingerprint($c->action,$c->payload))throw new RuntimeException('idempotency key reused with different request');unset($r['_request_hash']);return $r;}
  $cur=$this->store->find($c->companyId,$c->quoteRef);$v=(int)($cur['version']??0);if($v!==$c->expectedVersion)throw new RuntimeException('stale quote version');
  $status=$cur['status']??null;
  if($c->action==='accept'&&isset($cur['valid_until'])&&$cur['valid_until']!==null&&strtotime((string)$cur['valid_until'])!==false&&strtotime((string)$cur['valid_until'])<time())throw new RuntimeException('quote expired');
  $nextStatus=match($c->action){'draft'=> $status===null?'draft':throw new RuntimeException('illegal quote transition'),'send'=>$status==='draft'?'sent':throw new RuntimeException('illegal quote transition'),'accept'=>$status==='sent'?'accepted':throw new RuntimeException('illegal quote transition'),'reject'=>$status==='sent'?'rejected':throw new RuntimeException('illegal quote transition'),'expire'=>$status==='sent'?'expired':throw new RuntimeException('illegal quote transition'),'revise'=>in_array($status,['draft','sent','rejected','expired'],true)?'draft':throw new RuntimeException('illegal quote transition'),default=>throw new RuntimeException('illegal quote transition')};
  $next=array_merge($cur??[],$c->payload,['company_id'=>$c->companyId,'public_id'=>$c->quoteRef,'status'=>$nextStatus,'version'=>$v+1]);
  foreach(['tenant'.'_company_id','invoice_id','payment_id','worker_id'] as $f)unset($next[$f]);
  return $this->store->commit($c,$next);
 }
}
