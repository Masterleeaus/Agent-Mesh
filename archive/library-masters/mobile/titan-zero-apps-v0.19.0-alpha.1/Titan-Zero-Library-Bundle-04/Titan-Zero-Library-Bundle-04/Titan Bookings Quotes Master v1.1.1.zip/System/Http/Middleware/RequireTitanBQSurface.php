<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Middleware;
use Closure;use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,SurfaceAuthorityPort};
final readonly class RequireTitanBQSurface{
 public function __construct(private ActorContextPort $actors,private SurfaceAuthorityPort $authority){}
 public function handle(Request $request,Closure $next,string $surface){$this->authority->authorize($surface,$this->actors->current());return $next($request);}
}
