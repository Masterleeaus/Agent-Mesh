<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use Illuminate\Support\Facades\DB;use DateTimeImmutable;use DateTimeZone;use RuntimeException;
final class IcalendarExportService{
 public function booking(int $companyId,string $bookingRef):string{$b=DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('public_id',$bookingRef)->first();if(!$b||!$b->starts_at||!$b->ends_at)throw new RuntimeException('booking not calendar exportable');return $this->render([(array)$b]);}
 public function feed(int $companyId,string $from,string $to):string{$rows=DB::table('titan_bq_bookings')->where('company_id',$companyId)->whereBetween('starts_at',[$from,$to])->whereNotIn('status',['cancelled'])->orderBy('starts_at')->get()->map(fn($r)=>(array)$r)->all();return $this->render($rows);}
 private function render(array $rows):string{$lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Titan Zero//Bookings Quotes//EN','CALSCALE:GREGORIAN'];foreach($rows as $b){$lines[]='BEGIN:VEVENT';$lines[]='UID:'.$this->esc('titan-booking-'.$b['company_id'].'-'.$b['public_id']);$lines[]='DTSTAMP:'.gmdate('Ymd\\THis\\Z');$lines[]='DTSTART:'.$this->utc((string)$b['starts_at']);$lines[]='DTEND:'.$this->utc((string)$b['ends_at']);$lines[]='SUMMARY:'.$this->esc('Booking '.($b['service_ref']??$b['public_id']));$lines[]='STATUS:'.(($b['status']??'')==='cancelled'?'CANCELLED':'CONFIRMED');$lines[]='END:VEVENT';}$lines[]='END:VCALENDAR';return implode("\r\n",$lines)."\r\n";}
 private function utc(string $v):string{return (new DateTimeImmutable($v))->setTimezone(new DateTimeZone('UTC'))->format('Ymd\\THis\\Z');}
 private function esc(string $v):string{return str_replace(["\\",";",",","\r","\n"],["\\\\","\\;","\\,","","\\n"],$v);}
}