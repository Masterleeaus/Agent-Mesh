<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Intelligence;
final readonly class FrontOfficeFinding{public function __construct(public int $companyId,public string $kind,public string $aggregateRef,public string $severity){}public function toArray():array{return ['company_id'=>$this->companyId,'kind'=>$this->kind,'aggregate_ref'=>$this->aggregateRef,'severity'=>$this->severity];}}
