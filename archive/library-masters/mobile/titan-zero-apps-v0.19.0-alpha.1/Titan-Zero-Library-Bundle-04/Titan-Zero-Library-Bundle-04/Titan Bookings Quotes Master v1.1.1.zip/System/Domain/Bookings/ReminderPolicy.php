<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use DateTimeImmutable;
final class ReminderPolicy{public function leadTimes(array $v=[]):array{$v=array_values(array_unique(array_filter(array_map('intval',$v?:[1440,120]),fn($x)=>$x>0)));rsort($v);return $v;}public function due(string $startsAt,int $lead,string $now,int $tol=5):bool{$s=new DateTimeImmutable($startsAt);$n=new DateTimeImmutable($now);$t=$s->modify("-$lead minutes")->getTimestamp();$h=max(0,$tol)*30;return $n->getTimestamp()>=$t-$h&&$n->getTimestamp()<=$t+$h;}}
