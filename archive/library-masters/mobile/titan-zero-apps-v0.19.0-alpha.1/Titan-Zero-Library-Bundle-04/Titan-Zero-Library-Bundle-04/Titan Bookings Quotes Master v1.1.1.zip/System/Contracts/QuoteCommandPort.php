<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface QuoteCommandPort{public function execute(int $companyId,string $capability,array $payload,array $context):array;}
