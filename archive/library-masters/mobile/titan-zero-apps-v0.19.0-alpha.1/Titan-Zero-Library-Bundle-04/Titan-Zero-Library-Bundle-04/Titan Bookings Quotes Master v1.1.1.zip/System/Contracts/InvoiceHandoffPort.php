<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface InvoiceHandoffPort{public function request(int $companyId,string $quoteRef,array $commercialSnapshot,string $idempotencyKey):array;}
