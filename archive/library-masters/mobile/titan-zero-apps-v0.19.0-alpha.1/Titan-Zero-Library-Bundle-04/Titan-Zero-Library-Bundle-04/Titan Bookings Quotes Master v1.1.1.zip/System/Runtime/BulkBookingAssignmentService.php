<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\{BookingAssignmentPort,BookingAvailabilityPort};
final readonly class BulkBookingAssignmentService{
 public function __construct(private BookingAssignmentPort $assignments,private BookingAvailabilityPort $availability){}
 public function assign(int $companyId,array $bookingRefs,?string $workerRef,string $actorRef,?string $note=null):array{$r=['assigned'=>0,'skipped'=>0,'errors'=>[]];foreach(array_values(array_unique(array_map('strval',$bookingRefs))) as $ref){try{if($workerRef!==null)$this->availability->assertAssignable($companyId,$ref,$workerRef);$this->assignments->assign($companyId,$ref,$workerRef,$actorRef,$note);$r['assigned']++;}catch(\Throwable $e){$r['skipped']++;$r['errors'][$ref]=$e->getMessage();}}return $r;}
}