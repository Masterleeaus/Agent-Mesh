<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface CalendarProjectionPort{public function project(int $companyId,string $bookingRef,string $reason='changed'):array;public function cancel(int $companyId,string $bookingRef,string $reason='cancelled'):array;}
