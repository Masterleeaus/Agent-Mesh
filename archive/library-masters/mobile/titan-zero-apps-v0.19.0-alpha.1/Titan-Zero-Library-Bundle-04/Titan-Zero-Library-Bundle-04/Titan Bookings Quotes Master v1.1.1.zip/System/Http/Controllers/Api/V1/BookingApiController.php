<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Api\V1;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,BookingReadPort,BookingCommandPort};
final readonly class BookingApiController{
 public function __construct(private ActorContextPort $actor,private BookingReadPort $reads,private BookingCommandPort $commands){}
 private function limit(Request $r):int{return min(100,max(1,(int)$r->query('limit',25)));}
 public function index(Request $r){$a=$this->actor->current();return response()->json($this->reads->page($a['company_id'],$this->limit($r),$r->query('cursor')));}
 public function show(Request $r,string $bookingRef){$a=$this->actor->current();$row=$this->reads->find($a['company_id'],$bookingRef);abort_if(!$row,404);return response()->json($row);}
 public function store(Request $r){$a=$this->actor->current();$d=$r->validate(['service_ref'=>'nullable|string|max:128','site'=>'required|array','requested_windows'=>'required|array|min:1|max:5','idempotency_key'=>'required|string|max:128']);$d['booking_ref']='bkg_'.bin2hex(random_bytes(12));$d['customer_ref']=$a['customer_ref'];return response()->json($this->commands->execute($a['company_id'],'bookings.create',$d,$a),201);}
}
