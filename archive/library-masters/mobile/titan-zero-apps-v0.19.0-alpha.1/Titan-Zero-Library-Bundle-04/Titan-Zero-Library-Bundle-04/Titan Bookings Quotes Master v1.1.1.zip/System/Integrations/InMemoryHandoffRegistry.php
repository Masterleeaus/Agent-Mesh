<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
use RuntimeException;
final class InMemoryHandoffRegistry implements HandoffRegistry{
 private array $rows=[];
 public function receipt(int $c,string $t,string $k):?HandoffReceipt{$r=$this->rows[$c][$t][$k]??null;return ($r['status']??null)==='delivered'?$r['receipt']:null;}
 public function reserve(HandoffRequest $r):?string{$x=$this->rows[$r->companyId][$r->target][$r->idempotencyKey]??null;if($x&&$x['status']==='delivered')return null;$token=bin2hex(random_bytes(12));$this->rows[$r->companyId][$r->target][$r->idempotencyKey]=['status'=>'pending','token'=>$token];return $token;}
 public function deliver(int $c,string $a,HandoffReceipt $r,string $leaseToken):void{$x=$this->rows[$c][$r->target][$r->idempotencyKey]??null;if(($x['token']??null)!==$leaseToken)throw new RuntimeException('lost handoff lease');$this->rows[$c][$r->target][$r->idempotencyKey]=['status'=>'delivered','receipt'=>$r];}
 public function fail(HandoffRequest $r,string $e,string $leaseToken):void{$x=$this->rows[$r->companyId][$r->target][$r->idempotencyKey]??null;if(($x['token']??null)!==$leaseToken)throw new RuntimeException('lost handoff lease');$this->rows[$r->companyId][$r->target][$r->idempotencyKey]=['status'=>'failed','error'=>$e];}
}
