<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,QuoteReadPort,QuoteCommandPort};
final readonly class HubQuoteController{
 public function __construct(private ActorContextPort $actor,private QuoteReadPort $reads,private QuoteCommandPort $commands){}
 private function owned(array $a,string $ref):array{if(($a['customer_ref']??null)===null)abort(403,'customer authority unavailable');$q=$this->reads->find($a['company_id'],$ref);abort_if(!$q||!hash_equals((string)($q['customer_ref']??''),(string)$a['customer_ref']),404);return $q;}
 public function show(Request $r,string $quoteRef){$a=$this->actor->current();$q=$this->owned($a,$quoteRef);return view('titan-bookings-quotes::hub.quotes.show',['quote'=>$q,'quoteRef'=>$quoteRef]);}
 public function decision(Request $r,string $quoteRef){$a=$this->actor->current();$q=$this->owned($a,$quoteRef);$d=$r->validate(['decision'=>'required|in:accept,reject','expected_version'=>'required|integer|min:1','idempotency_key'=>'required|string|max:128']);$d['quote_ref']=$quoteRef;return response()->json($this->commands->execute($a['company_id'],'quotes.'.$d['decision'],$d,$a));}
 public function variationDecision(Request $r,string $variationRef){abort(501,'Variation command adapter not configured');}
}
