<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Intelligence;
use DateTimeImmutable;
final readonly class FrontOfficeDetector{
 public function __construct(private DateTimeImmutable $now){}
 public function inspect(array $rows):array{$out=[];foreach($rows as $r){$c=(int)($r['company_id']??0);$ref=(string)($r['public_id']??'');if($c<1||$ref==='')continue;
  if(($r['type']??'')==='quote'&&($r['status']??'')==='sent'){
   $sent=isset($r['sent_at'])?new DateTimeImmutable($r['sent_at']):null;$valid=isset($r['valid_until'])?new DateTimeImmutable($r['valid_until']):null;
   if($sent&&$this->now->getTimestamp()-$sent->getTimestamp()>=7*86400)$out[]=new FrontOfficeFinding($c,'quote.stale',$ref,'medium');
   if($valid&&$valid->getTimestamp()>=$this->now->getTimestamp()&&$valid->getTimestamp()-$this->now->getTimestamp()<=2*86400)$out[]=new FrontOfficeFinding($c,'quote.expiring',$ref,'medium');
  }
  if(($r['type']??'')==='booking'&&in_array(($r['status']??''),['requested','scoped'],true)&&empty($r['scope']))$out[]=new FrontOfficeFinding($c,'booking.scope_missing',$ref,'high');
  if(($r['type']??'')==='handoff'&&($r['status']??'')==='failed')$out[]=new FrontOfficeFinding($c,'handoff.failed',$ref,'high');
 }return $out;}
}
