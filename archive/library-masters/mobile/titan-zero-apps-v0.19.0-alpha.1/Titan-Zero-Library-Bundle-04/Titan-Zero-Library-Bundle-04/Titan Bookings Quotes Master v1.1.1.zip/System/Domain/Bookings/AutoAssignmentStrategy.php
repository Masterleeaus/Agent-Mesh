<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
final class AutoAssignmentStrategy{
 public function pick(array $candidates,array $counts,string $strategy='least_busy',int $pointer=0):?string{
  $candidates=array_values(array_unique(array_filter(array_map('strval',$candidates))));if(!$candidates)return null;
  if($strategy==='round_robin')return $candidates[$pointer%count($candidates)];
  usort($candidates,fn($a,$b)=>(($counts[$a]??0)<=>($counts[$b]??0))?:strcmp($a,$b));return $candidates[0]??null;
 }
}
