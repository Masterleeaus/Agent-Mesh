<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
final class InMemoryQuoteStore implements QuoteStore{
 private array $quotes=[],$receipts=[];
 public function find(int $companyId,string $quoteRef):?array{return $this->quotes[$companyId][$quoteRef]??null;}
 public function receipt(int $companyId,string $key):?array{return $this->receipts[$companyId][$key]??null;}
 public function commit(QuoteCommand $c,array $next):array{$this->quotes[$c->companyId][$c->quoteRef]=$next;$this->receipts[$c->companyId][$c->idempotencyKey]=$next;return $next;}
}
