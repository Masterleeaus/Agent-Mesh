<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface CustomerReferencePort{public function resolve(int $companyId,string $customerRef):?array;}
