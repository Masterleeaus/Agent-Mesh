<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface SchedulingHandoffPort{public function request(int $companyId,string $bookingRef,array $requirements,string $idempotencyKey):array;}
