<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
interface QuoteStore{public function find(int $companyId,string $quoteRef):?array;public function receipt(int $companyId,string $key):?array;public function commit(QuoteCommand $command,array $next):array;}
