<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use RuntimeException;
final class CapacityPolicy{
 public function assert(array $candidate,array $existing,array $policy):void{
  $day=(string)($candidate['date']??substr((string)($candidate['start']??''),0,10));$start=strtotime((string)($candidate['start']??''));$end=strtotime((string)($candidate['end']??''));
  if(!$start||!$end||$end<=$start)throw new RuntimeException('invalid assignment window');
  $sameDay=0;$overlap=0;
  foreach($existing as $x){if(($x['status']??'confirmed')==='cancelled')continue;$xd=(string)($x['date']??substr((string)($x['start']??''),0,10));if($xd===$day)$sameDay++;$xs=strtotime((string)($x['start']??''));$xe=strtotime((string)($x['end']??''));if($xs&&$xe&&$xs<$end&&$xe>$start)$overlap++;}
  if(isset($policy['max_per_day'])&&$policy['max_per_day']!==null&&$sameDay>=(int)$policy['max_per_day'])throw new RuntimeException('worker daily capacity exceeded');
  if(($policy['enforce_conflicts']??true)&&$overlap>=(int)($policy['max_per_slot']??1))throw new RuntimeException('worker slot capacity exceeded');
 }
}
