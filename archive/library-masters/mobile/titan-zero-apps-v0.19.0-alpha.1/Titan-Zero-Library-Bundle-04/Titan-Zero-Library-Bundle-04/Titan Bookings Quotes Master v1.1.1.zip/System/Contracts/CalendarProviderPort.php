<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface CalendarProviderPort{public function provider():string;public function upsert(int $companyId,?string $calendarRef,?string $eventRef,array $payload):array;public function cancel(int $companyId,?string $calendarRef,string $eventRef,array $payload=[]):void;}
