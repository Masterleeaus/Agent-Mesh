<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System;
use Illuminate\Support\ServiceProvider;
use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,SurfaceAuthorityPort,BookingReadPort,QuoteReadPort,BookingCommandPort,QuoteCommandPort};
use App\Extensions\TitanBookingsQuotes\System\Runtime\{DefaultActorContext,DefaultSurfaceAuthority,DatabaseBookingReadPort,DatabaseQuoteReadPort,BookingCommandAdapter,QuoteCommandAdapter};
use App\Extensions\TitanBookingsQuotes\System\Domain\Bookings\{BookingStore,DatabaseBookingStore,BookingLifecycleService};
use App\Extensions\TitanBookingsQuotes\System\Domain\Quotes\{QuoteStore,DatabaseQuoteStore,QuoteLifecycleService};
final class TitanBookingsQuotesServiceProvider extends ServiceProvider{
 public function register():void{
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanBookingsQuotes\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanBookingsQuotes\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

  $this->mergeConfigFrom(__DIR__.'/../config/bookings-quotes.php','titan-bookings-quotes');
  $this->app->bind(ActorContextPort::class,DefaultActorContext::class);$this->app->bind(SurfaceAuthorityPort::class,DefaultSurfaceAuthority::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\BookingAssignmentPort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\DatabaseBookingAssignmentPort::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\CalendarProjectionPort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\DatabaseCalendarProjectionPort::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\DispatchPort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\DatabaseDispatchPort::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\WorkerSchedulePort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\WorkforceWorkerSchedulePort::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\BookingAvailabilityPort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\DatabaseBookingAvailabilityPort::class);$this->app->bind(\App\Extensions\TitanBookingsQuotes\System\Contracts\BookingReminderPort::class,\App\Extensions\TitanBookingsQuotes\System\Runtime\DatabaseBookingReminderPort::class);$this->app->bind(BookingReadPort::class,DatabaseBookingReadPort::class);$this->app->bind(QuoteReadPort::class,DatabaseQuoteReadPort::class);
  $this->app->bind(BookingStore::class,DatabaseBookingStore::class);$this->app->bind(QuoteStore::class,DatabaseQuoteStore::class);
  $this->app->bind(BookingCommandPort::class,BookingCommandAdapter::class);$this->app->bind(QuoteCommandPort::class,QuoteCommandAdapter::class);
  $this->app->singleton(BookingLifecycleService::class);$this->app->singleton(QuoteLifecycleService::class);
 }
 public function boot():void{$this->app['router']->aliasMiddleware('titan-bq.surface',\App\Extensions\TitanBookingsQuotes\System\Http\Middleware\RequireTitanBQSurface::class);$m=__DIR__.'/../database/migrations';if(is_dir($m))$this->loadMigrationsFrom($m);$v=__DIR__.'/../resources/views';if(is_dir($v))$this->loadViewsFrom($v,'titan-bookings-quotes');foreach(['hub.php','admin.php','api.php'] as $f){$r=__DIR__.'/../routes/'.$f;if(is_file($r))$this->loadRoutesFrom($r);}}
}
