<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\WorkerSchedulePort;use Illuminate\Support\Facades\DB;
final class WorkforceWorkerSchedulePort implements WorkerSchedulePort{
 public function eligibleWorkers(int $companyId,array $booking):array{
  if(!DB::getSchemaBuilder()->hasTable('titan_workforce_workers'))return [];
  $q=DB::table('titan_workforce_workers')->where('company_id',$companyId)->where('active',true);
  if(!empty($booking['service_ref'])&&DB::getSchemaBuilder()->hasTable('titan_workforce_worker_capabilities'))$q->whereIn('worker_ref',DB::table('titan_workforce_worker_capabilities')->select('worker_ref')->where('company_id',$companyId)->where('capability_ref',(string)$booking['service_ref']));
  return array_map('strval',$q->pluck('worker_ref')->all());
 }
 public function existingWindows(int $companyId,string $workerRef,string $date):array{return DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('assigned_worker_ref',$workerRef)->whereDate('starts_at',$date)->whereNotIn('status',['cancelled'])->get()->map(fn($r)=>['start'=>(string)$r->starts_at,'end'=>(string)$r->ends_at,'status'=>(string)$r->status])->all();}
 public function capacityPolicy(int $companyId,string $workerRef):array{
  if(DB::getSchemaBuilder()->hasTable('titan_bq_worker_capacity')){$r=DB::table('titan_bq_worker_capacity')->where('company_id',$companyId)->where('worker_ref',$workerRef)->first();if($r)return ['max_per_day'=>$r->max_per_day,'max_per_slot'=>$r->max_per_slot,'enforce_conflicts'=>(bool)$r->enforce_conflicts];}
  return ['max_per_day'=>null,'max_per_slot'=>1,'enforce_conflicts'=>true];
 }
 public function workloadCounts(int $companyId,array $workerRefs,string $date):array{if(!$workerRefs)return [];$rows=DB::table('titan_bq_bookings')->selectRaw('assigned_worker_ref, COUNT(*) as c')->where('company_id',$companyId)->whereIn('assigned_worker_ref',$workerRefs)->whereDate('starts_at',$date)->whereNotIn('status',['cancelled'])->groupBy('assigned_worker_ref')->get();$out=[];foreach($rows as $r)$out[(string)$r->assigned_worker_ref]=(int)$r->c;return $out;}
}