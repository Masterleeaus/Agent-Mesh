<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
final readonly class QuoteCommand{public function __construct(public int $companyId,public string $quoteRef,public string $action,public int $expectedVersion,public string $idempotencyKey,public array $payload){}}
