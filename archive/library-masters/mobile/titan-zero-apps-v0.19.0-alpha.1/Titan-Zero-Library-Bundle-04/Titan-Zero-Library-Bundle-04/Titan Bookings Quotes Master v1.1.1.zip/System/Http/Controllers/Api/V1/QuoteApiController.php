<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Api\V1;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,QuoteReadPort,QuoteCommandPort};
final readonly class QuoteApiController{
 public function __construct(private ActorContextPort $actor,private QuoteReadPort $reads,private QuoteCommandPort $commands){}
 private function limit(Request $r):int{return min(100,max(1,(int)$r->query('limit',25)));}
 public function index(Request $r){$a=$this->actor->current();return response()->json($this->reads->page($a['company_id'],$this->limit($r),$r->query('cursor')));}
 public function show(Request $r,string $quoteRef){$a=$this->actor->current();$row=$this->reads->find($a['company_id'],$quoteRef);abort_if(!$row,404);return response()->json($row);}
 public function store(Request $r){$a=$this->actor->current();$d=$r->validate(['booking_ref'=>'nullable|string|max:64','currency'=>'required|string|size:3','lines'=>'required|array|min:1|max:100','idempotency_key'=>'required|string|max:128']);$d['quote_ref']='quo_'.bin2hex(random_bytes(12));$d['customer_ref']=$a['customer_ref'];return response()->json($this->commands->execute($a['company_id'],'quotes.create',$d,$a),201);}
 public function action(Request $r,string $quoteRef){$a=$this->actor->current();$d=$r->validate(['action'=>'required|in:send,revise,expire','expected_version'=>'required|integer|min:1','idempotency_key'=>'required|string|max:128']);$d['quote_ref']=$quoteRef;return response()->json($this->commands->execute($a['company_id'],'quotes.'.$d['action'],$d,$a));}
}
