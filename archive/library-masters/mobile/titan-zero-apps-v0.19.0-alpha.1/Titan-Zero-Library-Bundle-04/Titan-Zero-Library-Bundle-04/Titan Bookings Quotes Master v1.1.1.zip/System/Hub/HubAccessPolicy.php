<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Hub;
final readonly class HubAccessPolicy{
 public function __construct(private HubCommercialReader $reader){}
 private function owned(HubActor $a,?array $row):?array{return $row!==null&&hash_equals((string)($row['customer_ref']??''),$a->customerRef)?$row:null;}
 public function quote(HubActor $a,string $ref):?array{return $this->owned($a,$this->reader->quote($a->companyId,$ref));}
 public function booking(HubActor $a,string $ref):?array{return $this->owned($a,$this->reader->booking($a->companyId,$ref));}
 public function variation(HubActor $a,string $ref):?array{return $this->owned($a,$this->reader->variation($a->companyId,$ref));}
}
