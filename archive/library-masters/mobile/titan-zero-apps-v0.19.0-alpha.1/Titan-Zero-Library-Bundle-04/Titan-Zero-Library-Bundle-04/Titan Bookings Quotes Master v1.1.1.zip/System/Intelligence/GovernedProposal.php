<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Intelligence;
final readonly class GovernedProposal{public function __construct(public int $companyId,public string $capability,public string $aggregateRef,public string $idempotencyKey,public bool $requiresApproval=true,public string $executionState='proposed'){}}
