<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use DateTimeImmutable;use RuntimeException;
final class CalendarPayloadMapper{
 public function map(array $booking):array{
  if(empty($booking['starts_at'])||empty($booking['ends_at']))throw new RuntimeException('booking has no confirmed calendar window');
  $start=new DateTimeImmutable((string)$booking['starts_at']);$end=new DateTimeImmutable((string)$booking['ends_at']);if($end<=$start)throw new RuntimeException('invalid calendar window');
  $site=$booking['site']??null;if(is_string($site))$site=json_decode($site,true,512,JSON_THROW_ON_ERROR);
  $scope=$booking['scope']??null;if(is_string($scope))$scope=json_decode($scope,true,512,JSON_THROW_ON_ERROR);
  return ['uid'=>'titan-booking-'.$booking['company_id'].'-'.$booking['public_id'],'title'=>'Booking '.($booking['service_ref']??$booking['public_id']),'description'=>(string)($scope['summary']??''),'location'=>(string)($site['formatted_address']??$site['address']??''),'starts_at'=>$start->format(DATE_ATOM),'ends_at'=>$end->format(DATE_ATOM),'status'=>$booking['status']??'confirmed','attendee_refs'=>array_values(array_filter([(string)($booking['assigned_worker_ref']??'')])),'source'=>'titan_bookings_quotes'];}
 public function fingerprint(array $payload):string{ksort($payload);return hash('sha256',json_encode($payload,JSON_THROW_ON_ERROR|JSON_PRESERVE_ZERO_FRACTION));}
}