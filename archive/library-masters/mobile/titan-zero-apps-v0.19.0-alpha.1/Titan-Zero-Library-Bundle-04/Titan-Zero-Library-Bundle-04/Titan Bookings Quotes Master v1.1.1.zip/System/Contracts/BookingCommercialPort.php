<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface BookingCommercialPort{public function fromAcceptedQuote(int $companyId,string $quoteRef,string $actorRef,string $idempotencyKey):array;public function invoiceCompleted(int $companyId,string $bookingRef,string $idempotencyKey):array;}
