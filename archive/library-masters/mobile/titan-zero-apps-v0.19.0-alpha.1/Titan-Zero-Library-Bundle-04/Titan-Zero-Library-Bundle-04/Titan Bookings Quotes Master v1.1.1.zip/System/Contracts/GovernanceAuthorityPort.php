<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface GovernanceAuthorityPort{public function authorize(int $companyId,string $capability,array $context):bool;}
