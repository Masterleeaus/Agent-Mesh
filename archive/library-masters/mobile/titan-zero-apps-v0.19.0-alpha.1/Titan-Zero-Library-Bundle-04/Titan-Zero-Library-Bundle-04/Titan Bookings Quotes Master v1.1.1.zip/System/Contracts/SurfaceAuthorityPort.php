<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface SurfaceAuthorityPort{public function authorize(string $surface,array $actor):void;}
