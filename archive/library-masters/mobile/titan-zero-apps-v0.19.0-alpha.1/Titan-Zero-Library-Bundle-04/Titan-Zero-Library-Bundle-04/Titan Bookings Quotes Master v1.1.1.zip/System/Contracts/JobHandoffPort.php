<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface JobHandoffPort{public function request(int $companyId,string $bookingRef,array $jobRequirements,string $idempotencyKey):array;}
