<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\SurfaceAuthorityPort;
final class DefaultSurfaceAuthority implements SurfaceAuthorityPort{
 public function authorize(string $surface,array $actor):void{
  $roles=array_values(array_filter((array)($actor['roles']??[]),'is_string'));
  $customer=$actor['customer_ref']??null;
  $ok=match($surface){
   'hub'=>$customer!==null,
   'zero'=>count(array_intersect($roles,['owner','admin','manager','estimator','office']))>0,
   // Compatibility-only aliases; Agent 1 shared AppSurface normalization should resolve these before provider policy.
   'bos','command','owner','manager','business'=>count(array_intersect($roles,['owner','admin','manager','estimator','office']))>0,
   'field','worker'=>count(array_intersect($roles,['worker','crew_lead','supervisor']))>0,
   'customer'=>$customer!==null,
   'onboarding'=>count(array_intersect($roles,['owner','admin','manager','estimator','office']))>0,
   'go'=>count(array_intersect($roles,['worker','crew_lead','supervisor']))>0,
   'api'=>count(array_intersect($roles,['owner','admin','manager','estimator','office','api']))>0,
   default=>false};
  if(!$ok)abort(403,'surface authority denied');
 }
}
