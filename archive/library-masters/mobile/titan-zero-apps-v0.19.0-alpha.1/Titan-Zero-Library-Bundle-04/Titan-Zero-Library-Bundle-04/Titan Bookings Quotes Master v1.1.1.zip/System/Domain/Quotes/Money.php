<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
use InvalidArgumentException;
final readonly class Money{public function __construct(public string $currency,public int $minor){if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('currency');}}
