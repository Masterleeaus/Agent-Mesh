<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Admin;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,BookingReadPort};
final readonly class BookingController{public function __construct(private ActorContextPort $actor,private BookingReadPort $reads){}public function index(Request $r){$a=$this->actor->current();return view('titan-bookings-quotes::admin.bookings.index',['bookings'=>$this->reads->page($a['company_id'],50,$r->query('cursor'))]);}}
