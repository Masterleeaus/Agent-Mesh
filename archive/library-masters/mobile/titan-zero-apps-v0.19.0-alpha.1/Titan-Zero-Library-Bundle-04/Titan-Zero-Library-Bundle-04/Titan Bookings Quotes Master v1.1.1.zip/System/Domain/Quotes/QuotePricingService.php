<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Quotes;
use InvalidArgumentException;
final class QuotePricingService{
 public function price(string $currency,array $lines):array{
  if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('currency');
  if($lines===[]||count($lines)>100)throw new InvalidArgumentException('lines');
  $subtotal=0;$discount=0;$tax=0;$priced=[];
  foreach($lines as $line){
   $q=(string)($line['quantity']??'0');if(!preg_match('/^\d+(?:\.\d{1,3})?$/',$q))throw new InvalidArgumentException('quantity');
   [$whole,$frac]=array_pad(explode('.',$q,2),2,'');$scale=1000;$qty=((int)$whole*$scale)+(int)str_pad($frac,3,'0');
   $unit=(int)($line['unit_price_minor']??0);$disc=(int)($line['discount_minor']??0);$bps=(int)($line['tax_rate_bps']??0);
   if($qty>1000000000||$unit>1000000000000||$disc>1000000000000)throw new InvalidArgumentException('price bounds');
   if($unit<0||$disc<0||$bps<0||$bps>10000)throw new InvalidArgumentException('price');
   if($unit!==0&&$qty>intdiv(PHP_INT_MAX-500,$unit))throw new InvalidArgumentException('price overflow');
   $gross=intdiv($unit*$qty+500,$scale);if($disc>$gross)throw new InvalidArgumentException('discount');
   $net=$gross-$disc;if($bps!==0&&$net>intdiv(PHP_INT_MAX-5000,$bps))throw new InvalidArgumentException('tax overflow');$lineTax=intdiv($net*$bps+5000,10000);$total=$net+$lineTax;
   $subtotal+=$gross;$discount+=$disc;$tax+=$lineTax;$priced[]=array_merge($line,['gross_minor'=>$gross,'net_minor'=>$net,'tax_minor'=>$lineTax,'total_minor'=>$total]);
  }
  return ['currency'=>$currency,'subtotal_minor'=>$subtotal,'discount_minor'=>$discount,'tax_minor'=>$tax,'total_minor'=>$subtotal-$discount+$tax,'lines'=>$priced];
 }
}
