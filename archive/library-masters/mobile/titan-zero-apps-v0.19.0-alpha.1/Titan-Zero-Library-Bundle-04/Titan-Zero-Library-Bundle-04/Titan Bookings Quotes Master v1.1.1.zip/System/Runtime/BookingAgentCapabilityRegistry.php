<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
final class BookingAgentCapabilityRegistry{public function manifest():array{return ['agent'=>'TitanZero','domain'=>'bookings_quotes','capabilities'=>['booking.lookup','booking.availability','booking.create','booking.reschedule','booking.cancel','booking.assign','booking.complete','quote.convert','calendar.export','booking.status'],'authority'=>'governed'];}public function canExpose(string $capability):bool{return in_array($capability,$this->manifest()['capabilities'],true);}}
