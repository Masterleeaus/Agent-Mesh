<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\BookingReadPort;use Illuminate\Support\Facades\DB;
final class DatabaseBookingReadPort implements BookingReadPort{
 public function find(int $companyId,string $ref):?array{$r=DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('public_id',$ref)->first();return $r?(array)$r:null;}
 public function page(int $companyId,int $limit=25,?string $cursor=null):array{$q=DB::table('titan_bq_bookings')->where('company_id',$companyId)->orderBy('id');if($cursor!==null)$q->where('id','>',(int)$cursor);$rows=$q->limit(min(100,max(1,$limit))+1)->get()->map(fn($r)=>(array)$r)->all();$more=count($rows)>$limit;if($more)array_pop($rows);return ['data'=>$rows,'next_cursor'=>$more?(string)end($rows)['id']:null];}
 public function findForCustomer(int $companyId,string $customerRef,string $bookingRef):?array{$r=DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('customer_ref',$customerRef)->where('public_id',$bookingRef)->first();return $r?(array)$r:null;}
 public function pageForCustomer(int $companyId,string $customerRef,int $limit=25,?string $cursor=null):array{$q=DB::table('titan_bq_bookings')->where('company_id',$companyId)->where('customer_ref',$customerRef)->orderBy('id');if($cursor!==null)$q->where('id','>',(int)$cursor);$rows=$q->limit(min(100,max(1,$limit))+1)->get()->map(fn($r)=>(array)$r)->all();$more=count($rows)>$limit;if($more)array_pop($rows);return ['data'=>$rows,'next_cursor'=>$more?(string)end($rows)['id']:null];}
}
