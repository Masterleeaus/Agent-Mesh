<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use RuntimeException;
final class PublicBookingGuard{public function assert(array $i,int $renderedAt,int $now,int $min=3):void{if(trim((string)($i['_hp']??''))!=='')throw new RuntimeException('public booking rejected');if($renderedAt>0&&$now-$renderedAt<max(0,$min))throw new RuntimeException('public booking rejected');foreach(['name','email','starts_at','ends_at'] as $k)if(trim((string)($i[$k]??''))==='')throw new RuntimeException('missing public booking field');if(!filter_var((string)$i['email'],FILTER_VALIDATE_EMAIL))throw new RuntimeException('invalid email');}}
