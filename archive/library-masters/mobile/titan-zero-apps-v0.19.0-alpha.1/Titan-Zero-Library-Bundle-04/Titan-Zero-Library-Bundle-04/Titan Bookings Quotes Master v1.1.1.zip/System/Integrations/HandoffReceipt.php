<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
final readonly class HandoffReceipt{public function __construct(public string $target,public string $idempotencyKey,public string $externalRef){}}
