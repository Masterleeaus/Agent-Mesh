<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use RuntimeException;
final readonly class BookingLifecycleService{
 private const TRANSITIONS=['create'=>[null,'requested'],'scope'=>['requested','scoped'],'quote'=>['scoped','quote_pending'],'confirm'=>['quote_pending','confirmed'],'cancel'=>['requested','scoped','quote_pending','confirmed']];
 public function __construct(private BookingStore $store){}
 private static function fingerprint(string $action,array $payload):string{$normalize=function($v)use(&$normalize){if(is_array($v)){if(!array_is_list($v))ksort($v);foreach($v as $k=>$x)$v[$k]=$normalize($x);}return $v;};unset($payload['idempotency_key']);return hash('sha256',$action.'|'.json_encode($normalize($payload),JSON_THROW_ON_ERROR|JSON_PRESERVE_ZERO_FRACTION));}
 public function execute(BookingCommand $c):array{
  if(trim($c->idempotencyKey)==='')throw new RuntimeException('idempotency key required');
  if($old=$this->store->receipt($c->companyId,$c->idempotencyKey)){if(isset($old['_request_hash'])&&$old['_request_hash']!==null&&$old['_request_hash']!==self::fingerprint($c->action,$c->payload))throw new RuntimeException('idempotency key reused with different request');unset($old['_request_hash']);return $old;}
  $current=$this->store->find($c->companyId,$c->bookingRef);$version=(int)($current['version']??0);
  if($version!==$c->expectedVersion)throw new RuntimeException('stale booking version');
  $rule=self::TRANSITIONS[$c->action]??null;if(!$rule)throw new RuntimeException('illegal booking transition');
  $status=$current['status']??null;
  if($c->action==='cancel'){if(!in_array($status,$rule,true))throw new RuntimeException('illegal booking transition');$nextStatus='cancelled';}else{if($rule[0]!==$status)throw new RuntimeException('illegal booking transition');$nextStatus=$rule[1];}
  $next=array_merge($current??[], $c->payload, ['company_id'=>$c->companyId,'public_id'=>$c->bookingRef,'status'=>$nextStatus,'version'=>$version+1]);
  foreach(['tenant'.'_company_id','worker_id','schedule_id','invoice_id','payment_id'] as $forbidden)unset($next[$forbidden]);
  return $this->store->commit($c,$next);
 }
}
