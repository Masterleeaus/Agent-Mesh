<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Admin;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,QuoteReadPort};
final readonly class QuoteController{
 public function __construct(private ActorContextPort $actor,private QuoteReadPort $reads){}
 public function index(Request $r){$a=$this->actor->current();return view('titan-bookings-quotes::admin.quotes.index',['quotes'=>$this->reads->page($a['company_id'],50,$r->query('cursor'))]);}
 public function builder(Request $r){$this->actor->current();return view('titan-bookings-quotes::admin.quotes.builder');}
 public function approvals(Request $r){$a=$this->actor->current();return view('titan-bookings-quotes::admin.approvals.index',['quotes'=>$this->reads->page($a['company_id'],100,null)]);}
 public function settings(Request $r){$this->actor->current();return view('titan-bookings-quotes::admin.settings.index');}
}
