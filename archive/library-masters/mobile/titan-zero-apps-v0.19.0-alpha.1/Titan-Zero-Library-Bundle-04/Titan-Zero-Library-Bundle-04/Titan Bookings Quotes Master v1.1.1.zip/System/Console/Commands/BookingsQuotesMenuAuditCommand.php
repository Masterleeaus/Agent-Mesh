<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Console\Commands;
use Illuminate\Console\Command;
final class BookingsQuotesMenuAuditCommand extends Command{
 protected $signature='titan-bookings-quotes:menu-audit';protected $description='Report canonical Titan Bookings & Quotes menu entries without overwriting administrator menu state';
 public function handle():int{$this->line((string)file_get_contents(__DIR__.'/../../../resources/navigation.json'));return self::SUCCESS;}
}
