<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Hub;
final readonly class HubActor{public function __construct(public int $companyId,public string $customerRef,public string $actorRef){}}
