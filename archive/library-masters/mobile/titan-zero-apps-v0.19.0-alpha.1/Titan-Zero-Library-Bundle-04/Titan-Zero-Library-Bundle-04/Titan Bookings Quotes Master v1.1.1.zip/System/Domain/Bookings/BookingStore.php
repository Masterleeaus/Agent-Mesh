<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
interface BookingStore{public function find(int $companyId,string $bookingRef):?array;public function receipt(int $companyId,string $idempotencyKey):?array;public function commit(BookingCommand $command,array $next):array;}
