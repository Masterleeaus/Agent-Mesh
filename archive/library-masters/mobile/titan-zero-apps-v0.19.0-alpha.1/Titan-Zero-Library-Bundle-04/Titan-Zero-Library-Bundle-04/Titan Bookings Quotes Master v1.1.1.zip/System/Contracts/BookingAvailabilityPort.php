<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface BookingAvailabilityPort{public function slots(int $companyId,array $request):array;public function assertAssignable(int $companyId,string $bookingRef,string $workerRef):void;}
