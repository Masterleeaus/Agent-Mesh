<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
final class ApprovalPolicy{public function requiresApproval(?float $value,float $threshold=1000):bool{return $value!==null&&$value>=$threshold;}public function initialStatus(?float $value,float $threshold=1000):string{return $this->requiresApproval($value,$threshold)?'pending_approval':'draft';}public function timeoutHours(int $hours=24):int{return max(1,$hours);}}
