<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
final class CommandFingerprint{
 public static function make(string $action,array $payload):string{$normalize=function($v)use(&$normalize){if(is_array($v)){if(!array_is_list($v))ksort($v);foreach($v as $k=>$x)$v[$k]=$normalize($x);}return $v;};unset($payload['idempotency_key']);return hash('sha256',$action.'|'.json_encode($normalize($payload),JSON_THROW_ON_ERROR|JSON_PRESERVE_ZERO_FRACTION));}
}
