<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
interface HandoffRegistry{
 public function receipt(int $companyId,string $target,string $key):?HandoffReceipt;
 public function reserve(HandoffRequest $request):?string;
 public function deliver(int $companyId,string $aggregateRef,HandoffReceipt $receipt,string $leaseToken):void;
 public function fail(HandoffRequest $request,string $error,string $leaseToken):void;
}
