<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
interface HandoffPort{public function send(HandoffRequest $request):HandoffReceipt;}
