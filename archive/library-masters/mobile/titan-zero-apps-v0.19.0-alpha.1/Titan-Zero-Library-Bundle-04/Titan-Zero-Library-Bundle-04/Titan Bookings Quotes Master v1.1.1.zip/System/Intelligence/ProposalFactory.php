<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Intelligence;
final class ProposalFactory{
 public function fromFinding(array $f):GovernedProposal{$company=(int)$f['company_id'];$kind=(string)$f['kind'];$ref=(string)$f['aggregate_ref'];$key='bq-proposal:'.hash('sha256',$company.'|'.$kind.'|'.$ref);return new GovernedProposal($company,'front-office.remediate.'.$kind,$ref,$key,true,'proposed');}
}
