<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
final readonly class HandoffRequest{public function __construct(public int $companyId,public string $target,public string $aggregateRef,public string $idempotencyKey,public array $payload){}}
