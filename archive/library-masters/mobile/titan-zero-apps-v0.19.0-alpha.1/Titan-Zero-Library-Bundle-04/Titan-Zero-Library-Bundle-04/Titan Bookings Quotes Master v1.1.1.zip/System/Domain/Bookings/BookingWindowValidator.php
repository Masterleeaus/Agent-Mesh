<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use DateTimeImmutable;use DateTimeZone;use InvalidArgumentException;
final class BookingWindowValidator{
 public function validate(array $windows,string $timezone='UTC'):array{
  if($windows===[]||count($windows)>5)throw new InvalidArgumentException('booking windows required');
  $tz=new DateTimeZone($timezone);$out=[];
  foreach($windows as $i=>$w){$start=new DateTimeImmutable((string)($w['start']??''),$tz);$end=new DateTimeImmutable((string)($w['end']??''),$tz);if($end<=$start)throw new InvalidArgumentException('end must be after start');if($end->getTimestamp()-$start->getTimestamp()>86400)throw new InvalidArgumentException('maximum booking window is 24 hours');$out[]=['start'=>$start->setTimezone(new DateTimeZone('UTC'))->format(DATE_ATOM),'end'=>$end->setTimezone(new DateTimeZone('UTC'))->format(DATE_ATOM),'i'=>$i];}
  usort($out,fn($a,$b)=>strcmp($a['start'],$b['start']));for($i=1;$i<count($out);$i++)if($out[$i]['start']<$out[$i-1]['end'])throw new InvalidArgumentException('booking window overlap');
  return array_map(fn($x)=>['start'=>$x['start'],'end'=>$x['end']],$out);
 }
}
