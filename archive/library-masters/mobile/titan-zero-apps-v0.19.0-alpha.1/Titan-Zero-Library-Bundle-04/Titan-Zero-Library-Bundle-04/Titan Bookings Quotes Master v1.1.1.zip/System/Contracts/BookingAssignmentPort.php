<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface BookingAssignmentPort{public function assign(int $companyId,string $bookingRef,?string $workerRef,string $actorRef,?string $note=null):array;public function autoAssign(int $companyId,string $bookingRef,string $strategy='least_busy'):array;}
