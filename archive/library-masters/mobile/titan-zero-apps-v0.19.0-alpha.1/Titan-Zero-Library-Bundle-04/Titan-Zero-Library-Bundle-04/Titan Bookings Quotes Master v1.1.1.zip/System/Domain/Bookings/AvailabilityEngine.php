<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use DateInterval;use DateTimeImmutable;use DateTimeZone;use RuntimeException;
final class AvailabilityEngine{
 public function slots(array $workingWindows,array $busyWindows,int $durationMinutes,int $stepMinutes=30,int $bufferBefore=0,int $bufferAfter=0):array{
  if($durationMinutes<1||$stepMinutes<1)throw new RuntimeException('invalid availability duration');
  $out=[];
  foreach($workingWindows as $w){$start=new DateTimeImmutable((string)$w['start']);$end=new DateTimeImmutable((string)$w['end']);if($end<=$start)continue;
   for($cursor=$start;$cursor->modify("+$durationMinutes minutes")<=$end;$cursor=$cursor->modify("+$stepMinutes minutes")){
    $finish=$cursor->modify("+$durationMinutes minutes");$blockedStart=$cursor->modify("-$bufferBefore minutes");$blockedEnd=$finish->modify("+$bufferAfter minutes");$conflict=false;
    foreach($busyWindows as $b){$bs=new DateTimeImmutable((string)$b['start']);$be=new DateTimeImmutable((string)$b['end']);if($bs<$blockedEnd&&$be>$blockedStart){$conflict=true;break;}}
    if(!$conflict)$out[]=['start'=>$cursor->format(DATE_ATOM),'end'=>$finish->format(DATE_ATOM)];
   }
  }return $out;
 }
}