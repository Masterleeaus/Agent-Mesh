<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use App\Extensions\TitanBookingsQuotes\System\Contracts\ActorContextPort;use RuntimeException;
final class DefaultActorContext implements ActorContextPort{
 public function current():array{$u=auth()->user();if(!$u)throw new RuntimeException('authenticated actor required');$company=(int)($u->company_id??0);if($company<1)throw new RuntimeException('actor company unavailable');$customer=$u->customer_ref??null;if($customer!==null&&trim((string)$customer)==='')throw new RuntimeException('customer authority unavailable');$roles=method_exists($u,'getRoleNames')?$u->getRoleNames()->all():(array)($u->roles??[]);return ['roles'=>array_map('strval',$roles),'company_id'=>$company,'actor_ref'=>(string)($u->public_id??$u->id??''),'customer_ref'=>$customer===null?null:(string)$customer];}
}
