<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface CommandBusPort{public function dispatch(string $capability,array $payload,array $context):array;}
