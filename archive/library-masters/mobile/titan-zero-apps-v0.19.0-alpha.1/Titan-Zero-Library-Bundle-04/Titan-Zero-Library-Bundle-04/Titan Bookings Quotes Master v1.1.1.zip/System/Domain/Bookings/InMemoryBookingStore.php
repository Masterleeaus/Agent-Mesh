<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
final class InMemoryBookingStore implements BookingStore{
 private array $bookings=[],$receipts=[];
 public function find(int $companyId,string $bookingRef):?array{return $this->bookings[$companyId][$bookingRef]??null;}
 public function receipt(int $companyId,string $idempotencyKey):?array{return $this->receipts[$companyId][$idempotencyKey]??null;}
 public function commit(BookingCommand $c,array $next):array{$this->bookings[$c->companyId][$c->bookingRef]=$next;$this->receipts[$c->companyId][$c->idempotencyKey]=$next;return $next;}
}
