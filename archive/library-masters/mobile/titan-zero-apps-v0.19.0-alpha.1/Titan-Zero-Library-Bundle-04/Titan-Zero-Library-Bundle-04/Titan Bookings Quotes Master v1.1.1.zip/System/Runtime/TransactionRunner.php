<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
use Illuminate\Database\QueryException;use Illuminate\Support\Facades\DB;use Throwable;
final class TransactionRunner{
 public static function run(callable $fn,int $attempts=3):mixed{
  $try=0;begin:try{return DB::transaction($fn);}catch(QueryException $e){$try++;$code=(string)($e->errorInfo[0]??$e->getCode());$driver=(int)($e->errorInfo[1]??0);$retry=in_array($code,['40001','40P01'],true)||in_array($driver,[1205,1213],true);if($retry&&$try<$attempts){usleep(25000*(2**($try-1)));goto begin;}throw $e;}
 }
}
