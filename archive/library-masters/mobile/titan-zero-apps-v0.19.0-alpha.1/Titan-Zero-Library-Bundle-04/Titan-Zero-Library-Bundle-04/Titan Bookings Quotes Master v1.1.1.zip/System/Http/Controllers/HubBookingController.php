<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Http\Controllers;
use Illuminate\Http\Request;use App\Extensions\TitanBookingsQuotes\System\Contracts\{ActorContextPort,BookingReadPort,BookingCommandPort};
final readonly class HubBookingController{
 public function __construct(private ActorContextPort $actor,private BookingReadPort $reads,private BookingCommandPort $commands){}
 public function index(Request $r){$a=$this->actor->current();if(($a['customer_ref']??null)===null)abort(403,'customer authority unavailable');return view('titan-bookings-quotes::hub.bookings.index',['bookings'=>$this->reads->pageForCustomer($a['company_id'],(string)$a['customer_ref'],25,null)['data']]);}
 private function owned(array $a,string $ref):array{$b=$this->reads->findForCustomer($a['company_id'],(string)$a['customer_ref'],$ref);abort_if(!$b,404);return $b;}
 public function store(Request $r){$a=$this->actor->current();if(($a['customer_ref']??null)===null)abort(403,'customer authority unavailable');$d=$r->validate(['service_ref'=>'nullable|string|max:128','site'=>'required|array','requested_windows'=>'required|array|min:1|max:5','requested_windows.*.start'=>'required|date','requested_windows.*.end'=>'required|date|after:requested_windows.*.start','notes'=>'nullable|string|max:4000','idempotency_key'=>'required|string|max:128']);$d['booking_ref']='bkg_'.bin2hex(random_bytes(12));$d['customer_ref']=$a['customer_ref'];return response()->json($this->commands->execute($a['company_id'],'bookings.create',$d,$a),201);}
}
