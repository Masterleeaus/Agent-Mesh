<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Signals;
final class FrontOfficeSignalProjector{
 private const ALLOWED=['company_id','kind','aggregate_ref','severity','total_minor','currency'];
 public function project(array $fact):array{$out=[];foreach(self::ALLOWED as $k)if(array_key_exists($k,$fact))$out[$k]=$fact[$k];return $out;}
}
