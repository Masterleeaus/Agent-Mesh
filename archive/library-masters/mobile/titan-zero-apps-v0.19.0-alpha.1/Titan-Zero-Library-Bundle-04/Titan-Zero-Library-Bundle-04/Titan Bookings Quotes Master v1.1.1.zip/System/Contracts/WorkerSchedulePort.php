<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface WorkerSchedulePort{public function eligibleWorkers(int $companyId,array $booking):array;public function existingWindows(int $companyId,string $workerRef,string $date):array;public function capacityPolicy(int $companyId,string $workerRef):array;public function workloadCounts(int $companyId,array $workerRefs,string $date):array;}
