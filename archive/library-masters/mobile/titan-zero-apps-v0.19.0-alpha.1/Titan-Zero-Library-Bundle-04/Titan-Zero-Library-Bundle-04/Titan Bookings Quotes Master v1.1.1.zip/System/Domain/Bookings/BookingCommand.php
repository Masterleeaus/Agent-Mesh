<?php
declare(strict_types=1);
namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
final readonly class BookingCommand{
 public function __construct(public int $companyId,public string $bookingRef,public string $action,public int $expectedVersion,public string $idempotencyKey,public array $payload){}
}
