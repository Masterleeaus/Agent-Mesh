<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Domain\Bookings;
use DateTimeImmutable;use RuntimeException;
final class RecurrenceExpander{
 public function expand(string $start,string $end,array $rule,int $max=366):array{$s=new DateTimeImmutable($start);$e=new DateTimeImmutable($end);if($e<=$s)throw new RuntimeException('invalid recurrence window');$type=(string)($rule['type']??'');$every=max(1,(int)($rule['every']??1));$cycles=min($max,max(0,(int)($rule['cycles']??0)));if(!in_array($type,['day','week','month','year'],true))throw new RuntimeException('unsupported recurrence type');$out=[];$cs=$s;$ce=$e;for($i=0;$i<$cycles;$i++){$out[]=['sequence'=>$i+1,'start'=>$cs->format(DATE_ATOM),'end'=>$ce->format(DATE_ATOM)];$cs=$cs->modify("+$every $type");$ce=$ce->modify("+$every $type");}return $out;}
}