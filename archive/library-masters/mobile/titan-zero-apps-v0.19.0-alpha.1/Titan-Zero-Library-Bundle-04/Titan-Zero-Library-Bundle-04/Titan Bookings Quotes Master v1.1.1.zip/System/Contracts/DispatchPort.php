<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Contracts;
interface DispatchPort{public function move(int $companyId,string $bookingRef,?string $workerRef,string $startsAt,string $endsAt,string $actorRef,string $note=''):array;public function board(int $companyId,string $date):array;}
