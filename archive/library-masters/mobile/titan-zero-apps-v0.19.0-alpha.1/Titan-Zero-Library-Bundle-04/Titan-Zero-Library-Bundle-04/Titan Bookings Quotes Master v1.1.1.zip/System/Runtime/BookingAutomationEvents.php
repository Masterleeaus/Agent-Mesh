<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Runtime;
final class BookingAutomationEvents{public function name():string{return 'booking.lifecycle';}public function events():array{return ['booking.requested','booking.completed','booking.cancelled','booking.approval.requested','booking.approval.decided','quote.accepted','schedule.assigned','schedule.rescheduled','booking.no_show','booking.recurring.instance_created'];}}
