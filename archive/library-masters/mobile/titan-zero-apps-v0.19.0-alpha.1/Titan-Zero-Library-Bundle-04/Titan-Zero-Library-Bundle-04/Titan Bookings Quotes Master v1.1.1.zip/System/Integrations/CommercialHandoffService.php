<?php
declare(strict_types=1);namespace App\Extensions\TitanBookingsQuotes\System\Integrations;
use RuntimeException;use Throwable;
final readonly class CommercialHandoffService{
 public function __construct(private HandoffRegistry $registry,private array $ports){}
 public function dispatch(HandoffRequest $r):HandoffReceipt{
  if(trim($r->idempotencyKey)==='')throw new RuntimeException('idempotency key required');
  if($old=$this->registry->receipt($r->companyId,$r->target,$r->idempotencyKey))return $old;
  $port=$this->ports[$r->target]??null;if(!$port instanceof HandoffPort)throw new RuntimeException($r->target.' integration unavailable');
  if(!($leaseToken=$this->registry->reserve($r))){if($old=$this->registry->receipt($r->companyId,$r->target,$r->idempotencyKey))return $old;throw new RuntimeException('handoff already in progress');}
  try{$receipt=$port->send($r);if(trim($receipt->externalRef)==='')throw new RuntimeException('handoff returned no external receipt');$this->registry->deliver($r->companyId,$r->aggregateRef,$receipt,$leaseToken);return $receipt;}catch(Throwable $e){$this->registry->fail($r,$e->getMessage(),$leaseToken);throw $e;}
 }
}
