<?php
declare(strict_types=1);
return [
 'enabled'=>env('TITAN_BOOKINGS_QUOTES_ENABLED',true),
 'tenant_key'=>'company_id',
 'api_default_page'=>25,
 'api_max_page'=>100,
 'legacy_import_enabled'=>env('TITAN_BOOKINGS_QUOTES_LEGACY_IMPORT_ENABLED',false),
];
