<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{
  Schema::table('titan_bq_bookings',function(Blueprint $t){
   if(!Schema::hasColumn('titan_bq_bookings','starts_at'))$t->timestampTz('starts_at')->nullable()->index();
   if(!Schema::hasColumn('titan_bq_bookings','ends_at'))$t->timestampTz('ends_at')->nullable();
   if(!Schema::hasColumn('titan_bq_bookings','assigned_worker_ref'))$t->string('assigned_worker_ref',128)->nullable()->index();
   if(!Schema::hasColumn('titan_bq_bookings','assignment_status'))$t->string('assignment_status',24)->default('unassigned');
  });
  if(!Schema::hasTable('titan_bq_booking_assignments'))Schema::create('titan_bq_booking_assignments',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->string('booking_public_id',64);$t->string('from_worker_ref',128)->nullable();$t->string('to_worker_ref',128)->nullable();$t->string('action',32);$t->string('actor_ref',128);$t->text('note')->nullable();$t->timestamps();$t->index(['company_id','booking_public_id','id']);});
  if(!Schema::hasTable('titan_bq_calendar_links'))Schema::create('titan_bq_calendar_links',function(Blueprint $t){$t->id();$t->unsignedBigInteger('company_id');$t->string('booking_public_id',64);$t->string('provider',64)->default('titan');$t->string('calendar_ref',191)->nullable();$t->string('event_ref',191)->nullable();$t->string('sync_status',32)->default('pending');$t->string('sync_fingerprint',64)->nullable();$t->json('payload_snapshot')->nullable();$t->text('last_error')->nullable();$t->timestampTz('last_synced_at')->nullable();$t->timestamps();$t->unique(['company_id','booking_public_id','provider','calendar_ref'],'titan_bq_calendar_link_unique');});
 }
 public function down():void{Schema::dropIfExists('titan_bq_calendar_links');Schema::dropIfExists('titan_bq_booking_assignments');}
};