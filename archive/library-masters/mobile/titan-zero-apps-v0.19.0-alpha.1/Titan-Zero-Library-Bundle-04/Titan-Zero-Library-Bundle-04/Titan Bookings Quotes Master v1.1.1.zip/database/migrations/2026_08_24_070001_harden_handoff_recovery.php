<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{if(!Schema::hasTable('titan_bq_handoffs'))return;Schema::table('titan_bq_handoffs',function(Blueprint $t){
  if(!Schema::hasColumn('titan_bq_handoffs','lease_token'))$t->string('lease_token',64)->nullable()->after('lease_expires_at');
  if(!Schema::hasColumn('titan_bq_handoffs','next_attempt_at'))$t->timestampTz('next_attempt_at')->nullable()->after('lease_token');
  if(!Schema::hasColumn('titan_bq_handoffs','dead_lettered'))$t->boolean('dead_lettered')->default(false)->after('next_attempt_at');
 });}
 public function down():void{/* Safe additive rollback; dropIfExists is intentionally not used because this migration alters an existing owned table. */if(!Schema::hasTable('titan_bq_handoffs'))return;Schema::table('titan_bq_handoffs',function(Blueprint $t){foreach(['dead_lettered','next_attempt_at','lease_token'] as $c)if(Schema::hasColumn('titan_bq_handoffs',$c))$t->dropColumn($c);});}
};
