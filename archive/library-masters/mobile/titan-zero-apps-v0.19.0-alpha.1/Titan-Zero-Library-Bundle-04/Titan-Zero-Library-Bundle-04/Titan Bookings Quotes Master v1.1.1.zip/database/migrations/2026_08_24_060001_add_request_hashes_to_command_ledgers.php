<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{
  Schema::table('titan_bq_booking_events',fn(Blueprint $t)=>$t->char('request_hash',64)->nullable()->after('idempotency_key'));
  Schema::table('titan_bq_quote_commands',fn(Blueprint $t)=>$t->char('request_hash',64)->nullable()->after('idempotency_key'));
  Schema::table('titan_bq_quote_versions',function(Blueprint $t){$t->unsignedInteger('parent_version')->nullable()->after('version');$t->unsignedInteger('supersedes_version')->nullable()->after('parent_version');});
  Schema::table('titan_bq_handoffs',fn(Blueprint $t)=>$t->timestampTz('lease_expires_at')->nullable()->after('status'));
 }
 public function down():void{/* Existing tables are altered; dropIfExists is intentionally not used for owned parent tables. */
  Schema::table('titan_bq_handoffs',fn(Blueprint $t)=>$t->dropColumn('lease_expires_at'));
  Schema::table('titan_bq_quote_versions',fn(Blueprint $t)=>$t->dropColumn(['parent_version','supersedes_version']));
  Schema::table('titan_bq_quote_commands',fn(Blueprint $t)=>$t->dropColumn('request_hash'));
  Schema::table('titan_bq_booking_events',fn(Blueprint $t)=>$t->dropColumn('request_hash'));
 }
};
