<?php
use Illuminate\Support\Facades\Route;
use App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Admin\{BookingController,QuoteController,CommercialTimelineController};
Route::prefix('titan-zero/bookings-quotes')->middleware(['web','auth'])->middleware('titan-bq.surface:zero')->group(function():void{
 Route::get('/bookings',[BookingController::class,'index'])->name('titan-bq.admin.bookings');
 Route::get('/quotes',[QuoteController::class,'index'])->name('titan-bq.admin.quotes');
 Route::get('/quotes/builder',[QuoteController::class,'builder'])->name('titan-bq.admin.quote-builder');
 Route::get('/approvals',[QuoteController::class,'approvals'])->name('titan-bq.admin.approvals');
 Route::get('/timeline',[CommercialTimelineController::class,'index'])->name('titan-bq.admin.timeline');
 Route::get('/settings',[QuoteController::class,'settings'])->name('titan-bq.admin.settings');
});
