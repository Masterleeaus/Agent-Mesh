<?php
use Illuminate\Support\Facades\Route;
use App\Extensions\TitanBookingsQuotes\System\Http\Controllers\HubBookingController;
use App\Extensions\TitanBookingsQuotes\System\Http\Controllers\HubQuoteController;
Route::prefix('titan-hub/bookings-quotes')->middleware(['web','auth'])->middleware('titan-bq.surface:hub')->group(function():void{
 Route::get('/bookings',[HubBookingController::class,'index'])->name('titan-bq.hub.bookings');
 Route::post('/bookings',[HubBookingController::class,'store'])->name('titan-bq.hub.bookings.store');
 Route::get('/quotes/{quoteRef}',[HubQuoteController::class,'show'])->name('titan-bq.hub.quotes.show');
 Route::post('/quotes/{quoteRef}/decision',[HubQuoteController::class,'decision'])->name('titan-bq.hub.quotes.decision');
 Route::post('/variations/{variationRef}/decision',[HubQuoteController::class,'variationDecision'])->name('titan-bq.hub.variations.decision');
});
