<?php
use Illuminate\Support\Facades\Route;
use App\Extensions\TitanBookingsQuotes\System\Http\Controllers\Api\V1\{BookingApiController,QuoteApiController};
Route::prefix('api/v1/titan-bookings-quotes')->middleware(['api','auth'])->middleware('titan-bq.surface:api')->group(function():void{
 Route::get('/bookings',[BookingApiController::class,'index']);Route::get('/bookings/{bookingRef}',[BookingApiController::class,'show']);
 Route::post('/bookings',[BookingApiController::class,'store']);
 Route::get('/quotes',[QuoteApiController::class,'index']);Route::get('/quotes/{quoteRef}',[QuoteApiController::class,'show']);
 Route::post('/quotes',[QuoteApiController::class,'store']);Route::post('/quotes/{quoteRef}/actions',[QuoteApiController::class,'action']);
});
