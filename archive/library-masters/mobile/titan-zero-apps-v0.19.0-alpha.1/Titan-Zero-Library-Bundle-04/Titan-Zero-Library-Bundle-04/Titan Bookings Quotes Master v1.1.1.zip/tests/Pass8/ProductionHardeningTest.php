<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$prod='';foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System')) as $f){if($f->isFile()&&$f->getExtension()==='php')$prod.=file_get_contents($f->getPathname())."\n";}
$t->assert(!str_contains($prod,'tenant'.'_company_id'),'no retired company key in production');
$t->assert(!preg_match('/DB::table\([\'"](?:jobs|schedules|shifts|invoices|payments|transactions|customers|users)[\'"]/', $prod),'no peer private table coupling');
$t->assert(!preg_match('/\b(?:dd|dump|var_dump)\s*\(/',$prod),'no debug residue');
$t->assert(!preg_match('/\b(?:TODO|FIXME|HACK)\b/i',$prod),'no unfinished markers');
$t->finish('Pass8 production hardening');
