<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/database/migrations/2026_08_24_070001_harden_handoff_recovery.php');
foreach(['Schema::hasColumn','lease_token','next_attempt_at','dead_lettered'] as $x)$t->assert(str_contains($s,$x),'migration guard '.$x);
$t->finish('Pass13 migration upgrade safety');
