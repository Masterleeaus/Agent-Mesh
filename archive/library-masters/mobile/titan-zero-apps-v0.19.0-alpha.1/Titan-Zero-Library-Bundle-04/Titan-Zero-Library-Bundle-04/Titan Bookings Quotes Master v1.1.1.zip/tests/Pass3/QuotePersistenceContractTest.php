<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$req=['database/migrations/2026_08_22_020001_create_titan_bq_quotes.php','database/migrations/2026_08_22_020002_create_titan_bq_quote_versions.php','database/migrations/2026_08_22_020003_create_titan_bq_quote_lines.php','database/migrations/2026_08_22_020004_create_titan_bq_quote_acceptances.php','database/migrations/2026_08_22_020005_create_titan_bq_variations.php'];
foreach($req as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$all='';foreach(glob($root.'/database/migrations/*.php')?:[] as $f)$all.=file_get_contents($f);
$t->assert(!str_contains($all,'tenant'.'_company_id'),'company_id only');
$t->assert(str_contains($all,"unique(['company_id','public_id']"),'opaque public IDs scoped');
$t->assert(str_contains($all,"unique(['company_id','quote_public_id','version']"),'quote versions unique');
$t->assert(str_contains($all,"unique(['company_id','idempotency_key']"),'idempotency company scoped');
$t->finish('Pass3 quote persistence');
