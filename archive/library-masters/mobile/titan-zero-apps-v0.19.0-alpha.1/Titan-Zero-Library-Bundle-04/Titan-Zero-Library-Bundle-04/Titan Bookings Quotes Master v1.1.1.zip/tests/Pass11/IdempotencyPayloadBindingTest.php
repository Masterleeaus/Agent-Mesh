<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['database/migrations/2026_08_24_060001_add_request_hashes_to_command_ledgers.php','System/Runtime/CommandFingerprint.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$b=(string)file_get_contents($root.'/System/Domain/Bookings/DatabaseBookingStore.php');$q=(string)file_get_contents($root.'/System/Domain/Quotes/DatabaseQuoteStore.php');
foreach([$b,$q] as $s){$t->assert(str_contains($s,'request_hash'),'request hash persisted');$t->assert(str_contains($s,'request_hash'),'mismatch fails closed');}
$t->finish('Pass11 idempotency payload binding');
