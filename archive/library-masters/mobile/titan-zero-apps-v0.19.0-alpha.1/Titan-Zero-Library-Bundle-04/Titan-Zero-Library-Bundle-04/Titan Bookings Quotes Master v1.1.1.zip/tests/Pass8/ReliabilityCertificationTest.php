<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$handoff=(string)file_get_contents($root.'/database/migrations/2026_08_22_030001_create_titan_bq_handoffs.php');
$signal=(string)file_get_contents($root.'/database/migrations/2026_08_22_040001_create_titan_bq_signal_outbox.php');
$t->assert(str_contains($handoff,"unique(['company_id','target','idempotency_key']"),'handoff dedupe');
$t->assert(str_contains($signal,"unique(['company_id','dedupe_key']"),'signal dedupe');
$t->assert(str_contains($signal,"index(['company_id','status','available_at','id']"),'signal recovery index');
$quote=(string)file_get_contents($root.'/System/Domain/Quotes/QuoteLifecycleService.php');
$booking=(string)file_get_contents($root.'/System/Domain/Bookings/BookingLifecycleService.php');
$t->assert(str_contains($quote,'expectedVersion')&&str_contains($booking,'expectedVersion'),'optimistic concurrency retained');
$t->finish('Pass8 reliability certification');
