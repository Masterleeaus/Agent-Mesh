<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';require dirname(__DIR__,2).'/System/Domain/Quotes/QuotePricingService.php';
use App\Extensions\TitanBookingsQuotes\System\Domain\Quotes\QuotePricingService;$t=new TitanBQTest();$s=new QuotePricingService();
try{$s->price('AUD',[['quantity'=>'999999999999999.999','unit_price_minor'=>PHP_INT_MAX,'discount_minor'=>0,'tax_rate_bps'=>10000]]);$t->assert(false,'overflow accepted');}catch(InvalidArgumentException $e){$t->assert(true,'overflow rejected');}
try{$s->price('AUD',[]);$t->assert(false,'empty quote accepted');}catch(InvalidArgumentException $e){$t->assert(true,'empty quote rejected');}
$t->finish('Pass10 pricing bounds');
