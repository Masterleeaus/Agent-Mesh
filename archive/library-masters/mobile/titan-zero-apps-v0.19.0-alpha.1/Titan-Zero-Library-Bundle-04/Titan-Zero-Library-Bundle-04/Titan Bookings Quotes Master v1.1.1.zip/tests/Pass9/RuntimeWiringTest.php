<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Contracts/ActorContextPort.php','System/Runtime/DefaultActorContext.php','System/Domain/Quotes/DatabaseQuoteStore.php','System/Runtime/DatabaseBookingReadPort.php','System/Runtime/DatabaseQuoteReadPort.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$provider=(string)file_get_contents($root.'/System/TitanBookingsQuotesServiceProvider.php');
foreach(['ActorContextPort','BookingReadPort','QuoteReadPort','BookingCommandPort','QuoteCommandPort'] as $c)$t->assert(str_contains($provider,$c),'provider binding '.$c);
$t->finish('Pass9 runtime wiring');
