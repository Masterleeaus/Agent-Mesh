<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$pricing=(string)file_get_contents($root.'/System/Domain/Quotes/QuotePricingService.php');
$t->assert(!str_contains($pricing,'float'),'pricing must avoid floating point');
$life=(string)file_get_contents($root.'/System/Domain/Quotes/QuoteLifecycleService.php');
$t->assert(str_contains($life,"'expire'"),'expiry transition required');
$t->assert(str_contains($life,"'revise'"),'requote/version lineage transition required');
$all='';foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System')) as $f){if($f->isFile()&&$f->getExtension()==='php')$all.=file_get_contents($f->getPathname());}
$t->assert(!preg_match('/DB::table\([\'\"](?:invoices|payments|customers|users|schedules|shifts)[\'\"]/', $all),'quote engine must not access peer private tables');
$t->finish('Pass3 quote hardening');
