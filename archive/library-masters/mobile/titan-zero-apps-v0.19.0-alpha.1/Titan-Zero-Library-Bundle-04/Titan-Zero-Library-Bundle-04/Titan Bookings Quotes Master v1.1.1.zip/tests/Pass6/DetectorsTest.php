<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['FrontOfficeDetector','FrontOfficeFinding'] as $f)require dirname(__DIR__,2).'/System/Intelligence/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Intelligence\FrontOfficeDetector;
$t=new TitanBQTest();$d=new FrontOfficeDetector(new DateTimeImmutable('2026-08-22T12:00:00Z'));
$f=$d->inspect([
 ['type'=>'quote','company_id'=>2,'public_id'=>'q1','status'=>'sent','sent_at'=>'2026-08-10T00:00:00Z','valid_until'=>'2026-08-23T00:00:00Z'],
 ['type'=>'booking','company_id'=>2,'public_id'=>'b1','status'=>'requested','scope'=>null,'created_at'=>'2026-08-20T00:00:00Z'],
 ['type'=>'handoff','company_id'=>2,'public_id'=>'h1','status'=>'failed','attempts'=>3],
]);
$keys=array_column(array_map(fn($x)=>$x->toArray(),$f),'kind');
foreach(['quote.stale','quote.expiring','booking.scope_missing','handoff.failed'] as $k)$t->assert(in_array($k,$keys,true),'missing '.$k);
$t->assert($d->inspect([])===[],'deterministic empty');
$t->finish('Pass6 detectors');
