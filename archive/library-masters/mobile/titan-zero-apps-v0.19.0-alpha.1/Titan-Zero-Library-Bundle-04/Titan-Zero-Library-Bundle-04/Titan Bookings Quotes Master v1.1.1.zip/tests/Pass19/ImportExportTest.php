<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingTransferService.php');$t->assert(str_contains($s,"where('company_id',$"."companyId)"),'transfer company scoped');$t->assert(str_contains($s,'ALLOWED'),'import allowlist');$t->finish('Pass19 transfer');
