<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Domain/Bookings/PublicBookingGuard.php'),'public guard');$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/PublicBookingService.php'),'public booking service');$t->finish('Pass17 public booking');
