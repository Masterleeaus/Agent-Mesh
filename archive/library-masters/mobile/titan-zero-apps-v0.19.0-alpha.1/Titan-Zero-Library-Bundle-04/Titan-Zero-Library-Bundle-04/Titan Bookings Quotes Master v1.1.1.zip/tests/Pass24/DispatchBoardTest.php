<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingDispatchBoardService.php');$t->assert(str_contains($s,"where('company_id',$"."companyId)"),'dispatch company scoped');$t->assert(!str_contains($s,'workspace'),'no workspace boundary');$t->finish('Pass24 dispatch');
