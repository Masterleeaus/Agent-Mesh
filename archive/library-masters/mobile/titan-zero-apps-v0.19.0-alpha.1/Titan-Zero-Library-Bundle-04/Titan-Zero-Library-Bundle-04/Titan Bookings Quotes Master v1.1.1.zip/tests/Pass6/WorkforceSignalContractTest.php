<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$w=json_decode((string)file_get_contents($root.'/resources/workforce/workforce-manifest.json'),true,512,JSON_THROW_ON_ERROR);
$t->assert(($w['governance']['ai_self_approval']??true)===false,'AI self approval forbidden');
$t->assert(($w['governance']['direct_execution']??true)===false,'AI direct execution forbidden');
$t->assert(count($w['responsibilities']??[])===4,'four proactive responsibility sets');
$t->assert(is_file($root.'/database/migrations/2026_08_22_040001_create_titan_bq_signal_outbox.php'),'durable signal outbox');
$t->finish('Pass6 Workforce Signal contract');
