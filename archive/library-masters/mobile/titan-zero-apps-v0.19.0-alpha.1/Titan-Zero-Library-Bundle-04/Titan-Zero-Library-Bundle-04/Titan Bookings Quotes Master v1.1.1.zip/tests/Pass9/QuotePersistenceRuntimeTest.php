<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$s=(string)file_get_contents($root.'/System/Domain/Quotes/DatabaseQuoteStore.php');
$t->assert(str_contains($s,'lockForUpdate'),'quote write concurrency lock');
$t->assert(str_contains($s,'titan_bq_quote_versions'),'version snapshots persisted');
$t->assert(str_contains($s,'titan_bq_quote_lines'),'quote lines persisted');
$t->assert(str_contains($s,'titan_bq_quotes'),'aggregate persisted');
$t->finish('Pass9 quote persistence runtime');
