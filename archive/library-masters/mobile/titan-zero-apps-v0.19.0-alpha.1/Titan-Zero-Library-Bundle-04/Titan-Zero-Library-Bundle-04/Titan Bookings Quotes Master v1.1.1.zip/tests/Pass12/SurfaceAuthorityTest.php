<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Contracts/SurfaceAuthorityPort.php','System/Runtime/DefaultSurfaceAuthority.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
foreach(['routes/admin.php'=>'bos','routes/hub.php'=>'hub','routes/api.php'=>'api'] as $f=>$surface){$s=(string)file_get_contents($root.'/'.$f);$t->assert(str_contains($s,"titan-bq.surface:$surface"),'surface middleware '.$surface);}
$t->finish('Pass12 surface authority');
