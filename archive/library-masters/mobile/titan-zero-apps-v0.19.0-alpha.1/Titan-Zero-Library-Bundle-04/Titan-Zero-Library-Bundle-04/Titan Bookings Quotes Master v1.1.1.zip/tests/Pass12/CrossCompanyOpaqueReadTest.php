<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Runtime/DatabaseBookingReadPort.php','System/Runtime/DatabaseQuoteReadPort.php'] as $f){$s=(string)file_get_contents($root.'/'.$f);$t->assert(substr_count($s,"where('company_id',$"."companyId)")>=2,'company filter every read '.$f);}
$t->finish('Pass12 cross-company opaque reads');
