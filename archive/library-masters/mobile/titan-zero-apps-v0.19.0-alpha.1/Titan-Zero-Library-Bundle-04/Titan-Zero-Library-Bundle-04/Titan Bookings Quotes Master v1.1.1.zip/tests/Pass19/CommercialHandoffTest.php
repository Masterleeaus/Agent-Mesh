<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingCommercialHandoff.php');foreach(['invoiceRequest','paymentRequest','idempotency_key',"where('company_id',$"."companyId)"] as $x)$t->assert(str_contains($s,$x),'commercial '.$x);$t->finish('Pass19 commercial handoff');
