<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Integrations/DatabaseHandoffRegistry.php');
$t->assert(str_contains($s,'lease_expires_at'),'handoff lease persisted');
$t->assert(str_contains($s,"where('lease_expires_at','<',now())"),'expired pending lease reclaimable');
$t->finish('Pass11 handoff lease');
