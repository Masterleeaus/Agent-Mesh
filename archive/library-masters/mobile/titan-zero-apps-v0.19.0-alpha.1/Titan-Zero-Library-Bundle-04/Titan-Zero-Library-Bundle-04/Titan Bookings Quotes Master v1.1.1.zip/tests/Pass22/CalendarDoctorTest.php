<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/CalendarProductionDoctor.php'),'Pass22 target');$t->finish('Pass22 CalendarProductionDoctor.php');
