<?php
declare(strict_types=1);
final class TitanBQTest {
    private int $count=0;
    public function assert(bool $ok,string $msg):void{$this->count++;if(!$ok){fwrite(STDERR,"FAIL: {$msg}\n");exit(1);}}
    public function finish(string $name):void{echo "PASS {$name} ({$this->count} assertions)\n";}
}
