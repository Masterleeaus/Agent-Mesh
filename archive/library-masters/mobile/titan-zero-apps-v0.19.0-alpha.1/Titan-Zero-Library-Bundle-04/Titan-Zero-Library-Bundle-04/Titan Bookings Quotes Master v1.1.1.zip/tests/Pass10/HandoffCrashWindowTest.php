<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Integrations/CommercialHandoffService.php');
$t->assert(str_contains($s,'reserve('),'handoff reserved before external send');
$t->assert(str_contains($s,'fail('),'handoff failure persisted');
$t->assert(str_contains($s,'deliver('),'handoff delivery finalized');
$t->finish('Pass10 handoff crash window');
