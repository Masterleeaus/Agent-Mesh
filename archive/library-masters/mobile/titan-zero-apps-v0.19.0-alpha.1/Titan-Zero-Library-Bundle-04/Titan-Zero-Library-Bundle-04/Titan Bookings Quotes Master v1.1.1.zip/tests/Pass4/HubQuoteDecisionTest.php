<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['HubActor','HubCommercialReader','InMemoryHubCommercialReader','HubAccessPolicy','HubQuoteDecisionService'] as $f)require dirname(__DIR__,2).'/System/Hub/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Hub\{HubActor,InMemoryHubCommercialReader,HubAccessPolicy,HubQuoteDecisionService};
$t=new TitanBQTest();$r=new InMemoryHubCommercialReader([['company_id'=>7,'public_id'=>'quo_1','customer_ref'=>'cus_A','status'=>'sent','version'=>2,'valid_until'=>'2099-01-01T00:00:00Z']]);$svc=new HubQuoteDecisionService(new HubAccessPolicy($r));
$a=new HubActor(7,'cus_A','actor_1');$x=$svc->decide($a,'quo_1','accept','idem-a');$t->assert($x['company_id']===7&&$x['customer_ref']==='cus_A','authority derived from actor');$t->assert($x['quote_version']===2&&$x['decision']==='accept','version/decision derived');
$t->assert($svc->decide($a,'quo_1','accept','idem-a')===$x,'decision replay idempotent');
try{$svc->decide(new HubActor(7,'cus_B','actor_2'),'quo_1','accept','idem-b');$t->assert(false,'IDOR');}catch(RuntimeException $e){$t->assert(true,'IDOR rejected');}
$t->finish('Pass4 Hub quote decision');
