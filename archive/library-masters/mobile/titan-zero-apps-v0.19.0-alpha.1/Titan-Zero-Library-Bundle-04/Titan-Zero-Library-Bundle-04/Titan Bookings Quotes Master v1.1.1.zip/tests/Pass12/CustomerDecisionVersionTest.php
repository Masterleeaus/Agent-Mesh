<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Http/Controllers/HubQuoteController.php');
$t->assert(str_contains($s,"'expected_version'=>'required|integer|min:1'"),'customer submits displayed version');
$t->assert(!str_contains($s,"$"."d['expected_version']=(int)$"."q['current_version']"),'server does not silently upgrade stale tab');
$t->finish('Pass12 stale customer decision');
