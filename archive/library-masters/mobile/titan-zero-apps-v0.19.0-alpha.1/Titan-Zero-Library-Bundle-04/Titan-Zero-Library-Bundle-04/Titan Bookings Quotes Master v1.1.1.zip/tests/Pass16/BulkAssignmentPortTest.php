<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BulkBookingAssignmentService.php');$t->assert(str_contains($s,'assertAssignable'),'bulk validates capacity');$t->assert(str_contains($s,"['assigned'=>0,'skipped'=>0,'errors'=>[]]"),'partial results');$t->finish('Pass16 bulk assignment');
