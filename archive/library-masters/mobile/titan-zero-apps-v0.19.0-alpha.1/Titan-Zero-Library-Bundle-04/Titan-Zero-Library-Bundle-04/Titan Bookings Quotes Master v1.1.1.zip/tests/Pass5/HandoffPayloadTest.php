<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
require dirname(__DIR__,2).'/System/Integrations/HandoffPayloadFactory.php';
use App\Extensions\TitanBookingsQuotes\System\Integrations\HandoffPayloadFactory;
$t=new TitanBQTest();$f=new HandoffPayloadFactory();
$s=$f->scheduling(2,'bkg_1',[['start'=>'a','end'=>'b']],['service_ref'=>'svc_1']);$t->assert($s['company_id']===2&&$s['booking_ref']==='bkg_1','schedule refs');$t->assert(!isset($s['worker_id']),'does not assign worker');
$i=$f->invoice(2,'quo_1',['currency'=>'AUD','total_minor'=>12000]);$t->assert($i['quote_ref']==='quo_1'&&$i['commercial_snapshot']['total_minor']===12000,'invoice request snapshot');
$pay=$f->payment(2,'quo_1',['currency'=>'AUD','amount_minor'=>2000]);$t->assert(!isset($pay['card_number'])&&!isset($pay['bank_account']),'no payment credentials owned');
$t->finish('Pass5 handoff payloads');
