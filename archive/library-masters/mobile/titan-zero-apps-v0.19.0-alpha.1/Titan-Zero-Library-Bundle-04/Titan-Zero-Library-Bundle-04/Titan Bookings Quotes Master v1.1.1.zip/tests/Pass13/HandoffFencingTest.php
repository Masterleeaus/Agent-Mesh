<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$s=(string)file_get_contents($root.'/System/Integrations/DatabaseHandoffRegistry.php');
foreach(['lease_token',"where('lease_token',$"."leaseToken)",'lost handoff lease'] as $x)$t->assert(str_contains($s,$x),'missing '.$x);
$t->finish('Pass13 handoff fencing');
