<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/BookingStatusHistoryService.php'),'status history');$t->finish('Pass20 status history');
