<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingLifecycleCoordinator.php');foreach(['reschedule','cancel','noShow'] as $x)$t->assert(str_contains($s,$x),'lifecycle '.$x);$t->finish('Pass17 lifecycle');
