<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Runtime/TransactionRunner.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
foreach(['System/Domain/Bookings/DatabaseBookingStore.php','System/Domain/Quotes/DatabaseQuoteStore.php'] as $f){$s=(string)file_get_contents($root.'/'.$f);$t->assert(str_contains($s,'TransactionRunner'),'store uses retry transaction runner');}
$t->finish('Pass13 transaction retry');
