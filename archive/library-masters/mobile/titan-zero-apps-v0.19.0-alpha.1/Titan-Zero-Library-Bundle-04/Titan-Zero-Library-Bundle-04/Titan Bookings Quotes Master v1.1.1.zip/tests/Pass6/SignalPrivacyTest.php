<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
require dirname(__DIR__,2).'/System/Signals/FrontOfficeSignalProjector.php';
use App\Extensions\TitanBookingsQuotes\System\Signals\FrontOfficeSignalProjector;
$t=new TitanBQTest();$p=new FrontOfficeSignalProjector();
$s=$p->project(['company_id'=>4,'kind'=>'quote.expiring','aggregate_ref'=>'q1','severity'=>'medium','customer_name'=>'SECRET','site_address'=>'SECRET','notes'=>'SECRET','total_minor'=>5000,'currency'=>'AUD']);
$t->assert($s===['company_id'=>4,'kind'=>'quote.expiring','aggregate_ref'=>'q1','severity'=>'medium','total_minor'=>5000,'currency'=>'AUD'],'privacy allowlist exact');
$t->finish('Pass6 signal privacy');
