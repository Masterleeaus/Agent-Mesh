<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Integrations/DatabaseHandoffRegistry.php');
foreach(['next_attempt_at','dead_lettered','MAX_ATTEMPTS','retry backoff'] as $x)$t->assert(str_contains($s,$x),'missing '.$x);
$t->finish('Pass13 handoff retry/dead-letter');
