<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingAgentCapabilityRegistry.php');foreach(['TitanZero','booking.availability','quote.convert','authority'] as $x)$t->assert(str_contains($s,$x),'agent '.$x);$t->finish('Pass23 agent registry');
