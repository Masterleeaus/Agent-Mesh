<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/CalendarSyncQueueService.php');foreach(['idempotency_key','attempts','available_at',"where('company_id',$"."companyId)"] as $x)$t->assert(str_contains($s,$x),'queue '.$x);$t->finish('Pass22 calendar queue');
