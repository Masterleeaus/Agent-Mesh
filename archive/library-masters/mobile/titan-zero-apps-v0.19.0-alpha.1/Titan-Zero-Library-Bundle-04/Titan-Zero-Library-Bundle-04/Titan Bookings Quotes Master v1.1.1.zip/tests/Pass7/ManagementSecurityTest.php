<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$api='';foreach(glob($root.'/System/Http/Controllers/Api/V1/*.php')?:[] as $f)$api.=file_get_contents($f);
foreach(['company_id','customer_ref','status','total_minor','invoice_id','payment_id'] as $field)$t->assert(!preg_match('/validate\([^;]*[\'"]'.$field.'[\'"]\s*=>/s',$api),'protected field absent: '.$field);
$cmd=(string)file_get_contents($root.'/System/Console/Commands/BookingsQuotesMenuAuditCommand.php');
$t->assert(!str_contains($cmd,'DB::'),'menu audit must not mutate host DB');
$t->finish('Pass7 management security');
