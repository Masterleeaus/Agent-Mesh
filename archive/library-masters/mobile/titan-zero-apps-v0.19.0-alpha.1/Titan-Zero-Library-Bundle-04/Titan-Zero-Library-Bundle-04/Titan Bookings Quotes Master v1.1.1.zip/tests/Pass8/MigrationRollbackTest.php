<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$files=glob($root.'/database/migrations/*.php')?:[];$t->assert(count($files)>=1,'migrations exist');
foreach($files as $f){$s=(string)file_get_contents($f);$t->assert(str_contains($s,'function down()'),'rollback present '.basename($f));$t->assert(str_contains($s,'dropIfExists'),'safe rollback '.basename($f));}
$t->finish('Pass8 migration rollback');
