<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingAutoAssignmentService.php');foreach(['least_busy','assertAssignable',"where('company_id',$"."companyId)"] as $x)$t->assert(str_contains($s,$x),'autoassign '.$x);$t->finish('Pass24 autoassignment');
