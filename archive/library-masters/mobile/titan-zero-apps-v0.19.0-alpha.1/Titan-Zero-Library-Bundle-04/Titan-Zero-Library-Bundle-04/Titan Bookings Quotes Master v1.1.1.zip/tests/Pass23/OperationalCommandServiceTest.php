<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/BookingOperationsService.php'),'Pass23 target');$t->finish('Pass23 BookingOperationsService.php');
