<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$e=json_decode((string)file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
$m=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$t->assert(($e['schema']??'')==='titan-extension-v1'&&($e['version']??'')!=='','installer metadata present');
$t->assert(($m['slug']??'')==='titan-bookings-quotes','canonical manifest slug');
$t->assert(($m['data']['tenant_key']??'')==='company_id','company tenancy declared');
foreach($m['database']['owned_tables']??[] as $table)$t->assert(str_starts_with($table,'titan_bq_'),'only namespaced owned tables');
$t->finish('Pass8 installer contract');
