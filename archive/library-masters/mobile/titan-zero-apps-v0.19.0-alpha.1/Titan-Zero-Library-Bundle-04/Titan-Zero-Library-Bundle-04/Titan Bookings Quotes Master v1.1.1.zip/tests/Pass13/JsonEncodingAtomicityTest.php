<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Domain/Bookings/DatabaseBookingStore.php','System/Domain/Quotes/DatabaseQuoteStore.php'] as $f){$s=(string)file_get_contents($root.'/'.$f);$t->assert(str_contains($s,'JSON_THROW_ON_ERROR'),'JSON encoding fails before partial persistence '.$f);}
$t->finish('Pass13 JSON atomicity');
