<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
require dirname(__DIR__,2).'/System/Domain/Quotes/Money.php';
require dirname(__DIR__,2).'/System/Domain/Quotes/QuotePricingService.php';
use App\Extensions\TitanBookingsQuotes\System\Domain\Quotes\{Money,QuotePricingService};
$t=new TitanBQTest();$svc=new QuotePricingService();
$r=$svc->price('AUD',[
 ['description'=>'Labour','quantity'=>'2.5','unit_price_minor'=>10000,'discount_minor'=>1000,'tax_rate_bps'=>1000],
 ['description'=>'Materials','quantity'=>'1','unit_price_minor'=>5500,'discount_minor'=>0,'tax_rate_bps'=>1000],
]);
$t->assert($r['subtotal_minor']===30500,'deterministic subtotal');
$t->assert($r['discount_minor']===1000,'discount total');
$t->assert($r['tax_minor']===2950,'tax deterministic');
$t->assert($r['total_minor']===32450,'grand total deterministic');
$t->assert($r['currency']==='AUD','currency retained');
$t->finish('Pass3 quote pricing');
