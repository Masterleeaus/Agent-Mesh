<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Domain/Bookings/DatabaseBookingStore.php');
$t->assert(str_contains($s,"json_decode((string)$"."r->site"),'site JSON hydrated');
$t->assert(str_contains($s,"json_decode((string)$"."r->scope"),'scope JSON hydrated');
$t->assert(str_contains($s,'titan_bq_booking_windows'),'booking windows persisted');
$t->finish('Pass10 booking hydration');
