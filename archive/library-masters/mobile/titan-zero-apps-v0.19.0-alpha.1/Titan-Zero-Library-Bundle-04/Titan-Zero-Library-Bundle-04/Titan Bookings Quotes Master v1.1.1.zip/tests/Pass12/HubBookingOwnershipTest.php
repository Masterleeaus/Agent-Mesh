<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Http/Controllers/HubBookingController.php');
$t->assert(str_contains($s,'pageForCustomer'),'Hub booking list customer scoped');
$t->assert(str_contains($s,'findForCustomer'),'Hub booking reads customer scoped');
$t->finish('Pass12 Hub booking ownership');
