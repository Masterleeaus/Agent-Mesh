<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['routes/hub.php','System/Http/Controllers/HubBookingController.php','System/Http/Controllers/HubQuoteController.php','resources/views/hub/bookings/index.blade.php','resources/views/hub/quotes/show.blade.php','resources/views/hub/variations/show.blade.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$routes=(string)file_get_contents($root.'/routes/hub.php');$t->assert(str_contains($routes,"middleware(['web','auth'])"),'Hub routes authenticated');$t->assert(!preg_match('/Route::get\([^;\n]*(accept|reject|approve|cancel)/i',$routes),'no state mutation GET');
foreach(['company_id','customer_ref'] as $field)$t->assert(!preg_match('/request\([^)]*\).*'.$field.'/s',$routes),'authority fields not caller supplied');
$t->finish('Pass4 Hub surface');
