<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$m=$root.'/database/migrations/2026_08_24_050001_create_titan_bq_quote_commands.php';$t->assert(is_file($m),'quote command receipt migration');
$s=(string)file_get_contents($root.'/System/Domain/Quotes/DatabaseQuoteStore.php');
$t->assert(str_contains($s,'titan_bq_quote_commands'),'all quote command idempotency persisted');
$t->assert(str_contains((string)file_get_contents($m),"unique(['company_id','idempotency_key']"),'company-scoped command dedupe');
$t->finish('Pass9 quote idempotency persistence');
