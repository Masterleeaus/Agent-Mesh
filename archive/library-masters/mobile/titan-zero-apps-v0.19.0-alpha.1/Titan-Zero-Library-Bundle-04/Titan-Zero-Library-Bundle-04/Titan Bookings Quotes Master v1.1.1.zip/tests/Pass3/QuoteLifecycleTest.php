<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['QuoteCommand','QuoteStore','InMemoryQuoteStore','QuoteLifecycleService'] as $f)require dirname(__DIR__,2).'/System/Domain/Quotes/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Domain\Quotes\{QuoteCommand,InMemoryQuoteStore,QuoteLifecycleService};
$t=new TitanBQTest();$s=new InMemoryQuoteStore();$svc=new QuoteLifecycleService($s);
$r=$svc->execute(new QuoteCommand(4,'quo_01','draft',0,'qidem-1',['booking_ref'=>'bkg_01','customer_ref'=>'cus_A','currency'=>'AUD','lines'=>[['description'=>'Clean','quantity'=>'1','unit_price_minor'=>10000,'discount_minor'=>0,'tax_rate_bps'=>1000]]]));
$t->assert($r['status']==='draft'&&$r['version']===1,'draft created');
$sent=$svc->execute(new QuoteCommand(4,'quo_01','send',1,'qidem-2',[]));$t->assert($sent['status']==='sent'&&$sent['version']===2,'sent version immutable');
$again=$svc->execute(new QuoteCommand(4,'quo_01','send',1,'qidem-2',[]));$t->assert($again===$sent,'idempotent replay');
try{$svc->execute(new QuoteCommand(4,'quo_01','revise',1,'qidem-3',[]));$t->assert(false,'stale version');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'stale'),'stale rejected');}
$accepted=$svc->execute(new QuoteCommand(4,'quo_01','accept',2,'qidem-4',['acceptance_ref'=>'acc_01']));$t->assert($accepted['status']==='accepted','accepted');
$t->assert($s->find(5,'quo_01')===null,'cross-company isolation');
$t->finish('Pass3 quote lifecycle');
