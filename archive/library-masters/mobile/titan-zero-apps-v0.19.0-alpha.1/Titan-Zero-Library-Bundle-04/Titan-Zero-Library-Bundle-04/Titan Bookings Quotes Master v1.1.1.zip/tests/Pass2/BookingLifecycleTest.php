<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
require dirname(__DIR__,2).'/System/Domain/Bookings/BookingCommand.php';
require dirname(__DIR__,2).'/System/Domain/Bookings/BookingStore.php';
require dirname(__DIR__,2).'/System/Domain/Bookings/BookingLifecycleService.php';
require dirname(__DIR__,2).'/System/Domain/Bookings/InMemoryBookingStore.php';
use App\Extensions\TitanBookingsQuotes\System\Domain\Bookings\{BookingCommand,BookingLifecycleService,InMemoryBookingStore};
$t=new TitanBQTest();$s=new InMemoryBookingStore();$svc=new BookingLifecycleService($s);
$r=$svc->execute(new BookingCommand(7,'bkg_01','create',0,'idem-1',['customer_ref'=>'cus_A','service_ref'=>'svc_clean','requested_windows'=>[['start'=>'2026-08-24T09:00:00+10:00','end'=>'2026-08-24T12:00:00+10:00']]]));
$t->assert($r['version']===1&&$r['status']==='requested','create transition');
$again=$svc->execute(new BookingCommand(7,'bkg_01','create',0,'idem-1',[]));$t->assert($again===$r,'idempotent replay');
$cross=$s->find(8,'bkg_01');$t->assert($cross===null,'cross-company read denied');
try{$svc->execute(new BookingCommand(7,'bkg_01','confirm',0,'idem-2',[]));$t->assert(false,'stale version must fail');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'stale'),'stale version rejected');}
try{$svc->execute(new BookingCommand(7,'bkg_01','complete',1,'idem-3',[]));$t->assert(false,'illegal transition must fail');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'transition'),'illegal transition rejected');}
$foreignKey='tenant'.'_company_id';
$r2=$svc->execute(new BookingCommand(7,'bkg_02','create',0,'idem-4',[$foreignKey=>999,'customer_ref'=>'cus_B']));
$t->assert(!array_key_exists($foreignKey,$r2),'foreign tenant authority field stripped');
$t->finish('Pass2 booking lifecycle');
