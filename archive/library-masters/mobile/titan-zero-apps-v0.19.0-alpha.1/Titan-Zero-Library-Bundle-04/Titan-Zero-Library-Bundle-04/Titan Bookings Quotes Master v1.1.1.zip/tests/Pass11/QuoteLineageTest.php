<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Domain/Quotes/DatabaseQuoteStore.php');
$t->assert(str_contains($s,"'parent_version'"),'version lineage persisted');
$t->assert(str_contains($s,"'supersedes_version'"),'revision supersession persisted');
$t->finish('Pass11 quote lineage');
