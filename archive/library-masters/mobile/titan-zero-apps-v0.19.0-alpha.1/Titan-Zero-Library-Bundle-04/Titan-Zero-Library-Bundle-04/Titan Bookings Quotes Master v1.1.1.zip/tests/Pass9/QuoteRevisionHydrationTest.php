<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$s=(string)file_get_contents($root.'/System/Domain/Quotes/DatabaseQuoteStore.php');
$t->assert(substr_count($s,"DB::table('titan_bq_quote_lines')")>=2,'find hydrates prior lines and commit persists lines');
$t->assert(str_contains($s,"'lines'=>".'$'."lines"),'hydrated aggregate carries lines across lifecycle actions');
$t->finish('Pass9 quote revision hydration');
