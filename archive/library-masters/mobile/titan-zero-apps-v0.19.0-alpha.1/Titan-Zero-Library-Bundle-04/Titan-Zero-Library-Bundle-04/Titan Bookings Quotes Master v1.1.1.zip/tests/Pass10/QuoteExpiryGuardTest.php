<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['QuoteCommand','QuoteStore','QuoteLifecycleService'] as $f)require dirname(__DIR__,2).'/System/Domain/Quotes/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Domain\Quotes\{QuoteCommand,QuoteStore,QuoteLifecycleService};
$t=new TitanBQTest();$store=new class implements QuoteStore{public array $cur=['company_id'=>1,'public_id'=>'q','status'=>'sent','version'=>1,'valid_until'=>'2020-01-01T00:00:00Z','lines'=>[]];public function find(int $c,string $r):?array{return $this->cur;}public function receipt(int $c,string $k):?array{return null;}public function commit(QuoteCommand $c,array $n):array{$this->cur=$n;return $n;}};
try{(new QuoteLifecycleService($store))->execute(new QuoteCommand(1,'q','accept',1,'k',[]));$t->assert(false,'expired quote accepted');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'expired'),'expired acceptance fails closed');}$t->finish('Pass10 expiry guard');
