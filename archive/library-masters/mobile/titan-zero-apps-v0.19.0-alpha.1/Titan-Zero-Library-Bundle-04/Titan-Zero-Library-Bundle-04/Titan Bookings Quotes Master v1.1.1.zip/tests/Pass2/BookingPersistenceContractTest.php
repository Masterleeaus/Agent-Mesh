<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$required=['database/migrations/2026_08_22_010001_create_titan_bq_bookings.php','database/migrations/2026_08_22_010002_create_titan_bq_booking_events.php','database/migrations/2026_08_22_010003_create_titan_bq_booking_windows.php','System/Domain/Bookings/DatabaseBookingStore.php'];
foreach($required as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$all='';foreach(glob($root.'/database/migrations/*.php')?:[] as $f)$all.=file_get_contents($f);
$t->assert(!str_contains($all,'tenant'.'_company_id'),'migrations must use company_id only');
$t->assert(str_contains($all,"unique(['company_id','public_id']"),'booking public ID unique per company');
$t->assert(str_contains($all,"unique(['company_id','idempotency_key']"),'event idempotency unique per company');
$t->finish('Pass2 persistence contract');
