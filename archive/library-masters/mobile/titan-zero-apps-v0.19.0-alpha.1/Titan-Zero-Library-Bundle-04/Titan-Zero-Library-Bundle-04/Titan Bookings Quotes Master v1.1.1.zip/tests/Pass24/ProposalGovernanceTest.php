<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingProposalService.php');foreach(['canExpose','status','pending','approved_by_ref'] as $x)$t->assert(str_contains($s,$x),'proposal '.$x);$t->finish('Pass24 proposal governance');
