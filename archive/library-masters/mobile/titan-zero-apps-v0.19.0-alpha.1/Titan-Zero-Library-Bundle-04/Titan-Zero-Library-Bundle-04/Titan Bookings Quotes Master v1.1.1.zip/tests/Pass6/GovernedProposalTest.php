<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['GovernedProposal','ProposalFactory'] as $f)require dirname(__DIR__,2).'/System/Intelligence/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Intelligence\ProposalFactory;
$t=new TitanBQTest();$f=new ProposalFactory();$p=$f->fromFinding(['company_id'=>3,'kind'=>'quote.stale','aggregate_ref'=>'q1','severity'=>'medium']);
$t->assert($p->requiresApproval===true,'AI proposal cannot self approve');
$t->assert($p->executionState==='proposed','AI cannot execute directly');
$t->assert($p->idempotencyKey===$f->fromFinding(['company_id'=>3,'kind'=>'quote.stale','aggregate_ref'=>'q1','severity'=>'medium'])->idempotencyKey,'proposal deterministic');
$t->finish('Pass6 governed proposals');
