<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Domain/Bookings/BookingLifecycleService.php');
$t->assert(str_contains($s,"'cancel'=>['requested','scoped','quote_pending','confirmed']"),'cancel bounded states');
$t->assert(!str_contains($s,"'cancel'=>['*'"),'cancel not wildcard');
$t->finish('Pass12 cancellation terminality');
