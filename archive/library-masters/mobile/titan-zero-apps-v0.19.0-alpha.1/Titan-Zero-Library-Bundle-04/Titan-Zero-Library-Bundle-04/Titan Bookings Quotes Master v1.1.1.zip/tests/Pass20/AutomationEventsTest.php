<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/BookingAutomationEvents.php'),'automation events');$t->finish('Pass20 automation events');
