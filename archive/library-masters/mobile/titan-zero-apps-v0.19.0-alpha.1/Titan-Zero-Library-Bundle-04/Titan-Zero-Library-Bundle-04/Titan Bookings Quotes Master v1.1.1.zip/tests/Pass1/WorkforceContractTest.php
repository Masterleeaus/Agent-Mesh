<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$w=json_decode((string)file_get_contents($root.'/resources/workforce/workforce-manifest.json'),true,512,JSON_THROW_ON_ERROR);
$t->assert(($w['schema_version']??null)==='2.0','workforce schema 2.0 required');
$keys=array_column($w['roles']??[],'key');
foreach(['front-office-manager','booking-coordinator','quote-specialist','conversion-analyst'] as $k)$t->assert(in_array($k,$keys,true),'missing workforce role '.$k);
foreach($w['tools']??[] as $tool)$t->assert(($tool['mutates']??true)===false,'Pass1 tools must be read-only');
$t->finish('Pass1 workforce contract');
