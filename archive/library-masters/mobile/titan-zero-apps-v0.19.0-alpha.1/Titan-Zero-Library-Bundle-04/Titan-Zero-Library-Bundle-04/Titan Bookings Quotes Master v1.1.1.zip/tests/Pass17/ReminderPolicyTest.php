<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Domain/Bookings/ReminderPolicy.php'),'reminder policy');$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/DatabaseBookingReminderPort.php'),'reminder runtime');$t->finish('Pass17 reminder');
