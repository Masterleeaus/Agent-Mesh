<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$files=glob($root.'/System/Http/Controllers/{HubBookingController.php,HubQuoteController.php,Api/V1/*.php}',GLOB_BRACE)?:[];$all='';foreach($files as $f)$all.=file_get_contents($f);
$t->assert(str_contains($all,'ActorContextPort'),'controllers resolve actor authority');
$t->assert(str_contains($all,'BookingCommandPort'),'booking mutations execute command port');
$t->assert(str_contains($all,'QuoteCommandPort'),'quote mutations execute command port');
$t->assert(str_contains($all,'BookingReadPort'),'booking reads use read port');
$t->assert(str_contains($all,'QuoteReadPort'),'quote reads use read port');
$t->assert(!str_contains($all,"['data'=>[]"),'no placeholder empty list');
$t->assert(!str_contains($all,"['accepted'=>true,'input'"),'no echo-only mutation placeholder');
$t->finish('Pass9 controller execution');
