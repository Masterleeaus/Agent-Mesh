<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Domain/Bookings/DatabaseBookingStore.php');
$t->assert(str_contains($s,'JSON_THROW_ON_ERROR'),'corrupt booking JSON fails closed');
$t->finish('Pass11 corrupt JSON fail closed');
