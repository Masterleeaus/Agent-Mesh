<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Domain/Bookings/BookingWindowValidator.php');
foreach(['DateTimeImmutable','DateTimeZone','end must be after start','overlap','maximum booking window'] as $x)$t->assert(str_contains($s,$x),'missing '.$x);
$t->finish('Pass11 booking window validation');
