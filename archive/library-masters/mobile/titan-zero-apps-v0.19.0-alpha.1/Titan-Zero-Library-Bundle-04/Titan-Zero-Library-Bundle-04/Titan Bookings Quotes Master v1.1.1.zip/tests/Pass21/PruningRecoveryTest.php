<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$t->assert(is_file(dirname(__DIR__,2).'/System/Runtime/NotificationMaintenanceService.php'),'maintenance service');$t->finish('Pass21 maintenance');
