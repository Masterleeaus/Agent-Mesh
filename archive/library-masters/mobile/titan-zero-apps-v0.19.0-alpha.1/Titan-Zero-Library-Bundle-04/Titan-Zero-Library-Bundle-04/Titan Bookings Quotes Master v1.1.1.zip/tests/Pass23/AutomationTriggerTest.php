<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/BookingAutomationPublisher.php');foreach(['booking.requested','booking.completed','quote.accepted','titan_bq_automation_outbox',"company_id"] as $x)$t->assert(str_contains($s,$x),'automation '.$x);$t->finish('Pass23 automation');
