<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$r=(string)file_get_contents($root.'/routes/api.php');$t->assert(str_contains($r,"prefix('api/v1/titan-bookings-quotes')"),'versioned API prefix');$t->assert(str_contains($r,"middleware(['api','auth'])"),'API authenticated');$t->assert(!preg_match('/Route::get\([^;\n]*(accept|reject|approve|cancel|delete|update)/i',$r),'no state GET');
$all='';foreach(glob($root.'/System/Http/Controllers/Api/V1/*.php')?:[] as $f)$all.=file_get_contents($f);
$t->assert(str_contains($all,'min(100'),'pagination hard max 100');$t->assert(!preg_match('/input\([\'"]company_id/', $all),'company authority actor-derived');
$t->assert(!preg_match('/input\([\'"]customer_ref/', $all),'customer authority actor-derived');
$t->finish('Pass7 API contract');
