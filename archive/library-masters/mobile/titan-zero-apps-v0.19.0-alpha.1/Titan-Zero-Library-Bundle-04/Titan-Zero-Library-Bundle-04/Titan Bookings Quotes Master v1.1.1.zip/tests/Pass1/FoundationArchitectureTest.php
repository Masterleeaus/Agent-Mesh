<?php
declare(strict_types=1);
require dirname(__DIR__).'/bootstrap.php';
$t=new TitanBQTest();$root=dirname(__DIR__,2);
$required=[
'extension.json','extension.manifest.json','System/TitanBookingsQuotesServiceProvider.php','config/bookings-quotes.php',
'System/Contracts/BookingReadPort.php','System/Contracts/BookingCommandPort.php',
'System/Contracts/QuoteReadPort.php','System/Contracts/QuoteCommandPort.php',
'System/Contracts/CustomerReferencePort.php','System/Contracts/SchedulingHandoffPort.php',
'System/Contracts/InvoiceHandoffPort.php','System/Contracts/PaymentIntentPort.php',
'System/Contracts/GovernanceAuthorityPort.php','System/Contracts/CommandBusPort.php',
'resources/workforce/workforce-manifest.json'
];
foreach($required as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
if(is_file($root.'/extension.manifest.json')){
 $m=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
 $t->assert(($m['data']['tenant_key']??null)==='company_id','company_id must be sole tenant boundary');
 $t->assert(($m['schema_version']??null)==='2.2','manifest schema must be 2.2');
}
$prod='';foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root)) as $f){if($f->isFile()&&$f->getExtension()==='php'&&!str_contains($f->getPathname(),'/tests/'))$prod.=file_get_contents($f->getPathname())."\n";}
$t->assert(!str_contains($prod,'tenant'.'_company_id'),'new production code must use canonical company_id only');
$t->assert(!preg_match('/Route::get\([^;\n]*(delete|destroy|approve|reject|accept|update|store)/i',$prod),'no state-changing GET routes');
$t->finish('Pass1 foundation architecture');
