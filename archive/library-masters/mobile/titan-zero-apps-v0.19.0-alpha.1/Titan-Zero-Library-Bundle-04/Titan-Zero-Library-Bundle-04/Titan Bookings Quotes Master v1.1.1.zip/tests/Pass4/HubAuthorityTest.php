<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['HubActor','HubCommercialReader','HubAccessPolicy','InMemoryHubCommercialReader'] as $f)require dirname(__DIR__,2).'/System/Hub/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Hub\{HubActor,HubAccessPolicy,InMemoryHubCommercialReader};
$t=new TitanBQTest();$r=new InMemoryHubCommercialReader([['company_id'=>7,'public_id'=>'quo_1','customer_ref'=>'cus_A','status'=>'sent','valid_until'=>'2099-01-01T00:00:00Z']]);$p=new HubAccessPolicy($r);
$a=new HubActor(7,'cus_A','actor_1');$t->assert($p->quote($a,'quo_1')['public_id']==='quo_1','owner customer can read');
$t->assert($p->quote(new HubActor(7,'cus_B','actor_2'),'quo_1')===null,'customer IDOR denied');
$t->assert($p->quote(new HubActor(8,'cus_A','actor_3'),'quo_1')===null,'company IDOR denied');
$t->finish('Pass4 Hub authority');
