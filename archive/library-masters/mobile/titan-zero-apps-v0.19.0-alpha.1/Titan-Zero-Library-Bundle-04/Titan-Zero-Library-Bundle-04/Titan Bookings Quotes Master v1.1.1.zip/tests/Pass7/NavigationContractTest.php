<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$n=json_decode((string)file_get_contents($root.'/resources/navigation.json'),true,512,JSON_THROW_ON_ERROR);$keys=array_column($n['items']??[],'key');
foreach(['bookings','quotes','quote-builder','approvals-expiring','commercial-timeline','bookings-quotes-settings'] as $k)$t->assert(in_array($k,$keys,true),'missing nav '.$k);
$t->finish('Pass7 navigation');
