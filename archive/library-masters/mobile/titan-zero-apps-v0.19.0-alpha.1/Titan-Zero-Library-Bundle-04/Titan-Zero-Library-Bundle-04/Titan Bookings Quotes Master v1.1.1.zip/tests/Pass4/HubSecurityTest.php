<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
$controllers='';foreach(glob($root.'/System/Http/Controllers/*.php')?:[] as $f)$controllers.=file_get_contents($f);
$t->assert(!preg_match('/input\([\'"]company_id/', $controllers),'company authority never accepted from input');
$t->assert(!preg_match('/input\([\'"]customer_ref/', $controllers),'customer authority never accepted from input');
$t->assert(!preg_match('/validate\([^;]*(company_id|customer_ref)/s',$controllers),'authority fields absent from validation');
$routes=(string)file_get_contents($root.'/routes/hub.php');
$t->assert(substr_count($routes,'Route::post')===3,'all customer decisions/requests use POST');
$t->finish('Pass4 Hub security');
