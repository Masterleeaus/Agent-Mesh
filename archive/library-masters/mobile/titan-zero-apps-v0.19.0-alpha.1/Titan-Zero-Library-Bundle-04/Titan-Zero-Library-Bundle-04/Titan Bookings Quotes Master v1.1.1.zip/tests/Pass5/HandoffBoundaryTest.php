<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);
foreach(['System/Contracts/JobHandoffPort.php','System/Integrations/CommercialHandoffService.php','database/migrations/2026_08_22_030001_create_titan_bq_handoffs.php'] as $f)$t->assert(is_file($root.'/'.$f),'missing '.$f);
$prod='';foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/System')) as $f){if($f->isFile()&&$f->getExtension()==='php')$prod.=file_get_contents($f->getPathname())."\n";}
$t->assert(!preg_match('/DB::table\([\'"](?:schedules|shifts|jobs|invoices|payments|transactions)[\'"]/', $prod),'no peer private table access');
$t->assert(!str_contains($prod,'tenant'.'_company_id'),'company_id only');
$t->finish('Pass5 handoff boundary');
