<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$root=dirname(__DIR__,2);$s=(string)file_get_contents($root.'/System/Domain/Quotes/DatabaseQuoteStore.php');
$t->assert(str_contains($s,'titan_bq_quote_acceptances'),'accept/reject evidence persisted');
$t->assert(str_contains($s,"'decision'=>$"."c->action"),'decision stored');
$t->assert(str_contains($s,"'quote_version'=>$"."next['version']"),'decision version bound');
$t->finish('Pass10 quote decision evidence');
