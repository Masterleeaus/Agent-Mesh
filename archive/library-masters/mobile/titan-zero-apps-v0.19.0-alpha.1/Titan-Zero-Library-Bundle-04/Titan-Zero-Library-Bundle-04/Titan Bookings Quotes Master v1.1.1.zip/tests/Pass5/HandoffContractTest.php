<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';
foreach(['HandoffRequest','HandoffReceipt','HandoffPort','HandoffRegistry','InMemoryHandoffRegistry','CommercialHandoffService'] as $f)require dirname(__DIR__,2).'/System/Integrations/'.$f.'.php';
use App\Extensions\TitanBookingsQuotes\System\Integrations\{HandoffRequest,HandoffPort,HandoffReceipt,InMemoryHandoffRegistry,CommercialHandoffService};
$t=new TitanBQTest();$port=new class implements HandoffPort{public int $calls=0;public function send(HandoffRequest $r):HandoffReceipt{$this->calls++;return new HandoffReceipt($r->target,$r->idempotencyKey,'ext-'.$this->calls);}};
$svc=new CommercialHandoffService(new InMemoryHandoffRegistry(),['scheduling'=>$port,'jobs'=>$port,'invoicing'=>$port,'payments'=>$port]);
$r=new HandoffRequest(9,'scheduling','bkg_1','idem-1',['requested_windows'=>[['start'=>'x','end'=>'y']]]);$a=$svc->dispatch($r);$b=$svc->dispatch($r);
$t->assert($a==$b&&$port->calls===1,'duplicate handoff must not duplicate external work');
try{(new CommercialHandoffService(new InMemoryHandoffRegistry(),[]))->dispatch($r);$t->assert(false,'missing peer must fail');}catch(RuntimeException $e){$t->assert(str_contains($e->getMessage(),'unavailable'),'missing peer fails closed');}
$t->finish('Pass5 handoff contract');
