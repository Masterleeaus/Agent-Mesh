<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=(string)file_get_contents(dirname(__DIR__,2).'/System/Runtime/DefaultActorContext.php');
$t->assert(str_contains($s,'customer authority unavailable'),'customer surfaces can require explicit customer mapping');
$t->assert(!str_contains($s,"customer_ref??''"),'no silent empty customer authority');
$t->finish('Pass10 actor scope fail closed');
