<?php
declare(strict_types=1);require dirname(__DIR__).'/bootstrap.php';$t=new TitanBQTest();$s=file_get_contents(dirname(__DIR__,2).'/System/Runtime/RecurringBookingService.php');foreach(['RecurrenceExpander','titan_bq_recurring_series','TransactionRunner'] as $x)$t->assert(str_contains($s,$x),'recurring '.$x);$t->finish('Pass18 recurring');
