<?php

return [
    'webhooks' => [
        'replay_window_seconds' => 300,
        'facebook' => [
            'verify_token' => env('FACEBOOK_WEBHOOK_VERIFY_TOKEN'),
            'app_secret' => env('FACEBOOK_APP_SECRET'),
        ],
        'instagram' => [
            'verify_token' => env('INSTAGRAM_WEBHOOK_VERIFY_TOKEN', env('FACEBOOK_WEBHOOK_VERIFY_TOKEN')),
            'app_secret' => env('INSTAGRAM_APP_SECRET', env('FACEBOOK_APP_SECRET')),
        ],
        'x' => [
            'consumer_secret' => env('X_API_SECRET'),
            'webhook_secret' => env('X_WEBHOOK_SECRET', env('X_API_SECRET')),
        ],
        'tiktok' => [
            'webhook_secret' => env('TIKTOK_WEBHOOK_SECRET', env('TIKTOK_APP_SECRET')),
        ],
        'linkedin' => [
            'webhook_secret' => env('LINKEDIN_WEBHOOK_SECRET', env('LINKEDIN_APP_SECRET')),
        ],
    ],
];
