<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-flow',
    'module_slug' => 'lead_review_automation',
    'module_name' => 'Lead & Review Automation',
    'version' => '1.42',
    'runtime_smoke_ready' => true,
    'route_names' => [
        'dashboard.user.titan-reach.automation.field-service-workspace',
        'dashboard.user.titan-reach.automation.index',
        'dashboard.user.titan-reach.automation.create',
        'dashboard.user.titan-reach.automation.field-service-presets',
        'dashboard.user.titan-reach.automation.social-leads.index',
        'titan-reach.automation.webhook.facebook',
        'titan-reach.automation.webhook.instagram'
    ],
    'route_prefixes' => [
        'dashboard/user/titan-reach/automation',
        'titan-reach/automation/webhook'
    ],
    'views' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/index.blade.php',
        'resources/views/builder/index.blade.php'
    ],
    'controllers' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/AutomationController.php',
        'System/Http/Controllers/AutomationBuilderController.php',
        'System/Http/Controllers/SocialLeadController.php',
        'System/Http/Controllers/WebhookController.php'
    ],
    'navigation_modules' => [
        'field_marketing_hub',
        'local_growth_agent',
        'lead_review_automation',
        'campaign_playbooks'
    ],
    'checks' => [
        'route_registration',
        'view_resolution',
        'controller_presence',
        'config_registration',
        'workspace_navigation',
        'permission_gate',
        'standalone_fallback'
    ]
];
