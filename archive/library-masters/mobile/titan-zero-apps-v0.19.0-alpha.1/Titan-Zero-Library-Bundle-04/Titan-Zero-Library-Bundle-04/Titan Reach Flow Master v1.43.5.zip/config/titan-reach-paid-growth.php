<?php

return [
    'role' => 'lead_review_automation',
    'mode' => 'lead_attention',
    'activation_authority' => false,
    'automatic_spend' => false,
    'pro_binding' => 'titan-reach.paid-growth',
];
