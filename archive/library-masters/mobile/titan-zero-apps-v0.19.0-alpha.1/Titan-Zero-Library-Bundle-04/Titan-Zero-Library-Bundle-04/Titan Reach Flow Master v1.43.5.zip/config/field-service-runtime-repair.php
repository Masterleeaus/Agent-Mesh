<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-flow',
    'module_slug' => 'lead_review_automation',
    'module_label' => 'Lead & Review Automation',
    'route_names' => [
        'dashboard.user.titan-reach.automation.field-service-workspace',
        'dashboard.user.titan-reach.automation.index',
        'dashboard.user.titan-reach.automation.create',
        'dashboard.user.titan-reach.automation.field-service-presets',
        'dashboard.user.titan-reach.automation.social-leads.index',
        'titan-reach.automation.webhook.facebook',
        'titan-reach.automation.webhook.instagram'
    ],
    'view_paths' => [
        'resources/views/field-service-workspace.blade.php',
        'resources/views/index.blade.php',
        'resources/views/builder/index.blade.php'
    ],
    'controller_paths' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/AutomationController.php',
        'System/Http/Controllers/AutomationBuilderController.php',
        'System/Http/Controllers/SocialLeadController.php',
        'System/Http/Controllers/WebhookController.php'
    ],
    'safe_route_resolution' => true,
    'safe_blade_includes' => true,
    'missing_module_mode' => 'disabled_link',
    'fallback_url_mode' => 'url_path',
    'permission' => 'field_service_marketing.view',
    'company_scoped' => true,
];
