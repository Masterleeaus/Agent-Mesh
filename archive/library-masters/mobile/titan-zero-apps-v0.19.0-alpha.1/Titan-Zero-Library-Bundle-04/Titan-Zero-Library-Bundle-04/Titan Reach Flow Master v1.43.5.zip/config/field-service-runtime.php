<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-flow',
    'module_slug' => 'lead_review_automation',
    'module_name' => 'Lead & Review Automation',
    'version' => '1.42',
    'phase' => 'phase-2-runtime-commercialization',
    'step' => 17,
    'installer_runtime_trial' => [
        'enabled' => true,
        'requires_company_id' => true,
        'standalone_safe' => true,
        'fail_closed_public_surfaces' => true,
        'validate_manifest_before_install' => true,
        'validate_migrations_before_install' => true,
        'validate_views_before_install' => true,
        'validate_routes_before_install' => true,
    ],
    'health_checks' => [
        'manifest_json' => true,
        'service_provider_boot' => true,
        'route_registration' => true,
        'migration_discovery' => true,
        'view_discovery' => true,
        'config_registration' => true,
    ],
];
