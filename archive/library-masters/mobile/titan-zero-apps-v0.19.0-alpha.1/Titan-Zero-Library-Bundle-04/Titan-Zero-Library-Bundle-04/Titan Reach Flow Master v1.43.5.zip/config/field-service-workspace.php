<?php

declare(strict_types=1);

return ['workspace' => 'field_home_services_social_marketing', 'module' => 'lead_review_automation', 'label' => 'Lead & Review Automation', 'role' => 'Inbound lead and review workflow engine', 'route' => 'dashboard.user.titan-reach.automation.field-service-workspace', 'permissions' => ['field_service_marketing.view', 'field_service_marketing.manage_context', 'field_service_marketing.create_content', 'field_service_marketing.manage_campaigns', 'field_service_marketing.manage_automations', 'field_service_marketing.view_leads', 'field_service_marketing.publish']];
