<?php

return [
    'max_items_per_page' => 100,
    'store_raw_provider_payloads' => false,
    'auto_reply_enabled' => false,
    'categories' => [
        'lead', 'quote_request', 'booking_request', 'review', 'complaint',
        'urgent_safety', 'spam', 'human_review', 'general',
    ],
    'priorities' => ['low', 'normal', 'high', 'urgent'],
    'safety_terms' => ['gas leak', 'electric shock', 'no power', 'flooding', 'fire', 'unsafe', 'injury', 'emergency'],
];
