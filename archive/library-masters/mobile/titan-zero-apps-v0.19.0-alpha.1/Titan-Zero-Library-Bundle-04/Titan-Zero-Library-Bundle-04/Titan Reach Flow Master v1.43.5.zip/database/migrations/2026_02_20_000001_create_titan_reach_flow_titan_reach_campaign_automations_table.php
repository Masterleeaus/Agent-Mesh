<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_automations')) {
            Schema::create('titan_reach_flow_automations', function (Blueprint $table) {
                        $table->id();
                        // Soft references keep scoped installs independent and rollback-safe.
                        $table->unsignedBigInteger('user_id');
                        $table->unsignedBigInteger('titan_reach_platform_id');
                        $table->string('name');
                        $table->string('status')->default('draft');
                        $table->string('trigger_target')->default('all_posts');
                        $table->string('trigger_post_id')->nullable();
                        $table->json('trigger_post_data')->nullable();
                        $table->string('keyword_mode')->default('any');
                        $table->json('include_keywords')->nullable();
                        $table->json('exclude_keywords')->nullable();
                        $table->boolean('enable_public_replies')->default(false);
                        $table->unsignedInteger('delay_seconds')->default(0);
                        $table->timestamps();
            
                        $table->index(['user_id', 'status'], 'idx_user_id_status_82107634');
                        $table->index(['titan_reach_platform_id', 'status'], 'idx_titan_reach_platform_i_a6563cd3');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_automations');
    }
};
