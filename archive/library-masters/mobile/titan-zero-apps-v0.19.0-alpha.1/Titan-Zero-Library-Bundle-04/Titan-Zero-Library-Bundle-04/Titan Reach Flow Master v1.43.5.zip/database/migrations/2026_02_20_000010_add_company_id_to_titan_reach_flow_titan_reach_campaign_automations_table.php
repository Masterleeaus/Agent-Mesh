<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_flow_automations') && ! Schema::hasColumn('titan_reach_flow_automations', 'company_id')) {
            Schema::table('titan_reach_flow_automations', function (Blueprint $table): void {
                $table->unsignedBigInteger('company_id')->nullable()->after('user_id')->index('idx_company_id_c2e24dae');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_reach_flow_automations') && Schema::hasColumn('titan_reach_flow_automations', 'company_id')) {
            Schema::table('titan_reach_flow_automations', function (Blueprint $table): void {
                $table->dropColumn('company_id');
            });
        }
    }
};
