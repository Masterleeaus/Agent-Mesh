<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_automation_replies')) {
            Schema::create('titan_reach_flow_automation_replies', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('automation_id');
                        $table->text('content');
                        $table->timestamps();
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_automation_replies');
    }
};
