<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_flow_automation_logs') && ! Schema::hasColumn('titan_reach_flow_automation_logs', 'social_lead_id')) {
            Schema::table('titan_reach_flow_automation_logs', function (Blueprint $table) {
                $table->unsignedBigInteger('social_lead_id')->nullable()->after('automation_id')->index('idx_social_lead_id_a4a02e19');
            });
        }

        if (Schema::hasTable('titan_reach_flow_pending_automations') && ! Schema::hasColumn('titan_reach_flow_pending_automations', 'social_lead_id')) {
            Schema::table('titan_reach_flow_pending_automations', function (Blueprint $table) {
                $table->unsignedBigInteger('social_lead_id')->nullable()->after('automation_id')->index('idx_social_lead_id_9740e687');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_reach_flow_automation_logs') && Schema::hasColumn('titan_reach_flow_automation_logs', 'social_lead_id')) {
            Schema::table('titan_reach_flow_automation_logs', function (Blueprint $table) {
                $table->dropColumn('social_lead_id');
            });
        }

        if (Schema::hasTable('titan_reach_flow_pending_automations') && Schema::hasColumn('titan_reach_flow_pending_automations', 'social_lead_id')) {
            Schema::table('titan_reach_flow_pending_automations', function (Blueprint $table) {
                $table->dropColumn('social_lead_id');
            });
        }
    }
};
