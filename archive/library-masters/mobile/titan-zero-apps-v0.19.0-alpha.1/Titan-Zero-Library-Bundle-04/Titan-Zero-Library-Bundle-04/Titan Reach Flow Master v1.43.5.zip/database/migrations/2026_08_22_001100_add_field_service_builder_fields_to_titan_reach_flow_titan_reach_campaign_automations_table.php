<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_flow_automations') && ! Schema::hasColumn('titan_reach_flow_automations', 'field_service_preset')) {
            Schema::table('titan_reach_flow_automations', function (Blueprint $table) {
                $table->string('field_service_preset', 80)->nullable()->after('workflow_graph')->index('idx_field_service_preset_0c2d4eea');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_reach_flow_automations') && Schema::hasColumn('titan_reach_flow_automations', 'field_service_preset')) {
            Schema::table('titan_reach_flow_automations', function (Blueprint $table) {
                $table->dropColumn('field_service_preset');
            });
        }
    }
};
