<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_automation_logs')) {
            Schema::create('titan_reach_flow_automation_logs', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('automation_id');
                        $table->string('platform_comment_id')->nullable();
                        $table->string('commenter_id')->nullable();
                        $table->string('commenter_username')->nullable();
                        $table->string('comment_text')->nullable();
                        $table->json('actions_executed')->nullable();
                        $table->string('status')->default('success');
                        $table->text('error_message')->nullable();
                        $table->timestamps();
            
                        $table->index('automation_id', 'idx_automation_id_69e86bc8');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_automation_logs');
    }
};
