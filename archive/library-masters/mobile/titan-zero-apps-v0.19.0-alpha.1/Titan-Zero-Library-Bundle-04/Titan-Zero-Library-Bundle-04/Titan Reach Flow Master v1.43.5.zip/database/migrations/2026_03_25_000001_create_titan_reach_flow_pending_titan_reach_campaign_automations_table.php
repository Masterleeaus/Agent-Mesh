<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_pending_automations')) {
            Schema::create('titan_reach_flow_pending_automations', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('automation_id');
                        $table->json('comment_data');
                        $table->timestamp('execute_at');
                        $table->string('status')->default('pending');
                        $table->text('error_message')->nullable();
                        $table->timestamps();
            
                        $table->index(['status', 'execute_at'], 'idx_status_execute_at_a3da1bda');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_pending_automations');
    }
};
