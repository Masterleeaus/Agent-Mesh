<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_automation_actions')) {
            Schema::create('titan_reach_flow_automation_actions', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('automation_id');
                        $table->string('type');
                        $table->json('content');
                        $table->unsignedInteger('order')->default(0);
                        $table->timestamps();
            
                        $table->index(['automation_id', 'order'], 'idx_automation_id_order_ef739577');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_automation_actions');
    }
};
