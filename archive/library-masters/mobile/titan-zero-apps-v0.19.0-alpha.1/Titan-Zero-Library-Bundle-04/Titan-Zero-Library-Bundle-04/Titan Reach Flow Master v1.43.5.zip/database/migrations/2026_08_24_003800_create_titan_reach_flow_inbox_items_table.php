<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_flow_inbox_items')) { return; }
        Schema::create('titan_reach_flow_inbox_items', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index('idx_company_id_6e5817ac');
            $table->unsignedBigInteger('social_lead_id')->nullable()->index('idx_social_lead_id_d62f37a1');
            $table->string('platform', 40)->index('idx_platform_66a6f9b1');
            $table->string('source_type', 40)->index('idx_source_type_c97926c4');
            $table->string('source_id')->nullable()->index('idx_source_id_b86feefa');
            $table->string('thread_key', 128)->nullable()->index('idx_thread_key_9323b654');
            $table->string('category', 40)->default('general')->index('idx_category_ad34e515');
            $table->string('priority', 20)->default('normal')->index('idx_priority_af8418a2');
            $table->string('status', 24)->default('open')->index('idx_status_bd82ebb6');
            $table->boolean('requires_human')->default(false)->index('idx_requires_human_2274f7eb');
            $table->boolean('safety_risk')->default(false)->index('idx_safety_risk_37227b98');
            $table->text('message_excerpt')->nullable();
            $table->json('redacted_metadata')->nullable();
            $table->timestamp('received_at')->nullable()->index('idx_received_at_cfc4c5cf');
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            $table->index(['company_id','status','priority','received_at'], 'titan_reach_flow_inbox_company_attention_idx');
            $table->unique(['company_id','platform','source_type','source_id'], 'titan_reach_flow_inbox_source_unique');
        });
    }
    public function down(): void { Schema::dropIfExists('titan_reach_flow_inbox_items'); }
};
