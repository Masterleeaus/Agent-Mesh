<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_reach_flow_social_leads')) {
            Schema::create('titan_reach_flow_social_leads', function (Blueprint $table) {
                        $table->id();
                        $table->unsignedBigInteger('company_id')->nullable()->index('idx_company_id_5b1007f1');
                        $table->unsignedBigInteger('automation_id')->nullable()->index('idx_automation_id_265edab8');
                        $table->string('platform', 40)->index('idx_platform_e1ef9447');
                        $table->string('source_extension', 120)->nullable();
                        $table->string('source_account_id')->nullable()->index('idx_source_account_id_422e7950');
                        $table->string('source_post_id')->nullable()->index('idx_source_post_id_b649d647');
                        $table->string('source_campaign_id')->nullable()->index('idx_source_campaign_id_cb8b89f9');
                        $table->string('source_comment_id')->nullable()->index('idx_source_comment_id_35c6384e');
                        $table->string('attribution_key')->nullable()->index('idx_attribution_key_c90ccba9');
                        $table->string('service_interest')->nullable()->index('idx_service_interest_fcb6fe19');
                        $table->string('service_area')->nullable()->index('idx_service_area_993f05c6');
                        $table->string('urgency', 32)->default('unknown')->index('idx_urgency_6ed44f73');
                        $table->string('status', 32)->default('new')->index('idx_status_75f90edf');
                        $table->string('consent_status', 32)->default('unknown');
                        $table->string('contact_channel', 40)->nullable();
                        $table->string('contact_value_hash', 128)->nullable();
                        $table->string('customer_external_id_hash', 128)->nullable();
                        $table->string('customer_handle_hash', 128)->nullable();
                        $table->string('customer_name_hash', 128)->nullable();
                        $table->text('first_message_excerpt')->nullable();
                        $table->json('metadata')->nullable();
                        $table->timestamp('first_seen_at')->nullable();
                        $table->timestamp('last_activity_at')->nullable();
                        $table->timestamps();
            
                        $table->index(['company_id', 'status', 'last_activity_at'], 'titan_reach_flow_social_leads_company_status_activity_idx');
                        $table->index(['company_id', 'service_interest', 'service_area'], 'titan_reach_flow_social_leads_company_service_area_idx');
                        $table->unique(['company_id', 'platform', 'source_comment_id'], 'titan_reach_flow_social_leads_company_platform_comment_unique');
                    });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_flow_social_leads');
    }
};
