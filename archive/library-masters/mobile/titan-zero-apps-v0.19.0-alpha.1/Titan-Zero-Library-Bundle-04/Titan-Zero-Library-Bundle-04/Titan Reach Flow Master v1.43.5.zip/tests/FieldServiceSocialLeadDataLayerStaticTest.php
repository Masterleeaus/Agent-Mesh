<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldServiceSocialLeadDataLayerStaticTest extends TestCase
{
    public function test_social_lead_data_layer_files_exist(): void
    {
        $root = dirname(__DIR__);

        $this->assertFileExists($root . '/System/Models/SocialLead.php');
        $this->assertFileExists($root . '/System/Services/FieldService/FieldServiceSocialLeadService.php');
        $this->assertFileExists($root . '/System/Services/FieldService/SharedFieldServiceSocialLeadEmitter.php');
        $this->assertFileExists($root . '/database/migrations/2026_08_22_001000_create_titan_reach_flow_social_leads_table.php');
    }

    public function test_social_leads_are_company_scoped_and_privacy_safe(): void
    {
        $root = dirname(__DIR__);
        $migration = file_get_contents($root . '/database/migrations/2026_08_22_001000_create_titan_reach_flow_social_leads_table.php');
        $service = file_get_contents($root . '/System/Services/FieldService/FieldServiceSocialLeadService.php');

        $this->assertStringContainsString("'company_id'", $migration);
        $this->assertStringContainsString('titan_reach_flow_social_leads_company_status_activity_idx', $migration);
        $this->assertStringContainsString('hash_hmac', $service);
        $this->assertStringContainsString('inferServiceInterest', $service);
        $this->assertStringContainsString('inferServiceArea', $service);
        $this->assertStringContainsString('inferUrgency', $service);
    }
}
