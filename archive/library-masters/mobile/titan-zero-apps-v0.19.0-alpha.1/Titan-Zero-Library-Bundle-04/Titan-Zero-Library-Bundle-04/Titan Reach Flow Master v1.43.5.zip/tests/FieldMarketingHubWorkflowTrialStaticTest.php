<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Tests;

use App\Extensions\TitanReachFlow\System\Support\FieldMarketingHubWorkflowTrial;

final class FieldMarketingHubWorkflowTrialStaticTest
{
    public function test_complete_workflow_passes_without_auto_publish(): void
    {
        $trial = new FieldMarketingHubWorkflowTrial();
        $result = $trial->evaluate([
            'company_id' => 1001,
            'context_ready' => true,
            'vertical_pack' => 'cleaning',
            'draft_created' => true,
            'media_privacy_acknowledged' => true,
            'publish_governance_reviewed' => true,
            'publish_request_ready' => true,
            'attribution_key' => 'demo-attribution-key',
        ]);

        assert($result['passed'] === true);
        assert($result['dry_run_only'] === true);
    }

    public function test_missing_company_or_unsafe_claim_blocks_workflow(): void
    {
        $trial = new FieldMarketingHubWorkflowTrial();
        $result = $trial->evaluate([
            'mentions_emergency' => true,
            'emergency_configured' => false,
            'auto_publish_attempted' => true,
            'token' => 'secret-token',
        ]);

        assert($result['passed'] === false);
        assert(in_array('company_id_missing', $result['blocked_reasons'], true));
        assert(in_array('emergency_claim_not_configured', $result['blocked_reasons'], true));
        assert(in_array('auto_publish_blocked', $result['blocked_reasons'], true));
        assert($result['redacted_context']['token'] === '[redacted]');
    }
}
