<?php

declare(strict_types=1);
use PHPUnit\Framework\TestCase;
final class TitanReachInboxStaticTest extends TestCase
{
    public function test_inbox_assets_are_present(): void
    {
        $root=dirname(__DIR__);
        foreach (['config/titan-reach-inbox.php','System/Models/TitanReachInboxItem.php','System/Services/Inbox/TitanReachInboxClassifier.php','System/Services/Inbox/TitanReachInboxService.php','System/Support/TitanReachInboxBridge.php','System/Http/Controllers/TitanReachInboxController.php','resources/views/inbox/index.blade.php'] as $path) self::assertFileExists($root.'/'.$path);
    }
    public function test_company_boundary_and_attention_categories_are_declared(): void
    {
        $root=dirname(__DIR__); $code=file_get_contents($root.'/System/Services/Inbox/TitanReachInboxService.php');
        self::assertStringContainsString("company_id is required",$code);
        $config=file_get_contents($root.'/config/titan-reach-inbox.php');
        foreach(['quote_request','booking_request','complaint','urgent_safety','human_review'] as $value) self::assertStringContainsString($value,$config);
    }
}
