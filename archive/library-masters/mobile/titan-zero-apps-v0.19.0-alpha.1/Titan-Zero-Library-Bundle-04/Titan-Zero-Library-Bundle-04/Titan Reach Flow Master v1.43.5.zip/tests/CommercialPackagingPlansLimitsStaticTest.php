<?php

namespace App\Extensions\TitanReachFlow\Tests;

use App\Extensions\TitanReachFlow\System\Support\FieldServiceCommercialPlanLimits;

final class CommercialPackagingPlansLimitsStaticTest
{
    public function testCommercialPlanHelperFailsClosedAndPreservesSafetyControls(): void
    {
        $helper = new FieldServiceCommercialPlanLimits();
        $payload = $helper->describe('free');

        assert($payload['plan'] === 'free');
        assert($payload['security_controls_locked'] === true);
        assert($payload['privacy_controls_locked'] === true);
        assert($payload['platform_ai_default_enabled'] === false);
        assert($helper->allows('field_service_context', 'free') === true);
        assert($helper->allows('titan_integrations', 'free') === false);
        assert($helper->assertAllowed('titan_integrations', 'free')['allowed'] === false);
    }
}
