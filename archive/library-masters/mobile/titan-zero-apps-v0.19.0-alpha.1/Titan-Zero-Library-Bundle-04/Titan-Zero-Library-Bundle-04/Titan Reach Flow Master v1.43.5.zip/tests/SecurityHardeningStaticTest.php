<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class SecurityHardeningStaticTest extends TestCase
{
    private function read(string $path): string
    {
        return file_get_contents(dirname(__DIR__) . '/' . $path) ?: '';
    }

    public function test_webhook_signatures_replay_and_redaction_are_enforced(): void
    {
        $controller = $this->read('System/Http/Controllers/WebhookController.php');
        $security = $this->read('System/Support/WebhookSecurity.php');
        $processor = $this->read('System/Services/WebhookProcessor.php');

        self::assertStringContainsString('configuredSecret', $security);
        self::assertStringContainsString('rejectReplay', $security);
        self::assertStringContainsString('verifyHubSignature', $security);
        self::assertStringContainsString('verifyTimestampedHmac', $security);
        self::assertStringContainsString('Cache::add', $security);
        self::assertStringContainsString("['default-password', 'changeme', 'secret']", $security);
        self::assertStringContainsString('verifyHubSignature($request', $controller);
        self::assertStringContainsString('verifyTimestampedHmac($request', $controller);
        self::assertStringContainsString('WebhookSecurity::redacted', $processor);
        self::assertStringNotContainsString('payload_preview', $controller);
        self::assertStringNotContainsString('getTraceAsString', $controller);
    }

    public function test_public_webhook_routes_are_throttled_and_automation_is_company_correlated(): void
    {
        $provider = $this->read('System/TitanReachFlowServiceProvider.php');
        $service = $this->read('System/Services/AutomationExecutionService.php');
        $migration = $this->read('database/migrations/2026_02_20_000010_add_company_id_to_titan_reach_flow_titan_reach_campaign_automations_table.php');

        self::assertStringContainsString("'middleware' => ['throttle:60,1']", $provider);
        self::assertStringNotContainsString('Route::any', $provider);
        self::assertStringContainsString("where('company_id', $", $service);
        self::assertStringContainsString("credentials->company_id", $service);
        self::assertStringContainsString("company_id", $migration);
    }
}
