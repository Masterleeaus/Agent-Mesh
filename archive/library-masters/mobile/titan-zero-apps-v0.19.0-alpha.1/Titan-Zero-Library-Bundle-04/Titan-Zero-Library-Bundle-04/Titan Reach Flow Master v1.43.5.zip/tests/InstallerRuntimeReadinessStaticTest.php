<?php

declare(strict_types=1);

use App\Extensions\TitanReachFlow\System\Support\InstallerRuntimeReadiness;
use PHPUnit\Framework\TestCase;

final class InstallerRuntimeReadinessStaticTest extends TestCase
{
    public function test_runtime_manifest_is_complete(): void
    {
        $manifest = InstallerRuntimeReadiness::manifest();

        self::assertSame('titan-reach-flow', $manifest['extension_key']);
        self::assertSame('lead_review_automation', $manifest['module_slug']);
        self::assertSame('1.12', $manifest['version']);
        self::assertTrue($manifest['requires_company_id']);
        self::assertTrue($manifest['standalone_safe']);
        self::assertTrue($manifest['public_webhooks_fail_closed']);
    }

    public function test_extension_manifest_matches_runtime_version(): void
    {
        $root = dirname(__DIR__);
        $json = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);

        self::assertSame([], InstallerRuntimeReadiness::manifestErrors($json));
    }

    public function test_required_runtime_files_are_present(): void
    {
        $root = dirname(__DIR__);
        $checks = InstallerRuntimeReadiness::filesystemChecks($root);
        $missing = array_values(array_filter($checks, static fn (array $row): bool => ! (bool) $row['ok']));

        self::assertSame([], $missing);
    }
}
