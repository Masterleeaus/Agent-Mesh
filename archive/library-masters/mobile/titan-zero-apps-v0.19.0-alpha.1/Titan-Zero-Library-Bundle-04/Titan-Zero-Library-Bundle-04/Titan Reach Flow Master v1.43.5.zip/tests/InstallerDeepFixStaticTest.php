<?php
$root=dirname(__DIR__); $fail=[]; $ok=function($c,$m)use(&$fail){if(!$c)$fail[]=$m;};
$m=json_decode(file_get_contents($root.'/extension.json'),true);
$ok(($m['schema']??null)==='titan-extension-v1','schema');
$ok((bool)preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/',(string)($m['version']??'')),'semver');
foreach(($m['dependencies']??[]) as $d)$ok(!str_starts_with((string)($d['slug']??''),'titan-reach-'),'hard Reach sibling dependency');
$all=''; foreach(glob($root.'/database/migrations/*.php')?:[] as $f)$all.=file_get_contents($f)."\n";
$ok(!preg_match('/->(?:foreign|constrained|references)\s*\(/',$all),'database FK found');
$ok(!preg_match('/->(?:index|unique)\s*\(\s*\)/',$all),'implicit index name found');
$prov=file_get_contents($root.'/System/TitanReachFlowServiceProvider.php');
$ok(str_contains($prov,'TitanReachMenuInstaller::healIfNeeded'),'menu healer not boot-wired');
$ok(is_file($root.'/System/Navigation/TitanReachMenuInstaller.php'),'menu installer missing');
$ok(is_file($root.'/System/Navigation/TitanReachMenuDefinition.php'),'menu definition missing');
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);} echo "PASS\n";
