<?php

namespace App\Extensions\TitanReachFlow\System\Contracts\FieldService;

interface FieldServiceEventPublisher
{
    /** @param array<string, mixed> $payload @param array<string, mixed> $metadata @return array<string, mixed> */
    public function publish(string $eventType, int|string $companyId, string $sourceExtension, array $payload = [], array $metadata = []): array;
}
