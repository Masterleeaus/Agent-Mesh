<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachFlow\System\Services\Inbox;

final class TitanReachInboxClassifier
{
    public function classify(string $text, ?int $rating = null): array
    {
        $t = mb_strtolower($text);
        $has = fn(array $terms): bool => collect($terms)->contains(fn(string $term) => str_contains($t, $term));
        if ($has(config('titan-reach-inbox.safety_terms', []))) return ['category'=>'urgent_safety','priority'=>'urgent','requires_human'=>true,'safety_risk'=>true];
        if ($has(['complaint','unhappy','refund','damaged','poor service','not happy'])) return ['category'=>'complaint','priority'=>'high','requires_human'=>true,'safety_risk'=>false];
        if ($rating !== null && $rating <= 2) return ['category'=>'review','priority'=>'high','requires_human'=>true,'safety_risk'=>false];
        if ($has(['quote','price','cost','estimate'])) return ['category'=>'quote_request','priority'=>'high','requires_human'=>false,'safety_risk'=>false];
        if ($has(['book','booking','available','appointment','when can'])) return ['category'=>'booking_request','priority'=>'high','requires_human'=>false,'safety_risk'=>false];
        if ($rating !== null) return ['category'=>'review','priority'=>'normal','requires_human'=>true,'safety_risk'=>false];
        if ($has(['spam','crypto','investment opportunity'])) return ['category'=>'spam','priority'=>'low','requires_human'=>false,'safety_risk'=>false];
        return ['category'=>'lead','priority'=>'normal','requires_human'=>false,'safety_risk'=>false];
    }
}
