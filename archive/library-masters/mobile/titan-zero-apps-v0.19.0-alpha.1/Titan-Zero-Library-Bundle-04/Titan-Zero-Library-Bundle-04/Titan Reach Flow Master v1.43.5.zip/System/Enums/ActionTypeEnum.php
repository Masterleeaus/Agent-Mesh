<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Enums;

enum ActionTypeEnum: string
{
    case Text = 'text';
    case Button = 'button';
    case Image = 'image';
    case QuickReplies = 'quick_replies';
    case Delay = 'delay';
    case FieldServiceQuote = 'field_service_quote';
    case FieldServiceBooking = 'field_service_booking';
    case FieldServiceReviewRequest = 'field_service_review_request';
    case FieldServiceEmergencyHandoff = 'field_service_emergency_handoff';
    case FieldServiceAvailability = 'field_service_availability';
    case FieldServiceComplaintHandoff = 'field_service_complaint_handoff';
    case FieldServiceLeadQualifier = 'field_service_lead_qualifier';

    public function label(): string
    {
        return match ($this) {
            self::Text => __('Text Message'),
            self::Button => __('Button'),
            self::Image => __('Image'),
            self::QuickReplies => __('Quick Replies'),
            self::Delay => __('Persisted Delay'),
            self::FieldServiceQuote => __('Field-Service Quote Capture'),
            self::FieldServiceBooking => __('Field-Service Booking CTA'),
            self::FieldServiceReviewRequest => __('Field-Service Review Request'),
            self::FieldServiceEmergencyHandoff => __('Emergency Handoff'),
            self::FieldServiceAvailability => __('Availability Response'),
            self::FieldServiceComplaintHandoff => __('Complaint Handoff'),
            self::FieldServiceLeadQualifier => __('Lead Qualifier'),
        };
    }
}
