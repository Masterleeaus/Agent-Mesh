<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Integration\TitanApps;

/**
 * Provider-owned semantic contributions for the public Titan Apps boundary.
 *
 * This adapter intentionally contains no Interface Runtime, Interaction Engine or Builder
 * implementation and grants no execution authority. Actions remain capability intents.
 */
final class TitanAppsContributionProvider
{
    public const OWNER_EXTENSION = 'titan-reach-flow';
    public const REGISTRY_KEY = 'titan-apps.interface-contributions.' . self::OWNER_EXTENSION;

    /** @return array<int,array<string,mixed>> */
    public function contributions(): array
    {
        return [['contribution_id' => 'reach.flow-summary', 'owner_extension' => 'titan-reach-flow', 'supported_surfaces' => ['zero'], 'variants' => ['AutomationFlowSummary'], 'projection_ids' => ['reach.flow.read'], 'action_ids' => ['reach.flow.activate'], 'capability_ids' => ['reach.flow.read', 'reach.flow.activate'], 'permissions' => ['reach.flow.read', 'reach.flow.activate'], 'sensitivity' => 'business_confidential', 'risk_classification' => 'governed', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability']];
    }

    /** @return array<string,mixed> */
    public function contractDescriptor(): array
    {
        return [
            'owner_extension' => self::OWNER_EXTENSION,
            'supported_surfaces' => $this->supportedSurfaces(),
            'canonical_app_boundary' => ['zero', 'go', 'hub'],
            'canonical_surfaces_only' => true,
            'interface_runtime' => 'public_contract_only',
            'interaction_engine' => 'public_contract_only',
            'builder' => 'contribution_registration_only',
            'package_location_independent' => true,
            'authority' => 'none',
        ];
    }
    /** @return array<int,string> */
    private function supportedSurfaces(): array
    {
        $surfaces = [];
        foreach ($this->contributions() as $contribution) {
            foreach (($contribution['supported_surfaces'] ?? []) as $surface) {
                if (is_string($surface) && ! in_array($surface, $surfaces, true)) {
                    $surfaces[] = $surface;
                }
            }
        }

        return $surfaces;
    }

}
