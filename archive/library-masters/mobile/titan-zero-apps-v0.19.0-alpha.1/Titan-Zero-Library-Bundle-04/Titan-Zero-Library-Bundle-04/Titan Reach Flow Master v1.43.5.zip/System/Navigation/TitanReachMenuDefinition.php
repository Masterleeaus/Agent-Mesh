<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Navigation;

final class TitanReachMenuDefinition
{
    public static function root(): array
    {
        return [
            'key' => 'ext_titan_reach',
            'label' => 'Marketing & Advertising',
            'route' => null,
            'icon' => 'tabler-speakerphone',
            'order' => 8,
        ];
    }

    public static function item(): array
    {
        return [
            'key' => 'titan_reach_flow',
            'label' => 'Reach Inbox',
            'route' => 'dashboard.user.titan-reach.automation.inbox.index',
            'icon' => 'tabler-inbox',
            'order' => 3,
        ];
    }
}
