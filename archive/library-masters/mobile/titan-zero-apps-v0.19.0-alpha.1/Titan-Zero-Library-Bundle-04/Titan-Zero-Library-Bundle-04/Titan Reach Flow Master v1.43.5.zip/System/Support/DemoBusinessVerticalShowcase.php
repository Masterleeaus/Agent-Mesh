<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

final class DemoBusinessVerticalShowcase
{
    /**
     * Return deterministic demo-only vertical seed payloads.
     * These examples are safe starter content and must never be treated as real
     * customer records, licences, coverage, prices, warranties or emergency claims.
     *
     * @return array<int, array<string, mixed>>
     */
    public function verticals(?array $config = null): array
    {
        $config ??= config('field-service-demo-showcase.verticals', []);
        $items = [];

        foreach ($config as $slug => $vertical) {
            if (! is_array($vertical)) {
                continue;
            }

            $items[] = $this->normalise((string) $slug, $vertical);
        }

        return $items;
    }

    /**
     * @param array<string, mixed> $vertical
     * @return array<string, mixed>
     */
    private function normalise(string $slug, array $vertical): array
    {
        return [
            'slug' => $slug,
            'demo_only' => true,
            'business_name' => (string) ($vertical['demo_business_name'] ?? 'Demo Field Service Business'),
            'vertical' => (string) ($vertical['vertical'] ?? $slug),
            'services' => $this->safeList($vertical['services'] ?? []),
            'service_areas' => $this->safeList($vertical['service_areas'] ?? []),
            'content_lanes' => $this->safeList($vertical['content_lanes'] ?? []),
            'automation_keywords' => $this->safeList($vertical['automation_keywords'] ?? []),
            'default_cta' => (string) ($vertical['default_cta'] ?? 'Request a quote'),
            'privacy_warning' => (string) ($vertical['privacy_warning'] ?? 'Do not invent licences, prices, coverage or customer details.'),
            'forbidden_claims' => [
                'real_customer_identity',
                'licence_or_insurance_status',
                'prices_or_discounts',
                'emergency_availability',
                'guaranteed_geographic_coverage',
                'warranty_or_authorised_repairer_status',
            ],
        ];
    }

    /**
     * @param mixed $value
     * @return array<int, string>
     */
    private function safeList(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map(static function ($item): string {
            return trim((string) $item);
        }, $value), static fn (string $item): bool => $item !== ''));
    }
}
