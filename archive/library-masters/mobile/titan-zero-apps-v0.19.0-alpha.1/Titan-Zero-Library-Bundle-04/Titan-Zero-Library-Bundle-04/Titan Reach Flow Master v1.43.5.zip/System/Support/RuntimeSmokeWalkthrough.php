<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

/**
 * Static runtime smoke-map for install walk-through validation.
 *
 * The class avoids framework calls so ZIP validators and post-install PHPUnit
 * can check route names, view files, controllers, config and workspace links
 * before a browser user hits a blank page.
 */
final class RuntimeSmokeWalkthrough
{
    public const EXTENSION_KEY = 'titan-reach-flow';
    public const MODULE_SLUG = 'lead_review_automation';
    public const MODULE_NAME = 'Lead & Review Automation';
    public const VERSION = '1.13';

    /** @return array<string, mixed> */
    public static function manifest(): array
    {
        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'module_name' => self::MODULE_NAME,
            'version' => self::VERSION,
            'route_names' => self::routeNames(),
            'route_prefixes' => self::routePrefixes(),
            'views' => self::viewPaths(),
            'controllers' => self::controllerPaths(),
            'navigation_modules' => ['field_marketing_hub', 'local_growth_agent', 'lead_review_automation', 'campaign_playbooks'],
            'permission_required' => 'field_service_marketing.view',
            'company_scoped' => true,
            'standalone_safe' => true,
        ];
    }

    /** @return array<int, string> */
    public static function routeNames(): array
    {
        return [
    'dashboard.user.titan-reach.automation.field-service-workspace',
    'dashboard.user.titan-reach.automation.index',
    'dashboard.user.titan-reach.automation.create',
    'dashboard.user.titan-reach.automation.field-service-presets',
    'dashboard.user.titan-reach.automation.social-leads.index',
    'titan-reach.automation.webhook.facebook',
    'titan-reach.automation.webhook.instagram'
];
    }

    /** @return array<int, string> */
    public static function routePrefixes(): array
    {
        return [
    'dashboard/user/titan-reach/automation',
    'titan-reach/automation/webhook'
];
    }

    /** @return array<int, string> */
    public static function viewPaths(): array
    {
        return [
    'resources/views/field-service-workspace.blade.php',
    'resources/views/index.blade.php',
    'resources/views/builder/index.blade.php'
];
    }

    /** @return array<int, string> */
    public static function controllerPaths(): array
    {
        return [
    'System/Http/Controllers/FieldServiceWorkspaceController.php',
    'System/Http/Controllers/AutomationController.php',
    'System/Http/Controllers/AutomationBuilderController.php',
    'System/Http/Controllers/SocialLeadController.php',
    'System/Http/Controllers/WebhookController.php'
];
    }

    /**
     * @param string $extensionRoot absolute extension root path.
     * @return array<int, array<string, string|bool>>
     */
    public static function filesystemChecks(string $extensionRoot): array
    {
        $root = rtrim($extensionRoot, DIRECTORY_SEPARATOR);
        $required = array_merge(
            ['extension.json', 'README.md', 'config/field-service-runtime-smoke.php', 'resources/views/field-service-workspace.blade.php'],
            self::viewPaths(),
            self::controllerPaths()
        );
        $required = array_values(array_unique($required));

        return array_map(static function (string $path) use ($root): array {
            $absolute = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);

            return [
                'path' => $path,
                'ok' => file_exists($absolute),
                'message' => file_exists($absolute) ? 'present' : 'missing route/view/controller smoke dependency',
            ];
        }, $required);
    }

    /**
     * @param string $extensionRoot absolute extension root path.
     * @return array<int, array<string, string|bool>>
     */
    public static function sourceChecks(string $extensionRoot): array
    {
        $root = rtrim($extensionRoot, DIRECTORY_SEPARATOR);
        $provider = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, 'System/TitanReachFlowServiceProvider.php');
        $source = is_file($provider) ? (string) file_get_contents($provider) : '';
        $checks = [
            [
                'name' => 'runtime smoke config is registered',
                'ok' => str_contains($source, 'field-service-runtime-smoke.php'),
                'message' => 'service provider must merge field-service-runtime-smoke.php',
            ],
            [
                'name' => 'workspace route is registered',
                'ok' => str_contains($source, 'field-service-workspace'),
                'message' => 'service provider must expose field-service-workspace route',
            ],
            [
                'name' => 'authenticated browser routes remain protected',
                'ok' => str_contains($source, "'web', 'auth'") || str_contains($source, '"web", "auth"'),
                'message' => 'browser smoke routes must stay behind web/auth middleware',
            ],
        ];

        foreach (self::routePrefixes() as $prefix) {
            $checks[] = [
                'name' => 'route prefix ' . $prefix,
                'ok' => str_contains($source, $prefix),
                'message' => 'expected runtime route prefix missing from provider source',
            ];
        }

        return $checks;
    }

    /** @return array<string, mixed> */
    public static function report(string $extensionRoot): array
    {
        $filesystem = self::filesystemChecks($extensionRoot);
        $source = self::sourceChecks($extensionRoot);
        $failedFilesystem = array_values(array_filter($filesystem, static fn (array $row): bool => ! (bool) $row['ok']));
        $failedSource = array_values(array_filter($source, static fn (array $row): bool => ! (bool) $row['ok']));

        return [
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'version' => self::VERSION,
            'filesystem' => $filesystem,
            'source' => $source,
            'ok' => $failedFilesystem === [] && $failedSource === [],
        ];
    }
}
