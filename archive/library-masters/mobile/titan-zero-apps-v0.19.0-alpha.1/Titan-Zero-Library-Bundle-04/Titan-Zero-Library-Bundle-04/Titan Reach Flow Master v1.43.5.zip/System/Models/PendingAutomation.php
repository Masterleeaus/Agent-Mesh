<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PendingAutomation extends Model
{
    protected $table = 'titan_reach_flow_pending_automations';

    protected $fillable = [
        'automation_id',
        'social_lead_id',
        'comment_data',
        'execute_at',
        'status',
        'error_message',
    ];

    protected $casts = [
        'comment_data' => 'array',
        'execute_at'   => 'datetime',
    ];

    public function automation(): BelongsTo
    {
        return $this->belongsTo(Automation::class);
    }
}
