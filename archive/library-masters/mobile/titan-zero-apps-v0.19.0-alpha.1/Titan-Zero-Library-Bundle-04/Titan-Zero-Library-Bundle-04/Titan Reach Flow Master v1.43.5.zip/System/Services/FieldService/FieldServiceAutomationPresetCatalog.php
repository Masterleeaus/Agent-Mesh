<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

class FieldServiceAutomationPresetCatalog
{
    /** @return array<string, array<string, mixed>> */
    public function presets(array $context = []): array
    {
        $hasQuote = ! empty($context['quote_url']);
        $hasBooking = ! empty($context['booking_url']);
        $hasReview = ! empty($context['review_url']);
        $emergency = (bool) ($context['emergency_available'] ?? false);
        $verticalPack = (new FieldServiceVerticalPackCatalog())->resolve((string) ($context['vertical'] ?? ''));
        $verticalKeywords = array_values($verticalPack['automation_keyword_suggestions'] ?? []);

        return [
            'quote_request' => [
                'label' => 'Quote or price request',
                'trigger_keywords' => array_values(array_unique(array_merge(['quote', 'price', 'cost', 'estimate', 'how much'], $verticalKeywords))),
                'actions' => [
                    ['type' => 'field_service_lead_qualifier', 'content' => ['fields' => ['service_interest', 'service_area', 'urgency']]],
                    ['type' => 'field_service_quote', 'content' => ['requires_configured_url' => $hasQuote]],
                ],
            ],
            'availability_request' => [
                'label' => 'Availability or booking request',
                'trigger_keywords' => ['available', 'booking', 'book', 'appointment', 'when'],
                'actions' => [
                    ['type' => 'field_service_availability', 'content' => ['safe_default' => 'We can check availability after we know your service and area.']],
                    ['type' => 'field_service_booking', 'content' => ['requires_configured_url' => $hasBooking]],
                ],
            ],
            'emergency_request' => [
                'label' => 'Emergency enquiry',
                'enabled' => $emergency,
                'trigger_keywords' => ['emergency', 'urgent', 'asap', 'today', 'now'],
                'actions' => [
                    ['type' => 'field_service_emergency_handoff', 'content' => ['enabled' => $emergency]],
                ],
            ],
            'review_request' => [
                'label' => 'Positive comment to review',
                'trigger_keywords' => ['great', 'thanks', 'excellent', 'happy', 'recommend'],
                'actions' => [
                    ['type' => 'field_service_review_request', 'content' => ['requires_configured_url' => $hasReview]],
                ],
            ],
            'complaint_handoff' => [
                'label' => 'Complaint or problem handoff',
                'trigger_keywords' => ['complaint', 'problem', 'issue', 'unhappy', 'broken', 'refund'],
                'actions' => [
                    ['type' => 'field_service_complaint_handoff', 'content' => ['human_review_required' => true]],
                ],
            ],
        ];
    }
}
