<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

final class TitanReachGrowthIntelligenceBridge
{
    /** @param array<string,mixed> $context @return array<string,mixed> */
    public function recommend(array $context): array
    {
        if (empty($context['company_id'])) {
            return ['status' => 'blocked', 'reason' => 'company_id_required', 'recommendations' => []];
        }

        if (function_exists('app') && app()->bound('titan-reach.growth-intelligence')) {
            $engine = app('titan-reach.growth-intelligence');
            if (is_object($engine) && method_exists($engine, 'recommend')) {
                return $engine->recommend($context);
            }
        }

        return [
            'status' => 'standalone',
            'company_id' => (string) $context['company_id'],
            'recommendations' => [],
            'next_best_action' => null,
            'governance' => ['auto_publish' => false, 'auto_message_customers' => false],
        ];
    }
}
