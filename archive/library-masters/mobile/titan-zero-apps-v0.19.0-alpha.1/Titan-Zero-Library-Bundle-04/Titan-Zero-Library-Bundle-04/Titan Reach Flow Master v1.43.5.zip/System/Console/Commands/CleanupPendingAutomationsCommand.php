<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Console\Commands;

use App\Extensions\TitanReachFlow\System\Models\PendingAutomation;
use Illuminate\Console\Command;

class CleanupPendingAutomationsCommand extends Command
{
    protected $signature = 'titan-reach-flow:cleanup-pending';

    protected $description = 'Delete old completed and failed pending automation records';

    public function handle(): void
    {
        PendingAutomation::query()
            ->whereIn('status', ['completed', 'failed'])
            ->where('updated_at', '<', now()->subDays(7))
            ->delete();
    }
}
