<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

class FieldServiceAutomationBuilderService
{
    public function __construct(
        private SharedFieldServiceContextResolver $contextResolver,
        private FieldServiceAutomationPresetCatalog $catalog
    ) {}

    /** @return array<string, mixed> */
    public function presets(?int $companyId = null, ?int $userId = null): array
    {
        $context = $this->contextResolver->resolve($companyId, $userId);
        $presets = $this->catalog->presets($context);

        return [
            'context' => [
                'company_id' => $context['company_id'] ?? null,
                'business_name' => $context['business_name'] ?? null,
                'vertical' => $context['vertical'] ?? null,
                'services_configured' => count((array) ($context['services'] ?? [])),
                'areas_configured' => count((array) ($context['service_areas'] ?? [])),
                'quote_url_configured' => ! empty($context['quote_url']),
                'booking_url_configured' => ! empty($context['booking_url']),
                'review_url_configured' => ! empty($context['review_url']),
                'emergency_available' => (bool) ($context['emergency_available'] ?? false),
                'standalone_fallback' => (bool) ($context['standalone_fallback'] ?? false),
            ],
            'presets' => $presets,
            'guardrails' => [
                'do_not_invent_prices',
                'do_not_invent_licences',
                'do_not_invent_emergency_service',
                'do_not_invent_service_areas',
                'handoff_complaints_to_human',
            ],
        ];
    }
}
