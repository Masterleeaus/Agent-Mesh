<?php

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

use Illuminate\Support\Facades\Log;
use Throwable;

class SharedFieldServiceAttributionEmitter
{
    public function emit(array $payload): array
    {
        $payload['source_extension'] = $payload['source_extension'] ?? static::class;
        $payload['standalone_safe'] = true;

        if (class_exists('App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceAttributionService')) {
            try {
                $event = app('App\Extensions\TitanReachPro\System\Services\FieldService\FieldServiceAttributionService')->recordEvent($payload);

                return [
                    'status' => 'emitted',
                    'provider' => 'titan-reach-pro',
                    'event_id' => $event->id ?? null,
                ];
            } catch (Throwable $exception) {
                Log::warning('field_service_attribution_emit_failed', [
                    'source_extension' => static::class,
                    'event_type' => $payload['event_type'] ?? null,
                ]);
            }
        }

        return [
            'status' => 'standalone',
            'provider' => 'local-fallback',
            'event_type' => $payload['event_type'] ?? 'lead',
        ];
    }
}
