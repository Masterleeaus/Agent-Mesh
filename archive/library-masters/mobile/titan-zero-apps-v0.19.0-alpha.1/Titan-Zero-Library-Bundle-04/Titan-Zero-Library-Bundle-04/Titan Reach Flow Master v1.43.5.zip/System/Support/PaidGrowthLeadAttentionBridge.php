<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachFlow\System\Support;
final class PaidGrowthLeadAttentionBridge { public function classify(array $lead): array { return ['company_id'=>(int)($lead['company_id']??0),'source'=>(string)($lead['source']??'paid_growth'),'attention'=>'lead','human_review'=>true]; } }
