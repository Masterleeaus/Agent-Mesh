<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

use App\Extensions\TitanReachFlow\System\Models\PendingAutomation;
use Carbon\CarbonInterface;

class PersistedActionDelayService
{
    /** @param array<string, mixed> $payload */
    public function queue(int $automationId, array $payload, int $seconds, ?int $socialLeadId = null): PendingAutomation
    {
        return PendingAutomation::query()->create([
            'automation_id' => $automationId,
            'social_lead_id' => $socialLeadId,
            'comment_data' => $payload,
            'execute_at' => now()->addSeconds(max(1, min($seconds, 86400))),
            'status' => 'pending',
        ]);
    }

    public function nextRunFromSeconds(int $seconds): CarbonInterface
    {
        return now()->addSeconds(max(1, min($seconds, 86400)));
    }
}
