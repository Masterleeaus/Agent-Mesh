<?php

namespace App\Extensions\TitanReachFlow\System\Services\FieldService\Events;

use InvalidArgumentException;

final class FieldServiceEventEnvelope
{
    /** @param array<string, mixed> $payload @param array<string, mixed> $metadata */
    public function __construct(
        public readonly string $eventType,
        public readonly int|string $companyId,
        public readonly string $sourceExtension,
        public readonly array $payload = [],
        public readonly array $metadata = [],
        public readonly ?string $correlationId = null,
        public readonly ?string $occurredAt = null,
    ) {
        if (! FieldServiceEventCatalog::isKnown($eventType)) {
            throw new InvalidArgumentException('Unknown field-service event type: '.$eventType);
        }

        if ((string) $companyId === '') {
            throw new InvalidArgumentException('Field-service events require a company_id.');
        }
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'event_type' => $this->eventType,
            'company_id' => $this->companyId,
            'source_extension' => $this->sourceExtension,
            'correlation_id' => $this->correlationId ?: $this->stableCorrelationId(),
            'occurred_at' => $this->occurredAt ?: gmdate('c'),
            'payload' => $this->redactedPayload($this->payload),
            'metadata' => $this->redactedPayload($this->metadata),
        ];
    }

    public function stableCorrelationId(): string
    {
        return hash('sha256', implode('|', [
            $this->eventType,
            (string) $this->companyId,
            $this->sourceExtension,
            json_encode($this->redactedPayload($this->payload), JSON_UNESCAPED_SLASHES),
        ]));
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    private function redactedPayload(array $payload): array
    {
        $sensitive = ['token', 'access_token', 'refresh_token', 'secret', 'signature', 'password', 'customer_name', 'customer_handle', 'customer_external_id', 'contact_value', 'raw_body', 'webhook_body'];

        foreach ($payload as $key => $value) {
            $lower = strtolower((string) $key);
            if (in_array($lower, $sensitive, true) || str_contains($lower, 'token') || str_contains($lower, 'secret')) {
                $payload[$key] = '[redacted]';
                continue;
            }

            if (is_array($value)) {
                /** @var array<string, mixed> $value */
                $payload[$key] = $this->redactedPayload($value);
            }
        }

        return $payload;
    }
}
