<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

final class FieldMarketingHubWorkflowTrial
{
    private const SENSITIVE_KEYS = [
        'token', 'secret', 'signature', 'customer_name', 'customer_handle',
        'external_customer_id', 'contact_value', 'raw_webhook_body', 'message_body',
        'comment_text', 'address', 'plate', 'face',
    ];

    /**
     * Evaluate the owner-facing workflow without publishing, sending messages or creating real leads.
     *
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function evaluate(array $input): array
    {
        $companyId = $input['company_id'] ?? null;
        $checks = [
            'context_setup' => ! empty($input['context_ready']),
            'vertical_pack_selected' => ! empty($input['vertical_pack']),
            'content_draft_created' => ! empty($input['draft_created']),
            'media_privacy_reviewed' => ! empty($input['media_privacy_acknowledged']),
            'publish_governance_reviewed' => ! empty($input['publish_governance_reviewed']),
            'publish_request_handoff' => ! empty($input['publish_request_ready']) && empty($input['auto_publish_attempted']),
            'attribution_visibility' => ! empty($input['attribution_key']) || ! empty($input['attribution_visible']),
        ];

        $blocked = [];
        if (empty($companyId)) {
            $blocked[] = 'company_id_missing';
        }
        if (! empty($input['mentions_emergency']) && empty($input['emergency_configured'])) {
            $blocked[] = 'emergency_claim_not_configured';
        }
        if (! empty($input['mentions_licence']) && empty($input['licence_statement_configured'])) {
            $blocked[] = 'licence_claim_not_configured';
        }
        if (! empty($input['mentions_price']) && empty($input['price_claim_authorised'])) {
            $blocked[] = 'price_claim_not_authorised';
        }
        if (! empty($input['auto_publish_attempted'])) {
            $blocked[] = 'auto_publish_blocked';
        }

        $passed = $companyId !== null && $blocked === [] && ! in_array(false, $checks, true);

        return [
            'workflow' => 'field_marketing_hub_workflow_trial',
            'company_id' => $companyId,
            'dry_run_only' => true,
            'passed' => $passed,
            'checks' => $checks,
            'blocked_reasons' => $blocked,
            'next_safe_action' => $passed ? 'ready_for_reviewed_publish_request' : 'complete_missing_context_or_review',
            'redacted_context' => $this->redact($input),
        ];
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    public function redact(array $payload): array
    {
        foreach ($payload as $key => $value) {
            $lower = strtolower((string) $key);
            if (in_array($lower, self::SENSITIVE_KEYS, true) || str_contains($lower, 'token') || str_contains($lower, 'secret') || str_contains($lower, 'signature')) {
                $payload[$key] = '[redacted]';
                continue;
            }
            if (is_array($value)) {
                $payload[$key] = $this->redact($value);
            }
        }
        return $payload;
    }
}
