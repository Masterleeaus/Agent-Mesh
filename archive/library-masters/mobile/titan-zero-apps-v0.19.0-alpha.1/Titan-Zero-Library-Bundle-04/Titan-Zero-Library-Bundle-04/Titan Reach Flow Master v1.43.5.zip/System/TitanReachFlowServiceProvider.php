<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanReachFlow\System\Console\Commands\CleanupPendingAutomationsCommand;
use App\Extensions\TitanReachFlow\System\Console\Commands\ProcessPendingAutomationsCommand;
use App\Extensions\TitanReachFlow\System\Http\Controllers\AutomationBuilderController;
use App\Extensions\TitanReachFlow\System\Http\Controllers\AutomationController;
use App\Extensions\TitanReachFlow\System\Http\Controllers\WebhookController;
use App\Extensions\TitanReachFlow\System\Http\Controllers\SocialLeadController;
use App\Extensions\TitanReachFlow\System\Http\Controllers\FieldServiceWorkspaceController;
use App\Extensions\TitanReachFlow\System\Http\Controllers\TitanReachInboxController;
use App\Extensions\TitanReachFlow\System\Navigation\TitanReachMenuInstaller;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use App\Extensions\TitanReachFlow\System\Services\FieldService\SharedFieldServiceContextResolver;
use App\Extensions\TitanReachFlow\System\Services\FieldService\SharedFieldServiceSocialLeadEmitter;

class TitanReachFlowServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-reach-flow', \App\Extensions\TitanReachFlow\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton('field-service.live-install-evidence.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\LiveInstallerEvidenceCapture::class);
        $this->app->singleton('field-service.commercial.enforcement-upgrade-ux.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\CommercialTierEnforcementUpgradeUX::class);
        $this->app->singleton('field-service.local-growth-operational-trial.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\LocalGrowthAgentOperationalTrial::class);
        $this->app->singleton('field-service.hub-workflow-trial.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\FieldMarketingHubWorkflowTrial::class);
        $this->app->singleton('field-service.webhook-dry-run.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\RealWebhookAutomationDryRun::class);
        $this->app->singleton('field-service.migration-compatibility.titan_reach_flow', \App\Extensions\TitanReachFlow\System\Support\DatabaseMigrationUpgradeCompatibility::class);
        $this->app->singleton('field-service.runtime-repair.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\RuntimeMenuRouteBladeRepair::class);
        $this->app->singleton('field-service.commercial.plan-limits.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\FieldServiceCommercialPlanLimits::class);
        $this->registerConfig();
        $this->app->singleton('field-service.workspace.navigator.lead_review_automation', \App\Extensions\TitanReachFlow\System\Services\FieldService\FieldServiceWorkspaceNavigator::class);
        $this->app->singleton('field-service.workspace.health.lead_review_automation', \App\Extensions\TitanReachFlow\System\Services\FieldService\FieldServiceWorkspaceHealth::class);
        $this->app->singleton('titan-reach-flow.field-service.context', SharedFieldServiceContextResolver::class);
        $this->app->singleton('field-service.social-leads', SharedFieldServiceSocialLeadEmitter::class);
        $this->app->singleton('titan-reach-flow.field-service.presets', \App\Extensions\TitanReachFlow\System\Services\FieldService\FieldServiceAutomationBuilderService::class);
    }


    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-titan-zero-closed-loop.php', 'titan-reach-titan-zero-closed-loop.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-production-release.php', 'titan-reach-production-release.' . self::class);
        $this->app->singleton('titan-reach.production-release.' . self::class, \App\Extensions\TitanReachFlow\System\Support\TitanReachProductionRelease::class);
        $this->app->singleton('titan-reach.titan-zero.closed-loop.' . self::class, \App\Extensions\TitanReachFlow\System\Support\TitanZeroClosedLoopBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-presence.php', 'titan-reach-local-presence.' . self::class);
        $this->app->singleton('titan-reach.local-presence.bridge.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\TitanReachLocalPresenceBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-paid-growth.php', 'titan-reach-paid-growth.' . self::class);
        $this->app->singleton('titan-reach.paid-growth.bridge.' . self::class, \App\Extensions\TitanReachFlow\System\Support\TitanReachPaidGrowthBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-reputation.php', 'titan-reach-reputation.' . self::class);
        $this->app->singleton('titan-reach.reputation.bridge.lead_review_automation', \App\Extensions\TitanReachFlow\System\Support\TitanReachReputationBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-distribution.php', 'titan-reach-distribution');
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-distribution.php', 'titan-reach-local-distribution.' . self::class);
        $this->app->singleton('titan-reach.distribution.bridge.titan_reach_flow', \App\Extensions\TitanReachFlow\System\Support\TitanReachDistributionBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-flow.php', 'titan-reach-flow');
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-events.php', 'field-service-events.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-workspace.php', 'field-service-workspace.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-production.php', 'field-service-production.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime.php', 'field-service-runtime.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-smoke.php', 'field-service-runtime-smoke.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-lead-flow-simulation.php', 'field-service-lead-flow-simulation.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-publish-governance.php', 'field-service-publish-governance.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial.php', 'field-service-commercial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-demo-showcase.php', 'field-service-demo-showcase.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-certification.php', 'field-service-runtime-certification.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-installer-diagnostics.php', 'field-service-live-installer-diagnostics.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-repair.php', 'field-service-runtime-repair.' . self::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-webhook-dry-run.php', 'field-service-webhook-dry-run.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hub-workflow-trial.php', 'field-service-hub-workflow-trial.' . self::class);

                $this->mergeConfigFrom(__DIR__ . '/../config/field-service-local-growth-operational-trial.php', 'field-service-local-growth-operational-trial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial-enforcement.php', 'field-service-commercial-enforcement.' . self::class);


        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-final-customer-release.php', 'field-service-final-customer-release.' . self::class);
        $this->app->singleton('field-service-final-customer-release.' . self::class, fn () => new \App\Extensions\TitanReachFlow\System\Support\FinalCustomerReleaseCandidate());
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-install-evidence.php', 'field-service-live-install-evidence.' . self::class);
        $this->app->singleton('field-service-live-install-evidence.' . self::class, fn () => new \App\Extensions\TitanReachFlow\System\Support\LiveInstallerEvidenceCapture());

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-hotfix-intake.php', 'field-service-hotfix-intake.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-inbox.php', 'titan-reach-inbox');
        $this->app->singleton(\App\Extensions\TitanReachFlow\System\Services\Inbox\TitanReachInboxClassifier::class);
        $this->app->singleton(\App\Extensions\TitanReachFlow\System\Services\Inbox\TitanReachInboxService::class);
        $this->app->singleton('titan-reach.inbox', \App\Extensions\TitanReachFlow\System\Support\TitanReachInboxBridge::class);
        $this->app->singleton('field-service-hotfix-intake.' . self::class, fn () => new \App\Extensions\TitanReachFlow\System\Support\DiagnosticsDrivenHotfixIntake());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-growth-intelligence.php', 'titan-reach-growth-intelligence.' . self::class);
        $this->app->singleton('titan-reach.growth-intelligence.bridge.' . self::class, \App\Extensions\TitanReachFlow\System\Support\TitanReachGrowthIntelligenceBridge::class);
        return $this;
    }

    public function boot(): void
    {
        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->registerMigrations()
            ->registerCommands();
        $this->app->booted(static function (): void { TitanReachMenuInstaller::healIfNeeded(); });
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', $this->registerKey());

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], $this->registerKey());

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }

    private function registerRoutes(): static
    {
        $this->router()
            ->group([
                'middleware' => ['web', 'auth'],
            ], function (Router $router) {
                $router
                    ->name('dashboard.user.titan-reach.automation.')
                    ->prefix('dashboard/user/titan-reach/automation')
                    ->group(function (Router $router) {
                        $router->get('field-service-workspace', FieldServiceWorkspaceController::class)->name('field-service-workspace');
                        Route::get('', [AutomationController::class, 'index'])->name('index');
                        Route::get('create', [AutomationController::class, 'create'])->name('create');
                        Route::get('{automation}/edit', [AutomationController::class, 'edit'])->name('edit');
                        Route::post('', [AutomationController::class, 'store'])->name('store');
                        Route::put('{automation}', [AutomationController::class, 'update'])->name('update');
                        Route::patch('{automation}/status', [AutomationController::class, 'toggleStatus'])->name('toggle-status');
                        Route::delete('{automation}', [AutomationController::class, 'destroy'])->name('destroy');
                        Route::get('social-leads', [SocialLeadController::class, 'index'])->name('social-leads.index');
                        Route::patch('social-leads/{socialLead}/status', [SocialLeadController::class, 'updateStatus'])->name('social-leads.status');
                        Route::get('inbox', [TitanReachInboxController::class, 'index'])->name('inbox.index');
                        Route::patch('inbox/{inboxItem}', [TitanReachInboxController::class, 'update'])->name('inbox.update');

                        // Builder AJAX endpoints
                        Route::get('posts', [AutomationBuilderController::class, 'fetchPosts'])->name('posts');
                        Route::post('upload-image', [AutomationBuilderController::class, 'uploadImage'])->name('upload-image');
                        Route::get('field-service-presets', [AutomationBuilderController::class, 'fieldServicePresets'])->name('field-service-presets');
                    });

            });



        $this->router()
            ->group([
                'middleware' => ['throttle:60,1'],
            ], function (Router $router) {
                $router
                    ->name('titan-reach.automation.webhook.')
                    ->prefix('titan-reach/automation/webhook')
                    ->group(function (Router $router) {
                        Route::match(['GET', 'POST'], 'x', [WebhookController::class, 'x'])->name('x');
                        Route::post('tiktok', [WebhookController::class, 'tiktok'])->name('tiktok');
                        Route::post('linkedin', [WebhookController::class, 'linkedin'])->name('linkedin');
                        Route::match(['GET', 'POST'], 'facebook', [WebhookController::class, 'facebook'])->name('facebook');
                        Route::match(['GET', 'POST'], 'instagram', [WebhookController::class, 'instagram'])->name('instagram');
                    });
            });

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    private function registerCommands(): static
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                ProcessPendingAutomationsCommand::class,
                CleanupPendingAutomationsCommand::class,
            ]);

            $this->app->booted(function () {
                $schedule = $this->app->make(Schedule::class);
                $schedule->command('titan-reach-flow:process-pending')->everyMinute()->withoutOverlapping(5);
                $schedule->command('titan-reach-flow:cleanup-pending')->daily()->withoutOverlapping(60);
            });
        }

        return $this;
    }

    public static function uninstall(): void {}

    public function registerKey(): string
    {
        return 'titan-reach-flow';
    }
}
