<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachFlow\System\Services\Inbox;

use App\Extensions\TitanReachFlow\System\Models\TitanReachInboxItem;
use Illuminate\Support\Arr;

final class TitanReachInboxService
{
    public function __construct(private readonly TitanReachInboxClassifier $classifier) {}
    public function ingest(array $payload): TitanReachInboxItem
    {
        $companyId = $payload['company_id'] ?? null;
        if (!is_numeric($companyId)) throw new \InvalidArgumentException('company_id is required');
        $text = (string)($payload['message'] ?? '');
        $classification = $this->classifier->classify($text, isset($payload['rating']) ? (int)$payload['rating'] : null);
        $sourceId = isset($payload['source_id']) ? (string)$payload['source_id'] : null;
        $keys = ['platform','source_type','source_id','thread_key','social_lead_id'];
        $meta = Arr::only($payload, ['service_interest','service_area','urgency','attribution_key','rating']);
        $attrs = array_merge([
            'company_id'=>(int)$companyId,
            'platform'=>(string)($payload['platform'] ?? 'unknown'),
            'source_type'=>(string)($payload['source_type'] ?? 'message'),
            'source_id'=>$sourceId,
            'thread_key'=>isset($payload['thread_key']) ? hash('sha256',(string)$payload['thread_key']) : null,
            'social_lead_id'=>$payload['social_lead_id'] ?? null,
            'message_excerpt'=>$this->safeExcerpt($text),
            'redacted_metadata'=>$meta,
            'received_at'=>$payload['received_at'] ?? now(),
            'status'=>'open',
        ], $classification);
        if ($sourceId !== null && $sourceId !== '') {
            return TitanReachInboxItem::query()->updateOrCreate([
                'company_id'=>(int)$companyId,'platform'=>$attrs['platform'],'source_type'=>$attrs['source_type'],'source_id'=>$sourceId,
            ], $attrs);
        }
        return TitanReachInboxItem::query()->create($attrs);
    }

    private function safeExcerpt(string $text): string
    {
        $text = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', '[redacted-email]', $text) ?? $text;
        $text = preg_replace('/(?:\+?\d[\d\s().-]{7,}\d)/', '[redacted-phone]', $text) ?? $text;
        return mb_substr(trim(preg_replace('/\s+/', ' ', $text) ?? $text), 0, 280);
    }
}
