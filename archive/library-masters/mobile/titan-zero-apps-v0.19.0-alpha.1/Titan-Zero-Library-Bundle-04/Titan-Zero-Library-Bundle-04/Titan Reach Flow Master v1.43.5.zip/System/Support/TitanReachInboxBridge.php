<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachFlow\System\Support;

use App\Extensions\TitanReachFlow\System\Services\Inbox\TitanReachInboxService;

final class TitanReachInboxBridge
{
    public function __construct(private readonly TitanReachInboxService $inbox) {}
    public function ingest(array $payload): array
    {
        $item = $this->inbox->ingest($payload);
        return ['accepted'=>true,'inbox_item_id'=>$item->id,'category'=>$item->category,'priority'=>$item->priority,'requires_human'=>$item->requires_human,'safety_risk'=>$item->safety_risk];
    }
}
