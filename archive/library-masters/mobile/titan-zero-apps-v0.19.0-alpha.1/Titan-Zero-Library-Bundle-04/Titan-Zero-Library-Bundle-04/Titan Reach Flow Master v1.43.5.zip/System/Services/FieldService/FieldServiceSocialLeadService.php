<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

use App\Extensions\TitanReachFlow\System\Models\Automation;
use App\Extensions\TitanReachFlow\System\Models\SocialLead;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Throwable;

class FieldServiceSocialLeadService
{
    public function __construct(
        private SharedFieldServiceContextResolver $contextResolver
    ) {}

    /**
     * @param  array<string, mixed>  $payload
     */
    public function fromWebhookComment(string $platform, array $payload, ?int $automationId = null): SocialLead
    {
        $automation = $automationId ? Automation::query()->find($automationId) : null;
        $companyId = $this->resolveCompanyId($payload, $automation);
        $context = $this->contextResolver->resolve($companyId);
        $message = (string) ($payload['text'] ?? '');
        $now = now();

        $attributes = [
            'company_id' => $companyId,
            'automation_id' => $automation?->id,
            'platform' => $this->normalizePlatform($platform),
            'source_extension' => 'titan-reach-flow',
            'source_account_id' => $this->nullableString($payload['account_id'] ?? null),
            'source_post_id' => $this->nullableString($payload['post_id'] ?? null),
            'source_campaign_id' => $this->nullableString($payload['campaign_id'] ?? null),
            'source_comment_id' => $this->nullableString($payload['comment_id'] ?? null),
            'attribution_key' => $this->nullableString($payload['attribution_key'] ?? null),
            'service_interest' => $this->inferServiceInterest($message, (array) ($context['services'] ?? [])),
            'service_area' => $this->inferServiceArea($message, (array) ($context['service_areas'] ?? [])),
            'urgency' => $this->inferUrgency($message, (bool) ($context['emergency_available'] ?? false)),
            'status' => 'new',
            'consent_status' => (string) ($payload['consent_status'] ?? 'unknown'),
            'contact_channel' => $this->nullableString($payload['contact_channel'] ?? $platform),
            'contact_value_hash' => $this->hashNullable($payload['contact_value'] ?? null),
            'customer_external_id_hash' => $this->hashNullable($payload['commenter_id'] ?? null),
            'customer_handle_hash' => $this->hashNullable($payload['commenter_username'] ?? null),
            'customer_name_hash' => $this->hashNullable($payload['commenter_name'] ?? null),
            'first_message_excerpt' => $this->safeExcerpt($message),
            'metadata' => $this->safeMetadata($payload),
            'first_seen_at' => $now,
            'last_activity_at' => $now,
        ];

        $existing = $this->findExistingLead($attributes);
        if ($existing) {
            $existing->fill(Arr::except($attributes, ['first_seen_at', 'status']));
            $existing->last_activity_at = $now;
            $existing->save();

            return $existing;
        }

        return SocialLead::query()->create($attributes);
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    public function fromExternalPayload(array $payload): SocialLead
    {
        return $this->fromWebhookComment((string) ($payload['platform'] ?? 'unknown'), $payload, $payload['automation_id'] ?? null);
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function resolveCompanyId(array $payload, ?Automation $automation): ?int
    {
        $companyId = $payload['company_id'] ?? $automation?->company_id ?? null;
        if ($companyId !== null && is_numeric($companyId)) {
            return (int) $companyId;
        }

        $platformCompanyId = $automation?->platform?->company_id
            ?? ($automation?->platform?->credentials['company_id'] ?? null);

        return is_numeric($platformCompanyId) ? (int) $platformCompanyId : null;
    }

    /**
     * @param  array<int, mixed>  $services
     */
    private function inferServiceInterest(string $message, array $services): ?string
    {
        $text = Str::lower($message);
        foreach ($services as $service) {
            $name = is_array($service) ? ($service['name'] ?? null) : ($service->name ?? null);
            if (is_string($name) && $name !== '' && str_contains($text, Str::lower($name))) {
                return $name;
            }
        }

        return null;
    }

    /**
     * @param  array<int, mixed>  $areas
     */
    private function inferServiceArea(string $message, array $areas): ?string
    {
        $text = Str::lower($message);
        foreach ($areas as $area) {
            $name = is_array($area) ? ($area['name'] ?? null) : ($area->name ?? null);
            if (is_string($name) && $name !== '' && str_contains($text, Str::lower($name))) {
                return $name;
            }
        }

        return null;
    }

    private function inferUrgency(string $message, bool $emergencyAvailable): string
    {
        $text = Str::lower($message);
        if ($emergencyAvailable && preg_match('/\b(emergency|urgent|asap|today|tonight|now)\b/', $text)) {
            return 'urgent';
        }

        if (preg_match('/\b(this week|soon|tomorrow)\b/', $text)) {
            return 'soon';
        }

        return 'unknown';
    }

    /**
     * @param  array<string, mixed>  $attributes
     */
    private function findExistingLead(array $attributes): ?SocialLead
    {
        $query = SocialLead::query()
            ->where('platform', $attributes['platform']);

        if (! empty($attributes['company_id'])) {
            $query->where('company_id', $attributes['company_id']);
        } else {
            $query->whereNull('company_id');
        }

        if (! empty($attributes['source_comment_id'])) {
            return $query->where('source_comment_id', $attributes['source_comment_id'])->first();
        }

        if (! empty($attributes['attribution_key'])) {
            return $query->where('attribution_key', $attributes['attribution_key'])->first();
        }

        return null;
    }

    private function normalizePlatform(string $platform): string
    {
        $platform = Str::lower(trim($platform));

        return $platform === 'twitter' ? 'x' : ($platform ?: 'unknown');
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        return (string) $value;
    }

    private function hashNullable(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        return hash_hmac('sha256', (string) $value, (string) config('app.key', 'field-service-social-leads'));
    }

    private function safeExcerpt(string $message): ?string
    {
        $clean = trim(preg_replace('/\s+/', ' ', $message) ?? '');
        if ($clean === '') {
            return null;
        }

        return Str::limit($clean, 280, '');
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    private function safeMetadata(array $payload): array
    {
        return Arr::only($payload, [
            'company_id',
            'campaign_id',
            'attribution_key',
            'post_id',
            'comment_id',
            'consent_status',
            'source_url',
        ]);
    }
}
