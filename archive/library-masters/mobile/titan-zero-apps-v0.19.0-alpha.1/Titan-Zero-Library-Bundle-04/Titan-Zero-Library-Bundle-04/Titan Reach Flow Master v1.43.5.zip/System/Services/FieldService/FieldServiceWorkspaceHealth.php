<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

use Illuminate\Contracts\Container\Container;

class FieldServiceWorkspaceHealth
{
    public function __construct(private readonly Container $container)
    {
    }

    public function snapshot(): array
    {
        return [
            'module' => 'lead_review_automation',
            'context' => $this->bindingHealth('titan-reach.field-service.context'),
            'events' => $this->bindingHealth('field-service.events'),
            'social_leads' => $this->bindingHealth('field-service.social-leads'),
            'ai_provider' => $this->bindingHealth('titan.ai.chat-provider'),
            'automation_presets' => $this->bindingHealth('titan-reach-flow.field-service.presets'),
        ];
    }

    private function bindingHealth(string $binding): array
    {
        return [
            'binding' => $binding,
            'available' => $this->container->bound($binding),
            'mode' => $this->container->bound($binding) ? 'connected' : 'standalone_safe',
        ];
    }
}
