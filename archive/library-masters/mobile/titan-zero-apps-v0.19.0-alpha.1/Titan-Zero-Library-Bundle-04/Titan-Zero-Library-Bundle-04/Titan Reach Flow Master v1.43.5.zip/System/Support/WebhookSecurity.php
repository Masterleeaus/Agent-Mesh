<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class WebhookSecurity
{
    /** @var list<string> */
    private const SENSITIVE_KEYS = [
        'access_token', 'refresh_token', 'token', 'secret', 'signature', 'authorization',
        'message', 'text', 'payload', 'body', 'comment_text', 'email', 'phone', 'name',
    ];

    public static function configuredSecret(?string $secret): ?string
    {
        $secret = is_string($secret) ? trim($secret) : '';

        if ($secret === '' || in_array($secret, ['default-password', 'changeme', 'secret'], true)) {
            return null;
        }

        return $secret;
    }

    /**
     * Verify X-Hub-Signature-256 style HMAC signatures and reject replayed payloads.
     */
    public static function verifyHubSignature(Request $request, ?string $secret, string $platform): bool
    {
        $secret = self::configuredSecret($secret);
        if ($secret === null) {
            Log::warning("{$platform} webhook disabled: missing signing secret");
            return false;
        }

        $signature = (string) $request->header('X-Hub-Signature-256', '');
        if ($signature === '') {
            Log::warning("{$platform} webhook rejected: missing signature");
            return false;
        }

        $expected = 'sha256=' . hash_hmac('sha256', $request->getContent(), $secret);
        if (! hash_equals($expected, $signature)) {
            Log::warning("{$platform} webhook rejected: invalid signature");
            return false;
        }

        return self::rejectReplay($platform, hash('sha256', $signature . '|' . $request->getContent()));
    }

    /**
     * Verify generic timestamped HMAC signatures for platforms without a shared Laravel adapter.
     */
    public static function verifyTimestampedHmac(Request $request, ?string $secret, string $platform, array $signatureHeaders): bool
    {
        $secret = self::configuredSecret($secret);
        if ($secret === null) {
            Log::warning("{$platform} webhook disabled: missing signing secret");
            return false;
        }

        $timestamp = (string) ($request->header('X-Webhook-Timestamp') ?: $request->header('X-Timestamp') ?: $request->query('timestamp', ''));
        if (! self::validTimestamp($timestamp)) {
            Log::warning("{$platform} webhook rejected: missing or stale timestamp");
            return false;
        }

        $signature = '';
        foreach ($signatureHeaders as $header) {
            $signature = (string) $request->header($header, '');
            if ($signature !== '') {
                break;
            }
        }

        if ($signature === '') {
            Log::warning("{$platform} webhook rejected: missing signature");
            return false;
        }

        $canonical = $timestamp . '.' . $request->getContent();
        $rawExpected = hash_hmac('sha256', $canonical, $secret);
        $accepted = [$rawExpected, 'sha256=' . $rawExpected, base64_encode(hex2bin($rawExpected) ?: '')];

        foreach ($accepted as $expected) {
            if ($expected !== '' && hash_equals($expected, $signature)) {
                return self::rejectReplay($platform, hash('sha256', $timestamp . '|' . $signature));
            }
        }

        Log::warning("{$platform} webhook rejected: invalid signature");
        return false;
    }

    public static function validTimestamp(string $timestamp): bool
    {
        if ($timestamp === '' || ! ctype_digit($timestamp)) {
            return false;
        }

        $window = (int) config('titan-reach-flow.webhooks.replay_window_seconds', 300);
        return abs(time() - (int) $timestamp) <= max(60, $window);
    }

    public static function rejectReplay(string $platform, string $fingerprint): bool
    {
        $ttl = now()->addSeconds((int) config('titan-reach-flow.webhooks.replay_window_seconds', 300));
        $key = 'sm_automation_webhook_replay:' . $platform . ':' . $fingerprint;

        if (! Cache::add($key, true, $ttl)) {
            Log::warning("{$platform} webhook rejected: replay detected");
            return false;
        }

        return true;
    }

    /** @param array<string,mixed> $payload */
    public static function redacted(array $payload): array
    {
        return self::redactValue($payload);
    }

    private static function redactValue(mixed $value): mixed
    {
        if (is_array($value)) {
            $redacted = [];
            foreach ($value as $key => $item) {
                $keyString = strtolower((string) $key);
                $redacted[$key] = self::isSensitiveKey($keyString) ? '[redacted]' : self::redactValue($item);
            }
            return $redacted;
        }

        return $value;
    }

    private static function isSensitiveKey(string $key): bool
    {
        foreach (self::SENSITIVE_KEYS as $sensitive) {
            if (str_contains($key, $sensitive)) {
                return true;
            }
        }

        return false;
    }
}
