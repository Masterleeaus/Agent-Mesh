<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

final class FieldServiceVerticalPackCatalog

{
    /** @return array<string, array<string, mixed>> */
    public function all(): array
    {
        return [
            'cleaning' => $this->pack('Cleaning', ['house cleaning', 'end-of-lease cleaning', 'office cleaning', 'deep cleaning', 'window cleaning'], ['spring clean reminders', 'end-of-lease season', 'pre-holiday refresh'], ['before_after', 'completed_job', 'review_request', 'maintenance_tip'], ['request a quote', 'book a clean', 'ask about recurring cleaning'], ['clean', 'cleaner', 'end of lease', 'bond clean', 'deep clean'], ['Do not promise bond return or stain removal guarantees.']),
            'plumbing' => $this->pack('Plumbing', ['leak repairs', 'blocked drains', 'tap repairs', 'hot water checks', 'toilet repairs'], ['winter pipe checks', 'stormwater preparation', 'holiday plumbing readiness'], ['emergency_availability', 'maintenance_tip', 'service_spotlight', 'local_availability'], ['request a plumbing quote', 'book a licensed plumber only when licence is configured', 'send a service enquiry'], ['plumber', 'leak', 'blocked drain', 'hot water', 'tap'], ['Do not claim licence, gas fitting, emergency response or fixed pricing unless explicitly configured.']),
            'electrical' => $this->pack('Electrical', ['safety switch checks', 'power point repairs', 'lighting upgrades', 'fault finding', 'smoke alarm checks'], ['winter safety checks', 'pre-summer load checks', 'rental safety reminder'], ['trust_builder', 'maintenance_tip', 'service_spotlight', 'review_request'], ['request an electrical quote', 'book an inspection', 'ask about availability'], ['electrician', 'power', 'lights', 'safety switch', 'smoke alarm'], ['Do not claim electrical licence, compliance certification, emergency service or safety approval unless explicitly configured.']),
            'hvac' => $this->pack('HVAC', ['split system servicing', 'filter cleaning', 'air conditioning repairs', 'heating checks', 'ventilation checks'], ['pre-summer air conditioning', 'winter heating readiness', 'filter maintenance'], ['seasonal_reminder', 'maintenance_tip', 'local_availability', 'review_request'], ['book a service', 'request a quote', 'ask about maintenance'], ['air con', 'air conditioning', 'heating', 'hvac', 'filter'], ['Do not promise energy savings, refrigerant licensing or emergency repairs unless configured.']),
            'handyman_property_maintenance' => $this->pack('Handyman / property maintenance', ['minor repairs', 'door repairs', 'fixture installs', 'patching', 'property maintenance'], ['pre-rental inspection fixes', 'spring maintenance', 'storm preparation'], ['completed_job', 'service_spotlight', 'local_availability', 'maintenance_tip'], ['request a quote', 'send a job list', 'book property maintenance'], ['handyman', 'repair', 'maintenance', 'fix', 'install'], ['Do not imply trade-licensed work is covered unless the specific licence/service is configured.']),
            'landscaping_gardening_lawn_care' => $this->pack('Landscaping / gardening / lawn care', ['lawn mowing', 'garden clean-ups', 'hedge trimming', 'mulching', 'weed control'], ['spring growth', 'summer lawn care', 'autumn clean-up'], ['before_after', 'seasonal_reminder', 'local_availability', 'review_request'], ['request a garden quote', 'book lawn care', 'ask about recurring maintenance'], ['garden', 'lawn', 'mowing', 'hedge', 'landscaping'], ['Do not promise plant survival, chemical treatments or council compliance unless configured.']),
            'pest_control' => $this->pack('Pest control', ['general pest treatment', 'rodent checks', 'spider treatment', 'ant treatment', 'inspection'], ['summer pests', 'winter rodent checks', 'pre-holiday pest prevention'], ['seasonal_reminder', 'trust_builder', 'maintenance_tip', 'service_spotlight'], ['request an inspection', 'ask about pest treatment', 'book a quote'], ['pest', 'spider', 'ant', 'rodent', 'termite'], ['Do not claim chemical licensing, termite certification, eradication guarantees or safety approvals unless configured.']),
            'locksmith_security' => $this->pack('Locksmith / security', ['lock repairs', 'rekeying', 'key cutting', 'door hardware', 'security checks'], ['holiday security checks', 'moving house rekeying', 'rental turnover'], ['service_spotlight', 'local_availability', 'trust_builder', 'emergency_availability'], ['request locksmith help', 'book a security check', 'ask about rekeying'], ['locksmith', 'lock', 'keys', 'rekey', 'security'], ['Do not claim security licensing, emergency response, access authority or police checks unless configured.']),
            'roofing_guttering' => $this->pack('Roofing / guttering', ['gutter cleaning', 'minor roof repairs', 'downpipe checks', 'roof inspections', 'storm preparation'], ['pre-storm gutter checks', 'autumn leaf build-up', 'winter leak prevention'], ['seasonal_reminder', 'before_after', 'maintenance_tip', 'local_availability'], ['request a roofing quote', 'book gutter cleaning', 'ask about inspection availability'], ['roof', 'gutter', 'downpipe', 'leak', 'storm'], ['Do not promise waterproofing, structural safety, insurance outcomes or emergency storm response unless configured.']),
            'appliance_equipment_repair' => $this->pack('Appliance / equipment repair', ['appliance diagnosis', 'equipment servicing', 'washer repairs', 'dryer checks', 'oven repairs'], ['pre-holiday appliance checks', 'winter dryer maintenance', 'routine equipment servicing'], ['service_spotlight', 'maintenance_tip', 'review_request', 'local_availability'], ['request repair help', 'book diagnosis', 'ask about service availability'], ['appliance', 'repair', 'washer', 'dryer', 'oven'], ['Do not promise warranty coverage, parts availability, licensed electrical/gas work or same-day repairs unless configured.']),
        ];
    }

    public function get(string $slug): ?array
    {
        $key = $this->normaliseSlug($slug);
        return $this->all()[$key] ?? null;
    }

    public function labels(): array
    {
        return array_map(static fn (array $pack): string => $pack['label'], $this->all());
    }

    public function resolve(?string $vertical): array
    {
        $key = $this->normaliseSlug((string) $vertical);
        return $this->all()[$key] ?? $this->safeDefault();
    }

    public function safeDefault(): array
    {
        return [
            'slug' => 'custom_field_service',
            'label' => 'Custom field/home service',
            'suggested_services' => [],
            'seasonal_themes' => [],
            'safe_content_lanes' => ['service_spotlight', 'maintenance_tip', 'review_request'],
            'common_cta_styles' => ['request a quote', 'book a consultation', 'ask about availability'],
            'review_prompts' => ['If you were happy with the service, a review helps local customers choose with confidence.'],
            'local_growth_signals' => ['profile_gap', 'local_gap', 'review_builder'],
            'playbook_defaults' => ['seasonal_service_campaign', 'quiet_week_schedule_filler', 'review_generation_campaign'],
            'automation_keyword_suggestions' => ['quote', 'price', 'booking', 'available', 'review'],
            'privacy_warnings' => ['Use only configured services and service areas; do not include exact addresses, customer names, faces or vehicle plates without explicit permission.'],
            'forbidden_claims' => $this->forbiddenClaims(),
        ];
    }

    public function forbiddenClaims(): array
    {
        return [
            'licence_or_certification_not_configured',
            'prices_or_discounts_not_configured',
            'emergency_or_after_hours_availability_not_configured',
            'unconfigured_service_area_or_suburb',
            'guaranteed_results_or_outcomes',
            'exact_customer_address_or_private_customer_detail',
            'identifiable_faces_or_vehicle_plates_without_consent',
        ];
    }

    private function pack(string $label, array $services, array $seasonalThemes, array $lanes, array $ctas, array $keywords, array $warnings): array
    {
        return [
            'slug' => $this->normaliseSlug($label),
            'label' => $label,
            'suggested_services' => $services,
            'seasonal_themes' => $seasonalThemes,
            'safe_content_lanes' => $lanes,
            'common_cta_styles' => $ctas,
            'review_prompts' => ['If you were happy with the service, a review helps local customers choose with confidence.'],
            'local_growth_signals' => ['seasonal_demand', 'local_availability', 'content_gap', 'review_builder'],
            'playbook_defaults' => ['seasonal_service_campaign', 'quiet_week_schedule_filler', 'review_generation_campaign'],
            'automation_keyword_suggestions' => $keywords,
            'privacy_warnings' => array_values(array_merge($warnings, ['Never include exact addresses, customer names, faces, vehicle plates or private job details unless explicitly permitted.'])),
            'forbidden_claims' => $this->forbiddenClaims(),
        ];
    }

    private function normaliseSlug(string $value): string
    {
        $value = strtolower(trim($value));
        $value = str_replace(['/', '&', '+'], ' ', $value);
        $value = preg_replace('/[^a-z0-9]+/', '_', $value) ?: '';
        $value = trim($value, '_');

        return match ($value) {
            'handyman', 'property_maintenance', 'handyman_property_maintenance' => 'handyman_property_maintenance',
            'landscaping', 'gardening', 'lawn', 'lawn_care', 'landscaping_gardening_lawn_care' => 'landscaping_gardening_lawn_care',
            'locksmith', 'security', 'locksmith_security' => 'locksmith_security',
            'roofing', 'guttering', 'roofing_guttering' => 'roofing_guttering',
            'appliance_repair', 'equipment_repair', 'appliance_equipment_repair' => 'appliance_equipment_repair',
            'air_conditioning', 'heating', 'heating_cooling' => 'hvac',
            default => $value,
        };
    }
}
