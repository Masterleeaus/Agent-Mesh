<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Models;

use Illuminate\Database\Eloquent\Model;

class TitanReachInboxItem extends Model
{
    protected $table = 'titan_reach_flow_inbox_items';
    protected $fillable = ['company_id','social_lead_id','platform','source_type','source_id','thread_key','category','priority','status','requires_human','safety_risk','message_excerpt','redacted_metadata','received_at','resolved_at'];
    protected $casts = ['redacted_metadata'=>'array','requires_human'=>'boolean','safety_risk'=>'boolean','received_at'=>'datetime','resolved_at'=>'datetime'];
}
