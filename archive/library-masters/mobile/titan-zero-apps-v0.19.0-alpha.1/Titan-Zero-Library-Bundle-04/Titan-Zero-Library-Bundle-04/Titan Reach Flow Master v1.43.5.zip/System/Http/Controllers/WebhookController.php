<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Http\Controllers;

use App\Extensions\TitanReachFlow\System\Services\WebhookProcessor;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Extensions\TitanReachFlow\System\Support\WebhookSecurity;
use Illuminate\Support\Facades\Log;
use Throwable;

class WebhookController extends Controller
{
    public function __construct(
        private WebhookProcessor $processor
    ) {}

    /**
     * Handle X/Twitter Account Activity API webhooks.
     *
     * GET = CRC challenge verification
     * POST = Event delivery
     */
    public function x(Request $request): Response
    {
        // GET: CRC challenge response
        if ($request->isMethod('GET')) {
            $crcToken = $request->get('crc_token');

            if (! $crcToken) {
                return response('Missing crc_token', 400);
            }

            $consumerSecret = setting('X_API_SECRET');

            if (! $consumerSecret) {
                return response('Webhook not configured', 500);
            }

            $responseToken = $this->processor->generateXCrcResponse($crcToken, $consumerSecret);

            return response(json_encode(['response_token' => $responseToken]), 200)
                ->header('Content-Type', 'application/json');
        }

        // POST: Process incoming events. X has no session context, so require a configured timestamped HMAC.
        if ($request->isMethod('POST')) {
            $secret = setting('X_WEBHOOK_SECRET') ?: config('titan-reach-flow.webhooks.x.webhook_secret');
            if (! WebhookSecurity::verifyTimestampedHmac($request, $secret, 'x', ['X-Twitter-Webhooks-Signature', 'X-Webhook-Signature'])) {
                return response('Forbidden', 403);
            }

            try {
                $this->processor->processXPayload($request->json()->all());
            } catch (Throwable $e) {
                Log::error('X webhook processing failed', ['error' => $e->getMessage()]);
            }

            return response('', 200);
        }

        return response('Method not allowed', 405);
    }

    /**
     * Handle TikTok webhook events.
     *
     * TikTok uses a webhook verification challenge and POST event delivery.
     */
    public function tiktok(Request $request): Response
    {
        // TikTok verification challenge
        if ($request->isMethod('POST') && $request->json('challenge')) {
            return response(json_encode([
                'challenge' => $request->json('challenge'),
            ]), 200)->header('Content-Type', 'application/json');
        }

        // Process comment events
        if ($request->isMethod('POST')) {
            $secret = setting('TIKTOK_WEBHOOK_SECRET') ?: config('titan-reach-flow.webhooks.tiktok.webhook_secret');
            if (! WebhookSecurity::verifyTimestampedHmac($request, $secret, 'tiktok', ['X-Tt-Signature', 'X-TikTok-Signature', 'X-Webhook-Signature'])) {
                return response('Forbidden', 403);
            }

            try {
                $event = $request->json('event', '');

                if ($event === 'comment.create') {
                    $data = $request->json('data', []);

                    $this->processor->executionService()->processCommentEvent('tiktok', [
                        'account_id'           => null,
                        'post_id'              => $data['video_id'] ?? null,
                        'comment_id'           => $data['comment_id'] ?? null,
                        'commenter_id'         => $data['user_id'] ?? null,
                        'commenter_username'   => $data['username'] ?? null,
                        'commenter_name'       => $data['display_name'] ?? null,
                        'text'                 => $data['text'] ?? '',
                    ]);
                }
            } catch (Throwable $e) {
                Log::error('TikTok webhook processing failed', [
                    'error' => $e->getMessage(),
                ]);
            }

            return response('', 200);
        }

        return response('Method not allowed', 405);
    }

    /**
     * Handle Facebook webhook events.
     *
     * GET  = Hub verification challenge
     * POST = Event delivery (comment events on page posts)
     */
    public function facebook(Request $request): Response
    {
        if ($request->isMethod('GET')) {
            $mode = $request->get('hub_mode') ?? $request->get('hub.mode');
            $token = $request->get('hub_verify_token') ?? $request->get('hub.verify_token');
            $challenge = $request->get('hub_challenge') ?? $request->get('hub.challenge');
            $verifyToken = WebhookSecurity::configuredSecret(setting('FACEBOOK_WEBHOOK_VERIFY_TOKEN') ?: config('titan-reach-flow.webhooks.facebook.verify_token'));

            if ($verifyToken === null) {
                Log::warning('Facebook webhook verification disabled: missing verify token');
                return response('Webhook not configured', 503);
            }

            if ($mode === 'subscribe' && is_string($challenge) && hash_equals($verifyToken, (string) $token)) {
                return response((string) $challenge, 200);
            }

            return response('Forbidden', 403);
        }

        if ($request->isMethod('POST')) {
            $appSecret = setting('FACEBOOK_APP_SECRET') ?: config('titan-reach-flow.webhooks.facebook.app_secret');
            if (! WebhookSecurity::verifyHubSignature($request, $appSecret, 'facebook')) {
                return response('Forbidden', 403);
            }

            try {
                $this->processor->processFacebookPayload($request->json()->all());
            } catch (Throwable $e) {
                Log::error('Facebook webhook processing failed', ['error' => $e->getMessage()]);
            }

            return response('', 200);
        }

        return response('Method not allowed', 405);
    }

    /**
     * Handle Instagram webhook events.
     *
     * GET  = Hub verification challenge
     * POST = Event delivery (comment events on media)
     */
    public function instagram(Request $request): Response
    {
        if ($request->isMethod('GET')) {
            $mode = $request->get('hub_mode') ?? $request->get('hub.mode');
            $token = $request->get('hub_verify_token') ?? $request->get('hub.verify_token');
            $challenge = $request->get('hub_challenge') ?? $request->get('hub.challenge');
            $verifyToken = WebhookSecurity::configuredSecret(setting('INSTAGRAM_WEBHOOK_VERIFY_TOKEN') ?: config('titan-reach-flow.webhooks.instagram.verify_token'));

            if ($verifyToken === null) {
                Log::warning('Instagram webhook verification disabled: missing verify token');
                return response('Webhook not configured', 503);
            }

            if ($mode === 'subscribe' && is_string($challenge) && hash_equals($verifyToken, (string) $token)) {
                return response((string) $challenge, 200);
            }

            return response('Forbidden', 403);
        }

        if ($request->isMethod('POST')) {
            $appSecret = setting('INSTAGRAM_APP_SECRET') ?: config('titan-reach-flow.webhooks.instagram.app_secret');
            if (! WebhookSecurity::verifyHubSignature($request, $appSecret, 'instagram')) {
                return response('Forbidden', 403);
            }

            try {
                $this->processor->processInstagramPayload($request->json()->all());
            } catch (Throwable $e) {
                Log::error('Instagram webhook processing failed', ['error' => $e->getMessage()]);
            }

            return response('', 200);
        }

        return response('Method not allowed', 405);
    }

    /**
     * Handle LinkedIn webhook events.
     *
     * LinkedIn uses validation endpoint and POST event delivery.
     */
    public function linkedin(Request $request): Response
    {
        // LinkedIn validation challenge
        if ($request->isMethod('GET') && $request->has('validationToken')) {
            return response($request->get('validationToken'), 200)
                ->header('Content-Type', 'text/plain');
        }

        // Process comment events
        if ($request->isMethod('POST')) {
            $secret = setting('LINKEDIN_WEBHOOK_SECRET') ?: config('titan-reach-flow.webhooks.linkedin.webhook_secret');
            if (! WebhookSecurity::verifyTimestampedHmac($request, $secret, 'linkedin', ['X-LinkedIn-Signature', 'X-Webhook-Signature'])) {
                return response('Forbidden', 403);
            }

            try {
                $eventType = $request->header('X-LinkedIn-Event-Type', '');

                if (str_contains($eventType, 'COMMENT')) {
                    $data = $request->json()->all();
                    $actor = $data['actor'] ?? '';
                    $object = $data['object'] ?? '';

                    $this->processor->executionService()->processCommentEvent('linkedin', [
                        'account_id'           => null,
                        'post_id'              => $object,
                        'comment_id'           => $data['id'] ?? null,
                        'commenter_id'         => $actor,
                        'commenter_username'   => $data['actor~']['vanityName'] ?? null,
                        'commenter_name'       => ($data['actor~']['localizedFirstName'] ?? '') . ' ' . ($data['actor~']['localizedLastName'] ?? ''),
                        'text'                 => $data['message']['text'] ?? '',
                    ]);
                }
            } catch (Throwable $e) {
                Log::error('LinkedIn webhook processing failed', [
                    'error' => $e->getMessage(),
                ]);
            }

            return response('', 200);
        }

        return response('Method not allowed', 405);
    }
}
