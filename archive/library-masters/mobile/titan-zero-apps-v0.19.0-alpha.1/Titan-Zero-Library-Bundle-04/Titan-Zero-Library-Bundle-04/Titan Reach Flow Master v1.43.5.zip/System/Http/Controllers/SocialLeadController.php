<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Http\Controllers;

use App\Extensions\TitanReachFlow\System\Models\SocialLead;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SocialLeadController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);

        $query = SocialLead::query()->latest('last_activity_at')->limit(100);
        if ($companyId !== null) {
            $query->where('company_id', $companyId);
        } else {
            $query->whereNull('company_id');
        }

        return response()->json([
            'data' => $query->get()->map(fn (SocialLead $lead) => $this->serializeLead($lead))->values(),
        ]);
    }

    public function updateStatus(Request $request, SocialLead $socialLead): JsonResponse
    {
        $companyId = $this->companyId($request);
        abort_unless($companyId !== null && (int) $socialLead->company_id === $companyId, 404);

        $data = $request->validate([
            'status' => ['required', 'string', 'in:new,qualified,quoted,booked,review_requested,closed,lost,spam'],
        ]);

        $socialLead->update(['status' => $data['status']]);

        return response()->json(['data' => $this->serializeLead($socialLead->fresh())]);
    }

    private function companyId(Request $request): ?int
    {
        $companyId = $request->user()?->company_id
            ?? $request->user()?->selected_company_id
            ?? $request->session()->get('company_id');

        return is_numeric($companyId) ? (int) $companyId : null;
    }

    /**
     * @return array<string, mixed>
     */
    private function serializeLead(SocialLead $lead): array
    {
        return [
            'id' => $lead->id,
            'company_id' => $lead->company_id,
            'platform' => $lead->platform,
            'service_interest' => $lead->service_interest,
            'service_area' => $lead->service_area,
            'urgency' => $lead->urgency,
            'status' => $lead->status,
            'consent_status' => $lead->consent_status,
            'source_post_id' => $lead->source_post_id,
            'source_campaign_id' => $lead->source_campaign_id,
            'attribution_key' => $lead->attribution_key,
            'last_activity_at' => optional($lead->last_activity_at)->toIso8601String(),
        ];
    }
}
