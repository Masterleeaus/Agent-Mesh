<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachFlow\System\Http\Controllers;

use App\Extensions\TitanReachFlow\System\Models\TitanReachInboxItem;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

final class TitanReachInboxController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = $this->companyId($request); abort_unless($companyId !== null, 403);
        $items = TitanReachInboxItem::query()->where('company_id',$companyId)->orderByRaw("CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END")->latest('received_at')->paginate(50);
        return view('titan-reach-flow::inbox.index', compact('items'));
    }
    public function update(Request $request, TitanReachInboxItem $inboxItem): RedirectResponse
    {
        $companyId=$this->companyId($request); abort_unless($companyId !== null && (int)$inboxItem->company_id === $companyId,404);
        $data=$request->validate(['status'=>['required','in:open,working,resolved,spam']]);
        $inboxItem->update(['status'=>$data['status'],'resolved_at'=>$data['status']==='resolved'?now():null]);
        return back();
    }
    private function companyId(Request $request): ?int
    {
        $id=$request->user()?->company_id ?? $request->user()?->selected_company_id ?? $request->session()->get('company_id');
        return is_numeric($id)?(int)$id:null;
    }
}
