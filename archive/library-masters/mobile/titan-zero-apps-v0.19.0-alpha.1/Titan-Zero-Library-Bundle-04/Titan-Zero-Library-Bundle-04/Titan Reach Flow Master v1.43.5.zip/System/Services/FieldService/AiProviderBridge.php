<?php

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

class AiProviderBridge
{
    public const HOST_PROVIDER_BINDING = 'titan.ai.chat-provider';

    public function available(): bool
    {
        return function_exists('app') && app()->bound(self::HOST_PROVIDER_BINDING);
    }

    public function bindingName(): string
    {
        return self::HOST_PROVIDER_BINDING;
    }
}
