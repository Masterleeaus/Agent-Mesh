<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

final class DatabaseMigrationUpgradeCompatibility
{
    /**
     * Return the migration compatibility checks this extension expects a live installer to run.
     *
     * @return array<string, mixed>
     */
    public function checklist(): array
    {
        return [
            'step' => 27,
            'extension' => 'Lead & Review Automation',
            'fresh_install_supported' => true,
            'upgrade_install_supported' => true,
            'non_destructive_only' => true,
            'duplicate_safe_columns' => true,
            'requires_company_id_boundary' => true,
            'required_checks' => [
                'all table creates are guarded with Schema::hasTable checks',
                'all column adds are guarded with Schema::hasColumn checks',
                'migrations do not drop live customer data',
                'migrations do not replace company_id with user_id tenancy',
                'installer diagnostics preserve the failed migration stage',
                'post-migration runtime repair and certification configs remain registered',
            ],
        ];
    }

    /**
     * Build a deterministic compatibility report from a schema snapshot.
     * The snapshot may be collected by a host/Titan adapter later; standalone mode passes an empty array.
     *
     * @param array<string, array<int, string>> $schemaSnapshot
     * @return array<string, mixed>
     */
    public function trialReport(array $schemaSnapshot = []): array
    {
        $tables = array_keys($schemaSnapshot);
        sort($tables);

        return [
            'status' => 'ready_for_live_trial',
            'fresh_install' => [
                'mode' => 'create-missing-only',
                'destructive_operations_allowed' => false,
            ],
            'upgrade_install' => [
                'mode' => 'add-missing-only',
                'duplicate_column_replay_safe' => true,
                'destructive_operations_allowed' => false,
            ],
            'observed_tables' => $tables,
            'company_id_required' => true,
            'safe_when_schema_snapshot_unavailable' => true,
            'diagnostic_message' => 'Run host migrations with table/column guards and capture failed stage before retrying.',
        ];
    }

    /**
     * Classify a migration exception without leaking SQL values or customer data.
     */
    public function classifyFailure(string $message): string
    {
        $lower = strtolower($message);

        if (str_contains($lower, 'duplicate column') || str_contains($lower, 'already exists')) {
            return 'duplicate_schema_replay';
        }

        if (str_contains($lower, 'foreign key') || str_contains($lower, 'constraint')) {
            return 'constraint_or_ordering_failure';
        }

        if (str_contains($lower, 'unknown column') || str_contains($lower, 'base table or view not found')) {
            return 'missing_schema_dependency';
        }

        if (str_contains($lower, 'access denied') || str_contains($lower, 'permission')) {
            return 'database_permission_failure';
        }

        return 'migration_failure_needs_diagnostics';
    }
}
