<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Services\FieldService;

use App\Extensions\TitanReachFlow\System\Support\FieldServiceMarketingPermissionGate;

class FieldServiceWorkspaceNavigator
{
    public function __construct(private readonly FieldServiceMarketingPermissionGate $permissions)
    {
    }

    public function module(): array
    {
        return [
            'key' => 'lead_review_automation',
            'label' => 'Titan Reach Flow',
            'role' => 'Unified engagement inbox, leads, reviews and automation',
            'workspace' => 'field_home_services_social_marketing',
        ];
    }

    public function links(?object $user = null, ?int $companyId = null): array
    {
        $links = [['label' => 'Inbox', 'path' => '/dashboard/user/titan-reach/automation/inbox', 'action' => 'leads'], ['label' => 'Automations', 'path' => '/dashboard/user/titan-reach/automation', 'action' => 'titan_reach_campaign_automations'], ['label' => 'Create Automation', 'path' => '/dashboard/user/titan-reach/automation/create', 'action' => 'titan_reach_campaign_automations'], ['label' => 'Social Leads', 'path' => '/dashboard/user/titan-reach/automation/social-leads', 'action' => 'leads'], ['label' => 'Field-Service Presets', 'path' => '/dashboard/user/titan-reach/automation/field-service-presets', 'action' => 'titan_reach_campaign_automations']];

        return array_map(function (array $link) use ($user, $companyId): array {
            $link['enabled'] = $this->permissions->allows($user, $link['action'], $companyId);
            $link['permission'] = $this->permissions->abilityFor($link['action']);

            return $link;
        }, $links);
    }

    public function crossExtensionLinks(): array
    {
        return [
            ['module' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'binding' => 'titan-reach.field-service.context'],
            ['module' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'binding' => 'titan-reach-agent.field-service.context'],
            ['module' => 'lead_review_automation', 'label' => 'Titan Reach Flow', 'binding' => 'titan-reach-flow.field-service.context'],
            ['module' => 'campaign_playbooks', 'label' => 'Campaign Playbooks', 'binding' => 'titan-reach-campaigns.field-service.context'],
        ];
    }
}
