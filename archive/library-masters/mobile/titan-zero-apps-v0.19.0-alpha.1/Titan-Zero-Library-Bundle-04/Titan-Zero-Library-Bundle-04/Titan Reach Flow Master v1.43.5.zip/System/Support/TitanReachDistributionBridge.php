<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Support;

final class TitanReachDistributionBridge
{
    public function plan(array $item): array
    {
        if (($item['company_id'] ?? '') === '') { return [['destination'=>'all','status'=>'blocked','reasons'=>['company_id_required'],'approval_required'=>true,'assisted'=>false,'paid'=>false]]; }
        if (function_exists('app') && app()->bound('titan-reach.distribution.bridge')) { return app('titan-reach.distribution.bridge')->resolve($item); }
        return [['destination'=>'titan_reach_pro','status'=>'standalone_fallback','reasons'=>['titan_reach_pro_distribution_engine_not_available'],'approval_required'=>true,'assisted'=>true,'paid'=>false]];
    }
}
