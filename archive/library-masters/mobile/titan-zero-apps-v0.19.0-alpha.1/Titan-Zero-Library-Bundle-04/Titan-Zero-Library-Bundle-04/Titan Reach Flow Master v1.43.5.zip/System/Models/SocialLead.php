<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachFlow\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SocialLead extends Model
{
    protected $table = 'titan_reach_flow_social_leads';

    protected $fillable = [
        'company_id',
        'automation_id',
        'platform',
        'source_extension',
        'source_account_id',
        'source_post_id',
        'source_campaign_id',
        'source_comment_id',
        'attribution_key',
        'service_interest',
        'service_area',
        'urgency',
        'status',
        'consent_status',
        'contact_channel',
        'contact_value_hash',
        'customer_external_id_hash',
        'customer_handle_hash',
        'customer_name_hash',
        'first_message_excerpt',
        'metadata',
        'first_seen_at',
        'last_activity_at',
    ];

    protected $casts = [
        'metadata' => 'array',
        'first_seen_at' => 'datetime',
        'last_activity_at' => 'datetime',
    ];

    public function automation(): BelongsTo
    {
        return $this->belongsTo(Automation::class, 'automation_id');
    }

    public function isNew(): bool
    {
        return $this->status === 'new';
    }
}
