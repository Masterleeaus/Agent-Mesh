export const NODE_TYPES = {
    TRIGGER: 'trigger',
    DELAY: 'delay',
    ACTION: 'action',
};

export const DEFAULT_POSITIONS = {
    trigger: { x: 100, y: 200 },
    delay: { x: 500, y: 200 },
    action: { x: 900, y: 200 },
    actionNoDelay: { x: 550, y: 200 },
};

export const ACTION_TYPES = ['text', 'button', 'image', 'quick_replies', 'delay', 'field_service_quote', 'field_service_booking', 'field_service_review_request', 'field_service_emergency_handoff', 'field_service_availability', 'field_service_complaint_handoff', 'field_service_lead_qualifier'];

export const VARIABLES = ['{first_name}', '{username}', '{comment_text}', '{service_interest}', '{service_area}', '{urgency}'];

export const FIELD_SERVICE_AUTOMATION_PRESETS = ['quote_request', 'availability_request', 'emergency_request', 'review_request', 'complaint_handoff'];
