@extends('panel.layout.app')
@section('title', 'Titan Reach Inbox')
@section('content')
<div class="container-fluid py-4">
  <div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="mb-1">Titan Reach Inbox</h1><p class="text-muted mb-0">Unified attention for leads, quotes, bookings, reviews, complaints and safety issues.</p></div></div>
  <div class="card"><div class="card-body p-0"><div class="table-responsive"><table class="table mb-0">
    <thead><tr><th>Priority</th><th>Type</th><th>Channel</th><th>Message</th><th>Status</th><th></th></tr></thead><tbody>
    @forelse($items as $item)<tr>
      <td><strong>{{ strtoupper($item->priority) }}</strong></td><td>{{ str_replace('_',' ',ucfirst($item->category)) }}</td><td>{{ ucfirst($item->platform) }}</td><td>{{ $item->message_excerpt }}</td><td>{{ ucfirst($item->status) }}</td>
      <td><form method="POST" action="{{ route('dashboard.user.titan-reach.automation.inbox.update', $item) }}">@csrf @method('PATCH')<select name="status" onchange="this.form.submit()"><option value="open" @selected($item->status==='open')>Open</option><option value="working" @selected($item->status==='working')>Working</option><option value="resolved" @selected($item->status==='resolved')>Resolved</option><option value="spam" @selected($item->status==='spam')>Spam</option></select></form></td>
    </tr>@empty<tr><td colspan="6" class="text-center py-5 text-muted">No attention items yet.</td></tr>@endforelse
    </tbody></table></div></div></div><div class="mt-3">{{ $items->links() }}</div>
</div>
@endsection
