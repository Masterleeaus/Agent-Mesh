@php
    $module = $module ?? ['label' => 'Field-Service Workspace', 'role' => 'Marketing module'];
    $links = $links ?? [];
    $crossExtensionLinks = $crossExtensionLinks ?? [];
    $health = $health ?? [];
@endphp

<div class="container-fluid py-4 field-service-workspace">
    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 mb-4">
        <div>
            <p class="text-muted text-uppercase small mb-1">Field & Home Services Social Stack</p>
            <h1 class="mb-1">{{ $module['label'] ?? 'Field-Service Workspace' }}</h1>
            <p class="text-muted mb-0">{{ $module['role'] ?? 'Unified marketing workspace' }}</p>
        </div>
        <span class="badge bg-primary-subtle text-primary">Company scoped{{ $companyId ? ': #' . $companyId : '' }}</span>
    </div>

    @includeIf('titan-reach-flow::components.field-service-runtime-links')

    <div class="row g-3 mb-4">
        @foreach ($links as $link)
            <div class="col-md-6 col-xl-3">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title mb-2">{{ $link['label'] }}</h5>
                        <p class="text-muted small mb-3">Permission: {{ $link['permission'] }}</p>
                        @if ($link['enabled'])
                            <a class="btn btn-sm btn-primary" href="{{ url($link['path']) }}">Open</a>
                        @else
                            <button class="btn btn-sm btn-outline-secondary" disabled>Permission required</button>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white"><strong>Connected social stack</strong></div>
                <div class="card-body">
                    @foreach ($crossExtensionLinks as $item)
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>{{ $item['label'] }}</span>
                            <code>{{ $item['binding'] }}</code>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white"><strong>Health indicators</strong></div>
                <div class="card-body">
                    @foreach ($health as $key => $indicator)
                        @if (is_array($indicator))
                            <div class="d-flex justify-content-between border-bottom py-2">
                                <span>{{ str_replace('_', ' ', ucfirst($key)) }}</span>
                                <span class="badge {{ !empty($indicator['available']) ? 'bg-success' : 'bg-secondary' }}">{{ $indicator['mode'] ?? 'unknown' }}</span>
                            </div>
                        @endif
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
