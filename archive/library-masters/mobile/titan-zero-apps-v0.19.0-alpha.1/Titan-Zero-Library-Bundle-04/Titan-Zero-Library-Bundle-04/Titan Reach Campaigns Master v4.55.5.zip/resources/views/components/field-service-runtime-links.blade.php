@php
    $runtimeLinks = $runtimeLinks ?? [
        ['label' => 'Field Marketing Hub', 'route' => 'dashboard.user.titan-reach.field-service-workspace', 'path' => 'dashboard/user/titan-reach/field-service-workspace'],
        ['label' => 'Local Growth Agent', 'route' => 'dashboard.user.titan-reach.agent.field-service-workspace', 'path' => 'dashboard/user/titan-reach/agent/field-service-workspace'],
        ['label' => 'Lead & Review Automation', 'route' => 'dashboard.user.titan-reach.automation.field-service-workspace', 'path' => 'dashboard/user/titan-reach/automation/field-service-workspace'],
        ['label' => 'Campaign Playbooks', 'route' => 'dashboard.user.titan-reach.campaigns.workspace', 'path' => 'dashboard/user/titan-reach/campaigns/workspace'],
    ];
@endphp

<div class="alert alert-light border mb-4 field-service-runtime-links">
    <strong>Social Stack Runtime Links</strong>
    <div class="d-flex flex-wrap gap-2 mt-2">
        @foreach ($runtimeLinks as $runtimeLink)
            @php
                $runtimeRoute = $runtimeLink['route'] ?? null;
                $runtimePath = $runtimeLink['path'] ?? '#';
                $runtimeAvailable = $runtimeRoute && \Illuminate\Support\Facades\Route::has($runtimeRoute);
            @endphp
            @if ($runtimeAvailable)
                <a class="btn btn-sm btn-outline-primary" href="{{ route($runtimeRoute) }}">{{ $runtimeLink['label'] }}</a>
            @else
                <span class="btn btn-sm btn-outline-secondary disabled" aria-disabled="true" title="Module route unavailable in this install">{{ $runtimeLink['label'] }}</span>
            @endif
        @endforeach
    </div>
</div>
