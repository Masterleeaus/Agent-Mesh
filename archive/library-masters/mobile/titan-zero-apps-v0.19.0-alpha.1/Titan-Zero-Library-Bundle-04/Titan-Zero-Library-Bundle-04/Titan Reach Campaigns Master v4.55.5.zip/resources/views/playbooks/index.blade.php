@extends('panel.layout.app')
@section('title', 'Titan Reach Campaigns')
@section('titlebar_subtitle', 'Campaign playbooks and governed growth planning')

@section('content')
<div class="py-10">
    <h1 class="text-2xl font-semibold">Titan Reach Campaigns</h1>
    <p class="mt-2 text-sm text-gray-600">Plan field-service campaigns for Titan Reach Pro. Campaigns never publishes directly.</p>

    <form class="mt-6 rounded-lg border p-4" method="POST" action="{{ route('dashboard.user.titan-reach.campaigns.playbooks.store') }}">
        @csrf
        <input type="hidden" name="company_id" value="{{ $companyId }}">
        <div class="grid gap-4 md:grid-cols-2">
            <label>Campaign name<input class="form-control" type="text" name="campaign_name" maxlength="255"></label>
            <label>Duration<select class="form-control" name="duration_weeks" required>@foreach($durations as $duration)<option value="{{ $duration }}">{{ $duration }} week{{ $duration == 1 ? '' : 's' }}</option>@endforeach</select></label>
            <label>Category<select class="form-control" name="category" required>@foreach($categories as $key => $label)<option value="{{ $key }}">{{ $label }}</option>@endforeach</select></label>
            <label>Start date<input class="form-control" type="date" name="start_date"></label>
        </div>
        <button class="btn btn-primary mt-4" type="submit">Create playbook</button>
    </form>

    <div class="mt-6 rounded-lg border p-4">
        <h2 class="font-medium">Planned content</h2>
        @forelse($items as $item)
            <div class="border-b py-3 last:border-b-0">
                <div class="font-medium">{{ $item->headline }}</div>
                <div class="text-sm text-gray-600">{{ $item->brief }}</div>
                <div class="mt-1 text-xs uppercase tracking-wide text-gray-500">{{ $item->handoff_status }}</div>
            </div>
        @empty
            <p class="text-sm text-gray-600">No playbook items planned yet.</p>
        @endforelse
        <div class="mt-4">{{ $items->withQueryString()->links() }}</div>
    </div>
</div>
@endsection
