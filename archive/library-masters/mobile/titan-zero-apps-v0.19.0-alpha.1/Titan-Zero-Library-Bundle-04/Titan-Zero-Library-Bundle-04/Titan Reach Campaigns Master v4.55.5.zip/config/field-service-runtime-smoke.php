<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-campaigns',
    'module_slug' => 'campaign_playbooks',
    'module_name' => 'Campaign Playbooks',
    'version' => '4.54',
    'runtime_smoke_ready' => true,
    'route_names' => [
        'dashboard.user.titan-reach.campaigns.workspace',
        'dashboard.user.titan-reach.campaigns.playbooks.index',
        'dashboard.user.titan-reach.campaigns.playbooks.store',
        'dashboard.user.titan-reach.campaigns.playbooks.export',
                    ],
    'route_prefixes' => [
        'dashboard',
        'automation/playbooks'
    ],
    'views' => [
        'resources/views/field-service-workspace.blade.php',
                'resources/views/playbooks/index.blade.php',
            ],
    'controllers' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/CampaignPlaybookController.php',
            ],
    'navigation_modules' => [
        'field_marketing_hub',
        'local_growth_agent',
        'lead_review_automation',
        'campaign_playbooks'
    ],
    'checks' => [
        'route_registration',
        'view_resolution',
        'controller_presence',
        'config_registration',
        'workspace_navigation',
        'permission_gate',
        'standalone_fallback'
    ]
];
