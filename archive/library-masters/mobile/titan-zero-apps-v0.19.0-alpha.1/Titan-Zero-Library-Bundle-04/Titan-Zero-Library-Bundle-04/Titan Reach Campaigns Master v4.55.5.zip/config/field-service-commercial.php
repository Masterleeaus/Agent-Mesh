<?php

return [
    'enabled' => true,
    'fail_closed' => true,
    'free_plan' => [
        'monthly_ai_drafts' => 10,
        'monthly_titan_reach_campaign_scheduled_posts' => 20,
        'monthly_automation_runs' => 50,
        'connected_social_accounts' => 2,
        'active_campaign_playbooks' => 2,
        'lead_capture_retention_days' => 30,
    ],
    'plans' => [
        'free' => [
            'label' => 'Starter',
            'description' => 'Basic field-service social planning with conservative limits.',
            'features' => ['field_service_context', 'manual_drafts', 'basic_vertical_packs'],
        ],
        'growth' => [
            'label' => 'Growth',
            'description' => 'Local growth automation for busy field/home-service teams.',
            'features' => ['local_growth_agent', 'lead_capture', 'automation_presets', 'campaign_playbooks'],
        ],
        'pro' => [
            'label' => 'Pro',
            'description' => 'Full field-service marketing workspace with approvals and attribution.',
            'features' => ['publish_governance', 'conversion_attribution', 'titan_integrations', 'advanced_reporting'],
        ],
    ],
    'feature_flags' => [
        'field_service_context' => true,
        'manual_drafts' => true,
        'basic_vertical_packs' => true,
        'local_growth_agent' => 'growth',
        'lead_capture' => 'growth',
        'automation_presets' => 'growth',
        'campaign_playbooks' => 'growth',
        'publish_governance' => 'pro',
        'conversion_attribution' => 'pro',
        'titan_integrations' => 'pro',
        'advanced_reporting' => 'pro',
    ],
    'commercial_safety' => [
        'never_disable_security_controls' => true,
        'never_disable_privacy_redaction' => true,
        'never_enable_platform_ai_by_default' => true,
        'require_explicit_upgrade_for_paid_features' => true,
        'safe_unavailable_message' => 'This field-service marketing feature is not available on the current plan.',
    ],
];
