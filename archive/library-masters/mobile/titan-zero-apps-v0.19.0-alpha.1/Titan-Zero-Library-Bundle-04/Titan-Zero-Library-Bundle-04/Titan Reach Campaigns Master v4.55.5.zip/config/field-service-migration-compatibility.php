<?php

declare(strict_types=1);

return [
    'step' => 27,
    'name' => 'Database Migration & Upgrade Compatibility Trial',
    'non_destructive_only' => true,
    'fresh_install_supported' => true,
    'upgrade_install_supported' => true,
    'duplicate_safe_columns' => true,
    'schema_rules' => [
        'never_drop_columns' => true,
        'never_rename_existing_columns_without_compatibility_alias' => true,
        'guard_add_columns_with_schema_has_column' => true,
        'guard_create_tables_with_schema_has_table' => true,
        'preserve_company_id_as_canonical_tenant_boundary' => true,
        'preserve_user_id_as_actor_metadata_only' => true,
    ],
    'diagnostic_stages' => [
        'preflight',
        'fresh_install_schema_plan',
        'upgrade_schema_plan',
        'duplicate_column_replay',
        'rollback_safety_review',
        'post_migration_runtime_readiness',
    ],
    'required_runtime_artifacts' => [
        'config/field-service-runtime-repair.php',
        'config/field-service-live-installer-diagnostics.php',
        'config/field-service-runtime-certification.php',
    ],
    'safety_controls_that_must_survive_migration' => [
        'company_id tenancy correlation',
        'webhook fail-closed verification',
        'callback state correlation',
        'payload redaction',
        'job media privacy defaults',
        'publish governance',
    ],
];
