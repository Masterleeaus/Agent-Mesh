<?php
return [
    'company_boundary' => 'company_id',
    'organisation_owner' => 'titan-ai-workforce',
    'host_contracts' => [
        'command_bus' => 'App\\Extensions\\TitanCommandBus\\System\\Contracts\\CommandBusContract',
        'crm_gateway' => 'App\\Extensions\\Crm\\System\\Governance\\CrmCommandBusGateway',
        'crm_scope' => 'App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyScope',
        'crm_context_resolver' => 'App\\Extensions\\Crm\\System\\Tenancy\\CrmCompanyContextResolver',
        'field_tenant' => 'App\\Extensions\\TitanField\\System\\Contracts\\FieldTenantContext',
        'field_signal' => 'App\\Extensions\\TitanField\\System\\Contracts\\FieldSignalPort',
        'field_capacity' => 'App\\Extensions\\TitanField\\System\\Domains\\FieldServices\\Forecasting\\CapacityForecastService',
        'connect_gateway' => 'App\\Extensions\\TitanConnect\\System\\Contracts\\MessagingToolGateway',
    ],
    'rules' => [
        'crm_writes_via_crm_command_bus_gateway' => true,
        'field_capacity_is_read_only_service' => true,
        'field_signals_via_field_signal_port' => true,
        'connect_messages_via_messaging_tool_gateway' => true,
        'root_command_bus_only_for_registered_adapters' => true,
        'no_direct_host_table_writes' => true,
    ],
];
