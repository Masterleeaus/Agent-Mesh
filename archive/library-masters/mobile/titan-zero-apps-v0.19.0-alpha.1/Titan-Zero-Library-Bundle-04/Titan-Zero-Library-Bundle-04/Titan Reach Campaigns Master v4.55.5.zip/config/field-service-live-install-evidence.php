<?php

declare(strict_types=1);

return [
    'phase' => 'phase_4_live_install_production',
    'step' => 33,
    'module_key' => 'campaign_playbooks',
    'capture_enabled' => true,
    'required_evidence' => [
        'install_id',
        'installer_stage',
        'installer_status',
        'package_sha256',
        'extension_version',
        'php_version',
        'laravel_version',
        'database_driver',
        'event_timeline',
        'redacted_error_summary',
    ],
    'redaction_keys' => [
        'token', 'secret', 'signature', 'password', 'authorization', 'cookie',
        'customer_name', 'customer_handle', 'contact_value', 'external_customer_id',
        'raw_webhook_body', 'message_body', 'comment_text', 'stack_trace',
    ],
    'decision_states' => [
        'evidence_ready',
        'needs_hotfix',
        'blocked_missing_evidence',
    ],
    'safety_rules' => [
        'never_log_tokens' => true,
        'never_log_customer_text' => true,
        'preserve_company_boundary' => true,
        'diagnostics_are_non_mutating' => true,
    ],
];
