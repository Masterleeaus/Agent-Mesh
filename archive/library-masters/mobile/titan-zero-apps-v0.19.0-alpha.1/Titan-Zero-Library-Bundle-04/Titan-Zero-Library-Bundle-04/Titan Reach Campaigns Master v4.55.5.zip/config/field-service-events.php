<?php

return [
    'enabled' => true,
    'source_extension' => 'titan-reach-campaigns',
    'public_event_name' => 'field_service.social.event',
    'canonical_events' => [
        'content_draft_proposed' => 'field_service.content_draft_proposed',
        'publish_requested' => 'field_service.publish_requested',
        'post_published' => 'field_service.post_published',
        'lead_captured' => 'field_service.lead_captured',
        'review_opportunity' => 'field_service.review_opportunity',
        'campaign_plan_ready' => 'field_service.campaign_plan_ready',
        'conversion_recorded' => 'field_service.conversion_recorded',
    ],
    'privacy' => [
        'redact_payloads_before_logging' => true,
        'require_company_id' => true,
        'do_not_dispatch_raw_webhook_bodies' => true,
        'do_not_dispatch_provider_tokens' => true,
    ],
];
