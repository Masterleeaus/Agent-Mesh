<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'require_company_id' => true,
    'dry_run_by_default' => true,
    'signals' => [
        'route_density' => ['weight' => 30, 'minimum_jobs' => 2],
        'schedule_gap' => ['weight' => 25, 'minimum_open_slots' => 1],
        'seasonal_service' => ['weight' => 18],
        'review_flywheel' => ['weight' => 22, 'minimum_completed_jobs' => 1],
        'presence_gap' => ['weight' => 15],
    ],
    'guardrails' => [
        'invent_prices' => false,
        'invent_licences' => false,
        'invent_emergency_availability' => false,
        'invent_service_areas' => false,
        'use_private_customer_data' => false,
        'auto_publish' => false,
        'auto_message_customers' => false,
    ],
];
