<?php

declare(strict_types=1);

return [
    'module' => 'titan_reach_distribution_engine',
    'version' => 'step36',
    'policy' => [
        'company_id_required' => true,
        'publish_authority' => 'titan_reach_pro',
        'assisted_distribution_requires_owner_action' => true,
        'paid_distribution_requires_budget_approval' => true,
        'never_invent_licence_price_emergency_or_coverage' => true,
    ],
    'destinations' => [
        'facebook_page' => ['mode' => 'direct', 'priority' => 'primary', 'content' => ['text','image','video','link'], 'capabilities' => ['publish','schedule','analytics','inbox','cta'], 'approval_required' => true],
        'instagram_business' => ['mode' => 'direct', 'priority' => 'primary', 'content' => ['image','video','reel','story'], 'capabilities' => ['publish','schedule','analytics','inbox'], 'approval_required' => true],
        'google_business_profile' => ['mode' => 'direct', 'priority' => 'critical', 'content' => ['update','photo','review_reply'], 'capabilities' => ['publish','photos','reviews','analytics','local_presence'], 'approval_required' => true],
        'meta_ads' => ['mode' => 'paid_governed', 'priority' => 'critical', 'content' => ['ad_draft','creative','audience'], 'capabilities' => ['draft','preview','budget','activate','pause','insights'], 'approval_required' => true, 'budget_approval_required' => true],
        'google_local_services_ads' => ['mode' => 'paid_governed', 'priority' => 'critical', 'content' => ['lead_ads_readiness','budget_plan'], 'capabilities' => ['readiness','budget','lead_attribution'], 'approval_required' => true, 'verification_required' => true],
        'nextdoor' => ['mode' => 'assisted', 'priority' => 'high', 'content' => ['neighbourhood_post','offer','service_update'], 'capabilities' => ['assisted_package','manual_completion'], 'approval_required' => true],
        'gumtree' => ['mode' => 'assisted', 'priority' => 'high_au', 'content' => ['classified','service_listing'], 'capabilities' => ['assisted_package','manual_completion'], 'approval_required' => true],
        'facebook_marketplace' => ['mode' => 'assisted', 'priority' => 'high', 'content' => ['listing_package'], 'capabilities' => ['assisted_package','manual_completion'], 'approval_required' => true],
        'pinterest' => ['mode' => 'direct_or_assisted', 'priority' => 'medium', 'content' => ['pin','board','image'], 'capabilities' => ['publish','analytics'], 'approval_required' => true],
        'linkedin' => ['mode' => 'direct', 'priority' => 'b2b', 'content' => ['post','image','document'], 'capabilities' => ['publish','schedule','analytics'], 'approval_required' => true],
        'youtube_shorts' => ['mode' => 'direct', 'priority' => 'video', 'content' => ['short_video'], 'capabilities' => ['publish','analytics'], 'approval_required' => true],
        'tiktok' => ['mode' => 'direct_or_assisted', 'priority' => 'video', 'content' => ['short_video'], 'capabilities' => ['publish','analytics'], 'approval_required' => true],
        'apple_business_connect' => ['mode' => 'local_presence', 'priority' => 'medium', 'content' => ['presence_update'], 'capabilities' => ['presence_health','assisted_package'], 'approval_required' => true],
        'bing_places' => ['mode' => 'local_presence', 'priority' => 'medium', 'content' => ['presence_update'], 'capabilities' => ['presence_health','assisted_package'], 'approval_required' => true],
        'directories' => ['mode' => 'assisted', 'priority' => 'directory', 'content' => ['listing_health','profile_update'], 'capabilities' => ['presence_health','lead_import','manual_completion'], 'approval_required' => true],
    ],
];
