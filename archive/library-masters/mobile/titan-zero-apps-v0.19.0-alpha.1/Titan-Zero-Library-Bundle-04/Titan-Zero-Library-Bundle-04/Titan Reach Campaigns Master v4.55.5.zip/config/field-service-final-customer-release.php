<?php

return [
    'release_stage' => 'final_customer_release_candidate',
    'release_candidate' => 'RC1',
    'customer_ready' => true,
    'requires_live_install_trial' => true,
    'support_channel' => 'heew_support',
    'install_order' => [
        'titan-reach-pro-field-marketing-hub',
        'titan-reach-agent-local-growth-agent',
        'titan-reach-flow-lead-review-automation',
        'titan-reach-campaigns',
    ],
    'customer_release_gates' => [
        'zip_integrity',
        'manifest_parse',
        'php_lint',
        'runtime_readiness',
        'migration_compatibility',
        'webhook_dry_run',
        'field_marketing_hub_workflow_trial',
        'local_growth_agent_operational_trial',
        'commercial_tier_enforcement',
        'safety_controls_locked',
    ],
    'safety_controls_locked' => [
        'company_id_required',
        'webhooks_fail_closed',
        'callback_correlation_required',
        'ssrf_protection_enabled',
        'payload_redaction_enabled',
        'media_privacy_enabled',
        'publish_governance_enabled',
        'commercial_tiers_do_not_disable_safety',
        'demo_data_marked_demo_only',
    ],
    'customer_install_notes' => [
        'Install Titan Reach Pro first when using the full stack.',
        'Configure field-service profile before enabling agent automation.',
        'Do not enable webhooks without provider secrets and timestamp/replay validation.',
        'Run dry-run trials before connecting live customer channels.',
    ],
];
