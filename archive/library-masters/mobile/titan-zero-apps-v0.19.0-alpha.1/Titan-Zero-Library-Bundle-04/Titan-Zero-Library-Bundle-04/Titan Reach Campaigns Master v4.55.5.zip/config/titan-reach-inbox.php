<?php
return ['owner'=>'titan-reach-flow','binding'=>'titan-reach.inbox','standalone_safe'=>true];
