<?php

return [
    'release' => 'step-44-production',
    'tenant_boundary' => 'company_id',
    'host_bridge' => 'TitanZeroClosedLoopBridge',
    'legacy_placeholder_integrations_removed' => true,
    'ownership' => [
        'pro' => 'distribution, publishing, reputation, paid-growth governance, local presence',
        'agent' => 'growth intelligence and recommendations',
        'flow' => 'inbox, lead/review automation and engagement operations',
        'campaigns' => 'campaign playbooks and governed planning',
    ],
    'safety' => [
        'webhooks_fail_closed' => true,
        'publish_governance_required' => true,
        'paid_activation_requires_human_approval' => true,
        'direct_host_table_writes_forbidden' => true,
    ],
];
