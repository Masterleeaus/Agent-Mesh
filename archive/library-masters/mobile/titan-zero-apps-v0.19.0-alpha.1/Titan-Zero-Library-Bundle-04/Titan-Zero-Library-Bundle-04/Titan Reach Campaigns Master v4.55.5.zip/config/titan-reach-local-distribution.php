<?php

declare(strict_types=1);

return [
    'module' => 'titan_reach_local_distribution',
    'version' => 'step40',
    'policy' => [
        'company_id_required' => true,
        'direct_publish_authority' => 'titan_reach_pro',
        'assisted_requires_owner_action' => true,
        'manual_completion_requires_owner_action' => true,
        'never_claim_provider_api_support_without_adapter' => true,
        'never_invent_price_licence_emergency_or_coverage' => true,
    ],
    'destinations' => [
        'gumtree' => ['label'=>'Gumtree','mode'=>'assisted','region'=>'AU','capabilities'=>['listing_package','manual_completion','lead_source']],
        'facebook_marketplace' => ['label'=>'Facebook Marketplace','mode'=>'assisted','region'=>'global','capabilities'=>['listing_package','manual_completion','lead_source']],
        'nextdoor' => ['label'=>'Nextdoor','mode'=>'assisted','region'=>'supported_markets','capabilities'=>['neighbourhood_package','manual_completion','lead_source']],
        'apple_business_connect' => ['label'=>'Apple Business Connect','mode'=>'local_presence','region'=>'global','capabilities'=>['presence_health','profile_package','manual_completion']],
        'bing_places' => ['label'=>'Bing Places','mode'=>'local_presence','region'=>'global','capabilities'=>['presence_health','profile_package','manual_completion']],
        'hipages' => ['label'=>'hipages','mode'=>'directory_assisted','region'=>'AU','capabilities'=>['profile_health','lead_source','manual_completion']],
        'oneflare' => ['label'=>'Oneflare','mode'=>'directory_assisted','region'=>'AU','capabilities'=>['profile_health','lead_source','manual_completion']],
        'airtasker' => ['label'=>'Airtasker','mode'=>'marketplace_assisted','region'=>'AU','capabilities'=>['profile_health','lead_source','manual_completion']],
        'serviceseeking' => ['label'=>'ServiceSeeking','mode'=>'directory_assisted','region'=>'AU','capabilities'=>['profile_health','lead_source','manual_completion']],
        'yellow_pages_au' => ['label'=>'Yellow Pages Australia','mode'=>'directory_assisted','region'=>'AU','capabilities'=>['presence_health','profile_package','manual_completion']],
        'true_local' => ['label'=>'True Local','mode'=>'directory_assisted','region'=>'AU','capabilities'=>['presence_health','profile_package','manual_completion']],
        'houzz' => ['label'=>'Houzz','mode'=>'directory_assisted','region'=>'supported_markets','capabilities'=>['portfolio_package','profile_health','lead_source']],
        'ebay' => ['label'=>'eBay','mode'=>'optional_commerce','region'=>'global','capabilities'=>['listing_package','manual_completion'],'service_default'=>false],
    ],
];
