<?php

declare(strict_types=1);

return [
    'release_step' => 29,
    'workflow_name' => 'field_marketing_hub_workflow_trial',
    'required_company_scope' => true,
    'checks' => [
        'context_setup',
        'vertical_pack_selected',
        'content_draft_created',
        'media_privacy_reviewed',
        'publish_governance_reviewed',
        'publish_request_handoff',
        'attribution_visibility',
    ],
    'forbidden_inference' => [
        'licences',
        'prices',
        'emergency_availability',
        'unsupported_service_areas',
        'customer_names',
        'exact_addresses',
        'faces',
        'vehicle_plates',
    ],
    'dry_run_only' => true,
];
