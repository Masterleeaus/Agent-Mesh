<?php

declare(strict_types=1);

return [
    'extension_key' => 'titan-reach-campaigns',
    'module_slug' => 'campaign_playbooks',
    'module_label' => 'Campaign Playbooks',
    'route_names' => [
        'dashboard.user.titan-reach.campaigns.workspace',
        'dashboard.user.titan-reach.campaigns.playbooks.index',
        'dashboard.user.titan-reach.campaigns.playbooks.store',
        'dashboard.user.titan-reach.campaigns.playbooks.export',
                    ],
    'view_paths' => [
        'resources/views/field-service-workspace.blade.php',
                'resources/views/playbooks/index.blade.php',
                    ],
    'controller_paths' => [
        'System/Http/Controllers/FieldServiceWorkspaceController.php',
        'System/Http/Controllers/CampaignPlaybookController.php',
            ],
    'safe_route_resolution' => true,
    'safe_blade_includes' => true,
    'missing_module_mode' => 'disabled_link',
    'fallback_url_mode' => 'url_path',
    'permission' => 'field_service_marketing.view',
    'company_scoped' => true,
];
