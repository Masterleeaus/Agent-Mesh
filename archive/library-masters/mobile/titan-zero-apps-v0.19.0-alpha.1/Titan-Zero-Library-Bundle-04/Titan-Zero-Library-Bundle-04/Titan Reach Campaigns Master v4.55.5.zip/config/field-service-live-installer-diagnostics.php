<?php

return [
    'module' => 'Campaign Playbooks',
    'phase' => 'phase_3_step_25',
    'enabled' => true,
    'fail_closed' => true,
    'capture' => [
        'install_id' => true,
        'stage' => true,
        'installer_build' => true,
        'php_version' => true,
        'laravel_version' => true,
        'database_driver' => true,
        'package_sha256' => true,
    ],
    'redact_keys' => [
        'token', 'access_token', 'refresh_token', 'secret', 'password', 'authorization',
        'signature', 'webhook_secret', 'api_key', 'client_secret', 'customer_name',
        'customer_handle', 'contact_value', 'raw_body', 'payload', 'message_body',
    ],
    'required_install_checks' => [
        'extension_json_parseable',
        'service_provider_loadable',
        'config_registered',
        'migrations_discoverable',
        'routes_discoverable',
        'views_discoverable',
        'support_classes_autoloadable',
        'company_id_runtime_context_available',
    ],
    'common_hotfix_routes' => [
        'manifest_schema_mismatch' => 'Confirm installer build expects the legacy five-field extension.json shape before upload.',
        'class_not_found' => 'Run composer/package autoload refresh or confirm extension folder namespace matches the ServiceProvider namespace.',
        'migration_failure' => 'Check migration order, duplicate table guards and company_id compatibility before retrying.',
        'view_not_found' => 'Confirm loadViewsFrom namespace registration and resources/views path were installed.',
        'route_collision' => 'Confirm route names are extension-prefixed and no legacy duplicate route remains active.',
        'permission_denied' => 'Confirm storage/public/vendor extension asset paths and cache directories are writable by PHP.',
    ],
];
