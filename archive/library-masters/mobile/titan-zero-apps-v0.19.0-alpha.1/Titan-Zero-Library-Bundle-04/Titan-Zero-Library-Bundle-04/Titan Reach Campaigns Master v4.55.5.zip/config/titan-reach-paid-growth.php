<?php

return [
    'role' => 'campaign_playbooks',
    'mode' => 'campaign_plan',
    'activation_authority' => false,
    'automatic_spend' => false,
    'pro_binding' => 'titan-reach.paid-growth',
];
