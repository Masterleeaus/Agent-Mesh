<?php

declare(strict_types=1);

return [
    'step' => 28,
    'name' => 'Real Webhook & Automation Dry Run',
    'dry_run_only' => true,
    'provider_messages_enabled' => false,
    'publishing_enabled' => false,
    'requires_company_id' => true,
    'requires_signature_verification' => true,
    'requires_replay_protection' => true,
    'redact_sensitive_payloads' => true,
    'supported_platforms' => ['facebook', 'instagram', 'x', 'tiktok', 'linkedin'],
    'covered_triggers' => [
        'quote_request',
        'booking_request',
        'emergency_handoff',
        'review_opportunity',
        'complaint_handoff',
    ],
];
