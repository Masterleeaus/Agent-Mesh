<?php

return [
    'release' => [
        'step' => 16,
        'name' => 'production-hardening-final',
        'created_at' => '2026-08-22T20:58:00+10:00',
        'extension_name' => 'Titan Reach Campaigns - Campaign Playbooks',
        'extension_version' => '4.54',
        'requires_company_id' => true,
        'publishing_authority' => 'external_or_bridge',
    ],
    'installed_together_contracts' => [
        'field_service_context_provider',
        'field_service_event_bus',
        'field_service_social_lead_bridge',
        'field_service_ai_provider_bridge',
        'field_service_workspace_health',
    ],
    'production_gates' => [
        'zip_paths_are_portable' => true,
        'extension_json_has_no_bom' => true,
        'php_lint_clean' => true,
        'externally_reachable_surfaces_fail_closed' => true,
        'company_id_required_for_cross_extension_context' => true,
        'sensitive_payloads_redacted' => true,
        'standalone_fallbacks_available' => true,
    ],
    'safe_defaults' => [
        'invent_licences' => false,
        'invent_prices' => false,
        'invent_emergency_availability' => false,
        'invent_service_areas' => false,
        'infer_customer_identity_from_media' => false,
        'auto_publish_playbook_items' => false,
    ],
];
