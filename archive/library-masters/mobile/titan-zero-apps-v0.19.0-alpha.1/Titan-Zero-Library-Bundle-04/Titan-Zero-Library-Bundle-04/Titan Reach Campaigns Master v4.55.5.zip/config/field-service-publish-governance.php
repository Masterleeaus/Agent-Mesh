<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'requires_company_id' => true,
    'states' => [
        'draft',
        'review_required',
        'approved',
        'publish_requested',
        'published',
        'rejected',
        'blocked',
    ],
    'permissions' => [
        'view' => 'field_service_marketing.view',
        'create_content' => 'field_service_marketing.create_content',
        'request_publish' => 'field_service_marketing.manage_campaigns',
        'approve_publish' => 'field_service_marketing.publish',
        'publish' => 'field_service_marketing.publish',
    ],
    'guardrails' => [
        'separate_draft_from_publish' => true,
        'require_human_approval_when_profile_requires_review' => true,
        'block_unconfigured_emergency_claims' => true,
        'block_unconfigured_licence_claims' => true,
        'block_unauthorised_price_claims' => true,
        'require_media_privacy_acknowledgement_for_job_media' => true,
        'never_auto_publish_playbook_handoffs' => true,
        'redact_audit_payloads' => true,
    ],
    'audit_summary_fields' => [
        'company_id',
        'actor_id',
        'draft_id',
        'campaign_id',
        'state',
        'reasons',
        'created_at',
    ],
];
