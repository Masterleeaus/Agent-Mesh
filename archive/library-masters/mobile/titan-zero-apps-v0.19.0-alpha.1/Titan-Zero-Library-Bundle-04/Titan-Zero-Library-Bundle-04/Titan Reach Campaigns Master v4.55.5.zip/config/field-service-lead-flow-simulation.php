<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'scenario' => 'field_service_quote_request',
    'required_company_correlation' => true,
    'privacy_mode' => 'redacted',
    'steps' => [
        'engagement_received',
        'automation_trigger_matched',
        'social_lead_captured',
        'attribution_recorded',
        'event_published',
        'workspace_visible',
    ],
    'required_events' => [
        'field_service.lead_captured',
        'field_service.conversion_recorded',
        'field_service.review_opportunity',
    ],
    'redacted_fields' => [
        'customer_name',
        'customer_handle',
        'customer_external_id',
        'contact_value',
        'raw_webhook_body',
        'token',
        'secret',
        'signature',
    ],
    'standalone_fallback' => true,
];
