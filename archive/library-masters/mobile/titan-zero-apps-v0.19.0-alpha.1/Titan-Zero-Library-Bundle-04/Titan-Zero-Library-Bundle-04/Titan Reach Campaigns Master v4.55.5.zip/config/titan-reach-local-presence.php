<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'require_company_id' => true,
    'nap_consistency' => true,
    'presence_channels' => ['google_business_profile','apple_business_connect','bing_places','facebook_page'],
    'directory_channels' => ['hipages','oneflare','serviceseeking','yellow_pages_au','true_local','houzz'],
    'checks' => ['business_name','phone','website','service_areas','services','hours','categories','reviews','photos','local_landing_pages'],
    'safe_defaults' => [
        'invent_coverage' => false,
        'invent_licences' => false,
        'invent_prices' => false,
        'auto_edit_external_profiles' => false,
    ],
];
