<?php

declare(strict_types=1);

namespace Tests\Feature\Extensions;

final class DemoBusinessVerticalShowcaseStaticTest
{
    public function test_demo_showcase_contract_is_present(): void
    {
        $extensionRoot = dirname(__DIR__, 2);

        $config = file_get_contents($extensionRoot . '/config/field-service-demo-showcase.php');
        $support = file_get_contents($extensionRoot . '/System/Support/DemoBusinessVerticalShowcase.php');

        assert(str_contains($config, "'demo_only' => true"));
        assert(substr_count($config, "'demo_business_name'") === 10);
        assert(str_contains($config, "'never_assert_licence' => true"));
        assert(str_contains($config, "'never_assert_price' => true"));
        assert(str_contains($config, "'never_assert_emergency_service' => true"));
        assert(str_contains($support, 'forbidden_claims'));
        assert(str_contains($support, 'demo_only'));
    }
}
