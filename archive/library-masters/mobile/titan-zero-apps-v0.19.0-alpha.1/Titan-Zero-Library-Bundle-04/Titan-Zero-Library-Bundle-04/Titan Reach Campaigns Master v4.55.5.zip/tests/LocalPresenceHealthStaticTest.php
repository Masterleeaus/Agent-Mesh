<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\Tests;

use PHPUnit\Framework\TestCase;

final class LocalPresenceHealthStaticTest extends TestCase
{
    public function test_step_41_contract_is_present(): void
    {
        $root = dirname(__DIR__);
        self::assertFileExists($root . '/config/titan-reach-local-presence.php');
        self::assertFileExists($root . '/System/Support/TitanReachLocalPresenceBridge.php');
    }
}
