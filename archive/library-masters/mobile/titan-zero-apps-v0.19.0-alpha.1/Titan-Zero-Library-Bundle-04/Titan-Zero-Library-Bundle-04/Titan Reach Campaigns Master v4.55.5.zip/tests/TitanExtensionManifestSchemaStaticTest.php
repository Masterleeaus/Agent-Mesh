<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class TitanExtensionManifestSchemaStaticTest extends TestCase
{
    public function test_manifest_matches_titan_extension_manager_contract(): void
    {
        $manifest = json_decode((string) file_get_contents(__DIR__ . '/../extension.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('titan-extension-v1', $manifest['schema'] ?? null);
        self::assertNotEmpty($manifest['slug'] ?? null);
        self::assertNotEmpty($manifest['folder'] ?? null);
        self::assertNotEmpty($manifest['provider'] ?? null);
        self::assertNotEmpty($manifest['version'] ?? null);
        self::assertIsBool($manifest['migrations'] ?? null);
    }
}
