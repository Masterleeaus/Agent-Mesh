<?php

use PHPUnit\Framework\TestCase;

final class FieldServiceVerticalPacksStaticTest extends TestCase
{
    public function testTenVerticalPacksExistAndCarrySafeSignals(): void
    {
        $root = dirname(__DIR__);
        $file = $root.'/System/Services/FieldService/FieldServiceVerticalPackCatalog.php';
        self::assertFileExists($file);
        $source = file_get_contents($file);

        foreach ([
            'cleaning',
            'plumbing',
            'electrical',
            'hvac',
            'handyman_property_maintenance',
            'landscaping_gardening_lawn_care',
            'pest_control',
            'locksmith_security',
            'roofing_guttering',
            'appliance_equipment_repair',
        ] as $slug) {
            self::assertStringContainsString("'{$slug}'", $source);
        }

        foreach ([
            'suggested_services',
            'seasonal_themes',
            'safe_content_lanes',
            'common_cta_styles',
            'review_prompts',
            'local_growth_signals',
            'playbook_defaults',
            'automation_keyword_suggestions',
            'privacy_warnings',
            'forbidden_claims',
        ] as $contractKey) {
            self::assertStringContainsString($contractKey, $source);
        }
    }

    public function testPacksForbidInventedClaims(): void
    {
        $source = file_get_contents(dirname(__DIR__).'/System/Services/FieldService/FieldServiceVerticalPackCatalog.php');
        foreach ([
            'licence_or_certification_not_configured',
            'prices_or_discounts_not_configured',
            'emergency_or_after_hours_availability_not_configured',
            'unconfigured_service_area_or_suburb',
            'exact_customer_address_or_private_customer_detail',
            'identifiable_faces_or_vehicle_plates_without_consent',
        ] as $forbidden) {
            self::assertStringContainsString($forbidden, $source);
        }
    }
}
