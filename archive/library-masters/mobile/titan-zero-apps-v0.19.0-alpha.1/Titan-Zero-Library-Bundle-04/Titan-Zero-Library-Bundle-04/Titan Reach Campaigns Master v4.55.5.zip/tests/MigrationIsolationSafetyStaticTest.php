<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Tests;

use PHPUnit\Framework\TestCase;

final class MigrationIsolationSafetyStaticTest extends TestCase
{
    public function test_migrations_do_not_create_database_foreign_keys(): void
    {
        $root = dirname(__DIR__);
        foreach (glob($root . '/database/migrations/*.php') ?: [] as $file) {
            $source = (string) file_get_contents($file);
            self::assertStringNotContainsString('->constrained(', $source, basename($file));
            self::assertStringNotContainsString('->foreign(', $source, basename($file));
        }
    }

    public function test_down_methods_are_not_empty(): void
    {
        $root = dirname(__DIR__);
        foreach (glob($root . '/database/migrations/*.php') ?: [] as $file) {
            $source = (string) file_get_contents($file);
            self::assertDoesNotMatchRegularExpression('/public function down\(\): void\s*\{\s*\}/s', $source, basename($file));
        }
    }
}
