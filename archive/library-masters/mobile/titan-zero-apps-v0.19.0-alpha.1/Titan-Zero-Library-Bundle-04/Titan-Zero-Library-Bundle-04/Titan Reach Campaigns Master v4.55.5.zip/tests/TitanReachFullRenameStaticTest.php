<?php

declare(strict_types=1);

final class TitanReachFullRenameStaticTest extends \PHPUnit\Framework\TestCase
{
    public function testManifestUsesTitanReachIdentity(): void
    {
        $manifest = json_decode((string) file_get_contents(dirname(__DIR__) . '/extension.json'), true);
        $this->assertIsArray($manifest);
        $this->assertStringStartsWith('Titan Reach', $manifest['name'] ?? '');
        $this->assertStringStartsWith('titan-reach', $manifest['slug'] ?? '');
        $this->assertStringContainsString('TitanReach', $manifest['namespace'] ?? '');
        $this->assertStringContainsString('TitanReach', $manifest['service_provider'] ?? '');
    }
}
