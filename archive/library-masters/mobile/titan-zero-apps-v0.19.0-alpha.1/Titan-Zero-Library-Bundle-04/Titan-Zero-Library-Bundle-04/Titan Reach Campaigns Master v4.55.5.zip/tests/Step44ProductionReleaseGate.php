<?php
$root = dirname(__DIR__);
$failures = [];
foreach ([
    '/System/Support/TitanIntegrationBridge.php',
    '/System/Support/TitanFieldServiceIntegrationHooks.php',
    '/config/field-service-titan-integrations.php',
    '/tests/TitanIntegrationHooksStaticTest.php',
] as $obsolete) {
    if (is_file($root.$obsolete)) $failures[] = 'obsolete:'.$obsolete;
}
$required = [
    '/System/Support/TitanZeroClosedLoopBridge.php',
    '/System/Support/TitanReachProductionRelease.php',
    '/config/titan-reach-production-release.php',
];
foreach ($required as $path) {
    if (!is_file($root.$path)) $failures[] = 'missing:'.$path;
}
$provider = glob($root.'/System/*ServiceProvider.php')[0] ?? null;
if (!$provider || str_contains((string) file_get_contents($provider), 'TitanFieldServiceIntegrationHooks')) {
    $failures[] = 'provider still references legacy integration hooks';
}
if ($failures) {
    fwrite(STDERR, implode("\n", $failures)."\n");
    exit(1);
}
echo "PASS Step44ProductionReleaseGate\n";
