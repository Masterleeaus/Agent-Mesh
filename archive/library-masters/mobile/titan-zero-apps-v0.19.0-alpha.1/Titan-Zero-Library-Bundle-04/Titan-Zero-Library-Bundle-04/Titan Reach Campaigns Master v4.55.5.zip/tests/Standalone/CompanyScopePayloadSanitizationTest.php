<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$bridge = (string) file_get_contents($root.'/System/Support/TitanZeroClosedLoopBridge.php');
$fail = static function (string $message): never { fwrite(STDERR, $message."\n"); exit(1); };

if (! str_contains($bridge, "unset(\$payload['company_id'],\$payload['tenant_company_id'],\$payload['tenant_id']);")) {
    $fail('Closed-loop payload sanitizer does not strip canonical and legacy caller-supplied tenant scope fields.');
}
if (! str_contains($bridge, "'company_boundary'=>'company_id'")) {
    $fail('Closed-loop bridge does not declare company_id as the sole company boundary.');
}
if (str_contains($bridge, "'company_boundary'=>'tenant_company_id'")) {
    $fail('Legacy tenant_company_id is still declared as an authoritative boundary.');
}

echo "Reach company scope payload sanitization: PASS\n";
