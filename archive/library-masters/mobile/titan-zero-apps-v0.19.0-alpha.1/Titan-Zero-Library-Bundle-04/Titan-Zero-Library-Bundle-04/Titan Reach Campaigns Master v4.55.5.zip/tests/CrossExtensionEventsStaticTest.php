<?php

use PHPUnit\Framework\TestCase;

final class CrossExtensionEventsStaticTest extends TestCase
{
    public function testFieldServiceEventContractsArePresent(): void
    {
        $root = dirname(__DIR__);
        $files = [
            $root.'/System/Services/FieldService/Events/FieldServiceEventCatalog.php',
            $root.'/System/Services/FieldService/Events/FieldServiceEventEnvelope.php',
            $root.'/System/Services/FieldService/Events/FieldServiceEventBus.php',
            $root.'/System/Services/FieldService/Events/SharedFieldServiceEventBridge.php',
        ];

        foreach ($files as $file) {
            self::assertFileExists($file);
        }
    }

    public function testCanonicalEventNamesAreDeclared(): void
    {
        $catalog = file_get_contents(dirname(__DIR__).'/System/Services/FieldService/Events/FieldServiceEventCatalog.php');
        foreach ([
            'field_service.content_draft_proposed',
            'field_service.publish_requested',
            'field_service.post_published',
            'field_service.lead_captured',
            'field_service.review_opportunity',
            'field_service.campaign_plan_ready',
            'field_service.conversion_recorded',
        ] as $eventName) {
            self::assertStringContainsString($eventName, $catalog);
        }
    }

    public function testEventEnvelopeRequiresCompanyAndRedactsSecrets(): void
    {
        $envelope = file_get_contents(dirname(__DIR__).'/System/Services/FieldService/Events/FieldServiceEventEnvelope.php');
        self::assertStringContainsString('Field-service events require a company_id', $envelope);
        self::assertStringContainsString('[redacted]', $envelope);
        self::assertStringContainsString('access_token', $envelope);
        self::assertStringContainsString('customer_name', $envelope);
    }
}
