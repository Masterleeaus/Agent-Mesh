<?php
use PHPUnit\Framework\TestCase;
final class TitanReachInboxBridgeStaticTest extends TestCase { public function test_bridge_exists(): void { self::assertFileExists(dirname(__DIR__).'/System/Support/TitanReachInboxBridge.php'); self::assertStringContainsString('titan-reach.inbox', file_get_contents(dirname(__DIR__).'/System/Support/TitanReachInboxBridge.php')); } }
