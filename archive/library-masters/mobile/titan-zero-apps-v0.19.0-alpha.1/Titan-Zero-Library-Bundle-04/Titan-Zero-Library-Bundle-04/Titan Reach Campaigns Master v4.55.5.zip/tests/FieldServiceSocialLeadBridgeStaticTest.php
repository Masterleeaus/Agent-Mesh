<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class FieldServiceSocialLeadBridgeStaticTest extends TestCase
{
    public function test_social_lead_bridge_is_standalone_safe(): void
    {
        $root = dirname(__DIR__);
        $bridge = file_get_contents($root . '/System/Services/FieldService/SharedFieldServiceSocialLeadEmitter.php');

        $this->assertStringContainsString('FieldServiceSocialLeadService', $bridge);
        $this->assertStringContainsString('local-fallback', $bridge);
        $this->assertStringContainsString('source_extension', $bridge);
        $this->assertStringContainsString('emitLead', $bridge);
    }
}
