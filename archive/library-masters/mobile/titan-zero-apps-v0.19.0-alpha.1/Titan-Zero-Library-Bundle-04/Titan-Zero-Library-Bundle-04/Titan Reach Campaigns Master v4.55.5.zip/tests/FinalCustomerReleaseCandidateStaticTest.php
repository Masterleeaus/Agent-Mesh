<?php

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;

final class FinalCustomerReleaseCandidateStaticTest extends TestCase
{
    public function testFinalCustomerReleaseCandidateArtifactsExist(): void
    {
        $root = dirname(__DIR__);
        self::assertFileExists($root . '/config/field-service-final-customer-release.php');
        self::assertFileExists($root . '/System/Support/FinalCustomerReleaseCandidate.php');
        self::assertFileExists($root . '/docs/STEP32_FINAL_CUSTOMER_RELEASE_CANDIDATE.md');
    }

    public function testSafetyControlsAreLockedForCustomerRelease(): void
    {
        $source = file_get_contents(dirname(__DIR__) . '/System/Support/FinalCustomerReleaseCandidate.php');
        self::assertIsString($source);
        self::assertStringContainsString('company_id_required', $source);
        self::assertStringContainsString('webhooks_fail_closed', $source);
        self::assertStringContainsString('ssrf_protection_enabled', $source);
        self::assertStringContainsString('publish_governance_enabled', $source);
        self::assertStringContainsString('commercial_tiers_do_not_disable_safety', $source);
        self::assertStringContainsString('demo_data_marked_demo_only', $source);
    }
}
