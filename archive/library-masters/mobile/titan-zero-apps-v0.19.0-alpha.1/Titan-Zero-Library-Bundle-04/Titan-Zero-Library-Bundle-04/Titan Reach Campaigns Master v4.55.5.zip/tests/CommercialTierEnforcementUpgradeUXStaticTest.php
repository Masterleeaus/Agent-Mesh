<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class CommercialTierEnforcementUpgradeUXStaticTest extends TestCase
{
    public function testCommercialEnforcementFilesDeclareSafePlanGates(): void
    {
        $root = dirname(__DIR__);
        $config = file_get_contents($root . '/config/field-service-commercial-enforcement.php');
        $support = file_get_contents($root . '/System/Support/CommercialTierEnforcementUpgradeUX.php');

        self::assertStringContainsString('safety_always_on', $config);
        self::assertStringContainsString('tenant_company_checks', $config);
        self::assertStringContainsString('webhook_signature_verification', $config);
        self::assertStringContainsString('publish_governance', $config);
        self::assertStringContainsString('upgrade_required', $support);
        self::assertStringContainsString('blocked_missing_company', $support);
        self::assertStringContainsString('redactForUpgradeUx', $support);
    }
}
