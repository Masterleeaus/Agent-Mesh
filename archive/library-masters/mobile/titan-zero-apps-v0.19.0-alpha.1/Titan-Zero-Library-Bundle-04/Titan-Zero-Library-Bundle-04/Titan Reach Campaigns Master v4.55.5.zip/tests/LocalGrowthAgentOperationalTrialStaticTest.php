<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Tests;

final class LocalGrowthAgentOperationalTrialStaticTest
{
    public function test_local_growth_operational_trial_requires_company_context_and_privacy(): void
    {
        $config = require dirname(__DIR__) . '/config/field-service-local-growth-operational-trial.php';

        assert(($config['mode'] ?? null) === 'dry_run');
        assert(($config['requires_company_id'] ?? false) === true);
        assert(in_array('privacy_guardrails_present', $config['checks'] ?? [], true));
        assert(in_array('event_emission_ready', $config['checks'] ?? [], true));
        assert(in_array('customer_name', $config['redacted_fields'] ?? [], true));
        assert(in_array('prices', $config['forbidden_inferences'] ?? [], true));
    }
}
