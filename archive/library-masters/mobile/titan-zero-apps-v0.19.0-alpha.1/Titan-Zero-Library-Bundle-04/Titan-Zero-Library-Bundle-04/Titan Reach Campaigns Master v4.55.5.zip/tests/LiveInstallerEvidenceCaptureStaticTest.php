<?php

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;

final class LiveInstallerEvidenceCaptureStaticTest extends TestCase
{
    public function testLiveInstallerEvidenceArtifactsExist(): void
    {
        $root = dirname(__DIR__);
        self::assertFileExists($root . '/config/field-service-live-install-evidence.php');
        self::assertFileExists($root . '/System/Support/LiveInstallerEvidenceCapture.php');
        self::assertFileExists($root . '/docs/STEP33_LIVE_INSTALLER_EVIDENCE_CAPTURE.md');
    }

    public function testEvidenceCaptureKeepsDiagnosticsSafeAndDecisionReady(): void
    {
        $source = file_get_contents(dirname(__DIR__) . '/System/Support/LiveInstallerEvidenceCapture.php');
        self::assertIsString($source);
        self::assertStringContainsString('REQUIRED_EVIDENCE', $source);
        self::assertStringContainsString('blocked_missing_evidence', $source);
        self::assertStringContainsString('needs_hotfix', $source);
        self::assertStringContainsString('evidence_ready', $source);
        self::assertStringContainsString('diagnostics_are_non_mutating', $source);
        self::assertStringContainsString('preserve_company_boundary', $source);
        self::assertStringContainsString('[redacted]', $source);
    }
}
