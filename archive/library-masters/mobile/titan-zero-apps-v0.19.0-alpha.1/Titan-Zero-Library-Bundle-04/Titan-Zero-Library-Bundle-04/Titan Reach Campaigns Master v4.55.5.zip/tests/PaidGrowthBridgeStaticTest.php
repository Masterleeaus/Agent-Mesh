<?php

declare(strict_types=1);
$root=dirname(__DIR__);
foreach (['config/titan-reach-paid-growth.php','System/Support/TitanReachPaidGrowthBridge.php'] as $file) { if(!is_file($root.'/'.$file)){fwrite(STDERR,"Missing $file\n");exit(1);} }
$code=file_get_contents($root.'/System/Support/TitanReachPaidGrowthBridge.php');
foreach (['company_id_required','automatic_activation','paid_growth_authority_unavailable'] as $token) { if(!str_contains($code,$token)){fwrite(STDERR,"Missing $token\n");exit(1);} }
echo "Paid growth bridge static gate PASS\n";
