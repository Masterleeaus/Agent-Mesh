<?php

use PHPUnit\Framework\TestCase;

final class ProductionHardeningReleaseStaticTest extends TestCase
{
    private string $root;

    protected function setUp(): void
    {
        $this->root = dirname(__DIR__);
    }

    public function testProductionReleaseMetadataIsPresent(): void
    {
        $this->assertFileExists($this->root . '/config/field-service-production.php');
        $config = file_get_contents($this->root . '/config/field-service-production.php');

        $this->assertStringContainsString("'step' => 16", $config);
        $this->assertStringContainsString('production-hardening-final', $config);
        $this->assertStringContainsString('requires_company_id', $config);
        $this->assertStringContainsString('externally_reachable_surfaces_fail_closed', $config);
        $this->assertStringContainsString('standalone_fallbacks_available', $config);
    }

    public function testSafeDefaultsRemainExplicitlyDisabled(): void
    {
        $config = file_get_contents($this->root . '/config/field-service-production.php');

        foreach ([
            'invent_licences',
            'invent_prices',
            'invent_emergency_availability',
            'invent_service_areas',
            'infer_customer_identity_from_media',
            'auto_publish_playbook_items',
        ] as $safeDefault) {
            $this->assertStringContainsString($safeDefault, $config);
        }

        $this->assertStringNotContainsString("'invent_licences' => true", $config);
        $this->assertStringNotContainsString("'invent_prices' => true", $config);
        $this->assertStringNotContainsString("'invent_emergency_availability' => true", $config);
        $this->assertStringNotContainsString("'auto_publish_playbook_items' => true", $config);
    }

    public function testFinalReleaseNotesArePresent(): void
    {
        $this->assertFileExists($this->root . '/docs/FIELD_SERVICE_FINAL_RELEASE.md');
        $notes = file_get_contents($this->root . '/docs/FIELD_SERVICE_FINAL_RELEASE.md');

        $this->assertStringContainsString('company_id', $notes);
        $this->assertStringContainsString('publishing authority', $notes);
        $this->assertStringContainsString('fail closed', $notes);
        $this->assertStringContainsString('never invents licences, prices, emergency availability', $notes);
    }
}
