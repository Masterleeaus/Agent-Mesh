<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class UnifiedFieldServiceWorkspaceStaticTest extends TestCase
{
    public function testUnifiedWorkspaceComponentsExist(): void
    {
        $root = dirname(__DIR__);

        $this->assertFileExists($root . '/System/Support/FieldServiceMarketingPermissionGate.php');
        $this->assertFileExists($root . '/System/Services/FieldService/FieldServiceWorkspaceNavigator.php');
        $this->assertFileExists($root . '/System/Services/FieldService/FieldServiceWorkspaceHealth.php');
        $this->assertFileExists($root . '/System/Http/Controllers/FieldServiceWorkspaceController.php');
        $this->assertFileExists($root . '/resources/views/field-service-workspace.blade.php');
    }

    public function testWorkspaceIsPermissionedCompanyScopedAndStandaloneSafe(): void
    {
        $root = dirname(__DIR__);
        $permissionGate = file_get_contents($root . '/System/Support/FieldServiceMarketingPermissionGate.php');
        $controller = file_get_contents($root . '/System/Http/Controllers/FieldServiceWorkspaceController.php');
        $health = file_get_contents($root . '/System/Services/FieldService/FieldServiceWorkspaceHealth.php');
        $navigator = file_get_contents($root . '/System/Services/FieldService/FieldServiceWorkspaceNavigator.php');

        $this->assertStringContainsString('field_service_marketing.view', $permissionGate);
        $this->assertStringContainsString('resolveCompanyId', $controller);
        $this->assertStringContainsString('company_id', $controller);
        $this->assertStringContainsString('standalone_safe', $health);
        $this->assertStringContainsString('field_marketing_hub', $navigator);
        $this->assertStringContainsString('local_growth_agent', $navigator);
        $this->assertStringContainsString('lead_review_automation', $navigator);
        $this->assertStringContainsString('campaign_playbooks', $navigator);
    }
}
