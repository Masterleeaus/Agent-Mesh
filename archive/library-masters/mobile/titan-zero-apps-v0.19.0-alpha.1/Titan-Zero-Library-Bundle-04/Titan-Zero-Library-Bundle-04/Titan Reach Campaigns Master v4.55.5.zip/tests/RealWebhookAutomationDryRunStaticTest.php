<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root . '/config/field-service-webhook-dry-run.php',
    $root . '/System/Support/RealWebhookAutomationDryRun.php',
    $root . '/docs/STEP28_REAL_WEBHOOK_AUTOMATION_DRY_RUN.md',
];

foreach ($required as $file) {
    if (! is_file($file)) {
        throw new RuntimeException('Missing Step 28 dry-run file: ' . $file);
    }
}

$config = require $root . '/config/field-service-webhook-dry-run.php';
if (($config['dry_run_only'] ?? false) !== true) {
    throw new RuntimeException('Step 28 dry-run config must be dry-run only.');
}
if (($config['provider_messages_enabled'] ?? true) !== false) {
    throw new RuntimeException('Step 28 dry-run must not send provider messages.');
}
if (($config['requires_company_id'] ?? false) !== true) {
    throw new RuntimeException('Step 28 dry-run must require company_id.');
}
if (($config['requires_signature_verification'] ?? false) !== true) {
    throw new RuntimeException('Step 28 dry-run must require signature verification.');
}

$source = file_get_contents($root . '/System/Support/RealWebhookAutomationDryRun.php') ?: '';
foreach (['missing_company_id', 'unsigned_or_unverified_webhook', 'replay_or_stale_webhook', 'would_send_provider_message', '[redacted]'] as $needle) {
    if (! str_contains($source, $needle)) {
        throw new RuntimeException('Step 28 dry-run source missing expected guard: ' . $needle);
    }
}
