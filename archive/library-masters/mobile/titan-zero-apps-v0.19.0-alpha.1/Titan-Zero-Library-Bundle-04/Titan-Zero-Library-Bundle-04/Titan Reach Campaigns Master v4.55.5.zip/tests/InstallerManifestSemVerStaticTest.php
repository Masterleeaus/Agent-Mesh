<?php

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;

final class InstallerManifestSemVerStaticTest extends TestCase
{
    public function test_extension_manifest_uses_strict_semver(): void
    {
        $manifest = json_decode((string) file_get_contents(__DIR__ . '/../extension.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('titan-extension-v1', $manifest['schema'] ?? null);
        self::assertMatchesRegularExpression('/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/', (string) ($manifest['version'] ?? ''));
        self::assertNotEmpty($manifest['folder'] ?? null);
        self::assertNotEmpty($manifest['provider'] ?? null);
    }
}
