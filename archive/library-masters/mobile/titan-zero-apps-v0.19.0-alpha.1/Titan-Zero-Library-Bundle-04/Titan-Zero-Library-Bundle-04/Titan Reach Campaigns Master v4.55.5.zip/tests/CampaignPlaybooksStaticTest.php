<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class CampaignPlaybooksStaticTest extends TestCase
{
    private function read(string $path): string
    {
        return file_get_contents(dirname(__DIR__) . '/' . $path) ?: '';
    }

    public function test_campaigns_is_planning_only(): void
    {
        $provider = $this->read('System/TitanReachCampaignsServiceProvider.php');
        self::assertStringContainsString('CampaignPlaybookController', $provider);
        self::assertStringNotContainsString('AutomationController', $provider);
        self::assertStringNotContainsString('GeneratePostDailyCommand', $provider);
        self::assertFileDoesNotExist(dirname(__DIR__) . '/System/Jobs/UserPostJob.php');
        self::assertFileDoesNotExist(dirname(__DIR__) . '/System/Services/AutomationService.php');
    }

    public function test_playbook_generator_is_company_scoped_and_pro_handoff_only(): void
    {
        $generator = $this->read('System/Services/FieldService/CampaignPlaybookGenerator.php');
        $model = $this->read('System/Models/CampaignPlaybookItem.php');
        self::assertStringContainsString("'company_id' => \$companyId", $generator);
        self::assertStringContainsString("'channel_hint' => 'handoff_to_titan_reach_pro'", $generator);
        self::assertStringContainsString("protected \$table = 'titan_reach_campaign_playbook_items'", $model);
        self::assertStringNotContainsString('automation_campaign_id', $model);
    }
}
