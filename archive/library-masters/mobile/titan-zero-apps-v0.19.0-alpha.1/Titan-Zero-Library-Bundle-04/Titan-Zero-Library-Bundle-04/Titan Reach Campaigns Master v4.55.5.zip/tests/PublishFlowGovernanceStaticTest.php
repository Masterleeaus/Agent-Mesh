<?php

declare(strict_types=1);

final class PublishFlowGovernanceStaticTest
{
    public function testStaticCoverage(): void
    {
        $root = dirname(__DIR__);
        $support = $root . '/System/Support/PublishFlowGovernance.php';
        $config = $root . '/config/field-service-publish-governance.php';

        assert(is_file($support), 'PublishFlowGovernance support class must exist.');
        assert(is_file($config), 'field-service-publish-governance config must exist.');

        $source = file_get_contents($support);
        assert(str_contains($source, 'company_id_required'), 'Publish governance must require company correlation.');
        assert(str_contains($source, 'STATE_PUBLISH_REQUESTED'), 'Publish governance must separate publish request from published.');
        assert(str_contains($source, 'approval_required'), 'Publish governance must support explicit approval blocking.');
        assert(str_contains($source, 'media_privacy_acknowledgement_required'), 'Publish governance must enforce media privacy acknowledgement.');
        assert(str_contains($source, 'emergency_claim_not_configured'), 'Publish governance must block unconfigured emergency claims.');
        assert(str_contains($source, 'licence_claim_not_configured'), 'Publish governance must block unconfigured licence claims.');
        assert(str_contains($source, 'price_claim_not_authorised'), 'Publish governance must block unauthorised price claims.');

        $configSource = file_get_contents($config);
        assert(str_contains($configSource, 'never_auto_publish_playbook_handoffs'), 'Playbook handoffs must never auto-publish.');
        assert(str_contains($configSource, 'field_service_marketing.publish'), 'Publish permission gate must be explicit.');
    }
}
