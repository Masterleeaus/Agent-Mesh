<?php

declare(strict_types=1);

$root = dirname(__DIR__);
foreach ([$root . '/config/titan-reach-distribution.php', $root . '/System/Support/TitanReachDistributionBridge.php'] as $file) { if (! is_file($file)) { fwrite(STDERR, "Missing distribution file: {$file}\n"); exit(1); } }
$config = require $root . '/config/titan-reach-distribution.php';
if (($config['policy']['company_id_required'] ?? false) !== true) { fwrite(STDERR, "Distribution policy must require company_id.\n"); exit(1); }
$destinations = $config['destinations'] ?? [];
foreach (['google_business_profile','meta_ads','google_local_services_ads','nextdoor','gumtree'] as $channel) { if (! array_key_exists($channel, $destinations)) { fwrite(STDERR, "Missing vital channel: {$channel}\n"); exit(1); } }
$bridge = file_get_contents($root . '/System/Support/TitanReachDistributionBridge.php');
foreach (['company_id_required','titan-reach.distribution.bridge'] as $needle) { if (! str_contains($bridge, $needle)) { fwrite(STDERR, "Bridge missing {$needle}.\n"); exit(1); } }
echo "Titan Reach distribution bridge static gate PASS\n";
