<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Tests;

use App\Extensions\TitanReachCampaigns\System\Support\DatabaseMigrationUpgradeCompatibility;

final class DatabaseMigrationUpgradeCompatibilityStaticTest
{
    public function testStep27MigrationCompatibilityIsNonDestructive(): void
    {
        $compatibility = new DatabaseMigrationUpgradeCompatibility();
        $checklist = $compatibility->checklist();
        $report = $compatibility->trialReport(['example_table' => ['id', 'company_id']]);

        assert($checklist['step'] === 27);
        assert($checklist['non_destructive_only'] === true);
        assert($checklist['requires_company_id_boundary'] === true);
        assert($report['fresh_install']['destructive_operations_allowed'] === false);
        assert($report['upgrade_install']['duplicate_column_replay_safe'] === true);
        assert($compatibility->classifyFailure('Duplicate column name company_id') === 'duplicate_schema_replay');
    }
}
