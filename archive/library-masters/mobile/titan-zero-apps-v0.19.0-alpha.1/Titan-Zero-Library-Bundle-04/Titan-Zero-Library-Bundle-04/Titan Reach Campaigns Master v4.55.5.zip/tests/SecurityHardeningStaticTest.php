<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class SecurityHardeningStaticTest extends TestCase
{
    private function read(string $path): string
    {
        return file_get_contents(dirname(__DIR__) . '/' . $path) ?: '';
    }

    public function test_campaign_routes_are_authenticated_and_non_destructive(): void
    {
        $provider = $this->read('System/TitanReachCampaignsServiceProvider.php');
        self::assertStringContainsString("'middleware' => ['web', 'auth']", $provider);
        self::assertStringContainsString("Route::post('', 'store')", $provider);
        self::assertStringNotContainsString("Route::get('disconnect", $provider);
        self::assertStringNotContainsString('Route::any(', $provider);
    }

    public function test_playbook_controller_requires_company_id(): void
    {
        $controller = $this->read('System/Http/Controllers/CampaignPlaybookController.php');
        self::assertStringContainsString("'company_id' => ['required', 'integer', 'min:1']", $controller);
        self::assertStringContainsString("->where('company_id', $companyId)", $controller);
    }
}
