<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    'config/titan-reach-local-distribution.php',
    'System/Support/TitanReachLocalDistributionBridge.php',
];
foreach ($required as $file) {
    if (!is_file($root.'/'.$file)) { fwrite(STDERR, "Missing $file\n"); exit(1); }
}
$cfg = file_get_contents($root.'/config/titan-reach-local-distribution.php');
foreach (['gumtree','facebook_marketplace','nextdoor','apple_business_connect','bing_places','hipages','oneflare'] as $token) {
    if (!str_contains($cfg, $token)) { fwrite(STDERR, "Missing destination $token\n"); exit(1); }
}
$bridge = file_get_contents($root.'/System/Support/TitanReachLocalDistributionBridge.php');
foreach (['company_id_required','manual_completion','assisted'] as $token) {
    if (!str_contains($bridge, $token)) { fwrite(STDERR, "Missing bridge policy $token\n"); exit(1); }
}
echo "Step 40 local distribution static gate PASS\n";
