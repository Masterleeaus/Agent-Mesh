<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$manifest = json_decode((string) file_get_contents($root . '/extension.json'), true);
assert(($manifest['version'] ?? null) === '4.55.5');
$menu = (string) file_get_contents($root . '/System/Navigation/TitanReachMenuDefinition.php');
assert(str_contains($menu, "'dashboard.user.titan-reach.campaigns.playbooks.index'"));
assert(str_contains($menu, "'/dashboard/user/titan-reach/campaigns/playbooks'"));
$installer = (string) file_get_contents($root . '/System/Navigation/TitanReachMenuInstaller.php');
assert(str_contains($installer, "route_slug"));
$workspace = (string) file_get_contents($root . '/resources/views/field-service-workspace.blade.php');
assert(str_contains($workspace, "@extends('panel.layout.app')"));
assert(str_contains($workspace, "@section('content')"));
