<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_reach_campaign_playbook_items')) {
            return;
        }
        Schema::create('titan_reach_campaign_playbook_items', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index('idx_company_id_d7472560');
            $table->unsignedBigInteger('actor_user_id')->nullable()->index('idx_actor_user_id_91e9a701');
            $table->string('playbook_key', 120)->index('idx_playbook_key_054642e9');
            $table->string('category', 120)->index('idx_category_5ac92eb2');
            $table->unsignedTinyInteger('duration_weeks')->default(1);
            $table->unsignedInteger('sequence')->default(1);
            $table->timestamp('planned_for')->nullable()->index('idx_planned_for_828d5aac');
            $table->string('channel_hint', 80)->nullable();
            $table->string('content_lane', 120)->nullable();
            $table->string('headline', 255)->nullable();
            $table->text('brief')->nullable();
            $table->string('cta', 255)->nullable();
            $table->string('status', 40)->default('planned')->index('idx_status_0415580c');
            $table->string('handoff_status', 40)->default('standalone_export')->index('idx_handoff_status_123acbed');
            $table->json('handoff_payload')->nullable();
            $table->json('standalone_export_payload')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_reach_campaign_playbook_items');
    }
};
