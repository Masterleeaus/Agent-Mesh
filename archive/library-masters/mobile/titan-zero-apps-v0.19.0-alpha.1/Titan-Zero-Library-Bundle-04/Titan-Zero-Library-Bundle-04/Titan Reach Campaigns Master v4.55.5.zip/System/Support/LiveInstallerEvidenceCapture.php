<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class LiveInstallerEvidenceCapture
{
    public const REQUIRED_EVIDENCE = [
        'install_id',
        'installer_stage',
        'installer_status',
        'package_sha256',
        'extension_version',
        'php_version',
        'laravel_version',
        'database_driver',
        'event_timeline',
        'redacted_error_summary',
    ];

    public const DECISION_STATES = [
        'evidence_ready',
        'needs_hotfix',
        'blocked_missing_evidence',
    ];

    /** @var array<string, mixed> */
    private array $config;

    /** @param array<string, mixed>|null $config */
    public function __construct(?array $config = null)
    {
        $this->config = $config ?? (function_exists('config') ? (array) config('field-service-live-install-evidence.' . self::class, []) : []);
    }

    /** @param array<string, mixed> $attempt @return array<string, mixed> */
    public function capture(array $attempt): array
    {
        $missing = [];
        foreach (self::REQUIRED_EVIDENCE as $key) {
            if (!array_key_exists($key, $attempt) || $attempt[$key] === null || $attempt[$key] === '') {
                $missing[] = $key;
            }
        }

        $stage = (string) ($attempt['installer_stage'] ?? 'unknown');
        $status = strtolower((string) ($attempt['installer_status'] ?? 'unknown'));
        $decision = $missing !== [] ? 'blocked_missing_evidence' : ($status === 'failed' || $status === 'error' ? 'needs_hotfix' : 'evidence_ready');

        return [
            'status' => $decision,
            'phase' => $this->config['phase'] ?? 'phase_4_live_install_production',
            'step' => $this->config['step'] ?? 33,
            'module_key' => $this->config['module_key'] ?? 'campaign_playbooks',
            'install_id' => (string) ($attempt['install_id'] ?? ''),
            'installer_stage' => $stage,
            'installer_status' => (string) ($attempt['installer_status'] ?? ''),
            'package_sha256' => (string) ($attempt['package_sha256'] ?? ''),
            'missing_evidence' => $missing,
            'release_decision_input' => $this->classify($stage, $status, $missing),
            'redacted_attempt' => $this->redact($attempt),
            'diagnostics_are_non_mutating' => true,
            'preserve_company_boundary' => true,
        ];
    }

    /** @param array<int, string> $missing */
    private function classify(string $stage, string $status, array $missing): string
    {
        if ($missing !== []) {
            return 'collect_missing_live_install_evidence';
        }
        if ($status === 'failed' || $status === 'error') {
            return match (true) {
                str_contains($stage, 'manifest') => 'hotfix_manifest_or_schema',
                str_contains($stage, 'migration') || str_contains($stage, 'database') => 'hotfix_migration_or_schema',
                str_contains($stage, 'route') => 'hotfix_route_registration',
                str_contains($stage, 'view') || str_contains($stage, 'blade') => 'hotfix_view_or_blade',
                str_contains($stage, 'autoload') || str_contains($stage, 'class') => 'hotfix_class_or_autoload',
                default => 'hotfix_unknown_install_failure',
            };
        }
        return 'candidate_ready_for_runtime_review';
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    private function redact(array $payload): array
    {
        $blocked = (array) ($this->config['redaction_keys'] ?? [
            'token', 'secret', 'signature', 'password', 'authorization', 'cookie',
            'customer_name', 'customer_handle', 'contact_value', 'external_customer_id',
            'raw_webhook_body', 'message_body', 'comment_text', 'stack_trace',
        ]);
        $redacted = [];
        foreach ($payload as $key => $value) {
            $normalised = strtolower((string) $key);
            if (in_array($normalised, $blocked, true)) {
                $redacted[$key] = '[redacted]';
                continue;
            }
            $redacted[$key] = is_array($value) ? $this->redact($value) : $value;
        }
        return $redacted;
    }
}
