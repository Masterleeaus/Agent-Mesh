<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Models;

use Illuminate\Database\Eloquent\Model;

class CampaignPlaybookItem extends Model
{
    protected $table = 'titan_reach_campaign_playbook_items';

    protected $fillable = [
        'company_id',
        'actor_user_id',
        'playbook_key',
        'category',
        'duration_weeks',
        'sequence',
        'planned_for',
        'channel_hint',
        'content_lane',
        'headline',
        'brief',
        'cta',
        'status',
        'handoff_status',
        'handoff_payload',
        'standalone_export_payload',
    ];

    protected $casts = [
        'handoff_payload' => 'array',
        'standalone_export_payload' => 'array',
        'planned_for' => 'datetime',
        'duration_weeks' => 'integer',
        'sequence' => 'integer',
    ];
}
