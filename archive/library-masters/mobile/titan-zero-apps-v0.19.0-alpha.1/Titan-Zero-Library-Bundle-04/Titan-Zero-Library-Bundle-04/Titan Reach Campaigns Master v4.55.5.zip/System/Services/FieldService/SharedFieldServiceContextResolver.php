<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

class SharedFieldServiceContextResolver
{
    private const PRO_CONTRACT = 'App\\Extensions\\TitanReach\\System\\Contracts\\FieldServiceContextProvider';

    /**
     * Resolve the shared field-service marketing context without hard-coupling this
     * extension to Titan Reach Pro. When the Pro contract is installed and bound,
     * this adapter returns the exact normalized context it provides. Otherwise it
     * returns conservative standalone defaults and never invents business claims.
     */
    public function resolve(?int $companyId = null, ?int $userId = null): array
    {
        $companyId ??= $this->resolveCompanyId($userId);

        if (class_exists(self::PRO_CONTRACT) && app()->bound(self::PRO_CONTRACT)) {
            $context = app(self::PRO_CONTRACT)->resolve($companyId, $userId);

            if (is_object($context) && method_exists($context, 'toArray')) {
                return $context->toArray();
            }
        }

        return $this->standaloneDefault($companyId);
    }

    private function standaloneDefault(?int $companyId): array
    {
        return [
            'company_id'                  => $companyId,
            'profile_id'                  => null,
            'business_name'               => null,
            'vertical'                    => null,
            'services'                    => [],
            'service_areas'               => [],
            'hours'                       => [],
            'emergency_available'         => false,
            'contact_channels'            => [],
            'quote_url'                   => null,
            'booking_url'                 => null,
            'review_url'                  => null,
            'licence_trust_statements'    => [],
            'seasonal_services'           => [],
            'brand_voice'                 => 'Clear, practical and helpful. Avoid claims that have not been explicitly supplied.',
            'privacy_defaults'            => [
                'include_customer_names'     => false,
                'include_exact_addresses'    => false,
                'include_faces'              => false,
                'include_vehicle_plates'     => false,
                'include_before_after_media' => false,
                'require_human_review'       => true,
            ],
            'completeness_score'          => 0,
            'missing_fields'              => ['business_name', 'vertical', 'services', 'service_areas', 'contact_channels'],
            'standalone_fallback'         => true,
        ];
    }

    private function resolveCompanyId(?int $userId): ?int
    {
        $user = auth()->user();

        if (! $user && $userId && class_exists('App\\Models\\User')) {
            $user = app('App\\Models\\User')::query()->find($userId);
        }

        if (! $user) {
            return null;
        }

        foreach (['company_id', 'current_company_id'] as $field) {
            if (isset($user->{$field}) && $user->{$field}) {
                return (int) $user->{$field};
            }
        }

        return null;
    }
}
