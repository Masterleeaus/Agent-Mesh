<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class CommercialTierEnforcementUpgradeUX
{
    public const SAFETY_ALWAYS_ON = [
        'tenant_company_checks',
        'webhook_signature_verification',
        'replay_protection',
        'payload_redaction',
        'job_media_privacy',
        'media_consent_controls',
        'publish_governance',
        'ssrf_protection',
        'csrf_protection',
        'destructive_mutation_verbs',
    ];

    /** @var array<string, mixed> */
    private array $config;

    /**
     * @param array<string, mixed>|null $config
     */
    public function __construct(?array $config = null)
    {
        $this->config = $config ?? (function_exists('config') ? (array) config('field-service-commercial-enforcement.' . self::class, []) : []);
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function evaluate(string $plan, string $feature, array $context = []): array
    {
        $plan = $this->normalisePlan($plan);
        $feature = $this->normaliseFeature($feature);

        if (in_array($feature, self::SAFETY_ALWAYS_ON, true)) {
            return [
                'allowed' => true,
                'status' => 'safety_always_available',
                'plan' => $plan,
                'feature' => $feature,
                'message' => 'This safety control is always enabled and cannot be disabled by plan limits.',
            ];
        }

        if (empty($context['company_id'])) {
            return [
                'allowed' => false,
                'status' => 'blocked_missing_company',
                'plan' => $plan,
                'feature' => $feature,
                'message' => 'A company context is required before field-service social features can run.',
            ];
        }

        $allowedFeatures = $this->featuresForPlan($plan);
        if (in_array($feature, $allowedFeatures, true)) {
            return [
                'allowed' => true,
                'status' => 'allowed',
                'plan' => $plan,
                'feature' => $feature,
                'message' => 'Feature is available for the current plan.',
            ];
        }

        return [
            'allowed' => false,
            'status' => 'upgrade_required',
            'plan' => $plan,
            'feature' => $feature,
            'message' => $this->upgradeMessage($feature),
            'recommended_plan' => $this->recommendedPlanFor($feature),
        ];
    }

    /**
     * @return list<string>
     */
    public function featuresForPlan(string $plan): array
    {
        $plans = (array) ($this->config['plans'] ?? []);
        $selected = (array) ($plans[$this->normalisePlan($plan)] ?? $plans['starter'] ?? []);

        return array_values(array_unique(array_map(
            fn ($feature) => $this->normaliseFeature((string) $feature),
            (array) ($selected['features'] ?? [])
        )));
    }

    public function upgradeMessage(string $feature): string
    {
        $feature = $this->normaliseFeature($feature);
        $copy = (array) ($this->config['upgrade_copy'] ?? []);

        return (string) ($copy[$feature] ?? 'Upgrade your field-service social plan to unlock this feature.');
    }

    public function recommendedPlanFor(string $feature): string
    {
        $feature = $this->normaliseFeature($feature);
        $plans = (array) ($this->config['plans'] ?? []);

        foreach ($plans as $plan => $definition) {
            $features = array_map(fn ($value) => $this->normaliseFeature((string) $value), (array) ($definition['features'] ?? []));
            if (in_array($feature, $features, true)) {
                return (string) $plan;
            }
        }

        return 'pro';
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function redactForUpgradeUx(array $payload): array
    {
        $redacted = [];
        foreach ($payload as $key => $value) {
            $normalisedKey = strtolower((string) $key);
            if (preg_match('/token|secret|signature|customer|contact|handle|external_id|raw|body|message|comment/', $normalisedKey)) {
                $redacted[$key] = '[redacted]';
                continue;
            }
            $redacted[$key] = is_array($value) ? $this->redactForUpgradeUx($value) : $value;
        }

        return $redacted;
    }

    private function normalisePlan(string $plan): string
    {
        $plan = strtolower(trim($plan));
        return $plan !== '' ? $plan : (string) ($this->config['default_plan'] ?? 'starter');
    }

    private function normaliseFeature(string $feature): string
    {
        return strtolower(trim(str_replace(['-', ' '], '_', $feature)));
    }
}
