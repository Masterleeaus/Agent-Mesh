<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class LocalGrowthAgentOperationalTrial
{
    /** @var array<string, mixed> */
    private array $config;

    /**
     * @param array<string, mixed>|null $config
     */
    public function __construct(?array $config = null)
    {
        $this->config = $config ?? require dirname(__DIR__, 2) . '/config/field-service-local-growth-operational-trial.php';
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function run(array $payload): array
    {
        $companyId = $payload['company_id'] ?? null;
        $blocked = [];

        if (empty($companyId)) {
            $blocked[] = 'company_id_required';
        }

        if (($payload['context_resolved'] ?? false) !== true) {
            $blocked[] = 'field_service_context_required';
        }

        if (($payload['privacy_guardrails_present'] ?? false) !== true) {
            $blocked[] = 'privacy_guardrails_required';
        }

        $signals = $this->normaliseSignals($payload['growth_signals'] ?? []);
        if ($signals === []) {
            $signals[] = 'safe_local_authority';
        }

        $aiReady = ($payload['ai_provider_ready'] ?? false) === true;

        return [
            'mode' => 'dry_run',
            'module' => $this->config['module'] ?? 'unknown',
            'company_id' => $companyId,
            'status' => $blocked === [] ? 'ready' : 'blocked',
            'blocked_reasons' => $blocked,
            'checks' => [
                'context_resolved' => $blocked === [] || ! in_array('field_service_context_required', $blocked, true),
                'growth_signal_selected' => $signals !== [],
                'ai_provider_ready_or_safe_fallback' => $aiReady || ($payload['allow_safe_fallback'] ?? true) === true,
                'privacy_guardrails_present' => ! in_array('privacy_guardrails_required', $blocked, true),
                'draft_plan_created' => $blocked === [],
                'publish_governance_respected' => true,
                'event_emission_ready' => $blocked === [],
                'standalone_fallback_ready' => true,
            ],
            'selected_growth_signals' => $signals,
            'draft_plan' => $blocked === [] ? $this->buildDraftPlan($signals) : [],
            'redacted_payload' => $this->redact($payload),
        ];
    }

    /** @param mixed $signals @return array<int, string> */
    private function normaliseSignals(mixed $signals): array
    {
        if (! is_array($signals)) { return []; }
        return array_values(array_filter(array_map(static fn ($signal): string => strtolower(trim((string) $signal)), $signals)));
    }

    /** @param array<int, string> $signals @return array<int, array<string, string>> */
    private function buildDraftPlan(array $signals): array
    {
        return array_map(static fn (string $signal): array => [
            'signal' => $signal,
            'action' => 'prepare_reviewable_local_growth_draft',
            'publishing' => 'requires_governed_review_before_publish',
        ], $signals);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function redact(array $payload): array
    {
        $redacted = [];
        $blocked = array_map('strtolower', $this->config['redacted_fields'] ?? []);
        foreach ($payload as $key => $value) {
            $normalisedKey = strtolower((string) $key);
            $redacted[$key] = in_array($normalisedKey, $blocked, true) ? '[redacted]' : $value;
        }
        return $redacted;
    }
}
