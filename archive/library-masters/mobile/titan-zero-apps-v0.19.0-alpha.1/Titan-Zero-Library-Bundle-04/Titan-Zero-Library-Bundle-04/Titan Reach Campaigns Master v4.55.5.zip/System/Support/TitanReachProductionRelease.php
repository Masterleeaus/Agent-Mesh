<?php

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class TitanReachProductionRelease
{
    public function summary(): array
    {
        return [
            'release' => 'step-44-production',
            'company_boundary' => 'company_id',
            'host_bridge' => TitanZeroClosedLoopBridge::class,
            'legacy_placeholder_integrations_removed' => true,
        ];
    }
}
