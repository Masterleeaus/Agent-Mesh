<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

use App\Extensions\TitanReachCampaigns\System\Support\FieldServiceMarketingPermissionGate;

class FieldServiceWorkspaceNavigator
{
    public function __construct(private readonly FieldServiceMarketingPermissionGate $permissions)
    {
    }

    public function module(): array
    {
        return [
            'key' => 'campaign_playbooks',
            'label' => 'Campaign Playbooks',
            'role' => 'Campaign planning engine',
            'workspace' => 'field_home_services_social_marketing',
        ];
    }

    public function links(?object $user = null, ?int $companyId = null): array
    {
        $links = [
            ['label' => 'Campaign Workspace', 'path' => '/dashboard/user/titan-reach/campaigns/workspace', 'action' => 'view'],
            ['label' => 'Playbooks', 'path' => '/dashboard/user/titan-reach/campaigns/playbooks', 'action' => 'campaigns'],
        ];

        return array_map(function (array $link) use ($user, $companyId): array {
            $link['enabled'] = $this->permissions->allows($user, $link['action'], $companyId);
            $link['permission'] = $this->permissions->abilityFor($link['action']);

            return $link;
        }, $links);
    }

    public function crossExtensionLinks(): array
    {
        return [
            ['module' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'binding' => 'titan-reach.field-service.context'],
            ['module' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'binding' => 'titan-reach-agent.field-service.context'],
            ['module' => 'lead_review_automation', 'label' => 'Lead & Review Automation', 'binding' => 'titan-reach-flow.field-service.context'],
            ['module' => 'campaign_playbooks', 'label' => 'Campaign Playbooks', 'binding' => 'titan-reach-campaigns.field-service.context'],
        ];
    }
}
