<?php

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class FieldServiceCommercialPlanLimits
{
    /**
     * Resolve a safe commercial plan payload for UI, guards and optional host adapters.
     * This helper never disables security/privacy controls, even when a paid feature is unavailable.
     */
    public function describe(?string $plan = null): array
    {
        $plan = $this->normalisePlan($plan ?? 'free');
        $config = config('field-service-commercial.' . self::class, []);

        return [
            'plan' => $plan,
            'limits' => $this->limitsFor($plan, $config),
            'features' => $this->featuresFor($plan, $config),
            'safe_unavailable_message' => data_get(
                $config,
                'commercial_safety.safe_unavailable_message',
                'This field-service marketing feature is not available on the current plan.'
            ),
            'security_controls_locked' => true,
            'privacy_controls_locked' => true,
            'platform_ai_default_enabled' => false,
        ];
    }

    public function allows(string $feature, ?string $plan = null): bool
    {
        $plan = $this->normalisePlan($plan ?? 'free');
        $config = config('field-service-commercial.' . self::class, []);
        $required = data_get($config, 'feature_flags.' . $feature, false);

        if ($required === true) {
            return true;
        }

        if ($required === false || $required === null) {
            return false;
        }

        return $this->planRank($plan) >= $this->planRank((string) $required);
    }

    public function assertAllowed(string $feature, ?string $plan = null): array
    {
        if ($this->allows($feature, $plan)) {
            return ['allowed' => true, 'message' => null];
        }

        $description = $this->describe($plan);

        return [
            'allowed' => false,
            'message' => $description['safe_unavailable_message'],
        ];
    }

    private function limitsFor(string $plan, array $config): array
    {
        $free = data_get($config, 'free_plan', []);

        if ($plan === 'free') {
            return $free;
        }

        if ($plan === 'growth') {
            return array_merge($free, [
                'monthly_ai_drafts' => 100,
                'monthly_titan_reach_campaign_scheduled_posts' => 250,
                'monthly_automation_runs' => 1000,
                'connected_social_accounts' => 8,
                'active_campaign_playbooks' => 12,
                'lead_capture_retention_days' => 180,
            ]);
        }

        return array_merge($free, [
            'monthly_ai_drafts' => 1000,
            'monthly_titan_reach_campaign_scheduled_posts' => 2000,
            'monthly_automation_runs' => 10000,
            'connected_social_accounts' => 25,
            'active_campaign_playbooks' => 100,
            'lead_capture_retention_days' => 730,
        ]);
    }

    private function featuresFor(string $plan, array $config): array
    {
        $features = [];
        foreach ((array) data_get($config, 'feature_flags', []) as $feature => $required) {
            if ($required === true || ($required !== false && $this->planRank($plan) >= $this->planRank((string) $required))) {
                $features[] = $feature;
            }
        }

        return $features;
    }

    private function normalisePlan(string $plan): string
    {
        return in_array($plan, ['free', 'growth', 'pro'], true) ? $plan : 'free';
    }

    private function planRank(string $plan): int
    {
        return match ($plan) {
            'pro' => 3,
            'growth' => 2,
            default => 1,
        };
    }
}
