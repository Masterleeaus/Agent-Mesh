<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Support;

/**
 * Step 26 live-runtime repair map for menus, route names and Blade views.
 *
 * This helper is framework-light on purpose: it can run in static ZIP
 * verification, post-install diagnostics, and live boot checks before a user
 * opens a broken menu link. Browser links must be disabled rather than broken
 * when another social-stack extension is absent.
 */
final class RuntimeMenuRouteBladeRepair
{
    public const VERSION = '4.33';
    public const EXTENSION_KEY = 'titan-reach-campaigns';
    public const MODULE_SLUG = 'campaign_playbooks';
    public const MODULE_LABEL = 'Campaign Playbooks';

    /** @return array<string, mixed> */
    public static function manifest(): array
    {
        return [
            'version' => self::VERSION,
            'extension_key' => self::EXTENSION_KEY,
            'module_slug' => self::MODULE_SLUG,
            'module_label' => self::MODULE_LABEL,
            'role' => 'Field-service campaign planning and Pro handoff without direct publishing authority',
            'route_names' => self::routeNames(),
            'view_paths' => self::viewPaths(),
            'controller_paths' => self::controllerPaths(),
            'safe_route_resolution' => true,
            'safe_blade_includes' => true,
            'missing_module_mode' => 'disabled_link',
            'company_scoped' => true,
        ];
    }

    /** @return array<int, string> */
    public static function routeNames(): array
    {
        return [
            'dashboard.user.titan-reach.campaigns.workspace',
            'dashboard.user.titan-reach.campaigns.playbooks.index',
            'dashboard.user.titan-reach.campaigns.playbooks.store',
            'dashboard.user.titan-reach.campaigns.playbooks.export',
                            ];
    }

    /** @return array<int, string> */
    public static function viewPaths(): array
    {
        return [
            'resources/views/field-service-workspace.blade.php',
                        'resources/views/playbooks/index.blade.php',
                            ];
    }

    /** @return array<int, string> */
    public static function controllerPaths(): array
    {
        return [
            'System/Http/Controllers/FieldServiceWorkspaceController.php',
            'System/Http/Controllers/CampaignPlaybookController.php',
                ];
    }

    /** @return array<int, array<string, mixed>> */
    public static function navigationModules(): array
    {
        return [
            ['slug' => 'field_marketing_hub', 'label' => 'Field Marketing Hub', 'route' => 'dashboard.user.titan-reach.field-service-workspace', 'path' => 'dashboard/user/titan-reach/field-service-workspace'],
            ['slug' => 'local_growth_agent', 'label' => 'Local Growth Agent', 'route' => 'dashboard.user.titan-reach.agent.field-service-workspace', 'path' => 'dashboard/user/titan-reach/agent/field-service-workspace'],
            ['slug' => 'lead_review_automation', 'label' => 'Lead & Review Automation', 'route' => 'dashboard.user.titan-reach.automation.field-service-workspace', 'path' => 'dashboard/user/titan-reach/automation/field-service-workspace'],
            ['slug' => 'campaign_playbooks', 'label' => 'Campaign Playbooks', 'route' => 'dashboard.user.titan-reach.campaigns.workspace', 'path' => 'dashboard/user/titan-reach/campaigns/workspace'],
        ];
    }

    /**
     * @param string $extensionRoot absolute extension root.
     * @return array<int, array<string, string|bool>>
     */
    public static function filesystemChecks(string $extensionRoot): array
    {
        $root = rtrim($extensionRoot, DIRECTORY_SEPARATOR);
        $required = array_values(array_unique(array_merge(
            ['extension.json', 'README.md', 'config/field-service-runtime-repair.php', 'resources/views/field-service-workspace.blade.php'],
            self::viewPaths(),
            self::controllerPaths()
        )));

        return array_map(static function (string $path) use ($root): array {
            $absolute = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);
            return [
                'path' => $path,
                'ok' => is_file($absolute),
                'message' => is_file($absolute) ? 'present' : 'missing runtime menu/route/blade dependency',
            ];
        }, $required);
    }

    /**
     * @param array<int, string> $availableRoutes routes known to the host/router.
     * @return array<int, array<string, mixed>>
     */
    public static function resolvedNavigation(array $availableRoutes = []): array
    {
        $routeSet = array_flip($availableRoutes);
        return array_map(static function (array $module) use ($routeSet): array {
            $route = (string) $module['route'];
            $available = $availableRoutes === [] || isset($routeSet[$route]);
            return [
                'slug' => $module['slug'],
                'label' => $module['label'],
                'route' => $route,
                'path' => $module['path'],
                'available' => $available,
                'mode' => $available ? 'route' : 'disabled_link',
            ];
        }, self::navigationModules());
    }
}
