<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Http\Controllers;

use App\Extensions\TitanReachCampaigns\System\Models\CampaignPlaybookItem;
use App\Extensions\TitanReachCampaigns\System\Services\FieldService\CampaignPlaybookCatalog;
use App\Extensions\TitanReachCampaigns\System\Services\FieldService\CampaignPlaybookGenerator;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class CampaignPlaybookController extends Controller
{
    public function __construct(
        private readonly CampaignPlaybookCatalog $catalog = new CampaignPlaybookCatalog(),
        private readonly CampaignPlaybookGenerator $generator = new CampaignPlaybookGenerator(),
    ) {}

    public function index(Request $request): View
    {
        $companyId = $this->companyId($request);
        $items = CampaignPlaybookItem::query()
            ->where('company_id', $companyId)
            ->orderBy('planned_for')
            ->orderBy('sequence')
            ->paginate(25);

        return view('titan-reach-campaigns::playbooks.index', [
            'items' => $items,
            'categories' => $this->catalog->categories(),
            'durations' => $this->catalog->durations(),
            'publishingAuthority' => 'Titan Reach Pro',
            'companyId' => $companyId,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'campaign_name' => ['nullable', 'string', 'max:255'],
            'category' => ['required', 'string'],
            'duration_weeks' => ['required', 'integer', 'in:1,2,4,12'],
            'topics' => ['nullable', 'array'],
            'topics.*' => ['string', 'max:120'],
            'start_date' => ['nullable', 'date'],
        ]);

        $items = $this->generator->generate([
            ...$validated,
            'actor_user_id' => auth()->id(),
        ]);

        return response()->json([
            'status' => 'planned',
            'publishing_authority' => 'titan_reach_pro',
            'items_created' => count($items),
            'items' => array_map(static fn (CampaignPlaybookItem $item): array => [
                'id' => $item->id,
                'category' => $item->category,
                'duration_weeks' => $item->duration_weeks,
                'sequence' => $item->sequence,
                'planned_for' => optional($item->planned_for)->toDateTimeString(),
                'handoff_status' => $item->handoff_status,
            ], $items),
        ]);
    }

    public function export(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);
        $items = CampaignPlaybookItem::query()
            ->where('company_id', $companyId)
            ->whereIn('handoff_status', ['standalone_export', 'pro_available_pending_publish_queue'])
            ->orderBy('planned_for')
            ->get();

        return response()->json([
            'source_extension' => 'titan-reach-campaigns',
            'publishing_authority' => 'titan_reach_pro',
            'standalone_safe' => true,
            'items' => $items->map(fn (CampaignPlaybookItem $item): array => [
                'id' => $item->id,
                'company_id' => $item->company_id,
                'category' => $item->category,
                'playbook_key' => $item->playbook_key,
                'planned_for' => optional($item->planned_for)->toIso8601String(),
                'headline' => $item->headline,
                'brief' => $item->brief,
                'cta' => $item->cta,
                'handoff_status' => $item->handoff_status,
            ])->values()->all(),
        ]);
    }

    private function companyId(Request $request): int
    {
        $validated = $request->validate(['company_id' => ['required', 'integer', 'min:1']]);
        return (int) $validated['company_id'];
    }
}
