<?php

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

use Illuminate\Support\Facades\Log;
use Throwable;

class SharedFieldServiceSocialLeadEmitter
{
    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function emitLead(array $payload): array
    {
        $payload['source_extension'] = $payload['source_extension'] ?? 'titan-reach-campaigns-legacy';

        if (class_exists('App\Extensions\TitanReachFlow\System\Services\FieldService\FieldServiceSocialLeadService')) {
            try {
                $lead = app('App\Extensions\TitanReachFlow\System\Services\FieldService\FieldServiceSocialLeadService')->fromExternalPayload($payload);

                return [
                    'status' => 'emitted',
                    'provider' => 'titan-reach-flow',
                    'lead_id' => $lead->id ?? null,
                ];
            } catch (Throwable $exception) {
                Log::warning('field_service_social_lead_emit_failed', [
                    'source_extension' => $payload['source_extension'] ?? static::class,
                    'event_type' => $payload['event_type'] ?? 'lead',
                ]);
            }
        }

        return [
            'status' => 'standalone',
            'provider' => 'local-fallback',
            'event_type' => $payload['event_type'] ?? 'lead',
        ];
    }
}
