<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Http\Controllers;

use App\Extensions\TitanReachCampaigns\System\Services\FieldService\FieldServiceWorkspaceHealth;
use App\Extensions\TitanReachCampaigns\System\Services\FieldService\FieldServiceWorkspaceNavigator;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class FieldServiceWorkspaceController
{
    public function __construct(
        private readonly FieldServiceWorkspaceNavigator $navigator,
        private readonly FieldServiceWorkspaceHealth $health,
    ) {
    }

    public function __invoke(Request $request): View
    {
        $user = $request->user();
        $companyId = $this->resolveCompanyId($request);

        return view('titan-reach-campaigns::field-service-workspace', [
            'module' => $this->navigator->module(),
            'links' => $this->navigator->links($user, $companyId),
            'crossExtensionLinks' => $this->navigator->crossExtensionLinks(),
            'health' => $this->health->snapshot(),
            'companyId' => $companyId,
        ]);
    }

    private function resolveCompanyId(Request $request): ?int
    {
        $user = $request->user();
        $companyId = $request->integer('company_id') ?: null;

        if ($companyId) {
            return $companyId;
        }

        foreach (['company_id', 'current_company_id', 'active_company_id'] as $attribute) {
            if ($user && isset($user->{$attribute}) && is_numeric($user->{$attribute})) {
                return (int) $user->{$attribute};
            }
        }

        return null;
    }
}
