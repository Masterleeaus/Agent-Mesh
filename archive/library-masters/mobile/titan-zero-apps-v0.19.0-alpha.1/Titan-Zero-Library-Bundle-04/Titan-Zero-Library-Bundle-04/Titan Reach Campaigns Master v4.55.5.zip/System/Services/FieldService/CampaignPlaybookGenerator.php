<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

use App\Extensions\TitanReachCampaigns\System\Models\CampaignPlaybookItem;
use Carbon\CarbonImmutable;
use InvalidArgumentException;

final class CampaignPlaybookGenerator
{
    public function __construct(
        private readonly CampaignPlaybookCatalog $catalog = new CampaignPlaybookCatalog(),
        private readonly CampaignPlaybookProHandoffEmitter $handoff = new CampaignPlaybookProHandoffEmitter(),
    ) {}

    public function generate(array $input): array
    {
        $companyId = (int) ($input['company_id'] ?? 0);
        if ($companyId < 1) {
            throw new InvalidArgumentException('company_id is required.');
        }

        $durationWeeks = (int) ($input['duration_weeks'] ?? 1);
        $category = (string) ($input['category'] ?? 'seasonal_service_campaign');
        if (! $this->catalog->isValidDuration($durationWeeks)) {
            throw new InvalidArgumentException('Unsupported campaign playbook duration.');
        }
        if (! $this->catalog->isValidCategory($category)) {
            throw new InvalidArgumentException('Unsupported campaign playbook category.');
        }

        $campaignName = trim((string) ($input['campaign_name'] ?? 'Field-service campaign playbook')) ?: 'Field-service campaign playbook';
        $topics = array_values(array_filter((array) ($input['topics'] ?? [])));
        $lanes = $this->catalog->defaultContentLanes($category);
        $start = CarbonImmutable::parse($input['start_date'] ?? now());
        $items = [];
        $totalItems = max(3, $durationWeeks * 3);

        for ($i = 0; $i < $totalItems; $i++) {
            $sequence = $i + 1;
            $lane = $lanes[$i % count($lanes)];
            $topic = $topics[$i % max(1, count($topics))] ?? $this->catalog->categories()[$category];

            $item = CampaignPlaybookItem::query()->create([
                'company_id' => $companyId,
                'actor_user_id' => isset($input['actor_user_id']) ? (int) $input['actor_user_id'] : null,
                'playbook_key' => $category . '-' . $durationWeeks . 'w',
                'category' => $category,
                'duration_weeks' => $durationWeeks,
                'sequence' => $sequence,
                'planned_for' => $start->addDays($i * 2)->toDateTimeString(),
                'channel_hint' => 'handoff_to_titan_reach_pro',
                'content_lane' => $lane,
                'headline' => $this->headline($campaignName, $lane, $sequence),
                'brief' => $this->brief($topic, $lane),
                'cta' => $this->cta($category),
                'status' => 'planned',
                'handoff_status' => 'pending',
            ]);

            $this->handoff->emit($item);
            $items[] = $item;
        }
        return $items;
    }

    private function headline(string $campaignName, string $lane, int $sequence): string
    {
        return $campaignName . ' — playbook item ' . $sequence . ' (' . str_replace('_', ' ', $lane) . ')';
    }

    private function brief(string $topic, string $lane): string
    {
        return 'Plan a field-service post for ' . $topic . ' using the ' . str_replace('_', ' ', $lane) . ' lane. Use only configured services, service areas, trust statements and URLs.';
    }

    private function cta(string $category): string
    {
        return match ($category) {
            'review_generation_campaign' => 'Use the configured review URL only when present.',
            'quiet_week_schedule_filler' => 'Promote real available capacity without inventing dates or prices.',
            'emergency_readiness_campaign' => 'Mention emergency support only when explicitly enabled in the field-service profile.',
            default => 'Use the configured quote or booking URL when present.',
        };
    }
}
