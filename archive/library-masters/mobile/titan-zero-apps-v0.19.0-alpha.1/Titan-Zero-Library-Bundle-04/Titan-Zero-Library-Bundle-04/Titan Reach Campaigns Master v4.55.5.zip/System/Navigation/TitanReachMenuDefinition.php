<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Navigation;

final class TitanReachMenuDefinition
{
    public static function root(): array
    {
        return [
            'key' => 'ext_titan_reach',
            'label' => 'Marketing & Advertising',
            'route' => null,
            'icon' => 'tabler-speakerphone',
            'order' => 8,
        ];
    }

    public static function item(): array
    {
        return [
            'key' => 'titan_reach_campaigns',
            'label' => 'Campaigns',
            'route' => 'dashboard.user.titan-reach.campaigns.playbooks.index',
            'route_slug' => '/dashboard/user/titan-reach/campaigns/playbooks',
            'icon' => 'tabler-calendar-event',
            'order' => 4,
        ];
    }
}
