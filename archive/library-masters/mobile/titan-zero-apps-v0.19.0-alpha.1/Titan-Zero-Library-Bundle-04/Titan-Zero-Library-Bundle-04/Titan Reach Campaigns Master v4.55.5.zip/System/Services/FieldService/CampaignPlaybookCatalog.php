<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

final class CampaignPlaybookCatalog
{
    public const DURATIONS = [1, 2, 4, 12];

    public const CATEGORIES = [
        'seasonal_service_campaign' => 'Seasonal service campaign',
        'quiet_week_schedule_filler' => 'Quiet-week schedule filler',
        'emergency_readiness_campaign' => 'Emergency readiness campaign',
        'recurring_maintenance_campaign' => 'Recurring maintenance campaign',
        'lapsed_customer_reactivation' => 'Lapsed-customer reactivation',
        'neighbourhood_route_density_campaign' => 'Neighbourhood route-density campaign',
        'review_generation_campaign' => 'Review generation campaign',
        'trust_licence_insurance_campaign' => 'Trust/licence/insurance campaign',
    ];

    public function durations(): array
    {
        return self::DURATIONS;
    }

    public function categories(): array
    {
        return self::CATEGORIES;
    }

    public function isValidDuration(int $weeks): bool
    {
        return in_array($weeks, self::DURATIONS, true);
    }

    public function isValidCategory(string $category): bool
    {
        return array_key_exists($category, self::CATEGORIES);
    }

    public function verticalDefaults(?string $vertical): array
    {
        $pack = (new FieldServiceVerticalPackCatalog())->resolve((string) $vertical);

        return [
            'vertical' => $pack['label'],
            'categories' => array_values($pack['playbook_defaults']),
            'lanes' => array_values($pack['safe_content_lanes']),
            'seasonal_themes' => array_values($pack['seasonal_themes']),
            'forbidden_claims' => array_values($pack['forbidden_claims']),
        ];
    }

    public function defaultContentLanes(string $category): array
    {
        return match ($category) {
            'quiet_week_schedule_filler' => ['local_availability', 'schedule_opening', 'maintenance_tip'],
            'emergency_readiness_campaign' => ['preparedness_tip', 'emergency_disclaimer', 'safe_contact_channel'],
            'recurring_maintenance_campaign' => ['maintenance_reminder', 'service_spotlight', 'booking_cta'],
            'lapsed_customer_reactivation' => ['reactivation_prompt', 'seasonal_checkup', 'review_builder'],
            'neighbourhood_route_density_campaign' => ['local_availability', 'completed_job_generalised', 'route_density_cta'],
            'review_generation_campaign' => ['review_request', 'testimonial_prompt', 'trust_builder'],
            'trust_licence_insurance_campaign' => ['trust_builder', 'licence_statement_if_configured', 'proof_without_claims'],
            default => ['seasonal_reminder', 'service_spotlight', 'quote_cta'],
        };
    }
}
