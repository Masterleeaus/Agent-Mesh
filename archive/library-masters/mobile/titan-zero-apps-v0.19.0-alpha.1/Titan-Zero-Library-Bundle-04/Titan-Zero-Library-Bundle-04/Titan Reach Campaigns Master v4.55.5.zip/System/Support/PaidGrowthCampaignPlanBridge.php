<?php

declare(strict_types=1);
namespace App\Extensions\TitanReachCampaigns\System\Support;
final class PaidGrowthCampaignPlanBridge { public function prepare(array $plan): array { $plan['draft_only']=true; $plan['automatic_activation']=false; $plan['requires_paid_growth_governance']=true; return $plan; } }
