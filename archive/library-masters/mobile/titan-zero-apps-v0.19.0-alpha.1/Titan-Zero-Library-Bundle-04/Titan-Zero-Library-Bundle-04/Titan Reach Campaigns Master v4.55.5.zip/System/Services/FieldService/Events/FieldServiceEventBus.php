<?php

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService\Events;

use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Log;
use Throwable;

class FieldServiceEventBus
{
    /** @return array<string, mixed> */
    public function publish(FieldServiceEventEnvelope $envelope): array
    {
        $event = $envelope->toArray();

        try {
            Event::dispatch('field_service.social.event', [$event]);
            Event::dispatch($event['event_type'], [$event]);
        } catch (Throwable $exception) {
            Log::warning('field_service_event_dispatch_failed', [
                'event_type' => $event['event_type'],
                'company_id' => $event['company_id'],
                'source_extension' => $event['source_extension'],
                'correlation_id' => $event['correlation_id'],
            ]);

            return ['status' => 'failed', 'event' => $event];
        }

        return ['status' => 'published', 'event' => $event];
    }

    /** @param array<string, mixed> $payload @return array<string, mixed> */
    public function publishArray(string $eventType, int|string $companyId, string $sourceExtension, array $payload = [], array $metadata = []): array
    {
        return $this->publish(new FieldServiceEventEnvelope(
            eventType: $eventType,
            companyId: $companyId,
            sourceExtension: $sourceExtension,
            payload: $payload,
            metadata: $metadata,
        ));
    }
}
