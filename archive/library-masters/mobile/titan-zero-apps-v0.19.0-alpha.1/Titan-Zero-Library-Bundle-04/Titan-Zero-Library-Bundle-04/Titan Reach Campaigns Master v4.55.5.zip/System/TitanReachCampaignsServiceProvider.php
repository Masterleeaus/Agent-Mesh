<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System;

use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanReachCampaigns\System\Http\Controllers\CampaignPlaybookController;
use App\Extensions\TitanReachCampaigns\System\Http\Controllers\FieldServiceWorkspaceController;
use App\Extensions\TitanReachCampaigns\System\Navigation\TitanReachMenuInstaller;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use App\Extensions\TitanReachCampaigns\System\Services\FieldService\SharedFieldServiceContextResolver;

class TitanReachCampaignsServiceProvider extends ServiceProvider implements UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-reach-campaigns', \App\Extensions\TitanReachCampaigns\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton('field-service.live-install-evidence.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\LiveInstallerEvidenceCapture::class);
        $this->app->singleton('field-service.commercial.enforcement-upgrade-ux.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\CommercialTierEnforcementUpgradeUX::class);
        $this->app->singleton('field-service.local-growth-operational-trial.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\LocalGrowthAgentOperationalTrial::class);
        $this->app->singleton('field-service.hub-workflow-trial.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\FieldMarketingHubWorkflowTrial::class);
        $this->app->singleton('field-service.webhook-dry-run.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\RealWebhookAutomationDryRun::class);
        $this->app->singleton('field-service.migration-compatibility.titan_reach_campaigns', \App\Extensions\TitanReachCampaigns\System\Support\DatabaseMigrationUpgradeCompatibility::class);
        $this->app->singleton('field-service.runtime-repair.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\RuntimeMenuRouteBladeRepair::class);
        $this->app->singleton('field-service.commercial.plan-limits.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\FieldServiceCommercialPlanLimits::class);
        $this->app->singleton('field-service.workspace.navigator.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Services\FieldService\FieldServiceWorkspaceNavigator::class);
        $this->app->singleton('field-service.workspace.health.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Services\FieldService\FieldServiceWorkspaceHealth::class);
        $this->registerConfig();
        $this->app->singleton('titan-reach-campaigns.field-service.context', SharedFieldServiceContextResolver::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->registerTranslations()
            ->registerViews()
            ->registerRoutes()
            ->registerMigrations()
            ->publishAssets();
        $this->app->booted(static function (): void { TitanReachMenuInstaller::healIfNeeded(); });

    }

    public function publishAssets(): static
    {
        $this->publishes([
            __DIR__ . '/../resources/assets/images' => public_path('vendor/titan-reach-campaigns/images'),
        ], 'extension');

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-webhook-dry-run.php', 'field-service-webhook-dry-run.' . self::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-final-customer-release.php', 'field-service-final-customer-release.' . self::class);
        $this->app->singleton('field-service-final-customer-release.' . self::class, fn () => new \App\Extensions\TitanReachCampaigns\System\Support\FinalCustomerReleaseCandidate());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-inbox.php', 'titan-reach-inbox.' . self::class);
        $this->app->singleton('titan-reach.inbox.bridge.' . self::class, \App\Extensions\TitanReachCampaigns\System\Support\TitanReachInboxBridge::class);
        return $this;
    }

    public function registerConfig(): static
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-titan-zero-closed-loop.php', 'titan-reach-titan-zero-closed-loop.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-production-release.php', 'titan-reach-production-release.' . self::class);
        $this->app->singleton('titan-reach.production-release.' . self::class, \App\Extensions\TitanReachCampaigns\System\Support\TitanReachProductionRelease::class);
        $this->app->singleton('titan-reach.titan-zero.closed-loop.' . self::class, \App\Extensions\TitanReachCampaigns\System\Support\TitanZeroClosedLoopBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-presence.php', 'titan-reach-local-presence.' . self::class);
        $this->app->singleton('titan-reach.local-presence.bridge.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\TitanReachLocalPresenceBridge::class);

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-paid-growth.php', 'titan-reach-paid-growth.' . self::class);
        $this->app->singleton('titan-reach.paid-growth.bridge.' . self::class, \App\Extensions\TitanReachCampaigns\System\Support\TitanReachPaidGrowthBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-reputation.php', 'titan-reach-reputation.' . self::class);
        $this->app->singleton('titan-reach.reputation.bridge.campaign_playbooks', \App\Extensions\TitanReachCampaigns\System\Support\TitanReachReputationBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-distribution.php', 'titan-reach-distribution');
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-local-distribution.php', 'titan-reach-local-distribution.' . self::class);
        $this->app->singleton('titan-reach.distribution.bridge.titan_reach_campaigns', \App\Extensions\TitanReachCampaigns\System\Support\TitanReachDistributionBridge::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-campaigns.php', 'titan-reach-campaigns');
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-events.php', 'field-service-events.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-workspace.php', 'field-service-workspace.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-production.php', 'field-service-production.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime.php', 'field-service-runtime.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-smoke.php', 'field-service-runtime-smoke.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-lead-flow-simulation.php', 'field-service-lead-flow-simulation.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-publish-governance.php', 'field-service-publish-governance.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial.php', 'field-service-commercial.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-demo-showcase.php', 'field-service-demo-showcase.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-certification.php', 'field-service-runtime-certification.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-installer-diagnostics.php', 'field-service-live-installer-diagnostics.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-runtime-repair.php', 'field-service-runtime-repair.' . self::class);
        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-commercial-enforcement.php', 'field-service-commercial-enforcement.' . self::class);


        $this->mergeConfigFrom(__DIR__ . '/../config/field-service-live-install-evidence.php', 'field-service-live-install-evidence.' . self::class);
        $this->app->singleton('field-service-live-install-evidence.' . self::class, fn () => new \App\Extensions\TitanReachCampaigns\System\Support\LiveInstallerEvidenceCapture());
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-reach-growth-intelligence.php', 'titan-reach-growth-intelligence.' . self::class);
        $this->app->singleton('titan-reach.growth-intelligence.bridge.' . self::class, \App\Extensions\TitanReachCampaigns\System\Support\TitanReachGrowthIntelligenceBridge::class);
        return $this;
    }

    protected function registerTranslations(): static
    {
        $this->loadTranslationsFrom(__DIR__ . '/../resources/lang', 'titan-reach-campaigns');

        return $this;
    }

    public function registerViews(): static
    {
        $this->loadViewsFrom([__DIR__ . '/../resources/views'], 'titan-reach-campaigns');

        return $this;
    }

    public function registerMigrations(): static
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');

        return $this;
    }

    private function registerRoutes(): static
    {
        $this->router()->group(['middleware' => ['web', 'auth']], function (): void {
            Route::prefix('dashboard/user/titan-reach/campaigns')
                ->name('dashboard.user.titan-reach.campaigns.')
                ->group(function (): void {
                    Route::get('workspace', FieldServiceWorkspaceController::class)->name('workspace');
                    Route::controller(CampaignPlaybookController::class)
                        ->prefix('playbooks')
                        ->name('playbooks.')
                        ->group(function (): void {
                            Route::get('', 'index')->name('index');
                            Route::post('', 'store')->name('store');
                            Route::get('export', 'export')->name('export');
                        });
                });
        });

        return $this;
    }

    private function router(): Router|Route
    {
        return $this->app['router'];
    }

    public static function uninstall(): void
    {
        // Campaigns owns no host-global setting that should be mutated on uninstall.
    }
}
