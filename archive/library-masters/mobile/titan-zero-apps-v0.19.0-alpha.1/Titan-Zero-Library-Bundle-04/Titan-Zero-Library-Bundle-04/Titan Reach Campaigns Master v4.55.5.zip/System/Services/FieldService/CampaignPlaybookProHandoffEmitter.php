<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Services\FieldService;

use App\Extensions\TitanReachCampaigns\System\Models\CampaignPlaybookItem;
use Illuminate\Support\Facades\Log;
use Throwable;

final class CampaignPlaybookProHandoffEmitter
{
    public function emit(CampaignPlaybookItem $item): array
    {
        $payload = [
            'source_extension' => 'titan-reach-campaigns',
            'event' => 'CampaignPlanReady',
            'company_id' => $item->company_id,
            'playbook_item_id' => $item->id,
            'playbook_key' => $item->playbook_key,
            'category' => $item->category,
            'planned_for' => optional($item->planned_for)->toIso8601String(),
            'headline' => $item->headline,
            'brief' => $item->brief,
            'cta' => $item->cta,
            'content_lane' => $item->content_lane,
        ];

        if (app()->bound('titan-reach.field-service.campaign-playbook-handoff')) {
            try {
                app('titan-reach.field-service.campaign-playbook-handoff')->receive($payload);
                $item->forceFill(['handoff_status' => 'pro_available_pending_publish_queue', 'handoff_payload' => $payload])->save();
                return ['status' => 'pro_available_pending_publish_queue', 'payload' => $payload];
            } catch (Throwable $error) {
                Log::warning('Titan Reach Campaigns handoff deferred', [
                    'company_id' => $item->company_id,
                    'playbook_item_id' => $item->id,
                    'error_class' => $error::class,
                ]);
            }
        }

        $item->forceFill(['handoff_status' => 'standalone_export', 'standalone_export_payload' => $payload])->save();
        return ['status' => 'standalone_export', 'payload' => $payload];
    }
}
