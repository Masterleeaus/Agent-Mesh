<?php

declare(strict_types=1);

namespace App\Extensions\TitanReachCampaigns\System\Support;

final class TitanReachReputationBridge
{
    /**
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    public function summarizeReadiness(array $context): array
    {
        $companyId = $context['company_id'] ?? null;
        if ($companyId === null || $companyId === '') {
            return [
                'ready' => false,
                'blocked_by' => 'missing_company_id',
                'destination' => 'google_business_profile',
                'safe_fallback' => true,
            ];
        }

        return [
            'ready' => true,
            'blocked_by' => null,
            'destination' => 'google_business_profile',
            'company_id' => $companyId,
            'supports' => [
                'posts',
                'photos',
                'reviews',
                'review_replies',
                'location_discovery',
                'performance_signals',
            ],
            'governance' => [
                'auto_reply_reviews' => false,
                'auto_publish_posts' => false,
                'requires_human_approval_for_review_replies' => true,
                'do_not_invent_licences_or_prices' => true,
            ],
        ];
    }
}
