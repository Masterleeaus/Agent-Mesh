<?php

namespace App\Extensions\TitanReachCampaigns\System\Enums;

enum Platform: string
{
    case x = 'x';
    case linkedin = 'linkedin';
    case instagram = 'instagram';
}
