<?php
$root=dirname(__DIR__); $fails=[]; $ok=0;
$check=function(bool $v,string $m)use(&$fails,&$ok){if($v){$ok++;}else{$fails[]=$m;}};
$read=fn($p)=>(string)@file_get_contents($root.'/'.$p);
$manifest=json_decode($read('docs/extension-manifest-v1-legacy-reference.json'),true)?:[];
$check(version_compare((string)($manifest['version']??'0'),'1.0.0-alpha.15','>='),'Field version not advanced to Pass 14');
$check(($manifest['titan_architecture']['offline_field_runtime']??null)==='titan_go_governed_offline_replay_v1','offline runtime architecture marker missing');
foreach([
'System/Domains/FieldServices/Offline/OfflineReplayPolicy.php',
'System/Domains/FieldServices/Offline/OfflineFieldRuntime.php',
'System/Http/Controllers/TitanGoApiController.php',
'database/migrations/2026_08_18_000008_create_titan_field_offline_runtime.php',
'routes/api.php','docs/PASS14_TITAN_GO_OFFLINE_RUNTIME.md'
] as $p)$check(is_file($root.'/'.$p),'missing '.$p);
$policy=$read('System/Domains/FieldServices/Offline/OfflineReplayPolicy.php');
foreach(['device_id','operation_id','occurred_at','base_entity_version','entity_type','entity_public_id','OFFLINE_CONFLICT_ENTITY_VERSION','maximum_offline_age_days'] as $t)$check(str_contains($policy,$t),'offline replay policy missing '.$t);
$runtime=$read('System/Domains/FieldServices/Offline/OfflineFieldRuntime.php');
foreach(['FieldCommandGateway','SpatialIntelligenceGateway','titan_field_offline_devices','titan_field_offline_receipts','registerDevice','mobileContext','replay','replayBatch','syncOfflineWorkerLocations','base_entity_version','entity_version','conflict','titan-go-offline'] as $t)$check(str_contains($runtime,$t),'offline runtime missing '.$t);
foreach(['work_order.note','work_order.task_status','work_order.status','work_order.complete','work_order.time','dispatch.status','route_stop.status','form.response','form.submit','evidence.reference','signature.reference','location.batch'] as $op)$check(str_contains($runtime,"'{$op}'"),'offline operation missing '.$op);
foreach(['failed','processing','OFFLINE_CONFLICT_ENTITY_MISSING','work_order_tasks'] as $t)$check(str_contains($runtime,$t),'offline retry/context hardening missing '.$t);
$api=$read('routes/api.php');$check(str_contains($api,"prefix('api/titan-field/v1/mobile')"),'Titan Go mobile API prefix missing'); foreach(["'/context'","'/devices/register'","'/replay'","'/sync'","'/evidence'"] as $t)$check(str_contains($api,$t),'Titan Go API route missing '.$t);
$controller=$read('System/Http/Controllers/TitanGoApiController.php'); foreach(['context','registerDevice','replay','sync','evidence','X-Titan-Device-Id','X-Titan-Operation-Id','base_entity_version'] as $t)$check(str_contains($controller,$t),'Titan Go controller missing '.$t);
$router=$read('System/Infrastructure/Commands/FieldServiceCommandRouter.php'); foreach(['titan.field.work_orders|add_note','titan.field.forms|save_response','titan.field.forms|submit_submission','titan.field.evidence|record_reference','titan.field.dispatch|transition_for_worker'] as $t)$check(str_contains($router,$t),'command router missing offline target '.$t);
$migration=$read('database/migrations/2026_08_18_000008_create_titan_field_offline_runtime.php');
foreach(['titan_field_offline_devices','titan_field_offline_receipts','entity_version','crm_dispatch_assignments','crm_form_submissions','titan_field_routes','titan_field_route_stops'] as $t)$check(str_contains($migration,$t),'offline migration missing '.$t);
foreach([
'System/Domains/FieldServices/WorkOrders/WorkOrderService.php',
'System/Domains/FieldServices/Forms/FormService.php',
'System/Domains/FieldServices/Dispatch/DispatchService.php',
'System/Domains/FieldServices/Routing/RouteService.php'
] as $p)$check(str_contains($read($p),'entity_version'),$p.' does not advance entity_version');
$spatial=$read('System/Contracts/SpatialIntelligenceGateway.php');$check(str_contains($spatial,'syncOfflineWorkerLocations'),'spatial gateway missing offline location sync');
foreach(['System/Infrastructure/Spatial/OptionalTitanMapsSpatialIntelligenceGateway.php','System/Infrastructure/Spatial/FallbackSpatialIntelligenceGateway.php'] as $p)$check(str_contains($read($p),'syncOfflineWorkerLocations'),$p.' missing offline sync implementation');
$provider=$read('System/TitanFieldServiceProvider.php');foreach(['OfflineReplayPolicy','OfflineFieldRuntime'] as $t)$check(str_contains($provider,$t),'provider missing '.$t);
$verify=$read('bin/verify-extraction.php');$check(str_contains($verify,'Pass 14'),'embedded verifier missing Pass 14');
$cap=json_decode($read('CAPABILITIES.json'),true)?:[];$check(($cap['offline_runtime_policy']??null)==='device_bound_versioned_replay_v1','CAPABILITIES offline runtime policy missing');
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n"); fwrite(STDERR,count($fails)." failures\n"); exit(1);} echo "PASS Titan Field Pass 14 offline runtime ($ok assertions)\n";
