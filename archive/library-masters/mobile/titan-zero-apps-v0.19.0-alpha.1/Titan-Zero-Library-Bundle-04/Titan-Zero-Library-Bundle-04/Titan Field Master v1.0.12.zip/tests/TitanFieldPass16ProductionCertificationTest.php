<?php
declare(strict_types=1);
$root=dirname(__DIR__); $n=0; $fail=[];
$ok=function(bool $v,string $m)use(&$n,&$fail){$n++; if(!$v)$fail[]=$m;};
$menu=file_get_contents($root.'/System/Navigation/TitanFieldMenuDefinition.php');
foreach(['crm_field_overview','crm_agreements','crm_catalogue','crm_forms','crm_verticals','crm_reviews','crm_schedule','crm_dispatch','crm_timesheets','crm_customer_assets'] as $key)$ok(str_contains($menu,"'key' => '$key'"),"host menu identity $key retained");
foreach(['crm_field_work_overview','crm_recurring_work','crm_services_catalogue','crm_field_forms','crm_vertical_profiles','crm_reviews_recovery'] as $key)$ok(!str_contains($menu,"'key' => '$key'"),"synthetic menu key $key removed");
$installer=file_get_contents($root.'/System/Navigation/TitanFieldMenuInstaller.php'); foreach(['tabler-chart-line','tabler-alert-triangle','tabler-route'] as $icon)$ok(str_contains($installer,"'$icon'"),"host-safe icon $icon supported");
$manifest=json_decode(file_get_contents($root.'/extension.json'),true); $sidecar=json_decode(file_get_contents($root.'/extension.manifest.json'),true); $ok(($sidecar['data']['tenant_key']??null)==='company_id','canonical tenant boundary');
$ok(($manifest['uninstall']['preserve_data']??true)===true,'uninstall retains domain data');
$provider=file_get_contents($root.'/System/TitanFieldServiceProvider.php'); $ok(str_contains($provider,'OptionalTitanMapsSpatialIntelligenceGateway'),'Maps peer remains optional');
$ok(str_contains($provider,'TitanFieldMenuInstaller::healIfNeeded'),'menu self-healing remains wired');
$ok(is_file($root.'/docs/PASS16_PRODUCTION_CERTIFICATION.md'),'production certification report present');
foreach(glob($root.'/database/migrations/*.php') as $p){$s=file_get_contents($p); if(preg_match('/public function up\(\): void\s*\{([\s\S]*?)public function down/',$s,$mm))$ok(!preg_match('/Schema::drop|dropColumn|dropIfExists/',$mm[1]),'no destructive up migration '.basename($p));}
if($fail){foreach($fail as $x)fwrite(STDERR,"FAIL $x\n"); exit(1);} echo "PASS: $n assertions\n";
