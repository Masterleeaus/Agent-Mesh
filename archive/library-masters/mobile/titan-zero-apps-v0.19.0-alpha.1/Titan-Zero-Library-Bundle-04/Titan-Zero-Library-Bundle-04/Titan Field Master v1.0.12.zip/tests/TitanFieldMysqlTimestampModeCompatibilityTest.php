<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$checks = 0;
$assert = static function (bool $condition, string $message) use (&$failures, &$checks): void {
    $checks++;
    if (! $condition) {
        $failures[] = $message;
    }
};

foreach (glob($root . '/database/migrations/*.php') ?: [] as $migration) {
    $source = file_get_contents($migration);
    if (! is_string($source)) {
        $failures[] = basename($migration) . ': unreadable';
        continue;
    }

    preg_match_all("/->timestamp\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)([^;]*);/", $source, $matches, PREG_SET_ORDER);
    foreach ($matches as $match) {
        $column = (string) $match[1];
        $chain = (string) $match[2];
        $safe = str_contains($chain, '->nullable()')
            || str_contains($chain, '->useCurrent()')
            || str_contains($chain, '->default(')
            || str_contains($chain, '->useCurrentOnUpdate()');

        $assert(
            $safe,
            basename($migration) . ": required timestamp '{$column}' relies on MySQL implicit default semantics; use dateTime() or an explicit safe default"
        );
    }
}

$routes = file_get_contents($root . '/database/migrations/2026_08_18_000007_create_titan_field_routes_live_position.php');
$assert(is_string($routes) && str_contains($routes, "dateTime('captured_at')"), 'worker-location captured_at uses DATETIME');
$assert(is_string($routes) && str_contains($routes, "dateTime('consent_granted_at')"), 'worker-location consent_granted_at uses DATETIME');
$assert(is_string($routes) && str_contains($routes, "dateTime('retention_expires_at')"), 'worker-location retention_expires_at uses DATETIME');
$assert(is_string($routes) && substr_count($routes, "Schema::hasTable('titan_field_routes')") >= 1, 'route table is guarded for retry after a partially completed migration');
$assert(is_string($routes) && substr_count($routes, "Schema::hasTable('titan_field_route_stops')") >= 1, 'route-stop table is guarded for retry after a partially completed migration');
$assert(is_string($routes) && substr_count($routes, "Schema::hasTable('titan_field_worker_location_pings')") >= 1, 'worker-location migration remains retry-safe after a failed create');

$offline = file_get_contents($root . '/database/migrations/2026_08_18_000008_create_titan_field_offline_runtime.php');
$assert(is_string($offline) && str_contains($offline, "dateTime('registered_at')"), 'offline device registered_at uses DATETIME');
$assert(is_string($offline) && str_contains($offline, "dateTime('occurred_at')"), 'offline command occurred_at uses DATETIME');
$assert(is_string($offline) && str_contains($offline, "dateTime('received_at')"), 'offline command received_at uses DATETIME');
$assert(is_string($offline) && str_contains($offline, "Schema::hasTable('titan_field_offline_devices')"), 'offline device table is guarded for retry');
$assert(is_string($offline) && str_contains($offline, "Schema::hasTable('titan_field_offline_receipts')"), 'offline receipt table is guarded for retry');

if ($failures !== []) {
    foreach ($failures as $failure) {
        fwrite(STDERR, "FAIL {$failure}\n");
    }
    fwrite(STDERR, 'Failed: ' . count($failures) . " / {$checks}\n");
    exit(1);
}

echo "PASS Titan Field MySQL timestamp-mode compatibility ({$checks} assertions)\n";
