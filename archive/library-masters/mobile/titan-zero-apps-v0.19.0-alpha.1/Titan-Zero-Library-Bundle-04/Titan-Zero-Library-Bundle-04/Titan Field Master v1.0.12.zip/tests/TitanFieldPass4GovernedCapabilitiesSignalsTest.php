<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];
$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) { $passes[] = $message; } else { $failures[] = $message; }
};
$read = static function (string $relative) use ($root): string {
    $path = $root . '/' . $relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

foreach ([
    'System/Contracts/FieldSignalPort.php',
    'System/Infrastructure/Signals/DatabaseFieldSignalOutbox.php',
    'database/migrations/2026_08_17_000002_create_titan_field_signal_outbox.php',
] as $file) {
    $assert(is_file($root . '/' . $file), "Pass 4 signal/outbox file exists: {$file}");
}

$capabilities = json_decode($read('CAPABILITIES.json'), true);
$assert(is_array($capabilities), 'CAPABILITIES.json parses');
$definitions = is_array($capabilities['definitions'] ?? null) ? $capabilities['definitions'] : [];
$assert(count($definitions) >= 20, 'capability manifest exposes the complete Field capability family');
$requiredFields = ['id','legacy_aliases','owner','input_contract','output_contract','risk','autonomy','evidence','offline','reversibility','idempotency'];
foreach ($definitions as $index => $definition) {
    $label = is_array($definition) ? (string)($definition['id'] ?? $index) : (string)$index;
    $assert(is_array($definition), "capability definition is structured: {$label}");
    if (! is_array($definition)) continue;
    foreach ($requiredFields as $field) {
        $assert(array_key_exists($field, $definition), "capability {$label} declares {$field}");
    }
    $assert(str_starts_with((string)($definition['id'] ?? ''), 'titan.field.'), "capability uses canonical titan.field name: {$label}");
    $assert(($definition['owner'] ?? null) === 'titan-field', "capability owner is titan-field: {$label}");
    $aliases = is_array($definition['legacy_aliases'] ?? null) ? $definition['legacy_aliases'] : [];
    $assert($aliases !== [] && str_starts_with((string)$aliases[0], 'crm.'), "capability preserves CRM compatibility alias: {$label}");
    $assert(is_array($definition['risk'] ?? null) && isset($definition['risk']['level']), "capability risk is explicit: {$label}");
    $assert(is_array($definition['autonomy'] ?? null) && isset($definition['autonomy']['mode']), "capability autonomy is explicit: {$label}");
    $assert(is_array($definition['offline'] ?? null) && array_key_exists('allowed', $definition['offline']), "capability offline policy is explicit: {$label}");
    $assert(is_array($definition['idempotency'] ?? null) && array_key_exists('required_for_mutations', $definition['idempotency']), "capability idempotency is explicit: {$label}");
}

$registry = $read('System/Domains/FieldServices/FieldServiceCapabilityRegistry.php');
foreach (['canonicalName','definition','allDefinitions','legacy_aliases','CAPABILITIES.json'] as $token) {
    $assert(str_contains($registry, $token), "runtime capability registry exposes governance token: {$token}");
}

$signalPort = $read('System/Contracts/FieldSignalPort.php');
foreach (['trace_id','correlation_id','causation_id','idempotency_key','record'] as $token) {
    $assert(str_contains($signalPort, $token), "FieldSignalPort contract declares {$token}");
}
$outbox = $read('System/Infrastructure/Signals/DatabaseFieldSignalOutbox.php');
foreach (['company_id','trace_id','correlation_id','causation_id','idempotency_key','receipt','titan_field_signal_outbox'] as $token) {
    $assert(str_contains($outbox, $token), "database signal outbox persists {$token}");
}
$assert(str_contains($outbox, "where('company_id'"), 'signal idempotency lookup is tenant scoped');
$assert(str_contains($outbox, "where('idempotency_key'"), 'signal outbox deduplicates by idempotency key');

$migration = $read('database/migrations/2026_08_17_000002_create_titan_field_signal_outbox.php');
$assert(str_contains($migration, "Schema::hasTable('titan_field_signal_outbox')"), 'signal outbox migration is restartable');
foreach (['trace_id','correlation_id','causation_id','idempotency_key','payload','receipt','status','published_at'] as $column) {
    $assert(str_contains($migration, "'{$column}'"), "signal outbox schema contains {$column}");
}
$down = substr($migration, (int) strpos($migration, 'public function down(): void'));
$assert(! str_contains($down, 'dropIfExists') && ! str_contains($down, 'dropColumn'), 'signal outbox rollback retains event evidence');

$provider = $read('System/TitanFieldServiceProvider.php');
$assert(str_contains($provider, 'FieldSignalPort::class'), 'provider binds FieldSignalPort');
$assert(str_contains($provider, 'DatabaseFieldSignalOutbox::class'), 'provider binds database signal outbox');

$coreMutations = [
    'System/Domains/FieldServices/Requests/ServiceRequestService.php',
    'System/Domains/FieldServices/WorkOrders/WorkOrderService.php',
    'System/Domains/FieldServices/Scheduling/AppointmentService.php',
    'System/Domains/FieldServices/Dispatch/DispatchService.php',
    'System/Domains/FieldServices/Recurring/RecurringServiceEngine.php',
    'System/Domains/FieldServices/Forms/FormService.php',
    'System/Domains/FieldServices/Evidence/FieldEvidenceService.php',
    'System/Domains/FieldServices/Support/SupportService.php',
    'System/Domains/FieldServices/Reviews/ReviewRecoveryService.php',
];
foreach ($coreMutations as $service) {
    $source = $read($service);
    $assert(str_contains($source, 'FieldSignalPort'), "important mutation service consumes FieldSignalPort: {$service}");
    $assert(str_contains($source, '->record('), "important mutation service records Signal envelope: {$service}");
    $assert(str_contains($source, '->transaction('), "important mutation service has transaction boundary for Signal atomicity: {$service}");
}

$manifest = json_decode($read('docs/extension-manifest-v1-legacy-reference.json'), true);
$assert(($manifest['titan_architecture']['signal'] ?? null) === 'titan_field_transactional_signal_outbox_v1', 'manifest declares transactional Titan Field Signal outbox');
$assert(($manifest['titan_architecture']['capability_governance'] ?? null) === 'governed_capability_manifest_v1', 'manifest declares governed capability manifest');

$verify = $read('bin/verify-extraction.php');
$assert(str_contains($verify, 'TitanFieldPass4GovernedCapabilitiesSignalsTest.php'), 'embedded verifier includes Pass 4 regression gate');
$assert(str_contains($verify, 'titan_field_signal_outbox'), 'embedded verifier checks signal outbox');
$assert(str_contains($verify, 'governed_capability_manifest_v1'), 'embedded verifier checks capability governance declaration');

if ($failures !== []) {
    fwrite(STDERR, "FAIL Titan Field Pass 4 governed-capabilities/signals contract\n");
    foreach ($failures as $failure) fwrite(STDERR, " - {$failure}\n");
    fwrite(STDERR, sprintf("Passed assertions: %d; failed assertions: %d\n", count($passes), count($failures)));
    exit(1);
}

echo sprintf("PASS Titan Field Pass 4 governed-capabilities/signals contract (%d assertions)\n", count($passes));
