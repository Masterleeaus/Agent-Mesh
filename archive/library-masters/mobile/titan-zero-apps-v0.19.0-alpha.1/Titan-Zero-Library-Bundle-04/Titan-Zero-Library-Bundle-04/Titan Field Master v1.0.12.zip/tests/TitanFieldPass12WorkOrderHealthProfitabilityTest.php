<?php
$root=dirname(__DIR__); $fails=[]; $ok=0;
$check=function(bool $v,string $m)use(&$fails,&$ok){if($v){$ok++;}else{$fails[]=$m;}};
$read=fn($p)=>(string)@file_get_contents($root.'/'.$p);
$manifest=json_decode($read('docs/extension-manifest-v1-legacy-reference.json'),true)?:[];
$check(version_compare((string)($manifest['version']??'0'),'1.0.0-alpha.13','>='),'Field version not advanced to Pass 12');
$check(($manifest['titan_architecture']['work_order_health']??null)==='read_only_profitability_spatial_evidence_v1','work-order health architecture marker missing');
foreach([
'System/Domains/FieldServices/WorkOrders/WorkOrderProfitabilityCalculator.php',
'System/Domains/FieldServices/WorkOrders/WorkOrderHealthService.php',
'docs/PASS12_WORK_ORDER_HEALTH_PROFITABILITY.md'
] as $p)$check(is_file($root.'/'.$p),'missing '.$p);
$contract=$read('System/Contracts/SpatialIntelligenceGateway.php'); $check(str_contains($contract,'workOrderCostEvidence'),'spatial contract missing workOrderCostEvidence');
foreach(['System/Infrastructure/Spatial/FallbackSpatialIntelligenceGateway.php','System/Infrastructure/Spatial/OptionalTitanMapsSpatialIntelligenceGateway.php'] as $p)$check(str_contains($read($p),'workOrderCostEvidence'),$p.' missing workOrderCostEvidence');
$health=$read('System/Domains/FieldServices/WorkOrders/WorkOrderHealthService.php');
$calculator=$read('System/Domains/FieldServices/WorkOrders/WorkOrderProfitabilityCalculator.php');
foreach(['crm_work_orders','crm_work_order_services','crm_work_order_time_entries','crm_work_order_materials','crm_field_worker_profiles','SpatialIntelligenceGateway','quoted_revenue_minor','planned_labour_minutes','actual_labour_minutes'] as $t)$check(str_contains($health,$t),'health service missing '.$t);
foreach(['forecast_final_cost_minor','projected_margin_minor','over_hours','over_budget','cost_coverage'] as $t)$check(str_contains($calculator,$t),'profitability calculator missing '.$t);
$check(!str_contains($health,"->insert("),'health service must remain read-only');
$check(!str_contains($health,"->update("),'health service must remain read-only');
$controller=$read('System/Http/Controllers/FieldServiceController.php'); $check(str_contains($controller,'WorkOrderHealthService'),'controller missing work-order health service');
$check(str_contains($controller,"\$detail['health']") && str_contains($controller,'workOrderHealth->health'),'work-order detail does not expose health');
$view=$read('resources/views/field-services/work-order-show.blade.php'); foreach(['Work-order health','Projected margin','Forecast final cost','Actual labour','Materials cost','Spatial cost evidence','pricing hints are advisory'] as $t)$check(str_contains($view,$t),'work-order UI missing '.$t);
$provider=$read('System/TitanFieldServiceProvider.php'); $check(str_contains($provider,'WorkOrderHealthService'),'provider missing WorkOrderHealthService');
$verify=$read('bin/verify-extraction.php'); $check(str_contains($verify,'Pass 12'),'embedded verifier missing Pass 12');
$calcFile=$root.'/System/Domains/FieldServices/WorkOrders/WorkOrderProfitabilityCalculator.php';
if(is_file($calcFile)){
    require_once $calcFile;
    $class='App\\Extensions\\TitanField\\System\\Domains\\FieldServices\\WorkOrders\\WorkOrderProfitabilityCalculator';
    $calc=new $class();
    $result=$calc->calculate([
        'quoted_revenue_minor'=>100000,'planned_labour_minutes'=>240,'actual_labour_minutes'=>180,
        'known_actual_labour_cost_minor'=>30000,'labour_cost_complete'=>true,'planned_labour_cost_minor'=>40000,
        'material_cost_minor'=>10000,'material_cost_complete'=>true,'additional_billable_revenue_minor'=>0,
        'travel_time_cost_minor'=>3000,'travel_distance_cost_minor'=>2000,'unresolved_exception_severities'=>[],
    ]);
    $check(($result['forecast_final_cost_minor']??null)===55000,'calculator forecast expected 55000');
    $check(($result['projected_margin_minor']??null)===45000,'calculator margin expected 45000');
    $check(abs((float)($result['projected_margin_percent']??0)-45.0)<0.001,'calculator margin percent expected 45');
    $check(($result['health_status']??null)==='healthy','calculator expected healthy status');
    $incomplete=$calc->calculate([
        'quoted_revenue_minor'=>100000,'planned_labour_minutes'=>240,'actual_labour_minutes'=>180,
        'known_actual_labour_cost_minor'=>10000,'labour_cost_complete'=>false,'planned_labour_cost_minor'=>null,
        'material_cost_minor'=>5000,'material_cost_complete'=>true,'additional_billable_revenue_minor'=>0,
        'travel_time_cost_minor'=>null,'travel_distance_cost_minor'=>null,'unresolved_exception_severities'=>[],
    ]);
    $check(array_key_exists('forecast_final_cost_minor',$incomplete) && $incomplete['forecast_final_cost_minor']===null,'incomplete cost coverage must null forecast');
    $check(array_key_exists('projected_margin_minor',$incomplete) && $incomplete['projected_margin_minor']===null,'incomplete cost coverage must null projected margin');
}
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n"); fwrite(STDERR,count($fails)." failures\n"); exit(1);} echo "PASS Titan Field Pass 12 work-order health/profitability ($ok assertions)\n";
