<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$n=0;$fail=[];
$ok=static function(bool $v,string $m)use(&$n,&$fail):void{$n++;if(!$v)$fail[]=$m;};

$provider=file_get_contents($root.'/System/TitanFieldServiceProvider.php');
$installer=file_get_contents($root.'/System/Navigation/TitanFieldMenuInstaller.php');
$controllerPath=$root.'/System/Http/Controllers/StagedScheduleController.php';
$view=file_get_contents($root.'/resources/views/field-services/schedule.blade.php');

$ok(is_file($controllerPath),'staged read-only Schedule controller exists');
$controller=is_file($controllerPath)?file_get_contents($controllerPath):'';
$ok(str_contains($controller,"DB::table('crm_appointments')"),'staged Schedule reads existing CRM appointments');
$ok(str_contains($controller,"'staged' => true"),'staged Schedule explicitly marks read-only rendering mode');
$ok(!str_contains($controller,'FieldCommandGateway'),'staged Schedule has no Field mutation gateway');
$ok(str_contains($provider,'StagedScheduleController'),'provider registers staged Schedule surface');
$ok(str_contains($provider,"dashboard.user.titan-field.schedule"),'provider names staged Schedule route');
$ok(str_contains($provider,"/titan-field/schedule"),'staged route uses a non-conflicting URI');
$ok(str_contains($installer,'syncStagedSchedule'),'menu installer has bounded staged Schedule repair');
$ok(str_contains($installer,"'label' => 'Schedule'"),'staged menu repair renames Calendar to Schedule');
$ok(str_contains($installer,"'route' => 'dashboard.user.titan-field.schedule'"),'staged menu repair points to read-only staged route');
$ok(str_contains($view,"Read-only staged Schedule"),'view clearly labels staged Schedule as read-only');
$ok(str_contains($view,'schedule-calendar-grid'),'staged view uses the same real calendar grid');

if($fail){foreach($fail as $m)fwrite(STDERR,"FAIL $m\n");fwrite(STDERR,'Failed: '.count($fail)." / $n\n");exit(1);}echo "PASS Titan Field staged Schedule UI ($n assertions)\n";
