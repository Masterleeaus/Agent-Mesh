<?php

declare(strict_types=1);

$root=dirname(__DIR__);$fail=[];$pass=[];
$a=static function(bool $c,string $m)use(&$fail,&$pass){if($c){$pass[]=$m;}else{$fail[]=$m;}};
$r=static function(string $f)use($root):string{$p=$root.'/'.$f;return is_file($p)?(string)file_get_contents($p):'';};

$files=[
 'System/Domains/FieldServices/Scheduling/TechnicianRecommendationService.php',
 'System/Domains/FieldServices/Scheduling/TravelEstimator.php',
];
foreach($files as $f)$a(is_file($root.'/'.$f),"Pass 7 file exists: {$f}");

$kernel=$r('System/Domains/FieldServices/Scheduling/SchedulingKernel.php');
$recommend=$r($files[0]);$travel=$r($files[1]);$provider=$r('System/TitanFieldServiceProvider.php');
$controller=$r('System/Http/Controllers/FieldServiceController.php');$routes=$r('routes/web.php');

foreach(['assertServiceArea','service_area_public_id','location_public_id','postcode','latitude','longitude','remaining_daily_minutes','daily_load_minutes'] as $t)$a(str_contains($kernel,$t),"SchedulingKernel v2 carries {$t}");
$a(str_contains($kernel,'ServiceAreaMatcher'),'SchedulingKernel v2 consumes service-area authority');
$a(str_contains($kernel,'assertSchedulable'),'hard constraint authority remains SchedulingKernel');

foreach(['recommend(','SchedulingKernel','crm_field_worker_profiles','score','reasons','components','eligible','capacity','skills','service_area','travel','continuity'] as $t)$a(str_contains($recommend,$t),"recommendation layer contains {$t}");
$a(str_contains($recommend,'try')&&str_contains($recommend,'InvalidArgumentException'),'recommendation layer converts hard-constraint failures into explicit ineligible reasons');
$a(str_contains($recommend,'assertSchedulable'),'recommendation layer ranks through hard kernel rather than bypassing it');
$a(str_contains($recommend,'sortByDesc')||str_contains($recommend,'usort'),'recommendations are deterministically ranked');
$a(str_contains($recommend,"'eligible'=>true")||str_contains($recommend,"'eligible' => true"),'eligible recommendation state explicit');
$a(str_contains($recommend,"'eligible'=>false")||str_contains($recommend,"'eligible' => false"),'ineligible recommendation state explicit');
$a(str_contains($recommend,'max(0')&&str_contains($recommend,'min(100'),'recommendation score bounded to 0..100');

foreach(['estimate(','haversine','distance_meters','duration_seconds','provider'] as $t)$a(str_contains(strtolower($travel),strtolower($t)),"travel estimator exposes {$t}");
$a(!str_contains($travel,'curl_')&&!str_contains($travel,'Http::'),'Pass 7 travel estimate has no hidden network dependency');

foreach(['TechnicianRecommendationService::class','TravelEstimator::class'] as $t)$a(str_contains($provider,$t),"provider exposes Pass 7 service: {$t}");
$a(str_contains($controller,'TechnicianRecommendationService'),'controller exposes recommendation read path');
$a(str_contains($controller,'recommendWorkers'),'controller has recommendWorkers endpoint');
$a(str_contains($routes,'recommend-workers'),'routes expose worker recommendation endpoint');
$a(str_contains($routes,'crm.scheduling.manage')||str_contains($routes,'titan.field.scheduling.view'),'recommendation route remains permission-gated');

$cap=json_decode($r('CAPABILITIES.json'),true);$a(is_array($cap),'capability manifest parses');
if(is_array($cap)){
 $ids=array_column($cap['definitions']??[],'id');
 $a(in_array('titan.field.scheduling.recommend_workers',$ids,true),'canonical scheduling recommendation capability declared');
 $aliases=[];foreach(($cap['definitions']??[]) as $d){foreach(($d['legacy_aliases']??[]) as $alias)$aliases[]=$alias;}
 $a(in_array('crm.scheduling.recommend_workers',$aliases,true),'legacy CRM scheduling recommendation alias retained');
 $a(version_compare((string)($cap['release']??'0.0.0'),'1.0.0-alpha.8','>='),'capability manifest retains Pass 7 in alpha.8 or later');
}
$manifest=json_decode($r('docs/extension-manifest-v1-legacy-reference.json'),true);$a(is_array($manifest),'extension manifest parses');
if(is_array($manifest)){$a(version_compare((string)($manifest['version']??'0.0.0'),'1.0.0-alpha.8','>='),'manifest retains Pass 7 in alpha.8 or later');$a(($manifest['scheduling_policy']??null)==='hard_constraints_explainable_recommendations_v2','manifest declares Scheduling Kernel v2 contract');}
$verify=$r('bin/verify-extraction.php');foreach(['TechnicianRecommendationService','TravelEstimator','recommend_workers','hard_constraints_explainable_recommendations_v2'] as $t)$a(str_contains($verify,$t),"embedded verifier enforces Pass 7 token: {$t}");

if($fail){fwrite(STDERR,"FAIL Titan Field Pass 7 scheduling/recommendation contract\n");foreach($fail as $f)fwrite(STDERR," - {$f}\n");fwrite(STDERR,sprintf("Passed assertions: %d; failed assertions: %d\n",count($pass),count($fail)));exit(1);}echo sprintf("PASS Titan Field Pass 7 scheduling/recommendation contract (%d assertions)\n",count($pass));
