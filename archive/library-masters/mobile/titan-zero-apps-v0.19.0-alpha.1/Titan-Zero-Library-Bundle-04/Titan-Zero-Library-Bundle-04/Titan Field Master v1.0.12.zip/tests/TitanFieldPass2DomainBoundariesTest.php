<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];

$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) {
        $passes[] = $message;
        return;
    }
    $failures[] = $message;
};

$read = static function (string $relative) use ($root): string {
    $path = $root . '/' . $relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

$contracts = [
    'System/Contracts/FieldTenantContext.php',
    'System/Contracts/FieldAuditPort.php',
    'System/Contracts/FieldAutomationPort.php',
    'System/Contracts/FieldHostGate.php',
    'System/Contracts/FieldPermissionGate.php',
];
foreach ($contracts as $file) {
    $assert(is_file($root . '/' . $file), "Field-owned boundary contract exists: {$file}");
}

$adapters = [
    'System/Infrastructure/Compatibility/Crm/CrmFieldTenantContext.php',
    'System/Infrastructure/Compatibility/Crm/CrmFieldAuditAdapter.php',
    'System/Infrastructure/Compatibility/Crm/CrmFieldAutomationAdapter.php',
    'System/Infrastructure/Compatibility/Crm/CrmFieldHostGate.php',
    'System/Infrastructure/Compatibility/Crm/CrmFieldPermissionGate.php',
];
foreach ($adapters as $file) {
    $assert(is_file($root . '/' . $file), "CRM compatibility adapter exists: {$file}");
}

foreach ([
    'System/Http/Middleware/EnsureTitanFieldHostEnabled.php',
    'System/Http/Middleware/EnsureTitanFieldPermission.php',
    'config/titan-field.php',
] as $file) {
    $assert(is_file($root . '/' . $file), "Field boundary support exists: {$file}");
}

$provider = $read('System/TitanFieldServiceProvider.php');
foreach ([
    'FieldTenantContext::class',
    'FieldAuditPort::class',
    'FieldAutomationPort::class',
    'FieldHostGate::class',
    'FieldPermissionGate::class',
    'CrmFieldTenantContext::class',
    'CrmFieldAuditAdapter::class',
    'CrmFieldAutomationAdapter::class',
    'CrmFieldHostGate::class',
    'CrmFieldPermissionGate::class',
] as $token) {
    $assert(str_contains($provider, $token), "provider binds boundary token: {$token}");
}
$assert(str_contains($provider, 'mergeConfigFrom'), 'provider loads Titan Field compatibility config');

$forbiddenRoots = [
    $root . '/System/Domains',
    $root . '/System/Http/Controllers',
    $root . '/routes',
];
foreach ($forbiddenRoots as $scanRoot) {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($scanRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $fileInfo) {
        if (! $fileInfo->isFile() || ! in_array($fileInfo->getExtension(), ['php'], true)) {
            continue;
        }
        $contents = (string) file_get_contents($fileInfo->getPathname());
        $relative = substr($fileInfo->getPathname(), strlen($root) + 1);
        $assert(! str_contains($contents, 'App\\Extensions\\Crm\\'), "no direct CRM class dependency outside adapter boundary: {$relative}");
        $assert(! str_contains($contents, "config('crm."), "no direct CRM config dependency outside compatibility config: {$relative}");
    }
}

$routes = $read('routes/web.php');
$assert(str_contains($routes, 'EnsureTitanFieldHostEnabled::class'), 'routes use Titan Field host middleware');
$assert(str_contains($routes, 'EnsureTitanFieldPermission::class'), 'routes use Titan Field permission middleware');
$assert(! str_contains($routes, 'EnsureCrmHostEnabled'), 'routes no longer import CRM host middleware');
$assert(! str_contains($routes, 'EnsureCrmPermission'), 'routes no longer import CRM permission middleware');
foreach ([
    'dashboard.user.crm.field-services.index',
    'dashboard.user.crm.field-services.work-orders',
    'dashboard.user.crm.field-services.schedule',
    'dashboard.user.crm.field-services.dispatch',
] as $routeName) {
    $assert(str_contains($read('System/Navigation/TitanFieldMenuDefinition.php'), $routeName), "legacy named route remains compatible: {$routeName}");
}

$domainFiles = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System/Domains', FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $fileInfo) {
    if ($fileInfo->isFile() && $fileInfo->getExtension() === 'php') {
        $domainFiles[] = $fileInfo->getPathname();
    }
}
$combinedDomain = implode("\n", array_map(static fn (string $file): string => (string) file_get_contents($file), $domainFiles));
$assert(str_contains($combinedDomain, 'FieldTenantContext'), 'domain services consume FieldTenantContext');
$assert(str_contains($combinedDomain, 'FieldAuditPort'), 'mutation services consume FieldAuditPort');
$assert(str_contains($combinedDomain, 'FieldAutomationPort'), 'automation-producing services consume FieldAutomationPort');
$assert(! str_contains($combinedDomain, 'CrmCompanyScope'), 'domain layer no longer references CrmCompanyScope');
$assert(! str_contains($combinedDomain, 'CrmAuditRecorder'), 'domain layer no longer references CrmAuditRecorder');
$assert(! str_contains($combinedDomain, 'CrmAutomationTriggered'), 'domain layer no longer references CrmAutomationTriggered');

$compatibilityDirectory = $root . '/System/Infrastructure/Compatibility/Crm';
$compatibilityCombined = '';
if (is_dir($compatibilityDirectory)) {
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($compatibilityDirectory, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $fileInfo) {
        if ($fileInfo->isFile() && $fileInfo->getExtension() === 'php') {
            $compatibilityCombined .= (string) file_get_contents($fileInfo->getPathname());
        }
    }
}
foreach (['CrmCompanyScope', 'CrmAuditRecorder', 'CrmAutomationTriggered', 'EnsureCrmHostEnabled', 'EnsureCrmPermission'] as $legacyToken) {
    $assert(str_contains($compatibilityCombined, $legacyToken), "legacy CRM dependency is isolated inside compatibility adapters: {$legacyToken}");
}

$manifest = json_decode($read('docs/extension-manifest-v1-legacy-reference.json'), true);
$version=(string)($manifest['version']??'');$assert(version_compare($version,'1.0.0-alpha.3','>='), 'manifest remains at or beyond alpha.3');
$assert(($manifest['titan_architecture']['domain_boundary'] ?? null) === 'field_ports_with_crm_compatibility_adapters', 'manifest declares Field-owned domain boundary');

$dependencyDoc = $read('docs/DEPENDENCY_INVENTORY.md');
$assert(str_contains($dependencyDoc, 'Pass 2'), 'dependency inventory records Pass 2 boundary conversion');
$assert(str_contains($dependencyDoc, 'System/Infrastructure/Compatibility/Crm'), 'dependency inventory identifies isolated CRM compatibility boundary');

$verify = $read('bin/verify-extraction.php');
$assert(str_contains($verify, 'TitanFieldPass2DomainBoundariesTest.php'), 'embedded verifier includes Pass 2 boundary regression checks');
$assert(str_contains($verify, 'System/Contracts/FieldTenantContext.php'), 'embedded verifier checks Field-owned contracts');
$assert(str_contains($verify, 'System/Infrastructure/Compatibility/Crm'), 'embedded verifier checks CRM compatibility isolation');

if ($failures !== []) {
    fwrite(STDERR, "FAIL Titan Field Pass 2 domain-boundary contract\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    fwrite(STDERR, sprintf("Passed assertions: %d; failed assertions: %d\n", count($passes), count($failures)));
    exit(1);
}

echo sprintf("PASS Titan Field Pass 2 domain-boundary contract (%d assertions)\n", count($passes));
