<?php

declare(strict_types=1);

$root=dirname(__DIR__);$fail=[];$pass=[];
$a=static function(bool $c,string $m)use(&$fail,&$pass){if($c){$pass[]=$m;}else{$fail[]=$m;}};
$r=static function(string $f)use($root):string{$p=$root.'/'.$f;return is_file($p)?(string)file_get_contents($p):'';};

$files=[
'System/Domains/FieldServices/Recurring/RecurrenceCalculator.php',
'System/Domains/FieldServices/Scheduling/WorkerAvailabilityPolicy.php',
'System/Domains/FieldServices/Scheduling/OperationalBlackoutPolicy.php',
'database/migrations/2026_08_17_000004_add_titan_field_availability_blackout_policies.php',
];
foreach($files as $f)$a(is_file($root.'/'.$f),"Pass 6 file exists: {$f}");

$calc=$r($files[0]);$availability=$r($files[1]);$blackout=$r($files[2]);$migration=$r($files[3]);
$engine=$r('System/Domains/FieldServices/Recurring/RecurringServiceEngine.php');$kernel=$r('System/Domains/FieldServices/Scheduling/SchedulingKernel.php');$provider=$r('System/TitanFieldServiceProvider.php');

foreach(['weekdays','day_of_month','nth_weekday','include_dates','exclude_dates','interval','frequency'] as $t)$a(str_contains($calc,$t),"recurrence calculator supports {$t}");
$a(str_contains($calc,'nextAfter('),'recurrence calculator exposes nextAfter');
$a(str_contains($calc,'occurrencesBetween('),'recurrence calculator supports deterministic preview/range calculation');
$a(str_contains($engine,'RecurrenceCalculator'),'recurring engine delegates recurrence math');
$a(str_contains($engine,"recurrence_rule"),'recurring agreement stores recurrence rule in preferences');
$a(!str_contains($engine,'private function nextOccurrence('),'legacy inline cadence calculator removed');

foreach(['titan_field_worker_availability_rules','titan_field_worker_availability_exceptions','titan_field_blackout_policies'] as $table){
 $a(str_contains($migration,$table),"migration defines {$table}");
 $a(str_contains($migration,"Schema::hasTable('{$table}')"),"migration restartable for {$table}");
}
$a(!preg_match('/public function down\(\): void[\s\S]*?(dropIfExists|->drop\()/',$migration),'Pass 6 policy migration retains operational history on rollback');
foreach(['company_id','worker_user_id','day_of_week','starts_at','ends_at','effective_from','effective_until'] as $t)$a(str_contains($migration,$t),"availability schema carries {$t}");
foreach(['scope_type','scope_public_id','postcode','starts_at','ends_at','reason'] as $t)$a(str_contains($migration,$t),"blackout schema carries {$t}");

$a(str_contains($availability,'assertAvailable('),'worker availability policy exposes assertion');
$a(str_contains($availability,'titan_field_worker_availability_exceptions'),'availability policy checks normalized exceptions');
$a(str_contains($availability,'titan_field_worker_availability_rules'),'availability policy checks normalized rules');
$a(str_contains($availability,'crm_field_worker_time_off'),'availability policy preserves historical approved time-off');
$a(str_contains($blackout,'assertNotBlocked('),'blackout policy exposes assertion');
$a(str_contains($blackout,'scope_type'),'blackout policy supports generalized scopes');
foreach(['business','service','service_area','postcode','worker'] as $scope)$a(str_contains($blackout,"'{$scope}'"),"blackout policy supports {$scope} scope");
$a(str_contains($kernel,'WorkerAvailabilityPolicy'),'scheduling kernel consumes normalized worker availability');
$a(str_contains($kernel,'OperationalBlackoutPolicy'),'scheduling kernel consumes operational blackout policy');
$a(str_contains($kernel,'assertNotBlocked'),'scheduling rejects blackout windows');
$a(str_contains($kernel,'assertAvailable'),'scheduling rejects normalized availability violations');
$a(str_contains($kernel,'assertWeeklyAvailability'),'legacy JSON availability remains as compatibility fallback');

foreach(['RecurrenceCalculator::class','WorkerAvailabilityPolicy::class','OperationalBlackoutPolicy::class'] as $t)$a(str_contains($provider,$t),"provider exposes Pass 6 service: {$t}");

$manifest=json_decode($r('docs/extension-manifest-v1-legacy-reference.json'),true);$a(is_array($manifest),'manifest parses');
if(is_array($manifest)){$release=(string)($manifest['version']??'');$a(version_compare($release,'1.0.0-alpha.7','>='),'manifest retains Pass 6 contract at alpha.7 or later');$a(($manifest['recurrence_policy']??null)==='advanced_recurrence_availability_blackout_v1','manifest declares Pass 6 contract');}
$verify=$r('bin/verify-extraction.php');foreach(['RecurrenceCalculator','WorkerAvailabilityPolicy','OperationalBlackoutPolicy','titan_field_blackout_policies'] as $t)$a(str_contains($verify,$t),"embedded verifier enforces Pass 6 token: {$t}");

if($fail){fwrite(STDERR,"FAIL Titan Field Pass 6 recurrence/availability policy contract\n");foreach($fail as $f)fwrite(STDERR," - {$f}\n");fwrite(STDERR,sprintf("Passed assertions: %d; failed assertions: %d\n",count($pass),count($fail)));exit(1);}echo sprintf("PASS Titan Field Pass 6 recurrence/availability policy contract (%d assertions)\n",count($pass));
