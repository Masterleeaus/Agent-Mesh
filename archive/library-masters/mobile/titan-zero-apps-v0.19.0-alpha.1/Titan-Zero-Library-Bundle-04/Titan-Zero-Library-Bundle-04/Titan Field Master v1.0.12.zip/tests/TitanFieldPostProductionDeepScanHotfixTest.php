<?php
declare(strict_types=1);
$root=dirname(__DIR__);$n=0;$fails=[];$ok=function(bool $v,string $m)use(&$n,&$fails){$n++;if(!$v)$fails[]=$m;};
$extension=json_decode(file_get_contents($root.'/extension.json'),true);
$legacyManifest = json_decode((string) file_get_contents($root.'/docs/extension-manifest-v1-legacy-reference.json'), true) ?: [];
$deps=$extension['dependencies']??[];$crmDep=is_array($deps)?current(array_values(array_filter($deps,static fn($d):bool=>is_array($d)&&($d['slug']??null)==='crm'))):false;$ok(is_array($crmDep)&&($crmDep['version']??null)==='>=1.3.0-alpha.17','CRM dependency permits staged schema install on alpha.17 in Installer 1.7.3 list format');$ok(($legacyManifest['titan_architecture']['activation_floor']??null)==='crm>=1.3.0-alpha.24','authoritative Field activation remains gated to CRM alpha.24+');
$runtime=file_get_contents($root.'/System/Domains/FieldServices/Offline/OfflineFieldRuntime.php');
$ok(str_contains($runtime,'insertOrIgnore'),'offline receipt reservation is atomic');
$ok(str_contains($runtime,'processing_lease_seconds'),'processing receipts have an abandoned-operation lease');
$ok(str_contains($runtime,'reserveReceipt'),'offline receipt reservation is centralized');
$ok(!str_contains($runtime,"->where('id',\$existing->id)->delete()"),'failed retries do not delete the unique receipt row');
$ok(str_contains($runtime,"status'=>'processing'")||str_contains($runtime,"'status'=>'processing'"),'processing reservation state retained');
$fallback=file_get_contents($root.'/System/Infrastructure/Spatial/FallbackSpatialIntelligenceGateway.php');
$ok(str_contains($fallback,"crm_field_worker_profiles"),'fallback live positions re-check active worker profile');
$ok(str_contains($fallback,"location_tracking_consent"),'fallback live positions re-check current tracking consent');
$ok(str_contains($fallback,"titan_field_routes"),'fallback live positions require an active current route/shift');

$offlineFallbackStart=strpos($fallback,'function syncOfflineWorkerLocations');
$offlineFallback=$offlineFallbackStart===false?'':substr($fallback,$offlineFallbackStart,7500);
$ok(str_contains($offlineFallback,"json_decode((string)(\$existing->metadata"),'fallback offline dedupe restores stored live/historical classification from metadata');
$ok(!str_contains($offlineFallback,"'historical_only'=>(bool)(\$existing->offline_sync"),'fallback offline dedupe does not misclassify every offline sample as historical');
$ok(is_file($root.'/System/Console/PruneFieldWorkerLocationPingsCommand.php'),'Field fallback GPS retention has a pruning command');
$provider=file_get_contents($root.'/System/TitanFieldServiceProvider.php');
$ok(str_contains($provider,'PruneFieldWorkerLocationPingsCommand'),'Field provider registers pruning command');
$ok(str_contains($provider,'titan-field:prune-worker-location'),'Field provider schedules pruning');
$config=file_get_contents($root.'/config/titan-field.php');
$ok(str_contains($config,"'processing_lease_seconds'"),'offline processing lease is configurable');

$menu=file_get_contents($root.'/System/Navigation/TitanFieldMenuDefinition.php');
$ok(!preg_match("/'label'\s*=>\s*'[^']*&[^']*'/",$menu),'Field menu labels avoid ampersands that host navigation may HTML-encode');
if($fails){fwrite(STDERR,"FAIL post-production Field hotfix gate\n - ".implode("\n - ",$fails)."\nPassed assertions: ".($n-count($fails))."; failed assertions: ".count($fails)."\n");exit(1);}echo "PASS Titan Field post-production deep-scan hotfix ($n assertions)\n";
