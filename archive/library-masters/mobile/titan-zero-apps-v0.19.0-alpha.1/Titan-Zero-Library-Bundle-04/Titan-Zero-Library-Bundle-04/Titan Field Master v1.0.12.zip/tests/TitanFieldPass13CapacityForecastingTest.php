<?php
$root=dirname(__DIR__); $fails=[]; $ok=0;
$check=function(bool $v,string $m)use(&$fails,&$ok){if($v){$ok++;}else{$fails[]=$m;}};
$read=fn($p)=>(string)@file_get_contents($root.'/'.$p);
$manifest=json_decode($read('docs/extension-manifest-v1-legacy-reference.json'),true)?:[];
$check(version_compare((string)($manifest['version']??'0'),'1.0.0-alpha.14','>='),'Field version not advanced to Pass 13');
$check(($manifest['titan_architecture']['capacity_forecasting']??null)==='read_only_predictive_capacity_v1','capacity forecasting architecture marker missing');
foreach([
'System/Domains/FieldServices/Forecasting/CapacityForecastCalculator.php',
'System/Domains/FieldServices/Forecasting/CapacityForecastService.php',
'docs/PASS13_CAPACITY_FORECASTING.md'
] as $p)$check(is_file($root.'/'.$p),'missing '.$p);
$contract=$read('System/Contracts/SpatialIntelligenceGateway.php');
$check(str_contains($contract,'capacityPressureEvidence'),'spatial contract missing capacityPressureEvidence');
foreach(['System/Infrastructure/Spatial/FallbackSpatialIntelligenceGateway.php','System/Infrastructure/Spatial/OptionalTitanMapsSpatialIntelligenceGateway.php'] as $p)$check(str_contains($read($p),'capacityPressureEvidence'),$p.' missing capacityPressureEvidence');
$service=$read('System/Domains/FieldServices/Forecasting/CapacityForecastService.php');
foreach(['crm_field_worker_profiles','titan_field_worker_availability_rules','titan_field_worker_availability_exceptions','crm_field_worker_time_off','crm_appointments','crm_work_orders','crm_service_requests','crm_services','crm_service_locations','capacityPressureEvidence','skill_pressure','service_area_pressure','unfilled_demand_minutes','spatial_pressure'] as $t)$check(str_contains($service,$t),'capacity forecast service missing '.$t);
$check(!str_contains($service,'->insert('),'capacity forecast service must remain read-only');
$check(!str_contains($service,'->update('),'capacity forecast service must remain read-only');
$calc=$read('System/Domains/FieldServices/Forecasting/CapacityForecastCalculator.php');
foreach(['effective_available_minutes','remaining_minutes','shortage_minutes','utilization_percent','coverage_percent','pressure_status','recommendations'] as $t)$check(str_contains($calc,$t),'capacity calculator missing '.$t);
$controller=$read('System/Http/Controllers/FieldServiceController.php');
$check(str_contains($controller,'CapacityForecastService'),'controller missing CapacityForecastService');
$check(str_contains($controller,'capacityForecast'),'controller missing capacity forecast endpoint');
$routes=$read('routes/web.php'); $check(str_contains($routes,'field-services.capacity'),'capacity forecast route missing');
$view=$read('resources/views/field-services/capacity.blade.php'); foreach(['Capacity forecast','Unfilled demand','Skill pressure','Service-area pressure','Spatial pressure','read-only forecast'] as $t)$check(str_contains(strtolower($view),strtolower($t)),'capacity UI missing '.$t);
$provider=$read('System/TitanFieldServiceProvider.php'); $check(str_contains($provider,'CapacityForecastService'),'provider missing CapacityForecastService');
$verify=$read('bin/verify-extraction.php'); $check(str_contains($verify,'Pass 13'),'embedded verifier missing Pass 13');
$calcFile=$root.'/System/Domains/FieldServices/Forecasting/CapacityForecastCalculator.php';
if(is_file($calcFile)){
 require_once $calcFile; $class='App\\Extensions\\TitanField\\System\\Domains\\FieldServices\\Forecasting\\CapacityForecastCalculator'; $c=new $class();
 $r=$c->calculate(['available_minutes'=>960,'booked_minutes'=>720,'unfilled_demand_minutes'=>480,'spatial_travel_burden_minutes'=>120,'spatial_uncovered_demand_count'=>0]);
 $check(($r['effective_available_minutes']??null)===840,'effective capacity expected 840');
 $check(($r['remaining_minutes']??null)===120,'remaining capacity expected 120');
 $check(($r['shortage_minutes']??null)===360,'shortage expected 360');
 $check(abs((float)($r['utilization_percent']??0)-85.7143)<0.01,'utilization expected ~85.71');
 $check(($r['pressure_status']??null)==='critical','shortage should be critical');
 $u=$c->calculate(['available_minutes'=>0,'booked_minutes'=>0,'unfilled_demand_minutes'=>0,'spatial_travel_burden_minutes'=>null,'spatial_uncovered_demand_count'=>0]);
 $check(($u['pressure_status']??null)==='unknown','zero-evidence capacity should be unknown');
}
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n"); fwrite(STDERR,count($fails)." failures\n"); exit(1);} echo "PASS Titan Field Pass 13 capacity forecasting ($ok assertions)\n";
