<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$checks = 0; $failures = [];
$assert = static function (bool $ok, string $message) use (&$checks, &$failures): void {
    $checks++;
    if (! $ok) $failures[] = $message;
};

$manifest = json_decode((string) file_get_contents($root.'/extension.json'), true);
$legacyManifest = json_decode((string) file_get_contents($root.'/docs/extension-manifest-v1-legacy-reference.json'), true) ?: [];
$deps = $manifest['dependencies'] ?? null;
$assert(is_array($deps) && array_is_list($deps), 'Extension Manager 1.7.3 dependencies is a JSON list');
if (is_array($deps)) {
    foreach ($deps as $i => $dependency) {
        $assert(is_array($dependency), "dependencies[$i] is an object");
        $assert(is_string($dependency['slug'] ?? null) && trim((string) $dependency['slug']) !== '', "dependencies[$i] contains slug");
        $assert(is_string($dependency['version'] ?? null) && trim((string) $dependency['version']) !== '', "dependencies[$i] contains version");
    }
}
$assert(($deps[0]['slug'] ?? null) === 'crm', 'CRM dependency uses slug crm');
$assert(($deps[0]['version'] ?? null) === '>=1.3.0-alpha.17', 'CRM dependency permits schema-only staged install on current alpha.17 host');
$assert(($legacyManifest['titan_architecture']['activation_floor'] ?? null) === 'crm>=1.3.0-alpha.24', 'authoritative activation remains blocked until CRM alpha.24');

/** @return list<array{file:string,name:string,length:int}> */
function generatedMysqlNames(string $root): array {
    $problems = [];
    foreach (glob($root.'/database/migrations/*.php') ?: [] as $file) {
        $source = (string) file_get_contents($file);
        preg_match_all("/Schema::create\\('([^']+)'\\s*,\\s*function\\s*\\(Blueprint\\s*\\$(\\w+)\\).*?\\{([\\s\\S]*?)\\n\\s*\\}\\);/", $source, $creates, PREG_SET_ORDER);
        foreach ($creates as $create) {
            [$all, $table, $var, $body] = $create;
            preg_match_all('/\\$'.preg_quote($var,'/').'->\\w+\\(\'([^\']+)\'[^;]*?\\)->(index|unique)\\(\\)/', $body, $columns, PREG_SET_ORDER);
            foreach ($columns as $column) {
                $name = $table.'_'.$column[1].'_'.$column[2];
                if (strlen($name) > 64) $problems[] = ['file'=>basename($file),'name'=>$name,'length'=>strlen($name)];
            }
            preg_match_all('/\\$'.preg_quote($var,'/').'->(index|unique)\\(\\[([^\\]]+)\\]\\s*\\)/', $body, $compound, PREG_SET_ORDER);
            foreach ($compound as $entry) {
                preg_match_all("/'([^']+)'/", $entry[2], $cols);
                $name = $table.'_'.implode('_', $cols[1] ?? []).'_'.$entry[1];
                if (strlen($name) > 64) $problems[] = ['file'=>basename($file),'name'=>$name,'length'=>strlen($name)];
            }
        }
    }
    return $problems;
}

$longNames = generatedMysqlNames($root);
$assert($longNames === [], 'all Laravel-generated MySQL index/unique identifiers are <=64 characters: '.json_encode($longNames));

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL $failure\n");
    fwrite(STDERR, "Failed: ".count($failures)." / $checks\n");
    exit(1);
}
echo "PASS Titan Field Installer 1.7.3/MySQL compatibility ($checks assertions)\n";
