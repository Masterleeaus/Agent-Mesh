<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$n=0;$fail=[];
$ok=function(bool $v,string $m)use(&$n,&$fail){$n++;if(!$v)$fail[]=$m;};

$extension=json_decode(file_get_contents($root.'/extension.json'),true);
$legacyManifest = json_decode((string) file_get_contents($root.'/docs/extension-manifest-v1-legacy-reference.json'), true) ?: [];
$deps=$extension['dependencies']??[];
$crm=is_array($deps)?current(array_values(array_filter($deps,static fn($d):bool=>is_array($d)&&($d['slug']??null)==='crm'))):false;
$ok(is_array($crm)&&($crm['version']??null)==='>=1.3.0-alpha.17','installer dependency accepts current CRM alpha.17 host');
$ok(($legacyManifest['titan_architecture']['activation_floor']??null)==='crm>=1.3.0-alpha.24','manifest records authoritative activation floor');
$ok(($legacyManifest['titan_architecture']['staged_activation']??null)==='schema_only_until_activation_floor','manifest declares staged activation behavior');

$config=file_get_contents($root.'/config/titan-field.php');
$ok(str_contains($config,"'minimum_authoritative_crm' => '1.3.0-alpha.24'"),'config retains alpha.24 authoritative activation floor');

$gatePath=$root.'/System/Activation/TitanFieldActivationGate.php';
$ok(is_file($gatePath),'activation gate exists');
if(is_file($gatePath)){
  $gate=file_get_contents($gatePath);
  $ok(str_contains($gate,"where('slug', 'crm')"),'activation gate resolves CRM from extension registry');
  $ok(str_contains($gate,'version_compare'),'activation gate uses semantic version comparison');
  $ok(str_contains($gate,"config('titan-field.compatibility.minimum_authoritative_crm'"),'activation gate reads configured floor');
  $ok(str_contains($gate,'catch (\\Throwable)'), 'activation gate fails closed on registry errors');
}

$provider=file_get_contents($root.'/System/TitanFieldServiceProvider.php');
$ok(str_contains($provider,'TitanFieldActivationGate'),'provider uses activation gate');
$ok(str_contains($provider,'$activationReady = $activation->isAuthoritativeReady();'),'provider computes activation state');
$ok(str_contains($provider,'if (! $activationReady) {') && str_contains($provider,'Schema-only staged install'),'register returns before operational bindings in staged mode');
$ok(str_contains($provider,'if ($activationReady) {') && str_contains($provider,'FieldCommandGateway::class, GovernedFieldCommandGateway::class'),'command gateway binding is activation-gated');
$ok(str_contains($provider,'if (! $activation->isAuthoritativeReady())') && str_contains($provider,'return;'),'boot exits after migrations/views when CRM is below floor');
$ok(str_contains($provider,'$this->loadMigrationsFrom'),'migrations always load for staged install');
$ok(str_contains($provider,'$this->loadViewsFrom'),'views may load during staged install');
$ok(str_contains($provider,"'titan-field.workforce-manifest'"),'workforce contribution remains available after activation');
$ok(strpos($provider,"'titan-field.workforce-manifest'") > strpos($provider,'if ($activationReady) {'),'workforce contribution binding is activation-gated');

if($fail){foreach($fail as $x)fwrite(STDERR,"FAIL $x\n");exit(1);}
echo "PASS: $n assertions\n";
