<?php

declare(strict_types=1);

$root=dirname(__DIR__);$fail=[];$pass=[];
$a=static function(bool $c,string $m)use(&$fail,&$pass){if($c){$pass[]=$m;}else{$fail[]=$m;}};
$r=static function(string $f)use($root):string{$p=$root.'/'.$f;return is_file($p)?(string)file_get_contents($p):'';};

$files=[
 'System/Domains/FieldServices/Scheduling/RecommendationEvidenceStore.php',
 'database/migrations/2026_08_18_000005_create_titan_field_recommendation_snapshots.php',
 'docs/PASS8_RECOMMENDATION_DECISION_EVIDENCE.md',
];
foreach($files as $f)$a(is_file($root.'/'.$f),"Pass 8 file exists: {$f}");

$svc=$r('System/Domains/FieldServices/Scheduling/TechnicianRecommendationService.php');
$store=$r($files[0]);$provider=$r('System/TitanFieldServiceProvider.php');$migration=$r($files[1]);
foreach(['POLICY_VERSION','recommendation_id','policy_version','rolling_workload','territory','route_fit','continuity','source_facts','scoreEligible'] as $t)$a(str_contains($svc,$t),"recommendation hardening contains {$t}");
foreach(['crm_appointments','scheduled_start','scheduled_end','7','daily_load_minutes'] as $t)$a(str_contains($svc,$t),"workload balancing evidence contains {$t}");
foreach(['service_area_public_ids','preferred_postcodes','territory_postcodes'] as $t)$a(str_contains($svc,$t),"worker territory preference supports {$t}");
$a(str_contains($svc,'previous')&&str_contains($svc,'next'),'route fit considers both previous and next appointment adjacency');
$a(str_contains($svc,'recommendationHash')||str_contains($svc,'recommendation_hash'),'recommendations expose deterministic evidence hash');
$a(str_contains($svc,'RecommendationEvidenceStore'),'recommendation service persists decision evidence through dedicated store');
$a(!str_contains($store,'update(')&&!str_contains($store,'updateOrInsert'),'recommendation evidence store is append-only/immutable');
foreach(['titan_field_recommendation_snapshots','context_hash','recommendation_hash','recommendations','policy_version','trace_id','correlation_id'] as $t)$a(str_contains($store.$migration,$t),"decision evidence persistence carries {$t}");
$a(str_contains($provider,'RecommendationEvidenceStore::class'),'provider binds recommendation evidence store');

$manifest=json_decode($r('docs/extension-manifest-v1-legacy-reference.json'),true);$a(is_array($manifest),'manifest parses');
if(is_array($manifest)){
 $a(version_compare((string)($manifest['version']??''),'1.0.0-alpha.9','>='),'manifest advanced to alpha.9');
 $a(($manifest['recommendation_policy']??null)==='explainable_balanced_decision_evidence_v3','manifest declares Pass 8 recommendation policy');
}
$cap=json_decode($r('CAPABILITIES.json'),true);$a(is_array($cap),'capabilities parse');if(is_array($cap))$a(version_compare((string)($cap['release']??''),'1.0.0-alpha.9','>='),'capability release advanced to alpha.9');
$verify=$r('bin/verify-extraction.php');foreach(['RecommendationEvidenceStore','titan_field_recommendation_snapshots','explainable_balanced_decision_evidence_v3','TitanFieldPass8RecommendationHardeningTest'] as $t)$a(str_contains($verify,$t),"embedded verifier enforces Pass 8 token: {$t}");

if($fail){fwrite(STDERR,"FAIL Titan Field Pass 8 recommendation hardening contract\n");foreach($fail as $f)fwrite(STDERR," - {$f}\n");fwrite(STDERR,sprintf("Passed assertions: %d; failed assertions: %d\n",count($pass),count($fail)));exit(1);}echo sprintf("PASS Titan Field Pass 8 recommendation hardening contract (%d assertions)\n",count($pass));
