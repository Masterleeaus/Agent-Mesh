<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];
$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) { $passes[] = $message; return; }
    $failures[] = $message;
};
$read = static function (string $relative) use ($root): string {
    $path = $root . '/' . $relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

foreach ([
    'System/Contracts/FieldCommandGateway.php',
    'System/Contracts/FieldCommandAuthorizer.php',
    'System/Contracts/FieldCommandRouter.php',
    'System/Infrastructure/Commands/GovernedFieldCommandGateway.php',
    'System/Infrastructure/Commands/FieldServiceCommandRouter.php',
    'System/Infrastructure/Commands/FieldCommandPermissionAuthorizer.php',
    'System/Security/FieldPermissionCatalog.php',
    'System/Security/FieldPermissionService.php',
    'System/Http/Middleware/TitanFieldPermissionGate.php',
    'database/migrations/2026_08_17_000003_create_titan_field_command_receipts.php',
] as $file) {
    $assert(is_file($root . '/' . $file), "Pass 5 command boundary exists: {$file}");
}

$gateway = $read('System/Infrastructure/Commands/GovernedFieldCommandGateway.php');
$router = $read('System/Infrastructure/Commands/FieldServiceCommandRouter.php');
$provider = $read('System/TitanFieldServiceProvider.php');
$migration = $read('database/migrations/2026_08_17_000003_create_titan_field_command_receipts.php');
$controller = $read('System/Http/Controllers/FieldServiceController.php');
$registry = $read('System/Domains/FieldServices/FieldServiceCapabilityRegistry.php');
$authorizer = $read('System/Infrastructure/Commands/FieldCommandPermissionAuthorizer.php');
$permissionCatalog = $read('System/Security/FieldPermissionCatalog.php');
$permissionService = $read('System/Security/FieldPermissionService.php');

foreach ([
    'FieldCommandGateway::class',
    'GovernedFieldCommandGateway::class',
    'FieldCommandAuthorizer::class',
    'FieldCommandPermissionAuthorizer::class',
    'FieldPermissionService::class',
    'TitanFieldPermissionGate::class',
    'FieldCommandRouter::class',
    'FieldServiceCommandRouter::class',
] as $token) {
    $assert(str_contains($provider, $token), "provider binds governed command token: {$token}");
}

$assert(str_contains($gateway, 'canonicalName('), 'gateway resolves canonical and legacy capability names through registry');
$assert(str_contains($gateway, "definition['kind']"), 'gateway checks capability kind before mutation');
$assert(str_contains($gateway, "required_for_mutations"), 'gateway enforces manifest idempotency requirement');
$assert(str_contains($gateway, 'FieldCommandAuthorizer'), 'gateway invokes command authorization port');
$assert(str_contains($gateway, 'FieldCommandRouter'), 'gateway delegates only after governance checks');
$assert(str_contains($gateway, "titan.field.command.receipt.v1"), 'gateway emits structured command receipt schema');
$assert(str_contains($gateway, 'request_hash'), 'gateway fingerprints command payloads');
$assert(str_contains($gateway, 'idempotency_hash'), 'gateway uses bounded deterministic idempotency hash');
$assert(str_contains($gateway, 'lockForUpdate'), 'gateway serializes receipt replay decisions');
$assert(str_contains($gateway, 'insertOrIgnore'), 'gateway handles concurrent idempotency reservation without duplicate execution');
$assert(str_contains($gateway, 'compensate('), 'gateway invokes command compensation when outer transaction fails after a side effect');
$assert(str_contains($router, 'Storage::disk'), 'command router can compensate evidence files after outer rollback');
$assert(str_contains($gateway, 'transaction('), 'gateway keeps command receipt and domain mutation in one transaction');
$assert(str_contains($gateway, 'Idempotency key was already used with a different Titan Field command payload.'), 'gateway rejects conflicting idempotency replay');
$assert(str_contains($gateway, "['replayed'] = true") || str_contains($gateway, "'replayed' => true") || str_contains($gateway, "'replayed'=>true"), 'gateway returns explicit replay receipt');
foreach (['trace_id','correlation_id','causation_id','source','actor_user_id','company_id','requested_capability','capability_id','operation'] as $token) {
    $assert(str_contains($gateway, $token), "command receipt carries {$token}");
}

$assert(str_contains($migration, "Schema::hasTable('titan_field_command_receipts')"), 'command receipt migration is restartable');
$assert(str_contains($migration, "idempotency_hash"), 'command receipt migration stores idempotency hash');
$assert(str_contains($migration, "request_hash"), 'command receipt migration stores request fingerprint');
$assert(str_contains($migration, "unique(['company_id', 'idempotency_hash']") || str_contains($migration, "unique(['company_id','idempotency_hash']"), 'command receipt uniqueness is bounded and tenant scoped');
$down = strpos($migration, 'public function down(): void');
$downText = $down === false ? '' : substr($migration, $down);
$assert($down !== false && !str_contains($downText, 'dropIfExists') && !str_contains($downText, 'drop('), 'command receipt rollback retains audit/replay history');

$assert(str_contains($authorizer, 'FieldPermissionService'), 'command authorizer delegates to Field-owned permission service');
$assert(str_contains($authorizer, 'authorize('), 'command authorizer invokes Field permission authorization');
$assert(str_contains($permissionCatalog, 'LEGACY_ALIASES'), 'Field permission catalog preserves legacy CRM permission aliases');
foreach (['crm.field_services.manage','crm.service_requests.manage','crm.work_orders.manage','crm.scheduling.manage','crm.dispatch.manage','crm.recurring.manage','crm.forms.manage','crm.field_evidence.manage','crm.service_areas.manage','crm.support.manage','crm.reviews.manage'] as $legacyPermission) {
    $assert(str_contains($permissionCatalog, $legacyPermission), "legacy permission alias retained: {$legacyPermission}");
}
$assert(str_contains($permissionService, 'Gate::has'), 'Field permission service honors host gates when defined');
$assert(str_contains($permissionService, 'strict_host_gates'), 'Field permission service supports fail-closed strict host-gate mode');
$assert(!str_contains($permissionService, 'CrmPermissionService'), 'Field permission ownership no longer depends on CRM permission catalogue');
$assert(!str_contains($gateway, 'App\\Extensions\\Crm\\'), 'governed command gateway has no direct CRM dependency');
$assert(str_contains($registry, 'permission'), 'capability registry exposes command permission metadata');

$expectedRoutes = [
    'titan.field.verticals|apply',
    'titan.field.catalogue|create_service',
    'titan.field.locations|create_location',
    'titan.field.requests|create_request',
    'titan.field.requests|transition_request',
    'titan.field.work_orders|create_work_order',
    'titan.field.work_orders|create_from_request',
    'titan.field.work_orders|transition_work_order',
    'titan.field.work_orders|add_task',
    'titan.field.work_orders|set_task_status',
    'titan.field.work_orders|add_time_entry',
    'titan.field.work_orders|add_material',
    'titan.field.forms|start_submission',
    'titan.field.evidence|store_evidence',
    'titan.field.scheduling|schedule_appointment',
    'titan.field.dispatch|assign_dispatch',
    'titan.field.dispatch|transition_dispatch',
    'titan.field.recurring|create_agreement',
    'titan.field.recurring|generate_due_occurrences',
    'titan.field.recurring|set_agreement_status',
    'titan.field.forms|create_template',
    'titan.field.forms|publish_template',
    'titan.field.support|create_ticket',
    'titan.field.assets|create_asset',
    'titan.field.service_areas|create_service_area',
    'titan.field.service_areas|update_service_area',
];
foreach ($expectedRoutes as $route) {
    [$capability,$operation] = explode('|',$route,2);
    $assert(str_contains($router, "'{$capability}|{$operation}'"), "command router exposes {$route}");
}

$mutatingControllerMethods = [
    'applyVertical','storeService','storeLocation','storeRequest','requestStatus','storeWorkOrder','workOrderFromRequest','workOrderStatus',
    'storeWorkOrderTask','workOrderTaskStatus','storeTimeEntry','storeMaterial','startWorkOrderForm','storeEvidence','storeAppointment','assignDispatch',
    'dispatchStatus','storeAgreement','generateRecurring','agreementStatus','storeForm','publishForm','storeSupport','storeAsset','storeServiceArea','updateServiceArea',
];
$assert(str_contains($controller, 'FieldCommandGateway'), 'controller receives governed command gateway');
foreach ($mutatingControllerMethods as $method) {
    $pattern = '/public function\s+' . preg_quote($method,'/') . '\b[\s\S]*?(?=\n\s*public function|\n}\s*$)/';
    preg_match($pattern, $controller, $m);
    $body = $m[0] ?? '';
    $assert($body !== '', "controller mutation method found: {$method}");
    $assert(str_contains($body, '$this->commands->execute('), "controller mutation enters command gateway: {$method}");
}

$capabilities = json_decode($read('CAPABILITIES.json'), true);
$assert(is_array($capabilities), 'CAPABILITIES.json parses for Pass 5');
if (is_array($capabilities)) {
    $release=(string)($capabilities['release']??'');$assert(version_compare($release,'1.0.0-alpha.6','>='), 'capability manifest retains Pass 5 contract at alpha.6 or later');
    $assert(($capabilities['governance_contract_status'] ?? null) === 'governed_command_gateway_v1', 'capability manifest declares governed command gateway');
    foreach (($capabilities['definitions'] ?? []) as $definition) {
        if (($definition['kind'] ?? '') !== 'read_write') continue;
        $assert(is_string($definition['permission'] ?? null) && ($definition['permission'] ?? '') !== '', 'read_write capability declares permission: '.($definition['id'] ?? 'unknown'));
    }
}

$verify = $read('bin/verify-extraction.php');
foreach (['GovernedFieldCommandGateway','titan_field_command_receipts','governed_command_gateway_v1','FieldCommandAuthorizer','FieldPermissionCatalog'] as $token) {
    $assert(str_contains($verify, $token), "embedded verifier enforces Pass 5 token: {$token}");
}

if ($failures !== []) {
    fwrite(STDERR, "FAIL Titan Field Pass 5 governed command gateway contract\n");
    foreach ($failures as $failure) fwrite(STDERR, " - {$failure}\n");
    fwrite(STDERR, sprintf("Passed assertions: %d; failed assertions: %d\n", count($passes), count($failures)));
    exit(1);
}

echo sprintf("PASS Titan Field Pass 5 governed command gateway contract (%d assertions)\n", count($passes));
