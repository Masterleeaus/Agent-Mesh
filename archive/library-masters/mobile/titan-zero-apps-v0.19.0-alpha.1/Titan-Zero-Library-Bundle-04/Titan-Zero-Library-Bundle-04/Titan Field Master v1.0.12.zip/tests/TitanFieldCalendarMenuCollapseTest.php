<?php

declare(strict_types=1);

$root=dirname(__DIR__);$n=0;$fail=[];
$ok=static function(bool $v,string $m)use(&$n,&$fail):void{$n++;if(!$v)$fail[]=$m;};
$installer=file_get_contents($root.'/System/Navigation/TitanFieldMenuInstaller.php');

$ok(str_contains($installer,"where('key', 'crm_calendar')"),'menu repair detects legacy crm_calendar row');
$ok(str_contains($installer,"where('key', 'ext_crm_crew')"),'menu repair addresses Crew parent row');
$ok(substr_count($installer,'dashboard.user.titan-field.schedule')>=2,'staged Schedule route is used for child and Crew parent');
$ok(str_contains($installer,'dashboard.user.crm.field-services.schedule'),'active mode restores canonical authoritative Schedule route');
$ok(str_contains($installer,"'is_active' => 0"),'legacy Calendar row is deactivated');
$ok(str_contains($installer,'suppressLegacyCalendarDuplicate'),'active and staged sync share legacy Calendar suppression');
$ok(str_contains($installer,"suppressLegacyCalendarDuplicate(\$row->id ?? null, 'dashboard.user.titan-field.schedule')"),'staged suppression rewires legacy Calendar to the real staged Schedule route before hiding it');
$ok(str_contains($installer,'restoreCanonicalCrewScheduleRoute'),'authoritative activation restores Crew parent route');
$ok(str_contains($installer,'syncStagedCrewScheduleRoute'),'staged mode rewires Crew parent to read-only calendar');
$ok(str_contains($installer,"(string) (\$crew->route ?? '') !== 'dashboard.user.crm.field-services.schedule'"),'health check catches Crew parent route drift');
$ok(str_contains($installer,"(int) (\$legacyCalendar->is_active ?? 0) === 1"),'health check catches an active legacy Calendar duplicate');

if($fail){foreach($fail as $m)fwrite(STDERR,"FAIL $m\n");fwrite(STDERR,'Failed: '.count($fail)." / $n\n");exit(1);}echo "PASS Titan Field Calendar/Schedule menu collapse ($n assertions)\n";
