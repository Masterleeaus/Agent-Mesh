<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];

$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) {
        $passes[] = $message;
        return;
    }
    $failures[] = $message;
};

$read = static function (string $relative) use ($root): string {
    $path = $root . '/' . $relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

$provider = $read('System/TitanFieldServiceProvider.php');
$migration11 = $read('database/migrations/2026_08_09_000011_add_field_service_domains.php');
$migration12 = $read('database/migrations/2026_08_09_000012_add_field_service_profile_tracking.php');
$migration33 = $read('database/migrations/2026_08_15_000033_harden_crm_field_integrity.php');

$assert(str_contains($migration12, "Schema::hasTable('crm_field_service_profiles')"), 'profile migration is restartable');
$assert(str_contains($migration12, "Schema::hasColumn('crm_field_service_profiles'"), 'profile migration repairs partial existing tables');
$assert(!preg_match("/public function down\(\): void\s*\{[\s\S]*Schema::dropIfExists\('crm_field_service_profiles'\)/", $migration12), 'profile rollback retains installed data');
$assert(!preg_match("/public function down\(\): void\s*\{[\s\S]*Schema::dropIfExists\('crm_work_orders'\)/", $migration11), 'field-domain rollback retains historical work data');
$migration33Down = substr($migration33, (int) strpos($migration33, 'public function down(): void'));
$assert(!str_contains($migration33Down, 'dropIfExists') && !str_contains($migration33Down, 'dropColumn'), 'integrity hardening rollback retains worker and evidence data');

$canonicalProfiles = [
    'cleaning',
    'plumbing',
    'electrical',
    'hvac',
    'handyman-property-maintenance',
    'landscaping-gardening',
    'pest-control',
    'locksmith-security',
    'roofing-guttering',
    'appliance-equipment-repair',
];
foreach ($canonicalProfiles as $slug) {
    $path = $root . '/resources/field-services/verticals/' . $slug . '.json';
    $assert(is_file($path), "canonical vertical exists: {$slug}");
    if (! is_file($path)) {
        continue;
    }
    $json = json_decode((string) file_get_contents($path), true);
    $assert(is_array($json), "canonical vertical parses: {$slug}");
    $assert(($json['key'] ?? null) === $slug, "canonical vertical key matches slug: {$slug}");
    $assert(is_array($json['services'] ?? null) && ($json['services'] ?? []) !== [], "canonical vertical has services: {$slug}");
}

$menuDefinitionPath = $root . '/System/Navigation/TitanFieldMenuDefinition.php';
$menuInstallerPath = $root . '/System/Navigation/TitanFieldMenuInstaller.php';
$assert(is_file($menuDefinitionPath), 'Titan Field owns a menu definition');
$assert(is_file($menuInstallerPath), 'Titan Field owns a self-healing menu installer');
$menuDefinition = is_file($menuDefinitionPath) ? (string) file_get_contents($menuDefinitionPath) : '';
$menuInstaller = is_file($menuInstallerPath) ? (string) file_get_contents($menuInstallerPath) : '';

foreach ([
    'dashboard.user.crm.field-services.index',
    'dashboard.user.crm.field-services.requests',
    'dashboard.user.crm.field-services.work-orders',
    'dashboard.user.crm.field-services.agreements',
    'dashboard.user.crm.field-services.catalogue',
    'dashboard.user.crm.field-services.locations',
    'dashboard.user.crm.field-services.forms',
    'dashboard.user.crm.field-services.service-areas',
    'dashboard.user.crm.field-services.verticals',
    'dashboard.user.crm.field-services.schedule',
    'dashboard.user.crm.field-services.dispatch',
    'dashboard.user.crm.field-services.timesheets',
    'dashboard.user.crm.field-services.assets',
    'dashboard.user.crm.field-services.support',
    'dashboard.user.crm.field-services.reviews',
] as $route) {
    $assert(str_contains($menuDefinition, $route), "legacy CRM field route retained: {$route}");
}
$assert(!str_contains($menuDefinition, "'/dashboard/"), 'menu definition does not hard-code dashboard URLs');
$assert(str_contains($menuInstaller, "where('route', \$item['route'])") || str_contains($menuInstaller, "where('route', (string) \$item['route'])"), 'menu healer adopts existing CRM rows by route before inserting');
$assert(str_contains($menuInstaller, 'MenuService::class') && str_contains($menuInstaller, "'regenerate'"), 'menu healer regenerates host menu cache when available');
$assert(str_contains($menuInstaller, 'healIfNeeded'), 'menu installer supports runtime drift healing');
$assert(str_contains($menuInstaller, "whereNotNull('parent_id')"), 'route adoption cannot mistake a root menu for a child row');
$assert(str_contains($menuInstaller, 'activateExistingRoot'), 'preserved shared parent menus are reactivated without relabelling them');
$assert(str_contains($provider, 'ensureRouteFileLoaded'), 'provider has route-cache self-healing fallback');
$assert(str_contains($provider, 'dashboard.user.crm.field-services.index'), 'provider uses field-service route sentinel');
$assert(str_contains($provider, 'TitanFieldMenuInstaller'), 'provider invokes menu self-healing');

$verify = $read('bin/verify-extraction.php');
$assert(str_contains($verify, 'resources/field-services/verticals'), 'release verifier checks canonical vertical resources');
$assert(str_contains($verify, 'TitanFieldMenuInstaller'), 'release verifier checks menu self-healing implementation');
$assert(str_contains($verify, 'Schema::dropIfExists'), 'release verifier guards destructive rollback patterns');

if ($failures !== []) {
    fwrite(STDERR, "FAIL Titan Field Pass 1 hardening contract\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, " - {$failure}\n");
    }
    fwrite(STDERR, sprintf("Passed assertions: %d; failed assertions: %d\n", count($passes), count($failures)));
    exit(1);
}

echo sprintf("PASS Titan Field Pass 1 hardening contract (%d assertions)\n", count($passes));
