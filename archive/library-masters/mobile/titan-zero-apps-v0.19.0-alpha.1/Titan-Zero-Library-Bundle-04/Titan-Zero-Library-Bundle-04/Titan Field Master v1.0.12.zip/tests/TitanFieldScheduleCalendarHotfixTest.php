<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$count = 0;
$fail = [];
$ok = static function (bool $value, string $message) use (&$count, &$fail): void {
    $count++;
    if (! $value) $fail[] = $message;
};

$view = file_get_contents($root . '/resources/views/field-services/schedule.blade.php');
$controller = file_get_contents($root . '/System/Http/Controllers/FieldServiceController.php');
$menu = file_get_contents($root . '/System/Navigation/TitanFieldMenuDefinition.php');
$installer = file_get_contents($root . '/System/Navigation/TitanFieldMenuInstaller.php');

$ok(str_contains($menu, "'key' => 'crm_schedule', 'label' => 'Schedule'"), 'schedule menu label is Schedule');
$ok(str_contains($installer, "(string) (\$row->label ?? '') !== (string) (\$child['label'] ?? '')"), 'menu health detects stale child labels');
$ok(str_contains($view, "['title'=>'Schedule'"), 'page title is Schedule');
$ok(! str_contains($view, "<th>Appointment</th><th>Start</th><th>End</th><th>Status</th>"), 'old table-only schedule UI removed');
$ok(str_contains($view, 'schedule-calendar-grid'), 'real calendar grid is rendered');
foreach (['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'] as $day) {
    $ok(str_contains($view, $day), "calendar includes {$day} heading");
}
$ok(str_contains($view, "query('month')"), 'calendar month is navigable from request');
$ok(str_contains($controller, "modify('monday this week')") || str_contains($controller, "modify('last monday')"), 'controller builds a Monday-based calendar grid');
$ok(str_contains($controller, "'calendarWeeks'"), 'controller supplies calendar weeks');
$ok(str_contains($controller, "'previousMonth'"), 'controller supplies previous month navigation');
$ok(str_contains($controller, "'nextMonth'"), 'controller supplies next month navigation');
$ok(str_contains($controller, "'selectedDate'"), 'controller supplies selected-day agenda state');
$ok(str_contains($view, 'Today'), 'calendar has Today navigation');
$ok(str_contains($view, 'Previous month'), 'calendar has previous month navigation');
$ok(str_contains($view, 'Next month'), 'calendar has next month navigation');
$ok(str_contains($view, 'Selected day'), 'calendar includes selected-day agenda');

if ($fail) {
    foreach ($fail as $message) fwrite(STDERR, "FAIL {$message}\n");
    fwrite(STDERR, 'Failed: ' . count($fail) . " / {$count}\n");
    exit(1);
}

echo "PASS Titan Field Schedule calendar hotfix ({$count} assertions)\n";
