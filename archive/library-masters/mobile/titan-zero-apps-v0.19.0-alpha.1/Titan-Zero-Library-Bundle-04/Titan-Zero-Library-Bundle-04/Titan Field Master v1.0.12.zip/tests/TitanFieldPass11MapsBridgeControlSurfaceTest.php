<?php
$root=dirname(__DIR__); $fails=[]; $ok=0;
$check=function(bool $v,string $m)use(&$fails,&$ok){if($v){$ok++;}else{$fails[]=$m;}};
$read=fn($p)=>(string)@file_get_contents($root.'/'.$p);
$manifest=json_decode($read('docs/extension-manifest-v1-legacy-reference.json'),true)?:[];
$check(version_compare((string)($manifest['version']??'0'),'1.0.0-alpha.12','>='),'version not advanced to Pass 11');
$check(($manifest['titan_architecture']['maps_peer_bridge']??null)==='optional_titan_maps_spatial_peer_v1','maps peer architecture marker missing');
foreach([
'System/Contracts/SpatialIntelligenceGateway.php',
'System/Infrastructure/Spatial/FallbackSpatialIntelligenceGateway.php',
'System/Infrastructure/Spatial/OptionalTitanMapsSpatialIntelligenceGateway.php',
'System/Domains/FieldServices/Scheduling/CalendarDispatchControlService.php',
'resources/views/field-services/control.blade.php',
'docs/PASS11_FIELD_MAPS_CONTROL_SURFACE.md'
] as $p)$check(is_file($root.'/'.$p),'missing '.$p);
$contract=$read('System/Contracts/SpatialIntelligenceGateway.php'); foreach(['available','latestWorkerPositions','estimateTravel','recordWorkerLocation','mapPayload','mapUi'] as $t)$check(str_contains($contract,$t),'spatial contract missing '.$t);
$optional=$read('System/Infrastructure/Spatial/OptionalTitanMapsSpatialIntelligenceGateway.php'); foreach(['App\\\\Extensions\\\\TitanMapsIntelligence\\\\Contracts\\\\FieldSpatialPeerGateway','interface_exists','field-fallback','peerAvailable'] as $t)$check(str_contains($optional,$t),'optional Maps adapter missing '.$t);
$provider=$read('System/TitanFieldServiceProvider.php'); foreach(['SpatialIntelligenceGateway','OptionalTitanMapsSpatialIntelligenceGateway','CalendarDispatchControlService'] as $t)$check(str_contains($provider,$t),'provider missing '.$t);
$routeService=$read('System/Domains/FieldServices/Routing/RouteService.php');
$check(str_contains($routeService,'SpatialIntelligenceGateway'),'RouteService does not consume spatial gateway');
$check(str_contains($routeService,'recordWorkerLocation'),'RouteService does not delegate location recording');
$check(!str_contains($routeService,"table('titan_field_worker_location_pings')->insert"),'RouteService still directly owns preferred high-frequency ping insertion');
$control=$read('System/Domains/FieldServices/Scheduling/CalendarDispatchControlService.php'); foreach(['worker_lanes','route_overlays','exception_overlays','map_payload','spatial_provider'] as $t)$check(str_contains($control,$t),'control service missing '.$t);
$view=$read('resources/views/field-services/control.blade.php'); foreach(['data-titan-field-control-surface','data-titan-map-root','data-titan-map-payload','data-worker-lane','data-calendar-event','Move appointment','Resize appointment','Routes / ETA','Operational exceptions'] as $t)$check(str_contains($view,$t),'control view missing '.$t);
$routes=$read('routes/web.php'); foreach(['field-services.control','field-services.schedule.move','field-services.schedule.resize'] as $t)$check(str_contains($routes,$t),'route missing '.$t);
$controller=$read('System/Http/Controllers/FieldServiceController.php'); foreach(['function controlSurface','function moveAppointment','function resizeAppointment'] as $t)$check(str_contains($controller,$t),'controller missing '.$t);
$router=$read('System/Infrastructure/Commands/FieldServiceCommandRouter.php'); $check(str_contains($router,'titan.field.scheduling|reschedule_appointment'),'reschedule command operation missing');
$appointments=$read('System/Domains/FieldServices/Scheduling/AppointmentService.php'); foreach(['function reschedule','assertSchedulable','field.appointment.rescheduled'] as $t)$check(str_contains($appointments,$t),'appointment reschedule missing '.$t);
$verify=$read('bin/verify-extraction.php'); $check(str_contains($verify,'Pass 11'),'embedded verifier missing Pass 11');
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n"); fwrite(STDERR,count($fails)." failures\n"); exit(1);} echo "PASS Titan Field Pass 11 Maps bridge/control surface ($ok assertions)\n";
