<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$passes = [];
$assert = static function (bool $condition, string $message) use (&$failures, &$passes): void {
    if ($condition) $passes[] = $message; else $failures[] = $message;
};
$read = static function (string $relative) use ($root): string {
    $path = $root . '/' . $relative;
    return is_file($path) ? (string) file_get_contents($path) : '';
};

$guardFile = 'System/Domains/FieldServices/Integrity/FieldReferenceIntegrity.php';
$assert(is_file($root . '/' . $guardFile), 'central tenant/reference integrity guard exists');
$guard = $read($guardFile);
foreach ([
    "'company_public_id'=>'crm_companies'",
    "'contact_public_id'=>'crm_contacts'",
    "'location_public_id'=>'crm_service_locations'",
    "'asset_public_id'=>'crm_customer_assets'",
    "'service_public_id'=>'crm_services'",
    "'service_request_public_id'=>'crm_service_requests'",
    "'work_order_public_id'=>'crm_work_orders'",
    "'appointment_public_id'=>'crm_appointments'",
    "'form_public_id'=>'crm_form_templates'",
    "'form_submission_public_id'=>'crm_form_submissions'",
    "'review_request_public_id'=>'crm_review_requests'",
    "'review_public_id'=>'crm_reviews'",
    "'service_area_public_id'=>'crm_service_areas'",
    "'agreement_public_id'=>'crm_service_agreements'",
    "'lead_public_id'=>'crm_leads'",
    "'deal_public_id'=>'crm_deals'",
] as $token) $assert(str_contains($guard, $token), "guard maps tenant-owned reference {$token}");
foreach (['companyId', "where('company_id'", 'assertContext', 'assertWorker', 'assertTenantUser', 'assertServiceList', 'assertLocationOwnership', 'assertAssetOwnership'] as $token) {
    $assert(str_contains($guard, $token), "integrity guard contains {$token}");
}
$assert(str_contains($guard, 'crm_field_worker_profiles'), 'worker validation uses tenant-scoped field-worker profiles');
$assert(str_contains($read('System/Contracts/FieldTenantContext.php'), 'userBelongsToTenant'), 'tenant port exposes membership validation');
$assert(str_contains($read('System/Infrastructure/Compatibility/Crm/CrmFieldTenantContext.php'), 'actorBelongsToCompany'), 'CRM tenant adapter delegates membership validation');
$assert(str_contains($guard, "throw new InvalidArgumentException"), 'reference failures fail closed');

$services = [
    'System/Domains/FieldServices/Locations/ServiceLocationService.php' => ['assertContext'],
    'System/Domains/FieldServices/Assets/CustomerAssetService.php' => ['assertContext'],
    'System/Domains/FieldServices/Requests/ServiceRequestService.php' => ['assertContext'],
    'System/Domains/FieldServices/WorkOrders/WorkOrderService.php' => ['assertContext','assertWorker'],
    'System/Domains/FieldServices/Scheduling/AppointmentService.php' => ['assertContext'],
    'System/Domains/FieldServices/Scheduling/SchedulingKernel.php' => ['assertWorker'],
    'System/Domains/FieldServices/Dispatch/DispatchService.php' => ['assertContext','assertWorker'],
    'System/Domains/FieldServices/Recurring/RecurringServiceEngine.php' => ['assertContext'],
    'System/Domains/FieldServices/Forms/FormService.php' => ['assertContext'],
    'System/Domains/FieldServices/Evidence/FieldEvidenceService.php' => ['assertContext'],
    'System/Domains/FieldServices/Support/SupportService.php' => ['assertContext'],
    'System/Domains/FieldServices/Reviews/ReviewRecoveryService.php' => ['assertContext'],
    'System/Domains/FieldServices/Catalogue/ServiceCatalogueService.php' => ['assertContext'],
    'System/Domains/FieldServices/ServiceAreas/ServiceAreaMatcher.php' => ['assertServiceList'],
];
foreach ($services as $file => $calls) {
    $source = $read($file);
    $assert(str_contains($source, 'FieldReferenceIntegrity'), "{$file} depends on central integrity guard");
    foreach ($calls as $call) $assert(str_contains($source, '->'.$call.'('), "{$file} invokes {$call}");
}

$appointment = $read('System/Domains/FieldServices/Scheduling/AppointmentService.php');
$assert(str_contains($appointment, "'work_order_public_id'"), 'appointment validates work-order reference');
$assert(str_contains($appointment, "'service_request_public_id'"), 'appointment validates service-request reference');
$assert(str_contains($appointment, "'location_public_id'"), 'appointment validates location reference');

$dispatch = $read('System/Domains/FieldServices/Dispatch/DispatchService.php');
$assert(str_contains($dispatch, "'appointment_public_id'"), 'dispatch validates appointment reference');
$assert(! str_contains($dispatch, 'catch(\\Throwable){}'), 'dispatch no longer swallows work-order transition failures silently');

$workOrders = $read('System/Domains/FieldServices/WorkOrders/WorkOrderService.php');
$assert(str_contains($workOrders, "'service_request_public_id'"), 'work order validates source request');
$assert(str_contains($workOrders, "'asset_public_id'"), 'work order validates asset reference');
$assert(str_contains($workOrders, 'assertWorker($userId,$workerUserId'), 'time recording validates worker tenancy');
$assert(str_contains($workOrders, 'assertTenantUser'), 'work-order ownership validates tenant user membership');
$assert(str_contains($read('System/Domains/FieldServices/Requests/ServiceRequestService.php'), 'assertTenantUser'), 'service-request ownership validates tenant user membership');
$assert(str_contains($read('System/Domains/FieldServices/Support/SupportService.php'), 'assertTenantUser'), 'support ownership/authorship validates tenant user membership');

$catalogue = $read('System/Domains/FieldServices/Catalogue/ServiceCatalogueService.php');
$assert(str_contains($catalogue, "'category_public_id'"), 'catalogue validates category reference');
$assert(str_contains($catalogue, 'assertReferenceList'), 'catalogue validates referenced form-template lists');

$serviceAreas = $read('System/Domains/FieldServices/ServiceAreas/ServiceAreaMatcher.php');
$assert(str_contains($serviceAreas, 'assertServiceList'), 'service-area service restriction list is tenant validated');

$manifest = json_decode($read('docs/extension-manifest-v1-legacy-reference.json'), true);
$version=(string)($manifest['version']??'');$assert(version_compare($version,'1.0.0-alpha.4','>='), 'manifest remains at or beyond alpha.4');
$assert(($manifest['titan_architecture']['reference_integrity'] ?? null) === 'tenant_scoped_fail_closed', 'manifest declares fail-closed reference integrity');

$verify = $read('bin/verify-extraction.php');
$assert(str_contains($verify, 'TitanFieldPass3TenantReferenceIntegrityTest.php'), 'embedded verifier includes Pass 3 integrity regression gate');
$assert(str_contains($verify, 'FieldReferenceIntegrity.php'), 'embedded verifier requires central integrity guard');

if ($failures !== []) {
    fwrite(STDERR, "FAIL Titan Field Pass 3 tenant/reference-integrity contract\n");
    foreach ($failures as $failure) fwrite(STDERR, " - {$failure}\n");
    fwrite(STDERR, sprintf("Passed assertions: %d; failed assertions: %d\n", count($passes), count($failures)));
    exit(1);
}

echo sprintf("PASS Titan Field Pass 3 tenant/reference-integrity contract (%d assertions)\n", count($passes));
