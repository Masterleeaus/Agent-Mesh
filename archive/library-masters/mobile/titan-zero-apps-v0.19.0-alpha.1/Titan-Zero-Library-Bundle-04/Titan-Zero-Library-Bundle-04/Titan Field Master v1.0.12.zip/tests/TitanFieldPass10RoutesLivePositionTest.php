<?php
$root=dirname(__DIR__); $fails=[]; $ok=0;
$check=function(bool $v,string $m)use(&$fails,&$ok){if($v){$ok++;}else{$fails[]=$m;}};
$read=fn($p)=>(string)@file_get_contents($root.'/'.$p);
$manifest=json_decode($read('docs/extension-manifest-v1-legacy-reference.json'),true)?:[];
$caps=json_decode($read('CAPABILITIES.json'),true)?:[];
$check(version_compare((string)($manifest['version']??'0'),'1.0.0-alpha.11','>='),'version not advanced');
$check(($manifest['titan_architecture']['routes_live_position']??null)==='titan_field_routes_live_position_v1','manifest marker missing');
foreach([
'database/migrations/2026_08_18_000007_create_titan_field_routes_live_position.php',
'System/Domains/FieldServices/Routing/RouteService.php',
'System/Domains/FieldServices/Routing/WorkerLocationPolicy.php',
'resources/views/field-services/routes.blade.php',
'docs/PASS10_ROUTES_LIVE_POSITION_DESIGN.md'
] as $p)$check(is_file($root.'/'.$p),'missing '.$p);
$m=$read('database/migrations/2026_08_18_000007_create_titan_field_routes_live_position.php');
foreach(['titan_field_routes','titan_field_route_stops','titan_field_worker_location_pings','consent_granted_at','retention_expires_at','sequence','planned_arrival_at','actual_arrival_at'] as $t)$check(str_contains($m,$t),'migration missing '.$t);
$s=$read('System/Domains/FieldServices/Routing/RouteService.php');
foreach(['createForWorkerDay','addStop','resequence','transitionStop','recordLocationPing','FieldSignalPort','company_id','Route optimization is not claimed'] as $t)$check(str_contains($s,$t),'route service missing '.$t);
$p=$read('System/Domains/FieldServices/Routing/WorkerLocationPolicy.php');
foreach(['consent','active shift','retention','accuracy','assertCanRecord'] as $t)$check(str_contains($p,$t),'location policy missing '.$t);
$r=$read('routes/web.php'); foreach(['field-services.routes','field-services.routes.store','field-services.routes.stops.store','field-services.routes.stops.resequence','field-services.routes.stops.status','field-services.routes.location-ping'] as $t)$check(str_contains($r,$t),'route missing '.$t);
$c=$read('System/Http/Controllers/FieldServiceController.php'); foreach(['function routes','function storeRoute','function storeRouteStop','function resequenceRouteStops','function routeStopStatus','function recordWorkerLocation'] as $t)$check(str_contains($c,$t),'controller missing '.$t);
$router=$read('System/Infrastructure/Commands/FieldServiceCommandRouter.php'); foreach(['titan.field.routes|create_route','titan.field.routes|add_stop','titan.field.routes|resequence_stops','titan.field.routes|transition_stop','titan.field.routes|record_location'] as $t)$check(str_contains($router,$t),'command route missing '.$t);
$capIds=array_column($caps['definitions']??[],'id'); $check(in_array('titan.field.routes',$capIds,true),'route capability missing'); $check(in_array('crm.field.routes',$caps['capabilities']??[],true),'legacy route alias missing');
$menu=$read('System/Navigation/TitanFieldMenuDefinition.php'); $check(str_contains($menu,"'label' => 'Routes and Live Position'"),'menu entry missing');
$perms=$read('System/Security/FieldPermissionCatalog.php'); $check(str_contains($perms,'titan.field.routes.manage'),'permission missing');
$verify=$read('bin/verify-extraction.php'); $check(str_contains($verify,'Pass 10'),'embedded verifier missing Pass 10');
if($fails){foreach($fails as $f)fwrite(STDERR,"FAIL: $f\n"); fwrite(STDERR,count($fails)." failures\n"); exit(1);} echo "PASS Titan Field Pass 10 routes/live-position contract ($ok assertions)\n";
