<?php

declare(strict_types=1);

/*
 * Titan Field owns its runtime configuration namespace. During the extraction
 * bridge, defaults are inherited from CRM so installed businesses keep their
 * existing behaviour. Future passes can move each setting without touching the
 * domain services again.
 */
return [
    'compatibility' => [
        // Field may be staged on older CRM releases, but it must not become an authoritative writer
        // until CRM has crossed the Field-domain extraction boundary.
        'minimum_authoritative_crm' => '1.3.0-alpha.24',
    ],
    'middleware' => config('crm.middleware', ['web', 'auth']),
    'api_middleware' => config('crm.api_middleware', ['api', 'auth']),
    'offline' => [
        'maximum_offline_age_days' => 14,
        'maximum_batch_size' => 100,
        'maximum_future_skew_seconds' => 300,
        'fallback_live_position_max_age_minutes' => 30,
        'processing_lease_seconds' => 300,
    ],
    'field_services' => [
        'default_timezone' => config('crm.field_services.default_timezone', 'Australia/Melbourne'),
        'evidence_disk' => config('crm.field_services.evidence_disk', 'local'),
        'review_recovery_threshold' => config('crm.field_services.review_recovery_threshold', 2),
        'recurring_generation_limit' => config('crm.field_services.recurring_generation_limit', 100),
        'capabilities' => config('crm.field_services.capabilities', []),
        'location' => [
            'retention_days' => 7,
        ],
        'scheduling' => [
            'max_daily_minutes' => config('crm.field_services.scheduling.max_daily_minutes', 720),
            'default_travel_buffer_minutes' => config('crm.field_services.scheduling.default_travel_buffer_minutes', 0),
        ],
    ],

    'permissions' => [
        // When false, existing tenant isolation remains the baseline if the host has no Field-specific Gate definitions.
        // Set true in hardened hosts to require an explicit canonical or legacy Titan Field Gate.
        'strict_host_gates' => (bool) config('crm.permissions.strict_host_gates', false),
    ],
];
