<?php

declare(strict_types=1);

use App\Extensions\TitanField\System\Http\Controllers\FieldServiceController;
use App\Http\Middleware\CheckTemplateTypeAndPlan;
use App\Extensions\TitanField\System\Http\Middleware\EnsureTitanFieldHostEnabled;
use App\Extensions\TitanField\System\Http\Middleware\EnsureTitanFieldPermission;
use Illuminate\Support\Facades\Route;

Route::middleware(array_merge(config('titan-field.middleware', ['web','auth']), [EnsureTitanFieldHostEnabled::class, CheckTemplateTypeAndPlan::class]))
    ->prefix('dashboard/user/crm')
    ->name('dashboard.user.crm.')
    ->group(function (): void {
        Route::get('/field-services', [FieldServiceController::class, 'dashboard'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.index');
        Route::get('/field-services/verticals', [FieldServiceController::class, 'verticals'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.manage')->name('field-services.verticals');
        Route::post('/field-services/verticals/{profile}/apply', [FieldServiceController::class, 'applyVertical'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.manage')->name('field-services.verticals.apply');
        Route::get('/field-services/catalogue', [FieldServiceController::class, 'catalogue'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.catalogue');
        Route::post('/field-services/catalogue', [FieldServiceController::class, 'storeService'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.manage')->name('field-services.catalogue.store');
        Route::get('/field-services/locations', [FieldServiceController::class, 'locations'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.locations');
        Route::post('/field-services/locations', [FieldServiceController::class, 'storeLocation'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.manage')->name('field-services.locations.store');
        Route::get('/field-services/service-requests', [FieldServiceController::class, 'requests'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.requests');
        Route::post('/field-services/service-requests', [FieldServiceController::class, 'storeRequest'])->middleware(EnsureTitanFieldPermission::class . ':crm.service_requests.manage')->name('field-services.requests.store');
        Route::post('/field-services/service-requests/{serviceRequest}/status', [FieldServiceController::class, 'requestStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.service_requests.manage')->name('field-services.requests.status');
        Route::post('/field-services/service-requests/{serviceRequest}/work-order', [FieldServiceController::class, 'workOrderFromRequest'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.requests.work-order');
        Route::get('/field-services/work-orders', [FieldServiceController::class, 'workOrders'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.work-orders');
        Route::post('/field-services/work-orders', [FieldServiceController::class, 'storeWorkOrder'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.store');
        Route::get('/field-services/work-orders/{workOrder}', [FieldServiceController::class, 'workOrderShow'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.work-orders.show');
        Route::post('/field-services/work-orders/{workOrder}/status', [FieldServiceController::class, 'workOrderStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.status');
        Route::post('/field-services/work-orders/{workOrder}/tasks', [FieldServiceController::class, 'storeWorkOrderTask'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.tasks.store');
        Route::post('/field-services/work-orders/{workOrder}/tasks/{task}/status', [FieldServiceController::class, 'workOrderTaskStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.tasks.status');
        Route::post('/field-services/work-orders/{workOrder}/time-entries', [FieldServiceController::class, 'storeTimeEntry'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.time.store');
        Route::post('/field-services/work-orders/{workOrder}/materials', [FieldServiceController::class, 'storeMaterial'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.work-orders.materials.store');
        Route::post('/field-services/work-orders/{workOrder}/forms/start', [FieldServiceController::class, 'startWorkOrderForm'])->middleware(EnsureTitanFieldPermission::class . ':crm.forms.manage')->name('field-services.work-orders.forms.start');
        Route::post('/field-services/work-orders/{workOrder}/evidence', [FieldServiceController::class, 'storeEvidence'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_evidence.manage')->name('field-services.work-orders.evidence.store');
        Route::get('/field-services/control', [FieldServiceController::class, 'controlSurface'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.control');
        Route::get('/field-services/capacity', [FieldServiceController::class, 'capacityForecast'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.capacity');
        Route::get('/field-services/schedule', [FieldServiceController::class, 'schedule'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.schedule');
        Route::get('/field-services/schedule/recommend-workers', [FieldServiceController::class, 'recommendWorkers'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.schedule.recommend-workers');
        Route::post('/field-services/schedule', [FieldServiceController::class, 'storeAppointment'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.schedule.store');
        Route::post('/field-services/schedule/{appointment}/move', [FieldServiceController::class, 'moveAppointment'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.schedule.move');
        Route::post('/field-services/schedule/{appointment}/resize', [FieldServiceController::class, 'resizeAppointment'])->middleware(EnsureTitanFieldPermission::class . ':crm.scheduling.manage')->name('field-services.schedule.resize');
        Route::get('/field-services/dispatch', [FieldServiceController::class, 'dispatch'])->middleware(EnsureTitanFieldPermission::class . ':crm.dispatch.manage')->name('field-services.dispatch');
        Route::get('/field-services/routes', [FieldServiceController::class, 'routes'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes');
        Route::post('/field-services/routes', [FieldServiceController::class, 'storeRoute'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.store');
        Route::post('/field-services/routes/{route}/stops', [FieldServiceController::class, 'storeRouteStop'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.stops.store');
        Route::post('/field-services/routes/{route}/stops/resequence', [FieldServiceController::class, 'resequenceRouteStops'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.stops.resequence');
        Route::post('/field-services/route-stops/{stop}/status', [FieldServiceController::class, 'routeStopStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.stops.status');
        Route::post('/field-services/routes/location-ping', [FieldServiceController::class, 'recordWorkerLocation'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.location-ping');
        Route::post('/field-services/routes/{route}/optimisation-proposals', [FieldServiceController::class, 'requestRouteOptimisationProposal'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.optimisation-proposals.store');
        Route::post('/field-services/routes/optimisation-proposals/{proposal}/accept', [FieldServiceController::class, 'acceptRouteOptimisationProposal'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.optimisation-proposals.accept');
        Route::post('/field-services/routes/optimisation-proposals/{proposal}/reject', [FieldServiceController::class, 'rejectRouteOptimisationProposal'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.optimisation-proposals.reject');
        Route::post('/field-services/routes/optimisation-proposals/{proposal}/apply', [FieldServiceController::class, 'applyRouteOptimisationProposal'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.routes.manage')->name('field-services.routes.optimisation-proposals.apply');
        Route::get('/field-services/exceptions', [FieldServiceController::class, 'exceptions'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions');
        Route::post('/field-services/exceptions/detect', [FieldServiceController::class, 'detectExceptions'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions.detect');
        Route::post('/field-services/exceptions/{exception}/acknowledge', [FieldServiceController::class, 'acknowledgeException'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions.acknowledge');
        Route::post('/field-services/exceptions/{exception}/assign', [FieldServiceController::class, 'assignException'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions.assign');
        Route::post('/field-services/exceptions/{exception}/resolve', [FieldServiceController::class, 'resolveException'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions.resolve');
        Route::post('/field-services/exceptions/{exception}/close', [FieldServiceController::class, 'closeException'])->middleware(EnsureTitanFieldPermission::class . ':crm.field.exceptions.manage')->name('field-services.exceptions.close');
        Route::get('/field-services/timesheets', [FieldServiceController::class, 'timesheets'])->middleware(EnsureTitanFieldPermission::class . ':crm.work_orders.manage')->name('field-services.timesheets');
        Route::post('/field-services/dispatch', [FieldServiceController::class, 'assignDispatch'])->middleware(EnsureTitanFieldPermission::class . ':crm.dispatch.manage')->name('field-services.dispatch.assign');
        Route::post('/field-services/dispatch/{assignment}/status', [FieldServiceController::class, 'dispatchStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.dispatch.manage')->name('field-services.dispatch.status');
        Route::get('/field-services/service-agreements', [FieldServiceController::class, 'agreements'])->middleware(EnsureTitanFieldPermission::class . ':crm.recurring.manage')->name('field-services.agreements');
        Route::post('/field-services/service-agreements', [FieldServiceController::class, 'storeAgreement'])->middleware(EnsureTitanFieldPermission::class . ':crm.recurring.manage')->name('field-services.agreements.store');
        Route::post('/field-services/service-agreements/generate', [FieldServiceController::class, 'generateRecurring'])->middleware(EnsureTitanFieldPermission::class . ':crm.recurring.manage')->name('field-services.agreements.generate');
        Route::post('/field-services/service-agreements/{agreement}/status', [FieldServiceController::class, 'agreementStatus'])->middleware(EnsureTitanFieldPermission::class . ':crm.recurring.manage')->name('field-services.agreements.status');
        Route::get('/field-services/forms', [FieldServiceController::class, 'forms'])->middleware(EnsureTitanFieldPermission::class . ':crm.forms.manage')->name('field-services.forms');
        Route::post('/field-services/forms', [FieldServiceController::class, 'storeForm'])->middleware(EnsureTitanFieldPermission::class . ':crm.forms.manage')->name('field-services.forms.store');
        Route::post('/field-services/forms/{form}/publish', [FieldServiceController::class, 'publishForm'])->middleware(EnsureTitanFieldPermission::class . ':crm.forms.manage')->name('field-services.forms.publish');
        Route::get('/field-services/assets', [FieldServiceController::class, 'assets'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.view')->name('field-services.assets');
        Route::post('/field-services/assets', [FieldServiceController::class, 'storeAsset'])->middleware(EnsureTitanFieldPermission::class . ':crm.field_services.manage')->name('field-services.assets.store');
        Route::get('/field-services/service-areas', [FieldServiceController::class, 'serviceAreas'])->middleware(EnsureTitanFieldPermission::class . ':crm.service_areas.manage')->name('field-services.service-areas');
        Route::post('/field-services/service-areas', [FieldServiceController::class, 'storeServiceArea'])->middleware(EnsureTitanFieldPermission::class . ':crm.service_areas.manage')->name('field-services.service-areas.store');
        Route::post('/field-services/service-areas/{serviceArea}', [FieldServiceController::class, 'updateServiceArea'])->middleware(EnsureTitanFieldPermission::class . ':crm.service_areas.manage')->name('field-services.service-areas.update');
        Route::get('/field-services/support', [FieldServiceController::class, 'support'])->middleware(EnsureTitanFieldPermission::class . ':crm.support.manage')->name('field-services.support');
        Route::post('/field-services/support', [FieldServiceController::class, 'storeSupport'])->middleware(EnsureTitanFieldPermission::class . ':crm.support.manage')->name('field-services.support.store');
        Route::get('/field-services/reviews', [FieldServiceController::class, 'reviews'])->middleware(EnsureTitanFieldPermission::class . ':crm.reviews.manage')->name('field-services.reviews');
    });
