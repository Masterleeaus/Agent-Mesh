<?php

declare(strict_types=1);

use App\Extensions\TitanField\System\Http\Controllers\TitanGoApiController;
use App\Extensions\TitanField\System\Http\Middleware\EnsureTitanFieldHostEnabled;
use Illuminate\Support\Facades\Route;

Route::middleware(array_merge(config('titan-field.api_middleware',['api','auth']),[EnsureTitanFieldHostEnabled::class]))
    ->prefix('api/titan-field/v1/mobile')->name('titan-field.mobile.')->group(function():void{
        Route::get('/context',[TitanGoApiController::class,'context'])->name('context');
        Route::post('/devices/register',[TitanGoApiController::class,'registerDevice'])->name('devices.register');
        Route::post('/replay',[TitanGoApiController::class,'replay'])->name('replay');
        Route::post('/sync',[TitanGoApiController::class,'sync'])->name('sync');
        Route::post('/evidence',[TitanGoApiController::class,'evidence'])->name('evidence');
    });
