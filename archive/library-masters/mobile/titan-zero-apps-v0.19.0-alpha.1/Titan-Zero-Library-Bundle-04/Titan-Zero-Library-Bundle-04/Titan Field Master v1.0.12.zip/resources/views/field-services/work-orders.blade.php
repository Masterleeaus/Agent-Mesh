@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Jobs','subtitle'=>'Plan, assign and deliver customer work.','surface'=>'work','journey'=>'new-job'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Number</th><th>Job</th><th>Status</th><th>Schedule</th></tr></thead><tbody>@forelse($workOrders as $x)<tr><td>{{$x['number']}}</td><td><a href="{{ route('dashboard.user.crm.field-services.work-orders.show',$x['public_id']) }}"><strong>{{$x['title']}}</strong></a></td><td>{{$x['status']}}</td><td>{{$x['scheduled_start'] ?? 'Unscheduled'}}</td></tr>@empty<tr><td colspan="4" class="text-muted">No jobs yet.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
