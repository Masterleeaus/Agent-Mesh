@extends('panel.layout.app')
@section('content')
<div class="mb-3"><a class="btn btn-outline-primary btn-sm" href="{{ route('dashboard.user.crm.field-services.control') }}">Open Field Control</a></div>
@component('crm::components.interaction-page-shell',['title'=>'Dispatch','subtitle'=>'Assign jobs to crew and monitor dispatch state.','surface'=>'crew','journey'=>'new-dispatch-assignment','secondaryJourneys'=>['new-job']])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Job</th><th>Worker</th><th>Status</th><th>Window</th></tr></thead><tbody>@forelse($assignments as $x)<tr><td>{{$x['work_order_public_id']}}</td><td>{{$x['worker_user_id']}}</td><td>{{$x['status']}}</td><td>{{$x['scheduled_start'] ?? '—'}}</td></tr>@empty<tr><td colspan="4" class="text-muted">No dispatch assignments.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
