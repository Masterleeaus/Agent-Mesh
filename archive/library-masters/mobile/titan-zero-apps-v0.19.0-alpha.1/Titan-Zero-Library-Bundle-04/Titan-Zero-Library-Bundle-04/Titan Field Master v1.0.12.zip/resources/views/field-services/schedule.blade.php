@extends('panel.layout.app')
@section('content')
<style>
    .schedule-calendar-wrap{overflow-x:auto}
    .schedule-calendar-grid{display:grid;grid-template-columns:repeat(7,minmax(132px,1fr));min-width:960px;border-top:1px solid var(--tblr-border-color,rgba(98,105,118,.16));border-left:1px solid var(--tblr-border-color,rgba(98,105,118,.16))}
    .schedule-calendar-head{padding:.7rem .75rem;font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em;background:var(--tblr-bg-surface-secondary,#f6f8fb);border-right:1px solid var(--tblr-border-color,rgba(98,105,118,.16));border-bottom:1px solid var(--tblr-border-color,rgba(98,105,118,.16))}
    .schedule-calendar-day{min-height:150px;padding:.55rem;background:var(--tblr-bg-surface,#fff);border-right:1px solid var(--tblr-border-color,rgba(98,105,118,.16));border-bottom:1px solid var(--tblr-border-color,rgba(98,105,118,.16))}
    .schedule-calendar-day.is-outside{background:var(--tblr-bg-surface-secondary,#f6f8fb);opacity:.7}
    .schedule-calendar-day.is-today{box-shadow:inset 0 0 0 2px var(--tblr-primary,#206bc4)}
    .schedule-calendar-date{display:flex;align-items:center;justify-content:space-between;margin-bottom:.45rem}
    .schedule-calendar-date a{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;border-radius:999px;text-decoration:none;font-weight:600}
    .schedule-calendar-day.is-today .schedule-calendar-date a{background:var(--tblr-primary,#206bc4);color:#fff}
    .schedule-event{display:block;margin-bottom:.35rem;padding:.38rem .45rem;border:1px solid var(--tblr-border-color,rgba(98,105,118,.16));border-radius:.4rem;background:var(--tblr-bg-surface,#fff);text-decoration:none;color:inherit;font-size:.76rem;line-height:1.25}
    .schedule-event-time{font-size:.68rem;color:var(--tblr-secondary,#626976)}
    .schedule-event-title{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .schedule-more{font-size:.72rem;color:var(--tblr-secondary,#626976)}
</style>

@php($isStaged = (bool)($staged ?? false))
@php($scheduleRoute = $isStaged ? 'dashboard.user.titan-field.schedule' : 'dashboard.user.crm.field-services.schedule')

@if($isStaged)
<div class="mb-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
        <div><h1 class="h2 mb-1">Schedule</h1><div class="text-muted">Appointments and crew scheduling.</div></div>
    </div>
    <div class="alert alert-info mb-0"><strong>Read-only staged Schedule.</strong> Titan Field is displaying the real calendar while CRM remains the authoritative Field writer. Scheduling changes stay disabled until the CRM extraction boundary is reached.</div>
</div>
@else
<div class="mb-3 d-flex flex-wrap gap-2 justify-content-between align-items-center">
    <a class="btn btn-outline-primary btn-sm" href="{{ route('dashboard.user.crm.field-services.control') }}">Open Field Control</a>
</div>
@component('crm::components.interaction-page-shell',['title'=>'Schedule','subtitle'=>'Appointments and crew scheduling.','surface'=>'crew','journey'=>'new-appointment','secondaryJourneys'=>['new-job']])
@include('crm::finance-assistants.context-links',['financeSurface'=>'crew'])
@endif
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif

@php($monthQuery = request()->query('month'))
<div class="card mb-4">
    <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
            <h2 class="card-title mb-1">{{ $calendarTitle }}</h2>
            <div class="text-muted small">Real appointment schedule · Monday to Sunday</div>
        </div>
        <div class="btn-list">
            <a class="btn btn-outline-secondary btn-sm" aria-label="Previous month" href="{{ route($scheduleRoute,['month'=>$previousMonth]) }}">‹</a>
            <a class="btn btn-outline-primary btn-sm" href="{{ route($scheduleRoute,['month'=>$todayMonth,'date'=>$todayDate]) }}">Today</a>
            <a class="btn btn-outline-secondary btn-sm" aria-label="Next month" href="{{ route($scheduleRoute,['month'=>$nextMonth]) }}">›</a>
        </div>
    </div>
    <div class="schedule-calendar-wrap">
        <div class="schedule-calendar-grid">
            @foreach(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'] as $weekday)
                <div class="schedule-calendar-head">{{ $weekday }}</div>
            @endforeach

            @foreach($calendarWeeks as $week)
                @foreach($week as $day)
                    <div class="schedule-calendar-day @if(!$day['in_month']) is-outside @endif @if($day['is_today']) is-today @endif">
                        <div class="schedule-calendar-date">
                            <a href="{{ route($scheduleRoute,['month'=>$currentMonth,'date'=>$day['date']]) }}" @if($day['date']===$selectedDate) aria-current="date" @endif>{{ $day['day'] }}</a>
                            @if(count($day['appointments'])>0)<span class="badge bg-primary-lt">{{ count($day['appointments']) }}</span>@endif
                        </div>
                        @foreach(array_slice($day['appointments'],0,3) as $event)
                            <a class="schedule-event" href="{{ route($scheduleRoute,['month'=>$currentMonth,'date'=>$day['date']]) }}" title="{{ $event['title'] ?? 'Appointment' }}">
                                <div class="schedule-event-time">{{ date('g:i A',strtotime((string)$event['scheduled_start'])) }}–{{ date('g:i A',strtotime((string)$event['scheduled_end'])) }}</div>
                                <div class="schedule-event-title">{{ $event['title'] ?? 'Appointment' }}</div>
                                <div class="text-muted">{{ str_replace('_',' ',(string)($event['status'] ?? 'scheduled')) }}@if(!empty($event['assigned_user_id'])) · Worker #{{ $event['assigned_user_id'] }}@endif</div>
                            </a>
                        @endforeach
                        @if(count($day['appointments'])>3)<div class="schedule-more">+{{ count($day['appointments'])-3 }} more</div>@endif
                    </div>
                @endforeach
            @endforeach
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <h3 class="card-title mb-1">Selected day · {{ date('l, j F Y',strtotime($selectedDate)) }}</h3>
            <div class="text-muted small">{{ count($selectedAppointments) }} appointment{{ count($selectedAppointments)===1?'':'s' }}</div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-vcenter mb-0">
            <thead><tr><th>Time</th><th>Appointment</th><th>Worker</th><th>Status</th></tr></thead>
            <tbody>
            @forelse($selectedAppointments as $x)
                <tr>
                    <td class="text-nowrap"><strong>{{ date('g:i A',strtotime((string)$x['scheduled_start'])) }}</strong><div class="text-muted small">to {{ date('g:i A',strtotime((string)$x['scheduled_end'])) }}</div></td>
                    <td><strong>{{ $x['title'] ?? 'Appointment' }}</strong>@if(!empty($x['work_order_public_id']))<div class="text-muted small">Job {{ $x['work_order_public_id'] }}</div>@endif</td>
                    <td>{{ !empty($x['assigned_user_id']) ? '#'.$x['assigned_user_id'] : 'Unassigned' }}</td>
                    <td><span class="badge bg-secondary-lt">{{ str_replace('_',' ',(string)($x['status'] ?? 'scheduled')) }}</span></td>
                </tr>
            @empty
                <tr><td colspan="4" class="text-muted py-4 text-center">No appointments scheduled for this day.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>
@if(!$isStaged)
@endcomponent
@endif
@endsection
