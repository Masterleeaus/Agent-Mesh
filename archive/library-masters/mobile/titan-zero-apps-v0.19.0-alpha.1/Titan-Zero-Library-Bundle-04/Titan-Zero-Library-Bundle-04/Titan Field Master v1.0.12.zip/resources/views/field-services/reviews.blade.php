@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Reviews and Recovery','subtitle'=>'Customer feedback and service-recovery cases.','surface'=>'customers'])
<div class="row g-4"><div class="col-lg-7"><div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Rating</th><th>Comment</th><th>Date</th></tr></thead><tbody>@forelse($reviews as $x)<tr><td>{{$x['rating']}} / 5</td><td>{{$x['comment'] ?? '—'}}</td><td>{{$x['reviewed_at'] ?? $x['created_at']}}</td></tr>@empty<tr><td colspan="3" class="text-muted">No reviews yet.</td></tr>@endforelse</tbody></table></div></div></div><div class="col-lg-5"><div class="card"><div class="card-header">Recovery cases</div><ul class="list-group list-group-flush">@forelse($recovery as $x)<li class="list-group-item"><strong>{{$x['status']}}</strong> @if($x['rebooking_requested'])<span class="badge border text-body">Rebooking</span>@endif</li>@empty<li class="list-group-item text-muted">No recovery cases.</li>@endforelse</ul></div></div></div>
@endcomponent
@endsection
