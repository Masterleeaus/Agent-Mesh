@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Services and Catalogue','subtitle'=>'Services, duration and pricing defaults used by jobs and quotes.','surface'=>'work','journey'=>'new-service'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Service</th><th>Duration</th><th>Pricing</th><th>Flags</th></tr></thead><tbody>@forelse($services as $s)<tr><td><strong>{{$s['name']}}</strong><div class="small text-muted">{{$s['key']}}</div></td><td>{{$s['default_duration_minutes'] ?? '—'}} min</td><td>{{$s['pricing_model'] ?? 'fixed'}}</td><td>@if($s['emergency_capable'] ?? false)<span class="badge border text-body">Emergency</span>@endif @if($s['regulated_work'] ?? false)<span class="badge border text-body">Regulated</span>@endif</td></tr>@empty<tr><td colspan="4" class="text-muted">No services yet.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
