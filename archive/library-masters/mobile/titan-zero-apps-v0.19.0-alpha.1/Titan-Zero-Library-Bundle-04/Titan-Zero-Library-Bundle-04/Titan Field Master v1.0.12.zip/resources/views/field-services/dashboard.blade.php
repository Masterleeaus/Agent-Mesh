@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Work','subtitle'=>'Service intake, scheduling, dispatch, jobs, recurring work and service quality.','surface'=>'work','journey'=>'new-job','secondaryJourneys'=>['new-service-request','new-appointment']])
<div class="row g-3 mb-4">@foreach($counts as $key=>$value)<div class="col-6 col-lg-3"><div class="card"><div class="card-body"><div class="text-muted small">{{ ucwords(str_replace('_',' ',$key)) }}</div><div class="fs-2 fw-bold">{{ $value }}</div></div></div></div>@endforeach</div>
<div class="d-flex flex-wrap gap-2">@foreach(['verticals'=>'Vertical Profiles','catalogue'=>'Services','locations'=>'Locations','service-requests'=>'Service Requests','work-orders'=>'Jobs','schedule'=>'Schedule','dispatch'=>'Dispatch','service-agreements'=>'Recurring Work','forms'=>'Forms','assets'=>'Customer Assets','support'=>'Support','reviews'=>'Reviews','service-areas'=>'Service Areas'] as $route=>$label)<a class="btn btn-outline-primary" href="{{ url('dashboard/user/crm/field-services/'.$route) }}">{{ $label }}</a>@endforeach</div>
@endcomponent
@endsection
