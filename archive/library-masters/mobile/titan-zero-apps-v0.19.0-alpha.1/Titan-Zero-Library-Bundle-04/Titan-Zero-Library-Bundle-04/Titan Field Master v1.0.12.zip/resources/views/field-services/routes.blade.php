@extends('panel.layout.app')
@section('title', 'Routes & Live Position')
@section('content')
<div class="mb-3"><a class="btn btn-outline-primary btn-sm" href="{{ route('dashboard.user.crm.field-services.control') }}">Open Field Control</a></div>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="h3 mb-1">Routes & Live Position</h1><p class="text-muted mb-0">Ordered day routes and consent-bound live worker position. Maps can generate explainable route optimisation proposals. Titan Field remains the only route writer; proposals require explicit governed acceptance and apply.</p></div></div>
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    <div class="card mb-4"><div class="card-body"><h2 class="h5">Create day route</h2><form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.store') }}" class="row g-3">@csrf
        <div class="col-md-3"><label class="form-label">Worker user ID</label><input class="form-control" type="number" name="worker_user_id" required></div>
        <div class="col-md-3"><label class="form-label">Route date</label><input class="form-control" type="date" name="route_date" value="{{ now()->toDateString() }}" required></div>
        <div class="col-md-4"><label class="form-label">Name</label><input class="form-control" name="name"></div>
        <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Create</button></div>
    </form></div></div>
    @forelse($routes as $route)
      <div class="card mb-3"><div class="card-body">
        <div class="d-flex justify-content-between"><div><strong>{{ $route['name'] }}</strong><div class="text-muted">Worker {{ $route['worker_user_id'] }} · {{ $route['route_date'] }} · {{ $route['status'] }}</div></div><div>{{ number_format(((int)$route['total_distance_meters'])/1000,1) }} km planned</div></div>
        @if(!empty($route['latest_location']))<div class="small mt-2">Latest consented position: {{ $route['latest_location']['latitude'] }}, {{ $route['latest_location']['longitude'] }} · {{ $route['latest_location']['captured_at'] }}</div>@endif
        <div class="table-responsive mt-3"><table class="table table-sm"><thead><tr><th>#</th><th>Appointment</th><th>Status</th><th>Planned</th><th>Travel</th></tr></thead><tbody>
        @forelse($route['stops'] as $stop)<tr><td>{{ $stop['sequence'] }}</td><td>{{ $stop['appointment_public_id'] }}</td><td>{{ $stop['status'] }}</td><td>{{ $stop['planned_arrival_at'] }}</td><td>{{ $stop['distance_meters_from_previous'] ? number_format($stop['distance_meters_from_previous']/1000,1).' km' : '—' }}</td></tr>@empty<tr><td colspan="5" class="text-muted">No stops.</td></tr>@endforelse
        </tbody></table></div>
        <form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.stops.store',$route['public_id']) }}" class="d-flex gap-2">@csrf<input class="form-control" name="appointment_public_id" placeholder="Appointment public ID" required><button class="btn btn-outline-primary">Add stop</button></form>
        @if(count($route['stops'] ?? []) >= 2)<form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.optimisation-proposals.store',$route['public_id']) }}" class="mt-2">@csrf<button class="btn btn-outline-secondary btn-sm">Generate optimisation proposal</button></form>@endif
        @foreach(($optimisationProposals ?? []) as $proposal)@if(($proposal['route_public_id'] ?? null) === $route['public_id'])<div class="border rounded p-2 mt-2 small"><strong>Optimisation proposal {{ $proposal['public_id'] }}</strong> · {{ $proposal['status'] }}<br>Provider: {{ $proposal['provider'] }} · Expires: {{ $proposal['expires_at'] }}<div class="d-flex gap-2 mt-2">@if($proposal['status']==='pending')<form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.optimisation-proposals.accept',$proposal['public_id']) }}">@csrf<button class="btn btn-success btn-sm">Accept</button></form><form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.optimisation-proposals.reject',$proposal['public_id']) }}">@csrf<button class="btn btn-outline-danger btn-sm">Reject</button></form>@elseif($proposal['status']==='accepted')<form method="POST" action="{{ route('dashboard.user.crm.field-services.routes.optimisation-proposals.apply',$proposal['public_id']) }}">@csrf<button class="btn btn-primary btn-sm">Apply through governance</button></form>@endif</div></div>@endif@endforeach
      </div></div>
    @empty<div class="card"><div class="card-body text-muted">No routes for this filter.</div></div>@endforelse
</div>
@endsection
