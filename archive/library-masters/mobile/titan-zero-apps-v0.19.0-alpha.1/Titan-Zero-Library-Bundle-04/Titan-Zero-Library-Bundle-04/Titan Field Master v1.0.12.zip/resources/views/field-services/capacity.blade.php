@extends('panel.layout.app')
@section('title', 'Capacity Forecast')
@section('content')
<div class="container-fluid py-4" data-titan-field-capacity-forecast>
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Capacity forecast</h1>
            <p class="text-muted mb-0">Evidence-backed, read-only forecast. It does not assign, reschedule or accept work.</p>
        </div>
        <form method="GET" action="{{ route('dashboard.user.crm.field-services.capacity') }}" class="d-flex gap-2 align-items-end">
            <div><label class="form-label mb-1">From</label><input class="form-control" type="date" name="from" value="{{ $from }}"></div>
            <div><label class="form-label mb-1">Days</label><input class="form-control" type="number" min="1" max="60" name="days" value="{{ $days }}"></div>
            <button class="btn btn-outline-primary">Forecast</button>
        </form>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Pressure</div><div class="h4 mb-0 text-capitalize">{{ $summary['pressure_status'] ?? 'unknown' }}</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Available</div><div class="h4 mb-0">{{ number_format((int)($summary['effective_available_minutes'] ?? 0)) }} min</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Booked</div><div class="h4 mb-0">{{ number_format((int)($summary['booked_minutes'] ?? 0)) }} min</div></div></div></div>
        <div class="col-md-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Unfilled demand</div><div class="h4 mb-0">{{ number_format((int)($unfilled_demand_minutes ?? 0)) }} min</div><div class="small text-muted">{{ (int)($unfilled_demand_count ?? 0) }} item(s)</div></div></div></div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-xl-7">
            <div class="card h-100"><div class="card-header"><h2 class="card-title mb-0">Daily team capacity</h2></div><div class="card-body table-responsive">
                <table class="table table-sm align-middle"><thead><tr><th>Date</th><th>Available</th><th>Booked</th><th>Remaining</th><th>Utilisation</th><th>Status</th></tr></thead><tbody>
                @foreach($daily as $row)<tr><td>{{ $row['date'] }}</td><td>{{ number_format((int)$row['team']['effective_available_minutes']) }} min</td><td>{{ number_format((int)$row['team']['booked_minutes']) }} min</td><td>{{ number_format((int)$row['team']['remaining_minutes']) }} min</td><td>{{ number_format((float)$row['team']['utilization_percent'],1) }}%</td><td class="text-capitalize">{{ $row['team']['pressure_status'] }}</td></tr>@endforeach
                </tbody></table>
            </div></div>
        </div>
        <div class="col-xl-5">
            <div class="card h-100"><div class="card-header"><h2 class="card-title mb-0">Spatial pressure</h2></div><div class="card-body">
                <div class="mb-2"><strong>Provider:</strong> {{ $spatial_pressure['provider'] ?? 'unavailable' }}</div>
                <div class="mb-2"><strong>Basis:</strong> {{ $spatial_pressure['basis'] ?? 'unavailable' }}</div>
                <div class="mb-2"><strong>Uncovered demand:</strong> {{ (int)($spatial_pressure['uncovered_demand_count'] ?? 0) }}</div>
                <div class="mb-2"><strong>Nearest worker travel:</strong> @if(isset($spatial_pressure['nearest_worker_duration_seconds'])){{ (int)ceil(((int)$spatial_pressure['nearest_worker_duration_seconds'])/60) }} min average @else unknown @endif</div>
                <div class="small text-muted mt-3">Spatial travel is advisory capacity evidence only. It is not a future route commitment.</div>
            </div></div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-xl-6"><div class="card h-100"><div class="card-header"><h2 class="card-title mb-0">Skill pressure</h2></div><div class="card-body table-responsive"><table class="table table-sm"><thead><tr><th>Service</th><th>Demand</th><th>Eligible workers</th><th>Upper-bound capacity</th><th>Shortage</th></tr></thead><tbody>
        @forelse($skill_pressure as $row)<tr><td>{{ $row['service_public_id'] ?? 'Unclassified' }}</td><td>{{ number_format((int)$row['demand_minutes']) }} min</td><td>{{ (int)$row['eligible_worker_count'] }}</td><td>{{ number_format((int)$row['eligible_remaining_minutes_upper_bound']) }} min</td><td>{{ number_format((int)$row['shortage_minutes_upper_bound']) }} min</td></tr>@empty<tr><td colspan="5" class="text-muted">No unfilled skill-constrained demand.</td></tr>@endforelse
        </tbody></table></div></div></div>
        <div class="col-xl-6"><div class="card h-100"><div class="card-header"><h2 class="card-title mb-0">Service-area pressure</h2></div><div class="card-body table-responsive"><table class="table table-sm"><thead><tr><th>Area</th><th>Demand items</th><th>Demand minutes</th><th>Spatial basis</th></tr></thead><tbody>
        @forelse($service_area_pressure as $row)<tr><td>{{ $row['service_area_key'] }}</td><td>{{ (int)$row['unfilled_demand_count'] }}</td><td>{{ number_format((int)$row['unfilled_demand_minutes']) }}</td><td>{{ $row['spatial_evidence_basis'] }}</td></tr>@empty<tr><td colspan="4" class="text-muted">No service-area demand pressure.</td></tr>@endforelse
        </tbody></table></div></div></div>
    </div>

    <div class="card"><div class="card-header"><h2 class="card-title mb-0">Recommendations</h2></div><div class="card-body"><ul class="mb-0">@foreach(($recommendations ?? []) as $recommendation)<li>{{ $recommendation }}</li>@endforeach</ul><p class="small text-muted mt-3 mb-0">All recommendations are non-authoritative and require normal governed scheduling/dispatch commands for any consequential change.</p></div></div>
</div>
@endsection
