@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Service Locations','subtitle'=>'Customer homes, offices and service sites.','surface'=>'work','journey'=>'new-service-location'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Location</th><th>Address</th><th>Access</th></tr></thead><tbody>@forelse($locations as $x)<tr><td><strong>{{$x['name'] ?? 'Service site'}}</strong></td><td>{{$x['address_line_1']}} {{$x['suburb'] ?? ''}} {{$x['postcode'] ?? ''}}</td><td>{{\Illuminate\Support\Str::limit($x['access_instructions'] ?? '',70)}}</td></tr>@empty<tr><td colspan="3" class="text-muted">No service locations.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
