@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Forms','subtitle'=>'Checklists, inspections, certificates and compliance forms.','surface'=>'work','journey'=>'new-form'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Template</th><th>Type</th><th>Status</th><th>Version</th><th></th></tr></thead><tbody>@forelse($templates as $x)<tr><td>{{$x['name']}}</td><td>{{$x['form_type']}}</td><td>{{$x['status']}}</td><td>{{$x['current_version']}}</td><td>@if($x['status']!=='published')<form method="post" action="{{ route('dashboard.user.crm.field-services.forms.publish',$x['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-primary">Publish</button></form>@else<span class="badge border text-body">Published</span>@endif</td></tr>@empty<tr><td colspan="5" class="text-muted">No forms yet.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
