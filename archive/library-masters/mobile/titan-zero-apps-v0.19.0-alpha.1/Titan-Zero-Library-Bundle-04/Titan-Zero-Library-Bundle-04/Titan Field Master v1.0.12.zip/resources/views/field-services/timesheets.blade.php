@extends('panel.layout.app')
@section('title','Timesheets')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Timesheets','subtitle'=>'Recorded crew time across jobs.','surface'=>'crew','journey'=>'new-time-entry'])
@include('crm::finance-assistants.context-links',['financeSurface'=>'crew'])
<div class="card"><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Started</th><th>Ended</th><th>Worker</th><th>Job</th><th class="text-end">Minutes</th><th>Source</th><th>Notes</th></tr></thead><tbody>@forelse($timeEntries as $entry)<tr><td>{{ $entry['started_at'] }}</td><td>{{ $entry['ended_at'] ?: 'Running' }}</td><td>{{ $entry['worker_user_id'] }}</td><td><a href="{{ route('dashboard.user.crm.field-services.work-orders.show',$entry['work_order_public_id']) }}">{{ $entry['work_order_public_id'] }}</a></td><td class="text-end">{{ $entry['minutes'] ?? '—' }}</td><td>{{ $entry['source'] ?? 'manual' }}</td><td>{{ $entry['notes'] ?? '—' }}</td></tr>@empty<tr><td colspan="7" class="text-muted">No time entries yet.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
