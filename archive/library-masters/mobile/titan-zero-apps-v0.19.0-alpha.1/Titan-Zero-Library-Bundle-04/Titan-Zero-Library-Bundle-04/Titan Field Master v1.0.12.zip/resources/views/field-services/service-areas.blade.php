@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Service Areas','subtitle'=>'Postcode, radius and polygon serviceability rules.','surface'=>'work','journey'=>'new-service-area'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Name</th><th>Match type</th><th>Rule</th><th>Active</th></tr></thead><tbody>@forelse($areas as $x)<tr><td>{{$x['name']}}</td><td>{{$x['match_type']}}</td><td class="small">@if($x['match_type']==='postcode'){{ implode(', ',json_decode($x['postcodes'] ?? '[]',true) ?: []) }}@elseif($x['match_type']==='radius'){{$x['radius_km']}} km @else Polygon@endif</td><td>{{$x['active'] ? 'Yes' : 'No'}}</td></tr>@empty<tr><td colspan="4" class="text-muted">No service areas configured.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
