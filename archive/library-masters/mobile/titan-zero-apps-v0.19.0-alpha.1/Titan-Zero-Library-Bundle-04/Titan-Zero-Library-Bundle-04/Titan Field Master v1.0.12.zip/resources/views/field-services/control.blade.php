@extends('panel.layout.app')
@section('title', 'Field Control')
@section('content')
@if(\Illuminate\Support\Facades\Route::has('dashboard.user.titan-maps-intelligence.assets.show') && (($map_ui['enabled'] ?? false) === true))
<link rel="stylesheet" href="{{ route('dashboard.user.titan-maps-intelligence.assets.show', ['asset' => 'titan-map-engine.css']) }}">
@endif
<div class="container-fluid py-4" data-titan-field-control-surface data-spatial-provider="{{ $spatial_provider }}">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Field Control</h1>
            <p class="text-muted mb-0">Calendar, dispatch, routes, ETA, operational exceptions and live worker position in one governed surface.</p>
        </div>
        <form method="GET" action="{{ route('dashboard.user.crm.field-services.control') }}" class="d-flex gap-2 align-items-end">
            <div><label class="form-label mb-1">Date</label><input class="form-control" type="date" name="date" value="{{ $date }}"></div>
            <button class="btn btn-outline-primary">Load</button>
        </form>
    </div>

    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif

    <div class="row g-4 mb-4">
        <div class="col-xl-8">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div><h2 class="card-title mb-0">Live worker map</h2><div class="text-muted small">Spatial provider: {{ $spatial_provider }}</div></div>
                    @if($spatial_provider === 'titan-maps-intelligence')<span class="badge bg-success-subtle text-success">Maps Intelligence active</span>@else<span class="badge bg-secondary-subtle text-secondary">Field fallback</span>@endif
                </div>
                <div class="card-body p-0 position-relative" data-titan-map-root>
                    @if(\Illuminate\Support\Facades\Route::has('dashboard.user.titan-maps-intelligence.assets.show') && (($map_ui['enabled'] ?? false) === true))
                        <div class="titan-map-canvas" data-titan-map-canvas role="application" aria-label="Titan Field live worker map" style="min-height:420px"></div>
                        <div class="titan-map-empty" data-titan-map-empty hidden>No live worker positions are available.</div>
                        <div class="titan-map-legend" data-titan-map-legend></div>
                        <div class="titan-map-attribution" data-titan-map-attribution></div>
                    @else
                        <div class="p-4">
                            <p class="text-muted">Titan Maps Intelligence is unavailable or graphical maps are disabled. Field is showing retained position evidence instead.</p>
                            <div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Marker</th><th>Position</th><th>Type</th></tr></thead><tbody>
                            @forelse(($map_payload['markers'] ?? []) as $marker)
                                <tr><td>{{ $marker['label'] ?? $marker['id'] ?? 'Position' }}</td><td>{{ $marker['lat'] ?? '—' }}, {{ $marker['lng'] ?? '—' }}</td><td>{{ $marker['type'] ?? 'location' }}</td></tr>
                            @empty<tr><td colspan="3" class="text-muted">No retained positions.</td></tr>@endforelse
                            </tbody></table></div>
                        </div>
                    @endif
                    <script type="application/json" data-titan-map-payload>@json($map_payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)</script>
                    <script type="application/json" data-titan-map-config>@json($map_ui, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)</script>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header"><h2 class="card-title mb-0">Routes / ETA</h2></div>
                <div class="card-body">
                    @forelse($route_overlays as $route)
                        <div class="border rounded p-3 mb-2">
                            <div class="fw-semibold">Worker {{ $route['worker_user_id'] }}</div>
                            <div class="small text-muted">{{ $route['status'] }} · {{ number_format(((int)$route['distance_meters'])/1000,1) }} km · {{ (int)ceil(((int)$route['duration_seconds'])/60) }} min</div>
                            <div class="small mt-1">{{ count($route['stops'] ?? []) }} stop(s)</div>
                        </div>
                    @empty<p class="text-muted mb-0">No route overlays for this date.</p>@endforelse
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h2 class="card-title mb-0">Operational exceptions</h2></div>
                <div class="card-body">
                    @forelse($exception_overlays as $exception)
                        <div class="border rounded p-3 mb-2" data-exception="{{ $exception['public_id'] }}">
                            <div class="d-flex justify-content-between gap-2"><span class="fw-semibold">{{ $exception['title'] }}</span><span class="badge bg-warning-subtle text-warning">{{ $exception['severity'] }}</span></div>
                            <div class="small text-muted">{{ $exception['type'] }} · {{ $exception['status'] }}</div>
                            @if(!empty($exception['sla_due_at']))<div class="small mt-1">SLA due {{ $exception['sla_due_at'] }}</div>@endif
                        </div>
                    @empty<p class="text-muted mb-0">No open operational exceptions for this control window.</p>@endforelse
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h2 class="card-title mb-0">Calendar & dispatch worker lanes</h2><div class="text-muted small">Drag an appointment to another worker lane to request a governed move. SchedulingKernel revalidates every change.</div></div>
        <div class="card-body">
            <div class="row g-3" data-worker-lanes>
                @foreach($worker_lanes as $lane)
                    <div class="col-xl-4 col-lg-6" data-worker-lane="{{ $lane['worker_user_id'] }}">
                        <div class="border rounded h-100 p-3 titan-field-worker-lane" data-worker-drop-zone="{{ $lane['worker_user_id'] }}">
                            <div class="d-flex justify-content-between align-items-center mb-3"><strong>{{ $lane['label'] }}</strong><span class="small text-muted">{{ $lane['max_daily_minutes'] }} min/day</span></div>
                            @forelse($lane['appointments'] as $event)
                                <div class="border rounded p-3 mb-2 bg-body" draggable="true" data-calendar-event="{{ $event['public_id'] }}" data-start="{{ $event['scheduled_start'] }}" data-end="{{ $event['scheduled_end'] }}" data-worker="{{ $event['worker_user_id'] }}">
                                    <div class="fw-semibold">{{ $event['title'] }}</div>
                                    <div class="small text-muted">{{ $event['scheduled_start'] }} → {{ $event['scheduled_end'] }}</div>
                                    <div class="small">{{ $event['status'] }}</div>
                                    <details class="mt-2"><summary class="small text-primary">Move appointment</summary>
                                        <form method="POST" action="{{ route('dashboard.user.crm.field-services.schedule.move', $event['public_id']) }}" class="row g-2 mt-1">@csrf
                                            <div class="col-12"><label class="form-label small">Start</label><input class="form-control form-control-sm" name="scheduled_start" value="{{ $event['scheduled_start'] }}" required></div>
                                            <div class="col-12"><label class="form-label small">End</label><input class="form-control form-control-sm" name="scheduled_end" value="{{ $event['scheduled_end'] }}" required></div>
                                            <div class="col-12"><label class="form-label small">Worker user ID</label><input class="form-control form-control-sm" type="number" name="assigned_user_id" value="{{ $event['worker_user_id'] ?: '' }}"></div>
                                            <div class="col-12"><button class="btn btn-sm btn-outline-primary">Move appointment</button></div>
                                        </form>
                                    </details>
                                    <details class="mt-2"><summary class="small text-primary">Resize appointment</summary>
                                        <form method="POST" action="{{ route('dashboard.user.crm.field-services.schedule.resize', $event['public_id']) }}" class="d-flex gap-2 mt-2">@csrf
                                            <input class="form-control form-control-sm" name="scheduled_end" value="{{ $event['scheduled_end'] }}" required>
                                            <button class="btn btn-sm btn-outline-secondary">Resize appointment</button>
                                        </form>
                                    </details>
                                </div>
                            @empty<div class="text-muted small py-4 text-center">No appointments.</div>@endforelse
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

@if(\Illuminate\Support\Facades\Route::has('dashboard.user.titan-maps-intelligence.assets.show') && (($map_ui['enabled'] ?? false) === true))
<script src="{{ route('dashboard.user.titan-maps-intelligence.assets.show', ['asset' => 'titan-map-engine.js']) }}"></script>
@endif
<script>
(() => {
    const token = @json(csrf_token());
    const moveTemplate = @json(route('dashboard.user.crm.field-services.schedule.move', ['appointment' => '__APPOINTMENT__']));
    let dragged = null;
    document.querySelectorAll('[data-calendar-event]').forEach(el => {
        el.addEventListener('dragstart', () => { dragged = el; });
        el.addEventListener('dragend', () => { dragged = null; });
    });
    document.querySelectorAll('[data-worker-drop-zone]').forEach(zone => {
        zone.addEventListener('dragover', event => event.preventDefault());
        zone.addEventListener('drop', event => {
            event.preventDefault();
            if (!dragged) return;
            const worker = Number(zone.dataset.workerDropZone || 0);
            if (worker < 1 || String(worker) === String(dragged.dataset.worker || '')) return;
            const form = document.createElement('form'); form.method = 'POST';
            form.action = moveTemplate.replace('__APPOINTMENT__', encodeURIComponent(dragged.dataset.calendarEvent));
            const fields = {_token: token, scheduled_start: dragged.dataset.start, scheduled_end: dragged.dataset.end, assigned_user_id: String(worker)};
            Object.entries(fields).forEach(([name,value]) => { const input=document.createElement('input'); input.type='hidden'; input.name=name; input.value=value; form.appendChild(input); });
            document.body.appendChild(form); form.submit();
        });
    });
})();
</script>
@endsection
