@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Service Requests','subtitle'=>'Capture and qualify incoming customer work.','surface'=>'work','journey'=>'new-service-request'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Request</th><th>Urgency</th><th>Status</th><th></th></tr></thead><tbody>@forelse($requests as $x)<tr><td><strong>{{$x['title']}}</strong><div class="small text-muted">{{$x['source']}} / {{$x['channel'] ?? 'direct'}}</div></td><td>{{$x['urgency']}}</td><td>{{$x['status']}}</td><td><form method="post" action="{{ route('dashboard.user.crm.field-services.requests.status',$x['public_id']) }}">@csrf<select name="status" class="form-select form-select-sm" onchange="this.form.submit()"><option>{{$x['status']}}</option>@foreach(['triaged','awaiting_customer','qualified','ready_for_quote','quoted','accepted','handed_off','resolved','cancelled'] as $s)<option>{{$s}}</option>@endforeach</select></form></td></tr>@empty<tr><td colspan="4" class="text-muted">No requests.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
