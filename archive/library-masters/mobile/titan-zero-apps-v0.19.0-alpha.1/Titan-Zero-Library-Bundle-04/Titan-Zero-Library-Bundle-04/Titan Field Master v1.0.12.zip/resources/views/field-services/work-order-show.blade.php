@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>$work_order['title'],'subtitle'=>$work_order['number'].' · '.ucfirst(str_replace('_',' ',$work_order['status'])),'surface'=>'work','journey'=>'new-time-entry','secondaryJourneys'=>['new-appointment'],'recordType'=>'job','context'=>array_filter(['record_type'=>'job','public_id'=>$work_order['public_id'],'work_order_public_id'=>$work_order['public_id'],'company_public_id'=>$work_order['company_public_id'] ?? null,'contact_public_id'=>$work_order['contact_public_id'] ?? null,'location_public_id'=>$work_order['location_public_id'] ?? null,'service_public_id'=>$work_order['service_public_id'] ?? null])])
    @include('crm::finance-assistants.context-links',['financeSurface'=>'work','financeReferences'=>['work_order_public_id'=>$work_order['public_id'],'company_public_id'=>$work_order['company_public_id'] ?? null,'contact_public_id'=>$work_order['contact_public_id'] ?? null]])
    @if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
    <div class="d-flex flex-wrap justify-content-between gap-3 align-items-center mb-4"><div><span class="badge bg-secondary">{{ $work_order['status'] }}</span> <span class="badge bg-light text-dark">{{ $work_order['priority'] }}</span></div><a href="{{ route('dashboard.user.crm.field-services.work-orders') }}" class="btn btn-outline-secondary">Jobs</a></div>
    <div class="row g-4">
        <div class="col-xl-8">
            <div class="card mb-4"><div class="card-body"><h5>Status</h5><form class="row g-2" method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.status',$work_order['public_id']) }}">@csrf<div class="col-md-4"><select class="form-select" name="status">@foreach(['draft','ready','scheduled','dispatched','in_progress','paused','awaiting_customer','completed','invoiced','closed','cancelled'] as $status)<option value="{{ $status }}" @selected($work_order['status']===$status)>{{ str_replace('_',' ',$status) }}</option>@endforeach</select></div><div class="col-md-6"><input class="form-control" name="reason" placeholder="Reason / completion notes when required"></div><div class="col-md-2"><button class="btn btn-primary w-100">Update</button></div></form></div></div>

            <div class="card mb-4"><div class="card-body"><h5>Tasks</h5><form class="row g-2 mb-3" method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.tasks.store',$work_order['public_id']) }}">@csrf<div class="col-md-7"><input class="form-control" name="title" required placeholder="Task"></div><div class="col-md-3"><select class="form-select" name="required"><option value="1">Required</option><option value="0">Optional</option></select></div><div class="col-md-2"><button class="btn btn-outline-primary w-100">Add</button></div></form>
            <div class="table-responsive"><table class="table"><thead><tr><th>Task</th><th>Status</th><th>Action</th></tr></thead><tbody>@forelse($tasks as $task)<tr><td>{{ $task['title'] }}</td><td>{{ $task['status'] }}</td><td><form class="d-flex gap-1" method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.tasks.status',[$work_order['public_id'],$task['public_id']]) }}">@csrf<select class="form-select form-select-sm" name="status">@foreach(['pending','in_progress','completed','skipped'] as $state)<option value="{{$state}}" @selected($task['status']===$state)>{{$state}}</option>@endforeach</select><input class="form-control form-control-sm" name="reason" placeholder="Skip reason"><button class="btn btn-sm btn-outline-secondary">Save</button></form></td></tr>@empty<tr><td colspan="3">No tasks yet.</td></tr>@endforelse</tbody></table></div></div></div>

            <div class="card mb-4"><div class="card-body"><h5>Forms</h5><form class="d-flex gap-2 mb-3" method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.forms.start',$work_order['public_id']) }}">@csrf<select class="form-select" name="form_public_id" required><option value="">Select published form</option>@foreach($available_forms as $form)<option value="{{$form['public_id']}}">{{$form['name']}}</option>@endforeach</select><button class="btn btn-outline-primary">Start</button></form><ul class="list-group">@forelse($form_submissions as $submission)<li class="list-group-item d-flex justify-content-between"><span>{{$submission['template_public_id']}}</span><span>{{$submission['status']}}</span></li>@empty<li class="list-group-item text-muted">No form submissions.</li>@endforelse</ul></div></div>

            <div class="card"><div class="card-body"><h5>Evidence</h5><form class="row g-2 mb-3" method="post" enctype="multipart/form-data" action="{{ route('dashboard.user.crm.field-services.work-orders.evidence.store',$work_order['public_id']) }}">@csrf<div class="col-md-4"><select name="evidence_type" class="form-select"><option>photo</option><option>document</option><option>signature</option><option>certificate</option><option>other</option></select></div><div class="col-md-6"><input class="form-control" type="file" name="file" required></div><div class="col-md-2"><button class="btn btn-outline-primary w-100">Store</button></div></form><div class="small text-muted mb-2">Stored on the private CRM evidence disk.</div><ul>@foreach($evidence as $item)<li>{{ $item['original_name'] }} · {{ $item['evidence_type'] }}</li>@endforeach</ul></div></div>
        </div>

        <div class="col-12">
            @php
                $money = static fn($minor) => $minor === null ? '—' : (($health['currency'] ?? 'AUD').' '.number_format(((int)$minor)/100,2));
                $healthClass = match($health['health_status'] ?? 'unknown') { 'healthy'=>'success','warning'=>'warning','critical'=>'danger',default=>'secondary' };
                $spatialEvidence = $health['spatial_cost_evidence'] ?? [];
            @endphp
            <div class="card mb-4" data-work-order-health>
                <div class="card-body">
                    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
                        <div><h5 class="mb-1">Work-order health</h5><div class="text-muted small">Read-only operational profitability from authoritative Field records.</div></div>
                        <span class="badge bg-{{ $healthClass }}">{{ ucfirst($health['health_status'] ?? 'unknown') }}</span>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-2"><div class="small text-muted">Quoted revenue</div><strong>{{ $money($health['quoted_revenue_minor'] ?? null) }}</strong></div>
                        <div class="col-md-2"><div class="small text-muted">Forecast final cost</div><strong>{{ $money($health['forecast_final_cost_minor'] ?? null) }}</strong></div>
                        <div class="col-md-2"><div class="small text-muted">Projected margin</div><strong>{{ $money($health['projected_margin_minor'] ?? null) }}</strong><div class="small text-muted">{{ isset($health['projected_margin_percent']) && $health['projected_margin_percent'] !== null ? number_format((float)$health['projected_margin_percent'],1).'%' : '—' }}</div></div>
                        <div class="col-md-2"><div class="small text-muted">Actual labour</div><strong>{{ (int)($health['actual_labour_minutes'] ?? 0) }} min</strong><div class="small text-muted">{{ $money($health['known_actual_labour_cost_minor'] ?? null) }}</div></div>
                        <div class="col-md-2"><div class="small text-muted">Materials cost</div><strong>{{ $money($health['material_cost_minor'] ?? null) }}</strong></div>
                        <div class="col-md-2"><div class="small text-muted">Plan variance</div><strong>{{ !empty($health['over_hours']) ? 'Over hours' : 'Hours OK' }}</strong><div class="small text-muted">{{ !empty($health['over_budget']) ? 'Over budget' : 'Budget OK / unknown' }}</div></div>
                    </div>
                    <hr>
                    <div class="row g-3">
                        <div class="col-lg-7">
                            <div class="small text-muted">Spatial cost evidence</div>
                            <div><strong>{{ $spatialEvidence['provider'] ?? 'field-fallback' }}</strong> · {{ str_replace('_',' ',(string)($spatialEvidence['basis'] ?? 'no spatial evidence')) }}</div>
                            <div class="small text-muted">Travel: {{ isset($health['travel_distance_meters']) && $health['travel_distance_meters'] !== null ? number_format(((int)$health['travel_distance_meters'])/1000,1).' km' : '—' }} · {{ isset($health['travel_duration_seconds']) && $health['travel_duration_seconds'] !== null ? round(((int)$health['travel_duration_seconds'])/60).' min' : '—' }}</div>
                            <div class="small text-muted">Travel time cost: {{ $money($health['travel_time_cost_minor'] ?? null) }} · distance cost: {{ $money($health['travel_distance_cost_minor'] ?? null) }}</div>
                        </div>
                        <div class="col-lg-5">
                            <div class="small text-muted">Cost coverage</div>
                            <div class="small">Labour {{ !empty($health['cost_coverage']['labour_complete']) ? '✓' : 'incomplete' }} · materials {{ !empty($health['cost_coverage']['materials_complete']) ? '✓' : 'incomplete' }} · forecast {{ !empty($health['cost_coverage']['forecast_complete']) ? '✓' : 'incomplete' }}</div>
                            <div class="small text-muted mt-2">Maps pricing hints are advisory only; pricing hints are advisory and are never applied to Field revenue, invoices or margin automatically.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="card mb-4"><div class="card-body"><h5>Time</h5><form method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.time.store',$work_order['public_id']) }}">@csrf<input class="form-control mb-2" type="datetime-local" name="started_at" required><input class="form-control mb-2" type="number" min="0" name="minutes" placeholder="Minutes"><textarea class="form-control mb-2" name="notes" placeholder="Notes"></textarea><button class="btn btn-outline-primary w-100">Record time</button></form><hr>@foreach($time_entries as $entry)<div class="small mb-2">{{ $entry['started_at'] }} · {{ $entry['minutes'] ?? '—' }} min</div>@endforeach</div></div>
            <div class="card mb-4"><div class="card-body"><h5>Materials</h5><form method="post" action="{{ route('dashboard.user.crm.field-services.work-orders.materials.store',$work_order['public_id']) }}">@csrf<input class="form-control mb-2" name="name" required placeholder="Material"><input class="form-control mb-2" type="number" step="0.001" min="0.001" name="quantity" value="1" required><input class="form-control mb-2" name="unit" placeholder="Unit"><button class="btn btn-outline-primary w-100">Add material</button></form><hr>@foreach($materials as $item)<div class="small mb-2">{{ $item['name'] }} · {{ $item['quantity'] }} {{ $item['unit'] ?? '' }}</div>@endforeach</div></div>
            <div class="card"><div class="card-body"><h5>Dispatch & Schedule</h5><div class="small text-muted mb-2">Dispatch</div>@forelse($dispatch as $item)<div>{{ $item['status'] }} · worker #{{ $item['worker_user_id'] }}</div>@empty<div class="text-muted">Unassigned</div>@endforelse<hr><div class="small text-muted mb-2">Appointments</div>@forelse($appointments as $item)<div>{{ $item['scheduled_start'] }} · {{ $item['status'] }}</div>@empty<div class="text-muted">Unscheduled</div>@endforelse</div></div>
        </div>
    </div>
@endcomponent
@endsection
