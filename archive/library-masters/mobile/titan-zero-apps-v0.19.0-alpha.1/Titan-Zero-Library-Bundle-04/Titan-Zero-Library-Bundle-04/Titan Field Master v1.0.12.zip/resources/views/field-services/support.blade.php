@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Support','subtitle'=>'Customer support cases and operational follow-up.','surface'=>'customers','journey'=>'new-support-case'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Ticket</th><th>Priority</th><th>Status</th></tr></thead><tbody>@forelse($tickets as $x)<tr><td>{{$x['subject']}}</td><td>{{$x['priority']}}</td><td>{{$x['status']}}</td></tr>@empty<tr><td colspan="3" class="text-muted">No support cases.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
