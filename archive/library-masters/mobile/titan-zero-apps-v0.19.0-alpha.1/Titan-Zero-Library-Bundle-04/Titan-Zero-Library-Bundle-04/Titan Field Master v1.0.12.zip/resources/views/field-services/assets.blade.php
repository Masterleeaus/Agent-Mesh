@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Customer Assets','subtitle'=>'Equipment and assets installed at customer sites.','surface'=>'gear','journey'=>'new-customer-asset'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Asset</th><th>Type</th><th>Model</th><th>Next service</th></tr></thead><tbody>@forelse($assets as $x)<tr><td>{{$x['name']}}</td><td>{{$x['asset_type']}}</td><td>{{$x['manufacturer'] ?? ''}} {{$x['model'] ?? ''}}</td><td>{{$x['next_service_on'] ?? '—'}}</td></tr>@empty<tr><td colspan="4" class="text-muted">No customer assets.</td></tr>@endforelse</tbody></table></div></div>
@endcomponent
@endsection
