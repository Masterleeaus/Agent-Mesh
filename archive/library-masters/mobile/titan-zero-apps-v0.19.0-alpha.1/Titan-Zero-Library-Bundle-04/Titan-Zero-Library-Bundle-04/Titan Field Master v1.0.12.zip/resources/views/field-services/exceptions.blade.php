@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Operational Exceptions','subtitle'=>'SLA risks and field-operation issues that need attention.','surface'=>'crew','journey'=>'operational-exceptions'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<form method="POST" action="{{route('dashboard.user.crm.field-services.exceptions.detect')}}" class="mb-3">@csrf<button class="btn btn-primary">Detect exceptions</button></form>
<div class="card"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Severity</th><th>Type</th><th>Issue</th><th>Status</th><th>SLA due</th><th>Owner</th><th>Actions</th></tr></thead><tbody>
@forelse($exceptions as $x)<tr><td><span class="badge">{{strtoupper($x['severity'])}}</span></td><td>{{$x['exception_type']}}</td><td><strong>{{$x['title']}}</strong><div class="text-muted small">{{$x['description'] ?? ''}}</div></td><td>{{$x['status']}}</td><td>{{$x['sla_due_at'] ?? '—'}}</td><td>{{$x['owner_user_id'] ?? '—'}}</td><td>
@if($x['status']==='open')<form method="POST" action="{{route('dashboard.user.crm.field-services.exceptions.acknowledge',$x['public_id'])}}" class="d-inline">@csrf<button class="btn btn-sm btn-outline-primary">Acknowledge</button></form>@endif
@if(in_array($x['status'],['open','acknowledged','assigned']))<form method="POST" action="{{route('dashboard.user.crm.field-services.exceptions.resolve',$x['public_id'])}}" class="d-inline">@csrf<input type="hidden" name="resolution" value="Resolved from operational queue"><button class="btn btn-sm btn-outline-primary">Resolve</button></form>@endif
@if($x['status']==='resolved')<form method="POST" action="{{route('dashboard.user.crm.field-services.exceptions.close',$x['public_id'])}}" class="d-inline">@csrf<button class="btn btn-sm btn-outline-primary">Close</button></form>@endif
</td></tr>@empty<tr><td colspan="7" class="text-muted">No operational exceptions.</td></tr>@endforelse
</tbody></table></div></div>
@endcomponent
@endsection
