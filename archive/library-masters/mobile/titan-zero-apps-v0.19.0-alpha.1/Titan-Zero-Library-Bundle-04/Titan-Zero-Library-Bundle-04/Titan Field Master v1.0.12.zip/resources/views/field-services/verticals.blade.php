@extends('panel.layout.app')
@section('content')
@component('crm::components.interaction-page-shell',['title'=>'Vertical Profiles','subtitle'=>'Apply CRM-native service, task and form defaults while preserving user pricing.','surface'=>'work'])
@if(session('status'))<div class="alert alert-success">{{session('status')}}</div>@endif
<div class="row g-3">@foreach($profiles as $profile)@php($state=$installed[$profile['key']]??null)<div class="col-lg-6 col-xl-4"><div class="card h-100"><div class="card-body"><div class="d-flex justify-content-between gap-2"><h5>{{ $profile['name'] }}</h5><span class="badge border text-body">{{ $state?'Installed':'Available' }}</span></div><div class="small text-muted mb-3">{{ count($profile['services'] ?? []) }} services · {{ count($profile['forms'] ?? []) }} forms</div><ul class="small">@foreach(array_slice(array_values($profile['services'] ?? []),0,6) as $service)<li>{{ $service['name'] ?? 'Service' }}</li>@endforeach</ul><form method="post" action="{{ route('dashboard.user.crm.field-services.verticals.apply',$profile['key']) }}">@csrf<button class="btn btn-primary w-100">{{ $state?'Re-apply profile':'Apply profile' }}</button></form>@if($state)<div class="small text-muted mt-2">Last installed {{ $state['applied_at'] ?? $state['updated_at'] ?? '' }}</div>@endif</div></div></div>@endforeach</div>
@endcomponent
@endsection
