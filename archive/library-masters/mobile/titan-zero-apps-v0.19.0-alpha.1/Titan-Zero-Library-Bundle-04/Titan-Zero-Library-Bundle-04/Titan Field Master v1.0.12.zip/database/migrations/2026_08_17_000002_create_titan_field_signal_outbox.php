<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_field_signal_outbox')) return;

        Schema::create('titan_field_signal_outbox', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id', 26)->unique();
            $t->unsignedBigInteger('company_id')->index();
            $t->unsignedBigInteger('user_id')->nullable()->index();
            $t->unsignedBigInteger('actor_user_id')->nullable()->index();
            $t->string('event_name', 140)->index();
            $t->string('subject_type', 80)->index();
            $t->char('subject_public_id', 26)->nullable()->index();
            $t->string('trace_id', 191)->index();
            $t->string('correlation_id', 191)->index();
            $t->string('causation_id', 191)->index();
            $t->string('idempotency_key', 191);
            $t->json('payload');
            $t->json('receipt');
            $t->string('status', 30)->default('pending')->index();
            $t->unsignedInteger('attempts')->default(0);
            $t->timestamp('available_at')->nullable()->index();
            $t->timestamp('published_at')->nullable()->index();
            $t->text('last_error')->nullable();
            $t->timestamps();
            $t->unique(['company_id', 'idempotency_key'], 'titan_field_signal_outbox_tenant_idem_unique');
            $t->index(['company_id', 'status', 'available_at'], 'titan_field_signal_outbox_pending_idx');
        });
    }

    public function down(): void
    {
        // Signal envelopes and structured receipts are audit/replay evidence.
        // Titan Field's retain policy never destroys them on rollback/uninstall.
    }
};
