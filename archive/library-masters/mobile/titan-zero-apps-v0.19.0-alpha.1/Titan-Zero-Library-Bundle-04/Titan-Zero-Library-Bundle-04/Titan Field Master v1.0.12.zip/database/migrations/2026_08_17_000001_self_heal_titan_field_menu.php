<?php

declare(strict_types=1);

use App\Extensions\TitanField\System\Navigation\TitanFieldMenuInstaller;
use App\Extensions\TitanField\System\Activation\TitanFieldActivationGate;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (app(TitanFieldActivationGate::class)->isAuthoritativeReady() && Schema::hasTable('menus')) {
            TitanFieldMenuInstaller::sync();
        }
    }

    public function down(): void
    {
        // Navigation rows are retained. Existing CRM identities may pre-date Titan Field,
        // and deleting/deactivating them during rollback would damage host navigation.
    }
};
