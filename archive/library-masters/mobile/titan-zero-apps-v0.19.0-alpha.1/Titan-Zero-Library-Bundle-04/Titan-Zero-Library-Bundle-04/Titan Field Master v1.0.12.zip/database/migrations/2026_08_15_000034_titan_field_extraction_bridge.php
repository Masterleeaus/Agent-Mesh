<?php

declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    private array $tables=['crm_service_categories','crm_services','crm_service_variants','crm_service_locations','crm_service_requests','crm_customer_assets','crm_work_orders','crm_work_order_tasks','crm_work_order_services','crm_work_order_time_entries','crm_work_order_materials','crm_field_evidence','crm_appointments','crm_dispatch_assignments','crm_service_agreements','crm_service_agreement_services','crm_recurring_occurrences','crm_form_templates','crm_form_template_versions','crm_form_fields','crm_form_submissions','crm_form_responses','crm_service_areas','crm_support_tickets','crm_support_messages','crm_review_requests','crm_reviews','crm_service_recovery_cases','crm_service_history_events','crm_field_service_profiles'];
    public function up():void {
        foreach($this->tables as $table){ if(Schema::hasTable($table)&&!Schema::hasColumn($table,'company_id')) Schema::table($table,fn(Blueprint $t)=>$t->unsignedBigInteger('company_id')->nullable()->index()); }
        foreach(['crm_service_requests','crm_work_orders','crm_appointments','crm_customer_assets','crm_reviews','crm_support_tickets'] as $table) if(Schema::hasTable($table)&&!Schema::hasColumn($table,'entity_version')) Schema::table($table,fn(Blueprint $t)=>$t->unsignedBigInteger('entity_version')->default(1));
        if(Schema::hasTable('crm_services')) Schema::table('crm_services',function(Blueprint $t){ if(!Schema::hasColumn('crm_services','tax_behavior'))$t->string('tax_behavior',40)->default('default'); if(!Schema::hasColumn('crm_services','booking_available'))$t->boolean('booking_available')->default(true)->index(); if(!Schema::hasColumn('crm_services','required_skills'))$t->json('required_skills')->nullable(); if(!Schema::hasColumn('crm_services','field_requirements'))$t->json('field_requirements')->nullable(); if(!Schema::hasColumn('crm_services','evidence_requirements'))$t->json('evidence_requirements')->nullable(); if(!Schema::hasColumn('crm_services','form_template_public_ids'))$t->json('form_template_public_ids')->nullable(); if(!Schema::hasColumn('crm_services','recurring_eligible'))$t->boolean('recurring_eligible')->default(false)->index(); });
        if(Schema::hasTable('crm_work_order_materials')) Schema::table('crm_work_order_materials',function(Blueprint $t){ if(!Schema::hasColumn('crm_work_order_materials','inventory_item_public_id'))$t->char('inventory_item_public_id',26)->nullable()->index(); if(!Schema::hasColumn('crm_work_order_materials','stock_movement_public_id'))$t->char('stock_movement_public_id',26)->nullable()->index(); if(!Schema::hasColumn('crm_work_order_materials','unit_sale_price_minor'))$t->bigInteger('unit_sale_price_minor')->nullable(); if(!Schema::hasColumn('crm_work_order_materials','line_total_minor'))$t->bigInteger('line_total_minor')->nullable(); if(!Schema::hasColumn('crm_work_order_materials','invoice_line_public_id'))$t->char('invoice_line_public_id',26)->nullable()->index(); });
    }
    public function down():void {}
};
