<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_field_service_profiles')) {
            // This table existed in later CRM builds before extraction. Repair only
            // missing additive columns; never recreate/replace the table or its rows.
            $missing = [
                'public_id' => ! Schema::hasColumn('crm_field_service_profiles', 'public_id'),
                'user_id' => ! Schema::hasColumn('crm_field_service_profiles', 'user_id'),
                'company_id' => ! Schema::hasColumn('crm_field_service_profiles', 'company_id'),
                'profile_key' => ! Schema::hasColumn('crm_field_service_profiles', 'profile_key'),
                'profile_name' => ! Schema::hasColumn('crm_field_service_profiles', 'profile_name'),
                'profile_hash' => ! Schema::hasColumn('crm_field_service_profiles', 'profile_hash'),
                'profile_version' => ! Schema::hasColumn('crm_field_service_profiles', 'profile_version'),
                'enabled' => ! Schema::hasColumn('crm_field_service_profiles', 'enabled'),
                'applied_by_user_id' => ! Schema::hasColumn('crm_field_service_profiles', 'applied_by_user_id'),
                'applied_at' => ! Schema::hasColumn('crm_field_service_profiles', 'applied_at'),
                'settings' => ! Schema::hasColumn('crm_field_service_profiles', 'settings'),
                'metadata' => ! Schema::hasColumn('crm_field_service_profiles', 'metadata'),
                'created_at' => ! Schema::hasColumn('crm_field_service_profiles', 'created_at'),
                'updated_at' => ! Schema::hasColumn('crm_field_service_profiles', 'updated_at'),
            ];
            if (in_array(true, $missing, true)) {
                Schema::table('crm_field_service_profiles', function (Blueprint $t) use ($missing): void {
                    if ($missing['public_id']) $t->char('public_id', 26)->nullable()->index();
                    if ($missing['user_id']) $t->unsignedBigInteger('user_id')->nullable()->index();
                    if ($missing['company_id']) $t->unsignedBigInteger('company_id')->nullable()->index();
                    if ($missing['profile_key']) $t->string('profile_key', 120)->nullable();
                    if ($missing['profile_name']) $t->string('profile_name', 180)->nullable();
                    if ($missing['profile_hash']) $t->string('profile_hash', 64)->nullable();
                    if ($missing['profile_version']) $t->unsignedInteger('profile_version')->default(1);
                    if ($missing['enabled']) $t->boolean('enabled')->default(true)->index();
                    if ($missing['applied_by_user_id']) $t->unsignedBigInteger('applied_by_user_id')->nullable()->index();
                    if ($missing['applied_at']) $t->timestamp('applied_at')->nullable();
                    if ($missing['settings']) $t->json('settings')->nullable();
                    if ($missing['metadata']) $t->json('metadata')->nullable();
                    if ($missing['created_at']) $t->timestamp('created_at')->nullable();
                    if ($missing['updated_at']) $t->timestamp('updated_at')->nullable();
                });
            }
            return;
        }

        Schema::create('crm_field_service_profiles', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id', 26)->unique();
            $t->unsignedBigInteger('user_id')->index();
            $t->unsignedBigInteger('company_id')->nullable()->index();
            $t->string('profile_key', 120);
            $t->string('profile_name', 180);
            $t->string('profile_hash', 64);
            $t->unsignedInteger('profile_version')->default(1);
            $t->boolean('enabled')->default(true)->index();
            $t->unsignedBigInteger('applied_by_user_id')->nullable()->index();
            $t->timestamp('applied_at')->nullable();
            $t->json('settings')->nullable();
            $t->json('metadata')->nullable();
            $t->timestamps();
            $t->unique(['company_id','profile_key'], 'crm_field_service_profiles_user_key_unique');
        });
    }

    public function down(): void
    {
        // Retain profile installation history and user settings across rollback/reinstall.
    }
};
