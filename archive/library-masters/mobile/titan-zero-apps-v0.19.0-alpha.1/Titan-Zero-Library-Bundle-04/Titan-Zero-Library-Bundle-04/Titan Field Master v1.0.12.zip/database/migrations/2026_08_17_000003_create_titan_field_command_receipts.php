<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_field_command_receipts')) {
            Schema::create('titan_field_command_receipts', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->char('command_id', 26)->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('actor_user_id')->nullable()->index();
                $table->string('requested_capability', 160);
                $table->string('capability_id', 160)->index();
                $table->string('operation', 120);
                $table->string('permission', 160);
                $table->string('source', 80)->default('titan_field');
                $table->string('idempotency_key', 191);
                $table->char('idempotency_hash', 64);
                $table->char('request_hash', 64);
                $table->uuid('trace_id');
                $table->uuid('correlation_id');
                $table->uuid('causation_id');
                $table->string('status', 24)->default('processing')->index();
                $table->json('request_envelope')->nullable();
                $table->json('result')->nullable();
                $table->json('receipt')->nullable();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'idempotency_hash'], 'tf_cmd_tenant_idempotency_unique');
            });
            return;
        }

        // Restartable additive repair for a partially-created table.
        $columns = [
            'command_id' => fn (Blueprint $t) => $t->char('command_id', 26)->nullable(),
            'company_id' => fn (Blueprint $t) => $t->unsignedBigInteger('company_id')->nullable(),
            'actor_user_id' => fn (Blueprint $t) => $t->unsignedBigInteger('actor_user_id')->nullable(),
            'requested_capability' => fn (Blueprint $t) => $t->string('requested_capability', 160)->nullable(),
            'capability_id' => fn (Blueprint $t) => $t->string('capability_id', 160)->nullable(),
            'operation' => fn (Blueprint $t) => $t->string('operation', 120)->nullable(),
            'permission' => fn (Blueprint $t) => $t->string('permission', 160)->nullable(),
            'source' => fn (Blueprint $t) => $t->string('source', 80)->nullable(),
            'idempotency_key' => fn (Blueprint $t) => $t->string('idempotency_key', 191)->nullable(),
            'idempotency_hash' => fn (Blueprint $t) => $t->char('idempotency_hash', 64)->nullable(),
            'request_hash' => fn (Blueprint $t) => $t->char('request_hash', 64)->nullable(),
            'trace_id' => fn (Blueprint $t) => $t->uuid('trace_id')->nullable(),
            'correlation_id' => fn (Blueprint $t) => $t->uuid('correlation_id')->nullable(),
            'causation_id' => fn (Blueprint $t) => $t->uuid('causation_id')->nullable(),
            'status' => fn (Blueprint $t) => $t->string('status', 24)->nullable(),
            'request_envelope' => fn (Blueprint $t) => $t->json('request_envelope')->nullable(),
            'result' => fn (Blueprint $t) => $t->json('result')->nullable(),
            'receipt' => fn (Blueprint $t) => $t->json('receipt')->nullable(),
            'started_at' => fn (Blueprint $t) => $t->timestamp('started_at')->nullable(),
            'completed_at' => fn (Blueprint $t) => $t->timestamp('completed_at')->nullable(),
        ];
        foreach ($columns as $column => $add) {
            if (! Schema::hasColumn('titan_field_command_receipts', $column)) {
                Schema::table('titan_field_command_receipts', $add);
            }
        }
    }

    public function down(): void
    {
        // Retain governed command receipts. They are audit/idempotency/rollback metadata.
    }
};
