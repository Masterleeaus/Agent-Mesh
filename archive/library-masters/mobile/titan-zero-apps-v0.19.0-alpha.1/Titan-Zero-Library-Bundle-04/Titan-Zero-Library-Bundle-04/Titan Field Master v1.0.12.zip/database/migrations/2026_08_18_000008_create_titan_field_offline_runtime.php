<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_field_offline_devices')) {
            Schema::create('titan_field_offline_devices', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->unsignedBigInteger('worker_user_id')->nullable()->index();
                $t->char('device_hash',64);
                $t->string('device_name',180)->nullable();
                $t->string('platform',80)->nullable();
                $t->string('app_version',80)->nullable();
                $t->string('status',30)->default('active')->index();
                $t->dateTime('registered_at');
                $t->timestamp('last_seen_at')->nullable();
                $t->timestamp('revoked_at')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','device_hash'],'titan_field_offline_device_hash_uq');
            });
        }
        if (! Schema::hasTable('titan_field_offline_receipts')) {
            Schema::create('titan_field_offline_receipts', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->char('device_hash',64)->index();
                $t->string('operation_id',191);
                $t->string('operation',120)->index();
                $t->string('entity_type',80)->nullable()->index();
                $t->string('entity_public_id',191)->nullable()->index();
                $t->unsignedBigInteger('base_entity_version')->nullable();
                $t->unsignedBigInteger('result_entity_version')->nullable();
                $t->char('request_hash',64);
                $t->string('status',30)->index();
                $t->string('conflict_code',120)->nullable()->index();
                $t->dateTime('occurred_at');
                $t->dateTime('received_at');
                $t->json('request_envelope');
                $t->json('receipt')->nullable();
                $t->text('error_message')->nullable();
                $t->timestamps();
                $t->unique(['company_id','device_hash','operation_id'],'titan_field_offline_operation_uq');
            });
        }
        foreach (['crm_dispatch_assignments','crm_form_submissions','crm_work_order_tasks','titan_field_routes','titan_field_route_stops'] as $table) {
            if (Schema::hasTable($table) && ! Schema::hasColumn($table,'entity_version')) {
                Schema::table($table, fn(Blueprint $t) => $t->unsignedBigInteger('entity_version')->default(1)->index());
            }
        }
        if (Schema::hasTable('titan_field_worker_location_pings')) {
            Schema::table('titan_field_worker_location_pings', function(Blueprint $t):void{
                if(!Schema::hasColumn('titan_field_worker_location_pings','client_sample_id'))$t->string('client_sample_id',191)->nullable()->index();
                if(!Schema::hasColumn('titan_field_worker_location_pings','device_hash'))$t->char('device_hash',64)->nullable()->index();
                if(!Schema::hasColumn('titan_field_worker_location_pings','offline_sync'))$t->boolean('offline_sync')->default(false)->index();
            });
        }
    }

    public function down(): void
    {
        // Offline receipts/device provenance and entity versions are retained for reconciliation/audit safety.
    }
};
