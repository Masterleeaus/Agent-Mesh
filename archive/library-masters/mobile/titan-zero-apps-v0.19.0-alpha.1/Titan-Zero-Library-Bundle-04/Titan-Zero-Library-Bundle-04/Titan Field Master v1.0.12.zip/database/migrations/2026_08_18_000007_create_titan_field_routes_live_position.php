<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_field_routes')) {
            Schema::create('titan_field_routes', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('user_id')->index();
                $t->unsignedBigInteger('worker_user_id')->index();
                $t->date('route_date')->index();
                $t->string('name', 180);
                $t->string('status', 30)->default('draft')->index();
                $t->unsignedInteger('total_distance_meters')->default(0);
                $t->unsignedInteger('total_duration_seconds')->default(0);
                $t->timestamp('started_at')->nullable();
                $t->timestamp('completed_at')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','worker_user_id','route_date'], 'titan_field_route_worker_day_unique');
            });
        }

        if (! Schema::hasTable('titan_field_route_stops')) {
            Schema::create('titan_field_route_stops', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('route_public_id', 26)->index();
                $t->char('work_order_public_id', 26)->nullable()->index();
                $t->char('appointment_public_id', 26)->nullable()->index();
                $t->char('location_public_id', 26)->nullable()->index();
                $t->unsignedInteger('sequence')->default(1)->index();
                $t->string('status', 30)->default('planned')->index();
                $t->timestamp('planned_arrival_at')->nullable();
                $t->timestamp('planned_departure_at')->nullable();
                $t->timestamp('actual_arrival_at')->nullable();
                $t->timestamp('actual_departure_at')->nullable();
                $t->unsignedInteger('travel_seconds_from_previous')->nullable();
                $t->unsignedInteger('distance_meters_from_previous')->nullable();
                $t->text('notes')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','route_public_id','appointment_public_id'], 'titan_field_route_stop_appt_unique');
            });
        }

        if (! Schema::hasTable('titan_field_worker_location_pings')) {
            Schema::create('titan_field_worker_location_pings', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('worker_user_id')->index();
                $t->char('route_public_id', 26)->nullable()->index();
                $t->char('appointment_public_id', 26)->nullable()->index();
                $t->decimal('latitude', 10, 7);
                $t->decimal('longitude', 10, 7);
                $t->decimal('accuracy_meters', 10, 2)->nullable();
                $t->decimal('heading_degrees', 7, 2)->nullable();
                $t->decimal('speed_mps', 10, 3)->nullable();
                $t->string('source', 40)->default('titan-go');
                $t->dateTime('captured_at')->index();
                $t->dateTime('consent_granted_at');
                $t->dateTime('retention_expires_at')->index();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->index(['company_id','worker_user_id','captured_at'], 'titan_field_location_worker_time_idx');
            });
        }
    }

    public function down(): void
    {
        // Retain route history and privacy-sensitive location evidence by default.
        // Destructive removal must be an explicit retention/compliance operation.
    }
};
