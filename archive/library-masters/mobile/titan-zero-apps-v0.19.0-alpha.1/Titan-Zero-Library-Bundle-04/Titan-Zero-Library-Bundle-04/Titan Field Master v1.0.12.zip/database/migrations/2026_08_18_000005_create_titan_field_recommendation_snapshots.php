<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(Schema::hasTable('titan_field_recommendation_snapshots'))return;
        Schema::create('titan_field_recommendation_snapshots',function(Blueprint $t):void{
            $t->id();
            $t->char('public_id',26)->unique();
            $t->unsignedBigInteger('company_id')->index();
            $t->unsignedBigInteger('requested_by_user_id')->index();
            $t->string('policy_version',100)->index();
            $t->dateTime('scheduled_start')->index();
            $t->dateTime('scheduled_end')->index();
            $t->char('context_hash',64)->index();
            $t->char('recommendation_hash',64)->index();
            $t->unsignedBigInteger('top_worker_user_id')->nullable()->index();
            $t->unsignedTinyInteger('top_score')->nullable();
            $t->json('context');
            $t->json('recommendations');
            $t->string('trace_id',100)->nullable()->index();
            $t->string('correlation_id',100)->nullable()->index();
            $t->timestamp('created_at')->useCurrent()->index();
        });
    }

    public function down(): void
    {
        // Retain recommendation decision evidence under Titan Field's retain-on-uninstall policy.
    }
};
