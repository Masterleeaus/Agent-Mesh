<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('crm_field_worker_profiles')) {
            Schema::create('crm_field_worker_profiles', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('worker_user_id')->index();
                $t->json('skills')->nullable();
                $t->json('weekly_availability')->nullable();
                $t->unsignedInteger('max_daily_minutes')->default(720);
                $t->unsignedInteger('travel_buffer_minutes')->default(0);
                $t->string('timezone',80)->default('Australia/Melbourne');
                $t->boolean('active')->default(true)->index();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','worker_user_id'],'crm_field_worker_profile_unique');
            });
        }

        if (!Schema::hasTable('crm_field_worker_time_off')) {
            Schema::create('crm_field_worker_time_off', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('worker_user_id')->index();
                $t->dateTime('starts_at')->index();
                $t->dateTime('ends_at')->index();
                $t->string('status',30)->default('approved')->index();
                $t->string('reason',255)->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->index(['company_id','worker_user_id','status','starts_at'],'crm_field_time_off_worker_idx');
            });
        }

        if (Schema::hasTable('crm_work_orders')) {
            Schema::table('crm_work_orders', function (Blueprint $t): void {
                if (!Schema::hasColumn('crm_work_orders','completion_evidence_hash')) $t->char('completion_evidence_hash',64)->nullable()->index();
                if (!Schema::hasColumn('crm_work_orders','completion_evidence_snapshot')) $t->json('completion_evidence_snapshot')->nullable();
            });
        }

        if (Schema::hasTable('crm_work_order_time_entries')) {
            Schema::table('crm_work_order_time_entries', function (Blueprint $t): void {
                if (!Schema::hasColumn('crm_work_order_time_entries','billable')) $t->boolean('billable')->default(true)->index();
                if (!Schema::hasColumn('crm_work_order_time_entries','hourly_sale_rate_minor')) $t->bigInteger('hourly_sale_rate_minor')->nullable();
                if (!Schema::hasColumn('crm_work_order_time_entries','invoice_line_public_id')) $t->char('invoice_line_public_id',26)->nullable()->index();
            });
        }

        if (Schema::hasTable('crm_service_agreements')) {
            Schema::table('crm_service_agreements', function (Blueprint $t): void {
                if (!Schema::hasColumn('crm_service_agreements','last_generated_until')) $t->dateTime('last_generated_until')->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        // Retain worker availability/time-off, completion evidence and commercial
        // time-entry fields. These records are authoritative Titan Field state and
        // must survive rollback/reinstall under the extension retention policy.
    }
};
