<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('titan_field_operational_exceptions')) {
            Schema::create('titan_field_operational_exceptions', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id', 26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index();
                $t->unsignedBigInteger('owner_user_id')->nullable()->index();
                $t->string('exception_type', 80)->index();
                $t->string('severity', 20)->index();
                $t->string('status', 30)->default('open')->index();
                $t->string('subject_type', 80)->index();
                $t->char('subject_public_id', 26)->nullable()->index();
                $t->char('work_order_public_id', 26)->nullable()->index();
                $t->char('appointment_public_id', 26)->nullable()->index();
                $t->unsignedBigInteger('worker_user_id')->nullable()->index();
                $t->string('title', 220);
                $t->text('description')->nullable();
                $t->string('dedupe_key', 191);
                $t->dateTime('detected_at')->index();
                $t->dateTime('sla_due_at')->nullable()->index();
                $t->dateTime('acknowledged_at')->nullable();
                $t->dateTime('resolved_at')->nullable();
                $t->dateTime('closed_at')->nullable();
                $t->text('resolution')->nullable();
                $t->json('evidence')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['company_id','dedupe_key'], 'titan_field_exception_tenant_dedupe_unique');
                $t->index(['company_id','status','severity'], 'titan_field_exception_queue_index');
            });
        }
        if (! Schema::hasTable('titan_field_operational_exception_events')) {
            Schema::create('titan_field_operational_exception_events', function (Blueprint $t): void {
                $t->id();
                $t->char('public_id',26)->unique();
                $t->unsignedBigInteger('company_id')->index();
                $t->char('exception_public_id',26)->index('tf_exception_event_exception_idx');
                $t->unsignedBigInteger('actor_user_id')->nullable()->index();
                $t->string('event_type',60)->index();
                $t->string('from_status',30)->nullable();
                $t->string('to_status',30)->nullable();
                $t->text('note')->nullable();
                $t->json('payload')->nullable();
                $t->dateTime('occurred_at')->index();
                $t->timestamp('created_at')->useCurrent();
                $t->index(['company_id','exception_public_id','occurred_at'], 'titan_field_exception_event_timeline');
            });
        }
    }
    public function down(): void
    {
        // Retain exception history under Titan Field's retain-on-uninstall policy.
    }
};
