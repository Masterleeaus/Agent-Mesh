<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_field_route_optimisation_proposals')) return;
        Schema::create('titan_field_route_optimisation_proposals', function (Blueprint $t): void {
            $t->id();
            $t->char('public_id',26)->unique();
            $t->unsignedBigInteger('company_id')->index();
            $t->char('route_public_id',26)->index();
            $t->string('provider',80)->default('titan-maps-intelligence');
            $t->string('provider_proposal_id',64)->nullable()->index('tfrop_provider_proposal_idx');
            $t->char('input_hash',64)->index();
            $t->char('proposal_hash',64)->index();
            $t->json('baseline_stop_public_ids');
            $t->json('proposed_stop_public_ids');
            $t->json('proposal_payload');
            $t->string('status',30)->default('pending')->index();
            $t->unsignedInteger('entity_version')->default(1);
            $t->unsignedBigInteger('requested_by_user_id')->nullable()->index('tfrop_requested_by_idx');
            $t->unsignedBigInteger('accepted_by_user_id')->nullable()->index('tfrop_accepted_by_idx');
            $t->timestamp('expires_at')->nullable()->index();
            $t->timestamp('accepted_at')->nullable();
            $t->timestamp('rejected_at')->nullable();
            $t->text('rejection_reason')->nullable();
            $t->timestamp('applied_at')->nullable();
            $t->string('applied_command_receipt_id',191)->nullable();
            $t->timestamps();
            $t->unique(['company_id','input_hash','proposal_hash'],'tfrop_tenant_input_proposal_uq');
            $t->index(['company_id','route_public_id','status'],'tfrop_route_status_idx');
        });
    }
    public function down(): void
    {
        // Retained optimisation decision evidence. Never destroy on rollback/reinstall.
    }
};
