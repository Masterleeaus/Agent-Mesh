<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('crm_service_categories')) {
            Schema::create('crm_service_categories', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index();
                $t->string('key',120); $t->string('name',180); $t->text('description')->nullable(); $t->unsignedInteger('sort_order')->default(0);
                $t->boolean('active')->default(true)->index(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
                $t->unique(['company_id','key'],'crm_service_categories_user_key_unique');
            });
        }
        if (!Schema::hasTable('crm_services')) {
            Schema::create('crm_services', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('category_public_id',26)->nullable()->index();
                $t->string('key',120); $t->string('name',180); $t->text('description')->nullable(); $t->text('customer_faq')->nullable();
                $t->unsignedInteger('default_duration_minutes')->nullable(); $t->string('pricing_model',40)->default('fixed'); $t->bigInteger('price_minor')->nullable(); $t->char('currency',3)->default('AUD');
                $t->boolean('quote_required')->default(false); $t->boolean('emergency_capable')->default(false); $t->boolean('regulated_work')->default(false); $t->boolean('active')->default(true)->index();
                $t->json('intake_schema')->nullable(); $t->json('default_tasks')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
                $t->unique(['company_id','key'],'crm_services_user_key_unique');
            });
        }
        if (!Schema::hasTable('crm_service_variants')) {
            Schema::create('crm_service_variants', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('service_public_id',26)->index();
                $t->string('key',120); $t->string('name',180); $t->unsignedInteger('duration_minutes')->nullable(); $t->bigInteger('price_minor')->nullable(); $t->boolean('active')->default(true);
                $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','service_public_id','key'],'crm_service_variants_unique');
            });
        }
        if (!Schema::hasTable('crm_service_locations')) {
            Schema::create('crm_service_locations', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index();
                $t->string('name',180)->nullable(); $t->string('location_type',60)->default('service_site')->index(); $t->string('address_line_1',255); $t->string('address_line_2',255)->nullable();
                $t->string('suburb',120)->nullable(); $t->string('state',80)->nullable(); $t->string('postcode',20)->nullable()->index(); $t->string('country',2)->default('AU');
                $t->decimal('latitude',10,7)->nullable(); $t->decimal('longitude',10,7)->nullable(); $t->text('access_instructions')->nullable(); $t->text('parking_instructions')->nullable();
                $t->text('pet_notes')->nullable(); $t->text('hazard_notes')->nullable(); $t->json('preferred_service_windows')->nullable(); $t->char('service_area_public_id',26)->nullable()->index();
                $t->boolean('primary')->default(false); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_service_requests')) {
            Schema::create('crm_service_requests', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index();
                $t->char('location_public_id',26)->nullable()->index(); $t->char('service_public_id',26)->nullable()->index(); $t->char('asset_public_id',26)->nullable()->index(); $t->char('lead_public_id',26)->nullable()->index(); $t->char('deal_public_id',26)->nullable()->index();
                $t->string('title',220); $t->text('description')->nullable(); $t->string('status',40)->default('new')->index(); $t->string('priority',30)->default('normal')->index(); $t->string('urgency',30)->default('normal')->index();
                $t->string('source',60)->default('manual')->index(); $t->string('channel',60)->nullable()->index(); $t->timestamp('preferred_at')->nullable(); $t->timestamp('respond_by_at')->nullable();
                $t->unsignedBigInteger('owner_user_id')->nullable()->index(); $t->string('idempotency_key',120)->nullable(); $t->text('resolution')->nullable(); $t->json('intake_payload')->nullable(); $t->json('metadata')->nullable();
                $t->timestamp('qualified_at')->nullable(); $t->timestamp('accepted_at')->nullable(); $t->timestamp('resolved_at')->nullable(); $t->softDeletes(); $t->timestamps();
                $t->unique(['company_id','idempotency_key'],'crm_service_requests_idempotency_unique');
            });
        }
        if (!Schema::hasTable('crm_customer_assets')) {
            Schema::create('crm_customer_assets', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index();
                $t->string('asset_type',120)->index(); $t->string('name',180); $t->string('manufacturer',120)->nullable(); $t->string('model',120)->nullable(); $t->string('serial_number',160)->nullable()->index();
                $t->date('installed_on')->nullable(); $t->date('warranty_expires_on')->nullable(); $t->string('condition',50)->nullable(); $t->date('last_serviced_on')->nullable(); $t->date('next_service_on')->nullable()->index();
                $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_work_orders')) {
            Schema::create('crm_work_orders', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->string('number',80); $t->char('service_request_public_id',26)->nullable()->index(); $t->char('company_public_id',26)->nullable()->index();
                $t->char('contact_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index(); $t->char('asset_public_id',26)->nullable()->index(); $t->char('service_public_id',26)->nullable()->index();
                $t->string('title',220); $t->text('description')->nullable(); $t->string('status',40)->default('draft')->index(); $t->string('priority',30)->default('normal')->index();
                $t->unsignedBigInteger('owner_user_id')->nullable()->index(); $t->unsignedBigInteger('assigned_user_id')->nullable()->index(); $t->timestamp('scheduled_start')->nullable()->index(); $t->timestamp('scheduled_end')->nullable(); $t->string('timezone',80)->default('Australia/Melbourne');
                $t->timestamp('started_at')->nullable(); $t->timestamp('completed_at')->nullable(); $t->timestamp('closed_at')->nullable(); $t->string('idempotency_key',120)->nullable(); $t->text('completion_notes')->nullable(); $t->json('metadata')->nullable();
                $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','number'],'crm_work_orders_number_unique'); $t->unique(['company_id','idempotency_key'],'crm_work_orders_idempotency_unique');
            });
        }
        if (!Schema::hasTable('crm_work_order_tasks')) {
            Schema::create('crm_work_order_tasks', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->index(); $t->string('title',220); $t->text('instructions')->nullable();
                $t->boolean('required')->default(true); $t->string('status',30)->default('pending')->index(); $t->unsignedInteger('sort_order')->default(0); $t->unsignedBigInteger('completed_by_user_id')->nullable(); $t->timestamp('completed_at')->nullable(); $t->text('skip_reason')->nullable();
                $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_work_order_services')) {
            Schema::create('crm_work_order_services', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->index(); $t->char('service_public_id',26)->nullable()->index(); $t->string('description',220);
                $t->decimal('quantity',12,3)->default(1); $t->bigInteger('unit_price_minor')->default(0); $t->bigInteger('total_minor')->default(0); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_work_order_time_entries')) {
            Schema::create('crm_work_order_time_entries', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->index(); $t->unsignedBigInteger('worker_user_id')->index();
                $t->dateTime('started_at'); $t->timestamp('ended_at')->nullable(); $t->unsignedInteger('minutes')->nullable(); $t->text('notes')->nullable(); $t->string('source',40)->default('manual'); $t->string('idempotency_key',120)->nullable(); $t->timestamps();
                $t->unique(['company_id','idempotency_key'],'crm_work_order_time_idempotency_unique');
            });
        }
        if (!Schema::hasTable('crm_work_order_materials')) {
            Schema::create('crm_work_order_materials', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->index(); $t->string('name',180); $t->string('sku',100)->nullable();
                $t->decimal('quantity',12,3)->default(1); $t->string('unit',40)->nullable(); $t->bigInteger('unit_cost_minor')->nullable(); $t->boolean('billable')->default(true); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_field_evidence')) {
            Schema::create('crm_field_evidence', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->char('form_submission_public_id',26)->nullable()->index();
                $t->string('evidence_type',40)->index(); $t->string('disk',60)->default('local'); $t->string('path',500); $t->string('original_name',255)->nullable(); $t->string('mime_type',120)->nullable(); $t->unsignedBigInteger('size_bytes')->nullable(); $t->string('sha256',64)->nullable()->index();
                $t->decimal('latitude',10,7)->nullable(); $t->decimal('longitude',10,7)->nullable(); $t->timestamp('captured_at')->nullable(); $t->unsignedBigInteger('captured_by_user_id')->nullable()->index(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_appointments')) {
            Schema::create('crm_appointments', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->char('service_request_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index();
                $t->string('title',220); $t->string('status',30)->default('scheduled')->index(); $t->dateTime('scheduled_start')->index(); $t->dateTime('scheduled_end'); $t->string('timezone',80); $t->unsignedBigInteger('assigned_user_id')->nullable()->index();
                $t->text('customer_notes')->nullable(); $t->text('internal_notes')->nullable(); $t->string('idempotency_key',120)->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','idempotency_key'],'crm_appointments_idempotency_unique');
            });
        }
        if (!Schema::hasTable('crm_dispatch_assignments')) {
            Schema::create('crm_dispatch_assignments', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('work_order_public_id',26)->index(); $t->char('appointment_public_id',26)->nullable()->index(); $t->unsignedBigInteger('worker_user_id')->index();
                $t->string('status',30)->default('assigned')->index(); $t->timestamp('scheduled_start')->nullable()->index(); $t->timestamp('scheduled_end')->nullable(); $t->string('timezone',80)->nullable(); $t->timestamp('dispatched_at')->nullable(); $t->timestamp('arrived_at')->nullable(); $t->timestamp('completed_at')->nullable();
                $t->text('status_reason')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_service_agreements')) {
            Schema::create('crm_service_agreements', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index();
                $t->string('name',220); $t->string('status',30)->default('draft')->index(); $t->string('cadence',40); $t->unsignedInteger('interval_count')->default(1); $t->date('starts_on'); $t->date('ends_on')->nullable(); $t->timestamp('next_occurrence_at')->nullable()->index();
                $t->bigInteger('price_minor')->nullable(); $t->char('currency',3)->default('AUD'); $t->boolean('auto_create_work_order')->default(true); $t->json('preferences')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_service_agreement_services')) {
            Schema::create('crm_service_agreement_services', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('agreement_public_id',26)->index(); $t->char('service_public_id',26)->index(); $t->decimal('quantity',12,3)->default(1); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_recurring_occurrences')) {
            Schema::create('crm_recurring_occurrences', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('agreement_public_id',26)->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->dateTime('due_at')->index(); $t->string('status',30)->default('generated')->index();
                $t->string('idempotency_key',160); $t->json('metadata')->nullable(); $t->timestamps(); $t->unique(['company_id','idempotency_key'],'crm_recurring_occurrence_unique');
            });
        }
        if (!Schema::hasTable('crm_form_templates')) {
            Schema::create('crm_form_templates', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->string('key',120); $t->string('name',220); $t->string('form_type',50)->default('checklist')->index(); $t->string('applies_to',50)->default('work_order')->index();
                $t->string('status',30)->default('draft')->index(); $t->unsignedInteger('current_version')->default(1); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','key'],'crm_form_templates_user_key_unique');
            });
        }
        if (!Schema::hasTable('crm_form_template_versions')) {
            Schema::create('crm_form_template_versions', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('template_public_id',26)->index(); $t->unsignedInteger('version'); $t->string('status',30)->default('draft'); $t->timestamp('published_at')->nullable(); $t->unsignedBigInteger('published_by_user_id')->nullable(); $t->json('schema')->nullable(); $t->timestamps();
                $t->unique(['company_id','template_public_id','version'],'crm_form_template_version_unique');
            });
        }
        if (!Schema::hasTable('crm_form_fields')) {
            Schema::create('crm_form_fields', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('version_public_id',26)->index(); $t->string('key',120); $t->string('label',220); $t->string('field_type',50); $t->boolean('required')->default(false); $t->unsignedInteger('sort_order')->default(0); $t->json('options')->nullable(); $t->json('validation')->nullable(); $t->timestamps();
                $t->unique(['company_id','version_public_id','key'],'crm_form_fields_version_key_unique');
            });
        }
        if (!Schema::hasTable('crm_form_submissions')) {
            Schema::create('crm_form_submissions', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('template_public_id',26)->index(); $t->char('version_public_id',26)->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->char('service_request_public_id',26)->nullable()->index();
                $t->string('status',30)->default('draft')->index(); $t->unsignedBigInteger('submitted_by_user_id')->nullable()->index(); $t->timestamp('submitted_at')->nullable(); $t->boolean('has_failures')->default(false)->index(); $t->string('idempotency_key',160)->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
                $t->unique(['company_id','idempotency_key'],'crm_form_submissions_idempotency_unique');
            });
        }
        if (!Schema::hasTable('crm_form_responses')) {
            Schema::create('crm_form_responses', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('submission_public_id',26)->index(); $t->char('field_public_id',26)->index(); $t->text('value_text')->nullable(); $t->json('value_json')->nullable(); $t->boolean('failed')->default(false)->index(); $t->text('failure_notes')->nullable(); $t->timestamps();
                $t->unique(['company_id','submission_public_id','field_public_id'],'crm_form_response_unique');
            });
        }
        if (!Schema::hasTable('crm_service_areas')) {
            Schema::create('crm_service_areas', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->string('name',180); $t->string('match_type',30)->default('postcode')->index(); $t->json('postcodes')->nullable(); $t->decimal('center_latitude',10,7)->nullable(); $t->decimal('center_longitude',10,7)->nullable(); $t->decimal('radius_km',10,2)->nullable(); $t->json('polygon')->nullable(); $t->json('service_public_ids')->nullable(); $t->boolean('active')->default(true); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_support_tickets')) {
            Schema::create('crm_support_tickets', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index(); $t->char('asset_public_id',26)->nullable()->index(); $t->char('service_request_public_id',26)->nullable()->index();
                $t->string('subject',220); $t->text('description')->nullable(); $t->string('status',30)->default('open')->index(); $t->string('priority',30)->default('normal')->index(); $t->unsignedBigInteger('owner_user_id')->nullable()->index(); $t->string('source',60)->default('manual'); $t->timestamp('resolved_at')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_support_messages')) {
            Schema::create('crm_support_messages', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('ticket_public_id',26)->index(); $t->string('author_type',30); $t->unsignedBigInteger('author_user_id')->nullable(); $t->text('body'); $t->boolean('customer_visible')->default(true); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_review_requests')) {
            Schema::create('crm_review_requests', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->string('channel',40)->default('email'); $t->string('status',30)->default('pending')->index(); $t->timestamp('sent_at')->nullable(); $t->timestamp('responded_at')->nullable(); $t->string('token_hash',64)->nullable()->index(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_reviews')) {
            Schema::create('crm_reviews', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('review_request_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('work_order_public_id',26)->nullable()->index(); $t->unsignedTinyInteger('rating')->index(); $t->text('comment')->nullable(); $t->boolean('published')->default(false); $t->timestamp('reviewed_at')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_service_recovery_cases')) {
            Schema::create('crm_service_recovery_cases', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('review_public_id',26)->nullable()->index(); $t->char('support_ticket_public_id',26)->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('work_order_public_id',26)->nullable()->index();
                $t->string('status',30)->default('open')->index(); $t->string('resolution_type',50)->nullable(); $t->text('resolution_notes')->nullable(); $t->boolean('rebooking_requested')->default(false); $t->char('rebooking_service_request_public_id',26)->nullable()->index('crm_recovery_rebook_req_idx'); $t->unsignedBigInteger('owner_user_id')->nullable()->index(); $t->timestamp('resolved_at')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
            });
        }
        if (!Schema::hasTable('crm_service_history_events')) {
            Schema::create('crm_service_history_events', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('company_id')->nullable()->index(); $t->char('contact_public_id',26)->nullable()->index(); $t->char('company_public_id',26)->nullable()->index(); $t->char('location_public_id',26)->nullable()->index(); $t->string('subject_type',60)->index(); $t->char('subject_public_id',26)->nullable()->index(); $t->string('event_type',100)->index(); $t->string('title',220); $t->text('summary')->nullable(); $t->dateTime('occurred_at')->index(); $t->string('fingerprint',64)->nullable(); $t->json('metadata')->nullable(); $t->timestamps(); $t->unique(['company_id','fingerprint'],'crm_service_history_fingerprint_unique');
            });
        }

        $this->ensureIndex('crm_service_recovery_cases', 'crm_recovery_rebook_req_idx', 'rebooking_service_request_public_id');
    }

    private function ensureIndex(string $table, string $index, string $column): void
    {
        if (! Schema::hasTable($table) || ! Schema::hasColumn($table, $column)) return;
        $connection = Schema::getConnection();
        if ($connection->getDriverName() !== 'mysql') return;
        $exists = $connection->selectOne(
            'SELECT 1 AS present FROM information_schema.statistics WHERE table_schema = ? AND table_name = ? AND index_name = ? LIMIT 1',
            [$connection->getDatabaseName(), $table, $index],
        );
        if ($exists !== null) return;
        Schema::table($table, function (Blueprint $t) use ($column, $index): void {
            $t->index($column, $index);
        });
    }

    public function down(): void
    {
        // Titan Field owns historical CRM field-service data after extraction.
        // The extension retention policy is non-destructive: rollback/uninstall
        // must never drop customer, job, evidence, scheduling, support or review data.
    }
};
