<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('titan_field_worker_availability_rules'))Schema::create('titan_field_worker_availability_rules',function(Blueprint $t){
            $t->bigIncrements('id');$t->unsignedBigInteger('company_id')->index();$t->unsignedBigInteger('worker_user_id')->index();$t->unsignedTinyInteger('day_of_week');
            $t->time('starts_at');$t->time('ends_at');$t->date('effective_from')->nullable();$t->date('effective_until')->nullable();$t->boolean('active')->default(true);
            $t->string('source',64)->default('titan_field');$t->json('metadata')->nullable();$t->timestamps();$t->index(['company_id','worker_user_id','day_of_week'],'titan_field_avail_rule_lookup');
        });
        if(!Schema::hasTable('titan_field_worker_availability_exceptions'))Schema::create('titan_field_worker_availability_exceptions',function(Blueprint $t){
            $t->bigIncrements('id');$t->unsignedBigInteger('company_id')->index('tf_avail_exc_tenant_idx');$t->unsignedBigInteger('worker_user_id')->index();$t->dateTime('starts_at',6);$t->dateTime('ends_at',6);
            $t->string('status',32)->default('approved');$t->string('reason')->nullable();$t->json('metadata')->nullable();$t->timestamps();$t->index(['company_id','worker_user_id','starts_at'],'titan_field_avail_exception_lookup');
        });
        if(!Schema::hasTable('titan_field_blackout_policies'))Schema::create('titan_field_blackout_policies',function(Blueprint $t){
            $t->bigIncrements('id');$t->unsignedBigInteger('company_id')->index();$t->string('scope_type',32)->default('business');$t->string('scope_public_id',64)->nullable();$t->string('postcode',24)->nullable();
            $t->dateTime('starts_at',6);$t->dateTime('ends_at',6);$t->string('reason')->nullable();$t->boolean('active')->default(true);$t->json('metadata')->nullable();$t->timestamps();
            $t->index(['company_id','starts_at','ends_at'],'titan_field_blackout_window');$t->index(['company_id','scope_type','scope_public_id'],'titan_field_blackout_scope');
        });
    }
    public function down(): void { /* Retain availability/blackout history under Titan Field's retain uninstall policy. */ }
};
