<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Locations;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ServiceLocationService
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db,private FieldReferenceIntegrity $integrity) {}
    public function forContact(int $userId,string $contactPublicId): array
    { return $this->db->table('crm_service_locations')->where('company_id', $this->tenantContext->companyId($userId))->where('contact_public_id',$contactPublicId)->whereNull('deleted_at')->orderByDesc('primary')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }
    public function forCompany(int $userId,string $companyPublicId): array
    { return $this->db->table('crm_service_locations')->where('company_id', $this->tenantContext->companyId($userId))->where('company_public_id',$companyPublicId)->whereNull('deleted_at')->orderByDesc('primary')->get()->map(fn($r)=>(array)$r)->all(); }
    public function create(int $userId,array $data): array
    {
        $address=trim((string)($data['address_line_1']??'')); if($address==='')throw new InvalidArgumentException('Service location address is required.');
        $this->integrity->assertContext($userId,$data);
        $publicId=(string)Str::ulid();
        $row=['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'name'=>$data['name']??null,'location_type'=>$data['location_type']??'service_site','address_line_1'=>$address,'address_line_2'=>$data['address_line_2']??null,'suburb'=>$data['suburb']??null,'state'=>$data['state']??null,'postcode'=>$data['postcode']??null,'country'=>$data['country']??'AU','latitude'=>$data['latitude']??null,'longitude'=>$data['longitude']??null,'access_instructions'=>$data['access_instructions']??null,'parking_instructions'=>$data['parking_instructions']??null,'pet_notes'=>$data['pet_notes']??null,'hazard_notes'=>$data['hazard_notes']??null,'preferred_service_windows'=>isset($data['preferred_service_windows'])?json_encode($data['preferred_service_windows']):null,'service_area_public_id'=>$data['service_area_public_id']??null,'primary'=>(bool)($data['primary']??false),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()];
        $this->db->table('crm_service_locations')->insert($row); return (array)$this->db->table('crm_service_locations')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }
}
