<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Exceptions;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class OperationalExceptionService
{
    public function __construct(private FieldTenantContext $tenant, private ConnectionInterface $db, private FieldSignalPort $signals, private OperationalExceptionPolicy $policy) {}

    /** @return array<int,array<string,mixed>> */
    public function list(int $userId, array $filters=[]): array
    {
        $q=$this->db->table('titan_field_operational_exceptions')->where('company_id',$this->tenant->companyId($userId));
        foreach(['status','severity','exception_type','owner_user_id'] as $f) if(isset($filters[$f]) && $filters[$f] !== '') $q->where($f,$filters[$f]);
        return $q->orderByRaw("CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END")->orderBy('sla_due_at')->limit(300)->get()->map(fn($r)=>(array)$r)->all();
    }

    /** @return array<int,array<string,mixed>> */
    public function detect(int $userId, ?int $actorUserId=null, array $context=[]): array
    {
        $tenantId=$this->tenant->companyId($userId); $now=now(); $opened=[];
        $late=$this->db->table('crm_appointments')->where('company_id',$tenantId)->whereNull('deleted_at')->whereIn('status',['scheduled','confirmed'])->where('scheduled_start','<',$now->copy()->subMinutes(15))->where('scheduled_end','>',$now->copy()->subHours(12))->limit(100)->get();
        foreach($late as $r){$a=(array)$r;$opened[]=$this->open($userId,$actorUserId,['exception_type'=>'late_worker','subject_type'=>'appointment','subject_public_id'=>$a['public_id']??null,'appointment_public_id'=>$a['public_id']??null,'work_order_public_id'=>$a['work_order_public_id']??null,'worker_user_id'=>$a['assigned_user_id']??null,'title'=>'Worker may be late','description'=>'Scheduled start has passed without an in-progress appointment state.','dedupe_key'=>'late_worker|'.($a['public_id']??'')],$context);}
        $noShow=$this->db->table('crm_appointments')->where('company_id',$tenantId)->whereNull('deleted_at')->whereIn('status',['scheduled','confirmed'])->where('scheduled_end','<',$now)->where('scheduled_end','>',$now->copy()->subDay())->limit(100)->get();
        foreach($noShow as $r){$a=(array)$r;$opened[]=$this->open($userId,$actorUserId,['exception_type'=>'no_show','subject_type'=>'appointment','subject_public_id'=>$a['public_id']??null,'appointment_public_id'=>$a['public_id']??null,'work_order_public_id'=>$a['work_order_public_id']??null,'worker_user_id'=>$a['assigned_user_id']??null,'title'=>'Appointment may be a no-show','description'=>'Appointment end time passed without progression.','dedupe_key'=>'no_show|'.($a['public_id']??'')],$context);}
        $sla=$this->db->table('crm_service_requests')->where('company_id',$tenantId)->whereNull('deleted_at')->whereNotIn('status',['resolved','cancelled'])->whereNotNull('respond_by_at')->where('respond_by_at','<=',$now->copy()->addMinutes(30))->where('respond_by_at','>',$now->copy()->subHours(12))->limit(100)->get();
        foreach($sla as $r){$a=(array)$r;$opened[]=$this->open($userId,$actorUserId,['exception_type'=>'sla_risk','subject_type'=>'service_request','subject_public_id'=>$a['public_id']??null,'title'=>'Service request SLA at risk','description'=>'Response target is due or overdue.','dedupe_key'=>'sla_risk|'.($a['public_id']??''),'sla_due_at'=>$a['respond_by_at']??null],$context);}
        return $opened;
    }

    /** @return array<string,mixed> */
    public function open(int $userId, ?int $actorUserId, array $data, array $context=[]): array
    {
        $tenantId=$this->tenant->companyId($userId); $type=(string)($data['exception_type']??''); $defaults=$this->policy->defaults($type);
        $severity=(string)($data['severity']??$defaults['severity']); if(!in_array($severity,OperationalExceptionPolicy::SEVERITIES,true)) throw new InvalidArgumentException('Invalid exception severity.');
        $dedupe=trim((string)($data['dedupe_key']??'')); if($dedupe==='') $dedupe=hash('sha256',$type.'|'.($data['subject_type']??'').'|'.($data['subject_public_id']??''));
        $existing=$this->db->table('titan_field_operational_exceptions')->where('company_id',$tenantId)->where('dedupe_key',$dedupe)->first(); if($existing) return (array)$existing;
        return $this->db->transaction(function()use($userId,$actorUserId,$tenantId,$type,$severity,$defaults,$dedupe,$data,$context){
            $id=(string)Str::ulid(); $now=now(); $sla=isset($data['sla_due_at'])&&$data['sla_due_at']? $data['sla_due_at'] : $now->copy()->addMinutes($defaults['sla_minutes']);
            $row=['public_id'=>$id,'company_id'=>$tenantId,'created_by_user_id'=>$actorUserId,'owner_user_id'=>$data['owner_user_id']??null,'exception_type'=>$type,'severity'=>$severity,'status'=>'open','subject_type'=>(string)($data['subject_type']??'operation'),'subject_public_id'=>$data['subject_public_id']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'appointment_public_id'=>$data['appointment_public_id']??null,'worker_user_id'=>$data['worker_user_id']??null,'title'=>(string)($data['title']??str_replace('_',' ',ucfirst($type))),'description'=>$data['description']??null,'dedupe_key'=>substr($dedupe,0,191),'detected_at'=>$now,'sla_due_at'=>$sla,'acknowledged_at'=>null,'resolved_at'=>null,'closed_at'=>null,'resolution'=>null,'evidence'=>isset($data['evidence'])?json_encode($data['evidence']):null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>$now,'updated_at'=>$now];
            $this->db->table('titan_field_operational_exceptions')->insert($row); $this->event($tenantId,$id,$actorUserId,'opened',null,'open',null,$data); $this->signals->record($userId,$actorUserId,'field.exception.opened','operational_exception',$id,['exception_type'=>$type,'severity'=>$severity,'sla_due_at'=>(string)$sla],$context); return $row;
        });
    }

    public function acknowledge(int $userId, ?int $actorUserId, string $publicId, ?string $note=null, array $context=[]): array { return $this->transition($userId,$actorUserId,$publicId,'acknowledged',['note'=>$note],$context); }
    public function assign(int $userId, ?int $actorUserId, string $publicId, int $ownerUserId, ?string $note=null, array $context=[]): array { return $this->transition($userId,$actorUserId,$publicId,'assigned',['owner_user_id'=>$ownerUserId,'note'=>$note],$context); }
    public function resolve(int $userId, ?int $actorUserId, string $publicId, string $resolution, array $evidence=[], array $context=[]): array { return $this->transition($userId,$actorUserId,$publicId,'resolved',['resolution'=>$resolution,'evidence'=>$evidence],$context); }
    public function close(int $userId, ?int $actorUserId, string $publicId, ?string $note=null, array $context=[]): array { return $this->transition($userId,$actorUserId,$publicId,'closed',['note'=>$note],$context); }

    /** @return array<string,mixed> */
    private function transition(int $userId, ?int $actorUserId, string $publicId, string $to, array $data, array $context): array
    {
        $tenantId=$this->tenant->companyId($userId);
        return $this->db->transaction(function()use($userId,$actorUserId,$tenantId,$publicId,$to,$data,$context){$row=$this->db->table('titan_field_operational_exceptions')->where('company_id',$tenantId)->where('public_id',$publicId)->lockForUpdate()->first(); if(!$row)throw new InvalidArgumentException('Operational exception not found.'); $from=(string)$row->status; $this->policy->assertTransition($from,$to); $now=now(); $update=['status'=>$to,'updated_at'=>$now]; if($to==='acknowledged')$update['acknowledged_at']=$now; if($to==='assigned'){$update['owner_user_id']=(int)($data['owner_user_id']??0);$update['acknowledged_at']=$row->acknowledged_at?:$now;} if($to==='resolved'){$update['resolved_at']=$now;$update['resolution']=(string)($data['resolution']??'');$update['evidence']=json_encode($data['evidence']??[]);} if($to==='closed')$update['closed_at']=$now; $this->db->table('titan_field_operational_exceptions')->where('company_id',$tenantId)->where('public_id',$publicId)->update($update); $this->event($tenantId,$publicId,$actorUserId,$to,$from,$to,$data['note']??($data['resolution']??null),$data); $this->signals->record($userId,$actorUserId,'field.exception.'.$to,'operational_exception',$publicId,['from_status'=>$from,'to_status'=>$to,'owner_user_id'=>$update['owner_user_id']??$row->owner_user_id],$context); return array_merge((array)$row,$update);});
    }

    private function event(int $tenantId,string $exceptionId,?int $actor,string $event,string|null $from,string|null $to,?string $note,array $payload): void { $this->db->table('titan_field_operational_exception_events')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenantId,'exception_public_id'=>$exceptionId,'actor_user_id'=>$actor,'event_type'=>$event,'from_status'=>$from,'to_status'=>$to,'note'=>$note,'payload'=>json_encode($payload),'occurred_at'=>now(),'created_at'=>now()]); }
}
