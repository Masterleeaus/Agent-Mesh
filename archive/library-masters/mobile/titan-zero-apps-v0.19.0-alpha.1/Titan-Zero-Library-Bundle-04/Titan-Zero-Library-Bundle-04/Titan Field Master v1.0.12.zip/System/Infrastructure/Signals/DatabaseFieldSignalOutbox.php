<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Signals;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class DatabaseFieldSignalOutbox implements FieldSignalPort
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
    ) {}

    public function record(
        int $userId,
        ?int $actorUserId,
        string $eventName,
        string $subjectType,
        ?string $subjectPublicId,
        array $payload = [],
        array $context = [],
    ): array {
        $eventName = trim($eventName);
        $subjectType = trim($subjectType);
        if ($eventName === '' || $subjectType === '') {
            throw new InvalidArgumentException('Signal event_name and subject_type are required.');
        }

        $tenantId = $this->tenantContext->companyId($userId);
        $eventId = (string) Str::ulid();
        $traceId = $this->identifier($context['trace_id'] ?? null) ?? $eventId;
        $correlationId = $this->identifier($context['correlation_id'] ?? null) ?? $traceId;
        $causationId = $this->identifier($context['causation_id'] ?? null) ?? $correlationId;
        $idempotencyKey = $this->identifier($context['idempotency_key'] ?? null)
            ?? hash('sha256', implode('|', [$tenantId, $eventName, $subjectType, (string) $subjectPublicId, $causationId, $this->stableJson($payload)]));

        $existing = $this->db->table('titan_field_signal_outbox')
            ->where('company_id', $tenantId)
            ->where('idempotency_key', $idempotencyKey)
            ->first();
        if ($existing) {
            $receipt = json_decode((string) ($existing->receipt ?? ''), true);
            return is_array($receipt) ? $receipt : $this->receiptFromRow((array) $existing);
        }

        $now = now();
        $receipt = [
            'schema' => 'titan.field.signal.receipt.v1',
            'event_id' => $eventId,
            'company_id' => $tenantId,
            'event_name' => $eventName,
            'subject_type' => $subjectType,
            'subject_public_id' => $subjectPublicId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'idempotency_key' => $idempotencyKey,
            'status' => 'pending',
            'recorded_at' => $now->toISOString(),
        ];

        $this->db->table('titan_field_signal_outbox')->insert([
            'public_id' => $eventId,
            'company_id' => $tenantId,
            'user_id' => $this->tenantContext->actorUserId($userId),
            'actor_user_id' => $actorUserId,
            'event_name' => $eventName,
            'subject_type' => $subjectType,
            'subject_public_id' => $subjectPublicId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'idempotency_key' => $idempotencyKey,
            'payload' => $this->stableJson($payload),
            'receipt' => $this->stableJson($receipt),
            'status' => 'pending',
            'attempts' => 0,
            'available_at' => $now,
            'published_at' => null,
            'last_error' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $receipt;
    }

    private function identifier(mixed $value): ?string
    {
        if (! is_scalar($value)) return null;
        $value = trim((string) $value);
        return $value === '' ? null : substr($value, 0, 191);
    }

    /** @param array<string,mixed> $payload */
    private function stableJson(array $payload): string
    {
        $this->sortRecursive($payload);
        return (string) json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    /** @param array<string,mixed> $payload */
    private function sortRecursive(array &$payload): void
    {
        if (! array_is_list($payload)) ksort($payload);
        foreach ($payload as &$value) if (is_array($value)) $this->sortRecursive($value);
    }

    /** @param array<string,mixed> $row */
    private function receiptFromRow(array $row): array
    {
        return [
            'schema' => 'titan.field.signal.receipt.v1',
            'event_id' => $row['public_id'] ?? null,
            'company_id' => $row['company_id'] ?? null,
            'event_name' => $row['event_name'] ?? null,
            'subject_type' => $row['subject_type'] ?? null,
            'subject_public_id' => $row['subject_public_id'] ?? null,
            'trace_id' => $row['trace_id'] ?? null,
            'correlation_id' => $row['correlation_id'] ?? null,
            'causation_id' => $row['causation_id'] ?? null,
            'idempotency_key' => $row['idempotency_key'] ?? null,
            'status' => $row['status'] ?? 'pending',
        ];
    }
}
