<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Dispatch;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderService;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\SchedulingKernel;
use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;
use App\Extensions\TitanField\System\Contracts\FieldAuditPort;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class DispatchService
{
    public function __construct(private FieldAutomationPort $automation,private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private DispatchStatusPolicy $policy,private FieldAuditPort $audit,private WorkOrderService $workOrders,private SchedulingKernel $scheduling,private FieldReferenceIntegrity $integrity) {}
    public function board(int $userId,?string $date=null): array
    { $q=$this->db->table('crm_dispatch_assignments')->where('company_id',$this->tenantContext->companyId($userId))->whereNull('deleted_at');if($date)$q->whereDate('scheduled_start',$date);return $q->orderBy('scheduled_start')->get()->map(fn($r)=>(array)$r)->all(); }

    public function assign(int $userId,?int $actorUserId,string $workOrderPublicId,int $workerUserId,array $data=[]): array
    {
        $this->integrity->assertContext($userId,['work_order_public_id'=>$workOrderPublicId,'appointment_public_id'=>$data['appointment_public_id']??null]);$this->integrity->assertWorker($userId,$workerUserId);$tenant=$this->tenantContext->companyId($userId);$work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();
        if(!$work)throw new InvalidArgumentException('Work order not found.');if($workerUserId<=0)throw new InvalidArgumentException('A valid worker_user_id is required.');
        $start=$data['scheduled_start']??$work->scheduled_start??null;$end=$data['scheduled_end']??$work->scheduled_end??null;
        if(($start===null)!==($end===null))throw new InvalidArgumentException('Dispatch scheduling requires both scheduled_start and scheduled_end.');
        if($start!==null&&$end!==null)$this->scheduling->assertSchedulable($userId,$workerUserId,$start,$end,['service_public_id'=>(string)($work->service_public_id??''),'work_order_public_id'=>$workOrderPublicId,'location_public_id'=>(string)($work->location_public_id??''),'travel_buffer_minutes'=>$data['travel_buffer_minutes']??null]);
        return $this->db->transaction(function()use($tenant,$userId,$actorUserId,$workOrderPublicId,$workerUserId,$data,$work,$start,$end):array{
            $publicId=(string)Str::ulid();$this->db->table('crm_dispatch_assignments')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>$this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'appointment_public_id'=>$data['appointment_public_id']??null,'worker_user_id'=>$workerUserId,'status'=>'assigned','entity_version'=>1,'scheduled_start'=>$start,'scheduled_end'=>$end,'timezone'=>$data['timezone']??$work->timezone??config('titan-field.field_services.default_timezone','UTC'),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
            $updates=['assigned_user_id'=>$workerUserId,'updated_at'=>now()];if($start!==null&&$end!==null){$updates['scheduled_start']=$start;$updates['scheduled_end']=$end;}$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->update($updates);
            $record=(array)$this->db->table('crm_dispatch_assignments')->where('company_id',$tenant)->where('public_id',$publicId)->first();$ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='dispatch.assigned:'.$publicId;$this->signals->record($userId,$actorUserId,'field.dispatch.assigned','dispatch',$publicId,['work_order_public_id'=>$workOrderPublicId,'worker_user_id'=>$workerUserId,'scheduled_start'=>$start,'scheduled_end'=>$end],$ctx);$this->audit->record($userId,$actorUserId,'field_service.dispatch.assigned','dispatch',$publicId,null,$record);return $record;
        });
    }

    public function transition(int $userId,?int $actorUserId,string $publicId,string $toStatus,?string $reason=null): array
    { $q=$this->db->table('crm_dispatch_assignments')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at');$row=$q->first();if(!$row)throw new InvalidArgumentException('Dispatch assignment not found.');if((string)$row->status===$toStatus)return (array)$row;$this->policy->assertTransition((string)$row->status,$toStatus,$reason);$updates=['status'=>$toStatus,'status_reason'=>$reason,'entity_version'=>((int)($row->entity_version??1))+1,'updated_at'=>now()];if($toStatus==='dispatched')$updates['dispatched_at']=now();if($toStatus==='arrived')$updates['arrived_at']=now();if($toStatus==='completed')$updates['completed_at']=now();$this->db->transaction(function()use($q,$updates,$toStatus,$userId,$actorUserId,$row,$publicId,$reason):void{$q->update($updates);if($toStatus==='in_progress')$this->workOrders->transition($userId,$actorUserId,(string)$row->work_order_public_id,'in_progress','Dispatch started');$this->signals->record($userId,$actorUserId,'field.dispatch.status_changed','dispatch',$publicId,['work_order_public_id'=>(string)$row->work_order_public_id,'worker_user_id'=>$row->worker_user_id,'from'=>(string)$row->status,'to'=>$toStatus,'reason'=>$reason],['idempotency_key'=>hash('sha256','dispatch.status|'.$publicId.'|'.$row->status.'|'.$toStatus.'|'.(string)($row->updated_at??''))]);});$after=(array)$q->first();$this->audit->record($userId,$actorUserId,'field_service.dispatch.status_changed','dispatch',$publicId,(array)$row,$after,['reason'=>$reason]);if($toStatus==='failed')$this->automation->trigger($userId,'dispatch.failed',['subject_type'=>'dispatch','subject_public_id'=>$publicId,'work_order_public_id'=>(string)$row->work_order_public_id,'worker_user_id'=>$row->worker_user_id,'reason'=>$reason,'idempotency_key'=>'dispatch.failed:'.$publicId.':'.now()->format('YmdHi')]);return $after; }

    public function transitionForWorker(int $userId,?int $actorUserId,string $workOrderPublicId,int $workerUserId,string $toStatus,?string $reason=null): array
    {
        $this->integrity->assertWorker($userId,$workerUserId);
        $row=$this->db->table('crm_dispatch_assignments')->where('company_id',$this->tenantContext->companyId($userId))->where('work_order_public_id',$workOrderPublicId)->where('worker_user_id',$workerUserId)->whereNull('deleted_at')->orderByDesc('id')->first();
        if(!$row)throw new InvalidArgumentException('Dispatch assignment not found for this worker.');
        $progression=$this->progressionFor($toStatus);$current=(string)$row->status;
        if($progression===null)return $this->transition($userId,$actorUserId,(string)$row->public_id,$toStatus,$reason);
        $currentIndex=array_search($current,$progression,true);$targetIndex=array_search($toStatus,$progression,true);
        if($currentIndex===false||$targetIndex===false||$currentIndex>$targetIndex)return $this->transition($userId,$actorUserId,(string)$row->public_id,$toStatus,$reason);
        $last=(array)$row;
        for($i=$currentIndex+1;$i<=$targetIndex;$i++)$last=$this->transition($userId,$actorUserId,(string)$row->public_id,$progression[$i],$reason??'Titan Go field progression');
        return $last;
    }

    /** @return array<int,string>|null */
    private function progressionFor(string $target): ?array
    {
        $all=['assigned','dispatched','en_route','arrived','in_progress','completed'];
        $index=array_search($target,$all,true);return $index===false?null:array_slice($all,0,$index+1);
    }

    public function reassign(int $userId,?int $actorUserId,string $publicId,int $workerUserId,string $reason): array
    { if(trim($reason)==='')throw new InvalidArgumentException('A reassignment reason is required.');$this->integrity->assertWorker($userId,$workerUserId);$q=$this->db->table('crm_dispatch_assignments')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at');$row=$q->first();if(!$row)throw new InvalidArgumentException('Dispatch assignment not found.');if($row->scheduled_start&&$row->scheduled_end){$work=$this->db->table('crm_work_orders')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$row->work_order_public_id)->first();$this->scheduling->assertSchedulable($userId,$workerUserId,$row->scheduled_start,$row->scheduled_end,['service_public_id'=>(string)($work->service_public_id??''),'work_order_public_id'=>(string)$row->work_order_public_id,'location_public_id'=>(string)($work->location_public_id??'')]);}$after=$this->db->transaction(function()use($q,$row,$userId,$actorUserId,$publicId,$workerUserId,$reason):array{$q->update(['worker_user_id'=>$workerUserId,'status'=>'assigned','status_reason'=>$reason,'entity_version'=>((int)($row->entity_version??1))+1,'updated_at'=>now()]);$this->db->table('crm_work_orders')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$row->work_order_public_id)->update(['assigned_user_id'=>$workerUserId,'updated_at'=>now()]);$after=(array)$q->first();$this->signals->record($userId,$actorUserId,'field.dispatch.reassigned','dispatch',$publicId,['work_order_public_id'=>(string)$row->work_order_public_id,'from_worker_user_id'=>$row->worker_user_id,'to_worker_user_id'=>$workerUserId,'reason'=>$reason],['idempotency_key'=>hash('sha256','dispatch.reassign|'.$publicId.'|'.$row->worker_user_id.'|'.$workerUserId.'|'.(string)($row->updated_at??''))]);return $after;});$this->audit->record($userId,$actorUserId,'field_service.dispatch.reassigned','dispatch',$publicId,(array)$row,$after,['reason'=>$reason]);return $after; }
}
