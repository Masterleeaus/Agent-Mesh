<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Verticals;

use InvalidArgumentException;

final class FieldServiceVerticalProfileService
{
    public const CANONICAL_SLUGS = [
        'cleaning',
        'plumbing',
        'electrical',
        'hvac',
        'handyman-property-maintenance',
        'landscaping-gardening',
        'pest-control',
        'locksmith-security',
        'roofing-guttering',
        'appliance-equipment-repair',
    ];

    private const LEGACY_ALIASES = [
        'handyman' => 'handyman-property-maintenance',
        'gardening' => 'landscaping-gardening',
    ];

    /** @return list<string> */
    public function keys(): array
    {
        $files = glob(dirname(__DIR__,4) . '/resources/field-services/verticals/*.json') ?: [];
        $keys = array_values(array_map(static fn(string $file): string => basename($file,'.json'),$files));
        sort($keys);
        return $keys;
    }

    /** @return list<string> */
    public function canonicalSlugs(): array
    {
        return self::CANONICAL_SLUGS;
    }

    public function canonicalSlug(string $key): string
    {
        $safe = preg_replace('/[^a-z0-9_\-]/i','',$key) ?: '';
        return self::LEGACY_ALIASES[$safe] ?? $safe;
    }

    /** @return array<string,mixed> */
    public function profile(string $key): array
    {
        $safe = preg_replace('/[^a-z0-9_\-]/i','',$key) ?: '';
        $file = dirname(__DIR__,4) . '/resources/field-services/verticals/' . $safe . '.json';
        if (! is_file($file)) {
            throw new InvalidArgumentException('Unknown field-service vertical profile.');
        }
        $data = json_decode((string) file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
        if (($data['key'] ?? null) !== $safe || ! is_array($data['services'] ?? null)) {
            throw new InvalidArgumentException('Invalid field-service vertical profile.');
        }
        if (($data['canonical'] ?? false) === true && ($data['slug'] ?? null) !== $safe) {
            throw new InvalidArgumentException('Canonical field-service vertical profile slug mismatch.');
        }
        return $data;
    }

    /** @return array<string,array<string,mixed>> */
    public function canonicalProfiles(): array
    {
        $profiles = [];
        foreach (self::CANONICAL_SLUGS as $slug) {
            $profiles[$slug] = $this->profile($slug);
        }
        return $profiles;
    }
}
