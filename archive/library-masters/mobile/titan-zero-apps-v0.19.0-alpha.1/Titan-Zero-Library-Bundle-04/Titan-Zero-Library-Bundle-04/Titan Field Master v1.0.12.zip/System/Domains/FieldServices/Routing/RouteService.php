<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Routing;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RouteService
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private FieldSignalPort $signals,
        private SpatialIntelligenceGateway $spatial,
        private ConnectionInterface $db,
    ) {}

    /** Route optimization is not claimed: sequencing is explicit/manual or appointment-time ordered. */
    public function list(int $userId, ?string $date = null): array
    {
        $tenantId = $this->tenantContext->companyId($userId);
        $routes = $this->db->table('titan_field_routes')->where('company_id', $tenantId)
            ->when($date, fn($q) => $q->whereDate('route_date', $date))
            ->orderByDesc('route_date')->orderBy('worker_user_id')->get()->map(fn($r)=>(array)$r)->all();
        $workerIds=array_values(array_unique(array_map(static fn(array $r):int=>(int)$r['worker_user_id'],$routes)));
        $positions=[]; foreach($this->spatial->latestWorkerPositions($userId,$workerIds) as $position){$positions[(int)($position['worker_user_id']??0)]=$position;}
        foreach ($routes as &$route) {
            $route['stops'] = $this->db->table('titan_field_route_stops')->where('company_id', $tenantId)
                ->where('route_public_id', $route['public_id'])->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all();
            $route['latest_location'] = $positions[(int)$route['worker_user_id']] ?? [];
            $route['spatial_provider'] = $this->spatial->available($userId) ? 'titan-maps-intelligence' : 'field-fallback';
        }
        return $routes;
    }

    public function createForWorkerDay(int $userId, ?int $actorUserId, int $workerUserId, string $routeDate, ?string $name = null, array $context = []): array
    {
        $tenantId = $this->tenantContext->companyId($userId);
        $this->assertWorker($tenantId, $workerUserId);
        return $this->db->transaction(function () use ($userId,$actorUserId,$workerUserId,$routeDate,$name,$context,$tenantId) {
            $existing = $this->db->table('titan_field_routes')->where('company_id',$tenantId)->where('worker_user_id',$workerUserId)->whereDate('route_date',$routeDate)->first();
            if ($existing) return (array) $existing;
            $publicId=(string)Str::ulid(); $now=now();
            $row=['public_id'=>$publicId,'company_id'=>$tenantId,'user_id'=>$this->tenantContext->actorUserId($userId) ?? $userId,'worker_user_id'=>$workerUserId,'route_date'=>$routeDate,'name'=>$name ?: 'Route '.$routeDate,'status'=>'draft','entity_version'=>1,'total_distance_meters'=>0,'total_duration_seconds'=>0,'started_at'=>null,'completed_at'=>null,'metadata'=>json_encode(['source'=>'titan-field']),'created_at'=>$now,'updated_at'=>$now];
            $this->db->table('titan_field_routes')->insert($row);
            $this->signals->record($userId,$actorUserId,'field.route.created','field_route',$publicId,['worker_user_id'=>$workerUserId,'route_date'=>$routeDate],$context);
            return $row;
        });
    }

    public function addStop(int $userId, ?int $actorUserId, string $routePublicId, string $appointmentPublicId, array $context = []): array
    {
        $tenantId=$this->tenantContext->companyId($userId);
        return $this->db->transaction(function () use ($userId,$actorUserId,$routePublicId,$appointmentPublicId,$context,$tenantId) {
            $route=$this->route($tenantId,$routePublicId,true);
            $appointment=$this->db->table('crm_appointments')->where('company_id',$tenantId)->where('public_id',$appointmentPublicId)->whereNull('deleted_at')->first();
            if(!$appointment) throw new InvalidArgumentException('Appointment does not belong to this Titan Field tenant.');
            if($appointment->assigned_user_id && (int)$appointment->assigned_user_id !== (int)$route->worker_user_id) throw new InvalidArgumentException('Appointment is assigned to a different worker.');
            $sequence=(int)$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$routePublicId)->max('sequence')+1;
            $publicId=(string)Str::ulid(); $now=now();
            $row=['public_id'=>$publicId,'company_id'=>$tenantId,'route_public_id'=>$routePublicId,'work_order_public_id'=>$appointment->work_order_public_id,'appointment_public_id'=>$appointmentPublicId,'location_public_id'=>$appointment->location_public_id,'sequence'=>$sequence,'status'=>'planned','entity_version'=>1,'planned_arrival_at'=>$appointment->scheduled_start,'planned_departure_at'=>$appointment->scheduled_end,'actual_arrival_at'=>null,'actual_departure_at'=>null,'travel_seconds_from_previous'=>null,'distance_meters_from_previous'=>null,'notes'=>null,'metadata'=>json_encode(['source'=>'appointment']),'created_at'=>$now,'updated_at'=>$now];
            $this->db->table('titan_field_route_stops')->updateOrInsert(['company_id'=>$tenantId,'route_public_id'=>$routePublicId,'appointment_public_id'=>$appointmentPublicId],$row);
            $this->recalculateTravel($userId,$tenantId,$routePublicId);
            $this->signals->record($userId,$actorUserId,'field.route.stop_added','field_route_stop',$publicId,['route_public_id'=>$routePublicId,'appointment_public_id'=>$appointmentPublicId],$context);
            return $row;
        });
    }

    /** @param array<int,string> $orderedStopPublicIds */
    public function resequence(int $userId, ?int $actorUserId, string $routePublicId, array $orderedStopPublicIds, array $context = []): array
    {
        $tenantId=$this->tenantContext->companyId($userId);
        return $this->db->transaction(function () use ($userId,$actorUserId,$routePublicId,$orderedStopPublicIds,$context,$tenantId) {
            $this->route($tenantId,$routePublicId,true);
            $existing=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$routePublicId)->pluck('public_id')->map(fn($v)=>(string)$v)->all();
            $requested=array_values(array_unique(array_map('strval',$orderedStopPublicIds)));
            sort($existing); $verify=$requested; sort($verify);
            if($existing!==$verify) throw new InvalidArgumentException('Route resequence must contain every existing stop exactly once.');
            foreach($requested as $i=>$stopId)$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$routePublicId)->where('public_id',$stopId)->update(['sequence'=>$i+1,'entity_version'=>$this->nextStopVersion($tenantId,$stopId),'updated_at'=>now()]);
            $this->recalculateTravel($userId,$tenantId,$routePublicId);
            $this->signals->record($userId,$actorUserId,'field.route.resequenced','field_route',$routePublicId,['stop_public_ids'=>$requested],$context);
            return $this->routeDetail($tenantId,$routePublicId);
        });
    }

    public function transitionStop(int $userId, ?int $actorUserId, string $stopPublicId, string $status, ?string $note = null, array $context = []): array
    {
        $allowed=['planned','en_route','arrived','in_progress','completed','skipped'];
        if(!in_array($status,$allowed,true)) throw new InvalidArgumentException('Unsupported route stop status.');
        $tenantId=$this->tenantContext->companyId($userId);
        return $this->db->transaction(function () use ($userId,$actorUserId,$stopPublicId,$status,$note,$context,$tenantId) {
            $stop=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('public_id',$stopPublicId)->lockForUpdate()->first();
            if(!$stop) throw new InvalidArgumentException('Route stop not found.');
            $update=['status'=>$status,'notes'=>$note ?? $stop->notes,'entity_version'=>((int)($stop->entity_version??1))+1,'updated_at'=>now()];
            if($status==='arrived' && !$stop->actual_arrival_at)$update['actual_arrival_at']=now();
            if(in_array($status,['completed','skipped'],true) && !$stop->actual_departure_at)$update['actual_departure_at']=now();
            $this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('id',$stop->id)->update($update);
            $this->syncRouteStatus($tenantId,(string)$stop->route_public_id);
            $this->signals->record($userId,$actorUserId,'field.route.stop_status_changed','field_route_stop',$stopPublicId,['status'=>$status,'route_public_id'=>$stop->route_public_id],$context);
            return (array)$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('id',$stop->id)->first();
        });
    }

    public function recordLocationPing(int $userId, ?int $actorUserId, int $workerUserId, float $latitude, float $longitude, float $accuracyMeters, array $data = [], array $context = []): array
    {
        if($latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) throw new InvalidArgumentException('Invalid coordinates.');
        $payload=array_merge($data,['latitude'=>$latitude,'longitude'=>$longitude,'accuracy_meters'=>$accuracyMeters]);
        $result=$this->spatial->recordWorkerLocation($userId,$workerUserId,$payload);
        $reference=(string)($result['ping_id']??$result['public_id']??Str::ulid());
        $this->signals->record($userId,$actorUserId,'field.worker.location_recorded','field_worker_location',$reference,[
            'worker_user_id'=>$workerUserId,'route_public_id'=>$data['route_public_id']??null,'accuracy_meters'=>$accuracyMeters,
            'spatial_provider'=>$result['provider']??($this->spatial->available($userId)?'titan-maps-intelligence':'field-fallback'),
        ],$context);
        return $result;
    }

    private function nextStopVersion(int $tenantId,string $stopPublicId): int
    {
        $row=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('public_id',$stopPublicId)->first();
        return ((int)($row->entity_version??1))+1;
    }

    private function assertWorker(int $tenantId,int $workerUserId): void
    {
        $ok=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenantId)->where('worker_user_id',$workerUserId)->where('active',true)->exists();
        if(!$ok) throw new InvalidArgumentException('Worker is not an active Titan Field worker.');
    }

    private function route(int $tenantId,string $publicId,bool $lock=false): object
    {
        $q=$this->db->table('titan_field_routes')->where('company_id',$tenantId)->where('public_id',$publicId); if($lock)$q->lockForUpdate();
        $row=$q->first(); if(!$row) throw new InvalidArgumentException('Route not found.'); return $row;
    }

    private function routeDetail(int $tenantId,string $publicId): array
    {
        $route=(array)$this->route($tenantId,$publicId); $route['stops']=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$publicId)->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all(); return $route;
    }

    private function recalculateTravel(int $userId,int $tenantId,string $routePublicId): void
    {
        $stops=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$routePublicId)->orderBy('sequence')->get();
        $previous=null; $totalDistance=0; $totalDuration=0;
        foreach($stops as $stop){
            $distance=null;$duration=null;
            $loc=$stop->location_public_id?$this->db->table('crm_service_locations')->where('company_id',$tenantId)->where('public_id',$stop->location_public_id)->whereNull('deleted_at')->first():null;
            if($previous && $loc && $previous->latitude!==null && $previous->longitude!==null && $loc->latitude!==null && $loc->longitude!==null){
                $estimate=$this->spatial->estimateTravel($userId,['latitude'=>(float)$previous->latitude,'longitude'=>(float)$previous->longitude],['latitude'=>(float)$loc->latitude,'longitude'=>(float)$loc->longitude],[
                    'origin_reference_type'=>'property','destination_reference_type'=>'property','destination_public_reference_id'=>(string)$stop->location_public_id,
                ]);
                $distance=(int)($estimate['road_distance_meters']??$estimate['straight_line_distance_meters']??$estimate['distance_meters']??0);
                $duration=isset($estimate['duration_seconds'])?(int)$estimate['duration_seconds']:null;
                if($distance>0)$totalDistance+=$distance;if($duration!==null&&$duration>0)$totalDuration+=$duration;
            }
            $metadata=json_decode((string)($stop->metadata??''),true);$metadata=is_array($metadata)?$metadata:[];$metadata['spatial_provider']=$this->spatial->available($userId)?'titan-maps-intelligence':'field-fallback';
            $this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('id',$stop->id)->update(['distance_meters_from_previous'=>$distance?:null,'travel_seconds_from_previous'=>$duration,'metadata'=>json_encode($metadata),'updated_at'=>now()]);
            if($loc)$previous=$loc;
        }
        $this->db->table('titan_field_routes')->where('company_id',$tenantId)->where('public_id',$routePublicId)->update(['total_distance_meters'=>$totalDistance,'total_duration_seconds'=>$totalDuration,'updated_at'=>now()]);
    }

    private function syncRouteStatus(int $tenantId,string $routePublicId): void
    {
        $statuses=$this->db->table('titan_field_route_stops')->where('company_id',$tenantId)->where('route_public_id',$routePublicId)->pluck('status')->all();
        $status='draft'; $started=null; $completed=null;
        if($statuses!==[]){if(count(array_filter($statuses,fn($s)=>in_array($s,['completed','skipped'],true)))===count($statuses)){$status='completed';$completed=now();}elseif(count(array_filter($statuses,fn($s)=>$s!=='planned'))>0){$status='in_progress';$started=now();}else{$status='active';}}
        $update=['status'=>$status,'updated_at'=>now()]; if($started)$update['started_at']=$started;if($completed)$update['completed_at']=$completed;
        $this->db->table('titan_field_routes')->where('company_id',$tenantId)->where('public_id',$routePublicId)->update($update);
    }
}
