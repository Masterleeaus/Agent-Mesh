<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldAutomationPort
{
    /** @param array<string,mixed> $payload */
    public function trigger(int $userId, string $eventName, array $payload = []): void;
}
