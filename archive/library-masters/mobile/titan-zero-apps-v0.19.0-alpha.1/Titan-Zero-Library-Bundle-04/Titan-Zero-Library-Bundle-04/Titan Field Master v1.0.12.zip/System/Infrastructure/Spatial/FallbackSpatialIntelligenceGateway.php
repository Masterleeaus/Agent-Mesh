<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Spatial;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use App\Extensions\TitanField\System\Domains\FieldServices\Routing\WorkerLocationPolicy;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\TravelEstimator;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Bounded standalone fallback used only when Titan Maps Intelligence is absent/unavailable. */
final class FallbackSpatialIntelligenceGateway implements SpatialIntelligenceGateway
{
    public function __construct(private FieldTenantContext $tenantContext, private WorkerLocationPolicy $policy, private TravelEstimator $travel, private ConnectionInterface $db) {}
    public function available(int $userId): bool { return false; }

    public function latestWorkerPositions(int $userId, array $workerUserIds = []): array
    {
        $tenant = $this->tenantContext->companyId($userId);
        $requested = array_values(array_unique(array_filter(array_map('intval', $workerUserIds), static fn(int $id): bool => $id > 0)));

        // Live fallback visibility must re-check current consent and current shift state.
        // Retained evidence is not permission to keep projecting a worker after consent/off-duty changes.
        $profiles = $this->db->table('crm_field_worker_profiles')
            ->where('company_id', $tenant)->where('active', true)
            ->when($requested !== [], fn($q) => $q->whereIn('worker_user_id', $requested))
            ->get();
        $consentByWorker = [];
        foreach ($profiles as $profile) {
            $metadata = json_decode((string) ($profile->metadata ?? ''), true);
            $metadata = is_array($metadata) ? $metadata : [];
            $grantedAt = trim((string) ($metadata['location_tracking_consent_granted_at'] ?? ''));
            if ((bool) ($metadata['location_tracking_consent'] ?? false) && $grantedAt !== '') {
                $consentByWorker[(int) $profile->worker_user_id] = $grantedAt;
            }
        }
        if ($consentByWorker === []) return [];

        $activeWorkers = $this->db->table('titan_field_routes')
            ->where('company_id', $tenant)
            ->whereIn('worker_user_id', array_keys($consentByWorker))
            ->whereIn('status', ['active','in_progress'])
            ->whereDate('route_date', now()->toDateString())
            ->pluck('worker_user_id')->map(static fn($id): int => (int) $id)->unique()->values()->all();
        if ($activeWorkers === []) return [];

        $q = $this->db->table('titan_field_worker_location_pings')
            ->where('company_id', $tenant)
            ->whereIn('worker_user_id', $activeWorkers)
            ->where('retention_expires_at', '>', now())
            ->where('captured_at', '>=', now()->subMinutes((int) config('titan-field.offline.fallback_live_position_max_age_minutes', 30)));
        $rows = $q->orderByDesc('captured_at')->get();
        $seen = []; $out = [];
        foreach ($rows as $row) {
            $id = (int) $row->worker_user_id;
            if (isset($seen[$id]) || ! isset($consentByWorker[$id])) continue;
            if (Carbon::parse((string) $row->captured_at)->lt(Carbon::parse($consentByWorker[$id]))) continue;
            $seen[$id] = true;
            $out[] = [
                'worker_user_id'=>$id,'worker_public_id'=>(string)$id,'latitude'=>(float)$row->latitude,'longitude'=>(float)$row->longitude,
                'captured_at'=>(string)$row->captured_at,'precision'=>'gps:'.(float)$row->accuracy_meters.'m','source'=>'field-fallback',
                'tracking_allowed'=>true,'on_duty'=>true,
            ];
        }
        return $out;
    }

    public function estimateTravel(int $userId, array $origin, array $destination, array $context = []): array
    {
        $e=$this->travel->estimate(isset($origin['latitude'])?(float)$origin['latitude']:null,isset($origin['longitude'])?(float)$origin['longitude']:null,isset($destination['latitude'])?(float)$destination['latitude']:null,isset($destination['longitude'])?(float)$destination['longitude']:null);
        return ['provider'=>'field-fallback','basis'=>'straight_line_estimate','road_distance_meters'=>null,'straight_line_distance_meters'=>$e['distance_meters'],'duration_seconds'=>$e['duration_seconds'],'traffic_delay_seconds'=>null,'eta_basis'=>'estimated','freshness'=>'estimate','encoded_polyline'=>null]+$e;
    }

    public function recordWorkerLocation(int $userId, int $workerUserId, array $payload): array
    {
        $lat=(float)($payload['latitude']??999);$lng=(float)($payload['longitude']??999);$accuracy=(float)($payload['accuracy_meters']??-1);
        if($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180)throw new InvalidArgumentException('Invalid coordinates.');
        $tenant=$this->tenantContext->companyId($userId);$route=isset($payload['route_public_id'])?trim((string)$payload['route_public_id']):null;
        $policy=$this->policy->assertCanRecord($tenant,$workerUserId,$route,$accuracy);
        $captured=isset($payload['captured_at'])?Carbon::parse((string)$payload['captured_at']):now();$publicId=(string)Str::ulid();
        $row=['public_id'=>$publicId,'company_id'=>$tenant,'worker_user_id'=>$workerUserId,'route_public_id'=>$route,'appointment_public_id'=>$payload['appointment_public_id']??null,'latitude'=>$lat,'longitude'=>$lng,'accuracy_meters'=>$accuracy,'heading_degrees'=>$payload['heading_degrees']??null,'speed_mps'=>$payload['speed_mps']??null,'source'=>'field-fallback','captured_at'=>$captured,'consent_granted_at'=>$policy['consent_granted_at'],'retention_expires_at'=>$captured->copy()->addDays($policy['retention_days']),'metadata'=>json_encode(['privacy_scope'=>'active_shift_only','spatial_authority'=>'field-fallback']),'created_at'=>now(),'updated_at'=>now()];
        $this->db->table('titan_field_worker_location_pings')->insert($row);return $row+['provider'=>'field-fallback'];
    }

    public function syncOfflineWorkerLocations(int $userId, int $workerUserId, array $samples, array $context = []): array
    {
        if($samples===[]||count($samples)>(int)config('titan-field.offline.maximum_batch_size',100))throw new InvalidArgumentException('Offline location batch is empty or exceeds the configured limit.');
        $tenant=$this->tenantContext->companyId($userId);$profile=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('worker_user_id',$workerUserId)->where('active',true)->first();if(!$profile)throw new InvalidArgumentException('Worker is not an active Titan Field worker.');
        $meta=json_decode((string)($profile->metadata??''),true);$meta=is_array($meta)?$meta:[];$consent=(bool)($meta['location_tracking_consent']??false);$consentAt=trim((string)($meta['location_tracking_consent_granted_at']??''));if(!$consent||$consentAt==='')throw new InvalidArgumentException('Worker location consent is required before offline location replay.');
        $deviceId=trim((string)($context['device_id']??''));if($deviceId==='')throw new InvalidArgumentException('Offline location replay requires device_id.');$deviceHash=hash('sha256',$tenant.'|'.$workerUserId.'|'.$deviceId);$retention=max(1,min(30,(int)config('titan-field.field_services.location.retention_days',7)));$receipts=[];$summary=['stored'=>0,'deduplicated'=>0,'historical_only'=>0,'live_eligible'=>0,'rejected'=>0];
        usort($samples,static fn($a,$b)=>strcmp((string)($a['captured_at']??''),(string)($b['captured_at']??'')));
        foreach($samples as $sample){try{$id=trim((string)($sample['client_sample_id']??''));if($id==='')throw new InvalidArgumentException('client_sample_id is required.');$captured=Carbon::parse((string)($sample['captured_at']??''));if($captured->isFuture()&&$captured->diffInSeconds(now())>(int)config('titan-field.offline.maximum_future_skew_seconds',300))throw new InvalidArgumentException('Offline location sample is too far in the future.');if($captured->lt(now()->subDays($retention)))throw new InvalidArgumentException('Offline location sample is outside retention.');if($captured->lt(Carbon::parse($consentAt)))throw new InvalidArgumentException('Offline location sample predates worker consent.');$accuracy=(float)($sample['accuracy_metres']??-1);if($accuracy<0||$accuracy>5000)throw new InvalidArgumentException('Offline location accuracy is outside the accepted operational range.');
            $existing=$this->db->table('titan_field_worker_location_pings')->where('company_id',$tenant)->where('worker_user_id',$workerUserId)->where('client_sample_id',$id)->first();if($existing){$storedMeta=json_decode((string)($existing->metadata??''),true);$storedMeta=is_array($storedMeta)?$storedMeta:[];$historical=(bool)($storedMeta['historical_only']??true);$summary['deduplicated']++;if($historical)$summary['historical_only']++;else$summary['live_eligible']++;$receipts[]=['client_sample_id'=>$id,'stored'=>false,'deduplicated'=>true,'historical_only'=>$historical,'live_eligible'=>!$historical,'status'=>$historical?'deduplicated_historical':'deduplicated_live_fallback','public_id'=>$existing->public_id];continue;}
            $route=$this->db->table('titan_field_routes')->where('company_id',$tenant)->where('worker_user_id',$workerUserId)->whereDate('route_date',$captured->toDateString())->whereIn('status',['active','in_progress','completed'])->first();if(!$route)throw new InvalidArgumentException('Offline GPS sample is not associated with a recorded worker shift route.');$fresh=$captured->gte(now()->subMinutes((int)config('titan-field.offline.fallback_live_position_max_age_minutes',30)))&&in_array((string)$route->status,['active','in_progress'],true);
            $row=['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'worker_user_id'=>$workerUserId,'route_public_id'=>$sample['route_public_id']??$route->public_id,'appointment_public_id'=>$sample['appointment_public_id']??null,'latitude'=>(float)($sample['latitude']??999),'longitude'=>(float)($sample['longitude']??999),'accuracy_meters'=>$accuracy,'heading_degrees'=>$sample['heading_degrees']??null,'speed_mps'=>$sample['speed_mps']??null,'source'=>'titan-go-offline-fallback','captured_at'=>$captured,'consent_granted_at'=>$consentAt,'retention_expires_at'=>$captured->copy()->addDays($retention),'client_sample_id'=>$id,'device_hash'=>$deviceHash,'offline_sync'=>true,'metadata'=>json_encode(['historical_only'=>!$fresh,'offline_sync'=>true]),'created_at'=>now(),'updated_at'=>now()];if($row['latitude'] < -90 || $row['latitude'] > 90 || $row['longitude'] < -180 || $row['longitude'] > 180)throw new InvalidArgumentException('Invalid coordinates.');$this->db->table('titan_field_worker_location_pings')->insert($row);$summary['stored']++;if($fresh)$summary['live_eligible']++;else$summary['historical_only']++;$receipts[]=['client_sample_id'=>$id,'stored'=>true,'deduplicated'=>false,'historical_only'=>!$fresh,'live_eligible'=>$fresh,'status'=>$fresh?'stored_live_fallback':'stale_historical','public_id'=>$row['public_id'],'captured_at'=>$captured->toAtomString(),'retention_expires_at'=>$row['retention_expires_at']->toAtomString()];
        }catch(\Throwable $e){$summary['rejected']++;$receipts[]=['client_sample_id'=>(string)($sample['client_sample_id']??''),'stored'=>false,'status'=>'rejected','historical_only'=>false,'live_eligible'=>false,'error'=>$e->getMessage()];}}
        return ['schema'=>'titan.field.worker-location.offline-sync.v1','provider'=>'field-fallback','summary'=>$summary,'receipts'=>$receipts];
    }

    public function workOrderCostEvidence(int $userId, string $workOrderPublicId, array $context = []): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $stop=$this->db->table('titan_field_route_stops')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->orderByDesc('id')->first();
        $route=$stop?$this->db->table('titan_field_routes')->where('company_id',$tenant)->where('public_id',$stop->route_public_id)->first():null;
        return [
            'provider'=>'field-fallback','basis'=>$stop?'field_route_stop_evidence':'no_spatial_evidence','authoritative'=>false,'financial_authority'=>false,
            'work_order_public_id'=>$workOrderPublicId,'road_distance_meters'=>null,
            'straight_line_distance_meters'=>$stop&&$stop->distance_meters_from_previous!==null?(int)$stop->distance_meters_from_previous:null,
            'duration_seconds'=>$stop&&$stop->travel_seconds_from_previous!==null?(int)$stop->travel_seconds_from_previous:null,
            'route_public_id'=>$route?->public_id,'route_total_distance_meters'=>$route?->total_distance_meters!==null?(int)$route->total_distance_meters:null,
            'route_total_duration_seconds'=>$route?->total_duration_seconds!==null?(int)$route->total_duration_seconds:null,
            'pricing_signals'=>[],'freshness'=>'retained_field_evidence',
        ];
    }

    public function capacityPressureEvidence(int $userId, array $context = []): array
    {
        $workers=$this->latestWorkerPositions($userId,(array)($context['worker_user_ids']??[]));$points=array_slice(array_values((array)($context['demand_points']??[])),0,20);$durations=[];$distances=[];$uncovered=0;$details=[];$evaluated=0;
        foreach($points as $point){if(!is_array($point)||!isset($point['latitude'],$point['longitude'])||!is_numeric($point['latitude'])||!is_numeric($point['longitude']))continue;$evaluated++;$best=null;foreach($workers as $worker){$estimate=$this->travel->estimate((float)$point['latitude'],(float)$point['longitude'],isset($worker['latitude'])?(float)$worker['latitude']:null,isset($worker['longitude'])?(float)$worker['longitude']:null);if(($estimate['distance_meters']??null)===null)continue;if($best===null||(int)$estimate['distance_meters']<(int)$best['distance_meters'])$best=$estimate+['worker_public_id'=>$worker['worker_public_id']??(string)($worker['worker_user_id']??'')];}if($best===null){$uncovered++;$details[]=['public_reference_id'=>$point['public_reference_id']??null,'basis'=>'no_recent_field_fallback_position','freshness'=>'none','nearest_worker_duration_seconds'=>null,'nearest_worker_distance_meters'=>null,'territory'=>'unknown'];continue;}$duration=isset($best['duration_seconds'])?(int)$best['duration_seconds']:null;$distance=isset($best['distance_meters'])?(int)$best['distance_meters']:null;if($duration!==null)$durations[]=$duration;if($distance!==null)$distances[]=$distance;$details[]=['public_reference_id'=>$point['public_reference_id']??null,'basis'=>'straight_line_estimate','freshness'=>'estimate','nearest_worker_public_id'=>$best['worker_public_id'],'nearest_worker_duration_seconds'=>$duration,'nearest_worker_distance_meters'=>$distance,'territory'=>'unknown'];}
        return ['provider'=>'field-fallback','basis'=>'nearest_recent_worker_straight_line_estimate','authoritative'=>false,'operational_authority'=>false,'financial_authority'=>false,'demand_points_received'=>count($points),'demand_points_evaluated'=>$evaluated,'uncovered_demand_count'=>$uncovered,'nearest_worker_duration_seconds'=>$durations===[]?null:(int)round(array_sum($durations)/count($durations)),'nearest_worker_distance_meters'=>$distances===[]?null:(int)round(array_sum($distances)/count($distances)),'capacity_adjustment_seconds'=>$durations===[]?null:array_sum($durations),'capacity_adjustment_basis'=>'sum_of_nearest_worker_one_way_travel_proxy_not_route_commitment','freshness'=>['fresh'=>0,'stale'=>0,'estimate'=>count($durations),'none'=>$uncovered],'territory'=>['covered'=>0,'uncovered'=>0,'unknown'=>$evaluated],'details'=>$details,'mutation'=>'none'];
    }


    public function routeOptimizationProposal(int $userId, string $routePublicId, array $route, array $stops, array $context = []): array
    {
        return ['schema'=>'titan.field.route-optimisation-proposal.unavailable.v1','available'=>false,'provider'=>'field-fallback','reason'=>'titan_maps_intelligence_required','read_only'=>true,'no_field_write'=>true,'route_public_id'=>$routePublicId];
    }

    public function mapPayload(int $userId, string $page = 'field.team'): array
    {
        $markers=array_map(static fn(array $p):array=>['id'=>'worker:'.$p['worker_user_id'],'lat'=>$p['latitude'],'lng'=>$p['longitude'],'type'=>'worker','label'=>'Worker '.$p['worker_user_id'],'subtitle'=>'Fallback position · '.$p['captured_at'],'status'=>'fallback'], $this->latestWorkerPositions($userId));
        return ['markers'=>$markers,'polylines'=>[],'polygons'=>[],'circles'=>[],'fit'=>true,'empty_message'=>'Titan Maps Intelligence is unavailable; showing retained Titan Field fallback positions.'];
    }
    public function mapUi(int $userId): array { return ['enabled'=>false,'provider'=>'field-fallback']; }
}
