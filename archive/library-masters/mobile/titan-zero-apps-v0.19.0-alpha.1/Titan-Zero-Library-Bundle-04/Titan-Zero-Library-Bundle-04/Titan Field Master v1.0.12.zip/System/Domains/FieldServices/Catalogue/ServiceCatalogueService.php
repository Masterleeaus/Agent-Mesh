<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Catalogue;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ServiceCatalogueService
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db,private FieldReferenceIntegrity $integrity) {}

    public function list(int $userId, bool $activeOnly = true): array
    {
        $q = $this->db->table('crm_services')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at');
        if ($activeOnly) $q->where('active',true);
        return $q->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();
    }

    public function find(int $userId,string $publicId): ?array
    {
        $row=$this->db->table('crm_services')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        return $row ? (array)$row : null;
    }

    public function createCategory(int $userId,array $data): array
    {
        $key=trim((string)($data['key']??'')); $name=trim((string)($data['name']??''));
        if ($key==='' || $name==='') throw new InvalidArgumentException('Service category key and name are required.');
        $publicId=(string)Str::ulid();
        $this->db->table('crm_service_categories')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'key'=>$key,'name'=>$name,'description'=>$data['description']??null,'sort_order'=>(int)($data['sort_order']??0),'active'=>(bool)($data['active']??true),'metadata'=>$this->json($data['metadata']??null),'created_at'=>now(),'updated_at'=>now()]);
        return (array)$this->db->table('crm_service_categories')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }

    public function createService(int $userId,array $data): array
    {
        $key=trim((string)($data['key']??'')); $name=trim((string)($data['name']??''));
        if ($key==='' || $name==='') throw new InvalidArgumentException('Service key and name are required.');
        $this->integrity->assertContext($userId,$data,['category_public_id']);
        $this->integrity->assertReferenceList($userId,'form_public_id',$data['form_template_public_ids']??$data['form_checklist_references']??[]);
        $publicId=(string)Str::ulid();
        $this->db->table('crm_services')->insert([
            'public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'category_public_id'=>$data['category_public_id']??null,'key'=>$key,'name'=>$name,
            'description'=>$data['description']??null,'customer_faq'=>$data['customer_faq']??null,'default_duration_minutes'=>$data['default_duration_minutes']??null,
            'pricing_model'=>$data['pricing_model']??'fixed','price_minor'=>$data['price_minor']??null,'currency'=>$data['currency']??'AUD','quote_required'=>(bool)($data['quote_required']??false),
            'emergency_capable'=>(bool)($data['emergency_capable']??$data['emergency_flag']??false),'regulated_work'=>(bool)($data['regulated_work']??false),'active'=>(bool)($data['active']??true),
            'tax_behavior'=>$data['tax_behavior']??'default','booking_available'=>(bool)($data['booking_available']??true),'required_skills'=>$this->json($data['required_skills']??$data['required_skill']??null),
            'field_requirements'=>$this->json($data['field_requirements']??null),'evidence_requirements'=>$this->json($data['evidence_requirements']??null),'form_template_public_ids'=>$this->json($data['form_template_public_ids']??$data['form_checklist_references']??null),
            'recurring_eligible'=>(bool)($data['recurring_eligible']??false),'intake_schema'=>$this->json($data['intake_schema']??null),'default_tasks'=>$this->json($data['default_tasks']??null),'metadata'=>$this->json($data['metadata']??null),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return (array)$this->db->table('crm_services')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }

    public function updateService(int $userId,string $publicId,array $data): array
    {
        $q=$this->db->table('crm_services')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at');
        $current=$q->first(); if(!$current) throw new InvalidArgumentException('Service not found.');
        $this->integrity->assertContext($userId,$data,['category_public_id']);
        if(array_key_exists('form_template_public_ids',$data)||array_key_exists('form_checklist_references',$data))$this->integrity->assertReferenceList($userId,'form_public_id',$data['form_template_public_ids']??$data['form_checklist_references']??[]);
        $allowed=['category_public_id','key','name','description','customer_faq','default_duration_minutes','pricing_model','price_minor','currency','quote_required','emergency_capable','regulated_work','active','tax_behavior','booking_available','recurring_eligible'];
        $updates=array_intersect_key($data,array_flip($allowed));
        foreach(['intake_schema','default_tasks','metadata','required_skills','field_requirements','evidence_requirements','form_template_public_ids'] as $field) if(array_key_exists($field,$data))$updates[$field]=$this->json($data[$field]);
        if(isset($data['required_skill'])&&!array_key_exists('required_skills',$data))$updates['required_skills']=$this->json($data['required_skill']);
        if(isset($data['emergency_flag'])&&!array_key_exists('emergency_capable',$data))$updates['emergency_capable']=(bool)$data['emergency_flag'];
        if(isset($data['form_checklist_references'])&&!array_key_exists('form_template_public_ids',$data))$updates['form_template_public_ids']=$this->json($data['form_checklist_references']);
        $updates['updated_at']=now();$q->update($updates);return (array)$q->first();
    }

    public function variants(int $userId,string $servicePublicId): array
    { return $this->db->table('crm_service_variants')->where('company_id',$this->tenantContext->companyId($userId))->where('service_public_id',$servicePublicId)->whereNull('deleted_at')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }

    public function createVariant(int $userId,string $servicePublicId,array $data): array
    {
        $this->integrity->assertContext($userId,['service_public_id'=>$servicePublicId]);
        $key=trim((string)($data['key']??''));$name=trim((string)($data['name']??''));if($key===''||$name==='')throw new InvalidArgumentException('Service variant key and name are required.');
        $id=(string)Str::ulid();$this->db->table('crm_service_variants')->insert(['public_id'=>$id,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),'service_public_id'=>$servicePublicId,'key'=>$key,'name'=>$name,'duration_minutes'=>$data['duration_minutes']??null,'price_minor'=>$data['price_minor']??null,'active'=>(bool)($data['active']??true),'metadata'=>$this->json($data['metadata']??null),'created_at'=>now(),'updated_at'=>now()]);
        return (array)$this->db->table('crm_service_variants')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$id)->first();
    }

    private function json(mixed $value): ?string { return $value===null ? null : json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); }
}
