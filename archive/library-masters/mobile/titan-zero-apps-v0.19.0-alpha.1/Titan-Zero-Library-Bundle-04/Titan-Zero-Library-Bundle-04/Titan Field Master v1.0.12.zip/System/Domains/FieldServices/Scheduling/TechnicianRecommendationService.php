<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/** Non-authoritative, explainable ranking over workers that pass SchedulingKernel hard constraints. */
final class TechnicianRecommendationService
{
    public const POLICY_VERSION='titan.field.recommendation.v3';

    public function __construct(
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private SchedulingKernel $kernel,
        private TravelEstimator $travel,
        private RecommendationEvidenceStore $evidenceStore,
    ) {}

    /** @return array{recommendation_id:string,recommendation_hash:string,context_hash:string,policy_version:string,data:list<array<string,mixed>>} */
    public function recommend(int $userId,mixed $start,mixed $end,array $context=[]): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $profiles=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('active',true)->orderBy('worker_user_id')->get();
        $target=$this->targetLocation($tenant,$context);
        $rows=[];
        foreach($profiles as $profile){
            $worker=(int)$profile->worker_user_id;
            try{
                $hard=$this->kernel->assertSchedulable($userId,$worker,$start,$end,$context);
                [$score,$reasons,$components,$facts]=$this->scoreEligible($tenant,$worker,$profile,$hard,$target,$start,$end,$context);
                $rows[]=['worker_user_id'=>$worker,'eligible'=>true,'score'=>$score,'reasons'=>$reasons,'components'=>$components,'source_facts'=>$facts,'hard_constraints'=>$hard];
            }catch(InvalidArgumentException $e){
                $rows[]=['worker_user_id'=>$worker,'eligible'=>false,'score'=>0,'reasons'=>[$e->getMessage()],'components'=>[],'source_facts'=>[],'hard_constraints'=>null];
            }
        }
        usort($rows,static fn(array $a,array $b):int=>($b['eligible']<=>$a['eligible'])?:($b['score']<=>$a['score'])?:($a['worker_user_id']<=>$b['worker_user_id']));
        $trace=is_string($context['_trace_id']??null)?$context['_trace_id']:null;
        $correlation=is_string($context['_correlation_id']??null)?$context['_correlation_id']:null;
        unset($context['_trace_id'],$context['_correlation_id']);
        $evidence=$this->evidenceStore->record($tenant,$userId,$start,$end,$context,$rows,self::POLICY_VERSION,$trace,$correlation);
        return $evidence+['data'=>$rows];
    }

    /** @return array{0:int,1:list<string>,2:array<string,mixed>,3:array<string,mixed>} */
    private function scoreEligible(int $tenant,int $worker,object $profile,array $hard,?object $target,mixed $start,mixed $end,array $context): array
    {
        $reasons=['Passed all hard scheduling constraints.'];$components=[];$facts=[];$score=15;
        $components['hard_constraints']=['score'=>15,'max'=>15];

        $required=(array)($hard['required_skills']??[]);$skillScore=$required===[]?10:20;$score+=$skillScore;
        $components['skills']=['score'=>$skillScore,'max'=>20,'required'=>$required];
        $reasons[]=$required===[]?'No mandatory skills specified.':'All required skills match.';

        $rolling=$this->rollingWorkload($tenant,$worker,$start,$end,$hard);$score+=$rolling['score'];
        $components['rolling_workload']=$rolling;$components['capacity']=$rolling;$facts['rolling_workload']=$rolling['facts'];
        $reasons[]=$rolling['reason'];

        $territory=$this->territoryFit($profile,$hard,$target,$context);$score+=$territory['score'];
        $components['territory']=$territory;$facts['territory']=$territory['facts'];
        $reasons[]=$territory['reason'];

        $route=$this->routeFit($tenant,$worker,$target,$start,$end);$score+=$route['score'];
        $components['route_fit']=$route;$components['travel']=$route;$facts['route_fit']=$route['facts'];
        $reasons[]=$route['reason'];

        $continuity=$this->continuityEvidence($tenant,$worker,$context);$score+=$continuity['score'];
        $components['continuity']=$continuity;$facts['continuity']=$continuity['facts'];
        if($continuity['reason']!=='')$reasons[]=$continuity['reason'];

        return [max(0,min(100,$score)),$reasons,$components,$facts];
    }

    /** @return array{score:int,max:int,reason:string,facts:array<string,mixed>} */
    private function rollingWorkload(int $tenant,int $worker,mixed $start,mixed $end,array $hard): array
    {
        $from=CarbonImmutable::parse($start)->utc();$windowStart=$from->subDays(3)->startOfDay();$windowEnd=$from->addDays(3)->endOfDay();
        $rows=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')->whereNotIn('status',['cancelled'])->where('scheduled_start','<',$windowEnd)->where('scheduled_end','>',$windowStart)->get(['scheduled_start','scheduled_end']);
        $sevenDayMinutes=0;foreach($rows as $row){$sevenDayMinutes+=CarbonImmutable::parse($row->scheduled_start)->diffInMinutes(CarbonImmutable::parse($row->scheduled_end));}
        $daily=max(0,(int)($hard['daily_load_minutes']??0));$max=max(1,(int)($hard['max_daily_minutes']??720));$dailyRatio=min(1,$daily/$max);
        $rollingTarget=$max*5;$rollingRatio=min(1,$sevenDayMinutes/max(1,$rollingTarget));
        $pressure=($dailyRatio*0.65)+($rollingRatio*0.35);$score=(int)round(20*(1-$pressure));
        return ['score'=>max(0,min(20,$score)),'max'=>20,'reason'=>sprintf('Workload balance: %d daily minutes; %d minutes across the 7-day window.',$daily,$sevenDayMinutes),'facts'=>['daily_load_minutes'=>$daily,'max_daily_minutes'=>$max,'seven_day_scheduled_minutes'=>$sevenDayMinutes,'window_days'=>7]];
    }

    /** @return array{score:int,max:int,reason:string,facts:array<string,mixed>} */
    private function territoryFit(object $profile,array $hard,?object $target,array $context): array
    {
        $meta=$this->decodeAssoc($profile->metadata??null);$areaPrefs=$this->stringList($meta['service_area_public_ids']??[]);$postcodePrefs=array_unique(array_merge($this->stringList($meta['preferred_postcodes']??[]),$this->stringList($meta['territory_postcodes']??[])));
        $targetPostcode=(string)($target->postcode??$context['postcode']??'');$areaMatches=array_map('strval',(array)($hard['service_area_matches']??[]));
        $hasPrefs=$areaPrefs!==[]||$postcodePrefs!==[];$matched=(!$hasPrefs)||array_intersect($areaPrefs,$areaMatches)!==[]||($targetPostcode!==''&&in_array($targetPostcode,$postcodePrefs,true));
        $score=$hasPrefs?($matched?15:5):10;
        return ['score'=>$score,'max'=>15,'reason'=>$hasPrefs?($matched?'Worker territory preferences match this job.':'Worker is eligible but outside preferred territory.'):'No worker-specific territory preference configured.','facts'=>['service_area_public_ids'=>$areaPrefs,'preferred_postcodes'=>$this->stringList($meta['preferred_postcodes']??[]),'territory_postcodes'=>$this->stringList($meta['territory_postcodes']??[]),'target_postcode'=>$targetPostcode,'matched_service_areas'=>$areaMatches,'preference_match'=>$matched]];
    }

    /** @return array{score:int,max:int,reason:string,facts:array<string,mixed>} */
    private function routeFit(int $tenant,int $worker,?object $target,mixed $start,mixed $end): array
    {
        if(!$target||$target->latitude===null||$target->longitude===null)return ['score'=>7,'max'=>15,'reason'=>'Route adjacency unavailable; neutral route-fit score used.','facts'=>['previous'=>null,'next'=>null]];
        $from=CarbonImmutable::parse($start)->utc();$to=CarbonImmutable::parse($end)->utc();
        $previous=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')->whereNotNull('location_public_id')->where('scheduled_end','<=',$from)->orderByDesc('scheduled_end')->first();
        $next=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')->whereNotNull('location_public_id')->where('scheduled_start','>=',$to)->orderBy('scheduled_start')->first();
        $prevEstimate=$this->adjacentEstimate($tenant,$previous,$target);$nextEstimate=$this->adjacentEstimate($tenant,$next,$target);
        $distances=array_values(array_filter([$prevEstimate['distance_meters']??null,$nextEstimate['distance_meters']??null],static fn($v)=>$v!==null));
        if($distances===[])return ['score'=>7,'max'=>15,'reason'=>'No adjacent geocoded jobs; neutral route-fit score used.','facts'=>['previous'=>$prevEstimate,'next'=>$nextEstimate]];
        $avgKm=(array_sum($distances)/count($distances))/1000;$score=$avgKm<=5?15:($avgKm<=15?12:($avgKm<=30?8:3));
        return ['score'=>$score,'max'=>15,'reason'=>sprintf('Route adjacency averages %.1f km from surrounding jobs.',$avgKm),'facts'=>['previous'=>$prevEstimate,'next'=>$nextEstimate,'average_distance_km'=>round($avgKm,2)]];
    }

    /** @return array{score:int,max:int,reason:string,facts:array<string,mixed>} */
    private function continuityEvidence(int $tenant,int $worker,array $context): array
    {
        $q=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at');$has=false;
        foreach(['company_public_id','location_public_id'] as $field){if(!empty($context[$field])){$q->where($field,(string)$context[$field]);$has=true;}}
        if(!$has)return ['score'=>0,'max'=>15,'reason'=>'','facts'=>['prior_jobs'=>0,'last_completed_at'=>null]];
        $prior=(clone $q)->count();$last=(clone $q)->orderByDesc('completed_at')->value('completed_at');$score=$prior>=3?15:($prior>=1?10:0);
        return ['score'=>$score,'max'=>15,'reason'=>$prior>0?"Worker has {$prior} prior matching customer/location job(s).":'No prior customer/location continuity.','facts'=>['prior_jobs'=>$prior,'last_completed_at'=>$last]];
    }

    private function adjacentEstimate(int $tenant,?object $appointment,object $target): array
    {
        if(!$appointment)return ['appointment_public_id'=>null,'location_public_id'=>null,'distance_meters'=>null,'duration_seconds'=>null];
        $location=$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$appointment->location_public_id)->whereNull('deleted_at')->first();
        if(!$location)return ['appointment_public_id'=>$appointment->public_id??null,'location_public_id'=>$appointment->location_public_id??null,'distance_meters'=>null,'duration_seconds'=>null];
        $estimate=$this->travel->estimate($location->latitude!==null?(float)$location->latitude:null,$location->longitude!==null?(float)$location->longitude:null,(float)$target->latitude,(float)$target->longitude);
        return ['appointment_public_id'=>$appointment->public_id??null,'location_public_id'=>$appointment->location_public_id??null]+$estimate;
    }

    private function targetLocation(int $tenant,array $context): ?object
    {
        if(empty($context['location_public_id']))return null;
        return $this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',(string)$context['location_public_id'])->whereNull('deleted_at')->first();
    }

    /** @return list<string> */
    private function stringList(mixed $value): array
    {
        if(is_string($value)){$d=json_decode($value,true);if(is_array($d))$value=$d;else$value=preg_split('/\s*,\s*/',trim($value))?:[];}
        if(!is_array($value))return [];
        return array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),$value),static fn($v)=>$v!=='')));
    }

    /** @return array<string,mixed> */
    private function decodeAssoc(mixed $value): array{if(is_array($value))return $value;if(!is_string($value)||trim($value)==='')return [];$v=json_decode($value,true);return is_array($v)?$v:[];}
}
