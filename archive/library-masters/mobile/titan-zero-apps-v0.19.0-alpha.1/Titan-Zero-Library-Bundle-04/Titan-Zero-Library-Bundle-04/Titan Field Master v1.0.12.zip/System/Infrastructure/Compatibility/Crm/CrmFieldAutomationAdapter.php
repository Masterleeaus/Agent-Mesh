<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm;

use App\Extensions\Crm\System\Automation\Events\CrmAutomationTriggered;
use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;

final class CrmFieldAutomationAdapter implements FieldAutomationPort
{
    public function trigger(int $userId, string $eventName, array $payload = []): void
    {
        event(new CrmAutomationTriggered($userId, $eventName, $payload));
    }
}
