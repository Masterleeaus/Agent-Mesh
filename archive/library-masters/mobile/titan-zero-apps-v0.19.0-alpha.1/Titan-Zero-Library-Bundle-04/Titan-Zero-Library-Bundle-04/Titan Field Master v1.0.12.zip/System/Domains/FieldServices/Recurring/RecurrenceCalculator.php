<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Recurring;

use Carbon\CarbonImmutable;
use DateTimeInterface;
use InvalidArgumentException;

/**
 * Deterministic recurrence mathematics for Titan Field.
 *
 * Donor provenance: clean-room adaptation of useful recurrence semantics observed
 * in the supplied FSMRecurring donor. Titan Field remains the sole occurrence writer.
 */
final class RecurrenceCalculator
{
    /** @param array<string,mixed> $rule */
    public function nextAfter(DateTimeInterface|string $after, array $rule): CarbonImmutable
    {
        $afterAt = CarbonImmutable::parse($after);
        $normal = $this->normalize($rule, $afterAt);

        $included = $this->nextIncludedDate($afterAt, $normal);
        $cursor = $afterAt->startOfDay()->addDay();
        $deadline = $cursor->addYears(10);
        while ($cursor->lessThanOrEqualTo($deadline)) {
            if ($this->matches($cursor, $normal)) {
                $candidate = $cursor->setTime($afterAt->hour, $afterAt->minute, $afterAt->second);
                if ($included !== null && $included->lessThan($candidate)) return $included;
                return $candidate;
            }
            $cursor = $cursor->addDay();
        }

        if ($included !== null) return $included;
        throw new InvalidArgumentException('No recurrence occurrence found within the supported 10-year horizon.');
    }

    /** @param array<string,mixed> $rule @return array<int,CarbonImmutable> */
    public function occurrencesBetween(DateTimeInterface|string $from, DateTimeInterface|string $until, array $rule, int $limit = 500): array
    {
        $start = CarbonImmutable::parse($from);
        $end = CarbonImmutable::parse($until);
        if ($end->lessThan($start)) throw new InvalidArgumentException('Recurrence range end must not precede its start.');
        $limit = max(1, min(5000, $limit));
        $normal = $this->normalize($rule, $start);
        $results = [];
        $cursor = $start->startOfDay();
        while ($cursor->lessThanOrEqualTo($end->endOfDay()) && count($results) < $limit) {
            if ($this->matches($cursor, $normal)) {
                $results[] = $cursor->setTime($start->hour, $start->minute, $start->second);
            }
            $cursor = $cursor->addDay();
        }
        foreach ((array)$normal['include_dates'] as $date) {
            $candidate = CarbonImmutable::parse($date)->setTime($start->hour, $start->minute, $start->second);
            if ($candidate->betweenIncluded($start, $end) && !$this->isExcluded($candidate, $normal)) $results[] = $candidate;
        }
        usort($results, static fn(CarbonImmutable $a, CarbonImmutable $b): int => $a->getTimestamp() <=> $b->getTimestamp());
        $unique = [];
        foreach ($results as $result) $unique[$result->toIso8601String()] = $result;
        return array_slice(array_values($unique), 0, $limit);
    }

    /** @param array<string,mixed> $rule @return array<string,mixed> */
    public function normalize(array $rule, ?CarbonImmutable $fallbackAnchor = null): array
    {
        $frequency = strtolower((string)($rule['frequency'] ?? $rule['cadence'] ?? 'monthly'));
        $frequency = match ($frequency) {
            'fortnightly' => 'weekly', 'quarterly' => 'monthly', 'annual' => 'yearly', default => $frequency,
        };
        if (!in_array($frequency, ['daily','weekly','monthly','yearly'], true)) throw new InvalidArgumentException('Unsupported recurrence frequency.');
        $interval = max(1, (int)($rule['interval'] ?? $rule['interval_count'] ?? 1));
        if (($rule['cadence'] ?? null) === 'fortnightly') $interval *= 2;
        if (($rule['cadence'] ?? null) === 'quarterly') $interval *= 3;
        $anchor = CarbonImmutable::parse($rule['anchor_date'] ?? $rule['starts_on'] ?? $fallbackAnchor ?? now())->startOfDay();
        $weekdays = array_values(array_unique(array_filter(array_map([$this,'weekdayNumber'], (array)($rule['weekdays'] ?? [])))));
        $dayOfMonth = isset($rule['day_of_month']) ? max(1, min(31, (int)$rule['day_of_month'])) : null;
        $nth = is_array($rule['nth_weekday'] ?? null) ? $rule['nth_weekday'] : null;
        if ($nth !== null) {
            $nth['nth'] = max(-1, min(5, (int)($nth['nth'] ?? 1)));
            if ($nth['nth'] === 0) $nth['nth'] = 1;
            $nth['weekday'] = $this->weekdayNumber($nth['weekday'] ?? null);
            if (!$nth['weekday']) $nth = null;
        }
        return [
            'frequency'=>$frequency,'interval'=>$interval,'anchor_date'=>$anchor->toDateString(),
            'weekdays'=>$weekdays,'day_of_month'=>$dayOfMonth,'nth_weekday'=>$nth,
            'include_dates'=>$this->dateList((array)($rule['include_dates'] ?? [])),
            'exclude_dates'=>$this->dateList((array)($rule['exclude_dates'] ?? [])),
        ];
    }

    /** @param array<string,mixed> $rule */
    private function matches(CarbonImmutable $date, array $rule): bool
    {
        if ($this->isExcluded($date, $rule)) return false;
        if (in_array($date->toDateString(), (array)$rule['include_dates'], true)) return true;
        $anchor = CarbonImmutable::parse((string)$rule['anchor_date']);
        if ($date->lessThan($anchor)) return false;
        $interval = (int)$rule['interval'];
        $frequency = (string)$rule['frequency'];
        $baseMatches = match ($frequency) {
            'daily' => $anchor->diffInDays($date) % $interval === 0,
            'weekly' => intdiv($anchor->diffInDays($date), 7) % $interval === 0,
            'monthly' => $this->monthDiff($anchor, $date) % $interval === 0,
            'yearly' => ($date->year - $anchor->year) % $interval === 0,
            default => false,
        };
        if (!$baseMatches) return false;

        $weekdays = (array)$rule['weekdays'];
        if ($weekdays !== [] && !in_array($date->isoWeekday(), $weekdays, true)) return false;
        if ($rule['nth_weekday'] !== null && !$this->matchesNthWeekday($date, (array)$rule['nth_weekday'])) return false;

        if ($frequency === 'monthly' || $frequency === 'yearly') {
            if ($frequency === 'yearly' && $date->month !== $anchor->month) return false;
            if ($rule['nth_weekday'] === null && $weekdays === []) {
                $desired = (int)($rule['day_of_month'] ?? $anchor->day);
                $desired = min($desired, $date->daysInMonth);
                if ($date->day !== $desired) return false;
            }
        }
        if ($frequency === 'weekly' && $weekdays === [] && $date->isoWeekday() !== $anchor->isoWeekday()) return false;
        return true;
    }

    /** @param array<string,mixed> $rule */
    private function isExcluded(CarbonImmutable $date, array $rule): bool
    {
        return in_array($date->toDateString(), (array)$rule['exclude_dates'], true);
    }

    /** @param array<string,mixed> $rule */
    private function nextIncludedDate(CarbonImmutable $after, array $rule): ?CarbonImmutable
    {
        $best = null;
        foreach ((array)$rule['include_dates'] as $date) {
            $candidate = CarbonImmutable::parse($date)->setTime($after->hour, $after->minute, $after->second);
            if ($candidate->lessThanOrEqualTo($after) || $this->isExcluded($candidate, $rule)) continue;
            if ($best === null || $candidate->lessThan($best)) $best = $candidate;
        }
        return $best;
    }

    /** @param array<string,mixed> $nth */
    private function matchesNthWeekday(CarbonImmutable $date, array $nth): bool
    {
        if ($date->isoWeekday() !== (int)$nth['weekday']) return false;
        $n = (int)$nth['nth'];
        if ($n === -1) return $date->addWeek()->month !== $date->month;
        return intdiv($date->day - 1, 7) + 1 === $n;
    }

    private function monthDiff(CarbonImmutable $a, CarbonImmutable $b): int
    {
        return (($b->year - $a->year) * 12) + ($b->month - $a->month);
    }

    private function weekdayNumber(mixed $value): ?int
    {
        if (is_int($value) || ctype_digit((string)$value)) { $n=(int)$value; return $n>=1&&$n<=7?$n:null; }
        return match (strtolower(substr(trim((string)$value),0,3))) {
            'mon'=>1,'tue'=>2,'wed'=>3,'thu'=>4,'fri'=>5,'sat'=>6,'sun'=>7,default=>null,
        };
    }

    /** @return array<int,string> */
    private function dateList(array $values): array
    {
        $dates=[];foreach($values as $value){try{$dates[]=CarbonImmutable::parse($value)->toDateString();}catch(\Throwable){}}
        return array_values(array_unique($dates));
    }
}
