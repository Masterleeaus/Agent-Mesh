<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices;

use RuntimeException;

final class FieldServiceCapabilityRegistry
{
    /** @var array<string,array<string,mixed>>|null */
    private ?array $definitions = null;

    public function enabled(string $capability): bool
    {
        $definition = $this->definition($capability);
        if ($definition === null) return false;
        $runtimeKey = (string) ($definition['runtime_key'] ?? '');
        return $runtimeKey !== '' && (bool) config('titan-field.field_services.capabilities.' . $runtimeKey, true);
    }

    public function canonicalName(string $capability): ?string
    {
        $definition = $this->definition($capability);
        return $definition === null ? null : (string) $definition['id'];
    }

    public function permission(string $capability): ?string
    {
        $definition = $this->definition($capability);
        if ($definition === null) return null;
        $permission = trim((string) ($definition['permission'] ?? ''));
        return $permission === '' ? null : $permission;
    }

    /** @return array<string,mixed>|null */
    public function definition(string $capability): ?array
    {
        $definitions = $this->allDefinitions();
        if (isset($definitions[$capability])) return $definitions[$capability];
        foreach ($definitions as $definition) {
            if (in_array($capability, (array) ($definition['legacy_aliases'] ?? []), true)) return $definition;
            if ($capability === (string) ($definition['runtime_key'] ?? '')) return $definition;
        }
        return null;
    }

    /** @return array<string,array<string,mixed>> keyed by canonical capability */
    public function allDefinitions(): array
    {
        if ($this->definitions !== null) return $this->definitions;
        $path = dirname(__DIR__, 3) . '/CAPABILITIES.json';
        $decoded = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
        if (! is_array($decoded) || ! is_array($decoded['definitions'] ?? null)) {
            throw new RuntimeException('Titan Field governed CAPABILITIES.json is missing or invalid.');
        }
        $out = [];
        foreach ($decoded['definitions'] as $definition) {
            if (! is_array($definition) || ! is_string($definition['id'] ?? null)) continue;
            $out[$definition['id']] = $definition;
        }
        return $this->definitions = $out;
    }

    /** @return array<string,bool> canonical capability => enabled */
    public function all(): array
    {
        $out = [];
        foreach ($this->allDefinitions() as $canonical => $_) $out[$canonical] = $this->enabled($canonical);
        return $out;
    }
}
