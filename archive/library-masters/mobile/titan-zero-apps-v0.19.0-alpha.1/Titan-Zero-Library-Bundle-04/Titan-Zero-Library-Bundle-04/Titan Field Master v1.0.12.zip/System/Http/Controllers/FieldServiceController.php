<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Controllers;

use App\Extensions\TitanField\System\Contracts\FieldCommandGateway;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;

use App\Extensions\TitanField\System\Domains\FieldServices\Assets\CustomerAssetService;
use App\Extensions\TitanField\System\Domains\FieldServices\Catalogue\ServiceCatalogueService;
use App\Extensions\TitanField\System\Domains\FieldServices\Dispatch\DispatchService;
use App\Extensions\TitanField\System\Domains\FieldServices\Evidence\FieldEvidenceService;
use App\Extensions\TitanField\System\Domains\FieldServices\Exceptions\OperationalExceptionService;
use App\Extensions\TitanField\System\Domains\FieldServices\Forms\FormService;
use App\Extensions\TitanField\System\Domains\FieldServices\Locations\ServiceLocationService;
use App\Extensions\TitanField\System\Domains\FieldServices\Recurring\RecurringServiceEngine;
use App\Extensions\TitanField\System\Domains\FieldServices\Requests\ServiceRequestService;
use App\Extensions\TitanField\System\Domains\FieldServices\Reviews\ReviewRecoveryService;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\AppointmentService;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\CalendarDispatchControlService;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\TechnicianRecommendationService;
use App\Extensions\TitanField\System\Domains\FieldServices\Forecasting\CapacityForecastService;
use App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteService;
use App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteOptimizationProposalService;
use App\Extensions\TitanField\System\Domains\FieldServices\ServiceAreas\ServiceAreaMatcher;
use App\Extensions\TitanField\System\Domains\FieldServices\Support\SupportService;
use App\Extensions\TitanField\System\Domains\FieldServices\Verticals\FieldServiceVerticalInstaller;
use App\Extensions\TitanField\System\Domains\FieldServices\Verticals\FieldServiceVerticalProfileService;
use App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderService;
use App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderHealthService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;

final class FieldServiceController extends Controller
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private FieldCommandGateway $commands,
        private ConnectionInterface $db,
        private ServiceCatalogueService $catalogue,
        private ServiceLocationService $locations,
        private ServiceRequestService $requests,
        private CustomerAssetService $assets,
        private WorkOrderService $workOrders,
        private WorkOrderHealthService $workOrderHealth,
        private AppointmentService $appointments,
        private CalendarDispatchControlService $controlSurfaceService,
        private TechnicianRecommendationService $technicianRecommendations,
        private CapacityForecastService $capacityForecasts,
        private DispatchService $dispatch,
        private RecurringServiceEngine $recurring,
        private FormService $forms,
        private SupportService $support,
        private ReviewRecoveryService $reviews,
        private ServiceAreaMatcher $serviceAreas,
        private FieldEvidenceService $evidence,
        private OperationalExceptionService $exceptionsEngine,
        private RouteService $routesEngine,
        private RouteOptimizationProposalService $routeOptimisationProposals,
        private FieldServiceVerticalProfileService $verticalProfiles,
        private FieldServiceVerticalInstaller $verticalInstaller,
    ) {}

    public function dashboard(Request $request)
    {
        $userId=(int)$request->user()->id;
        $counts=[];
        foreach(['service_requests','work_orders','appointments','dispatch_assignments','service_agreements','support_tickets','reviews','service_recovery_cases'] as $table){
            $counts[$table]=(int)$this->db->table('crm_'.$table)->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->count();
        }
        return view('titan-field::field-services.dashboard',['counts'=>$counts]);
    }

    public function verticals(Request $request)
    {
        $userId=(int)$request->user()->id;
        $installed=[];
        foreach($this->verticalInstaller->installed($userId) as $row)$installed[(string)$row['profile_key']]=$row;
        $profiles=[];
        foreach($this->verticalProfiles->keys() as $key)$profiles[]=$this->verticalProfiles->profile($key);
        return view('titan-field::field-services.verticals',['profiles'=>$profiles,'installed'=>$installed]);
    }

    public function applyVertical(Request $request,string $profile)
    {
        $this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.verticals','apply',['profile'=>$profile],$this->commandContext($request));
        return back()->with('status','Field-service profile applied. Existing user pricing was preserved.');
    }

    public function catalogue(Request $request){return view('titan-field::field-services.catalogue',['services'=>$this->catalogue->list((int)$request->user()->id)]);}
    public function storeService(Request $request){$data=$request->validate(['key'=>'required|string|max:120','name'=>'required|string|max:180','description'=>'nullable|string|max:10000','default_duration_minutes'=>'nullable|integer|min:1|max:10080','pricing_model'=>'nullable|string|max:40','price_minor'=>'nullable|integer|min:0','quote_required'=>'nullable|boolean','emergency_capable'=>'nullable|boolean','regulated_work'=>'nullable|boolean']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.catalogue','create_service',['data'=>$data],$this->commandContext($request));return back()->with('status','Service created.');}

    public function locations(Request $request){$userId=(int)$request->user()->id;$records=$this->db->table('crm_service_locations')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderByDesc('id')->limit(200)->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.locations',['locations'=>$records]);}
    public function storeLocation(Request $request){$data=$request->validate(['name'=>'nullable|string|max:180','contact_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','location_type'=>'nullable|string|max:60','address_line_1'=>'required|string|max:255','address_line_2'=>'nullable|string|max:255','suburb'=>'nullable|string|max:120','state'=>'nullable|string|max:80','postcode'=>'nullable|string|max:20','access_instructions'=>'nullable|string|max:10000','parking_instructions'=>'nullable|string|max:10000','pet_notes'=>'nullable|string|max:10000','hazard_notes'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.locations','create_location',['data'=>$data],$this->commandContext($request));return back()->with('status','Service location created.');}

    public function requests(Request $request){return view('titan-field::field-services.requests',['requests'=>$this->requests->search((int)$request->user()->id,$request->only(['status','priority','owner_user_id']),200),'services'=>$this->catalogue->list((int)$request->user()->id)]);}
    public function storeRequest(Request $request){$data=$request->validate(['title'=>'required|string|max:220','description'=>'nullable|string|max:20000','contact_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','service_public_id'=>'nullable|string|size:26','asset_public_id'=>'nullable|string|size:26','priority'=>'nullable|in:low,normal,high,urgent','urgency'=>'nullable|in:low,normal,high,emergency','source'=>'nullable|string|max:60','channel'=>'nullable|string|max:60','preferred_at'=>'nullable|date','owner_user_id'=>'nullable|integer']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.requests','create_request',['data'=>$data],$this->commandContext($request));return back()->with('status','Service request created.');}
    public function requestStatus(Request $request,string $serviceRequest){$data=$request->validate(['status'=>'required|string|max:40','reason'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.requests','transition_request',['public_id'=>$serviceRequest,'status'=>$data['status'],'reason'=>$data['reason']??null],$this->commandContext($request));return back()->with('status','Service request updated.');}

    public function workOrders(Request $request){return view('titan-field::field-services.work-orders',['workOrders'=>$this->workOrders->search((int)$request->user()->id,$request->only(['status','priority','assigned_user_id']),200)]);}
    public function workOrderShow(Request $request,string $workOrder){$userId=(int)$request->user()->id;$detail=$this->workOrders->detail($userId,$workOrder);$detail['health']=$this->workOrderHealth->health($userId,$workOrder);return view('titan-field::field-services.work-order-show',$detail);}
    public function storeWorkOrder(Request $request){$data=$request->validate(['title'=>'required|string|max:220','description'=>'nullable|string|max:20000','service_request_public_id'=>'nullable|string|size:26','contact_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','service_public_id'=>'nullable|string|size:26','asset_public_id'=>'nullable|string|size:26','priority'=>'nullable|in:low,normal,high,urgent','assigned_user_id'=>'nullable|integer']);$receipt=$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','create_work_order',['data'=>$data],$this->commandContext($request));$record=(array)($receipt['result']??[]);return redirect()->route('dashboard.user.crm.field-services.work-orders.show',$record['public_id'])->with('status','Work order created.');}
    public function workOrderFromRequest(Request $request,string $serviceRequest){$receipt=$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','create_from_request',['request_public_id'=>$serviceRequest],$this->commandContext($request));$record=(array)($receipt['result']??[]);return redirect()->route('dashboard.user.crm.field-services.work-orders.show',$record['public_id'])->with('status','Work order created from request.');}
    public function workOrderStatus(Request $request,string $workOrder){$data=$request->validate(['status'=>'required|string|max:40','reason'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','transition_work_order',['public_id'=>$workOrder,'status'=>$data['status'],'reason'=>$data['reason']??null],$this->commandContext($request));return back()->with('status','Work order updated.');}
    public function storeWorkOrderTask(Request $request,string $workOrder){$data=$request->validate(['title'=>'required|string|max:220','instructions'=>'nullable|string|max:10000','required'=>'nullable|boolean','sort_order'=>'nullable|integer|min:0|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','add_task',['work_order_public_id'=>$workOrder,'data'=>$data],$this->commandContext($request));return back()->with('status','Task added.');}
    public function workOrderTaskStatus(Request $request,string $workOrder,string $task){$data=$request->validate(['status'=>'required|in:pending,in_progress,completed,skipped','reason'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','set_task_status',['work_order_public_id'=>$workOrder,'task_public_id'=>$task,'status'=>$data['status'],'reason'=>$data['reason']??null],$this->commandContext($request));return back()->with('status','Task updated.');}
    public function storeTimeEntry(Request $request,string $workOrder){$data=$request->validate(['worker_user_id'=>'nullable|integer','started_at'=>'required|date','ended_at'=>'nullable|date|after_or_equal:started_at','minutes'=>'nullable|integer|min:0|max:100000','notes'=>'nullable|string|max:10000']);$workerId=(int)($data['worker_user_id']??$request->user()->id);unset($data['worker_user_id']);$data['source']='crm_web';$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','add_time_entry',['work_order_public_id'=>$workOrder,'worker_user_id'=>$workerId,'data'=>$data],$this->commandContext($request));return back()->with('status','Time entry recorded.');}
    public function storeMaterial(Request $request,string $workOrder){$data=$request->validate(['name'=>'required|string|max:180','sku'=>'nullable|string|max:100','quantity'=>'required|numeric|min:0.001|max:1000000','unit'=>'nullable|string|max:40','unit_cost_minor'=>'nullable|integer|min:0','billable'=>'nullable|boolean']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.work_orders','add_material',['work_order_public_id'=>$workOrder,'data'=>$data],$this->commandContext($request));return back()->with('status','Material recorded.');}
    public function startWorkOrderForm(Request $request,string $workOrder){$data=$request->validate(['form_public_id'=>'required|string|size:26']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.forms','start_submission',['form_public_id'=>$data['form_public_id'],'context'=>['work_order_public_id'=>$workOrder]],$this->commandContext($request));return back()->with('status','Form submission started.');}
    public function storeEvidence(Request $request,string $workOrder){$data=$request->validate(['file'=>'required|file|max:20480|mimes:jpg,jpeg,png,webp,pdf','evidence_type'=>'nullable|in:photo,document,signature,certificate,other','latitude'=>'nullable|numeric|between:-90,90','longitude'=>'nullable|numeric|between:-180,180','captured_at'=>'nullable|date']);$context=$data;unset($context['file']);$context['work_order_public_id']=$workOrder;$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.evidence','store_evidence',['file'=>$request->file('file'),'context'=>$context],$this->commandContext($request));return back()->with('status','Evidence stored privately.');}

    public function schedule(Request $request)
    {
        $userId = (int) $request->user()->id;
        $timezoneName = (string) config('titan-field.field_services.default_timezone', 'Australia/Melbourne');
        try {
            $timezone = new \DateTimeZone($timezoneName);
        } catch (\Throwable) {
            $timezone = new \DateTimeZone('UTC');
        }

        $today = new \DateTimeImmutable('now', $timezone);
        $monthQuery = trim((string) $request->query('month', ''));
        if (preg_match('/^\d{4}-\d{2}$/', $monthQuery) === 1) {
            $monthStart = \DateTimeImmutable::createFromFormat('!Y-m', $monthQuery, $timezone) ?: $today->modify('first day of this month')->setTime(0, 0);
        } else {
            $monthStart = $today->modify('first day of this month')->setTime(0, 0);
        }

        $monthEnd = $monthStart->modify('last day of this month')->setTime(23, 59, 59);
        $gridStart = $monthStart->modify('monday this week')->setTime(0, 0);
        $gridEnd = $monthEnd->modify('sunday this week')->setTime(23, 59, 59);

        $filters = $request->only(['status', 'assigned_user_id']);
        $filters['from'] = $gridStart->format('Y-m-d H:i:s');
        $filters['to'] = $gridEnd->format('Y-m-d H:i:s');
        $appointments = $this->appointments->search($userId, $filters, 250);

        $calendarWeeks = [];
        for ($weekStart = $gridStart; $weekStart <= $gridEnd; $weekStart = $weekStart->modify('+7 days')) {
            $week = [];
            for ($offset = 0; $offset < 7; $offset++) {
                $day = $weekStart->modify('+' . $offset . ' days');
                $dayStart = $day->setTime(0, 0, 0)->getTimestamp();
                $dayEnd = $day->setTime(23, 59, 59)->getTimestamp();
                $dayAppointments = [];
                foreach ($appointments as $appointment) {
                    $start = strtotime((string) ($appointment['scheduled_start'] ?? ''));
                    $end = strtotime((string) ($appointment['scheduled_end'] ?? ''));
                    if ($start === false || $end === false) {
                        continue;
                    }
                    if ($start <= $dayEnd && $end >= $dayStart) {
                        $dayAppointments[] = $appointment;
                    }
                }
                $week[] = [
                    'date' => $day->format('Y-m-d'),
                    'day' => (int) $day->format('j'),
                    'in_month' => $day->format('Y-m') === $monthStart->format('Y-m'),
                    'is_today' => $day->format('Y-m-d') === $today->format('Y-m-d'),
                    'appointments' => $dayAppointments,
                ];
            }
            $calendarWeeks[] = $week;
        }

        $selectedDate = trim((string) $request->query('date', ''));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate) !== 1) {
            $selectedDate = $today->format('Y-m') === $monthStart->format('Y-m')
                ? $today->format('Y-m-d')
                : $monthStart->format('Y-m-d');
        }
        $selectedStart = strtotime($selectedDate . ' 00:00:00');
        $selectedEnd = strtotime($selectedDate . ' 23:59:59');
        $selectedAppointments = array_values(array_filter($appointments, static function (array $appointment) use ($selectedStart, $selectedEnd): bool {
            $start = strtotime((string) ($appointment['scheduled_start'] ?? ''));
            $end = strtotime((string) ($appointment['scheduled_end'] ?? ''));
            return $start !== false && $end !== false && $selectedStart !== false && $selectedEnd !== false
                && $start <= $selectedEnd && $end >= $selectedStart;
        }));

        return view('titan-field::field-services.schedule', [
            'appointments' => $appointments,
            'calendarWeeks' => $calendarWeeks,
            'calendarTitle' => $monthStart->format('F Y'),
            'currentMonth' => $monthStart->format('Y-m'),
            'previousMonth' => $monthStart->modify('-1 month')->format('Y-m'),
            'nextMonth' => $monthStart->modify('+1 month')->format('Y-m'),
            'todayDate' => $today->format('Y-m-d'),
            'todayMonth' => $today->format('Y-m'),
            'selectedDate' => $selectedDate,
            'selectedAppointments' => $selectedAppointments,
        ]);
    }
    public function recommendWorkers(Request $request){$data=$request->validate(['scheduled_start'=>'required|date','scheduled_end'=>'required|date|after:scheduled_start','service_public_id'=>'nullable|string|size:26','work_order_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','postcode'=>'nullable|string|max:20','latitude'=>'nullable|numeric|between:-90,90','longitude'=>'nullable|numeric|between:-180,180','travel_buffer_minutes'=>'nullable|integer|min:0|max:1440']);$context=$data;unset($context['scheduled_start'],$context['scheduled_end']);$context['_trace_id']=$request->header('X-Trace-Id');$context['_correlation_id']=$request->header('X-Correlation-Id');return response()->json($this->technicianRecommendations->recommend((int)$request->user()->id,$data['scheduled_start'],$data['scheduled_end'],$context));}
    public function storeAppointment(Request $request){$data=$request->validate(['title'=>'required|string|max:220','work_order_public_id'=>'nullable|string|size:26','service_request_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','scheduled_start'=>'required|date','scheduled_end'=>'required|date','timezone'=>'required|string|max:80','assigned_user_id'=>'nullable|integer','customer_notes'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.scheduling','schedule_appointment',['data'=>$data],$this->commandContext($request));return back()->with('status','Appointment scheduled.');}

    public function controlSurface(Request $request){$date=(string)($request->query('date')?:now()->toDateString());return view('titan-field::field-services.control',$this->controlSurfaceService->forDate((int)$request->user()->id,$date));}
    public function capacityForecast(Request $request){$from=(string)($request->query('from')?:now()->toDateString());$days=max(1,min(60,(int)$request->query('days',14)));return view('titan-field::field-services.capacity',$this->capacityForecasts->forecast((int)$request->user()->id,$from,$days));}
    public function moveAppointment(Request $request,string $appointment){$data=$request->validate(['scheduled_start'=>'required|date','scheduled_end'=>'required|date','assigned_user_id'=>'nullable|integer|min:1','timezone'=>'nullable|string|max:80']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.scheduling','reschedule_appointment',['public_id'=>$appointment,'data'=>$data],$this->commandContext($request));return back()->with('status','Appointment moved through SchedulingKernel validation.');}
    public function resizeAppointment(Request $request,string $appointment){$data=$request->validate(['scheduled_end'=>'required|date','timezone'=>'nullable|string|max:80']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.scheduling','reschedule_appointment',['public_id'=>$appointment,'data'=>$data],$this->commandContext($request));return back()->with('status','Appointment duration updated through SchedulingKernel validation.');}

    public function dispatch(Request $request){return view('titan-field::field-services.dispatch',['assignments'=>$this->dispatch->board((int)$request->user()->id,$request->query('date'))]);}
    public function assignDispatch(Request $request){$data=$request->validate(['work_order_public_id'=>'required|string|size:26','worker_user_id'=>'required|integer','appointment_public_id'=>'nullable|string|size:26','scheduled_start'=>'nullable|date','scheduled_end'=>'nullable|date','timezone'=>'nullable|string|max:80']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.dispatch','assign_dispatch',['work_order_public_id'=>$data['work_order_public_id'],'worker_user_id'=>(int)$data['worker_user_id'],'data'=>$data],$this->commandContext($request));return back()->with('status','Dispatch assigned.');}
    public function dispatchStatus(Request $request,string $assignment){$data=$request->validate(['status'=>'required|string|max:30','reason'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.dispatch','transition_dispatch',['public_id'=>$assignment,'status'=>$data['status'],'reason'=>$data['reason']??null],$this->commandContext($request));return back()->with('status','Dispatch updated.');}

    public function timesheets(Request $request)
    {
        $userId = (int) $request->user()->id;
        $rows = $this->db->table('crm_work_order_time_entries')
            ->where('company_id', $this->tenantContext->companyId($userId))
            ->orderByDesc('started_at')
            ->limit(300)
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
        return view('titan-field::field-services.timesheets', ['timeEntries' => $rows]);
    }

    public function agreements(Request $request){$userId=(int)$request->user()->id;$rows=$this->db->table('crm_service_agreements')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderByDesc('id')->limit(200)->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.agreements',['agreements'=>$rows]);}
    public function storeAgreement(Request $request){$data=$request->validate(['name'=>'required|string|max:220','contact_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','cadence'=>'required|in:daily,weekly,fortnightly,monthly,quarterly,yearly,annual','interval_count'=>'nullable|integer|min:1|max:100','starts_on'=>'required|date','ends_on'=>'nullable|date','price_minor'=>'nullable|integer|min:0','currency'=>'nullable|string|size:3','auto_create_work_order'=>'nullable|boolean']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.recurring','create_agreement',['data'=>$data],$this->commandContext($request));return back()->with('status','Service agreement created.');}
    public function generateRecurring(Request $request){$receipt=$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.recurring','generate_due_occurrences',[],$this->commandContext($request));$items=(array)($receipt['result']??[]);return back()->with('status',count($items).' recurring occurrence(s) generated.');}
    public function agreementStatus(Request $request,string $agreement){$data=$request->validate(['status'=>'required|in:active,paused,cancelled,expired']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.recurring','set_agreement_status',['public_id'=>$agreement,'status'=>$data['status']],$this->commandContext($request));return back()->with('status','Service agreement updated.');}

    public function forms(Request $request){$userId=(int)$request->user()->id;$rows=$this->db->table('crm_form_templates')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderBy('name')->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.forms',['templates'=>$rows]);}
    public function storeForm(Request $request){$data=$request->validate(['key'=>'required|string|max:120','name'=>'required|string|max:220','form_type'=>'nullable|string|max:50','applies_to'=>'nullable|string|max:50']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.forms','create_template',['data'=>$data+['fields'=>[['key'=>'completed','label'=>'Completed','field_type'=>'boolean','required'=>true]]]],$this->commandContext($request));return back()->with('status','Form template created.');}
    public function publishForm(Request $request,string $form){$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.forms','publish_template',['public_id'=>$form],$this->commandContext($request));return back()->with('status','Form template published.');}


    public function exceptions(Request $request){return view('titan-field::field-services.exceptions',['exceptions'=>$this->exceptionsEngine->list((int)$request->user()->id,$request->only(['status','severity','exception_type','owner_user_id']))]);}
    public function detectExceptions(Request $request){$receipt=$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.exceptions','detect',[],$this->commandContext($request));$items=(array)($receipt['result']??[]);return back()->with('status',count($items).' operational exception candidate(s) detected or already tracked.');}
    public function acknowledgeException(Request $request,string $exception){$data=$request->validate(['note'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.exceptions','acknowledge',['public_id'=>$exception,'note'=>$data['note']??null],$this->commandContext($request));return back()->with('status','Exception acknowledged.');}
    public function assignException(Request $request,string $exception){$data=$request->validate(['owner_user_id'=>'required|integer|min:1','note'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.exceptions','assign',['public_id'=>$exception,'owner_user_id'=>$data['owner_user_id'],'note'=>$data['note']??null],$this->commandContext($request));return back()->with('status','Exception assigned.');}
    public function resolveException(Request $request,string $exception){$data=$request->validate(['resolution'=>'required|string|max:20000','evidence'=>'nullable|string|max:20000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.exceptions','resolve',['public_id'=>$exception,'resolution'=>$data['resolution'],'evidence'=>$data['evidence']?['note'=>$data['evidence']]:[]],$this->commandContext($request));return back()->with('status','Exception resolved.');}
    public function closeException(Request $request,string $exception){$data=$request->validate(['note'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.exceptions','close',['public_id'=>$exception,'note'=>$data['note']??null],$this->commandContext($request));return back()->with('status','Exception closed.');}

    public function support(Request $request){$userId=(int)$request->user()->id;$rows=$this->db->table('crm_support_tickets')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderByDesc('id')->limit(200)->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.support',['tickets'=>$rows]);}
    public function storeSupport(Request $request){$data=$request->validate(['subject'=>'required|string|max:220','description'=>'nullable|string|max:20000','contact_public_id'=>'nullable|string|size:26','priority'=>'nullable|in:low,normal,high,urgent']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.support','create_ticket',['data'=>$data],$this->commandContext($request));return back()->with('status','Support ticket created.');}

    public function reviews(Request $request){$userId=(int)$request->user()->id;$reviews=$this->db->table('crm_reviews')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderByDesc('id')->limit(200)->get()->map(fn($x)=>(array)$x)->all();$recovery=$this->db->table('crm_service_recovery_cases')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderByDesc('id')->limit(100)->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.reviews',['reviews'=>$reviews,'recovery'=>$recovery]);}

    public function assets(Request $request){$userId=(int)$request->user()->id;$rows=$this->db->table('crm_customer_assets')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderBy('name')->limit(200)->get()->map(fn($x)=>(array)$x)->all();return view('titan-field::field-services.assets',['assets'=>$rows]);}
    public function storeAsset(Request $request){$data=$request->validate(['name'=>'required|string|max:180','asset_type'=>'required|string|max:120','contact_public_id'=>'nullable|string|size:26','company_public_id'=>'nullable|string|size:26','location_public_id'=>'nullable|string|size:26','manufacturer'=>'nullable|string|max:120','model'=>'nullable|string|max:120','serial_number'=>'nullable|string|max:160','warranty_expires_on'=>'nullable|date','next_service_on'=>'nullable|date']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.assets','create_asset',['data'=>$data],$this->commandContext($request));return back()->with('status','Customer asset created.');}

    public function serviceAreas(Request $request){return view('titan-field::field-services.service-areas',['areas'=>$this->serviceAreas->list((int)$request->user()->id)]);}
    public function storeServiceArea(Request $request){$data=$request->validate(['name'=>'required|string|max:180','match_type'=>'required|in:postcode,radius,polygon','postcodes'=>'nullable|string|max:10000','center_latitude'=>'nullable|numeric|between:-90,90','center_longitude'=>'nullable|numeric|between:-180,180','radius_km'=>'nullable|numeric|min:0.01|max:5000','polygon'=>'nullable|string|max:50000','service_public_ids'=>'nullable|string|max:10000','active'=>'nullable|boolean']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.service_areas','create_service_area',['data'=>$data],$this->commandContext($request));return back()->with('status','Service area created.');}
    public function updateServiceArea(Request $request,string $serviceArea){$data=$request->validate(['name'=>'required|string|max:180','match_type'=>'required|in:postcode,radius,polygon','postcodes'=>'nullable|string|max:10000','center_latitude'=>'nullable|numeric|between:-90,90','center_longitude'=>'nullable|numeric|between:-180,180','radius_km'=>'nullable|numeric|min:0.01|max:5000','polygon'=>'nullable|string|max:50000','service_public_ids'=>'nullable|string|max:10000','active'=>'nullable|boolean']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.service_areas','update_service_area',['public_id'=>$serviceArea,'data'=>$data],$this->commandContext($request));return back()->with('status','Service area updated.');}

    /** @return array<string,mixed> */
    public function routes(Request $request){$userId=(int)$request->user()->id;return view('titan-field::field-services.routes',['routes'=>$this->routesEngine->list($userId,$request->query('date')),'optimisationProposals'=>$this->routeOptimisationProposals->list($userId,null,100)]);}
    public function storeRoute(Request $request){$data=$request->validate(['worker_user_id'=>'required|integer|min:1','route_date'=>'required|date','name'=>'nullable|string|max:180']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','create_route',$data,$this->commandContext($request));return back()->with('status','Route created.');}
    public function storeRouteStop(Request $request,string $route){$data=$request->validate(['appointment_public_id'=>'required|string|size:26']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','add_stop',['route_public_id'=>$route,'appointment_public_id'=>$data['appointment_public_id']],$this->commandContext($request));return back()->with('status','Route stop added.');}
    public function resequenceRouteStops(Request $request,string $route){$data=$request->validate(['stop_public_ids'=>'required|array|min:1','stop_public_ids.*'=>'required|string|size:26']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','resequence_stops',['route_public_id'=>$route,'stop_public_ids'=>$data['stop_public_ids']],$this->commandContext($request));return back()->with('status','Route order updated.');}
    public function routeStopStatus(Request $request,string $stop){$data=$request->validate(['status'=>'required|in:planned,en_route,arrived,in_progress,completed,skipped','note'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','transition_stop',['stop_public_id'=>$stop,'status'=>$data['status'],'note'=>$data['note']??null],$this->commandContext($request));return back()->with('status','Route stop updated.');}
    public function recordWorkerLocation(Request $request){$data=$request->validate(['worker_user_id'=>'required|integer|min:1','route_public_id'=>'nullable|string|size:26','appointment_public_id'=>'nullable|string|size:26','latitude'=>'required|numeric|between:-90,90','longitude'=>'required|numeric|between:-180,180','accuracy_meters'=>'required|numeric|min:0|max:5000','heading_degrees'=>'nullable|numeric|min:0|max:360','speed_mps'=>'nullable|numeric|min:0|max:200','captured_at'=>'nullable|date','source'=>'nullable|string|max:40']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','record_location',$data,$this->commandContext($request));return response()->json(['status'=>'recorded']);}
    public function requestRouteOptimisationProposal(Request $request,string $route){$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','request_optimisation_proposal',['route_public_id'=>$route],$this->commandContext($request));return back()->with('status','Route optimisation proposal generated for review.');}
    public function acceptRouteOptimisationProposal(Request $request,string $proposal){$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','accept_optimisation_proposal',['proposal_public_id'=>$proposal],$this->commandContext($request));return back()->with('status','Route optimisation proposal accepted. Apply it separately to change route order.');}
    public function rejectRouteOptimisationProposal(Request $request,string $proposal){$data=$request->validate(['reason'=>'nullable|string|max:10000']);$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','reject_optimisation_proposal',['proposal_public_id'=>$proposal,'reason'=>$data['reason']??null],$this->commandContext($request));return back()->with('status','Route optimisation proposal rejected.');}
    public function applyRouteOptimisationProposal(Request $request,string $proposal){$this->commands->execute((int)$request->user()->id,(int)$request->user()->id,'titan.field.routes','apply_optimisation_proposal',['proposal_public_id'=>$proposal],$this->commandContext($request));return back()->with('status','Accepted route optimisation proposal applied through Titan Field governance.');}

    private function commandContext(Request $request): array
    {
        $idempotency = trim((string) $request->header('Idempotency-Key', ''));
        if ($idempotency === '') $idempotency = (string) Str::uuid();
        return [
            'source' => 'crm_web',
            'idempotency_key' => $idempotency,
            'trace_id' => $request->header('X-Trace-Id'),
            'correlation_id' => $request->header('X-Correlation-Id'),
            'causation_id' => $request->header('X-Causation-Id'),
        ];
    }

}
