<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders;

use InvalidArgumentException;

final class WorkOrderStatusPolicy
{
    private const TRANSITIONS = [
        'draft'=>['ready','cancelled'],
        'ready'=>['scheduled','dispatched','in_progress','cancelled'],
        'scheduled'=>['dispatched','in_progress','cancelled'],
        'dispatched'=>['in_progress','cancelled'],
        'in_progress'=>['paused','awaiting_customer','completed','cancelled'],
        'paused'=>['in_progress','awaiting_customer','cancelled'],
        'awaiting_customer'=>['in_progress','cancelled'],
        'completed'=>['in_progress','invoiced'],
        'invoiced'=>['closed','in_progress'],
        'closed'=>['in_progress'],
        'cancelled'=>['draft'],
    ];

    public function assertTransition(string $fromStatus, string $toStatus, ?string $reason, int $incompleteRequiredTasks, int $incompleteRequiredForms = 0): void
    {
        if ($fromStatus === $toStatus) return;
        if (! in_array($toStatus, self::TRANSITIONS[$fromStatus] ?? [], true)) throw new InvalidArgumentException("Work order cannot move from {$fromStatus} to {$toStatus}.");
        if (($toStatus === 'cancelled' || in_array($fromStatus,['completed','invoiced','closed','cancelled'],true)) && trim((string)$reason) === '') throw new InvalidArgumentException('A reason is required when cancelling or reopening a closed work order.');
        if ($toStatus === 'completed' && $incompleteRequiredTasks > 0) throw new InvalidArgumentException('All required work-order tasks must be completed or skipped before completion.');
        if ($toStatus === 'completed' && $incompleteRequiredForms > 0) throw new InvalidArgumentException('All required work-order forms must be submitted before completion.');
    }
}
