<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/** Evidence/form gate for the authoritative work-order completed transition. */
final class WorkOrderCompletionGuard
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db) {}

    /** @return array{evidence_attached_hash:string,evidence_count:int,form_count:int,required_evidence:array<string,int>,required_forms:array<int,string>,snapshot:array<string,mixed>} */
    public function assertCanComplete(int $userId,string $workOrderPublicId,?string $providedEvidenceAttachedHash=null): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();
        if(!$work)throw new InvalidArgumentException('Work order not found.');
        $service=$work->service_public_id?$this->db->table('crm_services')->where('company_id',$tenant)->where('public_id',$work->service_public_id)->whereNull('deleted_at')->first():null;

        $requiredEvidence=$this->normaliseEvidenceRequirements($service->evidence_requirements??null);
        $requiredForms=$this->decodeList($service->form_template_public_ids??null);
        $allEvidence=$this->db->table('crm_field_evidence')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->whereNull('deleted_at')->orderBy('public_id')->get(['public_id','evidence_type','sha256','captured_at'])->map(fn($r)=>(array)$r)->all();
        $verifiedEvidence=array_values(array_filter($allEvidence,fn(array $item):bool=>preg_match('/^[a-f0-9]{64}$/i',trim((string)($item['sha256']??'')))===1));$evidence=$verifiedEvidence;
        $forms=$this->db->table('crm_form_submissions')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->whereNull('deleted_at')->where('status','submitted')->orderBy('public_id')->get(['public_id','template_public_id','version_public_id','submitted_at','has_failures'])->map(fn($r)=>(array)$r)->all();

        $counts=[];foreach($evidence as $item){$type=strtolower((string)($item['evidence_type']??''));$counts[$type]=($counts[$type]??0)+1;}
        foreach($requiredEvidence as $type=>$minimum){if(($counts[$type]??0)<$minimum)throw new InvalidArgumentException("Work order requires at least {$minimum} {$type} evidence item(s) before completion.");}
        $submittedTemplates=array_values(array_unique(array_map(fn($r)=>(string)$r['template_public_id'],$forms)));
        $missingForms=array_values(array_diff($requiredForms,$submittedTemplates));
        if($missingForms!==[])throw new InvalidArgumentException('Required completion form(s) are not submitted: '.implode(', ',$missingForms).'.');

        $snapshot=['work_order_public_id'=>$workOrderPublicId,'evidence'=>$evidence,'forms'=>$forms,'required_evidence'=>$requiredEvidence,'required_forms'=>$requiredForms];
        $hash=hash('sha256',json_encode($snapshot,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION));
        if($providedEvidenceAttachedHash!==null&&trim($providedEvidenceAttachedHash)!==''&&!hash_equals($hash,trim($providedEvidenceAttachedHash))){
            throw new InvalidArgumentException('evidence_attached_hash does not match the current completion evidence set.');
        }
        return ['evidence_attached_hash'=>$hash,'evidence_count'=>count($evidence),'form_count'=>count($forms),'required_evidence'=>$requiredEvidence,'required_forms'=>$requiredForms,'snapshot'=>$snapshot];
    }

    /** @return array<string,int> */
    private function normaliseEvidenceRequirements(mixed $raw): array
    {
        $data=$this->decodeAssoc($raw);$result=[];
        if(array_is_list($data)){foreach($data as $value){if(is_string($value)&&trim($value)!=='')$result[strtolower(trim($value))]=1;elseif(is_array($value)&&isset($value['type']))$result[strtolower((string)$value['type'])]=max(1,(int)($value['min']??$value['minimum']??1));}}
        else{foreach($data as $type=>$value){$result[strtolower((string)$type)]=max(1,(int)(is_array($value)?($value['min']??$value['minimum']??1):$value));}}
        return $result;
    }

    /** @return array<int,string> */
    private function decodeList(mixed $raw): array
    {
        $data=$this->decodeAssoc($raw);if(!array_is_list($data))return [];
        return array_values(array_filter(array_map(fn($v)=>trim((string)$v),$data),fn($v)=>$v!==''));
    }

    /** @return array<mixed> */
    private function decodeAssoc(mixed $raw): array
    {
        if(is_array($raw))return $raw;
        if(!is_string($raw)||trim($raw)==='')return [];
        $decoded=json_decode($raw,true);return is_array($decoded)?$decoded:[];
    }
}
