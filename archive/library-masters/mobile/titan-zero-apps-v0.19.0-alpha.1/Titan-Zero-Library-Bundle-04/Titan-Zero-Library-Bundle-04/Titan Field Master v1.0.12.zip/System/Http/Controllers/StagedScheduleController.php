<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Read-only calendar exposed while CRM still owns Field authority.
 * No Field command gateway or mutation service is available on this surface.
 */
final class StagedScheduleController
{
    public function __invoke(Request $request): mixed
    {
        $timezoneName = (string) config('titan-field.field_services.default_timezone', 'Australia/Melbourne');
        try {
            $timezone = new \DateTimeZone($timezoneName);
        } catch (\Throwable) {
            $timezone = new \DateTimeZone('UTC');
        }

        $today = new \DateTimeImmutable('now', $timezone);
        $monthQuery = trim((string) $request->query('month', ''));
        $monthStart = preg_match('/^\d{4}-\d{2}$/', $monthQuery) === 1
            ? (\DateTimeImmutable::createFromFormat('!Y-m', $monthQuery, $timezone) ?: $today->modify('first day of this month')->setTime(0, 0))
            : $today->modify('first day of this month')->setTime(0, 0);
        $monthEnd = $monthStart->modify('last day of this month')->setTime(23, 59, 59);
        $gridStart = $monthStart->modify('monday this week')->setTime(0, 0);
        $gridEnd = $monthEnd->modify('sunday this week')->setTime(23, 59, 59);

        $companyId = (int) ($request->user()?->company_id ?? 0);
        $appointments = [];
        if ($companyId > 0 && Schema::hasTable('crm_appointments')) {
            $query = DB::table('crm_appointments')
                ->where('company_id', $companyId)
                ->where('scheduled_end', '>=', $gridStart->format('Y-m-d H:i:s'))
                ->where('scheduled_start', '<=', $gridEnd->format('Y-m-d H:i:s'));
            if (Schema::hasColumn('crm_appointments', 'deleted_at')) {
                $query->whereNull('deleted_at');
            }
            $appointments = $query->orderBy('scheduled_start')->limit(250)->get()->map(static fn ($row): array => (array) $row)->all();
        }

        $calendarWeeks = [];
        for ($weekStart = $gridStart; $weekStart <= $gridEnd; $weekStart = $weekStart->modify('+7 days')) {
            $week = [];
            for ($offset = 0; $offset < 7; $offset++) {
                $day = $weekStart->modify('+' . $offset . ' days');
                $dayStart = $day->setTime(0, 0, 0)->getTimestamp();
                $dayEnd = $day->setTime(23, 59, 59)->getTimestamp();
                $dayAppointments = array_values(array_filter($appointments, static function (array $appointment) use ($dayStart, $dayEnd): bool {
                    $start = strtotime((string) ($appointment['scheduled_start'] ?? ''));
                    $end = strtotime((string) ($appointment['scheduled_end'] ?? ''));
                    return $start !== false && $end !== false && $start <= $dayEnd && $end >= $dayStart;
                }));
                $week[] = [
                    'date' => $day->format('Y-m-d'),
                    'day' => (int) $day->format('j'),
                    'in_month' => $day->format('Y-m') === $monthStart->format('Y-m'),
                    'is_today' => $day->format('Y-m-d') === $today->format('Y-m-d'),
                    'appointments' => $dayAppointments,
                ];
            }
            $calendarWeeks[] = $week;
        }

        $selectedDate = trim((string) $request->query('date', ''));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate) !== 1) {
            $selectedDate = $today->format('Y-m') === $monthStart->format('Y-m') ? $today->format('Y-m-d') : $monthStart->format('Y-m-d');
        }
        $selectedStart = strtotime($selectedDate . ' 00:00:00');
        $selectedEnd = strtotime($selectedDate . ' 23:59:59');
        $selectedAppointments = array_values(array_filter($appointments, static function (array $appointment) use ($selectedStart, $selectedEnd): bool {
            $start = strtotime((string) ($appointment['scheduled_start'] ?? ''));
            $end = strtotime((string) ($appointment['scheduled_end'] ?? ''));
            return $start !== false && $end !== false && $selectedStart !== false && $selectedEnd !== false && $start <= $selectedEnd && $end >= $selectedStart;
        }));

        return view('titan-field::field-services.schedule', [
            'appointments' => $appointments,
            'calendarWeeks' => $calendarWeeks,
            'calendarTitle' => $monthStart->format('F Y'),
            'currentMonth' => $monthStart->format('Y-m'),
            'previousMonth' => $monthStart->modify('-1 month')->format('Y-m'),
            'nextMonth' => $monthStart->modify('+1 month')->format('Y-m'),
            'todayDate' => $today->format('Y-m-d'),
            'todayMonth' => $today->format('Y-m'),
            'selectedDate' => $selectedDate,
            'selectedAppointments' => $selectedAppointments,
            'staged' => true,
        ]);
    }
}
