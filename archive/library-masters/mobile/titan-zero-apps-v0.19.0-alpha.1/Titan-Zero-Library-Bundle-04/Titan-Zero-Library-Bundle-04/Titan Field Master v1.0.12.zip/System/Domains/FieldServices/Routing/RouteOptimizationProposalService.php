<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Routing;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use InvalidArgumentException;

/** Maps proposes; Titan Field owns acceptance and authoritative route mutation. */
final class RouteOptimizationProposalService
{
    public function __construct(
        private readonly FieldTenantContext $tenantContext,
        private readonly ConnectionInterface $db,
        private readonly SpatialIntelligenceGateway $spatial,
        private readonly FieldSignalPort $signals,
        private readonly RouteService $routes,
    ) {}

    /** @return array<string,mixed> */
    public function request(int $userId, ?int $actorUserId, string $routePublicId, array $context = []): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $route=$this->db->table('titan_field_routes')->where('company_id',$tenant)->where('public_id',$routePublicId)->first();
        if(!$route)throw new InvalidArgumentException('Route not found.');
        $rows=$this->db->table('titan_field_route_stops')->where('company_id',$tenant)->where('route_public_id',$routePublicId)->orderBy('sequence')->get();
        if($rows->count()<2)throw new InvalidArgumentException('Route optimisation requires at least two stops.');
        $stops=[];
        foreach($rows as $row){
            $location=$row->location_public_id?$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$row->location_public_id)->whereNull('deleted_at')->first():null;
            if(!$location||$location->latitude===null||$location->longitude===null)throw new InvalidArgumentException('All route stops must have geocoded service locations before optimisation can be proposed.');
            $appointment=$row->appointment_public_id?$this->db->table('crm_appointments')->where('company_id',$tenant)->where('public_id',$row->appointment_public_id)->whereNull('deleted_at')->first():null;
            $duration=0;if($appointment&&$appointment->scheduled_start&&$appointment->scheduled_end){$duration=max(0,Carbon::parse($appointment->scheduled_start)->diffInSeconds(Carbon::parse($appointment->scheduled_end)));}
            $stops[]=['public_id'=>(string)$row->public_id,'sequence'=>(int)$row->sequence,'work_order_public_id'=>$row->work_order_public_id,'appointment_public_id'=>$row->appointment_public_id,'location_public_id'=>$row->location_public_id,'latitude'=>(float)$location->latitude,'longitude'=>(float)$location->longitude,'label'=>$appointment?->title??('Route stop '.(int)$row->sequence),'service_duration_seconds'=>$duration,'window_start'=>$appointment?->scheduled_start,'window_end'=>$appointment?->scheduled_end,'locked'=>in_array((string)$row->status,['en_route','arrived','in_progress','completed','skipped'],true),'status'=>(string)$row->status];
        }
        $routePayload=['public_id'=>(string)$route->public_id,'route_date'=>(string)$route->route_date,'worker_user_id'=>(int)$route->worker_user_id,'status'=>(string)$route->status,'entity_version'=>(int)($route->entity_version??1),'start_at'=>$route->started_at?:($stops[0]['window_start']??null)];
        $proposal=$this->spatial->routeOptimizationProposal($userId,$routePublicId,$routePayload,$stops,$context);
        if(!(bool)($proposal['available']??false))throw new InvalidArgumentException('Titan Maps Intelligence is required for route optimisation proposals.');
        $baseline=array_values(array_map(static fn(array $s):string=>(string)$s['public_id'],$stops));$proposed=array_values(array_map('strval',(array)($proposal['proposed_stop_public_ids']??[])));
        if(count($proposed)!==count($baseline)||array_diff($baseline,$proposed)!==[]||array_diff($proposed,$baseline)!==[])throw new InvalidArgumentException('Maps proposal does not contain exactly the current Field route stops.');
        $inputHash=(string)($proposal['input_hash']??hash('sha256',json_encode([$routePayload,$stops],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)));
        $proposalHash=(string)($proposal['proposal_hash']??hash('sha256',json_encode($proposal,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)));
        $existing=$this->db->table('titan_field_route_optimisation_proposals')->where('company_id',$tenant)->where('input_hash',$inputHash)->where('proposal_hash',$proposalHash)->first();
        if($existing)return $this->row($existing);
        $publicId=(string)Str::ulid();$now=now();
        $row=['public_id'=>$publicId,'company_id'=>$tenant,'route_public_id'=>$routePublicId,'provider'=>(string)($proposal['provider']??'titan-maps-intelligence'),'provider_proposal_id'=>isset($proposal['proposal_id'])?(string)$proposal['proposal_id']:null,'input_hash'=>$inputHash,'proposal_hash'=>$proposalHash,'baseline_stop_public_ids'=>json_encode($baseline),'proposed_stop_public_ids'=>json_encode($proposed),'proposal_payload'=>json_encode($proposal),'status'=>'pending','entity_version'=>1,'requested_by_user_id'=>$actorUserId??$userId,'accepted_by_user_id'=>null,'expires_at'=>isset($proposal['expires_at'])?Carbon::parse((string)$proposal['expires_at']):$now->copy()->addMinutes(15),'accepted_at'=>null,'rejected_at'=>null,'rejection_reason'=>null,'applied_at'=>null,'applied_command_receipt_id'=>null,'created_at'=>$now,'updated_at'=>$now];
        $this->db->transaction(function()use($row,$userId,$actorUserId,$context,$publicId,$routePublicId,$proposalHash):void{$this->db->table('titan_field_route_optimisation_proposals')->insert($row);$this->signals->record($userId,$actorUserId,'field.route.optimisation_proposal_recorded','field_route_optimisation_proposal',$publicId,['route_public_id'=>$routePublicId,'proposal_hash'=>$proposalHash,'status'=>'pending'],$context);});
        return $this->row((object)$row);
    }

    /** @return array<string,mixed> */
    public function accept(int $userId, ?int $actorUserId, string $proposalPublicId, array $context = []): array
    {
        return $this->transitionDecision($userId,$actorUserId,$proposalPublicId,'accepted',null,$context);
    }

    /** @return array<string,mixed> */
    public function reject(int $userId, ?int $actorUserId, string $proposalPublicId, ?string $reason = null, array $context = []): array
    {
        return $this->transitionDecision($userId,$actorUserId,$proposalPublicId,'rejected',$reason,$context);
    }

    /** @return array<string,mixed> */
    public function apply(int $userId, ?int $actorUserId, string $proposalPublicId, array $context = []): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        return $this->db->transaction(function()use($userId,$actorUserId,$proposalPublicId,$context,$tenant):array{
            $proposal=$this->db->table('titan_field_route_optimisation_proposals')->where('company_id',$tenant)->where('public_id',$proposalPublicId)->lockForUpdate()->first();if(!$proposal)throw new InvalidArgumentException('Route optimisation proposal not found.');
            if((string)$proposal->status!=='accepted')throw new InvalidArgumentException('Only an accepted optimisation proposal can be applied.');
            if($proposal->expires_at&&Carbon::parse($proposal->expires_at)->isPast()){ $this->markStale($proposal,'expired');throw new InvalidArgumentException('Route optimisation proposal has expired.'); }
            $baseline=$this->jsonArray($proposal->baseline_stop_public_ids);$proposed=$this->jsonArray($proposal->proposed_stop_public_ids);$current=$this->db->table('titan_field_route_stops')->where('company_id',$tenant)->where('route_public_id',$proposal->route_public_id)->orderBy('sequence')->pluck('public_id')->map(fn($v)=>(string)$v)->all();
            if($current!==$baseline){$this->markStale($proposal,'route_changed_after_proposal');throw new InvalidArgumentException('Route changed after this optimisation proposal was generated. Generate a new proposal.');}
            $result=$this->routes->resequence($userId,$actorUserId,(string)$proposal->route_public_id,$proposed,array_merge($context,['causation_id'=>$proposalPublicId]));
            $now=now();$this->db->table('titan_field_route_optimisation_proposals')->where('id',$proposal->id)->update(['status'=>'applied','applied_at'=>$now,'applied_command_receipt_id'=>$context['idempotency_key']??null,'entity_version'=>((int)$proposal->entity_version)+1,'updated_at'=>$now]);
            $this->signals->record($userId,$actorUserId,'field.route.optimisation_proposal_applied','field_route_optimisation_proposal',$proposalPublicId,['route_public_id'=>$proposal->route_public_id,'proposal_hash'=>$proposal->proposal_hash,'status'=>'applied'],$context);
            return ['proposal'=>$this->row($this->db->table('titan_field_route_optimisation_proposals')->where('id',$proposal->id)->first()),'route'=>$result];
        });
    }

    /** @return array<int,array<string,mixed>> */
    public function list(int $userId, ?string $routePublicId = null, int $limit = 100): array
    {
        $tenant=$this->tenantContext->companyId($userId);$q=$this->db->table('titan_field_route_optimisation_proposals')->where('company_id',$tenant);if($routePublicId)$q->where('route_public_id',$routePublicId);return $q->orderByDesc('id')->limit(max(1,min(200,$limit)))->get()->map(fn($r)=>$this->row($r))->all();
    }

    private function transitionDecision(int $userId, ?int $actorUserId, string $publicId, string $status, ?string $reason, array $context): array
    {
        $tenant=$this->tenantContext->companyId($userId);return $this->db->transaction(function()use($userId,$actorUserId,$publicId,$status,$reason,$context,$tenant):array{$row=$this->db->table('titan_field_route_optimisation_proposals')->where('company_id',$tenant)->where('public_id',$publicId)->lockForUpdate()->first();if(!$row)throw new InvalidArgumentException('Route optimisation proposal not found.');if(!in_array((string)$row->status,['pending','accepted'],true))throw new InvalidArgumentException('Route optimisation proposal is not awaiting a decision.');if($row->expires_at&&Carbon::parse($row->expires_at)->isPast()){$this->markStale($row,'expired');throw new InvalidArgumentException('Route optimisation proposal has expired.');}$now=now();$update=['status'=>$status,'entity_version'=>((int)$row->entity_version)+1,'updated_at'=>$now];if($status==='accepted'){$update['accepted_at']=$now;$update['accepted_by_user_id']=$actorUserId??$userId;}else{$update['rejected_at']=$now;$update['rejection_reason']=$reason;}$this->db->table('titan_field_route_optimisation_proposals')->where('id',$row->id)->update($update);$this->signals->record($userId,$actorUserId,'field.route.optimisation_proposal_'.$status,'field_route_optimisation_proposal',$publicId,['route_public_id'=>$row->route_public_id,'proposal_hash'=>$row->proposal_hash,'status'=>$status,'reason'=>$reason],$context);return $this->row($this->db->table('titan_field_route_optimisation_proposals')->where('id',$row->id)->first());});
    }

    private function markStale(object $row,string $reason): void{$payload=json_decode((string)$row->proposal_payload,true);$payload=is_array($payload)?$payload:[];$payload['stale_reason']=$reason;$this->db->table('titan_field_route_optimisation_proposals')->where('id',$row->id)->update(['status'=>'stale','proposal_payload'=>json_encode($payload),'entity_version'=>((int)$row->entity_version)+1,'updated_at'=>now()]);}
    private function jsonArray(mixed $value): array{$decoded=is_array($value)?$value:json_decode((string)$value,true);return array_values(array_map('strval',is_array($decoded)?$decoded:[]));}
    private function row(object $row): array{$out=(array)$row;foreach(['baseline_stop_public_ids','proposed_stop_public_ids','proposal_payload'] as $k)if(isset($out[$k])&&!is_array($out[$k]))$out[$k]=json_decode((string)$out[$k],true)?:[];return $out;}
}
