<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Assets;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class CustomerAssetService
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db,private FieldReferenceIntegrity $integrity) {}
    public function forContact(int $userId,string $contactPublicId): array { return $this->db->table('crm_customer_assets')->where('company_id', $this->tenantContext->companyId($userId))->where('contact_public_id',$contactPublicId)->whereNull('deleted_at')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }
    public function forLocation(int $userId,string $locationPublicId): array { return $this->db->table('crm_customer_assets')->where('company_id', $this->tenantContext->companyId($userId))->where('location_public_id',$locationPublicId)->whereNull('deleted_at')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }
    public function create(int $userId,array $data): array
    { $name=trim((string)($data['name']??''));$type=trim((string)($data['asset_type']??''));if($name===''||$type==='')throw new InvalidArgumentException('Customer asset name and type are required.');$this->integrity->assertContext($userId,$data);$publicId=(string)Str::ulid();$this->db->table('crm_customer_assets')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'location_public_id'=>$data['location_public_id']??null,'asset_type'=>$type,'name'=>$name,'manufacturer'=>$data['manufacturer']??null,'model'=>$data['model']??null,'serial_number'=>$data['serial_number']??null,'installed_on'=>$data['installed_on']??null,'warranty_expires_on'=>$data['warranty_expires_on']??null,'condition'=>$data['condition']??null,'last_serviced_on'=>$data['last_serviced_on']??null,'next_service_on'=>$data['next_service_on']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return (array)$this->db->table('crm_customer_assets')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first(); }
}
