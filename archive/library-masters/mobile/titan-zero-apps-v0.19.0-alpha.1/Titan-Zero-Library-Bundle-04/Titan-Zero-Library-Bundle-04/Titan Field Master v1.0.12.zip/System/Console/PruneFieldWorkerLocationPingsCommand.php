<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class PruneFieldWorkerLocationPingsCommand extends Command
{
    protected $signature = 'titan-field:prune-worker-location';
    protected $description = 'Delete expired Titan Field fallback worker-location evidence.';

    public function handle(): int
    {
        if (! Schema::hasTable('titan_field_worker_location_pings')) {
            $this->info('Titan Field fallback worker-location table is not installed.');
            return self::SUCCESS;
        }
        $deleted = DB::table('titan_field_worker_location_pings')
            ->whereNotNull('retention_expires_at')->where('retention_expires_at', '<=', now())->delete();
        $this->info("Pruned {$deleted} expired Titan Field fallback worker-location ping(s).");
        return self::SUCCESS;
    }
}
