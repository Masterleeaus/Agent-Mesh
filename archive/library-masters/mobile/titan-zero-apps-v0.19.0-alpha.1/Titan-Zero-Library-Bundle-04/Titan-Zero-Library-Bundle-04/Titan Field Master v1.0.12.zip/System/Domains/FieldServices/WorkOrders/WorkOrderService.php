<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use App\Extensions\TitanField\System\Domains\FieldServices\History\ServiceHistoryProjector;
use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;
use App\Extensions\TitanField\System\Contracts\FieldAuditPort;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkOrderService
{
    public function __construct(private FieldAutomationPort $automation,private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private WorkOrderStatusPolicy $policy,private FieldAuditPort $audit,private ServiceHistoryProjector $history,private WorkOrderCompletionGuard $completion,private FieldReferenceIntegrity $integrity) {}

    public function search(int $userId,array $filters=[],int $limit=100): array
    { $q=$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at'); foreach(['status','priority','assigned_user_id','contact_public_id','company_public_id','location_public_id','service_public_id'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]); return $q->orderByDesc('id')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all(); }

    public function create(int $userId,?int $actorUserId,array $data): array
    {
        $title=trim((string)($data['title']??'')); if($title==='')throw new InvalidArgumentException('Work-order title is required.');
        $idempotencyKey=trim((string)($data['idempotency_key']??'')); if($idempotencyKey!==''){ $existing=$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('idempotency_key',$idempotencyKey)->whereNull('deleted_at')->first(); if($existing)return (array)$existing; }
        $this->integrity->assertContext($userId,$data);
        if(array_key_exists('owner_user_id',$data)&&$data['owner_user_id']!==null)$this->integrity->assertTenantUser($userId,(int)$data['owner_user_id']);
        if(array_key_exists('assigned_user_id',$data)&&$data['assigned_user_id']!==null)$this->integrity->assertWorker($userId,(int)$data['assigned_user_id']);
        $publicId=(string)Str::ulid(); $number=$data['number']??('WO-'.now()->format('Ymd').'-'.strtoupper(substr($publicId,-6)));
        $row=['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'number'=>$number,'service_request_public_id'=>$data['service_request_public_id']??null,'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'location_public_id'=>$data['location_public_id']??null,'asset_public_id'=>$data['asset_public_id']??null,'service_public_id'=>$data['service_public_id']??null,'title'=>$title,'description'=>$data['description']??null,'status'=>$data['status']??'draft','priority'=>$data['priority']??'normal','owner_user_id'=>$data['owner_user_id']??null,'assigned_user_id'=>$data['assigned_user_id']??null,'scheduled_start'=>$data['scheduled_start']??null,'scheduled_end'=>$data['scheduled_end']??null,'timezone'=>$data['timezone']??config('titan-field.field_services.default_timezone','UTC'),'idempotency_key'=>$idempotencyKey!==''?$idempotencyKey:null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()];
        $this->db->transaction(function() use($row,$userId,$actorUserId,$publicId,$data):void { $this->db->table('crm_work_orders')->insert($row); foreach((array)($data['tasks']??[]) as $i=>$task)$this->addTask($userId,$publicId,['title'=>$task['title']??$task['name']??('Task '.($i+1)),'instructions'=>$task['instructions']??null,'required'=>$task['required']??$task['is_required']??true,'sort_order'=>$task['sort_order']??$i]); $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='work_order.created:'.$publicId;$this->signals->record($userId,$actorUserId,'field.work_order.created','work_order',$publicId,['status'=>$row['status'],'priority'=>$row['priority'],'service_request_public_id'=>$row['service_request_public_id'],'assigned_user_id'=>$row['assigned_user_id']],$ctx); });
        $record=(array)$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first(); $this->audit->record($userId,$actorUserId,'field_service.work_order.created','work_order',$publicId,null,$record); $this->history->record($userId,'work_order',$publicId,'work_order.created','Work order created',$data['description']??null,$record); return $record;
    }

    public function createFromRequest(int $userId,?int $actorUserId,string $requestPublicId,array $overrides=[]): array
    {
        $r=$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$requestPublicId)->whereNull('deleted_at')->first(); if(!$r)throw new InvalidArgumentException('Service request not found.');
        $tasks=[]; if($r->service_public_id){$service=$this->db->table('crm_services')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$r->service_public_id)->whereNull('deleted_at')->first();$tasks=$service&&$service->default_tasks?json_decode((string)$service->default_tasks,true)?:[]:[];}
        return $this->create($userId,$actorUserId,array_merge(['service_request_public_id'=>$r->public_id,'company_public_id'=>$r->company_public_id,'contact_public_id'=>$r->contact_public_id,'location_public_id'=>$r->location_public_id,'asset_public_id'=>$r->asset_public_id,'service_public_id'=>$r->service_public_id,'title'=>$r->title,'description'=>$r->description,'priority'=>$r->priority,'tasks'=>$tasks,'idempotency_key'=>'request:'.$r->public_id],$overrides));
    }

    public function transition(int $userId,?int $actorUserId,string $publicId,string $toStatus,?string $reason=null,?string $evidenceAttachedHash=null): array
    {
        $row=$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first(); if(!$row)throw new InvalidArgumentException('Work order not found.');
        if((string)$row->status===$toStatus)return (array)$row;
        $incompleteTasks=$this->db->table('crm_work_order_tasks')->where('company_id', $this->tenantContext->companyId($userId))->where('work_order_public_id',$publicId)->where('required',true)->whereNull('deleted_at')->whereNotIn('status',['completed','skipped'])->count();
        $incompleteForms=$this->db->table('crm_form_submissions')->where('company_id', $this->tenantContext->companyId($userId))->where('work_order_public_id',$publicId)->whereNull('deleted_at')->whereNotIn('status',['submitted'])->count();
        $this->policy->assertTransition((string)$row->status,$toStatus,$reason,$incompleteTasks,$incompleteForms);
        $completionEvidence=null;if($toStatus==='completed')$completionEvidence=$this->completion->assertCanComplete($userId,$publicId,$evidenceAttachedHash);
        $updates=['status'=>$toStatus,'entity_version'=>((int)($row->entity_version??1))+1,'updated_at'=>now()]; if($toStatus==='in_progress'&&!$row->started_at)$updates['started_at']=now(); if($toStatus==='completed'){$updates['completed_at']=now();$updates['completion_notes']=$reason;$updates['completion_evidence_hash']=$completionEvidence['evidence_attached_hash'];$updates['completion_evidence_snapshot']=json_encode($completionEvidence['snapshot'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);} if($toStatus==='closed')$updates['closed_at']=now();
        $after=$this->db->transaction(function()use($userId,$actorUserId,$publicId,$updates,$row,$toStatus,$reason,$completionEvidence):array{
            $this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->update($updates);
            $after=(array)$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $this->signals->record($userId,$actorUserId,'field.work_order.status_changed','work_order',$publicId,['from'=>(string)$row->status,'to'=>$toStatus,'reason'=>$reason,'completion_evidence_hash'=>$completionEvidence['evidence_attached_hash']??null],['idempotency_key'=>hash('sha256','work_order.status|'.$publicId.'|'.$row->status.'|'.$toStatus.'|'.(string)($row->updated_at??''))]);
            if($toStatus==='completed')$this->signals->record($userId,$actorUserId,'field.work_order.completed','work_order',$publicId,['completion_evidence_hash'=>$after['completion_evidence_hash']??null,'contact_public_id'=>$after['contact_public_id']??null,'location_public_id'=>$after['location_public_id']??null,'service_public_id'=>$after['service_public_id']??null],['idempotency_key'=>'work_order.completed:'.$publicId]);
            return $after;
        });
        $this->audit->record($userId,$actorUserId,'field_service.work_order.status_changed','work_order',$publicId,(array)$row,$after,['reason'=>$reason,'completion_evidence_hash'=>$after['completion_evidence_hash']??null]); $this->history->record($userId,'work_order',$publicId,'work_order.status_changed','Work order '.$toStatus,$reason,$after); if($toStatus==='completed')$this->automation->trigger($userId,'work_order.completed',['subject_type'=>'work_order','subject_public_id'=>$publicId,'contact_public_id'=>$after['contact_public_id']??null,'location_public_id'=>$after['location_public_id']??null,'service_public_id'=>$after['service_public_id']??null,'idempotency_key'=>'work_order.completed:'.$publicId]); return $after;
    }

    public function addTask(int $userId,string $workOrderPublicId,array $data): array
    { if(!$this->owns($userId,$workOrderPublicId))throw new InvalidArgumentException('Work order not found.');$title=trim((string)($data['title']??''));if($title==='')throw new InvalidArgumentException('Task title is required.');$publicId=(string)Str::ulid();$this->db->table('crm_work_order_tasks')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'title'=>$title,'instructions'=>$data['instructions']??null,'required'=>(bool)($data['required']??true),'status'=>'pending','sort_order'=>(int)($data['sort_order']??0),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return (array)$this->db->table('crm_work_order_tasks')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first(); }
    public function setTaskStatus(int $userId,string $taskPublicId,string $status,?string $reason=null,?int $actorUserId=null): array
    {
        if(!in_array($status,['pending','in_progress','completed','skipped'],true))throw new InvalidArgumentException('Invalid task status.');
        if($status==='skipped'&&trim((string)$reason)==='')throw new InvalidArgumentException('A skip reason is required.');
        $tenant=$this->tenantContext->companyId($userId);$q=$this->db->table('crm_work_order_tasks')->where('company_id',$tenant)->where('public_id',$taskPublicId)->whereNull('deleted_at');$row=$q->first();if(!$row)throw new InvalidArgumentException('Work-order task not found.');
        if((string)$row->status===$status)return (array)$row;
        $after=$this->db->transaction(function()use($q,$row,$status,$reason,$actorUserId,$userId,$taskPublicId):array{
            $q->update(['status'=>$status,'skip_reason'=>$status==='skipped'?$reason:null,'completed_by_user_id'=>in_array($status,['completed','skipped'],true)?$actorUserId:null,'completed_at'=>in_array($status,['completed','skipped'],true)?now():null,'entity_version'=>((int)($row->entity_version??1))+1,'updated_at'=>now()]);
            $after=(array)$q->first();
            $this->signals->record($userId,$actorUserId,'field.work_order.task_status_changed','work_order_task',$taskPublicId,['work_order_public_id'=>$row->work_order_public_id,'from'=>(string)$row->status,'to'=>$status,'reason'=>$reason],['idempotency_key'=>hash('sha256','work_order.task|'.$taskPublicId.'|'.$row->status.'|'.$status.'|'.(string)($row->updated_at??''))]);
            return $after;
        });
        $this->audit->record($userId,$actorUserId,'field_service.work_order.task_status_changed','work_order_task',$taskPublicId,(array)$row,$after,['reason'=>$reason]);
        return $after;
    }
    public function addTimeEntry(int $userId,string $workOrderPublicId,int $workerUserId,array $data): array
    { if(!$this->owns($userId,$workOrderPublicId))throw new InvalidArgumentException('Work order not found.');$this->integrity->assertWorker($userId,$workerUserId);$idk=trim((string)($data['idempotency_key']??''));if($idk!==''&&($e=$this->db->table('crm_work_order_time_entries')->where('company_id', $this->tenantContext->companyId($userId))->where('idempotency_key',$idk)->first()))return (array)$e;$publicId=(string)Str::ulid();$this->db->table('crm_work_order_time_entries')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'worker_user_id'=>$workerUserId,'started_at'=>$data['started_at']??now(),'ended_at'=>$data['ended_at']??null,'minutes'=>$data['minutes']??null,'notes'=>$data['notes']??null,'source'=>$data['source']??'manual','billable'=>(bool)($data['billable']??true),'hourly_sale_rate_minor'=>$data['hourly_sale_rate_minor']??null,'idempotency_key'=>$idk!==''?$idk:null,'created_at'=>now(),'updated_at'=>now()]);return (array)$this->db->table('crm_work_order_time_entries')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first(); }
    public function addMaterial(int $userId,string $workOrderPublicId,array $data): array
    { if(!$this->owns($userId,$workOrderPublicId))throw new InvalidArgumentException('Work order not found.');$name=trim((string)($data['name']??''));if($name==='')throw new InvalidArgumentException('Material name is required.');$publicId=(string)Str::ulid();$this->db->table('crm_work_order_materials')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'name'=>$name,'sku'=>$data['sku']??null,'quantity'=>$data['quantity']??1,'unit'=>$data['unit']??null,'unit_cost_minor'=>$data['unit_cost_minor']??null,'unit_sale_price_minor'=>$data['unit_sale_price_minor']??null,'billable'=>(bool)($data['billable']??true),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return (array)$this->db->table('crm_work_order_materials')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first(); }
    public function recordTime(int $userId,string $workOrderPublicId,int $workerUserId,array $data): array
    { return $this->addTimeEntry($userId,$workOrderPublicId,$workerUserId,$data); }

    public function addNote(int $userId,string $workOrderPublicId,string $body,?int $actorUserId=null,?string $fingerprint=null): array
    { if(!$this->owns($userId,$workOrderPublicId))throw new InvalidArgumentException('Work order not found.');$text=trim($body);if($text==='')throw new InvalidArgumentException('Work-order note cannot be empty.');$work=$this->db->table('crm_work_orders')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$workOrderPublicId)->first();return $this->history->record($userId,'work_order',$workOrderPublicId,'work_order.note','Field note',$text,['contact_public_id'=>$work->contact_public_id??null,'company_public_id'=>$work->company_public_id??null,'location_public_id'=>$work->location_public_id??null,'actor_user_id'=>$actorUserId,'fingerprint'=>$fingerprint]); }

    /** @return array<string,mixed> */
    public function detail(int $userId,string $publicId): array
    {
        $work=$this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$work)throw new InvalidArgumentException('Work order not found.');
        $list=fn(string $table)=>$this->db->table($table)->where('company_id', $this->tenantContext->companyId($userId))->where('work_order_public_id',$publicId)->when(in_array($table,['crm_work_order_tasks','crm_work_order_services','crm_field_evidence','crm_form_submissions'],true),fn($q)=>$q->whereNull('deleted_at'))->orderBy('id')->get()->map(fn($r)=>(array)$r)->all();
        $dispatch=$this->db->table('crm_dispatch_assignments')->where('company_id', $this->tenantContext->companyId($userId))->where('work_order_public_id',$publicId)->whereNull('deleted_at')->orderByDesc('id')->get()->map(fn($r)=>(array)$r)->all();
        $appointments=$this->db->table('crm_appointments')->where('company_id', $this->tenantContext->companyId($userId))->where('work_order_public_id',$publicId)->whereNull('deleted_at')->orderBy('scheduled_start')->get()->map(fn($r)=>(array)$r)->all();
        $forms=$this->db->table('crm_form_templates')->where('company_id', $this->tenantContext->companyId($userId))->where('status','published')->where('applies_to','work_order')->whereNull('deleted_at')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();
        return [
            'work_order'=>(array)$work,
            'tasks'=>$list('crm_work_order_tasks'),
            'services'=>$list('crm_work_order_services'),
            'time_entries'=>$list('crm_work_order_time_entries'),
            'materials'=>$list('crm_work_order_materials'),
            'evidence'=>$list('crm_field_evidence'),
            'form_submissions'=>$list('crm_form_submissions'),
            'available_forms'=>$forms,
            'dispatch'=>$dispatch,
            'appointments'=>$appointments,
        ];
    }

    private function owns(int $userId,string $publicId): bool { return $this->db->table('crm_work_orders')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->exists(); }
}
