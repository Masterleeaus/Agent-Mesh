<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Navigation;

/**
 * Titan Field reuses the CRM field/home-service navigation identities and named
 * routes that existed before domain extraction. Existing rows are adopted by
 * route by TitanFieldMenuInstaller, so upgrades preserve historical host keys.
 */
final class TitanFieldMenuDefinition
{
    /** @return array<int,array<string,mixed>> */
    public static function all(): array
    {
        return [
            [
                'key' => 'ext_crm_dropdown',
                'label' => 'Customers',
                'route' => 'dashboard.user.crm.companies.index',
                'icon' => 'tabler-users',
                'order' => 2,
                'preserve_existing_parent' => true,
                'children' => [
                    ['key' => 'crm_support', 'label' => 'Support', 'route' => 'dashboard.user.crm.field-services.support', 'icon' => 'tabler-message', 'order' => 40],
                    ['key' => 'crm_reviews', 'label' => 'Reviews and Recovery', 'route' => 'dashboard.user.crm.field-services.reviews', 'icon' => 'tabler-user-check', 'order' => 50],
                ],
            ],
            [
                'key' => 'ext_crm_work',
                'label' => 'Work',
                'route' => 'dashboard.user.crm.field-services.index',
                'icon' => 'tabler-briefcase',
                'order' => 4,
                'preserve_existing_parent' => false,
                'children' => [
                    ['key' => 'crm_field_overview', 'label' => 'Work Overview', 'route' => 'dashboard.user.crm.field-services.index', 'icon' => 'tabler-layout-dashboard', 'order' => 1],
                    ['key' => 'crm_service_requests', 'label' => 'Service Requests', 'route' => 'dashboard.user.crm.field-services.requests', 'icon' => 'tabler-inbox', 'order' => 2],
                    ['key' => 'crm_work_orders', 'label' => 'Jobs', 'route' => 'dashboard.user.crm.field-services.work-orders', 'icon' => 'tabler-briefcase', 'order' => 3],
                    ['key' => 'crm_agreements', 'label' => 'Recurring Work', 'route' => 'dashboard.user.crm.field-services.agreements', 'icon' => 'tabler-calendar', 'order' => 4],
                    ['key' => 'crm_catalogue', 'label' => 'Services and Catalogue', 'route' => 'dashboard.user.crm.field-services.catalogue', 'icon' => 'tabler-category', 'order' => 20],
                    ['key' => 'crm_service_locations', 'label' => 'Service Locations', 'route' => 'dashboard.user.crm.field-services.locations', 'icon' => 'tabler-building', 'order' => 21],
                    ['key' => 'crm_forms', 'label' => 'Forms', 'route' => 'dashboard.user.crm.field-services.forms', 'icon' => 'tabler-checklist', 'order' => 22],
                    ['key' => 'crm_service_areas', 'label' => 'Service Areas', 'route' => 'dashboard.user.crm.field-services.service-areas', 'icon' => 'tabler-world', 'order' => 23],
                    ['key' => 'crm_verticals', 'label' => 'Vertical Profiles', 'route' => 'dashboard.user.crm.field-services.verticals', 'icon' => 'tabler-components', 'order' => 24],
                ],
            ],
            [
                'key' => 'ext_crm_crew',
                'label' => 'Crew',
                'route' => 'dashboard.user.crm.field-services.schedule',
                'icon' => 'tabler-users-group',
                'order' => 6,
                'preserve_existing_parent' => true,
                'children' => [
                    ['key' => 'titan_field_control', 'label' => 'Field Control', 'route' => 'dashboard.user.crm.field-services.control', 'icon' => 'tabler-layout-dashboard', 'order' => 1],
                    ['key' => 'titan_field_capacity', 'label' => 'Capacity Forecast', 'route' => 'dashboard.user.crm.field-services.capacity', 'icon' => 'tabler-chart-line', 'order' => 2],
                    ['key' => 'crm_schedule', 'label' => 'Schedule', 'route' => 'dashboard.user.crm.field-services.schedule', 'icon' => 'tabler-calendar', 'order' => 3],
                    ['key' => 'crm_dispatch', 'label' => 'Dispatch', 'route' => 'dashboard.user.crm.field-services.dispatch', 'icon' => 'tabler-directions', 'order' => 4],
                    ['key' => 'titan_field_exceptions', 'label' => 'Operational Exceptions', 'route' => 'dashboard.user.crm.field-services.exceptions', 'icon' => 'tabler-alert-triangle', 'order' => 5],
                    ['key' => 'titan_field_routes', 'label' => 'Routes and Live Position', 'route' => 'dashboard.user.crm.field-services.routes', 'icon' => 'tabler-route', 'order' => 6],
                    ['key' => 'crm_timesheets', 'label' => 'Timesheets', 'route' => 'dashboard.user.crm.field-services.timesheets', 'icon' => 'tabler-checklist', 'order' => 7],
                ],
            ],
            [
                'key' => 'ext_crm_gear',
                'label' => 'Gear',
                'route' => 'dashboard.user.crm.field-services.assets',
                'icon' => 'tabler-tool',
                'order' => 7,
                'preserve_existing_parent' => true,
                'children' => [
                    ['key' => 'crm_customer_assets', 'label' => 'Customer Assets', 'route' => 'dashboard.user.crm.field-services.assets', 'icon' => 'tabler-tool', 'order' => 90],
                ],
            ],
        ];
    }

    /** @return list<string> */
    public static function canonicalRoutes(): array
    {
        $routes = [];
        foreach (self::all() as $root) {
            foreach ($root['children'] ?? [] as $child) {
                $routes[] = (string) $child['route'];
            }
        }
        return array_values(array_unique($routes));
    }
}
