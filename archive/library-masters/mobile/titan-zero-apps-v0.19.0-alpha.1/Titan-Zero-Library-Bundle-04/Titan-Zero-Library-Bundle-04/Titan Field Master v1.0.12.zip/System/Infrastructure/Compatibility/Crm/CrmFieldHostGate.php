<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm;

use App\Extensions\Crm\System\Http\Middleware\EnsureCrmHostEnabled;
use App\Extensions\TitanField\System\Contracts\FieldHostGate;
use Closure;
use Illuminate\Http\Request;

final class CrmFieldHostGate implements FieldHostGate
{
    public function __construct(private EnsureCrmHostEnabled $middleware) {}

    public function handle(Request $request, Closure $next): mixed
    {
        return $this->middleware->handle($request, $next);
    }
}
