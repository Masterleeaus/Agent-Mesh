<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\Crm\System\Tenancy\CrmCompanyContextResolver;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;

final class CrmFieldTenantContext implements FieldTenantContext
{
    public function __construct(private CrmCompanyContextResolver $resolver) {}
    public function companyId(int $userId): int
    {
        return CrmCompanyScope::companyId($userId);
    }

    public function actorUserId(int $userId): ?int
    {
        return CrmCompanyScope::actorUserId($userId);
    }

    public function userBelongsToTenant(int $userId,int $candidateUserId): bool
    {
        if($candidateUserId<=0)return false;
        return $this->resolver->actorBelongsToCompany($candidateUserId,$this->companyId($userId));
    }
}
