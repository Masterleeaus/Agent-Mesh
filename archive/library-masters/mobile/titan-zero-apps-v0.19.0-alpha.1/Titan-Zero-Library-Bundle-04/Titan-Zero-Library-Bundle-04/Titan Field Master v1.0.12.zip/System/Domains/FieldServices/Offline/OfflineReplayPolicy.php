<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Offline;

use DateTimeImmutable;
use InvalidArgumentException;
use RuntimeException;

final class OfflineReplayPolicy
{
    public const VERSION_CONFLICT = 'OFFLINE_CONFLICT_ENTITY_VERSION';

    public function __construct(
        private readonly int $maximumOfflineAgeDays = 14,
        private readonly int $maximumBatchSize = 100,
        private readonly int $maximumFutureSkewSeconds = 300,
    ) {}

    /** @return array<string,mixed> */
    public function validateEnvelope(array $envelope): array
    {
        $deviceId = trim((string)($envelope['device_id'] ?? ''));
        $operationId = trim((string)($envelope['operation_id'] ?? ''));
        $operation = trim((string)($envelope['operation'] ?? ''));
        $occurredAt = trim((string)($envelope['occurred_at'] ?? ''));
        if ($deviceId === '' || strlen($deviceId) > 191) throw new InvalidArgumentException('Offline device_id is required and must be at most 191 characters.');
        if ($operationId === '' || strlen($operationId) > 191) throw new InvalidArgumentException('Offline operation_id is required and must be at most 191 characters.');
        if ($operation === '' || strlen($operation) > 120) throw new InvalidArgumentException('Offline operation is required.');
        if ($occurredAt === '') throw new InvalidArgumentException('Offline occurred_at is required.');
        try { $occurred = new DateTimeImmutable($occurredAt); } catch (\Throwable) { throw new InvalidArgumentException('Offline occurred_at is invalid.'); }
        $now = new DateTimeImmutable('now');
        if ($occurred->getTimestamp() > $now->getTimestamp() + $this->maximumFutureSkewSeconds) throw new InvalidArgumentException('Offline occurred_at is too far in the future.');
        if ($occurred->getTimestamp() < $now->modify('-'.$this->maximumOfflineAgeDays.' days')->getTimestamp()) throw new InvalidArgumentException('Offline operation is older than maximum_offline_age_days.');
        $base = $envelope['base_entity_version'] ?? null;
        if ($base !== null && (! is_numeric($base) || (int)$base < 1)) throw new InvalidArgumentException('base_entity_version must be a positive integer when supplied.');
        $entityType = trim((string)($envelope['entity_type'] ?? ''));
        $entityPublicId = trim((string)($envelope['entity_public_id'] ?? ''));
        if (($entityType === '') !== ($entityPublicId === '')) throw new InvalidArgumentException('entity_type and entity_public_id must be supplied together.');
        return $envelope + [
            'device_id'=>$deviceId,'operation_id'=>$operationId,'operation'=>$operation,'occurred_at'=>$occurred->format(DATE_ATOM),
            'base_entity_version'=>$base === null ? null : (int)$base,'entity_type'=>$entityType,'entity_public_id'=>$entityPublicId,
        ];
    }

    public function assertEntityVersion(?int $currentVersion, ?int $baseEntityVersion): void
    {
        if ($baseEntityVersion === null || $currentVersion === null) return;
        if ($currentVersion !== $baseEntityVersion) {
            throw new RuntimeException(self::VERSION_CONFLICT.': current='.$currentVersion.' base='.$baseEntityVersion);
        }
    }

    public function maximumBatchSize(): int { return max(1, min(250, $this->maximumBatchSize)); }
    public function maximumOfflineAgeDays(): int { return max(1, min(90, $this->maximumOfflineAgeDays)); }
}
