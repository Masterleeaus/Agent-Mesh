<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldCommandRouter
{
    /** @param array<string,mixed> $input @param array<string,mixed> $context */
    public function dispatch(
        int $userId,
        ?int $actorUserId,
        string $canonicalCapability,
        string $operation,
        array $input,
        array $context = [],
    ): mixed;

    /** @param array<string,mixed> $input @param array<string,mixed> $context */
    public function compensate(
        int $userId,
        ?int $actorUserId,
        string $canonicalCapability,
        string $operation,
        array $input,
        array $context,
        mixed $result,
        \Throwable $failure,
    ): void;
}
