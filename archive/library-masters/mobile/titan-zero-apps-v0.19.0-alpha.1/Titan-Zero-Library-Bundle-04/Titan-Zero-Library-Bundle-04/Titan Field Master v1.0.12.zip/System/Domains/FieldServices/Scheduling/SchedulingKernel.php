<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use App\Extensions\TitanField\System\Domains\FieldServices\ServiceAreas\ServiceAreaMatcher;
use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/** Canonical field scheduling validator shared by appointment + dispatch writes. */
final class SchedulingKernel
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private FieldReferenceIntegrity $integrity,
        private WorkerAvailabilityPolicy $availabilityPolicy,
        private OperationalBlackoutPolicy $blackoutPolicy,
        private ServiceAreaMatcher $serviceAreas,
    ) {}

    /**
     * @return array<string,mixed>
     */
    public function assertSchedulable(int $userId, ?int $workerUserId, mixed $start, mixed $end, array $context=[]): array
    {
        if (!$workerUserId || $workerUserId <= 0) {
            return ['worker_user_id'=>0,'start'=>(string)$start,'end'=>(string)$end,'duration_minutes'=>0,'max_daily_minutes'=>0,'travel_buffer_minutes'=>0,'required_skills'=>[]];
        }

        $this->integrity->assertWorker($userId,$workerUserId);
        $tenant=$this->tenantContext->companyId($userId);
        $from=CarbonImmutable::parse($start)->utc();
        $to=CarbonImmutable::parse($end)->utc();
        if ($to->lessThanOrEqualTo($from)) throw new InvalidArgumentException('Scheduling end time must be after its start time.');

        $profile=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('worker_user_id',$workerUserId)->first();
        if ($profile && !(bool)$profile->active) throw new InvalidArgumentException('Assigned worker is not active for field scheduling.');

        $timezone=(string)($profile->timezone??config('titan-field.field_services.default_timezone','Australia/Melbourne'));
        $maxDaily=max(1,(int)($profile->max_daily_minutes??config('titan-field.field_services.scheduling.max_daily_minutes',720)));
        $travelBuffer=max(0,(int)($context['travel_buffer_minutes']??$profile->travel_buffer_minutes??config('titan-field.field_services.scheduling.default_travel_buffer_minutes',0)));

        $context=$this->enrichLocationContext($tenant,$context);
        $normalizedAvailability=$this->availabilityPolicy->assertAvailable($tenant,$workerUserId,$from,$to,$timezone);
        $this->blackoutPolicy->assertNotBlocked($tenant,$workerUserId,$from,$to,$context);
        $requiredSkills=$this->requiredSkills($tenant,(string)($context['service_public_id']??''));
        $this->assertSkills($profile,$requiredSkills);
        if(!$normalizedAvailability)$this->assertWeeklyAvailability($profile,$from,$to,$timezone);
        $this->assertNoOverlap($tenant,$workerUserId,$from,$to,$travelBuffer,(string)($context['work_order_public_id']??''),(string)($context['appointment_public_id']??''));
        $dailyLoad=$this->assertDailyMinutes($tenant,$workerUserId,$from,$to,$maxDaily,$timezone,(string)($context['work_order_public_id']??''),(string)($context['appointment_public_id']??''));
        $areaMatches=$this->assertServiceArea($userId,$tenant,$context);

        return [
            'worker_user_id'=>$workerUserId,
            'start'=>$from->toIso8601String(),
            'end'=>$to->toIso8601String(),
            'duration_minutes'=>$from->diffInMinutes($to),
            'max_daily_minutes'=>$maxDaily,
            'travel_buffer_minutes'=>$travelBuffer,
            'required_skills'=>$requiredSkills,
            'daily_load_minutes'=>$dailyLoad,
            'remaining_daily_minutes'=>max(0,$maxDaily-$dailyLoad),
            'service_area_matches'=>$areaMatches,
            'service_area_public_id'=>$context['service_area_public_id']??null,
            'location_public_id'=>$context['location_public_id']??null,
            'postcode'=>$context['postcode']??null,
            'latitude'=>$context['latitude']??null,
            'longitude'=>$context['longitude']??null,
        ];
    }

    private function assertNoTimeOff(int $tenant,int $worker,CarbonImmutable $from,CarbonImmutable $to): void
    {
        $blocked=$this->db->table('crm_field_worker_time_off')->where('company_id',$tenant)->where('worker_user_id',$worker)
            ->where('status','approved')->where('starts_at','<',$to)->where('ends_at','>',$from)->exists();
        if($blocked)throw new InvalidArgumentException('Assigned worker is unavailable during the requested schedule window.');
    }

    /** @return array<int,string> */
    private function requiredSkills(int $tenant,string $servicePublicId): array
    {
        if($servicePublicId==='')return [];
        $raw=$this->db->table('crm_services')->where('company_id',$tenant)->where('public_id',$servicePublicId)->whereNull('deleted_at')->value('required_skills');
        $decoded=$this->decodeList($raw);
        return array_values(array_unique(array_filter(array_map(fn($v)=>strtolower(trim((string)$v)),$decoded))));
    }

    /** @param array<int,string> $requiredSkills */
    private function assertSkills(?object $profile,array $requiredSkills): void
    {
        if($requiredSkills===[])return;
        $owned=array_values(array_unique(array_map(fn($v)=>strtolower(trim((string)$v)),$this->decodeList($profile->skills??null))));
        $missing=array_values(array_diff($requiredSkills,$owned));
        if($missing!==[])throw new InvalidArgumentException('Assigned worker is missing required skills: '.implode(', ',$missing).'.');
    }

    private function assertWeeklyAvailability(?object $profile,CarbonImmutable $from,CarbonImmutable $to,string $timezone): void
    {
        $availability=$this->decodeAssoc($profile->weekly_availability??null);
        if($availability===[])return;
        $localStart=$from->setTimezone($timezone);$localEnd=$to->setTimezone($timezone);
        if($localStart->toDateString()!==$localEnd->toDateString())throw new InvalidArgumentException('Requested schedule crosses a worker availability day boundary.');
        $keys=[strtolower($localStart->format('D')),(string)$localStart->dayOfWeek,(string)$localStart->isoWeekday()];
        $windows=[];foreach($keys as $key){if(isset($availability[$key])){$windows=(array)$availability[$key];break;}}
        if($windows===[])throw new InvalidArgumentException('Assigned worker is unavailable on the requested day.');
        foreach($windows as $window){
            $w=(array)$window;$open=(string)($w['start']??$w['opens_at']??'');$close=(string)($w['end']??$w['closes_at']??'');
            if($open===''||$close==='')continue;
            $windowStart=$localStart->startOfDay()->setTimeFromTimeString($open);$windowEnd=$localStart->startOfDay()->setTimeFromTimeString($close);
            if($localStart->greaterThanOrEqualTo($windowStart)&&$localEnd->lessThanOrEqualTo($windowEnd))return;
        }
        throw new InvalidArgumentException('Requested schedule is outside the worker weekly availability window.');
    }

    private function assertNoOverlap(int $tenant,int $worker,CarbonImmutable $from,CarbonImmutable $to,int $buffer,string $workOrderPublicId,string $appointmentPublicId): void
    {
        $paddedFrom=$from->subMinutes($buffer);$paddedTo=$to->addMinutes($buffer);
        $q=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')
            ->whereNotIn('status',['cancelled','completed'])->where('scheduled_start','<',$paddedTo)->where('scheduled_end','>',$paddedFrom);
        if($workOrderPublicId!=='')$q->where(function($x)use($workOrderPublicId){$x->whereNull('work_order_public_id')->orWhere('work_order_public_id','<>',$workOrderPublicId);});
        if($appointmentPublicId!=='')$q->where('public_id','<>',$appointmentPublicId);
        if($q->exists())throw new InvalidArgumentException($buffer>0?'Assigned worker does not have sufficient travel buffer between appointments.':'Assigned worker already has an overlapping appointment.');
    }

    private function assertDailyMinutes(int $tenant,int $worker,CarbonImmutable $from,CarbonImmutable $to,int $maxDaily,string $timezone,string $workOrderPublicId,string $appointmentPublicId): int
    {
        $local=$from->setTimezone($timezone);$dayStart=$local->startOfDay()->utc();$dayEnd=$local->endOfDay()->utc();
        $q=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')
            ->whereNotIn('status',['cancelled'])->where('scheduled_start','<',$dayEnd)->where('scheduled_end','>',$dayStart);
        if($workOrderPublicId!=='')$q->where(function($x)use($workOrderPublicId){$x->whereNull('work_order_public_id')->orWhere('work_order_public_id','<>',$workOrderPublicId);});
        if($appointmentPublicId!=='')$q->where('public_id','<>',$appointmentPublicId);
        $minutes=0;foreach($q->get(['scheduled_start','scheduled_end']) as $row){$s=CarbonImmutable::parse($row->scheduled_start);$e=CarbonImmutable::parse($row->scheduled_end);$minutes+=$s->diffInMinutes($e);}
        $minutes+=$from->diffInMinutes($to);
        if($minutes>$maxDaily)throw new InvalidArgumentException("Assigned worker would exceed the {$maxDaily}-minute daily scheduling limit.");
        return $minutes;
    }

    /** @return list<string> */
    private function assertServiceArea(int $userId,int $tenant,array $context): array
    {
        $service=(string)($context['service_public_id']??'');
        $q=$this->db->table('crm_service_areas')->where('company_id',$tenant)->where('active',true)->whereNull('deleted_at');
        $areas=$q->get(['public_id','service_public_ids']);
        $applicable=[];
        foreach($areas as $area){$services=$this->decodeList($area->service_public_ids??null);if($service===''||$services===[]||in_array($service,array_map('strval',$services),true))$applicable[]=(string)$area->public_id;}
        if($applicable===[])return [];
        $postcode=isset($context['postcode'])?(string)$context['postcode']:null;
        $lat=isset($context['latitude'])&&$context['latitude']!==null?(float)$context['latitude']:null;
        $lon=isset($context['longitude'])&&$context['longitude']!==null?(float)$context['longitude']:null;
        if($postcode===null&&$lat===null&&$lon===null)return [];
        $matches=$this->serviceAreas->match($userId,$postcode,$lat,$lon,$service!==''?$service:null);
        $ids=array_values(array_map(static fn(array $row):string=>(string)$row['public_id'],$matches));
        if($ids===[])throw new InvalidArgumentException('Requested schedule is outside configured service areas.');
        return $ids;
    }

    /** @return array<string,mixed> */
    private function enrichLocationContext(int $tenant,array $context): array
    {
        $locationId=(string)($context['location_public_id']??'');
        if($locationId==='')return $context;
        $location=$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$locationId)->whereNull('deleted_at')->first();
        if(!$location)return $context;
        foreach(['service_area_public_id','postcode','latitude','longitude','company_public_id','contact_public_id'] as $field){if(!array_key_exists($field,$context)||$context[$field]===null||$context[$field]==='')$context[$field]=$location->{$field}??null;}
        return $context;
    }

    /** @return array<int,mixed> */
    private function decodeList(mixed $value): array
    {
        if(is_array($value))return array_is_list($value)?$value:array_keys(array_filter($value));
        if(!is_string($value)||trim($value)==='')return [];
        $decoded=json_decode($value,true);if(!is_array($decoded))return [];
        return array_is_list($decoded)?$decoded:array_keys(array_filter($decoded));
    }

    /** @return array<string,mixed> */
    private function decodeAssoc(mixed $value): array
    {
        if(is_array($value))return $value;
        if(!is_string($value)||trim($value)==='')return [];
        $decoded=json_decode($value,true);return is_array($decoded)?$decoded:[];
    }
}
