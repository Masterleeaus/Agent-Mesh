<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

/** Normalized availability policy; returns false when legacy JSON fallback should be used. */
final class WorkerAvailabilityPolicy
{
    public function __construct(private ConnectionInterface $db) {}

    public function assertAvailable(int $tenant, int $worker, CarbonImmutable $from, CarbonImmutable $to, string $timezone): bool
    {
        $blocked=$this->db->table('crm_field_worker_time_off')->where('company_id',$tenant)->where('worker_user_id',$worker)
            ->where('status','approved')->where('starts_at','<',$to)->where('ends_at','>',$from)->exists();
        if($blocked)throw new InvalidArgumentException('Assigned worker has approved time off during the requested schedule window.');

        if (!Schema::hasTable('titan_field_worker_availability_rules') || !Schema::hasTable('titan_field_worker_availability_exceptions')) return false;
        $exception=$this->db->table('titan_field_worker_availability_exceptions')->where('company_id',$tenant)->where('worker_user_id',$worker)
            ->where('status','approved')->where('starts_at','<',$to)->where('ends_at','>',$from)->first();
        if($exception)throw new InvalidArgumentException('Assigned worker has an approved availability exception during the requested schedule window'.($exception->reason?': '.$exception->reason:'').'.');

        $hasRules=$this->db->table('titan_field_worker_availability_rules')->where('company_id',$tenant)->where('worker_user_id',$worker)->where('active',true)->exists();
        if(!$hasRules)return false;
        $localStart=$from->setTimezone($timezone);$localEnd=$to->setTimezone($timezone);
        if($localStart->toDateString()!==$localEnd->toDateString())throw new InvalidArgumentException('Requested schedule crosses a normalized availability day boundary.');
        $date=$localStart->toDateString();$dow=$localStart->isoWeekday();
        $rules=$this->db->table('titan_field_worker_availability_rules')->where('company_id',$tenant)->where('worker_user_id',$worker)
            ->where('active',true)->where('day_of_week',$dow)
            ->where(function($q)use($date){$q->whereNull('effective_from')->orWhere('effective_from','<=',$date);})
            ->where(function($q)use($date){$q->whereNull('effective_until')->orWhere('effective_until','>=',$date);})
            ->get();
        foreach($rules as $rule){
            $open=$localStart->startOfDay()->setTimeFromTimeString((string)$rule->starts_at);
            $close=$localStart->startOfDay()->setTimeFromTimeString((string)$rule->ends_at);
            if($localStart->greaterThanOrEqualTo($open)&&$localEnd->lessThanOrEqualTo($close))return true;
        }
        throw new InvalidArgumentException('Requested schedule is outside normalized worker availability.');
    }
}
