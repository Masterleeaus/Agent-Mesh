<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Spatial;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Illuminate\Contracts\Container\Container;
use Throwable;

/** Resolves Titan Maps lazily by string contract; Field has no compile-time Maps dependency. */
final class OptionalTitanMapsSpatialIntelligenceGateway implements SpatialIntelligenceGateway
{
    private const MAPS_PEER='App\\Extensions\\TitanMapsIntelligence\\Contracts\\FieldSpatialPeerGateway';
    public function __construct(private Container $app, private FieldTenantContext $tenantContext, private FallbackSpatialIntelligenceGateway $fallback) {}
    public function peerAvailable(): bool { return interface_exists(self::MAPS_PEER) && $this->app->bound(self::MAPS_PEER); }
    private function company(int $userId): string { return (string)$this->tenantContext->companyId($userId); }
    private function peer(): object { return $this->app->make(self::MAPS_PEER); }

    public function available(int $userId): bool { if(!$this->peerAvailable())return false;try{return (bool)$this->peer()->healthy($this->company($userId));}catch(Throwable){return false;} }
    public function latestWorkerPositions(int $userId,array $workerUserIds=[]):array{if(!$this->available($userId))return $this->fallback->latestWorkerPositions($userId,$workerUserIds);try{return (array)$this->peer()->latestWorkerPositions($this->company($userId),$workerUserIds);}catch(Throwable){return $this->fallback->latestWorkerPositions($userId,$workerUserIds);}}
    public function estimateTravel(int $userId,array $origin,array $destination,array $context=[]):array{if(!$this->available($userId))return $this->fallback->estimateTravel($userId,$origin,$destination,$context);try{return (array)$this->peer()->estimateTravel($this->company($userId),$origin,$destination,$context);}catch(Throwable){return $this->fallback->estimateTravel($userId,$origin,$destination,$context);}}
    public function recordWorkerLocation(int $userId,int $workerUserId,array $payload):array{if(!$this->peerAvailable())return $this->fallback->recordWorkerLocation($userId,$workerUserId,$payload);$payload['worker_public_id']=(string)$workerUserId;return (array)$this->peer()->recordWorkerLocation($this->company($userId),(string)$userId,$payload);}
    public function syncOfflineWorkerLocations(int $userId,int $workerUserId,array $samples,array $context=[]):array{if(!$this->peerAvailable())return $this->fallback->syncOfflineWorkerLocations($userId,$workerUserId,$samples,$context);$context['worker_public_id']=(string)$workerUserId;return (array)$this->peer()->syncOfflineWorkerLocations($this->company($userId),(string)$userId,$samples,$context);}
    public function workOrderCostEvidence(int $userId,string $workOrderPublicId,array $context=[]):array{if(!$this->available($userId))return $this->fallback->workOrderCostEvidence($userId,$workOrderPublicId,$context);try{return (array)$this->peer()->workOrderCostEvidence($this->company($userId),$workOrderPublicId,$context);}catch(Throwable){return $this->fallback->workOrderCostEvidence($userId,$workOrderPublicId,$context);}}
    public function capacityPressureEvidence(int $userId,array $context=[]):array{if(!$this->available($userId))return $this->fallback->capacityPressureEvidence($userId,$context);try{return (array)$this->peer()->capacityPressureEvidence($this->company($userId),$context);}catch(Throwable){return $this->fallback->capacityPressureEvidence($userId,$context);}}
    public function routeOptimizationProposal(int $userId,string $routePublicId,array $route,array $stops,array $context=[]):array{if(!$this->available($userId))return $this->fallback->routeOptimizationProposal($userId,$routePublicId,$route,$stops,$context);try{return (array)$this->peer()->routeOptimizationProposal($this->company($userId),$routePublicId,$route,$stops,$context);}catch(Throwable){return $this->fallback->routeOptimizationProposal($userId,$routePublicId,$route,$stops,$context);}}
    public function mapPayload(int $userId,string $page='field.team'):array{if(!$this->available($userId))return $this->fallback->mapPayload($userId,$page);try{return (array)$this->peer()->mapPayload($this->company($userId),$page);}catch(Throwable){return $this->fallback->mapPayload($userId,$page);}}
    public function mapUi(int $userId):array{if(!$this->available($userId))return $this->fallback->mapUi($userId);try{return (array)$this->peer()->mapUi();}catch(Throwable){return ['enabled'=>false,'provider'=>'field-fallback'];}}
}
