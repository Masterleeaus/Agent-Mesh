<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Exceptions;

use InvalidArgumentException;

final class OperationalExceptionPolicy
{
    public const TYPES = [
        'late_worker','no_show','site_inaccessible','missing_evidence',
        'route_disruption','capacity_risk','sla_risk','equipment_unavailable',
    ];
    public const SEVERITIES = ['low','medium','high','critical'];
    public const STATUSES = ['open','acknowledged','assigned','resolved','closed'];

    /** @return array{severity:string,sla_minutes:int} */
    public function defaults(string $type): array
    {
        return match ($type) {
            'sla_risk' => ['severity'=>'critical','sla_minutes'=>15],
            'no_show','route_disruption' => ['severity'=>'high','sla_minutes'=>30],
            'late_worker','site_inaccessible','equipment_unavailable' => ['severity'=>'high','sla_minutes'=>60],
            'missing_evidence','capacity_risk' => ['severity'=>'medium','sla_minutes'=>120],
            default => throw new InvalidArgumentException('Unsupported operational exception type.'),
        };
    }

    public function assertTransition(string $from, string $to): void
    {
        $allowed = [
            'open'=>['acknowledged','assigned','resolved'],
            'acknowledged'=>['assigned','resolved'],
            'assigned'=>['acknowledged','resolved'],
            'resolved'=>['closed','open'],
            'closed'=>[],
        ];
        if (! in_array($to, $allowed[$from] ?? [], true)) {
            throw new InvalidArgumentException("Invalid exception transition {$from} -> {$to}.");
        }
    }
}
