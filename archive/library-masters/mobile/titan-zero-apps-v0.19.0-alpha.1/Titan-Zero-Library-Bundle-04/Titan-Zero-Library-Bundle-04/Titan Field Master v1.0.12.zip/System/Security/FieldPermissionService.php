<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Security;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

final class FieldPermissionService
{
    public function allows(int $userId, string $permission): bool
    {
        if ($userId <= 0) return false;
        $canonical = FieldPermissionCatalog::canonical($permission);
        if ($canonical === null) return false;

        $actorId = Auth::id();
        if ($actorId !== null && (int) $actorId !== $userId) return false;

        $candidates = array_values(array_unique(array_merge([$canonical, $permission], FieldPermissionCatalog::aliasesFor($canonical))));
        foreach ($candidates as $candidate) {
            if (Gate::has($candidate)) return Gate::allows($candidate);
        }

        // Compatibility mode mirrors CRM's historical behaviour: tenant-scoped
        // records are the baseline boundary when the host defines no matching gate.
        // Production hosts can force fail-closed gate registration with this flag.
        return ! (bool) config('titan-field.permissions.strict_host_gates', false);
    }

    public function authorize(int $userId, string $permission): void
    {
        if (! $this->allows($userId, $permission)) {
            throw new AccessDeniedHttpException("Titan Field permission denied: {$permission}");
        }
    }
}
