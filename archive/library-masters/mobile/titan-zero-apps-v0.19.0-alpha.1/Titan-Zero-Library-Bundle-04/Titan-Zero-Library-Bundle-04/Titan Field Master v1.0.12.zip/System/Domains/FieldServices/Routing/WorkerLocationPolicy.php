<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Routing;

use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class WorkerLocationPolicy
{
    public function __construct(private ConnectionInterface $db) {}

    /** @return array{consent_granted_at:string,retention_days:int} */
    public function assertCanRecord(int $tenantId, int $workerUserId, ?string $routePublicId, float $accuracyMeters): array
    {
        if ($accuracyMeters < 0 || $accuracyMeters > 5000) {
            throw new InvalidArgumentException('Location accuracy is outside the accepted operational range.');
        }

        $profile = $this->db->table('crm_field_worker_profiles')
            ->where('company_id', $tenantId)
            ->where('worker_user_id', $workerUserId)
            ->where('active', true)
            ->first();
        if (! $profile) throw new InvalidArgumentException('Worker is not an active Titan Field worker.');

        $metadata = json_decode((string) ($profile->metadata ?? ''), true);
        $metadata = is_array($metadata) ? $metadata : [];
        $consent = (bool) ($metadata['location_tracking_consent'] ?? false);
        $consentGrantedAt = trim((string) ($metadata['location_tracking_consent_granted_at'] ?? ''));
        if (! $consent || $consentGrantedAt === '') {
            throw new InvalidArgumentException('Worker location consent is required before recording live position.');
        }

        $activeRoute = $this->db->table('titan_field_routes')
            ->where('company_id', $tenantId)
            ->where('worker_user_id', $workerUserId)
            ->whereIn('status', ['active','in_progress'])
            ->when($routePublicId, fn($q) => $q->where('public_id', $routePublicId))
            ->whereDate('route_date', now()->toDateString())
            ->exists();
        if (! $activeRoute) {
            throw new InvalidArgumentException('Live location may only be recorded during an active shift route.');
        }

        $retentionDays = max(1, min(30, (int) config('titan-field.field_services.location.retention_days', 7)));
        return ['consent_granted_at' => $consentGrantedAt, 'retention_days' => $retentionDays];
    }
}
