<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Support;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class SupportService
{
    public function __construct(
        private FieldSignalPort $signals,
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private FieldReferenceIntegrity $integrity,
    ) {}

    public function createTicket(int $userId,array $data): array
    {
        $subject=trim((string)($data['subject']??''));
        if($subject==='')throw new InvalidArgumentException('Support subject is required.');
        $this->integrity->assertContext($userId,$data);
        if(array_key_exists('owner_user_id',$data)&&$data['owner_user_id']!==null)$this->integrity->assertTenantUser($userId,(int)$data['owner_user_id']);
        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($userId,$data,$subject,$publicId):array{
            $this->db->table('crm_support_tickets')->insert([
                'public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),
                'contact_public_id'=>$data['contact_public_id']??null,'company_public_id'=>$data['company_public_id']??null,'location_public_id'=>$data['location_public_id']??null,
                'asset_public_id'=>$data['asset_public_id']??null,'service_request_public_id'=>$data['service_request_public_id']??null,'subject'=>$subject,'description'=>$data['description']??null,
                'status'=>'open','priority'=>$data['priority']??'normal','owner_user_id'=>$data['owner_user_id']??null,'source'=>$data['source']??'manual',
                'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()
            ]);
            $record=(array)$this->db->table('crm_support_tickets')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='support.ticket.created:'.$publicId;
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.support.ticket_created','support_ticket',$publicId,['status'=>'open','priority'=>$record['priority']??'normal','service_request_public_id'=>$record['service_request_public_id']??null],$ctx);
            return $record;
        });
    }

    public function addMessage(int $userId,string $ticketPublicId,string $body,string $authorType='staff',?int $authorUserId=null,bool $customerVisible=true): array
    {
        if(trim($body)==='')throw new InvalidArgumentException('Support message cannot be empty.');
        if($authorUserId!==null)$this->integrity->assertTenantUser($userId,$authorUserId);
        $this->integrity->assertContext($userId,['support_ticket_public_id'=>$ticketPublicId]);
        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($userId,$ticketPublicId,$body,$authorType,$authorUserId,$customerVisible,$publicId):array{
            $this->db->table('crm_support_messages')->insert([
                'public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),
                'ticket_public_id'=>$ticketPublicId,'author_type'=>$authorType,'author_user_id'=>$authorUserId,'body'=>$body,'customer_visible'=>$customerVisible,'created_at'=>now(),'updated_at'=>now()
            ]);
            $record=(array)$this->db->table('crm_support_messages')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $this->signals->record($userId,$authorUserId,'field.support.message_added','support_message',$publicId,['ticket_public_id'=>$ticketPublicId,'author_type'=>$authorType,'customer_visible'=>$customerVisible],['idempotency_key'=>'support.message:'.$publicId]);
            return $record;
        });
    }

    public function forContact(int $userId,string $contactPublicId): array
    {
        return $this->db->table('crm_support_tickets')->where('company_id',$this->tenantContext->companyId($userId))->where('contact_public_id',$contactPublicId)->whereNull('deleted_at')->orderByDesc('id')->get()->map(fn($r)=>(array)$r)->all();
    }
}
