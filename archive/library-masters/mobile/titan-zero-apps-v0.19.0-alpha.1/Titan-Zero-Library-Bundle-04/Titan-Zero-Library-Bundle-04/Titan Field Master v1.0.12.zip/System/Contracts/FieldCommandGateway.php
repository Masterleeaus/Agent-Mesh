<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldCommandGateway
{
    /**
     * Execute one consequential Titan Field command through the governed boundary.
     *
     * @param array<string,mixed> $input
     * @param array{source?:string,idempotency_key?:string,trace_id?:string,correlation_id?:string,causation_id?:string,command_id?:string} $context
     * @return array<string,mixed> titan.field.command.receipt.v1
     */
    public function execute(
        int $userId,
        ?int $actorUserId,
        string $capability,
        string $operation,
        array $input = [],
        array $context = [],
    ): array;
}
