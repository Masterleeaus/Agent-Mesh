<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Security;

final class FieldPermissionCatalog
{
    public const ALL = [
        'titan.field.view',
        'titan.field.manage',
        'titan.field.requests.manage',
        'titan.field.work_orders.manage',
        'titan.field.scheduling.manage',
        'titan.field.dispatch.manage',
        'titan.field.exceptions.manage',
        'titan.field.routes.manage',
        'titan.field.recurring.manage',
        'titan.field.forms.manage',
        'titan.field.evidence.manage',
        'titan.field.service_areas.manage',
        'titan.field.support.manage',
        'titan.field.reviews.manage',
    ];

    /** Legacy route/host permissions retained during the CRM -> Titan Field strangler. */
    public const LEGACY_ALIASES = [
        'crm.field_services.view' => 'titan.field.view',
        'crm.field_services.manage' => 'titan.field.manage',
        'crm.service_requests.manage' => 'titan.field.requests.manage',
        'crm.work_orders.manage' => 'titan.field.work_orders.manage',
        'crm.scheduling.manage' => 'titan.field.scheduling.manage',
        'crm.dispatch.manage' => 'titan.field.dispatch.manage',
        'crm.field.exceptions.manage' => 'titan.field.exceptions.manage',
        'crm.field.routes.manage' => 'titan.field.routes.manage',
        'crm.recurring.manage' => 'titan.field.recurring.manage',
        'crm.forms.manage' => 'titan.field.forms.manage',
        'crm.field_evidence.manage' => 'titan.field.evidence.manage',
        'crm.service_areas.manage' => 'titan.field.service_areas.manage',
        'crm.support.manage' => 'titan.field.support.manage',
        'crm.reviews.manage' => 'titan.field.reviews.manage',
    ];

    public static function canonical(string $permission): ?string
    {
        if (in_array($permission, self::ALL, true)) return $permission;
        return self::LEGACY_ALIASES[$permission] ?? null;
    }

    /** @return array<int,string> */
    public static function aliasesFor(string $canonical): array
    {
        $out = [];
        foreach (self::LEGACY_ALIASES as $legacy => $target) if ($target === $canonical) $out[] = $legacy;
        return $out;
    }
}
