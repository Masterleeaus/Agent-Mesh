<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldSignalPort
{
    /**
     * Persist a Titan Signal-compatible envelope on the caller's active database
     * transaction. Implementations must fail closed: a failed outbox write means
     * the authoritative mutation is rolled back by the caller transaction.
     *
     * Context accepts trace_id, correlation_id, causation_id and idempotency_key.
     * Missing trace/correlation/causation identifiers are generated coherently.
     *
     * @param array<string,mixed> $payload
     * @param array{trace_id?:string,correlation_id?:string,causation_id?:string,idempotency_key?:string} $context
     * @return array<string,mixed> structured Titan/Rewind-compatible receipt
     */
    public function record(
        int $userId,
        ?int $actorUserId,
        string $eventName,
        string $subjectType,
        ?string $subjectPublicId,
        array $payload = [],
        array $context = [],
    ): array;
}
