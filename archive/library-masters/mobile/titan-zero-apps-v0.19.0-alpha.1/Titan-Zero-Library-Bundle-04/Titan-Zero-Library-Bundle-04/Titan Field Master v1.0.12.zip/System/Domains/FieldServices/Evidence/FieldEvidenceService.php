<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Evidence;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class FieldEvidenceService
{
    public function __construct(private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private FieldReferenceIntegrity $integrity) {}

    public function store(int $userId,int $actorUserId,UploadedFile $file,array $context): array
    {
        $work=$context['work_order_public_id']??null;
        $submission=$context['form_submission_public_id']??null;
        if(!$work&&!$submission)throw new InvalidArgumentException('Evidence must belong to a work order or form submission.');
        $this->integrity->assertContext($userId,['work_order_public_id'=>$work,'form_submission_public_id'=>$submission]);

        if($work && !$this->db->table('crm_work_orders')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$work)->whereNull('deleted_at')->exists())throw new InvalidArgumentException('Work order not found.');
        if($submission){
            $form=$this->db->table('crm_form_submissions')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$submission)->whereNull('deleted_at')->first();
            if(!$form)throw new InvalidArgumentException('Form submission not found.');
            if($work && $form->work_order_public_id && $form->work_order_public_id!==$work)throw new InvalidArgumentException('Form submission does not belong to this work order.');
            $work=$work ?: $form->work_order_public_id;
        }

        $disk=(string)config('titan-field.field_services.evidence_disk','local');
        $extension=strtolower((string)$file->getClientOriginalExtension());
        $name=(string)Str::ulid().($extension!==''?'.'.$extension:'');
        $path=$file->storeAs('crm-field-evidence/'.$userId,$name,$disk);
        $publicId=(string)Str::ulid();
        try {
            return $this->db->transaction(function()use($userId,$actorUserId,$file,$context,$work,$submission,$disk,$path,$publicId):array{
                $sha256=hash_file('sha256',$file->getRealPath());
                $this->db->table('crm_field_evidence')->insert([
                    'public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),'work_order_public_id'=>$work,'form_submission_public_id'=>$submission,
                    'evidence_type'=>$context['evidence_type']??'photo','disk'=>$disk,'path'=>$path,'original_name'=>$file->getClientOriginalName(),'mime_type'=>$file->getMimeType(),'size_bytes'=>$file->getSize(),'sha256'=>$sha256,
                    'latitude'=>$context['latitude']??null,'longitude'=>$context['longitude']??null,'captured_at'=>$context['captured_at']??now(),'captured_by_user_id'=>$actorUserId,'metadata'=>isset($context['metadata'])?json_encode($context['metadata']):null,'created_at'=>now(),'updated_at'=>now()
                ]);
                $record=(array)$this->db->table('crm_field_evidence')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
                $ctx=is_array($context['signal_context']??null)?$context['signal_context']:[];$ctx['idempotency_key']='evidence.recorded:'.$sha256.':'.$publicId;
                $this->signals->record($userId,$actorUserId,'field.evidence.recorded','field_evidence',$publicId,['work_order_public_id'=>$work,'form_submission_public_id'=>$submission,'evidence_type'=>$record['evidence_type']??'photo','sha256'=>$sha256,'size_bytes'=>$record['size_bytes']??null],$ctx);
                return $record;
            });
        } catch (\Throwable $e) {
            Storage::disk($disk)->delete($path);
            throw $e;
        }
    }

    public function downloadPath(int $userId,string $publicId): array
    {
        $row=$this->db->table('crm_field_evidence')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$row)throw new InvalidArgumentException('Evidence not found.');
        if(!Storage::disk($row->disk)->exists($row->path))throw new InvalidArgumentException('Evidence file is unavailable.');
        return (array)$row;
    }

    public function recordReference(int $userId,int $actorUserId,string $workOrderPublicId,array $data): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $this->integrity->assertContext($userId,['work_order_public_id'=>$workOrderPublicId,'form_submission_public_id'=>$data['form_submission_public_id']??null]);
        $path=trim((string)($data['path']??$data['attachment_path']??''));if($path==='')throw new InvalidArgumentException('Evidence reference path is required.');
        $sha256=strtolower(trim((string)($data['sha256']??'')));if(preg_match('/^[a-f0-9]{64}$/i',$sha256)!==1)throw new InvalidArgumentException('Evidence reference requires a valid SHA-256 content hash.');
        $submission=trim((string)($data['form_submission_public_id']??''));if($submission!=='')$this->assertSubmissionBelongsToWorkOrder($tenant,$submission,$workOrderPublicId);
        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($tenant,$userId,$actorUserId,$workOrderPublicId,$data,$path,$sha256,$submission,$publicId):array{
            $this->db->table('crm_field_evidence')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>$this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'form_submission_public_id'=>$submission!==''?$submission:null,'evidence_type'=>$data['evidence_type']??'photo','disk'=>$data['disk']??'titan_field_offline','path'=>$path,'original_name'=>$data['original_name']??null,'mime_type'=>$data['mime_type']??null,'size_bytes'=>$data['size_bytes']??null,'sha256'=>$sha256,'latitude'=>$data['latitude']??null,'longitude'=>$data['longitude']??null,'captured_at'=>$data['captured_at']??now(),'captured_by_user_id'=>$actorUserId,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
            $record=(array)$this->db->table('crm_field_evidence')->where('company_id',$tenant)->where('public_id',$publicId)->first();
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='evidence.reference:'.$sha256.':'.$publicId;
            $this->signals->record($userId,$actorUserId,'field.evidence.recorded','field_evidence',$publicId,['work_order_public_id'=>$workOrderPublicId,'form_submission_public_id'=>$submission!==''?$submission:null,'evidence_type'=>$record['evidence_type']??'photo','sha256'=>$sha256,'reference'=>true],$ctx);
            return $record;
        });
    }

    private function assertSubmissionBelongsToWorkOrder(int $tenant,string $submissionPublicId,string $workOrderPublicId): void
    {
        $form=$this->db->table('crm_form_submissions')->where('company_id',$tenant)->where('public_id',$submissionPublicId)->whereNull('deleted_at')->first();
        if(!$form)throw new InvalidArgumentException('Form submission not found.');
        if(trim((string)($form->work_order_public_id??''))!==$workOrderPublicId)throw new InvalidArgumentException('Form submission does not belong to this work order.');
    }
}
