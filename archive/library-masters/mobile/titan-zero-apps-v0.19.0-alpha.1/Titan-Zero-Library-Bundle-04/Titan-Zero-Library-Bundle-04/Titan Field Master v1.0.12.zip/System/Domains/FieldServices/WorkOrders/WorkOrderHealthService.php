<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

/** Read-only operational health/profitability projection over authoritative Field records. */
final class WorkOrderHealthService
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private SpatialIntelligenceGateway $spatial,
        private WorkOrderProfitabilityCalculator $calculator,
    ) {}

    /** @return array<string,mixed> */
    public function health(int $userId, string $workOrderPublicId): array
    {
        $tenant = $this->tenantContext->companyId($userId);
        $work = $this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();
        if (!$work) throw new InvalidArgumentException('Work order not found.');
        $workMeta = $this->json($work->metadata ?? null);

        $services = $this->db->table('crm_work_order_services')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->whereNull('deleted_at')->get();
        $timeEntries = $this->db->table('crm_work_order_time_entries')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->get();
        $materials = $this->db->table('crm_work_order_materials')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->get();
        $appointments = $this->db->table('crm_appointments')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->whereNull('deleted_at')->get();

        $service = null;
        if (!empty($work->service_public_id)) {
            $service = $this->db->table('crm_services')->where('company_id',$tenant)->where('public_id',(string)$work->service_public_id)->whereNull('deleted_at')->first();
        }

        $quotedRevenue = $this->firstNumeric($workMeta, ['quoted_revenue_minor','quote_total_minor','quoted_total_minor']);
        if ($quotedRevenue === null) {
            $sum = 0; $has = false;
            foreach ($services as $line) { if (isset($line->total_minor) && is_numeric($line->total_minor)) { $sum += (int)$line->total_minor; $has = true; } }
            if ($has) $quotedRevenue = $sum;
        }
        if ($quotedRevenue === null && $service && isset($service->price_minor) && is_numeric($service->price_minor)) $quotedRevenue = (int)$service->price_minor;

        $plannedMinutes = $this->plannedMinutes($work, $appointments, $service);
        $workerIds = [];
        foreach ($timeEntries as $entry) $workerIds[] = (int)$entry->worker_user_id;
        if (!empty($work->assigned_user_id)) $workerIds[] = (int)$work->assigned_user_id;
        $workerIds = array_values(array_unique(array_filter($workerIds)));
        $profiles = [];
        if ($workerIds !== []) {
            foreach ($this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->whereIn('worker_user_id',$workerIds)->get() as $profile) {
                $profiles[(int)$profile->worker_user_id] = $profile;
            }
        }

        $actualMinutes = 0; $actualLabourCost = 0; $labourComplete = true; $timeSaleRevenue = 0;
        foreach ($timeEntries as $entry) {
            $minutes = $this->entryMinutes($entry); $actualMinutes += $minutes;
            $rate = $this->workerCostRate($workMeta, $profiles[(int)$entry->worker_user_id] ?? null);
            if ($minutes > 0 && $rate === null) $labourComplete = false;
            elseif ($rate !== null) $actualLabourCost += (int)round(($minutes / 60) * $rate);
            if ((bool)($entry->billable ?? true) && isset($entry->hourly_sale_rate_minor) && is_numeric($entry->hourly_sale_rate_minor)) {
                $timeSaleRevenue += (int)round(($minutes / 60) * (int)$entry->hourly_sale_rate_minor);
            }
        }

        $assignedRate = $this->workerCostRate($workMeta, !empty($work->assigned_user_id) ? ($profiles[(int)$work->assigned_user_id] ?? null) : null);
        $plannedLabourCost = $plannedMinutes === 0 ? 0 : ($assignedRate === null ? null : (int)round(($plannedMinutes / 60) * $assignedRate));

        $materialCost = 0; $materialComplete = true; $materialSaleRevenue = 0;
        foreach ($materials as $item) {
            $qty = is_numeric($item->quantity ?? null) ? (float)$item->quantity : 0.0;
            if ($qty > 0 && (!isset($item->unit_cost_minor) || $item->unit_cost_minor === null || !is_numeric($item->unit_cost_minor))) $materialComplete = false;
            elseif ($qty > 0) $materialCost += (int)round($qty * (int)$item->unit_cost_minor);
            if ((bool)($item->billable ?? true)) {
                if (isset($item->line_total_minor) && is_numeric($item->line_total_minor)) $materialSaleRevenue += (int)$item->line_total_minor;
                elseif (isset($item->unit_sale_price_minor) && is_numeric($item->unit_sale_price_minor)) $materialSaleRevenue += (int)round($qty * (int)$item->unit_sale_price_minor);
            }
        }

        $spatial = $this->spatial->workOrderCostEvidence($userId,$workOrderPublicId,['service_public_id'=>$work->service_public_id ?? null,'location_public_id'=>$work->location_public_id ?? null]);
        $travelSeconds = $this->nullableInt($spatial['duration_seconds'] ?? null);
        $travelMeters = $this->nullableInt($spatial['road_distance_meters'] ?? ($spatial['straight_line_distance_meters'] ?? null));
        $travelTimeCost = ($travelSeconds !== null && $assignedRate !== null) ? (int)round(($travelSeconds / 3600) * $assignedRate) : null;
        $perKm = $this->firstNumeric($workMeta,['travel_cost_per_km_minor','vehicle_cost_per_km_minor']);
        $travelDistanceCost = ($travelMeters !== null && $perKm !== null) ? (int)round(($travelMeters / 1000) * $perKm) : null;

        $severities = [];
        if (Schema::hasTable('titan_field_operational_exceptions')) {
            $severities = $this->db->table('titan_field_operational_exceptions')->where('company_id',$tenant)->where('work_order_public_id',$workOrderPublicId)->whereNotIn('status',['resolved','closed'])->pluck('severity')->map(fn($v)=>(string)$v)->all();
        }

        $health = $this->calculator->calculate([
            'quoted_revenue_minor'=>$quotedRevenue,
            'planned_labour_minutes'=>$plannedMinutes,
            'actual_labour_minutes'=>$actualMinutes,
            'known_actual_labour_cost_minor'=>$actualLabourCost,
            'labour_cost_complete'=>$labourComplete,
            'planned_labour_cost_minor'=>$plannedLabourCost,
            'material_cost_minor'=>$materialCost,
            'material_cost_complete'=>$materialComplete,
            'additional_billable_revenue_minor'=>$timeSaleRevenue+$materialSaleRevenue,
            'travel_time_cost_minor'=>$travelTimeCost,
            'travel_distance_cost_minor'=>$travelDistanceCost,
            'unresolved_exception_severities'=>$severities,
        ]);

        return $health + [
            'work_order_public_id'=>$workOrderPublicId,
            'currency'=>(string)($service->currency ?? ($workMeta['currency'] ?? 'AUD')),
            'revenue_basis'=>$quotedRevenue !== null ? ($this->firstNumeric($workMeta,['quoted_revenue_minor','quote_total_minor','quoted_total_minor']) !== null ? 'work_order_metadata' : ($services->count()>0 ? 'work_order_service_lines' : 'service_catalogue')) : 'unknown',
            'labour_rate_basis'=>$assignedRate === null ? 'incomplete' : 'explicit_field_cost_rate',
            'spatial_cost_evidence'=>$spatial,
            'travel_duration_seconds'=>$travelSeconds,
            'travel_distance_meters'=>$travelMeters,
            'pricing_signals'=>(array)($spatial['pricing_signals'] ?? []),
            'advisory_pricing_applied'=>false,
        ];
    }

    private function plannedMinutes(object $work, iterable $appointments, ?object $service): int
    {
        $sum=0;
        foreach($appointments as $appointment){$m=$this->diffMinutes($appointment->scheduled_start??null,$appointment->scheduled_end??null); if($m>0)$sum+=$m;}
        if($sum>0)return $sum;
        $fromWork=$this->diffMinutes($work->scheduled_start??null,$work->scheduled_end??null); if($fromWork>0)return $fromWork;
        return isset($service?->default_duration_minutes)&&is_numeric($service->default_duration_minutes)?max(0,(int)$service->default_duration_minutes):0;
    }
    private function entryMinutes(object $entry): int { if(isset($entry->minutes)&&is_numeric($entry->minutes))return max(0,(int)$entry->minutes); return $this->diffMinutes($entry->started_at??null,$entry->ended_at??null); }
    private function diffMinutes(mixed $start,mixed $end): int { if(!$start||!$end)return 0;$a=strtotime((string)$start);$b=strtotime((string)$end);return ($a===false||$b===false||$b<$a)?0:(int)floor(($b-$a)/60); }
    /** @return array<string,mixed> */
    private function json(mixed $value): array { if(is_array($value))return $value;if(!is_string($value)||trim($value)==='')return []; $d=json_decode($value,true);return is_array($d)?$d:[]; }
    private function workerCostRate(array $workMeta, ?object $profile): ?int
    {
        $rate=$this->firstNumeric($workMeta,['hourly_cost_rate_minor','labour_cost_rate_minor','labor_cost_rate_minor','cost_rate_minor']); if($rate!==null)return $rate;
        if(!$profile)return null; return $this->firstNumeric($this->json($profile->metadata??null),['hourly_cost_rate_minor','labour_cost_rate_minor','labor_cost_rate_minor','cost_rate_minor']);
    }
    private function firstNumeric(array $data,array $keys): ?int { foreach($keys as $key)if(array_key_exists($key,$data)&&is_numeric($data[$key]))return max(0,(int)round((float)$data[$key]));return null; }
    private function nullableInt(mixed $value): ?int { return $value===null||$value===''||!is_numeric($value)?null:(int)round((float)$value); }
}
