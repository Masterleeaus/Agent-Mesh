<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

/** Append-only evidence snapshots for non-authoritative technician recommendations. */
final class RecommendationEvidenceStore
{
    public function __construct(private ConnectionInterface $db) {}

    /** @param array<string,mixed> $context @param list<array<string,mixed>> $recommendations */
    public function record(int $companyId, int $requestedByUserId, mixed $start, mixed $end, array $context, array $recommendations, string $policyVersion, ?string $traceId=null, ?string $correlationId=null): array
    {
        $recommendationId=(string) Str::ulid();
        $normalizedContext=$this->normalize($context);
        $normalizedRecommendations=$this->normalize($recommendations);
        $contextHash=hash('sha256',$this->json($normalizedContext));
        $recommendationHash=hash('sha256',$this->json(['policy_version'=>$policyVersion,'context'=>$normalizedContext,'recommendations'=>$normalizedRecommendations]));
        $top=$recommendations[0]??null;
        $now=now();
        $this->db->table('titan_field_recommendation_snapshots')->insert([
            'public_id'=>$recommendationId,
            'company_id'=>$companyId,
            'requested_by_user_id'=>$requestedByUserId,
            'policy_version'=>$policyVersion,
            'scheduled_start'=>$start,
            'scheduled_end'=>$end,
            'context_hash'=>$contextHash,
            'recommendation_hash'=>$recommendationHash,
            'top_worker_user_id'=>is_array($top)&&($top['eligible']??false)?(int)$top['worker_user_id']:null,
            'top_score'=>is_array($top)?(int)($top['score']??0):null,
            'context'=>$this->json($normalizedContext),
            'recommendations'=>$this->json($normalizedRecommendations),
            'trace_id'=>$traceId,
            'correlation_id'=>$correlationId,
            'created_at'=>$now,
        ]);
        return ['recommendation_id'=>$recommendationId,'recommendation_hash'=>$recommendationHash,'context_hash'=>$contextHash,'policy_version'=>$policyVersion];
    }

    private function json(mixed $value): string
    {
        return (string) json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR);
    }

    private function normalize(mixed $value): mixed
    {
        if(!is_array($value))return $value;
        if(array_is_list($value))return array_map(fn($v)=>$this->normalize($v),$value);
        ksort($value,SORT_STRING);
        foreach($value as $k=>$v)$value[$k]=$this->normalize($v);
        return $value;
    }
}
