<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Commands;

use App\Extensions\TitanField\System\Contracts\FieldCommandRouter;
use App\Extensions\TitanField\System\Domains\FieldServices\Assets\CustomerAssetService;
use App\Extensions\TitanField\System\Domains\FieldServices\Catalogue\ServiceCatalogueService;
use App\Extensions\TitanField\System\Domains\FieldServices\Dispatch\DispatchService;
use App\Extensions\TitanField\System\Domains\FieldServices\Evidence\FieldEvidenceService;
use App\Extensions\TitanField\System\Domains\FieldServices\Exceptions\OperationalExceptionService;
use App\Extensions\TitanField\System\Domains\FieldServices\Forms\FormService;
use App\Extensions\TitanField\System\Domains\FieldServices\Locations\ServiceLocationService;
use App\Extensions\TitanField\System\Domains\FieldServices\Recurring\RecurringServiceEngine;
use App\Extensions\TitanField\System\Domains\FieldServices\Requests\ServiceRequestService;
use App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\AppointmentService;
use App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteService;
use App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteOptimizationProposalService;
use App\Extensions\TitanField\System\Domains\FieldServices\ServiceAreas\ServiceAreaMatcher;
use App\Extensions\TitanField\System\Domains\FieldServices\Support\SupportService;
use App\Extensions\TitanField\System\Domains\FieldServices\Verticals\FieldServiceVerticalInstaller;
use App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderService;
use Illuminate\Support\Facades\Storage;
use InvalidArgumentException;

final class FieldServiceCommandRouter implements FieldCommandRouter
{
    public function __construct(
        private FieldServiceVerticalInstaller $verticals,
        private ServiceCatalogueService $catalogue,
        private ServiceLocationService $locations,
        private ServiceRequestService $requests,
        private WorkOrderService $workOrders,
        private FormService $forms,
        private FieldEvidenceService $evidence,
        private OperationalExceptionService $exceptions,
        private RouteService $routes,
        private RouteOptimizationProposalService $routeOptimisationProposals,
        private AppointmentService $appointments,
        private DispatchService $dispatch,
        private RecurringServiceEngine $recurring,
        private SupportService $support,
        private CustomerAssetService $assets,
        private ServiceAreaMatcher $serviceAreas,
    ) {}

    public function dispatch(
        int $userId,
        ?int $actorUserId,
        string $canonicalCapability,
        string $operation,
        array $input,
        array $context = [],
    ): mixed {
        $signalContext = array_intersect_key($context, array_flip(['trace_id','correlation_id','causation_id','idempotency_key']));
        $idempotencyKey = (string) ($context['idempotency_key'] ?? '');
        $key = $canonicalCapability.'|'.$operation;

        return match ($key) {
            'titan.field.verticals|apply' => $this->verticals->apply($userId, (string) $this->required($input, 'profile'), $actorUserId, (array) ($input['settings'] ?? [])),
            'titan.field.catalogue|create_service' => $this->catalogue->createService($userId, (array) $this->required($input, 'data')),
            'titan.field.locations|create_location' => $this->locations->create($userId, (array) $this->required($input, 'data')),
            'titan.field.requests|create_request' => $this->requests->create($userId, $actorUserId, $this->withCommandContext((array) $this->required($input, 'data'), $idempotencyKey, $signalContext)),
            'titan.field.requests|transition_request' => $this->requests->transition($userId, $actorUserId, (string) $this->required($input, 'public_id'), (string) $this->required($input, 'status'), $input['reason'] ?? null),
            'titan.field.work_orders|create_work_order' => $this->workOrders->create($userId, $actorUserId, $this->withCommandContext((array) $this->required($input, 'data'), $idempotencyKey, $signalContext)),
            'titan.field.work_orders|create_from_request' => $this->workOrders->createFromRequest($userId, $actorUserId, (string) $this->required($input, 'request_public_id'), $this->withCommandContext((array) ($input['overrides'] ?? []), $idempotencyKey, $signalContext)),
            'titan.field.work_orders|transition_work_order' => $this->workOrders->transition($userId, $actorUserId, (string) $this->required($input, 'public_id'), (string) $this->required($input, 'status'), $input['reason'] ?? null, $input['evidence_attached_hash'] ?? null),
            'titan.field.work_orders|add_task' => $this->workOrders->addTask($userId, (string) $this->required($input, 'work_order_public_id'), (array) $this->required($input, 'data')),
            'titan.field.work_orders|set_task_status' => $this->workOrders->setTaskStatus($userId, (string) $this->required($input, 'task_public_id'), (string) $this->required($input, 'status'), $input['reason'] ?? null, $actorUserId),
            'titan.field.work_orders|add_note' => $this->workOrders->addNote($userId, (string) $this->required($input, 'work_order_public_id'), (string) $this->required($input, 'body'), $actorUserId, isset($input['fingerprint']) ? (string)$input['fingerprint'] : null),
            'titan.field.work_orders|add_time_entry' => $this->workOrders->addTimeEntry($userId, (string) $this->required($input, 'work_order_public_id'), (int) $this->required($input, 'worker_user_id'), $this->withCommandContext((array) $this->required($input, 'data'), $idempotencyKey, $signalContext)),
            'titan.field.work_orders|add_material' => $this->workOrders->addMaterial($userId, (string) $this->required($input, 'work_order_public_id'), (array) $this->required($input, 'data')),
            'titan.field.forms|start_submission' => $this->forms->startSubmission($userId, (string) $this->required($input, 'form_public_id'), $this->withCommandContext((array) ($input['context'] ?? []), $idempotencyKey, $signalContext)),
            'titan.field.forms|save_response' => $this->forms->saveResponse($userId, (string) $this->required($input, 'submission_public_id'), (string) $this->required($input, 'field_public_id'), $input['value'] ?? null, (bool)($input['failed'] ?? false), isset($input['failure_notes']) ? (string)$input['failure_notes'] : null),
            'titan.field.forms|submit_submission' => $this->forms->submit($userId, (string) $this->required($input, 'submission_public_id'), (int)($actorUserId ?? $userId)),
            'titan.field.evidence|store_evidence' => $this->evidence->store($userId, (int) ($actorUserId ?? $userId), $this->required($input, 'file'), array_merge((array) $this->required($input, 'context'), ['signal_context' => $signalContext])),
            'titan.field.evidence|record_reference' => $this->evidence->recordReference($userId, (int)($actorUserId ?? $userId), (string)$this->required($input, 'work_order_public_id'), array_merge((array)$this->required($input, 'data'), ['signal_context'=>$signalContext])),
            'titan.field.exceptions|detect' => $this->exceptions->detect($userId, $actorUserId, $signalContext),
            'titan.field.exceptions|acknowledge' => $this->exceptions->acknowledge($userId, $actorUserId, (string) $this->required($input, 'public_id'), $input['note'] ?? null, $signalContext),
            'titan.field.exceptions|assign' => $this->exceptions->assign($userId, $actorUserId, (string) $this->required($input, 'public_id'), (int) $this->required($input, 'owner_user_id'), $input['note'] ?? null, $signalContext),
            'titan.field.exceptions|resolve' => $this->exceptions->resolve($userId, $actorUserId, (string) $this->required($input, 'public_id'), (string) $this->required($input, 'resolution'), (array) ($input['evidence'] ?? []), $signalContext),
            'titan.field.exceptions|close' => $this->exceptions->close($userId, $actorUserId, (string) $this->required($input, 'public_id'), $input['note'] ?? null, $signalContext),
            'titan.field.routes|create_route' => $this->routes->createForWorkerDay($userId, $actorUserId, (int) $this->required($input, 'worker_user_id'), (string) $this->required($input, 'route_date'), $input['name'] ?? null, $signalContext),
            'titan.field.routes|add_stop' => $this->routes->addStop($userId, $actorUserId, (string) $this->required($input, 'route_public_id'), (string) $this->required($input, 'appointment_public_id'), $signalContext),
            'titan.field.routes|resequence_stops' => $this->routes->resequence($userId, $actorUserId, (string) $this->required($input, 'route_public_id'), (array) $this->required($input, 'stop_public_ids'), $signalContext),
            'titan.field.routes|transition_stop' => $this->routes->transitionStop($userId, $actorUserId, (string) $this->required($input, 'stop_public_id'), (string) $this->required($input, 'status'), $input['note'] ?? null, $signalContext),
            'titan.field.routes|record_location' => $this->routes->recordLocationPing($userId, $actorUserId, (int) $this->required($input, 'worker_user_id'), (float) $this->required($input, 'latitude'), (float) $this->required($input, 'longitude'), (float) $this->required($input, 'accuracy_meters'), $input, $signalContext),
            'titan.field.routes|request_optimisation_proposal' => $this->routeOptimisationProposals->request($userId,$actorUserId,(string)$this->required($input,'route_public_id'),$signalContext),
            'titan.field.routes|accept_optimisation_proposal' => $this->routeOptimisationProposals->accept($userId,$actorUserId,(string)$this->required($input,'proposal_public_id'),$signalContext),
            'titan.field.routes|reject_optimisation_proposal' => $this->routeOptimisationProposals->reject($userId,$actorUserId,(string)$this->required($input,'proposal_public_id'),isset($input['reason'])?(string)$input['reason']:null,$signalContext),
            'titan.field.routes|apply_optimisation_proposal' => $this->routeOptimisationProposals->apply($userId,$actorUserId,(string)$this->required($input,'proposal_public_id'),$signalContext),
            'titan.field.scheduling|schedule_appointment' => $this->appointments->schedule($userId, $this->withCommandContext((array) $this->required($input, 'data'), $idempotencyKey, $signalContext)),
            'titan.field.scheduling|reschedule_appointment' => $this->appointments->reschedule($userId, (string) $this->required($input, 'public_id'), $this->withCommandContext((array) $this->required($input, 'data'), $idempotencyKey, $signalContext)),
            'titan.field.dispatch|assign_dispatch' => $this->dispatch->assign($userId, $actorUserId, (string) $this->required($input, 'work_order_public_id'), (int) $this->required($input, 'worker_user_id'), array_merge((array) ($input['data'] ?? []), ['signal_context' => $signalContext])),
            'titan.field.dispatch|transition_dispatch' => $this->dispatch->transition($userId, $actorUserId, (string) $this->required($input, 'public_id'), (string) $this->required($input, 'status'), $input['reason'] ?? null),
            'titan.field.dispatch|transition_for_worker' => $this->dispatch->transitionForWorker($userId, $actorUserId, (string)$this->required($input, 'work_order_public_id'), (int)$this->required($input, 'worker_user_id'), (string)$this->required($input, 'status'), $input['reason'] ?? null),
            'titan.field.recurring|create_agreement' => $this->recurring->createAgreement($userId, array_merge((array) $this->required($input, 'data'), ['signal_context' => $signalContext])),
            'titan.field.recurring|generate_due_occurrences' => $this->recurring->generateDueOccurrences($userId, $actorUserId),
            'titan.field.recurring|set_agreement_status' => $this->recurring->setAgreementStatus($userId, (string) $this->required($input, 'public_id'), (string) $this->required($input, 'status')),
            'titan.field.forms|create_template' => $this->forms->createTemplate($userId, (array) $this->required($input, 'data')),
            'titan.field.forms|publish_template' => $this->forms->publish($userId, (string) $this->required($input, 'public_id'), $actorUserId),
            'titan.field.support|create_ticket' => $this->support->createTicket($userId, array_merge((array) $this->required($input, 'data'), ['signal_context' => $signalContext])),
            'titan.field.assets|create_asset' => $this->assets->create($userId, (array) $this->required($input, 'data')),
            'titan.field.service_areas|create_service_area' => $this->serviceAreas->create($userId, (array) $this->required($input, 'data')),
            'titan.field.service_areas|update_service_area' => $this->serviceAreas->update($userId, (string) $this->required($input, 'public_id'), (array) $this->required($input, 'data')),
            default => throw new InvalidArgumentException("Unsupported Titan Field command route: {$canonicalCapability}.{$operation}"),
        };
    }

    public function compensate(
        int $userId,
        ?int $actorUserId,
        string $canonicalCapability,
        string $operation,
        array $input,
        array $context,
        mixed $result,
        \Throwable $failure,
    ): void {
        if ($canonicalCapability !== 'titan.field.evidence' || $operation !== 'store_evidence' || ! is_array($result)) return;
        $disk = trim((string) ($result['disk'] ?? ''));
        $path = trim((string) ($result['path'] ?? ''));
        if ($disk !== '' && $path !== '') Storage::disk($disk)->delete($path);
    }

    /** @param array<string,mixed> $data @param array<string,mixed> $signalContext @return array<string,mixed> */
    private function withCommandContext(array $data, string $idempotencyKey, array $signalContext): array
    {
        if ($idempotencyKey !== '' && ! isset($data['idempotency_key'])) $data['idempotency_key'] = $idempotencyKey;
        if ($signalContext !== [] && ! isset($data['signal_context'])) $data['signal_context'] = $signalContext;
        return $data;
    }

    private function required(array $input, string $key): mixed
    {
        if (! array_key_exists($key, $input)) throw new InvalidArgumentException("Titan Field command input missing: {$key}");
        return $input[$key];
    }
}
