<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Offline;

use App\Extensions\TitanField\System\Contracts\FieldCommandGateway;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use Illuminate\Http\UploadedFile;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class OfflineFieldRuntime
{
    /** @var array<string,array{capability?:string,command?:string,entity:string,versioned:bool}> */
    private const OPERATIONS = [
        'work_order.note'=>['capability'=>'titan.field.work_orders','command'=>'add_note','entity'=>'work_order','versioned'=>false],
        'work_order.task_status'=>['capability'=>'titan.field.work_orders','command'=>'set_task_status','entity'=>'work_order_task','versioned'=>true],
        'work_order.status'=>['capability'=>'titan.field.work_orders','command'=>'transition_work_order','entity'=>'work_order','versioned'=>true],
        'work_order.complete'=>['capability'=>'titan.field.work_orders','command'=>'transition_work_order','entity'=>'work_order','versioned'=>true],
        'work_order.time'=>['capability'=>'titan.field.work_orders','command'=>'add_time_entry','entity'=>'work_order','versioned'=>false],
        'dispatch.status'=>['capability'=>'titan.field.dispatch','command'=>'transition_for_worker','entity'=>'dispatch','versioned'=>true],
        'dispatch.check_in'=>['capability'=>'titan.field.dispatch','command'=>'transition_for_worker','entity'=>'dispatch','versioned'=>true],
        'dispatch.check_out'=>['capability'=>'titan.field.dispatch','command'=>'transition_for_worker','entity'=>'dispatch','versioned'=>true],
        'route_stop.status'=>['capability'=>'titan.field.routes','command'=>'transition_stop','entity'=>'route_stop','versioned'=>true],
        'form.response'=>['capability'=>'titan.field.forms','command'=>'save_response','entity'=>'form_submission','versioned'=>true],
        'form.submit'=>['capability'=>'titan.field.forms','command'=>'submit_submission','entity'=>'form_submission','versioned'=>true],
        'evidence.reference'=>['capability'=>'titan.field.evidence','command'=>'record_reference','entity'=>'work_order','versioned'=>false],
        'signature.reference'=>['capability'=>'titan.field.evidence','command'=>'record_reference','entity'=>'work_order','versioned'=>false],
        'location.batch'=>['entity'=>'worker_location','versioned'=>false],
    ];

    public function __construct(
        private FieldCommandGateway $commands,
        private SpatialIntelligenceGateway $spatial,
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private OfflineReplayPolicy $policy,
    ) {}

    /** @return array<string,mixed> */
    public function registerDevice(int $userId, ?int $actorUserId, string $deviceId, array $metadata = []): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $actor=$actorUserId ?? $this->tenantContext->actorUserId($userId) ?? $userId;
        if(!$this->tenantContext->userBelongsToTenant($userId,$actor)) throw new InvalidArgumentException('Offline device user is outside the active tenant.');
        if(!$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('worker_user_id',$actor)->where('active',true)->exists()) {
            throw new InvalidArgumentException('Titan Go device registration requires an active Titan Field worker profile.');
        }
        $deviceId=trim($deviceId); if($deviceId===''||strlen($deviceId)>191) throw new InvalidArgumentException('device_id is required.');
        $hash=$this->deviceHash($tenant,$actor,$deviceId); $existing=$this->db->table('titan_field_offline_devices')->where('company_id',$tenant)->where('device_hash',$hash)->first();
        $row=['company_id'=>$tenant,'user_id'=>$actor,'worker_user_id'=>$actor,'device_hash'=>$hash,'device_name'=>$metadata['device_name']??null,'platform'=>$metadata['platform']??null,'app_version'=>$metadata['app_version']??null,'status'=>'active','last_seen_at'=>now(),'metadata'=>isset($metadata['metadata'])?json_encode($metadata['metadata']):null,'updated_at'=>now()];
        if($existing){$this->db->table('titan_field_offline_devices')->where('id',$existing->id)->update($row);}
        else{$row+=['public_id'=>(string)Str::ulid(),'registered_at'=>now(),'created_at'=>now()];$this->db->table('titan_field_offline_devices')->insert($row);}
        return $this->safeDevice((array)$this->db->table('titan_field_offline_devices')->where('company_id',$tenant)->where('device_hash',$hash)->first());
    }

    /** @return array<string,mixed> */
    public function mobileContext(int $userId, ?int $workerUserId = null, int $horizonDays = 7): array
    {
        $tenant=$this->tenantContext->companyId($userId);$worker=$workerUserId ?? $this->tenantContext->actorUserId($userId) ?? $userId;
        if(!$this->tenantContext->userBelongsToTenant($userId,$worker)) throw new InvalidArgumentException('Titan Go worker is outside the active tenant.');
        if(!$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('worker_user_id',$worker)->where('active',true)->exists()) throw new InvalidArgumentException('Titan Go requires an active Titan Field worker profile.');
        $horizon=max(1,min(14,$horizonDays));$from=now()->startOfDay();$to=now()->copy()->addDays($horizon)->endOfDay();
        $dispatchWork=$this->db->table('crm_dispatch_assignments')->where('company_id',$tenant)->where('worker_user_id',$worker)->whereNull('deleted_at')->whereNotIn('status',['completed','cancelled','failed'])->pluck('work_order_public_id')->all();
        $workOrders=$this->db->table('crm_work_orders')->where('company_id',$tenant)->whereNull('deleted_at')->where(function($q)use($worker,$dispatchWork){$q->where('assigned_user_id',$worker);if($dispatchWork!==[])$q->orWhereIn('public_id',$dispatchWork);})->whereNotIn('status',['closed','cancelled'])->orderBy('updated_at')->limit(100)->get()->map(fn($r)=>(array)$r)->all();
        $workIds=array_values(array_unique(array_filter(array_map(fn($r)=>(string)($r['public_id']??''),$workOrders))));
        $appointments=$this->db->table('crm_appointments')->where('company_id',$tenant)->whereNull('deleted_at')->where('assigned_user_id',$worker)->whereBetween('scheduled_start',[$from,$to])->orderBy('scheduled_start')->limit(100)->get()->map(fn($r)=>(array)$r)->all();
        $route=$this->db->table('titan_field_routes')->where('company_id',$tenant)->where('worker_user_id',$worker)->whereDate('route_date',now()->toDateString())->first();
        $stops=$route?$this->db->table('titan_field_route_stops')->where('company_id',$tenant)->where('route_public_id',$route->public_id)->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all():[];
        $forms=$workIds===[]?[]:$this->db->table('crm_form_submissions')->where('company_id',$tenant)->whereIn('work_order_public_id',$workIds)->whereNull('deleted_at')->whereIn('status',['draft','in_progress'])->orderBy('updated_at')->limit(100)->get()->map(fn($r)=>(array)$r)->all();
        $tasks=$workIds===[]?[]:$this->db->table('crm_work_order_tasks')->where('company_id',$tenant)->whereIn('work_order_public_id',$workIds)->whereNull('deleted_at')->orderBy('work_order_public_id')->orderBy('sort_order')->limit(500)->get()->map(fn($r)=>(array)$r)->all();
        $latest=max(array_map(static fn(array $r):string=>(string)($r['updated_at']??''),array_merge($workOrders,$appointments,$stops,$forms,$tasks))?:['']);
        return ['schema'=>'titan.field.mobile.context.v1','company_id'=>$tenant,'worker_user_id'=>$worker,'generated_at'=>now()->toAtomString(),'horizon_days'=>$horizon,'sync_token'=>hash('sha256',$tenant.'|'.$worker.'|'.$latest.'|'.count($workOrders).'|'.count($appointments)),'work_orders'=>$workOrders,'work_order_tasks'=>$tasks,'appointments'=>$appointments,'route'=>$route?(array)$route:null,'route_stops'=>$stops,'form_submissions'=>$forms,'spatial_provider'=>$this->spatial->available($userId)?'titan-maps-intelligence':'field-fallback'];
    }

    /** @return array<string,mixed> */
    public function replay(int $userId, ?int $actorUserId, array $envelope): array
    {
        $envelope = $this->policy->validateEnvelope($envelope);
        $tenant = $this->tenantContext->companyId($userId);
        $actor = $actorUserId ?? $this->tenantContext->actorUserId($userId) ?? $userId;
        $device = $this->assertRegisteredDevice($tenant, $actor, (string) $envelope['device_id']);
        $deviceHash = (string) $device->device_hash;
        $requestHash = $this->hash($envelope);
        $definition = self::OPERATIONS[(string) $envelope['operation']] ?? null;
        if (! $definition) throw new InvalidArgumentException('Unsupported Titan Go offline operation.');

        $this->db->table('titan_field_offline_devices')->where('id', $device->id)->update(['last_seen_at'=>now(),'updated_at'=>now()]);
        $reservation = $this->reserveReceipt($tenant, $actor, $deviceHash, $envelope, $requestHash);
        if (isset($reservation['replay'])) return (array) $reservation['replay'];
        $receiptId = (string) $reservation['public_id'];

        $base = $envelope['base_entity_version'];
        $current = $this->entityVersion($tenant, (string) $envelope['entity_type'], (string) $envelope['entity_public_id']);
        if (($definition['versioned'] ?? false) === true) {
            if ($current === null) return $this->recordConflict($receiptId, $tenant, $envelope, 'OFFLINE_CONFLICT_ENTITY_MISSING', null);
            if ($base === null) return $this->recordConflict($receiptId, $tenant, $envelope, 'OFFLINE_CONFLICT_BASE_VERSION_REQUIRED', $current);
            try {
                $this->policy->assertEntityVersion($current, (int) $base);
            } catch (RuntimeException) {
                return $this->recordConflict($receiptId, $tenant, $envelope, OfflineReplayPolicy::VERSION_CONFLICT, $current);
            }
        }

        try {
            $result = (string) $envelope['operation'] === 'location.batch'
                ? $this->spatial->syncOfflineWorkerLocations($userId, $actor, (array) ($envelope['payload']['samples'] ?? []), [
                    'device_id'=>$envelope['device_id'], 'operation_id'=>$envelope['operation_id'], 'occurred_at'=>$envelope['occurred_at'],
                ])
                : $this->commands->execute(
                    $userId, $actor, (string) $definition['capability'], (string) $definition['command'],
                    $this->commandInput((string) $envelope['operation'], $actor, $envelope),
                    array_filter([
                        'source'=>'titan-go-offline',
                        'idempotency_key'=>'offline:'.substr($deviceHash,0,16).':'.$envelope['operation_id'],
                        'trace_id'=>$envelope['trace_id']??null,
                        'correlation_id'=>$envelope['correlation_id']??null,
                        'causation_id'=>$envelope['causation_id']??null,
                    ], fn($v)=>$v!==null&&$v!=='')
                );
            $resultVersion = $this->entityVersion($tenant, (string) $envelope['entity_type'], (string) $envelope['entity_public_id']);
            $receipt = [
                'schema'=>'titan.field.offline.receipt.v1', 'offline_receipt_id'=>$receiptId,
                'operation_id'=>$envelope['operation_id'], 'operation'=>$envelope['operation'], 'status'=>'completed',
                'conflict'=>false, 'replayed'=>false, 'occurred_at'=>$envelope['occurred_at'], 'received_at'=>now()->toAtomString(),
                'base_entity_version'=>$base, 'entity_version'=>$resultVersion, 'result'=>$result,
            ];
            $receipt['integrity_hash'] = $this->hash($receipt);
            $this->db->table('titan_field_offline_receipts')->where('company_id',$tenant)->where('public_id',$receiptId)->where('status','processing')->update([
                'status'=>'completed','result_entity_version'=>$resultVersion,
                'receipt'=>json_encode($receipt,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'error_message'=>null,'updated_at'=>now(),
            ]);
            return $receipt;
        } catch (Throwable $e) {
            $this->db->table('titan_field_offline_receipts')->where('company_id',$tenant)->where('public_id',$receiptId)->where('status','processing')->update([
                'status'=>'failed','error_message'=>mb_substr($e->getMessage(),0,10000),'updated_at'=>now(),
            ]);
            throw $e;
        }
    }

    /** @return array{public_id:string,replay?:array<string,mixed>} */
    private function reserveReceipt(int $tenant, int $actor, string $deviceHash, array $envelope, string $requestHash): array
    {
        $newId = (string) Str::ulid();
        $now = now();
        $row = [
            'public_id'=>$newId,'company_id'=>$tenant,'user_id'=>$actor,'device_hash'=>$deviceHash,
            'operation_id'=>$envelope['operation_id'],'operation'=>$envelope['operation'],
            'entity_type'=>$envelope['entity_type']!==''?$envelope['entity_type']:null,
            'entity_public_id'=>$envelope['entity_public_id']!==''?$envelope['entity_public_id']:null,
            'base_entity_version'=>$envelope['base_entity_version'],'request_hash'=>$requestHash,'status'=>'processing',
            'occurred_at'=>$envelope['occurred_at'],'received_at'=>$now,
            'request_envelope'=>json_encode($envelope,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'created_at'=>$now,'updated_at'=>$now,
        ];
        if ((int) $this->db->table('titan_field_offline_receipts')->insertOrIgnore($row) === 1) {
            return ['public_id'=>$newId];
        }

        $query = $this->db->table('titan_field_offline_receipts')
            ->where('company_id',$tenant)->where('device_hash',$deviceHash)->where('operation_id',$envelope['operation_id']);
        $existing = $query->first();
        if (! $existing) throw new RuntimeException('Offline receipt reservation could not be resolved.');
        if (! hash_equals((string) $existing->request_hash, $requestHash)) {
            throw new InvalidArgumentException('Offline operation_id was already used with a different payload.');
        }
        if (in_array((string) $existing->status, ['completed','conflict'], true)) {
            $receipt = $this->decode($existing->receipt); $receipt['replayed'] = true;
            return ['public_id'=>(string)$existing->public_id,'replay'=>$receipt];
        }

        if ((string) $existing->status === 'failed') {
            $claimed = $this->db->table('titan_field_offline_receipts')->where('id',$existing->id)->where('status','failed')->where('request_hash',$requestHash)->update([
                'status'=>'processing','received_at'=>$now,'error_message'=>null,'updated_at'=>$now,
            ]);
            if ($claimed === 1) return ['public_id'=>(string)$existing->public_id];
            throw new RuntimeException('Offline operation retry was claimed by another request.');
        }

        if ((string) $existing->status === 'processing') {
            $lease = max(30, min(3600, (int) config('titan-field.offline.processing_lease_seconds', 300)));
            $leaseCutoff = now()->subSeconds($lease);
            $claimed = $this->db->table('titan_field_offline_receipts')->where('id',$existing->id)->where('status','processing')->where('request_hash',$requestHash)->where('updated_at','<=',$leaseCutoff)->update([
                'received_at'=>$now,'error_message'=>null,'updated_at'=>$now,
            ]);
            if ($claimed === 1) return ['public_id'=>(string)$existing->public_id];
            throw new RuntimeException('Offline operation is already processing.');
        }

        throw new RuntimeException('Offline operation has an unsupported receipt state.');
    }

    /** @return array<string,mixed> */
    public function storeUploadedEvidence(int $userId, ?int $actorUserId, string $deviceId, string $operationId, UploadedFile $file, array $context): array
    {
        $tenant=$this->tenantContext->companyId($userId);$actor=$actorUserId ?? $this->tenantContext->actorUserId($userId) ?? $userId;
        $device=$this->assertRegisteredDevice($tenant,$actor,$deviceId);$deviceHash=(string)$device->device_hash;
        $idempotencyKey='offline:'.substr($deviceHash,0,16).':'.$operationId;
        return $this->commands->execute($userId,$actor,'titan.field.evidence','store_evidence',['file'=>$file,'context'=>$context],['source'=>'titan-go-offline','idempotency_key'=>$idempotencyKey]);
    }

    /** @return array<string,mixed> */
    public function replayBatch(int $userId, ?int $actorUserId, array $operations): array
    {
        if(count($operations)>$this->policy->maximumBatchSize())throw new InvalidArgumentException('Offline sync batch exceeds maximum batch size.');
        $receipts=[];$summary=['completed'=>0,'conflict'=>0,'failed'=>0];
        foreach($operations as $operation){try{$receipt=$this->replay($userId,$actorUserId,(array)$operation);$receipts[]=$receipt;$summary[($receipt['status']??'')==='conflict'?'conflict':'completed']++;}catch(Throwable $e){$summary['failed']++;$receipts[]=['schema'=>'titan.field.offline.receipt.v1','operation_id'=>(string)($operation['operation_id']??''),'status'=>'failed','conflict'=>false,'error'=>$e->getMessage()];}}
        return ['schema'=>'titan.field.offline.batch-receipt.v1','received_at'=>now()->toAtomString(),'summary'=>$summary,'receipts'=>$receipts];
    }

    /** @return array<string,mixed> */
    private function commandInput(string $operation,int $actor,array $envelope): array
    {
        $payload=(array)($envelope['payload']??[]);$entity=(string)$envelope['entity_public_id'];
        return match($operation){
            'work_order.note'=>['work_order_public_id'=>$entity,'body'=>(string)($payload['body']??''),'fingerprint'=>$payload['fingerprint']??null],
            'work_order.task_status'=>['task_public_id'=>$entity,'status'=>(string)($payload['status']??''),'reason'=>$payload['reason']??null],
            'work_order.status'=>['public_id'=>$entity,'status'=>(string)($payload['status']??''),'reason'=>$payload['reason']??null],
            'work_order.complete'=>['public_id'=>$entity,'status'=>'completed','reason'=>$payload['reason']??null,'evidence_attached_hash'=>$payload['evidence_attached_hash']??null],
            'work_order.time'=>['work_order_public_id'=>$entity,'worker_user_id'=>$actor,'data'=>$payload+['source'=>'titan-go-offline']],
            'dispatch.status'=>['work_order_public_id'=>(string)($payload['work_order_public_id']??''),'worker_user_id'=>$actor,'status'=>(string)($payload['status']??''),'reason'=>$payload['reason']??null],
            'dispatch.check_in'=>['work_order_public_id'=>(string)($payload['work_order_public_id']??''),'worker_user_id'=>$actor,'status'=>'arrived','reason'=>$payload['reason']??null],
            'dispatch.check_out'=>['work_order_public_id'=>(string)($payload['work_order_public_id']??''),'worker_user_id'=>$actor,'status'=>'completed','reason'=>$payload['reason']??null],
            'route_stop.status'=>['stop_public_id'=>$entity,'status'=>(string)($payload['status']??''),'note'=>$payload['note']??null],
            'form.response'=>['submission_public_id'=>$entity,'field_public_id'=>(string)($payload['field_public_id']??''),'value'=>$payload['value']??null,'failed'=>(bool)($payload['failed']??false),'failure_notes'=>$payload['failure_notes']??null],
            'form.submit'=>['submission_public_id'=>$entity],
            'evidence.reference','signature.reference'=>['work_order_public_id'=>$entity,'data'=>$payload+['evidence_type'=>$operation==='signature.reference'?'signature':($payload['evidence_type']??'photo')]],
            default=>throw new InvalidArgumentException('Unsupported Titan Go offline operation.'),
        };
    }

    private function assertRegisteredDevice(int $tenant,int $actor,string $deviceId): object
    {
        $hash=$this->deviceHash($tenant,$actor,$deviceId);$row=$this->db->table('titan_field_offline_devices')->where('company_id',$tenant)->where('user_id',$actor)->where('device_hash',$hash)->where('status','active')->first();if(!$row)throw new InvalidArgumentException('Titan Go device is not registered or has been revoked.');return $row;
    }
    private function deviceHash(int $tenant,int $actor,string $deviceId): string{return hash('sha256',$tenant.'|'.$actor.'|'.trim($deviceId));}
    private function safeDevice(array $row): array{return ['schema'=>'titan.field.offline.device.v1','public_id'=>$row['public_id']??null,'worker_user_id'=>$row['worker_user_id']??null,'device_name'=>$row['device_name']??null,'platform'=>$row['platform']??null,'app_version'=>$row['app_version']??null,'status'=>$row['status']??null,'registered_at'=>$row['registered_at']??null,'last_seen_at'=>$row['last_seen_at']??null];}

    private function entityVersion(int $tenant,string $type,string $publicId): ?int
    {
        if($type===''||$publicId==='')return null;$tables=['work_order'=>'crm_work_orders','work_order_task'=>'crm_work_order_tasks','appointment'=>'crm_appointments','dispatch'=>'crm_dispatch_assignments','form_submission'=>'crm_form_submissions','route'=>'titan_field_routes','route_stop'=>'titan_field_route_stops'];$table=$tables[$type]??null;if(!$table)return null;$row=$this->db->table($table)->where('company_id',$tenant)->where('public_id',$publicId)->first();if(!$row)return null;return isset($row->entity_version)?(int)$row->entity_version:1;
    }

    /** @return array<string,mixed> */
    private function recordConflict(string $receiptId, int $tenant, array $envelope, string $code, ?int $current): array
    {
        $receipt = [
            'schema'=>'titan.field.offline.receipt.v1','offline_receipt_id'=>$receiptId,'operation_id'=>$envelope['operation_id'],
            'operation'=>$envelope['operation'],'status'=>'conflict','conflict'=>true,'conflict_code'=>$code,
            'base_entity_version'=>$envelope['base_entity_version'],'entity_version'=>$current,'occurred_at'=>$envelope['occurred_at'],
            'received_at'=>now()->toAtomString(),'replayed'=>false,
        ];
        $receipt['integrity_hash']=$this->hash($receipt);
        $this->db->table('titan_field_offline_receipts')->where('company_id',$tenant)->where('public_id',$receiptId)->where('status','processing')->update([
            'status'=>'conflict','result_entity_version'=>$current,'conflict_code'=>$code,
            'receipt'=>json_encode($receipt,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'updated_at'=>now(),
        ]);
        return $receipt;
    }
    private function hash(array $value):string{$normal=$this->normalise($value);return hash('sha256',json_encode($normal,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));}
    private function normalise(mixed $value):mixed{if(is_array($value)){if(!array_is_list($value))ksort($value);foreach($value as $k=>$v)$value[$k]=$this->normalise($v);}return $value;}
    private function decode(mixed $value):array{if(is_array($value))return $value;if(!is_string($value)||$value==='')return [];$d=json_decode($value,true);return is_array($d)?$d:[];}
}
