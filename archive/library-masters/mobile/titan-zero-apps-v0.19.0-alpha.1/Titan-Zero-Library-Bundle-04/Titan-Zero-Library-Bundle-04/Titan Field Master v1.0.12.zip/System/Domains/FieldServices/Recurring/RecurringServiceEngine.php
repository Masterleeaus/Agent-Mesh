<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Recurring;

use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderService;
use Carbon\Carbon;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class RecurringServiceEngine
{
    public function __construct(
        private FieldSignalPort $signals,
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private WorkOrderService $workOrders,
        private FieldReferenceIntegrity $integrity,
        private RecurrenceCalculator $recurrence,
    ) {}

    public function createAgreement(int $userId,array $data): array
    {
        $name=trim((string)($data['name']??''));
        if($name==='')throw new InvalidArgumentException('Service agreement name is required.');
        $this->integrity->assertContext($userId,$data);
        $this->integrity->assertServiceList($userId,$data['service_public_ids']??[]);
        $preferences=$this->agreementPreferences($data);
        $startsAt=Carbon::parse($data['starts_on']??now());
        $first=$this->recurrence->occurrencesBetween($startsAt,$startsAt->copy()->addYears(10),$preferences['recurrence_rule'],1);
        if($first===[]&&!isset($data['next_occurrence_at']))throw new InvalidArgumentException('Recurring rule produces no occurrence within the supported 10-year horizon.');
        $initialOccurrence=$data['next_occurrence_at']??($first[0]??$startsAt);
        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($userId,$data,$name,$publicId,$preferences,$initialOccurrence):array{
            $this->db->table('crm_service_agreements')->insert([
                'public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),
                'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'location_public_id'=>$data['location_public_id']??null,
                'name'=>$name,'status'=>$data['status']??'draft','cadence'=>$data['cadence']??'monthly','interval_count'=>max(1,(int)($data['interval_count']??1)),
                'starts_on'=>$data['starts_on']??now()->toDateString(),'ends_on'=>$data['ends_on']??null,'next_occurrence_at'=>$initialOccurrence,
                'price_minor'=>$data['price_minor']??null,'currency'=>$data['currency']??'AUD','auto_create_work_order'=>(bool)($data['auto_create_work_order']??true),
                'preferences'=>json_encode($preferences),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()
            ]);
            foreach((array)($data['service_public_ids']??[]) as $sid)$this->db->table('crm_service_agreement_services')->insert([
                'public_id'=>(string)Str::ulid(),'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),
                'agreement_public_id'=>$publicId,'service_public_id'=>$sid,'quantity'=>1,'created_at'=>now(),'updated_at'=>now()
            ]);
            $record=(array)$this->db->table('crm_service_agreements')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='recurring.agreement.created:'.$publicId;
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.recurring.agreement_created','service_agreement',$publicId,['status'=>$record['status']??'draft','cadence'=>$record['cadence']??null,'service_public_ids'=>array_values((array)($data['service_public_ids']??[]))],$ctx);
            return $record;
        });
    }

    public function setAgreementStatus(int $userId,string $publicId,string $status): array
    {
        $row=$this->db->table('crm_service_agreements')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$row)throw new InvalidArgumentException('Service agreement not found.');
        $allowed=['draft'=>['active','cancelled'],'active'=>['paused','cancelled','expired'],'paused'=>['active','cancelled','expired'],'cancelled'=>[],'expired'=>[]];
        $from=(string)$row->status;
        if($status===$from)return (array)$row;
        if(!in_array($status,$allowed[$from]??[],true))throw new InvalidArgumentException("Invalid service-agreement transition {$from} -> {$status}.");
        $updates=['status'=>$status,'updated_at'=>now()];
        if($status==='active'&&!$row->next_occurrence_at)$updates['next_occurrence_at']=$row->starts_on?:now();
        return $this->db->transaction(function()use($userId,$publicId,$status,$from,$row,$updates):array{
            $this->db->table('crm_service_agreements')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->update($updates);
            $after=(array)$this->db->table('crm_service_agreements')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.recurring.status_changed','service_agreement',$publicId,['from'=>$from,'to'=>$status],['idempotency_key'=>hash('sha256','recurring.status|'.$publicId.'|'.$from.'|'.$status.'|'.(string)($row->updated_at??''))]);
            return $after;
        });
    }

    public function generateDueOccurrences(int $userId,?int $actorUserId=null): array
    {
        $limit=(int)config('titan-field.field_services.recurring_generation_limit',100);
        $agreements=$this->db->table('crm_service_agreements')->where('company_id',$this->tenantContext->companyId($userId))->where('status','active')->whereNull('deleted_at')->whereNotNull('next_occurrence_at')->where('next_occurrence_at','<=',now())->orderBy('next_occurrence_at')->limit(max(1,min($limit,500)))->get();
        $generated=[];
        foreach($agreements as $agreement)$generated[]=$this->generateOccurrence($userId,$actorUserId,(array)$agreement);
        return $generated;
    }

    private function generateOccurrence(int $userId,?int $actorUserId,array $agreement): array
    {
        return $this->db->transaction(function()use($userId,$actorUserId,$agreement):array{
            $tenant=$this->tenantContext->companyId($userId);
            $locked=$this->db->table('crm_service_agreements')->where('company_id',$tenant)->where('public_id',$agreement['public_id'])->whereNull('deleted_at')->lockForUpdate()->first();
            if(!$locked)throw new InvalidArgumentException('Service agreement not found.');
            if((string)$locked->status!=='active')return ['status'=>'skipped','reason'=>'agreement_not_active','agreement_public_id'=>(string)$locked->public_id];
            if(!$locked->next_occurrence_at)return ['status'=>'skipped','reason'=>'no_next_occurrence','agreement_public_id'=>(string)$locked->public_id];
            $due=Carbon::parse($locked->next_occurrence_at);
            $idempotencyKey='agreement:'.$locked->public_id.':'.$due->toIso8601String();
            $existing=$this->db->table('crm_recurring_occurrences')->where('company_id',$tenant)->where('idempotency_key',$idempotencyKey)->first();
            $next=$this->recurrence->nextAfter($due,$this->agreementRule((array)$locked));
            if($existing){
                $this->db->table('crm_service_agreements')->where('company_id',$tenant)->where('public_id',$locked->public_id)->update(['last_generated_until'=>$due,'next_occurrence_at'=>$next,'updated_at'=>now()]);
                return (array)$existing;
            }
            $service=$this->db->table('crm_service_agreement_services')->where('company_id',$tenant)->where('agreement_public_id',$locked->public_id)->orderBy('id')->first();
            $work=null;
            if((bool)$locked->auto_create_work_order)$work=$this->workOrders->create($userId,$actorUserId,[
                'company_public_id'=>$locked->company_public_id,'contact_public_id'=>$locked->contact_public_id,'location_public_id'=>$locked->location_public_id,
                'service_public_id'=>$service->service_public_id??null,'title'=>$locked->name,'description'=>'Recurring service occurrence','status'=>'ready','idempotency_key'=>$idempotencyKey,
                'signal_context'=>['correlation_id'=>'recurring:'.$locked->public_id.':'.$due->toIso8601String(),'causation_id'=>$idempotencyKey],
            ]);
            $publicId=(string)Str::ulid();
            $this->db->table('crm_recurring_occurrences')->insert([
                'public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>$this->tenantContext->actorUserId($userId),'agreement_public_id'=>$locked->public_id,
                'work_order_public_id'=>$work['public_id']??null,'due_at'=>$due,'status'=>'generated','idempotency_key'=>$idempotencyKey,'created_at'=>now(),'updated_at'=>now()
            ]);
            $this->db->table('crm_service_agreements')->where('company_id',$tenant)->where('public_id',$locked->public_id)->update(['last_generated_until'=>$due,'next_occurrence_at'=>$next,'updated_at'=>now()]);
            $record=(array)$this->db->table('crm_recurring_occurrences')->where('company_id',$tenant)->where('public_id',$publicId)->first();
            $this->signals->record($userId,$actorUserId,'field.recurring.occurrence_generated','recurring_occurrence',$publicId,['agreement_public_id'=>(string)$locked->public_id,'work_order_public_id'=>$work['public_id']??null,'due_at'=>$due->toIso8601String(),'next_occurrence_at'=>$next->toIso8601String()],['correlation_id'=>'recurring:'.$locked->public_id.':'.$due->toIso8601String(),'causation_id'=>$idempotencyKey,'idempotency_key'=>'recurring.occurrence:'.$idempotencyKey]);
            return $record;
        });
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    private function agreementPreferences(array $data): array
    {
        $preferences=is_array($data['preferences']??null)?$data['preferences']:[];
        $rule=is_array($data['recurrence_rule']??null)?$data['recurrence_rule']:(is_array($preferences['recurrence_rule']??null)?$preferences['recurrence_rule']:[]);
        $rule=array_merge([
            'frequency'=>$data['cadence']??'monthly',
            'interval'=>$data['interval_count']??1,
            'anchor_date'=>$data['starts_on']??now()->toDateString(),
        ],$rule);
        $preferences['recurrence_rule']=$this->recurrence->normalize($rule,Carbon::parse($data['starts_on']??now())->toImmutable());
        return $preferences;
    }

    /** @param array<string,mixed> $agreement @return array<string,mixed> */
    private function agreementRule(array $agreement): array
    {
        $preferences=[];
        if(is_string($agreement['preferences']??null)&&trim((string)$agreement['preferences'])!==''){
            $decoded=json_decode((string)$agreement['preferences'],true);if(is_array($decoded))$preferences=$decoded;
        }elseif(is_array($agreement['preferences']??null))$preferences=$agreement['preferences'];
        $rule=is_array($preferences['recurrence_rule']??null)?$preferences['recurrence_rule']:[];
        return array_merge([
            'frequency'=>$agreement['cadence']??'monthly',
            'interval'=>$agreement['interval_count']??1,
            'anchor_date'=>$agreement['starts_on']??null,
        ],$rule);
    }
}
