<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

/** Optional spatial peer boundary. Titan Field remains operational authority. */
interface SpatialIntelligenceGateway
{
    public function available(int $userId): bool;
    /** @param array<int,int> $workerUserIds @return array<int,array<string,mixed>> */
    public function latestWorkerPositions(int $userId, array $workerUserIds = []): array;
    /** @return array<string,mixed> */
    public function estimateTravel(int $userId, array $origin, array $destination, array $context = []): array;
    /** @return array<string,mixed> */
    public function recordWorkerLocation(int $userId, int $workerUserId, array $payload): array;
    /** Offline-safe bounded GPS replay; stale samples must remain historical evidence. @return array<string,mixed> */
    public function syncOfflineWorkerLocations(int $userId, int $workerUserId, array $samples, array $context = []): array;
    /** Read-only work-order spatial cost evidence; Maps never writes Field financial state. @return array<string,mixed> */
    public function workOrderCostEvidence(int $userId, string $workOrderPublicId, array $context = []): array;

    /** Read-only spatial capacity pressure evidence; Maps never schedules Field work. @return array<string,mixed> */
    public function capacityPressureEvidence(int $userId, array $context = []): array;
    /** Read-only Maps optimisation proposal; Field retains all route-write authority. @return array<string,mixed> */
    public function routeOptimizationProposal(int $userId, string $routePublicId, array $route, array $stops, array $context = []): array;
    /** @return array<string,mixed> */
    public function mapPayload(int $userId, string $page = 'field.team'): array;
    /** @return array<string,mixed> */
    public function mapUi(int $userId): array;
}
