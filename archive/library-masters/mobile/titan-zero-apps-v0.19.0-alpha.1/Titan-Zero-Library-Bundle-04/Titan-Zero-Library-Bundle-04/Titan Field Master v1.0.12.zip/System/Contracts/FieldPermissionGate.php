<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

use Closure;
use Illuminate\Http\Request;

interface FieldPermissionGate
{
    public function handle(Request $request, Closure $next, string $permission): mixed;
}
