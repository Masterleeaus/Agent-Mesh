<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

/** Deterministic offline travel estimate. External routing providers can replace it later. */
final class TravelEstimator
{
    /** @return array{distance_meters:?int,duration_seconds:?int,provider:string} */
    public function estimate(?float $originLatitude, ?float $originLongitude, ?float $destinationLatitude, ?float $destinationLongitude): array
    {
        $distance=$this->haversineMeters($originLatitude,$originLongitude,$destinationLatitude,$destinationLongitude);
        return [
            'distance_meters'=>$distance,
            'duration_seconds'=>$distance===null?null:(int)ceil(($distance/1000)/35*3600),
            'provider'=>'haversine_fallback',
        ];
    }

    private function haversineMeters(?float $lat1,?float $lon1,?float $lat2,?float $lon2): ?int
    {
        if($lat1===null||$lon1===null||$lat2===null||$lon2===null)return null;
        $earth=6371000.0;$dLat=deg2rad($lat2-$lat1);$dLon=deg2rad($lon2-$lon1);
        $a=sin($dLat/2)**2+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLon/2)**2;
        return (int)round($earth*2*atan2(sqrt($a),sqrt(max(0.0,1-$a))));
    }
}
