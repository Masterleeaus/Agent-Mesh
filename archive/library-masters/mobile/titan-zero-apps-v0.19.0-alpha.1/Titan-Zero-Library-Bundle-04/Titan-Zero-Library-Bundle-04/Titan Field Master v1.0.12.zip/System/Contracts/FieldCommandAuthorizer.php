<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldCommandAuthorizer
{
    public function authorize(int $userId, string $permission): void;
}
