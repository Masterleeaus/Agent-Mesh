<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Middleware;

use App\Extensions\TitanField\System\Contracts\FieldPermissionGate;
use App\Extensions\TitanField\System\Security\FieldPermissionService;
use Closure;
use Illuminate\Http\Request;

final class TitanFieldPermissionGate implements FieldPermissionGate
{
    public function __construct(private FieldPermissionService $permissions) {}

    public function handle(Request $request, Closure $next, string $permission): mixed
    {
        $userId = (int) ($request->user()?->id ?? 0);
        $this->permissions->authorize($userId, $permission);
        return $next($request);
    }
}
