<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Commands;

use App\Extensions\TitanField\System\Contracts\FieldCommandAuthorizer;
use App\Extensions\TitanField\System\Contracts\FieldCommandGateway;
use App\Extensions\TitanField\System\Contracts\FieldCommandRouter;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\FieldServiceCapabilityRegistry;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

final class GovernedFieldCommandGateway implements FieldCommandGateway
{
    public function __construct(
        private FieldServiceCapabilityRegistry $capabilities,
        private FieldCommandAuthorizer $authorizer,
        private FieldCommandRouter $router,
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
    ) {}

    public function execute(
        int $userId,
        ?int $actorUserId,
        string $capability,
        string $operation,
        array $input = [],
        array $context = [],
    ): array {
        $requestedCapability = trim($capability);
        $operation = trim($operation);
        if ($requestedCapability === '' || $operation === '') {
            throw new InvalidArgumentException('Titan Field capability and operation are required.');
        }

        $canonical = $this->capabilities->canonicalName($requestedCapability);
        if ($canonical === null) throw new InvalidArgumentException("Unknown Titan Field capability: {$requestedCapability}");
        $definition = $this->capabilities->definition($canonical);
        if ($definition === null) throw new InvalidArgumentException("Titan Field capability definition missing: {$canonical}");
        if (! $this->capabilities->enabled($canonical)) throw new RuntimeException("Titan Field capability disabled: {$canonical}");
        if (($definition['kind'] ?? null) !== 'read_write') {
            throw new InvalidArgumentException("Titan Field capability is not mutation-capable: {$canonical}");
        }

        $permission = trim((string) ($definition['permission'] ?? ''));
        if ($permission === '') throw new RuntimeException("Titan Field capability permission missing: {$canonical}");
        $this->authorizer->authorize($userId, $permission);

        $tenantId = $this->tenantContext->companyId($userId);
        $resolvedActor = $actorUserId ?? $this->tenantContext->actorUserId($userId);
        if ($resolvedActor !== null && ! $this->tenantContext->userBelongsToTenant($userId, $resolvedActor)) {
            throw new InvalidArgumentException('Titan Field command actor does not belong to the active tenant.');
        }

        $idempotencyRequired = (bool) ($definition['idempotency']['required_for_mutations'] ?? false);
        $idempotencyKey = trim((string) ($context['idempotency_key'] ?? $input['idempotency_key'] ?? ''));
        if ($idempotencyRequired && $idempotencyKey === '') {
            throw new InvalidArgumentException("Titan Field command idempotency key is required: {$canonical}.{$operation}");
        }
        if ($idempotencyKey === '') $idempotencyKey = (string) Str::uuid();

        $traceId = $this->uuid($context['trace_id'] ?? null);
        $correlationId = $this->uuid($context['correlation_id'] ?? null, $traceId);
        $causationId = $this->uuid($context['causation_id'] ?? null, $correlationId);
        $source = trim((string) ($context['source'] ?? 'titan_field')) ?: 'titan_field';
        $commandId = $this->ulid($context['command_id'] ?? null);
        $requestHash = $this->requestHash($input);
        $idempotencyHash = hash('sha256', $canonical.'|'.$operation.'|'.$idempotencyKey);
        $started = microtime(true);

        $resultForCompensation = null;
        try {
            return $this->db->transaction(function () use (
                $userId, $resolvedActor, $requestedCapability, $canonical, $operation, $input, $context,
                $permission, $tenantId, $idempotencyKey, $idempotencyHash, $requestHash,
                $traceId, $correlationId, $causationId, $source, $commandId, $started, &$resultForCompensation
            ): array {
                $table = $this->db->table('titan_field_command_receipts');
                $existing = $table->where('company_id', $tenantId)
                    ->where('idempotency_hash', $idempotencyHash)->lockForUpdate()->first();

                if ($existing !== null) {
                    if (! hash_equals((string) ($existing->request_hash ?? ''), $requestHash)) {
                        throw new InvalidArgumentException('Idempotency key was already used with a different Titan Field command payload.');
                    }
                    if ((string) ($existing->status ?? '') === 'completed') {
                        $receipt = $this->decode($existing->receipt ?? null);
                        $receipt['replayed'] = true;
                        return $receipt;
                    }
                    throw new RuntimeException('Matching Titan Field command is already processing.');
                }

                $requestEnvelope = [
                'schema' => 'titan.field.command.request.v1',
                'command_id' => $commandId,
                'company_id' => $tenantId,
                'actor_user_id' => $resolvedActor,
                'requested_capability' => $requestedCapability,
                'capability_id' => $canonical,
                'operation' => $operation,
                'permission' => $permission,
                'source' => $source,
                'idempotency_key' => $idempotencyKey,
                'trace_id' => $traceId,
                'correlation_id' => $correlationId,
                'causation_id' => $causationId,
                'input' => $this->serialisable($input),
            ];

                $inserted = $table->insertOrIgnore([
                    'command_id' => $commandId,
                    'company_id' => $tenantId,
                    'actor_user_id' => $resolvedActor,
                    'requested_capability' => $requestedCapability,
                    'capability_id' => $canonical,
                    'operation' => $operation,
                    'permission' => $permission,
                    'source' => $source,
                    'idempotency_key' => $idempotencyKey,
                    'idempotency_hash' => $idempotencyHash,
                    'request_hash' => $requestHash,
                    'trace_id' => $traceId,
                    'correlation_id' => $correlationId,
                    'causation_id' => $causationId,
                    'status' => 'processing',
                    'request_envelope' => $this->json($requestEnvelope),
                    'started_at' => now(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
                if ($inserted !== 1) {
                    $existing = $this->db->table('titan_field_command_receipts')
                        ->where('company_id', $tenantId)->where('idempotency_hash', $idempotencyHash)
                        ->lockForUpdate()->first();
                    if ($existing === null) throw new RuntimeException('Titan Field command idempotency reservation failed.');
                    if (! hash_equals((string) ($existing->request_hash ?? ''), $requestHash)) {
                        throw new InvalidArgumentException('Idempotency key was already used with a different Titan Field command payload.');
                    }
                    if ((string) ($existing->status ?? '') === 'completed') {
                        $receipt = $this->decode($existing->receipt ?? null);
                        $receipt['replayed'] = true;
                        return $receipt;
                    }
                    throw new RuntimeException('Matching Titan Field command is already processing.');
                }

                $commandContext = array_merge($context, [
                'command_id' => $commandId,
                'requested_capability' => $requestedCapability,
                'capability_id' => $canonical,
                'operation' => $operation,
                'permission' => $permission,
                'source' => $source,
                'idempotency_key' => $idempotencyKey,
                'trace_id' => $traceId,
                'correlation_id' => $correlationId,
                'causation_id' => $causationId,
            ]);
                $result = $this->router->dispatch($userId, $resolvedActor, $canonical, $operation, $input, $commandContext);
                $resultForCompensation = $result;

            $receipt = [
                'schema' => 'titan.field.command.receipt.v1',
                'command_id' => $commandId,
                'company_id' => $tenantId,
                'actor_user_id' => $resolvedActor,
                'requested_capability' => $requestedCapability,
                'capability_id' => $canonical,
                'operation' => $operation,
                'permission' => $permission,
                'source' => $source,
                'idempotency_key' => $idempotencyKey,
                'request_hash' => $requestHash,
                'trace_id' => $traceId,
                'correlation_id' => $correlationId,
                'causation_id' => $causationId,
                'status' => 'completed',
                'replayed' => false,
                'duration_ms' => max(0, (int) round((microtime(true) - $started) * 1000)),
                'result' => $this->serialisable($result),
            ];
            $receipt['integrity_hash'] = hash('sha256', $this->json($receipt));

            $this->db->table('titan_field_command_receipts')
                ->where('company_id', $tenantId)->where('idempotency_hash', $idempotencyHash)
                ->update([
                    'status' => 'completed',
                    'result' => $this->json($this->serialisable($result)),
                    'receipt' => $this->json($receipt),
                    'completed_at' => now(),
                    'updated_at' => now(),
                ]);

                return $receipt;
            });
        } catch (\Throwable $failure) {
            if ($resultForCompensation !== null) {
                try {
                    $this->router->compensate($userId, $resolvedActor, $canonical, $operation, $input, $context, $resultForCompensation, $failure);
                } catch (\Throwable) {
                    // Compensation is best-effort here; the original command failure remains authoritative.
                }
            }
            throw $failure;
        }
    }

    private function requestHash(array $input): string
    {
        return hash('sha256', $this->json($this->serialisable($input)));
    }

    private function uuid(mixed $value, ?string $fallback = null): string
    {
        $candidate = is_string($value) ? trim($value) : '';
        if ($candidate !== '' && Str::isUuid($candidate)) return $candidate;
        if ($fallback !== null && Str::isUuid($fallback)) return $fallback;
        return (string) Str::uuid();
    }

    private function ulid(mixed $value): string
    {
        $candidate = is_string($value) ? trim($value) : '';
        return $candidate !== '' && strlen($candidate) === 26 ? $candidate : (string) Str::ulid();
    }

    private function serialisable(mixed $value): mixed
    {
        if (is_array($value)) {
            if (! array_is_list($value)) ksort($value);
            foreach ($value as $key => $item) $value[$key] = $this->serialisable($item);
            return $value;
        }
        if (is_object($value)) {
            $filePath = method_exists($value, 'getRealPath') ? $value->getRealPath() : false;
            $out = ['object_class' => $value::class];
            if (method_exists($value, 'getClientOriginalName')) $out['original_name'] = $value->getClientOriginalName();
            if (method_exists($value, 'getSize')) $out['size'] = $value->getSize();
            if (is_string($filePath) && $filePath !== '' && is_file($filePath)) $out['sha256'] = hash_file('sha256', $filePath);
            return $out;
        }
        if (is_resource($value)) return ['resource_type' => get_resource_type($value)];
        return $value;
    }

    private function json(mixed $value): string
    {
        return json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    /** @return array<string,mixed> */
    private function decode(mixed $value): array
    {
        if (is_array($value)) return $value;
        if (is_object($value)) return (array) $value;
        if (! is_string($value) || $value === '') return [];
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }
}
