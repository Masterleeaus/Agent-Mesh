<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Navigation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Idempotent/self-healing host-menu bridge.
 *
 * Historical CRM rows are resolved by preferred key first and named route
 * second. Matching by route is deliberate: it preserves an existing CRM menu
 * identity even when an older release used a different child key.
 */
final class TitanFieldMenuInstaller
{
    private const HOST_SAFE_ICONS = [
        'tabler-layout-dashboard', 'tabler-users', 'tabler-folders', 'tabler-settings',
        'tabler-command', 'tabler-directions', 'tabler-tool', 'tabler-components',
        'tabler-category', 'tabler-inbox', 'tabler-message', 'tabler-users-group',
        'tabler-world', 'tabler-user-check', 'tabler-building', 'tabler-briefcase',
        'tabler-checklist', 'tabler-calendar', 'tabler-chart-line', 'tabler-alert-triangle', 'tabler-route',
    ];

    public static function sync(): void
    {
        if (! self::menuTableAvailable()) {
            return;
        }

        $columns = array_flip(Schema::getColumnListing('menus'));
        foreach (TitanFieldMenuDefinition::all() as $root) {
            $parentId = self::syncRoot($root, $columns);
            if ($parentId === null) {
                continue;
            }

            foreach ($root['children'] ?? [] as $child) {
                self::upsertChild($child, $parentId, $columns);
            }
        }

        // The pre-extraction CRM host can contain both crm_calendar and crm_schedule under Crew.
        // Titan Field owns one canonical Schedule surface after activation: restore the Crew parent
        // to that route and hide the obsolete duplicate Calendar row.
        self::restoreCanonicalCrewScheduleRoute();
        self::suppressLegacyCalendarDuplicate();
        self::invalidateHostMenuCache();
    }

    /**
     * Runtime drift repair is deliberately fail-soft: menu recovery may never
     * prevent the application from booting. Writes occur only when a required
     * row/route/parent has actually drifted.
     */
    /**
     * CRM alpha.17-alpha.23 compatibility: keep Titan Field dormant as a writer,
     * but adopt only the existing schedule row and point it at the bounded read-only
     * staged calendar. Full sync takes the row back to the canonical Field route on activation.
     */
    public static function syncStagedSchedule(): void
    {
        try {
            if (! self::menuTableAvailable() || ! Schema::hasColumn('menus', 'route') || ! Schema::hasColumn('menus', 'label')) {
                return;
            }

            $row = DB::table('menus')->where('key', 'crm_schedule')->first();
            $legacyCalendar = DB::table('menus')->where('key', 'crm_calendar')->first();
            if (! $row) {
                $row = DB::table('menus')->where('route', 'dashboard.user.crm.field-services.schedule')->first();
            }
            if (! $row && $legacyCalendar) {
                // Very old hosts may have Calendar but no dedicated Schedule row. Adopt that row
                // instead of creating a second visible calendar entry.
                $row = $legacyCalendar;
                $legacyCalendar = null;
            }
            if (! $row) {
                return;
            }

            $data = [
                'label' => 'Schedule',
                'route' => 'dashboard.user.titan-field.schedule',
            ];
            if (Schema::hasColumn('menus', 'key') && (string) ($row->key ?? '') !== 'crm_schedule') $data['key'] = 'crm_schedule';
            if (Schema::hasColumn('menus', 'is_active')) $data['is_active'] = 1;
            if (Schema::hasColumn('menus', 'updated_at')) $data['updated_at'] = now();

            DB::table('menus')->where('id', $row->id)->update($data);
            self::syncStagedCrewScheduleRoute();
            self::suppressLegacyCalendarDuplicate($row->id ?? null, 'dashboard.user.titan-field.schedule');
            self::invalidateHostMenuCache();
        } catch (\Throwable) {
            // Read-only staged navigation recovery must never prevent application boot.
        }
    }


    private static function syncStagedCrewScheduleRoute(): void
    {
        if (! Schema::hasColumn('menus', 'route')) {
            return;
        }
        $crew = DB::table('menus')->where('key', 'ext_crm_crew')->first();
        if (! $crew) {
            return;
        }
        $data = ['route' => 'dashboard.user.titan-field.schedule'];
        if (Schema::hasColumn('menus', 'is_active')) $data['is_active'] = 1;
        if (Schema::hasColumn('menus', 'updated_at')) $data['updated_at'] = now();
        DB::table('menus')->where('id', $crew->id)->update($data);
    }

    private static function restoreCanonicalCrewScheduleRoute(): void
    {
        if (! Schema::hasColumn('menus', 'route')) {
            return;
        }
        $crew = DB::table('menus')->where('key', 'ext_crm_crew')->first();
        if (! $crew) {
            return;
        }
        $data = ['route' => 'dashboard.user.crm.field-services.schedule'];
        if (Schema::hasColumn('menus', 'is_active')) $data['is_active'] = 1;
        if (Schema::hasColumn('menus', 'updated_at')) $data['updated_at'] = now();
        DB::table('menus')->where('id', $crew->id)->update($data);
    }

    private static function suppressLegacyCalendarDuplicate(mixed $canonicalId = null, string $targetRoute = 'dashboard.user.crm.field-services.schedule'): void
    {
        if (! Schema::hasColumn('menus', 'key')) {
            return;
        }
        $query = DB::table('menus')->where('key', 'crm_calendar');
        if ($canonicalId !== null && Schema::hasColumn('menus', 'id')) {
            $query->where('id', '<>', $canonicalId);
        }
        $legacyCalendar = $query->first();
        if (! $legacyCalendar) {
            return;
        }
        $data = ['label' => 'Schedule', 'route' => $targetRoute, 'is_active' => 0];
        if (! Schema::hasColumn('menus', 'label')) unset($data['label']);
        if (! Schema::hasColumn('menus', 'route')) unset($data['route']);
        if (! Schema::hasColumn('menus', 'is_active')) unset($data['is_active']);
        if (Schema::hasColumn('menus', 'updated_at')) $data['updated_at'] = now();
        if ($data === []) {
            return;
        }
        DB::table('menus')->where('id', $legacyCalendar->id)->update($data);
    }

    public static function healIfNeeded(): void
    {
        try {
            if (! self::menuTableAvailable() || self::healthy()) {
                return;
            }
            self::sync();
        } catch (\Throwable) {
            // Installation/runtime must remain available even if host menu storage is unavailable.
        }
    }

    private static function healthy(): bool
    {
        if (! Schema::hasColumn('menus', 'route') || ! Schema::hasColumn('menus', 'parent_id')) {
            return false;
        }

        foreach (TitanFieldMenuDefinition::all() as $root) {
            $parent = DB::table('menus')->where('key', $root['key'])->first();
            if (! $parent) {
                return false;
            }
            if (($root['preserve_existing_parent'] ?? false) !== true
                && (string) ($parent->route ?? '') !== (string) ($root['route'] ?? '')) {
                return false;
            }
            if (Schema::hasColumn('menus', 'is_active') && (int) ($parent->is_active ?? 0) !== 1) {
                return false;
            }

            foreach ($root['children'] ?? [] as $child) {
                $row = self::findExisting($child);
                if (! $row
                    || (string) ($row->route ?? '') !== (string) $child['route']
                    || (string) ($row->parent_id ?? '') !== (string) ($parent->id ?? '')
                    || (string) ($row->label ?? '') !== (string) ($child['label'] ?? '')) {
                    return false;
                }
                if (Schema::hasColumn('menus', 'is_active') && (int) ($row->is_active ?? 0) !== 1) {
                    return false;
                }
            }
        }

        $crew = DB::table('menus')->where('key', 'ext_crm_crew')->first();
        if ($crew && (string) ($crew->route ?? '') !== 'dashboard.user.crm.field-services.schedule') {
            return false;
        }
        if (Schema::hasColumn('menus', 'is_active')) {
            $legacyCalendar = DB::table('menus')->where('key', 'crm_calendar')->first();
            if ($legacyCalendar && (int) ($legacyCalendar->is_active ?? 0) === 1) {
                return false;
            }
        }

        return true;
    }

    /** @param array<string,mixed> $root @param array<string,int> $columns */
    private static function syncRoot(array $root, array $columns): mixed
    {
        $existing = DB::table('menus')->where('key', $root['key'])->first();
        if ($existing && ($root['preserve_existing_parent'] ?? false) === true) {
            self::activateExistingRoot($existing, $columns);
            return $existing->id ?? null;
        }

        self::upsertByKey($root, null, $columns);
        return isset($columns['id']) ? DB::table('menus')->where('key', $root['key'])->value('id') : null;
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns */
    private static function upsertChild(array $item, mixed $parentId, array $columns): void
    {
        $existing = self::findExisting($item);
        if ($existing) {
            self::updateExisting($existing, $item, $parentId, $columns);
            return;
        }
        self::upsertByKey($item, $parentId, $columns);
    }

    /** @param array<string,mixed> $item */
    private static function findExisting(array $item): ?object
    {
        $byKey = DB::table('menus')->where('key', $item['key'])->first();
        if ($byKey) {
            return $byKey;
        }

        // Compatibility path: adopt the actual pre-extraction CRM row by its named route.
        $routeQuery = DB::table('menus')->where('route', $item['route']);
        if (Schema::hasColumn('menus', 'parent_id')) {
            // Never adopt a root row merely because a child intentionally shares its route.
            $routeQuery->whereNotNull('parent_id');
        }
        return $routeQuery->first();
    }

    /** @param object $existing @param array<string,int> $columns */
    private static function activateExistingRoot(object $existing, array $columns): void
    {
        $data = [];
        if (isset($columns['is_active'])) $data['is_active'] = 1;
        if (isset($columns['updated_at'])) $data['updated_at'] = now();
        if ($data === []) return;

        $query = isset($existing->id)
            ? DB::table('menus')->where('id', $existing->id)
            : DB::table('menus')->where('key', $existing->key);
        $query->update($data);
    }

    /** @param object $existing @param array<string,mixed> $item @param array<string,int> $columns */
    private static function updateExisting(object $existing, array $item, mixed $parentId, array $columns): void
    {
        $data = self::data($item, $parentId, $columns);
        $query = isset($existing->id)
            ? DB::table('menus')->where('id', $existing->id)
            : DB::table('menus')->where('key', $existing->key);
        $query->update($data);
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns */
    private static function upsertByKey(array $item, mixed $parentId, array $columns): void
    {
        $data = self::data($item, $parentId, $columns);
        $query = DB::table('menus')->where('key', $item['key']);
        if ($query->exists()) {
            $query->update($data);
            return;
        }

        $insert = ['key' => $item['key']] + $data;
        if (isset($columns['created_at'])) {
            $insert['created_at'] = now();
        }
        DB::table('menus')->insert(array_intersect_key($insert, $columns));
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns @return array<string,mixed> */
    private static function data(array $item, mixed $parentId, array $columns): array
    {
        $data = [
            'parent_id' => $parentId,
            'route' => $item['route'] ?? null,
            'route_slug' => null,
            'label' => $item['label'] ?? $item['key'],
            'icon' => self::safeIcon((string) ($item['icon'] ?? '')),
            'svg' => null,
            'order' => (int) ($item['order'] ?? 0),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 0,
            'updated_at' => now(),
        ];
        return array_intersect_key($data, $columns);
    }

    private static function safeIcon(string $icon): string
    {
        return in_array($icon, self::HOST_SAFE_ICONS, true) ? $icon : 'tabler-folders';
    }

    private static function menuTableAvailable(): bool
    {
        return Schema::hasTable('menus') && Schema::hasColumn('menus', 'key');
    }

    private static function invalidateHostMenuCache(): void
    {
        if (! class_exists(\App\Services\Common\MenuService::class)) {
            return;
        }
        try {
            $menuService = app(\App\Services\Common\MenuService::class);
            if (method_exists($menuService, 'regenerate')) {
                $menuService->regenerate();
            }
        } catch (\Throwable) {
            // Persisted menu rows are authoritative; cache invalidation must not block install/boot.
        }
    }
}
