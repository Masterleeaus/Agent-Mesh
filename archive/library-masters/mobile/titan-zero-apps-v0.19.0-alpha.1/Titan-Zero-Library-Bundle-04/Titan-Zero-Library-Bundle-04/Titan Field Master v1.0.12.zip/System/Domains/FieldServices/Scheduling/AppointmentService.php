<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class AppointmentService
{
    public function __construct(private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private AppointmentWindowPolicy $window,private SchedulingKernel $scheduling,private FieldReferenceIntegrity $integrity) {}

    public function schedule(int $userId,array $data): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $idk=trim((string)($data['idempotency_key']??''));
        if($idk!==''&&($e=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('idempotency_key',$idk)->whereNull('deleted_at')->first()))return (array)$e;
        $this->integrity->assertContext($userId,$data);
        $normal=$this->window->normalise((string)($data['scheduled_start']??''),(string)($data['scheduled_end']??''),(string)($data['timezone']??config('titan-field.field_services.default_timezone','UTC')));

        $workOrderPublicId=(string)($data['work_order_public_id']??'');$servicePublicId=(string)($data['service_public_id']??'');$locationPublicId=(string)($data['location_public_id']??'');
        if($workOrderPublicId!==''){
            $work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();
            if($work){$servicePublicId=$servicePublicId!==''?$servicePublicId:(string)($work->service_public_id??'');$locationPublicId=$locationPublicId!==''?$locationPublicId:(string)($work->location_public_id??'');}
        }
        $this->scheduling->assertSchedulable($userId,isset($data['assigned_user_id'])?(int)$data['assigned_user_id']:null,$normal['scheduled_start'],$normal['scheduled_end'],[
            'service_public_id'=>$servicePublicId,'work_order_public_id'=>$workOrderPublicId,'location_public_id'=>$locationPublicId,'travel_buffer_minutes'=>$data['travel_buffer_minutes']??null,
        ]);

        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($userId,$tenant,$publicId,$workOrderPublicId,$locationPublicId,$data,$normal,$idk):array{
            $this->db->table('crm_appointments')->insert([
                'public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>$this->tenantContext->actorUserId($userId),'work_order_public_id'=>$workOrderPublicId!==''?$workOrderPublicId:null,
                'service_request_public_id'=>$data['service_request_public_id']??null,'location_public_id'=>$locationPublicId!==''?$locationPublicId:null,'title'=>$data['title']??'Service appointment','status'=>$data['status']??'scheduled',
                'scheduled_start'=>$normal['scheduled_start'],'scheduled_end'=>$normal['scheduled_end'],'timezone'=>$normal['timezone'],'assigned_user_id'=>$data['assigned_user_id']??null,
                'customer_notes'=>$data['customer_notes']??null,'internal_notes'=>$data['internal_notes']??null,'idempotency_key'=>$idk!==''?$idk:null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()
            ]);
            $record=(array)$this->db->table('crm_appointments')->where('company_id',$tenant)->where('public_id',$publicId)->first();
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']=$idk!==''?'appointment.scheduled:'.$idk:'appointment.scheduled:'.$publicId;
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.appointment.scheduled','appointment',$publicId,['work_order_public_id'=>$record['work_order_public_id']??null,'assigned_user_id'=>$record['assigned_user_id']??null,'scheduled_start'=>$record['scheduled_start']??null,'scheduled_end'=>$record['scheduled_end']??null],$ctx);
            return $record;
        });
    }

    public function reschedule(int $userId,string $publicId,array $data): array
    {
        $tenant=$this->tenantContext->companyId($userId);
        $existing=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$existing)throw new \InvalidArgumentException('Appointment not found.');
        $start=(string)($data['scheduled_start']??$existing->scheduled_start);$end=(string)($data['scheduled_end']??$existing->scheduled_end);$timezone=(string)($data['timezone']??$existing->timezone??config('titan-field.field_services.default_timezone','UTC'));
        $normal=$this->window->normalise($start,$end,$timezone);
        $worker=array_key_exists('assigned_user_id',$data)?($data['assigned_user_id']===null?null:(int)$data['assigned_user_id']):($existing->assigned_user_id===null?null:(int)$existing->assigned_user_id);
        $servicePublicId=''; if(!empty($existing->work_order_public_id)){$work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$existing->work_order_public_id)->whereNull('deleted_at')->first();$servicePublicId=(string)($work->service_public_id??'');}
        $this->scheduling->assertSchedulable($userId,$worker,$normal['scheduled_start'],$normal['scheduled_end'],[
            'appointment_public_id'=>$publicId,'work_order_public_id'=>(string)($existing->work_order_public_id??''),'location_public_id'=>(string)($existing->location_public_id??''),'service_public_id'=>$servicePublicId,'travel_buffer_minutes'=>$data['travel_buffer_minutes']??null,
        ]);
        return $this->db->transaction(function()use($userId,$tenant,$publicId,$normal,$worker,$data):array{
            $row=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->lockForUpdate()->first();if(!$row)throw new \InvalidArgumentException('Appointment not found.');
            $before=['scheduled_start'=>$row->scheduled_start,'scheduled_end'=>$row->scheduled_end,'assigned_user_id'=>$row->assigned_user_id];
            $this->db->table('crm_appointments')->where('company_id',$tenant)->where('id',$row->id)->update(['scheduled_start'=>$normal['scheduled_start'],'scheduled_end'=>$normal['scheduled_end'],'timezone'=>$normal['timezone'],'assigned_user_id'=>$worker,'updated_at'=>now()]);
            $record=(array)$this->db->table('crm_appointments')->where('company_id',$tenant)->where('id',$row->id)->first();$ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.appointment.rescheduled','appointment',$publicId,['before'=>$before,'after'=>['scheduled_start'=>$record['scheduled_start'],'scheduled_end'=>$record['scheduled_end'],'assigned_user_id'=>$record['assigned_user_id']]],$ctx);
            return $record;
        });
    }

    public function search(int $userId,array $filters=[],int $limit=100): array
    { $q=$this->db->table('crm_appointments')->where('company_id',$this->tenantContext->companyId($userId))->whereNull('deleted_at');foreach(['status','assigned_user_id','work_order_public_id','location_public_id'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]);if(isset($filters['from']))$q->where('scheduled_end','>=',$filters['from']);if(isset($filters['to']))$q->where('scheduled_start','<=',$filters['to']);return $q->orderBy('scheduled_start')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all(); }
}
