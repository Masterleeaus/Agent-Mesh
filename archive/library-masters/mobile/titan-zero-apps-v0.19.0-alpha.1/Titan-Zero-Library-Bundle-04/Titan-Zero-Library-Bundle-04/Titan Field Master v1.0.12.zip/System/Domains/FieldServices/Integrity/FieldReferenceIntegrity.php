<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Integrity;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

/**
 * Fail-closed tenant/reference integrity gate for Titan Field mutations.
 *
 * Historical crm_* table names remain intact for upgrade compatibility, but
 * every supplied public-id relationship is resolved inside the active tenant
 * before any mutation is allowed to persist it.
 */
final class FieldReferenceIntegrity
{
    /** @var array<string,string> */
    private const REFERENCES=[
        'company_public_id'=>'crm_companies',
        'contact_public_id'=>'crm_contacts',
        'location_public_id'=>'crm_service_locations',
        'asset_public_id'=>'crm_customer_assets',
        'service_public_id'=>'crm_services',
        'service_request_public_id'=>'crm_service_requests',
        'work_order_public_id'=>'crm_work_orders',
        'appointment_public_id'=>'crm_appointments',
        'form_public_id'=>'crm_form_templates',
        'template_public_id'=>'crm_form_templates',
        'form_submission_public_id'=>'crm_form_submissions',
        'review_request_public_id'=>'crm_review_requests',
        'review_public_id'=>'crm_reviews',
        'service_area_public_id'=>'crm_service_areas',
        'agreement_public_id'=>'crm_service_agreements',
        'lead_public_id'=>'crm_leads',
        'deal_public_id'=>'crm_deals',
        'category_public_id'=>'crm_service_categories',
        'support_ticket_public_id'=>'crm_support_tickets',
        'recovery_public_id'=>'crm_service_recovery_cases',
    ];

    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db) {}

    /** @param array<string,mixed> $data */
    public function assertContext(int $userId,array $data,array $fields=[]): void
    {
        $fields=$fields!==[]?$fields:array_keys(self::REFERENCES);
        foreach($fields as $field){
            if(!array_key_exists($field,$data))continue;
            $this->assertReference($userId,(string)$field,$data[$field]);
        }
        $this->assertContactCompanyOwnership($userId,$data);
        $this->assertLocationOwnership($userId,$data);
        $this->assertAssetOwnership($userId,$data);
        $this->assertWorkOrderRelationships($userId,$data);
        $this->assertAppointmentRelationships($userId,$data);
    }

    public function assertReference(int $userId,string $field,mixed $value): void
    {
        if($value===null||trim((string)$value)==='')return;
        $table=self::REFERENCES[$field]??null;
        if($table===null)throw new InvalidArgumentException("Unsupported Titan Field reference: {$field}.");
        $tenant=$this->tenantContext->companyId($userId);
        $query=$this->db->table($table)->where('company_id',$tenant)->where('public_id',(string)$value);
        if($this->hasColumn($table,'deleted_at'))$query->whereNull('deleted_at');
        if(!$query->exists())throw new InvalidArgumentException("Linked {$field} record was not found in the active tenant.");
    }

    public function assertTenantUser(int $userId,?int $candidateUserId): void
    {
        if($candidateUserId===null)return;
        if($candidateUserId<=0)throw new InvalidArgumentException('A valid tenant user id is required.');
        $actor=$this->tenantContext->actorUserId($userId);
        if($actor!==null&&$actor===$candidateUserId)return;
        if(!$this->tenantContext->userBelongsToTenant($userId,$candidateUserId))throw new InvalidArgumentException('Referenced user does not belong to the active tenant.');
    }

    public function assertWorker(int $userId,?int $workerUserId,bool $requireActive=true): void
    {
        if($workerUserId===null)return;
        if($workerUserId<=0)throw new InvalidArgumentException('A valid worker user id is required.');
        $tenant=$this->tenantContext->companyId($userId);
        $profile=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('worker_user_id',$workerUserId)->first();
        if(!$profile)throw new InvalidArgumentException('Assigned worker is not registered for the active tenant.');
        if($requireActive&&!(bool)($profile->active??false))throw new InvalidArgumentException('Assigned worker is not active for field operations.');
    }

    public function assertServiceList(int $userId,mixed $value): void
    {
        $this->assertReferenceList($userId,'service_public_id',$value);
    }

    public function assertReferenceList(int $userId,string $field,mixed $value): void
    {
        foreach($this->normaliseList($value) as $publicId)$this->assertReference($userId,$field,$publicId);
    }

    /** @param array<string,mixed> $data */
    public function assertLocationOwnership(int $userId,array $data): void
    {
        $locationPublicId=trim((string)($data['location_public_id']??''));
        if($locationPublicId==='')return;
        $tenant=$this->tenantContext->companyId($userId);
        $location=$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$locationPublicId)->whereNull('deleted_at')->first();
        if(!$location)return;
        foreach(['company_public_id','contact_public_id'] as $field){
            $supplied=trim((string)($data[$field]??''));$owned=trim((string)($location->{$field}??''));
            if($supplied!==''&&$owned!==''&&$supplied!==$owned)throw new InvalidArgumentException("Linked location does not belong to the supplied {$field}.");
        }
    }

    /** @param array<string,mixed> $data */
    public function assertAssetOwnership(int $userId,array $data): void
    {
        $assetPublicId=trim((string)($data['asset_public_id']??''));
        if($assetPublicId==='')return;
        $tenant=$this->tenantContext->companyId($userId);
        $asset=$this->db->table('crm_customer_assets')->where('company_id',$tenant)->where('public_id',$assetPublicId)->whereNull('deleted_at')->first();
        if(!$asset)return;
        foreach(['company_public_id','contact_public_id','location_public_id'] as $field){
            $supplied=trim((string)($data[$field]??''));$owned=trim((string)($asset->{$field}??''));
            if($supplied!==''&&$owned!==''&&$supplied!==$owned)throw new InvalidArgumentException("Linked asset does not belong to the supplied {$field}.");
        }
    }

    /** @param array<string,mixed> $data */
    private function assertContactCompanyOwnership(int $userId,array $data): void
    {
        $contactPublicId=trim((string)($data['contact_public_id']??''));$companyPublicId=trim((string)($data['company_public_id']??''));
        if($contactPublicId===''||$companyPublicId==='')return;
        $tenant=$this->tenantContext->companyId($userId);
        $company=$this->db->table('crm_companies')->where('company_id',$tenant)->where('public_id',$companyPublicId)->whereNull('deleted_at')->first();
        $contact=$this->db->table('crm_contacts')->where('company_id',$tenant)->where('public_id',$contactPublicId)->whereNull('deleted_at')->first();
        if(!$company||!$contact)return;
        $companyId=(int)($contact->company_id??0);
        if($companyId>0&&$companyId!==(int)$company->id)throw new InvalidArgumentException('Linked contact does not belong to the supplied company.');
    }

    /** @param array<string,mixed> $data */
    private function assertWorkOrderRelationships(int $userId,array $data): void
    {
        $workOrderPublicId=trim((string)($data['work_order_public_id']??''));
        if($workOrderPublicId==='')return;
        $tenant=$this->tenantContext->companyId($userId);
        $work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();
        if(!$work)return;
        foreach(['service_request_public_id','company_public_id','contact_public_id','location_public_id','asset_public_id','service_public_id'] as $field){
            $supplied=trim((string)($data[$field]??''));$owned=trim((string)($work->{$field}??''));
            if($supplied!==''&&$supplied!==$owned)throw new InvalidArgumentException("Linked work order conflicts with supplied {$field}.");
        }
    }

    /** @param array<string,mixed> $data */
    private function assertAppointmentRelationships(int $userId,array $data): void
    {
        $appointmentPublicId=trim((string)($data['appointment_public_id']??''));
        if($appointmentPublicId==='')return;
        $tenant=$this->tenantContext->companyId($userId);
        $appointment=$this->db->table('crm_appointments')->where('company_id',$tenant)->where('public_id',$appointmentPublicId)->whereNull('deleted_at')->first();
        if(!$appointment)return;
        foreach(['work_order_public_id','service_request_public_id','location_public_id'] as $field){
            $supplied=trim((string)($data[$field]??''));$owned=trim((string)($appointment->{$field}??''));
            if($supplied!==''&&$supplied!==$owned)throw new InvalidArgumentException("Linked appointment conflicts with supplied {$field}.");
        }
    }

    /** @return list<string> */
    private function normaliseList(mixed $value): array
    {
        if($value===null||$value==='')return [];
        if(is_array($value))$items=$value;
        elseif(is_string($value)){
            $trim=trim($value);if($trim==='')return [];
            if(str_starts_with($trim,'[')){ $decoded=json_decode($trim,true);$items=is_array($decoded)?$decoded:[]; }
            else $items=explode(',',$trim);
        } else throw new InvalidArgumentException('Reference list must be an array, JSON array or comma-separated string.');
        $items=array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),$items),static fn($v)=>$v!=='')));
        return $items;
    }

    private function hasColumn(string $table,string $column): bool
    {
        try{return $this->db->getSchemaBuilder()->hasColumn($table,$column);}catch(\Throwable){return false;}
    }
}
