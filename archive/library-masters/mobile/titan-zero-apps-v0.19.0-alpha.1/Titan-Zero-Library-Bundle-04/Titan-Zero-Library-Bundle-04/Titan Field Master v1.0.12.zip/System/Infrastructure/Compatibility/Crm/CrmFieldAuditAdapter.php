<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm;

use App\Extensions\Crm\System\Services\CrmAuditRecorder;
use App\Extensions\TitanField\System\Contracts\FieldAuditPort;

final class CrmFieldAuditAdapter implements FieldAuditPort
{
    public function __construct(private CrmAuditRecorder $audit) {}

    public function record(
        int $userId,
        ?int $actorUserId,
        string $action,
        ?string $subjectType = null,
        ?string $subjectPublicId = null,
        ?array $before = null,
        ?array $after = null,
        array $context = [],
    ): void {
        $this->audit->record($userId, $actorUserId, $action, $subjectType, $subjectPublicId, $before, $after, $context);
    }
}
