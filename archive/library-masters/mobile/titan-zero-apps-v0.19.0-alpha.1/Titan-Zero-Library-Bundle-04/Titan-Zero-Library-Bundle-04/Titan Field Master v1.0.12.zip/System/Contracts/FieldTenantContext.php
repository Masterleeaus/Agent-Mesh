<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldTenantContext
{
    public function companyId(int $userId): int;

    public function actorUserId(int $userId): ?int;

    public function userBelongsToTenant(int $userId,int $candidateUserId): bool;
}
