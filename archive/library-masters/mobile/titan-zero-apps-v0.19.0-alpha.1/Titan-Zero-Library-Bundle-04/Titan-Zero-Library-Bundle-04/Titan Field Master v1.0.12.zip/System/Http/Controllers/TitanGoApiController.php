<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Controllers;

use App\Extensions\TitanField\System\Contracts\FieldCommandGateway;
use App\Extensions\TitanField\System\Domains\FieldServices\Offline\OfflineFieldRuntime;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

final class TitanGoApiController
{
    public function __construct(private OfflineFieldRuntime $offline, private FieldCommandGateway $commands) {}

    public function context(Request $request): JsonResponse
    {
        $data=$request->validate(['horizon_days'=>'nullable|integer|min:1|max:14']);
        return response()->json(['data'=>$this->offline->mobileContext((int)$request->user()->id,(int)$request->user()->id,(int)($data['horizon_days']??7))]);
    }

    public function registerDevice(Request $request): JsonResponse
    {
        $data=$request->validate(['device_id'=>'nullable|string|max:191','device_name'=>'nullable|string|max:180','platform'=>'nullable|string|max:80','app_version'=>'nullable|string|max:80','metadata'=>'nullable|array']);
        $deviceId=trim((string)($data['device_id']??$request->header('X-Titan-Device-Id','')));if($deviceId==='')throw new InvalidArgumentException('X-Titan-Device-Id or device_id is required.');
        $device=$this->offline->registerDevice((int)$request->user()->id,(int)$request->user()->id,$deviceId,$data);
        return response()->json(['data'=>$device],201);
    }

    public function replay(Request $request): JsonResponse
    {
        $data=$request->validate(['operation_id'=>'nullable|string|max:191','operation'=>'required|string|max:120','occurred_at'=>'required|date','entity_type'=>'nullable|string|max:80','entity_public_id'=>'nullable|string|max:191','base_entity_version'=>'nullable|integer|min:1','payload'=>'nullable|array','trace_id'=>'nullable|string|max:64','correlation_id'=>'nullable|string|max:64','causation_id'=>'nullable|string|max:64','device_id'=>'nullable|string|max:191']);
        $data['device_id']=trim((string)($data['device_id']??$request->header('X-Titan-Device-Id','')));$data['operation_id']=trim((string)($data['operation_id']??$request->header('X-Titan-Operation-Id','')));
        $receipt=$this->offline->replay((int)$request->user()->id,(int)$request->user()->id,$data);
        return response()->json(['data'=>$receipt],($receipt['status']??'')==='conflict'?409:200);
    }

    public function sync(Request $request): JsonResponse
    {
        $data=$request->validate(['operations'=>'required|array|min:1|max:100','operations.*'=>'array']);$device=(string)$request->header('X-Titan-Device-Id','');
        $operations=array_map(static function(array $op)use($device):array{if(!isset($op['device_id'])||trim((string)$op['device_id'])==='')$op['device_id']=$device;return $op;},$data['operations']);
        return response()->json(['data'=>$this->offline->replayBatch((int)$request->user()->id,(int)$request->user()->id,$operations)]);
    }

    public function evidence(Request $request): JsonResponse
    {
        $data=$request->validate(['file'=>'required|file|max:20480|mimes:jpg,jpeg,png,webp,pdf','work_order_public_id'=>'required|string|size:26','form_submission_public_id'=>'nullable|string|size:26','evidence_type'=>'nullable|in:photo,document,signature,certificate,other','latitude'=>'nullable|numeric|between:-90,90','longitude'=>'nullable|numeric|between:-180,180','captured_at'=>'nullable|date','base_entity_version'=>'nullable|integer|min:1','device_id'=>'nullable|string|max:191','operation_id'=>'nullable|string|max:191']);
        $deviceId=trim((string)($data['device_id']??$request->header('X-Titan-Device-Id','')));$operationId=trim((string)($data['operation_id']??$request->header('X-Titan-Operation-Id','')));if($deviceId===''||$operationId==='')throw new InvalidArgumentException('X-Titan-Device-Id and X-Titan-Operation-Id are required for Titan Go evidence replay.');
        $receipt=$this->offline->storeUploadedEvidence((int)$request->user()->id,(int)$request->user()->id,$deviceId,$operationId,$request->file('file'),array_diff_key($data,['file'=>true,'device_id'=>true,'operation_id'=>true,'base_entity_version'=>true]));
        return response()->json(['data'=>$receipt],201);
    }
}
