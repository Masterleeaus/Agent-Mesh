<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Forecasting;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

/** Evidence-backed capacity forecast. Read-only: it never creates, assigns or reschedules work. */
final class CapacityForecastService
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private SpatialIntelligenceGateway $spatial,
        private CapacityForecastCalculator $calculator,
        private ConnectionInterface $db,
    ) {}

    /** @return array<string,mixed> */
    public function forecast(int $userId, string $from, int $days=14): array
    {
        if($days<1||$days>60)throw new InvalidArgumentException('Capacity forecast horizon must be between 1 and 60 days.');
        $tenant=$this->tenantContext->companyId($userId);
        $forecastTimezone=(string)config('titan-field.field_services.default_timezone','Australia/Melbourne');$start=CarbonImmutable::parse($from,$forecastTimezone)->startOfDay();$end=$start->addDays($days);
        $workers=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('active',true)->orderBy('worker_user_id')->get()->map(fn($r)=>(array)$r)->all();
        $workerHorizon=[];$daily=[];$horizonAvailable=0;$horizonBooked=0;
        foreach($workers as $worker)$workerHorizon[(int)$worker['worker_user_id']]=['available_minutes'=>0,'booked_minutes'=>0,'remaining_minutes'=>0,'skills'=>$this->list($worker['skills']??null)];

        for($i=0;$i<$days;$i++){
            $day=$start->addDays($i);$dayAvailable=0;$dayBooked=0;$workerRows=[];
            foreach($workers as $worker){
                $id=(int)$worker['worker_user_id'];$available=$this->availableMinutes($tenant,$worker,$day);$booked=$this->bookedMinutes($tenant,$id,$day,(string)($worker['timezone']??'Australia/Melbourne'));
                $remaining=max(0,$available-$booked);$workerRows[]=['worker_user_id'=>$id,'available_minutes'=>$available,'booked_minutes'=>$booked,'remaining_minutes'=>$remaining,'utilization_percent'=>$available>0?round(($booked/$available)*100,2):($booked>0?100.0:0.0)];
                $workerHorizon[$id]['available_minutes']+=$available;$workerHorizon[$id]['booked_minutes']+=$booked;$workerHorizon[$id]['remaining_minutes']+=$remaining;$dayAvailable+=$available;$dayBooked+=$booked;
            }
            $daily[]=['date'=>$day->toDateString(),'team'=>$this->calculator->calculate(['available_minutes'=>$dayAvailable,'booked_minutes'=>$dayBooked,'unfilled_demand_minutes'=>0,'spatial_travel_burden_minutes'=>null,'spatial_uncovered_demand_count'=>0]),'workers'=>$workerRows];
            $horizonAvailable+=$dayAvailable;$horizonBooked+=$dayBooked;
        }

        $demand=$this->unfilledDemand($tenant);$unfilledMinutes=array_sum(array_column($demand,'duration_minutes'));
        $demandPoints=[];foreach($demand as $item){if($item['latitude']===null||$item['longitude']===null)continue;$demandPoints[]=['reference_type'=>$item['source_type'],'public_reference_id'=>$item['public_id'],'latitude'=>$item['latitude'],'longitude'=>$item['longitude'],'service_area_public_id'=>$item['service_area_public_id'],'postcode'=>$item['postcode'],'service_public_id'=>$item['service_public_id']];if(count($demandPoints)>=20)break;}
        $spatialPressure=$this->spatial->capacityPressureEvidence($userId,['from'=>$start->toIso8601String(),'to'=>$end->toIso8601String(),'worker_user_ids'=>array_keys($workerHorizon),'demand_points'=>$demandPoints]);
        $burdenSeconds=$spatialPressure['capacity_adjustment_seconds']??null;$burdenMinutes=is_numeric($burdenSeconds)?(int)ceil(max(0,(int)$burdenSeconds)/60):null;
        $summary=$this->calculator->calculate(['available_minutes'=>$horizonAvailable,'booked_minutes'=>$horizonBooked,'unfilled_demand_minutes'=>$unfilledMinutes,'spatial_travel_burden_minutes'=>$burdenMinutes,'spatial_uncovered_demand_count'=>(int)($spatialPressure['uncovered_demand_count']??0)]);
        $skillPressure=$this->skillPressure($tenant,$demand,$workerHorizon);
        $serviceAreaPressure=$this->serviceAreaPressure($demand,$spatialPressure);

        return [
            'from'=>$start->toDateString(),'to'=>$end->subDay()->toDateString(),'days'=>$days,'generated_at'=>now()->toIso8601String(),
            'forecast_policy'=>'titan.field.capacity.v1','authoritative'=>false,'mutation'=>'none','capacity_basis'=>'availability_minus_bookings_with_advisory_spatial_travel_adjustment',
            'summary'=>$summary,'daily'=>$daily,'workers'=>array_values(array_map(fn($id,$x)=>['worker_user_id'=>$id]+$x,array_keys($workerHorizon),$workerHorizon)),
            'unfilled_demand_count'=>count($demand),'unfilled_demand_minutes'=>$unfilledMinutes,'demand'=>$demand,
            'skill_pressure'=>$skillPressure,'service_area_pressure'=>$serviceAreaPressure,'spatial_pressure'=>$spatialPressure,
            'recommendations'=>$summary['recommendations'],
        ];
    }

    private function availableMinutes(int $tenant,array $worker,CarbonImmutable $day): int
    {
        $id=(int)$worker['worker_user_id'];$timezone=(string)($worker['timezone']??config('titan-field.field_services.default_timezone','Australia/Melbourne'));$local=CarbonImmutable::parse($day->toDateString(),$timezone)->startOfDay();$max=max(1,(int)($worker['max_daily_minutes']??720));$minutes=null;
        if(Schema::hasTable('titan_field_worker_availability_rules')){
            $hasRules=$this->db->table('titan_field_worker_availability_rules')->where('company_id',$tenant)->where('worker_user_id',$id)->where('active',true)->exists();
            if($hasRules){$date=$local->toDateString();$rules=$this->db->table('titan_field_worker_availability_rules')->where('company_id',$tenant)->where('worker_user_id',$id)->where('active',true)->where('day_of_week',$local->isoWeekday())->where(function($q)use($date){$q->whereNull('effective_from')->orWhere('effective_from','<=',$date);})->where(function($q)use($date){$q->whereNull('effective_until')->orWhere('effective_until','>=',$date);})->get();$minutes=0;foreach($rules as $r){$a=$local->startOfDay()->setTimeFromTimeString((string)$r->starts_at);$b=$local->startOfDay()->setTimeFromTimeString((string)$r->ends_at);if($b->greaterThan($a))$minutes+=$a->diffInMinutes($b);}}
        }
        if($minutes===null){$weekly=$this->assoc($worker['weekly_availability']??null);if($weekly!==[]){$minutes=0;$keys=[strtolower($local->format('D')),(string)$local->dayOfWeek,(string)$local->isoWeekday()];$windows=[];foreach($keys as $k){if(isset($weekly[$k])){$windows=(array)$weekly[$k];break;}}foreach($windows as $w){$w=(array)$w;$a=(string)($w['start']??$w['opens_at']??'');$b=(string)($w['end']??$w['closes_at']??'');if($a===''||$b==='')continue;$s=$local->startOfDay()->setTimeFromTimeString($a);$e=$local->startOfDay()->setTimeFromTimeString($b);if($e->greaterThan($s))$minutes+=$s->diffInMinutes($e);}}}
        if($minutes===null)$minutes=$max;$minutes=min($max,max(0,$minutes));
        return max(0,$minutes-$this->blockedMinutes($tenant,$id,$local,$timezone));
    }

    private function blockedMinutes(int $tenant,int $worker,CarbonImmutable $local,string $timezone): int
    {
        $from=$local->startOfDay()->utc();$to=$local->endOfDay()->utc();$ranges=[];
        foreach([['crm_field_worker_time_off','status'],['titan_field_worker_availability_exceptions','status']] as [$table,$status]){if(!Schema::hasTable($table))continue;foreach($this->db->table($table)->where('company_id',$tenant)->where('worker_user_id',$worker)->where($status,'approved')->where('starts_at','<',$to)->where('ends_at','>',$from)->get(['starts_at','ends_at']) as $r)$ranges[]=[CarbonImmutable::parse($r->starts_at)->utc(),CarbonImmutable::parse($r->ends_at)->utc()];}
        if(Schema::hasTable('titan_field_blackout_policies'))foreach($this->db->table('titan_field_blackout_policies')->where('company_id',$tenant)->where('active',true)->where('starts_at','<',$to)->where('ends_at','>',$from)->where(function($q)use($worker){$q->where('scope_type','business')->orWhere(function($x)use($worker){$x->where('scope_type','worker')->where('scope_public_id',(string)$worker);});})->get(['starts_at','ends_at']) as $r)$ranges[]=[CarbonImmutable::parse($r->starts_at)->utc(),CarbonImmutable::parse($r->ends_at)->utc()];
        if($ranges===[])return 0;usort($ranges,fn($a,$b)=>$a[0]<=>$b[0]);$merged=[];foreach($ranges as [$a,$b]){$a=$a->greaterThan($from)?$a:$from;$b=$b->lessThan($to)?$b:$to;if(!$b->greaterThan($a))continue;if($merged===[]||$a->greaterThan($merged[count($merged)-1][1]))$merged[]=[$a,$b];elseif($b->greaterThan($merged[count($merged)-1][1]))$merged[count($merged)-1][1]=$b;}$m=0;foreach($merged as [$a,$b])$m+=$a->diffInMinutes($b);return $m;
    }

    private function bookedMinutes(int $tenant,int $worker,CarbonImmutable $day,string $timezone): int
    {
        $local=CarbonImmutable::parse($day->toDateString(),$timezone)->startOfDay();$from=$local->startOfDay()->utc();$to=$local->endOfDay()->utc();$m=0;
        foreach($this->db->table('crm_appointments')->where('company_id',$tenant)->where('assigned_user_id',$worker)->whereNull('deleted_at')->whereNotIn('status',['cancelled'])->where('scheduled_start','<',$to)->where('scheduled_end','>',$from)->get(['scheduled_start','scheduled_end']) as $r){$a=CarbonImmutable::parse($r->scheduled_start)->utc();$b=CarbonImmutable::parse($r->scheduled_end)->utc();$a=$a->greaterThan($from)?$a:$from;$b=$b->lessThan($to)?$b:$to;if($b->greaterThan($a))$m+=$a->diffInMinutes($b);}return $m;
    }

    /** @return array<int,array<string,mixed>> */
    private function unfilledDemand(int $tenant): array
    {
        $services=[];foreach($this->db->table('crm_services')->where('company_id',$tenant)->whereNull('deleted_at')->get(['public_id','default_duration_minutes','required_skills','name']) as $s)$services[(string)$s->public_id]=(array)$s;
        $locations=[];foreach($this->db->table('crm_service_locations')->where('company_id',$tenant)->whereNull('deleted_at')->get(['public_id','service_area_public_id','postcode','latitude','longitude']) as $l)$locations[(string)$l->public_id]=(array)$l;
        $items=[];
        $orders=$this->db->table('crm_work_orders')->where('company_id',$tenant)->whereNull('deleted_at')->whereNotIn('status',['completed','closed','cancelled'])->where(function($q){$q->whereNull('scheduled_start')->orWhereNull('assigned_user_id');})->limit(500)->get();
        foreach($orders as $r)$items[]=$this->demandItem('job',(array)$r,$services,$locations);
        $converted=$this->db->table('crm_work_orders')->where('company_id',$tenant)->whereNull('deleted_at')->whereNotNull('service_request_public_id')->pluck('service_request_public_id')->all();
        $rq=$this->db->table('crm_service_requests')->where('company_id',$tenant)->whereNull('deleted_at')->whereNotIn('status',['resolved','cancelled']);if($converted!==[])$rq->whereNotIn('public_id',$converted);
        foreach($rq->limit(500)->get() as $r)$items[]=$this->demandItem('service_request',(array)$r,$services,$locations);
        return $items;
    }

    /** @param array<string,array<string,mixed>> $services @param array<string,array<string,mixed>> $locations @return array<string,mixed> */
    private function demandItem(string $type,array $row,array $services,array $locations): array
    {
        $serviceId=(string)($row['service_public_id']??'');$service=$services[$serviceId]??[];$locationId=(string)($row['location_public_id']??'');$loc=$locations[$locationId]??[];
        return ['source_type'=>$type,'public_id'=>(string)$row['public_id'],'service_public_id'=>$serviceId?:null,'service_name'=>$service['name']??null,'location_public_id'=>$locationId?:null,'service_area_public_id'=>$loc['service_area_public_id']??null,'postcode'=>$loc['postcode']??null,'latitude'=>isset($loc['latitude'])&&$loc['latitude']!==null?(float)$loc['latitude']:null,'longitude'=>isset($loc['longitude'])&&$loc['longitude']!==null?(float)$loc['longitude']:null,'duration_minutes'=>max(1,(int)($service['default_duration_minutes']??60)),'required_skills'=>$this->list($service['required_skills']??null),'priority'=>$row['priority']??'normal'];
    }

    /** @param array<int,array<string,mixed>> $demand @param array<int,array<string,mixed>> $workers @return array<int,array<string,mixed>> */
    private function skillPressure(int $tenant,array $demand,array $workers): array
    {
        $groups=[];foreach($demand as $d){$key=(string)($d['service_public_id']??'unclassified');$groups[$key]['demand_minutes']=($groups[$key]['demand_minutes']??0)+(int)$d['duration_minutes'];$groups[$key]['required_skills']=$d['required_skills'];}
        $out=[];foreach($groups as $service=>$g){$eligible=0;$eligibleWorkers=0;foreach($workers as $w){$missing=array_diff((array)$g['required_skills'],(array)$w['skills']);if($missing===[]){$eligible+=(int)$w['remaining_minutes'];$eligibleWorkers++;}}$out[]=['service_public_id'=>$service==='unclassified'?null:$service,'required_skills'=>$g['required_skills'],'demand_minutes'=>$g['demand_minutes'],'eligible_worker_count'=>$eligibleWorkers,'eligible_remaining_minutes_upper_bound'=>$eligible,'shortage_minutes_upper_bound'=>max(0,(int)$g['demand_minutes']-$eligible),'basis'=>'upper_bound_remaining_minutes_not_reserved_across_services'];}return $out;
    }

    /** @param array<int,array<string,mixed>> $demand @return array<int,array<string,mixed>> */
    private function serviceAreaPressure(array $demand,array $spatial): array
    {
        $g=[];foreach($demand as $d){$key=(string)($d['service_area_public_id']??($d['postcode']?'postcode:'.$d['postcode']:'unassigned'));$g[$key]['count']=($g[$key]['count']??0)+1;$g[$key]['minutes']=($g[$key]['minutes']??0)+(int)$d['duration_minutes'];}$out=[];foreach($g as $key=>$v)$out[]=['service_area_key'=>$key,'unfilled_demand_count'=>$v['count'],'unfilled_demand_minutes'=>$v['minutes'],'spatial_evidence_basis'=>$spatial['basis']??'unavailable'];return $out;
    }

    /** @return list<string> */ private function list(mixed $v): array{$a=is_array($v)?$v:(is_string($v)?(json_decode($v,true)?:[]):[]);return array_values(array_unique(array_filter(array_map(fn($x)=>strtolower(trim((string)$x)),is_array($a)?$a:[]))));}
    /** @return array<string,mixed> */ private function assoc(mixed $v): array{$a=is_array($v)?$v:(is_string($v)?json_decode($v,true):[]);return is_array($a)?$a:[];}
}
