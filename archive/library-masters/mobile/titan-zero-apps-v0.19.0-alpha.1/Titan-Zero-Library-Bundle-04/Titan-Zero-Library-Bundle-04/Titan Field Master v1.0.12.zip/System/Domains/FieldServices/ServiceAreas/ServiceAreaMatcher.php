<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\ServiceAreas;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ServiceAreaMatcher
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db,private FieldReferenceIntegrity $integrity) {}

    /** @return list<array<string,mixed>> */
    public function list(int $userId): array
    {
        return $this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at')->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();
    }

    /** @return array<string,mixed> */
    public function create(int $userId,array $data): array
    {
        $row=$this->normalize($data);
        $this->integrity->assertServiceList($userId,$row['service_public_ids']??null);
        $publicId=(string)Str::ulid();
        $this->db->table('crm_service_areas')->insert($row+['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'created_at'=>now(),'updated_at'=>now()]);
        return (array)$this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }

    /** @return array<string,mixed> */
    public function update(int $userId,string $publicId,array $data): array
    {
        $existing=$this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first();
        if(!$existing)throw new InvalidArgumentException('Service area not found.');
        $merged=array_merge((array)$existing,$data);
        $row=$this->normalize($merged);
        $this->integrity->assertServiceList($userId,$row['service_public_ids']??null);
        $this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->update($row+['updated_at'=>now()]);
        return (array)$this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }

    public function match(int $userId,?string $postcode,?float $latitude=null,?float $longitude=null,?string $service_public_id=null): array
    { $this->integrity->assertContext($userId,['service_public_id'=>$service_public_id]);
        $areas=$this->db->table('crm_service_areas')->where('company_id', $this->tenantContext->companyId($userId))->where('active',true)->whereNull('deleted_at')->orderBy('id')->get();$matches=[];
        foreach($areas as $area){$services=$area->service_public_ids?json_decode((string)$area->service_public_ids,true):[];if($service_public_id&&$services&&!in_array($service_public_id,$services,true))continue;$ok=false;$type=(string)$area->match_type;if($type==='postcode'){$postcodes=$area->postcodes?json_decode((string)$area->postcodes,true):[];$ok=$postcode!==null&&in_array((string)$postcode,array_map('strval',$postcodes),true);}elseif($type==='radius'&&$latitude!==null&&$longitude!==null&&$area->center_latitude!==null&&$area->center_longitude!==null&&$area->radius_km!==null){$ok=$this->distanceKm($latitude,$longitude,(float)$area->center_latitude,(float)$area->center_longitude)<=(float)$area->radius_km;}elseif($type==='polygon'&&$latitude!==null&&$longitude!==null&&$area->polygon){$polygon=json_decode((string)$area->polygon,true)?:[];$ok=$this->pointInPolygon($longitude,$latitude,$polygon);}if($ok)$matches[]=(array)$area;}
        return $matches;
    }

    /** @return array<string,mixed> */
    private function normalize(array $data): array
    {
        $name=trim((string)($data['name']??''));
        if($name==='')throw new InvalidArgumentException('Service area name is required.');
        $type=(string)($data['match_type']??'postcode');
        if(!in_array($type,['postcode','radius','polygon'],true))throw new InvalidArgumentException('Unsupported service-area match type.');
        $postcodes=$this->arrayValue($data['postcodes']??null);
        $polygon=$this->arrayValue($data['polygon']??null);
        $services=$this->arrayValue($data['service_public_ids']??null);
        if($type==='postcode'&&$postcodes===[])throw new InvalidArgumentException('Postcode service areas require at least one postcode.');
        if($type==='radius'&&(!isset($data['center_latitude'],$data['center_longitude'],$data['radius_km'])||(float)$data['radius_km']<=0))throw new InvalidArgumentException('Radius service areas require a centre and positive radius_km.');
        if($type==='polygon'&&count($polygon)<3)throw new InvalidArgumentException('Polygon service areas require at least three points.');
        return [
            'name'=>$name,'match_type'=>$type,
            'postcodes'=>$postcodes===[]?null:json_encode(array_values(array_unique(array_map('strval',$postcodes)))),
            'center_latitude'=>$type==='radius'?(float)$data['center_latitude']:null,
            'center_longitude'=>$type==='radius'?(float)$data['center_longitude']:null,
            'radius_km'=>$type==='radius'?(float)$data['radius_km']:null,
            'polygon'=>$type==='polygon'?json_encode(array_values($polygon)):null,
            'service_public_ids'=>$services===[]?null:json_encode(array_values(array_unique(array_map('strval',$services)))),
            'active'=>(bool)($data['active']??true),
            'metadata'=>isset($data['metadata'])?(is_string($data['metadata'])?$data['metadata']:json_encode($data['metadata'])):null,
        ];
    }

    /** @return list<mixed> */
    private function arrayValue(mixed $value): array
    {
        if($value===null||$value==='')return [];
        if(is_array($value))return array_values($value);
        if(is_string($value)){
            $trim=trim($value);
            if($trim==='')return [];
            if(str_starts_with($trim,'[')){ $decoded=json_decode($trim,true); if(is_array($decoded))return array_values($decoded); }
            return array_values(array_filter(array_map('trim',explode(',',$trim)),fn($v)=>$v!==''));
        }
        throw new InvalidArgumentException('Service-area list values must be arrays, JSON arrays or comma-separated strings.');
    }

    private function distanceKm(float $lat1,float $lon1,float $lat2,float $lon2): float { $r=6371.0;$dLat=deg2rad($lat2-$lat1);$dLon=deg2rad($lon2-$lon1);$a=sin($dLat/2)**2+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLon/2)**2;return 2*$r*atan2(sqrt($a),sqrt(1-$a)); }
    /** @param array<int,array{0:float|int,1:float|int}> $polygon */
    private function pointInPolygon(float $x,float $y,array $polygon): bool { $inside=false;$n=count($polygon);if($n<3)return false;for($i=0,$j=$n-1;$i<$n;$j=$i++){$xi=(float)$polygon[$i][0];$yi=(float)$polygon[$i][1];$xj=(float)$polygon[$j][0];$yj=(float)$polygon[$j][1];$intersect=(($yi>$y)!==($yj>$y))&&($x<($xj-$xi)*($y-$yi)/(($yj-$yi)?:1e-12)+$xi);if($intersect)$inside=!$inside;}return $inside; }
}
