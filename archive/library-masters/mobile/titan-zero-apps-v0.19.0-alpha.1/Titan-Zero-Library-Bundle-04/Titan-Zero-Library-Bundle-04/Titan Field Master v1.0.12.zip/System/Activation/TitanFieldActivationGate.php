<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Activation;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

final class TitanFieldActivationGate
{
    public function isAuthoritativeReady(): bool
    {
        try {
            if (! Schema::hasTable('extensions')) {
                return false;
            }

            $version = DB::table('extensions')
                ->where('slug', 'crm')
                ->value('version');

            if (! is_string($version) || trim($version) === '') {
                return false;
            }

            $minimum = (string) config('titan-field.compatibility.minimum_authoritative_crm', '1.3.0-alpha.24');

            return version_compare($version, $minimum, '>=');
        } catch (\Throwable) {
            return false;
        }
    }
}
