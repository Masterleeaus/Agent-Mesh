<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Forecasting;

/** Pure, read-only capacity arithmetic. It never schedules or mutates Field state. */
final class CapacityForecastCalculator
{
    /** @param array<string,mixed> $input @return array<string,mixed> */
    public function calculate(array $input): array
    {
        $available=max(0,(int)($input['available_minutes']??0));
        $booked=max(0,(int)($input['booked_minutes']??0));
        $demand=max(0,(int)($input['unfilled_demand_minutes']??0));
        $spatialRaw=$input['spatial_travel_burden_minutes']??null;
        $spatial=is_numeric($spatialRaw)?max(0,(int)$spatialRaw):null;
        $effective=$spatial===null?$available:max(0,$available-$spatial);
        $remaining=max(0,$effective-$booked);
        $shortage=max(0,$demand-$remaining);
        $utilization=$effective>0?round(($booked/$effective)*100,4):($booked>0?100.0:0.0);
        $coverage=$demand>0?round(($remaining/$demand)*100,4):($remaining>0?100.0:0.0);
        $uncovered=max(0,(int)($input['spatial_uncovered_demand_count']??0));

        if($available===0 && $booked===0 && $demand===0 && $spatial===null){$status='unknown';}
        elseif($shortage>0 || $utilization>=95.0){$status='critical';}
        elseif($utilization>=80.0 || ($demand>0 && $coverage<125.0) || $uncovered>0){$status='warning';}
        else{$status='healthy';}

        $recommendations=[];
        if($shortage>0)$recommendations[]='Add, extend or rebalance eligible capacity before accepting more demand in this horizon.';
        if($utilization>=80.0)$recommendations[]='Review high-utilisation workers and redistribute work before hard scheduling limits are reached.';
        if($uncovered>0)$recommendations[]='Review demand locations with no fresh nearby worker evidence or territory coverage.';
        if($spatial!==null && $spatial>0)$recommendations[]='Reserve explicit travel time when converting forecast demand into appointments.';
        if($status==='healthy')$recommendations[]='Current evidence shows sufficient capacity; continue monitoring demand and travel pressure.';
        if($status==='unknown')$recommendations[]='Capacity evidence is insufficient; do not treat this forecast as a scheduling commitment.';

        return [
            'available_minutes'=>$available,
            'spatial_travel_burden_minutes'=>$spatial,
            'effective_available_minutes'=>$effective,
            'booked_minutes'=>$booked,
            'remaining_minutes'=>$remaining,
            'unfilled_demand_minutes'=>$demand,
            'shortage_minutes'=>$shortage,
            'utilization_percent'=>$utilization,
            'coverage_percent'=>$coverage,
            'spatial_uncovered_demand_count'=>$uncovered,
            'pressure_status'=>$status,
            'recommendations'=>$recommendations,
            'authoritative'=>false,
            'mutation'=>'none',
        ];
    }
}
