<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Requests;

use InvalidArgumentException;

final class ServiceRequestStatusPolicy
{
    private const TRANSITIONS = [
        'new'=>['triaged','cancelled'],
        'triaged'=>['awaiting_customer','qualified','cancelled'],
        'awaiting_customer'=>['triaged','qualified','cancelled'],
        'qualified'=>['ready_for_quote','cancelled'],
        'ready_for_quote'=>['quoted','cancelled'],
        'quoted'=>['accepted','awaiting_customer','cancelled'],
        'accepted'=>['handed_off','resolved','cancelled'],
        'handed_off'=>['resolved','cancelled'],
        'resolved'=>['triaged'],
        'cancelled'=>['triaged'],
    ];
    public function assertTransition(string $from, string $to, ?string $reason = null): void
    {
        if ($from === $to) return;
        if (! in_array($to, self::TRANSITIONS[$from] ?? [], true)) throw new InvalidArgumentException("Service request cannot move from {$from} to {$to}.");
        if (($to === 'cancelled' || in_array($from,['resolved','cancelled'],true)) && trim((string)$reason) === '') throw new InvalidArgumentException('A reason is required when cancelling or reopening a closed service request.');
    }
}
