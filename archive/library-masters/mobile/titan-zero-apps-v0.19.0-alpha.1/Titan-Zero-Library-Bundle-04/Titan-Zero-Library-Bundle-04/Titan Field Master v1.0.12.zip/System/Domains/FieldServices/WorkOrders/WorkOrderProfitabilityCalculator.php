<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders;

/**
 * Pure arithmetic/policy layer for read-only work-order health.
 * Unknown authoritative costs stay unknown; the calculator never invents rates.
 */
final class WorkOrderProfitabilityCalculator
{
    /** @param array<string,mixed> $facts @return array<string,mixed> */
    public function calculate(array $facts): array
    {
        $quoted = $this->nullableInt($facts['quoted_revenue_minor'] ?? null);
        $plannedMinutes = max(0, (int)($facts['planned_labour_minutes'] ?? 0));
        $actualMinutes = max(0, (int)($facts['actual_labour_minutes'] ?? 0));
        $actualLabour = max(0, (int)($facts['known_actual_labour_cost_minor'] ?? 0));
        $labourComplete = (bool)($facts['labour_cost_complete'] ?? false);
        $plannedLabour = $this->nullableInt($facts['planned_labour_cost_minor'] ?? null);
        $materialCost = max(0, (int)($facts['material_cost_minor'] ?? 0));
        $materialComplete = (bool)($facts['material_cost_complete'] ?? false);
        $additionalRevenue = max(0, (int)($facts['additional_billable_revenue_minor'] ?? 0));
        $travelTimeCost = $this->nullableInt($facts['travel_time_cost_minor'] ?? null);
        $travelDistanceCost = $this->nullableInt($facts['travel_distance_cost_minor'] ?? null);
        $severities = array_values(array_filter(array_map(static fn($v): string => strtolower(trim((string)$v)), (array)($facts['unresolved_exception_severities'] ?? []))));

        $forecastComplete = $materialComplete && $labourComplete && ($plannedMinutes === 0 || $plannedLabour !== null);
        $forecastLabour = null;
        if ($forecastComplete) {
            $forecastLabour = $plannedLabour === null ? $actualLabour : max($actualLabour, $plannedLabour);
        }

        $knownTravel = ($travelTimeCost ?? 0) + ($travelDistanceCost ?? 0);
        $knownActualCost = $actualLabour + $materialCost + $knownTravel;
        $forecast = $forecastLabour === null ? null : $forecastLabour + $materialCost + $knownTravel;
        $projectedMargin = ($quoted !== null && $forecast !== null) ? $quoted - $forecast : null;
        $projectedPercent = ($projectedMargin !== null && $quoted !== null && $quoted > 0)
            ? round(($projectedMargin / $quoted) * 100, 2)
            : null;
        $billableRevenue = $quoted === null ? null : $quoted + $additionalRevenue;
        $overHours = $plannedMinutes > 0 && $actualMinutes > $plannedMinutes;
        $overBudget = $quoted !== null && $forecast !== null && $forecast > $quoted;

        $criticalException = array_intersect($severities, ['critical','urgent']);
        $warningException = array_intersect($severities, ['high','warning']);
        $health = 'healthy';
        if ($quoted === null || $forecast === null) {
            $health = 'unknown';
        }
        if ($criticalException !== [] || $overBudget || ($plannedMinutes > 0 && $actualMinutes > (int)ceil($plannedMinutes * 1.25)) || ($projectedPercent !== null && $projectedPercent < 0)) {
            $health = 'critical';
        } elseif ($health !== 'unknown' && ($warningException !== [] || $overHours || ($projectedPercent !== null && $projectedPercent < 15))) {
            $health = 'warning';
        }

        return [
            'quoted_revenue_minor' => $quoted,
            'additional_billable_revenue_minor' => $additionalRevenue,
            'estimated_billable_revenue_minor' => $billableRevenue,
            'planned_labour_minutes' => $plannedMinutes,
            'actual_labour_minutes' => $actualMinutes,
            'known_actual_labour_cost_minor' => $actualLabour,
            'planned_labour_cost_minor' => $plannedLabour,
            'material_cost_minor' => $materialCost,
            'travel_time_cost_minor' => $travelTimeCost,
            'travel_distance_cost_minor' => $travelDistanceCost,
            'known_actual_cost_minor' => $knownActualCost,
            'forecast_final_cost_minor' => $forecast,
            'projected_margin_minor' => $projectedMargin,
            'projected_margin_percent' => $projectedPercent,
            'over_hours' => $overHours,
            'over_budget' => $overBudget,
            'health_status' => $health,
            'cost_coverage' => [
                'labour_complete' => $labourComplete,
                'materials_complete' => $materialComplete,
                'planned_labour_rate_available' => $plannedMinutes === 0 || $plannedLabour !== null,
                'forecast_complete' => $forecast !== null,
            ],
        ];
    }

    private function nullableInt(mixed $value): ?int
    {
        return $value === null || $value === '' || !is_numeric($value) ? null : (int)round((float)$value);
    }
}
