<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Forms;

use InvalidArgumentException;

final class FormSubmissionPolicy
{
    public function assertEditable(string $status): void
    { if (! in_array($status,['draft','in_progress'],true)) throw new InvalidArgumentException('Only draft or in-progress form submissions can be edited.'); }
    public function assertTemplatePublishable(int $fieldCount,string $status): void
    { if ($status==='published') throw new InvalidArgumentException('This form template version is already published.'); if ($fieldCount < 1) throw new InvalidArgumentException('A form template needs at least one field before publishing.'); }
    public function assertSubmittable(int $missingRequiredFields): void
    { if ($missingRequiredFields > 0) throw new InvalidArgumentException('All required form fields must be answered before submission.'); }
}
