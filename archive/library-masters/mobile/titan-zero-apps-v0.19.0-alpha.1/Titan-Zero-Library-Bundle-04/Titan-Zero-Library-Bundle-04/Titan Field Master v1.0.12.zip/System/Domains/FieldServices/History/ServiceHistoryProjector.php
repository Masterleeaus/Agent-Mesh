<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\History;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class ServiceHistoryProjector
{
    public function __construct(private FieldTenantContext $tenantContext,private ConnectionInterface $db) {}
    public function record(int $userId,string $subjectType,string $subjectPublicId,string $eventType,string $title,?string $summary=null,array $context=[]): array
    {
        $fingerprint=$context['fingerprint']??null; if($fingerprint&&($existing=$this->db->table('crm_service_history_events')->where('company_id', $this->tenantContext->companyId($userId))->where('fingerprint',$fingerprint)->first()))return (array)$existing;
        $publicId=(string)Str::ulid(); $this->db->table('crm_service_history_events')->insert(['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'contact_public_id'=>$context['contact_public_id']??null,'company_public_id'=>$context['company_public_id']??null,'location_public_id'=>$context['location_public_id']??null,'subject_type'=>$subjectType,'subject_public_id'=>$subjectPublicId,'event_type'=>$eventType,'title'=>$title,'summary'=>$summary,'occurred_at'=>$context['occurred_at']??now(),'fingerprint'=>$fingerprint,'metadata'=>json_encode($context,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'created_at'=>now(),'updated_at'=>now()]); return (array)$this->db->table('crm_service_history_events')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
    }
    public function forContact(int $userId,string $contactPublicId,int $limit=100): array { return $this->db->table('crm_service_history_events')->where('company_id', $this->tenantContext->companyId($userId))->where('contact_public_id',$contactPublicId)->orderByDesc('occurred_at')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all(); }
    public function forLocation(int $userId,string $locationPublicId,int $limit=100): array { return $this->db->table('crm_service_history_events')->where('company_id', $this->tenantContext->companyId($userId))->where('location_public_id',$locationPublicId)->orderByDesc('occurred_at')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all(); }
}
