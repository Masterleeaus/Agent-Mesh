<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Schema;
use InvalidArgumentException;

/** Generalized business/service/service-area/postcode/worker blackout validation. */
final class OperationalBlackoutPolicy
{
    public const SCOPES=['business','service','service_area','postcode','worker'];
    public function __construct(private ConnectionInterface $db) {}

    /** @param array<string,mixed> $context */
    public function assertNotBlocked(int $tenant, ?int $worker, CarbonImmutable $from, CarbonImmutable $to, array $context=[]): void
    {
        if(!Schema::hasTable('titan_field_blackout_policies'))return;
        $rows=$this->db->table('titan_field_blackout_policies')->where('company_id',$tenant)->where('active',true)
            ->where('starts_at','<',$to)->where('ends_at','>',$from)->get();
        foreach($rows as $row){
            $scope=(string)$row->scope_type;$target=(string)($row->scope_public_id??'');$matches=false;
            if($scope==='business')$matches=true;
            elseif($scope==='worker')$matches=$worker!==null&&$target===(string)$worker;
            elseif($scope==='service')$matches=$target!==''&&$target===(string)($context['service_public_id']??'');
            elseif($scope==='service_area')$matches=$target!==''&&$target===(string)($context['service_area_public_id']??'');
            elseif($scope==='postcode')$matches=(string)($row->postcode??$target)!==''&&(string)($row->postcode??$target)===(string)($context['postcode']??'');
            if($matches)throw new InvalidArgumentException('Requested schedule is blocked by an operational blackout'.($row->reason?': '.$row->reason:'').'.');
        }
    }
}
