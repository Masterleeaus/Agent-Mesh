<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Contracts;

interface FieldAuditPort
{
    /** @param array<string,mixed>|null $before @param array<string,mixed>|null $after @param array<string,mixed> $context */
    public function record(
        int $userId,
        ?int $actorUserId,
        string $action,
        ?string $subjectType = null,
        ?string $subjectPublicId = null,
        ?array $before = null,
        ?array $after = null,
        array $context = [],
    ): void;
}
