<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Console;

use App\Extensions\TitanField\System\Domains\FieldServices\Recurring\RecurringServiceEngine;
use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;

final class GenerateRecurringServicesCommand extends Command
{
    protected $signature = 'crm:field-services:generate-recurring {--user=}';
    protected $description = 'Generate due CRM recurring-service occurrences and work orders with bounded per-user processing.';

    public function handle(RecurringServiceEngine $engine, ConnectionInterface $db): int
    {
        $ids = $this->option('user') !== null
            ? [(int) $this->option('user')]
            : $db->table('crm_service_agreements')->where('status', 'active')->whereNull('deleted_at')->distinct()->pluck('user_id')->map(fn ($id) => (int) $id)->all();

        $total = 0;
        foreach ($ids as $userId) {
            $generated = $engine->generateDueOccurrences($userId, null);
            $total += count($generated);
            $this->line("{$userId}: generated ".count($generated).' recurring occurrence(s).');
        }
        $this->info("CRM recurring occurrences generated: {$total}");
        return self::SUCCESS;
    }
}
