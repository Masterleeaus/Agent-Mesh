<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Reviews;

use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;
use App\Extensions\TitanField\System\Domains\FieldServices\Requests\ServiceRequestService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ReviewRecoveryService
{
    public function __construct(private FieldAutomationPort $automation,private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private ServiceRequestService $requests,private FieldReferenceIntegrity $integrity) {}

    public function requestReview(int $userId,string $contactPublicId,?string $workOrderPublicId=null,string $channel='email'): array
    {
        $this->integrity->assertContext($userId,['contact_public_id'=>$contactPublicId,'work_order_public_id'=>$workOrderPublicId]);
        $publicId=(string)Str::ulid();$raw=bin2hex(random_bytes(24));
        return $this->db->transaction(function()use($userId,$contactPublicId,$workOrderPublicId,$channel,$publicId,$raw):array{
            $this->db->table('crm_review_requests')->insert(['public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),'contact_public_id'=>$contactPublicId,'work_order_public_id'=>$workOrderPublicId,'channel'=>$channel,'status'=>'pending','token_hash'=>hash('sha256',$raw),'created_at'=>now(),'updated_at'=>now()]);
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.review.requested','review_request',$publicId,['contact_public_id'=>$contactPublicId,'work_order_public_id'=>$workOrderPublicId,'channel'=>$channel],['idempotency_key'=>'review.requested:'.$publicId]);
            return ['public_id'=>$publicId,'token'=>$raw,'status'=>'pending'];
        });
    }

    public function recordReview(int $userId,array $data): array
    {
        $rating=(int)($data['rating']??0);if($rating<1||$rating>5)throw new InvalidArgumentException('Review rating must be between 1 and 5.');
        $this->integrity->assertContext($userId,$data);$publicId=(string)Str::ulid();$threshold=(int)config('titan-field.field_services.review_recovery_threshold',2);
        $review=$this->db->transaction(function()use($userId,$data,$rating,$publicId,$threshold):array{
            $this->db->table('crm_reviews')->insert(['public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),'review_request_public_id'=>$data['review_request_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'rating'=>$rating,'comment'=>$data['comment']??null,'published'=>(bool)($data['published']??false),'reviewed_at'=>now(),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
            if(!empty($data['review_request_public_id']))$this->db->table('crm_review_requests')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$data['review_request_public_id'])->update(['status'=>'responded','responded_at'=>now(),'updated_at'=>now()]);
            $review=(array)$this->db->table('crm_reviews')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            if($rating<=$threshold)$review['service_recovery']=$this->openRecovery($userId,$publicId,$data);
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='review.recorded:'.$publicId;
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.review.recorded','review',$publicId,['rating'=>$rating,'contact_public_id'=>$data['contact_public_id']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'recovery_opened'=>$rating<=$threshold],$ctx);
            return $review;
        });
        if($rating<=$threshold)$this->automation->trigger($userId,'review.low_rating',['subject_type'=>'review','subject_public_id'=>$publicId,'rating'=>$rating,'contact_public_id'=>$data['contact_public_id']??null,'work_order_public_id'=>$data['work_order_public_id']??null,'idempotency_key'=>'review.low_rating:'.$publicId]);
        return $review;
    }

    public function openRecovery(int $userId,string $reviewPublicId,array $context=[]): array
    {
        $this->integrity->assertContext($userId,['review_public_id'=>$reviewPublicId]+$context);
        if(array_key_exists('owner_user_id',$context)&&$context['owner_user_id']!==null)$this->integrity->assertTenantUser($userId,(int)$context['owner_user_id']);
        $existing=$this->db->table('crm_service_recovery_cases')->where('company_id',$this->tenantContext->companyId($userId))->where('review_public_id',$reviewPublicId)->whereNull('deleted_at')->first();
        if($existing)return (array)$existing;
        $publicId=(string)Str::ulid();
        return $this->db->transaction(function()use($userId,$reviewPublicId,$context,$publicId):array{
            $review=$this->db->table('crm_reviews')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$reviewPublicId)->first();
            $this->db->table('crm_service_recovery_cases')->insert(['public_id'=>$publicId,'company_id'=>$this->tenantContext->companyId($userId),'user_id'=>$this->tenantContext->actorUserId($userId),'review_public_id'=>$reviewPublicId,'contact_public_id'=>$context['contact_public_id']??$review->contact_public_id??null,'work_order_public_id'=>$context['work_order_public_id']??$review->work_order_public_id??null,'status'=>'open','owner_user_id'=>$context['owner_user_id']??null,'created_at'=>now(),'updated_at'=>now()]);
            $record=(array)$this->db->table('crm_service_recovery_cases')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $ctx=is_array($context['signal_context']??null)?$context['signal_context']:[];$ctx['idempotency_key']='review.recovery.opened:'.$reviewPublicId;
            $this->signals->record($userId,$this->tenantContext->actorUserId($userId),'field.review.recovery_opened','service_recovery',$publicId,['review_public_id'=>$reviewPublicId,'contact_public_id'=>$record['contact_public_id']??null,'work_order_public_id'=>$record['work_order_public_id']??null],$ctx);
            return $record;
        });
    }

    public function requestRebooking(int $userId,int $actorUserId,string $recoveryPublicId,array $requestData): array
    {
        $case=$this->db->table('crm_service_recovery_cases')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$recoveryPublicId)->whereNull('deleted_at')->first();
        if(!$case)throw new InvalidArgumentException('Service recovery case not found.');
        return $this->db->transaction(function()use($userId,$actorUserId,$recoveryPublicId,$requestData,$case):array{
            $request=$this->requests->create($userId,$actorUserId,array_merge(['title'=>'Service recovery rebooking','contact_public_id'=>$case->contact_public_id,'source'=>'service_recovery','priority'=>'high','signal_context'=>['correlation_id'=>'recovery:'.$recoveryPublicId,'causation_id'=>'recovery.rebooking:'.$recoveryPublicId]],$requestData));
            $this->db->table('crm_service_recovery_cases')->where('company_id',$this->tenantContext->companyId($userId))->where('public_id',$recoveryPublicId)->update(['rebooking_requested'=>true,'rebooking_service_request_public_id'=>$request['public_id'],'updated_at'=>now()]);
            $this->signals->record($userId,$actorUserId,'field.review.rebooking_requested','service_recovery',$recoveryPublicId,['service_request_public_id'=>$request['public_id']],['correlation_id'=>'recovery:'.$recoveryPublicId,'causation_id'=>'recovery.rebooking:'.$recoveryPublicId,'idempotency_key'=>'recovery.rebooking:'.$recoveryPublicId]);
            return $request;
        });
    }
}
