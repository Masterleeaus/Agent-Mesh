<?php

declare(strict_types=1);
namespace App\Extensions\TitanField\System\Domains\FieldServices\Requests;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Domains\FieldServices\Integrity\FieldReferenceIntegrity;

use App\Extensions\TitanField\System\Domains\FieldServices\History\ServiceHistoryProjector;
use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;
use App\Extensions\TitanField\System\Contracts\FieldAuditPort;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ServiceRequestService
{
    public const STATES=['new','triaged','awaiting_customer','qualified','ready_for_quote','quoted','accepted','handed_off','resolved','cancelled'];
    public function __construct(private FieldAutomationPort $automation,private FieldSignalPort $signals,private FieldTenantContext $tenantContext,private ConnectionInterface $db,private ServiceRequestStatusPolicy $policy,private FieldAuditPort $audit,private ServiceHistoryProjector $history,private FieldReferenceIntegrity $integrity) {}
    public function search(int $userId,array $filters=[],int $limit=100): array
    { $q=$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->whereNull('deleted_at'); foreach(['status','priority','contact_public_id','company_public_id','location_public_id','service_public_id','owner_user_id'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]); return $q->orderByDesc('id')->limit(min(max($limit,1),250))->get()->map(fn($r)=>(array)$r)->all(); }
    public function create(int $userId,?int $actorUserId,array $data): array
    {
        $title=trim((string)($data['title']??'')); if($title==='')throw new InvalidArgumentException('Service request title is required.');
        $idempotency=trim((string)($data['idempotency_key']??'')); if($idempotency!==''){ $existing=$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('idempotency_key',$idempotency)->whereNull('deleted_at')->first(); if($existing)return (array)$existing; }
        $this->integrity->assertContext($userId,$data);
        if(array_key_exists('owner_user_id',$data)&&$data['owner_user_id']!==null)$this->integrity->assertTenantUser($userId,(int)$data['owner_user_id']);
        $publicId=(string)Str::ulid(); $now=now();
        $row=['public_id'=>$publicId,'company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId),'company_public_id'=>$data['company_public_id']??null,'contact_public_id'=>$data['contact_public_id']??null,'location_public_id'=>$data['location_public_id']??null,'service_public_id'=>$data['service_public_id']??null,'asset_public_id'=>$data['asset_public_id']??null,'lead_public_id'=>$data['lead_public_id']??null,'deal_public_id'=>$data['deal_public_id']??null,'title'=>$title,'description'=>$data['description']??null,'status'=>'new','priority'=>$data['priority']??'normal','urgency'=>$data['urgency']??'normal','source'=>$data['source']??'manual','channel'=>$data['channel']??null,'preferred_at'=>$data['preferred_at']??null,'respond_by_at'=>$data['respond_by_at']??null,'owner_user_id'=>$data['owner_user_id']??null,'idempotency_key'=>$idempotency!==''?$idempotency:null,'intake_payload'=>isset($data['intake_payload'])?json_encode($data['intake_payload']):null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>$now,'updated_at'=>$now];
        $record=$this->db->transaction(function()use($row,$userId,$actorUserId,$publicId,$data):array{
            $this->db->table('crm_service_requests')->insert($row);
            $record=(array)$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $ctx=is_array($data['signal_context']??null)?$data['signal_context']:[];$ctx['idempotency_key']='service_request.created:'.$publicId;
            $this->signals->record($userId,$actorUserId,'field.service_request.created','service_request',$publicId,['status'=>'new','source'=>$record['source']??'manual','priority'=>$record['priority']??'normal','urgency'=>$record['urgency']??'normal'],$ctx);
            return $record;
        });
        $this->audit->record($userId,$actorUserId,'field_service.service_request.created','service_request',$publicId,null,$record);
        $this->history->record($userId,'service_request',$publicId,'service_request.created','Service request created',$data['description']??null,$record);
        $this->automation->trigger($userId,'service_request.created',['subject_type'=>'service_request','subject_public_id'=>$publicId,'status'=>'new','source'=>$record['source']??'manual','priority'=>$record['priority']??'normal','urgency'=>$record['urgency']??'normal','idempotency_key'=>'service_request.created:'.$publicId]);
        return $record;
    }
    public function transition(int $userId,?int $actorUserId,string $publicId,string $toStatus,?string $reason=null): array
    {
        $row=$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->whereNull('deleted_at')->first(); if(!$row)throw new InvalidArgumentException('Service request not found.');
        $this->policy->assertTransition((string)$row->status,$toStatus,$reason); $updates=['status'=>$toStatus,'updated_at'=>now()]; if($toStatus==='qualified')$updates['qualified_at']=now(); if($toStatus==='accepted')$updates['accepted_at']=now(); if($toStatus==='resolved'){$updates['resolved_at']=now();$updates['resolution']=$reason;}
        $after=$this->db->transaction(function()use($userId,$actorUserId,$publicId,$updates,$row,$toStatus,$reason):array{
            $this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->update($updates);
            $after=(array)$this->db->table('crm_service_requests')->where('company_id', $this->tenantContext->companyId($userId))->where('public_id',$publicId)->first();
            $this->signals->record($userId,$actorUserId,'field.service_request.status_changed','service_request',$publicId,['from'=>(string)$row->status,'to'=>$toStatus,'reason'=>$reason],['idempotency_key'=>hash('sha256','service_request.status|'.$publicId.'|'.$row->status.'|'.$toStatus.'|'.(string)($row->updated_at??''))]);
            return $after;
        });
        $this->audit->record($userId,$actorUserId,'field_service.service_request.status_changed','service_request',$publicId,(array)$row,$after,['reason'=>$reason]); $this->history->record($userId,'service_request',$publicId,'service_request.status_changed','Service request '.$toStatus,$reason,$after); return $after;
    }
}
