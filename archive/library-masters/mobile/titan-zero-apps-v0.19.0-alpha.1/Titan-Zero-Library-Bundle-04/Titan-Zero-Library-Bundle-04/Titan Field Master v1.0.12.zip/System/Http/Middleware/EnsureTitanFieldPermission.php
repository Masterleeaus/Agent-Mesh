<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Middleware;

use App\Extensions\TitanField\System\Contracts\FieldPermissionGate;
use Closure;
use Illuminate\Http\Request;

final class EnsureTitanFieldPermission
{
    public function __construct(private FieldPermissionGate $gate) {}

    public function handle(Request $request, Closure $next, string $permission): mixed
    {
        return $this->gate->handle($request, $next, $permission);
    }
}
