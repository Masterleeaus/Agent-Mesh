<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Commands;

use App\Extensions\TitanField\System\Contracts\FieldCommandAuthorizer;
use App\Extensions\TitanField\System\Security\FieldPermissionService;

final class FieldCommandPermissionAuthorizer implements FieldCommandAuthorizer
{
    public function __construct(private FieldPermissionService $permissions) {}

    public function authorize(int $userId, string $permission): void
    {
        $this->permissions->authorize($userId, $permission);
    }
}
