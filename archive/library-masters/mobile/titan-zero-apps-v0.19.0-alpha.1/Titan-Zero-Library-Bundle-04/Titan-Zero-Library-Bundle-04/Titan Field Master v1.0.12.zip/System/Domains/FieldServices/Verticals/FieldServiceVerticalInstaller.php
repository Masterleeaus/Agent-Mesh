<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Verticals;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;

use App\Extensions\TitanField\System\Domains\FieldServices\Catalogue\ServiceCatalogueService;
use App\Extensions\TitanField\System\Domains\FieldServices\Forms\FormService;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;

final class FieldServiceVerticalInstaller
{
    public function __construct(
        private FieldTenantContext $tenantContext,
        private ConnectionInterface $db,
        private FieldServiceVerticalProfileService $profiles,
        private ServiceCatalogueService $catalogue,
        private FormService $forms,
    ) {}

    /** @return array<string,mixed> */
    public function apply(int $userId, string $profileKey, ?int $actorUserId = null, array $settings = []): array
    {
        $profile = $this->profiles->profile($profileKey);
        $profileHash = hash('sha256', json_encode($profile, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

        return $this->db->transaction(function () use ($userId, $actorUserId, $settings, $profile, $profileHash): array {
            $category = $this->upsertCategory($userId, (array) ($profile['category'] ?? [
                'key' => $profile['key'],
                'name' => $profile['name'].' Services',
            ]));

            $formIds = [];
            foreach ((array) ($profile['forms'] ?? []) as $definition) {
                $form = $this->createFormTemplate($userId, (array) $definition, (string) $profile['key']);
                $formIds[] = (string) $form['public_id'];
            }

            $serviceIds = [];
            $intakeSchema = isset($profile['intake_fields'])
                ? ['fields' => array_values((array) $profile['intake_fields'])]
                : null;
            $verticalFieldRequirements = [
                'specialist_fields' => array_values((array) ($profile['specialist_fields'] ?? [])),
                'default_checklists' => array_values((array) ($profile['default_checklists'] ?? [])),
                'compliance_categories' => array_values((array) ($profile['compliance_categories'] ?? [])),
            ];

            foreach ((array) $profile['services'] as $serviceKey => $definition) {
                $definition = array_replace([
                    'required_skills' => array_values((array) ($profile['required_skills'] ?? [])),
                    'evidence_requirements' => array_values((array) ($profile['evidence_requirements'] ?? [])),
                    'field_requirements' => $verticalFieldRequirements,
                    'form_template_public_ids' => $formIds,
                    'booking_available' => true,
                    'recurring_eligible' => (bool) ($profile['recurring_eligible'] ?? false),
                ], (array) $definition);
                $service = $this->upsertService($userId, (string) $serviceKey, $definition, (string) $category['public_id'], $intakeSchema, (string) $profile['key']);
                $serviceIds[] = (string) $service['public_id'];
            }

            $existing = $this->db->table('crm_field_service_profiles')
                ->where('company_id', $this->tenantContext->companyId($userId))
                ->where('profile_key', (string) $profile['key'])
                ->first();
            $publicId = $existing?->public_id ?: (string) Str::ulid();

            $this->db->table('crm_field_service_profiles')->updateOrInsert(
                ['company_id' => $this->tenantContext->companyId($userId), 'user_id' => $this->tenantContext->actorUserId($userId), 'profile_key' => (string) $profile['key']],
                [
                    'public_id' => $publicId,
                    'profile_name' => (string) ($profile['name'] ?? $profile['key']),
                    'profile_hash' => $profileHash,
                    'profile_version' => max(1, (int) ($profile['version'] ?? 1)),
                    'enabled' => true,
                    'applied_by_user_id' => $actorUserId,
                    'applied_at' => now(),
                    'settings' => $settings === [] ? null : json_encode($settings, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                    'metadata' => json_encode([
                        'category_public_id' => $category['public_id'],
                        'service_public_ids' => $serviceIds,
                        'form_public_ids' => $formIds,
                    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                    'created_at' => $existing?->created_at ?? now(),
                    'updated_at' => now(),
                ]
            );

            return [
                'profile' => (string) $profile['key'],
                'profile_hash' => $profileHash,
                'category' => $category,
                'services' => $serviceIds,
                'forms' => $formIds,
                'installed' => true,
            ];
        });
    }

    /** @return list<array<string,mixed>> */
    public function installed(int $userId): array
    {
        return $this->db->table('crm_field_service_profiles')
            ->where('company_id', $this->tenantContext->companyId($userId))
            ->orderBy('profile_name')
            ->get()
            ->map(static fn ($row): array => (array) $row)
            ->all();
    }

    /** @return array<string,mixed> */
    private function upsertCategory(int $userId, array $definition): array
    {
        $key = trim((string) ($definition['key'] ?? ''));
        $existing = $this->db->table('crm_service_categories')
            ->where('company_id', $this->tenantContext->companyId($userId))->where('key', $key)->whereNull('deleted_at')->first();

        if (! $existing) {
            return $this->catalogue->createCategory($userId, [
                'key' => $key,
                'name' => (string) ($definition['name'] ?? $key),
                'description' => $definition['description'] ?? null,
                'metadata' => ['vertical_profile' => true],
            ]);
        }

        $this->db->table('crm_service_categories')->where('id', $existing->id)->update([
            'name' => (string) ($definition['name'] ?? $existing->name),
            'description' => $definition['description'] ?? $existing->description,
            'active' => true,
            'updated_at' => now(),
        ]);
        return (array) $this->db->table('crm_service_categories')->where('id', $existing->id)->first();
    }

    /** @return array<string,mixed> */
    private function upsertService(int $userId, string $key, array $definition, string $categoryPublicId, ?array $intakeSchema, string $profileKey): array
    {
        $defaultTasks = array_map(static fn (array $task): array => [
            'key' => (string) ($task['key'] ?? Str::slug((string) ($task['name'] ?? 'task'), '_')),
            'title' => (string) ($task['name'] ?? $task['title'] ?? 'Task'),
            'instructions' => $task['instructions'] ?? null,
            'required' => (bool) ($task['is_required'] ?? $task['required'] ?? true),
            'sort_order' => (int) ($task['sort_order'] ?? 0),
        ], array_values((array) ($definition['tasks'] ?? [])));

        $catalogueKey=$profileKey.'.'.$key;
        $existing = $this->db->table('crm_services')->where('company_id', $this->tenantContext->companyId($userId))->where('key', $catalogueKey)->whereNull('deleted_at')->first();
        if (! $existing) {
            return $this->catalogue->createService($userId, [
                'category_public_id' => $categoryPublicId,
                'key' => $catalogueKey,
                'name' => (string) ($definition['name'] ?? $key),
                'description' => $definition['description'] ?? null,
                'default_duration_minutes' => $definition['default_duration_minutes'] ?? null,
                'pricing_model' => $definition['pricing_model'] ?? 'fixed',
                'quote_required' => (bool) ($definition['quote_required'] ?? false),
                'emergency_capable' => (bool) ($definition['emergency_capable'] ?? false),
                'regulated_work' => (bool) ($definition['regulated_work'] ?? false),
                'default_tasks' => $defaultTasks,
                'intake_schema' => $intakeSchema,
                'tax_behavior' => $definition['tax_behavior'] ?? 'default',
                'booking_available' => (bool) ($definition['booking_available'] ?? true),
                'required_skills' => $definition['required_skills'] ?? [],
                'field_requirements' => $definition['field_requirements'] ?? [],
                'evidence_requirements' => $definition['evidence_requirements'] ?? [],
                'form_template_public_ids' => $definition['form_template_public_ids'] ?? [],
                'recurring_eligible' => (bool) ($definition['recurring_eligible'] ?? false),
                'metadata' => ['vertical_profile' => $profileKey, 'profile_service_key' => $key],
            ]);
        }

        // Re-applying a profile updates profile-owned defaults but deliberately preserves user pricing.
        $this->db->table('crm_services')->where('id', $existing->id)->update([
            'category_public_id' => $categoryPublicId,
            'name' => (string) ($definition['name'] ?? $existing->name),
            'description' => $definition['description'] ?? $existing->description,
            'default_duration_minutes' => $definition['default_duration_minutes'] ?? $existing->default_duration_minutes,
            'pricing_model' => $definition['pricing_model'] ?? $existing->pricing_model,
            'quote_required' => (bool) ($definition['quote_required'] ?? $existing->quote_required),
            'emergency_capable' => (bool) ($definition['emergency_capable'] ?? $existing->emergency_capable),
            'regulated_work' => (bool) ($definition['regulated_work'] ?? $existing->regulated_work),
            'default_tasks' => json_encode($defaultTasks, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'intake_schema' => $intakeSchema === null ? $existing->intake_schema : json_encode($intakeSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'tax_behavior' => $definition['tax_behavior'] ?? ($existing->tax_behavior ?? 'default'),
            'booking_available' => (bool) ($definition['booking_available'] ?? ($existing->booking_available ?? true)),
            'required_skills' => json_encode(array_values((array) ($definition['required_skills'] ?? [])), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'field_requirements' => json_encode((array) ($definition['field_requirements'] ?? []), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'evidence_requirements' => json_encode(array_values((array) ($definition['evidence_requirements'] ?? [])), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'form_template_public_ids' => json_encode(array_values((array) ($definition['form_template_public_ids'] ?? [])), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'recurring_eligible' => (bool) ($definition['recurring_eligible'] ?? ($existing->recurring_eligible ?? false)),
            'active' => true,
            'updated_at' => now(),
        ]);
        return (array) $this->db->table('crm_services')->where('id', $existing->id)->first();
    }

    /** @return array<string,mixed> */
    private function createFormTemplate(int $userId, array $definition, string $profileKey): array
    {
        $key = trim((string) ($definition['key'] ?? ''));
        $existing = $this->db->table('crm_form_templates')->where('company_id', $this->tenantContext->companyId($userId))->where('key', $key)->whereNull('deleted_at')->first();
        if ($existing) return (array) $existing;

        return $this->forms->createTemplate($userId, [
            'key' => $key,
            'name' => (string) ($definition['name'] ?? $key),
            'form_type' => (string) ($definition['form_type'] ?? 'checklist'),
            'applies_to' => (string) ($definition['applies_to'] ?? 'work_order'),
            'metadata' => ['vertical_profile' => $profileKey, 'profile_service_key' => $key],
            'fields' => [
                ['key' => 'completed_work', 'label' => 'Work completed', 'field_type' => 'textarea', 'required' => true, 'sort_order' => 0],
                ['key' => 'exceptions', 'label' => 'Exceptions / defects', 'field_type' => 'textarea', 'required' => false, 'sort_order' => 10],
                ['key' => 'customer_signoff', 'label' => 'Customer sign-off', 'field_type' => 'signature', 'required' => false, 'sort_order' => 20],
            ],
        ]);
    }
}
