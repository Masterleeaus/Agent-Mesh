<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm;

use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use App\Extensions\TitanField\System\Contracts\FieldPermissionGate;
use Closure;
use Illuminate\Http\Request;

final class CrmFieldPermissionGate implements FieldPermissionGate
{
    public function __construct(private EnsureCrmPermission $middleware) {}

    public function handle(Request $request, Closure $next, string $permission): mixed
    {
        return $this->middleware->handle($request, $next, $permission);
    }
}
