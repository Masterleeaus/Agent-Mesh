<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanField\System\Console\GenerateRecurringServicesCommand;
use App\Extensions\TitanField\System\Console\PruneFieldWorkerLocationPingsCommand;
use App\Extensions\TitanField\System\Activation\TitanFieldActivationGate;
use App\Extensions\TitanField\System\Contracts\FieldAuditPort;
use App\Extensions\TitanField\System\Contracts\FieldCommandAuthorizer;
use App\Extensions\TitanField\System\Contracts\FieldCommandGateway;
use App\Extensions\TitanField\System\Contracts\FieldCommandRouter;
use App\Extensions\TitanField\System\Contracts\FieldAutomationPort;
use App\Extensions\TitanField\System\Contracts\FieldHostGate;
use App\Extensions\TitanField\System\Contracts\FieldPermissionGate;
use App\Extensions\TitanField\System\Contracts\FieldSignalPort;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm\CrmFieldAuditAdapter;
use App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm\CrmFieldAutomationAdapter;
use App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm\CrmFieldHostGate;
use App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm\CrmFieldPermissionGate;
use App\Extensions\TitanField\System\Infrastructure\Compatibility\Crm\CrmFieldTenantContext;
use App\Extensions\TitanField\System\Infrastructure\Signals\DatabaseFieldSignalOutbox;
use App\Extensions\TitanField\System\Infrastructure\Spatial\FallbackSpatialIntelligenceGateway;
use App\Extensions\TitanField\System\Infrastructure\Spatial\OptionalTitanMapsSpatialIntelligenceGateway;
use App\Extensions\TitanField\System\Infrastructure\Commands\FieldCommandPermissionAuthorizer;
use App\Extensions\TitanField\System\Infrastructure\Commands\FieldServiceCommandRouter;
use App\Extensions\TitanField\System\Infrastructure\Commands\GovernedFieldCommandGateway;
use App\Extensions\TitanField\System\Http\Controllers\StagedScheduleController;
use App\Extensions\TitanField\System\Http\Middleware\TitanFieldPermissionGate;
use App\Extensions\TitanField\System\Security\FieldPermissionService;
use App\Extensions\TitanField\System\Domains\FieldServices\Offline\OfflineFieldRuntime;
use App\Extensions\TitanField\System\Domains\FieldServices\Offline\OfflineReplayPolicy;
use App\Extensions\TitanField\System\Navigation\TitanFieldMenuInstaller;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

final class TitanFieldServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        // Agent 2 Titan Apps convergence: expose semantic contributions through container discovery; no UI/runtime authority lives here.
        $this->app->singleton(\App\Extensions\TitanField\System\TitanApps\ProviderInterfaceContributionCatalog::class);
        $this->app->tag([\App\Extensions\TitanField\System\TitanApps\ProviderInterfaceContributionCatalog::class], 'titan.apps.interface-contributions');

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-field.php', 'titan-field');
        $this->app->singleton(TitanFieldActivationGate::class);
        $activation = $this->app->make(TitanFieldActivationGate::class);
        $activationReady = $activation->isAuthoritativeReady();
        if (! $activationReady) {
            // Schema-only staged install. No operational adapters, command gateways, domain
            // services, Workforce contributions or offline runtime are registered below the
            // extraction boundary.
            return;
        }

        // Pass 2: the domain resolves Field-owned ports only. CRM implementation
        // classes are isolated to compatibility adapters and can be swapped later
        // without rewriting domain services or route definitions.
        $this->app->singleton(FieldTenantContext::class, CrmFieldTenantContext::class);
        $this->app->singleton(FieldAuditPort::class, CrmFieldAuditAdapter::class);
        $this->app->singleton(FieldAutomationPort::class, CrmFieldAutomationAdapter::class);
        $this->app->singleton(FieldHostGate::class, CrmFieldHostGate::class);
        $this->app->singleton(FieldPermissionService::class);
        // Retain the Pass-2 CRM gate adapter as an injectable compatibility alias;
        // canonical Field route/command authorization is now Field-owned.
        $this->app->singleton(CrmFieldPermissionGate::class);
        $this->app->singleton(FieldPermissionGate::class, TitanFieldPermissionGate::class);
        $this->app->singleton(FieldSignalPort::class, DatabaseFieldSignalOutbox::class);
        // Pass 11: spatial intelligence is optional. Maps Intelligence is preferred when its peer
        // contract is installed/bound; otherwise Field retains deterministic local fallbacks.
        $this->app->singleton(FallbackSpatialIntelligenceGateway::class);
        $this->app->singleton(SpatialIntelligenceGateway::class, OptionalTitanMapsSpatialIntelligenceGateway::class);

        // Staged activation: schema may be installed on CRM alpha.17+, but authoritative Field
        // mutation surfaces are not bound until CRM crosses the alpha.24 extraction boundary.
        // Maps also uses FieldCommandGateway::bound() as the peer-activation signal.
        if ($activationReady) {
            $this->app->singleton(FieldCommandAuthorizer::class, FieldCommandPermissionAuthorizer::class);
            $this->app->singleton(FieldCommandRouter::class, FieldServiceCommandRouter::class);
            $this->app->singleton(FieldCommandGateway::class, GovernedFieldCommandGateway::class);

            // Pass 15: extension-owned Workforce Manifest 2.0 contribution. AI Workforce discovers
            // this only after authoritative activation; no role auto-activation occurs here.
            $this->app->singleton('titan-field.workforce-manifest', static fn (): array => ['path'=>__DIR__.'/../resources/workforce/workforce-manifest.json','schema_version'=>'3.0','source_of_truth'=>'capability-provider','owner_extension'=>'titan-field']);
            $this->app->singleton('titan-field.workforce-capability-binding', static fn (): array => json_decode((string) file_get_contents(__DIR__.'/../resources/workforce/capability-bindings.json'), true, 512, JSON_THROW_ON_ERROR));

            $this->app->singleton(OfflineReplayPolicy::class, static fn () => new OfflineReplayPolicy(
                maximumOfflineAgeDays: (int) config('titan-field.offline.maximum_offline_age_days', 14),
                maximumBatchSize: (int) config('titan-field.offline.maximum_batch_size', 100),
                maximumFutureSkewSeconds: (int) config('titan-field.offline.maximum_future_skew_seconds', 300),
            ));
            $this->app->singleton(OfflineFieldRuntime::class);
        }

        foreach ([
            \App\Extensions\TitanField\System\Domains\FieldServices\Assets\CustomerAssetService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Catalogue\ServiceCatalogueService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Dispatch\DispatchService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Dispatch\DispatchStatusPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Evidence\FieldEvidenceService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Exceptions\OperationalExceptionPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Exceptions\OperationalExceptionService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\FieldServiceCapabilityRegistry::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Forecasting\CapacityForecastCalculator::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Forecasting\CapacityForecastService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Forms\FormService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Forms\FormSubmissionPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Locations\ServiceLocationService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Recurring\RecurrenceCalculator::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Recurring\RecurringServiceEngine::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Routing\WorkerLocationPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Routing\RouteOptimizationProposalService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Requests\ServiceRequestService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Requests\ServiceRequestStatusPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Reviews\ReviewRecoveryService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\AppointmentService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\CalendarDispatchControlService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\AppointmentWindowPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\WorkerAvailabilityPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\OperationalBlackoutPolicy::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\TravelEstimator::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\RecommendationEvidenceStore::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Scheduling\TechnicianRecommendationService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\ServiceAreas\ServiceAreaMatcher::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Support\SupportService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Verticals\FieldServiceVerticalInstaller::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\Verticals\FieldServiceVerticalProfileService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderProfitabilityCalculator::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderHealthService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderCompletionGuard::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderService::class,
            \App\Extensions\TitanField\System\Domains\FieldServices\WorkOrders\WorkOrderStatusPolicy::class,
        ] as $service) {
            $this->app->singleton($service);
        }
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-field');

        $activation = $this->app->make(TitanFieldActivationGate::class);
        if (! $activation->isAuthoritativeReady()) {
            // Installed-but-dormant compatibility state. Authoritative mutation/runtime surfaces
            // remain disabled until CRM reaches the extraction boundary. A single bounded,
            // read-only Schedule route is exposed so the current CRM host can use the real
            // calendar UI without creating a second operational writer.
            Route::middleware((array) config('titan-field.middleware', ['web', 'auth']))
                ->get('/dashboard/user/titan-field/schedule', StagedScheduleController::class)
                ->name('dashboard.user.titan-field.schedule');
            $this->app->booted(static function (): void {
                TitanFieldMenuInstaller::syncStagedSchedule();
            });
            return;
        }

        $webRoutes = __DIR__ . '/../routes/web.php';
        $this->loadRoutesFrom($webRoutes);
        // MagicAI menu rows intentionally store named routes. A host route cache may
        // pre-date an extension upgrade, so recover the Field route file when any
        // sentinel is absent instead of allowing route names to become broken URLs.
        $this->ensureRouteFileLoaded($webRoutes, [
            'dashboard.user.crm.field-services.index',
            'dashboard.user.crm.field-services.work-orders',
            'dashboard.user.crm.field-services.schedule',
            'dashboard.user.crm.field-services.dispatch',
            'dashboard.user.crm.field-services.routes',
            'dashboard.user.crm.field-services.control',
            'dashboard.user.crm.field-services.capacity',
        ]);

        if (is_file(__DIR__ . '/../routes/api.php')) {
            $this->loadRoutesFrom(__DIR__ . '/../routes/api.php');
        }

        $this->app->booted(static function (): void {
            TitanFieldMenuInstaller::healIfNeeded();
        });

        if ($this->app->runningInConsole()) {
            $this->commands([GenerateRecurringServicesCommand::class, PruneFieldWorkerLocationPingsCommand::class]);
        }
        $this->app->afterResolving(Schedule::class, static function (Schedule $schedule): void {
            $schedule->command('titan-field:prune-worker-location')->hourly()->withoutOverlapping();
        });
    }

    /** @param array<int,string> $sentinelRouteNames */
    private function ensureRouteFileLoaded(string $path, array $sentinelRouteNames): void
    {
        foreach ($sentinelRouteNames as $routeName) {
            if (! Route::has($routeName)) {
                require $path;
                return;
            }
        }
    }

    public function registerKey(): string { return 'titan-field'; }
    public static function uninstall(): void { /* Domain data retained by default for safe extraction/upgrades. */ }
}
