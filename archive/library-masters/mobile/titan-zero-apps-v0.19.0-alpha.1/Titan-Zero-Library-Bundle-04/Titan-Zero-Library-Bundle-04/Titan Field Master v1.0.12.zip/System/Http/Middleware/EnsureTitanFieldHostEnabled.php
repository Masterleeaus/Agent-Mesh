<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Http\Middleware;

use App\Extensions\TitanField\System\Contracts\FieldHostGate;
use Closure;
use Illuminate\Http\Request;

final class EnsureTitanFieldHostEnabled
{
    public function __construct(private FieldHostGate $gate) {}

    public function handle(Request $request, Closure $next): mixed
    {
        return $this->gate->handle($request, $next);
    }
}
