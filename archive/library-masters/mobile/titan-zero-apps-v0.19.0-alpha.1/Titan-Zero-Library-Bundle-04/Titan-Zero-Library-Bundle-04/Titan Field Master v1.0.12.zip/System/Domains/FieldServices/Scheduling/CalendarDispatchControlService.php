<?php

declare(strict_types=1);

namespace App\Extensions\TitanField\System\Domains\FieldServices\Scheduling;

use App\Extensions\TitanField\System\Contracts\FieldTenantContext;
use App\Extensions\TitanField\System\Contracts\SpatialIntelligenceGateway;
use Carbon\CarbonImmutable;
use Illuminate\Database\ConnectionInterface;

/** Read-only control-surface projection. All mutations remain governed commands. */
final class CalendarDispatchControlService
{
    public function __construct(private FieldTenantContext $tenantContext, private SpatialIntelligenceGateway $spatial, private ConnectionInterface $db) {}

    /** @return array<string,mixed> */
    public function forDate(int $userId, string $date): array
    {
        $tenant=$this->tenantContext->companyId($userId);$day=CarbonImmutable::parse($date)->startOfDay();$next=$day->addDay();
        $workers=$this->db->table('crm_field_worker_profiles')->where('company_id',$tenant)->where('active',true)->orderBy('worker_user_id')->get()->map(fn($r)=>(array)$r)->all();
        $appointments=$this->db->table('crm_appointments')->where('company_id',$tenant)->whereNull('deleted_at')->where('scheduled_start','<',$next)->where('scheduled_end','>=',$day)->orderBy('scheduled_start')->get()->map(fn($r)=>(array)$r)->all();
        $dispatch=$this->db->table('crm_dispatch_assignments')->where('company_id',$tenant)->whereNull('deleted_at')->where(function($q)use($day,$next){$q->whereNull('scheduled_start')->orWhere(function($x)use($day,$next){$x->where('scheduled_start','<',$next)->where(function($y)use($day){$y->whereNull('scheduled_end')->orWhere('scheduled_end','>=',$day);});});})->get()->map(fn($r)=>(array)$r)->all();
        $routes=$this->db->table('titan_field_routes')->where('company_id',$tenant)->whereDate('route_date',$day->toDateString())->orderBy('worker_user_id')->get()->map(fn($r)=>(array)$r)->all();
        $exceptions=$this->db->table('titan_field_operational_exceptions')->where('company_id',$tenant)->whereNotIn('status',['closed'])->where(function($q)use($day,$next){$q->whereBetween('detected_at',[$day,$next])->orWhereBetween('sla_due_at',[$day,$next])->orWhereNull('sla_due_at');})->orderByRaw("CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END")->limit(100)->get()->map(fn($r)=>(array)$r)->all();

        $events=[];$byWorker=[];
        foreach($appointments as $a){$worker=$a['assigned_user_id']===null?0:(int)$a['assigned_user_id'];$event=['public_id'=>$a['public_id'],'title'=>$a['title'],'worker_user_id'=>$worker,'scheduled_start'=>$a['scheduled_start'],'scheduled_end'=>$a['scheduled_end'],'status'=>$a['status'],'work_order_public_id'=>$a['work_order_public_id'],'location_public_id'=>$a['location_public_id']];$events[]=$event;$byWorker[$worker][]=$event;}
        $worker_lanes=[];foreach($workers as $w){$id=(int)$w['worker_user_id'];$worker_lanes[]=['worker_user_id'=>$id,'label'=>'Worker '.$id,'timezone'=>$w['timezone']??config('titan-field.field_services.default_timezone','Australia/Melbourne'),'max_daily_minutes'=>(int)($w['max_daily_minutes']??720),'appointments'=>$byWorker[$id]??[]];}
        if(isset($byWorker[0]))array_unshift($worker_lanes,['worker_user_id'=>0,'label'=>'Unassigned','timezone'=>config('titan-field.field_services.default_timezone','Australia/Melbourne'),'max_daily_minutes'=>0,'appointments'=>$byWorker[0]]);

        $route_overlays=[];$routePoints=[];
        foreach($routes as $route){$stops=$this->db->table('titan_field_route_stops')->where('company_id',$tenant)->where('route_public_id',$route['public_id'])->orderBy('sequence')->get()->map(fn($r)=>(array)$r)->all();$route_overlays[]=['public_id'=>$route['public_id'],'worker_user_id'=>(int)$route['worker_user_id'],'status'=>$route['status'],'distance_meters'=>(int)$route['total_distance_meters'],'duration_seconds'=>(int)$route['total_duration_seconds'],'stops'=>$stops];$points=[];foreach($stops as $stop){if(empty($stop['location_public_id']))continue;$loc=$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$stop['location_public_id'])->whereNull('deleted_at')->first();if($loc&&$loc->latitude!==null&&$loc->longitude!==null)$points[]=['lat'=>(float)$loc->latitude,'lng'=>(float)$loc->longitude];}if(count($points)>1)$routePoints[]=['id'=>'field-route:'.$route['public_id'],'type'=>'route_plan_sequence','points'=>$points];}
        $exception_overlays=array_map(static fn(array $x):array=>['public_id'=>$x['public_id'],'type'=>$x['exception_type'],'severity'=>$x['severity'],'status'=>$x['status'],'worker_user_id'=>$x['worker_user_id'],'appointment_public_id'=>$x['appointment_public_id'],'title'=>$x['title'],'sla_due_at'=>$x['sla_due_at']],$exceptions);

        $map=$this->spatial->mapPayload($userId,'field.team');$map['polylines']=array_merge((array)($map['polylines']??[]),$routePoints);
        $locations=[];foreach($appointments as $a){$id=(string)($a['location_public_id']??'');if($id===''||isset($locations[$id]))continue;$loc=$this->db->table('crm_service_locations')->where('company_id',$tenant)->where('public_id',$id)->whereNull('deleted_at')->first();if($loc&&$loc->latitude!==null&&$loc->longitude!==null){$locations[$id]=true;$map['markers'][]=['id'=>'appointment-location:'.$id,'lat'=>(float)$loc->latitude,'lng'=>(float)$loc->longitude,'type'=>'job','label'=>(string)($loc->name??'Service location'),'subtitle'=>(string)($loc->postcode??'')];}}

        return ['date'=>$day->toDateString(),'worker_lanes'=>$worker_lanes,'events'=>$events,'dispatch'=>$dispatch,'route_overlays'=>$route_overlays,'exception_overlays'=>$exception_overlays,'map_payload'=>$map,'map_ui'=>$this->spatial->mapUi($userId),'spatial_provider'=>$this->spatial->available($userId)?'titan-maps-intelligence':'field-fallback'];
    }
}
