<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class PriceBookItem extends Model
{
    protected $table = 'financial_price_book_items';
    protected $fillable = ['company_id','price_book_id','code','name','description','item_type','unit','cost','sell_price','pricing_method','target_margin_percent','markup_percent','tax_rate_percent','minimum_price','maximum_discount_percent','active','meta'];
    protected $casts = ['active'=>'boolean','meta'=>'array'];
}
