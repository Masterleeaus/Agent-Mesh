<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use InvalidArgumentException;

final class BreakEvenScenarioEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'break_even_scenario'; }
    public function priority(): int { return 160; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $fixed = $this->decimal($context, $state, 'fixed_costs');
        $price = $this->decimal($context, $state, 'price_per_unit');
        $variable = $this->decimal($context, $state, 'variable_cost_per_unit');
        $contribution = $price->sub($variable);
        if ($contribution->compare('0') <= 0) {
            throw new InvalidArgumentException('price_per_unit must exceed variable_cost_per_unit.');
        }
        $units = $fixed->div($contribution)->ceilToInt();
        $revenue = $price->mul($units);

        return $this->result(['contribution_per_unit' => $contribution, 'break_even_units' => $units, 'break_even_revenue' => $revenue], ['fixed_costs' => $fixed, 'price_per_unit' => $price, 'variable_cost_per_unit' => $variable]);
    }
}
