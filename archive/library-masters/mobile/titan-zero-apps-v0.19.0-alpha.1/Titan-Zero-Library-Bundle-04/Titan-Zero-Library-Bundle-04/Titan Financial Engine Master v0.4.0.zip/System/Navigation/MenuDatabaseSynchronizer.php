<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Navigation;

use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Keeps the extension-owned menu hierarchy visible on MagicAI hosts that use
 * the database-backed `menus` table. User navigation is safe to synchronise on
 * the verified base schema. Admin rows are written only when the host exposes
 * an explicit `is_admin` column, otherwise the Blueprint contribution registry
 * remains the authority for administrator navigation.
 */
final class MenuDatabaseSynchronizer
{
    /** @var array<int,string> */
    private const KEYS = [
        'ext_titan_financial',
        'titan_financial_overview',
        'titan_financial_quotes',
        'titan_financial_quote_builder',
        'titan_financial_price_books',
        'titan_financial_rate_cards',
        'titan_financial_margin_rules',
        'titan_financial_settings',
        'titan_financial_admin',
        'titan_financial_admin_overview',
        'titan_financial_admin_promotions',
        'titan_financial_admin_settings',
    ];

    public static function sync(): void
    {
        try {
            if (!Schema::hasTable('menus')) {
                return;
            }

            $required = ['key', 'parent_id', 'route', 'label', 'order', 'is_active'];
            foreach ($required as $column) {
                if (!Schema::hasColumn('menus', $column)) {
                    return;
                }
            }

            self::syncDefinitions(FinancialNavigation::user(), false);

            // Do not risk leaking Super Admin navigation into ordinary user
            // navigation on legacy schemas that cannot represent admin state.
            if (Schema::hasColumn('menus', 'is_admin')) {
                self::syncDefinitions(FinancialNavigation::admin(), true);
            }

            self::regenerateHostMenuCache();
        } catch (Throwable) {
            // Navigation compatibility must never break extension install/boot.
        }
    }

    public static function remove(): void
    {
        try {
            if (!Schema::hasTable('menus') || !Schema::hasColumn('menus', 'key')) {
                return;
            }

            app('db')->table('menus')->whereIn('key', self::KEYS)->delete();
            self::regenerateHostMenuCache();
        } catch (Throwable) {
            // Idempotent uninstall/rollback cleanup.
        }
    }

    /** @param array<int,array<string,mixed>> $definitions */
    private static function syncDefinitions(array $definitions, bool $admin): void
    {
        $parentIds = [];

        foreach ($definitions as $definition) {
            $parentKey = $definition['parent_key'] ?? null;
            $parentId = null;
            if (is_string($parentKey) && $parentKey !== '') {
                $parentId = $parentIds[$parentKey]
                    ?? app('db')->table('menus')->where('key', $parentKey)->value('id');
            }

            $row = self::rowForHost($definition, $parentId, $admin);
            app('db')->table('menus')->updateOrInsert(['key' => $definition['key']], $row);

            if ($parentKey === null) {
                $parentIds[$definition['key']] = app('db')->table('menus')
                    ->where('key', $definition['key'])
                    ->value('id');
            }
        }
    }

    /** @param array<string,mixed> $definition @return array<string,mixed> */
    private static function rowForHost(array $definition, mixed $parentId, bool $admin): array
    {
        $now = now();
        $candidate = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $definition['key'],
            'icon' => $definition['icon'] ?? null,
            'svg' => $definition['svg'] ?? null,
            'order' => $definition['order'] ?? 0,
            'is_active' => (bool) ($definition['is_active'] ?? true),
            'params' => json_encode($definition['params'] ?? [], JSON_THROW_ON_ERROR),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            'extension' => '1',
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 0,
            'is_admin' => $admin,
            'created_at' => $now,
            'updated_at' => $now,
        ];

        $row = [];
        foreach ($candidate as $column => $value) {
            if (Schema::hasColumn('menus', $column)) {
                $row[$column] = $value;
            }
        }

        return $row;
    }

    private static function regenerateHostMenuCache(): void
    {
        $menuService = 'App\\Services\\Common\\MenuService';
        if (!class_exists($menuService) || !method_exists($menuService, 'regenerate')) {
            return;
        }

        try {
            // Current MagicAI exposes MenuService::regenerate(). If a host has
            // converted it to an instance method, resolve and invoke it instead.
            $reflection = new \ReflectionMethod($menuService, 'regenerate');
            if ($reflection->isStatic()) {
                $menuService::regenerate();
            } else {
                app($menuService)->regenerate();
            }
        } catch (Throwable) {
            // Cache refresh is best-effort; the installer can still clear cache.
        }
    }
}
