<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Settings;

use App\Extensions\TitanFinancialEngine\System\Support\EngineCatalog;

final class FinancialSettingsSchema
{
    /** @return array<string,mixed> */
    public static function companyDefaults(): array
    {
        return [
            'general' => [
                'enabled' => true,
                'default_currency' => 'AUD',
                'money_decimals' => 2,
            ],
            'tax' => [
                'default_rate_percent' => '10.0000',
                'prices_include_tax' => false,
                'tax_label' => 'GST',
            ],
            'quotes' => [
                'validity_days' => 30,
                'good_margin_percent' => '25.0000',
                'better_margin_percent' => '35.0000',
                'best_margin_percent' => '45.0000',
                'default_deposit_percent' => '0.0000',
                'require_customer_acceptance' => true,
            ],
            'numbering' => [
                'quote_prefix' => 'TZQ',
                'next_quote_number' => 1,
                'pad_length' => 6,
            ],
            'approvals' => [
                'approval_below_margin_percent' => '30.0000',
                'block_below_margin_percent' => '20.0000',
                'maximum_discount_without_approval_percent' => '10.0000',
            ],
            'integrations' => [
                'jobs_enabled' => true,
                'titan_gear_enabled' => true,
                'titan_pay_enabled' => true,
            ],
        ];
    }

    /** @return array<string,mixed> */
    public static function platformDefaults(): array
    {
        return [
            'general' => [
                'enabled' => true,
                'allow_company_overrides' => true,
                'default_currency' => 'AUD',
                'default_tax_rate_percent' => '10.0000',
            ],
            'engines' => array_fill_keys(array_keys(EngineCatalog::definitions()), true),
            'governance' => [
                'persist_calculation_audit' => true,
                'require_company_context' => true,
                'allow_manual_price_override' => true,
            ],
            'integrations' => [
                'jobs_enabled' => true,
                'titan_gear_enabled' => true,
                'titan_pay_enabled' => true,
            ],
        ];
    }
}
