<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class AssetFleetEquipmentCostEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'asset_fleet_equipment_cost'; }
    public function priority(): int { return 35; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $components = (array) $context->input('hourly_components', []);
        $internal = Decimal::zero();
        foreach ($components as $component) {
            $internal = $internal->add(Decimal::from((string) $component));
        }

        if ($internal->isZero()) {
            $annualCosts = $this->decimal($context, $state, 'annual_asset_costs');
            $utilisationHours = $this->decimal($context, $state, 'annual_utilisation_hours');
            if (!$annualCosts->isZero() && $utilisationHours->compare('0') > 0) {
                $internal = $annualCosts->div($utilisationHours);
            }
        }

        $margin = $this->decimal($context, $state, 'target_margin_percent', '0');
        if ($margin->compare('100') >= 0) {
            throw new InvalidArgumentException('target_margin_percent must be less than 100.');
        }
        $charge = $margin->isZero()
            ? $internal
            : $internal->div(Decimal::from('1')->sub($margin->div(100)));

        return $this->result([
            'asset_internal_hourly_cost' => $internal,
            'asset_charge_hourly_rate' => $charge,
        ], ['hourly_components' => $components, 'target_margin_percent' => $margin]);
    }
}
