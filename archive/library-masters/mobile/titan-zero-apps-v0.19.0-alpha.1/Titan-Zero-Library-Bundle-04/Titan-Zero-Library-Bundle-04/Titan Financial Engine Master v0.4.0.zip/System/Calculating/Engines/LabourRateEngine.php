<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;

final class LabourRateEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'labour_rate'; }
    public function priority(): int { return 20; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $hours = $this->decimal($context, $state, 'hours');
        $rate = $this->decimal($context, $state, 'hourly_rate');
        $overtimeHours = $this->decimal($context, $state, 'overtime_hours');
        $overtimeMultiplier = $this->decimal($context, $state, 'overtime_multiplier', '1.5');
        $callout = $this->decimal($context, $state, 'callout_fee');
        $travel = $this->decimal($context, $state, 'travel_cost');

        $ordinary = $hours->mul($rate);
        $overtime = $overtimeHours->mul($rate)->mul($overtimeMultiplier);
        $total = $ordinary->add($overtime)->add($callout)->add($travel);

        return $this->result([
            'ordinary_labour_cost' => $ordinary,
            'overtime_labour_cost' => $overtime,
            'labour_cost' => $total,
        ], compact('hours', 'rate', 'overtimeHours', 'overtimeMultiplier', 'callout', 'travel'));
    }
}
