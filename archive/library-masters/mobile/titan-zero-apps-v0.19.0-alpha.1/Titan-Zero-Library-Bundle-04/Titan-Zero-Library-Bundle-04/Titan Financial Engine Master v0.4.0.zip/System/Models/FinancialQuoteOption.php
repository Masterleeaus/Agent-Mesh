<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class FinancialQuoteOption extends Model
{
    protected $table = 'financial_quote_options';
    protected $fillable = ['company_id','quote_id','version','option_key','name','sort_order','target_margin_percent','cost','sell_price','discount_percent','discount_amount','subtotal','tax_rate_percent','tax_amount','total','gross_profit','gross_margin_percent','approval_status','meta'];
    protected $casts = ['meta'=>'array'];
}
