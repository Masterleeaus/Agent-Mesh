<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

final class FinancialSetting extends Model
{
    protected $table = 'financial_settings';

    protected $fillable = [
        'scope_key',
        'scope',
        'company_id',
        'settings',
        'updated_by',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'settings' => 'array',
        'updated_by' => 'integer',
    ];
}
