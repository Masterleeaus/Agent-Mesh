<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class InventoryMaterialsCostEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'inventory_materials_cost'; }
    public function priority(): int { return 30; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $materials = (array) $context->input('materials', []);
        $total = Decimal::zero();
        $outputs = [];

        foreach ($materials as $index => $material) {
            $quantity = Decimal::from((string) ($material['quantity'] ?? '0'));
            $unitCost = Decimal::from((string) ($material['unit_cost'] ?? '0'));
            $waste = Decimal::from((string) ($material['waste_percent'] ?? '0'));
            $packSize = Decimal::from((string) ($material['pack_size'] ?? '0'));
            $required = $quantity->add($this->percentOf($quantity, $waste));
            $purchaseQuantity = $required;

            if ($packSize->compare('0') > 0) {
                $packs = $required->div($packSize)->ceilToInt();
                $purchaseQuantity = $packSize->mul($packs);
                $outputs["materials.{$index}.packs"] = $packs;
            }

            $lineCost = $purchaseQuantity->mul($unitCost);
            $outputs["materials.{$index}.purchase_quantity"] = $purchaseQuantity;
            $outputs["materials.{$index}.cost"] = $lineCost;
            $total = $total->add($lineCost);
        }

        $outputs['materials_cost'] = $total;
        return $this->result($outputs, ['materials' => $materials]);
    }
}
