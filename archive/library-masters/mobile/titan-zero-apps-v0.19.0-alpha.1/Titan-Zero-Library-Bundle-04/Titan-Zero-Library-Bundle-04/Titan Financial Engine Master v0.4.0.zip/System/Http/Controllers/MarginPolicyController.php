<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Models\MarginPolicy;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class MarginPolicyController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $policies = MarginPolicy::query()->where('company_id',$companyId)->orderByDesc('active')->orderBy('name')->limit(5000)->get();
        return view('titan-financial-engine::financial.margin-policies', compact('companyId','policies'));
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $data = $request->validate([
            'id'=>['nullable','integer'],'name'=>['required','string','max:255'],'approval_below_percent'=>['required','numeric','min:0','lt:100'],
            'block_below_percent'=>['required','numeric','min:0','lt:100','lte:approval_below_percent'],'maximum_discount_percent'=>['nullable','numeric','min:0','max:100'],'active'=>['sometimes','boolean'],
        ]);
        $policy = isset($data['id']) ? MarginPolicy::query()->where('company_id',$companyId)->findOrFail((int)$data['id']) : new MarginPolicy();
        unset($data['id']);
        $policy->fill(array_merge($data,['company_id'=>$companyId,'active'=>(bool)($data['active'] ?? true)]));
        $policy->save();
        return back()->with('success', __('Margin policy saved.'));
    }

    public function destroy(Request $request, int $policy): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        MarginPolicy::query()->where('company_id',$companyId)->findOrFail($policy)->delete();
        return back()->with('success', __('Margin policy deleted.'));
    }
}
