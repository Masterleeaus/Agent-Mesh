<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class RateCardItem extends Model
{
    protected $table = 'financial_rate_card_items';
    protected $fillable = ['company_id','rate_card_id','code','name','skill_or_role','unit','cost_rate','base_rate','overtime_multiplier','weekend_multiplier','public_holiday_multiplier','after_hours_multiplier','minimum_units','callout_fee','travel_rate','active','meta'];
    protected $casts = ['active'=>'boolean','meta'=>'array'];
}
