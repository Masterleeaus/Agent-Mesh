<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Models\RateCard;
use App\Extensions\TitanFinancialEngine\System\Models\RateCardItem;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class RateCardController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $cards = RateCard::query()->where('company_id',$companyId)->orderByDesc('active')->orderBy('name')->limit(5000)->get();
        $items = RateCardItem::query()->where('company_id',$companyId)->orderBy('name')->limit(5000)->get()->groupBy('rate_card_id');
        return view('titan-financial-engine::financial.rate-cards', compact('companyId','cards','items'));
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $data = $request->validate(['id'=>['nullable','integer'],'name'=>['required','string','max:255'],'currency'=>['required','string','size:3'],'active'=>['sometimes','boolean'],'effective_from'=>['nullable','date'],'effective_to'=>['nullable','date','after_or_equal:effective_from']]);
        $card = isset($data['id']) ? RateCard::query()->where('company_id',$companyId)->findOrFail((int)$data['id']) : new RateCard();
        $card->fill(['company_id'=>$companyId,'name'=>$data['name'],'currency'=>strtoupper($data['currency']),'active'=>(bool)($data['active'] ?? true),'rates'=>[],'effective_from'=>$data['effective_from'] ?? null,'effective_to'=>$data['effective_to'] ?? null]);
        $card->save();
        return back()->with('success', __('Rate card saved.'));
    }

    public function storeItem(Request $request): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $data = $request->validate([
            'rate_card_id'=>['required','integer'],'item_id'=>['nullable','integer'],'code'=>['required','string','max:100'],'name'=>['required','string','max:255'],'skill_or_role'=>['nullable','string','max:255'],'unit'=>['required','string','max:40'],
            'cost_rate'=>['required','numeric','min:0'],'base_rate'=>['required','numeric','min:0'],'overtime_multiplier'=>['required','numeric','min:1'],'weekend_multiplier'=>['required','numeric','min:1'],'public_holiday_multiplier'=>['required','numeric','min:1'],'after_hours_multiplier'=>['required','numeric','min:1'],
            'minimum_units'=>['required','numeric','min:0'],'callout_fee'=>['required','numeric','min:0'],'travel_rate'=>['required','numeric','min:0'],'active'=>['sometimes','boolean'],
        ]);
        RateCard::query()->where('company_id',$companyId)->findOrFail((int)$data['rate_card_id']);
        $item = isset($data['item_id']) ? RateCardItem::query()->where('company_id',$companyId)->where('rate_card_id',$data['rate_card_id'])->findOrFail((int)$data['item_id']) : new RateCardItem();
        unset($data['item_id']);
        $item->fill(array_merge($data,['company_id'=>$companyId,'active'=>(bool)($data['active'] ?? true)]));
        $item->save();
        return back()->with('success', __('Rate card item saved.'));
    }

    public function destroy(Request $request, int $rateCard): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        RateCardItem::query()->where('company_id',$companyId)->where('rate_card_id',$rateCard)->delete();
        RateCard::query()->where('company_id',$companyId)->findOrFail($rateCard)->delete();
        return back()->with('success', __('Rate card deleted.'));
    }

    public function destroyItem(Request $request, int $item): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        RateCardItem::query()->where('company_id',$companyId)->findOrFail($item)->delete();
        return back()->with('success', __('Rate card item deleted.'));
    }
}
