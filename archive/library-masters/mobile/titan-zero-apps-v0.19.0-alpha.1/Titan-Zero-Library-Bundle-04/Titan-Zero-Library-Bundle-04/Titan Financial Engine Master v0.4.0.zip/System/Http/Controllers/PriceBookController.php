<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Models\PriceBook;
use App\Extensions\TitanFinancialEngine\System\Models\PriceBookItem;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class PriceBookController extends Controller
{
    public function index(Request $request): View
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $books = PriceBook::query()->where('company_id', $companyId)->orderByDesc('active')->orderBy('name')->limit(5000)->get();
        $items = PriceBookItem::query()->where('company_id', $companyId)->orderBy('name')->limit(5000)->get()->groupBy('price_book_id');
        return view('titan-financial-engine::financial.price-books', compact('companyId', 'books', 'items'));
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $data = $request->validate([
            'id' => ['nullable','integer','min:1'], 'name' => ['required','string','max:255'],
            'currency' => ['required','string','size:3'], 'active' => ['sometimes','boolean'],
            'effective_from' => ['nullable','date'], 'effective_to' => ['nullable','date','after_or_equal:effective_from'],
        ]);
        $book = isset($data['id']) ? PriceBook::query()->where('company_id', $companyId)->findOrFail((int) $data['id']) : new PriceBook();
        $book->fill(['company_id'=>$companyId,'name'=>$data['name'],'currency'=>strtoupper($data['currency']),'active'=>(bool)($data['active'] ?? true),'effective_from'=>$data['effective_from'] ?? null,'effective_to'=>$data['effective_to'] ?? null]);
        $book->save();
        return back()->with('success', __('Price book saved.'));
    }

    public function storeItem(Request $request): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $data = $request->validate([
            'price_book_id'=>['required','integer','min:1'],'item_id'=>['nullable','integer','min:1'],'code'=>['required','string','max:100'],
            'name'=>['required','string','max:255'],'description'=>['nullable','string','max:2000'],'item_type'=>['required','string','max:40'],
            'unit'=>['required','string','max:40'],'cost'=>['required','numeric','min:0'],'sell_price'=>['nullable','numeric','min:0'],
            'pricing_method'=>['required','in:fixed,markup,target_margin'],'target_margin_percent'=>['nullable','numeric','min:0','lt:100'],
            'markup_percent'=>['nullable','numeric','min:0'],'tax_rate_percent'=>['required','numeric','min:0','max:100'],
            'minimum_price'=>['nullable','numeric','min:0'],'maximum_discount_percent'=>['nullable','numeric','min:0','max:100'],'active'=>['sometimes','boolean'],
        ]);
        PriceBook::query()->where('company_id', $companyId)->findOrFail((int)$data['price_book_id']);
        $item = isset($data['item_id']) ? PriceBookItem::query()->where('company_id',$companyId)->where('price_book_id',$data['price_book_id'])->findOrFail((int)$data['item_id']) : new PriceBookItem();
        $item->fill(array_merge($data, ['company_id'=>$companyId,'active'=>(bool)($data['active'] ?? true)]));
        unset($item->item_id);
        $item->save();
        return back()->with('success', __('Price book item saved.'));
    }

    public function destroy(Request $request, int $priceBook): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        PriceBookItem::query()->where('company_id',$companyId)->where('price_book_id',$priceBook)->delete();
        PriceBook::query()->where('company_id',$companyId)->findOrFail($priceBook)->delete();
        return back()->with('success', __('Price book deleted.'));
    }

    public function destroyItem(Request $request, int $item): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        PriceBookItem::query()->where('company_id',$companyId)->findOrFail($item)->delete();
        return back()->with('success', __('Price book item deleted.'));
    }
}
