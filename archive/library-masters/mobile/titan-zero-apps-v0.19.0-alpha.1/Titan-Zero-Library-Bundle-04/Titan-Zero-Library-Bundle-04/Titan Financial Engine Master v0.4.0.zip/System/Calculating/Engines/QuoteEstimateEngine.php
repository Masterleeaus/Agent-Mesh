<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class QuoteEstimateEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'quote_estimate'; }
    public function priority(): int { return 60; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $components = ['labour_cost','materials_cost','equipment_cost','travel_cost','subcontractor_cost','permit_cost','disposal_cost','overhead_cost','contingency_cost','other_cost'];
        $subtotal = Decimal::zero();
        $resolved = [];
        foreach ($components as $key) {
            $value = $this->decimal($context, $state, $key, '0');
            $resolved[$key] = $value;
            $subtotal = $subtotal->add($value);
        }
        if ($state?->has('sell_price')) {
            $subtotal = $state->decimalValue('sell_price');
        }
        return $this->result(['quote_subtotal' => $subtotal, 'subtotal' => $subtotal, 'base_price' => $subtotal], $resolved);
    }
}
