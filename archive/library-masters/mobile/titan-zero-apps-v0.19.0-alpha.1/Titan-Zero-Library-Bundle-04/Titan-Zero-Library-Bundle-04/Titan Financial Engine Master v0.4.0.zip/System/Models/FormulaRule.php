<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class FormulaRule extends Model
{
    protected $table = 'financial_formula_rules';
    protected $fillable = ['company_id','key','name','version','priority','active','definition','effective_from','effective_to'];
    protected $casts = ['active'=>'boolean','definition'=>'array','effective_from'=>'datetime','effective_to'=>'datetime'];
}
