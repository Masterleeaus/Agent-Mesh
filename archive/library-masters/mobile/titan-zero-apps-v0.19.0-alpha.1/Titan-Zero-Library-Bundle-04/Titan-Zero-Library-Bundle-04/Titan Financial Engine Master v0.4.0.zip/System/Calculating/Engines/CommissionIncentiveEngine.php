<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use InvalidArgumentException;

final class CommissionIncentiveEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'commission_incentive'; }
    public function priority(): int { return 120; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $basisType = (string) $this->value($context, $state, 'commission_basis', 'revenue');
        $basis = match ($basisType) {
            'revenue' => $this->decimal($context, $state, 'revenue', $this->decimal($context, $state, 'subtotal', '0')),
            'gross_profit' => $this->decimal($context, $state, 'gross_profit'),
            default => throw new InvalidArgumentException("Unsupported commission_basis: {$basisType}"),
        };
        $percent = $this->decimal($context, $state, 'commission_percent');
        $fixed = $this->decimal($context, $state, 'commission_fixed');
        $commission = $this->percentOf($basis, $percent)->add($fixed);

        return $this->result(['commission_basis_amount' => $basis, 'commission_amount' => $commission], ['commission_basis' => $basisType, 'commission_percent' => $percent, 'commission_fixed' => $fixed]);
    }
}
