<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\DTO;

use InvalidArgumentException;

final class CalculationContext
{
    public function __construct(
        public readonly int $companyId,
        public readonly string $currency = 'AUD',
        private readonly array $inputs = [],
        private readonly array $meta = [],
    ) {
        if ($companyId <= 0) {
            throw new InvalidArgumentException('company_id is required and must be greater than zero.');
        }
        if (!preg_match('/^[A-Z]{3}$/', strtoupper($currency))) {
            throw new InvalidArgumentException('currency must be a three-letter ISO-style code.');
        }
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return array_key_exists($key, $this->inputs) ? $this->inputs[$key] : $default;
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->inputs);
    }

    public function inputs(): array
    {
        return $this->inputs;
    }

    public function meta(string $key, mixed $default = null): mixed
    {
        return array_key_exists($key, $this->meta) ? $this->meta[$key] : $default;
    }

    public function metadata(): array
    {
        return $this->meta;
    }
}
