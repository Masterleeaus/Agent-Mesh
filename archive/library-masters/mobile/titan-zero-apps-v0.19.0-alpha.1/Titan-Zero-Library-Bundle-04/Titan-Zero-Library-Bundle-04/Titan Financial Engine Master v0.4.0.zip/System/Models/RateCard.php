<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class RateCard extends Model
{
    protected $table = 'financial_rate_cards';
    protected $fillable = ['company_id','name','currency','active','rates','effective_from','effective_to'];
    protected $casts = ['active'=>'boolean','rates'=>'array','effective_from'=>'datetime','effective_to'=>'datetime'];
}
