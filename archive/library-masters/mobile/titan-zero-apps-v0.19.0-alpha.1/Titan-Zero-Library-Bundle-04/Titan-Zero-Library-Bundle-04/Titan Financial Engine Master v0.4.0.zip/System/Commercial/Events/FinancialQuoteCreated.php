<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Commercial\Events;
final class FinancialQuoteCreated
{
    public function __construct(public readonly int $companyId, public readonly int $quoteId, public readonly array $payload = []) {}
}
