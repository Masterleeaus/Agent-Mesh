<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Commercial\Services;

use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class QuoteCostService
{
    /** @return array{total_cost:Decimal,lines:array<int,array<string,mixed>>} */
    public function summarize(array $lines): array
    {
        $total = Decimal::zero();
        $normalized = [];
        foreach ($lines as $line) {
            $quantity = Decimal::from((string)($line['quantity'] ?? '1'));
            $unitCost = Decimal::from((string)($line['unit_cost'] ?? '0'));
            $costTotal = Decimal::from($quantity->mul($unitCost)->toString(2));
            $total = $total->add($costTotal);
            $normalized[] = array_merge($line, [
                'quantity' => $quantity->toString(6),
                'unit_cost' => $unitCost->toString(6),
                'cost_total' => $costTotal->toString(2),
            ]);
        }
        return ['total_cost' => $total, 'lines' => $normalized];
    }
}
