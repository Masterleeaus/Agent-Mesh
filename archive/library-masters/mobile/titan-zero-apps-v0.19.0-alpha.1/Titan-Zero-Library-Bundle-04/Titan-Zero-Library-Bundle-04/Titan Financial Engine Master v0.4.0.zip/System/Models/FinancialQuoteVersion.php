<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class FinancialQuoteVersion extends Model
{
    public $timestamps = false;
    protected $table = 'financial_quote_versions';
    protected $fillable = ['company_id','quote_id','version','status','input_snapshot','totals_snapshot','created_by','created_at'];
    protected $casts = ['input_snapshot'=>'array','totals_snapshot'=>'array','created_at'=>'datetime'];
}
