<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class ProcurementLandedCostEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'procurement_landed_cost'; }
    public function priority(): int { return 25; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $positive = ['supplier_price','freight','duties','brokerage','insurance','handling','storage','currency_cost'];
        $total = Decimal::zero();
        $inputs = [];
        foreach ($positive as $key) {
            $value = $this->decimal($context, $state, $key);
            $inputs[$key] = $value;
            $total = $total->add($value);
        }
        $rebates = $this->decimal($context, $state, 'rebates');
        $total = $total->sub($rebates);
        $inputs['rebates'] = $rebates;

        return $this->result(['landed_cost' => $total], $inputs);
    }
}
