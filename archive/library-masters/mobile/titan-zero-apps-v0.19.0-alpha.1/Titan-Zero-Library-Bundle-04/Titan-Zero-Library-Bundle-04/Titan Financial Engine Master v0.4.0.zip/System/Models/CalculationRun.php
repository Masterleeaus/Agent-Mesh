<?php

namespace App\Extensions\TitanFinancialEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

class CalculationRun extends Model
{
    protected $table = 'financial_calculation_runs';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'id','company_id','user_id','currency','engine_keys','status','context_type','context_id',
        'input_snapshot','output_snapshot','completed_at'
    ];

    protected $casts = [
        'engine_keys' => 'array',
        'input_snapshot' => 'array',
        'output_snapshot' => 'array',
        'completed_at' => 'datetime',
    ];
}
