<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class MarginProfitabilityEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'margin_profitability'; }
    public function priority(): int { return 80; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $revenue = $this->decimal($context, $state, 'revenue', $this->decimal($context, $state, 'subtotal', '0'));
        $cost = $this->decimal($context, $state, 'cost', $this->decimal($context, $state, 'total_cost', '0'));
        $profit = $revenue->sub($cost);
        $margin = $revenue->isZero() ? Decimal::zero() : $profit->div($revenue)->mul(100);
        $markup = $cost->isZero() ? Decimal::zero() : $profit->div($cost)->mul(100);
        $minimum = $this->decimal($context, $state, 'minimum_margin_percent', '0');
        $status = $margin->compare($minimum) >= 0 ? 'approved' : 'approval_required';

        return $this->result([
            'gross_profit' => $profit,
            'gross_margin_percent' => $margin,
            'markup_percent' => $markup,
            'margin_status' => $status,
        ], ['revenue' => $revenue, 'cost' => $cost, 'minimum_margin_percent' => $minimum]);
    }
}
