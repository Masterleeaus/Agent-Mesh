<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\Contracts;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;

interface CalculatingEngine
{
    public function key(): string;
    public function priority(): int;
    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult;
}
