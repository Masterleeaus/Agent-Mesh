<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Settings;

use App\Extensions\TitanFinancialEngine\System\Models\FinancialSetting;
use Illuminate\Support\Facades\DB;

final class FinancialSettingsService
{
    /** @return array<string,mixed> */
    public function company(int $companyId): array
    {
        $platform = $this->platform();
        $defaults = FinancialSettingsSchema::companyDefaults();
        $defaults['general']['default_currency'] = (string) ($platform['general']['default_currency'] ?? $defaults['general']['default_currency']);
        $defaults['tax']['default_rate_percent'] = (string) ($platform['general']['default_tax_rate_percent'] ?? $defaults['tax']['default_rate_percent']);

        $record = FinancialSetting::query()
            ->where('scope_key', self::companyScopeKey($companyId))
            ->first();
        $saved = $record?->settings;
        $resolved = array_replace_recursive($defaults, is_array($saved) ? $saved : []);

        if (!(bool) ($platform['general']['allow_company_overrides'] ?? true)) {
            $resolved['general']['default_currency'] = $defaults['general']['default_currency'];
            $resolved['tax']['default_rate_percent'] = $defaults['tax']['default_rate_percent'];
        }

        foreach (['jobs_enabled', 'titan_gear_enabled', 'titan_pay_enabled'] as $integration) {
            if (!(bool) ($platform['integrations'][$integration] ?? true)) {
                $resolved['integrations'][$integration] = false;
            }
        }

        return $resolved;
    }

    /** @param array<string,mixed> $settings @return array<string,mixed> */
    public function saveCompany(int $companyId, array $settings, ?int $userId): array
    {
        $merged = array_replace_recursive($this->company($companyId), $settings);
        FinancialSetting::query()->updateOrCreate(
            ['scope_key' => self::companyScopeKey($companyId)],
            [
                'scope' => 'company',
                'company_id' => $companyId,
                'settings' => $merged,
                'updated_by' => $userId,
            ]
        );

        return $merged;
    }

    /**
     * Reserve the next quote sequence atomically for the company and return its
     * formatted document number. The sequence lives in the company settings
     * record so numbering configuration is authoritative rather than cosmetic.
     */
    public function nextQuoteNumber(int $companyId, ?int $userId = null): string
    {
        return DB::transaction(function () use ($companyId, $userId): string {
            $scopeKey = self::companyScopeKey($companyId);
            $record = FinancialSetting::query()->where('scope_key', $scopeKey)->lockForUpdate()->first();

            if ($record === null) {
                $record = FinancialSetting::query()->create([
                    'scope_key' => $scopeKey,
                    'scope' => 'company',
                    'company_id' => $companyId,
                    'settings' => $this->company($companyId),
                    'updated_by' => $userId,
                ]);
            }

            $values = array_replace_recursive($this->company($companyId), is_array($record->settings) ? $record->settings : []);
            $number = max(1, (int) ($values['numbering']['next_quote_number'] ?? 1));
            $prefix = strtoupper((string) ($values['numbering']['quote_prefix'] ?? 'TZQ'));
            $pad = min(12, max(1, (int) ($values['numbering']['pad_length'] ?? 6)));

            $values['numbering']['next_quote_number'] = $number + 1;
            $record->settings = $values;
            $record->updated_by = $userId;
            $record->save();

            return $prefix . '-' . str_pad((string) $number, $pad, '0', STR_PAD_LEFT);
        });
    }

    /** @return array<string,mixed> */
    public function platform(): array
    {
        $record = FinancialSetting::query()
            ->where('scope_key', 'platform')
            ->first();
        $saved = $record?->settings;

        return array_replace_recursive(FinancialSettingsSchema::platformDefaults(), is_array($saved) ? $saved : []);
    }

    /** @param array<string,mixed> $settings @return array<string,mixed> */
    public function savePlatform(array $settings, ?int $userId): array
    {
        $merged = array_replace_recursive(FinancialSettingsSchema::platformDefaults(), $settings);
        FinancialSetting::query()->updateOrCreate(
            ['scope_key' => 'platform'],
            [
                'scope' => 'platform',
                'company_id' => null,
                'settings' => $merged,
                'updated_by' => $userId,
            ]
        );

        return $merged;
    }

    private static function companyScopeKey(int $companyId): string
    {
        return 'company:' . $companyId;
    }
}
