<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Integration\TitanApps;

/**
 * Provider-owned semantic contributions for the public Titan Apps boundary.
 *
 * This adapter intentionally contains no Interface Runtime, Interaction Engine or Builder
 * implementation and grants no execution authority. Actions remain capability intents.
 */
final class TitanAppsContributionProvider
{
    public const OWNER_EXTENSION = 'titan-financial-engine';
    public const REGISTRY_KEY = 'titan-apps.interface-contributions.' . self::OWNER_EXTENSION;

    /** @return array<int,array<string,mixed>> */
    public function contributions(): array
    {
        return [['contribution_id' => 'financial.summary', 'owner_extension' => 'titan-financial-engine', 'supported_surfaces' => ['zero'], 'variants' => ['FinancialSummary'], 'projection_ids' => ['financial.summary.read'], 'action_ids' => [], 'capability_ids' => ['financial.summary'], 'permissions' => ['financial.summary'], 'sensitivity' => 'confidential_financial', 'risk_classification' => 'read_only', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability'], ['contribution_id' => 'quote.margin-review', 'owner_extension' => 'titan-financial-engine', 'supported_surfaces' => ['zero'], 'variants' => ['QuoteMarginReview'], 'projection_ids' => ['financial.quote.read'], 'action_ids' => ['financial.quote.approve'], 'capability_ids' => ['financial.quote.read', 'financial.quote.approve'], 'permissions' => ['financial.quote.read', 'financial.quote.approve'], 'sensitivity' => 'confidential_financial', 'risk_classification' => 'governed', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability']];
    }

    /** @return array<string,mixed> */
    public function contractDescriptor(): array
    {
        return [
            'owner_extension' => self::OWNER_EXTENSION,
            'supported_surfaces' => $this->supportedSurfaces(),
            'canonical_app_boundary' => ['zero', 'go', 'hub'],
            'canonical_surfaces_only' => true,
            'interface_runtime' => 'public_contract_only',
            'interaction_engine' => 'public_contract_only',
            'builder' => 'contribution_registration_only',
            'package_location_independent' => true,
            'authority' => 'none',
        ];
    }
    /** @return array<int,string> */
    private function supportedSurfaces(): array
    {
        $surfaces = [];
        foreach ($this->contributions() as $contribution) {
            foreach (($contribution['supported_surfaces'] ?? []) as $surface) {
                if (is_string($surface) && ! in_array($surface, $surfaces, true)) {
                    $surfaces[] = $surface;
                }
            }
        }

        return $surfaces;
    }

}
