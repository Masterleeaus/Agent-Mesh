<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class JobCostingEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'job_costing'; }
    public function priority(): int { return 40; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $keys = ['actual_labour_cost','actual_materials_cost','actual_equipment_cost','actual_travel_cost','actual_subcontractor_cost','actual_other_cost'];
        $total = Decimal::zero();
        $inputs = [];
        foreach ($keys as $key) {
            $value = $this->decimal($context, $state, $key);
            $inputs[$key] = $value;
            $total = $total->add($value);
        }
        $estimated = $this->decimal($context, $state, 'estimated_cost', '0');
        $variance = $total->sub($estimated);
        $variancePercent = $estimated->isZero() ? Decimal::zero() : $variance->div($estimated)->mul(100);

        return $this->result([
            'total_cost' => $total,
            'cost_variance' => $variance,
            'cost_variance_percent' => $variancePercent,
        ], array_merge($inputs, ['estimated_cost' => $estimated]));
    }
}
