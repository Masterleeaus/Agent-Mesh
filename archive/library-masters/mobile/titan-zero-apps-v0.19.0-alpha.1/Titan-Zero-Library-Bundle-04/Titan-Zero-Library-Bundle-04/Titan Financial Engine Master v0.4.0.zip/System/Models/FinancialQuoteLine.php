<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class FinancialQuoteLine extends Model
{
    protected $table = 'financial_quote_lines';
    protected $fillable = ['company_id','quote_id','version','code','description','line_type','quantity','unit','unit_cost','cost_total','taxable','tax_rate_percent','source_type','source_id','meta'];
    protected $casts = ['taxable'=>'boolean','meta'=>'array'];
}
