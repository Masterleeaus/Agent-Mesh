<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\Services\CalculatingEngineService;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use App\Extensions\TitanFinancialEngine\System\Models\CalculationRun;
use App\Extensions\TitanFinancialEngine\System\Models\CalculationStep;
use App\Extensions\TitanFinancialEngine\System\Settings\FinancialSettingsSchema;
use App\Extensions\TitanFinancialEngine\System\Settings\FinancialSettingsService;
use App\Extensions\TitanFinancialEngine\System\Support\AssistantInputAdapter;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Extensions\TitanFinancialEngine\System\Support\EngineCatalog;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Throwable;

final class FinancialEngineController extends Controller
{
    public function index(CalculatingEngineService $service, FinancialSettingsService $settings): View
    {
        $platform = $settings->platform();

        return view('titan-financial-engine::financial.dashboard', [
            'engineDefinitions' => EngineCatalog::definitions(),
            'assistantDefinitions' => EngineCatalog::assistants(),
            'registeredEngines' => $service->keys(),
            'platformEngineSettings' => (array) ($platform['engines'] ?? []),
        ]);
    }

    public function engines(CalculatingEngineService $service): JsonResponse
    {
        $assistants = EngineCatalog::assistants();

        return response()->json([
            'engines' => array_map(
                fn (string $key) => [
                    'key' => $key,
                    'name' => $assistants[$key]['name'] ?? Str::headline($key),
                    'description' => $assistants[$key]['description'] ?? EngineCatalog::definitions()[$key] ?? '',
                    'icon' => $assistants[$key]['icon'] ?? 'tabler-calculator',
                ],
                $service->keys()
            ),
        ]);
    }

    public function assistant(Request $request, string $engine, CalculatingEngineService $service, FinancialSettingsService $settings): View
    {
        $assistant = $this->assistantDefinition($engine, $service);
        $isAdmin = $request->routeIs('dashboard.admin.titan-financial-engine.*');
        $companyId = null;

        if ($isAdmin) {
            $requested = (int) $request->query('company_id', 0);
            $companyId = $requested > 0 ? $requested : null;
            $companySettings = $companyId !== null ? $settings->company($companyId) : FinancialSettingsSchema::companyDefaults();
        } else {
            $companyId = CompanyContextResolver::resolve(auth()->user(), null);
            $companySettings = $settings->company($companyId);
        }

        return view('titan-financial-engine::financial.assistant', [
            'engineKey' => $engine,
            'assistant' => $assistant,
            'companyId' => $companyId,
            'isAdminFinancial' => $isAdmin,
            'formValues' => $this->assistantDefaults($assistant, $companySettings),
            'displayResults' => [],
            'calculationTrace' => [],
            'runId' => null,
            'assistantError' => null,
        ]);
    }

    public function assistantCalculate(Request $request, string $engine, CalculatingEngineService $service, FinancialSettingsService $settings): View
    {
        $assistant = $this->assistantDefinition($engine, $service);
        $isAdmin = $request->routeIs('dashboard.admin.titan-financial-engine.*');
        $requestedCompanyId = $request->filled('company_id') ? (int) $request->input('company_id') : null;
        $companyId = CompanyContextResolver::resolve(auth()->user(), $requestedCompanyId);
        $platformSettings = $settings->platform();
        $companySettings = $settings->company($companyId);

        if (!(bool) ($platformSettings['general']['enabled'] ?? true) || !(bool) ($companySettings['general']['enabled'] ?? true)) {
            abort(403, 'Titan Financial Engine is disabled for this company.');
        }
        if (!(bool) ($platformSettings['engines'][$engine] ?? true)) {
            abort(403, 'This financial assistant is disabled by platform settings.');
        }

        $raw = $request->input('inputs', []);
        if (!is_array($raw)) {
            throw ValidationException::withMessages(['inputs' => 'Assistant inputs must be submitted as fields.']);
        }

        $formValues = $this->sanitizeAssistantForm($assistant, $raw);
        $inputs = AssistantInputAdapter::adapt($engine, $formValues);
        $currency = strtoupper((string) ($request->input('currency') ?: ($companySettings['general']['default_currency'] ?? 'AUD')));
        $runId = (string) Str::uuid();
        $displayResults = [];
        $trace = [];
        $error = null;

        try {
            $context = new CalculationContext($companyId, $currency, $inputs, [
                'context_type' => 'financial_assistant',
                'context_id' => $engine,
                'assistant_name' => $assistant['name'],
            ]);
            $result = $service->calculate([$engine], $context);
            $normalized = $result->toArray();
            $values = (array) ($normalized['values'] ?? []);

            if ($engine === 'formula_rules') {
                $outputName = AssistantInputAdapter::formulaOutputName($formValues);
                if (array_key_exists($outputName, $values)) {
                    $values['result'] = $values[$outputName];
                }
            }

            $displayResults = $this->presentAssistantResults($assistant, $values, $currency);
            $trace = (array) ($normalized['steps'] ?? []);

            $persistAudit = (bool) ($platformSettings['governance']['persist_calculation_audit'] ?? true);
            if ($persistAudit) {
                $this->persistRun($runId, $context, [$engine], $normalized);
            }
        } catch (Throwable $e) {
            report($e);
            $error = $e->getMessage();
        }

        return view('titan-financial-engine::financial.assistant', [
            'engineKey' => $engine,
            'assistant' => $assistant,
            'companyId' => $companyId,
            'isAdminFinancial' => $isAdmin,
            'formValues' => $formValues,
            'displayResults' => $displayResults,
            'calculationTrace' => $trace,
            'runId' => $runId,
            'assistantError' => $error,
            'currency' => $currency,
        ]);
    }

    public function calculate(Request $request, CalculatingEngineService $service, FinancialSettingsService $settings): JsonResponse
    {
        $validated = $request->validate([
            'company_id' => ['nullable','integer','min:1'],
            'currency' => ['sometimes','string','size:3'],
            'engines' => ['required','array','min:1','max:17'],
            'engines.*' => ['string', Rule::in($service->keys())],
            'inputs' => ['sometimes','array'],
            'meta' => ['sometimes','array'],
            'persist' => ['sometimes','boolean'],
        ]);

        $companyId = CompanyContextResolver::resolve(auth()->user(), isset($validated['company_id']) ? (int) $validated['company_id'] : null);
        $platformSettings = $settings->platform();
        $companySettings = $settings->company($companyId);
        if (!(bool) ($platformSettings['general']['enabled'] ?? true) || !(bool) ($companySettings['general']['enabled'] ?? true)) {
            abort(403, 'Titan Financial Engine is disabled for this company.');
        }

        $disabledEngines = array_values(array_filter(
            $validated['engines'],
            static fn (string $engine): bool => !(bool) ($platformSettings['engines'][$engine] ?? true)
        ));
        if ($disabledEngines !== []) {
            return response()->json([
                'message' => 'One or more requested financial engines are disabled by platform settings.',
                'disabled_engines' => $disabledEngines,
            ], 422);
        }

        $currency = strtoupper((string) ($validated['currency'] ?? $companySettings['general']['default_currency'] ?? 'AUD'));
        $context = new CalculationContext($companyId, $currency, $validated['inputs'] ?? [], $validated['meta'] ?? []);
        $runId = (string) Str::uuid();
        $persistAudit = (bool) ($platformSettings['governance']['persist_calculation_audit'] ?? true)
            && (($validated['persist'] ?? true) === true);

        try {
            $result = $service->calculate($validated['engines'], $context);
            if ($persistAudit) {
                $this->persistRun($runId, $context, $validated['engines'], $result->toArray());
            }

            return response()->json([
                'run_id' => $runId,
                'company_id' => $companyId,
                'currency' => $currency,
                'engines' => $validated['engines'],
                'result' => $result->toArray(),
            ]);
        } catch (Throwable $e) {
            report($e);
            return response()->json([
                'run_id' => $runId,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /** @return array<string,mixed> */
    private function assistantDefinition(string $engine, CalculatingEngineService $service): array
    {
        $assistant = EngineCatalog::assistants()[$engine] ?? null;
        if (!$service->has($engine) || !is_array($assistant)) {
            abort(404, 'Unknown financial assistant.');
        }

        return $assistant;
    }

    /** @param array<string,mixed> $assistant @param array<string,mixed> $companySettings @return array<string,mixed> */
    private function assistantDefaults(array $assistant, array $companySettings): array
    {
        $values = [];
        foreach ((array) ($assistant['fields'] ?? []) as $field) {
            $name = (string) ($field['name'] ?? '');
            if ($name !== '') {
                $values[$name] = $field['default'] ?? '';
            }
        }

        $overrides = [
            'tax_rate_percent' => $companySettings['tax']['default_rate_percent'] ?? null,
            'target_margin_percent' => $companySettings['quotes']['better_margin_percent'] ?? null,
            'minimum_margin_percent' => $companySettings['approvals']['approval_below_margin_percent'] ?? null,
            'deposit_percent' => $companySettings['quotes']['default_deposit_percent'] ?? null,
        ];
        foreach ($overrides as $key => $value) {
            if ($value !== null && array_key_exists($key, $values)) {
                $values[$key] = (string) $value;
            }
        }

        return $values;
    }

    /** @param array<string,mixed> $assistant @param array<string,mixed> $raw @return array<string,mixed> */
    private function sanitizeAssistantForm(array $assistant, array $raw): array
    {
        $clean = [];
        foreach ((array) ($assistant['fields'] ?? []) as $field) {
            $name = (string) ($field['name'] ?? '');
            $type = (string) ($field['type'] ?? 'text');
            if ($name === '') {
                continue;
            }

            if ($type === 'checkbox') {
                $clean[$name] = !empty($raw[$name]);
                continue;
            }

            $value = $raw[$name] ?? ($field['default'] ?? '');
            if (is_array($value) || is_object($value)) {
                throw ValidationException::withMessages(["inputs.{$name}" => 'Enter a single value.']);
            }
            $value = trim((string) $value);

            if ($type === 'select') {
                $options = (array) ($field['options'] ?? []);
                if (!array_key_exists($value, $options)) {
                    throw ValidationException::withMessages(["inputs.{$name}" => 'Choose one of the available options.']);
                }
                $clean[$name] = $value;
                continue;
            }

            if (in_array($type, ['money','percent','number','integer'], true)) {
                $value = str_replace([',', '$', '%', ' '], '', $value);
                if ($value === '') {
                    $value = (string) ($field['default'] ?? '0');
                }
                $pattern = $type === 'integer' ? '/^-?\d+$/' : '/^-?\d+(?:\.\d{1,6})?$/' ;
                if (preg_match($pattern, $value) !== 1) {
                    throw ValidationException::withMessages(["inputs.{$name}" => 'Enter a valid number.']);
                }
                $clean[$name] = $type === 'integer' ? (string) ((int) $value) : $value;
                continue;
            }

            $clean[$name] = mb_substr($value, 0, 120);
        }

        return $clean;
    }

    /** @param array<string,mixed> $assistant @param array<string,mixed> $values @return array<int,array<string,string>> */
    private function presentAssistantResults(array $assistant, array $values, string $currency): array
    {
        $rows = [];
        foreach ((array) ($assistant['results'] ?? []) as $result) {
            $key = (string) ($result['key'] ?? '');
            if ($key === '' || !array_key_exists($key, $values)) {
                continue;
            }
            $format = (string) ($result['format'] ?? 'number');
            $rows[] = [
                'key' => $key,
                'label' => (string) ($result['label'] ?? Str::headline($key)),
                'value' => $this->formatAssistantValue($values[$key], $format, $currency),
                'format' => $format,
            ];
        }

        return $rows;
    }

    private function formatAssistantValue(mixed $value, string $format, string $currency): string
    {
        if (is_array($value)) {
            return (string) json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        }
        if ($format === 'status') {
            return Str::headline((string) $value);
        }
        if ($format === 'money') {
            return $currency . ' ' . Decimal::from((string) $value)->toString(2);
        }
        if ($format === 'percent') {
            return Decimal::from((string) $value)->toString(2) . '%';
        }
        if (is_int($value)) {
            return (string) $value;
        }
        if (is_string($value) && preg_match('/^-?\d+(?:\.\d+)?$/', $value) === 1) {
            return rtrim(rtrim(Decimal::from($value)->toString(4), '0'), '.');
        }

        return (string) $value;
    }

    private function persistRun(string $runId, CalculationContext $context, array $engines, array $result): void
    {
        DB::transaction(function () use ($runId, $context, $engines, $result): void {
            CalculationRun::create([
                'id' => $runId,
                'company_id' => $context->companyId,
                'user_id' => auth()->id(),
                'currency' => strtoupper($context->currency),
                'engine_keys' => $engines,
                'status' => 'completed',
                'context_type' => $context->meta('context_type'),
                'context_id' => $context->meta('context_id'),
                'input_snapshot' => $context->inputs(),
                'output_snapshot' => $result['values'] ?? [],
                'completed_at' => now(),
            ]);

            foreach (($result['steps'] ?? []) as $sequence => $step) {
                CalculationStep::create([
                    'run_id' => $runId,
                    'company_id' => $context->companyId,
                    'sequence' => $sequence + 1,
                    'engine_key' => $step['engine'] ?? 'unknown',
                    'input_snapshot' => $step['inputs'] ?? [],
                    'output_snapshot' => $step['outputs'] ?? [],
                    'notes' => $step['notes'] ?? [],
                    'created_at' => now(),
                ]);
            }
        });
    }
}
