<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use InvalidArgumentException;

final class PricingEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'pricing'; }
    public function priority(): int { return 50; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $cost = $this->decimal($context, $state, 'cost', $this->decimal($context, $state, 'total_cost', '0'));
        $method = (string) $this->value($context, $state, 'pricing_method', 'target_margin');
        $inputs = ['cost' => $cost, 'pricing_method' => $method];

        $sell = match ($method) {
            'fixed' => $this->decimal($context, $state, 'fixed_price'),
            'markup' => $cost->add($this->percentOf($cost, $this->decimal($context, $state, 'markup_percent'))),
            'target_margin' => $this->targetMarginPrice($cost, $this->decimal($context, $state, 'target_margin_percent')),
            default => throw new InvalidArgumentException("Unsupported pricing_method: {$method}"),
        };

        return $this->result(['sell_price' => $sell, 'subtotal' => $sell], $inputs);
    }

    private function targetMarginPrice($cost, $margin)
    {
        if ($margin->compare('100') >= 0) {
            throw new InvalidArgumentException('target_margin_percent must be less than 100.');
        }
        return $cost->div(
            \App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal::from('1')
                ->sub($margin->div(100))
        );
    }
}
