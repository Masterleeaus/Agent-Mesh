<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class FormulaRulesEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'formula_rules'; }
    public function priority(): int { return 10; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $variables = [];
        foreach ((array) $context->input('variables', []) as $key => $value) {
            $variables[(string) $key] = Decimal::from((string) $value);
        }
        if ($state) {
            foreach ($state->values() as $key => $value) {
                if ($value instanceof Decimal) {
                    $variables[$key] = $value;
                }
            }
        }

        foreach ((array) $context->input('formula', []) as $operation) {
            $op = (string) ($operation['op'] ?? '');
            $as = (string) ($operation['as'] ?? '');
            if ($as === '') {
                throw new InvalidArgumentException('Every formula operation requires an "as" output key.');
            }
            $left = $this->operand($operation['left'] ?? '0', $variables);
            $right = $this->operand($operation['right'] ?? '0', $variables);
            $variables[$as] = match ($op) {
                'add' => $left->add($right),
                'subtract' => $left->sub($right),
                'multiply' => $left->mul($right),
                'divide' => $left->div($right),
                'min' => $left->min($right),
                'max' => $left->max($right),
                default => throw new InvalidArgumentException("Unsupported formula operation: {$op}"),
            };
        }

        return $this->result($variables, ['variables' => $context->input('variables', []), 'formula' => $context->input('formula', [])], ['execution' => 'structured-no-eval']);
    }

    private function operand(mixed $operand, array $variables): Decimal
    {
        if (is_string($operand) && array_key_exists($operand, $variables)) {
            return $variables[$operand];
        }
        return Decimal::from(is_int($operand) || is_string($operand) ? $operand : '0');
    }
}
