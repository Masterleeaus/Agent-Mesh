<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class MarginPolicy extends Model
{
    protected $table = 'financial_margin_policies';
    protected $fillable = ['company_id','name','approval_below_percent','block_below_percent','maximum_discount_percent','active','applies_to'];
    protected $casts = ['active'=>'boolean','applies_to'=>'array'];
}
