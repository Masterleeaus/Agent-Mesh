<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

final class ForecastCashFlowEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'forecast_cash_flow'; }
    public function priority(): int { return 140; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $opening = $this->decimal($context, $state, 'opening_balance');
        $balance = $opening;
        $minimum = $opening;
        $rows = [];
        foreach ((array) $context->input('periods', []) as $period) {
            $inflows = Decimal::from((string) ($period['inflows'] ?? '0'));
            $outflows = Decimal::from((string) ($period['outflows'] ?? '0'));
            $net = $inflows->sub($outflows);
            $balance = $balance->add($net);
            if ($balance->compare($minimum) < 0) {
                $minimum = $balance;
            }
            $rows[] = ['label' => (string) ($period['label'] ?? ''), 'inflows' => $inflows, 'outflows' => $outflows, 'net' => $net, 'ending_balance' => $balance];
        }

        return $this->result(['forecast_periods' => $rows, 'ending_balance' => $balance, 'minimum_balance' => $minimum], ['opening_balance' => $opening, 'periods' => $context->input('periods', [])]);
    }
}
