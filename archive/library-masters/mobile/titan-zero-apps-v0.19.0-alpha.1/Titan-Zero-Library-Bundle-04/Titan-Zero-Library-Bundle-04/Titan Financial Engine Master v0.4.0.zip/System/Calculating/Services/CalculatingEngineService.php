<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\Services;

use App\Extensions\TitanFinancialEngine\System\Calculating\Contracts\CalculatingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use InvalidArgumentException;

final class CalculatingEngineService
{
    /** @var array<string, CalculatingEngine> */
    private array $engines = [];

    public function registerEngine(CalculatingEngine $engine): void
    {
        $this->engines[$engine->key()] = $engine;
    }

    public function has(string $key): bool
    {
        return isset($this->engines[$key]);
    }

    public function keys(): array
    {
        return array_keys($this->engines);
    }

    public function engine(string $key): CalculatingEngine
    {
        if (!isset($this->engines[$key])) {
            throw new InvalidArgumentException("Unknown calculating engine: {$key}");
        }
        return $this->engines[$key];
    }

    public function calculate(array $engineKeys, CalculationContext $context): CalculationResult
    {
        $state = new CalculationResult();
        foreach ($engineKeys as $key) {
            $state = $state->merge($this->engine((string) $key)->calculate($context, $state));
        }
        return $state;
    }
}
