<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Navigation;

final class FinancialNavigation
{
    public const USER_PARENT = 'ext_titan_financial';
    public const ADMIN_PARENT = 'titan_financial_admin';

    /** @return array<int,array<string,mixed>> */
    public static function user(): array
    {
        return [
            self::item(null, self::USER_PARENT, 'dashboard.titan-financial-engine.overview', 'Financial Assistants', 10, false, 'tabler-calculator', ['dashboard.titan-financial-engine.*']),
            self::item(self::USER_PARENT, 'titan_financial_overview', 'dashboard.titan-financial-engine.overview', 'All Assistants', 1, false, 'tabler-apps'),
            self::item(self::USER_PARENT, 'titan_financial_quotes', 'dashboard.titan-financial-engine.quotes.index', 'Quotes', 2, false, 'tabler-file-invoice'),
            self::item(self::USER_PARENT, 'titan_financial_quote_builder', 'dashboard.titan-financial-engine.quotes.create', 'Create Quote', 3, false, 'tabler-file-plus'),
            self::item(self::USER_PARENT, 'titan_financial_price_books', 'dashboard.titan-financial-engine.price-books.index', 'Price Books', 4, false, 'tabler-book-2'),
            self::item(self::USER_PARENT, 'titan_financial_rate_cards', 'dashboard.titan-financial-engine.rate-cards.index', 'Rate Cards', 5, false, 'tabler-clock-dollar'),
            self::item(self::USER_PARENT, 'titan_financial_margin_rules', 'dashboard.titan-financial-engine.margin-policies.index', 'Margin Rules', 6, false, 'tabler-chart-line'),
            self::item(self::USER_PARENT, 'titan_financial_settings', 'dashboard.titan-financial-engine.settings.index', 'Settings', 7, false, 'tabler-settings'),
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public static function admin(): array
    {
        return [
            self::item(null, self::ADMIN_PARENT, 'dashboard.admin.titan-financial-engine.index', 'Titan Financial Engine', 40, true, 'tabler-report-money', ['dashboard.admin.titan-financial-engine.*']),
            self::item(self::ADMIN_PARENT, 'titan_financial_admin_overview', 'dashboard.admin.titan-financial-engine.index', 'Assistant Overview', 1, true, 'tabler-apps'),
            self::item(self::ADMIN_PARENT, 'titan_financial_admin_promotions', 'dashboard.admin.titan-financial-engine.promotions.index', 'Promotions & Discounts', 2, true, 'tabler-discount-2'),
            self::item(self::ADMIN_PARENT, 'titan_financial_admin_settings', 'dashboard.admin.titan-financial-engine.settings.index', 'Settings', 3, true, 'tabler-settings'),
        ];
    }

    /** @return array<string,mixed> */
    private static function item(
        ?string $parentKey,
        string $key,
        string $route,
        string $label,
        int $order,
        bool $admin = false,
        ?string $icon = null,
        ?array $activeCondition = null
    ): array {
        return [
            'parent_key' => $parentKey,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => $label,
            'icon' => $icon,
            'svg' => null,
            'order' => $order,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => true,
            'active_condition' => $activeCondition ?? [$route],
            'show_condition' => true,
            'is_admin' => $admin,
            'data-name' => $key,
        ];
    }
}
