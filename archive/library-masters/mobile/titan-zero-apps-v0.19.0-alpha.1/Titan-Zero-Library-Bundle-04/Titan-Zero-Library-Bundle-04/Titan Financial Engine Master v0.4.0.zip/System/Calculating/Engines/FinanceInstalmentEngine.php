<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use InvalidArgumentException;

final class FinanceInstalmentEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'finance_instalment'; }
    public function priority(): int { return 130; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $principal = $this->decimal($context, $state, 'principal');
        $depositPercent = $this->decimal($context, $state, 'deposit_percent');
        $annualRate = $this->decimal($context, $state, 'annual_rate_percent');
        $months = (int) $this->value($context, $state, 'term_months', 1);
        if ($months <= 0) {
            throw new InvalidArgumentException('term_months must be greater than zero.');
        }

        $deposit = $this->percentOf($principal, $depositPercent);
        $balance = $principal->sub($deposit);
        $financeCharge = $this->percentOf($balance, $annualRate)->mul($months)->div(12);
        $financedTotal = $balance->add($financeCharge);
        $instalment = $financedTotal->div($months);

        return $this->result([
            'deposit_amount' => $deposit,
            'financed_balance' => $balance,
            'finance_charge' => $financeCharge,
            'financed_total' => $financedTotal,
            'instalment_amount' => $instalment,
        ], ['principal' => $principal, 'deposit_percent' => $depositPercent, 'annual_rate_percent' => $annualRate, 'term_months' => $months], ['interest_method' => 'simple']);
    }
}
