<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Commercial\Events\FinancialQuoteApproved;
use App\Extensions\TitanFinancialEngine\System\Commercial\Events\FinancialQuoteCreated;
use App\Extensions\TitanFinancialEngine\System\Commercial\Events\FinancialQuoteOptionSelected;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\MarginApprovalService;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\CatalogLineFactory;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteCostService;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteOptionBuilder;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteIntegrationPayloadBuilder;
use App\Extensions\TitanFinancialEngine\System\Models\FinancialQuote;
use App\Extensions\TitanFinancialEngine\System\Models\FinancialQuoteLine;
use App\Extensions\TitanFinancialEngine\System\Models\FinancialQuoteOption;
use App\Extensions\TitanFinancialEngine\System\Models\FinancialQuoteVersion;
use App\Extensions\TitanFinancialEngine\System\Models\MarginPolicy;
use App\Extensions\TitanFinancialEngine\System\Models\PriceBook;
use App\Extensions\TitanFinancialEngine\System\Models\PriceBookItem;
use App\Extensions\TitanFinancialEngine\System\Models\RateCard;
use App\Extensions\TitanFinancialEngine\System\Models\RateCardItem;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Extensions\TitanFinancialEngine\System\Settings\FinancialSettingsService;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

final class QuoteBuilderController extends Controller
{
    public function __construct(
        private readonly QuoteCostService $costService,
        private readonly QuoteOptionBuilder $optionBuilder,
        private readonly MarginApprovalService $marginApproval,
        private readonly QuoteIntegrationPayloadBuilder $integrationPayloads,
        private readonly CatalogLineFactory $catalogLines,
        private readonly FinancialSettingsService $settings,
    ) {}

    public function index(Request $request): View
    {
        $companyId = $this->companyId($request);
        $quotes = FinancialQuote::query()->where('company_id',$companyId)->latest()->paginate(25);
        return view('titan-financial-engine::quotes.index', compact('companyId','quotes'));
    }

    public function create(Request $request): View
    {
        $companyId = $this->companyId($request);
        return view('titan-financial-engine::quotes.create', [
            'companyId'=>$companyId,
            'financialSettings'=>$this->settings->company($companyId),
            'priceBooks'=>PriceBook::query()->where('company_id',$companyId)->where('active',true)->orderBy('name')->limit(5000)->get(),
            'rateCards'=>RateCard::query()->where('company_id',$companyId)->where('active',true)->orderBy('name')->limit(5000)->get(),
            'marginPolicies'=>MarginPolicy::query()->where('company_id',$companyId)->where('active',true)->orderBy('name')->limit(5000)->get(),
        ]);
    }

    public function priceBookCatalog(Request $request, int $priceBook): JsonResponse
    {
        $companyId = $this->companyId($request);
        PriceBook::query()->where('company_id',$companyId)->where('active',true)->findOrFail($priceBook);
        $items = PriceBookItem::query()->where('company_id',$companyId)->where('price_book_id',$priceBook)->where('active',true)->orderBy('name')->limit(5000)->get();
        return response()->json(['items'=>$items->map(fn ($item) => ['id'=>$item->id,'name'=>$item->name,'code'=>$item->code,'quote_line'=>$this->catalogLines->fromPriceBookItem($item->toArray())])->values()]);
    }

    public function rateCardCatalog(Request $request, int $rateCard): JsonResponse
    {
        $companyId = $this->companyId($request);
        RateCard::query()->where('company_id',$companyId)->where('active',true)->findOrFail($rateCard);
        $items = RateCardItem::query()->where('company_id',$companyId)->where('rate_card_id',$rateCard)->where('active',true)->orderBy('name')->limit(5000)->get();
        return response()->json(['items'=>$items->map(fn ($item) => ['id'=>$item->id,'name'=>$item->name,'code'=>$item->code,'quote_line'=>$this->catalogLines->fromRateCardItem($item->toArray())])->values()]);
    }

    public function simulate(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);
        $data = $this->validatedQuoteInput($request, false);
        $summary = $this->costService->summarize($data['lines']);
        $definitions = $this->optionDefinitions($data);
        $options = $this->optionBuilder->build($summary['total_cost'], $definitions, (string)$data['tax_rate_percent']);
        $policy = $this->resolvePolicy($companyId, $data['margin_policy_id'] ?? null);
        $options = $this->applyApprovals($options, $policy, $companyId);
        $safe = $this->marginApproval->maximumSafeDiscount(
            $options[0]['sell_price'] ?? $summary['total_cost'],
            $summary['total_cost'],
            $policy?->block_below_percent ?? (string) ($this->settings->company($companyId)['approvals']['block_below_margin_percent'] ?? '15')
        );

        return response()->json([
            'company_id'=>$companyId,
            'total_cost'=>$summary['total_cost']->toString(2),
            'options'=>$options,
            'maximum_safe_discount'=>[
                'amount'=>$safe['amount']->toString(2),
                'percent'=>$safe['percent']->toString(4),
                'floor_price'=>$safe['floor_price']->toString(2),
            ],
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = $this->companyId($request);
        $data = $this->validatedQuoteInput($request, true);
        $summary = $this->costService->summarize($data['lines']);
        $policy = $this->resolvePolicy($companyId, $data['margin_policy_id'] ?? null);
        $options = $this->applyApprovals(
            $this->optionBuilder->build($summary['total_cost'], $this->optionDefinitions($data), (string)$data['tax_rate_percent']),
            $policy,
            $companyId
        );

        $quote = DB::transaction(function () use ($companyId,$data,$summary,$options,$policy): FinancialQuote {
            $quote = FinancialQuote::create([
                'company_id'=>$companyId,
                'quote_number'=>null,
                'customer_id'=>$data['customer_id'] ?? null,
                'job_id'=>$data['job_id'] ?? null,
                'price_book_id'=>$data['price_book_id'] ?? null,
                'rate_card_id'=>$data['rate_card_id'] ?? null,
                'margin_policy_id'=>$policy?->id,
                'title'=>$data['title'],
                'status'=>'draft',
                'currency'=>strtoupper($data['currency']),
                'valid_until'=>$data['valid_until'] ?? null,
                'notes'=>$data['notes'] ?? null,
                'totals'=>['total_cost'=>$summary['total_cost']->toString(2),'options'=>$options],
                'meta'=>['integration'=>['customer_id'=>$data['customer_id'] ?? null,'job_id'=>$data['job_id'] ?? null]],
                'created_by'=>auth()->id(),
            ]);
            $quote->quote_number = $this->settings->nextQuoteNumber($companyId, auth()->id());
            $quote->save();

            FinancialQuoteVersion::create([
                'company_id'=>$companyId,'quote_id'=>$quote->id,'version'=>1,'status'=>'draft',
                'input_snapshot'=>$data,'totals_snapshot'=>['total_cost'=>$summary['total_cost']->toString(2),'options'=>$options],
                'created_by'=>auth()->id(),'created_at'=>now(),
            ]);

            foreach ($summary['lines'] as $line) {
                FinancialQuoteLine::create([
                    'company_id'=>$companyId,'quote_id'=>$quote->id,'version'=>1,
                    'code'=>$line['code'] ?? null,'description'=>$line['description'],'line_type'=>$line['line_type'] ?? 'service',
                    'quantity'=>$line['quantity'],'unit'=>$line['unit'] ?? 'each','unit_cost'=>$line['unit_cost'],'cost_total'=>$line['cost_total'],
                    'taxable'=>(bool)($line['taxable'] ?? true),'tax_rate_percent'=>$line['tax_rate_percent'] ?? $data['tax_rate_percent'],
                    'source_type'=>$line['source_type'] ?? null,'source_id'=>$line['source_id'] ?? null,
                    'meta'=>$line['meta'] ?? null,
                ]);
            }

            foreach ($options as $index=>$option) {
                FinancialQuoteOption::create([
                    'company_id'=>$companyId,'quote_id'=>$quote->id,'version'=>1,'option_key'=>$option['key'],'name'=>$option['name'],'sort_order'=>$index,
                    'target_margin_percent'=>$option['target_margin_percent'],'cost'=>$option['cost'],'sell_price'=>$option['sell_price'],
                    'discount_percent'=>$option['discount_percent'],'discount_amount'=>$option['discount_amount'],'subtotal'=>$option['subtotal'],
                    'tax_rate_percent'=>$option['tax_rate_percent'],'tax_amount'=>$option['tax_amount'],'total'=>$option['total'],
                    'gross_profit'=>$option['gross_profit'],'gross_margin_percent'=>$option['gross_margin_percent'],'approval_status'=>$option['approval_status'],'meta'=>$option['meta'] ?? null,
                ]);
            }

            return $quote;
        });

        event(new FinancialQuoteCreated($companyId, $quote->id, ['quote_number'=>$quote->quote_number]));
        return redirect()->route('dashboard.titan-financial-engine.quotes.show', ['quote'=>$quote->id])->with('success', __('Quote created.'));
    }

    public function show(Request $request, int $quote): View
    {
        $companyId = $this->companyId($request);
        $quoteModel = FinancialQuote::query()->where('company_id',$companyId)->findOrFail($quote);
        $version = (int)(FinancialQuoteVersion::query()->where('quote_id',$quoteModel->id)->max('version') ?: 1);
        $options = FinancialQuoteOption::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->orderBy('sort_order')->limit(5000)->get();
        $lines = FinancialQuoteLine::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->orderBy('id')->limit(5000)->get();
        return view('titan-financial-engine::quotes.show', ['companyId'=>$companyId,'quote'=>$quoteModel,'version'=>$version,'options'=>$options,'lines'=>$lines]);
    }

    public function integrations(Request $request, int $quote): JsonResponse
    {
        $companyId = $this->companyId($request);
        $quoteModel = FinancialQuote::query()->where('company_id',$companyId)->findOrFail($quote);
        if (!$quoteModel->selected_option_key) {
            throw ValidationException::withMessages(['quote'=>__('Select a quote option before requesting integration hand-offs.')]);
        }
        $version = (int)(FinancialQuoteVersion::query()->where('quote_id',$quoteModel->id)->max('version') ?: 1);
        $option = FinancialQuoteOption::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->where('option_key',$quoteModel->selected_option_key)->firstOrFail();
        $lines = FinancialQuoteLine::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->orderBy('id')->limit(5000)->get()->map->toArray()->all();
        return response()->json($this->filteredIntegrationPayload($companyId, $quoteModel->toArray(), $option->toArray(), $lines));
    }

    public function select(Request $request, int $quote): RedirectResponse
    {
        $companyId = $this->companyId($request);
        $data = $request->validate(['option_key'=>['required','string','max:40']]);
        $quoteModel = FinancialQuote::query()->where('company_id',$companyId)->findOrFail($quote);
        $version = (int)(FinancialQuoteVersion::query()->where('quote_id',$quoteModel->id)->max('version') ?: 1);
        $option = FinancialQuoteOption::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->where('option_key',$data['option_key'])->firstOrFail();
        if ($option->approval_status === 'blocked') {
            throw ValidationException::withMessages(['option_key'=>__('This option is below the configured margin floor and cannot be selected.')]);
        }
        $quoteModel->selected_option_key = $option->option_key;
        $quoteModel->status = $option->approval_status === 'approval_required' ? 'pending_approval' : 'selected';
        $quoteModel->save();
        event(new FinancialQuoteOptionSelected($companyId,$quoteModel->id,$option->option_key,['approval_status'=>$option->approval_status]));
        return back()->with('success', __('Quote option selected.'));
    }

    public function approve(Request $request, int $quote): RedirectResponse
    {
        $companyId = $this->companyId($request);
        $quoteModel = FinancialQuote::query()->where('company_id',$companyId)->findOrFail($quote);
        if (!$quoteModel->selected_option_key) {
            throw ValidationException::withMessages(['quote'=>__('Select a quote option before approval.')]);
        }
        $version = (int)(FinancialQuoteVersion::query()->where('quote_id',$quoteModel->id)->max('version') ?: 1);
        $option = FinancialQuoteOption::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->where('option_key',$quoteModel->selected_option_key)->firstOrFail();
        if ($option->approval_status === 'blocked') {
            throw ValidationException::withMessages(['quote'=>__('Blocked margin options cannot be approved.')]);
        }
        $option->approval_status = 'approved';
        $option->save();
        $quoteModel->status='approved';
        $quoteModel->approved_by=auth()->id();
        $quoteModel->approved_at=now();
        $quoteModel->save();
        $lines = FinancialQuoteLine::query()->where('company_id',$companyId)->where('quote_id',$quoteModel->id)->where('version',$version)->orderBy('id')->limit(5000)->get()->map->toArray()->all();
        $handoffs = $this->filteredIntegrationPayload($companyId, $quoteModel->fresh()->toArray(), $option->fresh()->toArray(), $lines);
        event(new FinancialQuoteApproved($companyId,$quoteModel->id,$option->option_key,['total'=>(string)$option->total,'handoffs'=>$handoffs]));
        return back()->with('success', __('Quote approved.'));
    }

    private function validatedQuoteInput(Request $request, bool $requireTitle): array
    {
        return $request->validate([
            'title'=>[$requireTitle ? 'required' : 'nullable','string','max:255'],
            'company_id'=>['nullable','integer','min:1'],'customer_id'=>['nullable','integer','min:1'],'job_id'=>['nullable','integer','min:1'],
            'price_book_id'=>['nullable','integer','min:1'],'rate_card_id'=>['nullable','integer','min:1'],'margin_policy_id'=>['nullable','integer','min:1'],
            'currency'=>['required','string','size:3'],'valid_until'=>['nullable','date'],'notes'=>['nullable','string','max:5000'],
            'tax_rate_percent'=>['required','numeric','min:0','max:100'],
            'good_margin_percent'=>['required','numeric','min:0','lt:100'],'better_margin_percent'=>['required','numeric','min:0','lt:100','gte:good_margin_percent'],'best_margin_percent'=>['required','numeric','min:0','lt:100','gte:better_margin_percent'],
            'good_discount_percent'=>['nullable','numeric','min:0','max:100'],'better_discount_percent'=>['nullable','numeric','min:0','max:100'],'best_discount_percent'=>['nullable','numeric','min:0','max:100'],
            'lines'=>['required','array','min:1','max:200'],'lines.*.code'=>['nullable','string','max:100'],'lines.*.description'=>['required','string','max:255'],
            'lines.*.line_type'=>['nullable','string','max:40'],'lines.*.quantity'=>['required','numeric','gt:0'],'lines.*.unit'=>['nullable','string','max:40'],'lines.*.unit_cost'=>['required','numeric','min:0'],
            'lines.*.taxable'=>['nullable','boolean'],'lines.*.tax_rate_percent'=>['nullable','numeric','min:0','max:100'],'lines.*.source_type'=>['nullable','string','max:80'],'lines.*.source_id'=>['nullable','string','max:120'],
        ]);
    }

    private function optionDefinitions(array $data): array
    {
        return [
            ['key'=>'good','name'=>'Good','target_margin_percent'=>(string)$data['good_margin_percent'],'discount_percent'=>(string)($data['good_discount_percent'] ?? '0')],
            ['key'=>'better','name'=>'Better','target_margin_percent'=>(string)$data['better_margin_percent'],'discount_percent'=>(string)($data['better_discount_percent'] ?? '0')],
            ['key'=>'best','name'=>'Best','target_margin_percent'=>(string)$data['best_margin_percent'],'discount_percent'=>(string)($data['best_discount_percent'] ?? '0')],
        ];
    }

    private function resolvePolicy(int $companyId, ?int $policyId): ?MarginPolicy
    {
        if ($policyId) return MarginPolicy::query()->where('company_id',$companyId)->findOrFail($policyId);
        return MarginPolicy::query()->where('company_id',$companyId)->where('active',true)->orderBy('id')->first();
    }

    private function applyApprovals(array $options, ?MarginPolicy $policy, int $companyId): array
    {
        $companySettings = $this->settings->company($companyId);
        $approvalSettings = $companySettings['approvals'] ?? [];
        $policyValues = [
            'approval_below_percent'=>$policy?->approval_below_percent ?? (string) ($approvalSettings['approval_below_margin_percent'] ?? '25'),
            'block_below_percent'=>$policy?->block_below_percent ?? (string) ($approvalSettings['block_below_margin_percent'] ?? '15'),
        ];
        $maximumDiscount = $policy?->maximum_discount_percent
            ?? (string) ($approvalSettings['maximum_discount_without_approval_percent'] ?? '10');

        foreach ($options as &$option) {
            $decision = $this->marginApproval->evaluate((string)$option['gross_margin_percent'], $policyValues);
            if (Decimal::from((string)$option['discount_percent'])->compare((string)$maximumDiscount) > 0 && $decision['status'] === 'approved') {
                $decision['status'] = 'approval_required';
            }
            $option['approval_status']=$decision['status'];
            $option['meta']=['margin_policy_id'=>$policy?->id];
        }
        unset($option);
        return $options;
    }

    /** @param array<string,mixed> $quote @param array<string,mixed> $option @param array<int,array<string,mixed>> $lines */
    private function filteredIntegrationPayload(int $companyId, array $quote, array $option, array $lines): array
    {
        $payload = $this->integrationPayloads->build($quote, $option, $lines);
        $integrationSettings = $this->settings->company($companyId)['integrations'] ?? [];
        $mapping = [
            'jobs' => 'jobs_enabled',
            'gear' => 'titan_gear_enabled',
            'pay' => 'titan_pay_enabled',
        ];
        $enabled = [];
        foreach ($mapping as $section => $settingKey) {
            $isEnabled = (bool) ($integrationSettings[$settingKey] ?? true);
            $enabled[$section] = $isEnabled;
            if (!$isEnabled) {
                unset($payload[$section]);
            }
        }
        $payload['integrations_enabled'] = $enabled;

        return $payload;
    }

    private function companyId(Request $request): int
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $platform = $this->settings->platform();
        $company = $this->settings->company($companyId);
        if (!(bool) ($platform['general']['enabled'] ?? true) || !(bool) ($company['general']['enabled'] ?? true)) {
            abort(403, 'Titan Financial Engine is disabled for this company.');
        }

        return $companyId;
    }
}
