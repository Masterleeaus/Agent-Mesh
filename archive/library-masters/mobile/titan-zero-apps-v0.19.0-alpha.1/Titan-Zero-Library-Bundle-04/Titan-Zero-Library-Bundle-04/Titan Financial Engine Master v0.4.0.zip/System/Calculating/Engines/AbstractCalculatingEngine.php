<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\Contracts\CalculatingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;

abstract class AbstractCalculatingEngine implements CalculatingEngine
{
    protected function value(CalculationContext $context, ?CalculationResult $state, string $key, mixed $default = null): mixed
    {
        if ($state?->has($key)) {
            return $state->value($key);
        }
        return $context->input($key, $default);
    }

    protected function decimal(CalculationContext $context, ?CalculationResult $state, string $key, Decimal|string|int $default = '0'): Decimal
    {
        $value = $this->value($context, $state, $key, $default);
        if ($value instanceof Decimal) {
            return $value;
        }
        return Decimal::from(is_int($value) || is_string($value) ? $value : (string) $default);
    }

    protected function percentOf(Decimal $base, Decimal|string|int $percent): Decimal
    {
        return $base->mul($percent)->div(100);
    }

    protected function result(array $outputs, array $inputs = [], array $notes = []): CalculationResult
    {
        return CalculationResult::forEngine($this->key(), $outputs, $inputs, $notes);
    }
}
