<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Commercial\Services;

use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class QuoteOptionBuilder
{
    /**
     * @param array<int,array{key:string,name:string,target_margin_percent:string|int,discount_percent?:string|int}> $definitions
     * @return array<int,array<string,string>>
     */
    public function build(
        Decimal|string|int $cost,
        array $definitions,
        Decimal|string|int $taxRatePercent = '10',
    ): array {
        $cost = Decimal::from($cost);
        $taxRate = Decimal::from($taxRatePercent);
        $options = [];

        foreach ($definitions as $definition) {
            $margin = Decimal::from($definition['target_margin_percent']);
            if ($margin->compare('0') < 0 || $margin->compare('100') >= 0) {
                throw new InvalidArgumentException('target_margin_percent must be between 0 and 100.');
            }

            // Financial documents settle at money precision between commercial stages.
            $sellPrice = $this->money($cost->div(Decimal::from('1')->sub($margin->div('100'))));
            $discountPercent = Decimal::from($definition['discount_percent'] ?? '0');
            $discount = $this->money($sellPrice->mul($discountPercent)->div('100'));
            $subtotal = $this->money($sellPrice->sub($discount));
            $tax = $this->money($subtotal->mul($taxRate)->div('100'));
            $total = $this->money($subtotal->add($tax));
            $grossProfit = $this->money($subtotal->sub($cost));
            $actualMargin = $subtotal->isZero()
                ? Decimal::zero()
                : $grossProfit->div($subtotal)->mul('100');

            $options[] = [
                'key' => (string) $definition['key'],
                'name' => (string) $definition['name'],
                'cost' => $cost->toString(2),
                'target_margin_percent' => $margin->toString(4),
                'sell_price' => $sellPrice->toString(2),
                'discount_percent' => $discountPercent->toString(4),
                'discount_amount' => $discount->toString(2),
                'subtotal' => $subtotal->toString(2),
                'tax_rate_percent' => $taxRate->toString(4),
                'tax_amount' => $tax->toString(2),
                'total' => $total->toString(2),
                'gross_profit' => $grossProfit->toString(2),
                'gross_margin_percent' => $actualMargin->toString(4),
            ];
        }

        return $options;
    }

    private function money(Decimal $value): Decimal
    {
        return Decimal::from($value->toString(2));
    }
}
