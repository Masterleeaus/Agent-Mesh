<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\DTO;

use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class CalculationResult
{
    public function __construct(
        private array $values = [],
        private array $steps = [],
    ) {}

    public function value(string $key, mixed $default = null): mixed
    {
        return array_key_exists($key, $this->values) ? $this->values[$key] : $default;
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->values);
    }

    public function decimalValue(string $key, Decimal|string|int|null $default = null): Decimal
    {
        $value = $this->value($key, $default ?? '0');
        if ($value instanceof Decimal) {
            return $value;
        }
        if (is_int($value) || is_string($value)) {
            return Decimal::from($value);
        }
        throw new InvalidArgumentException("Result value {$key} is not decimal-compatible.");
    }

    public function money(string $key): string
    {
        return $this->decimalValue($key)->toString(2);
    }

    public function decimal(string $key, int $precision = 6): string
    {
        return $this->decimalValue($key)->toString($precision);
    }

    public function values(): array
    {
        return $this->values;
    }

    public function steps(): array
    {
        return $this->steps;
    }

    public function merge(self $other): self
    {
        return new self(array_replace($this->values, $other->values), array_merge($this->steps, $other->steps));
    }

    public static function forEngine(string $engine, array $values, array $inputs = [], array $notes = []): self
    {
        return new self($values, [[
            'engine' => $engine,
            'inputs' => self::normalize($inputs),
            'outputs' => self::normalize($values),
            'notes' => $notes,
        ]]);
    }

    public function toArray(): array
    {
        return [
            'values' => self::normalize($this->values),
            'steps' => self::normalize($this->steps),
        ];
    }

    private static function normalize(mixed $value): mixed
    {
        if ($value instanceof Decimal) {
            return $value->toString();
        }
        if (is_array($value)) {
            foreach ($value as $key => $item) {
                $value[$key] = self::normalize($item);
            }
        }
        return $value;
    }
}
