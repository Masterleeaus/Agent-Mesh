<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class DiscountPromotionEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'discount_promotion'; }
    public function priority(): int { return 70; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $base = $this->decimal($context, $state, 'base_price', $this->decimal($context, $state, 'subtotal', '0'));
        $type = (string) $this->value($context, $state, 'discount_type', 'percent');
        $value = $this->decimal($context, $state, 'discount_value', '0');

        if ($value->isNegative()) {
            throw new InvalidArgumentException('discount_value cannot be negative.');
        }

        if ($type === 'percent') {
            $discount = $this->percentOf($base, $value);
        } elseif ($type === 'fixed') {
            $discount = $value;
        } elseif ($type === 'final_price') {
            $discount = $base->sub($value)->max('0');
        } else {
            throw new InvalidArgumentException("Unsupported discount_type: {$type}");
        }

        $discount = $discount->min($base)->max('0');
        $after = $base->sub($discount);

        return $this->result([
            'pre_discount_price' => $base,
            'discount_amount' => $discount,
            'price_after_discount' => $after,
            'subtotal' => $after,
        ], ['base_price' => $base, 'discount_type' => $type, 'discount_value' => $value]);
    }
}
