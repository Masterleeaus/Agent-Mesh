<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class FinancialQuote extends Model
{
    protected $table = 'financial_quotes';
    protected $fillable = ['company_id','quote_number','customer_id','job_id','price_book_id','rate_card_id','margin_policy_id','title','status','currency','valid_until','selected_option_key','notes','totals','meta','created_by','approved_by','approved_at'];
    protected $casts = ['valid_until'=>'date','totals'=>'array','meta'=>'array','approved_at'=>'datetime'];
}
