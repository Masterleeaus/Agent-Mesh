<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;

final class PaymentSettlementCostEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'payment_settlement_cost'; }
    public function priority(): int { return 110; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $amount = $this->decimal($context, $state, 'payment_amount', $this->decimal($context, $state, 'total', '0'));
        $percent = $this->decimal($context, $state, 'fee_percent');
        $fixed = $this->decimal($context, $state, 'fixed_fee');
        $fee = $this->percentOf($amount, $percent)->add($fixed);
        $net = $amount->sub($fee);

        return $this->result(['payment_fee' => $fee, 'net_settlement' => $net], ['payment_amount' => $amount, 'fee_percent' => $percent, 'fixed_fee' => $fixed]);
    }
}
