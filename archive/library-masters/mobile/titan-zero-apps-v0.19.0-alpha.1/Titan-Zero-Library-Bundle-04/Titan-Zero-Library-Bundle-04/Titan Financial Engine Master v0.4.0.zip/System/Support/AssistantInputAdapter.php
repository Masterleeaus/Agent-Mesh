<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Support;

final class AssistantInputAdapter
{
    /** @param array<string,mixed> $form @return array<string,mixed> */
    public static function adapt(string $engine, array $form): array
    {
        return match ($engine) {
            'inventory_materials_cost' => [
                'materials' => [[
                    'quantity' => $form['material_quantity'] ?? '0',
                    'unit_cost' => $form['material_unit_cost'] ?? '0',
                    'waste_percent' => $form['material_waste_percent'] ?? '0',
                    'pack_size' => $form['material_pack_size'] ?? '0',
                ]],
            ],
            'forecast_cash_flow' => [
                'opening_balance' => $form['opening_balance'] ?? '0',
                'periods' => array_map(
                    static fn (int $i): array => [
                        'label' => (string) ($form["period_{$i}_label"] ?? "Period {$i}"),
                        'inflows' => (string) ($form["period_{$i}_inflows"] ?? '0'),
                        'outflows' => (string) ($form["period_{$i}_outflows"] ?? '0'),
                    ],
                    [1, 2, 3]
                ),
            ],
            'formula_rules' => self::formulaInputs($form),
            default => $form,
        };
    }

    /** @param array<string,mixed> $form */
    public static function formulaOutputName(array $form): string
    {
        return preg_replace('/[^A-Za-z0-9_]/', '_', (string) ($form['formula_output_name'] ?? 'result')) ?: 'result';
    }

    /** @param array<string,mixed> $form @return array<string,mixed> */
    private static function formulaInputs(array $form): array
    {
        return [
            'variables' => [
                'a' => $form['formula_value_a'] ?? '0',
                'b' => $form['formula_value_b'] ?? '0',
            ],
            'formula' => [[
                'op' => $form['formula_operation'] ?? 'add',
                'left' => 'a',
                'right' => 'b',
                'as' => self::formulaOutputName($form),
            ]],
        ];
    }
}
