<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Http\Controllers;

use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use App\Extensions\TitanFinancialEngine\System\Settings\FinancialSettingsService;
use App\Extensions\TitanFinancialEngine\System\Support\CompanyContextResolver;
use App\Extensions\TitanFinancialEngine\System\Support\EngineCatalog;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

final class FinancialSettingsController extends Controller
{
    public function company(Request $request, FinancialSettingsService $settings): View
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);

        $platform = $settings->platform();

        return view('titan-financial-engine::financial.settings.company', [
            'companyId' => $companyId,
            'settings' => $settings->company($companyId),
            'allowCompanyOverrides' => (bool) ($platform['general']['allow_company_overrides'] ?? true),
        ]);
    }

    public function updateCompany(Request $request, FinancialSettingsService $settings): RedirectResponse
    {
        $companyId = CompanyContextResolver::resolve(auth()->user(), $request->integer('company_id') ?: null);
        $platform = $settings->platform();
        if (!(bool) ($platform['general']['allow_company_overrides'] ?? true)) {
            abort(403, 'Company financial setting overrides are disabled by the platform administrator.');
        }

        $data = $request->validate([
            'general.enabled' => ['required','boolean'],
            'general.default_currency' => ['required','string','size:3'],
            'general.money_decimals' => ['required','integer','min:0','max:6'],
            'tax.default_rate_percent' => ['required','numeric','min:0','max:100'],
            'tax.prices_include_tax' => ['required','boolean'],
            'tax.tax_label' => ['required','string','max:40'],
            'quotes.validity_days' => ['required','integer','min:1','max:3650'],
            'quotes.good_margin_percent' => ['required','numeric','min:0','lt:100'],
            'quotes.better_margin_percent' => ['required','numeric','min:0','lt:100'],
            'quotes.best_margin_percent' => ['required','numeric','min:0','lt:100'],
            'quotes.default_deposit_percent' => ['required','numeric','min:0','max:100'],
            'quotes.require_customer_acceptance' => ['required','boolean'],
            'numbering.quote_prefix' => ['required','string','max:12','regex:/^[A-Za-z0-9-]+$/'],
            'numbering.next_quote_number' => ['required','integer','min:1'],
            'numbering.pad_length' => ['required','integer','min:1','max:12'],
            'approvals.approval_below_margin_percent' => ['required','numeric','min:0','lt:100'],
            'approvals.block_below_margin_percent' => ['required','numeric','min:0','lt:100'],
            'approvals.maximum_discount_without_approval_percent' => ['required','numeric','min:0','max:100'],
            'integrations.jobs_enabled' => ['required','boolean'],
            'integrations.titan_gear_enabled' => ['required','boolean'],
            'integrations.titan_pay_enabled' => ['required','boolean'],
        ]);

        $data['general']['default_currency'] = strtoupper($data['general']['default_currency']);
        $data['numbering']['quote_prefix'] = strtoupper($data['numbering']['quote_prefix']);
        $this->assertMarginOrder($data['quotes']);
        $this->assertApprovalOrder($data['approvals']);
        $settings->saveCompany($companyId, $data, auth()->id());

        return back()->with('success', __('Financial settings saved.'));
    }

    public function platform(FinancialSettingsService $settings): View
    {
        return view('titan-financial-engine::financial.settings.platform', [
            'settings' => $settings->platform(),
            'engineDefinitions' => EngineCatalog::definitions(),
        ]);
    }

    public function updatePlatform(Request $request, FinancialSettingsService $settings): RedirectResponse
    {
        $rules = [
            'general.enabled' => ['required','boolean'],
            'general.allow_company_overrides' => ['required','boolean'],
            'general.default_currency' => ['required','string','size:3'],
            'general.default_tax_rate_percent' => ['required','numeric','min:0','max:100'],
            'governance.persist_calculation_audit' => ['required','boolean'],
            'governance.require_company_context' => ['required','boolean'],
            'governance.allow_manual_price_override' => ['required','boolean'],
            'integrations.jobs_enabled' => ['required','boolean'],
            'integrations.titan_gear_enabled' => ['required','boolean'],
            'integrations.titan_pay_enabled' => ['required','boolean'],
        ];
        foreach (array_keys(EngineCatalog::definitions()) as $key) {
            $rules['engines.' . $key] = ['required','boolean'];
        }

        $data = $request->validate($rules);
        $data['general']['default_currency'] = strtoupper($data['general']['default_currency']);
        $settings->savePlatform($data, auth()->id());

        return back()->with('success', __('Platform financial settings saved.'));
    }

    /** @param array<string,mixed> $quotes */
    private function assertMarginOrder(array $quotes): void
    {
        if (Decimal::from((string) $quotes['good_margin_percent'])->compare((string) $quotes['better_margin_percent']) > 0
            || Decimal::from((string) $quotes['better_margin_percent'])->compare((string) $quotes['best_margin_percent']) > 0) {
            abort(422, 'Good margin must be less than or equal to Better, and Better less than or equal to Best.');
        }
    }

    /** @param array<string,mixed> $approvals */
    private function assertApprovalOrder(array $approvals): void
    {
        if (Decimal::from((string) $approvals['block_below_margin_percent'])->compare((string) $approvals['approval_below_margin_percent']) > 0) {
            abort(422, 'The hard block margin cannot exceed the approval threshold margin.');
        }
    }
}
