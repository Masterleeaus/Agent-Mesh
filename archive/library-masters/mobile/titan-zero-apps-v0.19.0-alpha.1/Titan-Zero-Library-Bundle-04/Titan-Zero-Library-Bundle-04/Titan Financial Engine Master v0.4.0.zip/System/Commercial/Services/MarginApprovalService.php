<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Commercial\Services;

use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use InvalidArgumentException;

final class MarginApprovalService
{
    /**
     * @param array{approval_below_percent?:string|int,block_below_percent?:string|int} $policy
     * @return array{status:string,margin_percent:string,approval_below_percent:string,block_below_percent:string}
     */
    public function evaluate(Decimal|string|int $marginPercent, array $policy): array
    {
        $margin = Decimal::from($marginPercent);
        $approvalBelow = Decimal::from($policy['approval_below_percent'] ?? '25');
        $blockBelow = Decimal::from($policy['block_below_percent'] ?? '15');

        if ($approvalBelow->compare($blockBelow) < 0) {
            throw new InvalidArgumentException('approval_below_percent must be greater than or equal to block_below_percent.');
        }

        $status = 'approved';
        if ($margin->compare($blockBelow) < 0) {
            $status = 'blocked';
        } elseif ($margin->compare($approvalBelow) < 0) {
            $status = 'approval_required';
        }

        return [
            'status' => $status,
            'margin_percent' => $margin->toString(4),
            'approval_below_percent' => $approvalBelow->toString(4),
            'block_below_percent' => $blockBelow->toString(4),
        ];
    }

    /** @return array{amount:Decimal,percent:Decimal,floor_price:Decimal} */
    public function maximumSafeDiscount(
        Decimal|string|int $currentPrice,
        Decimal|string|int $cost,
        Decimal|string|int $minimumMarginPercent,
    ): array {
        $price = Decimal::from($currentPrice);
        $cost = Decimal::from($cost);
        $margin = Decimal::from($minimumMarginPercent);

        if ($price->compare('0') <= 0) {
            throw new InvalidArgumentException('currentPrice must be greater than zero.');
        }
        if ($margin->compare('0') < 0 || $margin->compare('100') >= 0) {
            throw new InvalidArgumentException('minimumMarginPercent must be between 0 and 100.');
        }

        $floorPrice = $cost->div(Decimal::from('1')->sub($margin->div('100')));
        $amount = $price->sub($floorPrice)->max('0');
        $percent = $amount->div($price)->mul('100');

        return [
            'amount' => $amount,
            'percent' => $percent,
            'floor_price' => $floorPrice,
        ];
    }
}
