<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Support;

use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\AssetFleetEquipmentCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\BreakEvenScenarioEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\CommissionIncentiveEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\DiscountPromotionEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\FinanceInstalmentEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\ForecastCashFlowEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\FormulaRulesEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\InventoryMaterialsCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\JobCostingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\LabourRateEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\MarginProfitabilityEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\PaymentSettlementCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\PricingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\ProcurementLandedCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\QuoteEstimateEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\RecurringPricingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\TaxEngine;

final class EngineCatalog
{
    public static function classes(): array
    {
        return [
            FormulaRulesEngine::class,
            LabourRateEngine::class,
            ProcurementLandedCostEngine::class,
            InventoryMaterialsCostEngine::class,
            AssetFleetEquipmentCostEngine::class,
            JobCostingEngine::class,
            PricingEngine::class,
            QuoteEstimateEngine::class,
            DiscountPromotionEngine::class,
            MarginProfitabilityEngine::class,
            TaxEngine::class,
            RecurringPricingEngine::class,
            PaymentSettlementCostEngine::class,
            CommissionIncentiveEngine::class,
            FinanceInstalmentEngine::class,
            ForecastCashFlowEngine::class,
            BreakEvenScenarioEngine::class,
        ];
    }

    /** @return array<string,string> */
    public static function definitions(): array
    {
        return array_map(
            static fn (array $assistant): string => (string) $assistant['description'],
            self::assistants()
        );
    }

    /**
     * Human-facing assistant catalogue. These definitions intentionally expose
     * business language rather than the internal calculating-engine class names.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function assistants(): array
    {
        return [
            'pricing' => self::assistant(
                'Pricing Assistant', 'Pricing & Quotes', '💲', 'tabler-currency-dollar',
                'Turn a known cost into a selling price using target margin, markup or a fixed price.',
                [
                    self::money('cost', 'Your cost', '0', 'What it costs you to deliver the item or service.'),
                    self::select('pricing_method', 'Pricing method', ['target_margin'=>'Target margin','markup'=>'Markup','fixed'=>'Fixed selling price'], 'target_margin'),
                    self::percent('target_margin_percent', 'Target margin', '35', 'Used when Target margin is selected.'),
                    self::percent('markup_percent', 'Markup', '50', 'Used when Markup is selected.'),
                    self::money('fixed_price', 'Fixed selling price', '0', 'Used when Fixed selling price is selected.'),
                ],
                [self::result('sell_price', 'Recommended selling price', 'money'), self::result('subtotal', 'Pricing subtotal', 'money')]
            ),
            'quote_estimate' => self::assistant(
                'Quote & Estimate Assistant', 'Pricing & Quotes', '🧾', 'tabler-file-invoice',
                'Add the major cost components of a job to produce a reliable estimate subtotal.',
                [
                    self::money('labour_cost', 'Labour'), self::money('materials_cost', 'Materials'), self::money('equipment_cost', 'Equipment'),
                    self::money('travel_cost', 'Travel'), self::money('subcontractor_cost', 'Subcontractors'), self::money('permit_cost', 'Permits'),
                    self::money('disposal_cost', 'Disposal'), self::money('overhead_cost', 'Overheads'), self::money('contingency_cost', 'Contingency'),
                    self::money('other_cost', 'Other costs'),
                ],
                [self::result('quote_subtotal', 'Estimate subtotal', 'money')]
            ),
            'labour_rate' => self::assistant(
                'Labour Rate Assistant', 'Costs & Resources', '⏱️', 'tabler-clock-dollar',
                'Calculate ordinary labour, overtime, call-out and travel charges for a job.',
                [
                    self::number('hours', 'Ordinary hours', '1'), self::money('hourly_rate', 'Hourly rate'), self::number('overtime_hours', 'Overtime hours', '0'),
                    self::number('overtime_multiplier', 'Overtime multiplier', '1.5'), self::money('callout_fee', 'Call-out fee'), self::money('travel_cost', 'Travel charge'),
                ],
                [self::result('ordinary_labour_cost', 'Ordinary labour', 'money'), self::result('overtime_labour_cost', 'Overtime labour', 'money'), self::result('labour_cost', 'Total labour', 'money')]
            ),
            'job_costing' => self::assistant(
                'Job Costing Assistant', 'Costs & Resources', '🧰', 'tabler-briefcase',
                'Compare estimated job cost with actual labour, material, equipment and other costs.',
                [
                    self::money('estimated_cost', 'Estimated cost'), self::money('actual_labour_cost', 'Actual labour'), self::money('actual_materials_cost', 'Actual materials'),
                    self::money('actual_equipment_cost', 'Actual equipment'), self::money('actual_travel_cost', 'Actual travel'), self::money('actual_subcontractor_cost', 'Actual subcontractors'),
                    self::money('actual_other_cost', 'Other actual costs'),
                ],
                [self::result('total_cost', 'Actual total cost', 'money'), self::result('cost_variance', 'Cost variance', 'money'), self::result('cost_variance_percent', 'Variance', 'percent')]
            ),
            'margin_profitability' => self::assistant(
                'Margin & Profit Assistant', 'Profit & Decisions', '📈', 'tabler-chart-line',
                'See gross profit, margin, markup and whether a price meets your minimum margin rule.',
                [self::money('revenue', 'Selling price / revenue'), self::money('cost', 'Total cost'), self::percent('minimum_margin_percent', 'Minimum acceptable margin', '25')],
                [self::result('gross_profit', 'Gross profit', 'money'), self::result('gross_margin_percent', 'Gross margin', 'percent'), self::result('markup_percent', 'Markup', 'percent'), self::result('margin_status', 'Margin decision', 'status')]
            ),
            'discount_promotion' => self::assistant(
                'Discount Assistant', 'Pricing & Quotes', '🏷️', 'tabler-discount-2',
                'Test percentage, fixed-dollar or final-price discounts before offering them to a customer.',
                [self::money('base_price', 'Price before discount'), self::select('discount_type', 'Discount type', ['percent'=>'Percentage','fixed'=>'Fixed amount','final_price'=>'Set final price'], 'percent'), self::number('discount_value', 'Discount value', '10')],
                [self::result('discount_amount', 'Discount amount', 'money'), self::result('price_after_discount', 'Price after discount', 'money')]
            ),
            'tax' => self::assistant(
                'Tax & GST Assistant', 'Pricing & Quotes', '🧮', 'tabler-receipt-tax',
                'Calculate tax-exclusive or tax-inclusive totals such as Australian GST.',
                [self::money('subtotal', 'Amount'), self::percent('tax_rate_percent', 'Tax / GST rate', '10'), self::checkbox('tax_inclusive', 'Amount already includes tax')],
                [self::result('taxable_subtotal', 'Tax-exclusive amount', 'money'), self::result('tax_amount', 'Tax amount', 'money'), self::result('total', 'Total', 'money')]
            ),
            'inventory_materials_cost' => self::assistant(
                'Materials Cost Assistant', 'Costs & Resources', '📦', 'tabler-packages',
                'Price a material requirement including waste allowance and whole-pack purchasing.',
                [self::number('material_quantity', 'Required quantity', '1'), self::money('material_unit_cost', 'Unit cost'), self::percent('material_waste_percent', 'Waste allowance', '0'), self::number('material_pack_size', 'Pack size', '0', 'Use 0 when material is bought in exact quantities.')],
                [self::result('materials.0.purchase_quantity', 'Purchase quantity', 'number'), self::result('materials.0.packs', 'Packs required', 'number'), self::result('materials.0.cost', 'Material line cost', 'money'), self::result('materials_cost', 'Total material cost', 'money')]
            ),
            'asset_fleet_equipment_cost' => self::assistant(
                'Asset & Fleet Cost Assistant', 'Costs & Resources', '🚚', 'tabler-truck',
                'Convert annual equipment or vehicle ownership costs into an hourly internal cost and charge-out rate.',
                [self::money('annual_asset_costs', 'Annual ownership & operating costs'), self::number('annual_utilisation_hours', 'Billable / utilised hours per year', '1000'), self::percent('target_margin_percent', 'Target margin', '35')],
                [self::result('asset_internal_hourly_cost', 'Internal hourly cost', 'money'), self::result('asset_charge_hourly_rate', 'Recommended hourly charge', 'money')]
            ),
            'recurring_pricing' => self::assistant(
                'Recurring Pricing Assistant', 'Pricing & Quotes', '🔁', 'tabler-repeat',
                'Calculate per-period and full-contract value for recurring services or subscriptions.',
                [self::money('unit_price', 'Price per unit / visit'), self::number('quantity', 'Units per period', '1'), self::integer('periods', 'Number of periods', '12')],
                [self::result('period_value', 'Value per period', 'money'), self::result('contract_value', 'Total contract value', 'money')]
            ),
            'payment_settlement_cost' => self::assistant(
                'Payment Fee Assistant', 'Payments & Finance', '💳', 'tabler-credit-card',
                'See gateway fees and the net amount you actually receive after settlement costs.',
                [self::money('payment_amount', 'Customer payment'), self::percent('fee_percent', 'Gateway percentage fee', '1.75'), self::money('fixed_fee', 'Fixed fee', '0.30')],
                [self::result('payment_fee', 'Payment fee', 'money'), self::result('net_settlement', 'Net settlement', 'money')]
            ),
            'commission_incentive' => self::assistant(
                'Commission Assistant', 'Payments & Finance', '🎯', 'tabler-target-arrow',
                'Calculate staff or sales commission from revenue or gross profit, with an optional fixed amount.',
                [self::select('commission_basis', 'Commission basis', ['revenue'=>'Revenue','gross_profit'=>'Gross profit'], 'revenue'), self::money('revenue', 'Revenue'), self::money('gross_profit', 'Gross profit'), self::percent('commission_percent', 'Commission rate', '10'), self::money('commission_fixed', 'Fixed commission', '0')],
                [self::result('commission_basis_amount', 'Commission basis amount', 'money'), self::result('commission_amount', 'Commission payable', 'money')]
            ),
            'finance_instalment' => self::assistant(
                'Instalment Assistant', 'Payments & Finance', '🗓️', 'tabler-calendar-dollar',
                'Model a deposit, simple finance charge and equal instalments for customer payment plans.',
                [self::money('principal', 'Purchase / financed amount'), self::percent('deposit_percent', 'Deposit', '20'), self::percent('annual_rate_percent', 'Annual finance rate', '0'), self::integer('term_months', 'Term in months', '12')],
                [self::result('deposit_amount', 'Deposit amount', 'money'), self::result('financed_balance', 'Balance financed', 'money'), self::result('finance_charge', 'Finance charge', 'money'), self::result('financed_total', 'Total financed repayments', 'money'), self::result('instalment_amount', 'Instalment amount', 'money')]
            ),
            'forecast_cash_flow' => self::assistant(
                'Cash Flow Forecast Assistant', 'Payments & Finance', '💵', 'tabler-cash',
                'Project cash balances across three upcoming periods to identify the lowest expected balance.',
                [
                    self::money('opening_balance', 'Opening cash balance'),
                    self::text('period_1_label', 'Period 1', 'Month 1'), self::money('period_1_inflows', 'Period 1 inflows'), self::money('period_1_outflows', 'Period 1 outflows'),
                    self::text('period_2_label', 'Period 2', 'Month 2'), self::money('period_2_inflows', 'Period 2 inflows'), self::money('period_2_outflows', 'Period 2 outflows'),
                    self::text('period_3_label', 'Period 3', 'Month 3'), self::money('period_3_inflows', 'Period 3 inflows'), self::money('period_3_outflows', 'Period 3 outflows'),
                ],
                [self::result('ending_balance', 'Ending cash balance', 'money'), self::result('minimum_balance', 'Lowest projected balance', 'money')]
            ),
            'break_even_scenario' => self::assistant(
                'Break-Even Assistant', 'Profit & Decisions', '⚖️', 'tabler-scale',
                'Find how many units or jobs you need to sell before fixed costs are covered.',
                [self::money('fixed_costs', 'Fixed costs'), self::money('price_per_unit', 'Selling price per unit / job', '100'), self::money('variable_cost_per_unit', 'Variable cost per unit / job', '50')],
                [self::result('contribution_per_unit', 'Contribution per unit', 'money'), self::result('break_even_units', 'Break-even units', 'number'), self::result('break_even_revenue', 'Break-even revenue', 'money')]
            ),
            'procurement_landed_cost' => self::assistant(
                'Landed Cost Assistant', 'Costs & Resources', '🚢', 'tabler-package-import',
                'Calculate true landed procurement cost after freight, duties, brokerage, handling and rebates.',
                [
                    self::money('supplier_price', 'Supplier price'), self::money('freight', 'Freight'), self::money('duties', 'Duties / tariffs'), self::money('brokerage', 'Brokerage'),
                    self::money('insurance', 'Insurance'), self::money('handling', 'Handling'), self::money('storage', 'Storage'), self::money('currency_cost', 'Currency / FX cost'), self::money('rebates', 'Rebates / credits'),
                ],
                [self::result('landed_cost', 'Total landed cost', 'money')]
            ),
            'formula_rules' => self::assistant(
                'Formula Assistant', 'Profit & Decisions', 'ƒx', 'tabler-function',
                'Run a safe custom two-value formula without arbitrary code or eval.',
                [self::number('formula_value_a', 'Value A', '0'), self::number('formula_value_b', 'Value B', '0'), self::select('formula_operation', 'Operation', ['add'=>'Add','subtract'=>'Subtract','multiply'=>'Multiply','divide'=>'Divide','min'=>'Minimum','max'=>'Maximum'], 'add'), self::text('formula_output_name', 'Result name', 'result')],
                [self::result('result', 'Calculated result', 'number')]
            ),
        ];
    }

    /** @return array<string,mixed> */
    private static function assistant(string $name, string $category, string $symbol, string $icon, string $description, array $fields, array $results): array
    {
        return compact('name', 'category', 'symbol', 'icon', 'description', 'fields', 'results');
    }

    /** @return array<string,mixed> */
    private static function field(string $name, string $label, string $type, string $default = '0', string $help = '', array $options = []): array
    {
        return compact('name', 'label', 'type', 'default', 'help', 'options');
    }

    private static function money(string $name, string $label, string $default = '0', string $help = ''): array { return self::field($name, $label, 'money', $default, $help); }
    private static function percent(string $name, string $label, string $default = '0', string $help = ''): array { return self::field($name, $label, 'percent', $default, $help); }
    private static function number(string $name, string $label, string $default = '0', string $help = ''): array { return self::field($name, $label, 'number', $default, $help); }
    private static function integer(string $name, string $label, string $default = '1', string $help = ''): array { return self::field($name, $label, 'integer', $default, $help); }
    private static function text(string $name, string $label, string $default = '', string $help = ''): array { return self::field($name, $label, 'text', $default, $help); }
    private static function checkbox(string $name, string $label, bool $default = false, string $help = ''): array { return self::field($name, $label, 'checkbox', $default ? '1' : '0', $help); }
    private static function select(string $name, string $label, array $options, string $default, string $help = ''): array { return self::field($name, $label, 'select', $default, $help, $options); }

    /** @return array<string,string> */
    private static function result(string $key, string $label, string $format): array
    {
        return compact('key', 'label', 'format');
    }
}
