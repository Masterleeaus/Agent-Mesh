<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Commercial\Services;

final class CatalogLineFactory
{
    public function fromPriceBookItem(array $item): array
    {
        return [
            'code'=>(string)($item['code'] ?? ''),
            'description'=>(string)($item['name'] ?? ''),
            'line_type'=>(string)($item['item_type'] ?? 'service'),
            'quantity'=>'1',
            'unit'=>(string)($item['unit'] ?? 'each'),
            'unit_cost'=>(string)($item['cost'] ?? '0'),
            'source_type'=>'price_book',
            'source_id'=>(string)($item['id'] ?? ''),
            'meta'=>[
                'catalog_sell_price'=>(string)($item['sell_price'] ?? ''),
                'pricing_method'=>(string)($item['pricing_method'] ?? 'fixed'),
            ],
        ];
    }

    public function fromRateCardItem(array $item): array
    {
        return [
            'code'=>(string)($item['code'] ?? ''),
            'description'=>(string)($item['name'] ?? ''),
            'line_type'=>'labour',
            'quantity'=>'1',
            'unit'=>(string)($item['unit'] ?? 'hour'),
            'unit_cost'=>(string)($item['cost_rate'] ?? '0'),
            'source_type'=>'rate_card',
            'source_id'=>(string)($item['id'] ?? ''),
            'meta'=>[
                'catalog_charge_rate'=>(string)($item['base_rate'] ?? ''),
                'skill_or_role'=>(string)($item['skill_or_role'] ?? ''),
            ],
        ];
    }
}
