<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Commercial\Events;
final class FinancialQuoteApproved
{
    public function __construct(public readonly int $companyId, public readonly int $quoteId, public readonly string $optionKey, public readonly array $payload = []) {}
}
