<?php
namespace App\Extensions\TitanFinancialEngine\System\Models;
use Illuminate\Database\Eloquent\Model;
class PriceBook extends Model
{
    protected $table = 'financial_price_books';
    protected $fillable = ['company_id','name','currency','active','effective_from','effective_to','rules'];
    protected $casts = ['active'=>'boolean','effective_from'=>'datetime','effective_to'=>'datetime','rules'=>'array'];
}
