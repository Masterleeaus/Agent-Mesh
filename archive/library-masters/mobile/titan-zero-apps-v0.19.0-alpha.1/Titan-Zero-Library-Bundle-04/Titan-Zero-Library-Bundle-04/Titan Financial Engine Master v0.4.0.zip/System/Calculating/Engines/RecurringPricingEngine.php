<?php

declare(strict_types=1);
namespace App\Extensions\TitanFinancialEngine\System\Calculating\Engines;

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationResult;

final class RecurringPricingEngine extends AbstractCalculatingEngine
{
    public function key(): string { return 'recurring_pricing'; }
    public function priority(): int { return 100; }

    public function calculate(CalculationContext $context, ?CalculationResult $state = null): CalculationResult
    {
        $unit = $this->decimal($context, $state, 'unit_price');
        $quantity = $this->decimal($context, $state, 'quantity', '1');
        $periods = (int) $this->value($context, $state, 'periods', 1);
        $periodValue = $unit->mul($quantity);
        $contract = $periodValue->mul(max(0, $periods));

        return $this->result(['period_value' => $periodValue, 'contract_value' => $contract], ['unit_price' => $unit, 'quantity' => $quantity, 'periods' => $periods]);
    }
}
