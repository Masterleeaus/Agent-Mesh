<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanFinancialEngine\System\Calculating\Services\CalculatingEngineService;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\DiscountManagerController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\FinancialEngineController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\PriceBookController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\RateCardController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\MarginPolicyController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\QuoteBuilderController;
use App\Extensions\TitanFinancialEngine\System\Http\Controllers\FinancialSettingsController;
use App\Extensions\TitanFinancialEngine\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanFinancialEngine\System\Navigation\MenuDatabaseSynchronizer;
use App\Extensions\TitanFinancialEngine\System\Support\EngineCatalog;
use Illuminate\Routing\Router;
use Illuminate\Support\ServiceProvider;
use Throwable;

final class TitanFinancialEngineServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton('titan-apps.interface-contributions.titan-financial-engine', \App\Extensions\TitanFinancialEngine\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton(CalculatingEngineService::class, function (): CalculatingEngineService {
            $service = new CalculatingEngineService();
            foreach (EngineCatalog::classes() as $engineClass) {
                $service->registerEngine(new $engineClass());
            }
            return $service;
        });

        $this->bridgeToHostCalculatingService();
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-financial-engine');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->registerRoutes();
        HostNavigationRegistrar::register($this->app);

        $this->publishes([
            __DIR__ . '/../resources/assets/images' => public_path('vendor/titan-financial-engine/images'),
        ], 'extension');
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];

        // Company-user commercial workspace.
        $router->group([
            'middleware' => ['web','auth'],
            'prefix' => 'dashboard/titan-financial-engine',
            'as' => 'dashboard.titan-financial-engine.',
        ], function (Router $router): void {
            $router->get('/', [QuoteBuilderController::class, 'index'])->name('workspace');
            $router->get('/overview', [FinancialEngineController::class, 'index'])->name('overview');
            $router->get('/assistants/{engine}', [FinancialEngineController::class, 'assistant'])->name('assistants.show');
            $router->post('/assistants/{engine}', [FinancialEngineController::class, 'assistantCalculate'])->name('assistants.calculate');
            $router->get('/quotes', [QuoteBuilderController::class, 'index'])->name('quotes.index');
            $router->get('/quotes/create', [QuoteBuilderController::class, 'create'])->name('quotes.create');
            $router->post('/quotes/simulate', [QuoteBuilderController::class, 'simulate'])->name('quotes.simulate');
            $router->get('/catalog/price-books/{priceBook}', [QuoteBuilderController::class, 'priceBookCatalog'])->name('catalog.price-book');
            $router->get('/catalog/rate-cards/{rateCard}', [QuoteBuilderController::class, 'rateCardCatalog'])->name('catalog.rate-card');
            $router->post('/quotes', [QuoteBuilderController::class, 'store'])->name('quotes.store');
            $router->get('/quotes/{quote}', [QuoteBuilderController::class, 'show'])->name('quotes.show');
            $router->get('/quotes/{quote}/integrations', [QuoteBuilderController::class, 'integrations'])->name('quotes.integrations');
            $router->post('/quotes/{quote}/select', [QuoteBuilderController::class, 'select'])->name('quotes.select');
            $router->post('/calculate', [FinancialEngineController::class, 'calculate'])->name('calculate');
            $router->get('/price-books', [PriceBookController::class, 'index'])->name('price-books.index');
            $router->post('/price-books', [PriceBookController::class, 'store'])->name('price-books.store');
            $router->delete('/price-books/{priceBook}', [PriceBookController::class, 'destroy'])->name('price-books.destroy');
            $router->post('/price-book-items', [PriceBookController::class, 'storeItem'])->name('price-books.items.store');
            $router->delete('/price-book-items/{item}', [PriceBookController::class, 'destroyItem'])->name('price-books.items.destroy');

            $router->get('/rate-cards', [RateCardController::class, 'index'])->name('rate-cards.index');
            $router->post('/rate-cards', [RateCardController::class, 'store'])->name('rate-cards.store');
            $router->delete('/rate-cards/{rateCard}', [RateCardController::class, 'destroy'])->name('rate-cards.destroy');
            $router->post('/rate-card-items', [RateCardController::class, 'storeItem'])->name('rate-cards.items.store');
            $router->delete('/rate-card-items/{item}', [RateCardController::class, 'destroyItem'])->name('rate-cards.items.destroy');

            $router->get('/margin-policies', [MarginPolicyController::class, 'index'])->name('margin-policies.index');
            $router->post('/margin-policies', [MarginPolicyController::class, 'store'])->name('margin-policies.store');
            $router->delete('/margin-policies/{policy}', [MarginPolicyController::class, 'destroy'])->name('margin-policies.destroy');

            $router->get('/settings', [FinancialSettingsController::class, 'company'])->name('settings.index');
            $router->patch('/settings', [FinancialSettingsController::class, 'updateCompany'])->name('settings.update');
        });

        // Super-admin/configuration workspace.
        $router->group([
            'middleware' => ['web','auth','admin'],
            'prefix' => 'dashboard/admin/titan-financial-engine',
            'as' => 'dashboard.admin.titan-financial-engine.',
        ], function (Router $router): void {
            $router->get('/', [FinancialEngineController::class, 'index'])->name('index');
            $router->get('/assistants/{engine}', [FinancialEngineController::class, 'assistant'])->name('assistants.show');
            $router->post('/assistants/{engine}', [FinancialEngineController::class, 'assistantCalculate'])->name('assistants.calculate');
            $router->get('/engines', [FinancialEngineController::class, 'engines'])->name('engines');
            $router->post('/calculate', [FinancialEngineController::class, 'calculate'])->name('calculate');

            $router->get('/price-books', [PriceBookController::class, 'index'])->name('price-books.index');
            $router->post('/price-books', [PriceBookController::class, 'store'])->name('price-books.store');
            $router->delete('/price-books/{priceBook}', [PriceBookController::class, 'destroy'])->name('price-books.destroy');
            $router->post('/price-book-items', [PriceBookController::class, 'storeItem'])->name('price-books.items.store');
            $router->delete('/price-book-items/{item}', [PriceBookController::class, 'destroyItem'])->name('price-books.items.destroy');

            $router->get('/rate-cards', [RateCardController::class, 'index'])->name('rate-cards.index');
            $router->post('/rate-cards', [RateCardController::class, 'store'])->name('rate-cards.store');
            $router->delete('/rate-cards/{rateCard}', [RateCardController::class, 'destroy'])->name('rate-cards.destroy');
            $router->post('/rate-card-items', [RateCardController::class, 'storeItem'])->name('rate-cards.items.store');
            $router->delete('/rate-card-items/{item}', [RateCardController::class, 'destroyItem'])->name('rate-cards.items.destroy');

            $router->get('/margin-policies', [MarginPolicyController::class, 'index'])->name('margin-policies.index');
            $router->post('/margin-policies', [MarginPolicyController::class, 'store'])->name('margin-policies.store');
            $router->delete('/margin-policies/{policy}', [MarginPolicyController::class, 'destroy'])->name('margin-policies.destroy');

            $router->post('/quotes/{quote}/approve', [QuoteBuilderController::class, 'approve'])->name('quotes.approve');

            $router->get('/settings', [FinancialSettingsController::class, 'platform'])->name('settings.index');
            $router->patch('/settings', [FinancialSettingsController::class, 'updatePlatform'])->name('settings.update');

            $router->group(['prefix' => 'promotions', 'as' => 'promotions.'], function (Router $router): void {
                $router->get('/', [DiscountManagerController::class, 'index'])->name('index');
                $router->get('/discount/{discount?}', [DiscountManagerController::class, 'discount'])->name('discount');
                $router->get('/banner/{discount?}', [DiscountManagerController::class, 'banner'])->name('banner');
                $router->group(['middleware' => ['is_not_demo']], function (Router $router): void {
                    $router->put('/discount-save/{discount?}', [DiscountManagerController::class, 'saveDiscount'])->name('discount-save');
                    $router->post('/banner-save/{banner?}', [DiscountManagerController::class, 'saveBanner'])->name('banner-save');
                    $router->post('/discount-duplicate', [DiscountManagerController::class, 'discountDuplicate'])->name('discount-duplicate');
                    $router->delete('/discount-delete', [DiscountManagerController::class, 'discountDelete'])->name('discount-delete');
                });
            });
        });
    }

    private function bridgeToHostCalculatingService(): void
    {
        $hostServiceClass = 'App\\Domains\\WorkCore\\Calculating\\Services\\CalculatingEngineService';
        if (!class_exists($hostServiceClass)) {
            return;
        }

        $this->app->afterResolving($hostServiceClass, function ($hostService): void {
            if (!method_exists($hostService, 'registerEngine')) {
                return;
            }
            foreach (EngineCatalog::classes() as $engineClass) {
                $engine = new $engineClass();
                try {
                    $hostService->registerEngine($engine->key(), $engineClass);
                } catch (Throwable) {
                    // Host bridge is optional. The extension's own registry remains authoritative.
                }
            }
        });
    }

    public static function uninstall(): void
    {
        MenuDatabaseSynchronizer::remove();
    }

    public function registerKey(): string
    {
        return 'titan-financial-engine';
    }
}
