<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Support;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Validation\ValidationException;

final class CompanyContextResolver
{
    public static function resolve(?Authenticatable $user, ?int $requestedCompanyId): int
    {
        $userCompanyId = null;
        if ($user && method_exists($user, 'getAttribute')) {
            $candidate = $user->getAttribute('company_id');
            if (is_numeric($candidate) && (int) $candidate > 0) {
                $userCompanyId = (int) $candidate;
            }
        }

        if ($userCompanyId !== null) {
            if ($requestedCompanyId !== null && $requestedCompanyId !== $userCompanyId) {
                throw ValidationException::withMessages(['company_id' => 'The requested company does not match the authenticated company boundary.']);
            }
            return $userCompanyId;
        }

        $isAdmin = $user && method_exists($user, 'isAdmin') && $user->isAdmin();
        if ($isAdmin && $requestedCompanyId !== null && $requestedCompanyId > 0) {
            return $requestedCompanyId;
        }

        throw ValidationException::withMessages(['company_id' => 'A valid company_id is required for financial calculations.']);
    }
}
