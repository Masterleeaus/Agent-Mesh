<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Commercial\Services;

final class QuoteIntegrationPayloadBuilder
{
    /**
     * Build stable host-neutral hand-off payloads for Titan Jobs, Titan Gear and Titan Pay.
     * The extension does not assume those modules' database schemas.
     */
    public function build(array $quote, array $selectedOption, array $lines): array
    {
        $reservations = [];
        foreach ($lines as $line) {
            if (($line['source_type'] ?? null) !== 'titan_gear' || empty($line['source_id'])) {
                continue;
            }
            $reservations[] = [
                'item_id' => (string)$line['source_id'],
                'description' => (string)($line['description'] ?? ''),
                'quantity' => (string)($line['quantity'] ?? '0'),
                'unit' => (string)($line['unit'] ?? 'each'),
                'relationship' => 'quote_material_requirement',
            ];
        }

        $reference = (string)($quote['quote_number'] ?? ('QUOTE-'.$quote['id']));
        $currency = strtoupper((string)($quote['currency'] ?? 'AUD'));

        return [
            'schema' => 'titan-financial-handoff-v1',
            'jobs' => [
                'company_id' => (int)$quote['company_id'],
                'quote_id' => (int)$quote['id'],
                'quote_number' => $reference,
                'customer_id' => isset($quote['customer_id']) ? (int)$quote['customer_id'] : null,
                'job_id' => isset($quote['job_id']) ? (int)$quote['job_id'] : null,
                'status' => (string)($quote['status'] ?? 'draft'),
                'selected_option_key' => (string)($selectedOption['option_key'] ?? $selectedOption['key'] ?? ''),
                'quoted_total' => (string)($selectedOption['total'] ?? '0.00'),
                'gross_margin_percent' => (string)($selectedOption['gross_margin_percent'] ?? '0.0000'),
                'currency' => $currency,
            ],
            'gear' => [
                'company_id' => (int)$quote['company_id'],
                'quote_id' => (int)$quote['id'],
                'reference' => $reference,
                'reservations' => $reservations,
            ],
            'pay' => [
                'company_id' => (int)$quote['company_id'],
                'quote_id' => (int)$quote['id'],
                'customer_id' => isset($quote['customer_id']) ? (int)$quote['customer_id'] : null,
                'reference' => $reference,
                'currency' => $currency,
                'amount' => (string)($selectedOption['total'] ?? '0.00'),
                'subtotal' => (string)($selectedOption['subtotal'] ?? '0.00'),
                'tax_amount' => (string)($selectedOption['tax_amount'] ?? '0.00'),
                'payment_state' => (($quote['status'] ?? null) === 'approved') ? 'ready_to_create' : 'not_ready',
            ],
        ];
    }
}
