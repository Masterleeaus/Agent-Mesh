<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Navigation;

use Illuminate\Contracts\Container\Container;
use ReflectionMethod;
use Throwable;

/**
 * Adapts Titan/Blueprint navigation registries without coupling the extension
 * to one host build. Navigation is intentionally fail-open: a registry API
 * mismatch must never prevent the financial engine from booting.
 */
final class HostNavigationRegistrar
{
    public static function register(Container $app): void
    {
        self::registerUser($app);
        self::registerAdmin($app);
    }

    private static function registerUser(Container $app): void
    {
        $class = 'App\\Support\\Extensions\\MenuContributionRegistry';
        if (!class_exists($class)) {
            return;
        }

        try {
            $registry = $app->make($class);
            self::invoke($registry, null, 'titan-financial-engine', FinancialNavigation::user());
        } catch (Throwable) {
            // Optional navigation bridge only.
        }
    }

    private static function registerAdmin(Container $app): void
    {
        $class = 'App\\Support\\Extensions\\ContributionRegistry';
        if (!class_exists($class)) {
            return;
        }

        try {
            $registry = $app->make($class);
            self::invoke($registry, 'navigation.admin', 'titan-financial-engine', FinancialNavigation::admin());
        } catch (Throwable) {
            // Optional navigation bridge only.
        }
    }

    /** @param array<int,array<string,mixed>> $definitions */
    private static function invoke(object $registry, ?string $channel, string $owner, array $definitions): bool
    {
        foreach (['register', 'contribute', 'add'] as $method) {
            if (!method_exists($registry, $method)) {
                continue;
            }

            try {
                $reflection = new ReflectionMethod($registry, $method);
                $parameters = $reflection->getParameters();
                $count = count($parameters);

                if ($count === 1) {
                    $registry->{$method}($definitions);
                    return true;
                }

                if ($count === 2) {
                    $first = strtolower($parameters[0]->getName());
                    if (str_contains($first, 'channel') || str_contains($first, 'type')) {
                        $registry->{$method}($channel ?? 'navigation.user', $definitions);
                    } else {
                        $registry->{$method}($owner, $definitions);
                    }
                    return true;
                }

                if ($count >= 3) {
                    $first = strtolower($parameters[0]->getName());
                    if (str_contains($first, 'channel') || str_contains($first, 'type')) {
                        $registry->{$method}($channel ?? 'navigation.user', $owner, $definitions);
                    } else {
                        $registry->{$method}($owner, $channel ?? 'navigation.user', $definitions);
                    }
                    return true;
                }
            } catch (Throwable) {
                continue;
            }
        }

        return false;
    }
}
