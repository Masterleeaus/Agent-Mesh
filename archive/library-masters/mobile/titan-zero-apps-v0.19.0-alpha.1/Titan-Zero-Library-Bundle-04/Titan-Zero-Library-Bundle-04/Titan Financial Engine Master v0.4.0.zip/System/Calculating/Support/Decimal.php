<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Calculating\Support;

use InvalidArgumentException;
use RuntimeException;

final class Decimal
{
    public const SCALE = 1_000_000;
    private const SCALE_DIGITS = 6;

    private function __construct(private readonly int $raw) {}

    public static function zero(): self
    {
        return new self(0);
    }

    public static function from(self|int|string $value): self
    {
        if ($value instanceof self) {
            return $value;
        }
        if (is_int($value)) {
            return new self($value * self::SCALE);
        }

        $value = trim($value);
        if ($value === '') {
            return self::zero();
        }
        if (!preg_match('/^([+-]?)(\d+)(?:\.(\d+))?$/', $value, $matches)) {
            throw new InvalidArgumentException("Invalid decimal value: {$value}");
        }

        $sign = ($matches[1] ?? '') === '-' ? -1 : 1;
        $whole = (int) $matches[2];
        $fraction = $matches[3] ?? '';
        $fraction = substr(str_pad($fraction, self::SCALE_DIGITS + 1, '0'), 0, self::SCALE_DIGITS + 1);
        $main = (int) substr($fraction, 0, self::SCALE_DIGITS);
        $roundDigit = (int) substr($fraction, self::SCALE_DIGITS, 1);
        if ($roundDigit >= 5) {
            $main++;
            if ($main >= self::SCALE) {
                $whole++;
                $main = 0;
            }
        }

        return new self($sign * (($whole * self::SCALE) + $main));
    }

    public static function fromRaw(int $raw): self
    {
        return new self($raw);
    }

    public function raw(): int
    {
        return $this->raw;
    }

    public function add(self|int|string $other): self
    {
        return new self($this->raw + self::from($other)->raw);
    }

    public function sub(self|int|string $other): self
    {
        return new self($this->raw - self::from($other)->raw);
    }

    public function mul(self|int|string $other): self
    {
        $b = self::from($other)->raw;
        if ($this->raw === 0 || $b === 0) {
            return self::zero();
        }

        $sign = (($this->raw < 0) xor ($b < 0)) ? -1 : 1;
        $a = abs($this->raw);
        $b = abs($b);
        $whole = intdiv($a, self::SCALE);
        $remainder = $a % self::SCALE;
        $raw = ($whole * $b) + self::roundDivPositive($remainder * $b, self::SCALE);

        return new self($sign * $raw);
    }

    public function div(self|int|string $other): self
    {
        $b = self::from($other)->raw;
        if ($b === 0) {
            throw new RuntimeException('Division by zero');
        }
        if ($this->raw === 0) {
            return self::zero();
        }

        $sign = (($this->raw < 0) xor ($b < 0)) ? -1 : 1;
        $a = abs($this->raw);
        $b = abs($b);
        $whole = intdiv($a, $b);
        $remainder = $a % $b;
        $raw = ($whole * self::SCALE) + self::roundDivPositive($remainder * self::SCALE, $b);

        return new self($sign * $raw);
    }

    public function min(self|int|string $other): self
    {
        $other = self::from($other);
        return $this->raw <= $other->raw ? $this : $other;
    }

    public function max(self|int|string $other): self
    {
        $other = self::from($other);
        return $this->raw >= $other->raw ? $this : $other;
    }

    public function abs(): self
    {
        return new self(abs($this->raw));
    }

    public function isZero(): bool
    {
        return $this->raw === 0;
    }

    public function isNegative(): bool
    {
        return $this->raw < 0;
    }

    public function compare(self|int|string $other): int
    {
        return $this->raw <=> self::from($other)->raw;
    }

    public function ceilToInt(): int
    {
        if ($this->raw >= 0) {
            return intdiv($this->raw + self::SCALE - 1, self::SCALE);
        }
        return intdiv($this->raw, self::SCALE);
    }

    public function toString(int $precision = self::SCALE_DIGITS): string
    {
        if ($precision < 0 || $precision > self::SCALE_DIGITS) {
            throw new InvalidArgumentException('Precision must be between 0 and 6.');
        }

        $negative = $this->raw < 0;
        $abs = abs($this->raw);
        $factor = 10 ** (self::SCALE_DIGITS - $precision);
        $rounded = self::roundDivPositive($abs, $factor);
        $precisionScale = 10 ** $precision;
        $whole = intdiv($rounded, $precisionScale);
        $fraction = $rounded % $precisionScale;

        if ($precision === 0) {
            return ($negative ? '-' : '') . (string) $whole;
        }

        return ($negative ? '-' : '') . $whole . '.' . str_pad((string) $fraction, $precision, '0', STR_PAD_LEFT);
    }

    public function jsonSerialize(): string
    {
        return $this->toString();
    }

    private static function roundDivPositive(int $numerator, int $denominator): int
    {
        return intdiv($numerator + intdiv($denominator, 2), $denominator);
    }
}
