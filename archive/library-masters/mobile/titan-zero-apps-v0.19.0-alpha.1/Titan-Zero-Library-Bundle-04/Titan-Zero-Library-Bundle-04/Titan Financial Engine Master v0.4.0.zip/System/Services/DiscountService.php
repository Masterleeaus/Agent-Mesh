<?php

declare(strict_types=1);

namespace App\Extensions\TitanFinancialEngine\System\Services;

use App\Extensions\TitanFinancialEngine\System\Enums\UserTypeEnum;
use App\Extensions\TitanFinancialEngine\System\Models\ConditionalDiscount;
use App\Helpers\Classes\Helper;
use App\Models\Coupon;
use App\Services\Payment\Enums\PaymentGatewayEnum;

final class DiscountService
{
    public static function applyDiscountCoupon(): ?Coupon
    {
        $currentUrl = request()?->url() ?? '';
        $userId = auth()->id();
        $hasActiveSubscription = !is_null(Helper::getCurrentActiveSubscription($userId));
        $gateway = self::gatewayFromUrl($currentUrl);
        $planId = self::planFromUrl($currentUrl);

        $discounts = ConditionalDiscount::query()
            ->where('active', true)
            ->whereNotNull('coupon_id')
            ->orderByDesc('amount')
            ->limit(5000)->get();

        foreach ($discounts as $discount) {
            if (self::validateDiscountConditions($discount, $userId, $planId, $gateway, $hasActiveSubscription)) {
                return $discount->coupon;
            }
        }

        return null;
    }

    public static function checkDiscountConditionsFor(
        ?ConditionalDiscount $discount,
        ?string $planId,
        ?string $gateway,
        ?bool $hasActiveSubscription = null
    ): bool {
        $userId = auth()->id();
        $hasActiveSubscription ??= !is_null(Helper::getCurrentActiveSubscription($userId));

        return self::validateDiscountConditions($discount, $userId, $planId, $gateway, $hasActiveSubscription);
    }

    private static function validateDiscountConditions(
        ?ConditionalDiscount $discount,
        ?int $userId,
        ?string $planId,
        ?string $gateway,
        bool $hasActiveSubscription
    ): bool {
        if (!$discount || !$discount->active || !$discount->coupon) {
            return false;
        }
        if ($discount->hide_discount_for_subscribed_users && $hasActiveSubscription) {
            return false;
        }
        if ($discount->scheduled && (
            !$discount->start_date || !$discount->end_date ||
            now()->isBefore($discount->start_date) || now()->isAfter($discount->end_date)
        )) {
            return false;
        }

        $usageCount = (int) ($discount->coupon->usage_count ?? 0);
        if ($discount->total_usage_limit > 0 && $usageCount >= $discount->total_usage_limit) {
            return false;
        }
        if ($discount->allow_once_per_user && $userId && $discount->coupon->usersUsed()->where('user_id', $userId)->exists()) {
            return false;
        }

        $checks = [];

        $gateways = array_values(array_filter(explode(',', (string) $discount->payment_gateway)));
        if ($gateways !== []) {
            $checks[] = $gateway !== null && in_array($gateway, $gateways, true);
        }

        $plans = array_values(array_filter(explode(',', (string) $discount->pricing_plans)));
        if ($plans !== []) {
            $checks[] = $planId !== null && in_array($planId, $plans, true);
        }

        $userTypes = array_values(array_filter(explode(',', (string) $discount->user_type)));
        if ($userTypes !== []) {
            $user = auth()->user();
            $userMatch = false;
            if (in_array(UserTypeEnum::INACTIVE->value, $userTypes, true) && !$hasActiveSubscription) {
                $userMatch = true;
            }
            if (in_array(UserTypeEnum::NEW->value, $userTypes, true) && $user?->created_at?->gte(now()->subDays(7))) {
                $userMatch = true;
            }
            $checks[] = $userMatch;
        }

        if ($checks === []) {
            return true;
        }

        return ($discount->condition ?? 'and') === 'or'
            ? in_array(true, $checks, true)
            : !in_array(false, $checks, true);
    }

    private static function gatewayFromUrl(string $url): ?string
    {
        foreach (PaymentGatewayEnum::activeGateways() as $gateway) {
            if ($url !== '' && str_contains($url, $gateway)) {
                return $gateway;
            }
        }
        return null;
    }

    private static function planFromUrl(string $url): ?string
    {
        return preg_match('/\/(\d+)\//', $url, $matches) ? $matches[1] : null;
    }
}
