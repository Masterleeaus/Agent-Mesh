<?php

namespace App\Extensions\TitanFinancialEngine\System\Models;

use Illuminate\Database\Eloquent\Model;

class CalculationStep extends Model
{
    protected $table = 'financial_calculation_steps';
    public $timestamps = false;
    protected $fillable = ['run_id','company_id','sequence','engine_key','input_snapshot','output_snapshot','notes','created_at'];
    protected $casts = ['input_snapshot' => 'array','output_snapshot' => 'array','notes' => 'array','created_at' => 'datetime'];
}
