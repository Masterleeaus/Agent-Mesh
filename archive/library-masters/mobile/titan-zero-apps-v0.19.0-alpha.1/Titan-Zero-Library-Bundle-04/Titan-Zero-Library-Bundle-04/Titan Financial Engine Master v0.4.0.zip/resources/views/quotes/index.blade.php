@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Financial Engine · Quotes'))
@section('titlebar_subtitle', __('Create, compare and approve deterministic commercial quotes.'))
@section('titlebar_actions')
<x-button href="{{ route('dashboard.titan-financial-engine.quotes.create') }}" variant="primary"><x-tabler-plus class="size-5" />{{ __('New Quote') }}</x-button>
@endsection
@section('content')
<div class="py-10">
    @include('titan-financial-engine::financial.partials.nav', ['companyId'=>$companyId])
    @if (session('success')) <div class="mb-5 rounded-xl border p-4 text-sm">{{ session('success') }}</div> @endif
    <div class="overflow-x-auto rounded-xl border">
        <table class="w-full text-sm"><thead><tr class="border-b text-left"><th class="p-3">{{ __('Quote') }}</th><th class="p-3">{{ __('Title') }}</th><th class="p-3">{{ __('Customer') }}</th><th class="p-3">{{ __('Status') }}</th><th class="p-3">{{ __('Selected') }}</th><th class="p-3">{{ __('Created') }}</th></tr></thead>
        <tbody>@forelse($quotes as $quote)<tr class="border-b"><td class="p-3"><a class="font-medium underline" href="{{ route('dashboard.titan-financial-engine.quotes.show',['quote'=>$quote->id]) }}">{{ $quote->quote_number }}</a></td><td class="p-3">{{ $quote->title }}</td><td class="p-3">{{ $quote->customer_id ?: '—' }}</td><td class="p-3">{{ str($quote->status)->replace('_',' ')->title() }}</td><td class="p-3">{{ $quote->selected_option_key ? str($quote->selected_option_key)->title() : '—' }}</td><td class="p-3">{{ optional($quote->created_at)->format('Y-m-d H:i') }}</td></tr>@empty<tr><td colspan="6" class="p-8 text-center opacity-60">{{ __('No quotes yet. Build your first Good / Better / Best quote.') }}</td></tr>@endforelse</tbody>
        </table>
    </div>
    <div class="mt-4">{{ $quotes->links() }}</div>
</div>
@endsection
