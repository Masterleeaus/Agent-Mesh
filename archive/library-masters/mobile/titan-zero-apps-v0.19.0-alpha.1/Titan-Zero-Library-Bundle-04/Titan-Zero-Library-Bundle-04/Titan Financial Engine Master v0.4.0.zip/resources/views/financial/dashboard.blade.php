@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Financial Assistants'))
@section('titlebar_subtitle', __('Guided pricing, quoting, costing and financial calculators for everyday business decisions.'))

@section('titlebar_actions')
    @if (request()->routeIs('dashboard.admin.titan-financial-engine.*'))
        <x-button href="{{ route('dashboard.admin.titan-financial-engine.settings.index') }}" variant="ghost">
            <x-tabler-settings class="size-5" />
            {{ __('Settings') }}
        </x-button>
    @else
        <x-button href="{{ route('dashboard.titan-financial-engine.quotes.create') }}" variant="primary">
            <x-tabler-file-plus class="size-5" />
            {{ __('Create Quote') }}
        </x-button>
    @endif
@endsection

@section('content')
    <div class="py-10">
        @include('titan-financial-engine::financial.partials.nav', ['companyId'=>request('company_id')])

        <div class="mb-8 grid gap-4 md:grid-cols-3">
            <div class="rounded-xl border p-5">
                <div class="text-xs font-medium uppercase opacity-60">{{ __('Available Assistants') }}</div>
                <div class="mt-2 text-3xl font-semibold">{{ count($registeredEngines) }}</div>
            </div>
            <div class="rounded-xl border p-5">
                <div class="text-xs font-medium uppercase opacity-60">{{ __('How they work') }}</div>
                <div class="mt-2 text-lg font-semibold">{{ __('Guided + Auditable') }}</div>
            </div>
            <div class="rounded-xl border p-5">
                <div class="text-xs font-medium uppercase opacity-60">{{ __('Business boundary') }}</div>
                <div class="mt-2 text-lg font-semibold">company_id</div>
            </div>
        </div>

        <div class="mb-8 rounded-xl border p-5">
            <h2 class="text-xl font-semibold">{{ __('Choose what you want to work out') }}</h2>
            <p class="mt-1 text-sm opacity-60">{{ __('You do not need to know the engine names. Open an assistant, enter the business numbers you know, and it will guide the calculation.') }}</p>
        </div>

        @php($groupedAssistants = collect($assistantDefinitions)->groupBy(fn ($assistant) => $assistant['category'] ?? __('Other')))
        @foreach ($groupedAssistants as $category => $assistants)
            <section class="mb-10">
                <div class="mb-4 flex items-center justify-between gap-4">
                    <h2 class="text-lg font-semibold">{{ __($category) }}</h2>
                    <span class="text-xs opacity-50">{{ count($assistants) }} {{ __('assistants') }}</span>
                </div>

                <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    @foreach ($assistants as $key => $assistant)
                        @php
                            $isRegistered = in_array($key, $registeredEngines, true);
                            $isEnabled = $isRegistered && (bool) ($platformEngineSettings[$key] ?? true);
                            $isAdminFinancial = request()->routeIs('dashboard.admin.titan-financial-engine.*');
                            $routeName = $isAdminFinancial
                                ? 'dashboard.admin.titan-financial-engine.assistants.show'
                                : 'dashboard.titan-financial-engine.assistants.show';
                            $routeParams = ['engine' => $key];
                            if ($isAdminFinancial && request('company_id')) {
                                $routeParams['company_id'] = request('company_id');
                            }
                        @endphp
                        <a
                            href="{{ $isEnabled ? route($routeName, $routeParams) : '#' }}"
                            class="group block rounded-xl border p-5 transition hover:-translate-y-0.5 hover:shadow-md {{ $isEnabled ? '' : 'pointer-events-none opacity-50' }}"
                            data-icon="{{ $assistant['icon'] }}"
                        >
                            <div class="mb-4 flex items-start justify-between gap-4">
                                <span class="flex size-11 items-center justify-center rounded-xl border text-2xl" aria-hidden="true">{{ $assistant['symbol'] }}</span>
                                @if ($isEnabled)
                                    <span class="rounded-full bg-green-500/10 px-2 py-1 text-xs font-medium text-green-600">{{ __('Ready') }}</span>
                                @elseif ($isRegistered)
                                    <span class="rounded-full bg-amber-500/10 px-2 py-1 text-xs font-medium text-amber-600">{{ __('Disabled') }}</span>
                                @else
                                    <span class="rounded-full bg-red-500/10 px-2 py-1 text-xs font-medium text-red-600">{{ __('Unavailable') }}</span>
                                @endif
                            </div>
                            <h3 class="font-semibold group-hover:underline">{{ __($assistant['name']) }}</h3>
                            <p class="mt-2 min-h-10 text-sm opacity-60">{{ __($assistant['description']) }}</p>
                            <div class="mt-4 flex items-center justify-between gap-2 border-t pt-3">
                                <span class="text-xs opacity-40">{{ $key }}</span>
                                <span class="text-sm font-medium">{{ __('Open assistant') }} →</span>
                            </div>
                        </a>
                    @endforeach
                </div>
            </section>
        @endforeach
    </div>
@endsection
