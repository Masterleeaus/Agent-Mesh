@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Financial Engine · Quote Builder'))
@section('titlebar_subtitle', __('Build line-item cost, simulate Good / Better / Best margins and see approval status before saving.'))
@section('content')
<div class="py-10">
    @include('titan-financial-engine::financial.partials.nav', ['companyId'=>$companyId])
    @if ($errors->any()) <div class="mb-5 rounded-xl border border-red-300 p-4 text-sm text-red-600">{{ $errors->first() }}</div> @endif
    <form id="quote-builder-form" method="POST" action="{{ route('dashboard.titan-financial-engine.quotes.store') }}" data-simulate-url="{{ route('dashboard.titan-financial-engine.quotes.simulate') }}" data-price-book-url="{{ route('dashboard.titan-financial-engine.catalog.price-book', ['priceBook'=>'__ID__']) }}" data-rate-card-url="{{ route('dashboard.titan-financial-engine.catalog.rate-card', ['rateCard'=>'__ID__']) }}" class="space-y-6">
        @csrf
        <input type="hidden" name="company_id" value="{{ $companyId }}">
        <div class="grid gap-4 rounded-xl border p-5 md:grid-cols-2 xl:grid-cols-4">
            <label class="text-sm">{{ __('Quote title') }}<input class="form-control mt-1" name="title" value="{{ old('title') }}" placeholder="{{ __('Hot water unit replacement') }}" required></label>
            <label class="text-sm">{{ __('Customer ID') }}<input class="form-control mt-1" type="number" min="1" name="customer_id" value="{{ old('customer_id') }}"></label>
            <label class="text-sm">{{ __('Job ID') }}<input class="form-control mt-1" type="number" min="1" name="job_id" value="{{ old('job_id') }}"></label>
            <label class="text-sm">{{ __('Currency') }}<input class="form-control mt-1" name="currency" maxlength="3" value="{{ old('currency', $financialSettings['general']['default_currency'] ?? 'AUD') }}" required></label>
            <label class="text-sm">{{ __('Price book') }}<select id="price-book-select" class="form-control mt-1" name="price_book_id"><option value="">{{ __('None') }}</option>@foreach($priceBooks as $book)<option value="{{ $book->id }}">{{ $book->name }}</option>@endforeach</select></label>
            <label class="text-sm">{{ __('Rate card') }}<select id="rate-card-select" class="form-control mt-1" name="rate_card_id"><option value="">{{ __('None') }}</option>@foreach($rateCards as $card)<option value="{{ $card->id }}">{{ $card->name }}</option>@endforeach</select></label>
            <label class="text-sm">{{ __('Margin policy') }}<select class="form-control mt-1" name="margin_policy_id"><option value="">{{ __('Default / first active') }}</option>@foreach($marginPolicies as $policy)<option value="{{ $policy->id }}">{{ $policy->name }}</option>@endforeach</select></label>
            <label class="text-sm">{{ __('Valid until') }}<input class="form-control mt-1" type="date" name="valid_until" value="{{ old('valid_until', now()->addDays((int) ($financialSettings['quotes']['validity_days'] ?? 30))->toDateString()) }}"></label>
        </div>

        <section class="rounded-xl border p-5">
            <div class="mb-3"><h2 class="text-lg font-semibold">{{ __('Catalog picker') }}</h2><p class="text-xs opacity-60">{{ __('Choose a Price Book or Rate Card above; active catalog entries appear here and can be inserted into the quote.') }}</p></div>
            <div id="catalog-results" class="flex flex-wrap gap-2 text-sm opacity-70">{{ __('Select a catalog to load items.') }}</div>
        </section>

        <section class="rounded-xl border p-5">
            <div class="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h2 class="text-lg font-semibold">{{ __('Cost lines') }}</h2><p class="text-xs opacity-60">{{ __('Use source type/id to link a line back to Titan Gear, a job, supplier item or other module record.') }}</p></div><x-button id="add-line" type="button" variant="ghost">{{ __('Add Line') }}</x-button></div>
            <div id="quote-lines" class="space-y-3"></div>
        </section>

        <section class="rounded-xl border p-5">
            <div class="grid gap-4 md:grid-cols-4">
                <label class="text-sm">{{ __('GST / Tax %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="100" name="tax_rate_percent" value="{{ old('tax_rate_percent', $financialSettings['tax']['default_rate_percent'] ?? '10') }}" required></label>
                <label class="text-sm">{{ __('Good margin %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="99.999999" name="good_margin_percent" value="{{ old('good_margin_percent', $financialSettings['quotes']['good_margin_percent'] ?? '25') }}" required></label>
                <label class="text-sm">{{ __('Better margin %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="99.999999" name="better_margin_percent" value="{{ old('better_margin_percent', $financialSettings['quotes']['better_margin_percent'] ?? '35') }}" required></label>
                <label class="text-sm">{{ __('Best margin %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="99.999999" name="best_margin_percent" value="{{ old('best_margin_percent', $financialSettings['quotes']['best_margin_percent'] ?? '45') }}" required></label>
                <label class="text-sm">{{ __('Good discount %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="100" name="good_discount_percent" value="{{ old('good_discount_percent','0') }}"></label>
                <label class="text-sm">{{ __('Better discount %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="100" name="better_discount_percent" value="{{ old('better_discount_percent','0') }}"></label>
                <label class="text-sm">{{ __('Best discount %') }}<input class="form-control mt-1" type="number" step="0.000001" min="0" max="100" name="best_discount_percent" value="{{ old('best_discount_percent','0') }}"></label>
            </div>
        </section>

        <section class="rounded-xl border p-5"><div class="mb-4 flex items-center justify-between"><div><h2 class="text-lg font-semibold">{{ __('Live quote simulator') }}</h2><p class="text-xs opacity-60">{{ __('Recalculates after edits using the same server-side commercial services used when the quote is saved.') }}</p></div><span id="simulation-state" class="text-xs opacity-60">{{ __('Ready') }}</span></div><div id="quote-options" class="grid gap-4 md:grid-cols-3"></div><div id="safe-discount" class="mt-4 text-xs opacity-70"></div></section>

        <label class="block text-sm">{{ __('Notes') }}<textarea class="form-control mt-1" rows="4" name="notes">{{ old('notes') }}</textarea></label>
        <div class="flex justify-end"><x-button type="submit" variant="primary">{{ __('Save Quote') }}</x-button></div>
    </form>
</div>

<script>
(() => {
    const form = document.getElementById('quote-builder-form');
    const lines = document.getElementById('quote-lines');
    const options = document.getElementById('quote-options');
    const state = document.getElementById('simulation-state');
    const safe = document.getElementById('safe-discount');
    let lineIndex = 0, timer = null;
    const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

    function addLine(seed = {}) {
        const i = lineIndex++;
        const row = document.createElement('div');
        row.className = 'grid gap-2 rounded-lg border p-3 md:grid-cols-4 xl:grid-cols-8';
        row.innerHTML = `
            <input class="form-control" name="lines[${i}][description]" placeholder="Description" value="${esc(seed.description || '')}" required>
            <select class="form-control" name="lines[${i}][line_type]"><option value="service">Service</option><option value="labour">Labour</option><option value="material">Material</option><option value="equipment">Equipment</option><option value="travel">Travel</option><option value="subcontractor">Subcontractor</option></select>
            <input class="form-control" type="number" step="0.000001" min="0.000001" name="lines[${i}][quantity]" value="${esc(seed.quantity || '1')}" required>
            <input class="form-control" name="lines[${i}][unit]" value="${esc(seed.unit || 'each')}" placeholder="Unit">
            <input class="form-control" type="number" step="0.000001" min="0" name="lines[${i}][unit_cost]" value="${esc(seed.unit_cost || '0')}" placeholder="Unit cost" required>
            <input class="form-control" name="lines[${i}][source_type]" value="${esc(seed.source_type || '')}" placeholder="Source type">
            <input class="form-control" name="lines[${i}][source_id]" value="${esc(seed.source_id || '')}" placeholder="Source ID">
            <button type="button" class="remove-line rounded-lg border px-3 text-sm">Remove</button>`;
        row.querySelector('.remove-line').addEventListener('click', () => { row.remove(); schedule(); });
        row.querySelectorAll('input,select').forEach(el => el.addEventListener('input', schedule));
        lines.appendChild(row);
    }

    function render(data) {
        options.innerHTML = '';
        for (const option of data.options || []) {
            const card = document.createElement('div');
            const statusClass = option.approval_status === 'blocked' ? 'text-red-600' : option.approval_status === 'approval_required' ? 'text-amber-600' : 'text-green-600';
            card.className = 'rounded-xl border p-5';
            card.innerHTML = `<div class="flex justify-between gap-3"><h3 class="font-semibold">${esc(option.name)}</h3><span class="text-xs ${statusClass}">${esc(option.approval_status.replaceAll('_',' '))}</span></div><div class="mt-3 text-3xl font-semibold">$${esc(option.total)}</div><div class="mt-2 text-sm opacity-70">Subtotal $${esc(option.subtotal)} · Tax $${esc(option.tax_amount)}</div><div class="mt-1 text-sm opacity-70">Gross profit $${esc(option.gross_profit)} · Margin ${esc(option.gross_margin_percent)}%</div>`;
            options.appendChild(card);
        }
        const m = data.maximum_safe_discount || {};
        safe.textContent = `Cost $${data.total_cost} · Maximum safe discount before configured margin floor: $${m.amount || '0.00'} (${m.percent || '0.0000'}%) · Floor price $${m.floor_price || '0.00'}`;
    }

    async function simulate() {
        if (!form.reportValidity()) return;
        state.textContent = 'Calculating…';
        const response = await fetch(form.dataset.simulateUrl, {method:'POST', headers:{'Accept':'application/json'}, body:new FormData(form)});
        const data = await response.json();
        if (!response.ok) { state.textContent = data.message || 'Check quote inputs'; return; }
        render(data); state.textContent = 'Calculated';
    }
    function schedule() { clearTimeout(timer); timer = setTimeout(() => simulate().catch(() => { state.textContent = 'Unable to calculate'; }), 350); }
    async function loadCatalog(kind, id) {
        const target = document.getElementById('catalog-results');
        if (!id) { target.textContent = 'Select a catalog to load items.'; return; }
        target.textContent = 'Loading catalog…';
        const template = kind === 'price_book' ? form.dataset.priceBookUrl : form.dataset.rateCardUrl;
        const response = await fetch(template.replace('__ID__', encodeURIComponent(id)), {headers:{'Accept':'application/json'}});
        const data = await response.json();
        target.innerHTML = '';
        if (!response.ok || !(data.items || []).length) { target.textContent = 'No active catalog items found.'; return; }
        for (const item of data.items) {
            const button = document.createElement('button');
            button.type = 'button'; button.className = 'rounded-lg border px-3 py-2 text-sm';
            button.textContent = `${item.code} · ${item.name}`;
            button.addEventListener('click', () => { addLine(item.quote_line); schedule(); });
            target.appendChild(button);
        }
    }
    document.getElementById('price-book-select').addEventListener('change', e => loadCatalog('price_book', e.target.value).catch(() => {}));
    document.getElementById('rate-card-select').addEventListener('change', e => loadCatalog('rate_card', e.target.value).catch(() => {}));
    document.getElementById('add-line').addEventListener('click', () => { addLine(); schedule(); });
    form.querySelectorAll('input,select').forEach(el => el.addEventListener('input', schedule));
    addLine({description:'Labour',quantity:'1',unit:'hour',unit_cost:'0',source_type:'rate_card'});
    addLine({description:'Materials',quantity:'1',unit:'each',unit_cost:'0',source_type:'titan_gear'});
    schedule();
})();
</script>
@endsection
