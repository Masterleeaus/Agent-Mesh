@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Financial Engine · Settings'))
@section('titlebar_subtitle', __('Super Admin defaults, engine availability, governance and integration controls.'))
@section('content')
<div class="py-10">
    @include('titan-financial-engine::financial.partials.nav', ['companyId'=>null])

    @if (session('success')) <div class="mb-5 rounded-xl border border-green-300 p-4 text-sm text-green-700">{{ session('success') }}</div> @endif
    @if ($errors->any()) <div class="mb-5 rounded-xl border border-red-300 p-4 text-sm text-red-600">{{ $errors->first() }}</div> @endif

    <form method="POST" action="{{ route('dashboard.admin.titan-financial-engine.settings.update') }}" class="space-y-6">
        @csrf
        @method('PATCH')

        <section class="rounded-xl border p-5">
            <h2 class="mb-4 text-lg font-semibold">{{ __('Platform Defaults') }}</h2>
            <div class="grid gap-4 md:grid-cols-4">
                <label class="space-y-1"><span class="text-sm">{{ __('Default currency') }}</span><input class="form-control" maxlength="3" name="general[default_currency]" value="{{ old('general.default_currency', $settings['general']['default_currency']) }}"></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Default tax rate %') }}</span><input class="form-control" type="number" min="0" max="100" step="0.0001" name="general[default_tax_rate_percent]" value="{{ old('general.default_tax_rate_percent', $settings['general']['default_tax_rate_percent']) }}"></label>
                <label class="flex items-center gap-2 pt-7"><input type="hidden" name="general[enabled]" value="0"><input type="checkbox" name="general[enabled]" value="1" @checked(old('general.enabled', $settings['general']['enabled']))><span>{{ __('Engine enabled globally') }}</span></label>
                <label class="flex items-center gap-2 pt-7"><input type="hidden" name="general[allow_company_overrides]" value="0"><input type="checkbox" name="general[allow_company_overrides]" value="1" @checked(old('general.allow_company_overrides', $settings['general']['allow_company_overrides']))><span>{{ __('Allow company overrides') }}</span></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Calculation Engines') }}</h2>
            <p class="mb-4 text-sm opacity-60">{{ __('Enable or disable individual engines at platform level.') }}</p>
            <div class="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                @foreach ($engineDefinitions as $key => $description)
                    <label class="flex items-start gap-3 rounded-lg border p-4">
                        <span><input type="hidden" name="engines[{{ $key }}]" value="0"><input type="checkbox" name="engines[{{ $key }}]" value="1" @checked(old('engines.'.$key, $settings['engines'][$key] ?? true))></span>
                        <span><strong class="block text-sm">{{ str($key)->replace('_',' ')->title() }}</strong><span class="text-xs opacity-60">{{ __($description) }}</span></span>
                    </label>
                @endforeach
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-4 text-lg font-semibold">{{ __('Governance') }}</h2>
            <div class="grid gap-3 md:grid-cols-3">
                @foreach (['persist_calculation_audit'=>'Persist calculation audit trail','require_company_context'=>'Require company context','allow_manual_price_override'=>'Allow manual price override'] as $key=>$label)
                    <label class="flex items-center gap-2 rounded-lg border p-3"><input type="hidden" name="governance[{{ $key }}]" value="0"><input type="checkbox" name="governance[{{ $key }}]" value="1" @checked(old('governance.'.$key, $settings['governance'][$key]))><span>{{ __($label) }}</span></label>
                @endforeach
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-4 text-lg font-semibold">{{ __('Integration Availability') }}</h2>
            <div class="grid gap-3 md:grid-cols-3">
                @foreach (['jobs_enabled'=>'Jobs / WorkCore','titan_gear_enabled'=>'Titan Gear','titan_pay_enabled'=>'Titan Pay'] as $key=>$label)
                    <label class="flex items-center gap-2 rounded-lg border p-3"><input type="hidden" name="integrations[{{ $key }}]" value="0"><input type="checkbox" name="integrations[{{ $key }}]" value="1" @checked(old('integrations.'.$key, $settings['integrations'][$key]))><span>{{ __($label) }}</span></label>
                @endforeach
            </div>
        </section>

        <div class="flex justify-end"><x-button type="submit" variant="primary">{{ __('Save Platform Settings') }}</x-button></div>
    </form>
</div>
@endsection
