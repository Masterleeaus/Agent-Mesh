@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Financial Settings'))
@section('titlebar_subtitle', __('Company defaults for currency, GST/tax, quotes, numbering, approvals and Titan integrations.'))
@section('content')
<div class="py-10">
    @include('titan-financial-engine::financial.partials.nav', ['companyId'=>$companyId])

    @if (session('success'))
        <div class="mb-5 rounded-xl border border-green-300 p-4 text-sm text-green-700">{{ session('success') }}</div>
    @endif
    @if ($errors->any())
        <div class="mb-5 rounded-xl border border-red-300 p-4 text-sm text-red-600">{{ $errors->first() }}</div>
    @endif

    @if (!$allowCompanyOverrides)
        <div class="mb-5 rounded-xl border border-amber-300 p-4 text-sm text-amber-700">{{ __('Company overrides are disabled by the Super Admin. These settings are read-only.') }}</div>
    @endif

    <form method="POST" action="{{ route('dashboard.titan-financial-engine.settings.update') }}" class="space-y-6">
        @csrf
        @method('PATCH')
        <fieldset @disabled(!$allowCompanyOverrides)>
        <input type="hidden" name="company_id" value="{{ $companyId }}">

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('General') }}</h2>
            <p class="mb-4 text-sm opacity-60">{{ __('Core financial-engine defaults for this company.') }}</p>
            <div class="grid gap-4 md:grid-cols-3">
                <label class="space-y-1"><span class="text-sm">{{ __('Default currency') }}</span><input class="form-control" name="general[default_currency]" maxlength="3" value="{{ old('general.default_currency', $settings['general']['default_currency']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Money decimals') }}</span><input class="form-control" type="number" min="0" max="6" name="general[money_decimals]" value="{{ old('general.money_decimals', $settings['general']['money_decimals']) }}" required></label>
                <label class="flex items-center gap-2 pt-7"><input type="hidden" name="general[enabled]" value="0"><input type="checkbox" name="general[enabled]" value="1" @checked(old('general.enabled', $settings['general']['enabled']))><span>{{ __('Financial Engine enabled') }}</span></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Tax & GST') }}</h2>
            <p class="mb-4 text-sm opacity-60">{{ __('Defaults only; line-level and jurisdiction rules can still override these values.') }}</p>
            <div class="grid gap-4 md:grid-cols-3">
                <label class="space-y-1"><span class="text-sm">{{ __('Tax label') }}</span><input class="form-control" name="tax[tax_label]" value="{{ old('tax.tax_label', $settings['tax']['tax_label']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Default tax rate %') }}</span><input class="form-control" type="number" min="0" max="100" step="0.0001" name="tax[default_rate_percent]" value="{{ old('tax.default_rate_percent', $settings['tax']['default_rate_percent']) }}" required></label>
                <label class="flex items-center gap-2 pt-7"><input type="hidden" name="tax[prices_include_tax]" value="0"><input type="checkbox" name="tax[prices_include_tax]" value="1" @checked(old('tax.prices_include_tax', $settings['tax']['prices_include_tax']))><span>{{ __('Prices include tax by default') }}</span></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Quote Defaults') }}</h2>
            <div class="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
                <label class="space-y-1"><span class="text-sm">{{ __('Validity days') }}</span><input class="form-control" type="number" min="1" name="quotes[validity_days]" value="{{ old('quotes.validity_days', $settings['quotes']['validity_days']) }}"></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Good margin %') }}</span><input class="form-control" type="number" min="0" max="99.9999" step="0.0001" name="quotes[good_margin_percent]" value="{{ old('quotes.good_margin_percent', $settings['quotes']['good_margin_percent']) }}"></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Better margin %') }}</span><input class="form-control" type="number" min="0" max="99.9999" step="0.0001" name="quotes[better_margin_percent]" value="{{ old('quotes.better_margin_percent', $settings['quotes']['better_margin_percent']) }}"></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Best margin %') }}</span><input class="form-control" type="number" min="0" max="99.9999" step="0.0001" name="quotes[best_margin_percent]" value="{{ old('quotes.best_margin_percent', $settings['quotes']['best_margin_percent']) }}"></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Deposit %') }}</span><input class="form-control" type="number" min="0" max="100" step="0.0001" name="quotes[default_deposit_percent]" value="{{ old('quotes.default_deposit_percent', $settings['quotes']['default_deposit_percent']) }}"></label>
                <label class="flex items-center gap-2 pt-7"><input type="hidden" name="quotes[require_customer_acceptance]" value="0"><input type="checkbox" name="quotes[require_customer_acceptance]" value="1" @checked(old('quotes.require_customer_acceptance', $settings['quotes']['require_customer_acceptance']))><span>{{ __('Require acceptance') }}</span></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Numbering') }}</h2>
            <div class="grid gap-4 md:grid-cols-3">
                <label class="space-y-1"><span class="text-sm">{{ __('Quote prefix') }}</span><input class="form-control" name="numbering[quote_prefix]" value="{{ old('numbering.quote_prefix', $settings['numbering']['quote_prefix']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Next quote number') }}</span><input class="form-control" type="number" min="1" name="numbering[next_quote_number]" value="{{ old('numbering.next_quote_number', $settings['numbering']['next_quote_number']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Number padding') }}</span><input class="form-control" type="number" min="1" max="12" name="numbering[pad_length]" value="{{ old('numbering.pad_length', $settings['numbering']['pad_length']) }}" required></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Approval Rules') }}</h2>
            <div class="grid gap-4 md:grid-cols-3">
                <label class="space-y-1"><span class="text-sm">{{ __('Approval below margin %') }}</span><input class="form-control" type="number" min="0" max="99.9999" step="0.0001" name="approvals[approval_below_margin_percent]" value="{{ old('approvals.approval_below_margin_percent', $settings['approvals']['approval_below_margin_percent']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Hard block below margin %') }}</span><input class="form-control" type="number" min="0" max="99.9999" step="0.0001" name="approvals[block_below_margin_percent]" value="{{ old('approvals.block_below_margin_percent', $settings['approvals']['block_below_margin_percent']) }}" required></label>
                <label class="space-y-1"><span class="text-sm">{{ __('Max discount without approval %') }}</span><input class="form-control" type="number" min="0" max="100" step="0.0001" name="approvals[maximum_discount_without_approval_percent]" value="{{ old('approvals.maximum_discount_without_approval_percent', $settings['approvals']['maximum_discount_without_approval_percent']) }}" required></label>
            </div>
        </section>

        <section class="rounded-xl border p-5">
            <h2 class="mb-1 text-lg font-semibold">{{ __('Integrations') }}</h2>
            <p class="mb-4 text-sm opacity-60">{{ __('Controls whether Financial Engine emits hand-off data for each Titan domain.') }}</p>
            <div class="grid gap-3 md:grid-cols-3">
                @foreach (['jobs_enabled'=>'Jobs / WorkCore','titan_gear_enabled'=>'Titan Gear','titan_pay_enabled'=>'Titan Pay'] as $key=>$label)
                    <label class="flex items-center gap-2 rounded-lg border p-3"><input type="hidden" name="integrations[{{ $key }}]" value="0"><input type="checkbox" name="integrations[{{ $key }}]" value="1" @checked(old('integrations.'.$key, $settings['integrations'][$key]))><span>{{ __($label) }}</span></label>
                @endforeach
            </div>
        </section>

        <div class="flex justify-end"><x-button type="submit" variant="primary">{{ __('Save Financial Settings') }}</x-button></div>
        </fieldset>
    </form>
</div>
@endsection
