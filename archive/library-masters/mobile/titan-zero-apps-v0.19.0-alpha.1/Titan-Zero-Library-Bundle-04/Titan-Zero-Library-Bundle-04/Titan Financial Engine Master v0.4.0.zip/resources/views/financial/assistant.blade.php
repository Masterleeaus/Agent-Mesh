@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __($assistant['name']))
@section('titlebar_subtitle', __($assistant['description']))

@section('titlebar_actions')
    @php
        $overviewRoute = $isAdminFinancial ? 'dashboard.admin.titan-financial-engine.index' : 'dashboard.titan-financial-engine.overview';
        $overviewParams = $isAdminFinancial && !empty($companyId) ? ['company_id' => $companyId] : [];
    @endphp
    <x-button href="{{ route($overviewRoute, $overviewParams) }}" variant="ghost">
        ← {{ __('All Assistants') }}
    </x-button>
@endsection

@section('content')
    <div class="py-10">
        @include('titan-financial-engine::financial.partials.nav', ['companyId'=>$companyId])

        <div class="mx-auto max-w-6xl">
            <div class="mb-6 flex items-start gap-4 rounded-xl border p-5">
                <div class="flex size-14 shrink-0 items-center justify-center rounded-xl border text-3xl" data-icon="{{ $assistant['icon'] }}">{{ $assistant['symbol'] }}</div>
                <div>
                    <div class="text-xs font-medium uppercase opacity-50">{{ __($assistant['category']) }}</div>
                    <h2 class="mt-1 text-xl font-semibold">{{ __($assistant['name']) }}</h2>
                    <p class="mt-1 text-sm opacity-60">{{ __($assistant['description']) }}</p>
                </div>
            </div>

            @if ($assistantError)
                <div class="mb-6 rounded-xl border border-red-500/30 bg-red-500/5 p-4 text-sm text-red-600">
                    <strong>{{ __('Could not calculate:') }}</strong> {{ $assistantError }}
                </div>
            @endif

            @if ($errors->any())
                <div class="mb-6 rounded-xl border border-red-500/30 bg-red-500/5 p-4 text-sm text-red-600">
                    <strong>{{ __('Please check these fields:') }}</strong>
                    <ul class="mt-2 list-disc ps-5">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="grid gap-6 lg:grid-cols-[1.15fr_.85fr]">
                <div class="rounded-xl border p-5">
                    <div class="mb-5">
                        <h3 class="font-semibold">{{ __('Enter your numbers') }}</h3>
                        <p class="mt-1 text-sm opacity-60">{{ __('Use the values you know. Defaults are only a starting point and can be changed.') }}</p>
                    </div>

                    @php($calculateRoute = $isAdminFinancial ? 'dashboard.admin.titan-financial-engine.assistants.calculate' : 'dashboard.titan-financial-engine.assistants.calculate')
                    <form method="POST" action="{{ route($calculateRoute, ['engine' => $engineKey]) }}" class="space-y-5">
                        @csrf

                        @if ($isAdminFinancial)
                            <div>
                                <label class="mb-1 block text-sm font-medium">{{ __('Company ID') }}</label>
                                <input name="company_id" value="{{ old('company_id', $companyId) }}" inputmode="numeric" required class="w-full rounded-lg border bg-transparent px-3 py-2" placeholder="123">
                                <p class="mt-1 text-xs opacity-50">{{ __('Required for a Super Admin calculation so the correct company settings and audit boundary are used.') }}</p>
                            </div>
                        @else
                            <input type="hidden" name="company_id" value="{{ $companyId }}">
                        @endif

                        <div class="grid gap-4 md:grid-cols-2">
                            @foreach ($assistant['fields'] as $field)
                                @php
                                    $name = $field['name'];
                                    $type = $field['type'];
                                    $value = old('inputs.'.$name, $formValues[$name] ?? $field['default'] ?? '');
                                @endphp
                                <div class="{{ $type === 'checkbox' ? 'md:col-span-2' : '' }}">
                                    @if ($type === 'checkbox')
                                        <label class="flex items-center gap-3 rounded-lg border p-3">
                                            <input type="checkbox" name="inputs[{{ $name }}]" value="1" @checked((bool) $value)>
                                            <span>
                                                <span class="block text-sm font-medium">{{ __($field['label']) }}</span>
                                                @if (!empty($field['help']))<span class="text-xs opacity-50">{{ __($field['help']) }}</span>@endif
                                            </span>
                                        </label>
                                    @elseif ($type === 'select')
                                        <label class="mb-1 block text-sm font-medium">{{ __($field['label']) }}</label>
                                        <select name="inputs[{{ $name }}]" class="w-full rounded-lg border bg-transparent px-3 py-2">
                                            @foreach ($field['options'] as $optionValue => $optionLabel)
                                                <option value="{{ $optionValue }}" @selected((string) $value === (string) $optionValue)>{{ __($optionLabel) }}</option>
                                            @endforeach
                                        </select>
                                        @if (!empty($field['help']))<p class="mt-1 text-xs opacity-50">{{ __($field['help']) }}</p>@endif
                                    @else
                                        <label class="mb-1 block text-sm font-medium">{{ __($field['label']) }}</label>
                                        <div class="relative">
                                            @if ($type === 'money')
                                                <span class="pointer-events-none absolute inset-y-0 start-3 flex items-center text-xs opacity-50">{{ $currency ?? 'AUD' }}</span>
                                            @elseif ($type === 'percent')
                                                <span class="pointer-events-none absolute inset-y-0 end-3 flex items-center text-sm opacity-50">%</span>
                                            @endif
                                            <input
                                                name="inputs[{{ $name }}]"
                                                value="{{ $value }}"
                                                @if (in_array($type, ['money','percent','number','integer'], true)) inputmode="decimal" @endif
                                                class="w-full rounded-lg border bg-transparent px-3 py-2 {{ $type === 'money' ? 'ps-14' : '' }} {{ $type === 'percent' ? 'pe-8' : '' }}"
                                            >
                                        </div>
                                        @if (!empty($field['help']))<p class="mt-1 text-xs opacity-50">{{ __($field['help']) }}</p>@endif
                                    @endif
                                </div>
                            @endforeach
                        </div>

                        <div class="flex flex-wrap items-center gap-3 border-t pt-5">
                            <x-button type="submit" variant="primary">
                                <x-tabler-calculator class="size-5" />
                                {{ __('Calculate') }}
                            </x-button>
                            <span class="text-xs opacity-50">{{ __('Calculation uses fixed-point financial arithmetic.') }}</span>
                        </div>
                    </form>
                </div>

                <div class="space-y-6">
                    <div class="rounded-xl border p-5">
                        <h3 class="font-semibold">{{ __('Result') }}</h3>
                        @if (empty($displayResults))
                            <div class="mt-5 rounded-lg border border-dashed p-6 text-center text-sm opacity-50">
                                {{ __('Enter your values and select Calculate. Your result will appear here.') }}
                            </div>
                        @else
                            <div class="mt-4 space-y-3">
                                @foreach ($displayResults as $result)
                                    <div class="flex items-center justify-between gap-4 rounded-lg border p-3">
                                        <span class="text-sm opacity-70">{{ __($result['label']) }}</span>
                                        <span class="text-end font-semibold {{ $result['format'] === 'status' ? 'capitalize' : '' }}">{{ $result['value'] }}</span>
                                    </div>
                                @endforeach
                            </div>
                            @if ($runId)
                                <div class="mt-4 text-xs opacity-40">{{ __('Calculation ID:') }} {{ $runId }}</div>
                            @endif
                        @endif
                    </div>

                    @if (!empty($calculationTrace))
                        <details class="rounded-xl border p-5">
                            <summary class="cursor-pointer font-medium">{{ __('Calculation trace') }}</summary>
                            <p class="mt-2 text-xs opacity-50">{{ __('Shows the exact structured inputs and outputs used by this assistant.') }}</p>
                            <pre class="mt-4 max-h-96 overflow-auto whitespace-pre-wrap rounded-lg border p-3 text-xs">{{ json_encode($calculationTrace, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
                        </details>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
