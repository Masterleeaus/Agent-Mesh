@php($isAdminFinancial = request()->routeIs('dashboard.admin.titan-financial-engine.*'))
<div class="mb-6 flex flex-wrap gap-2 rounded-xl border p-3">
    @if ($isAdminFinancial)
        <x-button href="{{ route('dashboard.admin.titan-financial-engine.index', !empty($companyId) ? ['company_id'=>$companyId] : []) }}" variant="ghost"><x-tabler-apps class="size-4" />{{ __('Assistants') }}</x-button>
        <x-button href="{{ route('dashboard.admin.titan-financial-engine.promotions.index') }}" variant="ghost"><x-tabler-discount-2 class="size-4" />{{ __('Promotions') }}</x-button>
        <x-button href="{{ route('dashboard.admin.titan-financial-engine.settings.index') }}" variant="ghost"><x-tabler-settings class="size-4" />{{ __('Settings') }}</x-button>
        @if (!empty($companyId))
            <x-button href="{{ route('dashboard.admin.titan-financial-engine.price-books.index', ['company_id'=>$companyId]) }}" variant="ghost"><x-tabler-book-2 class="size-4" />{{ __('Price Books') }}</x-button>
            <x-button href="{{ route('dashboard.admin.titan-financial-engine.rate-cards.index', ['company_id'=>$companyId]) }}" variant="ghost"><x-tabler-clock-dollar class="size-4" />{{ __('Rate Cards') }}</x-button>
            <x-button href="{{ route('dashboard.admin.titan-financial-engine.margin-policies.index', ['company_id'=>$companyId]) }}" variant="ghost"><x-tabler-chart-line class="size-4" />{{ __('Margin Policies') }}</x-button>
        @endif
    @else
        <x-button href="{{ route('dashboard.titan-financial-engine.overview') }}" variant="ghost"><x-tabler-apps class="size-4" />{{ __('All Assistants') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.quotes.index') }}" variant="ghost"><x-tabler-file-invoice class="size-4" />{{ __('Quotes') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.quotes.create') }}" variant="ghost"><x-tabler-file-plus class="size-4" />{{ __('Quote Builder') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.price-books.index') }}" variant="ghost"><x-tabler-book-2 class="size-4" />{{ __('Price Books') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.rate-cards.index') }}" variant="ghost"><x-tabler-clock-dollar class="size-4" />{{ __('Rate Cards') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.margin-policies.index') }}" variant="ghost"><x-tabler-chart-line class="size-4" />{{ __('Margin Rules') }}</x-button>
        <x-button href="{{ route('dashboard.titan-financial-engine.settings.index') }}" variant="ghost"><x-tabler-settings class="size-4" />{{ __('Settings') }}</x-button>
    @endif
</div>
