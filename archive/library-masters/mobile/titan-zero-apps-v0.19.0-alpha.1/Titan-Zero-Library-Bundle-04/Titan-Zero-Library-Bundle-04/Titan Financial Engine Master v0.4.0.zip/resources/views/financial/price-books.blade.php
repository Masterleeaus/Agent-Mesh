@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('Titan Financial Engine · Price Books'))
@section('titlebar_subtitle', __('Company-specific service, product and contract pricing with cost, margin and discount controls.'))
@section('content')
@php($financialRouteBase = request()->routeIs('dashboard.admin.titan-financial-engine.*') ? 'dashboard.admin.titan-financial-engine' : 'dashboard.titan-financial-engine')
<div class="py-10">
    @include('titan-financial-engine::financial.partials.nav', ['companyId'=>$companyId])
    @if ($errors->any()) <div class="mb-5 rounded-xl border border-red-300 p-4 text-sm text-red-600">{{ $errors->first() }}</div> @endif

    <div class="mb-8 rounded-xl border p-5">
        <h2 class="mb-4 text-lg font-semibold">{{ __('Create price book') }}</h2>
        <form method="POST" action="{{ route($financialRouteBase . '.price-books.store') }}" class="grid gap-3 md:grid-cols-4">
            @csrf
            <input type="hidden" name="company_id" value="{{ $companyId }}">
            <input class="form-control" name="name" placeholder="{{ __('Residential Standard') }}" required>
            <input class="form-control" name="currency" value="AUD" maxlength="3" required>
            <input class="form-control" type="date" name="effective_from">
            <x-button type="submit" variant="primary">{{ __('Create Price Book') }}</x-button>
        </form>
    </div>

    <div class="space-y-6">
        @forelse ($books as $book)
            <section class="rounded-xl border p-5">
                <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
                    <div><h3 class="text-lg font-semibold">{{ $book->name }}</h3><p class="text-xs opacity-60">{{ $book->currency }} · {{ $book->active ? __('Active') : __('Inactive') }}</p></div>
                    <form method="POST" action="{{ route($financialRouteBase . '.price-books.destroy', ['priceBook'=>$book->id]) }}">@csrf @method('DELETE')<input type="hidden" name="company_id" value="{{ $companyId }}"><x-button type="submit" variant="ghost" onclick="return confirm('{{ __('Delete this price book?') }}')">{{ __('Delete') }}</x-button></form>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm"><thead><tr class="border-b text-left"><th class="p-2">{{ __('Code') }}</th><th class="p-2">{{ __('Item') }}</th><th class="p-2">{{ __('Type') }}</th><th class="p-2">{{ __('Cost') }}</th><th class="p-2">{{ __('Sell') }}</th><th class="p-2">{{ __('Method') }}</th><th class="p-2">{{ __('Margin') }}</th><th></th></tr></thead>
                        <tbody>@foreach (($items[$book->id] ?? collect()) as $item)<tr class="border-b"><td class="p-2">{{ $item->code }}</td><td class="p-2">{{ $item->name }}</td><td class="p-2">{{ $item->item_type }}</td><td class="p-2">{{ number_format((float)$item->cost,2) }}</td><td class="p-2">{{ $item->sell_price !== null ? number_format((float)$item->sell_price,2) : '—' }}</td><td class="p-2">{{ $item->pricing_method }}</td><td class="p-2">{{ $item->target_margin_percent !== null ? number_format((float)$item->target_margin_percent,2).'%' : '—' }}</td><td class="p-2"><form method="POST" action="{{ route($financialRouteBase . '.price-books.items.destroy',['item'=>$item->id]) }}">@csrf @method('DELETE')<input type="hidden" name="company_id" value="{{ $companyId }}"><button class="text-xs text-red-600">{{ __('Remove') }}</button></form></td></tr>@endforeach</tbody>
                    </table>
                </div>
                <form method="POST" action="{{ route($financialRouteBase . '.price-books.items.store') }}" class="mt-5 grid gap-2 md:grid-cols-4 xl:grid-cols-6">
                    @csrf<input type="hidden" name="company_id" value="{{ $companyId }}"><input type="hidden" name="price_book_id" value="{{ $book->id }}">
                    <input class="form-control" name="code" placeholder="CODE" required><input class="form-control" name="name" placeholder="{{ __('Item name') }}" required>
                    <select class="form-control" name="item_type"><option value="service">{{ __('Service') }}</option><option value="product">{{ __('Product') }}</option><option value="labour">{{ __('Labour') }}</option><option value="equipment">{{ __('Equipment') }}</option></select>
                    <input class="form-control" name="unit" value="each" required><input class="form-control" type="number" step="0.000001" min="0" name="cost" placeholder="{{ __('Cost') }}" required>
                    <input class="form-control" type="number" step="0.000001" min="0" name="sell_price" placeholder="{{ __('Fixed sell price') }}">
                    <select class="form-control" name="pricing_method"><option value="fixed">{{ __('Fixed') }}</option><option value="target_margin">{{ __('Target margin') }}</option><option value="markup">{{ __('Markup') }}</option></select>
                    <input class="form-control" type="number" step="0.000001" min="0" max="99.999999" name="target_margin_percent" placeholder="{{ __('Margin %') }}">
                    <input class="form-control" type="number" step="0.000001" min="0" name="markup_percent" placeholder="{{ __('Markup %') }}">
                    <input class="form-control" type="number" step="0.000001" min="0" max="100" name="tax_rate_percent" value="10" required>
                    <input class="form-control" type="number" step="0.000001" min="0" name="minimum_price" placeholder="{{ __('Min price') }}">
                    <input class="form-control" type="number" step="0.000001" min="0" max="100" name="maximum_discount_percent" placeholder="{{ __('Max discount %') }}">
                    <x-button type="submit" variant="primary">{{ __('Add Item') }}</x-button>
                </form>
            </section>
        @empty <div class="rounded-xl border p-8 text-center opacity-60">{{ __('No price books yet.') }}</div> @endforelse
    </div>
</div>
@endsection
