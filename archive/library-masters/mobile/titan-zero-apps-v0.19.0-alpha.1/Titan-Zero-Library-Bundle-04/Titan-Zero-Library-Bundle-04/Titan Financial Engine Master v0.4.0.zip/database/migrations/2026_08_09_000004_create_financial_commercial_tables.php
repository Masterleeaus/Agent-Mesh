<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('financial_price_book_items', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('price_book_id')->index();
            $table->string('code', 100);
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('item_type', 40)->default('service')->index();
            $table->string('unit', 40)->default('each');
            $table->decimal('cost', 20, 6)->default(0);
            $table->decimal('sell_price', 20, 6)->nullable();
            $table->string('pricing_method', 40)->default('fixed');
            $table->decimal('target_margin_percent', 10, 6)->nullable();
            $table->decimal('markup_percent', 10, 6)->nullable();
            $table->decimal('tax_rate_percent', 10, 6)->default(10);
            $table->decimal('minimum_price', 20, 6)->nullable();
            $table->decimal('maximum_discount_percent', 10, 6)->nullable();
            $table->boolean('active')->default(true)->index();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->unique(['price_book_id', 'code']);
            $table->index(['company_id', 'price_book_id', 'active'], 'fin_pb_items_company_book_active');
        });

        Schema::create('financial_rate_card_items', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('rate_card_id')->index();
            $table->string('code', 100);
            $table->string('name');
            $table->string('skill_or_role')->nullable()->index();
            $table->string('unit', 40)->default('hour');
            $table->decimal('cost_rate', 20, 6)->default(0);
            $table->decimal('base_rate', 20, 6)->default(0);
            $table->decimal('overtime_multiplier', 10, 6)->default(1.5);
            $table->decimal('weekend_multiplier', 10, 6)->default(1.5);
            $table->decimal('public_holiday_multiplier', 10, 6)->default(2);
            $table->decimal('after_hours_multiplier', 10, 6)->default(1.75);
            $table->decimal('minimum_units', 12, 6)->default(0);
            $table->decimal('callout_fee', 20, 6)->default(0);
            $table->decimal('travel_rate', 20, 6)->default(0);
            $table->boolean('active')->default(true)->index();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->unique(['rate_card_id', 'code']);
            $table->index(['company_id', 'rate_card_id', 'active'], 'fin_rc_items_company_card_active');
        });

        Schema::create('financial_margin_policies', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name');
            $table->decimal('approval_below_percent', 10, 6)->default(25);
            $table->decimal('block_below_percent', 10, 6)->default(15);
            $table->decimal('maximum_discount_percent', 10, 6)->nullable();
            $table->boolean('active')->default(true)->index();
            $table->json('applies_to')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'active']);
        });

        Schema::create('financial_quotes', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('quote_number', 80)->nullable();
            $table->unsignedBigInteger('customer_id')->nullable()->index();
            $table->unsignedBigInteger('job_id')->nullable()->index();
            $table->unsignedBigInteger('price_book_id')->nullable()->index();
            $table->unsignedBigInteger('rate_card_id')->nullable()->index();
            $table->unsignedBigInteger('margin_policy_id')->nullable()->index();
            $table->string('title');
            $table->string('status', 40)->default('draft')->index();
            $table->char('currency', 3)->default('AUD');
            $table->date('valid_until')->nullable();
            $table->string('selected_option_key', 40)->nullable();
            $table->text('notes')->nullable();
            $table->json('totals')->nullable();
            $table->json('meta')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'quote_number']);
            $table->index(['company_id', 'status', 'created_at'], 'fin_quotes_company_status_created');
        });

        Schema::create('financial_quote_versions', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('quote_id')->index();
            $table->unsignedInteger('version');
            $table->string('status', 40)->default('draft');
            $table->json('input_snapshot');
            $table->json('totals_snapshot');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->unique(['quote_id', 'version']);
            $table->index(['company_id', 'quote_id', 'version'], 'fin_quote_versions_company_quote_version');
        });

        Schema::create('financial_quote_options', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('quote_id')->index();
            $table->unsignedInteger('version');
            $table->string('option_key', 40);
            $table->string('name');
            $table->unsignedInteger('sort_order')->default(0);
            $table->decimal('target_margin_percent', 10, 6);
            $table->decimal('cost', 20, 6);
            $table->decimal('sell_price', 20, 6);
            $table->decimal('discount_percent', 10, 6)->default(0);
            $table->decimal('discount_amount', 20, 6)->default(0);
            $table->decimal('subtotal', 20, 6);
            $table->decimal('tax_rate_percent', 10, 6)->default(10);
            $table->decimal('tax_amount', 20, 6)->default(0);
            $table->decimal('total', 20, 6);
            $table->decimal('gross_profit', 20, 6);
            $table->decimal('gross_margin_percent', 10, 6);
            $table->string('approval_status', 40)->default('approved')->index();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->unique(['quote_id', 'version', 'option_key']);
            $table->index(['company_id', 'quote_id', 'version'], 'fin_quote_options_company_quote_version');
        });

        Schema::create('financial_quote_lines', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('quote_id')->index();
            $table->unsignedInteger('version');
            $table->string('code', 100)->nullable();
            $table->string('description');
            $table->string('line_type', 40)->default('service')->index();
            $table->decimal('quantity', 14, 6)->default(1);
            $table->string('unit', 40)->default('each');
            $table->decimal('unit_cost', 20, 6)->default(0);
            $table->decimal('cost_total', 20, 6)->default(0);
            $table->boolean('taxable')->default(true);
            $table->decimal('tax_rate_percent', 10, 6)->default(10);
            $table->string('source_type', 80)->nullable()->index();
            $table->string('source_id', 120)->nullable()->index();
            $table->json('meta')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'quote_id', 'version'], 'fin_quote_lines_company_quote_version');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_quote_lines');
        Schema::dropIfExists('financial_quote_options');
        Schema::dropIfExists('financial_quote_versions');
        Schema::dropIfExists('financial_quotes');
        Schema::dropIfExists('financial_margin_policies');
        Schema::dropIfExists('financial_rate_card_items');
        Schema::dropIfExists('financial_price_book_items');
    }
};
