<?php

declare(strict_types=1);

use App\Extensions\TitanFinancialEngine\System\Navigation\MenuDatabaseSynchronizer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Re-run the extension-owned upsert so existing v0.3.x menu records get
        // the new Financial Assistants label and icon-rich child definitions.
        MenuDatabaseSynchronizer::sync();
    }

    public function down(): void
    {
        try {
            if (!Schema::hasTable('menus') || !Schema::hasColumn('menus', 'key')) {
                return;
            }

            $updates = [
                'ext_titan_financial' => ['label' => 'Financial', 'icon' => 'tabler-calculator'],
                'titan_financial_overview' => ['label' => 'Overview', 'icon' => null],
                'titan_financial_quotes' => ['label' => 'Quotes', 'icon' => null],
                'titan_financial_quote_builder' => ['label' => 'Create Quote', 'icon' => null],
                'titan_financial_price_books' => ['label' => 'Price Books', 'icon' => null],
                'titan_financial_rate_cards' => ['label' => 'Rate Cards', 'icon' => null],
                'titan_financial_margin_rules' => ['label' => 'Margin Rules', 'icon' => null],
                'titan_financial_settings' => ['label' => 'Settings', 'icon' => null],
                'titan_financial_admin_overview' => ['label' => 'Overview', 'icon' => null],
                'titan_financial_admin_promotions' => ['label' => 'Promotions & Discounts', 'icon' => null],
                'titan_financial_admin_settings' => ['label' => 'Settings', 'icon' => null],
            ];

            foreach ($updates as $key => $values) {
                $row = ['label' => $values['label']];
                if (Schema::hasColumn('menus', 'icon')) {
                    $row['icon'] = $values['icon'];
                }
                if (Schema::hasColumn('menus', 'updated_at')) {
                    $row['updated_at'] = now();
                }
                DB::table('menus')->where('key', $key)->update($row);
            }
        } catch (\Throwable) {
            // Rollback must remain safe on hosts without the optional menu schema.
        }
    }
};
