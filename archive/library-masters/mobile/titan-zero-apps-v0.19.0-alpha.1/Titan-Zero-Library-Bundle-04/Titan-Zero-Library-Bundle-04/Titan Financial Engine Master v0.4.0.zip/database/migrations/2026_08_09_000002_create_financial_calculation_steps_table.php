<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('financial_calculation_steps', function (Blueprint $table): void {
            $table->id();
            $table->uuid('run_id')->index();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedSmallInteger('sequence');
            $table->string('engine_key', 80)->index();
            $table->json('input_snapshot')->nullable();
            $table->json('output_snapshot')->nullable();
            $table->json('notes')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('run_id')->references('id')->on('financial_calculation_runs')->cascadeOnDelete();
            $table->unique(['run_id', 'sequence']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_calculation_steps');
    }
};
