<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('financial_price_books', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name');
            $table->char('currency', 3)->default('AUD');
            $table->boolean('active')->default(true)->index();
            $table->timestamp('effective_from')->nullable();
            $table->timestamp('effective_to')->nullable();
            $table->json('rules')->nullable();
            $table->timestamps();
            $table->index(['company_id','active']);
        });

        Schema::create('financial_rate_cards', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('name');
            $table->char('currency', 3)->default('AUD');
            $table->boolean('active')->default(true)->index();
            $table->json('rates');
            $table->timestamp('effective_from')->nullable();
            $table->timestamp('effective_to')->nullable();
            $table->timestamps();
            $table->index(['company_id','active']);
        });

        Schema::create('financial_formula_rules', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('key', 120);
            $table->string('name');
            $table->unsignedInteger('version')->default(1);
            $table->integer('priority')->default(100);
            $table->boolean('active')->default(true)->index();
            $table->json('definition');
            $table->timestamp('effective_from')->nullable();
            $table->timestamp('effective_to')->nullable();
            $table->timestamps();
            $table->unique(['company_id','key','version']);
            $table->index(['company_id','active','priority']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_formula_rules');
        Schema::dropIfExists('financial_rate_cards');
        Schema::dropIfExists('financial_price_books');
    }
};
