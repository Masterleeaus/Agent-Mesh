<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('financial_settings')) {
            return;
        }

        Schema::create('financial_settings', function (Blueprint $table): void {
            $table->id();
            $table->string('scope_key', 120)->unique();
            $table->string('scope', 20)->index();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->json('settings');
            $table->unsignedBigInteger('updated_by')->nullable()->index();
            $table->timestamps();
            $table->index(['scope','company_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_settings');
    }
};
