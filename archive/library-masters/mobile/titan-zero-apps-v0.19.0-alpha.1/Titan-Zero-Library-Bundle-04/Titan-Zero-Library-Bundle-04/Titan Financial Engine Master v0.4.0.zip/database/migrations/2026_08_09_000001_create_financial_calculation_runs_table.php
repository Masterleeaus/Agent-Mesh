<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('financial_calculation_runs', function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->char('currency', 3)->default('AUD');
            $table->json('engine_keys');
            $table->string('status', 32)->default('completed')->index();
            $table->string('context_type', 80)->nullable()->index();
            $table->string('context_id', 191)->nullable()->index();
            $table->json('input_snapshot');
            $table->json('output_snapshot')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_calculation_runs');
    }
};
