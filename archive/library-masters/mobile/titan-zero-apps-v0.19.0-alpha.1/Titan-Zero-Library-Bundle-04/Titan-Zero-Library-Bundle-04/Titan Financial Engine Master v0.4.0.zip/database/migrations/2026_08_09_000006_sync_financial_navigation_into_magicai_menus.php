<?php

declare(strict_types=1);

use App\Extensions\TitanFinancialEngine\System\Navigation\MenuDatabaseSynchronizer;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    public function up(): void
    {
        MenuDatabaseSynchronizer::sync();
    }

    public function down(): void
    {
        MenuDatabaseSynchronizer::remove();
    }
};
