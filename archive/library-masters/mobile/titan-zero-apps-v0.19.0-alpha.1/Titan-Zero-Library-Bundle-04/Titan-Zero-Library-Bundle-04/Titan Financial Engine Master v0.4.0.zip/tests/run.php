<?php

declare(strict_types=1);

$root = dirname(__DIR__);

spl_autoload_register(function (string $class) use ($root): void {
    $prefix = 'App\\Extensions\\TitanFinancialEngine\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $path = $root . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

use App\Extensions\TitanFinancialEngine\System\Calculating\DTO\CalculationContext;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\BreakEvenScenarioEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\DiscountPromotionEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\MarginProfitabilityEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\PricingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\QuoteEstimateEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\TaxEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\LabourRateEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\JobCostingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\InventoryMaterialsCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\AssetFleetEquipmentCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\RecurringPricingEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\PaymentSettlementCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\CommissionIncentiveEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\FinanceInstalmentEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\ForecastCashFlowEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\ProcurementLandedCostEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Engines\FormulaRulesEngine;
use App\Extensions\TitanFinancialEngine\System\Calculating\Services\CalculatingEngineService;
use App\Extensions\TitanFinancialEngine\System\Calculating\Support\Decimal;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\MarginApprovalService;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteOptionBuilder;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteCostService;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\QuoteIntegrationPayloadBuilder;
use App\Extensions\TitanFinancialEngine\System\Commercial\Services\CatalogLineFactory;
use App\Extensions\TitanFinancialEngine\System\Navigation\FinancialNavigation;
use App\Extensions\TitanFinancialEngine\System\Support\EngineCatalog;
use App\Extensions\TitanFinancialEngine\System\Support\AssistantInputAdapter;
use App\Extensions\TitanFinancialEngine\System\Settings\FinancialSettingsSchema;

$tests = [];
$assertSame = static function ($expected, $actual, string $message = ''): void {
    if ($expected !== $actual) {
        throw new RuntimeException(($message ? $message . ': ' : '') . 'expected ' . var_export($expected, true) . ', got ' . var_export($actual, true));
    }
};

$tests['decimal avoids binary float artifacts'] = static function () use ($assertSame): void {
    $value = Decimal::from('0.10')->add(Decimal::from('0.20'));
    $assertSame('0.300000', $value->toString(6));
};

$tests['pricing engine distinguishes margin from markup'] = static function () use ($assertSame): void {
    $engine = new PricingEngine();
    $context = new CalculationContext(42, 'AUD', ['cost' => '70', 'pricing_method' => 'target_margin', 'target_margin_percent' => '40']);
    $result = $engine->calculate($context, null);
    $assertSame('116.67', $result->money('sell_price'));
};

$tests['discount engine enforces price result'] = static function () use ($assertSame): void {
    $engine = new DiscountPromotionEngine();
    $context = new CalculationContext(42, 'AUD', ['base_price' => '1000', 'discount_type' => 'percent', 'discount_value' => '8.5']);
    $result = $engine->calculate($context, null);
    $assertSame('85.00', $result->money('discount_amount'));
    $assertSame('915.00', $result->money('price_after_discount'));
};

$tests['tax engine calculates australian gst style exclusive tax'] = static function () use ($assertSame): void {
    $engine = new TaxEngine();
    $context = new CalculationContext(42, 'AUD', ['subtotal' => '1000', 'tax_rate_percent' => '10', 'tax_inclusive' => false]);
    $result = $engine->calculate($context, null);
    $assertSame('100.00', $result->money('tax_amount'));
    $assertSame('1100.00', $result->money('total'));
};

$tests['margin engine reports gross margin'] = static function () use ($assertSame): void {
    $engine = new MarginProfitabilityEngine();
    $context = new CalculationContext(42, 'AUD', ['revenue' => '1250', 'cost' => '800']);
    $result = $engine->calculate($context, null);
    $assertSame('450.00', $result->money('gross_profit'));
    $assertSame('36.0000', $result->decimal('gross_margin_percent', 4));
};

$tests['break even engine rounds required units up'] = static function () use ($assertSame): void {
    $engine = new BreakEvenScenarioEngine();
    $context = new CalculationContext(42, 'AUD', ['fixed_costs' => '10000', 'price_per_unit' => '250', 'variable_cost_per_unit' => '100']);
    $result = $engine->calculate($context, null);
    $assertSame(67, $result->value('break_even_units'));
    $assertSame('16750.00', $result->money('break_even_revenue'));
};

$tests['engine service runs quote chain and retains trace'] = static function () use ($assertSame): void {
    $service = new CalculatingEngineService();
    $service->registerEngine(new QuoteEstimateEngine());
    $service->registerEngine(new DiscountPromotionEngine());
    $service->registerEngine(new TaxEngine());

    $context = new CalculationContext(99, 'AUD', [
        'labour_cost' => '500',
        'materials_cost' => '300',
        'equipment_cost' => '100',
        'other_cost' => '100',
        'discount_type' => 'percent',
        'discount_value' => '5',
        'tax_rate_percent' => '10',
        'tax_inclusive' => false,
    ]);

    $result = $service->calculate(['quote_estimate', 'discount_promotion', 'tax'], $context);
    $assertSame('1045.00', $result->money('total'));
    $assertSame(3, count($result->steps()));
};


$tests['labour engine calculates ordinary overtime callout and travel'] = static function () use ($assertSame): void {
    $engine = new LabourRateEngine();
    $context = new CalculationContext(42, 'AUD', [
        'hours' => '8', 'hourly_rate' => '120', 'overtime_hours' => '2',
        'overtime_multiplier' => '1.5', 'callout_fee' => '85', 'travel_cost' => '40'
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('1445.00', $result->money('labour_cost'));
};

$tests['job costing engine reports estimated versus actual variance'] = static function () use ($assertSame): void {
    $engine = new JobCostingEngine();
    $context = new CalculationContext(42, 'AUD', [
        'estimated_cost' => '1000', 'actual_labour_cost' => '500', 'actual_materials_cost' => '450', 'actual_other_cost' => '150'
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('1100.00', $result->money('total_cost'));
    $assertSame('100.00', $result->money('cost_variance'));
};

$tests['inventory engine includes waste and pack rounding'] = static function () use ($assertSame): void {
    $engine = new InventoryMaterialsCostEngine();
    $context = new CalculationContext(42, 'AUD', [
        'materials' => [[
            'quantity' => '34.2', 'unit_cost' => '42.48', 'waste_percent' => '10', 'pack_size' => '1.44'
        ]]
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('38.88', $result->decimal('materials.0.purchase_quantity', 2));
    $assertSame('1651.62', $result->money('materials_cost'));
};

$tests['asset engine derives internal and charge out hourly rates'] = static function () use ($assertSame): void {
    $engine = new AssetFleetEquipmentCostEngine();
    $context = new CalculationContext(42, 'AUD', [
        'hourly_components' => ['28','9','31','14','5','3'], 'target_margin_percent' => '35'
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('90.00', $result->money('asset_internal_hourly_cost'));
    $assertSame('138.46', $result->money('asset_charge_hourly_rate'));
};

$tests['recurring pricing engine totals recurring units and periods'] = static function () use ($assertSame): void {
    $engine = new RecurringPricingEngine();
    $context = new CalculationContext(42, 'AUD', ['unit_price' => '150', 'quantity' => '3', 'periods' => 12]);
    $result = $engine->calculate($context, null);
    $assertSame('5400.00', $result->money('contract_value'));
};

$tests['payment settlement engine calculates percentage and fixed fees'] = static function () use ($assertSame): void {
    $engine = new PaymentSettlementCostEngine();
    $context = new CalculationContext(42, 'AUD', ['payment_amount' => '1000', 'fee_percent' => '1.75', 'fixed_fee' => '0.30']);
    $result = $engine->calculate($context, null);
    $assertSame('17.80', $result->money('payment_fee'));
    $assertSame('982.20', $result->money('net_settlement'));
};

$tests['commission engine can calculate from gross profit'] = static function () use ($assertSame): void {
    $engine = new CommissionIncentiveEngine();
    $context = new CalculationContext(42, 'AUD', ['commission_basis' => 'gross_profit', 'gross_profit' => '450', 'commission_percent' => '10']);
    $result = $engine->calculate($context, null);
    $assertSame('45.00', $result->money('commission_amount'));
};

$tests['finance engine calculates deposit simple interest and equal instalments'] = static function () use ($assertSame): void {
    $engine = new FinanceInstalmentEngine();
    $context = new CalculationContext(42, 'AUD', [
        'principal' => '12000', 'deposit_percent' => '20', 'annual_rate_percent' => '6', 'term_months' => 6
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('2400.00', $result->money('deposit_amount'));
    $assertSame('288.00', $result->money('finance_charge'));
    $assertSame('1648.00', $result->money('instalment_amount'));
};

$tests['cash flow engine rolls period balances forward'] = static function () use ($assertSame): void {
    $engine = new ForecastCashFlowEngine();
    $context = new CalculationContext(42, 'AUD', [
        'opening_balance' => '1000',
        'periods' => [
            ['label' => 'M1', 'inflows' => '5000', 'outflows' => '4000'],
            ['label' => 'M2', 'inflows' => '3000', 'outflows' => '4500'],
        ]
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('500.00', $result->money('ending_balance'));
};

$tests['landed cost engine sums acquisition costs less rebates'] = static function () use ($assertSame): void {
    $engine = new ProcurementLandedCostEngine();
    $context = new CalculationContext(42, 'AUD', [
        'supplier_price' => '1000', 'freight' => '100', 'duties' => '50', 'brokerage' => '20',
        'insurance' => '10', 'handling' => '15', 'storage' => '5', 'rebates' => '50'
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('1150.00', $result->money('landed_cost'));
};

$tests['formula engine executes structured operations without eval'] = static function () use ($assertSame): void {
    $engine = new FormulaRulesEngine();
    $context = new CalculationContext(42, 'AUD', [
        'variables' => ['rooms' => '4', 'room_rate' => '75', 'travel' => '40'],
        'formula' => [
            ['op' => 'multiply', 'left' => 'rooms', 'right' => 'room_rate', 'as' => 'room_cost'],
            ['op' => 'add', 'left' => 'room_cost', 'right' => 'travel', 'as' => 'formula_total'],
        ]
    ]);
    $result = $engine->calculate($context, null);
    $assertSame('340.00', $result->money('formula_total'));
};


$tests['catalog line factory maps price book and rate card items into quote cost lines'] = static function () use ($assertSame): void {
    $factory = new CatalogLineFactory();
    $service = $factory->fromPriceBookItem(['id'=>5,'code'=>'CLEAN-1','name'=>'Standard Clean','item_type'=>'service','unit'=>'job','cost'=>'80.00','sell_price'=>'125.00']);
    $labour = $factory->fromRateCardItem(['id'=>8,'code'=>'TECH','name'=>'Senior Tech','unit'=>'hour','cost_rate'=>'72.50','base_rate'=>'145.00']);
    $assertSame('price_book', $service['source_type']);
    $assertSame('80.00', $service['unit_cost']);
    $assertSame('rate_card', $labour['source_type']);
    $assertSame('72.50', $labour['unit_cost']);
};

$tests['quote integration payload builder creates jobs gear and pay handoffs'] = static function () use ($assertSame): void {
    $builder = new QuoteIntegrationPayloadBuilder();
    $payload = $builder->build(
        ['id'=>7,'quote_number'=>'TZQ-42-000007','company_id'=>42,'customer_id'=>9,'job_id'=>12,'currency'=>'AUD','status'=>'approved'],
        ['option_key'=>'better','subtotal'=>'1000.00','tax_amount'=>'100.00','total'=>'1100.00','gross_margin_percent'=>'35.0000'],
        [
            ['description'=>'Filter','line_type'=>'material','quantity'=>'2','unit'=>'each','source_type'=>'titan_gear','source_id'=>'SKU-77'],
            ['description'=>'Technician','line_type'=>'labour','quantity'=>'2.5','unit'=>'hour','source_type'=>'rate_card','source_id'=>'TECH-SENIOR'],
        ]
    );
    $assertSame(12, $payload['jobs']['job_id']);
    $assertSame('SKU-77', $payload['gear']['reservations'][0]['item_id']);
    $assertSame('1100.00', $payload['pay']['amount']);
    $assertSame('TZQ-42-000007', $payload['pay']['reference']);
};

$tests['quote cost service totals decimal line quantities without float math'] = static function () use ($assertSame): void {
    $service = new QuoteCostService();
    $result = $service->summarize([
        ['description' => 'Labour', 'quantity' => '2.5', 'unit_cost' => '120'],
        ['description' => 'Materials', 'quantity' => '3', 'unit_cost' => '42.48'],
    ]);
    $assertSame('427.44', $result['total_cost']->toString(2));
    $assertSame('300.00', $result['lines'][0]['cost_total']);
    $assertSame('127.44', $result['lines'][1]['cost_total']);
};

$tests['margin approval service approves warns and blocks by policy'] = static function () use ($assertSame): void {
    $service = new MarginApprovalService();
    $assertSame('approved', $service->evaluate('36', ['approval_below_percent' => '30', 'block_below_percent' => '20'])['status']);
    $assertSame('approval_required', $service->evaluate('28', ['approval_below_percent' => '30', 'block_below_percent' => '20'])['status']);
    $assertSame('blocked', $service->evaluate('15', ['approval_below_percent' => '30', 'block_below_percent' => '20'])['status']);
};

$tests['margin approval service calculates maximum safe discount'] = static function () use ($assertSame): void {
    $service = new MarginApprovalService();
    $result = $service->maximumSafeDiscount('1250', '800', '25');
    $assertSame('183.33', $result['amount']->toString(2));
    $assertSame('14.6667', $result['percent']->toString(4));
};

$tests['quote option builder produces ordered good better best totals'] = static function () use ($assertSame): void {
    $builder = new QuoteOptionBuilder();
    $options = $builder->build('800', [
        ['key' => 'good', 'name' => 'Good', 'target_margin_percent' => '25'],
        ['key' => 'better', 'name' => 'Better', 'target_margin_percent' => '35'],
        ['key' => 'best', 'name' => 'Best', 'target_margin_percent' => '45'],
    ], '10');

    $assertSame(3, count($options));
    $assertSame('good', $options[0]['key']);
    $assertSame('1173.34', $options[0]['total']);
    $assertSame('better', $options[1]['key']);
    $assertSame('best', $options[2]['key']);
    if ((float) $options[0]['total'] >= (float) $options[1]['total'] || (float) $options[1]['total'] >= (float) $options[2]['total']) {
        throw new RuntimeException('Expected Good < Better < Best totals.');
    }
};


$tests['financial navigation exposes one user parent with required child links'] = static function () use ($assertSame): void {
    $items = FinancialNavigation::user();
    $parent = array_values(array_filter($items, static fn (array $item): bool => $item['key'] === 'ext_titan_financial'));
    $assertSame(1, count($parent));
    $assertSame('Financial Assistants', $parent[0]['label']);
    $children = array_values(array_filter($items, static fn (array $item): bool => ($item['parent_key'] ?? null) === 'ext_titan_financial'));
    $keys = array_column($children, 'key');
    foreach (['titan_financial_overview','titan_financial_quotes','titan_financial_quote_builder','titan_financial_price_books','titan_financial_rate_cards','titan_financial_margin_rules','titan_financial_settings'] as $key) {
        if (!in_array($key, $keys, true)) {
            throw new RuntimeException("Missing user financial menu child {$key}");
        }
    }
};

$tests['financial navigation exposes super admin parent and settings child'] = static function () use ($assertSame): void {
    $items = FinancialNavigation::admin();
    $parent = array_values(array_filter($items, static fn (array $item): bool => $item['key'] === 'titan_financial_admin'));
    $assertSame(1, count($parent));
    $assertSame(true, $parent[0]['is_admin']);
    $settings = array_values(array_filter($items, static fn (array $item): bool => $item['key'] === 'titan_financial_admin_settings'));
    $assertSame(1, count($settings));
    $assertSame('dashboard.admin.titan-financial-engine.settings.index', $settings[0]['route']);
};

$tests['financial settings schema contains company and platform configuration domains'] = static function () use ($assertSame): void {
    $company = FinancialSettingsSchema::companyDefaults();
    $platform = FinancialSettingsSchema::platformDefaults();
    foreach (['general','tax','quotes','numbering','approvals','integrations'] as $section) {
        if (!array_key_exists($section, $company)) {
            throw new RuntimeException("Missing company settings section {$section}");
        }
    }
    $assertSame('AUD', $company['general']['default_currency']);
    $assertSame('10.0000', $company['tax']['default_rate_percent']);
    $assertSame('TZQ', $company['numbering']['quote_prefix']);
    $assertSame(true, $platform['general']['enabled']);
    $assertSame(17, count($platform['engines']));
};


$tests['financial provider keeps company and platform settings routes in their correct security groups'] = static function (): void {
    $provider = file_get_contents(__DIR__ . '/../System/TitanFinancialEngineServiceProvider.php');
    if ($provider === false) {
        throw new RuntimeException('Unable to read provider source.');
    }
    [$userBlock, $adminBlock] = array_pad(explode('// Super-admin/configuration workspace.', $provider, 2), 2, '');
    if (!str_contains($userBlock, "[FinancialSettingsController::class, 'company']")
        || !str_contains($userBlock, "[FinancialSettingsController::class, 'updateCompany']")) {
        throw new RuntimeException('Company settings routes are not registered in the authenticated user group.');
    }
    if (str_contains($userBlock, "[FinancialSettingsController::class, 'platform']")
        || str_contains($userBlock, "[FinancialSettingsController::class, 'updatePlatform']")) {
        throw new RuntimeException('Platform settings routes leaked into the authenticated company-user group.');
    }
    if (!str_contains($adminBlock, "[FinancialSettingsController::class, 'platform']")
        || !str_contains($adminBlock, "[FinancialSettingsController::class, 'updatePlatform']")) {
        throw new RuntimeException('Platform settings routes are missing from the Super Admin group.');
    }
};

$tests['financial navigation route names are represented by provider route suffixes'] = static function (): void {
    $provider = file_get_contents(__DIR__ . '/../System/TitanFinancialEngineServiceProvider.php');
    if ($provider === false) {
        throw new RuntimeException('Unable to read provider source.');
    }
    foreach (array_merge(FinancialNavigation::user(), FinancialNavigation::admin()) as $item) {
        $route = (string) ($item['route'] ?? '');
        if ($route === 'dashboard.admin.titan-financial-engine.promotions.index') {
            if (!str_contains($provider, "'prefix' => 'promotions'")
                || !str_contains($provider, "'as' => 'promotions.'")) {
                throw new RuntimeException('Promotions menu route group is missing.');
            }
            continue;
        }
        $prefixes = ['dashboard.titan-financial-engine.', 'dashboard.admin.titan-financial-engine.'];
        $suffix = $route;
        foreach ($prefixes as $prefix) {
            if (str_starts_with($suffix, $prefix)) {
                $suffix = substr($suffix, strlen($prefix));
                break;
            }
        }
        if (!str_contains($provider, "->name('{$suffix}')")) {
            throw new RuntimeException("Menu route {$route} is not registered by the provider.");
        }
    }
};

$tests['financial settings validation does not use binary float comparisons'] = static function (): void {
    $controller = file_get_contents(__DIR__ . '/../System/Http/Controllers/FinancialSettingsController.php');
    if ($controller === false) {
        throw new RuntimeException('Unable to read settings controller source.');
    }
    if (str_contains($controller, '(float)')) {
        throw new RuntimeException('Financial settings controller contains binary float comparisons.');
    }
};


$tests['financial menu database synchronizer is host-schema defensive and admin-safe'] = static function (): void {
    $path = __DIR__ . '/../System/Navigation/MenuDatabaseSynchronizer.php';
    if (!is_file($path)) {
        throw new RuntimeException('MenuDatabaseSynchronizer is missing.');
    }
    $source = file_get_contents($path);
    if ($source === false) {
        throw new RuntimeException('Unable to read menu synchronizer source.');
    }
    foreach (["hasTable('menus')", "hasColumn('menus', 'is_admin')", 'updateOrInsert', 'MenuService', 'regenerate'] as $needle) {
        if (!str_contains($source, $needle)) {
            throw new RuntimeException("Menu synchronizer is missing host-safety behavior: {$needle}");
        }
    }
};


$tests['financial settings service reads settings through model casts'] = static function (): void {
    $source = file_get_contents(__DIR__ . '/../System/Settings/FinancialSettingsService.php');
    if ($source === false) {
        throw new RuntimeException('Unable to read financial settings service source.');
    }
    if (str_contains($source, "->value('settings')")) {
        throw new RuntimeException('Settings JSON is read with value(), bypassing reliable model-cast hydration.');
    }
};


$tests['financial uninstall removes only extension-owned menu rows'] = static function (): void {
    $provider = file_get_contents(__DIR__ . '/../System/TitanFinancialEngineServiceProvider.php');
    if ($provider === false || !str_contains($provider, 'MenuDatabaseSynchronizer::remove()')) {
        throw new RuntimeException('Extension uninstall does not clean up its owned menu rows.');
    }
};


$tests['quote builder consumes persisted financial defaults and numbering'] = static function (): void {
    $source = file_get_contents(__DIR__ . '/../System/Http/Controllers/QuoteBuilderController.php');
    if ($source === false) {
        throw new RuntimeException('Unable to read QuoteBuilderController source.');
    }
    foreach (['FinancialSettingsService', 'financialSettings', 'nextQuoteNumber'] as $needle) {
        if (!str_contains($source, $needle)) {
            throw new RuntimeException("Quote Builder is not wired to financial setting: {$needle}");
        }
    }
};

$tests['calculation endpoint enforces platform and company financial settings'] = static function (): void {
    $source = file_get_contents(__DIR__ . '/../System/Http/Controllers/FinancialEngineController.php');
    if ($source === false) {
        throw new RuntimeException('Unable to read FinancialEngineController source.');
    }
    foreach (['FinancialSettingsService', "['engines']", 'persist_calculation_audit', 'default_currency'] as $needle) {
        if (!str_contains($source, $needle)) {
            throw new RuntimeException("Calculation endpoint is not enforcing financial setting: {$needle}");
        }
    }
};


$tests['company financial settings obey platform override governance'] = static function (): void {
    $controller = file_get_contents(__DIR__ . '/../System/Http/Controllers/FinancialSettingsController.php');
    $view = file_get_contents(__DIR__ . '/../resources/views/financial/settings/company.blade.php');
    if ($controller === false || $view === false) {
        throw new RuntimeException('Unable to inspect company settings governance.');
    }
    if (!str_contains($controller, 'allow_company_overrides') || !str_contains($controller, 'allowCompanyOverrides')) {
        throw new RuntimeException('Company settings controller does not enforce platform override governance.');
    }
    if (!str_contains($view, 'allowCompanyOverrides')) {
        throw new RuntimeException('Company settings UI does not expose read-only override state.');
    }
};


$tests['quote governance and integration handoffs consume company settings'] = static function (): void {
    $source = file_get_contents(__DIR__ . '/../System/Http/Controllers/QuoteBuilderController.php');
    if ($source === false) {
        throw new RuntimeException('Unable to inspect quote governance source.');
    }
    foreach (['approval_below_margin_percent', 'block_below_margin_percent', 'maximum_discount_without_approval_percent', 'jobs_enabled', 'titan_gear_enabled', 'titan_pay_enabled'] as $needle) {
        if (!str_contains($source, $needle)) {
            throw new RuntimeException("Quote runtime does not consume company setting: {$needle}");
        }
    }
};


$tests['financial navigation uses financial assistants parent and icons on every visible child'] = static function () use ($assertSame): void {
    $items = FinancialNavigation::user();
    $parent = array_values(array_filter($items, static fn (array $item): bool => $item['key'] === 'ext_titan_financial'));
    $assertSame('Financial Assistants', $parent[0]['label']);
    if (empty($parent[0]['icon'])) {
        throw new RuntimeException('Financial Assistants parent is missing an icon.');
    }
    foreach ($items as $item) {
        if (($item['parent_key'] ?? null) === 'ext_titan_financial' && empty($item['icon'])) {
            throw new RuntimeException("Financial menu child {$item['key']} is missing an icon.");
        }
    }
};

$tests['engine catalog exposes clickable assistant metadata for every registered engine'] = static function () use ($assertSame): void {
    $assistants = EngineCatalog::assistants();
    $assertSame(17, count($assistants));
    foreach (EngineCatalog::definitions() as $key => $description) {
        if (!isset($assistants[$key])) {
            throw new RuntimeException("Missing assistant metadata for {$key}");
        }
        foreach (['name','description','icon','fields','results'] as $required) {
            if (empty($assistants[$key][$required])) {
                throw new RuntimeException("Assistant {$key} is missing {$required}");
            }
        }
    }
};

$tests['provider registers per-engine assistant workspace routes'] = static function (): void {
    $provider = file_get_contents(__DIR__ . '/../System/TitanFinancialEngineServiceProvider.php');
    if ($provider === false) {
        throw new RuntimeException('Unable to read provider source.');
    }
    foreach (["/assistants/{engine}", "name('assistants.show')", "name('assistants.calculate')"] as $needle) {
        if (!str_contains($provider, $needle)) {
            throw new RuntimeException("Missing assistant route contract: {$needle}");
        }
    }
};

$tests['assistant dashboard cards link to assistant workspace and render icons'] = static function (): void {
    $view = file_get_contents(__DIR__ . '/../resources/views/financial/dashboard.blade.php');
    if ($view === false) {
        throw new RuntimeException('Unable to read financial dashboard view.');
    }
    foreach (["assistants.show", "assistant['icon']", "Open assistant"] as $needle) {
        if (!str_contains($view, $needle)) {
            throw new RuntimeException("Dashboard is missing clickable assistant UI: {$needle}");
        }
    }
};


$tests['assistant input adapter converts guided material fields into engine material payload'] = static function () use ($assertSame): void {
    $inputs = AssistantInputAdapter::adapt('inventory_materials_cost', [
        'material_quantity' => '5', 'material_unit_cost' => '12.50', 'material_waste_percent' => '10', 'material_pack_size' => '2'
    ]);
    $assertSame('5', $inputs['materials'][0]['quantity']);
    $assertSame('2', $inputs['materials'][0]['pack_size']);
};

$tests['assistant input adapter builds three cash flow periods'] = static function () use ($assertSame): void {
    $inputs = AssistantInputAdapter::adapt('forecast_cash_flow', [
        'opening_balance'=>'1000', 'period_1_label'=>'Week 1', 'period_1_inflows'=>'500', 'period_1_outflows'=>'300',
        'period_2_label'=>'Week 2', 'period_2_inflows'=>'400', 'period_2_outflows'=>'250',
        'period_3_label'=>'Week 3', 'period_3_inflows'=>'600', 'period_3_outflows'=>'450',
    ]);
    $assertSame(3, count($inputs['periods']));
    $assertSame('Week 2', $inputs['periods'][1]['label']);
};

$tests['assistant input adapter sanitizes formula result name consistently'] = static function () use ($assertSame): void {
    $form = ['formula_value_a'=>'8', 'formula_value_b'=>'2', 'formula_operation'=>'divide', 'formula_output_name'=>'My Result'];
    $inputs = AssistantInputAdapter::adapt('formula_rules', $form);
    $assertSame('My_Result', $inputs['formula'][0]['as']);
    $assertSame('My_Result', AssistantInputAdapter::formulaOutputName($form));
};


$tests['all guided assistant defaults execute through their registered engine'] = static function (): void {
    $service = new CalculatingEngineService();
    foreach (EngineCatalog::classes() as $engineClass) {
        $service->registerEngine(new $engineClass());
    }

    foreach (EngineCatalog::assistants() as $key => $assistant) {
        $form = [];
        foreach ($assistant['fields'] as $field) {
            $form[$field['name']] = $field['type'] === 'checkbox'
                ? (($field['default'] ?? '0') === '1')
                : ($field['default'] ?? '');
        }
        $inputs = AssistantInputAdapter::adapt($key, $form);
        $service->calculate([$key], new CalculationContext(42, 'AUD', $inputs));
    }
};

$failed = 0;
foreach ($tests as $name => $test) {
    try {
        $test();
        echo "PASS: {$name}\n";
    } catch (Throwable $e) {
        $failed++;
        echo "FAIL: {$name}\n  {$e->getMessage()}\n";
    }
}

exit($failed === 0 ? 0 : 1);
