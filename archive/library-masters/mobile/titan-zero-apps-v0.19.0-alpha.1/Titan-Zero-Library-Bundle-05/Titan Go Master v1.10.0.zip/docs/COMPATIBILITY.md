# Compatibility

Legacy surface aliases `field`, `worker`, `titan_go` and `titan-go` resolve to canonical `go`. No Chatbot model is application authority. Titan Field's existing Titan Go offline APIs remain valid provider-side compatibility endpoints while the Go app consumes them through governed provider contracts.
