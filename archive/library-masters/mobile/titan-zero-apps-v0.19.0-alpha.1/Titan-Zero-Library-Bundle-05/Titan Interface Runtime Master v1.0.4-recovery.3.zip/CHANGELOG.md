## 1.0.4-recovery.1 — Full runtime recovery + semantic convergence
- Restored the certified v1.0.3 production runtime graph from its hash-verified 459-file canonical package.
- Preserved historical pass evidence and mature Laravel routes/controllers/views/registries/adapters/verification tooling.
- Added reconstructed semantic Generative-UI public contracts without overwriting the mature contribution-discovery registry.
- Added canonical Zero/Go/Hub surface resolver and onboarding-as-Zero-journey compatibility.
- Reasserted `company_id` as the sole canonical company boundary; legacy tenant fields resolve to the same company context only.
- Added Builder, Interaction Engine and Visual Runtime semantic boundaries and safe generated-interface guards.

## 1.0.3 — Website1408 Host View + Full Menu Hotfix

- Replaced the unsupported `<x-layouts.app>` overview wrapper with the verified Website1408/MagicAI `panel.layout.app` Blade layout.
- Restyled the Interface Runtime overview with host Tabler/Bootstrap cards and direct shortcuts to the runtime capability surfaces.
- Added one Titan Interface Runtime parent plus 17 child menu links: Overview, Explore, Command Surface, Continue, Attention, Approvals, Inbox, Sync, Object Workspaces, Collections, Spatial, Decisions, Governance, Working Sets, Configuration, Experience and Product Surfaces.
- Added host-rendered landing pages for parameterized Object Workspace, Collection, Spatial, Decision, Governance, Working Set and Configuration capabilities without fabricating object/action identifiers.
- Fixed PHP 8.3 legacy menu fallback by using `TitanInterfaceRuntimeMenuContributor::definitions()` instead of statically invoking the non-static `user()` method.
- Added executable legacy `menus` hierarchy verification for parent IDs, route slugs and uninstall cleanup.
- No migrations, business-authority changes or direct mutation paths were added.

## 1.0.2 — Installer 1.7.6 Provider-Boot Binding Hotfix

- Fixed missing `FacetRegistryContract` container registration exposed by live Installer 1.7.6 `app()->register()` provider boot.
- Bound `FacetRegistryContract` to `InMemoryFacetRegistry` with the existing `ObjectRegistryContract` dependency.
- Added a permanent provider-boot registry binding regression covering every registry contract resolved during `boot()`.
- Retains v1.0.1 hidden-file integrity fix; no migrations, business authority, routes or persistence changes.

## 1.0.1 — Installer 1.7.6 Hidden-File Integrity Compatibility Hotfix

- Removed `database/migrations/.gitkeep` and `resources/lang/.gitkeep`; Laravel/Symfony `File::allFiles()` excludes hidden files from the live integrity comparison.
- Regenerated `PACKAGE-FILES.sha256` and `extension.json.integrity.files` from the exact release tree.
- Added a permanent Installer 1.7.6 file-list regression that emulates the live verifier's hidden-file behavior.
- No migrations, business-domain changes, authority changes, or runtime feature changes.

# Changelog

## 1.0.0 — Pass 20: Donor Rationalization, E2E Hardening & Production Release

- Audited exact Menu, Focus Mode, Announcement, Onboarding Pro and Introductions donor ZIPs and recorded immutable SHA-256 evidence in `DONOR-AUDIT.json`.
- Added presentation-only workspace focus that can hide nonessential chrome but never approvals, Sync/conflict status, Attention HUD or the escape control.
- Added Attention HUD projection over source-owned Global Work `attention`, `approvals` and `sync` references.
- Added semantic/plain-text coachmark guidance with bounded target/action references; raw HTML, arbitrary selectors and direct execution are rejected.
- Rationalized donor ownership: Interaction Engine remains wizard/journey authority; Announcement/banner/survey records remain source-owned; Introductions can retire after guidance cutover.
- Added deterministic CRM/Work/Finance/Connect/Maps E2E product-surface matrix coverage.
- Added v1 migration, donor-retirement, E2E and retain-data uninstall runbooks.
- Added final lifecycle verification for disable gating, migration-free upgrade and rollback-safe/uninstall-safe package behavior.
- Promoted cumulative runtime to v1.0.0.

## 0.18.0 — Pass 18: Product Surface Policies

- Added centralized Command / Go / Hub / Onboarding product-surface policy profiles.
- Added deterministic product-surface projections across domains, objects, views, facets and actions.
- Hardened object resolution to enforce object capabilities before any workspace/read projection.
- Unified view surface/Hub-safety/capability checks through `visibleIn(InterfaceContext)`.
- Added Go compact/mobile-first/task-first hints and Onboarding progressive/stepwise disclosure budgets.
- Added hard Hub customer-safety filtering and matrix regressions proving owner/worker/customer isolation.
- Added read-only surface-policy endpoint and runtime health/config diagnostics.
- Verified Website1408 Titan Builder owner/field/customer read models remain read-only, explicitly surface-scoped and capability-gated.

## 0.17.0 — Pass 17: Configuration Lifecycle Workspace

- Standardized Draft → Preview → Validate → Publish → History → Rollback presentation over source-owned configuration lifecycles.
- Added metadata-only lifecycle normalization and governed preview/validate/publish/rollback action handoffs.
- Verified current Titan Builder validated preview, versioned publish history, immutable publish snapshots and rollback compatibility.

## 0.15.0 — Pass 15: Trust, Governance, Receipts & Rollback UI

- Added source-authoritative governance provider/gateway contracts and a Trust/Governance workspace.
- Added bounded proposal, risk, assurance, autonomy, approval, execution, receipt, rollback and provenance normalization.
- Added reusable execution-receipt presentation with correlation/causation ids, change summaries and reversibility metadata.
- Added tenant/user revalidation and degraded isolation for invalid governance providers.
- Added soft current-host TitanAI ApprovalQueue adapter without direct TitanAI SQL.
- Added protected TitanAI approval/reject and receipt-rollback POST handoffs.
- All governance actions remain `executable=false`; Interface Runtime never calculates governance or performs the authoritative mutation.
- Added read-only governance workspace endpoint, health diagnostics and Pass 15 regression/snapshot coverage.

## 0.14.0 — Pass 14: Decide & Scenario Workspace

- Added contributor-scoped Decision Provider Registry over Blueprint `providers.decisions`.
- Added manifest-declared `scenario` view composition using the existing governed Read Authority layer.
- Added bounded observation, recommendation, assumption, scenario outcome and consequence normalization.
- Added source/provenance display for scenario views and decision providers.
- Added explicit observation → recommendation → scenario → choice presentation layers.
- Added product-surface, permission and Hub `customer_safe` action filtering.
- All scenario choices remain non-executable intents and preserve capability/Interaction Engine execution authority.
- Added hard `recommendation_is_not_execution` / `auto_execute=false` presentation policy.
- Cross-tenant or unavailable decision providers degrade independently and cannot contaminate healthy source data.
- Added read-only Decide endpoint.
- Removed duplicate service-provider route registration uncovered during Pass 14 binding work.

## 0.13.0 — Pass 13: Spatial Workspace

- Added manifest-declared `map` spatial workspaces for any registered object.
- Titan Maps Intelligence remains the required spatial authority; Interface Runtime only normalizes and composes bounded presentation state.
- Added layers, tenant-safe object pins, discovery candidates, route paths, territory polygons and traffic summaries.
- Added WGS84 coordinate validation, geometry/item limits and omit-not-recalculate handling for invalid spatial records.
- Added map-specific governed action intents filtered by product surface, permissions and Hub `customer_safe`.
- Added read-only spatial endpoint and Titan Builder map-container adaptation with safe fallback.
- Fixed latent `ObjectRegistryContract::find()` calls to the actual `get()` contract in view/legacy-data/Data-mode paths.
- Verified Website1408 Maps `2.0.0-alpha.6.3` spatial primitives; Maps has not yet declared Interface Contribution v1.1 and is intentionally not modified here.


## 0.8.0 — Pass 8: Read Authority & Legacy Data Adapter

- Added deterministic global View Registry over declared interface views.
- Added bounded `ReadQuery` filters, sorting, pagination, cursor and search contracts.
- Added `ReadAuthorityRouter` with `read-model`, governed `capability`, and `legacy-route` modes.
- Added mandatory tenant/user/surface/domain/trace/correlation/query provenance.
- Added request-local security-context-scoped read memoization; cross-tenant shared caching remains disabled.
- Added container read-model provider and governed capability gateway contracts with fail-closed defaults.
- Added `AuthorizedViewReader` product-surface, permission and Hub-safety enforcement.
- Added Legacy Data surface registry/projector preserving existing Laravel/MagicAI routes as deep links only.
- Legacy Data mode is disabled on Hub by default and never copies business query/controller authorization logic.
- Added Pass 8 regression, binding, health, cache-isolation and query-budget coverage.

## 0.7.0 — Pass 7: Presentation Model & Titan Builder Adapter

- Added stable Presentation Model v1.0 tree/DTO serialization and SHA-256 fingerprints.
- Added responsive presentation hints and policy enforcement.
- Added optional soft adapter to Titan Builder `ComponentRegistry` without concrete imports.
- Added deterministic container-to-component fallbacks and an internal `safe-container` fallback.
- Rejects non-presentation, inaccessible, or required-nonresponsive Builder components.
- Strips Builder component actions at the adapter boundary so presentation metadata cannot grant mutation authority.
- Verified compatibility against all 125 component definitions in the supplied Website1408 Titan Builder snapshot.
- Added Pass 7 regression, binding, Builder-snapshot and runtime-health coverage.

## 0.6.0 — Pass 6: Facet Registry & Object Workspace

- Added deterministic global facet registry with cross-extension `applies_to` support.
- Added canonical facet-kind ordering for reusable object workspaces.
- Added product-surface, Hub customer-safety and authenticated-capability filtering.
- Added fail-closed facet collisions and unknown object-target handling.
- Added lazy `FacetSlot` and `ObjectWorkspace` models; authoritative business payloads are not loaded by this pass.
- Added object-level workspace permission gating and Laravel runtime bindings.
- Relaxed discovery validation only for syntactically valid cross-extension facet targets; global existence remains enforced after object registration.
- Added Pass 6 regression coverage and runtime health diagnostics.

## 0.5.0 — Pass 5: Object & Relationship Registry

- Added deterministic cross-extension object registry with immutable normalized descriptors.
- Added canonical `tenant_company_id` object-scope enforcement.
- Added directed cross-extension relationship normalization from `relationship_refs`.
- Added fail-closed duplicate-object collisions and unknown relationship handling.
- Added safe tenant-bound/global object-reference parsing and resolution.
- Added product-surface and Hub customer-safety enforcement during object resolution.
- Added object registry health/diagnostic integration and Pass 5 regression coverage.

## 0.4.0 — Pass 4: Domain & Intent Surface Registry

- Added deterministic cross-extension domain registry derived from validated Interface Contribution descriptors.
- Added canonical intent surface catalog: Home, Ask, Work, Do, Decide, Explore, Insights and Data.
- Added product-surface filtering for Command, Go, Hub and Onboarding.
- Added registry-derived navigation projection contract with no dependency on Menu internals.
- Duplicate domain ownership now fails closed and is reported as a registry collision.
- Added contributor rejection for unsupported intent/product surfaces and deterministic priority ordering.
- Added Pass 4 regression verifier and PHPUnit coverage.


## 0.3.0 — Pass 3: Context Spine

- Added fail-closed authenticated tenant/user context resolution.
- Added immutable InterfaceContext v1.0 with branch/workspace/team/device/object/conversation/journey and trace metadata.
- Added request-scoped context store and interface-route binding middleware.
- Prevented child-context changes to tenant, user, roles, capabilities, product surface, trace and correlation identity.
- Added Context Spine regression and isolation tests.

## 0.2.0 — Pass 2 Contribution Discovery & Validation

- Added deterministic discovery of installed Blueprint 2.1 interface contributors.
- Added Interface Contribution v1.0 validation and internal-reference checks.
- Added normalized immutable contribution descriptors with SHA-256 identities.
- Added contributor-level health states (`VALID`, `DEGRADED`, `DISABLED`).
- Invalid, missing, duplicate and path-traversal contributors now fail closed without taking down the runtime.
- Added request/process discovery snapshot caching and registry normalization.
- Added the canonical Interface Contribution v1.0 JSON Schema to runtime resources.

## 0.1.0 — Pass 1 Production Scaffold

- Created Blueprint v4.1 / manifest schema 2.1 `titan-ui` extension package.
- Added registry, context, presentation, read-authority, governed-action and receipt contracts.
- Added immutable context, presentation, authority-result and receipt DTOs.
- Added an in-memory metadata-only registry scaffold.
- Added health and authority-boundary diagnostics.
- Removed all business-domain migrations/models and direct persistence paths.
- Added architecture/lifecycle/serialization tests and implementation roadmap.

## 0.19.0 — Pass 19

- Added source-authoritative offline/sync/conflict workspace over the Sync tray.
- Added soft Interaction Engine `SyncEngine::getStatus()` adapter without queue ownership.
- Added bounded optional Global Work metadata for safe sync-state presentation.
- Added WCAG 2.2 AA target auditing, localization/RTL, responsive auditing and p95/payload/node/depth budgets.
- Added tenant/user/surface/domain/workspace/locale-scoped presentation cache.
- Added measured Pass 19 performance and Interaction Engine offline-contract verification.
