<?php

declare(strict_types=1);

return [
    'name' => 'Titan Interface Runtime',
    'description' => 'Universal context-aware presentation and workspace runtime for Titan Zero.',
];
