<?php
declare(strict_types=1);
/**
 * Compatibility config entrypoint retained from reconstructed Interface Runtime packages.
 * Canonical configuration is config/titan-interface-runtime.php.
 */
return require __DIR__.'/titan-interface-runtime.php';
