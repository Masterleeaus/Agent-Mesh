# Capabilities

Pass 1 exposes the runtime identity `interface-runtime` but no executable business capability contract. Future mutating UI actions must resolve to capabilities or Interaction Engine references owned elsewhere.
