# Disaster Recovery

Pass 1 has no durable business state. Recovery consists of reinstalling the package and restoring optional published configuration. Domain data recovery remains the responsibility of each authoritative source extension.
