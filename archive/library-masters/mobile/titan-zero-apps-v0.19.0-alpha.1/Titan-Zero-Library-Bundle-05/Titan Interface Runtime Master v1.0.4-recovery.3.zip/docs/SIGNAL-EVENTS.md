# Signal Events

Pass 1 emits no Signal events. Later observability passes may emit runtime health/composition events without asserting domain truth.
