# Pass 04 Verification

Fresh release gate must prove:

- Pass 1–3 regressions: PASS.
- Pass 4 standalone acceptance groups: PASS.
- Multi-extension domain ordering: PASS.
- Duplicate-domain collision fail-closed behavior: PASS.
- Command/Go/Hub/Onboarding product-surface visibility: PASS.
- Navigation projection is registry-derived and canonical intent order is preserved: PASS.
- Blueprint v4.1 architecture and schema gates: PASS.
- PHP/JSON syntax gates: PASS.
- Titan host installer manifest and all-files integrity semantics: PASS.
- Clean-unzip archive verification: PASS.
