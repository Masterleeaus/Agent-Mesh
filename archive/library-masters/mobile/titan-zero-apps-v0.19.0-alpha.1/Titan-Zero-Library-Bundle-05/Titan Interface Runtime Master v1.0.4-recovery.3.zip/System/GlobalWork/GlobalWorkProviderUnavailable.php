<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\GlobalWork;

final class GlobalWorkProviderUnavailable extends \RuntimeException
{
}
