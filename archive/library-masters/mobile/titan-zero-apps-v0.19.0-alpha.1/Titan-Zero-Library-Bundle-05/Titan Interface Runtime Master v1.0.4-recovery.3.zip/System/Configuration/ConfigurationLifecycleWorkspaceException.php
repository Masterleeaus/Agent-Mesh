<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Configuration;

final class ConfigurationLifecycleWorkspaceException extends \RuntimeException {}
