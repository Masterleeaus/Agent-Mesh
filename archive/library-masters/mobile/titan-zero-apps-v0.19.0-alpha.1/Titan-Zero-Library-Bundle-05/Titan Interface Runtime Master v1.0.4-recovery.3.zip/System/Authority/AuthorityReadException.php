<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Authority;

final class AuthorityReadException extends \RuntimeException
{
}
