<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Objects;

final class ObjectReferenceResolutionException extends \RuntimeException
{
}
