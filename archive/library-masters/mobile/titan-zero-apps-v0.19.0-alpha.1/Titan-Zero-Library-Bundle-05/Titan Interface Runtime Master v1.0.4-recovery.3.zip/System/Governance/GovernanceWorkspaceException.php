<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Governance;

final class GovernanceWorkspaceException extends \RuntimeException {}
