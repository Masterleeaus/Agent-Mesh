<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Interaction;

final class InteractionAdapterException extends \RuntimeException {}
