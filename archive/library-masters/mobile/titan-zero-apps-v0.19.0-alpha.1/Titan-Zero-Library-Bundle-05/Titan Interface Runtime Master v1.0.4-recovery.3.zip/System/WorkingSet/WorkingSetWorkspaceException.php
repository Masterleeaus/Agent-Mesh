<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\WorkingSet;

final class WorkingSetWorkspaceException extends \RuntimeException {}
