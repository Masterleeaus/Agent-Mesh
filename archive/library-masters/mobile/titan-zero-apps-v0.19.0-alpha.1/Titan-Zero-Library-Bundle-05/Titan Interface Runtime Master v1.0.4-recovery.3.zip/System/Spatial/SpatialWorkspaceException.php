<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Spatial;

final class SpatialWorkspaceException extends \RuntimeException
{
}
