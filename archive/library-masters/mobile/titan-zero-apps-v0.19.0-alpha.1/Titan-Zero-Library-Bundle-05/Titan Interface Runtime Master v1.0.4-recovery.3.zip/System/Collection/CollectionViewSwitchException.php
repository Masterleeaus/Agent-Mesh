<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Collection;

final class CollectionViewSwitchException extends \RuntimeException {}
