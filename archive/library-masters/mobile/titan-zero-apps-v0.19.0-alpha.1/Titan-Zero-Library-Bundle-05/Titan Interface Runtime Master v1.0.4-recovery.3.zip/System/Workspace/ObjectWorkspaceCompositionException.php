<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Workspace;

final class ObjectWorkspaceCompositionException extends \RuntimeException
{
}
