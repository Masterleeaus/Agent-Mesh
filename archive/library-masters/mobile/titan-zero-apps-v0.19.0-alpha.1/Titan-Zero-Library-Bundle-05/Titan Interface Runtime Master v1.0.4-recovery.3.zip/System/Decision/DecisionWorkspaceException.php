<?php

declare(strict_types=1);
namespace App\Extensions\TitanInterfaceRuntime\System\Decision;
final class DecisionWorkspaceException extends \RuntimeException {}
