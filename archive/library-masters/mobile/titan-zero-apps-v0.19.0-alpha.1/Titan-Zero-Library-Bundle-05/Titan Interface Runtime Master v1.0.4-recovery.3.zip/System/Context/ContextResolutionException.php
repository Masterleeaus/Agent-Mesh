<?php

declare(strict_types=1);

namespace App\Extensions\TitanInterfaceRuntime\System\Context;

use RuntimeException;

final class ContextResolutionException extends RuntimeException
{
}
