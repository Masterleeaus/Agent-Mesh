# Titan Apps: Interface Runtime

Titan Interface Runtime is Titan Zero's universal semantic presentation and workspace layer.

**Canonical surfaces:** `zero`, `go`, `hub`. Legacy names (`command`, `bos`, `field`, `worker`, `customer`, etc.) are compatibility aliases only; onboarding is a Zero journey.

**Canonical company boundary:** `company_id` is the sole company/tenant isolation boundary. Legacy tenant fields may be accepted only as compatibility inputs and must resolve to the same `company_id`.

This recovery release restores the complete certified v1.0.3 runtime graph (discovery, context, registries, object/facet/action/view workspaces, Builder and Interaction adapters, global work trays, governance/receipts, spatial/decision/configuration workspaces, offline/sync, host routes/views/menu integration and production verification tooling) and layers the newer semantic Generative-UI runtime contracts on top.

Interface Runtime owns presentation/composition semantics, not provider/domain truth, workflow authority, Builder component authoring, or Visual Runtime media/effects execution. The Titan Apps Suite is an implementation/development/release ownership grouping, not an isolation boundary.
