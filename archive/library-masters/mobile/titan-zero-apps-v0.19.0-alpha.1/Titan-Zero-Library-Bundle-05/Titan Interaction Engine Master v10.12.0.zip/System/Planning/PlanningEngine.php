<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Planning;

class PlanningEngine extends \App\Extensions\InteractionEngine\System\Engines\Planning\Implementations\PlanningEngine {}
