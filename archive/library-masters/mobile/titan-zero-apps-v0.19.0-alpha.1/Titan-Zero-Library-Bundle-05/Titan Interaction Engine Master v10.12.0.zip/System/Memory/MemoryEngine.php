<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Memory;

class MemoryEngine extends \App\Extensions\InteractionEngine\System\Engines\Memory\Implementations\MemoryEngine {}
