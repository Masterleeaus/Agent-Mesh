<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Goals;

class GoalEngine extends \App\Extensions\InteractionEngine\System\Engines\Executive\Implementations\GoalEngine {}
