<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Semantic;

class SemanticEngine extends \App\Extensions\InteractionEngine\System\Engines\Cognitive\Implementations\SemanticEngine {}
