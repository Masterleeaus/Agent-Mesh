<?php

declare(strict_types=1);
namespace App\Extensions\InteractionEngine\System\AI\Providers;
final class ProviderKinds{public const DETERMINISTIC='deterministic';public const BROWSER_LLM='browser_llm';public const DEVICE_AI='device_ai';public const BYO_AI='byo_ai';public const CLOUD_AI='cloud_ai';private function __construct(){}}
