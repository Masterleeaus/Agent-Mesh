<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Capabilities\Contracts;

interface ConnectCapabilityGatewayInterface extends ExternalCapabilityGatewayInterface
{
}
