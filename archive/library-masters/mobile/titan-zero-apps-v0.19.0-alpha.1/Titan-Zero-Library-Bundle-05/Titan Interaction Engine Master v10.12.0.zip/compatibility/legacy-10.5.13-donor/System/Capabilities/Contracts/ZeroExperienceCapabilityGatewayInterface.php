<?php

declare(strict_types=1);

namespace App\Extensions\InteractionEngine\System\Capabilities\Contracts;

/** Canonical Titan Apps: Zero experience capability boundary. */
interface ZeroExperienceCapabilityGatewayInterface extends ExternalCapabilityGatewayInterface
{
}
