# Titan Apps: Hub

Canonical customer application surface for Titan Zero.

- Canonical surface: `hub`
- Compatibility alias: `customer -> hub`
- Namespace: `App\Extensions\TitanHub`
- Business authority: external CRM/domain providers
- UI actions: governed intents only
- PWA scope: `/customer/{portal}/`

This release is an evidence-backed reconstruction from surviving Titan platform contracts after the historical Hub source archive was lost.
