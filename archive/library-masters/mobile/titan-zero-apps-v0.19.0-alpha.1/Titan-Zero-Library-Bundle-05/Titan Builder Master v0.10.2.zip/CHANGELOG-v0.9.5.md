# Titan Builder v0.9.5 — Contract drift evidence

- Pins visual metadata contract v1.0 to SHA-256 `3e8078fc6be89e534948a4a17ec49878ec1813e75dfba7f327326a8644abfbe1`.
- Adds standalone drift detection against the actual published schema bytes.
- Preserves declarative-only, non-authoritative visual metadata semantics.
