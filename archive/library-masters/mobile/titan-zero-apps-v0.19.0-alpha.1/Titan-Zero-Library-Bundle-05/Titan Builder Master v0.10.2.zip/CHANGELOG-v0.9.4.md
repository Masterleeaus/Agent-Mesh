# Titan Builder v0.9.4 — Visual Runtime contract hardening

- Publishes explicit declarative visual metadata contract v1.0.
- Declares schema identity `titan://builder/schema/visual-metadata/v1`.
- Requires Visual Runtime major-version compatibility.
- Keeps zero/go/hub as the only canonical surfaces.
- Keeps visual metadata non-authoritative and declarative-only.
