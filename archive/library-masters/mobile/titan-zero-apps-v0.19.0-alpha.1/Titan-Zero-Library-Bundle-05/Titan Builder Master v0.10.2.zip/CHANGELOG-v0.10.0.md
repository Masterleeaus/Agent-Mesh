# Titan Builder v0.10.0 — Upgrade Pass

- Advances declarative visual metadata contract to v1.1.
- Adds governed resource cache policy, visual priority and capability fallback order.
- Adds contract evolution policy with backward compatibility inside major version 1.
- Pins upgraded schema SHA-256 `38f0752dedb7578fde0eda36e7b145879a4fb8a27049664faecdd0b1afa10745`.
- Preserves `company_id` as the sole canonical tenant/company boundary.
