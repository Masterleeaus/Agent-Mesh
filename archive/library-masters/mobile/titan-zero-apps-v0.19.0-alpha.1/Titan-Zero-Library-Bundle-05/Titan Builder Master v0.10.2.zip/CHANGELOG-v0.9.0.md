# Titan Builder v0.9.0

## Premium Management UI

- Added complete company/user Builder management surface under `/titan-builder`.
- Added Super Admin Builder control surface under `/titan-builder/admin` guarded by `builder.admin`.
- Added 19 active Blade views, extension-owned responsive management CSS and vanilla JS.
- Added project/page editor UI with validation, TitanAI proposals, validated preview, draft save, publish and rollback controls.
- Added four-PWA provisioning/configuration UI for Titan Hub, Titan Go, Titan Command and Titan Onboarding.
- Added company asset upload/library, shared brand/theme, integrations, permissions and Builder settings pages.
- Added Super Admin registry, vertical-pack, integration, permission, diagnostics and platform settings pages.
- Added `titan_builder_settings` as an additive Builder-owned settings table with explicit platform/company scope.
- Hardened project/page/asset/preview/publish API controllers with explicit Builder ability checks.
- Expanded project and preview request compatibility to include the Onboarding surface and v0.8 preview states.
- Preserved all 125 registered components, 26 blocks, 11 templates, 33 pages, 29 specs, CRM/TitanAI/four-PWA provisioning and company_id tenancy.
