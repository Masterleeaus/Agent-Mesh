# Titan Builder v0.5.0 — Premium Mobile Foundation

- Extracted Mobilekit v2.9.1 into 17 Titan-native Premium declarative components.
- Added 18 Premium mobile page presets.
- Added Mobilekit-derived Premium theme and mobile-app template.
- Added scoped `tpm-*` Premium CSS and presentation-only device helper runtime.
- Replaced the dormant raw-HTML Mobilekit adapter with a read-only catalogue adapter.
- Kept `company_id` as the only active tenant boundary.
- Kept TitanMobileCore authoritative for PWA/offline/service-worker behavior.
