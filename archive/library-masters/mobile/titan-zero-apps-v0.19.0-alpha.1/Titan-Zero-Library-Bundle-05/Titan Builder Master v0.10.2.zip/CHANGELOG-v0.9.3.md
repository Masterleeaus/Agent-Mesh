# Titan Builder v0.9.3 — Titan Apps convergence

- Converges Builder to the single canonical Titan Apps Builder for `zero`, `go`, and `hub`.
- Preserves legacy surface aliases as compatibility inputs.
- Models onboarding as `surface: zero`, `journey: onboarding`.
- Adds governed Visual Runtime metadata and `VisualContribution` contract.
- Rejects executable/authority-bearing visual metadata through the Agent 4 guard.
- Preserves v0.9.2 donor migrations, models, publishing, rollback, Generative UI, assets, themes, and historical evidence.
