# Titan Builder v0.9.6 — Release evidence and provenance

- Adds canonical contribution provenance metadata.
- Adds strict package-manifest validation for slug, schema, zero/go/hub and onboarding journey semantics.
- Adds integration checklist for final suite convergence.
- Preserves prior contract fingerprint and authority guards.
