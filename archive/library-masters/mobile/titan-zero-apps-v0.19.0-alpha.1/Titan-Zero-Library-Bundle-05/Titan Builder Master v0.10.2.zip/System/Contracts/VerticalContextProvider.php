<?php
namespace App\Extensions\TitanBuilder\System\Contracts;
interface VerticalContextProvider { public function current(int $companyId): array; }
