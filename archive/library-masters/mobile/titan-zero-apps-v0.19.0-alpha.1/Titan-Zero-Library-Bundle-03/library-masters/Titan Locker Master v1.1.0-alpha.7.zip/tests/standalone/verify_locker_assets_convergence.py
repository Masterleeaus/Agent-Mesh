#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(sys.argv[1]);e=[]
def read(rel):
 p=root/rel
 if not p.is_file(): e.append('missing:'+rel); return ''
 return p.read_text(errors='replace')
provider=read('System/TitanLockerServiceProvider.php')
controller=read('System/Http/Controllers/LockerController.php')
routes=read('routes/web.php')
view=read('resources/views/locker/index.blade.php')
manifest=read('extension.json')
for cls in ['AssetRegisterService','ToolCustodyService','FleetService','MaintenanceService']:
 if f'Domains\\Locker\\{cls}' in provider: e.append('provider-still-writes:'+cls)
 if (root/f'System/Domains/Locker/{cls}.php').exists(): e.append('duplicate-service-file:'+cls)
 if f'App\\Extensions\\TitanAssets\\System\\Domains\\Assets\\{cls}' not in controller: e.append('missing-assets-delegation:'+cls)
for route in ['titan-assets.tools','titan-assets.equipment','titan-assets.fleet','titan-assets.maintenance']:
 if route not in routes: e.append('missing-ui-redirect:'+route)
for old in ['locker.assets.store','locker.tools.checkout','locker.tools.return','locker.fleet.assign','locker.maintenance.store']:
 if old not in routes: e.append('missing-legacy-route:'+old)
for bad in ['$tools','$equipment','$vehicles','$fleetAlerts','$maintenance','id="tools"','id="equipment"','id="fleet"','id="maintenance"']:
 if bad in view: e.append('locker-ui-still-assets:'+bad)
try:
 m=json.loads(manifest)
 if m.get('version')!='1.1.0-alpha.6': e.append('version')
 deps=m.get('dependencies')
 expected=[{'slug':'crm','version':'>=1.3.0-alpha.17'},{'slug':'titan-assets','version':'>=0.2.0-alpha.2'}]
 if deps!=expected: e.append('installer-1.7.8-dependencies')
 if m.get('optional_dependencies')!=[]: e.append('optional-dependencies-array')
except Exception as x:e.append('manifest-json:'+str(x))
# Installer 1.7.8 live-host contract: never republish historical migration basenames already recorded.
historical={
 '2026_08_09_000017_add_crm_titan_locker_domains.php',
 '2026_08_09_000019_harden_crm_locker_operations.php',
 '2026_08_09_000020_add_crm_locker_purchasing_stock_control.php',
}
shipped={p.name for p in (root/'database/migrations').glob('*.php')}
for name in sorted(historical & shipped): e.append('historical-migration-republished:'+name)
for prefix in ['2026_08_18_231010_','2026_08_18_231020_','2026_08_18_231030_','2026_08_18_231040_','2026_08_19_011500_']:
 if not any(n.startswith(prefix) for n in shipped): e.append('missing-reconciliation-migration:'+prefix)
menu_files=[p for p in (root/'database/migrations').glob('2026_08_18_231040_*.php')]
if menu_files:
 menu=menu_files[0].read_text(errors='replace')
 for marker in ['ext_crm_gear','titan_assets','crm_tools','crm_equipment','crm_fleet','crm_maintenance','crm_customer_assets','MenuService::class','->regenerate()']:
  if marker not in menu: e.append('locker-menu-convergence:'+marker)
 if 'Inventory & Supplies' in menu: e.append('locker-menu-ampersand-label')
# All convergence rollback paths must preserve stock and asset data.
for p in (root/'database/migrations').glob('*.php'):
 s=p.read_text(errors='replace')
 down=s[s.find('public function down'): ] if 'public function down' in s else ''
 if re.search(r'(dropIfExists|dropColumn|dropUnique|->drop\(|->rename\()',down): e.append('destructive-down:'+p.name)
# alpha.5 self-healing menu and theme regression gate
nav_file=root/'config/navigation.php'
healer_file=root/'System/Navigation/LockerMenuSelfHealer.php'
if not nav_file.is_file(): e.append('locker-navigation-config-missing')
if not healer_file.is_file(): e.append('locker-menu-self-healer-missing')
if nav_file.is_file():
 nav=nav_file.read_text(errors='replace')
 if "'label' => 'Titan Locker'" not in nav: e.append('locker-parent-label')
 if 'Inventory & Supplies' in nav or 'Gear Overview' in nav: e.append('locker-legacy-menu-label')
 if '&' in ''.join(re.findall(r"'label'\s*=>\s*'([^']*)'", nav)): e.append('locker-menu-label-ampersand')
if healer_file.is_file():
 healer=healer_file.read_text(errors='replace')
 for marker in ['MenuService::class','->regenerate()','titan_locker_menu_schema_version','Cache::forever','catch (\\Throwable)']:
  if marker not in healer: e.append('locker-healer:'+marker)
if 'LockerMenuSelfHealer' not in provider or '->heal()' not in provider: e.append('locker-provider-self-heal')
if 'Inventory & Supplies' in view or 'Gear action failed.' in view: e.append('locker-ui-legacy-copy')
for marker in ['.titan-locker-theme .card','--tblr-primary','color-mix']:
 if marker not in view: e.append('locker-theme:'+marker)

if e:
 print('FAIL',len(e));[print(x) for x in e];sys.exit(1)
print('PASS Titan Locker assets convergence contract')
