<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$sp=file_get_contents($root.'/System/TitanLockerServiceProvider.php');
$adapter=file_get_contents($root.'/System/Workforce/LockerDomainCommandAdapter.php');
$client=file_get_contents($root.'/System/Workforce/LockerCommandBusAdapter.php');
foreach(['inventory.reorder','inventory.purchase_orders','inventory.goods_receipts','inventory.stock_counts','inventory.stock_transfers','inventory.job_consumption'] as $cap) {
 if(!str_contains($sp,$cap) || !str_contains($adapter,"'$cap'")) throw new RuntimeException('Missing Command Bus registration: '.$cap);
}
if(!str_contains($adapter,'CommandAdapterContract')) throw new RuntimeException('Locker domain adapter does not implement canonical Command Bus contract.');
if(!str_contains($client,'CommandBusContract')) throw new RuntimeException('Workforce adapter does not resolve canonical Command Bus.');
$m=json_decode(file_get_contents($root.'/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR);
foreach($m['commands'] as $c) if(($c['workforce_execution']??'')!=='available_when_command_bus_ready') throw new RuntimeException('Mutation still permanently blocked.');
echo "Locker Command Bus integration: PASS\n";
