# Titan Locker Domain Ownership — v1.1.0-alpha.6

Titan Locker owns inventory, consumables/materials, stock locations, stock movements, reservations, reorder logic, suppliers, purchase orders, goods receipts, stock counts, and stock transfers.

Titan Assets owns individually tracked tools, equipment, fleet, custody, maintenance, repairs, warranties, mileage and premises links. Legacy Locker asset route names remain as compatibility routes but execute Titan Assets services or redirect to Titan Assets UI.

Existing `crm_locker_*` asset tables are preserved; table names are historical persistence contracts and no longer indicate Locker write ownership.
