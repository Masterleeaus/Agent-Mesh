## Workforce convergence Pass 6
- Pass 6: implemented conditional canonical Titan Command Bus mutation adapters for Workforce.

# Titan Locker v1.1.0-alpha.6

## Dependency compatibility hotfix

- Fixes live Titan Extension Manager 1.7.3 validation failure: `Unsatisfied extension dependencies: titan-assets >=0.2.1-alpha.3`.
- Relaxes the required Titan Assets floor to `>=0.2.0-alpha.2`, which is the first full donor-parity Assets release and already contains every runtime service/route contract Titan Locker delegates to.
- Titan Assets `0.2.1-alpha.3` changed theme/menu presentation only; no Locker-consumed runtime services or routes were introduced there.
- Keeps Titan Locker menu self-healing and theme-card work intact and bumps the menu schema marker so the healer runs once after this upgrade.
- No database ownership or domain boundary changes.

- Added a boot-time and migration-time self-healing menu that adopts the live `ext_crm_gear` parent as `Titan Locker` and repairs all inventory child links.
- Removed ampersand menu wording and legacy `Gear Overview` presentation.
- Theme-aware card surfaces now derive from the active Titan/MagicAI primary colour.
- Asset-specific menu rows remain owned exclusively by Titan Assets.

# Titan Locker Changelog

## 1.1.0-alpha.4 — Installer 1.7.8 dependency contract + Assets 0.2 authority floor

- Corrects root dependency metadata to Installer 1.7.8 object-array form with `slug` and `version`.
- Requires Titan Assets `>=0.2.0-alpha.2`, the full useful asset-donor convergence build.
- Keeps Locker authoritative only for inventory, stock, supplies, purchasing, suppliers, reservations, stock counts/transfers, reorder and job consumption.
- Keeps historical Locker asset UI/action route names as compatibility bridges into Titan Assets; no duplicate Locker asset writer services are restored.
- Preserves the four new 2026-08-18 reconciliation migration basenames and does not republish the three already-recorded 2026-08-09 Locker migrations from the supplied live DB dump.
- Keeps the Gear parent labelled `Inventory & Supplies` and reinforces Assets ownership of historical tool/equipment/fleet/maintenance/customer-asset menu keys.

## 1.1.0-alpha.2

- Initial Option-A asset-authority convergence package.
- Superseded because its dependency map did not conform to Installer 1.7.8's required dependency-entry shape.

## Workforce Runtime Integration Pass 2 — 2026-08-22
- Added deterministic runtime discovery/provider fingerprint contract.
- Added fail-closed request/decision/response envelopes, idempotency, audit and health semantics.
- Added executable runtime descriptor regression coverage without granting authority on registration.
- Kept all Workforce mutations blocked until a verified Titan Command Bus adapter exists.
