<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Workforce;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanCommandBus\System\Contracts\CommandAdapterContract;
use App\Extensions\TitanCommandBus\System\DTO\CommandContext;
use App\Extensions\TitanCommandBus\System\DTO\CommandExecutionResult;
use App\Extensions\TitanCommandBus\System\DTO\CommandRequest;
use Illuminate\Contracts\Container\Container;
use InvalidArgumentException;

/**
 * Canonical Titan Command Bus domain adapter for Locker mutations.
 * Loaded only when Titan Command Bus is installed. It never grants authority;
 * Command Bus owns governance/risk/assurance/autonomy/approval gating.
 */
final class LockerDomainCommandAdapter implements CommandAdapterContract
{
    public function __construct(private Container $app, private string $capability) {}

    public function capability(): string { return $this->capability; }

    public function execute(CommandContext $context, CommandRequest $request, string $operationId): CommandExecutionResult
    {
        $actorId = filter_var($context->actorId, FILTER_VALIDATE_INT);
        if ($actorId === false || $actorId < 1) throw new InvalidArgumentException('Locker commands require a concrete user actor.');
        $resolvedCompany = CrmCompanyScope::companyId((int) $actorId);
        if ($resolvedCompany !== $context->companyId) throw new InvalidArgumentException('Locker command company scope mismatch.');

        $payload = $request->payload;
        $operation = trim((string) ($payload['operation'] ?? ''));
        if ($operation === '') throw new InvalidArgumentException('Locker command payload.operation is required.');
        $result = $this->dispatch((int) $actorId, $operation, $payload, $request->idempotencyKey);
        if (! is_array($result)) throw new \RuntimeException('Locker authoritative service returned an invalid result.');

        $entityId = $this->entityId($result);
        $reference = 'titan-locker:' . $this->capability . ':' . $operationId . ':' . substr(hash('sha256', json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)), 0, 24);
        return new CommandExecutionResult($reference, true, $entityId, $this->capability, null, [
            'operation' => $operation,
            'company_id' => $context->companyId,
            'idempotency_key' => $request->idempotencyKey,
        ]);
    }

    private function dispatch(int $userId, string $operation, array $p, string $idempotencyKey): array
    {
        $data = (array) ($p['data'] ?? []);
        $data['idempotency_key'] ??= $idempotencyKey;
        return match ($this->capability) {
            'inventory.reorder' => match ($operation) {
                'upsert_rule' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\ReorderService::class)->upsertRule($userId, $this->req($p,'item_public_id'), $this->nullable($p,'location_public_id'), $data),
                'draft_purchase_orders' => ['orders' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\ReorderPurchaseService::class)->draftPurchaseOrders($userId, $data)],
                default => throw new InvalidArgumentException('Unsupported inventory.reorder operation.'),
            },
            'inventory.purchase_orders' => match ($operation) {
                'create' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\PurchaseOrderService::class)->create($userId, $data),
                'submit' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\PurchaseOrderService::class)->submit($userId, $this->req($p,'public_id')),
                'approve' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\PurchaseOrderService::class)->approve($userId, $this->req($p,'public_id')),
                'cancel' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\PurchaseOrderService::class)->cancel($userId, $this->req($p,'public_id')),
                default => throw new InvalidArgumentException('Unsupported inventory.purchase_orders operation.'),
            },
            'inventory.goods_receipts' => match ($operation) {
                'receive' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\GoodsReceiptService::class)->receive($userId, $data),
                default => throw new InvalidArgumentException('Unsupported inventory.goods_receipts operation.'),
            },
            'inventory.stock_counts' => match ($operation) {
                'create' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockCountService::class)->create($userId, $data),
                'complete' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockCountService::class)->complete($userId, $this->req($p,'public_id'), $data),
                'adjust' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockCountService::class)->adjust($userId, $this->req($p,'item_public_id'), $this->req($p,'location_public_id'), (float) $this->req($p,'delta'), $data),
                default => throw new InvalidArgumentException('Unsupported inventory.stock_counts operation.'),
            },
            'inventory.stock_transfers' => match ($operation) {
                'create' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockTransferWorkflowService::class)->create($userId, $data),
                'dispatch' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockTransferWorkflowService::class)->dispatch($userId, $this->req($p,'public_id')),
                'receive' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockTransferWorkflowService::class)->receive($userId, $this->req($p,'public_id')),
                'cancel' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\StockTransferWorkflowService::class)->cancel($userId, $this->req($p,'public_id')),
                default => throw new InvalidArgumentException('Unsupported inventory.stock_transfers operation.'),
            },
            'inventory.job_consumption' => match ($operation) {
                'consume' => $this->app->make(\App\Extensions\TitanLocker\System\Domains\Locker\JobConsumptionService::class)->consume($userId, $this->req($p,'work_order_public_id'), $this->req($p,'item_public_id'), $this->req($p,'location_public_id'), (float) $this->req($p,'quantity'), $data),
                default => throw new InvalidArgumentException('Unsupported inventory.job_consumption operation.'),
            },
            default => throw new InvalidArgumentException('Unsupported Locker capability.'),
        };
    }

    private function req(array $p, string $key): mixed
    {
        $v = $p[$key] ?? null;
        if ($v === null || $v === '') throw new InvalidArgumentException('Locker command payload.' . $key . ' is required.');
        return $v;
    }
    private function nullable(array $p, string $key): ?string { $v=$p[$key]??null; return $v===null||$v===''?null:(string)$v; }
    private function entityId(array $result): int|string|null
    {
        foreach (['public_id','id'] as $k) if (isset($result[$k]) && (is_int($result[$k]) || is_string($result[$k]))) return $result[$k];
        foreach (['order','receipt','count','transfer','material','movement'] as $nested) if (isset($result[$nested]) && is_array($result[$nested])) foreach (['public_id','id'] as $k) if (isset($result[$nested][$k])) return $result[$nested][$k];
        return null;
    }
}
