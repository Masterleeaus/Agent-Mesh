<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Http\Controllers;

use App\Extensions\TitanLocker\System\Domains\Locker\{
    AllocationService,
    GoodsReceiptService,
    InventoryService,
    JobConsumptionService,
    PurchaseOrderService,
    ReorderPurchaseService,
    ReorderService,
    StockCountService,
    StockMovementService,
    StockTransferWorkflowService,
    SupplierService
};
use App\Extensions\TitanAssets\System\Domains\Assets\AssetRegisterService;
use App\Extensions\TitanAssets\System\Domains\Assets\FleetService;
use App\Extensions\TitanAssets\System\Domains\Assets\MaintenanceService;
use App\Extensions\TitanAssets\System\Domains\Assets\ToolCustodyService;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

final class LockerController extends Controller
{
    public function __construct(
        private InventoryService $inventory,
        private StockMovementService $stock,
        private AllocationService $allocations,
        private ReorderService $reorder,
        private AssetRegisterService $assets,
        private ToolCustodyService $tools,
        private FleetService $fleet,
        private MaintenanceService $maintenance,
        private JobConsumptionService $jobs,
        private SupplierService $supplierOps,
        private PurchaseOrderService $purchaseOrders,
        private GoodsReceiptService $goodsReceipts,
        private StockCountService $stockCounts,
        private StockTransferWorkflowService $stockTransfers,
        private ReorderPurchaseService $reorderPurchasing,
    ) {}

    public function index(Request $request)
    {
        $u = (int) $request->user()->id;
        $routeName = (string) ($request->route()?->getName() ?? '');
        $activeSection = match ($routeName) {
            'dashboard.user.crm.locker.inventory.index' => 'inventory',
            'dashboard.user.crm.locker.locations.index' => 'stock-locations',
            'dashboard.user.crm.locker.stock-control.index' => 'stock-control',
            'dashboard.user.crm.locker.reservations.index' => 'stock-reservations',
            'dashboard.user.crm.locker.reorder.ui' => 'reorder',
            'dashboard.user.crm.locker.suppliers.index' => 'suppliers',
            'dashboard.user.crm.locker.purchase-orders.ui' => 'purchase-orders',
            'dashboard.user.crm.locker.goods-receipts.ui' => 'goods-receipts',
            'dashboard.user.crm.locker.stock-counts.ui' => 'stock-counts',
            'dashboard.user.crm.locker.stock-transfers.ui' => 'stock-transfers',
            default => 'overview',
        };
        $orders = $this->purchaseOrders->orders($u, ['limit' => 50]);
        $orderDetails = [];
        foreach ($orders as $order) $orderDetails[$order['public_id']] = $this->purchaseOrders->detail($u, (string) $order['public_id']);
        $supplierRows = $this->inventory->suppliers($u);
        $supplierRatings = [];
        foreach ($supplierRows as $supplier) $supplierRatings[$supplier['public_id']] = $this->supplierOps->supplierRatings($u, (string) $supplier['public_id']);
        $counts = $this->stockCounts->counts($u, ['limit' => 50]);
        $countDetails = [];
        foreach ($counts as $count) if (in_array($count['status'], ['open','counting'], true)) $countDetails[$count['public_id']] = $this->stockCounts->detail($u, (string) $count['public_id']);
        return view('titan-locker::locker.index', [
            'items' => $this->inventory->items($u),
            'locations' => $this->inventory->locations($u),
            'suppliers' => $supplierRows,
            'supplierRatings' => $supplierRatings,
            'purchaseOrders' => $orders,
            'purchaseOrderDetails' => $orderDetails,
            'goodsReceipts' => $this->goodsReceipts->receipts($u, ['limit' => 50]),
            'stockCounts' => $counts,
            'stockCountDetails' => $countDetails,
            'stockTransfers' => $this->stockTransfers->transfers($u, ['limit' => 50]),
            'allocations' => $this->allocations->search($u, ['limit' => 50]),
            'reorderRules' => $this->reorder->rules($u),
            'reorderSuggestions' => $this->reorder->suggestions($u),
            'activeSection' => $activeSection,
        ]);
    }

    public function overview(Request $request)
    {
        $u = (int) $request->user()->id;
        $supplierRows = $this->inventory->suppliers($u);
        $supplierRatings = [];
        foreach ($supplierRows as $supplier) $supplierRatings[$supplier['public_id']] = $this->supplierOps->supplierRatings($u, (string) $supplier['public_id']);
        return response()->json([
            'items' => $this->inventory->items($u, $request->only(['item_type', 'q'])),
            'locations' => $this->inventory->locations($u),
            'suppliers' => $supplierRows,
            'supplierRatings' => $supplierRatings,
            'allocations' => $this->allocations->search($u, $request->only(['work_order_public_id', 'inventory_item_public_id', 'location_public_id', 'status'])),
            'reorder_suggestions' => $this->reorder->suggestions($u),
            'purchase_orders' => $this->purchaseOrders->orders($u, $request->only(['status','supplier_public_id','delivery_location_public_id','limit'])),
            'goods_receipts' => $this->goodsReceipts->receipts($u, $request->only(['purchase_order_public_id','supplier_public_id','location_public_id','limit'])),
            'stock_counts' => $this->stockCounts->counts($u, $request->only(['location_public_id','status','count_type','limit'])),
            'stock_transfers' => $this->stockTransfers->transfers($u, $request->only(['status','from_location_public_id','to_location_public_id','limit'])),
        ]);
    }

    public function availableStock(Request $request)
    {
        $d = $request->validate(['inventory_item_public_id' => 'required|string|max:26', 'location_public_id' => 'nullable|string|max:26']);
        return response()->json(['quantity' => $this->allocations->available((int) $request->user()->id, $d['inventory_item_public_id'], $d['location_public_id'] ?? null)]);
    }

    public function allocationIndex(Request $request)
    {
        return response()->json($this->allocations->search((int) $request->user()->id, $request->only(['work_order_public_id', 'inventory_item_public_id', 'location_public_id', 'status', 'limit'])));
    }

    public function reorderIndex(Request $request)
    {
        $u = (int) $request->user()->id;
        return response()->json(['rules' => $this->reorder->rules($u), 'suggestions' => $this->reorder->suggestions($u)]);
    }

    public function createItem(Request $request)
    {
        $row = $this->inventory->createItem((int) $request->user()->id, $request->validate([
            'name' => 'required|string|max:190', 'sku' => 'required|string|max:100', 'item_type' => 'nullable|string|max:40',
            'barcode' => 'nullable|string|max:160', 'qr_code' => 'nullable|string|max:160', 'unit' => 'nullable|string|max:40',
            'cost_minor' => 'nullable|integer|min:0', 'sale_price_minor' => 'nullable|integer|min:0', 'currency' => 'nullable|string|size:3',
            'costing_method' => 'nullable|in:fifo,lifo,weighted_average', 'track_stock' => 'nullable|boolean', 'billable_default' => 'nullable|boolean',
            'preferred_supplier_public_id' => 'nullable|string|max:26',
        ]));
        return $this->respond($request, $row, 'Inventory item created.');
    }

    public function createLocation(Request $request)
    {
        $row = $this->inventory->createLocation((int) $request->user()->id, $request->validate([
            'name' => 'required|string|max:180', 'code' => 'required|string|max:80', 'location_type' => 'nullable|string|max:40',
            'business_location_public_id' => 'nullable|string|max:26', 'fleet_vehicle_public_id' => 'nullable|string|max:26', 'assigned_user_id' => 'nullable|integer|min:1',
        ]));
        return $this->respond($request, $row, 'Stock location created.');
    }

    public function createSupplier(Request $request)
    {
        $row = $this->inventory->createSupplier((int) $request->user()->id, $request->validate([
            'name' => 'required|string|max:190', 'code' => 'nullable|string|max:80', 'email' => 'nullable|email', 'phone' => 'nullable|string|max:80',
            'website' => 'nullable|string|max:255', 'account_reference' => 'nullable|string|max:120', 'contact_name' => 'nullable|string|max:160',
            'tax_identifier' => 'nullable|string|max:80', 'payment_terms' => 'nullable|string|max:120', 'currency' => 'nullable|string|size:3', 'address' => 'nullable|string', 'capabilities' => 'nullable|array',
        ]));
        return $this->respond($request, $row, 'Supplier created.');
    }

    public function rateSupplier(Request $request, string $supplier)
    {
        $row = $this->supplierOps->rateSupplier((int) $request->user()->id, $supplier, $request->validate([
            'quality_rating' => 'required|integer|min:1|max:5', 'delivery_rating' => 'required|integer|min:1|max:5', 'service_rating' => 'required|integer|min:1|max:5',
            'notes' => 'nullable|string|max:2000', 'rated_at' => 'nullable|date',
        ]));
        return $this->respond($request, $row, 'Supplier rating saved.');
    }

    public function purchaseOrderIndex(Request $request)
    { return response()->json($this->purchaseOrders->orders((int) $request->user()->id, $request->only(['status','supplier_public_id','delivery_location_public_id','limit']))); }

    public function createPurchaseOrder(Request $request)
    {
        $d=$request->validate([
            'supplier_public_id'=>'required|string|max:26','delivery_location_public_id'=>'nullable|string|max:26','order_number'=>'nullable|string|max:100','currency'=>'nullable|string|size:3',
            'ordered_on'=>'nullable|date','expected_on'=>'nullable|date','supplier_reference'=>'nullable|string|max:160','notes'=>'nullable|string','idempotency_key'=>'nullable|string|max:160',
            'items'=>'required|array|min:1','items.*.inventory_item_public_id'=>'nullable|string|max:26','items.*.description'=>'nullable|string|max:255','items.*.quantity'=>'required|numeric|min:0.001','items.*.unit_cost_minor'=>'nullable|integer|min:0','items.*.gst_rate'=>'nullable|numeric|min:0|max:100',
        ]);
        return $this->respond($request,$this->purchaseOrders->create((int)$request->user()->id,$d),'Purchase order created.');
    }
    public function submitPurchaseOrder(Request $request,string $purchaseOrder){return $this->respond($request,$this->purchaseOrders->submit((int)$request->user()->id,$purchaseOrder),'Purchase order submitted.',200);}
    public function approvePurchaseOrder(Request $request,string $purchaseOrder){return $this->respond($request,$this->purchaseOrders->approve((int)$request->user()->id,$purchaseOrder),'Purchase order approved.',200);}
    public function cancelPurchaseOrder(Request $request,string $purchaseOrder){return $this->respond($request,$this->purchaseOrders->cancel((int)$request->user()->id,$purchaseOrder),'Purchase order cancelled.',200);}

    public function goodsReceiptIndex(Request $request)
    { return response()->json($this->goodsReceipts->receipts((int)$request->user()->id,$request->only(['purchase_order_public_id','supplier_public_id','location_public_id','limit']))); }
    public function receiveGoods(Request $request)
    {
        $d=$request->validate([
            'purchase_order_public_id'=>'required|string|max:26','location_public_id'=>'required|string|max:26','receipt_number'=>'nullable|string|max:100','supplier_delivery_reference'=>'nullable|string|max:160','received_at'=>'nullable|date','idempotency_key'=>'nullable|string|max:160','notes'=>'nullable|string',
            'items'=>'required|array|min:1','items.*.purchase_order_item_public_id'=>'required|string|max:26|distinct','items.*.quantity'=>'required|numeric|min:0.001',
        ]);
        return $this->respond($request,$this->goodsReceipts->receive((int)$request->user()->id,$d),'Goods received into Locker stock.');
    }

    public function stockCountIndex(Request $request)
    { return response()->json($this->stockCounts->counts((int)$request->user()->id,$request->only(['location_public_id','status','count_type','limit']))); }
    public function createStockCount(Request $request)
    { $d=$request->validate(['location_public_id'=>'required|string|max:26','count_number'=>'nullable|string|max:100','count_type'=>'nullable|in:cycle,full,spot','scheduled_at'=>'nullable|date','notes'=>'nullable|string','idempotency_key'=>'nullable|string|max:160']);return $this->respond($request,$this->stockCounts->create((int)$request->user()->id,$d),'Stock count opened.'); }
    public function completeStockCount(Request $request,string $stockCount)
    { $d=$request->validate(['post_adjustments'=>'nullable|boolean','items'=>'required|array|min:1','items.*.inventory_item_public_id'=>'required|string|max:26|distinct','items.*.counted_quantity'=>'required|numeric|min:0','items.*.variance_reason'=>'nullable|string|max:255']);return $this->respond($request,$this->stockCounts->complete((int)$request->user()->id,$stockCount,$d),'Stock count completed.',200); }

    public function stockTransferIndex(Request $request)
    { return response()->json($this->stockTransfers->transfers((int)$request->user()->id,$request->only(['status','from_location_public_id','to_location_public_id','limit']))); }
    public function createStockTransfer(Request $request)
    { $d=$request->validate(['from_location_public_id'=>'required|string|max:26','to_location_public_id'=>'required|string|max:26','transfer_number'=>'nullable|string|max:100','idempotency_key'=>'nullable|string|max:160','notes'=>'nullable|string','items'=>'required|array|min:1','items.*.inventory_item_public_id'=>'required|string|max:26|distinct','items.*.quantity'=>'required|numeric|min:0.001']);return $this->respond($request,$this->stockTransfers->create((int)$request->user()->id,$d),'Stock transfer requested.'); }
    public function dispatchStockTransfer(Request $request,string $stockTransfer){return $this->respond($request,$this->stockTransfers->dispatch((int)$request->user()->id,$stockTransfer),'Stock transfer dispatched.',200);}
    public function receiveStockTransfer(Request $request,string $stockTransfer){return $this->respond($request,$this->stockTransfers->receive((int)$request->user()->id,$stockTransfer),'Stock transfer received.',200);}
    public function cancelStockTransfer(Request $request,string $stockTransfer){return $this->respond($request,$this->stockTransfers->cancel((int)$request->user()->id,$stockTransfer),'Stock transfer cancelled.',200);}

    public function draftReorderPurchaseOrders(Request $request)
    { $d=$request->validate(['rule_public_ids'=>'nullable|array','rule_public_ids.*'=>'string|max:26','gst_rate'=>'nullable|numeric|min:0|max:100','currency'=>'nullable|string|size:3','idempotency_key'=>'nullable|string|max:120']);return $this->respond($request,['purchase_orders'=>$this->reorderPurchasing->draftPurchaseOrders((int)$request->user()->id,$d)],'Draft purchase orders created from reorder suggestions.'); }

    public function receive(Request $request)
    {
        $d = $request->validate([
            'inventory_item_public_id' => 'required|string|max:26', 'location_public_id' => 'required|string|max:26', 'quantity' => 'required|numeric|min:0.001',
            'unit_cost_minor' => 'nullable|integer|min:0', 'supplier_public_id' => 'nullable|string|max:26', 'reference' => 'nullable|string|max:160', 'idempotency_key' => 'nullable|string|max:190',
        ]);
        $row = $this->stock->receive((int) $request->user()->id, $d['inventory_item_public_id'], $d['location_public_id'], (float) $d['quantity'], $d);
        return $this->respond($request, $row, 'Stock received.');
    }

    public function transfer(Request $request)
    {
        $d = $request->validate([
            'inventory_item_public_id' => 'required|string|max:26', 'from_location_public_id' => 'required|string|max:26', 'to_location_public_id' => 'required|string|max:26',
            'quantity' => 'required|numeric|min:0.001', 'reference' => 'nullable|string|max:160', 'idempotency_key' => 'nullable|string|max:190',
        ]);
        $row = $this->stock->transfer((int) $request->user()->id, $d['inventory_item_public_id'], $d['from_location_public_id'], $d['to_location_public_id'], (float) $d['quantity'], $d);
        return $this->respond($request, $row, 'Stock transferred.');
    }

    public function reserveAllocation(Request $request)
    {
        $d = $request->validate([
            'work_order_public_id' => 'required|string|max:26', 'inventory_item_public_id' => 'required|string|max:26', 'location_public_id' => 'required|string|max:26',
            'quantity' => 'required|numeric|min:0.001', 'reserved_until' => 'nullable|date', 'idempotency_key' => 'nullable|string|max:160',
        ]);
        $row = $this->allocations->reserve((int) $request->user()->id, $d['work_order_public_id'], $d['inventory_item_public_id'], $d['location_public_id'], (float) $d['quantity'], $d);
        return $this->respond($request, $row, 'Stock reserved for job.');
    }

    public function releaseAllocation(Request $request, string $allocation)
    {
        $row = $this->allocations->release((int) $request->user()->id, $allocation, $request->validate(['metadata' => 'nullable|array']));
        return $this->respond($request, $row, 'Stock reservation released.', 200);
    }

    public function fulfillAllocation(Request $request, string $allocation)
    {
        $d = $request->validate(['quantity' => 'nullable|numeric|min:0.001', 'unit_cost_minor' => 'nullable|integer|min:0', 'reference' => 'nullable|string|max:160', 'idempotency_key' => 'nullable|string|max:120']);
        $row = $this->allocations->fulfill((int) $request->user()->id, $allocation, isset($d['quantity']) ? (float) $d['quantity'] : null, $d);
        return $this->respond($request, $row, 'Stock reservation fulfilled.', 200);
    }

    public function upsertReorderRule(Request $request)
    {
        $d = $request->validate([
            'inventory_item_public_id' => 'required|string|max:26', 'location_public_id' => 'nullable|string|max:26', 'reorder_point' => 'required|numeric|min:0',
            'reorder_quantity' => 'required|numeric|min:0', 'preferred_supplier_public_id' => 'nullable|string|max:26', 'supplier_lead_days' => 'nullable|integer|min:0|max:365', 'enabled' => 'nullable|boolean',
        ]);
        $row = $this->reorder->upsertRule((int) $request->user()->id, $d['inventory_item_public_id'], $d['location_public_id'] ?? null, $d);
        return $this->respond($request, $row, 'Reorder rule saved.', 200);
    }

    public function consumeJob(Request $request, string $workOrder)
    {
        $d = $request->validate([
            'inventory_item_public_id' => 'required|string|max:26', 'location_public_id' => 'required|string|max:26', 'quantity' => 'required|numeric|min:0.001',
            'unit_cost_minor' => 'nullable|integer|min:0', 'unit_sale_price_minor' => 'nullable|integer|min:0', 'billable' => 'nullable|boolean',
            'reference' => 'nullable|string|max:160', 'idempotency_key' => 'nullable|string|max:190',
        ]);
        $row = $this->jobs->consume((int) $request->user()->id, $workOrder, $d['inventory_item_public_id'], $d['location_public_id'], (float) $d['quantity'], $d);
        return response()->json($row, $row['duplicate'] ? 200 : 201);
    }

    public function createAsset(Request $request, string $type)
    {
        $common = ['status' => 'nullable|string|max:40', 'acquired_on' => 'nullable|date', 'acquisition_cost_minor' => 'nullable|integer|min:0', 'current_value_minor' => 'nullable|integer|min:0', 'warranty_expires_on' => 'nullable|date', 'retired_on' => 'nullable|date', 'metadata' => 'nullable|array'];
        $rules = match ($type) {
            'tool' => $common + ['asset_tag' => 'required|string|max:100', 'name' => 'required|string|max:180', 'inventory_item_public_id' => 'nullable|string|max:26', 'serial_number' => 'nullable|string|max:160', 'custodian_user_id' => 'nullable|integer|min:1', 'location_public_id' => 'nullable|string|max:26'],
            'equipment' => $common + ['asset_tag' => 'required|string|max:100', 'name' => 'required|string|max:180', 'equipment_type' => 'nullable|string|max:100', 'manufacturer' => 'nullable|string|max:120', 'model' => 'nullable|string|max:120', 'serial_number' => 'nullable|string|max:160', 'assigned_user_id' => 'nullable|integer|min:1', 'location_public_id' => 'nullable|string|max:26', 'depreciation_method' => 'nullable|string|max:40', 'useful_life_months' => 'nullable|integer|min:1', 'salvage_value_minor' => 'nullable|integer|min:0', 'next_service_on' => 'nullable|date', 'sold_on' => 'nullable|date'],
            'vehicle' => $common + ['registration' => 'required|string|max:40', 'vin' => 'nullable|string|max:80', 'make' => 'nullable|string|max:100', 'model' => 'nullable|string|max:100', 'year' => 'nullable|integer|min:1900|max:2100', 'assigned_user_id' => 'nullable|integer|min:1', 'odometer_km' => 'nullable|integer|min:0', 'depreciation_method' => 'nullable|string|max:40', 'useful_life_months' => 'nullable|integer|min:1', 'salvage_value_minor' => 'nullable|integer|min:0', 'registration_expires_on' => 'nullable|date', 'next_service_on' => 'nullable|date', 'sold_on' => 'nullable|date'],
            default => abort(404),
        };
        $data = $request->validate($rules);
        $row = match ($type) {
            'tool' => $this->assets->createTool((int) $request->user()->id, $data),
            'equipment' => $this->assets->createEquipment((int) $request->user()->id, $data),
            'vehicle' => $this->assets->createVehicle((int) $request->user()->id, $data),
        };
        return $this->respond($request, $row, ucfirst($type) . ' created.');
    }

    public function checkoutTool(Request $request, string $tool)
    {
        $d = $request->validate(['custodian_user_id' => 'required|integer|min:1', 'location_public_id' => 'nullable|string|max:26', 'due_back_at' => 'nullable|date']);
        return $this->respond($request, $this->tools->checkout((int) $request->user()->id, $tool, (int) $d['custodian_user_id'], $d), 'Tool checked out.', 200);
    }

    public function returnTool(Request $request, string $tool)
    {
        $d = $request->validate(['location_public_id' => 'nullable|string|max:26']);
        return $this->respond($request, $this->tools->returnTool((int) $request->user()->id, $tool, $d), 'Tool returned.', 200);
    }

    public function damageTool(Request $request, string $tool)
    {
        return $this->respond($request, $this->tools->markDamaged((int) $request->user()->id, $tool, $request->validate(['notes' => 'nullable|string|max:2000'])), 'Tool marked damaged.', 200);
    }

    public function lostTool(Request $request, string $tool)
    {
        return $this->respond($request, $this->tools->markLost((int) $request->user()->id, $tool, $request->validate(['notes' => 'nullable|string|max:2000'])), 'Tool marked lost.', 200);
    }

    public function assignFleet(Request $request, string $vehicle)
    {
        $d = $request->validate(['assigned_user_id' => 'required|integer|min:1']);
        return $this->respond($request, $this->fleet->assign((int) $request->user()->id, $vehicle, (int) $d['assigned_user_id']), 'Vehicle assigned.', 200);
    }

    public function unassignFleet(Request $request, string $vehicle)
    {
        return $this->respond($request, $this->fleet->unassign((int) $request->user()->id, $vehicle), 'Vehicle unassigned.', 200);
    }

    public function updateFleetOdometer(Request $request, string $vehicle)
    {
        $d = $request->validate(['odometer_km' => 'required|integer|min:0', 'occurred_at' => 'nullable|date']);
        return $this->respond($request, $this->fleet->updateOdometer((int) $request->user()->id, $vehicle, (int) $d['odometer_km'], $d), 'Odometer updated.', 200);
    }

    public function updateFleetStatus(Request $request, string $vehicle)
    {
        $d = $request->validate(['status' => 'required|in:active,in_service,out_of_service,retired,sold', 'notes' => 'nullable|string|max:2000']);
        return $this->respond($request, $this->fleet->updateStatus((int) $request->user()->id, $vehicle, $d['status'], $d), 'Vehicle status updated.', 200);
    }

    public function scheduleMaintenance(Request $request, string $type, string $asset)
    {
        $row = $this->maintenance->schedule((int) $request->user()->id, $type, $asset, $request->validate([
            'scheduled_for' => 'required|date', 'maintenance_type' => 'nullable|string|max:80', 'odometer_km' => 'nullable|integer|min:0',
            'cost_minor' => 'nullable|integer|min:0', 'currency' => 'nullable|string|size:3', 'supplier_public_id' => 'nullable|string|max:26',
            'notes' => 'nullable|string', 'next_due_on' => 'nullable|date', 'next_due_odometer_km' => 'nullable|integer|min:0',
        ]));
        return $this->respond($request, $row, 'Maintenance scheduled.');
    }

    public function completeMaintenance(Request $request, string $maintenance)
    {
        $row = $this->maintenance->complete((int) $request->user()->id, $maintenance, $request->validate([
            'completed_on' => 'nullable|date', 'odometer_km' => 'nullable|integer|min:0', 'cost_minor' => 'nullable|integer|min:0', 'notes' => 'nullable|string',
            'next_due_on' => 'nullable|date', 'next_due_odometer_km' => 'nullable|integer|min:0',
        ]));
        return $this->respond($request, $row, 'Maintenance completed.', 200);
    }

    public function cancelMaintenance(Request $request, string $maintenance)
    {
        $d = $request->validate(['reason' => 'nullable|string|max:255']);
        return $this->respond($request, $this->maintenance->cancel((int) $request->user()->id, $maintenance, $d['reason'] ?? null), 'Maintenance cancelled.', 200);
    }

    private function respond(Request $request, array $row, string $message, int $status = 201)
    {
        if ($request->expectsJson()) return response()->json($row, $status);
        return back()->with('success', $message);
    }
}
