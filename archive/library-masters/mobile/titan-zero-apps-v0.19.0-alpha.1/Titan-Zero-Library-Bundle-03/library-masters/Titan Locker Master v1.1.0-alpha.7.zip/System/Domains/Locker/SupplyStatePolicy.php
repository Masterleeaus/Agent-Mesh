<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use InvalidArgumentException;

final class SupplyStatePolicy
{
    private const PO = [
        'draft'=>['submitted','approved','cancelled'],
        'submitted'=>['approved','cancelled'],
        'approved'=>['partially_received','received','cancelled'],
        'partially_received'=>['partially_received','received','cancelled'],
        'received'=>[], 'cancelled'=>[],
    ];
    private const TRANSFER = ['requested'=>['in_transit','cancelled'],'in_transit'=>['received'],'received'=>[],'cancelled'=>[]];

    public function assertPurchaseOrderTransition(string $from,string $to):void
    { if(!isset(self::PO[$from])||!in_array($to,self::PO[$from],true))throw new InvalidArgumentException("Invalid purchase order transition {$from} -> {$to}."); }
    public function assertReceivableStatus(string $status):void
    { if(!in_array($status,['approved','partially_received'],true))throw new InvalidArgumentException('Purchase order is not receivable.'); }
    public function assertTransferStatus(string $from,string $to):void
    { if(!isset(self::TRANSFER[$from])||!in_array($to,self::TRANSFER[$from],true))throw new InvalidArgumentException("Invalid stock transfer transition {$from} -> {$to}."); }
}
