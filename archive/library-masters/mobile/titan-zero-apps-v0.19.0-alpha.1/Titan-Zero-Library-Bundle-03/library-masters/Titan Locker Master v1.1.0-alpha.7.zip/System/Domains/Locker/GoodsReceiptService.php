<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GoodsReceiptService
{
    public function __construct(private ConnectionInterface $db,private StockMovementService $stock,private SupplyStatePolicy $state) {}

    public function receipts(int $userId,array $filters=[]):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$q=$this->db->table('crm_locker_goods_receipts')->where('company_id',$tenant);
        foreach(['purchase_order_public_id','supplier_public_id','location_public_id'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]);
        return$q->orderByDesc('received_at')->limit(max(1,min((int)($filters['limit']??100),250)))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function receive(int $userId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$poId=trim((string)($data['purchase_order_public_id']??''));$locationId=trim((string)($data['location_public_id']??''));if($poId===''||$locationId==='')throw new InvalidArgumentException('purchase_order_public_id and location_public_id are required.');$this->location($tenant,$locationId);$lines=(array)($data['items']??[]);if($lines===[])throw new InvalidArgumentException('Goods receipt requires at least one item.');$seen=[];foreach($lines as$line){$k=trim((string)($line['purchase_order_item_public_id']??''));if($k!==''&&isset($seen[$k]))throw new InvalidArgumentException('Duplicate purchase order line in goods receipt.');if($k!=='')$seen[$k]=true;}$idk=trim((string)($data['idempotency_key']??''));
        if($idk!==''&&($existing=$this->db->table('crm_locker_goods_receipts')->where('company_id',$tenant)->where('idempotency_key',$idk)->first()))return$this->detail($tenant,(string)$existing->public_id);
        return$this->db->transaction(function()use($userId,$tenant,$poId,$locationId,$lines,$data,$idk):array{
            $po=$this->db->table('crm_locker_purchase_orders')->where('company_id',$tenant)->where('public_id',$poId)->lockForUpdate()->first();if(!$po)throw new InvalidArgumentException('Purchase order not found.');$this->state->assertReceivableStatus((string)$po->status);
            $receiptId=(string)Str::ulid();$receiptNo=trim((string)($data['receipt_number']??''));if($receiptNo==='')$receiptNo='GR-'.now()->format('ymd').'-'.substr($receiptId,-6);
            $this->db->table('crm_locker_goods_receipts')->insert(['public_id'=>$receiptId,'company_id'=>$tenant,'purchase_order_public_id'=>$poId,'supplier_public_id'=>$po->supplier_public_id,'location_public_id'=>$locationId,'receipt_number'=>$receiptNo,'supplier_delivery_reference'=>$data['supplier_delivery_reference']??null,'received_at'=>$data['received_at']??now(),'received_by_user_id'=>CrmCompanyScope::actorUserId($userId),'idempotency_key'=>$idk!==''?$idk:null,'notes'=>$data['notes']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
            foreach($lines as $line){$poLineId=trim((string)($line['purchase_order_item_public_id']??''));$qty=round((float)($line['quantity']??0),3);if($poLineId===''||$qty<=0)throw new InvalidArgumentException('Each goods receipt line requires purchase_order_item_public_id and positive quantity.');$poLine=$this->db->table('crm_locker_purchase_order_items')->where('company_id',$tenant)->where('purchase_order_public_id',$poId)->where('public_id',$poLineId)->lockForUpdate()->first();if(!$poLine)throw new InvalidArgumentException('Purchase order line not found.');if(!$poLine->inventory_item_public_id)throw new InvalidArgumentException('Purchase order line is not linked to Locker inventory.');$remaining=round((float)$poLine->ordered_quantity-(float)$poLine->received_quantity,3);if($qty>$remaining+0.0005)throw new InvalidArgumentException('Goods receipt quantity exceeds outstanding purchase quantity.');$move=$this->stock->receive($userId,(string)$poLine->inventory_item_public_id,$locationId,$qty,['unit_cost_minor'=>(int)$poLine->unit_cost_minor,'supplier_public_id'=>$po->supplier_public_id,'source_type'=>'purchase_order','source_public_id'=>$poId,'reference'=>$receiptNo,'idempotency_key'=>'gr:'.$receiptId.':'.$poLineId]);$lineId=(string)Str::ulid();$this->db->table('crm_locker_goods_receipt_items')->insert(['public_id'=>$lineId,'company_id'=>$tenant,'goods_receipt_public_id'=>$receiptId,'purchase_order_item_public_id'=>$poLineId,'inventory_item_public_id'=>$poLine->inventory_item_public_id,'received_quantity'=>$qty,'unit_cost_minor'=>(int)$poLine->unit_cost_minor,'stock_movement_public_id'=>$move['public_id']??null,'metadata'=>isset($line['metadata'])?json_encode($line['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);$this->db->table('crm_locker_purchase_order_items')->where('id',$poLine->id)->update(['received_quantity'=>round((float)$poLine->received_quantity+$qty,3),'updated_at'=>now()]);}
            $outstanding=(float)$this->db->table('crm_locker_purchase_order_items')->where('company_id',$tenant)->where('purchase_order_public_id',$poId)->selectRaw('COALESCE(SUM(ordered_quantity-received_quantity),0) AS q')->value('q');$to=$outstanding<=0.0005?'received':'partially_received';if((string)$po->status!==$to)$this->state->assertPurchaseOrderTransition((string)$po->status,$to);$this->db->table('crm_locker_purchase_orders')->where('id',$po->id)->update(['status'=>$to,'updated_at'=>now()]);return$this->detail($tenant,$receiptId);
        },3);
    }

    private function detail(int $tenant,string $publicId):array{$r=$this->db->table('crm_locker_goods_receipts')->where('company_id',$tenant)->where('public_id',$publicId)->first();if(!$r)throw new InvalidArgumentException('Goods receipt not found.');$items=$this->db->table('crm_locker_goods_receipt_items')->where('company_id',$tenant)->where('goods_receipt_public_id',$publicId)->orderBy('id')->get()->map(fn($x)=>(array)$x)->all();return['receipt'=>(array)$r,'items'=>$items];}
    private function location(int $tenant,string $publicId):object{$r=$this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('public_id',$publicId)->where('active',true)->first();if(!$r)throw new InvalidArgumentException('Stock location not found.');return$r;}
}
