<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanLocker\System\Domains\Locker\Policies\InventoryQuantityPolicy;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class AllocationService
{
    public function __construct(private ConnectionInterface $db, private StockMovementService $stock, private JobConsumptionService $jobs, private InventoryQuantityPolicy $quantityPolicy) {}

    public function search(int $userId, array $filters = []): array
    {
        $q = $this->db->table('crm_locker_stock_allocations')
            ->where('company_id', CrmCompanyScope::companyId($userId));
        foreach (['work_order_public_id', 'inventory_item_public_id', 'location_public_id', 'status'] as $field) {
            if (array_key_exists($field, $filters) && $filters[$field] !== '' && $filters[$field] !== null) $q->where($field, $filters[$field]);
        }
        return $q->orderByDesc('id')->limit((int) ($filters['limit'] ?? 200))->get()->map(fn ($row) => (array) $row)->all();
    }

    public function available(int $userId, string $itemPublicId, ?string $locationPublicId = null): float
    {
        $tenant = CrmCompanyScope::companyId($userId);
        $onHand = $this->stock->onHand($userId, $itemPublicId, $locationPublicId);
        $q = $this->db->table('crm_locker_stock_allocations')
            ->where('company_id', $tenant)
            ->where('inventory_item_public_id', $itemPublicId)
            ->whereIn('status', ['reserved', 'partially_fulfilled'])
            ->where(function ($x): void { $x->whereNull('reserved_until')->orWhere('reserved_until', '>=', now()); });
        if ($locationPublicId !== null) $q->where('location_public_id', $locationPublicId);
        $reserved = (float) $q->selectRaw('COALESCE(SUM(quantity - fulfilled_quantity), 0) AS reserved_qty')->value('reserved_qty');
        return round(max(0.0, $this->quantityPolicy->available($onHand, $reserved)), 3);
    }

    public function reserve(int $userId, string $workOrderPublicId, string $itemPublicId, string $locationPublicId, float $quantity, array $data = []): array
    {
        $this->quantityPolicy->assertPositive($quantity, 'reserved quantity');
        $tenant = CrmCompanyScope::companyId($userId);
        $idempotency = trim((string) ($data['idempotency_key'] ?? ''));
        if ($idempotency !== '') {
            $existing = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('idempotency_key', $idempotency)->first();
            if ($existing) return (array) $existing;
        }

        return $this->db->transaction(function () use ($userId, $tenant, $workOrderPublicId, $itemPublicId, $locationPublicId, $quantity, $data, $idempotency): array {
            $this->lockItem($tenant, $itemPublicId);
            $this->assertWorkOrder($tenant, $workOrderPublicId);
            $this->assertLocation($tenant, $locationPublicId);
            $this->quantityPolicy->assertAvailable($this->available($userId, $itemPublicId, $locationPublicId), 0.0, $quantity);
            if ($idempotency !== '') {
                $existing = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('idempotency_key', $idempotency)->first();
                if ($existing) return (array) $existing;
            }
            $publicId = (string) Str::ulid();
            $this->db->table('crm_locker_stock_allocations')->insert([
                'public_id' => $publicId,
                'company_id' => $tenant,
                'inventory_item_public_id' => $itemPublicId,
                'location_public_id' => $locationPublicId,
                'work_order_public_id' => $workOrderPublicId,
                'quantity' => round($quantity, 3),
                'fulfilled_quantity' => 0,
                'status' => 'reserved',
                'reserved_until' => $data['reserved_until'] ?? null,
                'idempotency_key' => $idempotency !== '' ? $idempotency : null,
                'source_type' => $data['source_type'] ?? null,
                'source_public_id' => $data['source_public_id'] ?? null,
                'created_by_user_id' => CrmCompanyScope::actorUserId($userId),
                'updated_by_user_id' => CrmCompanyScope::actorUserId($userId),
                'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : null,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            return (array) $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $publicId)->first();
        });
    }

    public function release(int $userId, string $allocationPublicId, array $data = []): array
    {
        $tenant = CrmCompanyScope::companyId($userId);
        return $this->db->transaction(function () use ($tenant, $userId, $allocationPublicId, $data): array {
            $row = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->lockForUpdate()->first();
            if (! $row) throw new InvalidArgumentException('Stock allocation not found.');
            if (in_array($row->status, ['released', 'fulfilled'], true)) return (array) $row;
            $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->update([
                'status' => 'released', 'released_at' => now(), 'updated_by_user_id' => CrmCompanyScope::actorUserId($userId),
                'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : $row->metadata, 'updated_at' => now(),
            ]);
            return (array) $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->first();
        });
    }

    public function fulfill(int $userId, string $allocationPublicId, ?float $quantity = null, array $data = []): array
    {
        $tenant = CrmCompanyScope::companyId($userId);
        $seed = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->first();
        if (! $seed) throw new InvalidArgumentException('Stock allocation not found.');
        $idempotency = trim((string) ($data['idempotency_key'] ?? ''));
        $movementKey = $idempotency !== '' ? 'alloc-fulfill:' . $idempotency : null;
        if ($movementKey !== null) {
            $existingMovement = $this->db->table('crm_locker_stock_movements')->where('company_id', $tenant)->where('idempotency_key', $movementKey)->first();
            if ($existingMovement) return ['allocation' => (array) $seed, 'movement' => (array) $existingMovement, 'duplicate' => true];
        }

        return $this->db->transaction(function () use ($userId, $tenant, $allocationPublicId, $seed, $quantity, $data, $movementKey): array {
            $this->lockItem($tenant, (string) $seed->inventory_item_public_id);
            $row = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->lockForUpdate()->first();
            if (! $row) throw new InvalidArgumentException('Stock allocation not found.');
            if ($row->status === 'released') throw new InvalidArgumentException('Released allocation cannot be fulfilled.');
            $remaining = round((float) $row->quantity - (float) $row->fulfilled_quantity, 3);
            if ($remaining <= 0) return ['allocation' => (array) $row, 'movement' => null, 'duplicate' => true];
            $consumeQty = $quantity === null ? $remaining : round($quantity, 3);
            $this->quantityPolicy->assertReservationConsumption((float) $row->quantity, (float) $row->fulfilled_quantity, $consumeQty);
            if ($movementKey !== null && ($existing = $this->db->table('crm_locker_stock_movements')->where('company_id', $tenant)->where('idempotency_key', $movementKey)->first())) {
                return ['allocation' => (array) $row, 'movement' => (array) $existing, 'duplicate' => true];
            }
            $jobResult = $this->jobs->consume($userId, (string) $row->work_order_public_id, (string) $row->inventory_item_public_id, (string) $row->location_public_id, $consumeQty, [
                'allocation_public_id' => $allocationPublicId,
                'reference' => $data['reference'] ?? null,
                'idempotency_key' => $movementKey,
                'unit_cost_minor' => $data['unit_cost_minor'] ?? null,
                'unit_sale_price_minor' => $data['unit_sale_price_minor'] ?? null,
                'billable' => $data['billable'] ?? true,
                'movement_metadata' => ['allocation_public_id' => $allocationPublicId] + (array)($data['metadata'] ?? []),
                'metadata' => ['allocation_public_id' => $allocationPublicId] + (array)($data['metadata'] ?? []),
            ]);
            $movement = $jobResult['movement'];
            $fulfilled = round((float) $row->fulfilled_quantity + $consumeQty, 3);
            $complete = $fulfilled + 0.0005 >= (float) $row->quantity;
            $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->update([
                'fulfilled_quantity' => $fulfilled,
                'status' => $complete ? 'fulfilled' : 'partially_fulfilled',
                'fulfilled_at' => $complete ? now() : null,
                'updated_by_user_id' => CrmCompanyScope::actorUserId($userId),
                'updated_at' => now(),
            ]);
            $updated = $this->db->table('crm_locker_stock_allocations')->where('company_id', $tenant)->where('public_id', $allocationPublicId)->first();
            return ['allocation' => (array) $updated, 'movement' => $movement, 'material' => $jobResult['material'] ?? null, 'duplicate' => (bool)($jobResult['duplicate'] ?? false)];
        });
    }

    private function lockItem(int $tenant, string $itemPublicId): void
    {
        $item = $this->db->table('crm_locker_inventory_items')->where('company_id', $tenant)->where('public_id', $itemPublicId)->whereNull('deleted_at')->lockForUpdate()->first();
        if (! $item) throw new InvalidArgumentException('Inventory item not found.');
    }

    private function assertLocation(int $tenant, string $locationPublicId): void
    {
        if (! $this->db->table('crm_locker_stock_locations')->where('company_id', $tenant)->where('public_id', $locationPublicId)->where('active', true)->exists()) throw new InvalidArgumentException('Stock location not found.');
    }

    private function assertWorkOrder(int $tenant, string $workOrderPublicId): void
    {
        if (! $this->db->table('crm_work_orders')->where('company_id', $tenant)->where('public_id', $workOrderPublicId)->whereNull('deleted_at')->exists()) throw new InvalidArgumentException('Work order not found.');
    }
}
