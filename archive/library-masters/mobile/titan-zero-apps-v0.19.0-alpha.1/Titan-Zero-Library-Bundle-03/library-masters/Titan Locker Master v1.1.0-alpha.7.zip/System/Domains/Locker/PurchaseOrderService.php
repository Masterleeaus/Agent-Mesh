<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class PurchaseOrderService
{
    public function __construct(private ConnectionInterface $db,private SupplyStatePolicy $state) {}

    public function orders(int $userId,array $filters=[]):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$q=$this->db->table('crm_locker_purchase_orders as po')->leftJoin('crm_locker_suppliers as s',function($j){$j->on('s.public_id','=','po.supplier_public_id')->on('s.company_id','=','po.company_id');})->where('po.company_id',$tenant);
        foreach(['status','supplier_public_id','delivery_location_public_id'] as $f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where('po.'.$f,$filters[$f]);
        return$q->select(['po.*','s.name as supplier_name'])->orderByDesc('po.id')->limit(max(1,min((int)($filters['limit']??100),250)))->get()->map(fn($r)=>(array)$r)->all();
    }

    public function detail(int $userId,string $publicId):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$po=$this->po($tenant,$publicId);$items=$this->db->table('crm_locker_purchase_order_items')->where('company_id',$tenant)->where('purchase_order_public_id',$publicId)->orderBy('id')->get()->map(fn($r)=>(array)$r)->all();return['order'=>(array)$po,'items'=>$items];
    }

    public function create(int $userId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$supplierId=trim((string)($data['supplier_public_id']??''));if($supplierId==='')throw new InvalidArgumentException('supplier_public_id is required.');$this->supplier($tenant,$supplierId);
        $location=$data['delivery_location_public_id']??null;if($location!==null&&$location!=='')$this->location($tenant,(string)$location);
        $items=(array)($data['items']??[]);if($items===[])throw new InvalidArgumentException('Purchase order requires at least one item.');$idk=trim((string)($data['idempotency_key']??''));
        if($idk!==''&&($existing=$this->db->table('crm_locker_purchase_orders')->where('company_id',$tenant)->where('idempotency_key',$idk)->first()))return$this->detail($userId,(string)$existing->public_id);
        return$this->db->transaction(function()use($userId,$tenant,$supplierId,$location,$items,$data,$idk):array{
            $resolved=[];$subtotal=0;$gst=0;
            foreach($items as $line){$itemId=trim((string)($line['inventory_item_public_id']??''));$item=$itemId!==''?$this->item($tenant,$itemId):null;$qty=round((float)($line['quantity']??0),3);$unit=(int)($line['unit_cost_minor']??($item->cost_minor??0));$rate=(float)($line['gst_rate']??10);if($qty<=0||$unit<0||$rate<0)throw new InvalidArgumentException('Purchase order line quantity/cost/GST is invalid.');$ex=(int)round($qty*$unit);$lineGst=(int)round($ex*$rate/100);$subtotal+=$ex;$gst+=$lineGst;$resolved[]=['inventory_item_public_id'=>$itemId!==''?$itemId:null,'description'=>trim((string)($line['description']??($item->name??'')))?:'Purchased item','ordered_quantity'=>$qty,'unit_cost_minor'=>$unit,'gst_rate'=>$rate,'line_ex_gst_minor'=>$ex,'gst_minor'=>$lineGst,'line_total_minor'=>$ex+$lineGst,'metadata'=>$line['metadata']??null];}
            $publicId=(string)Str::ulid();$orderNo=trim((string)($data['order_number']??''));if($orderNo==='')$orderNo='PO-'.now()->format('ymd').'-'.substr($publicId,-6);
            if($this->db->table('crm_locker_purchase_orders')->where('company_id',$tenant)->where('order_number',$orderNo)->exists())throw new InvalidArgumentException('Purchase order number already exists.');
            $this->db->table('crm_locker_purchase_orders')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'supplier_public_id'=>$supplierId,'delivery_location_public_id'=>$location?:null,'order_number'=>$orderNo,'status'=>'draft','currency'=>strtoupper((string)($data['currency']??'AUD')),'ordered_on'=>$data['ordered_on']??null,'expected_on'=>$data['expected_on']??null,'subtotal_minor'=>$subtotal,'gst_minor'=>$gst,'total_minor'=>$subtotal+$gst,'supplier_reference'=>$data['supplier_reference']??null,'notes'=>$data['notes']??null,'idempotency_key'=>$idk!==''?$idk:null,'created_by_user_id'=>CrmCompanyScope::actorUserId($userId),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);
            foreach($resolved as $line){$this->db->table('crm_locker_purchase_order_items')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'purchase_order_public_id'=>$publicId,'inventory_item_public_id'=>$line['inventory_item_public_id'],'description'=>$line['description'],'ordered_quantity'=>$line['ordered_quantity'],'received_quantity'=>0,'unit_cost_minor'=>$line['unit_cost_minor'],'gst_rate'=>$line['gst_rate'],'line_ex_gst_minor'=>$line['line_ex_gst_minor'],'gst_minor'=>$line['gst_minor'],'line_total_minor'=>$line['line_total_minor'],'metadata'=>$line['metadata']!==null?json_encode($line['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);}
            return$this->detail($userId,$publicId);
        },3);
    }

    public function submit(int $userId,string $publicId):array{return$this->transition($userId,$publicId,'submitted');}
    public function approve(int $userId,string $publicId):array{return$this->transition($userId,$publicId,'approved');}
    public function cancel(int $userId,string $publicId):array{return$this->transition($userId,$publicId,'cancelled');}

    private function transition(int $userId,string $publicId,string $to):array
    {
        $tenant=CrmCompanyScope::companyId($userId);return$this->db->transaction(function()use($userId,$tenant,$publicId,$to):array{$po=$this->db->table('crm_locker_purchase_orders')->where('company_id',$tenant)->where('public_id',$publicId)->lockForUpdate()->first();if(!$po)throw new InvalidArgumentException('Purchase order not found.');$this->state->assertPurchaseOrderTransition((string)$po->status,$to);$actor=CrmCompanyScope::actorUserId($userId);$payload=['status'=>$to,'updated_at'=>now()];if($to==='submitted'){$payload['submitted_by_user_id']=$actor;$payload['submitted_at']=now();}if($to==='approved'){$payload['approved_by_user_id']=$actor;$payload['approved_at']=now();$payload['ordered_on']=$po->ordered_on??now()->toDateString();}if($to==='cancelled'){$payload['cancelled_by_user_id']=$actor;$payload['cancelled_at']=now();}$this->db->table('crm_locker_purchase_orders')->where('id',$po->id)->update($payload);return$this->detail($userId,$publicId);},3);
    }

    private function po(int $tenant,string $publicId):object{$row=$this->db->table('crm_locker_purchase_orders')->where('company_id',$tenant)->where('public_id',$publicId)->first();if(!$row)throw new InvalidArgumentException('Purchase order not found.');return$row;}
    private function supplier(int $tenant,string $publicId):object{$row=$this->db->table('crm_locker_suppliers')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();if(!$row)throw new InvalidArgumentException('Supplier not found.');return$row;}
    private function item(int $tenant,string $publicId):object{$row=$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();if(!$row)throw new InvalidArgumentException('Inventory item not found.');return$row;}
    private function location(int $tenant,string $publicId):object{$row=$this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('public_id',$publicId)->where('active',true)->first();if(!$row)throw new InvalidArgumentException('Stock location not found.');return$row;}
}
