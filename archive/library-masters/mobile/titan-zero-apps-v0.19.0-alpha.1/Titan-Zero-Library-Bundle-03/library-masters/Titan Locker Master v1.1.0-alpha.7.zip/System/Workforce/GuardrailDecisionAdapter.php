<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
interface GuardrailDecisionAdapter { public function stage(): string; public function evaluate(array $request): array; }
