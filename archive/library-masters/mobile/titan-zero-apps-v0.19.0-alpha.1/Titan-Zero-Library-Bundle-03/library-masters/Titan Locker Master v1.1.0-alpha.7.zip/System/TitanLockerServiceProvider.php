<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanLocker\System\Navigation\LockerMenuSelfHealer;
use Illuminate\Support\ServiceProvider;
use App\Extensions\TitanLocker\System\Workforce\LockerCommandBusAdapter;
use App\Extensions\TitanLocker\System\Workforce\CommandBusAdapter;
use App\Extensions\TitanLocker\System\Workforce\LockerDomainCommandAdapter;

final class TitanLockerServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/navigation.php', 'titan-locker-navigation');
        $this->app->singleton(LockerMenuSelfHealer::class);
        $this->app->singleton(CommandBusAdapter::class, fn ($app) => new LockerCommandBusAdapter($app));
        foreach ([
            \App\Extensions\TitanLocker\System\Domains\Locker\AllocationService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\GoodsReceiptService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\InventoryService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\JobConsumptionService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\Policies\InventoryQuantityPolicy::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\Policies\StockMovementPolicy::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\PurchaseOrderService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\ReorderPurchaseService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\ReorderService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\StockCountService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\StockMovementService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\StockTransferWorkflowService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\SupplierService::class,
            \App\Extensions\TitanLocker\System\Domains\Locker\SupplyStatePolicy::class
        ] as $service) $this->app->singleton($service);
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-locker');
        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        if (is_file(__DIR__ . '/../routes/api.php')) $this->loadRoutesFrom(__DIR__ . '/../routes/api.php');
        try { $this->app->make(LockerMenuSelfHealer::class)->heal(); } catch (\Throwable) { /* Fail-open navigation repair. */ }
        $this->registerCommandBusAdapters();
    }


    private function registerCommandBusAdapters(): void
    {
        $registryContract = 'App\\Extensions\\TitanCommandBus\\System\\Contracts\\CommandAdapterRegistryContract';
        $adapterContract = 'App\\Extensions\\TitanCommandBus\\System\\Contracts\\CommandAdapterContract';
        if (! interface_exists($registryContract) || ! interface_exists($adapterContract) || ! $this->app->bound($registryContract)) return;
        try {
            $registry = $this->app->make($registryContract);
            foreach (['inventory.reorder','inventory.purchase_orders','inventory.goods_receipts','inventory.stock_counts','inventory.stock_transfers','inventory.job_consumption'] as $capability) {
                if (method_exists($registry, 'has') && $registry->has($capability)) continue;
                $registry->register(new LockerDomainCommandAdapter($this->app, $capability));
            }
        } catch (\Throwable $e) {
            // Fail closed: no mutation path is exposed if the canonical bus registry cannot be verified.
            report($e);
        }
    }

    public function registerKey(): string { return 'titan-locker'; }
    public static function uninstall(): void { /* Domain data retained by default for safe extraction/upgrades. */ }
}
