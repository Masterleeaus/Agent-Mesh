<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Workforce;

use InvalidArgumentException;

final class EvidenceReceipt
{
    /** @param list<string> $reasonCodes @param list<string> $evidenceRefs @return array<string,mixed> */
    public function issue(string $receiptId, string $correlationId, string $companyId, string $provider, string $providerVersion, string $capabilityId, string $decision, array $reasonCodes, array $evidenceRefs, string $occurredAt): array
    {
        foreach ([$receiptId,$correlationId,$companyId,$provider,$providerVersion,$capabilityId,$decision,$occurredAt] as $value) {
            if ($value === '') throw new InvalidArgumentException('Evidence receipt fields must be non-empty.');
        }
        $payload=['receipt_id'=>$receiptId,'correlation_id'=>$correlationId,'company_id'=>$companyId,'provider'=>$provider,'provider_version'=>$providerVersion,'capability_id'=>$capabilityId,'decision'=>$decision,'reason_codes'=>array_values($reasonCodes),'evidence_refs'=>array_values($evidenceRefs),'occurred_at'=>$occurredAt];
        $canonical=json_encode($payload, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $payload['integrity_sha256']=hash('sha256',$canonical);
        return $payload;
    }
}
