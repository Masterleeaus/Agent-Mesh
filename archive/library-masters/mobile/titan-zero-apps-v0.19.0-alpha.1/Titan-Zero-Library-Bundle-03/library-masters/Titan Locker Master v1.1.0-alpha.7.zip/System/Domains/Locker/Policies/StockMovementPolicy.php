<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker\Policies;

use InvalidArgumentException;

final class StockMovementPolicy
{
    private const TYPES = ['receive', 'transfer', 'transfer_dispatch', 'transfer_receive', 'adjust', 'consume', 'return', 'dispose'];

    public function assertQuantity(string $type, float $quantity): void
    {
        if (! in_array($type, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported stock movement type.');
        }
        if ($type === 'adjust') {
            if (abs($quantity) < 0.00001) {
                throw new InvalidArgumentException('Adjustment quantity cannot be zero.');
            }
            return;
        }
        if ($quantity <= 0) {
            throw new InvalidArgumentException('Stock movement quantity must be greater than zero.');
        }
    }

    public function assertShape(string $type, ?string $source, ?string $target): void
    {
        if (! in_array($type, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported stock movement type.');
        }
        if (in_array($type, ['transfer','transfer_dispatch','transfer_receive'], true) && ($source === null || $target === null)) {
            throw new InvalidArgumentException('Transfers require source and destination stock locations.');
        }
        if (in_array($type, ['consume', 'dispose'], true) && $source === null) {
            throw new InvalidArgumentException("{$type} movements require a source stock location.");
        }
        if (in_array($type, ['receive', 'return', 'adjust'], true) && $target === null) {
            throw new InvalidArgumentException("{$type} movements require a destination stock location.");
        }
        if ($source !== null && $target !== null && $source === $target) {
            throw new InvalidArgumentException('Source and destination stock locations must differ.');
        }
    }
}
