<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class JobConsumptionService
{
    public function __construct(private ConnectionInterface $db,private StockMovementService $stock) {}

    public function consume(int $userId,string $workOrderPublicId,string $itemPublicId,string $locationPublicId,float $quantity,array $data=[]):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$work=$this->db->table('crm_work_orders')->where('company_id',$tenant)->where('public_id',$workOrderPublicId)->whereNull('deleted_at')->first();if(!$work)throw new InvalidArgumentException('Work order not found.');
        $item=$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$itemPublicId)->whereNull('deleted_at')->first();if(!$item)throw new InvalidArgumentException('Inventory item not found.');$idk=trim((string)($data['idempotency_key']??''));
        return$this->db->transaction(function()use($userId,$tenant,$workOrderPublicId,$itemPublicId,$locationPublicId,$quantity,$data,$item,$idk){$movement=$this->stock->consume($userId,$itemPublicId,$locationPublicId,$quantity,['work_order_public_id'=>$workOrderPublicId,'source_type'=>'work_order_material','reference'=>$data['reference']??null,'idempotency_key'=>$idk!==''?$idk:null,'unit_cost_minor'=>$data['unit_cost_minor']??$item->cost_minor,'allocation_public_id'=>$data['allocation_public_id']??null,'metadata'=>$data['movement_metadata']??[]]);if($existing=$this->db->table('crm_work_order_materials')->where('company_id',$tenant)->where('stock_movement_public_id',$movement['public_id'])->first())return['movement'=>$movement,'material'=>(array)$existing,'duplicate'=>true];$publicId=(string)Str::ulid();$unitSale=(int)($data['unit_sale_price_minor']??$item->sale_price_minor);$lineTotal=(int)round($quantity*$unitSale);$this->db->table('crm_work_order_materials')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'user_id'=>CrmCompanyScope::actorUserId($userId),'work_order_public_id'=>$workOrderPublicId,'name'=>$item->name,'sku'=>$item->sku,'quantity'=>round($quantity,3),'unit'=>$item->unit,'unit_cost_minor'=>$data['unit_cost_minor']??$item->cost_minor,'billable'=>(bool)($data['billable']??$item->billable_default),'inventory_item_public_id'=>$itemPublicId,'stock_movement_public_id'=>$movement['public_id'],'unit_sale_price_minor'=>$unitSale,'line_total_minor'=>$lineTotal,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return['movement'=>$movement,'material'=>(array)$this->db->table('crm_work_order_materials')->where('company_id',$tenant)->where('public_id',$publicId)->first(),'duplicate'=>false];});
    }
}
