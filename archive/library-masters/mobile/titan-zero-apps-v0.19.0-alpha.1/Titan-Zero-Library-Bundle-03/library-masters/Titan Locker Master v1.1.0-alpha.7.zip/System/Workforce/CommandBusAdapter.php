<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
interface CommandBusAdapter { public function ready(): bool; public function execute(array $commandEnvelope): array; }
