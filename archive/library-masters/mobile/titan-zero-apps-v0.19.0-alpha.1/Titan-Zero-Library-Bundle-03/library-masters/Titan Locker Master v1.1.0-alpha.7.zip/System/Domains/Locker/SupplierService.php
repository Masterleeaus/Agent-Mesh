<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class SupplierService
{
    public function __construct(private ConnectionInterface $db) {}

    public function rateSupplier(int $userId,string $supplierPublicId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$this->supplier($tenant,$supplierPublicId);
        $quality=(int)($data['quality_rating']??0);$delivery=(int)($data['delivery_rating']??0);$service=(int)($data['service_rating']??0);
        foreach(['quality'=>$quality,'delivery'=>$delivery,'service'=>$service] as $name=>$rating)if($rating<1||$rating>5)throw new InvalidArgumentException("{$name} rating must be between 1 and 5.");
        $publicId=(string)Str::ulid();$this->db->table('crm_locker_supplier_ratings')->insert([
            'public_id'=>$publicId,'company_id'=>$tenant,'supplier_public_id'=>$supplierPublicId,
            'quality_rating'=>$quality,'delivery_rating'=>$delivery,'service_rating'=>$service,'notes'=>$data['notes']??null,
            'rated_by_user_id'=>CrmCompanyScope::actorUserId($userId),'rated_at'=>$data['rated_at']??now(),'created_at'=>now(),'updated_at'=>now(),
        ]);
        return(array)$this->db->table('crm_locker_supplier_ratings')->where('company_id',$tenant)->where('public_id',$publicId)->first();
    }

    public function supplierRatings(int $userId,string $supplierPublicId):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$this->supplier($tenant,$supplierPublicId);
        $rows=$this->db->table('crm_locker_supplier_ratings')->where('company_id',$tenant)->where('supplier_public_id',$supplierPublicId)->orderByDesc('rated_at')->get()->map(fn($r)=>(array)$r)->all();
        $count=count($rows);$average=$count?[
            'quality'=>round(array_sum(array_column($rows,'quality_rating'))/$count,2),
            'delivery'=>round(array_sum(array_column($rows,'delivery_rating'))/$count,2),
            'service'=>round(array_sum(array_column($rows,'service_rating'))/$count,2),
        ]:['quality'=>null,'delivery'=>null,'service'=>null];
        return['ratings'=>$rows,'average'=>$average,'count'=>$count];
    }

    private function supplier(int $tenant,string $publicId):object
    { $row=$this->db->table('crm_locker_suppliers')->where('company_id',$tenant)->where('public_id',$publicId)->whereNull('deleted_at')->first();if(!$row)throw new InvalidArgumentException('Supplier not found.');return$row; }
}
