<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ReorderService
{
    public function __construct(private ConnectionInterface $db, private AllocationService $allocations) {}

    public function rules(int $userId): array
    {
        return $this->db->table('crm_locker_reorder_rules')->where('company_id', CrmCompanyScope::companyId($userId))->orderByDesc('enabled')->orderBy('inventory_item_public_id')->get()->map(fn ($r) => (array) $r)->all();
    }

    public function upsertRule(int $userId, string $itemPublicId, ?string $locationPublicId, array $data): array
    {
        $tenant = CrmCompanyScope::companyId($userId);
        $point = round((float) ($data['reorder_point'] ?? 0), 3);
        $quantity = round((float) ($data['reorder_quantity'] ?? 0), 3);
        if ($point < 0 || $quantity < 0) throw new InvalidArgumentException('Reorder values cannot be negative.');
        if (! $this->db->table('crm_locker_inventory_items')->where('company_id', $tenant)->where('public_id', $itemPublicId)->whereNull('deleted_at')->exists()) throw new InvalidArgumentException('Inventory item not found.');
        if ($locationPublicId !== null && ! $this->db->table('crm_locker_stock_locations')->where('company_id', $tenant)->where('public_id', $locationPublicId)->where('active', true)->exists()) throw new InvalidArgumentException('Stock location not found.');
        $supplierPublicId = $data['preferred_supplier_public_id'] ?? null;
        if ($supplierPublicId !== null && $supplierPublicId !== '' && ! $this->db->table('crm_locker_suppliers')->where('company_id', $tenant)->where('public_id', $supplierPublicId)->whereNull('deleted_at')->exists()) throw new InvalidArgumentException('Supplier not found.');
        $q = $this->db->table('crm_locker_reorder_rules')->where('company_id', $tenant)->where('inventory_item_public_id', $itemPublicId);
        $locationPublicId === null ? $q->whereNull('location_public_id') : $q->where('location_public_id', $locationPublicId);
        $existing = $q->first();
        $payload = [
            'reorder_point' => $point,
            'reorder_quantity' => $quantity,
            'preferred_supplier_public_id' => $data['preferred_supplier_public_id'] ?? null,
            'supplier_lead_days' => (int) ($data['supplier_lead_days'] ?? 0),
            'enabled' => (bool) ($data['enabled'] ?? true),
            'updated_by_user_id' => CrmCompanyScope::actorUserId($userId),
            'metadata' => isset($data['metadata']) ? json_encode($data['metadata']) : ($existing->metadata ?? null),
            'updated_at' => now(),
        ];
        if ($existing) {
            $this->db->table('crm_locker_reorder_rules')->where('id', $existing->id)->update($payload);
            return (array) $this->db->table('crm_locker_reorder_rules')->where('id', $existing->id)->first();
        }
        $publicId = (string) Str::ulid();
        $this->db->table('crm_locker_reorder_rules')->insert($payload + [
            'public_id' => $publicId, 'company_id' => $tenant, 'inventory_item_public_id' => $itemPublicId,
            'location_public_id' => $locationPublicId, 'created_at' => now(),
        ]);
        return (array) $this->db->table('crm_locker_reorder_rules')->where('company_id', $tenant)->where('public_id', $publicId)->first();
    }

    public function suggestions(int $userId): array
    {
        $tenant = CrmCompanyScope::companyId($userId);
        $rules = $this->db->table('crm_locker_reorder_rules as r')
            ->join('crm_locker_inventory_items as i', function ($join): void { $join->on('i.public_id', '=', 'r.inventory_item_public_id')->on('i.company_id', '=', 'r.company_id'); })
            ->leftJoin('crm_locker_suppliers as s', function ($join): void { $join->on('s.public_id', '=', 'r.preferred_supplier_public_id')->on('s.company_id', '=', 'r.company_id'); })
            ->where('r.company_id', $tenant)->where('r.enabled', true)->whereNull('i.deleted_at')
            ->select(['r.*', 'i.sku', 'i.name as item_name', 'i.unit', 'i.currency', 'i.cost_minor', 's.name as supplier_name'])->get();
        $out = [];
        foreach ($rules as $rule) {
            $available = $this->allocations->available($userId, (string) $rule->inventory_item_public_id, $rule->location_public_id ? (string) $rule->location_public_id : null);
            $point = (float) $rule->reorder_point;
            if ($available > $point + 0.0005) continue;
            $minimum = max(0.0, $point - $available);
            $suggested = max((float) $rule->reorder_quantity, $minimum);
            $out[] = [
                'rule_public_id' => $rule->public_id,
                'inventory_item_public_id' => $rule->inventory_item_public_id,
                'location_public_id' => $rule->location_public_id,
                'sku' => $rule->sku, 'item_name' => $rule->item_name, 'unit' => $rule->unit,
                'available_quantity' => round($available, 3), 'reorder_point' => round($point, 3),
                'suggested_quantity' => round($suggested, 3), 'preferred_supplier_public_id' => $rule->preferred_supplier_public_id,
                'supplier_name' => $rule->supplier_name, 'supplier_lead_days' => (int) $rule->supplier_lead_days,
                'estimated_cost_minor' => (int) round($suggested * (int) $rule->cost_minor), 'currency' => $rule->currency,
            ];
        }
        usort($out, fn ($a, $b) => ($a['available_quantity'] <=> $b['available_quantity']) ?: strcmp((string) $a['item_name'], (string) $b['item_name']));
        return $out;
    }
}
