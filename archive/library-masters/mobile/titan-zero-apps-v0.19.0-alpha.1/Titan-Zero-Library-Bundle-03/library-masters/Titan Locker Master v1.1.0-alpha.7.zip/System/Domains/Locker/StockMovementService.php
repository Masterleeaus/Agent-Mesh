<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use App\Extensions\TitanLocker\System\Domains\Locker\Policies\StockMovementPolicy;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class StockMovementService
{
    public function __construct(private ConnectionInterface $db, private StockMovementPolicy $movementPolicy) {}

    public function onHand(int $userId,string $itemPublicId,?string $locationPublicId=null):float
    { $q=$this->db->table('crm_locker_stock_movements')->where('company_id',CrmCompanyScope::companyId($userId))->where('inventory_item_public_id',$itemPublicId);if($locationPublicId!==null)$q->where('location_public_id',$locationPublicId);return round((float)$q->sum('quantity_delta'),3); }

    public function receive(int $userId,string $itemPublicId,string $locationPublicId,float $quantity,array $data=[]):array
    { $this->movementPolicy->assertQuantity('receive',$quantity);$this->movementPolicy->assertShape('receive',null,$locationPublicId);return$this->db->transaction(fn()=>$this->record($userId,$itemPublicId,$locationPublicId,'receive',$quantity,$data)); }

    public function adjust(int $userId,string $itemPublicId,string $locationPublicId,float $delta,array $data=[]):array
    {
        $this->movementPolicy->assertQuantity('adjust',$delta);$this->movementPolicy->assertShape('adjust',null,$locationPublicId);
        return$this->withItemLock($userId,$itemPublicId,function()use($userId,$itemPublicId,$locationPublicId,$delta,$data){if($delta<0)$this->assertAvailable($userId,$itemPublicId,$locationPublicId,abs($delta));return$this->record($userId,$itemPublicId,$locationPublicId,'adjust',$delta,$data);});
    }

    public function consume(int $userId,string $itemPublicId,string $locationPublicId,float $quantity,array $data=[]):array
    { $this->movementPolicy->assertQuantity('consume',$quantity);$this->movementPolicy->assertShape('consume',$locationPublicId,null);return$this->withItemLock($userId,$itemPublicId,function()use($userId,$itemPublicId,$locationPublicId,$quantity,$data){$this->assertAvailable($userId,$itemPublicId,$locationPublicId,$quantity,isset($data['allocation_public_id'])?(string)$data['allocation_public_id']:null);return$this->record($userId,$itemPublicId,$locationPublicId,'consume',-$quantity,$data);}); }

    public function dispose(int $userId,string $itemPublicId,string $locationPublicId,float $quantity,array $data=[]):array
    { $this->movementPolicy->assertQuantity('dispose',$quantity);$this->movementPolicy->assertShape('dispose',$locationPublicId,null);return$this->withItemLock($userId,$itemPublicId,function()use($userId,$itemPublicId,$locationPublicId,$quantity,$data){$this->assertAvailable($userId,$itemPublicId,$locationPublicId,$quantity);return$this->record($userId,$itemPublicId,$locationPublicId,'dispose',-$quantity,$data);}); }

    public function transfer(int $userId,string $itemPublicId,string $fromLocation,string $toLocation,float $quantity,array $data=[]):array
    {
        $this->movementPolicy->assertQuantity('transfer',$quantity);$this->movementPolicy->assertShape('transfer',$fromLocation,$toLocation);
        return$this->withItemLock($userId,$itemPublicId,function()use($userId,$itemPublicId,$fromLocation,$toLocation,$quantity,$data){$this->assertAvailable($userId,$itemPublicId,$fromLocation,$quantity);$group=(string)Str::ulid();$base=trim((string)($data['idempotency_key']??''));$out=$this->record($userId,$itemPublicId,$fromLocation,'transfer_out',-$quantity,$data+['counterpart_location_public_id'=>$toLocation,'transfer_group_public_id'=>$group,'idempotency_key'=>$base!==''?$base.':out':null]);$in=$this->record($userId,$itemPublicId,$toLocation,'transfer_in',$quantity,$data+['counterpart_location_public_id'=>$fromLocation,'transfer_group_public_id'=>$group,'idempotency_key'=>$base!==''?$base.':in':null]);return['transfer_group_public_id'=>$group,'out'=>$out,'in'=>$in];});
    }

    public function transferDispatch(int $userId,string $itemPublicId,string $fromLocation,string $toLocation,float $quantity,array $data=[]):array
    {
        $this->movementPolicy->assertQuantity('transfer_dispatch',$quantity);$this->movementPolicy->assertShape('transfer_dispatch',$fromLocation,$toLocation);
        return $this->withItemLock($userId,$itemPublicId,function()use($userId,$itemPublicId,$fromLocation,$toLocation,$quantity,$data){$this->assertAvailable($userId,$itemPublicId,$fromLocation,$quantity);return $this->record($userId,$itemPublicId,$fromLocation,'transfer_dispatch',-$quantity,$data+['counterpart_location_public_id'=>$toLocation]);});
    }

    public function transferReceive(int $userId,string $itemPublicId,string $fromLocation,string $toLocation,float $quantity,array $data=[]):array
    {
        $this->movementPolicy->assertQuantity('transfer_receive',$quantity);$this->movementPolicy->assertShape('transfer_receive',$fromLocation,$toLocation);
        return $this->withItemLock($userId,$itemPublicId,fn()=>$this->record($userId,$itemPublicId,$toLocation,'transfer_receive',$quantity,$data+['counterpart_location_public_id'=>$fromLocation]));
    }

    private function withItemLock(int $userId,string $itemPublicId,callable $callback):mixed
    {
        $tenant=CrmCompanyScope::companyId($userId);return$this->db->transaction(function()use($tenant,$itemPublicId,$callback){$item=$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$itemPublicId)->whereNull('deleted_at')->lockForUpdate()->first();if(!$item)throw new InvalidArgumentException('Inventory item not found.');return$callback();});
    }

    private function record(int $userId,string $itemPublicId,string $locationPublicId,string $type,float $delta,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$this->assertItemLocation($tenant,$itemPublicId,$locationPublicId);$idk=trim((string)($data['idempotency_key']??''));if($idk!==''&&($existing=$this->db->table('crm_locker_stock_movements')->where('company_id',$tenant)->where('idempotency_key',$idk)->first()))return(array)$existing;
        $item=$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$itemPublicId)->whereNull('deleted_at')->first();$unitCost=(isset($data['unit_cost_minor'])&&$data['unit_cost_minor']!==null)?(int)$data['unit_cost_minor']:(int)$item->cost_minor;$publicId=(string)Str::ulid();$this->db->table('crm_locker_stock_movements')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'inventory_item_public_id'=>$itemPublicId,'location_public_id'=>$locationPublicId,'counterpart_location_public_id'=>$data['counterpart_location_public_id']??null,'transfer_group_public_id'=>$data['transfer_group_public_id']??null,'movement_type'=>$type,'quantity_delta'=>round($delta,3),'unit_cost_minor'=>$unitCost,'total_cost_minor'=>(int)round(abs($delta)*$unitCost),'work_order_public_id'=>$data['work_order_public_id']??null,'supplier_public_id'=>$data['supplier_public_id']??null,'source_type'=>$data['source_type']??null,'source_public_id'=>$data['source_public_id']??null,'reference'=>$data['reference']??null,'idempotency_key'=>$idk!==''?$idk:null,'occurred_at'=>$data['occurred_at']??now(),'created_by_user_id'=>CrmCompanyScope::actorUserId($userId),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return(array)$this->db->table('crm_locker_stock_movements')->where('company_id',$tenant)->where('public_id',$publicId)->first();
    }
    private function assertAvailable(int $userId,string $item,string $location,float $qty,?string $allocationPublicId=null):void
    {
        if((bool)config('crm.locker.allow_negative_stock',false))return;
        $tenant=CrmCompanyScope::companyId($userId);
        $reservedQuery=$this->db->table('crm_locker_stock_allocations')->where('company_id',$tenant)->where('inventory_item_public_id',$item)->where('location_public_id',$location)->whereIn('status',['reserved','partially_fulfilled'])->where(function($q):void{$q->whereNull('reserved_until')->orWhere('reserved_until','>=',now());});
        if($allocationPublicId!==null)$reservedQuery->where('public_id','!=',$allocationPublicId);
        $reserved=(float)$reservedQuery->selectRaw('COALESCE(SUM(quantity - fulfilled_quantity),0) AS reserved_qty')->value('reserved_qty');
        $available=round(max(0.0,$this->onHand($userId,$item,$location)-$reserved),3);
        if($available+0.0005<$qty)throw new InvalidArgumentException('Insufficient unreserved stock at selected location.');
    }
    private function assertItemLocation(int $tenant,string $item,string $location):void{if(!$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$item)->whereNull('deleted_at')->exists())throw new InvalidArgumentException('Inventory item not found.');if(!$this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('public_id',$location)->where('active',true)->exists())throw new InvalidArgumentException('Stock location not found.');}
}
