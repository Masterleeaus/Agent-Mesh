<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
final class CircuitBreaker {
 private int $failures=0; private ?int $openedAt=null;
 public function __construct(private int $threshold=3,private int $cooldownSeconds=30) { if($threshold<1||$cooldownSeconds<1) throw new \InvalidArgumentException('invalid_circuit_policy'); }
 public function allow(int $now): bool { if($this->openedAt===null) return true; if(($now-$this->openedAt)>=$this->cooldownSeconds) { $this->failures=0; $this->openedAt=null; return true; } return false; }
 public function success(): void { $this->failures=0; $this->openedAt=null; }
 public function failure(int $now): void { $this->failures++; if($this->failures >= $this->threshold) $this->openedAt=$now; }
 public function state(): array { return ['state'=>$this->openedAt===null?'closed':'open','failures'=>$this->failures,'opened_at'=>$this->openedAt]; }
}
