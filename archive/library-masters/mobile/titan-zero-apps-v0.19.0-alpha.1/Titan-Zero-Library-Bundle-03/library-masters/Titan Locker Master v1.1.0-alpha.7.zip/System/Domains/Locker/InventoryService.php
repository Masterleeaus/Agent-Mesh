<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class InventoryService
{
    public function __construct(private ConnectionInterface $db) {}

    public function items(int $userId,array $filters=[]):array
    { $q=$this->db->table('crm_locker_inventory_items')->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at');foreach(['item_type','active','preferred_supplier_public_id']as$f)if(array_key_exists($f,$filters)&&$filters[$f]!=='')$q->where($f,$filters[$f]);if(!empty($filters['q']))$q->where(function($x)use($filters){$s='%'.$filters['q'].'%';$x->where('name','like',$s)->orWhere('sku','like',$s)->orWhere('barcode','like',$s);});return$q->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }

    public function createItem(int $userId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$name=trim((string)($data['name']??''));$sku=trim((string)($data['sku']??''));if($name===''||$sku==='')throw new InvalidArgumentException('Inventory item name and SKU are required.');if($this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('sku',$sku)->whereNull('deleted_at')->exists())throw new InvalidArgumentException('Inventory SKU already exists.');
        $method=(string)($data['costing_method']??'weighted_average');if(!in_array($method,['fifo','lifo','weighted_average'],true))throw new InvalidArgumentException('Inventory costing method must be fifo, lifo or weighted_average.');$publicId=(string)Str::ulid();
        $this->db->table('crm_locker_inventory_items')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'item_type'=>$data['item_type']??'consumable','sku'=>$sku,'barcode'=>$data['barcode']??null,'qr_code'=>$data['qr_code']??null,'name'=>$name,'description'=>$data['description']??null,'unit'=>$data['unit']??'each','cost_minor'=>(int)($data['cost_minor']??0),'sale_price_minor'=>(int)($data['sale_price_minor']??0),'currency'=>strtoupper((string)($data['currency']??config('crm.settings.defaults.default_currency','AUD'))),'costing_method'=>$method,'track_stock'=>(bool)($data['track_stock']??true),'billable_default'=>(bool)($data['billable_default']??true),'active'=>(bool)($data['active']??true),'preferred_supplier_public_id'=>$data['preferred_supplier_public_id']??null,'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return(array)$this->db->table('crm_locker_inventory_items')->where('company_id',$tenant)->where('public_id',$publicId)->first();
    }

    public function createLocation(int $userId,array $data):array
    { $tenant=CrmCompanyScope::companyId($userId);$name=trim((string)($data['name']??''));$code=trim((string)($data['code']??''));if($name===''||$code==='')throw new InvalidArgumentException('Stock location name and code are required.');if($this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('code',$code)->exists())throw new InvalidArgumentException('Stock location code already exists.');$publicId=(string)Str::ulid();$this->db->table('crm_locker_stock_locations')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'location_type'=>$data['location_type']??'warehouse','code'=>$code,'name'=>$name,'business_location_public_id'=>$data['business_location_public_id']??null,'fleet_vehicle_public_id'=>$data['fleet_vehicle_public_id']??null,'assigned_user_id'=>$data['assigned_user_id']??null,'active'=>(bool)($data['active']??true),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return(array)$this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('public_id',$publicId)->first(); }

    public function locations(int $userId):array
    {return$this->db->table('crm_locker_stock_locations')->where('company_id',CrmCompanyScope::companyId($userId))->where('active',true)->orderBy('name')->get()->map(fn($r)=>(array)$r)->all();}

    public function suppliers(int $userId): array
    { return $this->db->table('crm_locker_suppliers')->where('company_id',CrmCompanyScope::companyId($userId))->whereNull('deleted_at')->where('active',true)->orderBy('name')->get()->map(fn($r)=>(array)$r)->all(); }

    public function createSupplier(int $userId,array $data):array
    { $tenant=CrmCompanyScope::companyId($userId);$name=trim((string)($data['name']??''));if($name==='')throw new InvalidArgumentException('Supplier name is required.');$publicId=(string)Str::ulid();$this->db->table('crm_locker_suppliers')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'name'=>$name,'code'=>$data['code']??null,'contact_name'=>$data['contact_name']??null,'email'=>$data['email']??null,'phone'=>$data['phone']??null,'website'=>$data['website']??null,'account_reference'=>$data['account_reference']??null,'tax_identifier'=>$data['tax_identifier']??null,'payment_terms'=>$data['payment_terms']??null,'currency'=>strtoupper((string)($data['currency']??'AUD')),'address'=>$data['address']??null,'capabilities'=>isset($data['capabilities'])?json_encode($data['capabilities']):null,'active'=>(bool)($data['active']??true),'metadata'=>isset($data['metadata'])?json_encode($data['metadata']):null,'created_at'=>now(),'updated_at'=>now()]);return(array)$this->db->table('crm_locker_suppliers')->where('company_id',$tenant)->where('public_id',$publicId)->first(); }
}
