<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Navigation;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

final class LockerMenuSelfHealer
{
    private const SCHEMA_VERSION = 'titan-locker-menu-1.1.0-alpha.6';
    private const CACHE_KEY = 'titan_locker_menu_schema_version';
    private const HOST_MENU_CACHE_KEYS = ['dynamic_menu_key', 'dynamic_menu_key_active', 'navbar_cache_registry'];

    public function heal(bool $force = false): void
    {
        try {
            if (! Schema::hasTable('menus')) {
                return;
            }
            $columns = array_flip(Schema::getColumnListing('menus'));
            if (! isset($columns['key'])) {
                return;
            }

            $parent = (array) config('titan-locker-navigation.parent', []);
            if (! $this->routeExists((string) ($parent['route'] ?? ''))) {
                return;
            }

            [$parentId, $changed] = $this->upsert($parent, null, $columns, true);
            if ($parentId <= 0) {
                return;
            }

            $protectedForParentRoute = [$parentId];
            foreach ((array) config('titan-locker-navigation.items', []) as $item) {
                if (! is_array($item) || ! $this->routeExists((string) ($item['route'] ?? ''))) {
                    continue;
                }
                [$id, $itemChanged] = $this->upsert($item, $parentId, $columns, false);
                $changed = $itemChanged || $changed;
                if ($id <= 0) {
                    continue;
                }

                $protected = [$id];
                if ((string) ($item['route'] ?? '') === (string) ($parent['route'] ?? '')) {
                    $protected[] = $parentId;
                    $protectedForParentRoute[] = $id;
                }
                $changed = $this->deactivateRouteDuplicates((string) $item['route'], array_values(array_unique($protected)), $columns) || $changed;
            }

            // Asset-specific legacy rows are intentionally left alone here. Titan Assets owns and
            // self-heals crm_tools, crm_equipment, crm_fleet, crm_maintenance and crm_customer_assets.
            $versionChanged = Cache::get(self::CACHE_KEY) !== self::SCHEMA_VERSION;
            if ($force || $changed || $versionChanged) {
                $this->regenerate();
                Cache::forever(self::CACHE_KEY, self::SCHEMA_VERSION);
            }
        } catch (\Throwable) {
            // Fail open: Locker routes remain usable even if host navigation repair is temporarily unavailable.
        }
    }

    /** @param array<string,mixed> $item @param array<string,int> $columns @return array{0:int,1:bool} */
    private function upsert(array $item, ?int $parentId, array $columns, bool $isParent): array
    {
        $key = trim((string) ($item['key'] ?? ''));
        $route = trim((string) ($item['route'] ?? ''));
        if ($key === '' || $route === '') {
            return [0, false];
        }

        $existing = DB::table('menus')->where('key', $key)->first();
        if (! $existing) {
            $candidate = DB::table('menus')->where('route', $route);
            $candidate = $isParent ? $candidate->whereNull('parent_id') : $candidate->where('parent_id', $parentId);
            $existing = $candidate->orderBy('id')->first();
        }

        $values = $this->filtered([
            'parent_id' => $parentId,
            'menu_group_id' => null,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => (string) ($item['label'] ?? $key),
            'icon' => (string) ($item['icon'] ?? 'tabler-package'),
            'svg' => null,
            'order' => (int) ($item['order'] ?? 50),
            'is_active' => 1,
            'params' => '[]',
            'type' => 'item',
            'badge' => null,
            'extension' => 'titan-locker',
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
            'custom_menu' => 1,
            'updated_at' => now(),
        ], $columns);

        if ($existing) {
            $changed = false;
            foreach ($values as $field => $value) {
                if ($field === 'updated_at') {
                    continue;
                }
                if (($existing->{$field} ?? null) != $value) {
                    $changed = true;
                    break;
                }
            }
            if ($changed) {
                DB::table('menus')->where('id', $existing->id)->update($values);
            }
            return [(int) $existing->id, $changed];
        }

        if (isset($columns['created_at'])) {
            $values['created_at'] = now();
        }
        $id = (int) DB::table('menus')->insertGetId($values);
        return [$id, true];
    }

    /** @param list<int> $protectedIds @param array<string,int> $columns */
    private function deactivateRouteDuplicates(string $route, array $protectedIds, array $columns): bool
    {
        if ($route === '' || ! isset($columns['is_active'])) {
            return false;
        }
        $query = DB::table('menus')->where('route', $route)->whereNotIn('id', $protectedIds)->where('is_active', 1);
        if ($query->count() === 0) {
            return false;
        }
        $query->update($this->filtered(['is_active' => 0, 'updated_at' => now()], $columns));
        return true;
    }

    private function routeExists(string $route): bool
    {
        return $route !== '' && Route::has($route);
    }

    /** @param array<string,mixed> $values @param array<string,int> $columns @return array<string,mixed> */
    private function filtered(array $values, array $columns): array
    {
        return array_intersect_key($values, $columns);
    }

    private function regenerate(): void
    {
        foreach (self::HOST_MENU_CACHE_KEYS as $key) {
            Cache::forget($key);
        }
        try {
            if (class_exists(\App\Services\Common\MenuService::class)) {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) {
                    $service->regenerate();
                }
            }
        } catch (\Throwable) {
            foreach (self::HOST_MENU_CACHE_KEYS as $key) {
                Cache::forget($key);
            }
        }
    }
}
