<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
final class GovernedCommandEnvelope { public static function build(array $r): array { foreach(['command_id','company_id','actor_id','correlation_id','idempotency_key','capability_id','provider','provider_version','guardrail_receipt_id'] as $k) if(!isset($r[$k])||$r[$k]==='') throw new \InvalidArgumentException($k.' required'); return $r+['issued_at'=>gmdate('c')]; } }
