<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Workforce;

use Illuminate\Contracts\Container\Container;

/** Workforce-facing client for the canonical Titan Command Bus. */
final class LockerCommandBusAdapter implements CommandBusAdapter
{
    private const BUS = 'App\\Extensions\\TitanCommandBus\\System\\Contracts\\CommandBusContract';
    private const CONTEXT = 'App\\Extensions\\TitanCommandBus\\System\\DTO\\CommandContext';
    private const REQUEST = 'App\\Extensions\\TitanCommandBus\\System\\DTO\\CommandRequest';

    public function __construct(private Container $app) {}

    public function ready(): bool
    {
        if (! interface_exists(self::BUS) || ! class_exists(self::CONTEXT) || ! class_exists(self::REQUEST) || ! $this->app->bound(self::BUS)) return false;
        try {
            $health = (array) $this->app->make(self::BUS)->health();
            $state = strtolower((string) ($health['status'] ?? $health['state'] ?? ''));
            return in_array($state, ['ok','healthy','ready','available'], true) || (($health['ready'] ?? false) === true);
        } catch (\Throwable) { return false; }
    }

    public function execute(array $e): array
    {
        if (! $this->ready()) return ['status'=>'failed','reason'=>'command_bus.unavailable'];
        try {
            $companyId=(int)($e['company_id']??0); $actor=(array)($e['actor_context']??[]); $actorId=$actor['user_id']??$actor['actor_id']??null;
            $contextClass=self::CONTEXT; $requestClass=self::REQUEST;
            $ctx=new $contextClass($companyId,(string)($actor['actor_type']??'workforce'),$actorId,'titan-ai-workforce');
            $correlation=(string)($e['correlation_id']??''); $trace=(string)($e['trace_id']??$correlation); $cause=(string)($e['causation_id']??$correlation); $root=(string)($e['root_causation_id']??$cause);
            $req=new $requestClass((string)$e['capability_id'],(array)($e['payload']??[]),(string)$e['idempotency_key'],$trace,$correlation,$cause,$root,$e['expected_entity_version']??null,(bool)($e['prepared_offline']??false));
            $receipt=$this->app->make(self::BUS)->dispatch($ctx,$req);
            $data=method_exists($receipt,'toArray')?$receipt->toArray():(array)$receipt;
            return ['status'=>(($data['status']??'')==='applied'?'succeeded':'failed'),'receipt_id'=>(string)($data['operation_id']??''),'command_receipt'=>$data,'reason'=>$data['reason_code']??null];
        } catch (\Throwable $x) { return ['status'=>'failed','reason'=>'command_bus.dispatch_failed','exception_class'=>$x::class]; }
    }
}
