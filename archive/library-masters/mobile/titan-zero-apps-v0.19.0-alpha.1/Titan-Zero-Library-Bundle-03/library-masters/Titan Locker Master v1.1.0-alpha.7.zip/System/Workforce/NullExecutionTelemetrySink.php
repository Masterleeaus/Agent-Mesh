<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
final class NullExecutionTelemetrySink implements ExecutionTelemetrySink { public function record(array $event): void { } }
