<?php
declare(strict_types=1);
namespace App\Extensions\TitanLocker\System\Workforce;
final class PersistentReceiptRegistry implements ReceiptRegistry {
 public function __construct(private \Closure $storeFn,private \Closure $findIdFn,private \Closure $findKeyFn) {}
 public function store(array $receipt): void { ($this->storeFn)($receipt); }
 public function find(string $companyId,string $receiptId): ?array { $r=($this->findIdFn)($companyId,$receiptId); return is_array($r)?$r:null; }
 public function findByIdempotency(string $companyId,string $key): ?array { $r=($this->findKeyFn)($companyId,$key); return is_array($r)?$r:null; }
}
