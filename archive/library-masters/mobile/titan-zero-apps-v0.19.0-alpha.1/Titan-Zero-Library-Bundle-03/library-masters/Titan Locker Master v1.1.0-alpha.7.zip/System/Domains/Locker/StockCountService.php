<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use App\Extensions\Crm\System\Tenancy\CrmCompanyScope;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class StockCountService
{
    public function __construct(private ConnectionInterface $db,private StockMovementService $stock) {}

    public function counts(int $userId,array $filters=[]):array
    { $tenant=CrmCompanyScope::companyId($userId);$q=$this->db->table('crm_locker_stock_counts')->where('company_id',$tenant);foreach(['location_public_id','status','count_type']as$f)if(isset($filters[$f])&&$filters[$f]!=='')$q->where($f,$filters[$f]);return$q->orderByDesc('id')->limit(max(1,min((int)($filters['limit']??100),250)))->get()->map(fn($r)=>(array)$r)->all(); }

    public function create(int $userId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$location=trim((string)($data['location_public_id']??''));if($location==='')throw new InvalidArgumentException('location_public_id is required.');$this->location($tenant,$location);$idk=trim((string)($data['idempotency_key']??''));if($idk!==''&&($existing=$this->db->table('crm_locker_stock_counts')->where('company_id',$tenant)->where('idempotency_key',$idk)->first()))return$this->detail($userId,(string)$existing->public_id);$publicId=(string)Str::ulid();$number=trim((string)($data['count_number']??''));if($number==='')$number='SC-'.now()->format('ymd').'-'.substr($publicId,-6);
        return$this->db->transaction(function()use($userId,$tenant,$location,$publicId,$number,$data,$idk):array{$this->db->table('crm_locker_stock_counts')->insert(['public_id'=>$publicId,'company_id'=>$tenant,'location_public_id'=>$location,'count_number'=>$number,'count_type'=>$data['count_type']??'cycle','status'=>'open','idempotency_key'=>$idk!==''?$idk:null,'scheduled_at'=>$data['scheduled_at']??null,'started_at'=>now(),'counted_by_user_id'=>CrmCompanyScope::actorUserId($userId),'notes'=>$data['notes']??null,'created_at'=>now(),'updated_at'=>now()]);$balances=$this->db->table('crm_locker_stock_movements')->where('company_id',$tenant)->where('location_public_id',$location)->groupBy('inventory_item_public_id')->selectRaw('inventory_item_public_id, COALESCE(SUM(quantity_delta),0) AS quantity')->get();foreach($balances as$b)$this->db->table('crm_locker_stock_count_items')->insert(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'stock_count_public_id'=>$publicId,'inventory_item_public_id'=>$b->inventory_item_public_id,'expected_quantity'=>round((float)$b->quantity,3),'created_at'=>now(),'updated_at'=>now()]);return$this->detail($userId,$publicId);},3);
    }

    public function complete(int $userId,string $publicId,array $data):array
    {
        $tenant=CrmCompanyScope::companyId($userId);$items=(array)($data['items']??[]);if($items===[])throw new InvalidArgumentException('Stock count completion requires item counts.');$seen=[];foreach($items as$line){$k=trim((string)($line['inventory_item_public_id']??''));if($k!==''&&isset($seen[$k]))throw new InvalidArgumentException('Duplicate inventory item in stock count.');if($k!=='')$seen[$k]=true;}$post=(bool)($data['post_adjustments']??true);
        return$this->db->transaction(function()use($userId,$tenant,$publicId,$items,$post):array{$count=$this->db->table('crm_locker_stock_counts')->where('company_id',$tenant)->where('public_id',$publicId)->lockForUpdate()->first();if(!$count)throw new InvalidArgumentException('Stock count not found.');if(!in_array($count->status,['open','counting'],true))throw new InvalidArgumentException('Stock count is not open.');foreach($items as$line){$itemId=trim((string)($line['inventory_item_public_id']??''));if($itemId==='')throw new InvalidArgumentException('inventory_item_public_id is required for count line.');$counted=round((float)($line['counted_quantity']??0),3);if($counted<0)throw new InvalidArgumentException('Counted quantity cannot be negative.');$row=$this->db->table('crm_locker_stock_count_items')->where('company_id',$tenant)->where('stock_count_public_id',$publicId)->where('inventory_item_public_id',$itemId)->lockForUpdate()->first();if(!$row){$expected=$this->stock->onHand($userId,$itemId,(string)$count->location_public_id);$rowId=$this->db->table('crm_locker_stock_count_items')->insertGetId(['public_id'=>(string)Str::ulid(),'company_id'=>$tenant,'stock_count_public_id'=>$publicId,'inventory_item_public_id'=>$itemId,'expected_quantity'=>$expected,'created_at'=>now(),'updated_at'=>now()]);$row=$this->db->table('crm_locker_stock_count_items')->where('id',$rowId)->first();}$variance=round($counted-(float)$row->expected_quantity,3);$movementId=null;if($post&&abs($variance)>0.0005){$move=$this->stock->adjust($userId,$itemId,(string)$count->location_public_id,$variance,['source_type'=>'stock_count','source_public_id'=>$publicId,'reference'=>$count->count_number,'idempotency_key'=>'sc:'.$publicId.':'.$itemId]);$movementId=$move['public_id']??null;}$this->db->table('crm_locker_stock_count_items')->where('id',$row->id)->update(['counted_quantity'=>$counted,'variance_quantity'=>$variance,'variance_reason'=>$line['variance_reason']??null,'adjustment_movement_public_id'=>$movementId,'updated_at'=>now()]);}$this->db->table('crm_locker_stock_counts')->where('id',$count->id)->update(['status'=>'completed','completed_at'=>now(),'approved_by_user_id'=>CrmCompanyScope::actorUserId($userId),'updated_at'=>now()]);return$this->detail($userId,$publicId);},3);
    }

    public function adjust(int $userId,string $itemPublicId,string $locationPublicId,float $delta,array $data=[]):array{return$this->stock->adjust($userId,$itemPublicId,$locationPublicId,$delta,$data+['source_type'=>'manual_stock_adjustment']);}
    public function detail(int $userId,string $publicId):array{$tenant=CrmCompanyScope::companyId($userId);$c=$this->db->table('crm_locker_stock_counts')->where('company_id',$tenant)->where('public_id',$publicId)->first();if(!$c)throw new InvalidArgumentException('Stock count not found.');$i=$this->db->table('crm_locker_stock_count_items')->where('company_id',$tenant)->where('stock_count_public_id',$publicId)->orderBy('id')->get()->map(fn($r)=>(array)$r)->all();return['count'=>(array)$c,'items'=>$i];}
    private function location(int $tenant,string $publicId):object{$r=$this->db->table('crm_locker_stock_locations')->where('company_id',$tenant)->where('public_id',$publicId)->where('active',true)->first();if(!$r)throw new InvalidArgumentException('Stock location not found.');return$r;}
}
