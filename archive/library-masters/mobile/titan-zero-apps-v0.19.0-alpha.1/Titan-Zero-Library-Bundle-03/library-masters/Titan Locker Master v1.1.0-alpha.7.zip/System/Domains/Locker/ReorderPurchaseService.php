<?php

declare(strict_types=1);

namespace App\Extensions\TitanLocker\System\Domains\Locker;

use InvalidArgumentException;

final class ReorderPurchaseService
{
    public function __construct(private ReorderService $reorder,private PurchaseOrderService $orders) {}

    public function draftPurchaseOrders(int $userId,array $data=[]):array
    {
        $suggestions=$this->reorder->suggestions($userId);$selected=array_values(array_filter((array)($data['rule_public_ids']??[]),fn($v)=>is_string($v)&&$v!==''));if($selected)$suggestions=array_values(array_filter($suggestions,fn($s)=>in_array($s['rule_public_id'],$selected,true)));if(!$suggestions)throw new InvalidArgumentException('No reorder suggestions selected.');$groups=[];
        foreach($suggestions as$s){$supplier=(string)($s['preferred_supplier_public_id']??'');if($supplier==='')continue;$location=(string)($s['location_public_id']??'');$key=$supplier.'|'.$location;$groups[$key]['supplier_public_id']=$supplier;$groups[$key]['delivery_location_public_id']=$location!==''?$location:null;$groups[$key]['items'][]=['inventory_item_public_id'=>$s['inventory_item_public_id'],'description'=>$s['item_name'],'quantity'=>$s['suggested_quantity'],'unit_cost_minor'=>$s['suggested_quantity']>0?(int)round($s['estimated_cost_minor']/$s['suggested_quantity']):0,'gst_rate'=>(float)($data['gst_rate']??10)];}
        if(!$groups)throw new InvalidArgumentException('Selected reorder suggestions do not have preferred suppliers.');$created=[];foreach($groups as$group){$created[]=$this->orders->create($userId,$group+['currency'=>$data['currency']??'AUD','notes'=>'Drafted from Locker reorder suggestions.','idempotency_key'=>isset($data['idempotency_key'])?$data['idempotency_key'].':'.md5($group['supplier_public_id'].'|'.($group['delivery_location_public_id']??'')):null]);}return$created;
    }
}
