# Workforce Runtime Pass 3 — Guardrail Composition & Evidence Receipts

Provider: `titan-locker`

This pass adds deterministic cross-extension guardrail decision composition, immutable SHA-256 evidence receipt contracts, degraded-provider fail-closed rules, and a governed Command Bus bridge contract. Workforce remains the sole employee/role identity owner and `company_id` remains the canonical authority boundary.

For Titan Locker, Workforce mutations remain explicitly blocked until a verified Titan Command Bus adapter exists; no direct table-write bypass was introduced.
