<?php

return [
    // Keep the live CRM key so existing menu row ID 371 is adopted instead of duplicated.
    'parent' => [
        'key' => 'ext_crm_gear',
        'label' => 'Titan Locker',
        'route' => 'dashboard.user.crm.locker.index',
        'icon' => 'tabler-package',
        'order' => 9,
    ],
    'items' => [
        ['key' => 'crm_locker', 'label' => 'Overview', 'route' => 'dashboard.user.crm.locker.index', 'icon' => 'tabler-layout-dashboard', 'order' => 1],
        ['key' => 'crm_inventory', 'label' => 'Inventory', 'route' => 'dashboard.user.crm.locker.inventory.index', 'icon' => 'tabler-folders', 'order' => 2],
        ['key' => 'crm_stock_locations', 'label' => 'Stock Locations', 'route' => 'dashboard.user.crm.locker.locations.index', 'icon' => 'tabler-map-pin', 'order' => 3],
        ['key' => 'crm_stock_control', 'label' => 'Stock Control', 'route' => 'dashboard.user.crm.locker.stock-control.index', 'icon' => 'tabler-arrows-exchange', 'order' => 4],
        ['key' => 'crm_stock_reservations', 'label' => 'Stock Reservations', 'route' => 'dashboard.user.crm.locker.reservations.index', 'icon' => 'tabler-bookmark', 'order' => 5],
        ['key' => 'crm_reorder', 'label' => 'Reorder', 'route' => 'dashboard.user.crm.locker.reorder.ui', 'icon' => 'tabler-refresh', 'order' => 6],
        ['key' => 'crm_suppliers', 'label' => 'Suppliers', 'route' => 'dashboard.user.crm.locker.suppliers.index', 'icon' => 'tabler-building-store', 'order' => 7],
        ['key' => 'crm_locker_purchase_orders', 'label' => 'Purchase Orders', 'route' => 'dashboard.user.crm.locker.purchase-orders.ui', 'icon' => 'tabler-file-invoice', 'order' => 8],
        ['key' => 'crm_locker_goods_receipts', 'label' => 'Goods Receipts', 'route' => 'dashboard.user.crm.locker.goods-receipts.ui', 'icon' => 'tabler-receipt', 'order' => 9],
        ['key' => 'crm_locker_stock_counts', 'label' => 'Stock Counts', 'route' => 'dashboard.user.crm.locker.stock-counts.ui', 'icon' => 'tabler-checklist', 'order' => 10],
        ['key' => 'crm_locker_stock_transfers', 'label' => 'Stock Transfers', 'route' => 'dashboard.user.crm.locker.stock-transfers.ui', 'icon' => 'tabler-transfer', 'order' => 11],
    ],
];
