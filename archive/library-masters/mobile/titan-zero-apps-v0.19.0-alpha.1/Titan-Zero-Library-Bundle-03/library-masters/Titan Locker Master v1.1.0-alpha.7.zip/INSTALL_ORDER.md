# Installation / Upgrade Order — Option A Assets Convergence

Target host evidence: Titan Extension Manager 1.7.8 and CRM `1.3.0-alpha.17` from the supplied production database dump.

1. Install **Titan Assets v0.2.0-alpha.2** first.
2. Install/upgrade **Titan Locker v1.1.0-alpha.6** second.
3. Run `php artisan optimize:clear` if the host installer does not already clear Laravel caches.
4. Re-open the user navigation so the regenerated menu cache is read.

The Locker package deliberately uses new 2026-08-18 reconciliation migration basenames. The supplied database already records the historical 2026-08-09 Locker migrations, so republishing those names would be unsafe for Installer 1.7.8. Reconciliation migrations are idempotent and every `down()` is data-preserving.
