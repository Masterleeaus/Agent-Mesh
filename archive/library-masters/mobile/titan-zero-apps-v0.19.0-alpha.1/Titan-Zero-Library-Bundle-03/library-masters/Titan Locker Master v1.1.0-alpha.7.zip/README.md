# Titan Locker 1.1.0-alpha.6

Titan Locker is the authoritative **inventory and supplies** domain: inventory/SKUs, stock locations and movements, reservations, job consumption, reorder, suppliers, purchase orders, goods receipts, stock counts and transfers.

Individually tracked tools, equipment, vehicles, custody, maintenance, repairs, warranties, QR operations and lifecycle belong to **Titan Assets >=0.2.0-alpha.2**. Locker intentionally remains small after Option A because duplicate asset implementations were removed rather than copied twice.

Legacy Locker asset routes remain compatibility bridges so existing callers can transition without creating a second write authority.

Install Titan Assets 0.2.0-alpha.2 first, then this package.
