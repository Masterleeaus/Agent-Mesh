# Workforce Runtime Pass 4 — Live Execution Protocol

Provider: `titan-locker`

Added portable live-execution safety primitives: decision-adapter contract, provider health gate, immutable receipt registry contract, idempotency replay protection, governed command envelope and execution coordinator.

Mutation state: **BLOCKED — no verified Command Bus adapter**.

No installation, discovery, health state, cached receipt, retry, or signal may grant authority. `company_id` remains canonical.
