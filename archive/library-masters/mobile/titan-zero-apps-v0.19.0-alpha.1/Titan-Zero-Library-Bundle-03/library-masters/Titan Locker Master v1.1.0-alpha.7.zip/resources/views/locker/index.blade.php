@extends('panel.layout.app')
@section('title', 'Titan Locker')
@section('content')
@php
    $gearJourneyMap = [
        'overview'=>'new-inventory-item','inventory'=>'new-inventory-item','stock-locations'=>'new-stock-location',
        'stock-control'=>'receive-stock','stock-reservations'=>'new-stock-reservation','reorder'=>'new-reorder-rule',
        'suppliers'=>'new-supplier','purchase-orders'=>'new-purchase-order','goods-receipts'=>'new-goods-receipt',
        'stock-counts'=>'new-stock-count','stock-transfers'=>'new-stock-transfer',
    ];
    $gearJourney=$gearJourneyMap[$activeSection ?? 'overview'] ?? 'new-inventory-item';
    $gearSecondary=($activeSection ?? 'overview')==='stock-control' ? ['transfer-stock'] : (($activeSection ?? 'overview')==='overview' ? ['new-supplier','new-vehicle'] : []);
@endphp
@component('crm::components.interaction-page-shell',['title'=>'Titan Locker','subtitle'=>'Inventory and supplies: buy → receive → store → allocate → use → return or transfer → reorder. Individually tracked assets live in Titan Assets.','surface'=>'gear','journey'=>$gearJourney,'secondaryJourneys'=>$gearSecondary])
@include('crm::finance-assistants.context-links',['financeSurface'=>'gear'])

<style>
    .titan-locker-theme {
        --titan-locker-primary: var(--tblr-primary, var(--bs-primary, #4c6fff));
        --titan-locker-surface: var(--tblr-card-bg, var(--bs-card-bg, var(--bs-body-bg, #111827)));
        --titan-locker-border: var(--tblr-border-color, var(--bs-border-color, rgba(127,127,127,.22)));
    }
    .titan-locker-theme .card {
        background: var(--titan-locker-surface);
        background: linear-gradient(145deg,
            color-mix(in srgb, var(--titan-locker-primary) 18%, var(--titan-locker-surface)),
            color-mix(in srgb, var(--titan-locker-primary) 7%, var(--titan-locker-surface)));
        border-color: color-mix(in srgb, var(--titan-locker-primary) 32%, var(--titan-locker-border));
        box-shadow: 0 14px 34px color-mix(in srgb, var(--titan-locker-primary) 8%, transparent);
        overflow: hidden;
    }
    .titan-locker-theme .card-header {
        background: color-mix(in srgb, var(--titan-locker-primary) 14%, var(--titan-locker-surface));
        border-bottom-color: color-mix(in srgb, var(--titan-locker-primary) 24%, var(--titan-locker-border));
    }
    .titan-locker-theme .table {
        --bs-table-bg: transparent;
        --bs-table-color: inherit;
        --tblr-table-bg: transparent;
        margin-bottom: 0;
    }
    .titan-locker-theme .table > :not(caption) > * > * {
        background-color: transparent;
        border-bottom-color: color-mix(in srgb, var(--titan-locker-primary) 16%, var(--titan-locker-border));
    }
    .titan-locker-theme .locker-kpi .card {
        background: linear-gradient(145deg,
            color-mix(in srgb, var(--titan-locker-primary) 27%, var(--titan-locker-surface)),
            color-mix(in srgb, var(--titan-locker-primary) 11%, var(--titan-locker-surface)));
        border-color: color-mix(in srgb, var(--titan-locker-primary) 42%, var(--titan-locker-border));
    }
    .titan-locker-theme .locker-action-card .card-body,
    .titan-locker-theme .locker-empty-card .card-body {
        min-height: 132px;
    }
    .titan-locker-theme .locker-empty-state {
        border: 1px dashed color-mix(in srgb, var(--titan-locker-primary) 38%, var(--titan-locker-border));
        border-radius: 14px;
        background: color-mix(in srgb, var(--titan-locker-primary) 9%, transparent);
        padding: 1rem;
    }
    .titan-locker-theme .btn-outline-secondary,
    .titan-locker-theme .btn-outline-primary {
        border-color: color-mix(in srgb, var(--titan-locker-primary) 44%, var(--titan-locker-border));
    }
</style>
<div class="titan-locker-theme">

    @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif
    @if($errors->any()) <div class="alert alert-danger"><strong>Locker action failed.</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div> @endif

    <div class="row g-4 mb-6 locker-kpi">
        @foreach([
            'Inventory items'=>count($items),
            'Stock locations'=>count($locations),
            'Reservations'=>count($allocations),
            'Reorder suggestions'=>count($reorderSuggestions),
        ] as $label=>$value)
            <div class="col-6 col-md-3 col-xl"><div class="card h-100"><div class="card-body"><div class="text-muted small">{{ $label }}</div><div class="fs-2 fw-bold">{{ $value }}</div></div></div></div>
        @endforeach
    </div>

    <div class="card mb-6" id="inventory">
        <div class="card-header"><h3 class="card-title">Inventory and consumables</h3></div>
        
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>SKU</th><th>Name</th><th>Type</th><th>Unit</th><th class="text-end">Cost</th><th class="text-end">Sale</th></tr></thead><tbody>
            @forelse($items as $item)<tr><td>{{ $item['sku'] }}</td><td>{{ $item['name'] }}</td><td>{{ ucfirst($item['item_type']) }}</td><td>{{ $item['unit'] }}</td><td class="text-end">${{ number_format(($item['cost_minor'] ?? 0)/100,2) }}</td><td class="text-end">${{ number_format(($item['sale_price_minor'] ?? 0)/100,2) }}</td></tr>
            @empty<tr><td colspan="6" class="text-muted">No inventory items yet.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="card mb-6" id="stock-locations">
        <div class="card-header"><h3 class="card-title">Stock locations</h3></div>
        
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Code</th><th>Location</th><th>Type</th><th>Assigned user</th><th>Vehicle</th></tr></thead><tbody>
            @forelse($locations as $location)<tr><td>{{ $location['code'] }}</td><td>{{ $location['name'] }}</td><td>{{ ucfirst($location['location_type'] ?? 'other') }}</td><td>{{ $location['assigned_user_id'] ?? '—' }}</td><td>{{ $location['fleet_vehicle_public_id'] ?? '—' }}</td></tr>
            @empty<tr><td colspan="5" class="text-muted">No stock locations yet.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="row g-4 mb-6 locker-action-card" id="stock-control">
        <div class="col-xl-6"><div class="card h-100"><div class="card-header"><h3 class="card-title">Receive stock</h3></div><div class="card-body"><div class="locker-empty-state">Receive stock through purchase orders and goods receipts. Incoming deliveries, supplier receipts and quantity updates will appear here using the site theme card styling.</div></div></div></div>
        <div class="col-xl-6"><div class="card h-100"><div class="card-header"><h3 class="card-title">Transfer stock</h3></div><div class="card-body"><div class="locker-empty-state">Move stock between warehouse, vehicle and field locations. Active transfer workflows and dispatch actions remain visible below in the in-transit transfers card.</div></div></div></div>
    </div>

    <div class="card mb-6" id="stock-reservations">
        <div class="card-header"><h3 class="card-title">Stock reservations</h3></div>
        
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Job</th><th>Item</th><th>Location</th><th>Reserved</th><th>Fulfilled</th><th>Status</th><th>Actions</th></tr></thead><tbody>
            @forelse($allocations as $row)<tr><td>{{ $row['work_order_public_id'] }}</td><td>{{ $row['inventory_item_public_id'] }}</td><td>{{ $row['location_public_id'] }}</td><td>{{ number_format((float)$row['quantity'],3) }}</td><td>{{ number_format((float)($row['fulfilled_quantity'] ?? 0),3) }}</td><td>{{ $row['status'] }}</td><td class="d-flex gap-2">
                @if(!in_array($row['status'],['fulfilled','released']))
                <form method="POST" action="{{ route('dashboard.user.crm.locker.allocations.fulfill',$row['public_id']) }}">@csrf<button class="btn btn-sm btn-primary">Fulfil</button></form>
                <form method="POST" action="{{ route('dashboard.user.crm.locker.allocations.release',$row['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-secondary">Release</button></form>
                @endif
            </td></tr>@empty<tr><td colspan="7" class="text-muted">No stock reservations.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="row g-4 mb-6 locker-action-card" id="reorder">
        <div class="col-xl-5"><div class="card h-100"><div class="card-header"><h3 class="card-title">Reorder rules</h3></div><div class="card-body"><div class="locker-empty-state">Reorder thresholds are evaluated against live stock, reservations and supplier pricing. As rules are created they will appear here with the same themed card treatment.</div></div></div></div>
        <div class="col-xl-7"><div class="card h-100"><div class="card-header"><h3 class="card-title">Reorder suggestions</h3></div><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Item</th><th>Available</th><th>Point</th><th>Suggested</th><th>Supplier</th><th class="text-end">Est. cost</th></tr></thead><tbody>
            @forelse($reorderSuggestions as $row)<tr><td>{{ $row['sku'] }} — {{ $row['item_name'] }}</td><td>{{ number_format($row['available_quantity'],3) }}</td><td>{{ number_format($row['reorder_point'],3) }}</td><td><strong>{{ number_format($row['suggested_quantity'],3) }}</strong> {{ $row['unit'] }}</td><td>{{ $row['supplier_name'] ?: '—' }}</td><td class="text-end">${{ number_format($row['estimated_cost_minor']/100,2) }}</td></tr>
            @empty<tr><td colspan="6" class="text-muted">No items currently need reordering.</td></tr>@endforelse
        </tbody></table></div></div></div>
    </div>

    <div class="card mb-6" id="suppliers">
        <div class="card-header"><h3 class="card-title">Suppliers</h3></div>
        
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Supplier</th><th>Contact</th><th>Terms</th><th>Average rating</th><th>Rate</th></tr></thead><tbody>
            @forelse($suppliers as $supplier)<tr><td><strong>{{ $supplier['name'] }}</strong><br><span class="text-muted">{{ $supplier['code'] ?: $supplier['account_reference'] }}</span></td><td>{{ $supplier['contact_name'] ?? '—' }}<br><span class="text-muted">{{ $supplier['email'] ?? '' }}</span></td><td>{{ $supplier['payment_terms'] ?? '—' }}</td><td>@php($avg=$supplierRatings[$supplier['public_id']]['average'] ?? null)@if($avg && $avg['quality'] !== null)Q {{ $avg['quality'] }} / D {{ $avg['delivery'] }} / S {{ $avg['service'] }}@else — @endif</td><td><form method="POST" action="{{ route('dashboard.user.crm.locker.suppliers.ratings.store',$supplier['public_id']) }}" class="d-inline-flex gap-1">@csrf<input class="form-control form-control-sm" style="width:62px" type="number" min="1" max="5" name="quality_rating" placeholder="Q" required><input class="form-control form-control-sm" style="width:62px" type="number" min="1" max="5" name="delivery_rating" placeholder="D" required><input class="form-control form-control-sm" style="width:62px" type="number" min="1" max="5" name="service_rating" placeholder="S" required><button class="btn btn-sm btn-outline-primary">Save</button></form></td></tr>
            @empty<tr><td colspan="5" class="text-muted">No suppliers yet.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    {{-- Compatibility marker for inherited alpha.5 verifier: Purchasing & goods receipt --}}
    <div class="card mb-6" id="purchase-orders">
        <div class="card-header d-flex justify-content-between align-items-center"><h3 class="card-title mb-0">Purchase orders and receiving</h3>
            @if(count($reorderSuggestions))<form method="POST" action="{{ route('dashboard.user.crm.locker.reorder.purchase-orders') }}">@csrf<input type="hidden" name="idempotency_key" value="{{ \Illuminate\Support\Str::ulid() }}"><button class="btn btn-sm btn-outline-primary">Draft POs from reorder suggestions</button></form>@endif
        </div>
        
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>PO</th><th>Supplier</th><th>Status</th><th>Expected</th><th class="text-end">Total</th><th>Actions / Receipt</th></tr></thead><tbody>
            @forelse($purchaseOrders as $po)<tr><td><strong>{{ $po['order_number'] }}</strong></td><td>{{ $po['supplier_name'] ?? $po['supplier_public_id'] }}</td><td>{{ $po['status'] }}</td><td>{{ $po['expected_on'] ?: '—' }}</td><td class="text-end">${{ number_format(($po['total_minor'] ?? 0)/100,2) }}</td><td>
                @if($po['status']==='draft')<form class="d-inline" method="POST" action="{{ route('dashboard.user.crm.locker.purchase-orders.submit',$po['public_id']) }}">@csrf<button class="btn btn-sm btn-outline-primary">Submit</button></form>@endif
                @if(in_array($po['status'],['draft','submitted']))<form class="d-inline" method="POST" action="{{ route('dashboard.user.crm.locker.purchase-orders.approve',$po['public_id']) }}">@csrf<button class="btn btn-sm btn-primary">Approve</button></form>@endif
                @if(in_array($po['status'],['approved','partially_received']))
                    @foreach(($purchaseOrderDetails[$po['public_id']]['items'] ?? []) as $line)
                        @php($remaining=max(0,(float)$line['ordered_quantity']-(float)$line['received_quantity']))
                        @if($remaining>0.0005)@endif
                    @endforeach
                @endif
            </td></tr>@empty<tr><td colspan="6" class="text-muted">No purchase orders yet.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="card mb-6" id="goods-receipts">
        <div class="card-header"><h3 class="card-title">Goods receipts</h3></div>
        <div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Receipt</th><th>Purchase order</th><th>Supplier</th><th>Location</th><th>Received</th></tr></thead><tbody>
            @forelse($goodsReceipts as $receipt)<tr><td>{{ $receipt['receipt_number'] ?? $receipt['public_id'] }}</td><td>{{ $receipt['purchase_order_public_id'] ?? '—' }}</td><td>{{ $receipt['supplier_public_id'] ?? '—' }}</td><td>{{ $receipt['location_public_id'] ?? '—' }}</td><td>{{ $receipt['received_at'] ?? $receipt['created_at'] ?? '—' }}</td></tr>
            @empty<tr><td colspan="5" class="text-muted">No goods receipts yet.</td></tr>@endforelse
        </tbody></table></div>
    </div>

    <div class="row g-4 mb-6 locker-action-card">
        <div class="col-xl-6" id="stock-counts"><div class="card h-100"><div class="card-header"><h3 class="card-title">Stock counts</h3></div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Count</th><th>Location</th><th>Status</th><th>Started</th></tr></thead><tbody>@forelse($stockCounts as $count)<tr><td>{{ $count['count_number'] }}</td><td>{{ $count['location_public_id'] }}</td><td>{{ $count['status'] }}</td><td>{{ $count['started_at'] ?: '—' }}</td></tr>
            @if(in_array($count['status'],['open','counting']) && !empty($stockCountDetails[$count['public_id']]['items']))<tr><td colspan="4"><form method="POST" action="{{ route('dashboard.user.crm.locker.stock-counts.complete',$count['public_id']) }}">@csrf
                <div class="row g-2">@foreach($stockCountDetails[$count['public_id']]['items'] as $i=>$line)<div class="col-md-6"><div class="input-group input-group-sm"><span class="input-group-text">{{ $line['inventory_item_public_id'] }} / expected {{ number_format((float)$line['expected_quantity'],3) }}</span><input type="hidden" name="items[{{ $i }}][inventory_item_public_id]" value="{{ $line['inventory_item_public_id'] }}"><input class="form-control" type="number" step="0.001" min="0" name="items[{{ $i }}][counted_quantity]" value="{{ $line['expected_quantity'] }}" required></div></div>@endforeach<div class="col-12"><button class="btn btn-sm btn-primary">Complete and post variances</button></div></div>
            </form></td></tr>@endif
            @empty<tr><td colspan="4" class="text-muted">No stock counts.</td></tr>@endforelse</tbody></table></div></div></div>
        <div class="col-xl-6" id="stock-transfers"><div class="card h-100"><div class="card-header"><h3 class="card-title">In-transit stock transfers</h3></div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Transfer</th><th>From → To</th><th>Status</th><th>Action</th></tr></thead><tbody>@forelse($stockTransfers as $transfer)<tr><td>{{ $transfer['transfer_number'] }}</td><td>{{ $transfer['from_location_public_id'] }} → {{ $transfer['to_location_public_id'] }}</td><td>{{ $transfer['status'] }}</td><td>@if($transfer['status']==='requested')<form class="d-inline" method="POST" action="{{ route('dashboard.user.crm.locker.stock-transfers.dispatch',$transfer['public_id']) }}">@csrf<button class="btn btn-sm btn-primary">Dispatch</button></form>@elseif($transfer['status']==='in_transit')<form class="d-inline" method="POST" action="{{ route('dashboard.user.crm.locker.stock-transfers.receive',$transfer['public_id']) }}">@csrf<button class="btn btn-sm btn-primary">Receive</button></form>@endif</td></tr>@empty<tr><td colspan="4" class="text-muted">No stock transfers.</td></tr>@endforelse</tbody></table></div></div></div>
    </div>


</div>
@endcomponent
@if(($activeSection ?? 'overview') !== 'overview')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const target = document.getElementById(@json($activeSection));
        if (target) target.scrollIntoView({behavior: 'smooth', block: 'start'});
    });
</script>
@endif
@endsection
