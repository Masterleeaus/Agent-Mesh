<?php

declare(strict_types=1);

use App\Extensions\TitanLocker\System\Http\Controllers\LockerController;
use App\Http\Middleware\CheckTemplateTypeAndPlan;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmHostEnabled;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use Illuminate\Support\Facades\Route;

Route::middleware(array_merge(config('crm.middleware', ['web','auth']), [EnsureCrmHostEnabled::class, CheckTemplateTypeAndPlan::class]))
    ->prefix('dashboard/user/crm')
    ->name('dashboard.user.crm.')
    ->group(function (): void {
        Route::get('/locker', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.index');
        Route::get('/locker/inventory', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.inventory.index');
        Route::get('/locker/locations', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.locations.index');
        Route::get('/locker/stock-control', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-control.index');
        Route::get('/locker/reservations', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.reservations.index');
        Route::get('/locker/reorder/manage', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.reorder.ui');
        Route::get('/locker/suppliers', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.suppliers.index');
        Route::get('/locker/purchase-orders/manage', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.purchase-orders.ui');
        Route::get('/locker/goods-receipts/manage', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.goods-receipts.ui');
        Route::get('/locker/stock-counts/manage', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-counts.ui');
        Route::get('/locker/stock-transfers/manage', [LockerController::class, 'index'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-transfers.ui');
        Route::get('/locker/tools', fn () => redirect()->route('titan-assets.tools'))->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.tools.index');
        Route::get('/locker/equipment', fn () => redirect()->route('titan-assets.equipment'))->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.equipment.index');
        Route::get('/locker/fleet', fn () => redirect()->route('titan-assets.fleet'))->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.fleet.index');
        Route::get('/locker/maintenance', fn () => redirect()->route('titan-assets.maintenance'))->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.maintenance.index');
        Route::post('/locker/items', [LockerController::class, 'createItem'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.items.store');
        Route::post('/locker/locations', [LockerController::class, 'createLocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.locations.store');
        Route::post('/locker/suppliers', [LockerController::class, 'createSupplier'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.suppliers.store');
        Route::post('/locker/stock/receive', [LockerController::class, 'receive'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.stock.receive');
        Route::post('/locker/stock/transfer', [LockerController::class, 'transfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.stock.transfer');
        Route::post('/locker/allocations', [LockerController::class, 'reserveAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.store');
        Route::post('/locker/allocations/{allocation}/release', [LockerController::class, 'releaseAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.release');
        Route::post('/locker/allocations/{allocation}/fulfill', [LockerController::class, 'fulfillAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.fulfill');
        Route::post('/locker/reorder', [LockerController::class, 'upsertReorderRule'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.reorder.store');
        Route::get('/locker/purchase-orders', [LockerController::class, 'purchaseOrderIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.purchase-orders.index');
        Route::post('/locker/purchase-orders', [LockerController::class, 'createPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.store');
        Route::post('/locker/purchase-orders/{purchaseOrder}/submit', [LockerController::class, 'submitPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.submit');
        Route::post('/locker/purchase-orders/{purchaseOrder}/approve', [LockerController::class, 'approvePurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.approve');
        Route::post('/locker/purchase-orders/{purchaseOrder}/cancel', [LockerController::class, 'cancelPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.cancel');
        Route::post('/locker/suppliers/{supplier}/ratings', [LockerController::class, 'rateSupplier'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.suppliers.ratings.store');
        Route::get('/locker/goods-receipts', [LockerController::class, 'goodsReceiptIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.goods-receipts.index');
        Route::post('/locker/goods-receipts', [LockerController::class, 'receiveGoods'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.goods-receipts.store');
        Route::get('/locker/stock-counts', [LockerController::class, 'stockCountIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-counts.index');
        Route::post('/locker/stock-counts', [LockerController::class, 'createStockCount'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock_counts.manage')->name('locker.stock-counts.store');
        Route::post('/locker/stock-counts/{stockCount}/complete', [LockerController::class, 'completeStockCount'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock_counts.manage')->name('locker.stock-counts.complete');
        Route::get('/locker/stock-transfers', [LockerController::class, 'stockTransferIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-transfers.index');
        Route::post('/locker/stock-transfers', [LockerController::class, 'createStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.store');
        Route::post('/locker/stock-transfers/{stockTransfer}/dispatch', [LockerController::class, 'dispatchStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.dispatch');
        Route::post('/locker/stock-transfers/{stockTransfer}/receive', [LockerController::class, 'receiveStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.receive');
        Route::post('/locker/stock-transfers/{stockTransfer}/cancel', [LockerController::class, 'cancelStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.cancel');
        Route::post('/locker/reorder/purchase-orders', [LockerController::class, 'draftReorderPurchaseOrders'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.reorder.purchase-orders');
        Route::post('/locker/assets/{type}', [LockerController::class, 'createAsset'])->whereIn('type',['tool','equipment','vehicle'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.assets.store');
        Route::post('/locker/tools/{tool}/checkout', [LockerController::class, 'checkoutTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.checkout');
        Route::post('/locker/tools/{tool}/return', [LockerController::class, 'returnTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.return');
        Route::post('/locker/tools/{tool}/damage', [LockerController::class, 'damageTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.damage');
        Route::post('/locker/tools/{tool}/lost', [LockerController::class, 'lostTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.lost');
        Route::post('/locker/fleet/{vehicle}/assign', [LockerController::class, 'assignFleet'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.assign');
        Route::post('/locker/fleet/{vehicle}/unassign', [LockerController::class, 'unassignFleet'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.unassign');
        Route::post('/locker/fleet/{vehicle}/odometer', [LockerController::class, 'updateFleetOdometer'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.odometer');
        Route::post('/locker/fleet/{vehicle}/status', [LockerController::class, 'updateFleetStatus'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.status');
        Route::post('/locker/assets/{type}/{asset}/maintenance', [LockerController::class, 'scheduleMaintenance'])->whereIn('type',['tool','equipment','vehicle'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.store');
        Route::post('/locker/maintenance/{maintenance}/complete', [LockerController::class, 'completeMaintenance'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.complete');
        Route::post('/locker/maintenance/{maintenance}/cancel', [LockerController::class, 'cancelMaintenance'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.cancel');
    });
