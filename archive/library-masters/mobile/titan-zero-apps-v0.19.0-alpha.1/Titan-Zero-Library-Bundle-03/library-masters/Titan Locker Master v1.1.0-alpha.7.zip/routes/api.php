<?php

declare(strict_types=1);

use App\Extensions\TitanLocker\System\Http\Controllers\LockerController;
use App\Extensions\Crm\System\Http\Middleware\EnsureCrmPermission;
use Illuminate\Support\Facades\Route;

Route::middleware(config('crm.api_middleware', ['api', 'auth:api']))
    ->prefix('api/crm')
    ->name('api.crm.')
    ->group(function (): void {
        Route::get('/locker/overview', [LockerController::class, 'overview'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.overview');
        Route::post('/locker/items', [LockerController::class, 'createItem'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.items.store');
        Route::post('/locker/locations', [LockerController::class, 'createLocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.locations.store');
        Route::post('/locker/suppliers', [LockerController::class, 'createSupplier'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.suppliers.store');
        Route::post('/locker/stock/receive', [LockerController::class, 'receive'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.stock.receive');
        Route::post('/locker/stock/transfer', [LockerController::class, 'transfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.stock.transfer');
        Route::post('/locker/jobs/{workOrder}/consume', [LockerController::class, 'consumeJob'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.jobs.consume');
        Route::post('/locker/assets/{type}', [LockerController::class, 'createAsset'])->whereIn('type',['tool','equipment','vehicle'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.assets.store');
        Route::post('/locker/assets/{type}/{asset}/maintenance', [LockerController::class, 'scheduleMaintenance'])->whereIn('type',['tool','equipment','vehicle'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.store');
        Route::post('/locker/maintenance/{maintenance}/complete', [LockerController::class, 'completeMaintenance'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.complete');
        Route::get('/locker/stock/available', [LockerController::class, 'availableStock'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock.available');
        Route::get('/locker/allocations', [LockerController::class, 'allocationIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.allocations.index');
        Route::post('/locker/allocations', [LockerController::class, 'reserveAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.store');
        Route::post('/locker/allocations/{allocation}/release', [LockerController::class, 'releaseAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.release');
        Route::post('/locker/allocations/{allocation}/fulfill', [LockerController::class, 'fulfillAllocation'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock.manage')->name('locker.allocations.fulfill');
        Route::get('/locker/reorder', [LockerController::class, 'reorderIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.reorder.index');
        Route::post('/locker/reorder', [LockerController::class, 'upsertReorderRule'])->middleware(EnsureCrmPermission::class . ':crm.locker.manage')->name('locker.reorder.store');
        Route::get('/locker/purchase-orders', [LockerController::class, 'purchaseOrderIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.purchase-orders.index');
        Route::post('/locker/purchase-orders', [LockerController::class, 'createPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.store');
        Route::post('/locker/purchase-orders/{purchaseOrder}/submit', [LockerController::class, 'submitPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.submit');
        Route::post('/locker/purchase-orders/{purchaseOrder}/approve', [LockerController::class, 'approvePurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.approve');
        Route::post('/locker/purchase-orders/{purchaseOrder}/cancel', [LockerController::class, 'cancelPurchaseOrder'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.purchase-orders.cancel');
        Route::post('/locker/suppliers/{supplier}/ratings', [LockerController::class, 'rateSupplier'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.suppliers.ratings.store');
        Route::get('/locker/goods-receipts', [LockerController::class, 'goodsReceiptIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.goods-receipts.index');
        Route::post('/locker/goods-receipts', [LockerController::class, 'receiveGoods'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.goods-receipts.store');
        Route::get('/locker/stock-counts', [LockerController::class, 'stockCountIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-counts.index');
        Route::post('/locker/stock-counts', [LockerController::class, 'createStockCount'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock_counts.manage')->name('locker.stock-counts.store');
        Route::post('/locker/stock-counts/{stockCount}/complete', [LockerController::class, 'completeStockCount'])->middleware(EnsureCrmPermission::class . ':crm.locker.stock_counts.manage')->name('locker.stock-counts.complete');
        Route::get('/locker/stock-transfers', [LockerController::class, 'stockTransferIndex'])->middleware(EnsureCrmPermission::class . ':crm.locker.view')->name('locker.stock-transfers.index');
        Route::post('/locker/stock-transfers', [LockerController::class, 'createStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.store');
        Route::post('/locker/stock-transfers/{stockTransfer}/dispatch', [LockerController::class, 'dispatchStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.dispatch');
        Route::post('/locker/stock-transfers/{stockTransfer}/receive', [LockerController::class, 'receiveStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.receive');
        Route::post('/locker/stock-transfers/{stockTransfer}/cancel', [LockerController::class, 'cancelStockTransfer'])->middleware(EnsureCrmPermission::class . ':crm.locker.transfers.manage')->name('locker.stock-transfers.cancel');
        Route::post('/locker/reorder/purchase-orders', [LockerController::class, 'draftReorderPurchaseOrders'])->middleware(EnsureCrmPermission::class . ':crm.locker.purchasing.manage')->name('locker.reorder.purchase-orders');
        Route::post('/locker/tools/{tool}/checkout', [LockerController::class, 'checkoutTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.checkout');
        Route::post('/locker/tools/{tool}/return', [LockerController::class, 'returnTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.return');
        Route::post('/locker/tools/{tool}/damage', [LockerController::class, 'damageTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.damage');
        Route::post('/locker/tools/{tool}/lost', [LockerController::class, 'lostTool'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.tools.lost');
        Route::post('/locker/fleet/{vehicle}/assign', [LockerController::class, 'assignFleet'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.assign');
        Route::post('/locker/fleet/{vehicle}/unassign', [LockerController::class, 'unassignFleet'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.unassign');
        Route::post('/locker/fleet/{vehicle}/odometer', [LockerController::class, 'updateFleetOdometer'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.odometer');
        Route::post('/locker/fleet/{vehicle}/status', [LockerController::class, 'updateFleetStatus'])->middleware(EnsureCrmPermission::class . ':crm.locker.fleet.manage')->name('locker.fleet.status');
        Route::post('/locker/maintenance/{maintenance}/cancel', [LockerController::class, 'cancelMaintenance'])->middleware(EnsureCrmPermission::class . ':crm.locker.assets.manage')->name('locker.maintenance.cancel');
    });
