<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** Wave 1C: company_id is the sole Titan tenant/company boundary. */
    public function up(): void
    {
        foreach ($this->tables() as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'tenant_company_id')) continue;
            if (Schema::hasColumn($table, 'company_id')) {
                throw new RuntimeException("Wave 1C cannot canonicalize {$table}: both tenant_company_id and company_id exist; semantic review required.");
            }
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('tenant_company_id', 'company_id');
            });
        }
    }

    public function down(): void
    {
        foreach (array_reverse($this->tables()) as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id') || Schema::hasColumn($table, 'tenant_company_id')) continue;
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('company_id', 'tenant_company_id');
            });
        }
    }

    /** @return list<string> */
    private function tables(): array
    {
        return [
            'crm_locker_asset_events',
            'crm_locker_equipment',
            'crm_locker_fleet_vehicles',
            'crm_locker_goods_receipt_items',
            'crm_locker_goods_receipts',
            'crm_locker_inventory_items',
            'crm_locker_maintenance_records',
            'crm_locker_purchase_order_items',
            'crm_locker_purchase_orders',
            'crm_locker_reorder_rules',
            'crm_locker_stock_allocations',
            'crm_locker_stock_count_items',
            'crm_locker_stock_counts',
            'crm_locker_stock_locations',
            'crm_locker_stock_movements',
            'crm_locker_stock_transfer_items',
            'crm_locker_stock_transfers',
            'crm_locker_supplier_ratings',
            'crm_locker_suppliers',
            'crm_locker_tools'
        ];
    }
};
