<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_locker_stock_allocations')) {
            Schema::table('crm_locker_stock_allocations', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'idempotency_key')) $t->string('idempotency_key', 160)->nullable();
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'fulfilled_quantity')) $t->decimal('fulfilled_quantity', 14, 3)->default(0);
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'released_at')) $t->dateTime('released_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'fulfilled_at')) $t->dateTime('fulfilled_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'updated_by_user_id')) $t->unsignedBigInteger('updated_by_user_id')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'source_type')) $t->string('source_type', 80)->nullable()->index();
                if (! Schema::hasColumn('crm_locker_stock_allocations', 'source_public_id')) $t->char('source_public_id', 26)->nullable()->index();
            });
            try { Schema::table('crm_locker_stock_allocations', fn (Blueprint $t) => $t->unique(['company_id', 'idempotency_key'], 'crm_locker_allocation_idempotency_unique')); } catch (\Throwable) {}
        }

        if (Schema::hasTable('crm_locker_tools')) {
            Schema::table('crm_locker_tools', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_tools', 'due_back_at')) $t->dateTime('due_back_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_tools', 'checked_out_at')) $t->dateTime('checked_out_at')->nullable()->index();
            });
        }

        if (Schema::hasTable('crm_locker_fleet_vehicles')) {
            Schema::table('crm_locker_fleet_vehicles', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_fleet_vehicles', 'assigned_at')) $t->dateTime('assigned_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_fleet_vehicles', 'last_odometer_at')) $t->dateTime('last_odometer_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_fleet_vehicles', 'next_service_odometer_km')) $t->unsignedBigInteger('next_service_odometer_km')->nullable()->index();
            });
        }

        if (Schema::hasTable('crm_locker_maintenance_records')) {
            Schema::table('crm_locker_maintenance_records', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_maintenance_records', 'next_due_on')) $t->date('next_due_on')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_maintenance_records', 'next_due_odometer_km')) $t->unsignedBigInteger('next_due_odometer_km')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_maintenance_records', 'cancelled_at')) $t->dateTime('cancelled_at')->nullable()->index();
                if (! Schema::hasColumn('crm_locker_maintenance_records', 'cancel_reason')) $t->string('cancel_reason', 255)->nullable();
            });
        }

        if (Schema::hasTable('crm_locker_reorder_rules')) {
            Schema::table('crm_locker_reorder_rules', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_reorder_rules', 'supplier_lead_days')) $t->unsignedSmallInteger('supplier_lead_days')->default(0);
                if (! Schema::hasColumn('crm_locker_reorder_rules', 'updated_by_user_id')) $t->unsignedBigInteger('updated_by_user_id')->nullable()->index();
            });
        }
    }

    public function down(): void
    {
        // Option A convergence is data-preserving: never remove existing Locker or migrated asset state.
    }
};
