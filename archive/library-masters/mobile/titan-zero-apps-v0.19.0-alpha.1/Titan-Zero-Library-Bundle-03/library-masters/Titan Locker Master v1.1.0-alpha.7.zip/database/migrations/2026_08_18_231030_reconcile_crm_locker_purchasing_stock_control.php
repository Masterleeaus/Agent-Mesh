<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('crm_locker_suppliers')) {
            Schema::table('crm_locker_suppliers', function (Blueprint $t): void {
                if (! Schema::hasColumn('crm_locker_suppliers', 'contact_name')) $t->string('contact_name', 160)->nullable();
                if (! Schema::hasColumn('crm_locker_suppliers', 'tax_identifier')) $t->string('tax_identifier', 80)->nullable();
                if (! Schema::hasColumn('crm_locker_suppliers', 'payment_terms')) $t->string('payment_terms', 120)->nullable();
                if (! Schema::hasColumn('crm_locker_suppliers', 'currency')) $t->char('currency', 3)->default('AUD');
                if (! Schema::hasColumn('crm_locker_suppliers', 'address')) $t->text('address')->nullable();
                if (! Schema::hasColumn('crm_locker_suppliers', 'capabilities')) $t->json('capabilities')->nullable();
            });
        }

        if (! Schema::hasTable('crm_locker_supplier_ratings')) {
            Schema::create('crm_locker_supplier_ratings', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_sup_rating_tenant_idx');
                $t->char('supplier_public_id',26)->index('crm_sup_rating_supplier_idx');
                $t->unsignedTinyInteger('quality_rating'); $t->unsignedTinyInteger('delivery_rating'); $t->unsignedTinyInteger('service_rating');
                $t->text('notes')->nullable(); $t->unsignedBigInteger('rated_by_user_id')->nullable()->index('crm_sup_rating_actor_idx');
                $t->dateTime('rated_at')->index('crm_sup_rating_at_idx'); $t->timestamps();
                $t->index(['company_id','supplier_public_id','rated_at'],'crm_sup_rating_timeline_idx');
            });
        }

        if (! Schema::hasTable('crm_locker_purchase_orders')) {
            Schema::create('crm_locker_purchase_orders', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_po_tenant_idx');
                $t->char('supplier_public_id',26)->index('crm_po_supplier_idx'); $t->char('delivery_location_public_id',26)->nullable()->index('crm_po_location_idx');
                $t->string('order_number',100); $t->string('status',40)->default('draft')->index('crm_po_status_idx'); $t->char('currency',3)->default('AUD');
                $t->date('ordered_on')->nullable()->index('crm_po_ordered_idx'); $t->date('expected_on')->nullable()->index('crm_po_expected_idx');
                $t->bigInteger('subtotal_minor')->default(0); $t->bigInteger('gst_minor')->default(0); $t->bigInteger('total_minor')->default(0);
                $t->string('supplier_reference',160)->nullable(); $t->text('notes')->nullable(); $t->string('idempotency_key',160)->nullable();
                $t->unsignedBigInteger('created_by_user_id')->nullable()->index('crm_po_creator_idx'); $t->unsignedBigInteger('submitted_by_user_id')->nullable(); $t->unsignedBigInteger('approved_by_user_id')->nullable(); $t->unsignedBigInteger('cancelled_by_user_id')->nullable();
                $t->dateTime('submitted_at')->nullable(); $t->dateTime('approved_at')->nullable(); $t->dateTime('cancelled_at')->nullable();
                $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','order_number'],'crm_po_number_unique');
                $t->unique(['company_id','idempotency_key'],'crm_po_idem_unique');
            });
        }

        if (! Schema::hasTable('crm_locker_purchase_order_items')) {
            Schema::create('crm_locker_purchase_order_items', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_po_item_tenant_idx');
                $t->char('purchase_order_public_id',26)->index('crm_po_item_po_idx'); $t->char('inventory_item_public_id',26)->nullable()->index('crm_po_item_inventory_idx');
                $t->string('description',255); $t->decimal('ordered_quantity',14,3); $t->decimal('received_quantity',14,3)->default(0);
                $t->bigInteger('unit_cost_minor'); $t->decimal('gst_rate',6,3)->default(0); $t->bigInteger('line_ex_gst_minor'); $t->bigInteger('gst_minor'); $t->bigInteger('line_total_minor');
                $t->json('metadata')->nullable(); $t->timestamps();
                $t->index(['company_id','purchase_order_public_id','inventory_item_public_id'],'crm_po_item_lookup_idx');
            });
        }

        if (! Schema::hasTable('crm_locker_goods_receipts')) {
            Schema::create('crm_locker_goods_receipts', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_gr_tenant_idx');
                $t->char('purchase_order_public_id',26)->nullable()->index('crm_gr_po_idx'); $t->char('supplier_public_id',26)->nullable()->index('crm_gr_supplier_idx');
                $t->char('location_public_id',26)->index('crm_gr_location_idx'); $t->string('receipt_number',100); $t->string('supplier_delivery_reference',160)->nullable();
                $t->dateTime('received_at')->index('crm_gr_received_idx'); $t->unsignedBigInteger('received_by_user_id')->nullable()->index('crm_gr_actor_idx');
                $t->string('idempotency_key',160)->nullable(); $t->text('notes')->nullable(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','receipt_number'],'crm_gr_number_unique'); $t->unique(['company_id','idempotency_key'],'crm_gr_idem_unique');
            });
        }

        if (! Schema::hasTable('crm_locker_goods_receipt_items')) {
            Schema::create('crm_locker_goods_receipt_items', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_gr_item_tenant_idx');
                $t->char('goods_receipt_public_id',26)->index('crm_gr_item_receipt_idx'); $t->char('purchase_order_item_public_id',26)->nullable()->index('crm_gr_item_po_line_idx');
                $t->char('inventory_item_public_id',26)->index('crm_gr_item_inventory_idx'); $t->decimal('received_quantity',14,3); $t->bigInteger('unit_cost_minor');
                $t->char('stock_movement_public_id',26)->nullable()->index('crm_gr_item_move_idx'); $t->json('metadata')->nullable(); $t->timestamps();
            });
        }

        if (! Schema::hasTable('crm_locker_stock_counts')) {
            Schema::create('crm_locker_stock_counts', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_count_tenant_idx');
                $t->char('location_public_id',26)->index('crm_count_location_idx'); $t->string('count_number',100); $t->string('count_type',40)->default('cycle')->index('crm_count_type_idx');
                $t->string('status',40)->default('open')->index('crm_count_status_idx'); $t->string('idempotency_key',160)->nullable(); $t->dateTime('scheduled_at')->nullable(); $t->dateTime('started_at')->nullable(); $t->dateTime('completed_at')->nullable();
                $t->unsignedBigInteger('counted_by_user_id')->nullable(); $t->unsignedBigInteger('approved_by_user_id')->nullable(); $t->text('notes')->nullable(); $t->timestamps();
                $t->unique(['company_id','count_number'],'crm_count_number_unique'); $t->unique(['company_id','idempotency_key'],'crm_count_idem_unique');
            });
        }

        if (! Schema::hasTable('crm_locker_stock_count_items')) {
            Schema::create('crm_locker_stock_count_items', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_count_item_tenant_idx');
                $t->char('stock_count_public_id',26)->index('crm_count_item_count_idx'); $t->char('inventory_item_public_id',26)->index('crm_count_item_inventory_idx');
                $t->decimal('expected_quantity',14,3); $t->decimal('counted_quantity',14,3)->nullable(); $t->decimal('variance_quantity',14,3)->nullable();
                $t->string('variance_reason',255)->nullable(); $t->char('adjustment_movement_public_id',26)->nullable()->index('crm_count_item_adjust_idx'); $t->timestamps();
                $t->unique(['company_id','stock_count_public_id','inventory_item_public_id'],'crm_count_item_unique');
            });
        }

        if (! Schema::hasTable('crm_locker_stock_transfers')) {
            Schema::create('crm_locker_stock_transfers', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_xfer_tenant_idx');
                $t->string('transfer_number',100); $t->char('from_location_public_id',26)->index('crm_xfer_from_idx'); $t->char('to_location_public_id',26)->index('crm_xfer_to_idx');
                $t->string('status',40)->default('requested')->index('crm_xfer_status_idx'); $t->dateTime('requested_at')->index('crm_xfer_requested_idx'); $t->dateTime('dispatched_at')->nullable(); $t->dateTime('received_at')->nullable(); $t->dateTime('cancelled_at')->nullable();
                $t->unsignedBigInteger('requested_by_user_id')->nullable(); $t->unsignedBigInteger('dispatched_by_user_id')->nullable(); $t->unsignedBigInteger('received_by_user_id')->nullable(); $t->unsignedBigInteger('cancelled_by_user_id')->nullable();
                $t->string('idempotency_key',160)->nullable(); $t->text('notes')->nullable(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','transfer_number'],'crm_xfer_number_unique'); $t->unique(['company_id','idempotency_key'],'crm_xfer_idem_unique');
            });
        }

        if (! Schema::hasTable('crm_locker_stock_transfer_items')) {
            Schema::create('crm_locker_stock_transfer_items', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index('crm_xfer_item_tenant_idx');
                $t->char('stock_transfer_public_id',26)->index('crm_xfer_item_transfer_idx'); $t->char('inventory_item_public_id',26)->index('crm_xfer_item_inventory_idx');
                $t->decimal('requested_quantity',14,3); $t->decimal('dispatched_quantity',14,3)->default(0); $t->decimal('received_quantity',14,3)->default(0);
                $t->char('dispatch_movement_public_id',26)->nullable()->index('crm_xfer_item_out_idx'); $t->char('receive_movement_public_id',26)->nullable()->index('crm_xfer_item_in_idx');
                $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','stock_transfer_public_id','inventory_item_public_id'],'crm_xfer_item_unique');
            });
        }
    }

    public function down(): void
    {
        // Option A convergence is data-preserving: never remove existing Locker or migrated asset state.
    }
};
