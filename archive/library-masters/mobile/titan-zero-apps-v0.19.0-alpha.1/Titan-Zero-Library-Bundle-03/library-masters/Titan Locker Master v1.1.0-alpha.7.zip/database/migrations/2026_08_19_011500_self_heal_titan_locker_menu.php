<?php

declare(strict_types=1);

use App\Extensions\TitanLocker\System\Navigation\LockerMenuSelfHealer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;

return new class extends Migration
{
    public function up(): void
    {
        Cache::forget('titan_locker_menu_schema_version');
        try {
            app(LockerMenuSelfHealer::class)->heal(true);
        } catch (\Throwable) {
            // Navigation repair is deliberately non-fatal; normal boot retries it.
        }
    }

    public function down(): void
    {
        // Preserve the repaired Titan Locker navigation on rollback.
    }
};
