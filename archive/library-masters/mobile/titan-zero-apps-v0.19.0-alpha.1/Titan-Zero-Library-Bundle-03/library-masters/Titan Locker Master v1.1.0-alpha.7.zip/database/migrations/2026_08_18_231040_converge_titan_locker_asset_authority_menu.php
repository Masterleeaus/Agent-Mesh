<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus')) return;

        $now = now();
        DB::table('menus')->where('key', 'ext_crm_gear')->update([
            'label' => 'Titan Locker',
            'is_active' => 1,
            'updated_at' => $now,
        ]);

        $assetsParent = DB::table('menus')->where('key', 'titan_assets')->first();
        if ($assetsParent) {
            $items = [
                'crm_tools' => ['Tools', 'titan-assets.tools', 'tabler-tool', 3],
                'crm_equipment' => ['Equipment', 'titan-assets.equipment', 'tabler-engine', 4],
                'crm_fleet' => ['Fleet', 'titan-assets.fleet', 'tabler-car', 5],
                'crm_customer_assets' => ['Customer Assets', 'titan-assets.customer-assets', 'tabler-building-factory-2', 6],
                'crm_maintenance' => ['Maintenance', 'titan-assets.maintenance', 'tabler-settings', 8],
            ];
            foreach ($items as $key => [$label, $route, $icon, $order]) {
                DB::table('menus')->where('key', $key)->update([
                    'parent_id' => (int) $assetsParent->id,
                    'route' => $route,
                    'route_slug' => null,
                    'label' => $label,
                    'icon' => $icon,
                    'order' => $order,
                    'is_active' => 1,
                    'extension' => 'titan-assets',
                    'custom_menu' => 1,
                    'updated_at' => $now,
                ]);
            }
        }

        foreach (['titan_assets_menu_schema_version', 'dynamic_menu_key', 'dynamic_menu_key_active', 'navbar_cache_registry'] as $key) Cache::forget($key);
        try {
            if (class_exists(\App\Services\Common\MenuService::class)) app(\App\Services\Common\MenuService::class)->regenerate();
        } catch (\Throwable) {
            foreach (['dynamic_menu_key', 'dynamic_menu_key_active', 'navbar_cache_registry'] as $key) Cache::forget($key);
        }
    }

    public function down(): void
    {
        // Preserve converged menu ownership and all operational data on rollback.
    }
};
