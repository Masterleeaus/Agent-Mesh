<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('crm_locker_suppliers')) {
            Schema::create('crm_locker_suppliers', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('name',190); $t->string('code',80)->nullable(); $t->string('email')->nullable(); $t->string('phone',80)->nullable(); $t->string('website')->nullable(); $t->string('account_reference',120)->nullable(); $t->boolean('active')->default(true)->index(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps();
                $t->unique(['company_id','code'],'crm_locker_supplier_code_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_inventory_items')) {
            Schema::create('crm_locker_inventory_items', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('item_type',40)->default('consumable')->index(); $t->string('sku',100); $t->string('barcode',160)->nullable()->index(); $t->string('qr_code',160)->nullable()->index(); $t->string('name',190); $t->text('description')->nullable(); $t->string('unit',40)->default('each');
                $t->bigInteger('cost_minor')->default(0); $t->bigInteger('sale_price_minor')->default(0); $t->char('currency',3)->default('AUD'); $t->string('costing_method',40)->default('weighted_average')->index(); $t->boolean('track_stock')->default(true)->index(); $t->boolean('billable_default')->default(true); $t->boolean('active')->default(true)->index();
                $t->char('preferred_supplier_public_id',26)->nullable()->index(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','sku'],'crm_locker_item_sku_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_stock_locations')) {
            Schema::create('crm_locker_stock_locations', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('location_type',40)->default('warehouse')->index(); $t->string('code',80); $t->string('name',180); $t->char('business_location_public_id',26)->nullable()->index(); $t->char('fleet_vehicle_public_id',26)->nullable()->index(); $t->unsignedBigInteger('assigned_user_id')->nullable()->index(); $t->boolean('active')->default(true)->index(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','code'],'crm_locker_location_code_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_stock_movements')) {
            Schema::create('crm_locker_stock_movements', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->char('inventory_item_public_id',26)->index(); $t->char('location_public_id',26)->index(); $t->char('counterpart_location_public_id',26)->nullable()->index(); $t->char('transfer_group_public_id',26)->nullable()->index();
                $t->string('movement_type',40)->index(); $t->decimal('quantity_delta',14,3); $t->bigInteger('unit_cost_minor')->nullable(); $t->bigInteger('total_cost_minor')->nullable(); $t->char('work_order_public_id',26)->nullable()->index(); $t->char('supplier_public_id',26)->nullable()->index(); $t->string('source_type',80)->nullable()->index(); $t->char('source_public_id',26)->nullable()->index(); $t->string('reference',160)->nullable()->index(); $t->string('idempotency_key',190)->nullable();
                $t->dateTime('occurred_at')->index(); $t->unsignedBigInteger('created_by_user_id')->nullable()->index(); $t->json('metadata')->nullable(); $t->timestamps(); $t->unique(['company_id','idempotency_key'],'crm_locker_movement_idempotency_unique'); $t->index(['company_id','inventory_item_public_id','location_public_id'],'crm_locker_stock_lookup');
            });
        }
        if (! Schema::hasTable('crm_locker_stock_allocations')) {
            Schema::create('crm_locker_stock_allocations', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->char('inventory_item_public_id',26)->index(); $t->char('location_public_id',26)->index(); $t->char('work_order_public_id',26)->index(); $t->decimal('quantity',14,3); $t->string('status',40)->default('reserved')->index(); $t->dateTime('reserved_until')->nullable()->index(); $t->unsignedBigInteger('created_by_user_id')->nullable()->index(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->index(['company_id','work_order_public_id','status'],'crm_locker_allocation_job_status');
            });
        }
        if (! Schema::hasTable('crm_locker_tools')) {
            Schema::create('crm_locker_tools', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->char('inventory_item_public_id',26)->nullable()->index(); $t->string('asset_tag',100); $t->string('name',180); $t->string('serial_number',160)->nullable()->index(); $t->string('status',40)->default('available')->index(); $t->unsignedBigInteger('custodian_user_id')->nullable()->index(); $t->char('location_public_id',26)->nullable()->index();
                $t->date('acquired_on')->nullable(); $t->bigInteger('acquisition_cost_minor')->nullable(); $t->bigInteger('current_value_minor')->nullable(); $t->date('warranty_expires_on')->nullable()->index(); $t->date('retired_on')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','asset_tag'],'crm_locker_tool_asset_tag_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_equipment')) {
            Schema::create('crm_locker_equipment', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('asset_tag',100); $t->string('equipment_type',100)->nullable()->index(); $t->string('name',180); $t->string('manufacturer',120)->nullable(); $t->string('model',120)->nullable(); $t->string('serial_number',160)->nullable()->index(); $t->string('status',40)->default('active')->index(); $t->unsignedBigInteger('assigned_user_id')->nullable()->index(); $t->char('location_public_id',26)->nullable()->index();
                $t->date('acquired_on')->nullable(); $t->bigInteger('acquisition_cost_minor')->nullable(); $t->bigInteger('current_value_minor')->nullable(); $t->string('depreciation_method',40)->default('none'); $t->unsignedInteger('useful_life_months')->nullable(); $t->bigInteger('salvage_value_minor')->nullable(); $t->date('warranty_expires_on')->nullable()->index(); $t->date('next_service_on')->nullable()->index(); $t->date('retired_on')->nullable(); $t->date('sold_on')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','asset_tag'],'crm_locker_equipment_asset_tag_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_fleet_vehicles')) {
            Schema::create('crm_locker_fleet_vehicles', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('registration',40); $t->string('vin',80)->nullable()->index(); $t->string('make',100)->nullable(); $t->string('model',100)->nullable(); $t->unsignedSmallInteger('year')->nullable(); $t->string('status',40)->default('active')->index(); $t->unsignedBigInteger('assigned_user_id')->nullable()->index(); $t->unsignedBigInteger('odometer_km')->nullable();
                $t->date('acquired_on')->nullable(); $t->bigInteger('acquisition_cost_minor')->nullable(); $t->bigInteger('current_value_minor')->nullable(); $t->string('depreciation_method',40)->default('none'); $t->unsignedInteger('useful_life_months')->nullable(); $t->bigInteger('salvage_value_minor')->nullable(); $t->date('registration_expires_on')->nullable()->index(); $t->date('warranty_expires_on')->nullable()->index(); $t->date('next_service_on')->nullable()->index(); $t->date('retired_on')->nullable(); $t->date('sold_on')->nullable(); $t->json('metadata')->nullable(); $t->softDeletes(); $t->timestamps(); $t->unique(['company_id','registration'],'crm_locker_vehicle_registration_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_maintenance_records')) {
            Schema::create('crm_locker_maintenance_records', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('subject_type',40)->index(); $t->char('subject_public_id',26)->index(); $t->string('maintenance_type',80)->default('service')->index(); $t->string('status',40)->default('scheduled')->index(); $t->date('scheduled_for')->nullable()->index(); $t->date('completed_on')->nullable()->index(); $t->unsignedBigInteger('odometer_km')->nullable(); $t->bigInteger('cost_minor')->nullable(); $t->char('currency',3)->default('AUD'); $t->char('supplier_public_id',26)->nullable()->index(); $t->text('notes')->nullable(); $t->json('metadata')->nullable(); $t->unsignedBigInteger('created_by_user_id')->nullable()->index(); $t->timestamps();
                $t->index(['company_id','subject_type','subject_public_id'],'crm_locker_maintenance_subject');
            });
        }
        if (! Schema::hasTable('crm_locker_reorder_rules')) {
            Schema::create('crm_locker_reorder_rules', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->char('inventory_item_public_id',26)->index(); $t->char('location_public_id',26)->nullable()->index(); $t->decimal('reorder_point',14,3)->default(0); $t->decimal('reorder_quantity',14,3)->default(0); $t->char('preferred_supplier_public_id',26)->nullable()->index(); $t->boolean('enabled')->default(true)->index(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->unique(['company_id','inventory_item_public_id','location_public_id'],'crm_locker_reorder_rule_unique');
            });
        }
        if (! Schema::hasTable('crm_locker_asset_events')) {
            Schema::create('crm_locker_asset_events', function (Blueprint $t): void {
                $t->id(); $t->char('public_id',26)->unique(); $t->unsignedBigInteger('company_id')->index(); $t->string('subject_type',40)->index(); $t->char('subject_public_id',26)->index(); $t->string('event_type',60)->index(); $t->dateTime('occurred_at')->index(); $t->unsignedBigInteger('actor_user_id')->nullable()->index(); $t->char('location_public_id',26)->nullable()->index(); $t->bigInteger('value_minor')->nullable(); $t->json('metadata')->nullable(); $t->timestamps();
                $t->index(['company_id','subject_type','subject_public_id','occurred_at'],'crm_locker_asset_event_timeline');
            });
        }
    }

    public function down(): void
    {
        // Option A convergence is data-preserving: never remove existing Locker or migrated asset state.
    }
};
