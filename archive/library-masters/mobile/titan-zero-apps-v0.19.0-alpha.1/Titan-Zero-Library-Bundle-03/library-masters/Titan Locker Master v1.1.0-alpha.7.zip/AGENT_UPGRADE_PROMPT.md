# Titan Locker — Agent Upgrade / Continuation Prompt

You are working on an EXISTING Titan Zero extension extracted from Titan CRM v1.3.0-alpha.23. **Do not rebuild it from scratch.** Deep scan the entire package before modifying anything and preserve working domain services, routes, migrations, UI, installer conventions and tenant isolation.

## Mission

Owns inventory items, consumables, stock locations/movements/allocations, suppliers, purchasing, purchase orders, goods receipts, stock counts/transfers and reorder state. Titan Assets owns tools/equipment/fleet/custody/maintenance/repairs/warranties/mileage.

## Non-negotiable Titan rules

1. `company_id` is the canonical tenant boundary. Never substitute CRM customer `company_id` or `user_id`.
2. AI does not write authoritative business state directly. Consequential mutations go through Titan Command Bus / the CRM governance gateway until a domain-native gateway is formally introduced.
3. Important state changes emit Titan Signal-compatible events with `trace_id`, `correlation_id`, `causation_id`, and tenant identity.
4. External side effects must be idempotent.
5. Preserve Titan Rewind-compatible structured receipts; never store unrestricted hidden chain-of-thought.
6. Preserve installer compatibility and existing table data. This extraction intentionally retains the historical `crm_*` table names during the strangler migration. Do **not** rename/move tables destructively.
7. Maintain exactly one authoritative writer per domain. Do not reintroduce duplicate domain logic into CRM Core.
8. Prefer adapters/ports over cross-extension table writes.
9. Every exposed capability must declare owner, input/output contract, risk, autonomy, evidence, offline policy, reversibility, and idempotency.
10. Do not claim functionality exists unless implemented and tested.

## Current ownership

Owns inventory items, consumables, stock locations/movements/allocations, suppliers, purchasing, purchase orders, goods receipts, stock counts/transfers and reorder state. Titan Assets owns tools/equipment/fleet/custody/maintenance/repairs/warranties/mileage.

## Known transitional debt to remove safely

Legacy `crm.locker.*` capability registration remains in CRM Core as a compatibility adapter and resolves these extracted services. Replace direct CRM operational-signal reads of Locker tables with Locker query ports/Signal projections before deleting aliases.

## Required next-agent procedure

- Run syntax/tests/verifiers before edits and again after edits.
- Trace every cross-extension import. Replace direct cross-domain table reads with read/query ports before deleting compatibility aliases.
- Keep legacy `crm.*` capability names working until all consumers migrate; canonical new capability aliases may be introduced additively.
- If adopting existing tables, migrations must use `Schema::hasTable/hasColumn` and be safe on both upgraded and fresh installs.
- Never create a second writer as a migration shortcut.
- Update README, ownership map, changelog, capability manifest, agent prompt and CODEE artifact metadata on every cumulative release.

## Done when

The extension owns only its declared domain, can be installed/upgraded without data loss, integrates through governed contracts, and CRM Core no longer contains a second implementation of the same domain.

## Option A convergence

This package is the inventory-side convergence release. Do not restore the removed Locker asset writer services. Preserve legacy route names only as compatibility bridges into Titan Assets.
