<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_context_accesses')) return;
        Schema::create('ext_titan_ai_workforce_context_accesses', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('member_id')->index();
            $table->string('role_definition_id', 190)->index();
            $table->string('responsibility_id', 255)->index();
            $table->string('surface_id', 255)->index();
            $table->string('purpose', 255);
            $table->string('provider', 190)->nullable()->index();
            $table->string('provider_version', 80)->nullable();
            $table->string('decision', 32)->index();
            $table->string('reason', 190)->nullable();
            $table->unsignedInteger('item_count')->default(0);
            $table->timestamp('accessed_at')->nullable()->index();
            $table->timestamps();
            $table->index(['company_id','member_id','accessed_at'], 'twf_context_company_member_time');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_context_accesses');
    }
};
