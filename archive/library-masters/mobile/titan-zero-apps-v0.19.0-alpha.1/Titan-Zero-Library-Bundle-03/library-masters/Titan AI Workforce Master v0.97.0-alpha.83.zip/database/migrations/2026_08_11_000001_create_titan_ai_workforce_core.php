<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_titan_ai_workforce_divisions', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->string('key'); $table->string('name');
            $table->text('purpose')->nullable(); $table->boolean('is_active')->default(true); $table->json('metadata')->nullable();
            $table->timestamps(); $table->softDeletes(); $table->unique(['company_id','key'], 'taiw_division_company_key_unique');
        });

        Schema::create('ext_titan_ai_workforce_teams', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('division_id')->nullable()->index();
            $table->string('key'); $table->string('name'); $table->text('purpose')->nullable(); $table->boolean('is_active')->default(true);
            $table->json('metadata')->nullable(); $table->timestamps(); $table->softDeletes(); $table->unique(['company_id','key'], 'taiw_team_company_key_unique');
        });

        Schema::create('ext_titan_ai_workforce_members', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('division_id')->nullable()->index(); $table->unsignedBigInteger('team_id')->nullable()->index();
            $table->unsignedBigInteger('manager_id')->nullable()->index(); $table->unsignedTinyInteger('tier'); $table->string('key'); $table->string('name');
            $table->string('role'); $table->text('purpose')->nullable(); $table->json('responsibilities')->nullable(); $table->json('goals')->nullable();
            $table->json('capabilities')->nullable(); $table->json('capability_variants')->nullable(); $table->json('skills')->nullable();
            $table->json('playbooks')->nullable(); $table->json('interaction_wizards')->nullable(); $table->json('knowledge_scopes')->nullable();
            $table->json('memory_scopes')->nullable(); $table->json('provider_preferences')->nullable(); $table->json('model_preferences')->nullable();
            $table->json('schedule_config')->nullable(); $table->json('workload_config')->nullable(); $table->json('escalation_policy')->nullable();
            $table->string('risk_ceiling')->default('LOW'); $table->json('autonomy_references')->nullable(); $table->json('assurance_references')->nullable();
            $table->json('performance_history')->nullable(); $table->string('status')->default('AVAILABLE'); $table->boolean('is_active')->default(true);
            $table->json('metadata')->nullable(); $table->timestamps(); $table->softDeletes();
            $table->unique(['company_id','key'], 'taiw_member_company_key_unique');
        });

        Schema::create('ext_titan_ai_workforce_relationships', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('source_member_id')->index();
            $table->unsignedBigInteger('target_member_id')->index(); $table->string('relationship_type', 40)->index(); $table->boolean('is_active')->default(true);
            $table->json('metadata')->nullable(); $table->timestamps();
            $table->unique(['company_id','source_member_id','target_member_id','relationship_type'], 'taiw_relationship_unique');
        });

        Schema::create('ext_titan_ai_workforce_tasks', function (Blueprint $table) {
            $table->id(); $table->uuid('task_uuid')->unique(); $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('parent_task_id')->nullable()->index(); $table->unsignedBigInteger('division_id')->nullable()->index();
            $table->unsignedBigInteger('team_id')->nullable()->index(); $table->unsignedBigInteger('assignee_member_id')->nullable()->index();
            $table->unsignedBigInteger('manager_member_id')->nullable()->index(); $table->string('origin_type')->nullable(); $table->string('origin_id')->nullable();
            $table->string('title'); $table->text('description')->nullable(); $table->string('capability')->nullable()->index(); $table->string('capability_variant')->nullable();
            $table->string('status', 40)->default('CREATED')->index(); $table->unsignedTinyInteger('priority')->default(50)->index(); $table->string('risk_level')->default('LOW')->index();
            $table->json('payload')->nullable(); $table->json('result')->nullable(); $table->json('evidence')->nullable(); $table->json('governance')->nullable();
            $table->json('risk_snapshot')->nullable(); $table->json('assurance_snapshot')->nullable(); $table->json('autonomy_snapshot')->nullable();
            $table->uuid('trace_id')->index(); $table->uuid('correlation_id')->index(); $table->uuid('causation_id')->nullable()->index();
            $table->string('idempotency_key')->nullable(); $table->timestamp('scheduled_at')->nullable()->index(); $table->timestamp('deadline_at')->nullable()->index();
            $table->timestamp('started_at')->nullable(); $table->timestamp('completed_at')->nullable(); $table->timestamp('last_activity_at')->nullable();
            $table->unsignedInteger('attempt_count')->default(0); $table->unsignedInteger('revision_count')->default(0); $table->string('sla_key')->nullable();
            $table->json('metadata')->nullable(); $table->timestamps(); $table->softDeletes();
            $table->unique(['company_id','idempotency_key'], 'taiw_task_idempotency_unique');
        });

        Schema::create('ext_titan_ai_workforce_task_dependencies', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('task_id')->index();
            $table->unsignedBigInteger('depends_on_task_id')->index(); $table->boolean('blocking')->default(true); $table->timestamps();
            $table->unique(['company_id','task_id','depends_on_task_id'], 'taiw_task_dependency_unique');
        });

        Schema::create('ext_titan_ai_workforce_handoffs', function (Blueprint $table) {
            $table->id(); $table->uuid('handoff_uuid')->unique(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('task_id')->index();
            $table->unsignedBigInteger('origin_member_id')->nullable()->index(); $table->unsignedBigInteger('origin_manager_id')->nullable()->index();
            $table->unsignedBigInteger('receiving_division_id')->nullable()->index(); $table->unsignedBigInteger('receiving_manager_id')->nullable()->index();
            $table->unsignedBigInteger('receiving_specialist_id')->nullable()->index(); $table->string('status', 40)->default('PENDING')->index();
            $table->text('reason')->nullable(); $table->json('evidence')->nullable(); $table->json('metadata')->nullable(); $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('ext_titan_ai_workforce_task_history', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('task_id')->index();
            $table->unsignedBigInteger('actor_member_id')->nullable()->index(); $table->string('event', 80)->index(); $table->string('from_status', 40)->nullable();
            $table->string('to_status', 40)->nullable(); $table->text('reason')->nullable(); $table->json('context')->nullable(); $table->uuid('trace_id')->index();
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('ext_titan_ai_workforce_schedules', function (Blueprint $table) {
            $table->id(); $table->unsignedBigInteger('company_id')->index(); $table->unsignedBigInteger('member_id')->index();
            $table->string('key'); $table->string('name'); $table->string('trigger_type')->default('schedule')->index(); $table->string('event_type')->nullable()->index(); $table->json('conditions')->nullable(); $table->json('schedule')->nullable();
            $table->json('task_template'); $table->timestamp('next_run_at')->nullable()->index(); $table->timestamp('last_run_at')->nullable();
            $table->boolean('is_active')->default(true); $table->json('metadata')->nullable(); $table->timestamps(); $table->softDeletes();
            $table->unique(['company_id','member_id','key'], 'taiw_schedule_company_member_key_unique');
        });

        Schema::create('ext_titan_ai_workforce_signal_outbox', function (Blueprint $table) {
            $table->id(); $table->uuid('signal_id')->unique(); $table->unsignedBigInteger('company_id')->index(); $table->string('event_type')->index();
            $table->uuid('trace_id')->index(); $table->uuid('correlation_id')->index(); $table->uuid('causation_id')->nullable()->index(); $table->json('payload');
            $table->unsignedInteger('publish_attempts')->default(0); $table->timestamp('published_at')->nullable(); $table->timestamp('failed_at')->nullable();
            $table->text('last_error')->nullable(); $table->timestamps();
        });

    }

    public function down(): void
    {
        foreach (['ext_titan_ai_workforce_signal_outbox','ext_titan_ai_workforce_schedules','ext_titan_ai_workforce_task_history','ext_titan_ai_workforce_handoffs','ext_titan_ai_workforce_task_dependencies','ext_titan_ai_workforce_tasks','ext_titan_ai_workforce_relationships','ext_titan_ai_workforce_members','ext_titan_ai_workforce_teams','ext_titan_ai_workforce_divisions'] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
