<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_action_review_packets')) {
            Schema::create('ext_titan_ai_workforce_action_review_packets', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->unsignedBigInteger('task_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->string('stage_key', 64)->index();
                $table->unsignedInteger('packet_version')->default(1);
                $table->char('packet_sha256', 64)->index();
                $table->json('packet');
                $table->timestamp('sealed_at')->index();
                $table->timestamps();

                $table->unique(['company_id','processing_id','stage'], 'taiw_action_review_packet_stage_unique');
                $table->foreign('decision_chain_id', 'taiw_action_packet_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_action_review_packets');
    }
};
