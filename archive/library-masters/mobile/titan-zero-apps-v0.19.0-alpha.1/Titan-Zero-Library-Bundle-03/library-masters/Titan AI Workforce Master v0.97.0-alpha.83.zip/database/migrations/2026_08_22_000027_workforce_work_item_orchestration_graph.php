<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_task_dependencies')) {
            Schema::table('ext_titan_ai_workforce_task_dependencies', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_task_dependencies', 'dependency_type')) {
                    $table->string('dependency_type', 40)->default('finish_to_start')->after('depends_on_task_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_task_dependencies', 'failure_policy')) {
                    $table->string('failure_policy', 40)->default('block')->after('blocking')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_task_dependencies', 'condition')) {
                    $table->json('condition')->nullable()->after('failure_policy');
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_task_dependencies', 'metadata')) {
                    $table->json('metadata')->nullable()->after('condition');
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'orchestration_group')) {
                    $table->string('orchestration_group', 120)->nullable()->after('goal_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'sequence_index')) {
                    $table->unsignedInteger('sequence_index')->nullable()->after('orchestration_group')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'estimated_minutes')) {
                    $table->unsignedInteger('estimated_minutes')->nullable()->after('sequence_index');
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'max_attempts')) {
                    $table->unsignedSmallInteger('max_attempts')->default(3)->after('attempt_count');
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'retry_strategy')) {
                    $table->string('retry_strategy', 40)->default('exponential')->after('max_attempts');
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'compensation_capability')) {
                    $table->string('compensation_capability', 255)->nullable()->after('retry_strategy')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'critical_path')) {
                    $table->boolean('critical_path')->default(false)->after('compensation_capability')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'blocked_by_graph')) {
                    $table->boolean('blocked_by_graph')->default(false)->after('critical_path')->index();
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_task_dependencies')) {
            Schema::table('ext_titan_ai_workforce_task_dependencies', function (Blueprint $table): void {
                foreach (['metadata','condition','failure_policy','dependency_type'] as $column) {
                    if (Schema::hasColumn('ext_titan_ai_workforce_task_dependencies', $column)) $table->dropColumn($column);
                }
            });
        }
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                foreach (['blocked_by_graph','critical_path','compensation_capability','retry_strategy','max_attempts','estimated_minutes','sequence_index','orchestration_group'] as $column) {
                    if (Schema::hasColumn('ext_titan_ai_workforce_tasks', $column)) $table->dropColumn($column);
                }
            });
        }
    }
};
