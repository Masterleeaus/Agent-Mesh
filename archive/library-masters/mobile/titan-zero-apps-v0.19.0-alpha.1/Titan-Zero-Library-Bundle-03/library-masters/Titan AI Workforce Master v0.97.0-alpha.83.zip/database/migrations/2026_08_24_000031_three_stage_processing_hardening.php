<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_processing_checkpoints', function (Blueprint $table): void {
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','owner_member_id')) $table->unsignedBigInteger('owner_member_id')->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','attempt_count')) $table->unsignedSmallInteger('attempt_count')->default(0);
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','max_attempts')) $table->unsignedSmallInteger('max_attempts')->default(3);
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','started_at')) $table->timestamp('started_at')->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','due_at')) $table->timestamp('due_at')->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','last_transition_at')) $table->timestamp('last_transition_at')->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','superseded_by_checkpoint_id')) $table->unsignedBigInteger('superseded_by_checkpoint_id')->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','status_reason')) $table->text('status_reason')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_processing_checkpoints', function (Blueprint $table): void {
            foreach (['owner_member_id','attempt_count','max_attempts','started_at','due_at','last_transition_at','superseded_by_checkpoint_id','status_reason'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints',$column)) $table->dropColumn($column);
            }
        });
    }
};
