<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_titan_ai_workforce_execution_attempts', function (Blueprint $table) {
            $table->id();
            $table->uuid('attempt_uuid')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('task_id')->index();
            $table->unsignedBigInteger('worker_member_id')->index();
            $table->uuid('intent_id')->index();
            $table->char('intent_sha256', 64)->index();
            $table->char('state_fingerprint', 64);
            $table->string('idempotency_key', 96);
            $table->json('command_payload');
            $table->json('expected_state');
            $table->json('state_revalidation')->nullable();
            $table->string('status', 40)->default('INTENT_LOCKED')->index();
            $table->timestamp('dispatched_at')->nullable();
            $table->json('receipt')->nullable();
            $table->string('receipt_ref')->nullable()->index();
            $table->char('receipt_sha256', 64)->nullable();
            $table->string('verification_status', 40)->nullable()->index();
            $table->json('verification')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->string('compensation_ref')->nullable()->index();
            $table->json('recovery')->nullable();
            $table->timestamps();
            $table->unique(['company_id','idempotency_key'], 'taiw_execution_attempt_idempotency_unique');
            $table->index(['company_id','task_id','status'], 'taiw_execution_attempt_task_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_execution_attempts');
    }
};
