<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_titan_ai_workforce_journey_records', function (Blueprint $table) {
            $table->id();
            $table->uuid('event_uuid')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('task_id')->nullable()->index();
            $table->unsignedBigInteger('member_id')->nullable()->index();
            $table->string('category', 32)->index();
            $table->string('phase', 24)->index();
            $table->string('event_type', 100)->index();
            $table->uuid('trace_id')->index();
            $table->uuid('correlation_id')->index();
            $table->uuid('causation_id')->nullable()->index();
            $table->string('source_ref')->nullable()->index();
            $table->json('rationale_refs')->nullable();
            $table->json('evidence_refs')->nullable();
            $table->json('decision_refs')->nullable();
            $table->json('execution_refs')->nullable();
            $table->json('outcome_refs')->nullable();
            $table->json('summary')->nullable();
            $table->char('event_sha256', 64)->index();
            $table->timestamp('observed_at')->index();
            $table->timestamps();
            $table->index(['company_id','correlation_id','observed_at'], 'taiw_journey_correlation_time');
            $table->index(['company_id','task_id','observed_at'], 'taiw_journey_task_time');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_journey_records');
    }
};
