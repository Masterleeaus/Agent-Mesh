<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_learning_recommendations')) {
            Schema::create('ext_titan_ai_workforce_chain_learning_recommendations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('recommendation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('scope_key',190)->index();
                $table->string('recommendation_type',80)->index();
                $table->string('status',32)->default('PROPOSED')->index();
                $table->decimal('confidence',6,2)->default(0);
                $table->unsignedInteger('sample_size')->default(0);
                $table->json('current_policy')->nullable();
                $table->json('recommended_policy');
                $table->json('evidence')->nullable();
                $table->json('expected_effect')->nullable();
                $table->unsignedBigInteger('approved_by_user_id')->nullable()->index();
                $table->timestamp('approved_at')->nullable();
                $table->unsignedBigInteger('rejected_by_user_id')->nullable()->index();
                $table->timestamp('rejected_at')->nullable();
                $table->timestamp('generated_at')->index();
                $table->timestamps();
                $table->unique(['company_id','scope_key','recommendation_type','status'],'taiw_chain_learning_rec_unique');
            });
        }

        if (!Schema::hasTable('ext_titan_ai_workforce_reviewer_combination_learning')) {
            Schema::create('ext_titan_ai_workforce_reviewer_combination_learning', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('scope_key',190)->index();
                $table->char('combination_sha256',64)->index();
                $table->json('reviewer_signature');
                $table->unsignedInteger('sample_size')->default(0);
                $table->decimal('success_rate',6,2)->nullable();
                $table->decimal('disagreement_rate',6,2)->nullable();
                $table->decimal('authority_denial_rate',6,2)->nullable();
                $table->decimal('overturn_rate',6,2)->nullable();
                $table->decimal('average_latency_seconds',14,2)->nullable();
                $table->decimal('quality_score',6,2)->nullable();
                $table->timestamp('calculated_at')->index();
                $table->timestamps();
                $table->unique(['company_id','scope_key','combination_sha256'],'taiw_reviewer_combo_learning_unique');
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_reviewer_combination_learning');
        Schema::dropIfExists('ext_titan_ai_workforce_chain_learning_recommendations');
    }
};
