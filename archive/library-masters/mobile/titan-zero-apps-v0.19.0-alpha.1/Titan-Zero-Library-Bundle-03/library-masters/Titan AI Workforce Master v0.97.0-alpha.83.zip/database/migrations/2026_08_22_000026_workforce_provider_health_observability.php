<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_provider_health_events')) return;
        Schema::create('ext_titan_ai_workforce_provider_health_events', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('provider', 190)->index();
            $table->string('provider_version', 80)->nullable();
            $table->string('surface_type', 40)->nullable()->index();
            $table->string('surface_id', 255)->nullable()->index();
            $table->string('role_definition_id', 190)->nullable()->index();
            $table->string('responsibility_id', 255)->nullable()->index();
            $table->string('state', 40)->index();
            $table->string('event_type', 80)->index();
            $table->string('reason', 190)->nullable()->index();
            $table->text('message')->nullable();
            $table->json('details')->nullable();
            $table->timestamp('observed_at')->index();
            $table->timestamp('recovered_at')->nullable()->index();
            $table->timestamps();
            $table->index(['company_id','provider','observed_at'], 'twf_provider_health_company_provider_time');
            $table->index(['company_id','state','observed_at'], 'twf_provider_health_company_state_time');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_provider_health_events');
    }
};
