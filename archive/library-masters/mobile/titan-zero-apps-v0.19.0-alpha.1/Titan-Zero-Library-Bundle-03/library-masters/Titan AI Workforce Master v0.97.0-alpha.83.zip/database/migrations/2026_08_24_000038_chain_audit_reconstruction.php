<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_audit_snapshots')) {
            Schema::create('ext_titan_ai_workforce_chain_audit_snapshots', function (Blueprint $table): void {
                $table->id();
                $table->uuid('snapshot_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedBigInteger('task_id')->index();
                $table->string('snapshot_type',60)->index();
                $table->unsignedInteger('sequence')->default(1);
                $table->char('previous_sha256',64)->nullable();
                $table->char('snapshot_sha256',64)->index();
                $table->json('reconstruction');
                $table->timestamp('captured_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id','sequence'],'taiw_chain_audit_sequence_unique');
                $table->foreign('decision_chain_id','taiw_chain_audit_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_chain_audit_snapshots');
    }
};
