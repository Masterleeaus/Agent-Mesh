<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_assurance_council_reviews')) {
            Schema::create('ext_titan_ai_workforce_assurance_council_reviews', function (Blueprint $table): void {
                $table->id();
                $table->uuid('review_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->unsignedBigInteger('manager_escalation_id')->nullable()->index();
                $table->string('assurance_status',32)->nullable()->index();
                $table->decimal('assurance_score',6,2)->nullable();
                $table->json('assurance_result')->nullable();
                $table->boolean('model_council_required')->default(false)->index();
                $table->string('council_status',32)->nullable()->index();
                $table->json('council_role_models')->nullable();
                $table->json('council_result')->nullable();
                $table->string('final_status',40)->default('PENDING')->index();
                $table->boolean('advisory_only')->default(true);
                $table->timestamp('reviewed_at')->index();
                $table->timestamps();
                $table->foreign('decision_chain_id','taiw_assurance_council_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_assurance_council_reviews');
    }
};
