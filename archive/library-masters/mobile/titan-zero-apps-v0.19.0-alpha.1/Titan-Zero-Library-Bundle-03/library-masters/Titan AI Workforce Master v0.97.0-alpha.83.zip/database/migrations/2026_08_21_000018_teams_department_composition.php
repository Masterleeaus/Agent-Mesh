<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_team_definitions')) {
            Schema::create('ext_titan_ai_workforce_team_definitions', function (Blueprint $table): void {
                $table->id();
                $table->string('team_definition_id', 180)->unique();
                $table->string('key', 120)->unique();
                $table->string('name', 180);
                $table->string('division_definition_id', 180)->index();
                $table->string('division_key', 120)->index();
                $table->text('purpose');
                $table->json('boundaries');
                $table->json('role_definition_ids');
                $table->json('applicability');
                $table->json('activation_rules');
                $table->string('definition_scope', 40)->default('INTRINSIC')->index();
                $table->string('definition_version', 40)->default('1');
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_teams') && ! Schema::hasColumn('ext_titan_ai_workforce_teams', 'team_definition_id')) {
            Schema::table('ext_titan_ai_workforce_teams', function (Blueprint $table): void {
                $table->string('team_definition_id', 180)->nullable()->index();
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && ! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'team_definition_id')) {
            Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void {
                $table->string('team_definition_id', 180)->nullable()->index();
            });
        }

        $path = dirname(__DIR__, 2) . '/resources/workforce/team-definitions.json';
        $definitions = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $timestamp = now();

        foreach ($definitions as $definition) {
            DB::table('ext_titan_ai_workforce_team_definitions')->updateOrInsert(
                ['team_definition_id' => (string) $definition['team_definition_id']],
                [
                    'key' => (string) $definition['key'],
                    'name' => (string) $definition['name'],
                    'division_definition_id' => (string) $definition['division_definition_id'],
                    'division_key' => (string) $definition['division_key'],
                    'purpose' => (string) $definition['purpose'],
                    'boundaries' => json_encode($definition['boundaries'], JSON_THROW_ON_ERROR),
                    'role_definition_ids' => json_encode($definition['role_definition_ids'], JSON_THROW_ON_ERROR),
                    'applicability' => json_encode($definition['applicability'], JSON_THROW_ON_ERROR),
                    'activation_rules' => json_encode($definition['activation_rules'], JSON_THROW_ON_ERROR),
                    'definition_scope' => (string) ($definition['definition_scope'] ?? 'INTRINSIC'),
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => (string) ($definition['status'] ?? 'ACTIVE'),
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'team_definition_id')) {
            $rolesPath = dirname(__DIR__, 2) . '/resources/workforce/role-definitions.json';
            $roles = json_decode((string) file_get_contents($rolesPath), true, 512, JSON_THROW_ON_ERROR);
            foreach ($roles as $role) {
                DB::table('ext_titan_ai_workforce_role_definitions')
                    ->where('role_definition_id', (string) $role['role_definition_id'])
                    ->update([
                        'team_key' => (string) $role['team_key'],
                        'team_definition_id' => (string) $role['team_definition_id'],
                        'updated_at' => $timestamp,
                    ]);
            }
        }

        // Existing company teams are only bound when their key already matches a canonical team.
        // Pass 8 never creates employee rows; WorkforceBootstrapService materialises canonical
        // company team containers on demand from these immutable definitions.
        if (Schema::hasTable('ext_titan_ai_workforce_teams') && Schema::hasColumn('ext_titan_ai_workforce_teams', 'team_definition_id')) {
            foreach ($definitions as $definition) {
                DB::table('ext_titan_ai_workforce_teams')
                    ->where('key', (string) $definition['key'])
                    ->whereNull('team_definition_id')
                    ->update(['team_definition_id' => (string) $definition['team_definition_id']]);
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'team_definition_id')) {
            Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void { $table->dropColumn('team_definition_id'); });
        }
        if (Schema::hasTable('ext_titan_ai_workforce_teams') && Schema::hasColumn('ext_titan_ai_workforce_teams', 'team_definition_id')) {
            Schema::table('ext_titan_ai_workforce_teams', function (Blueprint $table): void { $table->dropColumn('team_definition_id'); });
        }
        Schema::dropIfExists('ext_titan_ai_workforce_team_definitions');
    }
};
