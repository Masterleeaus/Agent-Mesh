<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_signal_work_rules')) {
            Schema::create('ext_titan_ai_workforce_signal_work_rules', function (Blueprint $table): void {
                $table->id();
                $table->uuid('rule_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('key', 190);
                $table->string('event_type', 190)->index();
                $table->string('role_definition_id', 190)->index();
                $table->string('responsibility_id', 255)->index();
                $table->string('capability', 255)->index();
                $table->unsignedBigInteger('assignee_member_id')->nullable()->index();
                $table->json('conditions')->nullable();
                $table->json('goal_template');
                $table->json('work_item_template');
                $table->boolean('is_active')->default(false)->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id','key'], 'twf_signal_rule_company_key_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_signal_work_receipts')) {
            Schema::create('ext_titan_ai_workforce_signal_work_receipts', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('rule_id')->index();
                $table->string('signal_id', 190);
                $table->string('event_type', 190)->index();
                $table->unsignedBigInteger('goal_id')->nullable()->index();
                $table->unsignedBigInteger('work_item_id')->nullable()->index();
                $table->string('status', 40)->index();
                $table->string('reason', 190)->nullable();
                $table->json('metadata')->nullable();
                $table->timestamp('processed_at')->nullable()->index();
                $table->timestamps();
                $table->unique(['company_id','rule_id','signal_id'], 'twf_signal_receipt_replay_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_signal_work_receipts');
        Schema::dropIfExists('ext_titan_ai_workforce_signal_work_rules');
    }
};
