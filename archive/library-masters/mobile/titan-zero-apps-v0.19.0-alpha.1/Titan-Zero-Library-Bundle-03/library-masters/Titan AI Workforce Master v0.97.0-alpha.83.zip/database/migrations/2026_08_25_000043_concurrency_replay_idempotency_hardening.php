<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_operation_ledger')) {
            Schema::create('ext_titan_ai_workforce_operation_ledger', function (Blueprint $table): void {
                $table->id();
                $table->uuid('operation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('operation_key',190);
                $table->string('operation_type',80)->index();
                $table->char('payload_sha256',64)->index();
                $table->string('status',32)->default('PROCESSING')->index();
                $table->string('result_type',100)->nullable();
                $table->string('result_ref',190)->nullable();
                $table->json('result_snapshot')->nullable();
                $table->unsignedInteger('replay_count')->default(0);
                $table->timestamp('started_at')->index();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id','operation_key'],'taiw_operation_ledger_key_unique');
            });
        }

        Schema::table('ext_titan_ai_workforce_processing_checkpoints', function (Blueprint $table): void {
            if (!Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','revision')) {
                $table->unsignedInteger('revision')->default(0)->index();
            }
            if (!Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints','claim_token')) {
                $table->uuid('claim_token')->nullable()->index();
            }
        });

        Schema::table('ext_titan_ai_workforce_domain_handoffs', function (Blueprint $table): void {
            if (!Schema::hasColumn('ext_titan_ai_workforce_domain_handoffs','revision')) {
                $table->unsignedInteger('revision')->default(0)->index();
            }
            if (!Schema::hasColumn('ext_titan_ai_workforce_domain_handoffs','operation_key')) {
                $table->string('operation_key',190)->nullable()->index();
            }
        });

        Schema::table('ext_titan_ai_workforce_recovery_steps', function (Blueprint $table): void {
            if (!Schema::hasColumn('ext_titan_ai_workforce_recovery_steps','revision')) {
                $table->unsignedInteger('revision')->default(0)->index();
            }
            if (!Schema::hasColumn('ext_titan_ai_workforce_recovery_steps','operation_key')) {
                $table->string('operation_key',190)->nullable()->index();
            }
        });
    }

    public function down(): void {
        Schema::table('ext_titan_ai_workforce_recovery_steps', function (Blueprint $table): void {
            foreach(['revision','operation_key'] as $c) if(Schema::hasColumn('ext_titan_ai_workforce_recovery_steps',$c)) $table->dropColumn($c);
        });
        Schema::table('ext_titan_ai_workforce_domain_handoffs', function (Blueprint $table): void {
            foreach(['revision','operation_key'] as $c) if(Schema::hasColumn('ext_titan_ai_workforce_domain_handoffs',$c)) $table->dropColumn($c);
        });
        Schema::table('ext_titan_ai_workforce_processing_checkpoints', function (Blueprint $table): void {
            foreach(['revision','claim_token'] as $c) if(Schema::hasColumn('ext_titan_ai_workforce_processing_checkpoints',$c)) $table->dropColumn($c);
        });
        Schema::dropIfExists('ext_titan_ai_workforce_operation_ledger');
    }
};
