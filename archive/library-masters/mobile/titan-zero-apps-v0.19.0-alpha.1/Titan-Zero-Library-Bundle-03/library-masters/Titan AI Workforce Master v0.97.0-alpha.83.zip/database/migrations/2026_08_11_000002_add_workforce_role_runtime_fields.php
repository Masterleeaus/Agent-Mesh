<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_id')) {
                $table->string('role_definition_id')->nullable()->after('key')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'maturity_level')) {
                $table->string('maturity_level', 24)->default('JUNIOR')->after('role')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'max_concurrent_tasks')) {
                $table->unsignedSmallInteger('max_concurrent_tasks')->default(5)->after('maturity_level');
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'substitution_enabled')) {
                $table->boolean('substitution_enabled')->default(true)->after('max_concurrent_tasks');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            foreach (['role_definition_id','maturity_level','max_concurrent_tasks','substitution_enabled'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_members', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
