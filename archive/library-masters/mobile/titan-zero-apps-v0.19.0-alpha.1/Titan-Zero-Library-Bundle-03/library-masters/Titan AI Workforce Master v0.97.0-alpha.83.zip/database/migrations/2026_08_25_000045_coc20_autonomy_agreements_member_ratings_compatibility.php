<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if(!Schema::hasTable('ext_titan_ai_workforce_autonomy_agreements')){
            Schema::create('ext_titan_ai_workforce_autonomy_agreements',function(Blueprint $table):void{
                $table->id();$table->unsignedBigInteger('company_id')->index();$table->unsignedBigInteger('member_id')->index();
                $table->string('scope_key',190)->default('*')->index();$table->string('requested_level',40)->default('manual');
                $table->string('accepted_level',40)->default('manual');$table->string('effective_level',40)->default('manual');
                $table->timestamp('platform_approved_at')->nullable();$table->timestamp('user_accepted_at')->nullable();
                $table->timestamp('ai_accepted_at')->nullable();$table->timestamp('revoked_at')->nullable()->index();
                $table->json('constraints')->nullable();$table->json('metadata')->nullable();$table->timestamps();
                $table->unique(['company_id','member_id','scope_key'],'twf_autonomy_agreement_scope_unique');
            });
        }
        if(!Schema::hasTable('ext_titan_ai_workforce_member_ratings')){
            Schema::create('ext_titan_ai_workforce_member_ratings',function(Blueprint $table):void{
                $table->id();$table->unsignedBigInteger('company_id')->index();$table->unsignedBigInteger('member_id')->index();
                $table->decimal('score',8,4)->default(50);$table->json('dimensions')->nullable();$table->json('evidence')->nullable();
                $table->timestamp('calculated_at')->nullable()->index();$table->timestamps();
                $table->unique(['company_id','member_id'],'twf_member_rating_company_member_unique');
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_member_ratings');
        Schema::dropIfExists('ext_titan_ai_workforce_autonomy_agreements');
    }
};
