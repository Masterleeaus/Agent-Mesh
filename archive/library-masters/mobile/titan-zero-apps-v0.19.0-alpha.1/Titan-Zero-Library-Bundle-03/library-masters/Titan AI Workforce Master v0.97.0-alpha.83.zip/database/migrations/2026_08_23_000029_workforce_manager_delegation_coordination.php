<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_delegations')) {
            Schema::table('ext_titan_ai_workforce_delegations', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'responsibility_id')) {
                    $table->string('responsibility_id', 255)->nullable()->after('task_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'capability')) {
                    $table->string('capability', 255)->nullable()->after('responsibility_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'review_required')) {
                    $table->boolean('review_required')->default(true)->after('authority_scope')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'reviewer_member_id')) {
                    $table->unsignedBigInteger('reviewer_member_id')->nullable()->after('review_required')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'review_status')) {
                    $table->string('review_status', 40)->default('PENDING')->after('reviewer_member_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'reviewed_at')) {
                    $table->timestamp('reviewed_at')->nullable()->after('review_status');
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'chain_depth')) {
                    $table->unsignedTinyInteger('chain_depth')->default(1)->after('reviewed_at')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_delegations', 'parent_delegation_id')) {
                    $table->unsignedBigInteger('parent_delegation_id')->nullable()->after('chain_depth')->index();
                }
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_workload_snapshots')) {
            Schema::create('ext_titan_ai_workforce_workload_snapshots', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('member_id')->index();
                $table->unsignedInteger('open_work_items')->default(0);
                $table->unsignedInteger('blocked_work_items')->default(0);
                $table->unsignedInteger('critical_path_work_items')->default(0);
                $table->unsignedInteger('estimated_minutes')->default(0);
                $table->unsignedInteger('overdue_work_items')->default(0);
                $table->unsignedTinyInteger('load_score')->default(0)->index();
                $table->string('state', 40)->default('AVAILABLE')->index();
                $table->json('details')->nullable();
                $table->timestamp('observed_at')->index();
                $table->timestamps();
                $table->index(['company_id','member_id','observed_at'], 'twf_workload_member_time_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_workload_snapshots');
        if (Schema::hasTable('ext_titan_ai_workforce_delegations')) {
            Schema::table('ext_titan_ai_workforce_delegations', function (Blueprint $table): void {
                foreach (['parent_delegation_id','chain_depth','reviewed_at','review_status','reviewer_member_id','review_required','capability','responsibility_id'] as $column) {
                    if (Schema::hasColumn('ext_titan_ai_workforce_delegations', $column)) $table->dropColumn($column);
                }
            });
        }
    }
};
