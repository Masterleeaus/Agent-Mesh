<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'lifecycle_state')) $table->string('lifecycle_state', 24)->nullable()->after('status')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'lifecycle_changed_at')) $table->timestamp('lifecycle_changed_at')->nullable()->after('lifecycle_state')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'activated_at')) $table->timestamp('activated_at')->nullable()->after('lifecycle_changed_at');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'suspended_at')) $table->timestamp('suspended_at')->nullable()->after('activated_at');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'retired_at')) $table->timestamp('retired_at')->nullable()->after('suspended_at')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'replaced_by_member_id')) $table->unsignedBigInteger('replaced_by_member_id')->nullable()->after('retired_at')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'lifecycle_metadata')) $table->json('lifecycle_metadata')->nullable()->after('replaced_by_member_id');
        });

        // Backfill conservatively. Existing inactive/suspended staff never gain authority during migration.
        DB::table('ext_titan_ai_workforce_members')->orderBy('id')->chunkById(100, function ($rows): void {
            foreach ($rows as $row) {
                $status = strtoupper((string) ($row->status ?? ''));
                $active = (bool) ($row->is_active ?? false);
                $state = ($active && $status !== 'SUSPENDED') ? 'ACTIVE' : 'SUSPENDED';
                DB::table('ext_titan_ai_workforce_members')->where('id', $row->id)->update([
                    'lifecycle_state' => $state,
                    'lifecycle_changed_at' => $row->updated_at ?? now(),
                    'activated_at' => $state === 'ACTIVE' ? ($row->created_at ?? now()) : null,
                    'suspended_at' => $state === 'SUSPENDED' ? ($row->updated_at ?? now()) : null,
                ]);
            }
        }, 'id');
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            foreach (['lifecycle_metadata','replaced_by_member_id','retired_at','suspended_at','activated_at','lifecycle_changed_at','lifecycle_state'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_members', $column)) $table->dropColumn($column);
            }
        });
    }
};
