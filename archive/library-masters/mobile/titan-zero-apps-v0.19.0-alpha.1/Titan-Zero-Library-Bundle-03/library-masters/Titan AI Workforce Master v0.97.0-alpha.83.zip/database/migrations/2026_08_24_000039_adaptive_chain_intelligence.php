<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_adaptive_chain_profiles')) {
            Schema::create('ext_titan_ai_workforce_adaptive_chain_profiles', function (Blueprint $table): void {
                $table->id();
                $table->uuid('profile_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->string('depth',40)->index();
                $table->unsignedTinyInteger('uncertainty_score')->index();
                $table->unsignedTinyInteger('consequence_score')->index();
                $table->unsignedTinyInteger('reviewer_quality_floor')->default(0);
                $table->boolean('force_assurance')->default(false);
                $table->boolean('force_model_council')->default(false);
                $table->boolean('prefer_provider_diversity')->default(false);
                $table->boolean('mandatory_three_checks')->default(true);
                $table->json('signals')->nullable();
                $table->json('reviewer_requirements')->nullable();
                $table->timestamp('calculated_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id'],'taiw_adaptive_chain_profile_unique');
                $table->foreign('decision_chain_id','taiw_adaptive_chain_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_adaptive_chain_profiles');
    }
};
