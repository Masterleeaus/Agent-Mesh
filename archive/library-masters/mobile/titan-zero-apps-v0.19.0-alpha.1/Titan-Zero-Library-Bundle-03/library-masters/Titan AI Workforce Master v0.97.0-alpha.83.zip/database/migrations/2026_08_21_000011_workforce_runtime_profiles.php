<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_runtime_profiles')) {
            Schema::create('ext_titan_ai_workforce_runtime_profiles', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('profile_id', 120);
                $table->string('name', 160);
                $table->string('persona', 255)->nullable();
                $table->text('system_prompt')->nullable();
                $table->json('provider_policy')->nullable();
                $table->json('model_policy')->nullable();
                $table->json('memory_policy')->nullable();
                $table->json('channel_behavior')->nullable();
                $table->json('informational_tools')->nullable();
                $table->json('reasoning_config')->nullable();
                $table->json('metadata')->nullable();
                $table->char('fingerprint', 64)->index();
                $table->boolean('is_active')->default(true)->index();
                $table->timestamps();
                $table->unique(['company_id', 'profile_id'], 'taiw_runtime_profile_company_id_unique');
            });
        }

        // Additive, no-authority-increase backfill. Existing members receive a
        // proposal-only default profile with zero informational/consequential tools.
        if (Schema::hasTable('ext_titan_ai_workforce_members') && Schema::hasColumn('ext_titan_ai_workforce_members', 'runtime_profile_id')) {
            DB::table('ext_titan_ai_workforce_members')->orderBy('id')->chunkById(100, function ($rows): void {
                foreach ($rows as $row) {
                    $companyId = (int) ($row->company_id ?? 0);
                    if ($companyId < 1) continue;
                    $profileId = trim((string) ($row->runtime_profile_id ?? '')) ?: 'workforce-member-' . (int) $row->id;
                    $provider = $this->jsonArray($row->provider_preferences ?? null);
                    $model = $this->jsonArray($row->model_preferences ?? null);
                    $memoryScopes = $this->jsonArray($row->memory_scopes ?? null);
                    $profile = [
                        'company_id' => $companyId,
                        'profile_id' => $profileId,
                        'name' => trim((string) ($row->name ?? 'Workforce Member')) . ' Runtime Profile',
                        'persona' => trim((string) ($row->role ?? '')) ?: null,
                        'system_prompt' => 'Act as the assigned Titan AI Workforce employee. Stay within the supplied company, employee and task context. Produce reasoning, conversational output and governed proposals only; never claim consequential business execution unless an authoritative result is supplied.',
                        'provider_policy' => json_encode($provider, JSON_UNESCAPED_SLASHES),
                        'model_policy' => json_encode($model, JSON_UNESCAPED_SLASHES),
                        'memory_policy' => json_encode(['enabled' => true, 'include_user_memory' => false, 'history_turns' => 12, 'scopes' => array_values(array_map('strval', $memoryScopes))], JSON_UNESCAPED_SLASHES),
                        'channel_behavior' => json_encode(['mode' => 'workforce', 'allow_surface_override' => false], JSON_UNESCAPED_SLASHES),
                        'informational_tools' => json_encode([], JSON_UNESCAPED_SLASHES),
                        'reasoning_config' => json_encode(['web_search' => false, 'response_mode' => 'json'], JSON_UNESCAPED_SLASHES),
                        'metadata' => json_encode(['owner' => 'titan-ai-workforce', 'binding' => 'workforce-member', 'workforce_member_id' => (int) $row->id, 'consequential_execution_authority' => 'none'], JSON_UNESCAPED_SLASHES),
                        'is_active' => true,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                    $fingerprintInput = $profile;
                    unset($fingerprintInput['created_at'], $fingerprintInput['updated_at']);
                    $profile['fingerprint'] = hash('sha256', json_encode($fingerprintInput, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
                    DB::table('ext_titan_ai_workforce_runtime_profiles')->updateOrInsert(
                        ['company_id' => $companyId, 'profile_id' => $profileId],
                        $profile,
                    );
                    if (trim((string) ($row->runtime_profile_id ?? '')) === '') {
                        DB::table('ext_titan_ai_workforce_members')->where('id', $row->id)->where('company_id', $companyId)->update(['runtime_profile_id' => $profileId]);
                    }
                }
            });
        }
    }

    public function down(): void
    {
        // Keep member.runtime_profile_id values. Removing them would mutate the
        // employee identity binding. Only the additive profile store is removed.
        Schema::dropIfExists('ext_titan_ai_workforce_runtime_profiles');
    }

    /** @return array<int|string,mixed> */
    private function jsonArray(mixed $value): array
    {
        if (is_array($value)) return $value;
        if (! is_string($value) || trim($value) === '') return [];
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }
};
