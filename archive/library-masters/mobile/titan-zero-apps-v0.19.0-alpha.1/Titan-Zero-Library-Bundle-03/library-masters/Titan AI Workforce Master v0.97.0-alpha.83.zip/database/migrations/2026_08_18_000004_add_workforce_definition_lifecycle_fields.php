<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_owner_extension')) $table->string('role_owner_extension')->nullable()->after('role_definition_id')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_owner_extension_version')) $table->string('role_owner_extension_version', 80)->nullable()->after('role_owner_extension');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_version')) $table->string('role_definition_version', 80)->nullable()->after('role_owner_extension_version');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_fingerprint')) $table->string('role_definition_fingerprint', 64)->nullable()->after('role_definition_version')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_state')) $table->string('role_definition_state', 32)->default('ACTIVE')->after('role_definition_fingerprint')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_snapshot')) $table->json('role_definition_snapshot')->nullable()->after('role_definition_state');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_deprecated_at')) $table->timestamp('role_definition_deprecated_at')->nullable()->after('role_definition_snapshot');
            if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'role_definition_grace_until')) $table->timestamp('role_definition_grace_until')->nullable()->after('role_definition_deprecated_at')->index();
        });

        Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_id')) $table->string('role_definition_id')->nullable()->after('manager_member_id')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_owner_extension')) $table->string('role_owner_extension')->nullable()->after('role_definition_id')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_owner_extension_version')) $table->string('role_owner_extension_version', 80)->nullable()->after('role_owner_extension');
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_version')) $table->string('role_definition_version', 80)->nullable()->after('role_owner_extension_version');
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_fingerprint')) $table->string('role_definition_fingerprint', 64)->nullable()->after('role_definition_version')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_state')) $table->string('role_definition_state', 32)->nullable()->after('role_definition_fingerprint')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_snapshot')) $table->json('role_definition_snapshot')->nullable()->after('role_definition_state');
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_deprecated_at')) $table->timestamp('role_definition_deprecated_at')->nullable()->after('role_definition_snapshot');
            if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'role_definition_grace_until')) $table->timestamp('role_definition_grace_until')->nullable()->after('role_definition_deprecated_at');
        });

        // Preserve the role contract already instantiated by pre-Pass-4 staff. We do not
        // fabricate provenance for historical tasks because their assignment-time definition
        // cannot be reconstructed safely after the fact.
        DB::table('ext_titan_ai_workforce_members')
            ->whereNotNull('role_definition_id')
            ->whereNull('role_definition_snapshot')
            ->orderBy('id')
            ->chunkById(100, function ($rows): void {
                foreach ($rows as $row) {
                    $decode = static function (mixed $value): array {
                        if (is_array($value)) return $value;
                        if (! is_string($value) || trim($value) === '') return [];
                        $decoded = json_decode($value, true);
                        return is_array($decoded) ? $decoded : [];
                    };
                    $metadata = $decode($row->metadata ?? null);
                    $snapshot = [
                        'role_id' => (string) ($row->role_definition_id ?? ''),
                        'owner_extension' => (string) ($metadata['owner_extension'] ?? ''),
                        'owner_extension_version' => (string) ($metadata['owner_extension_version'] ?? ''),
                        'tier' => (int) ($row->tier ?? 0),
                        'division' => '',
                        'team' => '',
                        'capabilities' => $decode($row->capabilities ?? null),
                        'tool_access' => is_array($metadata['tool_access'] ?? null) ? $metadata['tool_access'] : [],
                        'workflow_refs' => is_array($metadata['workflow_refs'] ?? null) ? $metadata['workflow_refs'] : [],
                        'risk_ceiling' => (string) ($row->risk_ceiling ?? 'LOW'),
                        'autonomy_profile' => ['starting_score' => null],
                    ];
                    $encoded = json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                    DB::table('ext_titan_ai_workforce_members')->where('id', $row->id)->update([
                        'role_owner_extension' => $snapshot['owner_extension'] !== '' ? $snapshot['owner_extension'] : null,
                        'role_owner_extension_version' => $snapshot['owner_extension_version'] !== '' ? $snapshot['owner_extension_version'] : null,
                        'role_definition_version' => $snapshot['owner_extension_version'] !== '' ? $snapshot['owner_extension_version'] : null,
                        'role_definition_fingerprint' => hash('sha256', (string) $encoded),
                        'role_definition_state' => $snapshot['owner_extension'] !== '' ? 'LEGACY_PINNED' : 'CUSTOM',
                        'role_definition_snapshot' => $encoded,
                    ]);
                }
            }, 'id');
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table) {
            foreach (['role_definition_grace_until','role_definition_deprecated_at','role_definition_snapshot','role_definition_state','role_definition_fingerprint','role_definition_version','role_owner_extension_version','role_owner_extension','role_definition_id'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_tasks', $column)) $table->dropColumn($column);
            }
        });
        Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) {
            foreach (['role_definition_grace_until','role_definition_deprecated_at','role_definition_snapshot','role_definition_state','role_definition_fingerprint','role_definition_version','role_owner_extension_version','role_owner_extension'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_members', $column)) $table->dropColumn($column);
            }
        });
    }
};
