<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_notifications')) {
            Schema::create('ext_titan_ai_workforce_notifications', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('dedupe_key', 64);
                $table->string('category', 100)->index();
                $table->unsignedTinyInteger('severity_score')->default(1)->index();
                $table->unsignedInteger('priority_score')->default(0)->index();
                $table->string('title', 255);
                $table->text('detail')->nullable();
                $table->text('url')->nullable();
                $table->json('audience_scope')->nullable();
                $table->unsignedBigInteger('responsible_manager_member_id')->nullable()->index();
                $table->unsignedBigInteger('team_id')->nullable()->index();
                $table->unsignedInteger('occurrence_count')->default(1);
                $table->boolean('is_active')->default(true)->index();
                $table->timestamp('first_seen_at')->nullable();
                $table->timestamp('last_seen_at')->nullable();
                $table->timestamp('resolved_at')->nullable();
                $table->timestamp('acknowledged_at')->nullable()->index();
                $table->unsignedBigInteger('acknowledged_by')->nullable()->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['company_id','dedupe_key'], 'taiw_notification_company_dedupe_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_notification_preferences')) {
            Schema::create('ext_titan_ai_workforce_notification_preferences', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->unique();
                $table->unsignedTinyInteger('severity_threshold')->default(3);
                $table->boolean('in_app')->default(true);
                $table->boolean('route_owner_admin')->default(true);
                $table->boolean('route_responsible_manager')->default(true);
                $table->boolean('route_specific_team')->default(true);
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_notification_preferences');
        Schema::dropIfExists('ext_titan_ai_workforce_notifications');
    }
};
