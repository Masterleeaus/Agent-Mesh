<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_reviewer_independence')) {
            Schema::create('ext_titan_ai_workforce_reviewer_independence', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->unsignedBigInteger('reviewer_member_id')->index();
                $table->string('runtime_profile_id', 190)->nullable()->index();
                $table->string('provider_key', 120)->nullable()->index();
                $table->string('model_key', 190)->nullable()->index();
                $table->char('runtime_identity_fingerprint', 64)->nullable()->index();
                $table->boolean('member_independent')->default(false);
                $table->boolean('runtime_independent')->default(false);
                $table->boolean('provider_model_independent')->default(false);
                $table->boolean('organisationally_independent')->default(false);
                $table->boolean('eligible')->default(false)->index();
                $table->string('policy_level', 40)->default('STANDARD')->index();
                $table->json('conflicts')->nullable();
                $table->json('evidence')->nullable();
                $table->timestamp('assessed_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id','stage'], 'taiw_reviewer_independence_stage_unique');
                $table->foreign('decision_chain_id', 'taiw_review_ind_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_reviewer_independence');
    }
};
