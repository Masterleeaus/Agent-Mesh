<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ext_titan_ai_workforce_staffing_proposals', function (Blueprint $table) {
            $table->id();
            $table->uuid('proposal_uuid')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('role_definition_id')->index();
            $table->string('role_key')->index();
            $table->string('role_name');
            $table->string('division_key')->index();
            $table->string('reason', 120);
            $table->unsignedInteger('score')->default(0);
            $table->string('risk_ceiling', 16)->default('LOW');
            $table->string('status', 24)->default('RECOMMENDED')->index();
            $table->uuid('trace_id')->index();
            $table->uuid('correlation_id')->index();
            $table->uuid('causation_id')->nullable()->index();
            $table->json('metrics')->nullable();
            $table->json('metadata')->nullable();
            $table->unsignedBigInteger('reviewed_by_user_id')->nullable()->index();
            $table->text('review_reason')->nullable();
            $table->timestamp('recommended_at')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();
            $table->index(['company_id','status'], 'taiw_staffing_company_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_staffing_proposals');
    }
};
