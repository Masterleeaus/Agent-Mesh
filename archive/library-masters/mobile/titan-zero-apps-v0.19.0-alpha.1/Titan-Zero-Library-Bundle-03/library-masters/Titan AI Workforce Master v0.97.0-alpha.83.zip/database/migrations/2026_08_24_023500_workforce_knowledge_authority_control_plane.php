<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'knowledge_preflight')) {
                    $table->json('knowledge_preflight')->nullable()->after('autonomy_snapshot');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')
            && Schema::hasColumn('ext_titan_ai_workforce_tasks', 'knowledge_preflight')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                $table->dropColumn('knowledge_preflight');
            });
        }
    }
};
