<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'capability_owner_extension')) {
                    $table->string('capability_owner_extension', 180)->nullable()->after('capability')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'capability_owner_extension_version')) {
                    $table->string('capability_owner_extension_version', 80)->nullable()->after('capability_owner_extension');
                }
            });
            DB::table('ext_titan_ai_workforce_tasks')
                ->whereNotNull('capability')
                ->whereNull('capability_owner_extension')
                ->whereNotNull('role_owner_extension')
                ->where('role_owner_extension', '!=', 'titan-ai-workforce')
                ->update([
                    'capability_owner_extension' => DB::raw('role_owner_extension'),
                    'capability_owner_extension_version' => DB::raw('role_owner_extension_version'),
                ]);
        }

        if (Schema::hasTable('ext_titan_ai_workforce_actions')) {
            Schema::table('ext_titan_ai_workforce_actions', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_actions', 'capability_owner_extension')) {
                    $table->string('capability_owner_extension', 180)->nullable()->after('capability')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_actions', 'capability_owner_extension_version')) {
                    $table->string('capability_owner_extension_version', 80)->nullable()->after('capability_owner_extension');
                }
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_execution_attempts')) {
            Schema::table('ext_titan_ai_workforce_execution_attempts', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_execution_attempts', 'capability_owner_extension')) {
                    $table->string('capability_owner_extension', 180)->nullable()->after('worker_member_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_execution_attempts', 'capability_owner_extension_version')) {
                    $table->string('capability_owner_extension_version', 80)->nullable()->after('capability_owner_extension');
                }
            });
        }
    }

    public function down(): void
    {
        foreach (['ext_titan_ai_workforce_execution_attempts','ext_titan_ai_workforce_actions','ext_titan_ai_workforce_tasks'] as $tableName) {
            if (! Schema::hasTable($tableName)) continue;
            Schema::table($tableName, function (Blueprint $table) use ($tableName): void {
                foreach (['capability_owner_extension_version','capability_owner_extension'] as $column) {
                    if (Schema::hasColumn($tableName, $column)) $table->dropColumn($column);
                }
            });
        }
    }
};
