<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
 public function up(): void {
  if (!Schema::hasTable('ext_titan_ai_workforce_resource_entitlements')) Schema::create('ext_titan_ai_workforce_resource_entitlements', function(Blueprint $t){
   $t->id(); $t->unsignedBigInteger('company_id')->index(); $t->string('entitlement_key'); $t->string('capability')->nullable(); $t->string('provider')->nullable();
   $t->string('execution_location')->nullable(); $t->string('autonomy_ceiling')->default('assist'); $t->decimal('usage_allowance',18,6)->nullable(); $t->decimal('usage_used',18,6)->default(0);
   $t->decimal('resource_budget',18,6)->nullable(); $t->string('add_on')->nullable(); $t->string('vertical')->nullable(); $t->boolean('enabled')->default(true);
   $t->timestamp('valid_from')->nullable(); $t->timestamp('valid_until')->nullable(); $t->string('source')->default('system'); $t->json('metadata')->nullable(); $t->timestamps();
   $t->unique(['company_id','entitlement_key'],'titan_wf_entitlement_company_key_uq');
  });
  if (!Schema::hasTable('ext_titan_ai_workforce_resource_budgets')) Schema::create('ext_titan_ai_workforce_resource_budgets', function(Blueprint $t){
   $t->id(); $t->unsignedBigInteger('company_id')->index(); $t->string('resource_type'); $t->string('currency',3)->default('USD'); $t->string('period')->default('monthly');
   $t->decimal('soft_limit',18,6)->nullable(); $t->decimal('hard_limit',18,6)->nullable(); $t->decimal('spent_amount',18,6)->default(0); $t->decimal('autonomous_spend_ceiling',18,6)->nullable();
   $t->json('metadata')->nullable(); $t->timestamps(); $t->unique(['company_id','resource_type','period'],'titan_wf_resource_budget_uq');
  });
  if (!Schema::hasTable('ext_titan_ai_workforce_cost_receipts')) Schema::create('ext_titan_ai_workforce_cost_receipts', function(Blueprint $t){
   $t->id(); $t->unsignedBigInteger('company_id')->index(); $t->string('correlation_id')->nullable()->index(); $t->string('actor')->nullable(); $t->string('workforce_role')->nullable(); $t->string('manager')->nullable();
   $t->string('capability'); $t->string('provider'); $t->string('execution_location'); $t->string('cost_owner'); $t->string('resource_type');
   $t->decimal('estimated_cost',18,8)->nullable(); $t->decimal('actual_cost',18,8)->nullable(); $t->string('currency',3)->default('USD'); $t->decimal('billing_units',20,8)->nullable();
   $t->string('billing_unit')->nullable(); $t->string('model')->nullable(); $t->json('usage')->nullable(); $t->string('entitlement_used')->nullable(); $t->string('autonomy_level')->default('assist');
   $t->json('approval')->nullable(); $t->json('outcome')->nullable(); $t->json('metadata')->nullable(); $t->timestamps();
  });
 }
 public function down(): void { Schema::dropIfExists('ext_titan_ai_workforce_cost_receipts'); Schema::dropIfExists('ext_titan_ai_workforce_resource_budgets'); Schema::dropIfExists('ext_titan_ai_workforce_resource_entitlements'); }
};
