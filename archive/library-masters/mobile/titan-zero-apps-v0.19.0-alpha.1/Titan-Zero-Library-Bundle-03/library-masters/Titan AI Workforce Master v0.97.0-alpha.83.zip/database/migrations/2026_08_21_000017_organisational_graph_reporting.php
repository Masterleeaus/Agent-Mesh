<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_relationship_definitions')) {
            Schema::create('ext_titan_ai_workforce_relationship_definitions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('relationship_definition_id', 255)->unique();
                $table->string('source_role_definition_id', 180)->index();
                $table->string('target_role_definition_id', 180)->index();
                $table->string('relationship_type', 40)->index();
                $table->string('definition_scope', 40)->default('INTRINSIC')->index();
                $table->string('activation_rule', 80)->default('when_both_members_active');
                $table->boolean('authority_inherited')->default(false);
                $table->text('rationale')->nullable();
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['source_role_definition_id','target_role_definition_id','relationship_type'], 'taiw_rel_def_edge_unique');
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_relationships')) {
            Schema::table('ext_titan_ai_workforce_relationships', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_relationships', 'relationship_definition_id')) {
                    $table->string('relationship_definition_id', 255)->nullable()->index();
                }
            });
        }

        $path = dirname(__DIR__, 2).'/resources/workforce/organisational-relationships.json';
        $blueprint = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $now = now();
        foreach ((array) ($blueprint['relationships'] ?? []) as $definition) {
            DB::table('ext_titan_ai_workforce_relationship_definitions')->updateOrInsert(
                ['relationship_definition_id' => (string) $definition['relationship_definition_id']],
                [
                    'company_id' => null,
                    'source_role_definition_id' => (string) $definition['source_role_definition_id'],
                    'target_role_definition_id' => (string) $definition['target_role_definition_id'],
                    'relationship_type' => (string) $definition['relationship_type'],
                    'definition_scope' => (string) ($definition['definition_scope'] ?? 'INTRINSIC'),
                    'activation_rule' => (string) ($definition['activation_rule'] ?? 'when_both_members_active'),
                    'authority_inherited' => false,
                    'rationale' => (string) ($definition['rationale'] ?? ''),
                    'status' => 'ACTIVE',
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $now,
                    'updated_at' => $now,
                    'deleted_at' => null,
                ]
            );
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_relationships') && Schema::hasColumn('ext_titan_ai_workforce_relationships', 'relationship_definition_id')) {
            Schema::table('ext_titan_ai_workforce_relationships', function (Blueprint $table): void {
                $table->dropColumn('relationship_definition_id');
            });
        }
        Schema::dropIfExists('ext_titan_ai_workforce_relationship_definitions');
    }
};
