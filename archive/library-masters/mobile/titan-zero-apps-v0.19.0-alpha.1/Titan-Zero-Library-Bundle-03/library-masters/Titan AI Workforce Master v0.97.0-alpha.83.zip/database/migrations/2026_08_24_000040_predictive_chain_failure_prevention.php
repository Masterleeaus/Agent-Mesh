<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_failure_predictions')) {
            Schema::create('ext_titan_ai_workforce_chain_failure_predictions', function (Blueprint $table): void {
                $table->id();
                $table->uuid('prediction_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('failure_probability')->index();
                $table->string('risk_band',40)->index();
                $table->boolean('likely_disagreement')->default(false)->index();
                $table->boolean('likely_authority_denial')->default(false)->index();
                $table->boolean('likely_stall')->default(false)->index();
                $table->boolean('weak_reviewer_pool')->default(false)->index();
                $table->boolean('knowledge_gap_risk')->default(false)->index();
                $table->json('signals')->nullable();
                $table->json('preventive_requirements')->nullable();
                $table->json('wisdom_prediction')->nullable();
                $table->boolean('mandatory_three_checks')->default(true);
                $table->timestamp('predicted_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id'],'taiw_chain_failure_prediction_unique');
                $table->foreign('decision_chain_id','taiw_chain_failure_prediction_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_chain_failure_predictions');
    }
};
