<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_schedules', function (Blueprint $table): void {
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'owner_extension')) $table->string('owner_extension')->nullable()->after('member_id')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'owner_extension_version')) $table->string('owner_extension_version', 80)->nullable()->after('owner_extension');
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'role_definition_id')) $table->string('role_definition_id')->nullable()->after('owner_extension_version')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'role_definition_fingerprint')) $table->string('role_definition_fingerprint', 64)->nullable()->after('role_definition_id');
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'routine_id')) $table->string('routine_id')->nullable()->after('role_definition_fingerprint')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'routine_fingerprint')) $table->string('routine_fingerprint', 64)->nullable()->after('routine_id')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_schedules', 'source_schema_version')) $table->string('source_schema_version', 20)->nullable()->after('routine_fingerprint');
        });
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_schedules', function (Blueprint $table): void {
            foreach (['source_schema_version','routine_fingerprint','routine_id','role_definition_fingerprint','role_definition_id','owner_extension_version','owner_extension'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_schedules', $column)) $table->dropColumn($column);
            }
        });
    }
};
