<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ext_titan_ai_workforce_handoffs', function (Blueprint $table) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'packet_version')) {
                $table->unsignedSmallInteger('packet_version')->nullable()->after('status');
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'packet_sha256')) {
                $table->char('packet_sha256', 64)->nullable()->after('packet_version')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'packet')) {
                $table->json('packet')->nullable()->after('packet_sha256');
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'trace_id')) {
                $table->uuid('trace_id')->nullable()->after('packet')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'correlation_id')) {
                $table->uuid('correlation_id')->nullable()->after('trace_id')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'causation_id')) {
                $table->uuid('causation_id')->nullable()->after('correlation_id')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'decision_version')) {
                $table->unsignedInteger('decision_version')->default(0)->after('causation_id');
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'decision_id')) {
                $table->uuid('decision_id')->nullable()->after('decision_version')->unique();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'accepted_task_id')) {
                $table->unsignedBigInteger('accepted_task_id')->nullable()->after('decision_id')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'decided_by_member_id')) {
                $table->unsignedBigInteger('decided_by_member_id')->nullable()->after('accepted_task_id')->index();
            }
            if (! Schema::hasColumn('ext_titan_ai_workforce_handoffs', 'decision_reason')) {
                $table->text('decision_reason')->nullable()->after('decided_by_member_id');
            }
        });
    }

    public function down(): void
    {
        Schema::table('ext_titan_ai_workforce_handoffs', function (Blueprint $table) {
            foreach (['decision_reason','decided_by_member_id','accepted_task_id','decision_id','decision_version','causation_id','correlation_id','trace_id','packet','packet_sha256','packet_version'] as $column) {
                if (Schema::hasColumn('ext_titan_ai_workforce_handoffs', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
