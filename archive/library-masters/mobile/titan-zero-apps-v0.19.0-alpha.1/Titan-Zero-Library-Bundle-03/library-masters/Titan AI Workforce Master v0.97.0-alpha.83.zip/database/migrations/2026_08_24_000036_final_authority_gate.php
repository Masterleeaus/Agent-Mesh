<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_final_authority_gates')) {
            Schema::create('ext_titan_ai_workforce_final_authority_gates', function (Blueprint $table): void {
                $table->id();
                $table->uuid('gate_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedBigInteger('task_id')->index();
                $table->unsignedBigInteger('actor_member_id')->index();
                $table->boolean('organisationally_approved')->default(false)->index();
                $table->boolean('governance_allowed')->default(false)->index();
                $table->boolean('risk_allowed')->default(false)->index();
                $table->boolean('autonomy_allowed')->default(false)->index();
                $table->boolean('final_allowed')->default(false)->index();
                $table->string('effective_autonomy_level',40)->nullable()->index();
                $table->json('governance_result')->nullable();
                $table->json('risk_result')->nullable();
                $table->json('autonomy_result')->nullable();
                $table->json('policy_result')->nullable();
                $table->json('reason_codes')->nullable();
                $table->timestamp('evaluated_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id'],'taiw_final_authority_processing_unique');
                $table->foreign('decision_chain_id','taiw_final_authority_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_final_authority_gates');
    }
};
