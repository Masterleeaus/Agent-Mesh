<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'member_kind')) $table->string('member_kind', 40)->default('STAFF')->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'system_role_key')) $table->string('system_role_key', 120)->nullable()->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'consumes_seat')) $table->boolean('consumes_seat')->default(true)->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'is_permanent_system_role')) $table->boolean('is_permanent_system_role')->default(false)->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'visibility_scope')) $table->json('visibility_scope')->nullable();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'coordination_permissions')) $table->json('coordination_permissions')->nullable();
            });

            try {
                Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                    $table->unique(['company_id','system_role_key'], 'taiw_member_company_system_role_unique');
                });
            } catch (\Throwable) {
                // Upgrade-safe: an equivalent index may already exist on a partially applied package.
            }
        }

        $definitionPath = dirname(__DIR__, 2) . '/resources/workforce/system-role-definitions.json';
        $definition = json_decode((string) file_get_contents($definitionPath), true, 512, JSON_THROW_ON_ERROR)[0];
        $timestamp = now();
        $fingerprint = hash('sha256', json_encode($definition, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions')) {
            DB::table('ext_titan_ai_workforce_role_definitions')->updateOrInsert(
                ['role_definition_id' => 'titan.system.titan_zero'],
                [
                    'company_id' => null,
                    'key' => 'titan-zero',
                    'name' => 'Titan Zero',
                    'tier' => 1,
                    'division_definition_id' => null,
                    'division_key' => null,
                    'team_key' => null,
                    'purpose' => (string) $definition['purpose'],
                    'reports_to_role_definition_id' => null,
                    'responsibilities' => json_encode($definition['responsibilities'], JSON_THROW_ON_ERROR),
                    'recommended_skills' => json_encode($definition['recommended_skills'], JSON_THROW_ON_ERROR),
                    'vertical_applicability' => json_encode(['all'], JSON_THROW_ON_ERROR),
                    'recommended_business_maturity' => json_encode(['min' => 'SOLO', 'max' => 'ENTERPRISE'], JSON_THROW_ON_ERROR),
                    'activation_rules' => json_encode($definition['activation_rules'], JSON_THROW_ON_ERROR),
                    'risk_ceiling' => 'LOW',
                    'maturity_default' => 'LEAD',
                    'substitution_allowed' => false,
                    'aliases' => json_encode(['chief-of-staff','chief_of_staff','titan-zero'], JSON_THROW_ON_ERROR),
                    'tags' => json_encode(['system','chief-of-staff','owner-facing','non-seat'], JSON_THROW_ON_ERROR),
                    'definition_scope' => 'SYSTEM',
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => 'ACTIVE',
                    'metadata' => json_encode([
                        'system_role' => true,
                        'permanent' => true,
                        'consumes_seat' => false,
                        'owner_facing_interface' => true,
                        'visibility_scope' => $definition['visibility_scope'],
                        'coordination_permissions' => $definition['coordination_permissions'],
                        'executable_capabilities' => [],
                        'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
                        'definition_fingerprint' => $fingerprint,
                    ], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }

        // Existing companies receive the same permanent system identity during upgrade.
        // New companies are idempotently ensured by TitanZeroChiefOfStaffService during Workforce bootstrap.
        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            $companyIds = collect();
            if (Schema::hasTable('ext_titan_ai_workforce_organisations')) {
                $companyIds = $companyIds->merge(DB::table('ext_titan_ai_workforce_organisations')->pluck('company_id'));
            }
            $companyIds = $companyIds->merge(DB::table('ext_titan_ai_workforce_members')->pluck('company_id'));
            if (Schema::hasTable('ext_titan_ai_workforce_divisions')) {
                $companyIds = $companyIds->merge(DB::table('ext_titan_ai_workforce_divisions')->pluck('company_id'));
            }

            foreach ($companyIds->filter()->map(fn ($id) => (int) $id)->unique()->values() as $companyId) {
                $organisationId = null;
                if (Schema::hasTable('ext_titan_ai_workforce_organisations')) {
                    $organisation = DB::table('ext_titan_ai_workforce_organisations')->where('company_id', $companyId)->first();
                    if (! $organisation) {
                        $organisationId = DB::table('ext_titan_ai_workforce_organisations')->insertGetId([
                            'company_id' => $companyId,
                            'key' => 'primary',
                            'name' => 'Workforce Organisation',
                            'status' => 'ACTIVE',
                            'metadata' => json_encode(['definition_source' => 'titan-ai-workforce'], JSON_THROW_ON_ERROR),
                            'created_at' => $timestamp,
                            'updated_at' => $timestamp,
                        ]);
                    } else {
                        $organisationId = (int) $organisation->id;
                    }
                }

                $existingSystem = DB::table('ext_titan_ai_workforce_members')->where('company_id', $companyId)->where('system_role_key', 'titan-zero')->first();
                $memberKey = 'titan-zero';
                $keyCollision = DB::table('ext_titan_ai_workforce_members')->where('company_id', $companyId)->where('key', 'titan-zero')
                    ->when($existingSystem, fn ($q) => $q->where('id', '<>', $existingSystem->id))->exists();
                if ($keyCollision) $memberKey = 'titan-zero-system';

                DB::table('ext_titan_ai_workforce_members')->updateOrInsert(
                    ['company_id' => $companyId, 'system_role_key' => 'titan-zero'],
                    [
                        'organisation_id' => $organisationId,
                        'user_id' => null,
                        'created_by_user_id' => null,
                        'activated_by_user_id' => null,
                        'division_id' => null,
                        'team_id' => null,
                        'manager_id' => null,
                        'tier' => 1,
                        'key' => $memberKey,
                        'name' => 'Titan Zero',
                        'role' => 'Chief of Staff',
                        'purpose' => (string) $definition['purpose'],
                        'responsibilities' => json_encode($definition['responsibilities'], JSON_THROW_ON_ERROR),
                        'goals' => json_encode([], JSON_THROW_ON_ERROR),
                        'capabilities' => json_encode([], JSON_THROW_ON_ERROR),
                        'capability_variants' => json_encode([], JSON_THROW_ON_ERROR),
                        'skills' => json_encode($definition['recommended_skills'], JSON_THROW_ON_ERROR),
                        'risk_ceiling' => 'LOW',
                        'autonomy_references' => json_encode([
                            'authority_source' => 'titan_autonomy', 'initial_band' => 'Suggest', 'initial_score' => 0,
                            'desired_band' => 'Suggest', 'desired_score' => 0, 'self_promotion' => false,
                            'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
                        ], JSON_THROW_ON_ERROR),
                        'assurance_references' => json_encode(['required' => 'AMBER', 'bypass' => false], JSON_THROW_ON_ERROR),
                        'performance_history' => json_encode([], JSON_THROW_ON_ERROR),
                        'status' => 'AVAILABLE',
                        'lifecycle_state' => 'ACTIVE',
                        'lifecycle_changed_at' => $timestamp,
                        'activated_at' => $timestamp,
                        'is_active' => true,
                        'role_definition_id' => 'titan.system.titan_zero',
                        'role_owner_extension' => 'titan-ai-workforce',
                        'role_owner_extension_version' => 'intrinsic-system',
                        'role_definition_version' => (string) ($definition['definition_version'] ?? '1'),
                        'role_definition_fingerprint' => $fingerprint,
                        'role_definition_state' => 'CURRENT',
                        'role_definition_snapshot' => json_encode($definition, JSON_THROW_ON_ERROR),
                        'maturity_level' => 'LEAD',
                        'max_concurrent_tasks' => 1,
                        'substitution_enabled' => false,
                        'member_kind' => 'SYSTEM',
                        'consumes_seat' => false,
                        'is_permanent_system_role' => true,
                        'visibility_scope' => json_encode($definition['visibility_scope'], JSON_THROW_ON_ERROR),
                        'coordination_permissions' => json_encode($definition['coordination_permissions'], JSON_THROW_ON_ERROR),
                        'lifecycle_metadata' => json_encode(['system_role' => true, 'permanent' => true], JSON_THROW_ON_ERROR),
                        'metadata' => json_encode([
                            'definition_source' => 'intrinsic_system_role', 'system_role' => true,
                            'owner_facing_interface' => true, 'chief_of_staff' => true,
                            'coordination_not_domain_execution' => true, 'executable_capabilities' => [],
                            'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
                            'migration_trace_id' => (string) Str::uuid(),
                        ], JSON_THROW_ON_ERROR),
                        'updated_at' => $timestamp,
                        'created_at' => $timestamp,
                        'deleted_at' => null,
                    ]
                );
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            DB::table('ext_titan_ai_workforce_members')->where('system_role_key', 'titan-zero')->delete();
            try {
                Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                    $table->dropUnique('taiw_member_company_system_role_unique');
                });
            } catch (\Throwable) {}
            foreach (['coordination_permissions','visibility_scope','is_permanent_system_role','consumes_seat','system_role_key','member_kind'] as $column) {
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', $column)) continue;
                Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table) use ($column): void { $table->dropColumn($column); });
            }
        }
        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions')) {
            DB::table('ext_titan_ai_workforce_role_definitions')->where('role_definition_id', 'titan.system.titan_zero')->delete();
        }
    }
};
