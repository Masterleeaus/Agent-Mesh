<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_decision_challenges')) {
            Schema::create('ext_titan_ai_workforce_decision_challenges', function (Blueprint $table): void {
                $table->id();
                $table->uuid('challenge_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('challenger_stage')->index();
                $table->unsignedTinyInteger('challenged_stage')->index();
                $table->unsignedBigInteger('challenger_member_id')->index();
                $table->unsignedBigInteger('challenged_member_id')->nullable()->index();
                $table->string('status', 40)->default('OPEN')->index();
                $table->string('challenge_type', 80)->default('MATERIAL_DISAGREEMENT')->index();
                $table->decimal('challenger_confidence', 5, 2)->nullable();
                $table->decimal('challenged_confidence', 5, 2)->nullable();
                $table->decimal('confidence_delta', 5, 2)->nullable();
                $table->json('disputed_claims')->nullable();
                $table->json('evidence_challenges')->nullable();
                $table->json('authority_challenges')->nullable();
                $table->json('requested_information')->nullable();
                $table->text('reason');
                $table->unsignedTinyInteger('rebuttal_count')->default(0);
                $table->unsignedTinyInteger('max_rebuttals')->default(1);
                $table->json('rebuttal')->nullable();
                $table->json('resolution')->nullable();
                $table->timestamp('opened_at')->index();
                $table->timestamp('rebutted_at')->nullable();
                $table->timestamp('resolved_at')->nullable();
                $table->timestamp('escalated_at')->nullable();
                $table->timestamps();

                $table->unique(['company_id','processing_id','challenger_stage'], 'taiw_challenge_stage_unique');
                $table->foreign('decision_chain_id', 'taiw_challenge_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_decision_challenges');
    }
};
