<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_goals')) {
            Schema::create('ext_titan_ai_workforce_goals', function (Blueprint $table): void {
                $table->id();
                $table->uuid('goal_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('owner_member_id')->nullable()->index();
                $table->unsignedBigInteger('manager_member_id')->nullable()->index();
                $table->string('origin_type', 80)->nullable()->index();
                $table->string('origin_id', 190)->nullable();
                $table->string('title');
                $table->text('description')->nullable();
                $table->string('status', 32)->default('PROPOSED')->index();
                $table->unsignedTinyInteger('priority')->default(50)->index();
                $table->json('outcome_target');
                $table->json('success_criteria');
                $table->json('context_refs')->nullable();
                $table->timestamp('target_at')->nullable()->index();
                $table->timestamp('achieved_at')->nullable();
                $table->uuid('trace_id')->index();
                $table->uuid('correlation_id')->index();
                $table->string('idempotency_key')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id','idempotency_key'], 'twf_goal_company_idempotency_unique');
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'goal_id')) {
                    $table->unsignedBigInteger('goal_id')->nullable()->after('company_id')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'work_item_uuid')) {
                    $table->uuid('work_item_uuid')->nullable()->after('task_uuid')->unique();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'responsibility_id')) {
                    $table->string('responsibility_id', 255)->nullable()->after('work_item_uuid')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'verification_state')) {
                    $table->string('verification_state', 40)->default('PENDING')->after('status')->index();
                }
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'outcome_target_key')) {
                    $table->string('outcome_target_key', 190)->nullable()->after('responsibility_id')->index();
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                foreach (['outcome_target_key','verification_state','responsibility_id','work_item_uuid','goal_id'] as $column) {
                    if (Schema::hasColumn('ext_titan_ai_workforce_tasks', $column)) $table->dropColumn($column);
                }
            });
        }
        Schema::dropIfExists('ext_titan_ai_workforce_goals');
    }
};
