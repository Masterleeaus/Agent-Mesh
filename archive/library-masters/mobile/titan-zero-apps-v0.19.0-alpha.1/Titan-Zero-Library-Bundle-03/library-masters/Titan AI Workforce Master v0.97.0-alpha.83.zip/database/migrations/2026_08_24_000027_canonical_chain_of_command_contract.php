<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_decision_chains')) {
            Schema::create('ext_titan_ai_workforce_decision_chains', function (Blueprint $table): void {
                $table->id();
                $table->uuid('chain_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->index();
                $table->uuid('processing_id')->unique();
                $table->unsignedBigInteger('originator_member_id')->index();
                $table->string('origin_domain', 120)->nullable()->index();
                $table->string('processing_domain', 120)->nullable()->index();
                $table->string('receiving_domain', 120)->nullable()->index();
                $table->boolean('consequential')->default(true)->index();
                $table->string('risk_class', 40)->default('ordinary')->index();
                $table->string('state', 40)->default('PENDING_ORIGIN_REVIEW')->index();
                $table->unsignedTinyInteger('current_stage')->default(1)->index();
                $table->unsignedTinyInteger('required_stage_count')->default(3);
                $table->boolean('organisationally_approved')->default(false)->index();
                $table->boolean('authority_gates_ready')->default(false)->index();
                $table->timestamp('approved_at')->nullable();
                $table->timestamp('closed_at')->nullable();
                $table->json('contract_snapshot')->nullable();
                $table->json('knowledge_receipt')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['company_id','task_id','processing_id'], 'taiw_decision_chain_task_processing_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_decision_chain_events')) {
            Schema::create('ext_titan_ai_workforce_decision_chain_events', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->nullable()->index();
                $table->string('event_type', 80)->index();
                $table->unsignedBigInteger('actor_member_id')->nullable()->index();
                $table->string('from_state', 40)->nullable();
                $table->string('to_state', 40)->nullable();
                $table->json('evidence')->nullable();
                $table->timestamp('occurred_at')->index();
                $table->timestamps();
                $table->foreign('decision_chain_id', 'taiw_chain_event_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_decision_chain_events');
        Schema::dropIfExists('ext_titan_ai_workforce_decision_chains');
    }
};
