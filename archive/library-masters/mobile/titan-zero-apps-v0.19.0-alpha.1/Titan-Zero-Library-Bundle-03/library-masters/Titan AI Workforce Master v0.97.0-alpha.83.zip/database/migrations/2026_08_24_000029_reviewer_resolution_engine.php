<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_reviewer_resolutions')) {
            Schema::create('ext_titan_ai_workforce_reviewer_resolutions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->string('stage_role', 80)->index();
                $table->unsignedBigInteger('selected_member_id')->nullable()->index();
                $table->string('selected_role_definition_id', 190)->nullable()->index();
                $table->string('required_domain', 120)->nullable()->index();
                $table->string('required_capability', 190)->nullable()->index();
                $table->string('required_responsibility', 190)->nullable()->index();
                $table->decimal('selection_score', 6, 2)->nullable()->index();
                $table->json('score_breakdown')->nullable();
                $table->json('candidate_evidence')->nullable();
                $table->json('rejection_reasons')->nullable();
                $table->string('status', 40)->default('RESOLVED')->index();
                $table->timestamp('resolved_at')->index();
                $table->timestamps();
                $table->unique(['company_id','processing_id','stage'], 'taiw_reviewer_resolution_stage_unique');
                $table->foreign('decision_chain_id', 'taiw_review_resolution_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_reviewer_resolutions');
    }
};
