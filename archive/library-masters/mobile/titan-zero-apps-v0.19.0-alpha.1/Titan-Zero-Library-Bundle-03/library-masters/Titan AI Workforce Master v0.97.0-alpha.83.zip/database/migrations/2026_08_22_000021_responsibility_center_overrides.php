<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_responsibility_overrides')) return;
        Schema::create('ext_titan_ai_workforce_responsibility_overrides', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->string('responsibility_id', 180)->index();
            $table->unsignedBigInteger('assigned_member_id')->nullable()->index();
            $table->boolean('is_enabled')->default(true)->index();
            $table->json('schedule')->nullable();
            $table->json('trigger_conditions')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->unique(['company_id','responsibility_id'], 'taiw_resp_override_company_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_responsibility_overrides');
    }
};
