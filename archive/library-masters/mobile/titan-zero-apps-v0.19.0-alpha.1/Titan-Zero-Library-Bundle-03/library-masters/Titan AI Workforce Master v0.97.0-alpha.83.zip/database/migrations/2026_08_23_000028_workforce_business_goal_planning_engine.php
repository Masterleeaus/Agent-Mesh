<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_goal_plans')) return;
        Schema::create('ext_titan_ai_workforce_goal_plans', function (Blueprint $table): void {
            $table->id();
            $table->uuid('plan_uuid')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('planner_member_id')->index();
            $table->unsignedBigInteger('goal_id')->nullable()->index();
            $table->string('status', 40)->default('DRAFT')->index();
            $table->string('title', 255);
            $table->json('objective');
            $table->json('assumptions')->nullable();
            $table->json('constraints')->nullable();
            $table->json('plan_payload');
            $table->json('validation_report')->nullable();
            $table->char('plan_fingerprint', 64);
            $table->string('idempotency_key', 190)->nullable();
            $table->timestamp('committed_at')->nullable()->index();
            $table->timestamps();
            $table->softDeletes();
            $table->unique(['company_id','plan_fingerprint'], 'twf_goal_plan_company_fingerprint_unique');
            $table->unique(['company_id','idempotency_key'], 'twf_goal_plan_company_idempotency_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ext_titan_ai_workforce_goal_plans');
    }
};
