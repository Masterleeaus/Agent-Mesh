<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_recovery_plans')) {
            Schema::create('ext_titan_ai_workforce_recovery_plans', function (Blueprint $table): void {
                $table->id();
                $table->uuid('recovery_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('root_decision_chain_id')->index();
                $table->uuid('root_processing_id')->index();
                $table->unsignedBigInteger('federation_id')->nullable()->index();
                $table->unsignedBigInteger('trigger_handoff_id')->nullable()->index();
                $table->string('trigger_type',80)->index();
                $table->string('status',40)->default('PROPOSED')->index();
                $table->unsignedSmallInteger('step_count')->default(0);
                $table->unsignedSmallInteger('verified_step_count')->default(0);
                $table->boolean('manual_intervention_required')->default(false)->index();
                $table->json('trigger_evidence')->nullable();
                $table->timestamp('opened_at')->index();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->foreign('root_decision_chain_id','taiw_recovery_root_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }

        if (!Schema::hasTable('ext_titan_ai_workforce_recovery_steps')) {
            Schema::create('ext_titan_ai_workforce_recovery_steps', function (Blueprint $table): void {
                $table->id();
                $table->uuid('recovery_step_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('recovery_plan_id')->index();
                $table->unsignedSmallInteger('sequence')->index();
                $table->unsignedBigInteger('source_handoff_id')->nullable()->index();
                $table->string('domain',120)->index();
                $table->string('strategy',60)->index();
                $table->string('status',40)->default('PROPOSED')->index();
                $table->string('compensation_capability',190)->nullable()->index();
                $table->uuid('compensation_processing_id')->nullable()->index();
                $table->unsignedBigInteger('compensation_decision_chain_id')->nullable()->index();
                $table->json('proposed_action');
                $table->json('approval_evidence')->nullable();
                $table->json('execution_receipt')->nullable();
                $table->json('verification')->nullable();
                $table->char('receipt_sha256',64)->nullable()->index();
                $table->char('verification_sha256',64)->nullable()->index();
                $table->text('failure_reason')->nullable();
                $table->timestamp('proposed_at')->index();
                $table->timestamp('verified_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id','recovery_plan_id','sequence'],'taiw_recovery_step_sequence_unique');
                $table->foreign('recovery_plan_id','taiw_recovery_step_plan_fk')
                    ->references('id')->on('ext_titan_ai_workforce_recovery_plans')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_recovery_steps');
        Schema::dropIfExists('ext_titan_ai_workforce_recovery_plans');
    }
};
