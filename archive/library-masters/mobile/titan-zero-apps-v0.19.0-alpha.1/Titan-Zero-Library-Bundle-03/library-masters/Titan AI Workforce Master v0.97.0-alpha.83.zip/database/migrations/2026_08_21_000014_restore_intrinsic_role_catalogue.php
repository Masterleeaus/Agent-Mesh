<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_role_definitions')) return;

        Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void {
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'division_definition_id')) $table->string('division_definition_id', 180)->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'reports_to_role_definition_id')) $table->string('reports_to_role_definition_id', 180)->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'responsibilities')) $table->json('responsibilities')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'recommended_skills')) $table->json('recommended_skills')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'vertical_applicability')) $table->json('vertical_applicability')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'recommended_business_maturity')) $table->json('recommended_business_maturity')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'activation_rules')) $table->json('activation_rules')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'risk_ceiling')) $table->string('risk_ceiling', 40)->default('LOW')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'maturity_default')) $table->string('maturity_default', 40)->default('JUNIOR')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'substitution_allowed')) $table->boolean('substitution_allowed')->default(false);
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'aliases')) $table->json('aliases')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'tags')) $table->json('tags')->nullable();
        });

        $path = dirname(__DIR__, 2) . '/resources/workforce/role-definitions.json';
        $definitions = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $timestamp = now();

        foreach ($definitions as $definition) {
            DB::table('ext_titan_ai_workforce_role_definitions')->updateOrInsert(
                ['role_definition_id' => (string) $definition['role_definition_id']],
                [
                    'company_id' => null,
                    'key' => (string) $definition['key'],
                    'name' => (string) $definition['name'],
                    'tier' => (int) $definition['tier'],
                    'division_definition_id' => (string) $definition['division_definition_id'],
                    'division_key' => (string) $definition['division_key'],
                    'team_key' => (string) $definition['team_key'],
                    'purpose' => (string) $definition['purpose'],
                    'reports_to_role_definition_id' => $definition['reports_to_role_definition_id'] ?: null,
                    'responsibilities' => json_encode($definition['responsibilities'], JSON_THROW_ON_ERROR),
                    'recommended_skills' => json_encode($definition['recommended_skills'], JSON_THROW_ON_ERROR),
                    'vertical_applicability' => json_encode($definition['vertical_applicability'], JSON_THROW_ON_ERROR),
                    'recommended_business_maturity' => json_encode($definition['recommended_business_maturity'], JSON_THROW_ON_ERROR),
                    'activation_rules' => json_encode($definition['activation_rules'], JSON_THROW_ON_ERROR),
                    'risk_ceiling' => (string) $definition['risk_ceiling'],
                    'maturity_default' => (string) $definition['maturity_default'],
                    'substitution_allowed' => (bool) $definition['substitution_allowed'],
                    'aliases' => json_encode($definition['aliases'] ?? [], JSON_THROW_ON_ERROR),
                    'tags' => json_encode($definition['tags'] ?? [], JSON_THROW_ON_ERROR),
                    'definition_scope' => 'INTRINSIC',
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => (string) ($definition['status'] ?? 'ACTIVE'),
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_role_definitions')) return;

        $path = dirname(__DIR__, 2) . '/resources/workforce/role-definitions.json';
        if (is_file($path)) {
            $definitions = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            DB::table('ext_titan_ai_workforce_role_definitions')
                ->whereIn('role_definition_id', array_values(array_map(static fn (array $row): string => (string) $row['role_definition_id'], $definitions)))
                ->delete();
        }

        $columns = ['division_definition_id','reports_to_role_definition_id','responsibilities','recommended_skills','vertical_applicability','recommended_business_maturity','activation_rules','risk_ceiling','maturity_default','substitution_allowed','aliases','tags'];
        foreach ($columns as $column) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', $column)) continue;
            Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table) use ($column): void { $table->dropColumn($column); });
        }
    }
};
