<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_role_definitions')) return;

        $executivePath = dirname(__DIR__, 2) . '/resources/workforce/executive-role-definitions.json';
        $hierarchyPath = dirname(__DIR__, 2) . '/resources/workforce/executive-hierarchy.json';
        $rolesPath = dirname(__DIR__, 2) . '/resources/workforce/role-definitions.json';
        $executives = json_decode((string) file_get_contents($executivePath), true, 512, JSON_THROW_ON_ERROR);
        $hierarchy = json_decode((string) file_get_contents($hierarchyPath), true, 512, JSON_THROW_ON_ERROR);
        $roles = json_decode((string) file_get_contents($rolesPath), true, 512, JSON_THROW_ON_ERROR);
        $timestamp = now();

        foreach ($executives as $definition) {
            DB::table('ext_titan_ai_workforce_role_definitions')->updateOrInsert(
                ['role_definition_id' => (string) $definition['role_definition_id']],
                [
                    'company_id' => null,
                    'key' => (string) $definition['key'],
                    'name' => (string) $definition['name'],
                    'tier' => (int) $definition['tier'],
                    'division_definition_id' => null,
                    'division_key' => null,
                    'team_key' => (string) $definition['team_key'],
                    'purpose' => (string) $definition['purpose'],
                    'reports_to_role_definition_id' => (string) $definition['reports_to_role_definition_id'],
                    'responsibilities' => json_encode($definition['responsibilities'], JSON_THROW_ON_ERROR),
                    'recommended_skills' => json_encode($definition['recommended_skills'], JSON_THROW_ON_ERROR),
                    'vertical_applicability' => json_encode($definition['vertical_applicability'], JSON_THROW_ON_ERROR),
                    'recommended_business_maturity' => json_encode($definition['recommended_business_maturity'], JSON_THROW_ON_ERROR),
                    'activation_rules' => json_encode($definition['activation_rules'], JSON_THROW_ON_ERROR),
                    'risk_ceiling' => (string) $definition['risk_ceiling'],
                    'maturity_default' => (string) $definition['maturity_default'],
                    'substitution_allowed' => (bool) $definition['substitution_allowed'],
                    'aliases' => json_encode($definition['aliases'] ?? [], JSON_THROW_ON_ERROR),
                    'tags' => json_encode($definition['tags'] ?? [], JSON_THROW_ON_ERROR),
                    'definition_scope' => 'EXECUTIVE',
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => (string) ($definition['status'] ?? 'ACTIVE'),
                    'metadata' => json_encode(array_merge((array) ($definition['metadata'] ?? []), [
                        'reports_to_system_role' => 'titan.system.titan_zero',
                        'division_manager_role_definition_ids' => $hierarchy['division_manager_role_definition_ids'] ?? [],
                        'executable_capabilities' => [],
                        'bypass' => $definition['bypass'] ?? [],
                    ]), JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }

        foreach ($roles as $definition) {
            DB::table('ext_titan_ai_workforce_role_definitions')
                ->where('role_definition_id', (string) $definition['role_definition_id'])
                ->update([
                    'name' => (string) $definition['name'],
                    'purpose' => (string) $definition['purpose'],
                    'reports_to_role_definition_id' => $definition['reports_to_role_definition_id'] ?: null,
                    'aliases' => json_encode($definition['aliases'] ?? [], JSON_THROW_ON_ERROR),
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'updated_at' => $timestamp,
                ]);
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_role_definitions')) return;

        DB::table('ext_titan_ai_workforce_role_definitions')
            ->where('role_definition_id', 'titan.executive.business_manager')
            ->delete();

        // Restore only the two historically changed reporting/display contracts.
        DB::table('ext_titan_ai_workforce_role_definitions')
            ->where('role_definition_id', 'titan.manager.operations')
            ->update(['reports_to_role_definition_id' => null]);
        DB::table('ext_titan_ai_workforce_role_definitions')
            ->where('role_definition_id', 'titan.operations.chief_of_staff')
            ->update([
                'name' => 'Chief of Staff',
                'reports_to_role_definition_id' => 'titan.manager.operations',
            ]);
    }
};
