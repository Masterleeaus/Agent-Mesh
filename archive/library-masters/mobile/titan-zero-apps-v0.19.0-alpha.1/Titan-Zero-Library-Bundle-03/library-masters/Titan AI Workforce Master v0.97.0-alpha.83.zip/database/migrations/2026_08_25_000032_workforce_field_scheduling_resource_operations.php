<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if(Schema::hasTable('ext_titan_ai_workforce_field_operations_cycles')) return;
        Schema::create('ext_titan_ai_workforce_field_operations_cycles',function(Blueprint $table):void{
            $table->id();$table->uuid('cycle_uuid')->unique();$table->unsignedBigInteger('company_id')->index();
            $table->string('workflow_key',120)->index();$table->unsignedBigInteger('coordinator_member_id')->index();
            $table->unsignedBigInteger('goal_plan_id')->nullable()->index();$table->unsignedBigInteger('goal_id')->nullable()->index();
            $table->string('job_ref',190)->nullable()->index();$table->string('asset_ref',190)->nullable()->index();
            $table->string('status',40)->default('DRAFT')->index();$table->json('assignee_map');
            $table->json('context_refs')->nullable();$table->json('readiness_report')->nullable();$table->json('metadata')->nullable();
            $table->timestamp('started_at')->nullable()->index();$table->timestamp('completed_at')->nullable()->index();
            $table->timestamps();$table->softDeletes();$table->index(['company_id','workflow_key','job_ref'],'twf_field_cycle_lookup');
        });
    }
    public function down(): void { Schema::dropIfExists('ext_titan_ai_workforce_field_operations_cycles'); }
};
