<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_policies')) {
            Schema::create('ext_titan_ai_workforce_chain_policies', function (Blueprint $table): void {
                $table->id();
                $table->uuid('policy_uuid')->unique();
                $table->unsignedBigInteger('company_id')->unique();
                $table->unsignedInteger('revision')->default(1);
                $table->boolean('enabled')->default(true);
                $table->boolean('mandatory_three_checks')->default(true);
                $table->unsignedTinyInteger('minimum_reviewer_quality')->default(0);
                $table->unsignedTinyInteger('high_risk_reviewer_quality')->default(80);
                $table->unsignedTinyInteger('critical_risk_reviewer_quality')->default(85);
                $table->boolean('require_provider_diversity_high_risk')->default(true);
                $table->boolean('require_assurance_high_risk')->default(true);
                $table->boolean('require_model_council_critical')->default(true);
                $table->boolean('require_knowledge_authority')->default(true);
                $table->boolean('require_explicit_evidence_high_risk')->default(true);
                $table->boolean('require_manual_extreme_risk')->default(true);
                $table->boolean('allow_learned_policy')->default(true);
                $table->boolean('allow_predictive_tightening')->default(true);
                $table->boolean('allow_admin_force_approve')->default(false);
                $table->json('federation_paths')->nullable();
                $table->json('recovery_policy')->nullable();
                $table->json('escalation_policy')->nullable();
                $table->json('metadata')->nullable();
                $table->unsignedBigInteger('updated_by_user_id')->nullable()->index();
                $table->timestamp('policy_updated_at')->index();
                $table->timestamps();
            });
        }

        if (!Schema::hasTable('ext_titan_ai_workforce_chain_admin_overrides')) {
            Schema::create('ext_titan_ai_workforce_chain_admin_overrides', function (Blueprint $table): void {
                $table->id();
                $table->uuid('override_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->string('override_type',60)->index();
                $table->string('status',32)->default('ACTIVE')->index();
                $table->text('reason');
                $table->json('evidence_refs')->nullable();
                $table->json('effect')->nullable();
                $table->unsignedBigInteger('created_by_user_id')->index();
                $table->unsignedBigInteger('released_by_user_id')->nullable()->index();
                $table->timestamp('created_at_override')->index();
                $table->timestamp('released_at')->nullable();
                $table->timestamps();
                $table->index(['company_id','processing_id','status'],'taiw_chain_override_active_idx');
                $table->foreign('decision_chain_id','taiw_chain_override_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_chain_admin_overrides');
        Schema::dropIfExists('ext_titan_ai_workforce_chain_policies');
    }
};
