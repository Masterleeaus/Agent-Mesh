<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_responsibilities') || ! Schema::hasTable('ext_titan_ai_workforce_role_responsibilities')) return;

        Schema::table('ext_titan_ai_workforce_responsibilities', function (Blueprint $table): void {
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'division_definition_id')) $table->string('division_definition_id', 180)->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'team_definition_id')) $table->string('team_definition_id', 180)->nullable()->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'accountability_class')) $table->string('accountability_class', 80)->default('ROLE_ACCOUNTABILITY')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'is_executable')) $table->boolean('is_executable')->default(false)->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'capability_authority')) $table->string('capability_authority', 40)->default('NONE')->index();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'vertical_applicability')) $table->json('vertical_applicability')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'recommended_business_maturity')) $table->json('recommended_business_maturity')->nullable();
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', 'definition_version')) $table->string('definition_version', 40)->default('1');
        });

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && ! Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'responsibility_ids')) {
            Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void {
                $table->json('responsibility_ids')->nullable();
            });
        }

        if (! Schema::hasColumn('ext_titan_ai_workforce_role_responsibilities', 'authority_inherited')) {
            Schema::table('ext_titan_ai_workforce_role_responsibilities', function (Blueprint $table): void {
                $table->boolean('authority_inherited')->default(false)->index();
            });
        }

        $root = dirname(__DIR__, 2) . '/resources/workforce/';
        $definitions = json_decode((string) file_get_contents($root . 'responsibility-definitions.json'), true, 512, JSON_THROW_ON_ERROR);
        $assignments = json_decode((string) file_get_contents($root . 'role-responsibility-assignments.json'), true, 512, JSON_THROW_ON_ERROR);
        $roles = json_decode((string) file_get_contents($root . 'role-definitions.json'), true, 512, JSON_THROW_ON_ERROR);
        $timestamp = now();

        foreach ($definitions as $definition) {
            DB::table('ext_titan_ai_workforce_responsibilities')->updateOrInsert(
                ['responsibility_id' => (string) $definition['responsibility_id']],
                [
                    'company_id' => null,
                    'key' => (string) $definition['key'],
                    'name' => (string) $definition['name'],
                    'description' => (string) $definition['description'],
                    'category' => (string) $definition['category'],
                    'division_definition_id' => (string) $definition['division_definition_id'],
                    'team_definition_id' => (string) $definition['team_definition_id'],
                    'accountability_class' => (string) $definition['accountability_class'],
                    'is_executable' => false,
                    'capability_authority' => 'NONE',
                    'vertical_applicability' => json_encode($definition['vertical_applicability'], JSON_THROW_ON_ERROR),
                    'recommended_business_maturity' => json_encode($definition['recommended_business_maturity'], JSON_THROW_ON_ERROR),
                    'definition_scope' => 'INTRINSIC',
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => 'ACTIVE',
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }

        foreach ($assignments as $assignment) {
            DB::table('ext_titan_ai_workforce_role_responsibilities')->updateOrInsert(
                [
                    'role_definition_id' => (string) $assignment['role_definition_id'],
                    'responsibility_id' => (string) $assignment['responsibility_id'],
                    'assignment_type' => (string) $assignment['assignment_type'],
                ],
                [
                    'company_id' => null,
                    'is_required' => (bool) $assignment['is_required'],
                    'sequence' => (int) $assignment['sequence'],
                    'authority_inherited' => false,
                    'metadata' => json_encode($assignment['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                ]
            );
        }

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'responsibility_ids')) {
            foreach ($roles as $role) {
                DB::table('ext_titan_ai_workforce_role_definitions')
                    ->where('role_definition_id', (string) $role['role_definition_id'])
                    ->update([
                        'responsibility_ids' => json_encode($role['responsibility_ids'] ?? [], JSON_THROW_ON_ERROR),
                        'updated_at' => $timestamp,
                    ]);
            }
        }
    }

    public function down(): void
    {
        $root = dirname(__DIR__, 2) . '/resources/workforce/';
        if (is_file($root . 'responsibility-definitions.json')) {
            $definitions = json_decode((string) file_get_contents($root . 'responsibility-definitions.json'), true, 512, JSON_THROW_ON_ERROR);
            $ids = array_values(array_map(static fn (array $row): string => (string) $row['responsibility_id'], $definitions));
            DB::table('ext_titan_ai_workforce_role_responsibilities')->whereIn('responsibility_id', $ids)->delete();
            DB::table('ext_titan_ai_workforce_responsibilities')->whereIn('responsibility_id', $ids)->delete();
        }

        if (Schema::hasTable('ext_titan_ai_workforce_role_definitions') && Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'responsibility_ids')) {
            Schema::table('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void { $table->dropColumn('responsibility_ids'); });
        }
        if (Schema::hasTable('ext_titan_ai_workforce_role_responsibilities') && Schema::hasColumn('ext_titan_ai_workforce_role_responsibilities', 'authority_inherited')) {
            Schema::table('ext_titan_ai_workforce_role_responsibilities', function (Blueprint $table): void { $table->dropColumn('authority_inherited'); });
        }
        foreach (['division_definition_id','team_definition_id','accountability_class','is_executable','capability_authority','vertical_applicability','recommended_business_maturity','definition_version'] as $column) {
            if (! Schema::hasColumn('ext_titan_ai_workforce_responsibilities', $column)) continue;
            Schema::table('ext_titan_ai_workforce_responsibilities', function (Blueprint $table) use ($column): void { $table->dropColumn($column); });
        }
    }
};
