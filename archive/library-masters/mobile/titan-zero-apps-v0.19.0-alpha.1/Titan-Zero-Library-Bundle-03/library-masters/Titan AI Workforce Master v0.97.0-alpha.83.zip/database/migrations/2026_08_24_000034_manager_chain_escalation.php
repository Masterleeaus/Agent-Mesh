<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_escalations')) {
            Schema::create('ext_titan_ai_workforce_chain_escalations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('escalation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->unsignedBigInteger('raised_by_member_id')->nullable()->index();
                $table->unsignedBigInteger('assigned_to_member_id')->nullable()->index();
                $table->unsignedBigInteger('acting_for_member_id')->nullable()->index();
                $table->string('level',40)->index();
                $table->string('reason_code',80)->index();
                $table->string('status',32)->default('OPEN')->index();
                $table->decimal('business_value',14,2)->nullable();
                $table->unsignedTinyInteger('urgency_score')->default(50);
                $table->unsignedTinyInteger('disagreement_count')->default(0);
                $table->json('path')->nullable();
                $table->json('evidence')->nullable();
                $table->timestamp('raised_at')->index();
                $table->timestamp('resolved_at')->nullable();
                $table->timestamps();
                $table->foreign('decision_chain_id','taiw_chain_escalation_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_chain_escalations');
    }
};
