<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_organisations')) {
            Schema::create('ext_titan_ai_workforce_organisations', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->unique();
                $table->string('key', 120)->default('primary');
                $table->string('name', 180)->default('Workforce Organisation');
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_role_definitions')) {
            Schema::create('ext_titan_ai_workforce_role_definitions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('role_definition_id', 180)->unique();
                $table->string('key', 120)->index();
                $table->string('name', 180);
                $table->unsignedTinyInteger('tier')->default(3)->index();
                $table->string('division_key', 120)->nullable()->index();
                $table->string('team_key', 120)->nullable()->index();
                $table->text('purpose')->nullable();
                $table->string('definition_scope', 40)->default('INTRINSIC')->index();
                $table->string('definition_version', 40)->default('1');
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_responsibilities')) {
            Schema::create('ext_titan_ai_workforce_responsibilities', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('responsibility_id', 180)->unique();
                $table->string('key', 120)->index();
                $table->string('name', 180);
                $table->text('description')->nullable();
                $table->string('category', 80)->nullable()->index();
                $table->string('definition_scope', 40)->default('INTRINSIC')->index();
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_role_responsibilities')) {
            Schema::create('ext_titan_ai_workforce_role_responsibilities', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('role_definition_id', 180)->index();
                $table->string('responsibility_id', 180)->index();
                $table->string('assignment_type', 40)->default('PRIMARY')->index();
                $table->boolean('is_required')->default(true);
                $table->unsignedSmallInteger('sequence')->default(100);
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['role_definition_id','responsibility_id','assignment_type'], 'taiw_role_resp_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_actions')) {
            Schema::create('ext_titan_ai_workforce_actions', function (Blueprint $table): void {
                $table->id();
                $table->uuid('action_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->nullable()->index();
                $table->unsignedBigInteger('actor_member_id')->nullable()->index();
                $table->string('action_type', 120)->index();
                $table->string('capability', 180)->nullable()->index();
                $table->string('capability_variant', 180)->nullable();
                $table->string('target_type', 120)->nullable()->index();
                $table->string('target_id', 180)->nullable()->index();
                $table->string('status', 40)->default('PROPOSED')->index();
                $table->string('risk_level', 40)->default('LOW')->index();
                $table->json('payload')->nullable();
                $table->json('governance')->nullable();
                $table->string('idempotency_key', 191)->nullable();
                $table->uuid('trace_id')->nullable()->index();
                $table->uuid('correlation_id')->nullable()->index();
                $table->uuid('causation_id')->nullable()->index();
                $table->timestamps();
                $table->unique(['company_id','idempotency_key'], 'taiw_action_idempotency_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_triggers')) {
            Schema::create('ext_titan_ai_workforce_triggers', function (Blueprint $table): void {
                $table->id();
                $table->uuid('trigger_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('member_id')->nullable()->index();
                $table->string('role_definition_id', 180)->nullable()->index();
                $table->string('key', 160)->index();
                $table->string('name', 180);
                $table->string('trigger_type', 40)->index();
                $table->string('event_type', 180)->nullable()->index();
                $table->string('work_type', 80)->nullable()->index();
                $table->json('conditions')->nullable();
                $table->json('schedule')->nullable();
                $table->json('work_template')->nullable();
                $table->boolean('is_active')->default(true)->index();
                $table->timestamp('last_fired_at')->nullable();
                $table->timestamp('next_fire_at')->nullable()->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['company_id','key'], 'taiw_trigger_company_key_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_councils')) {
            Schema::create('ext_titan_ai_workforce_councils', function (Blueprint $table): void {
                $table->id();
                $table->uuid('council_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('key', 120);
                $table->string('name', 180);
                $table->text('purpose')->nullable();
                $table->string('chair_role_definition_id', 180)->nullable()->index();
                $table->string('decision_authority', 80)->default('none');
                $table->json('schedule')->nullable();
                $table->boolean('is_active')->default(true)->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->unique(['company_id','key'], 'taiw_council_company_key_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_council_memberships')) {
            Schema::create('ext_titan_ai_workforce_council_memberships', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('council_id')->index();
                $table->unsignedBigInteger('member_id')->nullable()->index();
                $table->string('role_definition_id', 180)->nullable()->index();
                $table->string('participation_type', 40)->default('MEMBER')->index();
                $table->boolean('is_active')->default(true);
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['company_id','council_id','member_id','role_definition_id'], 'taiw_council_membership_unique');
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_delegations')) {
            Schema::create('ext_titan_ai_workforce_delegations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('delegation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->nullable()->index();
                $table->unsignedBigInteger('from_member_id')->index();
                $table->unsignedBigInteger('to_member_id')->index();
                $table->string('delegation_type', 40)->default('WORK')->index();
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('authority_scope')->nullable();
                $table->text('reason')->nullable();
                $table->timestamp('expires_at')->nullable()->index();
                $table->timestamp('completed_at')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_escalations')) {
            Schema::create('ext_titan_ai_workforce_escalations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('escalation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->nullable()->index();
                $table->unsignedBigInteger('raised_by_member_id')->nullable()->index();
                $table->unsignedBigInteger('escalated_to_member_id')->nullable()->index();
                $table->string('reason_code', 120)->index();
                $table->string('risk_level', 40)->default('LOW')->index();
                $table->decimal('confidence', 6, 5)->nullable();
                $table->string('status', 40)->default('OPEN')->index();
                $table->json('evidence_refs')->nullable();
                $table->text('recommended_action')->nullable();
                $table->timestamp('resolved_at')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_evidence')) {
            Schema::create('ext_titan_ai_workforce_evidence', function (Blueprint $table): void {
                $table->id();
                $table->uuid('evidence_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->nullable()->index();
                $table->unsignedBigInteger('action_id')->nullable()->index();
                $table->string('subject_type', 120)->nullable()->index();
                $table->string('subject_id', 180)->nullable()->index();
                $table->string('evidence_type', 120)->index();
                $table->string('source_extension', 120)->nullable()->index();
                $table->string('reference', 255)->nullable();
                $table->string('content_sha256', 64)->nullable()->index();
                $table->json('payload')->nullable();
                $table->timestamp('observed_at')->nullable()->index();
                $table->timestamp('created_at')->useCurrent();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_outcomes')) {
            Schema::create('ext_titan_ai_workforce_outcomes', function (Blueprint $table): void {
                $table->id();
                $table->uuid('outcome_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('task_id')->nullable()->index();
                $table->unsignedBigInteger('action_id')->nullable()->index();
                $table->string('subject_type', 120)->nullable()->index();
                $table->string('subject_id', 180)->nullable()->index();
                $table->string('outcome_type', 120)->index();
                $table->string('status', 40)->default('OBSERVED')->index();
                $table->boolean('success')->nullable()->index();
                $table->json('summary')->nullable();
                $table->json('evidence_refs')->nullable();
                $table->timestamp('observed_at')->nullable()->index();
                $table->timestamp('verified_at')->nullable()->index();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('ext_titan_ai_workforce_performance_metrics')) {
            Schema::create('ext_titan_ai_workforce_performance_metrics', function (Blueprint $table): void {
                $table->id();
                $table->uuid('metric_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('member_id')->nullable()->index();
                $table->unsignedBigInteger('team_id')->nullable()->index();
                $table->unsignedBigInteger('division_id')->nullable()->index();
                $table->string('metric_key', 160)->index();
                $table->decimal('metric_value', 20, 6);
                $table->unsignedInteger('sample_size')->default(0);
                $table->timestamp('period_start')->index();
                $table->timestamp('period_end')->index();
                $table->json('context')->nullable();
                $table->timestamps();
            });
        }

        foreach (['ext_titan_ai_workforce_divisions','ext_titan_ai_workforce_teams','ext_titan_ai_workforce_members','ext_titan_ai_workforce_tasks'] as $tableName) {
            if (! Schema::hasTable($tableName) || Schema::hasColumn($tableName, 'organisation_id')) continue;
            Schema::table($tableName, function (Blueprint $table): void {
                $table->unsignedBigInteger('organisation_id')->nullable()->index();
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'created_by_user_id')) $table->unsignedBigInteger('created_by_user_id')->nullable()->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_members', 'activated_by_user_id')) $table->unsignedBigInteger('activated_by_user_id')->nullable()->index();
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'work_type')) $table->string('work_type', 80)->nullable()->index();
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'expected_outcome')) $table->json('expected_outcome')->nullable();
                if (! Schema::hasColumn('ext_titan_ai_workforce_tasks', 'evidence_requirements')) $table->json('evidence_requirements')->nullable();
            });
        }

        $companyIds = collect();
        foreach (['ext_titan_ai_workforce_divisions','ext_titan_ai_workforce_teams','ext_titan_ai_workforce_members','ext_titan_ai_workforce_tasks'] as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'company_id')) {
                $companyIds = $companyIds->merge(DB::table($tableName)->whereNotNull('company_id')->distinct()->pluck('company_id'));
            }
        }
        foreach ($companyIds->filter()->unique()->values() as $companyId) {
            $organisationId = DB::table('ext_titan_ai_workforce_organisations')->where('company_id', $companyId)->value('id');
            if (! $organisationId) {
                $organisationId = DB::table('ext_titan_ai_workforce_organisations')->insertGetId([
                    'company_id' => $companyId,
                    'key' => 'primary',
                    'name' => 'Workforce Organisation',
                    'status' => 'ACTIVE',
                    'metadata' => json_encode(['canonical' => true], JSON_UNESCAPED_SLASHES),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            foreach (['ext_titan_ai_workforce_divisions','ext_titan_ai_workforce_teams','ext_titan_ai_workforce_members','ext_titan_ai_workforce_tasks'] as $tableName) {
                if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'organisation_id')) {
                    DB::table($tableName)->where('company_id', $companyId)->whereNull('organisation_id')->update(['organisation_id' => $organisationId]);
                }
            }
        }

        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            DB::table('ext_titan_ai_workforce_members')->whereNull('created_by_user_id')->whereNotNull('user_id')->update(['created_by_user_id' => DB::raw('user_id')]);
            DB::table('ext_titan_ai_workforce_members')->whereNull('activated_by_user_id')->whereNotNull('user_id')->update(['activated_by_user_id' => DB::raw('user_id')]);
        }

        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            DB::table('ext_titan_ai_workforce_tasks')->where(function ($query): void {
                $query->whereNull('vertical')->orWhere('vertical', '');
            })->orderBy('id')->chunkById(200, function ($rows): void {
                foreach ($rows as $row) {
                    $metadata = json_decode((string) ($row->metadata ?? ''), true);
                    if (! is_array($metadata)) continue;
                    $vertical = trim((string) ($metadata['vertical'] ?? ''));
                    if ($vertical !== '') DB::table('ext_titan_ai_workforce_tasks')->where('id', $row->id)->update(['vertical' => $vertical]);
                }
            });
            DB::table('ext_titan_ai_workforce_tasks')->where(function ($query): void {
                $query->whereNull('workflow_ref')->orWhere('workflow_ref', '');
            })->orderBy('id')->chunkById(200, function ($rows): void {
                foreach ($rows as $row) {
                    $metadata = json_decode((string) ($row->metadata ?? ''), true);
                    if (! is_array($metadata)) continue;
                    $workflow = trim((string) ($metadata['interaction_workflow_ref'] ?? $metadata['workflow_ref'] ?? ''));
                    if ($workflow !== '') DB::table('ext_titan_ai_workforce_tasks')->where('id', $row->id)->update(['workflow_ref' => $workflow]);
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_tasks')) {
            Schema::table('ext_titan_ai_workforce_tasks', function (Blueprint $table): void {
                foreach (['evidence_requirements','expected_outcome','work_type','organisation_id'] as $column) if (Schema::hasColumn('ext_titan_ai_workforce_tasks', $column)) $table->dropColumn($column);
            });
        }
        if (Schema::hasTable('ext_titan_ai_workforce_members')) {
            Schema::table('ext_titan_ai_workforce_members', function (Blueprint $table): void {
                foreach (['activated_by_user_id','created_by_user_id','organisation_id'] as $column) if (Schema::hasColumn('ext_titan_ai_workforce_members', $column)) $table->dropColumn($column);
            });
        }
        foreach (['ext_titan_ai_workforce_teams','ext_titan_ai_workforce_divisions'] as $tableName) {
            if (Schema::hasTable($tableName) && Schema::hasColumn($tableName, 'organisation_id')) {
                Schema::table($tableName, function (Blueprint $table): void { $table->dropColumn('organisation_id'); });
            }
        }
        foreach ([
            'ext_titan_ai_workforce_performance_metrics','ext_titan_ai_workforce_outcomes','ext_titan_ai_workforce_evidence',
            'ext_titan_ai_workforce_escalations','ext_titan_ai_workforce_delegations','ext_titan_ai_workforce_council_memberships',
            'ext_titan_ai_workforce_councils','ext_titan_ai_workforce_triggers','ext_titan_ai_workforce_actions',
            'ext_titan_ai_workforce_role_responsibilities','ext_titan_ai_workforce_responsibilities','ext_titan_ai_workforce_role_definitions',
            'ext_titan_ai_workforce_organisations',
        ] as $tableName) Schema::dropIfExists($tableName);
    }
};
