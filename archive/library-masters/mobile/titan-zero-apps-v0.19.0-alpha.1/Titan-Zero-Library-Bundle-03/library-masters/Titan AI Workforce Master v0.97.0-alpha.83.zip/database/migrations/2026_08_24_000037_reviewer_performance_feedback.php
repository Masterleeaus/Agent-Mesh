<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_reviewer_feedback')) {
            Schema::create('ext_titan_ai_workforce_reviewer_feedback', function (Blueprint $table): void {
                $table->id();
                $table->uuid('feedback_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('processing_id')->index();
                $table->unsignedTinyInteger('stage')->index();
                $table->unsignedBigInteger('reviewer_member_id')->index();
                $table->string('event_type',80)->index();
                $table->decimal('quality_score',6,2)->index();
                $table->decimal('evidence_quality_score',6,2)->nullable();
                $table->decimal('judgement_score',6,2)->nullable();
                $table->decimal('escalation_score',6,2)->nullable();
                $table->decimal('risk_detection_score',6,2)->nullable();
                $table->boolean('verified_outcome')->default(false)->index();
                $table->boolean('overturned')->default(false)->index();
                $table->boolean('missed_risk')->default(false)->index();
                $table->boolean('unnecessary_escalation')->default(false)->index();
                $table->json('evidence')->nullable();
                $table->timestamp('observed_at')->index();
                $table->timestamps();
                $table->foreign('decision_chain_id','taiw_reviewer_feedback_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
                $table->index(['company_id','reviewer_member_id','observed_at'],'taiw_reviewer_feedback_member_time_idx');
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_reviewer_feedback');
    }
};
