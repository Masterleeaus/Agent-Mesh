<?php
declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('ext_titan_ai_workforce_chain_federations')) {
            Schema::create('ext_titan_ai_workforce_chain_federations', function (Blueprint $table): void {
                $table->id();
                $table->uuid('federation_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->unique();
                $table->uuid('root_processing_id')->index();
                $table->json('domain_path');
                $table->unsignedSmallInteger('handoff_count')->default(0);
                $table->unsignedSmallInteger('accepted_handoff_count')->default(0);
                $table->string('status',40)->default('PENDING')->index();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
                $table->foreign('decision_chain_id','taiw_chain_federation_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }

        if (!Schema::hasTable('ext_titan_ai_workforce_domain_handoffs')) {
            Schema::create('ext_titan_ai_workforce_domain_handoffs', function (Blueprint $table): void {
                $table->id();
                $table->uuid('handoff_uuid')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('federation_id')->index();
                $table->unsignedBigInteger('decision_chain_id')->index();
                $table->uuid('root_processing_id')->index();
                $table->unsignedSmallInteger('sequence')->index();
                $table->string('from_domain',120)->index();
                $table->string('to_domain',120)->index();
                $table->string('status',40)->default('PENDING')->index();
                $table->unsignedBigInteger('accepted_by_member_id')->nullable()->index();
                $table->unsignedBigInteger('source_checkpoint_id')->nullable()->index();
                $table->char('incoming_state_sha256',64)->nullable()->index();
                $table->char('acceptance_sha256',64)->nullable()->index();
                $table->json('incoming_state')->nullable();
                $table->json('acceptance')->nullable();
                $table->json('knowledge_authority_receipt')->nullable();
                $table->timestamp('offered_at')->nullable();
                $table->timestamp('accepted_at')->nullable();
                $table->timestamp('rejected_at')->nullable();
                $table->timestamps();
                $table->unique(['company_id','federation_id','sequence'],'taiw_domain_handoff_sequence_unique');
                $table->foreign('federation_id','taiw_domain_handoff_federation_fk')
                    ->references('id')->on('ext_titan_ai_workforce_chain_federations')->cascadeOnDelete();
                $table->foreign('decision_chain_id','taiw_domain_handoff_chain_fk')
                    ->references('id')->on('ext_titan_ai_workforce_decision_chains')->cascadeOnDelete();
            });
        }
    }

    public function down(): void {
        Schema::dropIfExists('ext_titan_ai_workforce_domain_handoffs');
        Schema::dropIfExists('ext_titan_ai_workforce_chain_federations');
    }
};
