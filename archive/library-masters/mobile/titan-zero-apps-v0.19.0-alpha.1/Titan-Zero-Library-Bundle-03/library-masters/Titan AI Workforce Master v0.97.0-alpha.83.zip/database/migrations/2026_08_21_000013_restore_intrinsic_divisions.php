<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ext_titan_ai_workforce_division_definitions')) {
            Schema::create('ext_titan_ai_workforce_division_definitions', function (Blueprint $table): void {
                $table->id();
                $table->string('division_definition_id', 180)->unique();
                $table->string('key', 120)->unique();
                $table->string('name', 180);
                $table->text('purpose');
                $table->string('manager_role_definition_id', 180)->index();
                $table->json('team_boundaries');
                $table->json('applicability');
                $table->json('activation_rules');
                $table->string('definition_version', 40)->default('1');
                $table->string('status', 40)->default('ACTIVE')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (Schema::hasTable('ext_titan_ai_workforce_divisions') && ! Schema::hasColumn('ext_titan_ai_workforce_divisions', 'division_definition_id')) {
            Schema::table('ext_titan_ai_workforce_divisions', function (Blueprint $table): void {
                $table->string('division_definition_id', 180)->nullable()->index();
            });
        }

        $path = dirname(__DIR__, 2) . '/resources/workforce/division-definitions.json';
        $definitions = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $timestamp = now();

        foreach ($definitions as $definition) {
            DB::table('ext_titan_ai_workforce_division_definitions')->updateOrInsert(
                ['division_definition_id' => (string) $definition['division_definition_id']],
                [
                    'key' => (string) $definition['key'],
                    'name' => (string) $definition['name'],
                    'purpose' => (string) $definition['purpose'],
                    'manager_role_definition_id' => (string) $definition['manager_role_definition_id'],
                    'team_boundaries' => json_encode($definition['team_boundaries'], JSON_THROW_ON_ERROR),
                    'applicability' => json_encode($definition['applicability'], JSON_THROW_ON_ERROR),
                    'activation_rules' => json_encode($definition['activation_rules'], JSON_THROW_ON_ERROR),
                    'definition_version' => (string) ($definition['definition_version'] ?? '1'),
                    'status' => (string) ($definition['status'] ?? 'ACTIVE'),
                    'metadata' => json_encode($definition['metadata'] ?? [], JSON_THROW_ON_ERROR),
                    'created_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'deleted_at' => null,
                ]
            );
        }

        if (Schema::hasTable('ext_titan_ai_workforce_divisions') && Schema::hasColumn('ext_titan_ai_workforce_divisions', 'division_definition_id')) {
            foreach ($definitions as $definition) {
                DB::table('ext_titan_ai_workforce_divisions')
                    ->where('key', (string) $definition['key'])
                    ->whereNull('division_definition_id')
                    ->update(['division_definition_id' => (string) $definition['division_definition_id']]);
            }
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('ext_titan_ai_workforce_divisions') && Schema::hasColumn('ext_titan_ai_workforce_divisions', 'division_definition_id')) {
            Schema::table('ext_titan_ai_workforce_divisions', function (Blueprint $table): void {
                $table->dropColumn('division_definition_id');
            });
        }

        Schema::dropIfExists('ext_titan_ai_workforce_division_definitions');
    }
};
