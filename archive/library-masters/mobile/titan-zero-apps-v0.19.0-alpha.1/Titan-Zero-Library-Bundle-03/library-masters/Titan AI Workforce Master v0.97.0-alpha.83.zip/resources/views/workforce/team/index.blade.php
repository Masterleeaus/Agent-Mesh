@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Organisation Map'))
@section('titlebar_subtitle', __('Interactive view of divisions, teams, reporting, coordination and live capability health.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php($map = $organisationMap)
@php($relationshipLabels = [
    'reports_to' => __('Reporting'), 'manages' => __('Management'), 'substitutes_for' => __('Deputy'),
    'delegates_to' => __('Delegation'), 'escalates_to' => __('Escalation'), 'coordinates' => __('Coordination'),
    'collaborates_with' => __('Collaboration'), 'hands_off_to' => __('Handoff'), 'consults' => __('Consults'),
    'informs' => __('Informs'), 'reviews_for' => __('Review'),
])
<div class="px-5 py-8 space-y-6" data-workforce-org-map>
    <section class="rounded-2xl border bg-card p-5">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <div class="text-xs font-semibold uppercase tracking-[.16em] text-foreground/45">{{ __('Organisation health') }}</div>
                <h1 class="mt-1 text-2xl font-semibold">{{ __('Interactive Organisation Map') }}</h1>
                <p class="mt-2 max-w-3xl text-sm text-foreground/60">{{ __('Reporting lines and coordination relationships never grant authority. Capability badges show current provider availability only.') }}</p>
            </div>
            <div class="grid grid-cols-3 gap-2 sm:grid-cols-6">
                @foreach([
                    [__('Staff'), data_get($map,'summary.staff',0)], [__('Managers'), data_get($map,'summary.managers',0)], [__('Specialists'), data_get($map,'summary.specialists',0)],
                    [__('Degraded'), data_get($map,'summary.degraded',0)], [__('Overloaded'), data_get($map,'summary.overloaded',0)], [__('Missing manager'), data_get($map,'summary.missing_manager',0)],
                ] as [$label,$value])
                <div class="min-w-24 rounded-xl border px-3 py-2 text-center"><div class="text-lg font-semibold">{{ $value }}</div><div class="text-[10px] uppercase tracking-wide text-foreground/45">{{ $label }}</div></div>
                @endforeach
            </div>
        </div>
    </section>

    <section class="rounded-2xl border bg-card p-5">
        <div class="flex flex-wrap items-center justify-between gap-3"><div><h2 class="text-lg font-semibold">{{ __('Map filters') }}</h2><p class="text-xs text-foreground/50">{{ __('Combine filters to isolate organisational risk, workload or provider dependencies.') }}</p></div><button type="button" class="rounded-lg border px-3 py-2 text-xs" data-reset-filters>{{ __('Reset filters') }}</button></div>
        <div class="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
            <label class="text-xs text-foreground/55">{{ __('Division') }}<select class="mt-1 w-full rounded-lg border bg-transparent px-3 py-2 text-sm" data-filter="division"><option value="">{{ __('All divisions') }}</option>@foreach(data_get($map,'filters.divisions',[]) as $item)<option value="{{ $item['id'] }}">{{ $item['name'] }}</option>@endforeach</select></label>
            <label class="text-xs text-foreground/55">{{ __('Team') }}<select class="mt-1 w-full rounded-lg border bg-transparent px-3 py-2 text-sm" data-filter="team"><option value="">{{ __('All teams') }}</option>@foreach(data_get($map,'filters.teams',[]) as $item)<option value="{{ $item['id'] }}">{{ $item['name'] }}</option>@endforeach</select></label>
            <label class="text-xs text-foreground/55">{{ __('Role') }}<select class="mt-1 w-full rounded-lg border bg-transparent px-3 py-2 text-sm" data-filter="role"><option value="">{{ __('All roles') }}</option>@foreach(data_get($map,'filters.roles',[]) as $role)<option value="{{ $role }}">{{ $role }}</option>@endforeach</select></label>
            <label class="text-xs text-foreground/55">{{ __('Lifecycle') }}<select class="mt-1 w-full rounded-lg border bg-transparent px-3 py-2 text-sm" data-filter="lifecycle"><option value="">{{ __('All lifecycle states') }}</option>@foreach(data_get($map,'filters.lifecycles',[]) as $state)<option value="{{ $state }}">{{ $state }}</option>@endforeach</select></label>
            <label class="text-xs text-foreground/55">{{ __('Provider dependency') }}<select class="mt-1 w-full rounded-lg border bg-transparent px-3 py-2 text-sm" data-filter="provider"><option value="">{{ __('Any provider') }}</option>@foreach(data_get($map,'filters.providers',[]) as $provider)<option value="{{ $provider }}">{{ $provider }}</option>@endforeach</select></label>
        </div>
        <div class="mt-4 flex flex-wrap gap-2">
            <label class="inline-flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs"><input type="checkbox" data-flag-filter="degraded"> {{ __('Degraded staff') }}</label>
            <label class="inline-flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs"><input type="checkbox" data-flag-filter="overloaded"> {{ __('Overloaded staff') }}</label>
            <label class="inline-flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs"><input type="checkbox" data-flag-filter="missing-manager"> {{ __('Missing manager') }}</label>
        </div>
    </section>

    <section class="rounded-2xl border bg-card p-5">
        <div class="flex flex-wrap items-center justify-between gap-3"><div><h2 class="text-lg font-semibold">{{ __('Relationship overlays') }}</h2><p class="text-xs text-foreground/50">{{ __('Reporting, deputies, delegation, escalation and cross-team coordination are represented as separate organisational edges.') }}</p></div><span class="text-xs text-foreground/45"><span data-visible-count>{{ data_get($map,'summary.staff',0) }}</span> {{ __('staff visible') }}</span></div>
        <div class="mt-4 flex flex-wrap gap-2" data-edge-controls>
            @foreach($relationshipLabels as $type => $label)
                @if((data_get($map,'edge_counts.'.$type,0) ?? 0) > 0)
                <label class="inline-flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs"><input type="checkbox" value="{{ $type }}" data-edge-toggle @checked(in_array($type,['reports_to','substitutes_for','delegates_to','escalates_to','coordinates','collaborates_with']))> {{ $label }} <span class="text-foreground/40">{{ data_get($map,'edge_counts.'.$type,0) }}</span></label>
                @endif
            @endforeach
        </div>
        <div class="mt-4 grid gap-2 lg:grid-cols-2 xl:grid-cols-3" data-edge-list>
            @foreach(data_get($map,'edges',[]) as $edge)
                @php($from = collect(data_get($map,'members',[]))->firstWhere('id',$edge['from_member_id']))
                @php($to = collect(data_get($map,'members',[]))->firstWhere('id',$edge['to_member_id']))
                @continue(!$from || !$to)
                <div class="hidden rounded-lg border px-3 py-2 text-xs" data-edge-row data-edge-type="{{ $edge['type'] }}" data-from="{{ $edge['from_member_id'] }}" data-to="{{ $edge['to_member_id'] }}">
                    <span class="font-medium">{{ $from['name'] }}</span><span class="mx-2 text-foreground/35">→</span><span class="font-medium">{{ $to['name'] }}</span>
                    <div class="mt-1 flex flex-wrap gap-2 text-[10px] text-foreground/45"><span>{{ $relationshipLabels[$edge['type']] ?? $edge['type'] }}</span><span>{{ $edge['source'] }}</span>@if(data_get($edge,'metadata.cross_team'))<span>{{ __('cross-team') }}</span>@endif</div>
                </div>
            @endforeach
        </div>
    </section>

    <div class="space-y-8" data-org-canvas>
        @forelse(data_get($map,'divisions',[]) as $division)
        <section class="rounded-2xl border bg-card p-5" data-division-card data-division="{{ $division['id'] }}">
            <div class="flex flex-wrap items-start justify-between gap-3"><div><div class="text-[10px] font-semibold uppercase tracking-[.18em] text-foreground/40">{{ __('Division') }}</div><h2 class="text-xl font-semibold"><a class="hover:underline" href="{{ route('dashboard.user.titan-workforce.divisions.show', $division['id']) }}">{{ $division['name'] }}</a></h2><p class="mt-1 max-w-3xl text-sm text-foreground/55">{{ $division['purpose'] }}</p></div><span class="rounded-full bg-foreground/5 px-3 py-1 text-xs" data-division-count></span></div>
            <div class="mt-5 grid gap-5 xl:grid-cols-2 2xl:grid-cols-3">
                @foreach($division['teams'] as $team)
                <div class="rounded-xl border bg-background/30 p-4" data-team-card data-team="{{ $team['id'] }}">
                    <div class="mb-4 flex items-center justify-between"><div><div class="text-[10px] uppercase tracking-[.16em] text-foreground/40">{{ __('Team') }}</div><h3 class="font-semibold"><a class="hover:underline" href="{{ route('dashboard.user.titan-workforce.teams.show', $team['id']) }}">{{ $team['name'] }}</a></h3></div><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px]" data-team-count></span></div>
                    <div class="space-y-3">
                        @foreach($team['members'] as $member)
                        @php($providers = implode('|',$member['providers']))
                        @php($degraded = $member['capability_state'] !== 'available')
                        <article class="relative rounded-xl border p-4 transition hover:-translate-y-0.5 hover:shadow-sm" data-member-node
                            data-member-id="{{ $member['id'] }}" data-division="{{ $member['division_id'] }}" data-team="{{ $member['team_id'] }}" data-role="{{ e($member['role']) }}" data-lifecycle="{{ $member['lifecycle'] }}" data-providers="{{ e($providers) }}"
                            data-degraded="{{ $degraded ? '1':'0' }}" data-overloaded="{{ $member['overloaded'] ? '1':'0' }}" data-missing-manager="{{ $member['missing_manager'] ? '1':'0' }}">
                            <div class="absolute -left-1 top-1/2 h-px w-1 bg-foreground/20"></div>
                            <div class="flex items-start justify-between gap-3">
                                <div class="min-w-0"><a href="{{ route('dashboard.user.titan-workforce.staff.show', $member['id']) }}" class="font-semibold hover:underline">{{ $member['name'] }}</a><div class="truncate text-sm text-foreground/55">{{ $member['role'] }}</div></div>
                                <div class="flex flex-wrap justify-end gap-1">
                                    @include('titan-ai-workforce::components.capability-health-badge',['state'=>$member['capability_state'],'memberId'=>$member['id']])
                                    @if($member['overloaded'])<span class="rounded-full bg-red-500/10 px-2 py-1 text-[10px] font-semibold text-red-700 dark:text-red-300">{{ __('Overloaded') }}</span>@endif
                                    @if($member['missing_manager'])<span class="rounded-full bg-red-500/10 px-2 py-1 text-[10px] font-semibold text-red-700 dark:text-red-300">{{ __('No manager') }}</span>@endif
                                </div>
                            </div>
                            <div class="mt-3 grid grid-cols-2 gap-2 text-[11px]">
                                <div><div class="text-foreground/40">{{ __('Type') }}</div><div>{{ $member['tier_label'] }}</div></div>
                                <div><div class="text-foreground/40">{{ __('Lifecycle') }}</div><div>{{ $member['lifecycle'] }}</div></div>
                                <div><div class="text-foreground/40">{{ __('Reports to') }}</div><div>{{ $member['manager_name'] ?: __('Owner / executive layer') }}</div></div>
                                <div><div class="text-foreground/40">{{ __('Workload') }}</div><div>{{ $member['open_work'] }} / {{ $member['capacity'] }}</div></div>
                            </div>
                            @if($member['provider_states'])
                            <div class="mt-3 flex flex-wrap gap-1" title="{{ __('Live provider dependencies') }}">
                                @foreach($member['provider_states'] as $provider => $state)<span class="max-w-full truncate rounded border px-1.5 py-0.5 text-[9px] {{ $state==='available' ? 'text-foreground/55' : 'border-amber-500/30 bg-amber-500/5 text-amber-700 dark:text-amber-300' }}">{{ $provider }} · {{ $state }}</span>@endforeach
                            </div>
                            @endif
                            <div class="mt-3 flex items-center justify-between border-t pt-3 text-[10px] text-foreground/45"><span>{{ $member['status'] }}</span><a href="{{ route('dashboard.user.titan-workforce.staff.show', $member['id']) }}" class="font-medium text-foreground/70 hover:underline">{{ __('Open Employee 360 →') }}</a></div>
                        </article>
                        @endforeach
                    </div>
                </div>
                @endforeach
            </div>
        </section>
        @empty
        <div class="rounded-xl border border-dashed p-8 text-center text-sm text-foreground/60">{{ __('No Workforce organisation has been configured yet.') }}</div>
        @endforelse
    </div>

    <div class="hidden rounded-xl border border-dashed p-8 text-center text-sm text-foreground/60" data-empty-filter>{{ __('No staff match the current organisation-map filters.') }}</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('[data-workforce-org-map]'); if (!root) return;
    const filters = Object.fromEntries([...root.querySelectorAll('[data-filter]')].map(el => [el.dataset.filter, el]));
    const flags = Object.fromEntries([...root.querySelectorAll('[data-flag-filter]')].map(el => [el.dataset.flagFilter, el]));
    const nodes = [...root.querySelectorAll('[data-member-node]')];
    const edgeToggles = [...root.querySelectorAll('[data-edge-toggle]')];
    const edgeRows = [...root.querySelectorAll('[data-edge-row]')];
    const visibleCount = root.querySelector('[data-visible-count]');
    const empty = root.querySelector('[data-empty-filter]');
    const activeMemberIds = () => new Set(nodes.filter(n => !n.classList.contains('hidden')).map(n => n.dataset.memberId));

    function apply() {
        let count = 0;
        nodes.forEach(node => {
            const providerList = (node.dataset.providers || '').split('|').filter(Boolean);
            const show = (!filters.division.value || node.dataset.division === filters.division.value)
                && (!filters.team.value || node.dataset.team === filters.team.value)
                && (!filters.role.value || node.dataset.role === filters.role.value)
                && (!filters.lifecycle.value || node.dataset.lifecycle === filters.lifecycle.value)
                && (!filters.provider.value || providerList.includes(filters.provider.value))
                && (!flags.degraded.checked || node.dataset.degraded === '1')
                && (!flags.overloaded.checked || node.dataset.overloaded === '1')
                && (!flags['missing-manager'].checked || node.dataset.missingManager === '1');
            node.classList.toggle('hidden', !show); if (show) count++;
        });
        root.querySelectorAll('[data-team-card]').forEach(team => {
            const c = team.querySelectorAll('[data-member-node]:not(.hidden)').length;
            team.classList.toggle('hidden', c === 0); const badge=team.querySelector('[data-team-count]'); if(badge) badge.textContent = `${c} staff`;
        });
        root.querySelectorAll('[data-division-card]').forEach(div => {
            const c = div.querySelectorAll('[data-member-node]:not(.hidden)').length;
            div.classList.toggle('hidden', c === 0); const badge=div.querySelector('[data-division-count]'); if(badge) badge.textContent = `${c} visible`;
        });
        if (visibleCount) visibleCount.textContent = count; if (empty) empty.classList.toggle('hidden', count !== 0);
        applyEdges();
    }
    function applyEdges() {
        const enabled = new Set(edgeToggles.filter(t => t.checked).map(t => t.value)); const ids = activeMemberIds();
        edgeRows.forEach(row => row.classList.toggle('hidden', !enabled.has(row.dataset.edgeType) || !ids.has(row.dataset.from) || !ids.has(row.dataset.to)));
    }
    [...Object.values(filters), ...Object.values(flags)].forEach(el => el.addEventListener('change', apply));
    edgeToggles.forEach(el => el.addEventListener('change', applyEdges));
    root.querySelector('[data-reset-filters]')?.addEventListener('click', () => { Object.values(filters).forEach(el => el.value=''); Object.values(flags).forEach(el => el.checked=false); apply(); });
    apply();
});
</script>
@endsection
