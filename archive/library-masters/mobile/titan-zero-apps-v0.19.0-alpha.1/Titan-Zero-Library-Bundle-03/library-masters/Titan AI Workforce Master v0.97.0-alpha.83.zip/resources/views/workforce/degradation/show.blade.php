@extends('panel.layout.app')
@section('title', __('Safe Degradation'))
@section('content')
@php($m=$degradation['member'])
@php($status=$degradation['status'])
<div class="container-fluid py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><div class="small text-muted">{{ __('Employee capability health') }}</div><h1 class="mb-1">{{ $m->name }}</h1><p class="text-muted mb-0">{{ $m->role }} · {{ $m->division?->name }} · {{ $m->team?->name }}</p></div>
    <div class="d-flex gap-2"><a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan-workforce.staff.show',$m) }}">{{ __('Employee 360') }}</a>@include('titan-ai-workforce::components.capability-health-badge',['state'=>$degradation['raw_state'],'memberId'=>$m->id])</div>
  </div>

  <div class="alert {{ $status['key']==='healthy'?'alert-success':($status['key']==='blocked'?'alert-danger':'alert-warning') }}">
    <strong>{{ $status['icon'] }} {{ __($status['label']) }}</strong>
    <div class="mt-1">{{ __('The employee keeps the same role identity. Capability loss changes what can run now; it never creates substitute authority.') }}</div>
  </div>

  <div class="row g-4">
    <div class="col-xl-6"><div class="card h-100"><div class="card-header"><strong>{{ __('What is unavailable?') }}</strong></div><div class="card-body">
      @forelse($degradation['what_is_unavailable'] as $row)<div class="border rounded p-3 mb-2"><div><strong>{{ $row['id'] }}</strong> <span class="badge bg-secondary-lt">{{ str_replace('_',' ',$row['type']) }}</span></div><div class="small text-muted">{{ $row['provider'] }} · {{ $row['state'] }}</div><div class="small mt-1">{{ $row['reason'] }}</div></div>@empty<p class="text-muted mb-0">{{ __('Nothing is currently unavailable.') }}</p>@endforelse
    </div></div></div>
    <div class="col-xl-6"><div class="card h-100"><div class="card-header"><strong>{{ __('What still works?') }}</strong></div><div class="card-body">
      @forelse(array_slice($degradation['what_still_works'],0,80) as $row)<span class="badge bg-success-lt me-1 mb-1">{{ $row['id'] }} · {{ $row['provider'] }}</span>@empty<p class="text-muted mb-0">{{ __('No role-bound surfaces are live right now.') }}</p>@endforelse
    </div></div></div>

    <div class="col-xl-6"><div class="card h-100"><div class="card-header"><strong>{{ __('What work is affected?') }}</strong><span class="badge bg-secondary-lt ms-2">{{ $degradation['summary']['affected_work_count'] }}</span></div><div class="card-body">
      @forelse($degradation['affected_work'] as $task)<div class="border rounded p-3 mb-2"><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task) }}"><strong>#{{ $task->id }} {{ $task->title }}</strong></a><div class="small text-muted">{{ $task->status?->value ?? $task->status }} · {{ $task->capability ?: __('multiple/implicit capabilities') }}</div></div>@empty<p class="text-muted mb-0">{{ __('No currently open assigned work directly depends on the unavailable capability surfaces.') }}</p>@endforelse
    </div></div></div>

    <div class="col-xl-6"><div class="card h-100"><div class="card-header"><strong>{{ __('Approved fallback availability') }}</strong></div><div class="card-body">
      @forelse($degradation['fallbacks'] as $fallback)<div class="border rounded p-3 mb-2"><div><strong>{{ $fallback['surface_id'] }}</strong> · {{ $fallback['approved_fallback_available'] ? __('candidate available') : __('no approved fallback') }}</div><div class="small text-muted">{{ $fallback['candidate_providers'] ? implode(', ',$fallback['candidate_providers']) : __('No alternate canonical provider') }}</div><div class="small mt-1">{{ $fallback['why'] }}</div></div>@empty<p class="text-muted mb-0">{{ __('No unavailable surfaces require fallback analysis.') }}</p>@endforelse
    </div></div></div>

    <div class="col-12"><div class="card"><div class="card-header"><strong>{{ __('Required admin action') }}</strong></div><div class="card-body">
      @forelse($degradation['admin_actions'] as $action)<div class="alert alert-secondary mb-2">{{ $action }}</div>@empty<div class="alert alert-success mb-0">{{ __('No administrator action is required.') }}</div>@endforelse
      <div class="alert alert-info mt-3 mb-0"><strong>{{ __('Authority boundary:') }}</strong> {{ __('An available fallback is never automatically usable. Consequential execution still requires task-scoped Risk, Assurance, Governance and Autonomy authorization through Command Bus.') }}</div>
    </div></div></div>
  </div>
</div>
@endsection
