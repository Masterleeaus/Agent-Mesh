@extends('panel.layout.app')
@section('title', __('Workforce Notifications'))
@section('content')
<div class="container-xl py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="mb-1">{{ __('Notifications & Alert Routing') }}</h1><p class="text-muted mb-0">{{ __('Governed, deduplicated intervention notifications derived from Workforce Attention.') }}</p></div>
    <div class="d-flex gap-2"><span class="badge bg-red-lt">{{ $inbox['unacknowledged'] }} {{ __('Unacknowledged') }}</span><span class="badge bg-secondary-lt">{{ $inbox['acknowledged'] }} {{ __('Acknowledged') }}</span></div>
  </div>

  <div class="card mb-4"><div class="card-header"><h3 class="card-title">{{ __('Routing policy') }}</h3></div><div class="card-body">
    <form method="POST" action="{{ route('dashboard.user.titan-workforce.notifications.preferences') }}" class="row g-3">@csrf
      <div class="col-md-3"><label class="form-label">{{ __('Severity threshold') }}</label><select class="form-select" name="severity_threshold">@for($i=1;$i<=5;$i++)<option value="{{ $i }}" @selected((int)$inbox['preferences']->severity_threshold===$i)>{{ $i }}/5</option>@endfor</select></div>
      <div class="col-md-9"><div class="form-label">{{ __('Audience routing') }}</div><div class="d-flex flex-wrap gap-3">
        <label><input type="checkbox" name="in_app" value="1" @checked($inbox['preferences']->in_app)> {{ __('In-app') }}</label>
        <label><input type="checkbox" name="route_owner_admin" value="1" @checked($inbox['preferences']->route_owner_admin)> {{ __('Owner / admin') }}</label>
        <label><input type="checkbox" name="route_responsible_manager" value="1" @checked($inbox['preferences']->route_responsible_manager)> {{ __('Responsible manager') }}</label>
        <label><input type="checkbox" name="route_specific_team" value="1" @checked($inbox['preferences']->route_specific_team)> {{ __('Specific team') }}</label>
      </div></div>
      <div class="col-12"><button class="btn btn-primary">{{ __('Save routing policy') }}</button></div>
    </form>
  </div></div>

  <div class="card"><div class="table-responsive"><table class="table table-vcenter card-table"><thead><tr><th>{{ __('Alert') }}</th><th>{{ __('Severity') }}</th><th>{{ __('Audience') }}</th><th>{{ __('Deduplicated') }}</th><th>{{ __('State') }}</th><th></th></tr></thead><tbody>
    @forelse($inbox['notifications'] as $notification)
      <tr class="{{ $notification->acknowledged_at ? 'opacity-75' : '' }}">
        <td><div class="fw-semibold">{{ $notification->title }}</div><div class="small text-muted">{{ $notification->detail }}</div><div class="small text-muted">{{ __('Last seen') }} {{ optional($notification->last_seen_at)->diffForHumans() }}</div></td>
        <td><span class="badge {{ $notification->severity_score >= 5 ? 'bg-red-lt' : ($notification->severity_score >= 4 ? 'bg-orange-lt' : 'bg-yellow-lt') }}">{{ $notification->severity_score }}/5</span></td>
        <td>@foreach($notification->audience_scope ?? [] as $aud)<span class="badge bg-azure-lt me-1">{{ __(str_replace('_',' ',ucwords($aud['type'] ?? 'in_app','_'))) }}</span>@endforeach</td>
        <td>{{ $notification->occurrence_count }}×</td>
        <td>{{ $notification->acknowledged_at ? __('Acknowledged') : __('Needs acknowledgement') }}</td>
        <td class="text-end"><div class="d-flex gap-2 justify-content-end">@if($notification->url)<a href="{{ $notification->url }}" class="btn btn-sm btn-outline-primary">{{ __('Inspect') }}</a>@endif @unless($notification->acknowledged_at)<form method="POST" action="{{ route('dashboard.user.titan-workforce.notifications.acknowledge',$notification) }}">@csrf<button class="btn btn-sm btn-primary">{{ __('Acknowledge') }}</button></form>@endunless</div></td>
      </tr>
    @empty<tr><td colspan="6" class="text-center py-5"><div class="fw-semibold">{{ __('No routed notifications') }}</div><div class="small text-muted">{{ __('No attention condition meets the configured severity threshold.') }}</div></td></tr>@endforelse
  </tbody></table></div></div>
  <p class="text-muted small mt-3">{{ __('Notifications are informational routing only. Acknowledgement does not approve work, grant capability, or change Risk, Assurance, Governance, or Autonomy decisions.') }}</p>
</div>
@endsection
