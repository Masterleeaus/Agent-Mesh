@extends('panel.layout.app')
@section('title', __('Chain of Command'))
@section('content')
<div class="py-10">
    <div class="container-xl">
        <div class="mb-8">
            <h1 class="mb-2 text-3xl font-semibold">{{ __('Chain of Command Control Center') }}</h1>
            <p class="text-muted-foreground">{{ __('Live organisational decisions, independent AI checks, disagreements, authority gates and bottlenecks.') }}</p>
        </div>
        @php($s=$observability['summary'])
        <div class="grid grid-cols-2 gap-4 md:grid-cols-4 xl:grid-cols-7">
            @foreach(['active'=>'Active','organisationally_approved'=>'Org Approved','with_disagreement'=>'Disagreements','with_escalation'=>'Escalations','blocked_final_authority'=>'Blocked Gates','stalled'=>'Stalled','chains'=>'Observed'] as $k=>$label)
            <div class="rounded-xl border p-4"><div class="text-2xl font-semibold">{{ $s[$k] }}</div><div class="text-xs opacity-70">{{ __($label) }}</div></div>
            @endforeach
        </div>
        <div class="mt-8 overflow-x-auto rounded-xl border">
            <table class="w-full text-sm">
                <thead><tr class="border-b text-left">
                    <th class="p-3">Chain</th><th>Capability</th><th>State</th><th>Federation</th><th>Recovery</th><th>Depth</th><th>Failure Forecast</th><th>Stage</th><th>Reviewer</th><th>Disputes</th><th>Gate</th><th>Bottleneck</th>
                </tr></thead>
                <tbody>
                @forelse($observability['chains'] as $row)
                    <tr class="border-b">
                        <td class="p-3 font-mono text-xs">{{ \Illuminate\Support\Str::limit($row['chain_uuid'],18) }}</td>
                        <td>{{ $row['capability'] }}</td><td>{{ $row['state'] }}</td><td>{{ $row['federation_status'] ?? '—' }} {{ $row['federated_handoffs_accepted'] }}/{{ $row['federated_handoffs_total'] }}</td><td>{{ $row['recovery_status'] ?? '—' }} {{ $row['recovery_verified_steps'] }}/{{ $row['recovery_total_steps'] }}</td><td>{{ $row['adaptive_depth'] }} (U{{ $row['uncertainty_score'] }}/C{{ $row['consequence_score'] }})</td><td>{{ $row['failure_risk_band'] }} {{ $row['failure_probability'] }}%</td><td>{{ $row['current_stage'] ?? '—' }}</td>
                        <td>{{ $row['current_reviewer_member_id'] ?? '—' }}</td><td>{{ $row['open_challenges'] }}</td>
                        <td>{{ $row['blocked_gate'] ?? ($row['final_authority_allowed'] === true ? 'passed' : 'pending') }}</td>
                        <td>{{ $row['bottleneck']['reason'] }} / {{ $row['bottleneck']['severity'] }}</td>
                    </tr>
                @empty
                    <tr><td class="p-6" colspan="12">{{ __('No decision chains recorded yet.') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
