@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Work Command Center'))
@section('titlebar_subtitle', __('Persistent governed work across queues, reviews, handoffs, escalations, dependencies and recovery.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
$view = $center['view']; $summary = $center['summary'];
$views = ['list'=>'List','kanban'=>'Kanban','timeline'=>'Timeline','dependencies'=>'Dependency graph','review'=>'Manager review','handoffs'=>'Handoff queue','escalations'=>'Escalations','recovery'=>'Recovery'];
@endphp
<div class="px-5 py-8 space-y-5">
  <div class="grid grid-cols-2 gap-3 md:grid-cols-6">
    @foreach(['open'=>'Open','review'=>'Review','blocked'=>'Blocked','handoffs'=>'Handoffs','escalations'=>'Escalated','recovery'=>'Recovery'] as $key=>$label)
      <div class="rounded-xl border bg-card p-4"><div class="text-xs uppercase text-foreground/45">{{ __($label) }}</div><div class="mt-1 text-2xl font-semibold">{{ $summary[$key] ?? 0 }}</div></div>
    @endforeach
  </div>

  <div class="flex flex-wrap gap-2 rounded-xl border bg-card p-3">
    @foreach($views as $key=>$label)
      <a href="{{ route('dashboard.user.titan-workforce.tasks', ['view'=>$key]) }}" class="rounded-lg px-3 py-2 text-sm font-medium {{ $view===$key ? 'bg-foreground text-background' : 'bg-foreground/5 hover:bg-foreground/10' }}">{{ __($label) }}</a>
    @endforeach
  </div>

  @if($view === 'list')
    <div class="overflow-hidden rounded-xl border bg-card"><div class="overflow-x-auto"><table class="w-full text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-4">{{ __('Task') }}</th><th class="p-4">{{ __('Owner / Manager') }}</th><th class="p-4">{{ __('State') }}</th><th class="p-4">{{ __('Capability') }}</th><th class="p-4">{{ __('Queue') }}</th><th class="p-4">{{ __('Updated') }}</th></tr></thead><tbody>
    @forelse($center['tasks'] as $task)
      <tr class="border-t"><td class="p-4"><a class="font-semibold hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show',$task) }}">{{ $task->title }}</a><div class="mt-1 text-xs text-foreground/45">{{ $task->task_uuid }}</div></td><td class="p-4"><div>{{ $task->assignee?->name ?? __('Unassigned') }}</div><div class="text-xs text-foreground/45">{{ __('Manager:') }} {{ $task->manager?->name ?? '—' }}</div></td><td class="p-4"><span class="rounded-full bg-foreground/5 px-2 py-1 text-[11px] font-semibold">{{ $task->status?->value }}</span></td><td class="p-4 text-xs">{{ $task->capability ?: '—' }}</td><td class="p-4 font-semibold">{{ $task->queue_score }}</td><td class="p-4 text-foreground/60">{{ optional($task->last_activity_at ?? $task->updated_at)->diffForHumans() }}</td></tr>
    @empty <tr><td colspan="6" class="p-10 text-center text-foreground/60">{{ __('No Workforce tasks yet.') }}</td></tr> @endforelse
    </tbody></table></div></div><div>{{ $center['tasks']->links() }}</div>
  @elseif($view === 'kanban')
    <div class="flex gap-4 overflow-x-auto pb-3">
      @forelse($center['kanban'] as $state=>$tasks)
      <section class="min-w-[290px] max-w-[340px] flex-1 rounded-xl border bg-card p-3"><div class="mb-3 flex items-center justify-between"><h3 class="font-semibold">{{ $state }}</h3><span class="rounded-full bg-foreground/5 px-2 py-1 text-xs">{{ $tasks->count() }}</span></div><div class="space-y-2">
        @foreach($tasks as $task)<a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task) }}" class="block rounded-lg border bg-background p-3 hover:bg-foreground/[.03]"><div class="font-medium">{{ $task->title }}</div><div class="mt-2 text-xs text-foreground/50">{{ $task->assignee?->name ?? __('Unassigned') }} · {{ $task->division?->name ?? '—' }}</div></a>@endforeach
      </div></section>
      @empty <div class="rounded-xl border bg-card p-8 text-foreground/60">{{ __('No open work.') }}</div> @endforelse
    </div>
  @elseif($view === 'timeline')
    <div class="rounded-xl border bg-card p-5 space-y-0">@forelse($center['timeline'] as $task)<div class="relative border-l pl-6 pb-6 last:pb-0"><span class="absolute -left-1.5 top-1 h-3 w-3 rounded-full bg-foreground"></span><div class="text-xs text-foreground/45">{{ optional($task->deadline_at ?? $task->scheduled_at ?? $task->last_activity_at)->format('d M Y H:i') ?? __('No date') }}</div><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task) }}" class="font-semibold hover:underline">{{ $task->title }}</a><div class="text-sm text-foreground/55">{{ $task->status?->value }} · {{ $task->assignee?->name ?? __('Unassigned') }}</div></div>@empty<div class="text-foreground/60">{{ __('No timeline work.') }}</div>@endforelse</div>
  @elseif($view === 'dependencies')
    <div class="rounded-xl border bg-card overflow-x-auto"><table class="w-full text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-4">{{ __('Task') }}</th><th class="p-4">{{ __('Depends on') }}</th><th class="p-4">{{ __('Blocking') }}</th></tr></thead><tbody>@forelse($center['dependencies'] as $edge)<tr class="border-t"><td class="p-4">@if($edge->task)<a class="font-medium hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show',$edge->task) }}">{{ $edge->task->title }}</a>@endif</td><td class="p-4">@if($edge->dependsOn)<a class="font-medium hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show',$edge->dependsOn) }}">{{ $edge->dependsOn->title }}</a>@endif</td><td class="p-4">{{ $edge->blocking ? 'Yes' : 'No' }}</td></tr>@empty<tr><td colspan="3" class="p-8 text-center text-foreground/60">{{ __('No dependency edges.') }}</td></tr>@endforelse</tbody></table></div>
  @elseif($view === 'review')
    @include('titan-ai-workforce::tasks.partials.task-cards', ['rows'=>$center['review_queue'], 'empty'=>'No work awaiting manager review.'])
  @elseif($view === 'handoffs')
    <div class="space-y-3">@forelse($center['handoffs'] as $row)<div class="rounded-xl border bg-card p-4"><div class="flex justify-between gap-4"><div><div class="font-semibold">{{ $row->handoff_uuid }}</div><div class="text-sm text-foreground/55">{{ __('Task #') }}{{ $row->task_id }} · {{ $row->reason ?: __('No handoff reason recorded') }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-xs font-semibold">{{ $row->status?->value ?? $row->status }}</span></div></div>@empty<div class="rounded-xl border bg-card p-8 text-foreground/60">{{ __('No handoffs.') }}</div>@endforelse</div>
  @elseif($view === 'escalations')
    <div class="space-y-3">@forelse($center['escalations'] as $row)<div class="rounded-xl border bg-card p-4"><div class="flex justify-between gap-4"><div><div class="font-semibold">{{ $row->reason_code }}</div><div class="text-sm text-foreground/55">{{ __('Task #') }}{{ $row->task_id ?? '—' }} · {{ $row->recommended_action ?: __('No recommended action') }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-xs font-semibold">{{ $row->status }}</span></div></div>@empty<div class="rounded-xl border bg-card p-8 text-foreground/60">{{ __('No escalations.') }}</div>@endforelse</div>
  @elseif($view === 'recovery')
    @include('titan-ai-workforce::tasks.partials.task-cards', ['rows'=>$center['recovery'], 'empty'=>'No work currently requiring recovery.'])
  @endif

  <p class="text-xs text-foreground/45">{{ __('This command center projects authoritative Workforce state. Queue position, provider availability, review visibility and recovery state never grant execution authority.') }}</p>
</div>
@endsection
