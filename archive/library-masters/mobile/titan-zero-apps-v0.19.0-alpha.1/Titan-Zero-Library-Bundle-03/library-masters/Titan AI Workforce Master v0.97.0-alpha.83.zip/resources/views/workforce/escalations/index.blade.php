@extends('panel.layout.app')
@section('title', __('Escalations & Deadlocks'))
@section('content')
<div class="container-xl py-6 space-y-5">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div>
      <h1 class="mb-1">{{ __('Escalation & Deadlock Center') }}</h1>
      <p class="text-muted mb-0">{{ __('One place to understand unresolved work, the required resolver, evidence, prior decisions and blocked downstream work.') }}</p>
    </div>
    <div class="flex flex-wrap gap-2 text-xs">
      <span class="rounded-full border px-3 py-1">{{ __('Open') }} {{ $center['counts']['open'] }}</span>
      <span class="rounded-full border px-3 py-1">{{ __('Escalated') }} {{ $center['counts']['escalated'] }}</span>
      <span class="rounded-full border px-3 py-1">{{ __('Deadlocked') }} {{ $center['counts']['deadlocked'] }}</span>
      <span class="rounded-full border px-3 py-1">{{ __('Human required') }} {{ $center['counts']['human_required'] }}</span>
    </div>
  </div>

  <div class="rounded-xl border bg-card p-4 text-sm">
    <strong>{{ __('Authority boundary') }}:</strong>
    {{ __('No escalation or deadlock action grants execution authority. Escalation changes who must decide; Risk, Assurance, Governance and Autonomy remain mandatory.') }}
  </div>

  <section class="rounded-xl border bg-card p-4">
    <h2 class="mb-3 text-lg font-semibold">{{ __('Visual escalation tree') }}</h2>
    <div class="grid gap-2 md:grid-cols-6">
      @foreach($center['tree'] as $index => $node)
        <div class="relative rounded-lg border p-3 text-center">
          <div class="font-semibold">{{ $node['label'] }}</div>
          @if(!empty($node['member']))<a class="mt-1 block text-xs hover:underline" href="{{ $node['member']['url'] }}">{{ $node['member']['name'] }}</a>@endif
          <div class="mt-1 text-xs text-foreground/50">{{ $node['description'] }}</div>
          @if(!$loop->last)<div class="absolute -right-3 top-1/2 hidden -translate-y-1/2 md:block">→</div>@endif
        </div>
      @endforeach
    </div>
  </section>

  <div class="space-y-4">
    @forelse($center['rows'] as $row)
      <article class="rounded-xl border bg-card p-4">
        <div class="flex flex-wrap items-start justify-between gap-3">
          <div>
            <a class="font-semibold hover:underline" href="{{ $row['url'] }}">{{ $row['title'] }}</a>
            <div class="mt-1 flex flex-wrap gap-2 text-xs">
              <span class="rounded-full border px-2 py-1">{{ $row['state'] }}</span>
              @if($row['is_deadlock'])<span class="rounded-full border px-2 py-1">{{ __('Deadlock') }}</span>@endif
              @if($row['human_required'])<span class="rounded-full border px-2 py-1">{{ __('Human decision required') }}</span>@endif
              <span>{{ __('Age') }}: {{ $row['age'] }}</span>
            </div>
          </div>
          <div class="text-right text-xs">
            <div class="font-semibold">{{ __('Required resolver') }}</div>
            @if(!empty($row['required_resolver']['member']))
              <a class="hover:underline" href="{{ $row['required_resolver']['member']['url'] }}">{{ $row['required_resolver']['member']['name'] }}</a>
            @else
              <span>{{ ucfirst(str_replace('_',' ', $row['required_resolver']['level'])) }}</span>
            @endif
          </div>
        </div>

        <div class="mt-4 grid gap-4 lg:grid-cols-4">
          <div><div class="font-semibold">{{ __('Reason') }}</div><div class="text-sm text-foreground/60">{{ $row['reason'] }}</div></div>
          <div><div class="font-semibold">{{ __('Evidence') }}</div>@forelse($row['evidence'] as $evidence)<div class="text-xs text-foreground/60">{{ $evidence['type'] }}@if($evidence['reference']) · {{ $evidence['reference'] }}@endif</div>@empty<div class="text-xs text-foreground/50">{{ __('No evidence attached.') }}</div>@endforelse</div>
          <div><div class="font-semibold">{{ __('Previous decisions') }}</div>@forelse($row['previous_decisions'] as $decision)<div class="text-xs text-foreground/60">{{ $decision['event'] }}@if($decision['reason']) · {{ $decision['reason'] }}@endif</div>@empty<div class="text-xs text-foreground/50">{{ __('No prior deadlock decisions.') }}</div>@endforelse</div>
          <div><div class="font-semibold">{{ __('Blocked downstream work') }}</div>@forelse($row['blocked_downstream_work'] as $task)<a class="block text-xs hover:underline" href="{{ $task['url'] }}">{{ $task['title'] }} · {{ $task['status'] }}</a>@empty<div class="text-xs text-foreground/50">{{ __('No blocking dependents.') }}</div>@endforelse</div>
        </div>

        <form class="mt-4 grid gap-2 rounded-lg border p-3 md:grid-cols-[minmax(0,1fr)_180px_180px_auto]" method="POST" action="{{ route('dashboard.user.titan-workforce.escalations.action', $row['task_id']) }}">
          @csrf
          <input class="form-control" name="reason" required maxlength="4000" placeholder="{{ __('Decision reason / new evidence summary') }}">
          <select class="form-select" name="actor_id" required>
            <option value="">{{ __('Resolver') }}</option>
            @if(!empty($row['manager']))<option value="{{ $row['manager']['id'] }}">{{ $row['manager']['name'] }}</option>@endif
            @if(!empty($row['required_resolver']['member']) && ($row['required_resolver']['member']['id'] ?? null) !== ($row['manager']['id'] ?? null))<option value="{{ $row['required_resolver']['member']['id'] }}">{{ $row['required_resolver']['member']['name'] }}</option>@endif
          </select>
          <select class="form-select" name="action" required>
            <option value="RETRY_WITH_EVIDENCE">{{ __('Retry with evidence') }}</option>
            <option value="RETURN_TO_MAKER">{{ __('Return to maker') }}</option>
            <option value="ESCALATE_TO_PARENT">{{ __('Escalate') }}</option>
            <option value="HUMAN_DECISION_REQUIRED">{{ __('Human decision') }}</option>
            <option value="RESOLVE">{{ __('Resolve') }}</option>
          </select>
          <button class="btn btn-primary" type="submit">{{ __('Apply governed action') }}</button>
        </form>
      </article>
    @empty
      <div class="rounded-xl border bg-card p-8 text-center text-foreground/50">{{ __('No open escalations or deadlocks.') }}</div>
    @endforelse
  </div>
</div>
@endsection
