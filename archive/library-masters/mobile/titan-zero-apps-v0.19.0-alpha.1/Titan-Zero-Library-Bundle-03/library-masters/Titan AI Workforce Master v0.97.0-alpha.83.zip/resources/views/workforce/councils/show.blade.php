@extends('panel.layout.app')
@section('title', $council['name'])
@section('content')
<div class="container-xl py-6 space-y-5">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div>
      <a class="text-sm hover:underline" href="{{ route('dashboard.user.titan-workforce.councils') }}">← {{ __('Councils') }}</a>
      <h1 class="mb-1 mt-2">{{ $council['name'] }}</h1>
      <p class="text-muted mb-0">{{ $council['purpose'] }}</p>
    </div>
    <div class="text-right text-xs"><div class="rounded-full border px-3 py-1">{{ $council['decision_authority'] }}</div></div>
  </div>

  <div class="rounded-xl border bg-card p-4 text-sm">
    <strong>{{ __('Authority boundary') }}:</strong>
    {{ __('Council decisions do not grant execution authority. Final decisions are governance records; consequential follow-up Work Items require fresh capability, Risk, Assurance, Governance and Autonomy authorization.') }}
  </div>

  <section class="grid gap-4 lg:grid-cols-3">
    <article class="rounded-xl border bg-card p-4">
      <h2 class="font-semibold">{{ __('Chair') }}</h2>
      @if(!empty($council['chair']['member']))
        <a class="mt-2 block hover:underline" href="{{ $council['chair']['member']['url'] }}">{{ $council['chair']['member']['name'] }}</a>
        <div class="text-xs text-foreground/50">{{ $council['chair']['role_definition_id'] }}</div>
      @else
        <p class="mt-2 text-sm text-foreground/50">{{ __('No active chair is assigned.') }}</p>
      @endif
    </article>
    <article class="rounded-xl border bg-card p-4 lg:col-span-2">
      <h2 class="font-semibold">{{ __('Participants') }}</h2>
      <div class="mt-2 flex flex-wrap gap-2">
        @forelse($council['participants'] as $participant)
          <div class="rounded-lg border px-3 py-2 text-sm">
            @if(!empty($participant['member']))<a class="font-medium hover:underline" href="{{ $participant['member']['url'] }}">{{ $participant['member']['name'] }}</a>@else<span>{{ $participant['role_definition_id'] ?: __('Unfilled role') }}</span>@endif
            <div class="text-xs text-foreground/50">{{ $participant['participation_type'] }}</div>
          </div>
        @empty
          <span class="text-sm text-foreground/50">{{ __('No active participants found.') }}</span>
        @endforelse
      </div>
    </article>
  </section>

  <section class="grid gap-4 lg:grid-cols-2">
    <article class="rounded-xl border bg-card p-4"><h2 class="font-semibold">{{ __('Issue') }}</h2><p class="mt-2 text-sm">{{ $council['issue'] ?: __('No current issue recorded.') }}</p></article>
    <article class="rounded-xl border bg-card p-4"><h2 class="font-semibold">{{ __('Recommendation') }}</h2><p class="mt-2 text-sm">{{ $council['recommendation'] ?: __('No recommendation yet.') }}</p><h2 class="mt-4 font-semibold">{{ __('Final decision') }}</h2><p class="mt-2 text-sm">{{ $council['final_decision'] ?: __('No final decision yet.') }}</p></article>
  </section>

  <section class="grid gap-4 lg:grid-cols-3">
    @foreach(['evidence'=>__('Evidence'),'proposals'=>__('Proposals'),'dissent'=>__('Dissent')] as $key => $label)
      <article class="rounded-xl border bg-card p-4">
        <h2 class="font-semibold">{{ $label }}</h2>
        <div class="mt-2 space-y-2">
          @forelse($council[$key] as $entry)
            <div class="rounded-lg border p-2 text-sm"><div>{{ is_array($entry) ? ($entry['text'] ?? json_encode($entry)) : $entry }}</div>@if(is_array($entry) && !empty($entry['recorded_at']))<div class="mt-1 text-xs text-foreground/50">{{ $entry['recorded_at'] }}@if(!empty($entry['member_id'])) · {{ __('Member') }} #{{ $entry['member_id'] }}@endif</div>@endif</div>
          @empty
            <div class="text-sm text-foreground/50">{{ __('None recorded.') }}</div>
          @endforelse
        </div>
      </article>
    @endforeach
  </section>

  <section class="rounded-xl border bg-card p-4">
    <h2 class="text-lg font-semibold">{{ __('Record deliberation') }}</h2>
    <p class="mt-1 text-sm text-foreground/60">{{ __('Record evidence, proposals, dissent, a recommendation or final decision. Add follow-up titles only when separate governed Work Items are required.') }}</p>
    <form class="mt-4 grid gap-3" method="POST" action="{{ route('dashboard.user.titan-workforce.councils.decision', $council['id']) }}">
      @csrf
      <select class="form-select" name="participant_member_id" required>
        <option value="">{{ __('Participant recording this update') }}</option>
        @foreach($council['participants'] as $participant)
          @if(!empty($participant['member']))<option value="{{ $participant['member']['id'] }}">{{ $participant['member']['name'] }} · {{ $participant['participation_type'] }}</option>@endif
        @endforeach
      </select>
      <textarea class="form-control" name="issue" maxlength="4000" rows="2" placeholder="{{ __('Refine / replace current issue') }}"></textarea>
      <div class="grid gap-3 lg:grid-cols-3">
        <textarea class="form-control" name="evidence" maxlength="8000" rows="4" placeholder="{{ __('Add evidence') }}"></textarea>
        <textarea class="form-control" name="proposals" maxlength="8000" rows="4" placeholder="{{ __('Add proposal') }}"></textarea>
        <textarea class="form-control" name="dissent" maxlength="8000" rows="4" placeholder="{{ __('Record dissent') }}"></textarea>
      </div>
      <div class="grid gap-3 lg:grid-cols-2">
        <textarea class="form-control" name="recommendation" maxlength="8000" rows="3" placeholder="{{ __('Recommendation') }}"></textarea>
        <textarea class="form-control" name="final_decision" maxlength="8000" rows="3" placeholder="{{ __('Final decision') }}"></textarea>
      </div>
      <div class="grid gap-2 md:grid-cols-3">
        <input class="form-control" name="follow_up_titles[]" maxlength="500" placeholder="{{ __('Follow-up Work Item 1') }}">
        <input class="form-control" name="follow_up_titles[]" maxlength="500" placeholder="{{ __('Follow-up Work Item 2') }}">
        <input class="form-control" name="follow_up_titles[]" maxlength="500" placeholder="{{ __('Follow-up Work Item 3') }}">
      </div>
      <div><button class="btn btn-primary" type="submit">{{ __('Record governed council update') }}</button></div>
    </form>
  </section>

  <section class="grid gap-4 lg:grid-cols-2">
    <article class="rounded-xl border bg-card p-4">
      <h2 class="font-semibold">{{ __('Council session Work Items') }}</h2>
      <div class="mt-2 space-y-2">@forelse($council['session_tasks'] as $task)<a class="block rounded-lg border p-2 text-sm hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show', $task) }}">{{ $task->title }} · {{ is_object($task->status) ? $task->status->value : $task->status }}</a>@empty<div class="text-sm text-foreground/50">{{ __('No session Work Items found.') }}</div>@endforelse</div>
    </article>
    <article class="rounded-xl border bg-card p-4">
      <h2 class="font-semibold">{{ __('Follow-up Work Items') }}</h2>
      <div class="mt-2 space-y-2">@forelse($council['follow_up_work_items'] as $task)<a class="block rounded-lg border p-2 text-sm hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show', $task) }}">{{ $task->title }} · {{ is_object($task->status) ? $task->status->value : $task->status }}</a>@empty<div class="text-sm text-foreground/50">{{ __('No follow-up Work Items yet.') }}</div>@endforelse</div>
    </article>
  </section>
</div>
@endsection
