@extends('panel.layout.app')
@section('title', __('Workforce Attention'))
@section('content')
<div class="container-xl py-4">
  <div class="d-flex flex-wrap align-items-start justify-content-between gap-3 mb-4">
    <div><h1 class="mb-1">{{ __('Workforce Attention Center') }}</h1><p class="text-muted mb-0">{{ __('Everything needing intervention across the company, ranked by operational urgency.') }}</p></div>
    <div class="d-flex gap-2"><span class="badge bg-red-lt">{{ $attention['critical'] }} {{ __('Critical') }}</span><span class="badge bg-orange-lt">{{ $attention['high'] }} {{ __('High') }}</span><span class="badge bg-secondary-lt">{{ $attention['total'] }} {{ __('Total') }}</span></div>
  </div>

  <div class="card mb-4"><div class="card-body"><div class="row g-3">
    @foreach($attention['counts'] as $category=>$count)<div class="col-6 col-md-4 col-xl-3"><div class="border rounded p-3 h-100"><div class="text-muted small">{{ __(str_replace('_',' ',ucwords($category,'_'))) }}</div><div class="fs-2 fw-bold">{{ $count }}</div></div></div>@endforeach
  </div></div></div>

  <div class="card"><div class="table-responsive"><table class="table table-vcenter card-table">
    <thead><tr><th>{{ __('Intervention') }}</th><th>{{ __('Severity') }}</th><th>{{ __('Business impact') }}</th><th>{{ __('Age') }}</th><th>{{ __('Blocking effect') }}</th><th>{{ __('Priority') }}</th><th></th></tr></thead>
    <tbody>
    @forelse($attention['items'] as $item)
      <tr>
        <td><div class="fw-semibold">{{ $item['title'] }}</div><div class="small text-muted">{{ __(str_replace('_',' ',ucwords($item['category'],'_'))) }} · {{ $item['detail'] }}</div></td>
        <td><span class="badge {{ $item['severity_score'] >= 5 ? 'bg-red-lt' : ($item['severity_score'] >= 4 ? 'bg-orange-lt' : 'bg-yellow-lt') }}">{{ $item['severity_score'] }}/5</span></td>
        <td>{{ $item['business_impact_score'] }}/5</td>
        <td>{{ $item['age_score'] }}/5 <div class="small text-muted">{{ $item['age_hours'] }}h</div></td>
        <td>{{ $item['blocking_effect_score'] }}/5</td>
        <td><strong>{{ $item['priority_score'] }}</strong></td>
        <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="{{ $item['url'] }}">{{ __('Inspect') }}</a></td>
      </tr>
    @empty<tr><td colspan="7" class="text-center py-5"><div class="fw-semibold">{{ __('No intervention is currently required') }}</div><div class="text-muted small">{{ __('The attention inbox is clear.') }}</div></td></tr>@endforelse
    </tbody>
  </table></div></div>
  <p class="text-muted small mt-3">{{ __('Priority = Severity × Business impact × Age × Blocking effect. This inbox is read-only and never grants execution authority.') }}</p>
</div>
@endsection
