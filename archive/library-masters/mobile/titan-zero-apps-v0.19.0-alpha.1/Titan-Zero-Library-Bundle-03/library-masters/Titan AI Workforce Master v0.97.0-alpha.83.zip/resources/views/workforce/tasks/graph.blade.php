@extends('panel.layout.app')

@section('title', __('Visual Work Graph'))

@section('content')
@php
  $typeStyles = [
    'task' => 'border-slate-300 bg-card',
    'decision' => 'border-violet-300 bg-violet-50/40 dark:bg-violet-950/10',
    'review' => 'border-amber-300 bg-amber-50/40 dark:bg-amber-950/10',
    'handoff' => 'border-cyan-300 bg-cyan-50/40 dark:bg-cyan-950/10',
    'execution' => 'border-blue-300 bg-blue-50/40 dark:bg-blue-950/10',
    'evidence' => 'border-emerald-300 bg-emerald-50/40 dark:bg-emerald-950/10',
    'outcome' => 'border-green-400 bg-green-50/50 dark:bg-green-950/10',
  ];
@endphp
<div class="container-xl space-y-6 py-6">
  <div class="flex flex-wrap items-start justify-between gap-4">
    <div>
      <div class="text-xs font-semibold uppercase tracking-wider text-foreground/45">{{ __('Work Command Center') }}</div>
      <h1 class="mt-1 text-2xl font-bold">{{ __('Visual Work Graph') }}</h1>
      <p class="mt-1 max-w-3xl text-sm text-foreground/60">{{ __('Trace complex autonomous work across tasks, governed decisions, reviews, handoffs, executions, evidence and verified outcomes.') }}</p>
    </div>
    <div class="flex gap-2">
      <a href="{{ route('dashboard.user.titan-workforce.tasks.show', $graph['focus_task']) }}" class="rounded-lg border px-3 py-2 text-sm font-medium hover:bg-foreground/[.03]">{{ __('Task detail') }}</a>
      <a href="{{ route('dashboard.user.titan-workforce.tasks', ['view' => 'dependencies']) }}" class="rounded-lg border px-3 py-2 text-sm font-medium hover:bg-foreground/[.03]">{{ __('Work Center') }}</a>
    </div>
  </div>

  <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
    @foreach($graph['node_types'] as $type)
      <div class="rounded-xl border p-3 {{ $typeStyles[$type] ?? 'bg-card' }}"><div class="text-xs font-semibold uppercase text-foreground/45">{{ ucfirst($type) }}</div><div class="mt-1 text-2xl font-bold">{{ $graph['counts'][$type] ?? 0 }}</div></div>
    @endforeach
  </div>

  <div class="rounded-xl border bg-card p-4">
    <div class="flex flex-wrap gap-3 text-xs">
      @foreach($graph['node_types'] as $type)<span class="rounded-full border px-2 py-1 {{ $typeStyles[$type] ?? '' }}">{{ ucfirst($type) }}</span>@endforeach
      <span class="ml-auto text-foreground/45">{{ __('Read-only projection · no authority inheritance') }}</span>
    </div>
  </div>

  <section class="rounded-xl border bg-card p-3 sm:p-5">
    @if($graph['nodes']->isEmpty())
      <div class="p-10 text-center text-foreground/60">{{ __('No graph records are available for this work.') }}</div>
    @else
      <div id="work-graph-scroll" class="relative overflow-auto rounded-lg bg-foreground/[.015]" style="min-height:620px;">
        <div id="work-graph-canvas" class="relative min-w-[1200px] p-8" style="min-height:600px;">
          <svg id="work-graph-edges" class="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true"></svg>
          <div class="relative z-10 grid grid-cols-4 gap-x-16 gap-y-8 xl:grid-cols-5">
            @foreach($graph['nodes'] as $node)
              @php($meta = $node['meta'])
              <article data-work-node="{{ $node['id'] }}" class="work-graph-node min-h-[132px] rounded-xl border-2 p-4 shadow-sm {{ $typeStyles[$node['type']] ?? 'border-slate-300 bg-card' }} {{ !empty($meta['focus']) ? 'ring-2 ring-offset-2 ring-foreground/30' : '' }}">
                <div class="flex items-start justify-between gap-2"><span class="rounded-full bg-foreground/[.06] px-2 py-1 text-[10px] font-bold uppercase tracking-wide">{{ $node['type'] }}</span>@if($node['status'])<span class="text-[10px] font-semibold text-foreground/55">{{ $node['status'] }}</span>@endif</div>
                <div class="mt-3 font-semibold leading-snug">{{ \Illuminate\Support\Str::limit($node['title'], 76) }}</div>
                @if(!empty($meta['owner']))<div class="mt-2 text-xs text-foreground/55">{{ $meta['owner'] }}@if(!empty($meta['manager'])) · {{ __('Mgr:') }} {{ $meta['manager'] }}@endif</div>@endif
                @if(!empty($meta['occurred_at']))<div class="mt-1 text-[11px] text-foreground/40">{{ \Illuminate\Support\Carbon::parse($meta['occurred_at'])->format('d M Y H:i') }}</div>@endif
                @if($node['type'] === 'task' && !empty($meta['task_id']))<a href="{{ route('dashboard.user.titan-workforce.tasks.show', $meta['task_id']) }}" class="mt-3 inline-block text-xs font-semibold underline decoration-dotted underline-offset-4">{{ __('Open task') }} →</a>@endif
              </article>
            @endforeach
          </div>
        </div>
      </div>
      <div id="work-graph-edge-list" class="mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-3">
        @foreach($graph['edges'] as $edge)<div class="rounded-lg border px-3 py-2 text-xs text-foreground/60"><span class="font-semibold text-foreground/80">{{ $edge['label'] }}</span><div class="mt-1 truncate">{{ $edge['from'] }} → {{ $edge['to'] }}</div></div>@endforeach
      </div>
    @endif
  </section>
</div>

@if($graph['nodes']->isNotEmpty())
<script>
(() => {
  const edges = @json($graph['edges']);
  const canvas = document.getElementById('work-graph-canvas');
  const svg = document.getElementById('work-graph-edges');
  if (!canvas || !svg) return;
  const esc = (value) => window.CSS && CSS.escape ? CSS.escape(value) : value.replace(/([:\.])/g, '\\$1');
  const draw = () => {
    const box = canvas.getBoundingClientRect();
    svg.setAttribute('viewBox', `0 0 ${canvas.scrollWidth} ${canvas.scrollHeight}`);
    svg.innerHTML = '<defs><marker id="work-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="currentColor" opacity=".45"/></marker></defs>';
    edges.forEach((edge) => {
      const from = canvas.querySelector(`[data-work-node="${esc(edge.from)}"]`);
      const to = canvas.querySelector(`[data-work-node="${esc(edge.to)}"]`);
      if (!from || !to) return;
      const a = from.getBoundingClientRect(), b = to.getBoundingClientRect();
      const x1 = a.left - box.left + a.width / 2, y1 = a.top - box.top + a.height / 2;
      const x2 = b.left - box.left + b.width / 2, y2 = b.top - box.top + b.height / 2;
      const dx = Math.max(40, Math.abs(x2 - x1) * .45);
      const path = document.createElementNS('http://www.w3.org/2000/svg','path');
      path.setAttribute('d', `M ${x1} ${y1} C ${x1 + (x2 >= x1 ? dx : -dx)} ${y1}, ${x2 - (x2 >= x1 ? dx : -dx)} ${y2}, ${x2} ${y2}`);
      path.setAttribute('fill','none'); path.setAttribute('stroke','currentColor'); path.setAttribute('stroke-opacity','.22'); path.setAttribute('stroke-width','2'); path.setAttribute('marker-end','url(#work-arrow)');
      svg.appendChild(path);
    });
  };
  requestAnimationFrame(draw);
  window.addEventListener('resize', draw, {passive:true});
})();
</script>
@endif
@endsection
