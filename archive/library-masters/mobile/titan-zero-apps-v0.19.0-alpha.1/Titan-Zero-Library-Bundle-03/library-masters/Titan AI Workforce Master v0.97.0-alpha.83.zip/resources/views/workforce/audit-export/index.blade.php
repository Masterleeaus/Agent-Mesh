@extends('panel.layout.app',['disable_tblr'=>true,'layout_wide'=>true])
@section('title',__('Audit & Export'))
@section('content')
<div class="px-5 py-8 space-y-6">
<div class="flex flex-wrap items-start justify-between gap-4"><div><h1 class="text-2xl font-semibold">{{ __('Audit & Export') }}</h1><p class="mt-1 text-sm text-foreground/60">{{ __('Portable company-scoped evidence package for Workforce operations and governance.') }}</p></div><a href="{{ route('dashboard.user.titan-workforce.audit-export.download') }}" class="rounded-lg bg-foreground px-4 py-2 text-background">{{ __('Download evidence package') }}</a></div>
<div class="grid gap-4 md:grid-cols-3">
@foreach(['Organisation'=>count($package['organisation']['divisions'])+count($package['organisation']['teams']),'Employees'=>count($package['employees']),'Work'=>count($package['work']),'Responsibilities'=>count($package['responsibilities']),'Executions'=>count($package['executions']),'Outcomes'=>count($package['outcomes'])] as $label=>$count)
<div class="rounded-2xl border bg-card p-5"><div class="text-xs text-foreground/50">{{ __($label) }}</div><div class="mt-2 text-3xl font-semibold">{{ $count }}</div></div>
@endforeach
</div>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Governance') }}</h2><p class="mt-2 text-sm">{{ __('The package includes current trust/governance health, delegations, escalations, execution evidence and verified outcomes.') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Evidence package') }}</h2><dl class="mt-3 grid gap-2 text-sm"><div>Schema: {{ $package['schema'] }}</div><div>Generated: {{ $package['generated_at'] }}</div><div>Verified outcomes: {{ $package['integrity']['verified_outcomes'] }}</div><div>Execution receipts: {{ $package['integrity']['execution_receipts'] }}</div></dl><p class="mt-4 text-xs text-foreground/50">{{ __('Export is read-only. It grants no authority or execution rights.') }}</p></section>
</div>
@endsection
