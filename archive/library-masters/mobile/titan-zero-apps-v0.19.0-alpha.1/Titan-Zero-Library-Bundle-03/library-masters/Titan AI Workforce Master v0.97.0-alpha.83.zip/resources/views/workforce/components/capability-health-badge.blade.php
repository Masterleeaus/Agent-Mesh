@php
    $raw = (string) ($state ?? 'unavailable');
    $display = match($raw) {
        'available' => ['icon'=>'🟢','label'=>'Healthy','class'=>'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'],
        'blocked' => ['icon'=>'🔴','label'=>'Blocked','class'=>'bg-red-500/10 text-red-700 dark:text-red-300'],
        'missing_provider' => ['icon'=>'⚪','label'=>'Missing Provider','class'=>'bg-slate-500/10 text-slate-700 dark:text-slate-300'],
        'policy_disabled' => ['icon'=>'🔒','label'=>'Policy Disabled','class'=>'bg-violet-500/10 text-violet-700 dark:text-violet-300'],
        default => ['icon'=>'🟡','label'=>'Degraded','class'=>'bg-amber-500/10 text-amber-700 dark:text-amber-300'],
    };
@endphp
@if(!empty($memberId) && $raw !== 'available')
<a href="{{ route('dashboard.user.titan-workforce.staff.degradation', $memberId) }}" class="inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold {{ $display['class'] }}" title="{{ __('Open exact degradation explanation') }}"><span>{{ $display['icon'] }}</span><span>{{ __($display['label']) }}</span></a>
@else
<span class="inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-semibold {{ $display['class'] }}"><span>{{ $display['icon'] }}</span><span>{{ __($display['label']) }}</span></span>
@endif
