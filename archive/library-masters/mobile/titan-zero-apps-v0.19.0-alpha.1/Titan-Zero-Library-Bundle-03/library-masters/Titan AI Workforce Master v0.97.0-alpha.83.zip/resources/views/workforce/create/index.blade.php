@php
    $totalSteps = 20;
    $publicRoles = collect($roleCatalog);
@endphp
@extends('panel.layout.app', ['disable_tblr' => true, 'disable_titlebar' => true])
@section('title', __('Add Staff Member'))
@push('css')
<style>@media(min-width:992px){.lqd-navbar-expander,.lqd-navbar,.lqd-header,.lqd-page-footer{display:none!important}.lqd-page-wrapper{padding-inline:0!important}}[x-cloak]{display:none!important}</style>
@endpush
@section('content')
<div class="flex min-h-screen flex-col items-center justify-center py-10 lg:py-24" x-data="{step:1,total:{{ $totalSteps }},selectedOwner:'titan-ai-workforce'}">
    <div class="fixed inset-x-0 top-0 z-20 flex items-center bg-background/85 p-4 backdrop-blur">
        <div class="flex basis-1/3"><x-button variant="link" x-show="step>1" @click.prevent="step--"><x-tabler-arrow-left class="size-4"/>{{ __('Back') }}</x-button></div>
        <div class="flex basis-1/3 flex-col items-center gap-2"><div class="h-1.5 w-44 overflow-hidden rounded-full bg-foreground/10"><div class="h-full bg-foreground transition-all" :style="`width:${(step/total)*100}%`"></div></div><div class="text-xs text-foreground/50">{{ __('Employee Builder') }} · <span x-text="step"></span>/{{ $totalSteps }}</div></div>
        <div class="flex basis-1/3 justify-end"><x-button variant="link" href="{{ route('dashboard.user.titan-workforce.team') }}"><x-tabler-x class="size-4"/></x-button></div>
    </div>
    <form method="POST" action="{{ route('dashboard.user.titan-workforce.store') }}" class="mx-auto w-full max-w-xl px-5 pt-12">@csrf
        @if($errors->any())<div class="mb-5 rounded-xl border border-red-500/30 bg-red-500/5 p-4 text-sm"><div class="font-semibold">{{ __('Please correct the setup details.') }}</div><ul class="mt-2 list-disc ps-5">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
        <section x-show="step===1" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Identity') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Give this digital employee a clear human identity.') }}</p>
                <div class="mt-6"><label class="block text-sm font-medium">{{ __('Staff name') }}</label><input class="form-control mt-2" name="name" value="{{ old('name') }}" required placeholder="e.g. Finance Manager"><label class="mt-5 block text-sm font-medium">{{ __('Internal key (optional)') }}</label><input class="form-control mt-2" name="key" value="{{ old('key') }}" placeholder="finance-manager"></div>
            </div>
        </section>
        <section x-show="step===2" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Tier') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Tier is locked by the selected Workforce-owned RoleDefinition. Tier 3 Action Workers remain internal and are not hired from this builder.') }}</p><div class="mt-6 rounded-xl border bg-foreground/[.025] p-4 text-sm"><strong>{{ __('Governed capability binding') }}</strong><p class="mt-2 mb-0 text-foreground/60">{{ __('The builder cannot change a role from Manager to Specialist or Action Worker.') }}</p></div></div>
        </section>
        <section x-show="step===3" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Division & team') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Division and team are owned by Workforce and inherited from the selected intrinsic RoleDefinition.') }}</p><div class="mt-6 rounded-xl border bg-foreground/[.025] p-4 text-sm">{{ __('The organisational containers are resolved from the canonical Workforce division and team catalogues.') }}</div></div>
        </section>
        <section x-show="step===4" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Role') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Choose an intrinsic Workforce role. Installed extensions attach governed capabilities to the role without owning the employee identity.') }}</p>
                <div class="mt-6"><select class="form-control" name="role_definition_id" required>@foreach($publicRoles->groupBy('division') as $divisionKey => $roles)<optgroup label="{{ str($divisionKey)->replace('-', ' ')->title() }}">@foreach($roles as $role)<option value="{{ $role['role_id'] }}" data-owner="{{ $role['owner_extension'] }}" @selected(old('role_definition_id', $preselectedRole) === $role['role_id'] || old('role_definition_id', $preselectedRole) === $role['key'])>{{ $role['name'] }} @if(count($role['capability_providers'] ?? [])) · {{ count($role['capability_providers']) }} provider(s) @endif</option>@endforeach</optgroup>@endforeach</select><input type="hidden" name="role_owner_extension" x-bind:value="selectedOwner"><p class="mt-3 text-xs text-foreground/50">{{ __('Workforce owns role identity, tier, division, team and responsibilities. Provider capabilities/tools/workflows are attached separately and never inherit authority.') }}</p></div>
            </div>
        </section>
        <section x-show="step===5" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Manager') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('No specialist should self-certify consequential work.') }}</p>
                <div class="mt-6"><select class="form-control" name="manager_id"><option value="">{{ __('Titan AI Core / Owner (for Tier 1 Managers)') }}</option>@foreach($managers as $manager)<option value="{{ $manager->id }}">{{ $manager->name }} — {{ $manager->role }}</option>@endforeach</select></div>
            </div>
        </section>
        <section x-show="step===6" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Responsibilities') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Canonical responsibilities are owned by Titan AI Workforce. Add company-specific instructions without changing the role contract; installed capability extensions determine which governed actions the employee can perform.') }}</p><div class="mt-6"><textarea class="form-control" name="local_instructions" rows="5" placeholder="Optional local instructions">{{ old('local_instructions') }}</textarea></div></div>
        </section>
        <section x-show="step===7" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Skills') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Skills are supplied by the intrinsic RoleDefinition. They describe competence and remain separate from authority.') }}</p><div class="mt-6 rounded-xl border bg-foreground/[.025] p-4 text-sm">{{ __('Governed capability binding — no free-form skill injection during activation.') }}</div></div>
        </section>
        <section x-show="step===8" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Capabilities') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Capabilities come from installed provider bindings. This builder cannot mint new business authority.') }}</p><div class="mt-6 rounded-xl border bg-foreground/[.025] p-4 text-sm"><strong>{{ __('Governed capability binding') }}</strong><p class="mt-2 mb-0 text-foreground/60">{{ __('Capability expansion requires a provider binding and still passes Risk, Assurance, Governance and Autonomy.') }}</p></div></div>
        </section>
        <section x-show="step===9" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Capability variants') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Variants and tools are attached from provider contracts, not from employee identity.') }}</p></div>
        </section>
        <section x-show="step===10" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Playbooks') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Playbooks remain owned by the capability extension and are attached automatically.') }}</p></div>
        </section>
        <section x-show="step===11" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Interaction Wizards') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Workflow references are attached by provider contracts and cannot be broadened here.') }}</p></div>
        </section>
        <section x-show="step===12" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Knowledge sources') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Knowledge and data-source access is attached through governed providers and remains externally authorised.') }}</p></div>
        </section>
        <section x-show="step===13" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Memory scope') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Memory scope is controlled by Workforce runtime profile and tenant policy; activation cannot widen it.') }}</p></div>
        </section>
        <section x-show="step===14" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Initial authority / Autonomy') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Role activation does not inherit provider authority. Effective capability authority remains exclusively decided by Titan Autonomy and the control plane.') }}</p><div class="mt-6 rounded-xl border bg-foreground/[.025] p-4 text-sm">{{ __('No Autonomy grant can be entered in Employee Builder.') }}</div></div>
        </section>
        <section x-show="step===15" x-cloak>
            <div class="rounded-2xl border bg-card p-7"><h1 class="m-0 text-2xl font-semibold">{{ __('Risk ceiling') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('The maximum role risk ceiling is owned by Workforce and cannot be raised by a capability provider during activation.') }}</p></div>
        </section>
        <section x-show="step===16" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Assurance requirements') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Define the minimum evidence state required for normal work progression.') }}</p>
                <div class="mt-6"><select class="form-control" name="assurance_required"><option>RED</option><option selected>AMBER</option><option>GREEN</option></select></div>
            </div>
        </section>
        <section x-show="step===17" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Schedule') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Proactive staff receive scheduled and event-triggered responsibilities.') }}</p>
                <div class="mt-6"><select class="form-control" name="schedule_config[frequency]"><option value="">{{ __('No default recurrence') }}</option><option value="hourly">Hourly</option><option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option></select><input class="form-control mt-3" type="time" name="schedule_config[time]"></div>
            </div>
        </section>
        <section x-show="step===18" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Escalation') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Every disagreement and blocked job must have a defined exit.') }}</p>
                <div class="mt-6"><select class="form-control" name="escalation_policy[default]"><option>RETURN_TO_MAKER</option><option>RETRY_WITH_EVIDENCE</option><option>ESCALATE_TO_PARENT</option><option>ESCALATE_TO_TITAN</option><option>HUMAN_DECISION_REQUIRED</option></select></div>
            </div>
        </section>
        <section x-show="step===19" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Model / provider') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Preferences are advisory; Titan AI Core retains runtime governance.') }}</p>
                <div class="mt-6"><input class="form-control" name="provider_preferences[preferred]" placeholder="Provider preference (optional)"><input class="form-control mt-3" name="model_preferences[preferred]" placeholder="Model preference (optional)"></div>
            </div>
        </section>
        <section x-show="step===20" x-cloak>
            <div class="rounded-2xl border bg-card p-7">
                <h1 class="m-0 text-2xl font-semibold">{{ __('Activation') }}</h1>
                <p class="mt-2 text-sm text-foreground/60">{{ __('Submitting this builder explicitly activates one tenant-specific instance of the selected RoleDefinition.') }}</p>
                <div class="mt-6"><div class="rounded-xl border bg-foreground/[.025] p-4 text-sm"><p class="m-0 font-medium">{{ __('Activation rules') }}</p><ul class="mt-2 list-disc ps-5 text-foreground/65"><li>{{ __('No direct authoritative domain writes.') }}</li><li>{{ __('Consequential work uses Risk, Assurance, Autonomy and Command Bus.') }}</li><li>{{ __('Cross-division work uses Manager → governed handoff → receiving Manager.') }}</li><li>{{ __('Every meaningful transition is traceable and Signal-compatible.') }}</li></ul></div><button class="mt-5 w-full rounded-lg bg-primary px-4 py-3 font-semibold text-primary-foreground" type="submit">{{ __('Add Staff Member') }}</button></div>
            </div>
        </section>
        <div class="mt-8 flex justify-end" x-show="step<total"><x-button @click.prevent="step++">{{ __('Continue') }}<x-tabler-arrow-right class="size-4"/></x-button></div>
    </form>
</div>
@endsection
