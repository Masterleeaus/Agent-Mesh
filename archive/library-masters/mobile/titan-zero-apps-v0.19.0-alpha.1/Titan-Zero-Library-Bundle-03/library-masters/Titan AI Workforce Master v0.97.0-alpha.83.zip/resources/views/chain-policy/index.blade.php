@extends('panel.layout.app')
@section('title', __('Chain Policy'))
@section('content')
<div class="py-10">
    <div class="container-xl space-y-8">
        <div>
            <h1 class="mb-2 text-3xl font-semibold">{{ __('Chain-of-Command Policy') }}</h1>
            <p class="text-muted-foreground">
                {{ __('Company-level controls may tighten scrutiny, pause work, or require manual review. They cannot reduce the three independent checks, remove Knowledge Authority, bypass final authority gates, or force-approve an action.') }}
            </p>
        </div>

        @if(session('success'))
            <div class="rounded-xl border p-4">{{ session('success') }}</div>
        @endif

        <div class="grid gap-4 md:grid-cols-4">
            <div class="rounded-xl border p-4"><div class="text-xs opacity-70">Policy revision</div><div class="text-2xl font-semibold">{{ $policy->revision }}</div></div>
            <div class="rounded-xl border p-4"><div class="text-xs opacity-70">Mandatory checks</div><div class="text-2xl font-semibold">3 / 3</div></div>
            <div class="rounded-xl border p-4"><div class="text-xs opacity-70">Knowledge Authority</div><div class="text-2xl font-semibold">Required</div></div>
            <div class="rounded-xl border p-4"><div class="text-xs opacity-70">Force approve</div><div class="text-2xl font-semibold">Disabled</div></div>
        </div>

        <form method="POST" action="{{ route('dashboard.user.titan-workforce.chain-policy.update') }}" class="space-y-6 rounded-xl border p-6">
            @csrf
            <div class="grid gap-5 md:grid-cols-3">
                <label class="block">
                    <span class="text-sm font-medium">Base reviewer quality floor</span>
                    <input class="mt-2 w-full rounded-lg border bg-transparent p-3" type="number" min="0" max="100" name="minimum_reviewer_quality" value="{{ $policy->minimum_reviewer_quality }}">
                </label>
                <label class="block">
                    <span class="text-sm font-medium">High-risk reviewer floor</span>
                    <input class="mt-2 w-full rounded-lg border bg-transparent p-3" type="number" min="70" max="100" name="high_risk_reviewer_quality" value="{{ $policy->high_risk_reviewer_quality }}">
                </label>
                <label class="block">
                    <span class="text-sm font-medium">Critical reviewer floor</span>
                    <input class="mt-2 w-full rounded-lg border bg-transparent p-3" type="number" min="80" max="100" name="critical_risk_reviewer_quality" value="{{ $policy->critical_risk_reviewer_quality }}">
                </label>
            </div>

            @foreach([
                'require_provider_diversity_high_risk'=>'Provider/model diversity for high risk',
                'require_assurance_high_risk'=>'Assurance for high risk',
                'require_model_council_critical'=>'Model Council for critical risk',
                'require_explicit_evidence_high_risk'=>'Explicit evidence references for high risk',
                'require_manual_extreme_risk'=>'Manual review receipt for extreme risk',
                'allow_learned_policy'=>'Allow user-approved learned recommendations'
            ] as $field=>$label)
                <input type="hidden" name="{{ $field }}" value="0">
                <label class="flex items-center justify-between rounded-xl border p-4">
                    <span>{{ __($label) }}</span>
                    <input type="checkbox" name="{{ $field }}" value="1" @checked($policy->{$field})>
                </label>
            @endforeach

            <div>
                <label class="block text-sm font-medium">{{ __('Federation paths by capability') }}</label>
                <p class="mt-1 text-xs opacity-70">JSON example: {"booking.create":["booking","jobs","dispatch","invoice","payment"]}</p>
                <textarea name="federation_paths_json" rows="8" class="mt-2 w-full rounded-lg border bg-transparent p-3 font-mono text-xs">{{ json_encode($policy->federation_paths ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</textarea>
            </div>

            <button type="submit" class="rounded-lg border px-5 py-3 font-medium">{{ __('Save governed policy') }}</button>
        </form>

        <div class="rounded-xl border p-6">
            <h2 class="mb-3 text-xl font-semibold">{{ __('Immutable platform floors') }}</h2>
            <ul class="list-disc space-y-2 pl-5 text-sm opacity-80">
                <li>Three independent AI checks remain mandatory.</li>
                <li>Knowledge Authority remains required for consequential/federated processing.</li>
                <li>Admin overrides cannot force approval.</li>
                <li>Recovery cannot perform an ungoverned automatic undo.</li>
                <li>Governance, Risk and negotiated Autonomy remain final authority gates.</li>
            </ul>
        </div>
    </div>
</div>
@endsection
