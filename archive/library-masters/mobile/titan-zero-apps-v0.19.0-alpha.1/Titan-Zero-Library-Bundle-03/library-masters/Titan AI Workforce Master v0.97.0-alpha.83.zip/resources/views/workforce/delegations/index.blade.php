@extends('panel.layout.app')
@section('title', __('Delegations'))
@section('content')
@php($rows=$center['rows'])
<div class="container-xl py-6 space-y-5">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div><h1 class="mb-1">{{ __('Delegation Center') }}</h1><p class="text-muted mb-0">{{ __('Who delegated what work, to whom, for how long, and under which non-transferable authority boundary.') }}</p></div>
    <div class="flex flex-wrap gap-2 text-xs">
      <span class="rounded-full border px-3 py-1">{{ __('Active') }} {{ $center['counts']['active'] }}</span>
      <span class="rounded-full border px-3 py-1">{{ __('Expired') }} {{ $center['counts']['expired'] }}</span>
      <span class="rounded-full border px-3 py-1">{{ __('Revoked') }} {{ $center['counts']['revoked'] }}</span>
    </div>
  </div>
  <div class="rounded-xl border bg-card p-4 text-sm">
    <strong>{{ __('Authority boundary') }}:</strong> {{ __('Delegation never grants executable capability. It only assigns work scope; every consequential action still requires fresh capability, Risk, Assurance, Governance and Titan Autonomy authorization.') }}
  </div>
  <div class="overflow-x-auto rounded-xl border bg-card">
    <table class="min-w-full text-sm">
      <thead><tr class="border-b text-left"><th class="p-3">{{ __('Delegator') }}</th><th class="p-3">{{ __('Delegate') }}</th><th class="p-3">{{ __('Responsibility') }}</th><th class="p-3">{{ __('Work scope') }}</th><th class="p-3">{{ __('Start / end') }}</th><th class="p-3">{{ __('Status') }}</th><th class="p-3">{{ __('Related tasks') }}</th></tr></thead>
      <tbody>
      @forelse($rows as $row)
        <tr class="border-b align-top">
          <td class="p-3">@if($row['delegator'])<a class="font-medium hover:underline" href="{{ $row['delegator']['url'] }}">{{ $row['delegator']['name'] }}</a><div class="text-xs text-foreground/50">{{ $row['delegator']['role_definition_id'] }}</div>@else—@endif</td>
          <td class="p-3">@if($row['delegate'])<a class="font-medium hover:underline" href="{{ $row['delegate']['url'] }}">{{ $row['delegate']['name'] }}</a><div class="text-xs text-foreground/50">{{ $row['delegate']['role_definition_id'] }}</div>@else—@endif</td>
          <td class="p-3">{{ $row['responsibility'] }}</td>
          <td class="p-3"><div class="flex flex-wrap gap-1">@forelse($row['work_scope'] as $scope)<span class="rounded border px-2 py-1 text-xs">{{ $scope }}</span>@empty<span class="text-foreground/50">{{ __('No executable scope transferred') }}</span>@endforelse</div></td>
          <td class="p-3 text-xs"><div>{{ $row['start_at'] ?? '—' }}</div><div>{{ $row['end_at'] ?? __('Open-ended') }}</div></td>
          <td class="p-3"><span class="rounded-full border px-2 py-1 text-xs font-semibold">{{ ucfirst(strtolower($row['effective_status'])) }}</span></td>
          <td class="p-3">@forelse($row['related_tasks'] as $task)<a class="block hover:underline" href="{{ $task['url'] }}">{{ $task['title'] }}</a>@empty—@endforelse</td>
        </tr>
        <tr class="border-b bg-muted/20"><td colspan="7" class="p-3"><div class="grid gap-3 md:grid-cols-3"><div><div class="font-semibold">{{ __('Reason') }}</div><div class="text-xs text-foreground/60">{{ $row['reason'] ?: __('No reason recorded.') }}</div></div><div><div class="font-semibold">{{ __('Authority boundary') }}</div><div class="text-xs text-foreground/60">{{ $row['authority_boundary']['note'] }}</div></div><div><div class="font-semibold">{{ __('Audit history') }}</div>@foreach($row['audit_history'] as $audit)<div class="text-xs text-foreground/60">{{ $audit['at'] ?? '—' }} · {{ $audit['event'] ?? 'event' }}@if(!empty($audit['reason'])) · {{ $audit['reason'] }}@endif</div>@endforeach</div></div></td></tr>
      @empty
        <tr><td colspan="7" class="p-6 text-center text-foreground/50">{{ __('No delegation records yet.') }}</td></tr>
      @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection
