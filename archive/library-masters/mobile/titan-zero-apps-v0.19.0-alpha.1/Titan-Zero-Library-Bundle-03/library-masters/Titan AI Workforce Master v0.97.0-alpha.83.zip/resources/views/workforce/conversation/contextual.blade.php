@extends('panel.layout.app')
@section('title', 'Ask Workforce')
@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-start gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1">Ask Workforce</h1>
            <p class="text-muted mb-0">Contextual chat about this {{ ucfirst($context['context_type']) }}. Context does not grant authority.</p>
        </div>
        <span class="badge bg-secondary">Read-only context</span>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <div class="small text-muted mb-2">{{ ucfirst($context['context_type']) }} context</div>
            <pre class="mb-0 small" style="white-space:pre-wrap">{{ json_encode($context['object'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre>
        </div>
    </div>

    <form method="POST" action="{{ route('dashboard.user.titan-workforce.contextual-chat.submit', ['type'=>$context['context_type'],'id'=>$context['context_id']]) }}" class="card mb-4">
        @csrf
        <div class="card-body">
            <label class="form-label fw-semibold">Ask about this context</label>
            <textarea name="message" class="form-control" rows="4" maxlength="4000" required>{{ old('message', $message) }}</textarea>
            <div class="form-text">Requests to do work remain governed Work Items and require fresh execution authorization.</div>
        </div>
        <div class="card-footer text-end"><button class="btn btn-primary">Ask Workforce</button></div>
    </form>

    @if($response)
    <div class="card">
        <div class="card-body">
            <h2 class="h6">Workforce response</h2>
            <p class="mb-3">{{ $response['message'] ?? '' }}</p>
            <div class="small text-muted">Context mutated: {{ ($response['context_mutated'] ?? false) ? 'Yes' : 'No' }} · Authority inherited: No · Execution authority granted: No</div>
        </div>
    </div>
    @endif
</div>
@endsection
