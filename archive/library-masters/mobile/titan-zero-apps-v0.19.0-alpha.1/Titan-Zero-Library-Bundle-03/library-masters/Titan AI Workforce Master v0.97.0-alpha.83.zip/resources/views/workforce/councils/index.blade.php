@extends('panel.layout.app')
@section('title', __('Councils'))
@section('content')
<div class="container-xl py-6 space-y-5">
  <div class="flex flex-wrap items-start justify-between gap-3">
    <div>
      <h1 class="mb-1">{{ __('Councils & Multi-Agent Decisions') }}</h1>
      <p class="text-muted mb-0">{{ __('Governed cross-functional deliberation with explicit participants, evidence, dissent, recommendations, decisions and follow-up work.') }}</p>
    </div>
    <span class="rounded-full border px-3 py-1 text-xs">{{ count($center['councils']) }} {{ __('active council records') }}</span>
  </div>

  <div class="rounded-xl border bg-card p-4 text-sm">
    <strong>{{ __('Authority boundary') }}:</strong>
    {{ __('Council membership, recommendations and final decisions do not grant executable capability. Any consequential follow-up Work Item must independently pass capability availability, Risk, Assurance, Governance and Autonomy.') }}
  </div>

  <section class="space-y-3">
    <div><h2 class="text-lg font-semibold">{{ __('Built-in council templates') }}</h2><p class="text-sm text-foreground/60">{{ __('Convene a council around a concrete issue. Existing active staff matching the template roles become participants.') }}</p></div>
    <div class="grid gap-3 lg:grid-cols-2">
      @foreach($center['templates'] as $key => $template)
        <article class="rounded-xl border bg-card p-4">
          <div class="flex items-start justify-between gap-3">
            <div><div class="font-semibold">{{ $template['name'] }}</div><div class="mt-1 text-sm text-foreground/60">{{ $template['purpose'] }}</div></div>
            <span class="rounded-full border px-2 py-1 text-xs">{{ ucfirst(str_replace('_',' ', $template['cadence'] ?? 'as_needed')) }}</span>
          </div>
          <div class="mt-3 grid gap-2 text-xs md:grid-cols-2">
            <div><strong>{{ __('Chair role') }}:</strong> {{ $template['chair'] }}</div>
            <div><strong>{{ __('Participants') }}:</strong> {{ count($template['participants'] ?? []) }}</div>
          </div>
          <form class="mt-4 grid gap-2" method="POST" action="{{ route('dashboard.user.titan-workforce.councils.convene') }}">
            @csrf
            <input type="hidden" name="council_key" value="{{ $key }}">
            <textarea class="form-control" name="issue" required maxlength="4000" rows="2" placeholder="{{ __('Issue this council should deliberate') }}"></textarea>
            <div class="grid gap-2 md:grid-cols-[1fr_1fr_auto]">
              <input class="form-control" name="priority" type="number" min="1" max="100" value="70" aria-label="{{ __('Priority') }}">
              <select class="form-select" name="risk_level" aria-label="{{ __('Risk level') }}"><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option></select>
              <button class="btn btn-primary" type="submit">{{ __('Convene') }}</button>
            </div>
          </form>
        </article>
      @endforeach
    </div>
  </section>

  <section class="space-y-3">
    <h2 class="text-lg font-semibold">{{ __('Operational councils') }}</h2>
    <div class="overflow-x-auto rounded-xl border bg-card">
      <table class="min-w-full text-sm">
        <thead><tr class="border-b text-left"><th class="p-3">{{ __('Council') }}</th><th class="p-3">{{ __('Chair') }}</th><th class="p-3">{{ __('Participants') }}</th><th class="p-3">{{ __('Current issue') }}</th><th class="p-3">{{ __('Decision') }}</th><th class="p-3">{{ __('Follow-up work') }}</th></tr></thead>
        <tbody>
        @forelse($center['councils'] as $council)
          <tr class="border-b align-top">
            <td class="p-3"><a class="font-semibold hover:underline" href="{{ $council['url'] }}">{{ $council['name'] }}</a><div class="text-xs text-foreground/50">{{ $council['key'] }}</div></td>
            <td class="p-3">@if(!empty($council['chair']['member']))<a class="hover:underline" href="{{ $council['chair']['member']['url'] }}">{{ $council['chair']['member']['name'] }}</a>@else<span class="text-foreground/50">{{ __('No active chair') }}</span>@endif</td>
            <td class="p-3">{{ count($council['participants']) }}</td>
            <td class="p-3">{{ $council['issue'] ?: '—' }}</td>
            <td class="p-3">{{ $council['final_decision'] ?: ($council['recommendation'] ?: '—') }}</td>
            <td class="p-3">{{ count($council['follow_up_work_items']) }}</td>
          </tr>
        @empty
          <tr><td colspan="6" class="p-6 text-center text-foreground/50">{{ __('No councils have been convened yet.') }}</td></tr>
        @endforelse
        </tbody>
      </table>
    </div>
  </section>
</div>
@endsection
