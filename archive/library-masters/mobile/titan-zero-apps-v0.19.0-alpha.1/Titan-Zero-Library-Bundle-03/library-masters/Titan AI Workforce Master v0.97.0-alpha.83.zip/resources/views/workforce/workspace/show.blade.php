@extends('panel.layout.app')

@section('title', ($workspace['team']?->name ?? $workspace['division']->name).' · Workforce')

@section('content')
@php
    $scope = $workspace['scope'];
    $entity = $workspace['team'] ?: $workspace['division'];
    $queue = $workspace['queue_health'];
    $cap = $workspace['capability_health'];
    $pressureClass = match($queue['pressure'] ?? 'NORMAL') { 'CRITICAL' => 'bg-red-500/10 text-red-700 dark:text-red-300', 'HIGH' => 'bg-orange-500/10 text-orange-700 dark:text-orange-300', 'ELEVATED' => 'bg-amber-500/10 text-amber-700 dark:text-amber-300', default => 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' };
    $status = fn($task) => (string) ($task->status?->value ?? $task->status);
@endphp
<div class="space-y-6" data-workforce-operational-workspace data-scope="{{ $scope }}" data-scope-id="{{ $entity->id }}">
    <div class="flex flex-wrap items-start justify-between gap-4"><a href="{{ route('dashboard.user.titan-workforce.contextual-chat', ['type'=>$scope,'id'=>$entity->id]) }}" class="rounded-lg border px-3 py-2 text-sm font-semibold">{{ __('Ask Workforce') }}</a>

        <div>
            <div class="flex flex-wrap items-center gap-2 text-xs text-foreground/45">
                <a href="{{ route('dashboard.user.titan-workforce.team') }}" class="hover:underline">{{ __('Organisation') }}</a><span>→</span>
                @if($scope === 'team')<a href="{{ route('dashboard.user.titan-workforce.divisions.show', $workspace['division']->id) }}" class="hover:underline">{{ $workspace['division']->name }}</a><span>→</span>@endif
                <span>{{ $scope === 'team' ? __('Team') : __('Division') }}</span>
            </div>
            <h1 class="mt-2 text-2xl font-semibold">{{ $entity->name }}</h1>
            <p class="mt-1 max-w-3xl text-sm text-foreground/55">{{ $entity->purpose ?: data_get($entity,'definition.purpose') ?: __('Operational workspace for work, responsibility, capability and outcomes.') }}</p>
        </div>
        <div class="flex items-center gap-2"><span class="rounded-full px-3 py-1 text-xs font-semibold {{ $pressureClass }}">{{ __('Queue') }} {{ $queue['pressure'] ?? 'NORMAL' }}</span><span class="rounded-full bg-foreground/5 px-3 py-1 text-xs">{{ count($workspace['members']) }} {{ __('staff') }}</span></div>
    </div>

    <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        @foreach([
            [__('Open work'), count($workspace['work']['queue'])],
            [__('Blocked'), count($workspace['work']['blocked'])],
            [__('Objectives'), count($workspace['work']['objectives'])],
            [__('Active schedules'), collect($workspace['schedules'])->where('is_active',true)->count()],
            [__('Verified outcomes'), count($workspace['verified_outcomes'])],
            [__('Handoffs'), count($workspace['handoffs'])],
        ] as [$label,$value])
        <div class="rounded-xl border bg-card p-4"><div class="text-xs text-foreground/45">{{ $label }}</div><div class="mt-1 text-2xl font-semibold">{{ $value }}</div></div>
        @endforeach
    </div>

    <div class="grid gap-5 xl:grid-cols-3">
        <section class="rounded-2xl border bg-card p-5 xl:col-span-2">
            <div class="flex items-center justify-between"><div><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Leadership & team') }}</div><h2 class="mt-1 text-lg font-semibold">{{ __('Operational ownership') }}</h2></div>@if($workspace['manager'])<div class="flex gap-3"><a href="{{ route('dashboard.user.titan-workforce.managers.show',$workspace['manager']->id) }}" class="text-sm font-medium hover:underline">{{ __('Manager Command →') }}</a><a href="{{ route('dashboard.user.titan-workforce.staff.show',$workspace['manager']->id) }}" class="text-sm font-medium hover:underline">{{ __('Manager 360 →') }}</a></div>@endif</div>
            <div class="mt-4 rounded-xl border p-4"><div class="text-xs text-foreground/45">{{ __('Manager') }}</div>@if($workspace['manager'])<a class="mt-1 inline-block font-semibold hover:underline" href="{{ route('dashboard.user.titan-workforce.staff.show',$workspace['manager']->id) }}">{{ $workspace['manager']->name }}</a><div class="text-sm text-foreground/55">{{ $workspace['manager']->role }}</div>@else<div class="mt-1 font-semibold text-amber-700 dark:text-amber-300">{{ __('No manager assigned') }}</div>@endif</div>
            <div class="mt-4 grid gap-3 md:grid-cols-2 2xl:grid-cols-3">
                @foreach($workspace['members'] as $member)<a href="{{ route('dashboard.user.titan-workforce.staff.show',$member->id) }}" class="rounded-xl border p-3 transition hover:-translate-y-0.5 hover:shadow-sm"><div class="font-medium">{{ $member->name }}</div><div class="text-xs text-foreground/50">{{ $member->role }}</div><div class="mt-2 text-[10px] uppercase tracking-wide text-foreground/40">{{ $member->manager?->name ? __('Reports to').' '.$member->manager->name : __('Executive / unassigned reporting') }}</div></a>@endforeach
            </div>
        </section>
        <section class="rounded-2xl border bg-card p-5"><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Queue pressure') }}</div><h2 class="mt-1 text-lg font-semibold">{{ $queue['pressure'] ?? 'NORMAL' }}</h2><div class="mt-4 space-y-3 text-sm">
            @foreach([[__('Queue depth'),$queue['queue_depth']??0],[__('Capacity'),$queue['active_capacity']??0],[__('Load ratio'),$queue['load_ratio']??0],[__('Overdue'),$queue['overdue_count']??0],[__('Blocked'),$queue['blocked_count']??0],[__('Escalated'),$queue['escalated_count']??0]] as [$l,$v])<div class="flex justify-between border-b pb-2"><span class="text-foreground/50">{{ $l }}</span><strong>{{ $v }}</strong></div>@endforeach
        </div></section>
    </div>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="rounded-2xl border bg-card p-5"><div class="flex items-center justify-between"><h2 class="text-lg font-semibold">{{ __('Current objectives') }}</h2><span class="text-xs text-foreground/45">{{ count($workspace['work']['objectives']) }}</span></div><div class="mt-4 space-y-2">@forelse($workspace['work']['objectives'] as $task)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><div class="font-medium">{{ $task->title }}</div><span class="text-xs">{{ $status($task) }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ $task->assignee?->name ?: __('Unassigned') }} · {{ __('Priority') }} {{ $task->priority }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No active top-level objectives.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><div class="flex items-center justify-between"><h2 class="text-lg font-semibold">{{ __('Blocked work') }}</h2><span class="text-xs text-foreground/45">{{ count($workspace['work']['blocked']) }}</span></div><div class="mt-4 space-y-2">@forelse($workspace['work']['blocked'] as $task)<div class="rounded-xl border border-amber-500/20 p-3"><div class="font-medium">{{ $task->title }}</div><div class="mt-1 text-xs text-foreground/45">{{ $status($task) }} · {{ $task->assignee?->name ?: __('Unassigned') }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No blocked work.') }}</p>@endforelse</div></section>
    </div>

    <section class="rounded-2xl border bg-card p-5"><div class="flex flex-wrap items-center justify-between gap-2"><div><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Capability health') }}</div><h2 class="mt-1 text-lg font-semibold">{{ __('Live role/provider readiness') }}</h2></div><div class="flex flex-wrap gap-2 text-xs">@foreach(['available','degraded','blocked','missing_provider','policy_disabled','unavailable'] as $s)@if(($cap[$s]??0)>0)<span class="rounded-full bg-foreground/5 px-2.5 py-1">{{ $s }} {{ $cap[$s] }}</span>@endif @endforeach</div></div>
        <div class="mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-3">@foreach($cap['members'] as $row)<a href="{{ route('dashboard.user.titan-workforce.staff.show',$row['id']) }}" class="rounded-xl border p-3"><div class="flex items-center justify-between gap-2"><div><div class="font-medium">{{ $row['name'] }}</div><div class="text-xs text-foreground/45">{{ $row['role'] }}</div></div><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold">{{ $row['state'] }}</span></div><div class="mt-2 truncate text-[10px] text-foreground/40">{{ implode(' · ', $row['providers']) ?: __('No live providers') }}</div></a>@endforeach</div>
        <p class="mt-4 text-[11px] text-foreground/40">{{ __('Capability health is read-only. Provider availability never grants execution authority.') }}</p>
    </section>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Responsibilities') }}</h2><div class="mt-4 space-y-2">@forelse(array_slice($workspace['responsibilities'],0,30) as $r)<div class="rounded-xl border p-3"><div class="font-medium">{{ $r['name'] ?? $r['title'] ?? $r['responsibility_id'] ?? $r['key'] ?? __('Responsibility') }}</div><div class="mt-1 text-xs text-foreground/45">{{ $r['owner_name'] ?? '' }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No canonical responsibilities resolved for current staff.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Schedules') }}</h2><div class="mt-4 space-y-2">@forelse($workspace['schedules'] as $schedule)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><div class="font-medium">{{ $schedule->name }}</div><span class="text-xs {{ $schedule->is_active ? 'text-emerald-600':'text-foreground/40' }}">{{ $schedule->is_active ? __('Active'):__('Inactive') }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ __('Next') }}: {{ $schedule->next_run_at?->toDayDateTimeString() ?: '—' }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No schedules configured.') }}</p>@endforelse</div></section>
    </div>

    <div class="grid gap-5 xl:grid-cols-3">
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Handoffs') }}</h2><div class="mt-4 space-y-2">@forelse($workspace['handoffs']->take(20) as $h)<div class="rounded-xl border p-3 text-sm"><div class="font-medium">{{ (string)($h->status?->value ?? $h->status) }}</div><div class="text-xs text-foreground/45">{{ __('Task') }} #{{ $h->task_id }} · {{ $h->created_at?->diffForHumans() }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No recent handoffs.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Performance') }}</h2><div class="mt-4 space-y-2">@forelse($workspace['performance']->take(20) as $m)<div class="flex justify-between rounded-xl border p-3 text-sm"><span>{{ $m->metric_key }}</span><strong>{{ rtrim(rtrim(number_format((float)$m->metric_value,3), '0'),'.') }}</strong></div>@empty<p class="text-sm text-foreground/50">{{ __('No performance metrics yet.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Verified outcomes') }}</h2><div class="mt-4 space-y-2">@forelse($workspace['verified_outcomes']->take(20) as $o)<div class="rounded-xl border p-3"><div class="flex justify-between gap-2 text-sm"><span class="font-medium">{{ $o->outcome_type }}</span><span>{{ $o->success === null ? '—' : ($o->success ? '✓':'✕') }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ $o->verified_at?->diffForHumans() }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No verified outcomes yet.') }}</p>@endforelse</div></section>
    </div>

    <section class="rounded-2xl border bg-card p-5"><div class="flex items-center justify-between"><h2 class="text-lg font-semibold">{{ __('Work queue') }}</h2><a href="{{ route('dashboard.user.titan-workforce.tasks') }}" class="text-sm font-medium hover:underline">{{ __('Open all work →') }}</a></div><div class="mt-4 overflow-x-auto"><table class="w-full text-left text-sm"><thead class="text-xs uppercase text-foreground/40"><tr><th class="pb-2">{{ __('Work') }}</th><th>{{ __('Status') }}</th><th>{{ __('Owner') }}</th><th>{{ __('Priority') }}</th><th>{{ __('Deadline') }}</th></tr></thead><tbody>@forelse($workspace['work']['queue'] as $task)<tr class="border-t"><td class="py-3 pr-4 font-medium">{{ $task->title }}</td><td>{{ $status($task) }}</td><td>{{ $task->assignee?->name ?: '—' }}</td><td>{{ $task->priority }}</td><td>{{ $task->deadline_at?->toDateString() ?: '—' }}</td></tr>@empty<tr><td colspan="5" class="py-6 text-center text-foreground/45">{{ __('Queue is clear.') }}</td></tr>@endforelse</tbody></table></div></section>
</div>
@endsection
