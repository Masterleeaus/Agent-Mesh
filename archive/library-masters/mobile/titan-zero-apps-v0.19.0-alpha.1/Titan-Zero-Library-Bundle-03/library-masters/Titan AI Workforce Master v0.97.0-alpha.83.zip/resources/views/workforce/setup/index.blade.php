@extends('panel.layout.app', ['disable_tblr'=>true,'layout_wide'=>true])
@section('title', __('Workforce Setup'))
@section('content')
<div class="px-5 py-8 space-y-6">
<section class="rounded-2xl border bg-card p-6"><h1 class="text-2xl font-semibold">{{ __('Workforce Setup Wizard') }}</h1><p class="mt-2 text-sm text-foreground/60">{{ __('Configure the organisational starting point without automatically hiring employees or granting authority.') }}</p></section>
<form method="GET" class="rounded-2xl border bg-card p-5 space-y-4">
<h2 class="font-semibold">{{ __('Business profile') }}</h2>
<select name="business_tier" class="rounded-lg border bg-transparent px-3 py-2">@foreach(['SOLO','SMALL','GROWING','ENTERPRISE'] as $tier)<option @selected($profile['business_tier']===$tier)>{{ $tier }}</option>@endforeach</select>
<select name="operating_mode" class="rounded-lg border bg-transparent px-3 py-2">@foreach(['lean','balanced','coverage'] as $mode)<option @selected(($profile['operating_mode']??'balanced')===$mode)>{{ $mode }}</option>@endforeach</select>
<button class="rounded-lg border px-4 py-2">{{ __('Refresh recommendations') }}</button>
</form>
<div class="grid gap-4 lg:grid-cols-2">
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Recommended structure') }}</h2><p class="mt-2 text-sm">{{ count($setup['recommended_structure']['divisions']) }} {{ __('division signals') }} · {{ count($setup['recommended_roles']) }} {{ __('recommended roles') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Provider readiness') }}</h2><p class="mt-2 text-sm">{{ $setup['provider_readiness']['ready'] ? __('Ready') : __('Capability/provider gaps require review') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Responsibility coverage') }}</h2><p class="mt-2 text-sm">{{ $setup['responsibility_coverage']['gap_count'] }} {{ __('coverage gaps') }}</p></section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Review before apply') }}</h2><p class="mt-2 text-sm">{{ __('Applying creates canonical organisation containers only. Recommended employees still require explicit creation and approval.') }}</p></section>
</div>
<form method="POST" action="{{ route('dashboard.user.titan-workforce.setup.apply') }}" class="rounded-2xl border bg-card p-5">@csrf<input type="hidden" name="business_tier" value="{{ $profile['business_tier'] }}"><input type="hidden" name="operating_mode" value="{{ $profile['operating_mode'] ?? 'balanced' }}"><button class="rounded-lg bg-foreground px-4 py-2 text-background">{{ __('Apply organisation setup') }}</button></form>
@if($applied)<div class="rounded-xl border p-4 text-sm">{{ __('Setup applied. No employees were auto-created.') }} {{ $applied['organisation_containers_created'] }} {{ __('organisation containers are available.') }}</div>@endif
</div>
@endsection
