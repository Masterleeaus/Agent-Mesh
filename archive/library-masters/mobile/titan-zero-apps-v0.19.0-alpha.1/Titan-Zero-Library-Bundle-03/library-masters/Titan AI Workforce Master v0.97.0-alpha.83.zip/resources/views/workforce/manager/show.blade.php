@extends('panel.layout.app')

@section('title', $center['manager']->name.' · Manager Command Center')

@section('content')
@php
    $manager = $center['manager'];
    $q = $center['queue_health'];
    $status = fn($task) => (string) ($task->status?->value ?? $task->status);
    $pressureClass = match($q['pressure'] ?? 'NORMAL') { 'CRITICAL' => 'bg-red-500/10 text-red-700 dark:text-red-300', 'HIGH' => 'bg-orange-500/10 text-orange-700 dark:text-orange-300', 'ELEVATED' => 'bg-amber-500/10 text-amber-700 dark:text-amber-300', default => 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300' };
@endphp
<div class="space-y-6" data-manager-command-center data-manager-id="{{ $manager->id }}">
    <div class="flex flex-wrap items-start justify-between gap-4">
        <div>
            <div class="flex flex-wrap items-center gap-2 text-xs text-foreground/45"><a href="{{ route('dashboard.user.titan-workforce.team') }}" class="hover:underline">{{ __('Organisation') }}</a><span>→</span><span>{{ __('Manager Command Center') }}</span></div>
            <h1 class="mt-2 text-2xl font-semibold">{{ $manager->name }}</h1>
            <p class="mt-1 text-sm text-foreground/55">{{ $manager->role }} · {{ $manager->division?->name ?: __('No division') }} · {{ __('Operational home for reviews, team flow, handoffs, escalation and outcomes.') }}</p>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <span class="rounded-full px-3 py-1 text-xs font-semibold {{ $pressureClass }}">{{ __('Queue') }} {{ $q['pressure'] ?? 'NORMAL' }}</span>
            <a href="{{ route('dashboard.user.titan-workforce.staff.show',$manager->id) }}" class="rounded-lg border px-3 py-2 text-sm font-medium hover:bg-foreground/5">{{ __('Employee 360 →') }}</a>
        </div>
    </div>

    <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        @foreach([
            [__('My team'), count($center['my_team'])],
            [__('Awaiting review'), count($center['work_awaiting_review'])],
            [__('Blocked'), count($center['blocked_work'])],
            [__('Open escalations'), collect($center['escalations'])->where('status','OPEN')->count()],
            [__('Received handoffs'), count($center['handoffs_received'])],
            [__('Verified outcomes'), count($center['team_outcomes'])],
        ] as [$label,$value])
            <div class="rounded-xl border bg-card p-4"><div class="text-xs text-foreground/45">{{ $label }}</div><div class="mt-1 text-2xl font-semibold">{{ $value }}</div></div>
        @endforeach
    </div>

    <div class="grid gap-5 xl:grid-cols-3">
        <section class="rounded-2xl border bg-card p-5 xl:col-span-2">
            <div class="flex items-center justify-between"><div><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('My team') }}</div><h2 class="mt-1 text-lg font-semibold">{{ __('Staff availability') }}</h2></div><span class="text-xs text-foreground/45">{{ count($center['staff_availability']) }} {{ __('direct reports') }}</span></div>
            <div class="mt-4 grid gap-3 md:grid-cols-2">
                @forelse($center['staff_availability'] as $row)
                    @php $member=$row['member']; @endphp
                    <a href="{{ route('dashboard.user.titan-workforce.staff.show',$member->id) }}" class="rounded-xl border p-4 transition hover:-translate-y-0.5 hover:shadow-sm">
                        <div class="flex items-start justify-between gap-3"><div><div class="font-medium">{{ $member->name }}</div><div class="text-xs text-foreground/45">{{ $member->role }}</div></div><div class="text-right"><div class="text-xs font-semibold">{{ $row['workforce_status'] }}</div><div class="mt-1 text-[10px] text-foreground/45">{{ $row['capability_state'] }}</div></div></div>
                        <div class="mt-3 truncate text-[10px] text-foreground/40">{{ implode(' · ', $row['providers']) ?: __('No live capability providers') }}</div>
                    </a>
                @empty<p class="text-sm text-foreground/50">{{ __('No direct reports are currently assigned.') }}</p>@endforelse
            </div>
        </section>
        <section class="rounded-2xl border bg-card p-5">
            <div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Queue pressure') }}</div><h2 class="mt-1 text-lg font-semibold">{{ $q['pressure'] ?? 'NORMAL' }}</h2>
            <div class="mt-4 space-y-3 text-sm">
                @foreach([[__('Queue depth'),$q['queue_depth']??0],[__('Review'),$q['review_count']??0],[__('Blocked'),$q['blocked_count']??0],[__('Escalated'),$q['escalated_count']??0],[__('Overdue'),$q['overdue_count']??0],[__('Capacity'),$q['active_capacity']??0]] as [$label,$value])<div class="flex justify-between border-b pb-2"><span class="text-foreground/50">{{ $label }}</span><strong>{{ $value }}</strong></div>@endforeach
            </div>
        </section>
    </div>

    <section class="rounded-2xl border bg-card p-5">
        <div class="flex flex-wrap items-center justify-between gap-2"><div><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Work awaiting review') }}</div><h2 class="mt-1 text-lg font-semibold">{{ __('Manager actions · Governed action dock') }}</h2></div><span class="text-[11px] text-foreground/40">{{ __('Actions use existing Workforce authorization routes; this page grants no authority.') }}</span></div>
        <div class="mt-4 grid gap-4 xl:grid-cols-2">
            @foreach($center['work_awaiting_review']->take(12) as $task)
                <div class="rounded-xl border p-4">
                    <div class="flex items-start justify-between gap-3"><div><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task->id) }}" class="font-medium hover:underline">{{ $task->title }}</a><div class="mt-1 text-xs text-foreground/45">{{ $task->assignee?->name ?: __('Unassigned') }} · {{ $status($task) }}</div></div><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ __('Review') }}</span></div>
                    <form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.review',$task->id) }}" class="mt-3 flex flex-wrap gap-2">@csrf<input type="hidden" name="manager_id" value="{{ $manager->id }}"><input type="text" name="reason" placeholder="{{ __('Optional reason') }}" class="min-w-[180px] flex-1 rounded-lg border bg-transparent px-3 py-2 text-sm"><button name="decision" value="approve" class="rounded-lg border px-3 py-2 text-xs font-semibold">{{ __('Approve') }}</button><button name="decision" value="revise" class="rounded-lg border px-3 py-2 text-xs font-semibold">{{ __('Request revision') }}</button></form>
                </div>
            @endforeach
        </div>
        <div class="mt-5 grid gap-4 xl:grid-cols-2">
            <div class="rounded-xl border p-4"><div class="font-semibold">{{ __('Delegate approved work') }}</div><div class="mt-3 space-y-2">@forelse($center['action_targets']['delegate']->take(6) as $task)<form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.delegate-action',$task->id) }}" class="flex items-center justify-between gap-3 rounded-lg border p-2">@csrf<input type="hidden" name="manager_id" value="{{ $manager->id }}"><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task->id) }}" class="truncate text-sm hover:underline">{{ $task->title }}</a><button class="rounded-md border px-2.5 py-1.5 text-xs font-semibold">{{ __('Delegate') }}</button></form>@empty<p class="text-sm text-foreground/50">{{ __('No approved tasks are eligible for Action Worker delegation.') }}</p>@endforelse</div></div>
            <div class="rounded-xl border p-4"><div class="font-semibold">{{ __('Reassign managed work') }}</div><div class="mt-3 space-y-2">@forelse($center['action_targets']['reassign']->take(6) as $task)<form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.reassign',$task->id) }}" class="grid gap-2 rounded-lg border p-2 sm:grid-cols-[1fr_1fr_auto]">@csrf<input type="hidden" name="manager_id" value="{{ $manager->id }}"><select name="target_member_id" required class="rounded-md border bg-transparent px-2 py-1.5 text-xs"><option value="">{{ __('Target staff') }}</option>@foreach($center['my_team'] as $candidate)<option value="{{ $candidate->id }}">{{ $candidate->name }}</option>@endforeach</select><input name="reason" required value="Manager workload rebalance" class="rounded-md border bg-transparent px-2 py-1.5 text-xs"><button class="rounded-md border px-2.5 py-1.5 text-xs font-semibold">{{ __('Reassign') }}</button><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task->id) }}" class="truncate text-xs hover:underline sm:col-span-3">{{ $task->title }}</a></form>@empty<p class="text-sm text-foreground/50">{{ __('No managed work is currently reassignable.') }}</p>@endforelse</div></div>
            <div class="rounded-xl border p-4"><div class="font-semibold">{{ __('Decompose manager objective') }}</div>@if(count($center['action_targets']['decompose']) && count($center['decomposition_candidates']))@php $objective=$center['action_targets']['decompose']->first(); $dc=$center['decomposition_candidates']->first(); @endphp<form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.decompose',$objective->id) }}" class="mt-3 grid gap-2">@csrf<input type="hidden" name="manager_id" value="{{ $manager->id }}"><input type="hidden" name="plan[steps][0][id]" value="manager-step-1"><input type="hidden" name="plan[steps][0][role_key]" value="{{ $dc['role_key'] }}"><select name="plan[steps][0][capability]" required class="rounded-md border bg-transparent px-2 py-2 text-xs">@foreach($dc['capabilities'] as $capability)<option value="{{ $capability }}">{{ $capability }}</option>@endforeach</select><input name="plan[steps][0][title]" required value="Delegated specialist work" class="rounded-md border bg-transparent px-2 py-2 text-xs"><button class="rounded-md border px-3 py-2 text-xs font-semibold">{{ __('Decompose') }} · {{ $objective->title }}</button></form>@else<p class="mt-3 text-sm text-foreground/50">{{ __('No manager objective and eligible specialist capability are available for one-step decomposition.') }}</p>@endif</div>
            <div class="rounded-xl border p-4"><div class="font-semibold">{{ __('Resolve Deadlock') }}</div><div class="mt-3 space-y-2">@forelse($center['action_targets']['deadlock']->take(6) as $task)<form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.deadlock',$task->id) }}" class="grid gap-2 rounded-lg border p-2 sm:grid-cols-[1fr_1fr_auto]">@csrf<input type="hidden" name="actor_id" value="{{ $manager->id }}"><select name="resolution" class="rounded-md border bg-transparent px-2 py-1.5 text-xs"><option value="RETRY_WITH_EVIDENCE">{{ __('Retry with evidence') }}</option><option value="RETURN_TO_MAKER">{{ __('Return to maker') }}</option><option value="ESCALATE_TO_PARENT">{{ __('Escalate to parent') }}</option><option value="ESCALATE_TO_TITAN">{{ __('Escalate to Titan') }}</option><option value="HUMAN_DECISION_REQUIRED">{{ __('Human decision required') }}</option></select><input name="reason" value="Manager deadlock resolution" class="rounded-md border bg-transparent px-2 py-1.5 text-xs"><button class="rounded-md border px-2.5 py-1.5 text-xs font-semibold">{{ __('Resolve') }}</button><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task->id) }}" class="truncate text-xs hover:underline sm:col-span-3">{{ $task->title }}</a></form>@empty<p class="text-sm text-foreground/50">{{ __('No deadlock candidates.') }}</p>@endforelse</div></div>
        </div>
    </section>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="rounded-2xl border bg-card p-5"><div class="flex items-center justify-between"><h2 class="text-lg font-semibold">{{ __('Workload imbalance') }}</h2><span class="text-xs text-foreground/45">{{ collect($center['workload_imbalance'])->where('overloaded',true)->count() }} {{ __('overloaded') }}</span></div><div class="mt-4 space-y-2">@forelse($center['workload_imbalance'] as $row)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><a href="{{ route('dashboard.user.titan-workforce.staff.show',$row['member']->id) }}" class="font-medium hover:underline">{{ $row['member']->name }}</a><span class="text-xs {{ $row['overloaded']?'text-red-600':'text-foreground/50' }}">{{ $row['open'] }}/{{ $row['capacity'] }} · {{ round($row['load_ratio']*100) }}%</span></div></div>@empty<p class="text-sm text-foreground/50">{{ __('No workload data.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Staffing recommendations') }}</h2><div class="mt-4 space-y-2">@forelse($center['staffing_recommendations'] as $proposal)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><div><div class="font-medium">{{ $proposal->role_name }}</div><div class="text-xs text-foreground/45">{{ $proposal->reason }} · {{ __('Score') }} {{ $proposal->score }}</div></div><a href="{{ route('dashboard.user.titan-workforce.create',['role'=>$proposal->role_key]) }}" class="text-xs font-semibold hover:underline">{{ __('Review →') }}</a></div></div>@empty<p class="text-sm text-foreground/50">{{ __('No current staffing recommendations for this division.') }}</p>@endforelse</div></section>
    </div>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Handoffs received') }}</h2><div class="mt-4 space-y-2">@forelse($center['handoffs_received']->take(20) as $handoff)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$handoff->task_id) }}" class="font-medium hover:underline">#{{ $handoff->task_id }}</a><span class="text-xs">{{ (string)($handoff->status?->value ?? $handoff->status) }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ $handoff->reason ?: __('No handoff reason') }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No received handoffs.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Handoffs sent') }}</h2><div class="mt-4 space-y-2">@forelse($center['handoffs_sent']->take(20) as $handoff)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$handoff->task_id) }}" class="font-medium hover:underline">#{{ $handoff->task_id }}</a><span class="text-xs">{{ (string)($handoff->status?->value ?? $handoff->status) }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ $handoff->reason ?: __('No handoff reason') }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No sent handoffs.') }}</p>@endforelse</div></section>
    </div>

    <section id="escalations" class="rounded-2xl border bg-card p-5">
        <div class="flex items-center justify-between"><h2 class="text-lg font-semibold">{{ __('Escalations & blocked work') }}</h2><span class="text-xs text-foreground/45">{{ count($center['blocked_work']) }} {{ __('blocked') }}</span></div>
        <div class="mt-4 grid gap-3 xl:grid-cols-2">
            @forelse($center['blocked_work']->take(12) as $task)
                <div class="rounded-xl border border-amber-500/20 p-4"><a href="{{ route('dashboard.user.titan-workforce.tasks.show',$task->id) }}" class="font-medium hover:underline">{{ $task->title }}</a><div class="mt-1 text-xs text-foreground/45">{{ $status($task) }} · {{ $task->assignee?->name ?: __('Unassigned') }}</div>
                    <form method="POST" action="{{ route('dashboard.user.titan-workforce.tasks.escalate',$task->id) }}" class="mt-3 grid gap-2">@csrf<input type="hidden" name="manager_id" value="{{ $manager->id }}"><input type="text" name="reason_code" value="MANAGER_ATTENTION" class="rounded-lg border bg-transparent px-3 py-2 text-xs"><input type="text" name="reason" required placeholder="{{ __('Why escalation is required') }}" class="rounded-lg border bg-transparent px-3 py-2 text-sm"><button class="rounded-lg border px-3 py-2 text-xs font-semibold">{{ __('Escalate') }}</button></form>
                </div>
            @empty<p class="text-sm text-foreground/50">{{ __('No blocked work requires attention.') }}</p>@endforelse
        </div>
        @if(count($center['action_targets']['deadlock']))<div class="mt-4 text-xs text-foreground/50">{{ __('Resolve Deadlock remains available from each task detail page using the governed Resolve Deadlock action.') }}</div>@endif
    </section>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Proactive responsibilities') }}</h2><div class="mt-4 space-y-2">@forelse($center['proactive_responsibilities'] as $schedule)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><div class="font-medium">{{ $schedule->name }}</div><span class="text-xs">{{ $schedule->trigger_type }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ __('Next') }}: {{ $schedule->next_run_at?->toDayDateTimeString() ?: '—' }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No active proactive schedules for this manager or direct reports.') }}</p>@endforelse</div></section>
        <section class="rounded-2xl border bg-card p-5"><h2 class="text-lg font-semibold">{{ __('Team outcomes') }}</h2><div class="mt-4 space-y-2">@forelse($center['team_outcomes']->take(20) as $outcome)<div class="rounded-xl border p-3"><div class="flex justify-between gap-3"><div class="font-medium">{{ $outcome->outcome_type }}</div><span class="text-xs {{ $outcome->success===true?'text-emerald-600':($outcome->success===false?'text-red-600':'text-foreground/45') }}">{{ $outcome->success===true?__('Success'):($outcome->success===false?__('Failed'):__('Verified')) }}</span></div><div class="mt-1 text-xs text-foreground/45">{{ __('Task') }} #{{ $outcome->task_id }} · {{ $outcome->verified_at?->toDayDateTimeString() ?: '—' }}</div></div>@empty<p class="text-sm text-foreground/50">{{ __('No verified team outcomes yet.') }}</p>@endforelse</div></section>
    </div>

    <section class="rounded-2xl border bg-card p-5">
        <div class="flex items-center justify-between"><div><div class="text-xs uppercase tracking-[.16em] text-foreground/40">{{ __('Continuity') }}</div><h2 class="mt-1 text-lg font-semibold">{{ __('Appoint deputy') }}</h2></div></div>
        <form method="POST" action="{{ route('dashboard.user.titan-workforce.staff.deputy',$manager->id) }}" class="mt-4 grid gap-3 md:grid-cols-4">@csrf<select name="deputy_id" required class="rounded-lg border bg-transparent px-3 py-2 text-sm"><option value="">{{ __('Choose manager') }}</option>@foreach($center['deputy_candidates'] as $candidate)<option value="{{ $candidate->id }}">{{ $candidate->name }}</option>@endforeach</select><input type="text" name="scope[]" required value="manager_review" class="rounded-lg border bg-transparent px-3 py-2 text-sm"><input type="datetime-local" name="expires_at" required class="rounded-lg border bg-transparent px-3 py-2 text-sm"><button class="rounded-lg border px-3 py-2 text-sm font-semibold">{{ __('Appoint deputy') }}</button></form>
    </section>

    <p class="text-[11px] text-foreground/40">{{ __('Manager Command Center is a company-scoped operational projection. Queue pressure, availability, delegation, deputy coverage and escalation do not inherit or expand Titan execution authority.') }}</p>
</div>
@endsection
