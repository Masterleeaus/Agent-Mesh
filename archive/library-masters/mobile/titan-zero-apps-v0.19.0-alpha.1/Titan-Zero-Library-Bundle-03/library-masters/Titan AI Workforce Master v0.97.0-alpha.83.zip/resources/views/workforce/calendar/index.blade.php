@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Workforce Schedule'))
@section('titlebar_subtitle', __('Calendar of proactive work, deadlines and scheduled responsibilities.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@push('css')<style>#titan-workforce-calendar .fc-event{cursor:pointer}</style>@endpush
@section('content')<div class="px-5 py-8"><div id="titan-workforce-calendar" class="rounded-xl border bg-card p-5"></div></div>@endsection
@push('script')
<script src="{{ custom_theme_url('/assets/libs/fullcalendar/index.global.min.js') }}"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
 const el=document.getElementById('titan-workforce-calendar'); if(!el||typeof FullCalendar==='undefined') return;
 const cal=new FullCalendar.Calendar(el,{initialView:window.innerWidth<700?'listWeek':'dayGridMonth',height:'auto',events: async (info,ok,fail)=>{try{const q=new URLSearchParams({start_date:info.startStr,end_date:info.endStr}); const r=await fetch(`{{ route('dashboard.user.titan-workforce.api.tasks') }}?${q}`); const d=await r.json(); ok((d.tasks||[]).filter(t=>t.scheduled_at||t.deadline_at).map(t=>({id:t.id,title:(t.assignee?.name?`${t.assignee.name}: `:'')+t.title,start:t.scheduled_at||t.deadline_at,extendedProps:{status:t.status,risk:t.risk_level}})));}catch(e){fail(e);}}}); cal.render();
});
</script>
@endpush
