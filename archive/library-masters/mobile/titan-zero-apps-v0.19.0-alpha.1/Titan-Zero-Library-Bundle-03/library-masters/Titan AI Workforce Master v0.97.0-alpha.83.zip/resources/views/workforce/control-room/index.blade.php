@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Workforce Control Room'))
@section('titlebar_subtitle', __('Live organisational flow, trust, reviews, staffing and outcome traceability.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
    $summary = $controlRoom['summary'];
    $orgHealth = data_get($controlRoom, 'trust_health.organisation', []);
    $performanceRows = collect(data_get($controlRoom, 'performance.members', []));
    $outcomeRows = collect(data_get($controlRoom, 'outcome_refs', []));
@endphp
<div class="px-5 py-8 space-y-8">
    <div class="grid gap-4 md:grid-cols-5">
        @foreach ([
            ['Active staff',$summary['active_staff']],
            ['Divisions',$summary['divisions']],
            ['Approvals',$summary['pending_approvals']],
            ['Handoffs',$summary['open_handoffs']],
            ['Staffing',$summary['staffing_recommendations']],
        ] as [$label,$value])
            <div class="rounded-xl border bg-card p-5 shadow-sm"><div class="text-xs font-medium uppercase text-foreground/50">{{ __($label) }}</div><div class="mt-2 text-3xl font-semibold">{{ $value }}</div></div>
        @endforeach
    </div>

    <div class="grid gap-6 xl:grid-cols-3">
        <section class="rounded-xl border bg-card p-6 xl:col-span-2">
            <div class="flex items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Organisation') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Live chain of command and reporting structure.') }}</p></div><span class="rounded-full bg-foreground/5 px-3 py-1 text-xs">{{ count($controlRoom['organisation_graph']['nodes']) }} {{ __('people') }}</span></div>
            <div class="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                @foreach($controlRoom['organisation_graph']['nodes'] as $node)
                    <div class="rounded-lg border p-3"><div class="flex justify-between gap-2"><div><div class="font-medium">{{ $node['name'] }}</div><div class="text-xs text-foreground/50">{{ $node['role'] }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ $node['status'] }}</span></div><div class="mt-2 text-xs text-foreground/60">{{ $node['division'] }} · {{ $node['maturity'] }} · {{ $node['risk_ceiling'] }}</div><div class="mt-1 text-xs text-foreground/45">{{ __('Reports to') }}: {{ $node['manager'] ?? __('Owner / Titan AI Core') }}</div></div>
                @endforeach
            </div>
        </section>

        <section class="rounded-xl border bg-card p-6">
            <h2 class="m-0 text-xl font-semibold">{{ __('Trust & risk') }}</h2>
            <p class="mt-1 text-sm text-foreground/60">{{ __('Read-only summary from Titan Risk, Assurance and Autonomy evidence already attached to work.') }}</p>
            <div class="mt-5 rounded-lg border p-4"><div class="text-xs uppercase text-foreground/45">{{ __('Organisation state') }}</div><div class="mt-1 text-2xl font-semibold">{{ data_get($orgHealth, 'state', 'HEALTHY') }}</div></div>
            <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('High / Extreme risk') }}</div><div class="mt-1 text-xl font-semibold">{{ data_get($orgHealth, 'risk.HIGH', 0) + data_get($orgHealth, 'risk.EXTREME', 0) }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Red Assurance') }}</div><div class="mt-1 text-xl font-semibold">{{ data_get($orgHealth, 'assurance.RED', 0) }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Autonomy blocked') }}</div><div class="mt-1 text-xl font-semibold">{{ data_get($orgHealth, 'autonomy.blocked', 0) }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Recovery') }}</div><div class="mt-1 text-xl font-semibold">{{ data_get($orgHealth, 'recovery', 0) }}</div></div>
            </div>
        </section>
    </div>

    <section class="rounded-xl border bg-card p-6">
        <div><h2 class="m-0 text-xl font-semibold">{{ __('Manager queues') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Queue pressure, capacity and stalled work by operational manager.') }}</p></div>
        <div class="mt-5 overflow-x-auto"><table class="w-full text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-3">{{ __('Manager') }}</th><th class="p-3">{{ __('Division') }}</th><th class="p-3">{{ __('Pressure') }}</th><th class="p-3">{{ __('Open') }}</th><th class="p-3">{{ __('Capacity') }}</th><th class="p-3">{{ __('Overdue') }}</th><th class="p-3">{{ __('Blocked') }}</th><th class="p-3">{{ __('Starved') }}</th></tr></thead><tbody>
        @forelse($controlRoom['queues'] as $queue)<tr class="border-t"><td class="p-3 font-medium">{{ $queue['manager'] }}</td><td class="p-3">{{ $queue['division'] }}</td><td class="p-3"><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold">{{ data_get($queue,'health.pressure') }}</span></td><td class="p-3">{{ data_get($queue,'health.queue_depth',0) }}</td><td class="p-3">{{ data_get($queue,'health.active_capacity',0) }}</td><td class="p-3">{{ data_get($queue,'health.overdue_count',0) }}</td><td class="p-3">{{ data_get($queue,'health.blocked_count',0) }}</td><td class="p-3">{{ data_get($queue,'health.starved_count',0) }}</td></tr>@empty<tr><td colspan="8" class="p-6 text-center text-foreground/55">{{ __('No active Manager queues yet.') }}</td></tr>@endforelse
        </tbody></table></div>
    </section>

    <div class="grid gap-6 xl:grid-cols-2">
        <section class="rounded-xl border bg-card p-6">
            <h2 class="m-0 text-xl font-semibold">{{ __('Approvals') }}</h2>
            <p class="mt-1 text-sm text-foreground/60">{{ __('Manager, receiving-manager and escalated work waiting for a decision.') }}</p>
            <div class="mt-4 space-y-3">@forelse($controlRoom['approvals']->take(12) as $task)<div class="rounded-lg border p-3"><div class="flex justify-between gap-3"><div><div class="font-medium">{{ $task->title }}</div><div class="text-xs text-foreground/50">{{ $task->assignee?->name ?? __('Unassigned') }} → {{ $task->manager?->name ?? __('Manager pending') }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ $task->status?->value }}</span></div><div class="mt-2 text-xs text-foreground/50">{{ $task->risk_level }} · {{ $task->division?->name }} · {{ $task->task_uuid }}</div></div>@empty<div class="rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No reviews waiting.') }}</div>@endforelse</div>
        </section>

        <section class="rounded-xl border bg-card p-6">
            <h2 class="m-0 text-xl font-semibold">{{ __('Handoffs') }}</h2>
            <p class="mt-1 text-sm text-foreground/60">{{ __('Cross-division transfers retain their own chain-of-custody.') }}</p>
            <div class="mt-4 space-y-3">@forelse($controlRoom['handoffs']->take(12) as $handoff)<div class="rounded-lg border p-3"><div class="flex justify-between gap-3"><div class="font-medium">{{ $handoff->handoff_uuid }}</div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ $handoff->status?->value }}</span></div><div class="mt-2 text-xs text-foreground/50">{{ __('Task') }} #{{ $handoff->task_id }} · {{ __('Origin manager') }} #{{ $handoff->origin_manager_id }} → {{ __('Receiving manager') }} #{{ $handoff->receiving_manager_id }}</div></div>@empty<div class="rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No active handoffs.') }}</div>@endforelse</div>
        </section>
    </div>

    <section class="rounded-xl border bg-card p-6">
        <div class="flex flex-wrap items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Staffing') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Workforce Planning may recommend a role. Approval never auto-activates staff or grants authority.') }}</p></div>
            <form method="POST" action="{{ route('dashboard.user.titan-workforce.staffing.refresh') }}" class="flex items-center gap-2">@csrf<select name="business_tier" class="form-select"><option>SOLO</option><option selected>SMALL</option><option>GROWING</option><option>ENTERPRISE</option></select><x-button type="submit" variant="outline">{{ __('Refresh recommendations') }}</x-button></form>
        </div>
        <div class="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            @forelse($controlRoom['staffing'] as $proposal)
                <div class="rounded-lg border p-4"><div class="flex justify-between gap-3"><div><div class="font-medium">{{ $proposal->role_name }}</div><div class="text-xs text-foreground/50">{{ $proposal->division_key }} · {{ $proposal->reason }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ $proposal->status }}</span></div><div class="mt-2 text-xs text-foreground/60">{{ __('Score') }} {{ $proposal->score }} · {{ __('Risk ceiling') }} {{ $proposal->risk_ceiling }}</div>
                    @if($proposal->status === 'RECOMMENDED')<div class="mt-3 flex gap-2"><form method="POST" action="{{ route('dashboard.user.titan-workforce.staffing.approve', $proposal) }}">@csrf<x-button type="submit" size="sm">{{ __('Approve') }}</x-button></form><form method="POST" action="{{ route('dashboard.user.titan-workforce.staffing.reject', $proposal) }}">@csrf<x-button type="submit" size="sm" variant="outline">{{ __('Reject') }}</x-button></form></div>@endif
                    @if($proposal->status === 'APPROVED')<div class="mt-3"><x-button size="sm" href="{{ route('dashboard.user.titan-workforce.create', ['role'=>$proposal->role_key]) }}">{{ __('Open Employee Builder') }}</x-button></div>@endif
                </div>
            @empty<div class="col-span-full rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No staffing recommendations waiting.') }}</div>@endforelse
        </div>
    </section>

    <div class="grid gap-6 xl:grid-cols-2">
        <section class="rounded-xl border bg-card p-6"><h2 class="m-0 text-xl font-semibold">{{ __('Performance') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Maturity evidence is organisational only; it never changes Titan Autonomy.') }}</p><div class="mt-4 space-y-3">@foreach($performanceRows->take(12) as $row)<div class="rounded-lg border p-3"><div class="flex justify-between gap-3"><div><div class="font-medium">{{ $row['name'] }}</div><div class="text-xs text-foreground/50">{{ $row['role'] }}</div></div><span class="h-fit rounded-full bg-foreground/5 px-2 py-1 text-[10px]">{{ data_get($row, 'maturity.current') }}</span></div><div class="mt-2 text-xs text-foreground/60">{{ __('Manager acceptance') }} {{ number_format($row['manager_acceptance_rate'] * 100, 1) }}% · {{ __('Completed') }} {{ $row['completed_tasks'] }} · {{ __('Revisions') }} {{ $row['revisions'] }}</div></div>@endforeach</div></section>

        <section class="rounded-xl border bg-card p-6"><h2 class="m-0 text-xl font-semibold">{{ __('Rewind & outcomes') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Execution receipts and Titan Rewind/Wisdom references for reconstructing consequential work.') }}</p><div class="mt-4 space-y-3">@forelse($outcomeRows->take(12) as $row)<div class="rounded-lg border p-3"><div class="font-medium">{{ $row['title'] }}</div><div class="mt-1 text-xs text-foreground/50">{{ $row['status'] }} · {{ $row['task_id'] }}</div><div class="mt-2 break-all text-xs text-foreground/60">{{ __('Receipt') }}: {{ $row['receipt_ref'] ?? '—' }}<br>{{ __('Rewind') }}: {{ $row['rewind_ref'] ?? '—' }}<br>{{ __('Wisdom') }}: {{ $row['outcome_ref'] ?? '—' }}</div></div>@empty<div class="rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No execution outcome references yet.') }}</div>@endforelse</div></section>
    </div>
</div>
@endsection
