@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Governance Pipeline'))
@section('titlebar_subtitle', __('Explainable Titan control-plane lifecycle'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
  $selected = $pipeline['task'];
  $stateClasses = [
    'completed'=>'bg-emerald-500/10 text-emerald-700 border-emerald-500/25',
    'active'=>'bg-blue-500/10 text-blue-700 border-blue-500/25',
    'degraded'=>'bg-amber-500/10 text-amber-700 border-amber-500/25',
    'failed'=>'bg-red-500/10 text-red-700 border-red-500/25',
    'not_required'=>'bg-slate-500/10 text-slate-600 border-slate-500/20',
    'pending'=>'bg-foreground/[.04] text-foreground/55 border-foreground/10',
  ];
@endphp
<div class="px-5 py-8 space-y-5">
  <div class="rounded-xl border bg-card p-5">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div>
        <div class="text-xs uppercase tracking-wide text-foreground/45">{{ __('Control-plane explainability') }}</div>
        <h1 class="mt-1 text-2xl font-semibold">{{ __('Governance Pipeline Visualizer') }}</h1>
        <p class="mt-2 max-w-4xl text-sm text-foreground/60">{{ __('Signal → Prime → AI Core → Agent Runtime → Model Council → Risk → Assurance → Governance → Autonomy → Command Bus → Rewind → Wisdom. Every card is a read-only projection of authoritative Workforce evidence.') }}</p>
      </div>
      <form method="get" class="flex min-w-[300px] items-center gap-2">
        <select name="task" class="form-select min-w-[260px] rounded-lg border bg-background px-3 py-2 text-sm" onchange="this.form.submit()">
          <option value="">{{ __('Latest Work Item') }}</option>
          @foreach($pipeline['tasks'] as $row)
            <option value="{{ $row->id }}" @selected($selected && (int)$selected->id === (int)$row->id)>{{ $row->title }} · {{ $row->status?->value ?? $row->status }}</option>
          @endforeach
        </select>
      </form>
    </div>
    @if($selected)
      <div class="mt-4 flex flex-wrap items-center gap-2 text-sm">
        <span class="rounded-full bg-foreground/5 px-3 py-1 font-medium">{{ $selected->task_uuid }}</span>
        <a class="font-semibold hover:underline" href="{{ route('dashboard.user.titan-workforce.tasks.show',$selected) }}">{{ $selected->title }}</a>
        <span class="text-foreground/45">{{ $selected->status?->value ?? $selected->status }}</span>
      </div>
    @endif
  </div>

  <div class="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
    @foreach(['completed'=>'Completed','active'=>'Active','degraded'=>'Degraded','failed'=>'Failed','pending'=>'Pending','not_required'=>'Not required'] as $key=>$label)
      <div class="rounded-xl border bg-card p-4"><div class="text-xs uppercase text-foreground/45">{{ __($label) }}</div><div class="mt-1 text-2xl font-semibold">{{ $pipeline['counts'][$key] ?? 0 }}</div></div>
    @endforeach
  </div>

  <section class="rounded-xl border bg-card p-5 overflow-hidden">
    <div class="flex items-center justify-between gap-4"><div><h2 class="font-semibold">{{ __('Lifecycle') }}</h2><p class="text-xs text-foreground/45">{{ __('Stages are ordered by the canonical Workforce control-plane registry.') }}</p></div><span class="text-xs text-foreground/45">{{ $pipeline['generated_at'] }}</span></div>
    <div class="mt-5 overflow-x-auto pb-3">
      <div class="flex min-w-max items-stretch gap-2">
        @foreach($pipeline['stages'] as $index=>$stage)
          <a href="#stage-{{ $stage['key'] }}" class="group flex items-center gap-2">
            <div class="w-44 rounded-xl border p-4 {{ $stateClasses[$stage['state']] ?? $stateClasses['pending'] }}">
              <div class="flex items-start justify-between gap-2"><span class="text-[11px] font-semibold uppercase tracking-wide">{{ str_pad((string)($index+1),2,'0',STR_PAD_LEFT) }}</span><span class="text-[10px] uppercase">{{ str_replace('_',' ',$stage['state']) }}</span></div>
              <div class="mt-2 font-semibold">{{ $stage['label'] }}</div>
              <div class="mt-1 truncate text-[11px] opacity-75">{{ $stage['provider'] }}</div>
              @if(!$stage['provider_available'])<div class="mt-2 text-[10px] font-semibold">{{ __('Provider unavailable') }}</div>@endif
            </div>
            @if(!$loop->last)<div class="text-xl text-foreground/25 group-hover:text-foreground/45">→</div>@endif
          </a>
        @endforeach
      </div>
    </div>
  </section>

  <div class="space-y-4">
    @foreach($pipeline['stages'] as $stage)
      <section id="stage-{{ $stage['key'] }}" class="scroll-mt-24 rounded-xl border bg-card p-5">
        <div class="flex flex-wrap items-start justify-between gap-3">
          <div><div class="text-xs uppercase text-foreground/45">{{ $stage['stage'] }}</div><h2 class="text-lg font-semibold">{{ $stage['label'] }}</h2><div class="mt-1 text-xs text-foreground/50">{{ $stage['provider'] }} · {{ $stage['required'] }}</div></div>
          <span class="rounded-full border px-3 py-1 text-xs font-semibold {{ $stateClasses[$stage['state']] ?? $stateClasses['pending'] }}">{{ strtoupper(str_replace('_',' ',$stage['state'])) }}</span>
        </div>
        <div class="mt-5 grid gap-3 md:grid-cols-4">
          <div class="rounded-lg bg-foreground/[.03] p-3"><div class="text-[11px] uppercase text-foreground/45">{{ __('State') }}</div><div class="mt-1 text-sm font-semibold">{{ $stage['state'] }}</div></div>
          <div class="rounded-lg bg-foreground/[.03] p-3"><div class="text-[11px] uppercase text-foreground/45">{{ __('Timestamp') }}</div><div class="mt-1 text-sm font-medium">{{ $stage['timestamp'] ?: '—' }}</div></div>
          <div class="rounded-lg bg-foreground/[.03] p-3"><div class="text-[11px] uppercase text-foreground/45">{{ __('Duration') }}</div><div class="mt-1 text-sm font-medium">{{ $stage['duration_ms'] === null ? '—' : number_format($stage['duration_ms']).' ms' }}</div></div>
          <div class="rounded-lg bg-foreground/[.03] p-3"><div class="text-[11px] uppercase text-foreground/45">{{ __('Provider') }}</div><div class="mt-1 text-sm font-medium">{{ $stage['provider'] }}</div><div class="text-[11px] {{ $stage['provider_available'] ? 'text-emerald-600' : 'text-red-600' }}">{{ $stage['provider_available'] ? __('Available') : __('Unavailable') }}</div></div>
        </div>
        <div class="mt-4 grid gap-4 lg:grid-cols-2">
          <div class="rounded-lg border p-4"><div class="text-xs font-semibold uppercase text-foreground/45">{{ __('Decision') }}</div><pre class="mt-2 max-h-64 overflow-auto whitespace-pre-wrap break-words text-xs">{{ $stage['decision'] === null ? '—' : json_encode($stage['decision'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES) }}</pre></div>
          <div class="rounded-lg border p-4"><div class="text-xs font-semibold uppercase text-foreground/45">{{ __('Evidence') }}</div>@forelse($stage['evidence'] as $ref)<div class="mt-2 break-all rounded bg-foreground/[.03] px-2 py-1 text-xs">{{ $ref }}</div>@empty<div class="mt-2 text-sm text-foreground/45">—</div>@endforelse</div>
          <div class="rounded-lg border p-4"><div class="text-xs font-semibold uppercase text-foreground/45">{{ __('Reason') }}</div><div class="mt-2 text-sm">{{ $stage['reason'] }}</div></div>
          <div class="rounded-lg border p-4"><div class="grid gap-3 sm:grid-cols-2"><div><div class="text-xs font-semibold uppercase text-foreground/45">{{ __('Failure') }}</div><div class="mt-2 text-sm {{ $stage['failure'] ? 'text-red-600' : 'text-foreground/45' }}">{{ $stage['failure'] ?: '—' }}</div></div><div><div class="text-xs font-semibold uppercase text-foreground/45">{{ __('Degradation') }}</div><div class="mt-2 text-sm {{ $stage['degradation'] ? 'text-amber-600' : 'text-foreground/45' }}">{{ $stage['degradation'] ?: '—' }}</div></div></div></div>
        </div>
      </section>
    @endforeach
  </div>

  <div class="rounded-xl border border-amber-500/25 bg-amber-500/5 p-4 text-sm"><strong>{{ __('Authority boundary:') }}</strong> {{ __('This visualizer explains recorded decisions and provider state. It does not grant execution authority, infer approval, bypass a failed gate, or turn a missing decision into permission.') }}</div>
</div>
@endsection
