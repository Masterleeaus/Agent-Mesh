<div class="flex flex-wrap items-center gap-2">
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.index') }}">{{ __('Overview') }}</x-button>
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.team') }}">{{ __('Team') }}</x-button>
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.tasks') }}">{{ __('Work') }}</x-button>
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.calendar') }}">{{ __('Schedule') }}</x-button>
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.control-room') }}">{{ __('Control Room') }}</x-button>
    <x-button variant="ghost" href="{{ route('dashboard.user.titan-workforce.analytics') }}">{{ __('Performance') }}</x-button>
    <x-button href="{{ route('dashboard.user.titan-workforce.create') }}"><x-tabler-user-plus class="size-4" /> {{ __('Add Staff Member') }}</x-button>
</div>
