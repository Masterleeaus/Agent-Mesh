@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Journey Timeline 2.0'))
@section('titlebar_subtitle', __('A business-readable story of autonomous work, with technical detail available on demand.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
<div class="px-5 py-8 space-y-5">
  <section class="rounded-xl border bg-card p-5">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div><div class="text-xs uppercase text-foreground/45">{{ __('Business timeline') }}</div><h1 class="mt-1 text-2xl font-semibold">{{ __('Journey Timeline 2.0') }}</h1><p class="mt-2 max-w-3xl text-sm text-foreground/60">{{ __('Read the business story first. Expand any event only when you need IDs, evidence references, execution references, hashes or control-plane detail.') }}</p></div>
      @if($timeline['task'])<a class="rounded-lg border px-3 py-2 text-sm font-semibold hover:bg-foreground/[.03]" href="{{ route('dashboard.user.titan-workforce.tasks.show', $timeline['task']) }}">{{ __('Open Work Item') }} →</a>@endif
    </div>
    <form method="get" class="mt-5 flex flex-wrap items-end gap-3">
      <label class="min-w-[280px] flex-1"><span class="mb-1 block text-xs font-medium text-foreground/50">{{ __('Work Item') }}</span><select name="task" class="w-full rounded-lg border bg-transparent px-3 py-2" onchange="this.form.submit()"><option value="">{{ __('Select recent work') }}</option>@foreach($timeline['tasks'] as $task)<option value="{{ $task->id }}" @selected(($timeline['task']?->id ?? null)===$task->id)>{{ $task->title }} · {{ $task->status?->value }}</option>@endforeach</select></label>
    </form>
  </section>

  @if($timeline['task'])
  <section class="rounded-xl border bg-card p-5">
    <div class="flex flex-wrap justify-between gap-4"><div><div class="text-xs uppercase text-foreground/45">{{ $timeline['task']->task_uuid }}</div><h2 class="text-xl font-semibold">{{ $timeline['task']->title }}</h2></div><div class="text-sm text-foreground/50">{{ trans_choice(':count event|:count events', $timeline['event_count'], ['count'=>$timeline['event_count']]) }}</div></div>
    <div class="mt-6">
      @forelse($timeline['events'] as $event)
        <article class="relative border-l border-foreground/15 pb-7 pl-7 last:pb-0">
          <span class="absolute -left-2 top-1 flex h-4 w-4 items-center justify-center rounded-full border bg-card"><span class="h-2 w-2 rounded-full bg-foreground"></span></span>
          <div class="flex flex-wrap items-start justify-between gap-3"><div><div class="text-xs text-foreground/45">{{ optional($event['occurred_at'])->format('d M Y · H:i:s') }} · {{ Str::headline(strtolower($event['category'])) }}</div><h3 class="mt-1 font-semibold">{{ $event['business_title'] }}</h3><p class="mt-1 max-w-4xl text-sm text-foreground/60">{{ $event['business_summary'] }}</p>@if($event['actor_name'])<div class="mt-1 text-xs text-foreground/45">{{ __('By :name', ['name'=>$event['actor_name']]) }}</div>@endif</div><span class="rounded-full bg-foreground/5 px-2 py-1 text-xs">#{{ $event['sequence'] }}</span></div>
          <details class="mt-3 rounded-lg border bg-foreground/[.015] p-3">
            <summary class="cursor-pointer text-xs font-semibold">{{ __('Technical detail') }}</summary>
            <div class="mt-3 grid gap-3 lg:grid-cols-2"><div><div class="text-xs uppercase text-foreground/45">{{ __('Recorded event') }}</div><div class="mt-1 text-sm font-medium">{{ $event['event_type'] }}</div><div class="mt-1 text-xs text-foreground/50">{{ $event['phase'] }} / {{ $event['category'] }}</div></div><div><div class="text-xs uppercase text-foreground/45">{{ __('Structured evidence') }}</div><pre class="mt-1 max-h-80 overflow-auto whitespace-pre-wrap break-words text-xs">{{ json_encode($event['technical_details'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) }}</pre></div></div>
          </details>
        </article>
      @empty
        <div class="rounded-lg bg-foreground/[.03] p-5 text-sm text-foreground/55">{{ __('No journey events have been recorded for this Work Item yet.') }}</div>
      @endforelse
    </div>
  </section>
  @else
    <section class="rounded-xl border bg-card p-8 text-center text-sm text-foreground/55">{{ __('Select a recent Work Item to read its business journey.') }}</section>
  @endif

  <p class="text-xs text-foreground/45">{{ __('Journey Timeline 2.0 is a read-only projection of append-only Workforce evidence. It does not grant execution authority, infer approval, expose private reasoning, or change the underlying Work Item.') }}</p>
</div>
@endsection
