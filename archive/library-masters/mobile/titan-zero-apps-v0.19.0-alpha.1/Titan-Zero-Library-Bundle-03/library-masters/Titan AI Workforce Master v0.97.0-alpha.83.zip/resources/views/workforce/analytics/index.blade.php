@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Workforce Performance & Coaching'))
@section('titlebar_subtitle', __('Verified outcomes, work quality and advisory coaching signals. Activity is context, not success.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
    $performanceRows = collect(data_get($performance, 'members', []));
    $coachingRows = collect(data_get($coaching, 'employees', []));
    $recommendations = collect(data_get($coaching, 'recommendations', []));
    $strengths = collect(data_get($coaching, 'strengths', []));
    $weakResponsibilities = collect(data_get($coaching, 'weak_responsibilities', []));
@endphp
<div class="px-5 py-8 space-y-8">
    <section class="rounded-xl border bg-card p-6">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <h2 class="m-0 text-xl font-semibold">{{ __('Workforce Performance & Coaching') }}</h2>
                <p class="mt-1 text-sm text-foreground/60">{{ __('Verified outcomes drive coaching. Tasks, reviews and executions provide context but never count as business success by themselves.') }}</p>
            </div>
            <div class="rounded-lg border px-4 py-3 text-sm">
                <div class="font-semibold">{{ __('Performance never increases authority or autonomy') }}</div>
                <div class="mt-1 text-xs text-foreground/55">{{ __('Recommendations are advisory only. They cannot grant capability, raise a risk ceiling, reconfigure staff automatically or bypass Titan governance.') }}</div>
            </div>
        </div>
    </section>

    <div class="grid gap-4 md:grid-cols-4">
        @foreach([['Completed',$stats['completed']],['Open',$stats['open']],['Under review',$stats['review']],['Exceptions',$stats['exceptions']]] as [$label,$value])
            <div class="rounded-xl border bg-card p-5"><div class="text-xs uppercase text-foreground/45">{{ __($label) }}</div><div class="mt-2 text-3xl font-semibold">{{ $value }}</div></div>
        @endforeach
    </div>

    <div class="grid gap-6 xl:grid-cols-3">
        <section class="rounded-xl border bg-card p-6">
            <h3 class="m-0 text-base font-semibold">{{ __('Strengths') }}</h3>
            <div class="mt-4 space-y-3">
                @forelse($strengths as $row)
                    <div class="rounded-lg border p-3"><div class="font-medium">{{ $row['title'] }}</div><div class="text-xs text-foreground/50">{{ $row['employee'] }}</div><div class="mt-1 text-sm text-foreground/65">{{ $row['reason'] }}</div></div>
                @empty <p class="text-sm text-foreground/50">{{ __('More verified work evidence is needed before strengths are asserted.') }}</p> @endforelse
            </div>
        </section>
        <section class="rounded-xl border bg-card p-6">
            <h3 class="m-0 text-base font-semibold">{{ __('Weak responsibilities') }}</h3>
            <div class="mt-4 space-y-3">
                @forelse($weakResponsibilities as $row)
                    <div class="rounded-lg border p-3"><div class="font-medium">{{ $row['name'] }}</div><div class="mt-1 text-xs text-foreground/55">{{ __('Tasks') }} {{ $row['tasks'] }} · {{ __('Revisions') }} {{ $row['revisions'] }} · {{ __('Verified outcomes') }} {{ $row['verified'] }}</div></div>
                @empty <p class="text-sm text-foreground/50">{{ __('No responsibility has enough adverse evidence to be classified as weak.') }}</p> @endforelse
            </div>
        </section>
        <section class="rounded-xl border bg-card p-6">
            <h3 class="m-0 text-base font-semibold">{{ __('Coaching & reconfiguration recommendations') }}</h3>
            <div class="mt-4 space-y-3">
                @forelse($recommendations as $row)
                    <div class="rounded-lg border p-3"><div class="flex items-center justify-between gap-3"><div class="font-medium">{{ $row['title'] }}</div><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] uppercase">{{ $row['type'] }}</span></div><div class="text-xs text-foreground/50">{{ $row['employee'] }} · {{ $row['trigger'] }}</div><div class="mt-1 text-sm text-foreground/65">{{ $row['recommended_action'] }}</div><div class="mt-2 text-[11px] font-medium text-foreground/50">{{ __('Advisory only — no automatic reconfiguration or authority change.') }}</div></div>
                @empty <p class="text-sm text-foreground/50">{{ __('No coaching intervention is currently supported by enough evidence.') }}</p> @endforelse
            </div>
        </section>
    </div>

    <section class="rounded-xl border bg-card p-6">
        <div><h2 class="m-0 text-xl font-semibold">{{ __('Performance signals by employee') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Highlights revision pressure, failed handoffs, recurring escalations, slow execution and poor verified-outcome conversion.') }}</p></div>
        <div class="mt-5 overflow-x-auto"><table class="w-full text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-3">{{ __('Employee') }}</th><th class="p-3">{{ __('Revision pressure') }}</th><th class="p-3">{{ __('Failed handoffs') }}</th><th class="p-3">{{ __('Escalations') }}</th><th class="p-3">{{ __('Execution') }}</th><th class="p-3">{{ __('Verified outcome conversion') }}</th></tr></thead><tbody>
        @forelse($coachingRows as $row)
            <tr class="border-t"><td class="p-3"><div class="font-medium">{{ data_get($row,'employee.name') }}</div><div class="text-xs text-foreground/45">{{ data_get($row,'employee.role') }} · {{ $row['division'] ?? '—' }}</div></td><td class="p-3">@if($row['high_revision_rate'])<span class="font-semibold">{{ __('High') }}</span>@else{{ __('Normal') }}@endif<div class="text-xs text-foreground/45">{{ data_get($row,'activity.revisions',0) }} {{ __('revisions') }}</div></td><td class="p-3">{{ $row['failed_handoffs'] }}</td><td class="p-3">@if($row['recurring_escalations'])<span class="font-semibold">{{ __('Recurring') }}</span>@else{{ data_get($row,'activity.escalations',0) }}@endif</td><td class="p-3">@if($row['slow_execution'])<span class="font-semibold">{{ __('Slow') }}</span>@else{{ __('Normal / insufficient sample') }}@endif<div class="text-xs text-foreground/45">{{ data_get($row,'execution.average_seconds',0) }}s {{ __('average') }}</div></td><td class="p-3">{{ number_format((float)data_get($row,'verified_outcomes.conversion_rate',0)*100,1) }}%<div class="text-xs text-foreground/45">{{ data_get($row,'verified_outcomes.successful',0) }}/{{ data_get($row,'verified_outcomes.count',0) }} {{ __('successful verified outcomes') }}</div></td></tr>
        @empty<tr><td colspan="6" class="p-8 text-center text-foreground/55">{{ __('No active staff performance records yet.') }}</td></tr>@endforelse
        </tbody></table></div>
    </section>

    <section class="rounded-xl border bg-card p-6">
        <div class="flex items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Maturity evidence') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Maturity is evidence-based organisational experience only. It never grants or raises Titan Autonomy.') }}</p></div><x-button variant="outline" href="{{ route('dashboard.user.titan-workforce.outcome-intelligence') }}">{{ __('Open Outcome Intelligence') }}</x-button></div>
        <div class="mt-5 overflow-x-auto"><table class="w-full text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-3">{{ __('Staff') }}</th><th class="p-3">{{ __('Maturity') }}</th><th class="p-3">{{ __('Completed') }}</th><th class="p-3">{{ __('Manager acceptance') }}</th><th class="p-3">{{ __('Downstream acceptance') }}</th><th class="p-3">{{ __('Assurance calibration') }}</th><th class="p-3">{{ __('Revisions') }}</th></tr></thead><tbody>
        @forelse($performanceRows as $row)<tr class="border-t"><td class="p-3"><div class="font-medium">{{ $row['name'] }}</div><div class="text-xs text-foreground/45">{{ $row['role'] }} · {{ $row['division'] }}</div></td><td class="p-3"><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold">{{ data_get($row,'maturity.current') }}</span>@if(data_get($row,'maturity.eligible'))<div class="mt-1 text-xs text-foreground/50">{{ __('Eligible for') }} {{ data_get($row,'maturity.recommended') }}</div>@endif</td><td class="p-3">{{ $row['completed_tasks'] }}</td><td class="p-3">{{ number_format($row['manager_acceptance_rate']*100,1) }}%</td><td class="p-3">@if(($row['downstream_sample_size'] ?? 0)>0){{ number_format($row['downstream_acceptance_rate']*100,1) }}%@else<span class="text-foreground/40">—</span>@endif</td><td class="p-3">@if($row['assurance_calibration']>0){{ number_format($row['assurance_calibration']*100,1) }}%@else<span class="text-foreground/40">{{ __('Awaiting calibrated evidence') }}</span>@endif</td><td class="p-3">{{ $row['revisions'] }}</td></tr>
        @empty<tr><td colspan="7" class="p-8 text-center text-foreground/55">{{ __('No active staff performance records yet.') }}</td></tr>@endforelse
        </tbody></table></div>
    </section>
</div>
@endsection
