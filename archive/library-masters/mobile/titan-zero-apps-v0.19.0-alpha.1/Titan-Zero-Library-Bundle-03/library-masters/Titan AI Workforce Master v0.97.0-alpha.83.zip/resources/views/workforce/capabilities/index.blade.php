@extends('panel.layout.app')
@section('title', __('Capability Health'))
@section('content')
<div class="container-fluid py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="mb-1">{{ __('Capability Health & Provider Inspector') }}</h1><p class="text-muted mb-0">{{ __('Live provider presence, role composition, employee degradation and execution-surface provenance. Availability is never authority.') }}</p></div>
    <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan-workforce.team') }}">{{ __('Organisation Map') }}</a>
  </div>
  @php($s=$inspector['summary'])
  <div class="row g-3 mb-4">
    @foreach(['providers'=>'Providers','active_providers'=>'Active','degraded_providers'=>'Degraded','missing_providers'=>'Missing','quarantined_providers'=>'Quarantined','employees'=>'Employees','degraded_employees'=>'Affected staff'] as $key=>$label)
      <div class="col-6 col-md-3 col-xl"><div class="card h-100"><div class="card-body"><div class="small text-muted">{{ __($label) }}</div><div class="fs-2 fw-bold">{{ $s[$key] }}</div></div></div></div>
    @endforeach
  </div>
  @php($tabs=['providers'=>'Providers','roles'=>'Roles','employees'=>'Employees','capabilities'=>'Capabilities','tools'=>'Tools','commands'=>'Commands','signals'=>'Signals','data_sources'=>'Data sources','workflows'=>'Workflows'])
  <div class="card mb-4"><div class="card-body py-2"><div class="nav nav-pills flex-wrap gap-2">
    @foreach($tabs as $key=>$label)<a class="nav-link {{ $activeView===$key ? 'active' : '' }}" href="{{ route('dashboard.user.titan-workforce.capability-health',['view'=>$key]) }}">{{ __($label) }}</a>@endforeach
  </div></div></div>

  @if($activeView==='providers')
  <div class="card"><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Provider</th><th>Health</th><th>Version</th><th>Roles depending</th><th>Employees affected</th><th>Capabilities provided</th><th>Surfaces</th></tr></thead><tbody>
    @foreach($inspector['providers'] as $p)<tr>
      <td><strong>{{ $p['name'] }}</strong><div class="small text-muted">{{ $p['key'] }}</div></td>
      <td><span class="badge {{ $p['active']?'bg-success':($p['degraded']?'bg-warning':($p['quarantined']?'bg-danger':'bg-secondary')) }}">{{ $p['status'] }}</span><div class="small mt-1">installed {{ $p['installed']?'✓':'—' }} · active {{ $p['active']?'✓':'—' }} · degraded {{ $p['degraded']?'✓':'—' }} · missing {{ $p['missing']?'✓':'—' }} · quarantined {{ $p['quarantined']?'✓':'—' }}</div></td>
      <td>{{ $p['version'] ?: '—' }}</td>
      <td><strong>{{ $p['role_count'] }}</strong>@foreach(array_slice($p['roles'],0,4) as $r)<div class="small">{{ $r['name'] }}</div>@endforeach</td>
      <td><strong>{{ $p['employee_count'] }}</strong>@foreach(array_slice($p['employees_affected'],0,4) as $e)<div class="small"><a href="{{ route('dashboard.user.titan-workforce.staff.show',$e['id']) }}">{{ $e['name'] }}</a> · {{ $e['state'] }}</div>@endforeach</td>
      <td>{{ $p['capability_count'] }}</td>
      <td>@foreach($p['surface_counts'] as $type=>$count)<span class="badge bg-secondary-lt me-1 mb-1">{{ str_replace('_',' ',$type) }} {{ $count }}</span>@endforeach</td>
    </tr>@endforeach
  </tbody></table></div></div>
  @elseif($activeView==='roles')
  <div class="card"><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Role</th><th>Division / team</th><th>Live state</th><th>Expected providers</th><th>Available now</th><th>Employees</th></tr></thead><tbody>
  @foreach($inspector['roles'] as $r)<tr><td><strong>{{ $r['role_name'] }}</strong><div class="small text-muted">{{ $r['role_definition_id'] }}</div></td><td>{{ $r['division'] }} / {{ $r['team'] }}</td><td><span class="badge {{ $r['state']==='available'?'bg-success':'bg-warning' }}">{{ $r['state'] }}</span></td><td>{{ implode(', ',$r['expected_providers']) ?: '—' }}</td><td>{{ implode(', ',$r['available_providers']) ?: '—' }}</td><td>{{ $r['employee_count'] }}</td></tr>@endforeach
  </tbody></table></div></div>
  @elseif($activeView==='employees')
  <div class="card"><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>Employee</th><th>Health</th><th>Expected providers</th><th>Currently available</th><th>Degraded capabilities</th><th>Policy-disabled</th><th>Fallback eligibility</th></tr></thead><tbody>
  @foreach($inspector['employees'] as $e)<tr><td><a href="{{ route('dashboard.user.titan-workforce.staff.show',$e['id']) }}"><strong>{{ $e['name'] }}</strong></a><div class="small text-muted">{{ $e['role_name'] }}</div></td><td>@include('titan-ai-workforce::components.capability-health-badge',['state'=>$e['state'],'memberId'=>$e['id']])</td><td>{{ implode(', ',$e['expected_providers']) ?: '—' }}</td><td>{{ implode(', ',$e['available_providers']) ?: '—' }}</td><td>@forelse(array_slice($e['degraded_capabilities'],0,8) as $c)<div class="small">{{ $c['id'] }} <span class="text-muted">({{ $c['provider'] }}: {{ $c['state'] }})</span></div>@empty—@endforelse</td><td>@forelse(array_slice($e['policy_disabled_capabilities'],0,8) as $c)<div class="small">{{ $c['id'] }}</div>@empty—@endforelse</td><td>@forelse($e['fallback_eligibility'] as $f)<div class="small"><strong>{{ $f['capability'] }}</strong> eligible, authority: no</div>@empty—@endforelse</td></tr>@endforeach
  </tbody></table></div></div>
  @else
    @php($rows=$inspector['surfaces'][$activeView] ?? [])
    <div class="card"><div class="card-header"><strong>{{ $tabs[$activeView] ?? $activeView }}</strong><span class="text-muted ms-2">{{ count($rows) }} provider-qualified surfaces</span></div><div class="table-responsive"><table class="table table-vcenter mb-0"><thead><tr><th>ID</th><th>Provider</th><th>Provider health</th><th>Version</th><th>Mode / authority</th><th>Writes state</th></tr></thead><tbody>
    @foreach($rows as $row)<tr><td><code>{{ $row['id'] }}</code></td><td>{{ $row['provider'] }}</td><td><span class="badge {{ $row['provider_status']==='active'?'bg-success':($row['provider_status']==='quarantined'?'bg-danger':'bg-secondary') }}">{{ $row['provider_status'] }}</span></td><td>{{ $row['version'] ?: '—' }}</td><td>{{ $row['mode'] ?: '—' }} @if($row['authority'])· {{ $row['authority'] }}@endif</td><td>{{ $row['writes_state']?'yes':'no' }}</td></tr>@endforeach
    </tbody></table></div></div>
  @endif

  <div class="alert alert-info mt-4 mb-0"><strong>{{ __('Safety boundary:') }}</strong> {{ __('Expected/bound providers, currently available surfaces, policy state and fallback eligibility are diagnostic only. They never grant authority. Consequential execution still requires task-scoped Risk, Assurance, Governance and Autonomy authorization through Command Bus.') }}</div>
</div>
@endsection
