@extends('panel.layout.app')
@section('title', __('Ask Workforce'))
@section('content')
<div class="container-xl py-4 space-y-6">
  <div><h1 class="text-2xl font-semibold">{{ __('Ask Workforce') }}</h1><p class="text-sm text-foreground/60">{{ __('Talk to the organisational control plane. Read Workforce state or create a governed Work Item for an AI employee.') }}</p></div>
  <div class="alert alert-info">{{ __('Conversation can create a Governed Work Item, but it does not grant execution authority. Consequential work still requires the normal capability, Risk, Assurance, Governance and Autonomy gates.') }}</div>
  <form method="POST" action="{{ route('dashboard.user.titan-workforce.conversation.submit') }}" class="rounded-xl border p-4 space-y-3">@csrf
    <label class="form-label">{{ __('Message') }}</label>
    <textarea name="message" class="form-control" rows="4" required placeholder="What is my AI workforce doing?&#10;Why is Reception degraded?&#10;Ask Finance Manager to investigate overdue invoices.">{{ old('message', $message ?? '') }}</textarea>
    <button class="btn btn-primary" type="submit">{{ __('Ask Workforce') }}</button>
  </form>
  @if(!empty($response))
  <section class="rounded-xl border p-4"><div class="text-xs uppercase tracking-wide text-foreground/50">{{ $response['intent'] ?? 'response' }}</div><div class="mt-2 text-lg font-medium">{{ $response['message'] ?? '' }}</div>
    @if(!empty($response['task']['id']))<div class="mt-3"><a class="btn btn-outline-primary btn-sm" href="{{ route('dashboard.user.titan-workforce.tasks.show',$response['task']['id']) }}">{{ __('Open governed Work Item') }} #{{ $response['task']['id'] }}</a></div>@endif
    @if(!empty($response['items']))<div class="mt-4 space-y-2">@foreach(array_slice($response['items'],0,20) as $item)<div class="rounded-lg bg-foreground/[.03] p-3 text-sm"><strong>{{ $item['name'] ?? $item['title'] ?? ('Work Item #'.($item['id'] ?? '')) }}</strong><span class="text-foreground/50"> {{ $item['role'] ?? $item['status'] ?? '' }}</span></div>@endforeach</div>@endif
  </section>
  @endif
</div>
@endsection
