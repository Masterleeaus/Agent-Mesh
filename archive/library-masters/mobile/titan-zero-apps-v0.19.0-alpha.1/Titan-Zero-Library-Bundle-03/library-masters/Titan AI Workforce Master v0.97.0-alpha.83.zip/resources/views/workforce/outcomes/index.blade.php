@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Outcome Intelligence'))
@section('titlebar_subtitle', __('Separate Workforce activity from verified business results.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
  $activityLabels=['tasks'=>'Tasks','responses'=>'Responses','reviews'=>'Reviews','execution_count'=>'Executions'];
@endphp
<div class="px-5 py-8 space-y-8">
  <section class="rounded-2xl border bg-card p-6">
    <div class="flex flex-wrap items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Activity is not outcome') }}</h2><p class="mt-1 max-w-3xl text-sm text-foreground/60">{{ __('Tasks, responses, reviews and executions show work performed. They are never counted as evidence that the business result happened.') }}</p></div><span class="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-700">{{ number_format($center['verified_outcome_count']) }} {{ __('verified outcomes') }}</span></div>
    <div class="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">@foreach($activityLabels as $key=>$label)<div class="rounded-xl border p-4"><div class="text-xs uppercase text-foreground/45">{{ __($label) }}</div><div class="mt-2 text-2xl font-semibold">{{ number_format((int)($center['activity'][$key] ?? 0)) }}</div></div>@endforeach</div>
  </section>

  <section class="rounded-2xl border bg-card p-6">
    <div><h2 class="m-0 text-xl font-semibold">{{ __('Verified business outcomes') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Only verified WorkforceOutcome records contribute to these business-result measures.') }}</p></div>
    <div class="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">@foreach($center['outcome_labels'] as $key=>$label)<div class="rounded-xl border p-4"><div class="text-xs uppercase text-foreground/45">{{ __($label) }}</div><div class="mt-2 text-2xl font-semibold">@if($key==='recovered_revenue')${{ number_format((float)($center['outcomes'][$key] ?? 0),2) }}@else{{ number_format((float)($center['outcomes'][$key] ?? 0),0) }}@endif</div></div>@endforeach</div>
  </section>

  <section class="rounded-2xl border bg-card p-6">
    <div class="flex flex-wrap items-center justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Measure by organisation dimension') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Employee · role · team · division · responsibility · workflow') }}</p></div><div class="flex flex-wrap gap-2">@foreach($center['dimensions'] as $dimension)<a class="btn btn-sm {{ $center['dimension']===$dimension?'btn-primary':'btn-outline-secondary' }}" href="{{ route('dashboard.user.titan-workforce.outcome-intelligence',['dimension'=>$dimension]) }}">{{ __(ucfirst($dimension)) }}</a>@endforeach</div></div>
    <div class="mt-5 overflow-x-auto"><table class="w-full min-w-[1150px] text-sm"><thead class="bg-foreground/[.03] text-left text-xs uppercase text-foreground/50"><tr><th class="p-3">{{ __(ucfirst($center['dimension'])) }}</th>@foreach($activityLabels as $label)<th class="p-3">{{ __($label) }}</th>@endforeach @foreach($center['outcome_labels'] as $key=>$label)<th class="p-3">{{ __($label) }}</th>@endforeach</tr></thead><tbody>
    @forelse($center['rows'] as $row)<tr class="border-t"><td class="p-3 font-medium">{{ $row['label'] }}</td>@foreach(array_keys($activityLabels) as $key)<td class="p-3">{{ number_format((int)$row['activity'][$key]) }}</td>@endforeach @foreach($center['outcome_labels'] as $key=>$label)<td class="p-3">@if($key==='recovered_revenue')${{ number_format((float)$row['outcomes'][$key],2) }}@else{{ number_format((float)$row['outcomes'][$key],0) }}@endif</td>@endforeach</tr>@empty<tr><td colspan="13" class="p-8 text-center text-foreground/50">{{ __('No activity or verified outcome records are available for this dimension yet.') }}</td></tr>@endforelse
    </tbody></table></div>
  </section>

  <div class="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-foreground/70"><b>{{ __('Authority boundary:') }}</b> {{ __('Outcome Intelligence is read-only evidence. Performance or outcome scores do not grant, raise or inherit authority and this surface does not grant execution authority.') }}</div>
</div>
@endsection
