@extends('panel.layout.app')
@section('title', __('Decision Rights & RACI'))
@section('content')
@php
  $activeView = request('view', 'responsible');
  $labels = [
    'responsible'=>'Responsible','accountable'=>'Accountable','consulted'=>'Consulted','informed'=>'Informed',
    'reviewer'=>'Reviewer','escalation_owner'=>'Escalation owner','human_required'=>'Human-required decisions'
  ];
  $rows = $center['views'][$activeView] ?? $center['rows'];
@endphp
<div class="container-xl py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="mb-1">{{ __('Decision Rights & RACI Center') }}</h1><p class="text-muted mb-0">{{ __('Who participates in organisational decisions, who reviews them, where they escalate, and which decisions require a human.') }}</p></div>
    <div class="d-flex gap-2"><span class="badge bg-blue-lt">{{ $center['canonical_count'] }} {{ __('Canonical') }}</span><span class="badge bg-secondary-lt">{{ $center['extension_count'] }} {{ __('Extension-owned') }}</span></div>
  </div>

  <div class="alert alert-info"><strong>{{ __('RACI does not grant executable capability.') }}</strong> {{ __('Responsible, Accountable, Consulted, Informed, Reviewer or Escalation owner assignments describe organisational participation only. Risk, Assurance, Governance, Autonomy and Command Bus remain separate gates.') }}</div>

  <div class="card mb-4"><div class="card-body"><div class="d-flex flex-wrap gap-2">
    @foreach($labels as $key=>$label)
      <a href="{{ route('dashboard.user.titan-workforce.decision-rights-center', ['view'=>$key]) }}" class="btn btn-sm {{ $activeView === $key ? 'btn-primary' : 'btn-outline-secondary' }}">{{ __($label) }} <span class="badge bg-white-lt ms-1">{{ $center['counts'][$key] ?? 0 }}</span></a>
    @endforeach
  </div></div></div>

  <div class="card"><div class="table-responsive"><table class="table table-vcenter card-table">
    <thead><tr><th>{{ __('Decision') }}</th><th>{{ __($labels[$activeView] ?? 'Responsible') }}</th><th>{{ __('Provenance') }}</th><th>{{ __('Human required') }}</th></tr></thead>
    <tbody>
    @forelse($rows as $row)
      @php $participants = $activeView === 'human_required' ? $row['accountable'] : ($row[$activeView] ?? []); @endphp
      <tr>
        <td><div class="fw-semibold">{{ $row['name'] ?? $row['decision'] }}</div><div class="small text-muted"><code>{{ $row['decision'] }}</code></div></td>
        <td>
          @forelse($participants as $participant)
            <div class="mb-2"><span class="badge bg-blue-lt">{{ $participant['role_name'] }}</span>
              @forelse($participant['members'] as $member)<a class="badge bg-green-lt text-decoration-none" href="{{ $member['url'] }}">{{ $member['name'] }}</a>@empty<span class="badge bg-yellow-lt">{{ __('No active assignment') }}</span>@endforelse
            </div>
          @empty<span class="text-muted">—</span>@endforelse
        </td>
        <td><div>{{ $row['source'] ?? 'extension_workforce_manifest' }}</div><div class="small text-muted">{{ $row['owner_extension'] ?? 'unknown' }}</div></td>
        <td>{!! !empty($row['human_required']) ? '<span class="badge bg-red-lt">'.e(__('Yes')).'</span>' : '<span class="badge bg-secondary-lt">'.e(__('No')).'</span>' !!}</td>
      </tr>
    @empty<tr><td colspan="4" class="text-center py-5 text-muted">{{ __('No decision rights match this view.') }}</td></tr>@endforelse
    </tbody>
  </table></div></div>

  <p class="text-muted small mt-3">{{ __('RACI assignments never create capability, authority, autonomy, or provider access. They only identify organisational participation and escalation responsibility.') }}</p>
</div>
@endsection
