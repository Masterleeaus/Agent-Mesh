@extends('panel.layout.app',['disable_tblr'=>true,'layout_wide'=>true])
@section('title',__('Release Readiness'))
@section('content')
<div class="px-5 py-8 space-y-6">
<div class="flex flex-wrap items-start justify-between gap-4"><div><h1 class="text-2xl font-semibold">{{ __('Release Readiness') }}</h1><p class="mt-1 text-sm text-foreground/60">{{ __('Final production gate across architecture, tenancy, authority, providers, governance, outcomes and auditability.') }}</p></div><div class="rounded-full border px-4 py-2 font-semibold">{{ $readiness['release_gate'] }}</div></div>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Release gate') }}</h2><p class="mt-2 text-sm">{{ $readiness['release_gate']==='READY' ? __('No hard runtime readiness blocker is currently detected.') : __('Release is blocked until the findings below are resolved.') }}</p></section>
<div class="grid gap-4 md:grid-cols-2">@foreach($readiness['checks'] as $name=>$check)<section class="rounded-2xl border bg-card p-5"><div class="flex justify-between gap-3"><h2 class="font-semibold">{{ __(ucfirst(str_replace('_',' ',$name))) }}</h2><span class="text-sm font-semibold">{{ $check['state'] }}</span></div><p class="mt-2 text-sm text-foreground/60">{{ $check['evidence'] }}</p></section>@endforeach</div>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Blocking findings') }}</h2>@forelse($readiness['blocking_findings'] as $finding)<div class="mt-3 rounded-xl border p-3 text-sm">{{ $finding }}</div>@empty<p class="mt-2 text-sm">{{ __('None.') }}</p>@endforelse</section>
<section class="rounded-2xl border bg-card p-5"><h2 class="font-semibold">{{ __('Architecture') }} · {{ __('Tenancy') }} · {{ __('Auditability') }}</h2><p class="mt-2 text-xs text-foreground/50">{{ __('This gate is read-only. It cannot grant capability, inherit authority, approve governance decisions or create execution rights.') }}</p></section>
</div>
@endsection
