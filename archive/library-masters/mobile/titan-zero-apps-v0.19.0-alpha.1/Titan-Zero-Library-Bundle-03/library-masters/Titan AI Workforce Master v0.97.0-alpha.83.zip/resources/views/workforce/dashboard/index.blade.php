@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Titan AI Workforce'))
@section('titlebar_subtitle', __('Operational command home for workforce health, queues, capability availability, execution and outcomes.'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php
    $staff = $dashboard['staff'];
    $work = $dashboard['work'];
    $providers = $dashboard['providers'];
    $queues = $dashboard['manager_queues'];
    $execution = $dashboard['execution'];
    $outcomes = $dashboard['outcomes'];
    $healthTone = ['HEALTHY' => 'border-emerald-500/30 bg-emerald-500/5 text-emerald-700', 'ATTENTION' => 'border-amber-500/30 bg-amber-500/5 text-amber-700', 'CRITICAL' => 'border-red-500/30 bg-red-500/5 text-red-700'][$dashboard['health']] ?? 'border-foreground/10 bg-card';
@endphp
<div class="px-5 py-8 space-y-8">
    <section class="rounded-2xl border p-6 {{ $healthTone }}">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <div class="text-xs font-semibold uppercase tracking-wide opacity-70">{{ __('Workforce health') }}</div>
                <div class="mt-2 text-3xl font-semibold">{{ $dashboard['health'] }}</div>
                <p class="mt-2 max-w-3xl text-sm opacity-80">{{ __('One operational view of staffing, work pressure, provider availability, proactive routines, governed execution and verified outcomes.') }}</p>
            </div>
            <div class="flex gap-2"><x-button href="{{ route('dashboard.user.titan-workforce.control-room') }}" variant="outline">{{ __('Open Control Room') }}</x-button><x-button href="{{ route('dashboard.user.titan-workforce.tasks') }}" variant="outline">{{ __('Open Work') }}</x-button></div>
        </div>
    </section>

    <section>
        <div class="mb-3 flex items-end justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Workforce at a glance') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Live company-scoped health signals. Capability state is re-evaluated from installed providers and policy.') }}</p></div></div>
        <div class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-6">
            @foreach ([
                ['Active staff',$staff['active'],'Staff currently active'],
                ['Degraded staff',$staff['degraded'],'Partially available capability surface'],
                ['Blocked staff',$staff['blocked'],'Unavailable, blocked, missing-provider or policy-disabled'],
                ['Open work',$work['open'],'All non-terminal work'],
                ['Manager review',$work['review'],'Submitted or handoff review'],
                ['Blocked work',$work['blocked'],'Blocked, awaiting data or recovery'],
                ['Escalated work',$work['escalated'],'Needs higher-authority decision'],
                ['Provider health',$providers['healthy'].' / '.$providers['total'],'Healthy expected providers'],
                ['Queue pressure',$queues['critical'] + $queues['high'],'Critical or high manager queues'],
                ['Overdue proactive',$dashboard['proactive']['overdue_responsibilities'],'Scheduled responsibilities overdue'],
                ['Execution failures',$execution['failures'],'Blocked or recovery-required attempts'],
                ['Recoveries',$execution['recoveries'],'Reconciled, compensated or recovered attempts'],
            ] as [$label,$value,$hint])
                <div class="rounded-xl border bg-card p-4 shadow-sm"><div class="text-xs font-medium uppercase text-foreground/50">{{ __($label) }}</div><div class="mt-2 text-3xl font-semibold">{{ $value }}</div><div class="mt-1 text-xs text-foreground/45">{{ __($hint) }}</div></div>
            @endforeach
        </div>
    </section>

    <div class="grid gap-6 xl:grid-cols-3">
        <section class="rounded-xl border bg-card p-6 xl:col-span-2">
            <div class="flex items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Needs attention now') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Prioritized operational conditions derived from the same authoritative Workforce state shown elsewhere.') }}</p></div><span class="rounded-full bg-foreground/5 px-3 py-1 text-xs">{{ count($dashboard['needs_attention']) }}</span></div>
            <div class="mt-5 space-y-3">
                @forelse($dashboard['needs_attention'] as $item)
                    @php $tone = $item['severity'] === 'critical' ? 'border-red-500/30 bg-red-500/5' : ($item['severity'] === 'warning' ? 'border-amber-500/30 bg-amber-500/5' : 'border-foreground/10'); @endphp
                    <div class="rounded-lg border p-4 {{ $tone }}"><div class="flex flex-wrap items-start justify-between gap-3"><div><div class="font-semibold">{{ __($item['title']) }}</div><div class="mt-1 text-sm text-foreground/60">{{ __($item['detail']) }}</div></div><div class="flex items-center gap-2"><span class="rounded-full bg-foreground/5 px-2 py-1 text-xs font-semibold">{{ $item['count'] }}</span><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] uppercase">{{ $item['severity'] }}</span></div></div></div>
                @empty
                    <div class="rounded-lg border border-dashed p-6 text-center"><div class="font-semibold">{{ __('No immediate attention items') }}</div><div class="mt-1 text-sm text-foreground/55">{{ __('Current operational signals are healthy.') }}</div></div>
                @endforelse
            </div>
        </section>

        <section class="rounded-xl border bg-card p-6">
            <h2 class="m-0 text-xl font-semibold">{{ __('Outcome health') }}</h2>
            <p class="mt-1 text-sm text-foreground/60">{{ __('Execution is not considered a business outcome until authoritative verification arrives.') }}</p>
            <div class="mt-5 rounded-lg border p-4"><div class="text-xs uppercase text-foreground/45">{{ __('Status') }}</div><div class="mt-1 text-2xl font-semibold">{{ $outcomes['status'] }}</div></div>
            <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Missing verification') }}</div><div class="mt-1 text-xl font-semibold">{{ $outcomes['verification_missing'] }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Late verification') }}</div><div class="mt-1 text-xl font-semibold">{{ $outcomes['verification_late'] }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Recovery tasks') }}</div><div class="mt-1 text-xl font-semibold">{{ $outcomes['recovery_tasks'] }}</div></div>
                <div class="rounded-lg border p-3"><div class="text-xs text-foreground/45">{{ __('Staffing recommendations') }}</div><div class="mt-1 text-xl font-semibold">{{ $dashboard['staffing']['recommendations'] }}</div></div>
            </div>
        </section>
    </div>

    <div class="grid gap-6 xl:grid-cols-2">
        <section class="rounded-xl border bg-card p-6">
            <div class="flex items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Capability-provider health') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Expected provider bindings aggregated across active staff. Availability never grants execution authority.') }}</p></div><span class="rounded-full bg-foreground/5 px-3 py-1 text-xs">{{ $providers['healthy'] }}/{{ $providers['total'] }} {{ __('healthy') }}</span></div>
            <div class="mt-5 space-y-2 max-h-96 overflow-auto">
                @forelse(collect($providers['providers'])->sortByDesc('affected_staff')->take(18) as $provider)
                    <div class="flex items-center justify-between gap-3 rounded-lg border p-3"><div><div class="font-medium">{{ $provider['provider'] }}</div><div class="text-xs text-foreground/45">{{ $provider['role_bindings'] }} {{ __('active role bindings') }}</div></div><div class="text-right"><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold uppercase">{{ $provider['state'] }}</span>@if($provider['affected_staff'] > 0)<div class="mt-1 text-xs text-foreground/50">{{ $provider['affected_staff'] }} {{ __('affected staff') }}</div>@endif</div></div>
                @empty<div class="rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No provider bindings are required by current staff.') }}</div>@endforelse
            </div>
        </section>

        <section class="rounded-xl border bg-card p-6">
            <div><h2 class="m-0 text-xl font-semibold">{{ __('Manager queue pressure') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Pressure combines capacity, overdue, blocked, escalated and starved work.') }}</p></div>
            <div class="mt-5 overflow-x-auto"><table class="w-full text-sm"><thead class="text-left text-xs uppercase text-foreground/45"><tr><th class="pb-2">{{ __('Manager') }}</th><th class="pb-2">{{ __('Pressure') }}</th><th class="pb-2">{{ __('Open') }}</th><th class="pb-2">{{ __('Overdue') }}</th><th class="pb-2">{{ __('Blocked') }}</th></tr></thead><tbody>
                @forelse(collect($queues['rows'])->sortBy(fn($row) => ['CRITICAL'=>0,'HIGH'=>1,'ELEVATED'=>2,'NORMAL'=>3][data_get($row,'health.pressure')] ?? 9)->take(12) as $queue)
                    <tr class="border-t"><td class="py-3"><div class="font-medium">{{ $queue['manager'] }}</div><div class="text-xs text-foreground/45">{{ $queue['division'] }}</div></td><td class="py-3"><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold">{{ data_get($queue,'health.pressure') }}</span></td><td class="py-3">{{ data_get($queue,'health.queue_depth',0) }}</td><td class="py-3">{{ data_get($queue,'health.overdue_count',0) }}</td><td class="py-3">{{ data_get($queue,'health.blocked_count',0) }}</td></tr>
                @empty<tr><td colspan="5" class="py-6 text-center text-foreground/55">{{ __('No active manager queues yet.') }}</td></tr>@endforelse
            </tbody></table></div>
        </section>
    </div>

    <div class="grid gap-6 xl:grid-cols-2">
        <section class="rounded-xl border bg-card p-6">
            <div class="flex items-start justify-between gap-4"><div><h2 class="m-0 text-xl font-semibold">{{ __('Recent critical events') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Latest escalations, execution failures and recoveries from immutable task history.') }}</p></div><x-button href="{{ route('dashboard.user.titan-workforce.control-room') }}" variant="outline" size="sm">{{ __('Inspect') }}</x-button></div>
            <div class="mt-5 space-y-3">
                @forelse($dashboard['recent_critical_events'] as $event)
                    <div class="rounded-lg border p-3"><div class="flex items-start justify-between gap-3"><div><div class="font-medium">{{ $event['event'] }}</div><div class="mt-1 text-xs text-foreground/50">{{ __('Task') }} #{{ $event['task_id'] }} · {{ $event['created_at'] }}</div></div><span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] uppercase">{{ $event['severity'] }}</span></div>@if($event['reason'])<div class="mt-2 text-sm text-foreground/60">{{ $event['reason'] }}</div>@endif</div>
                @empty<div class="rounded-lg border border-dashed p-5 text-sm text-foreground/55">{{ __('No recent critical Workforce events.') }}</div>@endforelse
            </div>
        </section>

        <section class="rounded-xl border bg-card p-6">
            <div class="flex flex-wrap items-center justify-between gap-3"><div><h2 class="m-0 text-xl font-semibold">{{ __('AI Team') }}</h2><p class="mt-1 text-sm text-foreground/60">{{ __('Current managers and specialists. Live provider health is summarized above.') }}</p></div><x-button href="{{ route('dashboard.user.titan-workforce.team') }}" variant="outline">{{ __('Open Team Center') }}</x-button></div>
            <div class="mt-5 grid gap-3 sm:grid-cols-2">
                @forelse($members->take(12) as $member)
                    <div class="rounded-lg border p-3"><div class="flex items-start justify-between gap-3"><div><a class="font-semibold hover:underline" href="{{ route('dashboard.user.titan-workforce.staff.show', $member) }}">{{ $member->name }}</a><div class="text-sm text-foreground/60">{{ $member->role }}</div></div><div class="flex flex-wrap justify-end gap-1">@include('titan-ai-workforce::components.capability-health-badge',['state'=>$dashboard['member_capability_states'][$member->id] ?? 'unavailable','memberId'=>$member->id])<span class="rounded-full bg-foreground/5 px-2 py-1 text-[10px] font-semibold">{{ $member->status?->value }}</span></div></div><div class="mt-2 text-xs text-foreground/45">{{ $member->division?->name }} · {{ $member->tier?->label() }}</div></div>
                @empty<div class="col-span-full rounded-lg border border-dashed p-8 text-center"><h3 class="font-semibold">{{ __('Your workforce is ready to be assembled.') }}</h3><p class="text-sm text-foreground/60">{{ __('Add an Operations Manager or another intrinsic staff role.') }}</p><x-button class="mt-3" href="{{ route('dashboard.user.titan-workforce.create') }}">{{ __('Add Staff Member') }}</x-button></div>@endforelse
            </div>
        </section>
    </div>
</div>
@endsection
