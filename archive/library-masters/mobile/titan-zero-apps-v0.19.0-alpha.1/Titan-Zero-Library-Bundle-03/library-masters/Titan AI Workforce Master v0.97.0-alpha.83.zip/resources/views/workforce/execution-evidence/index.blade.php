@extends('panel.layout.app', ['disable_tblr' => true, 'layout_wide' => true])
@section('title', __('Execution & Evidence Explorer'))
@section('titlebar_subtitle', __('Forensic, read-only reconstruction of consequential Workforce actions'))
@section('titlebar_actions') @include('titan-ai-workforce::components.titlebar-actions') @endsection
@section('content')
@php $f=$explorer['filters']; @endphp
<div class="px-5 py-8 space-y-5">
  <div class="rounded-xl border bg-card p-5">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div><h1 class="text-2xl font-semibold">{{ __('Execution & Evidence Explorer') }}</h1><p class="mt-1 text-sm text-foreground/55">{{ __('Search the complete consequential-action evidence chain without changing its state.') }}</p></div>
      <div class="rounded-full bg-foreground/5 px-3 py-2 text-xs font-semibold">{{ number_format($explorer['total']) }} {{ __('matching records') }}</div>
    </div>
    <form method="GET" class="mt-5 grid gap-3 lg:grid-cols-5">
      <input name="q" value="{{ $f['q'] }}" placeholder="{{ __('Search task, employee, intent, receipt, decision, evidence…') }}" class="rounded-lg border bg-transparent px-3 py-2 text-sm lg:col-span-2">
      <select name="type" class="rounded-lg border bg-transparent px-3 py-2 text-sm"><option value="">{{ __('All evidence types') }}</option>@foreach($explorer['types'] as $key=>$label)<option value="{{ $key }}" @selected($f['type']===$key)>{{ $label }}</option>@endforeach</select>
      <select name="task" class="rounded-lg border bg-transparent px-3 py-2 text-sm"><option value="0">{{ __('All tasks') }}</option>@foreach($explorer['tasks'] as $task)<option value="{{ $task->id }}" @selected((int)$f['task']===(int)$task->id)>{{ $task->title }}</option>@endforeach</select>
      <div class="flex gap-2"><select name="employee" class="min-w-0 flex-1 rounded-lg border bg-transparent px-3 py-2 text-sm"><option value="0">{{ __('All employees') }}</option>@foreach($explorer['employees'] as $member)<option value="{{ $member->id }}" @selected((int)$f['employee']===(int)$member->id)>{{ $member->name }}</option>@endforeach</select><button class="rounded-lg bg-foreground px-4 py-2 text-sm font-semibold text-background">{{ __('Search') }}</button></div>
    </form>
  </div>

  <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-7">
    @foreach($explorer['types'] as $key=>$label)
      <a href="{{ route('dashboard.user.titan-workforce.execution-evidence', array_filter(['type'=>$key,'task'=>$f['task'] ?: null,'employee'=>$f['employee'] ?: null])) }}" class="rounded-xl border bg-card p-3 hover:bg-foreground/[.02]"><div class="text-xs text-foreground/45">{{ $label }}</div><div class="mt-1 text-xl font-semibold">{{ number_format((int)($explorer['counts'][$key] ?? 0)) }}</div></a>
    @endforeach
  </div>

  <section class="rounded-xl border bg-card overflow-hidden">
    <div class="border-b px-5 py-4"><h2 class="font-semibold">{{ __('Forensic evidence stream') }}</h2><p class="mt-1 text-xs text-foreground/45">{{ __('Execution intent → Risk → Assurance → Governance → Autonomy → Command Bus → execution attempt → receipt → state verification → Rewind recovery → Final outcome') }}</p></div>
    <div class="divide-y">
      @forelse($explorer['rows'] as $row)
        <article class="p-5">
          <div class="flex flex-wrap items-start justify-between gap-3">
            <div class="min-w-0"><div class="flex flex-wrap items-center gap-2"><span class="rounded-full bg-foreground/5 px-2 py-1 text-xs font-semibold">{{ $row['type_label'] }}</span><span class="rounded-full border px-2 py-1 text-xs">{{ $row['state'] ?: '—' }}</span></div><h3 class="mt-2 font-semibold">{{ $row['title'] }}</h3><div class="mt-1 text-xs text-foreground/45">{{ $row['timestamp'] ?: '—' }} @if($row['task_uuid']) · {{ $row['task_uuid'] }} @endif @if($row['employee_name']) · {{ $row['employee_name'] }} @endif</div></div>
            <div class="flex gap-2">@if($row['task_url'])<a href="{{ $row['task_url'] }}" class="rounded-lg border px-3 py-2 text-xs font-semibold">{{ __('Task') }}</a>@endif @if($row['employee_url'])<a href="{{ $row['employee_url'] }}" class="rounded-lg border px-3 py-2 text-xs font-semibold">{{ __('Employee') }}</a>@endif</div>
          </div>
          <details class="mt-3"><summary class="cursor-pointer text-sm font-medium">{{ __('Inspect recorded payload') }}</summary><pre class="mt-3 max-h-96 overflow-auto rounded-lg bg-foreground/[.03] p-3 text-xs whitespace-pre-wrap break-words">{{ json_encode($row['payload'], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) }}</pre></details>
        </article>
      @empty
        <div class="p-8 text-center text-sm text-foreground/50">{{ __('No forensic records match the selected filters.') }}</div>
      @endforelse
    </div>
  </section>

  <div class="rounded-xl border border-amber-500/25 bg-amber-500/5 p-4 text-sm"><strong>{{ __('Read-only forensic projection:') }}</strong> {{ __('This explorer reconstructs recorded evidence. It cannot approve work, alter a governance decision, retry a command, grant capability, or grant execution authority.') }}</div>
</div>
@endsection
