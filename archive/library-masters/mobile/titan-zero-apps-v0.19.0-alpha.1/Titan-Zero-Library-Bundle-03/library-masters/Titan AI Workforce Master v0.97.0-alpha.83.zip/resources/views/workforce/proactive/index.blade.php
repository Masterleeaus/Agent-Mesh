@extends('panel.layout.app')
@section('title', __('Proactive Operations'))
@section('content')
<div class="container-fluid py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="mb-1">{{ __('Proactive Operations Center') }}</h1><p class="text-muted mb-0">{{ __('What is the Workforce doing by itself? Scheduled and Signal-driven autonomous activity in one company-scoped view.') }}</p></div>
    <a class="btn btn-outline-secondary" href="{{ route('dashboard.user.titan-workforce.responsibilities') }}">{{ __('Responsibilities') }}</a>
  </div>
  @php($s=$center['summary'])
  <div class="row g-3 mb-4">
    @foreach(['scheduled_routines'=>'Scheduled routines','event_driven_routines'=>'Event-driven routines','generated_work'=>'Generated work','skipped_runs'=>'Skipped runs','degraded_runs'=>'Degraded runs','blocked_runs'=>'Blocked runs'] as $key=>$label)
      <div class="col-6 col-md-4 col-xl-2"><div class="card h-100"><div class="card-body"><div class="text-muted small">{{ __($label) }}</div><div class="fs-2 fw-bold">{{ $s[$key] }}</div></div></div></div>
    @endforeach
  </div>
  @foreach(['scheduled'=>'Scheduled routines','event_driven'=>'Event-driven routines'] as $bucket=>$heading)
  <div class="card mb-4">
    <div class="card-header"><h3 class="card-title mb-0">{{ __($heading) }}</h3></div>
    <div class="table-responsive"><table class="table table-vcenter mb-0">
      <thead><tr><th>Routine</th><th>Employee</th><th>Last / Next</th><th>Triggering Signal</th><th>Runs</th><th>Capability health</th><th>Provider dependencies</th><th>Recent work</th></tr></thead>
      <tbody>
      @forelse($center[$bucket] as $row)
        <tr>
          <td><strong>{{ $row['name'] }}</strong><div class="small text-muted">{{ $row['routine_id'] }} · {{ $row['is_active'] ? 'active' : 'disabled' }}</div>@if($row['disabled_reason'])<div class="small text-danger">{{ $row['disabled_reason'] }}</div>@endif</td>
          <td>@if($row['employee'])<a href="{{ route('dashboard.user.titan-workforce.staff.show',$row['employee']['id']) }}">{{ $row['employee']['name'] }}</a><div class="small text-muted">{{ $row['employee']['role'] }}</div>@else<span class="text-danger">Missing employee</span>@endif</td>
          <td><div><span class="text-muted">Last:</span> {{ $row['last_run_at'] ?: '—' }}</div><div><span class="text-muted">Next:</span> {{ $row['next_run_at'] ?: 'event driven' }}</div></td>
          <td>@if($row['triggering_signal'])<strong>{{ $row['triggering_signal']['event_type'] ?? 'Signal' }}</strong><div class="small text-muted">{{ $row['triggering_signal']['signal_id'] ?? 'no signal id' }}</div>@else—@endif</td>
          <td><div>Generated <strong>{{ $row['generated_runs'] }}</strong></div><div class="small">Skipped {{ $row['skipped_runs'] }} · Degraded {{ $row['degraded_runs'] }} · Blocked {{ $row['blocked_runs'] }}</div></td>
          <td><span class="badge {{ $row['capability_state']==='available' ? 'bg-success' : ($row['capability_state']==='degraded' ? 'bg-warning' : 'bg-danger') }}">{{ $row['capability_state'] }}</span><div class="small text-muted">{{ $row['last_status'] }}</div></td>
          <td>@forelse($row['provider_dependencies'] as $provider)<span class="badge bg-secondary-lt me-1 mb-1">{{ $provider['provider'] }}: {{ $provider['state'] }}</span>@empty—@endforelse</td>
          <td>@forelse($row['recent_work'] as $task)<a class="d-block" href="{{ route('dashboard.user.titan-workforce.tasks.show',$task['id']) }}">#{{ $task['id'] }} {{ \Illuminate\Support\Str::limit($task['title'],40) }}</a>@empty—@endforelse</td>
        </tr>
      @empty<tr><td colspan="8" class="text-center text-muted py-4">{{ __('No routines in this category.') }}</td></tr>@endforelse
      </tbody>
    </table></div>
  </div>
  @endforeach
  <div class="alert alert-info">{{ __('This center is observational. Routine, provider, employee or capability state does not grant execution authority; consequential work still passes through Risk, Assurance, Governance and Autonomy.') }}</div>
</div>
@endsection
