<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach(['System/Services/WorkforceSystemHealthService.php','resources/views/workforce/system-health/index.blade.php'] as $f){
 if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing {$f}\n");exit(1);}
}
$s=file_get_contents($root.'/System/Services/WorkforceSystemHealthService.php');
$c=file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$p=file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$v=file_get_contents($root.'/resources/views/workforce/system-health/index.blade.php');
foreach(['workforce_health','provider_health','queue_health','outcome_health','governance_health','proactive_health','data_integrity','critical_findings','recommended_actions','company_id'] as $n){
 if(strpos($s,$n)===false){fwrite(STDERR,"Service missing {$n}\n");exit(1);}
}
foreach(['System Health','Critical findings','Recommended actions','Provider health','Governance health'] as $n){
 if(strpos($v,$n)===false){fwrite(STDERR,"View missing {$n}\n");exit(1);}
}
if(strpos($c,'workforceSystemHealth')===false||strpos($p,"system-health")===false){fwrite(STDERR,"Route/controller missing\n");exit(1);}
echo "workforce_system_health_center_contract_test: PASS\n";
