<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};
$p=$json('resources/workforce/knowledge-authority-runtime-control.json');
if(($p['tenant_key']??null)!=='company_id')$fail('tenant');
if(($p['required_for_consequential_ai_work']??null)!==true)$fail('required');
if(($p['failure_mode']??null)!=='fail_closed')$fail('fail closed');
if(($p['safety']['knowledge_grants_execution_authority']??null)!==false)$fail('authority');
$s=$read('System/Services/WorkforceKnowledgeUncertaintyService.php');
foreach(['preflight-unresolved','missing-authority','public_reusable','knowledge_uncertainties','execution_authority_granted'] as $n)if(!str_contains($s,$n))$fail($n);
$m=$read('database/migrations/2026_08_24_023500_workforce_knowledge_authority_control_plane.php');
if(!str_contains($m,'knowledge_preflight'))$fail('migration');
echo "PASS: knowledge authority runtime control plane\n";
