<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$teamsPath = $root . '/resources/workforce/team-definitions.json';
$ok(is_file($teamsPath), 'canonical team catalogue must exist');
$teams = is_file($teamsPath) ? json_decode((string) file_get_contents($teamsPath), true) : [];
$ok(is_array($teams), 'canonical team catalogue must be a JSON array');
$teams = is_array($teams) ? $teams : [];
$ok(count($teams) === 62, 'canonical team catalogue must contain exactly 62 practical operational teams');

$divisionDefs = json_decode((string) file_get_contents($root . '/resources/workforce/division-definitions.json'), true);
$divisionKeys = [];
foreach (is_array($divisionDefs) ? $divisionDefs : [] as $division) $divisionKeys[(string) $division['key']] = true;

$teamIds = [];
$teamKeys = [];
$byDivision = [];
foreach ($teams as $team) {
    $id = (string) ($team['team_definition_id'] ?? '');
    $key = (string) ($team['key'] ?? '');
    $division = (string) ($team['division_key'] ?? '');
    $teamIds[] = $id;
    $teamKeys[] = $key;
    $byDivision[$division][] = $key;
    $ok(str_starts_with($id, 'titan.team.'), "team {$key} must have stable titan.team.* identity");
    $ok($key !== '', "team {$id} key missing");
    $ok(isset($divisionKeys[$division]), "team {$key} references unknown division {$division}");
    $ok(is_string($team['name'] ?? null) && trim((string) $team['name']) !== '', "team {$key} name missing");
    $ok(is_string($team['purpose'] ?? null) && trim((string) $team['purpose']) !== '', "team {$key} purpose missing");
    $ok(is_array($team['boundaries'] ?? null) && count($team['boundaries']) >= 1, "team {$key} boundaries missing");
    $ok(is_array($team['applicability'] ?? null), "team {$key} applicability missing");
    $ok(($team['activation_rules']['auto_activate'] ?? null) === false, "team {$key} must not auto-activate during Pass 8");
}
$ok(count(array_unique($teamIds)) === 62, 'team_definition_id values must be unique');
$ok(count(array_unique($teamKeys)) === 62, 'team keys must be unique');
foreach (array_keys($divisionKeys) as $division) $ok(isset($byDivision[$division]) && count($byDivision[$division]) >= 2, "division {$division} must be composed into multiple practical teams");

foreach (['reception','booking','dispatch','quality','billing','receivables','fleet','inventory','procurement','compliance'] as $requiredKey) {
    $ok(in_array($requiredKey, $teamKeys, true), "required practical team {$requiredKey} missing");
}

$roles = json_decode((string) file_get_contents($root . '/resources/workforce/role-definitions.json'), true);
$roles = is_array($roles) ? $roles : [];
$teamIndex = [];
foreach ($teams as $team) $teamIndex[(string) $team['key']] = $team;
foreach ($roles as $role) {
    $roleKey = (string) ($role['key'] ?? '');
    $teamKey = (string) ($role['team_key'] ?? '');
    $divisionKey = (string) ($role['division_key'] ?? '');
    $ok(isset($teamIndex[$teamKey]), "role {$roleKey} references missing team {$teamKey}");
    if (isset($teamIndex[$teamKey])) $ok(($teamIndex[$teamKey]['division_key'] ?? null) === $divisionKey, "role {$roleKey} team {$teamKey} crosses division boundary");
    $ok(($role['team_definition_id'] ?? null) === 'titan.team.' . $teamKey, "role {$roleKey} missing canonical team_definition_id binding");
}

$migrationPath = $root . '/database/migrations/2026_08_21_000018_teams_department_composition.php';
$ok(is_file($migrationPath), 'Pass 8 team composition migration must exist');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
$ok(str_contains($migration, "Schema::create('ext_titan_ai_workforce_team_definitions'"), 'team definition table migration missing');
$ok(str_contains($migration, "'team_definition_id'"), 'stable team_definition_id missing');
$ok(str_contains($migration, 'team-definitions.json'), 'migration must seed from canonical team catalogue');
$ok(str_contains($migration, "Schema::hasColumn('ext_titan_ai_workforce_teams', 'team_definition_id')"), 'company team definition binding missing');
$ok(str_contains($migration, "Schema::hasColumn('ext_titan_ai_workforce_role_definitions', 'team_definition_id')"), 'role definition team binding missing');
$ok(! str_contains($migration, "DB::table('ext_titan_ai_workforce_teams')->insert"), 'Pass 8 must not auto-create company team instances');
$ok(! str_contains($migration, "DB::table('ext_titan_ai_workforce_members')->insert"), 'Pass 8 must not auto-create employee instances');

$catalogPath = $root . '/System/Support/IntrinsicTeamCatalog.php';
$catalog = is_file($catalogPath) ? (string) file_get_contents($catalogPath) : '';
$ok(is_file($catalogPath), 'IntrinsicTeamCatalog support contract missing');
$ok(str_contains($catalog, 'team-definitions.json'), 'IntrinsicTeamCatalog must read canonical team definitions');
$ok(str_contains($catalog, 'titan.team.'), 'IntrinsicTeamCatalog must expose stable team identities');

$modelPath = $root . '/System/Models/WorkforceTeamDefinition.php';
$ok(is_file($modelPath), 'WorkforceTeamDefinition model missing');
$teamModel = is_file($root . '/System/Models/WorkforceTeam.php') ? (string) file_get_contents($root . '/System/Models/WorkforceTeam.php') : '';
$ok(str_contains($teamModel, "'team_definition_id'"), 'WorkforceTeam instance must expose team_definition_id binding');

$bootstrapPath = $root . '/System/Services/WorkforceBootstrapService.php';
$bootstrap = is_file($bootstrapPath) ? (string) file_get_contents($bootstrapPath) : '';
$ok(str_contains($bootstrap, 'IntrinsicDivisionCatalog'), 'bootstrap must compose intrinsic divisions');
$ok(str_contains($bootstrap, 'IntrinsicTeamCatalog'), 'bootstrap must compose intrinsic teams');
$ok(str_contains($bootstrap, "'division_definition_id'"), 'bootstrap must bind company divisions to canonical definitions');
$ok(str_contains($bootstrap, "'team_definition_id'"), 'bootstrap must bind company teams to canonical definitions');
$ok(! str_contains($bootstrap, "WorkforceMember::query()->create"), 'Pass 8 bootstrap must not auto-hire employees');

if ($failures !== []) {
    fwrite(STDERR, "FAIL teams_department_composition_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS teams_department_composition_contract_test\n";
