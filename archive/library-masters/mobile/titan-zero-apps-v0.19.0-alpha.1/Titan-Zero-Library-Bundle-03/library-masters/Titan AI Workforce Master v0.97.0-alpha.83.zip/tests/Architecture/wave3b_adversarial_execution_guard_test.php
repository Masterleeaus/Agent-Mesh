<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$guard = file_get_contents($root.'/System/Services/WorkforceAdversarialExecutionGuard.php');
$exec = file_get_contents($root.'/System/Services/WorkforceExecutionService.php');

$checks = [
    'cross-company rejection' => str_contains($guard, 'CROSS_COMPANY_REFERENCE_REJECTED'),
    'governance bypass rejection' => str_contains($guard, 'CONTROL_PLANE_BYPASS_ATTEMPT_REJECTED'),
    'secret rejection' => str_contains($guard, 'SECRET_MATERIAL_IN_EXECUTION_ENVELOPE_REJECTED'),
    'stale delegation rejection' => str_contains($guard, 'EXPIRED_DELEGATION_REJECTED'),
    'forged approval rejection' => str_contains($guard, 'UNVERIFIED_APPROVAL_REJECTED'),
    'predictive loop rejection' => str_contains($guard, 'PREDICTIVE_SELF_TRIGGER_LOOP_BLOCKED'),
    'prompt/control-plane injection rejection' => str_contains($guard, 'UNTRUSTED_CONTROL_PLANE_INSTRUCTION_REJECTED'),
    'guard executes before standard governance' =>
        strpos($exec, '$this->adversarialGuard->assertSafe') !== false &&
        strpos($exec, '$this->adversarialGuard->assertSafe') < strpos($exec, '$this->titanZeroAuthorityGuard->assertStandardGovernancePath'),
];
$failed = array_keys(array_filter($checks, fn($ok) => !$ok));
if ($failed) { fwrite(STDERR, 'FAIL: '.implode(', ', $failed).PHP_EOL); exit(1); }
echo 'Wave 3B adversarial execution guard contract: PASS ('.count($checks).'/'.count($checks).')'.PHP_EOL;
