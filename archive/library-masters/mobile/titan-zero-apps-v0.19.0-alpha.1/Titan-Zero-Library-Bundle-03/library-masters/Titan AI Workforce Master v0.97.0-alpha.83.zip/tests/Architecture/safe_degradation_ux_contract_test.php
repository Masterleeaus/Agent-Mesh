<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceSafeDegradationService.php';
$viewPath = $root.'/resources/views/workforce/degradation/show.blade.php';
$badgePath = $root.'/resources/views/workforce/components/capability-health-badge.blade.php';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$team = @file_get_contents($root.'/resources/views/workforce/team/index.blade.php') ?: '';
$employee = @file_get_contents($root.'/resources/views/workforce/employee/show.blade.php') ?: '';
$inspector = @file_get_contents($root.'/resources/views/workforce/capabilities/index.blade.php') ?: '';
$dashboard = @file_get_contents($root.'/resources/views/workforce/dashboard/index.blade.php') ?: '';

foreach ([$servicePath,$viewPath,$badgePath] as $path) $need(is_file($path), 'Safe Degradation UX artifact missing: '.basename($path));
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';
$badge = @file_get_contents($badgePath) ?: '';

foreach (['Healthy','Degraded','Blocked','Missing Provider','Policy Disabled'] as $label) {
    $need(str_contains($badge, $label) || str_contains($service, $label), "missing visible degradation status {$label}");
}
foreach (['what_is_unavailable','what_still_works','affected_work','fallbacks','admin_actions','authority_inherited'] as $field) {
    $need(str_contains($service, "'{$field}'"), "degradation snapshot missing {$field}");
}
foreach (['What is unavailable?','What still works?','What work is affected?','Approved fallback','Required admin action'] as $label) {
    $need(str_contains($view, $label), "degradation detail missing {$label}");
}
$need(str_contains($service, 'forCompany($companyId)'), 'affected work must be company scoped');
$need(str_contains($service, 'WorkforceCapabilityAvailabilityService'), 'degradation must use live capability state');
$need(str_contains($service, "'fallback_authority_granted' => false"), 'fallback must not grant authority');
$need(str_contains($service, "'authority_inherited' => false"), 'degradation must not inherit authority');
$need(str_contains($provider, "degradation/{member}"), 'degradation detail route missing');
$need(str_contains($provider, "name('staff.degradation')"), 'named degradation detail route missing');
$need(str_contains($controller, 'safeDegradation'), 'controller degradation action missing');
foreach ([$team,$employee,$inspector,$dashboard] as $source) {
    $need(str_contains($source, 'capability-health-badge'), 'core Workforce surface missing shared degradation badge');
}
foreach ([$view,$team,$employee,$inspector,$dashboard] as $source) {
    $need(! str_contains(strtolower($source), 'agent unavailable'), 'vague "agent unavailable" message must never be rendered');
}

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Safe Degradation UX contract\n";
