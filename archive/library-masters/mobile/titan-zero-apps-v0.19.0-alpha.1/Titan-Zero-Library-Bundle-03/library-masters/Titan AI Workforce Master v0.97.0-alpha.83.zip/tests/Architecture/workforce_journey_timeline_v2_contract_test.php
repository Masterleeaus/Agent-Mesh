<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceJourneyTimelineService.php';
$viewPath = $root.'/resources/views/workforce/journey-timeline/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$taskView = @file_get_contents($root.'/resources/views/workforce/tasks/show.blade.php') ?: '';

$need(is_file($servicePath), 'Journey Timeline 2.0 service missing');
$need(is_file($viewPath), 'Journey Timeline 2.0 view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach (['business_title','business_summary','technical_details','actor_name','category','occurred_at'] as $field) {
    $need(str_contains($service, $field) || str_contains($view, $field), "timeline field missing {$field}");
}
$need(str_contains($service, 'WorkforceJourneyRecord::query()->forCompany($companyId)'), 'timeline journey lookup must be company scoped');
$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'timeline task lookup must be company scoped');
$need(str_contains($service, 'WorkforceMember::query()->forCompany($companyId)'), 'timeline employee lookup must be company scoped');
$need(str_contains($service, "'authority_inherited' => false"), 'timeline must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'timeline must not grant execution authority');
$need(str_contains($controller, 'journeyTimeline'), 'timeline controller action missing');
$need(str_contains($provider, "get('journey-timeline'"), 'timeline route missing');
$need(str_contains($nav, 'Journey Timeline'), 'timeline navigation item missing');
$need(str_contains($taskView, 'journey-timeline'), 'task detail must link to Journey Timeline 2.0');
$need(str_contains($view, '<details'), 'technical event detail must be expandable');
$need(str_contains($view, 'Technical detail'), 'timeline must label expanded technical detail');
$need(str_contains($view, 'Business timeline'), 'timeline must default to readable business language');
$need(str_contains($view, 'does not grant execution authority'), 'timeline must explain read-only authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Journey Timeline 2.0 contract\n";
