<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};
$reg=$json('resources/workforce/ecosystem-capability-registry.json');
if(count($reg['providers']??[])!==38)$fail('provider count');
$keys=array_map(fn($p)=>$p['extension']['key'],$reg['providers']);
foreach(['titan-omnichannel','titan-bookings-quotes'] as $k)if(!in_array($k,$keys,true))$fail("missing {$k}");
if(in_array('titan-interface-runtime',$keys,true))$fail('interface runtime must not be a Workforce business provider');
$ui=$json('resources/workforce/ui-capability-surface-policy.json');
if(($ui['composition_runtime']['extension']??null)!=='titan-interface-runtime')$fail('interface runtime composition binding');
if(($ui['composition_runtime']['workforce_provider']??null)!==false)$fail('interface runtime provider classification');
if(($ui['composition_runtime']['owns_business_authority']??null)!==false)$fail('interface runtime authority');
$profiles=$json('resources/workforce/context-federation-profiles.json');
if(($profiles['profile_count']??null)!==21)$fail('context profile count');
foreach(['titan-omnichannel','titan-bookings-quotes'] as $pk){
  $found=false;foreach($profiles['profiles'] as $p)if(($p['provider']??null)===$pk){$found=true;if(($p['tenant_boundary']??null)!=='company_id')$fail("tenant {$pk}");}
  if(!$found)$fail("profile {$pk}");
}
echo "PASS: Omnichannel Bookings Interface Runtime integration\n";
