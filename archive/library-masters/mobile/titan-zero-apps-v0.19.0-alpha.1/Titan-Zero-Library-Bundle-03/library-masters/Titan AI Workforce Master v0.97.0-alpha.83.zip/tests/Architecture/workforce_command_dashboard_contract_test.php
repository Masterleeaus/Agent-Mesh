<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = @file_get_contents($root.'/System/Services/WorkforceCommandDashboardService.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$view = @file_get_contents($root.'/resources/views/workforce/dashboard/index.blade.php') ?: '';
$assert = static function (bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } };

foreach (['WorkforceCapabilityAvailabilityService','WorkforceQueueHealthService','WorkforceOutcomeHealthService','WorkforceExecutionAttempt','WorkforceSchedule','WorkforceStaffingProposal','WorkforceTaskHistory'] as $needle) {
    $assert(str_contains($service, $needle), 'dashboard aggregation missing '.$needle);
}
foreach (['active','degraded','blocked','open','review','escalated','overdue_responsibilities','failures','recoveries','recommendations','needs_attention','recent_critical_events'] as $needle) {
    $assert(str_contains($service, "'{$needle}'"), 'dashboard snapshot missing '.$needle);
}
foreach (['authority','company_id','forCompany','provider_bindings'] as $needle) {
    $assert(str_contains($service, $needle), 'dashboard safety/tenancy invariant missing '.$needle);
}
$assert(str_contains($controller, 'WorkforceCommandDashboardService'), 'controller does not depend on dashboard service');
$assert(str_contains($controller, "'dashboard' => \$dashboard"), 'controller does not pass dashboard snapshot');
foreach (['Workforce health','Needs attention now','Capability-provider health','Manager queue pressure','Recent critical events','Outcome health','Overdue proactive','Execution failures','Recoveries','Staffing recommendations'] as $needle) {
    $assert(str_contains($view, $needle), 'dashboard UI missing '.$needle);
}
$assert(!str_contains($view, 'tenant'.'_company_id'), 'dashboard must not expose retired company boundary');

echo "PASS: Workforce Command Dashboard operational-home contract\n";
