<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$mustExist = [
    'System/Services/WorkforceResponsibilitiesCenterService.php',
    'System/Models/WorkforceResponsibilityOverride.php',
    'resources/views/workforce/responsibilities/index.blade.php',
    'database/migrations/2026_08_22_000021_responsibility_center_overrides.php',
];
foreach ($mustExist as $file) {
    if (! is_file($root.'/'.$file)) { fwrite(STDERR, "Missing {$file}\n"); exit(1); }
}
$service = file_get_contents($root.'/System/Services/WorkforceResponsibilitiesCenterService.php');
$view = file_get_contents($root.'/resources/views/workforce/responsibilities/index.blade.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$migration = file_get_contents($root.'/database/migrations/2026_08_22_000021_responsibility_center_overrides.php');
$nav = file_get_contents($root.'/System/Navigation/WorkforceNavigation.php');
$definitions = json_decode((string) file_get_contents($root.'/resources/workforce/responsibility-definitions.json'), true, 512, JSON_THROW_ON_ERROR);
if (count($definitions) !== 118) { fwrite(STDERR, "Expected 118 canonical responsibilities\n"); exit(1); }
foreach (['required_capabilities','provider_health','authority_requirements','recent_work','recent_outcomes','eligible_members'] as $needle) {
    if (! str_contains($service, $needle)) { fwrite(STDERR, "Missing service projection {$needle}\n"); exit(1); }
}
foreach (['Responsibilities Center','Required capabilities & provider health','Authority requirements','Recent work generated','Recent outcomes','Schedule JSON','Trigger conditions JSON'] as $needle) {
    if (! str_contains($view, $needle)) { fwrite(STDERR, "Missing UI contract {$needle}\n"); exit(1); }
}
foreach (["'responsibilities'", "'responsibilities.update'"] as $needle) {
    if (! str_contains($provider, $needle)) { fwrite(STDERR, "Missing route {$needle}\n"); exit(1); }
}
if (! str_contains($nav, 'titan_workforce_responsibilities')) { fwrite(STDERR, "Responsibilities navigation missing\n"); exit(1); }
foreach (['company_id','responsibility_id','assigned_member_id','is_enabled','schedule','trigger_conditions'] as $needle) {
    if (! str_contains($migration, $needle)) { fwrite(STDERR, "Override migration missing {$needle}\n"); exit(1); }
}
foreach (['authority_inherited' => false, 'execution_authority_granted' => false] as $needle => $unused) {}
if (! str_contains($service, "'authority_inherited' => false") || ! str_contains($service, "'execution_authority_granted' => false")) {
    fwrite(STDERR, "Authority non-inheritance invariant missing\n"); exit(1);
}
if (! str_contains($service, 'forCompany($companyId)')) { fwrite(STDERR, "company_id scope missing\n"); exit(1); }
if (! str_contains($service, 'allowed canonical owner role')) { fwrite(STDERR, "Role-constrained reassignment guard missing\n"); exit(1); }
echo "RESPONSIBILITIES_CENTER_CONTRACT: PASS\n";
