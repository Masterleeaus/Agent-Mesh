<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceNotificationRoutingService.php';
$modelPath = $root.'/System/Models/WorkforceNotification.php';
$preferencePath = $root.'/System/Models/WorkforceNotificationPreference.php';
$viewPath = $root.'/resources/views/workforce/notifications/index.blade.php';
$migrationPath = $root.'/database/migrations/2026_08_22_000022_workforce_notification_routing.php';
$commandPath = $root.'/System/Console/Commands/RouteWorkforceNotificationsCommand.php';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

foreach ([$servicePath,$modelPath,$preferencePath,$viewPath,$migrationPath,$commandPath] as $file) $need(is_file($file), 'missing notification routing artifact: '.basename($file));
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';
$migration = @file_get_contents($migrationPath) ?: '';
$command = @file_get_contents($commandPath) ?: '';

foreach (['owner_admin','responsible_manager','specific_team','in_app'] as $token) $need(str_contains($service, $token), "routing service missing {$token}");
foreach (['severity_threshold','dedupe_key','acknowledged_at','acknowledged_by'] as $token) $need(str_contains($migration, $token) || str_contains($service, $token), "notification routing missing {$token}");
$need(str_contains($service, 'WorkforceAttentionCenterService'), 'notification routing must project from authoritative Attention Center conditions');
$need(str_contains($service, 'forCompany($companyId)'), 'notification routing must be company scoped');
$need(str_contains($service, "'authority_inherited' => false"), 'notifications must not inherit authority');
$need(str_contains($service, 'updateOrCreate') || str_contains($service, 'firstOrCreate'), 'deduplication must persist stable notification identity');
$need(str_contains($controller, 'notificationsCenter'), 'notification center controller action missing');
$need(str_contains($controller, 'acknowledgeNotification'), 'notification acknowledgement controller action missing');
$need(str_contains($controller, 'updateNotificationPreferences'), 'notification threshold settings action missing');
$need(str_contains($provider, "get('notifications'"), 'notification center route missing');
$need(str_contains($provider, "post('notifications/{notification}/acknowledge'"), 'notification acknowledgement route missing');
$need(str_contains($provider, "post('notifications/preferences'"), 'notification preferences route missing');
$need(str_contains($provider, 'titan-workforce:route-notifications'), 'scheduled notification routing command missing');
$need(str_contains($command, 'WorkforceNotificationRoutingService'), 'notification routing command must use routing service');
$need(str_contains($nav, 'Notifications'), 'notification navigation item missing');
foreach (['Owner / admin','Responsible manager','Specific team','Severity threshold','Acknowledge','Deduplicated'] as $label) $need(str_contains($view, $label), "notification UI missing {$label}");
$need(! str_contains(strtolower($view), 'notification grants authority'), 'notification UI must not imply authority');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Notifications & Alert Routing contract\n";
