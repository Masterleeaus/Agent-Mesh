<?php

declare(strict_types=1);

namespace Illuminate\Contracts\Container {
    interface Container {
        public function getBindings();
        public function make($abstract);
    }
}

namespace {
    require_once __DIR__ . '/../../System/Support/WorkforceManifestNormalizer.php';
    require_once __DIR__ . '/../../System/Support/WorkforceProactiveIdentity.php';
    require_once __DIR__ . '/../../System/Support/WorkforceManifestValidator.php';
    require_once __DIR__ . '/../../System/Support/WorkforceManifestRegistry.php';

    use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestNormalizer;
    use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
    use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestValidator;
    use Illuminate\Contracts\Container\Container;

    function fail_v2(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
    function ok_v2(bool $condition, string $message): void { if (! $condition) fail_v2($message); }

    final class FakeManifestContainer implements Container
    {
        public function __construct(private array $bindings = []) {}
        public function getBindings(): array { return array_fill_keys(array_keys($this->bindings), []); }
        public function make($abstract): mixed { return $this->bindings[$abstract] ?? throw new RuntimeException('missing binding'); }
    }

    function v2_manifest(string $key = 'example-domain', string $roleId = 'titan.example.manager'): array
    {
        return [
            'schema_version' => '2.0',
            'extension' => ['key' => $key, 'version' => '2.4.1'],
            'ownership' => ['source_of_truth' => 'extension', 'central_workforce_owns_definitions' => false, 'auto_seed_staff' => false],
            'runtime' => [
                'manifest_provider' => 'Example\\ManifestProvider', 'execution_context' => 'Example\\ExecutionContext',
                'tool_registry' => 'Example\\ToolRegistry', 'command_bus_port' => 'Example\\CommandBusPort',
                'risk_port' => 'Example\\RiskPort', 'assurance_port' => 'Example\\AssurancePort',
                'autonomy_port' => 'Example\\AutonomyPort', 'workforce_task_port' => 'Example\\WorkforceTaskPort',
                'workflow_router' => 'Example\\WorkflowRouter', 'wizard_registry' => 'Example\\WizardRegistry',
                'fail_closed' => true, 'execution_receipt_required' => true,
            ],
            'divisions' => [['id' => 'example', 'name' => 'Example']],
            'teams' => [['id' => 'example.ops', 'division_id' => 'example', 'name' => 'Operations']],
            'roles' => [[
                'role_id' => $roleId, 'name' => 'Example Manager', 'tier' => 1,
                'division_id' => 'example', 'team_id' => 'example.ops', 'reports_to' => null,
                'manages' => [], 'escalates_to' => 'titan.ops.manager', 'purpose' => 'Coordinate governed example work.',
                'responsibilities' => ['review work'], 'capabilities' => ['example.read'],
                'skills' => ['example.operations'], 'tools' => ['example.read'],
                'playbooks' => ['example.manager'], 'workflows' => ['example.standard'], 'wizards' => ['example.standard'],
                'risk_ceiling' => 'LOW',
                'autonomy' => [
                    'desired' => ['score' => 16, 'band' => 'Assist'],
                    'initial_earned_ceiling' => ['score' => 16, 'band' => 'Assist'],
                    'effective_authority' => ['source' => 'titan_autonomy', 'decision_contract' => 'schemas/autonomy-decision.schema.json', 'mutable_by_extension' => false],
                    'predictive_readiness' => ['source' => 'titan_autonomy', 'decision_contract' => 'schemas/autonomy-decision.schema.json', 'grants_mutation_authority' => false],
                    'capability_authority_refs' => [['capability' => 'example.read', 'variant' => 'standard', 'authority_source' => 'titan_autonomy']],
                ],
                'maturity' => ['default' => 'JUNIOR', 'levels' => ['JUNIOR','STANDARD','SENIOR','LEAD'], 'promotion_mode' => 'recommend_only'],
                'status' => 'available_definition',
            ]],
            'relationships' => [],
            'capabilities' => [[
                'name' => 'example.read', 'owner' => $key,
                'input_contract' => 'contracts/example/read.input.json', 'output_contract' => 'contracts/example/read.output.json',
                'risk_profile' => 'MINIMAL',
                'autonomy_requirement' => ['minimum_score' => 16, 'minimum_band' => 'Assist', 'variant' => 'standard', 'authority_source' => 'titan_autonomy'],
                'evidence_requirements' => [], 'offline_policy' => 'OFFLINE_PREPARE_ONLY',
                'reversibility' => 'reversible', 'idempotency_strategy' => 'read-only', 'mutation_mode' => 'read_only',
            ]],
            'tools' => [['id' => 'example.read', 'capability' => 'example.read', 'writes_state' => false, 'execution' => 'local_read']],
            'skills' => [['id' => 'example.operations', 'name' => 'Example Operations']],
            'playbooks' => [['id' => 'example.manager', 'name' => 'Manager', 'version' => '1.0']],
            'workflows' => [['id' => 'example.standard', 'interaction_workflow' => 'example.standard']],
            'wizards' => [['id' => 'example.standard', 'workflow' => 'example.standard']],
            'proactive' => [
                'schedules' => [['id' => 'example.daily-review', 'role_id' => $roleId, 'frequency' => 'weekday 08:00', 'creates' => 'workforce_task']],
                'signals' => [['event' => 'example.attention_required', 'role_id' => $roleId, 'creates' => 'workforce_task']],
                'auto_execute_business_mutations' => false,
            ],
            'raci' => [],
            'governance' => [
                'risk' => 'external_titan_engine', 'assurance' => 'external_titan_engine', 'autonomy' => 'external_titan_engine',
                'signal' => 'external_titan_engine', 'command_bus' => 'external_titan_engine', 'rewind' => 'external_titan_engine',
                'wisdom' => 'external_titan_engine', 'knowledge_authority' => 'external_titan_engine', 'shield' => 'external_titan_engine',
                'self_approval' => false, 'direct_domain_writes' => false,
                'trace_fields' => ['trace_id','correlation_id','causation_id','company_id'],
                'deadlock_states' => ['RETRY_WITH_EVIDENCE','RETURN_TO_MAKER','ESCALATE_TO_PARENT','ESCALATE_TO_TITAN','HUMAN_DECISION_REQUIRED'],
            ],
            'offline' => ['authority_may_increase' => false, 'default_policy' => 'OFFLINE_PREPARE_ONLY'],
            'workforce_planning' => ['enabled' => true, 'auto_activate' => false, 'signals' => ['queue_depth'], 'approval_required' => true],
        ];
    }

    $root = dirname(__DIR__, 2);
    $sidecar = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
    ok_v2(($sidecar['workforce']['discovery_contract'] ?? null) === 'titan.workforce.manifest.v2', 'sidecar must declare Workforce Manifest 2.0 discovery');
    ok_v2(in_array('titan-workforce.manifest-health', $sidecar['capabilities'] ?? [], true), 'sidecar must expose manifest-health capability');

    $providerSource = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
    ok_v2(str_contains($providerSource, "'titan.workforce.manifest-health'"), 'stable manifest-health adapter missing');
    ok_v2(str_contains($providerSource, "api/manifest-health"), 'manifest-health API route missing');
    $catalogSource = (string) file_get_contents($root . '/System/Support/WorkforceCapabilityCatalog.php');
    ok_v2(str_contains($catalogSource, "workforce.manifest-health.read"), 'manifest-health capability contract missing');

    ok_v2(is_file($root . '/resources/workforce/workforce-manifest.schema.json'), 'canonical v2 schema missing');
    ok_v2(is_file($root . '/resources/workforce/workforce-manifest-v1.1.schema.json'), 'legacy v1.1 schema missing');
    $schema = json_decode((string) file_get_contents($root . '/resources/workforce/workforce-manifest.schema.json'), true, flags: JSON_THROW_ON_ERROR);
    ok_v2(($schema['properties']['schema_version']['const'] ?? null) === '2.0', 'canonical schema must be Workforce Manifest 2.0');

    $canonical = v2_manifest();
    WorkforceManifestValidator::assertValid($canonical);
    ok_v2(WorkforceManifestNormalizer::normalize($canonical)['schema_version'] === '2.0', 'v2 manifest must remain canonical');

    $legacy = $canonical;
    $legacy['schema_version'] = '1.1';
    foreach ($legacy['roles'] as &$role) {
        $role['initial_autonomy'] = 'Trusted Auto';
        unset($role['autonomy']);
    }
    unset($role);
    foreach ($legacy['capabilities'] as &$capability) $capability['autonomy_requirement'] = 'Trusted Auto';
    unset($capability);
    $normalised = WorkforceManifestNormalizer::normalize($legacy);
    ok_v2(($normalised['schema_version'] ?? null) === '2.0', 'legacy manifest must normalise to 2.0');
    ok_v2(($normalised['roles'][0]['autonomy']['desired']['score'] ?? null) === 71, 'Trusted Auto migration must use band floor 71');
    ok_v2(($normalised['roles'][0]['autonomy']['initial_earned_ceiling']['score'] ?? null) === 71, 'legacy migration must not mint authority above the band floor');
    ok_v2(($normalised['capabilities'][0]['autonomy_requirement']['minimum_score'] ?? null) === 71, 'capability autonomy migration must use band floor 71');
    WorkforceManifestValidator::assertValid($normalised);

    $legacyRegistry = new WorkforceManifestRegistry(new FakeManifestContainer());
    $legacyRegistry->registerManifest($legacy, 80);
    $legacyRoles = $legacyRegistry->roles();
    ok_v2(count($legacyRoles) === 1, 'legacy 1.1 contributor must remain discoverable after normalisation');
    $legacyHealth = $legacyRegistry->health();
    ok_v2(($legacyHealth['example-domain']['status'] ?? null) === 'LEGACY_NORMALIZED', 'legacy contributor must be visibly marked LEGACY_NORMALIZED');
    ok_v2(($legacyRoles[0]['definition_source_schema_version'] ?? null) === '1.1', 'legacy role provenance must retain source schema version');

    $unsupported = $legacy;
    $unsupported['schema_version'] = '1.0';
    $rejected = false;
    try { WorkforceManifestNormalizer::normalize($unsupported); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'schema 1.0 must not be silently treated as canonical/legacy 1.1');

    $badRef = $canonical;
    $badRef['roles'][0]['tools'][] = 'example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badRef); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown role tool references must be rejected');

    $badBand = $canonical;
    $badBand['roles'][0]['autonomy']['desired'] = ['score' => 71, 'band' => 'Assist'];
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badBand); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'score/band mismatch must be rejected');

    $badTeam = $canonical;
    $badTeam['roles'][0]['team_id'] = 'example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badTeam); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown team references must be rejected');

    $badManager = $canonical;
    $badManager['roles'][0]['reports_to'] = 'titan.example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badManager); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown reports_to manager references must be rejected');

    $badCapability = $canonical;
    $badCapability['roles'][0]['capabilities'][] = 'example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badCapability); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown role capability references must be rejected');

    $badWorkflow = $canonical;
    $badWorkflow['roles'][0]['workflows'][] = 'example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badWorkflow); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown role workflow references must be rejected');

    $badSchedule = $canonical;
    $badSchedule['proactive']['schedules'][0]['role_id'] = 'titan.example.missing';
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badSchedule); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown proactive schedule role references must be rejected');

    $validRaci = $canonical;
    $validRaci['raci'] = [[
        'decision' => 'example.standard_change',
        'responsible' => ['titan.example.manager'],
        'accountable' => ['titan.example.manager'],
        'consulted' => [],
        'informed' => ['titan.ops.manager'],
    ]];
    WorkforceManifestValidator::assertValid($validRaci);

    $badRaci = $validRaci;
    $badRaci['raci'][0]['responsible'] = ['titan.example.missing'];
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badRaci); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'unknown responsible RACI roles must be rejected');

    $badRaci = $validRaci;
    $badRaci['raci'][0]['accountable'] = ['titan.example.manager','titan.example.manager'];
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($badRaci); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'RACI must have exactly one accountable role');

    $cycle = $canonical;
    $second = $cycle['roles'][0];
    $second['role_id'] = 'titan.example.manager2';
    $second['name'] = 'Example Manager 2';
    $second['reports_to'] = 'titan.example.manager';
    $cycle['roles'][0]['reports_to'] = 'titan.example.manager2';
    $cycle['roles'][] = $second;
    $rejected = false;
    try { WorkforceManifestValidator::assertValid($cycle); } catch (RuntimeException) { $rejected = true; }
    ok_v2($rejected, 'manifest reporting cycles must be rejected');

    $registry = new WorkforceManifestRegistry(new FakeManifestContainer());
    $registry->registerManifest($canonical, 100);
    $invalid = v2_manifest('broken-domain', 'titan.broken.manager');
    $invalid['roles'][0]['tools'][] = 'broken.missing';
    $registry->register('broken-domain', $invalid, 90);
    $all = $registry->all();
    ok_v2(isset($all['example-domain']), 'valid contributor must remain discoverable');
    ok_v2(! isset($all['broken-domain']), 'invalid contributor must be quarantined rather than activatable');
    $health = $registry->health();
    ok_v2(($health['example-domain']['status'] ?? null) === 'HEALTHY', 'canonical contributor health must be HEALTHY');
    ok_v2(($health['broken-domain']['status'] ?? null) === 'QUARANTINED', 'invalid contributor must expose QUARANTINED health');

    $routines = $registry->explicitRoutinesForRole('titan.example.manager');
    ok_v2(count($routines) === 2, 'v2 proactive schedules/signals must be discoverable for the role');
    ok_v2(($routines[0]['trigger_type'] ?? null) === 'schedule', 'v2 schedule must map to central schedule trigger');
    ok_v2(($routines[0]['schedule']['frequency'] ?? null) === 'weekdays', 'weekday schedule must normalise without changing cadence');
    ok_v2(($routines[1]['trigger_type'] ?? null) === 'event', 'v2 Signal trigger must map to central event trigger');
    ok_v2(($routines[1]['event_type'] ?? null) === 'example.attention_required', 'Signal event type must be preserved');

    $role = $registry->findRole('titan.example.manager');
    ok_v2(($role['owner_extension'] ?? null) === 'example-domain', 'role owner provenance missing');
    ok_v2(($role['owner_extension_version'] ?? null) === '2.4.1', 'role owner version provenance missing');
    ok_v2(($role['definition_version'] ?? null) === '2.4.1', 'role definition version missing');
    ok_v2(strlen((string) ($role['definition_fingerprint'] ?? '')) === 64, 'role definition fingerprint missing');

    $raciRegistry = new WorkforceManifestRegistry(new FakeManifestContainer());
    $raciRegistry->registerManifest($validRaci, 100);
    $rights = $raciRegistry->decisionRights();
    ok_v2(count($rights) === 1, 'extension-owned RACI must be discoverable from central registry');
    ok_v2(($rights[0]['owner_extension'] ?? null) === 'example-domain', 'RACI owner extension provenance missing');
    ok_v2(($raciRegistry->findDecisionRight('example.standard_change','example-domain')['accountable'][0] ?? null) === 'titan.example.manager', 'exact owner+decision RACI lookup failed');

    echo "PASS: Titan AI Workforce Manifest 2.0 registry and legacy normalisation contract\n";
}
