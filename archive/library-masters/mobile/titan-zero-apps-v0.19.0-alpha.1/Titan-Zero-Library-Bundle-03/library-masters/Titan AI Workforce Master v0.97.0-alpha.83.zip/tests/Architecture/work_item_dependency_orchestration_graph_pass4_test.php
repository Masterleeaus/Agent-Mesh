<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid JSON {$r}");return$d;};

$c=$json('resources/workforce/work-item-orchestration-graph.json');
if(($c['tenant_key']??null)!=='company_id')$fail('tenant key');
if(($c['dependency_types']??[])!==['finish_to_start','finish_to_finish','start_to_start','start_to_finish'])$fail('dependency types');
if(($c['failure_policies']??[])!==['block','continue','escalate','compensate'])$fail('failure policies');
foreach(['same_goal_dependencies_required','cycle_detection_required','critical_path_calculated','parallel_groups_supported','sequence_index_supported','start_gate_separate_from_completion_gate','ready_dependents_auto_dispatched'] as $key){
    if(($c['graph'][$key]??null)!==true)$fail("graph {$key}");
}
foreach(['max_attempts_per_work_item','retry_strategy_supported','compensation_capability_supported','failure_propagation_supported','state_machine_failure_propagation_safe'] as $key){
    if(($c['reliability'][$key]??null)!==true)$fail("reliability {$key}");
}
foreach(['cross_company_dependencies_allowed','cross_goal_dependencies_allowed','dependency_grants_authority','compensation_grants_authority','graph_grants_execution_authority'] as $key){
    if(($c['safety'][$key]??null)!==false)$fail("safety {$key}");
}

$s=$read('System/Services/WorkforceWorkItemOrchestrationGraphService.php');
foreach([
    'addDependency','recalculateGoal','dispatchReady','propagateFailure','criticalPath','retryable',
    'Work Item dependency must remain inside the same business Goal.',
    'failure_policy',
    'compensation_required',
    'safeGraphTransition',
    "'authority_inherited' => false",
    "'execution_authority_granted' => false",
] as $needle){
    if(!str_contains($s,$needle))$fail("graph service missing {$needle}");
}
if(str_contains($s,'tenant'.'_company_id'))$fail('graph service uses legacy tenant key');

$d=$read('System/Services/WorkforceDependencyService.php');
foreach(['readyForStart','readyForCompletion','finish_to_start','start_to_start','finish_to_finish','start_to_finish','conditionSatisfied','DEPENDENCY_CYCLE'] as $needle){
    if(!str_contains($d,$needle))$fail("dependency semantics missing {$needle}");
}

$t=$read('System/Services/WorkforceTaskService.php');
if(!str_contains($t,'readyForCompletion($task)'))$fail('completion dependency gate missing');
if(!str_contains($t,'Canonical Work Item cannot complete before completion-gated dependencies are satisfied.'))$fail('completion gate message missing');
if(!str_contains($t,'WorkforceTaskStatus::Processing, WorkforceTaskStatus::Executing, WorkforceTaskStatus::Completed'))$fail('start-dependent dispatch missing');

$job=$read('System/Jobs/ProcessWorkforceTaskJob.php');
if(!str_contains($job,'WorkforceWorkItemOrchestrationGraphService $orchestration'))$fail('job graph injection missing');
if(!str_contains($job,'$orchestration->propagateFailure'))$fail('job failure propagation missing');

$m=$read('database/migrations/2026_08_22_000027_workforce_work_item_orchestration_graph.php');
foreach(['dependency_type','failure_policy','condition','orchestration_group','sequence_index','estimated_minutes','max_attempts','retry_strategy','compensation_capability','critical_path','blocked_by_graph'] as $needle){
    if(!str_contains($m,$needle))$fail("orchestration migration missing {$needle}");
}
if(str_contains($m,'tenant'.'_company_id'))$fail('orchestration migration uses legacy tenant key');

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
if(!str_contains($sp,'WorkforceWorkItemOrchestrationGraphService::class'))$fail('graph service not registered');
if(!str_contains($sp,"'titan.workforce.work-item-graph'"))$fail('graph alias missing');

echo "PASS: Work Item dependency and orchestration graph contract\n";
