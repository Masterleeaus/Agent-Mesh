<?php
declare(strict_types=1);
$root=dirname(__DIR__,2); $fail=[];
$check=function(string $file,array $need)use($root,&$fail){$s=file_get_contents($root.'/'.$file);foreach($need as $n)if(strpos($s,$n)===false)$fail[]=$file.':'.$n;};
$check('System/Services/KnowledgeAuthorityPreflightService.php',['freshness_state','contradiction_claim_keys','context_sufficient','receipt_hash']);
$check('System/Services/WorkforcePreExecutionGovernanceService.php',['independentReviewPolicy','KNOWLEDGE_CONTRADICTION_REQUIRES_RESOLUTION','STALE_KNOWLEDGE_BLOCKS_HIGH_RISK_EXECUTION','model_council_required','originating_agent_may_self_certify']);
$check('System/Services/WorkforceGovernanceBridge.php',['knowledge_context_receipt_id','provenance_refs','independent_review']);
$policy=json_decode(file_get_contents($root.'/resources/workforce/mandatory-intelligence-preflight.json'),true); if(($policy['tenant_key']??null)!=='company_id')$fail[]='tenant';
if($fail){fwrite(STDERR,implode("\n",$fail)."\n");exit(1);} echo "PASS wave2d mandatory intelligence preflight\n";
