<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$files=[
 'System/Services/WorkforceSetupWizardService.php',
 'resources/views/workforce/setup/index.blade.php',
];
foreach($files as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing {$f}\n");exit(1);}}
$s=file_get_contents($root.'/System/Services/WorkforceSetupWizardService.php');
$p=file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$c=file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$v=file_get_contents($root.'/resources/views/workforce/setup/index.blade.php');
foreach(['business_profile','recommended_structure','recommended_roles','provider_readiness','responsibility_coverage','review_before_apply','approval_required','authority_inherited','execution_authority_granted'] as $n){
 if(strpos($s,$n)===false){fwrite(STDERR,"Missing {$n}\n");exit(1);}
}
if(strpos($p,"setup")===false||strpos($c,"workforceSetup")===false||strpos($c,"applyWorkforceSetup")===false){fwrite(STDERR,"Setup routes/actions missing\n");exit(1);}
foreach(['Business profile','Recommended structure','Provider readiness','Review before apply'] as $n){if(strpos($v,$n)===false){fwrite(STDERR,"View missing {$n}\n");exit(1);}}
echo "workforce_setup_wizard_contract_test: PASS\n";
