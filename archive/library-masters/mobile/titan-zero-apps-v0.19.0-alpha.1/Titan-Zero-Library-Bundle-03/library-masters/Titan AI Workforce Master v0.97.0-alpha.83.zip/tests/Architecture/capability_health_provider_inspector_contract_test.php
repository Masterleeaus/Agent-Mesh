<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };
$service = @file_get_contents($root.'/System/Services/WorkforceCapabilityHealthInspectorService.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$view = @file_get_contents($root.'/resources/views/workforce/capabilities/index.blade.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

foreach (['WorkforceCapabilityHealthInspectorService','forCompany($companyId)','installedContributions','manifestHealth','expected_providers','available_providers','degraded_capabilities','policy_disabled_capabilities','fallback_eligibility','fallback_authority_granted','authority_inherited'] as $needle) {
    $need(str_contains($service, $needle), "capability inspector service missing {$needle}");
}
foreach (['providers','roles','employees','capabilities','tools','commands','signals','data_sources','workflows'] as $tab) {
    $need(str_contains($controller, "'{$tab}'"), "controller missing inspector view {$tab}");
}
foreach (['installed','active','degraded','missing','quarantined','roles','employees_affected','capability_count'] as $field) {
    $need(str_contains($service, "'{$field}'"), "provider inspector missing {$field}");
}
foreach (['Expected providers','Currently available','Degraded capabilities','Policy-disabled','Fallback eligibility','Safety boundary'] as $label) {
    $need(str_contains($view, $label), "employee/provider inspector UI missing {$label}");
}
$need(str_contains($provider, "get('capability-health'"), 'capability health route missing');
$need(str_contains($provider, "name('capability-health')"), 'capability health named route missing');
$need(str_contains($nav, "'Capability Health'"), 'Capability Health navigation entry missing');
$need(str_contains($service, "'fallback_authority_granted' => false"), 'fallback eligibility must never grant authority');
$need(str_contains($service, "'authority_inherited' => false"), 'inspector must preserve no-authority-inheritance invariant');
$need(str_contains($view, 'They never grant authority'), 'UI must explicitly distinguish availability/fallback from authority');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: capability health and provider inspector contract\n";
