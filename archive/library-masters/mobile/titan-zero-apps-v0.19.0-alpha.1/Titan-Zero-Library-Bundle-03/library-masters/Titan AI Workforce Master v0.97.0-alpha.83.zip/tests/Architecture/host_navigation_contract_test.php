<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$navigationPath = $root.'/System/Navigation/WorkforceNavigation.php';
$registrarPath = $root.'/System/Navigation/HostNavigationRegistrar.php';
$commandPath = $root.'/System/Console/Commands/SyncWorkforceMenuCommand.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';

$assert(is_file($navigationPath), 'missing WorkforceNavigation');
$assert(is_file($registrarPath), 'missing HostNavigationRegistrar');
$assert(is_file($commandPath), 'missing titan-workforce host menu sync command');

if (is_file($navigationPath)) {
    require_once $navigationPath;
    $class = 'App\\Extensions\\TitanAIWorkforce\\System\\Navigation\\WorkforceNavigation';
    $assert(class_exists($class), 'WorkforceNavigation class does not resolve');
    if (class_exists($class)) {
        $items = $class::user();
        $assert(count($items) === 23, 'AI Workforce must expose one parent and twenty-two children');
        $keys = [];
        $routes = [];
        $parent = null;
        foreach ($items as $item) {
            $key = (string) ($item['key'] ?? '');
            $assert($key !== '', 'navigation item missing key');
            $assert(! isset($keys[$key]), "duplicate navigation key {$key}");
            $keys[$key] = true;
            $routes[] = (string) ($item['route'] ?? '');
            $assert(array_key_exists('extension', $item) && $item['extension'] === null, "{$key} must not be MagicAI plan-feature gated");
            $assert(($item['is_admin'] ?? null) === false, "{$key} must be user navigation");
            if (($item['parent_key'] ?? null) === null) {
                $assert($parent === null, 'more than one root AI Workforce navigation item');
                $parent = $item;
            } else {
                $assert(($item['parent_key'] ?? null) === 'titan_workforce', "{$key} must be child of titan_workforce");
            }
        }
        $assert(($parent['key'] ?? null) === 'titan_workforce', 'AI Workforce parent key must be titan_workforce');
        $assert(($parent['type'] ?? null) === 'dropdown', 'AI Workforce parent must be a dropdown');
        foreach ([
            'dashboard.user.titan-workforce.index',
            'dashboard.user.titan-workforce.team',
            'dashboard.user.titan-workforce.tasks',
            'dashboard.user.titan-workforce.responsibilities',
            'dashboard.user.titan-workforce.proactive-operations',
            'dashboard.user.titan-workforce.capability-health',
            'dashboard.user.titan-workforce.attention',
            'dashboard.user.titan-workforce.notifications',
            'dashboard.user.titan-workforce.decision-rights-center',
            'dashboard.user.titan-workforce.delegations',
            'dashboard.user.titan-workforce.escalations',
            'dashboard.user.titan-workforce.councils',
            'dashboard.user.titan-workforce.governance-pipeline',
            'dashboard.user.titan-workforce.execution-evidence',
            'dashboard.user.titan-workforce.journey-timeline',
            'dashboard.user.titan-workforce.outcome-intelligence',
            'dashboard.user.titan-workforce.conversation',
            'dashboard.user.titan-workforce.calendar',
            'dashboard.user.titan-workforce.control-room',
            'dashboard.user.titan-workforce.planning',
            'dashboard.user.titan-workforce.analytics',
            'dashboard.user.titan-workforce.create',
        ] as $route) {
            $assert(in_array($route, $routes, true), "missing navigation route {$route}");
        }
    }
}

$registrar = @file_get_contents($registrarPath) ?: '';
foreach ([
    'MenuContributionRegistry', 'ContributionRegistry', 'Schema::hasTable', "'menus'",
    "'parent_id'", "'id'", 'getColumnListing', 'MenuService', 'regenerate',
    'preserve', 'syncHostMenu', 'parent_key', "'extension' => null",
] as $needle) {
    $assert(str_contains($registrar, $needle), "menu registrar missing host compatibility behavior: {$needle}");
}
$assert(str_contains($registrar, "unset(\$payload['order']"), 'menu self-heal must preserve administrator order');
$assert(str_contains($registrar, "unset(\$payload['is_active']"), 'menu self-heal must preserve administrator enabled/disabled state');
$assert(str_contains($registrar, "where('key', \$parentKey)"), 'child rows must resolve the real parent database row by key');
$assert(str_contains($registrar, 'duplicate host menu keys'), 'menu registrar must detect duplicate host menu keys');
$assert(str_contains($registrar, "where('id', (int)"), 'duplicate-safe repair must update only the canonical row by id');

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, 'SyncWorkforceMenuCommand'), 'provider does not register the host-sync command');
$assert(str_contains($provider, 'syncHostMenu'), 'provider does not self-heal host menu rows at boot');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce parent/child host navigation contract\n";
