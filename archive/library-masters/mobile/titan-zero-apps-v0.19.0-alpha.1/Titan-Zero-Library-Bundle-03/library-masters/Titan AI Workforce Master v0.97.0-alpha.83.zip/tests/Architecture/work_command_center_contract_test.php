<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = file_get_contents($root.'/System/Services/WorkforceWorkCommandCenterService.php');
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$index = file_get_contents($root.'/resources/views/workforce/tasks/index.blade.php');
$show = file_get_contents($root.'/resources/views/workforce/tasks/show.blade.php');

$needles = [
    [$service, 'forCompany($companyId)', 'command center must remain company_id scoped'],
    [$service, "'authority_inherited' => false", 'work projections must not grant authority'],
    [$service, 'WorkforceTaskDependency::query()->forCompany($companyId)', 'dependency graph must be company scoped'],
    [$service, 'WorkforceEvidence::query()->forCompany($companyId)', 'evidence must be company scoped'],
    [$service, 'WorkforceOutcome::query()->forCompany($companyId)', 'outcomes must be company scoped'],
    [$controller, 'WorkforceWorkCommandCenterService $workCommandCenter', 'controller must consume command center service'],
    [$controller, 'public function task(WorkforceTask $task)', 'task detail action required'],
    [$provider, "name('tasks.show')", 'task detail route required'],
    [$index, "'kanban'=>'Kanban'", 'Kanban view required'],
    [$index, "'timeline'=>'Timeline'", 'Timeline view required'],
    [$index, "'dependencies'=>'Dependency graph'", 'Dependency graph view required'],
    [$index, "'review'=>'Manager review'", 'Manager review view required'],
    [$index, "'handoffs'=>'Handoff queue'", 'Handoff queue view required'],
    [$index, "'escalations'=>'Escalations'", 'Escalations view required'],
    [$index, "'recovery'=>'Recovery'", 'Recovery view required'],
    [$show, 'Hierarchy & dependencies', 'task hierarchy surface required'],
    [$show, 'Capability requirements & governance state', 'capability/governance surface required'],
    [$show, 'Evidence & reviews', 'evidence/review surface required'],
    [$show, 'Execution attempts & receipts', 'attempt/receipt surface required'],
    [$show, 'Outcome', 'outcome surface required'],
    [$show, 'Journey trace', 'journey surface required'],
    [$show, 'History', 'history surface required'],
    [$show, "dashboard.user.titan-workforce.staff.show", 'owner/manager must drill into Employee 360'],
];
foreach ($needles as [$haystack,$needle,$message]) {
    if (! str_contains($haystack, $needle)) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}
echo "PASS: Work Command Center contract\n";
