<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforcePlanningIntelligenceService.php';
$viewPath = $root.'/resources/views/workforce/planning/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$navigation = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

$need(is_file($servicePath), 'Workforce Planning 2.0 intelligence service missing');
$need(is_file($viewPath), 'Workforce Planning 2.0 view missing');
foreach (['overloaded_teams','underused_staff','responsibility_gaps','capability_gaps','manager_span','bottlenecks','upcoming_workload','proposed_roles','expected_benefit','provider_requirements'] as $needle) {
    $need(str_contains($service, "'{$needle}'") || str_contains(strtolower($view), str_replace('_',' ', $needle)), "planning signal missing {$needle}");
}
$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'planning tasks must be company scoped');
$need(str_contains($service, 'WorkforceMember::query()->forCompany($companyId)'), 'planning members must be company scoped');
$need(str_contains($service, 'WorkforceStaffingProposal::query()->forCompany($companyId)'), 'staffing proposals must be company scoped');
$need(str_contains($service, "'auto_hire' => false"), 'planning must explicitly prohibit auto-hire');
$need(str_contains($service, "'approval_required' => true"), 'planning must explicitly require approval');
$need(str_contains($service, "'authority_inherited' => false"), 'planning must not inherit authority');
$need(str_contains($controller, 'planningCenter'), 'controller must expose Workforce Planning 2.0');
$need(str_contains($provider, "get('planning'"), 'Workforce Planning route missing');
$need(str_contains($navigation, 'Workforce Planning'), 'Workforce Planning navigation item missing');
$need(str_contains($view, 'No staff are hired automatically'), 'planning UI must explain approval-gated hiring');
$need(str_contains($view, 'Provider requirements'), 'planning UI must expose provider requirements');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Planning 2.0 contract\n";
