<?php
$root = dirname(__DIR__, 2);
$files = [
    $root . '/System/TitanAIWorkforceServiceProvider.php',
    $root . '/System/Zero/Intent/Services/ZeroBaselineIntentClassifier.php',
];
foreach ($files as $file) {
    $text = file_get_contents($file);
    if (str_contains($text, 'App\\Extensions\\InteractionEngine\\')) {
        fwrite(STDERR, basename($file) . " compile-time couples Workforce to Interaction Engine package namespace\n");
        exit(1);
    }
}
$provider = file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
foreach (["'titan.apps.interaction'", "'titan.apps.intelligence-routing'"] as $key) {
    if (!str_contains($provider, $key)) {
        fwrite(STDERR, "Workforce missing stable service key {$key}\n");
        exit(1);
    }
}
echo "PASS Workforce package-location independent interaction discovery\n";
