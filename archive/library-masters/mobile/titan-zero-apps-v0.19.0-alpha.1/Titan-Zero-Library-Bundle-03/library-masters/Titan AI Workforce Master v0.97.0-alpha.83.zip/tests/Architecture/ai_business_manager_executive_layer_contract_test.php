<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$executivePath = $root . '/resources/workforce/executive-role-definitions.json';
$ok(is_file($executivePath), 'executive role catalogue missing');
$executives = is_file($executivePath) ? json_decode((string) file_get_contents($executivePath), true) : [];
$ok(is_array($executives) && count($executives) === 1, 'Step 6 must define exactly one AI Business Manager executive role');
$business = is_array($executives[0] ?? null) ? $executives[0] : [];
$ok(($business['role_definition_id'] ?? null) === 'titan.executive.business_manager', 'AI Business Manager canonical role id drift');
$ok(($business['key'] ?? null) === 'ai-business-manager', 'AI Business Manager key drift');
$ok(($business['name'] ?? null) === 'AI Business Manager', 'AI Business Manager display name drift');
$ok(($business['definition_scope'] ?? null) === 'EXECUTIVE', 'AI Business Manager must be EXECUTIVE scope');
$ok(($business['reports_to_role_definition_id'] ?? null) === 'titan.system.titan_zero', 'AI Business Manager must sit directly beneath Titan Zero');
$ok(($business['executable_capabilities'] ?? null) === [], 'AI Business Manager must not gain domain execution capabilities in Step 6');
foreach (['risk','assurance','governance','autonomy'] as $engine) {
    $ok(($business['bypass'][$engine] ?? null) === false, "AI Business Manager must not bypass {$engine}");
}

$divisionsPath = $root . '/resources/workforce/division-definitions.json';
$divisions = is_file($divisionsPath) ? json_decode((string) file_get_contents($divisionsPath), true) : [];
$managerIds = [];
foreach (is_array($divisions) ? $divisions : [] as $division) {
    $id = trim((string) ($division['manager_role_definition_id'] ?? ''));
    if ($id !== '') $managerIds[] = $id;
}
$managerIds = array_values(array_unique($managerIds));
$ok(count($managerIds) === 15, 'executive hierarchy must cover all 15 division manager roles');

$rolesPath = $root . '/resources/workforce/role-definitions.json';
$roles = is_file($rolesPath) ? json_decode((string) file_get_contents($rolesPath), true) : [];
$byId = [];
foreach (is_array($roles) ? $roles : [] as $role) $byId[(string) ($role['role_definition_id'] ?? '')] = $role;
foreach ($managerIds as $managerId) {
    $ok(isset($byId[$managerId]), "division manager {$managerId} missing from intrinsic role catalogue");
    if (isset($byId[$managerId])) {
        $ok(($byId[$managerId]['reports_to_role_definition_id'] ?? null) === 'titan.executive.business_manager', "division manager {$managerId} must report to AI Business Manager");
    }
}
$legacyChief = $byId['titan.operations.chief_of_staff'] ?? null;
$ok(is_array($legacyChief), 'historic internal Chief of Staff role must be preserved');
if (is_array($legacyChief)) {
    $ok(($legacyChief['name'] ?? null) === 'Executive Operations Coordinator', 'historic internal Chief of Staff must be disambiguated from Titan Zero');
    $ok(in_array('Chief of Staff', $legacyChief['aliases'] ?? [], true), 'historic Chief of Staff name must remain as compatibility alias');
    $ok(($legacyChief['reports_to_role_definition_id'] ?? null) === 'titan.executive.business_manager', 'Executive Operations Coordinator must report to AI Business Manager');
}

$hierarchyPath = $root . '/resources/workforce/executive-hierarchy.json';
$ok(is_file($hierarchyPath), 'canonical executive hierarchy resource missing');
$hierarchy = is_file($hierarchyPath) ? json_decode((string) file_get_contents($hierarchyPath), true) : [];
$ok(($hierarchy['owner_interface_role_definition_id'] ?? null) === 'titan.system.titan_zero', 'executive hierarchy owner interface must be Titan Zero');
$ok(($hierarchy['business_manager_role_definition_id'] ?? null) === 'titan.executive.business_manager', 'executive hierarchy AI Business Manager drift');
$declaredManagers = $hierarchy['division_manager_role_definition_ids'] ?? [];
sort($managerIds); sort($declaredManagers);
$ok($declaredManagers === $managerIds, 'executive hierarchy must enumerate exactly all division managers');
$ok(($hierarchy['operations_coordination_role_definition_id'] ?? null) === 'titan.manager.operations', 'Operations Manager must retain cross-division operational coordination role');
$ok(($hierarchy['internal_executive_coordination_role_definition_id'] ?? null) === 'titan.operations.chief_of_staff', 'historic executive coordination role must be preserved');

$catalogPath = $root . '/System/Support/ExecutiveRoleCatalog.php';
$ok(is_file($catalogPath), 'ExecutiveRoleCatalog support contract missing');
$catalog = is_file($catalogPath) ? (string) file_get_contents($catalogPath) : '';
foreach (['executive-role-definitions.json','titan.executive.business_manager','runtimeRoles'] as $needle) {
    $ok(str_contains($catalog, $needle), "ExecutiveRoleCatalog missing {$needle}");
}

$registryPath = $root . '/System/Support/WorkforceRoleRegistry.php';
$registry = is_file($registryPath) ? (string) file_get_contents($registryPath) : '';
$ok(str_contains($registry, 'ExecutiveRoleCatalog'), 'WorkforceRoleRegistry must expose the AI Business Manager definition');

$servicePath = $root . '/System/Services/ExecutiveLayerService.php';
$ok(is_file($servicePath), 'ExecutiveLayerService missing');
$service = is_file($servicePath) ? (string) file_get_contents($servicePath) : '';
foreach (['synchroniseForCompany','titan.executive.business_manager','titan.system.titan_zero','division_manager_role_definition_ids','authority_inherited'] as $needle) {
    $ok(str_contains($service, $needle), "ExecutiveLayerService missing {$needle}");
}
$ok(str_contains($service, "'authority_inherited' => false"), 'executive coordination relationships must never inherit authority');
$ok(! str_contains($service, 'createBusinessManager'), 'Step 6 must not auto-create a billable AI Business Manager employee');

$migrationPath = $root . '/database/migrations/2026_08_21_000016_ai_business_manager_executive_layer.php';
$ok(is_file($migrationPath), 'Step 6 executive-layer migration missing');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
foreach (['titan.executive.business_manager','titan.system.titan_zero','executive-role-definitions.json','executive-hierarchy.json'] as $needle) {
    $ok(str_contains($migration, $needle), "Step 6 migration missing {$needle}");
}
$ok(! str_contains($migration, "DB::table('ext_titan_ai_workforce_members')->insert"), 'Step 6 must not auto-create AI Business Manager staff instances');

$bootstrapPath = $root . '/System/Services/WorkforceBootstrapService.php';
$bootstrap = is_file($bootstrapPath) ? (string) file_get_contents($bootstrapPath) : '';
$ok(str_contains($bootstrap, 'ExecutiveLayerService'), 'Workforce bootstrap must integrate executive-layer synchronisation');
$ok(str_contains($bootstrap, 'synchroniseForCompany($companyId)'), 'Workforce bootstrap must align existing executive/manager instances without auto-hiring');

$providerPath = $root . '/System/TitanAIWorkforceServiceProvider.php';
$provider = is_file($providerPath) ? (string) file_get_contents($providerPath) : '';
$ok(str_contains($provider, "'titan.workforce.executive-layer'"), 'executive layer service container binding missing');
$ok(str_contains($provider, 'ExecutiveLayerService::class'), 'ExecutiveLayerService must be container-addressable');

if ($failures !== []) {
    fwrite(STDERR, "FAIL ai_business_manager_executive_layer_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS ai_business_manager_executive_layer_contract_test\n";
