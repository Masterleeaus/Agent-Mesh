<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceGovernancePipelineVisualizerService.php';
$viewPath = $root.'/resources/views/workforce/governance-pipeline/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$registry = json_decode(@file_get_contents($root.'/resources/workforce/control-plane-integration-registry.json') ?: '{}', true) ?: [];
$taskView = @file_get_contents($root.'/resources/views/workforce/tasks/show.blade.php') ?: '';

$need(is_file($servicePath), 'Governance Pipeline Visualizer service missing');
$need(is_file($viewPath), 'Governance Pipeline Visualizer view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

$expected = [
    ['signal','Signal'], ['prime','Prime'], ['ai_core','AI Core'], ['ai_runtime','Agent Runtime'],
    ['model_council','Model Council'], ['risk','Risk'], ['assurance','Assurance'], ['governance','Governance'],
    ['autonomy','Autonomy'], ['command_bus','Command Bus'], ['rewind','Rewind'], ['wisdom','Wisdom'],
];
$integrations = $registry['integrations'] ?? [];
$keys = array_map(static fn($row) => (string)($row['key'] ?? ''), is_array($integrations) ? $integrations : []);
$need(count($keys) === 12, 'control-plane registry must contain exactly 12 stages');
foreach ($expected as [$key, $label]) {
    $need(in_array($key, $keys, true), "control-plane stage missing {$key}");
    $need(str_contains($service, "'{$key}'") || str_contains($view, $label), "visualizer missing stage {$label}");
}

foreach (['state','timestamp','provider','decision','evidence','reason','duration','failure','degradation'] as $field) {
    $need(str_contains($service, $field) || str_contains($view, $field), "stage detail missing {$field}");
}

$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'visualizer task lookup must be company scoped');
$need(str_contains($service, 'WorkforceJourneyRecord::query()->forCompany($companyId)'), 'visualizer journey evidence must be company scoped');
$need(str_contains($service, 'WorkforceEvidence::query()->forCompany($companyId)'), 'visualizer evidence lookup must be company scoped');
$need(str_contains($service, 'WorkforceOutcome::query()->forCompany($companyId)'), 'visualizer outcome lookup must be company scoped');
$need(str_contains($service, "'authority_inherited' => false"), 'visualizer must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'visualizer must not grant execution authority');
$need(str_contains($controller, 'governancePipeline'), 'visualizer controller action missing');
$need(str_contains($provider, "get('governance-pipeline'"), 'visualizer route missing');
$need(str_contains($nav, 'Governance Pipeline'), 'visualizer navigation item missing');
$need(str_contains($taskView, 'governance-pipeline'), 'task detail must link to governance pipeline');
$need(str_contains($view, 'does not grant execution authority'), 'visualizer UI must explain authority boundary');
$need(str_contains($view, 'Signal') && str_contains($view, 'Wisdom'), 'visual pipeline must render end-to-end lifecycle');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Governance Pipeline Visualizer contract\n";
