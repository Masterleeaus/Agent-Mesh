<?php
declare(strict_types=1);

$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid JSON {$r}");return$d;};

$c=$json('resources/workforce/business-goal-planning-engine.json');
if(($c['tenant_key']??null)!=='company_id')$fail('tenant key');
if(($c['lifecycle']??[])!==['DRAFT','VALIDATED','COMMITTED'])$fail('plan lifecycle');
foreach(['requires_title','requires_outcome_target','requires_measurable_success_criteria','supports_target_date','supports_context_refs'] as $k)
    if(($c['objective'][$k]??null)!==true)$fail("objective {$k}");
foreach(['canonical_responsibilities_required','explicit_assignees_required','management_chain_enforced','deterministic_provider_route_required','expected_outcome_required','evidence_requirements_required','dependency_graph_validated','critical_path_after_commit'] as $k)
    if(($c['plan'][$k]??null)!==true)$fail("plan {$k}");
foreach(['validation_executes_work','commit_dispatches_work'] as $k)
    if(($c['execution'][$k]??null)!==false)$fail("execution {$k}");
if(($c['execution']['dispatch_is_separate_governed_action']??null)!==true)$fail('dispatch separation');
foreach(['planning_grants_authority','provider_discovery_grants_authority','cross_company_assignment_allowed','cross_management_chain_assignment_allowed','uncanonical_responsibility_allowed'] as $k)
    if(($c['safety'][$k]??null)!==false)$fail("safety {$k}");

$s=$read('System/Services/WorkforceBusinessGoalPlanningService.php');
foreach([
 'draft(','validate(','commit(','summary(',
 'plannerCanCoordinate','containsCycle','assertExecutableRoute',
 'Goal requires an explicit outcome target.','Goal requires measurable success criteria.',
 "planner is not in the assignee's management chain.",
 "'planning_grants_authority' => false",
 "'commit_dispatches_work' => false",
 "\$validation['dispatch_required_separately'] = true;",
 'goal-plan:',
] as $needle) if(!str_contains($s,$needle))$fail("planner service missing {$needle}");
if(str_contains($s,'tenant'.'_company_id'))$fail('planner uses legacy tenant key');
if(str_contains($s,'ProcessWorkforceTaskJob::dispatch'))$fail('planner directly dispatches work');

$migration=$read('database/migrations/2026_08_23_000028_workforce_business_goal_planning_engine.php');
foreach(['company_id','planner_member_id','goal_id','plan_payload','validation_report','plan_fingerprint','committed_at'] as $needle)
    if(!str_contains($migration,$needle))$fail("planner migration missing {$needle}");
if(str_contains($migration,'tenant'.'_company_id'))$fail('planner migration uses legacy tenant key');

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
if(!str_contains($sp,'WorkforceBusinessGoalPlanningService::class'))$fail('planner not registered');
if(!str_contains($sp,"'titan.workforce.goal-planning'"))$fail('planner alias missing');

$matrix=$read('System/Support/WorkforceCanonicalCapabilityMatrix.php');
if(!str_contains($matrix,"count(\$decoded['roles']) !== 117"))$fail('canonical matrix runtime still has stale role count');

echo "PASS: business goal planning engine contract\n";
