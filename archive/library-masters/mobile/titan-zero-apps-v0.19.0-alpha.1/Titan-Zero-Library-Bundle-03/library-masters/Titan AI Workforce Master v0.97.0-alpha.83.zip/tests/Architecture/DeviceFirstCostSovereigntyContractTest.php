<?php
$base=dirname(__DIR__,2);
$required=[
 'System/Services/CostSovereigntyRouter.php'=>['TITAN_MANAGED_NOT_EXPLICITLY_OPTED_IN','NO_ZERO_OR_ENTITLED_RESOURCE_ROUTE','FREE_TIER_TITAN_VARIABLE_COST_DENIED','hidden_fallback'],
 'System/Services/WorkforceProviderRoutingService.php'=>['cost_sovereignty_enforced','resource_route_availability','CostSovereigntyRouter'],
 'resources/workforce/resource-economics-registry.json'=>['device','local','byo_api','customer_service','titan_entitled','titan_metered'],
 'resources/workforce/cost-sovereignty-entitlement-catalog.json'=>['workforce.predictive','titan.phone.managed','titan.system_ai.standard']
];
foreach($required as $file=>$needles){$s=file_get_contents($base.'/'.$file);foreach($needles as $n){if(strpos($s,$n)===false){fwrite(STDERR,"Missing $n in $file\n");exit(1);}}}
echo "PASS device-first cost sovereignty contract\n";
