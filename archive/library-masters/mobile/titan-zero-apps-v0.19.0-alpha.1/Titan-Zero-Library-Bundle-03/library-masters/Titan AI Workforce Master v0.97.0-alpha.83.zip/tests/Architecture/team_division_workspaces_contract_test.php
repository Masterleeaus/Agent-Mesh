<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = file_get_contents($root.'/System/Services/WorkforceOperationalWorkspaceService.php');
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$view = file_get_contents($root.'/resources/views/workforce/workspace/show.blade.php');
$org = file_get_contents($root.'/resources/views/workforce/team/index.blade.php');

$needles = [
    [$service, 'forCompany($companyId)', 'workspace aggregation must remain company_id scoped'],
    [$service, 'WorkforceResponsibilityRegistry::accountabilitiesForRole', 'responsibilities must come from canonical role registry'],
    [$service, '$this->availability->forMember($member)', 'capability health must be live'],
    [$service, "'authority_inherited' => false", 'workspace health must not imply authority'],
    [$service, 'WorkforcePerformanceMetric::query()->forCompany($companyId)', 'performance must be company scoped'],
    [$service, 'whereNotNull(\'verified_at\')', 'verified outcomes must be distinguished'],
    [$provider, "name('divisions.show')", 'division workspace route required'],
    [$provider, "name('teams.show')", 'team workspace route required'],
    [$controller, 'divisionWorkspace(WorkforceDivision $division)', 'division controller action required'],
    [$controller, 'teamWorkspace(WorkforceTeam $teamScope)', 'team controller action required'],
    [$view, 'Queue pressure', 'queue pressure surface required'],
    [$view, 'Current objectives', 'objective surface required'],
    [$view, 'Blocked work', 'blocked-work surface required'],
    [$view, 'Capability health', 'capability health surface required'],
    [$view, 'Verified outcomes', 'verified outcomes surface required'],
    [$view, 'Responsibilities', 'responsibility surface required'],
    [$view, 'Schedules', 'schedule surface required'],
    [$view, 'Handoffs', 'handoff surface required'],
    [$view, 'Performance', 'performance surface required'],
    [$view, "dashboard.user.titan-workforce.staff.show", 'members must open Employee 360'],
    [$org, "dashboard.user.titan-workforce.divisions.show", 'organisation map must link divisions'],
    [$org, "dashboard.user.titan-workforce.teams.show", 'organisation map must link teams'],
];
foreach ($needles as [$haystack,$needle,$message]) {
    if (! str_contains($haystack, $needle)) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
}
echo "PASS: Team & Division Workspaces contract\n";
