<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$enum = @file_get_contents($root.'/System/Enums/WorkforceRelationshipType.php') ?: '';
foreach (['reports_to','manages','coordinates','consults','informs','delegates_to','escalates_to'] as $type) {
    $ok(str_contains($enum, "'{$type}'"), "canonical relationship type missing: {$type}");
}

$resourcePath = $root.'/resources/workforce/organisational-relationships.json';
$ok(is_file($resourcePath), 'intrinsic organisational relationship blueprint missing');
$data = is_file($resourcePath) ? json_decode((string) file_get_contents($resourcePath), true) : null;
$ok(is_array($data), 'organisational relationship blueprint must parse');
$ok(($data['schema'] ?? null) === 'titan.workforce.org-relationships.v1', 'relationship blueprint schema drift');
$relationships = is_array($data['relationships'] ?? null) ? $data['relationships'] : [];
$types = [];
$ids = [];
foreach ($relationships as $relationship) {
    $type = (string) ($relationship['relationship_type'] ?? '');
    $types[$type] = ($types[$type] ?? 0) + 1;
    $id = (string) ($relationship['relationship_definition_id'] ?? '');
    $ok($id !== '' && ! isset($ids[$id]), 'relationship definition ids must be non-empty and unique');
    $ids[$id] = true;
    $ok(($relationship['authority_inherited'] ?? null) === false, "relationship {$id} must never inherit authority");
}
foreach (['reports_to','manages','coordinates','consults','informs','delegates_to','escalates_to'] as $type) {
    $ok(($types[$type] ?? 0) > 0, "intrinsic blueprint must contain {$type} relationships");
}


$validator = @file_get_contents($root.'/System/Support/WorkforceManifestValidator.php') ?: '';
foreach (['coordinates','consults','informs'] as $type) {
    $ok(str_contains($validator, "'{$type}'"), "manifest validator must recognise canonical relationship type {$type}");
}
foreach (['workforce-manifest.schema.json','workforce-manifest-v1.1.schema.json'] as $schemaFile) {
    $schemaText = @file_get_contents($root.'/resources/workforce/'.$schemaFile) ?: '';
    foreach (['coordinates','consults','informs'] as $type) {
        $ok(str_contains($schemaText, '"'.$type.'"'), "{$schemaFile} must recognise canonical relationship type {$type}");
    }
}

$modelPath = $root.'/System/Models/WorkforceRelationshipDefinition.php';
$ok(is_file($modelPath), 'WorkforceRelationshipDefinition model missing');
$migrationPath = $root.'/database/migrations/2026_08_21_000017_organisational_graph_reporting.php';
$ok(is_file($migrationPath), 'Step 7 relationship-definition migration missing');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
foreach (['ext_titan_ai_workforce_relationship_definitions','relationship_definition_id','source_role_definition_id','target_role_definition_id','relationship_type','organisational-relationships.json'] as $needle) {
    $ok(str_contains($migration, $needle), "Step 7 migration missing {$needle}");
}

$service = @file_get_contents($root.'/System/Services/WorkforceGraphService.php') ?: '';
foreach (['assertNoReportingCycle','assertGraphIntegrity','validateGraph','synchroniseIntrinsicRelationships','assertSameCompany','ORPHAN_MANAGER','CROSS_COMPANY_RELATIONSHIP','SELF_RELATIONSHIP','REPORTING_CYCLE'] as $needle) {
    $ok(str_contains($service, $needle), "WorkforceGraphService missing {$needle}");
}
$ok(str_contains($service, 'authority_inherited'), 'graph service must keep relationship authority non-inherited');

$bootstrap = @file_get_contents($root.'/System/Services/WorkforceBootstrapService.php') ?: '';
$ok(str_contains($bootstrap, 'synchroniseIntrinsicRelationships($companyId)'), 'Workforce bootstrap must materialise intrinsic relationships for existing members');

$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$ok(str_contains($controller, "'integrity' => \$this->graph->validateGraph(\$this->companyId())"), 'organisation graph API must expose graph integrity status');

$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$ok(str_contains($provider, "'titan.workforce.relationship-definitions'"), 'relationship-definition registry binding missing');

if ($failures !== []) {
    fwrite(STDERR, "FAIL organisational_graph_reporting_v3_contract_test\n - ".implode("\n - ", $failures)."\n");
    exit(1);
}

echo "PASS organisational_graph_reporting_v3_contract_test\n";
