<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid JSON {$r}");return$d;};

$status=$json('resources/workforce/context-federation-status.json');
if(($status['tenant_key']??null)!=='company_id')$fail('federation tenant key');
if(($status['summary']['canonical_provider_count']??null)!==38)$fail('provider count');
if(($status['summary']['specialized_adapter_provider_count']??null)!==3)$fail('specialized provider count');
if(($status['summary']['federated_schema_adapter_provider_count']??null)!==21)$fail('federated provider count');
if(($status['summary']['business_context_adapter_provider_count']??null)!==24)$fail('business context adapter count');
if(($status['summary']['federated_surface_count']??null)!==149)$fail('federated surface count');
foreach(['company_id_public_boundary','legacy_storage_keys_internal_only','read_only','caller_company_override_forbidden','schema_checked_at_runtime','provider_version_pin_required'] as $k){
    if(($status['invariants'][$k]??null)!==true)$fail("federation invariant {$k}");
}
foreach(['authority_inherited','execution_authority_granted'] as $k){
    if(($status['invariants'][$k]??null)!==false)$fail("federation safety {$k}");
}

$profiles=$json('resources/workforce/context-federation-profiles.json');
if(($profiles['profile_count']??null)!==21)$fail('profile count');
if(($profiles['supported_surface_count']??null)!==149)$fail('profile surface count');
foreach($profiles['profiles'] as $profile){
    if(($profile['tenant_boundary']??null)!=='company_id')$fail('profile public tenant boundary');
    if(($profile['writes_allowed']??null)!==false)$fail('profile permits writes');
    if(($profile['authority_inherited']??null)!==false || ($profile['execution_authority_granted']??null)!==false)$fail('profile grants authority');
    if(count($profile['routes']??[])<1)$fail('empty federation profile');
}

$adapter=$read('System/Adapters/WorkforceFederatedSchemaContextProviderAdapter.php');
foreach([
    'implements WorkforceBusinessContextProviderContract',
    'where($storageKey, $companyId)',
    'hasTable($table)',
    'hasColumn($table, $storageKey)',
    'unset($filters[$key])',
    "'company_id' => \$companyId",
    "'provider-owned-schema-read-compatibility'",
] as $needle){
    if(!str_contains($adapter,$needle))$fail("adapter missing {$needle}");
}
if(str_contains($adapter,'insert(')||str_contains($adapter,'update(')||str_contains($adapter,'delete('))$fail('federation adapter contains mutation path');

$gateway=$read('System/Services/WorkforceBusinessContextGateway.php');
foreach(['healthSuccess','healthFailure','CONTEXT_PROVIDER_READ_FAILED','recordSuccess','recordFailure'] as $needle){
    if(!str_contains($gateway,$needle))$fail("gateway observability missing {$needle}");
}

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
foreach([
 'WorkforceContextFederationProfiles::class',
 'WorkforceFederatedSchemaContextProviderAdapter',
 "'titan.workforce.context-provider.crm'",
 "'titan.workforce.context-provider.titan-field'",
 "'titan.workforce.context-provider.titan-assets'",
 "'titan.workforce.context-provider.titan-time-attendance'",
 "'titan.workforce.context-provider.titan-connect'",
 "'titan.workforce.context-provider.titan-ledger'",
 "'titan.workforce.context-provider.titan-maps-intelligence'",
 "'titan.workforce.context-provider.titan-governance'",
 "'titan.workforce.context-provider.titan-assurance'",
 "'titan.workforce.context-provider.titan-shield'",
 "'titan.workforce.context-provider.titan-signal-engine'",
 "'titan.workforce.context-provider.titan-knowledge-authority'",
 "'titan.workforce.context-provider.titan-rewind'",
 "'titan.workforce.context-provider.titan-wisdom'",
] as $needle){
    if(!str_contains($sp,$needle))$fail("context binding missing {$needle}");
}

$recon=$json('resources/workforce/provider-contract-reconciliation.json');
if(($recon['summary']['context_adapter_implemented_count']??null)!==24)$fail('reconciliation adapter coverage');
if(($recon['summary']['context_adapter_planned_count']??null)!==0)$fail('old planned business adapter gap remains');

echo "PASS: end-to-end business context federation contract\n";
