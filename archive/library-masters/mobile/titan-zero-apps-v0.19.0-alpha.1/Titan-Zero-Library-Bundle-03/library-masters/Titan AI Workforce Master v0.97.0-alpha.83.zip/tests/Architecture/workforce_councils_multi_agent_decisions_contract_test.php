<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceCouncilOperationsService.php';
$viewPath = $root.'/resources/views/workforce/councils/index.blade.php';
$showPath = $root.'/resources/views/workforce/councils/show.blade.php';
$policyPath = $root.'/resources/workforce/organisation-policies.json';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$councilService = @file_get_contents($root.'/System/Services/WorkforceCouncilService.php') ?: '';
$policies = json_decode(@file_get_contents($policyPath) ?: '{}', true) ?: [];

$need(is_file($servicePath), 'Council Operations service missing');
$need(is_file($viewPath), 'Councils Center view missing');
$need(is_file($showPath), 'Council detail view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';
$show = @file_get_contents($showPath) ?: '';

$templates = [
    'executive_operations' => 'Executive Operations',
    'finance_review' => 'Finance Review',
    'risk_compliance' => 'Risk & Compliance',
    'quality' => 'Quality',
    'customer_recovery' => 'Customer Recovery',
    'major_incident' => 'Major Incident',
    'staffing' => 'Staffing',
    'strategic_planning' => 'Strategic Planning',
];
$councils = $policies['councils'] ?? [];
foreach ($templates as $key => $name) {
    $need(isset($councils[$key]), "built-in council template missing {$key}");
    $need(($councils[$key]['name'] ?? null) === $name, "council template name mismatch {$key}");
}

foreach (['participants','chair','issue','evidence','proposals','dissent','recommendation','final_decision','follow_up_work_items'] as $field) {
    $need(str_contains($service, $field) || str_contains($show, $field), "Council operational system missing {$field}");
}

$need(str_contains($service, 'WorkforceCouncil::query()->forCompany($companyId)'), 'Council Center must be company scoped');
$need(str_contains($service, 'WorkforceCouncilMembership::query()->forCompany($companyId)'), 'Council memberships must be company scoped');
$need(str_contains($councilService, 'WorkforceCouncil::query()->updateOrCreate'), 'convening must persist a WorkforceCouncil');
$need(str_contains($councilService, 'WorkforceCouncilMembership::query()->updateOrCreate'), 'convening must persist council participants');
$need(str_contains($controller, 'councilsCenter'), 'Council Center controller action missing');
$need(str_contains($controller, 'councilShow'), 'Council detail controller action missing');
$need(str_contains($controller, 'conveneCouncil'), 'Council convene action missing');
$need(str_contains($controller, 'updateCouncilDecision'), 'Council operational update action missing');
$need(str_contains($provider, "get('councils'"), 'Council Center route missing');
$need(str_contains($provider, "get('councils/{council}'"), 'Council detail route missing');
$need(str_contains($provider, "post('councils/convene'"), 'Council convene route missing');
$need(str_contains($provider, "post('councils/{council}/decision'"), 'Council decision route missing');
$need(str_contains($nav, 'Councils'), 'Councils navigation item missing');
$need(str_contains($service, "'authority_inherited' => false"), 'Councils must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'Councils must not grant execution authority');
$need(str_contains($councilService, "'governed_coordination_only' => true"), 'Council-created work must remain governed coordination');
$need(str_contains($councilService, "'requires_fresh_execution_authorization' => true"), 'Council follow-up work must require fresh execution authorization');
$need(str_contains($show, 'Council decisions do not grant execution authority'), 'Council UI must explain authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Councils & Multi-Agent Decisions contract\n";
