<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$fail = static function(string $m): never { fwrite(STDERR, "FAIL: {$m}\n"); exit(1); };
$json = static function(string $r) use($root,$fail): array {
    $p=$root.'/'.$r; if(!is_file($p))$fail("missing {$r}");
    $d=json_decode((string)file_get_contents($p),true); if(!is_array($d))$fail("invalid JSON {$r}"); return $d;
};
$read = static function(string $r) use($root,$fail): string {
    $p=$root.'/'.$r; if(!is_file($p))$fail("missing {$r}"); return (string)file_get_contents($p);
};

$registry=$json('resources/workforce/ecosystem-capability-registry.json');
$providers=$registry['providers']??[];
if(count($providers)!==38)$fail('expected exactly 38 canonical providers');
$keys=array_map(static fn($p)=>(string)($p['extension']['key']??''),$providers);
foreach(['titan-people','titan-payroll','titan-trust','onboarding-pro'] as $key) if(!in_array($key,$keys,true))$fail("missing provider {$key}");
if(count(array_unique($keys))!==38)$fail('duplicate provider identity');

foreach($providers as $p){
    if(($p['ownership']['organisation_owner']??null)!=='titan-ai-workforce')$fail('provider claims organisation ownership');
    if(($p['ownership']['role_definitions_owned_by_provider']??null)!==false)$fail('provider owns role definitions');
    if(($p['runtime']['catalogue_grants_authority']??null)!==false)$fail('provider catalogue grants authority');
}

$matrix=$json('resources/workforce/canonical-capability-binding-matrix.json');
if(($matrix['summary']['provider_count']??null)!==38)$fail('matrix provider count');
$roles=[];
foreach($matrix['roles'] as $r)$roles[$r['role_definition_id']]=$r;
foreach([
 'titan.manager.workforce'=>'titan-people',
 'titan.manager.finance'=>'titan-payroll',
 'titan.money.payroll_manager'=>'titan-payroll',
 'titan.work.quality_coordinator'=>'titan-trust',
 'titan.manager.compliance_governance'=>'titan-trust'
] as $role=>$provider){
    if(!isset($roles[$role]))$fail("missing role {$role}");
    $bound=array_map(static fn($b)=>(string)($b['provider']??''),$roles[$role]['provider_bindings']??[]);
    if(!in_array($provider,$bound,true))$fail("{$role} missing {$provider}");
}

$idx=$json('resources/workforce/platform-capability-index.json');
if(($idx['summary']['provider_count']??null)!==38)$fail('platform index provider count');
if(($idx['summary']['surface_count']??0)<1880)$fail('platform index unexpectedly incomplete');

$tasks=$read('System/Services/WorkforceTaskService.php');
if(!str_contains($tasks,'assertExecutableRoute('))$fail('deterministic provider routing not wired');
if(!str_contains($tasks,'Canonical Work Item cannot complete before verified outcome and evidence.'))$fail('verified outcome gate missing');

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
foreach(['WorkforceBusinessContextGateway::class','WorkforceGoalService::class','WorkforceWorkItemService::class','WorkforceSignalToWorkService::class'] as $needle)
    if(!str_contains($sp,$needle))$fail("runtime integration missing {$needle}");

foreach([
 'database/migrations/2026_08_22_000023_workforce_business_context_gateway.php',
 'database/migrations/2026_08_22_000024_workforce_goal_work_item_engine.php',
 'database/migrations/2026_08_22_000025_workforce_signal_to_work_automation.php'
] as $m) if(!is_file($root.'/'.$m))$fail("missing migration {$m}");

$context=$json('resources/workforce/business-context-source-catalog.json');
if(($context['tenant_key']??null)!=='company_id')$fail('context tenant boundary');
if(($context['summary']['source_count']??0)<220)$fail('context catalogue incomplete');

$signals=$json('resources/workforce/signal-work-candidate-catalog.json');
if(($signals['event_count']??0)<40)$fail('signal catalogue incomplete');
if(($signals['safety']['signal_grants_authority']??null)!==false)$fail('signal authority safety');

echo "PASS: 38-provider People/Payroll/TitanTrust/OnboardingPro full-platform Workforce convergence\n";
