<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$resourcePath = $root . '/resources/workforce/division-definitions.json';
$ok(is_file($resourcePath), 'intrinsic division catalogue must exist');
$definitions = [];
if (is_file($resourcePath)) {
    $decoded = json_decode((string) file_get_contents($resourcePath), true);
    $ok(is_array($decoded), 'intrinsic division catalogue must be valid JSON array');
    $definitions = is_array($decoded) ? $decoded : [];
}

$expected = [
    'operations' => ['Operations', 'titan.manager.operations'],
    'customer' => ['Customer', 'titan.manager.customer_service'],
    'sales' => ['Sales', 'titan.manager.sales'],
    'marketing' => ['Marketing & Reputation', 'titan.manager.marketing'],
    'work' => ['Work & Service Operations', 'titan.manager.service'],
    'money' => ['Money & Finance', 'titan.manager.finance'],
    'people' => ['People & Workforce', 'titan.manager.workforce'],
    'assets' => ['Assets, Stock & Fleet', 'titan.manager.assets'],
    'procurement' => ['Procurement & Supply', 'titan.manager.procurement_supply'],
    'records' => ['Records & Data', 'titan.manager.records_data'],
    'insights' => ['Business Intelligence', 'titan.manager.business_intelligence'],
    'automation' => ['Automation & Systems', 'titan.manager.automation'],
    'governance' => ['Governance & Incidents', 'titan.manager.compliance_governance'],
    'hospitality-realestate' => ['Hospitality & Real Estate', 'titan.manager.hospitality_realestate'],
    'retail-rental' => ['Retail, Rental & Fulfilment', 'titan.manager.retail_rental'],
];

$ok(count($definitions) === 15, 'intrinsic division catalogue must contain exactly 15 divisions');
$keys = [];
foreach ($definitions as $definition) {
    $key = (string) ($definition['key'] ?? '');
    $keys[] = $key;
    $ok(isset($expected[$key]), "unexpected intrinsic division {$key}");
    if (! isset($expected[$key])) continue;
    $ok(($definition['name'] ?? null) === $expected[$key][0], "division {$key} name drift");
    $ok(($definition['manager_role_definition_id'] ?? null) === $expected[$key][1], "division {$key} manager role drift");
    $ok(is_string($definition['purpose'] ?? null) && trim((string) $definition['purpose']) !== '', "division {$key} purpose missing");
    $ok(is_array($definition['team_boundaries'] ?? null) && count($definition['team_boundaries']) >= 1, "division {$key} team boundaries missing");
    $ok(is_array($definition['applicability'] ?? null), "division {$key} applicability missing");
    $businessTiers = $definition['applicability']['business_tiers'] ?? [];
    $ok(array_diff($businessTiers, ['SOLO','SMALL','GROWING','ENTERPRISE']) === [], "division {$key} business tier vocabulary drift");
    $ok(is_array($definition['activation_rules'] ?? null), "division {$key} activation rules missing");
    $ok(($definition['activation_rules']['auto_activate'] ?? null) === false, "division {$key} must not auto-activate during Pass 3");
}
$ok(count(array_unique($keys)) === 15, 'intrinsic division keys must be unique');

$migrationPath = $root . '/database/migrations/2026_08_21_000013_restore_intrinsic_divisions.php';
$ok(is_file($migrationPath), 'Pass 3 intrinsic division migration must exist');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
$ok(str_contains($migration, "Schema::create('ext_titan_ai_workforce_division_definitions'"), 'division definition table migration missing');
$ok(str_contains($migration, "'division_definition_id'"), 'stable division_definition_id missing');
$ok(str_contains($migration, "'manager_role_definition_id'"), 'manager role definition binding missing');
$ok(str_contains($migration, "'team_boundaries'"), 'team boundary column missing');
$ok(str_contains($migration, "'applicability'"), 'applicability column missing');
$ok(str_contains($migration, "'activation_rules'"), 'activation rules column missing');
$ok(str_contains($migration, "Schema::hasColumn('ext_titan_ai_workforce_divisions', 'division_definition_id')"), 'company division instance definition binding missing');
$ok(! str_contains($migration, "DB::table('ext_titan_ai_workforce_divisions')->insert"), 'Pass 3 must not auto-create company division instances');

foreach (['WorkforceDivisionDefinition.php'] as $file) {
    $ok(is_file($root . '/System/Models/' . $file), "missing {$file}");
}
$catalogPath = $root . '/System/Support/IntrinsicDivisionCatalog.php';
$ok(is_file($catalogPath), 'IntrinsicDivisionCatalog support contract missing');
$catalog = is_file($catalogPath) ? (string) file_get_contents($catalogPath) : '';
$ok(str_contains($catalog, 'division-definitions.json'), 'IntrinsicDivisionCatalog must read canonical division definitions');
$ok(str_contains($catalog, 'titan.division.'), 'IntrinsicDivisionCatalog must expose stable titan.division.* identities');

$modelText = is_file($root . '/System/Models/WorkforceDivision.php') ? (string) file_get_contents($root . '/System/Models/WorkforceDivision.php') : '';
$ok(str_contains($modelText, "'division_definition_id'"), 'WorkforceDivision instance must expose division_definition_id binding');

if ($failures !== []) {
    fwrite(STDERR, "FAIL intrinsic_divisions_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS intrinsic_divisions_contract_test\n";
