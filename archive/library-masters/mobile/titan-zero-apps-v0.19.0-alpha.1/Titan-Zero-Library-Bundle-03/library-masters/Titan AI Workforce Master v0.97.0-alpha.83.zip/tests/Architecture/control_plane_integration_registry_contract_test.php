<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$registryPath = $root.'/resources/workforce/control-plane-integration-registry.json';
$schemaPath = $root.'/resources/workforce/control-plane-integration-registry.schema.json';
$servicePath = $root.'/System/Support/WorkforceControlPlaneIntegrationRegistry.php';
$lifecyclePath = $root.'/System/Services/WorkforceControlPlaneLifecycleService.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';

foreach ([$registryPath,$schemaPath,$servicePath,$lifecyclePath] as $path) {
    $assert(is_file($path), 'missing Step 12 control-plane artifact: '.basename($path));
}

if (is_file($registryPath)) {
    $registry = json_decode((string) file_get_contents($registryPath), true, flags: JSON_THROW_ON_ERROR);
    $assert(($registry['schema_version'] ?? null) === '1.0', 'control-plane registry schema_version must be 1.0');
    $assert(($registry['tenant_key'] ?? null) === 'company_id', 'control-plane registry must use company_id');
    $integrations = $registry['integrations'] ?? [];
    $assert(count($integrations) === 12, 'control-plane registry must contain exactly 12 integrations');

    $expected = [
        'signal' => ['provider' => 'titan-signal-engine', 'stage' => 'observe', 'failure' => 'queue_and_retry'],
        'prime' => ['provider' => 'titan-prime', 'stage' => 'mission', 'failure' => 'fail_closed_when_required'],
        'ai_core' => ['provider' => 'titan-ai-core', 'stage' => 'plan', 'failure' => 'fail_closed_when_required'],
        'ai_runtime' => ['provider' => 'titan-ai', 'stage' => 'reason', 'failure' => 'fail_closed'],
        'model_council' => ['provider' => 'titan-model-council', 'stage' => 'deliberate', 'failure' => 'fail_closed_when_required'],
        'risk' => ['provider' => 'titan-risk-engine', 'stage' => 'risk', 'failure' => 'fail_closed'],
        'assurance' => ['provider' => 'titan-assurance', 'stage' => 'assure', 'failure' => 'fail_closed'],
        'governance' => ['provider' => 'titan-governance', 'stage' => 'govern', 'failure' => 'fail_closed'],
        'autonomy' => ['provider' => 'titan-autonomy', 'stage' => 'authorize', 'failure' => 'fail_closed'],
        'command_bus' => ['provider' => 'titan-command-bus', 'stage' => 'execute', 'failure' => 'recovery_required'],
        'rewind' => ['provider' => 'titan-rewind', 'stage' => 'recover', 'failure' => 'preserve_evidence'],
        'wisdom' => ['provider' => 'titan-wisdom', 'stage' => 'learn', 'failure' => 'withhold_learning'],
    ];
    $byKey = [];
    foreach ($integrations as $integration) {
        $key = (string) ($integration['key'] ?? '');
        $byKey[$key] = $integration;
        $assert(($integration['authority_inherited'] ?? true) === false, "{$key} must not inherit authority");
        $assert(is_array($integration['bindings'] ?? null) && ($integration['bindings'] ?? []) !== [], "{$key} must declare runtime bindings");
        $assert(is_array($integration['input_contract'] ?? null), "{$key} must declare input contract");
        $assert(is_array($integration['output_contract'] ?? null), "{$key} must declare output contract");
    }
    foreach ($expected as $key => $contract) {
        $assert(isset($byKey[$key]), "missing control-plane integration {$key}");
        if (! isset($byKey[$key])) continue;
        foreach ($contract as $field => $value) {
            $assert(($byKey[$key][$field] ?? null) === $value, "{$key}.{$field} mismatch");
        }
    }

    $order = array_values(array_map(static fn(array $row): string => (string) ($row['stage'] ?? ''), $integrations));
    $assert($order === ['observe','mission','plan','reason','deliberate','risk','assure','govern','authorize','execute','recover','learn'], 'control-plane stages must use canonical lifecycle order');
}

$service = is_file($servicePath) ? (string) file_get_contents($servicePath) : '';
foreach (['bindingsFor','availability','executionGateStatus','titan-governance','titan-command-bus','company_id'] as $needle) {
    $assert(str_contains($service, $needle), 'control-plane registry service missing '.$needle);
}
$lifecycle = is_file($lifecyclePath) ? (string) file_get_contents($lifecyclePath) : '';
foreach (['WorkforceControlPlaneIntegrationRegistry','lifecycle','executionGateStatus','observe','mission','plan','reason','deliberate','risk','assure','govern','authorize','execute','recover','learn'] as $needle) {
    $assert(str_contains($lifecycle, $needle), 'control-plane lifecycle service missing '.$needle);
}

$provider = (string) @file_get_contents($providerPath);
$assert(str_contains($provider, "'titan.workforce.control-plane-registry'"), 'service provider must expose stable control-plane registry binding');
$assert(str_contains($provider, "'titan.workforce.control-plane-lifecycle'"), 'service provider must expose stable control-plane lifecycle binding');

$pre = (string) @file_get_contents($root.'/System/Services/WorkforcePreExecutionGovernanceService.php');
$assert(str_contains($pre, 'WorkforceControlPlaneIntegrationRegistry'), 'pre-execution Risk/Assurance/Council adapters must resolve bindings from canonical registry');

$autonomy = (string) @file_get_contents($root.'/System/Services/WorkforceAutonomyService.php');
foreach (['WorkforceControlPlaneIntegrationRegistry','governanceConstraint','GOVERNANCE_ENGINE_UNAVAILABLE','governance_constraint'] as $needle) {
    $assert(str_contains($autonomy, $needle), 'Autonomy/Governance pipeline missing formal integration '.$needle);
}
$signal = (string) @file_get_contents($root.'/System/Services/WorkforceSignalBridge.php');
$assert(str_contains($signal, 'WorkforceControlPlaneIntegrationRegistry'), 'Signal adapter must resolve bindings from canonical registry');
$outcomes = (string) @file_get_contents($root.'/System/Services/WorkforceOutcomeFeedbackService.php');
$assert(str_contains($outcomes, 'WorkforceControlPlaneIntegrationRegistry'), 'Rewind/Wisdom adapters must resolve bindings from canonical registry');
$gateway = (string) @file_get_contents($root.'/System/Services/AgentRuntimeGateway.php');
$assert(str_contains($gateway, 'WorkforceControlPlaneIntegrationRegistry'), 'Agent Runtime gateway must resolve bindings from canonical registry');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce Control-Plane Integration Registry contract\n";
