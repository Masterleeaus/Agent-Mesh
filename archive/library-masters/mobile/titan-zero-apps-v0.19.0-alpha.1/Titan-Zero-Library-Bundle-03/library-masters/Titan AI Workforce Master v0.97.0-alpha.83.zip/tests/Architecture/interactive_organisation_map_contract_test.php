<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = @file_get_contents($root.'/System/Services/WorkforceOrganisationMapService.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$view = @file_get_contents($root.'/resources/views/workforce/team/index.blade.php') ?: '';
$assert = static function (bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } };

foreach (['WorkforceDivision','WorkforceMember','WorkforceRelationship','WorkforceDelegation','WorkforceEscalation','WorkforceCapabilityAvailabilityService','WorkforceTask'] as $needle) {
    $assert(str_contains($service, $needle), 'Organisation Map aggregation missing '.$needle);
}
foreach (['forCompany($companyId)','company_id','authority_inherited','provider_bindings','overloaded','missing_manager'] as $needle) {
    $assert(str_contains($service, $needle), 'Organisation Map tenancy/health invariant missing '.$needle);
}
foreach (['reports_to','delegates_to','escalates_to','substitutes_for'] as $needle) {
    $assert(str_contains($service.$view, $needle), 'Organisation Map relationship support missing '.$needle);
}
$assert(str_contains($controller, 'WorkforceOrganisationMapService'), 'controller missing Organisation Map service');
$assert(str_contains($controller, "'organisationMap' => \$this->organisationMap->snapshot(\$companyId)"), 'controller does not pass company-scoped Organisation Map');
foreach (['Interactive Organisation Map','Division','Team','Manager','Specialist','Deputy','Delegation','Escalation','Coordination','Degraded staff','Overloaded staff','Missing manager','Provider dependency','Open Employee 360'] as $needle) {
    $assert(str_contains($view, $needle), 'Organisation Map UI missing '.$needle);
}
foreach (['data-filter="division"','data-filter="team"','data-filter="role"','data-filter="lifecycle"','data-filter="provider"','data-flag-filter="degraded"','data-flag-filter="overloaded"','data-flag-filter="missing-manager"'] as $needle) {
    $assert(str_contains($view, $needle), 'Organisation Map filter missing '.$needle);
}
$assert(str_contains($view, 'staff.show') || str_contains($service, 'staff.show'), 'staff nodes do not link to Employee 360');
$assert(str_contains($view, 'never grant authority'), 'relationship/capability authority warning missing');
$assert(!str_contains($service.$view, 'tenant'.'_company_id'), 'Organisation Map must not use the retired company boundary');

echo "PASS: Interactive Organisation Map visual hierarchy + health/filter contract\n";
