<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$service = @file_get_contents($root.'/System/Services/WorkforceProactiveOperationsCenterService.php') ?: '';
$scheduled = @file_get_contents($root.'/System/Services/ProactiveWorkforceService.php') ?: '';
$events = @file_get_contents($root.'/System/Services/WorkforceEventTriggerService.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$view = @file_get_contents($root.'/resources/views/workforce/proactive/index.blade.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

foreach ([$service,$scheduled,$events] as $source) $need(str_contains($source, 'forCompany('), 'proactive operations must preserve company_id scoping');
foreach (['scheduled','event_driven','generated_work','skipped_runs','degraded_runs','blocked_runs','provider_dependencies','triggering_signal','employee'] as $needle) $need(str_contains($service, $needle), "center aggregation missing {$needle}");
foreach (['generated','skipped','degraded','blocked','run_telemetry'] as $needle) {
    $need(str_contains($scheduled, $needle), "scheduled runtime telemetry missing {$needle}");
    $need(str_contains($events, $needle), "event runtime telemetry missing {$needle}");
}
$need(str_contains($events, "'last_signal'"), 'event-driven telemetry must retain the latest triggering Signal identity');
$need(str_contains($controller, 'proactiveOperationsCenter->snapshot($this->companyId())'), 'controller must request company-scoped proactive snapshot');
$need(str_contains($provider, "name('proactive-operations')"), 'proactive operations route missing');
$need(str_contains($nav, 'titan_workforce_proactive'), 'proactive operations navigation missing');
foreach (['Scheduled routines','Event-driven routines','Triggering Signal','Skipped runs','Degraded runs','Blocked runs','Provider dependencies','What is the Workforce doing by itself?'] as $needle) $need(str_contains($view, $needle), "proactive center view missing {$needle}");
$need(str_contains($service, "'authority_inherited' => false"), 'center must state that operational visibility does not inherit authority');
$need(str_contains($view, 'does not grant execution authority'), 'UI must preserve no-authority-inheritance language');

if ($failures) { foreach ($failures as $f) fwrite(STDERR, "FAIL: {$f}\n"); exit(1); }
echo "PASS: proactive operations center contract\n";
