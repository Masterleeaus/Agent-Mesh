<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$policy=file_get_contents($root.'/System/Services/WorkforceRecoveryDecisionService.php');
$recovery=file_get_contents($root.'/System/Services/WorkforceExecutionRecoveryService.php');
$intent=file_get_contents($root.'/System/Services/WorkforceExecutionIntentService.php');

$checks=[
 'unknown outcome state'=>str_contains($policy,'UNKNOWN_OUTCOME'),
 'post-dispatch no blind retry'=>str_contains($policy,"'retry_allowed' => false"),
 'reconciliation required'=>str_contains($policy,"'reconciliation_required' => true"),
 'idempotency required'=>str_contains($policy,'IDEMPOTENCY_KEY_REQUIRED'),
 'duplicate existing receipt reused'=>str_contains($policy,'DUPLICATE_RETURN_EXISTING_RECEIPT'),
 'uncertain duplicate blocked'=>str_contains($policy,'DUPLICATE_EXECUTION_IN_FLIGHT_OR_UNCERTAIN'),
 'receipt reconciliation exists'=>str_contains($recovery,'reconcileReceipt'),
 'compensation governance required'=>str_contains($recovery,'RECOVERY_GOVERNANCE_REQUIRED'),
 'execution intent derives idempotency key'=>str_contains($intent,"'wfexec:'"),
];
$failed=array_keys(array_filter($checks,fn($v)=>!$v));
if($failed){fwrite(STDERR,'FAIL: '.implode(', ',$failed).PHP_EOL);exit(1);}
echo 'Wave 4A recovery/idempotency contract: PASS ('.count($checks).'/'.count($checks).')'.PHP_EOL;
