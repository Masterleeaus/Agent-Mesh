<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = @file_get_contents($root.'/System/Services/WorkforceEmployeeProfileService.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$view = @file_get_contents($root.'/resources/views/workforce/employee/show.blade.php') ?: '';
$table = @file_get_contents($root.'/resources/views/workforce/employee/partials/capability-table.blade.php') ?: '';
$team = @file_get_contents($root.'/resources/views/workforce/team/index.blade.php') ?: '';
$assert = static function (bool $condition, string $message): void { if (! $condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } };

foreach (['WorkforceCapabilityAvailabilityService','WorkforceResponsibilityRegistry','WorkforceSchedule','WorkforceDelegation','WorkforceEscalation','WorkforcePerformanceMetric','WorkforceOutcome','WorkforceRuntimeProfile','WorkforceTaskHistory'] as $needle) {
    $assert(str_contains($service, $needle), 'Employee 360 aggregation missing '.$needle);
}
foreach (['forCompany($companyId)','company_id','authority_inherited','task-scoped','autonomy_snapshot'] as $needle) {
    $assert(str_contains($service, $needle), 'Employee 360 tenancy/authority invariant missing '.$needle);
}
$assert(str_contains($provider, "get('team/{member}'"), 'Employee 360 route missing');
$assert(str_contains($provider, "name('staff.show')"), 'Employee 360 named route missing');
$assert(str_contains($controller, 'WorkforceEmployeeProfileService'), 'controller missing Employee 360 service');
$assert(str_contains($controller, "'profile' => \$this->employeeProfile->snapshot"), 'controller does not pass company-scoped profile');
foreach (['Overview','Responsibilities','Work','Capabilities','Tools','Schedule','Delegations','Escalations','Performance','Outcomes','Runtime','History','Can do','Available now','Authorized now'] as $needle) {
    $assert(str_contains($view, $needle), 'Employee 360 UI missing '.$needle);
}
foreach (['Bound','Available','Authorized'] as $needle) $assert(str_contains($table, $needle), 'capability distinction missing '.$needle);
$assert(str_contains($view, 'Neither binding nor availability grants authority'), 'authority distinction warning missing');
$assert(str_contains($view, 'A dash means Titan Autonomy has not made a current decision'), 'unknown authorization must be explicit');
$assert(str_contains($team, 'staff.show'), 'Team Center does not link to Employee 360');
$assert(!str_contains($service.$view, 'tenant'.'_company_id'), 'Employee 360 must not use the retired company boundary');

echo "PASS: Employee 360 profile + capability reality contract\n";
