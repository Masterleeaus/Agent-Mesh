<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$migrationPath = $root . '/database/migrations/2026_08_21_000012_canonical_workforce_domain.php';
$ok(is_file($migrationPath), 'canonical Workforce domain migration must exist');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';

$tables = [
    'ext_titan_ai_workforce_organisations',
    'ext_titan_ai_workforce_role_definitions',
    'ext_titan_ai_workforce_responsibilities',
    'ext_titan_ai_workforce_role_responsibilities',
    'ext_titan_ai_workforce_actions',
    'ext_titan_ai_workforce_triggers',
    'ext_titan_ai_workforce_councils',
    'ext_titan_ai_workforce_council_memberships',
    'ext_titan_ai_workforce_delegations',
    'ext_titan_ai_workforce_escalations',
    'ext_titan_ai_workforce_evidence',
    'ext_titan_ai_workforce_outcomes',
    'ext_titan_ai_workforce_performance_metrics',
];
foreach ($tables as $table) {
    $ok(str_contains($migration, "Schema::create('{$table}'"), "missing canonical domain table {$table}");
}

foreach (['organisation_id','created_by_user_id','activated_by_user_id'] as $column) {
    $ok(str_contains($migration, "'{$column}'"), "member canonical identity column {$column} missing");
}
foreach (['work_type','expected_outcome','evidence_requirements'] as $column) {
    $ok(str_contains($migration, "'{$column}'"), "work item canonical column {$column} missing");
}

$models = [
    'WorkforceOrganisation', 'WorkforceRoleDefinition', 'WorkforceResponsibility', 'WorkforceRoleResponsibility',
    'WorkforceAction', 'WorkforceTrigger', 'WorkforceCouncil', 'WorkforceCouncilMembership',
    'WorkforceDelegation', 'WorkforceEscalation', 'WorkforceEvidence', 'WorkforceOutcome', 'WorkforcePerformanceMetric',
];
foreach ($models as $model) {
    $ok(is_file($root . '/System/Models/' . $model . '.php'), "missing canonical model {$model}");
}

$domain = $root . '/System/Support/CanonicalWorkforceDomain.php';
$ok(is_file($domain), 'CanonicalWorkforceDomain support contract must exist');
$domainText = is_file($domain) ? (string) file_get_contents($domain) : '';
foreach (['organisation','division','team','role','responsibility','member','work_item','action','trigger','council','delegation','handoff','escalation','evidence','outcome','performance'] as $object) {
    $ok(str_contains($domainText, "'{$object}'"), "canonical domain object {$object} missing");
}
$ok(str_contains($domainText, "'task' => 'work_item'"), 'legacy task terminology must map to canonical work_item');
$ok(str_contains($domainText, "'schedule' => 'trigger'"), 'legacy schedule terminology must map to canonical trigger');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$owns = $manifest['authority']['owns'] ?? [];
foreach (['workforce-role-definitions','workforce-responsibilities','workforce-actions','workforce-triggers','workforce-councils','workforce-delegations','workforce-escalations','workforce-evidence','workforce-outcomes','workforce-performance'] as $owned) {
    $ok(in_array($owned, $owns, true), "manifest must declare canonical ownership of {$owned}");
}
$ok(! in_array('workforce-role-definitions', $manifest['authority']['must_not_own'] ?? [], true), 'role definitions can no longer be declared external-only');

if ($failures !== []) {
    fwrite(STDERR, "FAIL canonical_workforce_domain_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS canonical_workforce_domain_contract_test\n";
