<?php
$root=dirname(__DIR__,2);
$classifier=file_get_contents($root.'/System/Zero/Intent/Services/ZeroBaselineIntentClassifier.php');
$provider=file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
if(str_contains($classifier,'App\\Extensions\\InteractionEngine\\')){fwrite(STDERR,"classifier is package-namespace coupled\n");exit(1);} 
if(!str_contains($classifier,'interaction-engine')){fwrite(STDERR,"classifier does not identify canonical interaction source\n");exit(1);} 
if(!str_contains($classifier,'legacy_fallback')){fwrite(STDERR,"legacy deterministic fallback removed\n");exit(1);} 
if(str_contains($classifier,'LocalBrain')||str_contains($classifier,'LocalLanguageEngine')){fwrite(STDERR,"Workforce imports private Interaction implementation\n");exit(1);} 
if(!str_contains($provider,"'titan.apps.interaction'")){fwrite(STDERR,"service provider does not wire stable Interaction service key\n");exit(1);} 
echo "PASS Interaction Engine canonical intent routing\n";
