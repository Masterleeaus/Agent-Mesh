<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$centerPath = $root.'/System/Services/WorkforceDelegationCenterService.php';
$delegationServicePath = $root.'/System/Services/WorkforceDelegationService.php';
$viewPath = $root.'/resources/views/workforce/delegations/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

foreach ([$centerPath,$delegationServicePath,$viewPath] as $file) $need(is_file($file), 'missing Delegation Center artifact: '.basename($file));
$center = @file_get_contents($centerPath) ?: '';
$delegationService = @file_get_contents($delegationServicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach (['delegator','delegate','responsibility','work_scope','start_at','end_at','active','expired','revoked','related_tasks','authority_boundary','reason','audit_history'] as $token) {
    $need(str_contains($center, $token) || str_contains($view, $token), "Delegation Center missing {$token}");
}
$need(str_contains($center, 'forCompany($companyId)'), 'Delegation Center must be company scoped');
$need(str_contains($center, "'authority_inherited' => false"), 'Delegation Center must expose authority_inherited=false');
$need(str_contains($center, "'execution_authority_granted' => false"), 'Delegation Center must expose execution_authority_granted=false');
$need(str_contains($delegationService, 'WorkforceDelegation::query()->create'), 'governed delegation must persist a WorkforceDelegation record');
$need(str_contains($delegationService, 'requires_fresh_execution_authorization'), 'delegation must require fresh execution authorization');
$need(str_contains($delegationService, 'delegator_may_expand_authority'), 'delegation scope must explicitly forbid expanding authority');
$need(str_contains($delegationService, "'authority_inherited' => false"), 'delegation service must never inherit authority');
$need(str_contains($controller, 'delegationsCenter'), 'Delegation Center controller action missing');
$need(str_contains($provider, "get('delegations'"), 'Delegation Center route missing');
$need(str_contains($nav, 'Delegations'), 'Delegation Center navigation item missing');
foreach (['Delegator','Delegate','Responsibility','Work scope','Start / end','Active','Expired','Revoked','Related tasks','Authority boundary','Reason','Audit history'] as $label) {
    $need(str_contains($view, $label), "Delegation Center UI missing {$label}");
}
$need(str_contains($view, 'Delegation never grants executable capability'), 'Delegation Center must state the authority boundary plainly');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Delegation Center contract\n";
