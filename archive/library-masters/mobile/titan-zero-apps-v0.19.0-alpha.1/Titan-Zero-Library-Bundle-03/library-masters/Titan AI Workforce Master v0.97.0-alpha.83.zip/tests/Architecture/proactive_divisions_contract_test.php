<?php

declare(strict_types=1);

function fail_proactive(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_proactive(bool $condition, string $message): void { if (! $condition) fail_proactive($message); }

$root = dirname(__DIR__, 2);
ok_proactive(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'central domain responsibility catalogue must be absent');

$registry = (string) file_get_contents($root . '/System/Support/WorkforceResponsibilityRegistry.php');
ok_proactive(str_contains($registry, "'role_routines_source' => 'extension_manifest_only'"), 'responsibilities must be extension-manifest-only');
ok_proactive(str_contains($registry, 'explicitRoutinesForRole'), 'responsibility registry must read contributed manifest routines');
ok_proactive(! str_contains($registry, 'manager-morning-brief'), 'central Workforce must not invent default manager routines');
ok_proactive(! str_contains($registry, 'generic specialist'), 'central Workforce must not invent generic specialist work');

foreach (['/System/Services/ProactiveResponsibilityService.php','/System/Services/WorkforceQueueHealthService.php','/System/Services/ProactiveManagerService.php','/System/Console/Commands/SyncWorkforceResponsibilitiesCommand.php','/System/Console/Commands/RunWorkforceProactiveManagementCommand.php'] as $path) {
    ok_proactive(is_file($root . $path), basename($path) . ' missing');
}

$planningService = (string) file_get_contents($root . '/System/Services/WorkforcePlanningService.php');
ok_proactive(str_contains($planningService, 'role_definition_id'), 'planning must recognize active contributed role definitions');
ok_proactive(str_contains($planningService, 'WorkforceRoleRegistry::all()'), 'planning must consume aggregated extension role registry');

$queueHealth = (string) file_get_contents($root . '/System/Services/WorkforceQueueHealthService.php');
ok_proactive(str_contains($queueHealth, "whereNotIn('status', ['OFFLINE','SUSPENDED'])"), 'queue capacity must exclude offline/suspended staff');

$responsibilitySync = (string) file_get_contents($root . '/System/Services/ProactiveResponsibilityService.php');
ok_proactive(str_contains($responsibilitySync, 'user_override'), 'manifest routine sync must preserve explicit user schedule overrides');
ok_proactive(str_contains($responsibilitySync, "['role_registry','extension_workforce_manifest']") && str_contains($responsibilitySync, "'is_active' => false"), 'stale previously-synced routines must remain deactivatable across legacy and manifest-owned sources');

$managerService = (string) file_get_contents($root . '/System/Services/ProactiveManagerService.php');
ok_proactive(str_contains($managerService, 'WorkforcePlanningService'), 'proactive manager must use Workforce Planning');
ok_proactive(str_contains($managerService, 'findSubstitute'), 'proactive manager must use governed workload sharing');
ok_proactive(str_contains($managerService, 'WorkforceTaskStatus::Assigned'), 'automatic rebalance must be limited to unstarted assigned work');
ok_proactive(str_contains($managerService, 'auto_activate'), 'staffing recommendations must preserve no-auto-hire semantics');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
ok_proactive(str_contains($provider, 'titan-workforce:sync-responsibilities'), 'responsibility sync scheduler missing');
ok_proactive(str_contains($provider, "'titan.workforce.responsibilities'"), 'responsibility adapter missing');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach (['titan-workforce.proactive-responsibilities','titan-workforce.queue-health','titan-workforce.proactive-management'] as $capability) {
    ok_proactive(in_array($capability, $manifest['capabilities'] ?? [], true), "manifest missing {$capability}");
}

echo "PASS: Titan AI Workforce proactive orchestration contract\n";
