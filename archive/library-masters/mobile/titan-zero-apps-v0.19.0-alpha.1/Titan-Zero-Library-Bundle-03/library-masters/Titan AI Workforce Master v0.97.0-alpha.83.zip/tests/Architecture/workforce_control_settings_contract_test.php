<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach(['System/Services/WorkforceControlSettingsService.php','resources/views/workforce/settings/index.blade.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing {$f}\n");exit(1);}}
$s=file_get_contents($root.'/System/Services/WorkforceControlSettingsService.php');
$c=file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$p=file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$v=file_get_contents($root.'/resources/views/workforce/settings/index.blade.php');
foreach(['notification_thresholds','fallback_policy','proactive_operations','review_policy','outcome_verification','staffing_policy','human_decision_policy','authority_ceiling','company_id','cannot_grant_capability'] as $n){if(strpos($s,$n)===false){fwrite(STDERR,"Service missing {$n}\n");exit(1);}}
foreach(['Workforce Controls','Notification thresholds','Fallback policy','Human decision policy','Authority ceiling'] as $n){if(strpos($v,$n)===false){fwrite(STDERR,"View missing {$n}\n");exit(1);}}
if(strpos($c,'workforceControlSettings')===false||strpos($c,'updateWorkforceControlSettings')===false||strpos($p,"control-settings")===false){fwrite(STDERR,"Routes/actions missing\n");exit(1);}
echo "workforce_control_settings_contract_test: PASS\n";
