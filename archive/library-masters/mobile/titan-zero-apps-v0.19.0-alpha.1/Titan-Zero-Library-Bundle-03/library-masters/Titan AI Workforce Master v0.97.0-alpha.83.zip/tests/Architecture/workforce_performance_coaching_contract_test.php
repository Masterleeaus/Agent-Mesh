<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforcePerformanceCoachingService.php';
$viewPath = $root.'/resources/views/workforce/analytics/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

$need(is_file($servicePath), 'Workforce Performance & Coaching service missing');
foreach (['strengths','weak_responsibilities','high_revision_rate','failed_handoffs','recurring_escalations','slow_execution','poor_outcome_conversion','recommendations'] as $needle) {
    $need(str_contains($service, "'{$needle}'") || str_contains($view, str_replace('_',' ', $needle)), "performance/coaching signal missing {$needle}");
}
foreach (['employee','role','team','division','responsibility','workflow'] as $dimension) {
    $need(str_contains($service, "'{$dimension}'"), "performance/coaching dimension missing {$dimension}");
}
$need(str_contains($service, 'WorkforceOutcome::query()->forCompany($companyId)'), 'coaching outcome analysis must be company scoped');
$need(str_contains($service, 'verified_at'), 'coaching outcomes must require verified outcomes');
$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'coaching task analysis must be company scoped');
$need(str_contains($service, 'WorkforceEscalation'), 'recurring escalations must use authoritative escalation records');
$need(str_contains($service, 'WorkforceHandoff'), 'failed handoffs must use authoritative handoff records');
$need(str_contains($service, 'WorkforceExecutionAttempt'), 'slow execution must use authoritative execution attempts');
$need(str_contains($service, "'authority_changed' => false"), 'coaching must explicitly state authority is unchanged');
$need(str_contains($service, "'autonomy_changed' => false"), 'coaching must explicitly state autonomy is unchanged');
$need(str_contains($service, "'capability_granted' => false"), 'coaching must not grant capabilities');
$need(str_contains($service, "'risk_ceiling_changed' => false"), 'coaching must not change risk ceiling');
$need(str_contains($service, "'automatic_reconfiguration' => false"), 'coaching recommendations must not auto-reconfigure workforce');
$need(str_contains($controller, 'performanceCoaching'), 'controller must inject Performance & Coaching projection');
$need(str_contains($view, 'Workforce Performance & Coaching'), 'Performance page must identify coaching workspace');
$need(str_contains($view, 'Verified outcomes drive coaching'), 'UI must explain verified-outcome basis');
$need(str_contains($view, 'Performance never increases authority or autonomy'), 'UI must expose authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Performance & Coaching contract\n";
