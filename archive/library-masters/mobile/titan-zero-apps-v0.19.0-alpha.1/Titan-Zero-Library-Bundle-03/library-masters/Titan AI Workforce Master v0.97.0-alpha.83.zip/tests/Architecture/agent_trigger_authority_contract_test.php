<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$need = static function (bool $ok, string $message) use (&$errors): void { if (! $ok) $errors[] = $message; };
$text = static function (string $rel) use ($root, $need): string {
    $path = $root . '/' . $rel;
    $need(is_file($path), 'missing ' . $rel);
    return is_file($path) ? (string) file_get_contents($path) : '';
};
$ingress = $text('System/Services/AgentTriggerSignalIngressService.php');
$bridge = $text('System/Services/AgentWorkflowRuntimeBridge.php');
$dispatch = $text('System/Console/Commands/DispatchDueWorkforceSchedulesCommand.php');
$job = $text('System/Jobs/ProcessWorkforceTaskJob.php');
$provider = $text('System/TitanAIWorkforceServiceProvider.php');
$need(str_contains($ingress, "titan.agent-trigger/1"), 'trigger ingress must require titan.agent-trigger/1');
$need(str_contains($ingress, "agent.runtime.trigger.requested"), 'trigger ingress event type missing');
$need(str_contains($ingress, "execution_claimed"), 'trigger ingress must reject execution claims');
$need(str_contains($ingress, "origin_type' => 'agent_runtime_trigger'"), 'trigger ingress must create Workforce-owned trigger task');
$need(str_contains($bridge, "titan.agent-runtime.workflow/1"), 'agent workflow runtime bridge transport missing');
$need(str_contains($bridge, "status'] ?? null) === 'failed'"), 'failed agent workflow runs must fail Workforce processing rather than submit as success');
$need(str_contains($job, 'AgentWorkflowRuntimeBridge $legacyWorkflow'), 'Workforce task job must route legacy trigger tasks via subordinate bridge');
$need(str_contains($provider, 'AgentTriggerSignalIngressService::EVENT_TYPE'), 'Titan Signal listener must route Agent triggers to Workforce ingress');
$need(str_contains($provider, "'titan.ai-workforce.agent-trigger/1'"), 'Workforce trigger receiver binding missing');
if ($errors) { fwrite(STDERR, "TITAN_WORKFORCE_PASS7: FAIL\n" . implode("\n", array_map(fn($e)=>'ERROR: '.$e,$errors)) . "\n"); exit(1); }
echo "TITAN_WORKFORCE_PASS7: PASS\n";
