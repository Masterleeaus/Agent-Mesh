<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$rolesPath = $root . '/resources/workforce/role-definitions.json';
$ok(is_file($rolesPath), 'intrinsic role catalogue must exist');
$roles = [];
if (is_file($rolesPath)) {
    $decoded = json_decode((string) file_get_contents($rolesPath), true);
    $ok(is_array($decoded), 'intrinsic role catalogue must be valid JSON array');
    $roles = is_array($decoded) ? $decoded : [];
}

$divisionPath = $root . '/resources/workforce/division-definitions.json';
$divisions = is_file($divisionPath) ? json_decode((string) file_get_contents($divisionPath), true) : [];
$divisionKeys = [];
foreach (is_array($divisions) ? $divisions : [] as $division) $divisionKeys[(string) ($division['key'] ?? '')] = true;

$ok(count($roles) === 115, 'intrinsic role catalogue must contain exactly 115 roles');
$roleIds = [];
$keys = [];
$managers = [];
foreach ($roles as $role) {
    $roleId = (string) ($role['role_definition_id'] ?? '');
    $key = (string) ($role['key'] ?? '');
    $divisionKey = (string) ($role['division_key'] ?? '');
    $roleIds[] = $roleId;
    $keys[] = $key;

    $ok(str_starts_with($roleId, 'titan.'), "role {$key} must have stable titan.* role_definition_id");
    $ok($key !== '', "role {$roleId} key missing");
    $ok(is_string($role['name'] ?? null) && trim((string) $role['name']) !== '', "role {$key} name missing");
    $ok(is_string($role['purpose'] ?? null) && trim((string) $role['purpose']) !== '', "role {$key} purpose missing");
    $ok(in_array((int) ($role['tier'] ?? 0), [1,2], true), "role {$key} tier invalid");
    $ok(isset($divisionKeys[$divisionKey]), "role {$key} references unknown division {$divisionKey}");
    $ok(is_string($role['team_key'] ?? null) && trim((string) $role['team_key']) !== '', "role {$key} team boundary missing");
    $ok(is_array($role['responsibilities'] ?? null) && count($role['responsibilities']) >= 1, "role {$key} responsibilities missing");
    $ok(is_array($role['recommended_skills'] ?? null) && count($role['recommended_skills']) >= 1, "role {$key} recommended skills missing");
    $ok(is_array($role['vertical_applicability'] ?? null) && count($role['vertical_applicability']) >= 1, "role {$key} vertical applicability missing");
    $ok(is_array($role['recommended_business_maturity'] ?? null), "role {$key} business maturity missing");
    $ok(isset($role['recommended_business_maturity']['min']) && isset($role['recommended_business_maturity']['max']), "role {$key} maturity range incomplete");
    $ok(($role['activation_rules']['auto_activate'] ?? null) === false, "role {$key} must not auto-activate during Pass 4");

    $reportsTo = $role['reports_to_role_definition_id'] ?? null;
    if ($reportsTo !== null && $reportsTo !== '') $managers[$roleId] = (string) $reportsTo;
}

$ok(count(array_unique($roleIds)) === 115, 'role_definition_id values must be unique');
$ok(count(array_unique($keys)) === 115, 'role keys must be unique');
foreach ($managers as $roleId => $managerRoleId) {
    $ok(in_array($managerRoleId, $roleIds, true) || $managerRoleId === 'titan.executive.business_manager', "role {$roleId} reports to missing role {$managerRoleId}");
    $ok($roleId !== $managerRoleId, "role {$roleId} must not report to itself");
}

$operationsManager = null;
foreach ($roles as $role) if (($role['role_definition_id'] ?? '') === 'titan.manager.operations') $operationsManager = $role;
$ok(is_array($operationsManager), 'Operations Manager must exist');
if (is_array($operationsManager)) {
    $ok(($operationsManager['reports_to_role_definition_id'] ?? null) === 'titan.executive.business_manager', 'Operations Manager must report to AI Business Manager from executive layer Pass 6');
}

$migrationPath = $root . '/database/migrations/2026_08_21_000014_restore_intrinsic_role_catalogue.php';
$ok(is_file($migrationPath), 'Pass 4 intrinsic role migration must exist');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
foreach (['reports_to_role_definition_id','responsibilities','recommended_skills','vertical_applicability','recommended_business_maturity','activation_rules','risk_ceiling','maturity_default'] as $column) {
    $ok(str_contains($migration, "'{$column}'"), "Pass 4 migration missing {$column}");
}
$ok(str_contains($migration, 'role-definitions.json'), 'Pass 4 migration must seed from canonical role catalogue');
$ok(! str_contains($migration, "DB::table('ext_titan_ai_workforce_members')->insert"), 'Pass 4 must not auto-create employee instances');

$catalogPath = $root . '/System/Support/IntrinsicRoleCatalog.php';
$ok(is_file($catalogPath), 'IntrinsicRoleCatalog support contract missing');
$catalog = is_file($catalogPath) ? (string) file_get_contents($catalogPath) : '';
$ok(str_contains($catalog, 'role-definitions.json'), 'IntrinsicRoleCatalog must read canonical role definitions');
$ok(str_contains($catalog, 'role_definition_id'), 'IntrinsicRoleCatalog must expose canonical role_definition_id');

$registryPath = $root . '/System/Support/WorkforceRoleRegistry.php';
$registry = is_file($registryPath) ? (string) file_get_contents($registryPath) : '';
$ok(str_contains($registry, 'IntrinsicRoleCatalog'), 'WorkforceRoleRegistry must expose intrinsic roles');
$ok(str_contains($registry, 'intrinsic_workforce_catalogue'), 'intrinsic roles must retain provenance');

$modelPath = $root . '/System/Models/WorkforceRoleDefinition.php';
$model = is_file($modelPath) ? (string) file_get_contents($modelPath) : '';
foreach (['responsibilities','recommended_skills','vertical_applicability','recommended_business_maturity','activation_rules'] as $cast) {
    $ok(str_contains($model, "'{$cast}' => 'array'"), "WorkforceRoleDefinition missing {$cast} cast");
}

if ($failures !== []) {
    fwrite(STDERR, "FAIL intrinsic_role_catalogue_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS intrinsic_role_catalogue_contract_test\n";
