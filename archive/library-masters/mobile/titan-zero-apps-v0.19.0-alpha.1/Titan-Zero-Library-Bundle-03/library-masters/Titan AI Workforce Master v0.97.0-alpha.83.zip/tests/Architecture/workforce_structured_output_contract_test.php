<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$fail = static function (string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); };
$service = file_get_contents($root.'/System/Services/WorkforceStructuredOutputService.php');
$bridge = file_get_contents($root.'/System/Services/WorkforceAIRuntimeBridge.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');

foreach (['presentation_intent','capability_result','recommended_components','recommended_actions','confidence','evidence'] as $field) {
    if (! str_contains($service, "'{$field}'")) $fail("structured output missing {$field}");
}
foreach (['execution_authority_granted','self_authorization_allowed','arbitrary_executable_ui_allowed','command_bus_recheck_required'] as $guard) {
    if (! str_contains($service, $guard)) $fail("structured output missing safety guard {$guard}");
}
if (! str_contains($service, "'company_boundary' => 'company_id'")) $fail('company_id boundary declaration missing');
if (! str_contains($bridge, 'WorkforceStructuredOutputService $structuredOutput')) $fail('AI runtime bridge must depend on structured output normalizer');
if (! str_contains($bridge, '$this->structuredOutput->normalize($task, $member, $response->legacyOutput())')) $fail('AI runtime bridge must normalize all runtime proposals');
if (! str_contains($provider, 'singleton(WorkforceStructuredOutputService::class)')) $fail('structured output service binding missing');
if (! str_contains($service, 'array_merge($runtimeOutput, $envelope)')) $fail('legacy output compatibility must remain additive');

echo "PASS: Workforce structured output architecture contract\n";
