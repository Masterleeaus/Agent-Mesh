<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceOutcomeIntelligenceService.php';
$viewPath = $root.'/resources/views/workforce/outcomes/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

$need(is_file($servicePath), 'Outcome Intelligence service missing');
$need(is_file($viewPath), 'Outcome Intelligence view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach (['tasks','responses','reviews','execution_count'] as $activity) {
    $need(str_contains($service, "'{$activity}'") || str_contains($view, $activity), "activity metric missing {$activity}");
}
foreach (['quotes_accepted','jobs_completed','invoices_paid','complaints_resolved','cancellations_prevented','reviews_received','customer_retention','recovered_revenue'] as $outcome) {
    $need(str_contains($service, "'{$outcome}'") || str_contains($view, $outcome), "business outcome missing {$outcome}");
}
foreach (['employee','role','team','division','responsibility','workflow'] as $dimension) {
    $need(str_contains($service, "'{$dimension}'") || str_contains($view, $dimension), "measurement dimension missing {$dimension}");
}
$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'task analytics must be company scoped');
$need(str_contains($service, 'WorkforceOutcome::query()->forCompany($companyId)'), 'outcome analytics must be company scoped');
$need(str_contains($service, 'verified_at'), 'business outcomes must distinguish verified outcomes');
$need(str_contains($service, "'activity_is_outcome' => false"), 'activity must not be treated as outcome evidence');
$need(str_contains($service, "'authority_inherited' => false"), 'Outcome Intelligence must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'Outcome Intelligence must not grant execution authority');
$need(str_contains($controller, 'outcomeIntelligence'), 'Outcome Intelligence controller action missing');
$need(str_contains($provider, "get('outcome-intelligence'"), 'Outcome Intelligence route missing');
$need(str_contains($nav, 'Outcome Intelligence'), 'Outcome Intelligence navigation item missing');
$need(str_contains($view, 'Activity is not outcome'), 'UI must explain activity/outcome separation');
$need(str_contains($view, 'Verified business outcomes'), 'UI must identify verified business outcomes');
$need(str_contains($view, 'does not grant execution authority'), 'UI must explain read-only authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Outcome Intelligence Center contract\n";
