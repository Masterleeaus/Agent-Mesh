<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$need = static function (bool $condition, string $message) use (&$errors): void { if (! $condition) $errors[] = $message; };
$text = static function (string $rel) use ($root, $need): string {
    $path = $root . '/' . $rel;
    $need(is_file($path), 'missing ' . $rel);
    return is_file($path) ? (string) file_get_contents($path) : '';
};

$service = $text('System/Services/AgentWorkflowProposalIngressService.php');
$provider = $text('System/TitanAIWorkforceServiceProvider.php');
$extension = json_decode($text('extension.json'), true);

$need(str_contains($service, 'final class AgentWorkflowProposalIngressService'), 'missing Agent workflow proposal ingress service');
$need(str_contains($service, 'requires_governance'), 'proposal ingress must require governance');
$need(str_contains($service, 'execution_claimed'), 'proposal ingress must reject execution claims');
$need(str_contains($service, 'agent-workflow:'), 'proposal ingress must derive deterministic idempotency key');
$need(str_contains($service, "'origin_type' => 'agent_runtime_legacy_workflow'"), 'proposal task origin must identify Agent workflow');
$need(str_contains($service, 'ProcessWorkforceTaskJob::dispatch'), 'accepted proposal must enter Workforce task processing');
$need(str_contains($provider, "'titan.ai-workforce.workflow-proposal/1'"), 'Workforce must bind the versioned Agent workflow proposal receiver');
$need(($extension['version'] ?? null) === '0.97.0-alpha.83', 'Workforce version must be 0.97.0-alpha.83');

if ($errors) {
    fwrite(STDERR, "TITAN_WORKFORCE_PASS6: FAIL\n" . implode("\n", array_map(fn($e) => 'ERROR: ' . $e, $errors)) . "\n");
    exit(1);
}

echo "TITAN_WORKFORCE_PASS6: PASS\n";
