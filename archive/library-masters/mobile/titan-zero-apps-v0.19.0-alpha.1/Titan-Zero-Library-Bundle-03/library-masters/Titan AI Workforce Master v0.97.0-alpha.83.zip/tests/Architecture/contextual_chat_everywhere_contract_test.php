<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/Services/WorkforceContextualConversationService.php',
    'resources/views/workforce/conversation/contextual.blade.php',
];
foreach ($required as $rel) {
    if (! is_file($root.'/'.$rel)) { fwrite(STDERR, "Missing {$rel}\n"); exit(1); }
}
$svc = file_get_contents($root.'/System/Services/WorkforceContextualConversationService.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$view = file_get_contents($root.'/resources/views/workforce/conversation/contextual.blade.php');

$needles = [
    "'employee'", "'team'", "'division'", "'task'", "'responsibility'", "'provider'", "'execution'", "'outcome'",
    'company_id', 'authority_inherited', 'execution_authority_granted',
    'requires_fresh_execution_authorization', 'private_reasoning_exposed',
];
foreach ($needles as $needle) {
    if (strpos($svc, $needle) === false) { fwrite(STDERR, "Context service missing {$needle}\n"); exit(1); }
}
if (strpos($provider, "contextual-chat/{type}/{id}") === false) { fwrite(STDERR, "Contextual chat route missing\n"); exit(1); }
if (strpos($controller, 'contextualWorkforceConversation') === false || strpos($controller, 'submitContextualWorkforceConversation') === false) {
    fwrite(STDERR, "Contextual controller actions missing\n"); exit(1);
}
if (strpos($view, 'Ask Workforce') === false || strpos($view, 'Context does not grant authority') === false) {
    fwrite(STDERR, "Contextual view safety copy missing\n"); exit(1);
}
echo "contextual_chat_everywhere_contract_test: PASS\n";
