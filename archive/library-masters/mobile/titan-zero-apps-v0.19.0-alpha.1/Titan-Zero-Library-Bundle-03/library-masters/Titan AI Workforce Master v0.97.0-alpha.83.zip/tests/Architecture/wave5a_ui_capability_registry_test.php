<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$svc=file_get_contents($root.'/System/Services/WorkforceUiCapabilityRegistryService.php');
$policy=json_decode(file_get_contents($root.'/resources/workforce/ui-capability-surface-policy.json'),true);
$checks=[
 'company boundary'=>str_contains($svc,'CROSS_COMPANY_UI_CONTEXT_REJECTED'),
 'provider/capability availability'=>str_contains($svc,'CAPABILITY_NOT_LIVE'),
 'entitlement'=>str_contains($svc,'ENTITLEMENT_REQUIRED'),
 'authority separate'=>str_contains($svc,"'execution_authority_granted'=>false"),
 'server recheck'=>str_contains($svc,"'server_recheck_required'=>true"),
 'hub scope boundary'=>str_contains($svc,'HUB_SCOPE_DENIED'),
 'go scope boundary'=>str_contains($svc,'GO_SCOPE_DENIED'),
 'chat mode'=>in_array('chat',$policy['decision_inputs'])===false && isset($policy['surfaces']['chat']),
 'voice first-class surface'=>isset($policy['surfaces']['voice']),
 'vision first-class surface'=>($policy['surfaces']['vision']['first_class']??false)===true,
 'zero surface'=>isset($policy['surfaces']['zero']),
 'go surface'=>isset($policy['surfaces']['go']),
 'hub surface'=>isset($policy['surfaces']['hub']),
 'onboarding journey'=>isset($policy['journeys']['onboarding']),
];
$failed=array_keys(array_filter($checks,fn($v)=>!$v));
if($failed){fwrite(STDERR,'FAIL: '.implode(', ',$failed).PHP_EOL);exit(1);}
echo 'Wave 5A UI capability registry contract: PASS ('.count($checks).'/'.count($checks).')'.PHP_EOL;
