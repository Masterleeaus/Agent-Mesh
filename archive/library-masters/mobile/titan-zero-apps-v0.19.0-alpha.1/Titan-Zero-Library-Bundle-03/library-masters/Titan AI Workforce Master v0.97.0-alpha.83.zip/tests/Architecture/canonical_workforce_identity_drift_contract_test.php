<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$identity = (string) file_get_contents($root . '/System/Runtime/RuntimeIdentity.php');
$ok(str_contains($identity, 'workforceRoleId: $member?->role_definition_id'), 'runtime identity must use canonical role_definition_id');
$ok(! str_contains($identity, 'role_definition_key'), 'runtime identity must not use nonexistent role_definition_key');
$ok(! str_contains($identity, '$member?->role ??'), 'runtime identity must not fall back to display role name');

$pre = (string) file_get_contents($root . '/System/Services/WorkforcePreExecutionGovernanceService.php');
$autonomy = (string) file_get_contents($root . '/System/Services/WorkforceAutonomyService.php');
$ok(str_contains($pre, "'vertical' => \$task->vertical"), 'pre-execution governance must use task.vertical');
$ok(! str_contains($pre, "data_get(\$task->metadata ?? [], 'vertical')"), 'pre-execution governance must not read metadata.vertical');
$ok(str_contains($autonomy, "'vertical' => \$this->nullableString(\$task->vertical)"), 'Autonomy key must use task.vertical');
$ok(! str_contains($autonomy, "data_get(\$task->metadata ?? [], 'vertical')"), 'Autonomy must not read metadata.vertical');

$lifecycle = (string) file_get_contents($root . '/System/Services/WorkforceMemberLifecycleService.php');
$ok(str_contains($lifecycle, "'created_by_user_id' => \$actorUserId"), 'member creation must preserve creator separately');
$ok(str_contains($lifecycle, "'activated_by_user_id' => \$actorUserId"), 'member activation must preserve activator separately');
$ok(! str_contains($lifecycle, "'user_id' => \$actorUserId"), 'autonomous member must not inherit activating human user_id');

$aiBridge = (string) file_get_contents($root . '/System/Services/WorkforceAIRuntimeBridge.php');
$legacyBridge = (string) file_get_contents($root . '/System/Services/AgentWorkflowRuntimeBridge.php');
$ok(str_contains($aiBridge, 'RuntimeIdentity::fromTask($task, $member, null)'), 'autonomous AI runtime must not impersonate member creator user_id');
$ok(str_contains($legacyBridge, "'user_id' => null"), 'legacy autonomous runtime bridge must not impersonate member creator user_id');

if ($failures !== []) {
    fwrite(STDERR, "FAIL canonical_workforce_identity_drift_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS canonical_workforce_identity_drift_contract_test\n";
