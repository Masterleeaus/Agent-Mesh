<?php
$root = dirname(__DIR__, 2);
$service = file_get_contents($root.'/System/Services/WorkforceVisualWorkGraphService.php');
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$view = file_get_contents($root.'/resources/views/workforce/tasks/graph.blade.php');
$show = file_get_contents($root.'/resources/views/workforce/tasks/show.blade.php');
$checks = [
  [$service, 'forCompany($companyId)', 'graph data must use canonical company_id scoping'],
  [$service, "'task','decision','review','handoff','execution','evidence','outcome'", 'all seven visual node types required'],
  [$service, 'WorkforceTaskDependency', 'dependency edges required'],
  [$service, 'WorkforceTaskHandoff', 'handoff nodes required'],
  [$service, 'WorkforceExecutionAttempt', 'execution nodes required'],
  [$service, 'WorkforceEvidence', 'evidence nodes required'],
  [$service, 'WorkforceOutcome', 'outcome nodes required'],
  [$service, "'authority_inherited' => false", 'visual graph cannot grant authority'],
  [$controller, 'WorkforceVisualWorkGraphService $visualWorkGraph', 'controller must consume visual graph service'],
  [$controller, "titan-ai-workforce::tasks.graph", 'controller graph view required'],
  [$provider, "name('tasks.graph')", 'visual graph route required'],
  [$view, 'data-work-node', 'visual node DOM anchors required'],
  [$view, 'work-graph-edges', 'SVG relationship overlay required'],
  [$view, "tasks.show", 'task graph must drill into task detail'],
  [$show, "tasks.graph", 'task detail must expose visual graph'],
];
foreach ($checks as [$haystack,$needle,$message]) { if (strpos($haystack,$needle) === false) { fwrite(STDERR,"FAIL: $message\n"); exit(1); } }
echo "PASS: visual work graph contract\n";
