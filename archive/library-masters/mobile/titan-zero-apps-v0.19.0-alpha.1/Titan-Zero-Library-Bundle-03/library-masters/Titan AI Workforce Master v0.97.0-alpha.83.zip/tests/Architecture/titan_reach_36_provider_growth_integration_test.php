<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};

$reg=$json('resources/workforce/ecosystem-capability-registry.json');
if(count($reg['providers']??[])!==38)$fail('provider count');
$keys=array_map(fn($p)=>$p['extension']['key'],$reg['providers']);
foreach(['titan-reach-campaigns','titan-reach-agent','titan-reach-pro','titan-reach-flow'] as $k)if(!in_array($k,$keys,true))$fail("missing {$k}");

$w=$json('resources/workforce/reach-growth-operations-workflows.json');
if(count($w['workflows']??[])!==4)$fail('workflow count');
$steps=0;foreach($w['workflows'] as $wf)$steps+=count($wf['steps']??[]);
if($steps!==13)$fail('stage count');

$s=$read('System/Services/WorkforceReachGrowthOperationsService.php');
foreach(['readiness(','prepare(','commit(','assertExecutableRoute','knowledge_preflight_required','publish_is_explicit'] as $n)if(!str_contains($s,$n))$fail("service {$n}");
if(str_contains($s,'tenant'.'_company_id'))$fail('legacy tenant');

$profiles=$json('resources/workforce/context-federation-profiles.json');
if(($profiles['profile_count']??null)!==21)$fail('context profile count');
foreach(['titan-reach-campaigns','titan-reach-agent','titan-reach-pro','titan-reach-flow'] as $pk){
    $found=false;foreach($profiles['profiles'] as $p)if(($p['provider']??null)===$pk){$found=true;if(($p['tenant_boundary']??null)!=='company_id')$fail("tenant {$pk}");}
    if(!$found)$fail("context profile {$pk}");
}

$ui=$json('resources/workforce/ui-capability-surface-policy.json');
$domains=$ui['surfaces']['zero']['visible_manager_domains']??[];
if(!in_array('growth',$domains,true))$fail('Growth manager not visible in BOS');
if(($ui['surfaces']['zero']['ai_identity']??null)!=='titan_zero_chief')$fail('Chief identity changed');

echo "PASS: Titan Reach 38-provider growth integration\n";
