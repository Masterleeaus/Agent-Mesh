<?php
declare(strict_types=1);

$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};

foreach([
 'System/Services/WorkforcePeoplePayrollOperationsService.php',
 'System/Services/WorkforceCustomerRevenueOperationsService.php',
 'System/Services/WorkforceFieldSchedulingResourceOperationsService.php',
 'System/Services/WorkforceFinanceControlCommercialIntelligenceService.php',
 'System/Services/WorkforceAuthorityGraphValidator.php',
 'System/Services/KnowledgeAuthorityPreflightService.php',
 'System/Services/WorkforceAdversarialExecutionGuard.php',
 'System/Services/WorkforceRecoveryDecisionService.php',
 'System/Services/WorkforceUnifiedObservabilityService.php',
 'System/Services/CostSovereigntyRouter.php',
 'System/Services/WorkforceUiCapabilityRegistryService.php',
] as $file) if(!is_file($root.'/'.$file))$fail("missing convergence feature {$file}");

$registry=$json('resources/workforce/ecosystem-capability-registry.json');
if(count($registry['providers']??[])!==38)$fail('38-provider registry drifted');

$ui=$json('resources/workforce/ui-capability-surface-policy.json');
if(($ui['tenant_key']??null)!=='company_id')$fail('UI registry tenant boundary');
if(($ui['surfaces']['zero']['ai_identity']??null)!=='titan_zero_chief')$fail('BOS Chief identity');
$managers=$ui['surfaces']['zero']['visible_manager_domains']??[];
foreach(['money','work','people','customer','growth','risk'] as $manager)if(!in_array($manager,$managers,true))$fail("BOS manager {$manager}");
if(($ui['surfaces']['go']['ai_identity']??null)!=='work_ai')$fail('Go AI identity');
if(($ui['surfaces']['hub']['ai_identity']??null)!=='customer_ai')$fail('Hub AI identity');

$exec=$read('System/Services/WorkforceExecutionService.php');
if(!str_contains($exec,'$this->adversarialGuard->assertSafe'))$fail('adversarial guard missing');
if(!str_contains($exec,'knowledge_preflight'))$fail('knowledge preflight persistence missing');

$routing=$read('System/Services/WorkforceProviderRoutingService.php');
if(!str_contains($routing,'cost_sovereignty_enforced'))$fail('cost sovereignty routing missing');

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
foreach([
 'WorkforceCustomerRevenueOperationsService::class',
 'WorkforceFieldSchedulingResourceOperationsService::class',
 'WorkforceFinanceControlCommercialIntelligenceService::class',
 'WorkforceAuthorityGraphValidator::class',
 'KnowledgeAuthorityPreflightService::class',
 'WorkforceUiCapabilityRegistryService::class',
] as $needle)if(!str_contains($sp,$needle))$fail("service provider lost {$needle}");

$knowledge=$json('resources/workforce/knowledge-authority-runtime-control.json');
if(($knowledge['failure_mode']??null)!=='fail_closed')$fail('knowledge preflight not fail closed');

echo "PASS: current Workforce + Wave5A three-way convergence\n";
