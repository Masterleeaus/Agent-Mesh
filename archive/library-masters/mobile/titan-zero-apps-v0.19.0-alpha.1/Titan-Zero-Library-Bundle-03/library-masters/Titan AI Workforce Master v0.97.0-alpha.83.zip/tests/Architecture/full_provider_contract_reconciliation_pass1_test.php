<?php
declare(strict_types=1);

$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$json=static function(string $r)use($root,$fail):array{
    $p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");
    $d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid JSON {$r}");return$d;
};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};

$r=$json('resources/workforce/provider-contract-reconciliation.json');
if(($r['summary']['provider_count']??null)!==38)$fail('provider count');
if(($r['summary']['unique_provider_identity_count']??null)!==38)$fail('provider identities not unique');
if(($r['summary']['invalid_role_binding_reference_count']??null)!==0)$fail('invalid binding references');
if(($r['summary']['responsibility_without_provider_count']??null)!==0)$fail('responsibility without provider');
if(($r['summary']['commands_with_normalized_execution_contract']??0)!==263)$fail('command reconciliation incomplete');
if(($r['summary']['signals_classified_count']??0)!==110)$fail('signal classification incomplete');
if(($r['safety']['provider_installation_grants_authority']??null)!==false)$fail('provider install authority');
if(($r['safety']['unbound_capability_auto_granted']??null)!==false)$fail('unbound capability auto grant');

$a=$json('resources/workforce/ecosystem-provider-aliases.json');
if(($a['canonical_provider_count']??null)!==38)$fail('alias provider count');
foreach([
 'titan_people'=>'titan-people','people'=>'titan-people',
 'titan_payroll'=>'titan-payroll','payroll'=>'titan-payroll',
 'titan_trust'=>'titan-trust','titantrust'=>'titan-trust',
 'onboarding'=>'onboarding-pro','onboardingpro'=>'onboarding-pro','titan-onboarding'=>'onboarding-pro',
 'reach-campaigns'=>'titan-reach-campaigns','reach-agent'=>'titan-reach-agent','reach-pro'=>'titan-reach-pro','reach-flow'=>'titan-reach-flow',
 'omnichannel'=>'titan-omnichannel','marketing-bot'=>'titan-omnichannel','bookings-quotes'=>'titan-bookings-quotes',
] as $alias=>$canonical)if(($a['aliases'][$alias]??null)!==$canonical)$fail("alias {$alias}");

$sig=$json('resources/workforce/provider-signal-classification.json');
if(count($sig['signals']??[])!==110)$fail('signal classification count');
foreach($sig['signals'] as $row){
    if(($row['signal_grants_authority']??null)!==false)$fail('signal grants authority');
    if(!in_array($row['classification']??null,['telemetry','work_trigger','outcome_evidence'],true))$fail('invalid signal class');
}

$registry=$json('resources/workforce/ecosystem-capability-registry.json');
$commands=0;
foreach($registry['providers'] as $p){
    foreach($p['commands']??[] as $cmd){
        $commands++;
        if(trim((string)($cmd['execution']??''))==='')$fail('command missing execution semantics');
        if(($cmd['requires_exact_provider_version_pin']??null)!==true)$fail('command not provider/version pinned');
        if(($cmd['requires_governance']??null)!==true)$fail('command not governed');
        if(($cmd['authority_inherited']??null)!==false)$fail('command inherits authority');
        if(($cmd['execution_authority_granted']??null)!==false)$fail('command grants authority');
    }
}
if($commands!==263)$fail('expected 251 commands');

$svc=$read('System/Services/WorkforceProviderContractReconciliationService.php');
foreach(['assertNoBlockingIssues','classification','telemetry','canonicalProviderKey'] as $needle)if(!str_contains($svc,$needle))$fail("service missing {$needle}");

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
if(!str_contains($sp,'WorkforceProviderContractReconciliationService::class'))$fail('service not registered');
if(!str_contains($sp,"'titan.workforce.provider-reconciliation'"))$fail('service alias missing');

echo "PASS: full provider contract reconciliation\n";
