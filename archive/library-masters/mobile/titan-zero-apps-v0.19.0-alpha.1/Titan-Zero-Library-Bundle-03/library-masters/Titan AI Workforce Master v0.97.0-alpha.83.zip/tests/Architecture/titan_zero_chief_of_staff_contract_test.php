<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$resourcePath = $root . '/resources/workforce/system-role-definitions.json';
$ok(is_file($resourcePath), 'Titan Zero system role catalogue must exist');
$roles = [];
if (is_file($resourcePath)) {
    $decoded = json_decode((string) file_get_contents($resourcePath), true);
    $ok(is_array($decoded), 'Titan Zero system role catalogue must be valid JSON array');
    $roles = is_array($decoded) ? $decoded : [];
}
$ok(count($roles) === 1, 'Pass 5 must define exactly one permanent system role');
$zero = $roles[0] ?? [];
$ok(($zero['role_definition_id'] ?? null) === 'titan.system.titan_zero', 'Titan Zero role_definition_id drift');
$ok(($zero['key'] ?? null) === 'titan-zero', 'Titan Zero key drift');
$ok(($zero['name'] ?? null) === 'Titan Zero', 'Titan Zero name drift');
$ok(($zero['role'] ?? null) === 'Chief of Staff', 'Titan Zero business role must be Chief of Staff');
$ok(($zero['definition_scope'] ?? null) === 'SYSTEM', 'Titan Zero must be a SYSTEM role');
$ok(($zero['permanent'] ?? null) === true, 'Titan Zero must be permanent');
$ok(($zero['consumes_seat'] ?? null) === false, 'Titan Zero must not consume a staffing seat');
$ok(($zero['owner_facing_interface'] ?? null) === true, 'Titan Zero must be owner-facing');
$ok(($zero['visibility_scope']['organisation'] ?? null) === 'ALL', 'Titan Zero must have organisation-wide visibility');
$ok(is_array($zero['coordination_permissions'] ?? null) && count($zero['coordination_permissions']) >= 5, 'Titan Zero coordination permissions missing');
$ok(($zero['executable_capabilities'] ?? null) === [], 'Titan Zero system role must not carry domain executable capabilities');
foreach (['risk','assurance','governance','autonomy'] as $engine) {
    $ok(($zero['bypass'][$engine] ?? null) === false, "Titan Zero must not bypass {$engine}");
}

$migrationPath = $root . '/database/migrations/2026_08_21_000015_titan_zero_chief_of_staff.php';
$ok(is_file($migrationPath), 'Pass 5 Titan Zero migration must exist');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
foreach (['member_kind','system_role_key','consumes_seat','is_permanent_system_role','visibility_scope','coordination_permissions'] as $column) {
    $ok(str_contains($migration, "'{$column}'"), "Titan Zero migration missing {$column}");
}
$ok(str_contains($migration, 'titan.system.titan_zero'), 'Titan Zero migration must seed the system RoleDefinition');
$ok(str_contains($migration, "'definition_scope' => 'SYSTEM'"), 'Titan Zero RoleDefinition must use SYSTEM scope');
$ok(str_contains($migration, "'consumes_seat' => false"), 'Titan Zero migration must preserve non-seat semantics');

$servicePath = $root . '/System/Services/TitanZeroChiefOfStaffService.php';
$ok(is_file($servicePath), 'TitanZeroChiefOfStaffService missing');
$service = is_file($servicePath) ? (string) file_get_contents($servicePath) : '';
foreach (['ensureForCompany', "'system_role_key' => 'titan-zero'", "'consumes_seat' => false", "'is_permanent_system_role' => true", "'capabilities' => []"] as $needle) {
    $ok(str_contains($service, $needle), "Titan Zero ensure service missing {$needle}");
}
$ok(str_contains($service, "'user_id' => null"), 'Titan Zero autonomous identity must not borrow a human user_id');
$ok(str_contains($service, "'manager_id' => null"), 'Titan Zero must not report to an operational employee');

$modelPath = $root . '/System/Models/WorkforceMember.php';
$model = is_file($modelPath) ? (string) file_get_contents($modelPath) : '';
$ok(str_contains($model, "'consumes_seat' => 'boolean'"), 'WorkforceMember must cast consumes_seat');
$ok(str_contains($model, "'is_permanent_system_role' => 'boolean'"), 'WorkforceMember must cast permanent system-role flag');
$ok(str_contains($model, 'scopeStaffingSeats'), 'WorkforceMember must provide staffing-seat scope');
$ok(str_contains($model, "where('consumes_seat', true)"), 'staffing-seat scope must exclude Titan Zero');

$bootstrapPath = $root . '/System/Services/WorkforceBootstrapService.php';
$bootstrap = is_file($bootstrapPath) ? (string) file_get_contents($bootstrapPath) : '';
$ok(str_contains($bootstrap, 'TitanZeroChiefOfStaffService'), 'Workforce bootstrap must own Titan Zero lifecycle');
$ok(str_contains($bootstrap, 'ensureForCompany($companyId)'), 'Workforce bootstrap must ensure Titan Zero for every Workforce company');

$lifecyclePath = $root . '/System/Services/WorkforceMemberLifecycleService.php';
$lifecycle = is_file($lifecyclePath) ? (string) file_get_contents($lifecyclePath) : '';
$ok(str_contains($lifecycle, 'assertNotPermanentSystemRole'), 'member lifecycle must protect permanent system roles');
foreach (['suspend(', 'retire('] as $method) {
    $pos = strpos($lifecycle, 'public function '.$method);
    $guardPos = strpos($lifecycle, 'assertNotPermanentSystemRole', $pos === false ? 0 : $pos);
    $ok($pos !== false && $guardPos !== false, "{$method} must enforce permanent system-role guard");
}

$guardPath = $root . '/System/Services/TitanZeroAuthorityGuard.php';
$ok(is_file($guardPath), 'TitanZeroAuthorityGuard missing');
$guard = is_file($guardPath) ? (string) file_get_contents($guardPath) : '';
foreach (['risk','assurance','governance','autonomy','CONSEQUENTIAL_EXECUTION_REQUIRES_STANDARD_GOVERNANCE'] as $needle) {
    $ok(str_contains($guard, $needle), "Titan Zero authority guard missing {$needle}");
}

$executionPath = $root . '/System/Services/WorkforceExecutionService.php';
$execution = is_file($executionPath) ? (string) file_get_contents($executionPath) : '';
$ok(str_contains($execution, 'TitanZeroAuthorityGuard'), 'execution path must explicitly guard Titan Zero');
$ok(str_contains($execution, 'assertStandardGovernancePath'), 'Titan Zero execution must not bypass standard governance');

$providerPath = $root . '/System/TitanAIWorkforceServiceProvider.php';
$provider = is_file($providerPath) ? (string) file_get_contents($providerPath) : '';
$ok(str_contains($provider, "'titan.workforce.chief-of-staff'"), 'Titan Zero Chief-of-Staff service binding missing');
$ok(str_contains($provider, 'TitanZeroChiefOfStaffService::class'), 'Titan Zero service must be container-addressable');

if ($failures !== []) {
    fwrite(STDERR, "FAIL titan_zero_chief_of_staff_contract_test\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS titan_zero_chief_of_staff_contract_test\n";
