<?php

declare(strict_types=1);

require_once __DIR__ . '/../../System/Services/ManagerPlanValidator.php';

use App\Extensions\TitanAIWorkforce\System\Services\ManagerPlanValidator;

function fail_manager_ops(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_manager_ops(bool $condition, string $message): void { if (! $condition) fail_manager_ops($message); }

$roles = [
    'booking-coordinator' => ['key'=>'booking-coordinator','tier'=>2,'division'=>'customer','escalation_path'=>'customer-service-manager','capabilities'=>['coordinate_booking_work']],
    'customer-service-coordinator' => ['key'=>'customer-service-coordinator','tier'=>2,'division'=>'customer','escalation_path'=>'customer-service-manager','capabilities'=>['coordinate_customer_service_work']],
    'scheduler' => ['key'=>'scheduler','tier'=>2,'division'=>'work','escalation_path'=>'service-manager','capabilities'=>['perform_scheduler']],
    'billing-coordinator' => ['key'=>'billing-coordinator','tier'=>2,'division'=>'money','escalation_path'=>'finance-manager','capabilities'=>['draft_invoice']],
];
$validator = new ManagerPlanValidator(static fn (string $key): ?array => $roles[$key] ?? null);

$valid = [
    'plan_id' => 'plan-1',
    'steps' => [
        ['id'=>'capture','title'=>'Prepare booking request','role_key'=>'booking-coordinator','capability'=>'coordinate_booking_work','depends_on'=>[], 'handoff_to_division'=>'work','handoff_to_role_key'=>'scheduler','handoff_to_capability'=>'perform_scheduler'],
        ['id'=>'followup','title'=>'Confirm customer details','role_key'=>'customer-service-coordinator','capability'=>'coordinate_customer_service_work','depends_on'=>['capture']],
    ],
];
$result = $validator->validate($valid, 'customer', 'customer-service-manager');
ok_manager_ops(($result['valid'] ?? false) === true, 'valid contributed-role manager plan must pass');
ok_manager_ops(($result['steps'][0]['cross_division_handoff'] ?? false) === true, 'cross-division handoff must be explicit');

$result = $validator->validate($valid, 'customer', 'sales-manager');
ok_manager_ops(in_array('REPORTING_LINE_MISMATCH', array_column($result['errors'] ?? [], 'code'), true), 'reporting line mismatch missing');

$bad = $valid; $bad['steps'][0]['handoff_to_capability'] = 'draft_invoice';
$result = $validator->validate($bad, 'customer', 'customer-service-manager');
ok_manager_ops(in_array('HANDOFF_CAPABILITY_MISMATCH', array_column($result['errors'] ?? [], 'code'), true), 'handoff capability mismatch missing');

$bad = $valid; $bad['steps'][0]['role_key'] = 'imaginary-worker';
$result = $validator->validate($bad, 'customer', 'customer-service-manager');
ok_manager_ops(in_array('UNKNOWN_ROLE', array_column($result['errors'] ?? [], 'code'), true), 'unknown role reason missing');

$cycle = $valid; $cycle['steps'][0]['depends_on'] = ['followup'];
$result = $validator->validate($cycle, 'customer', 'customer-service-manager');
ok_manager_ops(in_array('DEPENDENCY_CYCLE', array_column($result['errors'] ?? [], 'code'), true), 'dependency cycle reason missing');

$wrongDivision = $valid; $wrongDivision['steps'][0]['role_key']='billing-coordinator'; $wrongDivision['steps'][0]['capability']='draft_invoice'; unset($wrongDivision['steps'][0]['handoff_to_division'],$wrongDivision['steps'][0]['handoff_to_role_key'],$wrongDivision['steps'][0]['handoff_to_capability']);
$result = $validator->validate($wrongDivision, 'customer', 'customer-service-manager');
ok_manager_ops(in_array('CROSS_DIVISION_DIRECT_ASSIGNMENT', array_column($result['errors'] ?? [], 'code'), true), 'cross-division direct assignment reason missing');

$root = dirname(__DIR__, 2);
foreach (['/System/Services/ManagerOperationsService.php','/System/Services/WorkforceDependencyService.php','/System/Services/WorkforceCouncilService.php','/System/Services/WorkforceDisputeService.php'] as $path) {
    ok_manager_ops(is_file($root . $path), basename($path) . ' missing');
}

$continuity = (string) file_get_contents($root . '/System/Services/ManagerContinuityService.php');
ok_manager_ops(str_contains($continuity, 'authority_inherited'), 'deputy relationship must prohibit authority inheritance');
$chain = (string) file_get_contents($root . '/System/Services/ChainOfCommandService.php');
ok_manager_ops(str_contains($chain, "'parent_task_id' => \$task->id"), 'cross-division handoff must create a child receiving task');
ok_manager_ops(str_contains($chain, 'receiving_capability'), 'handoff must carry receiving capability');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach (['titan-workforce.manager-operations','titan-workforce.councils','titan-workforce.disputes','titan-workforce.deputy-failover'] as $capability) {
    ok_manager_ops(in_array($capability, $manifest['capabilities'] ?? [], true), "manifest missing {$capability}");
}

echo "PASS: Titan AI Workforce manager operations contract\n";
