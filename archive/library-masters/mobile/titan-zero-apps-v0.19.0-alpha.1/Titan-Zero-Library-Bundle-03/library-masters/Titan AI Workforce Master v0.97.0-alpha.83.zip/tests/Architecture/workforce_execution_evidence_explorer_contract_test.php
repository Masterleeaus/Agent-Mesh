<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceExecutionEvidenceExplorerService.php';
$viewPath = $root.'/resources/views/workforce/execution-evidence/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$taskView = @file_get_contents($root.'/resources/views/workforce/tasks/show.blade.php') ?: '';

$need(is_file($servicePath), 'Execution & Evidence Explorer service missing');
$need(is_file($viewPath), 'Execution & Evidence Explorer view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach ([
    'task','employee','execution_intent','risk_assessment','assurance_result','governance_decision','autonomy_decision',
    'command_bus_command','execution_attempt','receipt','evidence','state_verification','rewind_recovery','final_outcome',
] as $surface) {
    $need(str_contains($service, $surface) || str_contains($view, $surface), "forensic search surface missing {$surface}");
}

$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'explorer tasks must be company scoped');
$need(str_contains($service, 'WorkforceMember::query()->forCompany($companyId)'), 'explorer employee lookup must be company scoped');
$need(str_contains($service, 'WorkforceEvidence::query()->forCompany($companyId)'), 'explorer evidence lookup must be company scoped');
$need(str_contains($service, 'WorkforceOutcome::query()->forCompany($companyId)'), 'explorer outcomes must be company scoped');
$need(str_contains($service, "where('company_id', \$companyId)"), 'explorer execution attempts must be company scoped');
$need(str_contains($service, "'authority_inherited' => false"), 'explorer must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'explorer must not grant execution authority');
$need(str_contains($controller, 'executionEvidenceExplorer'), 'explorer controller action missing');
$need(str_contains($provider, "get('execution-evidence'"), 'explorer route missing');
$need(str_contains($nav, 'Execution & Evidence'), 'explorer navigation item missing');
$need(str_contains($taskView, 'execution-evidence'), 'task detail must link to execution evidence explorer');
$need(str_contains($view, 'Read-only forensic projection'), 'explorer UI must explain read-only authority boundary');
$need(str_contains($view, 'Execution intent') && str_contains($view, 'Final outcome'), 'explorer must render consequential lifecycle evidence');
$need(str_contains($view, 'name="q"'), 'explorer must expose free-text forensic search');
$need(str_contains($view, 'name="type"'), 'explorer must expose evidence-type filter');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Execution & Evidence Explorer contract\n";
