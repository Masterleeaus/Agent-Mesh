<?php

declare(strict_types=1);

function fail_installer178(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_installer178(bool $condition, string $message): void { if (! $condition) fail_installer178($message); }

$root = dirname(__DIR__, 2);
$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
$sidecar = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

$expectedRootKeys = ['schema', 'slug', 'folder', 'provider', 'version', 'integrity'];
$actualRootKeys = array_keys($installer);
sort($expectedRootKeys);
sort($actualRootKeys);
ok_installer178($actualRootKeys === $expectedRootKeys, 'Installer 1.7.8 root extension.json must contain only the six canonical fields');
ok_installer178(($installer['schema'] ?? null) === 'titan-extension-v1', 'installer schema mismatch');
ok_installer178(($installer['slug'] ?? null) === 'titan-ai-workforce', 'installer slug mismatch');
ok_installer178(($installer['folder'] ?? null) === 'TitanAIWorkforce', 'installer folder mismatch');
ok_installer178(($installer['provider'] ?? null) === 'App\\Extensions\\TitanAIWorkforce\\System\\TitanAIWorkforceServiceProvider', 'installer provider mismatch');
ok_installer178(($installer['version'] ?? null) === '0.97.0-alpha.83', 'installer version mismatch');

$declared = $installer['integrity']['files'] ?? null;
ok_installer178(is_array($declared), 'integrity.files must be an object/map');
ok_installer178(! array_key_exists('extension.json', $declared), 'extension.json must be excluded from integrity.files');

$actual = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if (! $file->isFile() || $file->isLink()) continue;
    $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    if ($relative === 'extension.json') continue;
    $actual[$relative] = hash_file('sha256', $file->getPathname());
}
ksort($actual);
ksort($declared);
ok_installer178(array_keys($declared) === array_keys($actual), 'integrity.files must exactly match every regular package file except extension.json');
foreach ($actual as $path => $hash) {
    ok_installer178(($declared[$path] ?? null) === $hash, 'integrity hash mismatch: ' . $path);
}

ok_installer178(($sidecar['schema_version'] ?? null) === '2.2', 'rich sidecar must use canonical Manifest 2.2');
ok_installer178(($sidecar['architecture']['profile'] ?? null) === 'workforce-extension', 'sidecar architecture profile mismatch');
ok_installer178(($sidecar['architecture']['production_core'] ?? null) === 'titan.production.core.v1', 'production core inheritance missing');
ok_installer178(($sidecar['workforce']['source_of_truth'] ?? null) === 'central-runtime', 'central Workforce source_of_truth must be central-runtime');
ok_installer178(($sidecar['workforce']['auto_activate'] ?? true) === false, 'central Workforce must never auto-activate staff');
ok_installer178(($sidecar['workforce']['direct_domain_writes'] ?? true) === false, 'central Workforce may not write authoritative domain state directly');
ok_installer178(($sidecar['governance']['offline_never_increases_authority'] ?? false) === true, 'offline authority invariant missing');

ok_installer178(is_file($root . '/tools/build_installer_manifest.py'), 'package builder missing');
ok_installer178(is_file($root . '/tools/verify_zip.py'), 'ZIP verifier missing');
ok_installer178(is_file($root . '/tools/build_step11_package.py'), 'flat ZIP package builder missing');

echo "PASS: Installer 1.7.8 root manifest and Manifest 2.2 packaging contract\n";
