<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$manifest = json_decode((string) file_get_contents($root.'/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$service = (string) file_get_contents($root.'/System/Services/WorkforceStructuredOutputService.php');
$runtime = (string) file_get_contents($root.'/System/Zero/Interaction/Services/ZeroGenerativeInteractionRuntime.php');
$fail = static function (string $m): never { fwrite(STDERR, "FAIL: {$m}\n"); exit(1); };
$contributions = array_values(array_filter((array)($manifest['contributions'] ?? []), static fn($c) => is_array($c) && ($c['registry'] ?? null) === 'interface.semantic-contributions'));
if ($contributions === []) $fail('Workforce semantic interface contribution is not declared');
if (($contributions[0]['mode'] ?? null) !== 'semantic-only') $fail('Workforce contribution is not semantic-only');
if (! str_contains($service, "'composition_owner' => 'titan_apps_interface_runtime'")) $fail('Interface Runtime ownership not declared');
if (! str_contains($service, "'editing_owner' => 'titan_apps_builder'")) $fail('Builder ownership not declared');
if (! str_contains($runtime, "'component_source'=>'governed_component_registry'")) $fail('Zero runtime no longer uses governed component registry');
if (! str_contains($runtime, "'arbitrary_code_generation'=>false")) $fail('Zero runtime permits arbitrary code generation');
if (str_contains($service, 'TitanBuilder\\System\\') || str_contains($service, 'InterfaceRuntime\\System\\')) $fail('Workforce directly imports Titan Apps implementation internals');
echo "PASS: Interface Runtime + Builder contribution architecture contract\n";
