<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceEscalationDeadlockCenterService.php';
$viewPath = $root.'/resources/views/workforce/escalations/index.blade.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$chain = @file_get_contents($root.'/System/Services/ChainOfCommandService.php') ?: '';

$need(is_file($servicePath), 'Escalation & Deadlock Center service missing');
$need(is_file($viewPath), 'Escalation & Deadlock Center view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach (['Specialist','Manager','Division Manager','AI Business Manager','Titan Zero','Human'] as $tier) {
    $need(str_contains($service, $tier) || str_contains($view, $tier), "escalation tree missing {$tier}");
}
foreach (['reason','age','evidence','previous_decisions','blocked_downstream_work','required_resolver'] as $field) {
    $need(str_contains($service, $field) || str_contains($view, $field), "center missing {$field}");
}
foreach (['RETRY_WITH_EVIDENCE','RETURN_TO_MAKER','ESCALATE_TO_PARENT','HUMAN_DECISION_REQUIRED'] as $resolution) {
    $need(str_contains($view, $resolution) || str_contains($controller, $resolution), "center missing governed action {$resolution}");
}
$need(str_contains($controller, 'escalationDeadlockCenter'), 'center controller action missing');
$need(str_contains($controller, 'resolveEscalationCenterAction'), 'center governed action controller missing');
$need(str_contains($provider, "get('escalations'"), 'center route missing');
$need(str_contains($provider, "post('escalations/{task}/action'"), 'center action route missing');
$need(str_contains($nav, 'Escalations & Deadlocks'), 'center navigation item missing');
$need(str_contains($service, 'forCompany($companyId)'), 'center must be company scoped');
$need(str_contains($service, "'authority_inherited' => false"), 'center must expose no-authority-inheritance invariant');
$need(str_contains($service, "'execution_authority_granted' => false"), 'center must not grant execution authority');
$need(str_contains($chain, 'deadlock.retry_with_evidence'), 'retry-with-evidence must use governed chain service');
$need(str_contains($chain, 'deadlock.return_to_maker'), 'return-to-maker must use governed chain service');
$need(str_contains($chain, 'deadlock.human_required'), 'human-decision action must use governed chain service');
$need(str_contains($view, 'No escalation or deadlock action grants execution authority'), 'UI must explain authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Escalation & Deadlock Center contract\n";
