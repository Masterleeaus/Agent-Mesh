<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$ok = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$responsibilityPath = $root . '/resources/workforce/responsibility-definitions.json';
$assignmentPath = $root . '/resources/workforce/role-responsibility-assignments.json';
$schemaPath = $root . '/resources/workforce/responsibility-definition.schema.json';
$ok(is_file($responsibilityPath), 'intrinsic responsibility catalogue must exist');
$ok(is_file($assignmentPath), 'intrinsic role-responsibility assignment catalogue must exist');
$ok(is_file($schemaPath), 'responsibility definition schema must exist');

$responsibilities = is_file($responsibilityPath) ? json_decode((string) file_get_contents($responsibilityPath), true) : [];
$assignments = is_file($assignmentPath) ? json_decode((string) file_get_contents($assignmentPath), true) : [];
$roles = json_decode((string) file_get_contents($root . '/resources/workforce/role-definitions.json'), true);
$teams = json_decode((string) file_get_contents($root . '/resources/workforce/team-definitions.json'), true);
$divisions = json_decode((string) file_get_contents($root . '/resources/workforce/division-definitions.json'), true);
$responsibilities = is_array($responsibilities) ? $responsibilities : [];
$assignments = is_array($assignments) ? $assignments : [];
$roles = is_array($roles) ? $roles : [];
$teams = is_array($teams) ? $teams : [];
$divisions = is_array($divisions) ? $divisions : [];

$ok(count($responsibilities) === 118, 'intrinsic responsibility catalogue must contain exactly 118 v0.5 accountabilities');
$ok(count($assignments) === 118, 'role-responsibility assignment catalogue must contain exactly 118 assignments');

$roleIds = [];
$roleById = [];
foreach ($roles as $role) {
    $id = (string) ($role['role_definition_id'] ?? '');
    $roleIds[$id] = true;
    $roleById[$id] = $role;
}
$teamIds = [];
foreach ($teams as $team) $teamIds[(string) ($team['team_definition_id'] ?? '')] = true;
$divisionIds = [];
foreach ($divisions as $division) $divisionIds[(string) ($division['division_definition_id'] ?? '')] = true;

$definitionIds = [];
$keys = [];
foreach ($responsibilities as $definition) {
    $id = (string) ($definition['responsibility_id'] ?? '');
    $key = (string) ($definition['key'] ?? '');
    $definitionIds[$id] = true;
    $keys[$key] = true;
    $ok(str_starts_with($id, 'titan.responsibility.'), "responsibility {$key} must use stable titan.responsibility.* identity");
    $ok($key !== '', "responsibility {$id} key missing");
    $ok(is_string($definition['name'] ?? null) && trim((string) $definition['name']) !== '', "responsibility {$id} name missing");
    $ok(is_string($definition['description'] ?? null) && trim((string) $definition['description']) !== '', "responsibility {$id} description missing");
    $ok(isset($divisionIds[(string) ($definition['division_definition_id'] ?? '')]), "responsibility {$id} division missing or invalid");
    $ok(isset($teamIds[(string) ($definition['team_definition_id'] ?? '')]), "responsibility {$id} team missing or invalid");
    $ok(($definition['definition_scope'] ?? null) === 'INTRINSIC', "responsibility {$id} must be Workforce-owned");
    $ok(($definition['status'] ?? null) === 'ACTIVE', "responsibility {$id} must be active definition data");
    $ok(($definition['is_executable'] ?? null) === false, "responsibility {$id} must not grant executable authority");
    $ok(($definition['capability_authority'] ?? null) === 'NONE', "responsibility {$id} capability authority must be NONE");
    $ok(is_array($definition['vertical_applicability'] ?? null) && count($definition['vertical_applicability']) >= 1, "responsibility {$id} vertical applicability missing");
    $ok(is_array($definition['recommended_business_maturity'] ?? null), "responsibility {$id} business maturity missing");
    $source = (string) ($definition['metadata']['source'] ?? '');
    $ok(in_array($source, ['v0.5 intrinsic role responsibilities','Titan Payroll integration'], true), "responsibility {$id} source provenance missing");
    $ok(is_string($definition['metadata']['source_text'] ?? null) && trim((string) $definition['metadata']['source_text']) !== '', "responsibility {$id} source text missing");
}
$ok(count($definitionIds) === 118, 'responsibility IDs must be unique');
$ok(count($keys) === 118, 'responsibility keys must be unique');

$assignmentIds = [];
$assignmentsByRole = [];
foreach ($assignments as $assignment) {
    $roleId = (string) ($assignment['role_definition_id'] ?? '');
    $responsibilityId = (string) ($assignment['responsibility_id'] ?? '');
    $compound = $roleId . '|' . $responsibilityId . '|' . (string) ($assignment['assignment_type'] ?? '');
    $assignmentIds[$compound] = true;
    $assignmentsByRole[$roleId][] = $responsibilityId;
    $ok(isset($roleIds[$roleId]), "assignment references unknown role {$roleId}");
    $ok(isset($definitionIds[$responsibilityId]), "assignment references unknown responsibility {$responsibilityId}");
    $ok(($assignment['assignment_type'] ?? null) === 'PRIMARY', "assignment {$compound} must remain PRIMARY accountability");
    $ok(($assignment['is_required'] ?? null) === true, "assignment {$compound} must remain required");
    $ok(($assignment['authority_inherited'] ?? null) === false, "assignment {$compound} must not inherit authority");
}
$ok(count($assignmentIds) === 118, 'role-responsibility assignments must be unique');
$ok(count($assignmentsByRole) === 115, 'all 115 Workforce-owned roles must have accountability assignments');
$ok(count($assignmentsByRole['titan.manager.operations'] ?? []) === 4, 'Operations Manager must retain its four v0.5 accountabilities');

$roleResponsibilityIds = [];
foreach ($roles as $role) {
    $roleId = (string) ($role['role_definition_id'] ?? '');
    $ids = $role['responsibility_ids'] ?? null;
    $ok(is_array($ids) && count($ids) >= 1, "role {$roleId} canonical responsibility_ids missing");
    foreach (is_array($ids) ? $ids : [] as $id) {
        $roleResponsibilityIds[] = (string) $id;
        $ok(isset($definitionIds[(string) $id]), "role {$roleId} references unknown responsibility {$id}");
    }
    $expected = $assignmentsByRole[$roleId] ?? [];
    sort($expected);
    $actual = array_values(array_map('strval', is_array($ids) ? $ids : []));
    sort($actual);
    $ok($expected === $actual, "role {$roleId} responsibility_ids must match assignment catalogue");
}
$ok(count($roleResponsibilityIds) === 118, 'role definitions must expose exactly 118 responsibility references');

$catalogPath = $root . '/System/Support/IntrinsicResponsibilityCatalog.php';
$ok(is_file($catalogPath), 'IntrinsicResponsibilityCatalog missing');
$catalog = is_file($catalogPath) ? (string) file_get_contents($catalogPath) : '';
foreach (['responsibility-definitions.json', 'role-responsibility-assignments.json', 'function forRole', 'function assignmentsForRole'] as $needle) {
    $ok(str_contains($catalog, $needle), "IntrinsicResponsibilityCatalog missing {$needle}");
}

$registry = (string) file_get_contents($root . '/System/Support/WorkforceResponsibilityRegistry.php');
$ok(str_contains($registry, "'ownership' => 'titan-ai-workforce'"), 'responsibility registry must declare Workforce ownership');
$ok(str_contains($registry, "'routine_ownership' => 'contributing_extensions'"), 'proactive routine ownership must remain extension-owned until later passes');
$ok(str_contains($registry, 'accountabilitiesForRole'), 'responsibility registry must expose intrinsic role accountability lookup');
$ok(str_contains($registry, "'role_routines_source' => 'extension_manifest_only'"), 'Step 9 must not activate bundled proactive routines');

$migrationPath = $root . '/database/migrations/2026_08_22_000019_intrinsic_responsibilities.php';
$ok(is_file($migrationPath), 'Step 9 responsibility migration missing');
$migration = is_file($migrationPath) ? (string) file_get_contents($migrationPath) : '';
foreach (['responsibility-definitions.json', 'role-responsibility-assignments.json', "ext_titan_ai_workforce_responsibilities", "ext_titan_ai_workforce_role_responsibilities", "responsibility_ids"] as $needle) {
    $ok(str_contains($migration, $needle), "Step 9 migration missing {$needle}");
}
foreach (["ext_titan_ai_workforce_members')->insert", "ext_titan_ai_workforce_tasks')->insert", "ext_titan_ai_workforce_schedules')->insert", "ext_titan_ai_workforce_triggers')->insert"] as $forbidden) {
    $ok(! str_contains($migration, $forbidden), "Step 9 must not activate runtime work via {$forbidden}");
}

$roleModel = (string) file_get_contents($root . '/System/Models/WorkforceRoleDefinition.php');
$responsibilityModel = (string) file_get_contents($root . '/System/Models/WorkforceResponsibility.php');
$ok(str_contains($roleModel, "'responsibility_ids' => 'array'"), 'role model responsibility_ids cast missing');
foreach (["'vertical_applicability' => 'array'", "'recommended_business_maturity' => 'array'", "'is_executable' => 'boolean'"] as $cast) {
    $ok(str_contains($responsibilityModel, $cast), "responsibility model missing cast {$cast}");
}

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
$ok(str_contains($provider, 'titan.workforce.intrinsic-responsibilities'), 'intrinsic responsibility adapter missing');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$ok(in_array('titan-workforce.intrinsic-responsibilities-v1', $manifest['capabilities'] ?? [], true), 'manifest missing intrinsic responsibilities capability');

$ok(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'Step 9 must not restore scheduled/event proactive routine pack yet');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce intrinsic responsibilities contract (114 accountabilities / 111 roles)\n";
