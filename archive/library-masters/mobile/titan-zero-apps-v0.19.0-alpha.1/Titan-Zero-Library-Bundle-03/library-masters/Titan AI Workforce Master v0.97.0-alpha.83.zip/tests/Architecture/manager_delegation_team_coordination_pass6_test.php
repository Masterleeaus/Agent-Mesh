<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};
$c=$json('resources/workforce/manager-delegation-coordination.json');
if(($c['tenant_key']??null)!=='company_id')$fail('tenant');
foreach(['management_chain_required','same_responsibility_role_required','deterministic_provider_route_required','review_supported'] as $k)if(($c['delegation'][$k]??null)!==true)$fail("delegation {$k}");
foreach(['delegation_grants_authority','review_grants_authority','cross_company_delegation_allowed','cross_management_chain_delegation_allowed'] as $k)if(($c['safety'][$k]??null)!==false)$fail("safety {$k}");
$s=$read('System/Services/WorkforceManagerCoordinationService.php');
foreach(['workload(','teamSnapshot(','delegate(','review(','rebalance(','Delegation chain depth limit exceeded.','assertExecutableRoute','authority_inherited'] as $n)if(!str_contains($s,$n))$fail("service {$n}");
if(str_contains($s,'tenant'.'_company_id'))$fail('legacy tenant');
$m=$read('database/migrations/2026_08_23_000029_workforce_manager_delegation_coordination.php');
foreach(['review_required','reviewer_member_id','chain_depth','parent_delegation_id','ext_titan_ai_workforce_workload_snapshots','load_score'] as $n)if(!str_contains($m,$n))$fail("migration {$n}");
$sp=$read('System/TitanAIWorkforceServiceProvider.php');
if(!str_contains($sp,'WorkforceManagerCoordinationService::class'))$fail('registration');
echo "PASS: manager delegation and team coordination\n";
