<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};

$reg=$json('resources/workforce/ecosystem-capability-registry.json');
$provider=null;foreach($reg['providers'] as $p)if(($p['extension']['key']??null)==='onboarding-pro'){$provider=$p;break;}
if(!$provider)$fail('onboarding provider missing');
if(($provider['extension']['version']??null)!=='6.0.0-rc.2')$fail('onboarding version');
foreach(['onboarding.discovery.capture','onboarding.discovery.compile','onboarding.provisioning.prepare','onboarding.vertical.resolve','onboarding.nexus.read'] as $cap){
    $ids=array_map(fn($x)=>$x['id'],$provider['capabilities']??[]);
    if(!in_array($cap,$ids,true))$fail("missing capability {$cap}");
}
$profiles=$json('resources/workforce/context-federation-profiles.json');
$profile=null;foreach($profiles['profiles'] as $p)if(($p['provider']??null)==='onboarding-pro'){$profile=$p;break;}
if(!$profile)$fail('onboarding context profile');
if(($profile['provider_version']??null)!=='6.0.0-rc.2')$fail('context version');
if(($profile['surface_count']??0)!==25)$fail('context surface count');
foreach(['onboarding.nexus.opportunities','onboarding.nexus.diagnostics','onboarding.nexus.competitors','onboarding.nexus.benchmarks','onboarding.nexus.workforce-commands','onboarding.nexus.outcomes'] as $sid){
    if(!isset($profile['routes'][$sid]))$fail("missing Nexus context {$sid}");
    if(($profile['routes'][$sid]['storage_company_key']??null)!=='company_id')$fail("tenant {$sid}");
}
$rec=$json('resources/workforce/provider-contract-reconciliation.json');
if(($rec['summary']['provider_count']??0)!==38)$fail('provider count drift');
if(($rec['summary']['invalid_role_binding_reference_count']??1)!==0)$fail('invalid provider bindings');
echo "PASS: OnboardingPro Nexus v6 Workforce convergence\n";
