<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$authPath = $root.'/System/Host/TitanHostAuthorizationAdapter.php';
$permissionsPath = $root.'/System/Support/WorkforcePermissions.php';
$companyPath = $root.'/System/Support/CompanyContext.php';
$requestMiddlewarePath = $root.'/System/Http/Middleware/AuthorizeWorkforceRequest.php';
$queueMiddlewarePath = $root.'/System/Queue/Middleware/RestoreWorkforceTenantContext.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$processJobPath = $root.'/System/Jobs/ProcessWorkforceTaskJob.php';
$executeJobPath = $root.'/System/Jobs/ExecuteWorkforceActionJob.php';
$controllerPath = $root.'/System/Http/Controllers/WorkforceController.php';

foreach ([$authPath,$permissionsPath,$companyPath,$requestMiddlewarePath,$queueMiddlewarePath] as $path) {
    $assert(is_file($path), 'missing Pass 6 authorization/tenant file: '.basename($path));
}

$auth = @file_get_contents($authPath) ?: '';
foreach (['isSuperAdmin','isAdmin','checkPermission','hasPermissionTo','can('] as $needle) {
    $assert(str_contains($auth, $needle), "host authorization adapter missing {$needle}");
}
$assert(str_contains($auth, 'delegatedAdminPermissions'), 'delegated Admin access must be bounded by an explicit permission list');
$assert(str_contains($auth, 'return false'), 'ordinary users without explicit permission must fail closed');

$permissions = @file_get_contents($permissionsPath) ?: '';
foreach ([
    'titan-workforce.read',
    'titan-workforce.staff.add',
    'titan-workforce.staff.manage',
    'titan-workforce.tasks.review',
    'titan-workforce.tasks.reassign',
    'titan-workforce.staffing.approve',
    'titan-workforce.deadlocks.resolve',
    'titan-workforce.control-room',
] as $permission) {
    $assert(str_contains($permissions, $permission), "permission map missing {$permission}");
}

$company = @file_get_contents($companyPath) ?: '';
$assert(str_contains($company, "'company_id'"), 'CompanyContext must resolve canonical company_id');
$assert(str_contains($company, "'company_id'"), 'CompanyContext must use company_id as the sole canonical company boundary');
$assert(! str_contains($company, "'team_id'"), 'CompanyContext must not derive tenancy from team_id');
$assert(! str_contains($company, 'fromUserId'), 'CompanyContext must not derive tenancy from user_id');
$assert(! str_contains($company, '* 2'), 'CompanyContext must not synthesize tenant IDs arithmetically');
$assert(str_contains($company, 'runWith'), 'CompanyContext must support scoped background tenant restoration');
$assert(str_contains($company, 'clear'), 'CompanyContext must clear restored context after work');

$requestMiddleware = @file_get_contents($requestMiddlewarePath) ?: '';
$assert(str_contains($requestMiddleware, 'TitanHostAuthorizationAdapter'), 'request middleware must use host authorization adapter');
$assert(str_contains($requestMiddleware, 'CompanyContext::id'), 'request middleware must require canonical tenant context');
$assert(str_contains($requestMiddleware, 'CompanyContext::runWith'), 'request middleware must scope request execution to canonical tenant context');

$queueMiddleware = @file_get_contents($queueMiddlewarePath) ?: '';
$assert(str_contains($queueMiddleware, 'CompanyContext::runWith'), 'queue middleware must restore tenant context for the job');
$assert(str_contains($queueMiddleware, 'companyId'), 'queue middleware must carry immutable companyId');

foreach ([$processJobPath,$executeJobPath] as $path) {
    $job = @file_get_contents($path) ?: '';
    $assert(str_contains($job, 'RestoreWorkforceTenantContext'), basename($path).' must restore tenant context through queue middleware');
    $assert(str_contains($job, 'function middleware'), basename($path).' must declare tenant middleware');
}

$provider = @file_get_contents($providerPath) ?: '';
$assert(str_contains($provider, "aliasMiddleware('titan.workforce.authorize'"), 'provider must register Workforce authorization middleware alias');
foreach ([
    "'titan.workforce.authorize:titan-workforce.read'",
    "'titan.workforce.authorize:titan-workforce.staff.add'",
    "'titan.workforce.authorize:titan-workforce.staff.manage'",
    "'titan.workforce.authorize:titan-workforce.tasks.review'",
    "'titan.workforce.authorize:titan-workforce.tasks.reassign'",
    "'titan.workforce.authorize:titan-workforce.staffing.approve'",
    "'titan.workforce.authorize:titan-workforce.deadlocks.resolve'",
    "'titan.workforce.authorize:titan-workforce.control-room'",
] as $routePermission) {
    $assert(str_contains($provider, $routePermission), "route authorization map missing {$routePermission}");
}
$assert(str_contains($provider, "forCompany(CompanyContext::id(Auth::user()))"), 'route-model binding must remain tenant-scoped');

$schedulerTenantFiles = [
    $root.'/System/Services/ProactiveWorkforceService.php',
    $root.'/System/Services/ProactiveManagerService.php',
    $root.'/System/Services/ProactiveResponsibilityService.php',
    $root.'/System/Services/WorkforceSignalBridge.php',
];
foreach ($schedulerTenantFiles as $path) {
    $text = @file_get_contents($path) ?: '';
    $assert(str_contains($text, 'CompanyContext::runWith'), basename($path).' must restore canonical tenant context while processing cross-tenant scheduler/outbox rows');
}

$controller = @file_get_contents($controllerPath) ?: '';
$assert(! preg_match("/validate\\([^)]*company_id/s", $controller), 'controller must never accept authoritative company_id from request validation');


if (is_file($authPath) && is_file($permissionsPath) && is_file($companyPath)) {
    require_once $authPath;
    require_once $permissionsPath;
    require_once $companyPath;
    $authClass = 'App\\Extensions\\TitanAIWorkforce\\System\\Host\\TitanHostAuthorizationAdapter';
    $permissionClass = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\WorkforcePermissions';
    $companyClass = 'App\\Extensions\\TitanAIWorkforce\\System\\Support\\CompanyContext';
    $adapter = new $authClass();

    $ordinary = new class {
        public int $company_id = 41;
        public function can(string $permission): bool { return $permission === 'titan-workforce.read'; }
    };
    $assert($adapter->allows($ordinary, $permissionClass::READ, $permissionClass::delegatedAdminPermissions()), 'ordinary user with explicit read permission must be allowed');
    $assert(! $adapter->allows($ordinary, $permissionClass::STAFF_ADD, $permissionClass::delegatedAdminPermissions()), 'ordinary user without explicit mutation permission must be denied');

    $admin = new class {
        public int $company_id = 41;
        public function isAdmin(): bool { return true; }
    };
    $assert($adapter->allows($admin, $permissionClass::TASKS_REVIEW, $permissionClass::delegatedAdminPermissions()), 'delegated Admin must receive bounded Workforce permission');
    $assert(! $adapter->allows($admin, 'titan-workforce.unknown', $permissionClass::delegatedAdminPermissions()), 'delegated Admin must not receive undeclared permission');

    $super = new class {
        public int $company_id = 41;
        public function isSuperAdmin(): bool { return true; }
    };
    $assert($adapter->allows($super, 'titan-workforce.unknown', []), 'Super Admin must be the only unconditional platform bypass');

    $assert($companyClass::id($ordinary) === 41, 'CompanyContext must return exact company_id');
    $companyBoundActor = new class { public int $company_id = 41; public int $id = 7; public int $team_id = 3; };
    $assert($companyClass::id($companyBoundActor) === 41, 'company_id-bound actor must resolve the canonical company boundary');
    $missingCompany = new class { public int $id = 7; public int $team_id = 3; };
    $rejected = false;
    try { $companyClass::id($missingCompany); } catch (InvalidArgumentException) { $rejected = true; }
    $assert($rejected, 'team_id/user_id without company_id must fail closed');

    $inside = $companyClass::runWith(41, fn (): int => $companyClass::current());
    $assert($inside === 41, 'background runWith must restore exact company_id');
    $switched = false;
    try { $companyClass::runWith(41, fn () => $companyClass::runWith(42, fn () => null)); } catch (InvalidArgumentException) { $switched = true; }
    $assert($switched, 'nested background work must not switch company_id');
    $cleared = false;
    try { $companyClass::current(); } catch (InvalidArgumentException) { $cleared = true; }
    $assert($cleared, 'background tenant context must clear after runWith');
}

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Titan AI Workforce host authorization and tenant boundary contract\n";
