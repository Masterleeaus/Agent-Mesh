<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceDecisionRightsCenterService.php';
$viewPath = $root.'/resources/views/workforce/decision-rights/index.blade.php';
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$nav = file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$policyPath = $root.'/resources/workforce/organisation-policies.json';
$policy = json_decode((string) file_get_contents($policyPath), true, 512, JSON_THROW_ON_ERROR);

$need(is_file($servicePath), 'Decision Rights Center service missing');
$need(is_file($viewPath), 'Decision Rights Center view missing');
if (is_file($servicePath)) {
    $service = file_get_contents($servicePath) ?: '';
    foreach (['responsible','accountable','consulted','informed','reviewer','escalation_owner','human_required'] as $token) {
        $need(str_contains($service, $token), "Decision Rights Center service missing {$token}");
    }
    foreach (['forCompany($companyId)',"'authority_inherited' => false","'execution_authority_granted' => false"] as $token) {
        $need(str_contains($service, $token), "Decision Rights Center invariant missing {$token}");
    }
}
if (is_file($viewPath)) {
    $view = file_get_contents($viewPath) ?: '';
    foreach (['Responsible','Accountable','Consulted','Informed','Reviewer','Escalation owner','Human-required decisions','RACI does not grant executable capability'] as $label) {
        $need(str_contains($view, $label), "Decision Rights Center view missing {$label}");
    }
}
$rights = $policy['decision_rights'] ?? [];
$need(is_array($rights) && count($rights) >= 20, 'canonical decision-right catalogue must contain at least 20 populated entries');
foreach ($rights as $i => $right) {
    foreach (['decision','name','responsible','accountable','consulted','informed','reviewer','escalation_owner','human_required'] as $field) {
        $need(array_key_exists($field, $right), "decision_rights[{$i}] missing {$field}");
    }
    $need(($right['authority_inherited'] ?? null) === false, "decision_rights[{$i}] must set authority_inherited=false");
    $need(($right['execution_authority_granted'] ?? null) === false, "decision_rights[{$i}] must set execution_authority_granted=false");
}
$need(str_contains($controller, 'decisionRightsCenter'), 'controller Decision Rights Center action missing');
$need(str_contains($provider, "decision-rights-center"), 'Decision Rights Center route missing');
$need(str_contains($nav, "titan_workforce_decision_rights"), 'Decision Rights Center navigation item missing');

if ($failures !== []) {
    fwrite(STDERR, "FAIL workforce_decision_rights_raci_center_contract_test\n - ".implode("\n - ", $failures)."\n");
    exit(1);
}

echo "PASS workforce_decision_rights_raci_center_contract_test\n";
