<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceAttentionCenterService.php';
$viewPath = $root.'/resources/views/workforce/attention/index.blade.php';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$nav = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';

$need(is_file($servicePath), 'Attention Center service missing');
$need(is_file($viewPath), 'Attention Center view missing');
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';

foreach (['degraded_employee','blocked_work','manager_review','escalation','deadlock','missing_provider','policy_disabled','assurance_failure','autonomy_denial','execution_failure','unresolved_outcome','staffing_recommendation','human_decision_required'] as $category) {
    $need(str_contains($service, "'{$category}'"), "missing attention category {$category}");
}
foreach (['severity_score','business_impact_score','age_score','blocking_effect_score','priority_score'] as $field) {
    $need(str_contains($service, "'{$field}'"), "attention item missing {$field}");
}
$need(str_contains($service, "['severity_score'] *") && str_contains($service, "['business_impact_score'] *") && str_contains($service, "['age_score'] *") && str_contains($service, "['blocking_effect_score']"), 'priority must use severity × business impact × age × blocking effect');
$need(str_contains($service, 'forCompany($companyId)'), 'attention aggregation must be company scoped');
$need(str_contains($service, 'WorkforceCapabilityAvailabilityService'), 'attention must use live capability state');
$need(str_contains($service, "'authority_inherited' => false"), 'attention projection must not inherit authority');
$need(str_contains($provider, "get('attention'"), 'attention route missing');
$need(str_contains($provider, "name('attention')"), 'named attention route missing');
$need(str_contains($controller, 'attentionCenter'), 'controller attention action missing');
$need(str_contains($nav, 'Workforce Attention'), 'attention navigation item missing');
foreach (['Everything needing intervention','Severity','Business impact','Age','Blocking effect','Priority'] as $label) {
    $need(str_contains($view, $label), "attention UI missing {$label}");
}

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce Attention Center contract\n";
