<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) $failures[] = $message;
};

$validatorPath = $root.'/System/Services/WorkforceAuthorityGraphValidator.php';
$delegationPath = $root.'/System/Services/WorkforceDelegationService.php';
$continuityPath = $root.'/System/Services/ManagerContinuityService.php';
$providerPath = $root.'/System/TitanAIWorkforceServiceProvider.php';
$commandPath = $root.'/System/Console/Commands/ValidateWorkforceAuthorityGraphCommand.php';
$policyPath = $root.'/resources/workforce/chain-of-command-hardening.json';

foreach ([$validatorPath,$delegationPath,$continuityPath,$providerPath,$commandPath,$policyPath] as $path) {
    $assert(is_file($path), 'missing Wave 2A file: '.basename($path));
}

$validator = (string) @file_get_contents($validatorPath);
foreach (['validateCompany','assertCompany','assertDelegationAcyclic','assertSubstitutionAcyclic','validateReportingGraph','validateSubstitutionGraph','validateDelegations','validateResponsibilityOwnership','validateCouncilChairs'] as $method) {
    $assert(str_contains($validator, "function {$method}"), "authority validator missing {$method}");
}
foreach (['REPORTING_CYCLE','ORPHAN_MANAGER','DELEGATION_CYCLE','SUBSTITUTION_CYCLE','MULTIPLE_PRIMARY_RESPONSIBILITY_OWNERS','COUNCIL_CHAIR_AMBIGUOUS','EXPIRED_DELEGATION_ACTIVE','EXPIRED_SUBSTITUTION_ACTIVE','DELEGATION_AUTHORITY_EXPANSION_FORBIDDEN'] as $code) {
    $assert(str_contains($validator, $code), "authority validator missing {$code}");
}

$delegation = (string) @file_get_contents($delegationPath);
$assert(str_contains($delegation, 'WorkforceAuthorityGraphValidator $authorityGraph'), 'delegation service must receive authority graph validator');
$assert(str_contains($delegation, 'assertDelegationAcyclic'), 'delegation service must reject circular delegation before persistence');

$continuity = (string) @file_get_contents($continuityPath);
$assert(str_contains($continuity, 'WorkforceAuthorityGraphValidator $authorityGraph'), 'manager continuity must receive authority graph validator');
$assert(str_contains($continuity, 'assertSubstitutionAcyclic'), 'manager continuity must reject circular deputy substitution');
$assert(str_contains($continuity, 'Deputy expiry is required.'), 'temporary continuity must require expiry');
$assert(str_contains($continuity, 'Deputy scope is required.'), 'temporary continuity must require explicit scope');

$provider = (string) @file_get_contents($providerPath);
$assert(str_contains($provider, 'WorkforceAuthorityGraphValidator::class'), 'authority graph validator must be container registered');
$assert(str_contains($provider, "'titan.workforce.authority-graph-validator'"), 'stable authority graph adapter missing');
$assert(str_contains($provider, 'ValidateWorkforceAuthorityGraphCommand::class'), 'authority graph validation command missing');

$policy = json_decode((string) @file_get_contents($policyPath), true);
$assert(is_array($policy), 'hardening policy must be valid JSON');
$assert(($policy['tenant_key'] ?? null) === 'company_id', 'hardening policy must use canonical company_id');
$assert(($policy['delegation']['cycles_allowed'] ?? true) === false, 'delegation cycles must fail closed');
$assert(($policy['continuity']['substitution_cycles_allowed'] ?? true) === false, 'substitution cycles must fail closed');
$assert(($policy['responsibility']['multiple_primary_owners_allowed'] ?? true) === false, 'responsibility ownership must be unambiguous');
$assert(($policy['councils']['exactly_one_active_chair_required'] ?? false) === true, 'councils must have exactly one active chair');
$assert(($policy['escalation']['no_common_manager_action'] ?? null) === 'HUMAN_DECISION_REQUIRED', 'ambiguous escalation must terminate to human decision');
$assert(($policy['execution_authority_granted'] ?? true) === false, 'organisational graph must never grant execution authority');

if ($failures !== []) {
    foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n");
    exit(1);
}

echo "PASS: Wave 2A chain-of-command hardening contract\n";
