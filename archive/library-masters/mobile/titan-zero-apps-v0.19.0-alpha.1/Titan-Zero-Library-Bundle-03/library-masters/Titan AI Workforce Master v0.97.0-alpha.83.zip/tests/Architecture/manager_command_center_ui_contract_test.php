<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$service = file_get_contents($root.'/System/Services/WorkforceManagerCommandCenterService.php');
$controller = file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$provider = file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$view = file_get_contents($root.'/resources/views/workforce/manager/show.blade.php');
$workspace = file_get_contents($root.'/resources/views/workforce/workspace/show.blade.php');

$checks = [
    [$service, 'forCompany($companyId)', 'Manager Command Center must remain company_id scoped'],
    [$service, "'authority_inherited' => false", 'manager projections must never grant authority'],
    [$service, "'work_awaiting_review'", 'review queue required'],
    [$service, "'handoffs_received'", 'received handoff queue required'],
    [$service, "'handoffs_sent'", 'sent handoff queue required'],
    [$service, "'workload_imbalance'", 'workload imbalance required'],
    [$service, "'staff_availability'", 'staff availability required'],
    [$service, "'staffing_recommendations'", 'staffing recommendations required'],
    [$service, "'proactive_responsibilities'", 'proactive responsibility surface required'],
    [$service, "'team_outcomes'", 'team outcomes required'],
    [$controller, 'WorkforceManagerCommandCenterService $managerCommandCenter', 'controller must consume manager command service'],
    [$controller, 'public function managerWorkspace(WorkforceMember $member)', 'manager workspace action required'],
    [$controller, 'public function escalateTask(Request $request, WorkforceTask $task)', 'governed escalate action required'],
    [$controller, "'authority_inherited' => false", 'escalation must not transfer authority'],
    [$provider, "name('managers.show')", 'manager workspace route required'],
    [$provider, "name('tasks.escalate')", 'manager escalate route required'],
    [$view, 'My team', 'My team section required'],
    [$view, 'Work awaiting review', 'review label required'],
    [$view, 'Handoffs received', 'received handoffs section required'],
    [$view, 'Handoffs sent', 'sent handoffs section required'],
    [$view, 'Workload imbalance', 'workload section required'],
    [$view, 'Staffing recommendations', 'staffing section required'],
    [$view, 'Proactive responsibilities', 'proactive section required'],
    [$view, 'Team outcomes', 'outcome section required'],
    [$view, 'Approve', 'approve action required'],
    [$view, 'Request revision', 'revision action required'],
    [$view, 'Delegate', 'delegate action required'],
    [$view, 'Reassign', 'reassign action required'],
    [$view, 'Decompose', 'decompose action required'],
    [$view, 'Escalate', 'escalate action required'],
    [$view, 'Appoint deputy', 'deputy action required'],
    [$view, 'Resolve Deadlock', 'deadlock action affordance required'],
    [$workspace, "dashboard.user.titan-workforce.managers.show", 'team/division workspaces must link Manager Command Center'],
];
foreach ($checks as [$haystack,$needle,$message]) { if (! str_contains($haystack,$needle)) { fwrite(STDERR,"FAIL: $message\n"); exit(1); } }
echo "PASS: Manager Command Center UI contract\n";
