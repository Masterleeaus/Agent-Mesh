<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);$fail=static function(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);};
$read=static function(string $r)use($root,$fail):string{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");return(string)file_get_contents($p);};
$json=static function(string $r)use($root,$fail):array{$p=$root.'/'.$r;if(!is_file($p))$fail("missing {$r}");$d=json_decode((string)file_get_contents($p),true);if(!is_array($d))$fail("invalid {$r}");return$d;};
$c=$json('resources/workforce/finance-control-commercial-intelligence.json');
if(($c['tenant_key']??null)!=='company_id')$fail('tenant'); if(count($c['workflows']??[])!==4)$fail('workflow count');
foreach(['goal_planning_engine','work_item_graph','deterministic_provider_routes','manager_chain_enforced'] as $k)if(($c['coordination'][$k]??null)!==true)$fail("coord {$k}");
foreach(['receivable_recovery_explicit','cashflow_forecast_supported','profitability_review_supported','payables_reconciliation_supported','labour_cost_forecast_supported'] as $k)if(($c['finance'][$k]??null)!==true)$fail("finance {$k}");
foreach(['workflow_grants_authority','cross_company_operations_allowed','commit_dispatches_work'] as $k)if(($c['safety'][$k]??null)!==false)$fail("safety {$k}");
$w=$json('resources/workforce/finance-control-commercial-intelligence-workflows.json');$steps=0;foreach($w['workflows'] as $wf)$steps+=count($wf['steps']??[]);if($steps!==14)$fail('stage count');
$s=$read('System/Services/WorkforceFinanceControlCommercialIntelligenceService.php');foreach(['readiness(','prepare(','commit(','responsibilityFor(','assertExecutableRoute','financial_calculations_do_not_post_ledger_entries'] as $n)if(!str_contains($s,$n))$fail("service {$n}");
if(str_contains($s,'tenant'.'_company_id'))$fail('legacy tenant');
$m=$read('database/migrations/2026_08_25_000033_workforce_finance_control_commercial_intelligence.php');foreach(['ext_titan_ai_workforce_finance_control_cycles','company_id','invoice_ref','account_ref','readiness_report'] as $n)if(!str_contains($m,$n))$fail("migration {$n}");
echo "PASS: finance control commercial intelligence\n";
