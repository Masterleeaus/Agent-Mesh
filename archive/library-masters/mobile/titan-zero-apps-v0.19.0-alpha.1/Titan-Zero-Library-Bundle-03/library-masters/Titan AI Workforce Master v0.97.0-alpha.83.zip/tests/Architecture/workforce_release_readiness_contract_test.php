<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach(['System/Services/WorkforceReleaseReadinessService.php','resources/views/workforce/release-readiness/index.blade.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing {$f}\n");exit(1);}}
$s=file_get_contents($root.'/System/Services/WorkforceReleaseReadinessService.php');
$c=file_get_contents($root.'/System/Http/Controllers/WorkforceController.php');
$p=file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php');
$v=file_get_contents($root.'/resources/views/workforce/release-readiness/index.blade.php');
foreach(['company_id','architecture','tenancy','authority','providers','governance','outcomes','auditability','operational_health','release_gate','blocking_findings','authority_inherited','execution_authority_granted'] as $n){if(strpos($s,$n)===false){fwrite(STDERR,"Service missing {$n}\n");exit(1);}}
foreach(['Release Readiness','Release gate','Blocking findings','Architecture','Tenancy','Auditability'] as $n){if(strpos($v,$n)===false){fwrite(STDERR,"View missing {$n}\n");exit(1);}}
if(strpos($c,'workforceReleaseReadiness')===false||strpos($p,"release-readiness")===false){fwrite(STDERR,"Route/action missing\n");exit(1);}
echo "workforce_release_readiness_contract_test: PASS\n";
