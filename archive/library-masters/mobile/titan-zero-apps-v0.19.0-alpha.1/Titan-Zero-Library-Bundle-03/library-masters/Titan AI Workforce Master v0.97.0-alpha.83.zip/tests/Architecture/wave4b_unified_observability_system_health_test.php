<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$obs=file_get_contents($root.'/System/Services/WorkforceUnifiedObservabilityService.php');
$health=file_get_contents($root.'/System/Services/WorkforceSystemHealthService.php');
$view=file_get_contents($root.'/resources/views/workforce/system-health/index.blade.php');
$checks=[
 'correlation trace'=>str_contains($obs,'correlation_id'),
 'knowledge receipt lineage'=>str_contains($obs,'knowledge_receipt'),
 'risk lineage'=>str_contains($obs,'risk_reference'),
 'assurance lineage'=>str_contains($obs,'assurance_reference'),
 'autonomy lineage'=>str_contains($obs,'autonomy_reference'),
 'idempotency lineage'=>str_contains($obs,'idempotency_key'),
 'cost receipt lineage'=>str_contains($obs,"stage'=>'cost_receipt"),
 'outcome lineage'=>str_contains($obs,"stage'=>'outcome"),
 'stuck work health'=>str_contains($obs,'stuck_work'),
 'reconciliation health'=>str_contains($obs,'unresolved_reconciliation'),
 'provider incident health'=>str_contains($obs,'recent_provider_incidents'),
 'budget health'=>str_contains($obs,'resource_budgets'),
 'system health integration'=>str_contains($health,'observability_health'),
 'owner UI recovery health'=>str_contains($view,'Recovery & trace health'),
];
$failed=array_keys(array_filter($checks,fn($v)=>!$v));
if($failed){fwrite(STDERR,'FAIL: '.implode(', ',$failed).PHP_EOL);exit(1);}
echo 'Wave 4B unified observability/system health contract: PASS ('.count($checks).'/'.count($checks).')'.PHP_EOL;
