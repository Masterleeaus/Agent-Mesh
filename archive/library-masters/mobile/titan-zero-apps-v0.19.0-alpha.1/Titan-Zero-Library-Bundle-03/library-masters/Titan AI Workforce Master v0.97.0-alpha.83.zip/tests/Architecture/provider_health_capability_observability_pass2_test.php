<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$fail = static function (string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); };
$read = static function (string $rel) use ($root,$fail): string {
    $path=$root.'/'.$rel; if(!is_file($path))$fail("missing {$rel}"); return (string)file_get_contents($path);
};
$json = static function (string $rel) use ($root,$fail): array {
    $path=$root.'/'.$rel; if(!is_file($path))$fail("missing {$rel}");
    $decoded=json_decode((string)file_get_contents($path),true); if(!is_array($decoded))$fail("invalid JSON {$rel}"); return $decoded;
};

$c=$json('resources/workforce/provider-health-observability.json');
if(($c['tenant_key']??null)!=='company_id')$fail('tenant key');
$expected=['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];
if(($c['states']??[])!==$expected)$fail('six-state health model drifted');
foreach(['reports_version','reports_installation','reports_last_success','reports_last_failure','reports_impacted_roles','reports_context_adapter_status','reports_recovery_guidance'] as $key){
    if(($c['provider_snapshot'][$key]??null)!==true)$fail("provider snapshot {$key}");
}
foreach(['health_state_changes_role_identity','health_state_grants_authority','degradation_grants_fallback_authority','missing_provider_grants_substitute_authority'] as $key){
    if(($c['safety'][$key]??null)!==false)$fail("health safety {$key}");
}

$s=$read('System/Services/WorkforceProviderHealthObservabilityService.php');
foreach([
    'providerSnapshot','roleSnapshot','responsibilitySnapshot','recordSuccess','recordFailure',
    'last_success_at','last_failure_at','impacted_roles','recovery_guidance',
    'PROVIDER_CLASS_NOT_INSTALLED','Pause dependent Work Items',
    "'authority_inherited' => false","'fallback_authority_granted' => false"
] as $needle){
    if(!str_contains($s,$needle))$fail("health service missing {$needle}");
}
if(str_contains($s,'tenant'.'_company_id'))$fail('health service uses legacy tenant key');

$m=$read('database/migrations/2026_08_22_000026_workforce_provider_health_observability.php');
foreach(['company_id','provider_version','surface_type','surface_id','state','event_type','observed_at','recovered_at'] as $needle){
    if(!str_contains($m,$needle))$fail("health migration missing {$needle}");
}
if(str_contains($m,'tenant'.'_company_id'))$fail('health migration uses legacy tenant key');

$sp=$read('System/TitanAIWorkforceServiceProvider.php');
if(!str_contains($sp,'WorkforceProviderHealthObservabilityService::class'))$fail('health service not registered');
if(!str_contains($sp,"'titan.workforce.provider-health'"))$fail('health service alias missing');

$mf=$json('extension.manifest.json');
if(!in_array('titan-workforce.provider-health-observability-v1',$mf['capabilities']??[],true))$fail('manifest health capability missing');

$r=$json('resources/workforce/provider-contract-reconciliation.json');
if(($r['summary']['provider_count']??null)!==38)$fail('provider reconciliation provider count');

echo "PASS: provider health and capability observability contract\n";
