<?php

declare(strict_types=1);

function fail_loop(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok_loop(bool $condition, string $message): void { if (! $condition) fail_loop($message); }

$root = dirname(__DIR__, 2);

foreach ([
    '/System/Services/WorkforceOutcomeFeedbackService.php',
    '/System/Services/WorkforceTrustHealthService.php',
    '/System/Services/WorkforceVerticalOverlayService.php',
] as $path) {
    ok_loop(is_file($root . $path), basename($path) . ' missing');
}

$governance = (string) file_get_contents($root . '/System/Services/WorkforceGovernanceBridge.php');
ok_loop(str_contains($governance, "'role_definition_id'"), 'governance envelope must carry role definition identity');
ok_loop(str_contains($governance, "'manager_member_id'"), 'governance envelope must carry manager identity');
ok_loop(str_contains($governance, "'workflow_ref'"), 'governance envelope must carry Interaction workflow reference');
ok_loop(str_contains($governance, "'playbook_ref'"), 'governance envelope must carry playbook reference');
ok_loop(str_contains($governance, "'governance_complete'"), 'pre-execution governance completeness must be explicit');
ok_loop(str_contains($governance, 'prepareInteraction'), 'Interaction Engine adapter must exist');

$execution = (string) file_get_contents($root . '/System/Services/WorkforceExecutionService.php');
ok_loop(str_contains($execution, 'WorkforceOutcomeFeedbackService'), 'execution must forward observed outcomes');
ok_loop(str_contains($execution, "'execution.receipt_missing'"), 'executed commands without receipts must enter recovery');
ok_loop(str_contains($execution, 'WorkforceTaskStatus::Recovery'), 'missing-receipt execution must use recovery state');
ok_loop(str_contains($execution, "governance_complete"), 'execution must fail closed when governance engines are incomplete');

$outcome = (string) file_get_contents($root . '/System/Services/WorkforceOutcomeFeedbackService.php');
foreach (['WorkforceControlPlaneIntegrationRegistry',"bindingsFor('wisdom')","bindingsFor('rewind')",'WorkforceJourneySpineService','receipt_ref','outcome_ref'] as $needle) {
    ok_loop(str_contains($outcome, $needle), 'outcome feedback missing ' . $needle);
}

$health = (string) file_get_contents($root . '/System/Services/WorkforceTrustHealthService.php');
foreach (['risk','assurance','autonomy','engine_availability','blocked','recovery','escalated'] as $needle) {
    ok_loop(str_contains($health, $needle), 'trust health missing ' . $needle);
}

$vertical = (string) file_get_contents($root . '/System/Services/WorkforceVerticalOverlayService.php');
ok_loop(str_contains($vertical, 'titan.vertical-engine'), 'Vertical Engine adapter binding missing');
ok_loop(str_contains($vertical, "'available' => false"), 'Vertical Engine adapter must degrade safely when absent');


ok_loop(! is_file($root . '/resources/workforce/proactive-responsibilities.json'), 'governance follow-up must not depend on bundled domain role routines');
$eventTrigger = (string) file_get_contents($root . '/System/Services/WorkforceEventTriggerService.php');
ok_loop(str_contains($eventTrigger, 'WorkforceSchedule::query()'), 'Signal handling must use persisted schedules contributed/synchronised from extension manifests');
ok_loop(str_contains($eventTrigger, "'causation_id' => \$signalId"), 'signal-triggered tasks must directly cite the triggering signal as causation');

$provider = (string) file_get_contents($root . '/System/TitanAIWorkforceServiceProvider.php');
foreach ([
    "'titan.workforce.outcomes'",
    "'titan.workforce.trust-health'",
    "'titan.workforce.vertical-overlay'",
] as $binding) {
    ok_loop(str_contains($provider, $binding), 'provider missing ' . $binding);
}

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
foreach ([
    'titan-workforce.outcome-feedback',
    'titan-workforce.trust-health',
    'titan-workforce.vertical-overlays',
] as $capability) {
    ok_loop(in_array($capability, $manifest['capabilities'] ?? [], true), 'manifest missing ' . $capability);
}

$extension = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
ok_loop(($extension['version'] ?? null) === '0.97.0-alpha.83', 'extension version must be 0.97.0-alpha.83');
ok_loop(($manifest['version'] ?? null) === '0.97.0-alpha.83', 'manifest version must be 0.97.0-alpha.83');

fwrite(STDOUT, "PASS: governed intelligence loop architecture contract\n");
