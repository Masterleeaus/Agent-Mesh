<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$need = static function (bool $condition, string $message) use (&$failures): void { if (! $condition) $failures[] = $message; };

$servicePath = $root.'/System/Services/WorkforceConversationService.php';
$viewPath = $root.'/resources/views/workforce/conversation/index.blade.php';
$adapterPath = $root.'/System/TitanAI/WorkforceConversationSourceAdapter.php';
$controller = @file_get_contents($root.'/System/Http/Controllers/WorkforceController.php') ?: '';
$provider = @file_get_contents($root.'/System/TitanAIWorkforceServiceProvider.php') ?: '';
$navigation = @file_get_contents($root.'/System/Navigation/WorkforceNavigation.php') ?: '';
$service = @file_get_contents($servicePath) ?: '';
$view = @file_get_contents($viewPath) ?: '';
$adapter = @file_get_contents($adapterPath) ?: '';

$need(is_file($servicePath), 'Workforce conversation service missing');
$need(is_file($viewPath), 'Workforce conversation view missing');
foreach (['workforce_health','degraded_employees','work_awaiting_approval','create_governed_work_item'] as $needle) {
    $need(str_contains($service, "'{$needle}'") || str_contains($service, '"'.$needle.'"'), "conversation capability missing {$needle}");
}
$need(str_contains($service, 'WorkforceTask::query()->forCompany($companyId)'), 'conversation reads must be company scoped');
$need(str_contains($service, 'WorkforceMember::query()->forCompany($companyId)'), 'conversation employee resolution must be company scoped');
$need(str_contains($service, '$this->tasks->create($companyId'), 'delegated conversational requests must create governed Workforce tasks');
$need(str_contains($service, "'origin_type' => 'CONVERSATION'"), 'conversation-created work must preserve origin');
$need(str_contains($service, "'requires_fresh_execution_authorization' => true"), 'conversation-created work must require fresh execution authorization');
$need(str_contains($service, "'authority_inherited' => false"), 'conversation must never inherit authority');
$need(str_contains($controller, 'workforceConversation'), 'controller must expose conversational interface');
$need(str_contains($controller, 'submitWorkforceConversation'), 'controller must accept conversational requests');
$need(str_contains($provider, "get('conversation'"), 'conversation GET route missing');
$need(str_contains($provider, "post('conversation'"), 'conversation POST route missing');
$need(str_contains($navigation, 'Ask Workforce'), 'Ask Workforce navigation item missing');
$need(str_contains($adapter, 'WorkforceConversationService'), 'Titan AI conversation source must use Workforce conversation service');
$need(!str_contains($adapter, 'public function context(TitanAIRequest $request): array { return []; }'), 'Titan AI conversation context must no longer be empty');
$need(!str_contains($adapter, 'complete(TitanAIRequest $request, array $runtimeContext = []): ?array { return null; }'), 'Titan AI completion bridge must no longer be null');
$need(str_contains($view, 'Governed Work Item'), 'UI must explain governed Work Item creation');
$need(str_contains($view, 'does not grant execution authority'), 'UI must explain conversational authority boundary');

if ($failures !== []) { foreach ($failures as $failure) fwrite(STDERR, "FAIL: {$failure}\n"); exit(1); }
echo "PASS: Workforce conversational interface contract\n";
