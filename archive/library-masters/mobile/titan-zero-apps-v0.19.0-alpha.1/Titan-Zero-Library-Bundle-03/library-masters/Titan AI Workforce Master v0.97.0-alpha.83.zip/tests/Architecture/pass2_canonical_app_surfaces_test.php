<?php
$root=dirname(__DIR__,2);
$p=json_decode((string)file_get_contents($root.'/resources/workforce/ui-capability-surface-policy.json'),true);
$f=0;$c=function($x,$m)use(&$f){echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;};
$surfaces=$p['surfaces']??[];$aliases=$p['surface_aliases']??[];
$c(isset($surfaces['zero']),'zero is canonical Workforce surface');
$c(isset($surfaces['go']),'go is canonical Workforce surface');
$c(isset($surfaces['hub']),'hub is canonical Workforce surface');
$c(!isset($surfaces['titan_bos']),'titan_bos is not canonical surface');
$c(!isset($surfaces['onboarding']),'onboarding is not canonical surface');
foreach(['bos','command','owner','manager','business','titan_bos','titan_command'] as $a)$c(($aliases[$a]??null)==='zero',"{$a} alias resolves to zero");
foreach(['field','worker','titan_go'] as $a)$c(($aliases[$a]??null)==='go',"{$a} alias resolves to go");
foreach(['customer','titan_hub'] as $a)$c(($aliases[$a]??null)==='hub',"{$a} alias resolves to hub");
$c(($aliases['onboarding']??null)==='zero','onboarding compatibility alias resolves to zero');
$c(($p['journeys']['onboarding']['surface']??null)==='zero','onboarding journey is owned by zero');
$c(($p['principles']['alias_resolution_grants_authority']??true)===false,'alias resolution grants no authority');
exit($f?1:0);
