<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskDependency;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use RuntimeException;

final class WorkforceWorkItemOrchestrationGraphService
{
    private const TYPES = ['finish_to_start','finish_to_finish','start_to_start','start_to_finish'];
    private const FAILURE_POLICIES = ['block','continue','escalate','compensate'];

    public function __construct(
        private readonly WorkforceDependencyService $dependencies,
        private readonly WorkforceTaskService $tasks,
    ) {}

    public function addDependency(
        WorkforceTask $workItem,
        WorkforceTask $dependsOn,
        string $dependencyType = 'finish_to_start',
        bool $blocking = true,
        string $failurePolicy = 'block',
        array $condition = [],
        array $metadata = [],
    ): WorkforceTaskDependency {
        $this->assertWorkItem($workItem);
        $this->assertWorkItem($dependsOn);
        if ((int) $workItem->goal_id !== (int) $dependsOn->goal_id) {
            throw new InvalidArgumentException('Work Item dependency must remain inside the same business Goal.');
        }
        if (! in_array($dependencyType, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported Work Item dependency type.');
        }
        if (! in_array($failurePolicy, self::FAILURE_POLICIES, true)) {
            throw new InvalidArgumentException('Unsupported Work Item dependency failure policy.');
        }

        $edge = $this->dependencies->link($workItem, $dependsOn, $blocking);
        $edge->forceFill([
            'dependency_type' => $dependencyType,
            'failure_policy' => $failurePolicy,
            'condition' => $condition,
            'metadata' => array_merge($metadata, [
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ]),
        ])->save();

        $this->recalculateGoal((int) $workItem->company_id, (int) $workItem->goal_id);
        return $edge->refresh();
    }

    /** @return array<string,mixed> */
    public function graph(WorkforceGoal $goal): array
    {
        $companyId = (int) $goal->company_id;
        $items = WorkforceTask::query()->forCompany($companyId)
            ->where('goal_id', $goal->id)
            ->orderByRaw('COALESCE(sequence_index, 4294967295)')
            ->orderBy('id')
            ->get();

        $itemIds = $items->pluck('id')->map(fn ($id) => (int) $id)->all();
        $edges = WorkforceTaskDependency::query()->forCompany($companyId)
            ->whereIn('task_id', $itemIds)
            ->whereIn('depends_on_task_id', $itemIds)
            ->orderBy('id')
            ->get();

        $nodes = [];
        foreach ($items as $item) {
            $nodes[(int) $item->id] = [
                'task_id' => (int) $item->id,
                'work_item_uuid' => (string) ($item->work_item_uuid ?? ''),
                'title' => (string) $item->title,
                'status' => $item->status->value,
                'verification_state' => $item->verification_state?->value,
                'orchestration_group' => $item->orchestration_group,
                'sequence_index' => $item->sequence_index,
                'estimated_minutes' => (int) ($item->estimated_minutes ?? 0),
                'attempt_count' => (int) $item->attempt_count,
                'max_attempts' => (int) ($item->max_attempts ?? 3),
                'critical_path' => (bool) $item->critical_path,
                'blocked_by_graph' => (bool) $item->blocked_by_graph,
            ];
        }

        return [
            'company_id' => $companyId,
            'goal_id' => (int) $goal->id,
            'goal_uuid' => (string) $goal->goal_uuid,
            'nodes' => array_values($nodes),
            'edges' => $edges->map(fn (WorkforceTaskDependency $edge): array => [
                'dependency_id' => (int) $edge->id,
                'task_id' => (int) $edge->task_id,
                'depends_on_task_id' => (int) $edge->depends_on_task_id,
                'dependency_type' => (string) ($edge->dependency_type ?? 'finish_to_start'),
                'blocking' => (bool) $edge->blocking,
                'failure_policy' => (string) ($edge->failure_policy ?? 'block'),
                'condition' => $edge->condition ?? [],
            ])->values()->all(),
            'critical_path_task_ids' => array_values(array_map('intval', $items->where('critical_path', true)->pluck('id')->all())),
            'ready_task_ids' => $this->readyTaskIds($companyId, $itemIds),
            'blocked_task_ids' => array_values(array_map('intval', $items->where('blocked_by_graph', true)->pluck('id')->all())),
            'integrity' => $this->dependencies->integritySnapshot($companyId),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function recalculateGoal(int $companyId, int $goalId): array
    {
        $goal = WorkforceGoal::query()->forCompany($companyId)->find($goalId);
        if (! $goal) throw new RuntimeException('Workforce Goal not found.');

        return DB::transaction(function () use ($goal, $companyId): array {
            $items = WorkforceTask::query()->forCompany($companyId)
                ->where('goal_id', $goal->id)->lockForUpdate()->get();
            $ids = $items->pluck('id')->map(fn ($id) => (int) $id)->all();

            $edges = WorkforceTaskDependency::query()->forCompany($companyId)
                ->whereIn('task_id', $ids)->whereIn('depends_on_task_id', $ids)->get();

            $incoming = array_fill_keys($ids, []);
            $outgoing = array_fill_keys($ids, []);
            foreach ($edges as $edge) {
                $incoming[(int) $edge->task_id][] = $edge;
                $outgoing[(int) $edge->depends_on_task_id][] = $edge;
            }

            $blocked = [];
            foreach ($items as $item) {
                $itemBlocked = false;
                foreach ($incoming[(int) $item->id] ?? [] as $edge) {
                    if (! $edge->blocking) continue;
                    $dependency = $items->firstWhere('id', (int) $edge->depends_on_task_id);
                    if (! $dependency) continue;
                    if ($dependency->status === WorkforceTaskStatus::Failed) {
                        $policy = (string) ($edge->failure_policy ?? 'block');
                        if ($policy === 'continue') continue;
                        $itemBlocked = true;
                    } elseif ($dependency->status !== WorkforceTaskStatus::Completed) {
                        $itemBlocked = true;
                    }
                }
                $blocked[(int) $item->id] = $itemBlocked;
                $item->forceFill(['blocked_by_graph' => $itemBlocked])->save();
            }

            $critical = $this->criticalPath($items->all(), $outgoing);
            foreach ($items as $item) {
                $item->forceFill(['critical_path' => isset($critical[(int) $item->id])])->save();
            }

            return $this->graph($goal->refresh());
        });
    }

    public function dispatchReady(WorkforceGoal $goal): int
    {
        $graph = $this->recalculateGoal((int) $goal->company_id, (int) $goal->id);
        $dispatched = 0;
        foreach ((array) ($graph['ready_task_ids'] ?? []) as $taskId) {
            $task = WorkforceTask::query()->forCompany((int) $goal->company_id)->find((int) $taskId);
            if (! $task || $task->status->terminal() || $task->assignee_member_id === null) continue;
            ProcessWorkforceTaskJob::dispatch((int) $task->company_id, (int) $task->id);
            $dispatched++;
        }
        return $dispatched;
    }

    public function propagateFailure(WorkforceTask $failed, ?WorkforceMember $actor = null): array
    {
        $this->assertWorkItem($failed);
        if ($failed->status !== WorkforceTaskStatus::Failed && $failed->status !== WorkforceTaskStatus::Recovery) {
            throw new InvalidArgumentException('Failure propagation requires a failed or recovery Work Item.');
        }

        $affected = [];
        $edges = WorkforceTaskDependency::query()->forCompany((int) $failed->company_id)
            ->where('depends_on_task_id', $failed->id)->where('blocking', true)->get();

        foreach ($edges as $edge) {
            $dependent = WorkforceTask::query()->forCompany((int) $failed->company_id)->find((int) $edge->task_id);
            if (! $dependent || $dependent->status->terminal()) continue;
            $policy = (string) ($edge->failure_policy ?? 'block');

            if ($policy === 'continue') {
                $this->tasks->record($dependent, $actor, 'work_item.dependency_failure_ignored',
                    $dependent->status->value, $dependent->status->value, 'Dependency failure policy allows continuation.',
                    ['failed_dependency_task_id'=>(int)$failed->id]);
            } elseif ($policy === 'escalate') {
                $this->safeGraphTransition(
                    $dependent,
                    WorkforceTaskStatus::Escalated,
                    $actor,
                    'work_item.dependency_failure_escalated',
                    'Blocking dependency failed.',
                    ['failed_dependency_task_id'=>(int)$failed->id],
                );
            } elseif ($policy === 'compensate') {
                $this->queueCompensation($failed, $dependent, $actor);
            } else {
                $this->safeGraphTransition(
                    $dependent,
                    WorkforceTaskStatus::Blocked,
                    $actor,
                    'work_item.blocked_by_dependency',
                    'Blocking dependency failed.',
                    ['failed_dependency_task_id'=>(int)$failed->id],
                );
            }
            $dependent->forceFill(['blocked_by_graph' => $policy !== 'continue'])->save();
            $affected[] = ['task_id'=>(int)$dependent->id,'failure_policy'=>$policy];
        }

        if ($failed->goal_id) $this->recalculateGoal((int) $failed->company_id, (int) $failed->goal_id);
        return $affected;
    }

    public function retryable(WorkforceTask $workItem): bool
    {
        $this->assertWorkItem($workItem);
        return ! $workItem->status->terminal()
            && (int) $workItem->attempt_count < max(1, (int) ($workItem->max_attempts ?? 3));
    }

    private function safeGraphTransition(
        WorkforceTask $task,
        WorkforceTaskStatus $to,
        ?WorkforceMember $actor,
        string $event,
        string $reason,
        array $context = [],
    ): void {
        if ($task->status === $to) return;
        try {
            $this->tasks->transition($task, $to, $actor, $event, $reason, $context);
        } catch (InvalidArgumentException) {
            $this->tasks->record(
                $task,
                $actor,
                $event.'.state_unchanged',
                $task->status->value,
                $task->status->value,
                $reason,
                array_merge($context, ['graph_state'=>$to->value]),
            );
        }
    }

    private function queueCompensation(WorkforceTask $failed, WorkforceTask $dependent, ?WorkforceMember $actor): void
    {
        $capability = trim((string) ($failed->compensation_capability ?? ''));
        if ($capability === '') {
            $this->safeGraphTransition(
                $dependent,
                WorkforceTaskStatus::Escalated,
                $actor,
                'work_item.compensation_missing',
                'Dependency requires compensation but no compensation capability is configured.',
            );
            return;
        }

        $metadata = is_array($failed->metadata ?? null) ? $failed->metadata : [];
        $metadata['compensation_required'] = [
            'capability' => $capability,
            'failed_task_id' => (int) $failed->id,
            'dependent_task_id' => (int) $dependent->id,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
        $failed->forceFill(['metadata' => $metadata])->save();
        $this->tasks->record($failed, $actor, 'work_item.compensation_required',
            $failed->status->value, $failed->status->value, null, $metadata['compensation_required']);
    }

    /** @param list<WorkforceTask> $items @param array<int,list<WorkforceTaskDependency>> $outgoing @return array<int,bool> */
    private function criticalPath(array $items, array $outgoing): array
    {
        $byId = [];
        $indegree = [];
        foreach ($items as $item) {
            $id=(int)$item->id; $byId[$id]=$item; $indegree[$id]=0;
        }
        foreach ($outgoing as $from=>$edges) {
            foreach ($edges as $edge) if ($edge->blocking) $indegree[(int)$edge->task_id] = ($indegree[(int)$edge->task_id] ?? 0) + 1;
        }

        $queue=[];
        foreach ($indegree as $id=>$degree) if ($degree===0) $queue[]=$id;
        $distance=[]; $previous=[];
        foreach ($byId as $id=>$item) $distance[$id]=max(1,(int)($item->estimated_minutes ?? 1));

        while ($queue!==[]) {
            $node=array_shift($queue);
            foreach ($outgoing[$node] ?? [] as $edge) {
                if (! $edge->blocking) continue;
                $next=(int)$edge->task_id;
                $candidate=$distance[$node]+max(1,(int)($byId[$next]->estimated_minutes ?? 1));
                if ($candidate > ($distance[$next] ?? 0)) { $distance[$next]=$candidate; $previous[$next]=$node; }
                $indegree[$next]--;
                if ($indegree[$next]===0) $queue[]=$next;
            }
        }

        if ($distance===[]) return [];
        $end=(int)array_search(max($distance),$distance,true);
        $critical=[];
        while ($end>0) {
            $critical[$end]=true;
            if (! isset($previous[$end])) break;
            $end=(int)$previous[$end];
        }
        return $critical;
    }

    /** @param list<int> $itemIds @return list<int> */
    private function readyTaskIds(int $companyId, array $itemIds): array
    {
        $ready=[];
        foreach ($itemIds as $id) {
            $task=WorkforceTask::query()->forCompany($companyId)->find($id);
            if (! $task || $task->status->terminal() || $task->blocked_by_graph || $task->assignee_member_id===null) continue;
            if ($this->dependencies->ready($task)) $ready[]=(int)$task->id;
        }
        sort($ready,SORT_NUMERIC);
        return $ready;
    }

    private function assertWorkItem(WorkforceTask $task): void
    {
        if (! $task->work_item_uuid || ! $task->goal_id || ! $task->responsibility_id) {
            throw new InvalidArgumentException('Orchestration graph accepts canonical Work Items only.');
        }
    }
}
