<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;

/**
 * Read-only company-scoped projection for the Interactive Organisation Map.
 *
 * Relationship edges describe organisation/coordination only. Capability state
 * is live, and neither an edge nor provider availability grants authority.
 */
final class WorkforceOrganisationMapService
{
    // company_id is the sole canonical tenant/company boundary for this projection.
    private const TERMINAL_TASKS = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function __construct(
        private readonly WorkforceCapabilityAvailabilityService $capabilities,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $divisions = WorkforceDivision::query()->forCompany($companyId)
            ->with(['teams' => fn ($query) => $query->orderBy('name')])
            ->orderBy('name')->get();

        $members = WorkforceMember::query()->forCompany($companyId)
            ->with(['division','team','manager'])
            ->orderBy('tier')->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member): bool => (bool) data_get($member->metadata ?? [], 'internal', false))
            ->values();

        $openTaskCounts = WorkforceTask::query()->forCompany($companyId)
            ->whereNotIn('status', self::TERMINAL_TASKS)
            ->whereNotNull('assignee_member_id')
            ->selectRaw('assignee_member_id, COUNT(*) as aggregate')
            ->groupBy('assignee_member_id')
            ->pluck('aggregate', 'assignee_member_id');

        $memberRows = [];
        $providerKeys = [];
        foreach ($members as $member) {
            $capability = $this->capabilities->forMember($member);
            $providerStates = [];
            foreach ((array) ($capability['provider_bindings'] ?? []) as $binding) {
                $provider = (string) ($binding['provider'] ?? '');
                if ($provider === '') continue;
                $providerStates[$provider] = (string) ($binding['state'] ?? 'unavailable');
                $providerKeys[$provider] = true;
            }
            $open = (int) ($openTaskCounts[(int) $member->id] ?? 0);
            $capacity = max(1, (int) ($member->max_concurrent_tasks ?? 5));
            $loadRatio = round($open / $capacity, 3);
            $tier = $member->tier?->value ?? (int) $member->tier;
            $managerMissing = $tier > WorkforceTier::Manager->value
                && ((int) ($member->manager_id ?? 0) <= 0 || ! $member->manager || ! $member->manager->is_active);

            $memberRows[(int) $member->id] = [
                'id' => (int) $member->id,
                'name' => (string) $member->name,
                'role' => (string) $member->role,
                'role_definition_id' => (string) $member->role_definition_id,
                'tier' => $tier,
                'tier_label' => $member->tier?->label() ?? 'Unknown',
                'division_id' => $member->division_id ? (int) $member->division_id : null,
                'division_name' => (string) ($member->division?->name ?? 'Unassigned'),
                'team_id' => $member->team_id ? (int) $member->team_id : null,
                'team_name' => (string) ($member->team?->name ?? 'Unassigned'),
                'manager_id' => $member->manager_id ? (int) $member->manager_id : null,
                'manager_name' => (string) ($member->manager?->name ?? ''),
                'lifecycle' => $member->lifecycle_state?->value ?? 'LEGACY',
                'status' => $member->status?->value ?? '',
                'is_active' => (bool) $member->is_active,
                'capability_state' => (string) ($capability['state'] ?? 'unavailable'),
                'provider_states' => $providerStates,
                'providers' => array_keys($providerStates),
                'open_work' => $open,
                'capacity' => $capacity,
                'load_ratio' => $loadRatio,
                'overloaded' => $loadRatio >= 1.0,
                'missing_manager' => $managerMissing,
            ];
        }

        $edges = [];
        $relationships = WorkforceRelationship::query()->forCompany($companyId)
            ->where('is_active', true)->orderBy('id')->get();
        foreach ($relationships as $relationship) {
            $from = (int) $relationship->source_member_id;
            $to = (int) $relationship->target_member_id;
            if (! isset($memberRows[$from], $memberRows[$to])) continue;
            $type = $relationship->relationship_type?->value ?? (string) $relationship->relationship_type;
            $edges[] = $this->edge($from, $to, $type, 'relationship', [
                'cross_team' => ($memberRows[$from]['team_id'] ?? null) !== ($memberRows[$to]['team_id'] ?? null),
                'authority_inherited' => false,
            ]);
        }

        // Live delegation records are rendered independently of persistent graph edges.
        foreach (WorkforceDelegation::query()->forCompany($companyId)->where('status', 'ACTIVE')->orderByDesc('id')->limit(250)->get() as $delegation) {
            $from = (int) $delegation->from_member_id;
            $to = (int) $delegation->to_member_id;
            if (! isset($memberRows[$from], $memberRows[$to])) continue;
            $edges[] = $this->edge($from, $to, WorkforceRelationshipType::DelegatesTo->value, 'active_delegation', [
                'task_id' => $delegation->task_id ? (int) $delegation->task_id : null,
                'authority_inherited' => false,
            ]);
        }

        foreach (WorkforceEscalation::query()->forCompany($companyId)->where('status', 'OPEN')->whereNotNull('escalated_to_member_id')->orderByDesc('id')->limit(250)->get() as $escalation) {
            $from = (int) ($escalation->raised_by_member_id ?? 0);
            $to = (int) $escalation->escalated_to_member_id;
            if ($from <= 0 || ! isset($memberRows[$from], $memberRows[$to])) continue;
            $edges[] = $this->edge($from, $to, WorkforceRelationshipType::EscalatesTo->value, 'open_escalation', [
                'risk_level' => (string) $escalation->risk_level,
                'reason_code' => (string) $escalation->reason_code,
                'authority_inherited' => false,
            ]);
        }

        $edgeCounts = [];
        foreach ($edges as $edge) $edgeCounts[$edge['type']] = ($edgeCounts[$edge['type']] ?? 0) + 1;

        $divisionRows = [];
        foreach ($divisions as $division) {
            $teams = [];
            foreach ($division->teams as $team) {
                $teamMembers = array_values(array_filter($memberRows, static fn (array $m): bool => ($m['team_id'] ?? null) === (int) $team->id));
                $teams[] = [
                    'id' => (int) $team->id,
                    'name' => (string) $team->name,
                    'members' => $teamMembers,
                ];
            }
            $unassigned = array_values(array_filter($memberRows, static fn (array $m): bool => ($m['division_id'] ?? null) === (int) $division->id && ($m['team_id'] ?? null) === null));
            if ($unassigned !== []) $teams[] = ['id' => null, 'name' => 'Unassigned team', 'members' => $unassigned];
            $divisionRows[] = [
                'id' => (int) $division->id,
                'name' => (string) $division->name,
                'purpose' => (string) $division->purpose,
                'teams' => $teams,
            ];
        }

        return [
            'divisions' => $divisionRows,
            'members' => array_values($memberRows),
            'edges' => $edges,
            'edge_counts' => $edgeCounts,
            'providers' => array_values(array_keys($providerKeys)),
            'filters' => [
                'divisions' => $divisions->map(fn ($division): array => ['id' => (int) $division->id, 'name' => (string) $division->name])->values()->all(),
                'teams' => $divisions->flatMap(fn ($division) => $division->teams)->map(fn ($team): array => ['id' => (int) $team->id, 'name' => (string) $team->name])->values()->all(),
                'roles' => array_values(array_unique(array_map(static fn (array $m): string => $m['role'], $memberRows))),
                'lifecycles' => array_values(array_unique(array_map(static fn (array $m): string => $m['lifecycle'], $memberRows))),
                'providers' => array_values(array_keys($providerKeys)),
            ],
            'summary' => [
                'staff' => count($memberRows),
                'managers' => count(array_filter($memberRows, static fn (array $m): bool => $m['tier'] === WorkforceTier::Manager->value)),
                'specialists' => count(array_filter($memberRows, static fn (array $m): bool => $m['tier'] === WorkforceTier::Specialist->value)),
                'degraded' => count(array_filter($memberRows, static fn (array $m): bool => $m['capability_state'] !== 'available')),
                'overloaded' => count(array_filter($memberRows, static fn (array $m): bool => $m['overloaded'])),
                'missing_manager' => count(array_filter($memberRows, static fn (array $m): bool => $m['missing_manager'])),
            ],
            'authority_inherited' => false,
        ];
    }

    /** @return array<string,mixed> */
    private function edge(int $from, int $to, string $type, string $source, array $metadata): array
    {
        return [
            'from_member_id' => $from,
            'to_member_id' => $to,
            'type' => $type,
            'source' => $source,
            'metadata' => $metadata,
            'authority_inherited' => false,
        ];
    }
}
