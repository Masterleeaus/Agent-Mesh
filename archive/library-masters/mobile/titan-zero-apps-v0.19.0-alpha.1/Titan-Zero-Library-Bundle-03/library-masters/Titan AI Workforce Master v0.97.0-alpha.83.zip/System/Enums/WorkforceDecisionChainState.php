<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceDecisionChainState: string
{
    case PendingOriginReview = 'PENDING_ORIGIN_REVIEW';
    case PendingDomainProcessing = 'PENDING_DOMAIN_PROCESSING';
    case PendingReceivingAcceptance = 'PENDING_RECEIVING_ACCEPTANCE';
    case PendingFederatedAcceptance = 'PENDING_FEDERATED_ACCEPTANCE';
    case OrganisationallyApproved = 'ORGANISATIONALLY_APPROVED';
    case Rejected = 'REJECTED';
    case NeedsInformation = 'NEEDS_INFORMATION';
    case Disagreed = 'DISAGREED';
    case Escalated = 'ESCALATED';
    case Superseded = 'SUPERSEDED';
    case Closed = 'CLOSED';
}
