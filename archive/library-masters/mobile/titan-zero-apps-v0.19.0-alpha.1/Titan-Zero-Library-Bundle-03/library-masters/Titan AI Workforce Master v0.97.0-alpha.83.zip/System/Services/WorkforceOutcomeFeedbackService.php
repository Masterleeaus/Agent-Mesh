<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Throwable;

final class WorkforceOutcomeFeedbackService
{
    public function __construct(
        private readonly WorkforceJourneySpineService $journey,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
        private readonly WorkforceReviewerPerformanceFeedbackService $reviewerFeedback,
        private readonly WorkforceChainAuditReconstructionService $audit,
        private readonly WorkforceChainLearningPolicyService $chainLearning,
    ) {}

    public function record(WorkforceTask $task, WorkforceMember $actor, array $commandResult): array
    {
        $receipt = $commandResult['receipt'] ?? null;
        $receiptRef = $this->referenceFrom($receipt, ['receipt_id','command_id','id','ref']);
        $verification = is_array($commandResult['verification'] ?? null) ? $commandResult['verification'] : [];
        $verificationRef = $this->referenceFrom($verification, ['domain_state_ref','state_ref','verification_ref','reference','id']);
        $verified = ($verification['verified'] ?? false) === true
            && ($verificationRef !== null || ($verification['post_action_verification'] ?? null) === false);

        $payload = [
            'company_id' => (int) $task->company_id,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => $task->causation_id ? (string) $task->causation_id : null,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'actor_member_id' => (int) $actor->id,
            'actor_role_definition_id' => $actor->role_definition_id,
            'receipt_ref' => $receiptRef,
            'attempt_uuid' => $commandResult['attempt_uuid'] ?? null,
            'intent_id' => $commandResult['intent_id'] ?? null,
            'intent_sha256' => $commandResult['intent_sha256'] ?? null,
            'idempotency_key' => $commandResult['idempotency_key'] ?? null,
            'verified' => $verified,
            'verification_ref' => $verificationRef,
            'domain_state_ref' => $verificationRef,
            'verification_reason_code' => $verification['reason_code'] ?? null,
            'expected_outcome' => data_get($task->metadata ?? [], 'expected_outcome'),
            'evidence_refs' => array_values(array_unique(array_filter(array_merge(
                (array) data_get($task->evidence ?? [], 'refs', []),
                [$receiptRef, $verificationRef]
            )))),
            'decision_refs' => array_values(array_unique(array_filter([
                data_get($task->risk_snapshot ?? [], 'decision_id'),
                data_get($task->assurance_snapshot ?? [], 'decision_id'),
                data_get($task->autonomy_snapshot ?? [], 'decision_id'),
                data_get($task->governance ?? [], 'pre_execution.model_council.decision_id'),
            ]))),
            'execution_refs' => array_values(array_unique(array_filter([
                $commandResult['attempt_uuid'] ?? null,
                $commandResult['intent_id'] ?? null,
                $receiptRef,
                $verificationRef,
            ]))),
            'outcome_success' => $verified ? (bool) ($verification['outcome_success'] ?? true) : null,
        ];

        // Rewind receives structured receipt/verification references. It never receives private hidden reasoning.
        $rewind = $this->callOptional(
            $this->controlPlane->bindingsFor('rewind'),
            $this->controlPlane->methodsFor('rewind'),
            array_merge($payload, ['record_type' => 'workforce_execution_outcome_reference', 'private_reasoning_persisted' => false]),
            ['available' => false, 'reference' => null]
        );
        $rewindRef = $this->referenceFrom($rewind, ['rewind_ref','receipt_ref','reference','id']);

        $wisdom = ['available' => false, 'reference' => null, 'reason_code' => 'WISDOM_WITHHELD_UNVERIFIED_OUTCOME'];
        $autonomyEvidence = ['available' => false, 'reference' => null, 'reason_code' => 'AUTONOMY_EVIDENCE_WITHHELD_UNVERIFIED_OUTCOME'];
        if ($verified) {
            $wisdom = $this->callOptional(
                $this->controlPlane->bindingsFor('wisdom'),
                $this->controlPlane->methodsFor('wisdom'),
                array_merge($payload, ['outcome_source' => 'authoritative_post_action_verification']),
                ['available' => false, 'reference' => null]
            );
            $autonomyEvidence = $this->recordOutcomeEvidence($payload);
        }

        $outcomeRef = $this->referenceFrom($wisdom, ['outcome_ref','outcome_id','reference','id']);
        $autonomyEvidenceRef = $this->referenceFrom($autonomyEvidence, ['evidence_ref','reference','id']);
        $refs = [
            'verified' => $verified,
            'receipt_ref' => $receiptRef,
            'verification_ref' => $verificationRef,
            'rewind_ref' => $rewindRef,
            'outcome_ref' => $outcomeRef,
            'autonomy_evidence_ref' => $autonomyEvidenceRef,
            'rewind' => $rewind,
            'wisdom' => $wisdom,
            'autonomy_evidence' => $autonomyEvidence,
        ];

        $governance = $task->governance ?? [];
        $governance['post_execution'] = [
            'observed_at' => now()->toIso8601String(),
            'verified' => $verified,
            'receipt_ref' => $receiptRef,
            'rewind_ref' => $rewindRef,
            'outcome_ref' => $outcomeRef,
            'autonomy_evidence_ref' => $autonomyEvidenceRef,
            'intent_id' => $commandResult['intent_id'] ?? null,
            'intent_sha256' => $commandResult['intent_sha256'] ?? null,
            'verification_ref' => $verificationRef,
            'engine_availability' => [
                'rewind' => (bool) ($rewind['available'] ?? false),
                'wisdom' => (bool) ($wisdom['available'] ?? false),
                'autonomy' => (bool) ($autonomyEvidence['available'] ?? false),
            ],
        ];
        $task->forceFill(['governance' => $governance])->save();

        if ($verified) {
            $verifiedOutcome=array_merge($payload, [
                'rewind_ref'=>$rewindRef,
                'outcome_ref'=>$outcomeRef,
                'autonomy_evidence_ref'=>$autonomyEvidenceRef,
            ]);
            $this->journey->recordVerifiedOutcome($task->refresh(), $actor, $verifiedOutcome);
            $this->reviewerFeedback->recordVerifiedOutcome($task->refresh(), $verifiedOutcome);
            $this->captureAuditForTask($task->refresh(),'VERIFIED_OUTCOME');
            $this->chainLearning->refreshScope((int)$task->company_id,(string)($task->capability ?: '*'));
        } else {
            $this->journey->recordExecutionLifecycle($task->refresh(), $actor, 'outcome.verification_missing', [
                'evidence_refs' => $payload['evidence_refs'],
                'decision_refs' => $payload['decision_refs'],
                'execution_refs' => $payload['execution_refs'],
            ], [
                'verified' => false,
                'reason_code' => 'WISDOM_WITHHELD_UNVERIFIED_OUTCOME',
                'verification_ref' => $verificationRef,
            ]);
        }

        return $refs;
    }


    /**
     * Accept a later real-world outcome from another Titan/domain extension.
     * The envelope must explicitly declare verified outcome evidence and identify the Workforce task.
     */
    public function observeExternalVerifiedOutcome(array $envelope): array
    {
        $payload = is_array($envelope['payload'] ?? null) ? $envelope['payload'] : [];
        $companyId = (int) ($envelope['company_id'] ?? $payload['company_id'] ?? 0);
        $taskUuid = trim((string) ($payload['workforce_task_id'] ?? $payload['task_id'] ?? ''));
        $verified = ($payload['outcome_verified'] ?? $payload['verified'] ?? false) === true;
        $evidenceRefs = array_values(array_unique(array_filter((array) ($payload['evidence_refs'] ?? []))));
        $outcomeRef = trim((string) ($payload['outcome_ref'] ?? $payload['domain_state_ref'] ?? ''));
        if ($companyId <= 0 || $taskUuid === '' || ! $verified || $evidenceRefs === [] || $outcomeRef === '') {
            return ['accepted' => false, 'reason_code' => 'EXTERNAL_OUTCOME_EVIDENCE_INCOMPLETE'];
        }

        $task = WorkforceTask::query()->forCompany($companyId)->where('task_uuid', $taskUuid)->first();
        if (! $task || ! $task->assignee_member_id) return ['accepted' => false, 'reason_code' => 'WORKFORCE_TASK_OR_ACTOR_NOT_FOUND'];
        $actor = WorkforceMember::query()->forCompany($companyId)->find((int) $task->assignee_member_id);
        if (! $actor) return ['accepted' => false, 'reason_code' => 'WORKFORCE_ACTOR_NOT_FOUND'];

        $verifiedPayload = [
            'company_id' => $companyId,
            'trace_id' => (string) ($envelope['trace_id'] ?? $task->trace_id),
            'correlation_id' => (string) ($envelope['correlation_id'] ?? $task->correlation_id),
            'causation_id' => $envelope['causation_id'] ?? null,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'actor_member_id' => (int) $actor->id,
            'verified' => true,
            'verification_ref' => $outcomeRef,
            'domain_state_ref' => $outcomeRef,
            'outcome_ref' => $outcomeRef,
            'evidence_refs' => $evidenceRefs,
            'decision_refs' => array_values(array_unique(array_filter((array) ($payload['decision_refs'] ?? [])))),
            'execution_refs' => array_values(array_unique(array_filter((array) ($payload['execution_refs'] ?? [])))),
            'outcome_success' => array_key_exists('outcome_success', $payload) ? (bool) $payload['outcome_success'] : null,
            'outcome_source' => (string) ($payload['outcome_source'] ?? 'external_verified_domain_outcome'),
        ];
        $wisdom = $this->callOptional($this->controlPlane->bindingsFor('wisdom'), $this->controlPlane->methodsFor('wisdom'), $verifiedPayload, ['available' => false, 'reference' => null]);
        $autonomyEvidence = $this->recordOutcomeEvidence($verifiedPayload);
        $wisdomRef = $this->referenceFrom($wisdom, ['outcome_ref','outcome_id','reference','id']);
        $autonomyEvidenceRef = $this->referenceFrom($autonomyEvidence, ['evidence_ref','reference','id']);
        $externalOutcome=array_merge($verifiedPayload, [
            'outcome_ref'=>$wisdomRef ?? $outcomeRef,
            'autonomy_evidence_ref'=>$autonomyEvidenceRef,
        ]);
        $this->journey->recordVerifiedOutcome($task, $actor, $externalOutcome);
        $this->reviewerFeedback->recordVerifiedOutcome($task, $externalOutcome);
        $this->captureAuditForTask($task,'EXTERNAL_VERIFIED_OUTCOME');
        $this->chainLearning->refreshScope((int)$task->company_id,(string)($task->capability ?: '*'));

        $governance = $task->governance ?? [];
        $external = is_array($governance['verified_external_outcomes'] ?? null) ? $governance['verified_external_outcomes'] : [];
        $external[] = [
            'observed_at' => now()->toIso8601String(),
            'outcome_ref' => $wisdomRef ?? $outcomeRef,
            'domain_state_ref' => $outcomeRef,
            'autonomy_evidence_ref' => $autonomyEvidenceRef,
            'outcome_success' => $verifiedPayload['outcome_success'],
        ];
        $governance['verified_external_outcomes'] = array_slice($external, -25);
        $task->forceFill(['governance' => $governance])->save();

        return ['accepted' => true, 'outcome_ref' => $wisdomRef ?? $outcomeRef, 'autonomy_evidence_ref' => $autonomyEvidenceRef];
    }

    private function captureAuditForTask(WorkforceTask $task,string $type): void
    {
        $processingId=trim((string)data_get($task->metadata ?? [],'processing_id',''));
        if($processingId==='') return;
        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany((int)$task->company_id)->where('processing_id',$processingId)->first();
        if($chain) $this->audit->capture($chain,$type);
    }

    private function recordOutcomeEvidence(array $payload): array
    {
        $resolved = $this->controlPlane->resolve('autonomy');
        if ($resolved === null) return ['available' => false, 'reference' => null];
        $autonomy = $resolved['service'];
        foreach (['recordOutcomeEvidence','observeEvidence','recordEvidence'] as $method) {
            if (! method_exists($autonomy, $method)) continue;
            try {
                $result = $autonomy->{$method}(array_merge($payload, [
                    'evidence_kind' => 'verified_real_world_outcome',
                    'authority_mutation_requested' => false,
                ]));
                if (is_array($result)) return array_merge(['available' => true, 'method' => $method], $result);
                return ['available' => true, 'method' => $method, 'reference' => $result];
            } catch (Throwable $e) {
                return ['available' => true, 'failed' => true, 'method' => $method, 'error' => mb_substr($e->getMessage(), 0, 1000)];
            }
        }
        return ['available' => false, 'reference' => null];
    }

    private function callOptional(array $bindings, array $methods, array $payload, array $fallback): array
    {
        foreach ($bindings as $binding) {
            if (! app()->bound($binding)) continue;
            $service = app($binding);
            foreach ($methods as $method) {
                if (! method_exists($service, $method)) continue;
                try {
                    $result = $service->{$method}($payload);
                    if (is_array($result)) return array_merge(['available' => true, 'binding' => $binding, 'method' => $method], $result);
                    return ['available' => true, 'binding' => $binding, 'method' => $method, 'reference' => $result];
                } catch (Throwable $e) {
                    return array_merge($fallback, ['available' => true, 'failed' => true, 'binding' => $binding, 'method' => $method, 'error' => mb_substr($e->getMessage(), 0, 1000)]);
                }
            }
        }
        return $fallback;
    }

    private function referenceFrom(mixed $value, array $keys): ?string
    {
        if (is_scalar($value) && $value !== '') return (string) $value;
        if (! is_array($value)) return null;
        foreach ($keys as $key) {
            $candidate = $value[$key] ?? null;
            if (is_scalar($candidate) && $candidate !== '') return (string) $candidate;
        }
        return null;
    }
}
