<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\AI\Services;

use InvalidArgumentException;

final class ZeroAdaptiveAiRouter
{
    public function __construct(private readonly ?object $canonicalRouter = null) {}

    /** @param array<string,mixed> $request @param array<string,bool> $available @return array<string,mixed> */
    public function route(array $request, array $available): array
    {
        $companyId = trim((string)($request['company_id'] ?? ''));
        if ($companyId === '') throw new InvalidArgumentException('Zero AI routing requires canonical company_id.');
        foreach (['tenant_id','tenant_company_id','tenantId'] as $legacy) {
            if (isset($request[$legacy]) && trim((string)$request[$legacy]) !== '' && trim((string)$request[$legacy]) !== $companyId) {
                throw new InvalidArgumentException('Legacy tenant identifier conflicts with canonical company_id.');
            }
        }
        if ($this->canonicalRouter !== null && method_exists($this->canonicalRouter, 'select')) {
            return $this->canonicalRouter->select($request, $available);
        }

        // Compatibility/offline fallback only. Canonical routing is owned by Titan Apps Interaction Engine.
        $privacy=$request['privacy']??'private_preferred';$confidence=(float)($request['confidence']??0);$consequence=$request['consequence']??'medium';$high=$consequence==='high';$order=['deterministic','browser_ai','device_ai','native_ai','customer_ai','byo_cloud','titan_private_ai','model_council'];$cloud=['customer_ai','byo_cloud','titan_private_ai','model_council'];$route='unavailable';$reason='no_eligible_runtime';if($high&&$confidence<0.4&&($available['model_council']??false)&&$privacy!=='local_only'){$route='model_council';$reason='high_consequence_low_confidence';}else{foreach($order as $candidate){if(!($available[$candidate]??false))continue;if($privacy==='local_only'&&in_array($candidate,$cloud,true))continue;$route=$candidate;$reason='compatibility_fallback_route';break;}}return ['schema'=>'titan.zero.adaptive-ai-route.compat.v1','company_id'=>$companyId,'route'=>$route,'reason'=>$reason,'task'=>$request['task']??'unknown','confidence'=>$confidence,'consequence'=>$consequence,'privacy_policy'=>$privacy,'grants_authority'=>false,'executes_mutations'=>false,'model_council_is_escalation'=>$route==='model_council'];
    }
}
