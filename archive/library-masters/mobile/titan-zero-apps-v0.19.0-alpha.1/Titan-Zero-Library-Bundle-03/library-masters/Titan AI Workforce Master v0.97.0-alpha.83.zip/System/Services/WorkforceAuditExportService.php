<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResponsibility;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;

final class WorkforceAuditExportService
{
    public function __construct(private readonly WorkforceTrustHealthService $trust) {}

    public function package(int $companyId): array
    {
        $tasks=WorkforceTask::query()->forCompany($companyId)->get();
        $taskIds=$tasks->pluck('id');
        $executions=WorkforceExecutionAttempt::query()->whereIn('task_id',$taskIds)->get();
        $outcomes=WorkforceOutcome::query()->forCompany($companyId)->get();
        return [
            'schema'=>'titan-workforce.audit-export.v1',
            'company_id'=>$companyId,
            'generated_at'=>now()->toIso8601String(),
            'organisation'=>[
                'divisions'=>WorkforceDivision::query()->forCompany($companyId)->get()->toArray(),
                'teams'=>WorkforceTeam::query()->forCompany($companyId)->get()->toArray(),
            ],
            'employees'=>WorkforceMember::query()->forCompany($companyId)->get()->toArray(),
            'work'=>$tasks->toArray(),
            'responsibilities'=>WorkforceResponsibility::query()->visibleToCompany($companyId)->get()->toArray(),
            'delegations'=>WorkforceDelegation::query()->forCompany($companyId)->get()->toArray(),
            'escalations'=>WorkforceEscalation::query()->forCompany($companyId)->get()->toArray(),
            'executions'=>$executions->toArray(),
            'outcomes'=>$outcomes->toArray(),
            'governance'=>$this->trust->forCompany($companyId),
            'integrity'=>[
                'company_scope_enforced'=>true,
                'read_only_export'=>true,
                'authority_inherited'=>false,
                'execution_authority_granted'=>false,
                'verified_outcomes'=>$outcomes->whereNotNull('verified_at')->count(),
                'execution_receipts'=>$executions->whereNotNull('receipt')->count(),
            ],
        ];
    }
}
