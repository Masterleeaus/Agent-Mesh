<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\TitanAI;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;

final class WorkforceSourcePolicy
{
    public function filterCapabilities(TitanAIRequest $request, array $capabilities): array
    {
        return array_values(array_unique(array_intersect($capabilities, ['chat','memory','knowledge','web'])));
    }

    public function allowsBusinessActions(TitanAIRequest $request): bool
    {
        // Business mutations must leave the model runtime and pass through Workforce governance + Command Bus.
        return false;
    }

    public function allowsTool(TitanAIRequest $request, string $toolId): bool
    {
        return in_array($toolId, ['knowledge.search','memory.read','web.search'], true);
    }
}
