<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceProviderHealthEvent extends Model
{
    protected $table = 'ext_titan_ai_workforce_provider_health_events';
    protected $guarded = [];
    protected $casts = [
        'details' => 'array',
        'observed_at' => 'datetime',
        'recovered_at' => 'datetime',
    ];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
