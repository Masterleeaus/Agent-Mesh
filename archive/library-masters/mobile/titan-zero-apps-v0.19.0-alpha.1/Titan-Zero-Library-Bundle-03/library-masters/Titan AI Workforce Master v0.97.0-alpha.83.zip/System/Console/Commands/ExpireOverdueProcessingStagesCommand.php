<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProcessingLifecycleService;
use Illuminate\Console\Command;

final class ExpireOverdueProcessingStagesCommand extends Command
{
    protected $signature = 'titan-workforce:expire-processing-stages';
    protected $description = 'Escalate overdue AI decision-chain processing stages.';

    public function handle(WorkforceProcessingLifecycleService $lifecycle): int
    {
        $count=0;
        WorkforceProcessingCheckpoint::query()
            ->whereNotNull('company_id')
            ->select('company_id')->distinct()->orderBy('company_id')
            ->pluck('company_id')
            ->each(function ($companyId) use ($lifecycle,&$count): void {
                $count += $lifecycle->expireOverdue((int)$companyId);
            });

        $this->info('Escalated '.$count.' overdue processing stage(s).');
        return self::SUCCESS;
    }
}
