<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceJourneyRecord;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Read-only business-language projection of the append-only Workforce journey spine.
 * Technical evidence remains available per event but is deliberately collapsed by default.
 */
final class WorkforceJourneyTimelineService
{
    /** @return array<string,mixed> */
    public function snapshot(int $companyId, ?int $taskId = null): array
    {
        if ($companyId <= 0) throw new RuntimeException('company_id must be positive.');

        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->orderByDesc('updated_at')->limit(75)->get();
        $task = $taskId
            ? WorkforceTask::query()->forCompany($companyId)->find($taskId)
            : $tasks->first();

        $events = $task ? $this->eventsForTask($companyId, $task) : collect();

        return [
            'task' => $task,
            'tasks' => $tasks,
            'events' => $events,
            'event_count' => $events->count(),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
            'generated_at' => now()->toIso8601String(),
        ];
    }

    /** @return Collection<int,array<string,mixed>> */
    private function eventsForTask(int $companyId, WorkforceTask $task): Collection
    {
        $journey = WorkforceJourneyRecord::query()->forCompany($companyId)
            ->where(function ($query) use ($task) {
                $query->where('task_id', (int) $task->id)
                    ->orWhere('correlation_id', (string) $task->correlation_id)
                    ->orWhere('trace_id', (string) $task->trace_id);
            })
            ->orderBy('observed_at')->orderBy('id')->get();

        $memberIds = $journey->pluck('member_id')->filter()->unique()->values()->all();
        $members = WorkforceMember::query()->forCompany($companyId)
            ->whereIn('id', $memberIds)->get()->keyBy('id');

        return $journey->values()->map(function (WorkforceJourneyRecord $row, int $index) use ($task, $members): array {
            $summary = is_array($row->summary) ? $row->summary : [];
            $actor = $row->member_id ? $members->get((int) $row->member_id) : null;
            $event = $this->eventKey((string) $row->event_type);
            $businessTitle = $this->businessTitle($event, $summary, $actor?->name, $task->title);

            return [
                'sequence' => $index + 1,
                'business_title' => $businessTitle,
                'business_summary' => $this->businessSummary($event, $summary, $actor?->name, $task),
                'actor_name' => $actor?->name,
                'category' => (string) $row->category,
                'phase' => (string) $row->phase,
                'occurred_at' => $row->observed_at,
                'event_type' => (string) $row->event_type,
                'technical_details' => [
                    'event_uuid' => (string) $row->event_uuid,
                    'event_sha256' => (string) $row->event_sha256,
                    'trace_id' => (string) $row->trace_id,
                    'correlation_id' => (string) $row->correlation_id,
                    'causation_id' => $row->causation_id ? (string) $row->causation_id : null,
                    'source_ref' => (string) $row->source_ref,
                    'rationale_refs' => (array) $row->rationale_refs,
                    'evidence_refs' => (array) $row->evidence_refs,
                    'decision_refs' => (array) $row->decision_refs,
                    'execution_refs' => (array) $row->execution_refs,
                    'outcome_refs' => (array) $row->outcome_refs,
                    'summary' => $summary,
                ],
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ];
        });
    }

    private function eventKey(string $eventType): string
    {
        return Str::after($eventType, 'workforce.');
    }

    private function businessTitle(string $event, array $summary, ?string $actorName, string $taskTitle): string
    {
        $actor = $actorName ? $actorName.' ' : '';
        $to = strtoupper((string) ($summary['to_status'] ?? ''));

        if (str_contains($event, 'outcome.verified')) return 'Outcome verified';
        if (str_contains($event, 'wisdom')) return 'Wisdom feedback generated';
        if (str_contains($event, 'signal') || str_contains($event, 'trigger') || str_contains($event, 'ingress')) return 'Business signal received';
        if (str_contains($event, 'handoff')) return $actor.'handed work to the next owner';
        if (str_contains($event, 'escalat')) return $actor.'escalated the work';
        if (str_contains($event, 'execut')) return 'Command executed';
        if (str_contains($event, 'recover') || str_contains($event, 'rewind')) return 'Recovery action recorded';
        if (str_contains($event, 'review') || $to === 'UNDER_REVIEW' || $to === 'RECEIVER_REVIEW') return $actor.'submitted work for review';
        if (str_contains($event, 'approv') || $to === 'APPROVED') return $actor.'approved the work';
        if (str_contains($event, 'revision') || $to === 'REVISION_REQUIRED') return $actor.'requested changes';
        if (str_contains($event, 'complete') || $to === 'COMPLETED') return 'Work completed';
        if (str_contains($event, 'assign') || $to === 'ASSIGNED') return $actor.'accepted responsibility';
        if (str_contains($event, 'process') || $to === 'PROCESSING') return $actor.'started work';
        if (str_contains($event, 'verify')) return 'Business state verified';
        if (str_contains($event, 'create') || $to === 'CREATED') return $taskTitle.' created';

        return Str::headline(str_replace(['.', '_'], ' ', $event));
    }

    private function businessSummary(string $event, array $summary, ?string $actorName, WorkforceTask $task): string
    {
        $reason = trim((string) ($summary['reason_summary'] ?? data_get($summary, 'context.reason') ?? ''));
        if ($reason !== '') return $reason;

        $from = (string) ($summary['from_status'] ?? '');
        $to = (string) ($summary['to_status'] ?? '');
        if ($from !== '' || $to !== '') {
            $who = $actorName ?: 'Workforce';
            return trim($who.' moved the work'.($from !== '' ? ' from '.Str::headline(strtolower($from)) : '').($to !== '' ? ' to '.Str::headline(strtolower($to)) : '').'.');
        }

        if (str_contains($event, 'outcome')) return 'The business result was recorded against this work item.';
        if (str_contains($event, 'execut')) return 'A governed execution event was recorded for this work item.';
        if ($actorName) return $actorName.' recorded progress on '.$task->title.'.';
        return 'Workforce recorded a new stage in '.$task->title.'.';
    }
}
