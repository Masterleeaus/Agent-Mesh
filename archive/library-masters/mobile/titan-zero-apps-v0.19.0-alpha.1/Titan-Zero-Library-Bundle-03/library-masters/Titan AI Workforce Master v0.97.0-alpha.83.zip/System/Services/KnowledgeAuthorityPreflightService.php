<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Contracts\Container\Container;
use RuntimeException;

/**
 * Mandatory governed-knowledge preflight for consequential Workforce processing.
 * Knowledge Authority remains the source of knowledge truth; Workforce only consumes the receipt.
 */
final class KnowledgeAuthorityPreflightService
{
    private const CONTRACT = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Contracts\\KnowledgeAuthorityContract';

    public function __construct(
        private readonly Container $app,
        private readonly WorkforceKnowledgeUncertaintyService $uncertainty,
    ) {}

    public function resolve(WorkforceTask $task, array $request): array
    {
        $required = (bool) ($request['knowledge_required'] ?? $request['consequential'] ?? true);
        if (! $required) {
            return ['status' => 'NOT_REQUIRED', 'knowledge_required' => false];
        }

        if (! interface_exists(self::CONTRACT) || ! $this->app->bound(self::CONTRACT)) {
            throw new RuntimeException('KNOWLEDGE_AUTHORITY_REQUIRED_BUT_UNAVAILABLE');
        }

        $authority = $this->app->make(self::CONTRACT);
        if (! method_exists($authority, 'resolveContext')) {
            throw new RuntimeException('KNOWLEDGE_AUTHORITY_CONTEXT_RESOLUTION_UNAVAILABLE');
        }

        $context = $authority->resolveContext([
            'company_id' => (int) $task->company_id,
            'task_id' => $task->getKey(),
            'topics' => (array) ($request['knowledge_topics'] ?? $request['topics'] ?? []),
            'jurisdictions' => (array) ($request['jurisdictions'] ?? []),
            'origin_domain' => $request['origin_domain'] ?? null,
            'processing_domain' => $request['processing_domain'] ?? null,
            'receiving_domain' => $request['receiving_domain'] ?? null,
            'knowledge_required' => true,
            'consequential' => (bool) ($request['consequential'] ?? true),
        ]);

        if (($context['status'] ?? null) !== 'resolved') {
            $this->uncertainty->report($task,null,[
                'domain'=>$request['processing_domain'] ?? $request['origin_domain'] ?? 'general',
                'workflow_key'=>$request['workflow_key'] ?? null,
                'jurisdiction'=>$request['jurisdictions'][0] ?? null,
                'topic'=>implode(' ',(array)($request['knowledge_topics'] ?? $request['topics'] ?? [])) ?: 'Knowledge preflight unresolved',
                'uncertainty_type'=>'preflight-unresolved','privacy_classification'=>$request['privacy_classification'] ?? 'company_private','public_reusable'=>(bool)($request['public_reusable'] ?? false),'confidence'=>0,'risk_class'=>($request['consequential'] ?? true)?'high':'ordinary',
                'reason'=>'Knowledge Authority could not resolve the required context.',
            ]);
            throw new RuntimeException('KNOWLEDGE_AUTHORITY_PREFLIGHT_NOT_RESOLVED');
        }

        $sources = (array) ($context['authoritative_sources'] ?? []);
        $claims = (array) ($context['claims'] ?? []);
        $sections = (array) ($context['sections'] ?? []);
        if (($context['fail_closed_on_missing_authority'] ?? false) && $sources === [] && $claims === [] && $sections === []) {
            $this->uncertainty->report($task,null,[
                'domain'=>$request['processing_domain'] ?? $request['origin_domain'] ?? 'general',
                'workflow_key'=>$request['workflow_key'] ?? null,
                'jurisdiction'=>$request['jurisdictions'][0] ?? null,
                'topic'=>implode(' ',(array)($request['knowledge_topics'] ?? $request['topics'] ?? [])) ?: 'Required authoritative context missing',
                'uncertainty_type'=>'missing-authority','privacy_classification'=>$request['privacy_classification'] ?? 'company_private','public_reusable'=>(bool)($request['public_reusable'] ?? false),'confidence'=>0,'risk_class'=>'high',
                'reason'=>'Required Knowledge Authority context resolved empty.',
            ]);
            throw new RuntimeException('KNOWLEDGE_AUTHORITY_REQUIRED_CONTEXT_EMPTY');
        }

        $freshnessState = (string) ($context['freshness_state'] ?? 'unknown');
        $contradictionState = (string) ($context['contradiction_state'] ?? 'unknown');
        $staleClaimKeys = array_values(array_map('strval', (array) ($context['stale_claim_keys'] ?? [])));
        $contradictionClaimKeys = array_values(array_map('strval', (array) ($context['contradiction_claim_keys'] ?? [])));
        $contextSufficient = (bool) ($context['context_sufficient'] ?? ($sources !== [] || $claims !== [] || $sections !== []));
        $blockingReasonCodes = [];
        if (! $contextSufficient) $blockingReasonCodes[] = 'KNOWLEDGE_CONTEXT_INSUFFICIENT';
        if ($contradictionClaimKeys !== []) $blockingReasonCodes[] = 'KNOWLEDGE_CONTRADICTION_DETECTED';
        if ($staleClaimKeys !== []) $blockingReasonCodes[] = 'KNOWLEDGE_STALE_CLAIMS_PRESENT';

        return [
            'status' => 'RESOLVED',
            'knowledge_required' => true,
            'resolved_at' => $context['resolved_at'] ?? null,
            'source_registry_version' => $context['source_registry_version'] ?? null,
            'source_keys' => array_values(array_filter(array_map(static fn (array $s): ?string => $s['key'] ?? null, $sources))),
            'source_versions' => array_values(array_filter(array_map(static fn (array $c): mixed => $c['source_version_id'] ?? null, $claims))),
            'claim_keys' => array_values(array_filter(array_map(static fn (array $c): ?string => $c['claim_key'] ?? null, $claims))),
            'section_ids' => array_values(array_filter(array_map(static fn (array $section): mixed => $section['section_id'] ?? null, $sections))),
            'authority_floor' => $sources === [] ? null : max(array_map(static fn (array $s): int => (int) ($s['authority_rank'] ?? 0), $sources)),
            'freshness_state' => $freshnessState,
            'stale_claim_keys' => $staleClaimKeys,
            'contradiction_state' => $contradictionState,
            'contradiction_claim_keys' => $contradictionClaimKeys,
            'context_sufficient' => $contextSufficient,
            'blocking_reason_codes' => $blockingReasonCodes,
            'receipt_hash' => hash('sha256', json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)),
        ];
    }
}
