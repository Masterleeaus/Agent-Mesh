<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Navigation\HostNavigationRegistrar;
use Illuminate\Console\Command;

final class SyncWorkforceMenuCommand extends Command
{
    protected $signature = 'titan-workforce:host-sync';
    protected $description = 'Synchronise Titan AI Workforce parent/child navigation with the Titan/MagicAI host and refresh menu caches.';

    public function handle(HostNavigationRegistrar $registrar): int
    {
        $registrar->registerContributions();
        $result = $registrar->syncHostMenu(true);

        if (! ($result['available'] ?? false)) {
            $this->warn('Titan/MagicAI menu hierarchy is not available; contribution-registry registration was still attempted.');
            if (($result['reason'] ?? null) !== null) $this->line('Reason: '.(string) $result['reason']);
            return self::SUCCESS;
        }

        $this->info(($result['changed'] ?? false) ? 'AI Workforce menu hierarchy synchronised.' : 'AI Workforce menu hierarchy already current.');
        $this->line(($result['regenerated'] ?? false) ? 'MagicAI menu cache regenerated.' : 'MagicAI MenuService regeneration was unnecessary or unavailable.');
        return self::SUCCESS;
    }
}
