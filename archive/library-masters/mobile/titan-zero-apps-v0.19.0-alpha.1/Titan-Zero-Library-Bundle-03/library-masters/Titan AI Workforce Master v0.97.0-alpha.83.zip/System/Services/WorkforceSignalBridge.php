<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSignalOutbox;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Illuminate\Contracts\Events\Dispatcher;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

final class WorkforceSignalBridge
{
    public function __construct(
        private readonly Dispatcher $events,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    public function emit(int $companyId, string $eventType, array $payload, string $traceId, string $correlationId, ?string $causationId = null): string
    {
        $outbox = WorkforceSignalOutbox::query()->create([
            'signal_id' => (string) Str::uuid(),
            'company_id' => $companyId,
            'event_type' => $eventType,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'payload' => $payload,
        ]);
        $this->publish($outbox);
        return (string) $outbox->signal_id;
    }

    public function retry(WorkforceSignalOutbox $outbox): bool
    {
        if ($outbox->published_at) { return true; }
        return CompanyContext::runWith((int) $outbox->company_id, fn (): bool => $this->publish($outbox));
    }

    private function publish(WorkforceSignalOutbox $outbox): bool
    {
        try {
            $envelope = [
                'signal_id' => $outbox->signal_id,
                'event_type' => $outbox->event_type,
                'company_id' => $outbox->company_id,
                'trace_id' => $outbox->trace_id,
                'correlation_id' => $outbox->correlation_id,
                'causation_id' => $outbox->causation_id,
                'payload' => $outbox->payload ?? [],
            ];

            $deliveredToTitanSignal = false;
            foreach ($this->controlPlane->bindingsFor('signal') as $binding) {
                if (! app()->bound($binding)) continue;
                $signal = app($binding);
                foreach ($this->controlPlane->methodsFor('signal') as $method) {
                    if (! method_exists($signal, $method)) continue;
                    if ($method === 'emit') $signal->{$method}((string) $outbox->event_type, $envelope);
                    else $signal->{$method}($envelope);
                    $deliveredToTitanSignal = true;
                    break 2;
                }
            }

            // Compatibility event is local only and is never treated as proof that Titan Signal accepted the event.
            $this->events->dispatch('titan.workforce.signal', [$envelope]);
            if (! $deliveredToTitanSignal) {
                $outbox->forceFill([
                    'publish_attempts' => ((int) $outbox->publish_attempts) + 1,
                    'last_error' => 'Titan Signal adapter unavailable; event retained in durable outbox.',
                ])->save();
                return false;
            }

            $outbox->forceFill([
                'published_at' => now(),
                'failed_at' => null,
                'last_error' => null,
                'publish_attempts' => ((int) $outbox->publish_attempts) + 1,
            ])->save();
            return true;
        } catch (Throwable $e) {
            $outbox->forceFill([
                'publish_attempts' => ((int) $outbox->publish_attempts) + 1,
                'failed_at' => now(),
                'last_error' => mb_substr($e->getMessage(), 0, 4000),
            ])->save();
            Log::warning('Titan AI Workforce Signal delivery deferred to outbox.', [
                'signal_id' => $outbox->signal_id,
                'event' => $outbox->event_type,
            ]);
            return false;
        }
    }
}
