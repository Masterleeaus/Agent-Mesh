<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class WorkforceBusinessContextSourceCatalog
{
    private const DEFAULT_PATH = __DIR__.'/../../resources/workforce/business-context-source-catalog.json';
    private ?array $document = null;

    public function __construct(private readonly ?string $path = null) {}

    public function all(): array
    {
        if ($this->document !== null) return $this->document;
        $path = $this->path ?: self::DEFAULT_PATH;
        if (! is_file($path)) throw new RuntimeException("Workforce context source catalog missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)
            || ($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['sources'] ?? null)) {
            throw new RuntimeException('Workforce context source catalog is invalid.');
        }
        return $this->document = $decoded;
    }

    public function source(string $surfaceId): ?array
    {
        foreach ($this->all()['sources'] as $source) {
            if (is_array($source) && (string) ($source['id'] ?? '') === $surfaceId) return $source;
        }
        return null;
    }

    public function allowedFor(string $surfaceId, string $roleDefinitionId, string $responsibilityId): bool
    {
        $source = $this->source($surfaceId);
        if (! $source) return false;
        return in_array($roleDefinitionId, (array) ($source['allowed_roles'] ?? []), true)
            && in_array($responsibilityId, (array) ($source['allowed_responsibilities'] ?? []), true);
    }
}
