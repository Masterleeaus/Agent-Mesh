<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff as WorkforceHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;

final class WorkforcePerformanceCoachingService
{
    private const DIMENSIONS = ['employee','role','team','division','responsibility','workflow'];
    private const CLOSED = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function snapshot(int $companyId): array
    {
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->with(['assignee:id,name,role,role_definition_id,team_id,division_id','team:id,name','division:id,name'])
            ->latest('id')->limit(5000)->get();
        $taskIds = $tasks->pluck('id');

        $history = WorkforceTaskHistory::query()->where('company_id', $companyId)
            ->whereIn('task_id', $taskIds)->get();
        $handoffs = WorkforceHandoff::query()->forCompany($companyId)
            ->whereIn('task_id', $taskIds)->get();
        $escalations = WorkforceEscalation::query()->forCompany($companyId)
            ->whereIn('task_id', $taskIds)->get();
        $attempts = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->whereIn('task_id', $taskIds)->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)
            ->whereNotNull('verified_at')->whereIn('task_id', $taskIds)->get();

        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)
            ->with(['team:id,name','division:id,name'])->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member) => (bool) data_get($member->metadata ?? [], 'internal', false));

        $historyByTask = $history->groupBy('task_id');
        $handoffsByTask = $handoffs->groupBy('task_id');
        $escalationsByTask = $escalations->groupBy('task_id');
        $attemptsByTask = $attempts->groupBy('task_id');
        $outcomesByTask = $outcomes->groupBy('task_id');

        $rows = $members->map(function (WorkforceMember $member) use ($tasks, $historyByTask, $handoffsByTask, $escalationsByTask, $attemptsByTask, $outcomesByTask): array {
            $memberTasks = $tasks->where('assignee_member_id', $member->id)->values();
            return $this->memberInsight($member, $memberTasks, $historyByTask, $handoffsByTask, $escalationsByTask, $attemptsByTask, $outcomesByTask);
        })->values();

        return [
            'company_id' => $companyId,
            'dimensions' => self::DIMENSIONS,
            'employees' => $rows->all(),
            'strengths' => $rows->flatMap(fn (array $row) => $row['strengths'])->values()->take(12)->all(),
            'weak_responsibilities' => $this->weakResponsibilities($tasks, $historyByTask, $outcomesByTask),
            'recommendations' => $rows->flatMap(fn (array $row) => $row['recommendations'])->values()->take(20)->all(),
            'authority_changed' => false,
            'autonomy_changed' => false,
            'capability_granted' => false,
            'risk_ceiling_changed' => false,
            'automatic_reconfiguration' => false,
            'verified_outcomes_drive_coaching' => true,
            'read_only_projection' => true,
        ];
    }

    private function memberInsight(
        WorkforceMember $member,
        Collection $tasks,
        Collection $historyByTask,
        Collection $handoffsByTask,
        Collection $escalationsByTask,
        Collection $attemptsByTask,
        Collection $outcomesByTask,
    ): array {
        $completed = $tasks->filter(fn (WorkforceTask $task) => $this->status($task) === 'COMPLETED')->count();
        $closed = $tasks->filter(fn (WorkforceTask $task) => in_array($this->status($task), self::CLOSED, true))->count();
        $reviews = 0;
        $revisions = 0;
        $failedHandoffs = 0;
        $escalations = 0;
        $executionSeconds = [];
        $verified = 0;
        $successful = 0;

        foreach ($tasks as $task) {
            $taskHistory = $historyByTask->get($task->id, collect());
            $reviews += $taskHistory->filter(fn ($row) => $this->isReview((string) $row->event))->count();
            $revisions += $taskHistory->filter(fn ($row) => $this->isRevision((string) $row->event))->count();
            $failedHandoffs += $handoffsByTask->get($task->id, collect())->filter(fn ($row) => in_array($this->enumValue($row->status), ['REJECTED','RETURNED','ESCALATED'], true))->count();
            $escalations += $escalationsByTask->get($task->id, collect())->count();
            foreach ($attemptsByTask->get($task->id, collect()) as $attempt) {
                $start = $attempt->dispatched_at ?? $attempt->created_at;
                $end = $attempt->verified_at ?? $attempt->updated_at;
                if ($start && $end) $executionSeconds[] = max(0, $start->diffInSeconds($end));
            }
            foreach ($outcomesByTask->get($task->id, collect()) as $outcome) {
                $verified++;
                if ($outcome->success === true) $successful++;
            }
        }

        $revisionRate = $reviews > 0 ? round($revisions / $reviews, 4) : 0.0;
        $conversion = $closed > 0 ? round($successful / $closed, 4) : 0.0;
        $avgExecutionSeconds = $executionSeconds !== [] ? (int) round(array_sum($executionSeconds) / count($executionSeconds)) : 0;
        $highRevisionRate = $reviews >= 3 && $revisionRate >= 0.30;
        $recurringEscalations = $escalations >= 2;
        $slowExecution = count($executionSeconds) >= 2 && $avgExecutionSeconds >= 900;
        $poorOutcomeConversion = $closed >= 3 && $verified >= 2 && $conversion < 0.50;

        $strengths = [];
        if ($completed >= 3 && $revisionRate <= 0.10) $strengths[] = $this->strength($member, 'review_quality', 'Strong review quality', 'Low revision pressure across completed work.');
        if ($successful >= 3 && $conversion >= 0.75) $strengths[] = $this->strength($member, 'outcome_conversion', 'Strong verified outcome conversion', 'Verified successful outcomes are converting at a high rate.');
        if ($failedHandoffs === 0 && $completed >= 3) $strengths[] = $this->strength($member, 'handoff_quality', 'Reliable handoffs', 'No rejected, returned or escalated handoffs in the current evidence window.');
        if ($escalations === 0 && $completed >= 3) $strengths[] = $this->strength($member, 'escalation_control', 'Stable independent delivery', 'Completed work without recurring escalation pressure.');

        $recommendations = [];
        if ($highRevisionRate) $recommendations[] = $this->recommendation($member, 'coaching', 'Review recurring revision causes', 'High revision rate', 'Inspect manager revision reasons, then coach the employee on the repeated quality gap.');
        if ($failedHandoffs >= 2) $recommendations[] = $this->recommendation($member, 'reconfiguration', 'Tighten handoff preparation', 'Repeated failed handoffs', 'Review evidence completeness and receiving-team expectations before future handoffs.');
        if ($recurringEscalations) $recommendations[] = $this->recommendation($member, 'coaching', 'Review escalation patterns', 'Recurring escalations', 'Identify whether missing data, capability gaps or unclear responsibility boundaries are driving escalation.');
        if ($slowExecution) $recommendations[] = $this->recommendation($member, 'workflow', 'Investigate execution latency', 'Slow execution', 'Inspect provider latency, queue pressure and command verification time before changing staffing.');
        if ($poorOutcomeConversion) $recommendations[] = $this->recommendation($member, 'coaching', 'Improve business-outcome conversion', 'Poor verified outcome conversion', 'Compare successful and unsuccessful completed work and adjust coaching or workflow configuration.');

        return [
            'employee' => ['id'=>$member->id,'name'=>$member->name,'role'=>$member->role,'role_definition_id'=>$member->role_definition_id],
            'team' => $member->team?->name,
            'division' => $member->division?->name,
            'activity' => ['tasks'=>$tasks->count(),'completed'=>$completed,'reviews'=>$reviews,'revisions'=>$revisions,'failed_handoffs'=>$failedHandoffs,'escalations'=>$escalations],
            'verified_outcomes' => ['count'=>$verified,'successful'=>$successful,'conversion_rate'=>$conversion],
            'execution' => ['attempts'=>count($executionSeconds),'average_seconds'=>$avgExecutionSeconds],
            'high_revision_rate' => $highRevisionRate,
            'failed_handoffs' => $failedHandoffs,
            'recurring_escalations' => $recurringEscalations,
            'slow_execution' => $slowExecution,
            'poor_outcome_conversion' => $poorOutcomeConversion,
            'strengths' => $strengths,
            'recommendations' => $recommendations,
            'authority_changed' => false,
            'autonomy_changed' => false,
        ];
    }

    private function weakResponsibilities(Collection $tasks, Collection $historyByTask, Collection $outcomesByTask): array
    {
        $groups = [];
        foreach ($tasks as $task) {
            $meta = (array) ($task->metadata ?? []);
            $id = (string) ($meta['responsibility_id'] ?? $meta['responsibility_definition_id'] ?? '');
            if ($id === '') continue;
            $groups[$id] ??= ['responsibility_id'=>$id,'name'=>(string)($meta['responsibility_name'] ?? $id),'tasks'=>0,'revisions'=>0,'verified'=>0,'successful'=>0];
            $groups[$id]['tasks']++;
            $groups[$id]['revisions'] += $historyByTask->get($task->id, collect())->filter(fn ($row) => $this->isRevision((string) $row->event))->count();
            foreach ($outcomesByTask->get($task->id, collect()) as $outcome) {
                $groups[$id]['verified']++;
                if ($outcome->success === true) $groups[$id]['successful']++;
            }
        }
        foreach ($groups as &$row) {
            $row['outcome_conversion'] = $row['verified'] > 0 ? round($row['successful'] / $row['verified'], 4) : null;
            $row['weak'] = $row['tasks'] >= 3 && ($row['revisions'] >= 2 || ($row['verified'] >= 2 && $row['outcome_conversion'] < 0.5));
        }
        unset($row);
        return array_values(array_filter($groups, fn (array $row) => $row['weak']));
    }

    private function strength(WorkforceMember $member, string $signal, string $title, string $reason): array
    {
        return ['member_id'=>$member->id,'employee'=>$member->name,'signal'=>$signal,'title'=>$title,'reason'=>$reason];
    }

    private function recommendation(WorkforceMember $member, string $type, string $title, string $trigger, string $action): array
    {
        return [
            'member_id'=>$member->id,'employee'=>$member->name,'type'=>$type,'title'=>$title,'trigger'=>$trigger,'recommended_action'=>$action,
            'advisory_only'=>true,'authority_changed'=>false,'autonomy_changed'=>false,'capability_granted'=>false,'risk_ceiling_changed'=>false,'automatic_reconfiguration'=>false,
        ];
    }

    private function isReview(string $event): bool
    {
        $event = strtolower($event);
        return str_contains($event, 'review') || str_contains($event, 'approved') || str_contains($event, 'revision');
    }

    private function isRevision(string $event): bool
    {
        $event = strtolower($event);
        return str_contains($event, 'revision') || str_contains($event, 'returned');
    }

    private function status(WorkforceTask $task): string { return $this->enumValue($task->status); }
    private function enumValue(mixed $value): string { return is_object($value) && isset($value->value) ? (string) $value->value : (string) $value; }
}
