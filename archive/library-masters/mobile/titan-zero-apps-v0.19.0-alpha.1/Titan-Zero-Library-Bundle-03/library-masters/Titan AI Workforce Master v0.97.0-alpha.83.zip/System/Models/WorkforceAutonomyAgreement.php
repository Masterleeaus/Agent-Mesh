<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceAutonomyAgreement extends Model
{
    protected $table='ext_titan_ai_workforce_autonomy_agreements';
    protected $guarded=[];
    protected $casts=[
        'platform_approved_at'=>'datetime',
        'user_accepted_at'=>'datetime',
        'ai_accepted_at'=>'datetime',
        'revoked_at'=>'datetime',
        'constraints'=>'array',
        'metadata'=>'array',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
