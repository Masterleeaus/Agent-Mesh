<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceMemberLifecycleState: string
{
    case Invited = 'INVITED';
    case Configuring = 'CONFIGURING';
    case Ready = 'READY';
    case Active = 'ACTIVE';
    case Suspended = 'SUSPENDED';
    case Retired = 'RETIRED';

    public function canTransitionTo(self $target): bool
    {
        if ($this === $target) return true;

        return match ($this) {
            self::Invited => in_array($target, [self::Configuring, self::Suspended, self::Retired], true),
            self::Configuring => in_array($target, [self::Ready, self::Suspended, self::Retired], true),
            self::Ready => in_array($target, [self::Active, self::Suspended, self::Retired], true),
            self::Active => in_array($target, [self::Suspended, self::Retired], true),
            self::Suspended => in_array($target, [self::Ready, self::Active, self::Retired], true),
            self::Retired => false,
        };
    }
}
