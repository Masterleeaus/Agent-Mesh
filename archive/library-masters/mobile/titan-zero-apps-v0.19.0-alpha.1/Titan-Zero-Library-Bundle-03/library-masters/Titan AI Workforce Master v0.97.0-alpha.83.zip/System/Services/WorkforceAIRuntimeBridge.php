<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Contracts\AgentRuntimeContract;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeIdentity;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeRequest;
use RuntimeException;

/**
 * Workforce-facing intelligence bridge. Organisational/task authority stays here;
 * reasoning is delegated only through the versioned AgentRuntimeContract.
 */
final class WorkforceAIRuntimeBridge
{
    public function __construct(
        private readonly AgentRuntimeContract $runtime,
        private readonly RuntimeProfileBindingService $runtimeProfiles,
        private readonly WorkforceStructuredOutputService $structuredOutput,
    ) {}

    public function perform(WorkforceTask $task, WorkforceMember $member): array
    {
        $profile = $this->runtimeProfiles->forTask($task, $member);
        $task = $task->refresh();

        if ($member->tier === WorkforceTier::Manager) {
            $message = "Act as {$member->role}. Decompose the objective into a deterministic workforce_plan. Return JSON only. workforce_plan.steps must contain: id, title, role_key, capability, depends_on[], priority, optional deadline_at, optional handoff_to_division, handoff_to_role_key and handoff_to_capability. Assign only Tier-2 specialists from your own division. Cross-division work must be expressed as a handoff after your specialist completes and you review it. Also return presentation_intent, recommended_components, recommended_actions, confidence, and evidence as advisory structured fields. Components must be semantic registry IDs only; actions are proposals only. Do not execute business actions, emit executable UI, or self-approve.\n\nObjective: {$task->title}\n";
        } else {
            $message = "Complete the assigned Workforce task as {$member->role}. Return a concise structured proposal, evidence references, missing information, recommended next state, and any handoff required. Also return presentation_intent, recommended_components, recommended_actions, confidence, and evidence. Components must be semantic registry IDs only and recommendations must not claim authority. Do not claim execution has occurred or emit executable UI.\n\nTask: {$task->title}\n";
        }
        if ($task->description) { $message .= "Description: {$task->description}\n"; }
        if ($task->capability) { $message .= "Requested capability: {$task->capability}\n"; }

        $identity = RuntimeIdentity::fromTask($task, $member, null);
        $request = new RuntimeRequest(
            identity: $identity,
            instruction: $message,
            payload: [
                'workforce_member' => $member->toArray(),
                'workforce_task' => $task->toArray(),
                'evidence' => $task->evidence ?? [],
                'governance' => [
                    'risk_level' => $task->risk_level,
                    'no_direct_business_mutation' => true,
                    'requires_manager_review' => true,
                ],
            ],
            toolPermissions: [],
            metadata: [
                'runtime_profile' => $this->runtimeProfiles->runtimePayload($profile),
                'workforce_member_key' => (string) $member->key,
                'workforce_tier' => $member->tier->value,
                'execution_authority' => 'none',
                'workflow_id' => data_get($task->metadata ?? [], 'workflow_id'),
                'legacy_conversation_id' => (string) $task->correlation_id,
            ],
            responseMode: 'json',
            idempotencyKey: 'workforce-ai:' . $task->task_uuid . ':' . $task->attempt_count,
        );

        $response = $this->runtime->execute($request);
        if (! in_array($response->status, ['completed', 'tool_proposal'], true)) {
            $failure = $response->failure?->message ?? 'Agent Runtime is unavailable or did not return a usable proposal.';
            throw new RuntimeException($failure);
        }

        return $this->structuredOutput->normalize($task, $member, $response->legacyOutput());
    }
}
