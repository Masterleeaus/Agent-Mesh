<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceNotification;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceNotificationPreference;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;

/**
 * Converts authoritative Attention Center conditions into informational notifications.
 * Notifications never carry or inherit execution authority.
 */
final class WorkforceNotificationRoutingService
{
    public const AUDIENCE_IN_APP = 'in_app';
    public const AUDIENCE_OWNER_ADMIN = 'owner_admin';
    public const AUDIENCE_RESPONSIBLE_MANAGER = 'responsible_manager';
    public const AUDIENCE_SPECIFIC_TEAM = 'specific_team';

    public function __construct(private readonly WorkforceAttentionCenterService $attention) {}

    public function preferences(int $companyId): WorkforceNotificationPreference
    {
        return WorkforceNotificationPreference::query()->firstOrCreate(
            ['company_id' => $companyId],
            ['severity_threshold' => 3, 'in_app' => true, 'route_owner_admin' => true, 'route_responsible_manager' => true, 'route_specific_team' => true]
        );
    }

    /** @return array<string,mixed> */
    public function sync(int $companyId): array
    {
        $preferences = $this->preferences($companyId);
        $attention = $this->attention->snapshot($companyId);
        $seen = [];
        $created = 0;
        $updated = 0;

        foreach ($attention['items'] as $item) {
            if ((int) ($item['severity_score'] ?? 0) < (int) $preferences->severity_threshold) continue;
            $context = is_array($item['context'] ?? null) ? $item['context'] : [];
            [$managerId, $teamId] = $this->resolveRoutingContext($companyId, $context);
            $audience = $this->audience($preferences, $managerId, $teamId);
            if ($audience === []) continue;

            $dedupeKey = hash('sha256', implode('|', [
                (string) ($item['category'] ?? 'attention'),
                (string) ($context['task_id'] ?? ''),
                (string) ($context['member_id'] ?? ''),
                (string) ($context['attempt_id'] ?? ''),
                (string) ($context['escalation_id'] ?? ''),
                (string) ($context['proposal_id'] ?? ''),
                (string) ($item['title'] ?? ''),
            ]));
            $seen[] = $dedupeKey;

            $existing = WorkforceNotification::query()->forCompany($companyId)->where('dedupe_key', $dedupeKey)->first();
            $values = [
                'category' => (string) $item['category'],
                'severity_score' => (int) $item['severity_score'],
                'priority_score' => (int) $item['priority_score'],
                'title' => (string) $item['title'],
                'detail' => (string) $item['detail'],
                'url' => (string) $item['url'],
                'audience_scope' => $audience,
                'responsible_manager_member_id' => $managerId,
                'team_id' => $teamId,
                'is_active' => true,
                'last_seen_at' => now(),
                'resolved_at' => null,
                'occurrence_count' => $existing ? ((int) $existing->occurrence_count + 1) : 1,
                'metadata' => ['attention_context' => $context, 'authority_inherited' => false],
            ];
            if (! $existing) $values['first_seen_at'] = now();

            WorkforceNotification::query()->updateOrCreate(
                ['company_id' => $companyId, 'dedupe_key' => $dedupeKey],
                $values
            );
            $existing ? $updated++ : $created++;
        }

        $stale = WorkforceNotification::query()->forCompany($companyId)->where('is_active', true);
        if ($seen !== []) $stale->whereNotIn('dedupe_key', $seen);
        $resolved = $stale->update(['is_active' => false, 'resolved_at' => now()]);

        return ['created'=>$created,'updated'=>$updated,'resolved'=>$resolved,'active'=>count($seen),'authority_inherited'=>false];
    }

    /** @return array<string,mixed> */
    public function inbox(int $companyId): array
    {
        $this->sync($companyId);
        $preferences = $this->preferences($companyId);
        $rows = WorkforceNotification::query()->forCompany($companyId)->where('is_active', true)
            ->orderByDesc('priority_score')->orderBy('acknowledged_at')->orderByDesc('last_seen_at')->limit(500)->get();
        return [
            'notifications'=>$rows,
            'preferences'=>$preferences,
            'unacknowledged'=>$rows->whereNull('acknowledged_at')->count(),
            'acknowledged'=>$rows->whereNotNull('acknowledged_at')->count(),
            'authority_inherited'=>false,
        ];
    }

    public function acknowledge(int $companyId, WorkforceNotification $notification, int $userId): WorkforceNotification
    {
        if ((int) $notification->company_id !== $companyId) throw new \InvalidArgumentException('Notification belongs to another company.');
        $notification->forceFill(['acknowledged_at'=>now(),'acknowledged_by'=>$userId])->save();
        return $notification->fresh();
    }

    /** @param array<string,mixed> $values */
    public function updatePreferences(int $companyId, array $values): WorkforceNotificationPreference
    {
        $preference = $this->preferences($companyId);
        $preference->fill([
            'severity_threshold'=>max(1,min(5,(int) ($values['severity_threshold'] ?? 3))),
            'in_app'=>(bool) ($values['in_app'] ?? false),
            'route_owner_admin'=>(bool) ($values['route_owner_admin'] ?? false),
            'route_responsible_manager'=>(bool) ($values['route_responsible_manager'] ?? false),
            'route_specific_team'=>(bool) ($values['route_specific_team'] ?? false),
        ])->save();
        return $preference->fresh();
    }

    /** @return array{0:?int,1:?int} */
    private function resolveRoutingContext(int $companyId, array $context): array
    {
        if (! empty($context['task_id'])) {
            $task = WorkforceTask::query()->forCompany($companyId)->find((int) $context['task_id']);
            if ($task) return [$task->manager_member_id ? (int) $task->manager_member_id : null, $task->team_id ? (int) $task->team_id : null];
        }
        if (! empty($context['member_id'])) {
            $member = WorkforceMember::query()->forCompany($companyId)->find((int) $context['member_id']);
            if ($member) return [$member->manager_id ? (int) $member->manager_id : null, $member->team_id ? (int) $member->team_id : null];
        }
        return [null, null];
    }

    /** @return list<array<string,mixed>> */
    private function audience(WorkforceNotificationPreference $preferences, ?int $managerId, ?int $teamId): array
    {
        $audience = [];
        if ($preferences->in_app) $audience[] = ['type'=>self::AUDIENCE_IN_APP];
        if ($preferences->route_owner_admin) $audience[] = ['type'=>self::AUDIENCE_OWNER_ADMIN];
        if ($preferences->route_responsible_manager && $managerId) $audience[] = ['type'=>self::AUDIENCE_RESPONSIBLE_MANAGER,'member_id'=>$managerId];
        if ($preferences->route_specific_team && $teamId) $audience[] = ['type'=>self::AUDIENCE_SPECIFIC_TEAM,'team_id'=>$teamId];
        return $audience;
    }
}
