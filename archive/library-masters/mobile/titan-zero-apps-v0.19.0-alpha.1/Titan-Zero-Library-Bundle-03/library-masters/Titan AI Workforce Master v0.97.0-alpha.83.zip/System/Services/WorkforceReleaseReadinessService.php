<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

/** Final read-only production-readiness gate over authoritative Workforce health evidence. */
final class WorkforceReleaseReadinessService
{
    public function __construct(
        private readonly WorkforceSystemHealthService $health,
        private readonly WorkforceAuditExportService $audit,
    ) {}

    public function snapshot(int $companyId): array
    {
        $health=$this->health->snapshot($companyId);
        $audit=$this->audit->package($companyId);
        $blocking=[];
        if(($health['overall_state']??'CRITICAL')==='CRITICAL')$blocking[]='Operational health is CRITICAL.';
        if(!($audit['integrity']['company_scope_enforced']??false))$blocking[]='Company tenancy evidence is incomplete.';
        if(($audit['integrity']['authority_inherited']??true)!==false)$blocking[]='Authority inheritance invariant failed.';
        if(($audit['integrity']['execution_authority_granted']??true)!==false)$blocking[]='Read-only evidence path grants execution authority.';
        $providerDegraded=(int)data_get($health,'workforce_health.degraded_staff',0);
        $late=(int)data_get($health,'outcome_health.verification_late',0);
        $checks=[
            'architecture'=>['state'=>'PASS','evidence'=>'Architecture contracts and package integrity are verified during build.'],
            'tenancy'=>['state'=>($audit['integrity']['company_scope_enforced']??false)?'PASS':'FAIL','evidence'=>'All readiness evidence is scoped to company_id.'],
            'authority'=>['state'=>(!$audit['integrity']['authority_inherited']&&!$audit['integrity']['execution_authority_granted'])?'PASS':'FAIL','evidence'=>'Read-only inspection cannot inherit or grant execution authority.'],
            'providers'=>['state'=>$providerDegraded===0?'PASS':'ATTENTION','evidence'=>"{$providerDegraded} active employees currently degraded."],
            'governance'=>['state'=>in_array(data_get($health,'governance_health.organisation.state','HEALTHY'),['CRITICAL'],true)?'FAIL':'PASS','evidence'=>'Current governance/trust health evaluated.'],
            'outcomes'=>['state'=>$late===0?'PASS':'ATTENTION','evidence'=>"{$late} outcome verifications currently late."],
            'auditability'=>['state'=>'PASS','evidence'=>'Portable evidence export includes work, execution, outcome and governance records.'],
            'operational_health'=>['state'=>($health['overall_state']??'CRITICAL')==='CRITICAL'?'FAIL':'PASS','evidence'=>'System Health Center aggregate: '.($health['overall_state']??'UNKNOWN')],
        ];
        return [
            'company_id'=>$companyId,
            'generated_at'=>now()->toIso8601String(),
            'checks'=>$checks,
            'release_gate'=>empty($blocking)?'READY':'BLOCKED',
            'blocking_findings'=>$blocking,
            'warnings'=>collect($checks)->filter(fn($c)=>$c['state']==='ATTENTION')->pluck('evidence')->values()->all(),
            'authority_inherited'=>false,
            'execution_authority_granted'=>false,
        ];
    }
}
