<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceTier: int
{
    case Manager = 1;
    case Specialist = 2;
    case ActionWorker = 3;

    public function label(): string
    {
        return match ($this) {
            self::Manager => 'Manager',
            self::Specialist => 'Specialist',
            self::ActionWorker => 'Action Worker',
        };
    }
}
