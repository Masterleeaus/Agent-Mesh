<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManifestLifecycleService;
use Illuminate\Console\Command;

final class ReconcileWorkforceDefinitionsCommand extends Command
{
    protected $signature = 'titan-workforce:reconcile-definitions {extension? : Exact owner extension key}';
    protected $description = 'Reconcile instantiated Workforce members against extension-owned role definitions without deleting history.';

    public function handle(WorkforceManifestLifecycleService $lifecycle): int
    {
        $extension = trim((string) ($this->argument('extension') ?? ''));
        $result = $extension !== '' ? [$extension => $lifecycle->reconcileExtension($extension)] : $lifecycle->reconcileAll();
        foreach ($result as $owner => $stats) {
            $this->line($owner . ': ' . json_encode($stats, JSON_UNESCAPED_SLASHES));
        }
        return self::SUCCESS;
    }
}
