<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use InvalidArgumentException;

/** Deterministic escalation over the persisted tenant reporting graph. */
final class WorkforceEscalationService
{
    /** @return list<WorkforceMember> member first, then its reporting chain */
    public function chainFor(WorkforceMember $member): array
    {
        $chain = [];
        $cursor = $member;
        $seen = [];
        for ($depth = 0; $depth < 128; $depth++) {
            $id = (int) $cursor->id;
            if (isset($seen[$id])) {
                throw new InvalidArgumentException('HUMAN_DECISION_REQUIRED: reporting graph contains a cycle.');
            }
            $seen[$id] = true;
            $chain[] = $cursor;
            $managerId = (int) ($cursor->manager_id ?? 0);
            if ($managerId <= 0) break;
            $next = WorkforceMember::query()->forCompany((int) $member->company_id)->find($managerId);
            if (! $next) break;
            $cursor = $next;
        }
        return $chain;
    }

    public function commonManager(int $companyId, array $participantMemberIds): ?WorkforceMember
    {
        $participantMemberIds = array_values(array_unique(array_map('intval', $participantMemberIds)));
        if (count($participantMemberIds) < 2) return null;
        $chains = [];
        foreach ($participantMemberIds as $id) {
            $member = WorkforceMember::query()->forCompany($companyId)->find($id);
            if (! $member) return null;
            $chains[] = $this->chainFor($member);
        }
        $first = $chains[0];
        foreach ($first as $candidate) {
            $candidateId = (int) $candidate->id;
            if (in_array($candidateId, $participantMemberIds, true)) continue;
            $inAll = true;
            foreach (array_slice($chains, 1) as $chain) {
                $ids = array_map(static fn (WorkforceMember $m): int => (int) $m->id, $chain);
                if (! in_array($candidateId, $ids, true)) { $inAll = false; break; }
            }
            if ($inAll && $candidate->is_active) return $candidate;
        }
        return null;
    }

    public function resolveDisputeManager(int $companyId, array $participantMemberIds): WorkforceMember
    {
        $manager = $this->commonManager($companyId, $participantMemberIds);
        if (! $manager) {
            throw new InvalidArgumentException('HUMAN_DECISION_REQUIRED: no unambiguous common escalation Manager exists.');
        }
        return $manager;
    }
}
