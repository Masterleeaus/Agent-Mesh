<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use DateTimeInterface;

/**
 * Deterministic identities for extension-owned proactive routines and deliveries.
 * Identities bind owner + role + routine definition so retries cannot silently
 * cross an extension upgrade or another role instance.
 */
final class WorkforceProactiveIdentity
{
    public static function routineFingerprint(array $routine): string
    {
        $identity = [
            'owner_extension' => (string) ($routine['owner_extension'] ?? ''),
            'role_definition_id' => (string) ($routine['role_definition_id'] ?? $routine['role_id'] ?? ''),
            'routine_id' => (string) ($routine['routine_id'] ?? $routine['key'] ?? ''),
            'trigger_type' => (string) ($routine['trigger_type'] ?? ''),
            'event_type' => $routine['event_type'] ?? null,
            'schedule' => $routine['schedule'] ?? null,
            'conditions' => $routine['conditions'] ?? [],
            'creates' => (string) ($routine['creates'] ?? ''),
            'source_schema_version' => (string) ($routine['source_schema_version'] ?? ''),
        ];
        return hash('sha256', json_encode(self::canonicalize($identity), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    public static function scheduleIdempotencyKey(
        int $companyId,
        int $memberId,
        string $ownerExtension,
        string $roleDefinitionId,
        string $routineId,
        string $routineFingerprint,
        DateTimeInterface|string $occurrence,
    ): string {
        $occurrenceKey = $occurrence instanceof DateTimeInterface
            ? $occurrence->format('Y-m-d\TH:i:sP')
            : trim($occurrence);
        return 'proactive:schedule:' . hash('sha256', implode('|', [
            $companyId,
            $memberId,
            $ownerExtension,
            $roleDefinitionId,
            $routineId,
            $routineFingerprint,
            $occurrenceKey,
        ]));
    }

    public static function signalIdempotencyKey(
        int $companyId,
        int $memberId,
        string $ownerExtension,
        string $roleDefinitionId,
        string $routineId,
        string $routineFingerprint,
        string $eventType,
        ?string $signalId,
        array $envelope,
    ): string {
        $deliveryIdentity = trim((string) $signalId);
        if ($deliveryIdentity === '') {
            $deliveryIdentity = hash('sha256', json_encode(self::canonicalize([
                'event_type' => $eventType,
                'envelope' => $envelope,
            ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        }
        return 'proactive:signal:' . hash('sha256', implode('|', [
            $companyId,
            $memberId,
            $ownerExtension,
            $roleDefinitionId,
            $routineId,
            $routineFingerprint,
            $eventType,
            $deliveryIdentity,
        ]));
    }

    public static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) {
            return array_map([self::class, 'canonicalize'], $value);
        }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = self::canonicalize($item);
        return $value;
    }
}
