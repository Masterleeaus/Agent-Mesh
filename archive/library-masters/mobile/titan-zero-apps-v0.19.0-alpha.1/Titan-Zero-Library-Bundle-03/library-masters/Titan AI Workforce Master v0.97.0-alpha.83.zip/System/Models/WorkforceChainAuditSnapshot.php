<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainAuditSnapshot extends Model
{
    protected $table='ext_titan_ai_workforce_chain_audit_snapshots';
    protected $guarded=[];
    protected $casts=['reconstruction'=>'array','captured_at'=>'datetime','sequence'=>'integer'];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
