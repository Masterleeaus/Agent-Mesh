<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use RuntimeException;

/** Read-only lifecycle surface used by Titan Zero/Control Room and later hardening passes. */
final class WorkforceControlPlaneLifecycleService
{
    public function __construct(private readonly WorkforceControlPlaneIntegrationRegistry $registry) {}

    /** @return array<string,mixed> */
    public function lifecycle(int $companyId): array
    {
        if ($companyId <= 0) throw new RuntimeException('company_id must be positive.');
        $stages = [];
        foreach ($this->registry->integrations() as $integration) {
            $key = (string) $integration['key'];
            $stages[] = array_merge($integration, ['availability' => $this->registry->availability($key)]);
        }
        return [
            'company_id' => $companyId,
            'authority_inherited' => false,
            'lifecycle' => ['observe','mission','plan','reason','deliberate','risk','assure','govern','authorize','execute','recover','learn'],
            'stages' => $stages,
            'execution_gates' => $this->executionGateStatus($companyId),
        ];
    }

    /** @return array<string,mixed> */
    public function executionGateStatus(int $companyId): array
    {
        return $this->registry->executionGateStatus($companyId);
    }
}
