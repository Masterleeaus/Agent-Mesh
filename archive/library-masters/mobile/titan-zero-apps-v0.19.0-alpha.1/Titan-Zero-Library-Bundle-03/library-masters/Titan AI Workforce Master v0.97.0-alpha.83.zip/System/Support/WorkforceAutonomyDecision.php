<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/**
 * Validator/restrictor for Titan Autonomy Decision v2.
 *
 * Workforce never calculates earned authority. It validates the external
 * decision and may only narrow/deny it for local execution constraints.
 */
final class WorkforceAutonomyDecision
{
    private const BANDS = [
        'Manual' => [0.0, 15.0],
        'Assist' => [16.0, 30.0],
        'Semi-Autonomous' => [31.0, 50.0],
        'Autonomous' => [51.0, 85.0],
        'Predictive' => [86.0, 100.0],
    ];

    private const LEGACY_BAND_ALIASES = [
        'Suggest' => 'Manual',
        'Semi-Auto' => 'Semi-Autonomous',
        'Auto' => 'Autonomous',
        'Trusted Auto' => 'Predictive',
    ];

    private const KEY_FIELDS = [
        'company_id', 'agent_id', 'capability', 'capability_variant',
        'vertical', 'workflow', 'context',
    ];

    /** @return array<string,mixed> */
    public static function validate(array $decision, array $expectedKey): array
    {
        foreach ([
            'schema_version','decision_id','autonomy_key','desired_score','desired_band',
            'earned_score','earned_band','effective_score','effective_band',
            'predictive_readiness_score','predictive_readiness_band','allowed',
            'reason_codes','policy_version','evaluated_at',
        ] as $field) {
            if (! array_key_exists($field, $decision)) {
                throw new RuntimeException("Titan Autonomy decision missing {$field}.");
            }
        }

        if (($decision['schema_version'] ?? null) !== '2.0') {
            throw new RuntimeException('Titan Autonomy decision must use schema_version 2.0.');
        }
        if (! is_string($decision['decision_id']) || trim($decision['decision_id']) === '') {
            throw new RuntimeException('Titan Autonomy decision requires decision_id.');
        }
        if (! is_array($decision['autonomy_key'])) {
            throw new RuntimeException('Titan Autonomy decision requires autonomy_key.');
        }
        foreach (self::KEY_FIELDS as $field) {
            if (! array_key_exists($field, $decision['autonomy_key']) || ! array_key_exists($field, $expectedKey)) {
                throw new RuntimeException("Titan Autonomy key missing {$field}.");
            }
            if ((string) ($decision['autonomy_key'][$field] ?? '') !== (string) ($expectedKey[$field] ?? '')) {
                throw new RuntimeException("Titan Autonomy decision key mismatch for {$field}.");
            }
        }

        $desired = self::authorityPoint($decision, 'desired_score', 'desired_band');
        $earned = self::authorityPoint($decision, 'earned_score', 'earned_band');
        $effective = self::authorityPoint($decision, 'effective_score', 'effective_band');
        $predictive = self::authorityPoint($decision, 'predictive_readiness_score', 'predictive_readiness_band');

        if ($effective['score'] > $desired['score']) {
            throw new RuntimeException('Titan Autonomy effective authority exceeds desired authority.');
        }
        if ($effective['score'] > $earned['score']) {
            throw new RuntimeException('Titan Autonomy effective authority exceeds earned authority.');
        }
        if (! is_bool($decision['allowed'])) {
            throw new RuntimeException('Titan Autonomy decision allowed must be boolean.');
        }
        if (! is_array($decision['reason_codes']) || $decision['reason_codes'] === []) {
            throw new RuntimeException('Titan Autonomy decision requires at least one reason code.');
        }
        if (! is_string($decision['policy_version']) || trim($decision['policy_version']) === '') {
            throw new RuntimeException('Titan Autonomy decision requires policy_version.');
        }
        if (! is_string($decision['evaluated_at']) || strtotime($decision['evaluated_at']) === false) {
            throw new RuntimeException('Titan Autonomy decision requires a valid evaluated_at timestamp.');
        }
        if (isset($decision['lifecycle']) && ! in_array($decision['lifecycle'], ['ACTIVE','WATCH','DEGRADED','SUSPENDED','RE_EARNING'], true)) {
            throw new RuntimeException('Titan Autonomy decision contains invalid lifecycle.');
        }

        $decision['desired_score'] = $desired['score'];
        $decision['desired_band'] = $desired['band'];
        $decision['earned_score'] = $earned['score'];
        $decision['earned_band'] = $earned['band'];
        $decision['effective_score'] = $effective['score'];
        $decision['effective_band'] = $effective['band'];
        $decision['predictive_readiness_score'] = $predictive['score'];
        $decision['predictive_readiness_band'] = $predictive['band'];
        return $decision;
    }

    /**
     * Apply only restrictive Workforce-local execution policy.
     * Never increases external effective or predictive authority.
     *
     * @return array<string,mixed>
     */
    public static function applyLocalPolicy(
        array $decision,
        int $minimumScore,
        string $minimumBand,
        string $offlinePolicy,
        bool $offline,
        bool $predictiveRequired,
        ?int $offlineCapScore,
    ): array {
        $externalScore = (float) ($decision['effective_score'] ?? 0.0);
        $localScore = $externalScore;
        $constraints = [];
        $externalAllowed = ($decision['allowed'] ?? false) === true;

        if ($offline) {
            if (in_array($offlinePolicy, ['OFFLINE_BLOCKED','OFFLINE_PREPARE_ONLY','ONLINE_EXECUTE'], true)) {
                $constraints[] = 'OFFLINE_EXECUTION_BLOCKED';
            } elseif ($offlinePolicy === 'OFFLINE_EXECUTE' && $offlineCapScore !== null) {
                $cap = max(0, min(100, $offlineCapScore));
                if ($cap < $localScore) {
                    $localScore = (float) $cap;
                    $constraints[] = 'OFFLINE_AUTHORITY_CAP_APPLIED';
                }
            }
        }

        if ($localScore < $minimumScore) {
            $constraints[] = 'CAPABILITY_MINIMUM_AUTHORITY_NOT_MET';
        }

        $predictiveReady = (float) ($decision['predictive_readiness_score'] ?? 0.0) >= 86.0
            && ($decision['predictive_readiness_band'] ?? null) === 'Predictive';
        if ($predictiveRequired && ! $predictiveReady) {
            $constraints[] = 'PREDICTIVE_READINESS_NOT_MET';
        }

        if (($decision['lifecycle'] ?? 'ACTIVE') === 'SUSPENDED') {
            $constraints[] = 'AUTONOMY_LIFECYCLE_SUSPENDED';
        }

        $blockedOffline = $offline && in_array($offlinePolicy, ['OFFLINE_BLOCKED','OFFLINE_PREPARE_ONLY','ONLINE_EXECUTE'], true);
        $decision['external_allowed'] = $externalAllowed;
        $decision['allowed'] = $externalAllowed
            && ! $blockedOffline
            && $localScore >= $minimumScore
            && (! $predictiveRequired || $predictiveReady)
            && (($decision['lifecycle'] ?? 'ACTIVE') !== 'SUSPENDED');
        $decision['minimum_score'] = $minimumScore;
        $decision['minimum_band'] = $minimumBand;
        $decision['local_effective_score'] = $localScore;
        $decision['local_effective_band'] = self::bandForScore($localScore);
        $decision['predictive_required'] = $predictiveRequired;
        $decision['offline'] = $offline;
        $decision['offline_policy'] = $offlinePolicy;
        $decision['local_constraints'] = array_values(array_unique($constraints));
        $decision['authority_source'] = 'titan_autonomy';
        $decision['workforce_may_increase_authority'] = false;
        return $decision;
    }

    /** @return array<string,mixed> */
    public static function applyCommercialCeiling(array $decision, int $maximumScore, string $source): array
    {
        $maximumScore=max(0,min(100,$maximumScore));
        $local=(float)($decision['local_effective_score']??$decision['effective_score']??0.0);
        if ($local > $maximumScore) {
            $decision['local_effective_score']=(float)$maximumScore;
            $decision['local_effective_band']=self::bandForScore($maximumScore);
            $decision['local_constraints']=array_values(array_unique(array_merge((array)($decision['local_constraints']??[]),['COMMERCIAL_AUTONOMY_CEILING_APPLIED'])));
        }
        $decision['commercial_autonomy_ceiling_score']=$maximumScore;
        $decision['commercial_autonomy_ceiling_band']=self::bandForScore($maximumScore);
        $decision['commercial_autonomy_ceiling_source']=$source;
        $decision['commercial_entitlement_grants_authority']=false;
        if ((float)($decision['local_effective_score']??0.0) < (float)($decision['minimum_score']??0.0)) $decision['allowed']=false;
        return $decision;
    }

    public static function bandForScore(float|int $score): string
    {
        $score = max(0.0, min(100.0, (float) $score));
        foreach (self::BANDS as $band => [$min, $max]) {
            if ($score >= $min && $score <= $max) return $band;
        }
        return 'Manual';
    }

    /** @return array{score:float,band:string} */
    private static function authorityPoint(array $decision, string $scoreField, string $bandField): array
    {
        if (! is_int($decision[$scoreField] ?? null) && ! is_float($decision[$scoreField] ?? null)) {
            throw new RuntimeException("Titan Autonomy decision {$scoreField} must be numeric.");
        }
        $score = (float) $decision[$scoreField];
        $band = (string) ($decision[$bandField] ?? '');
        // Legacy labels are accepted only as input compatibility. Their numeric score is authoritative
        // and is re-banded into the canonical five-level model, preventing Trusted Auto from surviving
        // as a parallel runtime authority state.
        if (isset(self::LEGACY_BAND_ALIASES[$band])) {
            $band = self::bandForScore($score);
        }
        if ($score < 0 || $score > 100 || ! isset(self::BANDS[$band])) {
            throw new RuntimeException("Titan Autonomy decision {$scoreField}/{$bandField} is invalid.");
        }
        [$min, $max] = self::BANDS[$band];
        if ($score < $min || $score > $max) {
            throw new RuntimeException("Titan Autonomy decision {$scoreField}/{$bandField} mismatch.");
        }
        return ['score' => $score, 'band' => $band];
    }
}
