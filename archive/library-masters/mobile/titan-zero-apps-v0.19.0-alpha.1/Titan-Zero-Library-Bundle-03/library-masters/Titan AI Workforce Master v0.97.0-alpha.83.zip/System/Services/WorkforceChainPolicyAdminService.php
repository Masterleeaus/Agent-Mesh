<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainAdminOverride;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainPolicy;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceChainPolicyAdminService
{
    private const OVERRIDES=['HOLD','REQUIRE_MANUAL_REVIEW','INCREASE_SCRUTINY'];

    public function policy(int $companyId): WorkforceChainPolicy
    {
        return WorkforceChainPolicy::query()->firstOrCreate(
            ['company_id'=>$companyId],
            [
                'policy_uuid'=>(string)Str::uuid(),
                'revision'=>1,'enabled'=>true,'mandatory_three_checks'=>true,
                'minimum_reviewer_quality'=>0,'high_risk_reviewer_quality'=>80,
                'critical_risk_reviewer_quality'=>85,'require_provider_diversity_high_risk'=>true,
                'require_assurance_high_risk'=>true,'require_model_council_critical'=>true,
                'require_knowledge_authority'=>true,'require_explicit_evidence_high_risk'=>true,
                'require_manual_extreme_risk'=>true,'allow_learned_policy'=>true,
                'allow_predictive_tightening'=>true,'allow_admin_force_approve'=>false,
                'federation_paths'=>[],'recovery_policy'=>[
                    'unknown_strategy'=>'MANUAL_REPAIR',
                    'require_verified_receipt'=>true,
                    'allow_automatic_ungoverned_undo'=>false,
                ],
                'escalation_policy'=>[
                    'manager_required_high_risk'=>true,
                    'chief_required_critical'=>true,
                    'unresolved_disagreement_must_escalate'=>true,
                ],
                'policy_updated_at'=>now(),
            ]
        );
    }

    /** @param array<string,mixed> $input */
    public function updatePolicy(int $companyId,int $userId,array $input): WorkforceChainPolicy
    {
        return DB::transaction(function() use($companyId,$userId,$input){
            $policy=WorkforceChainPolicy::query()->forCompany($companyId)->lockForUpdate()->first()
                ?? $this->policy($companyId);

            $federationPaths=$this->normalizeFederationPaths((array)($input['federation_paths'] ?? $policy->federation_paths ?? []));
            $policy->forceFill([
                'revision'=>(int)$policy->revision+1,
                'enabled'=>(bool)($input['enabled'] ?? $policy->enabled),
                'mandatory_three_checks'=>true,
                'minimum_reviewer_quality'=>$this->clamp($input['minimum_reviewer_quality'] ?? $policy->minimum_reviewer_quality,0,100),
                'high_risk_reviewer_quality'=>$this->clamp($input['high_risk_reviewer_quality'] ?? $policy->high_risk_reviewer_quality,70,100),
                'critical_risk_reviewer_quality'=>$this->clamp($input['critical_risk_reviewer_quality'] ?? $policy->critical_risk_reviewer_quality,80,100),
                'require_provider_diversity_high_risk'=>(bool)($input['require_provider_diversity_high_risk'] ?? $policy->require_provider_diversity_high_risk),
                'require_assurance_high_risk'=>(bool)($input['require_assurance_high_risk'] ?? $policy->require_assurance_high_risk),
                'require_model_council_critical'=>(bool)($input['require_model_council_critical'] ?? $policy->require_model_council_critical),
                'require_knowledge_authority'=>true,
                'require_explicit_evidence_high_risk'=>(bool)($input['require_explicit_evidence_high_risk'] ?? $policy->require_explicit_evidence_high_risk),
                'require_manual_extreme_risk'=>(bool)($input['require_manual_extreme_risk'] ?? $policy->require_manual_extreme_risk),
                'allow_learned_policy'=>(bool)($input['allow_learned_policy'] ?? $policy->allow_learned_policy),
                'allow_predictive_tightening'=>true,
                'allow_admin_force_approve'=>false,
                'federation_paths'=>$federationPaths,
                'recovery_policy'=>[
                    'unknown_strategy'=>'MANUAL_REPAIR',
                    'require_verified_receipt'=>true,
                    'allow_automatic_ungoverned_undo'=>false,
                ],
                'escalation_policy'=>[
                    'manager_required_high_risk'=>true,
                    'chief_required_critical'=>true,
                    'unresolved_disagreement_must_escalate'=>true,
                ],
                'updated_by_user_id'=>$userId,
                'policy_updated_at'=>now(),
            ])->save();

            return $policy->refresh();
        },3);
    }

    /** @return array<string,mixed> */
    public function requirements(WorkforceDecisionChain $chain): array
    {
        $policy=$this->policy((int)$chain->company_id);
        $risk=strtoupper((string)$chain->risk_class);
        $high=in_array($risk,['HIGH','REGULATED','CRITICAL','SEVERE','EXTREME'],true);
        $critical=in_array($risk,['CRITICAL','SEVERE','EXTREME'],true);

        $floor=(int)$policy->minimum_reviewer_quality;
        if($high)$floor=max($floor,(int)$policy->high_risk_reviewer_quality);
        if($critical)$floor=max($floor,(int)$policy->critical_risk_reviewer_quality);

        $activeOverrides=WorkforceChainAdminOverride::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->where('status','ACTIVE')->get();

        $increase=$activeOverrides->where('override_type','INCREASE_SCRUTINY')->isNotEmpty();
        if($increase)$floor=max($floor,90);

        return [
            'admin_policy_revision'=>(int)$policy->revision,
            'mandatory_three_checks'=>true,
            'minimum_decision_quality'=>$floor,
            'prefer_provider_diversity'=>$increase || ($high && (bool)$policy->require_provider_diversity_high_risk),
            'force_assurance'=>$increase || ($high && (bool)$policy->require_assurance_high_risk),
            'force_model_council'=>($increase && $critical) || ($critical && (bool)$policy->require_model_council_critical),
            'require_knowledge_authority_receipt'=>true,
            'require_explicit_evidence_refs'=>$high && (bool)$policy->require_explicit_evidence_high_risk,
            'require_manual_review'=>$risk==='EXTREME' && (bool)$policy->require_manual_extreme_risk,
            'admin_hold'=>$activeOverrides->where('override_type','HOLD')->isNotEmpty(),
            'admin_require_manual_review'=>$activeOverrides->where('override_type','REQUIRE_MANUAL_REVIEW')->isNotEmpty(),
            'admin_increase_scrutiny'=>$activeOverrides->where('override_type','INCREASE_SCRUTINY')->isNotEmpty(),
            'admin_force_approve'=>false,
        ];
    }

    public function createOverride(
        WorkforceDecisionChain $chain,int $userId,string $type,string $reason,array $evidenceRefs=[]
    ): WorkforceChainAdminOverride {
        $type=strtoupper(trim($type));
        if(!in_array($type,self::OVERRIDES,true)) throw new RuntimeException('UNSAFE_OR_UNKNOWN_CHAIN_ADMIN_OVERRIDE');
        if(trim($reason)==='') throw new RuntimeException('CHAIN_ADMIN_OVERRIDE_REASON_REQUIRED');

        return WorkforceChainAdminOverride::query()->create([
            'override_uuid'=>(string)Str::uuid(),
            'company_id'=>(int)$chain->company_id,'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$chain->processing_id,'override_type'=>$type,'status'=>'ACTIVE',
            'reason'=>$reason,'evidence_refs'=>array_values($evidenceRefs),
            'effect'=>match($type){
                'HOLD'=>['may_progress'=>false,'may_approve'=>false],
                'REQUIRE_MANUAL_REVIEW'=>['manual_review_required'=>true,'may_auto_approve'=>false],
                default=>['increase_scrutiny'=>true,'reduce_scrutiny'=>false],
            },
            'created_by_user_id'=>$userId,'created_at_override'=>now(),
        ]);
    }

    public function releaseOverride(int $companyId,string $overrideUuid,int $userId): WorkforceChainAdminOverride
    {
        return DB::transaction(function() use($companyId,$overrideUuid,$userId){
            $override=WorkforceChainAdminOverride::query()->forCompany($companyId)
                ->where('override_uuid',$overrideUuid)->lockForUpdate()->firstOrFail();
            if($override->status==='RELEASED') return $override;
            $override->forceFill([
                'status'=>'RELEASED','released_by_user_id'=>$userId,'released_at'=>now(),
            ])->save();
            return $override->refresh();
        },3);
    }

    /** @return array<int,string> */
    public function federationPath(int $companyId,string $capability): array
    {
        $paths=(array)$this->policy($companyId)->federation_paths;
        $path=(array)($paths[$capability] ?? []);
        return array_values(array_filter(array_map(fn($v)=>strtolower(trim((string)$v)),$path)));
    }

    private function normalizeFederationPaths(array $paths): array
    {
        $out=[];
        foreach($paths as $capability=>$path){
            $capability=trim((string)$capability);
            if($capability==='' || !is_array($path)) continue;
            $domains=[];
            foreach($path as $domain){
                $d=strtolower(trim((string)$domain));
                if($d!=='' && ($domains===[] || end($domains)!==$d))$domains[]=$d;
            }
            if(count($domains)>=3)$out[$capability]=$domains;
        }
        return $out;
    }

    private function clamp(mixed $value,int $min,int $max): int
    {
        return max($min,min($max,(int)$value));
    }
}
