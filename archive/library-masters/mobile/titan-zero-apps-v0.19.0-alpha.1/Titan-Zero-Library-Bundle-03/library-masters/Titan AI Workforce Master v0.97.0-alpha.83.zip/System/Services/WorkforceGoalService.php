<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceGoalStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceGoalService
{
    public function create(int $companyId, array $data, ?WorkforceMember $owner = null): WorkforceGoal
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Goal requires company_id.');
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') throw new InvalidArgumentException('Goal requires a title.');
        $outcomeTarget = $data['outcome_target'] ?? null;
        $criteria = $data['success_criteria'] ?? null;
        if (! is_array($outcomeTarget) || $outcomeTarget === []) throw new InvalidArgumentException('Goal requires an explicit outcome target.');
        if (! is_array($criteria) || $criteria === []) throw new InvalidArgumentException('Goal requires measurable success criteria.');
        if ($owner && (int) $owner->company_id !== $companyId) throw new InvalidArgumentException('Goal owner belongs to another company.');

        return DB::transaction(function () use ($companyId, $data, $owner, $title, $outcomeTarget, $criteria): WorkforceGoal {
            $idempotency = trim((string) ($data['idempotency_key'] ?? ''));
            if ($idempotency !== '') {
                $existing = WorkforceGoal::query()->forCompany($companyId)->where('idempotency_key', $idempotency)->first();
                if ($existing) return $existing;
            }
            $trace = (string) ($data['trace_id'] ?? Str::uuid());
            return WorkforceGoal::query()->create([
                'goal_uuid' => $data['goal_uuid'] ?? (string) Str::uuid(),
                'company_id' => $companyId,
                'owner_member_id' => $owner?->id ?? $data['owner_member_id'] ?? null,
                'manager_member_id' => $data['manager_member_id'] ?? $owner?->manager_id,
                'origin_type' => $data['origin_type'] ?? 'manual',
                'origin_id' => $data['origin_id'] ?? null,
                'title' => $title,
                'description' => $data['description'] ?? null,
                'status' => $data['status'] ?? WorkforceGoalStatus::Proposed,
                'priority' => max(0, min(100, (int) ($data['priority'] ?? 50))),
                'outcome_target' => $outcomeTarget,
                'success_criteria' => $criteria,
                'context_refs' => is_array($data['context_refs'] ?? null) ? $data['context_refs'] : [],
                'target_at' => $data['target_at'] ?? null,
                'trace_id' => $trace,
                'correlation_id' => (string) ($data['correlation_id'] ?? $trace),
                'idempotency_key' => $idempotency !== '' ? $idempotency : null,
                'metadata' => is_array($data['metadata'] ?? null) ? $data['metadata'] : [],
            ]);
        });
    }

    public function activate(WorkforceGoal $goal): WorkforceGoal
    {
        if ($goal->status->terminal()) throw new InvalidArgumentException('Terminal goal cannot be activated.');
        $goal->forceFill(['status' => WorkforceGoalStatus::Active])->save();
        return $goal->refresh();
    }

    public function reconcile(WorkforceGoal $goal): WorkforceGoal
    {
        $items = $goal->workItems()->get();
        if ($items->isEmpty()) return $goal;

        $verified = $items->filter(fn ($item) => (string) $item->verification_state?->value === 'VERIFIED')->count();
        $failed = $items->filter(fn ($item) => in_array((string) $item->verification_state?->value, ['FAILED','REMEDIATION_REQUIRED'], true))->count();
        $total = $items->count();

        $status = $goal->status;
        $achievedAt = $goal->achieved_at;
        if ($verified === $total) {
            $status = WorkforceGoalStatus::Achieved;
            $achievedAt = now();
        } elseif ($failed > 0) {
            $status = WorkforceGoalStatus::AtRisk;
        } elseif ($status === WorkforceGoalStatus::Proposed) {
            $status = WorkforceGoalStatus::Active;
        }

        $goal->forceFill(['status' => $status, 'achieved_at' => $achievedAt])->save();
        return $goal->refresh();
    }
}
