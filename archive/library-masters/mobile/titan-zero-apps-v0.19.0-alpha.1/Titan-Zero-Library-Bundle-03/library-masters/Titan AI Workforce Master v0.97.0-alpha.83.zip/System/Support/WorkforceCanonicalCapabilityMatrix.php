<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/**
 * Workforce-owned canonical role -> provider capability composition.
 *
 * The matrix grants availability only. It never grants authority and every provider
 * remains fail-closed behind installation, Risk, Assurance, Governance, Autonomy and
 * Command Bus execution boundaries.
 */
final class WorkforceCanonicalCapabilityMatrix
{
    private const DEFAULT_MATRIX = __DIR__ . '/../../resources/workforce/canonical-capability-binding-matrix.json';

    /** @var array<string,mixed>|null */
    private ?array $matrix = null;

    public function __construct(private readonly ?string $matrixPath = null) {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->matrix !== null) return $this->matrix;
        $path = $this->matrixPath ?: self::DEFAULT_MATRIX;
        if (! is_file($path)) throw new RuntimeException("Titan Workforce canonical capability matrix missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true);
        if (! is_array($decoded)
            || ($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['roles'] ?? null)
            || count($decoded['roles']) !== 117
            || ($decoded['safety']['matrix_grants_execution_authority'] ?? null) !== false
            || ($decoded['safety']['authority_inherited'] ?? null) !== false) {
            throw new RuntimeException('Titan Workforce canonical capability matrix is invalid.');
        }
        return $this->matrix = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public function roles(): array
    {
        /** @var list<array<string,mixed>> $roles */
        $roles = array_values(array_filter($this->all()['roles'], 'is_array'));
        return $roles;
    }

    /** @return array<string,mixed>|null */
    public function role(string $roleDefinitionId): ?array
    {
        foreach ($this->roles() as $role) {
            if ((string) ($role['role_definition_id'] ?? '') === $roleDefinitionId) return $role;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public function bindingsForRole(string $roleDefinitionId): array
    {
        $role = $this->role($roleDefinitionId);
        if (! $role) return [];
        /** @var list<array<string,mixed>> $bindings */
        $bindings = array_values(array_filter((array) ($role['provider_bindings'] ?? []), 'is_array'));
        return $bindings;
    }

    /** @return list<string> */
    public function providerKeysForRole(string $roleDefinitionId): array
    {
        $keys = [];
        foreach ($this->bindingsForRole($roleDefinitionId) as $binding) {
            $key = trim((string) ($binding['provider'] ?? ''));
            if ($key !== '') $keys[$key] = true;
        }
        $out = array_keys($keys);
        sort($out);
        return $out;
    }

    /** @return list<string> */
    public function coordinationProvidersForRole(string $roleDefinitionId): array
    {
        $role = $this->role($roleDefinitionId);
        if (! $role) return [];
        $keys = array_values(array_unique(array_filter(array_map(
            static fn ($value): string => trim((string) $value),
            (array) ($role['coordination_providers'] ?? [])
        ), static fn (string $value): bool => $value !== '')));
        sort($keys);
        return $keys;
    }

    /** @return array<string,mixed> */
    public function summary(): array
    {
        return is_array($this->all()['summary'] ?? null) ? $this->all()['summary'] : [];
    }
}
