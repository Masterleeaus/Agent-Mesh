<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceWorkloadSnapshot extends Model
{
    protected $table = 'ext_titan_ai_workforce_workload_snapshots';
    protected $guarded = [];
    protected $casts = ['details'=>'array','observed_at'=>'datetime'];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
