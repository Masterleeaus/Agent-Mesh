<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceContextAccess;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceBusinessContextSourceCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use InvalidArgumentException;
use RuntimeException;

final class WorkforceBusinessContextGateway
{
    public function __construct(
        private readonly WorkforceBusinessContextSourceCatalog $catalog,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly WorkforceCapabilityBindingRegistry $bindings,
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly WorkforceBusinessContextProviderRegistry $providers,
        private readonly WorkforceProviderHealthObservabilityService $health,
    ) {}

    /** @return array<string,mixed> */
    public function plan(
        WorkforceMember $member,
        string $responsibilityId,
        string $purpose,
        array $policy = [],
    ): array {
        $purpose = trim($purpose);
        if ($purpose === '') throw new InvalidArgumentException('Business context access requires an explicit purpose.');
        $this->assertMemberIdentity($member);

        $requirement = $this->requirements->forResponsibility(trim($responsibilityId));
        if (! is_array($requirement)) throw new InvalidArgumentException('Unknown Workforce responsibility.');
        if ((string) ($requirement['role_definition_id'] ?? '') !== (string) $member->role_definition_id) {
            throw new InvalidArgumentException('Responsibility is not assigned to this Workforce role.');
        }

        $live = $this->availability->forMember($member, $policy);
        $sources = [];
        foreach ((array) ($requirement['candidate_data_sources'] ?? []) as $surfaceId) {
            $surfaceId = trim((string) $surfaceId);
            if ($surfaceId === '' || ! $this->catalog->allowedFor($surfaceId, (string) $member->role_definition_id, $responsibilityId)) continue;
            $source = $this->catalog->source($surfaceId);
            if (! is_array($source)) continue;
            if ($this->policyBlocksSensitivity($policy, (string) ($source['sensitivity'] ?? 'internal'))) continue;

            $routes = $this->liveReadRoutes($live, $surfaceId);
            $sources[] = [
                'surface_id' => $surfaceId,
                'domain' => (string) ($source['domain'] ?? 'operations'),
                'sensitivity' => (string) ($source['sensitivity'] ?? 'internal'),
                'routes' => $routes,
                'state' => $routes === [] ? WorkforceCapabilityState::Unavailable->value : WorkforceCapabilityState::Available->value,
                'purpose' => $purpose,
                'company_id' => (int) $member->company_id,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ];
        }

        return [
            'company_id' => (int) $member->company_id,
            'member_id' => (int) $member->id,
            'role_definition_id' => (string) $member->role_definition_id,
            'responsibility_id' => $responsibilityId,
            'purpose' => $purpose,
            'sources' => $sources,
            'read_only' => true,
            'role_identity_immutable' => true,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function read(
        WorkforceMember $member,
        string $responsibilityId,
        string $surfaceId,
        string $purpose,
        array $filters = [],
        int $limit = 50,
        ?string $requestedProvider = null,
        array $policy = [],
    ): array {
        $limit = max(1, min($limit, 200));
        $plan = $this->plan($member, $responsibilityId, $purpose, $policy);
        $sourcePlan = null;
        foreach ($plan['sources'] as $candidate) {
            if ((string) ($candidate['surface_id'] ?? '') === $surfaceId) {
                $sourcePlan = $candidate;
                break;
            }
        }
        if (! is_array($sourcePlan)) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, null, null, 'denied', 'SURFACE_NOT_ALLOWED_FOR_RESPONSIBILITY');
            throw new InvalidArgumentException('Requested business context surface is not allowed for this responsibility.');
        }

        $routes = (array) ($sourcePlan['routes'] ?? []);
        $route = $this->selectRoute($routes, $requestedProvider, $policy);
        if (! is_array($route)) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, null, null, 'blocked', 'NO_DETERMINISTIC_LIVE_PROVIDER');
            throw new RuntimeException('No deterministic live provider is available for this business context surface.');
        }

        $providerKey = (string) $route['provider'];
        $providerVersion = (string) $route['provider_version'];
        $provider = $this->providers->resolve($providerKey);
        if (! $provider || ! $provider->supports($surfaceId)) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, $providerKey, $providerVersion, 'blocked', 'CONTEXT_PROVIDER_ADAPTER_UNAVAILABLE');
            $this->healthFailure($member, $providerKey, $surfaceId, 'CONTEXT_PROVIDER_ADAPTER_UNAVAILABLE', 'Context provider adapter is unavailable for the selected provider.');
            throw new RuntimeException('Context provider adapter is unavailable for the selected provider.');
        }
        if ($provider->providerVersion() !== $providerVersion) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, $providerKey, $providerVersion, 'blocked', 'CONTEXT_PROVIDER_VERSION_MISMATCH');
            $this->healthFailure($member, $providerKey, $surfaceId, 'CONTEXT_PROVIDER_VERSION_MISMATCH', 'Context provider version does not match the pinned live provider version.');
            throw new RuntimeException('Context provider version does not match the pinned live provider version.');
        }

        $filters['company_id'] = (int) $member->company_id;
        try {
            $result = $provider->read((int) $member->company_id, $surfaceId, $filters, $limit);
        } catch (\Throwable $e) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, $providerKey, $providerVersion, 'blocked', 'CONTEXT_PROVIDER_READ_FAILED');
            $this->healthFailure($member, $providerKey, $surfaceId, 'CONTEXT_PROVIDER_READ_FAILED', mb_substr($e->getMessage(), 0, 1000));
            throw $e;
        }
        if (! is_array($result)
            || (int) ($result['company_id'] ?? 0) !== (int) $member->company_id
            || (string) ($result['surface_id'] ?? '') !== $surfaceId
            || ! is_array($result['items'] ?? null)) {
            $this->audit($member, $responsibilityId, $surfaceId, $purpose, $providerKey, $providerVersion, 'blocked', 'INVALID_CONTEXT_PROVIDER_ENVELOPE');
            $this->healthFailure($member, $providerKey, $surfaceId, 'INVALID_CONTEXT_PROVIDER_ENVELOPE', 'Context provider returned an invalid or cross-company envelope.');
            throw new RuntimeException('Context provider returned an invalid or cross-company envelope.');
        }

        $result['provider'] = $providerKey;
        $result['provider_version'] = $providerVersion;
        $result['purpose'] = $purpose;
        $result['responsibility_id'] = $responsibilityId;
        $result['member_id'] = (int) $member->id;
        $result['read_only'] = true;
        $result['authority_inherited'] = false;
        $result['execution_authority_granted'] = false;
        $this->audit($member, $responsibilityId, $surfaceId, $purpose, $providerKey, $providerVersion, 'allowed', null, count($result['items']));
        $this->healthSuccess($member, $providerKey, $surfaceId, count($result['items']));
        return $result;
    }

    private function healthSuccess(WorkforceMember $member, string $provider, string $surfaceId, int $itemCount): void
    {
        try {
            $this->health->recordSuccess((int) $member->company_id, $provider, 'data_source', $surfaceId, [
                'item_count' => $itemCount,
                'source' => 'business_context_gateway',
            ]);
        } catch (\Throwable) {
            // Observability storage never broadens or changes context access semantics.
        }
    }

    private function healthFailure(WorkforceMember $member, string $provider, string $surfaceId, string $reason, string $message): void
    {
        try {
            $this->health->recordFailure(
                (int) $member->company_id,
                $provider,
                WorkforceCapabilityState::Degraded->value,
                $reason,
                $message,
                'data_source',
                $surfaceId,
                ['source' => 'business_context_gateway'],
            );
        } catch (\Throwable) {
            // The context failure itself remains authoritative even when health persistence is unavailable.
        }
    }

    /** @return list<array<string,mixed>> */
    private function liveReadRoutes(array $live, string $surfaceId): array
    {
        $routes = [];
        foreach ((array) ($live['provider_bindings'] ?? []) as $binding) {
            $provider = $this->ecosystem->canonicalProviderKey((string) ($binding['provider'] ?? ''));
            if ($provider === '') continue;
            foreach ((array) (($binding['surfaces']['data_sources'] ?? [])) as $surface) {
                if (! is_array($surface)
                    || (string) ($surface['id'] ?? '') !== $surfaceId
                    || (string) ($surface['state'] ?? '') !== WorkforceCapabilityState::Available->value) continue;
                $routes[$provider] = [
                    'provider' => $provider,
                    'provider_version' => (string) ($binding['provider_version'] ?? ''),
                    'provider_class' => (string) ($binding['provider_class'] ?? ''),
                    'surface_id' => $surfaceId,
                ];
            }
        }
        ksort($routes);
        return array_values($routes);
    }

    private function selectRoute(array $routes, ?string $requestedProvider, array $policy): ?array
    {
        if ($requestedProvider !== null && trim($requestedProvider) !== '') {
            $requested = $this->ecosystem->canonicalProviderKey($requestedProvider);
            $matches = array_values(array_filter($routes, static fn (array $route): bool =>
                (string) ($route['provider'] ?? '') === $requested
            ));
            return count($matches) === 1 ? $matches[0] : null;
        }
        if (count($routes) === 1) return $routes[0];

        $preferred = [];
        foreach ((array) ($policy['preferred_providers'] ?? []) as $provider) {
            $provider = $this->ecosystem->canonicalProviderKey((string) $provider);
            if ($provider !== '' && ! in_array($provider, $preferred, true)) $preferred[] = $provider;
        }
        foreach ($preferred as $provider) {
            $matches = array_values(array_filter($routes, static fn (array $route): bool =>
                (string) ($route['provider'] ?? '') === $provider
            ));
            if (count($matches) === 1) return $matches[0];
        }
        return null;
    }

    private function assertMemberIdentity(WorkforceMember $member): void
    {
        if ((int) $member->company_id <= 0) throw new InvalidArgumentException('Workforce member requires company_id.');
        if (trim((string) $member->role_definition_id) === '') throw new InvalidArgumentException('Workforce member requires a canonical role definition.');
    }

    private function policyBlocksSensitivity(array $policy, string $sensitivity): bool
    {
        $blocked = array_map('strval', (array) ($policy['blocked_context_sensitivity'] ?? []));
        return in_array($sensitivity, $blocked, true);
    }

    private function audit(
        WorkforceMember $member,
        string $responsibilityId,
        string $surfaceId,
        string $purpose,
        ?string $provider,
        ?string $providerVersion,
        string $decision,
        ?string $reason,
        int $itemCount = 0,
    ): void {
        WorkforceContextAccess::query()->create([
            'company_id' => (int) $member->company_id,
            'member_id' => (int) $member->id,
            'role_definition_id' => (string) $member->role_definition_id,
            'responsibility_id' => $responsibilityId,
            'surface_id' => $surfaceId,
            'purpose' => $purpose,
            'provider' => $provider,
            'provider_version' => $providerVersion,
            'decision' => $decision,
            'reason' => $reason,
            'item_count' => $itemCount,
            'accessed_at' => now(),
        ]);
    }
}
