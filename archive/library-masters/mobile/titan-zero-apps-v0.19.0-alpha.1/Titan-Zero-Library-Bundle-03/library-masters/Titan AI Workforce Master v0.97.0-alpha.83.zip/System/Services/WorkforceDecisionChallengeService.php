<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceProcessingCheckpointState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceDecisionChallengeService
{
    public function __construct(
        private readonly WorkforceProcessingLifecycleService $lifecycle,
        private readonly WorkforceManagerEscalationService $managerEscalation,
        private readonly WorkforceAssuranceCouncilEscalationService $assuranceCouncil,
        private readonly WorkforceReviewerPerformanceFeedbackService $reviewerFeedback,
    ) {}

    /** @param array<string,mixed> $challenge */
    public function open(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $challengerCheckpoint,
        WorkforceMember $challenger,
        array $challenge
    ): WorkforceDecisionChallenge {
        if ((int)$challengerCheckpoint->stage <= 1) {
            throw new RuntimeException('CHALLENGE_REQUIRES_PRIOR_STAGE');
        }
        if ((int)$challengerCheckpoint->owner_member_id !== (int)$challenger->getKey()) {
            throw new RuntimeException('CHALLENGE_REQUIRES_STAGE_OWNER');
        }

        $prior=WorkforceProcessingCheckpoint::query()
            ->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where('stage',(int)$challengerCheckpoint->stage-1)
            ->firstOrFail();

        if ($prior->status !== WorkforceProcessingCheckpointState::Passed) {
            throw new RuntimeException('CHALLENGED_STAGE_MUST_HAVE_PASSED');
        }

        $reason=trim((string)($challenge['reason'] ?? ''));
        $claims=array_values((array)($challenge['disputed_claims'] ?? []));
        $evidence=array_values((array)($challenge['evidence_challenges'] ?? []));
        $authority=array_values((array)($challenge['authority_challenges'] ?? []));
        if ($reason==='' || ($claims===[] && $evidence===[] && $authority===[])) {
            throw new RuntimeException('MATERIAL_CHALLENGE_REQUIRES_REASON_AND_DISPUTE');
        }

        $challengerConfidence=$this->confidence($challenge['confidence'] ?? null);
        $challengedConfidence=$this->confidence(data_get($prior->decision ?? [],'knowledge_confidence',data_get($prior->decision ?? [],'confidence')));
        $delta=($challengerConfidence!==null && $challengedConfidence!==null)
            ? round(abs($challengerConfidence-$challengedConfidence),2) : null;

        return DB::transaction(function () use (
            $chain,$challengerCheckpoint,$challenger,$prior,$challenge,$reason,$claims,$evidence,$authority,
            $challengerConfidence,$challengedConfidence,$delta
        ): WorkforceDecisionChallenge {
            $existing=WorkforceDecisionChallenge::query()
                ->forCompany((int)$chain->company_id)
                ->where('processing_id',$chain->processing_id)
                ->where('challenger_stage',(int)$challengerCheckpoint->stage)
                ->lockForUpdate()->first();
            if ($existing) return $existing;

            $record=WorkforceDecisionChallenge::query()->create([
                'challenge_uuid'=>(string)Str::uuid(),
                'company_id'=>(int)$chain->company_id,
                'decision_chain_id'=>$chain->getKey(),
                'processing_id'=>$chain->processing_id,
                'challenger_stage'=>(int)$challengerCheckpoint->stage,
                'challenged_stage'=>(int)$prior->stage,
                'challenger_member_id'=>$challenger->getKey(),
                'challenged_member_id'=>$prior->reviewer_member_id,
                'status'=>'OPEN',
                'challenge_type'=>(string)($challenge['challenge_type'] ?? 'MATERIAL_DISAGREEMENT'),
                'challenger_confidence'=>$challengerConfidence,
                'challenged_confidence'=>$challengedConfidence,
                'confidence_delta'=>$delta,
                'disputed_claims'=>$claims,
                'evidence_challenges'=>$evidence,
                'authority_challenges'=>$authority,
                'requested_information'=>array_values((array)($challenge['requested_information'] ?? [])),
                'reason'=>$reason,
                'rebuttal_count'=>0,
                'max_rebuttals'=>1,
                'opened_at'=>now(),
            ]);

            $this->lifecycle->transition(
                $challengerCheckpoint,
                WorkforceProcessingCheckpointState::Disagreed,
                $challenger,
                $reason,
                ['challenge_uuid'=>$record->challenge_uuid,'confidence_delta'=>$delta]
            );

            $this->event($record,'CHALLENGE_OPENED',$challenger,[
                'challenged_stage'=>$prior->stage,
                'challenged_member_id'=>$prior->reviewer_member_id,
                'challenged_decision'=>$prior->decision ?? [],
                'challenged_packet'=>data_get($prior->decision ?? [],'action_review_packet'),
                'challenger_packet'=>data_get($challengerCheckpoint->metadata ?? [],'action_review_packet_sha256'),
                'disputed_claims'=>$claims,
                'evidence_challenges'=>$evidence,
                'authority_challenges'=>$authority,
                'confidence_delta'=>$delta,
            ]);
            return $record;
        },3);
    }

    /** @param array<string,mixed> $rebuttal */
    public function rebut(WorkforceDecisionChallenge $challenge, WorkforceMember $respondent, array $rebuttal): WorkforceDecisionChallenge
    {
        return DB::transaction(function () use ($challenge,$respondent,$rebuttal): WorkforceDecisionChallenge {
            $locked=WorkforceDecisionChallenge::query()->forCompany((int)$challenge->company_id)
                ->whereKey($challenge->getKey())->lockForUpdate()->firstOrFail();
            if ($locked->status !== 'OPEN') throw new RuntimeException('CHALLENGE_NOT_OPEN_FOR_REBUTTAL');
            if ((int)$locked->challenged_member_id !== (int)$respondent->getKey()) {
                throw new RuntimeException('ONLY_CHALLENGED_REVIEWER_MAY_REBUT');
            }
            if ((int)$locked->rebuttal_count >= (int)$locked->max_rebuttals) {
                throw new RuntimeException('CHALLENGE_REBUTTAL_LIMIT_REACHED');
            }

            $reason=trim((string)($rebuttal['reason'] ?? ''));
            if ($reason==='') throw new RuntimeException('REBUTTAL_REASON_REQUIRED');

            $payload=[
                'member_id'=>$respondent->getKey(),
                'reason'=>$reason,
                'claim_responses'=>array_values((array)($rebuttal['claim_responses'] ?? [])),
                'evidence'=>array_values((array)($rebuttal['evidence'] ?? [])),
                'authority_sources'=>array_values((array)($rebuttal['authority_sources'] ?? [])),
                'confidence'=>$this->confidence($rebuttal['confidence'] ?? null),
                'submitted_at'=>now()->toISOString(),
            ];

            $locked->forceFill([
                'status'=>'REBUTTED',
                'rebuttal_count'=>(int)$locked->rebuttal_count+1,
                'rebuttal'=>$payload,
                'rebutted_at'=>now(),
            ])->save();
            $this->event($locked,'CHALLENGE_REBUTTED',$respondent,$payload);
            return $locked->refresh();
        },3);
    }

    /** @param array<string,mixed> $resolution */
    public function resolve(
        WorkforceDecisionChallenge $challenge,
        WorkforceMember $challenger,
        bool $acceptRebuttal,
        array $resolution = []
    ): WorkforceDecisionChallenge {
        return DB::transaction(function () use ($challenge,$challenger,$acceptRebuttal,$resolution): WorkforceDecisionChallenge {
            $locked=WorkforceDecisionChallenge::query()->forCompany((int)$challenge->company_id)
                ->whereKey($challenge->getKey())->lockForUpdate()->firstOrFail();
            if ((int)$locked->challenger_member_id !== (int)$challenger->getKey()) {
                throw new RuntimeException('ONLY_CHALLENGER_MAY_RESOLVE_REBUTTAL');
            }
            if ($locked->status !== 'REBUTTED') {
                throw new RuntimeException('CHALLENGE_REQUIRES_REBUTTAL_BEFORE_RESOLUTION');
            }

            $checkpoint=WorkforceProcessingCheckpoint::query()->forCompany((int)$locked->company_id)
                ->where('processing_id',$locked->processing_id)
                ->where('stage',$locked->challenger_stage)->firstOrFail();

            if ($acceptRebuttal) {
                $payload=array_merge($resolution,[
                    'outcome'=>'REBUTTAL_ACCEPTED',
                    'resolved_by_member_id'=>$challenger->getKey(),
                    'resolved_at'=>now()->toISOString(),
                ]);
                $locked->forceFill(['status'=>'RESOLVED','resolution'=>$payload,'resolved_at'=>now()])->save();
                $this->lifecycle->retry($checkpoint,$challenger,'challenge-rebuttal-accepted');
                $this->event($locked,'CHALLENGE_RESOLVED',$challenger,$payload);
                $this->reviewerFeedback->recordChallengeResolution($locked->refresh());
                return $locked->refresh();
            }

            $payload=array_merge($resolution,[
                'outcome'=>'MATERIAL_DISAGREEMENT_REMAINS',
                'resolved_by_member_id'=>$challenger->getKey(),
                'resolved_at'=>now()->toISOString(),
            ]);
            $locked->forceFill([
                'status'=>'ESCALATED',
                'resolution'=>$payload,
                'resolved_at'=>now(),
                'escalated_at'=>now(),
            ])->save();
            $this->lifecycle->transition(
                $checkpoint,
                WorkforceProcessingCheckpointState::Escalated,
                $challenger,
                'material-disagreement-remains-after-rebuttal',
                ['challenge_uuid'=>$locked->challenge_uuid,'resolution'=>$payload]
            );
            $chain=WorkforceDecisionChain::query()->forCompany((int)$locked->company_id)
                ->whereKey($locked->decision_chain_id)->firstOrFail();
            $escalation=$this->managerEscalation->resolve(
                $chain,$checkpoint,$challenger,'UNRESOLVED_MATERIAL_DISAGREEMENT',
                [
                    'challenge_uuid'=>$locked->challenge_uuid,
                    'business_value'=>data_get($chain->task?->payload ?? [],'amount',0),
                    'urgency_score'=>(int)($chain->task?->priority ?? 50),
                    'disagreement_count'=>WorkforceDecisionChallenge::query()->forCompany((int)$locked->company_id)
                        ->where('processing_id',$locked->processing_id)->count(),
                    'resolution'=>$payload,
                ]
            );
            $review=$this->assuranceCouncil->review(
                $chain,$checkpoint,$escalation,
                [
                    'business_value'=>$escalation->business_value,
                    'urgency_score'=>$escalation->urgency_score,
                    'disagreement_count'=>$escalation->disagreement_count,
                    'challenge_uuid'=>$locked->challenge_uuid,
                ]
            );
            $payload['manager_escalation_uuid']=$escalation->escalation_uuid;
            $payload['assigned_to_member_id']=$escalation->assigned_to_member_id;
            $payload['assurance_council_review_uuid']=$review->review_uuid;
            $payload['assurance_status']=$review->assurance_status;
            $payload['model_council_required']=$review->model_council_required;
            $payload['council_status']=$review->council_status;
            $payload['assurance_council_final_status']=$review->final_status;
            $locked->forceFill(['resolution'=>$payload])->save();
            $this->event($locked,'CHALLENGE_ESCALATED',$challenger,$payload);
            $this->reviewerFeedback->recordChallengeResolution($locked->refresh());
            return $locked->refresh();
        },3);
    }

    public function escalateWithoutRebuttal(WorkforceDecisionChallenge $challenge, WorkforceMember $challenger, string $reason): WorkforceDecisionChallenge
    {
        return DB::transaction(function () use ($challenge,$challenger,$reason): WorkforceDecisionChallenge {
            $locked=WorkforceDecisionChallenge::query()->forCompany((int)$challenge->company_id)
                ->whereKey($challenge->getKey())->lockForUpdate()->firstOrFail();
            if ((int)$locked->challenger_member_id !== (int)$challenger->getKey()) throw new RuntimeException('ONLY_CHALLENGER_MAY_ESCALATE');
            if (!in_array($locked->status,['OPEN','REBUTTED'],true)) throw new RuntimeException('CHALLENGE_NOT_ESCALATABLE');

            $checkpoint=WorkforceProcessingCheckpoint::query()->forCompany((int)$locked->company_id)
                ->where('processing_id',$locked->processing_id)->where('stage',$locked->challenger_stage)->firstOrFail();

            $locked->forceFill([
                'status'=>'ESCALATED',
                'resolution'=>['outcome'=>'ESCALATED_WITHOUT_RESOLUTION','reason'=>$reason],
                'escalated_at'=>now(),
            ])->save();
            if ($checkpoint->status !== WorkforceProcessingCheckpointState::Escalated) {
                $this->lifecycle->transition($checkpoint,WorkforceProcessingCheckpointState::Escalated,$challenger,$reason,[
                    'challenge_uuid'=>$locked->challenge_uuid,
                ]);
            }
            $chain=WorkforceDecisionChain::query()->forCompany((int)$locked->company_id)
                ->whereKey($locked->decision_chain_id)->firstOrFail();
            $escalation=$this->managerEscalation->resolve(
                $chain,$checkpoint,$challenger,'CHALLENGE_ESCALATED_WITHOUT_RESOLUTION',
                [
                    'challenge_uuid'=>$locked->challenge_uuid,
                    'business_value'=>data_get($chain->task?->payload ?? [],'amount',0),
                    'urgency_score'=>(int)($chain->task?->priority ?? 50),
                    'disagreement_count'=>WorkforceDecisionChallenge::query()->forCompany((int)$locked->company_id)
                        ->where('processing_id',$locked->processing_id)->count(),
                    'reason'=>$reason,
                ]
            );
            $review=$this->assuranceCouncil->review(
                $chain,$checkpoint,$escalation,
                [
                    'business_value'=>$escalation->business_value,
                    'urgency_score'=>$escalation->urgency_score,
                    'disagreement_count'=>$escalation->disagreement_count,
                    'challenge_uuid'=>$locked->challenge_uuid,
                ]
            );
            $locked->forceFill(['resolution'=>array_merge((array)$locked->resolution,[
                'manager_escalation_uuid'=>$escalation->escalation_uuid,
                'assigned_to_member_id'=>$escalation->assigned_to_member_id,
                'assurance_council_review_uuid'=>$review->review_uuid,
                'assurance_status'=>$review->assurance_status,
                'model_council_required'=>$review->model_council_required,
                'council_status'=>$review->council_status,
                'assurance_council_final_status'=>$review->final_status,
            ])])->save();
            $this->event($locked,'CHALLENGE_ESCALATED',$challenger,[
                'reason'=>$reason,
                'manager_escalation_uuid'=>$escalation->escalation_uuid,
                'assigned_to_member_id'=>$escalation->assigned_to_member_id,
            ]);
            return $locked->refresh();
        },3);
    }

    private function confidence(mixed $value): ?float
    {
        if ($value===null || $value==='') return null;
        return max(0.0,min(100.0,(float)$value));
    }

    /** @param array<string,mixed> $evidence */
    private function event(WorkforceDecisionChallenge $challenge,string $type,?WorkforceMember $actor,array $evidence): void
    {
        DB::table('ext_titan_ai_workforce_decision_chain_events')->insert([
            'company_id'=>$challenge->company_id,
            'decision_chain_id'=>$challenge->decision_chain_id,
            'processing_id'=>$challenge->processing_id,
            'stage'=>$challenge->challenger_stage,
            'event_type'=>$type,
            'actor_member_id'=>$actor?->getKey(),
            'from_state'=>null,
            'to_state'=>$challenge->status,
            'evidence'=>json_encode(array_merge(['challenge_uuid'=>$challenge->challenge_uuid],$evidence),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'occurred_at'=>now(),'created_at'=>now(),'updated_at'=>now(),
        ]);
    }
}
