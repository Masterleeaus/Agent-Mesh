<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services;

use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilitySimilarityScorerContract;

/**
 * Deterministic local semantic scorer used before neural/browser embeddings are available.
 *
 * It combines semantic synonym expansion with weighted title, alias, action, entity,
 * identifier and search-document similarity. Pass 9 may replace or supplement this
 * scorer with WebGPU/native embeddings through the same contract.
 */
final class ZeroDeterministicCapabilitySimilarityScorer implements ZeroCapabilitySimilarityScorerContract
{
    /** @var list<list<string>> */
    private const SEMANTIC_GROUPS = [
        ['quote', 'estimate', 'quotation', 'pricing', 'price'],
        ['available', 'availability', 'free', 'open', 'vacant'],
        ['schedule', 'scheduled', 'scheduling', 'book', 'booking', 'reserve', 'appointment', 'reschedule'],
        ['customer', 'client'],
        ['worker', 'staff', 'crew', 'employee', 'team', 'technician', 'someone'],
        ['invoice', 'bill'],
        ['payment', 'pay', 'paid', 'settlement'],
        ['create', 'add', 'make', 'new', 'prepare'],
        ['read', 'view', 'show', 'get', 'find', 'search', 'lookup', 'check'],
        ['send', 'message', 'notify', 'contact', 'communicate'],
        ['job', 'work', 'workorder', 'work_order', 'booking'],
        ['change', 'update', 'edit', 'modify', 'revise'],
        ['cancel', 'void', 'withdraw', 'remove', 'delete'],
    ];

    /** @var array<string,bool> */
    private const STOP_WORDS = [
        'a' => true, 'an' => true, 'and' => true, 'are' => true, 'as' => true, 'at' => true,
        'be' => true, 'by' => true, 'do' => true, 'for' => true, 'from' => true, 'her' => true,
        'him' => true, 'his' => true, 'i' => true, 'in' => true, 'is' => true, 'it' => true,
        'me' => true, 'my' => true, 'of' => true, 'on' => true, 'our' => true, 'please' => true,
        'that' => true, 'the' => true, 'their' => true, 'them' => true, 'this' => true, 'to' => true,
        'us' => true, 'we' => true, 'with' => true, 'would' => true, 'mrs' => true, 'mr' => true,
        'ms' => true, 'next' => true,
    ];

    public function score(string $query, array $capability, array $context = []): array
    {
        $normalizedQuery = $this->normalize($query);
        if ($normalizedQuery === '') {
            return ['score' => 0.0, 'normalized_query' => '', 'matched_signals' => []];
        }

        $queryTokens = $this->expandTokens($this->tokens($normalizedQuery));
        if ($queryTokens === []) {
            return ['score' => 0.0, 'normalized_query' => $normalizedQuery, 'matched_signals' => []];
        }

        $title = $this->normalize((string) ($capability['title'] ?? ''));
        $id = $this->normalize((string) ($capability['id'] ?? ''));
        $search = $this->normalize((string) ($capability['search_document'] ?? ''));
        $aliases = $this->normalizeList((array) ($capability['aliases'] ?? []));
        $actions = $this->normalizeList((array) ($capability['action_verbs'] ?? []));
        $entities = $this->normalizeList((array) ($capability['business_entities'] ?? []));

        $titleScore = $this->fieldCoverage($queryTokens, $this->tokens($title));
        $aliasScore = 0.0;
        foreach ($aliases as $alias) {
            $aliasScore = max($aliasScore, $this->fieldCoverage($queryTokens, $this->tokens($alias)));
        }
        $actionScore = $this->fieldCoverage($queryTokens, $this->tokens(implode(' ', $actions)));
        $entityScore = $this->fieldCoverage($queryTokens, $this->tokens(implode(' ', $entities)));
        $idScore = $this->fieldCoverage($queryTokens, $this->tokens($id));
        $searchScore = $this->cosine($queryTokens, $this->expandTokens($this->tokens($search)));

        $phraseBoost = 0.0;
        $signals = [];
        if ($title !== '' && (str_contains($normalizedQuery, $title) || str_contains($title, $normalizedQuery))) {
            $phraseBoost = 0.15;
            $signals[] = 'title_phrase';
        }
        foreach ($aliases as $alias) {
            if ($alias !== '' && (str_contains($normalizedQuery, $alias) || str_contains($alias, $normalizedQuery))) {
                $phraseBoost = max($phraseBoost, 0.15);
                $signals[] = 'alias_phrase';
                break;
            }
        }

        if ($titleScore > 0.0) $signals[] = 'title_tokens';
        if ($aliasScore > 0.0) $signals[] = 'alias_tokens';
        if ($actionScore > 0.0) $signals[] = 'action_tokens';
        if ($entityScore > 0.0) $signals[] = 'entity_tokens';
        if ($idScore > 0.0) $signals[] = 'identifier_tokens';
        if ($searchScore > 0.0) $signals[] = 'search_document';

        $score = ($titleScore * 0.30)
            + ($aliasScore * 0.25)
            + ($actionScore * 0.20)
            + ($entityScore * 0.10)
            + ($searchScore * 0.10)
            + ($idScore * 0.05)
            + $phraseBoost;

        return [
            'score' => round(min(1.0, max(0.0, $score)), 6),
            'normalized_query' => $normalizedQuery,
            'matched_signals' => array_values(array_unique($signals)),
        ];
    }

    private function normalize(string $value): string
    {
        $value = strtolower(trim($value));
        $value = str_replace(['_', '-', '.', '/', '\\'], ' ', $value);
        $value = preg_replace('/[^a-z0-9\s]+/u', ' ', $value) ?? $value;
        $value = preg_replace('/\s+/', ' ', $value) ?? $value;
        return trim($value);
    }

    /** @return list<string> */
    private function tokens(string $value): array
    {
        $normalized = $this->normalize($value);
        if ($normalized === '') return [];
        $parts = preg_split('/\s+/', $normalized) ?: [];
        $out = [];
        foreach ($parts as $part) {
            if ($part === '' || isset(self::STOP_WORDS[$part])) continue;
            $out[$part] = true;
        }
        return array_keys($out);
    }

    /** @param list<string> $tokens @return list<string> */
    private function expandTokens(array $tokens): array
    {
        $expanded = array_fill_keys($tokens, true);
        foreach (self::SEMANTIC_GROUPS as $group) {
            $matched = false;
            foreach ($group as $term) {
                $normalizedTerm = $this->normalize($term);
                if ($normalizedTerm !== '' && isset($expanded[$normalizedTerm])) {
                    $matched = true;
                    break;
                }
            }
            if (! $matched) continue;
            foreach ($group as $term) {
                foreach ($this->tokens($term) as $token) $expanded[$token] = true;
            }
        }
        $out = array_keys($expanded);
        sort($out);
        return $out;
    }

    /** @param list<string> $queryTokens @param list<string> $fieldTokens */
    private function fieldCoverage(array $queryTokens, array $fieldTokens): float
    {
        if ($queryTokens === [] || $fieldTokens === []) return 0.0;
        $querySet = array_fill_keys($queryTokens, true);
        $fieldTokens = array_values(array_unique($fieldTokens));
        $matched = 0;
        foreach ($fieldTokens as $token) if (isset($querySet[$token])) $matched++;
        return $matched / count($fieldTokens);
    }

    /** @param list<string> $left @param list<string> $right */
    private function cosine(array $left, array $right): float
    {
        if ($left === [] || $right === []) return 0.0;
        $a = array_count_values($left);
        $b = array_count_values($right);
        $dot = 0.0;
        foreach ($a as $token => $count) $dot += $count * ($b[$token] ?? 0);
        if ($dot <= 0.0) return 0.0;
        $normA = sqrt(array_sum(array_map(static fn (int $v): int => $v * $v, $a)));
        $normB = sqrt(array_sum(array_map(static fn (int $v): int => $v * $v, $b)));
        if ($normA <= 0.0 || $normB <= 0.0) return 0.0;
        return $dot / ($normA * $normB);
    }

    /** @param array<mixed> $values @return list<string> */
    private function normalizeList(array $values): array
    {
        $out = [];
        foreach ($values as $value) {
            $normalized = $this->normalize((string) $value);
            if ($normalized !== '') $out[] = $normalized;
        }
        return array_values(array_unique($out));
    }
}
