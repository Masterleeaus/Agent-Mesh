<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts;

/**
 * Narrow read port used by Zero's business-context gateway.
 *
 * Implementations must preserve company_id internally and may never expose a
 * write path through this contract.
 */
interface ZeroBusinessContextReaderContract
{
    public function supports(string $providerKey, string $providerVersion, string $surfaceId): bool;

    /** @return array<string,mixed> */
    public function read(
        int $companyId,
        string $providerKey,
        string $providerVersion,
        string $surfaceId,
        array $filters = [],
        int $limit = 50,
    ): array;
}
