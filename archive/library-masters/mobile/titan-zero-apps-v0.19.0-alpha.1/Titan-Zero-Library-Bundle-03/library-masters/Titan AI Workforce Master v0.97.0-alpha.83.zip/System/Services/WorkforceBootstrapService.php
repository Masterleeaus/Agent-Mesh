<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicDivisionCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicTeamCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;

final class WorkforceBootstrapService
{
    public function __construct(
        private readonly WorkforceManifestRegistry $manifests,
        private readonly TitanZeroChiefOfStaffService $titanZero,
        private readonly ExecutiveLayerService $executiveLayer,
        private readonly WorkforceGraphService $graph,
        private readonly IntrinsicDivisionCatalog $intrinsicDivisions,
        private readonly IntrinsicTeamCatalog $intrinsicTeams,
    ) {}

    /**
     * Materialise the canonical organisation containers for a company.
     *
     * Workforce owns intrinsic divisions and teams. Extension manifests may add
     * compatibility containers, but they cannot redefine an intrinsic container.
     * This method intentionally creates NO WorkforceMember rows.
     *
     * @return array<string,WorkforceDivision>
     */
    public function ensureDivisions(int $companyId): array
    {
        $this->titanZero->ensureForCompany($companyId);
        $out = [];

        foreach ($this->intrinsicDivisions->all() as $definition) {
            $key = (string) $definition['key'];
            $out[$key] = WorkforceDivision::query()->updateOrCreate(
                ['company_id' => $companyId, 'key' => $key],
                [
                    'division_definition_id' => (string) $definition['division_definition_id'],
                    'name' => (string) $definition['name'],
                    'purpose' => (string) $definition['purpose'],
                    'is_active' => true,
                    'metadata' => [
                        'definition_source' => 'intrinsic_workforce_catalogue',
                        'manager_role_definition_id' => (string) $definition['manager_role_definition_id'],
                        'authority_inherited' => false,
                    ],
                ]
            );
        }

        // Compatibility window: extension-owned divisions may add non-colliding
        // containers, but intrinsic Workforce definitions always win collisions.
        foreach ($this->manifests->divisions() as $key => $definition) {
            if (isset($out[$key])) continue;
            $out[$key] = WorkforceDivision::query()->firstOrCreate(
                ['company_id' => $companyId, 'key' => $key],
                [
                    'name' => (string) ($definition['name'] ?? $key),
                    'purpose' => (string) ($definition['purpose'] ?? ''),
                    'is_active' => true,
                    'metadata' => ['definition_source' => 'extension_workforce_manifest', 'owner_extensions' => $definition['owner_extensions'] ?? []],
                ]
            );
        }

        $teams = [];
        foreach ($this->intrinsicTeams->all() as $definition) {
            $divisionKey = (string) $definition['division_key'];
            $division = $out[$divisionKey] ?? null;
            if (! $division) continue;
            $teamKey = (string) $definition['key'];
            $compound = $divisionKey . ':' . $teamKey;
            $teams[$compound] = WorkforceTeam::query()->updateOrCreate(
                ['company_id' => $companyId, 'key' => $teamKey],
                [
                    'division_id' => $division->id,
                    'team_definition_id' => (string) $definition['team_definition_id'],
                    'name' => (string) $definition['name'],
                    'purpose' => (string) $definition['purpose'],
                    'is_active' => true,
                    'metadata' => [
                        'definition_source' => 'intrinsic_workforce_catalogue',
                        'boundaries' => $definition['boundaries'] ?? [],
                        'authority_inherited' => false,
                    ],
                ]
            );
        }

        // Preserve non-colliding extension-contributed teams during the Manifest 2.0
        // compatibility window. They are containers only; no employee is auto-hired.
        foreach ($this->manifests->roles() as $role) {
            $divisionKey = (string) ($role['division'] ?? '');
            $division = $out[$divisionKey] ?? null;
            if (! $division) continue;
            $teamKey = trim((string) ($role['team'] ?? ''));
            if ($teamKey === '') continue;
            $compound = $divisionKey . ':' . $teamKey;
            if (isset($teams[$compound])) continue;
            $teams[$compound] = WorkforceTeam::query()->firstOrCreate(
                ['company_id' => $companyId, 'key' => $teamKey],
                [
                    'division_id' => $division->id,
                    'name' => ucwords(str_replace(['-', '_'], ' ', $teamKey)),
                    'purpose' => '',
                    'is_active' => true,
                    'metadata' => ['definition_source' => 'extension_workforce_manifest'],
                ]
            );
        }

        $this->executiveLayer->synchroniseForCompany($companyId);
        $this->graph->synchroniseIntrinsicRelationships($companyId);
        return $out;
    }
}
