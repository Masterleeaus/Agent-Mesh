<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberLifecycleState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceDefinitionChangeClassifier;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use Illuminate\Support\Str;

/**
 * Reconciles legacy extension-owned staff definitions during capability-binding migration.
 * Intrinsic Workforce-owned roles are not suspended when a capability provider changes;
 * provider availability is separate from employee identity.
 */
final class WorkforceManifestLifecycleService
{
    public const DEPRECATION_WINDOW_DAYS = 30;

    public function __construct(
        private readonly WorkforceManifestRegistry $registry,
        private readonly WorkforceSignalBridge $signals,
        private readonly ProactiveResponsibilityService $proactiveResponsibilities,
    ) {}

    /** @return array<string,mixed> */
    public function pinFieldsForRole(?array $definition): array
    {
        if (! $definition) return [];
        $snapshot = $this->snapshot($definition);
        return [
            'role_definition_id' => (string) ($definition['role_id'] ?? ''),
            'role_owner_extension' => (string) ($definition['owner_extension'] ?? ''),
            'role_owner_extension_version' => (string) ($definition['owner_extension_version'] ?? ''),
            'role_definition_version' => (string) ($definition['definition_version'] ?? $definition['owner_extension_version'] ?? ''),
            'role_definition_fingerprint' => (string) ($definition['definition_fingerprint'] ?? $this->fingerprint($snapshot)),
            'role_definition_state' => 'ACTIVE',
            'role_definition_snapshot' => $snapshot,
            'role_definition_deprecated_at' => null,
            'role_definition_grace_until' => null,
        ];
    }

    /** @return array<string,mixed> */
    public function pinRoleDefinition(?WorkforceMember $member): array
    {
        if (! $member || ! $member->role_definition_id) return [];
        $snapshot = is_array($member->role_definition_snapshot) ? $member->role_definition_snapshot : $this->snapshotFromMember($member);
        return [
            'role_definition_id' => (string) $member->role_definition_id,
            'role_owner_extension' => $member->role_owner_extension,
            'role_owner_extension_version' => $member->role_owner_extension_version,
            'role_definition_version' => $member->role_definition_version,
            'role_definition_fingerprint' => $member->role_definition_fingerprint ?: $this->fingerprint($snapshot),
            'role_definition_state' => $member->role_definition_state ?: 'ACTIVE',
            'role_definition_snapshot' => $snapshot,
            'role_definition_deprecated_at' => $member->role_definition_deprecated_at,
            'role_definition_grace_until' => $member->role_definition_grace_until,
        ];
    }

    public function rePinTask(WorkforceTask $task, WorkforceMember $member): WorkforceTask
    {
        $task->forceFill($this->pinRoleDefinition($member))->save();
        return $task->refresh();
    }

    public function onActivated(mixed $event = null): void
    {
        if ($key = $this->extensionKey($event)) {
            $this->registry->restoreExtension($key);
            $this->reconcileExtension($key, 'activated');
            $this->proactiveResponsibilities->syncOwner($key);
        }
    }

    public function onUpgraded(mixed $event = null): void
    {
        if ($key = $this->extensionKey($event)) {
            $this->registry->restoreExtension($key);
            $this->reconcileExtension($key, 'upgraded');
            $this->proactiveResponsibilities->syncOwner($key);
        }
    }

    public function onDisabled(mixed $event = null): void
    {
        if ($key = $this->extensionKey($event)) {
            $this->registry->suppressExtension($key);
            $this->proactiveResponsibilities->disableOwner($key, 'extension_disabled');
            $this->markOwnerUnavailable($key, 'disabled');
        }
    }

    public function onUninstalled(mixed $event = null): void
    {
        if ($key = $this->extensionKey($event)) {
            $this->registry->suppressExtension($key);
            $this->proactiveResponsibilities->disableOwner($key, 'extension_uninstalled');
            $this->markOwnerUnavailable($key, 'uninstalled');
        }
    }

    /** @return array{checked:int,active:int,compatible:int,breaking:int,missing:int} */
    public function reconcileExtension(string $extensionKey, string $reason = 'reconcile'): array
    {
        $extensionKey = trim($extensionKey);
        $stats = ['checked' => 0, 'active' => 0, 'compatible' => 0, 'breaking' => 0, 'missing' => 0];
        if ($extensionKey === '' || $extensionKey === 'titan-ai-workforce') return $stats;

        WorkforceMember::query()
            ->where('role_owner_extension', $extensionKey)
            ->where('is_permanent_system_role', false)
            ->orderBy('id')
            ->chunkById(100, function ($members) use ($extensionKey, $reason, &$stats): void {
                foreach ($members as $member) {
                    $stats['checked']++;
                    $definition = $member->role_definition_id
                        ? $this->registry->findOwnedRole($extensionKey, (string) $member->role_definition_id)
                        : null;
                    if (! $definition) {
                        $this->applyMissing($member, $reason);
                        $stats['missing']++;
                        continue;
                    }
                    $pinned = is_array($member->role_definition_snapshot)
                        ? $member->role_definition_snapshot
                        : $this->snapshotFromMember($member);
                    $available = $this->snapshot($definition);
                    $comparison = WorkforceDefinitionChangeClassifier::compare($pinned, $available);
                    if ($comparison['classification'] === 'IDENTICAL') {
                        $this->applyActive($member, $definition, $reason);
                        $stats['active']++;
                    } elseif ($comparison['classification'] === 'COMPATIBLE') {
                        $this->applyCompatible($member, $definition, $comparison['reasons'], $reason);
                        $stats['compatible']++;
                    } else {
                        $this->applyBreaking($member, $definition, $comparison['reasons'], $reason);
                        $stats['breaking']++;
                    }
                }
            });
        return $stats;
    }

    /** @return array<string,array{checked:int,active:int,compatible:int,breaking:int,missing:int}> */
    public function reconcileAll(): array
    {
        $owners = WorkforceMember::query()->staffingSeats()->whereNotNull('role_owner_extension')->where('role_owner_extension', '!=', 'titan-ai-workforce')->distinct()->pluck('role_owner_extension')->filter()->map('strval')->all();
        foreach (array_keys($this->registry->all()) as $owner) if (! in_array($owner, $owners, true)) $owners[] = $owner;
        $out = [];
        foreach ($owners as $owner) $out[$owner] = $this->reconcileExtension($owner);
        return $out;
    }

    private function markOwnerUnavailable(string $extensionKey, string $reason): void
    {
        WorkforceMember::query()
            ->where('role_owner_extension', $extensionKey)
            ->where('is_permanent_system_role', false)
            ->orderBy('id')
            ->chunkById(100, function ($members) use ($reason): void {
                foreach ($members as $member) $this->applyMissing($member, $reason);
            });
    }

    private function applyMissing(WorkforceMember $member, string $reason): void
    {
        $meta = is_array($member->metadata) ? $member->metadata : [];
        if (! ($meta['definition_lifecycle_suspended'] ?? false)) {
            $meta['definition_lifecycle_previous_status'] = $member->status?->value ?? (string) $member->status;
            $meta['definition_lifecycle_previous_is_active'] = (bool) $member->is_active;
        }
        $meta['definition_lifecycle_suspended'] = true;
        $meta['definition_lifecycle_reason'] = $reason;
        $member->forceFill([
            'role_definition_state' => 'MISSING',
            'status' => WorkforceMemberStatus::Offline,
            'is_active' => false,
            'metadata' => $meta,
        ])->save();
        $this->emitMemberState($member, 'workforce.definition.missing', $reason);
    }

    private function applyBreaking(WorkforceMember $member, array $definition, array $reasons, string $reason): void
    {
        $meta = is_array($member->metadata) ? $member->metadata : [];
        if (! ($meta['definition_lifecycle_suspended'] ?? false)) {
            $meta['definition_lifecycle_previous_status'] = $member->status?->value ?? (string) $member->status;
            $meta['definition_lifecycle_previous_is_active'] = (bool) $member->is_active;
        }
        $meta['definition_lifecycle_suspended'] = true;
        $meta['definition_lifecycle_reason'] = $reason;
        $meta['definition_breaking_reasons'] = array_values($reasons);
        $meta['definition_available_version'] = (string) ($definition['definition_version'] ?? $definition['owner_extension_version'] ?? '');
        $meta['definition_available_fingerprint'] = (string) ($definition['definition_fingerprint'] ?? '');
        $member->forceFill([
            'role_definition_state' => 'BREAKING',
            'status' => WorkforceMemberStatus::Offline,
            'is_active' => false,
            'role_definition_deprecated_at' => now(),
            'role_definition_grace_until' => now()->addDays(self::DEPRECATION_WINDOW_DAYS),
            'metadata' => $meta,
        ])->save();
        $this->emitMemberState($member, 'workforce.definition.breaking', implode(',', $reasons));
    }

    private function applyCompatible(WorkforceMember $member, array $definition, array $reasons, string $reason): void
    {
        $meta = is_array($member->metadata) ? $member->metadata : [];
        $meta['definition_update_available'] = true;
        $meta['definition_lifecycle_reason'] = $reason;
        $meta['definition_compatibility_reasons'] = array_values($reasons);
        $meta['definition_available_version'] = (string) ($definition['definition_version'] ?? $definition['owner_extension_version'] ?? '');
        $meta['definition_available_fingerprint'] = (string) ($definition['definition_fingerprint'] ?? '');
        [$status, $active, $meta] = $this->restoreLifecycleSuspension($member, $meta);
        $member->forceFill([
            'role_definition_state' => 'COMPATIBLE',
            'status' => $status,
            'is_active' => $active,
            'role_definition_deprecated_at' => $member->role_definition_deprecated_at ?: now(),
            'role_definition_grace_until' => $member->role_definition_grace_until ?: now()->addDays(self::DEPRECATION_WINDOW_DAYS),
            'metadata' => $meta,
        ])->save();
        $this->emitMemberState($member, 'workforce.definition.compatible-update', $reason);
    }

    private function applyActive(WorkforceMember $member, array $definition, string $reason): void
    {
        $meta = is_array($member->metadata) ? $member->metadata : [];
        unset($meta['definition_update_available'], $meta['definition_breaking_reasons'], $meta['definition_compatibility_reasons'], $meta['definition_available_version'], $meta['definition_available_fingerprint']);
        $meta['definition_lifecycle_reason'] = $reason;
        [$status, $active, $meta] = $this->restoreLifecycleSuspension($member, $meta);
        $member->forceFill([
            'role_definition_state' => 'ACTIVE',
            'status' => $status,
            'is_active' => $active,
            'role_definition_deprecated_at' => null,
            'role_definition_grace_until' => null,
            'metadata' => $meta,
        ])->save();
        $this->emitMemberState($member, 'workforce.definition.active', $reason);
    }

    /** @return array{0:mixed,1:bool,2:array} */
    private function restoreLifecycleSuspension(WorkforceMember $member, array $meta): array
    {
        $status = $member->status;
        $active = (bool) $member->is_active;
        if ($meta['definition_lifecycle_suspended'] ?? false) {
            $memberLifecycle = $member->lifecycle_state instanceof WorkforceMemberLifecycleState
                ? $member->lifecycle_state
                : WorkforceMemberLifecycleState::tryFrom((string) $member->lifecycle_state);
            if ($memberLifecycle === WorkforceMemberLifecycleState::Retired) {
                $status = WorkforceMemberStatus::Offline;
                $active = false;
            } elseif ($memberLifecycle === WorkforceMemberLifecycleState::Suspended) {
                $status = WorkforceMemberStatus::Suspended;
                $active = false;
            } else {
                $previous = (string) ($meta['definition_lifecycle_previous_status'] ?? WorkforceMemberStatus::Available->value);
                $status = WorkforceMemberStatus::tryFrom($previous) ?? WorkforceMemberStatus::Available;
                $active = (bool) ($meta['definition_lifecycle_previous_is_active'] ?? true);
            }
            unset($meta['definition_lifecycle_suspended'], $meta['definition_lifecycle_previous_status'], $meta['definition_lifecycle_previous_is_active']);
        }
        return [$status, $active, $meta];
    }

    private function emitMemberState(WorkforceMember $member, string $eventType, string $reason): void
    {
        $trace = (string) Str::uuid();
        $this->signals->emit((int) $member->company_id, $eventType, [
            'member_id' => $member->id,
            'role_definition_id' => $member->role_definition_id,
            'role_owner_extension' => $member->role_owner_extension,
            'role_definition_state' => $member->role_definition_state,
            'reason' => $reason,
        ], $trace, $trace, null);
    }

    /** @return array<string,mixed> */
    private function snapshot(array $definition): array
    {
        return [
            'role_id' => (string) ($definition['role_id'] ?? ''),
            'owner_extension' => (string) ($definition['owner_extension'] ?? ''),
            'owner_extension_version' => (string) ($definition['owner_extension_version'] ?? ''),
            'definition_version' => (string) ($definition['definition_version'] ?? $definition['owner_extension_version'] ?? ''),
            'tier' => (int) ($definition['tier'] ?? 0),
            'division' => (string) ($definition['division'] ?? ''),
            'team' => (string) ($definition['team'] ?? ''),
            'capabilities' => array_values(array_map('strval', $definition['capabilities'] ?? [])),
            'tool_access' => array_values(array_map('strval', $definition['tool_access'] ?? [])),
            'workflow_refs' => array_values(array_map('strval', $definition['workflow_refs'] ?? [])),
            'risk_ceiling' => (string) ($definition['risk_ceiling'] ?? 'LOW'),
            'autonomy_profile' => $definition['autonomy_profile'] ?? [],
        ];
    }

    /** @return array<string,mixed> */
    private function snapshotFromMember(WorkforceMember $member): array
    {
        return [
            'role_id' => (string) ($member->role_definition_id ?? ''),
            'owner_extension' => (string) ($member->role_owner_extension ?? data_get($member->metadata ?? [], 'owner_extension', '')),
            'owner_extension_version' => (string) ($member->role_owner_extension_version ?? data_get($member->metadata ?? [], 'owner_extension_version', '')),
            'definition_version' => (string) ($member->role_definition_version ?? ''),
            'tier' => (int) ($member->tier?->value ?? $member->tier ?? 0),
            'division' => (string) ($member->division?->key ?? ''),
            'team' => (string) ($member->team?->key ?? ''),
            'capabilities' => is_array($member->capabilities) ? $member->capabilities : [],
            'tool_access' => (array) data_get($member->metadata ?? [], 'tool_access', []),
            'workflow_refs' => (array) data_get($member->metadata ?? [], 'workflow_refs', []),
            'risk_ceiling' => (string) ($member->risk_ceiling ?? 'LOW'),
            'autonomy_profile' => ['starting_score' => data_get($member->autonomy_references ?? [], 'initial_score')],
        ];
    }

    private function fingerprint(array $snapshot): string
    {
        return hash('sha256', json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private function extensionKey(mixed $event): ?string
    {
        if (is_string($event)) return trim($event) !== '' ? trim($event) : null;
        if (is_array($event)) {
            foreach (['extension_key','key','slug','extension'] as $field) {
                $value = $event[$field] ?? null;
                if (is_string($value) && trim($value) !== '') return trim($value);
                if (is_array($value) && is_string($value['key'] ?? null)) return trim((string) $value['key']);
            }
        }
        if (is_object($event)) {
            foreach (['extensionKey','key','slug'] as $property) {
                if (isset($event->{$property}) && is_string($event->{$property}) && trim($event->{$property}) !== '') return trim($event->{$property});
            }
        }
        return null;
    }
}
