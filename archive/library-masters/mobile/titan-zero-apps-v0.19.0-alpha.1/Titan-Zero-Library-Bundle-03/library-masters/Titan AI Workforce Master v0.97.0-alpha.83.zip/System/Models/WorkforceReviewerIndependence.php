<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceReviewerIndependence extends Model
{
    protected $table = 'ext_titan_ai_workforce_reviewer_independence';
    protected $guarded = [];
    protected $casts = [
        'member_independent'=>'boolean',
        'runtime_independent'=>'boolean',
        'provider_model_independent'=>'boolean',
        'organisationally_independent'=>'boolean',
        'eligible'=>'boolean',
        'conflicts'=>'array',
        'evidence'=>'array',
        'assessed_at'=>'datetime',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id',$companyId);
    }
}
