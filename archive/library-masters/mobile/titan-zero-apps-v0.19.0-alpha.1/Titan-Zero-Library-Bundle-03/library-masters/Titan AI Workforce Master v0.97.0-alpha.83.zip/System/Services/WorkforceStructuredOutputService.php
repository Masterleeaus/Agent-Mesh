<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

/**
 * Normalises untrusted AI/runtime output into the stable Workforce -> Titan Apps
 * presentation contract. The result is advisory only: it cannot grant authority,
 * execute capabilities, select raw UI code, or redefine the company boundary.
 */
final class WorkforceStructuredOutputService
{
    public const SCHEMA = 'titan.workforce.structured-output/1';

    /**
     * @param array<string,mixed> $runtimeOutput
     * @return array<string,mixed>
     */
    public function normalize(WorkforceTask $task, WorkforceMember $member, array $runtimeOutput): array
    {
        $companyId = (int) $task->company_id;
        if ($companyId <= 0) {
            throw new InvalidArgumentException('Structured Workforce output requires canonical company_id.');
        }
        if ((int) $member->company_id !== $companyId) {
            throw new InvalidArgumentException('Structured Workforce output company boundary mismatch.');
        }

        $modelCompanyId = isset($runtimeOutput['company_id']) ? (int) $runtimeOutput['company_id'] : null;
        $companyConflictIgnored = $modelCompanyId !== null && $modelCompanyId > 0 && $modelCompanyId !== $companyId;

        // Legacy tenant identifiers are never emitted as authority fields. They are
        // model/runtime compatibility inputs only and cannot compete with company_id.
        unset($runtimeOutput['tenant_id'], $runtimeOutput['tenant_company_id'], $runtimeOutput['tenantId']);
        $runtimeOutput['company_id'] = $companyId;

        $presentationPurpose = $member->tier === WorkforceTier::Manager ? 'workforce_plan_review' : 'workforce_proposal_review';
        $journey = $this->stringOrNull($runtimeOutput['journey'] ?? null);
        $metadataConfidence = is_array($runtimeOutput['metadata'] ?? null) ? ($runtimeOutput['metadata']['confidence'] ?? null) : null;
        $confidence = $this->confidence($runtimeOutput['confidence'] ?? $metadataConfidence);
        $evidence = $this->evidence($runtimeOutput, (array) ($task->evidence ?? []));
        $components = $this->recommendedComponents($runtimeOutput, $member);
        $actions = $this->recommendedActions($runtimeOutput);
        $presentationData = $this->presentationData($runtimeOutput);

        $envelope = [
            'schema' => self::SCHEMA,
            'company_id' => $companyId,
            'presentation_intent' => [
                'surface' => 'zero',
                'journey' => $journey,
                'purpose' => $presentationPurpose,
                'mode' => 'semantic_components',
                'executable_ui' => false,
                'component_registry_required' => true,
                'contribution_schema' => 'titan.apps.interface-contribution/1',
                'composition_owner' => 'titan_apps_interface_runtime',
                'editing_owner' => 'titan_apps_builder',
                'provider_ui_ownership' => false,
            ],
            'capability_result' => [
                'capability' => $this->stringOrNull($task->capability),
                'status' => $member->tier === WorkforceTier::Manager ? 'plan_proposed' : 'proposal_submitted',
                'data' => $presentationData,
                'projection_candidate' => true,
                'authoritative_business_execution' => false,
            ],
            'recommended_components' => $components,
            'recommended_actions' => $actions,
            'confidence' => $confidence,
            'evidence' => $evidence,
            'safety' => [
                'execution_authority_granted' => false,
                'self_authorization_allowed' => false,
                'arbitrary_executable_ui_allowed' => false,
                'command_bus_recheck_required' => true,
                'interface_runtime_composition_required' => true,
                'builder_is_editing_authority' => true,
                'company_boundary' => 'company_id',
                'projection_required' => true,
                'raw_provider_fields_allowed' => false,
                'model_company_override_ignored' => $companyConflictIgnored,
            ],
        ];

        // Compatibility: retain established manager_plan/workforce_plan/proposal
        // fields while making the canonical structured contract available at root.
        return array_merge($runtimeOutput, $envelope);
    }


    /** @param array<string,mixed> $output @return array<string,mixed> */
    private function presentationData(array $output): array
    {
        $safe = [];
        foreach (['summary','workforce_plan','proposal','missing_information','recommended_next_state','handoff','status','result'] as $field) {
            if (array_key_exists($field, $output)) {
                $safe[$field] = $output[$field];
            }
        }
        return $safe;
    }

    /** @param array<string,mixed> $output @return list<string> */
    private function recommendedComponents(array $output, WorkforceMember $member): array
    {
        $raw = $output['recommended_components'] ?? $output['components'] ?? [];
        $ids = [];
        foreach ((array) $raw as $component) {
            if (is_array($component)) {
                $component = $component['id'] ?? $component['component_id'] ?? null;
            }
            if (! is_string($component)) continue;
            $component = trim($component);
            if ($component !== '' && preg_match('/^[a-z0-9][a-z0-9._-]{1,127}$/', $component)) {
                $ids[] = $component;
            }
        }
        if ($ids === []) {
            $ids[] = $member->tier === WorkforceTier::Manager ? 'workforce.plan.review' : 'workforce.proposal.review';
        }
        return array_values(array_unique($ids));
    }

    /** @param array<string,mixed> $output @return list<array<string,mixed>> */
    private function recommendedActions(array $output): array
    {
        $raw = $output['recommended_actions'] ?? $output['actions'] ?? [];
        if ($raw === [] && isset($output['runtime_tool_proposals']) && is_array($output['runtime_tool_proposals'])) {
            $raw = $output['runtime_tool_proposals'];
        }
        $actions = [];
        foreach ((array) $raw as $index => $action) {
            if (is_string($action)) {
                $action = ['label' => $action];
            }
            if (! is_array($action)) continue;
            $capability = $this->stringOrNull($action['capability'] ?? $action['tool'] ?? null);
            $label = $this->stringOrNull($action['label'] ?? $action['title'] ?? $action['name'] ?? null)
                ?? ($capability !== null ? 'Review '.$capability : 'Review recommendation');
            $actions[] = [
                'action_id' => $this->stringOrNull($action['action_id'] ?? $action['id'] ?? null) ?? 'recommendation-'.($index + 1),
                'label' => $label,
                'capability' => $capability,
                'parameters' => is_array($action['parameters'] ?? null) ? $action['parameters'] : [],
                'execution_authority_granted' => false,
                'requires_governed_execution' => true,
            ];
        }
        return $actions;
    }

    /** @param array<string,mixed> $output @param array<int|string,mixed> $taskEvidence @return array<string,mixed> */
    private function evidence(array $output, array $taskEvidence): array
    {
        $refs = [];
        foreach ([$output['evidence_refs'] ?? [], $output['evidence'] ?? [], $taskEvidence] as $source) {
            foreach ((array) $source as $entry) {
                if (is_string($entry) || is_int($entry)) {
                    $value = trim((string) $entry);
                    if ($value !== '') $refs[] = $value;
                    continue;
                }
                if (! is_array($entry)) continue;
                foreach (['ref','evidence_ref','id','uri'] as $key) {
                    if (isset($entry[$key]) && is_scalar($entry[$key])) {
                        $value = trim((string) $entry[$key]);
                        if ($value !== '') $refs[] = $value;
                        break;
                    }
                }
            }
        }
        return [
            'refs' => array_values(array_unique($refs)),
            'model_supplied' => isset($output['evidence']) || isset($output['evidence_refs']),
            'verified' => false,
            'verification_required_for_consequential_execution' => true,
        ];
    }

    private function confidence(mixed $value): ?float
    {
        if (! is_numeric($value)) return null;
        return max(0.0, min(1.0, (float) $value));
    }

    private function stringOrNull(mixed $value): ?string
    {
        if (! is_scalar($value)) return null;
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
