<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoalPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforcePeoplePayrollCycle;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

final class WorkforcePeoplePayrollOperationsService
{
    private const PATH = __DIR__.'/../../resources/workforce/people-payroll-operations-workflows.json';

    public function __construct(
        private readonly WorkforceBusinessGoalPlanningService $planning,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforceProviderRoutingService $routing,
    ) {}

    /** @return array<string,mixed> */
    public function readiness(
        WorkforceMember $coordinator,
        string $workflowKey,
        array $assigneeMap,
        array $policy = [],
    ): array {
        $workflow=$this->workflow($workflowKey);
        $issues=[];$warnings=[];$routes=[];$resolved=[];
        foreach($workflow['steps'] as $step){
            $key=(string)$step['key'];
            $memberId=(int)($assigneeMap[$key] ?? 0);
            $member=$memberId>0?WorkforceMember::query()->forCompany((int)$coordinator->company_id)->find($memberId):null;
            if(!$member || !$member->is_active){$issues[]="{$key}: active assignee required.";continue;}
            if((string)$member->role_definition_id!==(string)$step['role_definition_id']){$issues[]="{$key}: assignee role mismatch.";continue;}
            $responsibility=$this->responsibilityFor((string)$step['role_definition_id'],(string)$step['capability']);
            if(!$responsibility){$issues[]="{$key}: no canonical responsibility owns capability.";continue;}
            try{
                $route=$this->routing->assertExecutableRoute($member,(string)$step['capability'],'capability',(string)$step['responsibility_provider']);
                $routes[$key]=[
                    'provider'=>(string)($route['selected_provider']??''),
                    'provider_version'=>(string)($route['selected_provider_version']??''),
                    'responsibility_id'=>$responsibility,
                ];
                $resolved[$key]=(int)$member->id;
            }catch(\Throwable $e){$issues[]="{$key}: ".$e->getMessage();}
        }

        if($workflowKey==='time-to-payroll'){
            $submit=(int)($assigneeMap['payroll-submit']??0);
            $approve=(int)($assigneeMap['payroll-approve']??0);
            if($submit>0 && $approve>0 && $submit===$approve){
                if((bool)($policy['require_payroll_dual_control']??false)) $issues[]='Payroll submitter and approver must be different under dual-control policy.';
                else $warnings[]='Payroll submitter and approver are the same member; dual control is recommended.';
            }
        }

        return [
            'valid'=>$issues===[],
            'workflow_key'=>$workflowKey,
            'issue_count'=>count($issues),
            'warning_count'=>count($warnings),
            'issues'=>$issues,
            'warnings'=>$warnings,
            'routes'=>$routes,
            'assignees'=>$resolved,
            'company_id'=>(int)$coordinator->company_id,
            'provider_domain_ownership_preserved'=>true,
            'workflow_grants_authority'=>false,
        ];
    }

    public function prepare(
        WorkforceMember $coordinator,
        string $workflowKey,
        array $assigneeMap,
        array $contextRefs = [],
        ?string $periodKey = null,
        ?string $subjectType = null,
        ?string $subjectId = null,
        array $policy = [],
    ): WorkforcePeoplePayrollCycle {
        $readiness=$this->readiness($coordinator,$workflowKey,$assigneeMap,$policy);
        if(!$readiness['valid']) throw new InvalidArgumentException('People/Payroll operations workflow is not ready.');

        $workflow=$this->workflow($workflowKey);
        $items=[];
        foreach($workflow['steps'] as $index=>$step){
            $key=(string)$step['key'];
            $route=$readiness['routes'][$key];
            $items[]=[
                'key'=>$key,
                'title'=>(string)$step['title'],
                'assignee_member_id'=>(int)$readiness['assignees'][$key],
                'responsibility_id'=>(string)$route['responsibility_id'],
                'capability'=>(string)$step['capability'],
                'provider'=>(string)$route['provider'],
                'expected_outcome'=>(array)$step['expected_outcome'],
                'evidence_requirements'=>(array)$step['evidence_requirements'],
                'sequence_index'=>$index+1,
                'orchestration_group'=>$workflowKey,
                'estimated_minutes'=>(int)($step['estimated_minutes']??15),
            ];
        }

        $objective=(array)$workflow['objective_template'];
        $objective['context_refs']=$contextRefs;
        $plan=$this->planning->draft(
            $coordinator,
            $objective,
            $items,
            (array)$workflow['dependencies'],
            ['provider-domain-ownership-preserved'],
            ['workflow_key'=>$workflowKey],
            'people-payroll:'.$workflowKey.':'.($periodKey??'').':'.($subjectType??'').':'.($subjectId??'')
        );
        $validation=$this->planning->validate($plan);
        if(!$validation['valid']) throw new RuntimeException('Generated People/Payroll goal plan failed validation.');

        return WorkforcePeoplePayrollCycle::query()->firstOrCreate(
            [
                'company_id'=>(int)$coordinator->company_id,
                'workflow_key'=>$workflowKey,
                'period_key'=>$periodKey,
                'subject_type'=>$subjectType,
                'subject_id'=>$subjectId,
            ],
            [
                'cycle_uuid'=>(string)Str::uuid(),
                'coordinator_member_id'=>(int)$coordinator->id,
                'goal_plan_id'=>(int)$plan->id,
                'status'=>'VALIDATED',
                'assignee_map'=>$assigneeMap,
                'context_refs'=>$contextRefs,
                'readiness_report'=>$readiness,
                'metadata'=>['workflow_grants_authority'=>false],
            ]
        );
    }

    public function commit(WorkforcePeoplePayrollCycle $cycle): WorkforcePeoplePayrollCycle
    {
        if($cycle->status==='COMMITTED') return $cycle;
        $plan=WorkforceGoalPlan::query()->forCompany((int)$cycle->company_id)->findOrFail((int)$cycle->goal_plan_id);
        $plan=$this->planning->commit($plan);
        $cycle->forceFill([
            'goal_id'=>(int)$plan->goal_id,
            'status'=>'COMMITTED',
            'started_at'=>now(),
            'metadata'=>array_merge((array)$cycle->metadata,[
                'dispatch_required_separately'=>true,
                'domain_mutations_owned_by_providers'=>true,
            ]),
        ])->save();
        return $cycle->refresh();
    }

    /** @return array<string,mixed> */
    public function workflow(string $key): array
    {
        $doc=json_decode((string)file_get_contents(self::PATH),true,512,JSON_THROW_ON_ERROR);
        foreach((array)($doc['workflows']??[]) as $workflow){
            if((string)($workflow['key']??'')===$key) return $workflow;
        }
        throw new InvalidArgumentException('Unknown People/Payroll operations workflow.');
    }

    private function responsibilityFor(string $roleDefinitionId,string $capability): ?string
    {
        $doc=json_decode((string)file_get_contents(__DIR__.'/../../resources/workforce/responsibility-capability-requirements.json'),true,512,JSON_THROW_ON_ERROR);
        foreach((array)($doc['requirements']??[]) as $row){
            if((string)($row['role_definition_id']??'')!==$roleDefinitionId) continue;
            if(in_array($capability,(array)($row['candidate_capabilities']??[]),true)) return (string)$row['responsibility_id'];
        }
        return null;
    }
}
