<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceExecutionReceipt;
use Throwable;

final class WorkforceExecutionService
{
    public function __construct(
        private readonly WorkforceGovernanceBridge $governance,
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceOutcomeFeedbackService $outcomes,
        private readonly WorkforceExecutionIntentService $intents,
        private readonly WorkforcePostActionVerificationService $verification,
        private readonly WorkforceExecutionRecoveryService $recovery,
        private readonly TitanZeroAuthorityGuard $titanZeroAuthorityGuard,
        private readonly WorkforceAdversarialExecutionGuard $adversarialGuard,
        private readonly WorkforceThreeStageProcessingService $processing,
        private readonly WorkforceFinalAuthorityGateService $finalAuthority,
    ) {}

    public function execute(WorkforceTask $task, WorkforceMember $worker, array $command): WorkforceTask
    {
        $this->adversarialGuard->assertSafe($task, $worker, $command);
        $this->titanZeroAuthorityGuard->assertStandardGovernancePath($task, $worker, $command);

        /*
         * Compatibility/invariant note for the pre-existing execution contracts:
         * WorkforceFinalAuthorityGateService evaluates governance_complete, ['policy']['allowed'],
         * ['autonomy']['allowed'], effective_score and model_council evidence after the mandatory
         * organisational decision chain. A policy denial is the semantic successor of
         * execution.governance_policy_denied; the final gate may only tighten that rule.
         */

        // Organisational processing happens before final authority gates.
        // A proposal cannot be treated as executable merely because Governance/Risk/Autonomy would allow it.
        $processingId = trim((string) ($command['_processing_id'] ?? data_get($task->metadata ?? [], 'processing_id', '')));
        if ($processingId === '') {
            $processingId = $this->processing->begin($task, $worker, $command);
            $task->forceFill([
                'metadata' => array_merge($task->metadata ?? [], [
                    'processing_id' => $processingId,
                    'processing_model' => 'three-stage',
                    'authority_phase' => 'awaiting-organisational-approval',
                ]),
            ])->save();
            return $this->tasks->transition(
                $task->refresh(),
                WorkforceTaskStatus::Processing,
                $worker,
                'processing.requested',
                'Action entered the independent three-stage organisational processing chain before final authority gates.',
                ['processing_id' => $processingId]
            );
        }

        if (! $this->processing->isApproved((int) $task->company_id, $processingId)) {
            return $this->tasks->transition(
                $task->refresh(),
                WorkforceTaskStatus::UnderReview,
                $worker,
                'processing.awaiting_checks',
                'Action is awaiting independent origin review, domain processing and receiving-domain acceptance.',
                ['processing_id' => $processingId]
            );
        }

        $this->tasks->record(
            $task->refresh(),
            $worker,
            'processing.organizationally_approved',
            $task->status->value,
            $task->status->value,
            null,
            ['processing_id'=>$processingId,'checks'=>3]
        );

        // Final authority gates run only after the organisation has independently agreed.
        $gate = $this->finalAuthority->evaluate($task->refresh(), $worker, $processingId);
        $decision = (array)($gate['decision'] ?? []);
        $interaction = $this->governance->prepareInteraction($task->refresh(), $worker, $decision);
        $preExecution = array_merge($decision, [
            'interaction'=>$interaction,
            'final_authority_gate'=>array_diff_key($gate,['decision'=>true]),
            'processing_id'=>$processingId,
        ]);

        $task->forceFill([
            'risk_snapshot'=>$decision['risk'] ?? [],
            'assurance_snapshot'=>$decision['assurance'] ?? [],
            'autonomy_snapshot'=>$decision['autonomy'] ?? [],
            'knowledge_preflight'=>$decision['knowledge_preflight'] ?? $task->knowledge_preflight,
            'governance'=>array_merge($task->governance ?? [],[
                'post_organisational_authority'=>$preExecution,
            ]),
            'metadata'=>array_merge($task->metadata ?? [],[
                'authority_phase'=>($gate['allowed'] ?? false) ? 'final-authority-approved' : 'final-authority-blocked',
                'final_authority_gate_uuid'=>$gate['gate_uuid'] ?? null,
            ]),
        ])->save();

        if (($gate['allowed'] ?? false) !== true) {
            return $this->tasks->transition(
                $task->refresh(),
                WorkforceTaskStatus::Blocked,
                $worker,
                'authority.final_gate_denied',
                'The organisational chain approved the action, but Governance, Risk or negotiated Autonomy did not grant final authority.',
                [
                    'processing_id'=>$processingId,
                    'gate_uuid'=>$gate['gate_uuid'] ?? null,
                    'reason_codes'=>$gate['reason_codes'] ?? [],
                    'governance_allowed'=>$gate['governance_allowed'] ?? false,
                    'risk_allowed'=>$gate['risk_allowed'] ?? false,
                    'autonomy_allowed'=>$gate['autonomy_allowed'] ?? false,
                    'effective_autonomy_level'=>$gate['effective_autonomy_level'] ?? 'manual',
                ]
            );
        }

        if (($interaction['required'] ?? false) === true
            && (($interaction['available'] ?? false) !== true || ($interaction['prepared'] ?? false) !== true)) {
            return $this->tasks->transition(
                $task->refresh(),
                WorkforceTaskStatus::Blocked,
                $worker,
                'authority.interaction_blocked',
                $interaction['reason'] ?? 'Required Interaction workflow is unavailable or not ready.',
                ['interaction'=>$interaction,'processing_id'=>$processingId]
            );
        }

        if (($decision['missing_evidence'] ?? []) !== []) {
            return $this->tasks->transition(
                $task->refresh(),
                WorkforceTaskStatus::AwaitingData,
                $worker,
                'authority.evidence_collection_required',
                'Required evidence must be collected before final domain application.',
                [
                    'missing_evidence'=>$decision['missing_evidence'],
                    'required_evidence'=>$decision['required_evidence'] ?? [],
                    'interaction'=>$interaction,
                    'processing_id'=>$processingId,
                ]
            );
        }

        try {
            $locked = $this->intents->lock($task->refresh(), $worker, $command);
        } catch (Throwable $e) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.intent_rejected', $e->getMessage());
        }
        $attempt = $locked['attempt'];
        $this->tasks->record($task->refresh(), $worker, 'execution.intent_locked', $task->status->value, $task->status->value, null, [
            'attempt_uuid' => $attempt->attempt_uuid,
            'intent_id' => $attempt->intent_id,
            'intent_sha256' => $attempt->intent_sha256,
            'state_fingerprint' => $attempt->state_fingerprint,
            'idempotency_key' => $attempt->idempotency_key,
            'replayed' => $locked['replayed'],
        ]);

        $stateRevalidation = $this->intents->stateRevalidation($attempt, $task->refresh(), $worker);
        if (($stateRevalidation['matches_expected'] ?? false) !== true) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.state_changed', 'Authoritative domain state changed before execution; regenerate/review intent before retry.', [
                'attempt_uuid' => $attempt->attempt_uuid,
                'stateRevalidation' => $stateRevalidation,
            ]);
        }

        $receipt = is_array($attempt->receipt) ? $attempt->receipt : null;
        $commandResult = null;
        $recovered = false;

        if ($receipt === null) {
            $task = $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Executing, $worker, 'execution.started', null, [
                'attempt_uuid' => $attempt->attempt_uuid,
                'intent_id' => $attempt->intent_id,
                'idempotency_key' => $attempt->idempotency_key,
            ]);
            $attempt->forceFill(['status' => 'DISPATCHING', 'dispatched_at' => now()])->save();
            $commandResult = $this->governance->command($task, $worker, $command, [
                'intent_id' => $attempt->intent_id,
                'intent_sha256' => $attempt->intent_sha256,
                'state_fingerprint' => $attempt->state_fingerprint,
                'idempotency_key' => $attempt->idempotency_key,
                'expected_state' => $attempt->expected_state,
            ]);

            if (($commandResult['executed'] ?? false) !== true) {
                if (($commandResult['uncertain'] ?? false) === true) {
                    $reconcile = $this->recovery->reconcileReceipt($attempt->refresh(), $task->refresh(), $worker);
                    if (($reconcile['recovered'] ?? false) === true && is_array($reconcile['receipt'] ?? null)) {
                        $receipt = $reconcile['receipt'];
                        $recovered = true;
                        $this->tasks->record($task->refresh(), $worker, 'execution.recovered', $task->status->value, $task->status->value, null, ['receipt_ref' => $reconcile['receipt_ref'] ?? null]);
                    } else {
                        $task->forceFill(['result' => $commandResult])->save();
                        return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.uncertain', 'Command Bus execution outcome is uncertain; reconcile receipt before any retry.', ['attempt_uuid' => $attempt->attempt_uuid, 'recovery' => $reconcile]);
                    }
                } else {
                    $attempt->refresh()->forceFill(['status' => 'COMMAND_BLOCKED', 'recovery' => ['reason_code' => 'COMMAND_BLOCKED', 'command_result' => $commandResult]])->save();
                    $task->forceFill(['result' => $commandResult])->save();
                    return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Blocked, $worker, 'execution.command_blocked', $commandResult['reason'] ?? 'Command Bus rejected execution.', ['receipt' => $commandResult['receipt'] ?? null]);
                }
            } else {
                $receipt = $commandResult['receipt'] ?? null;
            }
        }

        if ($receipt === null || $receipt === '') {
            $reconcile = $this->recovery->reconcileReceipt($attempt->refresh(), $task->refresh(), $worker);
            if (($reconcile['recovered'] ?? false) === true && is_array($reconcile['receipt'] ?? null)) {
                $receipt = $reconcile['receipt'];
                $recovered = true;
                $this->tasks->record($task->refresh(), $worker, 'execution.recovered', $task->status->value, $task->status->value, null, ['receipt_ref' => $reconcile['receipt_ref'] ?? null]);
            } else {
                $task->forceFill(['result' => $commandResult ?? ['executed' => true, 'receipt' => null]])->save();
                return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.receipt_missing', 'Command Bus execution has no authoritative receipt; reconciliation is required before completion or retry.', ['attempt_uuid' => $attempt->attempt_uuid, 'recovery' => $reconcile]);
            }
        }

        try {
            $receipt = WorkforceExecutionReceipt::validate($receipt, [
                'company_id' => (int) $task->company_id,
                'task_id' => (string) $task->task_uuid,
                'capability' => (string) $task->capability,
                'intent_id' => (string) $attempt->intent_id,
                'intent_sha256' => (string) $attempt->intent_sha256,
                'idempotency_key' => (string) $attempt->idempotency_key,
            ]);
        } catch (Throwable $e) {
            $invalidReceipt = is_array($receipt) ? $receipt : ['raw' => $receipt];
            $attempt->refresh()->forceFill([
                'receipt' => $invalidReceipt,
                'receipt_sha256' => hash('sha256', json_encode($invalidReceipt, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
                'status' => 'RECOVERY_REQUIRED',
                'recovery' => ['reason_code' => 'RECEIPT_INVALID', 'error' => $e->getMessage()],
            ])->save();
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.receipt_invalid', 'Command Bus returned a receipt that does not match the locked execution intent.', ['attempt_uuid' => $attempt->attempt_uuid, 'error' => $e->getMessage()]);
        }
        $this->recovery->storeReceipt($attempt->refresh(), $receipt, $recovered ? 'RECONCILED' : 'RECEIPT_VALIDATED');

        $verification = $this->verification->verifyReceipt($attempt->refresh(), $task->refresh(), $worker, $receipt, $command);
        if (($verification['verified'] ?? false) !== true) {
            return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Recovery, $worker, 'execution.verification_failed', 'Command Bus receipt exists but the authoritative post-action state has not been verified.', [
                'attempt_uuid' => $attempt->attempt_uuid,
                'receipt_ref' => $receipt['receipt_id'] ?? null,
                'verification' => $verification,
                'compensation_available' => in_array((string) ($locked['capability']['reversibility'] ?? 'irreversible'), ['reversible','compensatable'], true),
            ]);
        }

        $feedbackInput = is_array($commandResult) ? $commandResult : [];
        $feedbackInput['executed'] = true;
        $feedbackInput['receipt'] = $receipt;
        $feedbackInput['verification'] = $verification;
        $feedbackInput['attempt_uuid'] = $attempt->attempt_uuid;
        $feedbackInput['intent_id'] = $attempt->intent_id;
        $feedbackInput['intent_sha256'] = $attempt->intent_sha256;
        $feedbackInput['idempotency_key'] = $attempt->idempotency_key;
        $feedback = $this->outcomes->record($task->refresh(), $worker, $feedbackInput);
        $attempt->refresh()->forceFill(['status' => 'COMPLETED'])->save();
        $task->forceFill(['result' => array_merge($feedbackInput, ['outcome_feedback' => $feedback])])->save();

        return $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Completed, $worker, 'execution.completed', null, [
            'attempt_uuid' => $attempt->attempt_uuid,
            'receipt' => $receipt,
            'receipt_ref' => $feedback['receipt_ref'] ?? ($receipt['receipt_id'] ?? null),
            'verification_ref' => $verification['domain_state_ref'] ?? null,
            'rewind_ref' => $feedback['rewind_ref'] ?? null,
            'outcome_ref' => $feedback['outcome_ref'] ?? null,
        ]);
    }
}
