<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use LogicException;

/** Append-only structured journey evidence. It never stores private chain-of-thought. */
final class WorkforceJourneyRecord extends Model
{
    protected $table = 'ext_titan_ai_workforce_journey_records';
    protected $guarded = [];
    protected $casts = [
        'rationale_refs' => 'array',
        'evidence_refs' => 'array',
        'decision_refs' => 'array',
        'execution_refs' => 'array',
        'outcome_refs' => 'array',
        'summary' => 'array',
        'observed_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(static function (): never {
            throw new LogicException('Workforce journey records are append-only and cannot be updated.');
        });
        static::deleting(static function (): never {
            throw new LogicException('Workforce journey records are append-only and cannot be deleted.');
        });
    }

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
