<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceStaffingProposalService
{
    public function __construct(
        private readonly WorkforcePlanningService $planning,
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforceJourneySpineService $journey,
    ) {}

    public function refreshFromCurrentQueues(int $companyId, string $businessTier, array $verticals = []): Collection
    {
        $metrics = [];
        foreach (WorkforceDivision::query()->forCompany($companyId)->where('is_active', true)->get(['id','key']) as $division) {
            $metrics[$division->key] = $this->queueHealth->snapshot($companyId, (int) $division->id);
        }
        return $this->refresh($companyId, $businessTier, $verticals, $metrics);
    }

    public function refresh(int $companyId, string $businessTier, array $verticals = [], array $metrics = []): Collection
    {
        $recommendations = $this->planning->recommend($companyId, $businessTier, $verticals, $metrics);
        $rows = collect();
        foreach ($recommendations as $recommendation) {
            $proposal = WorkforceStaffingProposal::query()->forCompany($companyId)
                ->where('role_definition_id', $recommendation['role_id'])
                ->where('status', 'RECOMMENDED')
                ->first();
            $isNew = ! $proposal;
            if (! $proposal) {
                $traceId = (string) Str::uuid();
                $proposal = new WorkforceStaffingProposal([
                    'proposal_uuid' => (string) Str::uuid(),
                    'company_id' => $companyId,
                    'role_definition_id' => $recommendation['role_id'],
                    'role_key' => $recommendation['key'],
                    'role_name' => $recommendation['name'],
                    'division_key' => $recommendation['division'],
                    'status' => 'RECOMMENDED',
                    'trace_id' => $traceId,
                    'correlation_id' => $traceId,
                    'causation_id' => null,
                    'recommended_at' => now(),
                ]);
            }
            $proposal->forceFill([
                'reason' => $recommendation['reason'],
                'score' => (int) $recommendation['score'],
                'risk_ceiling' => $recommendation['risk_ceiling'],
                'metrics' => $metrics[$recommendation['division']] ?? [],
                'metadata' => array_merge($proposal->metadata ?? [], [
                    'business_tier' => strtoupper($businessTier),
                    'verticals' => array_values($verticals),
                    'auto_activate' => false,
                ]),
            ])->save();
            if ($isNew) {
                $this->journey->recordStaffingLifecycle($proposal, 'staffing.recommended', [
                    'proposal_uuid' => $proposal->proposal_uuid,
                    'role_definition_id' => $proposal->role_definition_id,
                    'role_key' => $proposal->role_key,
                    'division_key' => $proposal->division_key,
                    'score' => $proposal->score,
                    'auto_activate' => false,
                ]);
            }
            $rows->push($proposal->refresh());
        }
        return $rows;
    }

    public function list(int $companyId): Collection
    {
        return WorkforceStaffingProposal::query()->forCompany($companyId)
            ->orderByRaw("CASE status WHEN 'RECOMMENDED' THEN 0 WHEN 'APPROVED' THEN 1 ELSE 2 END")
            ->orderByDesc('score')->orderByDesc('recommended_at')->limit(100)->get();
    }

    public function approve(int $companyId, WorkforceStaffingProposal $proposal, int $userId, ?string $reason = null): WorkforceStaffingProposal
    {
        $this->assertCompany($companyId, $proposal);
        if ($proposal->status !== 'RECOMMENDED') {
            throw new InvalidArgumentException('Only RECOMMENDED staffing proposals may be approved.');
        }
        $proposal->forceFill([
            'status' => 'APPROVED',
            'reviewed_by_user_id' => $userId,
            'reviewed_at' => now(),
            'review_reason' => $reason,
            'metadata' => array_merge($proposal->metadata ?? [], ['auto_activate' => false, 'approval_grants_authority' => false]),
        ])->save();
        $this->journey->recordStaffingLifecycle($proposal, 'staffing.approved', [
            'proposal_uuid' => $proposal->proposal_uuid,
            'role_definition_id' => $proposal->role_definition_id,
            'role_key' => $proposal->role_key,
            'reviewed_by_user_id' => $userId,
            'auto_activate' => false,
            'approval_grants_authority' => false,
        ]);
        return $proposal->refresh();
    }

    public function reject(int $companyId, WorkforceStaffingProposal $proposal, int $userId, ?string $reason = null): WorkforceStaffingProposal
    {
        $this->assertCompany($companyId, $proposal);
        if (! in_array($proposal->status, ['RECOMMENDED','APPROVED'], true)) {
            throw new InvalidArgumentException('Only active staffing proposals may be rejected.');
        }
        $proposal->forceFill([
            'status' => 'REJECTED',
            'reviewed_by_user_id' => $userId,
            'reviewed_at' => now(),
            'review_reason' => $reason,
            'metadata' => array_merge($proposal->metadata ?? [], ['auto_activate' => false]),
        ])->save();
        $this->journey->recordStaffingLifecycle($proposal, 'staffing.rejected', [
            'proposal_uuid' => $proposal->proposal_uuid,
            'role_definition_id' => $proposal->role_definition_id,
            'role_key' => $proposal->role_key,
            'reviewed_by_user_id' => $userId,
            'auto_activate' => false,
        ]);
        return $proposal->refresh();
    }

    private function assertCompany(int $companyId, WorkforceStaffingProposal $proposal): void
    {
        if ((int) $proposal->company_id !== $companyId) {
            throw new InvalidArgumentException('Cross-tenant staffing proposal operation rejected.');
        }
    }
}
