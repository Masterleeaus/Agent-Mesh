<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use InvalidArgumentException;

/**
 * Canonical resource-economics decision point.
 * Cost never grants authority: this service assumes policy/authority/autonomy have already bounded the action,
 * and it can only further restrict execution based on privacy, resource ownership, entitlement and budget.
 */
final class CostSovereigntyRouter
{
    private const PRIORITY = ['device'=>10,'local'=>20,'byo_api'=>30,'customer_service'=>40,'titan_entitled'=>50,'titan_metered'=>60];

    public function __construct(
        private readonly WorkforceResourceEconomicsRegistry $economics,
        private readonly WorkforceEntitlementService $entitlements,
        private readonly WorkforceResourceBudgetService $budgets,
        private readonly WorkforceCostReceiptService $receipts,
    ) {}

    /**
     * @param list<array<string,mixed>> $candidates
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    public function select(int $companyId, string $resourceType, array $candidates, array $context = []): array
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Cost Sovereignty routing requires company_id.');
        $tier = strtolower((string) ($context['business_capability_tier'] ?? 'free'));
        $autonomy = strtolower((string) ($context['autonomy_level'] ?? 'assist'));
        $explicitTitan = (bool) ($context['explicit_titan_managed_opt_in'] ?? false);
        $explicitApproval = (bool) ($context['explicit_cost_approval'] ?? false);
        $filtered = [];
        $rejections = [];

        foreach ($candidates as $candidate) {
            if (! is_array($candidate) || ! ($candidate['available'] ?? true)) continue;
            if ($this->containsSecretMaterial($candidate)) { $rejections[]=['route'=>(string)($candidate['route_kind']??''),'reason'=>'SECRET_MATERIAL_IN_ROUTE_METADATA']; continue; }
            $kind = (string) ($candidate['route_kind'] ?? '');
            if (! isset(self::PRIORITY[$kind])) { $rejections[]=['route'=>$kind,'reason'=>'UNKNOWN_ROUTE_KIND']; continue; }
            foreach (['security_ok','privacy_ok','quality_ok','capability_ok','data_residency_ok','policy_ok'] as $gate) {
                if (array_key_exists($gate, $candidate) && $candidate[$gate] !== true) { $rejections[]=['route'=>$kind,'reason'=>strtoupper($gate).'_FAILED']; continue 2; }
            }
            $owner = (string) ($candidate['cost_owner'] ?? ($kind === 'titan_entitled' || $kind === 'titan_metered' ? 'titan' : ($kind === 'device' ? 'none' : 'customer')));
            $estimated = max(0.0, (float) ($candidate['estimated_cost'] ?? 0.0));
            $entitlement = (string) ($candidate['requires_entitlement'] ?? $this->economics->managedEntitlement($resourceType) ?? '');

            if ($owner === 'titan') {
                if (! $explicitTitan) { $rejections[]=['route'=>$kind,'reason'=>'TITAN_MANAGED_NOT_EXPLICITLY_OPTED_IN']; continue; }
                if ($entitlement === '' || ! $this->entitlements->has($companyId, $entitlement)) { $rejections[]=['route'=>$kind,'reason'=>'TITAN_MANAGED_ENTITLEMENT_REQUIRED','entitlement'=>$entitlement]; continue; }
                $budget = $this->budgets->authorize($companyId, $resourceType, $estimated, $autonomy, $explicitApproval);
                if (! $budget['allowed']) { $rejections[]=['route'=>$kind,'reason'=>$budget['reason']]; continue; }
            }
            if ($tier === 'free' && $owner === 'titan' && ! $explicitTitan) { $rejections[]=['route'=>$kind,'reason'=>'FREE_TIER_TITAN_VARIABLE_COST_DENIED']; continue; }
            $candidate['route_kind']=$kind;
            $candidate['cost_owner']=$owner;
            $candidate['estimated_cost']=$estimated;
            $candidate['priority']=self::PRIORITY[$kind];
            $filtered[]=$candidate;
        }

        usort($filtered, static fn(array $a,array $b): int => [$a['priority'], (float)$a['estimated_cost'], (string)($a['provider']??'')] <=> [$b['priority'], (float)$b['estimated_cost'], (string)($b['provider']??'')]);
        if ($filtered === []) {
            return ['status'=>'denied','reason'=>'NO_ZERO_OR_ENTITLED_RESOURCE_ROUTE','company_id'=>$companyId,'resource_type'=>$resourceType,'rejections'=>$rejections,
                'alternatives'=>['use_device_or_local','configure_byo_provider','queue_safely','activate_relevant_titan_add_on']];
        }
        $selected=$filtered[0];
        return ['status'=>'selected','company_id'=>$companyId,'resource_type'=>$resourceType,'selected'=>$selected,'rejections'=>$rejections,
            'titan_variable_cost_authorized'=>($selected['cost_owner']??null)==='titan','hidden_fallback'=>false];
    }

    /**
     * Commit actual managed usage after successful execution. Selection is authorization; commit is accounting.
     * Customer-owned/device routes generate a transparency receipt without debiting Titan allowances.
     * @param array<string,mixed> $selection
     * @param array<string,mixed> $usage
     * @return array<string,mixed>
     */
    public function commitUsage(int $companyId, string $capability, array $selection, array $usage = []): array
    {
        $selected = (array) ($selection['selected'] ?? []);
        if (($selection['status'] ?? null) !== 'selected' || $selected === []) {
            throw new InvalidArgumentException('Cost usage can only be committed from a selected Cost Sovereignty route.');
        }
        if ($this->containsSecretMaterial($usage)) throw new InvalidArgumentException('Usage accounting must not contain provider secrets.');
        $resourceType=(string)($selection['resource_type']??$selected['resource_type']??'unknown');
        $actual=max(0.0,(float)($usage['actual_cost']??$selected['estimated_cost']??0.0));
        $units=max(0.0,(float)($usage['billing_units']??1.0));
        $owner=(string)($selected['cost_owner']??'none');
        $entitlement=(string)($selected['requires_entitlement']??'');
        if ($owner==='titan') {
            if ($entitlement==='' || ! $this->entitlements->consume($companyId,$entitlement,$units)) {
                throw new InvalidArgumentException('Titan-managed allowance is unavailable or exhausted.');
            }
            if (! $this->budgets->consume($companyId,$resourceType,$actual)) {
                throw new InvalidArgumentException('Titan-managed resource budget would be exceeded.');
            }
        }
        $receipt=$this->receipts->record([
            'company_id'=>$companyId,
            'correlation_id'=>$usage['correlation_id']??null,
            'actor'=>$usage['actor']??null,
            'workforce_role'=>$usage['workforce_role']??null,
            'manager'=>$usage['manager']??null,
            'capability'=>$capability,
            'provider'=>(string)($selected['provider']??'unknown'),
            'execution_location'=>(string)($selected['execution_location']??'unknown'),
            'cost_owner'=>$owner,
            'resource_type'=>$resourceType,
            'estimated_cost'=>(float)($selected['estimated_cost']??0.0),
            'actual_cost'=>$actual,
            'currency'=>(string)($usage['currency']??'USD'),
            'billing_units'=>$units,
            'billing_unit'=>$usage['billing_unit']??null,
            'model'=>$usage['model']??null,
            'usage'=>(array)($usage['usage']??[]),
            'entitlement_used'=>$entitlement!==''?$entitlement:null,
            'autonomy_level'=>(string)($usage['autonomy_level']??'assist'),
            'approval'=>(array)($usage['approval']??[]),
            'outcome'=>(array)($usage['outcome']??[]),
            'metadata'=>(array)($usage['metadata']??[]),
        ]);
        return ['receipt_id'=>$receipt->getKey(),'actual_cost'=>$actual,'billing_units'=>$units,'cost_owner'=>$owner,'resource_type'=>$resourceType];
    }

    private function containsSecretMaterial(array $value): bool
    {
        $forbidden=['api_key','apikey','secret','password','access_token','refresh_token','auth_token','credential_value'];
        $walk=function(array $arr) use (&$walk,$forbidden): bool {
            foreach($arr as $k=>$v){$key=strtolower((string)$k); if(in_array($key,$forbidden,true)) return true; if(is_array($v)&&$walk($v)) return true;}
            return false;
        };
        return $walk($value);
    }

    /** @return list<array<string,mixed>> */
    public function canonicalCandidatesForProvider(string $provider, array $availability = []): array
    {
        $defaults=$this->economics->provider($provider);
        $resource=(string)($defaults['resource_type']??'software');
        $routes=[];
        foreach ((array)($defaults['routes']??['device']) as $kind) {
            $kind=(string)$kind;
            $routes[]=[
                'provider'=>$provider,'route_kind'=>$kind,'resource_type'=>$resource,
                'available'=>(bool)($availability[$kind]??false),
                'execution_location'=>match($kind){'device'=>'device','local'=>'local_network','byo_api'=>'byo_provider','customer_service'=>'customer_cloud',default=>'titan_cloud'},
                'cost_owner'=>match($kind){'device'=>'none','local','byo_api','customer_service'=>'customer',default=>'titan'},
                'cost_type'=>match($kind){'device'=>'none','local'=>'fixed','byo_api','customer_service'=>'passthrough',default=>'metered'},
                'requires_entitlement'=>in_array($kind,['titan_entitled','titan_metered'],true)?$this->economics->managedEntitlement($resource):null,
            ];
        }
        return $routes;
    }
}
