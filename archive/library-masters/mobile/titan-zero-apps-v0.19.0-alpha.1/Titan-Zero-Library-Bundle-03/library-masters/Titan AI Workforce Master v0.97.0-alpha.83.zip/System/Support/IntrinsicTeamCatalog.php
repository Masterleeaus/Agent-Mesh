<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class IntrinsicTeamCatalog
{
    /** @var array<int,array<string,mixed>>|null */
    private static ?array $definitions = null;

    /** @return array<int,array<string,mixed>> */
    public function all(): array
    {
        if (self::$definitions !== null) return self::$definitions;

        $path = dirname(__DIR__, 2) . '/resources/workforce/team-definitions.json';
        if (! is_file($path)) throw new RuntimeException('Intrinsic Workforce team catalogue is missing.');

        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new RuntimeException('Intrinsic Workforce team catalogue must be an array.');

        return self::$definitions = array_values($decoded);
    }

    /** @return array<string,mixed>|null */
    public function find(string $keyOrDefinitionId): ?array
    {
        foreach ($this->all() as $definition) {
            if (($definition['key'] ?? null) === $keyOrDefinitionId || ($definition['team_definition_id'] ?? null) === $keyOrDefinitionId) return $definition;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public function forDivision(string $divisionKey): array
    {
        return array_values(array_filter($this->all(), static fn (array $definition): bool => (string) ($definition['division_key'] ?? '') === $divisionKey));
    }

    public function definitionId(string $key): string
    {
        return 'titan.team.' . $key;
    }
}
