<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceSignalWorkReceipt extends Model
{
    protected $table = 'ext_titan_ai_workforce_signal_work_receipts';
    protected $guarded = [];
    protected $casts = ['processed_at' => 'datetime', 'metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
