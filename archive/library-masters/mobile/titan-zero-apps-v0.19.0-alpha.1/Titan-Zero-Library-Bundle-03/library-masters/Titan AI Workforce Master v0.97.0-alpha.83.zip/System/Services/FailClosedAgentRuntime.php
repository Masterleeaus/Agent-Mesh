<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Contracts\AgentRuntimeContract;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeFailure;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeRequest;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeResponse;

final class FailClosedAgentRuntime implements AgentRuntimeContract
{
    public function execute(RuntimeRequest $request): RuntimeResponse
    {
        return new RuntimeResponse(
            status: 'unavailable',
            failure: null,
            metadata: [
                'runtime_contract' => AgentRuntimeContract::PROTOCOL,
                'reason' => 'No Agent Runtime implementation is registered.',
                'company_id' => $request->identity->companyId,
                'execution_authority' => 'none',
            ],
        );
    }
}
