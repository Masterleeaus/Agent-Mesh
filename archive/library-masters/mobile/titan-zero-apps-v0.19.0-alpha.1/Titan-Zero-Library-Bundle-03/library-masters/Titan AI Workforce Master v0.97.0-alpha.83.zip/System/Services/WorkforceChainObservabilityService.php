<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFederation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerFeedback;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainLearningRecommendation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainAdminOverride;
use Illuminate\Support\Facades\DB;

final class WorkforceChainObservabilityService
{
    public function __construct(
        private readonly WorkforceChainAuditReconstructionService $audit,
        private readonly WorkforceAdaptiveChainIntelligenceService $adaptive,
        private readonly WorkforcePredictiveChainFailureService $predictiveFailure,
        private readonly WorkforceChainPolicyAdminService $adminPolicy,
    ) {}

    /** @return array<string,mixed> */
    public function dashboard(int $companyId,int $limit=100): array
    {
        $chains=WorkforceDecisionChain::query()->forCompany($companyId)
            ->with('task')->latest('updated_at')->limit(max(1,min(250,$limit)))->get();
        $processingIds=$chains->pluck('processing_id')->filter()->values();

        $checkpoints=WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->whereIn('processing_id',$processingIds)->get()->groupBy('processing_id');
        $challenges=WorkforceDecisionChallenge::query()->forCompany($companyId)
            ->whereIn('processing_id',$processingIds)->get()->groupBy('processing_id');
        $escalations=WorkforceChainEscalation::query()->forCompany($companyId)
            ->whereIn('processing_id',$processingIds)->get()->groupBy('processing_id');
        $gates=WorkforceFinalAuthorityGate::query()->forCompany($companyId)
            ->whereIn('processing_id',$processingIds)->get()->keyBy('processing_id');
        $federations=WorkforceChainFederation::query()->forCompany($companyId)
            ->whereIn('root_processing_id',$processingIds)->get()->keyBy('root_processing_id');
        $recoveries=WorkforceRecoveryPlan::query()->forCompany($companyId)
            ->whereIn('root_processing_id',$processingIds)->latest('id')->get()->keyBy('root_processing_id');

        $rows=$chains->map(function($chain) use($checkpoints,$challenges,$escalations,$gates,$federations,$recoveries){
            $cp=$checkpoints->get($chain->processing_id,collect());
            $active=$cp->first(fn($c)=>!in_array($c->status->value,['PASSED','REJECTED'],true));
            $challengeRows=$challenges->get($chain->processing_id,collect());
            $escalationRows=$escalations->get($chain->processing_id,collect());
            $gate=$gates->get($chain->processing_id);
            $federation=$federations->get($chain->processing_id);
            $recovery=$recoveries->get($chain->processing_id);
            $age=max(0,now()->diffInSeconds($chain->created_at,false)*-1);
            $updatedAge=max(0,now()->diffInSeconds($chain->updated_at,false)*-1);
            $bottleneck=$this->bottleneck($chain,$cp,$challengeRows,$escalationRows,$gate,$updatedAge);
            $adaptive=$this->adaptive->profile($chain);
            $prediction=$this->predictiveFailure->predict($chain);

            return [
                'chain_uuid'=>$chain->chain_uuid,'processing_id'=>$chain->processing_id,
                'task_uuid'=>$chain->task?->task_uuid,'capability'=>$chain->task?->capability,
                'state'=>$chain->state->value,'risk_class'=>$chain->risk_class,
                'current_stage'=>$active?->stage,'current_reviewer_member_id'=>$active?->reviewer_member_id,
                'organisationally_approved'=>(bool)$chain->organisationally_approved,
                'open_challenges'=>$challengeRows->whereIn('status',['OPEN','REBUTTED','ESCALATED'])->count(),
                'open_escalations'=>$escalationRows->where('status','OPEN')->count(),
                'final_authority_allowed'=>$gate?->final_allowed,
                'blocked_gate'=>$gate && !$gate->final_allowed ? $this->blockedGate($gate) : null,
                'federation_uuid'=>$federation?->federation_uuid,
                'federation_status'=>$federation?->status,
                'federated_domains'=>$federation?->domain_path ?? [],
                'federated_handoffs_accepted'=>$federation?->accepted_handoff_count ?? 0,
                'federated_handoffs_total'=>$federation?->handoff_count ?? 0,
                'recovery_uuid'=>$recovery?->recovery_uuid,
                'recovery_status'=>$recovery?->status,
                'recovery_verified_steps'=>$recovery?->verified_step_count ?? 0,
                'recovery_total_steps'=>$recovery?->step_count ?? 0,
                'manual_recovery_required'=>$recovery?->manual_intervention_required ?? false,
                'age_seconds'=>$age,'seconds_since_progress'=>$updatedAge,
                'adaptive_depth'=>$adaptive->depth,
                'uncertainty_score'=>$adaptive->uncertainty_score,
                'consequence_score'=>$adaptive->consequence_score,
                'reviewer_quality_floor'=>$adaptive->reviewer_quality_floor,
                'force_assurance'=>$adaptive->force_assurance,
                'force_model_council'=>$adaptive->force_model_council,
                'failure_probability'=>$prediction->failure_probability,
                'failure_risk_band'=>$prediction->risk_band,
                'likely_disagreement'=>$prediction->likely_disagreement,
                'likely_authority_denial'=>$prediction->likely_authority_denial,
                'likely_stall'=>$prediction->likely_stall,
                'weak_reviewer_pool'=>$prediction->weak_reviewer_pool,
                'knowledge_gap_risk'=>$prediction->knowledge_gap_risk,
                'bottleneck'=>$bottleneck,
            ];
        })->values();

        $reviewer=$this->reviewerHealth($companyId);
        return [
            'summary'=>[
                'chains'=>$rows->count(),
                'active'=>$rows->whereNotIn('state',['CLOSED','REJECTED'])->count(),
                'organisationally_approved'=>$rows->where('organisationally_approved',true)->count(),
                'with_disagreement'=>$rows->where('open_challenges','>',0)->count(),
                'with_escalation'=>$rows->where('open_escalations','>',0)->count(),
                'blocked_final_authority'=>$rows->filter(fn($r)=>$r['blocked_gate']!==null)->count(),
                'stalled'=>$rows->filter(fn($r)=>$r['bottleneck']['severity']==='critical')->count(),
            ],
            'chains'=>$rows->all(),
            'reviewer_health'=>$reviewer,
            'admin_policy'=>$this->adminPolicy->policy($companyId)->toArray(),
            'active_admin_overrides'=>WorkforceChainAdminOverride::query()
                ->forCompany($companyId)->where('status','ACTIVE')->latest('created_at_override')->limit(100)->get()
                ->map(fn($o)=>[
                    'override_uuid'=>$o->override_uuid,'processing_id'=>$o->processing_id,
                    'override_type'=>$o->override_type,'reason'=>$o->reason,'effect'=>$o->effect,
                    'created_by_user_id'=>$o->created_by_user_id,
                    'created_at'=>$o->created_at_override?->toIso8601String(),
                ])->values()->all(),
            'learning_recommendations'=>WorkforceChainLearningRecommendation::query()
                ->forCompany($companyId)->where('status','PROPOSED')
                ->orderByDesc('confidence')->limit(50)->get()
                ->map(fn($r)=>[
                    'recommendation_uuid'=>$r->recommendation_uuid,
                    'scope_key'=>$r->scope_key,
                    'type'=>$r->recommendation_type,
                    'confidence'=>(float)$r->confidence,
                    'sample_size'=>(int)$r->sample_size,
                    'recommended_policy'=>$r->recommended_policy,
                    'evidence'=>$r->evidence,
                    'requires_user_approval'=>true,
                ])->values()->all(),
            'bottlenecks'=>$rows->filter(fn($r)=>$r['bottleneck']['severity']!=='normal')
                ->sortByDesc(fn($r)=>$r['seconds_since_progress'])->values()->all(),
            'generated_at'=>now()->toIso8601String(),
        ];
    }

    /** @return array<string,mixed> */
    public function chain(int $companyId,string $chainUuid): array
    {
        $chain=WorkforceDecisionChain::query()->forCompany($companyId)->where('chain_uuid',$chainUuid)->firstOrFail();
        return $this->audit->reconstruct($chain);
    }

    /** @return array<int,array<string,mixed>> */
    private function reviewerHealth(int $companyId): array
    {
        return WorkforceReviewerFeedback::query()->forCompany($companyId)
            ->selectRaw('reviewer_member_id, COUNT(*) samples, AVG(quality_score) quality,
                SUM(CASE WHEN overturned=1 THEN 1 ELSE 0 END) overturns,
                SUM(CASE WHEN missed_risk=1 THEN 1 ELSE 0 END) missed_risks,
                SUM(CASE WHEN unnecessary_escalation=1 THEN 1 ELSE 0 END) unnecessary_escalations')
            ->groupBy('reviewer_member_id')->orderByDesc('samples')->limit(100)->get()
            ->map(fn($r)=>[
                'reviewer_member_id'=>(int)$r->reviewer_member_id,'samples'=>(int)$r->samples,
                'decision_quality'=>round((float)$r->quality,2),'overturns'=>(int)$r->overturns,
                'missed_risks'=>(int)$r->missed_risks,'unnecessary_escalations'=>(int)$r->unnecessary_escalations,
            ])->all();
    }

    private function blockedGate($gate): string
    {
        if(!$gate->governance_allowed) return 'governance';
        if(!$gate->risk_allowed) return 'risk';
        if(!$gate->autonomy_allowed) return 'autonomy';
        return 'unknown';
    }

    private function bottleneck($chain,$cp,$challenges,$escalations,$gate,int $updatedAge): array
    {
        $reason='healthy';$severity='normal';
        if($gate && !$gate->final_allowed){$reason='final_authority_'.$this->blockedGate($gate);$severity='high';}
        elseif($escalations->where('status','OPEN')->isNotEmpty()){$reason='manager_escalation';$severity='high';}
        elseif($challenges->whereIn('status',['OPEN','REBUTTED','ESCALATED'])->isNotEmpty()){$reason='reviewer_disagreement';$severity='medium';}
        elseif($cp->whereNotIn('status',['PASSED','REJECTED'])->isNotEmpty()){$reason='review_pending';$severity='medium';}
        if($updatedAge>=86400){$reason='no_progress_24h';$severity='critical';}
        elseif($updatedAge>=14400 && $severity==='normal'){$reason='no_progress_4h';$severity='medium';}
        return ['reason'=>$reason,'severity'=>$severity];
    }
}
