<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

/**
 * Canonical Workforce role registry.
 *
 * Employee identity is owned exclusively by Titan AI Workforce. Contributing
 * extensions attach capabilities through WorkforceCapabilityBindingRegistry;
 * extension manifest role blocks are compatibility hints only.
 */
final class WorkforceRoleRegistry
{
    public static function all(): array
    {
        $executive = (new ExecutiveRoleCatalog())->runtimeRoles();
        $intrinsic = (new IntrinsicRoleCatalog())->runtimeRoles();

        foreach ($intrinsic as &$role) $role['definition_source'] = 'intrinsic_workforce_catalogue';
        unset($role);

        return array_values(array_merge($executive, $intrinsic));
    }

    public static function keyed(): array
    {
        $out = [];
        foreach (self::all() as $role) $out[(string) $role['key']] = $role;
        return $out;
    }

    public static function find(string $keyOrRoleId): ?array
    {
        foreach (self::all() as $role) {
            if (($role['key'] ?? null) === $keyOrRoleId || ($role['role_id'] ?? null) === $keyOrRoleId || ($role['role_definition_id'] ?? null) === $keyOrRoleId) return $role;
            if (in_array($keyOrRoleId, $role['aliases'] ?? [], true)) return $role;
        }
        return null;
    }

    public static function forVertical(string $vertical): array
    {
        return array_values(array_filter(self::all(), static function (array $role) use ($vertical): bool {
            $verticals = $role['activation']['verticals'] ?? $role['vertical_applicability'] ?? ['all'];
            return in_array('all', $verticals, true) || in_array($vertical, $verticals, true);
        }));
    }
}
