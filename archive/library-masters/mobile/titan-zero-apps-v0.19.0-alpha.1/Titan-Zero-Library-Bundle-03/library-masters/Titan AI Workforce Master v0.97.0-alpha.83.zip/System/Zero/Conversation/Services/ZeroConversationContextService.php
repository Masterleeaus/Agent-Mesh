<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Services;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Contracts\ZeroConversationContextStoreContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\ValueObjects\ZeroConversationContext;
final class ZeroConversationContextService
{
    public function __construct(private readonly ZeroConversationContextStoreContract $store) {}
    public function open(int $companyId,string $conversationId,string $actorId): ZeroConversationContext { return $this->load($companyId,$conversationId,$actorId) ?? new ZeroConversationContext($companyId,$conversationId,$actorId); }
    public function load(int $companyId,string $conversationId,string $actorId): ?ZeroConversationContext { return $this->store->load($companyId,$conversationId,$actorId); }
    public function recordTurn(ZeroConversationContext $c,string $role,string $content,array $metadata=[]): void { $c->turns[]=['role'=>$role,'content'=>$content,'metadata'=>$metadata]; if(count($c->turns)>40)$c->turns=array_slice($c->turns,-40); $this->store->save($c); }
    public function rememberEntity(ZeroConversationContext $c,string $type,string $ref,string $label,array $data=[]): void { $c->entities[$type]=['type'=>$type,'ref'=>$ref,'label'=>$label,'data'=>$data]; $this->store->save($c); }
    public function setActiveObject(ZeroConversationContext $c,string $type,string $ref,array $data=[]): void { $c->activeObjects[$type]=['type'=>$type,'ref'=>$ref,'data'=>$data]; $this->store->save($c); }
    public function setPendingClarification(ZeroConversationContext $c,string $id,string $question,array $data=[]): void { $c->pendingClarifications[$id]=['id'=>$id,'question'=>$question,'data'=>$data]; $this->store->save($c); }
    public function clearPendingClarification(ZeroConversationContext $c,string $id): void { unset($c->pendingClarifications[$id]); $this->store->save($c); }
    public function setPendingApproval(ZeroConversationContext $c,string $id,string $capability,array $data=[]): void { $c->pendingApprovals[$id]=['id'=>$id,'capability'=>$capability,'data'=>$data]; $this->store->save($c); }
    public function clearPendingApproval(ZeroConversationContext $c,string $id): void { unset($c->pendingApprovals[$id]); $this->store->save($c); }
    public function rememberAssumption(ZeroConversationContext $c,string $key,mixed $value,string $source,bool $confirmed=false): void { $c->assumptions[$key]=['value'=>$value,'source'=>$source,'confirmed'=>$confirmed]; $this->store->save($c); }
    public function recordOutcome(ZeroConversationContext $c,string $planId,string $status,array $data=[]): void { $c->outcomes[]=['plan_id'=>$planId,'status'=>$status,'data'=>$data]; if(count($c->outcomes)>20)$c->outcomes=array_slice($c->outcomes,-20); $this->store->save($c); }
    public function resolveReference(ZeroConversationContext $c,string $reference): ?array
    {
        $r=strtolower(trim($reference));
        if (in_array($r,['her','she','him','he','them','they'],true)) return $c->entities['customer'] ?? $c->entities['person'] ?? null;
        foreach ($c->activeObjects as $type=>$object) if (str_contains($r,(string)$type)) return $object;
        if (in_array($r,['that','that one','it'],true)) return $c->activeObjects !== [] ? end($c->activeObjects) : null;
        foreach (array_reverse($c->entities,true) as $entity) if (str_contains(strtolower((string)($entity['label']??'')),$r)) return $entity;
        return null;
    }
}
