<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceDivisionDefinition extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_division_definitions';
    protected $guarded = [];
    protected $casts = [
        'team_boundaries' => 'array',
        'applicability' => 'array',
        'activation_rules' => 'array',
        'metadata' => 'array',
    ];

    public function divisions(): HasMany
    {
        return $this->hasMany(WorkforceDivision::class, 'division_definition_id', 'division_definition_id');
    }
}
