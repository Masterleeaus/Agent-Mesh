<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts;

interface ZeroSemanticCapabilityCatalogueContract
{
    /** @return list<array<string,mixed>> */
    public function capabilities(): array;

    /** @return array<string,mixed>|null */
    public function capability(string $capabilityId): ?array;

    /** @return list<array<string,mixed>> */
    public function providerCapabilities(string $providerKey): array;

    /** @return array<string,mixed> */
    public function coverage(): array;
}
