<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use RuntimeException;

final class WorkforceResourceEconomicsRegistry
{
    /** @var array<string,mixed>|null */
    private ?array $data = null;

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->data !== null) return $this->data;
        $path = dirname(__DIR__, 2).'/resources/workforce/resource-economics-registry.json';
        $decoded = json_decode((string) @file_get_contents($path), true);
        if (! is_array($decoded)) throw new RuntimeException('Titan Cost Sovereignty registry is missing or invalid.');
        return $this->data = $decoded;
    }

    /** @return array<string,mixed> */
    public function provider(string $provider): array
    {
        return (array) (($this->all()['provider_defaults'] ?? [])[$provider] ?? []);
    }

    /** @return list<string> */
    public function routeKinds(string $provider): array
    {
        return array_values(array_map('strval', (array) ($this->provider($provider)['routes'] ?? [])));
    }

    public function managedEntitlement(string $resourceType): ?string
    {
        $v = ($this->all()['managed_entitlements'] ?? [])[$resourceType] ?? null;
        return is_string($v) && $v !== '' ? $v : null;
    }
}
