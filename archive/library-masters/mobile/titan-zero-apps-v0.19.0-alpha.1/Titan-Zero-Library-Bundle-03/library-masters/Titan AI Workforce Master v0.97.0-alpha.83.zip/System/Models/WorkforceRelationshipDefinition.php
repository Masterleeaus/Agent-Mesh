<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceRelationshipDefinition extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_relationship_definitions';
    protected $guarded = [];
    protected $casts = [
        'relationship_type' => WorkforceRelationshipType::class,
        'authority_inherited' => 'boolean',
        'metadata' => 'array',
    ];

    public function scopeVisibleToCompany($query, int $companyId)
    {
        return $query->where(function ($q) use ($companyId) {
            $q->whereNull('company_id')->orWhere('company_id', $companyId);
        });
    }
}
