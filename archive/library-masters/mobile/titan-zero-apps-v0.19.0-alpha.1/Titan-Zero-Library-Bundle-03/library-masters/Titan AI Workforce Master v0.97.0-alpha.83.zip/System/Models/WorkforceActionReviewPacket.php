<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use LogicException;

final class WorkforceActionReviewPacket extends Model
{
    protected $table = 'ext_titan_ai_workforce_action_review_packets';
    protected $guarded = [];
    protected $casts = [
        'packet'=>'array',
        'packet_version'=>'integer',
        'stage'=>'integer',
        'sealed_at'=>'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(function (self $packet): void {
            foreach ([
                'company_id','decision_chain_id','task_id','processing_id','stage','stage_key',
                'packet_version','packet_sha256','packet','sealed_at',
            ] as $field) {
                if ($packet->isDirty($field)) {
                    throw new LogicException('Immutable Workforce action review packet cannot be modified after sealing.');
                }
            }
        });
    }

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id',$companyId);
    }
}
