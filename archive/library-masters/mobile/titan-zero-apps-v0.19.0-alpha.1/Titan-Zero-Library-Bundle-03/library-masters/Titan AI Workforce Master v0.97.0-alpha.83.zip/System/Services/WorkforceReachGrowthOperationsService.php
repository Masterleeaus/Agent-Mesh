<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Services;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoalPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReachGrowthCycle;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

final class WorkforceReachGrowthOperationsService
{
    private const PATH=__DIR__.'/../../resources/workforce/reach-growth-operations-workflows.json';
    public function __construct(
        private readonly WorkforceBusinessGoalPlanningService $planning,
        private readonly WorkforceProviderRoutingService $routing,
    ) {}

    public function readiness(WorkforceMember $coordinator,string $workflowKey,array $assigneeMap): array
    {
        $workflow=$this->workflow($workflowKey);$issues=[];$routes=[];$resolved=[];
        foreach($workflow['steps'] as $step){
            $key=(string)$step['key'];$id=(int)($assigneeMap[$key]??0);
            $member=$id>0?WorkforceMember::query()->forCompany((int)$coordinator->company_id)->find($id):null;
            if(!$member||!$member->is_active){$issues[]="{$key}: active assignee required.";continue;}
            if((string)$member->role_definition_id!==(string)$step['role_definition_id']){$issues[]="{$key}: assignee role mismatch.";continue;}
            $responsibility=$this->responsibilityFor((string)$step['role_definition_id'],(string)$step['capability']);
            if(!$responsibility){$issues[]="{$key}: no canonical responsibility owns capability.";continue;}
            try{
                $route=$this->routing->assertExecutableRoute($member,(string)$step['capability'],'capability',(string)$step['provider']);
                $routes[$key]=['provider'=>(string)($route['selected_provider']??''),'provider_version'=>(string)($route['selected_provider_version']??''),'responsibility_id'=>$responsibility];
                $resolved[$key]=(int)$member->id;
            }catch(\Throwable $e){$issues[]="{$key}: ".$e->getMessage();}
        }
        return ['valid'=>$issues===[],'workflow_key'=>$workflowKey,'issues'=>$issues,'routes'=>$routes,'assignees'=>$resolved,
            'company_id'=>(int)$coordinator->company_id,'workflow_grants_authority'=>false,'knowledge_preflight_required'=>true];
    }

    public function prepare(WorkforceMember $coordinator,string $workflowKey,array $assigneeMap,array $contextRefs=[],?string $campaignRef=null,?string $leadRef=null): WorkforceReachGrowthCycle
    {
        $ready=$this->readiness($coordinator,$workflowKey,$assigneeMap);
        if(!$ready['valid']) throw new InvalidArgumentException('Reach growth workflow is not ready.');
        $workflow=$this->workflow($workflowKey);$items=[];
        foreach($workflow['steps'] as $index=>$step){
            $key=(string)$step['key'];$route=$ready['routes'][$key];
            $items[]=['key'=>$key,'title'=>(string)$step['title'],'assignee_member_id'=>(int)$ready['assignees'][$key],
                'responsibility_id'=>(string)$route['responsibility_id'],'capability'=>(string)$step['capability'],'provider'=>(string)$route['provider'],
                'expected_outcome'=>(array)$step['expected_outcome'],'evidence_requirements'=>(array)$step['evidence_requirements'],
                'sequence_index'=>$index+1,'orchestration_group'=>$workflowKey,'estimated_minutes'=>(int)($step['estimated_minutes']??10)];
        }
        $objective=(array)$workflow['objective_template'];$objective['context_refs']=$contextRefs;
        $plan=$this->planning->draft($coordinator,$objective,$items,(array)$workflow['dependencies'],
            ['reach-provider-domain-ownership-preserved','knowledge-preflight-required'],['workflow_key'=>$workflowKey],
            'reach-growth:'.$workflowKey.':'.($campaignRef??'').':'.($leadRef??''));
        $validation=$this->planning->validate($plan);
        if(!$validation['valid']) throw new RuntimeException('Generated Reach growth goal plan failed validation.');
        return WorkforceReachGrowthCycle::query()->firstOrCreate(
            ['company_id'=>(int)$coordinator->company_id,'workflow_key'=>$workflowKey,'campaign_ref'=>$campaignRef,'lead_ref'=>$leadRef],
            ['cycle_uuid'=>(string)Str::uuid(),'coordinator_member_id'=>(int)$coordinator->id,'goal_plan_id'=>(int)$plan->id,'status'=>'VALIDATED',
             'assignee_map'=>$assigneeMap,'context_refs'=>$contextRefs,'readiness_report'=>$ready,
             'metadata'=>['dispatch_required_separately'=>true,'publish_is_explicit'=>true,'knowledge_preflight_required'=>true,'workflow_grants_authority'=>false]]
        );
    }

    public function commit(WorkforceReachGrowthCycle $cycle): WorkforceReachGrowthCycle
    {
        if($cycle->status==='COMMITTED') return $cycle;
        $plan=WorkforceGoalPlan::query()->forCompany((int)$cycle->company_id)->findOrFail((int)$cycle->goal_plan_id);
        $plan=$this->planning->commit($plan);
        $cycle->forceFill(['goal_id'=>(int)$plan->goal_id,'status'=>'COMMITTED','started_at'=>now(),
            'metadata'=>array_merge((array)$cycle->metadata,['dispatch_required_separately'=>true,'publish_is_explicit'=>true])])->save();
        return $cycle->refresh();
    }

    public function workflow(string $key): array
    {
        $doc=json_decode((string)file_get_contents(self::PATH),true,512,JSON_THROW_ON_ERROR);
        foreach((array)($doc['workflows']??[]) as $workflow) if((string)($workflow['key']??'')===$key) return $workflow;
        throw new InvalidArgumentException('Unknown Reach growth workflow.');
    }

    private function responsibilityFor(string $role,string $capability): ?string
    {
        $doc=json_decode((string)file_get_contents(__DIR__.'/../../resources/workforce/responsibility-capability-requirements.json'),true,512,JSON_THROW_ON_ERROR);
        foreach((array)($doc['requirements']??[]) as $row){
            if((string)($row['role_definition_id']??'')!==$role) continue;
            if(in_array($capability,(array)($row['candidate_capabilities']??[]),true)) return (string)$row['responsibility_id'];
        }
        return null;
    }
}
