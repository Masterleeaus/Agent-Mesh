<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Contracts\WorkforceBusinessContextProviderContract;
use Illuminate\Contracts\Container\Container;
use RuntimeException;

final class WorkforceBusinessContextProviderRegistry
{
    /** @var array<string,WorkforceBusinessContextProviderContract> */
    private array $providers = [];

    public function __construct(private readonly Container $app) {}

    public function register(WorkforceBusinessContextProviderContract $provider): self
    {
        $key = strtolower(trim($provider->providerKey()));
        if ($key === '') throw new RuntimeException('Context provider requires a stable provider key.');
        $this->providers[$key] = $provider;
        return $this;
    }

    public function resolve(string $providerKey): ?WorkforceBusinessContextProviderContract
    {
        $key = strtolower(trim($providerKey));
        if ($key === '') return null;
        if (isset($this->providers[$key])) return $this->providers[$key];

        $binding = 'titan.workforce.context-provider.'.$key;
        if ($this->app->bound($binding)) {
            $resolved = $this->app->make($binding);
            if ($resolved instanceof WorkforceBusinessContextProviderContract) {
                return $this->providers[$key] = $resolved;
            }
        }
        return null;
    }

    public function has(string $providerKey): bool
    {
        return $this->resolve($providerKey) !== null;
    }
}
