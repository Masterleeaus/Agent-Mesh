<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceDecisionChallenge extends Model
{
    protected $table = 'ext_titan_ai_workforce_decision_challenges';
    protected $guarded = [];
    protected $casts = [
        'challenger_confidence'=>'decimal:2',
        'challenged_confidence'=>'decimal:2',
        'confidence_delta'=>'decimal:2',
        'disputed_claims'=>'array',
        'evidence_challenges'=>'array',
        'authority_challenges'=>'array',
        'requested_information'=>'array',
        'rebuttal'=>'array',
        'resolution'=>'array',
        'rebuttal_count'=>'integer',
        'max_rebuttals'=>'integer',
        'opened_at'=>'datetime',
        'rebutted_at'=>'datetime',
        'resolved_at'=>'datetime',
        'escalated_at'=>'datetime',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id',$companyId);
    }
}
