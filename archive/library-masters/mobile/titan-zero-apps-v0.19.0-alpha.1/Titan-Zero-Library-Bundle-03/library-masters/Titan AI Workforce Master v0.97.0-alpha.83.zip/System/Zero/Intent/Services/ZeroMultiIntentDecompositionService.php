<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentGraph;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentNode;
final class ZeroMultiIntentDecompositionService
{
    public function decompose(string $utterance,string $traceId): ZeroIntentGraph
    {
        $u=strtolower(trim($utterance)); $nodes=[]; $ids=[];
        $add=function(string $intent,float $confidence,array $deps=[],?array $condition=null,array $metadata=[]) use (&$nodes,&$ids,$traceId): string {
            if(isset($ids[$intent])) return $ids[$intent];
            $id='intent:'.substr(hash('sha256',$traceId.'|'.$intent.'|'.count($nodes)),0,24);$ids[$intent]=$id;
            $nodes[]=new ZeroIntentNode($id,$intent,$confidence,'zero-multi-intent-v1',dependsOn:$deps,condition:$condition,metadata:$metadata);return $id;
        };
        $customer=null;
        if(preg_match('/\b(?:mrs|mr|ms|miss|dr)\s+[a-z]+\b/i',$utterance)) $customer=$add('resolve_customer',0.93);
        $rate=null;
        if(str_contains($u,'usual rate')||str_contains($u,'normal rate')||str_contains($u,'same price')) $rate=$add('determine_usual_rate',0.94,$customer?[$customer]:[]);
        $quote=null;
        if(preg_match('/\b(quote|estimate|price)\b/',$u)) $quote=$add('create_quote',0.96,array_values(array_filter([$customer,$rate])));
        $availability=null;
        if(preg_match('/\b(find|someone|available|free|availability|crew|worker|staff)\b/',$u) && preg_match('/\b(mon|tue|wed|thu|fri|sat|sun|monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|today|next)\b/',$u)) $availability=$add('find_availability',0.91,$customer?[$customer]:[]);
        if(preg_match('/\b(book|schedule)\b/',$u)) {
            $deps=array_values(array_filter([$quote,$availability,$customer]));$condition=null;
            if(preg_match('/\b(if|when)\s+(?:she|he|they|customer|client)?\s*(accepts?|approves?|agrees?)\b/',$u,$m)) $condition=['event'=>'quote_accepted','source_phrase'=>$m[0]];
            $add('schedule_job',0.95,$deps,$condition);
        }
        if($nodes===[]) {
            $intent=preg_match('/\b(invoice|bill)\b/',$u)?'create_invoice':(preg_match('/\b(quote|estimate)\b/',$u)?'create_quote':'unknown');
            $add($intent,$intent==='unknown'?0.25:0.85);
        }
        return new ZeroIntentGraph('graph:'.substr(hash('sha256',$traceId.'|'.$utterance),0,24),$nodes);
    }
}
