<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMemberRating;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforcePerformanceMetric;

final class WorkforceMemberRatingService
{
    public function recalculate(WorkforceMember $member): WorkforceMemberRating
    {
        $metrics=WorkforcePerformanceMetric::query()
            ->forCompany((int)$member->company_id)
            ->where('member_id',$member->getKey())
            ->latest('period_end')->limit(250)->get();

        $dimensions=[];
        foreach($metrics->groupBy('metric_key') as $key=>$rows){
            $values=$rows->pluck('metric_value')->filter(fn($v)=>$v!==null)->map(fn($v)=>(float)$v);
            if($values->isNotEmpty()) $dimensions[(string)$key]=round((float)$values->avg(),4);
        }
        $score=$dimensions===[] ? 50.0 : round(array_sum($dimensions)/count($dimensions),4);

        return WorkforceMemberRating::query()->updateOrCreate(
            ['company_id'=>(int)$member->company_id,'member_id'=>$member->getKey()],
            [
                'score'=>max(0,min(100,$score)),
                'dimensions'=>$dimensions,
                'evidence'=>[
                    'metric_rows'=>$metrics->count(),
                    'source'=>'workforce-performance-metrics',
                    'authority_inherited'=>false,
                ],
                'calculated_at'=>now(),
            ]
        );
    }
}
