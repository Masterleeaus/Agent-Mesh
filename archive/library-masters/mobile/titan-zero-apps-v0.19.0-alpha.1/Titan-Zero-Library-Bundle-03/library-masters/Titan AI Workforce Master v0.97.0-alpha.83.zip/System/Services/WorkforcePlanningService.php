<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;

final class WorkforcePlanningService
{
    private const TIER_ORDER = ['SOLO' => 1, 'SMALL' => 2, 'GROWING' => 3, 'ENTERPRISE' => 4];

    public function recommend(int $companyId, string $businessTier, array $verticals = [], array $metrics = []): array
    {
        $tierRank = self::TIER_ORDER[strtoupper($businessTier)] ?? self::TIER_ORDER['SMALL'];
        $activeMembers = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)->get(['key','role_definition_id']);
        $activeKeys = $activeMembers->pluck('key')->filter()->all();
        $activeRoleIds = $activeMembers->pluck('role_definition_id')->filter()->all();
        $verticals = array_values(array_unique(array_filter(array_map('strval', $verticals))));
        $recommendations = [];

        foreach (WorkforceRoleRegistry::all() as $role) {
            if (in_array($role['key'], $activeKeys, true) || in_array($role['role_id'], $activeRoleIds, true)) {
                continue;
            }
            $minRank = self::TIER_ORDER[strtoupper((string) ($role['activation']['min_tier'] ?? 'SOLO'))] ?? 1;
            if ($minRank > $tierRank) {
                continue;
            }

            $roleVerticals = $role['activation']['verticals'] ?? ['all'];
            $verticalMatch = in_array('all', $roleVerticals, true) || $verticals === [] || array_intersect($roleVerticals, $verticals) !== [];
            if (! $verticalMatch) {
                continue;
            }

            $divisionMetrics = $metrics[$role['division']] ?? [];
            $queueDepth = (int) ($divisionMetrics['queue_depth'] ?? 0);
            $slaBreachRate = (float) ($divisionMetrics['sla_breach_rate'] ?? 0.0);
            $coverageGap = (bool) ($divisionMetrics['coverage_gap'] ?? false);
            $staffingPressure = is_array($divisionMetrics['staffing_pressure'] ?? null) ? $divisionMetrics['staffing_pressure'] : [];
            $staffingPressureScore = max(0, min(100, (int) ($staffingPressure['score'] ?? 0)));
            $staffingPressureRecommended = (bool) ($staffingPressure['recommend_staffing'] ?? false);

            $reason = null;
            $score = 0;
            if (($role['tier'] ?? 2) === 1 && $tierRank >= 3) { $reason = 'division_manager_required'; $score += 40; }
            if ($queueDepth >= 12) { $reason ??= 'sustained_queue_depth'; $score += min(35, $queueDepth); }
            if ($slaBreachRate >= 0.10) { $reason ??= 'sla_breach_rate'; $score += 30; }
            if ($coverageGap) { $reason ??= 'coverage_gap'; $score += 25; }
            if ($staffingPressureRecommended) { $reason ??= 'staffing_pressure'; $score += min(50, max(10, intdiv($staffingPressureScore, 2))); }
            if (! in_array('all', $roleVerticals, true) && array_intersect($roleVerticals, $verticals) !== []) { $reason ??= 'vertical_fit'; $score += 20; }

            if ($reason === null) {
                continue;
            }

            $recommendations[] = [
                'role_id' => $role['role_id'], 'key' => $role['key'], 'name' => $role['name'], 'division' => $role['division'],
                'reason' => $reason, 'score' => $score, 'risk_ceiling' => $role['risk_ceiling'],
                'action' => 'RECOMMEND_ACTIVATION', 'auto_activate' => false,
            ];
        }

        usort($recommendations, static fn (array $a, array $b): int => $b['score'] <=> $a['score']);
        return $recommendations;
    }
}
