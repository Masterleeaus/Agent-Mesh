<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

/**
 * Pure change classifier for pinned extension-owned role definitions.
 * It never grants new authority. Additive definitions remain pinned until an
 * explicit rebind; removals/structural changes are breaking and fail closed.
 */
final class WorkforceDefinitionChangeClassifier
{
    /** @return array{classification:string,reasons:list<string>,requires_explicit_rebind:bool,available_for_assignment:bool} */
    public static function compare(array $pinned, array $available): array
    {
        $reasons = [];

        foreach ([
            'role_id' => 'role_id_changed',
            'owner_extension' => 'owner_extension_changed',
            'tier' => 'tier_changed',
            'division' => 'division_changed',
            'team' => 'team_changed',
        ] as $field => $reason) {
            $old = $pinned[$field] ?? null;
            $new = $available[$field] ?? null;
            // Pre-Pass-4 snapshots may not know division/team keys. Unknown prior
            // provenance must not be invented and must not create a false breaking change.
            if ($old === null || $old === '' || ($field === 'tier' && (int) $old === 0)) continue;
            if ((string) $old !== (string) $new) $reasons[] = $reason;
        }

        foreach ([
            'capabilities' => 'capabilities_removed',
            'tool_access' => 'tools_removed',
            'workflow_refs' => 'workflows_removed',
        ] as $field => $reason) {
            if (self::removed($pinned[$field] ?? [], $available[$field] ?? []) !== []) {
                $reasons[] = $reason;
            }
        }

        $riskRank = ['MINIMAL' => 1, 'LOW' => 2, 'MEDIUM' => 3, 'HIGH' => 4, 'EXTREME' => 5];
        $oldRisk = strtoupper((string) ($pinned['risk_ceiling'] ?? 'LOW'));
        $newRisk = strtoupper((string) ($available['risk_ceiling'] ?? 'LOW'));
        if (($riskRank[$newRisk] ?? 1) < ($riskRank[$oldRisk] ?? 1)) {
            $reasons[] = 'risk_ceiling_reduced';
        }

        $oldAutonomy = self::autonomyScore($pinned);
        $newAutonomy = self::autonomyScore($available);
        if ($oldAutonomy !== null && $newAutonomy !== null && $newAutonomy < $oldAutonomy) {
            $reasons[] = 'initial_autonomy_ceiling_reduced';
        }

        if ($reasons !== []) {
            return [
                'classification' => 'BREAKING',
                'reasons' => array_values(array_unique($reasons)),
                'requires_explicit_rebind' => true,
                'available_for_assignment' => false,
            ];
        }

        if (self::canonicalSubset($pinned) === self::canonicalSubset($available)) {
            return [
                'classification' => 'IDENTICAL',
                'reasons' => [],
                'requires_explicit_rebind' => false,
                'available_for_assignment' => true,
            ];
        }

        return [
            'classification' => 'COMPATIBLE',
            'reasons' => ['definition_changed_without_contract_removal'],
            'requires_explicit_rebind' => true,
            'available_for_assignment' => true,
        ];
    }

    /** @return array{classification:string,reasons:list<string>,requires_explicit_rebind:bool,available_for_assignment:bool} */
    public static function missing(array $pinned): array
    {
        return [
            'classification' => 'MISSING',
            'reasons' => ['owner_extension_or_exact_role_definition_unavailable'],
            'requires_explicit_rebind' => true,
            'available_for_assignment' => false,
        ];
    }

    private static function autonomyScore(array $role): ?int
    {
        $value = $role['autonomy_profile']['starting_score']
            ?? $role['autonomy']['initial_earned_ceiling']['score']
            ?? null;
        return is_numeric($value) ? (int) $value : null;
    }

    /** @return list<string> */
    private static function removed(mixed $old, mixed $new): array
    {
        $old = array_values(array_unique(array_map('strval', is_array($old) ? $old : [])));
        $new = array_values(array_unique(array_map('strval', is_array($new) ? $new : [])));
        sort($old); sort($new);
        return array_values(array_diff($old, $new));
    }

    private static function canonicalSubset(array $role): string
    {
        $subset = [
            'role_id' => (string) ($role['role_id'] ?? ''),
            'owner_extension' => (string) ($role['owner_extension'] ?? ''),
            'tier' => (int) ($role['tier'] ?? 0),
            'division' => (string) ($role['division'] ?? ''),
            'team' => (string) ($role['team'] ?? ''),
            'capabilities' => self::sorted($role['capabilities'] ?? []),
            'tool_access' => self::sorted($role['tool_access'] ?? []),
            'workflow_refs' => self::sorted($role['workflow_refs'] ?? []),
            'risk_ceiling' => strtoupper((string) ($role['risk_ceiling'] ?? 'LOW')),
            'autonomy_score' => self::autonomyScore($role),
        ];
        return json_encode($subset, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    /** @return list<string> */
    private static function sorted(mixed $values): array
    {
        $values = array_values(array_unique(array_map('strval', is_array($values) ? $values : [])));
        sort($values);
        return $values;
    }
}
