<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceProcessingCheckpointState;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Canonical action path: requested -> processed -> accepted -> approved.
 * No single AI decision is sufficient. Each action requires three distinct checkpoints.
 */
final class WorkforceThreeStageProcessingService
{
    public function __construct(
        private readonly KnowledgeAuthorityPreflightService $knowledgeAuthority,
        private readonly WorkforceKnowledgeUncertaintyService $uncertainty,
        private readonly WorkforceDecisionChainService $decisionChain,
        private readonly WorkforceReviewerResolutionService $reviewerResolution,
        private readonly WorkforceActionReviewPacketService $reviewPackets,
        private readonly WorkforceProcessingLifecycleService $lifecycle,
        private readonly WorkforceDecisionChallengeService $challenges,
        private readonly WorkforceManagerEscalationService $managerEscalation,
        private readonly WorkforceAssuranceCouncilEscalationService $assuranceCouncil,
        private readonly WorkforceAdaptiveChainIntelligenceService $adaptive,
        private readonly WorkforcePredictiveChainFailureService $predictiveFailure,
        private readonly WorkforceChainLearningPolicyService $chainLearning,
        private readonly WorkforceCrossDomainFederationService $federation,
        private readonly WorkforceFederatedRecoveryService $federatedRecovery,
        private readonly WorkforceConcurrencyGuardService $concurrency,
        private readonly WorkforceChainPolicyAdminService $adminPolicy,
    ) {}

    public const STAGES = [
        1 => 'ORIGIN_REVIEW',       // originating employee/manager validates intent, evidence and authority
        2 => 'DOMAIN_PROCESSING',   // owning domain AI manager/specialist intercepts and processes the action
        3 => 'RECEIVING_ACCEPTANCE' // receiving domain AI manager/specialist validates state and accepts it
    ];

    public function begin(WorkforceTask $task, WorkforceMember $origin, array $request): string
    {
        $knowledgeReceipt = $this->knowledgeAuthority->resolve($task, $request);
        $processingId = (string) Str::uuid();
        $chain = $this->decisionChain->create($task, $origin, $processingId, $request, $knowledgeReceipt);
        $federation = $this->federation->attach($chain,$request);
        if($federation){
            $chain->forceFill(['metadata'=>array_merge((array)$chain->metadata,[
                'federation_uuid'=>$federation->federation_uuid,
                'federated_domain_path'=>$federation->domain_path,
                'federated_handoff_count'=>$federation->handoff_count,
            ])])->save();
        }
        foreach (self::STAGES as $stage => $key) {
            WorkforceProcessingCheckpoint::query()->create([
                'company_id'=>(int)$task->company_id,'task_id'=>$task->getKey(),'processing_id'=>$processingId,'stage'=>$stage,
                'stage_key'=>$key,'domain_key'=>$stage === 1 ? ($request['origin_domain'] ?? null) : ($stage === 2 ? ($request['processing_domain'] ?? null) : ($request['receiving_domain'] ?? null)),
                'reviewer_member_id'=>null,'reviewer_role'=>null,
                'status'=>WorkforceProcessingCheckpointState::Pending,
                'max_attempts'=>max(1,min(10,(int)($request['stage_max_attempts'] ?? 3))),
                'metadata'=>[
                    'request_fingerprint'=>hash('sha256', json_encode($request, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),
                    'knowledge_authority_receipt'=>$knowledgeReceipt,
                    'decision_chain_uuid'=>$chain->chain_uuid,
                    'decision_chain_contract_version'=>WorkforceDecisionChainService::CONTRACT_VERSION,
                    'proposed_by_member_id'=>$origin->getKey(),
                    'proposed_by_role'=>(string)$origin->role,
                    'timeout_minutes'=>max(1,min(1440,(int)($request['stage_timeout_minutes'] ?? 30))),
                ],
            ]);
        }
        $adaptive=$this->adaptive->profile($chain->refresh());
        $prediction=$this->predictiveFailure->predict($chain->refresh());
        $chain->forceFill(['metadata'=>array_merge((array)$chain->metadata,[
            'adaptive_profile_uuid'=>$adaptive->profile_uuid,
            'adaptive_depth'=>$adaptive->depth,
            'adaptive_uncertainty_score'=>$adaptive->uncertainty_score,
            'adaptive_consequence_score'=>$adaptive->consequence_score,
            'chain_failure_prediction_uuid'=>$prediction->prediction_uuid,
            'chain_failure_probability'=>$prediction->failure_probability,
            'chain_failure_risk_band'=>$prediction->risk_band,
            'mandatory_three_checks'=>true,
        ])])->save();

        return $processingId;
    }


    public function resolveReviewer(int $companyId, string $processingId, int $stage, array $requirements = []): WorkforceMember
    {
        $chain = \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)
            ->where('processing_id',$processingId)
            ->firstOrFail();

        $scopeKey=(string)($chain->task?->capability ?: '*');
        $companyPolicy=$this->adminPolicy->policy($companyId);
        $approvedLearning=$companyPolicy->allow_learned_policy
            ? $this->chainLearning->approvedPolicy($companyId,$scopeKey)
            : [];
        $learnedRequirements=[];
        foreach($approvedLearning as $policy){
            $learnedRequirements=array_merge($learnedRequirements,(array)$policy);
        }
        $requirements=array_merge(
            $this->adaptive->reviewerRequirements($chain,$stage),
            $this->predictiveFailure->requirements($chain),
            $learnedRequirements,
            $this->adminPolicy->requirements($chain),
            $requirements
        );
        $requirements['learned_policy_applied']=$learnedRequirements!==[];
        $requirements['learned_policy_source']='approved-only';

        $operation=$this->concurrency->begin(
            $companyId,
            'reviewer-resolution:'.$processingId.':stage:'.$stage,
            'REVIEWER_RESOLUTION',
            ['processing_id'=>$processingId,'stage'=>$stage,'requirements'=>$requirements]
        );
        if($operation['replayed']){
            $memberId=(int)$operation['ledger']->result_ref;
            $member=WorkforceMember::query()->forCompany($companyId)->find($memberId);
            if(!$member) throw new RuntimeException('REPLAYED_REVIEWER_RESOLUTION_MEMBER_MISSING');
            return $member;
        }

        try {
            $packet = $this->reviewPackets->buildForStage(
                $chain,
                $chain->task,
                $stage,
                (array) data_get($chain->metadata ?? [], 'request_snapshot', []),
                $requirements
            );
            $this->reviewPackets->verify($packet);

            $reviewer = $this->reviewerResolution->resolve($chain,$stage,$requirements);

            \Illuminate\Support\Facades\DB::transaction(function() use(
                $companyId,$processingId,$stage,$reviewer,$requirements,$packet,$operation
            ): void {
                $checkpoint = WorkforceProcessingCheckpoint::query()
                    ->forCompany($companyId)
                    ->where('processing_id',$processingId)
                    ->where('stage',$stage)
                    ->lockForUpdate()
                    ->firstOrFail();

                $existing=(int)data_get($checkpoint->metadata ?? [],'resolved_reviewer_member_id',0);
                if($existing>0 && $existing!==(int)$reviewer->getKey()){
                    throw new RuntimeException('REVIEWER_RESOLUTION_STALE_CONCURRENT_SELECTION');
                }

                $metadata=(array)($checkpoint->metadata ?? []);
                $metadata['resolved_reviewer_member_id']=$reviewer->getKey();
                $metadata['resolved_reviewer_role_definition_id']=$reviewer->role_definition_id;
                $metadata['reviewer_resolution']='role-responsibility-engine+adaptive-chain-intelligence+concurrency-guard';
                $metadata['reviewer_requirements']=$requirements;
                $metadata['adaptive_depth']=$requirements['adaptive_depth'] ?? 'STANDARD';
                $metadata['prediction_risk_band']=$requirements['prediction_risk_band'] ?? 'NORMAL';
                if(!empty($requirements['shorter_stage_timeout_minutes'])){
                    $metadata['timeout_minutes']=min(
                        (int)($metadata['timeout_minutes'] ?? 30),
                        (int)$requirements['shorter_stage_timeout_minutes']
                    );
                }
                $metadata['action_review_packet_id']=$packet->getKey();
                $metadata['action_review_packet_version']=$packet->packet_version;
                $metadata['action_review_packet_sha256']=$packet->packet_sha256;
                $checkpoint->forceFill([
                    'metadata'=>$metadata,
                    'revision'=>(int)$checkpoint->revision+1,
                ])->save();
            },3);

            $this->concurrency->complete(
                $operation['ledger'],
                'workforce_member',
                (string)$reviewer->getKey(),
                ['member_id'=>$reviewer->getKey(),'stage'=>$stage,'packet_sha256'=>$packet->packet_sha256]
            );
            return $reviewer;
        } catch (\Throwable $e) {
            $this->concurrency->fail($operation['ledger'],$e->getMessage());
            throw $e;
        }
    }

    public function decideResolved(int $companyId, string $processingId, int $stage, bool $passes, array $decision = [], array $requirements = []): WorkforceProcessingCheckpoint
    {
        $reviewer=$this->resolveReviewer($companyId,$processingId,$stage,$requirements);
        $checkpoint=WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
        $decision['expected_packet_sha256']=(string)data_get($checkpoint->metadata ?? [],'action_review_packet_sha256','');
        return $this->decide($companyId,$processingId,$stage,$reviewer,$passes,$decision);
    }

    public function decide(int $companyId, string $processingId, int $stage, WorkforceMember $reviewer, bool $passes, array $decision = []): WorkforceProcessingCheckpoint
    {
        $checkpoint = WorkforceProcessingCheckpoint::query()->forCompany($companyId)->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
        $chain = \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$processingId)->firstOrFail();
        $adminRequirements=$this->adminPolicy->requirements($chain);
        if(($adminRequirements['admin_hold'] ?? false)===true){
            throw new RuntimeException('CHAIN_PAUSED_BY_GOVERNED_ADMIN_HOLD');
        }
        if ($stage > 1) {
            $previous = WorkforceProcessingCheckpoint::query()->forCompany($companyId)->where('processing_id',$processingId)->where('stage',$stage-1)->first();
            if (! $previous || $previous->status !== WorkforceProcessingCheckpointState::Passed) throw new RuntimeException('PREVIOUS_AI_PROCESSING_CHECK_NOT_PASSED');
        }
        if ($checkpoint->reviewer_member_id && (int)$checkpoint->reviewer_member_id === (int)$reviewer->getKey() && $stage > 1) throw new RuntimeException('PROCESSING_REVIEW_REQUIRES_DISTINCT_AI_REVIEWER');
        $checkpoint = $this->lifecycle->claim(
            $checkpoint,
            $reviewer,
            (int) data_get($checkpoint->metadata ?? [], 'timeout_minutes', 30)
        );

        $packet = $this->reviewPackets->buildForStage(
            $chain,
            $chain->task,
            $stage,
            (array) data_get($chain->metadata ?? [], 'request_snapshot', []),
            (array) data_get($checkpoint->metadata ?? [], 'reviewer_requirements', [])
        );
        $this->reviewPackets->verify($packet);

        $expectedPacketHash=(string)data_get($checkpoint->metadata ?? [],'action_review_packet_sha256','');
        if($expectedPacketHash!=='' && !hash_equals($expectedPacketHash,(string)$packet->packet_sha256)) {
            throw new RuntimeException('STALE_REVIEW_PACKET_REJECTED');
        }

        $operation=$this->concurrency->begin(
            $companyId,
            'review:'.$processingId.':stage:'.$stage,
            'REVIEW_DECISION',
            [
                'processing_id'=>$processingId,'stage'=>$stage,'reviewer_member_id'=>$reviewer->getKey(),
                'passes'=>$passes,'decision'=>$decision,'packet_sha256'=>$packet->packet_sha256,
                'checkpoint_revision'=>(int)$checkpoint->revision,
            ]
        );
        if($operation['replayed']){
            return WorkforceProcessingCheckpoint::query()->forCompany($companyId)
                ->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
        }

        $this->decisionChain->assertReviewerEligible($chain,$stage,$reviewer);
        $gapReceipt = $this->uncertainty->captureDecisionUncertainty(
            $checkpoint->task,
            $reviewer,
            $processingId,
            $stage,
            array_merge($decision,['domain'=>$checkpoint->domain_key])
        );
        if ($gapReceipt !== null) {
            $decision['knowledge_gap_receipt']=$gapReceipt;
        }
        $decision['action_review_packet']=[
            'packet_id'=>$packet->getKey(),
            'packet_version'=>$packet->packet_version,
            'packet_sha256'=>$packet->packet_sha256,
            'sealed_at'=>$packet->sealed_at?->toISOString(),
        ];
        $checkpoint->forceFill([
            'reviewer_member_id'=>$reviewer->getKey(),
            'reviewer_role'=>(string)$reviewer->role,
            'decision'=>$decision,
        ])->save();

        if($passes && $stage===3
            && (($adminRequirements['require_manual_review'] ?? false)===true
                || ($adminRequirements['admin_require_manual_review'] ?? false)===true)
            && trim((string)($decision['manual_review_receipt'] ?? ''))===''){
            $checkpoint=$this->lifecycle->transition(
                $checkpoint,
                WorkforceProcessingCheckpointState::NeedsInfo,
                $reviewer,
                'governed-admin-policy-requires-manual-review',
                ['required'=>'manual_review_receipt']
            );
            return $checkpoint;
        }

        // Predictive failure prevention strengthens evidence requirements before a stage may pass.
        if ($passes) {
            $predictiveRequirements=array_merge(
                $this->predictiveFailure->requirements($chain),
                $adminRequirements
            );
            $requestSnapshot=(array)data_get($chain->metadata ?? [],'request_snapshot',[]);
            $missingPredictiveEvidence=[];

            if (($predictiveRequirements['require_explicit_evidence_refs'] ?? false)===true
                && (array)($decision['evidence_refs'] ?? $decision['knowledge_evidence'] ?? [])===[]) {
                $missingPredictiveEvidence[]='explicit_evidence_refs';
            }
            if (($predictiveRequirements['require_knowledge_authority_receipt'] ?? true)===true
                && (array)($chain->knowledge_receipt ?? [])===[]) {
                $missingPredictiveEvidence[]='knowledge_authority_receipt';
            }
            if (($predictiveRequirements['require_assumptions_declaration'] ?? false)===true
                && !array_key_exists('assumptions',$requestSnapshot)) {
                $missingPredictiveEvidence[]='assumptions_declaration';
            }
            if (($predictiveRequirements['require_unresolved_questions_declaration'] ?? false)===true
                && !array_key_exists('unresolved_questions',$requestSnapshot)) {
                $missingPredictiveEvidence[]='unresolved_questions_declaration';
            }

            if ($missingPredictiveEvidence!==[]) {
                $decision['predictive_failure_prevention']=[
                    'risk_band'=>$predictiveRequirements['prediction_risk_band'] ?? 'NORMAL',
                    'missing_requirements'=>$missingPredictiveEvidence,
                ];
                $checkpoint->forceFill(['decision'=>$decision])->save();
                $checkpoint=$this->lifecycle->transition(
                    $checkpoint,
                    WorkforceProcessingCheckpointState::NeedsInfo,
                    $reviewer,
                    'predictive-chain-failure-prevention-missing-evidence',
                    ['missing_requirements'=>$missingPredictiveEvidence]
                );
                $this->concurrency->complete(
                    $operation['ledger'],'processing_checkpoint',(string)$checkpoint->checkpoint_uuid,
                    ['status'=>$checkpoint->status->value,'revision'=>(int)$checkpoint->revision]
                );
                return $checkpoint;
            }
        }

        // Adaptive depth may add Assurance / Model Council scrutiny, but never removes a core stage.
        if ($passes && $stage===3) {
            $adaptiveContext=array_merge(
                $this->adaptive->escalationContext($chain),
                $adminRequirements
            );
            if (($adaptiveContext['force_assurance'] ?? false)===true) {
                $adaptiveReview=$this->assuranceCouncil->review($chain,$checkpoint,null,$adaptiveContext);
                $decision['adaptive_assurance']=[
                    'review_uuid'=>$adaptiveReview->review_uuid,
                    'assurance_status'=>$adaptiveReview->assurance_status,
                    'model_council_required'=>$adaptiveReview->model_council_required,
                    'council_status'=>$adaptiveReview->council_status,
                    'final_status'=>$adaptiveReview->final_status,
                ];
                $checkpoint->forceFill(['decision'=>$decision])->save();

                if (in_array((string)$adaptiveReview->final_status,[
                    'BLOCKED_ASSURANCE_UNAVAILABLE',
                    'BLOCKED_COUNCIL_UNRESOLVED',
                    'COUNCIL_ESCALATION_REQUIRED',
                    'ASSURANCE_REVIEW_REQUIRED',
                ],true)) {
                    $checkpoint=$this->lifecycle->transition(
                        $checkpoint,
                        WorkforceProcessingCheckpointState::Escalated,
                        $reviewer,
                        'adaptive-chain-preapproval-review-requires-escalation',
                        ['adaptive_assurance'=>$decision['adaptive_assurance']]
                    );
                    $this->concurrency->complete(
                        $operation['ledger'],'processing_checkpoint',(string)$checkpoint->checkpoint_uuid,
                        ['status'=>$checkpoint->status->value,'revision'=>(int)$checkpoint->revision]
                    );
                    return $checkpoint;
                }
            }
        }

        $checkpoint = $this->lifecycle->transition(
            $checkpoint,
            $passes ? WorkforceProcessingCheckpointState::Passed : WorkforceProcessingCheckpointState::Rejected,
            $reviewer,
            (string)($decision['reason'] ?? ''),
            ['decision'=>$decision]
        );

        $updatedChain=$this->decisionChain->recordStageDecision($chain,$checkpoint,$reviewer,$passes,$decision);
        if($passes && $stage===3){
            $this->federation->markCoreStagesAccepted($updatedChain->refresh());
        }
        $this->concurrency->complete(
            $operation['ledger'],
            'processing_checkpoint',
            (string)$checkpoint->checkpoint_uuid,
            ['status'=>$checkpoint->status->value,'revision'=>(int)$checkpoint->revision]
        );
        return $checkpoint->refresh();
    }

    public function needsInfo(int $companyId, string $processingId, int $stage, WorkforceMember $reviewer, string $reason, array $questions = []): WorkforceProcessingCheckpoint
    {
        $checkpoint=$this->activeCheckpoint($companyId,$processingId,$stage,$reviewer);
        return $this->lifecycle->transition($checkpoint,WorkforceProcessingCheckpointState::NeedsInfo,$reviewer,$reason,[
            'unresolved_questions'=>array_values($questions),
        ]);
    }

    public function disagree(
        int $companyId,
        string $processingId,
        int $stage,
        WorkforceMember $reviewer,
        string $reason,
        array $disputedClaims = [],
        array $evidenceChallenges = [],
        array $authorityChallenges = [],
        ?float $confidence = null,
        array $requestedInformation = []
    ): WorkforceProcessingCheckpoint {
        $checkpoint=$this->activeCheckpoint($companyId,$processingId,$stage,$reviewer);
        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$processingId)->firstOrFail();

        $challenge=$this->challenges->open($chain,$checkpoint,$reviewer,[
            'reason'=>$reason,
            'disputed_claims'=>array_values($disputedClaims),
            'evidence_challenges'=>array_values($evidenceChallenges),
            'authority_challenges'=>array_values($authorityChallenges),
            'confidence'=>$confidence,
            'requested_information'=>array_values($requestedInformation),
        ]);

        return WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
    }

    public function rebutChallenge(int $companyId, string $challengeUuid, WorkforceMember $respondent, array $rebuttal): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge
    {
        $challenge=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge::query()
            ->forCompany($companyId)->where('challenge_uuid',$challengeUuid)->firstOrFail();
        return $this->challenges->rebut($challenge,$respondent,$rebuttal);
    }

    public function resolveChallenge(int $companyId, string $challengeUuid, WorkforceMember $challenger, bool $acceptRebuttal, array $resolution = []): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge
    {
        $challenge=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge::query()
            ->forCompany($companyId)->where('challenge_uuid',$challengeUuid)->firstOrFail();
        return $this->challenges->resolve($challenge,$challenger,$acceptRebuttal,$resolution);
    }

    public function escalate(int $companyId, string $processingId, int $stage, WorkforceMember $reviewer, string $reason, array $evidence = []): WorkforceProcessingCheckpoint
    {
        $checkpoint=$this->activeCheckpoint($companyId,$processingId,$stage,$reviewer);
        $checkpoint=$this->lifecycle->transition($checkpoint,WorkforceProcessingCheckpointState::Escalated,$reviewer,$reason,$evidence);

        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$processingId)->firstOrFail();
        $escalation=$this->managerEscalation->resolve(
            $chain,$checkpoint,$reviewer,'MANUAL_STAGE_ESCALATION',
            array_merge($evidence,['reason'=>$reason])
        );

        $metadata=(array)($checkpoint->metadata ?? []);
        $metadata['manager_escalation_uuid']=$escalation->escalation_uuid;
        $metadata['escalation_assigned_to_member_id']=$escalation->assigned_to_member_id;
        $metadata['escalation_level']=$escalation->level;

        $review=$this->assuranceCouncil->review(
            $chain,$checkpoint,$escalation,
            array_merge(
                $evidence,
                $this->adaptive->escalationContext($chain),
                $this->predictiveFailure->requirements($chain),
                [
                    'business_value'=>$escalation->business_value,
                    'urgency_score'=>$escalation->urgency_score,
                    'disagreement_count'=>$escalation->disagreement_count,
                ]
            )
        );
        $metadata['assurance_council_review_uuid']=$review->review_uuid;
        $metadata['assurance_status']=$review->assurance_status;
        $metadata['model_council_required']=$review->model_council_required;
        $metadata['council_status']=$review->council_status;
        $metadata['assurance_council_final_status']=$review->final_status;

        $checkpoint->forceFill(['metadata'=>$metadata])->save();

        return $checkpoint->refresh();
    }

    public function supersede(int $companyId, string $processingId, int $stage, ?WorkforceMember $actor, string $reason): WorkforceProcessingCheckpoint
    {
        $checkpoint=WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
        return $this->lifecycle->transition($checkpoint,WorkforceProcessingCheckpointState::Superseded,$actor,$reason);
    }

    private function activeCheckpoint(int $companyId,string $processingId,int $stage,WorkforceMember $reviewer): WorkforceProcessingCheckpoint
    {
        $checkpoint=WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->where('processing_id',$processingId)->where('stage',$stage)->firstOrFail();
        if ($checkpoint->status !== WorkforceProcessingCheckpointState::Processing) {
            $checkpoint=$this->lifecycle->claim($checkpoint,$reviewer,(int)data_get($checkpoint->metadata ?? [],'timeout_minutes',30));
        } elseif ((int)$checkpoint->owner_member_id !== (int)$reviewer->getKey()) {
            throw new RuntimeException('PROCESSING_STAGE_OWNED_BY_DIFFERENT_REVIEWER');
        }
        return $checkpoint;
    }

    public function acceptFederatedHandoff(
        int $companyId,
        string $processingId,
        WorkforceMember $reviewer,
        array $incomingState,
        array $acceptance
    ): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDomainHandoff {
        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$processingId)->firstOrFail();
        return $this->federation->acceptNext($chain,$reviewer,$incomingState,$acceptance);
    }

    public function rejectFederatedHandoff(
        int $companyId,
        string $processingId,
        WorkforceMember $reviewer,
        string $reason,
        array $evidenceRefs=[],
        ?string $expectedHandoffUuid=null,
        ?string $operationKey=null
    ): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceDomainHandoff {
        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$processingId)->firstOrFail();
        return $this->federation->rejectNext(
            $chain,$reviewer,$reason,$evidenceRefs,$expectedHandoffUuid,$operationKey
        );
    }

    public function linkRecoveryCompensationChain(
        int $companyId,
        string $recoveryStepUuid,
        string $compensationProcessingId
    ): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep {
        $step=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep::query()
            ->forCompany($companyId)->where('recovery_step_uuid',$recoveryStepUuid)->firstOrFail();
        $chain=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain::query()
            ->forCompany($companyId)->where('processing_id',$compensationProcessingId)->firstOrFail();
        return $this->federatedRecovery->linkCompensationChain($step,$chain);
    }

    public function verifyRecoveryCompensation(
        int $companyId,
        string $recoveryStepUuid,
        array $receipt,
        array $verification
    ): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep {
        $step=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep::query()
            ->forCompany($companyId)->where('recovery_step_uuid',$recoveryStepUuid)->firstOrFail();
        return $this->federatedRecovery->verifyCompensation($step,$receipt,$verification);
    }

    public function failRecoveryCompensation(
        int $companyId,
        string $recoveryStepUuid,
        string $reason,
        bool $manualRequired=true
    ): \App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep {
        $step=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep::query()
            ->forCompany($companyId)->where('recovery_step_uuid',$recoveryStepUuid)->firstOrFail();
        return $this->federatedRecovery->failStep($step,$reason,$manualRequired);
    }

    public function isApproved(int $companyId, string $processingId): bool
    {
        return $this->decisionChain->isOrganisationallyApproved($companyId,$processingId);
    }
}
