<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainLearningRecommendation extends Model
{
    protected $table='ext_titan_ai_workforce_chain_learning_recommendations';
    protected $guarded=[];
    protected $casts=[
        'confidence'=>'decimal:2','sample_size'=>'integer','current_policy'=>'array',
        'recommended_policy'=>'array','evidence'=>'array','expected_effect'=>'array',
        'approved_at'=>'datetime','rejected_at'=>'datetime','generated_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
