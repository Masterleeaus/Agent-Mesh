<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFederation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDomainHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceFederatedRecoveryService
{
    public function planForRejectedHandoff(
        WorkforceDecisionChain $rootChain,
        WorkforceChainFederation $federation,
        WorkforceDomainHandoff $failedHandoff,
        array $triggerEvidence=[]
    ): ?WorkforceRecoveryPlan {
        $accepted=WorkforceDomainHandoff::query()->forCompany((int)$rootChain->company_id)
            ->where('federation_id',$federation->getKey())
            ->where('status','ACCEPTED')
            ->where('sequence','<',$failedHandoff->sequence)
            ->orderByDesc('sequence')->get();

        if($accepted->isEmpty()) return null;

        return DB::transaction(function() use($rootChain,$federation,$failedHandoff,$triggerEvidence,$accepted){
            $existing=WorkforceRecoveryPlan::query()->forCompany((int)$rootChain->company_id)
                ->where('root_decision_chain_id',$rootChain->getKey())
                ->where('trigger_handoff_id',$failedHandoff->getKey())
                ->lockForUpdate()->first();
            if($existing) return $existing;

            $plan=WorkforceRecoveryPlan::query()->create([
                'recovery_uuid'=>(string)Str::uuid(),
                'company_id'=>(int)$rootChain->company_id,
                'root_decision_chain_id'=>$rootChain->getKey(),
                'root_processing_id'=>$rootChain->processing_id,
                'federation_id'=>$federation->getKey(),
                'trigger_handoff_id'=>$failedHandoff->getKey(),
                'trigger_type'=>'FEDERATED_HANDOFF_REJECTED_AFTER_PARTIAL_ACCEPTANCE',
                'status'=>'PROPOSED',
                'step_count'=>$accepted->count(),
                'verified_step_count'=>0,
                'manual_intervention_required'=>false,
                'trigger_evidence'=>array_merge($triggerEvidence,[
                    'failed_handoff_uuid'=>$failedHandoff->handoff_uuid,
                    'failed_sequence'=>$failedHandoff->sequence,
                    'failed_from_domain'=>$failedHandoff->from_domain,
                    'failed_to_domain'=>$failedHandoff->to_domain,
                ]),
                'opened_at'=>now(),
            ]);

            $sequence=1;
            $manual=false;
            foreach($accepted as $handoff){
                [$strategy,$capability,$action]=$this->strategyFor($handoff,$rootChain);
                if($strategy==='MANUAL_REPAIR') $manual=true;

                WorkforceRecoveryStep::query()->create([
                    'recovery_step_uuid'=>(string)Str::uuid(),
                    'company_id'=>(int)$rootChain->company_id,
                    'recovery_plan_id'=>$plan->getKey(),
                    'sequence'=>$sequence++,
                    'source_handoff_id'=>$handoff->getKey(),
                    'domain'=>$handoff->to_domain,
                    'strategy'=>$strategy,
                    'status'=>$strategy==='MANUAL_REPAIR'?'MANUAL_REQUIRED':'PROPOSED',
                    'compensation_capability'=>$capability,
                    'proposed_action'=>$action,
                    'proposed_at'=>now(),
                ]);
            }

            if($manual){
                $plan->forceFill([
                    'manual_intervention_required'=>true,
                    'status'=>'MANUAL_REQUIRED',
                ])->save();
            }

            $rootChain->forceFill(['metadata'=>array_merge((array)$rootChain->metadata,[
                'recovery_required'=>true,
                'recovery_uuid'=>$plan->recovery_uuid,
                'recovery_status'=>$plan->status,
            ])])->save();

            return $plan->refresh();
        },3);
    }

    public function linkCompensationChain(
        WorkforceRecoveryStep $step,
        WorkforceDecisionChain $compensationChain
    ): WorkforceRecoveryStep {
        $step=WorkforceRecoveryStep::query()->forCompany((int)$step->company_id)
            ->whereKey($step->getKey())->lockForUpdate()->firstOrFail();

        if($step->status==='PROCESSING'){
            if((int)$step->compensation_decision_chain_id===(int)$compensationChain->getKey()) return $step;
            throw new RuntimeException('RECOVERY_STEP_ALREADY_LINKED_TO_DIFFERENT_CHAIN');
        }
        if($step->status==='VERIFIED'){
            if((int)$step->compensation_decision_chain_id===(int)$compensationChain->getKey()) return $step;
            throw new RuntimeException('RECOVERY_STEP_ALREADY_VERIFIED_WITH_DIFFERENT_CHAIN');
        }

        if((int)$step->company_id !== (int)$compensationChain->company_id) {
            throw new RuntimeException('RECOVERY_COMPENSATION_COMPANY_MISMATCH');
        }
        if($step->status!=='PROPOSED') throw new RuntimeException('RECOVERY_STEP_NOT_PROPOSABLE');

        if((int)$step->sequence>1){
            $prior=WorkforceRecoveryStep::query()->forCompany((int)$step->company_id)
                ->where('recovery_plan_id',$step->recovery_plan_id)
                ->where('sequence',(int)$step->sequence-1)->first();
            if(!$prior || $prior->status!=='VERIFIED'){
                throw new RuntimeException('RECOVERY_STEPS_MUST_VERIFY_IN_REVERSE_DEPENDENCY_ORDER');
            }
        }

        if(!$compensationChain->consequential) throw new RuntimeException('RECOVERY_COMPENSATION_MUST_BE_CONSEQUENTIAL');

        $step->forceFill([
            'status'=>'PROCESSING',
            'compensation_processing_id'=>$compensationChain->processing_id,
            'compensation_decision_chain_id'=>$compensationChain->getKey(),
            'approval_evidence'=>[
                'decision_chain_uuid'=>$compensationChain->chain_uuid,
                'processing_id'=>$compensationChain->processing_id,
                'mandatory_three_checks'=>true,
            ],
            'operation_key'=>'recovery-link:'.$step->recovery_step_uuid.':'.$compensationChain->processing_id,
            'revision'=>(int)$step->revision+1,
        ])->save();

        $this->refreshPlan($step->recovery_plan_id,(int)$step->company_id);
        return $step->refresh();
    }

    /** @param array<string,mixed> $receipt @param array<string,mixed> $verification */
    public function verifyCompensation(
        WorkforceRecoveryStep $step,
        array $receipt,
        array $verification
    ): WorkforceRecoveryStep {
        $step=WorkforceRecoveryStep::query()->forCompany((int)$step->company_id)
            ->whereKey($step->getKey())->lockForUpdate()->firstOrFail();
        $receiptHash=$this->sha($receipt);
        $verificationHash=$this->sha($verification);

        if($step->status==='VERIFIED'){
            if(hash_equals((string)$step->receipt_sha256,$receiptHash)
                && hash_equals((string)$step->verification_sha256,$verificationHash)) return $step;
            throw new RuntimeException('RECOVERY_VERIFICATION_REPLAY_PAYLOAD_MISMATCH');
        }

        if($step->status!=='PROCESSING') throw new RuntimeException('RECOVERY_STEP_NOT_PROCESSING');
        if(!$step->compensation_decision_chain_id) throw new RuntimeException('RECOVERY_STEP_COMPENSATION_CHAIN_MISSING');

        $chain=WorkforceDecisionChain::query()->forCompany((int)$step->company_id)
            ->findOrFail($step->compensation_decision_chain_id);
        if(!$chain->organisationally_approved || !$chain->authority_gates_ready) {
            throw new RuntimeException('RECOVERY_COMPENSATION_CHAIN_NOT_ORGANISATIONALLY_APPROVED');
        }

        $gate=WorkforceFinalAuthorityGate::query()->forCompany((int)$step->company_id)
            ->where('processing_id',$chain->processing_id)->first();
        if(!$gate || !$gate->final_allowed) {
            throw new RuntimeException('RECOVERY_COMPENSATION_FINAL_AUTHORITY_NOT_GRANTED');
        }
        if(($verification['verified'] ?? false)!==true) {
            throw new RuntimeException('RECOVERY_COMPENSATION_NOT_VERIFIED');
        }
        if($receipt===[]) throw new RuntimeException('RECOVERY_COMPENSATION_RECEIPT_REQUIRED');

        $step->forceFill([
            'status'=>'VERIFIED',
            'execution_receipt'=>$receipt,
            'verification'=>$verification,
            'receipt_sha256'=>$receiptHash,
            'verification_sha256'=>$verificationHash,
            'operation_key'=>'recovery-verify:'.$step->recovery_step_uuid,
            'revision'=>(int)$step->revision+1,
            'verified_at'=>now(),
        ])->save();

        $this->refreshPlan($step->recovery_plan_id,(int)$step->company_id);
        return $step->refresh();
    }

    public function failStep(WorkforceRecoveryStep $step,string $reason,bool $manualRequired=true): WorkforceRecoveryStep
    {
        if(trim($reason)==='') throw new RuntimeException('RECOVERY_FAILURE_REASON_REQUIRED');
        $step->forceFill([
            'status'=>$manualRequired?'MANUAL_REQUIRED':'FAILED',
            'failure_reason'=>$reason,
        ])->save();
        $this->refreshPlan($step->recovery_plan_id,(int)$step->company_id);
        return $step->refresh();
    }

    private function refreshPlan(int $planId,int $companyId): void
    {
        $plan=WorkforceRecoveryPlan::query()->forCompany($companyId)->findOrFail($planId);
        $steps=WorkforceRecoveryStep::query()->forCompany($companyId)
            ->where('recovery_plan_id',$planId)->orderBy('sequence')->get();
        $verified=$steps->where('status','VERIFIED')->count();
        $manual=$steps->where('status','MANUAL_REQUIRED')->isNotEmpty();
        $failed=$steps->where('status','FAILED')->isNotEmpty();
        $complete=$verified===$steps->count() && $steps->isNotEmpty();

        $status=$complete?'COMPLETED':($manual?'MANUAL_REQUIRED':($failed?'FAILED':
            ($steps->where('status','PROCESSING')->isNotEmpty()?'PROCESSING':'PROPOSED')));

        $plan->forceFill([
            'verified_step_count'=>$verified,
            'manual_intervention_required'=>$manual,
            'status'=>$status,
            'completed_at'=>$complete?now():null,
        ])->save();

        $root=WorkforceDecisionChain::query()->forCompany($companyId)->find($plan->root_decision_chain_id);
        if($root){
            $root->forceFill(['metadata'=>array_merge((array)$root->metadata,[
                'recovery_required'=>!$complete,
                'recovery_uuid'=>$plan->recovery_uuid,
                'recovery_status'=>$status,
                'recovery_verified_steps'=>$verified,
                'recovery_total_steps'=>$steps->count(),
            ])])->save();
        }
    }

    private function strategyFor(WorkforceDomainHandoff $handoff,WorkforceDecisionChain $root): array
    {
        $acceptance=(array)($handoff->acceptance ?? []);
        $incoming=(array)($handoff->incoming_state ?? []);

        $strategy=strtoupper((string)(
            data_get($acceptance,'recovery.strategy')
            ?? data_get($incoming,'recovery.strategy')
            ?? 'MANUAL_REPAIR'
        ));
        if(!in_array($strategy,['REVERSE','COMPENSATE','REPAIR','MANUAL_REPAIR'],true)) $strategy='MANUAL_REPAIR';

        $capability=(string)(
            data_get($acceptance,'recovery.capability')
            ?? data_get($incoming,'recovery.capability')
            ?? ''
        );
        if($strategy!=='MANUAL_REPAIR' && $capability==='') $strategy='MANUAL_REPAIR';

        $action=[
            'root_processing_id'=>$root->processing_id,
            'root_chain_uuid'=>$root->chain_uuid,
            'source_handoff_uuid'=>$handoff->handoff_uuid,
            'source_domain'=>$handoff->from_domain,
            'affected_domain'=>$handoff->to_domain,
            'strategy'=>$strategy,
            'capability'=>$capability!==''?$capability:null,
            'original_incoming_state_sha256'=>$handoff->incoming_state_sha256,
            'original_acceptance_sha256'=>$handoff->acceptance_sha256,
            'reason'=>'Compensate or repair previously accepted state after a later federated handoff failed.',
            'must_process_through_full_chain'=>true,
            'must_receive_final_authority'=>true,
            'must_verify_result'=>true,
        ];

        return [$strategy,$capability!==''?$capability:null,$action];
    }

    private function sha(array $payload): string
    {
        $normalize=function($v) use (&$normalize){
            if(!is_array($v)) return $v;
            if(array_is_list($v)) return array_map($normalize,$v);
            ksort($v,SORT_STRING);
            foreach($v as $k=>$x)$v[$k]=$normalize($x);
            return $v;
        };
        return hash('sha256',json_encode($normalize($payload),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
