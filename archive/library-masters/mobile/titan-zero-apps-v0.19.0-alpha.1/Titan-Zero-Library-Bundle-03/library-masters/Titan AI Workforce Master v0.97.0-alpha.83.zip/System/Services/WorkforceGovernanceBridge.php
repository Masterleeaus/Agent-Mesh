<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Throwable;

final class WorkforceGovernanceBridge
{
    public function __construct(
        private readonly WorkforceAutonomyService $autonomy,
        private readonly WorkforcePreExecutionGovernanceService $preExecution,
        private readonly WorkforceCapabilityBindingRegistry $manifests,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    /** @return array<string,mixed> */
    public function evaluate(WorkforceTask $task, WorkforceMember $actor): array
    {
        $external = $this->preExecution->evaluate($task, $actor);
        $autonomy = $this->autonomy->decide($task, $actor, $external);

        $councilRequired = (bool) data_get($external, 'model_council.required', false);
        $availability = [
            'risk' => (bool) data_get($external, 'risk.available', false),
            'assurance' => (bool) data_get($external, 'assurance.available', false),
            'governance' => (bool) data_get($autonomy, 'governance_constraint.available', false),
            'autonomy' => (bool) ($autonomy['available'] ?? false),
            'model_council' => ! $councilRequired || ((bool) data_get($external, 'model_council.available', false) && (bool) data_get($external, 'model_council.consulted', false)),
        ];

        return array_merge($external, [
            'autonomy' => $autonomy,
            'engine_availability' => $availability,
            'governance_complete' => ($external['governance_complete'] ?? false) === true && ! in_array(false, $availability, true),
        ]);
    }

    /** @return array<string,mixed> */
    public function prepareInteraction(WorkforceTask $task, WorkforceMember $actor, array $governance = []): array
    {
        $missingEvidence = array_values(array_map('strval', is_array($governance['missing_evidence'] ?? null) ? $governance['missing_evidence'] : []));
        $workflowRef = $this->workflowRef($task, $actor);
        $evidenceCollection = $missingEvidence !== [];

        if ($workflowRef === null && $evidenceCollection) {
            return [
                'required' => true,
                'available' => false,
                'prepared' => false,
                'evidence_collection' => true,
                'interaction_workflow_ref' => null,
                'workflow_ref' => null,
                'missing_evidence' => $missingEvidence,
                'reason' => 'Required evidence is missing and the owning extension does not provide an Interaction evidence-collection workflow.',
            ];
        }
        if ($workflowRef === null) {
            return ['required' => false, 'available' => true, 'prepared' => true, 'evidence_collection' => false, 'interaction_workflow_ref' => null, 'workflow_ref' => null, 'missing_evidence' => []];
        }

        foreach (['titan.interaction-engine','titan.interaction'] as $binding) {
            if (! app()->bound($binding)) continue;
            $service = app($binding);
            foreach (['prepareForWorkforce','prepare','resolve'] as $method) {
                if (! method_exists($service, $method)) continue;
                try {
                    $result = $service->{$method}([
                        'workflow_ref' => $workflowRef,
                        'interaction_workflow_ref' => $workflowRef,
                        'evidence_collection' => $evidenceCollection,
                        'required_evidence' => $governance['required_evidence'] ?? [],
                        'missing_evidence' => $missingEvidence,
                        'evidence_refs' => $governance['evidence_refs'] ?? [],
                        'envelope' => $this->envelope($task, $actor),
                    ]);
                } catch (Throwable $e) {
                    return [
                        'required' => true,
                        'available' => false,
                        'prepared' => false,
                        'evidence_collection' => $evidenceCollection,
                        'interaction_workflow_ref' => $workflowRef,
                        'workflow_ref' => $workflowRef,
                        'missing_evidence' => $missingEvidence,
                        'binding' => $binding,
                        'method' => $method,
                        'reason' => 'Titan Interaction Engine failed while preparing the referenced workflow.',
                        'error' => mb_substr($e->getMessage(), 0, 1000),
                    ];
                }
                if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
                if (is_array($result)) {
                    return array_merge([
                        'required' => true,
                        'available' => true,
                        'prepared' => (bool) ($result['prepared'] ?? $result['ready'] ?? true),
                        'evidence_collection' => $evidenceCollection,
                        'interaction_workflow_ref' => $workflowRef,
                        'workflow_ref' => $workflowRef,
                        'missing_evidence' => $missingEvidence,
                        'binding' => $binding,
                        'method' => $method,
                    ], $result);
                }
                return [
                    'required' => true,
                    'available' => true,
                    'prepared' => true,
                    'evidence_collection' => $evidenceCollection,
                    'interaction_workflow_ref' => $workflowRef,
                    'workflow_ref' => $workflowRef,
                    'missing_evidence' => $missingEvidence,
                    'binding' => $binding,
                    'method' => $method,
                    'result' => $result,
                ];
            }
        }

        return [
            'required' => true,
            'available' => false,
            'prepared' => false,
            'evidence_collection' => $evidenceCollection,
            'interaction_workflow_ref' => $workflowRef,
            'workflow_ref' => $workflowRef,
            'missing_evidence' => $missingEvidence,
            'reason' => 'Referenced Interaction workflow cannot be prepared because Titan Interaction Engine is unavailable.',
        ];
    }

    public function command(WorkforceTask $task, WorkforceMember $actor, array $request, array $executionContext = []): array
    {
        $envelope = array_merge($this->envelope($task, $actor), [
            'command' => $request,
            'intent_id' => $executionContext['intent_id'] ?? null,
            'intent_sha256' => $executionContext['intent_sha256'] ?? null,
            'state_fingerprint' => $executionContext['state_fingerprint'] ?? null,
            'idempotency_key' => $executionContext['idempotency_key'] ?? null,
            'expected_state' => $executionContext['expected_state'] ?? null,
            'knowledge_preflight' => is_array($task->knowledge_preflight ?? null) ? $task->knowledge_preflight : [],
            'knowledge_context_receipt_id' => data_get($task->knowledge_preflight ?? [], 'receipt_hash'),
            'provenance_refs' => array_values(array_unique(array_merge(
                (array) data_get($task->knowledge_preflight ?? [], 'source_keys', []),
                (array) data_get($task->knowledge_preflight ?? [], 'claim_keys', []),
            ))),
            'independent_review' => data_get($task->governance ?? [], 'pre_execution.independent_review', []),
        ]);
        $resolved = $this->controlPlane->resolve('command_bus');
        if ($resolved === null) {
            return ['executed' => false, 'blocked' => true, 'reason' => 'Titan Command Bus is unavailable.', 'receipt' => null];
        }
        $bus = $resolved['service'];
        foreach ($this->controlPlane->methodsFor('command_bus') as $method) {
            if (method_exists($bus, $method)) {
                try {
                    $result = $bus->{$method}($envelope);
                } catch (Throwable $e) {
                    return ['executed' => false, 'uncertain' => true, 'blocked' => false, 'reason' => 'Command Bus dispatch outcome is uncertain; reconcile by idempotency key before any retry.', 'error' => mb_substr($e->getMessage(), 0, 1000), 'receipt' => null];
                }
                if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
                return is_array($result) ? $result : ['executed' => true, 'receipt' => $result];
            }
        }
        return ['executed' => false, 'blocked' => true, 'reason' => 'Titan Command Bus does not expose a supported adapter method.', 'receipt' => null];
    }

    /** @return array<string,mixed> */
    public function envelope(WorkforceTask $task, WorkforceMember $actor): array
    {
        return [
            'company_id' => $task->company_id,
            'trace_id' => $task->trace_id,
            'correlation_id' => $task->correlation_id,
            'causation_id' => $task->causation_id,
            'task_id' => $task->task_uuid,
            'parent_task_id' => $task->parent_task_id,
            'manager_member_id' => $task->manager_member_id,
            'division_id' => $task->division_id,
            'team_id' => $task->team_id,
            'actor' => [
                'id' => $actor->id,
                'key' => $actor->key,
                'tier' => $actor->tier?->value,
                'role' => $actor->role,
                'role_definition_id' => $actor->role_definition_id,
                'role_owner_extension' => $actor->role_owner_extension,
                'maturity_level' => $actor->maturity_level,
                'manager_member_id' => $actor->manager_id,
            ],
            'role_definition_id' => $actor->role_definition_id,
            'role_owner_extension' => $actor->role_owner_extension,
            'capability' => $task->capability,
            'capability_owner_extension' => $task->capability_owner_extension,
            'capability_variant' => $task->capability_variant,
            'workflow_ref' => $this->workflowRef($task, $actor),
            'playbook_ref' => $this->playbookRef($task, $actor),
            'payload' => $task->payload ?? [],
            'evidence' => $task->evidence ?? [],
            'risk_ceiling' => $actor->risk_ceiling,
            'task_status' => $task->status?->value,
        ];
    }

    private function workflowRef(WorkforceTask $task, WorkforceMember $actor): ?string
    {
        foreach ([
            data_get($task->metadata ?? [], 'interaction_workflow_ref'),
            data_get($task->governance ?? [], 'interaction_workflow_ref'),
        ] as $explicit) {
            if (is_string($explicit) && trim($explicit) !== '') return trim($explicit);
        }

        $owner = trim((string) ($task->capability_owner_extension ?? ''));
        if ($owner === '' && $task->capability) {
            $owners = $this->manifests->ownersForCapability((string) $actor->role_definition_id, (string) $task->capability);
            $owner = count($owners) === 1 ? $owners[0] : '';
        }

        $requested = data_get($task->metadata ?? [], 'workflow_ref') ?? data_get($task->governance ?? [], 'workflow_ref');
        if (is_string($requested) && trim($requested) !== '') {
            $requested = trim($requested);
            $workflow = $owner !== '' ? $this->manifests->findOwnedWorkflow($owner, $requested) : null;
            return is_string($workflow['interaction_workflow'] ?? null) ? trim((string) $workflow['interaction_workflow']) : $requested;
        }

        foreach ((array) data_get($actor->metadata ?? [], 'workflow_refs', []) as $workflowId) {
            $workflow = $owner !== '' ? $this->manifests->findOwnedWorkflow($owner, (string) $workflowId) : null;
            if (is_string($workflow['interaction_workflow'] ?? null) && trim((string) $workflow['interaction_workflow']) !== '') return trim((string) $workflow['interaction_workflow']);
            if (is_string($workflowId) && trim($workflowId) !== '') return trim($workflowId);
        }

        return null;
    }

    private function playbookRef(WorkforceTask $task, WorkforceMember $actor): ?string
    {
        $candidates = [
            data_get($task->metadata ?? [], 'playbook_ref'),
            data_get($task->governance ?? [], 'playbook_ref'),
            ($actor->playbooks ?? [])[0] ?? null,
        ];
        foreach ($candidates as $candidate) {
            if (is_string($candidate) && trim($candidate) !== '') return trim($candidate);
        }
        return null;
    }
}
