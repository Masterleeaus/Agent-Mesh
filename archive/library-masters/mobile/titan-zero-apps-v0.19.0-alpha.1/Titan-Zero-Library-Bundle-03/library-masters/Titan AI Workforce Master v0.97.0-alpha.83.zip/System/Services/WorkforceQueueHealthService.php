<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use Carbon\Carbon;

final class WorkforceQueueHealthService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function forManager(WorkforceMember $manager): array
    {
        return $this->snapshot((int) $manager->company_id, (int) $manager->division_id);
    }

    public function snapshot(int $companyId, int $divisionId): array
    {
        $policy = WorkforceResponsibilityRegistry::policy();
        $starvationMinutes = max(15, (int) ($policy['starvation_minutes'] ?? 120));
        $base = WorkforceTask::query()->forCompany($companyId)->where('division_id', $divisionId)->whereNotIn('status', self::TERMINAL);
        $open = (clone $base)->count();
        $assigned = (clone $base)->where('status', 'ASSIGNED')->count();
        $unassigned = (clone $base)->whereNull('assignee_member_id')->count();
        $review = (clone $base)->whereIn('status', ['SUBMITTED','UNDER_REVIEW','HANDOFF_PENDING','RECEIVER_REVIEW'])->count();
        $blocked = (clone $base)->whereIn('status', ['BLOCKED','AWAITING_DATA','RECOVERY'])->count();
        $escalated = (clone $base)->where('status', 'ESCALATED')->count();
        $overdue = (clone $base)->whereNotNull('deadline_at')->where('deadline_at', '<', now())->count();
        $starved = (clone $base)->whereNotNull('last_activity_at')->where('last_activity_at', '<', now()->subMinutes($starvationMinutes))->count();
        $oldest = (clone $base)->min('created_at');

        $members = WorkforceMember::query()->forCompany($companyId)
            ->where('division_id', $divisionId)
            ->where('tier', WorkforceTier::Specialist->value)
            ->where('is_active', true)
            ->whereNotIn('status', ['OFFLINE','SUSPENDED'])
            ->get()
            ->reject(fn (WorkforceMember $member) => (bool) data_get($member->metadata ?? [], 'internal', false));
        $capacity = $members->sum(fn (WorkforceMember $member): int => max(1, (int) ($member->max_concurrent_tasks ?? 5)));
        $loadRatio = $capacity > 0 ? $open / $capacity : ($open > 0 ? 99.0 : 0.0);
        $slaBreachRate = $open > 0 ? round($overdue / $open, 4) : 0.0;
        $coverageGap = $open > 0 && $capacity === 0;
        $pressure = $this->pressure($open, $loadRatio, $overdue, $blocked, $escalated, $starved);
        $staffingPressure = $this->staffingPressure($loadRatio, $slaBreachRate, $coverageGap, $unassigned, $starved, $overdue);

        return [
            'queue_depth' => $open,
            'assigned_count' => $assigned,
            'unassigned_count' => $unassigned,
            'review_count' => $review,
            'blocked_count' => $blocked,
            'escalated_count' => $escalated,
            'overdue_count' => $overdue,
            'starved_count' => $starved,
            'starvation_minutes' => $starvationMinutes,
            'active_specialists' => $members->count(),
            'active_capacity' => $capacity,
            'load_ratio' => round($loadRatio, 3),
            'capacity_utilisation' => round($loadRatio, 3),
            'oldest_task_minutes' => $oldest ? max(0, now()->diffInMinutes(Carbon::parse((string) $oldest))) : 0,
            'pressure' => $pressure,
            'coverage_gap' => $coverageGap,
            'sla_breach_rate' => $slaBreachRate,
            'staffing_pressure' => $staffingPressure,
        ];
    }

    private function staffingPressure(float $loadRatio, float $slaBreachRate, bool $coverageGap, int $unassigned, int $starved, int $overdue): array
    {
        $score = 0;
        $signals = [];
        if ($coverageGap) { $score += 50; $signals[] = 'coverage_gap'; }
        if ($loadRatio >= 1.0) { $score += 30; $signals[] = 'capacity_exhausted'; }
        elseif ($loadRatio >= 0.75) { $score += 15; $signals[] = 'high_utilisation'; }
        if ($slaBreachRate >= 0.10) { $score += 25; $signals[] = 'sla_breach_rate'; }
        if ($unassigned > 0) { $score += min(20, $unassigned * 4); $signals[] = 'unassigned_work'; }
        if ($starved > 0) { $score += min(20, $starved * 4); $signals[] = 'queue_starvation'; }
        if ($overdue > 0) { $score += min(20, $overdue * 4); $signals[] = 'overdue_work'; }
        $score = min(100, $score);
        return [
            'score' => $score,
            'signals' => array_values(array_unique($signals)),
            'recommend_staffing' => $score >= 30,
            'auto_activate' => false,
        ];
    }

    private function pressure(int $open, float $loadRatio, int $overdue, int $blocked, int $escalated, int $starved): string
    {
        if ($open === 0) return 'NORMAL';
        if ($loadRatio >= 1.25 || $overdue >= 5 || $escalated >= 3) return 'CRITICAL';
        if ($loadRatio >= 1.0 || $overdue >= 2 || $blocked >= 4 || $starved >= 4) return 'HIGH';
        if ($loadRatio >= 0.75 || $overdue >= 1 || $blocked >= 2 || $starved >= 2) return 'ELEVATED';
        return 'NORMAL';
    }
}
