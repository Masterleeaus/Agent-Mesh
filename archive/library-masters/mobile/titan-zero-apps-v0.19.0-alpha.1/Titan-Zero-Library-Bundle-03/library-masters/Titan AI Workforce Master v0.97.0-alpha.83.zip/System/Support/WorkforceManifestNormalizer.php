<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/**
 * Conservative compatibility bridge from Workforce Manifest 1.1 to 2.0.
 * Legacy named Autonomy levels map to the floor of their 0-100 band so
 * normalisation can never mint additional authority.
 */
final class WorkforceManifestNormalizer
{
    private const LEGACY_BAND_FLOORS = [
        'Suggest' => 0,
        'Assist' => 16,
        'Semi-Auto' => 31,
        'Auto' => 51,
        'Trusted Auto' => 71,
    ];

    public static function normalize(array $source): array
    {
        $version = (string) ($source['schema_version'] ?? '');
        if ($version === '2.0') {
            return $source;
        }
        if ($version !== '1.1') {
            throw new RuntimeException("Unsupported Workforce manifest schema_version {$version}; expected 2.0 or legacy 1.1.");
        }

        $manifest = $source;
        $manifest['schema_version'] = '2.0';

        foreach ($manifest['roles'] ?? [] as $index => $role) {
            if (! is_array($role)) {
                throw new RuntimeException('Legacy Workforce manifest roles must be objects.');
            }
            $level = (string) ($role['initial_autonomy'] ?? '');
            $score = self::legacyFloor($level);
            unset($role['initial_autonomy']);
            $role['autonomy'] = [
                'desired' => ['score' => $score, 'band' => $level],
                'initial_earned_ceiling' => ['score' => $score, 'band' => $level],
                'effective_authority' => [
                    'source' => 'titan_autonomy',
                    'decision_contract' => 'schemas/autonomy-decision.schema.json',
                    'mutable_by_extension' => false,
                ],
                'predictive_readiness' => [
                    'source' => 'titan_autonomy',
                    'decision_contract' => 'schemas/autonomy-decision.schema.json',
                    'grants_mutation_authority' => false,
                ],
                'capability_authority_refs' => array_map(
                    static fn (mixed $capability): array => [
                        'capability' => (string) $capability,
                        'variant' => 'standard',
                        'authority_source' => 'titan_autonomy',
                    ],
                    is_array($role['capabilities'] ?? null) ? $role['capabilities'] : []
                ),
            ];
            $manifest['roles'][$index] = $role;
        }

        foreach ($manifest['capabilities'] ?? [] as $index => $capability) {
            if (! is_array($capability)) {
                throw new RuntimeException('Legacy Workforce manifest capabilities must be objects.');
            }
            $level = $capability['autonomy_requirement'] ?? null;
            if (is_string($level)) {
                $capability['autonomy_requirement'] = [
                    'minimum_score' => self::legacyFloor($level),
                    'minimum_band' => $level,
                    'variant' => 'standard',
                    'authority_source' => 'titan_autonomy',
                ];
            }
            $manifest['capabilities'][$index] = $capability;
        }

        return $manifest;
    }

    public static function scheduleExpression(string $expression): array
    {
        $expression = trim($expression);
        if ($expression === '') {
            throw new RuntimeException('Workforce schedule frequency may not be empty.');
        }
        if (strcasecmp($expression, 'hourly') === 0) {
            return ['frequency' => 'hourly'];
        }
        if (preg_match('/^daily(?:\s+(\d{1,2}:\d{2}))?$/i', $expression, $m)) {
            return ['frequency' => 'daily', 'time' => self::normaliseTime($m[1] ?? '08:00')];
        }
        if (preg_match('/^weekdays?(?:\s+(\d{1,2}:\d{2}))?$/i', $expression, $m)) {
            return ['frequency' => 'weekdays', 'time' => self::normaliseTime($m[1] ?? '08:00')];
        }
        if (preg_match('/^weekly(?:\s+(mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|fri(?:day)?|sat(?:urday)?|sun(?:day)?))?(?:\s+(\d{1,2}:\d{2}))?$/i', $expression, $m)) {
            $days = ['mon'=>1,'monday'=>1,'tue'=>2,'tuesday'=>2,'wed'=>3,'wednesday'=>3,'thu'=>4,'thursday'=>4,'fri'=>5,'friday'=>5,'sat'=>6,'saturday'=>6,'sun'=>7,'sunday'=>7];
            $day = strtolower($m[1] ?? 'monday');
            return ['frequency' => 'weekly', 'days' => [$days[$day]], 'time' => self::normaliseTime($m[2] ?? '08:00')];
        }
        if (preg_match('/^monthly(?:\s+(\d{1,2}))?(?:\s+(\d{1,2}:\d{2}))?$/i', $expression, $m)) {
            $day = (int) ($m[1] ?? 1);
            if ($day < 1 || $day > 28) throw new RuntimeException("Unsupported Workforce monthly schedule day {$day}; use 1-28.");
            return ['frequency' => 'monthly', 'day' => $day, 'time' => self::normaliseTime($m[2] ?? '08:00')];
        }
        throw new RuntimeException("Unsupported Workforce schedule frequency expression {$expression}.");
    }

    public static function isLegacy(array $manifest): bool
    {
        return (string) ($manifest['schema_version'] ?? '') === '1.1';
    }

    private static function normaliseTime(string $time): string
    {
        if (! preg_match('/^(\d{1,2}):(\d{2})$/', $time, $m)) throw new RuntimeException("Invalid Workforce schedule time {$time}.");
        $hour = (int) $m[1]; $minute = (int) $m[2];
        if ($hour > 23 || $minute > 59) throw new RuntimeException("Invalid Workforce schedule time {$time}.");
        return sprintf('%02d:%02d', $hour, $minute);
    }

    private static function legacyFloor(string $level): int
    {
        if (! array_key_exists($level, self::LEGACY_BAND_FLOORS)) {
            throw new RuntimeException("Unsupported legacy Workforce autonomy level {$level}.");
        }
        return self::LEGACY_BAND_FLOORS[$level];
    }
}
