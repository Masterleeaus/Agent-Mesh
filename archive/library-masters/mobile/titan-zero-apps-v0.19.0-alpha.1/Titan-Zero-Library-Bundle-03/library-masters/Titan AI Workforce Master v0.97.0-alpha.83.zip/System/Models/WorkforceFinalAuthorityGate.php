<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceFinalAuthorityGate extends Model
{
    protected $table='ext_titan_ai_workforce_final_authority_gates';
    protected $guarded=[];
    protected $casts=[
        'organisationally_approved'=>'boolean',
        'governance_allowed'=>'boolean',
        'risk_allowed'=>'boolean',
        'autonomy_allowed'=>'boolean',
        'final_allowed'=>'boolean',
        'governance_result'=>'array',
        'risk_result'=>'array',
        'autonomy_result'=>'array',
        'policy_result'=>'array',
        'reason_codes'=>'array',
        'evaluated_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
