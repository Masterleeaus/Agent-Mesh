<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceWorkItemVerificationState: string
{
    case Pending = 'PENDING';
    case EvidencePending = 'EVIDENCE_PENDING';
    case Ready = 'READY';
    case Verified = 'VERIFIED';
    case Failed = 'FAILED';
    case RemediationRequired = 'REMEDIATION_REQUIRED';
}
