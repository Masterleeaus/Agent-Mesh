<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceAssuranceCouncilReview extends Model
{
    protected $table='ext_titan_ai_workforce_assurance_council_reviews';
    protected $guarded=[];
    protected $casts=[
        'assurance_score'=>'decimal:2',
        'assurance_result'=>'array',
        'model_council_required'=>'boolean',
        'council_role_models'=>'array',
        'council_result'=>'array',
        'advisory_only'=>'boolean',
        'reviewed_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
