<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use InvalidArgumentException;

final class WorkloadSharingService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceManifestLifecycleService $definitionLifecycle,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
    ) {}

    public function findSubstitute(WorkforceTask $task, WorkforceMember $current): ?WorkforceMember
    {
        if ((int) $task->company_id !== (int) $current->company_id) {
            return null;
        }
        return $this->lowestLoadCandidate(
            (int) $task->company_id,
            (int) $current->division_id,
            (string) ($task->capability ?? ''),
            (string) ($task->risk_level ?? 'LOW'),
            null,
            [(int) $current->id],
        );
    }

    public function findForRole(int $companyId, int $divisionId, string $roleKey, string $capability = '', string $riskLevel = 'LOW'): ?WorkforceMember
    {
        $definition = WorkforceRoleRegistry::find($roleKey);
        if (! $definition || (int) ($definition['tier'] ?? 0) !== WorkforceTier::Specialist->value) {
            return null;
        }
        return $this->lowestLoadCandidate($companyId, $divisionId, $capability, $riskLevel, (string) ($definition['role_id'] ?? ''), []);
    }

    public function reassign(WorkforceTask $task, WorkforceMember $manager, WorkforceMember $target, string $reason): WorkforceTask
    {
        if ((int) $task->company_id !== (int) $manager->company_id || (int) $task->company_id !== (int) $target->company_id) {
            throw new InvalidArgumentException('Cross-tenant workload reassignment rejected.');
        }
        if ((int) $task->manager_member_id !== (int) $manager->id) {
            throw new InvalidArgumentException('Only the assigned Manager may rebalance this task.');
        }
        if ((int) $task->division_id !== (int) $target->division_id) {
            throw new InvalidArgumentException('Cross-division workload sharing requires a governed handoff.');
        }
        if (! $this->eligible($target, (string) ($task->capability ?? ''), (string) ($task->risk_level ?? 'LOW'))) {
            throw new InvalidArgumentException('Target member is not eligible for this task.');
        }
        $previous = $task->assignee_member_id;
        $task->forceFill(['assignee_member_id' => $target->id, 'team_id' => $target->team_id, 'last_activity_at' => now()])->save();
        $task = $this->definitionLifecycle->rePinTask($task->refresh(), $target);
        $this->tasks->record($task, $manager, 'task.reassigned', $task->status->value, $task->status->value, $reason, [
            'previous_assignee_member_id' => $previous,
            'new_assignee_member_id' => $target->id,
            'authority_inherited' => false,
        ]);
        if ($task->status === \App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus::Blocked && (bool) data_get($task->metadata ?? [], 'staffing_gap', false)) {
            $metadata = $task->metadata ?? [];
            $metadata['staffing_gap'] = false;
            $task->forceFill(['metadata' => $metadata])->save();
            $task = $this->tasks->transition($task->refresh(), \App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus::Assigned, $manager, 'task.reassignment_ready', 'Staffing gap resolved by Manager reassignment.');
            ProcessWorkforceTaskJob::dispatch((int) $task->company_id, (int) $task->id);
        }
        return $task->refresh();
    }

    private function lowestLoadCandidate(int $companyId, int $divisionId, string $capability, string $riskLevel, ?string $roleDefinitionId, array $excludeIds): ?WorkforceMember
    {
        $candidates = WorkforceMember::query()
            ->forCompany($companyId)
            ->where('division_id', $divisionId)
            ->where('tier', WorkforceTier::Specialist->value)
            ->where('is_active', true)
            ->when($excludeIds !== [], fn ($q) => $q->whereNotIn('id', $excludeIds))
            ->get()
            ->filter(function (WorkforceMember $member) use ($capability, $riskLevel, $roleDefinitionId): bool {
                if ($roleDefinitionId !== null && $roleDefinitionId !== '' && (string) $member->role_definition_id !== $roleDefinitionId) {
                    return false;
                }
                return $this->eligible($member, $capability, $riskLevel);
            });

        return $candidates->sortBy(function (WorkforceMember $member): int {
            $limit = max(1, (int) ($member->max_concurrent_tasks ?? data_get($member->workload_config ?? [], 'max_concurrent', 5)));
            $open = $member->assignedTasks()->whereNotIn('status', ['COMPLETED','FAILED','CANCELLED','REJECTED'])->count();
            return (int) round(($open / $limit) * 100000) + $open;
        })->first();
    }

    private function eligible(WorkforceMember $member, string $requiredCapability, string $riskLevel): bool
    {
        if ((bool) data_get($member->metadata ?? [], 'internal', false)) return false;
        if (! (bool) ($member->substitution_enabled ?? true)) return false;
        if (in_array($member->status, [WorkforceMemberStatus::Offline, WorkforceMemberStatus::Suspended], true)) return false;
        if ($requiredCapability !== '' && ! $this->capabilityAvailability->isCapabilityAvailable($member, $requiredCapability)) return false;
        $rank = ['MINIMAL'=>1,'LOW'=>2,'MEDIUM'=>3,'HIGH'=>4,'EXTREME'=>5];
        if (($rank[strtoupper($riskLevel)] ?? 2) > ($rank[strtoupper((string) $member->risk_ceiling)] ?? 2)) return false;
        $limit = max(1, (int) ($member->max_concurrent_tasks ?? data_get($member->workload_config ?? [], 'max_concurrent', 5)));
        $open = $member->assignedTasks()->whereNotIn('status', ['COMPLETED','FAILED','CANCELLED','REJECTED'])->count();
        return $open < $limit;
    }
}
