<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceCouncilMembership extends Model
{
    protected $table = 'ext_titan_ai_workforce_council_memberships';
    protected $guarded = [];
    protected $casts = ['is_active' => 'boolean', 'metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
