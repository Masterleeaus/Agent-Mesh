<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberLifecycleState;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOrganisation;
use App\Extensions\TitanAIWorkforce\System\Support\TitanZeroSystemRole;
use Illuminate\Support\Str;

/** Permanent owner-facing Chief of Staff. No domain capabilities or bypass authority. */
final class TitanZeroChiefOfStaffService
{
    public function ensureForCompany(int $companyId): WorkforceMember
    {
        if ($companyId <= 0) throw new \InvalidArgumentException('Titan Zero requires a valid company_id.');
        $definition = TitanZeroSystemRole::definition();
        $organisation = WorkforceOrganisation::query()->firstOrCreate(
            ['company_id' => $companyId],
            ['key' => 'primary', 'name' => 'Workforce Organisation', 'status' => 'ACTIVE', 'metadata' => ['definition_source' => 'titan-ai-workforce']],
        );

        $member = WorkforceMember::withTrashed()->forCompany($companyId)->where('system_role_key', TitanZeroSystemRole::KEY)->first();
        $fingerprint = hash('sha256', json_encode($definition, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        $attributes = [
            'company_id' => $companyId,
            'organisation_id' => $organisation->id,
            'user_id' => null,
            'created_by_user_id' => null,
            'activated_by_user_id' => null,
            'division_id' => null,
            'team_id' => null,
            'manager_id' => null,
            'tier' => WorkforceTier::Manager,
            'key' => $this->memberKeyForCompany($companyId, $member?->id),
            'name' => TitanZeroSystemRole::NAME,
            'role' => TitanZeroSystemRole::BUSINESS_ROLE,
            'purpose' => (string) $definition['purpose'],
            'responsibilities' => array_values(array_map('strval', $definition['responsibilities'] ?? [])),
            'goals' => [],
            'capabilities' => [],
            'capability_variants' => [],
            'skills' => array_values(array_map('strval', $definition['recommended_skills'] ?? [])),
            'playbooks' => [],
            'interaction_wizards' => [],
            'knowledge_scopes' => ['organisation:company'],
            'memory_scopes' => ['organisation:company'],
            'provider_preferences' => [],
            'model_preferences' => [],
            'schedule_config' => [],
            'workload_config' => ['system_role' => true],
            'escalation_policy' => ['route_material_owner_decisions' => true],
            'risk_ceiling' => 'LOW',
            'autonomy_references' => [
                'authority_source' => 'titan_autonomy',
                'initial_band' => 'Suggest',
                'initial_score' => 0,
                'desired_band' => 'Suggest',
                'desired_score' => 0,
                'self_promotion' => false,
                'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
            ],
            'assurance_references' => ['required' => 'AMBER', 'bypass' => false],
            'performance_history' => [],
            'status' => WorkforceMemberStatus::Available,
            'lifecycle_state' => WorkforceMemberLifecycleState::Active,
            'lifecycle_changed_at' => now(),
            'activated_at' => $member?->activated_at ?: now(),
            'suspended_at' => null,
            'retired_at' => null,
            'replaced_by_member_id' => null,
            'lifecycle_metadata' => ['system_role' => true, 'permanent' => true],
            'is_active' => true,
            'role_definition_id' => TitanZeroSystemRole::ROLE_DEFINITION_ID,
            'role_owner_extension' => 'titan-ai-workforce',
            'role_owner_extension_version' => 'intrinsic-system',
            'role_definition_version' => (string) ($definition['definition_version'] ?? '1'),
            'role_definition_fingerprint' => $fingerprint,
            'role_definition_state' => 'CURRENT',
            'role_definition_snapshot' => $definition,
            'role_definition_deprecated_at' => null,
            'role_definition_grace_until' => null,
            'maturity_level' => 'LEAD',
            'max_concurrent_tasks' => 1,
            'substitution_enabled' => false,
            'member_kind' => 'SYSTEM',
            'system_role_key' => 'titan-zero',
            'consumes_seat' => false,
            'is_permanent_system_role' => true,
            'visibility_scope' => (array) ($definition['visibility_scope'] ?? []),
            'coordination_permissions' => array_values(array_map('strval', $definition['coordination_permissions'] ?? [])),
            'metadata' => [
                'definition_source' => 'intrinsic_system_role',
                'system_role' => true,
                'owner_facing_interface' => true,
                'chief_of_staff' => true,
                'coordination_not_domain_execution' => true,
                'executable_capabilities' => [],
                'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
                'ensure_trace_id' => (string) Str::uuid(),
            ],
        ];

        if (! $member) {
            return WorkforceMember::query()->create($attributes)->refresh();
        }
        if ($member->trashed()) $member->restore();
        $member->forceFill($attributes)->save();
        return $member->refresh();
    }

    private function memberKeyForCompany(int $companyId, ?int $currentMemberId = null): string
    {
        $query = WorkforceMember::withTrashed()->forCompany($companyId)->where('key', TitanZeroSystemRole::KEY);
        if ($currentMemberId !== null) $query->where('id', '<>', $currentMemberId);
        return $query->exists() ? 'titan-zero-system' : TitanZeroSystemRole::KEY;
    }

    public function findForCompany(int $companyId): ?WorkforceMember
    {
        return WorkforceMember::query()->forCompany($companyId)->where('system_role_key', TitanZeroSystemRole::KEY)->first();
    }

    /** @return array<string,mixed> */
    public function coordinationProfile(): array
    {
        $definition = TitanZeroSystemRole::definition();
        return [
            'role_definition_id' => TitanZeroSystemRole::ROLE_DEFINITION_ID,
            'visibility_scope' => $definition['visibility_scope'] ?? [],
            'coordination_permissions' => $definition['coordination_permissions'] ?? [],
            'executable_capabilities' => [],
            'bypass' => ['risk' => false, 'assurance' => false, 'governance' => false, 'autonomy' => false],
        ];
    }
}
