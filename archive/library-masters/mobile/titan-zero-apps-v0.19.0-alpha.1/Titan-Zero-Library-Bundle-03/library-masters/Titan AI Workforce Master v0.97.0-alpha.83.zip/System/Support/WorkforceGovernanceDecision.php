<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class WorkforceGovernanceDecision
{
    public const RISK_LEVELS = ['MINIMAL','LOW','MEDIUM','HIGH','EXTREME'];
    public const ASSURANCE_STATES = ['GREEN','AMBER','RED'];

    /** @return array<string,mixed> */
    public static function normalizeRisk(array $decision): array
    {
        $level = strtoupper(trim((string) ($decision['level'] ?? $decision['risk_level'] ?? '')));
        if (! in_array($level, self::RISK_LEVELS, true)) {
            throw new RuntimeException('Titan Risk decision must use Minimal/Low/Medium/High/Extreme.');
        }
        if (! array_key_exists('allowed', $decision) || ! is_bool($decision['allowed'])) {
            throw new RuntimeException('Titan Risk decision requires an explicit boolean allowed field.');
        }
        foreach (['decision_id','policy_version','evaluated_at'] as $field) {
            if (trim((string) ($decision[$field] ?? '')) === '') throw new RuntimeException("Titan Risk decision requires {$field}.");
        }
        $decision['level'] = $level;
        $decision['available'] = true;
        $decision['requires_model_council'] = (bool) ($decision['requires_model_council'] ?? false);
        $decision['approval_requirements'] = self::stringList($decision['approval_requirements'] ?? []);
        $decision['reason_codes'] = self::stringList($decision['reason_codes'] ?? []);
        $decision['evidence_refs'] = self::stringList($decision['evidence_refs'] ?? []);
        return $decision;
    }

    /** @return array<string,mixed> */
    public static function normalizeAssurance(array $decision): array
    {
        $state = strtoupper(trim((string) ($decision['state'] ?? $decision['assurance_state'] ?? '')));
        if (! in_array($state, self::ASSURANCE_STATES, true)) {
            throw new RuntimeException('Titan Assurance decision must use Green/Amber/Red.');
        }
        if (! array_key_exists('allowed', $decision) || ! is_bool($decision['allowed'])) {
            throw new RuntimeException('Titan Assurance decision requires an explicit boolean allowed field.');
        }
        foreach (['decision_id','policy_version','evaluated_at'] as $field) {
            if (trim((string) ($decision[$field] ?? '')) === '') throw new RuntimeException("Titan Assurance decision requires {$field}.");
        }
        $decision['state'] = $state;
        $decision['available'] = true;
        $decision['reason_codes'] = self::stringList($decision['reason_codes'] ?? []);
        $decision['evidence_refs'] = self::stringList($decision['evidence_refs'] ?? []);
        $decision['missing_evidence'] = self::stringList($decision['missing_evidence'] ?? []);
        return $decision;
    }

    /** @return array{allowed:bool,reason_codes:list<string>} */
    public static function policy(array $risk, array $assurance, array $council): array
    {
        $reasons = [];
        if (($risk['available'] ?? false) !== true) $reasons[] = 'RISK_UNAVAILABLE';
        elseif (($risk['allowed'] ?? false) !== true) $reasons[] = 'RISK_DENIED';

        if (($assurance['available'] ?? false) !== true) $reasons[] = 'ASSURANCE_UNAVAILABLE';
        elseif (($assurance['allowed'] ?? false) !== true || strtoupper((string) ($assurance['state'] ?? '')) === 'RED') $reasons[] = 'ASSURANCE_DENIED';

        if (($council['required'] ?? false) === true) {
            if (($council['available'] ?? false) !== true || ($council['consulted'] ?? false) !== true) $reasons[] = 'MODEL_COUNCIL_UNAVAILABLE';
            elseif (($council['policy_satisfied'] ?? false) !== true) $reasons[] = 'MODEL_COUNCIL_POLICY_NOT_SATISFIED';
        }

        return ['allowed' => $reasons === [], 'reason_codes' => array_values(array_unique($reasons))];
    }

    /** @return list<string> */
    public static function evidenceRefs(array $evidence): array
    {
        $refs = [];
        foreach ($evidence as $entry) {
            if (is_string($entry) && trim($entry) !== '') {
                $refs[] = trim($entry);
                continue;
            }
            if (! is_array($entry)) continue;
            foreach (['ref','evidence_ref','id','uri'] as $key) {
                if (is_string($entry[$key] ?? null) && trim((string) $entry[$key]) !== '') {
                    $refs[] = trim((string) $entry[$key]);
                    break;
                }
            }
        }
        return array_values(array_unique($refs));
    }

    /** @return list<string> */
    public static function missingEvidence(array $required, array $evidence): array
    {
        $types = [];
        foreach ($evidence as $entry) {
            if (is_string($entry)) {
                $types[] = trim($entry);
                continue;
            }
            if (! is_array($entry)) continue;
            foreach (['type','kind','requirement','name'] as $key) {
                if (is_string($entry[$key] ?? null) && trim((string) $entry[$key]) !== '') {
                    $types[] = trim((string) $entry[$key]);
                    break;
                }
            }
        }
        $types = array_values(array_unique(array_filter($types)));
        $required = array_values(array_unique(array_map(static fn ($value): string => trim((string) $value), $required)));
        return array_values(array_filter($required, static fn (string $item): bool => $item !== '' && ! in_array($item, $types, true)));
    }

    /** @return list<string> */
    private static function stringList(mixed $value): array
    {
        if (! is_array($value)) return [];
        return array_values(array_unique(array_filter(array_map(static fn ($item): string => trim((string) $item), $value))));
    }
}
