<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforcePerformanceMetric;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRuntimeProfile;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Collection;

/**
 * Read-only, company-scoped Employee 360 projection.
 *
 * Bound, live availability, and execution authorization are deliberately separate.
 * Authorization is only displayed when Titan Autonomy has made a task-scoped decision;
 * a bound/available capability without such a decision is NEVER represented as authorized.
 */
final class WorkforceEmployeeProfileService
{
    public function __construct(private readonly WorkforceCapabilityAvailabilityService $availability) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId, WorkforceMember $member): array
    {
        if ((int) $member->company_id !== $companyId) {
            abort(404);
        }

        $member->loadMissing(['division','team','manager','reports']);
        $role = WorkforceRoleRegistry::find((string) $member->role_definition_id) ?? [];
        $live = $this->availability->forMember($member);
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->where(function ($q) use ($member): void {
                $q->where('assignee_member_id', $member->id)->orWhere('manager_member_id', $member->id);
            })
            ->latest('updated_at')->limit(250)->get();
        $assignedTasks = $tasks->where('assignee_member_id', $member->id)->values();
        $managedTasks = $tasks->where('manager_member_id', $member->id)->values();
        $taskIds = $tasks->pluck('id')->map(fn ($id) => (int) $id)->all();

        $capabilityRows = $this->capabilityRows($live, $assignedTasks);
        $toolRows = $this->toolRows($live, $member, $companyId);
        $responsibilities = WorkforceResponsibilityRegistry::accountabilitiesForRole((string) $member->role_definition_id);

        $schedules = WorkforceSchedule::query()->forCompany($companyId)->where('member_id', $member->id)->orderByDesc('is_active')->orderBy('next_run_at')->limit(100)->get();
        $delegations = WorkforceDelegation::query()->forCompany($companyId)->where(function ($q) use ($member): void {
            $q->where('from_member_id', $member->id)->orWhere('to_member_id', $member->id);
        })->latest('created_at')->limit(100)->get();
        $escalations = WorkforceEscalation::query()->forCompany($companyId)->where(function ($q) use ($member): void {
            $q->where('raised_by_member_id', $member->id)->orWhere('escalated_to_member_id', $member->id);
        })->latest('created_at')->limit(100)->get();
        $performance = WorkforcePerformanceMetric::query()->forCompany($companyId)->where('member_id', $member->id)->orderByDesc('period_end')->limit(100)->get();
        $outcomes = $taskIds === [] ? collect() : WorkforceOutcome::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->latest('observed_at')->limit(100)->get();
        $history = $taskIds === []
            ? WorkforceTaskHistory::query()->where('company_id', $companyId)->where('actor_member_id', $member->id)->latest('created_at')->limit(150)->get()
            : WorkforceTaskHistory::query()->where('company_id', $companyId)->where(function ($q) use ($member, $taskIds): void {
                $q->where('actor_member_id', $member->id)->orWhereIn('task_id', $taskIds);
            })->latest('created_at')->limit(150)->get();

        $runtimeProfileId = trim((string) ($member->runtime_profile_id ?? ''));
        $runtime = $runtimeProfileId === '' ? null : WorkforceRuntimeProfile::query()->forCompany($companyId)->where('profile_id', $runtimeProfileId)->first();

        return [
            'member' => $member,
            'role' => $role,
            'health' => [
                'capability_state' => (string) ($live['state'] ?? 'unavailable'),
                'bound_capabilities' => count($capabilityRows),
                'available_capabilities' => count(array_filter($capabilityRows, fn (array $r): bool => $r['available'] === true)),
                'authorized_capabilities' => count(array_filter($capabilityRows, fn (array $r): bool => $r['authorized'] === true)),
                'open_work' => $assignedTasks->filter(fn ($t): bool => ! in_array((string) ($t->status?->value ?? $t->status), ['COMPLETED','FAILED','CANCELLED'], true))->count(),
                'open_escalations' => $escalations->where('resolved_at', null)->count(),
                'active_schedules' => $schedules->where('is_active', true)->count(),
                'verified_outcomes' => $outcomes->whereNotNull('verified_at')->count(),
            ],
            'responsibilities' => $responsibilities,
            'work' => ['assigned' => $assignedTasks, 'managed' => $managedTasks],
            'capability_state' => $live,
            'capabilities' => $capabilityRows,
            'tools' => $toolRows,
            'schedules' => $schedules,
            'delegations' => $delegations,
            'escalations' => $escalations,
            'performance' => $performance,
            'outcomes' => $outcomes,
            'runtime' => $runtime,
            'history' => $history,
        ];
    }

    /** @param array<string,mixed> $live @param Collection<int,WorkforceTask> $tasks @return list<array<string,mixed>> */
    private function capabilityRows(array $live, Collection $tasks): array
    {
        $rows = [];
        foreach ((array) ($live['provider_bindings'] ?? []) as $binding) {
            $provider = (string) ($binding['provider'] ?? '');
            foreach ((array) data_get($binding, 'surfaces.capabilities', []) as $surface) {
                if (! is_array($surface)) continue;
                $id = trim((string) ($surface['id'] ?? ''));
                if ($id === '') continue;
                $latest = $tasks->first(function (WorkforceTask $task) use ($id): bool {
                    return trim((string) $task->capability) === $id && is_array($task->autonomy_snapshot) && $task->autonomy_snapshot !== [];
                });
                $decision = $latest ? data_get($latest->autonomy_snapshot, 'allowed') : null;
                $rows[$provider.'|'.$id] = [
                    'id' => $id,
                    'provider' => $provider,
                    'bound' => true,
                    'available' => (string) ($surface['state'] ?? '') === 'available',
                    'availability_state' => (string) ($surface['state'] ?? 'unavailable'),
                    'authorized' => is_bool($decision) ? $decision : null,
                    'authorization_scope' => $latest ? 'task:'.$latest->id : null,
                    'authorization_note' => is_bool($decision) ? 'Latest task-scoped Titan Autonomy decision' : 'No current task-scoped authority decision',
                    'authority_inherited' => false,
                ];
            }
        }
        $rows = array_values($rows);
        usort($rows, static fn (array $a, array $b): int => [$a['provider'],$a['id']] <=> [$b['provider'],$b['id']]);
        return $rows;
    }

    /** @param array<string,mixed> $live @return list<array<string,mixed>> */
    private function toolRows(array $live, WorkforceMember $member, int $companyId): array
    {
        $runtimeTools = [];
        $profileId = trim((string) ($member->runtime_profile_id ?? ''));
        if ($profileId !== '') {
            $profile = WorkforceRuntimeProfile::query()->forCompany($companyId)->where('profile_id', $profileId)->first();
            foreach ((array) ($profile?->informational_tools ?? []) as $tool) {
                $id = is_array($tool) ? trim((string) ($tool['id'] ?? $tool['name'] ?? '')) : trim((string) $tool);
                if ($id !== '') $runtimeTools[$id] = true;
            }
        }
        $rows = [];
        foreach ((array) ($live['provider_bindings'] ?? []) as $binding) {
            $provider = (string) ($binding['provider'] ?? '');
            foreach ((array) data_get($binding, 'surfaces.tools', []) as $surface) {
                if (! is_array($surface)) continue;
                $id = trim((string) ($surface['id'] ?? ''));
                if ($id === '') continue;
                $rows[$provider.'|'.$id] = [
                    'id' => $id,
                    'provider' => $provider,
                    'bound' => true,
                    'available' => (string) ($surface['state'] ?? '') === 'available',
                    'availability_state' => (string) ($surface['state'] ?? 'unavailable'),
                    'runtime_enabled' => isset($runtimeTools[$id]),
                    'authority_inherited' => false,
                ];
            }
        }
        $rows = array_values($rows);
        usort($rows, static fn (array $a, array $b): int => [$a['provider'],$a['id']] <=> [$b['provider'],$b['id']]);
        return $rows;
    }
}
