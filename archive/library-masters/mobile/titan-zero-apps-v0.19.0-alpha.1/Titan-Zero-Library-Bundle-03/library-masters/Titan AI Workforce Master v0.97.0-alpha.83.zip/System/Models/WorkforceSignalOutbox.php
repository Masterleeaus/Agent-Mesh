<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

class WorkforceSignalOutbox extends Model
{
    protected $table = 'ext_titan_ai_workforce_signal_outbox';
    protected $guarded = [];
    protected $casts = ['payload' => 'array', 'published_at' => 'datetime', 'failed_at' => 'datetime'];
}
