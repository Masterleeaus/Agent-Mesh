<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforcePerformanceMetric extends Model
{
    protected $table = 'ext_titan_ai_workforce_performance_metrics';
    protected $guarded = [];
    protected $casts = ['metric_value' => 'float', 'period_start' => 'datetime', 'period_end' => 'datetime', 'context' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
