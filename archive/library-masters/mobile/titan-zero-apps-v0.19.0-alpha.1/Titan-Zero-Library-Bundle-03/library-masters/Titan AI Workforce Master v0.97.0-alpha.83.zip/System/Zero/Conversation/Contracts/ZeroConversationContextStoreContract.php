<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Contracts;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\ValueObjects\ZeroConversationContext;
interface ZeroConversationContextStoreContract
{
    public function load(int $companyId, string $conversationId, string $actorId): ?ZeroConversationContext;
    public function save(ZeroConversationContext $context): void;
}
