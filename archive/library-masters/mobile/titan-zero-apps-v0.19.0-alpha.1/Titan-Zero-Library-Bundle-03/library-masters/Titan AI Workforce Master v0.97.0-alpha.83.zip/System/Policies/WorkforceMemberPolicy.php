<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Policies;

use App\Extensions\TitanAIWorkforce\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePermissions;
use InvalidArgumentException;

class WorkforceMemberPolicy
{
    public function __construct(private readonly TitanHostAuthorizationAdapter $authorization) {}

    public function viewAny(object $user): bool
    {
        return $this->withinTenant($user)
            && $this->authorization->allows($user, WorkforcePermissions::READ, WorkforcePermissions::delegatedAdminPermissions());
    }

    public function view(object $user, WorkforceMember $member): bool
    {
        return $this->viewAny($user) && (int) $member->company_id === CompanyContext::id($user);
    }

    public function update(object $user, WorkforceMember $member): bool
    {
        return $this->withinMemberTenant($user, $member)
            && $this->authorization->allows($user, WorkforcePermissions::STAFF_ADD, WorkforcePermissions::delegatedAdminPermissions());
    }

    public function delete(object $user, WorkforceMember $member): bool
    {
        if ((bool) ($member->is_permanent_system_role ?? false)) return false;
        return $this->update($user, $member);
    }

    private function withinTenant(object $user): bool
    {
        try { return CompanyContext::id($user) > 0; } catch (InvalidArgumentException) { return false; }
    }

    private function withinMemberTenant(object $user, WorkforceMember $member): bool
    {
        try { return (int) $member->company_id === CompanyContext::id($user); } catch (InvalidArgumentException) { return false; }
    }
}
