<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use Illuminate\Support\Str;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

final class WorkforceDelegationService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceGraphService $graph,
        private readonly WorkforceAuthorityGraphValidator $authorityGraph,
    ) {}

    public function toActionWorker(WorkforceTask $source, WorkforceMember $manager, ?int $workerId = null): WorkforceTask
    {
        if ((int) $source->company_id !== (int) $manager->company_id) { throw new InvalidArgumentException('Cross-tenant delegation rejected.'); }
        if ($source->status !== WorkforceTaskStatus::Approved) { throw new InvalidArgumentException('Only approved specialist work may be delegated to an Action Worker.'); }
        if ((int) $source->manager_member_id !== (int) $manager->id) { throw new InvalidArgumentException('Only the approving Manager may delegate this task.'); }
        if ((int) $source->division_id !== (int) $manager->division_id) { throw new InvalidArgumentException('Cross-division delegation requires a governed handoff.'); }
        if (! $source->capability) { throw new InvalidArgumentException('Task has no governed capability to execute.'); }

        $query = WorkforceMember::query()->forCompany((int) $source->company_id)
            ->where('tier', WorkforceTier::ActionWorker->value)->where('division_id', $source->division_id)->where('is_active', true);
        $worker = $workerId ? $query->find($workerId) : $query->orderBy('id')->first();
        if (! $worker) { throw new InvalidArgumentException('No active Tier 3 Action Worker is available in this division.'); }
        if ((int) $worker->division_id !== (int) $manager->division_id) { throw new InvalidArgumentException('Cross-division delegation requires a governed handoff.'); }
        $this->authorityGraph->assertDelegationAcyclic((int) $source->company_id, (int) $manager->id, (int) $worker->id);

        $this->graph->relate($manager, $worker, WorkforceRelationshipType::DelegatesTo, [
            'scope' => [(string) $source->capability],
            'task_uuid' => (string) $source->task_uuid,
            'relationship_contract' => 'delegates_to',
            'authority_inherited' => false,
            'requires_existing_autonomy' => true,
        ]);

        $delegation = WorkforceDelegation::query()->create([
            'delegation_uuid' => (string) Str::uuid(),
            'company_id' => (int) $source->company_id,
            'task_id' => (int) $source->id,
            'from_member_id' => (int) $manager->id,
            'to_member_id' => (int) $worker->id,
            'delegation_type' => 'WORK',
            'status' => 'ACTIVE',
            'authority_scope' => [
                'capabilities' => [(string) $source->capability],
                'delegator_may_expand_authority' => false,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
                'requires_fresh_execution_authorization' => true,
            ],
            'reason' => 'Approved specialist work delegated for governed Action Worker execution.',
            'metadata' => [
                'source_task_uuid' => (string) $source->task_uuid,
                'responsibility' => (string) (data_get($source->metadata ?? [], 'responsibility_key') ?? data_get($source->payload ?? [], 'responsibility_key') ?? 'Task-scoped governed work'),
                'audit_history' => [[
                    'event' => 'delegation.created',
                    'at' => now()->toIso8601String(),
                    'actor_member_id' => (int) $manager->id,
                    'reason' => 'Approved specialist work delegated to Action Worker.',
                ]],
            ],
        ]);

        $child = $this->tasks->create((int) $source->company_id, [
            'parent_task_id' => $source->id,
            'division_id' => $source->division_id,
            'team_id' => $worker->team_id,
            'assignee_member_id' => $worker->id,
            'manager_member_id' => $manager->id,
            'origin_type' => 'workforce_delegation',
            'origin_id' => $source->task_uuid,
            'title' => 'Execute: ' . $source->title,
            'description' => 'Prepare the final governed capability request from approved specialist work. Do not mutate business state directly.',
            'capability' => $source->capability,
            'capability_variant' => $source->capability_variant,
            'status' => WorkforceTaskStatus::Assigned,
            'priority' => $source->priority,
            'risk_level' => $source->risk_level,
            'payload' => ['approved_specialist_task' => $source->task_uuid, 'source_payload' => $source->payload, 'source_proposal' => $source->result],
            'evidence' => $source->evidence,
            'trace_id' => $source->trace_id,
            'correlation_id' => $source->correlation_id,
            'causation_id' => $source->task_uuid,
            'idempotency_key' => 'action-worker:' . $source->task_uuid,
            'metadata' => array_merge($source->metadata ?? [], ['action_worker_stage' => true, 'delegation_uuid' => (string) $delegation->delegation_uuid]),
        ], $manager);
        ProcessWorkforceTaskJob::dispatch((int) $child->company_id, (int) $child->id);
        return $child;
    }
}
