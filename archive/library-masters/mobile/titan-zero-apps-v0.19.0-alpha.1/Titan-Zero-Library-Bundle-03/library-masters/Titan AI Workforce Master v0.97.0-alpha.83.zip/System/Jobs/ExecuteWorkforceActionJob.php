<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Jobs;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Queue\Middleware\RestoreWorkforceTenantContext;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceExecutionService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use RuntimeException;

class ExecuteWorkforceActionJob implements ShouldQueue
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    public int $tries = 1;
    public function __construct(public readonly int $companyId, public readonly int $taskId) { $this->onQueue('titan-workforce'); }

    public function middleware(): array
    {
        return [new RestoreWorkforceTenantContext($this->companyId)];
    }

    public function handle(WorkforceExecutionService $execution): void
    {
        $task = WorkforceTask::query()->forCompany($this->companyId)->findOrFail($this->taskId);
        if ($task->status !== WorkforceTaskStatus::Approved) { return; }
        $worker = WorkforceMember::query()->forCompany($this->companyId)->findOrFail($task->assignee_member_id);
        if ($worker->tier !== WorkforceTier::ActionWorker) { throw new RuntimeException('Only Tier 3 Action Workers may enter capability execution.'); }
        $execution->execute($task, $worker, [
            'capability' => $task->capability,
            'variant' => $task->capability_variant,
            'payload' => $task->payload ?? [],
            'proposal' => $task->result['proposal'] ?? $task->result,
            'evidence' => $task->evidence ?? [],
            'expected_state' => data_get($task->metadata ?? [], 'expected_state') ?? data_get($task->governance ?? [], 'expected_state'),
            'expected_outcome' => data_get($task->metadata ?? [], 'expected_outcome') ?? data_get($task->governance ?? [], 'expected_outcome'),
        ]);
    }
}
