<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceDelegation extends Model
{
    protected $table = 'ext_titan_ai_workforce_delegations';
    protected $guarded = [];
    protected $casts = ['authority_scope' => 'array', 'expires_at' => 'datetime', 'completed_at' => 'datetime', 'review_required' => 'boolean', 'reviewed_at' => 'datetime', 'metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
