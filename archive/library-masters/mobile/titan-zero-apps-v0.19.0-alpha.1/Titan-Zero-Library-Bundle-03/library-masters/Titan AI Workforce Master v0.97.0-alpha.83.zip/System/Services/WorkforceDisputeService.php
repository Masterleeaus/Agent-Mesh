<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceDisputeService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceEscalationService $escalation,
    ) {}

    public function raise(int $companyId, string $conflict, array $context = []): WorkforceTask
    {
        $participants = array_values(array_unique(array_map('intval', (array) ($context['participant_manager_ids'] ?? []))));
        if (count($participants) < 2) {
            throw new InvalidArgumentException('Workforce disputes require at least two explicit participant_manager_ids.');
        }
        $manager = $this->escalation->resolveDisputeManager($companyId, $participants);

        $correlation = (string) ($context['correlation_id'] ?? Str::uuid());
        $task = $this->tasks->create($companyId, [
            'division_id' => $manager->division_id,
            'team_id' => $manager->team_id,
            'assignee_member_id' => $manager->id,
            'manager_member_id' => $manager->manager_id,
            'origin_type' => 'workforce_dispute',
            'origin_id' => (string) ($context['dispute_id'] ?? $correlation),
            'title' => 'Resolve organisational dispute: '.str_replace('_', ' ', $conflict),
            'description' => 'Resolve the organisational conflict by creating governed work or handoffs. The dispute does not confer execution authority.',
            'status' => WorkforceTaskStatus::Escalated,
            'priority' => (int) ($context['priority'] ?? 90),
            'risk_level' => (string) ($context['risk_level'] ?? 'MEDIUM'),
            'payload' => [
                'conflict' => $conflict,
                'participant_manager_ids' => $participants,
                'resolved_escalation_manager_id' => $manager->id,
                'context' => $context,
            ],
            'correlation_id' => $correlation,
            'idempotency_key' => 'dispute:'.$conflict.':'.($context['dispute_id'] ?? $correlation),
            'metadata' => [
                'governed_coordination_only' => true,
                'requires_defined_termination' => true,
                'resolution_source' => 'persisted_reporting_graph',
                'authority_inherited' => false,
            ],
        ], $manager);
        ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);
        return $task;
    }
}
