<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;

final class WorkforceMaturityService
{
    private const LEVELS = ['JUNIOR','STANDARD','SENIOR','LEAD'];

    public function evaluate(WorkforceMember $member, array $metrics): array
    {
        $current = strtoupper((string) ($member->maturity_level ?? 'JUNIOR'));
        $index = array_search($current, self::LEVELS, true);
        if ($index === false) { $index = 0; $current = self::LEVELS[0]; }

        $sample = (int) ($metrics['sample_size'] ?? 0);
        $managerAcceptance = (float) ($metrics['manager_acceptance_rate'] ?? 0);
        $downstreamAcceptance = (float) ($metrics['downstream_acceptance_rate'] ?? 0);
        $downstreamSample = (int) ($metrics['downstream_sample_size'] ?? 0);
        $policyViolations = (int) ($metrics['policy_violations'] ?? 0);
        $assuranceCalibration = (float) ($metrics['assurance_calibration'] ?? 0);
        $recentSeriousFailure = (bool) ($metrics['recent_serious_failure'] ?? false);
        $negativeOutcomeCount = (int) ($metrics['negative_outcome_count'] ?? 0);
        $recentNegativeOutcome = (bool) ($metrics['recent_negative_outcome'] ?? false);

        $eligible = $sample >= 100
            && $managerAcceptance >= 0.97
            && ($downstreamSample === 0 || $downstreamAcceptance >= 0.97)
            && $assuranceCalibration >= 0.95
            && $policyViolations === 0
            && ! $recentSeriousFailure
            && ! $recentNegativeOutcome
            && $index < count(self::LEVELS) - 1;

        return [
            'current' => $current,
            'eligible' => $eligible,
            'recommended' => $eligible ? self::LEVELS[$index + 1] : $current,
            'authority_changed' => false,
            'autonomy_changed' => false,
            'reason_codes' => array_values(array_filter([
                $sample < 100 ? 'INSUFFICIENT_SAMPLE' : null,
                $managerAcceptance < 0.97 ? 'MANAGER_ACCEPTANCE_BELOW_THRESHOLD' : null,
                $downstreamSample > 0 && $downstreamAcceptance < 0.97 ? 'DOWNSTREAM_ACCEPTANCE_BELOW_THRESHOLD' : null,
                $assuranceCalibration < 0.95 ? 'ASSURANCE_CALIBRATION_BELOW_THRESHOLD' : null,
                $policyViolations > 0 ? 'POLICY_VIOLATIONS_PRESENT' : null,
                $recentSeriousFailure ? 'RECENT_SERIOUS_FAILURE' : null,
                $recentNegativeOutcome || $negativeOutcomeCount > 0 ? 'RECENT_NEGATIVE_OUTCOME' : null,
                $index >= count(self::LEVELS) - 1 ? 'MAX_MATURITY_REACHED' : null,
            ])),
            'note' => 'Maturity is organisational experience only. Titan Autonomy remains the authority source.',
        ];
    }
}
