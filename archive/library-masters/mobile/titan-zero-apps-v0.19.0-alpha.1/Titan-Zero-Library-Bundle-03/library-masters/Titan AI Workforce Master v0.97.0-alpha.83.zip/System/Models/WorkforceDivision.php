<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkforceDivision extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_divisions';
    protected $guarded = [];
    protected $casts = ['metadata' => 'array', 'is_active' => 'boolean'];
    protected $appends = []; // division_definition_id is a persisted canonical binding.

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function organisation(): BelongsTo { return $this->belongsTo(WorkforceOrganisation::class, 'organisation_id'); }
    public function definition(): BelongsTo { return $this->belongsTo(WorkforceDivisionDefinition::class, 'division_definition_id', 'division_definition_id'); }
    public function teams(): HasMany { return $this->hasMany(WorkforceTeam::class, 'division_id'); }
    public function members(): HasMany { return $this->hasMany(WorkforceMember::class, 'division_id'); }
}
