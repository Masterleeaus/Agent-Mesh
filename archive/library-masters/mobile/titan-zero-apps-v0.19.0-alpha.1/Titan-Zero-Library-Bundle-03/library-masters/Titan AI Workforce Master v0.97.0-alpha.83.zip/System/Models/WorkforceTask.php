<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceWorkItemVerificationState;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeIdentity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkforceTask extends Model
{
    use SoftDeletes;
    protected $table = 'ext_titan_ai_workforce_tasks';
    protected $guarded = [];
    protected $casts = [
        'status' => WorkforceTaskStatus::class,
        'payload' => 'array', 'result' => 'array', 'evidence' => 'array', 'governance' => 'array',
        'expected_outcome' => 'array', 'evidence_requirements' => 'array', 'verification_state' => WorkforceWorkItemVerificationState::class, 'critical_path' => 'boolean', 'blocked_by_graph' => 'boolean',
        'risk_snapshot' => 'array', 'assurance_snapshot' => 'array', 'autonomy_snapshot' => 'array', 'knowledge_preflight' => 'array',
        'metadata' => 'array', 'role_definition_snapshot' => 'array', 'role_definition_deprecated_at' => 'datetime', 'role_definition_grace_until' => 'datetime',
        'scheduled_at' => 'datetime', 'deadline_at' => 'datetime',
        'started_at' => 'datetime', 'completed_at' => 'datetime', 'last_activity_at' => 'datetime',
    ];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function runtimeIdentity(?WorkforceMember $member = null, ?int $userId = null): RuntimeIdentity { return RuntimeIdentity::fromTask($this, $member, $userId); }
    public function organisation(): BelongsTo { return $this->belongsTo(WorkforceOrganisation::class, 'organisation_id'); }
    public function goal(): BelongsTo { return $this->belongsTo(WorkforceGoal::class, 'goal_id'); }
    public function parent(): BelongsTo { return $this->belongsTo(self::class, 'parent_task_id'); }
    public function children(): HasMany { return $this->hasMany(self::class, 'parent_task_id'); }
    public function assignee(): BelongsTo { return $this->belongsTo(WorkforceMember::class, 'assignee_member_id'); }
    public function manager(): BelongsTo { return $this->belongsTo(WorkforceMember::class, 'manager_member_id'); }
    public function division(): BelongsTo { return $this->belongsTo(WorkforceDivision::class, 'division_id'); }
    public function team(): BelongsTo { return $this->belongsTo(WorkforceTeam::class, 'team_id'); }
    public function history(): HasMany { return $this->hasMany(WorkforceTaskHistory::class, 'task_id'); }
    public function handoffs(): HasMany { return $this->hasMany(WorkforceTaskHandoff::class, 'task_id'); }
    public function executionAttempts(): HasMany { return $this->hasMany(WorkforceExecutionAttempt::class, 'task_id'); }
    public function journeyRecords(): HasMany { return $this->hasMany(WorkforceJourneyRecord::class, 'task_id'); }
}
