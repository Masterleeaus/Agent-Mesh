<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceRelationshipType: string
{
    case ReportsTo = 'reports_to';
    case Manages = 'manages';
    case Coordinates = 'coordinates';
    case Consults = 'consults';
    case Informs = 'informs';
    case DelegatesTo = 'delegates_to';
    case ReviewsFor = 'reviews_for';
    case HandsOffTo = 'hands_off_to';
    case EscalatesTo = 'escalates_to';
    case CollaboratesWith = 'collaborates_with';
    case SubstitutesFor = 'substitutes_for';
}
