<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceJourneyRecord;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;

final class WorkforcePerformanceService
{
    public function __construct(private readonly WorkforceMaturityService $maturity) {}

    public function forCompany(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->with('division:id,key,name')->orderBy('tier')->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member) => (bool) data_get($member->metadata ?? [], 'internal', false));

        return [
            'company_id' => $companyId,
            'members' => $members->map(fn (WorkforceMember $member) => $this->forMember($member))->values()->all(),
        ];
    }

    public function forMember(WorkforceMember $member): array
    {
        $tasks = WorkforceTask::query()->forCompany((int) $member->company_id)->where('assignee_member_id', $member->id)->get();
        $taskIds = $tasks->pluck('id')->all();
        $history = $taskIds === [] ? collect() : WorkforceTaskHistory::query()->where('company_id', $member->company_id)->whereIn('task_id', $taskIds)->get();

        $managerApproved = $history->where('event', 'manager.approved')->count();
        $managerRevisions = $history->where('event', 'manager.revision_required')->count();
        $handoffAccepted = $history->where('event', 'handoff.accepted')->count();
        $handoffReturned = $history->where('event', 'handoff.returned')->count();
        $managerAcceptanceRate = $this->ratio($managerApproved, $managerApproved + $managerRevisions);
        $downstreamSample = $handoffAccepted + $handoffReturned;
        $downstreamAcceptanceRate = $this->ratio($handoffAccepted, $downstreamSample);

        $calibration = $tasks->map(function (WorkforceTask $task) {
            $value = data_get($task->governance ?? [], 'post_execution.assurance_calibration');
            if ($value === null) $value = data_get($task->assurance_snapshot ?? [], 'calibration');
            return is_numeric($value) ? (float) $value : null;
        })->filter(fn ($value) => $value !== null);
        $assuranceCalibration = $calibration->count() > 0 ? round((float) $calibration->avg(), 4) : 0.0;

        $policyViolations = $history->filter(fn (WorkforceTaskHistory $row) => str_starts_with((string) $row->event, 'policy.violation'))->count();
        $outcomes = $taskIds === [] ? collect() : WorkforceJourneyRecord::query()
            ->forCompany((int) $member->company_id)->whereIn('task_id', $taskIds)->where('phase', 'OUTCOME')->get();
        $verifiedOutcomeCount = $outcomes->count();
        $negativeOutcomeCount = $outcomes->filter(fn (WorkforceJourneyRecord $row) => data_get($row->summary ?? [], 'outcome_success') === false)->count();
        $recentNegativeOutcome = $outcomes->filter(fn (WorkforceJourneyRecord $row) => data_get($row->summary ?? [], 'outcome_success') === false && optional($row->observed_at)->gte(now()->subDays(30)))->isNotEmpty();
        $recentSeriousFailure = $tasks->filter(function (WorkforceTask $task) {
            $status = is_object($task->status) ? $task->status->value : (string) $task->status;
            return in_array($status, ['FAILED','RECOVERY','ESCALATED'], true)
                && in_array(strtoupper((string) $task->risk_level), ['HIGH','EXTREME'], true)
                && optional($task->updated_at)->gte(now()->subDays(30));
        })->isNotEmpty();

        $sampleSize = $managerApproved + $managerRevisions;
        $metrics = [
            'sample_size' => $sampleSize,
            'manager_acceptance_rate' => $managerAcceptanceRate,
            'downstream_acceptance_rate' => $downstreamAcceptanceRate,
            'downstream_sample_size' => $downstreamSample,
            'assurance_calibration' => $assuranceCalibration,
            'policy_violations' => $policyViolations,
            'recent_serious_failure' => $recentSeriousFailure,
            'verified_outcome_count' => $verifiedOutcomeCount,
            'negative_outcome_count' => $negativeOutcomeCount,
            'recent_negative_outcome' => $recentNegativeOutcome,
        ];
        $maturity = $this->maturity->evaluate($member, $metrics);

        return [
            'member_id' => $member->id,
            'name' => $member->name,
            'role' => $member->role,
            'division' => $member->division?->name,
            'role_definition_id' => $member->role_definition_id,
            'open_tasks' => $tasks->filter(fn (WorkforceTask $task) => ! in_array(is_object($task->status) ? $task->status->value : (string) $task->status, ['COMPLETED','FAILED','CANCELLED','REJECTED'], true))->count(),
            'completed_tasks' => $tasks->filter(fn (WorkforceTask $task) => (is_object($task->status) ? $task->status->value : (string) $task->status) === 'COMPLETED')->count(),
            'revisions' => $managerRevisions + $handoffReturned,
            'manager_acceptance_rate' => $managerAcceptanceRate,
            'downstream_acceptance_rate' => $downstreamAcceptanceRate,
            'downstream_sample_size' => $downstreamSample,
            'assurance_calibration' => $assuranceCalibration,
            'policy_violations' => $policyViolations,
            'recent_serious_failure' => $recentSeriousFailure,
            'verified_outcome_count' => $verifiedOutcomeCount,
            'negative_outcome_count' => $negativeOutcomeCount,
            'recent_negative_outcome' => $recentNegativeOutcome,
            'maturity' => $maturity,
            'authority_changed' => false,
        ];
    }

    private function ratio(int $accepted, int $total): float
    {
        return $total > 0 ? round($accepted / $total, 4) : 0.0;
    }
}
