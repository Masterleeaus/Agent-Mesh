<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceDecisionChainState;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceProcessingCheckpointState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceProcessingLifecycleService
{
    /** @var array<string,list<string>> */
    private const TRANSITIONS = [
        'PENDING' => ['PROCESSING','SUPERSEDED'],
        'PROCESSING' => ['PASSED','REJECTED','NEEDS_INFO','DISAGREED','ESCALATED','SUPERSEDED'],
        'NEEDS_INFO' => ['PROCESSING','ESCALATED','SUPERSEDED'],
        'DISAGREED' => ['PROCESSING','ESCALATED','SUPERSEDED'],
        'ESCALATED' => ['PROCESSING','PASSED','REJECTED','SUPERSEDED'],
        'PASSED' => [],
        'REJECTED' => [],
        'SUPERSEDED' => [],
    ];

    public function claim(WorkforceProcessingCheckpoint $checkpoint, WorkforceMember $owner, int $timeoutMinutes = 30): WorkforceProcessingCheckpoint
    {
        return DB::transaction(function () use ($checkpoint,$owner,$timeoutMinutes): WorkforceProcessingCheckpoint {
            $locked=$this->lock($checkpoint);
            $this->assertCompany($locked,$owner);
            $this->assertPriorStagePassed($locked);

            if ($locked->status === WorkforceProcessingCheckpointState::Processing
                && (int)$locked->owner_member_id !== (int)$owner->getKey()) {
                throw new RuntimeException('PROCESSING_STAGE_ALREADY_OWNED');
            }

            if (!in_array($locked->status->value,['PENDING','NEEDS_INFO','DISAGREED','ESCALATED','PROCESSING'],true)) {
                throw new RuntimeException('PROCESSING_STAGE_NOT_CLAIMABLE');
            }

            $attempts=(int)$locked->attempt_count;
            if ($locked->status !== WorkforceProcessingCheckpointState::Processing) $attempts++;
            if ($attempts > max(1,(int)$locked->max_attempts)) {
                throw new RuntimeException('PROCESSING_STAGE_MAX_ATTEMPTS_EXCEEDED');
            }

            $from=$locked->status;
            $locked->forceFill([
                'status'=>WorkforceProcessingCheckpointState::Processing,
                'owner_member_id'=>$owner->getKey(),
                'attempt_count'=>$attempts,
                'started_at'=>$locked->started_at ?? now(),
                'due_at'=>now()->addMinutes(max(1,min($timeoutMinutes,1440))),
                'last_transition_at'=>now(),
                'status_reason'=>null,
                'revision'=>(int)$locked->revision+1,
                'claim_token'=>$locked->claim_token ?: (string)Str::uuid(),
            ])->save();
            $this->syncChainState($locked,WorkforceProcessingCheckpointState::Processing);
            $this->event($locked,'STAGE_CLAIMED',$owner,$from,WorkforceProcessingCheckpointState::Processing);
            return $locked->refresh();
        },3);
    }

    public function transition(
        WorkforceProcessingCheckpoint $checkpoint,
        WorkforceProcessingCheckpointState $to,
        ?WorkforceMember $actor = null,
        ?string $reason = null,
        array $evidence = []
    ): WorkforceProcessingCheckpoint {
        return DB::transaction(function () use ($checkpoint,$to,$actor,$reason,$evidence): WorkforceProcessingCheckpoint {
            $locked=$this->lock($checkpoint);
            if ($actor) $this->assertCompany($locked,$actor);
            $from=$locked->status;
            if ($from === $to) return $locked;
            if (!in_array($to->value,self::TRANSITIONS[$from->value] ?? [],true)) {
                throw new RuntimeException('INVALID_PROCESSING_STAGE_TRANSITION:'.$from->value.'->'.$to->value);
            }
            if ($to !== WorkforceProcessingCheckpointState::Processing && $from === WorkforceProcessingCheckpointState::Pending) {
                throw new RuntimeException('PROCESSING_STAGE_MUST_BE_CLAIMED_BEFORE_DECISION');
            }

            $locked->forceFill([
                'status'=>$to,
                'status_reason'=>$reason,
                'last_transition_at'=>now(),
                'reviewed_at'=>$to->terminal() ? now() : $locked->reviewed_at,
                'decision'=>$evidence!==[] ? array_merge((array)($locked->decision ?? []),$evidence) : $locked->decision,
                'revision'=>(int)$locked->revision+1,
            ])->save();

            $this->syncChainState($locked,$to);
            $this->event($locked,'STAGE_'.$to->value,$actor,$from,$to,['reason'=>$reason,'evidence'=>$evidence]);
            return $locked->refresh();
        },3);
    }

    public function retry(WorkforceProcessingCheckpoint $checkpoint, WorkforceMember $owner, ?string $reason = null): WorkforceProcessingCheckpoint
    {
        if (!in_array($checkpoint->status,[WorkforceProcessingCheckpointState::NeedsInfo,WorkforceProcessingCheckpointState::Disagreed,WorkforceProcessingCheckpointState::Escalated],true)) {
            throw new RuntimeException('PROCESSING_STAGE_NOT_RETRYABLE');
        }
        return $this->claim($checkpoint,$owner,(int)data_get($checkpoint->metadata ?? [],'timeout_minutes',30));
    }

    public function expireOverdue(int $companyId): int
    {
        $count=0;
        WorkforceProcessingCheckpoint::query()->forCompany($companyId)
            ->where('status',WorkforceProcessingCheckpointState::Processing->value)
            ->whereNotNull('due_at')->where('due_at','<',now())
            ->orderBy('id')->chunkById(100,function ($rows) use (&$count): void {
                foreach($rows as $row) {
                    $this->transition($row,WorkforceProcessingCheckpointState::Escalated,null,'stage-timeout',[
                        'timeout'=>true,'due_at'=>$row->due_at?->toISOString(),
                    ]);
                    $count++;
                }
            });
        return $count;
    }

    public function assertPriorStagePassed(WorkforceProcessingCheckpoint $checkpoint): void
    {
        if ((int)$checkpoint->stage <= 1) return;
        $previous=WorkforceProcessingCheckpoint::query()
            ->forCompany((int)$checkpoint->company_id)
            ->where('processing_id',$checkpoint->processing_id)
            ->where('stage',(int)$checkpoint->stage-1)
            ->first();
        if (!$previous || $previous->status !== WorkforceProcessingCheckpointState::Passed) {
            throw new RuntimeException('DOWNSTREAM_STAGE_BLOCKED_BY_PRIOR_STAGE');
        }
    }

    private function syncChainState(WorkforceProcessingCheckpoint $checkpoint, WorkforceProcessingCheckpointState $state): void
    {
        $chain=WorkforceDecisionChain::query()->forCompany((int)$checkpoint->company_id)
            ->where('processing_id',$checkpoint->processing_id)->first();
        if (!$chain) return;

        $map=match($state) {
            WorkforceProcessingCheckpointState::NeedsInfo => WorkforceDecisionChainState::NeedsInformation,
            WorkforceProcessingCheckpointState::Disagreed => WorkforceDecisionChainState::Disagreed,
            WorkforceProcessingCheckpointState::Escalated => WorkforceDecisionChainState::Escalated,
            WorkforceProcessingCheckpointState::Superseded => WorkforceDecisionChainState::Superseded,
            default => null,
        };
        if ($map) {
            $chain->forceFill([
                'state'=>$map,
                'organisationally_approved'=>false,
                'authority_gates_ready'=>false,
            ])->save();
        }
    }

    private function lock(WorkforceProcessingCheckpoint $checkpoint): WorkforceProcessingCheckpoint
    {
        return WorkforceProcessingCheckpoint::query()->forCompany((int)$checkpoint->company_id)
            ->whereKey($checkpoint->getKey())->lockForUpdate()->firstOrFail();
    }

    private function assertCompany(WorkforceProcessingCheckpoint $checkpoint, WorkforceMember $member): void
    {
        if ((int)$checkpoint->company_id !== (int)$member->company_id) throw new RuntimeException('PROCESSING_STAGE_COMPANY_MISMATCH');
    }

    private function event(
        WorkforceProcessingCheckpoint $checkpoint,
        string $eventType,
        ?WorkforceMember $actor,
        WorkforceProcessingCheckpointState $from,
        WorkforceProcessingCheckpointState $to,
        array $evidence = []
    ): void {
        $chain=WorkforceDecisionChain::query()->forCompany((int)$checkpoint->company_id)
            ->where('processing_id',$checkpoint->processing_id)->first();
        if (!$chain) return;
        DB::table('ext_titan_ai_workforce_decision_chain_events')->insert([
            'company_id'=>$checkpoint->company_id,'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$checkpoint->processing_id,'stage'=>$checkpoint->stage,
            'event_type'=>$eventType,'actor_member_id'=>$actor?->getKey(),
            'from_state'=>$from->value,'to_state'=>$to->value,
            'evidence'=>json_encode($evidence,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'occurred_at'=>now(),'created_at'=>now(),'updated_at'=>now(),
        ]);
    }
}
