<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceProcessingCheckpointState;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class WorkforceProcessingCheckpoint extends Model
{
    protected $table = 'ext_titan_ai_workforce_processing_checkpoints';
    protected $guarded = [];
    protected $casts = [
        'status'=>WorkforceProcessingCheckpointState::class,
        'decision'=>'array','reviewed_at'=>'datetime','metadata'=>'array',
        'started_at'=>'datetime','due_at'=>'datetime','last_transition_at'=>'datetime',
        'attempt_count'=>'integer','max_attempts'=>'integer','revision'=>'integer',
    ];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }

    public function task(): BelongsTo
    {
        return $this->belongsTo(WorkforceTask::class, 'task_id');
    }
}
