<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\TitanZeroSystemRole;
use InvalidArgumentException;

/**
 * Titan Zero coordinates the organisation but never receives an exceptional
 * execution path. Any consequential action still requires Risk, Assurance,
 * Governance and Autonomy through the standard Workforce execution pipeline.
 */
final class TitanZeroAuthorityGuard
{
    public const REASON = 'CONSEQUENTIAL_EXECUTION_REQUIRES_STANDARD_GOVERNANCE';

    public function isTitanZero(WorkforceMember $member): bool
    {
        return (string) $member->role_definition_id === TitanZeroSystemRole::ROLE_DEFINITION_ID
            || (string) ($member->system_role_key ?? '') === TitanZeroSystemRole::KEY;
    }

    /** @param array<string,mixed> $command */
    public function assertStandardGovernancePath(WorkforceTask $task, WorkforceMember $actor, array $command): void
    {
        if (! $this->isTitanZero($actor)) return;

        $sources = [$command, (array) ($task->payload ?? []), (array) ($task->metadata ?? []), (array) ($task->governance ?? [])];
        $forbidden = [
            'bypass_risk', 'skip_risk',
            'bypass_assurance', 'skip_assurance',
            'bypass_governance', 'skip_governance',
            'bypass_autonomy', 'skip_autonomy',
            'bypass_permission', 'skip_permission',
            'bypass_entitlement', 'skip_entitlement',
            'bypass_cost_sovereignty', 'skip_cost_sovereignty',
            'bypass_privacy', 'skip_privacy',
            'force_authority', 'override_authority', 'force_execute',
        ];
        foreach ($sources as $source) {
            foreach ($forbidden as $key) {
                if (($source[$key] ?? false) === true || data_get($source, 'bypass.'.$key, false) === true) {
                    throw new InvalidArgumentException(self::REASON.': Titan Zero cannot bypass permission, entitlement, Risk, Assurance, Governance, Autonomy, cost-sovereignty or privacy gates.');
                }
            }
        }
    }
}
