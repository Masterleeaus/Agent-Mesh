<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceReviewerCombinationLearning extends Model
{
    protected $table='ext_titan_ai_workforce_reviewer_combination_learning';
    protected $guarded=[];
    protected $casts=[
        'reviewer_signature'=>'array','sample_size'=>'integer','success_rate'=>'decimal:2',
        'disagreement_rate'=>'decimal:2','authority_denial_rate'=>'decimal:2','overturn_rate'=>'decimal:2',
        'average_latency_seconds'=>'decimal:2','quality_score'=>'decimal:2','calculated_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
