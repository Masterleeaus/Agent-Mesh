<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/**
 * Canonical catalogue of the supplied Titan ecosystem execution surfaces.
 *
 * This registry is descriptive until the owning provider is actually installed.
 * It never grants authority: Workforce owns roles; providers own their surfaces;
 * Risk/Assurance/Governance/Autonomy remain the execution decision boundary.
 */
final class WorkforceEcosystemCapabilityRegistry
{
    private const DEFAULT_CATALOG = __DIR__ . '/../../resources/workforce/ecosystem-capability-registry.json';
    private const DEFAULT_ALIASES = __DIR__ . '/../../resources/workforce/ecosystem-provider-aliases.json';

    /** @var array<string,mixed>|null */
    private ?array $catalog = null;
    /** @var array<string,string>|null */
    private ?array $aliases = null;

    public function __construct(
        private readonly ?string $catalogPath = null,
        private readonly ?string $aliasesPath = null,
    ) {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->catalog !== null) return $this->catalog;
        $path = $this->catalogPath ?: self::DEFAULT_CATALOG;
        $decoded = $this->decodeJsonFile($path);
        if (($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['providers'] ?? null)) {
            throw new RuntimeException('Titan Workforce ecosystem capability catalogue is invalid.');
        }
        return $this->catalog = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public function providers(): array
    {
        /** @var list<array<string,mixed>> $providers */
        $providers = array_values(array_filter($this->all()['providers'], 'is_array'));
        return $providers;
    }

    /** @return array<string,mixed>|null */
    public function provider(string $providerKey): ?array
    {
        $canonical = $this->canonicalProviderKey($providerKey);
        foreach ($this->providers() as $provider) {
            if ((string) ($provider['extension']['key'] ?? '') === $canonical) return $provider;
        }
        return null;
    }

    public function canonicalProviderKey(string $providerKey): string
    {
        $key = strtolower(trim($providerKey));
        if ($key === '') return '';
        return $this->aliasMap()[$key] ?? $key;
    }

    /**
     * Return provider-qualified ownership records for one capability identifier.
     * Catalogue ownership is provenance, never autonomous execution authority.
     *
     * @return list<array{provider:string,version:string,authority:string,capability:array<string,mixed>}>
     */
    public function capabilityOwners(string $capabilityId, bool $authoritativeOnly = false): array
    {
        $needle = trim($capabilityId);
        if ($needle === '') return [];
        $owners = [];
        foreach ($this->providers() as $provider) {
            $key = (string) ($provider['extension']['key'] ?? '');
            $version = (string) ($provider['extension']['version'] ?? '');
            foreach ((array) ($provider['capabilities'] ?? []) as $capability) {
                if (! is_array($capability)) continue;
                $id = (string) ($capability['id'] ?? $capability['name'] ?? '');
                if ($id !== $needle) continue;
                $authority = (string) ($capability['authority'] ?? 'informational');
                if ($authoritativeOnly && $authority !== 'authoritative') continue;
                $owners[] = ['provider' => $key, 'version' => $version, 'authority' => $authority, 'capability' => $capability];
            }
        }
        return $owners;
    }

    /**
     * Runtime contributions are fail-closed: a catalogue provider contributes only
     * when its declared provider class exists in the host application.
     *
     * @return array<string,array<string,mixed>> keyed by canonical provider key
     */
    public function installedContributions(): array
    {
        $installed = [];
        foreach ($this->providers() as $provider) {
            if (($provider['runtime']['availability_requires_installed_provider'] ?? null) !== true) continue;
            $providerClass = trim((string) ($provider['extension']['provider_class'] ?? ''));
            if ($providerClass === '' || ! class_exists($providerClass)) continue;
            $key = (string) ($provider['extension']['key'] ?? '');
            if ($key === '') continue;
            $contribution = $this->asContribution($provider);
            WorkforceCapabilityBindingValidator::assertValid($contribution);
            $installed[$key] = $contribution;
        }
        ksort($installed);
        return $installed;
    }

    /** @return array<string,string> */
    private function aliasMap(): array
    {
        if ($this->aliases !== null) return $this->aliases;
        $path = $this->aliasesPath ?: self::DEFAULT_ALIASES;
        $decoded = $this->decodeJsonFile($path);
        $aliases = [];
        foreach ((array) ($decoded['aliases'] ?? []) as $from => $to) {
            if (! is_string($from) || ! is_string($to)) continue;
            $from = strtolower(trim($from));
            $to = strtolower(trim($to));
            if ($from !== '' && $to !== '') $aliases[$from] = $to;
        }
        return $this->aliases = $aliases;
    }

    /** @param array<string,mixed> $provider @return array<string,mixed> */
    private function asContribution(array $provider): array
    {
        return [
            'schema_version' => '1.0',
            'extension' => [
                'key' => (string) ($provider['extension']['key'] ?? ''),
                'version' => (string) ($provider['extension']['version'] ?? ''),
            ],
            'ownership' => [
                'organisation_owner' => 'titan-ai-workforce',
                'provider_owns_execution_surfaces' => true,
                'role_definitions_owned_by_provider' => false,
            ],
            'role_bindings' => array_values((array) ($provider['role_bindings'] ?? [])),
            'capabilities' => array_values((array) ($provider['capabilities'] ?? [])),
            'tools' => array_values((array) ($provider['tools'] ?? [])),
            'commands' => array_values((array) ($provider['commands'] ?? [])),
            'signals' => array_values((array) ($provider['signals'] ?? [])),
            'data_sources' => array_values((array) ($provider['data_sources'] ?? [])),
            'workflows' => array_values((array) ($provider['workflows'] ?? [])),
            '_catalogue' => [
                'source' => 'full_ecosystem_capability_registry_v1',
                'provider_class' => (string) ($provider['extension']['provider_class'] ?? ''),
                'archive_sha256' => (string) ($provider['provenance']['archive_sha256'] ?? ''),
                'availability_requires_installed_provider' => true,
                'catalogue_grants_authority' => false,
            ],
        ];
    }

    /** @return array<string,mixed> */
    private function decodeJsonFile(string $path): array
    {
        if (! is_file($path)) throw new RuntimeException("Titan Workforce ecosystem registry file missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true);
        if (! is_array($decoded)) throw new RuntimeException("Titan Workforce ecosystem registry JSON invalid: {$path}");
        return $decoded;
    }
}
