<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceDecisionChainState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFederation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDomainHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceCrossDomainFederationService
{
    public function __construct(
        private readonly WorkforceFederatedRecoveryService $recovery,
        private readonly WorkforceConcurrencyGuardService $concurrency,
    ) {}

    public function attach(WorkforceDecisionChain $chain,array $request): ?WorkforceChainFederation
    {
        $path=$this->normalizePath($chain,$request);
        if(count($path)<4) return null;

        return DB::transaction(function() use($chain,$path): WorkforceChainFederation {
            $existing=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
                ->where('decision_chain_id',$chain->getKey())->lockForUpdate()->first();
            if($existing) return $existing;

            $federation=WorkforceChainFederation::query()->create([
                'federation_uuid'=>(string)Str::uuid(),
                'company_id'=>(int)$chain->company_id,
                'decision_chain_id'=>$chain->getKey(),
                'root_processing_id'=>$chain->processing_id,
                'domain_path'=>$path,
                'handoff_count'=>count($path)-1,
                'accepted_handoff_count'=>0,
                'status'=>'PENDING',
            ]);

            for($i=0;$i<count($path)-1;$i++){
                WorkforceDomainHandoff::query()->create([
                    'handoff_uuid'=>(string)Str::uuid(),
                    'company_id'=>(int)$chain->company_id,
                    'federation_id'=>$federation->getKey(),
                    'decision_chain_id'=>$chain->getKey(),
                    'root_processing_id'=>$chain->processing_id,
                    'sequence'=>$i+1,
                    'from_domain'=>$path[$i],
                    'to_domain'=>$path[$i+1],
                    'status'=>'PENDING',
                ]);
            }
            return $federation;
        },3);
    }

    public function markCoreStagesAccepted(WorkforceDecisionChain $chain): void
    {
        $federation=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
            ->where('decision_chain_id',$chain->getKey())->first();
        if(!$federation) return;

        $processing=(string)$chain->processing_domain;
        $receiving=(string)$chain->receiving_domain;
        $path=(array)$federation->domain_path;
        $upTo=0;
        foreach($path as $idx=>$domain){
            if((string)$domain===$receiving){$upTo=$idx;break;}
        }
        if($upTo<2) $upTo=2;

        $checkpoints=WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('stage')->get()->keyBy('stage');

        foreach(WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
            ->where('federation_id',$federation->getKey())->where('sequence','<=',$upTo)->orderBy('sequence')->get() as $handoff){
            if($handoff->status==='ACCEPTED') continue;
            $checkpoint=$handoff->sequence===1 ? $checkpoints->get(2) : $checkpoints->get(3);
            if(!$checkpoint || !$checkpoint->reviewer_member_id) continue;

            $state=[
                'from_domain'=>$handoff->from_domain,
                'to_domain'=>$handoff->to_domain,
                'root_processing_id'=>$chain->processing_id,
                'source_stage'=>(int)$checkpoint->stage,
                'decision'=>$checkpoint->decision,
            ];
            $sha=$this->sha($state);
            $acceptance=[
                'accepted'=>true,
                'acceptance_type'=>$handoff->sequence===1?'DOMAIN_PROCESSING_ACCEPTANCE':'RECEIVING_DOMAIN_ACCEPTANCE',
                'reviewer_member_id'=>(int)$checkpoint->reviewer_member_id,
                'checkpoint_uuid'=>$checkpoint->checkpoint_uuid,
                'packet_sha256'=>data_get($checkpoint->decision ?? [],'action_review_packet.packet_sha256'),
                'accepted_at'=>now()->toIso8601String(),
            ];
            $handoff->forceFill([
                'status'=>'ACCEPTED',
                'accepted_by_member_id'=>$checkpoint->reviewer_member_id,
                'source_checkpoint_id'=>$checkpoint->getKey(),
                'incoming_state'=>$state,
                'incoming_state_sha256'=>$sha,
                'acceptance'=>$acceptance,
                'acceptance_sha256'=>$this->sha($acceptance),
                'knowledge_authority_receipt'=>$chain->knowledge_receipt,
                'offered_at'=>$checkpoint->reviewed_at ?? now(),
                'accepted_at'=>$checkpoint->reviewed_at ?? now(),
            ])->save();
        }
        $this->refreshFederation($federation);
    }

    /** @param array<string,mixed> $incomingState @param array<string,mixed> $acceptance */
    public function acceptNext(
        WorkforceDecisionChain $chain,
        WorkforceMember $reviewer,
        array $incomingState,
        array $acceptance
    ): WorkforceDomainHandoff {
        $federation=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
            ->where('decision_chain_id',$chain->getKey())->firstOrFail();

        $expectedHandoffUuid=trim((string)($acceptance['expected_handoff_uuid'] ?? ''));
        $operationKey=trim((string)($acceptance['operation_key'] ?? ''));
        if($expectedHandoffUuid==='') throw new RuntimeException('FEDERATED_HANDOFF_EXPECTED_UUID_REQUIRED');
        if($operationKey==='') throw new RuntimeException('FEDERATED_HANDOFF_IDEMPOTENCY_KEY_REQUIRED');

        $operation=$this->concurrency->begin(
            (int)$chain->company_id,
            'federation:'.$federation->federation_uuid.':'.$operationKey,
            'FEDERATED_HANDOFF_ACCEPT',
            ['expected_handoff_uuid'=>$expectedHandoffUuid,'incoming_state'=>$incomingState,'acceptance'=>$acceptance]
        );
        if($operation['replayed']){
            return WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                ->where('federation_id',$federation->getKey())->where('handoff_uuid',$expectedHandoffUuid)->firstOrFail();
        }

        return DB::transaction(function() use($chain,$reviewer,$incomingState,$acceptance,$federation,$expectedHandoffUuid,$operation): WorkforceDomainHandoff {
            $handoff=WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                ->where('federation_id',$federation->getKey())->where('handoff_uuid',$expectedHandoffUuid)
                ->lockForUpdate()->firstOrFail();
            if($handoff->status!=='PENDING') throw new RuntimeException('FEDERATED_HANDOFF_STALE_OR_ALREADY_DECIDED');

            if((int)$reviewer->company_id !== (int)$chain->company_id) throw new RuntimeException('FEDERATED_HANDOFF_COMPANY_MISMATCH');
            if(!$reviewer->is_active) throw new RuntimeException('FEDERATED_HANDOFF_REVIEWER_INACTIVE');

            $used=array_values(array_filter(array_map('intval',
                WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                    ->where('federation_id',$federation->getKey())->whereNotNull('accepted_by_member_id')
                    ->pluck('accepted_by_member_id')->all()
            )));
            $core=WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
                ->where('processing_id',$chain->processing_id)->whereNotNull('reviewer_member_id')
                ->pluck('reviewer_member_id')->map(fn($v)=>(int)$v)->all();
            if(in_array((int)$reviewer->getKey(),array_unique(array_merge($used,$core)),true)){
                throw new RuntimeException('FEDERATED_HANDOFF_REQUIRES_INDEPENDENT_REVIEWER');
            }

            $domains=array_map('strtolower',array_values(array_map('strval',(array)data_get($reviewer->metadata ?? [],'domains',[]))));
            $roleText=strtolower((string)$reviewer->role.' '.(string)$reviewer->role_definition_id);
            if($domains!==[] && !in_array(strtolower((string)$handoff->to_domain),$domains,true)
                && !str_contains($roleText,strtolower((string)$handoff->to_domain))){
                throw new RuntimeException('FEDERATED_HANDOFF_REVIEWER_DOMAIN_MISMATCH');
            }

            if((array)$chain->knowledge_receipt===[]) throw new RuntimeException('FEDERATED_HANDOFF_REQUIRES_KNOWLEDGE_AUTHORITY_RECEIPT');
            if(trim((string)($acceptance['reason'] ?? ''))==='') throw new RuntimeException('FEDERATED_HANDOFF_ACCEPTANCE_REASON_REQUIRED');
            if((array)($acceptance['evidence_refs'] ?? [])===[]) throw new RuntimeException('FEDERATED_HANDOFF_ACCEPTANCE_EVIDENCE_REQUIRED');

            $state=array_merge($incomingState,[
                'from_domain'=>$handoff->from_domain,
                'to_domain'=>$handoff->to_domain,
                'root_processing_id'=>$chain->processing_id,
                'federation_uuid'=>$federation->federation_uuid,
                'sequence'=>(int)$handoff->sequence,
            ]);
            $sealedAcceptance=array_merge($acceptance,[
                'accepted'=>true,
                'reviewer_member_id'=>$reviewer->getKey(),
                'accepted_at'=>now()->toIso8601String(),
                'responsibility_transfer'=>[
                    'from_domain'=>$handoff->from_domain,
                    'to_domain'=>$handoff->to_domain,
                    'accepted_by_domain'=>$handoff->to_domain,
                ],
            ]);

            $handoff->forceFill([
                'status'=>'ACCEPTED','accepted_by_member_id'=>$reviewer->getKey(),
                'incoming_state'=>$state,'incoming_state_sha256'=>$this->sha($state),
                'acceptance'=>$sealedAcceptance,'acceptance_sha256'=>$this->sha($sealedAcceptance),
                'knowledge_authority_receipt'=>$chain->knowledge_receipt,
                'operation_key'=>$operation['ledger']->operation_key,
                'revision'=>(int)$handoff->revision+1,
                'offered_at'=>now(),'accepted_at'=>now(),
            ])->save();

            $this->refreshFederation($federation);
            $this->concurrency->complete(
                $operation['ledger'],'domain_handoff',(string)$handoff->handoff_uuid,
                ['status'=>'ACCEPTED','revision'=>(int)$handoff->revision,'acceptance_sha256'=>$handoff->acceptance_sha256]
            );
            return $handoff->refresh();
        },3);
    }

    public function rejectNext(
        WorkforceDecisionChain $chain,
        WorkforceMember $reviewer,
        string $reason,
        array $evidenceRefs=[],
        ?string $expectedHandoffUuid=null,
        ?string $operationKey=null
    ): WorkforceDomainHandoff
    {
        $federation=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
            ->where('decision_chain_id',$chain->getKey())->firstOrFail();

        $expectedHandoffUuid=trim((string)$expectedHandoffUuid);
        $operationKey=trim((string)$operationKey);
        if($expectedHandoffUuid==='') throw new RuntimeException('FEDERATED_HANDOFF_EXPECTED_UUID_REQUIRED');
        if($operationKey==='') throw new RuntimeException('FEDERATED_HANDOFF_IDEMPOTENCY_KEY_REQUIRED');

        $operation=$this->concurrency->begin(
            (int)$chain->company_id,
            'federation:'.$federation->federation_uuid.':'.$operationKey,
            'FEDERATED_HANDOFF_REJECT',
            ['expected_handoff_uuid'=>$expectedHandoffUuid,'reason'=>$reason,'evidence_refs'=>$evidenceRefs]
        );
        if($operation['replayed']){
            return WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                ->where('federation_id',$federation->getKey())->where('handoff_uuid',$expectedHandoffUuid)->firstOrFail();
        }

        return DB::transaction(function() use($chain,$reviewer,$reason,$evidenceRefs,$federation,$expectedHandoffUuid,$operation){
            $handoff=WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                ->where('federation_id',$federation->getKey())->where('handoff_uuid',$expectedHandoffUuid)
                ->lockForUpdate()->firstOrFail();
            if($handoff->status!=='PENDING') throw new RuntimeException('FEDERATED_HANDOFF_STALE_OR_ALREADY_DECIDED');
            if(trim($reason)==='') throw new RuntimeException('FEDERATED_HANDOFF_REJECTION_REASON_REQUIRED');

            $acceptance=[
                'accepted'=>false,'reviewer_member_id'=>$reviewer->getKey(),'reason'=>$reason,
                'evidence_refs'=>array_values($evidenceRefs),'rejected_at'=>now()->toIso8601String(),
            ];
            $handoff->forceFill([
                'status'=>'REJECTED','accepted_by_member_id'=>$reviewer->getKey(),
                'acceptance'=>$acceptance,'acceptance_sha256'=>$this->sha($acceptance),
                'operation_key'=>$operation['ledger']->operation_key,
                'revision'=>(int)$handoff->revision+1,
                'rejected_at'=>now(),
            ])->save();
            $federation->forceFill(['status'=>'REJECTED'])->save();
            $chain->forceFill([
                'state'=>WorkforceDecisionChainState::Rejected,
                'organisationally_approved'=>false,'authority_gates_ready'=>false,'closed_at'=>now(),
            ])->save();

            $plan=$this->recovery->planForRejectedHandoff(
                $chain->refresh(),$federation->refresh(),$handoff->refresh(),
                ['reason'=>$reason,'evidence_refs'=>array_values($evidenceRefs)]
            );
            if($plan){
                $chain->refresh()->forceFill(['metadata'=>array_merge((array)$chain->metadata,[
                    'recovery_required'=>true,
                    'recovery_uuid'=>$plan->recovery_uuid,
                    'recovery_status'=>$plan->status,
                ])])->save();
            }

            $this->concurrency->complete(
                $operation['ledger'],'domain_handoff',(string)$handoff->handoff_uuid,
                ['status'=>'REJECTED','revision'=>(int)$handoff->revision,'acceptance_sha256'=>$handoff->acceptance_sha256]
            );
            return $handoff->refresh();
        },3);
    }

    public function isComplete(WorkforceDecisionChain $chain): bool
    {
        $f=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
            ->where('decision_chain_id',$chain->getKey())->first();
        return !$f || $f->status==='COMPLETED';
    }

    private function refreshFederation(WorkforceChainFederation $federation): void
    {
        $accepted=WorkforceDomainHandoff::query()->forCompany((int)$federation->company_id)
            ->where('federation_id',$federation->getKey())->where('status','ACCEPTED')->count();
        $rejected=WorkforceDomainHandoff::query()->forCompany((int)$federation->company_id)
            ->where('federation_id',$federation->getKey())->where('status','REJECTED')->exists();
        $complete=!$rejected && $accepted>=(int)$federation->handoff_count;

        $federation->forceFill([
            'accepted_handoff_count'=>$accepted,
            'status'=>$rejected?'REJECTED':($complete?'COMPLETED':'PENDING'),
            'completed_at'=>$complete?now():null,
        ])->save();

        if($complete){
            $chain=WorkforceDecisionChain::query()->forCompany((int)$federation->company_id)
                ->find($federation->decision_chain_id);
            if($chain && $chain->state===WorkforceDecisionChainState::PendingFederatedAcceptance){
                $chain->forceFill([
                    'state'=>WorkforceDecisionChainState::OrganisationallyApproved,
                    'organisationally_approved'=>true,'authority_gates_ready'=>true,'approved_at'=>now(),
                    'metadata'=>array_merge((array)$chain->metadata,[
                        'federation_uuid'=>$federation->federation_uuid,
                        'federated_domain_path'=>$federation->domain_path,
                        'federated_handoffs_complete'=>true,
                    ]),
                ])->save();
            }
        }
    }

    private function normalizePath(WorkforceDecisionChain $chain,array $request): array
    {
        $path=array_values(array_filter(array_map(
            fn($v)=>trim(strtolower((string)$v)),
            (array)($request['domain_path'] ?? [])
        )));
        if($path===[]){
            $path=array_values(array_filter([
                strtolower((string)$chain->origin_domain),
                strtolower((string)$chain->processing_domain),
                strtolower((string)$chain->receiving_domain),
            ]));
        }
        $out=[];
        foreach($path as $d) if($d!=='' && ($out===[] || end($out)!==$d)) $out[]=$d;
        return $out;
    }

    private function sha(array $payload): string
    {
        $sort=function($v) use (&$sort){
            if(!is_array($v)) return $v;
            if(array_is_list($v)) return array_map($sort,$v);
            ksort($v,SORT_STRING);
            foreach($v as $k=>$x)$v[$k]=$sort($x);
            return $v;
        };
        return hash('sha256',json_encode($sort($payload),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
