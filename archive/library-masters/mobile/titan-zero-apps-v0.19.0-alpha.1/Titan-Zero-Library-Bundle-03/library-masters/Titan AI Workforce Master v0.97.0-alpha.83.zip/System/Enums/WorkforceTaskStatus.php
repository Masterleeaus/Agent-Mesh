<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceTaskStatus: string
{
    case Created = 'CREATED';
    case Assigned = 'ASSIGNED';
    case Processing = 'PROCESSING';
    case Submitted = 'SUBMITTED';
    case UnderReview = 'UNDER_REVIEW';
    case Approved = 'APPROVED';
    case Rejected = 'REJECTED';
    case RevisionRequired = 'REVISION_REQUIRED';
    case HandoffPending = 'HANDOFF_PENDING';
    case ReceiverReview = 'RECEIVER_REVIEW';
    case Accepted = 'ACCEPTED';
    case Blocked = 'BLOCKED';
    case AwaitingData = 'AWAITING_DATA';
    case Executing = 'EXECUTING';
    case Recovery = 'RECOVERY';
    case Escalated = 'ESCALATED';
    case Completed = 'COMPLETED';
    case Failed = 'FAILED';
    case Cancelled = 'CANCELLED';

    public function terminal(): bool
    {
        return in_array($this, [self::Rejected, self::Completed, self::Failed, self::Cancelled], true);
    }
}
