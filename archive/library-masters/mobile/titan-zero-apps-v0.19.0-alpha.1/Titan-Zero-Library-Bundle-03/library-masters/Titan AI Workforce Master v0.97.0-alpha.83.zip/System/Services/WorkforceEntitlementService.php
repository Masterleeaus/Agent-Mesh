<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResourceEntitlement;
use Illuminate\Support\Facades\DB;

final class WorkforceEntitlementService
{
    /** @return array<string,mixed>|null */
    public function active(int $companyId, string $key): ?array
    {
        $now = now();
        $row = WorkforceResourceEntitlement::query()
            ->forCompany($companyId)->where('entitlement_key', $key)->where('enabled', true)
            ->where(fn ($q) => $q->whereNull('valid_from')->orWhere('valid_from', '<=', $now))
            ->where(fn ($q) => $q->whereNull('valid_until')->orWhere('valid_until', '>=', $now))
            ->first();
        return $row?->toArray();
    }

    public function has(int $companyId, string $key): bool { return $this->active($companyId, $key) !== null; }

    public function consume(int $companyId, string $key, float $units): bool
    {
        if ($units < 0) return false;
        return DB::transaction(function () use ($companyId, $key, $units): bool {
            $row = WorkforceResourceEntitlement::query()->forCompany($companyId)
                ->where('entitlement_key', $key)->where('enabled', true)->lockForUpdate()->first();
            if (! $row) return false;
            if ($row->usage_allowance !== null && ((float) $row->usage_used + $units) > (float) $row->usage_allowance) return false;
            $row->usage_used = (float) $row->usage_used + $units;
            $row->save();
            return true;
        });
    }
}
