<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceMemberStatus: string
{
    case Available = 'AVAILABLE';
    case Working = 'WORKING';
    case Waiting = 'WAITING';
    case Reviewing = 'REVIEWING';
    case Blocked = 'BLOCKED';
    case Escalated = 'ESCALATED';
    case Offline = 'OFFLINE';
    case Suspended = 'SUSPENDED';
}
