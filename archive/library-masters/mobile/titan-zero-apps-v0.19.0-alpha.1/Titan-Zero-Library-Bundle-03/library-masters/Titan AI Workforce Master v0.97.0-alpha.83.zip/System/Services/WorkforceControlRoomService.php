<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;

final class WorkforceControlRoomService
{
    public function __construct(
        private readonly WorkforceTrustHealthService $trustHealth,
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforcePerformanceService $performance,
        private readonly WorkforceStaffingProposalService $staffingProposals,
        private readonly WorkforceOutcomeHealthService $outcomeHealth,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
    ) {}

    public function snapshot(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->with(['division:id,key,name','manager:id,name'])->orderBy('tier')->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member) => (bool) data_get($member->metadata ?? [], 'internal', false))->values();
        $capabilityStates = $members->mapWithKeys(fn (WorkforceMember $member) => [(int) $member->id => $this->capabilityAvailability->forMember($member)]);
        $memberIds = $members->pluck('id')->all();
        $relationships = WorkforceRelationship::query()->forCompany($companyId)->where('is_active', true)
            ->when($memberIds !== [], fn ($query) => $query->whereIn('source_member_id', $memberIds)->whereIn('target_member_id', $memberIds))->get();

        $managers = $members->filter(fn (WorkforceMember $member) => $member->tier === WorkforceTier::Manager && (bool) ($member->consumes_seat ?? true))->values();
        $queues = $managers->map(fn (WorkforceMember $manager) => [
            'manager_id' => $manager->id,
            'manager' => $manager->name,
            'division' => $manager->division?->name,
            'health' => $this->queueHealth->forManager($manager),
        ])->all();

        $handoffs = WorkforceTaskHandoff::query()->forCompany($companyId)->whereIn('status', ['PENDING','RECEIVER_REVIEW','RETURNED','ESCALATED'])->latest('updated_at')->limit(40)->get();
        $approvals = WorkforceTask::query()->forCompany($companyId)->whereIn('status', ['UNDER_REVIEW','RECEIVER_REVIEW','ESCALATED'])
            ->with(['assignee:id,name','manager:id,name','division:id,key,name'])->orderByDesc('priority')->orderBy('deadline_at')->limit(60)->get();

        $outcomeRefs = WorkforceTask::query()->forCompany($companyId)->where(function ($query) {
            $query->whereNotNull('completed_at')->orWhere('status', 'RECOVERY');
        })->latest('updated_at')->limit(40)->get()->map(fn (WorkforceTask $task) => [
            'task_id' => $task->task_uuid,
            'title' => $task->title,
            'status' => is_object($task->status) ? $task->status->value : (string) $task->status,
            'trace_id' => $task->trace_id,
            'correlation_id' => $task->correlation_id,
            'receipt_ref' => data_get($task->governance ?? [], 'post_execution.receipt_ref'),
            'rewind_ref' => data_get($task->governance ?? [], 'post_execution.rewind_ref'),
            'outcome_ref' => data_get($task->governance ?? [], 'post_execution.outcome_ref'),
        ])->filter(fn (array $row) => $row['receipt_ref'] || $row['rewind_ref'] || $row['outcome_ref'] || $row['status'] === 'RECOVERY')->values()->all();

        return [
            'company_id' => $companyId,
            'organisation_graph' => [
                'nodes' => $members->map(fn (WorkforceMember $member) => [
                    'id' => $member->id, 'name' => $member->name, 'role' => $member->role,
                    'tier' => $member->tier?->value, 'division' => $member->division?->name,
                    'manager_id' => $member->manager_id, 'manager' => $member->manager?->name, 'status' => $member->status?->value,
                    'maturity' => $member->maturity_level, 'risk_ceiling' => $member->risk_ceiling,
                    'capability_state' => data_get($capabilityStates->get((int) $member->id), 'state', 'unavailable'),
                    'capability_state_detail' => $capabilityStates->get((int) $member->id),
                ])->all(),
                'edges' => $relationships->map(fn (WorkforceRelationship $edge) => [
                    'source' => $edge->source_member_id, 'target' => $edge->target_member_id,
                    'type' => $edge->relationship_type?->value, 'metadata' => $edge->metadata ?? [],
                ])->all(),
            ],
            'queues' => $queues,
            'trust_health' => $this->trustHealth->forCompany($companyId),
            'handoffs' => $handoffs,
            'approvals' => $approvals,
            'staffing' => $this->staffingProposals->list($companyId),
            'performance' => $this->performance->forCompany($companyId),
            'outcome_health' => $this->outcomeHealth->snapshot($companyId),
            'outcome_refs' => $outcomeRefs,
            'summary' => [
                'active_staff' => $members->filter(fn (WorkforceMember $member) => (bool) ($member->consumes_seat ?? true))->count(),
                'system_staff' => $members->filter(fn (WorkforceMember $member) => ! (bool) ($member->consumes_seat ?? true))->count(),
                'divisions' => WorkforceDivision::query()->forCompany($companyId)->where('is_active', true)->count(),
                'pending_approvals' => $approvals->count(),
                'open_handoffs' => $handoffs->count(),
                'staffing_recommendations' => WorkforceStaffingProposal::query()->forCompany($companyId)->where('status', 'RECOMMENDED')->count(),
                'capability_states' => $capabilityStates->countBy(fn (array $state) => (string) ($state['state'] ?? 'unavailable'))->all(),
            ],
        ];
    }
}
