<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Contracts\Container\Container;
use RuntimeException;

/** Late-bound Workforce -> Agent Runtime compatibility bridge for governed agent triggers. */
final class AgentWorkflowRuntimeBridge
{
    public const TRANSPORT = 'titan.agent-runtime.workflow/1';

    public function __construct(
        private readonly Container $app,
        private readonly RuntimeProfileBindingService $profiles,
    ) {}

    public function handles(WorkforceTask $task): bool
    {
        return $task->origin_type === 'agent_runtime_trigger'
            && data_get($task->metadata ?? [], 'agent_trigger') === true;
    }

    /** @return array<string,mixed> */
    public function perform(WorkforceTask $task, WorkforceMember $member): array
    {
        if (! $this->handles($task)) throw new RuntimeException('Workforce task is not a governed Agent trigger.');
        if ((int) $task->company_id !== (int) $member->company_id) throw new RuntimeException('Agent trigger company boundary mismatch.');
        if (! $this->app->bound(self::TRANSPORT)) throw new RuntimeException('Titan Agent Runtime agent workflow transport is unavailable.');

        $profile = $this->profiles->forTask($task, $member);
        $task = $task->refresh();
        $trigger = data_get($task->payload ?? [], 'agent_trigger', []);
        if (! is_array($trigger)) throw new RuntimeException('Agent trigger payload is invalid.');

        $request = [
            'company_id' => (int) $task->company_id,
            'user_id' => null,
            'workforce_member_id' => (int) $member->id,
            'workforce_task_id' => (int) $task->id,
            'runtime_profile_id' => (string) $profile->profile_id,
            'workflow_id' => (int) ($trigger['workflow_id'] ?? 0),
            'trigger_type' => (string) ($trigger['trigger_type'] ?? ''),
            'trigger_data' => is_array($trigger['trigger_data'] ?? null) ? $trigger['trigger_data'] : [],
            'context' => is_array($trigger['context'] ?? null) ? $trigger['context'] : [],
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => $task->causation_id ? (string) $task->causation_id : null,
            'execution_authority' => 'none',
        ];

        $transport = $this->app->make(self::TRANSPORT);
        $result = is_callable($transport) ? $transport($request) : (method_exists($transport, 'execute') ? $transport->execute($request) : null);
        if (! is_array($result)) throw new RuntimeException('Titan Agent Runtime agent workflow transport returned an invalid response.');
        if (($result['status'] ?? null) === 'failed') {
            throw new RuntimeException('Legacy Agent workflow recipe failed: ' . (string) ($result['error_message'] ?? 'unknown runtime error'));
        }
        if (($result['execution_claimed'] ?? false) === true || ($result['business_outcome_claimed'] ?? false) === true) {
            throw new RuntimeException('Legacy Agent workflow runtime attempted to claim business execution.');
        }
        return $result + ['execution_claimed' => false, 'business_outcome_claimed' => false];
    }
}
