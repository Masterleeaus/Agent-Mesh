<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceNotificationPreference extends Model
{
    protected $table = 'ext_titan_ai_workforce_notification_preferences';
    protected $guarded = [];
    protected $casts = [
        'severity_threshold' => 'integer', 'in_app' => 'boolean',
        'route_owner_admin' => 'boolean', 'route_responsible_manager' => 'boolean',
        'route_specific_team' => 'boolean', 'metadata' => 'array',
    ];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
