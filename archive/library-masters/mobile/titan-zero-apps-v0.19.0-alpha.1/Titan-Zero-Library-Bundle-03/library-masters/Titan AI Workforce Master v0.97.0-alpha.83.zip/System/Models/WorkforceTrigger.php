<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceTrigger extends Model
{
    protected $table = 'ext_titan_ai_workforce_triggers';
    protected $guarded = [];
    protected $casts = ['conditions' => 'array', 'schedule' => 'array', 'work_template' => 'array', 'is_active' => 'boolean', 'last_fired_at' => 'datetime', 'next_fire_at' => 'datetime', 'metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
