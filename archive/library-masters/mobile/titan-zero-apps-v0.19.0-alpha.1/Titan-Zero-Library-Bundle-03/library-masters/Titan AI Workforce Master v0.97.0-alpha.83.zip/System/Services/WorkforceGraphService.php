<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicRelationshipCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * Persistent company-scoped organisational graph.
 *
 * Relationship edges describe organisation and communication only. They never
 * confer executable capability, Risk, Assurance, Governance or Autonomy authority.
 */
final class WorkforceGraphService
{
    public function __construct(private readonly WorkforceManifestRegistry $registry) {}

    public function relate(WorkforceMember $source, WorkforceMember $target, WorkforceRelationshipType $type, array $metadata = []): WorkforceRelationship
    {
        $this->assertSameCompany($source, $target);
        if ((int) $source->id === (int) $target->id) {
            throw new InvalidArgumentException('SELF_RELATIONSHIP: a Workforce Member cannot relate to itself for '.$type->value.'.');
        }

        if ($type === WorkforceRelationshipType::ReportsTo) {
            $this->assertNoReportingCycle($source, $target);
        }

        // Organisational relationships never transfer execution authority.
        if (($metadata['authority_inherited'] ?? false) !== false) {
            throw new InvalidArgumentException('RELATIONSHIP_AUTHORITY_INHERITANCE_FORBIDDEN: authority_inherited must be false.');
        }
        $metadata['authority_inherited'] = false;
        if (in_array($type, [WorkforceRelationshipType::DelegatesTo, WorkforceRelationshipType::SubstitutesFor], true)) {
            $metadata['requires_existing_autonomy'] = true;
        }

        $values = ['is_active' => true, 'metadata' => $metadata];
        if (array_key_exists('relationship_definition_id', $metadata)) {
            $values['relationship_definition_id'] = $metadata['relationship_definition_id'];
        }

        return WorkforceRelationship::query()->updateOrCreate([
            'company_id' => $source->company_id,
            'source_member_id' => $source->id,
            'target_member_id' => $target->id,
            'relationship_type' => $type->value,
        ], $values);
    }

    public function setManager(WorkforceMember $member, WorkforceMember $manager): void
    {
        $this->assertSameCompany($member, $manager);
        if ((int) $member->id === (int) $manager->id) {
            throw new InvalidArgumentException('SELF_RELATIONSHIP: a Workforce Member cannot manage itself.');
        }
        if ((int) $manager->tier !== WorkforceTier::Manager->value) {
            throw new InvalidArgumentException('Reporting manager must be an active Tier 1 Manager instance.');
        }
        if (! $manager->is_active) {
            throw new InvalidArgumentException('Reporting manager must be active.');
        }

        // Legacy extension-owned RoleDefinitions remain supported until capability-binding migration.
        $definition = null;
        if ((string) ($member->role_owner_extension ?? '') !== '' && (string) ($member->role_definition_id ?? '') !== '') {
            $definition = $this->registry->findOwnedRole((string) $member->role_owner_extension, (string) $member->role_definition_id);
        }
        if (is_array($definition)) {
            $expectedManagerRole = trim((string) ($definition['reports_to'] ?? $definition['parent_manager'] ?? ''));
            if ($expectedManagerRole === '') {
                throw new InvalidArgumentException('This RoleDefinition does not permit an assigned Workforce Manager.');
            }
            if ((string) $manager->role_owner_extension !== (string) $definition['owner_extension']
                || (string) $manager->role_definition_id !== $expectedManagerRole) {
                throw new InvalidArgumentException('Reporting manager violates the extension-owned RoleDefinition reports_to contract.');
            }
        }

        $this->assertNoReportingCycle($member, $manager);

        DB::transaction(function () use ($member, $manager): void {
            $oldManagerIds = WorkforceRelationship::query()
                ->forCompany((int) $member->company_id)
                ->where('source_member_id', $member->id)
                ->where('relationship_type', WorkforceRelationshipType::ReportsTo->value)
                ->where('is_active', true)
                ->pluck('target_member_id')
                ->map(fn ($id) => (int) $id)
                ->all();

            WorkforceRelationship::query()
                ->forCompany((int) $member->company_id)
                ->where('source_member_id', $member->id)
                ->where('relationship_type', WorkforceRelationshipType::ReportsTo->value)
                ->update(['is_active' => false]);

            if ($oldManagerIds !== []) {
                WorkforceRelationship::query()
                    ->forCompany((int) $member->company_id)
                    ->whereIn('source_member_id', $oldManagerIds)
                    ->where('target_member_id', $member->id)
                    ->whereIn('relationship_type', [WorkforceRelationshipType::Manages->value, WorkforceRelationshipType::ReviewsFor->value])
                    ->update(['is_active' => false]);
            }

            $member->forceFill(['manager_id' => $manager->id])->save();
            $this->relate($member, $manager, WorkforceRelationshipType::ReportsTo, ['source' => 'explicit_manager_assignment', 'authority_inherited' => false]);
            $this->relate($manager, $member, WorkforceRelationshipType::Manages, ['source' => 'explicit_manager_assignment', 'authority_inherited' => false]);
            $this->relate($manager, $member, WorkforceRelationshipType::ReviewsFor, ['source' => 'explicit_manager_assignment', 'authority_inherited' => false]);
        });
    }

    public function deactivateRelationship(WorkforceRelationship $relationship): WorkforceRelationship
    {
        $relationship->forceFill(['is_active' => false])->save();
        return $relationship->refresh();
    }

    /** Rejects both the proposed cycle and any pre-existing corrupt manager loop. */
    public function assertNoReportingCycle(WorkforceMember $member, WorkforceMember $manager): void
    {
        $this->assertSameCompany($member, $manager);
        $targetId = (int) $member->id;
        $cursor = $manager;
        $visited = [];

        for ($depth = 0; $depth < 128; $depth++) {
            $cursorId = (int) $cursor->id;
            if ($cursorId === $targetId) {
                throw new InvalidArgumentException('REPORTING_CYCLE: manager assignment would create a reporting cycle.');
            }
            if (isset($visited[$cursorId])) {
                throw new InvalidArgumentException('REPORTING_CYCLE: existing reporting hierarchy contains a cycle.');
            }
            $visited[$cursorId] = true;
            $nextId = (int) ($cursor->manager_id ?? 0);
            if ($nextId <= 0) return;
            $next = WorkforceMember::query()->forCompany((int) $member->company_id)->find($nextId);
            if (! $next) return;
            $cursor = $next;
        }

        throw new InvalidArgumentException('REPORTING_CYCLE: reporting hierarchy exceeded safe traversal depth.');
    }

    /**
     * Materialise intrinsic role-to-role relationship definitions for members that already exist.
     * This never hires staff and never grants capability or authority.
     *
     * @return array{created_or_refreshed:int,skipped_missing_member:int}
     */
    public function synchroniseIntrinsicRelationships(int $companyId): array
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Organisational graph requires a valid company_id.');

        $members = WorkforceMember::query()->forCompany($companyId)
            ->where('is_active', true)
            ->orderBy('id')
            ->get()
            ->groupBy(fn (WorkforceMember $member): string => (string) ($member->role_definition_id ?? ''));

        $count = 0;
        $skipped = 0;
        foreach (IntrinsicRelationshipCatalog::relationships() as $definition) {
            $sourceRole = (string) ($definition['source_role_definition_id'] ?? '');
            $targetRole = (string) ($definition['target_role_definition_id'] ?? '');
            $type = WorkforceRelationshipType::tryFrom((string) ($definition['relationship_type'] ?? ''));
            if (! $type || $sourceRole === '' || $targetRole === '') continue;

            /** @var Collection<int,WorkforceMember> $sources */
            $sources = $members->get($sourceRole, collect());
            /** @var Collection<int,WorkforceMember> $targets */
            $targets = $members->get($targetRole, collect());
            if ($sources->isEmpty() || $targets->isEmpty()) {
                $skipped++;
                continue;
            }

            $metadata = [
                'source' => 'intrinsic_relationship_definition',
                'relationship_definition_id' => (string) $definition['relationship_definition_id'],
                'authority_inherited' => false,
                'requires_existing_autonomy' => in_array($type, [WorkforceRelationshipType::DelegatesTo, WorkforceRelationshipType::SubstitutesFor], true),
            ];

            if ($type === WorkforceRelationshipType::ReportsTo) {
                $manager = $targets->first();
                foreach ($sources as $source) {
                    $this->assertSameCompany($source, $manager);
                    $this->assertNoReportingCycle($source, $manager);
                    $source->forceFill(['manager_id' => $manager->id])->save();
                    $this->relate($source, $manager, $type, $metadata);
                    $count++;
                }
                continue;
            }

            if (in_array($type, [WorkforceRelationshipType::Manages, WorkforceRelationshipType::DelegatesTo], true)) {
                $source = $sources->first();
                foreach ($targets as $target) {
                    $this->relate($source, $target, $type, $metadata);
                    $count++;
                }
                continue;
            }

            $target = $targets->first();
            foreach ($sources as $source) {
                $this->relate($source, $target, $type, $metadata);
                $count++;
            }
        }

        $this->assertGraphIntegrity($companyId);
        return ['created_or_refreshed' => $count, 'skipped_missing_member' => $skipped];
    }

    /**
     * Validate persisted graph endpoints, manager pointers and reporting cycles.
     *
     * @return array{valid:bool,violations:list<array{code:string,message:string,member_id?:int,relationship_id?:int}>}
     */
    public function validateGraph(int $companyId): array
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Organisational graph requires a valid company_id.');

        $violations = [];
        $members = WorkforceMember::query()->forCompany($companyId)->get();
        $byId = $members->keyBy(fn (WorkforceMember $member): int => (int) $member->id);

        foreach ($members as $member) {
            $memberId = (int) $member->id;
            $managerId = (int) ($member->manager_id ?? 0);
            if ($managerId <= 0) continue;
            if ($managerId === $memberId) {
                $violations[] = ['code' => 'SELF_RELATIONSHIP', 'message' => 'Member manages itself.', 'member_id' => $memberId];
                continue;
            }
            $manager = WorkforceMember::query()->find($managerId);
            if (! $manager) {
                $violations[] = ['code' => 'ORPHAN_MANAGER', 'message' => 'manager_id references a missing Workforce Member.', 'member_id' => $memberId];
                continue;
            }
            if ((int) $manager->company_id !== $companyId) {
                $violations[] = ['code' => 'CROSS_COMPANY_RELATIONSHIP', 'message' => 'manager_id crosses company boundary.', 'member_id' => $memberId];
                continue;
            }
            if (! $manager->is_active) {
                $violations[] = ['code' => 'ORPHAN_MANAGER', 'message' => 'manager_id references an inactive Workforce Member.', 'member_id' => $memberId];
            }
        }

        $validTypes = array_map(static fn (WorkforceRelationshipType $type): string => $type->value, WorkforceRelationshipType::cases());
        $relationships = WorkforceRelationship::query()->forCompany($companyId)->where('is_active', true)->get();
        foreach ($relationships as $relationship) {
            $sourceId = (int) $relationship->source_member_id;
            $targetId = (int) $relationship->target_member_id;
            if ($sourceId === $targetId) {
                $violations[] = ['code' => 'SELF_RELATIONSHIP', 'message' => 'Relationship source and target are identical.', 'relationship_id' => (int) $relationship->id];
                continue;
            }
            $source = WorkforceMember::query()->find($sourceId);
            $target = WorkforceMember::query()->find($targetId);
            if (! $source || ! $target) {
                $violations[] = ['code' => 'ORPHAN_RELATIONSHIP_ENDPOINT', 'message' => 'Relationship references a missing Workforce Member.', 'relationship_id' => (int) $relationship->id];
                continue;
            }
            if ((int) $source->company_id !== $companyId || (int) $target->company_id !== $companyId) {
                $violations[] = ['code' => 'CROSS_COMPANY_RELATIONSHIP', 'message' => 'Relationship endpoint crosses company boundary.', 'relationship_id' => (int) $relationship->id];
            }
            $type = is_object($relationship->relationship_type) ? $relationship->relationship_type->value : (string) $relationship->relationship_type;
            if (! in_array($type, $validTypes, true)) {
                $violations[] = ['code' => 'INVALID_RELATIONSHIP_TYPE', 'message' => 'Relationship type is not canonical.', 'relationship_id' => (int) $relationship->id];
            }
        }

        // Detect cycles from persisted manager pointers, including pre-existing corruption.
        foreach ($members as $start) {
            $seen = [];
            $cursor = $start;
            for ($depth = 0; $depth < 128; $depth++) {
                $cursorId = (int) $cursor->id;
                if (isset($seen[$cursorId])) {
                    $violations[] = ['code' => 'REPORTING_CYCLE', 'message' => 'Persisted manager chain contains a cycle.', 'member_id' => (int) $start->id];
                    break;
                }
                $seen[$cursorId] = true;
                $managerId = (int) ($cursor->manager_id ?? 0);
                if ($managerId <= 0) break;
                $next = $byId->get($managerId);
                if (! $next) break; // orphan is reported separately above.
                $cursor = $next;
            }
        }

        // De-duplicate equivalent findings caused by walking the same corrupt cycle from multiple members.
        $unique = [];
        foreach ($violations as $violation) {
            $key = json_encode($violation, JSON_UNESCAPED_SLASHES);
            $unique[$key] = $violation;
        }
        $violations = array_values($unique);

        return ['valid' => $violations === [], 'violations' => $violations];
    }

    public function assertGraphIntegrity(int $companyId): void
    {
        $result = $this->validateGraph($companyId);
        if ($result['valid']) return;
        $codes = array_values(array_unique(array_map(static fn (array $violation): string => $violation['code'], $result['violations'])));
        throw new InvalidArgumentException('ORGANISATIONAL_GRAPH_INVALID: '.implode(',', $codes));
    }

    /** @return array{members:list<array>,relationships:list<array>} */
    public function snapshot(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)
            ->orderBy('tier')->orderBy('id')->get()
            ->map(static fn (WorkforceMember $member): array => [
                'id' => (int) $member->id,
                'key' => (string) $member->key,
                'name' => (string) $member->name,
                'tier' => (int) $member->tier,
                'division_id' => $member->division_id ? (int) $member->division_id : null,
                'team_id' => $member->team_id ? (int) $member->team_id : null,
                'manager_id' => $member->manager_id ? (int) $member->manager_id : null,
                'role_owner_extension' => $member->role_owner_extension,
                'role_definition_id' => $member->role_definition_id,
                'lifecycle_state' => is_object($member->lifecycle_state) ? $member->lifecycle_state->value : $member->lifecycle_state,
                'status' => is_object($member->status) ? $member->status->value : $member->status,
                'is_active' => (bool) $member->is_active,
            ])->values()->all();

        $relationships = WorkforceRelationship::query()->forCompany($companyId)
            ->where('is_active', true)->orderBy('id')->get()
            ->map(static fn (WorkforceRelationship $relationship): array => [
                'id' => (int) $relationship->id,
                'relationship_definition_id' => $relationship->relationship_definition_id ?? null,
                'from_member_id' => (int) $relationship->source_member_id,
                'to_member_id' => (int) $relationship->target_member_id,
                'type' => is_object($relationship->relationship_type) ? $relationship->relationship_type->value : (string) $relationship->relationship_type,
                'metadata' => $relationship->metadata ?? [],
            ])->values()->all();

        return ['members' => $members, 'relationships' => $relationships];
    }

    private function assertSameCompany(WorkforceMember $source, WorkforceMember $target): void
    {
        if ((int) $source->company_id !== (int) $target->company_id) {
            throw new InvalidArgumentException('CROSS_COMPANY_RELATIONSHIP: organisational relationship rejected.');
        }
    }
}
