<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskDependency;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

final class WorkforceDependencyService
{
    public function link(WorkforceTask $task, WorkforceTask $dependsOn, bool $blocking = true): WorkforceTaskDependency
    {
        if ((int) $task->company_id !== (int) $dependsOn->company_id) {
            throw new InvalidArgumentException('Cross-tenant Workforce dependency rejected.');
        }
        if ((int) $task->id === (int) $dependsOn->id) {
            throw new InvalidArgumentException('DEPENDENCY_CYCLE: Workforce task cannot depend on itself.');
        }

        return DB::transaction(function () use ($task, $dependsOn, $blocking) {
            WorkforceTask::query()->forCompany((int) $task->company_id)->whereKey($task->id)->lockForUpdate()->firstOrFail();
            $this->assertNoCycle($task, $dependsOn);
            return WorkforceTaskDependency::query()->updateOrCreate([
                'company_id' => $task->company_id,
                'task_id' => $task->id,
                'depends_on_task_id' => $dependsOn->id,
            ], ['blocking' => $blocking]);
        });
    }

    public function assertNoCycle(WorkforceTask $task, WorkforceTask $dependsOn): void
    {
        $companyId = (int) $task->company_id;
        $targetId = (int) $task->id;
        $queue = [(int) $dependsOn->id];
        $seen = [];
        $steps = 0;

        while ($queue !== []) {
            $current = array_shift($queue);
            if ($current === $targetId) {
                throw new InvalidArgumentException('DEPENDENCY_CYCLE: Workforce dependency would create a cycle.');
            }
            if (isset($seen[$current])) continue;
            $seen[$current] = true;
            if (++$steps > 10000) {
                throw new InvalidArgumentException('DEPENDENCY_CYCLE: dependency graph traversal limit exceeded.');
            }
            $next = WorkforceTaskDependency::query()
                ->forCompany($companyId)
                ->where('task_id', $current)
                ->pluck('depends_on_task_id');
            foreach ($next as $nextId) $queue[] = (int) $nextId;
        }
    }

    public function assertParentExists(int $companyId, ?int $parentTaskId): ?WorkforceTask
    {
        if ($parentTaskId === null) return null;
        $parent = WorkforceTask::query()->forCompany($companyId)->find($parentTaskId);
        if (! $parent) {
            throw new InvalidArgumentException('ORPHAN_PARENT: Workforce child task parent does not exist in this tenant.');
        }
        return $parent;
    }

    public function integritySnapshot(int $companyId): array
    {
        $taskIds = WorkforceTask::query()->forCompany($companyId)->pluck('id')->map(fn ($id) => (int) $id)->values()->all();
        $taskSet = array_fill_keys($taskIds, true);

        $orphanParentTaskIds = [];
        foreach (WorkforceTask::query()->forCompany($companyId)->whereNotNull('parent_task_id')->get(['id','parent_task_id']) as $task) {
            if (! isset($taskSet[(int) $task->parent_task_id])) $orphanParentTaskIds[] = (int) $task->id;
        }

        $orphanDependencyIds = [];
        $graph = [];
        foreach (WorkforceTaskDependency::query()->forCompany($companyId)->get(['id','task_id','depends_on_task_id']) as $dependency) {
            $taskId = (int) $dependency->task_id;
            $dependsOnId = (int) $dependency->depends_on_task_id;
            if (! isset($taskSet[$taskId]) || ! isset($taskSet[$dependsOnId])) {
                $orphanDependencyIds[] = (int) $dependency->id;
                continue;
            }
            $graph[$taskId][] = $dependsOnId;
        }

        $orphanHandoffIds = [];
        foreach (WorkforceTaskHandoff::query()->forCompany($companyId)->get(['id','task_id','accepted_task_id']) as $handoff) {
            if (! isset($taskSet[(int) $handoff->task_id]) || ($handoff->accepted_task_id !== null && ! isset($taskSet[(int) $handoff->accepted_task_id]))) {
                $orphanHandoffIds[] = (int) $handoff->id;
            }
        }

        $cycleTaskIds = $this->detectCycles($graph);

        return [
            'company_id' => $companyId,
            'healthy' => $orphanParentTaskIds === [] && $orphanDependencyIds === [] && $orphanHandoffIds === [] && $cycleTaskIds === [],
            'orphan_parent_task_ids' => array_values(array_unique($orphanParentTaskIds)),
            'orphan_dependency_ids' => array_values(array_unique($orphanDependencyIds)),
            'orphan_handoff_ids' => array_values(array_unique($orphanHandoffIds)),
            'dependency_cycle_task_ids' => $cycleTaskIds,
        ];
    }

    public function ready(WorkforceTask $task): bool
    {
        return $this->readyForStart($task);
    }

    public function readyForStart(WorkforceTask $task): bool
    {
        $edges = WorkforceTaskDependency::query()
            ->forCompany((int) $task->company_id)
            ->where('task_id', $task->id)
            ->where('blocking', true)
            ->get();

        foreach ($edges as $edge) {
            $type = (string) ($edge->dependency_type ?? 'finish_to_start');
            if (! in_array($type, ['finish_to_start','start_to_start'], true)) continue;
            $dependency = WorkforceTask::query()->forCompany((int) $task->company_id)->find((int) $edge->depends_on_task_id);
            if (! $dependency) return false;
            if ($dependency->status === WorkforceTaskStatus::Failed && (string) ($edge->failure_policy ?? 'block') === 'continue') {
                continue;
            }
            if ($type === 'finish_to_start' && $dependency->status !== WorkforceTaskStatus::Completed) return false;
            if ($type === 'start_to_start' && $dependency->started_at === null) return false;
            if (! $this->conditionSatisfied($edge, $dependency)) return false;
        }
        return true;
    }

    public function readyForCompletion(WorkforceTask $task): bool
    {
        $edges = WorkforceTaskDependency::query()
            ->forCompany((int) $task->company_id)
            ->where('task_id', $task->id)
            ->where('blocking', true)
            ->get();

        foreach ($edges as $edge) {
            $type = (string) ($edge->dependency_type ?? 'finish_to_start');
            if (! in_array($type, ['finish_to_finish','start_to_finish'], true)) continue;
            $dependency = WorkforceTask::query()->forCompany((int) $task->company_id)->find((int) $edge->depends_on_task_id);
            if (! $dependency) return false;
            if ($dependency->status === WorkforceTaskStatus::Failed && (string) ($edge->failure_policy ?? 'block') === 'continue') {
                continue;
            }
            if ($type === 'finish_to_finish' && $dependency->status !== WorkforceTaskStatus::Completed) return false;
            if ($type === 'start_to_finish' && $dependency->started_at === null) return false;
            if (! $this->conditionSatisfied($edge, $dependency)) return false;
        }
        return true;
    }

    private function conditionSatisfied(WorkforceTaskDependency $edge, WorkforceTask $dependency): bool
    {
        $condition = (array) ($edge->condition ?? []);
        if ($condition === []) return true;

        if (isset($condition['required_status'])
            && (string) $condition['required_status'] !== $dependency->status->value) {
            return false;
        }
        if (isset($condition['required_verification_state'])) {
            $actual = $dependency->verification_state?->value;
            if ((string) $condition['required_verification_state'] !== (string) $actual) return false;
        }
        return true;
    }

    public function dispatchReadyDependents(WorkforceTask $completed): int
    {
        $taskIds = WorkforceTaskDependency::query()
            ->forCompany((int) $completed->company_id)
            ->where('depends_on_task_id', $completed->id)
            ->where('blocking', true)
            ->pluck('task_id')
            ->unique();

        $dispatched = 0;
        foreach ($taskIds as $taskId) {
            $task = WorkforceTask::query()->forCompany((int) $completed->company_id)->find($taskId);
            if (! $task || $task->status->terminal() || $task->assignee_member_id === null || ! $this->readyForStart($task)) {
                continue;
            }
            ProcessWorkforceTaskJob::dispatch((int) $task->company_id, (int) $task->id);
            $dispatched++;
        }
        return $dispatched;
    }

    private function detectCycles(array $graph): array
    {
        $state = [];
        $cycle = [];
        $visit = function (int $node) use (&$visit, &$state, &$cycle, $graph): void {
            if (($state[$node] ?? 0) === 1) { $cycle[$node] = true; return; }
            if (($state[$node] ?? 0) === 2) return;
            $state[$node] = 1;
            foreach ($graph[$node] ?? [] as $next) {
                if (($state[$next] ?? 0) === 1) { $cycle[$node] = true; $cycle[$next] = true; continue; }
                $visit((int) $next);
                if (isset($cycle[$next])) $cycle[$node] = true;
            }
            $state[$node] = 2;
        };
        foreach (array_keys($graph) as $node) $visit((int) $node);
        $ids = array_map('intval', array_keys($cycle));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }
}
