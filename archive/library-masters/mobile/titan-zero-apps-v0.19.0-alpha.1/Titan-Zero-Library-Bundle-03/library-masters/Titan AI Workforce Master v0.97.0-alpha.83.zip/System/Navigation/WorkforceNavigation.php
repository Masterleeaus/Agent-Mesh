<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Navigation;

final class WorkforceNavigation
{
    public static function user(): array
    {
        return [
            self::item(null, 'titan_workforce', 'AI Workforce', 'dashboard.user.titan-workforce.index', 'tabler-users-group', 5, ['dashboard.user.titan-workforce.*'], 'dropdown'),
            self::item('titan_workforce', 'titan_workforce_overview', 'Overview', 'dashboard.user.titan-workforce.index', 'tabler-layout-dashboard', 1, ['dashboard.user.titan-workforce.index']),
            self::item('titan_workforce', 'titan_workforce_team', 'Team', 'dashboard.user.titan-workforce.team', 'tabler-users', 2, ['dashboard.user.titan-workforce.team']),
            self::item('titan_workforce', 'titan_workforce_work', 'Work', 'dashboard.user.titan-workforce.tasks', 'tabler-briefcase', 3, ['dashboard.user.titan-workforce.tasks','dashboard.user.titan-workforce.tasks.*']),
            self::item('titan_workforce', 'titan_workforce_responsibilities', 'Responsibilities', 'dashboard.user.titan-workforce.responsibilities', 'tabler-checklist', 4, ['dashboard.user.titan-workforce.responsibilities','dashboard.user.titan-workforce.responsibilities.*']),
            self::item('titan_workforce', 'titan_workforce_proactive', 'Proactive Operations', 'dashboard.user.titan-workforce.proactive-operations', 'tabler-bolt', 5, ['dashboard.user.titan-workforce.proactive-operations']),
            self::item('titan_workforce', 'titan_workforce_capability_health', 'Capability Health', 'dashboard.user.titan-workforce.capability-health', 'tabler-plug-connected', 6, ['dashboard.user.titan-workforce.capability-health']),
            self::item('titan_workforce', 'titan_workforce_attention', 'Workforce Attention', 'dashboard.user.titan-workforce.attention', 'tabler-bell-exclamation', 7, ['dashboard.user.titan-workforce.attention']),
            self::item('titan_workforce', 'titan_workforce_notifications', 'Notifications', 'dashboard.user.titan-workforce.notifications', 'tabler-bell', 8, ['dashboard.user.titan-workforce.notifications','dashboard.user.titan-workforce.notifications.*']),
            self::item('titan_workforce', 'titan_workforce_decision_rights', 'Decision Rights & RACI', 'dashboard.user.titan-workforce.decision-rights-center', 'tabler-users-check', 9, ['dashboard.user.titan-workforce.decision-rights-center']),
            self::item('titan_workforce', 'titan_workforce_delegations', 'Delegations', 'dashboard.user.titan-workforce.delegations', 'tabler-user-share', 10, ['dashboard.user.titan-workforce.delegations']),
            self::item('titan_workforce', 'titan_workforce_escalations', 'Escalations & Deadlocks', 'dashboard.user.titan-workforce.escalations', 'tabler-arrow-up-right-circle', 11, ['dashboard.user.titan-workforce.escalations','dashboard.user.titan-workforce.escalations.*']),
            self::item('titan_workforce', 'titan_workforce_councils', 'Councils', 'dashboard.user.titan-workforce.councils', 'tabler-building-bank', 12, ['dashboard.user.titan-workforce.councils','dashboard.user.titan-workforce.councils.*']),
            self::item('titan_workforce', 'titan_workforce_governance_pipeline', 'Governance Pipeline', 'dashboard.user.titan-workforce.governance-pipeline', 'tabler-route', 13, ['dashboard.user.titan-workforce.governance-pipeline']),
            self::item('titan_workforce', 'titan_workforce_execution_evidence', 'Execution & Evidence', 'dashboard.user.titan-workforce.execution-evidence', 'tabler-search', 14, ['dashboard.user.titan-workforce.execution-evidence']),
            self::item('titan_workforce', 'titan_workforce_journey_timeline', 'Journey Timeline', 'dashboard.user.titan-workforce.journey-timeline', 'tabler-timeline', 15, ['dashboard.user.titan-workforce.journey-timeline']),
            self::item('titan_workforce', 'titan_workforce_outcome_intelligence', 'Outcome Intelligence', 'dashboard.user.titan-workforce.outcome-intelligence', 'tabler-chart-dots-3', 16, ['dashboard.user.titan-workforce.outcome-intelligence']),
            self::item('titan_workforce', 'titan_workforce_conversation', 'Ask Workforce', 'dashboard.user.titan-workforce.conversation', 'tabler-message-chatbot', 17, ['dashboard.user.titan-workforce.conversation','dashboard.user.titan-workforce.conversation.*']),
            self::item('titan_workforce', 'titan_workforce_schedule', 'Schedule', 'dashboard.user.titan-workforce.calendar', 'tabler-calendar', 18, ['dashboard.user.titan-workforce.calendar']),
            self::item('titan_workforce', 'titan_workforce_control_room', 'Control Room', 'dashboard.user.titan-workforce.control-room', 'tabler-activity-heartbeat', 19, ['dashboard.user.titan-workforce.control-room']),
            self::item('titan_workforce', 'titan_workforce_planning', 'Workforce Planning', 'dashboard.user.titan-workforce.planning', 'tabler-chart-arrows', 20, ['dashboard.user.titan-workforce.planning']),
            self::item('titan_workforce', 'titan_workforce_performance', 'Performance', 'dashboard.user.titan-workforce.analytics', 'tabler-chart-bar', 21, ['dashboard.user.titan-workforce.analytics']),
            self::item('titan_workforce', 'titan_workforce_add_staff', 'Add Staff Member', 'dashboard.user.titan-workforce.create', 'tabler-user-plus', 22, ['dashboard.user.titan-workforce.create']),
        ];
    }

    private static function item(?string $parentKey, string $key, string $label, string $route, ?string $icon, int $order, array $active, string $type = 'item'): array
    {
        return [
            'parent_key' => $parentKey, 'key' => $key, 'route' => $route, 'route_slug' => null,
            'label' => $label, 'icon' => $icon, 'order' => $order, 'is_active' => true, 'params' => [],
            'type' => $type, 'badge' => null, 'extension' => null, 'active_condition' => $active,
            'show_condition' => true, 'is_admin' => false, 'data-name' => $key,
        ];
    }
}
