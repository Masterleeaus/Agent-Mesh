<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceAssuranceCouncilReview;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerIndependence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRuntimeProfile;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceAssuranceCouncilEscalationService
{
    private const ASSURANCE_NORMALIZER='App\\Extensions\\TitanAssurance\\System\\Services\\Assurance\\Evidence\\EvidenceRecordNormalizer';
    private const ASSURANCE_RESULTS='App\\Extensions\\TitanAssurance\\System\\Services\\Assurance\\Evidence\\AssuranceResultService';
    private const COUNCIL_GATEWAY='App\\Extensions\\TitanModelCouncil\\System\\Contracts\\CouncilGatewayContract';
    private const COUNCIL_REQUEST='App\\Extensions\\TitanModelCouncil\\System\\ValueObjects\\CouncilRequest';

    public function __construct(private readonly Container $app) {}

    /** @param array<string,mixed> $context */
    public function review(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        ?WorkforceChainEscalation $managerEscalation = null,
        array $context = []
    ): WorkforceAssuranceCouncilReview {
        $assurance=$this->runAssurance($chain,$checkpoint,$context);
        $needCouncil=$this->requiresCouncil($chain,$checkpoint,$assurance,$managerEscalation,$context);

        $councilStatus=null;$councilResult=null;$roleModels=null;
        if($needCouncil){
            [$councilStatus,$councilResult,$roleModels]=$this->runCouncil($chain,$checkpoint,$managerEscalation,$assurance,$context);
        }

        $final=$this->finalStatus($assurance,$needCouncil,$councilStatus,$councilResult);

        return WorkforceAssuranceCouncilReview::query()->create([
            'review_uuid'=>(string)Str::uuid(),
            'company_id'=>(int)$chain->company_id,
            'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$chain->processing_id,
            'stage'=>(int)$checkpoint->stage,
            'manager_escalation_id'=>$managerEscalation?->getKey(),
            'assurance_status'=>$assurance['status'] ?? 'UNAVAILABLE',
            'assurance_score'=>$assurance['score'] ?? null,
            'assurance_result'=>$assurance,
            'model_council_required'=>$needCouncil,
            'council_status'=>$councilStatus,
            'council_role_models'=>$roleModels,
            'council_result'=>$councilResult,
            'final_status'=>$final,
            'advisory_only'=>true,
            'reviewed_at'=>now(),
        ]);
    }

    /** @return array<string,mixed> */
    private function runAssurance(WorkforceDecisionChain $chain,WorkforceProcessingCheckpoint $checkpoint,array $context): array
    {
        if(!class_exists(self::ASSURANCE_NORMALIZER) || !class_exists(self::ASSURANCE_RESULTS)){
            return ['status'=>'UNAVAILABLE','score'=>null,'reason_codes'=>['ASSURANCE_PROVIDER_UNAVAILABLE'],'advisory_only'=>true];
        }

        $normalizer=$this->app->make(self::ASSURANCE_NORMALIZER);
        $results=$this->app->make(self::ASSURANCE_RESULTS);

        $evidence=[];
        $rawEvidence=(array)($chain->task?->evidence ?? []);
        foreach($rawEvidence as $key=>$item){
            if(is_array($item) && isset($item['evidence_type'],$item['subject'],$item['source'])){
                $evidence[]=$normalizer->normalize($item);
                continue;
            }
            $value=is_array($item)?$item:['value'=>$item];
            $evidence[]=$normalizer->normalize([
                'evidence_type'=>'workforce-chain-evidence',
                'subject'=>['processing_id'=>$chain->processing_id,'stage'=>$checkpoint->stage,'key'=>(string)$key],
                'source'=>'titan-ai-workforce',
                'authority'=>'trusted','confidence'=>0.85,'relevance'=>1.0,'applicability'=>1.0,
                'provenance'=>['decision_chain_uuid'=>$chain->chain_uuid,'task_id'=>$chain->task_id],
                'verification_state'=>'recorded','content'=>$value,
            ]);
        }

        foreach((array)($chain->knowledge_receipt['sections'] ?? []) as $i=>$section){
            if(!is_array($section)) continue;
            $evidence[]=$normalizer->normalize([
                'evidence_type'=>'knowledge-authority-section',
                'subject'=>['processing_id'=>$chain->processing_id,'section'=>$i],
                'source'=>'titan-knowledge-authority',
                'authority'=>'authoritative','confidence'=>(float)($section['confidence'] ?? 0.95),
                'relevance'=>1.0,'applicability'=>1.0,
                'provenance'=>[
                    'source_key'=>$section['source_key'] ?? null,
                    'source_version'=>$section['source_version'] ?? null,
                    'claim_key'=>$section['claim_key'] ?? null,
                ],
                'verification_state'=>'verified','content'=>$section,
            ]);
        }

        $prior=WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->where('stage','<=',(int)$checkpoint->stage)
            ->orderBy('stage')->get();
        foreach($prior as $row){
            $evidence[]=$normalizer->normalize([
                'evidence_type'=>'independent-ai-review',
                'subject'=>['processing_id'=>$chain->processing_id,'stage'=>(int)$row->stage],
                'source'=>'titan-ai-workforce',
                'authority'=>'trusted',
                'confidence'=>max(0.0,min(1.0,((float)data_get($row->decision ?? [],'confidence',80))/100)),
                'relevance'=>1.0,'applicability'=>1.0,
                'provenance'=>[
                    'reviewer_member_id'=>$row->reviewer_member_id,
                    'review_packet_sha256'=>data_get($row->decision ?? [],'action_review_packet.packet_sha256'),
                ],
                'verification_state'=>'independent-review',
                'content'=>$row->decision ?? [],
            ]);
        }

        $requirements=[
            ['key'=>'knowledge-authority','evidence_type'=>'knowledge-authority-section','required'=>(bool)$chain->consequential,'critical'=>in_array(strtoupper((string)$chain->risk_class),['HIGH','REGULATED','CRITICAL','SEVERE','EXTREME'],true)],
            ['key'=>'independent-review','evidence_type'=>'independent-ai-review','required'=>true,'critical'=>true],
        ];

        $result=$results->evaluate($evidence,$requirements,1.0,'titan-workforce-chain-assurance-v1');
        $result['advisory_only']=true;
        $result['provider']='titan-assurance';
        $result['processing_id']=$chain->processing_id;
        return $result;
    }

    private function requiresCouncil(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        array $assurance,
        ?WorkforceChainEscalation $managerEscalation,
        array $context
    ): bool {
        if(($context['force_model_council'] ?? false)===true) return true;
        if(($context['force_assurance'] ?? false)===true && strtoupper((string)($assurance['status'] ?? ''))!=='GREEN') return true;
        $risk=strtoupper((string)$chain->risk_class);
        $assuranceStatus=strtoupper((string)($assurance['status'] ?? 'UNAVAILABLE'));
        $disagreements=(int)($managerEscalation?->disagreement_count ?? $context['disagreement_count'] ?? 0);
        return in_array($risk,['CRITICAL','SEVERE','EXTREME'],true)
            || $assuranceStatus==='RED'
            || ($assuranceStatus==='AMBER' && $disagreements>=2)
            || $disagreements>=3;
    }

    /** @return array{0:string,1:array<string,mixed>,2:array<string,string>} */
    private function runCouncil(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        ?WorkforceChainEscalation $managerEscalation,
        array $assurance,
        array $context
    ): array {
        if(!interface_exists(self::COUNCIL_GATEWAY) || !$this->app->bound(self::COUNCIL_GATEWAY) || !class_exists(self::COUNCIL_REQUEST)){
            return ['UNAVAILABLE',['status'=>'UNAVAILABLE','requires_escalation'=>true,'reason'=>'MODEL_COUNCIL_UNAVAILABLE','execution_authority'=>'advisory_only'],[]];
        }

        $userId=(int)($context['system_actor_user_id'] ?? 0);
        if($userId<1 && $managerEscalation?->assigned_to_member_id){
            $member=WorkforceMember::query()->forCompany((int)$chain->company_id)->find($managerEscalation->assigned_to_member_id);
            $userId=(int)($member?->user_id ?? 0);
        }
        if($userId<1){
            return ['BLOCKED',['status'=>'blocked','requires_escalation'=>true,'reason'=>'MODEL_COUNCIL_REQUIRES_AUTHENTICATED_SYSTEM_OR_MANAGER_ACTOR','execution_authority'=>'advisory_only'],[]];
        }

        $roleModels=$this->roleModels($chain,$context);
        if(count(array_unique(array_values($roleModels)))<3){
            return ['BLOCKED',['status'=>'blocked','requires_escalation'=>true,'reason'=>'MODEL_COUNCIL_REQUIRES_AT_LEAST_THREE_DISTINCT_MODELS','execution_authority'=>'advisory_only'],[]];
        }

        $requestClass=self::COUNCIL_REQUEST;
        $request=new $requestClass(
            prompt:$this->councilPrompt($chain,$checkpoint,$assurance),
            companyId:(int)$chain->company_id,
            userId:$userId,
            manualStrategy:'governed_deliberation',
            riskLevel:strtolower((string)$chain->risk_class),
            metadata:[
                'workforce_processing_id'=>$chain->processing_id,
                'decision_chain_uuid'=>$chain->chain_uuid,
                'stage'=>(int)$checkpoint->stage,
                'assurance'=>$assurance,
                'execution_authority'=>'advisory_only',
            ],
            traceId:(string)($chain->task?->trace_id ?? ''),
            correlationId:(string)($chain->task?->correlation_id ?? ''),
            causationId:(string)($chain->task?->causation_id ?? ''),
            rootCausationId:(string)($chain->task?->task_uuid ?? ''),
        );

        $gateway=$this->app->make(self::COUNCIL_GATEWAY);
        $result=$gateway->runGoverned($request,$roleModels);
        $result['execution_authority']='advisory_only';
        $result['workforce_authority_owner']='titan-ai-workforce';
        return [strtoupper((string)($result['status'] ?? 'COMPLETED')),$result,$roleModels];
    }

    /** @return array<string,string> */
    private function roleModels(WorkforceDecisionChain $chain,array $context): array
    {
        $provided=(array)($context['role_models'] ?? []);
        $required=['proposer','critic','verifier','arbiter'];
        $valid=true;
        foreach($required as $role){
            if(trim((string)($provided[$role] ?? ''))===''){$valid=false;break;}
        }
        if($valid) return array_intersect_key($provided,array_flip($required));

        $models=[];
        $rows=WorkforceReviewerIndependence::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->whereNotNull('model_key')
            ->where('eligible',true)->orderBy('stage')->get();
        foreach($rows as $row){
            if($row->model_key && !in_array((string)$row->model_key,$models,true)) $models[]=(string)$row->model_key;
        }
        $profiles=WorkforceRuntimeProfile::query()->forCompany((int)$chain->company_id)->orderBy('id')->get();
        foreach($profiles as $profile){
            $model=trim((string)data_get($profile->model_policy ?? [],'model',''));
            if($model!=='' && !in_array($model,$models,true)) $models[]=$model;
        }
        if(count($models)<3) return [];
        while(count($models)<4) $models[]=$models[0];

        return [
            'proposer'=>$models[0],
            'critic'=>$models[1],
            'verifier'=>$models[2],
            'arbiter'=>$models[3],
        ];
    }

    private function councilPrompt(WorkforceDecisionChain $chain,WorkforceProcessingCheckpoint $checkpoint,array $assurance): string
    {
        return json_encode([
            'instruction'=>'Independently evaluate this escalated Workforce decision. Preserve disagreement. Do not grant execution authority.',
            'processing_id'=>$chain->processing_id,
            'stage'=>(int)$checkpoint->stage,
            'risk_class'=>$chain->risk_class,
            'task'=>[
                'title'=>$chain->task?->title,
                'description'=>$chain->task?->description,
                'capability'=>$chain->task?->capability,
                'payload'=>$chain->task?->payload,
            ],
            'knowledge_receipt'=>$chain->knowledge_receipt,
            'checkpoint_decision'=>$checkpoint->decision,
            'assurance'=>$assurance,
        ],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    }

    private function finalStatus(array $assurance,bool $needCouncil,?string $councilStatus,?array $council): string
    {
        $a=strtoupper((string)($assurance['status'] ?? 'UNAVAILABLE'));
        if($a==='UNAVAILABLE') return 'BLOCKED_ASSURANCE_UNAVAILABLE';
        if(!$needCouncil) return $a==='GREEN'?'ASSURANCE_SUPPORTED':'ASSURANCE_REVIEW_REQUIRED';
        if(in_array($councilStatus,['UNAVAILABLE','BLOCKED'],true)) return 'BLOCKED_COUNCIL_UNRESOLVED';
        if(($council['requires_escalation'] ?? false)===true) return 'COUNCIL_ESCALATION_REQUIRED';
        return 'COUNCIL_ADVISORY_COMPLETE';
    }
}
