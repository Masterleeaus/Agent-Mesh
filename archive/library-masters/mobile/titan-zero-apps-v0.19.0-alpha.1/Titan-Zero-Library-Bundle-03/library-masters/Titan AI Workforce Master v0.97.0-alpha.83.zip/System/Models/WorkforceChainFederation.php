<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainFederation extends Model
{
    protected $table='ext_titan_ai_workforce_chain_federations';
    protected $guarded=[];
    protected $casts=['domain_path'=>'array','handoff_count'=>'integer','accepted_handoff_count'=>'integer','completed_at'=>'datetime'];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
