<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Runtime;

use InvalidArgumentException;

final readonly class RuntimeFailure
{
    /** @param array<string, mixed> $details */
    public function __construct(
        public string $code,
        public string $message,
        public bool $retryable = false,
        public array $details = [],
    ) {
        if (trim($code) === '' || trim($message) === '') {
            throw new InvalidArgumentException('Runtime failure requires code and message.');
        }
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            code: (string) ($data['code'] ?? ''),
            message: (string) ($data['message'] ?? ''),
            retryable: (bool) ($data['retryable'] ?? false),
            details: (array) ($data['details'] ?? []),
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'code' => $this->code,
            'message' => $this->message,
            'retryable' => $this->retryable,
            'details' => $this->details,
        ];
    }
}
