<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services\ZeroBaselineIntentClassifier;
use Illuminate\Support\Str;

/**
 * Governed conversational facade over Workforce state.
 * It may read company-scoped organisational state and create persistent Work Items.
 * It never executes business mutations or grants/inherits authority.
 */
final class WorkforceConversationService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];
    private const REVIEW = ['SUBMITTED','UNDER_REVIEW','RECEIVER_REVIEW'];

    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly ZeroBaselineIntentClassifier $intentClassifier,
    ) {}

    /** @return array<string,mixed> */
    public function context(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->with(['division','team','manager'])->orderBy('name')->get();
        $work = WorkforceTask::query()->forCompany($companyId)->with(['assignee','manager'])->orderByDesc('updated_at')->limit(100)->get();
        $open = $work->reject(fn (WorkforceTask $task): bool => in_array($task->status?->value ?? (string) $task->status, self::TERMINAL, true));
        $degraded = [];
        foreach ($members as $member) {
            $live = $this->availability->forMember($member);
            if (($live['state'] ?? 'unavailable') !== 'available') {
                $degraded[] = ['id'=>$member->id,'name'=>$member->name,'role'=>$member->role,'state'=>$live['state'] ?? 'unavailable'];
            }
        }

        return [
            'workforce_health' => ['active_staff'=>$members->count(),'open_work'=>$open->count(),'degraded_staff'=>count($degraded)],
            'degraded_employees' => $degraded,
            'work_awaiting_approval' => $open->filter(fn (WorkforceTask $task): bool => in_array($task->status?->value ?? (string) $task->status, self::REVIEW, true))->map(fn (WorkforceTask $task): array => ['id'=>$task->id,'title'=>$task->title,'status'=>$task->status?->value ?? (string)$task->status,'manager'=>$task->manager?->name])->values()->all(),
            'recent_work' => $open->take(20)->map(fn (WorkforceTask $task): array => ['id'=>$task->id,'title'=>$task->title,'status'=>$task->status?->value ?? (string)$task->status,'employee'=>$task->assignee?->name])->values()->all(),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function respond(int $companyId, string $message): array
    {
        $message = trim($message);
        $context = $this->context($companyId);
        if ($message === '') return ['intent'=>'help','message'=>$this->help(),'context'=>$context,'authority_inherited'=>false];

        $classification = $this->intentClassifier->classify($message);
        $intent = (string) ($classification['intent'] ?? 'help');

        if ($intent === 'create_governed_work_item') {
            return $this->createGovernedWorkItem(
                $companyId,
                (string) data_get($classification, 'entities.target', ''),
                (string) data_get($classification, 'entities.instruction', ''),
                $message,
            );
        }
        if ($intent === 'degraded_employees') {
            $rows = $context['degraded_employees'];
            return ['intent'=>'degraded_employees','message'=>$rows === [] ? 'All active Workforce employees currently report healthy capability availability.' : count($rows).' employee(s) currently have degraded capability availability.','items'=>$rows,'authority_inherited'=>false];
        }
        if ($intent === 'work_awaiting_approval') {
            $rows = $context['work_awaiting_approval'];
            return ['intent'=>'work_awaiting_approval','message'=>$rows === [] ? 'There is no Workforce work currently waiting for manager review.' : count($rows).' Work Item(s) are waiting for review.','items'=>$rows,'authority_inherited'=>false];
        }
        if ($intent === 'workforce_health') {
            $health = $context['workforce_health'];
            return ['intent'=>'workforce_health','message'=>sprintf('The Workforce has %d active staff, %d open Work Items, and %d degraded staff.', $health['active_staff'], $health['open_work'], $health['degraded_staff']),'items'=>$context['recent_work'],'authority_inherited'=>false];
        }

        return ['intent'=>'help','message'=>$this->help(),'context'=>$context,'authority_inherited'=>false];
    }

    /** @return array<string,mixed> */
    private function createGovernedWorkItem(int $companyId, string $target, string $instruction, string $sourceMessage): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->with(['manager'])->get();
        $needle = Str::lower($target);
        $member = $members->first(function (WorkforceMember $member) use ($needle): bool {
            $name = Str::lower((string) $member->name);
            $role = Str::lower((string) $member->role);
            return $name === $needle || $role === $needle || str_contains($name, $needle) || str_contains($role, $needle) || str_contains($needle, $role);
        });
        if (! $member) {
            return ['intent'=>'create_governed_work_item','created'=>false,'message'=>'I could not resolve that target to an active Workforce employee or role. No Work Item was created.','authority_inherited'=>false,'execution_authority_granted'=>false];
        }

        $task = $this->tasks->create($companyId, [
            'title' => Str::limit($instruction, 180, ''),
            'description' => $instruction,
            'instruction' => $instruction,
            'assignee_member_id' => $member->id,
            'manager_member_id' => $member->manager_id,
            'division_id' => $member->division_id,
            'team_id' => $member->team_id,
            'origin_type' => 'CONVERSATION',
            'origin_id' => 'conversation:'.hash('sha256', $sourceMessage),
            'payload' => ['conversation_request'=>$sourceMessage,'target'=>$target],
            'metadata' => [
                'created_via_workforce_conversation' => true,
                'requires_fresh_execution_authorization' => true,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ],
            'idempotency_key' => 'conversation:'.$companyId.':'.hash('sha256', Str::lower($sourceMessage)),
        ]);

        return [
            'intent'=>'create_governed_work_item',
            'created'=>true,
            'message'=>sprintf('Created governed Work Item #%d for %s (%s). It has not executed any business action.', $task->id, $member->name, $member->role),
            'task'=>['id'=>$task->id,'title'=>$task->title,'employee'=>$member->name,'role'=>$member->role,'status'=>$task->status?->value ?? (string)$task->status],
            'requires_fresh_execution_authorization'=>true,
            'authority_inherited'=>false,
            'execution_authority_granted'=>false,
        ];
    }

    private function help(): string
    {
        return 'Ask about Workforce health, degraded employees, work awaiting approval, or use “Ask <employee or role> to <work>” to create a governed Work Item.';
    }
}
