<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Queue\Middleware;

use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use Closure;

final class RestoreWorkforceTenantContext
{
    public function __construct(public readonly int $companyId) {}

    public function handle(object $job, Closure $next): mixed
    {
        return CompanyContext::runWith($this->companyId, fn () => $next($job));
    }
}
