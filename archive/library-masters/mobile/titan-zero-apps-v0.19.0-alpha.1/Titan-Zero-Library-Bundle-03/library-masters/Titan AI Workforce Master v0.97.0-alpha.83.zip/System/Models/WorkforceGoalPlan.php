<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceGoalPlan extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_goal_plans';
    protected $guarded = [];
    protected $casts = [
        'objective' => 'array',
        'assumptions' => 'array',
        'constraints' => 'array',
        'plan_payload' => 'array',
        'validation_report' => 'array',
        'committed_at' => 'datetime',
    ];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function goal(): BelongsTo { return $this->belongsTo(WorkforceGoal::class, 'goal_id'); }
    public function planner(): BelongsTo { return $this->belongsTo(WorkforceMember::class, 'planner_member_id'); }
}
