<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/**
 * Central discovery/orchestration registry for extension-owned Workforce manifests.
 * Canonical contract: Workforce Manifest 2.0. Legacy 1.1 is normalised conservatively.
 * Invalid contributors are quarantined independently so one extension cannot poison discovery.
 */
final class WorkforceManifestRegistry
{
    /** @var array<string,array{provider:mixed,priority:int}> */
    private array $providers = [];
    /** @var array<string,array> */
    private array $manifests = [];
    /** @var array<string,array> */
    private array $health = [];
    private bool $containerBindingsScanned = false;
    private bool $compiled = false;
    /** @var array<string,bool> */
    private array $suppressedExtensions = [];

    public function __construct(private readonly Container $app) {}

    /** Supports register($provider) and register($key, $provider, $priority). */
    public function register(mixed $keyOrProvider, mixed $provider = null, int $priority = 100): self
    {
        if ($provider === null) {
            $provider = $keyOrProvider;
            $key = $this->providerKey($provider);
        } else {
            $key = trim((string) $keyOrProvider);
        }
        if ($key === '') throw new RuntimeException('Workforce manifest contribution requires a stable key.');
        $this->providers[$key] = ['provider' => $provider, 'priority' => $priority];
        unset($this->manifests[$key], $this->health[$key]);
        $this->compiled = false;
        return $this;
    }

    public function add(mixed $keyOrProvider, mixed $provider = null, int $priority = 100): self
    {
        return $this->register($keyOrProvider, $provider, $priority);
    }

    public function registerManifest(array $manifest, int $priority = 100): self
    {
        $key = trim((string) ($manifest['extension']['key'] ?? ''));
        if ($key === '') throw new RuntimeException('Workforce manifest requires extension.key.');
        return $this->register($key, $manifest, $priority);
    }

    /** @return array<string,array> Canonical accepted manifests only. */
    public function all(): array
    {
        $this->discoverContainerBindings();
        if ($this->compiled) return $this->manifests;
        $this->manifests = [];
        $this->health = [];

        $providers = $this->providers;
        uasort($providers, static fn (array $a, array $b): int => ((int) $b['priority']) <=> ((int) $a['priority']));

        foreach ($providers as $providerKey => $entry) {
            $priority = (int) $entry['priority'];
            $sourceVersion = null;
            try {
                $raw = $this->resolveProvider($entry['provider']);
                $sourceVersion = (string) ($raw['schema_version'] ?? '');
                $manifest = WorkforceManifestNormalizer::normalize($raw);
                WorkforceManifestValidator::assertValid($manifest);
                $manifestKey = (string) $manifest['extension']['key'];

                if (isset($this->suppressedExtensions[$manifestKey])) {
                    $this->health[$manifestKey] = [
                        'status' => 'DISABLED', 'schema_version' => '2.0', 'source_schema_version' => $sourceVersion,
                        'legacy' => $sourceVersion === '1.1', 'priority' => $priority,
                        'extension_version' => (string) $manifest['extension']['version'], 'role_count' => 0,
                        'issues' => ['Extension Workforce contribution is suppressed by lifecycle state.'],
                    ];
                    continue;
                }

                if ($manifestKey !== $providerKey
                    && ! str_starts_with($providerKey, 'binding:')
                    && ! str_starts_with($providerKey, 'provider:')) {
                    throw new RuntimeException("Workforce manifest provider key {$providerKey} does not match extension key {$manifestKey}.");
                }

                // Manifest role blocks are compatibility binding hints only. Multiple providers may
                // legitimately attach execution surfaces to the same intrinsic Workforce role.
                $this->manifests[$manifestKey] = $this->withProvenance($manifest, $priority, $sourceVersion);
                $this->health[$manifestKey] = [
                    'status' => $sourceVersion === '1.1' ? 'LEGACY_NORMALIZED' : 'HEALTHY',
                    'schema_version' => '2.0',
                    'source_schema_version' => $sourceVersion,
                    'legacy' => $sourceVersion === '1.1',
                    'priority' => $priority,
                    'extension_version' => (string) $manifest['extension']['version'],
                    'role_count' => count($manifest['roles']),
                    'issues' => [],
                ];
            } catch (Throwable $e) {
                $healthKey = $this->healthKey($providerKey, $entry['provider']);
                $this->health[$healthKey] = [
                    'status' => 'QUARANTINED',
                    'schema_version' => null,
                    'source_schema_version' => $sourceVersion,
                    'legacy' => $sourceVersion === '1.1',
                    'priority' => $priority,
                    'extension_version' => null,
                    'role_count' => 0,
                    'issues' => [$e->getMessage()],
                ];
            }
        }

        $this->compiled = true;
        return $this->manifests;
    }

    /** @return array<string,array> */
    public function health(): array
    {
        $this->all();
        return $this->health;
    }

    public function findManifest(string $extensionKey): ?array
    {
        return $this->all()[$extensionKey] ?? null;
    }

    /**
     * Legacy Manifest 2.0 employee blocks retained as compatibility hints only.
     * They are never canonical Workforce role identity after capability binding convergence.
     *
     * @return list<array<string,mixed>>
     */
    public function compatibilityRoleHints(): array
    {
        return $this->roles();
    }

    /**
     * Translate accepted Manifest 2.0 providers into the capability-binding v1 ownership model.
     * Extension role blocks are interpreted only as legacy_v2_role_hint attachment hints.
     *
     * @return array<string,array<string,mixed>>
     */
    public function providerContributions(): array
    {
        $out = [];
        $intrinsic = new IntrinsicRoleCatalog();
        $executive = new ExecutiveRoleCatalog();

        foreach ($this->all() as $manifest) {
            $extensionKey = (string) $manifest['extension']['key'];
            $extensionVersion = (string) $manifest['extension']['version'];
            $toolsById = [];
            foreach ($manifest['tools'] ?? [] as $tool) {
                if (is_array($tool) && trim((string) ($tool['id'] ?? '')) !== '') $toolsById[(string) $tool['id']] = $tool;
            }

            $commands = [];
            $dataSources = [];
            foreach ($toolsById as $toolId => $tool) {
                $capability = (string) ($tool['capability'] ?? '');
                $writes = (bool) ($tool['writes_state'] ?? false);
                if ($writes) {
                    $commands[] = [
                        'id' => $toolId,
                        'capability' => $capability,
                        'execution' => (string) ($tool['execution'] ?? 'command_bus'),
                        'writes_state' => true,
                        'source' => 'legacy_manifest_tool',
                    ];
                } else {
                    $dataSources[] = [
                        'id' => $toolId,
                        'capability' => $capability,
                        'access' => 'read_only',
                        'source' => 'legacy_manifest_tool',
                    ];
                }
            }

            $signals = [];
            foreach ($manifest['proactive']['signals'] ?? [] as $signal) {
                if (! is_array($signal)) continue;
                $event = trim((string) ($signal['event'] ?? ''));
                if ($event === '') continue;
                $signals[] = [
                    'id' => $event,
                    'event_type' => $event,
                    'creates' => (string) ($signal['creates'] ?? 'workforce_task'),
                    'source' => 'legacy_manifest_signal',
                ];
            }

            $bindings = [];
            foreach ($manifest['roles'] ?? [] as $legacyRole) {
                if (! is_array($legacyRole)) continue;
                $roleId = trim((string) ($legacyRole['role_id'] ?? ''));
                $key = trim((string) ($legacyRole['key'] ?? ''));
                $definition = ($roleId !== '' ? $intrinsic->find($roleId) : null)
                    ?? ($key !== '' ? $intrinsic->find($key) : null)
                    ?? ($roleId !== '' ? $executive->find($roleId) : null)
                    ?? ($key !== '' ? $executive->find($key) : null);
                if (! $definition) continue;

                $canonicalRoleId = (string) $definition['role_definition_id'];
                $roleToolIds = array_values(array_unique(array_filter(array_map('strval', (array) ($legacyRole['tools'] ?? [])))));
                $roleCommands = [];
                $roleDataSources = [];
                foreach ($roleToolIds as $toolId) {
                    $tool = $toolsById[$toolId] ?? null;
                    if (! is_array($tool)) continue;
                    if ((bool) ($tool['writes_state'] ?? false)) $roleCommands[] = $toolId;
                    else $roleDataSources[] = $toolId;
                }
                $roleSignals = [];
                foreach ($manifest['proactive']['signals'] ?? [] as $signal) {
                    if (! is_array($signal) || (string) ($signal['role_id'] ?? '') !== $roleId) continue;
                    $event = trim((string) ($signal['event'] ?? ''));
                    if ($event !== '') $roleSignals[] = $event;
                }
                $bindings[] = [
                    'role_definition_id' => $canonicalRoleId,
                    'capabilities' => array_values(array_unique(array_filter(array_map('strval', (array) ($legacyRole['capabilities'] ?? []))))),
                    'tools' => $roleToolIds,
                    'commands' => array_values(array_unique($roleCommands)),
                    'signals' => array_values(array_unique($roleSignals)),
                    'data_sources' => array_values(array_unique($roleDataSources)),
                    'workflows' => array_values(array_unique(array_filter(array_map('strval', (array) ($legacyRole['workflows'] ?? []))))),
                    'authority_inherited' => false,
                    'source' => 'legacy_v2_role_hint',
                ];
            }

            $out[$extensionKey] = [
                'schema_version' => '1.0',
                'extension' => ['key' => $extensionKey, 'version' => $extensionVersion],
                'ownership' => [
                    'organisation_owner' => 'titan-ai-workforce',
                    'provider_owns_execution_surfaces' => true,
                    'role_definitions_owned_by_provider' => false,
                ],
                'role_bindings' => $bindings,
                'capabilities' => array_values((array) ($manifest['capabilities'] ?? [])),
                'tools' => array_values((array) ($manifest['tools'] ?? [])),
                'commands' => $commands,
                'signals' => $signals,
                'data_sources' => $dataSources,
                'workflows' => array_values((array) ($manifest['workflows'] ?? [])),
                '_compatibility' => [
                    'source_schema_version' => (string) ($manifest['_registry']['source_schema_version'] ?? $manifest['schema_version'] ?? '2.0'),
                    'role_blocks_are_hints_only' => true,
                ],
            ];
        }
        return $out;
    }

    /** @return list<array> Internal compatibility view enriched from canonical v2 role definitions. */
    public function roles(): array
    {
        $roles = [];
        foreach ($this->all() as $manifest) {
            $extensionKey = (string) $manifest['extension']['key'];
            $extensionVersion = (string) $manifest['extension']['version'];
            foreach ($manifest['roles'] as $definition) {
                $role = $definition;
                $roleId = (string) $definition['role_id'];
                $fingerprint = hash('sha256', json_encode($definition, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

                // Compatibility aliases for the existing central organisational runtime.
                $role['key'] = (string) ($definition['key'] ?? $roleId);
                $role['division'] = (string) $definition['division_id'];
                $role['team'] = (string) $definition['team_id'];
                $role['parent_manager'] = $definition['reports_to'];
                $role['tool_access'] = array_values(array_map('strval', $definition['tools']));
                $role['interaction_wizards'] = array_values(array_map('strval', $definition['wizards']));
                $role['workflow_refs'] = array_values(array_map('strval', $definition['workflows']));
                $role['autonomy_profile'] = [
                    'starting_level' => (string) $definition['autonomy']['initial_earned_ceiling']['band'],
                    'starting_score' => (int) $definition['autonomy']['initial_earned_ceiling']['score'],
                    'desired_level' => (string) $definition['autonomy']['desired']['band'],
                    'desired_score' => (int) $definition['autonomy']['desired']['score'],
                    'authority_source' => 'titan_autonomy',
                    'self_promotion' => false,
                ];
                $role['owner_extension'] = $extensionKey;
                $role['owner_extension_version'] = $extensionVersion;
                $role['definition_version'] = $extensionVersion;
                $role['definition_fingerprint'] = $fingerprint;
                $role['definition_schema_version'] = '2.0';
                $role['definition_source_schema_version'] = (string) ($manifest['_registry']['source_schema_version'] ?? '2.0');
                $role['definition_source'] = 'extension_workforce_manifest';
                $roles[] = $role;
            }
        }
        return $roles;
    }

    public function findRole(string $keyOrRoleId): ?array
    {
        foreach ($this->roles() as $role) {
            if (($role['key'] ?? null) === $keyOrRoleId || ($role['role_id'] ?? null) === $keyOrRoleId) return $role;
            if (in_array($keyOrRoleId, $role['aliases'] ?? [], true)) return $role;
        }
        return null;
    }

    public function find(string $keyOrRoleId): ?array { return $this->findRole($keyOrRoleId); }

    /** @return list<array> */
    public function forVertical(string $vertical): array
    {
        return array_values(array_filter($this->roles(), static function (array $role) use ($vertical): bool {
            $verticals = $role['activation']['verticals'] ?? ['all'];
            return in_array('all', $verticals, true) || in_array($vertical, $verticals, true);
        }));
    }

    /** @return array<string,array{name:string,purpose:string,owner_extensions:list<string>}> */
    public function divisions(): array
    {
        $out = [];
        foreach ($this->all() as $manifest) {
            $owner = (string) $manifest['extension']['key'];
            foreach ($manifest['divisions'] as $division) {
                $key = (string) $division['id'];
                $out[$key] ??= ['name' => (string) $division['name'], 'purpose' => (string) ($division['purpose'] ?? ''), 'owner_extensions' => []];
                if (! in_array($owner, $out[$key]['owner_extensions'], true)) $out[$key]['owner_extensions'][] = $owner;
            }
        }
        return $out;
    }

    /** @return list<array> Extension-owned organisational relationships with provenance. */
    public function relationships(): array
    {
        $out = [];
        foreach ($this->all() as $manifest) {
            $owner = (string) $manifest['extension']['key'];
            $version = (string) $manifest['extension']['version'];
            foreach ($manifest['relationships'] ?? [] as $relationship) {
                $relationship['owner_extension'] = $owner;
                $relationship['owner_extension_version'] = $version;
                $out[] = $relationship;
            }
        }
        return $out;
    }

    /** @return list<array> Extension-owned RACI decision rights with provenance. */
    public function decisionRights(): array
    {
        $out = [];
        foreach ($this->all() as $manifest) {
            $owner = (string) $manifest['extension']['key'];
            $version = (string) $manifest['extension']['version'];
            foreach ($manifest['raci'] ?? [] as $raci) {
                $raci['owner_extension'] = $owner;
                $raci['owner_extension_version'] = $version;
                $out[] = $raci;
            }
        }
        return $out;
    }

    public function findDecisionRight(string $decision, ?string $ownerExtension = null): ?array
    {
        $matches = array_values(array_filter($this->decisionRights(), static function (array $row) use ($decision, $ownerExtension): bool {
            if ((string) ($row['decision'] ?? '') !== $decision) return false;
            return $ownerExtension === null || (string) ($row['owner_extension'] ?? '') === $ownerExtension;
        }));
        return count($matches) === 1 ? $matches[0] : null;
    }

    /** @return list<array> */
    public function explicitRoutinesForRole(string $roleKeyOrId): array
    {
        foreach ($this->all() as $manifest) {
            foreach ($manifest['roles'] as $role) {
                $roleId = (string) $role['role_id'];
                if ($roleId !== $roleKeyOrId && (string) ($role['key'] ?? $roleId) !== $roleKeyOrId) continue;
                return $this->routinesForManifestRole($manifest, $role);
            }
        }
        return [];
    }

    /** @return list<array> */
    public function explicitRoutinesForOwnedRole(string $extensionKey, string $roleId): array
    {
        $manifest = $this->findManifest($extensionKey);
        if (! $manifest) return [];
        foreach ($manifest['roles'] as $role) {
            if ((string) ($role['role_id'] ?? '') === $roleId) return $this->routinesForManifestRole($manifest, $role);
        }
        return [];
    }

    /** @return list<array> */
    private function routinesForManifestRole(array $manifest, array $role): array
    {
        $roleId = (string) $role['role_id'];
        $out = [];
        foreach ($manifest['proactive']['schedules'] ?? [] as $schedule) {
            if (($schedule['role_id'] ?? null) === $roleId) $out[] = $this->normaliseRoutine($schedule, 'schedule', $manifest, $role);
        }
        foreach ($manifest['proactive']['signals'] ?? [] as $signal) {
            if (($signal['role_id'] ?? null) === $roleId) $out[] = $this->normaliseRoutine($signal, 'signal', $manifest, $role);
        }
        return $out;
    }

    /** @return list<array> */
    public function workflows(): array
    {
        $out = [];
        foreach ($this->all() as $manifest) {
            $owner = (string) $manifest['extension']['key'];
            foreach ($manifest['workflows'] as $workflow) {
                $workflow['workflow_id'] ??= $workflow['id'] ?? null;
                $workflow['owner_extension'] = $owner;
                $out[] = $workflow;
            }
        }
        return $out;
    }


    public function isSuppressedExtension(string $extensionKey): bool
    {
        $extensionKey = trim($extensionKey);
        return $extensionKey !== '' && isset($this->suppressedExtensions[$extensionKey]);
    }

    public function suppressExtension(string $extensionKey): void
    {
        $extensionKey = trim($extensionKey);
        if ($extensionKey === '') return;
        $this->suppressedExtensions[$extensionKey] = true;
        $this->invalidateExtension($extensionKey);
    }

    public function restoreExtension(string $extensionKey): void
    {
        unset($this->suppressedExtensions[trim($extensionKey)]);
        $this->invalidateExtension($extensionKey);
    }

    public function invalidateExtension(string $extensionKey): void
    {
        $this->manifests = [];
        $this->health = [];
        $this->containerBindingsScanned = false;
        $this->compiled = false;
    }

    public function findOwnedRole(string $extensionKey, string $roleId): ?array
    {
        foreach ($this->roles() as $role) {
            if ((string) ($role['owner_extension'] ?? '') !== $extensionKey) continue;
            if ((string) ($role['role_id'] ?? '') === $roleId) return $role;
        }
        return null;
    }

    /** Return an extension-owned capability contract, optionally matching its declared variant. */
    public function findOwnedCapability(string $extensionKey, string $capabilityName, ?string $variant = null): ?array
    {
        $manifest = $this->findManifest($extensionKey);
        if (! $manifest) return null;
        foreach ($manifest['capabilities'] ?? [] as $capability) {
            if ((string) ($capability['name'] ?? '') !== $capabilityName) continue;
            $declaredVariant = $capability['autonomy_requirement']['variant'] ?? null;
            if ($variant !== null && $declaredVariant !== null && (string) $declaredVariant !== $variant) continue;
            $capability['owner_extension'] = $extensionKey;
            $capability['owner_extension_version'] = (string) ($manifest['extension']['version'] ?? '');
            $capability['source_schema_version'] = (string) ($manifest['_registry']['source_schema_version'] ?? '2.0');
            return $capability;
        }
        return null;
    }

    /** Return one extension-owned workflow definition with its concrete Interaction Engine reference. */
    public function findOwnedWorkflow(string $extensionKey, string $workflowId): ?array
    {
        $manifest = $this->findManifest($extensionKey);
        if (! $manifest) return null;
        foreach ($manifest['workflows'] ?? [] as $workflow) {
            $id = (string) ($workflow['id'] ?? $workflow['workflow_id'] ?? '');
            if ($id !== $workflowId) continue;
            $workflow['workflow_id'] = $id;
            $workflow['owner_extension'] = $extensionKey;
            $workflow['owner_extension_version'] = (string) ($manifest['extension']['version'] ?? '');
            return $workflow;
        }
        return null;
    }

    /** Return one extension-owned Wizard definition. Wizards remain proposal/evidence journeys, never mutation authority. */
    public function findOwnedWizard(string $extensionKey, string $wizardId): ?array
    {
        $manifest = $this->findManifest($extensionKey);
        if (! $manifest) return null;
        foreach ($manifest['wizards'] ?? [] as $wizard) {
            if ((string) ($wizard['id'] ?? '') !== $wizardId) continue;
            $wizard['owner_extension'] = $extensionKey;
            $wizard['owner_extension_version'] = (string) ($manifest['extension']['version'] ?? '');
            return $wizard;
        }
        return null;
    }

    public function refresh(): void
    {
        $this->manifests = [];
        $this->health = [];
        $this->containerBindingsScanned = false;
        $this->compiled = false;
    }

    private function discoverContainerBindings(): void
    {
        if ($this->containerBindingsScanned) return;
        $this->containerBindingsScanned = true;
        if (! method_exists($this->app, 'getBindings')) return;
        foreach (array_keys($this->app->getBindings()) as $abstract) {
            $abstract = (string) $abstract;
            if ($abstract === 'titan.workforce.manifests' || $abstract === 'titan-workforce.manifests') continue;
            if (! str_contains($abstract, 'workforce-manifest')) continue;
            try { $resolved = $this->app->make($abstract); } catch (Throwable) { continue; }
            if (! is_array($resolved) && ! is_object($resolved) && ! is_callable($resolved)) continue;
            $this->providers['binding:' . $abstract] = ['provider' => $resolved, 'priority' => 50];
            $this->compiled = false;
        }
    }

    private function resolveProvider(mixed $provider): array
    {
        if (is_array($provider)) return $provider;
        if (is_string($provider) && class_exists($provider)) $provider = $this->app->make($provider);
        if (is_callable($provider) && ! is_object($provider)) $provider = $provider();
        if (is_object($provider) && method_exists($provider, 'all')) $provider = $provider->all();
        elseif (is_object($provider) && is_callable($provider)) $provider = $provider();
        if (! is_array($provider)) throw new RuntimeException('Workforce manifest provider did not resolve to an array.');
        return $provider;
    }

    private function providerKey(mixed $provider): string
    {
        if (is_array($provider)) return trim((string) ($provider['extension']['key'] ?? ''));
        if (is_string($provider)) return 'provider:' . trim($provider);
        if (is_object($provider)) return 'provider:' . get_class($provider) . ':' . spl_object_id($provider);
        return '';
    }

    private function healthKey(string $providerKey, mixed $provider): string
    {
        if (is_array($provider)) {
            $key = trim((string) ($provider['extension']['key'] ?? ''));
            if ($key !== '') return $key;
        }
        return $providerKey;
    }

    private function withProvenance(array $manifest, int $priority, string $sourceVersion): array
    {
        $manifest['_registry'] = [
            'source' => 'extension_owned',
            'priority' => $priority,
            'canonical_schema_version' => '2.0',
            'source_schema_version' => $sourceVersion,
            'legacy_normalized' => $sourceVersion === '1.1',
        ];
        return $manifest;
    }

    private function normaliseRoutine(array $entry, string $kind, array $manifest, array $role): array
    {
        $owner = (string) ($manifest['extension']['key'] ?? '');
        $ownerVersion = (string) ($manifest['extension']['version'] ?? '');
        $roleId = (string) ($role['role_id'] ?? $entry['role_id'] ?? '');
        $roleFingerprint = hash('sha256', json_encode($role, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
        $sourceSchema = (string) ($manifest['_registry']['source_schema_version'] ?? $manifest['schema_version'] ?? '2.0');

        if ($kind === 'schedule') {
            $key = (string) ($entry['id'] ?? '');
            $routine = [
                'key' => $key,
                'routine_id' => $key,
                'name' => $this->humanise($key),
                'trigger_type' => 'schedule',
                'schedule' => WorkforceManifestNormalizer::scheduleExpression((string) ($entry['frequency'] ?? '')),
                'conditions' => [],
                'task_template' => ['title' => $this->humanise($key), 'metadata' => ['source_contract' => 'workforce-manifest-2.0']],
                'role_id' => $roleId,
                'role_definition_id' => $roleId,
                'role_definition_fingerprint' => $roleFingerprint,
                'owner_extension' => $owner,
                'owner_extension_version' => $ownerVersion,
                'source_schema_version' => $sourceSchema,
                'creates' => 'workforce_task',
                'business_mutation' => false,
                'source_contract' => 'workforce-manifest-2.0',
            ];
            $routine['routine_fingerprint'] = WorkforceProactiveIdentity::routineFingerprint($routine);
            return $routine;
        }
        $event = (string) ($entry['event'] ?? '');
        $routine = [
            'key' => 'signal:' . $event,
            'routine_id' => 'signal:' . $event,
            'name' => $this->humanise($event),
            'trigger_type' => 'event',
            'event_type' => $event,
            'conditions' => [],
            'task_template' => ['title' => $this->humanise($event), 'metadata' => ['source_contract' => 'workforce-manifest-2.0']],
            'role_id' => $roleId,
            'role_definition_id' => $roleId,
            'role_definition_fingerprint' => $roleFingerprint,
            'owner_extension' => $owner,
            'owner_extension_version' => $ownerVersion,
            'source_schema_version' => $sourceSchema,
            'creates' => 'workforce_task',
            'business_mutation' => false,
            'source_contract' => 'workforce-manifest-2.0',
        ];
        $routine['routine_fingerprint'] = WorkforceProactiveIdentity::routineFingerprint($routine);
        return $routine;
    }

    private function humanise(string $value): string
    {
        $value = preg_replace('/[._-]+/', ' ', trim($value)) ?: trim($value);
        return ucwords($value);
    }
}
