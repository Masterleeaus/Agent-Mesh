<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums;

enum ZeroIntentResolutionStatus: string
{
    case RESOLVED = 'resolved';
    case CLARIFICATION_REQUIRED = 'clarification_required';
    case APPROVAL_REQUIRED = 'approval_required';
    case DENIED = 'denied';
    case UNSUPPORTED = 'unsupported';
    case DEGRADED = 'degraded';
}
