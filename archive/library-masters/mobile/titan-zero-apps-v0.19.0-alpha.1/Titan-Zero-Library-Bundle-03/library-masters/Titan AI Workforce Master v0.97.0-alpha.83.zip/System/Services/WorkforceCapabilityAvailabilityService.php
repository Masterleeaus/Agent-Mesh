<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCanonicalCapabilityMatrix;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityStateResolver;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use InvalidArgumentException;

/**
 * Computes live capability availability without mutating employee identity.
 *
 * Provider presence and exact published surfaces are evaluated on every read.
 * Cached member capabilities are never treated as current authority. Missing or
 * degraded providers therefore cannot rewrite role identity or create fallback authority.
 */
final class WorkforceCapabilityAvailabilityService
{
    private const SECTIONS = ['capabilities','tools','commands','signals','data_sources','workflows'];

    public function __construct(
        private readonly WorkforceCanonicalCapabilityMatrix $matrix,
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly WorkforceCapabilityBindingRegistry $bindings,
        private readonly WorkforceCapabilityStateResolver $resolver,
    ) {}

    /** @return array<string,mixed> */
    public function forRole(string $roleDefinitionId, array $policy = []): array
    {
        $roleDefinitionId = trim($roleDefinitionId);
        $role = $this->matrix->role($roleDefinitionId);
        if (! $role) {
            return $this->blockedRole($roleDefinitionId, 'ROLE_NOT_IN_CANONICAL_MATRIX');
        }

        $contributions = $this->bindings->contributions();
        $bindingStates = [];
        foreach ($this->matrix->bindingsForRole($roleDefinitionId) as $binding) {
            $provider = $this->ecosystem->canonicalProviderKey((string) ($binding['provider'] ?? ''));
            if ($provider === '') continue;
            $catalogueProvider = $this->ecosystem->provider($provider);
            $contribution = $contributions[$provider] ?? null;
            $providerClass = trim((string) ($catalogueProvider['extension']['provider_class'] ?? ''));
            $providerInstalled = is_array($contribution) || ($providerClass !== '' && class_exists($providerClass));
            $contributionValid = is_array($contribution);
            $providerPolicyEnabled = $this->policyAllowsProvider($policy, $provider);

            $surfaces = [];
            $surfaceStates = [];
            foreach (self::SECTIONS as $section) {
                $required = $this->normalise((array) ($binding[$section] ?? []));
                $published = $this->publishedIds(is_array($contribution) ? (array) ($contribution[$section] ?? []) : []);
                $publishedSet = array_fill_keys($published, true);
                $surfaces[$section] = [];
                foreach ($required as $id) {
                    $state = $this->resolver->classify([
                        'required' => [$id],
                        'published' => isset($publishedSet[$id]) ? [$id] : [],
                        'provider_installed' => $providerInstalled,
                        'contribution_valid' => $contributionValid,
                        'policy_enabled' => $providerPolicyEnabled && $this->policyAllowsSurface($policy, $section, $id),
                    ]);
                    $surfaces[$section][] = [
                        'id' => $id,
                        'state' => $state->value,
                        'provider' => $provider,
                        'authority_inherited' => false,
                        'fallback_authority_granted' => false,
                    ];
                    $surfaceStates[] = $state;
                }
            }

            $bindingState = $surfaceStates !== []
                ? $this->resolver->aggregate($surfaceStates)
                : $this->resolver->classify([
                    'required' => [],
                    'published' => [],
                    'provider_installed' => $providerInstalled,
                    'contribution_valid' => $contributionValid,
                    'policy_enabled' => $providerPolicyEnabled,
                ]);

            $bindingStates[] = [
                'provider' => $provider,
                'provider_version' => is_array($contribution) ? (string) ($contribution['extension']['version'] ?? '') : (string) ($catalogueProvider['extension']['version'] ?? ''),
                'provider_class' => $providerClass,
                'provider_installed' => $providerInstalled,
                'contribution_valid' => $contributionValid,
                'state' => $bindingState->value,
                'surfaces' => $surfaces,
                'authority_inherited' => false,
                'fallback_authority_granted' => false,
            ];
        }

        $roleState = $this->resolver->aggregate(array_map(static fn (array $binding): string => (string) $binding['state'], $bindingStates));
        $effective = $this->effectiveAccess($bindingStates);

        return [
            'role_definition_id' => $roleDefinitionId,
            'role_identity_source' => 'canonical_capability_binding_matrix_v1',
            'role_identity_immutable' => true,
            'state' => $roleState->value,
            'provider_bindings' => $bindingStates,
            'effective_access' => $effective,
            'policy' => $this->normalisePolicy($policy),
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function forMember(WorkforceMember $member, array $policy = []): array
    {
        $memberPolicy = is_array(data_get($member->metadata ?? [], 'capability_policy'))
            ? (array) data_get($member->metadata ?? [], 'capability_policy') : [];
        $effectivePolicy = array_replace_recursive($memberPolicy, $policy);
        $state = $this->forRole((string) $member->role_definition_id, $effectivePolicy);
        $state['member_id'] = $member->id;
        $state['company_id'] = $member->company_id;
        $state['role_owner_extension'] = (string) $member->role_owner_extension;
        $state['role_identity_immutable'] = true;
        return $state;
    }

    /** @return array<string,mixed> */
    public function capabilityState(string|WorkforceMember $roleOrMember, string $capabilityId, array $policy = []): array
    {
        $capabilityId = trim($capabilityId);
        $roleState = $roleOrMember instanceof WorkforceMember
            ? $this->forMember($roleOrMember, $policy)
            : $this->forRole((string) $roleOrMember, $policy);

        $matches = [];
        foreach ((array) ($roleState['provider_bindings'] ?? []) as $binding) {
            foreach ((array) (($binding['surfaces']['capabilities'] ?? [])) as $surface) {
                if (! is_array($surface) || (string) ($surface['id'] ?? '') !== $capabilityId) continue;
                $matches[] = $surface;
            }
        }
        if ($matches === []) {
            return [
                'capability' => $capabilityId,
                'state' => WorkforceCapabilityState::Unavailable->value,
                'available_providers' => [],
                'providers' => [],
                'reason' => 'CAPABILITY_NOT_BOUND_TO_ROLE',
                'role_definition_id' => (string) ($roleState['role_definition_id'] ?? ''),
                'role_identity_immutable' => true,
                'authority_inherited' => false,
                'fallback_authority_granted' => false,
            ];
        }

        $state = $this->resolver->aggregate(array_map(static fn (array $surface): string => (string) $surface['state'], $matches));
        $availableProviders = [];
        $providers = [];
        foreach ($matches as $surface) {
            $provider = (string) ($surface['provider'] ?? '');
            if ($provider !== '') $providers[$provider] = true;
            if (($surface['state'] ?? null) === WorkforceCapabilityState::Available->value && $provider !== '') $availableProviders[$provider] = true;
        }
        $providerKeys = array_keys($providers); sort($providerKeys);
        $availableKeys = array_keys($availableProviders); sort($availableKeys);
        // If at least one exact provider can supply the capability, the capability itself is available.
        if ($availableKeys !== []) $state = WorkforceCapabilityState::Available;

        return [
            'capability' => $capabilityId,
            'state' => $state->value,
            'available_providers' => $availableKeys,
            'providers' => $providerKeys,
            'role_definition_id' => (string) ($roleState['role_definition_id'] ?? ''),
            'role_identity_immutable' => true,
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
        ];
    }

    public function isCapabilityAvailable(string|WorkforceMember $roleOrMember, string $capabilityId, array $policy = []): bool
    {
        return ($this->capabilityState($roleOrMember, $capabilityId, $policy)['state'] ?? null) === WorkforceCapabilityState::Available->value;
    }

    /** @return array<string,mixed> */
    public function assertCapabilityAvailable(WorkforceMember $member, string $capabilityId, ?string $provider = null, array $policy = []): array
    {
        $state = $this->capabilityState($member, $capabilityId, $policy);
        $available = (array) ($state['available_providers'] ?? []);
        $provider = $provider !== null ? $this->ecosystem->canonicalProviderKey($provider) : null;
        if (($state['state'] ?? null) !== WorkforceCapabilityState::Available->value) {
            throw new InvalidArgumentException('Capability is not live for this employee: ' . (string) ($state['state'] ?? 'unavailable'));
        }
        if ($provider !== null && $provider !== '' && ! in_array($provider, $available, true)) {
            throw new InvalidArgumentException('Requested capability provider is not live for this employee.');
        }
        if ($provider === null || $provider === '') {
            if (count($available) !== 1) {
                throw new InvalidArgumentException('Capability has multiple live providers; an exact provider route is required.');
            }
            $provider = (string) $available[0];
        }
        $state['selected_provider'] = $provider;
        $contribution = $this->bindings->contributions()[$provider] ?? null;
        $state['selected_provider_version'] = is_array($contribution)
            ? trim((string) ($contribution['extension']['version'] ?? ''))
            : '';
        if ($state['selected_provider_version'] === '') {
            throw new InvalidArgumentException('Capability provider version could not be pinned.');
        }
        $state['execution_route_pinned'] = true;
        $state['execution_authority_granted'] = false;
        return $state;
    }

    /** @param list<array<string,mixed>> $bindingStates @return array<string,mixed> */
    private function effectiveAccess(array $bindingStates): array
    {
        $sets = array_fill_keys([...self::SECTIONS, 'providers'], []);
        foreach ($bindingStates as $binding) {
            $provider = (string) ($binding['provider'] ?? '');
            foreach (self::SECTIONS as $section) {
                foreach ((array) (($binding['surfaces'][$section] ?? [])) as $surface) {
                    if (! is_array($surface) || ($surface['state'] ?? null) !== WorkforceCapabilityState::Available->value) continue;
                    $id = trim((string) ($surface['id'] ?? ''));
                    if ($id === '') continue;
                    $sets[$section][$id] = true;
                    if ($provider !== '') $sets['providers'][$provider] = true;
                }
            }
        }
        $out = [];
        foreach ($sets as $key => $values) {
            $out[$key] = array_keys($values);
            sort($out[$key]);
        }
        $out['authority_inherited'] = false;
        $out['fallback_authority_granted'] = false;
        return $out;
    }

    /** @return array<string,mixed> */
    private function blockedRole(string $roleDefinitionId, string $reason): array
    {
        return [
            'role_definition_id' => $roleDefinitionId,
            'role_identity_source' => 'exact_member_role_definition_id',
            'role_identity_immutable' => true,
            'state' => WorkforceCapabilityState::Blocked->value,
            'reason' => $reason,
            'provider_bindings' => [],
            'effective_access' => ['capabilities'=>[], 'tools'=>[], 'commands'=>[], 'signals'=>[], 'data_sources'=>[], 'workflows'=>[], 'providers'=>[], 'authority_inherited'=>false, 'fallback_authority_granted'=>false],
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
            'execution_authority_granted' => false,
        ];
    }

    private function policyAllowsProvider(array $policy, string $provider): bool
    {
        if (($policy['enabled'] ?? true) !== true) return false;
        return ! in_array($provider, $this->normalise((array) ($policy['disabled_providers'] ?? [])), true);
    }

    private function policyAllowsSurface(array $policy, string $section, string $id): bool
    {
        $disabled = array_merge(
            (array) ($policy['disabled_surfaces'] ?? []),
            (array) ($policy['disabled_' . $section] ?? []),
        );
        return ! in_array($id, $this->normalise($disabled), true);
    }

    /** @return array<string,mixed> */
    private function normalisePolicy(array $policy): array
    {
        $out = ['enabled' => ($policy['enabled'] ?? true) === true];
        foreach (['disabled_providers','disabled_surfaces', ...array_map(static fn (string $section): string => 'disabled_' . $section, self::SECTIONS)] as $key) {
            $out[$key] = $this->normalise((array) ($policy[$key] ?? []));
        }
        return $out;
    }

    /** @return list<string> */
    private function publishedIds(array $items): array
    {
        $ids = [];
        foreach ($items as $item) {
            if (! is_array($item)) continue;
            $id = trim((string) ($item['id'] ?? $item['name'] ?? $item['workflow_id'] ?? ''));
            if ($id !== '') $ids[] = $id;
        }
        return $this->normalise($ids);
    }

    /** @return list<string> */
    private function normalise(array $values): array
    {
        $out = array_values(array_unique(array_filter(array_map(static fn ($value): string => trim((string) $value), $values), static fn (string $value): bool => $value !== '')));
        sort($out);
        return $out;
    }
}
