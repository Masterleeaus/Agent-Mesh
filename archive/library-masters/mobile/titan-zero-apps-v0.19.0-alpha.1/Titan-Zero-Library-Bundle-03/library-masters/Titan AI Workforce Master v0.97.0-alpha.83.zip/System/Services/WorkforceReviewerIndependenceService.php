<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerIndependence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRuntimeProfile;
use RuntimeException;

final class WorkforceReviewerIndependenceService
{
    public function __construct(private readonly RuntimeProfileBindingService $profiles) {}

    /** @return array<string,mixed> */
    public function assess(WorkforceDecisionChain $chain, int $stage, WorkforceMember $reviewer): array
    {
        if ((int)$reviewer->company_id !== (int)$chain->company_id) {
            throw new RuntimeException('REVIEWER_COMPANY_SCOPE_MISMATCH');
        }

        $risk=strtolower((string)$chain->risk_class);
        $policy=in_array($risk,['critical','severe'],true) ? 'CRITICAL'
            : (in_array($risk,['high','regulated'],true) ? 'HIGH' : 'STANDARD');

        $profile=$this->profiles->ensureForMember($reviewer);
        $runtime=$this->identity($profile);

        $prior=WorkforceProcessingCheckpoint::query()
            ->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where('stage','<',$stage)
            ->whereNotNull('reviewer_member_id')
            ->orderBy('stage')
            ->get();

        $priorMemberIds=$prior->pluck('reviewer_member_id')->map(static fn($v)=>(int)$v)->all();
        $priorAssessments=WorkforceReviewerIndependence::query()
            ->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where('stage','<',$stage)
            ->orderBy('stage')
            ->get();

        $conflicts=[];
        if ((int)$reviewer->getKey()===(int)$chain->originator_member_id) {
            $conflicts[]='ORIGINATOR_SELF_REVIEW';
        }
        if (in_array((int)$reviewer->getKey(),$priorMemberIds,true)) {
            $conflicts[]='MEMBER_REUSED_ACROSS_STAGES';
        }

        $priorRuntimeFingerprints=$priorAssessments->pluck('runtime_identity_fingerprint')->filter()->all();
        if ($runtime['fingerprint']!==null && in_array($runtime['fingerprint'],$priorRuntimeFingerprints,true)) {
            $conflicts[]='RUNTIME_IDENTITY_REUSED_ACROSS_STAGES';
        }

        $sameProviderModel=false;
        foreach($priorAssessments as $assessment) {
            if ($runtime['provider']!==null && $runtime['model']!==null
                && $runtime['provider']===$assessment->provider_key
                && $runtime['model']===$assessment->model_key) {
                $sameProviderModel=true;
                break;
            }
        }
        if ($sameProviderModel && in_array($policy,['HIGH','CRITICAL'],true)) {
            $conflicts[]='PROVIDER_MODEL_PAIR_REUSED_FOR_HIGH_RISK_REVIEW';
        }

        if ($policy==='CRITICAL') {
            $priorProviders=$priorAssessments->pluck('provider_key')->filter()->unique()->all();
            if ($runtime['provider']===null) {
                $conflicts[]='CRITICAL_REVIEW_PROVIDER_IDENTITY_UNKNOWN';
            } elseif (in_array($runtime['provider'],$priorProviders,true)) {
                $conflicts[]='CRITICAL_REVIEW_REQUIRES_PROVIDER_DIVERSITY';
            }
        }

        $origin=WorkforceMember::query()->forCompany((int)$chain->company_id)->find($chain->originator_member_id);
        if ($origin) {
            if ((int)($reviewer->replaced_by_member_id ?? 0)===(int)$origin->getKey()
                || (int)($origin->replaced_by_member_id ?? 0)===(int)$reviewer->getKey()) {
                $conflicts[]='REPLACEMENT_PROXY_CONFLICT';
            }
            if ($stage>=2 && $policy!=='STANDARD'
                && (int)($reviewer->manager_id ?? 0)===(int)$origin->getKey()) {
                $conflicts[]='HIGH_RISK_REVIEWER_DIRECTLY_REPORTS_TO_ORIGINATOR';
            }
        }

        if ($stage===3 && ($chain->processing_domain ?? null)!==null
            && ($chain->receiving_domain ?? null)!==null
            && $chain->processing_domain!==$chain->receiving_domain) {
            $stage2=WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
                ->where('processing_id',$chain->processing_id)->where('stage',2)->first();
            if ($stage2?->reviewer_member_id) {
                $processor=WorkforceMember::query()->forCompany((int)$chain->company_id)->find($stage2->reviewer_member_id);
                if ($processor && (int)($processor->division_id ?? 0)===(int)($reviewer->division_id ?? 0)) {
                    $conflicts[]='RECEIVING_CHECKER_MUST_BE_ORGANISATIONALLY_SEPARATE_FOR_CROSS_DOMAIN_HANDOFF';
                }
            }
        }

        $memberIndependent=!in_array('ORIGINATOR_SELF_REVIEW',$conflicts,true)
            && !in_array('MEMBER_REUSED_ACROSS_STAGES',$conflicts,true);
        $runtimeIndependent=!in_array('RUNTIME_IDENTITY_REUSED_ACROSS_STAGES',$conflicts,true);
        $providerModelIndependent=!in_array('PROVIDER_MODEL_PAIR_REUSED_FOR_HIGH_RISK_REVIEW',$conflicts,true)
            && !in_array('CRITICAL_REVIEW_REQUIRES_PROVIDER_DIVERSITY',$conflicts,true)
            && !in_array('CRITICAL_REVIEW_PROVIDER_IDENTITY_UNKNOWN',$conflicts,true);
        $organisationalIndependent=!in_array('REPLACEMENT_PROXY_CONFLICT',$conflicts,true)
            && !in_array('HIGH_RISK_REVIEWER_DIRECTLY_REPORTS_TO_ORIGINATOR',$conflicts,true)
            && !in_array('RECEIVING_CHECKER_MUST_BE_ORGANISATIONALLY_SEPARATE_FOR_CROSS_DOMAIN_HANDOFF',$conflicts,true);

        $eligible=$conflicts===[];

        WorkforceReviewerIndependence::query()->updateOrCreate(
            ['company_id'=>(int)$chain->company_id,'processing_id'=>$chain->processing_id,'stage'=>$stage],
            [
                'decision_chain_id'=>$chain->getKey(),
                'reviewer_member_id'=>$reviewer->getKey(),
                'runtime_profile_id'=>$profile->profile_id,
                'provider_key'=>$runtime['provider'],
                'model_key'=>$runtime['model'],
                'runtime_identity_fingerprint'=>$runtime['fingerprint'],
                'member_independent'=>$memberIndependent,
                'runtime_independent'=>$runtimeIndependent,
                'provider_model_independent'=>$providerModelIndependent,
                'organisationally_independent'=>$organisationalIndependent,
                'eligible'=>$eligible,
                'policy_level'=>$policy,
                'conflicts'=>$conflicts,
                'evidence'=>[
                    'originator_member_id'=>$chain->originator_member_id,
                    'prior_reviewer_member_ids'=>$priorMemberIds,
                    'prior_runtime_fingerprints'=>$priorRuntimeFingerprints,
                    'risk_class'=>$chain->risk_class,
                    'processing_domain'=>$chain->processing_domain,
                    'receiving_domain'=>$chain->receiving_domain,
                ],
                'assessed_at'=>now(),
            ]
        );

        return [
            'eligible'=>$eligible,'policy_level'=>$policy,'conflicts'=>$conflicts,
            'runtime_profile_id'=>$profile->profile_id,'provider_key'=>$runtime['provider'],
            'model_key'=>$runtime['model'],'runtime_identity_fingerprint'=>$runtime['fingerprint'],
        ];
    }

    public function assertEligible(WorkforceDecisionChain $chain, int $stage, WorkforceMember $reviewer): array
    {
        $assessment=$this->assess($chain,$stage,$reviewer);
        if (! $assessment['eligible']) {
            throw new RuntimeException('REVIEWER_INDEPENDENCE_REQUIRED:'.implode(',',$assessment['conflicts']));
        }
        return $assessment;
    }

    /** @return array{provider:?string,model:?string,fingerprint:?string} */
    private function identity(WorkforceRuntimeProfile $profile): array
    {
        $provider=(array)($profile->provider_policy ?? []);
        $model=(array)($profile->model_policy ?? []);
        $providerKey=$this->value($provider['engine'] ?? $provider['provider'] ?? null);
        $modelKey=$this->value($model['model'] ?? $model['id'] ?? null);
        $profileId=$this->value($profile->profile_id);
        $fingerprint=$profileId===null ? null : hash('sha256',implode('|',[
            $profileId,$providerKey ?? 'unknown-provider',$modelKey ?? 'unknown-model',(string)($profile->fingerprint ?? '')
        ]));
        return ['provider'=>$providerKey,'model'=>$modelKey,'fingerprint'=>$fingerprint];
    }

    private function value(mixed $value): ?string
    {
        $v=trim((string)($value ?? ''));
        return $v===''?null:$v;
    }
}
