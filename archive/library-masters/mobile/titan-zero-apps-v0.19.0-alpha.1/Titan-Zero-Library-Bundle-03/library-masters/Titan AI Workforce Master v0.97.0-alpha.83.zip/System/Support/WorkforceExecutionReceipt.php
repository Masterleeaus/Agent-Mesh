<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use InvalidArgumentException;

final class WorkforceExecutionReceipt
{
    /** @return array<string,mixed> */
    public static function validate(mixed $receipt, array $expected): array
    {
        if (is_object($receipt) && method_exists($receipt, 'toArray')) $receipt = $receipt->toArray();
        if (! is_array($receipt)) throw new InvalidArgumentException('Execution receipt must be a structured object.');

        foreach (['receipt_id','company_id','task_id','capability','intent_id','intent_sha256','idempotency_key','status','executed_at'] as $key) {
            if (! array_key_exists($key, $receipt) || $receipt[$key] === null || $receipt[$key] === '') {
                throw new InvalidArgumentException('Execution receipt missing '.$key.'.');
            }
        }
        if (! in_array(strtoupper((string) $receipt['status']), ['SUCCEEDED','COMPLETED','EXECUTED'], true)) {
            throw new InvalidArgumentException('Execution receipt is not successful.');
        }
        foreach (['company_id','task_id','capability','intent_id','intent_sha256','idempotency_key'] as $key) {
            if ((string) ($receipt[$key] ?? '') !== (string) ($expected[$key] ?? '')) {
                throw new InvalidArgumentException('Execution receipt identity mismatch for '.$key.'.');
            }
        }
        if (! preg_match('/^[a-f0-9]{64}$/', strtolower((string) $receipt['intent_sha256']))) {
            throw new InvalidArgumentException('Execution receipt intent hash is invalid.');
        }
        if (strtotime((string) $receipt['executed_at']) === false) {
            throw new InvalidArgumentException('Execution receipt executed_at is invalid.');
        }

        $receipt['status'] = strtoupper((string) $receipt['status']);
        $receipt['receipt_sha256'] = self::sha256($receipt);
        return $receipt;
    }

    public static function sha256(array $value): string
    {
        return hash('sha256', json_encode(self::canonical($value), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }

    private static function canonical(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map([self::class, 'canonical'], $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = self::canonical($item);
        return $value;
    }
}
