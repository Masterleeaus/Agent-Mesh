<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class WorkforceCapabilityBindingValidator
{
    /** @param array<string,mixed> $contribution */
    public static function assertValid(array $contribution): void
    {
        if (($contribution['schema_version'] ?? null) !== '1.0') {
            throw new RuntimeException('Workforce capability binding schema_version must be 1.0.');
        }
        $extension = $contribution['extension'] ?? null;
        if (! is_array($extension) || trim((string) ($extension['key'] ?? '')) === '' || trim((string) ($extension['version'] ?? '')) === '') {
            throw new RuntimeException('Workforce capability binding requires extension.key and extension.version.');
        }
        $ownership = $contribution['ownership'] ?? null;
        if (! is_array($ownership)
            || ($ownership['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($ownership['provider_owns_execution_surfaces'] ?? null) !== true
            || ($ownership['role_definitions_owned_by_provider'] ?? null) !== false) {
            throw new RuntimeException('Workforce capability binding ownership contract is invalid.');
        }
        foreach (['role_bindings','capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
            if (! isset($contribution[$section]) || ! is_array($contribution[$section])) {
                throw new RuntimeException("Workforce capability binding {$section} must be an array.");
            }
        }

        $roleIds = [];
        $intrinsic = new IntrinsicRoleCatalog();
        foreach ($contribution['role_bindings'] as $binding) {
            if (! is_array($binding)) throw new RuntimeException('Workforce role binding must be an object.');
            $roleId = trim((string) ($binding['role_definition_id'] ?? ''));
            if ($roleId === '' || (! $intrinsic->find($roleId) && $roleId !== ExecutiveRoleCatalog::BUSINESS_MANAGER_ROLE_DEFINITION_ID)) {
                throw new RuntimeException("Workforce capability binding references unknown intrinsic role {$roleId}.");
            }
            if (($binding['authority_inherited'] ?? null) !== false) {
                throw new RuntimeException("Workforce capability binding {$roleId} must not inherit authority.");
            }
            if (isset($roleIds[$roleId])) throw new RuntimeException("Duplicate Workforce capability binding for {$roleId}.");
            $roleIds[$roleId] = true;
            foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
                if (! is_array($binding[$section] ?? null)) throw new RuntimeException("Workforce role binding {$roleId} {$section} must be an array.");
            }
        }
    }
}
