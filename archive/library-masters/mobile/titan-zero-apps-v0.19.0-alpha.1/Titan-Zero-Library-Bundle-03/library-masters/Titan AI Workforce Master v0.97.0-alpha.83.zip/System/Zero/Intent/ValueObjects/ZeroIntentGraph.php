<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects;

use InvalidArgumentException;

final readonly class ZeroIntentGraph
{
    /** @param list<ZeroIntentNode> $nodes */
    public function __construct(public string $graphId, public array $nodes)
    {
        if (trim($this->graphId) === '') throw new InvalidArgumentException('Intent graph_id is required.');
        foreach ($this->nodes as $node) if (! $node instanceof ZeroIntentNode) throw new InvalidArgumentException('Intent graph nodes must be ZeroIntentNode values.');
        $ids = array_map(static fn (ZeroIntentNode $node): string => $node->nodeId, $this->nodes);
        if (count($ids) !== count(array_unique($ids))) throw new InvalidArgumentException('Intent graph node IDs must be unique.');
        foreach ($this->nodes as $node) {
            foreach ($node->dependsOn as $dependency) {
                if (! in_array($dependency, $ids, true)) throw new InvalidArgumentException("Unknown intent dependency: {$dependency}");
                if ($dependency === $node->nodeId) throw new InvalidArgumentException('Intent node cannot depend on itself.');
            }
        }
        $this->assertAcyclic();
    }

    private function assertAcyclic(): void
    {
        $dependencies = [];
        foreach ($this->nodes as $node) $dependencies[$node->nodeId] = $node->dependsOn;
        $visiting = [];
        $visited = [];
        $visit = function (string $id) use (&$visit, &$visiting, &$visited, $dependencies): void {
            if (isset($visited[$id])) return;
            if (isset($visiting[$id])) throw new InvalidArgumentException('Intent graph must be acyclic.');
            $visiting[$id] = true;
            foreach ($dependencies[$id] ?? [] as $dependency) $visit($dependency);
            unset($visiting[$id]);
            $visited[$id] = true;
        };
        foreach (array_keys($dependencies) as $id) $visit($id);
    }

    public function isCompound(): bool
    {
        return count($this->nodes) > 1;
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'graph_id' => $this->graphId,
            'compound' => $this->isCompound(),
            'node_count' => count($this->nodes),
            'nodes' => array_map(static fn (ZeroIntentNode $node): array => $node->toArray(), $this->nodes),
        ];
    }
}
