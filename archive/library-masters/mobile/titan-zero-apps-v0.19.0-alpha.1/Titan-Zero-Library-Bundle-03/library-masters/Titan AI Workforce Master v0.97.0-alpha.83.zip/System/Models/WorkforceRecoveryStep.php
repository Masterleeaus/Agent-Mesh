<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceRecoveryStep extends Model
{
    protected $table='ext_titan_ai_workforce_recovery_steps';
    protected $guarded=[];
    protected $casts=[
        'sequence'=>'integer','revision'=>'integer','proposed_action'=>'array','approval_evidence'=>'array',
        'execution_receipt'=>'array','verification'=>'array','proposed_at'=>'datetime','verified_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
