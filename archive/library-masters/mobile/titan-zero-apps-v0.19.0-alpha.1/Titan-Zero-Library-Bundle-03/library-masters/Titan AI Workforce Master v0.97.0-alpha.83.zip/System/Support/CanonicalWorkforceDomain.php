<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

/** Canonical Workforce-owned business-organisation vocabulary. */
final class CanonicalWorkforceDomain
{
    public const OBJECTS = [
        'organisation', 'division', 'team', 'role', 'responsibility', 'member',
        'work_item', 'action', 'trigger', 'council', 'delegation', 'handoff',
        'escalation', 'evidence', 'outcome', 'performance',
    ];

    public const LEGACY_ALIASES = [
        'task' => 'work_item',
        'schedule' => 'trigger',
        'role_definition_manifest' => 'role',
        'performance_history' => 'performance',
    ];

    public const CANONICAL_IDENTITY = [
        'tenant' => 'company_id',
        'role' => 'role_definition_id',
        'member' => 'workforce_member_id',
        'work_item' => 'task_uuid',
        'human_actor' => 'user_id',
        'vertical' => 'task.vertical',
        'workflow' => 'task.workflow_ref',
    ];

    public static function canonicalName(string $name): string
    {
        return self::LEGACY_ALIASES[$name] ?? $name;
    }

    public static function owns(string $name): bool
    {
        return in_array(self::canonicalName($name), self::OBJECTS, true);
    }
}
