<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Contracts;

use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentRequest;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentResolution;

interface ZeroIntentResolverContract
{
    public function resolve(ZeroIntentRequest $request): ZeroIntentResolution;
}
