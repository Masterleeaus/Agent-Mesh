<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanAIWorkforce\System\Contracts\AgentRuntimeContract;
use App\Extensions\TitanAIWorkforce\System\Adapters\TitanAIRuntimeAdapter;
use App\Extensions\TitanAIWorkforce\System\Services\FailClosedAgentRuntime;
use App\Extensions\TitanAIWorkforce\System\Services\AgentRuntimeGateway;
use App\Extensions\TitanAIWorkforce\System\Services\RuntimeProfileBindingService;
use App\Extensions\TitanAIWorkforce\System\Services\AgentWorkflowProposalIngressService;
use App\Extensions\TitanAIWorkforce\System\Services\AgentTriggerSignalIngressService;
use App\Extensions\TitanAIWorkforce\System\Services\AgentWorkflowRuntimeBridge;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\DispatchDueWorkforceSchedulesCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\RunWorkforceProactiveManagementCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\SyncWorkforceResponsibilitiesCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\RetryWorkforceSignalOutboxCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\ReconcileWorkforceDefinitionsCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\SyncWorkforceMenuCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\RouteWorkforceNotificationsCommand;
use App\Extensions\TitanAIWorkforce\System\Http\Controllers\WorkforceController;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePermissions;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicDivisionCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicRoleCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicResponsibilityCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\IntrinsicRelationshipCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\ExecutiveRoleCatalog;
use App\Extensions\TitanAIWorkforce\System\Http\Middleware\AuthorizeWorkforceRequest;
use App\Extensions\TitanAIWorkforce\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Navigation\HostNavigationRegistrar;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceNotification;
use App\Extensions\TitanAIWorkforce\System\Policies\WorkforceMemberPolicy;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEventTriggerService;
use App\Extensions\TitanAIWorkforce\System\Services\ProactiveManagerService;
use App\Extensions\TitanAIWorkforce\System\Services\ProactiveResponsibilityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceQueueHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProactiveRuntimeService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceObjectiveIngressService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePlanningService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePlanningIntelligenceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkloadSharingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDecisionRightsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDependencyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceGraphService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEscalationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEscalationDeadlockCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceMaturityService;
use App\Extensions\TitanAIWorkforce\System\Services\ManagerContinuityService;
use App\Extensions\TitanAIWorkforce\System\Services\ManagerOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCouncilService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDisputeService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOutcomeFeedbackService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceJourneySpineService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOutcomeHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceControlPlaneLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceExecutionService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceExecutionRecoveryService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePostActionVerificationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAutonomyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePreExecutionGovernanceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceTrustHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceVerticalOverlayService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceControlRoomService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePerformanceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceVisualWorkGraphService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManagerCommandCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceStaffingProposalService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManifestLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceMemberLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCapabilityAvailabilityService;
use App\Extensions\TitanAIWorkforce\System\Services\TitanZeroChiefOfStaffService;
use App\Extensions\TitanAIWorkforce\System\Services\TitanZeroAuthorityGuard;
use App\Extensions\TitanAIWorkforce\System\Services\ExecutiveLayerService;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\CoreWorkforceCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCanonicalCapabilityMatrix;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityStateResolver;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceOrganisationPolicyRegistry;
use App\Extensions\TitanAIWorkforce\System\TitanAI\WorkforceConversationSourceAdapter;
use App\Extensions\TitanAIWorkforce\System\TitanAI\WorkforceSourcePolicy;
use App\Extensions\TitanAIWorkforce\System\Adapters\WorkforcePeopleContextProviderAdapter;
use App\Extensions\TitanAIWorkforce\System\Adapters\WorkforcePayrollContextProviderAdapter;
use App\Extensions\TitanAIWorkforce\System\Adapters\WorkforceTitanTrustContextProviderAdapter;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceContextFederationProfiles;
use App\Extensions\TitanAIWorkforce\System\Adapters\WorkforceFederatedSchemaContextProviderAdapter;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProviderRoutingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceBusinessContextGateway;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceBusinessContextProviderRegistry;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceGoalService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceBusinessGoalPlanningService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManagerCoordinationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePeoplePayrollOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCustomerRevenueOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceFieldSchedulingResourceOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceFinanceControlCommercialIntelligenceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceWorkItemService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceWorkItemOrchestrationGraphService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceSignalToWorkService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProviderContractReconciliationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProviderHealthObservabilityService;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePlatformCapabilityIndex;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceBusinessRoleModel;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceProviderRoutingPolicy;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceBusinessContextSourceCatalog;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroSemanticCapabilityCatalogueContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilityDiscoveryContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilitySimilarityScorerContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services\ZeroSemanticCapabilityCatalogue;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services\ZeroCapabilityDiscoveryService;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services\ZeroDeterministicCapabilitySimilarityScorer;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextGatewayContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextReaderContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Adapters\ZeroWorkforceBusinessContextReader;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Services\ZeroBusinessContextGateway;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Contracts\ZeroConversationContextStoreContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Services\ZeroInMemoryConversationContextStore;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Services\ZeroConversationContextService;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Contracts\ZeroIntentResolverContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services\ZeroBaselineIntentClassifier;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services\ZeroMultiIntentDecompositionService;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services\ZeroEntityParameterBindingService;
use App\Extensions\TitanAIWorkforce\System\Zero\LocalAI\Services\ZeroLocalAiRuntimePolicy;
use App\Extensions\TitanAIWorkforce\System\Zero\AI\Services\ZeroAdaptiveAiRouter;
use App\Extensions\TitanAIWorkforce\System\Zero\Planning\Services\ZeroPlanCompiler;
use App\Extensions\TitanAIWorkforce\System\Zero\Governance\Services\ZeroExecutionPreflight;
use App\Extensions\TitanAIWorkforce\System\Zero\Interaction\Services\ZeroGenerativeInteractionRuntime;
use App\Extensions\TitanAIWorkforce\System\Zero\Proactive\Services\ZeroSignalWisdomActionLoop;
use App\Extensions\TitanAIWorkforce\System\Zero\Runtime\Services\ZeroIntelligenceConvergenceRuntime;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services\ZeroIntentResolutionService;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

use App\Extensions\TitanAIWorkforce\System\Console\Commands\ValidateWorkforceAuthorityGraphCommand;
use App\Extensions\TitanAIWorkforce\System\Console\Commands\ExpireOverdueProcessingStagesCommand;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAuthorityGraphValidator;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceKnowledgeUncertaintyService;
use App\Extensions\TitanAIWorkforce\System\Services\KnowledgeAuthorityPreflightService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAdversarialExecutionGuard;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceRecoveryDecisionService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceUnifiedObservabilityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceUiCapabilityRegistryService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceStructuredOutputService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceResourceEconomicsRegistry;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEntitlementService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCommercialCapabilityPolicyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceResourceBudgetService;
use App\Extensions\TitanAIWorkforce\System\Services\CostSovereigntyRouter;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCostReceiptService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceResourceRoutingSummaryService;

use App\Extensions\TitanAIWorkforce\System\Services\WorkforceReachGrowthOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAutonomyAgreementService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceMemberRatingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceThreeStageProcessingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDecisionChainService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceReviewerIndependenceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceReviewerResolutionService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceActionReviewPacketService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProcessingLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDecisionChallengeService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManagerEscalationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAssuranceCouncilEscalationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceFinalAuthorityGateService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceReviewerPerformanceFeedbackService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainAuditReconstructionService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainObservabilityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAdaptiveChainIntelligenceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePredictiveChainFailureService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainLearningPolicyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCrossDomainFederationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceFederatedRecoveryService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceConcurrencyGuardService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainPolicyAdminService;
class TitanAIWorkforceServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        // Workforce owns the canonical organisation, roles and responsibilities. Domain extensions contribute capabilities and runtime integrations.
        $this->app->singleton(WorkforceManifestRegistry::class, fn ($app) => new WorkforceManifestRegistry($app));
        $this->app->singleton(WorkforceRoleRegistry::class, fn () => new WorkforceRoleRegistry());
        $this->app->singleton(WorkforceEcosystemCapabilityRegistry::class);
        $this->app->singleton(WorkforceCanonicalCapabilityMatrix::class);
        $this->app->singleton(WorkforcePlatformCapabilityIndex::class);
        $this->app->singleton(ZeroSemanticCapabilityCatalogue::class);
        $this->app->singleton(ZeroSemanticCapabilityCatalogueContract::class, fn ($app) => $app->make(ZeroSemanticCapabilityCatalogue::class));
        $this->app->singleton(ZeroDeterministicCapabilitySimilarityScorer::class);
        $this->app->singleton(ZeroCapabilitySimilarityScorerContract::class, fn ($app) => $app->make(ZeroDeterministicCapabilitySimilarityScorer::class));
        $this->app->singleton(ZeroCapabilityDiscoveryService::class);
        $this->app->singleton(ZeroCapabilityDiscoveryContract::class, fn ($app) => $app->make(ZeroCapabilityDiscoveryService::class));
        $this->app->singleton(ZeroWorkforceBusinessContextReader::class);
        $this->app->singleton(ZeroBusinessContextReaderContract::class, fn ($app) => $app->make(ZeroWorkforceBusinessContextReader::class));
        $this->app->singleton(ZeroBusinessContextGateway::class);
        $this->app->singleton(ZeroBusinessContextGatewayContract::class, fn ($app) => $app->make(ZeroBusinessContextGateway::class));
        $this->app->singleton(ZeroInMemoryConversationContextStore::class);
        $this->app->singleton(ZeroConversationContextStoreContract::class, fn ($app) => $app->make(ZeroInMemoryConversationContextStore::class));
        $this->app->singleton(ZeroConversationContextService::class);
        $this->app->singleton(ZeroIntelligenceConvergenceRuntime::class);
        $this->app->singleton(ZeroSignalWisdomActionLoop::class);
        $this->app->singleton(ZeroGenerativeInteractionRuntime::class);
        $this->app->singleton(ZeroExecutionPreflight::class);
        $this->app->singleton(ZeroPlanCompiler::class);
        $this->app->singleton(ZeroAdaptiveAiRouter::class, function ($app): ZeroAdaptiveAiRouter {
            $service = 'titan.apps.intelligence-routing';
            $router = $app->bound($service) ? $app->make($service) : null;
            return new ZeroAdaptiveAiRouter($router);
        });
        $this->app->singleton(ZeroLocalAiRuntimePolicy::class);
        $this->app->singleton(ZeroEntityParameterBindingService::class);
        $this->app->singleton(ZeroMultiIntentDecompositionService::class);
        $this->app->singleton(ZeroBaselineIntentClassifier::class, function ($app): ZeroBaselineIntentClassifier {
            $service = 'titan.apps.interaction';
            $interaction = $app->bound($service) ? $app->make($service) : null;
            return new ZeroBaselineIntentClassifier($interaction);
        });
        $this->app->singleton(ZeroIntentResolutionService::class);
        $this->app->singleton(ZeroIntentResolverContract::class, fn ($app) => $app->make(ZeroIntentResolutionService::class));
        $this->app->singleton(WorkforceBusinessRoleModel::class);
        $this->app->singleton(WorkforceResponsibilityCapabilityRequirements::class);
        $this->app->singleton(WorkforceProviderRoutingPolicy::class);
        $this->app->singleton(WorkforceProviderRoutingService::class);
        $this->app->singleton(WorkforceResourceEconomicsRegistry::class);
        $this->app->singleton(WorkforceEntitlementService::class);
        $this->app->singleton(WorkforceCommercialCapabilityPolicyService::class);
        $this->app->singleton(WorkforceResourceBudgetService::class);
        $this->app->singleton(CostSovereigntyRouter::class);
        $this->app->singleton(WorkforceCostReceiptService::class);
        $this->app->singleton(WorkforceResourceRoutingSummaryService::class);
        $this->app->singleton(WorkforceKnowledgeUncertaintyService::class);
        $this->app->singleton(KnowledgeAuthorityPreflightService::class);
        $this->app->singleton(WorkforceAuthorityGraphValidator::class);
        $this->app->singleton(WorkforceAdversarialExecutionGuard::class);
        $this->app->singleton(WorkforceRecoveryDecisionService::class);
        $this->app->singleton(WorkforceUnifiedObservabilityService::class);
        $this->app->singleton(WorkforceStructuredOutputService::class);
        $this->app->singleton(WorkforceUiCapabilityRegistryService::class);
        $this->app->singleton(WorkforceBusinessContextSourceCatalog::class);
        $this->app->singleton(WorkforceBusinessContextProviderRegistry::class);
        $this->app->singleton(WorkforceBusinessContextGateway::class);
        $this->app->singleton(WorkforceGoalService::class);
        $this->app->singleton(WorkforceBusinessGoalPlanningService::class);
        $this->app->singleton(WorkforceManagerCoordinationService::class);
        $this->app->singleton(WorkforcePeoplePayrollOperationsService::class);
        $this->app->singleton(WorkforceCustomerRevenueOperationsService::class);
        $this->app->singleton(WorkforceFieldSchedulingResourceOperationsService::class);
        $this->app->singleton(WorkforceFinanceControlCommercialIntelligenceService::class);
        $this->app->singleton(WorkforceReachGrowthOperationsService::class);
        $this->app->alias(WorkforceReachGrowthOperationsService::class, 'titan.workforce.reach-growth-operations');
        $this->app->alias(WorkforceFinanceControlCommercialIntelligenceService::class, 'titan.workforce.finance-control');
        $this->app->alias(WorkforceFieldSchedulingResourceOperationsService::class, 'titan.workforce.field-resource-operations');
        $this->app->alias(WorkforceCustomerRevenueOperationsService::class, 'titan.workforce.customer-revenue-operations');
        $this->app->alias(WorkforcePeoplePayrollOperationsService::class, 'titan.workforce.people-payroll-operations');
        $this->app->alias(WorkforceManagerCoordinationService::class, 'titan.workforce.manager-coordination');
        $this->app->alias(WorkforceBusinessGoalPlanningService::class, 'titan.workforce.goal-planning');
        $this->app->singleton(WorkforceWorkItemService::class);
        $this->app->singleton(WorkforceWorkItemOrchestrationGraphService::class);
        $this->app->alias(WorkforceWorkItemOrchestrationGraphService::class, 'titan.workforce.work-item-graph');
        $this->app->singleton(WorkforceSignalToWorkService::class);
        $this->app->singleton(WorkforceProviderContractReconciliationService::class);
        $this->app->singleton(WorkforceProviderHealthObservabilityService::class);
        $this->app->alias(WorkforceProviderHealthObservabilityService::class, 'titan.workforce.provider-health');
        $this->app->alias(WorkforceProviderContractReconciliationService::class, 'titan.workforce.provider-reconciliation');
        $this->app->alias(WorkforceAuthorityGraphValidator::class, 'titan.workforce.authority-graph-validator');
        $this->app->alias(WorkforceKnowledgeUncertaintyService::class, 'titan.workforce.knowledge-uncertainty');
        $this->app->alias(KnowledgeAuthorityPreflightService::class, 'titan.workforce.knowledge-preflight');
        $this->app->alias(WorkforceResourceEconomicsRegistry::class, 'titan.workforce.resource-economics');
        $this->app->alias(WorkforceEntitlementService::class, 'titan.workforce.entitlements');
        $this->app->alias(WorkforceResourceBudgetService::class, 'titan.workforce.resource-budgets');
        $this->app->alias(CostSovereigntyRouter::class, 'titan.workforce.cost-sovereignty');
        $this->app->alias(WorkforceCostReceiptService::class, 'titan.workforce.cost-receipts');
        $this->app->alias(WorkforceResourceRoutingSummaryService::class, 'titan.workforce.resource-routing-summary');
        $this->app->alias(WorkforceRecoveryDecisionService::class, 'titan.workforce.recovery-decisions');
        $this->app->alias(WorkforceUnifiedObservabilityService::class, 'titan.workforce.unified-observability');
        $this->app->alias(WorkforceUiCapabilityRegistryService::class, 'titan.workforce.ui-capability-registry');
        $this->app->singleton(WorkforcePeopleContextProviderAdapter::class);
        $this->app->singleton(WorkforcePayrollContextProviderAdapter::class);
        $this->app->singleton(WorkforceTitanTrustContextProviderAdapter::class);
        $this->app->singleton(WorkforceContextFederationProfiles::class);
        $this->app->singleton('titan.workforce.context-provider.titan-trust', fn ($app) => $app->make(WorkforceTitanTrustContextProviderAdapter::class));
        $this->app->singleton('titan.workforce.context-provider.onboarding-pro', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('onboarding-pro');
            if (! is_array($profile)) throw new \RuntimeException('Missing onboarding-pro context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-reach-campaigns', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-reach-campaigns');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-reach-campaigns context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-reach-agent', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-reach-agent');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-reach-agent context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-reach-pro', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-reach-pro');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-reach-pro context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-reach-flow', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-reach-flow');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-reach-flow context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-omnichannel', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-omnichannel');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-omnichannel context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-bookings-quotes', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-bookings-quotes');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-bookings-quotes context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.crm', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('crm');
            if (! is_array($profile)) throw new \RuntimeException('Missing crm context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-field', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-field');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-field context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-assets', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-assets');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-assets context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-time-attendance', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-time-attendance');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-time-attendance context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-connect', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-connect');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-connect context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-ledger', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-ledger');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-ledger context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-maps-intelligence', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-maps-intelligence');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-maps-intelligence context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-governance', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-governance');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-governance context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-assurance', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-assurance');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-assurance context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-shield', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-shield');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-shield context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-signal-engine', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-signal-engine');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-signal-engine context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-knowledge-authority', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-knowledge-authority');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-knowledge-authority context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-rewind', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-rewind');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-rewind context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-wisdom', function ($app) {
            $profiles = $app->make(WorkforceContextFederationProfiles::class);
            $profile = $profiles->provider('titan-wisdom');
            if (! is_array($profile)) throw new \RuntimeException('Missing titan-wisdom context federation profile.');
            $connection = $app->make('db')->connection();
            return new WorkforceFederatedSchemaContextProviderAdapter($connection, $connection->getSchemaBuilder(), $profile);
        });
        $this->app->singleton('titan.workforce.context-provider.titan-people', fn ($app) => $app->make(WorkforcePeopleContextProviderAdapter::class));
        $this->app->singleton('titan.workforce.context-provider.titan-payroll', fn ($app) => $app->make(WorkforcePayrollContextProviderAdapter::class));
        $this->app->alias(WorkforcePlatformCapabilityIndex::class, 'titan.workforce.platform-capability-index');
        $this->app->alias(WorkforceProviderRoutingService::class, 'titan.workforce.provider-routing');
        $this->app->alias(WorkforceBusinessContextGateway::class, 'titan.workforce.business-context');
        $this->app->alias(WorkforceGoalService::class, 'titan.workforce.goals');
        $this->app->alias(WorkforceWorkItemService::class, 'titan.workforce.work-items');
        $this->app->alias(WorkforceSignalToWorkService::class, 'titan.workforce.signal-to-work');
        $this->app->alias(WorkforceCanonicalCapabilityMatrix::class, 'titan.workforce.canonical-capability-matrix');
        $this->app->alias(WorkforceEcosystemCapabilityRegistry::class, 'titan.workforce.ecosystem-capability-registry');
        $this->app->singleton(WorkforceControlPlaneIntegrationRegistry::class);
        $this->app->alias(WorkforceControlPlaneIntegrationRegistry::class, 'titan.workforce.control-plane-registry');
        $this->app->singleton(WorkforceControlPlaneLifecycleService::class);
        $this->app->alias(WorkforceControlPlaneLifecycleService::class, 'titan.workforce.control-plane-lifecycle');
        $this->app->singleton(WorkforceCapabilityBindingRegistry::class, fn ($app) => new WorkforceCapabilityBindingRegistry(
            $app,
            $app->make(WorkforceManifestRegistry::class),
            $app->make(WorkforceEcosystemCapabilityRegistry::class),
            $app->make(WorkforceCanonicalCapabilityMatrix::class),
        ));
        $this->app->alias(WorkforceCapabilityBindingRegistry::class, 'titan.workforce.capability-bindings');
        $this->app->alias(WorkforceCapabilityBindingRegistry::class, 'titan-workforce.capability-bindings');
        $this->app->singleton(WorkforceCapabilityStateResolver::class);
        $this->app->singleton(WorkforceAutonomyAgreementService::class);
        $this->app->singleton(WorkforceMemberRatingService::class);
        $this->app->singleton(WorkforceReviewerIndependenceService::class);
        $this->app->singleton(WorkforceReviewerResolutionService::class);
        $this->app->singleton(WorkforceActionReviewPacketService::class);
        $this->app->singleton(WorkforceProcessingLifecycleService::class);
        $this->app->singleton(WorkforceDecisionChallengeService::class);
        $this->app->singleton(WorkforceManagerEscalationService::class);
        $this->app->singleton(WorkforceAssuranceCouncilEscalationService::class);
        $this->app->singleton(WorkforceFinalAuthorityGateService::class);
        $this->app->singleton(WorkforceReviewerPerformanceFeedbackService::class);
        $this->app->singleton(WorkforceChainAuditReconstructionService::class);
        $this->app->singleton(WorkforceChainObservabilityService::class);
        $this->app->singleton(WorkforceAdaptiveChainIntelligenceService::class);
        $this->app->singleton(WorkforcePredictiveChainFailureService::class);
        $this->app->singleton(WorkforceChainLearningPolicyService::class);
        $this->app->singleton(WorkforceCrossDomainFederationService::class);
        $this->app->singleton(WorkforceFederatedRecoveryService::class);
        $this->app->singleton(WorkforceConcurrencyGuardService::class);
        $this->app->singleton(WorkforceChainPolicyAdminService::class);
        $this->app->singleton(WorkforceDecisionChainService::class);
        $this->app->singleton(WorkforceThreeStageProcessingService::class);
        $this->app->singleton(WorkforceCapabilityAvailabilityService::class);
        $this->app->singleton(WorkforceProviderRoutingPolicy::class);
        $this->app->singleton(WorkforceProviderRoutingService::class);
        $this->app->singleton(WorkforceBusinessContextSourceCatalog::class);
        $this->app->singleton(WorkforceBusinessContextProviderRegistry::class);
        $this->app->singleton(WorkforceBusinessContextGateway::class);
        $this->app->singleton(WorkforceGoalService::class);
        $this->app->singleton(WorkforceBusinessGoalPlanningService::class);
        $this->app->singleton(WorkforceManagerCoordinationService::class);
        $this->app->singleton(WorkforcePeoplePayrollOperationsService::class);
        $this->app->singleton(WorkforceCustomerRevenueOperationsService::class);
        $this->app->singleton(WorkforceFieldSchedulingResourceOperationsService::class);
        $this->app->singleton(WorkforceFinanceControlCommercialIntelligenceService::class);
        $this->app->alias(WorkforceFinanceControlCommercialIntelligenceService::class, 'titan.workforce.finance-control');
        $this->app->alias(WorkforceFieldSchedulingResourceOperationsService::class, 'titan.workforce.field-resource-operations');
        $this->app->alias(WorkforceCustomerRevenueOperationsService::class, 'titan.workforce.customer-revenue-operations');
        $this->app->alias(WorkforcePeoplePayrollOperationsService::class, 'titan.workforce.people-payroll-operations');
        $this->app->alias(WorkforceManagerCoordinationService::class, 'titan.workforce.manager-coordination');
        $this->app->alias(WorkforceBusinessGoalPlanningService::class, 'titan.workforce.goal-planning');
        $this->app->singleton(WorkforceWorkItemService::class);
        $this->app->singleton(WorkforceWorkItemOrchestrationGraphService::class);
        $this->app->alias(WorkforceWorkItemOrchestrationGraphService::class, 'titan.workforce.work-item-graph');
        $this->app->singleton(WorkforceSignalToWorkService::class);
        $this->app->singleton(WorkforceProviderContractReconciliationService::class);
        $this->app->singleton(WorkforceProviderHealthObservabilityService::class);
        $this->app->alias(WorkforceProviderHealthObservabilityService::class, 'titan.workforce.provider-health');
        $this->app->alias(WorkforceProviderContractReconciliationService::class, 'titan.workforce.provider-reconciliation');
        $this->app->alias(WorkforceProviderRoutingService::class, 'titan.workforce.provider-routing');
        $this->app->alias(WorkforceBusinessContextGateway::class, 'titan.workforce.business-context');
        $this->app->alias(WorkforceBusinessContextProviderRegistry::class, 'titan.workforce.business-context-providers');
        $this->app->alias(WorkforceAutonomyAgreementService::class, 'titan.workforce.autonomy-agreements');
        $this->app->alias(WorkforceMemberRatingService::class, 'titan.workforce.member-ratings');
        $this->app->alias(WorkforceDecisionChainService::class, 'titan.workforce.decision-chain');
        $this->app->alias(WorkforceReviewerIndependenceService::class, 'titan.workforce.reviewer-independence');
        $this->app->alias(WorkforceReviewerResolutionService::class, 'titan.workforce.reviewer-resolution');
        $this->app->alias(WorkforceActionReviewPacketService::class, 'titan.workforce.action-review-packets');
        $this->app->alias(WorkforceProcessingLifecycleService::class, 'titan.workforce.processing-lifecycle');
        $this->app->alias(WorkforceDecisionChallengeService::class, 'titan.workforce.decision-challenges');
        $this->app->alias(WorkforceManagerEscalationService::class, 'titan.workforce.manager-escalation');
        $this->app->alias(WorkforceAssuranceCouncilEscalationService::class, 'titan.workforce.assurance-council');
        $this->app->alias(WorkforceFinalAuthorityGateService::class, 'titan.workforce.final-authority-gate');
        $this->app->alias(WorkforceReviewerPerformanceFeedbackService::class, 'titan.workforce.reviewer-performance-feedback');
        $this->app->alias(WorkforceChainAuditReconstructionService::class, 'titan.workforce.chain-audit');
        $this->app->alias(WorkforceChainObservabilityService::class, 'titan.workforce.chain-observability');
        $this->app->alias(WorkforceAdaptiveChainIntelligenceService::class, 'titan.workforce.adaptive-chain');
        $this->app->alias(WorkforcePredictiveChainFailureService::class, 'titan.workforce.predictive-chain-failure');
        $this->app->alias(WorkforceChainLearningPolicyService::class, 'titan.workforce.chain-learning-policy');
        $this->app->alias(WorkforceCrossDomainFederationService::class, 'titan.workforce.cross-domain-federation');
        $this->app->alias(WorkforceFederatedRecoveryService::class, 'titan.workforce.federated-recovery');
        $this->app->alias(WorkforceConcurrencyGuardService::class, 'titan.workforce.concurrency-guard');
        $this->app->alias(WorkforceChainPolicyAdminService::class, 'titan.workforce.chain-policy-admin');
        $this->app->alias(WorkforceThreeStageProcessingService::class, 'titan.workforce.processing');
        $this->app->alias(WorkforceGoalService::class, 'titan.workforce.goals');
        $this->app->alias(WorkforceWorkItemService::class, 'titan.workforce.work-items');
        $this->app->alias(WorkforceSignalToWorkService::class, 'titan.workforce.signal-to-work');

        $this->app->alias(WorkforceCapabilityAvailabilityService::class, 'titan.workforce.capability-availability');
        $this->app->alias(WorkforceCapabilityAvailabilityService::class, 'titan-workforce.capability-availability');
        $this->app->singleton(TitanHostAuthorizationAdapter::class);
        $this->app->alias(WorkforceManifestRegistry::class, 'titan.workforce.manifests');
        $this->app->alias(WorkforceManifestRegistry::class, 'titan-workforce.manifests');
        $this->app->alias(WorkforceManifestRegistry::class, 'titan.workforce.manifest-registry');
        $this->app->alias(WorkforceRoleRegistry::class, 'titan.workforce.role-registry');

        // Versioned AI staff runtime port. Pass 4 late-binds the extracted Titan Agent Runtime
        // transport when installed, retains the legacy Titan AI adapter as compatibility fallback,
        // and otherwise fails closed. Workforce never imports Agent implementation classes.
        $this->app->singleton(FailClosedAgentRuntime::class);
        $this->app->singleton(AgentRuntimeContract::class, AgentRuntimeGateway::class);
        $this->app->alias(AgentRuntimeContract::class, AgentRuntimeContract::PROTOCOL);
        $this->app->singleton(RuntimeProfileBindingService::class);
        $this->app->singleton(TitanZeroChiefOfStaffService::class);
        $this->app->singleton(TitanZeroAuthorityGuard::class);
        $this->app->singleton(ExecutiveLayerService::class);
        $this->app->alias(RuntimeProfileBindingService::class, 'titan.workforce.runtime-profiles');
        $this->app->singleton('titan.ai-workforce.workflow-proposal/1', fn ($app) => $app->make(AgentWorkflowProposalIngressService::class));
        $this->app->singleton('titan.ai-workforce.agent-trigger/1', fn ($app) => $app->make(AgentTriggerSignalIngressService::class));
        $this->app->singleton(AgentWorkflowRuntimeBridge::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views/workforce', $this->registerKey());
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        Gate::policy(WorkforceMember::class, WorkforceMemberPolicy::class);
        $this->app['router']->aliasMiddleware('titan.workforce.authorize', AuthorizeWorkforceRequest::class);
        $this->registerRoutes();
        $this->registerCommands();
        $this->registerEngineAdapters();
        $this->app->booted(function () {
            // Discover extension-owned workforce manifests after all extension service providers have registered.
            $this->app->make(WorkforceManifestRegistry::class)->all();
            $this->app->make(WorkforceCapabilityBindingRegistry::class)->contributions();
            $navigation = $this->app->make(HostNavigationRegistrar::class);
            $navigation->registerContributions();
            $navigation->syncHostMenu();
        });
    }


    private function registerEngineAdapters(): void
    {
        // Titan AI Core may submit organisational objectives through this stable ingress contract.
        $this->app->singleton('titan.workforce.objectives', fn ($app) => $app->make(WorkforceObjectiveIngressService::class));
        $this->app->singleton('titan.workforce.capabilities', fn () => WorkforceCapabilityCatalog::all());
        $this->app->singleton('titan.workforce.roles', fn () => WorkforceRoleRegistry::all());
        $this->app->singleton('titan.workforce.manifest-health', fn ($app) => $app->make(WorkforceManifestRegistry::class)->health());
        $this->app->singleton('titan.workforce.provider-contributions', fn ($app) => $app->make(WorkforceCapabilityBindingRegistry::class)->contributions());
        $this->app->singleton('titan.workforce.ecosystem-capabilities', fn ($app) => $app->make(WorkforceEcosystemCapabilityRegistry::class)->all());
        $this->app->singleton('titan.workforce.capability-matrix', fn ($app) => $app->make(WorkforceCanonicalCapabilityMatrix::class)->all());
        $this->app->singleton('titan.zero.conversation-context', fn ($app) => $app->make(ZeroConversationContextService::class));
        $this->app->singleton('titan.zero.conversation-context-store', fn ($app) => $app->make(ZeroConversationContextStoreContract::class));
        $this->app->singleton('titan.zero.intelligence-runtime', fn ($app) => $app->make(ZeroIntelligenceConvergenceRuntime::class));
        $this->app->singleton('titan.zero.signal-wisdom-loop', fn ($app) => $app->make(ZeroSignalWisdomActionLoop::class));
        $this->app->singleton('titan.zero.generative-interaction', fn ($app) => $app->make(ZeroGenerativeInteractionRuntime::class));
        $this->app->singleton('titan.zero.execution-preflight', fn ($app) => $app->make(ZeroExecutionPreflight::class));
        $this->app->singleton('titan.zero.plan-compiler', fn ($app) => $app->make(ZeroPlanCompiler::class));
        $this->app->singleton('titan.zero.adaptive-ai-router', fn ($app) => $app->make(ZeroAdaptiveAiRouter::class));
        $this->app->singleton('titan.zero.local-ai-runtime', fn ($app) => $app->make(ZeroLocalAiRuntimePolicy::class));
        $this->app->singleton('titan.zero.entity-parameter-binding', fn ($app) => $app->make(ZeroEntityParameterBindingService::class));
        $this->app->singleton('titan.zero.multi-intent', fn ($app) => $app->make(ZeroMultiIntentDecompositionService::class));
        $this->app->singleton('titan.zero.intent-resolution', fn ($app) => $app->make(ZeroIntentResolutionService::class));
        $this->app->singleton('titan.zero.intent-resolver', fn ($app) => $app->make(ZeroIntentResolverContract::class));
        $this->app->singleton('titan.zero.semantic-capabilities', fn ($app) => $app->make(ZeroSemanticCapabilityCatalogueContract::class));
        $this->app->singleton('titan.zero.capability-discovery', fn ($app) => $app->make(ZeroCapabilityDiscoveryContract::class));
        $this->app->singleton('titan.zero.capability-similarity', fn ($app) => $app->make(ZeroCapabilitySimilarityScorerContract::class));
        $this->app->singleton('titan.zero.business-context', fn ($app) => $app->make(ZeroBusinessContextGatewayContract::class));
        $this->app->singleton('titan.zero.business-context-reader', fn ($app) => $app->make(ZeroBusinessContextReaderContract::class));
        $this->app->singleton('titan.workforce.control-plane-registry', fn ($app) => $app->make(WorkforceControlPlaneIntegrationRegistry::class));
        $this->app->singleton('titan.workforce.control-plane-lifecycle', fn ($app) => $app->make(WorkforceControlPlaneLifecycleService::class));
        $this->app->singleton('titan.workforce.missions', fn ($app) => $app->make(WorkforceObjectiveIngressService::class));
        $this->app->singleton('titan.workforce.manifest-lifecycle', fn ($app) => $app->make(WorkforceManifestLifecycleService::class));
        $this->app->singleton('titan.workforce.member-lifecycle', fn ($app) => $app->make(WorkforceMemberLifecycleService::class));
        $this->app->singleton('titan.workforce.chief-of-staff', fn ($app) => $app->make(TitanZeroChiefOfStaffService::class));
        $this->app->singleton('titan.workforce.system-roles', fn () => CoreWorkforceCatalog::systemRoles());
        $this->app->singleton('titan.workforce.titan-zero-authority-guard', fn ($app) => $app->make(TitanZeroAuthorityGuard::class));
        $this->app->singleton('titan.workforce.executive-layer', fn ($app) => $app->make(ExecutiveLayerService::class));
        $this->app->singleton('titan.workforce.executive-roles', fn () => new ExecutiveRoleCatalog());
        $this->app->singleton('titan.workforce.organisation-policy', fn () => WorkforceOrganisationPolicyRegistry::all());
        $this->app->singleton('titan.workforce.planning', fn ($app) => $app->make(WorkforcePlanningService::class));
        $this->app->singleton('titan.workforce.responsibilities', fn () => WorkforceResponsibilityRegistry::all());
        $this->app->singleton('titan.workforce.queue-health', fn ($app) => $app->make(WorkforceQueueHealthService::class));
        $this->app->singleton('titan.workforce.proactive-runtime', fn ($app) => $app->make(WorkforceProactiveRuntimeService::class));
        $this->app->singleton('titan.workforce.proactive-management', fn ($app) => $app->make(ProactiveManagerService::class));
        $this->app->singleton('titan.workforce.proactive-responsibility-sync', fn ($app) => $app->make(ProactiveResponsibilityService::class));
        $this->app->singleton('titan.workforce.workload-sharing', fn ($app) => $app->make(WorkloadSharingService::class));
        $this->app->singleton('titan.workforce.organisation-graph', fn ($app) => $app->make(WorkforceGraphService::class));
        $this->app->singleton('titan.workforce.decision-rights', fn ($app) => $app->make(WorkforceDecisionRightsService::class));
        $this->app->singleton('titan.workforce.chain-integrity', fn ($app) => $app->make(WorkforceDependencyService::class));
        $this->app->singleton('titan.workforce.escalation', fn ($app) => $app->make(WorkforceEscalationService::class));
        $this->app->singleton('titan.workforce.escalation-deadlock-center', fn ($app) => $app->make(WorkforceEscalationDeadlockCenterService::class));
        $this->app->singleton('titan.workforce.maturity', fn ($app) => $app->make(WorkforceMaturityService::class));
        $this->app->singleton('titan.workforce.manager-continuity', fn ($app) => $app->make(ManagerContinuityService::class));
        $this->app->singleton('titan.workforce.manager-operations', fn ($app) => $app->make(ManagerOperationsService::class));
        $this->app->singleton('titan.workforce.councils', fn ($app) => $app->make(WorkforceCouncilService::class));
        $this->app->singleton('titan.workforce.disputes', fn ($app) => $app->make(WorkforceDisputeService::class));
        $this->app->singleton('titan.workforce.outcomes', fn ($app) => $app->make(WorkforceOutcomeFeedbackService::class));
        $this->app->singleton('titan.workforce.journey-spine', fn ($app) => $app->make(WorkforceJourneySpineService::class));
        $this->app->singleton('titan.workforce.outcome-health', fn ($app) => $app->make(WorkforceOutcomeHealthService::class));
        $this->app->singleton('titan.workforce.autonomy', fn ($app) => $app->make(WorkforceAutonomyService::class));
        $this->app->singleton('titan.workforce.pre-execution-governance', fn ($app) => $app->make(WorkforcePreExecutionGovernanceService::class));
        $this->app->singleton('titan.workforce.execution', fn ($app) => $app->make(WorkforceExecutionService::class));
        $this->app->singleton('titan.workforce.execution-recovery', fn ($app) => $app->make(WorkforceExecutionRecoveryService::class));
        $this->app->singleton('titan.workforce.execution-verification', fn ($app) => $app->make(WorkforcePostActionVerificationService::class));
        $this->app->singleton('titan.workforce.trust-health', fn ($app) => $app->make(WorkforceTrustHealthService::class));
        $this->app->singleton('titan.workforce.vertical-overlay', fn ($app) => $app->make(WorkforceVerticalOverlayService::class));
        $this->app->singleton('titan.workforce.control-room', fn ($app) => $app->make(WorkforceControlRoomService::class));
        $this->app->singleton('titan.workforce.performance', fn ($app) => $app->make(WorkforcePerformanceService::class));
        $this->app->singleton('titan.workforce.staffing-proposals', fn ($app) => $app->make(WorkforceStaffingProposalService::class));
        $this->app->singleton('titan.workforce.planning-intelligence', fn ($app) => $app->make(WorkforcePlanningIntelligenceService::class));
        $this->app->singleton('titan.workforce.authorization', fn ($app) => $app->make(TitanHostAuthorizationAdapter::class));
        $this->app->singleton('titan.workforce.permissions', fn () => WorkforcePermissions::all());
        $this->app->singleton('titan.workforce.intrinsic-divisions', fn () => new IntrinsicDivisionCatalog());
        $this->app->singleton('titan.workforce.intrinsic-roles', fn () => new IntrinsicRoleCatalog());
        $this->app->singleton('titan.workforce.intrinsic-responsibilities', fn () => new IntrinsicResponsibilityCatalog());
        $this->app->singleton('titan.workforce.relationship-definitions', fn () => IntrinsicRelationshipCatalog::blueprint());

        if (class_exists(\App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry::class)) {
            $sources = $this->app->make(\App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceRegistry::class);
            if (! $sources->has('titan-workforce')) {
                $sources->register($this->app->make(WorkforceConversationSourceAdapter::class));
            }
            $policies = $this->app->make(\App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourcePolicyRegistry::class);
            if (! $policies->has('titan-workforce')) {
                $policies->register('titan-workforce', $this->app->make(WorkforceSourcePolicy::class));
            }
        }

        // Host/extension-manager integration points. Payloads are intentionally tolerant, but
        // reconciliation identity is always exact extension key + role_id.
        Event::listen('titan.extension.activated', function ($event = null): void {
            app(WorkforceManifestLifecycleService::class)->onActivated($event);
            app(WorkforceCapabilityBindingRegistry::class)->invalidate();
        });
        Event::listen('titan.extension.upgraded', function ($event = null): void {
            app(WorkforceManifestLifecycleService::class)->onUpgraded($event);
            app(WorkforceCapabilityBindingRegistry::class)->invalidate();
        });
        Event::listen('titan.extension.disabled', function ($event = null): void {
            app(WorkforceManifestLifecycleService::class)->onDisabled($event);
            app(WorkforceCapabilityBindingRegistry::class)->invalidate();
        });
        Event::listen('titan.extension.uninstalled', function ($event = null): void {
            app(WorkforceManifestLifecycleService::class)->onUninstalled($event);
            app(WorkforceCapabilityBindingRegistry::class)->invalidate();
        });

        // Titan Signal may publish a canonical envelope on this event. Event-triggered responsibilities
        // create persistent governed tasks with signal-derived idempotency keys.
        Event::listen('titan.signal', function (array $envelope = []) {
            $eventType = (string) ($envelope['event_type'] ?? data_get($envelope, 'payload.event_type', ''));
            if ($eventType === AgentTriggerSignalIngressService::EVENT_TYPE) {
                app(AgentTriggerSignalIngressService::class)->receive($envelope);
            } elseif ($eventType !== '') {
                app(WorkforceSignalToWorkService::class)->receive($eventType, $envelope);
                app(WorkforceEventTriggerService::class)->handle($eventType, $envelope);
            }
            $payload = is_array($envelope['payload'] ?? null) ? $envelope['payload'] : [];
            $outcomeVerified = ($payload['outcome_verified'] ?? false) === true;
            if ($outcomeVerified && ! str_starts_with($eventType, 'workforce.')) {
                app(WorkforceOutcomeFeedbackService::class)->observeExternalVerifiedOutcome($envelope);
            }
        });
    }

    private function registerCommands(): void
    {
        if (! $this->app->runningInConsole()) { return; }
        $this->commands([DispatchDueWorkforceSchedulesCommand::class, RetryWorkforceSignalOutboxCommand::class, SyncWorkforceResponsibilitiesCommand::class, RunWorkforceProactiveManagementCommand::class, ReconcileWorkforceDefinitionsCommand::class, SyncWorkforceMenuCommand::class, RouteWorkforceNotificationsCommand::class, ValidateWorkforceAuthorityGraphCommand::class, ExpireOverdueProcessingStagesCommand::class]);
        $this->app->booted(function () {
            $schedule = $this->app->make(Schedule::class);
            $schedule->command('titan-workforce:dispatch-due')->everyMinute()->withoutOverlapping(5);
            $schedule->command('titan-workforce:proactive-management')->everyFiveMinutes()->withoutOverlapping(5);
            $schedule->command('titan-workforce:retry-signals')->everyFiveMinutes()->withoutOverlapping(5);
            $schedule->command('titan-workforce:sync-responsibilities')->hourlyAt(7)->withoutOverlapping(10);
            $schedule->command('titan-workforce:route-notifications')->everyFiveMinutes()->withoutOverlapping(5);
            $schedule->command('titan-workforce:expire-processing-stages')->everyFiveMinutes()->withoutOverlapping(5);
        });
    }

    private function registerRoutes(): void
    {
        Route::bind('division', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceDivision::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('teamScope', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceTeam::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('member', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceMember::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('task', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceTask::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('handoff', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceTaskHandoff::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('proposal', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceStaffingProposal::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });
        Route::bind('notification', function ($value) {
            if (! Auth::check()) { abort(404); }
            return WorkforceNotification::query()->forCompany(CompanyContext::id(Auth::user()))->findOrFail($value);
        });

        $this->app['router']->group(['middleware'=>['web','auth'], 'prefix'=>'dashboard/user/titan-workforce', 'as'=>'dashboard.user.titan-workforce.'], function (Router $router) {
            $read = 'titan.workforce.authorize:titan-workforce.read';
            $staffAdd = 'titan.workforce.authorize:titan-workforce.staff.add';
            $staffManage = 'titan.workforce.authorize:titan-workforce.staff.manage';
            $organisationManage = 'titan.workforce.authorize:titan-workforce.organisation.manage';
            $review = 'titan.workforce.authorize:titan-workforce.tasks.review';
            $reassign = 'titan.workforce.authorize:titan-workforce.tasks.reassign';
            $staffing = 'titan.workforce.authorize:titan-workforce.staffing.approve';
            $deadlock = 'titan.workforce.authorize:titan-workforce.deadlocks.resolve';
            $controlRoom = 'titan.workforce.authorize:titan-workforce.control-room';

            $router->get('', [WorkforceController::class,'index'])->middleware($read)->name('index');
            $router->get('team', [WorkforceController::class,'team'])->middleware($read)->name('team');
            $router->get('divisions/{division}', [WorkforceController::class,'divisionWorkspace'])->middleware($read)->name('divisions.show');
            $router->get('teams/{teamScope}', [WorkforceController::class,'teamWorkspace'])->middleware($read)->name('teams.show');
            $router->get('team/{member}', [WorkforceController::class,'member'])->middleware($read)->name('staff.show');
            $router->get('degradation/{member}', [WorkforceController::class,'safeDegradation'])->middleware($read)->name('staff.degradation');
            $router->get('attention', [WorkforceController::class,'attentionCenter'])->middleware($read)->name('attention');
            $router->get('decision-rights-center', [WorkforceController::class,'decisionRightsCenter'])->middleware($read)->name('decision-rights-center');
            $router->get('delegations', [WorkforceController::class,'delegationsCenter'])->middleware($read)->name('delegations');
            $router->get('escalations', [WorkforceController::class,'escalationDeadlockCenter'])->middleware($read)->name('escalations');
            $router->post('escalations/{task}/action', [WorkforceController::class,'resolveEscalationCenterAction'])->middleware($deadlock)->name('escalations.action');
            $router->get('governance-pipeline', [WorkforceController::class,'governancePipeline'])->middleware($read)->name('governance-pipeline');
            $router->get('execution-evidence', [WorkforceController::class,'executionEvidenceExplorer'])->middleware($read)->name('execution-evidence');
            $router->get('journey-timeline', [WorkforceController::class,'journeyTimeline'])->middleware($read)->name('journey-timeline');
            $router->get('outcome-intelligence', [WorkforceController::class,'outcomeIntelligence'])->middleware($read)->name('outcome-intelligence');
            $router->get('release-readiness', [WorkforceController::class,'workforceReleaseReadiness'])->middleware($read)->name('release-readiness');
            $router->get('audit-export', [WorkforceController::class,'workforceAuditExport'])->middleware($read)->name('audit-export');
            $router->get('audit-export/download', [WorkforceController::class,'downloadWorkforceAuditExport'])->middleware($read)->name('audit-export.download');
            $router->get('control-settings', [WorkforceController::class,'workforceControlSettings'])->middleware($read)->name('control-settings');
            $router->post('control-settings', [WorkforceController::class,'updateWorkforceControlSettings'])->middleware($organisationManage)->name('control-settings.update');
            $router->get('system-health', [WorkforceController::class,'workforceSystemHealth'])->middleware($read)->name('system-health');
            $router->get('setup', [WorkforceController::class,'workforceSetup'])->middleware($read)->name('setup');
            $router->post('setup', [WorkforceController::class,'applyWorkforceSetup'])->middleware($organisationManage)->name('setup.apply');
            $router->get('conversation', [WorkforceController::class,'workforceConversation'])->middleware($read)->name('conversation');
            $router->post('conversation', [WorkforceController::class,'submitWorkforceConversation'])->middleware($read)->name('conversation.submit');
            $router->get('contextual-chat/{type}/{id}', [WorkforceController::class,'contextualWorkforceConversation'])->middleware($read)->name('contextual-chat');
            $router->post('contextual-chat/{type}/{id}', [WorkforceController::class,'submitContextualWorkforceConversation'])->middleware($read)->name('contextual-chat.submit');
            $router->get('planning', [WorkforceController::class,'planningCenter'])->middleware($read)->name('planning');
            $router->get('councils', [WorkforceController::class,'councilsCenter'])->middleware($read)->name('councils');
            $router->get('councils/{council}', [WorkforceController::class,'councilShow'])->middleware($read)->name('councils.show');
            $router->post('councils/convene', [WorkforceController::class,'conveneCouncil'])->middleware($review)->name('councils.convene');
            $router->post('councils/{council}/decision', [WorkforceController::class,'updateCouncilDecision'])->middleware($review)->name('councils.decision');
            $router->get('notifications', [WorkforceController::class,'notificationsCenter'])->middleware($read)->name('notifications');
            $router->post('notifications/{notification}/acknowledge', [WorkforceController::class,'acknowledgeNotification'])->middleware($controlRoom)->name('notifications.acknowledge');
            $router->post('notifications/preferences', [WorkforceController::class,'updateNotificationPreferences'])->middleware($controlRoom)->name('notifications.preferences');
            $router->get('managers/{member}', [WorkforceController::class,'managerWorkspace'])->middleware($read)->name('managers.show');
            $router->get('staff/create', [WorkforceController::class,'create'])->middleware($staffAdd)->name('create');
            $router->post('staff', [WorkforceController::class,'store'])->middleware($staffAdd)->name('store');
            $router->post('staff/{member}/suspend', [WorkforceController::class,'suspendStaff'])->middleware($staffManage)->name('staff.suspend');
            $router->post('staff/{member}/resume', [WorkforceController::class,'resumeStaff'])->middleware($staffManage)->name('staff.resume');
            $router->post('staff/{member}/retire', [WorkforceController::class,'retireStaff'])->middleware($staffManage)->name('staff.retire');
            $router->post('staff/{member}/manager', [WorkforceController::class,'setStaffManager'])->middleware($organisationManage)->name('staff.manager');
            $router->post('staff/{member}/deputy', [WorkforceController::class,'appointDeputy'])->middleware($organisationManage)->name('staff.deputy');
            $router->get('responsibilities', [WorkforceController::class,'responsibilitiesCenter'])->middleware($read)->name('responsibilities');
            $router->get('capability-health', [WorkforceController::class,'capabilityHealth'])->middleware($read)->name('capability-health');
            $router->get('proactive-operations', [WorkforceController::class,'proactiveOperations'])->middleware($read)->name('proactive-operations');
            $router->post('responsibilities/{responsibilityId}', [WorkforceController::class,'updateResponsibility'])->middleware($organisationManage)->name('responsibilities.update');
            $router->get('tasks', [WorkforceController::class,'tasks'])->middleware($read)->name('tasks');
            $router->get('tasks/{task}', [WorkforceController::class,'task'])->middleware($read)->name('tasks.show');
            $router->get('tasks/{task}/graph', [WorkforceController::class,'taskGraph'])->middleware($read)->name('tasks.graph');
            $router->get('calendar', [WorkforceController::class,'calendar'])->middleware($read)->name('calendar');
            $router->get('analytics', [WorkforceController::class,'analytics'])->middleware($read)->name('analytics');
            $router->get('control-room', [WorkforceController::class,'controlRoom'])->middleware($controlRoom)->name('control-room');
            $router->get('chain-command-center', [WorkforceController::class,'chainCommandCenter'])->middleware($controlRoom)->name('chain-command-center');
            $router->get('api/chain-command-center', [WorkforceController::class,'apiChainCommandCenter'])->middleware($controlRoom)->name('api.chain-command-center');
            $router->get('api/chain-command-center/{chainUuid}', [WorkforceController::class,'apiChainCommandCenterShow'])->middleware($controlRoom)->name('api.chain-command-center.show');
            $router->post('chain-learning/{recommendationUuid}/approve', [WorkforceController::class,'approveChainLearningRecommendation'])->middleware($organisationManage)->name('chain-learning.approve');
            $router->post('chain-learning/{recommendationUuid}/reject', [WorkforceController::class,'rejectChainLearningRecommendation'])->middleware($organisationManage)->name('chain-learning.reject');
            $router->get('chain-policy', [WorkforceController::class,'chainPolicy'])->middleware($controlRoom)->name('chain-policy');
            $router->post('chain-policy', [WorkforceController::class,'updateChainPolicy'])->middleware($organisationManage)->name('chain-policy.update');
            $router->post('chain-command-center/{chainUuid}/override', [WorkforceController::class,'createChainAdminOverride'])->middleware($organisationManage)->name('chain.override');
            $router->post('chain-command-center/override/{overrideUuid}/release', [WorkforceController::class,'releaseChainAdminOverride'])->middleware($organisationManage)->name('chain.override.release');
            $router->post('staffing/refresh', [WorkforceController::class,'refreshStaffingRecommendations'])->middleware($staffing)->name('staffing.refresh');
            $router->post('staffing/{proposal}/approve', [WorkforceController::class,'approveStaffingProposal'])->middleware($staffing)->name('staffing.approve');
            $router->post('staffing/{proposal}/reject', [WorkforceController::class,'rejectStaffingProposal'])->middleware($staffing)->name('staffing.reject');
            $router->get('api/tasks', [WorkforceController::class,'apiTasks'])->middleware($read)->name('api.tasks');
            $router->get('api/roles', [WorkforceController::class,'apiRoles'])->middleware($read)->name('api.roles');
            $router->get('api/manifest-health', [WorkforceController::class,'apiManifestHealth'])->middleware($read)->name('api.manifest-health');
            $router->get('api/workforce-plan', [WorkforceController::class,'apiWorkforcePlan'])->middleware($read)->name('api.workforce-plan');
            $router->get('api/manager-queue', [WorkforceController::class,'apiManagerQueue'])->middleware($read)->name('api.manager-queue');
            $router->get('api/organisation-graph', [WorkforceController::class,'apiOrganisationGraph'])->middleware($read)->name('api.organisation-graph');
            $router->get('api/decision-rights', [WorkforceController::class,'apiDecisionRights'])->middleware($read)->name('api.decision-rights');
            $router->get('api/chain-integrity', [WorkforceController::class,'apiChainIntegrity'])->middleware($read)->name('api.chain-integrity');
            $router->get('api/proactive-responsibilities', [WorkforceController::class,'apiProactiveResponsibilities'])->middleware($read)->name('api.proactive-responsibilities');
            $router->get('api/queue-health', [WorkforceController::class,'apiQueueHealth'])->middleware($read)->name('api.queue-health');
            $router->get('api/proactive-runtime', [WorkforceController::class,'apiProactiveRuntime'])->middleware($read)->name('api.proactive-runtime');
            $router->get('api/trust-health', [WorkforceController::class,'apiTrustHealth'])->middleware($read)->name('api.trust-health');
            $router->get('api/journey/{task}', [WorkforceController::class,'apiJourney'])->middleware($read)->name('api.journey');
            $router->get('api/outcome-health', [WorkforceController::class,'apiOutcomeHealth'])->middleware($read)->name('api.outcome-health');
            $router->get('api/control-room', [WorkforceController::class,'apiControlRoom'])->middleware($controlRoom)->name('api.control-room');
            $router->get('api/vertical-overlay', [WorkforceController::class,'apiVerticalOverlay'])->middleware($read)->name('api.vertical-overlay');
            $router->post('api/councils/convene', [WorkforceController::class,'apiConveneCouncil'])->middleware($review)->name('api.councils.convene');
            $router->post('api/disputes', [WorkforceController::class,'apiRaiseDispute'])->middleware($review)->name('api.disputes');
            $router->post('tasks/{task}/submit', [WorkforceController::class,'submitTask'])->middleware($review)->name('tasks.submit');
            $router->post('tasks/{task}/decompose', [WorkforceController::class,'decomposeTask'])->middleware($review)->name('tasks.decompose');
            $router->post('tasks/{task}/reassign', [WorkforceController::class,'reassignTask'])->middleware($reassign)->name('tasks.reassign');
            $router->post('tasks/{task}/review', [WorkforceController::class,'reviewTask'])->middleware($review)->name('tasks.review');
            $router->post('tasks/{task}/escalate', [WorkforceController::class,'escalateTask'])->middleware($review)->name('tasks.escalate');
            $router->post('tasks/{task}/handoff', [WorkforceController::class,'handoffTask'])->middleware($review)->name('tasks.handoff');
            $router->post('tasks/{task}/delegate-action', [WorkforceController::class,'delegateAction'])->middleware($review)->name('tasks.delegate-action');
            $router->post('handoffs/{handoff}/review', [WorkforceController::class,'receiverReview'])->middleware($review)->name('handoffs.review');
            $router->post('tasks/{task}/deadlock', [WorkforceController::class,'resolveDeadlock'])->middleware($deadlock)->name('tasks.deadlock');
        });
    }

    public static function uninstall(): void {}
    public function registerKey(): string { return 'titan-ai-workforce'; }
}
