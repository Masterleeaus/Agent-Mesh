<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;

final class QueuePriorityService
{
    private const RISK = ['MINIMAL' => 0, 'LOW' => 8, 'MEDIUM' => 18, 'HIGH' => 30, 'EXTREME' => 45];

    public function score(WorkforceTask $task): int
    {
        $score = max(0, min(100, (int) $task->priority));
        $score += self::RISK[strtoupper((string) $task->risk_level)] ?? 8;
        if ($task->deadline_at) {
            $minutes = now()->diffInMinutes($task->deadline_at, false);
            $score += $minutes <= 0 ? 40 : ($minutes <= 60 ? 30 : ($minutes <= 240 ? 20 : ($minutes <= 1440 ? 10 : 0)));
        }
        $ageHours = max(0, $task->created_at?->diffInHours(now()) ?? 0);
        $score += min(20, intdiv($ageHours, 6)); // starvation protection
        $meta = $task->metadata ?? [];
        $score += min(20, (int) ($meta['customer_impact'] ?? 0));
        $score += min(20, (int) ($meta['financial_impact'] ?? 0));
        $score += min(30, (int) ($meta['dependency_blocking'] ?? 0));
        $score += min(30, (int) ($meta['escalation_severity'] ?? 0));
        return $score;
    }
}
