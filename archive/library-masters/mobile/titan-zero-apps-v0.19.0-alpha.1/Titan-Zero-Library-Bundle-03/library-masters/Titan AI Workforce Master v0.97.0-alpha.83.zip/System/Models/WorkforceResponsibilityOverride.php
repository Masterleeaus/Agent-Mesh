<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceResponsibilityOverride extends Model
{
    protected $table = 'ext_titan_ai_workforce_responsibility_overrides';
    protected $guarded = [];
    protected $casts = [
        'is_enabled' => 'boolean',
        'schedule' => 'array',
        'trigger_conditions' => 'array',
        'metadata' => 'array',
    ];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
