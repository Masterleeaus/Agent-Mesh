<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceProactiveIdentity;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

final class ProactiveWorkforceService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly ProactiveResponsibilityService $responsibilities,
        private readonly WorkforceManifestRegistry $manifests,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
    ) {}

    public function dispatchDue(int $limit = 100): int
    {
        $created = 0;
        $due = WorkforceSchedule::query()
            ->where('is_active', true)
            ->where('trigger_type', 'schedule')
            ->whereNotNull('next_run_at')
            ->where('next_run_at', '<=', now())
            ->orderBy('next_run_at')->orderBy('id')
            ->limit($limit)
            ->get(['id','company_id']);

        foreach ($due as $candidate) {
            CompanyContext::runWith((int) $candidate->company_id, function () use ($candidate, &$created): void {
                DB::transaction(function () use ($candidate, &$created): void {
                    /** @var WorkforceSchedule|null $schedule */
                    $schedule = WorkforceSchedule::query()->forCompany((int) $candidate->company_id)
                        ->whereKey($candidate->id)->lockForUpdate()->first();
                    if (! $schedule || ! $schedule->is_active || $schedule->trigger_type !== 'schedule'
                        || ! $schedule->next_run_at || $schedule->next_run_at->isFuture()) return;

                    $member = WorkforceMember::query()->forCompany((int) $schedule->company_id)
                        ->where('is_active', true)->find($schedule->member_id);
                    $routine = $this->dispatchableRoutine($schedule, $member);
                    if (! $member || ! $routine) {
                        $this->recordRun($schedule, 'blocked');
                        $this->disableSchedule($schedule, 'source_definition_or_routine_unavailable');
                        return;
                    }

                    $capabilityState = (string) ($this->capabilityAvailability->forMember($member)['state'] ?? 'unavailable');
                    if ($capabilityState === 'degraded') $this->recordRun($schedule, 'degraded');
                    elseif ($capabilityState !== 'available') $this->recordRun($schedule, 'blocked');

                    $runAt = $schedule->next_run_at->copy();
                    $idempotencyKey = WorkforceProactiveIdentity::scheduleIdempotencyKey(
                        (int) $schedule->company_id,
                        (int) $member->id,
                        (string) $schedule->owner_extension,
                        (string) $schedule->role_definition_id,
                        (string) $schedule->routine_id,
                        (string) $schedule->routine_fingerprint,
                        $runAt,
                    );
                    $template = is_array($schedule->task_template) ? $schedule->task_template : [];
                    $templateMetadata = is_array($template['metadata'] ?? null) ? $template['metadata'] : [];
                    $task = $this->tasks->create((int) $schedule->company_id, array_merge($template, [
                        'title' => $template['title'] ?? $schedule->name,
                        'assignee_member_id' => $member->id,
                        'manager_member_id' => $member->manager_id,
                        'division_id' => $member->division_id,
                        'team_id' => $member->team_id,
                        'origin_type' => 'workforce_schedule',
                        'origin_id' => (string) $schedule->owner_extension . ':' . (string) $schedule->routine_id,
                        'idempotency_key' => $idempotencyKey,
                        'scheduled_at' => $runAt,
                        'metadata' => array_merge($templateMetadata, [
                            'proactive' => true,
                            'creates' => 'workforce_task',
                            'business_mutation' => false,
                            'owner_extension' => (string) $schedule->owner_extension,
                            'owner_extension_version' => (string) $schedule->owner_extension_version,
                            'role_definition_id' => (string) $schedule->role_definition_id,
                            'routine_id' => (string) $schedule->routine_id,
                            'routine_fingerprint' => (string) $schedule->routine_fingerprint,
                            'occurrence_at' => $runAt->toIso8601String(),
                        ]),
                    ]), $member);

                    if ($task->wasRecentlyCreated) {
                        $this->recordRun($schedule, 'generated');
                        ProcessWorkforceTaskJob::dispatch((int) $schedule->company_id, (int) $task->id);
                        $created++;
                    } else {
                        $this->recordRun($schedule, 'skipped');
                    }

                    $schedule->forceFill([
                        'last_run_at' => $runAt,
                        'next_run_at' => $this->nextRun($schedule),
                    ])->save();
                });
            });
        }
        return $created;
    }

    private function dispatchableRoutine(WorkforceSchedule $schedule, ?WorkforceMember $member): ?array
    {
        if (! $member) return null;
        $owner = trim((string) $schedule->owner_extension);
        $roleId = trim((string) $schedule->role_definition_id);
        $routineId = trim((string) $schedule->routine_id);
        $fingerprint = trim((string) $schedule->routine_fingerprint);
        if ($owner === '' || $roleId === '' || $routineId === '' || $fingerprint === '') return null;
        if ((string) $member->role_owner_extension !== $owner || (string) $member->role_definition_id !== $roleId) return null;
        if (! $this->manifests->findOwnedRole($owner, $roleId)) return null;

        foreach ($this->manifests->explicitRoutinesForOwnedRole($owner, $roleId) as $routine) {
            if ((string) ($routine['routine_id'] ?? '') !== $routineId) continue;
            if ((string) ($routine['routine_fingerprint'] ?? '') !== $fingerprint) return null;
            if (($routine['trigger_type'] ?? null) !== 'schedule') return null;
            if (($routine['creates'] ?? null) !== 'workforce_task' || ($routine['business_mutation'] ?? false) !== false) return null;
            return $routine;
        }
        return null;
    }

    private function recordRun(WorkforceSchedule $schedule, string $status): void
    {
        $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
        $telemetry = is_array($metadata['run_telemetry'] ?? null) ? $metadata['run_telemetry'] : [];
        foreach (['generated','skipped','degraded','blocked'] as $key) $telemetry[$key] = (int) ($telemetry[$key] ?? 0);
        if (array_key_exists($status, $telemetry)) $telemetry[$status]++;
        $telemetry['last_status'] = $status;
        $telemetry['last_run_at'] = now()->toIso8601String();
        $metadata['run_telemetry'] = $telemetry;
        $schedule->forceFill(['metadata' => $metadata])->save();
    }

    private function disableSchedule(WorkforceSchedule $schedule, string $reason): void
    {
        $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
        $metadata['disabled_reason'] = $reason;
        $metadata['disabled_at'] = now()->toIso8601String();
        $schedule->forceFill(['is_active' => false, 'metadata' => $metadata])->save();
    }

    private function nextRun(WorkforceSchedule $schedule): Carbon
    {
        $base = ($schedule->next_run_at ?: now())->copy()->addSecond();
        $timezone = (string) data_get($schedule->metadata ?? [], 'timezone', config('app.timezone', 'UTC'));
        return $this->responsibilities->nextOccurrence($schedule->schedule ?? [], $base, $timezone);
    }
}
