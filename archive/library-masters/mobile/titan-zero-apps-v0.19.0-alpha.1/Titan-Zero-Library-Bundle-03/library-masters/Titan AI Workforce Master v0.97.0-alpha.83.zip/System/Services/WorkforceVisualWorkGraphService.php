<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceJourneyRecord;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskDependency;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;
use InvalidArgumentException;

/**
 * Read-only visual projection of governed Workforce state.
 * Graph membership, provider state, history, evidence or execution records never grant authority.
 */
final class WorkforceVisualWorkGraphService
{
    private const REVIEW_STATUSES = ['UNDER_REVIEW','APPROVED','REJECTED','REVISION_REQUIRED','RECEIVER_REVIEW','ACCEPTED'];
    private const DECISION_STAGES = ['decision','risk','assurance','governance','autonomy','deliberate','model_council','approval'];

    public function graph(int $companyId, WorkforceTask $focus): array
    {
        if ((int) $focus->company_id !== $companyId) {
            throw new InvalidArgumentException('Task is outside the active company boundary.');
        }

        $tasks = $this->connectedTasks($companyId, $focus);
        $taskIds = $tasks->pluck('id')->map(fn ($id) => (int) $id)->all();

        $history = WorkforceTaskHistory::query()->whereIn('task_id', $taskIds)->orderBy('created_at')->get();
        $handoffs = WorkforceTaskHandoff::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->orderBy('created_at')->get();
        $attempts = WorkforceExecutionAttempt::query()->where('company_id', $companyId)->whereIn('task_id', $taskIds)->orderBy('created_at')->get();
        $evidence = WorkforceEvidence::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->orderBy('observed_at')->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->orderBy('observed_at')->get();
        $journey = WorkforceJourneyRecord::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->orderBy('observed_at')->get();
        $dependencies = WorkforceTaskDependency::query()->forCompany($companyId)
            ->whereIn('task_id', $taskIds)->whereIn('depends_on_task_id', $taskIds)->get();

        $nodes = collect();
        $edges = collect();

        foreach ($tasks as $task) {
            $id = 'task:'.$task->id;
            $nodes->push($this->node($id, 'task', $task->title, $task->status?->value ?? (string) $task->status, [
                'task_id' => $task->id,
                'task_uuid' => $task->task_uuid,
                'owner' => $task->assignee?->name,
                'manager' => $task->manager?->name,
                'team' => $task->team?->name,
                'division' => $task->division?->name,
                'occurred_at' => optional($task->created_at)->toIso8601String(),
                'focus' => (int) $task->id === (int) $focus->id,
            ]));
            if ($task->parent_task_id && in_array((int) $task->parent_task_id, $taskIds, true)) {
                $edges->push($this->edge('task:'.$task->parent_task_id, $id, 'child task'));
            }
        }

        foreach ($dependencies as $dependency) {
            $edges->push($this->edge('task:'.$dependency->depends_on_task_id, 'task:'.$dependency->task_id, $dependency->blocking ? 'blocking dependency' : 'dependency'));
        }

        foreach ($history as $row) {
            $event = strtolower((string) ($row->event ?? ''));
            $toStatus = strtoupper((string) ($row->to_status ?? ''));
            $isReview = str_contains($event, 'review') || in_array($toStatus, self::REVIEW_STATUSES, true);
            $isDecision = ! $isReview && ($this->containsDecisionWord($event) || $this->containsDecisionWord(strtolower((string) ($row->from_status ?? ''))));
            if (! $isReview && ! $isDecision) { continue; }
            $type = $isReview ? 'review' : 'decision';
            $id = $type.':history:'.$row->id;
            $title = $isReview ? 'Review · '.($row->event ?: $toStatus ?: 'review') : 'Decision · '.($row->event ?: $toStatus ?: 'decision');
            $nodes->push($this->node($id, $type, $title, $toStatus ?: null, [
                'task_id' => $row->task_id,
                'occurred_at' => optional($row->created_at)->toIso8601String(),
                'summary' => data_get($row->context ?? [], 'summary') ?? data_get($row->context ?? [], 'reason'),
            ]));
            $edges->push($this->edge('task:'.$row->task_id, $id, $type));
        }

        foreach ($journey as $record) {
            $stage = strtolower((string) ($record->stage ?? $record->event_type ?? data_get($record->summary ?? [], 'stage', '')));
            if (! $this->containsDecisionWord($stage) && empty($record->decision_refs)) { continue; }
            $id = 'decision:journey:'.$record->id;
            $nodes->push($this->node($id, 'decision', 'Decision · '.($stage ?: 'governed decision'), null, [
                'task_id' => $record->task_id,
                'occurred_at' => optional($record->observed_at)->toIso8601String(),
                'summary' => data_get($record->summary ?? [], 'summary') ?? data_get($record->summary ?? [], 'message'),
            ]));
            $edges->push($this->edge('task:'.$record->task_id, $id, 'decision'));
        }

        foreach ($handoffs as $handoff) {
            $id = 'handoff:'.$handoff->id;
            $nodes->push($this->node($id, 'handoff', 'Handoff', $handoff->status?->value ?? (string) $handoff->status, [
                'task_id' => $handoff->task_id,
                'origin_manager_id' => $handoff->origin_manager_id,
                'receiving_manager_id' => $handoff->receiving_manager_id,
                'occurred_at' => optional($handoff->created_at)->toIso8601String(),
                'packet_sha256' => $handoff->packet_sha256,
            ]));
            $edges->push($this->edge('task:'.$handoff->task_id, $id, 'handoff'));
            $receiverTaskId = (int) (data_get($handoff->metadata ?? [], 'receiving_task_id') ?? data_get($handoff->packet ?? [], 'receiving_task_id') ?? 0);
            if ($receiverTaskId && in_array($receiverTaskId, $taskIds, true)) {
                $edges->push($this->edge($id, 'task:'.$receiverTaskId, 'accepted by'));
            }
        }

        foreach ($attempts as $attempt) {
            $id = 'execution:'.$attempt->id;
            $status = (string) ($attempt->status ?? ($attempt->verified_at ? 'VERIFIED' : ($attempt->dispatched_at ? 'DISPATCHED' : 'PENDING')));
            $nodes->push($this->node($id, 'execution', 'Execution attempt', $status, [
                'task_id' => $attempt->task_id,
                'occurred_at' => optional($attempt->dispatched_at ?? $attempt->created_at)->toIso8601String(),
                'receipt_ref' => $attempt->receipt_ref,
                'verified_at' => optional($attempt->verified_at)->toIso8601String(),
            ]));
            $edges->push($this->edge('task:'.$attempt->task_id, $id, 'execute'));
        }

        foreach ($evidence as $item) {
            $id = 'evidence:'.$item->id;
            $nodes->push($this->node($id, 'evidence', (string) ($item->label ?? $item->type ?? 'Evidence'), null, [
                'task_id' => $item->task_id,
                'occurred_at' => optional($item->observed_at ?? $item->created_at)->toIso8601String(),
                'source' => $item->source ?? data_get($item->payload ?? [], 'source'),
            ]));
            $edges->push($this->edge('task:'.$item->task_id, $id, 'evidence'));
        }

        foreach ($outcomes as $outcome) {
            $id = 'outcome:'.$outcome->id;
            $nodes->push($this->node($id, 'outcome', (string) (data_get($outcome->summary ?? [], 'title') ?? data_get($outcome->summary ?? [], 'summary') ?? 'Outcome recorded'), $outcome->verified_at ? 'VERIFIED' : 'OBSERVED', [
                'task_id' => $outcome->task_id,
                'success' => $outcome->success,
                'occurred_at' => optional($outcome->observed_at ?? $outcome->created_at)->toIso8601String(),
                'verified_at' => optional($outcome->verified_at)->toIso8601String(),
            ]));
            $edges->push($this->edge('task:'.$outcome->task_id, $id, 'outcome'));
        }

        $nodes = $nodes->unique('id')->values();
        $edges = $edges->filter(fn (array $edge) => $nodes->contains('id', $edge['from']) && $nodes->contains('id', $edge['to']))->unique(fn (array $edge) => $edge['from'].'|'.$edge['to'].'|'.$edge['label'])->values();

        return [
            'company_id' => $companyId,
            'focus_task' => $focus,
            'nodes' => $nodes,
            'edges' => $edges,
            'counts' => $nodes->groupBy('type')->map->count()->all(),
            'node_types' => ['task','decision','review','handoff','execution','evidence','outcome'],
            'authority_inherited' => false,
        ];
    }

    private function connectedTasks(int $companyId, WorkforceTask $focus): Collection
    {
        $ids = collect([(int) $focus->id]);
        $cursor = $focus;
        for ($guard = 0; $guard < 20 && $cursor->parent_task_id; $guard++) {
            $parent = WorkforceTask::query()->forCompany($companyId)->find((int) $cursor->parent_task_id);
            if (! $parent || $ids->contains((int) $parent->id)) { break; }
            $ids->push((int) $parent->id);
            $cursor = $parent;
        }

        for ($pass = 0; $pass < 8; $pass++) {
            $before = $ids->count();
            $children = WorkforceTask::query()->forCompany($companyId)->whereIn('parent_task_id', $ids->all())->pluck('id');
            $dependencies = WorkforceTaskDependency::query()->forCompany($companyId)
                ->where(function ($query) use ($ids) {
                    $query->whereIn('task_id', $ids->all())->orWhereIn('depends_on_task_id', $ids->all());
                })->get(['task_id','depends_on_task_id']);
            $ids = $ids->merge($children)
                ->merge($dependencies->pluck('task_id'))
                ->merge($dependencies->pluck('depends_on_task_id'))
                ->map(fn ($id) => (int) $id)->filter()->unique()->values();
            if ($ids->count() === $before || $ids->count() >= 120) { break; }
        }

        return WorkforceTask::query()->forCompany($companyId)
            ->whereIn('id', $ids->take(120)->all())
            ->with(['assignee','manager','division','team','parent'])
            ->orderBy('created_at')->get();
    }

    private function containsDecisionWord(string $value): bool
    {
        foreach (self::DECISION_STAGES as $needle) {
            if (str_contains($value, $needle)) { return true; }
        }
        return false;
    }

    private function node(string $id, string $type, string $title, ?string $status, array $meta): array
    {
        return ['id' => $id, 'type' => $type, 'title' => $title, 'status' => $status, 'meta' => $meta];
    }

    private function edge(string $from, string $to, string $label): array
    {
        return ['from' => $from, 'to' => $to, 'label' => $label];
    }
}
