<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class WorkforcePermissions
{
    public const READ = 'titan-workforce.read';
    public const STAFF_ADD = 'titan-workforce.staff.add';
    public const STAFF_MANAGE = 'titan-workforce.staff.manage';
    public const ORGANISATION_MANAGE = 'titan-workforce.organisation.manage';
    public const TASKS_REVIEW = 'titan-workforce.tasks.review';
    public const TASKS_REASSIGN = 'titan-workforce.tasks.reassign';
    public const STAFFING_APPROVE = 'titan-workforce.staffing.approve';
    public const DEADLOCKS_RESOLVE = 'titan-workforce.deadlocks.resolve';
    public const CONTROL_ROOM = 'titan-workforce.control-room';

    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::READ,
            self::STAFF_ADD,
            self::STAFF_MANAGE,
            self::ORGANISATION_MANAGE,
            self::TASKS_REVIEW,
            self::TASKS_REASSIGN,
            self::STAFFING_APPROVE,
            self::DEADLOCKS_RESOLVE,
            self::CONTROL_ROOM,
        ];
    }

    /**
     * Bounded MagicAI Admin fallback. This is intentionally extension-local rather than a
     * platform-wide Admin bypass; explicit can/checkPermission/hasPermissionTo wins first.
     *
     * @return list<string>
     */
    public static function delegatedAdminPermissions(): array
    {
        return self::all();
    }
}
