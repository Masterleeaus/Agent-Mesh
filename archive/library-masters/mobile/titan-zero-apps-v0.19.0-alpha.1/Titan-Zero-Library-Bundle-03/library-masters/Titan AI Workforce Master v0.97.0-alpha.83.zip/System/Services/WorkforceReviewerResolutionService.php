<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceDecisionStageRole;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMemberRating;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerResolution;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceBusinessRoleModel;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use Illuminate\Support\Collection;
use RuntimeException;

final class WorkforceReviewerResolutionService
{
    public function __construct(
        private readonly WorkforceReviewerIndependenceService $independence,
        private readonly WorkforceCapabilityAvailabilityService $capabilities,
        private readonly WorkforceBusinessRoleModel $roles,
        private readonly WorkforceAdaptiveChainIntelligenceService $adaptive,
    ) {}

    public function resolve(WorkforceDecisionChain $chain, int $stage, array $requirements = []): WorkforceMember
    {
        if ($stage < 1 || $stage > 3) throw new RuntimeException('REVIEWER_RESOLUTION_UNKNOWN_STAGE');

        $requirements=array_merge($this->adaptive->reviewerRequirements($chain,$stage),$requirements);
        $requiredDomain=$this->requiredDomain($chain,$stage,$requirements);
        $requiredCapability=$this->nullable($requirements['capability'] ?? $chain->task?->capability ?? null);
        $requiredResponsibility=$this->nullable($requirements['responsibility_id'] ?? null);
        $roleDefinitionId=$this->nullable($requirements['role_definition_id'] ?? null);
        $stageRole=match($stage) {
            1 => WorkforceDecisionStageRole::OriginReviewer,
            2 => WorkforceDecisionStageRole::DomainProcessor,
            3 => WorkforceDecisionStageRole::ReceivingChecker,
        };

        $rows=[];
        $candidates=WorkforceMember::query()
            ->forCompany((int)$chain->company_id)
            ->where('is_active',true)
            ->whereNotIn('status',[
                WorkforceMemberStatus::Offline->value,
                WorkforceMemberStatus::Suspended->value,
            ])->get();

        foreach($candidates as $candidate) {
            $reject=[];
            if ((bool)data_get($candidate->metadata ?? [],'internal',false)) $reject[]='INTERNAL_SYSTEM_MEMBER';
            if ($roleDefinitionId && (string)$candidate->role_definition_id !== $roleDefinitionId) $reject[]='ROLE_DEFINITION_MISMATCH';
            if (! $this->domainFits($candidate,$requiredDomain,$stage,$chain)) $reject[]='DOMAIN_MISMATCH';
            if ($requiredCapability && ! $this->capabilities->isCapabilityAvailable($candidate,$requiredCapability)) $reject[]='CAPABILITY_UNAVAILABLE';
            if ($requiredResponsibility && ! $this->responsibilityFits($candidate,$requiredResponsibility)) $reject[]='RESPONSIBILITY_MISMATCH';
            if (! $this->riskFits($candidate,(string)$chain->risk_class)) $reject[]='RISK_CEILING_EXCEEDED';
            if (! $this->hasCapacity($candidate)) $reject[]='WORKLOAD_CAPACITY_EXCEEDED';

            $avoidSignature=(array)($requirements['avoid_reviewer_signature'] ?? []);
            foreach($avoidSignature as $sigRow){
                if(is_array($sigRow) && (int)($sigRow['stage'] ?? 0)===$stage
                    && (int)($sigRow['member_id'] ?? 0)===(int)$candidate->getKey()){
                    $reject[]='APPROVED_LEARNING_AVOIDS_REVIEWER_COMBINATION';
                }
            }

            $qualityFloor=max(0,min(100,(int)($requirements['minimum_decision_quality'] ?? 0)));
            if($qualityFloor>0){
                $rating=WorkforceMemberRating::query()->forCompany((int)$chain->company_id)
                    ->where('member_id',$candidate->getKey())->first();
                $quality=(float)data_get($rating?->dimensions ?? [],'reviewer.decision_quality',$rating?->score ?? 50);
                if($quality<$qualityFloor) $reject[]='ADAPTIVE_REVIEWER_QUALITY_FLOOR_NOT_MET';
            }

            $independence=null;
            if ($reject===[]) {
                try {
                    $independence=$this->independence->assess($chain,$stage,$candidate);
                    if (!($independence['eligible'] ?? false)) {
                        foreach((array)($independence['conflicts'] ?? []) as $conflict) $reject[]='INDEPENDENCE:'.$conflict;
                    }
                } catch (\Throwable $e) {
                    $reject[]='INDEPENDENCE_ASSESSMENT_FAILED:'.$e->getMessage();
                }
            }

            $score=$reject===[] ? $this->score($candidate,$chain,$stage,$requiredDomain,$requiredCapability,$requiredResponsibility) : null;
            $rows[]=[
                'member'=>$candidate,
                'eligible'=>$reject===[],
                'score'=>$score,
                'rejections'=>$reject,
                'independence'=>$independence,
            ];
        }

        $eligible=collect($rows)->where('eligible',true)->sortByDesc('score')->values();
        $winner=$eligible->first();

        if (!$winner) {
            WorkforceReviewerResolution::query()->updateOrCreate(
                ['company_id'=>(int)$chain->company_id,'processing_id'=>$chain->processing_id,'stage'=>$stage],
                [
                    'decision_chain_id'=>$chain->getKey(),'stage_role'=>$stageRole->value,
                    'required_domain'=>$requiredDomain,'required_capability'=>$requiredCapability,
                    'required_responsibility'=>$requiredResponsibility,'status'=>'UNRESOLVED',
                    'candidate_evidence'=>$this->candidateEvidence($rows),
                    'rejection_reasons'=>$this->aggregateRejections($rows),'resolved_at'=>now(),
                ]
            );
            throw new RuntimeException('NO_ELIGIBLE_INDEPENDENT_REVIEWER');
        }

        /** @var WorkforceMember $member */
        $member=$winner['member'];
        $breakdown=$this->scoreBreakdown($member,$chain,$stage,$requiredDomain,$requiredCapability,$requiredResponsibility);

        WorkforceReviewerResolution::query()->updateOrCreate(
            ['company_id'=>(int)$chain->company_id,'processing_id'=>$chain->processing_id,'stage'=>$stage],
            [
                'decision_chain_id'=>$chain->getKey(),'stage_role'=>$stageRole->value,
                'selected_member_id'=>$member->getKey(),
                'selected_role_definition_id'=>$member->role_definition_id,
                'required_domain'=>$requiredDomain,'required_capability'=>$requiredCapability,
                'required_responsibility'=>$requiredResponsibility,
                'selection_score'=>$winner['score'],'score_breakdown'=>$breakdown,
                'candidate_evidence'=>$this->candidateEvidence($rows),
                'rejection_reasons'=>[],'status'=>'RESOLVED','resolved_at'=>now(),
            ]
        );

        return $member;
    }

    /** @return array<int,array<string,mixed>> */
    private function candidateEvidence(array $rows): array
    {
        return array_map(static fn(array $row): array => [
            'member_id'=>$row['member']->getKey(),
            'role_definition_id'=>$row['member']->role_definition_id,
            'division_id'=>$row['member']->division_id,
            'eligible'=>$row['eligible'],
            'score'=>$row['score'],
            'rejections'=>$row['rejections'],
            'independence'=>$row['independence'],
        ],$rows);
    }

    /** @return string[] */
    private function aggregateRejections(array $rows): array
    {
        $all=[];
        foreach($rows as $row) foreach($row['rejections'] as $reason) $all[]=$reason;
        return array_values(array_unique($all));
    }

    private function score(
        WorkforceMember $member,
        WorkforceDecisionChain $chain,
        int $stage,
        ?string $domain,
        ?string $capability,
        ?string $responsibility
    ): float {
        return array_sum($this->scoreBreakdown($member,$chain,$stage,$domain,$capability,$responsibility));
    }

    /** @return array<string,float> */
    private function scoreBreakdown(
        WorkforceMember $member,
        WorkforceDecisionChain $chain,
        int $stage,
        ?string $domain,
        ?string $capability,
        ?string $responsibility
    ): array {
        $rating=WorkforceMemberRating::query()->forCompany((int)$chain->company_id)->where('member_id',$member->getKey())->first();
        $ratingScore=(float)($rating?->score ?? 50.0);
        $reviewerQuality=(float)data_get($rating?->dimensions ?? [],'reviewer.decision_quality',$ratingScore);
        $reviewerRisk=(float)data_get($rating?->dimensions ?? [],'reviewer.risk_detection',$ratingScore);
        $load=$this->loadRatio($member);
        $skills=array_map('strtolower',array_values(array_map('strval',(array)($member->skills ?? []))));
        $capabilities=array_map('strtolower',array_values(array_map('strval',(array)($member->capabilities ?? []))));

        $roleFit=0.0;
        $role=$member->role_definition_id ? $this->roles->role((string)$member->role_definition_id) : null;
        if ($role) {
            if ($responsibility && in_array($responsibility,(array)($role['responsibility_ids'] ?? []),true)) $roleFit+=18.0;
            if ($stage===2 && in_array((string)($role['role_level'] ?? ''),['manager','specialist','coordinator'],true)) $roleFit+=7.0;
            if ($stage===3 && in_array((string)($role['role_level'] ?? ''),['manager','lead','specialist'],true)) $roleFit+=7.0;
        }

        $skillFit=0.0;
        if ($domain && (in_array(strtolower($domain),$skills,true) || str_contains(strtolower((string)$member->role),strtolower($domain)))) $skillFit+=10.0;
        if ($capability && in_array(strtolower($capability),$capabilities,true)) $skillFit+=10.0;

        return [
            'rating'=>round($ratingScore*0.20,2),
            'reviewer_decision_quality'=>round($reviewerQuality*0.12,2),
            'reviewer_risk_detection'=>round($reviewerRisk*0.08,2),
            'capacity'=>round((1.0-$load)*20.0,2),
            'role_responsibility_fit'=>round($roleFit,2),
            'skill_capability_fit'=>round($skillFit,2),
            'availability'=>15.0,
            'domain_division_fit'=>$this->domainFits($member,$domain,$stage,$chain)?10.0:0.0,
        ];
    }

    private function domainFits(WorkforceMember $member, ?string $domain, int $stage, WorkforceDecisionChain $chain): bool
    {
        if ($domain===null || $domain==='') return true;
        $meta=(array)($member->metadata ?? []);
        $declared=array_map('strtolower',array_values(array_map('strval',(array)($meta['domains'] ?? $meta['domain_keys'] ?? []))));
        if (in_array(strtolower($domain),$declared,true)) return true;

        $roleText=strtolower((string)$member->role.' '.(string)$member->role_definition_id);
        if (str_contains($roleText,strtolower($domain))) return true;

        if ($stage===1 && (int)$member->division_id === (int)$chain->task?->division_id) return true;

        // For stage 3, cross-domain separation is enforced by the independence engine,
        // while a declared receiving-domain role remains preferred.
        return $declared===[] && $stage!==3;
    }

    private function responsibilityFits(WorkforceMember $member,string $responsibility): bool
    {
        if (in_array($responsibility,(array)($member->responsibilities ?? []),true)) return true;
        $role=$member->role_definition_id ? $this->roles->role((string)$member->role_definition_id) : null;
        return $role ? in_array($responsibility,(array)($role['responsibility_ids'] ?? []),true) : false;
    }

    private function riskFits(WorkforceMember $member,string $risk): bool
    {
        $rank=['MINIMAL'=>1,'LOW'=>2,'ORDINARY'=>2,'MEDIUM'=>3,'HIGH'=>4,'REGULATED'=>4,'CRITICAL'=>5,'SEVERE'=>5,'EXTREME'=>5];
        return ($rank[strtoupper($risk)] ?? 2) <= ($rank[strtoupper((string)$member->risk_ceiling)] ?? 2);
    }

    private function hasCapacity(WorkforceMember $member): bool
    {
        return $this->loadRatio($member) < 1.0;
    }

    private function loadRatio(WorkforceMember $member): float
    {
        $limit=max(1,(int)($member->max_concurrent_tasks ?? data_get($member->workload_config ?? [],'max_concurrent',5)));
        $open=$member->assignedTasks()->whereNotIn('status',['COMPLETED','FAILED','CANCELLED','REJECTED'])->count();
        return min(1.0,$open/$limit);
    }

    private function requiredDomain(WorkforceDecisionChain $chain,int $stage,array $requirements): ?string
    {
        return $this->nullable($requirements['domain'] ?? match($stage) {
            1 => $chain->origin_domain,
            2 => $chain->processing_domain,
            3 => $chain->receiving_domain,
        });
    }

    private function nullable(mixed $value): ?string
    {
        $v=trim((string)($value ?? ''));
        return $v===''?null:$v;
    }
}
