<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;

final class ProactiveManagerService
{
    public function __construct(
        private readonly WorkforceQueueHealthService $health,
        private readonly WorkforceTaskService $tasks,
        private readonly WorkloadSharingService $sharing,
        private readonly WorkforcePlanningService $planning,
        private readonly WorkforceManifestRegistry $manifests,
    ) {}

    public function runAll(int $limit = 100): array
    {
        $summary = ['managers' => 0, 'alerts' => 0, 'reassigned' => 0, 'staffing_recommendations' => 0];
        WorkforceMember::query()->staffingSeats()->where('tier', WorkforceTier::Manager->value)->where('is_active', true)->whereNotIn('status', ['OFFLINE','SUSPENDED'])->orderBy('id')->limit($limit)->get()
            ->each(function (WorkforceMember $manager) use (&$summary): void {
                CompanyContext::runWith((int) $manager->company_id, function () use ($manager, &$summary): void {
                    $result = $this->runManager($manager);
                    $summary['managers']++;
                    $summary['alerts'] += $result['alert_task_id'] ? 1 : 0;
                    $summary['reassigned'] += count($result['reassigned_task_ids']);
                    $summary['staffing_recommendations'] += count($result['staffing_recommendations']);
                });
            });
        return $summary;
    }

    public function runManager(WorkforceMember $manager): array
    {
        $snapshot = $this->health->forManager($manager);
        $definition = ($manager->role_owner_extension && $manager->role_definition_id)
            ? $this->manifests->findOwnedRole((string) $manager->role_owner_extension, (string) $manager->role_definition_id)
            : null;
        if (! $definition || (int) ($definition['tier'] ?? 0) !== WorkforceTier::Manager->value) {
            return [
                'queue_health' => $snapshot,
                'reassigned_task_ids' => [],
                'staffing_recommendations' => [],
                'alert_task_id' => null,
                'auto_activate' => false,
                'skipped_reason' => 'manifest_manager_definition_unavailable',
            ];
        }

        $reassigned = $this->rebalance($manager);
        $divisionKey = (string) optional($manager->division)->key;
        $businessTier = strtoupper((string) data_get($manager->metadata ?? [], 'business_tier', 'SMALL'));
        $verticals = (array) data_get($manager->metadata ?? [], 'verticals', []);
        $recommendations = $divisionKey !== ''
            ? $this->planning->recommend((int) $manager->company_id, $businessTier, $verticals, [$divisionKey => $snapshot])
            : [];
        $recommendations = array_values(array_filter($recommendations, fn (array $item): bool => ($item['division'] ?? null) === $divisionKey));
        foreach ($recommendations as &$recommendation) {
            $recommendation['auto_activate'] = false;
        }
        unset($recommendation);

        $staffingPressure = is_array($snapshot['staffing_pressure'] ?? null) ? $snapshot['staffing_pressure'] : [];
        $needsAttention = in_array($snapshot['pressure'], ['HIGH','CRITICAL'], true)
            || $snapshot['overdue_count'] > 0
            || $snapshot['starved_count'] > 0
            || $snapshot['coverage_gap']
            || (bool) ($staffingPressure['recommend_staffing'] ?? false)
            || $recommendations !== [];

        $alertTask = null;
        if ($needsAttention) {
            $capability = $this->managerPriorityCapability($definition);
            $window = now()->copy()->minute((int) floor(now()->minute / 15) * 15)->second(0)->format('YmdHi');
            $alertTask = $this->tasks->create((int) $manager->company_id, [
                'division_id' => $manager->division_id,
                'team_id' => $manager->team_id,
                'assignee_member_id' => $manager->id,
                'manager_member_id' => $manager->manager_id,
                'origin_type' => 'workforce_queue_health',
                'origin_id' => $divisionKey,
                'title' => ($manager->division?->name ?? 'Division') . ' proactive queue review',
                'description' => 'Review queue pressure, overdue work, starvation, coverage and staffing recommendations. Decompose only into governed Workforce tasks.',
                'capability' => $capability,
                'status' => WorkforceTaskStatus::Assigned,
                'priority' => $snapshot['pressure'] === 'CRITICAL' ? 95 : 80,
                'risk_level' => 'LOW',
                'payload' => [
                    'queue_health' => $snapshot,
                    'staffing_pressure' => $staffingPressure,
                    'staffing_recommendations' => $recommendations,
                    'auto_activate' => false,
                    'auto_hire' => false,
                ],
                'idempotency_key' => 'manager-health:' . $manager->id . ':' . $window,
                'metadata' => ['proactive' => true, 'organisational_only' => true, 'business_mutation' => false],
            ], $manager);
            if ($alertTask->wasRecentlyCreated) {
                ProcessWorkforceTaskJob::dispatch((int) $manager->company_id, (int) $alertTask->id);
            }
        }

        return [
            'queue_health' => $snapshot,
            'reassigned_task_ids' => $reassigned,
            'staffing_recommendations' => $recommendations,
            'staffing_pressure' => $staffingPressure,
            'alert_task_id' => $alertTask?->task_uuid,
            'auto_activate' => false,
        ];
    }

    private function rebalance(WorkforceMember $manager): array
    {
        $limit = max(0, (int) (WorkforceResponsibilityRegistry::policy()['rebalance_limit_per_manager'] ?? 3));
        if ($limit === 0) return [];

        $reassigned = [];
        $tasks = WorkforceTask::query()->forCompany((int) $manager->company_id)
            ->where('manager_member_id', $manager->id)
            ->where('division_id', $manager->division_id)
            ->where('status', WorkforceTaskStatus::Assigned->value)
            ->whereNotNull('assignee_member_id')
            ->orderByDesc('priority')->orderBy('created_at')->limit($limit * 4)->get();

        foreach ($tasks as $task) {
            if (count($reassigned) >= $limit) break;
            $current = WorkforceMember::query()->forCompany((int) $manager->company_id)->find($task->assignee_member_id);
            if (! $current || ! $this->isOverloaded($current)) continue;
            $substitute = $this->sharing->findSubstitute($task, $current);
            if (! $substitute) continue;
            $this->sharing->reassign($task, $manager, $substitute, 'Proactive same-division workload balance; no authority transferred.');
            $reassigned[] = (string) $task->task_uuid;
        }
        return $reassigned;
    }

    private function isOverloaded(WorkforceMember $member): bool
    {
        $limit = max(1, (int) ($member->max_concurrent_tasks ?? 5));
        $open = $member->assignedTasks()->whereNotIn('status', ['COMPLETED','FAILED','CANCELLED','REJECTED'])->count();
        return $open >= $limit;
    }

    private function managerPriorityCapability(array $definition): string
    {
        foreach ($definition['capabilities'] ?? [] as $capability) {
            if (str_starts_with((string) $capability, 'prioritise_')) return (string) $capability;
        }
        return (string) ($definition['capabilities'][0] ?? '');
    }
}
