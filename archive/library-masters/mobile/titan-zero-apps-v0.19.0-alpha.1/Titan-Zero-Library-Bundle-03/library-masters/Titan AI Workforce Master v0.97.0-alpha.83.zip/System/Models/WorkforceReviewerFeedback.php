<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceReviewerFeedback extends Model
{
    protected $table='ext_titan_ai_workforce_reviewer_feedback';
    protected $guarded=[];
    protected $casts=[
        'quality_score'=>'decimal:2','evidence_quality_score'=>'decimal:2','judgement_score'=>'decimal:2',
        'escalation_score'=>'decimal:2','risk_detection_score'=>'decimal:2',
        'verified_outcome'=>'boolean','overturned'=>'boolean','missed_risk'=>'boolean',
        'unnecessary_escalation'=>'boolean','evidence'=>'array','observed_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
