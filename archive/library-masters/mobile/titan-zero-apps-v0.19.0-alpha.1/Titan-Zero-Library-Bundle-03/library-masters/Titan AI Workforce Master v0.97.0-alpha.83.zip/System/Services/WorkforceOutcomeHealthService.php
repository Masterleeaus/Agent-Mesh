<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;

final class WorkforceOutcomeHealthService
{
    public function snapshot(int $companyId, int $lateAfterMinutes = 30): array
    {
        $lateAfterMinutes = max(5, min(10080, $lateAfterMinutes));
        $cutoff = now()->subMinutes($lateAfterMinutes);

        $attempts = WorkforceExecutionAttempt::query()
            ->where('company_id', $companyId)
            ->whereIn('status', ['RECEIPT_VALIDATED','VERIFIED','RECOVERY_REQUIRED','COMPLETED'])
            ->latest('updated_at')->limit(250)->get();

        $missing = $attempts->filter(fn (WorkforceExecutionAttempt $attempt) => $attempt->verification_status === null);
        $late = $attempts->filter(function (WorkforceExecutionAttempt $attempt) use ($cutoff) {
            if ($attempt->verification_status === 'VERIFIED') return false;
            return optional($attempt->updated_at)->lte($cutoff) ?? false;
        });
        $recovery = WorkforceTask::query()->forCompany($companyId)->where('status', 'RECOVERY')->count();

        $signals = [];
        if ($missing->isNotEmpty()) $signals[] = 'OUTCOME_VERIFICATION_MISSING';
        if ($late->isNotEmpty()) $signals[] = 'OUTCOME_VERIFICATION_LATE';
        if ($recovery > 0) $signals[] = 'RECOVERY';

        return [
            'company_id' => $companyId,
            'late_after_minutes' => $lateAfterMinutes,
            'verification_missing' => $missing->count(),
            'verification_late' => $late->count(),
            'recovery_tasks' => $recovery,
            'signals' => $signals,
            'status' => $late->isNotEmpty() ? 'ATTENTION_REQUIRED' : ($missing->isNotEmpty() || $recovery > 0 ? 'WATCH' : 'HEALTHY'),
            'attempts' => $attempts->take(50)->map(fn (WorkforceExecutionAttempt $attempt) => [
                'attempt_uuid' => $attempt->attempt_uuid,
                'task_id' => $attempt->task_id,
                'status' => $attempt->status,
                'verification_status' => $attempt->verification_status,
                'receipt_ref' => $attempt->receipt_ref,
                'updated_at' => optional($attempt->updated_at)->toIso8601String(),
            ])->values()->all(),
        ];
    }
}
