<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;

/**
 * Pure state classifier used by the live capability availability service.
 */
final class WorkforceCapabilityStateResolver
{
    /**
     * @param array{required?:array,published?:array,provider_installed?:bool,contribution_valid?:bool,policy_enabled?:bool} $input
     */
    public function classify(array $input): WorkforceCapabilityState
    {
        if (($input['policy_enabled'] ?? true) !== true) {
            return WorkforceCapabilityState::PolicyDisabled;
        }
        if (($input['provider_installed'] ?? false) !== true) {
            return WorkforceCapabilityState::MissingProvider;
        }
        if (($input['contribution_valid'] ?? false) !== true) {
            return WorkforceCapabilityState::Blocked;
        }

        $required = $this->normalise((array) ($input['required'] ?? []));
        $published = array_fill_keys($this->normalise((array) ($input['published'] ?? [])), true);
        if ($required === []) return WorkforceCapabilityState::Available;

        $matched = 0;
        foreach ($required as $id) {
            if (isset($published[$id])) $matched++;
        }
        if ($matched === count($required)) return WorkforceCapabilityState::Available;
        if ($matched > 0) return WorkforceCapabilityState::Degraded;
        return WorkforceCapabilityState::Unavailable;
    }

    /** @param list<WorkforceCapabilityState|string> $states */
    public function aggregate(array $states): WorkforceCapabilityState
    {
        $values = array_values(array_filter(array_map(
            static fn (WorkforceCapabilityState|string $state): ?WorkforceCapabilityState => $state instanceof WorkforceCapabilityState
                ? $state
                : WorkforceCapabilityState::tryFrom((string) $state),
            $states,
        )));
        if ($values === []) return WorkforceCapabilityState::Unavailable;

        $unique = [];
        foreach ($values as $state) $unique[$state->value] = $state;
        if (count($unique) === 1) return array_values($unique)[0];

        if (isset($unique[WorkforceCapabilityState::Available->value]) || isset($unique[WorkforceCapabilityState::Degraded->value])) {
            return WorkforceCapabilityState::Degraded;
        }
        if (isset($unique[WorkforceCapabilityState::Blocked->value])) return WorkforceCapabilityState::Blocked;
        if (isset($unique[WorkforceCapabilityState::PolicyDisabled->value])) return WorkforceCapabilityState::PolicyDisabled;
        if (isset($unique[WorkforceCapabilityState::MissingProvider->value])) return WorkforceCapabilityState::MissingProvider;
        return WorkforceCapabilityState::Unavailable;
    }

    /** @return list<string> */
    private function normalise(array $values): array
    {
        $out = array_values(array_unique(array_filter(array_map(
            static fn ($value): string => trim((string) $value),
            $values,
        ), static fn (string $value): bool => $value !== '')));
        sort($out);
        return $out;
    }
}
