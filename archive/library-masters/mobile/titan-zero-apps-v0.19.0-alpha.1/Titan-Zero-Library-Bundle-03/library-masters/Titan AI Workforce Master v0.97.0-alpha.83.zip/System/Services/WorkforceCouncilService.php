<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncil;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncilMembership;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceOrganisationPolicyRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceCouncilService
{
    public function __construct(private readonly WorkforceTaskService $tasks) {}

    public function convene(int $companyId, string $councilKey, array $context = []): WorkforceTask
    {
        $policy = WorkforceOrganisationPolicyRegistry::all()['councils'][$councilKey] ?? null;
        if (! is_array($policy)) {
            throw new InvalidArgumentException('Unknown Workforce council: ' . $councilKey);
        }
        $chair = $this->managerForRole($companyId, (string) ($policy['chair'] ?? 'operations-manager'));
        if (! $chair) {
            throw new InvalidArgumentException('Council chair is not active in this company.');
        }

        $council = WorkforceCouncil::query()->updateOrCreate(
            ['company_id' => $companyId, 'key' => $councilKey],
            [
                'council_uuid' => (string) (WorkforceCouncil::query()->forCompany($companyId)->where('key', $councilKey)->value('council_uuid') ?: Str::uuid()),
                'name' => (string) ($policy['name'] ?? $councilKey),
                'purpose' => (string) ($policy['purpose'] ?? 'Cross-functional Workforce coordination.'),
                'chair_role_definition_id' => (string) ($chair->role_definition_id ?? ''),
                'decision_authority' => (string) ($policy['decision_authority'] ?? 'none'),
                'schedule' => ['cadence' => $policy['cadence'] ?? 'as_needed'],
                'is_active' => true,
            ]
        );

        WorkforceCouncilMembership::query()->updateOrCreate(
            ['company_id' => $companyId, 'council_id' => $council->id, 'member_id' => $chair->id, 'role_definition_id' => (string) ($chair->role_definition_id ?? '')],
            ['participation_type' => 'CHAIR', 'is_active' => true, 'metadata' => ['authority_inherited' => false, 'execution_authority_granted' => false]]
        );
        foreach ($this->participantMembers($companyId, (array) ($policy['participants'] ?? [])) as $participant) {
            if ((int) $participant->id === (int) $chair->id) continue;
            WorkforceCouncilMembership::query()->updateOrCreate(
                ['company_id' => $companyId, 'council_id' => $council->id, 'member_id' => $participant->id, 'role_definition_id' => (string) ($participant->role_definition_id ?? '')],
                ['participation_type' => 'MEMBER', 'is_active' => true, 'metadata' => ['authority_inherited' => false, 'execution_authority_granted' => false]]
            );
        }

        $issue = trim((string) ($context['issue'] ?? $context['title'] ?? $policy['purpose'] ?? $policy['name'] ?? $councilKey));
        $period = $councilKey === 'daily_ops' || ($policy['cadence'] ?? null) === 'daily' ? now()->format('Y-m-d') : now()->format('o-W');
        $sessionKey = $period.'-'.substr(sha1($issue), 0, 10);
        $task = $this->tasks->create($companyId, [
            'division_id' => $chair->division_id,
            'team_id' => $chair->team_id,
            'assignee_member_id' => $chair->id,
            'manager_member_id' => $chair->manager_id,
            'origin_type' => 'workforce_council',
            'origin_id' => $councilKey . ':' . $sessionKey,
            'title' => (string) ($policy['name'] ?? $councilKey) . ': ' . $issue,
            'description' => $issue,
            'priority' => (int) ($context['priority'] ?? 70),
            'risk_level' => (string) ($context['risk_level'] ?? 'LOW'),
            'payload' => [
                'council_id' => $council->id,
                'council_key' => $councilKey,
                'participants' => $policy['participants'] ?? [],
                'issue' => $issue,
                'context' => $context,
                'decision_authority' => $policy['decision_authority'] ?? 'none',
            ],
            'idempotency_key' => 'council:' . $companyId . ':' . $councilKey . ':' . $sessionKey,
            'metadata' => [
                'governed_coordination_only' => true,
                'may_not_bypass_chain_of_command' => true,
                'requires_fresh_execution_authorization' => true,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ],
        ], $chair);

        $metadata = (array) ($council->metadata ?? []);
        $metadata['current_session'] = [
            'session_key' => $sessionKey,
            'task_id' => $task->id,
            'task_uuid' => $task->task_uuid,
            'issue' => $issue,
            'evidence' => array_values((array) ($context['evidence'] ?? [])),
            'proposals' => array_values((array) ($context['proposals'] ?? [])),
            'dissent' => array_values((array) ($context['dissent'] ?? [])),
            'recommendation' => $context['recommendation'] ?? null,
            'final_decision' => $context['final_decision'] ?? null,
            'follow_up_work_items' => [],
            'started_at' => now()->toIso8601String(),
        ];
        $metadata['audit_history'] = array_values(array_merge((array) ($metadata['audit_history'] ?? []), [[
            'event' => 'council.convened',
            'at' => now()->toIso8601String(),
            'member_id' => $chair->id,
            'data' => ['session_key' => $sessionKey, 'issue' => $issue, 'task_id' => $task->id],
            'authority_inherited' => false,
        ]]));
        $metadata['authority_inherited'] = false;
        $metadata['execution_authority_granted'] = false;
        $council->metadata = $metadata;
        $council->save();

        ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);
        return $task;
    }

    private function managerForRole(int $companyId, string $roleKey): ?WorkforceMember
    {
        $definition = WorkforceRoleRegistry::find($roleKey);
        $roleId = $definition['role_id'] ?? null;
        return WorkforceMember::query()->forCompany($companyId)
            ->staffingSeats()
            ->where('tier', WorkforceTier::Manager->value)
            ->where('is_active', true)
            ->where(function ($q) use ($roleKey, $roleId) {
                $q->where('key', $roleKey);
                if ($roleId) $q->orWhere('role_definition_id', $roleId);
            })->first();
    }

    /** @param array<int,string> $roleKeys @return array<int,WorkforceMember> */
    private function participantMembers(int $companyId, array $roleKeys): array
    {
        $members = collect();
        foreach ($roleKeys as $roleKey) {
            if ($roleKey === 'all-division-managers') {
                $members = $members->merge(WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('tier', WorkforceTier::Manager->value)->where('is_active', true)->get());
                continue;
            }
            $definition = WorkforceRoleRegistry::find((string) $roleKey);
            $roleId = $definition['role_id'] ?? null;
            $member = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)
                ->where(function ($q) use ($roleKey, $roleId) {
                    $q->where('key', $roleKey);
                    if ($roleId) $q->orWhere('role_definition_id', $roleId);
                })->first();
            if ($member) $members->push($member);
        }
        return $members->unique('id')->values()->all();
    }
}
