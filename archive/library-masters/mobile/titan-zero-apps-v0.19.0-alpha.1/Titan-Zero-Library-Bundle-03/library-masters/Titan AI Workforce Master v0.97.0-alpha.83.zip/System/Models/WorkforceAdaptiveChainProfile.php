<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceAdaptiveChainProfile extends Model
{
    protected $table='ext_titan_ai_workforce_adaptive_chain_profiles';
    protected $guarded=[];
    protected $casts=[
        'uncertainty_score'=>'integer','consequence_score'=>'integer','reviewer_quality_floor'=>'integer',
        'force_assurance'=>'boolean','force_model_council'=>'boolean','prefer_provider_diversity'=>'boolean',
        'mandatory_three_checks'=>'boolean','signals'=>'array','reviewer_requirements'=>'array','calculated_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
