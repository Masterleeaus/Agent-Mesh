<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class WorkforceResponsibilityCapabilityRequirements
{
    private ?array $document = null;

    public function all(): array
    {
        return $this->document ??= $this->load()['requirements'] ?? [];
    }

    public function forResponsibility(string $responsibilityId): ?array
    {
        foreach ($this->all() as $requirement) {
            if (($requirement['responsibility_id'] ?? null) === $responsibilityId) {
                return $requirement;
            }
        }

        return null;
    }

    public function forRole(string $roleDefinitionId): array
    {
        return array_values(array_filter(
            $this->all(),
            static fn (array $row): bool => ($row['role_definition_id'] ?? null) === $roleDefinitionId
        ));
    }

    private function load(): array
    {
        $path = dirname(__DIR__, 2).'/resources/workforce/responsibility-capability-requirements.json';
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);

        return is_array($decoded) ? $decoded : [];
    }
}
