<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
final class WorkforceFieldOperationsCycle extends Model
{
    use SoftDeletes;
    protected $table='ext_titan_ai_workforce_field_operations_cycles';
    protected $guarded=[];
    protected $casts=['assignee_map'=>'array','context_refs'=>'array','readiness_report'=>'array','metadata'=>'array','started_at'=>'datetime','completed_at'=>'datetime'];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
