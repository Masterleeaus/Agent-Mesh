<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResponsibility;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResponsibilityOverride;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRoleResponsibility;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTrigger;
use Illuminate\Support\Collection;
use InvalidArgumentException;

final class WorkforceResponsibilitiesCenterService
{
    public function __construct(private readonly WorkforceCapabilityAvailabilityService $availability) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $definitions = WorkforceResponsibility::query()->visibleToCompany($companyId)->orderBy('category')->orderBy('name')->get();
        $assignments = WorkforceRoleResponsibility::query()->visibleToCompany($companyId)->get()->groupBy('responsibility_id');
        $members = WorkforceMember::query()->forCompany($companyId)->with(['division','team'])->orderBy('name')->get();
        $overrides = WorkforceResponsibilityOverride::query()->forCompany($companyId)->get()->keyBy('responsibility_id');
        $schedules = WorkforceSchedule::query()->forCompany($companyId)->get();
        $triggers = WorkforceTrigger::query()->forCompany($companyId)->get();
        $tasks = WorkforceTask::query()->forCompany($companyId)->with('assignee')->latest('id')->limit(750)->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)->latest('id')->limit(500)->get();

        $rows = [];
        foreach ($definitions as $definition) {
            $responsibilityId = (string) $definition->responsibility_id;
            $roleAssignments = $assignments->get($responsibilityId, collect());
            $roleIds = $roleAssignments->pluck('role_definition_id')->filter()->unique()->values()->all();
            $eligibleMembers = $members->filter(fn (WorkforceMember $m): bool => in_array((string) $m->role_definition_id, $roleIds, true))->values();
            $override = $overrides->get($responsibilityId);
            $assigned = $override?->assigned_member_id ? $eligibleMembers->firstWhere('id', (int) $override->assigned_member_id) : $eligibleMembers->first(fn (WorkforceMember $m): bool => (bool) $m->is_active);
            $roleId = (string) ($roleIds[0] ?? data_get($definition->metadata ?? [], 'source_role_definition_id', ''));
            $capability = $roleId !== '' ? $this->availability->forRole($roleId) : [];
            $providerBindings = collect($capability['provider_bindings'] ?? []);
            $requiredCapabilities = $providerBindings->flatMap(fn (array $binding) => collect(data_get($binding, 'surfaces.capabilities', []))->pluck('id'))->filter()->unique()->values()->all();
            $providerHealth = $providerBindings->map(fn (array $binding): array => ['provider'=>(string)($binding['provider']??''),'state'=>(string)($binding['state']??'unavailable')])->values()->all();

            $relatedSchedules = $this->relatedSchedules($schedules, $responsibilityId, (string) $definition->key, $roleId);
            $relatedTriggers = $this->relatedTriggers($triggers, $responsibilityId, (string) $definition->key, $roleId);
            $recentWork = $tasks->filter(fn (WorkforceTask $task): bool => $this->taskMatches($task, $responsibilityId, (string) $definition->key))->take(5)->values();
            $taskIds = $recentWork->pluck('id')->map(fn ($v)=>(int)$v)->all();
            $recentOutcomes = $outcomes->filter(fn (WorkforceOutcome $outcome): bool => in_array((int) $outcome->task_id, $taskIds, true))->take(5)->values();

            $rows[] = [
                'definition' => $definition,
                'owner_role_ids' => $roleIds,
                'assigned_employee' => $assigned,
                'eligible_members' => $eligibleMembers,
                'division' => $assigned?->division,
                'team' => $assigned?->team,
                'purpose' => (string) ($definition->description ?? ''),
                'is_enabled' => $override ? (bool) $override->is_enabled : strtoupper((string) $definition->status) === 'ACTIVE',
                'schedule' => $override?->schedule ?? $relatedSchedules->first()?->schedule ?? null,
                'trigger_conditions' => $override?->trigger_conditions ?? $relatedTriggers->first()?->conditions ?? null,
                'source_schedules' => $relatedSchedules,
                'source_triggers' => $relatedTriggers,
                'required_capabilities' => $requiredCapabilities,
                'provider_health' => $providerHealth,
                'capability_state' => (string) ($capability['state'] ?? 'unavailable'),
                'authority_requirements' => [
                    'capability_authority' => (string) ($definition->capability_authority ?? 'NONE'),
                    'authority_inherited' => false,
                    'execution_authority_granted' => false,
                    'policy' => 'Execution authority is resolved separately by Governance and Titan Autonomy at task execution time.',
                ],
                'recent_work' => $recentWork,
                'recent_outcomes' => $recentOutcomes,
                'override' => $override,
            ];
        }

        return [
            'company_id' => $companyId,
            'total' => count($rows),
            'enabled' => count(array_filter($rows, fn(array $r): bool => $r['is_enabled'])),
            'disabled' => count(array_filter($rows, fn(array $r): bool => ! $r['is_enabled'])),
            'degraded' => count(array_filter($rows, fn(array $r): bool => in_array($r['capability_state'], ['degraded','blocked','missing_provider','unavailable'], true))),
            'rows' => $rows,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @param array<string,mixed> $data */
    public function update(int $companyId, string $responsibilityId, array $data): WorkforceResponsibilityOverride
    {
        $definition = WorkforceResponsibility::query()->visibleToCompany($companyId)->where('responsibility_id', $responsibilityId)->firstOrFail();
        $assignments = WorkforceRoleResponsibility::query()->visibleToCompany($companyId)->where('responsibility_id', $responsibilityId)->get();
        $roleIds = $assignments->pluck('role_definition_id')->filter()->unique()->values()->all();

        $memberId = isset($data['assigned_member_id']) && $data['assigned_member_id'] !== '' ? (int) $data['assigned_member_id'] : null;
        if ($memberId !== null) {
            $member = WorkforceMember::query()->forCompany($companyId)->findOrFail($memberId);
            if (! in_array((string) $member->role_definition_id, $roleIds, true)) {
                throw new InvalidArgumentException('Responsibility may only be reassigned to an employee holding an allowed canonical owner role.');
            }
        }

        $override = WorkforceResponsibilityOverride::query()->firstOrNew(['company_id'=>$companyId,'responsibility_id'=>$responsibilityId]);
        $override->fill([
            'assigned_member_id' => $memberId,
            'is_enabled' => (bool) ($data['is_enabled'] ?? false),
            'schedule' => $data['schedule'] ?? null,
            'trigger_conditions' => $data['trigger_conditions'] ?? null,
            'metadata' => [
                'source' => 'responsibilities_center',
                'authority_inherited' => false,
                'execution_authority_granted' => false,
                'canonical_definition_status' => (string) $definition->status,
            ],
        ])->save();
        return $override;
    }

    private function relatedSchedules(Collection $rows, string $id, string $key, string $roleId): Collection
    {
        return $rows->filter(fn (WorkforceSchedule $row): bool => (string)data_get($row->metadata ?? [], 'responsibility_id') === $id || (string)data_get($row->metadata ?? [], 'responsibility_key') === $key || ($roleId !== '' && (string)$row->role_definition_id === $roleId))->values();
    }
    private function relatedTriggers(Collection $rows, string $id, string $key, string $roleId): Collection
    {
        return $rows->filter(fn (WorkforceTrigger $row): bool => (string)data_get($row->metadata ?? [], 'responsibility_id') === $id || (string)data_get($row->metadata ?? [], 'responsibility_key') === $key || ($roleId !== '' && (string)$row->role_definition_id === $roleId))->values();
    }
    private function taskMatches(WorkforceTask $task, string $id, string $key): bool
    {
        $metadata = is_array($task->metadata) ? $task->metadata : [];
        $payload = is_array($task->payload) ? $task->payload : [];
        return in_array((string)($metadata['responsibility_id'] ?? ''), [$id,$key], true)
            || in_array((string)($metadata['responsibility_key'] ?? ''), [$id,$key], true)
            || in_array((string)($payload['responsibility_id'] ?? ''), [$id,$key], true)
            || in_array((string)($payload['responsibility_key'] ?? ''), [$id,$key], true);
    }
}
