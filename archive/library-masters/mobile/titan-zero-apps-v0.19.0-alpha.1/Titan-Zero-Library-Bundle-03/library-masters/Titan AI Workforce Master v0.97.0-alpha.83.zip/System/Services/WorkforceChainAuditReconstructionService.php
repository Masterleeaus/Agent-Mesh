<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceAssuranceCouncilReview;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainAuditSnapshot;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFederation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDomainHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerFeedback;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRecoveryStep;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceChainAuditReconstructionService
{
    /** @return array<string,mixed> */
    public function reconstruct(WorkforceDecisionChain $chain): array
    {
        $chain->loadMissing('task');
        $task=$chain->task;
        if(!$task) throw new RuntimeException('DECISION_CHAIN_TASK_MISSING');

        $checkpoints=WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('stage')->get();
        $challenges=WorkforceDecisionChallenge::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('id')->get();
        $escalations=WorkforceChainEscalation::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('id')->get();
        $assurance=WorkforceAssuranceCouncilReview::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('id')->get();
        $gates=WorkforceFinalAuthorityGate::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('id')->get();
        $attempts=WorkforceExecutionAttempt::query()->where('company_id',(int)$chain->company_id)
            ->where('task_id',$task->getKey())->orderBy('id')->get();
        $feedback=WorkforceReviewerFeedback::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->orderBy('id')->get();
        $federation=WorkforceChainFederation::query()->forCompany((int)$chain->company_id)
            ->where('decision_chain_id',$chain->getKey())->first();
        $handoffs=$federation
            ? WorkforceDomainHandoff::query()->forCompany((int)$chain->company_id)
                ->where('federation_id',$federation->getKey())->orderBy('sequence')->get()
            : collect();

        $recoveryPlans=WorkforceRecoveryPlan::query()->forCompany((int)$chain->company_id)
            ->where('root_decision_chain_id',$chain->getKey())->orderBy('id')->get();

        $events=DB::table('ext_titan_ai_workforce_decision_chain_events')
            ->where('company_id',(int)$chain->company_id)->where('processing_id',$chain->processing_id)
            ->orderBy('occurred_at')->orderBy('id')->get()->map(fn($e)=>[
                'event_type'=>$e->event_type,'stage'=>$e->stage,'actor_member_id'=>$e->actor_member_id,
                'from_state'=>$e->from_state,'to_state'=>$e->to_state,
                'evidence'=>$this->json($e->evidence),'occurred_at'=>$e->occurred_at,
            ])->values()->all();

        return [
            'schema'=>'titan.workforce.chain-audit.v1',
            'company_id'=>(int)$chain->company_id,
            'processing_id'=>$chain->processing_id,
            'decision_chain'=>[
                'chain_uuid'=>$chain->chain_uuid,
                'state'=>$chain->state->value,
                'task_id'=>$task->task_uuid,
                'capability'=>$task->capability,
                'proposer_member_id'=>$chain->proposer_member_id,
                'origin_domain'=>$chain->origin_domain,
                'processing_domain'=>$chain->processing_domain,
                'receiving_domain'=>$chain->receiving_domain,
                'risk_class'=>$chain->risk_class,
                'consequential'=>(bool)$chain->consequential,
                'organisationally_approved'=>(bool)$chain->organisationally_approved,
                'authority_gates_ready'=>(bool)$chain->authority_gates_ready,
                'contract_snapshot'=>$chain->contract_snapshot,
                'knowledge_authority_receipt'=>$chain->knowledge_receipt,
                'approved_at'=>$chain->approved_at?->toIso8601String(),
                'closed_at'=>$chain->closed_at?->toIso8601String(),
            ],
            'reviewers'=>$checkpoints->map(fn($c)=>[
                'stage'=>(int)$c->stage,
                'checkpoint_uuid'=>$c->checkpoint_uuid,
                'owner_member_id'=>$c->owner_member_id,
                'reviewer_member_id'=>$c->reviewer_member_id,
                'status'=>$c->status->value,
                'packet_sha256'=>data_get($c->decision ?? [],'action_review_packet.packet_sha256')
                    ?? data_get($c->metadata ?? [],'action_review_packet_sha256'),
                'knowledge_receipt'=>data_get($c->decision ?? [],'knowledge_gap_receipt')
                    ?? data_get($c->metadata ?? [],'knowledge_authority_receipt'),
                'decision'=>$c->decision,
                'reviewed_at'=>$c->reviewed_at?->toIso8601String(),
            ])->values()->all(),
            'challenges'=>$challenges->map(fn($c)=>[
                'challenge_uuid'=>$c->challenge_uuid,'challenger_stage'=>$c->challenger_stage,
                'challenged_stage'=>$c->challenged_stage,'challenger_member_id'=>$c->challenger_member_id,
                'challenged_member_id'=>$c->challenged_member_id,'status'=>$c->status,
                'disputed_claims'=>$c->disputed_claims,'evidence_challenges'=>$c->evidence_challenges,
                'authority_challenges'=>$c->authority_challenges,'rebuttal'=>$c->rebuttal,
                'resolution'=>$c->resolution,'opened_at'=>$c->opened_at?->toIso8601String(),
                'resolved_at'=>$c->resolved_at?->toIso8601String(),
            ])->values()->all(),
            'cross_domain_federation'=>$federation ? [
                'federation_uuid'=>$federation->federation_uuid,
                'root_processing_id'=>$federation->root_processing_id,
                'domain_path'=>$federation->domain_path,
                'handoff_count'=>$federation->handoff_count,
                'accepted_handoff_count'=>$federation->accepted_handoff_count,
                'status'=>$federation->status,
                'completed_at'=>$federation->completed_at?->toIso8601String(),
                'handoffs'=>$handoffs->map(fn($h)=>[
                    'handoff_uuid'=>$h->handoff_uuid,'sequence'=>$h->sequence,
                    'from_domain'=>$h->from_domain,'to_domain'=>$h->to_domain,'status'=>$h->status,
                    'accepted_by_member_id'=>$h->accepted_by_member_id,
                    'incoming_state_sha256'=>$h->incoming_state_sha256,
                    'acceptance_sha256'=>$h->acceptance_sha256,
                    'acceptance'=>$h->acceptance,
                    'knowledge_authority_receipt'=>$h->knowledge_authority_receipt,
                    'accepted_at'=>$h->accepted_at?->toIso8601String(),
                    'rejected_at'=>$h->rejected_at?->toIso8601String(),
                ])->values()->all(),
            ] : null,
            'manager_escalations'=>$escalations->map(fn($e)=>[
                'escalation_uuid'=>$e->escalation_uuid,'stage'=>$e->stage,'level'=>$e->level,
                'reason_code'=>$e->reason_code,'raised_by_member_id'=>$e->raised_by_member_id,
                'assigned_to_member_id'=>$e->assigned_to_member_id,'acting_for_member_id'=>$e->acting_for_member_id,
                'status'=>$e->status,'path'=>$e->path,'evidence'=>$e->evidence,
                'raised_at'=>$e->raised_at?->toIso8601String(),'resolved_at'=>$e->resolved_at?->toIso8601String(),
            ])->values()->all(),
            'assurance_and_model_council'=>$assurance->map(fn($a)=>[
                'review_uuid'=>$a->review_uuid,'assurance_status'=>$a->assurance_status,
                'assurance_score'=>$a->assurance_score,'assurance_result'=>$a->assurance_result,
                'model_council_required'=>(bool)$a->model_council_required,
                'council_status'=>$a->council_status,'council_role_models'=>$a->council_role_models,
                'council_result'=>$a->council_result,'final_status'=>$a->final_status,
                'advisory_only'=>(bool)$a->advisory_only,'reviewed_at'=>$a->reviewed_at?->toIso8601String(),
            ])->values()->all(),
            'authority_gates'=>$gates->map(fn($g)=>[
                'gate_uuid'=>$g->gate_uuid,'organisationally_approved'=>(bool)$g->organisationally_approved,
                'governance_allowed'=>(bool)$g->governance_allowed,'risk_allowed'=>(bool)$g->risk_allowed,
                'autonomy_allowed'=>(bool)$g->autonomy_allowed,'final_allowed'=>(bool)$g->final_allowed,
                'effective_autonomy_level'=>$g->effective_autonomy_level,'policy_result'=>$g->policy_result,
                'risk_result'=>$g->risk_result,'autonomy_result'=>$g->autonomy_result,
                'reason_codes'=>$g->reason_codes,'evaluated_at'=>$g->evaluated_at?->toIso8601String(),
            ])->values()->all(),
            'domain_application'=>$attempts->map(fn($a)=>[
                'attempt_uuid'=>$a->attempt_uuid,'worker_member_id'=>$a->worker_member_id,
                'intent_id'=>$a->intent_id,'intent_sha256'=>$a->intent_sha256,
                'idempotency_key'=>$a->idempotency_key,'status'=>$a->status,
                'receipt'=>$a->receipt,'verification'=>$a->verification,'recovery'=>$a->recovery,
                'dispatched_at'=>$a->dispatched_at?->toIso8601String(),
                'verified_at'=>$a->verified_at?->toIso8601String(),
            ])->values()->all(),
            'recovery_plans'=>$recoveryPlans->map(function($plan){
                $steps=WorkforceRecoveryStep::query()->forCompany((int)$plan->company_id)
                    ->where('recovery_plan_id',$plan->getKey())->orderBy('sequence')->get();
                return [
                    'recovery_uuid'=>$plan->recovery_uuid,
                    'trigger_type'=>$plan->trigger_type,
                    'status'=>$plan->status,
                    'step_count'=>$plan->step_count,
                    'verified_step_count'=>$plan->verified_step_count,
                    'manual_intervention_required'=>(bool)$plan->manual_intervention_required,
                    'trigger_evidence'=>$plan->trigger_evidence,
                    'opened_at'=>$plan->opened_at?->toIso8601String(),
                    'completed_at'=>$plan->completed_at?->toIso8601String(),
                    'steps'=>$steps->map(fn($step)=>[
                        'recovery_step_uuid'=>$step->recovery_step_uuid,
                        'sequence'=>$step->sequence,
                        'domain'=>$step->domain,
                        'strategy'=>$step->strategy,
                        'status'=>$step->status,
                        'compensation_capability'=>$step->compensation_capability,
                        'compensation_processing_id'=>$step->compensation_processing_id,
                        'proposed_action'=>$step->proposed_action,
                        'approval_evidence'=>$step->approval_evidence,
                        'receipt_sha256'=>$step->receipt_sha256,
                        'verification_sha256'=>$step->verification_sha256,
                        'failure_reason'=>$step->failure_reason,
                        'verified_at'=>$step->verified_at?->toIso8601String(),
                    ])->values()->all(),
                ];
            })->values()->all(),
            'verified_outcomes'=>$this->verifiedOutcomes($task),
            'reviewer_feedback'=>$feedback->map(fn($f)=>[
                'feedback_uuid'=>$f->feedback_uuid,'stage'=>$f->stage,'reviewer_member_id'=>$f->reviewer_member_id,
                'event_type'=>$f->event_type,'quality_score'=>$f->quality_score,
                'overturned'=>(bool)$f->overturned,'missed_risk'=>(bool)$f->missed_risk,
                'verified_outcome'=>(bool)$f->verified_outcome,'evidence'=>$f->evidence,
                'observed_at'=>$f->observed_at?->toIso8601String(),
            ])->values()->all(),
            'timeline'=>$events,
            'reconstructed_at'=>now()->toIso8601String(),
            'private_reasoning_included'=>false,
        ];
    }

    public function capture(WorkforceDecisionChain $chain,string $type='AUDIT_CHECKPOINT'): WorkforceChainAuditSnapshot
    {
        return DB::transaction(function() use($chain,$type){
            $last=WorkforceChainAuditSnapshot::query()->forCompany((int)$chain->company_id)
                ->where('processing_id',$chain->processing_id)->lockForUpdate()->latest('sequence')->first();
            $sequence=(int)($last?->sequence ?? 0)+1;
            $reconstruction=$this->reconstruct($chain);
            $canonical=$this->canonicalJson($reconstruction);
            $previous=$last?->snapshot_sha256;
            $hash=hash('sha256',($previous ?? '')."\n".$canonical);

            return WorkforceChainAuditSnapshot::query()->create([
                'snapshot_uuid'=>(string)Str::uuid(),'company_id'=>(int)$chain->company_id,
                'decision_chain_id'=>$chain->getKey(),'processing_id'=>$chain->processing_id,
                'task_id'=>$chain->task_id,'snapshot_type'=>$type,'sequence'=>$sequence,
                'previous_sha256'=>$previous,'snapshot_sha256'=>$hash,
                'reconstruction'=>$reconstruction,'captured_at'=>now(),
            ]);
        },3);
    }

    /** @return array<string,mixed> */
    public function verifySnapshot(WorkforceChainAuditSnapshot $snapshot): array
    {
        $previous=$snapshot->sequence>1
            ? WorkforceChainAuditSnapshot::query()->forCompany((int)$snapshot->company_id)
                ->where('processing_id',$snapshot->processing_id)->where('sequence',$snapshot->sequence-1)->first()
            : null;
        $expected=hash('sha256',($previous?->snapshot_sha256 ?? '')."\n".$this->canonicalJson((array)$snapshot->reconstruction));
        return [
            'valid'=>hash_equals((string)$snapshot->snapshot_sha256,$expected),
            'sequence'=>(int)$snapshot->sequence,
            'previous_link_valid'=>$snapshot->sequence===1 || ($previous && $snapshot->previous_sha256===$previous->snapshot_sha256),
            'snapshot_sha256'=>$snapshot->snapshot_sha256,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function verifiedOutcomes(WorkforceTask $task): array
    {
        $gov=(array)($task->governance ?? []);
        $out=[];
        if(is_array($gov['post_execution'] ?? null) && ($gov['post_execution']['verified'] ?? false)===true){
            $out[]=$gov['post_execution'];
        }
        foreach((array)($gov['verified_external_outcomes'] ?? []) as $row){
            if(is_array($row)) $out[]=$row;
        }
        return $out;
    }

    private function json(mixed $value): mixed
    {
        if(!is_string($value)) return $value;
        $decoded=json_decode($value,true);
        return json_last_error()===JSON_ERROR_NONE ? $decoded : $value;
    }

    private function canonicalJson(array $value): string
    {
        $normalize=function($v) use (&$normalize){
            if(!is_array($v)) return $v;
            if(array_is_list($v)) return array_map($normalize,$v);
            ksort($v,SORT_STRING);
            foreach($v as $k=>$x) $v[$k]=$normalize($x);
            return $v;
        };
        return json_encode($normalize($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION);
    }
}
