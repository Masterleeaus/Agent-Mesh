<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceWorkloadSnapshot;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceManagerCoordinationService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforceProviderRoutingService $routing,
    ) {}

    /** @return array<string,mixed> */
    public function workload(WorkforceMember $member): array
    {
        $query = WorkforceTask::query()->forCompany((int) $member->company_id)
            ->where('assignee_member_id', $member->id)
            ->whereNotIn('status', [
                WorkforceTaskStatus::Completed->value,
                WorkforceTaskStatus::Failed->value,
                WorkforceTaskStatus::Cancelled->value,
            ]);

        $items = $query->get();
        $open = $items->count();
        $blocked = $items->where('blocked_by_graph', true)->count();
        $critical = $items->where('critical_path', true)->count();
        $estimated = (int) $items->sum(fn ($t) => (int) ($t->estimated_minutes ?? 0));
        $overdue = $items->filter(fn ($t) => $t->deadline_at && $t->deadline_at->isPast())->count();
        $capacity = max(1, (int) ($member->max_concurrent_tasks ?? 5));
        $score = min(100, (int) round(($open / $capacity) * 70) + min(20, $blocked * 5) + min(10, $overdue * 5));
        $state = $score >= 90 ? 'OVERLOADED' : ($score >= 70 ? 'HIGH' : ($score >= 40 ? 'BALANCED' : 'AVAILABLE'));

        WorkforceWorkloadSnapshot::query()->create([
            'company_id' => (int) $member->company_id,
            'member_id' => (int) $member->id,
            'open_work_items' => $open,
            'blocked_work_items' => $blocked,
            'critical_path_work_items' => $critical,
            'estimated_minutes' => $estimated,
            'overdue_work_items' => $overdue,
            'load_score' => $score,
            'state' => $state,
            'details' => ['max_concurrent_tasks'=>$capacity,'authority_inherited'=>false],
            'observed_at' => now(),
        ]);

        return compact('open','blocked','critical','estimated','overdue','score','state') + [
            'member_id'=>(int)$member->id,
            'company_id'=>(int)$member->company_id,
            'max_concurrent_tasks'=>$capacity,
            'authority_inherited'=>false,
        ];
    }

    /** @return list<array<string,mixed>> */
    public function teamSnapshot(WorkforceMember $manager): array
    {
        $this->assertManager($manager);
        $members = WorkforceMember::query()->forCompany((int) $manager->company_id)
            ->where('manager_id', $manager->id)->where('is_active', true)->orderBy('id')->get();

        return $members->map(fn (WorkforceMember $member) => [
            'member_id'=>(int)$member->id,
            'role_definition_id'=>(string)$member->role_definition_id,
            'workload'=>$this->workload($member),
        ])->values()->all();
    }

    public function delegate(
        WorkforceTask $task,
        WorkforceMember $manager,
        WorkforceMember $assignee,
        string $reason,
        bool $reviewRequired = true,
        ?WorkforceDelegation $parentDelegation = null,
    ): WorkforceDelegation {
        $this->assertManager($manager);
        $this->assertCoordinatable($manager, $assignee);
        if ((int)$task->company_id !== (int)$manager->company_id || (int)$task->company_id !== (int)$assignee->company_id) {
            throw new InvalidArgumentException('Cross-company delegation rejected.');
        }
        if ($task->status->terminal()) throw new InvalidArgumentException('Terminal Work Item cannot be delegated.');
        if (! $task->work_item_uuid || ! $task->responsibility_id) {
            throw new InvalidArgumentException('Manager coordination delegates canonical Work Items only.');
        }

        $requirement = $this->requirements->forResponsibility((string)$task->responsibility_id);
        if (!is_array($requirement) || (string)($requirement['role_definition_id'] ?? '') !== (string)$assignee->role_definition_id) {
            throw new InvalidArgumentException('Delegate does not own the Work Item responsibility.');
        }
        $capability = trim((string)$task->capability);
        if ($capability === '' || !in_array($capability, (array)($requirement['candidate_capabilities'] ?? []), true)) {
            throw new InvalidArgumentException('Delegated capability is outside the responsibility contract.');
        }
        $route = $this->routing->assertExecutableRoute(
            $assignee,
            $capability,
            'capability',
            trim((string)($task->capability_owner_extension ?? '')) ?: null,
        );

        $depth = $parentDelegation ? ((int)$parentDelegation->chain_depth + 1) : 1;
        if ($depth > 5) throw new InvalidArgumentException('Delegation chain depth limit exceeded.');

        return DB::transaction(function () use ($task,$manager,$assignee,$reason,$reviewRequired,$parentDelegation,$route,$depth,$capability): WorkforceDelegation {
            $delegation = WorkforceDelegation::query()->create([
                'delegation_uuid'=>(string)Str::uuid(),
                'company_id'=>(int)$task->company_id,
                'task_id'=>(int)$task->id,
                'responsibility_id'=>(string)$task->responsibility_id,
                'capability'=>$capability,
                'from_member_id'=>(int)$manager->id,
                'to_member_id'=>(int)$assignee->id,
                'delegation_type'=>'WORK_ITEM',
                'status'=>'ACTIVE',
                'authority_scope'=>[
                    'responsibility_id'=>(string)$task->responsibility_id,
                    'capability'=>$capability,
                    'provider'=>(string)($route['selected_provider'] ?? ''),
                    'provider_version'=>(string)($route['selected_provider_version'] ?? ''),
                    'delegator_may_expand_authority'=>false,
                    'authority_inherited'=>false,
                    'execution_authority_granted'=>false,
                ],
                'reason'=>$reason,
                'review_required'=>$reviewRequired,
                'reviewer_member_id'=>$reviewRequired ? (int)$manager->id : null,
                'review_status'=>$reviewRequired ? 'PENDING' : 'NOT_REQUIRED',
                'chain_depth'=>$depth,
                'parent_delegation_id'=>$parentDelegation?->id,
                'metadata'=>[
                    'previous_assignee_member_id'=>$task->assignee_member_id,
                    'delegation_grants_authority'=>false,
                    'provider_route_pinned'=>true,
                ],
            ]);

            $old=(int)($task->assignee_member_id ?? 0);
            $task->forceFill([
                'assignee_member_id'=>(int)$assignee->id,
                'manager_member_id'=>(int)$manager->id,
                'capability_owner_extension'=>(string)($route['selected_provider'] ?? ''),
                'capability_owner_extension_version'=>(string)($route['selected_provider_version'] ?? ''),
            ])->save();
            $this->tasks->record($task,$manager,'work_item.delegated',$task->status->value,$task->status->value,$reason,[
                'delegation_uuid'=>(string)$delegation->delegation_uuid,
                'previous_assignee_member_id'=>$old,
                'new_assignee_member_id'=>(int)$assignee->id,
                'authority_inherited'=>false,
            ]);
            return $delegation;
        });
    }

    public function review(WorkforceDelegation $delegation, WorkforceMember $reviewer, bool $approved, ?string $reason = null): WorkforceDelegation
    {
        if ((int)$delegation->company_id !== (int)$reviewer->company_id) throw new InvalidArgumentException('Cross-company review rejected.');
        if ((int)($delegation->reviewer_member_id ?? 0) !== (int)$reviewer->id) throw new InvalidArgumentException('Only assigned delegation reviewer may review.');
        if ($delegation->review_status !== 'PENDING') throw new InvalidArgumentException('Delegation review is already resolved.');

        $delegation->forceFill([
            'review_status'=>$approved ? 'APPROVED' : 'REJECTED',
            'status'=>$approved ? 'ACTIVE' : 'REVOKED',
            'reviewed_at'=>now(),
            'completed_at'=>$approved ? null : now(),
            'metadata'=>array_merge((array)$delegation->metadata,[
                'review_reason'=>$reason,
                'reviewed_by'=>(int)$reviewer->id,
                'review_grants_authority'=>false,
            ]),
        ])->save();

        return $delegation->refresh();
    }

    /** @return array<string,mixed>|null */
    public function rebalance(WorkforceTask $task, WorkforceMember $manager): ?array
    {
        $this->assertManager($manager);
        if ((int)$task->company_id !== (int)$manager->company_id) throw new InvalidArgumentException('Cross-company rebalance rejected.');
        $current = $task->assignee_member_id
            ? WorkforceMember::query()->forCompany((int)$manager->company_id)->find((int)$task->assignee_member_id)
            : null;
        if (!$current) return null;

        $candidates = WorkforceMember::query()->forCompany((int)$manager->company_id)
            ->where('manager_id',$manager->id)->where('is_active',true)
            ->where('role_definition_id',$current->role_definition_id)
            ->whereKeyNot($current->id)->get();

        $best=null;$bestLoad=null;
        foreach ($candidates as $candidate) {
            $load=$this->workload($candidate);
            if ($best===null || $load['score'] < $bestLoad['score']) { $best=$candidate;$bestLoad=$load; }
        }
        $currentLoad=$this->workload($current);
        if (!$best || $bestLoad['score'] >= $currentLoad['score']) return null;

        $delegation=$this->delegate($task,$manager,$best,'Manager workload rebalance.',true);
        return [
            'delegation_uuid'=>(string)$delegation->delegation_uuid,
            'from_member_id'=>(int)$current->id,
            'to_member_id'=>(int)$best->id,
            'from_load'=>$currentLoad,
            'to_load'=>$bestLoad,
            'authority_inherited'=>false,
        ];
    }

    private function assertManager(WorkforceMember $manager): void
    {
        if (!$manager->is_active) throw new InvalidArgumentException('Manager must be active.');
        if ($manager->reports()->count()===0 && !str_contains(strtolower((string)$manager->role_definition_id),'manager') && !$manager->is_permanent_system_role) {
            throw new InvalidArgumentException('Workforce member is not a coordinating manager.');
        }
    }

    private function assertCoordinatable(WorkforceMember $manager, WorkforceMember $assignee): void
    {
        if ((int)$manager->company_id !== (int)$assignee->company_id) throw new InvalidArgumentException('Cross-company coordination rejected.');
        $current=$assignee;$visited=[];
        for ($depth=0;$depth<20 && $current->manager_id;$depth++) {
            $id=(int)$current->manager_id;
            if(isset($visited[$id])) break;
            $visited[$id]=true;
            if($id===(int)$manager->id) return;
            $current=WorkforceMember::query()->forCompany((int)$manager->company_id)->find($id);
            if(!$current) break;
        }
        throw new InvalidArgumentException('Assignee is outside the manager coordination chain.');
    }
}
