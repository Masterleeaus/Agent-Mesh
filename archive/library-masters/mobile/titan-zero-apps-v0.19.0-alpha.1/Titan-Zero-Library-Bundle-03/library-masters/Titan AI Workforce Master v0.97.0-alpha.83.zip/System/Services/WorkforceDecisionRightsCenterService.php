<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;

/**
 * Company-scoped, read-only Decision Rights & RACI Center projection.
 *
 * Organisational participation never grants executable capability or authority.
 */
final class WorkforceDecisionRightsCenterService
{
    public function __construct(private readonly WorkforceDecisionRightsService $decisionRights) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->orderBy('name')->get();
        $membersByRole = $members->groupBy(fn (WorkforceMember $member): string => (string) $member->role_definition_id);
        $roles = WorkforceRoleRegistry::keyed();
        $roleById = [];
        foreach ($roles as $role) $roleById[(string) ($role['role_definition_id'] ?? '')] = $role;

        $rows = [];
        foreach ($this->decisionRights->all() as $right) {
            $row = $right;
            foreach (['responsible','accountable','consulted','informed','reviewer','escalation_owner'] as $field) {
                $row[$field] = $this->participants((array) ($right[$field] ?? []), $membersByRole, $roleById);
            }
            $row['human_required'] = (bool) ($right['human_required'] ?? false);
            $row['authority_inherited'] = false;
            $row['execution_authority_granted'] = false;
            $rows[] = $row;
        }

        $views = [
            'responsible' => $rows,
            'accountable' => $rows,
            'consulted' => array_values(array_filter($rows, fn (array $r): bool => $r['consulted'] !== [])),
            'informed' => array_values(array_filter($rows, fn (array $r): bool => $r['informed'] !== [])),
            'reviewer' => array_values(array_filter($rows, fn (array $r): bool => $r['reviewer'] !== [])),
            'escalation_owner' => array_values(array_filter($rows, fn (array $r): bool => $r['escalation_owner'] !== [])),
            'human_required' => array_values(array_filter($rows, fn (array $r): bool => $r['human_required'])),
        ];

        return [
            'rows' => $rows,
            'views' => $views,
            'counts' => array_map('count', $views),
            'canonical_count' => count(array_filter($rows, fn (array $r): bool => ($r['source'] ?? '') === 'canonical_workforce_policy')),
            'extension_count' => count(array_filter($rows, fn (array $r): bool => ($r['source'] ?? '') !== 'canonical_workforce_policy')),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @param list<string> $roleIds @param mixed $membersByRole @param array<string,array> $roleById @return list<array<string,mixed>> */
    private function participants(array $roleIds, $membersByRole, array $roleById): array
    {
        $out = [];
        foreach ($roleIds as $roleId) {
            $roleId = (string) $roleId;
            $role = $roleById[$roleId] ?? null;
            $assigned = $membersByRole->get($roleId, collect());
            $out[] = [
                'role_definition_id' => $roleId,
                'role_name' => (string) ($role['name'] ?? $roleId),
                'members' => $assigned->map(fn (WorkforceMember $m): array => [
                    'id' => $m->id,
                    'name' => $m->name,
                    'active' => (bool) $m->is_active,
                    'url' => route('dashboard.user.titan-workforce.staff.show', $m),
                ])->values()->all(),
            ];
        }
        return $out;
    }
}
