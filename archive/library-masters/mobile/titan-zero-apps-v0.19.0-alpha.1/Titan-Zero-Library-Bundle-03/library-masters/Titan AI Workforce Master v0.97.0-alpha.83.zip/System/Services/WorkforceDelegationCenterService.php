<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;

/**
 * Company-scoped, read-only delegation projection.
 * Delegation expresses organisational work scope only. It never grants executable capability.
 */
final class WorkforceDelegationCenterService
{
    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $delegations = WorkforceDelegation::query()->forCompany($companyId)->orderByDesc('created_at')->limit(500)->get();
        $memberIds = $delegations->flatMap(fn (WorkforceDelegation $d): array => [(int)$d->from_member_id,(int)$d->to_member_id])->filter()->unique()->values();
        $members = WorkforceMember::query()->forCompany($companyId)->whereIn('id', $memberIds)->get()->keyBy('id');
        $taskIds = $delegations->pluck('task_id')->filter()->map(fn ($id): int => (int)$id)->unique()->values();
        $tasks = WorkforceTask::query()->forCompany($companyId)->whereIn('id', $taskIds)->get()->keyBy('id');

        $rows = $delegations->map(fn (WorkforceDelegation $d): array => $this->row($d, $members, $tasks))->values();
        return [
            'rows' => $rows,
            'views' => [
                'all' => $rows,
                'active' => $rows->where('effective_status', 'ACTIVE')->values(),
                'expired' => $rows->where('effective_status', 'EXPIRED')->values(),
                'revoked' => $rows->where('effective_status', 'REVOKED')->values(),
            ],
            'counts' => [
                'all' => $rows->count(),
                'active' => $rows->where('effective_status', 'ACTIVE')->count(),
                'expired' => $rows->where('effective_status', 'EXPIRED')->count(),
                'revoked' => $rows->where('effective_status', 'REVOKED')->count(),
            ],
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @param Collection<int,WorkforceMember> $members @param Collection<int,WorkforceTask> $tasks @return array<string,mixed> */
    private function row(WorkforceDelegation $delegation, Collection $members, Collection $tasks): array
    {
        $task = $delegation->task_id ? $tasks->get((int)$delegation->task_id) : null;
        $metadata = (array)($delegation->metadata ?? []);
        $scope = (array)($delegation->authority_scope ?? []);
        $status = strtoupper((string)$delegation->status);
        if ($status !== 'REVOKED' && $delegation->expires_at?->isPast()) $status = 'EXPIRED';
        elseif (! in_array($status, ['ACTIVE','EXPIRED','REVOKED'], true)) $status = $delegation->completed_at ? 'EXPIRED' : 'ACTIVE';

        $responsibility = (string)(data_get($metadata, 'responsibility')
            ?? data_get($task?->metadata ?? [], 'responsibility_key')
            ?? data_get($task?->payload ?? [], 'responsibility_key')
            ?? data_get($task?->metadata ?? [], 'responsibility_id')
            ?? 'Task-scoped governed work');
        $workScope = (array)($scope['capabilities'] ?? []);
        if ($workScope === [] && $task?->capability) $workScope[] = (string)$task->capability;

        $audit = array_values((array)data_get($metadata, 'audit_history', []));
        if ($audit === []) {
            $audit[] = ['event'=>'delegation.created','at'=>$delegation->created_at?->toIso8601String(),'actor_member_id'=>$delegation->from_member_id,'reason'=>$delegation->reason];
        }

        return [
            'id' => (int)$delegation->id,
            'delegation_uuid' => (string)$delegation->delegation_uuid,
            'delegator' => $this->member($members->get((int)$delegation->from_member_id)),
            'delegate' => $this->member($members->get((int)$delegation->to_member_id)),
            'responsibility' => $responsibility,
            'work_scope' => $workScope,
            'start_at' => $delegation->created_at?->toIso8601String(),
            'end_at' => $delegation->expires_at?->toIso8601String() ?? $delegation->completed_at?->toIso8601String(),
            'active' => $status === 'ACTIVE',
            'expired' => $status === 'EXPIRED',
            'revoked' => $status === 'REVOKED',
            'effective_status' => $status,
            'related_tasks' => $task ? [[
                'id'=>(int)$task->id,
                'task_uuid'=>(string)$task->task_uuid,
                'title'=>(string)$task->title,
                'status'=>is_object($task->status) ? $task->status->value : (string)$task->status,
                'url'=>route('dashboard.user.titan-workforce.tasks.show', $task),
            ]] : [],
            'authority_boundary' => [
                'authority_inherited' => false,
                'execution_authority_granted' => false,
                'delegator_may_expand_authority' => false,
                'requires_fresh_execution_authorization' => true,
                'note' => 'Delegation never grants executable capability. The delegated task must independently pass capability availability, Risk, Assurance, Governance and Titan Autonomy checks.',
            ],
            'reason' => (string)($delegation->reason ?? ''),
            'audit_history' => $audit,
        ];
    }

    /** @return array<string,mixed>|null */
    private function member(?WorkforceMember $member): ?array
    {
        if (! $member) return null;
        return ['id'=>(int)$member->id,'name'=>(string)$member->name,'role_definition_id'=>(string)$member->role_definition_id,'url'=>route('dashboard.user.titan-workforce.staff.show',$member)];
    }
}
