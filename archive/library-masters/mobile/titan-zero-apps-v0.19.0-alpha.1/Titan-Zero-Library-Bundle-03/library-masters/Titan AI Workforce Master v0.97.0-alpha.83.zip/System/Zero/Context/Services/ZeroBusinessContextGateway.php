<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Context\Services;

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceBusinessContextSourceCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceContextFederationProfiles;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextGatewayContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextReaderContract;
use InvalidArgumentException;
use RuntimeException;

/**
 * Unified read-only business-context gateway for Zero.
 *
 * This service exposes provider-owned truth without copying it into Workforce or
 * NEXUS. It validates company scope, actor identity, purpose, sensitivity and
 * the declared provider/version/surface route before delegating to an existing
 * context adapter. Context access is informational only and can never grant
 * execution authority.
 */
final class ZeroBusinessContextGateway implements ZeroBusinessContextGatewayContract
{
    /** @var array<string,array<string,mixed>>|null */
    private ?array $sourceIndex = null;

    public function __construct(
        private readonly WorkforceBusinessContextSourceCatalog $catalog,
        private readonly ZeroBusinessContextReaderContract $reader,
        private readonly WorkforceContextFederationProfiles $profiles,
    ) {}

    /** @return array<string,mixed> */
    public function plan(
        int $companyId,
        string $actorId,
        string $purpose,
        array $criteria = [],
    ): array {
        $this->assertIdentity($companyId, $actorId, $purpose);

        $surfaceIds = $this->normaliseList((array) ($criteria['surface_ids'] ?? []), false);
        $providers = $this->normaliseList((array) ($criteria['providers'] ?? []));
        $domains = $this->normaliseList((array) ($criteria['domains'] ?? []));
        $businessDomains = $this->normaliseList((array) ($criteria['business_domains'] ?? []));
        $blockedSensitivity = $this->normaliseList((array) ($criteria['blocked_context_sensitivity'] ?? []));
        $includeUnroutable = ($criteria['include_unroutable'] ?? true) !== false;
        $limit = max(1, min(500, (int) ($criteria['limit'] ?? 200)));

        $sources = [];
        $index = $this->sources();
        foreach ($index as $source) {
            $surfaceId = trim((string) ($source['id'] ?? ''));
            $domain = strtolower(trim((string) ($source['domain'] ?? 'operations')));
            $sensitivity = strtolower(trim((string) ($source['sensitivity'] ?? 'internal')));
            $access = strtolower(trim((string) ($source['access'] ?? 'read_only')));
            $businessDomain = $this->businessDomain($source);

            if ($surfaceId === '' || $access !== 'read_only') continue;
            if ($surfaceIds !== [] && ! in_array($surfaceId, $surfaceIds, true)) continue;
            if ($domains !== [] && ! in_array($domain, $domains, true)) continue;
            if ($businessDomains !== [] && ! in_array($businessDomain, $businessDomains, true)) continue;
            if ($blockedSensitivity !== [] && in_array($sensitivity, $blockedSensitivity, true)) continue;

            $routes = $this->routesForSource($source, $providers);
            $routable = $routes !== [];
            if (! $routable && ! $includeUnroutable) continue;

            $declaredProviders = [];
            foreach ((array) ($source['providers'] ?? []) as $provider) {
                if (! is_array($provider)) continue;
                $key = strtolower(trim((string) ($provider['provider'] ?? '')));
                if ($key !== '') $declaredProviders[] = $key;
            }
            $declaredProviders = array_values(array_unique($declaredProviders));
            sort($declaredProviders);

            $sources[] = [
                'surface_id' => $surfaceId,
                'domain' => $domain,
                'business_domain' => $businessDomain,
                'sensitivity' => $sensitivity,
                'access' => 'read_only',
                'declared_providers' => $declaredProviders,
                'routes' => $routes,
                'routable' => $routable,
                'state' => $routable ? 'route_configured' : 'unrouted',
                'runtime_data_availability_confirmed' => false,
                'purpose' => $purpose,
                'company_id' => $companyId,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ];
            if (count($sources) >= $limit) break;
        }

        return [
            'schema' => 'titan.zero.business-context-plan.v1',
            'company_id' => $companyId,
            'actor_id' => trim($actorId),
            'purpose' => trim($purpose),
            'indexed_source_count' => count($index),
            'source_count' => count($sources),
            'routable_source_count' => count(array_filter($sources, static fn (array $source): bool => ($source['routable'] ?? false) === true)),
            'sources' => $sources,
            'read_only' => true,
            'domain_truth_preserved' => true,
            'context_is_informational' => true,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
            'fresh_governance_required_before_execution' => true,
        ];
    }

    /** @return array<string,mixed> */
    public function read(
        int $companyId,
        string $actorId,
        string $surfaceId,
        string $purpose,
        array $filters = [],
        int $limit = 50,
        ?string $requestedProvider = null,
        array $policy = [],
    ): array {
        $this->assertIdentity($companyId, $actorId, $purpose);
        $surfaceId = trim($surfaceId);
        if ($surfaceId === '') throw new InvalidArgumentException('Zero business-context surface_id is required.');
        $limit = max(1, min($limit, 200));

        $source = $this->sources()[$surfaceId] ?? null;
        if (! is_array($source) || strtolower((string) ($source['access'] ?? 'read_only')) !== 'read_only') {
            throw new InvalidArgumentException('Requested Zero business-context surface is not a declared read-only source.');
        }
        $sensitivity = strtolower(trim((string) ($source['sensitivity'] ?? 'internal')));
        $blocked = $this->normaliseList((array) ($policy['blocked_context_sensitivity'] ?? []));
        if ($blocked !== [] && in_array($sensitivity, $blocked, true)) {
            throw new RuntimeException('Zero business-context policy blocks this source sensitivity.');
        }

        $providerFilter = [];
        if ($requestedProvider !== null && trim($requestedProvider) !== '') {
            $providerFilter[] = strtolower(trim($requestedProvider));
        } elseif (isset($policy['preferred_providers']) && is_array($policy['preferred_providers'])) {
            $providerFilter = $this->normaliseList($policy['preferred_providers']);
        }

        $routes = $this->routesForSource($source, []);
        $route = $this->selectRoute($routes, $providerFilter);
        if (! is_array($route)) {
            throw new RuntimeException('No deterministic live read provider is available for this Zero business-context surface.');
        }

        $safeFilters = $this->stripIdentityFilters($filters);
        $result = $this->reader->read(
            $companyId,
            (string) $route['provider'],
            (string) $route['provider_version'],
            $surfaceId,
            $safeFilters,
            $limit,
        );

        if (! is_array($result)
            || (int) ($result['company_id'] ?? 0) !== $companyId
            || (string) ($result['surface_id'] ?? '') !== $surfaceId
            || ! is_array($result['items'] ?? null)) {
            throw new RuntimeException('Zero business-context provider returned an invalid or cross-company envelope.');
        }

        $result['actor_id'] = trim($actorId);
        $result['purpose'] = trim($purpose);
        $result['provider'] = (string) $route['provider'];
        $result['provider_version'] = (string) $route['provider_version'];
        $result['domain'] = (string) ($source['domain'] ?? 'operations');
        $result['business_domain'] = $this->businessDomain($source);
        $result['sensitivity'] = $sensitivity;
        $result['read_only'] = true;
        $result['domain_truth_preserved'] = true;
        $result['context_is_informational'] = true;
        $result['authority_inherited'] = false;
        $result['execution_authority_granted'] = false;
        $result['runtime_data_availability_confirmed'] = true;
        $result['fresh_governance_required_before_execution'] = true;
        return $result;
    }

    /** @return array<string,array<string,mixed>> */
    private function sources(): array
    {
        if ($this->sourceIndex !== null) return $this->sourceIndex;

        $index = [];
        foreach ((array) ($this->catalog->all()['sources'] ?? []) as $source) {
            if (! is_array($source)) continue;
            $id = trim((string) ($source['id'] ?? ''));
            if ($id === '') continue;
            $source['source_origin'] = 'capability-derived-catalogue';
            $index[$id] = $source;
        }

        foreach ((array) ($this->profiles->all()['profiles'] ?? []) as $profile) {
            if (! is_array($profile)
                || ($profile['tenant_boundary'] ?? null) !== 'company_id'
                || ($profile['writes_allowed'] ?? true) !== false) continue;
            $providerKey = strtolower(trim((string) ($profile['provider'] ?? '')));
            $providerVersion = trim((string) ($profile['provider_version'] ?? ''));
            if ($providerKey === '' || $providerVersion === '') continue;

            foreach ((array) ($profile['routes'] ?? []) as $surfaceId => $route) {
                $surfaceId = trim((string) $surfaceId);
                if ($surfaceId === '' || isset($index[$surfaceId])) continue;
                $index[$surfaceId] = [
                    'id' => $surfaceId,
                    'domain' => $this->providerDomain($providerKey, $surfaceId),
                    'sensitivity' => 'internal',
                    'access' => 'read_only',
                    'providers' => [[
                        'provider' => $providerKey,
                        'provider_version' => $providerVersion,
                        'mode' => 'read',
                        'authority' => 'informational',
                        'source' => 'context-federation-profile',
                    ]],
                    'purpose_required' => true,
                    'company_scope_required' => true,
                    'authority_inherited' => false,
                    'execution_authority_granted' => false,
                    'source_origin' => 'context-federation-profile',
                ];
            }
        }
        ksort($index);
        return $this->sourceIndex = $index;
    }

    /** @param array<string,mixed> $source */
    private function businessDomain(array $source): string
    {
        $surfaceId = strtolower(trim((string) ($source['id'] ?? '')));
        $provider = '';
        foreach ((array) ($source['providers'] ?? []) as $candidate) {
            if (! is_array($candidate)) continue;
            $provider = strtolower(trim((string) ($candidate['provider'] ?? '')));
            if ($provider !== '') break;
        }
        if (str_starts_with($surfaceId, 'onboarding.nexus.')) return 'nexus';
        return $this->providerDomain($provider, $surfaceId);
    }

    private function providerDomain(string $provider, string $surfaceId): string
    {
        return match (true) {
            $provider === 'titan-nexus' => 'nexus',
            $provider === 'onboarding-pro' && str_contains($surfaceId, 'nexus') => 'nexus',
            $provider === 'crm' => 'customer',
            $provider === 'titan-bookings-quotes', $provider === 'titan-field', $provider === 'titan-maps-intelligence' => 'work',
            $provider === 'titan-ledger', $provider === 'titan-financial-engine' => 'finance',
            $provider === 'titan-people', $provider === 'titan-payroll', $provider === 'titan-time-attendance' => 'people',
            $provider === 'titan-omnichannel', $provider === 'titan-connect' => 'customer',
            str_starts_with($provider, 'titan-reach-') => 'growth',
            $provider === 'titan-assets' => 'assets',
            in_array($provider, ['titan-governance','titan-assurance','titan-shield','titan-trust'], true) => 'risk',
            $provider === 'titan-signal-engine' => 'signals',
            $provider === 'titan-knowledge-authority' => 'knowledge',
            $provider === 'titan-rewind' => 'evidence',
            default => strtolower(trim((string) (($this->catalog->source($surfaceId)['domain'] ?? 'operations')))) ?: 'operations',
        };
    }

    /** @param array<string,mixed> $source @param list<string> $providerFilter @return list<array<string,string>> */
    private function routesForSource(array $source, array $providerFilter): array
    {
        $routes = [];
        foreach ((array) ($source['providers'] ?? []) as $provider) {
            if (! is_array($provider)) continue;
            $mode = strtolower(trim((string) ($provider['mode'] ?? 'read')));
            if ($mode !== 'read') continue;
            $providerKey = strtolower(trim((string) ($provider['provider'] ?? '')));
            $providerVersion = trim((string) ($provider['provider_version'] ?? ''));
            $surfaceId = trim((string) ($source['id'] ?? ''));
            if ($providerKey === '' || $providerVersion === '' || $surfaceId === '') continue;
            if ($providerFilter !== [] && ! in_array($providerKey, $providerFilter, true)) continue;
            if (! $this->reader->supports($providerKey, $providerVersion, $surfaceId)) continue;

            $routes[$providerKey.'@'.$providerVersion] = [
                'provider' => $providerKey,
                'provider_version' => $providerVersion,
                'surface_id' => $surfaceId,
                'authority' => strtolower(trim((string) ($provider['authority'] ?? 'informational'))),
                'source' => (string) ($provider['source'] ?? 'declared'),
            ];
        }
        ksort($routes);
        return array_values($routes);
    }

    /** @param list<array<string,string>> $routes @param list<string> $preference */
    private function selectRoute(array $routes, array $preference): ?array
    {
        if ($routes === []) return null;
        if ($preference !== []) {
            foreach ($preference as $provider) {
                $matches = array_values(array_filter($routes, static fn (array $route): bool =>
                    (string) ($route['provider'] ?? '') === $provider
                ));
                if (count($matches) === 1) return $matches[0];
            }
            return null;
        }
        return count($routes) === 1 ? $routes[0] : null;
    }

    private function assertIdentity(int $companyId, string $actorId, string $purpose): void
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Zero business-context access requires company_id.');
        if (trim($actorId) === '') throw new InvalidArgumentException('Zero business-context access requires actor_id.');
        if (trim($purpose) === '') throw new InvalidArgumentException('Zero business-context access requires an explicit purpose.');
    }

    /** @param array<string,mixed> $filters @return array<string,mixed> */
    private function stripIdentityFilters(array $filters): array
    {
        foreach (array_keys($filters) as $key) {
            $normalised = strtolower((string) $key);
            if ($normalised === 'company_id') {
                unset($filters[$key]);
            }
        }
        return $filters;
    }

    /** @param array<mixed> $values @return list<string> */
    private function normaliseList(array $values, bool $lower = true): array
    {
        $out = [];
        foreach ($values as $value) {
            $value = trim((string) $value);
            if ($value === '') continue;
            $out[] = $lower ? strtolower($value) : $value;
        }
        $out = array_values(array_unique($out));
        sort($out);
        return $out;
    }
}
