<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services;

/**
 * Non-mutating compatibility classifier for the existing Workforce conversation vocabulary.
 * This is intentionally narrow. Later Zero passes add semantic/multi-intent intelligence above it.
 */
final class ZeroBaselineIntentClassifier
{
    public function __construct(private readonly ?object $interaction = null) {}

    /** @return array<string,mixed> */
    public function classify(string $message, array $trustedContext = []): array
    {
        if ($this->interaction !== null && method_exists($this->interaction, 'interpret') && trim($message) !== '') {
            try {
                $interpreted = $this->interaction->interpret($message, $trustedContext);
                if ((string)($interpreted['intent'] ?? 'unknown') !== 'unknown') {
                    return [
                        'intent' => (string)$interpreted['intent'],
                        'confidence' => (float)($interpreted['confidence'] ?? 0.0),
                        'recognized' => (bool)($interpreted['recognized'] ?? true),
                        'matched_by' => 'interaction-engine',
                        'alternatives' => is_array($interpreted['alternatives'] ?? null) ? $interpreted['alternatives'] : [],
                        'entities' => is_array($interpreted['entities'] ?? null) ? $interpreted['entities'] : [],
                        'parameters' => [],
                        'classifier' => (string)($interpreted['classification_source'] ?? 'interaction-engine'),
                        'mutated' => false,
                        'authority_inherited' => false,
                        'execution_authority_granted' => false,
                    ];
                }
            } catch (\Throwable) {
                // Compatibility/offline fallback below. Interpretation may never block Workforce availability.
            }
        }
        $message = trim($message);
        if ($message === '') {
            return $this->result('help', 0.20, false, 'empty_input');
        }

        if (preg_match('/^ask\s+(.+?)\s+to\s+(.+)$/i', $message, $m) === 1) {
            return $this->result('create_governed_work_item', 0.99, true, 'legacy_workforce_command', [
                'target' => trim($m[1]),
                'instruction' => trim($m[2]),
            ]);
        }

        $lower = strtolower($message);
        if (str_contains($lower, 'degraded') || str_contains($lower, 'unavailable') || str_contains($lower, 'missing provider')) {
            return $this->result('degraded_employees', 0.80, true, 'legacy_keyword');
        }
        if (str_contains($lower, 'approval') || str_contains($lower, 'review')) {
            return $this->result('work_awaiting_approval', 0.80, true, 'legacy_keyword');
        }
        if ((str_contains($lower, 'what') && (str_contains($lower, 'workforce') || str_contains($lower, 'team'))) || str_contains($lower, 'working on')) {
            return $this->result('workforce_health', 0.80, true, 'legacy_keyword');
        }

        return $this->result('help', 0.20, false, 'legacy_fallback');
    }

    /** @param array<string,mixed> $entities */
    private function result(string $intent, float $confidence, bool $recognized, string $matchedBy, array $entities = []): array
    {
        return [
            'intent' => $intent,
            'confidence' => $confidence,
            'recognized' => $recognized,
            'matched_by' => $matchedBy,
            'alternatives' => [],
            'entities' => $entities,
            'parameters' => [],
            'classifier' => 'workforce-baseline-v1',
            'mutated' => false,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }
}
