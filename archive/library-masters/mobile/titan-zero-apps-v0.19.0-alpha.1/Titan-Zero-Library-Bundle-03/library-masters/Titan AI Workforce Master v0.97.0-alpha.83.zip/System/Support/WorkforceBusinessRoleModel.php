<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class WorkforceBusinessRoleModel
{
    private ?array $model = null;

    public function all(): array
    {
        return $this->model ??= $this->load('business-role-responsibility-model.json');
    }

    public function families(): array
    {
        return $this->all()['role_families'] ?? [];
    }

    public function roles(): array
    {
        return $this->all()['roles'] ?? [];
    }

    public function role(string $roleDefinitionId): ?array
    {
        foreach ($this->roles() as $role) {
            if (($role['role_definition_id'] ?? null) === $roleDefinitionId) {
                return $role;
            }
        }

        return null;
    }

    private function load(string $file): array
    {
        $path = dirname(__DIR__, 2).'/resources/workforce/'.$file;
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);

        return is_array($decoded) ? $decoded : [];
    }
}
