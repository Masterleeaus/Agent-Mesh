<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberLifecycleState;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkforceMember extends Model
{
    use SoftDeletes;
    protected $table = 'ext_titan_ai_workforce_members';
    protected $guarded = [];
    protected $casts = [
        'tier' => WorkforceTier::class,
        'status' => WorkforceMemberStatus::class,
        'lifecycle_state' => WorkforceMemberLifecycleState::class,
        'responsibilities' => 'array', 'goals' => 'array', 'capabilities' => 'array',
        'capability_variants' => 'array', 'skills' => 'array', 'playbooks' => 'array',
        'interaction_wizards' => 'array', 'knowledge_scopes' => 'array', 'memory_scopes' => 'array',
        'provider_preferences' => 'array', 'model_preferences' => 'array', 'schedule_config' => 'array',
        'workload_config' => 'array', 'escalation_policy' => 'array', 'autonomy_references' => 'array',
        'assurance_references' => 'array', 'performance_history' => 'array', 'metadata' => 'array',
        'is_active' => 'boolean', 'substitution_enabled' => 'boolean', 'max_concurrent_tasks' => 'integer',
        'role_definition_snapshot' => 'array', 'role_definition_deprecated_at' => 'datetime', 'role_definition_grace_until' => 'datetime',
        'lifecycle_changed_at' => 'datetime', 'activated_at' => 'datetime', 'suspended_at' => 'datetime', 'retired_at' => 'datetime',
        'lifecycle_metadata' => 'array',
        'visibility_scope' => 'array', 'coordination_permissions' => 'array',
        'consumes_seat' => 'boolean', 'is_permanent_system_role' => 'boolean',
    ];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function scopeStaffingSeats($query) { return $query->where('consumes_seat', true); }
    public function scopeSystemRoles($query) { return $query->where('member_kind', 'SYSTEM'); }
    public function organisation(): BelongsTo { return $this->belongsTo(WorkforceOrganisation::class, 'organisation_id'); }
    public function division(): BelongsTo { return $this->belongsTo(WorkforceDivision::class, 'division_id'); }
    public function team(): BelongsTo { return $this->belongsTo(WorkforceTeam::class, 'team_id'); }
    public function manager(): BelongsTo { return $this->belongsTo(self::class, 'manager_id'); }
    public function replacementFor(): BelongsTo { return $this->belongsTo(self::class, 'replaced_by_member_id'); }
    public function replaces(): HasMany { return $this->hasMany(self::class, 'replaced_by_member_id'); }
    public function reports(): HasMany { return $this->hasMany(self::class, 'manager_id'); }
    public function assignedTasks(): HasMany { return $this->hasMany(WorkforceTask::class, 'assignee_member_id'); }
    public function managedTasks(): HasMany { return $this->hasMany(WorkforceTask::class, 'manager_member_id'); }
}
