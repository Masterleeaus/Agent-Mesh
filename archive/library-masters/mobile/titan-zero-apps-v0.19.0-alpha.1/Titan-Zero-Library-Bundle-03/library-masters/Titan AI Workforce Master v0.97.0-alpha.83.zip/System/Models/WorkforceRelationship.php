<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use Illuminate\Database\Eloquent\Model;

class WorkforceRelationship extends Model
{
    protected $table = 'ext_titan_ai_workforce_relationships';
    protected $guarded = [];
    protected $casts = ['relationship_type' => WorkforceRelationshipType::class, 'metadata' => 'array', 'is_active' => 'boolean'];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
