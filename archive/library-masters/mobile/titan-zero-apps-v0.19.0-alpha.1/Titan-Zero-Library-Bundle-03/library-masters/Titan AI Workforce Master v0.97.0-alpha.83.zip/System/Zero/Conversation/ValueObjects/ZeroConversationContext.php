<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Conversation\ValueObjects;
use InvalidArgumentException;
final class ZeroConversationContext
{
    public array $turns = [];
    public array $entities = [];
    public array $activeObjects = [];
    public array $pendingClarifications = [];
    public array $pendingApprovals = [];
    public array $assumptions = [];
    public array $outcomes = [];
    public function __construct(public readonly int $companyId, public readonly string $conversationId, public readonly string $actorId)
    {
        if ($companyId <= 0 || trim($conversationId)==='' || trim($actorId)==='') throw new InvalidArgumentException('company_id, conversation_id and actor_id are required.');
    }
    public function toArray(): array
    {
        return [
            'schema'=>'titan.zero.conversation-context.v1','company_id'=>$this->companyId,'conversation_id'=>$this->conversationId,'actor_id'=>$this->actorId,
            'turns'=>$this->turns,'entities'=>$this->entities,'active_objects'=>$this->activeObjects,'pending_clarifications'=>$this->pendingClarifications,
            'pending_approvals'=>$this->pendingApprovals,'assumptions'=>$this->assumptions,'outcomes'=>$this->outcomes,
            'safety'=>['grants_authority'=>false,'executes_mutations'=>false,'business_truth_authority'=>false],
        ];
    }
}
