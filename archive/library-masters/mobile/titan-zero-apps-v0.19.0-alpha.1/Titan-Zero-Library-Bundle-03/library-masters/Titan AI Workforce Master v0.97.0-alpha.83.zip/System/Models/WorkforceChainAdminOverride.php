<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainAdminOverride extends Model
{
    protected $table='ext_titan_ai_workforce_chain_admin_overrides';
    protected $guarded=[];
    protected $casts=[
        'evidence_refs'=>'array','effect'=>'array',
        'created_at_override'=>'datetime','released_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
