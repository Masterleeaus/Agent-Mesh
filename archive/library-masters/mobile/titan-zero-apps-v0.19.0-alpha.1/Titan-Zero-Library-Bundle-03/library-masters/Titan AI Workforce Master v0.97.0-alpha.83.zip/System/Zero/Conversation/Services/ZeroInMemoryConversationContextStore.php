<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Services;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Contracts\ZeroConversationContextStoreContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\ValueObjects\ZeroConversationContext;
final class ZeroInMemoryConversationContextStore implements ZeroConversationContextStoreContract
{
    private array $contexts=[];
    public function load(int $companyId,string $conversationId,string $actorId): ?ZeroConversationContext { return $this->contexts[$this->key($companyId,$conversationId,$actorId)] ?? null; }
    public function save(ZeroConversationContext $context): void { $this->contexts[$this->key($context->companyId,$context->conversationId,$context->actorId)]=$context; }
    private function key(int $companyId,string $conversationId,string $actorId): string { return hash('sha256',$companyId.'|'.$conversationId.'|'.$actorId); }
}
