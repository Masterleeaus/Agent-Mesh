<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class IntrinsicDivisionCatalog
{
    /** @var array<int,array<string,mixed>>|null */
    private static ?array $definitions = null;

    /** @return array<int,array<string,mixed>> */
    public function all(): array
    {
        if (self::$definitions !== null) return self::$definitions;

        $path = dirname(__DIR__, 2) . '/resources/workforce/division-definitions.json';
        if (! is_file($path)) throw new RuntimeException('Intrinsic Workforce division catalogue is missing.');

        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new RuntimeException('Intrinsic Workforce division catalogue must be an array.');

        return self::$definitions = array_values($decoded);
    }

    /** @return array<string,mixed>|null */
    public function find(string $keyOrDefinitionId): ?array
    {
        foreach ($this->all() as $definition) {
            if (($definition['key'] ?? null) === $keyOrDefinitionId || ($definition['division_definition_id'] ?? null) === $keyOrDefinitionId) {
                return $definition;
            }
        }
        return null;
    }

    public function definitionId(string $key): string
    {
        return 'titan.division.' . $key;
    }
}
