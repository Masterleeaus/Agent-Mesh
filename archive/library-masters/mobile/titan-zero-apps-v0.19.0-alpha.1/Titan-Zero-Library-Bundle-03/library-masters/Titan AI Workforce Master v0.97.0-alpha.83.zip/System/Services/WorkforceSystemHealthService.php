<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;

/** Read-only company-scoped operational health aggregation. */
final class WorkforceSystemHealthService
{
    public function __construct(
        private readonly WorkforceCapabilityHealthInspectorService $capabilities,
        private readonly WorkforceOutcomeHealthService $outcomes,
        private readonly WorkforceTrustHealthService $trust,
        private readonly WorkforceQueueHealthService $queues,
        private readonly WorkforceUnifiedObservabilityService $observability,
    ) {}

    public function snapshot(int $companyId): array
    {
        $provider=$this->capabilities->snapshot($companyId);
        $outcome=$this->outcomes->snapshot($companyId);
        $governance=$this->trust->forCompany($companyId);
        $divisions=WorkforceDivision::query()->forCompany($companyId)->where('is_active',true)->get();
        $queueRows=$divisions->map(fn($d)=>['division_id'=>(int)$d->id,'division'=>(string)$d->name]+$this->queues->snapshot($companyId,(int)$d->id))->values()->all();
        $observability=$this->observability->health($companyId);

        $members=WorkforceMember::query()->forCompany($companyId)->where('is_active',true)->get();
        $tasks=WorkforceTask::query()->forCompany($companyId)->whereNotIn('status',['COMPLETED','FAILED','CANCELLED','REJECTED'])->get();
        $degraded=collect($provider['employees'] ?? $provider['members'] ?? [])->filter(fn($r)=>!in_array((string)($r['state']??'unavailable'),['available','healthy'],true))->count();
        $critical=[];
        if($degraded>0)$critical[]=['type'=>'provider_health','severity'=>'HIGH','message'=>"{$degraded} employees have degraded capability/provider availability."];
        if(($outcome['verification_late']??0)>0)$critical[]=['type'=>'outcome_health','severity'=>'HIGH','message'=>(int)$outcome['verification_late'].' outcome verifications are late.'];
        foreach($queueRows as $row)if(in_array($row['pressure']??'NORMAL',['HIGH','CRITICAL'],true))$critical[]=['type'=>'queue_health','severity'=>$row['pressure'],'message'=>($row['division']??'Division').' queue pressure is '.($row['pressure']??'HIGH').'.'];
        if(in_array(data_get($governance,'organisation.state','HEALTHY'),['DEGRADED','CRITICAL'],true))$critical[]=['type'=>'governance_health','severity'=>data_get($governance,'organisation.state'),'message'=>'Governance/trust controls require attention.'];
        if(($observability['stuck_work']??0)>0)$critical[]=['type'=>'stuck_work','severity'=>'HIGH','message'=>(int)$observability['stuck_work'].' work items appear stuck or inactive.'];
        if(($observability['unresolved_reconciliation']??0)>0)$critical[]=['type'=>'reconciliation','severity'=>'CRITICAL','message'=>(int)$observability['unresolved_reconciliation'].' executions have unresolved or uncertain outcomes.'];
        if(($observability['recent_provider_incidents']??0)>0)$critical[]=['type'=>'provider_incident','severity'=>'HIGH','message'=>(int)$observability['recent_provider_incidents'].' degraded provider events were observed in the last 24 hours.'];
        foreach((array)($observability['resource_budgets']??[]) as $budget)if(in_array($budget['state']??'HEALTHY',['WARNING','EXHAUSTED'],true))$critical[]=['type'=>'budget_health','severity'=>($budget['state']==='EXHAUSTED'?'CRITICAL':'HIGH'),'message'=>($budget['resource_type']??'resource').' budget is '.strtolower((string)$budget['state']).'.'];

        $actions=collect($critical)->map(fn($f)=>match($f['type']){
            'provider_health'=>'Open Capability Health and restore or approve an eligible provider fallback.',
            'outcome_health'=>'Review pending outcome verification and recovery evidence.',
            'queue_health'=>'Open Workforce Planning or Manager Command Center to rebalance work.',
            'governance_health'=>'Inspect Risk, Assurance, Governance and Autonomy decisions before retry.',
            'stuck_work'=>'Open the correlation trace and inspect the last successful stage before retrying.',
            'reconciliation'=>'Reconcile authoritative provider/Command Bus receipts before any retry.',
            'provider_incident'=>'Inspect provider health and use only an authorised fallback.',
            'budget_health'=>'Review Cost Sovereignty budget usage and approval ceilings.',
            default=>'Review the affected Workforce record.',
        })->unique()->values()->all();

        return [
            'company_id'=>$companyId,
            'workforce_health'=>['active_staff'=>$members->count(),'open_work'=>$tasks->count(),'blocked_work'=>$tasks->whereIn('status',['BLOCKED','AWAITING_DATA','RECOVERY'])->count(),'degraded_staff'=>$degraded],
            'provider_health'=>$provider,
            'queue_health'=>$queueRows,
            'outcome_health'=>$outcome,
            'governance_health'=>$governance,
            'observability_health'=>$observability,
            'proactive_health'=>['scheduled_open'=>$tasks->whereNotNull('scheduled_at')->count(),'overdue'=>$tasks->filter(fn($t)=>$t->deadline_at && $t->deadline_at->isPast())->count()],
            'data_integrity'=>['company_scope_enforced'=>true,'authority_inherited'=>false,'execution_authority_granted'=>false,'diagnostic_is_read_only'=>true],
            'critical_findings'=>$critical,
            'recommended_actions'=>$actions,
            'overall_state'=>empty($critical)?'HEALTHY':(collect($critical)->contains(fn($f)=>$f['severity']==='CRITICAL')?'CRITICAL':'ATTENTION_REQUIRED'),
        ];
    }
}
