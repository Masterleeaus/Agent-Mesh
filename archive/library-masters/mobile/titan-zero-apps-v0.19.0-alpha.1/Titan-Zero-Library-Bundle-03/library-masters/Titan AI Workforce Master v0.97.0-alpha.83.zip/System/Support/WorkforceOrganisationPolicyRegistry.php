<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class WorkforceOrganisationPolicyRegistry
{
    private static ?array $cache = null;

    public static function all(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $path = dirname(__DIR__, 2) . '/resources/workforce/organisation-policies.json';
        $json = @file_get_contents($path);
        if ($json === false) {
            throw new RuntimeException('Titan AI Workforce organisation policy registry is unavailable.');
        }

        return self::$cache = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
    }

    public static function decisionRight(string $decision): ?array
    {
        foreach (self::all()['decision_rights'] ?? [] as $row) {
            if (($row['decision'] ?? null) === $decision) {
                return $row;
            }
        }
        return null;
    }

    public static function disputeRoute(string $conflict): ?array
    {
        foreach (self::all()['dispute_routes'] ?? [] as $row) {
            if (($row['conflict'] ?? null) === $conflict) {
                return $row;
            }
        }
        return null;
    }
}
