<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceProactiveIdentity;

final class WorkforceEventTriggerService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceManifestRegistry $manifests,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
    ) {}

    public function handle(string $eventType, array $envelope): int
    {
        $companyId = (int) ($envelope['company_id'] ?? data_get($envelope, 'payload.company_id', 0));
        $signalId = trim((string) ($envelope['signal_id'] ?? data_get($envelope, 'payload.signal_id', '')));
        if ($companyId < 1 || trim($eventType) === '') return 0;

        return CompanyContext::runWith($companyId, function () use ($companyId, $signalId, $eventType, $envelope): int {
            $created = 0;
            $triggers = WorkforceSchedule::query()->forCompany($companyId)
                ->where('is_active', true)
                ->where('trigger_type', 'event')
                ->where('event_type', $eventType)
                ->orderBy('id')->get();

            foreach ($triggers as $trigger) {
                if (! $this->matches($trigger->conditions ?? [], $envelope)) {
                    $this->recordRun($trigger, 'skipped', $eventType, $signalId);
                    continue;
                }
                $member = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->find($trigger->member_id);
                $routine = $this->triggerableRoutine($trigger, $member, $eventType);
                if (! $member || ! $routine) {
                    $this->recordRun($trigger, 'blocked', $eventType, $signalId);
                    $this->disableTrigger($trigger, 'source_definition_or_signal_routine_unavailable');
                    continue;
                }

                $capabilityState = (string) ($this->capabilityAvailability->forMember($member)['state'] ?? 'unavailable');
                if ($capabilityState === 'degraded') $this->recordRun($trigger, 'degraded', $eventType, $signalId);
                elseif ($capabilityState !== 'available') $this->recordRun($trigger, 'blocked', $eventType, $signalId);

                $idempotencyKey = WorkforceProactiveIdentity::signalIdempotencyKey(
                    $companyId,
                    (int) $member->id,
                    (string) $trigger->owner_extension,
                    (string) $trigger->role_definition_id,
                    (string) $trigger->routine_id,
                    (string) $trigger->routine_fingerprint,
                    $eventType,
                    $signalId !== '' ? $signalId : null,
                    $envelope,
                );
                $template = is_array($trigger->task_template) ? $trigger->task_template : [];
                $templateMetadata = is_array($template['metadata'] ?? null) ? $template['metadata'] : [];
                $task = $this->tasks->create($companyId, array_merge($template, [
                    'title' => $template['title'] ?? $trigger->name,
                    'assignee_member_id' => $member->id,
                    'manager_member_id' => $member->manager_id,
                    'division_id' => $member->division_id,
                    'team_id' => $member->team_id,
                    'origin_type' => 'titan_signal',
                    'origin_id' => $signalId !== '' ? $signalId : $eventType,
                    'payload' => array_merge($template['payload'] ?? [], ['trigger_signal' => $envelope]),
                    'idempotency_key' => $idempotencyKey,
                    'trace_id' => $envelope['trace_id'] ?? null,
                    'correlation_id' => $envelope['correlation_id'] ?? null,
                    'causation_id' => $signalId !== '' ? $signalId : ($envelope['causation_id'] ?? null),
                    'metadata' => array_merge($templateMetadata, [
                        'proactive' => true,
                        'creates' => 'workforce_task',
                        'business_mutation' => false,
                        'owner_extension' => (string) $trigger->owner_extension,
                        'owner_extension_version' => (string) $trigger->owner_extension_version,
                        'role_definition_id' => (string) $trigger->role_definition_id,
                        'routine_id' => (string) $trigger->routine_id,
                        'routine_fingerprint' => (string) $trigger->routine_fingerprint,
                        'trigger_event_type' => $eventType,
                        'trigger_signal_id' => $signalId !== '' ? $signalId : null,
                    ]),
                ]), $member);
                if ($task->wasRecentlyCreated) {
                    $this->recordRun($trigger, 'generated', $eventType, $signalId);
                    ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);
                    $created++;
                } else {
                    $this->recordRun($trigger, 'skipped', $eventType, $signalId);
                }
            }
            return $created;
        });
    }

    private function triggerableRoutine(WorkforceSchedule $trigger, ?WorkforceMember $member, string $eventType): ?array
    {
        if (! $member) return null;
        $owner = trim((string) $trigger->owner_extension);
        $roleId = trim((string) $trigger->role_definition_id);
        $routineId = trim((string) $trigger->routine_id);
        $fingerprint = trim((string) $trigger->routine_fingerprint);
        if ($owner === '' || $roleId === '' || $routineId === '' || $fingerprint === '') return null;
        if ((string) $member->role_owner_extension !== $owner || (string) $member->role_definition_id !== $roleId) return null;
        if (! $this->manifests->findOwnedRole($owner, $roleId)) return null;

        foreach ($this->manifests->explicitRoutinesForOwnedRole($owner, $roleId) as $routine) {
            if ((string) ($routine['routine_id'] ?? '') !== $routineId) continue;
            if ((string) ($routine['routine_fingerprint'] ?? '') !== $fingerprint) return null;
            if (($routine['trigger_type'] ?? null) !== 'event' || (string) ($routine['event_type'] ?? '') !== $eventType) return null;
            if (($routine['creates'] ?? null) !== 'workforce_task' || ($routine['business_mutation'] ?? false) !== false) return null;
            return $routine;
        }
        return null;
    }

    private function recordRun(WorkforceSchedule $trigger, string $status, string $eventType, string $signalId): void
    {
        $metadata = is_array($trigger->metadata) ? $trigger->metadata : [];
        $telemetry = is_array($metadata['run_telemetry'] ?? null) ? $metadata['run_telemetry'] : [];
        foreach (['generated','skipped','degraded','blocked'] as $key) $telemetry[$key] = (int) ($telemetry[$key] ?? 0);
        if (array_key_exists($status, $telemetry)) $telemetry[$status]++;
        $telemetry['last_status'] = $status;
        $telemetry['last_run_at'] = now()->toIso8601String();
        $telemetry['last_signal'] = ['event_type' => $eventType, 'signal_id' => $signalId !== '' ? $signalId : null];
        $metadata['run_telemetry'] = $telemetry;
        $trigger->forceFill(['last_run_at' => now(), 'metadata' => $metadata])->save();
    }

    private function disableTrigger(WorkforceSchedule $trigger, string $reason): void
    {
        $metadata = is_array($trigger->metadata) ? $trigger->metadata : [];
        $metadata['disabled_reason'] = $reason;
        $metadata['disabled_at'] = now()->toIso8601String();
        $trigger->forceFill(['is_active' => false, 'metadata' => $metadata])->save();
    }

    private function matches(array $conditions, array $envelope): bool
    {
        foreach ($conditions as $path => $expected) {
            if (data_get($envelope, (string) $path) != $expected) return false;
        }
        return true;
    }
}
