<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use Closure;
use InvalidArgumentException;

/**
 * Canonical Workforce tenancy boundary.
 *
 * company_id is the sole canonical company/tenant boundary. team_id and user_id are actor or grouping identities only.
 * HTTP requests derive company_id from authenticated host state. Background work uses
 * runWith() around an immutable company ID already persisted in the job/schedule/outbox row.
 */
final class CompanyContext
{
    private static ?int $restoredCompanyId = null;

    public static function id(object $user): int
    {
        $native = (int) self::attribute($user, 'company_id');
        if ($native < 1) {
            throw new InvalidArgumentException('Titan AI Workforce requires canonical company_id context.');
        }
        if (self::$restoredCompanyId !== null && self::$restoredCompanyId !== $native) {
            throw new InvalidArgumentException('Titan AI Workforce restored tenant context does not match authenticated company_id.');
        }
        return $native;
    }

    public static function current(): int
    {
        if (self::$restoredCompanyId === null || self::$restoredCompanyId < 1) {
            throw new InvalidArgumentException('Titan AI Workforce background tenant context is not restored.');
        }
        return self::$restoredCompanyId;
    }

    public static function assertMatches(int $companyId, object $user): void
    {
        if ($companyId < 1 || $companyId !== self::id($user)) {
            throw new InvalidArgumentException('Titan AI Workforce company boundary mismatch.');
        }
    }

    public static function runWith(int $companyId, Closure $callback): mixed
    {
        if ($companyId < 1) {
            throw new InvalidArgumentException('Titan AI Workforce cannot restore an invalid company_id.');
        }
        $previous = self::$restoredCompanyId;
        if ($previous !== null && $previous !== $companyId) {
            throw new InvalidArgumentException('Titan AI Workforce cannot switch company_id inside an active tenant scope.');
        }
        self::$restoredCompanyId = $companyId;
        try {
            return $callback();
        } finally {
            self::$restoredCompanyId = $previous;
        }
    }

    public static function clear(): void
    {
        self::$restoredCompanyId = null;
    }

    private static function attribute(object $user, string $key): mixed
    {
        return method_exists($user, 'getAttribute') ? $user->getAttribute($key) : ($user->{$key} ?? null);
    }
}
