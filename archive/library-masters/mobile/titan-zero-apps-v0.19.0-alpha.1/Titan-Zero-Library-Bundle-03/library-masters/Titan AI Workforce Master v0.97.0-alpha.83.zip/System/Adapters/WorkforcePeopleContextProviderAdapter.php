<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Adapters;

use App\Extensions\TitanAIWorkforce\System\Contracts\WorkforceBusinessContextProviderContract;
use RuntimeException;

final class WorkforcePeopleContextProviderAdapter implements WorkforceBusinessContextProviderContract
{
    public function providerKey(): string { return 'titan-people'; }
    public function providerVersion(): string { return '1.0.0-rc.1'; }

    public function supports(string $surfaceId): bool
    {
        return in_array($surfaceId, [
            'people.worker.read','tool:people.worker.read',
            'people.leave.read','tool:people.leave.read',
            'people.lifecycle.read','tool:people.lifecycle.read',
            'people.records.read','tool:people.records.read',
        ], true);
    }

    public function read(int $companyId, string $surfaceId, array $filters = [], int $limit = 50): array
    {
        $contract = 'App\\Extensions\\TitanPeople\\System\\Queries\\PeopleReadRepository';
        if (! app()->bound($contract)) throw new RuntimeException('Titan People read repository is unavailable.');
        $repo = app($contract);
        $limit = max(1, min($limit, 200));

        $items = match ($surfaceId) {
            'people.worker.read','tool:people.worker.read' => $this->pageItems($repo->paginateWorkers($companyId, $limit)),
            'people.leave.read','tool:people.leave.read' => $this->pageItems($repo->paginateLeave($companyId, $limit)),
            'people.lifecycle.read','tool:people.lifecycle.read' => $this->pageItems($repo->paginateLifecycle($companyId, $limit)),
            'people.records.read','tool:people.records.read' => [$repo->overview($companyId), $repo->organisation($companyId)],
            default => throw new RuntimeException('Unsupported Titan People context surface.'),
        };

        return [
            'company_id'=>$companyId,'surface_id'=>$surfaceId,'items'=>$items,
            'observed_at'=>now()->toIso8601String(),
            'provenance'=>['provider'=>'titan-people','provider_version'=>$this->providerVersion(),'storage_compatibility'=>'legacy-internal-key-adapted'],
        ];
    }

    private function pageItems(mixed $page): array
    {
        if (is_object($page) && method_exists($page, 'items')) return array_values(array_map(fn ($v) => is_object($v) && method_exists($v,'toArray') ? $v->toArray() : (array) $v, $page->items()));
        if (is_array($page)) return array_values($page);
        return [];
    }
}
