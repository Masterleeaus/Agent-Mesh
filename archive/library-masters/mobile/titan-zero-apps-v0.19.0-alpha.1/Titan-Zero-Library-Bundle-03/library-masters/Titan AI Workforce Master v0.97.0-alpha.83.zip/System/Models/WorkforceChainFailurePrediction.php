<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainFailurePrediction extends Model
{
    protected $table='ext_titan_ai_workforce_chain_failure_predictions';
    protected $guarded=[];
    protected $casts=[
        'failure_probability'=>'integer',
        'likely_disagreement'=>'boolean','likely_authority_denial'=>'boolean','likely_stall'=>'boolean',
        'weak_reviewer_pool'=>'boolean','knowledge_gap_risk'=>'boolean','mandatory_three_checks'=>'boolean',
        'signals'=>'array','preventive_requirements'=>'array','wisdom_prediction'=>'array','predicted_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
