<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

final class WorkforceCommercialCapabilityPolicyService
{
    public function __construct(private readonly WorkforceEntitlementService $entitlements) {}

    /** @return array{score:int,band:string,source:string} */
    public function autonomyCeiling(int $companyId, string $businessTier): array
    {
        $tier = strtolower(trim($businessTier));
        if ($tier === 'legacy_existing') return ['score'=>100,'band'=>'Predictive','source'=>'legacy_migration_grace'];
        if ($tier === '' || $tier === 'free') return ['score'=>30,'band'=>'Assist','source'=>'free_human_in_loop'];
        if ($this->entitlements->has($companyId, 'workforce.predictive')) return ['score'=>100,'band'=>'Predictive','source'=>'workforce.predictive'];
        if ($this->entitlements->has($companyId, 'workforce.autonomy.auto')) return ['score'=>85,'band'=>'Autonomous','source'=>'workforce.autonomy.auto'];
        if ($this->entitlements->has($companyId, 'workforce.autonomy.semi_auto')) return ['score'=>50,'band'=>'Semi-Autonomous','source'=>'workforce.autonomy.semi_auto'];
        return ['score'=>30,'band'=>'Assist','source'=>'no_paid_autonomy_entitlement'];
    }
}
