<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/**
 * Registry for extension-owned execution surfaces attached to Workforce-owned roles.
 *
 * Canonical ownership rule:
 * - Titan AI Workforce owns organisation/division/team/role/responsibility identity.
 * - Contributing extensions own capabilities, tools, commands, signals, data sources and workflows.
 * - Bindings never inherit authority; Risk/Assurance/Governance/Autonomy remain authoritative.
 *
 * Manifest 2.0 role blocks are accepted only as legacy_v2_role_hint input during the
 * compatibility window. They cannot create canonical Workforce roles.
 */
final class WorkforceCapabilityBindingRegistry
{
    /** @var array<string,array{provider:mixed,priority:int}> */
    private array $providers = [];
    /** @var array<string,array<string,mixed>> */
    private array $compiled = [];
    private bool $containerBindingsScanned = false;
    private bool $ready = false;

    public function __construct(
        private readonly Container $app,
        private readonly WorkforceManifestRegistry $manifests,
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly WorkforceCanonicalCapabilityMatrix $matrix,
    ) {}

    public function invalidate(): void
    {
        $this->compiled = [];
        $this->ready = false;
    }

    public function registerContribution(mixed $keyOrProvider, mixed $provider = null, int $priority = 100): self
    {
        if ($provider === null) {
            $provider = $keyOrProvider;
            $key = is_array($provider) ? trim((string) ($provider['extension']['key'] ?? '')) : 'provider:' . (is_object($provider) ? get_class($provider) . ':' . spl_object_id($provider) : trim((string) $provider));
        } else {
            $key = trim((string) $keyOrProvider);
        }
        if ($key === '') throw new RuntimeException('Workforce capability contribution requires a stable key.');
        $this->providers[$key] = ['provider' => $provider, 'priority' => $priority];
        $this->ready = false;
        return $this;
    }

    /** @return array<string,array<string,mixed>> keyed by extension key */
    public function contributions(): array
    {
        $this->discoverContainerBindings();
        if ($this->ready) return $this->compiled;

        // The full ecosystem registry is descriptive until the provider is installed.
        // installedContributions() performs the class_exists gate, so catalogue-only
        // providers can never become effective access on a partial installation.
        $compiled = $this->ecosystem->installedContributions();
        foreach (array_keys($compiled) as $extensionKey) {
            if ($this->manifests->isSuppressedExtension((string) $extensionKey)) unset($compiled[$extensionKey]);
        }

        // Compatibility translation: existing Manifest 2.0 packages keep working as
        // live capability providers, but their role blocks are only legacy_v2_role_hint
        // data. Merge them into the normalized ecosystem surfaces rather than allowing
        // either source to redefine Workforce-owned employee identity.
        foreach ($this->manifests->providerContributions() as $extensionKey => $contribution) {
            WorkforceCapabilityBindingValidator::assertValid($contribution);
            $compiled[$extensionKey] = isset($compiled[$extensionKey])
                ? $this->mergeContributions($compiled[$extensionKey], $contribution)
                : $contribution;
        }

        $providers = $this->providers;
        uasort($providers, static fn (array $a, array $b): int => ((int) $b['priority']) <=> ((int) $a['priority']));
        foreach ($providers as $providerKey => $entry) {
            try {
                $contribution = $this->resolveProvider($entry['provider']);
                WorkforceCapabilityBindingValidator::assertValid($contribution);
                $extensionKey = (string) $contribution['extension']['key'];
                if ($this->manifests->isSuppressedExtension($extensionKey)) continue;
                $contribution['_registry'] = ['source' => 'capability_binding_v1', 'priority' => (int) $entry['priority']];
                // Explicit capability-binding v1 providers augment the normalized/live
                // provider surfaces. They do not replace role identity or erase catalogue
                // provenance discovered from the supplied ecosystem.
                $compiled[$extensionKey] = isset($compiled[$extensionKey])
                    ? $this->mergeContributions($compiled[$extensionKey], $contribution)
                    : $contribution;
            } catch (Throwable) {
                // Fail closed: invalid provider contributes no executable surface.
                continue;
            }
        }

        return $this->compiled = $compiled;
    }

    /** @return list<array<string,mixed>> */
    public function bindingsForRole(string $roleDefinitionId): array
    {
        $role = $this->matrix->role($roleDefinitionId);
        if (! $role) return [];

        // Titan Zero is represented in the matrix for organisation-wide coordination,
        // but it intentionally has zero domain provider bindings.
        if ($roleDefinitionId === TitanZeroSystemRole::ROLE_DEFINITION_ID) return [];

        $contributions = $this->contributions();
        $out = [];
        foreach ($this->matrix->bindingsForRole($roleDefinitionId) as $binding) {
            $owner = trim((string) ($binding['provider'] ?? ''));
            if ($owner === '' || ! isset($contributions[$owner])) continue;
            $contribution = $contributions[$owner];
            if (! $this->matrixBindingSatisfiedByContribution($binding, $contribution)) continue;

            $binding['owner_extension'] = $owner;
            $binding['owner_extension_version'] = (string) ($contribution['extension']['version'] ?? '');
            $binding['authority_inherited'] = false;
            $binding['source'] = 'canonical_capability_binding_matrix_v1';
            $out[] = $binding;
        }
        return $out;
    }

    /**
     * Fail closed when an installed provider no longer publishes any surface pinned by
     * the canonical matrix. Provider upgrades therefore cannot silently expand, rename
     * or substitute a role's available execution surface.
     *
     * @param array<string,mixed> $binding
     * @param array<string,mixed> $contribution
     */
    private function matrixBindingSatisfiedByContribution(array $binding, array $contribution): bool
    {
        foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
            $required = array_values(array_filter(array_map(
                static fn ($value): string => trim((string) $value),
                (array) ($binding[$section] ?? [])
            ), static fn (string $value): bool => $value !== ''));
            if ($required === []) continue;

            $published = [];
            foreach ((array) ($contribution[$section] ?? []) as $item) {
                if (! is_array($item)) continue;
                $id = trim((string) ($item['id'] ?? $item['name'] ?? $item['workflow_id'] ?? ''));
                if ($id !== '') $published[$id] = true;
            }
            foreach ($required as $id) {
                if (! isset($published[$id])) return false;
            }
        }
        return true;
    }

    /**
     * Flatten all provider-owned execution surfaces available to one intrinsic role.
     * This is availability, not authority. Canonical invariant: 'authority_inherited' => false.
     *
     * @return array{capabilities:list<string>,tools:list<string>,commands:list<string>,signals:list<string>,data_sources:list<string>,workflows:list<string>,providers:list<string>,authority_inherited:false}
     */
    public function effectiveAccessForRole(string $roleDefinitionId): array
    {
        $sets = ['capabilities'=>[], 'tools'=>[], 'commands'=>[], 'signals'=>[], 'data_sources'=>[], 'workflows'=>[], 'providers'=>[]];
        foreach ($this->bindingsForRole($roleDefinitionId) as $binding) {
            $owner = (string) ($binding['owner_extension'] ?? '');
            if ($owner !== '') $sets['providers'][$owner] = true;
            foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
                foreach ((array) ($binding[$section] ?? []) as $id) {
                    $id = trim((string) $id);
                    if ($id !== '') $sets[$section][$id] = true;
                }
            }
        }
        $out = [];
        foreach ($sets as $section => $values) {
            $out[$section] = array_keys($values);
            sort($out[$section]);
        }
        $out['authority_inherited'] = false;
        return $out;
    }

    /** @return list<string> */
    public function ownersForCapability(string $roleDefinitionId, string $capabilityName): array
    {
        $owners = [];
        foreach ($this->bindingsForRole($roleDefinitionId) as $binding) {
            if (! in_array($capabilityName, (array) ($binding['capabilities'] ?? []), true)) continue;
            $owner = trim((string) ($binding['owner_extension'] ?? ''));
            if ($owner !== '') $owners[$owner] = true;
        }
        $out = array_keys($owners);
        sort($out);
        return $out;
    }

    /** @return array<string,mixed>|null */
    public function findOwnedWorkflow(string $extensionKey, string $workflowId): ?array
    {
        $contribution = $this->contributions()[$extensionKey] ?? null;
        if (! $contribution) return null;
        foreach ($contribution['workflows'] as $workflow) {
            if (! is_array($workflow)) continue;
            $id = (string) ($workflow['id'] ?? $workflow['workflow_id'] ?? '');
            if ($id !== $workflowId) continue;
            $workflow['workflow_id'] = $id;
            $workflow['owner_extension'] = $extensionKey;
            $workflow['owner_extension_version'] = (string) $contribution['extension']['version'];
            return $workflow;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public function capabilities(): array { return $this->surface('capabilities'); }
    /** @return list<array<string,mixed>> */
    public function tools(): array { return $this->surface('tools'); }
    /** @return list<array<string,mixed>> */
    public function commands(): array { return $this->surface('commands'); }
    /** @return list<array<string,mixed>> */
    public function signals(): array { return $this->surface('signals'); }
    /** @return list<array<string,mixed>> */
    public function data_sources(): array { return $this->surface('data_sources'); }
    /** @return list<array<string,mixed>> */
    public function workflows(): array { return $this->surface('workflows'); }

    /** @return array<string,mixed>|null */
    public function findOwnedCapability(string $extensionKey, string $capabilityName, ?string $variant = null): ?array
    {
        $contribution = $this->contributions()[$extensionKey] ?? null;
        if (! $contribution) return null;
        foreach ($contribution['capabilities'] as $capability) {
            if ((string) ($capability['name'] ?? $capability['id'] ?? '') !== $capabilityName) continue;
            $declaredVariant = $capability['autonomy_requirement']['variant'] ?? null;
            if ($variant !== null && $declaredVariant !== null && (string) $declaredVariant !== $variant) continue;
            $capability['owner_extension'] = $extensionKey;
            $capability['owner_extension_version'] = (string) $contribution['extension']['version'];
            return $capability;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    private function surface(string $section): array
    {
        $out = [];
        foreach ($this->contributions() as $contribution) {
            $owner = (string) $contribution['extension']['key'];
            $version = (string) $contribution['extension']['version'];
            foreach ($contribution[$section] as $item) {
                if (! is_array($item)) continue;
                $item['owner_extension'] = $owner;
                $item['owner_extension_version'] = $version;
                $out[] = $item;
            }
        }
        return $out;
    }

    private function discoverContainerBindings(): void
    {
        if ($this->containerBindingsScanned) return;
        $this->containerBindingsScanned = true;
        if (! method_exists($this->app, 'getBindings')) return;
        foreach (array_keys($this->app->getBindings()) as $abstract) {
            $abstract = (string) $abstract;
            if (! str_contains($abstract, 'workforce-capability-binding')) continue;
            try { $provider = $this->app->make($abstract); } catch (Throwable) { continue; }
            $this->providers['binding:' . $abstract] = ['provider' => $provider, 'priority' => 50];
        }
    }


    /**
     * Merge two contributions from the same provider without duplicating role bindings.
     * Later/live values win on identical surface IDs; all authority_inherited flags stay false.
     *
     * @param array<string,mixed> $base
     * @param array<string,mixed> $overlay
     * @return array<string,mixed>
     */
    private function mergeContributions(array $base, array $overlay): array
    {
        $merged = $base;
        $merged['extension'] = $overlay['extension'] ?? $base['extension'];
        $merged['ownership'] = [
            'organisation_owner' => 'titan-ai-workforce',
            'provider_owns_execution_surfaces' => true,
            'role_definitions_owned_by_provider' => false,
        ];

        foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
            $items = [];
            foreach (array_merge((array) ($base[$section] ?? []), (array) ($overlay[$section] ?? [])) as $item) {
                if (! is_array($item)) continue;
                $id = trim((string) ($item['id'] ?? $item['name'] ?? $item['workflow_id'] ?? ''));
                if ($id === '') $id = hash('sha256', json_encode($item, JSON_UNESCAPED_SLASHES) ?: '');
                $items[$id] = isset($items[$id]) ? array_replace_recursive($items[$id], $item) : $item;
            }
            $merged[$section] = array_values($items);
        }

        $bindings = [];
        foreach (array_merge((array) ($base['role_bindings'] ?? []), (array) ($overlay['role_bindings'] ?? [])) as $binding) {
            if (! is_array($binding)) continue;
            $roleId = trim((string) ($binding['role_definition_id'] ?? ''));
            if ($roleId === '') continue;
            if (! isset($bindings[$roleId])) {
                $bindings[$roleId] = [
                    'role_definition_id' => $roleId,
                    'capabilities' => [], 'tools' => [], 'commands' => [],
                    'signals' => [], 'data_sources' => [], 'workflows' => [],
                    'authority_inherited' => false,
                ];
            }
            foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $section) {
                $values = array_merge((array) $bindings[$roleId][$section], (array) ($binding[$section] ?? []));
                $values = array_values(array_unique(array_filter(array_map(static fn ($v): string => trim((string) $v), $values), static fn (string $v): bool => $v !== '')));
                sort($values);
                $bindings[$roleId][$section] = $values;
            }
            $bindings[$roleId]['authority_inherited'] = false;
            if (isset($binding['source'])) $bindings[$roleId]['source'] = $binding['source'];
        }
        ksort($bindings);
        $merged['role_bindings'] = array_values($bindings);
        $merged['schema_version'] = '1.0';
        if (isset($base['_catalogue'])) $merged['_catalogue'] = $base['_catalogue'];
        if (isset($overlay['_registry'])) $merged['_registry'] = $overlay['_registry'];
        WorkforceCapabilityBindingValidator::assertValid($merged);
        return $merged;
    }

    /** @return array<string,mixed> */
    private function resolveProvider(mixed $provider): array
    {
        if (is_array($provider)) return $provider;
        if (is_string($provider) && class_exists($provider)) $provider = $this->app->make($provider);
        if (is_callable($provider) && ! is_object($provider)) $provider = $provider();
        if (is_object($provider) && method_exists($provider, 'all')) $provider = $provider->all();
        elseif (is_object($provider) && is_callable($provider)) $provider = $provider();
        if (! is_array($provider)) throw new RuntimeException('Workforce capability binding provider did not resolve to an array.');
        return $provider;
    }
}
