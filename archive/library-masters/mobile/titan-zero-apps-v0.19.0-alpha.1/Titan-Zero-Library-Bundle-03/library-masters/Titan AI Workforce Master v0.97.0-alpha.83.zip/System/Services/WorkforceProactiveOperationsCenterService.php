<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;

/** Read-only company-scoped projection answering: what is the Workforce doing by itself? */
final class WorkforceProactiveOperationsCenterService
{
    public function __construct(private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability) {}

    public function snapshot(int $companyId): array
    {
        $schedules = WorkforceSchedule::query()->forCompany($companyId)->orderByDesc('is_active')->orderBy('trigger_type')->orderBy('name')->get();
        $members = WorkforceMember::query()->forCompany($companyId)->get()->keyBy('id');
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->where(function ($q) { $q->where('origin_type', 'workforce_schedule')->orWhere('origin_type', 'titan_signal'); })
            ->latest('id')->limit(500)->get();
        $tasksByRoutine = $tasks->groupBy(fn (WorkforceTask $task) => (string) data_get($task->metadata ?? [], 'routine_id', ''));

        $rows = $schedules->map(function (WorkforceSchedule $schedule) use ($members, $tasksByRoutine): array {
            /** @var WorkforceMember|null $member */
            $member = $members->get($schedule->member_id);
            $capability = $member ? $this->capabilityAvailability->forMember($member) : ['state' => 'blocked', 'provider_bindings' => []];
            $providerDependencies = collect((array) ($capability['provider_bindings'] ?? []))->map(static fn (array $binding): array => [
                'provider' => (string) ($binding['provider'] ?? ''),
                'state' => (string) ($binding['state'] ?? 'unavailable'),
            ])->filter(fn (array $row): bool => $row['provider'] !== '')->values()->all();

            $routineTasks = $tasksByRoutine->get((string) $schedule->routine_id, collect());
            $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
            $runTelemetry = is_array($metadata['run_telemetry'] ?? null) ? $metadata['run_telemetry'] : [];
            $latestSignal = $routineTasks->first(fn (WorkforceTask $task): bool => $task->origin_type === 'titan_signal');

            return [
                'id' => (int) $schedule->id,
                'name' => (string) $schedule->name,
                'routine_id' => (string) $schedule->routine_id,
                'trigger_type' => (string) $schedule->trigger_type,
                'event_type' => $schedule->event_type ? (string) $schedule->event_type : null,
                'is_active' => (bool) $schedule->is_active,
                'last_run_at' => $schedule->last_run_at?->toIso8601String() ?? ($runTelemetry['last_run_at'] ?? null),
                'next_run_at' => $schedule->next_run_at?->toIso8601String(),
                'employee' => $member ? ['id'=>(int)$member->id, 'name'=>(string)$member->name, 'role'=>(string)$member->role_definition_id] : null,
                'provider_dependencies' => $providerDependencies,
                'capability_state' => (string) ($capability['state'] ?? 'unavailable'),
                'triggering_signal' => $latestSignal ? [
                    'event_type' => (string) data_get($latestSignal->metadata ?? [], 'trigger_event_type', $schedule->event_type),
                    'signal_id' => data_get($latestSignal->metadata ?? [], 'trigger_signal_id'),
                    'task_id' => (int) $latestSignal->id,
                ] : ($runTelemetry['last_signal'] ?? null),
                'generated_work' => $routineTasks->count(),
                'generated_runs' => (int) ($runTelemetry['generated'] ?? $routineTasks->count()),
                'skipped_runs' => (int) ($runTelemetry['skipped'] ?? 0),
                'degraded_runs' => (int) ($runTelemetry['degraded'] ?? 0),
                'blocked_runs' => (int) ($runTelemetry['blocked'] ?? 0) + $routineTasks->filter(fn (WorkforceTask $task) => $task->status === WorkforceTaskStatus::Blocked)->count(),
                'last_status' => (string) ($runTelemetry['last_status'] ?? ($schedule->is_active ? 'ready' : 'blocked')),
                'disabled_reason' => data_get($metadata, 'disabled_reason'),
                'recent_work' => $routineTasks->take(5)->map(fn (WorkforceTask $task): array => [
                    'id'=>(int)$task->id,
                    'title'=>(string)$task->title,
                    'status'=>$task->status->value,
                    'created_at'=>$task->created_at?->toIso8601String(),
                ])->values()->all(),
            ];
        })->values();

        $scheduled = $rows->where('trigger_type', 'schedule')->values();
        $eventDriven = $rows->where('trigger_type', 'event')->values();
        return [
            'company_id' => $companyId,
            'authority_inherited' => false,
            'summary' => [
                'scheduled_routines' => $scheduled->count(),
                'event_driven_routines' => $eventDriven->count(),
                'active_routines' => $rows->where('is_active', true)->count(),
                'generated_work' => $rows->sum('generated_work'),
                'skipped_runs' => $rows->sum('skipped_runs'),
                'degraded_runs' => $rows->sum('degraded_runs'),
                'blocked_runs' => $rows->sum('blocked_runs'),
            ],
            'scheduled' => $scheduled->all(),
            'event_driven' => $eventDriven->all(),
        ];
    }
}
