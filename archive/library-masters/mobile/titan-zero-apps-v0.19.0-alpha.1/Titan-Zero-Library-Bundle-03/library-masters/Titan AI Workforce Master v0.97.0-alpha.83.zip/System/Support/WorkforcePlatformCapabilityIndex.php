<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/**
 * Provider-qualified normalized index of every Workforce-visible Titan platform surface.
 *
 * This is discovery/provenance data only. It deliberately does not select a provider,
 * inherit authority, or execute commands. Provider routing and authority remain later gates.
 */
final class WorkforcePlatformCapabilityIndex
{
    private const DEFAULT_INDEX = __DIR__ . '/../../resources/workforce/platform-capability-index.json';

    /** @var array<string,mixed>|null */
    private ?array $index = null;

    public function __construct(private readonly ?string $indexPath = null) {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->index !== null) return $this->index;
        $path = $this->indexPath ?: self::DEFAULT_INDEX;
        if (! is_file($path)) throw new RuntimeException("Titan Workforce platform capability index missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true);
        if (! is_array($decoded)
            || ($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['surfaces'] ?? null)) {
            throw new RuntimeException('Titan Workforce platform capability index is invalid.');
        }
        return $this->index = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public function surfaces(): array
    {
        return array_values(array_filter($this->all()['surfaces'], 'is_array'));
    }

    /** @return list<array<string,mixed>> */
    public function owners(string $surfaceId, ?string $surfaceType = null): array
    {
        $surfaceId = trim($surfaceId);
        if ($surfaceId === '') return [];
        $rows = array_values(array_filter($this->surfaces(), static function (array $row) use ($surfaceId, $surfaceType): bool {
            if ((string) ($row['id'] ?? '') !== $surfaceId) return false;
            return $surfaceType === null || (string) ($row['surface_type'] ?? '') === $surfaceType;
        }));
        usort($rows, static fn (array $a, array $b): int => [
            (string) ($a['provider'] ?? ''), (string) ($a['provider_version'] ?? ''), (string) ($a['surface_type'] ?? '')
        ] <=> [
            (string) ($b['provider'] ?? ''), (string) ($b['provider_version'] ?? ''), (string) ($b['surface_type'] ?? '')
        ]);
        return $rows;
    }

    /** @return list<array<string,mixed>> */
    public function providerSurfaces(string $providerKey): array
    {
        $providerKey = strtolower(trim($providerKey));
        if ($providerKey === '') return [];
        return array_values(array_filter($this->surfaces(), static fn (array $row): bool =>
            strtolower((string) ($row['provider'] ?? '')) === $providerKey
        ));
    }

    public function hasMultipleProviders(string $surfaceId): bool
    {
        $providers = [];
        foreach ($this->owners($surfaceId) as $row) {
            $provider = (string) ($row['provider'] ?? '');
            if ($provider !== '') $providers[$provider] = true;
        }
        return count($providers) > 1;
    }
}
