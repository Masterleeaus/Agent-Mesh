<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Models;
use Illuminate\Database\Eloquent\Model;
final class WorkforceResourceEntitlement extends Model {
 protected $table='ext_titan_ai_workforce_resource_entitlements'; protected $guarded=[];
 protected $casts=['enabled'=>'boolean','metadata'=>'array','valid_from'=>'datetime','valid_until'=>'datetime','usage_allowance'=>'float','usage_used'=>'float','resource_budget'=>'float'];
 public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);} }
