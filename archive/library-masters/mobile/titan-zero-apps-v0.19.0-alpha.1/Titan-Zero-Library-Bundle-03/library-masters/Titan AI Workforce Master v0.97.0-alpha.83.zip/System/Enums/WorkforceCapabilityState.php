<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

/**
 * Live capability availability state.
 *
 * Availability is deliberately separate from authority. A capability can be
 * available while still requiring Risk, Assurance, Governance and Autonomy.
 */
enum WorkforceCapabilityState: string
{
    case Available = 'available';
    case Unavailable = 'unavailable';
    case Degraded = 'degraded';
    case Blocked = 'blocked';
    case MissingProvider = 'missing_provider';
    case PolicyDisabled = 'policy_disabled';
}
