<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

/**
 * Normalizes company/member routing preferences without granting authority.
 */
final class WorkforceProviderRoutingPolicy
{
    /** @return array<string,mixed> */
    public function normalize(array $policy): array
    {
        $preferred = [];
        foreach ((array) ($policy['preferred_providers'] ?? []) as $provider) {
            $provider = strtolower(trim((string) $provider));
            if ($provider !== '' && ! in_array($provider, $preferred, true)) $preferred[] = $provider;
        }
        return [
            'preferred_providers' => $preferred,
            'disabled_providers' => $this->strings((array) ($policy['disabled_providers'] ?? [])),
            'disabled_surfaces' => $this->strings((array) ($policy['disabled_surfaces'] ?? [])),
            'allow_automatic_read_routing' => ($policy['allow_automatic_read_routing'] ?? true) === true,
            'require_exact_write_provider_pin' => true,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return list<string> */
    private function strings(array $values): array
    {
        $out = array_values(array_unique(array_filter(array_map(
            static fn ($value): string => strtolower(trim((string) $value)),
            $values,
        ), static fn (string $value): bool => $value !== '')));
        sort($out);
        return $out;
    }
}
