<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceMemberRating extends Model
{
    protected $table='ext_titan_ai_workforce_member_ratings';
    protected $guarded=[];
    protected $casts=['score'=>'float','dimensions'=>'array','evidence'=>'array','calculated_at'=>'datetime'];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
