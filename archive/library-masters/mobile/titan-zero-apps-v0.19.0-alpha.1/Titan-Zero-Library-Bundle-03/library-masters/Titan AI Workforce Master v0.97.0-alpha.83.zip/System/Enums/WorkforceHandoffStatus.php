<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceHandoffStatus: string
{
    case Pending = 'PENDING';
    case ReceiverReview = 'RECEIVER_REVIEW';
    case Accepted = 'ACCEPTED';
    case Rejected = 'REJECTED';
    case Returned = 'RETURNED';
    case Escalated = 'ESCALATED';
}
