<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceGovernanceDecision;
use InvalidArgumentException;

final class WorkforceHandoffPacketService
{
    public const VERSION = 3;

    public function build(
        WorkforceTask $task,
        WorkforceMember $originManager,
        WorkforceMember $approvedBy,
        WorkforceMember $receivingManager,
        ?WorkforceMember $receivingSpecialist,
        string $handoffUuid,
        ?string $reason,
        array $routingMetadata = [],
    ): array {
        $packet = [
            'packet_version' => self::VERSION,
            'company_id' => (int) $task->company_id,
            'handoff_uuid' => $handoffUuid,
            'source_task_id' => (int) $task->id,
            'source_task_uuid' => (string) $task->task_uuid,
            'source_task_status' => (string) $task->status->value,
            'parent_task_id' => $task->parent_task_id ? (int) $task->parent_task_id : null,
            'origin_member_id' => $task->assignee_member_id ? (int) $task->assignee_member_id : null,
            'origin_manager_id' => (int) $originManager->id,
            'approved_by_member_id' => (int) $approvedBy->id,
            'origin_review' => [
                'history_id' => isset($routingMetadata['origin_manager_review_history_id']) ? (int) $routingMetadata['origin_manager_review_history_id'] : null,
                'reviewed_by_member_id' => isset($routingMetadata['origin_manager_reviewed_by_member_id']) ? (int) $routingMetadata['origin_manager_reviewed_by_member_id'] : null,
            ],
            'origin_division_id' => $task->division_id ? (int) $task->division_id : null,
            'receiving_division_id' => (int) $receivingManager->division_id,
            'receiving_manager_id' => (int) $receivingManager->id,
            'receiving_specialist_id' => $receivingSpecialist?->id ? (int) $receivingSpecialist->id : null,
            'capability' => $task->capability,
            'capability_variant' => $task->capability_variant,
            'risk_level' => (string) $task->risk_level,
            'payload' => $task->payload ?? [],
            'result' => $task->result ?? [],
            'evidence' => $task->evidence ?? [],
            'evidence_refs' => array_values(array_unique(array_merge(
                WorkforceGovernanceDecision::evidenceRefs(is_array($task->evidence) ? $task->evidence : []),
                array_map('strval', is_array(data_get($task->risk_snapshot ?? [], 'evidence_refs')) ? data_get($task->risk_snapshot ?? [], 'evidence_refs') : []),
                array_map('strval', is_array(data_get($task->assurance_snapshot ?? [], 'evidence_refs')) ? data_get($task->assurance_snapshot ?? [], 'evidence_refs') : []),
                array_map('strval', is_array(data_get($task->governance ?? [], 'pre_execution.model_council.evidence_refs')) ? data_get($task->governance ?? [], 'pre_execution.model_council.evidence_refs') : []),
            ))),
            'governance' => $task->governance ?? [],
            'risk_snapshot' => $task->risk_snapshot ?? [],
            'assurance_snapshot' => $task->assurance_snapshot ?? [],
            'autonomy_snapshot' => $task->autonomy_snapshot ?? [],
            'role_provenance' => [
                'owner_extension' => $task->role_owner_extension,
                'owner_extension_version' => $task->role_owner_extension_version,
                'role_definition_id' => $task->role_definition_id,
                'role_definition_version' => $task->role_definition_version,
                'role_definition_sha256' => $task->role_definition_sha256,
            ],
            'routing' => [
                'receiving_role_key' => $routingMetadata['receiving_role_key'] ?? null,
                'receiving_capability' => $routingMetadata['receiving_capability'] ?? $task->capability,
                'planned_handoff' => (bool) ($routingMetadata['planned_handoff'] ?? false),
            ],
            'reason' => $reason,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => (string) $task->task_uuid,
        ];

        $canonical = $this->canonicalize($packet);
        $json = json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        return [
            'packet_version' => self::VERSION,
            'packet_sha256' => hash('sha256', $json),
            'packet' => $canonical,
        ];
    }

    public function verify(WorkforceTaskHandoff $handoff): void
    {
        if (! is_array($handoff->packet) || $handoff->packet === [] || ! is_string($handoff->packet_sha256) || $handoff->packet_sha256 === '') {
            throw new InvalidArgumentException('Workforce handoff packet is missing or incomplete.');
        }
        $canonical = $this->canonicalize($handoff->packet);
        $json = json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $actual = hash('sha256', $json);
        if (! hash_equals((string) $handoff->packet_sha256, $actual)) {
            throw new InvalidArgumentException('Workforce handoff packet integrity check failed.');
        }
    }

    public function canonicalize(array $value): array
    {
        foreach ($value as $key => $item) {
            if (is_array($item)) {
                $value[$key] = $this->isList($item)
                    ? array_map(fn ($row) => is_array($row) ? $this->canonicalize($row) : $row, $item)
                    : $this->canonicalize($item);
            }
        }
        if (! $this->isList($value)) {
            ksort($value, SORT_STRING);
        }
        return $value;
    }

    private function isList(array $value): bool
    {
        return array_is_list($value);
    }
}
