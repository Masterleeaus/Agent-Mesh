<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Carbon\CarbonInterface;

/**
 * Company-wide, read-only intervention inbox.
 *
 * Attention is a projection only: it never mutates work, grants capability,
 * inherits authority, or changes the result of Risk/Assurance/Governance/Autonomy.
 */
final class WorkforceAttentionCenterService
{
    private const REVIEW = ['SUBMITTED', 'UNDER_REVIEW', 'HANDOFF_PENDING', 'RECEIVER_REVIEW'];
    private const BLOCKED = ['BLOCKED', 'AWAITING_DATA', 'RECOVERY'];
    private const EXECUTION_FAILURE = ['COMMAND_BLOCKED', 'RECOVERY_REQUIRED'];

    public function __construct(
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $items = [];
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->with(['assignee:id,name,role','manager:id,name,role'])
            ->orderByDesc('updated_at')->limit(500)->get();

        $this->collectEmployeeHealth($companyId, $items);
        $this->collectTaskInterventions($tasks, $items);
        $this->collectEscalations($companyId, $items);
        $this->collectDeadlocksAndHumanDecisions($companyId, $items);
        $this->collectExecutionFailures($companyId, $items);
        $this->collectUnresolvedOutcomes($companyId, $tasks, $items);
        $this->collectStaffingRecommendations($companyId, $items);

        foreach ($items as &$item) {
            $item['priority_score'] = $item['severity_score'] * $item['business_impact_score'] * $item['age_score'] * $item['blocking_effect_score'];
            $item['authority_inherited'] = false;
        }
        unset($item);

        usort($items, static fn (array $a, array $b): int => [$b['priority_score'], $b['age_hours']] <=> [$a['priority_score'], $a['age_hours']]);

        $counts = [];
        foreach ($items as $item) $counts[$item['category']] = ($counts[$item['category']] ?? 0) + 1;

        return [
            'items' => $items,
            'counts' => $counts,
            'total' => count($items),
            'critical' => count(array_filter($items, static fn (array $item): bool => $item['severity_score'] >= 5)),
            'high' => count(array_filter($items, static fn (array $item): bool => $item['severity_score'] === 4)),
            'authority_inherited' => false,
            'generated_at' => now()->toIso8601String(),
        ];
    }

    /** @param list<array<string,mixed>> $items */
    private function collectEmployeeHealth(int $companyId, array &$items): void
    {
        $members = WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->orderBy('name')->get();
        foreach ($members as $member) {
            $state = $this->capabilityAvailability->forMember($member);
            $raw = (string) ($state['state'] ?? 'unavailable');
            if ($raw === 'available') continue;

            $category = match ($raw) {
                'missing_provider' => 'missing_provider',
                'policy_disabled' => 'policy_disabled',
                default => 'degraded_employee',
            };
            $severity = in_array($raw, ['blocked','missing_provider','unavailable'], true) ? 5 : 3;
            $this->push($items, $category, $severity, 3, $member->updated_at, 2,
                $member->name,
                'Employee capability health requires intervention.',
                route('dashboard.user.titan-workforce.staff.degradation', $member),
                ['member_id' => $member->id, 'state' => $raw]
            );
        }
    }

    /** @param iterable<int,WorkforceTask> $tasks @param list<array<string,mixed>> $items */
    private function collectTaskInterventions(iterable $tasks, array &$items): void
    {
        foreach ($tasks as $task) {
            $status = $task->status?->value ?? (string) $task->status;
            $impact = $this->taskImpact($task);
            $url = route('dashboard.user.titan-workforce.tasks.show', $task);

            if (in_array($status, self::BLOCKED, true)) {
                $this->push($items, 'blocked_work', 4, $impact, $task->last_activity_at ?? $task->updated_at, 5, $task->title, 'Work is blocked, awaiting data, or in recovery.', $url, ['task_id'=>$task->id,'status'=>$status]);
            }
            if (in_array($status, self::REVIEW, true)) {
                $this->push($items, 'manager_review', 3, $impact, $task->updated_at, 3, $task->title, 'Manager review is waiting.', $url, ['task_id'=>$task->id,'manager'=>$task->manager?->name]);
            }

            $assuranceState = strtoupper((string) data_get($task->assurance_snapshot ?? [], 'state', ''));
            if (in_array($assuranceState, ['FAILED','DENIED','RED','BLOCKED'], true)) {
                $this->push($items, 'assurance_failure', 5, $impact, $task->updated_at, 5, $task->title, 'Assurance did not verify the proposed consequential work.', $url, ['task_id'=>$task->id,'assurance_state'=>$assuranceState]);
            }
            $allowed = data_get($task->autonomy_snapshot ?? [], 'allowed');
            if ($allowed === false) {
                $this->push($items, 'autonomy_denial', 5, $impact, $task->updated_at, 5, $task->title, 'Titan Autonomy denied execution.', $url, ['task_id'=>$task->id]);
            }
        }
    }

    /** @param list<array<string,mixed>> $items */
    private function collectEscalations(int $companyId, array &$items): void
    {
        foreach (WorkforceEscalation::query()->forCompany($companyId)->where('status', 'OPEN')->orderByDesc('created_at')->limit(100)->get() as $escalation) {
            $task = $escalation->task_id ? WorkforceTask::query()->forCompany($companyId)->find($escalation->task_id) : null;
            $this->push($items, 'escalation', 5, $task ? $this->taskImpact($task) : 4, $escalation->created_at, 5,
                $task?->title ?? 'Open escalation',
                (string) ($escalation->recommended_action ?: $escalation->reason_code),
                $task ? route('dashboard.user.titan-workforce.tasks.show', $task) : route('dashboard.user.titan-workforce.tasks'),
                ['escalation_id'=>$escalation->id,'task_id'=>$escalation->task_id]
            );
        }
    }

    /** @param list<array<string,mixed>> $items */
    private function collectDeadlocksAndHumanDecisions(int $companyId, array &$items): void
    {
        $events = WorkforceTaskHistory::query()->where('company_id', $companyId)
            ->whereIn('event', ['deadlock.escalated','deadlock.human_required'])
            ->orderByDesc('created_at')->limit(100)->get();
        foreach ($events as $history) {
            $task = WorkforceTask::query()->forCompany($companyId)->find($history->task_id);
            if (! $task || in_array($task->status?->value ?? (string) $task->status, ['COMPLETED','FAILED','CANCELLED','REJECTED'], true)) continue;
            $category = $history->event === 'deadlock.human_required' ? 'human_decision_required' : 'deadlock';
            $this->push($items, $category, 5, $this->taskImpact($task), $history->created_at, 5, $task->title,
                $category === 'human_decision_required' ? 'A human decision is explicitly required.' : 'A governed deadlock remains unresolved.',
                route('dashboard.user.titan-workforce.tasks.show', $task), ['task_id'=>$task->id,'history_id'=>$history->id]);
        }
    }

    /** @param list<array<string,mixed>> $items */
    private function collectExecutionFailures(int $companyId, array &$items): void
    {
        foreach (WorkforceExecutionAttempt::query()->where('company_id', $companyId)->whereIn('status', self::EXECUTION_FAILURE)->orderByDesc('created_at')->limit(100)->get() as $attempt) {
            $task = WorkforceTask::query()->forCompany($companyId)->find($attempt->task_id);
            if (! $task) continue;
            $this->push($items, 'execution_failure', 5, $this->taskImpact($task), $attempt->updated_at ?? $attempt->created_at, 5,
                $task->title, 'A consequential execution attempt failed or requires recovery.',
                route('dashboard.user.titan-workforce.tasks.show', $task), ['task_id'=>$task->id,'attempt_id'=>$attempt->id,'status'=>$attempt->status]);
        }
    }

    /** @param iterable<int,WorkforceTask> $tasks @param list<array<string,mixed>> $items */
    private function collectUnresolvedOutcomes(int $companyId, iterable $tasks, array &$items): void
    {
        $verifiedTaskIds = WorkforceOutcome::query()->forCompany($companyId)->whereNotNull('verified_at')->whereNotNull('task_id')->pluck('task_id')->map(fn ($id) => (int) $id)->all();
        $verified = array_fill_keys($verifiedTaskIds, true);
        foreach ($tasks as $task) {
            if (($task->status?->value ?? (string) $task->status) !== 'COMPLETED') continue;
            if (isset($verified[(int) $task->id])) continue;
            if (! $task->expected_outcome && ! data_get($task->metadata ?? [], 'requires_outcome_verification', false)) continue;
            $this->push($items, 'unresolved_outcome', 3, $this->taskImpact($task), $task->completed_at ?? $task->updated_at, 2,
                $task->title, 'Completed work is still waiting for an authoritative verified outcome.',
                route('dashboard.user.titan-workforce.tasks.show', $task), ['task_id'=>$task->id]);
        }
    }

    /** @param list<array<string,mixed>> $items */
    private function collectStaffingRecommendations(int $companyId, array &$items): void
    {
        foreach (WorkforceStaffingProposal::query()->forCompany($companyId)->where('status', 'RECOMMENDED')->orderByDesc('recommended_at')->limit(100)->get() as $proposal) {
            $this->push($items, 'staffing_recommendation', 2, 2, $proposal->recommended_at ?? $proposal->created_at, 1,
                'Staffing recommendation', 'Workforce Planning has an unreviewed staffing recommendation.',
                route('dashboard.user.titan-workforce.control-room'), ['proposal_id'=>$proposal->id]);
        }
    }

    /** @param list<array<string,mixed>> $items @param array<string,mixed> $context */
    private function push(array &$items, string $category, int $severity, int $impact, $createdAt, int $blocking, string $title, string $detail, string $url, array $context = []): void
    {
        $ageHours = max(1, $createdAt instanceof CarbonInterface ? (int) $createdAt->diffInHours(now()) : 1);
        $ageScore = match (true) { $ageHours >= 168 => 5, $ageHours >= 72 => 4, $ageHours >= 24 => 3, $ageHours >= 4 => 2, default => 1 };
        $items[] = [
            'category' => $category,
            'severity_score' => max(1, min(5, $severity)),
            'business_impact_score' => max(1, min(5, $impact)),
            'age_score' => $ageScore,
            'blocking_effect_score' => max(1, min(5, $blocking)),
            'priority_score' => 0,
            'age_hours' => $ageHours,
            'title' => $title,
            'detail' => $detail,
            'url' => $url,
            'context' => $context,
        ];
    }

    private function taskImpact(WorkforceTask $task): int
    {
        $risk = strtoupper((string) ($task->risk_level ?? 'LOW'));
        $riskScore = ['CRITICAL'=>5,'HIGH'=>4,'MEDIUM'=>3,'LOW'=>2][$risk] ?? 2;
        $priorityScore = max(1, min(5, (int) ceil(((int) ($task->priority ?? 50)) / 20)));
        return max($riskScore, $priorityScore);
    }
}
