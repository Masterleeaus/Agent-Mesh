<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceWorkItemVerificationState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceWorkItemService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceGoalService $goals,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
    ) {}

    public function create(
        int $companyId,
        WorkforceGoal $goal,
        WorkforceMember $assignee,
        array $data,
        ?WorkforceMember $actor = null,
    ): WorkforceTask {
        if ((int) $goal->company_id !== $companyId || (int) $assignee->company_id !== $companyId) {
            throw new InvalidArgumentException('Goal, assignee and Work Item must share company_id.');
        }
        $responsibilityId = trim((string) ($data['responsibility_id'] ?? ''));
        if ($responsibilityId === '') throw new InvalidArgumentException('Work Item requires a canonical responsibility.');
        $requirement = $this->requirements->forResponsibility($responsibilityId);
        if (! is_array($requirement)) throw new InvalidArgumentException('Work Item responsibility is not canonical.');
        if ((string) ($requirement['role_definition_id'] ?? '') !== (string) $assignee->role_definition_id) {
            throw new InvalidArgumentException('Work Item responsibility does not belong to the assignee role.');
        }

        $expectedOutcome = $data['expected_outcome'] ?? null;
        $evidenceRequirements = $data['evidence_requirements'] ?? null;
        if (! is_array($expectedOutcome) || $expectedOutcome === []) {
            throw new InvalidArgumentException('Work Item requires an explicit expected outcome.');
        }
        if (! is_array($evidenceRequirements) || $evidenceRequirements === []) {
            throw new InvalidArgumentException('Work Item requires evidence requirements.');
        }
        $capability = trim((string) ($data['capability'] ?? ''));
        if ($capability === '' || ! in_array($capability, (array) ($requirement['candidate_capabilities'] ?? []), true)) {
            throw new InvalidArgumentException('Work Item capability is not allowed by the responsibility contract.');
        }

        $workItemUuid = (string) ($data['work_item_uuid'] ?? Str::uuid());
        $metadata = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
        $metadata['work_item_contract'] = [
            'schema_version' => '1.0',
            'goal_uuid' => (string) $goal->goal_uuid,
            'responsibility_id' => $responsibilityId,
            'requires_expected_outcome' => true,
            'requires_evidence' => true,
            'requires_verification' => true,
            'completion_requires_verified_outcome' => true,
        ];

        $task = $this->tasks->create($companyId, array_merge($data, [
            'work_item_uuid' => $workItemUuid,
            'goal_id' => (int) $goal->id,
            'responsibility_id' => $responsibilityId,
            'assignee_member_id' => (int) $assignee->id,
            'expected_outcome' => $expectedOutcome,
            'evidence_requirements' => $evidenceRequirements,
            'verification_state' => WorkforceWorkItemVerificationState::Pending,
            'outcome_target_key' => trim((string) ($data['outcome_target_key'] ?? '')) ?: null,
            'orchestration_group' => trim((string) ($data['orchestration_group'] ?? '')) ?: null,
            'sequence_index' => isset($data['sequence_index']) ? max(0, (int) $data['sequence_index']) : null,
            'estimated_minutes' => isset($data['estimated_minutes']) ? max(1, (int) $data['estimated_minutes']) : null,
            'max_attempts' => max(1, min(20, (int) ($data['max_attempts'] ?? 3))),
            'retry_strategy' => in_array((string) ($data['retry_strategy'] ?? 'exponential'), ['none','fixed','linear','exponential'], true)
                ? (string) ($data['retry_strategy'] ?? 'exponential') : 'exponential',
            'compensation_capability' => trim((string) ($data['compensation_capability'] ?? '')) ?: null,
            'critical_path' => false,
            'blocked_by_graph' => false,
            'work_type' => $data['work_type'] ?? 'business_work_item',
            'metadata' => $metadata,
        ]), $actor);

        $this->goals->activate($goal);
        return $task;
    }

    public function refreshVerification(WorkforceTask $workItem): WorkforceTask
    {
        if (! $workItem->work_item_uuid || ! $workItem->goal_id || ! $workItem->responsibility_id) {
            throw new InvalidArgumentException('Task is not a canonical Work Item.');
        }

        $evidenceRequired = count((array) ($workItem->evidence_requirements ?? [])) > 0;
        $evidenceCount = WorkforceEvidence::query()->forCompany((int) $workItem->company_id)->where('task_id', $workItem->id)->count();
        $verifiedOutcome = WorkforceOutcome::query()
            ->forCompany((int) $workItem->company_id)
            ->where('task_id', $workItem->id)
            ->whereNotNull('verified_at')
            ->where('success', true)
            ->exists();
        $failedOutcome = WorkforceOutcome::query()
            ->forCompany((int) $workItem->company_id)
            ->where('task_id', $workItem->id)
            ->whereNotNull('verified_at')
            ->where('success', false)
            ->exists();

        $state = WorkforceWorkItemVerificationState::Pending;
        if ($failedOutcome) {
            $state = WorkforceWorkItemVerificationState::RemediationRequired;
        } elseif ($verifiedOutcome && (! $evidenceRequired || $evidenceCount > 0)) {
            $state = WorkforceWorkItemVerificationState::Verified;
        } elseif ($evidenceRequired && $evidenceCount === 0) {
            $state = WorkforceWorkItemVerificationState::EvidencePending;
        } elseif ($evidenceCount > 0) {
            $state = WorkforceWorkItemVerificationState::Ready;
        }

        $workItem->forceFill(['verification_state' => $state])->save();
        $goal = WorkforceGoal::query()->forCompany((int) $workItem->company_id)->find((int) $workItem->goal_id);
        if ($goal) $this->goals->reconcile($goal);

        return $workItem->refresh();
    }

    public function assertCompletable(WorkforceTask $workItem): void
    {
        $workItem = $this->refreshVerification($workItem);
        if ($workItem->verification_state !== WorkforceWorkItemVerificationState::Verified) {
            throw new InvalidArgumentException('Work Item cannot complete until its expected business outcome is verified with required evidence.');
        }
    }

    public function complete(WorkforceTask $workItem, ?WorkforceMember $actor = null): WorkforceTask
    {
        return DB::transaction(function () use ($workItem, $actor): WorkforceTask {
            $this->assertCompletable($workItem);
            return $this->tasks->transition(
                $workItem->refresh(),
                WorkforceTaskStatus::Completed,
                $actor,
                'work_item.completed_verified',
                null,
                ['verification_state' => WorkforceWorkItemVerificationState::Verified->value],
            );
        });
    }
}
