<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use LogicException;

class WorkforceTaskHistory extends Model
{
    protected $table = 'ext_titan_ai_workforce_task_history';
    protected $guarded = [];
    protected $casts = ['context' => 'array', 'created_at' => 'datetime'];
    public $timestamps = false;

    protected static function booted(): void
    {
        static::updating(fn () => throw new LogicException('Immutable Workforce task history cannot be modified.'));
        static::deleting(fn () => throw new LogicException('Immutable Workforce task history cannot be modified.'));
    }
}
