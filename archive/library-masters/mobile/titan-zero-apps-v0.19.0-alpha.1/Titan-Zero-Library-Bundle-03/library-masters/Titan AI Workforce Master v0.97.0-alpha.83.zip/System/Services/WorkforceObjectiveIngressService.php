<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

final class WorkforceObjectiveIngressService
{
    public function __construct(private readonly WorkforceTaskService $tasks) {}

    public function receive(int $companyId, array $objective): WorkforceTask
    {
        $sourceProvider = trim((string) ($objective['source_provider'] ?? $objective['origin_type'] ?? 'titan-ai-core'));
        if (! in_array($sourceProvider, ['titan-ai-core','titan-prime','titan-zero'], true)) {
            throw new InvalidArgumentException('Unsupported Workforce objective source provider.');
        }
        $objective['source_provider'] = $sourceProvider;
        $objective['control_plane_stage'] = $sourceProvider === 'titan-prime' ? 'mission' : 'plan';

        $manager = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)->where('tier', WorkforceTier::Manager->value)
            ->when(!empty($objective['manager_key']), fn($q) => $q->where('key', $objective['manager_key']))
            ->when(empty($objective['manager_key']) && !empty($objective['division_id']), fn($q) => $q->where('division_id', $objective['division_id']))
            ->orderByRaw("CASE WHEN `key` = 'operations-manager' THEN 0 ELSE 1 END")->first();
        if (! $manager) { throw new InvalidArgumentException('No eligible Workforce Manager is available for this objective.'); }

        $task = $this->tasks->create($companyId, [
            'title' => (string) ($objective['title'] ?? 'Titan objective'),
            'description' => $objective['description'] ?? null,
            'payload' => $objective,
            'assignee_member_id' => $manager->id,
            'manager_member_id' => $manager->manager_id,
            'division_id' => $manager->division_id,
            'team_id' => $manager->team_id,
            'origin_type' => $sourceProvider,
            'origin_id' => (string) ($objective['objective_id'] ?? ''),
            'priority' => (int) ($objective['priority'] ?? 50),
            'risk_level' => (string) ($objective['risk_level'] ?? 'LOW'),
            'trace_id' => $objective['trace_id'] ?? null,
            'correlation_id' => $objective['correlation_id'] ?? null,
            'causation_id' => $objective['causation_id'] ?? null,
            'idempotency_key' => $objective['idempotency_key'] ?? null,
        ], $manager);
        ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);
        return $task;
    }
}
