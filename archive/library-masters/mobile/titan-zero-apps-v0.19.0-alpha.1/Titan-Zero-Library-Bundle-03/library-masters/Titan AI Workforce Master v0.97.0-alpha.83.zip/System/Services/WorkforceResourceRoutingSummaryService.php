<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCostReceipt;

final class WorkforceResourceRoutingSummaryService
{
    /** @return array<string,mixed> */
    public function monthly(int $companyId, ?\DateTimeInterface $at = null): array
    {
        $at ??= now();
        $start = \Illuminate\Support\Carbon::instance(\DateTime::createFromInterface($at))->startOfMonth();
        $end = (clone $start)->endOfMonth();
        $rows = WorkforceCostReceipt::query()->forCompany($companyId)->whereBetween('created_at', [$start, $end])->get();
        $total=max(1,$rows->count());
        $byLocation=[]; $byOwner=[]; $titan=0.0; $customer=0.0;
        foreach($rows as $row){
            $loc=(string)$row->execution_location; $owner=(string)$row->cost_owner;
            $byLocation[$loc]=($byLocation[$loc]??0)+1; $byOwner[$owner]=($byOwner[$owner]??0)+1;
            if($owner==='titan')$titan+=(float)$row->actual_cost; elseif($owner==='customer')$customer+=(float)$row->actual_cost;
        }
        $percent=[]; foreach($byLocation as $k=>$n)$percent[$k]=round($n*100/$total,1);
        return ['company_id'=>$companyId,'period'=>$start->format('Y-m'),'operations'=>$rows->count(),'execution_location_percent'=>$percent,'cost_owner_counts'=>$byOwner,'titan_managed_actual_cost'=>$titan,'customer_owned_reported_cost'=>$customer,'currency'=>'mixed_or_receipt_currency'];
    }
}
