<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceGoalStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceGoal extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_goals';
    protected $guarded = [];
    protected $casts = [
        'status' => WorkforceGoalStatus::class,
        'outcome_target' => 'array',
        'success_criteria' => 'array',
        'context_refs' => 'array',
        'metadata' => 'array',
        'target_at' => 'datetime',
        'achieved_at' => 'datetime',
    ];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function workItems(): HasMany { return $this->hasMany(WorkforceTask::class, 'goal_id'); }
}
