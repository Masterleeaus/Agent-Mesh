<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceRoleResponsibility extends Model
{
    protected $table = 'ext_titan_ai_workforce_role_responsibilities';
    protected $guarded = [];
    protected $casts = ['metadata' => 'array', 'is_required' => 'boolean', 'authority_inherited' => 'boolean'];

    public function scopeVisibleToCompany($query, int $companyId) { return $query->where(function ($q) use ($companyId) { $q->whereNull('company_id')->orWhere('company_id', $companyId); }); }
}
