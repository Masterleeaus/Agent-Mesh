<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\ProactiveManagerService;
use Illuminate\Console\Command;

class RunWorkforceProactiveManagementCommand extends Command
{
    protected $signature = 'titan-workforce:proactive-management {--limit=100}';
    protected $description = 'Run organisational queue-health, workload-balancing and staffing recommendation checks.';

    public function handle(ProactiveManagerService $service): int
    {
        $summary = $service->runAll((int) $this->option('limit'));
        $this->info(json_encode($summary, JSON_UNESCAPED_SLASHES));
        return self::SUCCESS;
    }
}
