<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class IntrinsicRelationshipCatalog
{
    /** @var array<string,mixed>|null */
    private static ?array $cache = null;

    /** @return array<string,mixed> */
    public static function blueprint(): array
    {
        if (self::$cache !== null) return self::$cache;
        $path = dirname(__DIR__, 2).'/resources/workforce/organisational-relationships.json';
        if (! is_file($path)) throw new RuntimeException('Intrinsic organisational relationship catalogue is missing.');
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded) || ($decoded['schema'] ?? null) !== 'titan.workforce.org-relationships.v1') {
            throw new RuntimeException('Intrinsic organisational relationship catalogue schema drift detected.');
        }
        return self::$cache = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public static function relationships(): array
    {
        return array_values(array_filter((array) (self::blueprint()['relationships'] ?? []), 'is_array'));
    }
}
