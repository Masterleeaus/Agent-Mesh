<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceEvidence extends Model
{
    protected $table = 'ext_titan_ai_workforce_evidence';
    protected $guarded = [];
    protected $casts = ['payload' => 'array', 'observed_at' => 'datetime'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
