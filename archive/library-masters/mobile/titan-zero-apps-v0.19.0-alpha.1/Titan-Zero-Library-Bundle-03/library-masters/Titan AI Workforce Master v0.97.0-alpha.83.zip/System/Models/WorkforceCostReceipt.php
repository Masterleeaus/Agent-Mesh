<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Models;
use Illuminate\Database\Eloquent\Model;
final class WorkforceCostReceipt extends Model {
 protected $table='ext_titan_ai_workforce_cost_receipts'; protected $guarded=[];
 protected $casts=['estimated_cost'=>'float','actual_cost'=>'float','billing_units'=>'float','usage'=>'array','approval'=>'array','outcome'=>'array','metadata'=>'array'];
 public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);} }
