<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResourceBudget;
use Illuminate\Support\Facades\DB;

final class WorkforceResourceBudgetService
{
    /** @return array{allowed:bool,reason:string,remaining:?float,projected:?float} */
    public function authorize(int $companyId, string $resourceType, float $estimatedCost, string $autonomyLevel, bool $explicitApproval): array
    {
        $budget = WorkforceResourceBudget::query()->forCompany($companyId)->where('resource_type', $resourceType)->first();
        if (! $budget) return ['allowed'=>true,'reason'=>'NO_MANAGED_BUDGET_CONFIGURED','remaining'=>null,'projected'=>null];
        $projected = (float) $budget->spent_amount + max(0.0, $estimatedCost);
        $remaining = $budget->hard_limit === null ? null : max(0.0, (float) $budget->hard_limit - (float) $budget->spent_amount);
        if ($budget->hard_limit !== null && $projected > (float) $budget->hard_limit) return ['allowed'=>false,'reason'=>'RESOURCE_HARD_BUDGET_EXCEEDED','remaining'=>$remaining,'projected'=>$projected];
        if (in_array($autonomyLevel, ['semi_autonomous','autonomous','predictive'], true)
            && $budget->autonomous_spend_ceiling !== null
            && $estimatedCost > (float) $budget->autonomous_spend_ceiling
            && ! $explicitApproval) {
            return ['allowed'=>false,'reason'=>'AUTONOMOUS_SPEND_APPROVAL_REQUIRED','remaining'=>$remaining,'projected'=>$projected];
        }
        return ['allowed'=>true,'reason'=>'WITHIN_RESOURCE_BUDGET','remaining'=>$remaining,'projected'=>$projected];
    }

    public function consume(int $companyId, string $resourceType, float $actualCost): bool
    {
        if ($actualCost < 0) return false;
        return DB::transaction(function () use ($companyId, $resourceType, $actualCost): bool {
            $budget = WorkforceResourceBudget::query()->forCompany($companyId)->where('resource_type', $resourceType)->lockForUpdate()->first();
            if (! $budget) return true;
            $projected = (float) $budget->spent_amount + $actualCost;
            if ($budget->hard_limit !== null && $projected > (float) $budget->hard_limit) return false;
            $budget->spent_amount = $projected;
            $budget->save();
            return true;
        });
    }

}
