<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Runtime;

use InvalidArgumentException;

final readonly class RuntimeRequest
{
    /**
     * @param array<string, mixed> $payload
     * @param array<int, string> $toolPermissions
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        public RuntimeIdentity $identity,
        public string $instruction,
        public array $payload = [],
        public array $toolPermissions = [],
        public array $metadata = [],
        public string $responseMode = 'json',
        public ?string $idempotencyKey = null,
    ) {
        if (trim($instruction) === '') {
            throw new InvalidArgumentException('Agent Runtime request requires a non-empty instruction.');
        }
        if ($identity->workforceMemberId === null || $identity->workforceMemberId < 1) {
            throw new InvalidArgumentException('Workforce Agent Runtime request requires workforce_member_id.');
        }
        if ($identity->workforceTaskId === null || $identity->workforceTaskId < 1) {
            throw new InvalidArgumentException('Workforce Agent Runtime request requires workforce_task_id.');
        }
        if ($idempotencyKey !== null && trim($idempotencyKey) === '') {
            throw new InvalidArgumentException('Agent Runtime idempotency key cannot be blank.');
        }
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'protocol' => 'titan.agent-runtime/1',
            'identity' => $this->identity->toArray(),
            'instruction' => $this->instruction,
            'payload' => $this->payload,
            'tool_permissions' => array_values(array_unique(array_map('strval', $this->toolPermissions))),
            'metadata' => $this->metadata,
            'response_mode' => $this->responseMode,
            'idempotency_key' => $this->idempotencyKey,
        ];
    }
}
