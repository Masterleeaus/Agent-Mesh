<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOperationLedger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceConcurrencyGuardService
{
    /** @return array{ledger:WorkforceOperationLedger,replayed:bool} */
    public function begin(int $companyId,string $operationKey,string $operationType,array $payload): array
    {
        $payloadHash=$this->sha($payload);

        return DB::transaction(function() use($companyId,$operationKey,$operationType,$payload,$payloadHash){
            $existing=WorkforceOperationLedger::query()->forCompany($companyId)
                ->where('operation_key',$operationKey)->lockForUpdate()->first();

            if($existing){
                if(!hash_equals((string)$existing->payload_sha256,$payloadHash)){
                    throw new RuntimeException('IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_PAYLOAD');
                }
                $existing->forceFill(['replay_count'=>(int)$existing->replay_count+1])->save();
                if($existing->status==='PROCESSING') {
                    throw new RuntimeException('IDENTICAL_OPERATION_ALREADY_IN_PROGRESS');
                }
                if($existing->status==='FAILED') {
                    $existing->forceFill(['status'=>'PROCESSING','started_at'=>now(),'completed_at'=>null])->save();
                    return ['ledger'=>$existing->refresh(),'replayed'=>false];
                }
                return ['ledger'=>$existing->refresh(),'replayed'=>$existing->status==='COMPLETED'];
            }

            $ledger=WorkforceOperationLedger::query()->create([
                'operation_uuid'=>(string)Str::uuid(),
                'company_id'=>$companyId,'operation_key'=>$operationKey,'operation_type'=>$operationType,
                'payload_sha256'=>$payloadHash,'status'=>'PROCESSING','replay_count'=>0,'started_at'=>now(),
            ]);
            return ['ledger'=>$ledger,'replayed'=>false];
        },3);
    }

    public function complete(
        WorkforceOperationLedger $ledger,
        string $resultType,
        string $resultRef,
        array $snapshot=[]
    ): WorkforceOperationLedger {
        return DB::transaction(function() use($ledger,$resultType,$resultRef,$snapshot){
            $locked=WorkforceOperationLedger::query()->forCompany((int)$ledger->company_id)
                ->whereKey($ledger->getKey())->lockForUpdate()->firstOrFail();
            if($locked->status==='COMPLETED') return $locked;
            $locked->forceFill([
                'status'=>'COMPLETED','result_type'=>$resultType,'result_ref'=>$resultRef,
                'result_snapshot'=>$snapshot,'completed_at'=>now(),
            ])->save();
            return $locked->refresh();
        },3);
    }

    public function fail(WorkforceOperationLedger $ledger,string $reason): void
    {
        WorkforceOperationLedger::query()->forCompany((int)$ledger->company_id)
            ->whereKey($ledger->getKey())->update([
                'status'=>'FAILED',
                'result_snapshot'=>json_encode(['reason'=>$reason],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
                'updated_at'=>now(),
            ]);
    }

    private function sha(array $payload): string
    {
        $normalize=function($v) use (&$normalize){
            if(!is_array($v)) return $v;
            if(array_is_list($v)) return array_map($normalize,$v);
            ksort($v,SORT_STRING);
            foreach($v as $k=>$x)$v[$k]=$normalize($x);
            return $v;
        };
        return hash('sha256',json_encode($normalize($payload),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
    }
}
