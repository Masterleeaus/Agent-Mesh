<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;

/**
 * Guided Workforce setup. Planning is advisory; applying setup creates organisation
 * containers only. Hiring and authority remain explicit downstream approvals.
 */
final class WorkforceSetupWizardService
{
    public function __construct(
        private readonly WorkforceBootstrapService $bootstrap,
        private readonly WorkforcePlanningIntelligenceService $planning,
    ) {}

    public function preview(int $companyId, array $businessProfile = []): array
    {
        $tier = strtoupper((string)($businessProfile['business_tier'] ?? 'SMALL'));
        $verticals = array_values(array_filter((array)($businessProfile['verticals'] ?? []),'is_string'));
        $plan = $this->planning->snapshot($companyId, $tier, $verticals);
        $roles = collect((array)($plan['proposed_roles'] ?? []))->take(12)->values()->all();

        return [
            'business_profile'=>['business_tier'=>$tier,'verticals'=>$verticals,'operating_mode'=>(string)($businessProfile['operating_mode'] ?? 'balanced')],
            'recommended_structure'=>['divisions'=>collect($plan['division_metrics'] ?? [])->keys()->values()->all(),'teams'=>collect($plan['overloaded_teams'] ?? [])->pluck('team')->values()->all()],
            'recommended_roles'=>$roles,
            'provider_readiness'=>['capability_gaps'=>$plan['capability_gaps'] ?? [],'ready'=>empty($plan['capability_gaps'])],
            'responsibility_coverage'=>['gaps'=>$plan['responsibility_gaps'] ?? [],'gap_count'=>count($plan['responsibility_gaps'] ?? [])],
            'review_before_apply'=>true,
            'approval_required'=>true,
            'auto_hire'=>false,
            'authority_inherited'=>false,
            'execution_authority_granted'=>false,
        ];
    }

    public function apply(int $companyId, array $businessProfile): array
    {
        $preview=$this->preview($companyId,$businessProfile);
        $divisions=$this->bootstrap->ensureDivisions($companyId);
        return [
            'applied'=>true,
            'organisation_containers_created'=>count($divisions),
            'employees_created'=>0,
            'next_step'=>'Review recommended roles in Workforce Planning / Employee Builder.',
            'preview'=>$preview,
            'approval_required'=>true,
            'authority_inherited'=>false,
            'execution_authority_granted'=>false,
        ];
    }
}
