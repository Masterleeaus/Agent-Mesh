<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceExecutionReceipt;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Throwable;

final class WorkforceExecutionRecoveryService
{
    public function __construct(
        private readonly WorkforceCapabilityBindingRegistry $manifests,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    /** @return array<string,mixed> */
    public function reconcileReceipt(WorkforceExecutionAttempt $attempt, WorkforceTask $task, WorkforceMember $worker): array
    {
        $resolved = $this->controlPlane->resolve('command_bus');
        if ($resolved === null) return $this->persistRecovery($attempt, ['recovered' => false, 'reason_code' => 'RECOVERY_REQUIRED']);
        $bus = $resolved['service'];
        $payload = [
            'company_id' => (int) $task->company_id,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'intent_id' => (string) $attempt->intent_id,
            'intent_sha256' => (string) $attempt->intent_sha256,
            'idempotency_key' => (string) $attempt->idempotency_key,
            'actor_member_id' => (int) $worker->id,
        ];
        foreach (['reconcileReceipt','reconcile','status'] as $method) {
            if (! method_exists($bus, $method)) continue;
            try { $result = $bus->{$method}($payload); }
            catch (Throwable $e) { return $this->persistRecovery($attempt, ['recovered' => false, 'reason_code' => 'RECOVERY_REQUIRED', 'error' => mb_substr($e->getMessage(), 0, 1000)]); }
            if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
            if (! is_array($result)) continue;
            $receipt = $result['receipt'] ?? null;
            if ($receipt === null) continue;
            try { $checked = WorkforceExecutionReceipt::validate($receipt, $this->expectedReceiptIdentity($attempt, $task)); }
            catch (Throwable $e) { return $this->persistRecovery($attempt, ['recovered' => false, 'reason_code' => 'RECEIPT_INVALID', 'error' => mb_substr($e->getMessage(), 0, 1000)]); }
            $this->storeReceipt($attempt, $checked, 'RECONCILED');
            return $this->persistRecovery($attempt, ['recovered' => true, 'reason_code' => 'RECEIPT_RECONCILED', 'receipt' => $checked, 'receipt_ref' => $checked['receipt_id']]);
        }
        return $this->persistRecovery($attempt, ['recovered' => false, 'reason_code' => 'RECOVERY_REQUIRED']);
    }

    /** @return array<string,mixed> */
    public function compensate(WorkforceExecutionAttempt $attempt, WorkforceTask $task, WorkforceMember $worker, string $reason, array $governance = []): array
    {
        if (($governance['allowed'] ?? false) !== true || empty($governance['risk_decision_id']) || empty($governance['autonomy_decision_id'])) {
            return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'RECOVERY_GOVERNANCE_REQUIRED']);
        }
        $owner = trim((string) ($task->capability_owner_extension ?? ''));
        if ($owner === '') {
            $owners = $this->manifests->ownersForCapability((string) $worker->role_definition_id, (string) $task->capability);
            $owner = count($owners) === 1 ? $owners[0] : '';
        }
        $capability = $owner !== '' ? $this->manifests->findOwnedCapability($owner, (string) $task->capability, $task->capability_variant) : null;
        $reversibility = (string) ($capability['reversibility'] ?? 'irreversible');
        if (! in_array($reversibility, ['reversible','compensatable'], true)) {
            return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'HUMAN_DECISION_REQUIRED', 'reversibility' => $reversibility]);
        }
        $resolved = $this->controlPlane->resolve('command_bus');
        if ($resolved === null) return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'RECOVERY_REQUIRED']);
        $bus = $resolved['service'];
        $payload = [
            'company_id' => (int) $task->company_id,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'intent_id' => (string) $attempt->intent_id,
            'idempotency_key' => (string) $attempt->idempotency_key,
            'receipt' => $attempt->receipt,
            'receipt_ref' => $attempt->receipt_ref,
            'reason' => $reason,
            'reversibility' => $reversibility,
            'governance' => [
                'risk_decision_id' => $governance['risk_decision_id'],
                'assurance_decision_id' => $governance['assurance_decision_id'] ?? null,
                'autonomy_decision_id' => $governance['autonomy_decision_id'],
            ],
        ];
        foreach (['compensate','rollback','reverse'] as $method) {
            if (! method_exists($bus, $method)) continue;
            try { $result = $bus->{$method}($payload); }
            catch (Throwable $e) { return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'RECOVERY_REQUIRED', 'error' => mb_substr($e->getMessage(), 0, 1000)]); }
            if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
            $result = is_array($result) ? $result : ['compensation_ref' => $result];
            $ref = $result['compensation_ref'] ?? $result['receipt_ref'] ?? $result['id'] ?? null;
            if (! $ref) return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'RECOVERY_REQUIRED']);
            $attempt->forceFill(['compensation_ref' => (string) $ref, 'status' => 'COMPENSATED'])->save();
            return $this->persistRecovery($attempt, array_merge($result, ['compensated' => true, 'reason_code' => 'COMPENSATED', 'compensation_ref' => (string) $ref]));
        }
        return $this->persistRecovery($attempt, ['compensated' => false, 'reason_code' => 'RECOVERY_REQUIRED']);
    }

    public function storeReceipt(WorkforceExecutionAttempt $attempt, array $receipt, string $status = 'RECEIPT_VALIDATED'): void
    {
        $attempt->forceFill([
            'receipt' => $receipt,
            'receipt_ref' => (string) ($receipt['receipt_id'] ?? ''),
            'receipt_sha256' => (string) ($receipt['receipt_sha256'] ?? WorkforceExecutionReceipt::sha256($receipt)),
            'status' => $status,
        ])->save();
    }

    /** @return array<string,mixed> */
    private function persistRecovery(WorkforceExecutionAttempt $attempt, array $value): array
    {
        $attributes = ['recovery' => array_merge($attempt->recovery ?? [], $value)];
        if (($value['recovered'] ?? null) === false || ($value['compensated'] ?? null) === false) {
            $attributes['status'] = 'RECOVERY_REQUIRED';
        }
        $attempt->forceFill($attributes)->save();
        return $value;
    }

    /** @return array<string,mixed> */
    private function expectedReceiptIdentity(WorkforceExecutionAttempt $attempt, WorkforceTask $task): array
    {
        return [
            'company_id' => (int) $task->company_id,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'intent_id' => (string) $attempt->intent_id,
            'intent_sha256' => (string) $attempt->intent_sha256,
            'idempotency_key' => (string) $attempt->idempotency_key,
        ];
    }
}
