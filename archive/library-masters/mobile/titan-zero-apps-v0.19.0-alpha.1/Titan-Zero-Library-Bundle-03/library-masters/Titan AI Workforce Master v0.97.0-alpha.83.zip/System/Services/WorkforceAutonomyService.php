<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceAutonomyDecision;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use RuntimeException;
use Throwable;

/**
 * Workforce adapter to Titan Autonomy continuous authority.
 *
 * Titan Autonomy owns earned/effective authority. Workforce only validates the
 * exact capability decision and may impose additional restrictive local caps.
 */
final class WorkforceAutonomyService
{
    public function __construct(
        private readonly WorkforceCapabilityBindingRegistry $registry,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
        private readonly WorkforceCommercialCapabilityPolicyService $commercialPolicy,
    ) {}

    /** @return array<string,mixed> */
    public function decide(WorkforceTask $task, WorkforceMember $actor, array $preExecution = []): array
    {
        try {
            $role = WorkforceRoleRegistry::find((string) $actor->role_definition_id);
            if (! $role) return $this->failClosed('ROLE_DEFINITION_UNAVAILABLE');

            $capabilityName = trim((string) $task->capability);
            if ($capabilityName === '') return $this->failClosed('CAPABILITY_UNSPECIFIED');
            $liveCapability = $this->capabilityAvailability->capabilityState($actor, $capabilityName);
            if (($liveCapability['state'] ?? null) !== 'available') {
                return $this->failClosed('CAPABILITY_STATE_' . strtoupper((string) ($liveCapability['state'] ?? 'unavailable')));
            }
            $capabilityOwner = trim((string) ($task->capability_owner_extension ?? ''));
            $owners = (array) ($liveCapability['available_providers'] ?? []);
            if ($capabilityOwner !== '' && ! in_array($capabilityOwner, $owners, true)) {
                return $this->failClosed('CAPABILITY_PROVIDER_NOT_LIVE');
            }
            if ($capabilityOwner === '') {
                if (count($owners) !== 1) return $this->failClosed(count($owners) > 1 ? 'CAPABILITY_OWNER_AMBIGUOUS' : 'CAPABILITY_OWNER_UNAVAILABLE');
                $capabilityOwner = (string) $owners[0];
            }
            $capability = $this->registry->findOwnedCapability(
                $capabilityOwner,
                (string) $task->capability,
                $task->capability_variant !== null ? (string) $task->capability_variant : null,
            );
            if (! $capability) return $this->failClosed('CAPABILITY_CONTRACT_UNAVAILABLE');

            $minimum = (array) ($capability['autonomy_requirement'] ?? []);
            $minimumScore = (int) ($minimum['minimum_score'] ?? 101);
            $minimumBand = (string) ($minimum['minimum_band'] ?? 'Predictive');
            $variant = $task->capability_variant !== null && trim((string) $task->capability_variant) !== ''
                ? (string) $task->capability_variant
                : (($minimum['variant'] ?? null) !== null ? (string) $minimum['variant'] : null);

            $desiredScore = (int) data_get($role, 'autonomy_profile.desired_score', 0);
            $desiredBand = (string) data_get($role, 'autonomy_profile.desired_level', WorkforceAutonomyDecision::bandForScore($desiredScore));
            $initialScore = (int) data_get($role, 'autonomy_profile.starting_score', 0);
            $initialBand = (string) data_get($role, 'autonomy_profile.starting_level', WorkforceAutonomyDecision::bandForScore($initialScore));
            $modelProviderFingerprint = $this->modelProviderFingerprint($actor);
            $previousFingerprint = (string) data_get($actor->autonomy_references ?? [], 'last_model_provider_fingerprint', '');
            $reevaluationReasons = $previousFingerprint !== '' && ! hash_equals($previousFingerprint, $modelProviderFingerprint)
                ? ['MODEL_PROVIDER_CHANGED'] : ['PRE_EXECUTION_REEVALUATION'];

            $offline = $this->isOffline($task);
            $contextFingerprint = $this->contextFingerprint($task, $actor, $modelProviderFingerprint, $offline);
            $key = [
                'company_id' => $task->company_id,
                'agent_id' => 'workforce-member:'.$actor->id,
                'capability' => (string) $task->capability,
                'capability_variant' => $variant,
                'vertical' => $this->nullableString($task->vertical),
                'workflow' => $this->workflowRef($task, $actor),
                'context' => 'ctx:'.$contextFingerprint,
            ];

            $governanceConstraint = $this->governanceConstraint($key, $task, $preExecution);
            if (($governanceConstraint['available'] ?? false) !== true || ! is_array($governanceConstraint['constraint'] ?? null)) {
                return array_merge($this->failClosed((string) ($governanceConstraint['reason'] ?? 'GOVERNANCE_ENGINE_UNAVAILABLE')), [
                    'governance_constraint' => $governanceConstraint,
                ]);
            }

            $request = [
                'schema_version' => '2.0',
                'autonomy_key' => $key,
                'governance_constraint' => $governanceConstraint['constraint'],
                'desired' => ['score' => $desiredScore, 'band' => $desiredBand],
                'initial_earned_ceiling' => ['score' => $initialScore, 'band' => $initialBand],
                'capability_requirement' => [
                    'minimum_score' => $minimumScore,
                    'minimum_band' => $minimumBand,
                    'variant' => $variant,
                    'authority_source' => 'titan_autonomy',
                ],
                'model_context' => [
                    'provider_preferences' => $actor->provider_preferences ?? [],
                    'model_preferences' => $actor->model_preferences ?? [],
                    'model_provider_fingerprint' => $modelProviderFingerprint,
                ],
                'connectivity' => $offline ? 'offline' : 'online',
                'reevaluation_reasons' => $reevaluationReasons,
                'trace_id' => $task->trace_id,
                'correlation_id' => $task->correlation_id,
                'causation_id' => $task->causation_id,
                // Organisational maturity/title/manager/deputy state are deliberately not authority inputs.
            ];

            $raw = $this->callTitanAutonomy($request);
            if (($raw['available'] ?? false) !== true || ! is_array($raw['decision'] ?? null)) {
                return array_merge($this->failClosed((string) ($raw['reason'] ?? 'AUTONOMY_UNAVAILABLE')), $raw);
            }

            $decision = WorkforceAutonomyDecision::validate($raw['decision'], $key);
            if ((float) $decision['desired_score'] > $desiredScore) {
                return array_merge($this->failClosed('ROLE_DESIRED_CEILING_EXCEEDED'), ['decision_id' => $decision['decision_id']]);
            }

            $offlinePolicy = (string) ($capability['offline_policy'] ?? 'OFFLINE_BLOCKED');
            $offlineCap = data_get($task->metadata ?? [], 'offline_authority_cap_score');
            $offlineCapScore = is_numeric($offlineCap) ? (int) $offlineCap : null;
            $predictiveRequired = $minimumScore >= 86
                || (bool) data_get($task->metadata ?? [], 'predictive', false)
                || data_get($task->metadata ?? [], 'execution_mode') === 'predictive';

            $decision = WorkforceAutonomyDecision::applyLocalPolicy(
                $decision,
                $minimumScore,
                $minimumBand,
                $offlinePolicy,
                $offline,
                $predictiveRequired,
                $offlineCapScore,
            );
            $businessTier = (string) data_get($task->metadata ?? [], 'business_capability_tier', 'legacy_existing');
            $commercialCeiling = $this->commercialPolicy->autonomyCeiling((int) $task->company_id, $businessTier);
            $decision = WorkforceAutonomyDecision::applyCommercialCeiling($decision, (int) $commercialCeiling['score'], (string) $commercialCeiling['source']);
            $decision['business_capability_tier'] = strtolower(trim($businessTier)) ?: 'legacy_existing';
            $decision['available'] = true;
            $decision['binding'] = $raw['binding'] ?? 'titan.autonomy';
            $decision['method'] = $raw['method'] ?? null;
            $decision['model_provider_fingerprint'] = $modelProviderFingerprint;
            $decision['context_fingerprint'] = $contextFingerprint;
            $decision['reevaluation_reasons'] = $reevaluationReasons;
            $decision['governance_constraint'] = $governanceConstraint;

            $refs = is_array($actor->autonomy_references) ? $actor->autonomy_references : [];
            // Persist references only. Runtime effective/earned scores remain external Titan Autonomy state.
            $refs['authority_source'] = 'titan_autonomy';
            $refs['last_decision_id'] = (string) $decision['decision_id'];
            $refs['last_policy_version'] = (string) $decision['policy_version'];
            $refs['last_evaluated_at'] = (string) $decision['evaluated_at'];
            $refs['last_context_fingerprint'] = $contextFingerprint;
            $refs['last_model_provider_fingerprint'] = $modelProviderFingerprint;
            $refs['effective_authority'] = null;
            $actor->forceFill(['autonomy_references' => $refs])->save();

            return $decision;
        } catch (Throwable $e) {
            return array_merge($this->failClosed('AUTONOMY_DECISION_INVALID'), [
                'error' => mb_substr($e->getMessage(), 0, 1000),
            ]);
        }
    }

    /** @return array<string,mixed> */
    public function context(WorkforceTask $task, WorkforceMember $actor): array
    {
        $fingerprint = $this->modelProviderFingerprint($actor);
        $offline = $this->isOffline($task);
        return [
            'autonomy_key' => [
                'company_id' => $task->company_id,
                'agent_id' => 'workforce-member:'.$actor->id,
                'capability' => (string) $task->capability,
                'capability_variant' => $task->capability_variant,
                'vertical' => $this->nullableString($task->vertical),
                'workflow' => $this->workflowRef($task, $actor),
                'context' => 'ctx:'.$this->contextFingerprint($task, $actor, $fingerprint, $offline),
            ],
            'model_provider_fingerprint' => $fingerprint,
            'offline' => $offline,
            'workforce_may_increase_authority' => false,
        ];
    }

    /** @return array<string,mixed> */
    private function governanceConstraint(array $autonomyKey, WorkforceTask $task, array $preExecution): array
    {
        $resolved = $this->controlPlane->resolve('governance');
        if ($resolved === null) return ['available' => false, 'reason' => 'GOVERNANCE_ENGINE_UNAVAILABLE', 'constraint' => null];
        $service = $resolved['service'];
        if (! method_exists($service, 'authorityConstraint')) {
            return ['available' => false, 'reason' => 'GOVERNANCE_AUTHORITY_CONSTRAINT_UNAVAILABLE', 'binding' => $resolved['binding'], 'constraint' => null];
        }

        $policyAllowed = (bool) data_get($preExecution, 'policy.allowed', false);
        $reasonCodes = array_values(array_unique(array_filter(array_map('strval', (array) data_get($preExecution, 'policy.reason_codes', [])))));
        if ($reasonCodes === []) $reasonCodes[] = $policyAllowed ? 'WORKFORCE_PRE_EXECUTION_POLICY_PASSED' : 'WORKFORCE_PRE_EXECUTION_POLICY_DENIED';
        $evidenceRefs = array_values(array_unique(array_filter(array_map('strval', (array) ($preExecution['evidence_refs'] ?? [])))));
        $disposition = $policyAllowed ? 'PASS' : 'DENY';
        $ceilingScore = $policyAllowed ? null : 0.0;

        try {
            $constraint = $service->authorityConstraint(
                $autonomyKey,
                $disposition,
                $ceilingScore,
                $reasonCodes,
                $evidenceRefs,
                'titan-workforce-control-plane-v1',
                (string) $task->trace_id,
            );
        } catch (Throwable $e) {
            return ['available' => false, 'reason' => 'GOVERNANCE_ENGINE_ERROR', 'binding' => $resolved['binding'], 'error' => mb_substr($e->getMessage(), 0, 1000), 'constraint' => null];
        }
        if (is_object($constraint) && method_exists($constraint, 'toArray')) $constraint = $constraint->toArray();
        if (! is_array($constraint)
            || trim((string) ($constraint['constraint_id'] ?? '')) === ''
            || ! in_array((string) ($constraint['disposition'] ?? ''), ['PASS','CONTRACT','REQUIRE_APPROVAL','HOLD','DENY'], true)) {
            return ['available' => false, 'reason' => 'GOVERNANCE_CONSTRAINT_INVALID', 'binding' => $resolved['binding'], 'constraint' => null];
        }
        return ['available' => true, 'binding' => $resolved['binding'], 'method' => 'authorityConstraint', 'constraint' => $constraint];
    }

    /** @return array{available:bool,decision?:array,binding?:string,method?:string,reason?:string,error?:string} */
    private function callTitanAutonomy(array $request): array
    {
        foreach ($this->controlPlane->bindingsFor('autonomy') as $binding) {
            if (! app()->bound($binding)) continue;
            $service = app($binding);
            foreach ($this->controlPlane->methodsFor('autonomy') as $method) {
                if (! method_exists($service, $method)) continue;
                try {
                    $result = $service->{$method}($request);
                } catch (Throwable $e) {
                    return ['available' => false, 'reason' => 'AUTONOMY_ENGINE_ERROR', 'binding' => $binding, 'method' => $method, 'error' => mb_substr($e->getMessage(), 0, 1000)];
                }
                if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
                if (! is_array($result)) return ['available' => false, 'reason' => 'AUTONOMY_DECISION_NOT_ARRAY', 'binding' => $binding, 'method' => $method];
                // Adapters may return the decision directly or wrapped under decision.
                $decision = is_array($result['decision'] ?? null) ? $result['decision'] : $result;
                return ['available' => true, 'decision' => $decision, 'binding' => $binding, 'method' => $method];
            }
        }
        return ['available' => false, 'reason' => 'AUTONOMY_ENGINE_UNAVAILABLE'];
    }

    private function modelProviderFingerprint(WorkforceMember $actor): string
    {
        return hash('sha256', json_encode($this->canonicalize([
            'provider_preferences' => $actor->provider_preferences ?? [],
            'model_preferences' => $actor->model_preferences ?? [],
        ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private function contextFingerprint(WorkforceTask $task, WorkforceMember $actor, string $modelProviderFingerprint, bool $offline): string
    {
        return hash('sha256', json_encode($this->canonicalize([
            'capability' => $task->capability,
            'capability_variant' => $task->capability_variant,
            'workflow' => $this->workflowRef($task, $actor),
            'vertical' => $task->vertical,
            'autonomy_context' => data_get($task->metadata ?? [], 'autonomy_context'),
            'model_provider_fingerprint' => $modelProviderFingerprint,
            'connectivity' => $offline ? 'offline' : 'online',
        ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private function isOffline(WorkforceTask $task): bool
    {
        $connectivity = strtolower((string) data_get($task->metadata ?? [], 'connectivity', 'online'));
        return (bool) data_get($task->metadata ?? [], 'offline', false) || $connectivity === 'offline';
    }

    private function workflowRef(WorkforceTask $task, WorkforceMember $actor): ?string
    {
        foreach ([
            $task->workflow_ref,
            data_get($task->governance ?? [], 'workflow_ref'),
            ($actor->interaction_wizards ?? [])[0] ?? null,
        ] as $candidate) {
            if (is_string($candidate) && trim($candidate) !== '') return trim($candidate);
        }
        return null;
    }

    private function nullableString(mixed $value): ?string
    {
        return is_string($value) && trim($value) !== '' ? trim($value) : null;
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn ($item) => $this->canonicalize($item), $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }

    /** @return array<string,mixed> */
    private function failClosed(string $reason): array
    {
        return [
            'available' => false,
            'allowed' => false,
            'effective_score' => 0.0,
            'effective_band' => 'Suggest',
            'predictive_readiness_score' => 0.0,
            'predictive_readiness_band' => 'Suggest',
            'approval_requirements' => ['governance_recovery'],
            'reason_codes' => [$reason],
            'authority_source' => 'titan_autonomy',
            'workforce_may_increase_authority' => false,
        ];
    }
}
