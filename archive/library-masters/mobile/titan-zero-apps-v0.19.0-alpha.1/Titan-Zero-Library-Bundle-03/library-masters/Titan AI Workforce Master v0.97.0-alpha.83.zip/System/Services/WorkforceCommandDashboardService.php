<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;

/**
 * Read-only, company-scoped operational home for Titan AI Workforce.
 *
 * This service only aggregates authoritative Workforce state. It never grants
 * capability or execution authority, mutates role identity, or treats cached
 * member capabilities as live availability.
 */
final class WorkforceCommandDashboardService
{
    private const TERMINAL_TASKS = ['COMPLETED', 'FAILED', 'CANCELLED', 'REJECTED'];
    private const REVIEW_TASKS = ['SUBMITTED', 'UNDER_REVIEW', 'HANDOFF_PENDING', 'RECEIVER_REVIEW'];
    private const BLOCKED_TASKS = ['BLOCKED', 'AWAITING_DATA', 'RECOVERY'];
    private const FAILURE_ATTEMPTS = ['COMMAND_BLOCKED', 'RECOVERY_REQUIRED'];
    private const RECOVERED_ATTEMPTS = ['RECONCILED', 'COMPENSATED', 'COMPLETED'];

    public function __construct(
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforceOutcomeHealthService $outcomeHealth,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)
            ->where('is_active', true)
            ->with(['division:id,key,name', 'manager:id,name'])
            ->orderBy('tier')->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member) => (bool) data_get($member->metadata ?? [], 'internal', false))
            ->values();

        $capabilityStates = $members->mapWithKeys(
            fn (WorkforceMember $member) => [(int) $member->id => $this->capabilityAvailability->forMember($member)]
        );
        $staffStateCounts = $capabilityStates->countBy(fn (array $state) => (string) ($state['state'] ?? 'unavailable'));

        $providerHealth = $this->providerHealth($capabilityStates);
        $queueHealth = $this->managerQueueHealth($companyId, $members);
        $outcomeHealth = $this->outcomeHealth->snapshot($companyId);

        $openTasks = WorkforceTask::query()->forCompany($companyId)->whereNotIn('status', self::TERMINAL_TASKS)->count();
        $reviewTasks = WorkforceTask::query()->forCompany($companyId)->whereIn('status', self::REVIEW_TASKS)->count();
        $blockedTasks = WorkforceTask::query()->forCompany($companyId)->whereIn('status', self::BLOCKED_TASKS)->count();
        $escalatedTasks = WorkforceTask::query()->forCompany($companyId)->where('status', 'ESCALATED')->count();

        $overdueSchedules = WorkforceSchedule::query()->forCompany($companyId)
            ->where('is_active', true)->where('trigger_type', 'schedule')->whereNotNull('next_run_at')
            ->where('next_run_at', '<', now())->count();

        $executionFailures = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->whereIn('status', self::FAILURE_ATTEMPTS)->count();
        $executionRecoveries = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->whereIn('status', self::RECOVERED_ATTEMPTS)
            ->where(function ($query): void {
                $query->whereNotNull('compensation_ref')->orWhereNotNull('recovery');
            })->count();

        $staffingCount = WorkforceStaffingProposal::query()->forCompany($companyId)->where('status', 'RECOMMENDED')->count();
        $recentEvents = $this->recentCriticalEvents($companyId);
        $attention = $this->attentionItems(
            $staffStateCounts,
            $providerHealth,
            $queueHealth,
            $reviewTasks,
            $blockedTasks,
            $escalatedTasks,
            $overdueSchedules,
            $executionFailures,
            $outcomeHealth,
            $staffingCount,
        );

        return [
            'health' => $this->overallHealth($attention),
            'staff' => [
                'active' => $members->filter(fn (WorkforceMember $member) => (bool) ($member->consumes_seat ?? true))->count(),
                'working' => $members->filter(fn (WorkforceMember $member) => ($member->status?->value ?? null) === 'WORKING')->count(),
                'degraded' => (int) $staffStateCounts->get('degraded', 0),
                'blocked' => (int) $staffStateCounts->get('blocked', 0)
                    + (int) $staffStateCounts->get('missing_provider', 0)
                    + (int) $staffStateCounts->get('policy_disabled', 0)
                    + (int) $staffStateCounts->get('unavailable', 0),
                'capability_states' => $staffStateCounts->all(),
            ],
            'work' => [
                'open' => $openTasks,
                'review' => $reviewTasks,
                'blocked' => $blockedTasks,
                'escalated' => $escalatedTasks,
            ],
            'providers' => $providerHealth,
            'manager_queues' => $queueHealth,
            'proactive' => ['overdue_responsibilities' => $overdueSchedules],
            'execution' => ['failures' => $executionFailures, 'recoveries' => $executionRecoveries],
            'outcomes' => $outcomeHealth,
            'staffing' => ['recommendations' => $staffingCount],
            'needs_attention' => $attention,
            'recent_critical_events' => $recentEvents,
            'members' => $members,
            'member_capability_states' => $capabilityStates->mapWithKeys(fn (array $state, $id) => [(int) $id => (string) ($state['state'] ?? 'unavailable')])->all(),
        ];
    }

    /** @param Collection<int,array<string,mixed>> $capabilityStates @return array<string,mixed> */
    private function providerHealth(Collection $capabilityStates): array
    {
        $providers = [];
        foreach ($capabilityStates as $state) {
            foreach ((array) ($state['provider_bindings'] ?? []) as $binding) {
                if (! is_array($binding)) continue;
                $key = trim((string) ($binding['provider'] ?? ''));
                if ($key === '') continue;
                $providers[$key] ??= ['provider' => $key, 'state' => 'available', 'affected_staff' => 0, 'role_bindings' => 0];
                $providers[$key]['role_bindings']++;
                $bindingState = (string) ($binding['state'] ?? 'unavailable');
                if ($bindingState !== 'available') $providers[$key]['affected_staff']++;
                $providers[$key]['state'] = $this->worstCapabilityState((string) $providers[$key]['state'], $bindingState);
            }
        }
        ksort($providers);
        $rows = array_values($providers);
        $counts = collect($rows)->countBy('state')->all();
        return [
            'total' => count($rows),
            'healthy' => (int) ($counts['available'] ?? 0),
            'degraded' => (int) ($counts['degraded'] ?? 0),
            'blocked' => count($rows) - (int) ($counts['available'] ?? 0) - (int) ($counts['degraded'] ?? 0),
            'states' => $counts,
            'providers' => $rows,
        ];
    }

    /** @param Collection<int,WorkforceMember> $members @return array<string,mixed> */
    private function managerQueueHealth(int $companyId, Collection $members): array
    {
        $rows = $members->filter(fn (WorkforceMember $member) => $member->tier === WorkforceTier::Manager && (bool) ($member->consumes_seat ?? true))
            ->map(function (WorkforceMember $manager) use ($companyId): array {
                $health = $manager->division_id
                    ? $this->queueHealth->snapshot($companyId, (int) $manager->division_id)
                    : ['pressure' => 'NORMAL', 'queue_depth' => 0, 'overdue_count' => 0, 'blocked_count' => 0, 'starved_count' => 0, 'active_capacity' => 0];
                return ['manager_id' => $manager->id, 'manager' => $manager->name, 'division' => $manager->division?->name, 'health' => $health];
            })->values();

        return [
            'critical' => $rows->filter(fn (array $row) => data_get($row, 'health.pressure') === 'CRITICAL')->count(),
            'high' => $rows->filter(fn (array $row) => data_get($row, 'health.pressure') === 'HIGH')->count(),
            'elevated' => $rows->filter(fn (array $row) => data_get($row, 'health.pressure') === 'ELEVATED')->count(),
            'rows' => $rows->all(),
        ];
    }

    /** @return list<array<string,mixed>> */
    private function recentCriticalEvents(int $companyId): array
    {
        $events = ['execution.receipt_invalid','execution.verification_failed','execution.uncertain','execution.receipt_missing','task.escalated','deadlock.escalated','execution.recovered'];
        return WorkforceTaskHistory::query()->where('company_id', $companyId)->whereIn('event', $events)
            ->orderByDesc('created_at')->limit(12)->get()
            ->map(fn (WorkforceTaskHistory $history) => [
                'id' => $history->id,
                'task_id' => $history->task_id,
                'event' => $history->event,
                'to_status' => $history->to_status,
                'reason' => $history->reason,
                'trace_id' => $history->trace_id,
                'created_at' => optional($history->created_at)->toIso8601String(),
                'severity' => $history->event === 'execution.recovered' ? 'recovered' : 'critical',
            ])->values()->all();
    }

    /** @return list<array<string,mixed>> */
    private function attentionItems(Collection $staffStates, array $providerHealth, array $queueHealth, int $review, int $blocked, int $escalated, int $overdueSchedules, int $executionFailures, array $outcomeHealth, int $staffing): array
    {
        $items = [];
        $push = static function (array &$items, string $severity, string $key, string $title, int $count, string $detail, string $target): void {
            if ($count < 1) return;
            $items[] = compact('severity','key','title','count','detail','target');
        };

        $hardBlockedStaff = (int) $staffStates->get('blocked', 0) + (int) $staffStates->get('missing_provider', 0) + (int) $staffStates->get('policy_disabled', 0) + (int) $staffStates->get('unavailable', 0);
        $push($items, 'critical', 'blocked_staff', 'Staff cannot perform expected work', $hardBlockedStaff, 'Live capability state is blocked, unavailable, missing a provider or disabled by policy.', 'team');
        $push($items, 'critical', 'escalated_work', 'Escalated work needs a decision', $escalated, 'Escalated tasks are waiting in the governed chain of command.', 'tasks');
        $push($items, 'critical', 'execution_failures', 'Execution failures need review', $executionFailures, 'Command execution is blocked or requires recovery.', 'control-room');
        $push($items, 'critical', 'critical_queues', 'Manager queues are critical', (int) ($queueHealth['critical'] ?? 0), 'At least one manager queue has critical pressure.', 'control-room');
        $push($items, 'warning', 'degraded_staff', 'Staff are operating in degraded mode', (int) $staffStates->get('degraded', 0), 'Some expected provider surfaces are unavailable, but employee identity is preserved.', 'team');
        $push($items, 'warning', 'provider_health', 'Capability providers need attention', (int) ($providerHealth['degraded'] ?? 0) + (int) ($providerHealth['blocked'] ?? 0), 'One or more provider bindings are degraded or unavailable.', 'control-room');
        $push($items, 'warning', 'blocked_work', 'Blocked work needs intervention', $blocked, 'Tasks are blocked, awaiting data or in recovery.', 'tasks');
        $push($items, 'warning', 'manager_review', 'Manager reviews are waiting', $review, 'Submitted, handoff or receiving-manager reviews need attention.', 'tasks');
        $push($items, 'warning', 'overdue_proactive', 'Proactive responsibilities are overdue', $overdueSchedules, 'Scheduled responsibilities have passed their next-run time.', 'calendar');
        $push($items, 'warning', 'outcome_health', 'Outcome verification needs attention', (int) ($outcomeHealth['verification_late'] ?? 0) + (int) ($outcomeHealth['verification_missing'] ?? 0), 'Executed work is waiting for authoritative outcome verification.', 'control-room');
        $push($items, 'info', 'staffing', 'Staffing recommendations are ready', $staffing, 'Workforce Planning has recommendations awaiting review.', 'control-room');

        $order = ['critical' => 0, 'warning' => 1, 'info' => 2];
        usort($items, static fn (array $a, array $b) => [$order[$a['severity']] ?? 9, -$a['count']] <=> [$order[$b['severity']] ?? 9, -$b['count']]);
        return array_slice($items, 0, 12);
    }

    /** @param list<array<string,mixed>> $attention */
    private function overallHealth(array $attention): string
    {
        if (collect($attention)->contains(fn (array $item) => $item['severity'] === 'critical')) return 'CRITICAL';
        if (collect($attention)->contains(fn (array $item) => $item['severity'] === 'warning')) return 'ATTENTION';
        return 'HEALTHY';
    }

    private function worstCapabilityState(string $left, string $right): string
    {
        $rank = ['available' => 0, 'degraded' => 1, 'policy_disabled' => 2, 'unavailable' => 3, 'missing_provider' => 4, 'blocked' => 5];
        return ($rank[$right] ?? 5) > ($rank[$left] ?? 5) ? $right : $left;
    }
}
