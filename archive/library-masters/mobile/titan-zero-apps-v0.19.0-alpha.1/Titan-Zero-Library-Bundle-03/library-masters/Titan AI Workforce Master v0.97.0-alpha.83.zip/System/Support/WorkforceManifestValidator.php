<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

/** Semantic validator for the canonical extension-owned Workforce Manifest 2.0 contract. */
final class WorkforceManifestValidator
{
    private const RISK_LEVELS = ['MINIMAL', 'LOW', 'MEDIUM', 'HIGH', 'EXTREME'];
    private const MATURITY_LEVELS = ['JUNIOR', 'STANDARD', 'SENIOR', 'LEAD'];
    private const OFFLINE_POLICIES = ['ONLINE_EXECUTE', 'OFFLINE_EXECUTE', 'OFFLINE_PREPARE_ONLY', 'OFFLINE_BLOCKED'];
    private const DEADLOCK_STATES = ['RETRY_WITH_EVIDENCE', 'RETURN_TO_MAKER', 'ESCALATE_TO_PARENT', 'ESCALATE_TO_TITAN', 'HUMAN_DECISION_REQUIRED'];
    private const BANDS = [
        'Suggest' => [0, 15], 'Assist' => [16, 30], 'Semi-Auto' => [31, 50],
        'Auto' => [51, 70], 'Trusted Auto' => [71, 85], 'Predictive' => [86, 100],
    ];

    public static function assertValid(array $manifest): void
    {
        if (($manifest['schema_version'] ?? null) !== '2.0') {
            throw new RuntimeException('Canonical Workforce manifest schema_version must be 2.0.');
        }

        $extension = self::object($manifest, 'extension');
        $extensionKey = self::nonEmpty($extension, 'key', 'extension');
        self::nonEmpty($extension, 'version', 'extension');

        $ownership = self::object($manifest, 'ownership');
        if (($ownership['source_of_truth'] ?? null) !== 'extension'
            || ($ownership['central_workforce_owns_definitions'] ?? null) !== false
            || ($ownership['auto_seed_staff'] ?? null) !== false) {
            throw new RuntimeException("Workforce manifest {$extensionKey} violates extension-owned definition/activation boundaries.");
        }

        $runtime = self::object($manifest, 'runtime');
        foreach (['manifest_provider','execution_context','tool_registry','command_bus_port','risk_port','assurance_port','autonomy_port','workforce_task_port','workflow_router','wizard_registry'] as $field) {
            self::nonEmpty($runtime, $field, 'runtime');
        }
        if (($runtime['fail_closed'] ?? null) !== true || ($runtime['execution_receipt_required'] ?? null) !== true) {
            throw new RuntimeException("Workforce manifest {$extensionKey} runtime must fail closed and require execution receipts.");
        }

        foreach (['relationships','raci'] as $requiredArray) {
            if (! array_key_exists($requiredArray, $manifest) || ! is_array($manifest[$requiredArray])) {
                throw new RuntimeException("Workforce manifest requires {$requiredArray} array.");
            }
        }

        $divisions = self::indexedObjects($manifest['divisions'] ?? null, 'divisions', 'id');
        $teams = self::indexedObjects($manifest['teams'] ?? null, 'teams', 'id');
        foreach ($teams as $teamId => $team) {
            $divisionId = self::nonEmpty($team, 'division_id', "team {$teamId}");
            if (! isset($divisions[$divisionId])) throw new RuntimeException("Workforce team {$teamId} references unknown division {$divisionId}.");
        }

        $capabilities = self::indexedObjects($manifest['capabilities'] ?? null, 'capabilities', 'name');
        foreach ($capabilities as $name => $capability) self::validateCapability($name, $capability);

        $tools = self::indexedObjects($manifest['tools'] ?? null, 'tools', 'id');
        foreach ($tools as $id => $tool) {
            $capabilityName = self::nonEmpty($tool, 'capability', "tool {$id}");
            if (! isset($capabilities[$capabilityName])) throw new RuntimeException("Workforce tool {$id} references undeclared capability {$capabilityName}.");
            $writes = $tool['writes_state'] ?? null;
            $execution = (string) ($tool['execution'] ?? '');
            if (! is_bool($writes) || ! in_array($execution, ['local_read','proposal_only','command_bus'], true)) {
                throw new RuntimeException("Workforce tool {$id} has invalid writes_state/execution metadata.");
            }
            if ($writes === true && ($execution !== 'command_bus' || ($capabilities[$capabilityName]['mutation_mode'] ?? null) !== 'command_bus_only')) {
                throw new RuntimeException("Mutating Workforce tool {$id} must execute through Command Bus only.");
            }
        }

        $skills = self::indexedObjects($manifest['skills'] ?? null, 'skills', 'id');
        $playbooks = self::indexedObjects($manifest['playbooks'] ?? null, 'playbooks', 'id');
        $workflows = self::indexedObjects($manifest['workflows'] ?? null, 'workflows', 'id');
        $wizards = self::indexedObjects($manifest['wizards'] ?? null, 'wizards', 'id');
        foreach ($wizards as $id => $wizard) {
            $workflow = self::nonEmpty($wizard, 'workflow', "wizard {$id}");
            if (! isset($workflows[$workflow])) throw new RuntimeException("Workforce wizard {$id} references unknown workflow {$workflow}.");
        }

        $roles = self::indexedObjects($manifest['roles'] ?? null, 'roles', 'role_id', true);
        foreach ($roles as $roleId => $role) {
            self::validateRole($roleId, $role, $roles, $divisions, $teams, $capabilities, $tools, $skills, $playbooks, $workflows, $wizards);
        }

        foreach ($manifest['relationships'] ?? [] as $relationship) {
            if (! is_array($relationship)) throw new RuntimeException('Workforce relationships must be objects.');
            $from = self::nonEmpty($relationship, 'from', 'relationship');
            if (! isset($roles[$from])) throw new RuntimeException("Workforce relationship starts from unknown role {$from}.");
            $to = self::nonEmpty($relationship, 'to', "relationship {$from}");
            if (! isset($roles[$to])) throw new RuntimeException("Workforce relationship {$from} points to unknown role {$to}.");
            if (! in_array($relationship['type'] ?? null, ['reports_to','manages','coordinates','consults','informs','delegates_to','reviews_for','hands_off_to','escalates_to','collaborates_with','substitutes_for'], true)) {
                throw new RuntimeException("Workforce relationship {$from} has invalid type.");
            }
            if (($relationship['authority_inherited'] ?? false) !== false) {
                throw new RuntimeException("Workforce relationship {$from} must not inherit authority.");
            }
        }
        self::assertNoManifestReportingCycles($roles, $manifest['relationships'] ?? []);

        $proactive = self::object($manifest, 'proactive');
        if (($proactive['auto_execute_business_mutations'] ?? null) !== false) {
            throw new RuntimeException('Proactive Workforce responsibilities may not auto-execute business mutations.');
        }
        foreach ($proactive['schedules'] ?? [] as $schedule) {
            self::validateProactiveRoleRef($schedule, 'schedule', $roles);
            WorkforceManifestNormalizer::scheduleExpression((string) ($schedule['frequency'] ?? ''));
        }
        foreach ($proactive['signals'] ?? [] as $signal) self::validateProactiveRoleRef($signal, 'signal', $roles);

        $seenDecisions = [];
        foreach ($manifest['raci'] ?? [] as $raci) {
            if (! is_array($raci) || trim((string) ($raci['decision'] ?? '')) === '') throw new RuntimeException('Workforce RACI entries require decision.');
            $decision = trim((string) $raci['decision']);
            if (isset($seenDecisions[$decision])) throw new RuntimeException("Workforce RACI decision {$decision} is duplicated inside one extension manifest.");
            $seenDecisions[$decision] = true;
            foreach (['responsible','accountable','consulted','informed'] as $field) {
                if (! is_array($raci[$field] ?? null)) throw new RuntimeException("Workforce RACI {$field} must be an array.");
            }
            if (($raci['responsible'] ?? []) === []) throw new RuntimeException("Workforce RACI responsible must contain at least one role for {$decision}.");
            if (count($raci['accountable'] ?? []) !== 1) throw new RuntimeException('Workforce RACI accountable must contain exactly one role.');
            foreach (['responsible','accountable'] as $field) {
                foreach ($raci[$field] as $roleRef) {
                    $roleRef = (string) $roleRef;
                    if (! isset($roles[$roleRef])) {
                        if ($field === 'responsible') throw new RuntimeException("RACI responsible references unknown role {$roleRef}.");
                        throw new RuntimeException("Workforce RACI accountable references unknown role {$roleRef}.");
                    }
                }
            }
            // consulted/informed may intentionally reference another extension-owned RoleDefinition.
            foreach (['consulted','informed'] as $field) {
                foreach ($raci[$field] as $roleRef) if (trim((string) $roleRef) === '') throw new RuntimeException("Workforce RACI {$field} contains an empty role reference.");
            }
        }

        self::validateGovernance(self::object($manifest, 'governance'));
        $offline = self::object($manifest, 'offline');
        if (($offline['authority_may_increase'] ?? null) !== false || ! in_array($offline['default_policy'] ?? null, self::OFFLINE_POLICIES, true)) {
            throw new RuntimeException('Workforce offline policy may never increase authority and must use a canonical policy.');
        }
        $planning = self::object($manifest, 'workforce_planning');
        if (! is_bool($planning['enabled'] ?? null) || ! is_array($planning['signals'] ?? null)
            || ($planning['auto_activate'] ?? null) !== false || ($planning['approval_required'] ?? null) !== true) {
            throw new RuntimeException('Workforce Planning may recommend staff but must never auto-activate them.');
        }
    }

    private static function validateRole(string $roleId, array $role, array $roles, array $divisions, array $teams, array $capabilities, array $tools, array $skills, array $playbooks, array $workflows, array $wizards): void
    {
        foreach (['name','division_id','team_id','purpose'] as $field) self::nonEmpty($role, $field, "role {$roleId}");
        foreach (['reports_to','escalates_to'] as $requiredKey) {
            if (! array_key_exists($requiredKey, $role)) throw new RuntimeException("Workforce role {$roleId} requires {$requiredKey}.");
        }
        $tier = $role['tier'] ?? null;
        if (! is_int($tier) || $tier < 1 || $tier > 3) throw new RuntimeException("Workforce role {$roleId} must declare tier 1, 2 or 3.");
        $divisionId = (string) $role['division_id'];
        $teamId = (string) $role['team_id'];
        if (! isset($divisions[$divisionId])) throw new RuntimeException("Workforce role {$roleId} references unknown division {$divisionId}.");
        if (! isset($teams[$teamId])) throw new RuntimeException("Workforce role {$roleId} references unknown team {$teamId}.");
        if (($teams[$teamId]['division_id'] ?? null) !== $divisionId) throw new RuntimeException("Workforce role {$roleId} team/division mismatch.");

        $reportsTo = $role['reports_to'] ?? null;
        if ($reportsTo !== null && $reportsTo !== '' && ! isset($roles[(string) $reportsTo])) throw new RuntimeException("Workforce role {$roleId} reports to unknown role {$reportsTo}.");
        foreach ($role['manages'] ?? [] as $managed) if (! isset($roles[(string) $managed])) throw new RuntimeException("Workforce role {$roleId} manages unknown role {$managed}.");

        if (! in_array($role['risk_ceiling'] ?? null, self::RISK_LEVELS, true)) throw new RuntimeException("Workforce role {$roleId} has invalid risk ceiling.");
        if (($role['status'] ?? null) !== 'available_definition') throw new RuntimeException("Workforce role {$roleId} must be an available_definition.");

        foreach (['responsibilities','capabilities','skills','tools','playbooks','workflows','wizards','manages'] as $field) {
            if (! is_array($role[$field] ?? null)) throw new RuntimeException("Workforce role {$roleId} {$field} must be an array.");
        }
        self::assertRefs($roleId, 'capability', $role['capabilities'], $capabilities);
        self::assertRefs($roleId, 'tool', $role['tools'], $tools);
        self::assertRefs($roleId, 'skill', $role['skills'], $skills);
        self::assertRefs($roleId, 'playbook', $role['playbooks'], $playbooks);
        self::assertRefs($roleId, 'workflow', $role['workflows'], $workflows);
        self::assertRefs($roleId, 'wizard', $role['wizards'], $wizards);
        foreach ($role['tools'] as $toolId) {
            $capability = (string) ($tools[(string) $toolId]['capability'] ?? '');
            if ($capability !== '' && ! in_array($capability, $role['capabilities'], true)) {
                throw new RuntimeException("Workforce role {$roleId} lacks capability {$capability} required by tool {$toolId}.");
            }
        }

        $maturity = is_array($role['maturity'] ?? null) ? $role['maturity'] : [];
        if (! in_array($maturity['default'] ?? null, self::MATURITY_LEVELS, true)
            || ($maturity['promotion_mode'] ?? null) !== 'recommend_only'
            || ! is_array($maturity['levels'] ?? null)
            || array_values($maturity['levels']) !== self::MATURITY_LEVELS) {
            throw new RuntimeException("Workforce role {$roleId} has invalid maturity policy.");
        }

        $autonomy = is_array($role['autonomy'] ?? null) ? $role['autonomy'] : [];
        $desired = self::authorityPoint($autonomy['desired'] ?? null, "role {$roleId} desired autonomy", 'score', 'band');
        $initial = self::authorityPoint($autonomy['initial_earned_ceiling'] ?? null, "role {$roleId} initial earned ceiling", 'score', 'band');
        if ($initial['score'] > $desired['score']) throw new RuntimeException("Workforce role {$roleId} initial earned authority may not exceed desired ceiling.");
        if (($autonomy['effective_authority']['source'] ?? null) !== 'titan_autonomy'
            || ($autonomy['effective_authority']['decision_contract'] ?? null) !== 'schemas/autonomy-decision.schema.json'
            || ($autonomy['effective_authority']['mutable_by_extension'] ?? null) !== false
            || ($autonomy['predictive_readiness']['source'] ?? null) !== 'titan_autonomy'
            || ($autonomy['predictive_readiness']['decision_contract'] ?? null) !== 'schemas/autonomy-decision.schema.json'
            || ($autonomy['predictive_readiness']['grants_mutation_authority'] ?? null) !== false) {
            throw new RuntimeException("Workforce role {$roleId} must leave effective authority/predictive readiness to Titan Autonomy.");
        }
        $authorityRefs = $autonomy['capability_authority_refs'] ?? null;
        if (! is_array($authorityRefs) || $authorityRefs === []) throw new RuntimeException("Workforce role {$roleId} requires capability authority references.");
        $referenced = [];
        foreach ($authorityRefs as $ref) {
            if (! is_array($ref) || ($ref['authority_source'] ?? null) !== 'titan_autonomy') throw new RuntimeException("Workforce role {$roleId} has invalid capability authority source.");
            $capability = trim((string) ($ref['capability'] ?? ''));
            if (! in_array($capability, $role['capabilities'], true)) throw new RuntimeException("Workforce role {$roleId} authority ref targets undeclared role capability {$capability}.");
            $referenced[$capability] = true;
        }
        foreach ($role['capabilities'] as $capability) if (! isset($referenced[(string) $capability])) throw new RuntimeException("Workforce role {$roleId} lacks Titan Autonomy authority ref for {$capability}.");
    }

    private static function assertNoManifestReportingCycles(array $roles, array $relationships): void
    {
        $parent = [];
        foreach ($roles as $roleId => $role) {
            $reportsTo = trim((string) ($role['reports_to'] ?? ''));
            if ($reportsTo !== '') $parent[(string) $roleId] = $reportsTo;
        }
        foreach ($relationships as $relationship) {
            if (! is_array($relationship) || ($relationship['type'] ?? null) !== 'reports_to') continue;
            $from = trim((string) ($relationship['from'] ?? ''));
            $to = trim((string) ($relationship['to'] ?? ''));
            if ($from !== '' && $to !== '') $parent[$from] = $to;
        }
        foreach (array_keys($roles) as $start) {
            $seen = [];
            $cursor = (string) $start;
            while (isset($parent[$cursor])) {
                if (isset($seen[$cursor])) {
                    throw new RuntimeException("Workforce relationship creates reporting cycle at role {$cursor}.");
                }
                $seen[$cursor] = true;
                $cursor = (string) $parent[$cursor];
            }
        }
    }

    private static function validateCapability(string $name, array $capability): void
    {
        foreach (['owner','input_contract','output_contract','idempotency_strategy'] as $field) self::nonEmpty($capability, $field, "capability {$name}");
        if (! in_array($capability['risk_profile'] ?? null, self::RISK_LEVELS, true)) throw new RuntimeException("Workforce capability {$name} has invalid risk profile.");
        self::authorityPoint($capability['autonomy_requirement'] ?? null, "capability {$name} autonomy requirement", 'minimum_score', 'minimum_band');
        if (($capability['autonomy_requirement']['authority_source'] ?? null) !== 'titan_autonomy') throw new RuntimeException("Workforce capability {$name} authority source must be Titan Autonomy.");
        if (! in_array($capability['offline_policy'] ?? null, self::OFFLINE_POLICIES, true)) throw new RuntimeException("Workforce capability {$name} has invalid offline policy.");
        if (! in_array($capability['reversibility'] ?? null, ['reversible','compensatable','irreversible'], true)) throw new RuntimeException("Workforce capability {$name} has invalid reversibility.");
        if (! in_array($capability['mutation_mode'] ?? null, ['read_only','proposal_only','command_bus_only'], true)) throw new RuntimeException("Workforce capability {$name} has invalid mutation mode.");
        if (! is_array($capability['evidence_requirements'] ?? null)) throw new RuntimeException("Workforce capability {$name} evidence requirements must be an array.");
    }

    private static function validateGovernance(array $governance): void
    {
        foreach (['risk','assurance','autonomy','signal','command_bus','rewind','wisdom','knowledge_authority','shield'] as $engine) {
            if (($governance[$engine] ?? null) !== 'external_titan_engine') throw new RuntimeException("Workforce governance {$engine} must remain external Titan engine authority.");
        }
        if (($governance['self_approval'] ?? null) !== false || ($governance['direct_domain_writes'] ?? null) !== false) throw new RuntimeException('Workforce governance forbids self approval and direct domain writes.');
        $trace = array_map('strval', is_array($governance['trace_fields'] ?? null) ? $governance['trace_fields'] : []);
        foreach (['trace_id','correlation_id','causation_id','company_id'] as $required) if (! in_array($required, $trace, true)) throw new RuntimeException("Workforce governance missing {$required} trace field.");
        $deadlocks = array_map('strval', is_array($governance['deadlock_states'] ?? null) ? $governance['deadlock_states'] : []);
        foreach (self::DEADLOCK_STATES as $required) if (! in_array($required, $deadlocks, true)) throw new RuntimeException("Workforce governance missing deadlock state {$required}.");
    }

    private static function validateProactiveRoleRef(mixed $entry, string $kind, array $roles): void
    {
        if (! is_array($entry)) throw new RuntimeException("Workforce proactive {$kind} entries must be objects.");
        $roleId = self::nonEmpty($entry, 'role_id', "proactive {$kind}");
        if (! isset($roles[$roleId])) throw new RuntimeException("Workforce proactive {$kind} references unknown role {$roleId}.");
        if (($entry['creates'] ?? null) !== 'workforce_task') throw new RuntimeException("Workforce proactive {$kind} must create workforce_task.");
    }

    private static function authorityPoint(mixed $value, string $context, string $scoreKey, string $bandKey): array
    {
        if (! is_array($value) || ! is_int($value[$scoreKey] ?? null)) throw new RuntimeException("{$context} requires integer {$scoreKey}.");
        $score = $value[$scoreKey];
        $band = (string) ($value[$bandKey] ?? '');
        if (! isset(self::BANDS[$band]) || $score < self::BANDS[$band][0] || $score > self::BANDS[$band][1]) throw new RuntimeException("{$context} score/band mismatch.");
        return ['score' => $score, 'band' => $band];
    }

    private static function assertRefs(string $roleId, string $kind, array $refs, array $catalogue): void
    {
        foreach ($refs as $ref) if (! isset($catalogue[(string) $ref])) throw new RuntimeException("Workforce role {$roleId} references unknown {$kind} {$ref}.");
    }

    private static function object(array $source, string $key): array
    {
        if (! is_array($source[$key] ?? null)) throw new RuntimeException("Workforce manifest requires {$key} object.");
        return $source[$key];
    }

    private static function nonEmpty(array $source, string $key, string $context): string
    {
        $value = trim((string) ($source[$key] ?? ''));
        if ($value === '') throw new RuntimeException("Workforce {$context} requires {$key}.");
        return $value;
    }

    private static function indexedObjects(mixed $items, string $context, string $key, bool $requireNonEmpty = false): array
    {
        if (! is_array($items) || ($requireNonEmpty && $items === [])) throw new RuntimeException("Workforce manifest {$context} must be " . ($requireNonEmpty ? 'a non-empty ' : 'an ') . 'array.');
        $out = [];
        foreach ($items as $item) {
            if (! is_array($item)) throw new RuntimeException("Workforce manifest {$context} entries must be objects.");
            $id = trim((string) ($item[$key] ?? ''));
            if ($id === '' || isset($out[$id])) throw new RuntimeException("Workforce manifest {$context} require unique {$key} values.");
            $out[$id] = $item;
        }
        return $out;
    }
}
