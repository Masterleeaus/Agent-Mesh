<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOrganisation;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceNotificationRoutingService;
use Illuminate\Console\Command;

final class RouteWorkforceNotificationsCommand extends Command
{
    protected $signature = 'titan-workforce:route-notifications {--company=}';
    protected $description = 'Project important Workforce Attention conditions into deduplicated governed in-app notifications.';

    public function handle(WorkforceNotificationRoutingService $routing): int
    {
        $company = $this->option('company');
        $ids = $company !== null && $company !== ''
            ? collect([(int) $company])
            : WorkforceOrganisation::query()->select('company_id')->distinct()->pluck('company_id');
        foreach ($ids as $companyId) {
            $summary = $routing->sync((int) $companyId);
            $this->line('company '.(int) $companyId.': '.json_encode($summary, JSON_UNESCAPED_SLASHES));
        }
        return self::SUCCESS;
    }
}
