<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceJourneyRecord;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Carbon\CarbonInterface;
use Illuminate\Support\Collection;
use RuntimeException;

/**
 * Read-only explainability projection of the canonical Titan control-plane.
 *
 * This visualizer reports evidence that already exists on the Workforce task,
 * journey, execution, evidence and outcome records. It never manufactures a
 * decision and it never grants authority.
 */
final class WorkforceGovernancePipelineVisualizerService
{
    private const LABELS = [
        'signal' => 'Signal',
        'prime' => 'Prime',
        'ai_core' => 'AI Core',
        'ai_runtime' => 'Agent Runtime',
        'model_council' => 'Model Council',
        'risk' => 'Risk',
        'assurance' => 'Assurance',
        'governance' => 'Governance',
        'autonomy' => 'Autonomy',
        'command_bus' => 'Command Bus',
        'rewind' => 'Rewind',
        'wisdom' => 'Wisdom',
    ];

    public function __construct(private readonly WorkforceControlPlaneIntegrationRegistry $registry) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId, ?int $taskId = null): array
    {
        if ($companyId <= 0) throw new RuntimeException('company_id must be positive.');

        $recentTasks = WorkforceTask::query()->forCompany($companyId)
            ->orderByDesc('updated_at')->limit(75)->get();

        $task = $taskId
            ? WorkforceTask::query()->forCompany($companyId)->find($taskId)
            : $recentTasks->first();

        $stages = $task ? $this->stagesForTask($companyId, $task) : $this->emptyStages();
        $counts = ['completed' => 0, 'active' => 0, 'degraded' => 0, 'failed' => 0, 'pending' => 0, 'not_required' => 0];
        foreach ($stages as $stage) $counts[$stage['state']] = ($counts[$stage['state']] ?? 0) + 1;

        return [
            'task' => $task,
            'tasks' => $recentTasks,
            'stages' => $stages,
            'counts' => $counts,
            'execution_gates' => $this->registry->executionGateStatus($companyId),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
            'generated_at' => now()->toIso8601String(),
        ];
    }

    /** @return list<array<string,mixed>> */
    private function stagesForTask(int $companyId, WorkforceTask $task): array
    {
        $journey = WorkforceJourneyRecord::query()->forCompany($companyId)
            ->where('task_id', $task->id)->orderBy('observed_at')->get();
        $evidence = WorkforceEvidence::query()->forCompany($companyId)
            ->where('task_id', $task->id)->orderBy('observed_at')->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)
            ->where('task_id', $task->id)->orderBy('observed_at')->get();
        $attempts = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->where('task_id', $task->id)->orderBy('created_at')->get();

        $stages = [];
        $previousTimestamp = $task->created_at;
        foreach ($this->registry->integrations() as $integration) {
            $key = (string) $integration['key'];
            $availability = $this->registry->availability($key);
            $payload = $this->payloadFor($key, $task, $journey, $attempts, $outcomes);
            $stageEvidence = $this->evidenceFor($key, $payload, $journey, $evidence, $outcomes);
            $timestamp = $this->timestampFor($key, $payload, $journey, $attempts, $outcomes, $task);
            $state = $this->stateFor($key, $payload, $availability, $task, $attempts, $outcomes);
            $reason = $this->reasonFor($key, $payload, $availability, $state);
            $decision = $this->decisionFor($key, $payload, $attempts, $outcomes);
            $duration = $this->durationMs($previousTimestamp, $timestamp);
            if ($timestamp instanceof CarbonInterface) $previousTimestamp = $timestamp;

            $failure = $this->failureFor($state, $payload, $availability);
            $degradation = $this->degradationFor($state, $availability, $payload);
            $stages[] = [
                'key' => $key,
                'label' => self::LABELS[$key] ?? (string) $integration['stage'],
                'stage' => (string) $integration['stage'],
                'state' => $state,
                'timestamp' => $timestamp?->toIso8601String(),
                'provider' => (string) $integration['provider'],
                'provider_available' => (bool) ($availability['available'] ?? false),
                'decision' => $decision,
                'evidence' => $stageEvidence,
                'reason' => $reason,
                'duration' => $duration,
                'duration_ms' => $duration,
                'failure' => $failure,
                'degradation' => $degradation,
                'required' => (string) ($integration['required'] ?? ''),
                'required_for_execution' => (bool) ($integration['required_for_execution'] ?? false),
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ];
        }
        return $stages;
    }

    /** @return list<array<string,mixed>> */
    private function emptyStages(): array
    {
        return array_map(function (array $integration): array {
            $key = (string) $integration['key'];
            $availability = $this->registry->availability($key);
            return [
                'key'=>$key, 'label'=>self::LABELS[$key] ?? (string)$integration['stage'], 'stage'=>(string)$integration['stage'],
                'state'=>'pending', 'timestamp'=>null, 'provider'=>(string)$integration['provider'],
                'provider_available'=>(bool)($availability['available'] ?? false), 'decision'=>null, 'evidence'=>[], 'reason'=>'No Work Item selected.',
                'duration'=>null, 'duration_ms'=>null, 'failure'=>null, 'degradation'=>($availability['available'] ?? false) ? null : (string)($availability['failure'] ?? 'provider_unavailable'),
                'required'=>(string)($integration['required'] ?? ''), 'required_for_execution'=>(bool)($integration['required_for_execution'] ?? false),
                'authority_inherited'=>false, 'execution_authority_granted'=>false,
            ];
        }, $this->registry->integrations());
    }

    private function payloadFor(string $key, WorkforceTask $task, Collection $journey, Collection $attempts, Collection $outcomes): array
    {
        $governance = is_array($task->governance) ? $task->governance : [];
        return match ($key) {
            'signal' => array_filter([
                'signal_id' => data_get($task->metadata ?? [], 'signal_id') ?? data_get($task->metadata ?? [], 'trigger_signal_id'),
                'event_type' => data_get($task->metadata ?? [], 'trigger_event_type') ?? data_get($task->metadata ?? [], 'event_type'),
                'source_ref' => $this->journeyMatch($journey, ['signal','trigger','ingress'])?->source_ref,
            ], static fn($v) => $v !== null && $v !== ''),
            'prime' => $this->structuredFromJourney($journey, ['prime','mission']),
            'ai_core' => $this->structuredFromJourney($journey, ['plan','objective']),
            'ai_runtime' => array_filter([
                'runtime_profile_id' => data_get($task->metadata ?? [], 'runtime_profile_id'),
                'result' => is_array($task->result) ? $task->result : null,
                'journey' => $this->structuredFromJourney($journey, ['runtime','reason','proposal']),
            ], static fn($v) => $v !== null && $v !== []),
            'model_council' => (array) data_get($governance, 'pre_execution.model_council', []),
            'risk' => is_array($task->risk_snapshot) ? $task->risk_snapshot : [],
            'assurance' => is_array($task->assurance_snapshot) ? $task->assurance_snapshot : [],
            'governance' => (array) (data_get($governance, 'pre_execution.autonomy.governance_constraint.constraint')
                ?? data_get($governance, 'pre_execution.governance_constraint.constraint')
                ?? data_get($governance, 'pre_execution.governance_constraint')
                ?? []),
            'autonomy' => is_array($task->autonomy_snapshot) ? $task->autonomy_snapshot : [],
            'command_bus' => ($attempt = $attempts->last()) ? array_filter([
                'attempt_uuid'=>$attempt->attempt_uuid, 'status'=>$attempt->status, 'receipt_ref'=>$attempt->receipt_ref,
                'receipt'=>$attempt->receipt, 'verification_status'=>$attempt->verification_status,
            ], static fn($v) => $v !== null && $v !== '') : [],
            'rewind' => ($attempt = $attempts->last()) ? array_filter([
                'recovery'=>$attempt->recovery, 'compensation_ref'=>$attempt->compensation_ref,
                'rewind_ref'=>data_get($governance, 'post_execution.rewind_ref'),
            ], static fn($v) => $v !== null && $v !== [] && $v !== '') : array_filter(['rewind_ref'=>data_get($governance, 'post_execution.rewind_ref')]),
            'wisdom' => ($outcome = $outcomes->last()) ? array_filter([
                'outcome_ref'=>$outcome->outcome_uuid ?? $outcome->id,
                'verified_at'=>$outcome->verified_at?->toIso8601String(), 'success'=>$outcome->success,
                'wisdom_ref'=>data_get($governance, 'post_execution.wisdom_ref'),
            ], static fn($v) => $v !== null && $v !== '') : [],
            default => [],
        };
    }

    private function stateFor(string $key, array $payload, array $availability, WorkforceTask $task, Collection $attempts, Collection $outcomes): string
    {
        if ($key === 'model_council' && (($payload['required'] ?? false) === false) && $payload !== []) return 'not_required';
        if ($key === 'rewind' && $payload === [] && ! in_array((string)($task->status?->value ?? $task->status), ['RECOVERY','FAILED'], true)) return 'not_required';
        if ($key === 'wisdom' && $outcomes->isNotEmpty() && ! $outcomes->last()?->verified_at) return 'pending';
        if ($payload !== []) {
            if ($this->payloadDenied($payload)) return 'failed';
            if ($this->payloadDegraded($payload)) return 'degraded';
            if ($key === 'command_bus' && strtoupper((string)($payload['status'] ?? '')) === 'DISPATCHING') return 'active';
            return 'completed';
        }
        if (($availability['available'] ?? false) !== true) return ($availability['required_for_execution'] ?? false) ? 'failed' : 'degraded';
        if ($attempts->isNotEmpty() && in_array($key, ['risk','assurance','governance','autonomy','command_bus'], true)) return 'pending';
        return 'pending';
    }

    private function payloadDenied(array $payload): bool
    {
        if (($payload['allowed'] ?? null) === false || ($payload['policy_satisfied'] ?? null) === false) return true;
        $state = strtoupper((string)($payload['state'] ?? $payload['status'] ?? ''));
        return in_array($state, ['FAILED','DENIED','BLOCKED','RED','REJECTED','RECOVERY_REQUIRED','COMMAND_BLOCKED'], true);
    }

    private function payloadDegraded(array $payload): bool
    {
        if (($payload['available'] ?? true) === false) return true;
        $state = strtoupper((string)($payload['state'] ?? $payload['status'] ?? ''));
        return in_array($state, ['DEGRADED','UNCERTAIN','PARTIAL'], true);
    }

    private function decisionFor(string $key, array $payload, Collection $attempts, Collection $outcomes): mixed
    {
        if ($payload === []) return null;
        return match ($key) {
            'risk' => ['decision_id'=>$payload['decision_id'] ?? null, 'allowed'=>$payload['allowed'] ?? null, 'level'=>$payload['level'] ?? null],
            'assurance' => ['decision_id'=>$payload['decision_id'] ?? null, 'allowed'=>$payload['allowed'] ?? null, 'state'=>$payload['state'] ?? null, 'missing_evidence'=>$payload['missing_evidence'] ?? []],
            'model_council' => ['decision_id'=>$payload['decision_id'] ?? null, 'consulted'=>$payload['consulted'] ?? null, 'policy_satisfied'=>$payload['policy_satisfied'] ?? null],
            'governance' => ['constraint_id'=>$payload['constraint_id'] ?? null, 'disposition'=>$payload['disposition'] ?? null, 'ceiling_score'=>$payload['ceiling_score'] ?? null],
            'autonomy' => ['decision_id'=>$payload['decision_id'] ?? null, 'allowed'=>$payload['allowed'] ?? null, 'effective_score'=>$payload['effective_score'] ?? null],
            'command_bus' => ['status'=>$payload['status'] ?? null, 'receipt_ref'=>$payload['receipt_ref'] ?? null, 'verification_status'=>$payload['verification_status'] ?? null],
            'rewind' => ['rewind_ref'=>$payload['rewind_ref'] ?? null, 'compensation_ref'=>$payload['compensation_ref'] ?? null, 'recovery'=>$payload['recovery'] ?? null],
            'wisdom' => ['outcome_ref'=>$payload['outcome_ref'] ?? null, 'verified_at'=>$payload['verified_at'] ?? null, 'success'=>$payload['success'] ?? null, 'wisdom_ref'=>$payload['wisdom_ref'] ?? null],
            default => $payload,
        };
    }

    /** @return list<string> */
    private function evidenceFor(string $key, array $payload, Collection $journey, Collection $evidence, Collection $outcomes): array
    {
        $refs = [];
        foreach (['evidence_refs','missing_evidence'] as $field) {
            foreach ((array)($payload[$field] ?? []) as $ref) if (is_scalar($ref) && (string)$ref !== '') $refs[] = (string)$ref;
        }
        $record = $this->journeyMatch($journey, $this->keywordsFor($key));
        if ($record) foreach ((array)$record->evidence_refs as $ref) if ((string)$ref !== '') $refs[] = (string)$ref;
        if ($key === 'signal') foreach ($evidence->take(3) as $row) $refs[] = (string)($row->reference ?: $row->evidence_uuid);
        if ($key === 'wisdom') foreach ($outcomes as $row) foreach ((array)$row->evidence_refs as $ref) $refs[] = (string)$ref;
        return array_values(array_unique(array_filter($refs)));
    }

    private function timestampFor(string $key, array $payload, Collection $journey, Collection $attempts, Collection $outcomes, WorkforceTask $task): ?CarbonInterface
    {
        $record = $this->journeyMatch($journey, $this->keywordsFor($key));
        if ($record?->observed_at instanceof CarbonInterface) return $record->observed_at;
        if ($key === 'command_bus' && ($attempt = $attempts->last())) return $attempt->dispatched_at ?? $attempt->created_at;
        if ($key === 'rewind' && ($attempt = $attempts->last()) && $payload !== []) return $attempt->verified_at ?? $attempt->updated_at ?? $attempt->created_at;
        if ($key === 'wisdom' && ($outcome = $outcomes->last())) return $outcome->verified_at ?? $outcome->observed_at ?? $outcome->created_at;
        if ($payload !== []) return $task->updated_at ?? $task->created_at;
        return null;
    }

    private function reasonFor(string $key, array $payload, array $availability, string $state): string
    {
        $candidates = [
            $payload['reason'] ?? null,
            $payload['reason_summary'] ?? null,
            is_array($payload['reason_codes'] ?? null) ? implode(', ', $payload['reason_codes']) : null,
            $availability['available'] ?? false ? null : ($availability['failure'] ?? 'provider_unavailable'),
        ];
        foreach ($candidates as $candidate) if (is_string($candidate) && trim($candidate) !== '') return trim($candidate);
        return match ($state) {
            'completed' => 'Stage evidence is present.',
            'not_required' => 'Stage was not required for this Work Item.',
            'active' => 'Stage is currently active.',
            'failed' => 'Stage failed closed or denied progression.',
            'degraded' => 'Stage is degraded or its provider is unavailable.',
            default => 'No authoritative stage evidence has been recorded yet.',
        };
    }

    private function failureFor(string $state, array $payload, array $availability): ?string
    {
        if ($state !== 'failed') return null;
        if (is_string($payload['reason'] ?? null)) return $payload['reason'];
        if (is_array($payload['reason_codes'] ?? null) && $payload['reason_codes'] !== []) return implode(', ', $payload['reason_codes']);
        return (string)($availability['failure'] ?? 'stage_failed');
    }

    private function degradationFor(string $state, array $availability, array $payload): ?string
    {
        if ($state !== 'degraded') return null;
        if (($availability['available'] ?? false) !== true) return 'Provider unavailable: '.(string)($availability['provider'] ?? 'unknown');
        if (is_string($payload['reason'] ?? null)) return $payload['reason'];
        return 'Recorded stage evidence indicates degraded or partial state.';
    }

    private function durationMs(?CarbonInterface $previous, ?CarbonInterface $current): ?int
    {
        if (! $previous || ! $current) return null;
        return (int) max(0, $previous->diffInMilliseconds($current));
    }

    private function journeyMatch(Collection $journey, array $keywords): ?WorkforceJourneyRecord
    {
        return $journey->first(function (WorkforceJourneyRecord $row) use ($keywords): bool {
            $haystack = strtolower(implode(' ', [(string)$row->phase, (string)$row->category, (string)$row->event_type, (string)$row->source_ref]));
            foreach ($keywords as $keyword) if (str_contains($haystack, strtolower($keyword))) return true;
            return false;
        });
    }

    private function structuredFromJourney(Collection $journey, array $keywords): array
    {
        $row = $this->journeyMatch($journey, $keywords);
        if (! $row) return [];
        return array_filter([
            'event_type'=>$row->event_type, 'source_ref'=>$row->source_ref,
            'decision_refs'=>$row->decision_refs, 'evidence_refs'=>$row->evidence_refs,
            'summary'=>$row->summary,
        ], static fn($v) => $v !== null && $v !== [] && $v !== '');
    }

    /** @return list<string> */
    private function keywordsFor(string $key): array
    {
        return match ($key) {
            'signal' => ['signal','trigger','ingress','observe'],
            'prime' => ['prime','mission'],
            'ai_core' => ['plan','objective','ai_core'],
            'ai_runtime' => ['runtime','reason','proposal'],
            'model_council' => ['model_council','deliberate'],
            'risk' => ['risk'],
            'assurance' => ['assurance','assure'],
            'governance' => ['governance','govern'],
            'autonomy' => ['autonomy','authorize'],
            'command_bus' => ['command','execution.started','execute'],
            'rewind' => ['rewind','recover','recovery'],
            'wisdom' => ['wisdom','outcome','learn'],
            default => [$key],
        };
    }
}
