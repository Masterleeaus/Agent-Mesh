<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\ProactiveWorkforceService;
use Illuminate\Console\Command;

class DispatchDueWorkforceSchedulesCommand extends Command
{
    protected $signature = 'titan-workforce:dispatch-due {--limit=100}';
    protected $description = 'Create governed Workforce tasks from due proactive responsibilities.';
    public function handle(ProactiveWorkforceService $service): int
    {
        $count = $service->dispatchDue((int) $this->option('limit'));
        $this->info("Dispatched {$count} proactive Workforce task(s).");
        return self::SUCCESS;
    }
}
