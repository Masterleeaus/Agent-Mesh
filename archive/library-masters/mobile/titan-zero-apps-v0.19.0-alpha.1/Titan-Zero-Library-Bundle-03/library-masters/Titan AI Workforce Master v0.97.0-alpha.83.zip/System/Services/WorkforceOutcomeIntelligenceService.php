<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;

final class WorkforceOutcomeIntelligenceService
{
    private const ACTIVITY = ['tasks','responses','reviews','execution_count'];
    private const OUTCOMES = [
        'quotes_accepted' => 'Quotes accepted',
        'jobs_completed' => 'Jobs completed',
        'invoices_paid' => 'Invoices paid',
        'complaints_resolved' => 'Complaints resolved',
        'cancellations_prevented' => 'Cancellations prevented',
        'reviews_received' => 'Reviews received',
        'customer_retention' => 'Customer retention',
        'recovered_revenue' => 'Recovered revenue',
    ];
    private const DIMENSIONS = ['employee','role','team','division','responsibility','workflow'];

    public function snapshot(int $companyId, string $dimension = 'employee'): array
    {
        if (! in_array($dimension, self::DIMENSIONS, true)) $dimension = 'employee';

        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->with(['assignee:id,name,role_definition_id,team_id,division_id','team:id,name','division:id,name'])
            ->latest('id')->limit(5000)->get();
        $taskIds = $tasks->pluck('id');

        $outcomes = WorkforceOutcome::query()->forCompany($companyId)
            ->whereNotNull('verified_at')->whereIn('task_id', $taskIds)->latest('verified_at')->limit(5000)->get();
        $attempts = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->whereIn('task_id', $taskIds)->get(['id','task_id']);
        $history = WorkforceTaskHistory::query()->where('company_id', $companyId)
            ->whereIn('task_id', $taskIds)->get(['task_id','event_type','context']);

        $activity = [
            'tasks' => $tasks->count(),
            'responses' => $history->filter(fn ($h) => $this->isResponse((string)$h->event_type, (array)($h->context ?? [])))->count(),
            'reviews' => $history->filter(fn ($h) => $this->isReview((string)$h->event_type))->count(),
            'execution_count' => $attempts->count(),
        ];

        $business = array_fill_keys(array_keys(self::OUTCOMES), 0.0);
        foreach ($outcomes as $outcome) {
            $key = $this->canonicalOutcome((string)$outcome->outcome_type);
            if ($key === null || $outcome->success === false) continue;
            $business[$key] += $key === 'recovered_revenue' ? $this->moneyValue((array)($outcome->summary ?? [])) : 1;
        }

        $tasksById = $tasks->keyBy('id');
        $attemptsByTask = $attempts->groupBy('task_id');
        $historyByTask = $history->groupBy('task_id');
        $outcomesByTask = $outcomes->groupBy('task_id');
        $rows = [];
        foreach ($tasks as $task) {
            $key = $this->dimensionKey($task, $dimension);
            if ($key['id'] === '') continue;
            $id = $key['id'];
            $rows[$id] ??= [
                'id'=>$id,'label'=>$key['label'],'dimension'=>$dimension,
                'activity'=>array_fill_keys(self::ACTIVITY, 0),
                'outcomes'=>array_fill_keys(array_keys(self::OUTCOMES), 0.0),
            ];
            $rows[$id]['activity']['tasks']++;
            $rows[$id]['activity']['execution_count'] += $attemptsByTask->get($task->id, collect())->count();
            $rows[$id]['activity']['responses'] += $historyByTask->get($task->id, collect())->filter(fn($h) => $this->isResponse((string)$h->event_type, (array)($h->context ?? [])))->count();
            $rows[$id]['activity']['reviews'] += $historyByTask->get($task->id, collect())->filter(fn($h) => $this->isReview((string)$h->event_type))->count();
            foreach ($outcomesByTask->get($task->id, collect()) as $outcome) {
                $outcomeKey = $this->canonicalOutcome((string)$outcome->outcome_type);
                if ($outcomeKey === null || $outcome->success === false) continue;
                $rows[$id]['outcomes'][$outcomeKey] += $outcomeKey === 'recovered_revenue' ? $this->moneyValue((array)($outcome->summary ?? [])) : 1;
            }
        }

        usort($rows, fn(array $a, array $b) => array_sum($b['outcomes']) <=> array_sum($a['outcomes']));

        return [
            'activity' => $activity,
            'outcomes' => $business,
            'outcome_labels' => self::OUTCOMES,
            'dimensions' => self::DIMENSIONS,
            'dimension' => $dimension,
            'rows' => array_values($rows),
            'verified_outcome_count' => $outcomes->count(),
            'activity_is_outcome' => false,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
            'read_only_projection' => true,
        ];
    }

    private function dimensionKey(WorkforceTask $task, string $dimension): array
    {
        $meta = (array)($task->metadata ?? []);
        return match ($dimension) {
            'employee' => ['id'=>(string)($task->assignee_member_id ?? ''), 'label'=>(string)($task->assignee?->name ?? 'Unassigned')],
            'role' => ['id'=>(string)($task->role_definition_id ?? $task->assignee?->role_definition_id ?? ''), 'label'=>(string)($task->role_definition_id ?? $task->assignee?->role_definition_id ?? 'Unspecified role')],
            'team' => ['id'=>(string)($task->team_id ?? ''), 'label'=>(string)($task->team?->name ?? 'No team')],
            'division' => ['id'=>(string)($task->division_id ?? ''), 'label'=>(string)($task->division?->name ?? 'No division')],
            'responsibility' => ['id'=>(string)($meta['responsibility_id'] ?? $meta['responsibility_definition_id'] ?? ''), 'label'=>(string)($meta['responsibility_name'] ?? $meta['responsibility_id'] ?? 'Unspecified responsibility')],
            'workflow' => ['id'=>(string)($task->workflow_ref ?? $meta['workflow_ref'] ?? ''), 'label'=>(string)($task->workflow_ref ?? $meta['workflow_ref'] ?? 'Unspecified workflow')],
            default => ['id'=>'','label'=>''],
        };
    }

    private function canonicalOutcome(string $type): ?string
    {
        $v = strtolower(trim(str_replace(['.','-',' '], '_', $type)));
        $aliases = [
            'quote_accepted'=>'quotes_accepted','quotes_accepted'=>'quotes_accepted','quote_approved'=>'quotes_accepted',
            'job_completed'=>'jobs_completed','jobs_completed'=>'jobs_completed','work_completed'=>'jobs_completed',
            'invoice_paid'=>'invoices_paid','invoices_paid'=>'invoices_paid','payment_received'=>'invoices_paid',
            'complaint_resolved'=>'complaints_resolved','complaints_resolved'=>'complaints_resolved','service_recovery_completed'=>'complaints_resolved',
            'cancellation_prevented'=>'cancellations_prevented','cancellations_prevented'=>'cancellations_prevented',
            'review_received'=>'reviews_received','reviews_received'=>'reviews_received','customer_review_received'=>'reviews_received',
            'customer_retained'=>'customer_retention','customer_retention'=>'customer_retention','retention'=>'customer_retention',
            'recovered_revenue'=>'recovered_revenue','revenue_recovered'=>'recovered_revenue','recovery_revenue'=>'recovered_revenue',
        ];
        return $aliases[$v] ?? null;
    }

    private function moneyValue(array $summary): float
    {
        foreach (['recovered_revenue','amount','value','revenue'] as $key) {
            if (isset($summary[$key]) && is_numeric($summary[$key])) return (float)$summary[$key];
        }
        return 0.0;
    }

    private function isResponse(string $event, array $context): bool
    {
        $v = strtolower($event.' '.(string)($context['action'] ?? ''));
        return str_contains($v, 'response') || str_contains($v, 'reply') || str_contains($v, 'respond');
    }

    private function isReview(string $event): bool
    {
        $v = strtolower($event);
        return str_contains($v, 'review') || str_contains($v, 'approved') || str_contains($v, 'revision');
    }
}
