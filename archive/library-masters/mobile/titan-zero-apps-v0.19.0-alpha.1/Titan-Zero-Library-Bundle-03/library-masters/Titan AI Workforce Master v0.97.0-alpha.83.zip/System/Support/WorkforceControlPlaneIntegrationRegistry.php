<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use Illuminate\Contracts\Container\Container;
use RuntimeException;
use Throwable;

/**
 * Canonical, non-authoritative map of Workforce's control-plane lifecycle.
 *
 * The registry declares where each Titan engine participates and how it is
 * late-bound. It never grants authority and it never treats installation as
 * proof that an execution gate has passed.
 */
final class WorkforceControlPlaneIntegrationRegistry
{
    public const PROVIDER_GOVERNANCE = 'titan-governance';
    public const PROVIDER_COMMAND_BUS = 'titan-command-bus';
    private const DEFAULT_REGISTRY = __DIR__ . '/../../resources/workforce/control-plane-integration-registry.json';

    /** @var array<string,mixed>|null */
    private ?array $catalog = null;

    public function __construct(
        private readonly Container $app,
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly ?string $registryPath = null,
    ) {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->catalog !== null) return $this->catalog;
        $path = $this->registryPath ?: self::DEFAULT_REGISTRY;
        if (! is_file($path)) throw new RuntimeException("Titan Workforce control-plane registry missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true);
        if (! is_array($decoded)
            || ($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['integrations'] ?? null)
            || count($decoded['integrations']) !== 12) {
            throw new RuntimeException('Titan Workforce control-plane registry is invalid.');
        }
        foreach ($decoded['integrations'] as $integration) {
            if (! is_array($integration) || ($integration['authority_inherited'] ?? null) !== false) {
                throw new RuntimeException('Control-plane integration authority inheritance is prohibited.');
            }
            $provider = trim((string) ($integration['provider'] ?? ''));
            if ($provider === '' || $this->ecosystem->provider($provider) === null) {
                throw new RuntimeException("Unknown control-plane provider: {$provider}");
            }
        }
        return $this->catalog = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public function integrations(): array
    {
        /** @var list<array<string,mixed>> $rows */
        $rows = array_values(array_filter($this->all()['integrations'], 'is_array'));
        usort($rows, static fn(array $a, array $b): int => ((int) ($a['order'] ?? 0)) <=> ((int) ($b['order'] ?? 0)));
        return $rows;
    }

    /** @return array<string,mixed>|null */
    public function integration(string $key): ?array
    {
        $needle = strtolower(trim($key));
        foreach ($this->integrations() as $integration) {
            if (strtolower((string) ($integration['key'] ?? '')) === $needle) return $integration;
        }
        return null;
    }

    /** @return list<string> */
    public function bindingsFor(string $key): array
    {
        $integration = $this->integration($key);
        if (! $integration) return [];
        return array_values(array_unique(array_filter(array_map('strval', (array) ($integration['bindings'] ?? [])))));
    }

    /** @return list<string> */
    public function methodsFor(string $key): array
    {
        $integration = $this->integration($key);
        if (! $integration) return [];
        return array_values(array_unique(array_filter(array_map('strval', (array) ($integration['methods'] ?? [])))));
    }

    /**
     * Installation and binding availability are intentionally separate. A class
     * existing on disk is not proof that its runtime adapter is ready.
     *
     * @return array<string,mixed>
     */
    public function availability(string $key): array
    {
        $integration = $this->integration($key);
        if (! $integration) return ['key' => $key, 'installed' => false, 'bound' => false, 'available' => false, 'binding' => null];
        $providerKey = (string) $integration['provider'];
        $provider = $this->ecosystem->provider($providerKey);
        $providerClass = trim((string) data_get($provider ?? [], 'extension.provider_class', ''));
        $installed = $providerClass !== '' && class_exists($providerClass);
        $binding = null;
        foreach ($this->bindingsFor($key) as $candidate) {
            try {
                if ($this->app->bound($candidate)) { $binding = $candidate; break; }
            } catch (Throwable) {
                continue;
            }
        }
        return [
            'key' => (string) $integration['key'],
            'stage' => (string) $integration['stage'],
            'provider' => $providerKey,
            'provider_class' => $providerClass,
            'installed' => $installed,
            'bound' => $binding !== null,
            'available' => $binding !== null,
            'binding' => $binding,
            'required' => (string) $integration['required'],
            'required_for_execution' => (bool) $integration['required_for_execution'],
            'failure' => (string) $integration['failure'],
            'authority_inherited' => false,
        ];
    }

    /** @return array{company_id:int,ready:bool,gates:array<string,array<string,mixed>>,missing:list<string>} */
    public function executionGateStatus(int $companyId): array
    {
        if ($companyId <= 0) throw new RuntimeException('company_id must be positive.');
        $gates = [];
        $missing = [];
        foreach ((array) ($this->all()['execution_gate_keys'] ?? []) as $key) {
            $key = (string) $key;
            $status = $this->availability($key);
            $gates[$key] = $status;
            if (($status['available'] ?? false) !== true) $missing[] = $key;
        }
        return ['company_id' => $companyId, 'ready' => $missing === [], 'gates' => $gates, 'missing' => $missing];
    }

    /** @return array{service:object,binding:string}|null */
    public function resolve(string $key): ?array
    {
        foreach ($this->bindingsFor($key) as $binding) {
            try {
                if (! $this->app->bound($binding)) continue;
                $service = $this->app->make($binding);
                if (is_object($service)) return ['service' => $service, 'binding' => $binding];
            } catch (Throwable) {
                continue;
            }
        }
        return null;
    }
}
