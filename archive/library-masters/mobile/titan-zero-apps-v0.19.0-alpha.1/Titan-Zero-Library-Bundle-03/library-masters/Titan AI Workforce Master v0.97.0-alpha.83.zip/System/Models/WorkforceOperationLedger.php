<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceOperationLedger extends Model
{
    protected $table='ext_titan_ai_workforce_operation_ledger';
    protected $guarded=[];
    protected $casts=[
        'result_snapshot'=>'array','replay_count'=>'integer',
        'started_at'=>'datetime','completed_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
