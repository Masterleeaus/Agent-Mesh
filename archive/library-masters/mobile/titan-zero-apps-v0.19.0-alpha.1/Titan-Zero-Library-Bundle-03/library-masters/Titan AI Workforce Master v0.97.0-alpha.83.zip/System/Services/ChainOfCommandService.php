<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\DeadlockResolution;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceHandoffStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ExecuteWorkforceActionJob;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class ChainOfCommandService
{
    public function __construct(
        private readonly WorkforceTaskService $tasks,
        private readonly ManagerContinuityService $continuity,
        private readonly WorkloadSharingService $workload,
        private readonly WorkforceHandoffPacketService $packets,
        private readonly WorkforceDecisionChainService $decisionChains,
    ) {}

    public function submit(WorkforceTask $task, WorkforceMember $maker): WorkforceTask
    {
        $this->assertCompany($task, $maker);
        if ((int) $task->assignee_member_id !== (int) $maker->id) {
            throw new InvalidArgumentException('Only the assigned Maker may submit this Workforce task.');
        }
        if (! $maker->manager_id) { throw new InvalidArgumentException('Maker has no Manager assigned.'); }
        if ((int) $maker->manager_id === (int) $maker->id) {
            throw new InvalidArgumentException('Maker cannot be its own reviewing Manager.');
        }
        $task->forceFill(['manager_member_id' => $maker->manager_id])->save();
        if ($task->status !== WorkforceTaskStatus::Submitted) {
            $task = $this->tasks->transition($task, WorkforceTaskStatus::Submitted, $maker, 'task.submitted', 'Maker submitted completed work for independent review.');
        }
        return $this->tasks->transition($task, WorkforceTaskStatus::UnderReview, $maker, 'task.under_review', 'Submitted to originating Manager for independent review.');
    }

    public function managerDecision(WorkforceTask $task, WorkforceMember $reviewer, bool $approve, ?string $reason = null): WorkforceTask
    {
        $this->assertCompany($task, $reviewer);
        $assignedManager = WorkforceMember::query()->forCompany((int) $task->company_id)->findOrFail($task->manager_member_id);
        $acting = $this->continuity->resolveReviewer($assignedManager, $reviewer, 'task.review');
        if ((int) $task->assignee_member_id === (int) $acting->id) {
            throw new InvalidArgumentException('Maker cannot approve its own Workforce task.');
        }
        $context = (int) $acting->id !== (int) $assignedManager->id ? ['acting_for_manager_id' => $assignedManager->id] : [];

        $task = $this->tasks->transition(
            $task,
            $approve ? WorkforceTaskStatus::Approved : WorkforceTaskStatus::RevisionRequired,
            $acting,
            $approve ? 'manager.approved' : 'manager.revision_required',
            $reason,
            $context,
        );
        if (! $approve) return $task;

        $maker = $task->assignee_member_id
            ? WorkforceMember::query()->forCompany((int) $task->company_id)->find($task->assignee_member_id)
            : null;
        if ($maker?->tier === WorkforceTier::ActionWorker) {
            $consequential = (bool) data_get($task->metadata ?? [], 'consequential',
                data_get($task->payload ?? [], 'consequential', true)
            );
            if ($consequential) {
                $this->decisionChains->assertAuthorityReady($task);
            }
            ExecuteWorkforceActionJob::dispatch((int) $task->company_id, (int) $task->id);
            return $task;
        }

        if ((bool) data_get($task->metadata ?? [], 'cross_division_handoff', false)) {
            $this->plannedHandoff($task, $acting);
            return $task->refresh();
        }
        return $task;
    }

    public function handoff(WorkforceTask $task, WorkforceMember $originReviewer, WorkforceMember $receivingManager, ?WorkforceMember $receivingSpecialist = null, ?string $reason = null, array $metadata = []): WorkforceTaskHandoff
    {
        $this->assertCompany($task, $originReviewer);
        $this->assertCompany($task, $receivingManager);
        if ($receivingSpecialist) $this->assertCompany($task, $receivingSpecialist);

        return DB::transaction(function () use ($task, $originReviewer, $receivingManager, $receivingSpecialist, $reason, $metadata) {
            $lockedTask = WorkforceTask::query()->forCompany((int) $task->company_id)->whereKey($task->id)->lockForUpdate()->firstOrFail();
            $existing = $this->activeHandoffForTask($lockedTask);
            if ($existing) {
                if ((int) $existing->receiving_manager_id !== (int) $receivingManager->id) {
                    throw new InvalidArgumentException('An active Workforce handoff already owns receiver review for this task.');
                }
                $this->packets->verify($existing);
                return $existing;
            }
            if ($lockedTask->status !== WorkforceTaskStatus::Approved) {
                throw new InvalidArgumentException('Only approved work may enter a cross-division handoff.');
            }

            $assignedOriginManager = WorkforceMember::query()->forCompany((int) $lockedTask->company_id)->findOrFail($lockedTask->manager_member_id);
            $acting = $this->continuity->resolveReviewer($assignedOriginManager, $originReviewer, 'task.handoff');
            $approvalEvidence = $this->assertOriginManagerApprovalEvidence($lockedTask, $assignedOriginManager);
            $this->assertIndependentReview($lockedTask, $assignedOriginManager, $acting, $receivingManager);

            if ($receivingManager->tier !== WorkforceTier::Manager) {
                throw new InvalidArgumentException('Cross-division handoff must be addressed to a receiving Manager.');
            }
            if ((int) $receivingManager->division_id === (int) $lockedTask->division_id) {
                throw new InvalidArgumentException('Cross-division handoff must target another division.');
            }
            if ($receivingSpecialist && ((int) $receivingSpecialist->division_id !== (int) $receivingManager->division_id || $receivingSpecialist->tier !== WorkforceTier::Specialist)) {
                throw new InvalidArgumentException('Receiving specialist does not belong to the receiving Manager division.');
            }

            $handoffUuid = (string) Str::uuid();
            $metadata = array_merge($metadata, [
                'origin_manager_review_history_id' => $approvalEvidence->id,
                'origin_manager_reviewed_by_member_id' => $approvalEvidence->actor_member_id,
            ]);
            $packet = $this->packets->build($lockedTask, $assignedOriginManager, $acting, $receivingManager, $receivingSpecialist, $handoffUuid, $reason, $metadata);
            $handoffMetadata = array_merge($metadata, [
                'approved_by_member_id' => $acting->id,
                'acting_for_manager_id' => (int) $acting->id !== (int) $assignedOriginManager->id ? $assignedOriginManager->id : null,
                'authority_inherited' => false,
                'packet_immutable' => true,
            ]);
            $handoff = WorkforceTaskHandoff::query()->create([
                'handoff_uuid' => $handoffUuid,
                'company_id' => $lockedTask->company_id,
                'task_id' => $lockedTask->id,
                'origin_member_id' => $lockedTask->assignee_member_id,
                'origin_manager_id' => $assignedOriginManager->id,
                'receiving_division_id' => $receivingManager->division_id,
                'receiving_manager_id' => $receivingManager->id,
                'receiving_specialist_id' => $receivingSpecialist?->id,
                'status' => WorkforceHandoffStatus::ReceiverReview,
                'packet_version' => $packet['packet_version'],
                'packet_sha256' => $packet['packet_sha256'],
                'packet' => $packet['packet'],
                'trace_id' => $lockedTask->trace_id,
                'correlation_id' => $lockedTask->correlation_id,
                'causation_id' => $lockedTask->task_uuid,
                'decision_version' => 0,
                'reason' => $reason,
                'evidence' => $lockedTask->evidence ?? [],
                'metadata' => $handoffMetadata,
            ]);
            $this->tasks->transition($lockedTask, WorkforceTaskStatus::ReceiverReview, $acting, 'handoff.requested', $reason, [
                'handoff_id' => $handoff->handoff_uuid,
                'handoff_packet_sha256' => $handoff->packet_sha256,
                'receiving_manager_id' => $receivingManager->id,
                'acting_for_manager_id' => $handoffMetadata['acting_for_manager_id'],
            ]);
            return $handoff;
        });
    }

    public function receiverDecision(WorkforceTaskHandoff $handoff, WorkforceMember $reviewer, bool $accept, ?string $reason = null): WorkforceTask
    {
        return DB::transaction(function () use ($handoff, $reviewer, $accept, $reason) {
            $lockedHandoff = WorkforceTaskHandoff::query()
                ->forCompany((int) $handoff->company_id)
                ->whereKey($handoff->id)
                ->lockForUpdate()
                ->firstOrFail();

            $task = WorkforceTask::query()
                ->forCompany((int) $lockedHandoff->company_id)
                ->whereKey($lockedHandoff->task_id)
                ->lockForUpdate()
                ->firstOrFail();
            $this->assertCompany($task, $reviewer);

            if ($lockedHandoff->status === WorkforceHandoffStatus::Accepted) {
                if (! $accept) throw new InvalidArgumentException('Conflicting receiver decision rejected for an accepted handoff.');
                if (! $lockedHandoff->accepted_task_id) throw new InvalidArgumentException('Accepted handoff is missing its receiving task reference.');
                return WorkforceTask::query()->forCompany((int) $lockedHandoff->company_id)->findOrFail($lockedHandoff->accepted_task_id);
            }
            if ($lockedHandoff->status === WorkforceHandoffStatus::Returned) {
                if ($accept) throw new InvalidArgumentException('Conflicting receiver decision rejected for a returned handoff.');
                return $task;
            }
            if ($lockedHandoff->status !== WorkforceHandoffStatus::ReceiverReview) {
                throw new InvalidArgumentException('Handoff is not awaiting a receiving Manager decision.');
            }

            $assignedReceiver = WorkforceMember::query()->forCompany((int) $lockedHandoff->company_id)->findOrFail($lockedHandoff->receiving_manager_id);
            $acting = $this->continuity->resolveReviewer($assignedReceiver, $reviewer, 'handoff.review');
            $originManager = WorkforceMember::query()->forCompany((int) $lockedHandoff->company_id)->findOrFail($lockedHandoff->origin_manager_id);
            $this->assertIndependentReview($task, $originManager, $originManager, $assignedReceiver, $acting);

            $decisionId = (string) Str::uuid();
            $actingFor = (int) $acting->id !== (int) $assignedReceiver->id ? $assignedReceiver->id : null;
            $hasImmutablePacket = is_array($lockedHandoff->packet) && $lockedHandoff->packet !== [] && is_string($lockedHandoff->packet_sha256) && $lockedHandoff->packet_sha256 !== '';
            if (! $hasImmutablePacket && $accept) {
                throw new InvalidArgumentException('Legacy handoff cannot be accepted without an immutable v2 packet; return it for re-review and reissue.');
            }
            if ($hasImmutablePacket) {
                $this->packets->verify($lockedHandoff);
            }
            if (! $accept) {
                $lockedHandoff->forceFill([
                    'status' => WorkforceHandoffStatus::Returned,
                    'decision_version' => (int) $lockedHandoff->decision_version + 1,
                    'decision_id' => $decisionId,
                    'decided_by_member_id' => $acting->id,
                    'decision_reason' => $reason,
                    'reviewed_at' => now(),
                    'metadata' => array_merge($lockedHandoff->metadata ?? [], [
                        'receiver_reviewed_by_member_id' => $acting->id,
                        'receiver_acting_for_manager_id' => $actingFor,
                    ]),
                ])->save();
                return $this->tasks->transition($task, WorkforceTaskStatus::RevisionRequired, $acting, 'handoff.returned', $reason, [
                    'handoff_id' => $lockedHandoff->handoff_uuid,
                    'handoff_packet_sha256' => $lockedHandoff->packet_sha256,
                    'decision_id' => $decisionId,
                    'acting_for_manager_id' => $actingFor,
                ]);
            }

            $packet = $lockedHandoff->packet ?? [];
            $routing = is_array($packet['routing'] ?? null) ? $packet['routing'] : [];
            $receivingRoleKey = (string) ($routing['receiving_role_key'] ?? '');
            $receivingCapability = (string) ($routing['receiving_capability'] ?? ($packet['capability'] ?? ''));
            $specialistId = $lockedHandoff->receiving_specialist_id;
            if (! $specialistId && $receivingRoleKey !== '') {
                $specialistId = $this->workload->findForRole(
                    (int) $lockedHandoff->company_id,
                    (int) $lockedHandoff->receiving_division_id,
                    $receivingRoleKey,
                    $receivingCapability,
                    (string) ($packet['risk_level'] ?? $task->risk_level),
                )?->id;
            }

            $task = $this->tasks->transition($task, WorkforceTaskStatus::Accepted, $acting, 'handoff.accepted', $reason, [
                'handoff_id' => $lockedHandoff->handoff_uuid,
                'handoff_packet_sha256' => $lockedHandoff->packet_sha256,
                'decision_id' => $decisionId,
                'acting_for_manager_id' => $actingFor,
            ]);

            $specialist = $specialistId
                ? WorkforceMember::query()->forCompany((int) $task->company_id)->find($specialistId)
                : null;
            $receivingTask = $this->tasks->create((int) $task->company_id, [
                'parent_task_id' => $task->id,
                'division_id' => $lockedHandoff->receiving_division_id,
                'team_id' => $specialist?->team_id,
                'assignee_member_id' => $specialistId,
                'manager_member_id' => $assignedReceiver->id,
                'origin_type' => 'workforce_handoff',
                'origin_id' => $lockedHandoff->handoff_uuid,
                'title' => 'Handoff: ' . $task->title,
                'description' => 'Accepted immutable cross-division work packet. Begin a new governed specialist cycle in the receiving division.',
                'capability' => $receivingCapability !== '' ? $receivingCapability : null,
                'status' => $specialistId ? WorkforceTaskStatus::Assigned : WorkforceTaskStatus::Blocked,
                'priority' => $task->priority,
                'risk_level' => (string) ($packet['risk_level'] ?? $task->risk_level),
                'payload' => [
                    'source_task_uuid' => $packet['source_task_uuid'] ?? $task->task_uuid,
                    'handoff_uuid' => $lockedHandoff->handoff_uuid,
                    'handoff_packet_sha256' => $lockedHandoff->packet_sha256,
                    'source_payload' => $packet['payload'] ?? [],
                    'source_result' => $packet['result'] ?? [],
                    'source_governance' => $packet['governance'] ?? [],
                    'source_evidence_refs' => $packet['evidence_refs'] ?? [],
                ],
                'evidence' => $packet['evidence'] ?? [],
                'trace_id' => $lockedHandoff->trace_id ?: $task->trace_id,
                'correlation_id' => $lockedHandoff->correlation_id ?: $task->correlation_id,
                'causation_id' => $lockedHandoff->handoff_uuid,
                'idempotency_key' => 'handoff-receive:' . $lockedHandoff->handoff_uuid,
                'metadata' => [
                    'source_handoff_uuid' => $lockedHandoff->handoff_uuid,
                    'handoff_packet_sha256' => $lockedHandoff->packet_sha256,
                    'receiving_role_key' => $receivingRoleKey !== '' ? $receivingRoleKey : null,
                    'inherited_risk_level' => $packet['risk_level'] ?? $task->risk_level,
                    'handoff_evidence_refs' => $packet['evidence_refs'] ?? [],
                    'new_governed_cycle' => true,
                    'authority_inherited' => false,
                ],
            ], $acting);

            $lockedHandoff->forceFill([
                'status' => WorkforceHandoffStatus::Accepted,
                'decision_version' => (int) $lockedHandoff->decision_version + 1,
                'decision_id' => $decisionId,
                'accepted_task_id' => $receivingTask->id,
                'decided_by_member_id' => $acting->id,
                'decision_reason' => $reason,
                'reviewed_at' => now(),
                'metadata' => array_merge($lockedHandoff->metadata ?? [], [
                    'receiver_reviewed_by_member_id' => $acting->id,
                    'receiver_acting_for_manager_id' => $actingFor,
                    'accepted_task_uuid' => $receivingTask->task_uuid,
                ]),
            ])->save();

            $this->tasks->transition($task->refresh(), WorkforceTaskStatus::Completed, $acting, 'handoff.origin_completed', 'Originating division responsibility transferred after receiving Manager acceptance.', [
                'handoff_id' => $lockedHandoff->handoff_uuid,
                'handoff_packet_sha256' => $lockedHandoff->packet_sha256,
                'receiving_task_uuid' => $receivingTask->task_uuid,
                'decision_id' => $decisionId,
            ]);

            if ($specialistId) {
                ProcessWorkforceTaskJob::dispatch((int) $receivingTask->company_id, (int) $receivingTask->id);
            } else {
                $this->tasks->record($receivingTask, $acting, 'handoff.staffing_gap', $receivingTask->status->value, $receivingTask->status->value, 'Receiving division accepted responsibility but has no eligible specialist capacity.', [
                    'receiving_role_key' => $receivingRoleKey,
                    'receiving_capability' => $receivingCapability,
                ]);
            }
            return $receivingTask;
        });
    }

    public function resolveDeadlock(WorkforceTask $task, WorkforceMember $actor, DeadlockResolution $resolution, ?string $reason = null): WorkforceTask
    {
        return match ($resolution) {
            DeadlockResolution::RetryWithEvidence => $this->tasks->transition($task, WorkforceTaskStatus::AwaitingData, $actor, 'deadlock.retry_with_evidence', $reason),
            DeadlockResolution::ReturnToMaker => $this->tasks->transition($task, WorkforceTaskStatus::RevisionRequired, $actor, 'deadlock.return_to_maker', $reason),
            DeadlockResolution::EscalateToParent, DeadlockResolution::EscalateToTitan => $this->tasks->transition($task, WorkforceTaskStatus::Escalated, $actor, 'deadlock.escalated', $reason, ['resolution' => $resolution->value]),
            DeadlockResolution::HumanDecisionRequired => $this->tasks->transition($task, WorkforceTaskStatus::Escalated, $actor, 'deadlock.human_required', $reason, ['resolution' => $resolution->value]),
        };
    }

    private function plannedHandoff(WorkforceTask $task, WorkforceMember $originReviewer): void
    {
        $divisionKey = (string) data_get($task->metadata ?? [], 'handoff_to_division', '');
        $roleKey = (string) data_get($task->metadata ?? [], 'handoff_to_role_key', '');
        $receivingCapability = (string) data_get($task->metadata ?? [], 'handoff_to_capability', '');
        $division = WorkforceDivision::query()->forCompany((int) $task->company_id)->where('key', $divisionKey)->first();
        if (! $division) {
            $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $originReviewer, 'handoff.division_missing', 'Planned receiving division is not provisioned.', ['division_key' => $divisionKey]);
            return;
        }
        $receiverRole = $roleKey !== '' ? WorkforceRoleRegistry::find($roleKey) : null;
        $managerRoleKey = (string) ($receiverRole['escalation_path'] ?? '');
        $managerDefinition = $managerRoleKey !== '' ? WorkforceRoleRegistry::find($managerRoleKey) : null;
        $manager = WorkforceMember::query()->forCompany((int) $task->company_id)
            ->staffingSeats()
            ->where('division_id', $division->id)
            ->where('tier', WorkforceTier::Manager->value)
            ->where('is_active', true)
            ->when($managerRoleKey !== '', function ($q) use ($managerRoleKey, $managerDefinition) {
                $q->where(function ($inner) use ($managerRoleKey, $managerDefinition) {
                    $inner->where('key', $managerRoleKey);
                    if (! empty($managerDefinition['role_id'])) $inner->orWhere('role_definition_id', $managerDefinition['role_id']);
                });
            })
            ->orderBy('id')->first();
        if (! $manager) {
            $this->tasks->transition($task, WorkforceTaskStatus::Blocked, $originReviewer, 'handoff.manager_missing', 'Planned receiving division has no active Manager.', ['division_key' => $divisionKey]);
            return;
        }
        $specialist = $roleKey !== '' ? $this->workload->findForRole((int) $task->company_id, (int) $division->id, $roleKey, $receivingCapability, (string) $task->risk_level) : null;
        $this->handoff($task, $originReviewer, $manager, $specialist, 'Planned cross-division handoff after originating Manager approval.', [
            'receiving_role_key' => $roleKey !== '' ? $roleKey : null,
            'receiving_capability' => $receivingCapability !== '' ? $receivingCapability : null,
            'planned_handoff' => true,
        ]);
    }

    private function assertOriginManagerApprovalEvidence(WorkforceTask $task, WorkforceMember $assignedManager): WorkforceTaskHistory
    {
        $reviews = WorkforceTaskHistory::query()
            ->where('company_id', $task->company_id)
            ->where('task_id', $task->id)
            ->where('event', 'manager.approved')
            ->orderByDesc('id')
            ->get();
        foreach ($reviews as $review) {
            if ((int) $review->actor_member_id === (int) $assignedManager->id) return $review;
            if ((int) data_get($review->context ?? [], 'acting_for_manager_id', 0) === (int) $assignedManager->id) return $review;
        }
        throw new InvalidArgumentException('Cross-division handoff requires recorded originating Manager approval evidence.');
    }

    private function activeHandoffForTask(WorkforceTask $task): ?WorkforceTaskHandoff
    {
        return WorkforceTaskHandoff::query()
            ->forCompany((int) $task->company_id)
            ->where('task_id', $task->id)
            ->whereIn('status', [WorkforceHandoffStatus::Pending->value, WorkforceHandoffStatus::ReceiverReview->value])
            ->orderBy('id')
            ->lockForUpdate()
            ->first();
    }

    private function assertIndependentReview(
        WorkforceTask $task,
        WorkforceMember $originManager,
        WorkforceMember $originReviewer,
        WorkforceMember $receivingManager,
        ?WorkforceMember $receivingReviewer = null,
    ): void {
        $makerId = $task->assignee_member_id ? (int) $task->assignee_member_id : null;
        if ($makerId !== null && ((int) $originManager->id === $makerId || (int) $originReviewer->id === $makerId)) {
            throw new InvalidArgumentException('Maker cannot self-approve consequential cross-division work.');
        }
        if ((int) $receivingManager->id === (int) $originManager->id || ($makerId !== null && (int) $receivingManager->id === $makerId)) {
            throw new InvalidArgumentException('Receiver Manager cannot be the originating Maker or Manager.');
        }
        if ($receivingReviewer && ((int) $receivingReviewer->id === (int) $originManager->id || ($makerId !== null && (int) $receivingReviewer->id === $makerId))) {
            throw new InvalidArgumentException('Receiving reviewer must remain independent from Maker and originating Manager.');
        }
    }

    private function assertCompany(WorkforceTask $task, WorkforceMember $member): void
    {
        if ((int) $task->company_id !== (int) $member->company_id) { throw new InvalidArgumentException('Cross-tenant Workforce operation rejected.'); }
    }
}
