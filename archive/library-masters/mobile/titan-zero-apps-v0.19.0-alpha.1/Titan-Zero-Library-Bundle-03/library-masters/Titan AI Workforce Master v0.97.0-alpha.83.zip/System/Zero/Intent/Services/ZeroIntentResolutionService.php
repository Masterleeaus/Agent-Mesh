<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services;

use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Contracts\ZeroIntentResolverContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroSemanticCapabilityCatalogueContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilityDiscoveryContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextGatewayContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Conversation\Services\ZeroConversationContextService;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums\ZeroIntentResolutionStatus;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentGraph;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentNode;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentRequest;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects\ZeroIntentResolution;

/**
 * Canonical non-mutating Zero intent facade.
 *
 * Pass 3 attaches advisory ranked capability candidates from the semantic catalogue.
 * Parameter completion, business-context authority, governance approval, and execution remain later gates.
 */
final class ZeroIntentResolutionService implements ZeroIntentResolverContract
{
    public function __construct(
        private readonly ZeroBaselineIntentClassifier $baseline,
        private readonly ?ZeroSemanticCapabilityCatalogueContract $semanticCatalogue = null,
        private readonly ?ZeroCapabilityDiscoveryContract $capabilityDiscovery = null,
        private readonly ?ZeroBusinessContextGatewayContract $businessContextGateway = null,
        private readonly ?ZeroConversationContextService $conversationContext = null,
        private readonly ?ZeroMultiIntentDecompositionService $multiIntent = null,
    ) {}

    public function resolve(ZeroIntentRequest $request): ZeroIntentResolution
    {
        $conversationContext = null;
        $conversationContextPersisted = false;
        if ($this->conversationContext !== null && trim((string) ($request->actorId ?? '')) !== '') {
            $conversationContext = $this->conversationContext->open($request->companyId, $request->conversationId, (string) $request->actorId);
            $this->conversationContext->recordTurn($conversationContext, 'user', $request->message, [
                'trace_id' => $request->traceId,
                'correlation_id' => $request->correlationId,
                'modality' => $request->modality->value,
            ]);
            $conversationContextPersisted = true;
        }

        $classified = $this->baseline->classify($request->message, [
            'company_id' => $request->companyId,
            'user_id' => $request->actorId,
            'actor_id' => $request->actorId,
            'correlation_id' => $request->correlationId,
            'online' => (bool)($request->contextHints['online'] ?? false),
        ]);
        $recognized = (bool) ($classified['recognized'] ?? false);
        $intent = (string) ($classified['intent'] ?? 'unknown');
        $confidence = (float) ($classified['confidence'] ?? 0.0);
        $nodeId = 'intent:'.substr(hash('sha256', $request->traceId.'|'.$intent.'|'.$request->message), 0, 24);

        $discoveryContext = is_array($request->contextHints['capability_discovery'] ?? null)
            ? $request->contextHints['capability_discovery']
            : [];
        $discovery = $this->capabilityDiscovery !== null && $request->message !== ''
            ? $this->capabilityDiscovery->discover($request->message, $discoveryContext)
            : null;
        $capabilityCandidates = is_array($discovery['candidates'] ?? null) ? $discovery['candidates'] : [];
        $capabilityDiscoveryComplete = ($discovery['complete'] ?? false) === true && $capabilityCandidates !== [];

        $businessContextPlan = null;
        $businessContextPlanReason = null;
        if ($this->businessContextGateway !== null) {
            $actorId = trim((string) ($request->actorId ?? ''));
            if ($actorId === '') {
                $businessContextPlanReason = 'actor_id_required';
            } else {
                $hint = is_array($request->contextHints['business_context'] ?? null)
                    ? $request->contextHints['business_context']
                    : [];
                $purpose = trim((string) ($hint['purpose'] ?? ''));
                if ($purpose === '') {
                    $purpose = 'Resolve business context for Zero intent: '.mb_substr($request->message, 0, 180);
                }
                unset($hint['purpose']);

                $criteria = $hint;
                if (! isset($criteria['providers']) && ! isset($criteria['domains']) && ! isset($criteria['surface_ids'])) {
                    $providers = [];
                    $domains = [];
                    foreach (array_slice($capabilityCandidates, 0, 8) as $candidate) {
                        $provider = strtolower(trim((string) ($candidate['provider'] ?? '')));
                        $domain = strtolower(trim((string) ($candidate['domain'] ?? '')));
                        if ($provider !== '') $providers[] = $provider;
                        if ($domain !== '') $domains[] = $domain;
                    }
                    if ($providers !== []) $criteria['providers'] = array_values(array_unique($providers));
                    if ($domains !== []) $criteria['domains'] = array_values(array_unique($domains));
                }
                $criteria['limit'] = max(1, min(100, (int) ($criteria['limit'] ?? 60)));

                try {
                    $businessContextPlan = $this->businessContextGateway->plan(
                        $request->companyId,
                        $actorId,
                        $purpose,
                        $criteria,
                    );
                } catch (\Throwable $e) {
                    $businessContextPlanReason = 'context_plan_failed:'.mb_substr($e->getMessage(), 0, 180);
                }
            }
        }

        $node = new ZeroIntentNode(
            nodeId: $nodeId,
            intent: $request->message === '' ? 'help' : ($recognized ? $intent : 'unknown'),
            confidence: $confidence,
            source: (string) ($classified['classifier'] ?? 'workforce-baseline-v1'),
            alternatives: is_array($classified['alternatives'] ?? null) ? $classified['alternatives'] : [],
            entities: is_array($classified['entities'] ?? null) ? $classified['entities'] : [],
            parameters: is_array($classified['parameters'] ?? null) ? $classified['parameters'] : [],
            requiresClarification: ! $recognized && $request->message !== '',
            metadata: [
                'baseline_intent' => $intent,
                'matched_by' => $classified['matched_by'] ?? null,
                'semantic_classification_complete' => false,
                'multi_intent_decomposition_complete' => $this->multiIntent !== null,
                'capability_candidates' => $capabilityCandidates,
                'capability_discovery_complete' => $capabilityDiscoveryComplete,
                'capability_discovery_safety' => is_array($discovery['safety'] ?? null) ? $discovery['safety'] : [],
                'business_context_plan' => $businessContextPlan,
                'business_context_plan_reason' => $businessContextPlanReason,
                'business_context_auto_reads' => 0,
                'conversation_context' => $conversationContext?->toArray(),
            ],
        );

        $graph = $this->multiIntent !== null && $request->message !== ''
            ? $this->multiIntent->decompose($request->message, $request->traceId)
            : new ZeroIntentGraph(
                graphId: 'graph:'.substr(hash('sha256', $request->conversationId.'|'.$request->traceId), 0, 24),
                nodes: [$node],
            );

        $status = $recognized || $request->message === ''
            ? ZeroIntentResolutionStatus::RESOLVED
            : ZeroIntentResolutionStatus::CLARIFICATION_REQUIRED;

        return new ZeroIntentResolution(
            request: $request,
            graph: $graph,
            status: $status,
            clarifyingQuestions: $status === ZeroIntentResolutionStatus::CLARIFICATION_REQUIRED
                ? ['What would you like Zero to do with this business request?']
                : [],
            warnings: ['Pass 4 context mode: capability ranking and business-context planning are advisory/read-only; automatic provider reads, parameter validation, governance, and execution remain intentionally disabled.'],
            capabilityDiscoveryComplete: $capabilityDiscoveryComplete,
            metadata: [
                'resolver' => 'zero-intent-resolution-v1',
                'baseline_classifier' => $classified['classifier'] ?? 'workforce-baseline-v1',
                'conversation_history_received' => count($request->history),
                'context_hints_received' => count($request->contextHints),
                'authority_context_received' => count($request->authorityContext),
                'semantic_capability_catalogue_available' => $this->semanticCatalogue !== null,
                'semantic_capability_count' => $this->semanticCatalogue !== null
                    ? (int) ($this->semanticCatalogue->coverage()['capabilities'] ?? 0)
                    : 0,
                'capability_discovery_available' => $this->capabilityDiscovery !== null,
                'capability_discovery_engine' => $this->capabilityDiscovery !== null ? 'zero-capability-discovery-v1' : null,
                'capability_candidates_returned' => count($capabilityCandidates),
                'business_context_gateway_available' => $this->businessContextGateway !== null,
                'business_context_plan_available' => is_array($businessContextPlan),
                'business_context_plan_reason' => $businessContextPlanReason,
                'business_context_sources' => is_array($businessContextPlan) ? (int) ($businessContextPlan['source_count'] ?? 0) : 0,
                'business_context_routable_sources' => is_array($businessContextPlan) ? (int) ($businessContextPlan['routable_source_count'] ?? 0) : 0,
                'business_context_auto_reads' => 0,
                'conversation_context' => $conversationContext?->toArray(),
                'conversation_context_loaded' => $conversationContext !== null,
                'conversation_context_persisted' => $conversationContextPersisted,
            ],
        );
    }

    /** @param array<string,mixed> $payload @return array<string,mixed> */
    public function resolveArray(array $payload): array
    {
        return $this->resolve(ZeroIntentRequest::fromArray($payload))->toArray();
    }
}
