<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;
use InvalidArgumentException;

/**
 * Explainable, read-only safe-degradation projection for one AI employee.
 * Live availability and canonical fallback candidates are diagnostics only;
 * neither can create, inherit, widen or bypass execution authority.
 */
final class WorkforceSafeDegradationService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function __construct(private readonly WorkforceCapabilityAvailabilityService $availability) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId, WorkforceMember $member): array
    {
        if ((int) $member->company_id !== $companyId) {
            throw new InvalidArgumentException('Employee is outside the active company boundary.');
        }

        $member->loadMissing(['division','team','manager']);
        $live = $this->availability->forMember($member);
        $bindings = collect((array) ($live['provider_bindings'] ?? []));
        $surfaces = $this->surfaceRows($bindings);
        $unavailable = $surfaces->filter(fn (array $row): bool => $row['state'] !== 'available')->values();
        $available = $surfaces->where('state', 'available')->values();
        $fallbacks = $this->fallbackRows($surfaces, $unavailable);
        $affectedWork = $this->affectedWork($companyId, $member, $unavailable);
        $state = (string) ($live['state'] ?? 'unavailable');

        return [
            'company_id' => $companyId,
            'member' => $member,
            'raw_state' => $state,
            'status' => $this->displayStatus($state),
            'what_is_unavailable' => $unavailable->all(),
            'what_still_works' => $available->all(),
            'affected_work' => $affectedWork->all(),
            'fallbacks' => $fallbacks,
            'admin_actions' => $this->adminActions($unavailable),
            'summary' => [
                'unavailable_count' => $unavailable->count(),
                'available_count' => $available->count(),
                'affected_work_count' => $affectedWork->count(),
                'fallback_count' => count($fallbacks),
            ],
            'role_identity_immutable' => true,
            'fallback_authority_granted' => false,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array{key:string,label:string,icon:string,tone:string} */
    public function displayStatus(string $state): array
    {
        return match ($state) {
            'available' => ['key'=>'healthy','label'=>'Healthy','icon'=>'🟢','tone'=>'success'],
            'blocked' => ['key'=>'blocked','label'=>'Blocked','icon'=>'🔴','tone'=>'danger'],
            'missing_provider' => ['key'=>'missing_provider','label'=>'Missing Provider','icon'=>'⚪','tone'=>'secondary'],
            'policy_disabled' => ['key'=>'policy_disabled','label'=>'Policy Disabled','icon'=>'🔒','tone'=>'secondary'],
            default => ['key'=>'degraded','label'=>'Degraded','icon'=>'🟡','tone'=>'warning'],
        };
    }

    /** @param Collection<int,array<string,mixed>> $bindings @return Collection<int,array<string,mixed>> */
    private function surfaceRows(Collection $bindings): Collection
    {
        return $bindings->flatMap(function (array $binding): array {
            $provider = (string) ($binding['provider'] ?? '');
            $rows = [];
            foreach (['capabilities','tools','commands','signals','data_sources','workflows'] as $type) {
                foreach ((array) data_get($binding, 'surfaces.'.$type, []) as $surface) {
                    if (! is_array($surface)) continue;
                    $id = trim((string) ($surface['id'] ?? ''));
                    if ($id === '') continue;
                    $rows[] = [
                        'type' => $type,
                        'id' => $id,
                        'provider' => $provider,
                        'state' => (string) ($surface['state'] ?? 'unavailable'),
                        'reason' => $this->reason((string) ($surface['state'] ?? 'unavailable'), $provider, $id),
                    ];
                }
            }
            return $rows;
        })->values();
    }

    /** @param Collection<int,array<string,mixed>> $all @param Collection<int,array<string,mixed>> $unavailable @return list<array<string,mixed>> */
    private function fallbackRows(Collection $all, Collection $unavailable): array
    {
        return $unavailable->map(function (array $row) use ($all): array {
            $alternatives = $all->filter(fn (array $candidate): bool =>
                $candidate['type'] === $row['type'] && $candidate['id'] === $row['id'] &&
                $candidate['provider'] !== $row['provider'] && $candidate['state'] === 'available'
            )->pluck('provider')->unique()->values()->all();
            $eligible = $alternatives !== [];
            return [
                'surface_type' => $row['type'],
                'surface_id' => $row['id'],
                'failed_provider' => $row['provider'],
                'approved_fallback_available' => $eligible,
                'candidate_providers' => $alternatives,
                'usable_now' => false,
                'why' => $eligible
                    ? 'A canonically bound alternative is live, but it is not automatically authorized; normal task-scoped Risk, Assurance, Governance and Autonomy checks still apply.'
                    : 'No canonically bound live provider supplies this exact surface, so Workforce will not invent or substitute a provider.',
                'fallback_authority_granted' => false,
                'authority_inherited' => false,
            ];
        })->values()->all();
    }

    /** @param Collection<int,array<string,mixed>> $unavailable @return Collection<int,WorkforceTask> */
    private function affectedWork(int $companyId, WorkforceMember $member, Collection $unavailable): Collection
    {
        $capabilities = $unavailable->where('type', 'capabilities')->pluck('id')->unique()->values()->all();
        $providers = $unavailable->pluck('provider')->filter()->unique()->values()->all();
        return WorkforceTask::query()->forCompany($companyId)
            ->where('assignee_member_id', $member->id)
            ->whereNotIn('status', self::TERMINAL)
            ->latest('last_activity_at')->limit(200)->get()
            ->filter(function (WorkforceTask $task) use ($capabilities, $providers): bool {
                $required = array_values(array_unique(array_filter(array_merge(
                    [(string) ($task->capability ?? '')],
                    array_map('strval', (array) data_get($task->metadata ?? [], 'required_capabilities', [])),
                    array_map('strval', (array) data_get($task->payload ?? [], 'required_capabilities', []))
                ))));
                $selectedProvider = trim((string) data_get($task->metadata ?? [], 'selected_provider', data_get($task->payload ?? [], 'selected_provider', '')));
                return array_intersect($required, $capabilities) !== [] || ($selectedProvider !== '' && in_array($selectedProvider, $providers, true));
            })->values();
    }

    /** @param Collection<int,array<string,mixed>> $unavailable @return list<string> */
    private function adminActions(Collection $unavailable): array
    {
        $actions = [];
        foreach ($unavailable->groupBy('state') as $state => $rows) {
            $providers = $rows->pluck('provider')->filter()->unique()->implode(', ');
            $actions[] = match ((string) $state) {
                'missing_provider' => 'Install or activate the required provider'.($providers !== '' ? ': '.$providers : '').'.',
                'policy_disabled' => 'Review company/member capability policy and re-enable only if business policy allows it.',
                'blocked' => 'Inspect provider manifest/quarantine/integrity health and repair the invalid contribution before retrying work.',
                'degraded' => 'Restore the provider surfaces required by this role or upgrade the provider to a compatible version.',
                default => 'Restore the required provider surface; Workforce will remain safely degraded until it is live.',
            };
        }
        return array_values(array_unique($actions));
    }

    private function reason(string $state, string $provider, string $id): string
    {
        return match ($state) {
            'missing_provider' => "Provider {$provider} is not installed or active for {$id}.",
            'policy_disabled' => "Company/member policy disables {$id} from {$provider}.",
            'blocked' => "Provider {$provider} is present but its contribution cannot be trusted for {$id}.",
            'degraded' => "Provider {$provider} supplies only part of the required surface for {$id}.",
            default => "Required surface {$id} is not currently available from {$provider}.",
        };
    }
}
