<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services;

use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilityDiscoveryContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroCapabilitySimilarityScorerContract;
use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroSemanticCapabilityCatalogueContract;

/**
 * Ranked, non-mutating discovery over the complete semantic capability catalogue.
 *
 * Filtering is explicit and fail-closed. Discovery never treats semantic similarity,
 * provider presence, role hints or authority labels as permission to execute.
 */
final class ZeroCapabilityDiscoveryService implements ZeroCapabilityDiscoveryContract
{
    public function __construct(
        private readonly ZeroSemanticCapabilityCatalogueContract $catalogue,
        private readonly ZeroCapabilitySimilarityScorerContract $scorer,
    ) {}

    /** @param array<string,mixed> $context @return array<string,mixed> */
    public function discover(string $query, array $context = []): array
    {
        $query = trim($query);
        $limit = max(1, min(50, (int) ($context['limit'] ?? 10)));
        $threshold = max(0.0, min(1.0, (float) ($context['threshold'] ?? 0.10)));

        if ($query === '') {
            return $this->result($query, '', [], $context, $limit, $threshold, false, 0);
        }

        $candidates = [];
        $considered = 0;
        $normalizedQuery = '';
        foreach ($this->catalogue->capabilities() as $capability) {
            if (! $this->passesFilters($capability, $context)) continue;
            $considered++;
            $scored = $this->scorer->score($query, $capability, $context);
            $normalizedQuery = (string) ($scored['normalized_query'] ?? $normalizedQuery);
            $baseScore = (float) ($scored['score'] ?? 0.0);
            $reranked = $this->contextRerank($capability, $context);
            $score = min(1.0, max(0.0, $baseScore + $reranked['boost']));
            if ($score < $threshold) continue;

            $signals = array_values(array_unique(array_merge(
                is_array($scored['matched_signals'] ?? null) ? $scored['matched_signals'] : [],
                $reranked['signals'],
            )));

            $candidates[] = [
                'id' => (string) ($capability['id'] ?? ''),
                'provider' => (string) ($capability['provider'] ?? ''),
                'provider_version' => (string) ($capability['provider_version'] ?? ''),
                'domain' => (string) ($capability['domain'] ?? ''),
                'title' => (string) ($capability['title'] ?? ''),
                'mode' => (string) ($capability['mode'] ?? ''),
                'authority' => (string) ($capability['authority'] ?? ''),
                'score' => round($score, 6),
                'confidence' => $this->confidence($score),
                'matched_signals' => $signals,
                'semantic_metadata_authoritative' => false,
                'provider_availability_confirmed' => $this->providerAvailabilityConfirmed($capability, $context),
                'parameter_schema_status' => (string) ($capability['parameters']['schema_status'] ?? 'unknown'),
                'execution_authority_granted' => false,
            ];
        }

        usort($candidates, static function (array $a, array $b): int {
            $score = ((float) ($b['score'] ?? 0.0)) <=> ((float) ($a['score'] ?? 0.0));
            if ($score !== 0) return $score;
            return [(string) ($a['id'] ?? ''), (string) ($a['provider'] ?? '')]
                <=> [(string) ($b['id'] ?? ''), (string) ($b['provider'] ?? '')];
        });
        $candidates = array_slice($candidates, 0, $limit);

        return $this->result($query, $normalizedQuery, $candidates, $context, $limit, $threshold, $candidates !== [], $considered);
    }

    /** @param array<string,mixed> $capability @param array<string,mixed> $context */
    private function passesFilters(array $capability, array $context): bool
    {
        $provider = strtolower(trim((string) ($capability['provider'] ?? '')));
        $domain = strtolower(trim((string) ($capability['domain'] ?? '')));
        $mode = strtolower(trim((string) ($capability['mode'] ?? '')));
        $authority = strtolower(trim((string) ($capability['authority'] ?? '')));
        $id = trim((string) ($capability['id'] ?? ''));

        if (! $this->allowed($provider, $context, 'providers')) return false;
        if ($this->blocked($provider, $context, 'exclude_providers')) return false;
        if (! $this->allowed($domain, $context, 'domains')) return false;
        if ($this->blocked($domain, $context, 'exclude_domains')) return false;
        if (! $this->allowed($mode, $context, 'modes')) return false;
        if (! $this->allowed($authority, $context, 'authorities')) return false;
        if (($context['authoritative_only'] ?? false) === true && $authority !== 'authoritative') return false;
        if (! $this->allowed($id, $context, 'capability_ids', false)) return false;
        if ($this->blocked($id, $context, 'exclude_capability_ids', false)) return false;

        if (array_key_exists('available_capability_ids', $context)) {
            $allowed = $this->normaliseList((array) $context['available_capability_ids'], false);
            if (! in_array($id, $allowed, true)) return false;
        }
        if (array_key_exists('available_provider_keys', $context)) {
            $availableProviders = $this->normaliseList((array) $context['available_provider_keys']);
            if (! in_array($provider, $availableProviders, true)) return false;
        }

        return true;
    }

    /** @param array<string,mixed> $capability @param array<string,mixed> $context @return array{boost:float,signals:list<string>} */
    private function contextRerank(array $capability, array $context): array
    {
        $boost = 0.0;
        $signals = [];
        $checks = [
            ['preferred_capability_ids', (string) ($capability['id'] ?? ''), 0.08, false, 'preferred_capability'],
            ['preferred_providers', (string) ($capability['provider'] ?? ''), 0.04, true, 'preferred_provider'],
            ['preferred_domains', (string) ($capability['domain'] ?? ''), 0.03, true, 'preferred_domain'],
            ['preferred_modes', (string) ($capability['mode'] ?? ''), 0.02, true, 'preferred_mode'],
        ];
        foreach ($checks as [$key, $value, $weight, $lower, $signal]) {
            if (! array_key_exists($key, $context)) continue;
            $list = $this->normaliseList((array) $context[$key], (bool) $lower);
            $needle = (bool) $lower ? strtolower(trim($value)) : trim($value);
            if ($needle !== '' && in_array($needle, $list, true)) {
                $boost += (float) $weight;
                $signals[] = (string) $signal;
            }
        }
        return ['boost' => min(0.15, $boost), 'signals' => $signals];
    }

    /** @param array<string,mixed> $capability @param array<string,mixed> $context */
    private function providerAvailabilityConfirmed(array $capability, array $context): bool
    {
        if (! array_key_exists('available_provider_keys', $context) || ! array_key_exists('available_capability_ids', $context)) return false;
        $provider = strtolower(trim((string) ($capability['provider'] ?? '')));
        $id = trim((string) ($capability['id'] ?? ''));
        return in_array($provider, $this->normaliseList((array) $context['available_provider_keys']), true)
            && in_array($id, $this->normaliseList((array) $context['available_capability_ids'], false), true);
    }

    /** @param array<string,mixed> $context */
    private function allowed(string $value, array $context, string $key, bool $lower = true): bool
    {
        if (! array_key_exists($key, $context)) return true;
        $list = $this->normaliseList((array) $context[$key], $lower);
        $needle = $lower ? strtolower(trim($value)) : trim($value);
        return $list !== [] && in_array($needle, $list, true);
    }

    /** @param array<string,mixed> $context */
    private function blocked(string $value, array $context, string $key, bool $lower = true): bool
    {
        if (! array_key_exists($key, $context)) return false;
        $needle = $lower ? strtolower(trim($value)) : trim($value);
        return in_array($needle, $this->normaliseList((array) $context[$key], $lower), true);
    }

    /** @param array<mixed> $values @return list<string> */
    private function normaliseList(array $values, bool $lower = true): array
    {
        $out = [];
        foreach ($values as $value) {
            $value = trim((string) $value);
            if ($value === '') continue;
            $out[] = $lower ? strtolower($value) : $value;
        }
        $out = array_values(array_unique($out));
        sort($out);
        return $out;
    }

    private function confidence(float $score): string
    {
        return match (true) {
            $score >= 0.75 => 'high',
            $score >= 0.50 => 'medium',
            $score >= 0.25 => 'low',
            default => 'weak',
        };
    }

    /** @param list<array<string,mixed>> $candidates @param array<string,mixed> $context @return array<string,mixed> */
    private function result(string $query, string $normalizedQuery, array $candidates, array $context, int $limit, float $threshold, bool $complete, int $considered): array
    {
        return [
            'schema' => 'titan.zero.capability-discovery.v1',
            'query' => $query,
            'normalized_query' => $normalizedQuery,
            'complete' => $complete,
            'candidate_count' => count($candidates),
            'catalogue_capabilities' => (int) ($this->catalogue->coverage()['capabilities'] ?? count($this->catalogue->capabilities())),
            'considered_after_filters' => $considered,
            'limit' => $limit,
            'threshold' => $threshold,
            'filters' => $this->filterSummary($context),
            'candidates' => $candidates,
            'safety' => [
                'discovery_is_advisory' => true,
                'semantic_metadata_authoritative' => false,
                'discovery_grants_authority' => false,
                'discovery_executes_commands' => false,
                'provider_availability_assumed' => false,
                'parameter_completeness_assumed' => false,
                'fresh_governance_required_before_execution' => true,
            ],
            'scoring' => [
                'engine' => 'deterministic-semantic-ranking-v1',
                'neural_embeddings_active' => false,
                'embedding_scorer_pluggable' => true,
            ],
        ];
    }

    /** @param array<string,mixed> $context @return array<string,mixed> */
    private function filterSummary(array $context): array
    {
        $keys = [
            'providers','exclude_providers','domains','exclude_domains','modes','authorities','authoritative_only',
            'capability_ids','exclude_capability_ids','available_capability_ids','available_provider_keys',
            'preferred_capability_ids','preferred_providers','preferred_domains','preferred_modes',
        ];
        $out = [];
        foreach ($keys as $key) if (array_key_exists($key, $context)) $out[$key] = $context[$key];
        return $out;
    }
}
