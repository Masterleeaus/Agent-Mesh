<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainPolicy extends Model
{
    protected $table='ext_titan_ai_workforce_chain_policies';
    protected $guarded=[];
    protected $casts=[
        'revision'=>'integer','enabled'=>'boolean','mandatory_three_checks'=>'boolean',
        'minimum_reviewer_quality'=>'integer','high_risk_reviewer_quality'=>'integer',
        'critical_risk_reviewer_quality'=>'integer','require_provider_diversity_high_risk'=>'boolean',
        'require_assurance_high_risk'=>'boolean','require_model_council_critical'=>'boolean',
        'require_knowledge_authority'=>'boolean','require_explicit_evidence_high_risk'=>'boolean',
        'require_manual_extreme_risk'=>'boolean','allow_learned_policy'=>'boolean',
        'allow_predictive_tightening'=>'boolean','allow_admin_force_approve'=>'boolean',
        'federation_paths'=>'array','recovery_policy'=>'array','escalation_policy'=>'array',
        'metadata'=>'array','policy_updated_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
