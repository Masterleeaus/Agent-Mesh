<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncil;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncilMembership;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDelegation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRoleResponsibility;
use InvalidArgumentException;

/**
 * Fail-closed validator for Titan's organisational authority graph.
 *
 * Relationships describe coordination only; they never create execution authority.
 * This validator detects ambiguity before work is routed or delegated.
 */
final class WorkforceAuthorityGraphValidator
{
    public const SAFE_DEPTH = 128;

    /** @return array{valid:bool,violations:list<array<string,mixed>>,counts:array<string,int>} */
    public function validateCompany(int $companyId): array
    {
        if ($companyId <= 0) throw new InvalidArgumentException('Authority graph validation requires a valid company_id.');

        $violations = [];
        $members = WorkforceMember::query()->forCompany($companyId)->get()->keyBy(fn (WorkforceMember $m): int => (int) $m->id);

        $this->validateReportingGraph($members->all(), $violations);
        $this->validateSubstitutionGraph($companyId, $members->all(), $violations);
        $this->validateDelegations($companyId, $members->all(), $violations);
        $this->validateResponsibilityOwnership($companyId, $violations);
        $this->validateCouncilChairs($companyId, $violations);

        $unique = [];
        foreach ($violations as $violation) {
            $unique[json_encode($violation, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)] = $violation;
        }
        $violations = array_values($unique);

        return [
            'valid' => $violations === [],
            'violations' => $violations,
            'counts' => [
                'members' => count($members),
                'active_delegations' => WorkforceDelegation::query()->forCompany($companyId)->where('status', 'ACTIVE')->count(),
                'active_council_memberships' => WorkforceCouncilMembership::query()->forCompany($companyId)->where('is_active', true)->count(),
                'violations' => count($violations),
            ],
        ];
    }

    public function assertCompany(int $companyId): void
    {
        $result = $this->validateCompany($companyId);
        if ($result['valid']) return;
        $first = $result['violations'][0] ?? ['code' => 'AUTHORITY_GRAPH_INVALID'];
        throw new InvalidArgumentException('AUTHORITY_GRAPH_INVALID: '.($first['code'] ?? 'UNKNOWN'));
    }

    public function assertDelegationAcyclic(int $companyId, int $fromMemberId, int $toMemberId): void
    {
        if ($fromMemberId <= 0 || $toMemberId <= 0 || $fromMemberId === $toMemberId) {
            throw new InvalidArgumentException('DELEGATION_CYCLE: invalid delegation endpoints.');
        }

        $edges = WorkforceDelegation::query()->forCompany($companyId)
            ->where('status', 'ACTIVE')
            ->get(['from_member_id','to_member_id','expires_at'])
            ->filter(fn (WorkforceDelegation $d): bool => $d->expires_at === null || $d->expires_at->isFuture())
            ->map(fn (WorkforceDelegation $d): array => [(int) $d->from_member_id, (int) $d->to_member_id])
            ->all();
        $edges[] = [$fromMemberId, $toMemberId];

        if ($this->wouldReach($edges, $toMemberId, $fromMemberId)) {
            throw new InvalidArgumentException('DELEGATION_CYCLE: delegation would create a circular authority path.');
        }
    }

    public function assertSubstitutionAcyclic(int $companyId, int $deputyId, int $managerId): void
    {
        $edges = WorkforceRelationship::query()->forCompany($companyId)
            ->where('relationship_type', WorkforceRelationshipType::SubstitutesFor->value)
            ->where('is_active', true)
            ->get(['source_member_id','target_member_id','metadata'])
            ->filter(function (WorkforceRelationship $r): bool {
                $expires = (array) ($r->metadata ?? []);
                $value = $expires['expires_at'] ?? null;
                return !is_string($value) || $value === '' || now()->lessThan($value);
            })
            ->map(fn (WorkforceRelationship $r): array => [(int) $r->source_member_id, (int) $r->target_member_id])
            ->all();
        $edges[] = [$deputyId, $managerId];

        if ($this->wouldReach($edges, $managerId, $deputyId)) {
            throw new InvalidArgumentException('SUBSTITUTION_CYCLE: deputy coverage would create a circular continuity path.');
        }
    }

    /** @param array<int,WorkforceMember> $members @param list<array<string,mixed>> $violations */
    private function validateReportingGraph(array $members, array &$violations): void
    {
        foreach ($members as $start) {
            $seen = [];
            $cursor = $start;
            for ($depth = 0; $depth < self::SAFE_DEPTH; $depth++) {
                $id = (int) $cursor->id;
                if (isset($seen[$id])) {
                    $violations[] = ['code' => 'REPORTING_CYCLE', 'member_id' => (int) $start->id];
                    break;
                }
                $seen[$id] = true;
                $managerId = (int) ($cursor->manager_id ?? 0);
                if ($managerId <= 0) break;
                if (! isset($members[$managerId])) {
                    $violations[] = ['code' => 'ORPHAN_MANAGER', 'member_id' => $id, 'manager_id' => $managerId];
                    break;
                }
                $cursor = $members[$managerId];
            }
        }
    }

    /** @param array<int,WorkforceMember> $members @param list<array<string,mixed>> $violations */
    private function validateSubstitutionGraph(int $companyId, array $members, array &$violations): void
    {
        $rels = WorkforceRelationship::query()->forCompany($companyId)
            ->where('relationship_type', WorkforceRelationshipType::SubstitutesFor->value)
            ->where('is_active', true)->get();
        $edges = [];
        foreach ($rels as $r) {
            $source = (int) $r->source_member_id;
            $target = (int) $r->target_member_id;
            $meta = (array) ($r->metadata ?? []);
            if (!isset($members[$source]) || !isset($members[$target])) {
                $violations[] = ['code' => 'ORPHAN_SUBSTITUTION_ENDPOINT', 'relationship_id' => (int) $r->id];
                continue;
            }
            if (($meta['authority_inherited'] ?? false) !== false) {
                $violations[] = ['code' => 'SUBSTITUTION_AUTHORITY_INHERITANCE_FORBIDDEN', 'relationship_id' => (int) $r->id];
            }
            $expiresAt = $meta['expires_at'] ?? null;
            if (!is_string($expiresAt) || trim($expiresAt) === '') {
                $violations[] = ['code' => 'SUBSTITUTION_EXPIRY_REQUIRED', 'relationship_id' => (int) $r->id];
            } elseif (now()->greaterThan($expiresAt)) {
                $violations[] = ['code' => 'EXPIRED_SUBSTITUTION_ACTIVE', 'relationship_id' => (int) $r->id];
                continue;
            }
            $edges[] = [$source, $target];
        }
        if ($this->hasCycle($edges)) $violations[] = ['code' => 'SUBSTITUTION_CYCLE'];
    }

    /** @param array<int,WorkforceMember> $members @param list<array<string,mixed>> $violations */
    private function validateDelegations(int $companyId, array $members, array &$violations): void
    {
        $delegations = WorkforceDelegation::query()->forCompany($companyId)->where('status', 'ACTIVE')->get();
        $edges = [];
        foreach ($delegations as $d) {
            $from = (int) $d->from_member_id;
            $to = (int) $d->to_member_id;
            if (!isset($members[$from]) || !isset($members[$to])) {
                $violations[] = ['code' => 'ORPHAN_DELEGATION_ENDPOINT', 'delegation_id' => (int) $d->id];
                continue;
            }
            if ($d->expires_at !== null && $d->expires_at->isPast()) {
                $violations[] = ['code' => 'EXPIRED_DELEGATION_ACTIVE', 'delegation_id' => (int) $d->id];
                continue;
            }
            $scope = (array) ($d->authority_scope ?? []);
            if (($scope['authority_inherited'] ?? false) !== false || ($scope['delegator_may_expand_authority'] ?? false) !== false) {
                $violations[] = ['code' => 'DELEGATION_AUTHORITY_EXPANSION_FORBIDDEN', 'delegation_id' => (int) $d->id];
            }
            $edges[] = [$from, $to];
        }
        if ($this->hasCycle($edges)) $violations[] = ['code' => 'DELEGATION_CYCLE'];
    }

    /** @param list<array<string,mixed>> $violations */
    private function validateResponsibilityOwnership(int $companyId, array &$violations): void
    {
        $rows = WorkforceRoleResponsibility::query()->visibleToCompany($companyId)->get();
        $owners = [];
        foreach ($rows as $row) {
            if (strtoupper((string) ($row->assignment_type ?? '')) !== 'PRIMARY') continue;
            $key = (string) ($row->responsibility_id ?? '');
            if ($key === '') continue;
            $owners[$key][] = (string) ($row->role_definition_id ?? '');
        }
        foreach ($owners as $responsibility => $roles) {
            $roles = array_values(array_unique(array_filter($roles)));
            if (count($roles) > 1) {
                $violations[] = ['code' => 'MULTIPLE_PRIMARY_RESPONSIBILITY_OWNERS', 'responsibility' => $responsibility, 'roles' => $roles];
            }
        }
    }

    /** @param list<array<string,mixed>> $violations */
    private function validateCouncilChairs(int $companyId, array &$violations): void
    {
        $chairs = WorkforceCouncilMembership::query()->forCompany($companyId)
            ->where('is_active', true)->where('participation_type', 'CHAIR')->get()->groupBy('council_id');
        $councils = WorkforceCouncil::query()->forCompany($companyId)->where('is_active', true)->get(['id']);
        foreach ($councils as $council) {
            $count = $chairs->get((int) $council->id, collect())->count();
            if ($count !== 1) {
                $violations[] = ['code' => 'COUNCIL_CHAIR_AMBIGUOUS', 'council_id' => (int) $council->id, 'chair_count' => $count];
            }
        }
    }

    /** @param list<array{0:int,1:int}> $edges */
    private function hasCycle(array $edges): bool
    {
        $nodes = [];
        foreach ($edges as [$a,$b]) { $nodes[$a] = true; $nodes[$b] = true; }
        foreach (array_keys($nodes) as $node) if ($this->wouldReach($edges, $node, $node, true)) return true;
        return false;
    }

    /** @param list<array{0:int,1:int}> $edges */
    private function wouldReach(array $edges, int $start, int $target, bool $requireEdge = false): bool
    {
        $adj = [];
        foreach ($edges as [$a,$b]) $adj[$a][] = $b;
        $stack = [[$start, 0]];
        $seen = [];
        while ($stack !== []) {
            [$node,$depth] = array_pop($stack);
            if ($depth > self::SAFE_DEPTH) return true;
            if ($node === $target && (!$requireEdge || $depth > 0)) return true;
            $key = $node.':'.$depth;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            foreach ($adj[$node] ?? [] as $next) $stack[] = [$next, $depth + 1];
        }
        return false;
    }
}
