<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceTeamDefinition extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_team_definitions';
    protected $guarded = [];
    protected $casts = [
        'boundaries' => 'array',
        'role_definition_ids' => 'array',
        'applicability' => 'array',
        'activation_rules' => 'array',
        'metadata' => 'array',
    ];

    public function teams(): HasMany
    {
        return $this->hasMany(WorkforceTeam::class, 'team_definition_id', 'team_definition_id');
    }
}
