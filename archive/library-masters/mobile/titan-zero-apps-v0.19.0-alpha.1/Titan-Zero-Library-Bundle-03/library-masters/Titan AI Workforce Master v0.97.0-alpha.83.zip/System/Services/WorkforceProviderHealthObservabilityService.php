<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProviderHealthEvent;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCanonicalCapabilityMatrix;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Carbon;
use RuntimeException;

final class WorkforceProviderHealthObservabilityService
{
    public function __construct(
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly WorkforceCanonicalCapabilityMatrix $matrix,
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforceProviderContractReconciliationService $reconciliation,
    ) {}

    /** @return array<string,mixed> */
    public function providerSnapshot(string $providerKey, ?int $companyId = null): array
    {
        $key = $this->ecosystem->canonicalProviderKey($providerKey);
        $provider = $this->ecosystem->provider($key);
        if (! is_array($provider)) throw new RuntimeException("Unknown provider {$providerKey}.");

        $providerClass = trim((string) ($provider['extension']['provider_class'] ?? ''));
        $installed = $providerClass !== '' && class_exists($providerClass);
        $reconciled = $this->reconciliation->provider($key);
        $roles = $this->rolesForProvider($key);
        $latest = $companyId && $companyId > 0 ? $this->latestEvent($companyId, $key) : null;

        $state = $installed ? WorkforceCapabilityState::Available->value : WorkforceCapabilityState::MissingProvider->value;
        $reason = $installed ? 'PROVIDER_INSTALLED' : 'PROVIDER_CLASS_NOT_INSTALLED';
        if ($latest && in_array((string) $latest->state, [
            WorkforceCapabilityState::Degraded->value,
            WorkforceCapabilityState::Unavailable->value,
            WorkforceCapabilityState::Blocked->value,
            WorkforceCapabilityState::PolicyDisabled->value,
        ], true)) {
            $state = (string) $latest->state;
            $reason = (string) ($latest->reason ?: 'RECENT_RUNTIME_HEALTH_EVENT');
        }

        return [
            'provider' => $key,
            'provider_version' => (string) ($provider['extension']['version'] ?? ''),
            'provider_class' => $providerClass,
            'installed' => $installed,
            'state' => $state,
            'reason' => $reason,
            'impacted_roles' => $roles,
            'impacted_role_count' => count($roles),
            'context_adapter_status' => (string) ($reconciled['context_adapter_status'] ?? 'unknown'),
            'surface_counts' => $reconciled['surface_counts'] ?? [],
            'last_event' => $latest ? $this->eventEnvelope($latest) : null,
            'last_success_at' => $companyId ? $this->lastObservedAt($companyId, $key, 'success') : null,
            'last_failure_at' => $companyId ? $this->lastObservedAt($companyId, $key, 'failure') : null,
            'recovery_guidance' => $this->guidance($state, $reason, $key),
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function roleSnapshot(string|WorkforceMember $roleOrMember, array $policy = []): array
    {
        $role = $roleOrMember instanceof WorkforceMember
            ? (string) $roleOrMember->role_definition_id
            : trim((string) $roleOrMember);
        $companyId = $roleOrMember instanceof WorkforceMember ? (int) $roleOrMember->company_id : null;
        $live = $roleOrMember instanceof WorkforceMember
            ? $this->availability->forMember($roleOrMember, $policy)
            : $this->availability->forRole($role, $policy);

        $providers = [];
        foreach ((array) ($live['provider_bindings'] ?? []) as $binding) {
            $key = (string) ($binding['provider'] ?? '');
            if ($key === '') continue;
            $providers[] = array_merge(
                $this->providerSnapshot($key, $companyId),
                [
                    'binding_state' => (string) ($binding['state'] ?? WorkforceCapabilityState::Unavailable->value),
                    'surface_states' => $binding['surfaces'] ?? [],
                ]
            );
        }

        $unavailable = array_values(array_filter($providers, static fn (array $p): bool =>
            ($p['binding_state'] ?? null) !== WorkforceCapabilityState::Available->value
        ));

        return [
            'company_id' => $companyId,
            'role_definition_id' => $role,
            'state' => (string) ($live['state'] ?? WorkforceCapabilityState::Unavailable->value),
            'provider_count' => count($providers),
            'problem_provider_count' => count($unavailable),
            'providers' => $providers,
            'effective_access' => $live['effective_access'] ?? [],
            'explanation' => $unavailable === []
                ? 'All provider bindings required by this role are currently available.'
                : count($unavailable).' provider binding(s) are degraded, unavailable, blocked, disabled or missing.',
            'role_identity_immutable' => true,
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function responsibilitySnapshot(
        string|WorkforceMember $roleOrMember,
        string $responsibilityId,
        array $policy = [],
    ): array {
        $requirement = $this->requirements->forResponsibility(trim($responsibilityId));
        if (! is_array($requirement)) throw new RuntimeException('Unknown canonical responsibility.');
        $role = $roleOrMember instanceof WorkforceMember
            ? (string) $roleOrMember->role_definition_id
            : trim((string) $roleOrMember);
        if ($role !== (string) ($requirement['role_definition_id'] ?? '')) {
            throw new RuntimeException('Responsibility does not belong to the requested Workforce role.');
        }

        $roleHealth = $this->roleSnapshot($roleOrMember, $policy);
        $requiredCapabilities = (array) ($requirement['candidate_capabilities'] ?? []);
        $capabilities = [];
        foreach ($requiredCapabilities as $capability) {
            $capabilities[] = $this->availability->capabilityState($roleOrMember, (string) $capability, $policy);
        }
        $available = array_filter($capabilities, static fn (array $c): bool =>
            ($c['state'] ?? null) === WorkforceCapabilityState::Available->value
        );
        $state = $capabilities !== [] && count($available) === count($capabilities)
            ? WorkforceCapabilityState::Available->value
            : (count($available) > 0 ? WorkforceCapabilityState::Degraded->value : WorkforceCapabilityState::Unavailable->value);

        return [
            'company_id' => $roleHealth['company_id'] ?? null,
            'role_definition_id' => $role,
            'responsibility_id' => $responsibilityId,
            'state' => $state,
            'required_capability_count' => count($capabilities),
            'available_capability_count' => count($available),
            'capabilities' => $capabilities,
            'provider_health' => $roleHealth['providers'],
            'explanation' => $state === WorkforceCapabilityState::Available->value
                ? 'All candidate capabilities required by this responsibility are live.'
                : ($state === WorkforceCapabilityState::Degraded->value
                    ? 'Some responsibility capabilities are live; execution may be partially degraded.'
                    : 'No complete live capability path is currently available for this responsibility.'),
            'recovery_guidance' => $this->responsibilityGuidance($capabilities),
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
        ];
    }

    public function recordSuccess(
        int $companyId,
        string $providerKey,
        ?string $surfaceType = null,
        ?string $surfaceId = null,
        array $details = [],
    ): WorkforceProviderHealthEvent {
        return $this->record($companyId, $providerKey, WorkforceCapabilityState::Available->value, 'success',
            'EXECUTION_SUCCEEDED', null, $surfaceType, $surfaceId, $details);
    }

    public function recordFailure(
        int $companyId,
        string $providerKey,
        string $state,
        string $reason,
        ?string $message = null,
        ?string $surfaceType = null,
        ?string $surfaceId = null,
        array $details = [],
    ): WorkforceProviderHealthEvent {
        if (! in_array($state, [
            WorkforceCapabilityState::Degraded->value,
            WorkforceCapabilityState::Unavailable->value,
            WorkforceCapabilityState::Blocked->value,
            WorkforceCapabilityState::MissingProvider->value,
            WorkforceCapabilityState::PolicyDisabled->value,
        ], true)) {
            throw new RuntimeException('Provider health failure requires a non-available Workforce capability state.');
        }
        return $this->record($companyId, $providerKey, $state, 'failure', $reason, $message, $surfaceType, $surfaceId, $details);
    }

    private function record(
        int $companyId,
        string $providerKey,
        string $state,
        string $eventType,
        string $reason,
        ?string $message,
        ?string $surfaceType,
        ?string $surfaceId,
        array $details,
    ): WorkforceProviderHealthEvent {
        if ($companyId <= 0) throw new RuntimeException('Provider health events require company_id.');
        $key = $this->ecosystem->canonicalProviderKey($providerKey);
        $provider = $this->ecosystem->provider($key);
        if (! is_array($provider)) throw new RuntimeException('Provider health event references unknown provider.');

        return WorkforceProviderHealthEvent::query()->create([
            'company_id' => $companyId,
            'provider' => $key,
            'provider_version' => (string) ($provider['extension']['version'] ?? ''),
            'surface_type' => $surfaceType,
            'surface_id' => $surfaceId,
            'state' => $state,
            'event_type' => $eventType,
            'reason' => $reason,
            'message' => $message,
            'details' => $details,
            'observed_at' => now(),
            'recovered_at' => $eventType === 'success' ? now() : null,
        ]);
    }

    private function latestEvent(int $companyId, string $provider): ?WorkforceProviderHealthEvent
    {
        return WorkforceProviderHealthEvent::query()->forCompany($companyId)
            ->where('provider', $provider)->orderByDesc('observed_at')->orderByDesc('id')->first();
    }

    private function lastObservedAt(int $companyId, string $provider, string $eventType): ?string
    {
        $event = WorkforceProviderHealthEvent::query()->forCompany($companyId)
            ->where('provider', $provider)->where('event_type', $eventType)
            ->orderByDesc('observed_at')->orderByDesc('id')->first();
        return $event?->observed_at?->toIso8601String();
    }

    /** @return list<string> */
    private function rolesForProvider(string $provider): array
    {
        $roles = [];
        foreach ($this->matrix->roles() as $role) {
            foreach ((array) ($role['provider_bindings'] ?? []) as $binding) {
                if ((string) ($binding['provider'] ?? '') === $provider) {
                    $roles[] = (string) ($role['role_definition_id'] ?? '');
                    break;
                }
            }
        }
        $roles = array_values(array_unique(array_filter($roles)));
        sort($roles);
        return $roles;
    }

    /** @return array<string,mixed> */
    private function eventEnvelope(WorkforceProviderHealthEvent $event): array
    {
        return [
            'state' => (string) $event->state,
            'event_type' => (string) $event->event_type,
            'reason' => $event->reason,
            'message' => $event->message,
            'surface_type' => $event->surface_type,
            'surface_id' => $event->surface_id,
            'observed_at' => $event->observed_at?->toIso8601String(),
            'details' => $event->details ?? [],
        ];
    }

    /** @return list<string> */
    private function guidance(string $state, string $reason, string $provider): array
    {
        return match ($state) {
            WorkforceCapabilityState::MissingProvider->value => [
                "Install or enable {$provider}.",
                'Verify the installed provider version matches the Workforce registry.',
                'Do not substitute another provider unless a deterministic provider route is explicitly configured.',
            ],
            WorkforceCapabilityState::PolicyDisabled->value => [
                'Review the company/member capability policy.',
                'Only re-enable the provider when policy and role authority permit it.',
            ],
            WorkforceCapabilityState::Blocked->value => [
                'Inspect provider contribution/manifest integrity and governance blocks.',
                'Resolve the blocking contract or policy issue before retrying.',
            ],
            WorkforceCapabilityState::Degraded->value => [
                'Inspect the most recent provider failure and unavailable surfaces.',
                'Continue only through capabilities still reported AVAILABLE.',
                'Do not elevate authority to compensate for degraded functionality.',
            ],
            WorkforceCapabilityState::Unavailable->value => [
                'Check provider health, dependencies, version compatibility and published surfaces.',
                'Pause dependent Work Items or route only through an explicitly equivalent provider.',
            ],
            default => ['Provider is available; continue to apply normal governance and provider/version pinning.'],
        };
    }

    /** @param list<array<string,mixed>> $capabilities @return list<string> */
    private function responsibilityGuidance(array $capabilities): array
    {
        $reasons = [];
        foreach ($capabilities as $capability) {
            if (($capability['state'] ?? null) === WorkforceCapabilityState::Available->value) continue;
            $reasons[] = (string) ($capability['reason'] ?? ($capability['state'] ?? 'unavailable'));
        }
        $reasons = array_values(array_unique(array_filter($reasons)));
        if ($reasons === []) return ['Responsibility capability path is healthy.'];
        return [
            'Inspect unavailable capability/provider states: '.implode(', ', $reasons).'.',
            'Pause or escalate blocked Work Items rather than broadening employee authority.',
            'Retry after provider health or policy state recovers.',
        ];
    }
}
