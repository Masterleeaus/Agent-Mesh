<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceOutcome extends Model
{
    protected $table = 'ext_titan_ai_workforce_outcomes';
    protected $guarded = [];
    protected $casts = ['success' => 'boolean', 'summary' => 'array', 'evidence_refs' => 'array', 'observed_at' => 'datetime', 'verified_at' => 'datetime'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
