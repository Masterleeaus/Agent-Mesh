<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Navigation;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Registers request-local Titan navigation and self-heals the MagicAI menus table when available.
 *
 * Structural fields owned by the extension (key, route, label, parent_id, etc.) may be repaired.
 * Administrator-controlled order and enabled/disabled state are preserved on existing rows.
 */
final class HostNavigationRegistrar
{
    private const OWNER = 'titan-ai-workforce';
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function __construct(private readonly Application $app) {}

    /** Backward-compatible entry point retained for hosts/callers from earlier Workforce builds. */
    public function register(): void
    {
        $this->registerContributions();
        $this->syncHostMenu();
    }

    /** Register request-local structural navigation against known Titan host registry signatures. */
    public function registerContributions(): bool
    {
        $items = WorkforceNavigation::user();

        if ($this->registerWith(self::USER_REGISTRY, [
            [$items],
            [self::OWNER, $items],
            ['navigation.user', self::OWNER, $items],
        ])) {
            return true;
        }

        return $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.user', self::OWNER, $items],
            ['navigation.user', $items],
            [$items],
        ]);
    }

    /**
     * Synchronise the parent + child hierarchy into MagicAI's menus table when available.
     * Existing administrator order and enabled/disabled state are deliberately preserved.
     *
     * @return array{available:bool,changed:bool,regenerated:bool,reason:?string,parent_id:?int}
     */
    public function syncHostMenu(bool $forceRegenerate = false): array
    {
        if (! Schema::hasTable('menus')) {
            return $this->result(false, false, false, 'menus_table_unavailable');
        }

        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (! isset($columns['key'])) {
                return $this->result(false, false, false, 'menus_key_column_unavailable');
            }
            if (! isset($columns['id']) || ! isset($columns['parent_id'])) {
                return $this->result(false, false, false, 'menus_hierarchy_columns_unavailable');
            }

            $definitions = WorkforceNavigation::user();
            $parent = null;
            $children = [];
            foreach ($definitions as $definition) {
                if (($definition['parent_key'] ?? null) === null) {
                    $parent ??= $definition;
                } else {
                    $children[] = $definition;
                }
            }
            if (! is_array($parent) || (string) ($parent['key'] ?? '') === '') {
                return $this->result(false, false, false, 'parent_definition_missing');
            }

            $changed = $this->upsertDefinition($parent, $columns, null);
            $parentKey = (string) $parent['key'];
            $parentId = DB::table('menus')->where('key', $parentKey)->orderBy('id')->value('id');
            if ($parentId === null) {
                return $this->result(false, $changed, false, 'parent_row_unresolved');
            }
            $parentId = (int) $parentId;

            usort($children, static fn (array $a, array $b): int => ((int) ($a['order'] ?? 0)) <=> ((int) ($b['order'] ?? 0)));
            foreach ($children as $definition) {
                if (($definition['parent_key'] ?? null) !== $parentKey) {
                    Log::warning('Titan AI Workforce ignored navigation child with unexpected parent.', [
                        'key' => $definition['key'] ?? null,
                        'parent_key' => $definition['parent_key'] ?? null,
                    ]);
                    continue;
                }
                $changed = $this->upsertDefinition($definition, $columns, $parentId) || $changed;
            }

            $regenerated = false;
            if ($changed || $forceRegenerate) {
                $regenerated = $this->regenerateMenuCache();
            }

            return $this->result(true, $changed, $regenerated, null, $parentId);
        } catch (Throwable $e) {
            Log::warning('Titan AI Workforce host menu self-heal failed.', ['error' => $e->getMessage()]);
            return $this->result(false, false, false, 'menu_sync_failed');
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsertDefinition(array $definition, array $columns, ?int $parentId): bool
    {
        $key = (string) ($definition['key'] ?? '');
        if ($key === '') return false;

        $matches = DB::table('menus')->where('key', $key)->orderBy('id')->get();
        $existing = $matches->first();
        if ($matches->count() > 1) {
            Log::warning('Titan AI Workforce detected duplicate host menu keys; preserving rows and repairing only the canonical first row.', [
                'key' => $key,
                'count' => $matches->count(),
            ]);
        }
        $query = $existing !== null
            ? DB::table('menus')->where('id', (int) ($existing->id ?? 0))
            : DB::table('menus')->where('key', $key);
        $now = now();

        $payload = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $definition['icon'] ?? 'tabler-folders',
            'svg' => $definition['svg'] ?? null,
            'params' => json_encode($definition['params'] ?? [], JSON_UNESCAPED_SLASHES),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            // Operational navigation is permission-governed, not a MagicAI plan/feature menu flag.
            'extension' => null,
            'order' => (int) ($definition['order'] ?? 100),
            'is_active' => (bool) ($definition['is_active'] ?? true) ? 1 : 0,
            'updated_at' => $now,
        ];
        $payload = array_intersect_key($payload, $columns);

        if ($existing !== null) {
            // Preserve administrator order and enabled/disabled state while repairing vendor-owned structure.
            unset($payload['order']);
            unset($payload['is_active']);

            $changed = false;
            foreach ($payload as $column => $value) {
                if ($column === 'updated_at') continue;
                $current = $existing->{$column} ?? null;
                if ($this->normaliseComparable($current) !== $this->normaliseComparable($value)) {
                    $changed = true;
                    break;
                }
            }
            if (! $changed) return false;
            $query->update($payload);
            return true;
        }

        $insert = array_merge([
            'key' => $key,
            'created_at' => $now,
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ], $payload);
        $insert = array_intersect_key($insert, $columns);
        DB::table('menus')->insert($insert);
        return true;
    }

    /** @param list<array<int,mixed>> $argumentSets */
    private function registerWith(string $class, array $argumentSets): bool
    {
        if (! class_exists($class)) return false;

        try {
            $registry = $this->app->make($class);
        } catch (Throwable) {
            return false;
        }

        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) continue;
            foreach ($argumentSets as $arguments) {
                try {
                    $registry->{$method}(...$arguments);
                    return true;
                } catch (Throwable) {
                    // Try the next known host signature. Registry contribution is compatibility-only.
                }
            }
        }

        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class = self::MENU_SERVICE;
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) return false;

        try {
            $this->app->make($class)->regenerate();
            return true;
        } catch (Throwable) {
            try {
                $class::regenerate();
                return true;
            } catch (Throwable) {
                return false;
            }
        }
    }

    private function normaliseComparable(mixed $value): string
    {
        if ($value === null) return '';
        if (is_bool($value)) return $value ? '1' : '0';
        return (string) $value;
    }

    /** @return array{available:bool,changed:bool,regenerated:bool,reason:?string,parent_id:?int} */
    private function result(bool $available, bool $changed, bool $regenerated, ?string $reason, ?int $parentId = null): array
    {
        return [
            'available' => $available,
            'changed' => $changed,
            'regenerated' => $regenerated,
            'reason' => $reason,
            'parent_id' => $parentId,
        ];
    }
}
