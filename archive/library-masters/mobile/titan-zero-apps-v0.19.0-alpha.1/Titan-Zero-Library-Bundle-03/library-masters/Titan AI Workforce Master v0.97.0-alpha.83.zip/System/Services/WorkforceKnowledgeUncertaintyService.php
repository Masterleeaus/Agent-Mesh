<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use RuntimeException;

/**
 * Workforce-side uncertainty recorder. Knowledge Authority remains the knowledge source of truth.
 * This service records uncertainty against the originating canonical Work Item and can emit a
 * governed task event without granting execution authority.
 */
final class WorkforceKnowledgeUncertaintyService
{
    private const TYPES = [
        'missing-authority','stale-authority','conflicting-authority','low-confidence','missing-context',
        'jurisdiction-uncertain','applicability-uncertain','preflight-unresolved','evidence-insufficient',
        'reviewer-disagreement',
    ];

    public function __construct(private readonly WorkforceTaskService $tasks) {}

    /** @return array<string,mixed> */
    public function report(WorkforceTask $task, ?WorkforceMember $actor, array $input): array
    {
        if (! $task->work_item_uuid) throw new RuntimeException('Knowledge uncertainty requires a canonical Work Item.');
        $type = strtolower(trim((string) ($input['uncertainty_type'] ?? 'missing-context')));
        if (! in_array($type, self::TYPES, true)) $type = 'missing-context';

        $privacy = strtolower(trim((string) ($input['privacy_classification'] ?? 'company_private')));
        if (! in_array($privacy, ['public_reusable','company_private','sensitive_restricted'], true)) {
            $privacy = 'company_private';
        }
        $publicReusable = (bool) ($input['public_reusable'] ?? false);
        if ($privacy !== 'public_reusable') $publicReusable = false;

        $record = [
            'uncertainty_type' => $type,
            'domain' => (string) ($input['domain'] ?? 'general'),
            'workflow_key' => $input['workflow_key'] ?? null,
            'jurisdiction' => $input['jurisdiction'] ?? null,
            'topic' => (string) ($input['topic'] ?? 'Knowledge uncertainty'),
            'reason' => (string) ($input['reason'] ?? ''),
            'confidence' => max(0, min(100, (int) ($input['confidence'] ?? 0))),
            'risk_class' => strtolower((string) ($input['risk_class'] ?? 'ordinary')),
            'privacy_classification' => $privacy,
            'public_reusable' => $publicReusable,
            'status' => 'OPEN',
            'reported_at' => now()->toIso8601String(),
            'company_id' => (int) $task->company_id,
            'task_id' => (int) $task->id,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];

        $metadata = is_array($task->metadata ?? null) ? $task->metadata : [];
        $items = array_values((array) ($metadata['knowledge_uncertainties'] ?? []));
        $items[] = $record;
        $metadata['knowledge_uncertainties'] = array_slice($items, -50);
        $task->forceFill(['metadata' => $metadata])->save();

        $this->tasks->record(
            $task,
            $actor,
            'work_item.knowledge_uncertainty_reported',
            $task->status->value,
            $task->status->value,
            $record['reason'] ?: null,
            $record,
        );

        return $record;
    }
}
