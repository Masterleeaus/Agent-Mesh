<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use InvalidArgumentException;

/** Converts Agent trigger signals into persistent Workforce-owned tasks. */
final class AgentTriggerSignalIngressService
{
    public const SCHEMA = 'titan.agent-trigger/1';
    public const EVENT_TYPE = 'agent.runtime.trigger.requested';

    public function __construct(private readonly WorkforceTaskService $tasks) {}

    /** @return array<string,mixed> */
    public function receive(array $envelope): array
    {
        $payload = $this->payload($envelope);
        $companyId = (int) ($payload['company_id'] ?? 0);
        $triggerId = trim((string) ($payload['trigger_id'] ?? ''));
        $triggerType = trim((string) ($payload['trigger_type'] ?? ''));
        $workflowId = (int) ($payload['workflow_id'] ?? 0);

        if (($payload['schema'] ?? null) !== self::SCHEMA) throw new InvalidArgumentException('Agent trigger signal schema is invalid.');
        if ($companyId <= 0 || $triggerId === '' || $workflowId <= 0) throw new InvalidArgumentException('Agent trigger signal identity is incomplete.');
        if (! in_array($triggerType, ['schedule', 'webhook', 'delayed'], true)) throw new InvalidArgumentException('Agent trigger type is not migrated to Workforce.');
        if (($payload['requires_workforce'] ?? null) !== true) throw new InvalidArgumentException('Agent trigger must require Workforce authority.');
        if (($payload['execution_claimed'] ?? false) === true || ($payload['business_outcome_claimed'] ?? false) === true) {
            throw new InvalidArgumentException('Agent trigger signal cannot claim execution or business outcome.');
        }

        $assignee = $this->resolveAssignee($companyId, $payload);
        $triggerData = is_array($payload['trigger_data'] ?? null) ? $payload['trigger_data'] : [];
        $context = is_array($payload['context'] ?? null) ? $payload['context'] : [];
        $idempotencyKey = sprintf('agent-trigger:%d:%s', $companyId, $triggerId);

        $task = $this->tasks->create($companyId, [
            'title' => sprintf('Legacy Agent %s trigger: workflow #%d', $triggerType, $workflowId),
            'description' => 'A legacy Agent business trigger was accepted by Titan Signal and converted into a Workforce-owned task. The old workflow may run only as a subordinate interaction recipe under this task.',
            'payload' => [
                'agent_trigger' => [
                    'schema' => self::SCHEMA,
                    'trigger_id' => $triggerId,
                    'trigger_type' => $triggerType,
                    'workflow_id' => $workflowId,
                    'trigger_data' => $triggerData,
                    'context' => $context,
                    'source_runtime_profile_id' => $payload['runtime_profile_id'] ?? null,
                ],
                'requires_governance' => true,
                'execution_claimed' => false,
                'business_outcome_claimed' => false,
            ],
            'assignee_member_id' => $assignee->id,
            'manager_member_id' => $assignee->manager_id,
            'division_id' => $assignee->division_id,
            'team_id' => $assignee->team_id,
            'origin_type' => 'agent_runtime_trigger',
            'origin_id' => $triggerId,
            'priority' => 50,
            'risk_level' => 'MEDIUM',
            'trace_id' => $payload['trace_id'] ?? null,
            'correlation_id' => $payload['correlation_id'] ?? $triggerId,
            'causation_id' => $payload['causation_id'] ?? null,
            'idempotency_key' => $idempotencyKey,
            'metadata' => [
                'source_extension' => 'ai-agent',
                'agent_trigger' => true,
                'workflow_id' => $workflowId,
                'trigger_id' => $triggerId,
                'trigger_type' => $triggerType,
                'source_runtime_profile_id' => $payload['runtime_profile_id'] ?? null,
                'trigger_authority' => 'titan_signal_workforce',
            ],
        ], $assignee);

        if ($task->wasRecentlyCreated) ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);

        return [
            'accepted' => true,
            'status' => $task->wasRecentlyCreated ? 'queued_for_workforce' : 'duplicate_accepted',
            'workforce_task_id' => (int) $task->id,
            'workforce_task_uuid' => (string) $task->task_uuid,
            'requires_governance' => true,
            'execution_claimed' => false,
            'business_outcome_claimed' => false,
        ];
    }

    private function payload(array $envelope): array
    {
        if (($envelope['schema'] ?? null) === self::SCHEMA) return $envelope;
        $payload = is_array($envelope['payload'] ?? null) ? $envelope['payload'] : [];
        return ($payload['schema'] ?? null) === self::SCHEMA ? $payload : $envelope;
    }

    private function resolveAssignee(int $companyId, array $payload): WorkforceMember
    {
        $memberId = (int) ($payload['workforce_member_id'] ?? 0);
        if ($memberId > 0) {
            $member = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)->find($memberId);
            if (! $member) throw new InvalidArgumentException('Agent trigger Workforce member is inactive or outside company boundary.');
            return $member;
        }
        $manager = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)
            ->where('tier', WorkforceTier::Manager->value)
            ->orderByRaw("CASE WHEN `key` = 'operations-manager' THEN 0 ELSE 1 END")->first();
        if (! $manager) throw new InvalidArgumentException('No eligible Workforce Manager is available for Agent trigger.');
        return $manager;
    }
}
