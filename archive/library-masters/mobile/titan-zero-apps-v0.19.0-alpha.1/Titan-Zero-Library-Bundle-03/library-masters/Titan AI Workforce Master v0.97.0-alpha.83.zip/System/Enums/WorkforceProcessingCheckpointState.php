<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceProcessingCheckpointState: string
{
    case Pending = 'PENDING';
    case Processing = 'PROCESSING';
    case Passed = 'PASSED';
    case Rejected = 'REJECTED';
    case NeedsInfo = 'NEEDS_INFO';
    case Disagreed = 'DISAGREED';
    case Escalated = 'ESCALATED';
    case Superseded = 'SUPERSEDED';

    public function terminal(): bool
    {
        return in_array($this, [self::Passed,self::Rejected,self::Superseded], true);
    }

    public function blocksDownstream(): bool
    {
        return $this !== self::Passed;
    }
}
