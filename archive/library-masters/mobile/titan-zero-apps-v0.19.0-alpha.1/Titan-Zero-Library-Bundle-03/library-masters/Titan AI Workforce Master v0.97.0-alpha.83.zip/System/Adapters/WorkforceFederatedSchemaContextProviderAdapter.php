<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Adapters;

use App\Extensions\TitanAIWorkforce\System\Contracts\WorkforceBusinessContextProviderContract;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Builder as SchemaBuilder;
use RuntimeException;

/**
 * Read-only compatibility adapter for extension-owned schema where the provider
 * does not yet expose a first-class Workforce read port.
 *
 * The public boundary is always company_id. Any legacy storage tenant key is
 * profile-internal and can never be supplied by callers.
 */
final class WorkforceFederatedSchemaContextProviderAdapter implements WorkforceBusinessContextProviderContract
{
    /** @param array<string,mixed> $profile */
    public function __construct(
        private readonly ConnectionInterface $db,
        private readonly SchemaBuilder $schema,
        private readonly array $profile,
    ) {}

    public function providerKey(): string
    {
        return (string) ($this->profile['provider'] ?? '');
    }

    public function providerVersion(): string
    {
        return (string) ($this->profile['provider_version'] ?? '');
    }

    public function supports(string $surfaceId): bool
    {
        return isset(($this->profile['routes'] ?? [])[$surfaceId]);
    }

    public function read(int $companyId, string $surfaceId, array $filters = [], int $limit = 50): array
    {
        if ($companyId <= 0) throw new RuntimeException('Federated context read requires company_id.');
        $route = ($this->profile['routes'] ?? [])[$surfaceId] ?? null;
        if (! is_array($route)) throw new RuntimeException('Unsupported federated context surface.');

        $table = trim((string) ($route['table'] ?? ''));
        $storageKey = trim((string) ($route['storage_company_key'] ?? ''));
        if ($table === '' || $storageKey === '') throw new RuntimeException('Federated context route is incomplete.');
        if (! $this->schema->hasTable($table)) throw new RuntimeException("Provider context table is unavailable: {$table}.");
        if (! $this->schema->hasColumn($table, $storageKey)) {
            throw new RuntimeException("Provider context table does not expose its declared company scope: {$table}.");
        }

        // Caller-controlled identity fields are forbidden. The canonical company_id
        // is translated only inside this adapter for legacy storage compatibility.
        foreach (array_keys($filters) as $key) {
            $normalised = strtolower((string) $key);
            if (in_array($normalised, ['company_id','tenant_id'], true) || str_contains($normalised, 'tenant'.'_company_id')) {
                unset($filters[$key]);
            }
        }

        $query = $this->db->table($table)->where($storageKey, $companyId);
        $allowed = array_fill_keys(array_map('strval', (array) ($route['allowed_filters'] ?? [])), true);
        foreach ($filters as $key => $value) {
            $key = (string) $key;
            if (! isset($allowed[$key]) || ! $this->schema->hasColumn($table, $key)) continue;
            if (is_array($value)) {
                $values = array_values(array_filter($value, static fn ($v): bool => is_scalar($v) || $v === null));
                if ($values !== []) $query->whereIn($key, $values);
            } elseif (is_scalar($value) || $value === null) {
                $query->where($key, $value);
            }
        }

        $orderBy = trim((string) ($route['order_by'] ?? 'id'));
        if ($orderBy !== '' && $this->schema->hasColumn($table, $orderBy)) {
            $direction = strtolower((string) ($route['order_direction'] ?? 'desc')) === 'asc' ? 'asc' : 'desc';
            $query->orderBy($orderBy, $direction);
        }

        $rows = $query->limit(max(1, min($limit, 200)))->get();
        $items = [];
        foreach ($rows as $row) {
            $item = (array) $row;
            // Never expose a legacy storage tenant key through the normalized envelope.
            foreach (array_keys($item) as $key) {
                if (str_contains(strtolower((string) $key), 'tenant'.'_company_id')) unset($item[$key]);
            }
            $items[] = $item;
        }

        return [
            'company_id' => $companyId,
            'surface_id' => $surfaceId,
            'items' => $items,
            'observed_at' => now()->toIso8601String(),
            'provenance' => [
                'provider' => $this->providerKey(),
                'provider_version' => $this->providerVersion(),
                'adapter' => 'provider-owned-schema-read-compatibility',
                'table' => $table,
            ],
        ];
    }
}
