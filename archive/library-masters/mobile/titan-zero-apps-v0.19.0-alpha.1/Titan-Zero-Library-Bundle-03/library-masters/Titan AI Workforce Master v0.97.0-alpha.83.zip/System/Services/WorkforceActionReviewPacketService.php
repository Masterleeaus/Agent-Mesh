<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceActionReviewPacket;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

final class WorkforceActionReviewPacketService
{
    public const VERSION = 1;

    public function buildForStage(
        WorkforceDecisionChain $chain,
        WorkforceTask $task,
        int $stage,
        array $request = [],
        array $reviewerRequirements = [],
    ): WorkforceActionReviewPacket {
        if ($stage < 1 || $stage > 3) {
            throw new InvalidArgumentException('ACTION_REVIEW_PACKET_UNKNOWN_STAGE');
        }

        $existing=WorkforceActionReviewPacket::query()
            ->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where('stage',$stage)
            ->first();
        if ($existing) {
            $this->verify($existing);
            return $existing;
        }

        $prior=WorkforceProcessingCheckpoint::query()
            ->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where('stage','<',$stage)
            ->orderBy('stage')
            ->get()
            ->map(static fn(WorkforceProcessingCheckpoint $checkpoint): array => [
                'stage'=>(int)$checkpoint->stage,
                'stage_key'=>(string)$checkpoint->stage_key,
                'domain_key'=>$checkpoint->domain_key,
                'reviewer_member_id'=>$checkpoint->reviewer_member_id,
                'reviewer_role'=>$checkpoint->reviewer_role,
                'status'=>(string)$checkpoint->status,
                'decision'=>$checkpoint->decision ?? [],
                'reviewed_at'=>$checkpoint->reviewed_at?->toISOString(),
            ])->values()->all();

        $packet=[
            'packet_version'=>self::VERSION,
            'company_id'=>(int)$chain->company_id,
            'decision_chain_uuid'=>(string)$chain->chain_uuid,
            'processing_id'=>(string)$chain->processing_id,
            'task_id'=>(int)$task->getKey(),
            'task_uuid'=>(string)$task->task_uuid,
            'stage'=>$stage,
            'stage_key'=>match($stage) {
                1=>'ORIGIN_REVIEW',
                2=>'DOMAIN_PROCESSING',
                3=>'RECEIVING_ACCEPTANCE',
            },
            'action_intent'=>[
                'title'=>(string)$task->title,
                'description'=>$task->description,
                'capability'=>$task->capability,
                'capability_variant'=>$task->capability_variant,
                'request'=>$request,
                'payload'=>$task->payload ?? [],
                'expected_outcome'=>$task->expected_outcome ?? [],
            ],
            'business_context'=>[
                'company_id'=>(int)$task->company_id,
                'division_id'=>$task->division_id,
                'team_id'=>$task->team_id,
                'source_extension'=>$task->source_extension,
                'vertical'=>$task->vertical,
                'workflow_ref'=>$task->workflow_ref,
                'conversation_id'=>$task->conversation_id,
                'channel_id'=>$task->channel_id,
            ],
            'domain_route'=>[
                'origin_domain'=>$chain->origin_domain,
                'processing_domain'=>$chain->processing_domain,
                'receiving_domain'=>$chain->receiving_domain,
                'current_domain'=>match($stage) {
                    1=>$chain->origin_domain,
                    2=>$chain->processing_domain,
                    3=>$chain->receiving_domain,
                },
            ],
            'knowledge_authority'=>[
                'receipt'=>$chain->knowledge_receipt ?? [],
                'required'=>(bool)($chain->consequential ?? true),
            ],
            'risk_and_control'=>[
                'risk_class'=>$chain->risk_class,
                'risk_snapshot'=>$task->risk_snapshot ?? [],
                'assurance_snapshot'=>$task->assurance_snapshot ?? [],
                'autonomy_snapshot'=>$task->autonomy_snapshot ?? [],
                'governance'=>$task->governance ?? [],
                'organisationally_approved'=>(bool)$chain->organisationally_approved,
                'authority_gates_ready'=>(bool)$chain->authority_gates_ready,
            ],
            'evidence'=>[
                'task_evidence'=>$task->evidence ?? [],
                'evidence_requirements'=>$task->evidence_requirements ?? [],
            ],
            'assumptions'=>array_values((array)($request['assumptions'] ?? data_get($task->metadata ?? [],'assumptions',[]))),
            'unresolved_questions'=>array_values((array)($request['unresolved_questions'] ?? data_get($task->metadata ?? [],'unresolved_questions',[]))),
            'prior_stage_decisions'=>$prior,
            'reviewer_requirements'=>$reviewerRequirements,
            'predictive_failure_prevention'=>[
                'risk_band'=>$reviewerRequirements['prediction_risk_band'] ?? 'NORMAL',
                'require_explicit_evidence_refs'=>(bool)($reviewerRequirements['require_explicit_evidence_refs'] ?? false),
                'require_knowledge_authority_receipt'=>(bool)($reviewerRequirements['require_knowledge_authority_receipt'] ?? true),
                'require_assumptions_declaration'=>(bool)($reviewerRequirements['require_assumptions_declaration'] ?? false),
                'require_unresolved_questions_declaration'=>(bool)($reviewerRequirements['require_unresolved_questions_declaration'] ?? false),
                'mandatory_three_checks'=>true,
            ],
            'provenance'=>[
                'originator_member_id'=>$chain->originator_member_id,
                'role_owner_extension'=>$task->role_owner_extension,
                'role_owner_extension_version'=>$task->role_owner_extension_version,
                'role_definition_id'=>$task->role_definition_id,
                'role_definition_version'=>$task->role_definition_version,
                'role_definition_sha256'=>$task->role_definition_sha256,
                'trace_id'=>(string)$task->trace_id,
                'correlation_id'=>(string)$task->correlation_id,
                'causation_id'=>(string)$task->causation_id,
                'decision_chain_contract'=>$chain->contract_snapshot ?? [],
                'request_fingerprint'=>data_get($chain->metadata ?? [],'request_fingerprint'),
            ],
        ];

        $canonical=$this->canonicalize($packet);
        $json=json_encode($canonical,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $sha=hash('sha256',$json);

        return WorkforceActionReviewPacket::query()->create([
            'company_id'=>(int)$chain->company_id,
            'decision_chain_id'=>$chain->getKey(),
            'task_id'=>$task->getKey(),
            'processing_id'=>$chain->processing_id,
            'stage'=>$stage,
            'stage_key'=>$canonical['stage_key'],
            'packet_version'=>self::VERSION,
            'packet_sha256'=>$sha,
            'packet'=>$canonical,
            'sealed_at'=>now(),
        ]);
    }

    public function verify(WorkforceActionReviewPacket $packet): void
    {
        if (!is_array($packet->packet) || $packet->packet===[] || !is_string($packet->packet_sha256) || $packet->packet_sha256==='') {
            throw new InvalidArgumentException('ACTION_REVIEW_PACKET_MISSING');
        }
        $canonical=$this->canonicalize($packet->packet);
        $json=json_encode($canonical,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        $actual=hash('sha256',$json);
        if (!hash_equals((string)$packet->packet_sha256,$actual)) {
            throw new InvalidArgumentException('ACTION_REVIEW_PACKET_INTEGRITY_FAILED');
        }
    }

    /** @return array<string,mixed> */
    public function payloadForReviewer(WorkforceActionReviewPacket $packet): array
    {
        $this->verify($packet);
        return [
            'packet_version'=>$packet->packet_version,
            'packet_sha256'=>$packet->packet_sha256,
            'sealed_at'=>$packet->sealed_at?->toISOString(),
            'packet'=>$packet->packet,
        ];
    }

    public function canonicalize(array $value): array
    {
        foreach($value as $key=>$item) {
            if (is_array($item)) {
                $value[$key]=array_is_list($item)
                    ? array_map(fn($row)=>is_array($row)?$this->canonicalize($row):$row,$item)
                    : $this->canonicalize($item);
            }
        }
        if (!array_is_list($value)) ksort($value,SORT_STRING);
        return $value;
    }
}
