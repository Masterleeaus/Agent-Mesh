<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\ProactiveResponsibilityService;
use Illuminate\Console\Command;

class SyncWorkforceResponsibilitiesCommand extends Command
{
    protected $signature = 'titan-workforce:sync-responsibilities {--limit=1000}';
    protected $description = 'Synchronize data-driven proactive responsibilities for active Workforce members.';

    public function handle(ProactiveResponsibilityService $service): int
    {
        $count = $service->syncAll((int) $this->option('limit'));
        $this->info("Synchronized proactive responsibilities for {$count} Workforce member(s).");
        return self::SUCCESS;
    }
}
