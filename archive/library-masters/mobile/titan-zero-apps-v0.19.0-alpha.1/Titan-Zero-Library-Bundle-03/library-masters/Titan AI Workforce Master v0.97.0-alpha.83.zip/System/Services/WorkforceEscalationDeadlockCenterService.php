<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskDependency;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use Illuminate\Support\Collection;

/**
 * Read-only operational projection of escalations and deadlocks.
 * It never grants capability or execution authority; actions remain in the
 * governed ChainOfCommand/Task services.
 */
final class WorkforceEscalationDeadlockCenterService
{
    private const BUSINESS_MANAGER_ROLE = 'titan.executive.business_manager';
    private const TITAN_ZERO_ROLE = 'titan.system.titan_zero';

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->where(function ($query): void {
                $query->whereIn('status', ['BLOCKED','ESCALATED','REVISION_REQUIRED','AWAITING_DATA','RECOVERY'])
                    ->orWhereHas('history', fn ($history) => $history->where('event', 'like', 'deadlock.%'));
            })
            ->with(['assignee:id,company_id,name,role,role_definition_id,manager_id,division_id,team_id', 'manager:id,company_id,name,role,role_definition_id,manager_id,division_id,team_id'])
            ->latest('updated_at')->limit(250)->get();

        $openEscalations = WorkforceEscalation::query()->forCompany($companyId)
            ->where('status', 'OPEN')->latest('created_at')->get()->groupBy('task_id');

        $rows = $tasks->map(fn (WorkforceTask $task): array => $this->caseRow($companyId, $task, $openEscalations->get($task->id, collect())))->values()->all();

        return [
            'rows' => $rows,
            'tree' => $this->tree($companyId),
            'counts' => [
                'open' => count($rows),
                'escalated' => collect($rows)->where('state', 'ESCALATED')->count(),
                'deadlocked' => collect($rows)->filter(fn (array $row): bool => $row['is_deadlock'])->count(),
                'human_required' => collect($rows)->filter(fn (array $row): bool => $row['human_required'])->count(),
            ],
            'authority_boundary' => [
                'authority_inherited' => false,
                'execution_authority_granted' => false,
                'note' => 'Escalation changes who must decide; it never grants executable capability or bypasses Risk, Assurance, Governance or Autonomy.',
            ],
        ];
    }

    /** @param Collection<int,WorkforceEscalation> $escalations @return array<string,mixed> */
    private function caseRow(int $companyId, WorkforceTask $task, Collection $escalations): array
    {
        $history = WorkforceTaskHistory::query()->where('task_id', $task->id)->latest('created_at')->limit(80)->get();
        $deadlockHistory = $history->filter(fn ($row): bool => str_starts_with((string) $row->event, 'deadlock.') || str_contains((string) $row->event, 'escalat'));
        $latestEscalation = $escalations->first();
        $evidence = WorkforceEvidence::query()->forCompany($companyId)->where('task_id', $task->id)->latest('created_at')->limit(25)->get();

        $blockedDownstream = WorkforceTaskDependency::query()->forCompany($companyId)
            ->where('depends_on_task_id', $task->id)->where('blocking', true)
            ->pluck('task_id')->map(fn ($id): int => (int) $id)->all();
        $downstreamTasks = $blockedDownstream === [] ? collect() : WorkforceTask::query()->forCompany($companyId)->whereIn('id', $blockedDownstream)->get(['id','task_uuid','title','status']);

        $resolver = $this->requiredResolver($companyId, $task, $latestEscalation);
        $state = (string) ($task->status?->value ?? $task->status);
        $created = $latestEscalation?->created_at ?? $deadlockHistory->last()?->created_at ?? $task->updated_at ?? $task->created_at;
        $humanRequired = $deadlockHistory->contains(fn ($row): bool => (string) $row->event === 'deadlock.human_required')
            || (string) data_get($latestEscalation?->metadata ?? [], 'resolution', '') === 'HUMAN_DECISION_REQUIRED';
        $reason = (string) ($latestEscalation?->recommended_action ?: $latestEscalation?->reason_code ?: $deadlockHistory->first()?->reason ?: data_get($task->metadata ?? [], 'blocked_reason', 'No explicit reason recorded.'));

        return [
            'task_id' => (int) $task->id,
            'task_uuid' => (string) $task->task_uuid,
            'title' => (string) $task->title,
            'state' => $state,
            'reason' => $reason,
            'age' => $created ? $created->diffForHumans() : 'Unknown',
            'age_minutes' => $created ? max(0, $created->diffInMinutes(now())) : 0,
            'evidence' => $evidence->map(fn ($item): array => [
                'type' => (string) $item->evidence_type,
                'reference' => (string) ($item->reference ?? ''),
                'observed_at' => optional($item->observed_at ?? $item->created_at)->toIso8601String(),
            ])->values()->all(),
            'previous_decisions' => $deadlockHistory->map(fn ($item): array => [
                'event' => (string) $item->event,
                'reason' => (string) ($item->reason ?? ''),
                'at' => optional($item->created_at)->toIso8601String(),
                'context' => (array) ($item->context ?? []),
            ])->values()->all(),
            'blocked_downstream_work' => $downstreamTasks->map(fn (WorkforceTask $item): array => [
                'id' => (int) $item->id,
                'title' => (string) $item->title,
                'status' => (string) ($item->status?->value ?? $item->status),
                'url' => route('dashboard.user.titan-workforce.tasks.show', $item),
            ])->values()->all(),
            'required_resolver' => $resolver,
            'owner' => $this->memberSummary($task->assignee),
            'manager' => $this->memberSummary($task->manager),
            'is_deadlock' => $deadlockHistory->isNotEmpty() || in_array($state, ['BLOCKED','REVISION_REQUIRED','AWAITING_DATA','RECOVERY'], true),
            'human_required' => $humanRequired,
            'open_escalation_ids' => $escalations->pluck('id')->map(fn ($id): int => (int) $id)->values()->all(),
            'url' => route('dashboard.user.titan-workforce.tasks.show', $task),
            'authority_boundary' => [
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ],
        ];
    }

    /** @return array<int,array<string,mixed>> */
    private function tree(int $companyId): array
    {
        $businessManager = WorkforceMember::query()->forCompany($companyId)->where('role_definition_id', self::BUSINESS_MANAGER_ROLE)->where('is_active', true)->first();
        $titanZero = WorkforceMember::query()->forCompany($companyId)->where('role_definition_id', self::TITAN_ZERO_ROLE)->where('is_active', true)->first();
        return [
            ['key'=>'specialist','label'=>'Specialist','description'=>'Work owner/maker closest to the issue.'],
            ['key'=>'manager','label'=>'Manager','description'=>'Responsible manager reviews the first escalation.'],
            ['key'=>'division_manager','label'=>'Division Manager','description'=>'Division-level resolver for unresolved or cross-team blockers.'],
            ['key'=>'business_manager','label'=>'AI Business Manager','description'=>'Executive cross-division coordination.','member'=>$this->memberSummary($businessManager)],
            ['key'=>'titan_zero','label'=>'Titan Zero','description'=>'Owner-facing coordination; never an authority bypass.','member'=>$this->memberSummary($titanZero)],
            ['key'=>'human','label'=>'Human','description'=>'Explicit human decision when policy or ambiguity requires it.'],
        ];
    }

    /** @return array<string,mixed> */
    private function requiredResolver(int $companyId, WorkforceTask $task, ?WorkforceEscalation $escalation): array
    {
        if ($escalation?->escalated_to_member_id) {
            $member = WorkforceMember::query()->forCompany($companyId)->find((int) $escalation->escalated_to_member_id);
            if ($member) return ['level'=>'assigned_escalation_owner','member'=>$this->memberSummary($member),'human'=>false];
        }
        if ($task->manager) return ['level'=>'manager','member'=>$this->memberSummary($task->manager),'human'=>false];
        $businessManager = WorkforceMember::query()->forCompany($companyId)->where('role_definition_id', self::BUSINESS_MANAGER_ROLE)->where('is_active', true)->first();
        if ($businessManager) return ['level'=>'ai_business_manager','member'=>$this->memberSummary($businessManager),'human'=>false];
        return ['level'=>'human','member'=>null,'human'=>true];
    }

    /** @return array<string,mixed>|null */
    private function memberSummary(?WorkforceMember $member): ?array
    {
        if (! $member) return null;
        return [
            'id'=>(int) $member->id,
            'name'=>(string) $member->name,
            'role'=>(string) ($member->role ?? $member->role_definition_id),
            'role_definition_id'=>(string) $member->role_definition_id,
            'url'=>route('dashboard.user.titan-workforce.staff.show', $member),
        ];
    }
}
