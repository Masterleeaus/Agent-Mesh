<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Collection;
use InvalidArgumentException;

/**
 * Read-only manager operational projection. Authority remains with the existing
 * task/chain/governance services and is never inherited from this dashboard.
 */
final class WorkforceManagerCommandCenterService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];
    private const REVIEW = ['SUBMITTED','UNDER_REVIEW','RECEIVER_REVIEW'];
    private const BLOCKED = ['BLOCKED','AWAITING_DATA','RECOVERY'];

    public function __construct(
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly QueuePriorityService $priority,
    ) {}

    public function snapshot(int $companyId, WorkforceMember $manager): array
    {
        if ((int) $manager->company_id !== $companyId) {
            throw new InvalidArgumentException('Cross-company Manager Command Center access rejected.');
        }
        if ($manager->tier !== WorkforceTier::Manager) {
            throw new InvalidArgumentException('Manager Command Center is available only to Tier 1 Workforce Managers.');
        }

        $manager->loadMissing(['division:id,key,name','team:id,key,name','manager:id,name,role']);
        $team = WorkforceMember::query()->forCompany($companyId)
            ->where('manager_id', $manager->id)
            ->where('is_active', true)
            ->with(['division:id,key,name','team:id,key,name'])
            ->orderBy('name')->get()
            ->reject(fn (WorkforceMember $member): bool => (bool) data_get($member->metadata ?? [], 'internal', false))
            ->values();

        $managed = WorkforceTask::query()->forCompany($companyId)
            ->where('manager_member_id', $manager->id)
            ->whereNotIn('status', self::TERMINAL)
            ->with(['assignee:id,name,role,status,max_concurrent_tasks','division:id,key,name','team:id,key,name'])
            ->get()
            ->each(function (WorkforceTask $task): void { $task->queue_score = $this->priority->score($task); })
            ->sortByDesc('queue_score')->values();

        $received = WorkforceTaskHandoff::query()->forCompany($companyId)
            ->where('receiving_manager_id', $manager->id)->latest('updated_at')->limit(100)->get();
        $sent = WorkforceTaskHandoff::query()->forCompany($companyId)
            ->where('origin_manager_id', $manager->id)->latest('updated_at')->limit(100)->get();
        $escalations = WorkforceEscalation::query()->forCompany($companyId)
            ->where(function ($query) use ($manager): void {
                $query->where('raised_by_member_id', $manager->id)->orWhere('escalated_to_member_id', $manager->id);
            })->latest()->limit(100)->get();

        $memberIds = collect([$manager->id])->merge($team->pluck('id'))->map(fn ($id): int => (int) $id)->unique()->values();
        $teamTaskIds = WorkforceTask::query()->forCompany($companyId)
            ->where(function ($query) use ($memberIds): void {
                $query->whereIn('assignee_member_id', $memberIds)->orWhereIn('manager_member_id', $memberIds);
            })->pluck('id');

        $outcomes = $teamTaskIds->isEmpty() ? collect() : WorkforceOutcome::query()->forCompany($companyId)
            ->whereIn('task_id', $teamTaskIds)->whereNotNull('verified_at')->latest('verified_at')->limit(100)->get();

        $schedules = WorkforceSchedule::query()->forCompany($companyId)
            ->whereIn('member_id', $memberIds)->where('is_active', true)->orderBy('next_run_at')->limit(100)->get();

        $divisionKey = (string) ($manager->division?->key ?? '');
        $staffing = WorkforceStaffingProposal::query()->forCompany($companyId)
            ->where('status', 'RECOMMENDED')
            ->when($divisionKey !== '', fn ($query) => $query->where('division_key', $divisionKey))
            ->orderByDesc('score')->latest('recommended_at')->limit(50)->get();

        $deputyCandidates = WorkforceMember::query()->forCompany($companyId)
            ->where('division_id', $manager->division_id)
            ->where('tier', WorkforceTier::Manager->value)
            ->where('is_active', true)
            ->where('id', '!=', $manager->id)
            ->orderBy('name')->get();

        $decompositionCandidates = $team->map(function (WorkforceMember $member): ?array {
            $definition = WorkforceRoleRegistry::find((string) $member->role_definition_id);
            if (! $definition || (int) ($definition['tier'] ?? 0) !== WorkforceTier::Specialist->value) return null;
            $capabilities = array_values(array_filter(array_map('strval', (array) ($definition['capabilities'] ?? []))));
            if ($capabilities === []) return null;
            return [
                'member' => $member,
                'role_key' => (string) ($definition['key'] ?? ''),
                'capabilities' => $capabilities,
            ];
        })->filter()->values();

        $availability = $team->map(function (WorkforceMember $member): array {
            $state = $this->availability->forMember($member);
            return [
                'member' => $member,
                'workforce_status' => (string) ($member->status?->value ?? $member->status),
                'capability_state' => (string) ($state['state'] ?? 'unavailable'),
                'providers' => array_values((array) data_get($state, 'effective_access.providers', [])),
                'authority_inherited' => false,
            ];
        })->values();

        $workload = $this->workload($companyId, $team);
        $queueHealth = $this->queueHealth->forManager($manager);
        $review = $managed->filter(fn (WorkforceTask $task): bool => in_array($this->taskStatus($task), self::REVIEW, true))->values();
        $blocked = $managed->filter(fn (WorkforceTask $task): bool => in_array($this->taskStatus($task), self::BLOCKED, true))->values();

        return [
            'manager' => $manager,
            'my_team' => $team,
            'work_awaiting_review' => $review,
            'escalations' => $escalations,
            'handoffs_received' => $received,
            'handoffs_sent' => $sent,
            'blocked_work' => $blocked,
            'workload_imbalance' => $workload,
            'staff_availability' => $availability,
            'staffing_recommendations' => $staffing,
            'deputy_candidates' => $deputyCandidates,
            'decomposition_candidates' => $decompositionCandidates,
            'proactive_responsibilities' => $schedules,
            'team_outcomes' => $outcomes,
            'managed_work' => $managed,
            'queue_health' => $queueHealth,
            'action_targets' => [
                'review' => $review,
                'delegate' => $managed->filter(fn (WorkforceTask $task): bool => in_array($this->taskStatus($task), ['APPROVED'], true))->values(),
                'reassign' => $managed,
                'decompose' => $managed->filter(fn (WorkforceTask $task): bool => (int) $task->assignee_member_id === (int) $manager->id)->values(),
                'escalate' => $managed->filter(fn (WorkforceTask $task): bool => ! in_array($this->taskStatus($task), ['ESCALATED', ...self::TERMINAL], true))->values(),
                'deadlock' => $managed->filter(fn (WorkforceTask $task): bool => in_array($this->taskStatus($task), ['BLOCKED','REVISION_REQUIRED','ESCALATED','RECOVERY','AWAITING_DATA'], true))->values(),
            ],
            'authority_inherited' => false,
        ];
    }

    private function workload(int $companyId, Collection $team): Collection
    {
        if ($team->isEmpty()) return collect();
        $counts = WorkforceTask::query()->forCompany($companyId)
            ->whereIn('assignee_member_id', $team->pluck('id'))
            ->whereNotIn('status', self::TERMINAL)
            ->selectRaw('assignee_member_id, COUNT(*) AS open_count')
            ->groupBy('assignee_member_id')->pluck('open_count', 'assignee_member_id');

        return $team->map(function (WorkforceMember $member) use ($counts): array {
            $open = (int) ($counts[$member->id] ?? 0);
            $capacity = max(1, (int) ($member->max_concurrent_tasks ?? 5));
            $ratio = round($open / $capacity, 3);
            return [
                'member' => $member,
                'open' => $open,
                'capacity' => $capacity,
                'load_ratio' => $ratio,
                'overloaded' => $ratio >= 1.0,
            ];
        })->sortByDesc('load_ratio')->values();
    }

    private function taskStatus(WorkforceTask $task): string
    {
        return (string) ($task->status?->value ?? $task->status);
    }
}
