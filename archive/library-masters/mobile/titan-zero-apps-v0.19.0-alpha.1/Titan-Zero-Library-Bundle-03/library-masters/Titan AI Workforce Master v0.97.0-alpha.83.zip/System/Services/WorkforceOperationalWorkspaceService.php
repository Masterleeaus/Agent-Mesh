<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforcePerformanceMetric;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use Illuminate\Support\Collection;

/**
 * Read-only company-scoped operational home for divisions and teams.
 * Queue/capability/performance projections never grant authority or mutate work.
 */
final class WorkforceOperationalWorkspaceService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function __construct(
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforceCapabilityAvailabilityService $availability,
    ) {}

    /** @return array<string,mixed> */
    public function forDivision(int $companyId, WorkforceDivision $division): array
    {
        $this->assertCompany($companyId, $division->company_id);
        $division->loadMissing(['definition','teams','members.manager']);
        return $this->snapshot($companyId, $division, null);
    }

    /** @return array<string,mixed> */
    public function forTeam(int $companyId, WorkforceTeam $team): array
    {
        $this->assertCompany($companyId, $team->company_id);
        $team->loadMissing(['definition','division.definition','members.manager']);
        if (! $team->division || (int) $team->division->company_id !== $companyId) abort(404);
        return $this->snapshot($companyId, $team->division, $team);
    }

    /** @return array<string,mixed> */
    private function snapshot(int $companyId, WorkforceDivision $division, ?WorkforceTeam $team): array
    {
        $memberQuery = WorkforceMember::query()->forCompany($companyId)->where('division_id', $division->id)->where('is_active', true);
        if ($team) $memberQuery->where('team_id', $team->id);
        $members = $memberQuery->with('manager')->orderBy('tier')->orderBy('name')->get();
        $memberIds = $members->pluck('id')->map(fn ($id) => (int) $id)->all();

        $taskQuery = WorkforceTask::query()->forCompany($companyId)->where('division_id', $division->id);
        if ($team) $taskQuery->where('team_id', $team->id);
        $tasks = $taskQuery->with(['assignee','manager'])->latest('updated_at')->limit(300)->get();
        $taskIds = $tasks->pluck('id')->map(fn ($id) => (int) $id)->all();
        $open = $tasks->filter(fn ($task) => ! in_array((string) ($task->status?->value ?? $task->status), self::TERMINAL, true))->values();
        $blocked = $open->filter(fn ($task) => in_array((string) ($task->status?->value ?? $task->status), ['BLOCKED','AWAITING_DATA','RECOVERY'], true))->values();
        $objectives = $open->filter(fn ($task) => $task->parent_task_id === null)->take(30)->values();

        $managers = $members->filter(fn (WorkforceMember $m) => $m->tier === WorkforceTier::Manager)->values();
        $manager = $team
            ? ($managers->first() ?: $members->pluck('manager')->filter()->first())
            : $managers->first();

        $responsibilities = [];
        foreach ($members as $member) {
            foreach (WorkforceResponsibilityRegistry::accountabilitiesForRole((string) $member->role_definition_id) as $item) {
                $key = (string) ($item['responsibility_id'] ?? $item['key'] ?? md5(json_encode($item)));
                $responsibilities[$key] = $item + ['owner_member_id' => $member->id, 'owner_name' => $member->name];
            }
        }

        $capability = ['available'=>0,'degraded'=>0,'blocked'=>0,'missing_provider'=>0,'policy_disabled'=>0,'unavailable'=>0,'members'=>[]];
        foreach ($members as $member) {
            $live = $this->availability->forMember($member);
            $state = (string) ($live['state'] ?? 'unavailable');
            if (! array_key_exists($state, $capability)) $capability[$state] = 0;
            $capability[$state]++;
            $capability['members'][] = ['id'=>$member->id,'name'=>$member->name,'role'=>$member->role,'state'=>$state,'providers'=>(array) data_get($live,'effective_access.providers',[])];
        }

        $schedules = $memberIds === [] ? collect() : WorkforceSchedule::query()->forCompany($companyId)->whereIn('member_id', $memberIds)->orderByDesc('is_active')->orderBy('next_run_at')->limit(100)->get();
        $handoffQuery = WorkforceTaskHandoff::query()->forCompany($companyId);
        if ($team) {
            $handoffs = $taskIds === [] ? collect() : $handoffQuery->whereIn('task_id', $taskIds)->latest('created_at')->limit(100)->get();
        } else {
            $handoffs = $handoffQuery->where(function ($q) use ($taskIds, $division): void {
                if ($taskIds !== []) $q->whereIn('task_id', $taskIds);
                $q->orWhere('receiving_division_id', $division->id);
            })->latest('created_at')->limit(100)->get();
        }
        $outcomes = $taskIds === [] ? collect() : WorkforceOutcome::query()->forCompany($companyId)->whereIn('task_id', $taskIds)->latest('observed_at')->limit(100)->get();
        $verifiedOutcomes = $outcomes->whereNotNull('verified_at')->values();

        $metricsQuery = WorkforcePerformanceMetric::query()->forCompany($companyId)->where('division_id', $division->id);
        if ($team) $metricsQuery->where('team_id', $team->id);
        $performance = $metricsQuery->orderByDesc('period_end')->limit(100)->get();

        $queue = $this->queueHealth->snapshot($companyId, (int) $division->id);
        if ($team) {
            $teamOpen = $open->count();
            $capacity = $members->filter(fn (WorkforceMember $m) => $m->tier === WorkforceTier::Specialist)->sum(fn (WorkforceMember $m) => max(1, (int) ($m->max_concurrent_tasks ?? 5)));
            $queue['queue_depth'] = $teamOpen;
            $queue['active_capacity'] = $capacity;
            $queue['load_ratio'] = $capacity > 0 ? round($teamOpen / $capacity, 3) : ($teamOpen > 0 ? 99.0 : 0.0);
            $queue['blocked_count'] = $blocked->count();
            $queue['escalated_count'] = $open->filter(fn ($task) => (string) ($task->status?->value ?? $task->status) === 'ESCALATED')->count();
            $queue['overdue_count'] = $open->filter(fn ($task) => $task->deadline_at && $task->deadline_at->isPast())->count();
            $queue['pressure'] = $this->pressure((float) $queue['load_ratio'], (int) $queue['blocked_count'], (int) $queue['overdue_count']);
        }

        return [
            'scope' => $team ? 'team' : 'division',
            'division' => $division,
            'team' => $team,
            'manager' => $manager,
            'members' => $members,
            'responsibilities' => array_values($responsibilities),
            'work' => ['queue'=>$open->take(100)->values(),'blocked'=>$blocked,'objectives'=>$objectives],
            'queue_health' => $queue,
            'handoffs' => $handoffs,
            'capability_health' => $capability,
            'schedules' => $schedules,
            'performance' => $performance,
            'outcomes' => $outcomes,
            'verified_outcomes' => $verifiedOutcomes,
            'authority_inherited' => false,
        ];
    }

    private function pressure(float $ratio, int $blocked, int $overdue): string
    {
        if ($ratio >= 1.25 || $overdue >= 3) return 'CRITICAL';
        if ($ratio >= 1.0 || $blocked >= 3 || $overdue >= 1) return 'HIGH';
        if ($ratio >= .75 || $blocked >= 1) return 'ELEVATED';
        return 'NORMAL';
    }

    private function assertCompany(int $companyId, mixed $recordCompanyId): void
    {
        if ((int) $recordCompanyId !== $companyId) abort(404);
    }
}
