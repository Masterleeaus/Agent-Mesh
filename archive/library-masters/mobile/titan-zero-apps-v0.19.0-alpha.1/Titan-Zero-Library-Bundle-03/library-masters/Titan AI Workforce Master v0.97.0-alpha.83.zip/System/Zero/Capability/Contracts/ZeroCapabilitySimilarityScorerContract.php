<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts;

interface ZeroCapabilitySimilarityScorerContract
{
    /**
     * Score one semantic capability projection against a natural-language query.
     * The scorer is descriptive only: it cannot establish authority or availability.
     *
     * @param array<string,mixed> $capability
     * @param array<string,mixed> $context
     * @return array{score:float,normalized_query:string,matched_signals:list<string>}
     */
    public function score(string $query, array $capability, array $context = []): array;
}
