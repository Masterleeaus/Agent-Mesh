<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceRecoveryPlan extends Model
{
    protected $table='ext_titan_ai_workforce_recovery_plans';
    protected $guarded=[];
    protected $casts=[
        'step_count'=>'integer','verified_step_count'=>'integer',
        'manual_intervention_required'=>'boolean','trigger_evidence'=>'array',
        'opened_at'=>'datetime','completed_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
