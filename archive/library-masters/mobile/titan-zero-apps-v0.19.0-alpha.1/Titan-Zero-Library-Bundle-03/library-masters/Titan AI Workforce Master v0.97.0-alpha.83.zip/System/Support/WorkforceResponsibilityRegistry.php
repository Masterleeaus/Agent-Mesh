<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class WorkforceResponsibilityRegistry
{
    public static function all(): array
    {
        $catalog = new IntrinsicResponsibilityCatalog();
        return [
            'ownership' => 'titan-ai-workforce',
            'definitions' => $catalog->all(),
            'assignments' => $catalog->assignments(),
            'routine_ownership' => 'contributing_extensions',
            'policy' => self::policy(),
            'workflows' => self::manifestRegistry()?->workflows() ?? [],
        ];
    }

    public static function policy(): array
    {
        $organisation = WorkforceOrganisationPolicyRegistry::all();
        return array_merge([
            'generic_specialist_review' => ['enabled' => false],
            'rebalance_limit_per_manager' => 3,
            // Pass 9 restores role accountabilities only. Scheduled/event routines remain contributed until Passes 20-21.
            'role_routines_source' => 'extension_manifest_only',
        ], is_array($organisation['proactive_policy'] ?? null) ? $organisation['proactive_policy'] : []);
    }

    /** @return list<array<string,mixed>> */
    public static function accountabilitiesForRole(string $roleKeyOrId, array $verticals = []): array
    {
        $rows = (new IntrinsicResponsibilityCatalog())->forRole($roleKeyOrId);
        if ($verticals === []) return $rows;
        return array_values(array_filter($rows, static function (array $definition) use ($verticals): bool {
            $supported = $definition['vertical_applicability'] ?? ['all'];
            return in_array('all', $supported, true) || array_intersect($verticals, $supported) !== [];
        }));
    }

    /** Compatibility API: returns proactive routines, not intrinsic accountability definitions. */
    public static function forRole(string $roleKeyOrId, array $verticals = []): array
    {
        $registry = self::manifestRegistry();
        if (! $registry) return [];
        $role = WorkforceRoleRegistry::find($roleKeyOrId);
        if (! $role) return [];
        return self::filterRoutines($registry->explicitRoutinesForRole($roleKeyOrId), $role, $verticals);
    }

    public static function forOwnedRole(string $ownerExtension, string $roleDefinitionId, array $verticals = []): array
    {
        $registry = self::manifestRegistry();
        if (! $registry) return [];
        $role = $registry->findOwnedRole($ownerExtension, $roleDefinitionId);
        if (! $role) return [];
        return self::filterRoutines($registry->explicitRoutinesForOwnedRole($ownerExtension, $roleDefinitionId), $role, $verticals);
    }

    private static function filterRoutines(array $source, array $role, array $verticals): array
    {
        $routines = [];
        foreach ($source as $routine) {
            $routineVerticals = $routine['verticals'] ?? ['all'];
            if (! in_array('all', $routineVerticals, true) && $verticals !== [] && array_intersect($routineVerticals, $verticals) === []) continue;
            $routine['role_key'] ??= (string) $role['key'];
            $routine['source'] = 'extension_workforce_manifest';
            $routines[] = $routine;
        }
        return $routines;
    }

    public static function verticalPacks(): array
    {
        return [];
    }

    private static function manifestRegistry(): ?WorkforceManifestRegistry
    {
        if (! function_exists('app')) return null;
        return app(WorkforceManifestRegistry::class);
    }
}
