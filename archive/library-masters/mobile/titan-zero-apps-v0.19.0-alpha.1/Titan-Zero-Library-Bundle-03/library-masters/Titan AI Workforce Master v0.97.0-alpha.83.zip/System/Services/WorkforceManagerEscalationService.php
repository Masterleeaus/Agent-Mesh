<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceManagerEscalationService
{
    public function resolve(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        ?WorkforceMember $raisedBy,
        string $reasonCode,
        array $context=[]
    ): WorkforceChainEscalation {
        $value=max(0,(float)($context['business_value'] ?? data_get($chain->task?->payload ?? [],'amount',0)));
        $urgency=max(0,min(100,(int)($context['urgency_score'] ?? $chain->task?->priority ?? 50)));
        $disagreements=max(0,(int)($context['disagreement_count'] ?? 0));
        $level=$this->requiredLevel((string)$chain->risk_class,$value,$urgency,$disagreements);

        $start=$raisedBy ?: ($checkpoint->owner_member_id
            ? WorkforceMember::query()->forCompany((int)$chain->company_id)->find($checkpoint->owner_member_id)
            : null);
        $path=$this->buildPath($chain,$start);
        [$target,$actingFor]=$this->selectTarget($chain,$path,$level);

        if (!$target) throw new RuntimeException('NO_AVAILABLE_MANAGER_ESCALATION_AUTHORITY');

        return WorkforceChainEscalation::query()->create([
            'escalation_uuid'=>(string)Str::uuid(),
            'company_id'=>(int)$chain->company_id,
            'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$chain->processing_id,
            'stage'=>(int)$checkpoint->stage,
            'raised_by_member_id'=>$raisedBy?->getKey(),
            'assigned_to_member_id'=>$target->getKey(),
            'acting_for_member_id'=>$actingFor,
            'level'=>$level,
            'reason_code'=>$reasonCode,
            'status'=>'OPEN',
            'business_value'=>$value ?: null,
            'urgency_score'=>$urgency,
            'disagreement_count'=>$disagreements,
            'path'=>array_map(fn(WorkforceMember $m)=>[
                'member_id'=>$m->getKey(),'role'=>$m->role,'role_definition_id'=>$m->role_definition_id,
                'division_id'=>$m->division_id,'manager_id'=>$m->manager_id,'available'=>$this->available($m),
            ],$path),
            'evidence'=>$context,
            'raised_at'=>now(),
        ]);
    }

    /** @return WorkforceMember[] */
    private function buildPath(WorkforceDecisionChain $chain,?WorkforceMember $start): array
    {
        $path=[];$seen=[];$current=$start;
        while($current && count($path)<12){
            if(isset($seen[$current->getKey()])) break;
            $seen[$current->getKey()]=true;
            if((int)$current->company_id !== (int)$chain->company_id) break;
            $path[]=$current;
            $current=$current->manager_id
                ? WorkforceMember::query()->forCompany((int)$chain->company_id)->find($current->manager_id)
                : null;
        }

        $divisionId=$start?->division_id ?? $chain->task?->division_id;
        if($divisionId){
            $divisionManagers=WorkforceMember::query()->forCompany((int)$chain->company_id)
                ->where('division_id',$divisionId)->where('tier',WorkforceTier::Manager->value)
                ->where('is_active',true)->get();
            foreach($divisionManagers as $m) if(!isset($seen[$m->getKey()])){$path[]=$m;$seen[$m->getKey()]=true;}
        }

        $executives=WorkforceMember::query()->forCompany((int)$chain->company_id)
            ->where('is_active',true)->where(function($q){
                $q->where('role_definition_id','titan.executive.business_manager')
                  ->orWhere('role_definition_id','titan.operations.chief_of_staff')
                  ->orWhere('is_permanent_system_role',true);
            })->get();
        foreach($executives as $m) if(!isset($seen[$m->getKey()])){$path[]=$m;$seen[$m->getKey()]=true;}
        return $path;
    }

    /** @param WorkforceMember[] $path @return array{0:?WorkforceMember,1:?int} */
    private function selectTarget(WorkforceDecisionChain $chain,array $path,string $level): array
    {
        foreach($path as $member){
            if(!$this->meetsLevel($member,$level)) continue;
            if($this->available($member)) return [$member,null];
            $deputy=$this->deputyFor($member,'decision-chain.escalation');
            if($deputy) return [$deputy,(int)$member->getKey()];
        }
        return [null,null];
    }

    private function requiredLevel(string $risk,float $value,int $urgency,int $disagreements): string
    {
        $risk=strtoupper($risk);
        if(in_array($risk,['CRITICAL','SEVERE','EXTREME'],true) || $value>=100000 || $disagreements>=3) return 'CHIEF';
        if(in_array($risk,['HIGH','REGULATED'],true) || $value>=25000 || $urgency>=90 || $disagreements>=2) return 'DIVISION_MANAGER';
        return 'MANAGER';
    }

    private function meetsLevel(WorkforceMember $member,string $level): bool
    {
        $role=(string)$member->role_definition_id;
        if($level==='CHIEF') return in_array($role,['titan.executive.business_manager','titan.operations.chief_of_staff'],true)
            || (bool)$member->is_permanent_system_role;
        if($level==='DIVISION_MANAGER') return (int)$member->tier===WorkforceTier::Manager->value;
        return (int)$member->tier===WorkforceTier::Manager->value || $member->manager_id===null;
    }

    private function available(WorkforceMember $member): bool
    {
        return (bool)$member->is_active
            && !in_array($member->status,[WorkforceMemberStatus::Offline,WorkforceMemberStatus::Suspended,WorkforceMemberStatus::Blocked],true);
    }

    private function deputyFor(WorkforceMember $manager,string $scope): ?WorkforceMember
    {
        $rows=WorkforceRelationship::query()->forCompany((int)$manager->company_id)
            ->where('target_member_id',$manager->getKey())
            ->where('relationship_type',WorkforceRelationshipType::SubstitutesFor->value)
            ->where('is_active',true)->get();
        foreach($rows as $rel){
            $meta=(array)($rel->metadata ?? []);
            $scopes=array_values(array_map('strval',(array)($meta['scope'] ?? [])));
            if($scopes!==[] && !in_array($scope,$scopes,true)) continue;
            if(($meta['authority_inherited'] ?? false)!==false) continue;
            $expires=$meta['expires_at'] ?? null;
            if(is_string($expires) && $expires!=='' && now()->greaterThan($expires)) continue;
            $member=WorkforceMember::query()->forCompany((int)$manager->company_id)->find($rel->source_member_id);
            if($member && $this->available($member)) return $member;
        }
        return null;
    }
}
