<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\TitanAI;

use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use App\Extensions\TitanAI\System\TitanAI\Integration\ConversationSourceAdapterContract;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceConversationService;

/**
 * Workforce uses Titan AI Core for intelligence only. It never grants direct business-write
 * authority to the runtime. Consequential outputs return to the Workforce task/governance path.
 */
final class WorkforceConversationSourceAdapter implements ConversationSourceAdapterContract
{
    public function __construct(private readonly WorkforceConversationService $conversation) {}
    public function source(): string { return 'titan-workforce'; }

    public function deployment(TitanAIRequest $request): ?array
    {
        $member = (array) ($request->payload['workforce_member'] ?? []);
        $role = (string) ($member['role'] ?? 'Titan Workforce Staff Member');
        $purpose = (string) ($member['purpose'] ?? 'Complete the assigned organisational work accurately and transparently.');
        $responsibilities = array_values(array_filter((array) ($member['responsibilities'] ?? []), 'is_string'));
        $system = "You are {$role}, a governed Titan AI Workforce staff member.\nPurpose: {$purpose}\n";
        if ($responsibilities !== []) { $system .= "Responsibilities:\n- " . implode("\n- ", $responsibilities) . "\n"; }
        $system .= "Produce structured work and evidence. Do not claim a business mutation occurred unless a Titan Command Bus receipt is present. Do not self-approve consequential work. Never fabricate evidence or authority.";

        return [
            'id' => $request->assistantDeploymentId ?: ('workforce:' . ($member['key'] ?? 'member')),
            'name' => $role,
            'system_prompt' => $system,
            'provider' => 'magicai-host',
            'model' => (string) data_get($member, 'model_preferences.preferred', ''),
            'capabilities' => ['chat','memory','knowledge','web'],
            'tool_schema_id' => 'titan-workforce',
            'web_search' => false,
        ];
    }

    public function context(TitanAIRequest $request): array
    {
        $companyId = (int) ($request->payload['company_id'] ?? 0);
        return $companyId > 0 ? $this->conversation->context($companyId) : ['authority_inherited'=>false,'execution_authority_granted'=>false];
    }

    public function complete(TitanAIRequest $request, array $runtimeContext = []): ?array
    {
        $companyId = (int) ($request->payload['company_id'] ?? 0);
        if ($companyId < 1) return ['status'=>'needs_input','content'=>'Workforce conversation requires company_id.','authority_inherited'=>false];
        $message = trim((string) ($request->payload['message'] ?? $request->payload['prompt'] ?? $request->payload['input'] ?? ''));
        $result = $this->conversation->respond($companyId, $message);
        return ['status'=>'completed','content'=>(string) ($result['message'] ?? ''),'workforce'=>$result,'authoritative_business_execution'=>false,'authority_inherited'=>false];
    }

    public function stream(TitanAIRequest $request, array $runtimeContext, callable $emit): ?array
    {
        $result = $this->complete($request, $runtimeContext);
        if (is_array($result) && isset($result['content'])) $emit((string) $result['content']);
        return $result;
    }
}
