<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Http\Middleware;

use App\Extensions\TitanAIWorkforce\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePermissions;
use Closure;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response;

final class AuthorizeWorkforceRequest
{
    public function __construct(private readonly TitanHostAuthorizationAdapter $authorization) {}

    public function handle(Request $request, Closure $next, string $permission = WorkforcePermissions::READ): Response
    {
        $user = $request->user();
        if (! is_object($user)) abort(401);

        try {
            $companyId = CompanyContext::id($user);
        } catch (InvalidArgumentException) {
            abort(403, 'Canonical Titan tenant context is required.');
        }

        if (! in_array($permission, WorkforcePermissions::all(), true)) {
            abort(403, 'Unknown Titan AI Workforce permission.');
        }
        if (! $this->authorization->allows($user, $permission, WorkforcePermissions::delegatedAdminPermissions())) {
            abort(403);
        }

        return CompanyContext::runWith($companyId, fn () => $next($request));
    }
}
