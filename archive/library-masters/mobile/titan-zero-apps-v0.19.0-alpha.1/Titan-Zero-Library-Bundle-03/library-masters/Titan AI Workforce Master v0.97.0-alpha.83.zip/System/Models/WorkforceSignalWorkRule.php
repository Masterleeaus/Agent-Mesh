<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceSignalWorkRule extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_signal_work_rules';
    protected $guarded = [];
    protected $casts = [
        'goal_template' => 'array',
        'work_item_template' => 'array',
        'conditions' => 'array',
        'is_active' => 'boolean',
        'metadata' => 'array',
    ];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
