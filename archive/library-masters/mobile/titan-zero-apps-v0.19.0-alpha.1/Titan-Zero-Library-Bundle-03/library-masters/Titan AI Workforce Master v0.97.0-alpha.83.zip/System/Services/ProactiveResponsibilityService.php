<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use Carbon\Carbon;
use DateTimeZone;

final class ProactiveResponsibilityService
{
    public function __construct(private readonly WorkforceManifestRegistry $manifests) {}

    public function syncAll(int $limit = 1000): int
    {
        $count = 0;
        $seen = 0;
        foreach (WorkforceMember::query()->staffingSeats()->where('is_active', true)->whereNotNull('role_owner_extension')->whereNull('deleted_at')->orderBy('id')->cursor() as $member) {
            if ($seen++ >= $limit) break;
            CompanyContext::runWith((int) $member->company_id, function () use ($member, &$count): void {
                if ($this->syncMember($member) > 0) $count++;
            });
        }
        return $count;
    }

    public function syncOwner(string $ownerExtension, int $limit = 1000): int
    {
        $ownerExtension = trim($ownerExtension);
        if ($ownerExtension === '') return 0;
        $count = 0;
        $seen = 0;
        foreach (WorkforceMember::query()->staffingSeats()->where('role_owner_extension', $ownerExtension)->whereNull('deleted_at')->orderBy('id')->cursor() as $member) {
            if ($seen++ >= $limit) break;
            CompanyContext::runWith((int) $member->company_id, function () use ($member, &$count): void {
                if (! $member->is_active) {
                    $this->disableMemberSources($member, 'member_inactive');
                    return;
                }
                if ($this->syncMember($member) > 0) $count++;
            });
        }
        return $count;
    }

    public function disableOwner(string $ownerExtension, string $reason = 'extension_disabled'): int
    {
        $ownerExtension = trim($ownerExtension);
        if ($ownerExtension === '') return 0;

        $memberIds = WorkforceMember::query()->staffingSeats()->where('role_owner_extension', $ownerExtension)->pluck('id')->all();
        $query = WorkforceSchedule::query()->where(function ($q) use ($ownerExtension, $memberIds): void {
            $q->where('owner_extension', $ownerExtension);
            if ($memberIds !== []) $q->orWhereIn('member_id', $memberIds);
        })->where('is_active', true);

        $count = 0;
        $query->orderBy('id')->chunkById(100, function ($schedules) use (&$count, $ownerExtension, $reason): void {
            foreach ($schedules as $schedule) {
                $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
                $metadata['source'] = 'extension_workforce_manifest';
                $metadata['owner_extension'] = $ownerExtension;
                $metadata['disabled_reason'] = $reason;
                $metadata['disabled_at'] = now()->toIso8601String();
                $schedule->forceFill(['is_active' => false, 'metadata' => $metadata])->save();
                $count++;
            }
        });
        return $count;
    }

    public function syncMember(WorkforceMember $member): int
    {
        if (! $member->is_active || (bool) data_get($member->metadata ?? [], 'internal', false)) return 0;

        $ownerExtension = trim((string) $member->role_owner_extension);
        $roleDefinitionId = trim((string) $member->role_definition_id);
        if ($ownerExtension === '' || $roleDefinitionId === '') {
            $this->disableMemberSources($member, 'missing_manifest_provenance');
            return 0;
        }

        if ((bool) data_get($member->schedule_config ?? [], 'proactive_enabled', true) === false) {
            $this->disableMemberSources($member, 'member_proactive_disabled');
            return 0;
        }

        $definition = $this->manifests->findOwnedRole($ownerExtension, $roleDefinitionId);
        if (! $definition) {
            $this->disableMemberSources($member, 'role_definition_unavailable');
            return 0;
        }

        $verticals = (array) data_get($member->metadata ?? [], 'verticals', $definition['activation']['verticals'] ?? []);
        $routines = WorkforceResponsibilityRegistry::forOwnedRole($ownerExtension, $roleDefinitionId, $verticals);
        $activeKeys = [];
        $playbooks = $member->playbooks ?? [];
        $timezone = $this->normaliseTimezone((string) data_get($member->schedule_config ?? [], 'timezone', config('app.timezone', 'UTC')));

        foreach ($routines as $routine) {
            if (($routine['creates'] ?? null) !== 'workforce_task' || ($routine['business_mutation'] ?? false) !== false) continue;

            $routineId = (string) ($routine['routine_id'] ?? $routine['key'] ?? '');
            $routineFingerprint = (string) ($routine['routine_fingerprint'] ?? '');
            if ($routineId === '' || $routineFingerprint === '') continue;

            $key = 'manifest:' . substr(hash('sha256', $ownerExtension . '|' . $routineId), 0, 40);
            $activeKeys[] = $key;
            $schedule = WorkforceSchedule::query()->firstOrNew([
                'company_id' => $member->company_id,
                'member_id' => $member->id,
                'key' => $key,
            ]);

            $triggerType = (string) ($routine['trigger_type'] ?? 'schedule');
            $scheduleConfig = $routine['schedule'] ?? null;
            $playbookRef = (string) ($routine['playbook_ref'] ?? '');
            if ($playbookRef !== '') $playbooks[] = $playbookRef;

            $existingMetadata = is_array($schedule->metadata) ? $schedule->metadata : [];
            $provenance = [
                'source' => 'extension_workforce_manifest',
                'owner_extension' => $ownerExtension,
                'owner_extension_version' => (string) ($routine['owner_extension_version'] ?? $definition['owner_extension_version'] ?? ''),
                'role_definition_id' => $roleDefinitionId,
                'role_definition_fingerprint' => (string) ($definition['definition_fingerprint'] ?? $routine['role_definition_fingerprint'] ?? ''),
                'routine_id' => $routineId,
                'routine_fingerprint' => $routineFingerprint,
                'source_schema_version' => (string) ($routine['source_schema_version'] ?? $definition['definition_source_schema_version'] ?? '2.0'),
                'role_key' => (string) ($definition['key'] ?? $roleDefinitionId),
                'playbook_ref' => $playbookRef,
                'verticals' => $verticals,
                'timezone' => $timezone,
                'creates' => 'workforce_task',
                'business_mutation' => false,
            ];

            if ((bool) ($existingMetadata['user_override'] ?? false)) {
                unset($existingMetadata['disabled_reason'], $existingMetadata['disabled_at']);
                $schedule->forceFill([
                    'owner_extension' => $ownerExtension,
                    'owner_extension_version' => $provenance['owner_extension_version'],
                    'role_definition_id' => $roleDefinitionId,
                    'role_definition_fingerprint' => $provenance['role_definition_fingerprint'],
                    'routine_id' => $routineId,
                    'routine_fingerprint' => $routineFingerprint,
                    'source_schema_version' => $provenance['source_schema_version'],
                    'is_active' => true,
                    'metadata' => array_merge($existingMetadata, $provenance, ['user_override' => true]),
                ])->save();
                continue;
            }

            $template = $routine['task_template'] ?? [];
            $template['metadata'] = array_merge($template['metadata'] ?? [], [
                'proactive' => true,
                'responsibility_key' => $routineId,
                'owner_extension' => $ownerExtension,
                'role_definition_id' => $roleDefinitionId,
                'routine_fingerprint' => $routineFingerprint,
                'playbook_ref' => $playbookRef,
                'verticals' => $verticals,
                'creates' => 'workforce_task',
                'business_mutation' => false,
            ]);

            $definitionChanged = ! $schedule->exists || (string) $schedule->routine_fingerprint !== $routineFingerprint;
            $scheduleChanged = $schedule->schedule !== $scheduleConfig;
            $schedule->fill([
                'owner_extension' => $ownerExtension,
                'owner_extension_version' => $provenance['owner_extension_version'],
                'role_definition_id' => $roleDefinitionId,
                'role_definition_fingerprint' => $provenance['role_definition_fingerprint'],
                'routine_id' => $routineId,
                'routine_fingerprint' => $routineFingerprint,
                'source_schema_version' => $provenance['source_schema_version'],
                'name' => (string) $routine['name'],
                'trigger_type' => $triggerType,
                'event_type' => $triggerType === 'event' ? ($routine['event_type'] ?? null) : null,
                'conditions' => $routine['conditions'] ?? [],
                'schedule' => $scheduleConfig,
                'task_template' => $template,
                'next_run_at' => $triggerType === 'schedule'
                    ? (($definitionChanged || $scheduleChanged || ! $schedule->next_run_at)
                        ? $this->nextOccurrence((array) $scheduleConfig, now(), $timezone)
                        : $schedule->next_run_at)
                    : null,
                'is_active' => true,
                'metadata' => array_merge($existingMetadata, $provenance),
            ]);
            $schedule->save();
        }

        foreach (WorkforceSchedule::query()->forCompany((int) $member->company_id)->where('member_id', $member->id)->get() as $schedule) {
            $source = (string) data_get($schedule->metadata ?? [], 'source', '');
            $ownedSource = (string) ($schedule->owner_extension ?? '') === $ownerExtension
                || in_array($source, ['role_registry','extension_workforce_manifest'], true);
            if ($ownedSource && ! in_array((string) $schedule->key, $activeKeys, true) && $schedule->is_active) {
                $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
                $metadata['disabled_reason'] = 'routine_removed_or_replaced';
                $schedule->forceFill(['is_active' => false, 'metadata' => $metadata])->save();
            }
        }

        $member->forceFill(['playbooks' => array_values(array_unique(array_filter($playbooks)))])->save();
        return count($routines);
    }

    public function nextOccurrence(array $schedule, Carbon $after, string $timezone): Carbon
    {
        $timezone = $this->normaliseTimezone($timezone);
        $cursor = $after->copy()->setTimezone($timezone);
        $frequency = strtolower((string) ($schedule['frequency'] ?? 'daily'));
        [$hour, $minute] = $this->parseTime((string) ($schedule['time'] ?? '08:00'));

        if ($frequency === 'hourly') {
            return $cursor->copy()->addHour()->startOfHour()->setTimezone(config('app.timezone', 'UTC'));
        }

        if ($frequency === 'monthly') {
            $day = max(1, min(28, (int) ($schedule['day'] ?? 1)));
            $candidate = $cursor->copy()->day($day)->setTime($hour, $minute);
            if ($candidate->lte($cursor)) $candidate = $cursor->copy()->addMonthNoOverflow()->day($day)->setTime($hour, $minute);
            return $candidate->setTimezone(config('app.timezone', 'UTC'));
        }

        $allowedDays = array_map('intval', $schedule['days'] ?? []);
        if ($frequency === 'weekdays') {
            $allowedDays = [1, 2, 3, 4, 5];
        } elseif ($frequency === 'weekly' && $allowedDays === []) {
            $allowedDays = [1];
        }

        for ($i = 0; $i < 370; $i++) {
            $candidate = $cursor->copy()->addDays($i)->setTime($hour, $minute, 0);
            if ($candidate->lte($cursor)) continue;
            if ($frequency === 'daily' || $allowedDays === [] || in_array($candidate->dayOfWeekIso, $allowedDays, true)) {
                return $candidate->setTimezone(config('app.timezone', 'UTC'));
            }
        }

        return $cursor->copy()->addDay()->setTime($hour, $minute)->setTimezone(config('app.timezone', 'UTC'));
    }

    private function disableMemberSources(WorkforceMember $member, string $reason): void
    {
        foreach (WorkforceSchedule::query()->forCompany((int) $member->company_id)->where('member_id', $member->id)->where('is_active', true)->get() as $schedule) {
            $source = (string) data_get($schedule->metadata ?? [], 'source', '');
            if (! in_array($source, ['role_registry','extension_workforce_manifest'], true) && ! $schedule->owner_extension) continue;
            $metadata = is_array($schedule->metadata) ? $schedule->metadata : [];
            $metadata['disabled_reason'] = $reason;
            $schedule->forceFill(['is_active' => false, 'metadata' => $metadata])->save();
        }
    }

    private function normaliseTimezone(string $timezone): string
    {
        $timezone = trim($timezone) !== '' ? trim($timezone) : (string) config('app.timezone', 'UTC');
        try { new DateTimeZone($timezone); return $timezone; } catch (\Throwable) { return (string) config('app.timezone', 'UTC'); }
    }

    private function parseTime(string $time): array
    {
        $parts = array_map('intval', explode(':', $time));
        return [max(0, min(23, $parts[0] ?? 8)), max(0, min(59, $parts[1] ?? 0))];
    }
}
