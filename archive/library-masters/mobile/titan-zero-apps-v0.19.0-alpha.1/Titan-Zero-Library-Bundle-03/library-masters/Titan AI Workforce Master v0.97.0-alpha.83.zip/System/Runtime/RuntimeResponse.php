<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Runtime;

use InvalidArgumentException;

final readonly class RuntimeResponse
{
    public const STATUSES = ['completed', 'needs_input', 'tool_proposal', 'unavailable', 'failed'];

    /**
     * @param array<string, mixed> $output
     * @param array<int, RuntimeToolProposal> $toolProposals
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        public string $status,
        public array $output = [],
        public array $toolProposals = [],
        public ?RuntimeFailure $failure = null,
        public ?string $runUuid = null,
        public array $metadata = [],
    ) {
        if (! in_array($status, self::STATUSES, true)) {
            throw new InvalidArgumentException('Unsupported Agent Runtime response status.');
        }
        foreach ($toolProposals as $proposal) {
            if (! $proposal instanceof RuntimeToolProposal) {
                throw new InvalidArgumentException('Agent Runtime tool_proposals must contain RuntimeToolProposal values.');
            }
        }
        if ($status === 'failed' && $failure === null) {
            throw new InvalidArgumentException('Failed Agent Runtime response requires RuntimeFailure.');
        }
        if ($status === 'tool_proposal' && $toolProposals === []) {
            throw new InvalidArgumentException('tool_proposal response requires at least one proposal.');
        }
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        if (($data['protocol'] ?? null) !== 'titan.agent-runtime/1') {
            throw new InvalidArgumentException('Unsupported Agent Runtime response protocol.');
        }
        if (($data['authoritative_business_execution'] ?? false) === true) {
            throw new InvalidArgumentException('Agent Runtime may not claim authoritative business execution.');
        }
        $proposals = array_map(
            static fn (array $proposal): RuntimeToolProposal => RuntimeToolProposal::fromArray($proposal),
            array_values(array_filter((array) ($data['tool_proposals'] ?? []), 'is_array')),
        );
        $failure = isset($data['failure']) && is_array($data['failure'])
            ? RuntimeFailure::fromArray($data['failure'])
            : null;

        return new self(
            status: (string) ($data['status'] ?? ''),
            output: (array) ($data['output'] ?? []),
            toolProposals: $proposals,
            failure: $failure,
            runUuid: isset($data['run_uuid']) ? (string) $data['run_uuid'] : null,
            metadata: (array) ($data['metadata'] ?? []),
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'protocol' => 'titan.agent-runtime/1',
            'status' => $this->status,
            'run_uuid' => $this->runUuid,
            'output' => $this->output,
            'tool_proposals' => array_map(static fn (RuntimeToolProposal $p): array => $p->toArray(), $this->toolProposals),
            'failure' => $this->failure?->toArray(),
            'metadata' => $this->metadata,
            'authoritative_business_execution' => false,
        ];
    }

    /**
     * Compatibility view for the pre-contract Workforce planning/review services.
     * This intentionally returns only model/runtime output, never execution claims.
     *
     * @return array<string, mixed>
     */
    public function legacyOutput(): array
    {
        $output = $this->output;
        if ($this->runUuid !== null && ! array_key_exists('run_uuid', $output)) {
            $output['run_uuid'] = $this->runUuid;
        }
        if ($this->toolProposals !== []) {
            $output['runtime_tool_proposals'] = array_map(static fn (RuntimeToolProposal $p): array => $p->toArray(), $this->toolProposals);
        }
        if ($this->failure !== null) {
            $output['runtime_failure'] = $this->failure->toArray();
        }
        return $output;
    }
}
