<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class WorkforceTaskDependency extends Model
{
    protected $table = 'ext_titan_ai_workforce_task_dependencies';
    protected $guarded = [];
    protected $casts = ['blocking' => 'boolean', 'condition' => 'array', 'metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
    public function task(): BelongsTo { return $this->belongsTo(WorkforceTask::class, 'task_id'); }
    public function dependsOn(): BelongsTo { return $this->belongsTo(WorkforceTask::class, 'depends_on_task_id'); }
}
