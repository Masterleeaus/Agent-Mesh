<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class IntrinsicRoleCatalog
{
    /** @var array<int,array<string,mixed>>|null */
    private static ?array $definitions = null;

    /** @return array<int,array<string,mixed>> */
    public function all(): array
    {
        if (self::$definitions !== null) return self::$definitions;

        $path = dirname(__DIR__, 2) . '/resources/workforce/role-definitions.json';
        if (! is_file($path)) throw new RuntimeException('Intrinsic Workforce role catalogue is missing.');

        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new RuntimeException('Intrinsic Workforce role catalogue must be an array.');

        return self::$definitions = array_values($decoded);
    }

    /** @return array<string,mixed>|null */
    public function find(string $keyOrDefinitionId): ?array
    {
        foreach ($this->all() as $definition) {
            if (($definition['key'] ?? null) === $keyOrDefinitionId || ($definition['role_definition_id'] ?? null) === $keyOrDefinitionId) return $definition;
            if (in_array($keyOrDefinitionId, $definition['aliases'] ?? [], true)) return $definition;
        }
        return null;
    }

    /** @return list<array<string,mixed>> Runtime-compatible views with zero executable capability authority. */
    public function runtimeRoles(): array
    {
        return array_map(static function (array $definition): array {
            $role = $definition;
            $role['role_id'] = (string) $definition['role_definition_id'];
            $role['division'] = (string) $definition['division_key'];
            $role['team'] = (string) $definition['team_key'];
            $role['parent_manager'] = $definition['reports_to_role_definition_id'] ?? null;
            $role['reports_to'] = $definition['reports_to_role_definition_id'] ?? null;
            $role['skills'] = array_values(array_map('strval', $definition['recommended_skills'] ?? []));
            $role['capabilities'] = [];
            $role['capability_variants'] = [];
            $role['tools'] = [];
            $role['tool_access'] = [];
            $role['playbooks'] = [];
            $role['interaction_wizards'] = [];
            $role['knowledge_scopes'] = [];
            $role['memory_scopes'] = [];
            $maturity = is_array($definition['recommended_business_maturity'] ?? null) ? $definition['recommended_business_maturity'] : [];
            $role['activation'] = [
                'min_tier' => (string) ($maturity['min'] ?? 'SOLO'),
                'max_tier' => (string) ($maturity['max'] ?? 'ENTERPRISE'),
                'verticals' => array_values(array_map('strval', $definition['vertical_applicability'] ?? ['all'])),
            ];
            $role['autonomy_profile'] = [
                'starting_level' => 'Suggest',
                'starting_score' => 0,
                'desired_level' => 'Suggest',
                'desired_score' => 0,
                'authority_source' => 'titan_autonomy',
                'self_promotion' => false,
            ];
            $role['owner_extension'] = 'titan-ai-workforce';
            $role['owner_extension_version'] = 'intrinsic';
            $role['definition_fingerprint'] = hash('sha256', json_encode($definition, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
            $role['definition_schema_version'] = 'intrinsic-v2';
            $role['definition_source'] = 'intrinsic_workforce_catalogue';
            return $role;
        }, $this->all());
    }
}
