<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceRuntimeProfile extends Model
{
    protected $table = 'ext_titan_ai_workforce_runtime_profiles';
    protected $guarded = [];
    protected $casts = [
        'provider_policy' => 'array',
        'model_policy' => 'array',
        'memory_policy' => 'array',
        'channel_behavior' => 'array',
        'informational_tools' => 'array',
        'reasoning_config' => 'array',
        'metadata' => 'array',
        'is_active' => 'boolean',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
