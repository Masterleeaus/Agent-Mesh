<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceAutonomyLevel: string
{
    case Manual = 'manual';
    case Assist = 'assist';
    case Semi = 'semi';
    case Auto = 'auto';
    case Predictive = 'predictive';

    public static function fromMixed(?string $value): self
    {
        return self::tryFrom(strtolower(trim((string)$value))) ?? self::Manual;
    }
}
