<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Throwable;

final class WorkforcePostActionVerificationService
{
    public function __construct(
        private readonly WorkforceCapabilityBindingRegistry $manifests,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    /** @return array<string,mixed> */
    public function verifyReceipt(WorkforceExecutionAttempt $attempt, WorkforceTask $task, WorkforceMember $worker, array $receipt, array $command): array
    {
        $owner = trim((string) ($task->capability_owner_extension ?? ''));
        if ($owner === '') {
            $owners = $this->manifests->ownersForCapability((string) $worker->role_definition_id, (string) $task->capability);
            $owner = count($owners) === 1 ? $owners[0] : '';
        }
        $capability = $owner !== '' ? $this->manifests->findOwnedCapability($owner, (string) $task->capability, $task->capability_variant) : null;
        if (! is_array($capability)) return $this->persist($attempt, false, 'CAPABILITY_CONTRACT_MISSING');

        $postActionRequired = ($capability['mutation_mode'] ?? null) === 'command_bus_only';
        if (! $postActionRequired) return $this->persist($attempt, true, 'VERIFICATION_NOT_REQUIRED', ['post_action_verification' => false]);
        $resolved = $this->controlPlane->resolve('command_bus');
        if ($resolved === null) return $this->persist($attempt, false, 'VERIFICATION_REQUIRED', ['reason' => 'Command Bus unavailable for post-action verification.']);

        $bus = $resolved['service'];
        $payload = [
            'company_id' => (int) $task->company_id,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'intent_id' => (string) $attempt->intent_id,
            'intent_sha256' => (string) $attempt->intent_sha256,
            'idempotency_key' => (string) $attempt->idempotency_key,
            'receipt' => $receipt,
            'expected_state' => $attempt->expected_state ?? [],
            'expected_outcome' => $command['expected_outcome'] ?? data_get($task->metadata ?? [], 'expected_outcome') ?? null,
            'post_action_verification' => true,
        ];
        foreach (['verifyReceipt','verifyExecution','verify'] as $method) {
            if (! method_exists($bus, $method)) continue;
            try { $result = $bus->{$method}($payload); }
            catch (Throwable $e) {
                return $this->persist($attempt, false, 'VERIFICATION_REQUIRED', ['error' => mb_substr($e->getMessage(), 0, 1000), 'method' => $method]);
            }
            if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
            if (! is_array($result)) return $this->persist($attempt, false, 'VERIFICATION_REQUIRED', ['method' => $method]);
            $verified = ($result['verified'] ?? false) === true;
            $reason = $verified ? 'VERIFIED' : (string) ($result['reason_code'] ?? 'VERIFICATION_FAILED');
            return $this->persist($attempt, $verified, $reason, array_merge($result, [
                'method' => $method,
                'domain_state_ref' => $result['domain_state_ref'] ?? $result['state_ref'] ?? null,
                'verified' => $verified,
            ]));
        }
        return $this->persist($attempt, false, 'VERIFICATION_REQUIRED', ['reason' => 'Command Bus does not expose a post-action verification method.']);
    }

    private function persist(WorkforceExecutionAttempt $attempt, bool $verified, string $reason, array $result = []): array
    {
        $value = array_merge($result, ['verified' => $verified, 'reason_code' => $reason]);
        $attempt->forceFill([
            'verification_status' => $verified ? 'VERIFIED' : 'FAILED',
            'verification' => $value,
            'verified_at' => $verified ? now() : null,
            'status' => $verified ? 'VERIFIED' : 'RECOVERY_REQUIRED',
        ])->save();
        return $value;
    }
}
