<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects;

use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums\ZeroInputModality;
use InvalidArgumentException;

final readonly class ZeroIntentRequest
{
    /**
     * @param list<array<string,mixed>> $history
     * @param array<string,mixed> $contextHints
     * @param array<string,mixed> $authorityContext
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public int $companyId,
        public string $message,
        public string $conversationId,
        public string $traceId,
        public string $correlationId,
        public ?string $actorId = null,
        public string $actorType = 'owner',
        public ZeroInputModality $modality = ZeroInputModality::TEXT,
        public array $history = [],
        public array $contextHints = [],
        public array $authorityContext = [],
        public array $metadata = [],
    ) {
        if ($this->companyId <= 0) throw new InvalidArgumentException('company_id must be a positive integer.');
        if (trim($this->conversationId) === '') throw new InvalidArgumentException('conversation_id is required.');
        if (trim($this->traceId) === '') throw new InvalidArgumentException('trace_id is required.');
        if (trim($this->correlationId) === '') throw new InvalidArgumentException('correlation_id is required.');
        if (trim($this->actorType) === '') throw new InvalidArgumentException('actor_type is required.');
    }

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        $companyId = (int) ($payload['company_id'] ?? 0);
        $message = trim((string) ($payload['message'] ?? ''));
        return new self(
            companyId: $companyId,
            message: $message,
            conversationId: self::identifier((string) ($payload['conversation_id'] ?? ''), 'conv'),
            traceId: self::identifier((string) ($payload['trace_id'] ?? ''), 'trace'),
            correlationId: self::identifier((string) ($payload['correlation_id'] ?? ''), 'corr'),
            actorId: isset($payload['actor_id']) ? (string) $payload['actor_id'] : null,
            actorType: trim((string) ($payload['actor_type'] ?? 'owner')) ?: 'owner',
            modality: self::modality((string) ($payload['modality'] ?? 'text')),
            history: self::listOfArrays($payload['history'] ?? []),
            contextHints: is_array($payload['context_hints'] ?? null) ? $payload['context_hints'] : [],
            authorityContext: is_array($payload['authority_context'] ?? null) ? $payload['authority_context'] : [],
            metadata: is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [],
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'actor_id' => $this->actorId,
            'actor_type' => $this->actorType,
            'conversation_id' => $this->conversationId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'modality' => $this->modality->value,
            'message' => $this->message,
            'history' => $this->history,
            'context_hints' => $this->contextHints,
            'authority_context' => $this->authorityContext,
            'metadata' => $this->metadata,
        ];
    }

    private static function identifier(string $value, string $prefix): string
    {
        $value = trim($value);
        return $value !== '' ? $value : $prefix.':'.bin2hex(random_bytes(16));
    }

    private static function modality(string $value): ZeroInputModality
    {
        return ZeroInputModality::tryFrom(strtolower(trim($value))) ?? ZeroInputModality::TEXT;
    }

    /** @return list<array<string,mixed>> */
    private static function listOfArrays(mixed $value): array
    {
        if (! is_array($value)) return [];
        $result = [];
        foreach ($value as $row) if (is_array($row)) $result[] = $row;
        return $result;
    }
}
