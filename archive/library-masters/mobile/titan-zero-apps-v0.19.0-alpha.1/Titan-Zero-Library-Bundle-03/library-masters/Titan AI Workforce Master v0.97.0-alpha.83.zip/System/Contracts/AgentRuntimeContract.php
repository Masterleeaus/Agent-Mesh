<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Contracts;

use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeRequest;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeResponse;

/**
 * Workforce-owned orchestration port for reusable AI staff intelligence.
 *
 * Implementations may reason, converse and propose tools. They must not claim
 * authoritative business execution or bypass Workforce governance/Command Bus.
 */
interface AgentRuntimeContract
{
    public const PROTOCOL = 'titan.agent-runtime/1';

    public function execute(RuntimeRequest $request): RuntimeResponse;
}
