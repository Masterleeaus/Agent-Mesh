<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceWorkItemVerificationState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHistory;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceTaskService
{
    public function __construct(
        private readonly WorkforceJourneySpineService $journey,
        private readonly WorkforceDependencyService $dependencies,
        private readonly WorkforceManifestLifecycleService $definitionLifecycle,
        private readonly WorkforceCapabilityBindingRegistry $capabilityBindings,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
        private readonly WorkforceProviderRoutingService $providerRouting,
    ) {}

    public function create(int $companyId, array $data, ?WorkforceMember $actor = null): WorkforceTask
    {
        return DB::transaction(function () use ($companyId, $data, $actor) {
            $trace = (string) ($data['trace_id'] ?? Str::uuid());
            $correlation = (string) ($data['correlation_id'] ?? $trace);
            $parentTaskId = isset($data['parent_task_id']) && $data['parent_task_id'] !== null ? (int) $data['parent_task_id'] : null;
            $this->dependencies->assertParentExists($companyId, $parentTaskId);
            $idempotency = isset($data['idempotency_key']) ? trim((string) $data['idempotency_key']) : '';
            if ($idempotency !== '') {
                $existing = WorkforceTask::withTrashed()->forCompany($companyId)->where('idempotency_key', $idempotency)->first();
                if ($existing) return $existing;
                $data['idempotency_key'] = $idempotency;
            }
            if (! empty($data['assignee_member_id'])) {
                $assignee = WorkforceMember::query()->forCompany($companyId)->find((int) $data['assignee_member_id']);
                if ($assignee) {
                    $data = array_merge($data, $this->definitionLifecycle->pinRoleDefinition($assignee));
                    $capabilityName = trim((string) ($data['capability'] ?? ''));
                    if ($capabilityName !== '') {
                        $requestedOwner = trim((string) ($data['capability_owner_extension'] ?? ''));
                        $liveCapability = $this->providerRouting->assertExecutableRoute(
                            $assignee,
                            $capabilityName,
                            'capability',
                            $requestedOwner !== '' ? $requestedOwner : null,
                        );
                        $selectedProvider = trim((string) ($liveCapability['selected_provider'] ?? ''));
                        $selectedVersion = trim((string) ($liveCapability['selected_provider_version'] ?? ''));
                        if ($selectedProvider === '' || $selectedVersion === '') {
                            throw new InvalidArgumentException('Executable Workforce task requires an exact capability provider/version pin.');
                        }
                        $data['capability_owner_extension'] = $selectedProvider;
                        $data['capability_owner_extension_version'] = $selectedVersion;
                        $metadata = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
                        $metadata['provider_route'] = [
                            'provider' => $selectedProvider,
                            'provider_version' => $selectedVersion,
                            'selection_basis' => (string) ($liveCapability['selection_basis'] ?? ''),
                            'surface_id' => $capabilityName,
                            'surface_type' => 'capability',
                            'authority_inherited' => false,
                            'execution_authority_granted' => false,
                        ];
                        $data['metadata'] = $metadata;
                    }
                }
            }

            $attributes = array_merge($data, [
                'task_uuid' => $data['task_uuid'] ?? (string) Str::uuid(),
                'company_id' => $companyId,
                'status' => $data['status'] ?? WorkforceTaskStatus::Created,
                'priority' => $data['priority'] ?? 50,
                'risk_level' => $data['risk_level'] ?? 'LOW',
                'trace_id' => $trace,
                'correlation_id' => $correlation,
                'last_activity_at' => now(),
            ]);

            if ($idempotency !== '') {
                $task = WorkforceTask::query()->withTrashed()->firstOrCreate(
                    ['company_id' => $companyId, 'idempotency_key' => $idempotency],
                    $attributes,
                );
                if (! $task->wasRecentlyCreated) return $task;
            } else {
                $task = WorkforceTask::query()->create($attributes);
            }

            $this->record($task, $actor, 'task.created', null, $task->status->value, null, ['origin' => $task->origin_type]);
            return $task;
        });
    }

    public function transition(WorkforceTask $task, WorkforceTaskStatus $to, ?WorkforceMember $actor, string $event, ?string $reason = null, array $context = []): WorkforceTask
    {
        if ($task->status->terminal()) { throw new InvalidArgumentException('Terminal Workforce task cannot transition.'); }
        if ($to === WorkforceTaskStatus::Completed && $task->work_item_uuid) {
            if ($task->verification_state !== WorkforceWorkItemVerificationState::Verified) {
                throw new InvalidArgumentException('Canonical Work Item cannot complete before verified outcome and evidence.');
            }
            if (! $this->dependencies->readyForCompletion($task)) {
                throw new InvalidArgumentException('Canonical Work Item cannot complete before completion-gated dependencies are satisfied.');
            }
        }
        if (! $this->canTransition($task->status, $to)) {
            throw new InvalidArgumentException('Invalid Workforce task transition: ' . $task->status->value . ' -> ' . $to->value);
        }
        $from = $task->status->value;
        $task->forceFill([
            'status' => $to,
            'last_activity_at' => now(),
            'started_at' => $task->started_at ?: (in_array($to, [WorkforceTaskStatus::Processing, WorkforceTaskStatus::Executing], true) ? now() : null),
            'completed_at' => $to === WorkforceTaskStatus::Completed ? now() : $task->completed_at,
        ])->save();
        $this->record($task, $actor, $event, $from, $to->value, $reason, $context);
        $task = $task->refresh();
        if (in_array($to, [WorkforceTaskStatus::Processing, WorkforceTaskStatus::Executing, WorkforceTaskStatus::Completed], true)) {
            $this->dependencies->dispatchReadyDependents($task);
        }
        return $task;
    }


    private function canTransition(WorkforceTaskStatus $from, WorkforceTaskStatus $to): bool
    {
        if ($from === $to) { return true; }
        $allowed = [
            WorkforceTaskStatus::Created->value => [WorkforceTaskStatus::Assigned, WorkforceTaskStatus::Processing, WorkforceTaskStatus::Blocked, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::Assigned->value => [WorkforceTaskStatus::Processing, WorkforceTaskStatus::Submitted, WorkforceTaskStatus::Blocked, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::Processing->value => [WorkforceTaskStatus::Submitted, WorkforceTaskStatus::Completed, WorkforceTaskStatus::AwaitingData, WorkforceTaskStatus::Recovery, WorkforceTaskStatus::Failed, WorkforceTaskStatus::Blocked, WorkforceTaskStatus::Escalated],
            WorkforceTaskStatus::Submitted->value => [WorkforceTaskStatus::UnderReview, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::UnderReview->value => [WorkforceTaskStatus::Approved, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Rejected, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::AwaitingData],
            WorkforceTaskStatus::Approved->value => [WorkforceTaskStatus::HandoffPending, WorkforceTaskStatus::ReceiverReview, WorkforceTaskStatus::Executing, WorkforceTaskStatus::Accepted, WorkforceTaskStatus::Completed, WorkforceTaskStatus::Blocked, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::RevisionRequired->value => [WorkforceTaskStatus::Processing, WorkforceTaskStatus::AwaitingData, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::HandoffPending->value => [WorkforceTaskStatus::ReceiverReview, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Escalated],
            WorkforceTaskStatus::ReceiverReview->value => [WorkforceTaskStatus::Accepted, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Rejected, WorkforceTaskStatus::Escalated],
            WorkforceTaskStatus::Accepted->value => [WorkforceTaskStatus::Assigned, WorkforceTaskStatus::Processing, WorkforceTaskStatus::Executing, WorkforceTaskStatus::Completed, WorkforceTaskStatus::Blocked],
            WorkforceTaskStatus::Blocked->value => [WorkforceTaskStatus::Assigned, WorkforceTaskStatus::Processing, WorkforceTaskStatus::AwaitingData, WorkforceTaskStatus::Recovery, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::AwaitingData->value => [WorkforceTaskStatus::Processing, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::Executing->value => [WorkforceTaskStatus::Completed, WorkforceTaskStatus::Recovery, WorkforceTaskStatus::Failed, WorkforceTaskStatus::Blocked],
            WorkforceTaskStatus::Recovery->value => [WorkforceTaskStatus::Processing, WorkforceTaskStatus::Executing, WorkforceTaskStatus::Failed, WorkforceTaskStatus::Escalated, WorkforceTaskStatus::Cancelled],
            WorkforceTaskStatus::Escalated->value => [WorkforceTaskStatus::Processing, WorkforceTaskStatus::RevisionRequired, WorkforceTaskStatus::Cancelled, WorkforceTaskStatus::Failed],
        ];
        return in_array($to, $allowed[$from->value] ?? [], true);
    }

    public function record(WorkforceTask $task, ?WorkforceMember $actor, string $event, ?string $from, ?string $to, ?string $reason, array $context = []): void
    {
        WorkforceTaskHistory::query()->create([
            'company_id' => $task->company_id,
            'task_id' => $task->id,
            'actor_member_id' => $actor?->id,
            'event' => $event,
            'from_status' => $from,
            'to_status' => $to,
            'reason' => $reason,
            'context' => $context,
            'trace_id' => $task->trace_id,
            'created_at' => now(),
        ]);
        $this->journey->recordTaskLifecycle($task, $actor, $event, $from, $to, $reason, $context);
    }
}
