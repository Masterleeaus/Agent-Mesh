<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSignalOutbox;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceSignalBridge;
use Illuminate\Console\Command;

class RetryWorkforceSignalOutboxCommand extends Command
{
    protected $signature = 'titan-workforce:retry-signals {--limit=100}';
    protected $description = 'Retry delivery of Workforce Signal outbox entries.';
    public function handle(WorkforceSignalBridge $signals): int
    {
        $rows = WorkforceSignalOutbox::query()->whereNull('published_at')->orderBy('id')->limit((int) $this->option('limit'))->get();
        foreach ($rows as $row) {
            $signals->retry($row);
        }
        $this->info('Retried ' . $rows->count() . ' Workforce Signal(s).');
        return self::SUCCESS;
    }
}
