<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCostReceipt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProviderHealthEvent;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResourceBudget;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;

/**
 * Read-only company-scoped observability projection.
 * Reconstructs one correlation trail without taking ownership from providers.
 */
final class WorkforceUnifiedObservabilityService
{
    public function trace(int $companyId, string $correlationId): array
    {
        $correlationId = trim($correlationId);
        if ($companyId <= 0 || $correlationId === '') {
            return ['company_id'=>$companyId,'correlation_id'=>$correlationId,'state'=>'INVALID','stages'=>[]];
        }

        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->where('correlation_id', $correlationId)->orderBy('created_at')->get();

        $stages = [];
        foreach ($tasks as $task) {
            $stages[] = [
                'stage'=>'workforce_task',
                'task_id'=>(string)$task->task_uuid,
                'status'=>is_object($task->status) ? $task->status->value : (string)$task->status,
                'capability'=>(string)$task->capability,
                'knowledge_receipt'=>data_get($task->knowledge_preflight,'receipt_hash'),
                'risk_reference'=>data_get($task->risk_snapshot,'decision_id'),
                'assurance_reference'=>data_get($task->assurance_snapshot,'decision_id'),
                'autonomy_reference'=>data_get($task->autonomy_snapshot,'decision_id'),
                'causation_id'=>(string)($task->causation_id ?? ''),
                'occurred_at'=>optional($task->created_at)->toISOString(),
            ];

            foreach (WorkforceExecutionAttempt::query()->where('company_id',$companyId)->where('task_id',$task->id)->orderBy('created_at')->get() as $attempt) {
                $stages[] = [
                    'stage'=>'execution_attempt',
                    'attempt_id'=>(string)$attempt->attempt_uuid,
                    'status'=>(string)$attempt->status,
                    'intent_id'=>(string)$attempt->intent_id,
                    'idempotency_key'=>(string)$attempt->idempotency_key,
                    'receipt_ref'=>$attempt->receipt_ref,
                    'recovery'=>$attempt->recovery,
                    'occurred_at'=>optional($attempt->created_at)->toISOString(),
                ];
            }
        }

        foreach (WorkforceCostReceipt::query()->forCompany($companyId)->where('correlation_id',$correlationId)->orderBy('created_at')->get() as $receipt) {
            $stages[] = [
                'stage'=>'cost_receipt',
                'provider'=>$receipt->provider,
                'execution_location'=>$receipt->execution_location,
                'cost_owner'=>$receipt->cost_owner,
                'resource_type'=>$receipt->resource_type,
                'actual_cost'=>(float)$receipt->actual_cost,
                'currency'=>$receipt->currency,
                'occurred_at'=>optional($receipt->created_at)->toISOString(),
            ];
        }

        foreach (WorkforceOutcome::query()->forCompany($companyId)->where('correlation_id',$correlationId)->orderBy('observed_at')->get() as $outcome) {
            $stages[] = [
                'stage'=>'outcome',
                'success'=>(bool)$outcome->success,
                'verified_at'=>optional($outcome->verified_at)->toISOString(),
                'occurred_at'=>optional($outcome->observed_at)->toISOString(),
            ];
        }

        usort($stages, static fn(array $a,array $b): int => strcmp((string)($a['occurred_at']??''),(string)($b['occurred_at']??'')));

        return [
            'company_id'=>$companyId,
            'correlation_id'=>$correlationId,
            'stage_count'=>count($stages),
            'stages'=>$stages,
            'authority_inherited'=>false,
            'read_only'=>true,
        ];
    }

    public function health(int $companyId): array
    {
        $now = now();
        $stuck = WorkforceTask::query()->forCompany($companyId)
            ->whereNotIn('status',['COMPLETED','FAILED','CANCELLED','REJECTED'])
            ->where(function($q) use ($now) {
                $q->where('last_activity_at','<',$now->copy()->subHours(4))
                  ->orWhere(function($q2) use ($now){$q2->whereNull('last_activity_at')->where('created_at','<',$now->copy()->subHours(4));});
            })->count();

        $unresolvedRecovery = WorkforceExecutionAttempt::query()
            ->where('company_id',$companyId)
            ->whereIn('status',['RECOVERY_REQUIRED','UNCERTAIN','RECONCILING'])
            ->count();

        $providerIncidents = WorkforceProviderHealthEvent::query()->forCompany($companyId)
            ->whereIn('state',['degraded','unavailable','blocked','policy_disabled'])
            ->where('observed_at','>=',$now->copy()->subDay())
            ->count();

        $budgets = WorkforceResourceBudget::query()->forCompany($companyId)->get();
        $budgetRows = $budgets->map(function($b){
            $hard=$b->hard_limit;
            $spent=(float)$b->spent_amount;
            $ratio=$hard && (float)$hard>0 ? $spent/(float)$hard : null;
            return [
                'resource_type'=>$b->resource_type,
                'spent'=>$spent,
                'hard_limit'=>$hard,
                'usage_ratio'=>$ratio===null?null:round($ratio,4),
                'state'=>$ratio===null?'UNBOUNDED':($ratio>=1?'EXHAUSTED':($ratio>=0.8?'WARNING':'HEALTHY')),
            ];
        })->values()->all();

        return [
            'stuck_work'=>$stuck,
            'unresolved_reconciliation'=>$unresolvedRecovery,
            'recent_provider_incidents'=>$providerIncidents,
            'resource_budgets'=>$budgetRows,
            'read_only'=>true,
        ];
    }
}
