<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceRoleDefinition extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_role_definitions';
    protected $guarded = [];
    protected $casts = [
        'responsibilities' => 'array',
        'responsibility_ids' => 'array',
        'recommended_skills' => 'array',
        'vertical_applicability' => 'array',
        'recommended_business_maturity' => 'array',
        'activation_rules' => 'array',
        'aliases' => 'array',
        'tags' => 'array',
        'substitution_allowed' => 'boolean',
        'metadata' => 'array',
    ];


    public function teamDefinition(): BelongsTo
    {
        return $this->belongsTo(WorkforceTeamDefinition::class, 'team_definition_id', 'team_definition_id');
    }

    public function scopeVisibleToCompany($query, int $companyId) { return $query->where(function ($q) use ($companyId) { $q->whereNull('company_id')->orWhere('company_id', $companyId); }); }
}
