<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums;

enum ZeroInputModality: string
{
    case TEXT = 'text';
    case VOICE = 'voice';
    case VISION = 'vision';
    case TOUCH = 'touch';
    case SYSTEM = 'system';
    case SIGNAL = 'signal';
}
