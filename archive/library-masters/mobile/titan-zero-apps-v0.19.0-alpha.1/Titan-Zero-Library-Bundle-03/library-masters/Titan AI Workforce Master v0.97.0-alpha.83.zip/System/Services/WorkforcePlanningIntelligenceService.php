<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCanonicalCapabilityMatrix;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Collection;

/** Read-only company-scoped capacity planning. Recommendations never hire staff or grant authority. */
final class WorkforcePlanningIntelligenceService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];

    public function __construct(
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforcePlanningService $planning,
        private readonly WorkforceCanonicalCapabilityMatrix $matrix,
        private readonly WorkforceCapabilityAvailabilityService $availability,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId, string $businessTier = 'SMALL', array $verticals = []): array
    {
        $members = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)
            ->with(['division','team'])->get();
        $tasks = WorkforceTask::query()->forCompany($companyId)->whereNotIn('status', self::TERMINAL)->get();
        $divisions = WorkforceDivision::query()->forCompany($companyId)->where('is_active', true)->with('definition')->get();
        $teams = WorkforceTeam::query()->forCompany($companyId)->where('is_active', true)->with(['definition','division'])->get();

        $divisionMetrics = [];
        foreach ($divisions as $division) {
            $divisionMetrics[(string) ($division->definition?->key ?? $division->division_definition_id ?? $division->id)] = $this->queueHealth->snapshot($companyId, (int) $division->id);
        }

        $openByMember = $tasks->whereNotNull('assignee_member_id')->countBy('assignee_member_id');
        $underused = $members->filter(function (WorkforceMember $member) use ($openByMember): bool {
            if ($member->tier === WorkforceTier::Manager) return false;
            $capacity = max(1, (int) ($member->max_concurrent_tasks ?? 5));
            return ((int) ($openByMember[(int)$member->id] ?? 0)) / $capacity <= 0.25;
        })->map(fn (WorkforceMember $m): array => [
            'member_id'=>(int)$m->id,'name'=>(string)$m->name,'role'=>(string)$m->role,
            'open_work'=>(int)($openByMember[(int)$m->id] ?? 0),'capacity'=>max(1,(int)($m->max_concurrent_tasks ?? 5)),
            'utilisation'=>round(((int)($openByMember[(int)$m->id] ?? 0))/max(1,(int)($m->max_concurrent_tasks ?? 5)),2),
        ])->values()->all();

        $overloadedTeams = $teams->map(function (WorkforceTeam $team) use ($members, $tasks): ?array {
            $teamMembers = $members->where('team_id', $team->id);
            $capacity = $teamMembers->sum(fn (WorkforceMember $m): int => max(1,(int)($m->max_concurrent_tasks ?? 5)));
            $open = $tasks->where('team_id', $team->id)->count();
            $ratio = $capacity > 0 ? $open / $capacity : ($open > 0 ? 99.0 : 0.0);
            if ($ratio < .80) return null;
            return ['team_id'=>(int)$team->id,'team'=>(string)($team->definition?->name ?? $team->name ?? $team->team_definition_id),
                'open_work'=>$open,'capacity'=>$capacity,'load_ratio'=>round($ratio,2),'pressure'=>$ratio>=1.0?'HIGH':'ELEVATED'];
        })->filter()->values()->all();

        $managerSpan = $members->where('tier', WorkforceTier::Manager)->map(function (WorkforceMember $manager) use ($members): array {
            $reports = $members->where('manager_id', $manager->id)->count();
            return ['manager_id'=>(int)$manager->id,'name'=>(string)$manager->name,'direct_reports'=>$reports,'over_span'=>$reports>8];
        })->sortByDesc('direct_reports')->values()->all();

        $activeRoleIds = $members->pluck('role_definition_id')->filter()->map('strval')->unique()->all();
        $responsibilityAssignments = (array) data_get(WorkforceResponsibilityRegistry::all(), 'assignments', []);
        $responsibilityGaps = collect($responsibilityAssignments)->filter(fn (array $a): bool => !in_array((string)($a['role_definition_id'] ?? ''), $activeRoleIds, true))
            ->map(fn (array $a): array => ['responsibility_id'=>(string)($a['responsibility_id'] ?? ''),'required_role_definition_id'=>(string)($a['role_definition_id'] ?? ''),'reason'=>'no_active_owner_role'])->unique(fn(array $r)=>$r['responsibility_id'].'|'.$r['required_role_definition_id'])->values()->take(100)->all();

        $capabilityGaps = [];
        foreach ($members as $member) {
            $live = $this->availability->forMember($member);
            if ((string)($live['state'] ?? 'available') === 'available') continue;
            $capabilityGaps[] = ['member_id'=>(int)$member->id,'name'=>(string)$member->name,'role'=>(string)$member->role,
                'state'=>(string)($live['state'] ?? 'unavailable'),'missing_providers'=>collect((array)($live['provider_bindings'] ?? []))->filter(fn(array $b)=>($b['state']??'unavailable')!=='available')->pluck('provider')->filter()->unique()->values()->all()];
        }

        $upcoming = WorkforceTask::query()->forCompany($companyId)->whereNotIn('status', self::TERMINAL)
            ->whereNotNull('scheduled_at')->whereBetween('scheduled_at', [now(), now()->addDays(14)])->get();
        $upcomingWorkload = ['next_14_days'=>$upcoming->count(),'unassigned'=>$upcoming->whereNull('assignee_member_id')->count(),
            'by_division'=>$upcoming->countBy('division_id')->sortDesc()->all(),'by_team'=>$upcoming->countBy('team_id')->sortDesc()->all()];

        $bottlenecks = collect($divisionMetrics)->filter(fn(array $m)=>in_array((string)($m['pressure']??'NORMAL'),['HIGH','CRITICAL'],true) || (bool)($m['coverage_gap']??false))
            ->map(fn(array $m,string $division): array => ['division'=>$division,'pressure'=>$m['pressure']??'NORMAL','queue_depth'=>$m['queue_depth']??0,'overdue'=>$m['overdue_count']??0,'blocked'=>$m['blocked_count']??0,'coverage_gap'=>$m['coverage_gap']??false])->values()->all();

        $recommendations = $this->planning->recommend($companyId, $businessTier, $verticals, $divisionMetrics);
        $proposedRoles = array_map(function (array $r): array {
            $providers = $this->matrix->providerKeysForRole((string)$r['role_id']);
            $benefit = match ((string)$r['reason']) {
                'coverage_gap' => 'Restore ownership/capacity where work has no active coverage.',
                'sustained_queue_depth','staffing_pressure' => 'Reduce queue pressure and blocked or overdue work.',
                'sla_breach_rate' => 'Increase capacity where service deadlines are being missed.',
                'division_manager_required' => 'Restore management span and review/escalation coverage.',
                default => 'Improve responsibility coverage for the current business profile.',
            };
            return $r + ['expected_benefit'=>$benefit,'provider_requirements'=>$providers,'approval_required'=>true,'auto_hire'=>false,'authority_inherited'=>false];
        }, $recommendations);

        $existingProposals = WorkforceStaffingProposal::query()->forCompany($companyId)->orderByDesc('recommended_at')->limit(100)->get();

        return [
            'company_id'=>$companyId,
            'overloaded_teams'=>$overloadedTeams,
            'underused_staff'=>$underused,
            'responsibility_gaps'=>$responsibilityGaps,
            'capability_gaps'=>$capabilityGaps,
            'manager_span'=>$managerSpan,
            'bottlenecks'=>$bottlenecks,
            'upcoming_workload'=>$upcomingWorkload,
            'proposed_roles'=>$proposedRoles,
            'existing_proposals'=>$existingProposals,
            'expected_benefit'=>collect($proposedRoles)->pluck('expected_benefit')->unique()->values()->all(),
            'provider_requirements'=>collect($proposedRoles)->flatMap(fn(array $r)=>$r['provider_requirements'])->unique()->sort()->values()->all(),
            'auto_hire' => false,
            'approval_required' => true,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }
}
