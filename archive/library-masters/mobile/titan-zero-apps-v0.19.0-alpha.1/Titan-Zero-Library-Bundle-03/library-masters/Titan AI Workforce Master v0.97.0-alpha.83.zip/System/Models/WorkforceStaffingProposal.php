<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

class WorkforceStaffingProposal extends Model
{
    protected $table = 'ext_titan_ai_workforce_staffing_proposals';
    protected $guarded = [];
    protected $casts = [
        'metrics' => 'array',
        'metadata' => 'array',
        'recommended_at' => 'datetime',
        'reviewed_at' => 'datetime',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
