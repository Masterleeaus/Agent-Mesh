<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskDependency;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use InvalidArgumentException;

final class WorkforceWorkCommandCenterService
{
    private const TERMINAL = ['COMPLETED','FAILED','CANCELLED','REJECTED'];
    private const REVIEW = ['SUBMITTED','UNDER_REVIEW','RECEIVER_REVIEW','REVISION_REQUIRED'];

    public function __construct(private readonly QueuePriorityService $priority) {}

    public function index(int $companyId, string $view, ?string $status = null): array
    {
        $view = in_array($view, ['list','kanban','timeline','dependencies','review','handoffs','escalations','recovery'], true) ? $view : 'list';
        $base = WorkforceTask::query()->forCompany($companyId)->with(['assignee','manager','division','team','parent'])->latest('last_activity_at');
        if ($status) { $base->where('status', $status); }
        /** @var LengthAwarePaginator $tasks */
        $tasks = $base->paginate(60)->withQueryString();
        $tasks->getCollection()->transform(function (WorkforceTask $task): WorkforceTask {
            $task->queue_score = $this->priority->score($task);
            return $task;
        });

        $allOpen = WorkforceTask::query()->forCompany($companyId)->with(['assignee','manager','division','team'])
            ->whereNotIn('status', self::TERMINAL)->latest('last_activity_at')->limit(500)->get();
        $dependencyRows = WorkforceTaskDependency::query()->forCompany($companyId)
            ->with(['task','dependsOn'])->latest()->limit(500)->get();
        $handoffs = WorkforceTaskHandoff::query()->forCompany($companyId)->latest()->limit(200)->get();
        $escalations = WorkforceEscalation::query()->forCompany($companyId)->latest()->limit(200)->get();

        return [
            'company_id' => $companyId,
            'view' => $view,
            'tasks' => $tasks,
            'open_tasks' => $allOpen,
            'kanban' => $allOpen->groupBy(fn ($task) => (string) ($task->status?->value ?? $task->status)),
            'timeline' => $allOpen->sortBy(fn ($task) => optional($task->deadline_at ?? $task->scheduled_at ?? $task->last_activity_at ?? $task->updated_at)->timestamp ?? PHP_INT_MAX)->values(),
            'dependencies' => $dependencyRows,
            'review_queue' => $allOpen->filter(fn ($task) => in_array((string) ($task->status?->value ?? $task->status), self::REVIEW, true))->values(),
            'handoffs' => $handoffs,
            'escalations' => $escalations,
            'recovery' => $allOpen->filter(fn ($task) => in_array((string) ($task->status?->value ?? $task->status), ['RECOVERY','FAILED','BLOCKED'], true))->values(),
            'summary' => [
                'open' => $allOpen->count(),
                'review' => $allOpen->filter(fn ($task) => in_array((string) ($task->status?->value ?? $task->status), self::REVIEW, true))->count(),
                'blocked' => $allOpen->whereIn('status', ['BLOCKED','AWAITING_DATA'])->count(),
                'handoffs' => $handoffs->filter(fn ($row) => ! in_array((string) ($row->status?->value ?? $row->status), ['ACCEPTED','REJECTED','CANCELLED'], true))->count(),
                'escalations' => $escalations->where('status', 'OPEN')->count(),
                'recovery' => $allOpen->where('status', 'RECOVERY')->count(),
            ],
            'authority_inherited' => false,
        ];
    }

    public function task(int $companyId, WorkforceTask $task): array
    {
        if ((int) $task->company_id !== $companyId) { throw new InvalidArgumentException('Task is outside the active company boundary.'); }
        $task->load(['assignee','manager','division','team','parent','children','history','handoffs','executionAttempts','journeyRecords']);
        $dependencies = WorkforceTaskDependency::query()->forCompany($companyId)->where('task_id', $task->id)->with('dependsOn')->get();
        $dependents = WorkforceTaskDependency::query()->forCompany($companyId)->where('depends_on_task_id', $task->id)->with('task')->get();
        $evidence = WorkforceEvidence::query()->forCompany($companyId)->where('task_id', $task->id)->latest('observed_at')->get();
        $escalations = WorkforceEscalation::query()->forCompany($companyId)->where('task_id', $task->id)->latest()->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)->where('task_id', $task->id)->latest('observed_at')->get();
        $history = $task->history->sortByDesc('created_at')->values();
        $reviews = $history->filter(fn ($row) => str_contains((string) $row->event, 'review') || in_array((string) $row->to_status, ['UNDER_REVIEW','APPROVED','REJECTED','REVISION_REQUIRED','RECEIVER_REVIEW','ACCEPTED'], true))->values();
        $capabilities = collect(array_filter(array_unique(array_merge(
            [(string) ($task->capability ?? '')],
            array_map('strval', (array) data_get($task->metadata ?? [], 'required_capabilities', [])),
            array_map('strval', (array) data_get($task->payload ?? [], 'required_capabilities', []))
        ))))->values();

        return [
            'company_id' => $companyId,
            'task' => $task,
            'owner' => $task->assignee,
            'manager' => $task->manager,
            'responsibility' => data_get($task->metadata ?? [], 'responsibility_key') ?? data_get($task->payload ?? [], 'responsibility_key') ?? data_get($task->metadata ?? [], 'responsibility_id'),
            'parent' => $task->parent,
            'children' => $task->children,
            'dependencies' => $dependencies,
            'dependents' => $dependents,
            'evidence' => $evidence,
            'reviews' => $reviews,
            'capability_requirements' => $capabilities,
            'governance_state' => [
                'governance' => $task->governance,
                'risk' => $task->risk_snapshot,
                'assurance' => $task->assurance_snapshot,
                'autonomy' => $task->autonomy_snapshot,
            ],
            'execution_attempts' => $task->executionAttempts->sortByDesc('created_at')->values(),
            'receipts' => $task->executionAttempts->filter(fn ($attempt) => ! empty($attempt->receipt) || ! empty($attempt->receipt_ref))->values(),
            'outcomes' => $outcomes,
            'journey' => $task->journeyRecords->sortBy('observed_at')->values(),
            'history' => $history,
            'handoffs' => $task->handoffs,
            'escalations' => $escalations,
            'authority_inherited' => false,
        ];
    }
}
