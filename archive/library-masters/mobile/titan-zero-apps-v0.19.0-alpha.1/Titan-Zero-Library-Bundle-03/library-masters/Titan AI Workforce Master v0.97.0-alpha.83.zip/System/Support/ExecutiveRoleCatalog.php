<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class ExecutiveRoleCatalog
{
    public const BUSINESS_MANAGER_ROLE_DEFINITION_ID = 'titan.executive.business_manager';

    /** @var array<int,array<string,mixed>>|null */
    private static ?array $definitions = null;

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        if (self::$definitions !== null) return self::$definitions;
        $path = dirname(__DIR__, 2) . '/resources/workforce/executive-role-definitions.json';
        if (! is_file($path)) throw new RuntimeException('Executive Workforce role catalogue is missing.');
        $rows = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($rows) || count($rows) !== 1 || ! is_array($rows[0] ?? null)) throw new RuntimeException('Executive Workforce role catalogue is invalid.');
        if (($rows[0]['role_definition_id'] ?? null) !== self::BUSINESS_MANAGER_ROLE_DEFINITION_ID) throw new RuntimeException('AI Business Manager role identity drift detected.');
        foreach (['risk','assurance','governance','autonomy'] as $engine) {
            if (($rows[0]['bypass'][$engine] ?? null) !== false) throw new RuntimeException("AI Business Manager may not bypass {$engine}.");
        }
        if (($rows[0]['executable_capabilities'] ?? null) !== []) throw new RuntimeException('AI Business Manager may not carry domain executable capabilities in Step 6.');
        return self::$definitions = array_values($rows);
    }

    /** @return array<string,mixed>|null */
    public function find(string $keyOrDefinitionId): ?array
    {
        foreach ($this->all() as $definition) {
            if (($definition['key'] ?? null) === $keyOrDefinitionId || ($definition['role_definition_id'] ?? null) === $keyOrDefinitionId) return $definition;
            if (in_array($keyOrDefinitionId, $definition['aliases'] ?? [], true)) return $definition;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public function runtimeRoles(): array
    {
        return array_map(static function (array $definition): array {
            $role = $definition;
            $role['role_id'] = (string) $definition['role_definition_id'];
            $role['division'] = '';
            $role['team'] = (string) ($definition['team_key'] ?? 'executive-management');
            $role['parent_manager'] = (string) $definition['reports_to_role_definition_id'];
            $role['reports_to'] = (string) $definition['reports_to_role_definition_id'];
            $role['skills'] = array_values(array_map('strval', $definition['recommended_skills'] ?? []));
            $role['capabilities'] = [];
            $role['capability_variants'] = [];
            $role['tools'] = [];
            $role['tool_access'] = [];
            $role['playbooks'] = [];
            $role['interaction_wizards'] = [];
            $role['knowledge_scopes'] = ['organisation:company'];
            $role['memory_scopes'] = ['organisation:company'];
            $role['activation'] = ['min_tier'=>'SOLO','max_tier'=>'ENTERPRISE','verticals'=>['all']];
            $role['autonomy_profile'] = ['starting_level'=>'Suggest','starting_score'=>0,'desired_level'=>'Suggest','desired_score'=>0,'authority_source'=>'titan_autonomy','self_promotion'=>false];
            $role['owner_extension'] = 'titan-ai-workforce';
            $role['owner_extension_version'] = 'intrinsic-executive';
            $role['definition_fingerprint'] = hash('sha256', json_encode($definition, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
            $role['definition_schema_version'] = 'executive-v1';
            $role['definition_source'] = 'intrinsic_executive_catalogue';
            return $role;
        }, $this->all());
    }
}
