<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceHandoffStatus;
use Illuminate\Database\Eloquent\Model;
use LogicException;

class WorkforceTaskHandoff extends Model
{
    protected $table = 'ext_titan_ai_workforce_handoffs';
    protected $guarded = [];
    protected $casts = [
        'status' => WorkforceHandoffStatus::class,
        'evidence' => 'array',
        'metadata' => 'array',
        'packet' => 'array',
        'packet_version' => 'integer',
        'decision_version' => 'integer',
        'reviewed_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::updating(function (self $handoff): void {
            foreach ($handoff->immutablePacketFields() as $field) {
                if ($handoff->isDirty($field) && $handoff->getOriginal($field) !== null) {
                    throw new LogicException('Immutable Workforce handoff packet cannot be modified after creation.');
                }
            }
        });
    }

    public function immutablePacketFields(): array
    {
        return [
            'company_id','task_id','origin_member_id','origin_manager_id',
            'receiving_division_id','receiving_manager_id','receiving_specialist_id',
            'packet_version','packet_sha256','packet','trace_id','correlation_id','causation_id',
        ];
    }

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
