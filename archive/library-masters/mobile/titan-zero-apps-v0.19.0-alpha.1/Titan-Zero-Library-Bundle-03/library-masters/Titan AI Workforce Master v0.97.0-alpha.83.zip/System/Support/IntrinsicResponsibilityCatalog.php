<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class IntrinsicResponsibilityCatalog
{
    /** @var array<int,array<string,mixed>>|null */
    private static ?array $definitions = null;
    /** @var array<int,array<string,mixed>>|null */
    private static ?array $assignments = null;

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        if (self::$definitions !== null) return self::$definitions;
        self::$definitions = $this->load('responsibility-definitions.json', 'Intrinsic Workforce responsibility catalogue');
        return self::$definitions;
    }

    /** @return list<array<string,mixed>> */
    public function assignments(): array
    {
        if (self::$assignments !== null) return self::$assignments;
        self::$assignments = $this->load('role-responsibility-assignments.json', 'Intrinsic Workforce role-responsibility assignments');
        return self::$assignments;
    }

    /** @return array<string,mixed>|null */
    public function find(string $keyOrDefinitionId): ?array
    {
        foreach ($this->all() as $definition) {
            if (($definition['key'] ?? null) === $keyOrDefinitionId || ($definition['responsibility_id'] ?? null) === $keyOrDefinitionId) return $definition;
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public function forRole(string $keyOrRoleDefinitionId): array
    {
        $role = (new IntrinsicRoleCatalog())->find($keyOrRoleDefinitionId);
        if (! $role) return [];
        $roleId = (string) $role['role_definition_id'];
        $wanted = [];
        foreach ($this->assignmentsForRole($roleId) as $assignment) $wanted[(string) $assignment['responsibility_id']] = true;
        return array_values(array_filter($this->all(), static fn (array $definition): bool => isset($wanted[(string) ($definition['responsibility_id'] ?? '')])));
    }

    /** @return list<array<string,mixed>> */
    public function assignmentsForRole(string $keyOrRoleDefinitionId): array
    {
        $role = (new IntrinsicRoleCatalog())->find($keyOrRoleDefinitionId);
        $roleId = $role ? (string) $role['role_definition_id'] : $keyOrRoleDefinitionId;
        return array_values(array_filter($this->assignments(), static fn (array $assignment): bool => (string) ($assignment['role_definition_id'] ?? '') === $roleId));
    }

    /** @return list<array<string,mixed>> */
    private function load(string $filename, string $label): array
    {
        $path = dirname(__DIR__, 2) . '/resources/workforce/' . $filename;
        if (! is_file($path)) throw new RuntimeException($label . ' is missing.');
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)) throw new RuntimeException($label . ' must be an array.');
        return array_values($decoded);
    }
}
