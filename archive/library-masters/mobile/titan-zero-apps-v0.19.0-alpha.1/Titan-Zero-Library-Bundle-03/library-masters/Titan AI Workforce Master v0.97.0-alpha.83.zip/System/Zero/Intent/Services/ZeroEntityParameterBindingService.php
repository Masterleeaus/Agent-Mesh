<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Services;
use DateTimeImmutable;
final class ZeroEntityParameterBindingService
{
 public function bind(string $utterance,array $authoritativeContext,?DateTimeImmutable $now=null): array
 {
  $now??=new DateTimeImmutable('now');$u=strtolower($utterance);$entities=[];$params=['rate'=>null];$ambiguities=[];$missing=[];
  $customers=array_values(array_filter($authoritativeContext['customer']??[],fn($c)=>is_array($c)&&isset($c['ref'])));
  if(count($customers)===1)$entities['customer']=$customers[0]; elseif(count($customers)>1){$ambiguities['customer']=$customers;$missing[]='customer';}
  if(str_contains($u,'usual rate')||str_contains($u,'normal rate')||str_contains($u,'same price')){
   $rates=$authoritativeContext['historical_rate']??[];$customerRef=$entities['customer']['ref']??null;
   $matches=array_values(array_filter($rates,fn($r)=>is_array($r)&&($customerRef===null||($r['customer_ref']??null)===$customerRef)&&isset($r['amount'])));
   if(count($matches)===1)$params['rate']=['amount'=>$matches[0]['amount'],'currency'=>$matches[0]['currency']??null,'source'=>'authoritative_history']; else $missing[]='rate';
  }
  if(preg_match('/\bnext\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/',$u,$m)){$params['date']=$this->nextWeekday($now,$m[1])->format('Y-m-d');}
  elseif(preg_match('/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/',$u,$m)){$params['date']=$this->nextWeekday($now,$m[1])->format('Y-m-d');}
  if(preg_match('/\b(available|free|availability|someone)\b/',$u)){
   $date=$params['date']??null;$workers=[];foreach($authoritativeContext['availability']??[] as $a)if(is_array($a)&&isset($a['worker_ref'])&&($date===null||($a['date']??null)===$date))$workers[]=['ref'=>$a['worker_ref'],'label'=>$a['label']??null,'date'=>$a['date']??null];
   $params['available_workers']=$workers;if($workers===[])$missing[]='available_workers';
  }
  return ['schema'=>'titan.zero.entity-parameter-binding.v1','entities'=>$entities,'parameters'=>$params,'ambiguities'=>$ambiguities,'missing_parameters'=>array_values(array_unique($missing)),'requires_clarification'=>$ambiguities!==[],'invented_values'=>false,'safety'=>['authoritative_context_only'=>true,'grants_authority'=>false,'executes_mutations'=>false]];
 }
 private function nextWeekday(DateTimeImmutable $now,string $weekday): DateTimeImmutable { $candidate=$now->modify('next '.$weekday); return $candidate; }
}
