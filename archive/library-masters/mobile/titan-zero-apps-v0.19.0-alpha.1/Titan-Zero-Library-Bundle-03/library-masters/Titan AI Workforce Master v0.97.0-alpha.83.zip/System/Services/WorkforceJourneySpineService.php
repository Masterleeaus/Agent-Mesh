<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceJourneyRecord;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Throwable;

/**
 * Append-only structured evidence spine for Signal + Rewind reconstruction.
 * Private/hidden reasoning is deliberately filtered and never persisted.
 */
final class WorkforceJourneySpineService
{
    private const FORBIDDEN_PRIVATE_KEYS = [
        'chain_of_thought', 'hidden_reasoning', 'private_reasoning', 'cot',
        'internal_monologue', 'scratchpad', 'raw_reasoning',
    ];

    public function __construct(private readonly WorkforceSignalBridge $signals) {}

    public function recordTaskLifecycle(
        WorkforceTask $task,
        ?WorkforceMember $actor,
        string $event,
        ?string $from,
        ?string $to,
        ?string $reason,
        array $context = [],
    ): WorkforceJourneyRecord {
        $summary = $this->sanitizeStructured([
            'task_uuid' => (string) $task->task_uuid,
            'capability' => $task->capability,
            'actor_member_id' => $actor?->id,
            'from_status' => $from,
            'to_status' => $to,
            'reason_code' => $context['reason_code'] ?? null,
            'reason_summary' => $reason,
            'context' => $context,
        ]);

        return $this->record([
            'company_id' => (int) $task->company_id,
            'task_id' => (int) $task->id,
            'member_id' => $actor?->id,
            'category' => $this->categoryFor($event),
            'phase' => $this->phaseFor($event),
            'event_type' => 'workforce.'.$event,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => $task->causation_id ? (string) $task->causation_id : null,
            'source_ref' => (string) $task->task_uuid,
            'rationale_refs' => $this->rationaleRefs($task, $context),
            'evidence_refs' => $this->evidenceRefs($task, $context),
            'decision_refs' => $this->decisionRefs($task, $context),
            'execution_refs' => $this->executionRefs($task, $context),
            'outcome_refs' => $this->outcomeRefs($task, $context),
            'summary' => $summary,
        ]);
    }

    public function recordStaffingLifecycle(WorkforceStaffingProposal $proposal, string $event, array $payload = []): WorkforceJourneyRecord
    {
        return $this->record([
            'company_id' => (int) $proposal->company_id,
            'task_id' => null,
            'member_id' => null,
            'category' => 'STAFFING',
            'phase' => 'ORGANISATION',
            'event_type' => 'workforce.'.$event,
            'trace_id' => (string) $proposal->trace_id,
            'correlation_id' => (string) $proposal->correlation_id,
            'causation_id' => $proposal->causation_id ? (string) $proposal->causation_id : null,
            'source_ref' => (string) $proposal->proposal_uuid,
            'rationale_refs' => array_values(array_filter([(string) ($proposal->review_reason ?? '')])),
            'evidence_refs' => [],
            'decision_refs' => array_values(array_filter([(string) ($proposal->status ?? '')])),
            'execution_refs' => [],
            'outcome_refs' => [],
            'summary' => $this->sanitizeStructured($payload),
        ]);
    }

    public function recordExecutionLifecycle(WorkforceTask $task, WorkforceMember $actor, string $event, array $refs = [], array $payload = []): WorkforceJourneyRecord
    {
        return $this->record([
            'company_id' => (int) $task->company_id,
            'task_id' => (int) $task->id,
            'member_id' => (int) $actor->id,
            'category' => 'EXECUTION',
            'phase' => 'EXECUTION',
            'event_type' => 'workforce.'.$event,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => $task->causation_id ? (string) $task->causation_id : null,
            'source_ref' => (string) $task->task_uuid,
            'rationale_refs' => array_values(array_filter((array) ($refs['rationale_refs'] ?? []))),
            'evidence_refs' => array_values(array_filter((array) ($refs['evidence_refs'] ?? []))),
            'decision_refs' => array_values(array_filter((array) ($refs['decision_refs'] ?? []))),
            'execution_refs' => array_values(array_filter((array) ($refs['execution_refs'] ?? []))),
            'outcome_refs' => array_values(array_filter((array) ($refs['outcome_refs'] ?? []))),
            'summary' => $this->sanitizeStructured($payload),
        ]);
    }

    public function recordVerifiedOutcome(WorkforceTask $task, WorkforceMember $actor, array $outcome): WorkforceJourneyRecord
    {
        $outcome = $this->sanitizeStructured($outcome);
        $refs = array_values(array_unique(array_filter([
            $outcome['outcome_ref'] ?? null,
            $outcome['verification_ref'] ?? null,
            $outcome['domain_state_ref'] ?? null,
        ])));

        return $this->record([
            'company_id' => (int) $task->company_id,
            'task_id' => (int) $task->id,
            'member_id' => (int) $actor->id,
            'category' => 'OUTCOME',
            'phase' => 'OUTCOME',
            'event_type' => 'workforce.outcome.verified',
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'causation_id' => $task->causation_id ? (string) $task->causation_id : null,
            'source_ref' => (string) $task->task_uuid,
            'rationale_refs' => [],
            'evidence_refs' => array_values(array_unique(array_filter((array) ($outcome['evidence_refs'] ?? [])))),
            'decision_refs' => array_values(array_unique(array_filter((array) ($outcome['decision_refs'] ?? [])))),
            'execution_refs' => array_values(array_unique(array_filter((array) ($outcome['execution_refs'] ?? [])))),
            'outcome_refs' => $refs,
            'summary' => $outcome,
        ]);
    }

    public function journeyForTask(WorkforceTask $task): Collection
    {
        return WorkforceJourneyRecord::query()
            ->forCompany((int) $task->company_id)
            ->where(function ($query) use ($task) {
                $query->where('correlation_id', (string) $task->correlation_id)
                    ->orWhere('trace_id', (string) $task->trace_id)
                    ->orWhere('task_id', (int) $task->id);
            })
            ->orderBy('observed_at')
            ->orderBy('id')
            ->get();
    }

    private function record(array $data): WorkforceJourneyRecord
    {
        $canonical = $this->canonicalize([
            'company_id' => $data['company_id'],
            'task_id' => $data['task_id'],
            'member_id' => $data['member_id'],
            'category' => $data['category'],
            'phase' => $data['phase'],
            'event_type' => $data['event_type'],
            'trace_id' => $data['trace_id'],
            'correlation_id' => $data['correlation_id'],
            'causation_id' => $data['causation_id'],
            'source_ref' => $data['source_ref'],
            'rationale_refs' => $this->sanitizeStructured($data['rationale_refs'] ?? []),
            'evidence_refs' => $this->sanitizeStructured($data['evidence_refs'] ?? []),
            'decision_refs' => $this->sanitizeStructured($data['decision_refs'] ?? []),
            'execution_refs' => $this->sanitizeStructured($data['execution_refs'] ?? []),
            'outcome_refs' => $this->sanitizeStructured($data['outcome_refs'] ?? []),
            'summary' => $this->sanitizeStructured($data['summary'] ?? []),
        ]);
        $hash = hash('sha256', json_encode($canonical, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
        $record = WorkforceJourneyRecord::query()->create(array_merge($canonical, [
            'event_uuid' => (string) Str::uuid(),
            'event_sha256' => $hash,
            'observed_at' => now(),
        ]));

        $signalPayload = [
            'journey_event_uuid' => $record->event_uuid,
            'journey_event_sha256' => $hash,
            'task_id' => $canonical['source_ref'],
            'member_id' => $canonical['member_id'],
            'category' => $canonical['category'],
            'phase' => $canonical['phase'],
            'rationale_refs' => $canonical['rationale_refs'],
            'evidence_refs' => $canonical['evidence_refs'],
            'decision_refs' => $canonical['decision_refs'],
            'execution_refs' => $canonical['execution_refs'],
            'outcome_refs' => $canonical['outcome_refs'],
            'summary' => $canonical['summary'],
        ];
        $this->signals->emit(
            (int) $canonical['company_id'],
            (string) $canonical['event_type'],
            $signalPayload,
            (string) $canonical['trace_id'],
            (string) $canonical['correlation_id'],
            $canonical['causation_id'] ? (string) $canonical['causation_id'] : null,
        );
        $this->recordRewind($record, $signalPayload);
        return $record;
    }

    private function recordRewind(WorkforceJourneyRecord $record, array $payload): void
    {
        if (! app()->bound('titan.rewind')) return;
        $rewind = app('titan.rewind');
        foreach (['recordEvent','recordDecision','record','capture'] as $method) {
            if (! method_exists($rewind, $method)) continue;
            try {
                $rewind->{$method}([
                    'record_type' => 'workforce_journey_reference',
                    'journey_event_uuid' => (string) $record->event_uuid,
                    'event_sha256' => (string) $record->event_sha256,
                    'event_type' => (string) $record->event_type,
                    'company_id' => (int) $record->company_id,
                    'trace_id' => (string) $record->trace_id,
                    'correlation_id' => (string) $record->correlation_id,
                    'causation_id' => $record->causation_id ? (string) $record->causation_id : null,
                    'structured_refs' => $payload,
                    'private_reasoning_persisted' => false,
                ]);
            } catch (Throwable) {
                // Signal outbox remains the durable transport. Rewind is an external evidence consumer.
            }
            return;
        }
    }

    /** Remove any private hidden-reasoning fields recursively before persistence or transport. */
    public function sanitizeStructured(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        $out = [];
        foreach ($value as $key => $item) {
            if (is_string($key) && in_array(strtolower($key), self::FORBIDDEN_PRIVATE_KEYS, true)) continue;
            $out[$key] = $this->sanitizeStructured($item);
        }
        return $out;
    }

    private function rationaleRefs(WorkforceTask $task, array $context): array
    {
        return array_values(array_unique(array_filter(array_merge(
            (array) ($context['rationale_refs'] ?? []),
            [(string) data_get($task->governance ?? [], 'pre_execution.risk.decision_id', ''), (string) data_get($task->governance ?? [], 'pre_execution.assurance.decision_id', '')]
        ))));
    }

    private function evidenceRefs(WorkforceTask $task, array $context): array
    {
        return array_values(array_unique(array_filter(array_merge(
            (array) ($context['evidence_refs'] ?? []),
            array_values(array_filter([$context['handoff_packet_sha256'] ?? null])),
            (array) data_get($task->evidence ?? [], 'refs', []),
            (array) data_get($task->governance ?? [], 'pre_execution.evidence_refs', [])
        ))));
    }

    private function decisionRefs(WorkforceTask $task, array $context): array
    {
        return array_values(array_unique(array_filter(array_merge((array) ($context['decision_refs'] ?? []), [
            $context['decision_id'] ?? null,
            $context['handoff_id'] ?? null,
            data_get($task->risk_snapshot ?? [], 'decision_id'),
            data_get($task->assurance_snapshot ?? [], 'decision_id'),
            data_get($task->autonomy_snapshot ?? [], 'decision_id'),
            data_get($task->governance ?? [], 'pre_execution.model_council.decision_id'),
        ]))));
    }

    private function executionRefs(WorkforceTask $task, array $context): array
    {
        return array_values(array_unique(array_filter(array_merge((array) ($context['execution_refs'] ?? []), [
            $context['receiving_task_uuid'] ?? null,
            $context['attempt_uuid'] ?? null,
            $context['receipt_ref'] ?? null,
            $context['verification_ref'] ?? null,
            data_get($task->result ?? [], 'attempt_uuid'),
            data_get($task->result ?? [], 'receipt.receipt_id'),
            data_get($task->result ?? [], 'verification.domain_state_ref'),
        ]))));
    }

    private function outcomeRefs(WorkforceTask $task, array $context): array
    {
        return array_values(array_unique(array_filter(array_merge((array) ($context['outcome_refs'] ?? []), [
            data_get($task->governance ?? [], 'post_execution.outcome_ref'),
            data_get($task->governance ?? [], 'post_execution.verification_ref'),
        ]))));
    }

    private function categoryFor(string $event): string
    {
        return match (true) {
            str_contains($event, 'handoff') => 'HANDOFF',
            str_contains($event, 'manager.') || str_contains($event, 'review') => 'REVIEW',
            str_contains($event, 'escalat') || str_contains($event, 'deadlock') || str_contains($event, 'dispute') => 'ESCALATION',
            str_contains($event, 'execution') => 'EXECUTION',
            default => 'TASK',
        };
    }

    private function phaseFor(string $event): string
    {
        if (str_contains($event, 'outcome')) return 'OUTCOME';
        if (str_contains($event, 'execution')) return 'EXECUTION';
        return 'DECISION';
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn ($item) => $this->canonicalize($item), $value);
        ksort($value);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }
}
