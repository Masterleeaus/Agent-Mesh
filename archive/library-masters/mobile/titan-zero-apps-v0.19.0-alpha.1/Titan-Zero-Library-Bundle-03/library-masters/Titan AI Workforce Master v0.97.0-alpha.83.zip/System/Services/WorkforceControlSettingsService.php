<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use Illuminate\Support\Facades\Cache;

/**
 * Company-scoped operator controls. These tune existing governance behaviour only.
 * They cannot create capability, bypass provider health, or raise an authority ceiling.
 */
final class WorkforceControlSettingsService
{
    private const DEFAULTS=[
        'notification_thresholds'=>['minimum_severity'=>'HIGH','deduplicate_minutes'=>30],
        'fallback_policy'=>['allow_approved_fallbacks'=>true,'require_equivalent_authority'=>true],
        'proactive_operations'=>['enabled'=>true,'max_generated_work_per_cycle'=>25],
        'review_policy'=>['manager_review_for_high_risk'=>true,'human_review_for_extreme_risk'=>true],
        'outcome_verification'=>['required'=>true,'late_after_minutes'=>30],
        'staffing_policy'=>['recommend_at_pressure_score'=>30,'auto_activate'=>false],
        'human_decision_policy'=>['required_for_authority_change'=>true,'required_for_policy_override'=>true],
        'authority_ceiling'=>['mode'=>'existing_assignments_only','may_raise'=>false],
    ];

    public function snapshot(int $companyId): array
    {
        return ['company_id'=>$companyId]+array_replace_recursive(self::DEFAULTS,(array)Cache::get($this->key($companyId),[]))+[
            'cannot_grant_capability'=>true,
            'cannot_raise_authority'=>true,
            'cannot_bypass_governance'=>true,
        ];
    }

    public function update(int $companyId,array $input): array
    {
        $current=$this->snapshot($companyId);
        $allowed=[
            'notification_thresholds'=>['minimum_severity'=>(string)data_get($input,'notification_thresholds.minimum_severity',$current['notification_thresholds']['minimum_severity']),'deduplicate_minutes'=>max(5,min(1440,(int)data_get($input,'notification_thresholds.deduplicate_minutes',$current['notification_thresholds']['deduplicate_minutes'])))],
            'fallback_policy'=>['allow_approved_fallbacks'=>(bool)data_get($input,'fallback_policy.allow_approved_fallbacks',false),'require_equivalent_authority'=>true],
            'proactive_operations'=>['enabled'=>(bool)data_get($input,'proactive_operations.enabled',false),'max_generated_work_per_cycle'=>max(1,min(100,(int)data_get($input,'proactive_operations.max_generated_work_per_cycle',25)))],
            'review_policy'=>['manager_review_for_high_risk'=>true,'human_review_for_extreme_risk'=>true],
            'outcome_verification'=>['required'=>true,'late_after_minutes'=>max(5,min(10080,(int)data_get($input,'outcome_verification.late_after_minutes',30)))],
            'staffing_policy'=>['recommend_at_pressure_score'=>max(1,min(100,(int)data_get($input,'staffing_policy.recommend_at_pressure_score',30))),'auto_activate'=>false],
            'human_decision_policy'=>['required_for_authority_change'=>true,'required_for_policy_override'=>true],
            'authority_ceiling'=>['mode'=>'existing_assignments_only','may_raise'=>false],
        ];
        Cache::forever($this->key($companyId),$allowed);
        return $this->snapshot($companyId);
    }

    private function key(int $companyId): string { return "titan-workforce:control-settings:company:{$companyId}"; }
}
