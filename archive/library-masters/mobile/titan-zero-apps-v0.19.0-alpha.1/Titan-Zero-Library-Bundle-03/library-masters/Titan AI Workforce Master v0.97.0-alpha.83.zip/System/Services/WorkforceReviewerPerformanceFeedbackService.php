<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforcePerformanceMetric;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerFeedback;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Str;

final class WorkforceReviewerPerformanceFeedbackService
{
    public function __construct(private readonly WorkforceMemberRatingService $ratings) {}

    /** @param array<string,mixed> $gate */
    public function recordFinalAuthorityGate(WorkforceDecisionChain $chain, WorkforceTask $task, array $gate): void
    {
        $allowed=(bool)($gate['allowed'] ?? false);
        $reasons=array_values((array)($gate['reason_codes'] ?? []));
        $riskDenied=in_array('RISK_GATE_DENIED_OR_UNAVAILABLE',$reasons,true);
        $governanceDenied=in_array('GOVERNANCE_DENIED_OR_INCOMPLETE',$reasons,true);

        foreach($this->reviewers($chain) as $checkpoint){
            $passed=(string)$checkpoint->status->value === 'PASSED';
            if(!$passed) continue;

            $missedRisk=(!$allowed && ($riskDenied || $governanceDenied));
            $score=$missedRisk ? 45.0 : ($allowed ? 88.0 : 68.0);
            $this->record($chain,$checkpoint,'FINAL_AUTHORITY_FEEDBACK',$score,[
                'judgement_score'=>$score,
                'risk_detection_score'=>$missedRisk?35.0:90.0,
                'evidence_quality_score'=>$this->evidenceScore($checkpoint),
                'missed_risk'=>$missedRisk,
                'verified_outcome'=>false,
                'evidence'=>[
                    'gate_uuid'=>$gate['gate_uuid'] ?? null,
                    'final_allowed'=>$allowed,
                    'reason_codes'=>$reasons,
                    'governance_allowed'=>$gate['governance_allowed'] ?? null,
                    'risk_allowed'=>$gate['risk_allowed'] ?? null,
                    'autonomy_allowed'=>$gate['autonomy_allowed'] ?? null,
                ],
            ]);
        }
    }

    /** @param array<string,mixed> $outcome */
    public function recordVerifiedOutcome(WorkforceTask $task,array $outcome): void
    {
        $processingId=trim((string)data_get($task->metadata ?? [],'processing_id',''));
        if($processingId==='') return;
        $chain=WorkforceDecisionChain::query()->forCompany((int)$task->company_id)
            ->where('processing_id',$processingId)->first();
        if(!$chain) return;

        $success=array_key_exists('outcome_success',$outcome) ? $outcome['outcome_success'] : null;
        if(!is_bool($success)) return;

        foreach($this->reviewers($chain) as $checkpoint){
            $status=(string)$checkpoint->status->value;
            if(!in_array($status,['PASSED','REJECTED'],true)) continue;
            $decisionSupported=($status==='PASSED' && $success) || ($status==='REJECTED' && !$success);
            $overturned=!$decisionSupported;
            $quality=$decisionSupported?96.0:30.0;

            $challenge=$this->challengeForCheckpoint($chain,$checkpoint);
            $escalationScore=85.0;
            $unnecessary=false;
            if($challenge){
                $challengeEscalated=$challenge->status==='ESCALATED';
                if($challengeEscalated && $decisionSupported){
                    $escalationScore=95.0;
                } elseif($challengeEscalated && !$decisionSupported){
                    $escalationScore=35.0;
                    $unnecessary=true;
                }
            }

            $evidenceScore=$this->evidenceScore($checkpoint);
            $composite=round($quality*.55+$evidenceScore*.20+$escalationScore*.15+$this->confidenceCalibrationScore($checkpoint,$success)*.10,2);

            $this->record($chain,$checkpoint,'VERIFIED_OUTCOME_FEEDBACK',$composite,[
                'judgement_score'=>$quality,
                'evidence_quality_score'=>$evidenceScore,
                'escalation_score'=>$escalationScore,
                'risk_detection_score'=>$decisionSupported?92.0:35.0,
                'verified_outcome'=>true,
                'overturned'=>$overturned,
                'unnecessary_escalation'=>$unnecessary,
                'evidence'=>[
                    'outcome_success'=>$success,
                    'outcome_ref'=>$outcome['outcome_ref'] ?? null,
                    'verification_ref'=>$outcome['verification_ref'] ?? $outcome['domain_state_ref'] ?? null,
                    'decision_status'=>$status,
                    'decision_supported'=>$decisionSupported,
                    'challenge_uuid'=>$challenge?->challenge_uuid,
                ],
            ]);
        }
    }

    public function recordChallengeResolution(WorkforceDecisionChallenge $challenge): void
    {
        $chain=WorkforceDecisionChain::query()->forCompany((int)$challenge->company_id)->find($challenge->decision_chain_id);
        if(!$chain) return;

        $challenger=WorkforceProcessingCheckpoint::query()->forCompany((int)$challenge->company_id)
            ->where('processing_id',$challenge->processing_id)->where('stage',$challenge->challenger_stage)->first();
        $challenged=WorkforceProcessingCheckpoint::query()->forCompany((int)$challenge->company_id)
            ->where('processing_id',$challenge->processing_id)->where('stage',$challenge->challenged_stage)->first();

        $outcome=(string)data_get($challenge->resolution ?? [],'outcome','');
        if($challenger && $challenger->reviewer_member_id){
            $accepted=$outcome==='REBUTTAL_ACCEPTED';
            $this->record($chain,$challenger,'CHALLENGE_RESOLUTION_FEEDBACK',$accepted?58.0:88.0,[
                'judgement_score'=>$accepted?55.0:90.0,
                'escalation_score'=>$accepted?50.0:90.0,
                'evidence_quality_score'=>$this->evidenceScore($challenger),
                'unnecessary_escalation'=>$accepted,
                'evidence'=>['challenge_uuid'=>$challenge->challenge_uuid,'outcome'=>$outcome],
            ]);
        }
        if($challenged && $challenged->reviewer_member_id && $outcome==='REBUTTAL_ACCEPTED'){
            $this->record($chain,$challenged,'SUCCESSFUL_REBUTTAL_FEEDBACK',86.0,[
                'judgement_score'=>88.0,
                'evidence_quality_score'=>$this->evidenceScore($challenged),
                'escalation_score'=>82.0,
                'evidence'=>['challenge_uuid'=>$challenge->challenge_uuid,'outcome'=>$outcome],
            ]);
        }
    }

    /** @return \Illuminate\Support\Collection<int,WorkforceProcessingCheckpoint> */
    private function reviewers(WorkforceDecisionChain $chain)
    {
        return WorkforceProcessingCheckpoint::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->whereNotNull('reviewer_member_id')->orderBy('stage')->get();
    }

    private function challengeForCheckpoint(WorkforceDecisionChain $chain,WorkforceProcessingCheckpoint $checkpoint): ?WorkforceDecisionChallenge
    {
        return WorkforceDecisionChallenge::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)
            ->where(function($q) use($checkpoint){
                $q->where('challenger_stage',$checkpoint->stage)->orWhere('challenged_stage',$checkpoint->stage);
            })->latest('id')->first();
    }

    private function evidenceScore(WorkforceProcessingCheckpoint $checkpoint): float
    {
        $decision=(array)($checkpoint->decision ?? []);
        $score=50.0;
        if(data_get($decision,'action_review_packet.packet_sha256')) $score+=15;
        if(data_get($decision,'knowledge_gap_receipt') || data_get($checkpoint->metadata ?? [],'knowledge_authority_receipt')) $score+=10;
        if(trim((string)($decision['reason'] ?? ''))!=='') $score+=10;
        if((array)($decision['evidence_refs'] ?? $decision['knowledge_evidence'] ?? [])!==[]) $score+=15;
        return min(100.0,$score);
    }

    private function confidenceCalibrationScore(WorkforceProcessingCheckpoint $checkpoint,bool $success): float
    {
        $confidence=(float)data_get($checkpoint->decision ?? [],'confidence',data_get($checkpoint->decision ?? [],'knowledge_confidence',75));
        $confidence=max(0,min(100,$confidence));
        $passed=(string)$checkpoint->status->value==='PASSED';
        $correct=($passed && $success) || (!$passed && !$success);
        return $correct ? min(100.0,70.0+$confidence*.30) : max(0.0,70.0-$confidence*.60);
    }

    /** @param array<string,mixed> $data */
    private function record(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        string $eventType,
        float $quality,
        array $data
    ): void {
        $memberId=(int)$checkpoint->reviewer_member_id;
        if($memberId<=0) return;

        WorkforceReviewerFeedback::query()->create([
            'feedback_uuid'=>(string)Str::uuid(),
            'company_id'=>(int)$chain->company_id,
            'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$chain->processing_id,
            'stage'=>(int)$checkpoint->stage,
            'reviewer_member_id'=>$memberId,
            'event_type'=>$eventType,
            'quality_score'=>max(0,min(100,$quality)),
            'evidence_quality_score'=>$data['evidence_quality_score'] ?? null,
            'judgement_score'=>$data['judgement_score'] ?? null,
            'escalation_score'=>$data['escalation_score'] ?? null,
            'risk_detection_score'=>$data['risk_detection_score'] ?? null,
            'verified_outcome'=>(bool)($data['verified_outcome'] ?? false),
            'overturned'=>(bool)($data['overturned'] ?? false),
            'missed_risk'=>(bool)($data['missed_risk'] ?? false),
            'unnecessary_escalation'=>(bool)($data['unnecessary_escalation'] ?? false),
            'evidence'=>$data['evidence'] ?? [],
            'observed_at'=>now(),
        ]);

        $this->syncMetrics((int)$chain->company_id,$memberId);
        $member=WorkforceMember::query()->forCompany((int)$chain->company_id)->find($memberId);
        if($member) $this->ratings->recalculate($member);
    }

    private function syncMetrics(int $companyId,int $memberId): void
    {
        $feedback=WorkforceReviewerFeedback::query()->forCompany($companyId)
            ->where('reviewer_member_id',$memberId)->latest('observed_at')->limit(100)->get();
        if($feedback->isEmpty()) return;

        $metrics=[
            'reviewer.decision_quality'=>$feedback->pluck('quality_score')->filter(fn($v)=>$v!==null),
            'reviewer.evidence_quality'=>$feedback->pluck('evidence_quality_score')->filter(fn($v)=>$v!==null),
            'reviewer.judgement'=>$feedback->pluck('judgement_score')->filter(fn($v)=>$v!==null),
            'reviewer.escalation_judgement'=>$feedback->pluck('escalation_score')->filter(fn($v)=>$v!==null),
            'reviewer.risk_detection'=>$feedback->pluck('risk_detection_score')->filter(fn($v)=>$v!==null),
        ];

        foreach($metrics as $key=>$values){
            if($values->isEmpty()) continue;
            $this->metric($companyId,$memberId,$key,(float)$values->avg(),$values->count(),$feedback);
        }

        $this->metric(
            $companyId,$memberId,'reviewer.overturn_avoidance',
            100.0-(100.0*$feedback->where('overturned',true)->count()/max(1,$feedback->count())),
            $feedback->count(),$feedback
        );
        $this->metric(
            $companyId,$memberId,'reviewer.missed_risk_avoidance',
            100.0-(100.0*$feedback->where('missed_risk',true)->count()/max(1,$feedback->count())),
            $feedback->count(),$feedback
        );
        $this->metric(
            $companyId,$memberId,'reviewer.escalation_efficiency',
            100.0-(100.0*$feedback->where('unnecessary_escalation',true)->count()/max(1,$feedback->count())),
            $feedback->count(),$feedback
        );
    }

    private function metric(int $companyId,int $memberId,string $key,float $value,int $sampleSize,$feedback): void
    {
        WorkforcePerformanceMetric::query()->create([
            'metric_uuid'=>(string)Str::uuid(),
            'company_id'=>$companyId,
            'member_id'=>$memberId,
            'metric_key'=>$key,
            'metric_value'=>round(max(0,min(100,$value)),4),
            'sample_size'=>$sampleSize,
            'period_start'=>$feedback->min('observed_at') ?? now(),
            'period_end'=>$feedback->max('observed_at') ?? now(),
            'context'=>[
                'source'=>'chain-of-command-reviewer-feedback',
                'feedback_rows'=>$feedback->count(),
                'verified_outcome_rows'=>$feedback->where('verified_outcome',true)->count(),
            ],
        ]);
    }

}
