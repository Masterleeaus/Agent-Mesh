<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceOrganisationPolicyRegistry;
use InvalidArgumentException;

/**
 * Extension-owned organisational decision rights.
 *
 * RACI does not confer execution authority. It only determines which instantiated
 * staff may prepare, account for, consult on, or be informed about a decision.
 * Risk, Assurance, Autonomy, Interaction and Command Bus remain separate gates.
 */
final class WorkforceDecisionRightsService
{
    public function __construct(private readonly WorkforceManifestRegistry $registry) {}

    /** @return list<array<string,mixed>> */
    public function all(): array
    {
        $canonical = array_map(static function (array $row): array {
            $row['source'] = $row['source'] ?? 'canonical_workforce_policy';
            $row['owner_extension'] = $row['owner_extension'] ?? 'titan-ai-workforce';
            $row['authority_inherited'] = false;
            $row['execution_authority_granted'] = false;
            return $row;
        }, WorkforceOrganisationPolicyRegistry::all()['decision_rights'] ?? []);

        return array_values(array_merge($canonical, $this->registry->decisionRights()));
    }

    public function decision(string $decision, ?string $ownerExtension = null): ?array
    {
        $matches = array_values(array_filter($this->all(), static function (array $row) use ($decision, $ownerExtension): bool {
            if ((string) ($row['decision'] ?? '') !== $decision) return false;
            return $ownerExtension === null || (string) ($row['owner_extension'] ?? '') === $ownerExtension;
        }));
        if ($matches === []) return null;
        if (count($matches) > 1) {
            throw new InvalidArgumentException('Decision right is ambiguous across extensions; owner_extension is required.');
        }
        return $matches[0];
    }

    /** Backwards-compatible alias for earlier central callers. */
    public function raci(string $decision, ?string $ownerExtension = null): ?array
    {
        return $this->decision($decision, $ownerExtension);
    }

    public function assertParticipant(WorkforceMember $member, string $decision, string $responsibility = 'responsible', ?string $ownerExtension = null): array
    {
        if (! in_array($responsibility, ['responsible','accountable','consulted','informed','reviewer','escalation_owner'], true)) {
            throw new InvalidArgumentException('Unknown RACI responsibility.');
        }
        $right = $this->decision($decision, $ownerExtension);
        if (! $right) throw new InvalidArgumentException('Unknown extension-owned Workforce decision right.');
        if (! $member->is_active) throw new InvalidArgumentException('Inactive staff cannot participate in an active Workforce decision.');
        if (in_array($responsibility, ['responsible','accountable','reviewer','escalation_owner'], true)
            && (string) $member->role_owner_extension !== (string) ($right['owner_extension'] ?? '')) {
            throw new InvalidArgumentException('RACI participant belongs to the wrong owning extension.');
        }
        if (! in_array((string) $member->role_definition_id, array_map('strval', $right[$responsibility] ?? []), true)) {
            throw new InvalidArgumentException("Staff RoleDefinition is not {$responsibility} for this decision.");
        }
        return $right;
    }

    public function resolveAccountableMember(int $companyId, string $decision, ?string $ownerExtension = null): ?WorkforceMember
    {
        $right = $this->decision($decision, $ownerExtension);
        if (! $right) return null;
        $roleId = (string) (($right['accountable'][0] ?? '') ?: '');
        if ($roleId === '') return null;
        return WorkforceMember::query()->forCompany($companyId)
            ->where('role_owner_extension', (string) $right['owner_extension'])
            ->where('role_definition_id', $roleId)
            ->where('is_active', true)
            ->orderBy('id')
            ->first();
    }


    public function resolveReviewerMember(int $companyId, string $decision, ?string $ownerExtension = null): ?WorkforceMember
    {
        return $this->resolveFirstRoleMember($companyId, $decision, 'reviewer', $ownerExtension);
    }

    public function resolveEscalationOwnerMember(int $companyId, string $decision, ?string $ownerExtension = null): ?WorkforceMember
    {
        return $this->resolveFirstRoleMember($companyId, $decision, 'escalation_owner', $ownerExtension);
    }

    private function resolveFirstRoleMember(int $companyId, string $decision, string $field, ?string $ownerExtension = null): ?WorkforceMember
    {
        $right = $this->decision($decision, $ownerExtension);
        if (! $right) return null;
        $roleId = (string) (($right[$field][0] ?? '') ?: '');
        if ($roleId === '') return null;
        return WorkforceMember::query()->forCompany($companyId)
            ->where('role_definition_id', $roleId)
            ->where('is_active', true)
            ->orderBy('id')
            ->first();
    }

    /** Legacy compatibility only; new disputes use graph-based escalation. */
    public function dispute(string $conflict): ?array
    {
        return WorkforceOrganisationPolicyRegistry::disputeRoute($conflict);
    }
}
