<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncil;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncilMembership;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceOrganisationPolicyRegistry;
use Illuminate\Support\Collection;
use InvalidArgumentException;

/**
 * Company-scoped operational projection for Workforce councils.
 * Councils deliberate and recommend. They never grant executable capability or authority.
 */
final class WorkforceCouncilOperationsService
{
    public function __construct(private readonly WorkforceTaskService $tasks) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $templates = $this->templates();
        $councils = WorkforceCouncil::query()->forCompany($companyId)->orderBy('name')->get();
        $memberships = WorkforceCouncilMembership::query()->forCompany($companyId)
            ->whereIn('council_id', $councils->pluck('id'))->where('is_active', true)->get()->groupBy('council_id');
        $memberIds = $memberships->flatten()->pluck('member_id')->filter()->map(fn ($id): int => (int) $id)->unique();
        $members = WorkforceMember::query()->forCompany($companyId)->whereIn('id', $memberIds)->get()->keyBy('id');

        return [
            'templates' => $templates,
            'councils' => $councils->map(fn (WorkforceCouncil $council): array => $this->row(
                $companyId,
                $council,
                $memberships->get($council->id, collect()),
                $members
            ))->values(),
            'authority_boundary' => [
                'authority_inherited' => false,
                'execution_authority_granted' => false,
                'note' => 'Council participation, recommendation and final-decision records are organisational evidence only. Consequential follow-up work requires its own capability, Risk, Assurance, Governance and Autonomy authorization.',
            ],
        ];
    }

    /** @return array<string,mixed> */
    public function detail(int $companyId, int $councilId): array
    {
        $council = WorkforceCouncil::query()->forCompany($companyId)->findOrFail($councilId);
        $memberships = WorkforceCouncilMembership::query()->forCompany($companyId)
            ->where('council_id', $council->id)->where('is_active', true)->get();
        $memberIds = $memberships->pluck('member_id')->filter()->map(fn ($id): int => (int) $id)->unique();
        $members = WorkforceMember::query()->forCompany($companyId)->whereIn('id', $memberIds)->get()->keyBy('id');
        $row = $this->row($companyId, $council, $memberships, $members);

        $sessionTasks = WorkforceTask::query()->forCompany($companyId)
            ->where('origin_type', 'workforce_council')
            ->where('origin_id', 'like', $council->key.':%')
            ->latest()->limit(100)->get();
        $followUpTasks = WorkforceTask::query()->forCompany($companyId)
            ->where('origin_type', 'workforce_council_followup')
            ->where('origin_id', 'like', $council->key.':%')
            ->latest()->limit(200)->get();

        return [
            ...$row,
            'session_tasks' => $sessionTasks,
            'follow_up_work_items' => $followUpTasks,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @param array<string,mixed> $data */
    public function recordDecisionUpdate(int $companyId, int $councilId, array $data, ?WorkforceMember $actor = null): WorkforceCouncil
    {
        $council = WorkforceCouncil::query()->forCompany($companyId)->findOrFail($councilId);
        $metadata = (array) ($council->metadata ?? []);
        $session = (array) data_get($metadata, 'current_session', []);
        $audit = array_values((array) data_get($metadata, 'audit_history', []));
        if ($actor) {
            $membership = WorkforceCouncilMembership::query()->forCompany($companyId)
                ->where('council_id', $council->id)->where('member_id', $actor->id)->where('is_active', true)->first();
            if (! $membership) throw new InvalidArgumentException('Only an active council participant may record deliberation.');
            $chairOnly = trim((string) ($data['final_decision'] ?? '')) !== '' || array_values(array_filter(array_map('trim', (array) ($data['follow_up_titles'] ?? [])))) !== [];
            if ($chairOnly && strtoupper((string) $membership->participation_type) !== 'CHAIR') {
                throw new InvalidArgumentException('Only the council chair may record a final decision or create follow-up Work Items.');
            }
        }

        foreach (['issue','recommendation','final_decision'] as $field) {
            if (array_key_exists($field, $data) && $data[$field] !== null && trim((string) $data[$field]) !== '') {
                $session[$field] = trim((string) $data[$field]);
                $audit[] = $this->audit($field.'.recorded', $actor, ['value' => $session[$field]]);
            }
        }
        foreach (['evidence','proposals','dissent'] as $field) {
            $value = trim((string) ($data[$field] ?? ''));
            if ($value === '') continue;
            $session[$field] = array_values((array) ($session[$field] ?? []));
            $session[$field][] = [
                'text' => $value,
                'recorded_at' => now()->toIso8601String(),
                'member_id' => $actor?->id,
            ];
            $audit[] = $this->audit($field.'.recorded', $actor, ['text' => $value]);
        }

        $followUps = array_values(array_filter(array_map('trim', (array) ($data['follow_up_titles'] ?? []))));
        if ($followUps !== []) {
            $chair = $this->chairMember($companyId, $council);
            if (! $chair) throw new InvalidArgumentException('Council chair must be active before follow-up work can be created.');
            $sessionKey = (string) ($session['session_key'] ?? ('manual-'.now()->format('YmdHis')));
            $created = array_values((array) ($session['follow_up_work_items'] ?? []));
            foreach ($followUps as $index => $title) {
                $task = $this->tasks->create($companyId, [
                    'division_id' => $chair->division_id,
                    'team_id' => $chair->team_id,
                    'assignee_member_id' => $chair->id,
                    'manager_member_id' => $chair->manager_id,
                    'origin_type' => 'workforce_council_followup',
                    'origin_id' => $council->key.':'.$sessionKey.':'.($index + 1),
                    'title' => $title,
                    'description' => 'Governed follow-up Work Item created from '.$council->name.'.',
                    'priority' => 70,
                    'risk_level' => 'LOW',
                    'payload' => [
                        'council_id' => $council->id,
                        'council_key' => $council->key,
                        'issue' => $session['issue'] ?? null,
                        'recommendation' => $session['recommendation'] ?? null,
                        'final_decision' => $session['final_decision'] ?? null,
                    ],
                    'idempotency_key' => 'council-followup:'.$companyId.':'.$council->id.':'.$sessionKey.':'.sha1($title),
                    'metadata' => [
                        'governed_coordination_only' => true,
                        'requires_fresh_execution_authorization' => true,
                        'authority_inherited' => false,
                        'execution_authority_granted' => false,
                    ],
                ], $chair);
                $created[] = ['task_id' => $task->id, 'task_uuid' => $task->task_uuid, 'title' => $task->title];
                $audit[] = $this->audit('follow_up_work_item.created', $actor, ['task_id' => $task->id, 'title' => $task->title]);
            }
            $session['follow_up_work_items'] = $created;
        }

        $metadata['current_session'] = $session;
        $metadata['audit_history'] = array_slice($audit, -500);
        $metadata['authority_inherited'] = false;
        $metadata['execution_authority_granted'] = false;
        $council->metadata = $metadata;
        $council->save();
        return $council->fresh();
    }

    /** @return array<string,array<string,mixed>> */
    public function templates(): array
    {
        $all = (array) (WorkforceOrganisationPolicyRegistry::all()['councils'] ?? []);
        $keys = ['executive_operations','finance_review','risk_compliance','quality','customer_recovery','major_incident','staffing','strategic_planning'];
        return array_intersect_key($all, array_flip($keys));
    }

    /** @param Collection<int,WorkforceCouncilMembership> $memberships @param Collection<int,WorkforceMember> $members */
    private function row(int $companyId, WorkforceCouncil $council, Collection $memberships, Collection $members): array
    {
        $metadata = (array) ($council->metadata ?? []);
        $session = (array) data_get($metadata, 'current_session', []);
        $participantRows = $memberships->map(function (WorkforceCouncilMembership $membership) use ($members): array {
            $member = $membership->member_id ? $members->get((int) $membership->member_id) : null;
            return [
                'membership_id' => (int) $membership->id,
                'participation_type' => (string) $membership->participation_type,
                'role_definition_id' => (string) ($membership->role_definition_id ?? ''),
                'member' => $member ? [
                    'id' => (int) $member->id,
                    'name' => (string) $member->name,
                    'url' => route('dashboard.user.titan-workforce.staff.show', $member),
                ] : null,
            ];
        })->values()->all();
        $chair = collect($participantRows)->first(fn (array $p): bool => strtoupper((string) $p['participation_type']) === 'CHAIR');

        return [
            'id' => (int) $council->id,
            'council_uuid' => (string) $council->council_uuid,
            'key' => (string) $council->key,
            'name' => (string) $council->name,
            'purpose' => (string) ($council->purpose ?? ''),
            'chair' => $chair,
            'participants' => $participantRows,
            'issue' => $session['issue'] ?? null,
            'evidence' => array_values((array) ($session['evidence'] ?? [])),
            'proposals' => array_values((array) ($session['proposals'] ?? [])),
            'dissent' => array_values((array) ($session['dissent'] ?? [])),
            'recommendation' => $session['recommendation'] ?? null,
            'final_decision' => $session['final_decision'] ?? null,
            'follow_up_work_items' => array_values((array) ($session['follow_up_work_items'] ?? [])),
            'is_active' => (bool) $council->is_active,
            'decision_authority' => (string) $council->decision_authority,
            'updated_at' => $council->updated_at?->toIso8601String(),
            'url' => route('dashboard.user.titan-workforce.councils.show', $council->id),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    private function chairMember(int $companyId, WorkforceCouncil $council): ?WorkforceMember
    {
        $membership = WorkforceCouncilMembership::query()->forCompany($companyId)
            ->where('council_id', $council->id)->where('is_active', true)->where('participation_type', 'CHAIR')->first();
        if (! $membership?->member_id) return null;
        return WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->find((int) $membership->member_id);
    }

    /** @return array<string,mixed> */
    private function audit(string $event, ?WorkforceMember $actor, array $data = []): array
    {
        return ['event' => $event, 'at' => now()->toIso8601String(), 'member_id' => $actor?->id, 'data' => $data, 'authority_inherited' => false];
    }
}
