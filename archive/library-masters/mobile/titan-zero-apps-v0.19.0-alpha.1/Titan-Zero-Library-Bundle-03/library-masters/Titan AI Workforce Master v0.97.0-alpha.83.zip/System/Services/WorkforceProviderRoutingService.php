<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePlatformCapabilityIndex;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use InvalidArgumentException;

/**
 * Deterministic provider routing for Workforce-visible platform surfaces.
 *
 * Routing proves technical/provider suitability only. It never grants employee
 * authority, approval, autonomy, or permission to execute a side effect.
 */
final class WorkforceProviderRoutingService
{
    private const SURFACE_TYPES = ['capability','tool','command','signal','data_source','workflow'];
    private const WRITE_MODES = ['write','mutation','command','execute'];

    public function __construct(
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforcePlatformCapabilityIndex $index,
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly CostSovereigntyRouter $costSovereignty,
        private readonly WorkforceResourceEconomicsRegistry $resourceEconomics,
    ) {}

    /** @return array<string,mixed> */
    public function routeCapability(
        string|WorkforceMember $roleOrMember,
        string $capabilityId,
        ?string $requestedProvider = null,
        array $policy = [],
    ): array {
        $capabilityId = trim($capabilityId);
        if ($capabilityId === '') throw new InvalidArgumentException('Capability routing requires a capability id.');

        $state = $this->availability->capabilityState($roleOrMember, $capabilityId, $policy);
        $candidates = $this->candidateRows($capabilityId, 'capability', (array) ($state['available_providers'] ?? []));
        return $this->select($capabilityId, 'capability', $candidates, $requestedProvider, $state);
    }

    /** @return array<string,mixed> */
    public function routeResponsibility(
        string|WorkforceMember $roleOrMember,
        string $responsibilityId,
        ?string $requestedProvider = null,
        array $policy = [],
    ): array {
        $requirement = $this->requirements->forResponsibility(trim($responsibilityId));
        if (! is_array($requirement)) {
            throw new InvalidArgumentException('Responsibility is not present in the canonical responsibility model.');
        }

        $roleId = $roleOrMember instanceof WorkforceMember
            ? (string) $roleOrMember->role_definition_id
            : trim((string) $roleOrMember);
        if ($roleId !== (string) ($requirement['role_definition_id'] ?? '')) {
            throw new InvalidArgumentException('Responsibility is not owned by this Workforce role.');
        }

        $providerRows = [];
        foreach ((array) ($requirement['candidate_capabilities'] ?? []) as $capabilityId) {
            $capabilityId = trim((string) $capabilityId);
            if ($capabilityId === '') continue;
            $state = $this->availability->capabilityState($roleOrMember, $capabilityId, $policy);
            foreach ($this->candidateRows($capabilityId, 'capability', (array) ($state['available_providers'] ?? [])) as $row) {
                $provider = (string) ($row['provider'] ?? '');
                if ($provider === '') continue;
                $providerRows[$provider]['provider'] = $provider;
                $providerRows[$provider]['provider_version'] = (string) ($row['provider_version'] ?? '');
                $providerRows[$provider]['provider_class'] = (string) ($row['provider_class'] ?? '');
                $providerRows[$provider]['archive_sha256'] = (string) ($row['archive_sha256'] ?? '');
                $providerRows[$provider]['capabilities'][$capabilityId] = true;
                $providerRows[$provider]['write_surface'] = ($providerRows[$provider]['write_surface'] ?? false)
                    || $this->isWriteSurface($row);
            }
        }

        $requiredClasses = array_values(array_unique(array_map(
            static fn ($v): string => trim((string) $v),
            (array) ($requirement['required_surface_classes'] ?? []),
        )));
        $providerCandidateSet = [];
        foreach ((array) ($requirement['candidate_providers'] ?? []) as $provider) {
            if (! is_array($provider)) continue;
            $key = $this->ecosystem->canonicalProviderKey((string) ($provider['provider'] ?? ''));
            if ($key !== '') $providerCandidateSet[$key] = true;
        }

        $candidates = [];
        foreach ($providerRows as $provider => $row) {
            if ($providerCandidateSet !== [] && ! isset($providerCandidateSet[$provider])) continue;
            $row['matched_capabilities'] = array_keys((array) ($row['capabilities'] ?? []));
            sort($row['matched_capabilities']);
            unset($row['capabilities']);
            $row['matched_capability_count'] = count($row['matched_capabilities']);
            $row['required_surface_classes'] = $requiredClasses;
            $row['provider_preference_rank'] = $this->preferenceRank($provider, $policy);
            $row['routing_score'] = ($row['matched_capability_count'] * 1000) - $row['provider_preference_rank'];
            $candidates[] = $row;
        }

        usort($candidates, static fn (array $a, array $b): int =>
            [-(int) ($a['routing_score'] ?? 0), (string) ($a['provider'] ?? ''), (string) ($a['provider_version'] ?? '')]
            <=>
            [-(int) ($b['routing_score'] ?? 0), (string) ($b['provider'] ?? ''), (string) ($b['provider_version'] ?? '')]
        );

        $state = [
            'responsibility_id' => $responsibilityId,
            'role_definition_id' => $roleId,
            'state' => $candidates !== [] ? WorkforceCapabilityState::Available->value : WorkforceCapabilityState::Unavailable->value,
            'reason' => $candidates !== [] ? 'LIVE_PROVIDER_CANDIDATES' : 'NO_LIVE_PROVIDER_CANDIDATE',
        ];
        return $this->select($responsibilityId, 'responsibility', $candidates, $requestedProvider, $state);
    }

    /**
     * Executable work must have an exact provider/version pin.
     *
     * @return array<string,mixed>
     */
    public function assertExecutableRoute(
        string|WorkforceMember $roleOrMember,
        string $surfaceId,
        string $surfaceType = 'capability',
        ?string $requestedProvider = null,
        array $policy = [],
    ): array {
        $surfaceType = trim($surfaceType);
        if (! in_array($surfaceType, self::SURFACE_TYPES, true)) {
            throw new InvalidArgumentException('Unsupported Workforce routing surface type.');
        }
        if ($surfaceType !== 'capability') {
            throw new InvalidArgumentException('Pass 3 executable routing currently requires a canonical capability surface.');
        }

        $route = $this->routeCapability($roleOrMember, $surfaceId, $requestedProvider, $policy);
        if (($route['status'] ?? null) !== 'selected') {
            throw new InvalidArgumentException('Executable work requires a deterministic provider route: '.(string) ($route['reason'] ?? 'unresolved'));
        }
        if (trim((string) ($route['selected_provider'] ?? '')) === ''
            || trim((string) ($route['selected_provider_version'] ?? '')) === '') {
            throw new InvalidArgumentException('Executable work requires an exact provider/version pin.');
        }
        $provider = (string) $route['selected_provider'];
        $resource = $this->resourceEconomics->provider($provider);
        $resourceType = (string) ($resource['resource_type'] ?? 'software');
        // Deterministic software providers without variable external resources remain usable.
        // Cost-incurring providers must present explicit availability for device/local/BYO/customer/Titan routes.
        if ($resourceType !== 'software' && $this->resourceEconomics->routeKinds($provider) !== []) {
            $companyId = (int) ($policy['company_id'] ?? ($roleOrMember instanceof WorkforceMember ? $roleOrMember->company_id : 0));
            $availability = (array) ($policy['resource_route_availability'] ?? []);
            $candidates = $this->costSovereignty->canonicalCandidatesForProvider($provider, $availability);
            foreach ($candidates as &$candidate) {
                if (isset($policy['estimated_cost'])) $candidate['estimated_cost'] = (float) $policy['estimated_cost'];
                foreach (['security_ok','privacy_ok','quality_ok','capability_ok','data_residency_ok','policy_ok'] as $gate) {
                    if (array_key_exists($gate, $policy)) $candidate[$gate] = (bool) $policy[$gate];
                }
            }
            unset($candidate);
            $economic = $this->costSovereignty->select($companyId, $resourceType, $candidates, $policy);
            if (($economic['status'] ?? null) !== 'selected') {
                throw new InvalidArgumentException('Executable work has no permitted Cost Sovereignty route: '.(string) ($economic['reason'] ?? 'denied'));
            }
            $route['resource_route'] = $economic;
        }
        $route['execution_route_pinned'] = true;
        $route['execution_authority_granted'] = false;
        $route['cost_sovereignty_enforced'] = true;
        return $route;
    }

    /** @param list<string> $availableProviders @return list<array<string,mixed>> */
    private function candidateRows(string $surfaceId, string $surfaceType, array $availableProviders): array
    {
        $available = [];
        foreach ($availableProviders as $provider) {
            $key = $this->ecosystem->canonicalProviderKey((string) $provider);
            if ($key !== '') $available[$key] = true;
        }
        $rows = [];
        foreach ($this->index->owners($surfaceId, $surfaceType) as $row) {
            $provider = $this->ecosystem->canonicalProviderKey((string) ($row['provider'] ?? ''));
            if ($provider === '' || ! isset($available[$provider])) continue;
            $row['provider'] = $provider;
            $row['provider_preference_rank'] = PHP_INT_MAX;
            $row['write_surface'] = $this->isWriteSurface($row);
            $rows[] = $row;
        }
        return $rows;
    }

    /** @param list<array<string,mixed>> $candidates @return array<string,mixed> */
    private function select(string $surfaceId, string $surfaceType, array $candidates, ?string $requestedProvider, array $state): array
    {
        $requested = $requestedProvider !== null
            ? $this->ecosystem->canonicalProviderKey($requestedProvider)
            : '';
        if ($requested !== '') {
            $candidates = array_values(array_filter($candidates, static fn (array $row): bool =>
                (string) ($row['provider'] ?? '') === $requested
            ));
            if ($candidates === []) {
                return $this->unresolved($surfaceId, $surfaceType, 'REQUESTED_PROVIDER_NOT_LIVE_OR_NOT_OWNER', [], $state);
            }
        }

        usort($candidates, static fn (array $a, array $b): int => [
            -(int) ($a['routing_score'] ?? 0),
            (int) ($a['provider_preference_rank'] ?? PHP_INT_MAX),
            (string) ($a['provider'] ?? ''),
            (string) ($a['provider_version'] ?? ''),
        ] <=> [
            -(int) ($b['routing_score'] ?? 0),
            (int) ($b['provider_preference_rank'] ?? PHP_INT_MAX),
            (string) ($b['provider'] ?? ''),
            (string) ($b['provider_version'] ?? ''),
        ]);

        if ($candidates === []) {
            return $this->unresolved($surfaceId, $surfaceType, (string) ($state['reason'] ?? 'NO_LIVE_PROVIDER_CANDIDATE'), [], $state);
        }

        // Explicit provider request is deterministic when exactly one installed version owns the route.
        if ($requested !== '') {
            if (count($candidates) !== 1) {
                return $this->unresolved($surfaceId, $surfaceType, 'REQUESTED_PROVIDER_VERSION_AMBIGUOUS', $candidates, $state);
            }
            return $this->selected($surfaceId, $surfaceType, $candidates[0], $candidates, 'explicit_provider_request', $state);
        }

        if (count($candidates) === 1) {
            return $this->selected($surfaceId, $surfaceType, $candidates[0], $candidates, 'single_live_provider', $state);
        }

        $top = $candidates[0];
        $next = $candidates[1];
        $topScore = (int) ($top['routing_score'] ?? 0);
        $nextScore = (int) ($next['routing_score'] ?? 0);
        $topRank = (int) ($top['provider_preference_rank'] ?? PHP_INT_MAX);
        $nextRank = (int) ($next['provider_preference_rank'] ?? PHP_INT_MAX);

        if ($topScore !== $nextScore || $topRank !== $nextRank) {
            return $this->selected($surfaceId, $surfaceType, $top, $candidates, 'deterministic_policy_or_coverage_rank', $state);
        }

        // Never use lexical ordering as a hidden business decision.
        return $this->unresolved($surfaceId, $surfaceType, 'AMBIGUOUS_CAPABILITY_PROVIDER', $candidates, $state);
    }

    /** @return array<string,mixed> */
    private function selected(string $surfaceId, string $surfaceType, array $selected, array $candidates, string $basis, array $state): array
    {
        return [
            'status' => 'selected',
            'surface_id' => $surfaceId,
            'surface_type' => $surfaceType,
            'selected_provider' => (string) ($selected['provider'] ?? ''),
            'selected_provider_version' => (string) ($selected['provider_version'] ?? ''),
            'selected_provider_class' => (string) ($selected['provider_class'] ?? ''),
            'selected_provider_archive_sha256' => (string) ($selected['archive_sha256'] ?? ''),
            'selection_basis' => $basis,
            'candidates' => $candidates,
            'availability' => $state,
            'tenant_key' => 'company_id',
            'role_identity_immutable' => true,
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    private function unresolved(string $surfaceId, string $surfaceType, string $reason, array $candidates, array $state): array
    {
        return [
            'status' => 'unresolved',
            'surface_id' => $surfaceId,
            'surface_type' => $surfaceType,
            'selected_provider' => null,
            'selected_provider_version' => null,
            'reason' => $reason,
            'candidates' => $candidates,
            'availability' => $state,
            'tenant_key' => 'company_id',
            'role_identity_immutable' => true,
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
            'execution_authority_granted' => false,
        ];
    }

    private function preferenceRank(string $provider, array $policy): int
    {
        $preferred = [];
        foreach ((array) ($policy['preferred_providers'] ?? []) as $index => $key) {
            $canonical = $this->ecosystem->canonicalProviderKey((string) $key);
            if ($canonical !== '' && ! isset($preferred[$canonical])) $preferred[$canonical] = (int) $index;
        }
        return $preferred[$provider] ?? 1000000;
    }

    private function isWriteSurface(array $row): bool
    {
        return in_array(strtolower(trim((string) ($row['mode'] ?? ''))), self::WRITE_MODES, true)
            || strtolower(trim((string) ($row['surface_type'] ?? ''))) === 'command';
    }
}
