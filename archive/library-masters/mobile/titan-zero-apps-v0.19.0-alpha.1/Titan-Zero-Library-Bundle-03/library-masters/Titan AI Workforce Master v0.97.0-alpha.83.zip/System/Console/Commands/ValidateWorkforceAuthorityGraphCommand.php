<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Console\Commands;

use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAuthorityGraphValidator;
use Illuminate\Console\Command;

final class ValidateWorkforceAuthorityGraphCommand extends Command
{
    protected $signature = 'titan:workforce:validate-authority-graph {company_id : Canonical company_id}';
    protected $description = 'Fail-closed validation of Titan Workforce reporting, delegation, continuity, responsibility and council authority graphs.';

    public function handle(WorkforceAuthorityGraphValidator $validator): int
    {
        $companyId = (int) $this->argument('company_id');
        $result = $validator->validateCompany($companyId);
        $this->line(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return $result['valid'] ? self::SUCCESS : self::FAILURE;
    }
}
