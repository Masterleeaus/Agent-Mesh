<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Runtime;

use InvalidArgumentException;

final readonly class RuntimeToolProposal
{
    /**
     * @param array<string, mixed> $arguments
     * @param array<int, string> $evidenceRefs
     */
    public function __construct(
        public string $capability,
        public ?string $capabilityVariant = null,
        public array $arguments = [],
        public ?float $confidence = null,
        public array $evidenceRefs = [],
        public bool $requiresGovernance = true,
    ) {
        if (trim($capability) === '') {
            throw new InvalidArgumentException('Runtime tool proposal requires a capability.');
        }
        if (! $requiresGovernance) {
            throw new InvalidArgumentException('Workforce runtime tool proposals cannot bypass governance.');
        }
        if ($confidence !== null && ($confidence < 0.0 || $confidence > 1.0)) {
            throw new InvalidArgumentException('Runtime tool proposal confidence must be between 0 and 1.');
        }
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        if (($data['execution_claimed'] ?? false) === true || ($data['requires_governance'] ?? true) !== true) {
            throw new InvalidArgumentException('Agent Runtime tool proposal attempted to bypass Workforce governance.');
        }
        return new self(
            capability: (string) ($data['capability'] ?? ''),
            capabilityVariant: isset($data['capability_variant']) ? (string) $data['capability_variant'] : null,
            arguments: (array) ($data['arguments'] ?? []),
            confidence: isset($data['confidence']) ? (float) $data['confidence'] : null,
            evidenceRefs: array_values(array_map('strval', (array) ($data['evidence_refs'] ?? []))),
            requiresGovernance: true,
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'capability' => $this->capability,
            'capability_variant' => $this->capabilityVariant,
            'arguments' => $this->arguments,
            'confidence' => $this->confidence,
            'evidence_refs' => array_values(array_map('strval', $this->evidenceRefs)),
            'requires_governance' => true,
            'execution_claimed' => false,
        ];
    }
}
