<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceAutonomyLevel;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceAutonomyAgreement;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;

final class WorkforceAutonomyAgreementService
{
    public function effectiveLevel(WorkforceMember $member,string $scopeKey='*'): WorkforceAutonomyLevel
    {
        $agreement=WorkforceAutonomyAgreement::query()
            ->forCompany((int)$member->company_id)
            ->where('member_id',$member->getKey())
            ->whereIn('scope_key',[$scopeKey,'*'])
            ->whereNull('revoked_at')
            ->orderByRaw('CASE WHEN scope_key = ? THEN 0 ELSE 1 END',[$scopeKey])
            ->latest('id')->first();

        if(!$agreement) return WorkforceAutonomyLevel::Manual;

        // Agreement is a ceiling and exists only when all required parties have accepted it.
        if(!$agreement->platform_approved_at || !$agreement->user_accepted_at || !$agreement->ai_accepted_at){
            return WorkforceAutonomyLevel::Manual;
        }

        return WorkforceAutonomyLevel::fromMixed((string)($agreement->effective_level ?? $agreement->accepted_level ?? 'manual'));
    }
}
