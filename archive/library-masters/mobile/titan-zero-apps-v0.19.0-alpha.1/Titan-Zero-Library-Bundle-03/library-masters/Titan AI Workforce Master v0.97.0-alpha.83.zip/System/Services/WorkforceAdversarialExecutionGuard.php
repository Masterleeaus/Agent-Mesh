<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use RuntimeException;

/**
 * Defense-in-depth guard for adversarial execution attempts.
 * This does not replace Risk/Assurance/Governance; it rejects malformed or
 * policy-bypass execution envelopes before they enter the normal pipeline.
 */
final class WorkforceAdversarialExecutionGuard
{
    private const FORBIDDEN_FLAGS = [
        'bypass_governance','skip_governance','bypass_approval','skip_approval',
        'bypass_assurance','skip_assurance','bypass_cost_sovereignty',
        'skip_cost_sovereignty','bypass_permission','skip_permission',
        'bypass_entitlement','skip_entitlement','bypass_privacy','skip_privacy',
        'bypass_autonomy','skip_autonomy','bypass_risk','skip_risk',
        'ignore_policy','ignore_authority','force_titan_paid_fallback','disable_tenant_check',
    ];

    public function assertSafe(WorkforceTask $task, WorkforceMember $worker, array $command): void
    {
        $companyId = (int) $task->company_id;
        if ($companyId <= 0) {
            throw new RuntimeException('ADVERSARIAL_GUARD_COMPANY_CONTEXT_REQUIRED');
        }

        $this->assertCompanyBoundary($command, $companyId);
        $this->assertNoBypassFlags($command);
        $this->assertNoSecretMaterial($command);
        $this->assertDelegationFreshness($command);
        $this->assertApprovalFreshness($command);
        $this->assertPredictiveChain($command);
        $this->assertUntrustedControlPlaneIsolation($command);
    }

    private function assertCompanyBoundary(array $value, int $companyId): void
    {
        foreach ($value as $key => $item) {
            $name = strtolower((string) $key);
            if (in_array($name, ['company_id','tenant_id','tenant_company_id','tenantid','tenantcompanyid'], true)
                && is_scalar($item) && trim((string) $item) !== '' && (int) $item !== $companyId) {
                throw new RuntimeException('CROSS_COMPANY_REFERENCE_REJECTED');
            }
            if (is_array($item)) $this->assertCompanyBoundary($item, $companyId);
        }
    }

    private function assertNoBypassFlags(array $value): void
    {
        foreach ($value as $key => $item) {
            if (in_array(strtolower((string) $key), self::FORBIDDEN_FLAGS, true) && $item) {
                throw new RuntimeException('CONTROL_PLANE_BYPASS_ATTEMPT_REJECTED');
            }
            if (is_array($item)) $this->assertNoBypassFlags($item);
        }
    }

    private function assertNoSecretMaterial(array $value): void
    {
        foreach ($value as $key => $item) {
            $k = strtolower((string) $key);
            if (preg_match('/(?:api[_-]?key|secret|password|access[_-]?token|refresh[_-]?token|authorization)/', $k)) {
                if (is_string($item) && trim($item) !== '') {
                    throw new RuntimeException('SECRET_MATERIAL_IN_EXECUTION_ENVELOPE_REJECTED');
                }
            }
            if (is_array($item)) $this->assertNoSecretMaterial($item);
        }
    }

    private function assertDelegationFreshness(array $command): void
    {
        $delegation = (array) ($command['delegation'] ?? []);
        if ($delegation === []) return;
        if (($delegation['active'] ?? true) !== true) {
            throw new RuntimeException('STALE_OR_INACTIVE_DELEGATION_REJECTED');
        }
        if (isset($delegation['valid_until']) && strtotime((string) $delegation['valid_until']) <= time()) {
            throw new RuntimeException('EXPIRED_DELEGATION_REJECTED');
        }
    }

    private function assertApprovalFreshness(array $command): void
    {
        $approval = (array) ($command['approval'] ?? []);
        if ($approval === []) return;
        if (($approval['forged'] ?? false) === true || ($approval['verified'] ?? true) !== true) {
            throw new RuntimeException('UNVERIFIED_APPROVAL_REJECTED');
        }
        if (isset($approval['valid_until']) && strtotime((string) $approval['valid_until']) <= time()) {
            throw new RuntimeException('EXPIRED_APPROVAL_REJECTED');
        }
    }

    private function assertPredictiveChain(array $command): void
    {
        $ctx = (array) ($command['predictive_context'] ?? []);
        if ($ctx === []) return;
        $depth = (int) ($ctx['chain_depth'] ?? 0);
        $max = max(0, (int) ($ctx['max_chain_depth'] ?? 1));
        if ($depth > $max) throw new RuntimeException('PREDICTIVE_SELF_TRIGGER_LOOP_BLOCKED');
        if (($ctx['origin_prediction_id'] ?? null) !== null
            && ($ctx['origin_prediction_id'] ?? null) === ($ctx['prediction_id'] ?? null)) {
            throw new RuntimeException('PREDICTIVE_SELF_TRIGGER_LOOP_BLOCKED');
        }
    }

    private function assertUntrustedControlPlaneIsolation(array $command): void
    {
        $untrusted = (array) ($command['untrusted_input'] ?? []);
        if ($untrusted === []) return;
        $json = strtolower(json_encode($untrusted, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '');
        $patterns = [
            'ignore previous instructions','ignore all previous','bypass approval',
            'bypass governance','disable safety','reveal system prompt','use another company',
            'switch company_id','force titan paid',
        ];
        foreach ($patterns as $pattern) {
            if (str_contains($json, $pattern)) {
                throw new RuntimeException('UNTRUSTED_CONTROL_PLANE_INSTRUCTION_REJECTED');
            }
        }
    }
}
