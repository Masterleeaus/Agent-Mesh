<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceDecisionChainState;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

final class WorkforceDecisionChain extends Model
{
    protected $table = 'ext_titan_ai_workforce_decision_chains';
    protected $guarded = [];
    protected $casts = [
        'state' => WorkforceDecisionChainState::class,
        'consequential' => 'boolean',
        'organisationally_approved' => 'boolean',
        'authority_gates_ready' => 'boolean',
        'contract_snapshot' => 'array',
        'knowledge_receipt' => 'array',
        'metadata' => 'array',
        'approved_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }

    public function task(): BelongsTo
    {
        return $this->belongsTo(WorkforceTask::class, 'task_id');
    }

    public function checkpoints(): HasMany
    {
        return $this->hasMany(WorkforceProcessingCheckpoint::class, 'processing_id', 'processing_id')
            ->orderBy('stage');
    }
}
