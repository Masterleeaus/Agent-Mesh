<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSignalWorkReceipt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSignalWorkRule;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class WorkforceSignalToWorkService
{
    public function __construct(
        private readonly WorkforceGoalService $goals,
        private readonly WorkforceWorkItemService $workItems,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
    ) {}

    public function receive(string $eventType, array $envelope): int
    {
        $eventType = trim($eventType);
        $companyId = (int) ($envelope['company_id'] ?? data_get($envelope, 'payload.company_id', 0));
        $signalId = trim((string) ($envelope['signal_id'] ?? data_get($envelope, 'payload.signal_id', '')));
        if ($companyId <= 0 || $eventType === '' || $signalId === '') return 0;

        return CompanyContext::runWith($companyId, function () use ($companyId, $eventType, $signalId, $envelope): int {
            $created = 0;
            $rules = WorkforceSignalWorkRule::query()->forCompany($companyId)
                ->where('is_active', true)->where('event_type', $eventType)->orderBy('id')->get();

            foreach ($rules as $rule) {
                if (! $this->matches((array) ($rule->conditions ?? []), $envelope)) continue;
                $requirement = $this->requirements->forResponsibility((string) $rule->responsibility_id);
                if (! is_array($requirement)
                    || (string) ($requirement['role_definition_id'] ?? '') !== (string) $rule->role_definition_id
                    || ! in_array($eventType, (array) ($requirement['candidate_signals'] ?? []), true)
                    || ! in_array((string) $rule->capability, (array) ($requirement['candidate_capabilities'] ?? []), true)) {
                    continue;
                }

                $member = $this->resolveMember($companyId, $rule);
                if (! $member) continue;

                $receipt = WorkforceSignalWorkReceipt::query()->firstOrCreate(
                    ['company_id'=>$companyId,'rule_id'=>$rule->id,'signal_id'=>$signalId],
                    ['event_type'=>$eventType,'status'=>'PROCESSING','metadata'=>['trace_id'=>$envelope['trace_id'] ?? null]]
                );
                if (! $receipt->wasRecentlyCreated && in_array((string) $receipt->status, ['CREATED','DUPLICATE'], true)) continue;

                DB::transaction(function () use ($companyId,$eventType,$signalId,$envelope,$rule,$member,$receipt,&$created): void {
                    $goalTemplate = (array) $rule->goal_template;
                    $goal = $this->goals->create($companyId, array_merge($goalTemplate, [
                        'origin_type'=>'titan_signal',
                        'origin_id'=>$signalId,
                        'idempotency_key'=>"signal-goal:{$rule->id}:{$signalId}",
                        'trace_id'=>$envelope['trace_id'] ?? null,
                        'correlation_id'=>$envelope['correlation_id'] ?? $signalId,
                        'metadata'=>array_merge((array)($goalTemplate['metadata'] ?? []),[
                            'signal_id'=>$signalId,'event_type'=>$eventType,'signal_rule_id'=>$rule->id,
                            'signal_grants_authority'=>false,
                        ]),
                    ]), $member);

                    $template = (array) $rule->work_item_template;
                    $workItem = $this->workItems->create($companyId,$goal,$member,array_merge($template,[
                        'responsibility_id'=>(string)$rule->responsibility_id,
                        'capability'=>(string)$rule->capability,
                        'origin_type'=>'titan_signal',
                        'origin_id'=>$signalId,
                        'idempotency_key'=>"signal-work:{$rule->id}:{$signalId}",
                        'trace_id'=>$envelope['trace_id'] ?? null,
                        'correlation_id'=>$envelope['correlation_id'] ?? $signalId,
                        'causation_id'=>$signalId,
                        'payload'=>array_merge((array)($template['payload'] ?? []),['trigger_signal'=>$envelope]),
                        'metadata'=>array_merge((array)($template['metadata'] ?? []),[
                            'signal_id'=>$signalId,'event_type'=>$eventType,'signal_rule_id'=>$rule->id,
                            'requires_governance'=>true,'execution_claimed'=>false,'business_outcome_claimed'=>false,
                        ]),
                    ]),$member);

                    $receipt->forceFill([
                        'goal_id'=>$goal->id,'work_item_id'=>$workItem->id,'status'=>'CREATED','processed_at'=>now(),
                        'reason'=>null,
                    ])->save();
                    if ($workItem->wasRecentlyCreated) {
                        ProcessWorkforceTaskJob::dispatch($companyId,(int)$workItem->id);
                        $created++;
                    }
                });
            }
            return $created;
        });
    }

    private function resolveMember(int $companyId, WorkforceSignalWorkRule $rule): ?WorkforceMember
    {
        $query = WorkforceMember::query()->forCompany($companyId)->where('is_active',true)
            ->where('role_definition_id',(string)$rule->role_definition_id);
        if ($rule->assignee_member_id) $query->whereKey((int)$rule->assignee_member_id);
        return $query->orderBy('id')->first();
    }

    private function matches(array $conditions, array $envelope): bool
    {
        foreach ($conditions as $path=>$expected) if (data_get($envelope,(string)$path) != $expected) return false;
        return true;
    }
}
