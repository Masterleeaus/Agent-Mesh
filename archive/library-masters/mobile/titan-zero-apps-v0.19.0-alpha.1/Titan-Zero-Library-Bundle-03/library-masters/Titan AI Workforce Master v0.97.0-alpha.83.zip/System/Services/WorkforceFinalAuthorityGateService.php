<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceFinalAuthorityGateService
{
    public function __construct(
        private readonly WorkforceGovernanceBridge $governance,
        private readonly WorkforceDecisionChainService $chains,
        private readonly WorkforceAutonomyAgreementService $agreements,
        private readonly WorkforceReviewerPerformanceFeedbackService $reviewerFeedback,
        private readonly WorkforceChainAuditReconstructionService $audit,
        private readonly WorkforceChainPolicyAdminService $adminPolicy,
    ) {}

    /** @return array<string,mixed> */
    public function evaluate(WorkforceTask $task, WorkforceMember $actor, string $processingId): array
    {
        $chain=$this->chains->assertAuthorityReady($task,$processingId);

        $decision=$this->governance->evaluate($task,$actor);
        $policy=(array)($decision['policy'] ?? []);
        $risk=(array)($decision['risk'] ?? []);
        $autonomy=(array)($decision['autonomy'] ?? []);
        $governanceAllowed=($decision['governance_complete'] ?? false)===true
            && ($policy['allowed'] ?? false)===true;
        $riskAllowed=($risk['allowed'] ?? $risk['decision'] ?? null)===true
            || in_array(strtoupper((string)($risk['decision'] ?? '')),['ALLOW','APPROVE','PASS'],true);
        if(($risk['available'] ?? false)!==true) $riskAllowed=false;
        $autonomyAllowed=($autonomy['allowed'] ?? false)===true;

        $admin=$this->adminPolicy->requirements($chain);
        $adminAllowed=($admin['admin_hold'] ?? false)!==true;
        $manualAdminRequired=($admin['admin_require_manual_review'] ?? false)===true
            || ($admin['require_manual_review'] ?? false)===true;
        if($manualAdminRequired){
            $stage3=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint::query()
                ->forCompany((int)$chain->company_id)
                ->where('processing_id',$chain->processing_id)->where('stage',3)->first();
            $manualReceipt=trim((string)data_get($stage3?->decision ?? [],'manual_review_receipt',''));
            if($manualReceipt==='') $adminAllowed=false;
        }

        $agreementModel=\App\Extensions\TitanAIWorkforce\System\Models\WorkforceAutonomyAgreement::query()
            ->forCompany((int)$actor->company_id)
            ->where('member_id',$actor->getKey())->where('scope_key','*')->first();
        $effectiveLevel=$this->agreements->effectiveLevel($actor)->value;
        $agreement=[
            'platform_approved'=>(bool)($agreementModel?->platform_approved_at),
            'user_accepted'=>(bool)($agreementModel?->user_accepted_at),
            'ai_accepted'=>(bool)($agreementModel?->ai_accepted_at),
        ];
        if(!in_array($effectiveLevel,['manual','assist','semi','auto','predictive'],true)) $effectiveLevel='manual';

        // Negotiated autonomy is a ceiling, never an authority grant.
        if(in_array($effectiveLevel,['semi','auto','predictive'],true)){
            foreach(['platform_approved','user_accepted','ai_accepted'] as $required){
                if(($agreement[$required] ?? false)!==true){
                    $autonomyAllowed=false;
                }
            }
        }

        $final=$chain->organisationally_approved
            && $chain->authority_gates_ready
            && $governanceAllowed
            && $riskAllowed
            && $autonomyAllowed
            && $adminAllowed;

        $reasons=[];
        if(!$chain->organisationally_approved)$reasons[]='ORGANISATIONAL_APPROVAL_MISSING';
        if(!$governanceAllowed)$reasons[]='GOVERNANCE_DENIED_OR_INCOMPLETE';
        if(!$riskAllowed)$reasons[]='RISK_GATE_DENIED_OR_UNAVAILABLE';
        if(!$autonomyAllowed)$reasons[]='AUTONOMY_GATE_DENIED_OR_HANDSHAKE_INCOMPLETE';
        if(($admin['admin_hold'] ?? false)===true)$reasons[]='ADMIN_GOVERNED_HOLD_ACTIVE';
        if($manualAdminRequired && !$adminAllowed && ($admin['admin_hold'] ?? false)!==true)$reasons[]='ADMIN_MANUAL_REVIEW_RECEIPT_REQUIRED';

        $record=WorkforceFinalAuthorityGate::query()->updateOrCreate(
            ['company_id'=>(int)$task->company_id,'processing_id'=>$processingId],
            [
                'gate_uuid'=>(string)(WorkforceFinalAuthorityGate::query()
                    ->forCompany((int)$task->company_id)->where('processing_id',$processingId)->value('gate_uuid') ?: Str::uuid()),
                'decision_chain_id'=>$chain->getKey(),
                'task_id'=>$task->getKey(),
                'actor_member_id'=>$actor->getKey(),
                'organisationally_approved'=>(bool)$chain->organisationally_approved,
                'governance_allowed'=>$governanceAllowed,
                'risk_allowed'=>$riskAllowed,
                'autonomy_allowed'=>$autonomyAllowed,
                'final_allowed'=>$final,
                'effective_autonomy_level'=>$effectiveLevel,
                'governance_result'=>$decision,
                'risk_result'=>$risk,
                'autonomy_result'=>$autonomy,
                'policy_result'=>$policy,
                'reason_codes'=>$reasons,
                'evaluated_at'=>now(),
            ]
        );

        $feedbackPayload=[
            'gate_uuid'=>$record->gate_uuid,
            'allowed'=>$final,
            'governance_allowed'=>$governanceAllowed,
            'risk_allowed'=>$riskAllowed,
            'autonomy_allowed'=>$autonomyAllowed,
            'reason_codes'=>$reasons,
        ];
        $this->reviewerFeedback->recordFinalAuthorityGate($chain,$task,$feedbackPayload);
        $this->audit->capture($chain->refresh(),'FINAL_AUTHORITY_GATE');

        return [
            'gate_uuid'=>$record->gate_uuid,
            'allowed'=>$final,
            'organisationally_approved'=>(bool)$chain->organisationally_approved,
            'governance_allowed'=>$governanceAllowed,
            'risk_allowed'=>$riskAllowed,
            'autonomy_allowed'=>$autonomyAllowed,
            'effective_autonomy_level'=>$effectiveLevel,
            'reason_codes'=>$reasons,
            'decision'=>$decision,
        ];
    }
}
