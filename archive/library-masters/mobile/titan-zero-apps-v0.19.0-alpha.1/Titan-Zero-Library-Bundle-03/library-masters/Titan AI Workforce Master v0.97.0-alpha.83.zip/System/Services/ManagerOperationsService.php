<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

final class ManagerOperationsService
{
    public function __construct(
        private readonly ManagerPlanValidator $validator,
        private readonly WorkforceTaskService $tasks,
        private readonly WorkforceDependencyService $dependencies,
        private readonly WorkloadSharingService $workload,
    ) {}

    public function decompose(WorkforceTask $objective, WorkforceMember $manager, array $runtimeResult): array
    {
        $this->assertManagerObjective($objective, $manager);
        if (in_array($objective->status, [WorkforceTaskStatus::Created, WorkforceTaskStatus::Assigned, WorkforceTaskStatus::Escalated], true)) {
            $objective = $this->tasks->transition($objective, WorkforceTaskStatus::Processing, $manager, 'manager.objective_processing');
        } elseif ($objective->status !== WorkforceTaskStatus::Processing) {
            throw new InvalidArgumentException('Manager objective is not in a decomposable state.');
        }
        $divisionKey = (string) optional($manager->division)->key;
        if ($divisionKey === '') {
            throw new InvalidArgumentException('Manager has no Workforce division.');
        }

        $plan = $this->extractPlan($runtimeResult);
        if ($plan === null) {
            $objective->forceFill(['result' => array_merge($objective->result ?? [], ['manager_plan' => null, 'manager_plan_errors' => [['code' => 'PLAN_NOT_FOUND']]])])->save();
            if ($objective->status !== WorkforceTaskStatus::AwaitingData) {
                $this->tasks->transition($objective->refresh(), WorkforceTaskStatus::AwaitingData, $manager, 'manager.plan_missing', 'Manager response did not contain a structured workforce_plan.');
            }
            return [];
        }

        $managerDefinition = $manager->role_definition_id ? WorkforceRoleRegistry::find((string) $manager->role_definition_id) : WorkforceRoleRegistry::find((string) $manager->key);
        $managerRoleKey = (string) ($managerDefinition['key'] ?? $manager->key);
        $validated = $this->validator->validate($plan, $divisionKey, $managerRoleKey);
        if (! ($validated['valid'] ?? false)) {
            $objective->forceFill(['result' => array_merge($objective->result ?? [], ['manager_plan' => $plan, 'manager_plan_validation' => $validated])])->save();
            $this->tasks->transition($objective->refresh(), WorkforceTaskStatus::AwaitingData, $manager, 'manager.plan_rejected', 'Manager plan failed deterministic Workforce validation.', ['errors' => $validated['errors'] ?? []]);
            return [];
        }

        $children = DB::transaction(function () use ($objective, $manager, $validated): array {
            $byStep = [];
            foreach ($validated['steps'] as $step) {
                $specialist = $this->workload->findForRole(
                    (int) $objective->company_id,
                    (int) $manager->division_id,
                    (string) $step['role_key'],
                    (string) $step['capability'],
                    (string) $objective->risk_level,
                );
                $status = $specialist ? WorkforceTaskStatus::Assigned : WorkforceTaskStatus::Blocked;
                $metadata = array_merge(is_array($step['metadata'] ?? null) ? $step['metadata'] : [], [
                    'manager_plan_id' => $validated['plan_id'] ?: ('plan:' . $objective->task_uuid),
                    'manager_plan_step_id' => $step['id'],
                    'depends_on_step_ids' => $step['depends_on'],
                    'handoff_to_division' => $step['handoff_to_division'],
                    'handoff_to_role_key' => $step['handoff_to_role_key'],
                    'handoff_to_capability' => $step['handoff_to_capability'] ?? null,
                    'cross_division_handoff' => $step['cross_division_handoff'],
                    'staffing_gap' => $specialist === null,
                ]);
                $child = $this->tasks->create((int) $objective->company_id, [
                    'parent_task_id' => $objective->id,
                    'division_id' => $manager->division_id,
                    'team_id' => $specialist?->team_id,
                    'assignee_member_id' => $specialist?->id,
                    'manager_member_id' => $manager->id,
                    'origin_type' => 'manager_plan',
                    'origin_id' => $objective->task_uuid,
                    'title' => (string) $step['title'],
                    'description' => $step['description'] ?? null,
                    'capability' => (string) $step['capability'],
                    'capability_variant' => $step['capability_variant'] ?? null,
                    'status' => $status,
                    'priority' => (int) $step['priority'],
                    'risk_level' => (string) $objective->risk_level,
                    'payload' => [
                        'objective_task_uuid' => $objective->task_uuid,
                        'manager_plan_step' => $step,
                        'objective_payload' => $objective->payload,
                    ],
                    'evidence' => $objective->evidence,
                    'trace_id' => $objective->trace_id,
                    'correlation_id' => $objective->correlation_id,
                    'causation_id' => $objective->task_uuid,
                    'idempotency_key' => 'manager-plan:' . $objective->task_uuid . ':' . $step['id'],
                    'deadline_at' => $step['deadline_at'] ?? null,
                    'sla_key' => $step['sla_key'] ?? $objective->sla_key,
                    'metadata' => $metadata,
                ], $manager);
                $byStep[$step['id']] = $child;
                if ($specialist === null) {
                    $this->tasks->record($child, $manager, 'manager.staffing_gap', $child->status->value, $child->status->value, 'No active specialist with required role/capability capacity.', [
                        'role_key' => $step['role_key'], 'capability' => $step['capability'],
                    ]);
                }
            }

            foreach ($validated['steps'] as $step) {
                foreach ($step['depends_on'] as $dependencyStepId) {
                    $this->dependencies->link($byStep[$step['id']], $byStep[$dependencyStepId], true);
                }
            }
            return $byStep;
        });

        foreach ($validated['steps'] as $step) {
            $child = $children[$step['id']];
            if ($child->assignee_member_id !== null && $step['depends_on'] === []) {
                ProcessWorkforceTaskJob::dispatch((int) $child->company_id, (int) $child->id);
            }
        }

        $objective->forceFill(['result' => array_merge($objective->result ?? [], [
            'manager_plan' => $validated,
            'delegated_task_uuids' => array_values(array_map(fn (WorkforceTask $task) => $task->task_uuid, $children)),
        ])])->save();
        $this->tasks->transition($objective->refresh(), WorkforceTaskStatus::Completed, $manager, 'manager.plan_decomposed', 'Manager objective decomposed into governed specialist work.', [
            'child_count' => count($children),
            'plan_id' => $validated['plan_id'] ?: null,
        ]);

        return array_values($children);
    }

    public function extractPlan(array $runtimeResult): ?array
    {
        foreach (['workforce_plan', 'manager_plan', 'plan'] as $key) {
            if (isset($runtimeResult[$key]) && is_array($runtimeResult[$key]) && isset($runtimeResult[$key]['steps'])) {
                return $runtimeResult[$key];
            }
        }
        foreach (['output', 'data', 'result', 'structured_output', 'proposal'] as $key) {
            if (isset($runtimeResult[$key])) {
                if (is_array($runtimeResult[$key])) {
                    $found = $this->extractPlan($runtimeResult[$key]);
                    if ($found) return $found;
                }
                if (is_string($runtimeResult[$key])) {
                    $decoded = json_decode($runtimeResult[$key], true);
                    if (is_array($decoded)) {
                        $found = $this->extractPlan($decoded);
                        if ($found) return $found;
                    }
                }
            }
        }
        foreach (['content', 'text', 'message'] as $key) {
            if (! isset($runtimeResult[$key]) || ! is_string($runtimeResult[$key])) continue;
            $decoded = json_decode($runtimeResult[$key], true);
            if (is_array($decoded)) {
                $found = $this->extractPlan($decoded);
                if ($found) return $found;
            }
        }
        return null;
    }

    private function assertManagerObjective(WorkforceTask $objective, WorkforceMember $manager): void
    {
        if ((int) $objective->company_id !== (int) $manager->company_id) {
            throw new InvalidArgumentException('Cross-tenant manager objective rejected.');
        }
        if ($manager->tier !== WorkforceTier::Manager || (int) $objective->assignee_member_id !== (int) $manager->id) {
            throw new InvalidArgumentException('Objective is not assigned to this Workforce Manager.');
        }
    }
}
