<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class TitanZeroSystemRole
{
    public const ROLE_DEFINITION_ID = 'titan.system.titan_zero';
    public const KEY = 'titan-zero';
    public const NAME = 'Titan Zero';
    public const BUSINESS_ROLE = 'Chief of Staff';

    /** @var array<string,mixed>|null */
    private static ?array $definition = null;

    /** @return array<string,mixed> */
    public static function definition(): array
    {
        if (self::$definition !== null) return self::$definition;

        $path = dirname(__DIR__, 2) . '/resources/workforce/system-role-definitions.json';
        if (! is_file($path)) throw new RuntimeException('Titan Zero system RoleDefinition is missing.');
        $rows = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($rows) || count($rows) !== 1 || ! is_array($rows[0] ?? null)) {
            throw new RuntimeException('Titan Zero system RoleDefinition catalogue is invalid.');
        }
        $definition = $rows[0];
        if (($definition['role_definition_id'] ?? null) !== self::ROLE_DEFINITION_ID
            || ($definition['key'] ?? null) !== self::KEY
            || ($definition['definition_scope'] ?? null) !== 'SYSTEM') {
            throw new RuntimeException('Titan Zero system RoleDefinition identity drift detected.');
        }
        foreach (['risk','assurance','governance','autonomy'] as $engine) {
            if (($definition['bypass'][$engine] ?? null) !== false) {
                throw new RuntimeException("Titan Zero may not bypass {$engine}.");
            }
        }
        if (($definition['consumes_seat'] ?? null) !== false || ($definition['permanent'] ?? null) !== true) {
            throw new RuntimeException('Titan Zero system RoleDefinition seat/permanence contract drift detected.');
        }
        return self::$definition = $definition;
    }
}
