<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceAdaptiveChainProfile;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerFeedback;
use Illuminate\Support\Str;

final class WorkforceAdaptiveChainIntelligenceService
{
    public function profile(WorkforceDecisionChain $chain): WorkforceAdaptiveChainProfile
    {
        $signals=$this->signals($chain);
        $uncertainty=$this->uncertaintyScore($signals);
        $consequence=$this->consequenceScore($chain,$signals);

        $depth=match(true){
            $consequence>=85 || $uncertainty>=85 => 'CRITICAL',
            $consequence>=65 || $uncertainty>=65 => 'ENHANCED',
            default => 'STANDARD',
        };

        $qualityFloor=match($depth){
            'CRITICAL'=>80,
            'ENHANCED'=>70,
            default=>0,
        };

        return WorkforceAdaptiveChainProfile::query()->updateOrCreate(
            ['company_id'=>(int)$chain->company_id,'processing_id'=>$chain->processing_id],
            [
                'profile_uuid'=>(string)(WorkforceAdaptiveChainProfile::query()->forCompany((int)$chain->company_id)
                    ->where('processing_id',$chain->processing_id)->value('profile_uuid') ?: Str::uuid()),
                'decision_chain_id'=>$chain->getKey(),
                'depth'=>$depth,
                'uncertainty_score'=>$uncertainty,
                'consequence_score'=>$consequence,
                'reviewer_quality_floor'=>$qualityFloor,
                'force_assurance'=>in_array($depth,['ENHANCED','CRITICAL'],true),
                'force_model_council'=>$depth==='CRITICAL' && ($uncertainty>=80 || $signals['repeated_disagreement']>=2),
                'prefer_provider_diversity'=>in_array($depth,['ENHANCED','CRITICAL'],true),
                'mandatory_three_checks'=>true,
                'signals'=>$signals,
                'reviewer_requirements'=>[
                    'minimum_decision_quality'=>$qualityFloor,
                    'prefer_provider_diversity'=>in_array($depth,['ENHANCED','CRITICAL'],true),
                    'force_assurance'=>in_array($depth,['ENHANCED','CRITICAL'],true),
                    'force_model_council'=>$depth==='CRITICAL' && ($uncertainty>=80 || $signals['repeated_disagreement']>=2),
                ],
                'calculated_at'=>now(),
            ]
        );
    }

    /** @return array<string,mixed> */
    public function reviewerRequirements(WorkforceDecisionChain $chain,int $stage): array
    {
        $profile=$this->profile($chain);
        return array_merge((array)$profile->reviewer_requirements,[
            'adaptive_depth'=>$profile->depth,
            'stage'=>$stage,
            'mandatory_three_checks'=>true,
        ]);
    }

    /** @return array<string,mixed> */
    public function escalationContext(WorkforceDecisionChain $chain): array
    {
        $p=$this->profile($chain);
        return [
            'adaptive_depth'=>$p->depth,
            'uncertainty_score'=>$p->uncertainty_score,
            'consequence_score'=>$p->consequence_score,
            'force_model_council'=>(bool)$p->force_model_council,
            'force_assurance'=>(bool)$p->force_assurance,
        ];
    }

    /** @return array<string,mixed> */
    private function signals(WorkforceDecisionChain $chain): array
    {
        $receipt=(array)($chain->knowledge_receipt ?? []);
        $confidence=(float)($receipt['confidence'] ?? $receipt['authority_confidence'] ?? 100);
        $sections=(array)($receipt['sections'] ?? []);
        if($sections!==[]){
            $vals=[];
            foreach($sections as $s) if(is_array($s) && isset($s['confidence'])) $vals[]=(float)$s['confidence']*100;
            if($vals!==[]) $confidence=min($confidence,array_sum($vals)/count($vals));
        }
        $challenges=WorkforceDecisionChallenge::query()->forCompany((int)$chain->company_id)
            ->where('processing_id',$chain->processing_id)->count();
        $history=WorkforceReviewerFeedback::query()->forCompany((int)$chain->company_id)
            ->whereIn('reviewer_member_id',function($q) use($chain){
                $q->select('reviewer_member_id')->from('ext_titan_ai_workforce_processing_checkpoints')
                    ->where('company_id',(int)$chain->company_id)->where('processing_id',$chain->processing_id)
                    ->whereNotNull('reviewer_member_id');
            })->latest('observed_at')->limit(100)->get();

        return [
            'knowledge_confidence'=>max(0,min(100,$confidence)),
            'knowledge_sections'=>count($sections),
            'repeated_disagreement'=>$challenges,
            'historical_overturn_rate'=>$history->isEmpty()?0.0:round(100*$history->where('overturned',true)->count()/$history->count(),2),
            'historical_missed_risk_rate'=>$history->isEmpty()?0.0:round(100*$history->where('missed_risk',true)->count()/$history->count(),2),
            'risk_class'=>strtoupper((string)$chain->risk_class),
            'business_value'=>(float)data_get($chain->task?->payload ?? [],'amount',0),
            'priority'=>(int)($chain->task?->priority ?? 50),
        ];
    }

    private function uncertaintyScore(array $s): int
    {
        $score=(100-(float)$s['knowledge_confidence'])*0.45;
        $score+=min(25,(int)$s['repeated_disagreement']*12.5);
        $score+=min(15,(float)$s['historical_overturn_rate']*.30);
        $score+=min(15,(float)$s['historical_missed_risk_rate']*.30);
        if((int)$s['knowledge_sections']===0) $score+=20;
        return (int)round(max(0,min(100,$score)));
    }

    private function consequenceScore(WorkforceDecisionChain $chain,array $s): int
    {
        $risk=['MINIMAL'=>10,'LOW'=>20,'ORDINARY'=>25,'MEDIUM'=>45,'HIGH'=>70,'REGULATED'=>75,'CRITICAL'=>90,'SEVERE'=>95,'EXTREME'=>100];
        $score=(float)($risk[$s['risk_class']] ?? 25);
        $value=(float)$s['business_value'];
        if($value>=100000)$score=max($score,90);
        elseif($value>=25000)$score=max($score,75);
        elseif($value>=5000)$score=max($score,55);
        if((int)$s['priority']>=90)$score=min(100,$score+10);
        return (int)round(max(0,min(100,$score)));
    }
}
