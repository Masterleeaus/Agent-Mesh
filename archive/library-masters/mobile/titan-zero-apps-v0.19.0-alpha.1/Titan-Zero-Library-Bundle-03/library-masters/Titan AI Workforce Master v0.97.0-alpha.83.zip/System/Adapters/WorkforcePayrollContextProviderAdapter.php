<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Adapters;

use App\Extensions\TitanAIWorkforce\System\Contracts\WorkforceBusinessContextProviderContract;
use RuntimeException;

final class WorkforcePayrollContextProviderAdapter implements WorkforceBusinessContextProviderContract
{
    public function providerKey(): string { return 'titan-payroll'; }
    public function providerVersion(): string { return '0.1.0-rc.2'; }

    public function supports(string $surfaceId): bool
    {
        return in_array($surfaceId, [
            'payroll.read',
            'tool:payroll.runs.read','tool:payroll.reconciliation.read',
            'tool:payroll.compliance.read','tool:payroll.forecast.read',
        ], true);
    }

    public function read(int $companyId, string $surfaceId, array $filters = [], int $limit = 50): array
    {
        $serviceClass = 'App\\Extensions\\TitanPayroll\\System\\Workforce\\PayrollWorkforceReadService';
        $contextClass = 'App\\Extensions\\TitanPayroll\\System\\Workforce\\PayrollWorkforceExecutionContext';
        if (! app()->bound($serviceClass) && ! class_exists($serviceClass)) throw new RuntimeException('Titan Payroll read service is unavailable.');
        if (! class_exists($contextClass)) throw new RuntimeException('Titan Payroll execution context is unavailable.');

        $service = app($serviceClass);
        $ctx = new $contextClass($companyId, (int) ($filters['actor_user_id'] ?? 0), (string) ($filters['role_id'] ?? 'titan-ai-workforce'), (string) ($filters['trace_id'] ?? 'workforce-context'));
        $input = $filters; $input['limit'] = max(1, min($limit, 100));

        $raw = match ($surfaceId) {
            'payroll.read','tool:payroll.runs.read' => $service->runs($ctx,$input),
            'tool:payroll.reconciliation.read' => $service->reconciliation($ctx,$input),
            'tool:payroll.compliance.read' => $service->compliance($ctx,$input),
            'tool:payroll.forecast.read' => $service->forecast($ctx,$input),
            default => throw new RuntimeException('Unsupported Titan Payroll context surface.'),
        };
        if (! is_array($raw)) $raw = ['value'=>$raw];
        foreach (array_keys($raw) as $key) { if (str_contains((string) $key, 'tenant'.'_company_id')) unset($raw[$key]); }
        return [
            'company_id'=>$companyId,'surface_id'=>$surfaceId,'items'=>[$raw],
            'observed_at'=>now()->toIso8601String(),
            'provenance'=>['provider'=>'titan-payroll','provider_version'=>$this->providerVersion(),'storage_compatibility'=>'legacy-internal-key-adapted'],
        ];
    }
}
