<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Adapters\TitanAIRuntimeAdapter;
use App\Extensions\TitanAIWorkforce\System\Contracts\AgentRuntimeContract;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeFailure;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeRequest;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeResponse;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Illuminate\Contracts\Container\Container;
use Throwable;

/**
 * Late-bound cross-extension gateway. Workforce never imports Agent Runtime
 * implementation classes; it speaks only the titan.agent-runtime/1 wire format.
 */
final class AgentRuntimeGateway implements AgentRuntimeContract
{
    private const TITAN_AI_RUNTIME = 'App\\Extensions\\TitanAI\\System\\TitanAI\\Contracts\\TitanAIRuntimeContract';

    public function __construct(
        private readonly Container $container,
        private readonly FailClosedAgentRuntime $failClosed,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    public function execute(RuntimeRequest $request): RuntimeResponse
    {
        foreach ($this->controlPlane->bindingsFor('ai_runtime') as $binding) {
            if (! $this->container->bound($binding)) continue;
            if ($binding === self::TITAN_AI_RUNTIME) {
                return $this->container->make(TitanAIRuntimeAdapter::class)->execute($request);
            }
            try {
                $transport = $this->container->make($binding);
                if (! is_object($transport) || ! method_exists($transport, 'execute')) {
                    throw new \RuntimeException('Registered Titan Agent Runtime transport is invalid.');
                }
                $payload = $transport->execute($request->toArray());
                if (is_object($payload) && method_exists($payload, 'toArray')) $payload = $payload->toArray();
                if (! is_array($payload)) {
                    throw new \RuntimeException('Titan Agent Runtime transport returned a non-array response.');
                }
                return RuntimeResponse::fromArray($payload);
            } catch (Throwable $e) {
                return new RuntimeResponse(
                    status: 'failed',
                    failure: new RuntimeFailure(
                        code: 'agent_runtime_transport_failed',
                        message: 'Titan Agent Runtime transport failed.',
                        retryable: true,
                        details: ['exception_class' => $e::class, 'binding' => $binding],
                    ),
                    metadata: ['runtime_contract' => AgentRuntimeContract::PROTOCOL, 'execution_authority' => 'none'],
                );
            }
        }

        return $this->failClosed->execute($request);
    }
}
