<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceEvidence;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;
use RuntimeException;

/**
 * Read-only forensic projection over consequential Workforce activity.
 *
 * This service deliberately reuses the authoritative task, execution-attempt,
 * evidence and outcome ledgers. It does not create audit facts, alter control
 * plane decisions, or grant execution authority.
 */
final class WorkforceExecutionEvidenceExplorerService
{
    public const TYPES = [
        'task' => 'Task',
        'employee' => 'Employee',
        'execution_intent' => 'Execution intent',
        'risk_assessment' => 'Risk assessment',
        'assurance_result' => 'Assurance result',
        'governance_decision' => 'Governance decision',
        'autonomy_decision' => 'Autonomy decision',
        'command_bus_command' => 'Command Bus command',
        'execution_attempt' => 'Execution attempt',
        'receipt' => 'Receipt',
        'evidence' => 'Evidence',
        'state_verification' => 'State verification',
        'rewind_recovery' => 'Rewind recovery',
        'final_outcome' => 'Final outcome',
    ];

    /** @param array<string,mixed> $filters @return array<string,mixed> */
    public function snapshot(int $companyId, array $filters = []): array
    {
        if ($companyId <= 0) throw new RuntimeException('company_id must be positive.');

        $query = mb_strtolower(trim((string)($filters['q'] ?? '')));
        $type = trim((string)($filters['type'] ?? ''));
        if ($type !== '' && ! array_key_exists($type, self::TYPES)) $type = '';
        $taskId = max(0, (int)($filters['task'] ?? 0));
        $employeeId = max(0, (int)($filters['employee'] ?? 0));

        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->orderByDesc('updated_at')->limit(300)->get();
        $members = WorkforceMember::query()->forCompany($companyId)
            ->orderBy('name')->get()->keyBy('id');
        $attempts = WorkforceExecutionAttempt::query()->where('company_id', $companyId)
            ->orderByDesc('created_at')->limit(500)->get();
        $evidence = WorkforceEvidence::query()->forCompany($companyId)
            ->orderByDesc('observed_at')->limit(500)->get();
        $outcomes = WorkforceOutcome::query()->forCompany($companyId)
            ->orderByDesc('observed_at')->limit(500)->get();

        $taskMap = $tasks->keyBy('id');
        $rows = collect();

        foreach ($tasks as $task) {
            $member = $task->assignee_member_id ? $members->get((int)$task->assignee_member_id) : null;
            $base = $this->base($task, $member);
            $rows->push($this->row('task', 'Task', (string)$task->title, (string)($task->status?->value ?? $task->status), $base, [
                'task_uuid'=>$task->task_uuid, 'description'=>$task->description, 'capability'=>$task->capability,
            ], $task->updated_at));

            if (is_array($task->risk_snapshot) && $task->risk_snapshot !== []) {
                $rows->push($this->row('risk_assessment', 'Risk assessment', (string)$task->title, (string)($task->risk_snapshot['decision'] ?? $task->risk_snapshot['risk_level'] ?? $task->risk_level ?? 'RECORDED'), $base, $task->risk_snapshot, $task->updated_at));
            }
            if (is_array($task->assurance_snapshot) && $task->assurance_snapshot !== []) {
                $rows->push($this->row('assurance_result', 'Assurance result', (string)$task->title, (string)($task->assurance_snapshot['decision'] ?? $task->assurance_snapshot['status'] ?? 'RECORDED'), $base, $task->assurance_snapshot, $task->updated_at));
            }
            $governance = is_array($task->governance) ? $task->governance : [];
            $governanceDecision = data_get($governance, 'pre_execution.autonomy.governance_constraint.constraint')
                ?? data_get($governance, 'pre_execution.governance_constraint.constraint')
                ?? data_get($governance, 'pre_execution.governance_constraint');
            if (is_array($governanceDecision) && $governanceDecision !== []) {
                $rows->push($this->row('governance_decision', 'Governance decision', (string)$task->title, (string)($governanceDecision['decision'] ?? $governanceDecision['status'] ?? 'RECORDED'), $base, $governanceDecision, $task->updated_at));
            }
            if (is_array($task->autonomy_snapshot) && $task->autonomy_snapshot !== []) {
                $rows->push($this->row('autonomy_decision', 'Autonomy decision', (string)$task->title, (string)($task->autonomy_snapshot['decision'] ?? $task->autonomy_snapshot['status'] ?? 'RECORDED'), $base, $task->autonomy_snapshot, $task->updated_at));
            }
        }

        foreach ($members as $member) {
            $rows->push($this->row('employee', 'Employee', (string)$member->name, (string)($member->lifecycle_state?->value ?? $member->lifecycle_state ?? 'ACTIVE'), [
                'task_id'=>null, 'task_uuid'=>null, 'task_title'=>null, 'employee_id'=>(int)$member->id, 'employee_name'=>(string)$member->name,
                'task_url'=>null, 'employee_url'=>route('dashboard.user.titan-workforce.staff.show', $member),
            ], ['role_definition_id'=>$member->role_definition_id,'division_id'=>$member->division_id,'team_id'=>$member->team_id], $member->updated_at));
        }

        foreach ($attempts as $attempt) {
            $task = $taskMap->get((int)$attempt->task_id);
            if (! $task) continue;
            $member = $attempt->worker_member_id ? $members->get((int)$attempt->worker_member_id) : null;
            $base = $this->base($task, $member);
            $rows->push($this->row('execution_intent', 'Execution intent', (string)$task->title, 'LOCKED', $base, [
                'intent_id'=>$attempt->intent_id, 'intent_sha256'=>$attempt->intent_sha256, 'idempotency_key'=>$attempt->idempotency_key,
                'state_fingerprint'=>$attempt->state_fingerprint, 'expected_state'=>$attempt->expected_state,
            ], $attempt->created_at));
            $rows->push($this->row('command_bus_command', 'Command Bus command', (string)$task->title, (string)$attempt->status, $base, [
                'attempt_uuid'=>$attempt->attempt_uuid, 'command'=>$attempt->command_payload, 'dispatched_at'=>$attempt->dispatched_at?->toIso8601String(),
            ], $attempt->dispatched_at ?? $attempt->created_at));
            $rows->push($this->row('execution_attempt', 'Execution attempt', (string)$task->title, (string)$attempt->status, $base, [
                'attempt_uuid'=>$attempt->attempt_uuid, 'intent_id'=>$attempt->intent_id, 'receipt_ref'=>$attempt->receipt_ref,
                'verification_status'=>$attempt->verification_status,
            ], $attempt->updated_at));
            if (is_array($attempt->receipt) && $attempt->receipt !== [] || $attempt->receipt_ref) {
                $rows->push($this->row('receipt', 'Receipt', (string)$task->title, (string)($attempt->receipt['status'] ?? $attempt->status), $base, [
                    'receipt_ref'=>$attempt->receipt_ref, 'receipt_sha256'=>$attempt->receipt_sha256, 'receipt'=>$attempt->receipt,
                ], $attempt->verified_at ?? $attempt->updated_at));
            }
            if (is_array($attempt->state_revalidation) && $attempt->state_revalidation !== []) {
                $rows->push($this->row('state_verification', 'State verification', (string)$task->title, (bool)($attempt->state_revalidation['matches_expected'] ?? false) ? 'MATCHED' : 'MISMATCH', $base, $attempt->state_revalidation, $attempt->updated_at));
            }
            if (is_array($attempt->verification) && $attempt->verification !== []) {
                $rows->push($this->row('state_verification', 'State verification', (string)$task->title, (string)($attempt->verification_status ?? 'RECORDED'), $base, $attempt->verification, $attempt->verified_at ?? $attempt->updated_at));
            }
            if (is_array($attempt->recovery) && $attempt->recovery !== [] || $attempt->compensation_ref) {
                $rows->push($this->row('rewind_recovery', 'Rewind recovery', (string)$task->title, (string)($attempt->recovery['reason_code'] ?? $attempt->status), $base, [
                    'recovery'=>$attempt->recovery, 'compensation_ref'=>$attempt->compensation_ref,
                ], $attempt->updated_at));
            }
        }

        foreach ($evidence as $item) {
            $task = $item->task_id ? $taskMap->get((int)$item->task_id) : null;
            $member = $task?->assignee_member_id ? $members->get((int)$task->assignee_member_id) : null;
            $base = $task ? $this->base($task, $member) : ['task_id'=>null,'task_uuid'=>null,'task_title'=>null,'employee_id'=>$member?->id,'employee_name'=>$member?->name,'task_url'=>null,'employee_url'=>$member ? route('dashboard.user.titan-workforce.staff.show',$member) : null];
            $rows->push($this->row('evidence', 'Evidence', $task?->title ?? (string)$item->evidence_type, (string)$item->evidence_type, $base, [
                'evidence_uuid'=>$item->evidence_uuid, 'source_extension'=>$item->source_extension, 'reference'=>$item->reference,
                'content_sha256'=>$item->content_sha256, 'payload'=>$item->payload,
            ], $item->observed_at ?? $item->created_at));
        }

        foreach ($outcomes as $outcome) {
            $task = $outcome->task_id ? $taskMap->get((int)$outcome->task_id) : null;
            $member = $task?->assignee_member_id ? $members->get((int)$task->assignee_member_id) : null;
            $base = $task ? $this->base($task, $member) : ['task_id'=>null,'task_uuid'=>null,'task_title'=>null,'employee_id'=>$member?->id,'employee_name'=>$member?->name,'task_url'=>null,'employee_url'=>$member ? route('dashboard.user.titan-workforce.staff.show',$member) : null];
            $rows->push($this->row('final_outcome', 'Final outcome', $task?->title ?? (string)$outcome->outcome_type, (string)($outcome->status ?? ($outcome->verified_at ? 'VERIFIED' : 'OBSERVED')), $base, [
                'outcome_uuid'=>$outcome->outcome_uuid, 'outcome_type'=>$outcome->outcome_type, 'success'=>$outcome->success,
                'summary'=>$outcome->summary, 'evidence_refs'=>$outcome->evidence_refs, 'verified_at'=>$outcome->verified_at?->toIso8601String(),
            ], $outcome->verified_at ?? $outcome->observed_at ?? $outcome->created_at));
        }

        $filtered = $rows->filter(function (array $row) use ($query, $type, $taskId, $employeeId): bool {
            if ($type !== '' && $row['type'] !== $type) return false;
            if ($taskId > 0 && (int)($row['task_id'] ?? 0) !== $taskId) return false;
            if ($employeeId > 0 && (int)($row['employee_id'] ?? 0) !== $employeeId) return false;
            if ($query === '') return true;
            return str_contains(mb_strtolower($this->searchText($row)), $query);
        })->sortByDesc(fn(array $row) => (string)($row['timestamp'] ?? ''))->take(750)->values();

        return [
            'rows'=>$filtered,
            'types'=>self::TYPES,
            'tasks'=>$tasks->take(100)->values(),
            'employees'=>$members->values(),
            'filters'=>['q'=>(string)($filters['q'] ?? ''),'type'=>$type,'task'=>$taskId,'employee'=>$employeeId],
            'counts'=>$rows->groupBy('type')->map->count()->all(),
            'total'=>$filtered->count(),
            'authority_inherited' => false,
            'execution_authority_granted' => false,
            'generated_at'=>now()->toIso8601String(),
        ];
    }

    /** @return array<string,mixed> */
    private function base(WorkforceTask $task, ?WorkforceMember $member): array
    {
        return [
            'task_id'=>(int)$task->id,
            'task_uuid'=>(string)$task->task_uuid,
            'task_title'=>(string)$task->title,
            'employee_id'=>$member ? (int)$member->id : null,
            'employee_name'=>$member?->name,
            'task_url'=>route('dashboard.user.titan-workforce.tasks.show', $task),
            'employee_url'=>$member ? route('dashboard.user.titan-workforce.staff.show', $member) : null,
        ];
    }

    /** @param array<string,mixed> $base @param array<string,mixed> $payload @return array<string,mixed> */
    private function row(string $type, string $label, string $title, string $state, array $base, array $payload, mixed $timestamp): array
    {
        return array_merge($base, [
            'type'=>$type, 'type_label'=>$label, 'title'=>$title, 'state'=>$state,
            'timestamp'=>$timestamp?->toIso8601String(), 'payload'=>$payload,
            'authority_inherited' => false, 'execution_authority_granted' => false,
        ]);
    }

    /** @param array<string,mixed> $row */
    private function searchText(array $row): string
    {
        return implode(' ', [
            (string)($row['type_label'] ?? ''), (string)($row['title'] ?? ''), (string)($row['state'] ?? ''),
            (string)($row['task_uuid'] ?? ''), (string)($row['employee_name'] ?? ''),
            json_encode($row['payload'] ?? [], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?: '',
        ]);
    }
}
