<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Context\Adapters;

use App\Extensions\TitanAIWorkforce\System\Services\WorkforceBusinessContextProviderRegistry;
use App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts\ZeroBusinessContextReaderContract;
use RuntimeException;

/**
 * Adapts the existing Workforce provider-registry read ports for Zero.
 *
 * Zero never receives provider write access here. Provider version matching is
 * strict so context cannot silently drift to a different installed contract.
 */
final class ZeroWorkforceBusinessContextReader implements ZeroBusinessContextReaderContract
{
    public function __construct(private readonly WorkforceBusinessContextProviderRegistry $providers) {}

    public function supports(string $providerKey, string $providerVersion, string $surfaceId): bool
    {
        $provider = $this->providers->resolve($providerKey);
        return $provider !== null
            && $provider->providerVersion() === $providerVersion
            && $provider->supports($surfaceId);
    }

    public function read(
        int $companyId,
        string $providerKey,
        string $providerVersion,
        string $surfaceId,
        array $filters = [],
        int $limit = 50,
    ): array {
        if ($companyId <= 0) throw new RuntimeException('Zero business-context read requires company_id.');

        $provider = $this->providers->resolve($providerKey);
        if ($provider === null) throw new RuntimeException('Zero business-context provider adapter is unavailable.');
        if ($provider->providerVersion() !== $providerVersion) {
            throw new RuntimeException('Zero business-context provider version does not match the declared context route.');
        }
        if (! $provider->supports($surfaceId)) {
            throw new RuntimeException('Zero business-context provider does not support the requested surface.');
        }

        return $provider->read($companyId, $surfaceId, $filters, max(1, min($limit, 200)));
    }
}
