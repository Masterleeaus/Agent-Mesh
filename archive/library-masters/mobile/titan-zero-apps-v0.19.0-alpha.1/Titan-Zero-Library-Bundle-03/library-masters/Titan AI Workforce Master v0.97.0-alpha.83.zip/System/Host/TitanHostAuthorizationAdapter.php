<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Host;

use Throwable;

/** MagicAI-compatible authorization. Super Admin is the only unconditional platform bypass. */
final class TitanHostAuthorizationAdapter
{
    /** @param list<string> $delegatedAdminPermissions */
    public function allows(object $user, string $permission, array $delegatedAdminPermissions = []): bool
    {
        try { if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) return true; } catch (Throwable) {}
        try { if (method_exists($user, 'can') && $user->can($permission)) return true; } catch (Throwable) {}
        try { if (method_exists($user, 'checkPermission') && $user->checkPermission($permission)) return true; } catch (Throwable) {}
        try { if (method_exists($user, 'hasPermissionTo') && $user->hasPermissionTo($permission)) return true; } catch (Throwable) {}
        try {
            if (method_exists($user, 'isAdmin') && $user->isAdmin()) {
                return in_array($permission, $delegatedAdminPermissions, true);
            }
        } catch (Throwable) {}
        return false;
    }
}
