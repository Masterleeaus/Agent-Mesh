<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

/**
 * Canonical retry/reconciliation classifier.
 *
 * The central invariant is that a command with an uncertain post-dispatch
 * outcome MUST NOT be blindly retried. It must first be reconciled against
 * the authoritative provider/Command Bus receipt state.
 */
final class WorkforceRecoveryDecisionService
{
    /** @return array<string,mixed> */
    public function classify(array $failure): array
    {
        $phase = strtoupper((string) ($failure['phase'] ?? 'UNKNOWN'));
        $kind = strtoupper((string) ($failure['kind'] ?? 'UNKNOWN'));
        $receiptKnown = (bool) ($failure['receipt_known'] ?? false);
        $sideEffectPossible = (bool) ($failure['side_effect_possible'] ?? in_array($phase, ['DISPATCHING','EXECUTING','POST_DISPATCH'], true));
        $reversible = in_array(strtolower((string) ($failure['reversibility'] ?? 'irreversible')), ['reversible','compensatable'], true);

        if ($receiptKnown) {
            return [
                'state' => 'RECEIPT_AVAILABLE',
                'retry_allowed' => false,
                'reconciliation_required' => false,
                'compensation_eligible' => false,
                'reason_code' => 'AUTHORITATIVE_RECEIPT_AVAILABLE',
            ];
        }

        if (! $sideEffectPossible && in_array($phase, ['PREFLIGHT','AUTHORIZED','PRE_DISPATCH'], true)) {
            return [
                'state' => 'SAFE_RETRY',
                'retry_allowed' => true,
                'reconciliation_required' => false,
                'compensation_eligible' => false,
                'reason_code' => 'FAILED_BEFORE_SIDE_EFFECT',
            ];
        }

        if (in_array($kind, ['TIMEOUT','NETWORK_LOSS','CONNECTION_RESET','PROCESS_CRASH','PROVIDER_UNKNOWN'], true) || $sideEffectPossible) {
            return [
                'state' => 'UNKNOWN_OUTCOME',
                'retry_allowed' => false,
                'reconciliation_required' => true,
                'compensation_eligible' => $reversible,
                'reason_code' => 'POST_DISPATCH_OUTCOME_UNCERTAIN',
            ];
        }

        return [
            'state' => 'RECOVERY_REQUIRED',
            'retry_allowed' => false,
            'reconciliation_required' => true,
            'compensation_eligible' => false,
            'reason_code' => 'FAIL_CLOSED_RECOVERY_REQUIRED',
        ];
    }

    /** @return array<string,mixed> */
    public function duplicateDecision(string $idempotencyKey, ?array $existingReceipt, string $existingState): array
    {
        if (trim($idempotencyKey) === '') {
            return ['allowed' => false, 'reason_code' => 'IDEMPOTENCY_KEY_REQUIRED'];
        }
        if (is_array($existingReceipt) && $existingReceipt !== []) {
            return ['allowed' => false, 'reason_code' => 'DUPLICATE_RETURN_EXISTING_RECEIPT', 'receipt' => $existingReceipt];
        }
        if (in_array(strtoupper($existingState), ['EXECUTING','UNCERTAIN','RECONCILING'], true)) {
            return ['allowed' => false, 'reason_code' => 'DUPLICATE_EXECUTION_IN_FLIGHT_OR_UNCERTAIN'];
        }
        return ['allowed' => true, 'reason_code' => 'NO_PRIOR_SIDE_EFFECT_EVIDENCE'];
    }
}
