<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceGoalPlan;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityCapabilityRequirements;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final class WorkforceBusinessGoalPlanningService
{
    private const MAX_ITEMS = 100;
    private const MAX_DEPENDENCIES = 300;

    public function __construct(
        private readonly WorkforceGoalService $goals,
        private readonly WorkforceWorkItemService $workItems,
        private readonly WorkforceWorkItemOrchestrationGraphService $graph,
        private readonly WorkforceResponsibilityCapabilityRequirements $requirements,
        private readonly WorkforceProviderRoutingService $routing,
    ) {}

    public function draft(
        WorkforceMember $planner,
        array $objective,
        array $items,
        array $dependencies = [],
        array $assumptions = [],
        array $constraints = [],
        ?string $idempotencyKey = null,
    ): WorkforceGoalPlan {
        $this->assertPlanner($planner);
        $normalised = $this->normalise($objective, $items, $dependencies);
        $fingerprint = hash('sha256', json_encode([
            'company_id' => (int) $planner->company_id,
            'planner_member_id' => (int) $planner->id,
            'objective' => $normalised['objective'],
            'items' => $normalised['items'],
            'dependencies' => $normalised['dependencies'],
            'assumptions' => $assumptions,
            'constraints' => $constraints,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

        $idempotencyKey = trim((string) $idempotencyKey);
        $existing = WorkforceGoalPlan::query()->forCompany((int) $planner->company_id)
            ->where(function ($query) use ($fingerprint, $idempotencyKey): void {
                $query->where('plan_fingerprint', $fingerprint);
                if ($idempotencyKey !== '') $query->orWhere('idempotency_key', $idempotencyKey);
            })->first();
        if ($existing) return $existing;

        return WorkforceGoalPlan::query()->create([
            'plan_uuid' => (string) Str::uuid(),
            'company_id' => (int) $planner->company_id,
            'planner_member_id' => (int) $planner->id,
            'status' => 'DRAFT',
            'title' => (string) $normalised['objective']['title'],
            'objective' => $normalised['objective'],
            'assumptions' => array_values($assumptions),
            'constraints' => array_values($constraints),
            'plan_payload' => [
                'items' => $normalised['items'],
                'dependencies' => $normalised['dependencies'],
            ],
            'validation_report' => null,
            'plan_fingerprint' => $fingerprint,
            'idempotency_key' => $idempotencyKey !== '' ? $idempotencyKey : null,
        ]);
    }

    /** @return array<string,mixed> */
    public function validate(WorkforceGoalPlan $plan): array
    {
        if ($plan->status === 'COMMITTED') throw new InvalidArgumentException('Committed business plan is immutable.');
        $planner = WorkforceMember::query()->forCompany((int) $plan->company_id)->find((int) $plan->planner_member_id);
        if (! $planner) throw new RuntimeException('Business plan planner is unavailable.');
        $this->assertPlanner($planner);

        $payload = (array) $plan->plan_payload;
        $items = array_values((array) ($payload['items'] ?? []));
        $dependencies = array_values((array) ($payload['dependencies'] ?? []));
        $issues = [];
        $warnings = [];
        $routes = [];
        $seen = [];
        $assignees = [];

        foreach ($items as $index => $item) {
            $key = trim((string) ($item['key'] ?? ''));
            if ($key === '') {
                $issues[] = "Item {$index} has no stable key.";
                continue;
            }
            if (isset($seen[$key])) {
                $issues[] = "Duplicate Work Item key: {$key}.";
                continue;
            }
            $seen[$key] = true;

            $assigneeId = (int) ($item['assignee_member_id'] ?? 0);
            $assignee = $assigneeId > 0
                ? WorkforceMember::query()->forCompany((int) $plan->company_id)->find($assigneeId)
                : null;
            if (! $assignee || ! $assignee->is_active) {
                $issues[] = "{$key}: assignee is missing or inactive.";
                continue;
            }
            $assignees[$key] = $assignee;
            if (! $this->plannerCanCoordinate($planner, $assignee)) {
                $issues[] = "{$key}: planner is not in the assignee's management chain.";
                continue;
            }

            $responsibilityId = trim((string) ($item['responsibility_id'] ?? ''));
            $requirement = $this->requirements->forResponsibility($responsibilityId);
            if (! is_array($requirement)) {
                $issues[] = "{$key}: responsibility is not canonical.";
                continue;
            }
            if ((string) ($requirement['role_definition_id'] ?? '') !== (string) $assignee->role_definition_id) {
                $issues[] = "{$key}: responsibility does not belong to assignee role.";
                continue;
            }

            $capability = trim((string) ($item['capability'] ?? ''));
            if ($capability === '' || ! in_array($capability, (array) ($requirement['candidate_capabilities'] ?? []), true)) {
                $issues[] = "{$key}: capability is outside the responsibility contract.";
                continue;
            }
            if (! is_array($item['expected_outcome'] ?? null) || ($item['expected_outcome'] ?? []) === []) {
                $issues[] = "{$key}: explicit expected outcome is required.";
            }
            if (! is_array($item['evidence_requirements'] ?? null) || ($item['evidence_requirements'] ?? []) === []) {
                $issues[] = "{$key}: evidence requirements are required.";
            }

            try {
                $route = $this->routing->assertExecutableRoute(
                    $assignee,
                    $capability,
                    'capability',
                    isset($item['provider']) ? trim((string) $item['provider']) : null,
                );
                $routes[$key] = [
                    'provider' => (string) ($route['selected_provider'] ?? ''),
                    'provider_version' => (string) ($route['selected_provider_version'] ?? ''),
                    'selection_basis' => (string) ($route['selection_basis'] ?? ''),
                    'authority_inherited' => false,
                    'execution_authority_granted' => false,
                ];
            } catch (Throwable $e) {
                $issues[] = "{$key}: no deterministic live provider route - ".$e->getMessage();
            }
        }

        if (count($dependencies) > self::MAX_DEPENDENCIES) {
            $issues[] = 'Plan exceeds maximum dependency count.';
        }
        foreach ($dependencies as $index => $edge) {
            $from = trim((string) ($edge['from'] ?? ''));
            $to = trim((string) ($edge['to'] ?? ''));
            if ($from === '' || $to === '' || ! isset($seen[$from], $seen[$to])) {
                $issues[] = "Dependency {$index} references unknown Work Item keys.";
            } elseif ($from === $to) {
                $issues[] = "Dependency {$index} is self-referential.";
            }
            if (! in_array((string) ($edge['type'] ?? 'finish_to_start'), ['finish_to_start','finish_to_finish','start_to_start','start_to_finish'], true)) {
                $issues[] = "Dependency {$index} has an unsupported dependency type.";
            }
            if (! in_array((string) ($edge['failure_policy'] ?? 'block'), ['block','continue','escalate','compensate'], true)) {
                $issues[] = "Dependency {$index} has an unsupported failure policy.";
            }
        }
        if ($this->containsCycle(array_keys($seen), $dependencies)) {
            $issues[] = 'Business plan dependency graph contains a cycle.';
        }

        $objective = (array) $plan->objective;
        if (! is_array($objective['outcome_target'] ?? null) || ($objective['outcome_target'] ?? []) === []) {
            $issues[] = 'Goal requires an explicit outcome target.';
        }
        if (! is_array($objective['success_criteria'] ?? null) || ($objective['success_criteria'] ?? []) === []) {
            $issues[] = 'Goal requires measurable success criteria.';
        }

        if ($items === []) $issues[] = 'Business plan must contain at least one Work Item.';
        if (count($items) > self::MAX_ITEMS) $issues[] = 'Business plan exceeds maximum Work Item count.';
        if (($objective['target_at'] ?? null) === null) {
            $warnings[] = 'Goal has no target date.';
        }

        $report = [
            'valid' => $issues === [],
            'issue_count' => count($issues),
            'warning_count' => count($warnings),
            'issues' => $issues,
            'warnings' => $warnings,
            'item_count' => count($items),
            'dependency_count' => count($dependencies),
            'provider_routes' => $routes,
            'planner_member_id' => (int) $planner->id,
            'validated_at' => now()->toIso8601String(),
            'planning_grants_authority' => false,
            'validation_executes_work' => false,
        ];

        $plan->forceFill([
            'status' => $report['valid'] ? 'VALIDATED' : 'DRAFT',
            'validation_report' => $report,
        ])->save();

        return $report;
    }

    public function commit(WorkforceGoalPlan $plan): WorkforceGoalPlan
    {
        if ($plan->status === 'COMMITTED') return $plan;
        $report = $this->validate($plan->refresh());
        if (! $report['valid']) throw new InvalidArgumentException('Business plan has blocking validation issues.');

        $planner = WorkforceMember::query()->forCompany((int) $plan->company_id)->findOrFail((int) $plan->planner_member_id);
        $payload = (array) $plan->plan_payload;
        $objective = (array) $plan->objective;

        return DB::transaction(function () use ($plan, $planner, $payload, $objective, $report): WorkforceGoalPlan {
            $goal = $this->goals->create((int) $plan->company_id, [
                'origin_type' => 'business_goal_plan',
                'origin_id' => (string) $plan->plan_uuid,
                'title' => (string) $objective['title'],
                'description' => $objective['description'] ?? null,
                'priority' => (int) ($objective['priority'] ?? 50),
                'outcome_target' => (array) $objective['outcome_target'],
                'success_criteria' => (array) $objective['success_criteria'],
                'context_refs' => (array) ($objective['context_refs'] ?? []),
                'target_at' => $objective['target_at'] ?? null,
                'manager_member_id' => (int) $planner->id,
                'idempotency_key' => 'goal-plan:'.(string) $plan->plan_uuid,
                'metadata' => [
                    'goal_plan_uuid' => (string) $plan->plan_uuid,
                    'planning_grants_authority' => false,
                    'commit_dispatches_work' => false,
                ],
            ], $planner);

            $created = [];
            foreach ((array) ($payload['items'] ?? []) as $item) {
                $key = (string) $item['key'];
                $assignee = WorkforceMember::query()
                    ->forCompany((int) $plan->company_id)
                    ->findOrFail((int) $item['assignee_member_id']);

                $created[$key] = $this->workItems->create(
                    (int) $plan->company_id,
                    $goal,
                    $assignee,
                    [
                        'title' => (string) $item['title'],
                        'description' => $item['description'] ?? null,
                        'priority' => max(0, min(100, (int) ($item['priority'] ?? $objective['priority'] ?? 50))),
                        'responsibility_id' => (string) $item['responsibility_id'],
                        'capability' => (string) $item['capability'],
                        'capability_owner_extension' => $report['provider_routes'][$key]['provider'] ?? null,
                        'expected_outcome' => (array) $item['expected_outcome'],
                        'evidence_requirements' => (array) $item['evidence_requirements'],
                        'outcome_target_key' => $item['outcome_target_key'] ?? null,
                        'orchestration_group' => $item['orchestration_group'] ?? null,
                        'sequence_index' => $item['sequence_index'] ?? null,
                        'estimated_minutes' => $item['estimated_minutes'] ?? null,
                        'max_attempts' => $item['max_attempts'] ?? 3,
                        'retry_strategy' => $item['retry_strategy'] ?? 'exponential',
                        'compensation_capability' => $item['compensation_capability'] ?? null,
                        'deadline_at' => $item['deadline_at'] ?? $objective['target_at'] ?? null,
                        'manager_member_id' => (int) $planner->id,
                        'idempotency_key' => 'goal-plan:'.(string) $plan->plan_uuid.':'.$key,
                        'metadata' => [
                            'goal_plan_uuid' => (string) $plan->plan_uuid,
                            'goal_plan_item_key' => $key,
                            'planner_member_id' => (int) $planner->id,
                            'planning_grants_authority' => false,
                        ],
                    ],
                    $planner,
                );
            }

            foreach ((array) ($payload['dependencies'] ?? []) as $edge) {
                $from = (string) $edge['from'];
                $to = (string) $edge['to'];
                $this->graph->addDependency(
                    $created[$to],
                    $created[$from],
                    (string) ($edge['type'] ?? 'finish_to_start'),
                    (bool) ($edge['blocking'] ?? true),
                    (string) ($edge['failure_policy'] ?? 'block'),
                    (array) ($edge['condition'] ?? []),
                    [
                        'goal_plan_uuid' => (string) $plan->plan_uuid,
                        'source_item_key' => $from,
                        'target_item_key' => $to,
                        'planning_grants_authority' => false,
                    ],
                );
            }

            $graph = $this->graph->recalculateGoal((int) $plan->company_id, (int) $goal->id);
            $validation = (array) $plan->validation_report;
            $validation['committed_goal_id'] = (int) $goal->id;
            $validation['committed_goal_uuid'] = (string) $goal->goal_uuid;
            $validation['critical_path_task_ids'] = $graph['critical_path_task_ids'] ?? [];
            $validation['ready_task_ids'] = $graph['ready_task_ids'] ?? [];
            $validation['dispatch_required_separately'] = true;

            $plan->forceFill([
                'goal_id' => (int) $goal->id,
                'status' => 'COMMITTED',
                'validation_report' => $validation,
                'committed_at' => now(),
            ])->save();

            return $plan->refresh();
        });
    }

    /** @return array<string,mixed> */
    public function summary(WorkforceGoalPlan $plan): array
    {
        return [
            'plan_uuid' => (string) $plan->plan_uuid,
            'company_id' => (int) $plan->company_id,
            'planner_member_id' => (int) $plan->planner_member_id,
            'goal_id' => $plan->goal_id ? (int) $plan->goal_id : null,
            'status' => (string) $plan->status,
            'title' => (string) $plan->title,
            'objective' => $plan->objective,
            'item_count' => count((array) data_get($plan->plan_payload, 'items', [])),
            'dependency_count' => count((array) data_get($plan->plan_payload, 'dependencies', [])),
            'validation_report' => $plan->validation_report,
            'committed_at' => $plan->committed_at?->toIso8601String(),
            'dispatch_is_separate_governed_action' => true,
            'planning_grants_authority' => false,
        ];
    }

    /** @return array{objective:array<string,mixed>,items:list<array<string,mixed>>,dependencies:list<array<string,mixed>>} */
    private function normalise(array $objective, array $items, array $dependencies): array
    {
        $title = trim((string) ($objective['title'] ?? ''));
        if ($title === '') throw new InvalidArgumentException('Business objective requires a title.');

        $normalisedItems = [];
        foreach (array_values($items) as $index => $item) {
            if (! is_array($item)) throw new InvalidArgumentException("Work Item {$index} must be an object.");
            $key = trim((string) ($item['key'] ?? ''));
            $item['key'] = $key !== '' ? $key : 'item-'.($index + 1);
            $item['title'] = trim((string) ($item['title'] ?? ''));
            if ($item['title'] === '') throw new InvalidArgumentException("Work Item {$item['key']} requires a title.");
            $normalisedItems[] = $item;
        }

        $normalisedDependencies = [];
        foreach (array_values($dependencies) as $edge) {
            if (! is_array($edge)) throw new InvalidArgumentException('Dependency must be an object.');
            $normalisedDependencies[] = [
                'from' => trim((string) ($edge['from'] ?? '')),
                'to' => trim((string) ($edge['to'] ?? '')),
                'type' => (string) ($edge['type'] ?? 'finish_to_start'),
                'blocking' => (bool) ($edge['blocking'] ?? true),
                'failure_policy' => (string) ($edge['failure_policy'] ?? 'block'),
                'condition' => (array) ($edge['condition'] ?? []),
            ];
        }

        $objective['title'] = $title;
        $objective['priority'] = max(0, min(100, (int) ($objective['priority'] ?? 50)));
        $objective['context_refs'] = (array) ($objective['context_refs'] ?? []);

        return [
            'objective' => $objective,
            'items' => $normalisedItems,
            'dependencies' => $normalisedDependencies,
        ];
    }

    private function assertPlanner(WorkforceMember $planner): void
    {
        if ((int) $planner->company_id <= 0 || ! $planner->is_active) {
            throw new InvalidArgumentException('Business goal planner must be an active Workforce member.');
        }
        $role = strtolower((string) $planner->role_definition_id);
        $coordination = (array) ($planner->coordination_permissions ?? []);
        $explicit = (bool) ($coordination['plan_business_goals'] ?? false);
        if (! $explicit
            && ! str_contains($role, 'manager')
            && ! str_contains($role, 'office_manager')
            && $planner->reports()->count() === 0
            && ! $planner->is_permanent_system_role) {
            throw new InvalidArgumentException('Workforce member is not authorized to plan business goals.');
        }
    }

    private function plannerCanCoordinate(WorkforceMember $planner, WorkforceMember $assignee): bool
    {
        if ((int) $planner->company_id !== (int) $assignee->company_id) return false;
        if ((int) $planner->id === (int) $assignee->id) return true;
        $current = $assignee;
        $visited = [];
        for ($depth = 0; $depth < 20 && $current->manager_id; $depth++) {
            $managerId = (int) $current->manager_id;
            if (isset($visited[$managerId])) return false;
            $visited[$managerId] = true;
            if ($managerId === (int) $planner->id) return true;
            $current = WorkforceMember::query()->forCompany((int) $planner->company_id)->find($managerId);
            if (! $current) return false;
        }
        return false;
    }

    /** @param list<string> $nodes @param list<array<string,mixed>> $dependencies */
    private function containsCycle(array $nodes, array $dependencies): bool
    {
        $adjacency = array_fill_keys($nodes, []);
        $indegree = array_fill_keys($nodes, 0);
        foreach ($dependencies as $edge) {
            $from = trim((string) ($edge['from'] ?? ''));
            $to = trim((string) ($edge['to'] ?? ''));
            if (! isset($adjacency[$from], $adjacency[$to]) || $from === $to) continue;
            $adjacency[$from][] = $to;
            $indegree[$to]++;
        }
        $queue = [];
        foreach ($indegree as $node => $degree) if ($degree === 0) $queue[] = $node;
        $visited = 0;
        while ($queue !== []) {
            $node = array_shift($queue);
            $visited++;
            foreach ($adjacency[$node] as $next) {
                $indegree[$next]--;
                if ($indegree[$next] === 0) $queue[] = $next;
            }
        }
        return $visited !== count($nodes);
    }
}
