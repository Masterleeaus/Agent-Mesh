<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Runtime;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

/**
 * Cross-system identity envelope shared with Titan Agent Runtime and AI Chat Pro.
 *
 * user_id is an actor/interface identity only. company_id is the sole tenant boundary.
 */
final readonly class RuntimeIdentity
{
    public function __construct(
        public int $companyId,
        public ?int $userId = null,
        public ?int $workforceMemberId = null,
        public ?string $workforceRoleId = null,
        public ?int $workforceTaskId = null,
        public ?string $runtimeProfileId = null,
        public ?string $conversationId = null,
        public ?string $channelId = null,
        public ?string $sourceExtension = null,
        public ?string $capability = null,
        public ?string $capabilityVariant = null,
        public ?string $vertical = null,
        public ?string $workflowRef = null,
        public ?string $traceId = null,
        public ?string $correlationId = null,
        public ?string $causationId = null,
    ) {
        if ($companyId < 1) {
            throw new InvalidArgumentException('Runtime identity requires a valid company_id.');
        }
    }

    public static function fromTask(WorkforceTask $task, ?WorkforceMember $member = null, ?int $userId = null): self
    {
        $member ??= $task->assignee;
        if ((int) $task->company_id < 1) {
            throw new InvalidArgumentException('Workforce task is missing canonical company_id.');
        }
        if ($member !== null && (int) $member->company_id !== (int) $task->company_id) {
            throw new InvalidArgumentException('Workforce member and task company_id do not match.');
        }
        if ($member !== null && trim((string) $member->runtime_profile_id) === '') {
            throw new InvalidArgumentException('Workforce member is missing its governed runtime_profile_id binding.');
        }
        if ($member !== null && trim((string) $task->runtime_profile_id) !== '' && (string) $task->runtime_profile_id !== (string) $member->runtime_profile_id) {
            throw new InvalidArgumentException('Workforce task runtime_profile_id cannot override its assignee profile.');
        }

        return new self(
            companyId: (int) $task->company_id,
            userId: $userId,
            workforceMemberId: $member?->id,
            workforceRoleId: $member?->role_definition_id,
            workforceTaskId: $task->id,
            runtimeProfileId: $task->runtime_profile_id ?? $member?->runtime_profile_id,
            conversationId: $task->conversation_id,
            channelId: $task->channel_id,
            sourceExtension: $task->source_extension,
            capability: $task->capability,
            capabilityVariant: $task->capability_variant,
            vertical: $task->vertical,
            workflowRef: $task->workflow_ref,
            traceId: $task->trace_id,
            correlationId: $task->correlation_id,
            causationId: $task->causation_id,
        );
    }

    /** @return array<string, int|string|null> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'user_id' => $this->userId,
            'workforce_member_id' => $this->workforceMemberId,
            'workforce_role_id' => $this->workforceRoleId,
            'workforce_task_id' => $this->workforceTaskId,
            'runtime_profile_id' => $this->runtimeProfileId,
            'conversation_id' => $this->conversationId,
            'channel_id' => $this->channelId,
            'source_extension' => $this->sourceExtension,
            'capability' => $this->capability,
            'capability_variant' => $this->capabilityVariant,
            'vertical' => $this->vertical,
            'workflow_ref' => $this->workflowRef,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
        ];
    }
}
