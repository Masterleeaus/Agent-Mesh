<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceDomainHandoff extends Model
{
    protected $table='ext_titan_ai_workforce_domain_handoffs';
    protected $guarded=[];
    protected $casts=[
        'sequence'=>'integer','revision'=>'integer','incoming_state'=>'array','acceptance'=>'array',
        'knowledge_authority_receipt'=>'array','offered_at'=>'datetime','accepted_at'=>'datetime','rejected_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
