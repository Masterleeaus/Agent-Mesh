<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRelationship;
use Carbon\CarbonInterface;
use InvalidArgumentException;

final class ManagerContinuityService
{
    public function __construct(
        private readonly WorkforceGraphService $graph,
        private readonly WorkforceAuthorityGraphValidator $authorityGraph,
    ) {}

    public function appointDeputy(WorkforceMember $manager, WorkforceMember $deputy, ?CarbonInterface $expiresAt = null, array $scope = []): WorkforceRelationship
    {
        if ((int) $manager->company_id !== (int) $deputy->company_id) {
            throw new InvalidArgumentException('Cross-tenant deputy assignment rejected.');
        }
        if ((int) $manager->division_id !== (int) $deputy->division_id) {
            throw new InvalidArgumentException('Deputy must belong to the same division by default.');
        }
        if ((int) $manager->id === (int) $deputy->id) {
            throw new InvalidArgumentException('Manager cannot substitute for itself.');
        }
        if ((int) $manager->tier !== WorkforceTier::Manager->value || (int) $deputy->tier !== WorkforceTier::Manager->value) {
            throw new InvalidArgumentException('Deputy coverage is limited to Tier 1 Manager instances.');
        }
        if ($scope === []) {
            throw new InvalidArgumentException('Deputy scope is required.');
        }
        if ($expiresAt === null) {
            throw new InvalidArgumentException('Deputy expiry is required.');
        }
        if ($expiresAt->isPast()) {
            throw new InvalidArgumentException('Deputy expiry must be in the future.');
        }
        if (! $manager->is_active || ! $deputy->is_active) {
            throw new InvalidArgumentException('Manager and deputy must both be active when coverage is appointed.');
        }
        $this->authorityGraph->assertSubstitutionAcyclic((int) $manager->company_id, (int) $deputy->id, (int) $manager->id);

        return $this->graph->relate($deputy, $manager, WorkforceRelationshipType::SubstitutesFor, [
            'scope' => array_values(array_unique(array_map('strval', $scope))),
            'expires_at' => $expiresAt?->toIso8601String(),
            'authority_inherited' => false,
            'requires_existing_autonomy' => true,
        ]);
    }

    public function resolveReviewer(WorkforceMember $assignedManager, WorkforceMember $reviewer, string $scope): WorkforceMember
    {
        if ((int) $assignedManager->company_id !== (int) $reviewer->company_id) {
            throw new InvalidArgumentException('Cross-tenant manager continuity rejected.');
        }
        if ((int) $assignedManager->id === (int) $reviewer->id) {
            return $assignedManager;
        }
        if (! in_array($assignedManager->status, [WorkforceMemberStatus::Offline, WorkforceMemberStatus::Suspended, WorkforceMemberStatus::Blocked], true)) {
            throw new InvalidArgumentException('Deputy review is only permitted while the assigned Manager is unavailable.');
        }
        if (! $reviewer->is_active || in_array($reviewer->status, [WorkforceMemberStatus::Offline, WorkforceMemberStatus::Suspended], true)) {
            throw new InvalidArgumentException('Deputy is not currently available.');
        }
        if ((int) $assignedManager->division_id !== (int) $reviewer->division_id) {
            throw new InvalidArgumentException('Deputy must remain inside the assigned Manager division.');
        }

        $relationship = WorkforceRelationship::query()
            ->forCompany((int) $assignedManager->company_id)
            ->where('source_member_id', $reviewer->id)
            ->where('target_member_id', $assignedManager->id)
            ->where('relationship_type', WorkforceRelationshipType::SubstitutesFor->value)
            ->where('is_active', true)
            ->first();
        if (! $relationship) {
            throw new InvalidArgumentException('No active deputy relationship exists for this Manager.');
        }

        $metadata = $relationship->metadata ?? [];
        if (($metadata['authority_inherited'] ?? false) !== false) {
            throw new InvalidArgumentException('Invalid deputy relationship: authority inheritance is prohibited.');
        }
        $expiresAt = $metadata['expires_at'] ?? null;
        if (is_string($expiresAt) && $expiresAt !== '' && now()->greaterThan($expiresAt)) {
            throw new InvalidArgumentException('Deputy relationship has expired.');
        }
        $scopes = array_values(array_filter(array_map('strval', $metadata['scope'] ?? [])));
        if ($scopes !== [] && ! in_array($scope, $scopes, true)) {
            throw new InvalidArgumentException('Deputy relationship does not cover this review scope.');
        }

        return $reviewer;
    }
}
