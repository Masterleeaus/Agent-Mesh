<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class CoreWorkforceCatalog
{
    public static function divisions(): array
    {
        if (! function_exists('app')) return [];
        return app(WorkforceManifestRegistry::class)->divisions();
    }

    public static function roles(): array
    {
        return WorkforceRoleRegistry::keyed();
    }

    public static function visibleRoles(): array
    {
        return WorkforceRoleRegistry::keyed();
    }

    public static function systemRoles(): array
    {
        return [TitanZeroSystemRole::definition()];
    }

    /** Central AI Workforce no longer ships generic/domain Action Workers. */
    public static function actionWorkers(): array
    {
        return [];
    }
}
