<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceSchedule;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;

final class WorkforceProactiveRuntimeService
{
    public function __construct(private readonly WorkforceManifestRegistry $manifests) {}

    public function snapshot(int $companyId): array
    {
        $rows = WorkforceSchedule::query()->forCompany($companyId)->get();
        $byOwner = [];
        $orphaned = 0;
        $disabled = 0;
        foreach ($rows as $row) {
            $owner = trim((string) $row->owner_extension);
            if ($owner === '') {
                if ($row->is_active) $orphaned++;
                continue;
            }
            $byOwner[$owner] ??= [
                'active_schedules' => 0,
                'active_signal_triggers' => 0,
                'disabled' => 0,
                'due' => 0,
            ];
            if (! $row->is_active) {
                $byOwner[$owner]['disabled']++;
                $disabled++;
                continue;
            }
            if ($row->trigger_type === 'event') $byOwner[$owner]['active_signal_triggers']++;
            else $byOwner[$owner]['active_schedules']++;
            if ($row->trigger_type === 'schedule' && $row->next_run_at && $row->next_run_at->lte(now())) $byOwner[$owner]['due']++;
            if (! $row->routine_id || ! $row->routine_fingerprint || ! $row->role_definition_id) $orphaned++;
        }

        return [
            'company_id' => $companyId,
            'source' => 'extension_owned_workforce_manifests',
            'auto_execute_business_mutations' => false,
            'schedule_rows' => $rows->count(),
            'active_schedule_count' => $rows->where('is_active', true)->where('trigger_type', 'schedule')->count(),
            'active_signal_trigger_count' => $rows->where('is_active', true)->where('trigger_type', 'event')->count(),
            'disabled_count' => $disabled,
            'orphaned_provenance_count' => $orphaned,
            'by_owner_extension' => $byOwner,
            'manifest_health' => $this->manifests->health(),
        ];
    }
}
