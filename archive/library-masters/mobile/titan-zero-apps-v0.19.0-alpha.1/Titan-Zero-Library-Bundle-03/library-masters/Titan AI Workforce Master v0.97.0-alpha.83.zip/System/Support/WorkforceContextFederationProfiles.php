<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

use RuntimeException;

final class WorkforceContextFederationProfiles
{
    private const PATH = __DIR__.'/../../resources/workforce/context-federation-profiles.json';
    private ?array $document = null;

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->document !== null) return $this->document;
        if (! is_file(self::PATH)) throw new RuntimeException('Context federation profiles are missing.');
        $decoded = json_decode((string) file_get_contents(self::PATH), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded) || ($decoded['tenant_key'] ?? null) !== 'company_id') {
            throw new RuntimeException('Context federation profiles are invalid.');
        }
        return $this->document = $decoded;
    }

    /** @return array<string,mixed>|null */
    public function provider(string $providerKey): ?array
    {
        foreach ((array) ($this->all()['profiles'] ?? []) as $profile) {
            if (is_array($profile) && (string) ($profile['provider'] ?? '') === $providerKey) return $profile;
        }
        return null;
    }

    /** @return list<string> */
    public function providersWithRoutes(): array
    {
        $out = [];
        foreach ((array) ($this->all()['profiles'] ?? []) as $profile) {
            if (! is_array($profile) || count((array) ($profile['routes'] ?? [])) === 0) continue;
            $out[] = (string) $profile['provider'];
        }
        sort($out);
        return $out;
    }
}
