<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceResponsibility extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_responsibilities';
    protected $guarded = [];
    protected $casts = [
        'metadata' => 'array',
        'vertical_applicability' => 'array',
        'recommended_business_maturity' => 'array',
        'is_executable' => 'boolean',
    ];

    public function scopeVisibleToCompany($query, int $companyId) { return $query->where(function ($q) use ($companyId) { $q->whereNull('company_id')->orWhere('company_id', $companyId); }); }
}
