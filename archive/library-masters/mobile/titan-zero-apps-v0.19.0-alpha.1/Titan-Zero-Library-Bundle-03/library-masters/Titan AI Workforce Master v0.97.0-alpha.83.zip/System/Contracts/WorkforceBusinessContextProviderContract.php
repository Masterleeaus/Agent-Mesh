<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Contracts;

interface WorkforceBusinessContextProviderContract
{
    public function providerKey(): string;
    public function providerVersion(): string;
    public function supports(string $surfaceId): bool;

    /**
     * Return a normalized read envelope:
     * [
     *   'company_id' => int,
     *   'surface_id' => string,
     *   'items' => list<array<string,mixed>>,
     *   'observed_at' => ISO-8601 string,
     *   'provenance' => array<string,mixed>
     * ]
     *
     * Implementations MUST enforce company_id internally as well.
     */
    public function read(int $companyId, string $surfaceId, array $filters = [], int $limit = 50): array;
}
