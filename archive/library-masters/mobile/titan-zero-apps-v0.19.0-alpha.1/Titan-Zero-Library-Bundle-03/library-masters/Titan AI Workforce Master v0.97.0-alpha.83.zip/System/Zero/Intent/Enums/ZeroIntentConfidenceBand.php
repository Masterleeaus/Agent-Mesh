<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums;

enum ZeroIntentConfidenceBand: string
{
    case HIGH = 'high';
    case MEDIUM = 'medium';
    case LOW = 'low';
    case UNKNOWN = 'unknown';

    public static function fromScore(float $score): self
    {
        return match (true) {
            $score >= 0.80 => self::HIGH,
            $score >= 0.55 => self::MEDIUM,
            $score >= 0.30 => self::LOW,
            default => self::UNKNOWN,
        };
    }
}
