<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use RuntimeException;

final class WorkforceProviderContractReconciliationService
{
    private const REPORT = __DIR__.'/../../resources/workforce/provider-contract-reconciliation.json';
    private const SIGNALS = __DIR__.'/../../resources/workforce/provider-signal-classification.json';

    public function __construct(private readonly WorkforceEcosystemCapabilityRegistry $registry) {}

    /** @return array<string,mixed> */
    public function report(): array
    {
        if (! is_file(self::REPORT)) throw new RuntimeException('Workforce provider reconciliation report is missing.');
        $decoded = json_decode((string) file_get_contents(self::REPORT), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded) || ($decoded['summary']['provider_count'] ?? null) !== 38) {
            throw new RuntimeException('Workforce provider reconciliation report is invalid.');
        }
        return $decoded;
    }

    /** @return array<string,mixed> */
    public function provider(string $providerKey): array
    {
        $key = $this->registry->canonicalProviderKey($providerKey);
        foreach ((array) ($this->report()['providers'] ?? []) as $row) {
            if ((string) ($row['provider'] ?? '') === $key) return $row;
        }
        throw new RuntimeException("Provider {$providerKey} is not part of the reconciled platform.");
    }

    /** @return array<string,mixed> */
    public function signal(string $providerKey, string $eventType): array
    {
        $key = $this->registry->canonicalProviderKey($providerKey);
        if (! is_file(self::SIGNALS)) throw new RuntimeException('Provider signal classification is missing.');
        $decoded = json_decode((string) file_get_contents(self::SIGNALS), true, 512, JSON_THROW_ON_ERROR);
        foreach ((array) ($decoded['signals'] ?? []) as $row) {
            if ((string) ($row['provider'] ?? '') === $key && (string) ($row['event_type'] ?? '') === $eventType) {
                return $row;
            }
        }
        return [
            'provider' => $key,
            'event_type' => $eventType,
            'classification' => 'telemetry',
            'creates_work_by_default' => false,
            'company_rule_enablement_required' => false,
            'signal_grants_authority' => false,
        ];
    }

    public function assertNoBlockingIssues(): void
    {
        $report = $this->report();
        if ((int) ($report['summary']['invalid_role_binding_reference_count'] ?? -1) !== 0) {
            throw new RuntimeException('Provider reconciliation contains invalid role-binding references.');
        }
        if ((int) ($report['summary']['responsibility_without_provider_count'] ?? -1) !== 0) {
            throw new RuntimeException('Provider reconciliation contains responsibilities without providers.');
        }
    }
}
