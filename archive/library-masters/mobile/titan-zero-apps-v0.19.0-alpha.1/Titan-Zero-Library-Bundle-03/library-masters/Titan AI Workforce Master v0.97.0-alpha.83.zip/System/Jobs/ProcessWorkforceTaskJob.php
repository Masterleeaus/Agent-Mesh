<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Jobs;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Queue\Middleware\RestoreWorkforceTenantContext;
use App\Extensions\TitanAIWorkforce\System\Services\ChainOfCommandService;
use App\Extensions\TitanAIWorkforce\System\Services\ManagerOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\AgentWorkflowRuntimeBridge;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAIRuntimeBridge;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDependencyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceTaskService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceWorkItemOrchestrationGraphService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Throwable;

class ProcessWorkforceTaskJob implements ShouldQueue, ShouldBeUnique
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $uniqueFor = 600;
    public array $backoff = [30, 120, 300];

    public function __construct(public readonly int $companyId, public readonly int $taskId)
    {
        $this->onQueue('titan-workforce');
    }

    public function uniqueId(): string
    {
        return $this->companyId . ':' . $this->taskId;
    }

    public function middleware(): array
    {
        return [new RestoreWorkforceTenantContext($this->companyId)];
    }

    public function handle(
        WorkforceAIRuntimeBridge $runtime,
        WorkforceTaskService $tasks,
        ChainOfCommandService $chain,
        WorkforceDependencyService $dependencies,
        ManagerOperationsService $managerOperations,
        AgentWorkflowRuntimeBridge $legacyWorkflow,
        WorkforceWorkItemOrchestrationGraphService $orchestration,
    ): void {
        $task = WorkforceTask::query()->forCompany($this->companyId)->findOrFail($this->taskId);
        if ($task->status->terminal() || in_array($task->status, [WorkforceTaskStatus::UnderReview, WorkforceTaskStatus::ReceiverReview, WorkforceTaskStatus::Executing], true)) { return; }
        if (! $dependencies->ready($task)) {
            $tasks->record($task, null, 'task.waiting_dependencies', $task->status->value, $task->status->value, 'Blocking Workforce dependencies are not complete.');
            return;
        }
        if (! $task->assignee_member_id) {
            $tasks->record($task, null, 'task.unassigned', $task->status->value, $task->status->value, 'Task has no eligible assignee.');
            return;
        }
        $member = WorkforceMember::query()->forCompany($this->companyId)->where('is_active', true)->findOrFail($task->assignee_member_id);

        $task->increment('attempt_count');
        $tasks->transition($task, WorkforceTaskStatus::Processing, $member, 'task.processing_started');
        try {
            if ($legacyWorkflow->handles($task)) {
                $proposal = $legacyWorkflow->perform($task->refresh(), $member);
                $task->forceFill(['result' => ['agent_workflow' => $proposal]])->save();
                $tasks->transition($task->refresh(), WorkforceTaskStatus::Submitted, $member, 'task.agent_recipe_submitted', null, [
                    'workflow_run_id' => $proposal['workflow_run_id'] ?? null,
                    'awaiting_governance' => ($proposal['status'] ?? null) === 'awaiting_governance',
                    'business_outcome_claimed' => false,
                ]);
                if ($member->manager_id) {
                    $chain->submit($task->refresh(), $member);
                } else {
                    $tasks->record($task->refresh(), $member, 'manager.missing', 'SUBMITTED', 'SUBMITTED', 'Agent trigger task has no Manager; it cannot self-approve.');
                }
                return;
            }

            $proposal = $runtime->perform($task->refresh(), $member);
            $task->forceFill(['result' => ['proposal' => $proposal]])->save();

            if ($member->tier === WorkforceTier::Manager) {
                $managerOperations->decompose($task->refresh(), $member, $proposal);
                return;
            }

            $tasks->transition($task->refresh(), WorkforceTaskStatus::Submitted, $member, 'task.work_submitted', null, ['runtime_run_uuid' => $proposal['run_uuid'] ?? null]);
            if ($member->manager_id) {
                $chain->submit($task->refresh(), $member);
            } else {
                $tasks->record($task->refresh(), $member, 'manager.missing', 'SUBMITTED', 'SUBMITTED', 'Specialist has no Manager; work cannot self-approve.');
            }
        } catch (Throwable $e) {
            $fresh = $task->refresh();
            if (! $fresh->status->terminal() && $fresh->status !== WorkforceTaskStatus::Recovery) {
                $fresh->forceFill(['result' => array_merge($fresh->result ?? [], ['last_error' => $e->getMessage()])])->save();
                $fresh = $tasks->transition($fresh->refresh(), WorkforceTaskStatus::Recovery, $member, 'task.processing_failed', $e->getMessage());
                if ($fresh->work_item_uuid) {
                    $orchestration->propagateFailure($fresh, $member);
                }
            }
            throw $e;
        }
    }
}
