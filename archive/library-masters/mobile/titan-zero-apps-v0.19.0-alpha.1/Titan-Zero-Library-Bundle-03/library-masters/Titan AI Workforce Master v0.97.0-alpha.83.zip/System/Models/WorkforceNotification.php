<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceNotification extends Model
{
    protected $table = 'ext_titan_ai_workforce_notifications';
    protected $guarded = [];
    protected $casts = [
        'audience_scope' => 'array', 'metadata' => 'array', 'is_active' => 'boolean',
        'severity_score' => 'integer', 'priority_score' => 'integer', 'occurrence_count' => 'integer',
        'first_seen_at' => 'datetime', 'last_seen_at' => 'datetime', 'resolved_at' => 'datetime',
        'acknowledged_at' => 'datetime', 'acknowledged_by' => 'integer',
    ];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
