<?php

declare(strict_types=1);
namespace App\Extensions\TitanAIWorkforce\System\Models;
use Illuminate\Database\Eloquent\Model;
final class WorkforceResourceBudget extends Model {
 protected $table='ext_titan_ai_workforce_resource_budgets'; protected $guarded=[];
 protected $casts=['soft_limit'=>'float','hard_limit'=>'float','spent_amount'=>'float','autonomous_spend_ceiling'=>'float','metadata'=>'array'];
 public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);} }
