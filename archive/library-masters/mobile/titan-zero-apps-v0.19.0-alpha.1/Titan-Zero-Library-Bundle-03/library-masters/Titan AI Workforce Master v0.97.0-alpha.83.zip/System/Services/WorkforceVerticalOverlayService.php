<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Throwable;

final class WorkforceVerticalOverlayService
{
    private const ALLOWED_OVERLAY_KEYS = [
        'terminology','responsibilities','playbook_refs','workflow_refs','knowledge_scopes','capability_variants','metadata',
    ];

    public function resolve(int $companyId, array $context = []): array
    {
        foreach (['titan.vertical-engine','titan.vertical'] as $binding) {
            if (! app()->bound($binding)) {
                continue;
            }
            $service = app($binding);
            foreach (['workforceOverlay','resolveWorkforceOverlay','resolve'] as $method) {
                if (! method_exists($service, $method)) {
                    continue;
                }
                try {
                    $result = $service->{$method}([
                        'company_id' => $companyId,
                        'context' => $context,
                        'roles' => array_map(static fn (array $role): array => [
                            'role_id' => $role['role_id'], 'key' => $role['key'], 'division' => $role['division'],
                        ], WorkforceRoleRegistry::all()),
                    ]);
                    return [
                        'available' => true,
                        'binding' => $binding,
                        'method' => $method,
                        'overlay' => is_array($result) ? $result : [],
                    ];
                } catch (Throwable $e) {
                    return [
                        'available' => true,
                        'failed' => true,
                        'binding' => $binding,
                        'method' => $method,
                        'overlay' => [],
                        'error' => mb_substr($e->getMessage(), 0, 1000),
                    ];
                }
            }
        }
        return ['available' => false, 'overlay' => []];
    }

    public function applyToRole(array $role, array $overlay): array
    {
        $roleOverlay = $overlay[$role['role_id'] ?? ''] ?? $overlay[$role['key'] ?? ''] ?? [];
        if (! is_array($roleOverlay)) {
            return $role;
        }

        foreach (self::ALLOWED_OVERLAY_KEYS as $key) {
            if (! array_key_exists($key, $roleOverlay)) {
                continue;
            }
            if (is_array($roleOverlay[$key] ?? null) && is_array($role[$key] ?? null)) {
                if ($key === 'metadata') {
                    $role[$key] = array_merge($role[$key], $roleOverlay[$key]);
                } else {
                    $role[$key] = array_values(array_unique(array_merge($role[$key], $roleOverlay[$key]), SORT_REGULAR));
                }
            } else {
                $role[$key] = $roleOverlay[$key];
            }
        }

        // Vertical overlays may specialise presentation/procedure context but may not silently increase authority.
        unset($role['risk_ceiling_override'], $role['autonomy_override'], $role['capabilities_override']);
        return $role;
    }
}
