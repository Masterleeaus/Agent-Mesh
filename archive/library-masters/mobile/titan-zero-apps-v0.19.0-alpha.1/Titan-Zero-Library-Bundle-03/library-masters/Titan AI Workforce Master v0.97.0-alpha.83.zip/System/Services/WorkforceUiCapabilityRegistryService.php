<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceCapabilityState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;

/**
 * Canonical UI capability decision service.
 *
 * UI visibility is derived from the same live capability/provider, entitlement,
 * resource-scope and authority context used by the governed runtime. A UI
 * decision never grants execution authority; server-side execution rechecks all gates.
 */
final class WorkforceUiCapabilityRegistryService
{
    public function __construct(
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly WorkforceEntitlementService $entitlements,
    ) {}

    /** @return array<string,mixed> */
    public function decide(
        int $companyId,
        string $appSurface,
        string $interactionMode,
        string $capabilityId,
        string|WorkforceMember $roleOrMember,
        array $context = [],
    ): array {
        $requestedSurface = strtolower(trim($appSurface));
        $appSurface = $this->canonicalSurface($requestedSurface);
        $interactionMode = strtolower(trim($interactionMode));
        $capabilityId = trim($capabilityId);

        if ($companyId <= 0 || $capabilityId === '' || ! in_array($appSurface, ['zero','go','hub'], true)) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'hidden','INVALID_UI_CONTEXT',$context);
        }
        if (! in_array($interactionMode, ['touch','chat','voice','vision'], true)) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'hidden','UNSUPPORTED_INTERACTION_MODE',$context);
        }

        if ($roleOrMember instanceof WorkforceMember && (int) $roleOrMember->company_id !== $companyId) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'hidden','CROSS_COMPANY_UI_CONTEXT_REJECTED',$context);
        }

        if (($context['resource_relationship_allowed'] ?? true) !== true) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'hidden','RESOURCE_RELATIONSHIP_DENIED',$context);
        }
        if (($context['policy_allowed'] ?? true) !== true) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'disabled','POLICY_DENIED',$context);
        }

        $surfaceScope = $this->surfaceScopeDecision($appSurface, $context);
        if ($surfaceScope !== null) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'hidden',$surfaceScope,$context);
        }

        $capability = $this->availability->capabilityState($roleOrMember,$capabilityId,(array)($context['capability_policy']??[]));
        if (($capability['state'] ?? null) !== WorkforceCapabilityState::Available->value) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'unavailable',
                'CAPABILITY_NOT_LIVE',array_merge($context,['capability_state'=>$capability]));
        }

        $entitlement = trim((string)($context['entitlement_key']??''));
        if ($entitlement !== '' && ! $this->entitlements->has($companyId,$entitlement)) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'entitlement_required',
                'ENTITLEMENT_REQUIRED',array_merge($context,['required_entitlement'=>$entitlement]));
        }

        // Availability can show an action, but consequential execution authority is separate.
        if (($context['authority_allowed'] ?? true) !== true) {
            $state = ($context['can_request_approval'] ?? false) ? 'approval_required' : 'disabled';
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,$state,
                $state === 'approval_required' ? 'AUTHORITY_APPROVAL_REQUIRED' : 'AUTHORITY_DENIED',$context);
        }

        if (($context['offline'] ?? false) === true && ($context['offline_allowed'] ?? false) !== true) {
            return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'disabled','OFFLINE_AUTHORITY_DENIED',$context);
        }

        return $this->decision($companyId,$appSurface,$interactionMode,$capabilityId,'available','AVAILABLE',
            array_merge($context,['capability_state'=>$capability]));
    }

    /** @return array<string,mixed>|null */
    private function surfaceScopeDecision(string $surface, array $context): ?string
    {
        $audience = strtolower((string)($context['audience']??''));
        $scope = strtolower((string)($context['resource_scope']??''));

        if ($surface === 'hub' && in_array($scope,['company_internal','workforce_private','financial_company_wide'],true)) {
            return 'HUB_SCOPE_DENIED';
        }
        if ($surface === 'go' && in_array($scope,['company_wide_financial','owner_governance','unrestricted_staff_tracking'],true)) {
            return 'GO_SCOPE_DENIED';
        }
        if ($surface === 'zero' && in_array($audience,['customer','lead'],true)) {
            return 'BOS_AUDIENCE_DENIED';
        }
        if ($surface === 'go' && in_array($audience,['customer','lead'],true)) {
            return 'GO_AUDIENCE_DENIED';
        }
        return null;
    }

    private function canonicalSurface(string $surface): string
    {
        return match ($surface) {
            'titan_bos','titan-bos','bos','command','owner','manager','business','onboarding','setup','titan_onboarding','titan-onboarding' => 'zero',
            'titan_go','titan-go','field','worker' => 'go',
            'titan_hub','titan-hub','customer' => 'hub',
            default => $surface,
        };
    }

    /** @return array<string,mixed> */
    private function decision(int $companyId,string $surface,string $mode,string $capability,string $state,string $reason,array $context): array
    {
        return [
            'schema_version'=>'ui-capability-decision.v1',
            'company_id'=>$companyId,
            'app_surface'=>$surface,
            'canonical_surfaces'=>['zero','go','hub'],
            'interaction_mode'=>$mode,
            'capability_id'=>$capability,
            'state'=>$state,
            'reason_code'=>$reason,
            'provider_state'=>$context['capability_state']??null,
            'required_entitlement'=>$context['required_entitlement']??$context['entitlement_key']??null,
            'resource_scope'=>$context['resource_scope']??null,
            'execution_authority_granted'=>false,
            'server_recheck_required'=>true,
        ];
    }
}
