<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Jobs\ProcessWorkforceTaskJob;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

/** Converts Agent workflow action requests into governed Workforce tasks. */
final class AgentWorkflowProposalIngressService
{
    public function __construct(private readonly WorkforceTaskService $tasks) {}

    /** @return array<string,mixed> */
    public function receive(array $proposal): array
    {
        $companyId = (int) ($proposal['company_id'] ?? 0);
        if ($companyId <= 0) {
            throw new InvalidArgumentException('Agent workflow proposal requires company_id.');
        }
        if (($proposal['requires_governance'] ?? null) !== true) {
            throw new InvalidArgumentException('Agent workflow proposal must require governance.');
        }
        if (($proposal['execution_claimed'] ?? false) === true) {
            throw new InvalidArgumentException('Agent workflow proposal cannot claim execution.');
        }

        $workflowId = (int) ($proposal['workflow_id'] ?? 0);
        $runId = (int) ($proposal['workflow_run_id'] ?? 0);
        $stepRef = trim((string) ($proposal['step_ref'] ?? ''));
        $action = trim((string) ($proposal['action'] ?? ''));
        if ($workflowId <= 0 || $runId <= 0 || $stepRef === '' || $action === '') {
            throw new InvalidArgumentException('Agent workflow proposal identity is incomplete.');
        }

        $assignee = $this->resolveAssignee($companyId, $proposal);
        $parentTaskId = $this->resolveParentTaskId($companyId, $proposal);
        $arguments = is_array($proposal['arguments'] ?? null) ? $proposal['arguments'] : [];
        $argumentsHash = hash('sha256', json_encode($arguments, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?: '{}');
        $idempotencyKey = sprintf('agent-workflow:%d:%d:%d:%s:%s:%s', $companyId, $workflowId, $runId, $stepRef, $action, $argumentsHash);

        $task = $this->tasks->create($companyId, [
            'title' => 'Legacy Agent workflow proposal: ' . $action,
            'description' => 'Consequential Agent workflow step routed to Titan AI Workforce for governed evaluation.',
            'payload' => [
                'proposal_schema' => 'titan.agent-workflow-proposal/1',
                'legacy_agent_workflow_proposal' => $proposal,
                'requires_governance' => true,
                'execution_claimed' => false,
                'business_outcome_claimed' => false,
            ],
            'parent_task_id' => $parentTaskId,
            'assignee_member_id' => $assignee->id,
            'manager_member_id' => $assignee->manager_id,
            'division_id' => $assignee->division_id,
            'team_id' => $assignee->team_id,
            'origin_type' => 'agent_runtime_legacy_workflow',
            'origin_id' => $runId . ':' . $stepRef,
            'priority' => 50,
            'risk_level' => 'MEDIUM',
            'trace_id' => $proposal['trace_id'] ?? null,
            'correlation_id' => $proposal['correlation_id'] ?? null,
            'causation_id' => $proposal['causation_id'] ?? null,
            'idempotency_key' => $idempotencyKey,
            'metadata' => [
                'source_extension' => 'ai-agent',
                'workflow_id' => $workflowId,
                'workflow_run_id' => $runId,
                'legacy_step_ref' => $stepRef,
                'legacy_action' => $action,
            ],
        ], $assignee);

        ProcessWorkforceTaskJob::dispatch($companyId, (int) $task->id);

        return [
            'accepted' => true,
            'status' => 'queued_for_workforce',
            'workforce_task_id' => (int) $task->id,
            'workforce_task_uuid' => (string) $task->task_uuid,
            'requires_governance' => true,
            'execution_claimed' => false,
            'business_outcome_claimed' => false,
        ];
    }

    private function resolveAssignee(int $companyId, array $proposal): WorkforceMember
    {
        $memberId = (int) ($proposal['workforce_member_id'] ?? 0);
        if ($memberId > 0) {
            $member = WorkforceMember::query()->forCompany($companyId)->staffingSeats()->where('is_active', true)->find($memberId);
            if (! $member) {
                throw new InvalidArgumentException('Agent workflow proposal Workforce member does not belong to company or is inactive.');
            }
            return $member;
        }

        $manager = WorkforceMember::query()->forCompany($companyId)
            ->staffingSeats()
            ->where('is_active', true)
            ->where('tier', WorkforceTier::Manager->value)
            ->orderByRaw("CASE WHEN `key` = 'operations-manager' THEN 0 ELSE 1 END")
            ->first();
        if (! $manager) {
            throw new InvalidArgumentException('No eligible Workforce Manager is available for Agent workflow proposal.');
        }
        return $manager;
    }

    private function resolveParentTaskId(int $companyId, array $proposal): ?int
    {
        $taskId = (int) ($proposal['workforce_task_id'] ?? 0);
        if ($taskId <= 0) {
            return null;
        }
        $task = WorkforceTask::query()->forCompany($companyId)->find($taskId);
        if (! $task) {
            throw new InvalidArgumentException('Agent workflow proposal parent Workforce task does not belong to company.');
        }
        return (int) $task->id;
    }
}
