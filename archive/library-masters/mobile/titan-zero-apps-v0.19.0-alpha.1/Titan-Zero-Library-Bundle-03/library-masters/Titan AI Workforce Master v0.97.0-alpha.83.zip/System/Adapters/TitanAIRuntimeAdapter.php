<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Adapters;

use App\Extensions\TitanAIWorkforce\System\Contracts\AgentRuntimeContract;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeFailure;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeRequest;
use App\Extensions\TitanAIWorkforce\System\Runtime\RuntimeResponse;
use App\Extensions\TitanAI\System\TitanAI\Contracts\TitanAIRuntimeContract;
use App\Extensions\TitanAI\System\TitanAI\DTO\TitanAIRequest;
use Throwable;

/**
 * Canonical adapter from Titan AI runtime into the stable Workforce AgentRuntimeContract.
 */
final class TitanAIRuntimeAdapter implements AgentRuntimeContract
{
    public function __construct(private readonly TitanAIRuntimeContract $runtime) {}

    public function execute(RuntimeRequest $request): RuntimeResponse
    {
        $identity = $request->identity;

        try {
            $legacy = new TitanAIRequest(
                message: $request->instruction,
                companyId: $identity->companyId,
                userId: (string) ($identity->userId ?: 'system'),
                deviceId: 'server:workforce',
                channel: 'workforce',
                conversationSource: 'titan-workforce',
                conversationId: (string) ($request->metadata['legacy_conversation_id'] ?? $identity->conversationId ?? $identity->correlationId ?? ''),
                assistantDeploymentId: 'workforce:' . ($request->metadata['workforce_member_key'] ?? $identity->workforceMemberId ?? 'unknown'),
                template: 'workforce-task',
                workflowId: $request->metadata['workflow_id'] ?? $identity->workflowRef,
                idempotencyKey: $request->idempotencyKey,
                responseMode: $request->responseMode,
                payload: $request->payload + [
                    'runtime_identity' => $identity->toArray(),
                    'runtime_contract' => AgentRuntimeContract::PROTOCOL,
                ],
                toolPermissions: $request->toolPermissions,
                availablePermissions: [],
                actorType: 'ai-workforce-member',
                actorId: (string) ($request->metadata['workforce_member_key'] ?? $identity->workforceMemberId ?? 'unknown'),
            );

            $result = $this->runtime->execute($legacy)->toArray();

            return new RuntimeResponse(
                status: 'completed',
                output: is_array($result) ? $result : ['result' => $result],
                runUuid: isset($result['run_uuid']) ? (string) $result['run_uuid'] : null,
                metadata: ['adapter' => 'titan-ai', 'execution_authority' => 'none'],
            );
        } catch (Throwable $e) {
            return new RuntimeResponse(
                status: 'failed',
                failure: new RuntimeFailure(
                    code: 'titan_ai_runtime_failed',
                    message: 'Titan AI runtime adapter failed.',
                    retryable: true,
                    details: ['exception_class' => $e::class],
                ),
                metadata: ['adapter' => 'titan-ai', 'execution_authority' => 'none'],
            );
        }
    }
}
