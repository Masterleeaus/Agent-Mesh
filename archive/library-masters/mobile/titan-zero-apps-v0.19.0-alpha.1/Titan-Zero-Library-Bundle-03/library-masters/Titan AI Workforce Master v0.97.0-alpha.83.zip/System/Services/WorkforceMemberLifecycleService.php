<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberLifecycleState;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use Illuminate\Support\Str;
use InvalidArgumentException;

/**
 * Tenant staff-instance lifecycle over extension-owned RoleDefinitions.
 *
 * This service never invents role authority. Capabilities, tool/workflow refs,
 * risk ceiling, starting earned Autonomy ceiling, tier, division and team are
 * copied from a currently valid installed Workforce manifest definition.
 */
final class WorkforceMemberLifecycleService
{
    public function __construct(
        private readonly WorkforceManifestRegistry $registry,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
        private readonly WorkforceBootstrapService $bootstrap,
        private readonly WorkforceManifestLifecycleService $definitionLifecycle,
        private readonly WorkforceGraphService $graph,
        private readonly WorkforceSignalBridge $signals,
        private readonly RuntimeProfileBindingService $runtimeProfiles,
    ) {}

    /** @param array<string,mixed> $input */
    public function activateFromDefinition(
        int $companyId,
        string $ownerExtension,
        string $roleDefinitionId,
        array $input,
        ?int $actorUserId = null,
    ): WorkforceMember {
        $definition = $this->assertRoleDefinitionAvailable($ownerExtension, $roleDefinitionId);
        $capabilityPolicy = is_array($input['capability_policy'] ?? null) ? (array) $input['capability_policy'] : [];
        $capabilityState = $this->capabilityAvailability->forRole((string) $definition['role_id'], $capabilityPolicy);
        $access = (array) ($capabilityState['effective_access'] ?? []);
        $containers = $this->bootstrap->ensureDivisions($companyId);

        $divisionKey = (string) ($definition['division'] ?? '');
        $teamKey = (string) ($definition['team'] ?? '');
        $division = $containers[$divisionKey]
            ?? WorkforceDivision::query()->forCompany($companyId)->where('key', $divisionKey)->where('is_active', true)->first();
        if (! $division) throw new InvalidArgumentException('The RoleDefinition division is not available for this tenant.');

        $team = WorkforceTeam::query()
            ->forCompany($companyId)
            ->where('division_id', $division->id)
            ->where('key', $teamKey)
            ->where('is_active', true)
            ->first();
        if ($teamKey !== '' && ! $team) throw new InvalidArgumentException('The RoleDefinition team is not available for this tenant.');

        $manager = $this->assertManagerConstraint($companyId, $definition, isset($input['manager_id']) ? (int) $input['manager_id'] : null);
        $startingBand = (string) data_get($definition, 'autonomy_profile.starting_level', 'Suggest');
        $startingScore = (int) data_get($definition, 'autonomy_profile.starting_score', 0);
        $desiredBand = (string) data_get($definition, 'autonomy_profile.desired_level', $startingBand);
        $desiredScore = (int) data_get($definition, 'autonomy_profile.desired_score', $startingScore);
        $trace = (string) Str::uuid();

        $member = WorkforceMember::query()->create([
            'company_id' => $companyId,
            'created_by_user_id' => $actorUserId,
            'activated_by_user_id' => $actorUserId,
            'division_id' => $division->id,
            'team_id' => $team?->id,
            'manager_id' => $manager?->id,
            'tier' => (int) $definition['tier'],
            'key' => trim((string) ($input['key'] ?? '')) !== ''
                ? trim((string) $input['key'])
                : Str::slug((string) $input['name']).'-'.Str::lower(Str::random(6)),
            'name' => trim((string) $input['name']),
            'role' => (string) $definition['name'],
            'purpose' => (string) ($definition['purpose'] ?? ''),
            'responsibilities' => array_values(array_map('strval', $definition['responsibilities'] ?? [])),
            'goals' => array_values(array_filter(array_map('strval', (array) ($input['goals'] ?? [])))),
            'capabilities' => $access['capabilities'],
            'capability_variants' => [],
            'skills' => array_values(array_map('strval', $definition['skills'] ?? [])),
            'playbooks' => array_values(array_map('strval', $definition['playbooks'] ?? [])),
            'interaction_wizards' => array_values(array_map('strval', $definition['interaction_wizards'] ?? [])),
            'knowledge_scopes' => array_values(array_map('strval', $definition['knowledge_scopes'] ?? [])),
            'memory_scopes' => array_values(array_map('strval', $definition['memory_scopes'] ?? [])),
            'provider_preferences' => (array) ($input['provider_preferences'] ?? []),
            'model_preferences' => (array) ($input['model_preferences'] ?? []),
            'schedule_config' => (array) ($input['schedule_config'] ?? []),
            'workload_config' => (array) ($input['workload_config'] ?? []),
            'escalation_policy' => (array) ($input['escalation_policy'] ?? []),
            'risk_ceiling' => (string) ($definition['risk_ceiling'] ?? 'LOW'),
            'autonomy_references' => [
                'authority_source' => 'titan_autonomy',
                'initial_band' => $startingBand,
                'initial_score' => $startingScore,
                'desired_band' => $desiredBand,
                'desired_score' => $desiredScore,
                'effective_authority' => null,
                'self_promotion' => false,
            ],
            'assurance_references' => ['required' => (string) ($input['assurance_required'] ?? 'AMBER')],
            'performance_history' => [],
            'status' => WorkforceMemberStatus::Available,
            'lifecycle_state' => WorkforceMemberLifecycleState::Active,
            'lifecycle_changed_at' => now(),
            'activated_at' => now(),
            'suspended_at' => null,
            'retired_at' => null,
            'replaced_by_member_id' => null,
            'lifecycle_metadata' => [
                'activation_actor_user_id' => $actorUserId,
                'activation_trace_id' => $trace,
                'local_instructions' => trim((string) ($input['local_instructions'] ?? '')),
            ],
            'is_active' => true,
            ...$this->definitionLifecycle->pinFieldsForRole($definition),
            'role_owner_extension' => 'titan-ai-workforce',
            'role_owner_extension_version' => 'intrinsic',
            'maturity_level' => (string) ($definition['maturity_default'] ?? data_get($definition, 'maturity.default', 'JUNIOR')),
            'max_concurrent_tasks' => max(1, (int) data_get($definition, 'workload.max_concurrent', 5)),
            'substitution_enabled' => (bool) ($definition['substitution_allowed'] ?? true),
            'metadata' => [
                'definition_source' => 'intrinsic_workforce_catalogue',
                'owner_extension' => 'titan-ai-workforce',
                'owner_extension_version' => 'intrinsic',
                'definition_fingerprint' => (string) $definition['definition_fingerprint'],
                'capability_providers' => $access['providers'],
                'tool_access' => $access['tools'],
                'command_access' => $access['commands'],
                'signal_subscriptions' => $access['signals'],
                'data_sources' => $access['data_sources'],
                'workflow_refs' => $access['workflows'] ?? [],
                'capability_policy' => $capabilityPolicy,
                'capability_state_snapshot' => $capabilityState,
                'capability_state_snapshot_is_authoritative' => false,
                'authority_inherited' => false,
                'fallback_authority_granted' => false,
            ],
        ]);

        $profile = $this->runtimeProfiles->ensureForMember($member, $definition, $input);
        $member->forceFill(['runtime_profile_id' => (string) $profile->profile_id])->save();

        if ($manager) $this->graph->setManager($member, $manager);

        $this->signals->emit($companyId, 'workforce.member.activated', [
            'member_id' => $member->id,
            'owner_extension' => $definition['owner_extension'],
            'role_definition_id' => $definition['role_id'],
            'definition_fingerprint' => $definition['definition_fingerprint'],
            'lifecycle_state' => WorkforceMemberLifecycleState::Active->value,
        ], $trace, $trace, null);

        return $member->refresh();
    }

    public function suspend(int $companyId, WorkforceMember $member, ?int $actorUserId = null, ?string $reason = null): WorkforceMember
    {
        $this->assertTenant($companyId, $member);
        $this->assertNotPermanentSystemRole($member);
        $this->transition($member, WorkforceMemberLifecycleState::Suspended);
        $meta = is_array($member->lifecycle_metadata) ? $member->lifecycle_metadata : [];
        $meta['suspended_by_user_id'] = $actorUserId;
        $meta['suspension_reason'] = $reason;
        $meta['previous_operational_status'] = $member->status?->value ?? (string) $member->status;
        $member->forceFill([
            'lifecycle_state' => WorkforceMemberLifecycleState::Suspended,
            'lifecycle_changed_at' => now(),
            'suspended_at' => now(),
            'status' => WorkforceMemberStatus::Suspended,
            'is_active' => false,
            'lifecycle_metadata' => $meta,
        ])->save();
        $this->emit($member, 'workforce.member.suspended', $reason);
        return $member->refresh();
    }

    public function resume(int $companyId, WorkforceMember $member, ?int $actorUserId = null): WorkforceMember
    {
        $this->assertTenant($companyId, $member);
        if (in_array((string) $member->role_definition_state, ['MISSING','BREAKING'], true)) {
            throw new InvalidArgumentException('Staff cannot resume while its RoleDefinition is missing or breaking.');
        }
        $this->assertPinnedRoleDefinitionAvailable($member);
        $this->transition($member, WorkforceMemberLifecycleState::Active);
        $meta = is_array($member->lifecycle_metadata) ? $member->lifecycle_metadata : [];
        $meta['resumed_by_user_id'] = $actorUserId;
        $member->forceFill([
            'lifecycle_state' => WorkforceMemberLifecycleState::Active,
            'lifecycle_changed_at' => now(),
            'suspended_at' => null,
            'status' => WorkforceMemberStatus::Available,
            'is_active' => true,
            'lifecycle_metadata' => $meta,
        ])->save();
        $this->emit($member, 'workforce.member.resumed');
        return $member->refresh();
    }

    public function retire(int $companyId, WorkforceMember $member, ?WorkforceMember $replacement = null, ?int $actorUserId = null, ?string $reason = null): WorkforceMember
    {
        $this->assertTenant($companyId, $member);
        $this->assertNotPermanentSystemRole($member);
        if ($replacement) {
            $this->assertTenant($companyId, $replacement);
            if ((int) $replacement->id === (int) $member->id) throw new InvalidArgumentException('A staff member cannot replace itself.');
            if (! $replacement->is_active || $replacement->lifecycle_state !== WorkforceMemberLifecycleState::Active) throw new InvalidArgumentException('Replacement staff must be active.');
            if ((string) $replacement->role_owner_extension !== (string) $member->role_owner_extension || (string) $replacement->role_definition_id !== (string) $member->role_definition_id) {
                throw new InvalidArgumentException('Replacement staff must instantiate the same extension-owned RoleDefinition.');
            }
        }
        $this->transition($member, WorkforceMemberLifecycleState::Retired);
        $meta = is_array($member->lifecycle_metadata) ? $member->lifecycle_metadata : [];
        $meta['retired_by_user_id'] = $actorUserId;
        $meta['retirement_reason'] = $reason;
        $member->forceFill([
            'lifecycle_state' => WorkforceMemberLifecycleState::Retired,
            'lifecycle_changed_at' => now(),
            'retired_at' => now(),
            'replaced_by_member_id' => $replacement?->id,
            'status' => WorkforceMemberStatus::Offline,
            'is_active' => false,
            'lifecycle_metadata' => $meta,
        ])->save();
        // Historical tasks, reviews, handoffs and receipts deliberately remain owned by this member.
        $this->emit($member, 'workforce.member.retired', $reason, ['replaced_by_member_id' => $replacement?->id]);
        return $member->refresh();
    }

    /** @return array<string,mixed> */
    public function assertRoleDefinitionAvailable(string $ownerExtension, string $roleDefinitionId): array
    {
        $ownerExtension = trim($ownerExtension);
        $roleDefinitionId = trim($roleDefinitionId);
        if ($roleDefinitionId === '') throw new InvalidArgumentException('An exact Workforce RoleDefinition is required.');
        if ($ownerExtension !== '' && $ownerExtension !== 'titan-ai-workforce') {
            throw new InvalidArgumentException('New staff must be activated from a Workforce-owned intrinsic RoleDefinition.');
        }
        $definition = WorkforceRoleRegistry::find($roleDefinitionId);
        if (! $definition || ! in_array((string) ($definition['definition_source'] ?? ''), ['intrinsic_workforce_catalogue','intrinsic_executive_catalogue'], true)) {
            throw new InvalidArgumentException('The requested intrinsic Workforce RoleDefinition is not available.');
        }
        return $definition;
    }

    private function assertPinnedRoleDefinitionAvailable(WorkforceMember $member): void
    {
        if ((string) $member->role_owner_extension === 'titan-ai-workforce') {
            $this->assertRoleDefinitionAvailable('titan-ai-workforce', (string) $member->role_definition_id);
            return;
        }
        // Compatibility only for staff instantiated before intrinsic-role convergence.
        $legacy = $this->registry->findOwnedRole((string) $member->role_owner_extension, (string) $member->role_definition_id);
        if (! $legacy) throw new InvalidArgumentException('The pinned legacy RoleDefinition is unavailable.');
    }

    /** @param array<string,mixed> $definition */
    public function assertManagerConstraint(int $companyId, array $definition, ?int $managerId): ?WorkforceMember
    {
        $reportsTo = trim((string) ($definition['parent_manager'] ?? $definition['reports_to'] ?? ''));
        if ($reportsTo === '') {
            if ($managerId) throw new InvalidArgumentException('This RoleDefinition reports to Titan AI Core / owner and cannot be assigned an arbitrary manager.');
            return null;
        }
        if (! $managerId) throw new InvalidArgumentException('This RoleDefinition requires its declared manager role.');
        $manager = WorkforceMember::query()->forCompany($companyId)->findOrFail($managerId);
        if (! $manager->is_active || $manager->lifecycle_state !== WorkforceMemberLifecycleState::Active) throw new InvalidArgumentException('The selected manager is not active.');
        if ((string) $manager->role_owner_extension !== 'titan-ai-workforce' || (string) $manager->role_definition_id !== $reportsTo) {
            throw new InvalidArgumentException('The selected manager does not satisfy the RoleDefinition reporting contract.');
        }
        return $manager;
    }

    private function assertNotPermanentSystemRole(WorkforceMember $member): void
    {
        if ((bool) ($member->is_permanent_system_role ?? false)) {
            throw new InvalidArgumentException('Permanent Workforce system roles cannot be suspended or retired.');
        }
    }

    private function assertTenant(int $companyId, WorkforceMember $member): void
    {
        if ((int) $member->company_id !== $companyId) throw new InvalidArgumentException('Cross-tenant staff lifecycle mutation rejected.');
    }

    private function transition(WorkforceMember $member, WorkforceMemberLifecycleState $target): void
    {
        $current = $member->lifecycle_state instanceof WorkforceMemberLifecycleState
            ? $member->lifecycle_state
            : WorkforceMemberLifecycleState::tryFrom((string) $member->lifecycle_state) ?? WorkforceMemberLifecycleState::Active;
        if (! $current->canTransitionTo($target)) throw new InvalidArgumentException("Invalid staff lifecycle transition {$current->value} -> {$target->value}.");
    }

    /** @param array<string,mixed> $extra */
    private function emit(WorkforceMember $member, string $eventType, ?string $reason = null, array $extra = []): void
    {
        $trace = (string) Str::uuid();
        $this->signals->emit((int) $member->company_id, $eventType, array_merge([
            'member_id' => $member->id,
            'owner_extension' => $member->role_owner_extension,
            'role_definition_id' => $member->role_definition_id,
            'definition_fingerprint' => $member->role_definition_fingerprint,
            'lifecycle_state' => $member->lifecycle_state?->value ?? (string) $member->lifecycle_state,
            'reason' => $reason,
        ], $extra), $trace, $trace, null);
    }
}
