<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceDecisionStageRole: string
{
    case OriginReviewer = 'ORIGIN_REVIEWER';
    case DomainProcessor = 'DOMAIN_PROCESSOR';
    case ReceivingChecker = 'RECEIVING_CHECKER';
}
