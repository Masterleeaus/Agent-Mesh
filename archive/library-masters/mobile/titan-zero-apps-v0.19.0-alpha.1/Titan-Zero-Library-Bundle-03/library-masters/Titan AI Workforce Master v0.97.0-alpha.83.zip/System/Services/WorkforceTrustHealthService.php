<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Collection;

final class WorkforceTrustHealthService
{
    public function forCompany(int $companyId): array
    {
        $tasks = WorkforceTask::query()->forCompany($companyId)
            ->whereNotIn('status', ['COMPLETED','FAILED','CANCELLED','REJECTED'])
            ->get(['division_id','status','risk_level','risk_snapshot','assurance_snapshot','autonomy_snapshot','governance']);

        $divisions = WorkforceDivision::query()->forCompany($companyId)->get(['id','key','name']);
        $rows = [];
        foreach ($divisions as $division) {
            $rows[] = $this->summarise($tasks->where('division_id', $division->id)->values(), [
                'division_id' => $division->id,
                'division_key' => $division->key,
                'division_name' => $division->name,
            ]);
        }

        return [
            'company_id' => $companyId,
            'organisation' => $this->summarise($tasks, ['division_id' => null, 'division_key' => 'all', 'division_name' => 'Organisation']),
            'divisions' => $rows,
        ];
    }

    private function summarise(Collection $tasks, array $identity): array
    {
        $risk = array_fill_keys(['MINIMAL','LOW','MEDIUM','HIGH','EXTREME','UNKNOWN'], 0);
        $assurance = array_fill_keys(['GREEN','AMBER','RED','UNKNOWN'], 0);
        $autonomy = ['allowed' => 0, 'blocked' => 0, 'unknown' => 0];
        $engineAvailability = ['risk' => 0, 'assurance' => 0, 'autonomy' => 0, 'complete' => 0, 'incomplete' => 0];
        $status = ['blocked' => 0, 'recovery' => 0, 'escalated' => 0, 'total_open' => $tasks->count()];

        foreach ($tasks as $task) {
            $riskLevel = strtoupper((string) data_get($task->risk_snapshot ?? [], 'level', $task->risk_level ?: 'UNKNOWN'));
            $risk[array_key_exists($riskLevel, $risk) ? $riskLevel : 'UNKNOWN']++;

            $assuranceState = strtoupper((string) data_get($task->assurance_snapshot ?? [], 'state', 'UNKNOWN'));
            $assurance[array_key_exists($assuranceState, $assurance) ? $assuranceState : 'UNKNOWN']++;

            $allowed = data_get($task->autonomy_snapshot ?? [], 'allowed');
            if ($allowed === true) $autonomy['allowed']++;
            elseif ($allowed === false) $autonomy['blocked']++;
            else $autonomy['unknown']++;

            $availability = (array) data_get($task->governance ?? [], 'pre_execution.engine_availability', []);
            foreach (['risk','assurance','autonomy'] as $engine) {
                if (($availability[$engine] ?? false) === true) $engineAvailability[$engine]++;
            }
            if (data_get($task->governance ?? [], 'pre_execution.governance_complete') === true) $engineAvailability['complete']++;
            elseif (data_get($task->governance ?? [], 'pre_execution') !== null) $engineAvailability['incomplete']++;

            $rawStatus = $task->status;
            $taskStatus = strtoupper($rawStatus instanceof WorkforceTaskStatus ? $rawStatus->value : (string) $rawStatus);
            if ($taskStatus === 'BLOCKED') $status['blocked']++;
            if ($taskStatus === 'RECOVERY') $status['recovery']++;
            if ($taskStatus === 'ESCALATED') $status['escalated']++;
        }

        $severity = 'HEALTHY';
        if ($risk['EXTREME'] > 0 || $status['recovery'] > 0) $severity = 'CRITICAL';
        elseif ($risk['HIGH'] > 0 || $assurance['RED'] > 0 || $status['escalated'] > 0) $severity = 'DEGRADED';
        elseif ($risk['MEDIUM'] > 0 || $assurance['AMBER'] > 0 || $status['blocked'] > 0 || $engineAvailability['incomplete'] > 0) $severity = 'WATCH';

        return array_merge($identity, [
            'state' => $severity,
            'risk' => $risk,
            'assurance' => $assurance,
            'autonomy' => $autonomy,
            'engine_availability' => $engineAvailability,
            'blocked' => $status['blocked'],
            'recovery' => $status['recovery'],
            'escalated' => $status['escalated'],
            'total_open' => $status['total_open'],
        ]);
    }
}
