<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCapabilityBindingRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceControlPlaneIntegrationRegistry;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

final class WorkforceExecutionIntentService
{
    public function __construct(
        private readonly WorkforceCapabilityBindingRegistry $manifests,
        private readonly WorkforceControlPlaneIntegrationRegistry $controlPlane,
    ) {}

    /** @return array{attempt:WorkforceExecutionAttempt,capability:array<string,mixed>,replayed:bool} */
    public function lock(WorkforceTask $task, WorkforceMember $worker, array $command): array
    {
        return DB::transaction(function () use ($task, $worker, $command): array {
            $locked = WorkforceTask::query()->forCompany((int) $task->company_id)->lockForUpdate()->findOrFail($task->id);
            if ((int) $locked->assignee_member_id !== (int) $worker->id) throw new RuntimeException('Execution worker no longer owns this task.');

            $owner = trim((string) ($locked->capability_owner_extension ?? ''));
            $capabilityName = trim((string) ($locked->capability ?? $command['capability'] ?? ''));
            if ($owner === '' && $capabilityName !== '') {
                $owners = $this->manifests->ownersForCapability((string) $worker->role_definition_id, $capabilityName);
                if (count($owners) > 1) throw new RuntimeException('Capability owner is ambiguous for this intrinsic role.');
                $owner = count($owners) === 1 ? $owners[0] : '';
            }
            $variant = $locked->capability_variant ?: ($command['variant'] ?? null);
            $capability = $owner !== '' && $capabilityName !== '' ? $this->manifests->findOwnedCapability($owner, $capabilityName, is_string($variant) ? $variant : null) : null;
            if (! is_array($capability)) throw new RuntimeException('Current extension-owned capability contract is unavailable.');
            if (($capability['mutation_mode'] ?? null) !== 'command_bus_only') throw new RuntimeException('Capability is not authorized for Command Bus mutation execution.');

            $expectedState = $command['expected_state'] ?? data_get($locked->metadata ?? [], 'expected_state') ?? data_get($locked->governance ?? [], 'expected_state');
            if (! is_array($expectedState) || $expectedState === []) throw new RuntimeException('Expected authoritative domain state is required before consequential execution.');

            $stateFingerprint = hash('sha256', $this->canonicalJson($expectedState));
            $intentPayload = [
                'company_id' => (int) $locked->company_id,
                'task_id' => (string) $locked->task_uuid,
                'worker_member_id' => (int) $worker->id,
                'owner_extension' => $owner,
                'owner_extension_version' => (string) ($capability['owner_extension_version'] ?? ''),
                'capability' => $capabilityName,
                'capability_variant' => $variant,
                'state_fingerprint' => $stateFingerprint,
                'command' => $this->stableCommand($command),
            ];
            $intentSha = hash('sha256', $this->canonicalJson($intentPayload));
            $idempotencyKey = 'wfexec:'.substr($intentSha, 0, 56);

            $existing = WorkforceExecutionAttempt::query()
                ->where('company_id', $locked->company_id)
                ->where('idempotency_key', $idempotencyKey)
                ->lockForUpdate()
                ->first();
            if ($existing) return ['attempt' => $existing, 'capability' => $capability, 'replayed' => true];

            $attempt = WorkforceExecutionAttempt::query()->create([
                'attempt_uuid' => (string) Str::uuid(),
                'company_id' => $locked->company_id,
                'task_id' => $locked->id,
                'worker_member_id' => $worker->id,
                'capability_owner_extension' => $owner,
                'capability_owner_extension_version' => (string) ($capability['owner_extension_version'] ?? ''),
                'intent_id' => (string) Str::uuid(),
                'intent_sha256' => $intentSha,
                'state_fingerprint' => $stateFingerprint,
                'idempotency_key' => $idempotencyKey,
                'command_payload' => $this->stableCommand($command),
                'expected_state' => $expectedState,
                'status' => 'INTENT_LOCKED',
            ]);
            return ['attempt' => $attempt, 'capability' => $capability, 'replayed' => false];
        });
    }

    /** @return array<string,mixed> */
    public function stateRevalidation(WorkforceExecutionAttempt $attempt, WorkforceTask $task, WorkforceMember $worker): array
    {
        $resolved = $this->controlPlane->resolve('command_bus');
        if ($resolved === null) return $this->storeRevalidation($attempt, false, 'COMMAND_BUS_UNAVAILABLE');
        $bus = $resolved['service'];
        $payload = [
            'company_id' => (int) $task->company_id,
            'trace_id' => (string) $task->trace_id,
            'correlation_id' => (string) $task->correlation_id,
            'task_id' => (string) $task->task_uuid,
            'capability' => (string) $task->capability,
            'capability_owner_extension' => (string) ($task->capability_owner_extension ?? ''),
            'intent_id' => (string) $attempt->intent_id,
            'intent_sha256' => (string) $attempt->intent_sha256,
            'state_fingerprint' => (string) $attempt->state_fingerprint,
            'expected_state' => $attempt->expected_state ?? [],
            'actor_member_id' => (int) $worker->id,
        ];

        foreach (['revalidate','preflight','inspectState'] as $method) {
            if (! method_exists($bus, $method)) continue;
            try { $result = $bus->{$method}($payload); }
            catch (Throwable) { return $this->storeRevalidation($attempt, false, 'STATE_REVALIDATION_FAILED'); }
            if (is_object($result) && method_exists($result, 'toArray')) $result = $result->toArray();
            if (! is_array($result)) return $this->storeRevalidation($attempt, false, 'STATE_REVALIDATION_INVALID');
            $matches = array_key_exists('matches_expected', $result) ? (bool) $result['matches_expected'] : null;
            if ($matches === null && is_array($result['current_state'] ?? null)) {
                $matches = hash_equals((string) $attempt->state_fingerprint, hash('sha256', $this->canonicalJson($result['current_state'])));
            }
            if ($matches !== true) return $this->storeRevalidation($attempt, false, 'STATE_CHANGED', $result);
            return $this->storeRevalidation($attempt, true, 'STATE_MATCHED', $result);
        }
        return $this->storeRevalidation($attempt, false, 'STATE_REVALIDATION_UNSUPPORTED');
    }

    private function storeRevalidation(WorkforceExecutionAttempt $attempt, bool $matches, string $reason, array $result = []): array
    {
        $value = array_merge($result, ['available' => $reason !== 'COMMAND_BUS_UNAVAILABLE', 'matches_expected' => $matches, 'reason_code' => $reason]);
        $attempt->forceFill(['state_revalidation' => $value, 'status' => $matches ? 'STATE_VALIDATED' : 'STATE_CHANGED'])->save();
        return $value;
    }

    private function stableCommand(array $command): array
    {
        unset($command['state_revalidation'], $command['receipt'], $command['runtime_result']);
        return $this->canonical($command);
    }

    private function canonicalJson(array $value): string
    {
        return json_encode($this->canonical($value), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
    }

    private function canonical(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn ($item) => $this->canonical($item), $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = $this->canonical($item);
        return $value;
    }
}
