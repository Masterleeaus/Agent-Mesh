<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceRelationshipType;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use RuntimeException;

/** Synchronises only already-active executive/manager instances; it never hires staff or transfers domain authority. */
final class ExecutiveLayerService
{
    public const BUSINESS_MANAGER_ROLE_DEFINITION_ID = 'titan.executive.business_manager';
    public const TITAN_ZERO_ROLE_DEFINITION_ID = 'titan.system.titan_zero';
    /** @var array<string,mixed>|null */
    private ?array $hierarchy = null;

    public function __construct(
        private readonly TitanZeroChiefOfStaffService $titanZero,
        private readonly WorkforceGraphService $graph,
    ) {}

    /** @return array<string,mixed> */
    public function blueprint(): array
    {
        if ($this->hierarchy !== null) return $this->hierarchy;
        $path = dirname(__DIR__, 2) . '/resources/workforce/executive-hierarchy.json';
        if (! is_file($path)) throw new RuntimeException('Canonical executive hierarchy is missing.');
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (! is_array($decoded)
            || ($decoded['owner_interface_role_definition_id'] ?? null) !== self::TITAN_ZERO_ROLE_DEFINITION_ID
            || ($decoded['business_manager_role_definition_id'] ?? null) !== self::BUSINESS_MANAGER_ROLE_DEFINITION_ID) {
            throw new RuntimeException('Canonical executive hierarchy identity drift detected.');
        }
        return $this->hierarchy = $decoded;
    }

    /**
     * Align existing active members to the executive blueprint. No member is auto-created.
     * @return array{business_manager_present:bool,division_managers_linked:int,internal_coordinator_linked:bool,operations_coordination_links:int}
     */
    public function synchroniseForCompany(int $companyId): array
    {
        if ($companyId <= 0) throw new \InvalidArgumentException('Executive layer requires a valid company_id.');
        $blueprint = $this->blueprint();
        $zero = $this->titanZero->ensureForCompany($companyId);
        $businessManager = WorkforceMember::query()->forCompany($companyId)
            ->where('role_definition_id', self::BUSINESS_MANAGER_ROLE_DEFINITION_ID)
            ->where('is_active', true)->first();
        if (! $businessManager) {
            return ['business_manager_present'=>false,'division_managers_linked'=>0,'internal_coordinator_linked'=>false,'operations_coordination_links'=>0];
        }

        $this->linkReporting($businessManager, $zero, 'executive_layer');
        $linked = 0;
        $managerMembers = [];
        foreach ((array) ($blueprint['division_manager_role_definition_ids'] ?? []) as $roleId) {
            $member = WorkforceMember::query()->forCompany($companyId)->where('role_definition_id', (string) $roleId)->where('is_active', true)->first();
            if (! $member) continue;
            $this->linkReporting($member, $businessManager, 'executive_division_manager');
            $this->graph->relate($businessManager, $member, WorkforceRelationshipType::Coordinates, [
                'source' => 'executive_division_coordination',
                'coordination_only' => true,
                'authority_inherited' => false,
            ]);
            $managerMembers[(string) $roleId] = $member;
            $linked++;
        }

        $internalLinked = false;
        $internalRoleId = (string) ($blueprint['internal_executive_coordination_role_definition_id'] ?? '');
        if ($internalRoleId !== '') {
            $internal = WorkforceMember::query()->forCompany($companyId)->where('role_definition_id', $internalRoleId)->where('is_active', true)->first();
            if ($internal) {
                $this->linkReporting($internal, $businessManager, 'executive_internal_coordination');
                $internalLinked = true;
            }
        }

        $opsLinks = 0;
        $operationsRoleId = (string) ($blueprint['operations_coordination_role_definition_id'] ?? '');
        $operationsManager = $managerMembers[$operationsRoleId] ?? null;
        if ($operationsManager) {
            foreach ($managerMembers as $roleId => $manager) {
                if ($roleId === $operationsRoleId) continue;
                $this->graph->relate($operationsManager, $manager, WorkforceRelationshipType::Coordinates, [
                    'source' => 'executive_operational_coordination',
                    'coordination_only' => true,
                    'authority_inherited' => false,
                ]);
                $opsLinks++;
            }
        }

        return ['business_manager_present'=>true,'division_managers_linked'=>$linked,'internal_coordinator_linked'=>$internalLinked,'operations_coordination_links'=>$opsLinks];
    }

    private function linkReporting(WorkforceMember $member, WorkforceMember $manager, string $source): void
    {
        if ((int) $member->company_id !== (int) $manager->company_id) throw new \InvalidArgumentException('Cross-tenant executive relationship rejected.');
        $this->graph->assertNoReportingCycle($member, $manager);
        $member->forceFill(['manager_id' => $manager->id])->save();
        $metadata = ['source'=>$source,'authority_inherited'=>false,'coordination_only'=>true];
        $this->graph->relate($member, $manager, WorkforceRelationshipType::ReportsTo, $metadata);
        $this->graph->relate($manager, $member, WorkforceRelationshipType::Manages, $metadata);
        $this->graph->relate($manager, $member, WorkforceRelationshipType::ReviewsFor, $metadata);
    }
}
