<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class WorkforceOrganisation extends Model
{
    use SoftDeletes;

    protected $table = 'ext_titan_ai_workforce_organisations';
    protected $guarded = [];
    protected $casts = ['metadata' => 'array'];

    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
