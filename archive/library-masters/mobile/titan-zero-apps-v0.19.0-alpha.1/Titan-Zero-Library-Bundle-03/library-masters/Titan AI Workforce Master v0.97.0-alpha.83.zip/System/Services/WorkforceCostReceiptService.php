<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceCostReceipt;

final class WorkforceCostReceiptService
{
    /** @param array<string,mixed> $data */
    public function record(array $data): WorkforceCostReceipt
    {
        $forbidden=['api_key','secret','access_token','refresh_token','credential','password'];
        $payload=json_encode($data);
        foreach ($forbidden as $needle) {
            if (stripos((string)$payload, $needle) !== false && ! str_contains(strtolower((string)$payload), 'secret_reference')) {
                throw new \InvalidArgumentException('Cost receipts must not contain provider credentials or secrets.');
            }
        }
        return WorkforceCostReceipt::query()->create($data);
    }
}
