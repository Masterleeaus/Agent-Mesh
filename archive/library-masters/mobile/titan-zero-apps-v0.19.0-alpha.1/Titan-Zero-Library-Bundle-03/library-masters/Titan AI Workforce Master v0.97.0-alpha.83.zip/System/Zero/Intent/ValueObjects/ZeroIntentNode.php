<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects;

use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums\ZeroIntentConfidenceBand;
use InvalidArgumentException;

final readonly class ZeroIntentNode
{
    /**
     * @param list<array{intent:string,confidence:float}> $alternatives
     * @param array<string,mixed> $entities
     * @param array<string,mixed> $parameters
     * @param list<string> $dependsOn
     * @param array<string,mixed>|null $condition
     * @param list<string> $missingParameters
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public string $nodeId,
        public string $intent,
        public float $confidence,
        public string $source,
        public array $alternatives = [],
        public array $entities = [],
        public array $parameters = [],
        public array $dependsOn = [],
        public ?array $condition = null,
        public bool $requiresClarification = false,
        public array $missingParameters = [],
        public array $metadata = [],
    ) {
        if (trim($this->nodeId) === '') throw new InvalidArgumentException('Intent node_id is required.');
        if (trim($this->intent) === '') throw new InvalidArgumentException('Intent name is required.');
        if ($this->confidence < 0.0 || $this->confidence > 1.0) throw new InvalidArgumentException('Intent confidence must be between 0 and 1.');
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'node_id' => $this->nodeId,
            'intent' => $this->intent,
            'confidence' => round($this->confidence, 6),
            'confidence_band' => ZeroIntentConfidenceBand::fromScore($this->confidence)->value,
            'source' => $this->source,
            'alternatives' => $this->alternatives,
            'entities' => $this->entities,
            'parameters' => $this->parameters,
            'depends_on' => $this->dependsOn,
            'condition' => $this->condition,
            'requires_clarification' => $this->requiresClarification,
            'missing_parameters' => $this->missingParameters,
            'metadata' => $this->metadata,
        ];
    }
}
