<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceReviewerResolution extends Model
{
    protected $table = 'ext_titan_ai_workforce_reviewer_resolutions';
    protected $guarded = [];
    protected $casts = [
        'selection_score'=>'decimal:2',
        'score_breakdown'=>'array',
        'candidate_evidence'=>'array',
        'rejection_reasons'=>'array',
        'resolved_at'=>'datetime',
    ];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id',$companyId);
    }
}
