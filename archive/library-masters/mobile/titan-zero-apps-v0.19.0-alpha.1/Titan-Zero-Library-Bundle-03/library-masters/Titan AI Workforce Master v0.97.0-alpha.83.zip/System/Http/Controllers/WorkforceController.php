<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Http\Controllers;

use App\Extensions\TitanAIWorkforce\System\Enums\DeadlockResolution;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceMemberStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTaskStatus;
use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceTier;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTaskHandoff;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceStaffingProposal;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceNotification;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;
use App\Extensions\TitanAIWorkforce\System\Services\ChainOfCommandService;
use App\Extensions\TitanAIWorkforce\System\Services\QueuePriorityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDelegationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceGraphService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceBootstrapService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceTaskService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePlanningService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePlanningIntelligenceService;
use App\Extensions\TitanAIWorkforce\System\Services\ProactiveResponsibilityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceQueueHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProactiveRuntimeService;
use App\Extensions\TitanAIWorkforce\System\Services\ManagerOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkloadSharingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCouncilService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCouncilOperationsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDisputeService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceTrustHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceVerticalOverlayService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceControlRoomService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCommandDashboardService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEmployeeProfileService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOrganisationMapService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOperationalWorkspaceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceWorkCommandCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceVisualWorkGraphService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManagerCommandCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceResponsibilitiesCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceProactiveOperationsCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCapabilityHealthInspectorService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceSafeDegradationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAttentionCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceNotificationRoutingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePerformanceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforcePerformanceCoachingService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceStaffingProposalService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceManifestLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceMemberLifecycleService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceCapabilityAvailabilityService;
use App\Extensions\TitanAIWorkforce\System\Services\ManagerContinuityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDecisionRightsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDecisionRightsCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDelegationCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceEscalationDeadlockCenterService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceGovernancePipelineVisualizerService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceExecutionEvidenceExplorerService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceJourneyTimelineService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOutcomeIntelligenceService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceConversationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceContextualConversationService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceSetupWizardService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceSystemHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceControlSettingsService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceAuditExportService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceReleaseReadinessService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceDependencyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceJourneySpineService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceOutcomeHealthService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainObservabilityService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainLearningPolicyService;
use App\Extensions\TitanAIWorkforce\System\Services\WorkforceChainPolicyAdminService;
use App\Extensions\TitanAIWorkforce\System\Support\CompanyContext;
use App\Extensions\TitanAIWorkforce\System\Host\TitanHostAuthorizationAdapter;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforcePermissions;
use App\Extensions\TitanAIWorkforce\System\Support\CoreWorkforceCatalog;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceResponsibilityRegistry;
use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use InvalidArgumentException;
use Illuminate\View\View;
use Carbon\CarbonImmutable;

class WorkforceController extends Controller
{
    public function __construct(
        private readonly WorkforceBootstrapService $bootstrap,
        private readonly WorkforceTaskService $tasks,
        private readonly ChainOfCommandService $chain,
        private readonly QueuePriorityService $priority,
        private readonly WorkforceDelegationService $delegation,
        private readonly WorkforceGraphService $graph,
        private readonly WorkforcePlanningService $planning,
        private readonly WorkforcePlanningIntelligenceService $planningIntelligence,
        private readonly ProactiveResponsibilityService $responsibilities,
        private readonly WorkforceQueueHealthService $queueHealth,
        private readonly WorkforceProactiveRuntimeService $proactiveRuntime,
        private readonly ManagerOperationsService $managerOperations,
        private readonly WorkloadSharingService $workloadSharing,
        private readonly WorkforceCouncilService $councils,
        private readonly WorkforceCouncilOperationsService $councilOperations,
        private readonly WorkforceDisputeService $disputes,
        private readonly WorkforceTrustHealthService $trustHealth,
        private readonly WorkforceVerticalOverlayService $verticalOverlay,
        private readonly WorkforceControlRoomService $controlRoomService,
        private readonly WorkforceCommandDashboardService $commandDashboard,
        private readonly WorkforceEmployeeProfileService $employeeProfile,
        private readonly WorkforceOrganisationMapService $organisationMap,
        private readonly WorkforceOperationalWorkspaceService $operationalWorkspace,
        private readonly WorkforceWorkCommandCenterService $workCommandCenter,
        private readonly WorkforceVisualWorkGraphService $visualWorkGraph,
        private readonly WorkforceManagerCommandCenterService $managerCommandCenter,
        private readonly WorkforceResponsibilitiesCenterService $responsibilitiesCenter,
        private readonly WorkforceProactiveOperationsCenterService $proactiveOperationsCenter,
        private readonly WorkforceCapabilityHealthInspectorService $capabilityHealthInspector,
        private readonly WorkforceSafeDegradationService $safeDegradation,
        private readonly WorkforceAttentionCenterService $attentionCenterService,
        private readonly WorkforceNotificationRoutingService $notificationRouting,
        private readonly WorkforcePerformanceService $performance,
        private readonly WorkforcePerformanceCoachingService $performanceCoaching,
        private readonly WorkforceStaffingProposalService $staffingProposals,
        private readonly WorkforceManifestRegistry $manifestRegistry,
        private readonly WorkforceCapabilityAvailabilityService $capabilityAvailability,
        private readonly WorkforceManifestLifecycleService $definitionLifecycle,
        private readonly WorkforceMemberLifecycleService $memberLifecycle,
        private readonly ManagerContinuityService $managerContinuity,
        private readonly WorkforceDecisionRightsService $decisionRights,
        private readonly WorkforceDecisionRightsCenterService $decisionRightsCenterService,
        private readonly WorkforceDelegationCenterService $delegationCenterService,
        private readonly WorkforceEscalationDeadlockCenterService $escalationDeadlockCenterService,
        private readonly WorkforceGovernancePipelineVisualizerService $governancePipelineVisualizerService,
        private readonly WorkforceExecutionEvidenceExplorerService $executionEvidenceExplorerService,
        private readonly WorkforceJourneyTimelineService $journeyTimelineService,
        private readonly WorkforceOutcomeIntelligenceService $outcomeIntelligenceService,
        private readonly WorkforceConversationService $conversationService,
        private readonly WorkforceContextualConversationService $contextualConversationService,
        private readonly WorkforceSetupWizardService $setupWizard,
        private readonly WorkforceSystemHealthService $systemHealth,
        private readonly WorkforceControlSettingsService $controlSettings,
        private readonly WorkforceAuditExportService $auditExport,
        private readonly WorkforceReleaseReadinessService $releaseReadiness,
        private readonly WorkforceDependencyService $dependencies,
        private readonly WorkforceJourneySpineService $journeySpine,
        private readonly WorkforceOutcomeHealthService $outcomeHealth,
        private readonly WorkforceChainObservabilityService $chainObservability,
        private readonly WorkforceChainLearningPolicyService $chainLearning,
        private readonly WorkforceChainPolicyAdminService $chainPolicyAdmin,
    ) {}

    public function index(): View
    {
        $companyId = $this->companyId();
        $this->bootstrap->ensureDivisions($companyId);
        $dashboard = $this->commandDashboard->snapshot($companyId);
        return view('titan-ai-workforce::dashboard.index', [
            'dashboard' => $dashboard,
            'members' => $dashboard['members'],
        ]);
    }

    public function team(): View
    {
        $companyId = $this->companyId();
        $this->bootstrap->ensureDivisions($companyId);
        return view('titan-ai-workforce::team.index', [
            'organisationMap' => $this->organisationMap->snapshot($companyId),
            'canManageStaff' => app(TitanHostAuthorizationAdapter::class)->allows(Auth::user(), WorkforcePermissions::STAFF_MANAGE, WorkforcePermissions::delegatedAdminPermissions()),
        ]);
    }

    public function divisionWorkspace(WorkforceDivision $division): View
    {
        $companyId = $this->companyId();
        return view('titan-ai-workforce::workspace.show', [
            'workspace' => $this->operationalWorkspace->forDivision($companyId, $division),
        ]);
    }

    public function teamWorkspace(WorkforceTeam $teamScope): View
    {
        $companyId = $this->companyId();
        return view('titan-ai-workforce::workspace.show', [
            'workspace' => $this->operationalWorkspace->forTeam($companyId, $teamScope),
        ]);
    }

    public function member(WorkforceMember $member): View
    {
        $companyId = $this->companyId();
        return view('titan-ai-workforce::employee.show', [
            'profile' => $this->employeeProfile->snapshot($companyId, $member),
        ]);
    }

    public function safeDegradation(WorkforceMember $member): View
    {
        return view('titan-ai-workforce::degradation.show', [
            'degradation' => $this->safeDegradation->snapshot($this->companyId(), $member),
        ]);
    }

    public function attentionCenter(): View
    {
        return view('titan-ai-workforce::attention.index', [
            'attention' => $this->attentionCenterService->snapshot($this->companyId()),
        ]);
    }

    public function decisionRightsCenter(): View
    {
        return view('titan-ai-workforce::decision-rights.index', [
            'center' => $this->decisionRightsCenterService->snapshot($this->companyId()),
        ]);
    }

    public function delegationsCenter(): View
    {
        return view('titan-ai-workforce::delegations.index', [
            'center' => $this->delegationCenterService->snapshot($this->companyId()),
        ]);
    }

    public function governancePipeline(Request $request): View
    {
        $taskId = $request->integer('task');
        return view('titan-ai-workforce::governance-pipeline.index', [
            'pipeline' => $this->governancePipelineVisualizerService->snapshot($this->companyId(), $taskId > 0 ? $taskId : null),
        ]);
    }


    public function executionEvidenceExplorer(Request $request): View
    {
        return view('titan-ai-workforce::execution-evidence.index', [
            'explorer' => $this->executionEvidenceExplorerService->snapshot($this->companyId(), [
                'q' => (string) $request->query('q', ''),
                'type' => (string) $request->query('type', ''),
                'task' => $request->integer('task'),
                'employee' => $request->integer('employee'),
            ]),
        ]);
    }

    public function outcomeIntelligence(Request $request): View
    {
        $companyId = $this->companyId();
        $dimension = (string) $request->query('dimension', 'employee');
        return view('titan-ai-workforce::outcomes.index', [
            'center' => $this->outcomeIntelligenceService->snapshot($companyId, $dimension),
        ]);
    }

    public function journeyTimeline(Request $request): View
    {
        $taskId = $request->integer('task');
        return view('titan-ai-workforce::journey-timeline.index', [
            'timeline' => $this->journeyTimelineService->snapshot($this->companyId(), $taskId > 0 ? $taskId : null),
        ]);
    }

    public function councilsCenter(): View
    {
        return view('titan-ai-workforce::councils.index', [
            'center' => $this->councilOperations->snapshot($this->companyId()),
        ]);
    }

    public function councilShow(int $council): View
    {
        return view('titan-ai-workforce::councils.show', [
            'council' => $this->councilOperations->detail($this->companyId(), $council),
        ]);
    }

    public function conveneCouncil(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'council_key' => ['required','in:executive_operations,finance_review,risk_compliance,quality,customer_recovery,major_incident,staffing,strategic_planning'],
            'issue' => ['required','string','max:4000'],
            'priority' => ['nullable','integer','min:1','max:100'],
            'risk_level' => ['nullable','in:LOW,MEDIUM,HIGH,CRITICAL'],
        ]);
        try {
            $task = $this->councils->convene($this->companyId(), (string) $data['council_key'], $data);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['council_key' => $e->getMessage()]);
        }
        $council = \App\Extensions\TitanAIWorkforce\System\Models\WorkforceCouncil::query()->forCompany($this->companyId())->where('key', (string) $data['council_key'])->firstOrFail();
        return redirect()->route('dashboard.user.titan-workforce.councils.show', $council->id)
            ->with('success', __('Council convened as governed Work Item :task. No execution authority was granted.', ['task' => $task->task_uuid]));
    }

    public function updateCouncilDecision(Request $request, int $council): RedirectResponse
    {
        $data = $request->validate([
            'issue' => ['nullable','string','max:4000'],
            'evidence' => ['nullable','string','max:8000'],
            'proposals' => ['nullable','string','max:8000'],
            'dissent' => ['nullable','string','max:8000'],
            'recommendation' => ['nullable','string','max:8000'],
            'final_decision' => ['nullable','string','max:8000'],
            'follow_up_titles' => ['nullable','array','max:20'],
            'follow_up_titles.*' => ['nullable','string','max:500'],
            'participant_member_id' => ['required','integer'],
        ]);
        $actor = $this->memberFromRequest((int) $data['participant_member_id']);
        try {
            $this->councilOperations->recordDecisionUpdate($this->companyId(), $council, $data, $actor);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['council' => $e->getMessage()]);
        }
        return back()->with('success', __('Council deliberation updated. Follow-up Work Items remain separately governed and require fresh execution authorization.'));
    }

    public function notificationsCenter(): View
    {
        return view('titan-ai-workforce::notifications.index', [
            'inbox' => $this->notificationRouting->inbox($this->companyId()),
        ]);
    }

    public function acknowledgeNotification(WorkforceNotification $notification): RedirectResponse
    {
        $this->notificationRouting->acknowledge($this->companyId(), $notification, (int) Auth::id());
        return back()->with('success', __('Notification acknowledged. This does not approve or authorize the underlying work.'));
    }

    public function updateNotificationPreferences(Request $request): RedirectResponse
    {
        $data = $request->validate(['severity_threshold'=>['required','integer','min:1','max:5']]);
        $this->notificationRouting->updatePreferences($this->companyId(), [
            'severity_threshold'=>(int) $data['severity_threshold'],
            'in_app'=>$request->boolean('in_app'),
            'route_owner_admin'=>$request->boolean('route_owner_admin'),
            'route_responsible_manager'=>$request->boolean('route_responsible_manager'),
            'route_specific_team'=>$request->boolean('route_specific_team'),
        ]);
        return back()->with('success', __('Workforce notification routing policy updated.'));
    }

    public function managerWorkspace(WorkforceMember $member): View
    {
        try {
            $center = $this->managerCommandCenter->snapshot($this->companyId(), $member);
        } catch (InvalidArgumentException $e) {
            abort(404, $e->getMessage());
        }
        return view('titan-ai-workforce::manager.show', ['center' => $center]);
    }

    public function create(): View
    {
        $companyId = $this->companyId();
        $divisions = $this->bootstrap->ensureDivisions($companyId);
        $roles = array_values(array_filter(WorkforceRoleRegistry::all(), static fn (array $role): bool => (int) ($role['tier'] ?? 0) < 3));
        foreach ($roles as &$role) {
            $capabilityState = $this->capabilityAvailability->forRole((string) $role['role_id']);
            $access = (array) ($capabilityState['effective_access'] ?? []);
            $role['owner_extension'] = 'titan-ai-workforce';
            $role['bound_capabilities'] = $access['capabilities'] ?? [];
            $role['bound_tools'] = $access['tools'] ?? [];
            $role['bound_workflows'] = $access['workflows'] ?? [];
            $role['capability_providers'] = $access['providers'] ?? [];
            $role['capability_state'] = (string) ($capabilityState['state'] ?? 'unavailable');
            $role['capability_state_detail'] = $capabilityState;
        }
        unset($role);
        $preselectedRole = (string) request()->query('role', '');
        $preselectedDefinition = $roles[0] ?? null;
        foreach ($roles as $role) {
            if (($role['role_id'] ?? null) === $preselectedRole || ($role['key'] ?? null) === $preselectedRole) { $preselectedDefinition = $role; break; }
        }
        $members = WorkforceMember::query()->forCompany($companyId)->staffingSeats()
            ->where('tier', WorkforceTier::Manager->value)->where('is_active', true)->orderBy('name')->get();
        return view('titan-ai-workforce::create.index', [
            'divisions' => collect($divisions),
            'managers' => $members,
            'roleCatalog' => $roles,
            'preselectedRole' => $preselectedRole,
            'preselectedOwner' => (string) ($preselectedDefinition['owner_extension'] ?? ''),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $companyId = $this->companyId();
        $data = $request->validate([
            'name' => ['required','string','max:120'],
            'key' => ['nullable','string','max:120'],
            'role_owner_extension' => ['nullable','string','max:180'],
            'role_definition_id' => ['required','string','max:180'],
            'manager_id' => ['nullable','integer'],
            'goals' => ['nullable','array'],
            'goals.*' => ['string','max:1000'],
            'local_instructions' => ['nullable','string','max:8000'],
            'schedule_config' => ['nullable','array'],
            'workload_config' => ['nullable','array'],
            'escalation_policy' => ['nullable','array'],
            'capability_policy' => ['nullable','array'],
            'capability_policy.enabled' => ['nullable','boolean'],
            'capability_policy.disabled_providers' => ['nullable','array'],
            'capability_policy.disabled_providers.*' => ['string','max:180'],
            'capability_policy.disabled_surfaces' => ['nullable','array'],
            'capability_policy.disabled_surfaces.*' => ['string','max:240'],
            'capability_policy.disabled_capabilities' => ['nullable','array'],
            'capability_policy.disabled_capabilities.*' => ['string','max:240'],
            'capability_policy.disabled_tools' => ['nullable','array'],
            'capability_policy.disabled_tools.*' => ['string','max:240'],
            'capability_policy.disabled_commands' => ['nullable','array'],
            'capability_policy.disabled_commands.*' => ['string','max:240'],
            'capability_policy.disabled_signals' => ['nullable','array'],
            'capability_policy.disabled_signals.*' => ['string','max:240'],
            'capability_policy.disabled_data_sources' => ['nullable','array'],
            'capability_policy.disabled_data_sources.*' => ['string','max:240'],
            'capability_policy.disabled_workflows' => ['nullable','array'],
            'capability_policy.disabled_workflows.*' => ['string','max:240'],
            'provider_preferences' => ['nullable','array'],
            'model_preferences' => ['nullable','array'],
            'assurance_required' => ['nullable','in:RED,AMBER,GREEN'],
        ]);

        try {
            $member = $this->memberLifecycle->activateFromDefinition(
                $companyId,
                'titan-ai-workforce',
                (string) $data['role_definition_id'],
                $data,
                Auth::id() ? (int) Auth::id() : null,
            );
            $this->responsibilities->syncMember($member);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['role_definition_id' => $e->getMessage()]);
        }

        return redirect()->route('dashboard.user.titan-workforce.team')->with('success', __('Staff member activated from the intrinsic Workforce RoleDefinition with installed provider capabilities attached.'));
    }

    public function suspendStaff(Request $request, WorkforceMember $member): RedirectResponse
    {
        $data = $request->validate(['reason' => ['nullable','string','max:4000']]);
        $this->memberLifecycle->suspend($this->companyId(), $member, Auth::id() ? (int) Auth::id() : null, $data['reason'] ?? null);
        return back()->with('success', __('Staff member suspended. Historical work remains unchanged.'));
    }

    public function resumeStaff(WorkforceMember $member): RedirectResponse
    {
        try {
            $this->memberLifecycle->resume($this->companyId(), $member, Auth::id() ? (int) Auth::id() : null);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['member' => $e->getMessage()]);
        }
        return back()->with('success', __('Staff member returned to active availability.'));
    }

    public function retireStaff(Request $request, WorkforceMember $member): RedirectResponse
    {
        $data = $request->validate([
            'reason' => ['nullable','string','max:4000'],
            'replacement_member_id' => ['nullable','integer'],
        ]);
        $replacement = null;
        if (! empty($data['replacement_member_id'])) {
            $replacement = WorkforceMember::query()->forCompany($this->companyId())->findOrFail((int) $data['replacement_member_id']);
        }
        try {
            $this->memberLifecycle->retire($this->companyId(), $member, $replacement, Auth::id() ? (int) Auth::id() : null, $data['reason'] ?? null);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['member' => $e->getMessage()]);
        }
        return back()->with('success', __('Staff member retired. Historical ownership and task records were preserved.'));
    }

    public function proactiveOperations(): View
    {
        return view('titan-ai-workforce::proactive.index', [
            'center' => $this->proactiveOperationsCenter->snapshot($this->companyId()),
        ]);
    }

    public function capabilityHealth(Request $request): View
    {
        $view = (string) $request->query('view', 'providers');
        $allowed = ['providers','roles','employees','capabilities','tools','commands','signals','data_sources','workflows'];
        if (! in_array($view, $allowed, true)) $view = 'providers';
        return view('titan-ai-workforce::capabilities.index', [
            'inspector' => $this->capabilityHealthInspector->snapshot($this->companyId()),
            'activeView' => $view,
        ]);
    }

    public function responsibilitiesCenter(): View
    {
        return view('titan-ai-workforce::responsibilities.index', [
            'center' => $this->responsibilitiesCenter->snapshot($this->companyId()),
        ]);
    }

    public function updateResponsibility(Request $request, string $responsibilityId): RedirectResponse
    {
        $data = $request->validate([
            'is_enabled' => ['nullable','boolean'],
            'assigned_member_id' => ['nullable','integer'],
            'schedule_json' => ['nullable','string','max:12000'],
            'trigger_conditions_json' => ['nullable','string','max:12000'],
        ]);
        try {
            $schedule = trim((string) ($data['schedule_json'] ?? '')) !== '' ? json_decode((string) $data['schedule_json'], true, 64, JSON_THROW_ON_ERROR) : null;
            $conditions = trim((string) ($data['trigger_conditions_json'] ?? '')) !== '' ? json_decode((string) $data['trigger_conditions_json'], true, 64, JSON_THROW_ON_ERROR) : null;
            if ($schedule !== null && ! is_array($schedule)) throw new InvalidArgumentException('Schedule must be a JSON object or array.');
            if ($conditions !== null && ! is_array($conditions)) throw new InvalidArgumentException('Trigger conditions must be a JSON object or array.');
            $this->responsibilitiesCenter->update($this->companyId(), $responsibilityId, [
                'is_enabled' => $request->boolean('is_enabled'),
                'assigned_member_id' => $data['assigned_member_id'] ?? null,
                'schedule' => $schedule,
                'trigger_conditions' => $conditions,
            ]);
        } catch (\JsonException|InvalidArgumentException $e) {
            throw ValidationException::withMessages(['responsibility' => $e->getMessage()]);
        }
        return back()->with('success', __('Responsibility settings updated without changing capability or execution authority.'));
    }

    public function tasks(Request $request): View
    {
        $companyId = $this->companyId();
        return view('titan-ai-workforce::tasks.index', [
            'center' => $this->workCommandCenter->index($companyId, (string) $request->query('view', 'list'), $request->filled('status') ? (string) $request->query('status') : null),
            'statuses' => WorkforceTaskStatus::cases(),
        ]);
    }

    public function task(WorkforceTask $task): View
    {
        return view('titan-ai-workforce::tasks.show', [
            'detail' => $this->workCommandCenter->task($this->companyId(), $task),
        ]);
    }

    public function taskGraph(WorkforceTask $task): View
    {
        return view('titan-ai-workforce::tasks.graph', [
            'graph' => $this->visualWorkGraph->graph($this->companyId(), $task),
        ]);
    }

    public function calendar(): View
    {
        return view('titan-ai-workforce::calendar.index', ['members' => WorkforceMember::query()->forCompany($this->companyId())->where('is_active', true)->orderBy('name')->get()]);
    }



    public function workforceReleaseReadiness(): View
    {
        return view('titan-ai-workforce::release-readiness.index',['readiness'=>$this->releaseReadiness->snapshot($this->companyId())]);
    }

    public function workforceAuditExport(): View
    {
        $package=$this->auditExport->package($this->companyId());
        return view('titan-ai-workforce::audit-export.index',['package'=>$package]);
    }

    public function downloadWorkforceAuditExport()
    {
        $package=$this->auditExport->package($this->companyId());
        $name='titan-workforce-audit-company-'.$this->companyId().'-'.now()->format('Ymd-His').'.json';
        return response()->streamDownload(function() use ($package){ echo json_encode($package, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES); },$name,['Content-Type'=>'application/json']);
    }

    public function workforceControlSettings(): View
    {
        return view('titan-ai-workforce::settings.index',['settings'=>$this->controlSettings->snapshot($this->companyId()),'saved'=>false]);
    }

    public function updateWorkforceControlSettings(Request $request): View
    {
        $data=$request->validate([
            'notification_thresholds.minimum_severity'=>['required','in:LOW,MEDIUM,HIGH,CRITICAL'],
            'notification_thresholds.deduplicate_minutes'=>['required','integer','min:5','max:1440'],
            'fallback_policy.allow_approved_fallbacks'=>['nullable','boolean'],
            'proactive_operations.enabled'=>['nullable','boolean'],
            'proactive_operations.max_generated_work_per_cycle'=>['required','integer','min:1','max:100'],
            'outcome_verification.late_after_minutes'=>['required','integer','min:5','max:10080'],
            'staffing_policy.recommend_at_pressure_score'=>['required','integer','min:1','max:100'],
        ]);
        return view('titan-ai-workforce::settings.index',['settings'=>$this->controlSettings->update($this->companyId(),$data),'saved'=>true]);
    }

    public function workforceSystemHealth(): View
    {
        return view('titan-ai-workforce::system-health.index', ['health'=>$this->systemHealth->snapshot($this->companyId())]);
    }

    public function workforceSetup(Request $request): View
    {
        $profile=[
            'business_tier'=>(string)$request->query('business_tier','SMALL'),
            'verticals'=>(array)$request->query('verticals',[]),
            'operating_mode'=>(string)$request->query('operating_mode','balanced'),
        ];
        return view('titan-ai-workforce::setup.index',['setup'=>$this->setupWizard->preview($this->companyId(),$profile),'profile'=>$profile,'applied'=>null]);
    }

    public function applyWorkforceSetup(Request $request): View
    {
        $data=$request->validate(['business_tier'=>['required','in:SOLO,SMALL,GROWING,ENTERPRISE'],'verticals'=>['nullable','array'],'verticals.*'=>['string','max:80'],'operating_mode'=>['nullable','in:lean,balanced,coverage']]);
        return view('titan-ai-workforce::setup.index',['setup'=>$this->setupWizard->preview($this->companyId(),$data),'profile'=>$data,'applied'=>$this->setupWizard->apply($this->companyId(),$data)]);
    }

    public function workforceConversation(): View
    {
        return view('titan-ai-workforce::conversation.index', [
            'response' => null,
            'message' => '',
        ]);
    }

    public function submitWorkforceConversation(Request $request): View
    {
        $data = $request->validate(['message' => ['required','string','max:4000']]);
        $message = trim((string) $data['message']);
        return view('titan-ai-workforce::conversation.index', [
            'response' => $this->conversationService->respond($this->companyId(), $message),
            'message' => $message,
        ]);
    }


    public function contextualWorkforceConversation(string $type, string $id): View
    {
        return view('titan-ai-workforce::conversation.contextual', [
            'context' => $this->contextualConversationService->envelope($this->companyId(), $type, $id),
            'response' => null,
            'message' => '',
        ]);
    }

    public function submitContextualWorkforceConversation(Request $request, string $type, string $id): View
    {
        $data = $request->validate(['message' => ['required','string','max:4000']]);
        $message = trim((string) $data['message']);
        return view('titan-ai-workforce::conversation.contextual', [
            'context' => $this->contextualConversationService->envelope($this->companyId(), $type, $id),
            'response' => $this->contextualConversationService->respond($this->companyId(), $type, $id, $message),
            'message' => $message,
        ]);
    }

    public function planningCenter(Request $request): View
    {
        $data = $request->validate([
            'business_tier' => ['nullable','in:SOLO,SMALL,GROWING,ENTERPRISE'],
            'verticals' => ['nullable','array'],
            'verticals.*' => ['string','max:80'],
        ]);
        return view('titan-ai-workforce::planning.index', [
            'planning' => $this->planningIntelligence->snapshot($this->companyId(), (string)($data['business_tier'] ?? 'SMALL'), $data['verticals'] ?? []),
        ]);
    }

    public function analytics(): View
    {
        $companyId = $this->companyId();
        return view('titan-ai-workforce::analytics.index', [
            'stats' => [
                'completed' => WorkforceTask::query()->forCompany($companyId)->where('status','COMPLETED')->count(),
                'open' => WorkforceTask::query()->forCompany($companyId)->whereNotIn('status',['COMPLETED','FAILED','CANCELLED','REJECTED'])->count(),
                'review' => WorkforceTask::query()->forCompany($companyId)->whereIn('status',['UNDER_REVIEW','RECEIVER_REVIEW'])->count(),
                'exceptions' => WorkforceTask::query()->forCompany($companyId)->whereIn('status',['BLOCKED','FAILED','ESCALATED','REVISION_REQUIRED'])->count(),
            ],
            'members' => WorkforceMember::query()->forCompany($companyId)->where('is_active', true)->get()->reject(fn ($m) => (bool) data_get($m->metadata ?? [], 'internal', false))->values(),
            'performance' => $this->performance->forCompany($companyId),
            'coaching' => $this->performanceCoaching->snapshot($companyId),
        ]);
    }

    public function controlRoom(): View
    {
        $companyId = $this->companyId();
        $this->bootstrap->ensureDivisions($companyId);
        return view('titan-ai-workforce::control-room.index', [
            'controlRoom' => $this->controlRoomService->snapshot($companyId),
        ]);
    }

    public function refreshStaffingRecommendations(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'business_tier' => ['required','in:SOLO,SMALL,GROWING,ENTERPRISE'],
            'verticals' => ['nullable','array'],
            'verticals.*' => ['string','max:80'],
        ]);
        $rows = $this->staffingProposals->refreshFromCurrentQueues(
            $this->companyId(),
            (string) $data['business_tier'],
            $data['verticals'] ?? [],
        );
        return back()->with('success', __('Workforce Planning refreshed :count staffing recommendations. No staff were auto-activated.', ['count'=>$rows->count()]));
    }

    public function approveStaffingProposal(Request $request, WorkforceStaffingProposal $proposal): RedirectResponse
    {
        $data = $request->validate(['reason' => ['nullable','string','max:4000']]);
        $proposal = $this->staffingProposals->approve($this->companyId(), $proposal, (int) Auth::id(), $data['reason'] ?? null);
        return redirect()->route('dashboard.user.titan-workforce.create', ['role' => $proposal->role_key])
            ->with('success', __('Staffing recommendation approved. Employee Builder opened; activation still requires explicit creation.'));
    }

    public function rejectStaffingProposal(Request $request, WorkforceStaffingProposal $proposal): RedirectResponse
    {
        $data = $request->validate(['reason' => ['nullable','string','max:4000']]);
        $this->staffingProposals->reject($this->companyId(), $proposal, (int) Auth::id(), $data['reason'] ?? null);
        return back()->with('success', __('Staffing recommendation rejected.'));
    }

    public function apiControlRoom(): JsonResponse
    {
        return response()->json(['success' => true, 'control_room' => $this->controlRoomService->snapshot($this->companyId())]);
    }

    public function apiTasks(Request $request): JsonResponse
    {
        $companyId = $this->companyId();
        $query = WorkforceTask::query()->forCompany($companyId)->with(['assignee:id,name','manager:id,name'])->orderBy('scheduled_at');
        if ($request->filled('start_date')) { $query->where('scheduled_at','>=',$request->string('start_date')); }
        if ($request->filled('end_date')) { $query->where('scheduled_at','<=',$request->string('end_date')); }
        return response()->json(['success' => true, 'tasks' => $query->limit(1000)->get()]);
    }

    public function apiManifestHealth(): JsonResponse
    {
        $health = $this->manifestRegistry->health();
        return response()->json([
            'success' => true,
            'canonical_schema_version' => '2.0',
            'contributors' => $health,
            'healthy' => count(array_filter($health, static fn (array $row): bool => in_array($row['status'] ?? null, ['HEALTHY','LEGACY_NORMALIZED'], true))),
            'quarantined' => count(array_filter($health, static fn (array $row): bool => ($row['status'] ?? null) === 'QUARANTINED')),
        ]);
    }

    public function apiRoles(Request $request): JsonResponse
    {
        $vertical = trim((string) $request->query('vertical', ''));
        $roles = $vertical !== '' ? WorkforceRoleRegistry::forVertical($vertical) : WorkforceRoleRegistry::all();
        return response()->json(['success' => true, 'count' => count($roles), 'roles' => $roles]);
    }

    public function apiWorkforcePlan(Request $request): JsonResponse
    {
        $data = $request->validate([
            'business_tier' => ['nullable','in:SOLO,SMALL,GROWING,ENTERPRISE'],
            'verticals' => ['nullable','array'],
            'verticals.*' => ['string','max:80'],
            'metrics' => ['nullable','array'],
        ]);
        $recommendations = $this->planning->recommend(
            $this->companyId(),
            (string) ($data['business_tier'] ?? 'SMALL'),
            $data['verticals'] ?? [],
            $data['metrics'] ?? [],
        );
        return response()->json(['success' => true, 'auto_hire' => false, 'recommendations' => $recommendations]);
    }

    public function submitTask(WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task); $maker = $this->memberFromRequest((int) $task->assignee_member_id);
        $this->chain->submit($task, $maker); return back()->with('success', __('Task submitted to Manager review.'));
    }

    public function reviewTask(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task); $data = $request->validate(['manager_id'=>['required','integer'],'decision'=>['required','in:approve,revise'],'reason'=>['nullable','string','max:4000']]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $this->chain->managerDecision($task, $manager, $data['decision']==='approve', $data['reason'] ?? null); return back()->with('success', __('Manager decision recorded.'));
    }

    public function handoffTask(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task); $data = $request->validate(['origin_manager_id'=>['required','integer'],'receiving_manager_id'=>['required','integer'],'receiving_specialist_id'=>['nullable','integer'],'reason'=>['nullable','string','max:4000']]);
        $origin = $this->memberFromRequest((int) $data['origin_manager_id']); $receiver = $this->memberFromRequest((int) $data['receiving_manager_id']);
        $specialist = !empty($data['receiving_specialist_id']) ? $this->memberFromRequest((int) $data['receiving_specialist_id']) : null;
        $this->chain->handoff($task, $origin, $receiver, $specialist, $data['reason'] ?? null); return back()->with('success', __('Governed handoff sent to receiving Manager.'));
    }


    public function delegateAction(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task);
        $data = $request->validate(['manager_id'=>['required','integer'],'action_worker_id'=>['nullable','integer']]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $child = $this->delegation->toActionWorker($task, $manager, !empty($data['action_worker_id']) ? (int) $data['action_worker_id'] : null);
        return back()->with('success', __('Approved work delegated to Action Worker :id.', ['id'=>$child->task_uuid]));
    }

    public function receiverReview(Request $request, WorkforceTaskHandoff $handoff): RedirectResponse
    {
        if ((int) $handoff->company_id !== $this->companyId()) { abort(404); }
        $data = $request->validate(['receiver_id'=>['required','integer'],'decision'=>['required','in:accept,return'],'reason'=>['nullable','string','max:4000']]);
        $receiver = $this->memberFromRequest((int) $data['receiver_id']);
        $this->chain->receiverDecision($handoff, $receiver, $data['decision']==='accept', $data['reason'] ?? null); return back()->with('success', __('Receiving Manager decision recorded.'));
    }

    public function resolveDeadlock(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task); $data = $request->validate(['actor_id'=>['required','integer'],'resolution'=>['required','string'],'reason'=>['nullable','string','max:4000']]);
        $actor = $this->memberFromRequest((int) $data['actor_id']);
        $this->chain->resolveDeadlock($task, $actor, DeadlockResolution::from($data['resolution']), $data['reason'] ?? null); return back()->with('success', __('Deadlock resolution recorded.'));
    }


    public function decomposeTask(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task);
        $data = $request->validate([
            'manager_id' => ['required','integer'],
            'plan' => ['required','array'],
            'plan.steps' => ['required','array','min:1','max:50'],
        ]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $children = $this->managerOperations->decompose($task, $manager, ['workforce_plan' => $data['plan']]);
        return back()->with('success', __('Manager objective decomposed into :count governed tasks.', ['count'=>count($children)]));
    }

    public function reassignTask(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task);
        $data = $request->validate([
            'manager_id' => ['required','integer'],
            'target_member_id' => ['required','integer'],
            'reason' => ['required','string','max:4000'],
        ]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $target = $this->memberFromRequest((int) $data['target_member_id']);
        $this->workloadSharing->reassign($task, $manager, $target, (string) $data['reason']);
        return back()->with('success', __('Task reassigned without transferring authority.'));
    }

    public function escalateTask(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task);
        $data = $request->validate([
            'manager_id' => ['required','integer'],
            'reason_code' => ['required','string','max:120'],
            'reason' => ['required','string','max:4000'],
        ]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        if ((int) $task->manager_member_id !== (int) $manager->id && (int) $task->assignee_member_id !== (int) $manager->id) {
            throw ValidationException::withMessages(['manager_id' => 'Only the responsible Manager may escalate this task.']);
        }
        $target = $manager->manager_id ? WorkforceMember::query()->forCompany($this->companyId())->find((int) $manager->manager_id) : null;
        try {
            $this->tasks->transition($task, WorkforceTaskStatus::Escalated, $manager, 'manager.escalated', (string) $data['reason'], [
                'reason_code' => (string) $data['reason_code'],
                'escalated_to_member_id' => $target?->id,
                'authority_inherited' => false,
            ]);
        } catch (InvalidArgumentException $e) {
            throw ValidationException::withMessages(['task' => $e->getMessage()]);
        }
        \App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation::query()->create([
            'escalation_uuid' => (string) Str::uuid(),
            'company_id' => $this->companyId(),
            'task_id' => $task->id,
            'raised_by_member_id' => $manager->id,
            'escalated_to_member_id' => $target?->id,
            'reason_code' => (string) $data['reason_code'],
            'risk_level' => (string) ($task->risk_level ?? 'LOW'),
            'status' => 'OPEN',
            'recommended_action' => (string) $data['reason'],
            'metadata' => ['authority_inherited' => false, 'source' => 'manager_command_center'],
        ]);
        return back()->with('success', __('Task escalated through the Workforce reporting chain. No authority was transferred.'));
    }

    public function escalationDeadlockCenter(): View
    {
        return view('titan-ai-workforce::escalations.index', [
            'center' => $this->escalationDeadlockCenterService->snapshot($this->companyId()),
        ]);
    }

    public function resolveEscalationCenterAction(Request $request, WorkforceTask $task): RedirectResponse
    {
        $this->authorizeTask($task);
        $data = $request->validate([
            'actor_id' => ['required','integer'],
            'action' => ['required','in:RETRY_WITH_EVIDENCE,RETURN_TO_MAKER,ESCALATE_TO_PARENT,HUMAN_DECISION_REQUIRED,RESOLVE'],
            'reason' => ['required','string','max:4000'],
        ]);
        $actor = $this->memberFromRequest((int) $data['actor_id']);
        $openEscalations = \App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation::query()
            ->forCompany($this->companyId())->where('task_id', $task->id)->where('status', 'OPEN')->get();
        $allowedActorIds = array_values(array_unique(array_filter([
            (int) ($task->manager_member_id ?? 0),
            (int) ($task->assignee_member_id ?? 0),
            ...$openEscalations->pluck('escalated_to_member_id')->map(fn ($id): int => (int) $id)->all(),
        ])));
        $isExecutiveResolver = in_array((string) $actor->role_definition_id, ['titan.executive.business_manager','titan.system.titan_zero'], true);
        if (! in_array((int) $actor->id, $allowedActorIds, true) && ! $isExecutiveResolver) {
            throw ValidationException::withMessages(['actor_id' => 'Only the responsible manager, assigned escalation owner, AI Business Manager or Titan Zero may act on this escalation.']);
        }

        if ($data['action'] === 'RESOLVE') {
            try {
                if ((string) ($task->status?->value ?? $task->status) === WorkforceTaskStatus::Escalated->value) {
                    $this->tasks->transition($task, WorkforceTaskStatus::Processing, $actor, 'escalation.resolved', (string) $data['reason'], [
                        'authority_inherited' => false,
                        'execution_authority_granted' => false,
                    ]);
                } else {
                    $this->tasks->record($task, $actor, 'escalation.resolved', (string) ($task->status?->value ?? $task->status), (string) ($task->status?->value ?? $task->status), (string) $data['reason'], [
                        'authority_inherited' => false,
                        'execution_authority_granted' => false,
                    ]);
                }
            } catch (InvalidArgumentException $e) {
                throw ValidationException::withMessages(['task' => $e->getMessage()]);
            }
            \App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation::query()->forCompany($this->companyId())
                ->where('task_id', $task->id)->where('status', 'OPEN')->update([
                    'status' => 'RESOLVED', 'resolved_at' => now(),
                    'metadata' => ['authority_inherited'=>false,'execution_authority_granted'=>false,'resolved_by_member_id'=>$actor->id,'resolution_reason'=>(string) $data['reason']],
                ]);
            return back()->with('success', __('Escalation resolved. No execution authority was granted.'));
        }

        $resolution = DeadlockResolution::from((string) $data['action']);
        $this->chain->resolveDeadlock($task, $actor, $resolution, (string) $data['reason']);
        if (in_array($resolution, [DeadlockResolution::EscalateToParent, DeadlockResolution::HumanDecisionRequired], true)) {
            $target = $actor->manager_id ? WorkforceMember::query()->forCompany($this->companyId())->find((int) $actor->manager_id) : null;
            \App\Extensions\TitanAIWorkforce\System\Models\WorkforceEscalation::query()->create([
                'escalation_uuid' => (string) Str::uuid(),
                'company_id' => $this->companyId(), 'task_id' => $task->id,
                'raised_by_member_id' => $actor->id, 'escalated_to_member_id' => $target?->id,
                'reason_code' => $resolution->value, 'risk_level' => (string) ($task->risk_level ?? 'LOW'),
                'status' => 'OPEN', 'recommended_action' => (string) $data['reason'],
                'metadata' => ['resolution'=>$resolution->value,'authority_inherited'=>false,'execution_authority_granted'=>false,'source'=>'escalation_deadlock_center'],
            ]);
        }
        return back()->with('success', __('Governed escalation/deadlock action recorded. No authority was transferred.'));
    }

    public function apiManagerQueue(Request $request): JsonResponse
    {
        $data = $request->validate(['manager_id'=>['required','integer']]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $rows = WorkforceTask::query()->forCompany($this->companyId())
            ->where('manager_member_id', $manager->id)
            ->whereNotIn('status', ['COMPLETED','FAILED','CANCELLED','REJECTED'])
            ->with(['assignee:id,name','division:id,key,name'])
            ->get()
            ->map(function (WorkforceTask $task) {
                $task->queue_score = $this->priority->score($task);
                return $task;
            })
            ->sortByDesc('queue_score')->values();
        return response()->json(['success'=>true,'manager_id'=>$manager->id,'count'=>$rows->count(),'tasks'=>$rows]);
    }

    public function apiConveneCouncil(Request $request): JsonResponse
    {
        $data = $request->validate([
            'council_key' => ['required','in:daily_ops,weekly_performance,executive_operations,finance_review,risk_compliance,quality,customer_recovery,major_incident,staffing,strategic_planning'],
            'context' => ['nullable','array'],
        ]);
        $task = $this->councils->convene($this->companyId(), (string) $data['council_key'], $data['context'] ?? []);
        return response()->json(['success'=>true,'task_id'=>$task->task_uuid,'status'=>$task->status->value]);
    }

    public function apiRaiseDispute(Request $request): JsonResponse
    {
        $data = $request->validate([
            'conflict' => ['required','string','max:120'],
            'context' => ['required','array'],
            'context.participant_manager_ids' => ['required','array','min:2','max:20'],
            'context.participant_manager_ids.*' => ['integer'],
        ]);
        foreach ($data['context']['participant_manager_ids'] as $managerId) $this->memberFromRequest((int) $managerId);
        $task = $this->disputes->raise($this->companyId(), (string) $data['conflict'], $data['context']);
        return response()->json(['success'=>true,'task_id'=>$task->task_uuid,'status'=>$task->status->value]);
    }

    public function apiProactiveResponsibilities(Request $request): JsonResponse
    {
        $data = $request->validate(['role' => ['required','string','max:180']]);
        $definition = WorkforceRoleRegistry::find((string) $data['role']);
        if (! $definition) { abort(404); }
        return response()->json([
            'success' => true,
            'role' => $definition['role_id'],
            'responsibilities' => WorkforceResponsibilityRegistry::accountabilitiesForRole((string) $definition['key'], $definition['activation']['verticals'] ?? []),
            'routines' => WorkforceResponsibilityRegistry::forRole((string) $definition['key'], $definition['activation']['verticals'] ?? []),
        ]);
    }

    public function apiQueueHealth(Request $request): JsonResponse
    {
        $data = $request->validate(['manager_id' => ['required','integer']]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        return response()->json(['success' => true, 'manager_id' => $manager->id, 'queue_health' => $this->queueHealth->forManager($manager)]);
    }

    public function apiProactiveRuntime(): JsonResponse
    {
        return response()->json(['success' => true, 'proactive_runtime' => $this->proactiveRuntime->snapshot($this->companyId())]);
    }

    public function apiTrustHealth(): JsonResponse
    {
        return response()->json(['success' => true, 'trust_health' => $this->trustHealth->forCompany($this->companyId())]);
    }

    public function apiJourney(WorkforceTask $task): JsonResponse
    {
        $this->authorizeTask($task);
        return response()->json([
            'success' => true,
            'company_id' => $this->companyId(),
            'task_id' => $task->task_uuid,
            'trace_id' => $task->trace_id,
            'correlation_id' => $task->correlation_id,
            'journey' => $this->journeySpine->journeyForTask($task),
        ]);
    }

    public function apiOutcomeHealth(Request $request): JsonResponse
    {
        return response()->json([
            'success' => true,
            'outcome_health' => $this->outcomeHealth->snapshot(
                $this->companyId(),
                max(5, (int) $request->integer('late_after_minutes', 30)),
            ),
        ]);
    }

    public function apiVerticalOverlay(Request $request): JsonResponse
    {
        $data = $request->validate([
            'verticals' => ['nullable','array'],
            'verticals.*' => ['string','max:80'],
            'jurisdiction' => ['nullable','string','max:120'],
            'business_tier' => ['nullable','in:SOLO,SMALL,GROWING,ENTERPRISE'],
        ]);
        return response()->json([
            'success' => true,
            'vertical_overlay' => $this->verticalOverlay->resolve($this->companyId(), $data),
        ]);
    }



    public function apiChainIntegrity(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'chain_integrity' => $this->dependencies->integritySnapshot($this->companyId()),
        ]);
    }

    public function apiOrganisationGraph(): JsonResponse
    {
        return response()->json([
            'success' => true,
            'graph' => $this->graph->snapshot($this->companyId()),
            'integrity' => $this->graph->validateGraph($this->companyId()),
        ]);
    }

    public function apiDecisionRights(Request $request): JsonResponse
    {
        $data = $request->validate([
            'decision' => ['nullable','string','max:180'],
            'owner_extension' => ['nullable','string','max:180'],
        ]);
        if (! empty($data['decision'])) {
            return response()->json([
                'success' => true,
                'decision_right' => $this->decisionRights->decision((string) $data['decision'], $data['owner_extension'] ?? null),
                'authority_note' => 'RACI does not confer execution authority.',
            ]);
        }
        return response()->json([
            'success' => true,
            'decision_rights' => $this->decisionRights->all(),
            'authority_note' => 'RACI does not confer execution authority.',
        ]);
    }

    public function setStaffManager(Request $request, WorkforceMember $member): RedirectResponse
    {
        $data = $request->validate(['manager_id' => ['required','integer']]);
        $manager = $this->memberFromRequest((int) $data['manager_id']);
        $this->graph->setManager($member, $manager);
        return back()->with('success', __('Reporting Manager updated after graph-cycle validation.'));
    }

    public function appointDeputy(Request $request, WorkforceMember $member): RedirectResponse
    {
        $data = $request->validate([
            'deputy_id' => ['required','integer'],
            'scope' => ['required','array','min:1','max:50'],
            'scope.*' => ['string','max:180'],
            'expires_at' => ['required','date','after:now'],
        ]);
        $deputy = $this->memberFromRequest((int) $data['deputy_id']);
        $this->managerContinuity->appointDeputy($member, $deputy, CarbonImmutable::parse((string) $data['expires_at']), $data['scope']);
        return back()->with('success', __('Scoped deputy coverage appointed.'));
    }

    public function chainCommandCenter(Request $request): View
    {
        $companyId=CompanyContext::id(Auth::user());
        return view('titan-ai-workforce::chain-command-center.index',[
            'observability'=>$this->chainObservability->dashboard($companyId,(int)$request->integer('limit',100)),
        ]);
    }

    public function apiChainCommandCenter(Request $request): JsonResponse
    {
        $companyId=CompanyContext::id(Auth::user());
        return response()->json($this->chainObservability->dashboard($companyId,(int)$request->integer('limit',100)));
    }

    public function apiChainCommandCenterShow(string $chainUuid): JsonResponse
    {
        return response()->json($this->chainObservability->chain(CompanyContext::id(Auth::user()),$chainUuid));
    }

    public function approveChainLearningRecommendation(string $recommendationUuid): JsonResponse
    {
        $companyId=CompanyContext::id(Auth::user());
        $record=$this->chainLearning->approve($companyId,$recommendationUuid,(int)Auth::id());
        return response()->json([
            'approved'=>true,
            'recommendation_uuid'=>$record->recommendation_uuid,
            'status'=>$record->status,
            'approved_at'=>$record->approved_at?->toIso8601String(),
            'authority_mutation'=>'user-approved-policy-input-only',
        ]);
    }

    public function rejectChainLearningRecommendation(string $recommendationUuid): JsonResponse
    {
        $companyId=CompanyContext::id(Auth::user());
        $record=$this->chainLearning->reject($companyId,$recommendationUuid,(int)Auth::id());
        return response()->json([
            'rejected'=>true,
            'recommendation_uuid'=>$record->recommendation_uuid,
            'status'=>$record->status,
            'rejected_at'=>$record->rejected_at?->toIso8601String(),
        ]);
    }

    public function legacyRedirect(): RedirectResponse { return redirect()->route('dashboard.user.titan-workforce.index'); }

    public function chainPolicy(): View
    {
        $companyId=$this->companyId();
        return view('titan-ai-workforce::chain-policy.index',[
            'policy'=>$this->chainPolicyAdmin->policy($companyId),
            'observability'=>$this->chainObservability->dashboard($companyId,50),
        ]);
    }

    public function updateChainPolicy(Request $request): JsonResponse
    {
        $companyId=$this->companyId();
        $data=$request->validate([
            'enabled'=>'sometimes|boolean',
            'minimum_reviewer_quality'=>'sometimes|integer|min:0|max:100',
            'high_risk_reviewer_quality'=>'sometimes|integer|min:70|max:100',
            'critical_risk_reviewer_quality'=>'sometimes|integer|min:80|max:100',
            'require_provider_diversity_high_risk'=>'sometimes|boolean',
            'require_assurance_high_risk'=>'sometimes|boolean',
            'require_model_council_critical'=>'sometimes|boolean',
            'require_explicit_evidence_high_risk'=>'sometimes|boolean',
            'require_manual_extreme_risk'=>'sometimes|boolean',
            'allow_learned_policy'=>'sometimes|boolean',
            'federation_paths'=>'sometimes|array',
            'federation_paths.*'=>'array|min:3',
            'federation_paths.*.*'=>'string|max:120',
            'federation_paths_json'=>'sometimes|nullable|string|max:20000',
        ]);
        if(isset($data['federation_paths_json']) && trim((string)$data['federation_paths_json'])!==''){
            $decoded=json_decode((string)$data['federation_paths_json'],true);
            if(!is_array($decoded)){
                throw ValidationException::withMessages(['federation_paths_json'=>'Federation paths must be valid JSON object data.']);
            }
            $data['federation_paths']=$decoded;
        }
        unset($data['federation_paths_json']);

        $policy=$this->chainPolicyAdmin->updatePolicy($companyId,(int)Auth::id(),$data);
        if(!$request->expectsJson()){
            return redirect()->route('dashboard.user.titan-workforce.chain-policy')
                ->with('success','Chain-of-command policy updated.');
        }
        return response()->json([
            'updated'=>true,
            'policy_uuid'=>$policy->policy_uuid,
            'revision'=>$policy->revision,
            'mandatory_three_checks'=>true,
            'allow_admin_force_approve'=>false,
            'policy'=>$policy->toArray(),
        ]);
    }

    public function createChainAdminOverride(Request $request,string $chainUuid): JsonResponse
    {
        $companyId=$this->companyId();
        $data=$request->validate([
            'override_type'=>'required|string|in:HOLD,REQUIRE_MANUAL_REVIEW,INCREASE_SCRUTINY',
            'reason'=>'required|string|min:5|max:2000',
            'evidence_refs'=>'sometimes|array',
            'evidence_refs.*'=>'string|max:500',
        ]);
        $chain=WorkforceDecisionChain::query()->forCompany($companyId)
            ->where('chain_uuid',$chainUuid)->firstOrFail();
        $override=$this->chainPolicyAdmin->createOverride(
            $chain,(int)Auth::id(),$data['override_type'],$data['reason'],(array)($data['evidence_refs'] ?? [])
        );
        return response()->json([
            'created'=>true,
            'override_uuid'=>$override->override_uuid,
            'override_type'=>$override->override_type,
            'status'=>$override->status,
            'effect'=>$override->effect,
            'can_force_approve'=>false,
        ]);
    }

    public function releaseChainAdminOverride(string $overrideUuid): JsonResponse
    {
        $override=$this->chainPolicyAdmin->releaseOverride($this->companyId(),$overrideUuid,(int)Auth::id());
        return response()->json([
            'released'=>true,
            'override_uuid'=>$override->override_uuid,
            'status'=>$override->status,
            'released_at'=>$override->released_at?->toIso8601String(),
        ]);
    }

    private function companyId(): int { return CompanyContext::id(Auth::user()); }
    private function memberFromRequest(int $id): WorkforceMember { return WorkforceMember::query()->forCompany($this->companyId())->findOrFail($id); }
    private function authorizeTask(WorkforceTask $task): void { if ((int) $task->company_id !== $this->companyId()) { abort(404); } }
}
