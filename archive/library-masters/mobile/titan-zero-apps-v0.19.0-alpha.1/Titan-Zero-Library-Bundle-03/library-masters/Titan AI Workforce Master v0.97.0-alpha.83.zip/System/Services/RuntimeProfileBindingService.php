<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceRuntimeProfile;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use InvalidArgumentException;

/**
 * Workforce owns employee intelligence-profile assignment. Agent Runtime only
 * consumes the resolved profile and may not select a different employee profile.
 */
final class RuntimeProfileBindingService
{
    /** @param array<string,mixed> $definition @param array<string,mixed> $input */
    public function ensureForMember(WorkforceMember $member, array $definition = [], array $input = []): WorkforceRuntimeProfile
    {
        $this->assertCompany($member);

        $profileId = trim((string) $member->runtime_profile_id);
        if ($profileId === '') {
            $profileId = 'workforce-member-' . (int) $member->id;
        } else {
            $existing = WorkforceRuntimeProfile::query()
                ->forCompany((int) $member->company_id)
                ->where('profile_id', $profileId)
                ->first();
            if ($existing !== null) return $existing;
        }

        $definitionProfile = $this->arrayValue($definition['runtime_profile'] ?? []);
        $providerPolicy = $this->arrayValue($input['provider_policy'] ?? $definitionProfile['provider_policy'] ?? $member->provider_preferences ?? []);
        $modelPolicy = $this->arrayValue($input['model_policy'] ?? $definitionProfile['model_policy'] ?? $member->model_preferences ?? []);
        $memoryPolicy = $this->arrayValue($input['memory_policy'] ?? $definitionProfile['memory_policy'] ?? [
            'enabled' => true,
            'include_user_memory' => false,
            'history_turns' => 12,
            'scopes' => array_values(array_map('strval', (array) ($member->memory_scopes ?? []))),
        ]);
        $channelBehavior = $this->arrayValue($input['channel_behavior'] ?? $definitionProfile['channel_behavior'] ?? [
            'mode' => 'workforce',
            'allow_surface_override' => false,
        ]);
        $reasoning = $this->arrayValue($input['reasoning_config'] ?? $definitionProfile['reasoning_config'] ?? [
            'web_search' => false,
            'response_mode' => 'json',
        ]);

        // Informational tools are explicitly non-consequential. Business tool
        // authority remains on the Workforce task/capability path and Command Bus.
        $informationalTools = array_values(array_unique(array_map('strval', (array) ($input['informational_tools'] ?? $definitionProfile['informational_tools'] ?? []))));

        $localInstructions = trim((string) data_get($member->lifecycle_metadata ?? [], 'local_instructions', ''));
        $persona = trim((string) ($input['persona'] ?? $definitionProfile['persona'] ?? $member->role ?? $member->name ?? ''));
        $systemPrompt = trim((string) ($input['system_prompt'] ?? $definitionProfile['system_prompt'] ?? $localInstructions));
        if ($systemPrompt === '') {
            $systemPrompt = 'Act as the assigned Titan AI Workforce employee. Stay within the supplied company, employee and task context. Produce reasoning, conversational output and governed proposals only; never claim consequential business execution unless an authoritative result is supplied.';
        }

        $payload = [
            'name' => trim((string) ($input['profile_name'] ?? $definitionProfile['name'] ?? ($member->name . ' Runtime Profile'))),
            'persona' => $persona !== '' ? $persona : null,
            'system_prompt' => $systemPrompt,
            'provider_policy' => $providerPolicy,
            'model_policy' => $modelPolicy,
            'memory_policy' => $memoryPolicy,
            'channel_behavior' => $channelBehavior,
            'informational_tools' => $informationalTools,
            'reasoning_config' => $reasoning,
            'metadata' => [
                'owner' => 'titan-ai-workforce',
                'binding' => 'workforce-member',
                'workforce_member_id' => (int) $member->id,
                'role_definition_id' => $member->role_definition_id,
                'role_owner_extension' => $member->role_owner_extension,
                'definition_fingerprint' => $member->role_definition_fingerprint,
                'source_definition_runtime_profile' => (array) ($definition['runtime_profile'] ?? []),
                'consequential_execution_authority' => 'none',
            ],
            'is_active' => true,
        ];
        $payload['fingerprint'] = hash('sha256', json_encode($this->canonicalize($payload), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));

        $profile = WorkforceRuntimeProfile::query()->updateOrCreate(
            ['company_id' => (int) $member->company_id, 'profile_id' => $profileId],
            $payload,
        );

        if ((string) $member->runtime_profile_id !== $profileId) {
            $member->forceFill(['runtime_profile_id' => $profileId])->save();
        }

        return $profile;
    }

    public function forTask(WorkforceTask $task, WorkforceMember $member): WorkforceRuntimeProfile
    {
        if ((int) $task->company_id < 1 || (int) $task->company_id !== (int) $member->company_id) {
            throw new InvalidArgumentException('Runtime profile binding requires matching canonical company_id.');
        }

        $profile = $this->ensureForMember($member);
        $taskProfileId = trim((string) $task->runtime_profile_id);
        if ($taskProfileId !== '' && $taskProfileId !== (string) $profile->profile_id) {
            throw new InvalidArgumentException('Workforce task cannot override its employee runtime profile.');
        }
        if ($taskProfileId === '') {
            $task->forceFill(['runtime_profile_id' => (string) $profile->profile_id])->save();
        }
        if (! $profile->is_active) {
            throw new InvalidArgumentException('Workforce employee runtime profile is inactive.');
        }

        return $profile;
    }

    /** @return array<string,mixed> */
    public function runtimePayload(WorkforceRuntimeProfile $profile): array
    {
        $provider = (array) ($profile->provider_policy ?? []);
        $model = (array) ($profile->model_policy ?? []);
        $memory = (array) ($profile->memory_policy ?? []);
        $reasoning = (array) ($profile->reasoning_config ?? []);

        $payload = [
            'id' => (string) $profile->profile_id,
            'profile_fingerprint' => (string) $profile->fingerprint,
            'persona' => $profile->persona,
            'system_prompt' => (string) $profile->system_prompt,
            'provider_policy' => $provider,
            'model_policy' => $model,
            'memory_policy' => $memory,
            'channel_behavior' => (array) ($profile->channel_behavior ?? []),
            'informational_tools' => array_values(array_map('strval', (array) ($profile->informational_tools ?? []))),
            'reasoning_config' => $reasoning,
            'web_search' => (bool) ($reasoning['web_search'] ?? false),
            'memory_enabled' => (bool) ($memory['enabled'] ?? true),
            'include_user_memory' => (bool) ($memory['include_user_memory'] ?? false),
            'history_turns' => max(0, min(50, (int) ($memory['history_turns'] ?? 12))),
        ];

        $engine = $provider['engine'] ?? $provider['provider'] ?? null;
        if (is_string($engine) && trim($engine) !== '') $payload['engine'] = trim($engine);
        $modelId = $model['model'] ?? $model['id'] ?? null;
        if (is_string($modelId) && trim($modelId) !== '') $payload['model'] = trim($modelId);

        return $payload;
    }

    private function assertCompany(WorkforceMember $member): void
    {
        if ((int) $member->company_id < 1) throw new InvalidArgumentException('Workforce member runtime profile requires company_id.');
        if ((int) $member->id < 1) throw new InvalidArgumentException('Persisted Workforce member is required for runtime profile binding.');
    }

    /** @return array<string,mixed> */
    private function arrayValue(mixed $value): array
    {
        return is_array($value) ? $value : [];
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn ($item) => $this->canonicalize($item), $value);
        ksort($value);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }
}
