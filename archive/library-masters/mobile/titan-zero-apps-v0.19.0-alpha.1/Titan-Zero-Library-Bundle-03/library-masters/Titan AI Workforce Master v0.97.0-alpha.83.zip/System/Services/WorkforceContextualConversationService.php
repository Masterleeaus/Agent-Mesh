<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDivision;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceExecutionAttempt;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceOutcome;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceResponsibility;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTeam;

/**
 * Read-only contextual envelope for Ask Workforce.
 * Object context improves relevance only; it never grants or inherits authority.
 */
final class WorkforceContextualConversationService
{
    private const TYPES = ['employee','team','division','task','responsibility','provider','execution','outcome'];

    public function __construct(private readonly WorkforceConversationService $conversation) {}

    /** @return array<string,mixed> */
    public function envelope(int $companyId, string $type, string $id): array
    {
        abort_unless(in_array($type, self::TYPES, true), 404);
        $object = match ($type) {
            'employee' => $this->employee($companyId, $id),
            'team' => $this->team($companyId, $id),
            'division' => $this->division($companyId, $id),
            'task' => $this->task($companyId, $id),
            'responsibility' => $this->responsibility($companyId, $id),
            'provider' => $this->provider($companyId, $id),
            'execution' => $this->execution($companyId, $id),
            'outcome' => $this->outcome($companyId, $id),
        };

        return [
            'company_id' => $companyId,
            'context_type' => $type,
            'context_id' => $id,
            'object' => $object,
            'context_is_read_only' => true,
            'private_reasoning_exposed' => false,
            'requires_fresh_execution_authorization' => true,
            'authority_inherited' => false,
            'execution_authority_granted' => false,
        ];
    }

    /** @return array<string,mixed> */
    public function respond(int $companyId, string $type, string $id, string $message): array
    {
        $envelope = $this->envelope($companyId, $type, $id);
        $result = $this->conversation->respond($companyId, $message);
        $result['context'] = $envelope;
        $result['context_mutated'] = false;
        $result['requires_fresh_execution_authorization'] = true;
        $result['authority_inherited'] = false;
        $result['execution_authority_granted'] = false;
        return $result;
    }

    private function employee(int $companyId, string $id): array
    {
        $m = WorkforceMember::query()->forCompany($companyId)->with(['division','team','manager'])->findOrFail((int)$id);
        return ['id'=>$m->id,'name'=>$m->name,'role'=>$m->role,'status'=>(string)($m->status?->value ?? $m->status),'division'=>$m->division?->name,'team'=>$m->team?->name,'manager'=>$m->manager?->name];
    }
    private function team(int $companyId, string $id): array
    {
        $m = WorkforceTeam::query()->forCompany($companyId)->findOrFail((int)$id);
        return ['id'=>$m->id,'name'=>$m->name,'division_id'=>$m->division_id];
    }
    private function division(int $companyId, string $id): array
    {
        $m = WorkforceDivision::query()->forCompany($companyId)->findOrFail((int)$id);
        return ['id'=>$m->id,'name'=>$m->name];
    }
    private function task(int $companyId, string $id): array
    {
        $m = WorkforceTask::query()->forCompany($companyId)->with(['assignee','manager'])->findOrFail((int)$id);
        return ['id'=>$m->id,'title'=>$m->title,'status'=>(string)($m->status?->value ?? $m->status),'employee'=>$m->assignee?->name,'manager'=>$m->manager?->name,'responsibility_id'=>$m->responsibility_id ?? null];
    }
    private function responsibility(int $companyId, string $id): array
    {
        $m = WorkforceResponsibility::query()->visibleToCompany($companyId)->where(function($q) use ($id) { $q->where('id',$id)->orWhere('key',$id); })->firstOrFail();
        return ['id'=>$m->id,'key'=>$m->key,'name'=>$m->name ?? $m->title ?? $m->key,'purpose'=>$m->purpose ?? null,'owner_role'=>$m->owner_role ?? null];
    }
    private function provider(int $companyId, string $id): array
    {
        // Provider context is intentionally descriptive; live provider health remains authoritative elsewhere.
        return ['key'=>$id,'scope'=>'capability-provider','company_id'=>$companyId,'note'=>'Provider context does not imply provider availability or authority.'];
    }
    private function execution(int $companyId, string $id): array
    {
        $m = WorkforceExecutionAttempt::query()->where('id',(int)$id)->whereHas('task', fn($q) => $q->forCompany($companyId))->with(['task','worker'])->firstOrFail();
        return ['id'=>$m->id,'task_id'=>$m->task_id,'task'=>$m->task?->title,'worker'=>$m->worker?->name,'status'=>$m->status ?? null,'verified_at'=>$m->verified_at?->toIso8601String()];
    }
    private function outcome(int $companyId, string $id): array
    {
        $m = WorkforceOutcome::query()->forCompany($companyId)->findOrFail((int)$id);
        return ['id'=>$m->id,'task_id'=>$m->task_id ?? null,'type'=>$m->outcome_type ?? $m->type ?? null,'success'=>$m->success,'verified_at'=>$m->verified_at?->toIso8601String(),'summary'=>$m->summary];
    }
}
