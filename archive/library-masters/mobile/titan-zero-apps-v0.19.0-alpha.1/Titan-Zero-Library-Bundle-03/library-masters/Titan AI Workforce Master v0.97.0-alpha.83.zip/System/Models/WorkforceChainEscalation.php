<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;

final class WorkforceChainEscalation extends Model
{
    protected $table='ext_titan_ai_workforce_chain_escalations';
    protected $guarded=[];
    protected $casts=[
        'business_value'=>'decimal:2','urgency_score'=>'integer','disagreement_count'=>'integer',
        'path'=>'array','evidence'=>'array','raised_at'=>'datetime','resolved_at'=>'datetime',
    ];
    public function scopeForCompany($query,int $companyId){return $query->where('company_id',$companyId);}
}
