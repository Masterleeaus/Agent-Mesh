<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum WorkforceGoalStatus: string
{
    case Proposed = 'PROPOSED';
    case Active = 'ACTIVE';
    case AtRisk = 'AT_RISK';
    case Achieved = 'ACHIEVED';
    case Failed = 'FAILED';
    case Cancelled = 'CANCELLED';

    public function terminal(): bool
    {
        return in_array($this, [self::Achieved, self::Failed, self::Cancelled], true);
    }
}
