<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class WorkforceExecutionAttempt extends Model
{
    protected $table = 'ext_titan_ai_workforce_execution_attempts';
    protected $guarded = [];
    protected $casts = [
        'command_payload' => 'array',
        'expected_state' => 'array',
        'state_revalidation' => 'array',
        'receipt' => 'array',
        'verification' => 'array',
        'recovery' => 'array',
        'dispatched_at' => 'datetime',
        'verified_at' => 'datetime',
    ];

    public function task(): BelongsTo { return $this->belongsTo(WorkforceTask::class, 'task_id'); }
    public function worker(): BelongsTo { return $this->belongsTo(WorkforceMember::class, 'worker_member_id'); }
}
