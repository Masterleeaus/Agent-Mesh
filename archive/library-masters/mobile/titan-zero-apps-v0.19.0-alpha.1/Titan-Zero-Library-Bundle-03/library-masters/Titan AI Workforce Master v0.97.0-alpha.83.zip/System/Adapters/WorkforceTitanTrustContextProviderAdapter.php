<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Adapters;

use App\Extensions\TitanAIWorkforce\System\Contracts\WorkforceBusinessContextProviderContract;
use RuntimeException;

final class WorkforceTitanTrustContextProviderAdapter implements WorkforceBusinessContextProviderContract
{
    public function providerKey(): string { return 'titan-trust'; }
    public function providerVersion(): string { return '2.1.0'; }

    public function supports(string $surfaceId): bool
    {
        return in_array($surfaceId, [
            'trust.evidence.read','tool:trust.evidence.read',
            'trust.evidence.readiness','tool:trust.evidence.readiness',
            'trust.job.timeline.read','tool:trust.job.timeline.read',
            'trust.presence.evaluate','tool:trust.presence.evaluate',
            'trust.incident.read','tool:trust.incident.read',
        ], true);
    }

    public function read(int $companyId, string $surfaceId, array $filters = [], int $limit = 50): array
    {
        $limit = max(1, min($limit, 200));
        $jobId = (int) ($filters['job_id'] ?? 0);
        $items = match ($surfaceId) {
            'trust.evidence.read','tool:trust.evidence.read' => $this->evidence($companyId, $jobId, $limit),
            'trust.evidence.readiness','tool:trust.evidence.readiness' => $this->readiness($companyId, $jobId, $filters),
            'trust.job.timeline.read','tool:trust.job.timeline.read' => $this->timeline($companyId, $jobId, $limit),
            'trust.presence.evaluate','tool:trust.presence.evaluate' => $this->presence($filters),
            'trust.incident.read','tool:trust.incident.read' => $this->incidents($companyId, $jobId, $limit),
            default => throw new RuntimeException('Unsupported TitanTrust context surface.'),
        };

        return [
            'company_id' => $companyId,
            'surface_id' => $surfaceId,
            'items' => $items,
            'observed_at' => now()->toIso8601String(),
            'provenance' => ['provider'=>'titan-trust','provider_version'=>$this->providerVersion()],
        ];
    }

    private function evidence(int $companyId, int $jobId, int $limit): array
    {
        $class = 'App\\Extensions\\TitanTrust\\System\\Models\\WorkEvidenceItem';
        if (! class_exists($class)) throw new RuntimeException('TitanTrust evidence model unavailable.');
        $query = $class::query()->where('company_id', $companyId);
        if ($jobId > 0) $query->where('job_id', $jobId);
        return array_values($query->orderByDesc('id')->limit($limit)->get()->map(fn ($row) => $row->toArray())->all());
    }

    private function readiness(int $companyId, int $jobId, array $filters): array
    {
        if ($jobId <= 0) throw new RuntimeException('TitanTrust readiness requires job_id.');
        $class = 'App\\Extensions\\TitanTrust\\System\\Services\\EvidenceReadiness';
        if (! class_exists($class)) throw new RuntimeException('TitanTrust readiness service unavailable.');
        return [$class::forJob(
            $companyId,
            (int) ($filters['actor_user_id'] ?? 0),
            $jobId,
            isset($filters['template_id']) ? (int) $filters['template_id'] : null,
            isset($filters['job_type']) ? (string) $filters['job_type'] : null,
            isset($filters['site_type']) ? (string) $filters['site_type'] : null,
        )];
    }

    private function timeline(int $companyId, int $jobId, int $limit): array
    {
        if ($jobId <= 0) throw new RuntimeException('TitanTrust timeline requires job_id.');
        $class = 'App\\Extensions\\TitanTrust\\System\\Audit\\JobTimeline';
        if (! class_exists($class)) throw new RuntimeException('TitanTrust timeline unavailable.');
        return array_values(array_map(static fn ($row): array => (array) $row, $class::list($companyId, 0, $jobId, $limit)->all()));
    }

    private function presence(array $filters): array
    {
        $class = 'App\\Extensions\\TitanTrust\\System\\Services\\TrustEvaluator';
        if (! class_exists($class)) throw new RuntimeException('TitanTrust trust evaluator unavailable.');
        [$level, $flags] = $class::evaluate(
            isset($filters['lat']) ? (float) $filters['lat'] : null,
            isset($filters['lng']) ? (float) $filters['lng'] : null,
            isset($filters['accuracy_m']) ? (float) $filters['accuracy_m'] : null,
            isset($filters['source']) ? (string) $filters['source'] : null,
        );
        return [['trust_level'=>$level,'trust_flags'=>$flags]];
    }

    private function incidents(int $companyId, int $jobId, int $limit): array
    {
        $class = 'App\\Extensions\\TitanTrust\\System\\Models\\WorkJobIncident';
        if (! class_exists($class)) throw new RuntimeException('TitanTrust incident model unavailable.');
        $query = $class::query()->where('company_id', $companyId);
        if ($jobId > 0) $query->where('job_id', $jobId);
        return array_values($query->orderByDesc('id')->limit($limit)->get()->map(fn ($row) => $row->toArray())->all());
    }
}
