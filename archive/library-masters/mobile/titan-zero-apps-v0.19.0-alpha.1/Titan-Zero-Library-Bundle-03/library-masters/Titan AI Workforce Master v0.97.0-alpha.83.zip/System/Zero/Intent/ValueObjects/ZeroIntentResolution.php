<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Intent\ValueObjects;

use InvalidArgumentException;
use App\Extensions\TitanAIWorkforce\System\Zero\Intent\Enums\ZeroIntentResolutionStatus;

final readonly class ZeroIntentResolution
{
    /**
     * @param list<string> $clarifyingQuestions
     * @param list<string> $warnings
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public ZeroIntentRequest $request,
        public ZeroIntentGraph $graph,
        public ZeroIntentResolutionStatus $status,
        public array $clarifyingQuestions = [],
        public array $warnings = [],
        public bool $capabilityDiscoveryComplete = false,
        public bool $parametersValidated = false,
        public bool $governanceChecked = false,
        public bool $executionReady = false,
        public array $metadata = [],
    ) {
        if ($this->executionReady && (! $this->capabilityDiscoveryComplete || ! $this->parametersValidated || ! $this->governanceChecked)) {
            throw new InvalidArgumentException('Execution-ready intent requires capability discovery, parameter validation, and governance preflight.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'schema' => 'titan.zero.intent-resolution.v1',
            'status' => $this->status->value,
            'request' => $this->request->toArray(),
            'intent_graph' => $this->graph->toArray(),
            'clarifying_questions' => $this->clarifyingQuestions,
            'warnings' => $this->warnings,
            'readiness' => [
                'capability_discovery_complete' => $this->capabilityDiscoveryComplete,
                'parameters_validated' => $this->parametersValidated,
                'governance_checked' => $this->governanceChecked,
                'execution_ready' => $this->executionReady,
            ],
            'safety' => [
                'resolution_is_non_mutating' => true,
                'requires_fresh_execution_authorization' => true,
                'authority_inherited' => false,
                'execution_authority_granted' => false,
            ],
            'metadata' => $this->metadata,
        ];
    }
}
