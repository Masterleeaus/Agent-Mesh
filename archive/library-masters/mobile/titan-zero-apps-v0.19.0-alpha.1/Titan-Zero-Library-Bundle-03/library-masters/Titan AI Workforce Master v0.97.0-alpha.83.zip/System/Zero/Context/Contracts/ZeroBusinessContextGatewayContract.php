<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Context\Contracts;

interface ZeroBusinessContextGatewayContract
{
    /** @return array<string,mixed> */
    public function plan(
        int $companyId,
        string $actorId,
        string $purpose,
        array $criteria = [],
    ): array;

    /** @return array<string,mixed> */
    public function read(
        int $companyId,
        string $actorId,
        string $surfaceId,
        string $purpose,
        array $filters = [],
        int $limit = 50,
        ?string $requestedProvider = null,
        array $policy = [],
    ): array;
}
