<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Enums\WorkforceDecisionChainState;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFederation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceTask;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceDecisionChainService
{
    public const CONTRACT_VERSION = '1.1';

    public function __construct(
        private readonly WorkforceReviewerIndependenceService $independence,
    ) {}

    /** @return array<string,mixed> */
    public function contractSnapshot(array $request): array
    {
        return [
            'version'=>self::CONTRACT_VERSION,
            'required_stages'=>[
                ['stage'=>1,'stage_key'=>'ORIGIN_REVIEW','role'=>'ORIGIN_REVIEWER','purpose'=>'Validate intent, evidence, authority and knowledge context.'],
                ['stage'=>2,'stage_key'=>'DOMAIN_PROCESSING','role'=>'DOMAIN_PROCESSOR','purpose'=>'Owning-domain AI independently processes the proposed business action.'],
                ['stage'=>3,'stage_key'=>'RECEIVING_ACCEPTANCE','role'=>'RECEIVING_CHECKER','purpose'=>'Receiving-domain AI independently validates resulting state and accepts or rejects the handoff.'],
            ],
            'invariants'=>[
                'consequential_actions_require_full_chain'=>true,
                'one_identity_cannot_satisfy_multiple_independent_stages'=>true,
                'runtime_identity_must_be_independent'=>true,
                'high_risk_reuses_no_provider_model_pair'=>true,
                'critical_reviews_require_provider_diversity'=>true,
                'originator_self_review_forbidden'=>true,
                'cross_domain_receiving_checker_requires_organisational_separation'=>true,
                'downstream_stage_requires_prior_pass'=>true,
                'rejection_blocks_authority_readiness'=>true,
                'organisational_approval_is_not_execution_authority'=>true,
                'authority_gates_follow_organisational_approval'=>true,
                'declared_cross_domain_path_requires_explicit_acceptance'=>true,
                'federated_handoffs_preserve_root_chain_identity'=>true,
                'federated_rejection_rejects_root_chain'=>true,
                'partial_cross_domain_success_requires_compensation_plan'=>true,
                'compensation_unwinds_in_reverse_dependency_order'=>true,
                'consequential_compensation_requires_full_decision_chain'=>true,
                'compensation_requires_final_authority_and_verified_receipt'=>true,
                'duplicate_operations_are_idempotent'=>true,
                'idempotency_key_payload_mismatch_is_rejected'=>true,
                'stale_review_packets_are_rejected'=>true,
                'simultaneous_reviewer_claims_are_serialized'=>true,
                'federated_handoffs_bind_to_expected_handoff_uuid'=>true,
                'recovery_verification_replay_requires_identical_payload'=>true,
                'company_admin_policy_may_tighten_but_not_weaken_platform_floors'=>true,
                'admin_override_may_hold_require_manual_or_increase_scrutiny_only'=>true,
                'admin_force_approve_is_forbidden'=>true,
                'policy_changes_are_company_scoped_and_revisioned'=>true,
            ],
            'federation'=>[
                'domain_path'=>array_values((array)($request['domain_path'] ?? [])),
                'all_declared_domains_must_accept'=>true,
                'single_root_processing_identity'=>true,
            ],
            'domains'=>[
                'origin'=>$request['origin_domain'] ?? null,
                'processing'=>$request['processing_domain'] ?? null,
                'receiving'=>$request['receiving_domain'] ?? null,
            ],
        ];
    }

    public function create(
        WorkforceTask $task,
        WorkforceMember $origin,
        string $processingId,
        array $request,
        array $knowledgeReceipt
    ): WorkforceDecisionChain {
        return DB::transaction(function () use ($task,$origin,$processingId,$request,$knowledgeReceipt): WorkforceDecisionChain {
            $existing=WorkforceDecisionChain::query()->forCompany((int)$task->company_id)
                ->where('processing_id',$processingId)->lockForUpdate()->first();
            if ($existing) return $existing;

            $chain=WorkforceDecisionChain::query()->create([
                'chain_uuid'=>(string)Str::uuid(),
                'company_id'=>(int)$task->company_id,
                'task_id'=>$task->getKey(),
                'processing_id'=>$processingId,
                'originator_member_id'=>$origin->getKey(),
                'origin_domain'=>$request['origin_domain'] ?? null,
                'processing_domain'=>$request['processing_domain'] ?? null,
                'receiving_domain'=>$request['receiving_domain'] ?? null,
                'consequential'=>(bool)($request['consequential'] ?? true),
                'risk_class'=>(string)($request['risk_class'] ?? $task->risk_level ?? 'ordinary'),
                'state'=>WorkforceDecisionChainState::PendingOriginReview,
                'current_stage'=>1,
                'required_stage_count'=>3,
                'organisationally_approved'=>false,
                'authority_gates_ready'=>false,
                'contract_snapshot'=>$this->contractSnapshot($request),
                'knowledge_receipt'=>$knowledgeReceipt,
                'metadata'=>[
                    'request_fingerprint'=>hash('sha256',json_encode($request,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)),
                    'request_snapshot'=>$request,
                    'created_from'=>'three-stage-processing',
                ],
            ]);
            $this->event($chain,'CHAIN_CREATED',$origin,null,WorkforceDecisionChainState::PendingOriginReview,[
                'contract_version'=>self::CONTRACT_VERSION,
                'consequential'=>$chain->consequential,
            ]);
            return $chain;
        },3);
    }


    public function assertReviewerEligible(
        WorkforceDecisionChain $chain,
        int $stage,
        WorkforceMember $reviewer
    ): void {
        if ($stage < 1 || $stage > 3) {
            throw new RuntimeException('DECISION_CHAIN_UNKNOWN_STAGE');
        }
        if ((int)$chain->current_stage !== $stage) {
            throw new RuntimeException('DECISION_CHAIN_STAGE_OUT_OF_SEQUENCE');
        }
        $this->independence->assertEligible($chain,$stage,$reviewer);
    }

    public function recordStageDecision(
        WorkforceDecisionChain $chain,
        WorkforceProcessingCheckpoint $checkpoint,
        WorkforceMember $reviewer,
        bool $passes,
        array $decision = []
    ): WorkforceDecisionChain {
        return DB::transaction(function () use ($chain,$checkpoint,$reviewer,$passes,$decision): WorkforceDecisionChain {
            $locked=WorkforceDecisionChain::query()->forCompany((int)$chain->company_id)
                ->whereKey($chain->getKey())->lockForUpdate()->firstOrFail();

            if ((int)$checkpoint->stage !== (int)$locked->current_stage) {
                throw new RuntimeException('DECISION_CHAIN_STAGE_OUT_OF_SEQUENCE');
            }

            $this->assertReviewerEligible($locked,(int)$checkpoint->stage,$reviewer);

            $from=$locked->state;
            if (! $passes) {
                $locked->forceFill([
                    'state'=>WorkforceDecisionChainState::Rejected,
                    'organisationally_approved'=>false,
                    'authority_gates_ready'=>false,
                    'closed_at'=>now(),
                ])->save();
                $this->event($locked,'STAGE_REJECTED',$reviewer,(int)$checkpoint->stage,$from,[
                    'decision'=>$decision,
                ],WorkforceDecisionChainState::Rejected);
                return $locked->refresh();
            }

            $stage=(int)$checkpoint->stage;
            if ($stage===1) {
                $to=WorkforceDecisionChainState::PendingDomainProcessing;
                $locked->forceFill(['state'=>$to,'current_stage'=>2])->save();
            } elseif ($stage===2) {
                $to=WorkforceDecisionChainState::PendingReceivingAcceptance;
                $locked->forceFill(['state'=>$to,'current_stage'=>3])->save();
            } elseif ($stage===3) {
                $federation=WorkforceChainFederation::query()->forCompany((int)$locked->company_id)
                    ->where('decision_chain_id',$locked->getKey())->first();
                $hasPendingFederatedHandoffs=$federation
                    && (int)$federation->accepted_handoff_count < (int)$federation->handoff_count;

                if($hasPendingFederatedHandoffs){
                    $to=WorkforceDecisionChainState::PendingFederatedAcceptance;
                    $locked->forceFill([
                        'state'=>$to,'current_stage'=>3,
                        'organisationally_approved'=>false,
                        'authority_gates_ready'=>false,
                        'metadata'=>array_merge((array)$locked->metadata,[
                            'federation_uuid'=>$federation->federation_uuid,
                            'federated_handoffs_complete'=>false,
                        ]),
                    ])->save();
                }else{
                    $to=WorkforceDecisionChainState::OrganisationallyApproved;
                    $locked->forceFill([
                        'state'=>$to,'current_stage'=>3,
                        'organisationally_approved'=>true,
                        'authority_gates_ready'=>true,
                        'approved_at'=>now(),
                    ])->save();
                }
            } else {
                throw new RuntimeException('DECISION_CHAIN_UNKNOWN_STAGE');
            }

            $this->event($locked,'STAGE_PASSED',$reviewer,$stage,$from,[
                'decision'=>$decision,
                'authority_gates_ready'=>$locked->authority_gates_ready,
            ],$to);
            return $locked->refresh();
        },3);
    }

    public function assertAuthorityReady(WorkforceTask $task, ?string $processingId = null): WorkforceDecisionChain
    {
        $query=WorkforceDecisionChain::query()->forCompany((int)$task->company_id)->where('task_id',$task->getKey());
        if ($processingId) $query->where('processing_id',$processingId);
        $chain=$query->latest('id')->first();

        if (! $chain) throw new RuntimeException('CONSEQUENTIAL_ACTION_REQUIRES_DECISION_CHAIN');
        if (! $chain->organisationally_approved || ! $chain->authority_gates_ready) {
            throw new RuntimeException('DECISION_CHAIN_NOT_READY_FOR_AUTHORITY_GATES');
        }
        return $chain;
    }

    public function isOrganisationallyApproved(int $companyId, string $processingId): bool
    {
        return WorkforceDecisionChain::query()->forCompany($companyId)
            ->where('processing_id',$processingId)
            ->where('organisationally_approved',true)
            ->where('authority_gates_ready',true)
            ->exists();
    }

    /** @param array<string,mixed> $evidence */
    private function event(
        WorkforceDecisionChain $chain,
        string $eventType,
        ?WorkforceMember $actor,
        ?int $stage,
        ?WorkforceDecisionChainState $from,
        array $evidence,
        ?WorkforceDecisionChainState $to = null
    ): void {
        DB::table('ext_titan_ai_workforce_decision_chain_events')->insert([
            'company_id'=>$chain->company_id,
            'decision_chain_id'=>$chain->getKey(),
            'processing_id'=>$chain->processing_id,
            'stage'=>$stage,
            'event_type'=>$eventType,
            'actor_member_id'=>$actor?->getKey(),
            'from_state'=>$from?->value,
            'to_state'=>$to?->value,
            'evidence'=>json_encode($evidence,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),
            'occurred_at'=>now(),'created_at'=>now(),'updated_at'=>now(),
        ]);
    }
}
