<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainLearningRecommendation;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerCombinationLearning;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceReviewerFeedback;
use Illuminate\Support\Str;
use RuntimeException;

final class WorkforceChainLearningPolicyService
{
    public function refreshCompany(int $companyId): array
    {
        $scopes=WorkforceDecisionChain::query()->forCompany($companyId)
            ->with('task')->where('created_at','>=',now()->subDays(180))->get()
            ->map(fn($c)=>(string)($c->task?->capability ?: '*'))->unique()->values();

        $results=[];
        foreach($scopes as $scope){
            $results[$scope]=$this->refreshScope($companyId,$scope);
        }
        if(!$scopes->contains('*')) $results['*']=$this->refreshScope($companyId,'*');
        return $results;
    }

    /** @return array<string,mixed> */
    public function refreshScope(int $companyId,string $scopeKey): array
    {
        $chains=WorkforceDecisionChain::query()->forCompany($companyId)->with('task')
            ->where('created_at','>=',now()->subDays(180))
            ->when($scopeKey!=='*',fn($q)=>$q->whereHas('task',fn($t)=>$t->where('capability',$scopeKey)))
            ->latest()->limit(500)->get();

        $combos=[];
        foreach($chains as $chain){
            $checkpoints=WorkforceProcessingCheckpoint::query()->forCompany($companyId)
                ->where('processing_id',$chain->processing_id)->orderBy('stage')->get();
            if($checkpoints->count()<3 || $checkpoints->whereNotNull('reviewer_member_id')->count()<3) continue;

            $sig=$checkpoints->map(fn($c)=>[
                'stage'=>(int)$c->stage,
                'member_id'=>(int)$c->reviewer_member_id,
                'role'=>(string)$c->reviewer_role,
                'provider'=>data_get($c->metadata ?? [],'provider_key'),
                'model'=>data_get($c->metadata ?? [],'model_key'),
            ])->values()->all();
            $hash=hash('sha256',json_encode($sig,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));

            $gate=WorkforceFinalAuthorityGate::query()->forCompany($companyId)
                ->where('processing_id',$chain->processing_id)->first();
            $challenges=WorkforceDecisionChallenge::query()->forCompany($companyId)
                ->where('processing_id',$chain->processing_id)->count();
            $feedback=WorkforceReviewerFeedback::query()->forCompany($companyId)
                ->where('processing_id',$chain->processing_id)->get();
            $verified=$feedback->where('verified_outcome',true);
            $success=$verified->isNotEmpty() && $verified->avg('quality_score')>=70;
            $overturn=$verified->where('overturned',true)->count()>0;
            $latency=max(0,$chain->created_at?->diffInSeconds($chain->updated_at) ?? 0);

            if(!isset($combos[$hash])) $combos[$hash]=[
                'signature'=>$sig,'sample'=>0,'success'=>0,'disagreement'=>0,'denied'=>0,'overturn'=>0,'latency'=>0.0,'quality'=>[]
            ];
            $combos[$hash]['sample']++;
            $combos[$hash]['success'] += $success?1:0;
            $combos[$hash]['disagreement'] += $challenges>0?1:0;
            $combos[$hash]['denied'] += ($gate && !$gate->final_allowed)?1:0;
            $combos[$hash]['overturn'] += $overturn?1:0;
            $combos[$hash]['latency'] += $latency;
            if($feedback->isNotEmpty()) $combos[$hash]['quality'][]=(float)$feedback->avg('quality_score');
        }

        $persisted=[];
        foreach($combos as $hash=>$row){
            $n=max(1,$row['sample']);
            $quality=$row['quality']===[]?null:array_sum($row['quality'])/count($row['quality']);
            $record=WorkforceReviewerCombinationLearning::query()->updateOrCreate(
                ['company_id'=>$companyId,'scope_key'=>$scopeKey,'combination_sha256'=>$hash],
                [
                    'reviewer_signature'=>$row['signature'],'sample_size'=>$row['sample'],
                    'success_rate'=>round(100*$row['success']/$n,2),
                    'disagreement_rate'=>round(100*$row['disagreement']/$n,2),
                    'authority_denial_rate'=>round(100*$row['denied']/$n,2),
                    'overturn_rate'=>round(100*$row['overturn']/$n,2),
                    'average_latency_seconds'=>round($row['latency']/$n,2),
                    'quality_score'=>$quality===null?null:round($quality,2),
                    'calculated_at'=>now(),
                ]
            );
            $persisted[]=$record;
        }

        $recommendations=$this->recommend($companyId,$scopeKey,collect($persisted),$chains->count());
        return [
            'scope_key'=>$scopeKey,
            'chain_sample'=>$chains->count(),
            'combination_count'=>count($persisted),
            'recommendations'=>$recommendations,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public function approvedPolicy(int $companyId,string $scopeKey): array
    {
        return WorkforceChainLearningRecommendation::query()->forCompany($companyId)
            ->whereIn('scope_key',[$scopeKey,'*'])->where('status','APPROVED')
            ->orderByDesc('approved_at')->get()
            ->groupBy('recommendation_type')
            ->map(fn($rows)=>(array)$rows->first()->recommended_policy)
            ->all();
    }

    public function approve(int $companyId,string $recommendationUuid,int $userId): WorkforceChainLearningRecommendation
    {
        $record=WorkforceChainLearningRecommendation::query()->forCompany($companyId)
            ->where('recommendation_uuid',$recommendationUuid)->firstOrFail();
        if($record->status!=='PROPOSED') throw new RuntimeException('CHAIN_LEARNING_RECOMMENDATION_NOT_PROPOSED');
        $record->forceFill([
            'status'=>'APPROVED','approved_by_user_id'=>$userId,'approved_at'=>now(),
            'rejected_by_user_id'=>null,'rejected_at'=>null,
        ])->save();
        return $record->refresh();
    }

    public function reject(int $companyId,string $recommendationUuid,int $userId): WorkforceChainLearningRecommendation
    {
        $record=WorkforceChainLearningRecommendation::query()->forCompany($companyId)
            ->where('recommendation_uuid',$recommendationUuid)->firstOrFail();
        if($record->status!=='PROPOSED') throw new RuntimeException('CHAIN_LEARNING_RECOMMENDATION_NOT_PROPOSED');
        $record->forceFill([
            'status'=>'REJECTED','rejected_by_user_id'=>$userId,'rejected_at'=>now(),
            'approved_by_user_id'=>null,'approved_at'=>null,
        ])->save();
        return $record->refresh();
    }

    /** @return array<int,array<string,mixed>> */
    private function recommend(int $companyId,string $scopeKey,$combos,int $chainSample): array
    {
        if($chainSample<5 || $combos->isEmpty()) return [];

        $best=$combos->sortByDesc(fn($r)=>$this->comboUtility($r))->first();
        $worst=$combos->sortBy(fn($r)=>$this->comboUtility($r))->first();
        $recs=[];

        if($best && $best->sample_size>=3 && ($best->quality_score ?? 0)>=75){
            $recs[]=$this->upsertRecommendation($companyId,$scopeKey,'REVIEWER_COMBINATION_PREFERENCE',[
                'preferred_combination_sha256'=>$best->combination_sha256,
                'preferred_reviewer_signature'=>$best->reviewer_signature,
                'minimum_sample_size'=>3,
            ],[
                'sample_size'=>$best->sample_size,'success_rate'=>$best->success_rate,
                'disagreement_rate'=>$best->disagreement_rate,'authority_denial_rate'=>$best->authority_denial_rate,
                'overturn_rate'=>$best->overturn_rate,'quality_score'=>$best->quality_score,
            ],$best->sample_size,min(95,55+$best->sample_size*4));
        }

        $avgDisagreement=(float)$combos->avg('disagreement_rate');
        if($avgDisagreement>=20){
            $recs[]=$this->upsertRecommendation($companyId,$scopeKey,'EVIDENCE_REQUIREMENTS',[
                'require_explicit_evidence_refs'=>true,
                'require_assumptions_declaration'=>true,
                'require_unresolved_questions_declaration'=>true,
            ],['average_disagreement_rate'=>$avgDisagreement,'combination_count'=>$combos->count()],
            $chainSample,min(95,50+$chainSample*.8));
        }

        $avgDenial=(float)$combos->avg('authority_denial_rate');
        if($avgDenial>=15){
            $recs[]=$this->upsertRecommendation($companyId,$scopeKey,'PRE_AUTHORITY_ASSURANCE',[
                'force_assurance'=>true,
                'minimum_decision_quality'=>80,
            ],['average_authority_denial_rate'=>$avgDenial],$chainSample,min(95,55+$chainSample*.6));
        }

        $avgOverturn=(float)$combos->avg('overturn_rate');
        if($avgOverturn>=10){
            $recs[]=$this->upsertRecommendation($companyId,$scopeKey,'REVIEWER_QUALITY_FLOOR',[
                'minimum_decision_quality'=>85,
                'prefer_provider_diversity'=>true,
            ],['average_overturn_rate'=>$avgOverturn],$chainSample,min(95,60+$chainSample*.5));
        }

        if($worst && $worst->sample_size>=3 && $this->comboUtility($worst)<45){
            $recs[]=$this->upsertRecommendation($companyId,$scopeKey,'REVIEWER_COMBINATION_AVOID',[
                'avoid_combination_sha256'=>$worst->combination_sha256,
                'avoid_reviewer_signature'=>$worst->reviewer_signature,
            ],[
                'sample_size'=>$worst->sample_size,'success_rate'=>$worst->success_rate,
                'disagreement_rate'=>$worst->disagreement_rate,'authority_denial_rate'=>$worst->authority_denial_rate,
                'overturn_rate'=>$worst->overturn_rate,'quality_score'=>$worst->quality_score,
            ],$worst->sample_size,min(95,55+$worst->sample_size*4));
        }

        return array_values(array_filter($recs));
    }

    private function comboUtility($r): float
    {
        return max(0,min(100,
            ((float)$r->success_rate)*.35
            +((float)($r->quality_score ?? 50))*.30
            +(100-(float)$r->disagreement_rate)*.10
            +(100-(float)$r->authority_denial_rate)*.10
            +(100-(float)$r->overturn_rate)*.15
        ));
    }

    private function upsertRecommendation(
        int $companyId,string $scopeKey,string $type,array $policy,array $evidence,int $sample,float $confidence
    ): ?array {
        $existing=WorkforceChainLearningRecommendation::query()->forCompany($companyId)
            ->where('scope_key',$scopeKey)->where('recommendation_type',$type)->where('status','PROPOSED')->first();

        $record=$existing ?: new WorkforceChainLearningRecommendation();
        $record->fill([
            'recommendation_uuid'=>$existing?->recommendation_uuid ?: (string)Str::uuid(),
            'company_id'=>$companyId,'scope_key'=>$scopeKey,'recommendation_type'=>$type,'status'=>'PROPOSED',
            'confidence'=>round(max(0,min(100,$confidence)),2),'sample_size'=>$sample,
            'current_policy'=>[],'recommended_policy'=>$policy,'evidence'=>$evidence,
            'expected_effect'=>['authority_mutation_requested'=>false,'requires_user_approval'=>true],
            'generated_at'=>now(),
        ])->save();

        return [
            'recommendation_uuid'=>$record->recommendation_uuid,'type'=>$type,'status'=>'PROPOSED',
            'confidence'=>(float)$record->confidence,'sample_size'=>$record->sample_size,
            'recommended_policy'=>$record->recommended_policy,'evidence'=>$record->evidence,
            'requires_user_approval'=>true,
        ];
    }
}
