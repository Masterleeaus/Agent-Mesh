<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Enums;

enum DeadlockResolution: string
{
    case RetryWithEvidence = 'RETRY_WITH_EVIDENCE';
    case ReturnToMaker = 'RETURN_TO_MAKER';
    case EscalateToParent = 'ESCALATE_TO_PARENT';
    case EscalateToTitan = 'ESCALATE_TO_TITAN';
    case HumanDecisionRequired = 'HUMAN_DECISION_REQUIRED';
}
