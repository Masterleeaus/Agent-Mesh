<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Support;

final class WorkforceCapabilityCatalog
{
    public static function all(): array
    {
        $floors = ['Suggest'=>0,'Assist'=>16,'Semi-Auto'=>31,'Auto'=>51,'Trusted Auto'=>71,'Predictive'=>86];
        $base = static fn(string $name, string $risk, string $autonomy, array $evidence, string $offline, string $reversible, string $idempotency): array => [
            'capability' => $name,
            'owning_extension' => 'titan-ai-workforce',
            'input_contract' => 'array:company_id,trace_id,correlation_id,causation_id,payload',
            'output_contract' => 'array:status,task_or_receipt,reason_codes',
            'risk_profile' => $risk,
            'autonomy_requirement' => [
                'minimum_score' => $floors[$autonomy] ?? 0,
                'minimum_band' => $autonomy,
                'variant' => 'standard',
                'authority_source' => 'titan_autonomy',
            ],
            'evidence_requirements' => $evidence,
            'offline_policy' => $offline,
            'reversibility' => $reversible,
            'idempotency_strategy' => $idempotency,
        ];

        return [
            'workforce.member.create' => $base('workforce.member.create','LOW','Assist',['valid installed RoleDefinition','tenant context'],'OFFLINE_PREPARE_ONLY','suspend / retire','tenant+member-key'),
            'workforce.member.activate' => $base('workforce.member.activate','LOW','Assist',['owner extension','RoleDefinition fingerprint','manager constraint'],'OFFLINE_BLOCKED','suspend / retire','tenant+member-key+definition-fingerprint'),
            'workforce.member.suspend' => $base('workforce.member.suspend','MEDIUM','Assist',['member lifecycle state','authorized actor'],'OFFLINE_BLOCKED','resume when definition remains valid','member+lifecycle-state-version'),
            'workforce.member.resume' => $base('workforce.member.resume','MEDIUM','Assist',['valid current RoleDefinition','member lifecycle state'],'OFFLINE_BLOCKED','suspend again','member+lifecycle-state-version'),
            'workforce.member.retire' => $base('workforce.member.retire','MEDIUM','Assist',['member lifecycle state','optional same-role replacement'],'OFFLINE_BLOCKED','not automatically reversible','member+retirement-state'),
            'workforce.task.create' => $base('workforce.task.create','MINIMAL','Assist',['origin','assigned responsibility'],'OFFLINE_PREPARE_ONLY','cancel before execution','tenant+idempotency-key'),
            'workforce.task.submit' => $base('workforce.task.submit','LOW','Assist',['maker output','manager relationship'],'OFFLINE_PREPARE_ONLY','return to maker','task+state-version'),
            'workforce.task.review' => $base('workforce.task.review','LOW','Assist',['task evidence','reviewer role'],'OFFLINE_BLOCKED','revision / reversal before execution','task+reviewer+state-version'),
            'workforce.handoff.create' => $base('workforce.handoff.create','LOW','Assist',['origin manager approval','receiving manager identity'],'OFFLINE_BLOCKED','return handoff','task+receiver+state-version'),
            'workforce.handoff.review' => $base('workforce.handoff.review','LOW','Assist',['handoff packet','receiving manager review'],'OFFLINE_BLOCKED','return to origin','handoff+receiver+state-version'),
            'workforce.schedule.manage' => $base('workforce.schedule.manage','MEDIUM','Assist',['role responsibility','schedule policy'],'OFFLINE_BLOCKED','disable schedule','tenant+member+schedule-key'),
            'workforce.role.read' => $base('workforce.role.read','MINIMAL','Suggest',[],'OFFLINE_PREPARE_ONLY','not applicable','role-registry-version'),
            'workforce.manifest-health.read' => $base('workforce.manifest-health.read','MINIMAL','Suggest',['extension manifest validation status'],'OFFLINE_PREPARE_ONLY','not applicable','manifest-registry-version'),
            'workforce.manifest-lifecycle.reconcile' => $base('workforce.manifest-lifecycle.reconcile','MEDIUM','Assist',['extension lifecycle event','pinned role-definition provenance'],'OFFLINE_BLOCKED','restore source definition or explicit rebind','owner-extension+role-definition+fingerprint'),
            'workforce.plan.recommend' => $base('workforce.plan.recommend','LOW','Suggest',['workload metrics','business tier','vertical context'],'OFFLINE_PREPARE_ONLY','recommendation only','tenant+planning-snapshot'),
            'workforce.workload.reassign' => $base('workforce.workload.reassign','MEDIUM','Assist',['capability match','same-division policy','current workload','manager/policy delegation'],'OFFLINE_BLOCKED','reassign back to prior owner','task+assignee+state-version'),
            'workforce.organisation.read' => $base('workforce.organisation.read','MINIMAL','Suggest',['tenant organisational graph'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+graph-version'),
            'workforce.organisation.manage' => $base('workforce.organisation.manage','MEDIUM','Assist',['tenant graph','validated reporting line','authorized actor'],'OFFLINE_BLOCKED','restore previous reporting relation','tenant+member+graph-version'),
            'workforce.deputy.appoint' => $base('workforce.deputy.appoint','MEDIUM','Assist',['Tier 1 manager','same-division deputy','explicit scope','future expiry'],'OFFLINE_BLOCKED','deactivate substitutes_for relationship','manager+deputy+scope+expiry'),
            'workforce.decision-right.read' => $base('workforce.decision-right.read','MINIMAL','Suggest',['extension-owned RACI manifest'],'OFFLINE_PREPARE_ONLY','not applicable','owner-extension+decision+manifest-version'),
            'workforce.decision-rights.read' => $base('workforce.decision-rights.read','MINIMAL','Suggest',[],'OFFLINE_PREPARE_ONLY','not applicable','policy-version'),
            'workforce.manager.objective.decompose' => $base('workforce.manager.objective.decompose','LOW','Assist',['manager role contract','objective','validated specialist plan'],'OFFLINE_PREPARE_ONLY','cancel child tasks before execution','objective+plan-step'),
            'workforce.manager.queue.read' => $base('workforce.manager.queue.read','MINIMAL','Suggest',['manager identity'],'OFFLINE_PREPARE_ONLY','not applicable','manager+queue-snapshot'),
            'workforce.council.convene' => $base('workforce.council.convene','LOW','Assist',['council policy','participant roles','operational context'],'OFFLINE_PREPARE_ONLY','cancel generated objective','council+period'),
            'workforce.dispute.raise' => $base('workforce.dispute.raise','MEDIUM','Assist',['dispute route','affected managers','supporting context'],'OFFLINE_PREPARE_ONLY','resolve/cancel escalation task','conflict+dispute-id'),
            'workforce.deputy.assign' => $base('workforce.deputy.assign','MEDIUM','Assist',['manager identity','deputy identity','scope','expiry'],'OFFLINE_BLOCKED','deactivate relationship','manager+deputy+scope'),
            'workforce.dependency.link' => $base('workforce.dependency.link','MINIMAL','Assist',['validated acyclic manager plan'],'OFFLINE_PREPARE_ONLY','remove dependency before execution','task+dependency'),
            'workforce.chain.integrity.read' => $base('workforce.chain.integrity.read','MINIMAL','Suggest',['tenant task/dependency/handoff graph'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+chain-snapshot'),
            'workforce.responsibility.read' => $base('workforce.responsibility.read','MINIMAL','Suggest',['registered role'],'OFFLINE_PREPARE_ONLY','not applicable','role+responsibility-registry-version'),
            'workforce.responsibility.sync' => $base('workforce.responsibility.sync','LOW','Assist',['registered role','schedule policy'],'OFFLINE_BLOCKED','disable generated schedules','tenant+member+responsibility-key'),
            'workforce.queue-health.read' => $base('workforce.queue-health.read','MINIMAL','Suggest',['manager identity','tenant context'],'OFFLINE_PREPARE_ONLY','not applicable','manager+queue-snapshot'),
            'workforce.proactive-runtime.read' => $base('workforce.proactive-runtime.read','MINIMAL','Suggest',['tenant context','extension manifest health','routine provenance'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+routine-registry-snapshot'),
            'workforce.proactive-management.run' => $base('workforce.proactive-management.run','LOW','Assist',['manager role','queue health','workload policy'],'OFFLINE_BLOCKED','reassignment may be reassigned back','manager+15-minute-window'),
            'workforce.trust-health.read' => $base('workforce.trust-health.read','MINIMAL','Suggest',['tenant context'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+trust-snapshot'),
            'workforce.autonomy.read' => $base('workforce.autonomy.read','MINIMAL','Suggest',['Titan Autonomy Decision v2','exact capability/variant/workflow/context key'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+member+capability+context+decision-id'),
            'workforce.pre-execution-governance.read' => $base('workforce.pre-execution-governance.read','MINIMAL','Suggest',['Titan Risk decision','Titan Assurance decision','optional Model Council decision','Interaction workflow evidence'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+task+risk+assurance+council-policy'),
            'workforce.execution.dispatch' => $base('workforce.execution.dispatch','HIGH','Auto',['locked execution intent','pre-execution state revalidation','Risk/Assurance/Autonomy decisions'],'OFFLINE_BLOCKED','capability-defined reversible/compensatable/irreversible','tenant+intent-sha256+state-fingerprint'),
            'workforce.execution.verify' => $base('workforce.execution.verify','MEDIUM','Assist',['authoritative Command Bus receipt','expected outcome/state'],'OFFLINE_BLOCKED','not applicable','tenant+receipt-sha256+intent-id'),
            'workforce.execution.recover' => $base('workforce.execution.recover','HIGH','Assist',['execution attempt ledger','intent id','idempotency key','receipt reconciliation evidence'],'OFFLINE_BLOCKED','capability-defined compensation only','tenant+intent-id+recovery-state'),
            'workforce.performance.read' => $base('workforce.performance.read','MINIMAL','Suggest',['persistent task/review history'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+performance-snapshot'),
            'workforce.control-room.read' => $base('workforce.control-room.read','MINIMAL','Suggest',['tenant context'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+control-room-snapshot'),
            'workforce.staffing.refresh' => $base('workforce.staffing.refresh','LOW','Assist',['business tier','vertical context','queue health'],'OFFLINE_BLOCKED','recommendation may be rejected','tenant+role+recommendation-state'),
            'workforce.staffing.review' => $base('workforce.staffing.review','LOW','Assist',['staffing proposal','authorized user review'],'OFFLINE_BLOCKED','approved proposal may be rejected before activation','proposal+review-state'),
            'workforce.outcome-references.read' => $base('workforce.outcome-references.read','MINIMAL','Suggest',['execution receipt references'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+outcome-snapshot'),
            'workforce.journey.read' => $base('workforce.journey.read','MINIMAL','Suggest',['structured task/review/handoff/execution/outcome references'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+correlation+journey-event-sha256'),
            'workforce.outcome-health.read' => $base('workforce.outcome-health.read','MINIMAL','Suggest',['execution attempt verification states'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+outcome-health-snapshot'),
            'workforce.vertical-overlay.read' => $base('workforce.vertical-overlay.read','MINIMAL','Suggest',['vertical context'],'OFFLINE_PREPARE_ONLY','not applicable','tenant+vertical+overlay-version'),
        ];
    }
}
