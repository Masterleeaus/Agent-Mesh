<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkforceSchedule extends Model
{
    use SoftDeletes;
    protected $table = 'ext_titan_ai_workforce_schedules';
    protected $guarded = [];
    protected $casts = ['conditions' => 'array', 'schedule' => 'array', 'task_template' => 'array', 'next_run_at' => 'datetime', 'last_run_at' => 'datetime', 'is_active' => 'boolean', 'metadata' => 'array'];
    public function scopeForCompany($query, int $companyId) { return $query->where('company_id', $companyId); }
}
