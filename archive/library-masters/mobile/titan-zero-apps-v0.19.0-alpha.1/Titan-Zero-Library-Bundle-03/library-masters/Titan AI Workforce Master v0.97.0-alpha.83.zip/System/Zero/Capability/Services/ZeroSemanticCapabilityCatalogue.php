<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Services;

use App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts\ZeroSemanticCapabilityCatalogueContract;
use RuntimeException;

/**
 * Non-authoritative semantic projection of the canonical Titan capability registry.
 *
 * Pass 2 makes provider-owned capability identifiers understandable/searchable by Zero.
 * Semantic metadata can guide discovery only. It cannot grant authority, select an
 * execution provider, infer missing consequential parameters, or execute commands.
 */
final class ZeroSemanticCapabilityCatalogue implements ZeroSemanticCapabilityCatalogueContract
{
    private const DEFAULT_CATALOGUE = __DIR__ . '/../../../../resources/workforce/zero-semantic-capability-catalogue.json';
    private const DEFAULT_SOURCE_REGISTRY = __DIR__ . '/../../../../resources/workforce/ecosystem-capability-registry.json';

    /** @var array<string,mixed>|null */
    private ?array $catalogue = null;
    /** @var array<string,array<string,mixed>>|null */
    private ?array $byId = null;

    public function __construct(
        private readonly ?string $cataloguePath = null,
        private readonly ?string $sourceRegistryPath = null,
    ) {}

    /** @return array<string,mixed> */
    public function all(): array
    {
        if ($this->catalogue !== null) return $this->catalogue;

        $path = $this->cataloguePath ?: self::DEFAULT_CATALOGUE;
        if (! is_file($path)) throw new RuntimeException("Zero semantic capability catalogue missing: {$path}");
        $decoded = json_decode((string) file_get_contents($path), true);
        if (! is_array($decoded)) throw new RuntimeException('Zero semantic capability catalogue JSON is invalid.');

        if (($decoded['schema_version'] ?? null) !== '1.0'
            || ($decoded['schema'] ?? null) !== 'titan.zero.semantic-capability-catalogue.v1'
            || ($decoded['organisation_owner'] ?? null) !== 'titan-ai-workforce'
            || ($decoded['tenant_key'] ?? null) !== 'company_id'
            || ! is_array($decoded['capabilities'] ?? null)) {
            throw new RuntimeException('Zero semantic capability catalogue contract is invalid.');
        }

        $safety = is_array($decoded['safety'] ?? null) ? $decoded['safety'] : [];
        if (($safety['semantic_metadata_is_authoritative'] ?? true) !== false
            || ($safety['catalogue_grants_authority'] ?? true) !== false
            || ($safety['catalogue_executes_commands'] ?? true) !== false
            || ($safety['unknown_parameters_are_not_invented'] ?? false) !== true) {
            throw new RuntimeException('Zero semantic capability catalogue safety invariants are invalid.');
        }

        $this->assertSourceRegistryBinding($decoded);
        $this->assertCapabilityIntegrity($decoded['capabilities']);

        return $this->catalogue = $decoded;
    }

    /** @return list<array<string,mixed>> */
    public function capabilities(): array
    {
        return array_values(array_filter($this->all()['capabilities'], 'is_array'));
    }

    /** @return array<string,mixed>|null */
    public function capability(string $capabilityId): ?array
    {
        $needle = trim($capabilityId);
        if ($needle === '') return null;
        if ($this->byId === null) {
            $this->byId = [];
            foreach ($this->capabilities() as $capability) {
                $id = (string) ($capability['id'] ?? '');
                if ($id !== '') $this->byId[$id] = $capability;
            }
        }
        return $this->byId[$needle] ?? null;
    }

    /** @return list<array<string,mixed>> */
    public function providerCapabilities(string $providerKey): array
    {
        $providerKey = strtolower(trim($providerKey));
        if ($providerKey === '') return [];
        return array_values(array_filter($this->capabilities(), static fn (array $capability): bool =>
            strtolower((string) ($capability['provider'] ?? '')) === $providerKey
        ));
    }

    /** @return array<string,mixed> */
    public function coverage(): array
    {
        return is_array($this->all()['coverage'] ?? null) ? $this->all()['coverage'] : [];
    }

    /**
     * Embedding/search text is deliberately prebuilt so Pass 3 can add local semantic
     * ranking without having to reconstruct human-readable capability meaning at runtime.
     */
    public function searchDocument(string $capabilityId): ?string
    {
        $capability = $this->capability($capabilityId);
        if ($capability === null) return null;
        $document = trim((string) ($capability['search_document'] ?? ''));
        return $document !== '' ? $document : null;
    }

    /** @param array<string,mixed> $decoded */
    private function assertSourceRegistryBinding(array $decoded): void
    {
        $source = $this->sourceRegistryPath ?: self::DEFAULT_SOURCE_REGISTRY;
        if (! is_file($source)) throw new RuntimeException("Canonical capability source registry missing: {$source}");
        $actual = hash_file('sha256', $source);
        $expected = strtolower(trim((string) ($decoded['source_registry_sha256'] ?? '')));
        if (! is_string($actual) || $expected === '' || ! hash_equals($expected, strtolower($actual))) {
            throw new RuntimeException('Zero semantic capability catalogue is stale relative to the canonical source registry.');
        }
    }

    /** @param mixed $capabilities */
    private function assertCapabilityIntegrity(mixed $capabilities): void
    {
        if (! is_array($capabilities) || $capabilities === []) {
            throw new RuntimeException('Zero semantic capability catalogue contains no capabilities.');
        }

        $ids = [];
        foreach ($capabilities as $row) {
            if (! is_array($row)) throw new RuntimeException('Zero semantic capability catalogue contains a malformed capability.');
            $id = trim((string) ($row['id'] ?? ''));
            if ($id === '' || isset($ids[$id])) throw new RuntimeException('Zero semantic capability IDs must be present and unique.');
            $ids[$id] = true;
            if (trim((string) ($row['title'] ?? '')) === ''
                || trim((string) ($row['description'] ?? '')) === ''
                || trim((string) ($row['search_document'] ?? '')) === ''
                || ! is_array($row['aliases'] ?? null)
                || ! is_array($row['parameters'] ?? null)
                || ! is_array($row['provenance'] ?? null)) {
                throw new RuntimeException("Zero semantic capability metadata incomplete for {$id}.");
            }
            if (($row['provenance']['semantic_metadata_authoritative'] ?? true) !== false
                || ($row['provenance']['catalogue_grants_authority'] ?? true) !== false
                || ($row['provenance']['catalogue_can_execute'] ?? true) !== false) {
                throw new RuntimeException("Zero semantic capability safety invariant invalid for {$id}.");
            }
        }
    }
}
