<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;

final class ManagerPlanValidator
{
    /** @var callable(string):?array */
    private $roleResolver;

    public function __construct(?callable $roleResolver = null)
    {
        $this->roleResolver = $roleResolver ?? static fn (string $key): ?array => WorkforceRoleRegistry::find($key);
    }

    private function role(string $key): ?array
    {
        return ($this->roleResolver)($key);
    }

    public function validate(array $plan, string $managerDivision, ?string $managerRoleKey = null): array
    {
        $errors = [];
        $steps = array_values($plan['steps'] ?? []);
        if ($steps === []) {
            return ['valid' => false, 'steps' => [], 'errors' => [['code' => 'EMPTY_PLAN', 'message' => 'Manager plan has no steps.']]];
        }
        if (count($steps) > 50) {
            $errors[] = ['code' => 'PLAN_TOO_LARGE', 'message' => 'Manager plan exceeds 50 steps.'];
        }

        $ids = [];
        $normalized = [];
        foreach ($steps as $index => $step) {
            $id = trim((string) ($step['id'] ?? ''));
            if ($id === '' || isset($ids[$id])) {
                $errors[] = ['code' => $id === '' ? 'MISSING_STEP_ID' : 'DUPLICATE_STEP_ID', 'step' => $id ?: (string) $index];
                continue;
            }
            $ids[$id] = true;

            $roleKey = trim((string) ($step['role_key'] ?? ''));
            $role = $this->role($roleKey);
            if (! $role) {
                $errors[] = ['code' => 'UNKNOWN_ROLE', 'step' => $id, 'role_key' => $roleKey];
            } elseif ((int) ($role['tier'] ?? 0) !== 2) {
                $errors[] = ['code' => 'MANAGER_MAY_ASSIGN_SPECIALISTS_ONLY', 'step' => $id, 'role_key' => $roleKey];
            } elseif (($role['division'] ?? null) !== $managerDivision) {
                $errors[] = ['code' => 'CROSS_DIVISION_DIRECT_ASSIGNMENT', 'step' => $id, 'role_key' => $roleKey, 'role_division' => $role['division'] ?? null];
            } elseif ($managerRoleKey !== null && $managerRoleKey !== '' && ($role['escalation_path'] ?? null) !== $managerRoleKey) {
                $errors[] = ['code' => 'REPORTING_LINE_MISMATCH', 'step' => $id, 'role_key' => $roleKey, 'expected_manager' => $role['escalation_path'] ?? null, 'actual_manager' => $managerRoleKey];
            }

            $capability = trim((string) ($step['capability'] ?? ''));
            if ($role && ($capability === '' || ! in_array($capability, $role['capabilities'] ?? [], true))) {
                $errors[] = ['code' => 'ROLE_CAPABILITY_MISMATCH', 'step' => $id, 'role_key' => $roleKey, 'capability' => $capability];
            }

            $dependsOn = array_values(array_unique(array_filter(array_map('strval', $step['depends_on'] ?? []), fn (string $v) => $v !== '')));
            $handoffDivision = trim((string) ($step['handoff_to_division'] ?? ''));
            $handoffRoleKey = trim((string) ($step['handoff_to_role_key'] ?? ''));
            $handoffCapability = trim((string) ($step['handoff_to_capability'] ?? ''));
            $crossDivision = $handoffDivision !== '' && $handoffDivision !== $managerDivision;
            if ($handoffDivision !== '') {
                if (! $crossDivision) {
                    $errors[] = ['code' => 'REDUNDANT_HANDOFF', 'step' => $id, 'handoff_to_division' => $handoffDivision];
                }
                if ($handoffRoleKey === '') {
                    $errors[] = ['code' => 'HANDOFF_ROLE_REQUIRED', 'step' => $id];
                } else {
                    $receiverRole = $this->role($handoffRoleKey);
                    if (! $receiverRole) {
                        $errors[] = ['code' => 'UNKNOWN_HANDOFF_ROLE', 'step' => $id, 'role_key' => $handoffRoleKey];
                    } elseif (($receiverRole['division'] ?? null) !== $handoffDivision || (int) ($receiverRole['tier'] ?? 0) !== 2) {
                        $errors[] = ['code' => 'HANDOFF_ROLE_DIVISION_MISMATCH', 'step' => $id, 'role_key' => $handoffRoleKey, 'division' => $handoffDivision];
                    } elseif ($handoffCapability === '' || ! in_array($handoffCapability, $receiverRole['capabilities'] ?? [], true)) {
                        $errors[] = ['code' => 'HANDOFF_CAPABILITY_MISMATCH', 'step' => $id, 'role_key' => $handoffRoleKey, 'capability' => $handoffCapability];
                    }
                }
            }

            $normalized[] = array_merge($step, [
                'id' => $id,
                'title' => trim((string) ($step['title'] ?? $id)),
                'role_key' => $roleKey,
                'capability' => $capability,
                'depends_on' => $dependsOn,
                'priority' => max(0, min(100, (int) ($step['priority'] ?? 50))),
                'cross_division_handoff' => $crossDivision,
                'handoff_to_division' => $handoffDivision !== '' ? $handoffDivision : null,
                'handoff_to_role_key' => $handoffRoleKey !== '' ? $handoffRoleKey : null,
                'handoff_to_capability' => $handoffCapability !== '' ? $handoffCapability : null,
            ]);
        }

        foreach ($normalized as $step) {
            foreach ($step['depends_on'] as $dependency) {
                if (! isset($ids[$dependency])) {
                    $errors[] = ['code' => 'UNKNOWN_DEPENDENCY', 'step' => $step['id'], 'depends_on' => $dependency];
                }
                if ($dependency === $step['id']) {
                    $errors[] = ['code' => 'SELF_DEPENDENCY', 'step' => $step['id']];
                }
            }
        }
        if ($this->hasCycle($normalized)) {
            $errors[] = ['code' => 'DEPENDENCY_CYCLE', 'message' => 'Manager plan contains a dependency cycle.'];
        }

        return [
            'valid' => $errors === [],
            'plan_id' => (string) ($plan['plan_id'] ?? ''),
            'steps' => $normalized,
            'errors' => $errors,
        ];
    }

    private function hasCycle(array $steps): bool
    {
        $graph = [];
        foreach ($steps as $step) {
            $graph[$step['id']] = $step['depends_on'];
        }
        $visiting = [];
        $visited = [];
        $visit = function (string $node) use (&$visit, &$graph, &$visiting, &$visited): bool {
            if (isset($visited[$node])) return false;
            if (isset($visiting[$node])) return true;
            $visiting[$node] = true;
            foreach ($graph[$node] ?? [] as $dep) {
                if (isset($graph[$dep]) && $visit($dep)) return true;
            }
            unset($visiting[$node]);
            $visited[$node] = true;
            return false;
        };
        foreach (array_keys($graph) as $node) {
            if ($visit($node)) return true;
        }
        return false;
    }
}
