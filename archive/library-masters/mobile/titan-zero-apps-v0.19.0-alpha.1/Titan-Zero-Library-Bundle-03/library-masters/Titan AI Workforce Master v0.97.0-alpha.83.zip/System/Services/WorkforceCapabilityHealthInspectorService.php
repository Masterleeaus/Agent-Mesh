<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMember;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceCanonicalCapabilityMatrix;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceEcosystemCapabilityRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceManifestRegistry;
use App\Extensions\TitanAIWorkforce\System\Support\WorkforceRoleRegistry;

/**
 * Read-only company-scoped capability/provider inspector.
 *
 * Bound/expected, live availability, company/member policy and fallback eligibility are
 * diagnostics only. None grants or inherits execution authority.
 */
final class WorkforceCapabilityHealthInspectorService
{
    private const SURFACES = ['capabilities','tools','commands','signals','data_sources','workflows'];

    public function __construct(
        private readonly WorkforceEcosystemCapabilityRegistry $ecosystem,
        private readonly WorkforceCanonicalCapabilityMatrix $matrix,
        private readonly WorkforceCapabilityAvailabilityService $availability,
        private readonly WorkforceManifestRegistry $manifests,
    ) {}

    /** @return array<string,mixed> */
    public function snapshot(int $companyId): array
    {
        $catalogueProviders = collect($this->ecosystem->providers());
        $installed = $this->ecosystem->installedContributions();
        $manifestHealth = $this->manifests->health();
        $matrixRoles = collect($this->matrix->roles());
        $roleCatalog = collect(WorkforceRoleRegistry::all())->keyBy(fn (array $role): string => (string) ($role['role_definition_id'] ?? $role['role_id'] ?? $role['key'] ?? ''));
        $members = WorkforceMember::query()->forCompany($companyId)->orderBy('name')->get();

        $memberRows = $members->map(function (WorkforceMember $member) use ($matrixRoles, $roleCatalog): array {
            $roleId = (string) $member->role_definition_id;
            $matrixRole = $matrixRoles->first(fn (array $row): bool => (string) ($row['role_definition_id'] ?? '') === $roleId) ?? [];
            $live = $this->availability->forMember($member);
            $expected = collect((array) ($matrixRole['provider_bindings'] ?? []))->pluck('provider')->filter()->unique()->sort()->values();
            $available = collect((array) data_get($live, 'effective_access.providers', []))->filter()->unique()->sort()->values();
            $bindings = collect((array) ($live['provider_bindings'] ?? []));
            $degradedCapabilities = $this->surfaceStateRows($bindings, 'capabilities', ['degraded','unavailable','missing_provider','blocked']);
            $policyDisabled = $this->surfaceStateRows($bindings, 'capabilities', ['policy_disabled']);
            $fallback = $this->fallbackEligibility($bindings, 'capabilities');
            $role = $roleCatalog->get($roleId, []);

            return [
                'id' => (int) $member->id,
                'name' => (string) $member->name,
                'role_definition_id' => $roleId,
                'role_name' => (string) ($role['name'] ?? $role['role_name'] ?? $matrixRole['role_name'] ?? $roleId),
                'lifecycle' => is_object($member->status) && property_exists($member->status, 'value') ? $member->status->value : (string) $member->status,
                'state' => (string) ($live['state'] ?? 'unavailable'),
                'expected_providers' => $expected->all(),
                'available_providers' => $available->all(),
                'missing_or_degraded_providers' => $bindings->filter(fn (array $b): bool => ! in_array((string) ($b['state'] ?? ''), ['available'], true))->map(fn (array $b): array => ['provider'=>(string)($b['provider'] ?? ''),'state'=>(string)($b['state'] ?? 'unavailable')])->values()->all(),
                'degraded_capabilities' => $degradedCapabilities,
                'policy_disabled_capabilities' => $policyDisabled,
                'fallback_eligibility' => $fallback,
                'fallback_authority_granted' => false,
                'authority_inherited' => false,
            ];
        })->values();

        $membersByRole = $memberRows->groupBy('role_definition_id');
        $roleRows = $matrixRoles->map(function (array $role) use ($roleCatalog, $membersByRole): array {
            $roleId = (string) ($role['role_definition_id'] ?? '');
            $live = $this->availability->forRole($roleId);
            $definition = $roleCatalog->get($roleId, []);
            return [
                'role_definition_id' => $roleId,
                'role_name' => (string) ($definition['name'] ?? $definition['role_name'] ?? $role['role_name'] ?? $roleId),
                'division' => (string) ($role['division_key'] ?? ''),
                'team' => (string) ($role['team_key'] ?? ''),
                'state' => (string) ($live['state'] ?? 'unavailable'),
                'expected_providers' => collect((array) ($role['provider_bindings'] ?? []))->pluck('provider')->filter()->unique()->sort()->values()->all(),
                'available_providers' => (array) data_get($live, 'effective_access.providers', []),
                'employee_count' => $membersByRole->get($roleId, collect())->count(),
                'authority_inherited' => false,
            ];
        })->sortBy('role_name')->values();

        $rolesByProvider = [];
        foreach ($matrixRoles as $role) {
            foreach ((array) ($role['provider_bindings'] ?? []) as $binding) {
                $key = $this->ecosystem->canonicalProviderKey((string) ($binding['provider'] ?? ''));
                if ($key === '') continue;
                $rolesByProvider[$key][(string) ($role['role_definition_id'] ?? '')] = (string) ($role['role_name'] ?? $role['role_definition_id'] ?? '');
            }
        }

        $providerRows = $catalogueProviders->map(function (array $provider) use ($installed, $manifestHealth, $rolesByProvider, $membersByRole): array {
            $key = $this->ecosystem->canonicalProviderKey((string) data_get($provider, 'extension.key', ''));
            $health = (array) ($manifestHealth[$key] ?? []);
            $quarantined = strtoupper((string) ($health['status'] ?? '')) === 'QUARANTINED';
            $isInstalled = isset($installed[$key]);
            $dependentRoles = array_keys((array) ($rolesByProvider[$key] ?? []));
            $affectedEmployees = collect($dependentRoles)->flatMap(fn (string $roleId) => $membersByRole->get($roleId, collect()))->unique('id')->values();
            $roleStates = collect($dependentRoles)->map(fn (string $roleId): string => (string) ($this->availability->forRole($roleId)['provider_bindings'][array_search($key, array_column((array)($this->availability->forRole($roleId)['provider_bindings'] ?? []), 'provider'), true)]['state'] ?? 'unavailable'));
            $degraded = $isInstalled && ! $quarantined && $roleStates->contains(fn (string $state): bool => $state !== 'available');
            $status = $quarantined ? 'quarantined' : (! $isInstalled ? 'missing' : ($degraded ? 'degraded' : 'active'));
            return [
                'key' => $key,
                'name' => (string) data_get($provider, 'extension.name', $key),
                'version' => (string) data_get($provider, 'extension.version', ''),
                'provider_class' => (string) data_get($provider, 'extension.provider_class', ''),
                'status' => $status,
                'installed' => $isInstalled,
                'active' => $status === 'active',
                'degraded' => $status === 'degraded',
                'missing' => $status === 'missing',
                'quarantined' => $quarantined,
                'roles' => collect((array) ($rolesByProvider[$key] ?? []))->map(fn (string $name, string $id): array => ['id'=>$id,'name'=>$name])->values()->all(),
                'role_count' => count((array) ($rolesByProvider[$key] ?? [])),
                'employees_affected' => $affectedEmployees->map(fn (array $m): array => ['id'=>$m['id'],'name'=>$m['name'],'state'=>$m['state']])->all(),
                'employee_count' => $affectedEmployees->count(),
                'capability_count' => count((array) ($provider['capabilities'] ?? [])),
                'surface_counts' => collect(self::SURFACES)->mapWithKeys(fn (string $section): array => [$section => count((array) ($provider[$section] ?? []))])->all(),
                'manifest_health' => $health,
                'authority_inherited' => false,
            ];
        })->sortBy('name')->values();

        $surfaces = [];
        foreach (self::SURFACES as $section) $surfaces[$section] = $this->surfaceCatalogue($catalogueProviders, $section, $installed, $manifestHealth);

        return [
            'company_id' => $companyId,
            'authority_inherited' => false,
            'fallback_authority_granted' => false,
            'summary' => [
                'providers' => $providerRows->count(),
                'active_providers' => $providerRows->where('active', true)->count(),
                'degraded_providers' => $providerRows->where('degraded', true)->count(),
                'missing_providers' => $providerRows->where('missing', true)->count(),
                'quarantined_providers' => $providerRows->where('quarantined', true)->count(),
                'roles' => $roleRows->count(),
                'employees' => $memberRows->count(),
                'degraded_employees' => $memberRows->filter(fn (array $row): bool => $row['state'] !== 'available')->count(),
            ],
            'providers' => $providerRows->all(),
            'roles' => $roleRows->all(),
            'employees' => $memberRows->all(),
            'surfaces' => $surfaces,
        ];
    }

    /** @return list<array<string,mixed>> */
    private function surfaceCatalogue($providers, string $section, array $installed, array $manifestHealth): array
    {
        $rows = [];
        foreach ($providers as $provider) {
            $providerKey = $this->ecosystem->canonicalProviderKey((string) data_get($provider, 'extension.key', ''));
            $health = (array) ($manifestHealth[$providerKey] ?? []);
            $quarantined = strtoupper((string) ($health['status'] ?? '')) === 'QUARANTINED';
            $providerStatus = $quarantined ? 'quarantined' : (isset($installed[$providerKey]) ? 'active' : 'missing');
            foreach ((array) ($provider[$section] ?? []) as $surface) {
                if (! is_array($surface)) continue;
                $id = trim((string) ($surface['id'] ?? $surface['capability'] ?? $surface['event_type'] ?? ''));
                if ($id === '') continue;
                $rows[] = [
                    'id' => $id,
                    'provider' => $providerKey,
                    'version' => (string) data_get($provider, 'extension.version', ''),
                    'provider_status' => $providerStatus,
                    'authority' => (string) ($surface['authority'] ?? ''),
                    'mode' => (string) ($surface['mode'] ?? $surface['access'] ?? $surface['execution'] ?? ''),
                    'writes_state' => (bool) ($surface['writes_state'] ?? false),
                    'authority_inherited' => false,
                ];
            }
        }
        usort($rows, static fn (array $a, array $b): int => [$a['id'],$a['provider']] <=> [$b['id'],$b['provider']]);
        return $rows;
    }

    /** @return list<array{provider:string,id:string,state:string}> */
    private function surfaceStateRows($bindings, string $section, array $states): array
    {
        $rows = [];
        foreach ($bindings as $binding) {
            foreach ((array) data_get($binding, 'surfaces.'.$section, []) as $surface) {
                if (! is_array($surface)) continue;
                $state = (string) ($surface['state'] ?? 'unavailable');
                if (! in_array($state, $states, true)) continue;
                $rows[] = ['provider'=>(string)($surface['provider'] ?? $binding['provider'] ?? ''),'id'=>(string)($surface['id'] ?? ''),'state'=>$state];
            }
        }
        return array_values($rows);
    }

    /** @return list<array<string,mixed>> */
    private function fallbackEligibility($bindings, string $section): array
    {
        $byId = [];
        foreach ($bindings as $binding) {
            foreach ((array) data_get($binding, 'surfaces.'.$section, []) as $surface) {
                if (! is_array($surface)) continue;
                $id = (string) ($surface['id'] ?? '');
                if ($id === '') continue;
                $byId[$id][] = ['provider'=>(string)($surface['provider'] ?? $binding['provider'] ?? ''),'state'=>(string)($surface['state'] ?? 'unavailable')];
            }
        }
        $out = [];
        foreach ($byId as $id => $providers) {
            if (count($providers) < 2) continue;
            $available = array_values(array_filter($providers, fn (array $p): bool => $p['state'] === 'available'));
            $unavailable = array_values(array_filter($providers, fn (array $p): bool => $p['state'] !== 'available'));
            if ($available === [] || $unavailable === []) continue;
            $out[] = ['capability'=>$id,'eligible'=>true,'available_providers'=>$available,'unavailable_providers'=>$unavailable,'authority_granted'=>false];
        }
        return $out;
    }
}
