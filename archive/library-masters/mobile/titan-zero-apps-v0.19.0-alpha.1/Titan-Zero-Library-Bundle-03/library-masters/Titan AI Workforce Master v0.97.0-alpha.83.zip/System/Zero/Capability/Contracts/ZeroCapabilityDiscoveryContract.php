<?php

declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Zero\Capability\Contracts;

interface ZeroCapabilityDiscoveryContract
{
    /**
     * Rank discoverable capabilities for a natural-language business request.
     * Discovery is advisory only and never grants execution authority.
     *
     * @param array<string,mixed> $context
     * @return array<string,mixed>
     */
    public function discover(string $query, array $context = []): array;
}
