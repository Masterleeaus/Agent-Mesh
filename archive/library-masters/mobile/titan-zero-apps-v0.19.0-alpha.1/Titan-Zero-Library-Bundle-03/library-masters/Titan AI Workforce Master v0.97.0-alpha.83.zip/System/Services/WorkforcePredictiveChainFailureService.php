<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIWorkforce\System\Services;

use App\Extensions\TitanAIWorkforce\System\Models\WorkforceChainFailurePrediction;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChain;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceDecisionChallenge;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceFinalAuthorityGate;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceMemberRating;
use App\Extensions\TitanAIWorkforce\System\Models\WorkforceProcessingCheckpoint;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class WorkforcePredictiveChainFailureService
{
    private const WISDOM='App\\Extensions\\TitanWisdomEngine\\System\\Services\\WisdomPredictionService';

    public function __construct(private readonly Container $app) {}

    public function predict(WorkforceDecisionChain $chain): WorkforceChainFailurePrediction
    {
        $signals=$this->signals($chain);
        $wisdom=$this->wisdom($chain);
        $probability=$this->probability($signals,$wisdom);

        $likelyDisagreement=$signals['historical_disagreement_rate']>=20 || $probability>=70;
        $likelyAuthorityDenial=$signals['historical_authority_denial_rate']>=15 || $signals['risk_weight']>=75;
        $likelyStall=$signals['historical_stall_rate']>=15 || $signals['eligible_reviewer_pool']<3;
        $weakPool=$signals['eligible_reviewer_pool']<3 || $signals['reviewer_quality_average']<65;
        $knowledgeGap=$signals['knowledge_confidence']<70 || $signals['knowledge_sections']===0;

        $band=match(true){$probability>=80=>'CRITICAL',$probability>=60=>'HIGH',$probability>=35=>'ELEVATED',default=>'NORMAL'};
        $requirements=[
            'prediction_risk_band'=>$band,
            'minimum_decision_quality'=>match($band){'CRITICAL'=>85,'HIGH'=>80,'ELEVATED'=>70,default=>0},
            'prefer_provider_diversity'=>$probability>=35,
            'require_explicit_evidence_refs'=>$probability>=35 || $knowledgeGap,
            'require_knowledge_authority_receipt'=>true,
            'require_assumptions_declaration'=>$probability>=35,
            'require_unresolved_questions_declaration'=>$probability>=35,
            'force_assurance'=>$probability>=60 || $likelyAuthorityDenial,
            'force_model_council'=>$probability>=80 && ($likelyDisagreement || $knowledgeGap),
            'shorter_stage_timeout_minutes'=>$likelyStall?15:null,
            'mandatory_three_checks'=>true,
        ];

        return WorkforceChainFailurePrediction::query()->updateOrCreate(
            ['company_id'=>(int)$chain->company_id,'processing_id'=>$chain->processing_id],
            [
                'prediction_uuid'=>(string)(WorkforceChainFailurePrediction::query()->forCompany((int)$chain->company_id)
                    ->where('processing_id',$chain->processing_id)->value('prediction_uuid') ?: Str::uuid()),
                'decision_chain_id'=>$chain->getKey(),'failure_probability'=>$probability,'risk_band'=>$band,
                'likely_disagreement'=>$likelyDisagreement,'likely_authority_denial'=>$likelyAuthorityDenial,
                'likely_stall'=>$likelyStall,'weak_reviewer_pool'=>$weakPool,'knowledge_gap_risk'=>$knowledgeGap,
                'signals'=>$signals,'preventive_requirements'=>$requirements,'wisdom_prediction'=>$wisdom,
                'mandatory_three_checks'=>true,'predicted_at'=>now(),
            ]
        );
    }

    /** @return array<string,mixed> */
    public function requirements(WorkforceDecisionChain $chain): array
    {
        return (array)$this->predict($chain)->preventive_requirements;
    }

    /** @return array<string,mixed> */
    private function signals(WorkforceDecisionChain $chain): array
    {
        $company=(int)$chain->company_id;
        $capability=(string)($chain->task?->capability ?? '');
        $recentChains=WorkforceDecisionChain::query()->forCompany($company)
            ->where('id','<>',$chain->getKey())
            ->when($capability!=='',fn($q)=>$q->whereHas('task',fn($t)=>$t->where('capability',$capability)))
            ->where('created_at','>=',now()->subDays(90))->latest()->limit(200)->get();
        $ids=$recentChains->pluck('processing_id');

        $challenges=$ids->isEmpty()?0:WorkforceDecisionChallenge::query()->forCompany($company)->whereIn('processing_id',$ids)->count();
        $gates=$ids->isEmpty()?collect():WorkforceFinalAuthorityGate::query()->forCompany($company)->whereIn('processing_id',$ids)->get();
        $denied=$gates->where('final_allowed',false)->count();

        $stalled=$recentChains->filter(fn($c)=>$c->updated_at && $c->created_at && $c->updated_at->diffInHours($c->created_at)>=4
            && !in_array($c->state->value,['CLOSED','REJECTED','ORGANISATIONALLY_APPROVED'],true))->count();

        $ratings=WorkforceMemberRating::query()->forCompany($company)->get();
        $quality=$ratings->map(fn($r)=>(float)data_get($r->dimensions ?? [],'reviewer.decision_quality',$r->score ?? 50));
        $eligiblePool=$ratings->filter(fn($r)=>(float)data_get($r->dimensions ?? [],'reviewer.decision_quality',$r->score ?? 50)>=65)->count();

        $receipt=(array)($chain->knowledge_receipt ?? []);
        $sections=(array)($receipt['sections'] ?? []);
        $confidence=(float)($receipt['confidence'] ?? $receipt['authority_confidence'] ?? 100);
        if($sections!==[]){
            $vals=[];
            foreach($sections as $s) if(is_array($s) && isset($s['confidence'])) $vals[]=(float)$s['confidence']*100;
            if($vals!==[]) $confidence=min($confidence,array_sum($vals)/count($vals));
        }

        $risk=['MINIMAL'=>10,'LOW'=>20,'ORDINARY'=>25,'MEDIUM'=>45,'HIGH'=>70,'REGULATED'=>75,'CRITICAL'=>90,'SEVERE'=>95,'EXTREME'=>100];

        return [
            'historical_chain_sample'=>$recentChains->count(),
            'historical_disagreement_rate'=>$recentChains->count()?round(100*$challenges/$recentChains->count(),2):0.0,
            'historical_authority_denial_rate'=>$gates->count()?round(100*$denied/$gates->count(),2):0.0,
            'historical_stall_rate'=>$recentChains->count()?round(100*$stalled/$recentChains->count(),2):0.0,
            'reviewer_quality_average'=>$quality->isEmpty()?50.0:round((float)$quality->avg(),2),
            'eligible_reviewer_pool'=>$eligiblePool,
            'knowledge_confidence'=>max(0,min(100,$confidence)),
            'knowledge_sections'=>count($sections),
            'risk_weight'=>$risk[strtoupper((string)$chain->risk_class)] ?? 25,
            'business_value'=>(float)data_get($chain->task?->payload ?? [],'amount',0),
        ];
    }

    /** @return array<string,mixed> */
    private function wisdom(WorkforceDecisionChain $chain): array
    {
        if(!class_exists(self::WISDOM)) return ['status'=>'UNAVAILABLE','confidence'=>0.0,'items'=>[]];
        try{
            $service=$this->app->make(self::WISDOM);
            $result=$service->predict([
                'company_id'=>(int)$chain->company_id,
                'prediction_type'=>'chain_failure',
                'horizon'=>'next_decision_chain',
                'capability'=>$chain->task?->capability,
                'processing_id'=>$chain->processing_id,
            ]);
            return (array)($result['predictions'] ?? $result);
        }catch(\Throwable $e){
            return ['status'=>'UNAVAILABLE','confidence'=>0.0,'items'=>[],'reason'=>'WISDOM_PREDICTION_FAILED'];
        }
    }

    private function probability(array $s,array $wisdom): int
    {
        $score=0.0;
        $score+=min(25,(float)$s['historical_disagreement_rate']*.50);
        $score+=min(20,(float)$s['historical_authority_denial_rate']*.60);
        $score+=min(15,(float)$s['historical_stall_rate']*.50);
        $score+=max(0,70-(float)$s['reviewer_quality_average'])*.50;
        if((int)$s['eligible_reviewer_pool']<3)$score+=15;
        $score+=max(0,80-(float)$s['knowledge_confidence'])*.40;
        if((int)$s['knowledge_sections']===0)$score+=10;
        $score+=((float)$s['risk_weight'])*.15;
        if((float)$s['business_value']>=100000)$score+=10;
        elseif((float)$s['business_value']>=25000)$score+=6;

        foreach((array)($wisdom['items'] ?? []) as $item){
            if(!is_array($item)) continue;
            $p=$item['probability'] ?? null;
            if(is_numeric($p)) $score=max($score,min(100,(float)$p*100));
        }
        return (int)round(max(0,min(100,$score)));
    }
}
