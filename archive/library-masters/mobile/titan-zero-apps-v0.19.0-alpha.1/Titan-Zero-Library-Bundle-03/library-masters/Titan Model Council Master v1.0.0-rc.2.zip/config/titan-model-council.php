<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'queue' => 'titan-model-council',
    'tenant_key' => 'company_id',

    'runtime' => [
        'max_models' => null,
        'synthesis_model' => '',
    ],

    'signal' => [
        'required' => true,
        'contract_candidates' => [
            'App\\Extensions\\TitanSignal\\System\\Contracts\\SignalEmitterContract',
            'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterContract',
        ],
        'forbidden_payload_fields' => ['password', 'token', 'secret', 'authorization', 'signature'],
    ],

    'ai_core' => [
        // AI Core is optional. Set execution_contract only when a verified executable Core runtime contract is installed.
        'execution_contract' => null,
        'prefer_ai_core' => true,
        'allow_legacy_provider_fallback' => true,
    ],

    'risk_engine' => [
        'enabled' => true,
        'fail_closed_on_error' => true,
    ],

    'selective_activation' => [
        'enabled' => true,
        'manual_override_wins' => true,
        // A Risk Engine decision may increase Council depth but manual input may never reduce it.
        'risk_monitoring_minimum' => 'lightweight_council',
        'governed_deliberation_enabled' => true,
        'greeting_patterns' => [
            '/^\s*(hi|hello|hey|good morning|good afternoon|good evening)\b/i',
        ],
        // These are only deterministic safety signals. Risk Engine will become the authoritative classifier.
        'high_consequence_actions' => [
            'delete', 'refund', 'pay', 'payment', 'send invoice', 'send email', 'send sms',
            'schedule', 'booking', 'cancel booking', 'terminate', 'approve', 'reject', 'publish',
        ],
    ],


    'governed_deliberation' => [
        'enabled' => true,
        // Four independent roles are mandatory; at least three distinct models are required by default.
        'minimum_distinct_models' => 3,
        'roles' => ['proposer', 'critic', 'verifier', 'arbiter'],
        'participant_failure_mode' => 'block_and_escalate',
    ],

    'shield' => [
        'enabled' => true,
        // Shield inspection lifecycle is used when available; configure semantic validation when Shield publishes that capability.
        'validation_contract' => null,
        'local_structural_fallback' => true,
    ],


    'assurance' => [
        'enabled' => true,
        'contract' => 'App\\Extensions\\ModelCouncil\\System\\Contracts\\EvidenceAssuranceEngine',
        'policy_version' => 'titan-assurance-v2.2',
        'fail_closed_when_required' => true,
    ],

    'receipts' => [
        'enabled' => true,
        'hash_algorithm' => 'sha256',
        'store_participant_output_hashes_only' => true,
    ],

    'contradiction' => [
        'enabled' => true,
        'confidence_ceiling' => 50,
    ],

    'provider_circuit_breaker' => [
        'enabled' => true,
        'failure_threshold' => 3,
        'cooldown_seconds' => 60,
    ],

    'adaptive_quorum' => [
        'enabled' => true,
        'minimum_successful_participants' => 2,
        'minimum_agreement_percent' => 90,
        'provider_timeout_seconds' => 90,
        // Cancellation of in-flight HTTP requests is not enabled until AI Core owns provider dispatch.
        'cancel_pending_requests' => false,
    ],

    'billing' => [
        'mode' => 'reserve_execute_settle',
        'reservation_required' => true,
        // Conservative Council-local ceiling. Titan AI Core billing will later supply provider-specific estimates/hard holds.
        'max_reserved_credits_per_participant' => 5000,
    ],
];
