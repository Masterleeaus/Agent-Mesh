<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

use App\Extensions\TitanModelCouncil\System\Shield\ShieldValidationResult;

final readonly class GovernedDeliberationResult
{
    /**
     * @param array<string,ParticipantResult> $participants
     * @param array<string,mixed> $metadata
     */
    public function __construct(
        public string $status,
        public ?string $finalAnswer,
        public array $participants,
        public int $actualParticipantCount,
        public bool $requiresEscalation,
        public ?int $confidencePercent = null,
        public ?ShieldValidationResult $preArbiterShield = null,
        public ?ShieldValidationResult $finalShield = null,
        public array $metadata = [],
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        $participants = [];
        foreach ($this->participants as $role => $result) {
            $participants[$role] = $result->toArray();
        }

        return [
            'status' => $this->status,
            'strategy' => 'governed_deliberation',
            'final_answer' => $this->finalAnswer,
            'participants' => $participants,
            'actual_participant_count' => $this->actualParticipantCount,
            'requires_escalation' => $this->requiresEscalation,
            'confidence_percent' => $this->confidencePercent,
            'pre_arbiter_shield' => $this->preArbiterShield?->toArray(),
            'final_shield' => $this->finalShield?->toArray(),
            'metadata' => $this->metadata,
        ];
    }
}
