<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Health;

use App\Extensions\TitanModelCouncil\System\AICore\AICoreRuntimeProbe;
use App\Extensions\TitanModelCouncil\System\Assurance\CouncilAssuranceBridge;
use App\Extensions\TitanModelCouncil\System\Contracts\ExtensionHealth;
use App\Extensions\TitanModelCouncil\System\Risk\CouncilRiskGatewayContract;
use App\Extensions\TitanModelCouncil\System\Risk\NullCouncilRiskGateway;
use App\Extensions\TitanModelCouncil\System\Shield\CouncilShieldGateContract;
use App\Extensions\TitanModelCouncil\System\Signal\CouncilSignalEmitter;
use Illuminate\Support\Facades\Schema;

final class TitanModelCouncilHealthCheck implements ExtensionHealth
{
    public function __construct(
        private readonly CouncilSignalEmitter $signal,
        private readonly AICoreRuntimeProbe $aiCore,
        private readonly CouncilRiskGatewayContract $risk,
        private readonly CouncilShieldGateContract $shield,
        private readonly CouncilAssuranceBridge $assurance,
    ) {
    }

    public function snapshot(): array
    {
        $checks = [
            'database.decisions' => Schema::hasTable('titan_model_council_decisions') ? 'HEALTHY' : 'UNAVAILABLE',
            'database.participants' => Schema::hasTable('titan_model_council_participants') ? 'HEALTHY' : 'UNAVAILABLE',
            'database.billing' => Schema::hasTable('titan_model_council_billing_reservations') ? 'HEALTHY' : 'UNAVAILABLE',
            'database.receipts' => Schema::hasTable('titan_model_council_receipts') ? 'HEALTHY' : 'UNAVAILABLE',
            'database.settings' => Schema::hasTable('titan_model_council_settings') ? 'HEALTHY' : 'UNAVAILABLE',
            'signal' => $this->signal->available() ? 'HEALTHY' : 'UNAVAILABLE',
            'risk' => ! (bool) config('titan-model-council.risk_engine.enabled', true) ? 'DISABLED' : ($this->risk instanceof NullCouncilRiskGateway ? 'DEGRADED' : 'HEALTHY'),
            'ai_core' => (($this->aiCore->status()['provider_execution_supported'] ?? false) === true) ? 'HEALTHY' : 'DEGRADED',
            'shield' => ! (bool) config('titan-model-council.shield.enabled', true) ? 'DISABLED' : ((($this->shield->status()['available'] ?? false) === true) ? 'HEALTHY' : 'DEGRADED'),
            'assurance' => ! (bool) config('titan-model-council.assurance.enabled', true) ? 'DISABLED' : ($this->assurance->available() ? 'HEALTHY' : 'DEGRADED'),
        ];

        $extensionEnabled = (bool) config('titan-model-council.enabled', true);
        $aiCoreSupported = (($this->aiCore->status()['provider_execution_supported'] ?? false) === true);
        $allowLegacyFallback = (bool) config('titan-model-council.ai_core.allow_legacy_provider_fallback', true);

        $requiredUnavailable = in_array('UNAVAILABLE', [
            $checks['database.decisions'],
            $checks['database.participants'],
            $checks['database.billing'],
            $checks['database.receipts'],
            $checks['database.settings'],
            $checks['signal'],
        ], true);
        $status = $requiredUnavailable ? 'UNAVAILABLE' : (in_array('DEGRADED', $checks, true) ? 'DEGRADED' : 'HEALTHY');
        $workforceState = ! $extensionEnabled
            ? 'policy_disabled'
            : ($requiredUnavailable
                ? 'unavailable'
                : (! $aiCoreSupported && ! $allowLegacyFallback
                    ? 'missing_provider'
                    : ($status === 'DEGRADED' ? 'degraded' : 'available')));

        return [
            'status' => $status,
            'workforce_state' => $workforceState,
            'checks' => $checks,
            'observed_at' => now()->toIso8601String(),
        ];
    }
}
