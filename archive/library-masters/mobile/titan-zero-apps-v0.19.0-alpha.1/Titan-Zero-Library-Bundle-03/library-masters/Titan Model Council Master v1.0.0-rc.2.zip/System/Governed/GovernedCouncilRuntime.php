<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

use App\Extensions\TitanModelCouncil\System\Billing\CouncilBillingReservationService;
use App\Extensions\TitanModelCouncil\System\Assurance\CouncilAssuranceBridge;
use App\Extensions\TitanModelCouncil\System\Receipts\CouncilDecisionReceiptService;
use App\Extensions\TitanModelCouncil\System\Persistence\CouncilDecisionRepository;
use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\Risk\CouncilRiskGatewayContract;
use App\Extensions\TitanModelCouncil\System\Shield\CouncilShieldGateContract;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use InvalidArgumentException;
use Throwable;

final class GovernedCouncilRuntime
{
    public function __construct(
        private readonly GovernedProviderRuntimeContract $providerRuntime,
        private readonly GovernedDeliberationOrchestrator $orchestrator,
        private readonly CouncilBillingReservationService $billing,
        private readonly CouncilDecisionRepository $decisions,
        private readonly CouncilRiskGatewayContract $risk,
        private readonly SelectiveActivationPolicy $activationPolicy,
        private readonly CouncilShieldGateContract $shield,
        private readonly CouncilAssuranceBridge $assurance,
        private readonly CouncilDecisionReceiptService $receipts,
    ) {
    }

    /** @param array<string,string> $roleModels @return array<string,mixed> */
    public function execute(CouncilRequest $request, array $roleModels): array
    {
        $models = $this->validatedModelAssignments($roleModels);
        $preflight = $this->providerRuntime->preflight($request->userId, array_values($models));
        if (($preflight['allowed'] ?? false) !== true) {
            return [
                'status' => 'rejected',
                'error' => 'Governed Council model preflight failed.',
                'reasons' => array_values((array) ($preflight['reasons'] ?? [])),
            ];
        }

        $preRisk = $this->risk->assessBefore($request);
        $activation = $this->activationPolicy->decide($request, $preRisk);
        if ($activation->strategy !== 'governed_deliberation') {
            return [
                'status' => 'rejected',
                'error' => 'Request did not resolve to governed_deliberation.',
                'activation' => $activation->toArray(),
                'risk' => $preRisk->toArray(),
            ];
        }

        $reservation = null;
        $decisionId = null;
        try {
            $reservation = $this->billing->reserveGoverned(
                $request->companyId,
                $request->userId,
                $models,
                $request->traceId,
            );
            $decisionId = $this->decisions->recordActivation($request, $activation, $reservation->reservationId, $preRisk);

            $deliberation = $this->orchestrator->deliberate($request, $models);
            $result = $deliberation->toArray();
            $result['activation'] = $activation->toArray();
            $result['preflight_risk'] = $preRisk->toArray();
            $result['shield'] = $this->shield->status();
            // Council deliberation is advisory evidence, never mutation authority. Risk may reduce this further.
            $result['execution_authority'] = (string) ($activation->triggerMetadata['execution_authority'] ?? 'advisory_only');
            if (($activation->triggerMetadata['governance_escalation_required'] ?? false) === true) {
                $result['requires_escalation'] = true;
            }

            $actualComponents = [];
            foreach ($deliberation->participants as $role => $participant) {
                if (! $participant->success || trim((string) $participant->responseText) === '') {
                    continue;
                }
                $credits = $this->providerRuntime->charge(
                    $request->userId,
                    $participant->modelSlug,
                    (string) $participant->responseText,
                );
                $actualComponents['role:' . $role . ':' . $participant->modelSlug] = max(0, $credits);
                $result['participants'][$role]['credits'] = max(0, $credits);
            }

            // Settle immediately after actual provider usage is known. If later audit/risk persistence fails,
            // the financial ledger remains accurate and the reservation cannot be incorrectly released.
            $settlement = $this->billing->settle(
                $reservation->reservationId,
                $request->companyId,
                $request->userId,
                $actualComponents,
            );

            $postRisk = $this->risk->assessAfter($request, $result);
            $result['postflight_risk'] = $postRisk->toArray();
            if ($postRisk->requiresEscalation) {
                $result['requires_escalation'] = true;
            }

            $assuranceRequired = (($activation->triggerMetadata['assurance_required'] ?? false) === true)
                || strtoupper($preRisk->decision) === 'REQUIRE_ASSURANCE'
                || strtoupper($postRisk->decision) === 'REQUIRE_ASSURANCE';
            $result['assurance'] = $this->assurance->assess($request, $result, $assuranceRequired);
            if (($result['assurance']['requires_escalation'] ?? false) === true) {
                $result['requires_escalation'] = true;
            }

            $this->decisions->recordGovernedParticipants($request, $decisionId, $result['participants'] ?? []);
            $result['receipt'] = $this->receipts->record(
                $request,
                $decisionId,
                $result,
                $settlement->toArray(),
            );
            $this->decisions->complete($request->companyId, $decisionId, $result, $postRisk);

            return [
                'decision_id' => $decisionId,
                'billing' => $settlement->toArray(),
                'receipt' => $result['receipt'],
                'result' => $result,
            ];
        } catch (Throwable $e) {
            if ($reservation !== null) {
                try {
                    $this->billing->release(
                        $reservation->reservationId,
                        $request->companyId,
                        $request->userId,
                        'governed_runtime_exception',
                    );
                } catch (Throwable) {
                    // Preserve the original exception as primary evidence.
                }
            }
            if ($decisionId !== null) {
                try {
                    $this->decisions->complete($request->companyId, $decisionId, [
                        'status' => 'failed',
                        'requires_escalation' => true,
                        'failure_reason' => 'governed_runtime_exception',
                        'exception' => $e::class,
                    ]);
                } catch (Throwable) {
                    // Persistence failure is secondary to the runtime failure.
                }
            }

            return [
                'decision_id' => $decisionId,
                'status' => 'failed',
                'error' => 'Governed Council execution failed.',
                'exception' => $e::class,
            ];
        }
    }

    /** @param array<string,string> $roleModels @return array<string,string> */
    private function validatedModelAssignments(array $roleModels): array
    {
        $out = [];
        foreach (CouncilRole::cases() as $role) {
            $slug = trim((string) ($roleModels[$role->value] ?? ''));
            if ($slug === '') {
                throw new InvalidArgumentException('Missing model assignment for role: ' . $role->value);
            }
            $out[$role->value] = $slug;
        }
        $minimumDistinct = max(1, min(4, (int) config('titan-model-council.governed_deliberation.minimum_distinct_models', 3)));
        if (count(array_unique(array_values($out))) < $minimumDistinct) {
            throw new InvalidArgumentException('Governed deliberation requires at least ' . $minimumDistinct . ' distinct entitled models.');
        }
        return $out;
    }
}
