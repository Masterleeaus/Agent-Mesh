<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\ValueObjects;

final readonly class CouncilRiskAssessment
{
    /** @param list<string> $reasonCodes @param array<string,mixed> $metadata */
    public function __construct(
        public bool $available,
        public ?float $score = null,
        public string $level = 'UNKNOWN',
        public string $decision = 'UNAVAILABLE',
        public bool $canProceedWithoutEscalation = true,
        public bool $requiresEscalation = false,
        public ?string $policyVersion = null,
        public array $reasonCodes = [],
        public array $metadata = [],
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'available' => $this->available,
            'score' => $this->score,
            'level' => $this->level,
            'decision' => $this->decision,
            'can_proceed_without_escalation' => $this->canProceedWithoutEscalation,
            'requires_escalation' => $this->requiresEscalation,
            'policy_version' => $this->policyVersion,
            'reason_codes' => $this->reasonCodes,
            'metadata' => $this->metadata,
        ];
    }
}
