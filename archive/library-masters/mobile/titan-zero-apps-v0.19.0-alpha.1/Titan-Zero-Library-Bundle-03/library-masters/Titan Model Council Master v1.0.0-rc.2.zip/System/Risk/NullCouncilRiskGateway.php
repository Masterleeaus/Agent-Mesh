<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Risk;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

final class NullCouncilRiskGateway implements CouncilRiskGatewayContract
{
    public function assessBefore(CouncilRequest $request): CouncilRiskAssessment
    {
        return new CouncilRiskAssessment(
            available: false,
            level: 'UNKNOWN',
            decision: 'UNAVAILABLE',
            canProceedWithoutEscalation: true,
            requiresEscalation: false,
            metadata: ['reason' => 'titan-risk-engine-unavailable'],
        );
    }

    public function assessAfter(CouncilRequest $request, array $result): CouncilRiskAssessment
    {
        return $this->assessBefore($request);
    }
}
