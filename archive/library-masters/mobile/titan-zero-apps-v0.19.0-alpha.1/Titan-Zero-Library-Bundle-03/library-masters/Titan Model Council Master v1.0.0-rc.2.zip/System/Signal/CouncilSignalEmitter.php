<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Signal;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Str;
use ReflectionMethod;
use Throwable;

final class CouncilSignalEmitter
{
    private const CURRENT_EMITTER = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterContract';
    private const CURRENT_AUTHORITY = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterAuthorityContract';
    private const CURRENT_CONTEXT = 'App\\Extensions\\TitanSignalEngine\\System\\Data\\SignalContext';

    /** @param array<int,string> $contractCandidates */
    public function __construct(
        private readonly Container $app,
        private readonly array $contractCandidates = [],
    ) {
    }

    public function available(): bool
    {
        if ($this->currentAvailable()) {
            return true;
        }

        return $this->resolveLegacyContract() !== null;
    }

    /** @param array<string,mixed> $payload @return array<string,mixed>|null */
    public function emit(CouncilRequest $request, string $eventType, array $payload, ?string $idempotencyKey = null): ?array
    {
        $traceId = $this->uuidOrNew($request->traceId);
        $correlationId = $this->uuidOrFallback($request->correlationId, $traceId);
        $causationId = $this->uuidOrFallback($request->causationId, $correlationId);
        $rootCausationId = $this->uuidOrFallback($request->rootCausationId, $causationId);

        $payload = $this->redact([
            ...$payload,
            'company_id' => $request->companyId,
            'company_id' => $request->companyId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $rootCausationId,
        ]);

        $signal = [
            'event_type' => $eventType,
            'scope' => 'tenant',
            'company_id' => $request->companyId,
            'company_id' => $request->companyId,
            'actor_type' => 'human',
            'actor_id' => (string) $request->userId,
            'actor_identity_provider' => 'laravel-auth',
            'actor_session_id' => $this->sessionId($request),
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $rootCausationId,
            'source' => 'titan-model-council',
            'source_component' => 'TitanModelCouncil',
            'schema_version' => 1,
            'payload' => $payload,
            'metadata' => ['advisory_only' => true],
            'severity' => $this->severity($eventType, $payload),
            'category' => 'model-deliberation',
            'idempotency_key' => $idempotencyKey,
        ];

        try {
            if ($this->currentAvailable()) {
                return $this->emitCurrent($request, $signal);
            }

            return $this->emitLegacy($signal);
        } catch (Throwable) {
            // Deliberation evidence must remain available even if telemetry is degraded.
            // Required Signal readiness is surfaced through health/certification instead.
            return null;
        }
    }

    /** @param array<string,mixed> $signal @return array<string,mixed>|null */
    private function emitCurrent(CouncilRequest $request, array $signal): ?array
    {
        $emitter = $this->app->make(self::CURRENT_EMITTER);
        $authority = $this->app->make(self::CURRENT_AUTHORITY);
        if (! is_object($emitter) || ! method_exists($emitter, 'emit') || ! is_object($authority) || ! method_exists($authority, 'issue')) {
            return null;
        }

        $identity = $authority->issue('titan-model-council');
        $contextClass = self::CURRENT_CONTEXT;
        $context = $contextClass::tenantHuman(
            $request->companyId,
            (string) $request->userId,
            $this->sessionId($request),
            'laravel-auth',
            $identity,
            ['signal.emit'],
        );

        // Titan Signal Engine v0.20+: trusted SignalContext is mandatory.
        $receipt = $emitter->emit($signal, $context);
        return $this->receiptArray($receipt);
    }

    /** @param array<string,mixed> $signal @return array<string,mixed>|null */
    private function emitLegacy(array $signal): ?array
    {
        $contract = $this->resolveLegacyContract();
        if ($contract === null) {
            return null;
        }
        $emitter = $this->app->make($contract);
        if (! is_object($emitter) || ! method_exists($emitter, 'emit')) {
            return null;
        }

        $method = new ReflectionMethod($emitter, 'emit');
        if ($method->getNumberOfRequiredParameters() > 1) {
            return null;
        }

        $receipt = $emitter->emit($signal);
        return $this->receiptArray($receipt);
    }

    private function currentAvailable(): bool
    {
        return interface_exists(self::CURRENT_EMITTER)
            && interface_exists(self::CURRENT_AUTHORITY)
            && class_exists(self::CURRENT_CONTEXT)
            && $this->app->bound(self::CURRENT_EMITTER)
            && $this->app->bound(self::CURRENT_AUTHORITY);
    }

    private function resolveLegacyContract(): ?string
    {
        $candidates = $this->contractCandidates ?: [
            'App\\Extensions\\TitanSignal\\System\\Contracts\\SignalEmitterContract',
            'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterContract',
        ];

        foreach ($candidates as $contract) {
            if (! is_string($contract) || $contract === '' || $contract === self::CURRENT_EMITTER) {
                continue;
            }
            if ($this->app->bound($contract)) {
                return $contract;
            }
        }

        return null;
    }

    private function sessionId(CouncilRequest $request): string
    {
        $candidate = trim((string) ($request->metadata['session_id'] ?? ''));
        return $candidate !== '' ? substr($candidate, 0, 160) : 'council:' . $request->userId;
    }

    /** @param array<string,mixed> $payload */
    private function severity(string $eventType, array $payload): string
    {
        if ($eventType === 'council.deliberation.failed') {
            return 'error';
        }
        if ($eventType === 'council.deliberation.escalated' || ($payload['requires_escalation'] ?? false) === true) {
            return 'warn';
        }
        return 'info';
    }

    private function uuidOrNew(?string $value): string
    {
        return is_string($value) && Str::isUuid($value) ? $value : (string) Str::uuid();
    }

    private function uuidOrFallback(?string $value, string $fallback): string
    {
        return is_string($value) && Str::isUuid($value) ? $value : $fallback;
    }

    /** @return array<string,mixed>|null */
    private function receiptArray(mixed $receipt): ?array
    {
        if (is_object($receipt) && method_exists($receipt, 'toArray')) {
            $array = $receipt->toArray();
            return is_array($array) ? $array : null;
        }
        if (is_array($receipt)) {
            return $receipt;
        }
        return null;
    }

    private function redact(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        $forbidden = array_map('strtolower', (array) config('titan-model-council.signal.forbidden_payload_fields', [
            'password', 'token', 'secret', 'authorization', 'signature',
        ]));
        $out = [];
        foreach ($value as $key => $item) {
            if (is_string($key) && in_array(strtolower($key), $forbidden, true)) {
                $out[$key] = '[REDACTED]';
                continue;
            }
            $out[$key] = $this->redact($item);
        }

        return $out;
    }
}
