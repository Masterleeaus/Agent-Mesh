<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Company;

use InvalidArgumentException;

final readonly class CompanyContext
{
    public function __construct(public int $companyId)
    {
        if ($companyId < 1) {
            throw new InvalidArgumentException('company_id must be positive.');
        }
    }
}
