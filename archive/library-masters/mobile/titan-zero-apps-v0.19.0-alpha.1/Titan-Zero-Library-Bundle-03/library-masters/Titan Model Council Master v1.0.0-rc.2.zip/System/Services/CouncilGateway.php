<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Services;

use App\Extensions\TitanModelCouncil\System\AICore\AICoreRuntimeProbe;
use App\Extensions\TitanModelCouncil\System\Assurance\CouncilAssuranceBridge;
use App\Extensions\TitanModelCouncil\System\Receipts\CouncilDecisionReceiptService;
use App\Extensions\TitanModelCouncil\System\Services\CouncilChatAdapter;
use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedCouncilRuntime;
use App\Extensions\TitanModelCouncil\System\Shield\CouncilShieldGateContract;
use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\Persistence\CouncilDecisionRepository;
use App\Extensions\TitanModelCouncil\System\Risk\CouncilRiskGatewayContract;
use App\Extensions\TitanModelCouncil\System\Signal\CouncilSignalEmitter;
use App\Extensions\TitanModelCouncil\System\Contracts\ExtensionHealth;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilActivationDecision;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

final class CouncilGateway implements CouncilGatewayContract
{
    private const STRATEGIES = [
        'single_model',
        'parallel_consensus',
        'lightweight_council',
        'governed_deliberation',
    ];

    public function __construct(
        private readonly CouncilChatAdapter $chat,
        private readonly SelectiveActivationPolicy $activationPolicy,
        private readonly CouncilDecisionRepository $decisions,
        private readonly CouncilRiskGatewayContract $risk,
        private readonly AICoreRuntimeProbe $aiCore,
        private readonly GovernedCouncilRuntime $governed,
        private readonly CouncilShieldGateContract $shield,
        private readonly CouncilSignalEmitter $signal,
        private readonly ExtensionHealth $extensionHealth,
        private readonly CouncilAssuranceBridge $assurance,
        private readonly CouncilDecisionReceiptService $receipts,
    ) {
    }

    public function health(): array
    {
        $aiCore = $this->aiCore->status();

        return [
            'engine' => 'titan-model-council',
            'status' => (bool) config('titan-model-council.enabled', true) ? 'release-candidate' : 'disabled',
            'foundation' => 'risk-integrated; governed-production-hardening',
            'version' => '1.0.0-rc.2',
            'execution_engine' => 'canonical',
            'strategies' => $this->strategies(),
            'selective_activation' => (bool) config('titan-model-council.selective_activation.enabled', true),
            'billing' => 'reserve_execute_settle',
            'risk_engine' => ! (bool) config('titan-model-council.risk_engine.enabled', true) ? 'disabled' : ($this->risk instanceof \App\Extensions\TitanModelCouncil\System\Risk\NullCouncilRiskGateway ? 'unavailable' : 'integrated'),
            'ai_core' => $aiCore,
            'governed_deliberation' => (bool) config('titan-model-council.governed_deliberation.enabled', true),
            'shield' => ! (bool) config('titan-model-council.shield.enabled', true) ? ['available' => false, 'status' => 'disabled'] : $this->shield->status(),
            'signal' => $this->signal->available() ? 'integrated-v0.20-compatible' : 'unavailable',
            'assurance' => ! (bool) config('titan-model-council.assurance.enabled', true) ? 'disabled' : ($this->assurance->available() ? 'integrated' : 'optional-unavailable'),
            'rewind_receipts' => 'local-hash-addressed',
            'operational_health' => $this->extensionHealth->snapshot(),
        ];
    }

    public function strategies(): array
    {
        return self::STRATEGIES;
    }

    public function supportsStrategy(string $strategy): bool
    {
        return in_array($strategy, self::STRATEGIES, true);
    }

    public function decideActivation(CouncilRequest $request): CouncilActivationDecision
    {
        if (! (bool) config('titan-model-council.enabled', true)) {
            return new CouncilActivationDecision('single_model', 'council_disabled', ['bypass_council' => true], 1);
        }
        $risk = $this->risk->assessBefore($request);
        return $this->activationPolicy->decide($request, $risk);
    }

    public function begin(CouncilRequest $request): array
    {
        if (! (bool) config('titan-model-council.enabled', true)) {
            $activation = new CouncilActivationDecision('single_model', 'council_disabled', ['bypass_council' => true], 1);
            return [
                'decision_id' => null,
                'activation' => $activation->toArray(),
                'risk' => (new CouncilRiskAssessment(false, null, 'UNKNOWN', 'UNAVAILABLE', true, false, null, ['council_disabled']))->toArray(),
                'ai_core' => $this->aiCore->status(),
            ];
        }
        $risk = $this->risk->assessBefore($request);
        $activation = $this->activationPolicy->decide($request, $risk);
        $decisionId = $this->decisions->recordActivation($request, $activation, null, $risk);
        $this->signal->emit($request, 'council.activation.decided', [
            'decision_id' => $decisionId,
            'strategy' => $activation->strategy,
            'activation_reason' => $activation->activationReason,
            'risk_level' => $risk->level,
            'requires_escalation' => $risk->requiresEscalation,
        ], 'council:activation:' . $decisionId);

        return [
            'decision_id' => $decisionId,
            'activation' => $activation->toArray(),
            'risk' => $risk->toArray(),
            'ai_core' => $this->aiCore->status(),
        ];
    }

    public function runGoverned(CouncilRequest $request, array $roleModels): array
    {
        if (! (bool) config('titan-model-council.enabled', true) || ! (bool) config('titan-model-council.governed_deliberation.enabled', true)) {
            return [
                'status' => 'rejected',
                'requires_escalation' => false,
                'execution_authority' => 'advisory_only',
                'reason' => 'governed_deliberation_disabled',
            ];
        }
        $this->signal->emit($request, 'council.deliberation.started', [
            'strategy' => 'governed_deliberation',
            'participant_roles' => array_keys($roleModels),
        ], 'council:governed:start:' . ($request->traceId ?? sha1($request->prompt)));

        $outcome = $this->governed->execute($request, $roleModels);
        $result = is_array($outcome['result'] ?? null) ? $outcome['result'] : $outcome;
        $failed = (($outcome['status'] ?? null) === 'failed') || (($result['status'] ?? null) === 'failed');
        $escalated = (($result['requires_escalation'] ?? false) === true);
        $event = $failed ? 'council.deliberation.failed' : ($escalated ? 'council.deliberation.escalated' : 'council.deliberation.completed');
        $this->signal->emit($request, $event, [
            'decision_id' => $outcome['decision_id'] ?? null,
            'status' => $result['status'] ?? ($outcome['status'] ?? 'completed'),
            'requires_escalation' => $escalated,
            'execution_authority' => $result['execution_authority'] ?? 'advisory_only',
            'receipt_id' => $outcome['receipt']['receipt_id'] ?? ($result['receipt']['receipt_id'] ?? null),
            'receipt_hash' => $outcome['receipt']['receipt_hash'] ?? ($result['receipt']['receipt_hash'] ?? null),
        ], 'council:governed:terminal:' . (($outcome['decision_id'] ?? null) ?: ($request->traceId ?? sha1($request->prompt))));

        return $outcome;
    }

    public function complete(CouncilRequest $request, int $decisionId, array $result): array
    {
        $postRisk = $this->risk->assessAfter($request, $result);
        $result['postflight_risk'] = $postRisk->toArray();
        if ($postRisk->requiresEscalation) {
            $result['requires_escalation'] = true;
        }
        $receipt = $this->receipts->record($request, $decisionId, $result);
        $result['receipt'] = $receipt;
        $updated = $this->decisions->complete($request->companyId, $decisionId, $result, $postRisk);
        $escalated = (bool) ($result['requires_escalation'] ?? false) || $postRisk->requiresEscalation;
        $this->signal->emit($request, $escalated ? 'council.deliberation.escalated' : 'council.deliberation.completed', [
            'decision_id' => $decisionId,
            'status' => (string) ($result['status'] ?? 'completed'),
            'requires_escalation' => $escalated,
            'confidence_percent' => $result['confidence_percent'] ?? null,
            'agreement_percent' => $result['agreement_percent'] ?? null,
            'receipt_id' => $receipt['receipt_id'] ?? null,
            'receipt_hash' => $receipt['receipt_hash'] ?? null,
        ], 'council:complete:' . $decisionId);

        return [
            'updated' => $updated,
            'decision_id' => $decisionId,
            'risk' => $postRisk->toArray(),
            'result' => $result,
        ];
    }
}
