<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

use Illuminate\Contracts\Container\Container;
use Throwable;

final class ShieldRuntimeProbe
{
    private const MANAGER = 'App\\Extensions\\TitanShield\\System\\Contracts\\ShieldManagerContract';
    private const INSPECTION_ENGINE = 'App\\Extensions\\TitanShield\\System\\Contracts\\InspectionEngineContract';

    public function __construct(
        private readonly Container $app,
        private readonly ?string $validationContract = null,
    ) {
    }

    /** @return array<string,mixed> */
    public function status(): array
    {
        $managerAvailable = interface_exists(self::MANAGER) && $this->app->bound(self::MANAGER);
        $capabilities = [];
        if ($managerAvailable) {
            try {
                $manager = $this->app->make(self::MANAGER);
                if (method_exists($manager, 'capabilities')) {
                    $capabilities = array_keys((array) $manager->capabilities());
                }
            } catch (Throwable) {
                $managerAvailable = false;
            }
        }

        $executionAvailable = is_string($this->validationContract)
            && trim($this->validationContract) !== ''
            && interface_exists($this->validationContract)
            && $this->app->bound($this->validationContract);

        $inspectionEngineAvailable = interface_exists(self::INSPECTION_ENGINE) && $this->app->bound(self::INSPECTION_ENGINE);

        return [
            'installed' => interface_exists(self::MANAGER) || interface_exists(self::INSPECTION_ENGINE),
            'manager_available' => $managerAvailable,
            'inspection_engine_available' => $inspectionEngineAvailable,
            'capabilities' => $capabilities,
            'council_validation_contract' => $this->validationContract,
            'semantic_validation_contract_detected' => $executionAvailable,
            'semantic_validation_execution_used' => false,
            'structural_validation' => 'local-guard',
            'inspection_lifecycle_bridge' => $inspectionEngineAvailable,
        ];
    }
}
