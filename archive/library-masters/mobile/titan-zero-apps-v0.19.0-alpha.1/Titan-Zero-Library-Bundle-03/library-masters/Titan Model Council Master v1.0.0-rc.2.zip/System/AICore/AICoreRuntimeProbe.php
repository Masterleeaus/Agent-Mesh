<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\AICore;

use Closure;
use Throwable;

final class AICoreRuntimeProbe
{
    private const MANAGER = 'App\\Extensions\\TitanAICore\\System\\Contracts\\AICoreManagerContract';

    private Closure $classExists;
    private Closure $resolver;

    public function __construct(?callable $classExists = null, ?callable $resolver = null, private readonly ?string $executionContract = null)
    {
        $this->classExists = Closure::fromCallable($classExists ?? static fn (string $class): bool => interface_exists($class) || class_exists($class));
        $this->resolver = Closure::fromCallable($resolver ?? static fn (string $abstract): mixed => function_exists('app') ? app($abstract) : null);
    }

    /** @return array<string,mixed> */
    public function status(): array
    {
        $exists = ($this->classExists)(self::MANAGER);
        if (! $exists) {
            return [
                'available' => false,
                'provider_execution_supported' => false,
                'mode' => 'legacy_provider_compatibility',
                'reason' => 'ai-core-contract-unavailable',
            ];
        }

        $health = [];
        try {
            $manager = ($this->resolver)(self::MANAGER);
            if (is_object($manager) && method_exists($manager, 'health')) {
                $health = (array) $manager->health();
            }
        } catch (Throwable $e) {
            $health = ['status' => 'error', 'exception' => $e::class];
        }

        $executionSupported = false;
        if (is_string($this->executionContract) && trim($this->executionContract) !== '') {
            $executionSupported = (bool) ($this->classExists)($this->executionContract);
        }

        return [
            'available' => true,
            'provider_execution_supported' => $executionSupported,
            'mode' => $executionSupported ? 'ai_core_runtime' : 'legacy_provider_compatibility',
            'health' => $health,
            'reason' => $executionSupported ? null : 'ai-core-has-no-published-execution-contract',
        ];
    }
}
