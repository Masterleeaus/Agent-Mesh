<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Company\CompanyContextResolver;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

final class PlanController
{
    public function __construct(
        private readonly CouncilGatewayContract $gateway,
        private readonly CompanyContextResolver $companyContext,
    ) {
    }

    public function __invoke(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'prompt' => ['required', 'string', 'max:100000'],
            'risk_level' => ['nullable', 'string', 'max:40'],
            'uncertainty' => ['nullable', 'string', 'max:40'],
            'manual_strategy' => ['nullable', 'string', 'max:80'],
            'trace_id' => ['nullable', 'uuid'],
            'correlation_id' => ['nullable', 'uuid'],
            'causation_id' => ['nullable', 'uuid'],
            'root_causation_id' => ['nullable', 'uuid'],
        ]);

        $actor = $request->user();
        if (! $actor) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }
        $company = $this->companyContext->resolve($request, $actor);
        if (! $company) {
            return response()->json(['error' => 'Company context required'], 422);
        }

        $traceId = (string) ($validated['trace_id'] ?? Str::uuid());
        $result = $this->gateway->begin(CouncilRequest::fromArray([
            'prompt' => $validated['prompt'],
            'company_id' => $company->companyId,
            'user_id' => (int) $actor->getAuthIdentifier(),
            'manual_strategy' => $validated['manual_strategy'] ?? null,
            'risk_level' => $validated['risk_level'] ?? 'unknown',
            'metadata' => [
                'uncertainty' => $validated['uncertainty'] ?? null,
            ],
            'trace_id' => $traceId,
            'correlation_id' => $validated['correlation_id'] ?? null,
            'causation_id' => $validated['causation_id'] ?? null,
            'root_causation_id' => $validated['root_causation_id'] ?? ($validated['causation_id'] ?? ($validated['correlation_id'] ?? $traceId)),
        ]));

        return response()->json([
            'trace_id' => $traceId,
            ...$result,
        ]);
    }
}
