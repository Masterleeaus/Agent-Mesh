<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Navigation;

use Illuminate\Contracts\Foundation\Application;
use App\Extensions\TitanModelCouncil\System\Models\HostMenuRecord;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Host compatibility adapter for Titan/MagicAI navigation.
 *
 * Modern contribution registries are attempted first. The database-backed
 * `menus` table remains the proven Website1408/Installer 1.7.x compatibility
 * fallback and is self-healed idempotently without touching business data.
 */
final class HostNavigationRegistrar
{
    private const OWNER = 'titan-model-council';
    private const USER_REGISTRY = 'App\\Support\\Extensions\\MenuContributionRegistry';
    private const CONTRIBUTION_REGISTRY = 'App\\Support\\Extensions\\ContributionRegistry';
    private const MENU_SERVICE = 'App\\Services\\Common\\MenuService';

    public function __construct(
        private readonly Application $app,
        private readonly ModelCouncilNavigation $navigation,
    ) {
    }

    public function register(): void
    {
        $this->registerContributions();
        $this->syncHostMenus();
    }

    public function registerContributions(): bool
    {
        $user = $this->navigation->userItems();
        $admin = $this->navigation->adminItems();

        $registered = $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.user', self::OWNER, $user],
            ['navigation.user', $user],
            [self::OWNER . '.user', $user],
        ]);

        $adminRegistered = $this->registerWith(self::CONTRIBUTION_REGISTRY, [
            ['navigation.admin', self::OWNER, $admin],
            ['navigation.admin', $admin],
            [self::OWNER . '.admin', $admin],
        ]);

        if (! $registered) {
            $registered = $this->registerWith(self::USER_REGISTRY, [
                ['navigation.user', self::OWNER, $user],
                ['navigation.user', $user],
                [self::OWNER, $user],
                [$user],
            ]);
        }

        if (! $adminRegistered) {
            $adminRegistered = $this->registerWith(self::USER_REGISTRY, [
                ['navigation.admin', self::OWNER, $admin],
                ['navigation.admin', $admin],
            ]);
        }

        return $registered || $adminRegistered;
    }

    /** @return array{available:bool,changed:bool,regenerated:bool,reason:?string,user_id:?int,admin_id:?int} */
    public function syncHostMenus(bool $forceRegenerate = false): array
    {
        if (! Schema::hasTable('menus')) {
            return $this->result(false, false, false, 'menus_table_unavailable');
        }

        try {
            $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
            if (! isset($columns['id']) || ! isset($columns['key'])) {
                return $this->result(false, false, false, 'menus_identity_columns_unavailable');
            }

            $user = $this->navigation->userItems()[0] ?? null;
            $adminItems = $this->navigation->adminItems();
            $admin = $adminItems[0] ?? null;
            if (! is_array($user) || ! is_array($admin)) {
                return $this->result(false, false, false, 'navigation_definition_missing');
            }

            $changed = false;
            $changed = $this->upsertDefinition($user, $columns, false, null) || $changed;

            // Parent must exist before child rows can resolve the host menus.parent_id.
            foreach ($adminItems as $definition) {
                if (! is_array($definition)) {
                    continue;
                }
                $parentId = null;
                $parentKey = trim((string) ($definition['parent_key'] ?? ''));
                if ($parentKey !== '') {
                    $resolvedParent = HostMenuRecord::query()->where('key', $parentKey)->orderBy('id')->value('id');
                    if ($resolvedParent === null) {
                        continue;
                    }
                    $parentId = (int) $resolvedParent;
                }
                $changed = $this->upsertDefinition($definition, $columns, true, $parentId) || $changed;
            }

            $userId = HostMenuRecord::query()->where('key', (string) $user['key'])->orderBy('id')->value('id');
            $adminId = HostMenuRecord::query()->where('key', (string) $admin['key'])->orderBy('id')->value('id');

            $regenerated = false;
            if ($changed || $forceRegenerate) {
                $regenerated = $this->regenerateMenuCache();
            }

            return $this->result(
                true,
                $changed,
                $regenerated,
                null,
                $userId === null ? null : (int) $userId,
                $adminId === null ? null : (int) $adminId,
            );
        } catch (Throwable $e) {
            Log::warning('Titan Model Council host menu self-heal failed.', [
                'error_class' => $e::class,
                'error_hash' => substr(hash('sha256', $e->getMessage()), 0, 16),
            ]);

            return $this->result(false, false, false, 'menu_sync_failed');
        }
    }

    /** @param array<string,mixed> $definition @param array<string,bool> $columns */
    private function upsertDefinition(array $definition, array $columns, bool $admin, ?int $parentId): bool
    {
        $key = trim((string) ($definition['key'] ?? ''));
        if ($key === '') {
            return false;
        }

        $existing = HostMenuRecord::query()->where('key', $key)->orderBy('id')->first();
        $matchCount = (int) HostMenuRecord::query()->where('key', $key)->count();
        if ($matchCount > 1) {
            Log::warning('Titan Model Council detected duplicate host menu keys; repairing only the canonical first row.', [
                'key' => $key,
                'count' => $matchCount,
            ]);
        }

        $now = now();
        $payload = [
            'parent_id' => $parentId,
            'route' => $definition['route'] ?? null,
            'route_slug' => $definition['route_slug'] ?? null,
            'label' => $definition['label'] ?? $key,
            'icon' => $definition['icon'] ?? 'tabler-users-group',
            'svg' => $definition['svg'] ?? null,
            'order' => (int) ($definition['order'] ?? $definition['priority'] ?? ($admin ? 994 : 125)),
            'is_active' => (bool) ($definition['is_active'] ?? true) ? 1 : 0,
            'params' => json_encode($definition['params'] ?? [], JSON_UNESCAPED_SLASHES),
            'type' => $definition['type'] ?? 'item',
            'badge' => $definition['badge'] ?? null,
            'extension' => '1',
            'is_admin' => $admin ? 1 : 0,
            'updated_at' => $now,
        ];
        $payload = array_intersect_key($payload, $columns);

        if ($existing !== null) {
            // Preserve explicit administrator enable/disable choice and custom ordering.
            unset($payload['is_active']);
            if ($parentId !== null || ! $admin || (int) ($existing->order ?? 0) >= 900) {
                unset($payload['order']);
            }

            $changed = false;
            foreach ($payload as $column => $value) {
                if ($column === 'updated_at') {
                    continue;
                }
                if ($this->normaliseComparable($existing->{$column} ?? null) !== $this->normaliseComparable($value)) {
                    $changed = true;
                    break;
                }
            }
            if (! $changed) {
                return false;
            }

            HostMenuRecord::query()->whereKey((int) ($existing->id ?? 0))->update($payload);
            return true;
        }

        $insert = array_merge([
            'key' => $key,
            'created_at' => $now,
            'custom_menu' => 0,
            'bolt_menu' => 0,
            'bolt_background' => null,
            'bolt_foreground' => null,
            'letter_icon' => 0,
            'letter_icon_bg' => null,
        ], $payload);
        HostMenuRecord::query()->insert(array_intersect_key($insert, $columns));

        return true;
    }

    /** @param list<array<int,mixed>> $argumentSets */
    private function registerWith(string $class, array $argumentSets): bool
    {
        if (! class_exists($class)) {
            return false;
        }

        try {
            $registry = $this->app->make($class);
        } catch (Throwable) {
            return false;
        }

        foreach (['register', 'contribute', 'add'] as $method) {
            if (! method_exists($registry, $method)) {
                continue;
            }
            foreach ($argumentSets as $arguments) {
                try {
                    $registry->{$method}(...$arguments);
                    return true;
                } catch (Throwable) {
                    // Try the next supported host signature.
                }
            }
        }

        return false;
    }

    private function regenerateMenuCache(): bool
    {
        $class = self::MENU_SERVICE;
        if (! class_exists($class) || ! method_exists($class, 'regenerate')) {
            return false;
        }

        try {
            $service = $this->app->make($class);
            $service->regenerate();
            return true;
        } catch (Throwable) {
            try {
                $class::regenerate();
                return true;
            } catch (Throwable) {
                return false;
            }
        }
    }

    private function normaliseComparable(mixed $value): string
    {
        if ($value === null) {
            return '';
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        return (string) $value;
    }

    /** @return array{available:bool,changed:bool,regenerated:bool,reason:?string,user_id:?int,admin_id:?int} */
    private function result(
        bool $available,
        bool $changed,
        bool $regenerated,
        ?string $reason,
        ?int $userId = null,
        ?int $adminId = null,
    ): array {
        return [
            'available' => $available,
            'changed' => $changed,
            'regenerated' => $regenerated,
            'reason' => $reason,
            'user_id' => $userId,
            'admin_id' => $adminId,
        ];
    }
}
