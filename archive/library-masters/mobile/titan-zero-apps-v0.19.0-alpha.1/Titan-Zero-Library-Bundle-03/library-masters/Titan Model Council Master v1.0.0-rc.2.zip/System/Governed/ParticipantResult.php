<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

final readonly class ParticipantResult
{
    /** @param array<string,mixed> $metadata */
    public function __construct(
        public CouncilRole $role,
        public string $modelSlug,
        public bool $success,
        public ?string $responseText = null,
        public ?int $confidencePercent = null,
        public ?int $responseTimeMs = null,
        public int $credits = 0,
        public ?string $failureReason = null,
        public array $metadata = [],
    ) {
    }

    /** @param array<string,mixed> $metadata */
    public static function success(CouncilRole $role, string $modelSlug, string $responseText, ?int $confidencePercent = null, ?int $responseTimeMs = null, int $credits = 0, array $metadata = []): self
    {
        return new self(
            role: $role,
            modelSlug: $modelSlug,
            success: true,
            responseText: trim($responseText),
            confidencePercent: $confidencePercent === null ? null : max(0, min(100, $confidencePercent)),
            responseTimeMs: $responseTimeMs,
            credits: max(0, $credits),
            metadata: $metadata,
        );
    }

    /** @param array<string,mixed> $metadata */
    public static function failure(CouncilRole $role, string $modelSlug, string $reason, ?int $responseTimeMs = null, array $metadata = []): self
    {
        return new self(
            role: $role,
            modelSlug: $modelSlug,
            success: false,
            responseTimeMs: $responseTimeMs,
            failureReason: trim($reason) !== '' ? trim($reason) : 'participant_failed',
            metadata: $metadata,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'role' => $this->role->value,
            'model_slug' => $this->modelSlug,
            'success' => $this->success,
            'response_text' => $this->responseText,
            'confidence_percent' => $this->confidencePercent,
            'response_time_ms' => $this->responseTimeMs,
            'credits' => $this->credits,
            'failure_reason' => $this->failureReason,
            'metadata' => $this->metadata,
        ];
    }
}
