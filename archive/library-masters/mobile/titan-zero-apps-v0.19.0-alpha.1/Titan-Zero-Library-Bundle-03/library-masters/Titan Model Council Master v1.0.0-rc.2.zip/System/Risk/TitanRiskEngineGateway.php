<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Risk;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

final class TitanRiskEngineGateway implements CouncilRiskGatewayContract
{
    private const MANAGER = 'App\\Extensions\\TitanRiskEngine\\System\\Contracts\\RiskManagerContract';
    private const CONTEXT = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskContext';
    private const IMPACT = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskImpactVector';
    private const REVERSIBILITY = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\Reversibility';
    private const CONNECTIVITY = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\ConnectivityState';

    public function __construct(private readonly Container $app) {}

    public static function isAvailable(Container $app): bool
    {
        return interface_exists(self::MANAGER) && $app->bound(self::MANAGER);
    }

    public function assessBefore(CouncilRequest $request): CouncilRiskAssessment
    {
        return $this->assess($request, [], 'council.preflight');
    }

    public function assessAfter(CouncilRequest $request, array $result): CouncilRiskAssessment
    {
        return $this->assess($request, $result, 'council.postflight');
    }

    /** @param array<string,mixed> $result */
    private function assess(CouncilRequest $request, array $result, string $action): CouncilRiskAssessment
    {
        if (! self::isAvailable($this->app)) {
            throw new RuntimeException('Titan Risk Engine is not available.');
        }

        try {
            $impactClass = self::IMPACT;
            $contextClass = self::CONTEXT;
            $reversibilityClass = self::REVERSIBILITY;
            $connectivityClass = self::CONNECTIVITY;

            $impactInput = is_array($request->metadata['risk_impact'] ?? null) ? $request->metadata['risk_impact'] : [];
            if ($result !== []) {
                if ((bool) ($result['strong_contradiction'] ?? false)) {
                    $impactInput['operational'] = max((float) ($impactInput['operational'] ?? 0), 65.0);
                    $impactInput['reputation'] = max((float) ($impactInput['reputation'] ?? 0), 50.0);
                }
                $confidence = isset($result['confidence_percent']) ? (float) $result['confidence_percent'] : null;
                if ($confidence !== null && $confidence < 50.0) {
                    $impactInput['operational'] = max((float) ($impactInput['operational'] ?? 0), 55.0);
                }
            }

            $impact = new $impactClass(
                financial: $this->clamp($impactInput['financial'] ?? 0),
                safety: $this->clamp($impactInput['safety'] ?? 0),
                privacy: $this->clamp($impactInput['privacy'] ?? 0),
                legal: $this->clamp($impactInput['legal'] ?? 0),
                operational: $this->clamp($impactInput['operational'] ?? 0),
                reputation: $this->clamp($impactInput['reputation'] ?? 0),
            );

            $reversibility = $this->enumCase($reversibilityClass, (string) ($request->metadata['reversibility'] ?? 'REVERSIBLE'), 'REVERSIBLE');
            $connectivity = $this->enumCase($connectivityClass, (string) ($request->metadata['connectivity'] ?? 'ONLINE'), 'ONLINE');

            $traceId = $request->traceId ?: (string) Str::uuid();
            $correlationId = $request->correlationId ?: $traceId;
            $causationId = $request->causationId ?: $correlationId;

            $metadata = $request->metadata;
            $metadata['council_phase'] = $action;
            if ($result !== []) {
                $metadata['council_result'] = [
                    'confidence_percent' => $result['confidence_percent'] ?? null,
                    'agreement_percent' => $result['agreement_percent'] ?? null,
                    'strong_contradiction' => (bool) ($result['strong_contradiction'] ?? false),
                    'actual_participant_count' => (int) ($result['actual_participant_count'] ?? 0),
                ];
            }

            $context = new $contextClass(
                companyId: $request->companyId,
                traceId: $traceId,
                correlationId: $correlationId,
                causationId: $causationId,
                capability: 'council.deliberate',
                action: $action,
                actorType: 'user',
                actorId: $request->userId,
                resourceType: isset($request->metadata['resource_type']) ? (string) $request->metadata['resource_type'] : null,
                resourceId: $request->metadata['resource_id'] ?? null,
                verticalKey: isset($request->metadata['vertical_key']) ? (string) $request->metadata['vertical_key'] : null,
                jurisdiction: isset($request->metadata['jurisdiction']) ? (string) $request->metadata['jurisdiction'] : null,
                impact: $impact,
                reversibility: $reversibility,
                connectivity: $connectivity,
                recentActivity: is_array($request->metadata['recent_activity'] ?? null) ? $request->metadata['recent_activity'] : [],
                metadata: $metadata,
            );

            $manager = $this->app->make(self::MANAGER);
            $assessment = $manager->assess($context);
            $array = $assessment->toArray();
            $reasonCodes = [];
            foreach (($array['reasons'] ?? []) as $reason) {
                if (is_array($reason) && isset($reason['code'])) {
                    $reasonCodes[] = (string) $reason['code'];
                }
            }

            return new CouncilRiskAssessment(
                available: true,
                score: isset($array['score']) ? (float) $array['score'] : null,
                level: strtoupper((string) ($array['level'] ?? 'UNKNOWN')),
                decision: strtoupper((string) ($array['decision'] ?? 'UNAVAILABLE')),
                canProceedWithoutEscalation: method_exists($assessment, 'canProceedWithoutEscalation') ? (bool) $assessment->canProceedWithoutEscalation() : false,
                requiresEscalation: ! (method_exists($assessment, 'canProceedWithoutEscalation') && $assessment->canProceedWithoutEscalation()),
                policyVersion: isset($array['policy_version']) ? (string) $array['policy_version'] : null,
                reasonCodes: array_values(array_unique($reasonCodes)),
                metadata: ['phase' => $action],
            );
        } catch (Throwable $e) {
            return new CouncilRiskAssessment(
                available: false,
                level: 'UNKNOWN',
                decision: 'ERROR',
                canProceedWithoutEscalation: false,
                requiresEscalation: true,
                metadata: ['reason' => 'risk-assessment-failed', 'exception' => $e::class],
            );
        }
    }

    private function clamp(mixed $value): float
    {
        return max(0.0, min(100.0, (float) $value));
    }

    private function enumCase(string $enumClass, string $value, string $default): object
    {
        $normalized = strtoupper(trim($value));
        foreach ($enumClass::cases() as $case) {
            if (strtoupper((string) $case->value) === $normalized || strtoupper($case->name) === $normalized) {
                return $case;
            }
        }
        foreach ($enumClass::cases() as $case) {
            if (strtoupper((string) $case->value) === $default || strtoupper($case->name) === $default) {
                return $case;
            }
        }
        return $enumClass::cases()[0];
    }
}
