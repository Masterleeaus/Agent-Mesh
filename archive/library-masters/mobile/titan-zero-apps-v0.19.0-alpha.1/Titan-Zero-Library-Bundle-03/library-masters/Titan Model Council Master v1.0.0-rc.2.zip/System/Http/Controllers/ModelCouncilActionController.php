<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\UserOpenaiChatMessage;
use App\Extensions\TitanModelCouncil\System\Security\AcceptedResponseScope;
use App\Extensions\TitanModelCouncil\System\Company\CompanyContextResolver;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class ModelCouncilActionController extends Controller
{
    public function __construct(private readonly CompanyContextResolver $companyContext)
    {
    }

    public function acceptResponse(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'messageId' => ['required', 'integer'],
        ]);

        $actor = $request->user();
        if (! $actor) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        $company = $this->companyContext->resolve($request, $actor);
        if (! $company) {
            return response()->json(['error' => 'Company context required'], 422);
        }

        $actorId = (int) $actor->getAuthIdentifier();
        $companyId = $company->companyId;
        $messageId = (int) $validated['messageId'];

        return DB::transaction(function () use ($actorId, $companyId, $messageId): JsonResponse {
            $message = UserOpenaiChatMessage::query()
                ->whereKey($messageId)
                ->where('company_id', $companyId)
                ->where('user_id', $actorId)
                ->lockForUpdate()
                ->first();

            if (! $message) {
                // Deliberately return 404 for both missing and foreign-owned IDs.
                return response()->json(['error' => 'Message not found'], 404);
            }

            $scope = AcceptedResponseScope::forMessage(
                $actorId,
                (int) $message->user_openai_chat_id,
                (int) $message->id,
                is_string($message->shared_uuid) ? $message->shared_uuid : null,
            );

            $deletedCount = 0;
            if ($scope !== null) {
                $deletedCount = UserOpenaiChatMessage::query()
                    ->where('company_id', $companyId)
                    ->where('user_id', $actorId)
                    ->where('user_openai_chat_id', $scope['user_openai_chat_id'])
                    ->where('shared_uuid', $scope['shared_uuid'])
                    ->where('id', '!=', $scope['exclude_id'])
                    ->delete();
            }

            if ($message->shared_uuid !== null) {
                $message->shared_uuid = null;
                $message->save();
            }

            return response()->json([
                'success' => true,
                'deleted' => $deletedCount,
            ]);
        });
    }
}
