<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Company;

final class CompanyIdResolver
{
    /**
     * Resolve only Titan's canonical company_id.
     * Resolve only Titan's canonical company_id; CRM customer/account relationships use customer_company_id and are intentionally separate.
     *
     * @param array<string,mixed> ...$sources
     */
    public function resolve(array ...$sources): ?int
    {
        foreach ($sources as $source) {
            $value = $source['company_id'] ?? null;
            if (is_int($value) || is_numeric($value)) {
                $id = (int) $value;
                if ($id > 0) {
                    return $id;
                }
            }
        }
        return null;
    }
}
