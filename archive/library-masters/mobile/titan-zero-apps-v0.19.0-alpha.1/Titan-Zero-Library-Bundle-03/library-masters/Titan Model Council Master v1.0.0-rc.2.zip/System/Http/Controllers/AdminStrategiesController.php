<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use Illuminate\Contracts\View\View;

final class AdminStrategiesController
{
    public function __construct(
        private readonly CouncilGatewayContract $gateway,
        private readonly ModelCouncilSettingsRepository $settings,
    ) {
    }

    public function __invoke(): View
    {
        return view('titan-model-council::admin.strategies', [
            'strategies' => $this->gateway->strategies(),
            'settings' => $this->settings->current(),
            'activation' => (array) config('titan-model-council.selective_activation', []),
            'governed' => (array) config('titan-model-council.governed_deliberation', []),
            'quorum' => (array) config('titan-model-council.adaptive_quorum', []),
        ]);
    }
}
