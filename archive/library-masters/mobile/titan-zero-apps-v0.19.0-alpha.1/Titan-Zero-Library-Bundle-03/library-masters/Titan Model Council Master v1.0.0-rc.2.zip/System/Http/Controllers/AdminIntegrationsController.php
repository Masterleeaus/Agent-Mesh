<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use Illuminate\Contracts\View\View;

final class AdminIntegrationsController
{
    public function __construct(
        private readonly CouncilGatewayContract $gateway,
        private readonly ModelCouncilSettingsRepository $settings,
    ) {
    }

    public function __invoke(): View
    {
        return view('titan-model-council::admin.integrations', [
            'health' => $this->gateway->health(),
            'settings' => $this->settings->current(),
            'signal' => (array) config('titan-model-council.signal', []),
            'risk' => (array) config('titan-model-council.risk_engine', []),
            'shield' => (array) config('titan-model-council.shield', []),
            'assurance' => (array) config('titan-model-council.assurance', []),
        ]);
    }
}
