<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

interface CouncilParticipantExecutorContract
{
    /** @param array<string,array<string,mixed>> $priorArtifacts */
    public function execute(
        CouncilRequest $request,
        CouncilRole $role,
        string $modelSlug,
        string $instruction,
        array $priorArtifacts = [],
    ): ParticipantResult;
}
