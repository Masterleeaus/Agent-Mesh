<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use Illuminate\Contracts\View\View;

final class IndexController
{
    public function __construct(private readonly CouncilGatewayContract $gateway)
    {
    }

    public function __invoke(): View
    {
        return view('titan-model-council::index', [
            'health' => $this->gateway->health(),
            'strategies' => $this->gateway->strategies(),
            'billingConfig' => (array) config('titan-model-council.billing', []),
        ]);
    }
}
