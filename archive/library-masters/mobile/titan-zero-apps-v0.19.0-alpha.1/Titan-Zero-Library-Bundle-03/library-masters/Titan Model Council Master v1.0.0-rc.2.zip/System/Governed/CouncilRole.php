<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

enum CouncilRole: string
{
    case PROPOSER = 'proposer';
    case CRITIC = 'critic';
    case VERIFIER = 'verifier';
    case ARBITER = 'arbiter';

    /** @return array<int,string> */
    public static function requiredValues(): array
    {
        return array_map(static fn (self $role): string => $role->value, self::cases());
    }
}
