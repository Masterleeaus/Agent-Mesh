<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

final class LocalCouncilShieldGate implements CouncilShieldGateContract
{
    public function validate(string $stage, CouncilRequest $request, array $artifacts): ShieldValidationResult
    {
        return match ($stage) {
            'pre_arbiter' => $this->validatePreArbiter($artifacts),
            'final' => $this->validateFinal($artifacts),
            default => ShieldValidationResult::block($stage, ['unknown_validation_stage']),
        };
    }

    public function status(): array
    {
        return [
            'source' => 'local-structural-guard',
            'external_available' => false,
            'scope' => 'structure-and-completeness-only',
            'factual_validation' => false,
        ];
    }

    /** @param array<string,array<string,mixed>> $artifacts */
    private function validatePreArbiter(array $artifacts): ShieldValidationResult
    {
        $reasons = [];
        foreach (['proposer', 'critic', 'verifier'] as $role) {
            $artifact = $artifacts[$role] ?? null;
            if (! is_array($artifact)) {
                $reasons[] = 'missing_' . $role;
                continue;
            }
            if (($artifact['success'] ?? false) !== true) {
                $reasons[] = $role . '_failed';
            }
            if (trim((string) ($artifact['response_text'] ?? '')) === '') {
                $reasons[] = $role . '_empty';
            }
        }

        return $reasons === []
            ? ShieldValidationResult::pass('pre_arbiter')
            : ShieldValidationResult::block('pre_arbiter', $reasons);
    }

    /** @param array<string,array<string,mixed>> $artifacts */
    private function validateFinal(array $artifacts): ShieldValidationResult
    {
        $arbiter = $artifacts['arbiter'] ?? null;
        if (! is_array($arbiter)) {
            return ShieldValidationResult::block('final', ['missing_arbiter']);
        }
        if (($arbiter['success'] ?? false) !== true) {
            return ShieldValidationResult::block('final', ['arbiter_failed']);
        }
        if (trim((string) ($arbiter['response_text'] ?? '')) === '') {
            return ShieldValidationResult::block('final', ['arbiter_empty']);
        }

        return ShieldValidationResult::pass('final');
    }
}
