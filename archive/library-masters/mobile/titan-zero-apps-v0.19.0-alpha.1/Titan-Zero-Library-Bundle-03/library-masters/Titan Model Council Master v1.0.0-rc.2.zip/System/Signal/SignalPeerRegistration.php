<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Signal;

use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Config\Repository as ConfigRepository;

/**
 * Registers Model Council as a trusted emitter and owner of its Council event
 * definitions when the current Titan Signal Engine is present. This modifies
 * runtime configuration only; it does not mutate the Signal extension package.
 */
final class SignalPeerRegistration
{
    public static function register(Container $app): void
    {
        if (! $app->bound('config')) {
            return;
        }

        /** @var ConfigRepository $config */
        $config = $app->make('config');
        $serviceId = 'titan-model-council';

        $trustedEmitters = (array) $config->get('titan-signal-engine.trusted_emitters', []);
        $trustedEmitters[$serviceId] = [
            'source' => $serviceId,
            'source_component' => 'TitanModelCouncil',
            'permissions' => ['signal.emit'],
            'event_type_patterns' => ['council.*'],
        ];
        $config->set('titan-signal-engine.trusted_emitters', $trustedEmitters);

        $eventTypes = (array) $config->get('titan-signal-engine.event_types', []);
        foreach (self::eventTypes() as $eventType => $definition) {
            // Do not silently override an existing canonical definition.
            $eventTypes[$eventType] ??= $definition;
        }
        $config->set('titan-signal-engine.event_types', $eventTypes);
    }

    /** @return array<string,array<string,mixed>> */
    private static function eventTypes(): array
    {
        $base = [
            'current_schema_version' => 1,
            'supported_schema_versions' => [1],
            'category' => 'model-deliberation',
            'allowed_scopes' => ['tenant'],
            'required_payload_fields' => [
                'company_id', 'trace_id', 'correlation_id', 'causation_id', 'root_causation_id',
            ],
            'optional_payload_fields' => [],
            'allow_additional_payload_fields' => true,
            'owner_source' => 'titan-model-council',
            'allowed_severities' => ['info', 'warn', 'error'],
            'status' => 'active',
        ];

        return [
            'council.activation.decided' => $base,
            'council.deliberation.started' => $base,
            'council.deliberation.completed' => $base,
            'council.deliberation.escalated' => $base,
            'council.deliberation.failed' => $base,
        ];
    }
}
