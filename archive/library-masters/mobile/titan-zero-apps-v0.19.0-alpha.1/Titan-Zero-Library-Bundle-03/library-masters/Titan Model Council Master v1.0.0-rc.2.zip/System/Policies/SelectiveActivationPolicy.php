<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Policies;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilActivationDecision;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

final class SelectiveActivationPolicy
{
    /** @param array<string,mixed> $config */
    public function __construct(private readonly array $config = [])
    {
    }

    public function decide(CouncilRequest $request, ?CouncilRiskAssessment $riskAssessment = null): CouncilActivationDecision
    {
        $manualDecision = $this->manualDecision($request);
        $riskDecision = $this->riskDecision($riskAssessment);

        if ($riskDecision !== null) {
            if ($manualDecision !== null && $this->strategyRank($manualDecision->strategy) > $this->strategyRank($riskDecision->strategy)) {
                return new CouncilActivationDecision(
                    $manualDecision->strategy,
                    $manualDecision->activationReason,
                    array_merge(
                        $riskDecision->triggerMetadata,
                        $manualDecision->triggerMetadata,
                        [
                            'risk_floor_strategy' => $riskDecision->strategy,
                            'risk_floor_applied' => false,
                        ],
                    ),
                    $manualDecision->requestedParticipants,
                );
            }

            if ($manualDecision !== null) {
                return new CouncilActivationDecision(
                    $riskDecision->strategy,
                    $riskDecision->activationReason,
                    array_merge(
                        $riskDecision->triggerMetadata,
                        [
                            'manual_strategy' => $request->manualStrategy,
                            'risk_floor_strategy' => $riskDecision->strategy,
                            'risk_floor_applied' => $this->strategyRank($manualDecision->strategy) < $this->strategyRank($riskDecision->strategy),
                        ],
                    ),
                    $riskDecision->requestedParticipants,
                );
            }

            return $riskDecision;
        }

        if ($manualDecision !== null) {
            return $manualDecision;
        }

        if (($this->config['enabled'] ?? true) !== true) {
            return new CouncilActivationDecision('parallel_consensus', 'selective_activation_disabled', [], 3);
        }

        foreach ((array) ($this->config['greeting_patterns'] ?? ['/^(hi|hello|hey)\\b/i']) as $pattern) {
            if (@preg_match((string) $pattern, $request->prompt) === 1) {
                return new CouncilActivationDecision('single_model', 'selective_trigger:greeting', ['matched_pattern' => $pattern], 1);
            }
        }

        $risk = strtolower($request->riskLevel);
        if (in_array($risk, ['high', 'critical', 'extreme'], true)) {
            $governed = (bool) ($this->config['governed_deliberation_enabled'] ?? false);
            $strategy = $governed ? 'governed_deliberation' : 'parallel_consensus';
            return new CouncilActivationDecision($strategy, 'selective_trigger:risk_level', ['risk_level' => $risk, 'governance_escalation_required' => ! $governed], $governed ? 4 : 3);
        }

        $prompt = strtolower($request->prompt);
        $matched = [];
        foreach ((array) ($this->config['high_consequence_actions'] ?? []) as $needle) {
            $needle = strtolower(trim((string) $needle));
            if ($needle !== '' && str_contains($prompt, $needle)) {
                $matched[] = $needle;
            }
        }
        if ($matched !== []) {
            $governed = (bool) ($this->config['governed_deliberation_enabled'] ?? false);
            $strategy = $governed ? 'governed_deliberation' : 'parallel_consensus';
            return new CouncilActivationDecision($strategy, 'selective_trigger:high_consequence', ['matched_actions' => array_values(array_unique($matched)), 'governance_escalation_required' => ! $governed], $governed ? 4 : 3);
        }

        $uncertainty = strtolower((string) ($request->metadata['uncertainty'] ?? ''));
        if (in_array($uncertainty, ['high', 'very_high'], true)) {
            return new CouncilActivationDecision('parallel_consensus', 'selective_trigger:high_uncertainty', ['uncertainty' => $uncertainty], 3);
        }
        if (in_array($uncertainty, ['moderate', 'medium'], true)) {
            return new CouncilActivationDecision('lightweight_council', 'selective_trigger:moderate_uncertainty', ['uncertainty' => $uncertainty], 2);
        }

        return new CouncilActivationDecision('single_model', 'selective_trigger:low_consequence', [], 1);
    }

    private function manualDecision(CouncilRequest $request): ?CouncilActivationDecision
    {
        if (! ($this->config['manual_override_wins'] ?? true)) {
            return null;
        }

        $manual = trim((string) ($request->manualStrategy ?? ''));
        $allowed = ['single_model', 'lightweight_council', 'parallel_consensus', 'governed_deliberation'];
        if (! in_array($manual, $allowed, true)) {
            return null;
        }

        if ($manual === 'governed_deliberation' && ! (bool) ($this->config['governed_deliberation_enabled'] ?? false)) {
            return new CouncilActivationDecision(
                'parallel_consensus',
                'manual_user_request',
                ['manual_strategy' => $manual, 'governance_escalation_required' => true],
                3,
            );
        }

        return new CouncilActivationDecision($manual, 'manual_user_request', ['manual_strategy' => $manual], $this->participantsFor($manual));
    }

    private function riskDecision(?CouncilRiskAssessment $risk): ?CouncilActivationDecision
    {
        if ($risk === null || ! $risk->available) {
            return null;
        }

        $decision = strtoupper($risk->decision);
        $level = strtoupper($risk->level);
        $base = [
            'risk_score' => $risk->score,
            'risk_level' => $level,
            'risk_decision' => $decision,
            'risk_policy_version' => $risk->policyVersion,
            'risk_reason_codes' => $risk->reasonCodes,
        ];

        if (in_array($decision, ['BLOCK', 'REQUIRE_APPROVAL', 'REDUCE_AUTHORITY', 'DEFER'], true) || in_array($level, ['HIGH', 'EXTREME'], true)) {
            $governed = (bool) ($this->config['governed_deliberation_enabled'] ?? false);
            return new CouncilActivationDecision(
                $governed ? 'governed_deliberation' : 'parallel_consensus',
                'risk_engine:' . strtolower($decision),
                $base + [
                    'governance_escalation_required' => true,
                    'execution_authority' => $decision === 'BLOCK' ? 'blocked' : 'reduced',
                ],
                $governed ? 4 : 3,
            );
        }

        if ($decision === 'REQUIRE_ASSURANCE' || $level === 'MEDIUM') {
            $governed = (bool) ($this->config['governed_deliberation_enabled'] ?? false);
            return new CouncilActivationDecision(
                $governed ? 'governed_deliberation' : 'parallel_consensus',
                'risk_engine:require_assurance',
                $base + [
                    'assurance_required' => true,
                    'governance_escalation_required' => true,
                ],
                $governed ? 4 : 3,
            );
        }

        if ($decision === 'ALLOW_WITH_MONITORING' && (($this->config['risk_monitoring_minimum'] ?? 'lightweight_council') === 'lightweight_council')) {
            return new CouncilActivationDecision(
                'lightweight_council',
                'risk_engine:allow_with_monitoring',
                $base + ['monitoring_required' => true],
                2,
            );
        }

        return null;
    }

    private function strategyRank(string $strategy): int
    {
        return match ($strategy) {
            'single_model' => 1,
            'lightweight_council' => 2,
            'parallel_consensus' => 3,
            'governed_deliberation' => 4,
            default => 0,
        };
    }

    private function participantsFor(string $strategy): int
    {
        return match ($strategy) {
            'single_model' => 1,
            'lightweight_council' => 2,
            'governed_deliberation' => 4,
            default => 3,
        };
    }
}
