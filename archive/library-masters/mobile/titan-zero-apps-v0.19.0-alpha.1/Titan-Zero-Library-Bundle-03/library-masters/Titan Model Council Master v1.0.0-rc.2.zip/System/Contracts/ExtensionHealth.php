<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Contracts;

interface ExtensionHealth
{
    /** @return array{status:string,checks:array<string,string>,observed_at:string} */
    public function snapshot(): array;
}
