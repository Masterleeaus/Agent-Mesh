<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use Illuminate\Contracts\View\View;

final class AdminProvidersController
{
    public function __construct(
        private readonly CouncilGatewayContract $gateway,
        private readonly ModelCouncilSettingsRepository $settings,
    ) {
    }

    public function __invoke(): View
    {
        $health = $this->gateway->health();
        return view('titan-model-council::admin.providers', [
            'health' => $health,
            'settings' => $this->settings->current(),
            'aiCore' => (array) config('titan-model-council.ai_core', []),
            'hostMaxModels' => function_exists('setting') ? setting('ai_chat_pro_council_max_models', null) : null,
            'hostSynthesisModel' => function_exists('setting') ? setting('ai_chat_pro_council_synthesis_model', null) : null,
        ]);
    }
}
