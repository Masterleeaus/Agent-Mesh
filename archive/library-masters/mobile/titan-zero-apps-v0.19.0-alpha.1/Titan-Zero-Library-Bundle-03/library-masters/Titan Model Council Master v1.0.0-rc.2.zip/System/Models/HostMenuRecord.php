<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Narrow compatibility record for MagicAI/Website1408's host-owned menus table.
 *
 * Model Council does not own this table; this record exists only to self-heal
 * declared navigation entries without bypassing the Blueprint domain boundary.
 */
final class HostMenuRecord extends Model
{
    protected $table = 'menus';

    protected $guarded = [];

    public $timestamps = false;
}
