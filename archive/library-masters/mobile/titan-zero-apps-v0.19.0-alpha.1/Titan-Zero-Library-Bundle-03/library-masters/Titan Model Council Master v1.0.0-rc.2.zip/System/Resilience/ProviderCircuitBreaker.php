<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Resilience;

use Illuminate\Support\Facades\Cache;

final class ProviderCircuitBreaker
{
    public function __construct(
        private readonly int $failureThreshold = 3,
        private readonly int $cooldownSeconds = 60,
    ) {
    }

    public function allowsUrl(string $url): bool
    {
        $host = $this->host($url);
        if ($host === '') {
            return true;
        }

        $state = $this->state($host);
        $openUntil = (int) ($state['open_until'] ?? 0);
        if ($openUntil <= 0) {
            return true;
        }
        if ($openUntil > time()) {
            return false;
        }

        // Cooldown expired. Permit probes again but retain the prior failure
        // history until a successful request proves recovery.
        return true;
    }

    public function recordSuccessUrl(string $url): void
    {
        $host = $this->host($url);
        if ($host !== '') {
            Cache::forget($this->key($host));
        }
    }

    public function recordFailureUrl(string $url): void
    {
        $host = $this->host($url);
        if ($host === '') {
            return;
        }

        $key = $this->key($host);
        $lock = Cache::lock($key . ':lock', 3);
        try {
            $lock->block(1, function () use ($key): void {
                $state = Cache::get($key, []);
                $failures = max(0, (int) ($state['failures'] ?? 0)) + 1;
                $openUntil = $failures >= max(1, $this->failureThreshold)
                    ? time() + max(1, $this->cooldownSeconds)
                    : (int) ($state['open_until'] ?? 0);

                Cache::put($key, [
                    'failures' => $failures,
                    'open_until' => $openUntil,
                    'updated_at' => time(),
                ], max(60, $this->cooldownSeconds * 4));
            });
        } catch (\Throwable) {
            // Circuit telemetry must never create a second provider outage.
            // On cache/lock failure the provider call itself remains authoritative.
        } finally {
            optional($lock)->release();
        }
    }

    /** @return array{failures:int,open_until:int,updated_at:int}|array{} */
    public function stateForUrl(string $url): array
    {
        $host = $this->host($url);
        return $host === '' ? [] : $this->state($host);
    }

    private function host(string $url): string
    {
        return strtolower((string) (parse_url($url, PHP_URL_HOST) ?: ''));
    }

    /** @return array<string,int> */
    private function state(string $host): array
    {
        $value = Cache::get($this->key($host), []);
        return is_array($value) ? $value : [];
    }

    private function key(string $host): string
    {
        return 'titan:model-council:provider-circuit:' . hash('sha256', $host);
    }
}
