<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

final class ShieldAwareCouncilGate implements CouncilShieldGateContract
{
    public function __construct(
        private readonly LocalCouncilShieldGate $local,
        private readonly ShieldRuntimeProbe $probe,
        private readonly TitanShieldInspectionBridge $inspectionBridge,
    ) {
    }

    public function validate(string $stage, CouncilRequest $request, array $artifacts): ShieldValidationResult
    {
        $result = $this->local->validate($stage, $request, $artifacts);
        $inspection = $this->inspectionBridge->record($stage, $request, $result);
        $source = (($inspection['recorded'] ?? false) === true)
            ? 'local-structural-guard+titan-shield-inspection'
            : 'local-structural-guard';

        return new ShieldValidationResult(
            stage: $result->stage,
            passed: $result->passed,
            blocked: $result->blocked,
            requiresEscalation: $result->requiresEscalation,
            reasonCodes: $result->reasonCodes,
            source: $source,
            metadata: $result->metadata + [
                'titan_shield' => $this->probe->status(),
                'shield_inspection' => $inspection,
            ],
        );
    }

    public function status(): array
    {
        return [
            ...$this->local->status(),
            'titan_shield' => $this->probe->status(),
            'inspection_bridge_available' => $this->inspectionBridge->available(),
            'note' => 'Shield inspection lifecycle is used when available; semantic/factual verdict generation remains local/peer-capability dependent.',
        ];
    }
}
