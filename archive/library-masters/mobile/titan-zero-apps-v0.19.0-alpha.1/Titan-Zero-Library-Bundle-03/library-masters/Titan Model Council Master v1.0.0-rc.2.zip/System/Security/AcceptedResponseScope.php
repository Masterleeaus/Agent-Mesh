<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Security;

final class AcceptedResponseScope
{
    /**
     * @return array{user_id:int,user_openai_chat_id:int,shared_uuid:string,exclude_id:int}|null
     */
    public static function forMessage(int $userId, int $chatId, int $messageId, ?string $sharedUuid): ?array
    {
        $sharedUuid = $sharedUuid === null ? null : trim($sharedUuid);

        if ($sharedUuid === null || $sharedUuid === '') {
            return null;
        }

        return [
            'user_id' => $userId,
            'user_openai_chat_id' => $chatId,
            'shared_uuid' => $sharedUuid,
            'exclude_id' => $messageId,
        ];
    }
}
