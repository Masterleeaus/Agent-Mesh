<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Commands;

use App\Extensions\TitanModelCouncil\System\Contracts\ExtensionHealth;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-model-council:certify {--json : Emit JSON evidence only}';
    protected $description = 'Run non-destructive Titan host certification checks for titan-model-council.';

    public function handle(): int
    {
        $checks = [];
        $record = static function (string $name, bool $passed, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $name, 'passed' => $passed, 'detail' => $detail];
        };

        $record('php', PHP_VERSION_ID >= 80200, PHP_VERSION);
        $record('laravel', str_starts_with((string) app()->version(), '10.'), (string) app()->version());
        $record('provider_binding', app()->providerIsLoaded(\App\Extensions\TitanModelCouncil\System\TitanModelCouncilServiceProvider::class));
        $record('storage', is_writable(storage_path()), storage_path());

        try {
            DB::connection()->getPdo();
            $record('database', DB::connection()->getDriverName() === 'mysql', DB::connection()->getDriverName());
        } catch (Throwable $e) {
            $record('database', false, $e->getMessage());
        }

        foreach (['titan_model_council_decisions', 'titan_model_council_participants', 'titan_model_council_billing_reservations', 'titan_model_council_receipts', 'titan_model_council_settings'] as $table) {
            $record('table:' . $table, Schema::hasTable($table));
        }

        $routePrefix = 'dashboard.user.titan.model.council.';
        $routeFound = collect(Route::getRoutes()->getRoutes())
            ->contains(static fn ($route): bool => str_starts_with((string) $route->getName(), $routePrefix));
        $record('routes', $routeFound, $routePrefix);

        try {
            $health = app(ExtensionHealth::class)->snapshot();
            $record('health', ($health['status'] ?? 'UNAVAILABLE') !== 'UNAVAILABLE', (string) ($health['status'] ?? 'UNAVAILABLE'));
            $record('signal', (($health['checks']['signal'] ?? null) === 'HEALTHY'), (string) ($health['checks']['signal'] ?? 'UNAVAILABLE'));
        } catch (Throwable $e) {
            $record('health', false, $e->getMessage());
        }

        $manifestPath = dirname(__DIR__, 2) . '/extension.manifest.json';
        $manifest = is_file($manifestPath) ? json_decode((string) file_get_contents($manifestPath), true) : null;
        $record('manifest_v2_2', is_array($manifest) && ($manifest['schema_version'] ?? null) === '2.2', $manifestPath);

        $passed = collect($checks)->every(static fn (array $check): bool => $check['passed'] === true);
        $evidence = [
            'schema_version' => '1.0',
            'contract' => 'titan.release-certification.v1',
            'extension' => 'titan-model-council',
            'host_certified' => $passed,
            'checked_at' => now()->toIso8601String(),
            'checks' => $checks,
        ];
        $json = json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $this->option('json') ? $this->line((string) $json) : $this->info(($passed ? 'Host certification PASS' : 'Host certification FAILED') . "\n" . $json);

        return $passed ? self::SUCCESS : self::FAILURE;
    }
}
