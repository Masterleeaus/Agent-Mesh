<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Contracts;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilActivationDecision;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

interface CouncilGatewayContract
{
    /** @return array<string,mixed> */
    public function health(): array;

    /** @return array<int,string> */
    public function strategies(): array;

    public function supportsStrategy(string $strategy): bool;

    public function decideActivation(CouncilRequest $request): CouncilActivationDecision;

    /** @return array<string,mixed> */
    public function begin(CouncilRequest $request): array;

    /** @param array<string,string> $roleModels @return array<string,mixed> */
    public function runGoverned(CouncilRequest $request, array $roleModels): array;

    /** @param array<string,mixed> $result @return array<string,mixed> */
    public function complete(CouncilRequest $request, int $decisionId, array $result): array;
}
