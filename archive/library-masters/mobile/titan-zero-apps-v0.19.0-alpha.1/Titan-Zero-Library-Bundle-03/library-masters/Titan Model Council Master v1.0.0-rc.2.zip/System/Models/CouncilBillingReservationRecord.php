<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;

final class CouncilBillingReservationRecord extends Model
{

    protected $table = 'titan_model_council_billing_reservations';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'company_id' => 'integer',
            'company_id' => 'integer',
        'user_id' => 'integer',
        'reserved_credits' => 'integer',
        'settled_credits' => 'integer',
        'released_credits' => 'integer',
        'reserved_components' => 'array',
        'settled_components' => 'array',
        'reserved_at' => 'datetime',
        'settled_at' => 'datetime',
        'released_at' => 'datetime',
    ];
}
