<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Services;

use App\Extensions\TitanModelCouncil\System\Services\ModelCouncilExecutionService;
use App\Models\User;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Canonical chat-facing adapter over the Model Council execution service.
 */
final class CouncilChatAdapter
{
    public function __construct(private readonly ModelCouncilExecutionService $service)
    {
    }

    public function generateCouncilResponse(Request $request, array $chatParams, array $history, ?User $user): array
    {
        return $this->service->generateCouncilResponse($request, $chatParams, $history, $user);
    }

    public function streamCouncilResponse(Request $request, array $chatParams, array $history, ?User $user): StreamedResponse
    {
        return $this->service->streamCouncilResponse($request, $chatParams, $history, $user);
    }

    public function streamCouncilSummaryFromShared(Request $request, array $chatParams, ?User $user): StreamedResponse
    {
        return $this->service->streamCouncilSummaryFromShared($request, $chatParams, $user);
    }
}
