<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Assurance;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Contracts\Container\Container;
use Throwable;

/**
 * Optional evidence-assurance boundary. It never upgrades Council authority;
 * AMBER/RED results only add escalation pressure.
 */
final class CouncilAssuranceBridge
{
    private const CONTRACT = 'App\\Extensions\\ModelCouncil\\System\\Contracts\\EvidenceAssuranceEngine';

    public function __construct(private readonly Container $app)
    {
    }

    public function available(): bool
    {
        return interface_exists(self::CONTRACT) && $this->app->bound(self::CONTRACT);
    }

    /** @param array<string,mixed> $result @return array<string,mixed> */
    public function assess(CouncilRequest $request, array $result, bool $required = false): array
    {
        if (! $this->available()) {
            return [
                'available' => false,
                'evaluated' => false,
                'required' => $required,
                'assurance-band' => null,
                'requires_escalation' => $required,
                'reason_codes' => $required ? ['ASSURANCE_REQUIRED_BUT_UNAVAILABLE'] : [],
            ];
        }

        try {
            $engine = $this->app->make(self::CONTRACT);
            $evidence = $this->evidence($result);
            $assessment = $engine->assess([
                'subject' => [
                    'type' => 'titan-model-council-decision',
                    'trace_id' => $request->traceId,
                ],
                'evidence' => $evidence,
                'decision_type' => 'model-deliberation',
                'capability' => 'council.deliberate',
                'workflow_key' => 'titan-model-council.governed',
                'policy_version' => (string) config('titan-model-council.assurance.policy_version', 'titan-assurance-v2.2'),
                'trace' => [
                    'trace_id' => $request->traceId,
                    'correlation_id' => $request->correlationId,
                    'causation_id' => $request->causationId,
                ],
                'idempotency_key' => 'council-assurance:' . ($request->traceId ?: hash('sha256', $request->prompt)),
            ]);

            $status = strtoupper(trim((string) ($assessment->status ?? 'RED')));
            if (! in_array($status, ['GREEN', 'AMBER', 'RED'], true)) {
                $status = 'RED';
            }
            $requiresEscalation = $status !== 'GREEN';

            return [
                'available' => true,
                'evaluated' => true,
                'required' => $required,
                'assessment_id' => isset($assessment->id) ? (int) $assessment->id : null,
                'assessment_uuid' => isset($assessment->uuid) ? (string) $assessment->uuid : null,
                'assurance-band' => $status,
                'score' => isset($assessment->score) ? (float) $assessment->score : null,
                'reason_codes' => array_values((array) ($assessment->reason_codes ?? [])),
                'policy_version' => isset($assessment->policy_version) ? (string) $assessment->policy_version : null,
                'requires_escalation' => $requiresEscalation,
            ];
        } catch (Throwable $e) {
            return [
                'available' => true,
                'evaluated' => false,
                'required' => $required,
                'assurance-band' => null,
                'requires_escalation' => $required,
                'reason_codes' => [$required ? 'ASSURANCE_REQUIRED_EVALUATION_FAILED' : 'ASSURANCE_OPTIONAL_EVALUATION_FAILED'],
                'exception' => $e::class,
            ];
        }
    }

    /** @param array<string,mixed> $result @return list<array<string,mixed>> */
    private function evidence(array $result): array
    {
        $out = [];
        foreach ((array) ($result['participants'] ?? []) as $role => $participant) {
            if (! is_array($participant) || ($participant['success'] ?? false) !== true) {
                continue;
            }
            $text = trim((string) ($participant['response_text'] ?? ''));
            $model = trim((string) ($participant['model_slug'] ?? 'unknown'));
            if ($text === '') {
                continue;
            }
            $out[] = [
                'evidence_type' => 'model-deliberation-participant',
                'subject' => ['role' => (string) $role, 'decision_type' => 'model-deliberation'],
                'source' => 'titan-model-council:model:' . $model,
                'confidence' => isset($participant['confidence_percent']) ? ((int) $participant['confidence_percent']) / 100 : 0.5,
                'authority' => 'model',
                'relevance' => 1.0,
                'verification_state' => 'unverified',
                'content' => [
                    'role' => (string) $role,
                    'model_slug' => $model,
                    'output_sha256' => hash('sha256', $text),
                ],
            ];
        }

        $final = trim((string) ($result['final_answer'] ?? ''));
        if ($final !== '') {
            $out[] = [
                'evidence_type' => 'model-deliberation-arbitrated-output',
                'subject' => ['role' => 'arbiter', 'decision_type' => 'model-deliberation'],
                'source' => 'titan-model-council:arbiter',
                'confidence' => isset($result['confidence_percent']) ? ((int) $result['confidence_percent']) / 100 : 0.5,
                'authority' => 'model',
                'relevance' => 1.0,
                'verification_state' => 'reviewed',
                'content' => ['output_sha256' => hash('sha256', $final)],
            ];
        }

        return $out;
    }
}
