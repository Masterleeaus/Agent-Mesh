<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ModelCouncilSetting extends Model
{
    protected $table = 'titan_model_council_settings';
    protected $guarded = ['id'];

    protected $casts = [
        'enabled' => 'boolean',
        'max_models' => 'integer',
        'selective_activation_enabled' => 'boolean',
        'governed_deliberation_enabled' => 'boolean',
        'minimum_distinct_models' => 'integer',
        'risk_engine_enabled' => 'boolean',
        'shield_enabled' => 'boolean',
        'assurance_enabled' => 'boolean',
        'contradiction_enabled' => 'boolean',
        'contradiction_confidence_ceiling' => 'integer',
        'adaptive_quorum_enabled' => 'boolean',
        'minimum_successful_participants' => 'integer',
        'minimum_agreement_percent' => 'integer',
        'provider_timeout_seconds' => 'integer',
        'provider_circuit_breaker_enabled' => 'boolean',
        'provider_failure_threshold' => 'integer',
        'provider_cooldown_seconds' => 'integer',
        'billing_reservation_required' => 'boolean',
        'max_reserved_credits_per_participant' => 'integer',
        'updated_by_user_id' => 'integer',
    ];
}
