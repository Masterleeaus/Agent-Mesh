<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Models\CouncilDecisionRecord;
use App\Extensions\TitanModelCouncil\System\Models\CouncilReceiptRecord;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Schema;

final class AdminDiagnosticsController
{
    public function __construct(private readonly CouncilGatewayContract $gateway)
    {
    }

    public function __invoke(): View
    {
        $decisions = collect();
        $receipts = collect();
        if (Schema::hasTable('titan_model_council_decisions')) {
            $decisions = CouncilDecisionRecord::query()->latest('id')->limit(25)->get();
        }
        if (Schema::hasTable('titan_model_council_receipts')) {
            $receipts = CouncilReceiptRecord::query()->latest('id')->limit(25)->get();
        }

        return view('titan-model-council::admin.diagnostics', [
            'health' => $this->gateway->health(),
            'decisions' => $decisions,
            'receipts' => $receipts,
        ]);
    }
}
