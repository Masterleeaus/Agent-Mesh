<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Models;

use Illuminate\Database\Eloquent\Model;

final class CouncilParticipantRecord extends Model
{

    protected $table = 'titan_model_council_participants';
    protected $guarded = [];

    protected $casts = [
        'company_id' => 'integer',
        'company_id' => 'integer',
            'company_id' => 'integer',
        'decision_id' => 'integer',
        'credits' => 'integer',
        'metadata' => 'array',
    ];
}
