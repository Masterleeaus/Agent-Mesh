<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Persistence;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilActivationDecision;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;
use App\Extensions\TitanModelCouncil\System\Models\CouncilDecisionRecord;
use App\Extensions\TitanModelCouncil\System\Models\CouncilParticipantRecord;
use Illuminate\Support\Str;

final class CouncilDecisionRepository
{
    public function recordActivation(CouncilRequest $request, CouncilActivationDecision $decision, ?string $billingReservationId = null, ?CouncilRiskAssessment $risk = null): int
    {
        $effectiveRiskLevel = $risk?->available ? $risk->level : $request->riskLevel;
        $record = CouncilDecisionRecord::query()->create([
            'company_id' => $request->companyId,
            'company_id' => $request->companyId,
            'trace_id' => $request->traceId ?: (string) Str::uuid(),
            'correlation_id' => $request->correlationId,
            'causation_id' => $request->causationId,
            'root_causation_id' => $request->rootCausationId,
            'type' => 'activation',
            'status' => $decision->strategy === 'single_model' ? 'bypassed' : 'activated',
            'activation_reason' => $decision->activationReason,
            'activation_source' => str_starts_with($decision->activationReason, 'manual_') ? 'manual' : (str_starts_with($decision->activationReason, 'risk_engine:') ? 'risk_engine' : 'policy'),
            'trigger_metadata' => $decision->triggerMetadata,
            'strategy' => $decision->strategy,
            'risk_level' => $effectiveRiskLevel,
            'risk_score' => $risk?->score,
            'risk_decision' => $risk?->decision,
            'risk_policy_version' => $risk?->policyVersion,
            'risk_engine_available' => $risk?->available ?? false,
            'preflight_risk_payload' => $risk?->toArray(),
            'requested_participant_count' => $decision->requestedParticipants,
            'actual_participant_count' => 0,
            'billing_reservation_id' => $billingReservationId,
            'payload' => ['user_id' => $request->userId],
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return (int) $record->getKey();
    }

    /** @param array<string,array<string,mixed>> $participants */
    public function recordGovernedParticipants(CouncilRequest $request, int $decisionId, array $participants): void
    {
        foreach ($participants as $role => $participant) {
            if (! is_array($participant)) {
                continue;
            }
            $responseText = trim((string) ($participant['response_text'] ?? ''));
            CouncilParticipantRecord::query()->updateOrCreate(
                [
                    'company_id' => $request->companyId,
            'company_id' => $request->companyId,
                    'decision_id' => $decisionId,
                    'role' => (string) $role,
                ],
                [
                    'trace_id' => $request->traceId,
                    'model_slug' => (string) ($participant['model_slug'] ?? ''),
                    'status' => (($participant['success'] ?? false) === true) ? 'completed' : 'failed',
                    'confidence_percent' => isset($participant['confidence_percent']) ? max(0, min(100, (int) $participant['confidence_percent'])) : null,
                    'response_time_ms' => isset($participant['response_time_ms']) ? max(0, (int) $participant['response_time_ms']) : null,
                    'credits' => max(0, (int) ($participant['credits'] ?? 0)),
                    'failure_reason' => isset($participant['failure_reason']) ? (string) $participant['failure_reason'] : null,
                    'response_text' => $responseText !== '' ? $responseText : null,
                    'output_sha256' => $responseText !== '' ? hash('sha256', $responseText) : null,
                    'metadata' => (array) ($participant['metadata'] ?? []),
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            );
        }
    }

    /** @param array<string,mixed> $result */
    public function complete(int $companyId, int $decisionId, array $result, ?CouncilRiskAssessment $postRisk = null): bool
    {
        return CouncilDecisionRecord::query()
            ->where('company_id', $companyId)
            ->where('id', $decisionId)
            ->update([
                'status' => (string) ($result['status'] ?? 'completed'),
                'actual_participant_count' => max(0, (int) ($result['actual_participant_count'] ?? 0)),
                'confidence_percent' => isset($result['confidence_percent']) ? max(0, min(100, (int) $result['confidence_percent'])) : null,
                'agreement_percent' => isset($result['agreement_percent']) ? max(0, min(100, (int) $result['agreement_percent'])) : null,
                'strong_contradiction' => (bool) ($result['strong_contradiction'] ?? false),
                'requires_escalation' => (bool) ($result['requires_escalation'] ?? false) || ($postRisk?->requiresEscalation ?? false),
                'pre_arbiter_validation_status' => $this->validationStatus($result['pre_arbiter_shield'] ?? null),
                'final_validation_status' => $this->validationStatus($result['final_shield'] ?? null),
                'validation_source' => $this->validationSource($result),
                'postflight_risk_level' => $postRisk?->level,
                'postflight_risk_score' => $postRisk?->score,
                'postflight_risk_decision' => $postRisk?->decision,
                'postflight_risk_payload' => $postRisk?->toArray(),
                'payload' => $result,
                'updated_at' => now(),
            ]) > 0;
    }

    private function validationStatus(mixed $payload): ?string
    {
        if (! is_array($payload)) {
            return null;
        }
        if (($payload['blocked'] ?? false) === true) {
            return 'blocked';
        }
        if (($payload['passed'] ?? false) === true) {
            return 'passed';
        }
        return 'unknown';
    }

    /** @param array<string,mixed> $result */
    private function validationSource(array $result): ?string
    {
        foreach (['final_shield', 'pre_arbiter_shield'] as $key) {
            if (is_array($result[$key] ?? null) && isset($result[$key]['source'])) {
                return (string) $result[$key]['source'];
            }
        }
        return null;
    }

    public function findForTenant(int $companyId, int $decisionId): ?object
    {
        return CouncilDecisionRecord::query()
            ->where('company_id', $companyId)
            ->where('id', $decisionId)
            ->first();
    }
}
