<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\ValueObjects;

use InvalidArgumentException;

final readonly class CouncilRequest
{
    /** @param array<string,mixed> $metadata */
    public function __construct(
        public string $prompt,
        public int $companyId,
        public int $userId,
        public ?string $manualStrategy = null,
        public string $riskLevel = 'unknown',
        public array $metadata = [],
        public ?string $traceId = null,
        public ?string $correlationId = null,
        public ?string $causationId = null,
        public ?string $rootCausationId = null,
    ) {
        if (trim($this->prompt) === '') {
            throw new InvalidArgumentException('Council prompt cannot be empty.');
        }
        if ($this->companyId < 1) {
            throw new InvalidArgumentException('company_id must be a positive integer.');
        }
        if ($this->userId < 1) {
            throw new InvalidArgumentException('user_id must be a positive integer.');
        }
    }

    /** @param array<string,mixed> $input */
    public static function fromArray(array $input): self
    {
        return new self(
            prompt: trim((string) ($input['prompt'] ?? '')),
            companyId: (int) ($input['company_id'] ?? 0),
            userId: (int) ($input['user_id'] ?? 0),
            manualStrategy: self::nullableString($input['manual_strategy'] ?? null),
            riskLevel: strtolower(trim((string) ($input['risk_level'] ?? 'unknown'))) ?: 'unknown',
            metadata: is_array($input['metadata'] ?? null) ? $input['metadata'] : [],
            traceId: self::nullableString($input['trace_id'] ?? null),
            correlationId: self::nullableString($input['correlation_id'] ?? null),
            causationId: self::nullableString($input['causation_id'] ?? null),
            rootCausationId: self::nullableString($input['root_causation_id'] ?? null),
        );
    }

    private static function nullableString(mixed $value): ?string
    {
        if (! is_string($value)) {
            return null;
        }
        $value = trim($value);
        return $value === '' ? null : $value;
    }
}
