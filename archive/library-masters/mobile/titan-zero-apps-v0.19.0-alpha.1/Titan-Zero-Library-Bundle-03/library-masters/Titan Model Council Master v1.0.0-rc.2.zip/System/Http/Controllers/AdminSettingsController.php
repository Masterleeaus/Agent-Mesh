<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class AdminSettingsController
{
    public function __construct(private readonly ModelCouncilSettingsRepository $settings)
    {
    }

    public function index(): View
    {
        return view('titan-model-council::admin.settings', [
            'settings' => $this->settings->current(),
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'enabled' => ['nullable', 'boolean'],
            'max_models' => ['required', 'integer', 'min:2', 'max:5'],
            'preferred_synthesis_model' => ['nullable', 'string', 'max:191'],
            'selective_activation_enabled' => ['nullable', 'boolean'],
            'governed_deliberation_enabled' => ['nullable', 'boolean'],
            'minimum_distinct_models' => ['required', 'integer', 'min:2', 'max:4'],
            'risk_engine_enabled' => ['nullable', 'boolean'],
            'shield_enabled' => ['nullable', 'boolean'],
            'assurance_enabled' => ['nullable', 'boolean'],
            'contradiction_enabled' => ['nullable', 'boolean'],
            'contradiction_confidence_ceiling' => ['required', 'integer', 'min:1', 'max:99'],
            'adaptive_quorum_enabled' => ['nullable', 'boolean'],
            'minimum_successful_participants' => ['required', 'integer', 'min:2', 'max:5'],
            'minimum_agreement_percent' => ['required', 'integer', 'min:50', 'max:100'],
            'provider_timeout_seconds' => ['required', 'integer', 'min:10', 'max:300'],
            'provider_circuit_breaker_enabled' => ['nullable', 'boolean'],
            'provider_failure_threshold' => ['required', 'integer', 'min:1', 'max:10'],
            'provider_cooldown_seconds' => ['required', 'integer', 'min:10', 'max:3600'],
            'billing_reservation_required' => ['nullable', 'boolean'],
            'max_reserved_credits_per_participant' => ['required', 'integer', 'min:1', 'max:1000000'],
        ]);

        foreach ([
            'enabled', 'selective_activation_enabled', 'governed_deliberation_enabled',
            'risk_engine_enabled', 'shield_enabled', 'assurance_enabled', 'contradiction_enabled',
            'adaptive_quorum_enabled', 'provider_circuit_breaker_enabled', 'billing_reservation_required',
        ] as $booleanField) {
            $validated[$booleanField] = $request->boolean($booleanField);
        }
        $validated['preferred_synthesis_model'] = trim((string) ($validated['preferred_synthesis_model'] ?? ''));

        $actorId = $request->user()?->getAuthIdentifier();
        $this->settings->save($validated, is_numeric($actorId) ? (int) $actorId : null);

        return back()->with('success', 'Model Council settings saved. Runtime policy has been refreshed.');
    }

    public function reset(Request $request): RedirectResponse
    {
        $actorId = $request->user()?->getAuthIdentifier();
        $this->settings->reset(is_numeric($actorId) ? (int) $actorId : null);
        return back()->with('success', 'Model Council settings reset to extension defaults.');
    }
}
