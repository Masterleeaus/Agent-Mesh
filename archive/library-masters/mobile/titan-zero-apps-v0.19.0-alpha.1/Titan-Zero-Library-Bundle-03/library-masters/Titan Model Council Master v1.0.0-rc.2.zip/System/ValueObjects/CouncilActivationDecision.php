<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\ValueObjects;

final readonly class CouncilActivationDecision
{
    /** @param array<string,mixed> $triggerMetadata */
    public function __construct(
        public string $strategy,
        public string $activationReason,
        public array $triggerMetadata = [],
        public int $requestedParticipants = 1,
    ) {
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'strategy' => $this->strategy,
            'activation_reason' => $this->activationReason,
            'trigger_metadata' => $this->triggerMetadata,
            'requested_participant_count' => $this->requestedParticipants,
        ];
    }
}
