<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Navigation;

final class ModelCouncilNavigation
{
    /** @return list<array<string,mixed>> */
    public function userItems(): array
    {
        return [[
            'parent_key' => null,
            'key' => 'titan_model_council',
            'route' => 'dashboard.user.titan.model.council.index',
            'route_slug' => null,
            'label' => 'Model Council',
            'icon' => 'tabler-users-group',
            'svg' => null,
            'order' => 125,
            'priority' => 125,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'active_condition' => ['dashboard.user.titan.model.council.*'],
            'show_condition' => true,
            'is_admin' => false,
            'data-name' => 'titan_model_council',
            'read_only' => false,
        ]];
    }

    /** @return list<array<string,mixed>> */
    public function adminItems(): array
    {
        $parentKey = 'titan_model_council_admin';
        $base = [
            'svg' => null,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'show_condition' => true,
            'is_admin' => true,
            'read_only' => false,
        ];

        return [
            array_merge($base, [
                'parent_key' => null,
                'key' => $parentKey,
                'route' => 'dashboard.admin.titan.model.council.index',
                'route_slug' => null,
                'label' => 'Model Council',
                'icon' => 'tabler-users-group',
                'order' => 994,
                'priority' => 994,
                'active_condition' => ['dashboard.admin.titan.model.council.*'],
                'data-name' => $parentKey,
            ]),
            $this->adminChild($parentKey, 'titan_model_council_admin_overview', 'Overview', 'dashboard.admin.titan.model.council.index', 'tabler-layout-dashboard', 1),
            $this->adminChild($parentKey, 'titan_model_council_admin_settings', 'Settings', 'dashboard.admin.titan.model.council.settings', 'tabler-settings', 2),
            $this->adminChild($parentKey, 'titan_model_council_admin_strategies', 'Strategies & Activation', 'dashboard.admin.titan.model.council.strategies', 'tabler-route-alt-left', 3),
            $this->adminChild($parentKey, 'titan_model_council_admin_providers', 'Providers & Models', 'dashboard.admin.titan.model.council.providers', 'tabler-cpu', 4),
            $this->adminChild($parentKey, 'titan_model_council_admin_integrations', 'Integrations', 'dashboard.admin.titan.model.council.integrations', 'tabler-plug-connected', 5),
            $this->adminChild($parentKey, 'titan_model_council_admin_billing', 'Billing & Limits', 'dashboard.admin.titan.model.council.billing', 'tabler-credit-card', 6),
            $this->adminChild($parentKey, 'titan_model_council_admin_diagnostics', 'Diagnostics & Audit', 'dashboard.admin.titan.model.council.diagnostics', 'tabler-activity-heartbeat', 7),
        ];
    }

    /** @return array<string,mixed> */
    private function adminChild(string $parentKey, string $key, string $label, string $route, string $icon, int $order): array
    {
        return [
            'parent_key' => $parentKey,
            'key' => $key,
            'route' => $route,
            'route_slug' => null,
            'label' => $label,
            'icon' => $icon,
            'svg' => null,
            'order' => $order,
            'priority' => $order,
            'is_active' => true,
            'params' => [],
            'type' => 'item',
            'badge' => null,
            'extension' => '1',
            'active_condition' => [$route],
            'show_condition' => true,
            'is_admin' => true,
            'data-name' => $key,
            'read_only' => false,
        ];
    }
}
