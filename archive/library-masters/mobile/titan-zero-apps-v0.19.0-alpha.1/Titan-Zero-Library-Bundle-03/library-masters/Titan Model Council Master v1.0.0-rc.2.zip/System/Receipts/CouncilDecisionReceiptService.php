<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Receipts;

use App\Extensions\TitanModelCouncil\System\Models\CouncilReceiptRecord;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Support\Str;
use JsonException;

/**
 * Creates a bounded, hash-addressed Council decision receipt suitable for
 * Rewind ingestion. It stores summaries and output hashes, never hidden
 * chain-of-thought or provider credentials.
 */
final class CouncilDecisionReceiptService
{
    /** @param array<string,mixed> $result @param array<string,mixed> $billing @return array<string,mixed> */
    public function record(CouncilRequest $request, int $decisionId, array $result, array $billing = []): array
    {
        $existing = CouncilReceiptRecord::query()
            ->where('company_id', $request->companyId)
            ->where('decision_id', $decisionId)
            ->first();
        if ($existing) {
            return $this->recordArray($existing);
        }

        $traceId = $this->uuidOrNew($request->traceId);
        $correlationId = $this->uuidOrFallback($request->correlationId, $traceId);
        $causationId = $this->uuidOrFallback($request->causationId, $correlationId);
        $rootCausationId = $this->uuidOrFallback($request->rootCausationId, $causationId);
        $receiptId = (string) Str::uuid();
        $payload = [
            'receipt_version' => '1.0',
            'receipt_id' => $receiptId,
            'decision_id' => $decisionId,
            'company_id' => $request->companyId,
            'company_id' => $request->companyId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $rootCausationId,
            'strategy' => (string) ($result['strategy'] ?? ($result['activation']['strategy'] ?? 'governed_deliberation')),
            'status' => (string) ($result['status'] ?? 'completed'),
            'execution_authority' => (string) ($result['execution_authority'] ?? 'advisory_only'),
            'requires_escalation' => (bool) ($result['requires_escalation'] ?? false),
            'confidence_percent' => $result['confidence_percent'] ?? null,
            'agreement_percent' => $result['agreement_percent'] ?? null,
            'preflight_risk' => $this->riskSummary((array) ($result['preflight_risk'] ?? [])),
            'postflight_risk' => $this->riskSummary((array) ($result['postflight_risk'] ?? [])),
            'assurance' => $this->assuranceSummary((array) ($result['assurance'] ?? [])),
            'shield' => [
                'pre_arbiter' => $this->validationSummary((array) ($result['pre_arbiter_shield'] ?? [])),
                'final' => $this->validationSummary((array) ($result['final_shield'] ?? [])),
            ],
            'billing' => [
                'reservation_id' => $billing['reservation_id'] ?? null,
                'reserved_credits' => $billing['reserved_credits'] ?? null,
                'settled_credits' => $billing['settled_credits'] ?? null,
                'released_credits' => $billing['released_credits'] ?? null,
                'status' => $billing['status'] ?? null,
            ],
            'participants' => $this->participantSummaries((array) ($result['participants'] ?? [])),
            'advisory_only' => true,
        ];
        $canonical = $this->canonicalize($payload);
        try {
            $json = json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        } catch (JsonException $e) {
            throw new JsonException('Council receipt cannot be canonicalized.', previous: $e);
        }
        $receiptHash = hash('sha256', $json);

        $record = CouncilReceiptRecord::query()->create([
            'receipt_id' => $receiptId,
            'company_id' => $request->companyId,
            'company_id' => $request->companyId,
            'decision_id' => $decisionId,
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $rootCausationId,
            'status' => (string) $payload['status'],
            'strategy' => (string) $payload['strategy'],
            'execution_authority' => (string) $payload['execution_authority'],
            'requires_escalation' => (bool) $payload['requires_escalation'],
            'receipt_hash' => $receiptHash,
            'receipt_payload' => $canonical,
            'recorded_at' => now(),
        ]);

        return $this->recordArray($record);
    }

    /** @return array<string,mixed> */
    private function recordArray(CouncilReceiptRecord $record): array
    {
        return [
            'receipt_id' => (string) $record->receipt_id,
            'decision_id' => (int) $record->decision_id,
            'receipt_hash' => (string) $record->receipt_hash,
            'status' => (string) $record->status,
            'strategy' => (string) $record->strategy,
            'execution_authority' => (string) $record->execution_authority,
            'requires_escalation' => (bool) $record->requires_escalation,
            'root_causation_id' => (string) $record->root_causation_id,
            'advisory_only' => true,
        ];
    }

    /** @param array<string,mixed> $participants @return array<string,array<string,mixed>> */
    private function participantSummaries(array $participants): array
    {
        $out = [];
        foreach ($participants as $role => $participant) {
            if (! is_array($participant)) continue;
            $text = trim((string) ($participant['response_text'] ?? ''));
            $out[(string) $role] = [
                'model_slug' => (string) ($participant['model_slug'] ?? ''),
                'success' => (bool) ($participant['success'] ?? false),
                'confidence_percent' => $participant['confidence_percent'] ?? null,
                'response_time_ms' => $participant['response_time_ms'] ?? null,
                'credits' => $participant['credits'] ?? 0,
                'output_sha256' => $text !== '' ? hash('sha256', $text) : null,
                'failure_reason' => $participant['failure_reason'] ?? null,
            ];
        }
        return $out;
    }

    /** @param array<string,mixed> $risk @return array<string,mixed> */
    private function riskSummary(array $risk): array
    {
        return array_intersect_key($risk, array_flip(['available', 'level', 'score', 'decision', 'requires_escalation', 'policy_version', 'reason_codes']));
    }

    /** @param array<string,mixed> $assurance @return array<string,mixed> */
    private function assuranceSummary(array $assurance): array
    {
        return array_intersect_key($assurance, array_flip(['available', 'evaluated', 'required', 'assessment_id', 'assessment_uuid', 'assurance-band', 'score', 'reason_codes', 'policy_version', 'requires_escalation']));
    }

    /** @param array<string,mixed> $validation @return array<string,mixed> */
    private function validationSummary(array $validation): array
    {
        return array_intersect_key($validation, array_flip(['passed', 'blocked', 'source', 'reason_codes']));
    }

    private function uuidOrNew(?string $value): string
    {
        return is_string($value) && Str::isUuid($value) ? $value : (string) Str::uuid();
    }

    private function uuidOrFallback(?string $value, string $fallback): string
    {
        return is_string($value) && Str::isUuid($value) ? $value : $fallback;
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) return $value;
        if (array_is_list($value)) return array_map(fn (mixed $item): mixed => $this->canonicalize($item), $value);
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }
}
