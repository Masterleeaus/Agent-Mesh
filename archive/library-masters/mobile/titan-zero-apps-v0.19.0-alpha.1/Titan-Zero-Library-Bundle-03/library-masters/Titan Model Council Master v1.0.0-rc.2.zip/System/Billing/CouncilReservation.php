<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Billing;

use InvalidArgumentException;
use LogicException;

final readonly class CouncilReservation
{
    private function __construct(
        public string $reservationId,
        public int $companyId,
        public int $userId,
        public int $reservedCredits,
        public int $settledCredits,
        public int $releasedCredits,
        public string $status,
        public ?string $releaseReason = null,
    ) {
    }

    public static function reserve(string $reservationId, int $companyId, int $userId, int $credits): self
    {
        if ($reservationId === '' || $companyId < 1 || $userId < 1 || $credits < 1) {
            throw new InvalidArgumentException('Invalid council reservation.');
        }
        return new self($reservationId, $companyId, $userId, $credits, 0, 0, 'reserved');
    }

    public function settle(int $actualCredits): self
    {
        if ($this->status !== 'reserved') {
            throw new LogicException('Only reserved Council credits may be settled.');
        }
        if ($actualCredits < 0 || $actualCredits > $this->reservedCredits) {
            throw new InvalidArgumentException('Actual Council credits cannot exceed the reservation.');
        }
        return new self(
            $this->reservationId,
            $this->companyId,
            $this->userId,
            $this->reservedCredits,
            $actualCredits,
            $this->reservedCredits - $actualCredits,
            'settled',
            null,
        );
    }

    public function release(string $reason): self
    {
        if ($this->status !== 'reserved') {
            throw new LogicException('Only reserved Council credits may be released.');
        }
        return new self(
            $this->reservationId,
            $this->companyId,
            $this->userId,
            $this->reservedCredits,
            0,
            $this->reservedCredits,
            'released',
            trim($reason) === '' ? 'released' : trim($reason),
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'reservation_id' => $this->reservationId,
            'company_id' => $this->companyId,
            'company_id' => $this->companyId,
            'user_id' => $this->userId,
            'reserved_credits' => $this->reservedCredits,
            'settled_credits' => $this->settledCredits,
            'released_credits' => $this->releasedCredits,
            'remaining_credits' => $this->remainingCredits(),
            'status' => $this->status,
            'release_reason' => $this->releaseReason,
        ];
    }

    public function remainingCredits(): int
    {
        return max(0, $this->reservedCredits - $this->settledCredits - $this->releasedCredits);
    }
}
