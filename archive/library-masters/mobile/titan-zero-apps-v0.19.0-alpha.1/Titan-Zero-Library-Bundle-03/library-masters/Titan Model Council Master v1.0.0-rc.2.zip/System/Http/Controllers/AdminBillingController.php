<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Models\CouncilBillingReservationRecord;
use App\Extensions\TitanModelCouncil\System\Settings\ModelCouncilSettingsRepository;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Schema;

final class AdminBillingController
{
    public function __construct(private readonly ModelCouncilSettingsRepository $settings)
    {
    }

    public function __invoke(): View
    {
        $recent = collect();
        if (Schema::hasTable('titan_model_council_billing_reservations')) {
            $recent = CouncilBillingReservationRecord::query()->latest('id')->limit(20)->get();
        }

        return view('titan-model-council::admin.billing', [
            'settings' => $this->settings->current(),
            'billing' => (array) config('titan-model-council.billing', []),
            'recentReservations' => $recent,
        ]);
    }
}
