<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

interface GovernedProviderRuntimeContract
{
    /** @param array<int,string> $modelSlugs @return array{allowed:bool,reasons:array<int,string>} */
    public function preflight(int $userId, array $modelSlugs): array;

    /** @param array<int,array{role:string,content:string}> $messages @return array<string,mixed> */
    public function execute(int $userId, string $modelSlug, array $messages): array;

    public function charge(int $userId, string $modelSlug, string $responseText): int;
}
