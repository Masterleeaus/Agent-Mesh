<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Company;

use App\Models\User;
use Illuminate\Http\Request;

final class CompanyContextResolver
{
    public function __construct(private readonly CompanyIdResolver $ids = new CompanyIdResolver())
    {
    }

    /** @param array<string,mixed> $context */
    public function resolve(Request $request, ?User $user = null, array $context = []): ?CompanyContext
    {
        $attributeValue = $request->attributes->get('company_id');
        $userValue = null;
        if ($user && method_exists($user, 'getAttribute')) {
            $userValue = $user->getAttribute('company_id');
        }
        $id = $this->ids->resolve(
            ['company_id' => $attributeValue],
            $context,
            ['company_id' => $userValue],
        );
        return $id ? new CompanyContext($id) : null;
    }
}
