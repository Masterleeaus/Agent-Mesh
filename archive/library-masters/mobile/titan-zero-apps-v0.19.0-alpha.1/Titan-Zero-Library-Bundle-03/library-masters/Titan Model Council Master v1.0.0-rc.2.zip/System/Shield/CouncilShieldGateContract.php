<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

interface CouncilShieldGateContract
{
    /** @param array<string,array<string,mixed>> $artifacts */
    public function validate(string $stage, CouncilRequest $request, array $artifacts): ShieldValidationResult;

    /** @return array<string,mixed> */
    public function status(): array;
}
