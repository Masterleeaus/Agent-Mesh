<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Quality;

final class ContradictionResolver
{
    public function __construct(private readonly int $confidenceCeiling = 50)
    {
    }

    /** @param array<string,mixed> $synthesis @return array<string,mixed> */
    public function apply(array $synthesis, bool $consequential): array
    {
        $disagreements = array_values(array_filter(array_map('strval', (array) ($synthesis['disagreements'] ?? []))));
        $strong = $this->containsMutuallyExclusiveClaims($disagreements);
        $synthesis['strong_contradiction'] = $strong;
        $synthesis['requires_escalation'] = $strong && $consequential;

        if (! $strong) {
            return $synthesis;
        }

        $ceiling = max(1, min(99, $this->confidenceCeiling));
        $synthesis['confidence_percent'] = min((int) ($synthesis['confidence_percent'] ?? 0), $ceiling - 1);
        $caveat = 'Models strongly disagree—independent verification is required before relying on this conclusion.';
        if ($consequential) {
            $caveat .= ' Escalate to an authorised human/manager before consequential execution.';
        }
        $answer = trim((string) ($synthesis['final_answer'] ?? ''));
        if (! str_contains($answer, 'Models strongly disagree')) {
            $synthesis['final_answer'] = trim($answer . "\n\n" . $caveat);
        }
        return $synthesis;
    }


    /** @param array<int,array<string,mixed>> $modelResults */
    public function detectInModelResults(array $modelResults): bool
    {
        $claims = [];
        foreach ($modelResults as $row) {
            if (($row['failed'] ?? true) || trim((string) ($row['response_text'] ?? '')) === '') {
                continue;
            }
            $claims[] = (string) $row['response_text'];
        }
        return $this->containsMutuallyExclusiveClaims($claims);
    }

    /** @param array<int,string> $items */
    private function containsMutuallyExclusiveClaims(array $items): bool
    {
        if (count($items) < 2) {
            return false;
        }

        $hasPositive = false;
        $hasNegative = false;
        foreach ($items as $item) {
            $text = strtolower(trim($item));
            if ($text === '') {
                continue;
            }
            $negative = preg_match('/\b(no|not permitted|not allowed|invalid|false|should not|cannot|can\'t|must not|mustn\'t|do not|don\'t)\b/i', $text) === 1;
            $positive = preg_match('/\b(yes|permitted|allowed|valid|true|should|can|must|proceed)\b/i', $text) === 1;

            if ($negative) {
                $hasNegative = true;
                continue;
            }
            if ($positive) {
                $hasPositive = true;
            }
        }

        return $hasPositive && $hasNegative;
    }
}
