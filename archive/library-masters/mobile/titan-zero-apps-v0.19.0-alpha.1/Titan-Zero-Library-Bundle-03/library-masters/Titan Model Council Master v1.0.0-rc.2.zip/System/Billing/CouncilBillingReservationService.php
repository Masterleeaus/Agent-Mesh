<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Billing;

use App\Extensions\TitanModelCouncil\System\Models\CouncilBillingReservationRecord;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

final class CouncilBillingReservationService
{
    /**
     * Council-local reservation ledger. This prevents the Council from dispatching
     * without an auditable maximum exposure record. Provider/account hard holds are
     * delegated to Titan AI Core once its billing gateway becomes the runtime owner.
     *
     * @param array<int,string> $modelSlugs
     */
    public function reserve(int $companyId, int $userId, array $modelSlugs, ?string $synthesisModelSlug, ?string $traceId = null): CouncilReservation
    {
        $participantMax = max(1, (int) config('titan-model-council.billing.max_reserved_credits_per_participant', 5000));
        $components = [];
        foreach (array_values(array_unique(array_filter(array_map('strval', $modelSlugs)))) as $slug) {
            $components['participant:' . $slug] = $participantMax;
        }
        if ($synthesisModelSlug) {
            $components['synthesis:' . $synthesisModelSlug] = $participantMax;
        }
        $max = array_sum($components);
        if ($max < 1) {
            throw new InvalidArgumentException('Cannot reserve an empty Council execution.');
        }

        $reservation = CouncilReservation::reserve((string) Str::uuid(), $companyId, $userId, $max);
        CouncilBillingReservationRecord::query()->create([
            'reservation_id' => $reservation->reservationId,
            'company_id' => $companyId,
            'company_id' => $companyId,
            'user_id' => $userId,
            'trace_id' => $traceId,
            'status' => 'reserved',
            'reserved_credits' => $max,
            'settled_credits' => 0,
            'released_credits' => 0,
            'reserved_components' => $components,
            'settled_components' => null,
            'reserved_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $reservation;
    }

    /** @param array<string,string> $roleModels */
    public function reserveGoverned(int $companyId, int $userId, array $roleModels, ?string $traceId = null): CouncilReservation
    {
        $participantMax = max(1, (int) config('titan-model-council.billing.max_reserved_credits_per_participant', 5000));
        $components = [];
        foreach ($roleModels as $role => $slug) {
            $role = trim((string) $role);
            $slug = trim((string) $slug);
            if ($role === '' || $slug === '') {
                continue;
            }
            $components['role:' . $role . ':' . $slug] = $participantMax;
        }
        $max = array_sum($components);
        if ($max < 1) {
            throw new InvalidArgumentException('Cannot reserve an empty governed Council execution.');
        }

        $reservation = CouncilReservation::reserve((string) Str::uuid(), $companyId, $userId, $max);
        CouncilBillingReservationRecord::query()->create([
            'reservation_id' => $reservation->reservationId,
            'company_id' => $companyId,
            'company_id' => $companyId,
            'user_id' => $userId,
            'trace_id' => $traceId,
            'status' => 'reserved',
            'reserved_credits' => $max,
            'settled_credits' => 0,
            'released_credits' => 0,
            'reserved_components' => $components,
            'settled_components' => null,
            'reserved_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $reservation;
    }

    /** @param array<string,int> $actualComponents */
    public function settle(string $reservationId, int $companyId, int $userId, array $actualComponents): CouncilReservation
    {
        return DB::transaction(function () use ($reservationId, $companyId, $userId, $actualComponents): CouncilReservation {
            $row = CouncilBillingReservationRecord::query()
                ->where('reservation_id', $reservationId)
                ->where('company_id', $companyId)
                ->where('user_id', $userId)
                ->lockForUpdate()
                ->first();
            if (! $row || $row->status !== 'reserved') {
                throw new RuntimeException('Council billing reservation is missing or no longer open.');
            }
            $actual = array_sum(array_map(static fn ($v): int => max(0, (int) $v), $actualComponents));
            $reservation = CouncilReservation::reserve($reservationId, $companyId, $userId, (int) $row->reserved_credits)->settle($actual);
            $row->fill([
                'status' => 'settled',
                'settled_credits' => $reservation->settledCredits,
                'released_credits' => $reservation->releasedCredits,
                'settled_components' => $actualComponents,
                'settled_at' => now(),
            ]);
            $row->save();
            return $reservation;
        });
    }

    public function release(string $reservationId, int $companyId, int $userId, string $reason): CouncilReservation
    {
        return DB::transaction(function () use ($reservationId, $companyId, $userId, $reason): CouncilReservation {
            $row = CouncilBillingReservationRecord::query()
                ->where('reservation_id', $reservationId)
                ->where('company_id', $companyId)
                ->where('user_id', $userId)
                ->lockForUpdate()
                ->first();
            if (! $row || $row->status !== 'reserved') {
                throw new RuntimeException('Council billing reservation is missing or no longer open.');
            }
            $reservation = CouncilReservation::reserve($reservationId, $companyId, $userId, (int) $row->reserved_credits)->release($reason);
            $row->fill([
                'status' => 'released',
                'released_credits' => $reservation->releasedCredits,
                'release_reason' => $reservation->releaseReason,
                'released_at' => now(),
            ]);
            $row->save();
            return $reservation;
        });
    }
}
