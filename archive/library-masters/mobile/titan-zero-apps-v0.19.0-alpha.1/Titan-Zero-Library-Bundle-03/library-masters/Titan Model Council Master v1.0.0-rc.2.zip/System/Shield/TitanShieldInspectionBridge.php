<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Str;
use Throwable;

/**
 * Records Model Council structural validation through Titan Shield when the
 * peer runtime is available. Shield v0.5+ is preferred; the older
 * InspectionEngineContract is retained as a compatibility fallback.
 */
final class TitanShieldInspectionBridge
{
    private const CURRENT_MANAGER = 'App\\Extensions\\TitanShield\\System\\Contracts\\ShieldManagerContract';
    private const CURRENT_CONTEXT = 'App\\Extensions\\TitanShield\\System\\Context\\ShieldExecutionContext';

    // Legacy Shield v0.2-v0.4 inspection contract fallback.
    private const LEGACY_ENGINE = 'App\\Extensions\\TitanShield\\System\\Contracts\\InspectionEngineContract';
    private const LEGACY_DEFINITION = 'App\\Extensions\\TitanShield\\System\\Domain\\Inspections\\InspectionDefinition';
    private const LEGACY_TRACE = 'App\\Extensions\\TitanShield\\System\\Domain\\Shared\\TraceContext';
    private const LEGACY_OUTCOME = 'App\\Extensions\\TitanShield\\System\\Domain\\Inspections\\VerificationOutcome';
    private const LEGACY_RATIONALE = 'App\\Extensions\\TitanShield\\System\\Domain\\Shared\\StructuredRationale';

    public function __construct(private readonly Container $app)
    {
    }

    public function available(): bool
    {
        return $this->currentAvailable() || $this->legacyAvailable();
    }

    /** @return array<string,mixed> */
    public function record(string $stage, CouncilRequest $request, ShieldValidationResult $validation): array
    {
        if ($this->currentAvailable()) {
            return $this->recordCurrent($stage, $request, $validation);
        }
        if ($this->legacyAvailable()) {
            return $this->recordLegacy($stage, $request, $validation);
        }

        return ['available' => false, 'recorded' => false, 'reason' => 'titan-shield-inspection-contract-unavailable'];
    }

    /** @return array<string,mixed> */
    private function recordCurrent(string $stage, CouncilRequest $request, ShieldValidationResult $validation): array
    {
        try {
            $manager = $this->app->make(self::CURRENT_MANAGER);
            $contextClass = self::CURRENT_CONTEXT;
            $traceId = $this->uuidOrNew($request->traceId);
            $correlationId = $this->uuidOrFallback($request->correlationId, $traceId);
            $causationId = $this->uuidOrFallback($request->causationId, $correlationId);
            $rootCausationId = $this->uuidOrFallback($request->rootCausationId, $causationId);
            $context = new $contextClass(
                $request->companyId,
                $traceId,
                $correlationId,
                $causationId,
                $request->userId,
                'titan-model-council',
                $rootCausationId,
            );

            $definition = $this->currentDefinition($stage);
            $facts = [
                'checklists' => [
                    'council_stage' => [
                        'local_validation_passed' => $validation->passed === true,
                        'local_validation_not_blocked' => $validation->blocked === false,
                    ],
                ],
            ];

            $inspection = $manager->evaluateInspection(
                (string) Str::uuid(),
                $definition,
                'titan_model_council_decision',
                $traceId . ':' . $stage,
                $facts,
                $context,
            );

            return [
                'available' => true,
                'recorded' => true,
                'contract' => 'ShieldManagerContract',
                'inspection' => is_array($inspection) ? $inspection : [],
            ];
        } catch (Throwable $e) {
            return [
                'available' => true,
                'recorded' => false,
                'contract' => 'ShieldManagerContract',
                'reason' => 'titan-shield-v05-inspection-record-failed',
                'exception' => $e::class,
            ];
        }
    }

    /** @return array<string,mixed> */
    private function currentDefinition(string $stage): array
    {
        $safeStage = in_array($stage, ['pre_arbiter', 'final'], true) ? $stage : 'validation';

        return [
            'definition_key' => 'titan_model_council.' . $safeStage,
            'version' => '1.0.0',
            'name' => 'Titan Model Council ' . str_replace('_', ' ', $safeStage) . ' structural validation',
            'description' => 'Deterministic structural gate for Model Council governed deliberation. It does not claim external factual verification.',
            'vertical_key' => 'titan-model-council',
            'inspection_type' => 'model_deliberation',
            'scope' => 'tenant',
            'status' => 'active',
            'rules' => [[
                'rule_key' => 'council.' . $safeStage . '.structural',
                'rule_type' => 'checklist_all',
                'parameters' => ['checklist_key' => 'council_stage'],
                'required' => true,
                'failure_severity' => 'high',
                'knowledge_reference' => null,
            ]],
            'evidence_requirements' => [],
            'pass_policy' => ['required_rules' => 'all'],
            'conditional_pass_policy' => ['allowed' => false],
            'review_policy' => ['required_on_failure' => true],
            'remediation_policy' => ['automatic' => false],
            'knowledge_references' => [],
            'source_pack' => 'titan-model-council/governed-deliberation',
            'effective_from' => '2026-08-19T00:00:00+00:00',
            'supersedes_version' => null,
        ];
    }

    /** @return array<string,mixed> */
    private function recordLegacy(string $stage, CouncilRequest $request, ShieldValidationResult $validation): array
    {
        try {
            $definitionClass = self::LEGACY_DEFINITION;
            $traceClass = self::LEGACY_TRACE;
            $outcomeClass = self::LEGACY_OUTCOME;
            $rationaleClass = self::LEGACY_RATIONALE;

            $requirements = $stage === 'pre_arbiter'
                ? ['council.proposer.present', 'council.critic.present', 'council.verifier.present']
                : ['council.arbiter.present', 'council.final.nonempty'];

            $definition = new $definitionClass(
                'model_council.' . $stage,
                '1.0.0',
                'Titan Model Council ' . str_replace('_', ' ', $stage) . ' validation',
                $requirements,
                false,
            );

            $traceId = $this->uuidOrNew($request->traceId);
            $correlationId = $this->uuidOrFallback($request->correlationId, $traceId);
            $causationId = $this->uuidOrFallback($request->causationId, $correlationId);
            $trace = new $traceClass($request->companyId, $traceId, $correlationId, $causationId);

            $engine = $this->app->make(self::LEGACY_ENGINE);
            $run = $engine->createRun((string) Str::uuid(), $definition, 'titan_model_council', $traceId . ':' . $stage, $trace);
            $run = $engine->start($run);
            $run = $engine->submitForVerification($run);

            $outcome = $validation->passed && ! $validation->blocked ? $outcomeClass::Pass : $outcomeClass::Fail;
            $summary = $validation->passed
                ? 'Council structural validation passed for stage ' . $stage . '.'
                : 'Council structural validation blocked stage ' . $stage . '.';
            $rationale = new $rationaleClass($summary, $validation->reasonCodes, $requirements, [], null);
            $run = $engine->recordVerification($run, $outcome, $rationale);

            return [
                'available' => true,
                'recorded' => true,
                'contract' => 'InspectionEngineContract',
                'inspection' => $run->toArray(),
            ];
        } catch (Throwable $e) {
            return [
                'available' => true,
                'recorded' => false,
                'contract' => 'InspectionEngineContract',
                'reason' => 'titan-shield-legacy-inspection-record-failed',
                'exception' => $e::class,
            ];
        }
    }

    private function currentAvailable(): bool
    {
        return interface_exists(self::CURRENT_MANAGER)
            && class_exists(self::CURRENT_CONTEXT)
            && $this->app->bound(self::CURRENT_MANAGER);
    }

    private function legacyAvailable(): bool
    {
        return interface_exists(self::LEGACY_ENGINE)
            && $this->app->bound(self::LEGACY_ENGINE)
            && class_exists(self::LEGACY_DEFINITION)
            && class_exists(self::LEGACY_TRACE)
            && enum_exists(self::LEGACY_OUTCOME)
            && class_exists(self::LEGACY_RATIONALE);
    }

    private function uuidOrNew(?string $value): string
    {
        return $this->isUuid($value) ? (string) $value : (string) Str::uuid();
    }

    private function uuidOrFallback(?string $value, string $fallback): string
    {
        return $this->isUuid($value) ? (string) $value : $fallback;
    }

    private function isUuid(?string $value): bool
    {
        return is_string($value) && Str::isUuid($value);
    }
}
