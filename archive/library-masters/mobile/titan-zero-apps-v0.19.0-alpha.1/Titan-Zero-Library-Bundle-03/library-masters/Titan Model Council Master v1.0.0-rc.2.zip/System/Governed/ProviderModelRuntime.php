<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Governed;

use App\Extensions\TitanModelCouncil\System\Services\ModelCouncilExecutionService;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedProviderRuntimeContract;

final class ProviderModelRuntime implements GovernedProviderRuntimeContract
{
    public function __construct(private readonly ModelCouncilExecutionService $runtime)
    {
    }

    public function preflight(int $userId, array $modelSlugs): array
    {
        return $this->runtime->governedModelPreflight($userId, $modelSlugs);
    }

    public function execute(int $userId, string $modelSlug, array $messages): array
    {
        $result = $this->runtime->executeGovernedModel($userId, $modelSlug, $messages);
        $result['runtime'] = 'titan-model-council-provider';
        return $result;
    }

    public function charge(int $userId, string $modelSlug, string $responseText): int
    {
        return $this->runtime->chargeGovernedOutput($userId, $modelSlug, $responseText);
    }
}
