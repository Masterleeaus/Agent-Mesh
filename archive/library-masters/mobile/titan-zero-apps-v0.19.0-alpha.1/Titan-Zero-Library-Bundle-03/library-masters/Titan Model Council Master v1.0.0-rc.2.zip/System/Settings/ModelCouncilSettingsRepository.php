<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Settings;

use App\Extensions\TitanModelCouncil\System\Models\ModelCouncilSetting;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class ModelCouncilSettingsRepository
{
    /** @return array<string,mixed> */
    public function defaults(): array
    {
        return [
            'enabled' => (bool) config('titan-model-council.enabled', true),
            'max_models' => (int) (config('titan-model-council.runtime.max_models') ?? (function_exists('setting') ? setting('ai_chat_pro_council_max_models', 5) : 5)),
            'preferred_synthesis_model' => (string) (config('titan-model-council.runtime.synthesis_model') ?: (function_exists('setting') ? setting('ai_chat_pro_council_synthesis_model', '') : '')),
            'selective_activation_enabled' => (bool) config('titan-model-council.selective_activation.enabled', true),
            'governed_deliberation_enabled' => (bool) config('titan-model-council.governed_deliberation.enabled', true),
            'minimum_distinct_models' => (int) config('titan-model-council.governed_deliberation.minimum_distinct_models', 3),
            'risk_engine_enabled' => (bool) config('titan-model-council.risk_engine.enabled', true),
            'shield_enabled' => (bool) config('titan-model-council.shield.enabled', true),
            'assurance_enabled' => (bool) config('titan-model-council.assurance.enabled', true),
            'contradiction_enabled' => (bool) config('titan-model-council.contradiction.enabled', true),
            'contradiction_confidence_ceiling' => (int) config('titan-model-council.contradiction.confidence_ceiling', 50),
            'adaptive_quorum_enabled' => (bool) config('titan-model-council.adaptive_quorum.enabled', true),
            'minimum_successful_participants' => (int) config('titan-model-council.adaptive_quorum.minimum_successful_participants', 2),
            'minimum_agreement_percent' => (int) config('titan-model-council.adaptive_quorum.minimum_agreement_percent', 90),
            'provider_timeout_seconds' => (int) config('titan-model-council.adaptive_quorum.provider_timeout_seconds', 90),
            'provider_circuit_breaker_enabled' => (bool) config('titan-model-council.provider_circuit_breaker.enabled', true),
            'provider_failure_threshold' => (int) config('titan-model-council.provider_circuit_breaker.failure_threshold', 3),
            'provider_cooldown_seconds' => (int) config('titan-model-council.provider_circuit_breaker.cooldown_seconds', 60),
            'billing_reservation_required' => (bool) config('titan-model-council.billing.reservation_required', true),
            'max_reserved_credits_per_participant' => (int) config('titan-model-council.billing.max_reserved_credits_per_participant', 5000),
        ];
    }

    /** @return array<string,mixed> */
    public function current(): array
    {
        $defaults = $this->defaults();
        if (! $this->available()) {
            return $defaults;
        }

        $row = ModelCouncilSetting::query()->whereKey(1)->first();
        if ($row === null) {
            return $defaults;
        }

        $values = $row->only(array_keys($defaults));
        return array_replace($defaults, array_filter($values, static fn ($value): bool => $value !== null));
    }

    /** @param array<string,mixed> $values */
    public function save(array $values, ?int $actorId = null): array
    {
        if (! $this->available()) {
            throw new \RuntimeException('Model Council settings table is unavailable. Run extension migrations first.');
        }

        $allowed = array_keys($this->defaults());
        $payload = array_intersect_key($values, array_fill_keys($allowed, true));
        $payload['updated_by_user_id'] = $actorId;

        $row = ModelCouncilSetting::query()->firstOrNew(['id' => 1]);
        $row->forceFill($payload);
        $row->save();

        $this->applyRuntimeOverrides();
        return $this->current();
    }

    public function reset(?int $actorId = null): array
    {
        if ($this->available()) {
            ModelCouncilSetting::query()->whereKey(1)->delete();
        }
        $this->applyValues($this->defaults());
        return $this->defaults();
    }

    public function applyRuntimeOverrides(): void
    {
        if (! $this->available()) {
            return;
        }
        $row = ModelCouncilSetting::query()->whereKey(1)->first();
        if ($row === null) {
            return;
        }
        $this->applyValues($this->current());
    }

    /** @param array<string,mixed> $values */
    private function applyValues(array $values): void
    {
        config()->set([
            'titan-model-council.enabled' => (bool) $values['enabled'],
            'titan-model-council.runtime.max_models' => (int) $values['max_models'],
            'titan-model-council.runtime.synthesis_model' => (string) $values['preferred_synthesis_model'],
            'titan-model-council.selective_activation.enabled' => (bool) $values['selective_activation_enabled'],
            'titan-model-council.governed_deliberation.enabled' => (bool) $values['governed_deliberation_enabled'],
            'titan-model-council.selective_activation.governed_deliberation_enabled' => (bool) $values['governed_deliberation_enabled'],
            'titan-model-council.governed_deliberation.minimum_distinct_models' => (int) $values['minimum_distinct_models'],
            'titan-model-council.risk_engine.enabled' => (bool) $values['risk_engine_enabled'],
            'titan-model-council.shield.enabled' => (bool) $values['shield_enabled'],
            'titan-model-council.assurance.enabled' => (bool) $values['assurance_enabled'],
            'titan-model-council.contradiction.enabled' => (bool) $values['contradiction_enabled'],
            'titan-model-council.contradiction.confidence_ceiling' => (int) $values['contradiction_confidence_ceiling'],
            'titan-model-council.adaptive_quorum.enabled' => (bool) $values['adaptive_quorum_enabled'],
            'titan-model-council.adaptive_quorum.minimum_successful_participants' => (int) $values['minimum_successful_participants'],
            'titan-model-council.adaptive_quorum.minimum_agreement_percent' => (int) $values['minimum_agreement_percent'],
            'titan-model-council.adaptive_quorum.provider_timeout_seconds' => (int) $values['provider_timeout_seconds'],
            'titan-model-council.provider_circuit_breaker.enabled' => (bool) $values['provider_circuit_breaker_enabled'],
            'titan-model-council.provider_circuit_breaker.failure_threshold' => (int) $values['provider_failure_threshold'],
            'titan-model-council.provider_circuit_breaker.cooldown_seconds' => (int) $values['provider_cooldown_seconds'],
            'titan-model-council.billing.reservation_required' => (bool) $values['billing_reservation_required'],
            'titan-model-council.billing.max_reserved_credits_per_participant' => (int) $values['max_reserved_credits_per_participant'],
        ]);
    }

    private function available(): bool
    {
        try {
            return Schema::hasTable('titan_model_council_settings');
        } catch (Throwable) {
            return false;
        }
    }
}
