<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Risk;

use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

interface CouncilRiskGatewayContract
{
    public function assessBefore(CouncilRequest $request): CouncilRiskAssessment;

    /** @param array<string,mixed> $result */
    public function assessAfter(CouncilRequest $request, array $result): CouncilRiskAssessment;
}
