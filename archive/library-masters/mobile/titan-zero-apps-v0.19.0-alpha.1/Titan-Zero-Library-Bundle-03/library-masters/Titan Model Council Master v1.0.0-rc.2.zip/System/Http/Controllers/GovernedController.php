<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Http\Controllers;

use App\Extensions\TitanModelCouncil\System\Contracts\CouncilGatewayContract;
use App\Extensions\TitanModelCouncil\System\Company\CompanyContextResolver;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use InvalidArgumentException;

final class GovernedController
{
    public function __construct(
        private readonly CouncilGatewayContract $gateway,
        private readonly CompanyContextResolver $companyContext,
    ) {
    }

    public function __invoke(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'prompt' => ['required', 'string', 'max:100000'],
            'role_models' => ['required', 'array'],
            'role_models.proposer' => ['required', 'string', 'max:160'],
            'role_models.critic' => ['required', 'string', 'max:160'],
            'role_models.verifier' => ['required', 'string', 'max:160'],
            'role_models.arbiter' => ['required', 'string', 'max:160'],
            'risk_level' => ['nullable', 'string', 'max:40'],
            'uncertainty' => ['nullable', 'string', 'max:40'],
            'trace_id' => ['nullable', 'uuid'],
            'correlation_id' => ['nullable', 'uuid'],
            'causation_id' => ['nullable', 'uuid'],
            'root_causation_id' => ['nullable', 'uuid'],
        ]);

        $actor = $request->user();
        if (! $actor) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }
        $company = $this->companyContext->resolve($request, $actor);
        if (! $company) {
            return response()->json(['error' => 'Company context required'], 422);
        }

        $traceId = (string) ($validated['trace_id'] ?? Str::uuid());
        $correlationId = (string) ($validated['correlation_id'] ?? $traceId);
        $causationId = (string) ($validated['causation_id'] ?? $correlationId);

        $councilRequest = CouncilRequest::fromArray([
            'prompt' => $validated['prompt'],
            'company_id' => $company->companyId,
            'user_id' => (int) $actor->getAuthIdentifier(),
            'manual_strategy' => 'governed_deliberation',
            'risk_level' => $validated['risk_level'] ?? 'unknown',
            'metadata' => [
                'uncertainty' => $validated['uncertainty'] ?? null,
                'request_surface' => 'native_governed_endpoint',
            ],
            'trace_id' => $traceId,
            'correlation_id' => $correlationId,
            'causation_id' => $causationId,
            'root_causation_id' => $validated['root_causation_id'] ?? $causationId,
        ]);

        try {
            $result = $this->gateway->runGoverned($councilRequest, (array) $validated['role_models']);
        } catch (InvalidArgumentException $e) {
            return response()->json(['error' => $e->getMessage(), 'trace_id' => $traceId], 422);
        }

        $status = (($result['status'] ?? null) === 'rejected') ? 422 : ((($result['status'] ?? null) === 'failed') ? 503 : 200);
        return response()->json(['trace_id' => $traceId, ...$result], $status);
    }
}
