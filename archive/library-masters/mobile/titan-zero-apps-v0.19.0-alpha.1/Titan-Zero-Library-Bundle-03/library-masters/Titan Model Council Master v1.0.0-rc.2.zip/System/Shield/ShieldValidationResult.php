<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Shield;

final readonly class ShieldValidationResult
{
    /** @param array<int,string> $reasonCodes @param array<string,mixed> $metadata */
    public function __construct(
        public string $stage,
        public bool $passed,
        public bool $blocked,
        public bool $requiresEscalation,
        public array $reasonCodes = [],
        public string $source = 'local-structural-guard',
        public array $metadata = [],
    ) {
    }

    public static function pass(string $stage, string $source = 'local-structural-guard', array $metadata = []): self
    {
        return new self($stage, true, false, false, [], $source, $metadata);
    }

    /** @param array<int,string> $reasonCodes */
    public static function block(string $stage, array $reasonCodes, string $source = 'local-structural-guard', array $metadata = []): self
    {
        return new self($stage, false, true, true, array_values(array_unique($reasonCodes)), $source, $metadata);
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'stage' => $this->stage,
            'passed' => $this->passed,
            'blocked' => $this->blocked,
            'requires_escalation' => $this->requiresEscalation,
            'reason_codes' => $this->reasonCodes,
            'source' => $this->source,
            'metadata' => $this->metadata,
        ];
    }
}
