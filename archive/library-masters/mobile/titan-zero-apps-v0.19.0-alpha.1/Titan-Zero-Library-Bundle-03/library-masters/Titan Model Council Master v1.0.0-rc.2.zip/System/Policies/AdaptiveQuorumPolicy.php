<?php

declare(strict_types=1);

namespace App\Extensions\TitanModelCouncil\System\Policies;

final readonly class AdaptiveQuorumPolicy
{
    public function __construct(
        private int $minimumSuccessfulParticipants = 2,
        private int $minimumAgreementPercent = 90,
    ) {
    }

    public function maySynthesizeEarly(int $requested, int $successful, int $agreementPercent, string $riskLevel, bool $contradictionDetected): bool
    {
        if ($requested <= $successful) {
            return false;
        }
        if ($successful < max(2, $this->minimumSuccessfulParticipants)) {
            return false;
        }
        if ($agreementPercent < $this->minimumAgreementPercent) {
            return false;
        }
        if ($contradictionDetected) {
            return false;
        }
        return ! in_array(strtolower($riskLevel), ['high', 'critical'], true);
    }
}
