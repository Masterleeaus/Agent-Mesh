use App\Extensions\TitanModelCouncil\System\Http\Controllers\ModelCouncilActionController;
<?php

use App\Extensions\TitanModelCouncil\System\Http\Controllers\IndexController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\GovernedController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\PlanController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', IndexController::class)->name('index');
$router->post('/plan', PlanController::class)->name('plan');
$router->post('/governed', GovernedController::class)->name('governed');

$router->post('actions/accept-response', [ModelCouncilActionController::class, 'acceptResponse'])->name('actions.prefer');
