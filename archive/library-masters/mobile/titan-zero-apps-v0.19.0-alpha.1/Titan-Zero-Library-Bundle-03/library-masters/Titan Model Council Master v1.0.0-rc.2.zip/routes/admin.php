<?php

use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminBillingController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminDiagnosticsController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminIntegrationsController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminProvidersController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminSettingsController;
use App\Extensions\TitanModelCouncil\System\Http\Controllers\AdminStrategiesController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
$router->get('/settings', [AdminSettingsController::class, 'index'])->name('settings');
$router->post('/settings', [AdminSettingsController::class, 'update'])->name('settings.update');
$router->post('/settings/reset', [AdminSettingsController::class, 'reset'])->name('settings.reset');
$router->get('/strategies', AdminStrategiesController::class)->name('strategies');
$router->get('/providers', AdminProvidersController::class)->name('providers');
$router->get('/integrations', AdminIntegrationsController::class)->name('integrations');
$router->get('/billing', AdminBillingController::class)->name('billing');
$router->get('/diagnostics', AdminDiagnosticsController::class)->name('diagnostics');
