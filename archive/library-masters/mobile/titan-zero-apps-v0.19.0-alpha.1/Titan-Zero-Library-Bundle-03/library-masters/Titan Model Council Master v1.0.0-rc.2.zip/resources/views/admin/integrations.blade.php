@extends('panel.layout.app')
@section('title', 'Model Council — Integrations')
@section('content')
<div class="container-fluid py-6"><div class="mb-4"><h1>Integrations</h1><p class="text-muted">Council peer-engine controls and current integration state.</p></div>@include('titan-model-council::admin._tabs')
<div class="row g-4">
@foreach ([['Risk Engine','risk_engine_enabled',$risk],['Shield','shield_enabled',$shield],['Assurance','assurance_enabled',$assurance],['Signal','signal_required',$signal]] as $item)
<div class="col-12 col-lg-6"><div class="card h-100"><div class="card-body"><h3 class="h5">{{ $item[0] }}</h3>@if($item[0] !== 'Signal')<p class="mb-2"><span class="badge {{ $settings[$item[1]] ? 'bg-success' : 'bg-secondary' }}">{{ $settings[$item[1]] ? 'Enabled' : 'Disabled' }}</span></p>@endif<pre class="small mb-0" style="white-space:pre-wrap">{{ json_encode($item[2], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre></div></div></div>
@endforeach
</div><div class="mt-4"><a class="btn btn-primary" href="{{ route('dashboard.admin.titan.model.council.settings') }}">Modify integration controls</a></div>
<div class="card mt-4"><div class="card-body"><h3 class="h5">Resolved health</h3><pre class="small mb-0" style="white-space:pre-wrap">{{ json_encode($health, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre></div></div></div>
@endsection
