@extends('panel.layout.app')

@section('title', 'Titan Model Council — Admin')

@section('content')
<div class="container-fluid py-6">
    <div class="mb-4">
        <h1 class="mb-2">Titan Model Council</h1>
        <p class="text-muted mb-0">Super Admin control centre for governed multi-model deliberation. Council remains advisory and never grants execution authority.</p>
    </div>
    @include('titan-model-council::admin._tabs')

    <div class="row g-4 mb-4">
        <div class="col-12 col-md-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Runtime</div><div class="h4 mb-1">{{ $settings['enabled'] ? 'Enabled' : 'Disabled' }}</div><span class="badge {{ $settings['enabled'] ? 'bg-success' : 'bg-secondary' }}">{{ $health['status'] ?? 'unknown' }}</span></div></div></div>
        <div class="col-12 col-md-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Governed mode</div><div class="h4 mb-1">{{ $settings['governed_deliberation_enabled'] ? 'On' : 'Off' }}</div><div class="small text-muted">{{ $settings['minimum_distinct_models'] }} distinct models minimum</div></div></div></div>
        <div class="col-12 col-md-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Adaptive quorum</div><div class="h4 mb-1">{{ $settings['minimum_agreement_percent'] }}%</div><div class="small text-muted">{{ $settings['minimum_successful_participants'] }} successful participants minimum</div></div></div></div>
        <div class="col-12 col-md-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small">Provider timeout</div><div class="h4 mb-1">{{ $settings['provider_timeout_seconds'] }}s</div><div class="small text-muted">Circuit breaker {{ $settings['provider_circuit_breaker_enabled'] ? 'enabled' : 'disabled' }}</div></div></div></div>
    </div>

    <div class="row g-4">
        <div class="col-12 col-xl-7"><div class="card h-100"><div class="card-body"><h3 class="h5">Control surfaces</h3><div class="row g-3">
            @foreach ([
                ['settings','Settings','Enable/disable Council and tune runtime policy.'],
                ['strategies','Strategies & Activation','Review selective activation and governed role depth.'],
                ['providers','Providers & Models','Control Council model limits and synthesis preference.'],
                ['integrations','Integrations','Control Risk, Shield and Assurance participation.'],
                ['billing','Billing & Limits','Set reservation policy and inspect recent reservations.'],
                ['diagnostics','Diagnostics & Audit','Inspect health, decisions and decision receipts.'],
            ] as [$routeName,$label,$description])
                <div class="col-12 col-md-6"><a class="card text-decoration-none h-100" href="{{ route('dashboard.admin.titan.model.council.'.$routeName) }}"><div class="card-body"><strong>{{ $label }}</strong><div class="small text-muted mt-1">{{ $description }}</div></div></a></div>
            @endforeach
        </div></div></div></div>
        <div class="col-12 col-xl-5"><div class="card h-100"><div class="card-body"><h3 class="h5">Runtime health</h3><pre class="small mb-0" style="white-space:pre-wrap">{{ json_encode($health, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre></div></div></div>
    </div>
</div>
@endsection
