@php
    $tabs = [
        ['route' => 'dashboard.admin.titan.model.council.index', 'label' => 'Overview'],
        ['route' => 'dashboard.admin.titan.model.council.settings', 'label' => 'Settings'],
        ['route' => 'dashboard.admin.titan.model.council.strategies', 'label' => 'Strategies & Activation'],
        ['route' => 'dashboard.admin.titan.model.council.providers', 'label' => 'Providers & Models'],
        ['route' => 'dashboard.admin.titan.model.council.integrations', 'label' => 'Integrations'],
        ['route' => 'dashboard.admin.titan.model.council.billing', 'label' => 'Billing & Limits'],
        ['route' => 'dashboard.admin.titan.model.council.diagnostics', 'label' => 'Diagnostics & Audit'],
    ];
@endphp
<div class="card mb-4">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            @foreach ($tabs as $tab)
                <a href="{{ route($tab['route']) }}" class="btn btn-sm {{ request()->routeIs($tab['route']) ? 'btn-primary' : 'btn-outline-secondary' }}">
                    {{ $tab['label'] }}
                </a>
            @endforeach
        </div>
    </div>
</div>
