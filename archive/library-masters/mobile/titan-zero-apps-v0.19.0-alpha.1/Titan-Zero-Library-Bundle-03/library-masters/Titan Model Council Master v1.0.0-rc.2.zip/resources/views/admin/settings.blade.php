@extends('panel.layout.app')

@section('title', 'Model Council — Settings')

@section('content')
<div class="container-fluid py-6">
    <div class="mb-4">
        <h1 class="mb-2">Model Council Settings</h1>
        <p class="text-muted mb-0">Control Council runtime policy. Changes are persisted by the extension and applied to subsequent requests.</p>
    </div>
    @include('titan-model-council::admin._tabs')

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger"><strong>Settings were not saved.</strong><ul class="mb-0 mt-2">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif

    <form method="POST" action="{{ route('dashboard.admin.titan.model.council.settings.update') }}">
        @csrf
        <div class="row g-4">
            <div class="col-12 col-xl-6">
                <div class="card h-100"><div class="card-body">
                    <h3 class="h5">Core runtime</h3>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="enabled" value="1" id="mc-enabled" @checked(old('enabled', $settings['enabled']))><label class="form-check-label" for="mc-enabled">Enable Model Council runtime</label></div>
                    <label class="form-label">Maximum Council models</label><input class="form-control mb-3" type="number" min="2" max="5" name="max_models" value="{{ old('max_models', $settings['max_models']) }}">
                    <label class="form-label">Preferred synthesis model slug</label><input class="form-control" type="text" name="preferred_synthesis_model" value="{{ old('preferred_synthesis_model', $settings['preferred_synthesis_model']) }}" placeholder="Leave blank to use host setting/default">
                    <div class="form-text">Provider credentials remain host-managed; this only selects the preferred synthesis model when available.</div>
                </div></div>
            </div>
            <div class="col-12 col-xl-6">
                <div class="card h-100"><div class="card-body">
                    <h3 class="h5">Activation & governed mode</h3>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="selective_activation_enabled" value="1" id="mc-selective" @checked(old('selective_activation_enabled', $settings['selective_activation_enabled']))><label class="form-check-label" for="mc-selective">Selective activation</label></div>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="governed_deliberation_enabled" value="1" id="mc-governed" @checked(old('governed_deliberation_enabled', $settings['governed_deliberation_enabled']))><label class="form-check-label" for="mc-governed">Governed deliberation</label></div>
                    <label class="form-label">Minimum distinct models in governed mode</label><input class="form-control" type="number" min="2" max="4" name="minimum_distinct_models" value="{{ old('minimum_distinct_models', $settings['minimum_distinct_models']) }}">
                </div></div>
            </div>
            <div class="col-12 col-xl-6">
                <div class="card h-100"><div class="card-body">
                    <h3 class="h5">Risk & validation</h3>
                    <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" name="risk_engine_enabled" value="1" id="mc-risk" @checked(old('risk_engine_enabled', $settings['risk_engine_enabled']))><label class="form-check-label" for="mc-risk">Titan Risk Engine integration</label></div>
                    <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" name="shield_enabled" value="1" id="mc-shield" @checked(old('shield_enabled', $settings['shield_enabled']))><label class="form-check-label" for="mc-shield">Titan Shield validation</label></div>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="assurance_enabled" value="1" id="mc-assurance" @checked(old('assurance_enabled', $settings['assurance_enabled']))><label class="form-check-label" for="mc-assurance">Titan Assurance evidence check</label></div>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="contradiction_enabled" value="1" id="mc-contradiction" @checked(old('contradiction_enabled', $settings['contradiction_enabled']))><label class="form-check-label" for="mc-contradiction">Contradiction safeguard</label></div>
                    <label class="form-label">Contradiction confidence ceiling (%)</label><input class="form-control" type="number" min="1" max="99" name="contradiction_confidence_ceiling" value="{{ old('contradiction_confidence_ceiling', $settings['contradiction_confidence_ceiling']) }}">
                </div></div>
            </div>
            <div class="col-12 col-xl-6">
                <div class="card h-100"><div class="card-body">
                    <h3 class="h5">Quorum & provider resilience</h3>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="adaptive_quorum_enabled" value="1" id="mc-quorum" @checked(old('adaptive_quorum_enabled', $settings['adaptive_quorum_enabled']))><label class="form-check-label" for="mc-quorum">Adaptive quorum / early synthesis</label></div>
                    <div class="row g-3">
                        <div class="col-6"><label class="form-label">Minimum successful participants</label><input class="form-control" type="number" min="2" max="5" name="minimum_successful_participants" value="{{ old('minimum_successful_participants', $settings['minimum_successful_participants']) }}"></div>
                        <div class="col-6"><label class="form-label">Minimum agreement (%)</label><input class="form-control" type="number" min="50" max="100" name="minimum_agreement_percent" value="{{ old('minimum_agreement_percent', $settings['minimum_agreement_percent']) }}"></div>
                        <div class="col-12"><label class="form-label">Provider timeout (seconds)</label><input class="form-control" type="number" min="10" max="300" name="provider_timeout_seconds" value="{{ old('provider_timeout_seconds', $settings['provider_timeout_seconds']) }}"></div>
                    </div>
                    <hr>
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="provider_circuit_breaker_enabled" value="1" id="mc-cb" @checked(old('provider_circuit_breaker_enabled', $settings['provider_circuit_breaker_enabled']))><label class="form-check-label" for="mc-cb">Provider circuit breaker</label></div>
                    <div class="row g-3"><div class="col-6"><label class="form-label">Failure threshold</label><input class="form-control" type="number" min="1" max="10" name="provider_failure_threshold" value="{{ old('provider_failure_threshold', $settings['provider_failure_threshold']) }}"></div><div class="col-6"><label class="form-label">Cooldown (seconds)</label><input class="form-control" type="number" min="10" max="3600" name="provider_cooldown_seconds" value="{{ old('provider_cooldown_seconds', $settings['provider_cooldown_seconds']) }}"></div></div>
                </div></div>
            </div>
            <div class="col-12">
                <div class="card"><div class="card-body">
                    <h3 class="h5">Billing safety</h3>
                    <div class="row g-3 align-items-end">
                        <div class="col-12 col-lg-5"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="billing_reservation_required" value="1" id="mc-billing" @checked(old('billing_reservation_required', $settings['billing_reservation_required']))><label class="form-check-label" for="mc-billing">Require Council reservation before provider execution</label></div></div>
                        <div class="col-12 col-lg-4"><label class="form-label">Max reserved credits per participant</label><input class="form-control" type="number" min="1" max="1000000" name="max_reserved_credits_per_participant" value="{{ old('max_reserved_credits_per_participant', $settings['max_reserved_credits_per_participant']) }}"></div>
                    </div>
                </div></div>
            </div>
        </div>
        <div class="d-flex gap-2 mt-4"><button class="btn btn-primary" type="submit">Save Model Council settings</button></div>
    </form>
    <form method="POST" action="{{ route('dashboard.admin.titan.model.council.settings.reset') }}" class="mt-2">@csrf<button class="btn btn-outline-danger" type="submit" onclick="return confirm('Reset Model Council settings to extension defaults?')">Reset to defaults</button></form>
</div>
@endsection
