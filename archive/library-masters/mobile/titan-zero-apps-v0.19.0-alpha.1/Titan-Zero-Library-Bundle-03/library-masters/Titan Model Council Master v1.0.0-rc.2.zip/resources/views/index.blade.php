@extends('panel.layout.app')

@section('title', 'Titan Model Council')

@section('content')
<div class="container-fluid py-6">
    <div class="mb-6">
        <h1 class="mb-2">Titan Model Council</h1>
        <p class="text-muted mb-0">Governed multi-model deliberation with risk-aware activation, assurance, Shield validation and auditable receipts.</p>
    </div>

    <div class="row g-4">
        <div class="col-12 col-md-6 col-xl-3">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="h6">Council Health</h3>
                    <div class="fs-5 fw-semibold">{{ strtoupper((string) ($health['operational_health']['status'] ?? $health['status'] ?? 'UNKNOWN')) }}</div>
                    <div class="text-muted small mt-2">Version {{ $health['version'] ?? 'unknown' }}</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="h6">Available Strategies</h3>
                    <ul class="mb-0 ps-3">
                        @foreach ($strategies as $strategy)
                            <li>{{ str_replace('_', ' ', $strategy) }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="h6">Billing</h3>
                    <div class="fw-semibold">{{ str_replace('_', ' → ', (string) ($billingConfig['mode'] ?? 'reserve_execute_settle')) }}</div>
                    <div class="text-muted small mt-2">Reservation required: {{ ($billingConfig['reservation_required'] ?? false) ? 'Yes' : 'No' }}</div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-xl-3">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="h6">Provider Runtime</h3>
                    <div class="fw-semibold">{{ $health['ai_core']['execution_runtime'] ?? $health['ai_core']['status'] ?? 'Legacy compatibility' }}</div>
                    <div class="text-muted small mt-2">Signal: {{ $health['signal'] ?? 'unknown' }} · Shield: {{ is_array($health['shield'] ?? null) ? ($health['shield']['status'] ?? 'available') : ($health['shield'] ?? 'unknown') }}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
