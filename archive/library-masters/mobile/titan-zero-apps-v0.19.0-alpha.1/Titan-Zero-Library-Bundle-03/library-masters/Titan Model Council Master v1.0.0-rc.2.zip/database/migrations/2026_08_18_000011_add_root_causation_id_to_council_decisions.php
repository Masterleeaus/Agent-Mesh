<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_model_council_decisions') || Schema::hasColumn('titan_model_council_decisions', 'root_causation_id')) {
            return;
        }
        Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
            $table->uuid('root_causation_id')->nullable()->index()->after('causation_id');
        });
    }

    public function down(): void
    {
        // Forward-only audit linkage is retained.
    }
};
