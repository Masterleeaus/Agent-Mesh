<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_model_council_decisions')) {
            return;
        }

        Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_model_council_decisions', 'pre_arbiter_validation_status')) {
                $table->string('pre_arbiter_validation_status', 40)->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'final_validation_status')) {
                $table->string('final_validation_status', 40)->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'validation_source')) {
                $table->string('validation_source', 100)->nullable();
            }
        });

        // Keep index creation independent from column creation so a retry repairs
        // partial MySQL DDL left by an earlier failed scoped install.
        if (! Schema::hasIndex('titan_model_council_decisions', 'tmc_dec_prearbiter_status_idx')) {
            Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
                $table->index('pre_arbiter_validation_status', 'tmc_dec_prearbiter_status_idx');
            });
        }
        if (! Schema::hasIndex('titan_model_council_decisions', 'tmc_dec_final_validation_idx')) {
            Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
                $table->index('final_validation_status', 'tmc_dec_final_validation_idx');
            });
        }
        if (! Schema::hasIndex('titan_model_council_decisions', 'tmc_dec_validation_source_idx')) {
            Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
                $table->index('validation_source', 'tmc_dec_validation_source_idx');
            });
        }
    }

    public function down(): void
    {
        // Forward-only audit fields.
    }
};
