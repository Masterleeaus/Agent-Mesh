<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_model_council_participants')) {
            return;
        }
        Schema::create('titan_model_council_participants', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('decision_id')->index();
            $table->uuid('trace_id')->nullable()->index();
            $table->string('role', 40)->index();
            $table->string('model_slug', 160)->index();
            $table->string('status', 40)->index();
            $table->unsignedTinyInteger('confidence_percent')->nullable();
            $table->unsignedInteger('response_time_ms')->nullable();
            $table->unsignedBigInteger('credits')->default(0);
            $table->string('failure_reason', 160)->nullable();
            $table->longText('response_text')->nullable();
            $table->char('output_sha256', 64)->nullable()->index();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'decision_id', 'role'], 'tmc_participant_role_unique');
        });
    }

    public function down(): void
    {
        // Forward-only audit history. Do not silently destroy deliberation evidence.
    }
};
