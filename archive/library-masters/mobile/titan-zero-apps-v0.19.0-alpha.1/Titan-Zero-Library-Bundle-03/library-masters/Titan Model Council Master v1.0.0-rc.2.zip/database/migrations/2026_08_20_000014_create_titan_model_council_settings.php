<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_model_council_settings')) {
            return;
        }

        Schema::create('titan_model_council_settings', function (Blueprint $table): void {
            $table->unsignedTinyInteger('id')->primary();
            $table->boolean('enabled')->default(true);
            $table->unsignedTinyInteger('max_models')->default(5);
            $table->string('preferred_synthesis_model', 191)->default('');
            $table->boolean('selective_activation_enabled')->default(true);
            $table->boolean('governed_deliberation_enabled')->default(true);
            $table->unsignedTinyInteger('minimum_distinct_models')->default(3);
            $table->boolean('risk_engine_enabled')->default(true);
            $table->boolean('shield_enabled')->default(true);
            $table->boolean('assurance_enabled')->default(true);
            $table->boolean('contradiction_enabled')->default(true);
            $table->unsignedTinyInteger('contradiction_confidence_ceiling')->default(50);
            $table->boolean('adaptive_quorum_enabled')->default(true);
            $table->unsignedTinyInteger('minimum_successful_participants')->default(2);
            $table->unsignedTinyInteger('minimum_agreement_percent')->default(90);
            $table->unsignedSmallInteger('provider_timeout_seconds')->default(90);
            $table->boolean('provider_circuit_breaker_enabled')->default(true);
            $table->unsignedTinyInteger('provider_failure_threshold')->default(3);
            $table->unsignedSmallInteger('provider_cooldown_seconds')->default(60);
            $table->boolean('billing_reservation_required')->default(true);
            $table->unsignedInteger('max_reserved_credits_per_participant')->default(5000);
            $table->unsignedBigInteger('updated_by_user_id')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        // Forward-only settings persistence. Extension uninstall owns cleanup policy.
    }
};
