<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_model_council_billing_reservations')) {
            return;
        }
        Schema::create('titan_model_council_billing_reservations', function (Blueprint $table): void {
            $table->id();
            $table->uuid('reservation_id')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->index();
            $table->uuid('trace_id')->nullable()->index();
            $table->string('status', 32)->default('reserved')->index();
            $table->unsignedInteger('reserved_credits');
            $table->unsignedInteger('settled_credits')->default(0);
            $table->unsignedInteger('released_credits')->default(0);
            $table->json('reserved_components')->nullable();
            $table->json('settled_components')->nullable();
            $table->string('release_reason', 160)->nullable();
            $table->timestamp('reserved_at');
            $table->timestamp('settled_at')->nullable();
            $table->timestamp('released_at')->nullable();
            $table->timestamps();
            $table->index(['company_id', 'user_id', 'status'], 'tmc_billing_tenant_user_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_model_council_billing_reservations');
    }
};
