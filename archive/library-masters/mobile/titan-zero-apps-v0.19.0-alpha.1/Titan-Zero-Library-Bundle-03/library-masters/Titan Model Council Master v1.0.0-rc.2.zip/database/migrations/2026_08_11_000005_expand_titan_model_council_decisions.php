<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_model_council_decisions')) {
            return;
        }
        Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_model_council_decisions', 'activation_reason')) {
                $table->string('activation_reason', 160)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'activation_source')) {
                $table->string('activation_source', 80)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'trigger_metadata')) {
                $table->json('trigger_metadata')->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'strategy')) {
                $table->string('strategy', 80)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'risk_level')) {
                $table->string('risk_level', 40)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'requested_participant_count')) {
                $table->unsignedSmallInteger('requested_participant_count')->default(1);
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'actual_participant_count')) {
                $table->unsignedSmallInteger('actual_participant_count')->default(0);
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'confidence_percent')) {
                $table->unsignedTinyInteger('confidence_percent')->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'agreement_percent')) {
                $table->unsignedTinyInteger('agreement_percent')->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'strong_contradiction')) {
                $table->boolean('strong_contradiction')->default(false)->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'requires_escalation')) {
                $table->boolean('requires_escalation')->default(false)->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'billing_reservation_id')) {
                $table->uuid('billing_reservation_id')->nullable()->index();
            }
        });
    }

    public function down(): void
    {
        // Forward-only extension migration. Do not remove audit fields once recorded.
    }
};
