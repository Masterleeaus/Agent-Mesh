<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('user_openai_chat_messages')) {
            return;
        }

        Schema::table('user_openai_chat_messages', function (Blueprint $table): void {
            if (! Schema::hasColumn('user_openai_chat_messages', 'is_council')) {
                $table->boolean('is_council')->default(false);
            }

            if (! Schema::hasColumn('user_openai_chat_messages', 'council_response')) {
                $table->json('council_response')->nullable();
            }
        });
    }

    public function down(): void
    {
        // Forward-compatible shared-table migration: intentionally do not remove
        // columns that may still be consumed by the legacy Model Council/UI.
    }
};
