<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_model_council_receipts')) {
            return;
        }

        Schema::create('titan_model_council_receipts', function (Blueprint $table): void {
            $table->id();
            $table->uuid('receipt_id')->unique();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('decision_id');
            $table->uuid('trace_id')->index();
            $table->uuid('correlation_id')->index();
            $table->uuid('causation_id')->index();
            $table->uuid('root_causation_id')->index();
            $table->string('status', 40);
            $table->string('strategy', 80);
            $table->string('execution_authority', 80)->default('advisory_only');
            $table->boolean('requires_escalation')->default(false);
            $table->char('receipt_hash', 64)->index();
            $table->json('receipt_payload');
            $table->timestamp('recorded_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id', 'decision_id'], 'tmc_receipt_tenant_decision_unique');
        });
    }

    public function down(): void
    {
        // Forward-only production migration: Council receipt evidence is retained.
    }
};
