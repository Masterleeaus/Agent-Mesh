<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }
        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['id'])) {
            return;
        }

        $parentKey = 'titan_model_council_admin';
        $rows = [
            [$parentKey, null, 'dashboard.admin.titan.model.council.index', 'Model Council', 'tabler-users-group', 994],
            ['titan_model_council_admin_overview', $parentKey, 'dashboard.admin.titan.model.council.index', 'Overview', 'tabler-layout-dashboard', 1],
            ['titan_model_council_admin_settings', $parentKey, 'dashboard.admin.titan.model.council.settings', 'Settings', 'tabler-settings', 2],
            ['titan_model_council_admin_strategies', $parentKey, 'dashboard.admin.titan.model.council.strategies', 'Strategies & Activation', 'tabler-route-alt-left', 3],
            ['titan_model_council_admin_providers', $parentKey, 'dashboard.admin.titan.model.council.providers', 'Providers & Models', 'tabler-cpu', 4],
            ['titan_model_council_admin_integrations', $parentKey, 'dashboard.admin.titan.model.council.integrations', 'Integrations', 'tabler-plug-connected', 5],
            ['titan_model_council_admin_billing', $parentKey, 'dashboard.admin.titan.model.council.billing', 'Billing & Limits', 'tabler-credit-card', 6],
            ['titan_model_council_admin_diagnostics', $parentKey, 'dashboard.admin.titan.model.council.diagnostics', 'Diagnostics & Audit', 'tabler-activity-heartbeat', 7],
        ];

        $changed = false;
        foreach ($rows as [$key, $parent, $route, $label, $icon, $order]) {
            $parentId = null;
            if ($parent !== null && isset($columns['parent_id'])) {
                $parentId = DB::table('menus')->where('key', $parent)->orderBy('id')->value('id');
                if ($parentId === null) {
                    continue;
                }
            }

            $payload = [
                'parent_id' => $parentId,
                'route' => $route,
                'route_slug' => null,
                'label' => $label,
                'icon' => $icon,
                'svg' => null,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                'extension' => '1',
                'is_admin' => 1,
            ];
            $existing = DB::table('menus')->where('key', $key)->orderBy('id')->first();
            if ($existing !== null) {
                if (isset($columns['updated_at'])) {
                    $payload['updated_at'] = now();
                }
                DB::table('menus')->where('id', (int) $existing->id)->update(array_intersect_key($payload, $columns));
                $changed = true;
                continue;
            }

            $payload += [
                'key' => $key,
                'order' => $order,
                'is_active' => 1,
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
            ];
            if (isset($columns['created_at'])) {
                $payload['created_at'] = now();
            }
            if (isset($columns['updated_at'])) {
                $payload['updated_at'] = now();
            }
            DB::table('menus')->insert(array_intersect_key($payload, $columns));
            $changed = true;
        }

        if ($changed && class_exists(\App\Services\Common\MenuService::class)) {
            try {
                app(\App\Services\Common\MenuService::class)->regenerate();
            } catch (\Throwable) {
                try { \App\Services\Common\MenuService::regenerate(); } catch (\Throwable) {}
            }
        }
    }

    public function down(): void
    {
        // Forward-only host navigation compatibility; uninstall owns cleanup.
    }
};
