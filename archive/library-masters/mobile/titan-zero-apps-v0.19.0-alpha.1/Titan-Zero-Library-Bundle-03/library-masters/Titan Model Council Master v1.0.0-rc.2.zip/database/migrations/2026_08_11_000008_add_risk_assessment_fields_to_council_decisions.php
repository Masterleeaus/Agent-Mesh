<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_model_council_decisions')) {
            return;
        }

        Schema::table('titan_model_council_decisions', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_model_council_decisions', 'risk_score')) {
                $table->decimal('risk_score', 5, 2)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'risk_decision')) {
                $table->string('risk_decision', 40)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'risk_policy_version')) {
                $table->string('risk_policy_version', 80)->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'risk_engine_available')) {
                $table->boolean('risk_engine_available')->default(false)->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'preflight_risk_payload')) {
                $table->json('preflight_risk_payload')->nullable();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'postflight_risk_level')) {
                $table->string('postflight_risk_level', 40)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'postflight_risk_score')) {
                $table->decimal('postflight_risk_score', 5, 2)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'postflight_risk_decision')) {
                $table->string('postflight_risk_decision', 40)->nullable()->index();
            }
            if (! Schema::hasColumn('titan_model_council_decisions', 'postflight_risk_payload')) {
                $table->json('postflight_risk_payload')->nullable();
            }
        });
    }

    public function down(): void
    {
        // Forward-only audit migration. Risk evidence must remain reconstructable.
    }
};
