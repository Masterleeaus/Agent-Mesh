<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('menus') || ! Schema::hasColumn('menus', 'key')) {
            return;
        }

        $columns = array_fill_keys(Schema::getColumnListing('menus'), true);
        if (! isset($columns['id'])) {
            return;
        }

        $rows = [
            [
                'key' => 'titan_model_council',
                'parent_id' => null,
                'route' => 'dashboard.user.titan.model.council.index',
                'route_slug' => null,
                'label' => 'Model Council',
                'icon' => 'tabler-users-group',
                'svg' => null,
                'order' => 125,
                'is_active' => 1,
                'is_admin' => 0,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                'extension' => '1',
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
            ],
            [
                'key' => 'titan_model_council_admin',
                'parent_id' => null,
                'route' => 'dashboard.admin.titan.model.council.index',
                'route_slug' => null,
                'label' => 'Model Council',
                'icon' => 'tabler-users-group',
                'svg' => null,
                'order' => 994,
                'is_active' => 1,
                'is_admin' => 1,
                'params' => '[]',
                'type' => 'item',
                'badge' => null,
                'extension' => '1',
                'custom_menu' => 0,
                'bolt_menu' => 0,
                'bolt_background' => null,
                'bolt_foreground' => null,
                'letter_icon' => 0,
                'letter_icon_bg' => null,
            ],
        ];

        $changed = false;
        foreach ($rows as $row) {
            $existing = DB::table('menus')->where('key', $row['key'])->orderBy('id')->first();
            $payload = array_intersect_key($row, $columns);

            if ($existing !== null) {
                // Preserve the host administrator's explicit enable/disable choice.
                unset($payload['is_active']);
                if ($row['key'] === 'titan_model_council' || (int) ($existing->order ?? 0) >= 900) {
                    unset($payload['order']);
                }
                if (isset($columns['updated_at'])) {
                    $payload['updated_at'] = now();
                }
                DB::table('menus')->where('id', (int) $existing->id)->update($payload);
                $changed = true;
                continue;
            }

            if (isset($columns['created_at'])) {
                $payload['created_at'] = now();
            }
            if (isset($columns['updated_at'])) {
                $payload['updated_at'] = now();
            }
            $payload['key'] = $row['key'];
            DB::table('menus')->insert(array_intersect_key($payload, $columns));
            $changed = true;
        }

        if ($changed && class_exists(\App\Services\Common\MenuService::class)) {
            try {
                $service = app(\App\Services\Common\MenuService::class);
                if (method_exists($service, 'regenerate')) {
                    $service->regenerate();
                }
            } catch (\Throwable) {
                try {
                    \App\Services\Common\MenuService::regenerate();
                } catch (\Throwable) {
                    // Durable menu rows are present; provider self-heal retries cache refresh.
                }
            }
        }
    }

    public function down(): void
    {
        // Navigation is intentionally self-healing and data-preserving across hotfix rollback.
        // Extension uninstall owns final cleanup policy.
    }
};
