<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanModelCouncil\System\Security\AcceptedResponseScope;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_null_shared_uuid_never_creates_a_deletion_scope(): void
    {
        self::assertNull(AcceptedResponseScope::forMessage(10, 20, 30, null));
    }

    public function test_deletion_scope_is_bound_to_user_chat_group_and_message(): void
    {
        self::assertSame([
            'user_id' => 10,
            'user_openai_chat_id' => 20,
            'shared_uuid' => 'group-a',
            'exclude_id' => 30,
        ], AcceptedResponseScope::forMessage(10, 20, 30, ' group-a '));
    }
}
