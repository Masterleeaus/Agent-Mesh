<?php

declare(strict_types=1);

require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/Shield/ShieldValidationResult.php';
require __DIR__ . '/../System/Shield/CouncilShieldGateContract.php';
require __DIR__ . '/../System/Shield/LocalCouncilShieldGate.php';

use App\Extensions\TitanModelCouncil\System\Shield\LocalCouncilShieldGate;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

$gate = new LocalCouncilShieldGate();
$request = new CouncilRequest('Review this decision', 1, 2);

$pre = $gate->validate('pre_arbiter', $request, [
    'proposer' => ['success' => true, 'response_text' => 'proposal'],
    'critic' => ['success' => true, 'response_text' => 'critique'],
    'verifier' => ['success' => true, 'response_text' => 'verification'],
]);
check($pre->passed === true, 'Complete role artifacts should pass local pre-arbiter structural validation.');

$bad = $gate->validate('pre_arbiter', $request, [
    'proposer' => ['success' => true, 'response_text' => 'proposal'],
    'critic' => ['success' => false, 'response_text' => ''],
]);
check($bad->passed === false && $bad->blocked === true, 'Missing/failed required role artifacts must block arbitration.');

$final = $gate->validate('final', $request, ['arbiter' => ['success' => true, 'response_text' => 'final answer']]);
check($final->passed === true, 'Non-empty arbiter output should pass local final structural validation.');

echo "PASS pass5_local_shield_runner\n";
