<?php
require __DIR__ . '/../System/AICore/AICoreRuntimeProbe.php';

use App\Extensions\TitanModelCouncil\System\AICore\AICoreRuntimeProbe;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
$probe = new AICoreRuntimeProbe(static fn (string $class): bool => $class === 'App\\Extensions\\TitanAICore\\System\\Contracts\\AICoreManagerContract', static fn (string $abstract): mixed => new class { public function health(): array { return ['engine'=>'titan-ai-core','status'=>'scaffold','version'=>'0.2.0']; } });
$status = $probe->status();
check($status['available'] === true, 'AI Core contract should be detected.');
check($status['provider_execution_supported'] === false, 'Health-only AI Core must not be falsely treated as an execution runtime.');
check($status['mode'] === 'legacy_provider_compatibility', 'Council must keep compatibility provider execution until AI Core publishes a real execution contract.');
echo "PASS pass4_ai_core_boundary_runner\n";
