<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$files = glob($root . '/database/migrations/*.php') ?: [];
$failures = [];
$checked = 0;

foreach ($files as $file) {
    $tableName = null;
    $lines = file($file, FILE_IGNORE_NEW_LINES) ?: [];
    foreach ($lines as $lineNo => $line) {
        if (preg_match('/Schema::(?:create|table)\(\'([^\']+)\'/', $line, $m)) {
            $tableName = $m[1];
        }
        if ($tableName === null) {
            continue;
        }

        if (preg_match('/\$table->(?:[A-Za-z0-9_]+)\(\'([^\']+)\'[^;]*->(index|unique)\(\)/', $line, $m)) {
            $identifier = $tableName . '_' . $m[1] . '_' . $m[2];
            $checked++;
            if (strlen($identifier) > 64) {
                $failures[] = basename($file) . ':' . ($lineNo + 1) . " inferred {$m[2]} identifier {$identifier} is " . strlen($identifier) . ' chars';
            }
        }

        if (preg_match('/->(?:index|unique)\(\'([^\']+)\'\)/', $line, $m)) {
            $checked++;
            if (strlen($m[1]) > 64) {
                $failures[] = basename($file) . ':' . ($lineNo + 1) . " explicit identifier {$m[1]} is " . strlen($m[1]) . ' chars';
            }
        }

        if (preg_match('/->(?:index|unique)\(\'([^\']+)\',\s*\'([^\']+)\'\)/', $line, $m)) {
            $checked++;
            if (strlen($m[2]) > 64) {
                $failures[] = basename($file) . ':' . ($lineNo + 1) . " explicit identifier {$m[2]} is " . strlen($m[2]) . ' chars';
            }
        }

        if (preg_match('/->(?:index|unique)\(\[[^]]+\],\s*\'([^\']+)\'\)/', $line, $m)) {
            $checked++;
            if (strlen($m[1]) > 64) {
                $failures[] = basename($file) . ':' . ($lineNo + 1) . " explicit composite identifier {$m[1]} is " . strlen($m[1]) . ' chars';
            }
        }

        if (preg_match('/\$table->foreignId\(\'([^\']+)\'\)/', $line, $m)) {
            $identifier = $tableName . '_' . $m[1] . '_foreign';
            $checked++;
            if (strlen($identifier) > 64) {
                $failures[] = basename($file) . ':' . ($lineNo + 1) . " inferred foreign identifier {$identifier} is " . strlen($identifier) . ' chars';
            }
        }
    }
}

if ($failures !== []) {
    fwrite(STDERR, "FAIL: MySQL identifier audit failed\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

fwrite(STDOUT, "PASS: MySQL migration identifier audit checked {$checked} generated/explicit identifiers; all are <=64 chars\n");
