<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$failures = [];
$expect = static function (bool $condition, string $message) use (&$failures): void {
    if (! $condition) {
        $failures[] = $message;
    }
};

$provider = (string) @file_get_contents($root . '/System/TitanModelCouncilServiceProvider.php');
$navPath = $root . '/System/Navigation/ModelCouncilNavigation.php';
$registrarPath = $root . '/System/Navigation/HostNavigationRegistrar.php';
$migrationPath = $root . '/database/migrations/2026_08_20_000013_register_model_council_host_navigation.php';

$expect(is_file($navPath), 'ModelCouncilNavigation is missing.');
$expect(is_file($registrarPath), 'HostNavigationRegistrar is missing.');
$expect(is_file($migrationPath), 'Host navigation migration is missing.');
$expect(str_contains($provider, 'HostNavigationRegistrar::class'), 'Provider does not register host navigation.');
$expect(str_contains($provider, 'syncHostMenus'), 'Provider does not self-heal host menus after boot.');
$expect(str_contains($provider, "whereIn('key', ["), 'Uninstall does not remove Model Council host menu rows.');
foreach ([
    "'titan_model_council'",
    "'titan_model_council_admin'",
    "'titan_model_council_admin_settings'",
    "'titan_model_council_admin_diagnostics'",
] as $menuKey) {
    $expect(str_contains($provider, $menuKey), "Uninstall cleanup missing {$menuKey}.");
}

if (is_file($navPath)) {
    $nav = (string) file_get_contents($navPath);
    foreach ([
        "'titan_model_council'",
        "'titan_model_council_admin'",
        "'dashboard.user.titan.model.council.index'",
        "'dashboard.admin.titan.model.council.index'",
        "'is_admin' => false",
        "'is_admin' => true",
    ] as $needle) {
        $expect(str_contains($nav, $needle), "Navigation definition missing {$needle}.");
    }
}

if (is_file($registrarPath)) {
    $registrar = (string) file_get_contents($registrarPath);
    $expect(str_contains($registrar, "Schema::hasTable('menus')"), 'Registrar does not guard missing menus table.');
    $expect(str_contains($registrar, 'HostMenuRecord::query()'), 'Registrar does not sync the proven MagicAI menus table through the Eloquent compatibility record.');
    $expect(! str_contains($registrar, "DB::" . "table('menus')"), 'Active navigation registrar must not bypass the Blueprint domain boundary with raw DB access.');
    $expect(str_contains($registrar, 'regenerateMenuCache'), 'Registrar does not refresh the host menu cache.');
    $expect(str_contains($registrar, 'registerContributions'), 'Registrar does not support modern contribution registries.');
}

if (is_file($migrationPath)) {
    $migration = (string) file_get_contents($migrationPath);
    $expect(str_contains($migration, "'titan_model_council'"), 'Migration does not create the user menu row.');
    $expect(str_contains($migration, "'titan_model_council_admin'"), 'Migration does not create the admin menu row.');
    $expect(str_contains($migration, "Schema::getColumnListing('menus')"), 'Migration is not host-column tolerant.');
}

if ($failures !== []) {
    fwrite(STDERR, "FAIL pass6 menu navigation\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS pass6 menu navigation\n";
