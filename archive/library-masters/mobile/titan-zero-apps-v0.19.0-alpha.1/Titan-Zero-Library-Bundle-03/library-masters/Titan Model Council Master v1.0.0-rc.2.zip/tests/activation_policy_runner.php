<?php

declare(strict_types=1);

require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/ValueObjects/CouncilActivationDecision.php';
require __DIR__ . '/../System/Policies/SelectiveActivationPolicy.php';

use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

$policy = new SelectiveActivationPolicy([
    'enabled' => true,
    'manual_override_wins' => true,
    'high_consequence_actions' => ['delete', 'refund', 'pay', 'send', 'schedule', 'booking'],
    'greeting_patterns' => ['/^\s*(hi|hello|hey)\b/i'],
]);

$greeting = CouncilRequest::fromArray(['prompt' => 'Hello there', 'company_id' => 42, 'user_id' => 7]);
$d = $policy->decide($greeting);
assert($d->strategy === 'single_model');
assert($d->activationReason === 'selective_trigger:greeting');

$consequential = CouncilRequest::fromArray(['prompt' => 'Delete all unpaid invoices', 'company_id' => 42, 'user_id' => 7]);
$d = $policy->decide($consequential);
assert($d->strategy === 'parallel_consensus');
assert($d->activationReason === 'selective_trigger:high_consequence');
assert($d->triggerMetadata['governance_escalation_required'] === true);

$manual = CouncilRequest::fromArray(['prompt' => 'Summarize this', 'company_id' => 42, 'user_id' => 7, 'manual_strategy' => 'parallel_consensus']);
$d = $policy->decide($manual);
assert($d->strategy === 'parallel_consensus');
assert($d->activationReason === 'manual_user_request');

echo "pass3_activation_policy_runner: OK\n";
