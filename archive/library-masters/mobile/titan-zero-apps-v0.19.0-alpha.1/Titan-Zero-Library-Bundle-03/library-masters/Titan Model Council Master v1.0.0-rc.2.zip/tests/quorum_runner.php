<?php

declare(strict_types=1);

require __DIR__ . '/../System/Policies/AdaptiveQuorumPolicy.php';

use App\Extensions\TitanModelCouncil\System\Policies\AdaptiveQuorumPolicy;

$p = new AdaptiveQuorumPolicy(2, 90);
assert($p->maySynthesizeEarly(3, 2, 94, 'low', false) === true);
assert($p->maySynthesizeEarly(3, 2, 94, 'high', false) === false);
assert($p->maySynthesizeEarly(3, 2, 94, 'low', true) === false);
assert($p->maySynthesizeEarly(3, 1, 99, 'low', false) === false);
assert($p->maySynthesizeEarly(3, 2, 82, 'low', false) === false);

echo "pass3_quorum_runner: OK\n";
