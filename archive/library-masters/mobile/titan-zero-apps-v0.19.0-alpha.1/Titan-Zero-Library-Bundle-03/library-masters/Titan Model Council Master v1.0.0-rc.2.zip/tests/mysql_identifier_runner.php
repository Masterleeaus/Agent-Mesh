<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$migration = $root . '/database/migrations/2026_08_11_000010_add_governed_validation_fields.php';
$source = file_get_contents($migration);
if ($source === false) {
    fwrite(STDERR, "FAIL: unable to read governed validation migration\n");
    exit(1);
}

$required = [
    'pre_arbiter_validation_status' => 'tmc_dec_prearbiter_status_idx',
    'final_validation_status' => 'tmc_dec_final_validation_idx',
    'validation_source' => 'tmc_dec_validation_source_idx',
];

foreach ($required as $column => $index) {
    if (strlen($index) > 64) {
        fwrite(STDERR, "FAIL: explicit MySQL index name exceeds 64 chars: {$index}\n");
        exit(1);
    }

    $pattern = "/->index\\(['\"]" . preg_quote($column, '/') . "['\"],\\s*['\"]" . preg_quote($index, '/') . "['\"]\\)/";
    if (! preg_match($pattern, $source)) {
        fwrite(STDERR, "FAIL: {$column} must use explicit bounded index {$index}\n");
        exit(1);
    }
}

$bad = 'titan_model_council_decisions_pre_arbiter_validation_status_index';
if (strlen($bad) <= 64) {
    fwrite(STDERR, "FAIL: regression fixture no longer represents an overlong MySQL identifier\n");
    exit(1);
}

fwrite(STDOUT, "PASS: governed validation migration uses explicit MySQL-safe index identifiers\n");
