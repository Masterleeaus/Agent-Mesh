<?php
$m = json_decode(file_get_contents(__DIR__ . '/../extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
$peers = array_values(array_filter(array_map(static fn ($dependency) => is_array($dependency) ? ($dependency['key'] ?? null) : $dependency, $m['dependencies']['optional'] ?? [])));
check(in_array('titan-risk-engine', $peers, true), 'Risk Engine must be declared optional peer dependency.');
check(in_array('titan-ai-core', $peers, true), 'AI Core must be declared optional peer dependency.');
check(in_array('council.risk-aware-activation', $m['capabilities'] ?? [], true), 'Manifest must advertise implemented risk-aware activation.');
echo "PASS pass4_manifest_peer_runner\n";
