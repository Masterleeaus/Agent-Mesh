<?php
$root = dirname(__DIR__);
foreach (['index.blade.php','admin.blade.php'] as $view) {
    $s = file_get_contents($root . '/resources/views/' . $view);
    if (str_contains($s, '<x-layouts.app>')) { fwrite(STDERR, "Unsupported x-layouts.app remains in {$view}\n"); exit(1); }
    if (!str_contains($s, "@extends('panel.layout.app')")) { fwrite(STDERR, "Host panel layout missing in {$view}\n"); exit(1); }
}
$index = file_get_contents($root . '/resources/views/index.blade.php');
foreach (['Council Health', 'Available Strategies', 'Billing', 'Provider Runtime'] as $needle) {
    if (!str_contains($index, $needle)) { fwrite(STDERR, "Missing user card {$needle}\n"); exit(1); }
}
echo "PASS pass6_ui_host_runner\n";
