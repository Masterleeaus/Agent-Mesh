<?php

declare(strict_types=1);

require __DIR__ . '/../System/Security/AcceptedResponseScope.php';

use App\Extensions\TitanModelCouncil\System\Security\AcceptedResponseScope;

$assertSame = static function (mixed $expected, mixed $actual, string $message): void {
    if ($expected !== $actual) {
        fwrite(STDERR, "FAIL: {$message}\nExpected: " . var_export($expected, true) . "\nActual: " . var_export($actual, true) . "\n");
        exit(1);
    }
};

$assertSame(null, AcceptedResponseScope::forMessage(7, 22, 99, null), 'null shared_uuid must never produce a sibling deletion scope');
$assertSame(null, AcceptedResponseScope::forMessage(7, 22, 99, '   '), 'blank shared_uuid must never produce a sibling deletion scope');
$assertSame([
    'user_id' => 7,
    'user_openai_chat_id' => 22,
    'shared_uuid' => 'grp-123',
    'exclude_id' => 99,
], AcceptedResponseScope::forMessage(7, 22, 99, ' grp-123 '), 'scope must bind deletion to actor, chat, group, and exclude accepted message');

echo "pass1 security scope tests passed\n";
