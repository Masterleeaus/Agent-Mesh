<?php

declare(strict_types=1);
$root=dirname(__DIR__);
$m=json_decode(file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$provider=(string)($m['provider']??''); $namespace=(string)($m['namespace']??'');
if(!str_contains($provider,'TitanModelCouncil') || !str_contains($namespace,'TitanModelCouncil')) throw new RuntimeException('Model Council canonical namespace/provider missing.');
if(str_contains($provider,'TitanAssurance') || str_contains($namespace,'TitanAssurance')) throw new RuntimeException('Model Council collides with Assurance.');
$w=json_decode(file_get_contents($root.'/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR);
if(($w['provider']['extension']??'')!=='titan-model-council') throw new RuntimeException('Model Council provider identity drift.');
echo "Titan Model Council identity isolation: PASS\n";
