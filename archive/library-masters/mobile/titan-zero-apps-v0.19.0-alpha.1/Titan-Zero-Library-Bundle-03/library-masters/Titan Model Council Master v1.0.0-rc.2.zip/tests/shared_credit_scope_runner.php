<?php

declare(strict_types=1);

$source = file_get_contents(__DIR__ . '/../System/Services/ModelCouncilExecutionService.php');
if (! str_contains($source, 'prepareCouncilContext($request, $user, $chatParams, false)')) {
    fwrite(STDERR, "FAIL: shared-summary flow must not re-require participant credits already spent by upstream model replies\n");
    exit(1);
}
if (! str_contains($source, 'bool $requireParticipantCredit = true')) {
    fwrite(STDERR, "FAIL: Council context must explicitly control participant-credit preflight\n");
    exit(1);
}
echo "pass3_shared_credit_scope_runner: OK\n";
