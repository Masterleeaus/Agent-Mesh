<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$matches = [];
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

foreach ($iterator as $file) {
    if ($file->isFile() && $file->getFilename() === 'extension.json') {
        $path = str_replace('\\', '/', $file->getPathname());
        $matches[] = ltrim(substr($path, strlen($root)), '/');
    }
}

sort($matches);

if ($matches !== ['extension.json']) {
    fwrite(STDERR, 'FAIL: Installer 1.7.4 requires exactly one discoverable extension.json; found: '.json_encode($matches).PHP_EOL);
    exit(1);
}

echo "PASS: Installer 1.7.4 archive shape has exactly one root extension.json\n";
