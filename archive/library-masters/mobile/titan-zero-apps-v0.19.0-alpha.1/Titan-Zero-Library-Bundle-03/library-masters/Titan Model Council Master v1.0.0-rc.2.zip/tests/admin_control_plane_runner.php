<?php
$root = dirname(__DIR__);
$requiredFiles = [
    'System/Settings/ModelCouncilSettingsRepository.php',
    'System/Models/ModelCouncilSetting.php',
    'System/Http/Controllers/AdminSettingsController.php',
    'System/Http/Controllers/AdminStrategiesController.php',
    'System/Http/Controllers/AdminProvidersController.php',
    'System/Http/Controllers/AdminIntegrationsController.php',
    'System/Http/Controllers/AdminBillingController.php',
    'System/Http/Controllers/AdminDiagnosticsController.php',
    'resources/views/admin/settings.blade.php',
    'resources/views/admin/strategies.blade.php',
    'resources/views/admin/providers.blade.php',
    'resources/views/admin/integrations.blade.php',
    'resources/views/admin/billing.blade.php',
    'resources/views/admin/diagnostics.blade.php',
    'database/migrations/2026_08_20_000014_create_titan_model_council_settings.php',
];
foreach ($requiredFiles as $file) {
    if (!is_file($root.'/'.$file)) {
        fwrite(STDERR, "Missing admin control-plane file: {$file}\n");
        exit(1);
    }
}
$routes = file_get_contents($root.'/routes/admin.php');
foreach (['settings', 'strategies', 'providers', 'integrations', 'billing', 'diagnostics'] as $route) {
    if (!str_contains($routes, "'{$route}'")) {
        fwrite(STDERR, "Missing admin route: {$route}\n");
        exit(1);
    }
}
$nav = file_get_contents($root.'/System/Navigation/ModelCouncilNavigation.php');
foreach (['titan_model_council_admin_settings','titan_model_council_admin_strategies','titan_model_council_admin_providers','titan_model_council_admin_integrations','titan_model_council_admin_billing','titan_model_council_admin_diagnostics'] as $key) {
    if (!str_contains($nav, $key)) {
        fwrite(STDERR, "Missing child menu key: {$key}\n");
        exit(1);
    }
}
$repo = file_get_contents($root.'/System/Settings/ModelCouncilSettingsRepository.php');
foreach (['applyRuntimeOverrides', 'selective_activation.enabled', 'adaptive_quorum.provider_timeout_seconds', 'billing.max_reserved_credits_per_participant'] as $needle) {
    if (!str_contains($repo, $needle)) {
        fwrite(STDERR, "Settings repository missing behavior: {$needle}\n");
        exit(1);
    }
}
$settingsController = file_get_contents($root.'/System/Http/Controllers/AdminSettingsController.php');
foreach (['minimum_agreement_percent','provider_timeout_seconds','max_reserved_credits_per_participant'] as $field) {
    if (!str_contains($settingsController, $field)) {
        fwrite(STDERR, "Settings validation missing field: {$field}\n");
        exit(1);
    }
}
$provider = file_get_contents($root.'/System/TitanModelCouncilServiceProvider.php');
if (!str_contains($provider, 'applyRuntimeOverrides')) {
    fwrite(STDERR, "Provider does not apply persisted settings\n");
    exit(1);
}
echo "PASS: native Super Admin control plane, child navigation and runtime settings overlay are present.\n";
