<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$migration = $root . '/database/migrations/2026_08_11_000010_add_governed_validation_fields.php';
$source = file_get_contents($migration);
if ($source === false) {
    fwrite(STDERR, "FAIL: unable to read governed validation migration\n");
    exit(1);
}

$requirements = [
    'pre_arbiter_validation_status' => 'tmc_dec_prearbiter_status_idx',
    'final_validation_status' => 'tmc_dec_final_validation_idx',
    'validation_source' => 'tmc_dec_validation_source_idx',
];

foreach ($requirements as $column => $index) {
    $hasIndex = "Schema::hasIndex('titan_model_council_decisions', '{$index}')";
    if (! str_contains($source, $hasIndex)) {
        fwrite(STDERR, "FAIL: retry-safe migration must independently check index {$index}\n");
        exit(1);
    }

    $indexPattern = "/->index\\(['\"]" . preg_quote($column, '/') . "['\"],\\s*['\"]" . preg_quote($index, '/') . "['\"]\\)/";
    if (! preg_match($indexPattern, $source)) {
        fwrite(STDERR, "FAIL: retry-safe migration must add {$index} independently for {$column}\n");
        exit(1);
    }

    $chainedPattern = "/['\"]" . preg_quote($column, '/') . "['\"][^;]*->index\\(/s";
    if (preg_match($chainedPattern, $source)) {
        fwrite(STDERR, "FAIL: {$column} still chains index creation to column creation; partial DDL retry can skip it\n");
        exit(1);
    }
}

fwrite(STDOUT, "PASS: governed validation migration repairs missing indexes independently after partial MySQL DDL\n");
