<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
$hardcodedPatterns = [
    '/(?<![A-Za-z])sk-[A-Za-z0-9_-]{16,}/',
    '/AIza[0-9A-Za-z_-]{20,}/',
];
foreach ($iterator as $file) {
    if (! $file->isFile() || ! in_array($file->getExtension(), ['php','json'], true)) {
        continue;
    }
    if (str_contains($file->getPathname(), DIRECTORY_SEPARATOR . 'legacy-source' . DIRECTORY_SEPARATOR)) {
        continue;
    }
    $contents = file_get_contents($file->getPathname());
    foreach ($hardcodedPatterns as $pattern) {
        if (preg_match($pattern, $contents)) {
            fwrite(STDERR, "FAIL: possible hard-coded provider credential in {$file->getPathname()}\n");
            exit(1);
        }
    }
}
$service = file_get_contents($root . '/System/Services/ModelCouncilExecutionService.php');
if (preg_match('/Log::(?:error|warning|info|debug)\([^;]*(headers|Authorization|api[_-]?key)/is', $service)) {
    fwrite(STDERR, "FAIL: provider credentials/request headers may be included in logs\n");
    exit(1);
}
echo "pass3_credential_audit_runner: OK\n";
