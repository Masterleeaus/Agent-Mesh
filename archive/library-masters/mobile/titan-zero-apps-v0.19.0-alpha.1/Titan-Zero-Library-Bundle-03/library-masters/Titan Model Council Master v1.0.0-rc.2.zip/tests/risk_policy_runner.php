<?php
require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/ValueObjects/CouncilActivationDecision.php';
require __DIR__ . '/../System/ValueObjects/CouncilRiskAssessment.php';
require __DIR__ . '/../System/Policies/SelectiveActivationPolicy.php';

use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

$policy = new SelectiveActivationPolicy(['enabled'=>true,'governed_deliberation_enabled'=>false,'manual_override_wins'=>true,'risk_monitoring_minimum'=>'lightweight_council']);
$request = new CouncilRequest('Review whether this action should proceed', 77, 9, metadata: ['uncertainty'=>'low']);
$risk = new CouncilRiskAssessment(true, 72.0, 'HIGH', 'REQUIRE_APPROVAL', false, true, 'baseline-v1', ['IMPACT_LEGAL']);
$decision = $policy->decide($request, $risk);
check($decision->strategy === 'parallel_consensus', 'High Risk Engine assessment must force full consensus.');
check(($decision->triggerMetadata['risk_decision'] ?? null) === 'REQUIRE_APPROVAL', 'Risk decision must be preserved in activation metadata.');
check(($decision->triggerMetadata['governance_escalation_required'] ?? false) === true, 'Approval-required risk must request governance escalation.');

$manualFull = new CouncilRequest('Review this', 77, 9, manualStrategy: 'parallel_consensus');
$monitoring = new CouncilRiskAssessment(true, 28.0, 'LOW', 'ALLOW_WITH_MONITORING', true, false, 'baseline-v1');
$fullDecision = $policy->decide($manualFull, $monitoring);
check($fullDecision->strategy === 'parallel_consensus', 'Risk floor must never downgrade a stronger manual Council strategy.');

$manualSingle = new CouncilRequest('Review this', 77, 9, manualStrategy: 'single_model');
$minimumDecision = $policy->decide($manualSingle, $monitoring);
check($minimumDecision->strategy === 'lightweight_council', 'Monitoring risk must raise a weaker manual strategy to the configured floor.');

echo "PASS pass4_risk_policy_runner\n";
