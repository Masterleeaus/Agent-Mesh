<?php

declare(strict_types=1);

require __DIR__ . '/../System/Quality/ContradictionResolver.php';

use App\Extensions\TitanModelCouncil\System\Quality\ContradictionResolver;

$resolver = new ContradictionResolver(50);
$result = $resolver->apply([
    'confidence_percent' => 92,
    'disagreements' => [
        'OpenAI: Yes, the action is permitted.',
        'Claude: No, the action is not permitted.',
    ],
    'final_answer' => 'Proceed.',
], true);

assert($result['strong_contradiction'] === true);
assert($result['confidence_percent'] <= 49);
assert($result['requires_escalation'] === true);
assert(str_contains($result['final_answer'], 'Models strongly disagree'));

$normal = $resolver->apply([
    'confidence_percent' => 88,
    'disagreements' => ['Models prefer different wording.'],
    'final_answer' => 'Either wording is acceptable.',
], false);
assert($normal['strong_contradiction'] === false);
assert($normal['confidence_percent'] === 88);


$negativeOnly = $resolver->apply([
    'confidence_percent' => 75,
    'disagreements' => [
        'Model A says this should not proceed.',
        'Model B says this is not allowed until approval.',
    ],
    'final_answer' => 'Do not proceed.',
], true);
assert($negativeOnly['strong_contradiction'] === false);

assert($resolver->detectInModelResults([
    ['failed' => false, 'response_text' => 'Yes, this is permitted.'],
    ['failed' => false, 'response_text' => 'No, this is not permitted.'],
]) === true);

echo "pass3_contradiction_runner: OK\n";
