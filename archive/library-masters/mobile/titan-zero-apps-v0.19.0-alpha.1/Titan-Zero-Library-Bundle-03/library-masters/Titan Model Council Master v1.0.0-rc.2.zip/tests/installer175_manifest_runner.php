<?php

declare(strict_types=1);

$root = dirname(__DIR__);
$manifestPath = $root . '/extension.json';
$manifest = json_decode((string) file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);

$requiredStrings = ['schema', 'slug', 'version', 'folder', 'provider'];
foreach ($requiredStrings as $key) {
    if (!isset($manifest[$key]) || !is_string($manifest[$key]) || trim($manifest[$key]) === '') {
        fwrite(STDERR, "FAIL: extension.json is missing a valid '{$key}' value.\n");
        exit(1);
    }
}
if ($manifest['schema'] !== 'titan-extension-v1') {
    fwrite(STDERR, "FAIL: unsupported schema\n"); exit(1);
}
foreach (['requires', 'uninstall', 'integrity'] as $key) {
    if (!isset($manifest[$key]) || !is_array($manifest[$key])) {
        fwrite(STDERR, "FAIL: Installer 1.7.8 '{$key}' object is missing.\n"); exit(1);
    }
}
foreach (['php', 'laravel', 'magicai'] as $key) {
    if (!isset($manifest['requires'][$key]) || !is_string($manifest['requires'][$key]) || trim($manifest['requires'][$key]) === '') {
        fwrite(STDERR, "FAIL: requires.{$key} is missing.\n"); exit(1);
    }
}
if (!array_key_exists('migrations', $manifest) || !is_bool($manifest['migrations'])) {
    fwrite(STDERR, "FAIL: migrations must be boolean.\n"); exit(1);
}
if (!isset($manifest['uninstall']['preserve_data']) || !is_bool($manifest['uninstall']['preserve_data'])) {
    fwrite(STDERR, "FAIL: uninstall.preserve_data must be boolean.\n"); exit(1);
}
if (!isset($manifest['integrity']['files']) || !is_array($manifest['integrity']['files'])) {
    fwrite(STDERR, "FAIL: integrity.files is missing.\n"); exit(1);
}
if (array_key_exists('name', $manifest)) {
    fwrite(STDERR, "FAIL: Installer 1.7.8 root manifest must not contain legacy name.\n"); exit(1);
}
if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $manifest['slug'])) {
    fwrite(STDERR, "FAIL: invalid slug\n"); exit(1);
}
if (!preg_match('/^[A-Za-z][A-Za-z0-9_]*$/', $manifest['folder'])) {
    fwrite(STDERR, "FAIL: invalid folder\n"); exit(1);
}
if (!preg_match('/^\d+\.\d+(?:\.\d+)?(?:[-+][0-9A-Za-z.-]+)?$/', $manifest['version'])) {
    fwrite(STDERR, "FAIL: invalid semver\n"); exit(1);
}
$prefix = 'App\\Extensions\\' . $manifest['folder'] . '\\';
if (!str_starts_with($manifest['provider'], $prefix)) {
    fwrite(STDERR, "FAIL: provider namespace mismatch\n"); exit(1);
}
echo "PASS: Installer 1.7.8 manifest contract\n";
