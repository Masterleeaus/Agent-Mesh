<?php
$root = dirname(__DIR__);
$bridge = file_get_contents($root . '/System/Shield/TitanShieldInspectionBridge.php');
foreach (['ShieldManagerContract', 'ShieldExecutionContext', 'evaluateInspection', 'InspectionEngineContract'] as $needle) {
    if (!str_contains($bridge, $needle)) { fwrite(STDERR, "Missing Shield v0.5/fallback marker: {$needle}\n"); exit(1); }
}
echo "PASS pass6_shield_v05_runner\n";
