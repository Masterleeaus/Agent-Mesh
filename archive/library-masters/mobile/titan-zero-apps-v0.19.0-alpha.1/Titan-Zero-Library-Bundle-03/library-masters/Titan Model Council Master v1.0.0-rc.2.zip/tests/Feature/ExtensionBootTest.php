<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_manifest_matches_compatibility_hardened_build(): void
    {
        $manifest = json_decode(
            file_get_contents(__DIR__ . '/../../extension.manifest.json'),
            true,
            512,
            JSON_THROW_ON_ERROR,
        );

        self::assertSame('titan-model-council', $manifest['key']);
        self::assertSame('0.4.0', $manifest['version']);
        self::assertContains('council.parallel-consensus', $manifest['capabilities']);
        self::assertContains('council.selective-activation', $manifest['capabilities']);
        self::assertContains('council.billing-reservation', $manifest['capabilities']);
        self::assertContains('model_council_responses', $manifest['database']['owned_tables']);
        self::assertContains('titan_model_council_billing_reservations', $manifest['database']['owned_tables']);
        self::assertContains('user_openai_chat_messages', $manifest['database']['shared_tables']);
    }
}
