<?php

declare(strict_types=1);

require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/ValueObjects/CouncilActivationDecision.php';
require __DIR__ . '/../System/ValueObjects/CouncilRiskAssessment.php';
require __DIR__ . '/../System/Policies/SelectiveActivationPolicy.php';

use App\Extensions\TitanModelCouncil\System\Policies\SelectiveActivationPolicy;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRiskAssessment;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

$policy = new SelectiveActivationPolicy([
    'enabled' => true,
    'manual_override_wins' => true,
    'governed_deliberation_enabled' => true,
    'risk_monitoring_minimum' => 'lightweight_council',
    'high_consequence_actions' => ['delete', 'refund', 'pay', 'approve'],
]);

$highConsequence = new CouncilRequest('Approve and pay this refund', 77, 9);
$decision = $policy->decide($highConsequence);
check($decision->strategy === 'governed_deliberation', 'High-consequence actions must enter governed deliberation when enabled.');
check($decision->requestedParticipants === 4, 'Governed deliberation requires four role participants.');

$risk = new CouncilRiskAssessment(true, 72.0, 'HIGH', 'REQUIRE_APPROVAL', false, true, 'baseline-v1');
$decision = $policy->decide(new CouncilRequest('Review this action', 77, 9), $risk);
check($decision->strategy === 'governed_deliberation', 'Approval-required Risk must raise Council depth to governed deliberation.');
check(($decision->triggerMetadata['execution_authority'] ?? null) === 'reduced', 'Approval-required Risk must preserve reduced execution authority.');

$blocked = new CouncilRiskAssessment(true, 99.0, 'EXTREME', 'BLOCK', false, true, 'baseline-v1');
$decision = $policy->decide(new CouncilRequest('Review this action', 77, 9), $blocked);
check($decision->strategy === 'governed_deliberation', 'Blocked Risk may still permit analysis through governed deliberation.');
check(($decision->triggerMetadata['execution_authority'] ?? null) === 'blocked', 'BLOCK must remain blocked after Council activation.');

echo "PASS pass5_governed_activation_runner\n";
