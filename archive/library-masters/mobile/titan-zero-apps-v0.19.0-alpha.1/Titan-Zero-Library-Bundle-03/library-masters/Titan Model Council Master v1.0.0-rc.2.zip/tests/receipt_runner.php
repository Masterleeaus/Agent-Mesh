<?php
$root = dirname(__DIR__);
foreach ([
    '/System/Receipts/CouncilDecisionReceiptService.php',
    '/System/Models/CouncilReceiptRecord.php',
    '/database/migrations/2026_08_19_000012_create_titan_model_council_receipts.php',
] as $rel) {
    if (!is_file($root . $rel)) { fwrite(STDERR, "Missing receipt artifact {$rel}\n"); exit(1); }
}
$s = file_get_contents($root . '/System/Receipts/CouncilDecisionReceiptService.php');
foreach (['receipt_hash', 'root_causation_id', 'advisory_only', 'canonicalize'] as $needle) {
    if (!str_contains($s, $needle)) { fwrite(STDERR, "Missing receipt marker {$needle}\n"); exit(1); }
}
$runtime = file_get_contents($root . '/System/Governed/GovernedCouncilRuntime.php');
if (!str_contains($runtime, "['receipt']")) { fwrite(STDERR, "Runtime does not return receipt\n"); exit(1); }
echo "PASS pass6_receipt_runner\n";
