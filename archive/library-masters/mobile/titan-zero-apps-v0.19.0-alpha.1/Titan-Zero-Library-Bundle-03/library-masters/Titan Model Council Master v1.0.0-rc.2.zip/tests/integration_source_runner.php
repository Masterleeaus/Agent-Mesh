<?php

declare(strict_types=1);

$provider = file_get_contents(__DIR__ . '/../System/TitanModelCouncilServiceProvider.php');
$controller = file_get_contents(__DIR__ . '/../System/Http/Controllers/ModelCouncilActionController.php');
$service = file_get_contents(__DIR__ . '/../System/Services/ModelCouncilExecutionService.php');
$config = file_get_contents(__DIR__ . '/../config/titan-model-council.php');
$migration = file_get_contents(__DIR__ . '/../database/migrations/2026_08_11_000005_expand_titan_model_council_decisions.php');

$checks = [
    [$provider, 'SelectiveActivationPolicy::class'],
    [$controller, "where('company_id'"],
    [$controller, 'CompanyContextResolver'],
    [$service, 'CouncilBillingReservationService'],
    [$service, "'company_id'"],
    [$service, 'ContradictionResolver'],
    [$config, "'reserve_execute_settle'"],
    [$migration, "'activation_reason'"],
    [$migration, "'trigger_metadata'"],
];
foreach ($checks as [$haystack, $needle]) {
    if (! str_contains($haystack, $needle)) {
        fwrite(STDERR, "FAIL missing integration marker: {$needle}\n");
        exit(1);
    }
}

echo "pass3_integration_source_runner: OK\n";
