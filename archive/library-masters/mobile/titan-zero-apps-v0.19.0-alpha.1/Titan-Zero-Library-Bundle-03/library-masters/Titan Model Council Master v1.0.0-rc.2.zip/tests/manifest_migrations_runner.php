<?php

declare(strict_types=1);

$manifest = json_decode(file_get_contents(__DIR__ . '/../extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$extension = json_decode(file_get_contents(__DIR__ . '/../extension.json'), true, 512, JSON_THROW_ON_ERROR);

if (($manifest['version'] ?? null) !== '1.0.0-rc.2' || ($extension['version'] ?? null) !== '1.0.0-rc.2') {
    fwrite(STDERR, "FAIL: package version must be 1.0.0-rc.2\n");
    exit(1);
}
$owned = $manifest['database']['owned_tables'] ?? [];
$shared = $manifest['database']['shared_tables'] ?? [];
if (! in_array('model_council_responses', $owned, true)) {
    fwrite(STDERR, "FAIL: compatibility response table is not declared\n");
    exit(1);
}
if (! in_array('user_openai_chat_messages', $shared, true)) {
    fwrite(STDERR, "FAIL: shared legacy chat table mutation is not declared\n");
    exit(1);
}

$requiredMigrations = [
    __DIR__ . '/../database/migrations/2026_08_11_000002_add_council_columns_to_user_openai_chat_messages.php',
    __DIR__ . '/../database/migrations/2026_08_11_000003_create_model_council_responses_table.php',
    __DIR__ . '/../database/migrations/2026_08_11_000004_add_causation_id_to_titan_model_council_decisions.php',
    __DIR__ . '/../database/migrations/2026_08_11_000005_expand_titan_model_council_decisions.php',
    __DIR__ . '/../database/migrations/2026_08_11_000006_create_titan_model_council_billing_reservations.php',
    __DIR__ . '/../database/migrations/2026_08_11_000008_add_risk_assessment_fields_to_council_decisions.php',
];
foreach ($requiredMigrations as $path) {
    if (! is_file($path)) {
        fwrite(STDERR, "FAIL: missing migration {$path}\n");
        exit(1);
    }
}

echo "pass2 manifest/migration checks passed\n";
