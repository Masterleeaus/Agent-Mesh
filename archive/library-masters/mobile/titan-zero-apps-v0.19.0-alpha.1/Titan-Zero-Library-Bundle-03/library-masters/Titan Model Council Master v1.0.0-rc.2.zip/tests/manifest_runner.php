<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$config = file_get_contents($root . '/config/titan-model-council.php');
$migrations = glob($root . '/database/migrations/*.php') ?: [];

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
check(($manifest['version'] ?? null) === '1.0.0-rc.2', 'Manifest must preserve the Blueprint v4.2 rebase in the v1.0.0-rc.2 release candidate.');
check(in_array('council.governed-deliberation', $manifest['capabilities'] ?? [], true), 'Manifest must advertise implemented governed deliberation.');
$optionalPeers = array_values(array_filter(array_map(static fn ($dependency) => is_array($dependency) ? ($dependency['key'] ?? null) : $dependency, $manifest['dependencies']['optional'] ?? [])));
check(in_array('titan-shield', $optionalPeers, true), 'Titan Shield must remain an optional governed peer.');
check(str_contains($config, "'governed_deliberation_enabled' => true"), 'Governed activation must be enabled in configuration.');
check(count(array_filter($migrations, static fn ($p) => str_contains($p, '000009_create_titan_model_council_participants'))) === 1, 'Participant audit migration must be packaged.');

echo "PASS pass5_manifest_runner\n";
