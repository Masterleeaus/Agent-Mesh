<?php

declare(strict_types=1);

require __DIR__ . '/../System/Company/CompanyContext.php';
require __DIR__ . '/../System/Company/CompanyIdResolver.php';

use App\Extensions\TitanModelCouncil\System\Company\CompanyIdResolver;

$r = new CompanyIdResolver();
assert($r->resolve(['company_id' => 44], ['company_id' => 55]) === 44);
assert($r->resolve([], ['company_id' => 55]) === 55);
assert($r->resolve(['company_id' => 0], ['company_id' => null]) === null);
assert($r->resolve(['company_id' => 99], []) === null); // never confuse CRM customer company_id with company_id

echo "pass3_tenant_context_runner: OK\n";
