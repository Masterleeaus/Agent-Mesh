<?php

declare(strict_types=1);

require __DIR__ . '/../System/Billing/CouncilReservation.php';

use App\Extensions\TitanModelCouncil\System\Billing\CouncilReservation;

$r = CouncilReservation::reserve('res_1', 42, 7, 100);
assert($r->status === 'reserved');
assert($r->reservedCredits === 100);
assert($r->settledCredits === 0);
assert($r->remainingCredits() === 100);

$r = $r->settle(64);
assert($r->status === 'settled');
assert($r->settledCredits === 64);
assert($r->releasedCredits === 36);
assert($r->remainingCredits() === 0);

$failed = CouncilReservation::reserve('res_2', 42, 7, 30)->release('provider_failure');
assert($failed->status === 'released');
assert($failed->releasedCredits === 30);
assert($failed->releaseReason === 'provider_failure');

$thrown = false;
try {
    CouncilReservation::reserve('res_3', 42, 7, 10)->settle(11);
} catch (InvalidArgumentException) {
    $thrown = true;
}
assert($thrown === true);

echo "pass3_billing_state_runner: OK\n";
