<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$gateway = file_get_contents($root . '/System/Risk/TitanRiskEngineGateway.php');
$council = file_get_contents($root . '/System/Services/CouncilGateway.php');
$repo = file_get_contents($root . '/System/Persistence/CouncilDecisionRepository.php');
$probe = file_get_contents($root . '/System/AICore/AICoreRuntimeProbe.php');

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
check(str_contains($gateway, 'RiskManagerContract'), 'Risk adapter must target the published RiskManagerContract.');
check(str_contains($gateway, "capability: 'council.deliberate'"), 'Risk context must identify Council capability.');
check(str_contains($council, 'assessBefore'), 'Council must perform preflight risk assessment.');
check(str_contains($council, 'assessAfter'), 'Council must perform postflight risk assessment.');
check(str_contains($repo, "->where('company_id', \$companyId)"), 'Decision completion must remain tenant scoped.');
check(str_contains($probe, 'ai-core-has-no-published-execution-contract'), 'AI Core probe must explicitly report missing runtime contract.');
check(! str_contains($probe, "method_exists(\$manager, 'execute')"), 'Council must not invent an AI Core execute method.');
echo "PASS pass4_integration_source_runner\n";
