<?php

declare(strict_types=1);

$source = file_get_contents(__DIR__ . '/../System/Company/CompanyContextResolver.php');
if (str_contains($source, "input('company_id')")) {
    fwrite(STDERR, "FAIL: company_id must never be trusted from raw request input\n");
    exit(1);
}
if (! str_contains($source, "attributes->get('company_id')")) {
    fwrite(STDERR, "FAIL: trusted middleware tenant attribute support missing\n");
    exit(1);
}
echo "pass3_tenant_trust_runner: OK\n";
