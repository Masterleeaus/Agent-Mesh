<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$bridge = file_get_contents($root . '/System/Shield/TitanShieldInspectionBridge.php');
$gate = file_get_contents($root . '/System/Shield/ShieldAwareCouncilGate.php');
$probe = file_get_contents($root . '/System/Shield/ShieldRuntimeProbe.php');
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
check(str_contains($bridge, 'InspectionEngineContract'), 'Council must target Shield published InspectionEngineContract.');
foreach (['createRun(', '->start(', '->submitForVerification(', '->recordVerification('] as $needle) {
    check(str_contains($bridge, $needle), 'Shield bridge missing lifecycle call: ' . $needle);
}
check(! str_contains($gate, '->validateCouncil('), 'Council must not invent a Shield validateCouncil API.');
check(str_contains($probe, "'semantic_validation_execution_used' => false"), 'Probe must not claim semantic Shield validation is executed.');
check(in_array('council.shield-inspection-bridge', $manifest['capabilities'] ?? [], true), 'Manifest must advertise the implemented Shield inspection bridge.');

echo "PASS pass5_shield_peer_runner\n";
