<?php
$root = dirname(__DIR__);
$path = $root . '/System/Assurance/CouncilAssuranceBridge.php';
if (!is_file($path)) { fwrite(STDERR, "CouncilAssuranceBridge missing\n"); exit(1); }
$s = file_get_contents($path);
foreach (['EvidenceAssuranceEngine', 'assess(', 'assurance-band', 'idempotency_key'] as $needle) {
    if (!str_contains($s, $needle)) { fwrite(STDERR, "Missing Assurance bridge marker: {$needle}\n"); exit(1); }
}
$runtime = file_get_contents($root . '/System/Governed/GovernedCouncilRuntime.php');
if (!str_contains($runtime, 'CouncilAssuranceBridge') || !str_contains($runtime, "['assurance']")) {
    fwrite(STDERR, "Governed runtime is not assurance-aware\n"); exit(1);
}
echo "PASS pass6_assurance_runner\n";
