<?php

declare(strict_types=1);

$root = realpath(__DIR__ . '/..');
$runtime = file_get_contents($root . '/System/Governed/GovernedCouncilRuntime.php');
$controller = file_get_contents($root . '/System/Http/Controllers/GovernedController.php');
$legacy = file_get_contents($root . '/System/Services/ModelCouncilExecutionService.php');
$repo = file_get_contents($root . '/System/Persistence/CouncilDecisionRepository.php');

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

$reserve = strpos($runtime, 'reserveGoverned(');
$deliberate = strpos($runtime, 'orchestrator->deliberate');
$settle = strpos($runtime, 'billing->settle');
$postRisk = strpos($runtime, 'risk->assessAfter');
check($reserve !== false && $deliberate !== false && $reserve < $deliberate, 'Governed credits must be reserved before any role provider execution.');
check($settle !== false && $postRisk !== false && $settle < $postRisk, 'Known actual provider usage must settle before later audit/risk work can fail.');
check(! str_contains($controller, "'company_id' => ['"), 'Native governed endpoint must never accept company_id as request input.');
check(str_contains($legacy, 'governedModelPreflight'), 'Legacy provider boundary must preflight every governed model.');
check(str_contains($legacy, 'council_access_denied'), 'Governed execution must enforce Council plan/access entitlement, not only model entitlement.');
check(str_contains($runtime, "'advisory_only'"), 'Governed Council must never grant downstream mutation authority by itself.');
check(str_contains($repo, "->where('company_id', \$companyId)"), 'Decision completion must remain tenant scoped.');

echo "PASS pass5_runtime_source_runner\n";
