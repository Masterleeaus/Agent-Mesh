<?php
$root = dirname(__DIR__);
$emitter = file_get_contents($root . '/System/Signal/CouncilSignalEmitter.php');
$provider = file_get_contents($root . '/System/TitanModelCouncilServiceProvider.php');
$registration = $root . '/System/Signal/SignalPeerRegistration.php';
$need = [
    'SignalEmitterAuthorityContract',
    'SignalContext',
    'tenantHuman',
    'emit($signal, $context)',
];
foreach ($need as $needle) {
    if (!str_contains($emitter, $needle)) {
        fwrite(STDERR, "Missing current Signal v0.20 integration marker: {$needle}\n"); exit(1);
    }
}
if (!is_file($registration)) { fwrite(STDERR, "SignalPeerRegistration missing\n"); exit(1); }
$reg = file_get_contents($registration);
foreach (['trusted_emitters', 'titan-model-council', 'event_types', 'council.deliberation.completed'] as $needle) {
    if (!str_contains($reg, $needle)) { fwrite(STDERR, "Missing peer registration marker: {$needle}\n"); exit(1); }
}
if (!str_contains($provider, 'SignalPeerRegistration::register')) { fwrite(STDERR, "Provider does not register Signal peer definitions\n"); exit(1); }
echo "PASS pass6_signal_v020_runner\n";
