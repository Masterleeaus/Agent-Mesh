<?php
$root = dirname(__DIR__);
$m = json_decode(file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
if (($m['version'] ?? '') !== '1.0.0-rc.2') { fwrite(STDERR, "Wrong manifest version\n"); exit(1); }
$caps = $m['capabilities'] ?? [];
foreach (['council.signal-v020', 'council.assurance-boundary', 'council.rewind-receipt'] as $cap) {
    if (!in_array($cap, $caps, true)) { fwrite(STDERR, "Missing capability {$cap}\n"); exit(1); }
}
$optional = array_column($m['dependencies']['optional'] ?? [], 'key');
if (!in_array('titan-assurance', $optional, true)) { fwrite(STDERR, "Titan Assurance optional dependency missing\n"); exit(1); }
if (!in_array('titan-shield', $optional, true)) { fwrite(STDERR, "Titan Shield optional dependency missing\n"); exit(1); }
echo "PASS pass6_manifest_rc_runner\n";
