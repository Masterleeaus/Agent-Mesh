<?php
require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/ValueObjects/CouncilRiskAssessment.php';
require __DIR__ . '/../System/Risk/CouncilRiskGatewayContract.php';
require __DIR__ . '/../System/Risk/NullCouncilRiskGateway.php';

use App\Extensions\TitanModelCouncil\System\Risk\NullCouncilRiskGateway;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }
$r = new CouncilRequest('hello', 3, 4, traceId:'t', correlationId:'c', causationId:'z');
$assessment = (new NullCouncilRiskGateway())->assessBefore($r);
check($assessment->available === false, 'Null risk adapter must explicitly report unavailable.');
check($assessment->level === 'UNKNOWN', 'Null risk level must be UNKNOWN.');
check($assessment->requiresEscalation === false, 'Risk absence must not silently invent escalation.');
echo "PASS pass4_risk_adapter_runner\n";
