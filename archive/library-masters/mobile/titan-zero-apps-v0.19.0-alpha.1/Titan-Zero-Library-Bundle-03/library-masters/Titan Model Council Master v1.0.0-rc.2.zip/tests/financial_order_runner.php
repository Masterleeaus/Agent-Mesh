<?php

declare(strict_types=1);

$source = file_get_contents(__DIR__ . '/../System/Services/ModelCouncilExecutionService.php');
$methodStart = strpos($source, 'public function generateCouncilResponse');
$methodEnd = strpos($source, 'private function allowedModelSlugsForUser', $methodStart);
$method = substr($source, $methodStart, $methodEnd - $methodStart);
$reserve = strpos($method, '$this->billingReservations->reserve(');
$execute = strpos($method, '$this->executeParallelCalls(');
$settle = strpos($method, '$this->billingReservations->settle(');
if ($reserve === false || $execute === false || $settle === false || ! ($reserve < $execute && $execute < $settle)) {
    fwrite(STDERR, "FAIL: non-streaming flow must reserve before execute and settle after execution\n");
    exit(1);
}
if (! str_contains($method, 'Every selected Council model must have available credit before execution.') && ! str_contains($source, 'Every selected Council model must have available credit before execution.')) {
    fwrite(STDERR, "FAIL: every participant must pass credit preflight\n");
    exit(1);
}
echo "pass3_financial_order_runner: OK\n";
