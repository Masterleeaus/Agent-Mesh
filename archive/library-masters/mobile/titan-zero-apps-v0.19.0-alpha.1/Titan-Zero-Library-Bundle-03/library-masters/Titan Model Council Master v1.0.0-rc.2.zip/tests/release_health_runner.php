<?php
$root = dirname(__DIR__);
$health = file_get_contents($root . '/System/Health/TitanModelCouncilHealthCheck.php');
$cert = file_get_contents($root . '/System/Commands/CertifyExtensionCommand.php');
$shield = file_get_contents($root . '/System/Shield/ShieldAwareCouncilGate.php');
foreach (['database.receipts', 'titan_model_council_receipts', 'assurance'] as $needle) {
    if (!str_contains($health, $needle)) { fwrite(STDERR, "Health missing release marker {$needle}\n"); exit(1); }
}
if (!str_contains($cert, "'titan_model_council_receipts'")) {
    fwrite(STDERR, "Certification does not require receipt table\n"); exit(1);
}
if (!str_contains($shield, 'inspection_bridge_available')) {
    fwrite(STDERR, "Shield status does not expose inspection bridge availability\n"); exit(1);
}
echo "PASS pass6_release_health_runner\n";
