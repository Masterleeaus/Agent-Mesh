<?php

declare(strict_types=1);

require __DIR__ . '/../System/ValueObjects/CouncilRequest.php';
require __DIR__ . '/../System/Governed/CouncilRole.php';
require __DIR__ . '/../System/Governed/ParticipantResult.php';
require __DIR__ . '/../System/Governed/GovernedDeliberationResult.php';
require __DIR__ . '/../System/Governed/CouncilParticipantExecutorContract.php';
require __DIR__ . '/../System/Shield/ShieldValidationResult.php';
require __DIR__ . '/../System/Shield/CouncilShieldGateContract.php';
require __DIR__ . '/../System/Governed/GovernedDeliberationOrchestrator.php';

use App\Extensions\TitanModelCouncil\System\Governed\CouncilParticipantExecutorContract;
use App\Extensions\TitanModelCouncil\System\Governed\CouncilRole;
use App\Extensions\TitanModelCouncil\System\Governed\GovernedDeliberationOrchestrator;
use App\Extensions\TitanModelCouncil\System\Governed\ParticipantResult;
use App\Extensions\TitanModelCouncil\System\Shield\CouncilShieldGateContract;
use App\Extensions\TitanModelCouncil\System\Shield\ShieldValidationResult;
use App\Extensions\TitanModelCouncil\System\ValueObjects\CouncilRequest;

function check(bool $ok, string $message): void { if (! $ok) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } }

final class FakeExecutor implements CouncilParticipantExecutorContract
{
    /** @var array<int,string> */ public array $roles = [];
    public function execute(CouncilRequest $request, CouncilRole $role, string $modelSlug, string $instruction, array $priorArtifacts = []): ParticipantResult
    {
        $this->roles[] = $role->value;
        $text = match ($role) {
            CouncilRole::PROPOSER => 'Proposed answer with assumptions.',
            CouncilRole::CRITIC => 'Critique: one assumption needs caution.',
            CouncilRole::VERIFIER => 'Verification: supplied evidence is internally consistent but external facts remain unverified.',
            CouncilRole::ARBITER => 'Final governed answer with the uncertainty disclosed.',
        };
        return ParticipantResult::success($role, $modelSlug, $text, 80, 10);
    }
}

final class FakeShield implements CouncilShieldGateContract
{
    /** @var array<int,string> */ public array $stages = [];
    public function validate(string $stage, CouncilRequest $request, array $artifacts): ShieldValidationResult
    {
        $this->stages[] = $stage;
        return ShieldValidationResult::pass($stage, 'test-shield');
    }
    public function status(): array { return ['source' => 'test-shield', 'external_available' => false]; }
}

$executor = new FakeExecutor();
$shield = new FakeShield();
$orchestrator = new GovernedDeliberationOrchestrator($executor, $shield);
$request = new CouncilRequest('Should this consequential action proceed?', 44, 8);
$result = $orchestrator->deliberate($request, [
    'proposer' => 'model-a',
    'critic' => 'model-b',
    'verifier' => 'model-c',
    'arbiter' => 'model-d',
]);

check($result->status === 'completed', 'Governed deliberation should complete when all roles and gates pass.');
check($executor->roles === ['proposer', 'critic', 'verifier', 'arbiter'], 'Roles must execute in proposer→critic→verifier→arbiter order.');
check($shield->stages === ['pre_arbiter', 'final'], 'Shield gate must run before arbiter and after arbiter.');
check($result->finalAnswer === 'Final governed answer with the uncertainty disclosed.', 'Arbiter output must become the final governed answer.');
check($result->actualParticipantCount === 4, 'All four successful roles must be counted.');

final class BlockingShield implements CouncilShieldGateContract
{
    public function validate(string $stage, CouncilRequest $request, array $artifacts): ShieldValidationResult
    {
        return $stage === 'pre_arbiter'
            ? ShieldValidationResult::block($stage, ['pre_validation_failed'], 'test-shield')
            : ShieldValidationResult::pass($stage, 'test-shield');
    }
    public function status(): array { return ['source' => 'test-shield', 'external_available' => false]; }
}
$executor2 = new FakeExecutor();
$blockedResult = (new GovernedDeliberationOrchestrator($executor2, new BlockingShield()))->deliberate($request, [
    'proposer' => 'model-a', 'critic' => 'model-b', 'verifier' => 'model-c', 'arbiter' => 'model-d',
]);
check($blockedResult->status === 'blocked', 'Pre-arbiter Shield failure must block arbitration.');
check($executor2->roles === ['proposer', 'critic', 'verifier'], 'Arbiter must not run after pre-validation blocks.');
check($blockedResult->requiresEscalation === true, 'Blocked governed deliberation must require escalation.');

echo "PASS pass5_governed_orchestrator_runner\n";
