<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;

final class BoundaryTest extends TestCase
{
    public function test_active_compatibility_controller_does_not_use_unsafe_legacy_group_delete(): void
    {
        $source = file_get_contents(__DIR__ . '/../../System/Http/Controllers/ModelCouncilActionController.php');

        self::assertIsString($source);
        self::assertStringContainsString("->where('company_id', \$companyId)", $source);
        self::assertStringContainsString("->where('user_id', \$actorId)", $source);
        self::assertStringContainsString("->where('user_openai_chat_id', \$scope['user_openai_chat_id'])", $source);
        self::assertStringNotContainsString("where('shared_uuid', \$message->shared_uuid)", $source);
    }

    public function test_active_legacy_engine_uses_titan_namespace(): void
    {
        $source = file_get_contents(__DIR__ . '/../../System/Services/ModelCouncilExecutionService.php');

        self::assertIsString($source);
        self::assertStringContainsString('namespace App\\Extensions\\TitanModelCouncil\\System\\Compatibility\\Legacy\\Services;', $source);
        self::assertStringNotContainsString('use App\\Extensions\\ModelCouncil\\System\\Models\\ModelCouncilResponse;', $source);
    }
}
