@extends('panel.layout.app')

@section('content')
<div class="container py-8">
        <h1>Titan Wisdom Engine — Admin</h1>
        <p><strong>Version:</strong> {{ $health['version'] }}</p>
        <p><strong>Runtime:</strong> {{ $health['status'] }}</p>
        <p><strong>Operational scope:</strong> {{ $readiness['operational_scope'] }}</p>
        <p><strong>Foundation ready:</strong> {{ $readiness['ready'] ? 'yes' : 'no' }}</p>
        <p>No outcome mutation, learning, calibration, or authority-changing control is exposed in this pass.</p>
    </div>
@endsection
