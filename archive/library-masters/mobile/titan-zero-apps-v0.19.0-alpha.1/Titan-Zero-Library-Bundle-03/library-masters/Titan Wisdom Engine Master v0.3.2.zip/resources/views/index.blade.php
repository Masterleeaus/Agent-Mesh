@extends('panel.layout.app')

@section('content')
<div class="container py-8">
        <h1>Titan Wisdom Engine</h1>
        <p>Outcome attribution and learning engine that converts real-world results into calibrated institutional wisdom.</p>
        <p><strong>Foundation:</strong> v{{ $health['version'] }} — {{ $health['status'] }}.</p>
        <p>The outcome, attribution, learning and calibration capabilities remain intentionally unavailable until their governed contracts are implemented.</p>
    </div>
@endsection
