<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Security;

use PHPUnit\Framework\TestCase;

final class OutcomeTenantIsolationTest extends TestCase
{
    public function test_repository_lookups_are_always_tenant_scoped(): void
    {
        $repository = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Repositories/DatabaseOutcomeRecordRepository.php');

        self::assertStringContainsString("->where('company_id', $companyId)", $repository);
        self::assertStringContainsString("->where('operation_id', $operationId)", $repository);
        self::assertStringNotContainsString("table('titan_wisdom_outcomes')", $repository);
    }

    public function test_canonical_table_requires_non_nullable_causal_context(): void
    {
        $migration = (string) file_get_contents(dirname(__DIR__, 2) . '/database/migrations/2026_08_19_000004_create_titan_wisdom_outcome_records_table.php');

        self::assertStringContainsString("\$table->unsignedBigInteger('company_id');", $migration);
        foreach (['trace_id', 'correlation_id', 'causation_id', 'root_causation_id'] as $column) {
            self::assertStringContainsString("\$table->uuid('{$column}');", $migration);
        }
    }
}
