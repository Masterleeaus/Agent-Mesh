<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Unit;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

require_once dirname(__DIR__, 2) . '/System/Context/WisdomExecutionContext.php';
require_once dirname(__DIR__, 2) . '/System/Governance/GovernanceDisposition.php';
require_once dirname(__DIR__, 2) . '/System/Governance/WisdomGovernedOperation.php';
require_once dirname(__DIR__, 2) . '/System/Governance/GovernanceDecision.php';
require_once dirname(__DIR__, 2) . '/System/Governance/GovernanceGateResult.php';
require_once dirname(__DIR__, 2) . '/System/Contracts/WisdomGovernanceGateContract.php';
require_once dirname(__DIR__, 2) . '/System/Services/WisdomGovernanceGate.php';

final class GovernanceGateTest extends TestCase
{
    private WisdomExecutionContext $context;
    private WisdomGovernanceGate $gate;

    protected function setUp(): void
    {
        $this->context = new WisdomExecutionContext(
            42,
            '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        );
        $this->gate = new WisdomGovernanceGate();
    }

    public function test_fresh_allow_for_same_tenant_and_operation_is_accepted(): void
    {
        $decision = $this->decision(GovernanceDisposition::ALLOW);

        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::OUTCOME_RECORD,
            $decision,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertTrue($result->allowed);
        self::assertSame('governance_allow', $result->reasonCode);
    }

    public function test_require_approval_is_not_allow(): void
    {
        $decision = $this->decision(GovernanceDisposition::REQUIRE_APPROVAL);

        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::OUTCOME_RECORD,
            $decision,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertFalse($result->allowed);
        self::assertSame('approval_required', $result->reasonCode);
    }

    public function test_missing_decision_fails_closed(): void
    {
        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::OUTCOME_RECORD,
            null,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertFalse($result->allowed);
        self::assertSame('governance_decision_missing', $result->reasonCode);
    }

    public function test_cross_tenant_decision_is_rejected(): void
    {
        $decision = $this->decision(GovernanceDisposition::ALLOW, companyId: 99);

        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::OUTCOME_RECORD,
            $decision,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertFalse($result->allowed);
        self::assertSame('governance_tenant_mismatch', $result->reasonCode);
    }

    public function test_expired_decision_is_rejected(): void
    {
        $decision = $this->decision(
            GovernanceDisposition::ALLOW,
            validUntil: new DateTimeImmutable('2026-08-19T00:24:00+10:00'),
        );

        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::OUTCOME_RECORD,
            $decision,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertFalse($result->allowed);
        self::assertSame('governance_decision_expired', $result->reasonCode);
    }


    public function test_hold_and_deny_remain_blocked(): void
    {
        foreach ([GovernanceDisposition::HOLD, GovernanceDisposition::DENY] as $disposition) {
            $result = $this->gate->evaluate(
                $this->context,
                WisdomGovernedOperation::OUTCOME_RECORD,
                $this->decision($disposition),
                new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
            );

            self::assertFalse($result->allowed);
        }
    }

    public function test_operation_mismatch_and_stale_or_future_decisions_are_rejected(): void
    {
        $now = new DateTimeImmutable('2026-08-19T00:25:00+10:00');

        self::assertSame(
            'governance_operation_mismatch',
            $this->gate->evaluate(
                $this->context,
                WisdomGovernedOperation::EVIDENCE_ATTACH,
                $this->decision(GovernanceDisposition::ALLOW),
                $now,
            )->reasonCode,
        );

        $stale = new GovernanceDecision(
            '0198a8d0-4a22-7b31-9b4c-7429136e23d2',
            42,
            WisdomGovernedOperation::OUTCOME_RECORD,
            GovernanceDisposition::ALLOW,
            'governance-policy-v1',
            new DateTimeImmutable('2026-08-19T00:19:59+10:00'),
            new DateTimeImmutable('2026-08-19T00:30:00+10:00'),
        );
        self::assertSame('governance_decision_stale', $this->gate->evaluate($this->context, WisdomGovernedOperation::OUTCOME_RECORD, $stale, $now)->reasonCode);

        $future = new GovernanceDecision(
            '0198a8d0-4a22-7b31-9b4c-7429136e23d3',
            42,
            WisdomGovernedOperation::OUTCOME_RECORD,
            GovernanceDisposition::ALLOW,
            'governance-policy-v1',
            new DateTimeImmutable('2026-08-19T00:26:00+10:00'),
            new DateTimeImmutable('2026-08-19T00:31:00+10:00'),
        );
        self::assertSame('governance_decision_not_yet_valid', $this->gate->evaluate($this->context, WisdomGovernedOperation::OUTCOME_RECORD, $future, $now)->reasonCode);
    }

    public function test_wisdom_can_never_promote_learning_into_authority(): void
    {
        $decision = $this->decision(
            GovernanceDisposition::ALLOW,
            operation: WisdomGovernedOperation::LEARNING_CANDIDATE_PROMOTE,
        );

        $result = $this->gate->evaluate(
            $this->context,
            WisdomGovernedOperation::LEARNING_CANDIDATE_PROMOTE,
            $decision,
            new DateTimeImmutable('2026-08-19T00:25:00+10:00'),
        );

        self::assertFalse($result->allowed);
        self::assertSame('wisdom_authority_boundary', $result->reasonCode);
    }

    private function decision(
        GovernanceDisposition $disposition,
        int $companyId = 42,
        WisdomGovernedOperation $operation = WisdomGovernedOperation::OUTCOME_RECORD,
        ?DateTimeImmutable $validUntil = null,
    ): GovernanceDecision {
        return new GovernanceDecision(
            '0198a8d0-4a22-7b31-9b4c-7429136e23d1',
            $companyId,
            $operation,
            $disposition,
            'governance-policy-v1',
            new DateTimeImmutable('2026-08-19T00:20:00+10:00'),
            $validUntil ?? new DateTimeImmutable('2026-08-19T00:30:00+10:00'),
            ['tenant-policy'],
        );
    }
}
