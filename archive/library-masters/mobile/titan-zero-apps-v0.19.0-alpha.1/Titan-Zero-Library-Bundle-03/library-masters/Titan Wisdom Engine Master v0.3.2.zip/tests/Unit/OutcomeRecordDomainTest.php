<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Unit;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Exceptions\OutcomeIdempotencyCollisionException;
use App\Extensions\TitanWisdomEngine\System\Exceptions\WisdomGovernanceDeniedException;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeClassification;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeRecorder;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;
use RuntimeException;

final class OutcomeRecordDomainTest extends TestCase
{
    public function test_governed_record_is_tenant_scoped_and_idempotent(): void
    {
        $repository = new InMemoryOutcomeRepository();
        $recorder = new WisdomOutcomeRecorder($repository, new WisdomGovernanceGate(300));
        $context = $this->context();
        $draft = $this->draft();
        $decision = $this->decision(GovernanceDisposition::ALLOW);
        $now = new DateTimeImmutable('2026-08-19T00:55:00+10:00');

        $first = $recorder->record($context, $draft, $decision, $now);
        $second = $recorder->record($context, $draft, $decision, new DateTimeImmutable('2026-08-19T00:55:30+10:00'));

        self::assertFalse($first->duplicate);
        self::assertTrue($second->duplicate);
        self::assertSame($first->record->outcomeId, $second->record->outcomeId);
        self::assertSame(42, $first->record->companyId);
        self::assertSame($decision->decisionId, $first->record->governanceDecisionId);
        self::assertStringStartsWith('wisdom.outcome.v1:', $first->record->idempotencyKey);
    }

    public function test_conflicting_payload_reusing_operation_id_fails_closed(): void
    {
        $repository = new InMemoryOutcomeRepository();
        $recorder = new WisdomOutcomeRecorder($repository, new WisdomGovernanceGate(300));
        $context = $this->context();
        $decision = $this->decision(GovernanceDisposition::ALLOW);
        $recorder->record($context, $this->draft(), $decision, new DateTimeImmutable('2026-08-19T00:55:00+10:00'));

        $this->expectException(OutcomeIdempotencyCollisionException::class);

        $recorder->record($context, new OutcomeRecordDraft(
            operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2300',
            intent: ['type' => 'invoice.collection', 'goal' => 'changed'],
            expectedResult: ['invoice_state' => 'paid'],
            actualResult: null,
            resolutionState: OutcomeResolutionState::PENDING,
            classification: OutcomeClassification::INCONCLUSIVE,
            confidence: 0.25,
            sourceComponent: 'titan-command-bus',
            sourceRecordRef: 'receipt:cmd-123',
        ), $decision, new DateTimeImmutable('2026-08-19T00:55:20+10:00'));
    }

    public function test_governance_denial_prevents_recording(): void
    {
        $this->expectException(WisdomGovernanceDeniedException::class);

        (new WisdomOutcomeRecorder(new InMemoryOutcomeRepository(), new WisdomGovernanceGate(300)))->record(
            $this->context(),
            $this->draft(),
            $this->decision(GovernanceDisposition::DENY),
            new DateTimeImmutable('2026-08-19T00:55:00+10:00'),
        );
    }

    public function test_unresolved_outcome_cannot_claim_success(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        new OutcomeRecordDraft(
            operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2311',
            intent: ['type' => 'test'],
            expectedResult: ['ok' => true],
            actualResult: ['ok' => true],
            resolutionState: OutcomeResolutionState::PENDING,
            classification: OutcomeClassification::SUCCESS,
            confidence: 1.0,
            sourceComponent: 'test',
            sourceRecordRef: 'test:1',
        );
    }

    private function context(): WisdomExecutionContext
    {
        return new WisdomExecutionContext(
            42,
            '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        );
    }

    private function draft(): OutcomeRecordDraft
    {
        return new OutcomeRecordDraft(
            operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2300',
            intent: ['type' => 'invoice.collection', 'goal' => 'recover balance'],
            expectedResult: ['invoice_state' => 'paid'],
            actualResult: null,
            resolutionState: OutcomeResolutionState::PENDING,
            classification: OutcomeClassification::INCONCLUSIVE,
            confidence: 0.25,
            sourceComponent: 'titan-command-bus',
            sourceRecordRef: 'receipt:cmd-123',
            contextVersions: ['workflow' => 'collections-v3', 'policy' => 'policy-v2'],
            observationStartedAt: new DateTimeImmutable('2026-08-19T00:55:00+10:00'),
            expectedResolutionAt: new DateTimeImmutable('2026-08-22T00:55:00+10:00'),
        );
    }

    private function decision(GovernanceDisposition $disposition): GovernanceDecision
    {
        return new GovernanceDecision(
            '0198a8d0-4a22-7b31-9b4c-7429136e2301',
            42,
            WisdomGovernedOperation::OUTCOME_RECORD,
            $disposition,
            'governance-policy-v1',
            new DateTimeImmutable('2026-08-19T00:53:00+10:00'),
            new DateTimeImmutable('2026-08-19T01:00:00+10:00'),
        );
    }
}

final class InMemoryOutcomeRepository implements OutcomeRecordRepositoryContract
{
    /** @var array<string, OutcomeRecord> */
    private array $records = [];

    public function findByOperationId(int $companyId, string $operationId): ?OutcomeRecord
    {
        return $this->records[$companyId . ':' . $operationId] ?? null;
    }

    public function insert(OutcomeRecord $record): void
    {
        $key = $record->companyId . ':' . $record->operationId;
        if (isset($this->records[$key])) {
            throw new RuntimeException('duplicate');
        }
        $this->records[$key] = $record;
    }
}
