<?php
declare(strict_types=1);

require_once __DIR__ . '/../System/Workforce/WorkforceLoopRuntime.php';

use App\Extensions\TitanWisdomEngine\System\Workforce\WorkforceLoopRuntime;

function rtAssert(bool $ok, string $message): void { if (!$ok) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

$contract = __DIR__ . '/../workforce-integration.json';
$runtime = WorkforceLoopRuntime::fromContractFile($contract);
rtAssert($runtime->tenantKey() === 'company_id', 'runtime canonical tenant key is company_id');
rtAssert($runtime->availability([])['status'] === 'available', 'provider is available when no required dependency is degraded');
rtAssert($runtime->availability(['signal' => 'degraded'])['status'] === 'degraded', 'degraded dependency degrades provider');
rtAssert($runtime->availability(['signal' => 'missing_provider'])['status'] === 'missing_provider', 'missing dependency fails closed');

$ctx = [
  'company_id' => 42,
  'trace_id' => 'trace-1',
  'correlation_id' => 'corr-1',
  'causation_id' => 'cause-1',
  'root_causation_id' => 'root-1',
];
$handoff = $runtime->prepareHandoff($ctx, 'titan-ai-workforce', 'knowledge.lookup');
rtAssert(($handoff['provider']['extension_key'] ?? '') !== '', 'handoff pins provider');
rtAssert(($handoff['provider']['version'] ?? '') !== '', 'handoff records provider version');
rtAssert(($handoff['company_id'] ?? null) === 42, 'handoff preserves company_id');
rtAssert(($handoff['authority_neutral'] ?? false) === true, 'handoff observations are authority-neutral');

$threw = false;
try { $legacy = $ctx; unset($legacy['company_id']); $legacy['tenant_key']=42; $runtime->prepareHandoff($legacy, 'titan-ai-workforce', 'knowledge.lookup'); } catch (InvalidArgumentException) { $threw = true; }
rtAssert($threw, 'legacy tenant key cannot replace canonical company_id');

$threw = false;
$bad = $ctx; unset($bad['causation_id']);
try { $runtime->prepareHandoff($bad, 'titan-ai-workforce', 'knowledge.lookup'); } catch (InvalidArgumentException) { $threw = true; }
rtAssert($threw, 'missing causal context fails closed');

$outcome = $runtime->acceptOutcome($ctx + ['originating_work_item_id'=>'work-7','execution_receipt_id'=>'receipt-7']);
rtAssert(($outcome['accepted'] ?? false) === true, 'outcome with lineage and receipt is accepted');

echo "PASS workforce runtime hardening\n";
