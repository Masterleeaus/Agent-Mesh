<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Security;

use PHPUnit\Framework\TestCase;

final class EvidenceTenantIsolationTest extends TestCase
{
    public function test_evidence_repository_scopes_reference_and_links_by_tenant(): void
    {
        $repository = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Repositories/DatabaseEvidenceRepository.php');
        self::assertGreaterThanOrEqual(3, substr_count($repository, "->where('company_id', $companyId)"));
        self::assertStringContainsString("->where('outcome_id', $outcomeId)", $repository);
        self::assertStringContainsString("->where('evidence_ref', $evidenceRef)", $repository);
    }

    public function test_self_report_cannot_be_authoritative_without_independent_validation(): void
    {
        $draft = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Evidence/EvidenceReferenceDraft.php');
        self::assertStringContainsString('agent_self_report', $draft);
        self::assertStringContainsString('cannot self-validate as authoritative truth', $draft);
        self::assertStringContainsString('authoritative evidence must be independently validated', $draft);
    }
}
