<?php

declare(strict_types=1);
$root = dirname(__DIR__, 2);
$source = file_get_contents($root . '/System/Commands/CertifyExtensionCommand.php');
if (!str_contains((string) $source, "runtime_enabled") || !str_contains((string) $source, '!$runtimeEnabled')) {
    fwrite(STDERR, "FAIL: certification must treat route absence as healthy when runtime is disabled\n");
    exit(1);
}
echo "Certification disabled-runtime safety smoke: PASS\n";
