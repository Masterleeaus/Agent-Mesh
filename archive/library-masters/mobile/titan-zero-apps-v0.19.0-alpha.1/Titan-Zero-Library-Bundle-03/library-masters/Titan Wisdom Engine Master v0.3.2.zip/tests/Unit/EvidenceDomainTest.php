<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Unit;

use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReferenceDraft;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceValidationState;
use DateTimeImmutable;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class EvidenceDomainTest extends TestCase
{
    public function test_claimed_agent_self_report_is_allowed_but_not_authoritative(): void
    {
        $draft = new EvidenceReferenceDraft(
            evidenceRef: 'agent:claim-1',
            sourceEngine: 'titan-ai-workforce',
            sourceType: 'agent_self_report',
            sourceRecordRef: 'task:1',
            validationState: EvidenceValidationState::CLAIMED,
            authoritativeForFact: false,
            observedAt: new DateTimeImmutable('2026-08-20T00:30:00+10:00'),
        );

        self::assertSame(EvidenceValidationState::CLAIMED, $draft->validationState);
        self::assertFalse($draft->authoritativeForFact);
    }

    public function test_agent_self_report_cannot_self_validate_as_authoritative(): void
    {
        $this->expectException(InvalidArgumentException::class);
        new EvidenceReferenceDraft(
            evidenceRef: 'agent:claim-2',
            sourceEngine: 'titan-ai-workforce',
            sourceType: 'agent_self_report',
            sourceRecordRef: 'task:2',
            validationState: EvidenceValidationState::VALIDATED,
            authoritativeForFact: true,
            observedAt: new DateTimeImmutable('2026-08-20T00:30:00+10:00'),
            validatedAt: new DateTimeImmutable('2026-08-20T00:31:00+10:00'),
            validatorRef: 'agent:self',
        );
    }
}
