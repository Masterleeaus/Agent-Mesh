<?php
declare(strict_types=1);
$m=json_decode((string)file_get_contents(__DIR__.'/../extension.json'),true);
function iAssert(bool $ok,string $m):void{if(!$ok){fwrite(STDERR,"FAIL: $m\n");exit(1);}}
iAssert(is_array($m),'manifest json');
foreach(['schema','slug','folder','provider','version','requires','migrations','uninstall'] as $k)iAssert(array_key_exists($k,$m),"required $k");
foreach(['name','type','description','support_telegram','publishes'] as $k)iAssert(!array_key_exists($k,$m),"1.7.8 forbids legacy/additional $k");
iAssert(($m['schema']??null)==='titan-extension-v1','schema');
iAssert(isset($m['requires']['php'],$m['requires']['laravel'],$m['requires']['magicai']),'requires triple');
iAssert(is_bool($m['migrations']??null),'migrations bool');
iAssert(is_bool($m['uninstall']['preserve_data']??null),'uninstall preserve_data');
echo "PASS installer 1.7.8 root manifest\n";
