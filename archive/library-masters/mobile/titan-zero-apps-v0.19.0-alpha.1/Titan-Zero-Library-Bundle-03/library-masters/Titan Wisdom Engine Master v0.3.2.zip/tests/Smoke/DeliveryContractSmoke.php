<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$required = [
    'System/Events/OutcomeObservationDue.php',
    'System/Jobs/ObserveDueOutcomeJob.php',
    'System/Commands/DispatchDueOutcomesCommand.php',
];
foreach ($required as $path) {
    if (!is_file($root . '/' . $path)) {
        fwrite(STDERR, "FAIL: missing {$path}\n");
        exit(1);
    }
}
$job = file_get_contents($root . '/System/Jobs/ObserveDueOutcomeJob.php');
$command = file_get_contents($root . '/System/Commands/DispatchDueOutcomesCommand.php');
$provider = file_get_contents($root . '/System/TitanWisdomEngineServiceProvider.php');
if (!str_contains((string) $job, 'ShouldQueue') || !str_contains((string) $job, 'ShouldBeUnique') || !str_contains((string) $job, 'idempotencyKey')) {
    fwrite(STDERR, "FAIL: queued observation job must carry idempotency identity\n"); exit(1);
}
if (!str_contains((string) $command, 'observations.dispatch_enabled') || !str_contains((string) $command, 'DueOutcomeScannerContract') || !str_contains((string) $command, 'ObserveDueOutcomeJob::dispatch')) {
    fwrite(STDERR, "FAIL: due outcome command must scan and dispatch queue work\n"); exit(1);
}
if (!str_contains((string) $provider, 'everyFiveMinutes') || !str_contains((string) $provider, 'withoutOverlapping') || !str_contains((string) $provider, 'onOneServer')) {
    fwrite(STDERR, "FAIL: provider must register stable overlap-protected one-server schedule\n"); exit(1);
}
echo "Delayed observation delivery contract smoke: PASS\n";
