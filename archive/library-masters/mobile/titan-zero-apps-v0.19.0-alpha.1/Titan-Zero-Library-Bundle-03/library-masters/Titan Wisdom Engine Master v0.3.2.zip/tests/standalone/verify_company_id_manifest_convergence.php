<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
$errors=[];
$walk=function(mixed $value,string $path='') use (&$walk,&$errors): void {
    if (!is_array($value)) return;
    foreach ($value as $key=>$item) {
        $p=$path===''?(string)$key:$path.'.'.$key;
        $keyName=strtolower((string)$key);
        if (in_array($keyName,['tenant_id','tenant_company_id'],true)) {
            $errors[]='forbidden legacy boundary key '.$p;
        }
        if ($keyName==='tenant_key' && is_string($item) && $item!=='company_id') {
            $errors[]=$p.' must normalize to company_id';
        }
        if (is_string($item) && preg_match('/\b(tenant_id|tenant_company_id)\b/i',$item)) {
            $errors[]='forbidden legacy boundary value '.$p.'='.$item;
        }
        $walk($item,$p);
    }
};
$walk($manifest);
if ($errors!==[]) { fwrite(STDERR,'company_id manifest convergence failed: '.implode(', ',$errors).PHP_EOL); exit(1); }
echo "company-id-manifest-convergence: PASS\n";
