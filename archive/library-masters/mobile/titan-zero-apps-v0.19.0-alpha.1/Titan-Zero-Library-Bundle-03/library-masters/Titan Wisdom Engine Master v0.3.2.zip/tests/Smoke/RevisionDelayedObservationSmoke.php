<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = [
    '/System/Support/Uuid.php',
    '/System/Support/CanonicalJson.php',
    '/System/Context/WisdomExecutionContext.php',
    '/System/Governance/GovernanceDisposition.php',
    '/System/Governance/WisdomGovernedOperation.php',
    '/System/Governance/GovernanceDecision.php',
    '/System/Governance/GovernanceGateResult.php',
    '/System/Contracts/WisdomGovernanceGateContract.php',
    '/System/Services/WisdomGovernanceGate.php',
    '/System/Outcomes/OutcomeClassification.php',
    '/System/Outcomes/OutcomeResolutionState.php',
    '/System/Outcomes/OutcomeRecord.php',
    '/System/Outcomes/OutcomeRecordReceipt.php',
    '/System/Evidence/EvidenceValidationState.php',
    '/System/Evidence/EvidenceRelationship.php',
    '/System/Evidence/EvidenceReference.php',
    '/System/Contracts/EvidenceRepositoryContract.php',
    '/System/Contracts/OutcomeRecordRepositoryContract.php',
    '/System/Contracts/OutcomeResolutionRepositoryContract.php',
    '/System/Outcomes/OutcomeRevisionDraft.php',
    '/System/Contracts/WisdomOutcomeReviserContract.php',
    '/System/Services/WisdomOutcomeReviser.php',
    '/System/Outcomes/DueOutcomeObservation.php',
    '/System/Contracts/DueOutcomeScannerContract.php',
    '/System/Services/WisdomDueOutcomeScanner.php',
];
foreach ($files as $file) {
    require_once $root . $file;
}

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\DueOutcomeScannerContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReference;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceValidationState;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeClassification;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRevisionDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeTransition;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomDueOutcomeScanner;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeReviser;

function pass3b(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
    echo "PASS: {$message}\n";
}

final class RevisionRecordRepo implements OutcomeRecordRepositoryContract
{
    /** @var array<string, OutcomeRecord> */
    public array $rows = [];
    public function findByOperationId(int $companyId, string $operationId): ?OutcomeRecord
    {
        return $this->rows[$companyId . ':' . $operationId] ?? null;
    }
    public function insert(OutcomeRecord $record): void
    {
        $key = $record->companyId . ':' . $record->operationId;
        if (isset($this->rows[$key])) {
            throw new RuntimeException('duplicate');
        }
        $this->rows[$key] = $record;
    }
}

final class RevisionResolutionRepo implements OutcomeResolutionRepositoryContract
{
    /** @var array<string, OutcomeRecord> */
    public array $rows = [];
    public function seed(OutcomeRecord $record): void { $this->rows[$record->companyId . ':' . $record->outcomeId] = $record; }
    public function findOutcomeById(int $companyId, string $outcomeId): ?OutcomeRecord { return $this->rows[$companyId . ':' . $outcomeId] ?? null; }
    public function findTransitionByOperationId(int $companyId, string $operationId): ?OutcomeTransition { return null; }
    public function compareAndSwap(OutcomeRecord $current, OutcomeRecord $next, OutcomeTransition $transition): bool { return false; }
    public function dueForObservation(DateTimeImmutable $now, int $limit): array
    {
        $due = array_values(array_filter($this->rows, static fn (OutcomeRecord $r): bool => !$r->resolutionState->isTerminal() && $r->expectedResolutionAt !== null && $r->expectedResolutionAt <= $now));
        return array_slice($due, 0, $limit);
    }
}

final class RevisionEvidenceRepo implements EvidenceRepositoryContract
{
    /** @var array<string, EvidenceReference> */ public array $evidence = [];
    /** @var array<string, array<string, EvidenceRelationship>> */ public array $links = [];
    public function findByReference(int $companyId, string $evidenceRef): ?EvidenceReference { return $this->evidence[$companyId . ':' . $evidenceRef] ?? null; }
    public function insert(EvidenceReference $evidence, string $outcomeId, EvidenceRelationship $relationship): void { $this->evidence[$evidence->companyId . ':' . $evidence->evidenceRef] = $evidence; $this->links[$evidence->companyId . ':' . $outcomeId][$evidence->evidenceRef] = $relationship; }
    public function linkExisting(int $companyId, string $outcomeId, string $evidenceRef, EvidenceRelationship $relationship): void { $this->links[$companyId . ':' . $outcomeId][$evidenceRef] = $relationship; }
    public function forOutcome(int $companyId, string $outcomeId): array
    {
        $result=[];
        foreach (($this->links[$companyId . ':' . $outcomeId] ?? []) as $ref=>$relationship) {
            if (($e=$this->findByReference($companyId,$ref)) !== null) $result[]=['evidence'=>$e,'relationship'=>$relationship];
        }
        return $result;
    }
}

$now = new DateTimeImmutable('2026-08-20T00:40:00+10:00');
$ctx = new WisdomExecutionContext(42,
    '0198a8d0-4a22-7b31-9b4c-7429136e2601','0198a8d0-4a22-7b31-9b4c-7429136e2602','0198a8d0-4a22-7b31-9b4c-7429136e2603','0198a8d0-4a22-7b31-9b4c-7429136e2604');
$original = new OutcomeRecord(
    outcomeId:'0198a8d0-4a22-7b31-9b4c-7429136e2610', companyId:42, operationId:'0198a8d0-4a22-7b31-9b4c-7429136e2611',
    traceId:$ctx->traceId, correlationId:$ctx->correlationId, causationId:$ctx->causationId, rootCausationId:$ctx->rootCausationId,
    intent:['type'=>'repair'], expectedResult:['state'=>'fixed'], actualResult:['state'=>'fixed'], resolutionState:OutcomeResolutionState::RESOLVED,
    classification:OutcomeClassification::SUCCESS, confidence:0.95, observationStartedAt:$now->modify('-2 days'), expectedResolutionAt:$now->modify('-1 day'), observedAt:$now->modify('-1 day'), resolvedAt:$now->modify('-1 day'),
    evidenceRefs:['inspection:1'], attributionRefs:[], contextVersions:[], revisesOutcomeId:null, idempotencyKey:'k1', payloadHash:str_repeat('a',64), sourceComponent:'titan-command-bus', sourceRecordRef:'job:1', governanceDecisionId:'0198a8d0-4a22-7b31-9b4c-7429136e2691', governancePolicyVersion:'p1', recordVersion:2, createdAt:$now->modify('-2 days'), updatedAt:$now->modify('-1 day')
);
$records = new RevisionRecordRepo();
$resolutions = new RevisionResolutionRepo();
$resolutions->seed($original);
$evidence = new RevisionEvidenceRepo();
$contradiction = new EvidenceReference(
    id:'0198a8d0-4a22-7b31-9b4c-7429136e2620', evidenceRef:'callback:failure-1', companyId:42, sourceEngine:'titan-crm-core', sourceType:'job_reopened', sourceRecordRef:'job:1', contentHash:null,
    validationState:EvidenceValidationState::VALIDATED, authoritativeForFact:true, observedAt:$now, validatedAt:$now, validatorRef:'crm:job-state', payloadHash:str_repeat('b',64), governanceDecisionId:'0198a8d0-4a22-7b31-9b4c-7429136e2692', governancePolicyVersion:'p2', createdAt:$now
);
$evidence->insert($contradiction, $original->outcomeId, EvidenceRelationship::CONTRADICTS);
$decision = new GovernanceDecision('0198a8d0-4a22-7b31-9b4c-7429136e2630',42,WisdomGovernedOperation::OUTCOME_REVISE,GovernanceDisposition::ALLOW,'p2',$now->modify('-1 minute'),$now->modify('+4 minutes'));
$reviser = new WisdomOutcomeReviser($records,$resolutions,$evidence,new WisdomGovernanceGate(300));
$revision = $reviser->revise($ctx,new OutcomeRevisionDraft(
    operationId:'0198a8d0-4a22-7b31-9b4c-7429136e2640', originalOutcomeId:$original->outcomeId, resolutionState:OutcomeResolutionState::CONTRADICTED,
    actualResult:['state'=>'failed_again'], classification:OutcomeClassification::FAILURE, confidence:0.99, evidenceRefs:['callback:failure-1'], observedAt:$now, resolvedAt:$now
),$decision,$now);
pass3b($revision->record->resolutionState===OutcomeResolutionState::CONTRADICTED,'validated contradicting evidence creates contradicted revision record');
pass3b($revision->record->revisesOutcomeId===$original->outcomeId,'revision preserves lineage to original outcome');
pass3b($revision->record->outcomeId!==$original->outcomeId,'revision is append-only and receives a new outcome id');
pass3b($resolutions->findOutcomeById(42,$original->outcomeId)?->resolutionState===OutcomeResolutionState::RESOLVED,'original outcome remains immutable after contradiction');

$pending = new OutcomeRecord(
    outcomeId:'0198a8d0-4a22-7b31-9b4c-7429136e2650', companyId:42, operationId:'0198a8d0-4a22-7b31-9b4c-7429136e2651',
    traceId:$ctx->traceId, correlationId:$ctx->correlationId, causationId:$ctx->causationId, rootCausationId:$ctx->rootCausationId,
    intent:['type'=>'retention'], expectedResult:['customer'=>'retained'], actualResult:null, resolutionState:OutcomeResolutionState::PENDING,
    classification:OutcomeClassification::INCONCLUSIVE, confidence:0.2, observationStartedAt:$now->modify('-2 days'), expectedResolutionAt:$now->modify('-1 minute'), observedAt:null, resolvedAt:null,
    evidenceRefs:[], attributionRefs:[], contextVersions:[], revisesOutcomeId:null, idempotencyKey:'k2', payloadHash:str_repeat('c',64), sourceComponent:'titan-crm-core', sourceRecordRef:'customer:22', governanceDecisionId:'0198a8d0-4a22-7b31-9b4c-7429136e2693', governancePolicyVersion:'p1', recordVersion:1, createdAt:$now->modify('-2 days'), updatedAt:$now->modify('-2 days')
);
$resolutions->seed($pending);
$scanner = new WisdomDueOutcomeScanner($resolutions);
$due = $scanner->scan($now,10);
pass3b(count($due)===1,'delayed observation scanner returns overdue unresolved outcomes only');
pass3b($due[0]->companyId===42 && $due[0]->traceId===$ctx->traceId,'due observation payload preserves tenant and trace context');
pass3b($due[0]->idempotencyKey!=='','due observation payload has stable idempotency key');

echo "Revision + delayed observation smoke: PASS\n";
