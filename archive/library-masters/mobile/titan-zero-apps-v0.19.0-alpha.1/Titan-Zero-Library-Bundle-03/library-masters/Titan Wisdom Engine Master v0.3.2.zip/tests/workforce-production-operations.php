<?php
declare(strict_types=1);
require_once __DIR__.'/../System/Workforce/DurableHandoffStoreContract.php';
require_once __DIR__.'/../System/Workforce/InMemoryDurableHandoffStore.php';
require_once __DIR__.'/../System/Workforce/CrossExtensionOrchestrator.php';
require_once __DIR__.'/../System/Workforce/PersistentOrchestrationRuntime.php';
require_once __DIR__.'/../System/Workforce/OrchestrationOperations.php';
use App\Extensions\TitanWisdomEngine\System\Workforce\{InMemoryDurableHandoffStore,CrossExtensionOrchestrator,PersistentOrchestrationRuntime,OrchestrationOperations};
function ok($v,$m){if(!$v){fwrite(STDERR,"FAIL: $m\n");exit(1);}}
$store=new InMemoryDurableHandoffStore(2); $orchestrator=new CrossExtensionOrchestrator('test-extension'); $runtime=new PersistentOrchestrationRuntime($orchestrator,$store); $ops=new OrchestrationOperations($runtime,$store);
$env=['schema'=>'titan.cross-extension-handoff.v1','handoff_id'=>'h1','idempotency_key'=>'k1','company_id'=>7,'target_provider'=>'provider.x','trace_id'=>'t','correlation_id'=>'c','causation_id'=>'ca','root_causation_id'=>'r','authority'=>['may_increase'=>false]]; $runtime->enqueue($env);
$r=$ops->dispatchBatch(7,'w1',['provider.x'=>'available'],fn($e)=>['execution_receipt_id'=>'rec1','outcome_id'=>'out1','status'=>'completed'],10); ok($r['delivered']===1,'batch delivers');
$h=$ops->health(7); ok(($h['counts']['delivered']??0)===1,'health reports delivered');
echo "PASS workforce production operations\n";
