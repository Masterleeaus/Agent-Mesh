<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = [
    '/System/Support/Uuid.php',
    '/System/Support/CanonicalJson.php',
    '/System/Context/WisdomExecutionContext.php',
    '/System/Governance/GovernanceDisposition.php',
    '/System/Governance/WisdomGovernedOperation.php',
    '/System/Governance/GovernanceDecision.php',
    '/System/Governance/GovernanceGateResult.php',
    '/System/Contracts/WisdomGovernanceGateContract.php',
    '/System/Services/WisdomGovernanceGate.php',
    '/System/Exceptions/OutcomeIdempotencyCollisionException.php',
    '/System/Exceptions/WisdomGovernanceDeniedException.php',
    '/System/Outcomes/OutcomeClassification.php',
    '/System/Outcomes/OutcomeResolutionState.php',
    '/System/Outcomes/OutcomeRecord.php',
    '/System/Evidence/EvidenceValidationState.php',
    '/System/Evidence/EvidenceRelationship.php',
    '/System/Evidence/EvidenceReferenceDraft.php',
    '/System/Evidence/EvidenceReference.php',
    '/System/Evidence/EvidenceAttachmentReceipt.php',
    '/System/Contracts/EvidenceRepositoryContract.php',
    '/System/Contracts/WisdomEvidenceAttacherContract.php',
    '/System/Services/WisdomEvidenceAttacher.php',
    '/System/Outcomes/OutcomeResolutionDraft.php',
    '/System/Outcomes/OutcomeResolutionReceipt.php',
    '/System/Outcomes/OutcomeTransition.php',
    '/System/Contracts/OutcomeResolutionRepositoryContract.php',
    '/System/Contracts/WisdomOutcomeResolverContract.php',
    '/System/Services/WisdomOutcomeResolver.php',
];
foreach ($files as $file) {
    require_once $root . $file;
}

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceAttachmentReceipt;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReference;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReferenceDraft;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceValidationState;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeClassification;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeTransition;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomEvidenceAttacher;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeResolver;

function pass3ok(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
    echo "PASS: {$message}\n";
}

final class MemoryEvidenceRepository implements EvidenceRepositoryContract
{
    /** @var array<string, EvidenceReference> */
    private array $evidence = [];
    /** @var array<string, array<string, EvidenceRelationship>> */
    private array $links = [];

    public function findByReference(int $companyId, string $evidenceRef): ?EvidenceReference
    {
        return $this->evidence[$companyId . ':' . $evidenceRef] ?? null;
    }

    public function insert(EvidenceReference $evidence, string $outcomeId, EvidenceRelationship $relationship): void
    {
        $key = $evidence->companyId . ':' . $evidence->evidenceRef;
        if (isset($this->evidence[$key])) {
            throw new RuntimeException('duplicate');
        }
        $this->evidence[$key] = $evidence;
        $this->links[$evidence->companyId . ':' . $outcomeId][$evidence->evidenceRef] = $relationship;
    }

    public function linkExisting(int $companyId, string $outcomeId, string $evidenceRef, EvidenceRelationship $relationship): void
    {
        $this->links[$companyId . ':' . $outcomeId][$evidenceRef] = $relationship;
    }

    public function forOutcome(int $companyId, string $outcomeId): array
    {
        $result = [];
        foreach (($this->links[$companyId . ':' . $outcomeId] ?? []) as $ref => $relationship) {
            $evidence = $this->findByReference($companyId, $ref);
            if ($evidence !== null) {
                $result[] = ['evidence' => $evidence, 'relationship' => $relationship];
            }
        }
        return $result;
    }
}

final class MemoryResolutionRepository implements OutcomeResolutionRepositoryContract
{
    /** @var array<string, OutcomeRecord> */
    private array $outcomes = [];
    /** @var array<string, OutcomeTransition> */
    private array $transitions = [];

    public function seed(OutcomeRecord $record): void
    {
        $this->outcomes[$record->companyId . ':' . $record->outcomeId] = $record;
    }

    public function findOutcomeById(int $companyId, string $outcomeId): ?OutcomeRecord
    {
        return $this->outcomes[$companyId . ':' . $outcomeId] ?? null;
    }

    public function findTransitionByOperationId(int $companyId, string $operationId): ?OutcomeTransition
    {
        return $this->transitions[$companyId . ':' . $operationId] ?? null;
    }

    public function compareAndSwap(OutcomeRecord $current, OutcomeRecord $next, OutcomeTransition $transition): bool
    {
        $key = $current->companyId . ':' . $current->outcomeId;
        $stored = $this->outcomes[$key] ?? null;
        if ($stored === null || $stored->recordVersion !== $current->recordVersion) {
            return false;
        }
        $this->outcomes[$key] = $next;
        $this->transitions[$transition->companyId . ':' . $transition->operationId] = $transition;
        return true;
    }

    public function dueForObservation(DateTimeImmutable $now, int $limit): array
    {
        return array_values(array_filter($this->outcomes, static fn (OutcomeRecord $record): bool =>
            !$record->resolutionState->isTerminal()
            && $record->expectedResolutionAt !== null
            && $record->expectedResolutionAt <= $now
        ));
    }
}

$now = new DateTimeImmutable('2026-08-20T00:30:00+10:00');
$context = new WisdomExecutionContext(
    42,
    '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
);
$governance = new WisdomGovernanceGate(300);

$selfReportRejected = false;
try {
    new EvidenceReferenceDraft(
        evidenceRef: 'evidence:self-report-1',
        sourceEngine: 'titan-ai-workforce',
        sourceType: 'agent_self_report',
        sourceRecordRef: 'agent:task-1',
        validationState: EvidenceValidationState::VALIDATED,
        authoritativeForFact: true,
        observedAt: $now,
        validatedAt: $now,
        validatorRef: 'agent:self',
    );
} catch (InvalidArgumentException) {
    $selfReportRejected = true;
}
pass3ok($selfReportRejected, 'agent self-report cannot self-validate as authoritative evidence');

$outcome = new OutcomeRecord(
    outcomeId: '0198a8d0-4a22-7b31-9b4c-7429136e2400',
    companyId: 42,
    operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2401',
    traceId: $context->traceId,
    correlationId: $context->correlationId,
    causationId: $context->causationId,
    rootCausationId: $context->rootCausationId,
    intent: ['type' => 'invoice.collection'],
    expectedResult: ['invoice_state' => 'paid'],
    actualResult: null,
    resolutionState: OutcomeResolutionState::PENDING,
    classification: OutcomeClassification::INCONCLUSIVE,
    confidence: 0.25,
    observationStartedAt: new DateTimeImmutable('2026-08-19T00:00:00+10:00'),
    expectedResolutionAt: new DateTimeImmutable('2026-08-20T00:00:00+10:00'),
    observedAt: null,
    resolvedAt: null,
    evidenceRefs: [],
    attributionRefs: [],
    contextVersions: ['workflow' => 'collections-v3'],
    revisesOutcomeId: null,
    idempotencyKey: 'wisdom.outcome.v1:test',
    payloadHash: str_repeat('a', 64),
    sourceComponent: 'titan-command-bus',
    sourceRecordRef: 'receipt:cmd-123',
    governanceDecisionId: '0198a8d0-4a22-7b31-9b4c-7429136e2490',
    governancePolicyVersion: 'policy-v2',
    recordVersion: 1,
    createdAt: new DateTimeImmutable('2026-08-19T00:00:00+10:00'),
    updatedAt: new DateTimeImmutable('2026-08-19T00:00:00+10:00'),
);

$evidenceRepo = new MemoryEvidenceRepository();
$resolutionRepo = new MemoryResolutionRepository();
$resolutionRepo->seed($outcome);
$attacher = new WisdomEvidenceAttacher($evidenceRepo, $resolutionRepo, $governance);

$evidenceDecision = new GovernanceDecision(
    '0198a8d0-4a22-7b31-9b4c-7429136e2501',
    42,
    WisdomGovernedOperation::EVIDENCE_ATTACH,
    GovernanceDisposition::ALLOW,
    'governance-policy-v2',
    $now->modify('-1 minute'),
    $now->modify('+4 minutes'),
);
$paymentEvidence = new EvidenceReferenceDraft(
    evidenceRef: 'payment:receipt-7788',
    sourceEngine: 'titan-pay',
    sourceType: 'payment_receipt',
    sourceRecordRef: 'payment:7788',
    validationState: EvidenceValidationState::VALIDATED,
    authoritativeForFact: true,
    observedAt: $now->modify('-2 minutes'),
    validatedAt: $now->modify('-1 minute'),
    validatorRef: 'titan-pay:ledger',
    contentHash: str_repeat('b', 64),
);
$attachment = $attacher->attach($context, $outcome->outcomeId, $paymentEvidence, EvidenceRelationship::SUPPORTS, $evidenceDecision, $now);
pass3ok($attachment instanceof EvidenceAttachmentReceipt && !$attachment->duplicate, 'validated external evidence attaches to tenant outcome');
pass3ok($attachment->evidence->authoritativeForFact, 'authoritative evidence flag is preserved');

$duplicateAttachment = $attacher->attach($context, $outcome->outcomeId, $paymentEvidence, EvidenceRelationship::SUPPORTS, $evidenceDecision, $now->modify('+10 seconds'));
pass3ok($duplicateAttachment->duplicate, 'same evidence attachment returns idempotent duplicate receipt');

$secondOutcome = new OutcomeRecord(
    outcomeId: '0198a8d0-4a22-7b31-9b4c-7429136e2402', companyId: 42, operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2403',
    traceId: $context->traceId, correlationId: $context->correlationId, causationId: $context->causationId, rootCausationId: $context->rootCausationId,
    intent: ['type' => 'cashflow.confirmation'], expectedResult: ['invoice_state' => 'paid'], actualResult: null,
    resolutionState: OutcomeResolutionState::PENDING, classification: OutcomeClassification::INCONCLUSIVE, confidence: 0.2,
    observationStartedAt: $now->modify('-1 hour'), expectedResolutionAt: $now->modify('+1 hour'), observedAt: null, resolvedAt: null,
    evidenceRefs: [], attributionRefs: [], contextVersions: [], revisesOutcomeId: null, idempotencyKey: 'wisdom.outcome.v1:test2', payloadHash: str_repeat('d', 64),
    sourceComponent: 'titan-pay', sourceRecordRef: 'invoice:7788', governanceDecisionId: '0198a8d0-4a22-7b31-9b4c-7429136e2491', governancePolicyVersion: 'policy-v2',
    recordVersion: 1, createdAt: $now, updatedAt: $now,
);
$resolutionRepo->seed($secondOutcome);
$reusedEvidence = $attacher->attach($context, $secondOutcome->outcomeId, $paymentEvidence, EvidenceRelationship::SUPPORTS, $evidenceDecision, $now->modify('+20 seconds'));
pass3ok($reusedEvidence->duplicate, 'same canonical evidence reference can link to a second tenant outcome without semantic collision');

$resolveDecision = new GovernanceDecision(
    '0198a8d0-4a22-7b31-9b4c-7429136e2502',
    42,
    WisdomGovernedOperation::OUTCOME_RESOLVE,
    GovernanceDisposition::ALLOW,
    'governance-policy-v2',
    $now->modify('-1 minute'),
    $now->modify('+4 minutes'),
);
$resolver = new WisdomOutcomeResolver($resolutionRepo, $evidenceRepo, $governance);
$resolution = $resolver->resolve(
    $context,
    new OutcomeResolutionDraft(
        operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2510',
        outcomeId: $outcome->outcomeId,
        actualResult: ['invoice_state' => 'paid', 'amount' => 1200],
        classification: OutcomeClassification::SUCCESS,
        confidence: 0.98,
        evidenceRefs: ['payment:receipt-7788'],
        observedAt: $now,
        resolvedAt: $now,
    ),
    $resolveDecision,
    $now,
);
pass3ok($resolution->record->resolutionState === OutcomeResolutionState::RESOLVED, 'pending outcome resolves when validated authoritative evidence exists');
pass3ok($resolution->record->classification === OutcomeClassification::SUCCESS, 'resolution stores actual classification');
pass3ok($resolution->record->recordVersion === 2, 'resolution increments optimistic record version');
pass3ok($resolution->transition->fromState === OutcomeResolutionState::PENDING, 'resolution transition preserves previous state');
pass3ok($resolution->transition->toState === OutcomeResolutionState::RESOLVED, 'resolution transition records terminal state');
pass3ok($resolution->record->governanceDecisionId === $outcome->governanceDecisionId, 'resolution preserves original record-creation governance provenance');
pass3ok($resolution->transition->governanceDecisionId === $resolveDecision->decisionId, 'resolution transition stores its own governance decision provenance');

$duplicateResolution = $resolver->resolve(
    $context,
    new OutcomeResolutionDraft(
        operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2510',
        outcomeId: $outcome->outcomeId,
        actualResult: ['invoice_state' => 'paid', 'amount' => 1200],
        classification: OutcomeClassification::SUCCESS,
        confidence: 0.98,
        evidenceRefs: ['payment:receipt-7788'],
        observedAt: $now,
        resolvedAt: $now,
    ),
    $resolveDecision,
    $now->modify('+15 seconds'),
);
pass3ok($duplicateResolution->duplicate, 'same resolution operation returns original transition receipt');

$due = $resolutionRepo->dueForObservation($now, 100);
pass3ok($due === [], 'resolved outcome is no longer selected as overdue observation work');

echo "Evidence + delayed resolution smoke: PASS\n";
