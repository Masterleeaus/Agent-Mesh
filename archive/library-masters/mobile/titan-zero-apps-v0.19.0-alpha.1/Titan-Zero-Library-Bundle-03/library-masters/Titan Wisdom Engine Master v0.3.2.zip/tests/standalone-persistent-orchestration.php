<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Workforce/CrossExtensionOrchestrator.php';
require_once __DIR__ . '/../System/Workforce/DurableHandoffStoreContract.php';
require_once __DIR__ . '/../System/Workforce/InMemoryDurableHandoffStore.php';
require_once __DIR__ . '/../System/Workforce/PersistentOrchestrationRuntime.php';

use App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator;
use App\Extensions\TitanWisdomEngine\System\Workforce\InMemoryDurableHandoffStore;
use App\Extensions\TitanWisdomEngine\System\Workforce\PersistentOrchestrationRuntime;

$orchestrator = new CrossExtensionOrchestrator('TitanWisdomEngine');
$store = new InMemoryDurableHandoffStore(maxAttempts: 2);
$runtime = new PersistentOrchestrationRuntime($orchestrator, $store);
$context = ['company_id'=>7,'trace_id'=>'trace-1','correlation_id'=>'corr-1','causation_id'=>'signal-1','root_causation_id'=>'signal-1'];
$handoff = $orchestrator->start($context, 'knowledge.resolve', 'titan-knowledge-authority', ['signal_id'=>'sig-1']);

$first = $runtime->enqueue($handoff);
$second = $runtime->enqueue($handoff);
if ($first['handoff_id'] !== $second['handoff_id'] || $store->snapshot(7)['total'] !== 1) { fwrite(STDERR, "dedupe failed\n"); exit(1); }

$claim = $runtime->claimNext(7, 'worker-a', ['titan-knowledge-authority'=>'available']);
if (!$claim || $claim['status'] !== 'in_flight' || $claim['attempts'] !== 1) { fwrite(STDERR, "claim failed\n"); exit(1); }

$accepted = $runtime->recordSuccess($claim, ['execution_receipt_id'=>'exec-1','outcome_id'=>'outcome-1','status'=>'completed']);
if (!$accepted['accepted'] || $store->snapshot(7)['delivered'] !== 1) { fwrite(STDERR, "success receipt failed\n"); exit(1); }

$h2 = $orchestrator->start($context, 'knowledge.resolve', 'missing-provider', ['signal_id'=>'sig-2']);
$runtime->enqueue($h2);
if ($runtime->claimNext(7, 'worker-a', ['missing-provider'=>'missing_provider']) !== null) { fwrite(STDERR, "fail closed failed\n"); exit(1); }
if ($store->snapshot(7)['deferred'] !== 1) { fwrite(STDERR, "defer failed\n"); exit(1); }

$h3 = $orchestrator->start($context, 'knowledge.resolve', 'titan-knowledge-authority', ['signal_id'=>'sig-3']);
$runtime->enqueue($h3);
$c3 = $runtime->claimNext(7, 'worker-a', ['titan-knowledge-authority'=>'available']);
$runtime->recordFailure($c3, 'boom-1', true);
$c4 = $runtime->claimNext(7, 'worker-b', ['titan-knowledge-authority'=>'available']);
$runtime->recordFailure($c4, 'boom-2', true);
if ($store->snapshot(7)['dead_letter'] !== 1) { fwrite(STDERR, "dead letter failed\n"); exit(1); }
$runtime->replayDeadLetter($h3['handoff_id']);
if ($store->snapshot(7)['pending'] !== 1) { fwrite(STDERR, "replay failed\n"); exit(1); }

$telemetry = $runtime->healthSnapshot(7);
if (($telemetry['company_id'] ?? 0) !== 7 || !isset($telemetry['counts']['delivered'])) { fwrite(STDERR, "telemetry failed\n"); exit(1); }

echo "PERSISTENT_ORCHESTRATION: PASS\n";
