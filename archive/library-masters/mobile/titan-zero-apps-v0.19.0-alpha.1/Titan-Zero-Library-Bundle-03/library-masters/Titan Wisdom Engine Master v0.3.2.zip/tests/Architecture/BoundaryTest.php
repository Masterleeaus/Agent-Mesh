<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

final class BoundaryTest extends TestCase
{
    public function test_extension_does_not_import_other_extension_internals(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));
        $violations = [];

        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            $contents = (string) file_get_contents($file->getPathname());
            if (preg_match('/use App\\\\Extensions\\\\(?!TitanWisdomEngine\\\\)/', $contents) === 1) {
                $violations[] = $file->getPathname();
            }
        }

        self::assertSame([], $violations, 'Wisdom must integrate through public contracts/adapters, not another extension internal namespace.');
    }

    public function test_execution_context_requires_all_canonical_trace_fields(): void
    {
        $context = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Context/WisdomExecutionContext.php');

        foreach (['companyId', 'traceId', 'correlationId', 'causationId', 'rootCausationId'] as $requiredField) {
            self::assertStringContainsString($requiredField, $context);
        }
    }
}
