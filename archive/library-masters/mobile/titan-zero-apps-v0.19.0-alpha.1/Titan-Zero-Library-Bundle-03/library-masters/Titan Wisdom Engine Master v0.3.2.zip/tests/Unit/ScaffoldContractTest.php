<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Unit;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

require_once dirname(__DIR__, 2) . '/System/Context/WisdomExecutionContext.php';

final class ScaffoldContractTest extends TestCase
{
    public function test_execution_context_serializes_canonical_keys(): void
    {
        $context = new WisdomExecutionContext(
            42,
            '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        );

        self::assertSame([
            'company_id' => 42,
            'trace_id' => '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
            'correlation_id' => '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            'causation_id' => '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            'root_causation_id' => '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        ], $context->toArray());
    }

    public function test_execution_context_rejects_missing_tenant_boundary(): void
    {
        $this->expectException(InvalidArgumentException::class);

        new WisdomExecutionContext(
            0,
            '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        );
    }

    public function test_execution_context_rejects_invalid_trace_identifier(): void
    {
        $this->expectException(InvalidArgumentException::class);

        new WisdomExecutionContext(
            42,
            'not-a-uuid',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
            '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
        );
    }
}
