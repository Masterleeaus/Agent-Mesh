<?php

declare(strict_types=1);

require_once __DIR__ . '/../System/Workforce/CrossExtensionOrchestrator.php';

use App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator;

$orchestrator = new CrossExtensionOrchestrator('TitanWisdomEngine');
$ctx = [
    'company_id' => 7,
    'trace_id' => 'tr-1',
    'correlation_id' => 'co-1',
    'causation_id' => 'ca-1',
    'root_causation_id' => 'root-1',
];
$env = $orchestrator->start($ctx, 'signal.observation', 'titan-knowledge-authority', ['x'=>1]);
if (($env['schema'] ?? null) !== 'titan.cross-extension-handoff.v1') throw new RuntimeException('schema');
if (($env['idempotency_key'] ?? '') === '') throw new RuntimeException('idempotency');
if (($env['authority']['may_increase_authority'] ?? true) !== false) throw new RuntimeException('authority');
$next = $orchestrator->forward($env, 'knowledge.refresh', 'titan-ai-workforce', ['k'=>2]);
if (($next['hop'] ?? null) !== 1) throw new RuntimeException('hop');
if (($next['causation_id'] ?? null) !== ($env['handoff_id'] ?? null)) throw new RuntimeException('causation');
$avail = $orchestrator->propagateAvailability(['signal'=>'available','knowledge'=>'degraded','workforce'=>'available']);
if (($avail['status'] ?? null) !== 'degraded' || ($avail['fail_closed'] ?? true) !== false) throw new RuntimeException('degraded');
$blocked = $orchestrator->propagateAvailability(['signal'=>'available','knowledge'=>'missing_provider']);
if (($blocked['status'] ?? null) !== 'missing_provider' || ($blocked['fail_closed'] ?? false) !== true) throw new RuntimeException('fail closed');
try { $orchestrator->assertFailoverSafe(['authority_level'=>2], ['authority_level'=>3]); throw new RuntimeException('unsafe failover accepted'); } catch (InvalidArgumentException $e) {}
$receipt = $orchestrator->acceptReceipt($next, ['execution_receipt_id'=>'r1','outcome_id'=>'o1','status'=>'succeeded']);
if (($receipt['accepted'] ?? false) !== true || ($receipt['trace_id'] ?? null) !== 'tr-1') throw new RuntimeException('receipt');
echo "CROSS_EXTENSION_ORCHESTRATION: PASS\n";
