<?php

declare(strict_types=1);

namespace Tests\TitanWisdomEngine\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_manifest_only_advertises_implemented_capabilities(): void
    {
        $manifest = json_decode(
            (string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'),
            true,
            512,
            JSON_THROW_ON_ERROR
        );

        self::assertSame('0.3.0', $manifest['version']);
        self::assertSame([
            'titan-wisdom',
            'wisdom.health.read',
            'wisdom.readiness.read',
            'wisdom.outcome.record',
            'wisdom.evidence.attach',
            'wisdom.outcome.resolve',
            'wisdom.outcome.revise',
        ], $manifest['capabilities']);
        self::assertTrue($manifest['queues']['used']);
        self::assertSame(['titan-wisdom'], $manifest['queues']['queue_names']);
        self::assertTrue($manifest['queues']['tenant_context_required']);
        self::assertSame('company_id', $manifest['data']['tenant_key']);
        self::assertTrue($manifest['lifecycle']['supports_disable']);
        self::assertSame('optional', $manifest['governance']['governance']);

        foreach ([
            'titan_wisdom_outcome_records',
            'titan_wisdom_evidence_references',
            'titan_wisdom_outcome_evidence',
            'titan_wisdom_outcome_transitions',
        ] as $table) {
            self::assertContains($table, $manifest['database']['owned_tables']);
        }

        self::assertSame([
            'wisdom.outcome.record',
            'wisdom.evidence.attach',
            'wisdom.outcome.resolve',
            'wisdom.outcome.revise',
        ], array_column($manifest['capability_contracts'], 'id'));

        foreach ($manifest['capability_contracts'] as $contract) {
            self::assertTrue($contract['fresh_governance_required']);
        }
    }

    public function test_delayed_observation_schedule_is_bounded_and_overlap_safe(): void
    {
        $manifest = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('titan-wisdom:due-outcome-observations', $manifest['schedules'][0]['key']);
        self::assertTrue($manifest['schedules'][0]['on_one_server']);
        self::assertTrue($manifest['schedules'][0]['without_overlapping']);
        self::assertTrue($manifest['queues']['delivery_contracts'][0]['idempotency_key_required']);
        self::assertSame('at_least_once', $manifest['queues']['delivery_contracts'][0]['delivery_guarantee']);
    }

    public function test_provider_enforces_runtime_disable_switch(): void
    {
        $provider = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanWisdomEngineServiceProvider.php');

        self::assertStringContainsString("config('titan-wisdom.enabled', true)", $provider);
        self::assertStringContainsString('return;', $provider);
        self::assertStringContainsString('everyFiveMinutes()', $provider);
        self::assertStringContainsString('withoutOverlapping(10)', $provider);
        self::assertStringContainsString('onOneServer()', $provider);
    }
}
