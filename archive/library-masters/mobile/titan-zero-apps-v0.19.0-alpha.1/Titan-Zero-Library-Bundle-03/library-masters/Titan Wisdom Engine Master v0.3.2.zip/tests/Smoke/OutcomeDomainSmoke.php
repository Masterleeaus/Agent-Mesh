<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$files = [
    '/System/Context/WisdomExecutionContext.php',
    '/System/Governance/GovernanceDisposition.php',
    '/System/Governance/WisdomGovernedOperation.php',
    '/System/Governance/GovernanceDecision.php',
    '/System/Governance/GovernanceGateResult.php',
    '/System/Contracts/WisdomGovernanceGateContract.php',
    '/System/Services/WisdomGovernanceGate.php',
    '/System/Support/Uuid.php',
    '/System/Support/CanonicalJson.php',
    '/System/Exceptions/WisdomGovernanceDeniedException.php',
    '/System/Exceptions/OutcomeIdempotencyCollisionException.php',
    '/System/Outcomes/OutcomeClassification.php',
    '/System/Outcomes/OutcomeResolutionState.php',
    '/System/Outcomes/OutcomeRecordDraft.php',
    '/System/Outcomes/OutcomeRecord.php',
    '/System/Outcomes/OutcomeRecordReceipt.php',
    '/System/Contracts/OutcomeRecordRepositoryContract.php',
    '/System/Contracts/WisdomOutcomeRecorderContract.php',
    '/System/Services/WisdomOutcomeRecorder.php',
];

foreach ($files as $file) {
    require_once $root . $file;
}

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeClassification;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeRecorder;

final class MemoryOutcomeRepository implements OutcomeRecordRepositoryContract
{
    /** @var array<string, OutcomeRecord> */
    private array $records = [];

    public function findByOperationId(int $companyId, string $operationId): ?OutcomeRecord
    {
        return $this->records[$companyId . ':' . $operationId] ?? null;
    }

    public function insert(OutcomeRecord $record): void
    {
        $key = $record->companyId . ':' . $record->operationId;
        if (isset($this->records[$key])) {
            throw new RuntimeException('duplicate');
        }
        $this->records[$key] = $record;
    }
}

function ok(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
    echo "PASS: {$message}\n";
}

$context = new WisdomExecutionContext(
    42,
    '0198a8d0-4a22-7b31-9b4c-7429136e23c1',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c2',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c3',
    '0198a8d0-4a22-7b31-9b4c-7429136e23c4',
);
$decision = new GovernanceDecision(
    '0198a8d0-4a22-7b31-9b4c-7429136e2301',
    42,
    WisdomGovernedOperation::OUTCOME_RECORD,
    GovernanceDisposition::ALLOW,
    'governance-policy-v1',
    new DateTimeImmutable('2026-08-19T00:53:00+10:00'),
    new DateTimeImmutable('2026-08-19T01:00:00+10:00'),
);
$draft = new OutcomeRecordDraft(
    operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2300',
    intent: ['type' => 'invoice.collection', 'goal' => 'recover balance'],
    expectedResult: ['invoice_state' => 'paid'],
    actualResult: null,
    resolutionState: OutcomeResolutionState::PENDING,
    classification: OutcomeClassification::INCONCLUSIVE,
    confidence: 0.25,
    sourceComponent: 'titan-command-bus',
    sourceRecordRef: 'receipt:cmd-123',
    contextVersions: ['workflow' => 'collections-v3', 'policy' => 'policy-v2'],
    observationStartedAt: new DateTimeImmutable('2026-08-19T00:55:00+10:00'),
    expectedResolutionAt: new DateTimeImmutable('2026-08-22T00:55:00+10:00'),
);
$repo = new MemoryOutcomeRepository();
$recorder = new WisdomOutcomeRecorder($repo, new WisdomGovernanceGate(300));
$receipt = $recorder->record($context, $draft, $decision, new DateTimeImmutable('2026-08-19T00:55:00+10:00'));

ok($receipt->duplicate === false, 'first governed record is persisted');
ok($receipt->record->companyId === 42, 'tenant boundary is copied from execution context');
ok($receipt->record->resolutionState === OutcomeResolutionState::PENDING, 'pending outcome remains pending');
ok($receipt->record->classification === OutcomeClassification::INCONCLUSIVE, 'pending outcome is inconclusive');
ok($receipt->record->governanceDecisionId === $decision->decisionId, 'governance provenance is retained');
ok($receipt->record->payloadHash !== '', 'canonical payload hash is present');

$duplicate = $recorder->record($context, $draft, $decision, new DateTimeImmutable('2026-08-19T00:55:30+10:00'));
ok($duplicate->duplicate === true, 'same tenant/operation id returns original record');
ok($duplicate->record->outcomeId === $receipt->record->outcomeId, 'idempotent duplicate keeps original outcome id');

$collisionCaught = false;
try {
    $recorder->record($context, new OutcomeRecordDraft(
        operationId: $draft->operationId,
        intent: ['type' => 'invoice.collection', 'goal' => 'different payload'],
        expectedResult: ['invoice_state' => 'paid'],
        actualResult: null,
        resolutionState: OutcomeResolutionState::PENDING,
        classification: OutcomeClassification::INCONCLUSIVE,
        confidence: 0.25,
        sourceComponent: 'titan-command-bus',
        sourceRecordRef: 'receipt:cmd-123',
        contextVersions: ['workflow' => 'collections-v3'],
    ), $decision, new DateTimeImmutable('2026-08-19T00:55:40+10:00'));
} catch (RuntimeException $e) {
    $collisionCaught = str_contains($e->getMessage(), 'idempotency');
}
ok($collisionCaught, 'conflicting payload under same tenant/operation id fails closed');

$invalidPendingCaught = false;
try {
    new OutcomeRecordDraft(
        operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2311',
        intent: ['type' => 'test'],
        expectedResult: ['ok' => true],
        actualResult: ['ok' => true],
        resolutionState: OutcomeResolutionState::PENDING,
        classification: OutcomeClassification::SUCCESS,
        confidence: 1.0,
        sourceComponent: 'test',
        sourceRecordRef: 'test:1',
    );
} catch (InvalidArgumentException) {
    $invalidPendingCaught = true;
}
ok($invalidPendingCaught, 'pending outcome cannot claim success');

$denied = new GovernanceDecision(
    '0198a8d0-4a22-7b31-9b4c-7429136e2302',
    42,
    WisdomGovernedOperation::OUTCOME_RECORD,
    GovernanceDisposition::DENY,
    'governance-policy-v1',
    new DateTimeImmutable('2026-08-19T00:50:00+10:00'),
    new DateTimeImmutable('2026-08-19T01:00:00+10:00'),
);
$deniedCaught = false;
try {
    $recorder->record($context, new OutcomeRecordDraft(
        operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2312',
        intent: ['type' => 'test'],
        expectedResult: ['ok' => true],
        actualResult: null,
        resolutionState: OutcomeResolutionState::PENDING,
        classification: OutcomeClassification::INCONCLUSIVE,
        confidence: 0.1,
        sourceComponent: 'test',
        sourceRecordRef: 'test:2',
    ), $denied, new DateTimeImmutable('2026-08-19T00:55:00+10:00'));
} catch (RuntimeException $e) {
    $deniedCaught = str_contains($e->getMessage(), 'governance');
}
ok($deniedCaught, 'governance denial prevents persistence');

$emptyContextDraft = new OutcomeRecordDraft(
    operationId: '0198a8d0-4a22-7b31-9b4c-7429136e2313',
    intent: ['type' => 'test.empty-context'],
    expectedResult: ['ok' => true],
    actualResult: null,
    resolutionState: OutcomeResolutionState::PENDING,
    classification: OutcomeClassification::INCONCLUSIVE,
    confidence: 0.1,
    sourceComponent: 'test',
    sourceRecordRef: 'test:empty-context',
);
$emptyContextReceipt = $recorder->record(
    $context,
    $emptyContextDraft,
    $decision,
    new DateTimeImmutable('2026-08-19T00:55:10+10:00')
);
$emptyContextJson = json_encode($emptyContextReceipt->record->toContractArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
ok(str_contains($emptyContextJson, '"context_versions":{}'), 'empty context_versions serializes as a JSON object');
$emptyContextRow = $emptyContextReceipt->record->toDatabaseRow();
ok($emptyContextRow['context_versions'] === '{}', 'empty context_versions persists as a JSON object');

echo "Outcome domain smoke: PASS\n";
