<?php
declare(strict_types=1);
$root = dirname(__DIR__, 2);
$data = json_decode((string) file_get_contents($root . '/workforce-integration.json'), true, 512, JSON_THROW_ON_ERROR);
$fail = static function (string $m): never { fwrite(STDERR, "FAIL: {$m}\n"); exit(1); };
(in_array(($data['contract'] ?? null), ['titan.workforce.extension-provider.v1','titan.workforce.extension-provider.v1.1'], true)) || $fail('contract');
(($data['tenancy']['canonical_key'] ?? null) === 'company_id') || $fail('company_id tenancy');
(($data['identity_ownership']['extension_owns_employees'] ?? true) === false) || $fail('employee ownership');
(($data['identity_ownership']['extension_owns_workforce_roles'] ?? true) === false) || $fail('role ownership');
(($data['availability']['fail_closed'] ?? false) === true) || $fail('fail closed');
$expected = ['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];
(($data['availability']['statuses'] ?? []) === $expected) || $fail('availability states');
(($data['governance']['available_implies_authorized'] ?? true) === false) || $fail('availability/authority separation');
(($data['signals']['authority_neutral'] ?? false) === true) || $fail('signal authority neutrality');
(($data['workforce_bindings']['may_grant_authority'] ?? true) === false) || $fail('work binding authority');
$ids = $data['capabilities']['all_ids'] ?? [];
(count($ids) === count(array_unique($ids))) || $fail('duplicate capability ids');
echo "WORKFORCE_INTEGRATION_CONTRACT: PASS\n";
