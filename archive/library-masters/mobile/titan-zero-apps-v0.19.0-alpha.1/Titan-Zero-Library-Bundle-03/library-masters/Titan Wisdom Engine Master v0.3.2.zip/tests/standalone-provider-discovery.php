<?php
declare(strict_types=1);

require_once __DIR__ . '/../System/Workforce/ProviderDiscovery.php';

use App\Extensions\TitanWisdomEngine\System\Workforce\ProviderDiscovery;

function pdAssert(bool $ok, string $message): void { if (!$ok) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); } }

final class FakeContainer {
    public function __construct(private array $bindings) {}
    public function bound(string $key): bool { return array_key_exists($key, $this->bindings); }
    public function make(string $key): mixed { return $this->bindings[$key] ?? null; }
}
final class HealthyProvider { public function workforceAvailability(): array { return ['status'=>'available']; } }
final class DegradedProvider { public function workforceAvailability(): array { return ['status'=>'degraded','reason'=>'maintenance']; } }

$rules = [
 ['provider'=>'titan-ai-workforce','required_for'=>'execution','bindings'=>['titan.workforce.runtime']],
 ['provider'=>'titan-signal-engine','required_for'=>'context','bindings'=>['titan.signal.runtime']],
];
$d = new ProviderDiscovery(new FakeContainer(['titan.workforce.runtime'=>new HealthyProvider(), 'titan.signal.runtime'=>new DegradedProvider()]), $rules);
$s = $d->snapshot();
pdAssert(($s['titan-ai-workforce']['status'] ?? null) === 'available', 'healthy binding discovered');
pdAssert(($s['titan-signal-engine']['status'] ?? null) === 'degraded', 'provider health method respected');
pdAssert(($s['titan-signal-engine']['binding'] ?? null) === 'titan.signal.runtime', 'binding provenance recorded');

$m = new ProviderDiscovery(new FakeContainer([]), $rules);
$ms = $m->snapshot();
pdAssert(($ms['titan-ai-workforce']['status'] ?? null) === 'missing_provider', 'missing provider fails closed');
pdAssert(($ms['titan-ai-workforce']['required_for'] ?? null) === 'execution', 'required_for preserved');

echo "PASS provider discovery\n";
