<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$manager=file_get_contents($root.'/System/Services/WisdomManager.php');
if (str_contains($manager, "config->get('titan-wisdom.tenant_key'")) { fwrite(STDERR,"runtime reads legacy tenant_key config\n"); exit(1); }
if (!str_contains($manager, "'canonical_company_key'") || !str_contains($manager, "'company_key' => \$companyKey")) { fwrite(STDERR,"canonical company readiness vocabulary missing\n"); exit(1); }
$config=file_get_contents($root.'/config/titan-wisdom.php');
if (!str_contains($config, "'company_key' => 'company_id'")) { fwrite(STDERR,"company_key config missing\n"); exit(1); }
echo "PASS company_id-only Wisdom runtime vocabulary\n";
