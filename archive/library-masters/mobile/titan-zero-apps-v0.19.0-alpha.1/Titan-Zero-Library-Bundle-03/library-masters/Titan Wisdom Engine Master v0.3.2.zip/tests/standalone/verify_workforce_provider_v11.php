<?php
$root = dirname(__DIR__, 2);
$data = json_decode(file_get_contents($root . '/workforce-integration.json'), true, 512, JSON_THROW_ON_ERROR);
$fail = static function (string $m): void { fwrite(STDERR, "FAIL: {$m}\n"); exit(1); };
if (($data['schema_version'] ?? null) !== '1.1') $fail('schema version');
if (($data['contract'] ?? null) !== 'titan.workforce.extension-provider.v1.1') $fail('provider contract');
if (($data['tenancy']['canonical_key'] ?? null) !== 'company_id') $fail('canonical company_id tenancy');
$loop = $data['loop_contract'] ?? [];
if (($loop['contract'] ?? null) !== 'titan.observation-knowledge-outcome-loop.v1') $fail('loop contract');
if (($loop['work_item_owner'] ?? null) !== 'titan-ai-workforce') $fail('work item ownership');
if (($loop['authority_neutral_inputs'] ?? null) !== true) $fail('authority neutrality');
if (($loop['provider_pin_required_for_executable_work'] ?? null) !== true) $fail('provider pin');
if (($loop['missing_context_behavior'] ?? null) !== 'fail_closed') $fail('fail closed');
$required = ['trace_id','correlation_id','causation_id','root_causation_id'];
if (array_values($loop['causal_context_required'] ?? []) !== $required) $fail('causal context');
$runtime = $data['runtime_contract'] ?? [];
foreach (['reads_are_non_mutating','commands_require_governed_execution_boundary','commands_require_execution_receipt','fallback_never_raises_authority'] as $k) if (($runtime[$k] ?? null) !== true) $fail($k);
echo "PASS workforce provider v1.1 + observation-knowledge-outcome loop\n";
