<?php
require_once __DIR__.'/../../System/Contracts/ContinuousIntelligence/OutcomeLearningContract.php';
require_once __DIR__.'/../../System/Services/ContinuousIntelligence/OutcomeLearningService.php';

use App\Extensions\TitanWisdomEngine\System\Services\ContinuousIntelligence\OutcomeLearningService;

$s=new OutcomeLearningService();
$r=[
 'company_id'=>'c1','loop_id'=>'l1','recommendation_id'=>'r1','intervention_key'=>'quote_followup',
 'confidence'=>0.8,
 'success_criteria'=>['metric'=>'quote_conversion','direction'=>'AT_LEAST','target'=>42.0]
];
$v=['company_id'=>'c1','loop_id'=>'l1','state'=>'BUSINESS_SUCCESS'];
$m=$s->measure($r,$v,['company_id'=>'c1','value'=>38.2],['company_id'=>'c1','value'=>44.1,'confidence'=>0.9,'time_to_effect_seconds'=>2592000]);
if(($m['success']??false)!==true) exit(1);
if(($m['effectiveness_score']??0)<=0.5) exit(2);
$p=$s->updateInterventionProfile([], $m);
if(($p['outcome_learning_ready']??false)!==true || ($p['measurement_count']??0)!==1) exit(3);
echo "PASS Pass14 Outcome Measurement & Wisdom Learning\n";
