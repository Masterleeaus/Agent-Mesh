<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Contracts\DueOutcomeScannerContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Outcomes\DueOutcomeObservation;
use DateTimeImmutable;
use DateTimeZone;

final class WisdomDueOutcomeScanner implements DueOutcomeScannerContract
{
    public function __construct(private readonly OutcomeResolutionRepositoryContract $outcomes)
    {
    }

    public function scan(?DateTimeImmutable $now = null, int $limit = 100): array
    {
        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $limit = max(1, min($limit, 1000));
        return array_map(
            static fn ($record): DueOutcomeObservation => DueOutcomeObservation::fromOutcome($record),
            $this->outcomes->dueForObservation($now, $limit)
        );
    }
}
