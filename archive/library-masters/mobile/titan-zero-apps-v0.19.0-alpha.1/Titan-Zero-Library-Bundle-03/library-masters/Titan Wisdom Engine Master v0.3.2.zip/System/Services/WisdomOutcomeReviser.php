<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeReviserContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceValidationState;
use App\Extensions\TitanWisdomEngine\System\Exceptions\OutcomeIdempotencyCollisionException;
use App\Extensions\TitanWisdomEngine\System\Exceptions\WisdomGovernanceDeniedException;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRevisionDraft;
use App\Extensions\TitanWisdomEngine\System\Support\CanonicalJson;
use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use Throwable;

final class WisdomOutcomeReviser implements WisdomOutcomeReviserContract
{
    public function __construct(
        private readonly OutcomeRecordRepositoryContract $records,
        private readonly OutcomeResolutionRepositoryContract $outcomes,
        private readonly EvidenceRepositoryContract $evidence,
        private readonly WisdomGovernanceGateContract $governance,
    ) {
    }

    public function revise(
        WisdomExecutionContext $context,
        OutcomeRevisionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt {
        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $gate = $this->governance->evaluate($context, WisdomGovernedOperation::OUTCOME_REVISE, $decision, $now);
        if (!$gate->allowed || $decision === null) {
            throw new WisdomGovernanceDeniedException('Wisdom outcome revision denied by governance: ' . $gate->reasonCode);
        }

        $payloadHash = CanonicalJson::hash(['context' => $context->toArray(), 'revision' => $draft->fingerprintPayload()]);
        $existing = $this->records->findByOperationId($context->companyId, $draft->operationId);
        if ($existing !== null) {
            if (!hash_equals($existing->payloadHash, $payloadHash)) {
                throw new OutcomeIdempotencyCollisionException('Outcome revision operation_id was reused with conflicting semantics.');
            }
            return new OutcomeRecordReceipt($existing, true);
        }

        $original = $this->outcomes->findOutcomeById($context->companyId, $draft->originalOutcomeId);
        if ($original === null) {
            throw new InvalidArgumentException('Original outcome not found in the active tenant boundary.');
        }
        if (!$original->resolutionState->isTerminal()) {
            throw new InvalidArgumentException('Only terminal outcomes may be revised or contradicted.');
        }

        $linked = $this->evidence->forOutcome($context->companyId, $original->outcomeId);
        $linkedByRef = [];
        foreach ($linked as $item) {
            $linkedByRef[$item['evidence']->evidenceRef] = $item;
        }

        $hasAuthoritative = false;
        $hasAuthoritativeContradiction = false;
        foreach ($draft->evidenceRefs as $ref) {
            $item = $linkedByRef[$ref] ?? null;
            if ($item === null) {
                throw new InvalidArgumentException('Revision evidence must be linked to the original tenant outcome: ' . $ref);
            }
            $isAuthoritative = $item['evidence']->validationState === EvidenceValidationState::VALIDATED
                && $item['evidence']->authoritativeForFact;
            $hasAuthoritative = $hasAuthoritative || $isAuthoritative;
            $hasAuthoritativeContradiction = $hasAuthoritativeContradiction
                || ($isAuthoritative && $item['relationship'] === EvidenceRelationship::CONTRADICTS);
        }

        if (!$hasAuthoritative) {
            throw new InvalidArgumentException('Outcome revision requires validated authoritative evidence.');
        }
        if ($draft->resolutionState === OutcomeResolutionState::CONTRADICTED && !$hasAuthoritativeContradiction) {
            throw new InvalidArgumentException('Contradicted outcomes require validated authoritative evidence linked as contradicts.');
        }

        $record = new OutcomeRecord(
            outcomeId: Uuid::v4(),
            companyId: $context->companyId,
            operationId: $draft->operationId,
            traceId: $context->traceId,
            correlationId: $context->correlationId,
            causationId: $context->causationId,
            rootCausationId: $context->rootCausationId,
            intent: $original->intent,
            expectedResult: $original->expectedResult,
            actualResult: $draft->actualResult,
            resolutionState: $draft->resolutionState,
            classification: $draft->classification,
            confidence: $draft->confidence,
            observationStartedAt: $original->observationStartedAt,
            expectedResolutionAt: $original->expectedResolutionAt,
            observedAt: $draft->observedAt,
            resolvedAt: $draft->resolvedAt,
            evidenceRefs: array_values($draft->evidenceRefs),
            attributionRefs: [],
            contextVersions: array_merge($original->contextVersions, ['revises_record_version' => $original->recordVersion]),
            revisesOutcomeId: $original->outcomeId,
            idempotencyKey: 'wisdom.outcome.revision.v1:' . hash('sha256', $context->companyId . '|' . $draft->operationId),
            payloadHash: $payloadHash,
            sourceComponent: 'titan-wisdom',
            sourceRecordRef: 'outcome:' . $original->outcomeId,
            governanceDecisionId: $decision->decisionId,
            governancePolicyVersion: $decision->policyVersion,
            recordVersion: 1,
            createdAt: $now,
            updatedAt: $now,
        );

        try {
            $this->records->insert($record);
            return new OutcomeRecordReceipt($record, false);
        } catch (Throwable $failure) {
            $existing = $this->records->findByOperationId($context->companyId, $draft->operationId);
            if ($existing !== null && hash_equals($existing->payloadHash, $payloadHash)) {
                return new OutcomeRecordReceipt($existing, true);
            }
            throw $failure;
        }
    }
}
