<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Capabilities;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomEvidenceAttacherContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceAttachmentReceipt;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReferenceDraft;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use DateTimeImmutable;

final class AttachEvidenceCapability
{
    public const KEY = 'wisdom.evidence.attach';

    public function __construct(private readonly WisdomEvidenceAttacherContract $attacher)
    {
    }

    public function key(): string
    {
        return self::KEY;
    }

    public function execute(
        WisdomExecutionContext $context,
        string $outcomeId,
        EvidenceReferenceDraft $draft,
        EvidenceRelationship $relationship,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): EvidenceAttachmentReceipt {
        return $this->attacher->attach($context, $outcomeId, $draft, $relationship, $decision, $now);
    }
}
