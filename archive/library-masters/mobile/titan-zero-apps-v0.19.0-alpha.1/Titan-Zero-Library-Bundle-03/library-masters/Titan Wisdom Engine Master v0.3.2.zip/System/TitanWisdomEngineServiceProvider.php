<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanWisdomEngine\System\Capabilities\AttachEvidenceCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\RecordOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\ResolveOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\ReviseOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanWisdomEngine\System\Commands\DispatchDueOutcomesCommand;
use App\Extensions\TitanWisdomEngine\System\Contracts\DueOutcomeScannerContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomEvidenceAttacherContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomManagerContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeRecorderContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeResolverContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeReviserContract;
use App\Extensions\TitanWisdomEngine\System\Repositories\DatabaseEvidenceRepository;
use App\Extensions\TitanWisdomEngine\System\Repositories\DatabaseOutcomeRecordRepository;
use App\Extensions\TitanWisdomEngine\System\Repositories\DatabaseOutcomeResolutionRepository;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomDueOutcomeScanner;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomEvidenceAttacher;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomGovernanceGate;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomManager;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeRecorder;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeResolver;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomOutcomeReviser;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomPredictionEngineContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomRecommendationEngineContract;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomPredictionEngine;
use App\Extensions\TitanWisdomEngine\System\Services\WisdomRecommendationEngine;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanWisdomEngineServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Contracts\ContinuousIntelligence\OutcomeLearningContract::class, \App\Extensions\TitanWisdomEngine\System\Services\ContinuousIntelligence\OutcomeLearningService::class);
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Services\ContinuousIntelligence\LearningConfidenceAdapter::class);
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator::class, static fn (): \App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator => new \App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator('TitanWisdomEngine'));
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\WorkforceLoopRuntime::class, static fn (): \App\Extensions\TitanWisdomEngine\System\Workforce\WorkforceLoopRuntime => \App\Extensions\TitanWisdomEngine\System\Workforce\WorkforceLoopRuntime::fromContractFile(__DIR__ . '/../workforce-integration.json'));
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\ProviderDiscovery::class, fn (): \App\Extensions\TitanWisdomEngine\System\Workforce\ProviderDiscovery => \App\Extensions\TitanWisdomEngine\System\Workforce\ProviderDiscovery::fromContractFile($this->app, __DIR__ . '/../workforce-integration.json'));

        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\DurableHandoffStoreContract::class, static fn (): \App\Extensions\TitanWisdomEngine\System\Workforce\DurableHandoffStoreContract => new \App\Extensions\TitanWisdomEngine\Persistence\Workforce\DatabaseDurableHandoffStore());
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\PersistentOrchestrationRuntime::class, static fn ($app): \App\Extensions\TitanWisdomEngine\System\Workforce\PersistentOrchestrationRuntime => new \App\Extensions\TitanWisdomEngine\System\Workforce\PersistentOrchestrationRuntime($app->make(\App\Extensions\TitanWisdomEngine\System\Workforce\CrossExtensionOrchestrator::class), $app->make(\App\Extensions\TitanWisdomEngine\System\Workforce\DurableHandoffStoreContract::class)));
        $this->app->singleton(\App\Extensions\TitanWisdomEngine\System\Workforce\OrchestrationOperations::class, static fn ($app): \App\Extensions\TitanWisdomEngine\System\Workforce\OrchestrationOperations => new \App\Extensions\TitanWisdomEngine\System\Workforce\OrchestrationOperations($app->make(\App\Extensions\TitanWisdomEngine\System\Workforce\PersistentOrchestrationRuntime::class), $app->make(\App\Extensions\TitanWisdomEngine\System\Workforce\DurableHandoffStoreContract::class)));
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-wisdom.php', 'titan-wisdom');
        $this->app->singleton(WisdomManagerContract::class, WisdomManager::class);
        $this->app->singleton(WisdomPredictionEngineContract::class, WisdomPredictionEngine::class);
        $this->app->singleton(WisdomRecommendationEngineContract::class, WisdomRecommendationEngine::class);
        $this->app->singleton(WisdomGovernanceGateContract::class, static function (): WisdomGovernanceGate {
            return new WisdomGovernanceGate((int) config('titan-wisdom.governance.decision_ttl_seconds', 300));
        });
        $this->app->singleton(OutcomeRecordRepositoryContract::class, static function ($app): DatabaseOutcomeRecordRepository {
            return new DatabaseOutcomeRecordRepository($app['db']->connection());
        });
        $this->app->singleton(OutcomeResolutionRepositoryContract::class, static function ($app): DatabaseOutcomeResolutionRepository {
            return new DatabaseOutcomeResolutionRepository($app['db']->connection());
        });
        $this->app->singleton(EvidenceRepositoryContract::class, static function ($app): DatabaseEvidenceRepository {
            return new DatabaseEvidenceRepository($app['db']->connection());
        });
        $this->app->singleton(WisdomOutcomeRecorderContract::class, WisdomOutcomeRecorder::class);
        $this->app->singleton(WisdomEvidenceAttacherContract::class, WisdomEvidenceAttacher::class);
        $this->app->singleton(WisdomOutcomeResolverContract::class, WisdomOutcomeResolver::class);
        $this->app->singleton(WisdomOutcomeReviserContract::class, WisdomOutcomeReviser::class);
        $this->app->singleton(DueOutcomeScannerContract::class, WisdomDueOutcomeScanner::class);
        $this->app->singleton(RecordOutcomeCapability::class);
        $this->app->singleton(AttachEvidenceCapability::class);
        $this->app->singleton(ResolveOutcomeCapability::class);
        $this->app->singleton(ReviseOutcomeCapability::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-wisdom');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes(
            [__DIR__ . '/../config/titan-wisdom.php' => config_path('titan-wisdom.php')],
            'extension'
        );

        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class, DispatchDueOutcomesCommand::class]);
        }

        if (!(bool) config('titan-wisdom.enabled', true)) {
            return;
        }

        $this->registerRoutes();
        $this->registerSchedule();
    }

    public function registerKey(): string
    {
        return WisdomManager::ENGINE_KEY;
    }

    public static function uninstall(): void
    {
        // Data is retained by design. Only the published extension config is removed.
        File::delete(config_path('titan-wisdom.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];

        $router->group([
            'middleware' => ['web', 'auth'],
            'prefix' => 'dashboard/user/titan-wisdom',
            'as' => 'dashboard.user.titan.wisdom.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/user.php';
        });

        $router->group([
            'middleware' => ['web', 'auth', 'admin'],
            'prefix' => 'dashboard/admin/titan-wisdom',
            'as' => 'dashboard.admin.titan.wisdom.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }

    private function registerSchedule(): void
    {
        $this->app->booted(function (): void {
            /** @var Schedule $schedule */
            $schedule = $this->app->make(Schedule::class);
            $schedule->command('titan:wisdom:dispatch-due-outcomes --limit=250')
                ->everyFiveMinutes()
                ->withoutOverlapping(10)
                ->onOneServer()
                ->name('titan-wisdom:due-outcome-observations');
        });
    }
}
