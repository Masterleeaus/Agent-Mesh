<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use DateTimeImmutable;

interface WisdomOutcomeRecorderContract
{
    public function record(
        WisdomExecutionContext $context,
        OutcomeRecordDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt;
}
