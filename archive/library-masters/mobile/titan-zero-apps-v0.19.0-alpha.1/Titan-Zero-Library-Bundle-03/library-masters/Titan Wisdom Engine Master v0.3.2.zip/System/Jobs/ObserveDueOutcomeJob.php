<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Jobs;

use App\Extensions\TitanWisdomEngine\System\Events\OutcomeObservationDue;
use App\Extensions\TitanWisdomEngine\System\Outcomes\DueOutcomeObservation;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

final class ObserveDueOutcomeJob implements ShouldQueue, ShouldBeUnique
{
    public bool $afterCommit = true;

    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 5;
    public int $timeout = 60;
    public int $uniqueFor = 600;

    public function __construct(
        public readonly DueOutcomeObservation $observation,
        public readonly string $idempotencyKey,
    ) {
    }

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 30, 120, 300];
    }

    public function handle(): void
    {
        // Intentionally non-mutating: downstream observers may collect evidence, but actual
        // OutcomeRecord resolution still requires the governance-gated resolver capability.
        event(new OutcomeObservationDue($this->observation));
    }

    public function uniqueId(): string
    {
        return $this->idempotencyKey;
    }
}
