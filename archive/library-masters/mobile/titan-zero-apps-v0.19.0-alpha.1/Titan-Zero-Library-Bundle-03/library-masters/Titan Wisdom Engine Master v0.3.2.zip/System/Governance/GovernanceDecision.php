<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Governance;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class GovernanceDecision
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $decisionId,
        public int $companyId,
        public WisdomGovernedOperation $operation,
        public GovernanceDisposition $disposition,
        public string $policyVersion,
        public DateTimeImmutable $evaluatedAt,
        public DateTimeImmutable $validUntil,
        public array $reasonCodes = [],
    ) {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $this->decisionId) !== 1) {
            throw new InvalidArgumentException('decision_id must be a valid UUID.');
        }

        if ($this->companyId <= 0) {
            throw new InvalidArgumentException('company_id must be a positive integer.');
        }

        if (trim($this->policyVersion) === '') {
            throw new InvalidArgumentException('policy_version is required.');
        }

        if ($this->validUntil <= $this->evaluatedAt) {
            throw new InvalidArgumentException('valid_until must be later than evaluated_at.');
        }

        foreach ($this->reasonCodes as $reasonCode) {
            if (!is_string($reasonCode) || trim($reasonCode) === '') {
                throw new InvalidArgumentException('reason_codes must contain non-empty strings.');
            }
        }
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'decision_id' => $this->decisionId,
            'company_id' => $this->companyId,
            'operation' => $this->operation->value,
            'disposition' => $this->disposition->value,
            'policy_version' => $this->policyVersion,
            'evaluated_at' => $this->evaluatedAt->format(DATE_ATOM),
            'valid_until' => $this->validUntil->format(DATE_ATOM),
            'reason_codes' => $this->reasonCodes,
        ];
    }
}
