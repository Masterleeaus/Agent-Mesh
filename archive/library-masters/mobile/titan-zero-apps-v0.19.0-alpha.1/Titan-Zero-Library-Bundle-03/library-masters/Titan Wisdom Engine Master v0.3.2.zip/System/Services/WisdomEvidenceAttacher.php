<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomEvidenceAttacherContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceAttachmentReceipt;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReference;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReferenceDraft;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Exceptions\OutcomeIdempotencyCollisionException;
use App\Extensions\TitanWisdomEngine\System\Exceptions\WisdomGovernanceDeniedException;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Support\CanonicalJson;
use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use Throwable;

final class WisdomEvidenceAttacher implements WisdomEvidenceAttacherContract
{
    public function __construct(
        private readonly EvidenceRepositoryContract $evidence,
        private readonly OutcomeResolutionRepositoryContract $outcomes,
        private readonly WisdomGovernanceGateContract $governance,
    ) {
    }

    public function attach(
        WisdomExecutionContext $context,
        string $outcomeId,
        EvidenceReferenceDraft $draft,
        EvidenceRelationship $relationship,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): EvidenceAttachmentReceipt {
        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $gate = $this->governance->evaluate($context, WisdomGovernedOperation::EVIDENCE_ATTACH, $decision, $now);
        if (!$gate->allowed || $decision === null) {
            throw new WisdomGovernanceDeniedException('Wisdom evidence attachment denied by governance: ' . $gate->reasonCode);
        }

        if ($this->outcomes->findOutcomeById($context->companyId, $outcomeId) === null) {
            throw new InvalidArgumentException('Outcome not found in the active tenant boundary.');
        }

        $payloadHash = CanonicalJson::hash([
            'company_id' => $context->companyId,
            'evidence' => $draft->fingerprintPayload(),
        ]);

        $existing = $this->evidence->findByReference($context->companyId, $draft->evidenceRef);
        if ($existing !== null) {
            if (!hash_equals($existing->payloadHash, $payloadHash)) {
                throw new OutcomeIdempotencyCollisionException('Evidence reference collision: the same tenant evidence_ref was reused with conflicting semantics.');
            }
            $this->evidence->linkExisting($context->companyId, $outcomeId, $existing->evidenceRef, $relationship);
            return new EvidenceAttachmentReceipt($existing, $outcomeId, $relationship, true);
        }

        $record = new EvidenceReference(
            id: Uuid::v4(),
            evidenceRef: $draft->evidenceRef,
            companyId: $context->companyId,
            sourceEngine: $draft->sourceEngine,
            sourceType: $draft->sourceType,
            sourceRecordRef: $draft->sourceRecordRef,
            contentHash: $draft->contentHash,
            validationState: $draft->validationState,
            authoritativeForFact: $draft->authoritativeForFact,
            observedAt: $draft->observedAt,
            validatedAt: $draft->validatedAt,
            validatorRef: $draft->validatorRef,
            payloadHash: $payloadHash,
            governanceDecisionId: $decision->decisionId,
            governancePolicyVersion: $decision->policyVersion,
            createdAt: $now,
        );

        try {
            $this->evidence->insert($record, $outcomeId, $relationship);
            return new EvidenceAttachmentReceipt($record, $outcomeId, $relationship, false);
        } catch (Throwable $failure) {
            $existing = $this->evidence->findByReference($context->companyId, $draft->evidenceRef);
            if ($existing !== null) {
                if (!hash_equals($existing->payloadHash, $payloadHash)) {
                    throw new OutcomeIdempotencyCollisionException('Evidence reference collision after concurrent insert.');
                }
                $this->evidence->linkExisting($context->companyId, $outcomeId, $existing->evidenceRef, $relationship);
                return new EvidenceAttachmentReceipt($existing, $outcomeId, $relationship, true);
            }
            throw $failure;
        }
    }
}
