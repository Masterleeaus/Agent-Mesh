<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Contracts;
use App\Extensions\TitanWisdomEngine\System\Prediction\WisdomPrediction;
interface WisdomPredictionEngineContract { public function predict(array $request): WisdomPrediction; }
