<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Capabilities;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeResolverContract;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionReceipt;
use DateTimeImmutable;

final class ResolveOutcomeCapability
{
    public const KEY = 'wisdom.outcome.resolve';

    public function __construct(private readonly WisdomOutcomeResolverContract $resolver)
    {
    }

    public function key(): string
    {
        return self::KEY;
    }

    public function execute(
        WisdomExecutionContext $context,
        OutcomeResolutionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeResolutionReceipt {
        return $this->resolver->resolve($context, $draft, $decision, $now);
    }
}
