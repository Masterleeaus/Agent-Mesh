<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Evidence;

enum EvidenceRelationship: string
{
    case SUPPORTS = 'supports';
    case CONTRADICTS = 'contradicts';
    case CONTEXT = 'context';
}
