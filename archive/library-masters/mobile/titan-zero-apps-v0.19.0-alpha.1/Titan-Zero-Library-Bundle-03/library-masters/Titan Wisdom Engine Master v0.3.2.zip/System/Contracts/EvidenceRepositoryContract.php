<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReference;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;

interface EvidenceRepositoryContract
{
    public function findByReference(int $companyId, string $evidenceRef): ?EvidenceReference;

    public function insert(EvidenceReference $evidence, string $outcomeId, EvidenceRelationship $relationship): void;

    public function linkExisting(int $companyId, string $outcomeId, string $evidenceRef, EvidenceRelationship $relationship): void;

    /** @return list<array{evidence: EvidenceReference, relationship: EvidenceRelationship}> */
    public function forOutcome(int $companyId, string $outcomeId): array;
}
