<?php
namespace App\Extensions\TitanWisdomEngine\System\Contracts\ContinuousIntelligence;

interface OutcomeLearningContract
{
    public function measure(array $recommendation, array $verification, array $baseline, array $observed): array;
    public function updateInterventionProfile(array $profile, array $measurement): array;
}
