<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use InvalidArgumentException;

final class InMemoryDurableHandoffStore implements DurableHandoffStoreContract
{
    /** @var array<string,array<string,mixed>> */
    private array $rows = [];

    public function __construct(private readonly int $maxAttempts = 5) {}

    public function enqueue(array $envelope): array
    {
        $id = (string)($envelope['handoff_id'] ?? '');
        $key = (string)($envelope['idempotency_key'] ?? '');
        $companyId = (int)($envelope['company_id'] ?? 0);
        if ($id === '' || $key === '' || $companyId <= 0) throw new InvalidArgumentException('Durable handoff identity and company_id are required.');
        foreach ($this->rows as $row) if ($row['company_id'] === $companyId && $row['idempotency_key'] === $key) return $row;
        $now = microtime(true);
        return $this->rows[$id] = [
            'handoff_id'=>$id,'idempotency_key'=>$key,'company_id'=>$companyId,'envelope'=>$envelope,
            'status'=>'pending','attempts'=>0,'worker_id'=>null,'leased_until'=>null,'available_at'=>$now,
            'last_error'=>null,'execution_receipt_id'=>null,'created_at'=>$now,'updated_at'=>$now,
        ];
    }

    public function claimNext(int $companyId, string $workerId, int $leaseSeconds = 120): ?array
    {
        if ($companyId <= 0 || trim($workerId) === '') throw new InvalidArgumentException('companyId and workerId are required.');
        $now = microtime(true);
        uasort($this->rows, static fn(array $a,array $b): int => $a['created_at'] <=> $b['created_at']);
        foreach ($this->rows as $id => $row) {
            if ($row['company_id'] !== $companyId) continue;
            $expired = $row['status'] === 'in_flight' && (float)($row['leased_until'] ?? 0) <= $now;
            $ready = in_array($row['status'], ['pending','retry','deferred'], true) && (float)$row['available_at'] <= $now;
            if (!$expired && !$ready) continue;
            $row['status']='in_flight'; $row['attempts']=(int)$row['attempts']+1; $row['worker_id']=$workerId;
            $row['leased_until']=$now+max(1,$leaseSeconds); $row['updated_at']=$now;
            return $this->rows[$id]=$row;
        }
        return null;
    }

    public function markDelivered(string $handoffId, string $receiptId): array
    {
        $row=$this->row($handoffId); $row['status']='delivered'; $row['execution_receipt_id']=$receiptId;
        $row['worker_id']=null; $row['leased_until']=null; $row['updated_at']=microtime(true);
        return $this->rows[$handoffId]=$row;
    }

    public function markFailed(string $handoffId, string $reason, bool $retryable, int $delaySeconds = 0): array
    {
        $row=$this->row($handoffId); $row['last_error']=$reason; $row['worker_id']=null; $row['leased_until']=null;
        $row['status']=$retryable && (int)$row['attempts'] < $this->maxAttempts ? 'retry' : 'dead_letter';
        $row['available_at']=microtime(true)+max(0,$delaySeconds); $row['updated_at']=microtime(true);
        return $this->rows[$handoffId]=$row;
    }

    public function defer(string $handoffId, string $reason, int $delaySeconds = 60): array
    {
        $row=$this->row($handoffId); $row['status']='deferred'; $row['last_error']=$reason; $row['worker_id']=null; $row['leased_until']=null;
        $row['attempts']=max(0,(int)$row['attempts']-1); $row['available_at']=microtime(true)+max(1,$delaySeconds); $row['updated_at']=microtime(true);
        return $this->rows[$handoffId]=$row;
    }

    public function redrive(string $handoffId): array
    {
        $row=$this->row($handoffId); if ($row['status'] !== 'dead_letter') throw new InvalidArgumentException('Only dead-letter handoffs may be redriven.');
        $row['status']='pending'; $row['attempts']=0; $row['last_error']=null; $row['available_at']=microtime(true); $row['updated_at']=microtime(true);
        return $this->rows[$handoffId]=$row;
    }

    public function snapshot(int $companyId): array
    {
        $counts=['pending'=>0,'in_flight'=>0,'retry'=>0,'deferred'=>0,'delivered'=>0,'dead_letter'=>0]; $total=0;
        foreach ($this->rows as $row) if ($row['company_id'] === $companyId) { $total++; $status=(string)$row['status']; $counts[$status]=($counts[$status]??0)+1; }
        return ['company_id'=>$companyId,'total'=>$total] + $counts;
    }

    public function releaseExpiredLeases(int $companyId): int
    {
        $now=microtime(true); $count=0;
        foreach ($this->rows as $id=>$row) if ($row['company_id']===$companyId && $row['status']==='in_flight' && (float)($row['leased_until']??0)<=$now) {
            $row['status']='retry'; $row['worker_id']=null; $row['leased_until']=null; $row['available_at']=$now; $row['updated_at']=$now; $this->rows[$id]=$row; $count++;
        }
        return $count;
    }

    public function listDeadLetters(int $companyId, int $limit = 100): array
    {
        $rows=array_values(array_filter($this->rows, static fn(array $r): bool => $r['company_id']===$companyId && $r['status']==='dead_letter'));
        usort($rows, static fn(array $a,array $b): int => $a['updated_at'] <=> $b['updated_at']);
        return array_slice($rows,0,max(1,$limit));
    }

    public function stalledCount(int $companyId, int $olderThanSeconds = 900): int
    {
        $cutoff=microtime(true)-max(1,$olderThanSeconds); $count=0;
        foreach ($this->rows as $row) if ($row['company_id']===$companyId && in_array($row['status'],['pending','retry','deferred','in_flight'],true) && (float)$row['updated_at']<=$cutoff) $count++;
        return $count;
    }

    public function pruneDeliveredBefore(int $companyId, string $beforeIso8601, int $limit = 1000): int
    {
        $before=strtotime($beforeIso8601); if ($before===false) throw new InvalidArgumentException('Invalid prune timestamp.'); $count=0;
        foreach (array_keys($this->rows) as $id) { $row=$this->rows[$id]; if ($count>=max(1,$limit)) break; if ($row['company_id']===$companyId && $row['status']==='delivered' && (float)$row['updated_at']<$before) { unset($this->rows[$id]); $count++; } }
        return $count;
    }

    private function row(string $handoffId): array
    {
        if (!isset($this->rows[$handoffId])) throw new InvalidArgumentException('Unknown handoff: '.$handoffId);
        return $this->rows[$handoffId];
    }
}
