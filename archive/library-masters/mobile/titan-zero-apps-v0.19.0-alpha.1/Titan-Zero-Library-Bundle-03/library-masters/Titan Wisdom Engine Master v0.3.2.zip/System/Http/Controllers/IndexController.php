<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Http\Controllers;

use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomManagerContract;
use Illuminate\Contracts\View\View;

final class IndexController
{
    public function __invoke(WisdomManagerContract $wisdom): View
    {
        return view('titan-wisdom::index', [
            'health' => $wisdom->health(),
            'readiness' => $wisdom->readiness(),
        ]);
    }
}
