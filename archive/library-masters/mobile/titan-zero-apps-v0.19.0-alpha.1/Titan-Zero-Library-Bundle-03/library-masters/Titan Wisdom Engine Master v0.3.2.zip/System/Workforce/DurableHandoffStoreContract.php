<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

interface DurableHandoffStoreContract
{
    public function enqueue(array $envelope): array;
    public function claimNext(int $companyId, string $workerId, int $leaseSeconds = 120): ?array;
    public function markDelivered(string $handoffId, string $receiptId): array;
    public function markFailed(string $handoffId, string $reason, bool $retryable, int $delaySeconds = 0): array;
    public function defer(string $handoffId, string $reason, int $delaySeconds = 60): array;
    public function redrive(string $handoffId): array;
    public function snapshot(int $companyId): array;
    public function releaseExpiredLeases(int $companyId): int;
    public function listDeadLetters(int $companyId, int $limit = 100): array;
    public function stalledCount(int $companyId, int $olderThanSeconds = 900): int;
    public function pruneDeliveredBefore(int $companyId, string $beforeIso8601, int $limit = 1000): int;
}
