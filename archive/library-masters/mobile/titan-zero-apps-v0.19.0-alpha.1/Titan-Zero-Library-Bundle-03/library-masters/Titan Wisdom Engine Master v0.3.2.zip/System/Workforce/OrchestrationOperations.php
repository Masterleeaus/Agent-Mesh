<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use InvalidArgumentException;

final class OrchestrationOperations
{
    public function __construct(private readonly PersistentOrchestrationRuntime $runtime, private readonly DurableHandoffStoreContract $store) {}

    public function dispatchBatch(int $companyId, string $workerId, array $providerStatuses, callable $executor, int $limit = 25): array
    {
        if ($companyId<=0 || trim($workerId)==='') throw new InvalidArgumentException('companyId and workerId are required.');
        $processed=$delivered=$failed=0; $this->store->releaseExpiredLeases($companyId);
        while ($processed<max(1,$limit)) {
            $claimed=$this->runtime->claimNext($companyId,$workerId,$providerStatuses); if ($claimed===null) break; $processed++;
            try { $receipt=$executor((array)$claimed['envelope']); $this->runtime->recordSuccess($claimed,(array)$receipt); $delivered++; }
            catch (\Throwable $e) { $retryable=!($e instanceof InvalidArgumentException); $attempt=max(1,(int)($claimed['attempts']??1)); $delay=$retryable ? min(3600,30*(2 ** min(7,$attempt-1))) : 0; $this->store->markFailed((string)$claimed['handoff_id'],$e->getMessage(),$retryable,$delay); $failed++; }
        }
        return ['company_id'=>$companyId,'processed'=>$processed,'delivered'=>$delivered,'failed'=>$failed,'health'=>$this->health($companyId)];
    }

    public function deadLetters(int $companyId, int $limit = 100): array { return $this->store->listDeadLetters($companyId,$limit); }
    public function redrive(int $companyId, string $handoffId): array { foreach ($this->store->listDeadLetters($companyId,1000) as $row) if (($row['handoff_id']??null)===$handoffId) return $this->runtime->replayDeadLetter($handoffId); throw new InvalidArgumentException('Dead-letter handoff not found for company.'); }
    public function prune(int $companyId, int $retentionDays = 30, int $limit = 1000): int { return $this->store->pruneDeliveredBefore($companyId,(new \DateTimeImmutable('now',new \DateTimeZone('UTC')))->modify('-'.max(1,$retentionDays).' days')->format(DATE_ATOM),$limit); }
    public function health(int $companyId, int $stalledAfterSeconds = 900): array { $base=$this->runtime->healthSnapshot($companyId); $base['stalled']=$this->store->stalledCount($companyId,$stalledAfterSeconds); $base['dead_letters']=$this->store->listDeadLetters($companyId,25); return $base; }
}
