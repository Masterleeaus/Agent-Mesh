<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeRecorderContract;
use App\Extensions\TitanWisdomEngine\System\Exceptions\OutcomeIdempotencyCollisionException;
use App\Extensions\TitanWisdomEngine\System\Exceptions\WisdomGovernanceDeniedException;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use App\Extensions\TitanWisdomEngine\System\Support\CanonicalJson;
use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use DateTimeZone;
use Throwable;

final class WisdomOutcomeRecorder implements WisdomOutcomeRecorderContract
{
    public function __construct(
        private readonly OutcomeRecordRepositoryContract $repository,
        private readonly WisdomGovernanceGateContract $governance,
    ) {
    }

    public function record(
        WisdomExecutionContext $context,
        OutcomeRecordDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt {
        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $gate = $this->governance->evaluate($context, WisdomGovernedOperation::OUTCOME_RECORD, $decision, $now);

        if (!$gate->allowed || $decision === null) {
            throw new WisdomGovernanceDeniedException('Wisdom outcome recording denied by governance: ' . $gate->reasonCode);
        }

        $payloadHash = CanonicalJson::hash([
            'context' => $context->toArray(),
            'draft' => $draft->fingerprintPayload(),
        ]);
        $idempotencyKey = 'wisdom.outcome.v1:' . hash('sha256', $context->companyId . '|' . $draft->operationId);

        $existing = $this->repository->findByOperationId($context->companyId, $draft->operationId);
        if ($existing !== null) {
            return $this->duplicateOrCollision($existing, $payloadHash);
        }

        $record = new OutcomeRecord(
            outcomeId: Uuid::v4(),
            companyId: $context->companyId,
            operationId: $draft->operationId,
            traceId: $context->traceId,
            correlationId: $context->correlationId,
            causationId: $context->causationId,
            rootCausationId: $context->rootCausationId,
            intent: $draft->intent,
            expectedResult: $draft->expectedResult,
            actualResult: $draft->actualResult,
            resolutionState: $draft->resolutionState,
            classification: $draft->classification,
            confidence: $draft->confidence,
            observationStartedAt: $draft->observationStartedAt,
            expectedResolutionAt: $draft->expectedResolutionAt,
            observedAt: $draft->observedAt,
            resolvedAt: $draft->resolvedAt,
            evidenceRefs: [],
            attributionRefs: [],
            contextVersions: $draft->contextVersions,
            revisesOutcomeId: $draft->revisesOutcomeId,
            idempotencyKey: $idempotencyKey,
            payloadHash: $payloadHash,
            sourceComponent: $draft->sourceComponent,
            sourceRecordRef: $draft->sourceRecordRef,
            governanceDecisionId: $decision->decisionId,
            governancePolicyVersion: $decision->policyVersion,
            recordVersion: 1,
            createdAt: $now,
            updatedAt: $now,
        );

        try {
            $this->repository->insert($record);
            return new OutcomeRecordReceipt($record, false);
        } catch (Throwable $writeFailure) {
            // A concurrent first writer may have won the unique tenant+operation_id race.
            $existing = $this->repository->findByOperationId($context->companyId, $draft->operationId);
            if ($existing !== null) {
                return $this->duplicateOrCollision($existing, $payloadHash);
            }
            throw $writeFailure;
        }
    }

    private function duplicateOrCollision(OutcomeRecord $existing, string $payloadHash): OutcomeRecordReceipt
    {
        if (!hash_equals($existing->payloadHash, $payloadHash)) {
            throw new OutcomeIdempotencyCollisionException(
                'Wisdom idempotency collision: the same company_id + operation_id was reused with a conflicting payload.'
            );
        }

        return new OutcomeRecordReceipt($existing, true);
    }
}
