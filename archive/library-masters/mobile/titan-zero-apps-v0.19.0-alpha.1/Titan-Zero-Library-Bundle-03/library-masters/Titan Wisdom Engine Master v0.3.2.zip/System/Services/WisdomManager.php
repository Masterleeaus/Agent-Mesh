<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomManagerContract;
use Illuminate\Contracts\Config\Repository as ConfigRepository;

final class WisdomManager implements WisdomManagerContract
{
    public const ENGINE_KEY = 'titan-wisdom';
    public const VERSION = '0.3.0';

    /** @var list<string> */
    private const CAPABILITIES = [
        self::ENGINE_KEY,
        'wisdom.health.read',
        'wisdom.readiness.read',
        'wisdom.outcome.record',
        'wisdom.evidence.attach',
        'wisdom.outcome.resolve',
        'wisdom.outcome.revise',
    ];

    public function __construct(private readonly ConfigRepository $config)
    {
    }

    public function isEnabled(): bool
    {
        return (bool) $this->config->get('titan-wisdom.enabled', true);
    }

    public function health(): array
    {
        return [
            'engine' => self::ENGINE_KEY,
            'status' => $this->isEnabled() ? 'operational-foundation' : 'disabled',
            'version' => self::VERSION,
            'phase' => 'evidence-and-delayed-outcome-resolution',
            'operational_capabilities' => $this->declaredCapabilities(),
            'governance_fail_closed' => (bool) $this->config->get('titan-wisdom.governance.fail_closed', true),
            'outcome_recording_ready' => true,
            'evidence_ingestion_ready' => true,
            'delayed_resolution_ready' => true,
            'outcome_learning_ready' => false,
        ];
    }

    public function readiness(): array
    {
        $companyKey = (string) $this->config->get('titan-wisdom.company_key', 'company_id');
        $queue = trim((string) $this->config->get('titan-wisdom.queue', ''));
        $traceContextRequired = (bool) $this->config->get('titan-wisdom.require_trace_context', true);
        $governanceRequired = (bool) $this->config->get('titan-wisdom.governance.required_for_mutations', true);
        $governanceFailClosed = (bool) $this->config->get('titan-wisdom.governance.fail_closed', true);
        $governanceDecisionTtl = (int) $this->config->get('titan-wisdom.governance.decision_ttl_seconds', 300);
        $observationDispatchEnabled = (bool) $this->config->get('titan-wisdom.observations.dispatch_enabled', true);
        $scanLimit = (int) $this->config->get('titan-wisdom.observations.scan_limit', 250);

        $checks = [
            'runtime_enabled' => $this->isEnabled(),
            'canonical_company_key' => $companyKey === 'company_id',
            'trace_context_required' => $traceContextRequired,
            'root_causation_required' => $traceContextRequired,
            'queue_name_configured' => $queue !== '',
            'governance_required_for_mutations' => $governanceRequired,
            'governance_fail_closed' => $governanceFailClosed,
            'governance_decision_ttl_valid' => $governanceDecisionTtl > 0,
            'outcome_domain_implemented' => true,
            'evidence_domain_implemented' => true,
            'outcome_resolution_implemented' => true,
            'append_only_revision_lineage' => true,
            'self_report_not_authoritative' => true,
            'delayed_observation_dispatch_enabled' => $observationDispatchEnabled,
            'delayed_observation_scan_limit_valid' => $scanLimit > 0 && $scanLimit <= 1000,
        ];

        return [
            'engine' => self::ENGINE_KEY,
            'version' => self::VERSION,
            'ready' => !in_array(false, $checks, true),
            'operational_scope' => 'governed-outcomes-evidence-delayed-resolution',
            'checks' => $checks,
            'queue' => $queue,
            'company_key' => $companyKey,
            'governance_decision_ttl_seconds' => $governanceDecisionTtl,
            'observation_scan_limit' => $scanLimit,
        ];
    }

    public function declaredCapabilities(): array
    {
        return self::CAPABILITIES;
    }
}
