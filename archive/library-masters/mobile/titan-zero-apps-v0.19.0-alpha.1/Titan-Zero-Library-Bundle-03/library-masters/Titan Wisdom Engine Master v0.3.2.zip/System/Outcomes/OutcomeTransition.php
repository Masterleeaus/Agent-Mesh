<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

use DateTimeImmutable;

final readonly class OutcomeTransition
{
    /** @param list<string> $evidenceRefs
     *  @param array<string, mixed> $recordSnapshot
     */
    public function __construct(
        public string $transitionId,
        public int $companyId,
        public string $outcomeId,
        public string $operationId,
        public OutcomeResolutionState $fromState,
        public OutcomeResolutionState $toState,
        public OutcomeClassification $classification,
        public array $evidenceRefs,
        public int $fromRecordVersion,
        public int $toRecordVersion,
        public string $payloadHash,
        public string $governanceDecisionId,
        public string $governancePolicyVersion,
        public array $recordSnapshot,
        public DateTimeImmutable $createdAt,
    ) {
    }

    /** @return array<string, mixed> */
    public function toDatabaseRow(): array
    {
        return [
            'id' => $this->transitionId,
            'company_id' => $this->companyId,
            'outcome_id' => $this->outcomeId,
            'operation_id' => $this->operationId,
            'from_state' => $this->fromState->value,
            'to_state' => $this->toState->value,
            'classification' => $this->classification->value,
            'evidence_refs' => json_encode($this->evidenceRefs, JSON_THROW_ON_ERROR),
            'from_record_version' => $this->fromRecordVersion,
            'to_record_version' => $this->toRecordVersion,
            'payload_hash' => $this->payloadHash,
            'governance_decision_id' => $this->governanceDecisionId,
            'governance_policy_version' => $this->governancePolicyVersion,
            'record_snapshot' => json_encode($this->recordSnapshot, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'created_at' => $this->createdAt->format('Y-m-d H:i:s.u'),
        ];
    }

    /** @param array<string, mixed> $row */
    public static function fromDatabaseRow(array $row): self
    {
        return new self(
            transitionId: (string) $row['id'],
            companyId: (int) $row['company_id'],
            outcomeId: (string) $row['outcome_id'],
            operationId: (string) $row['operation_id'],
            fromState: OutcomeResolutionState::from((string) $row['from_state']),
            toState: OutcomeResolutionState::from((string) $row['to_state']),
            classification: OutcomeClassification::from((string) $row['classification']),
            evidenceRefs: self::decodeList($row['evidence_refs']),
            fromRecordVersion: (int) $row['from_record_version'],
            toRecordVersion: (int) $row['to_record_version'],
            payloadHash: (string) $row['payload_hash'],
            governanceDecisionId: (string) $row['governance_decision_id'],
            governancePolicyVersion: (string) $row['governance_policy_version'],
            recordSnapshot: self::decodeObject($row['record_snapshot']),
            createdAt: new DateTimeImmutable((string) $row['created_at']),
        );
    }

    /** @return list<string> */
    private static function decodeList(mixed $value): array
    {
        $decoded = is_array($value) ? $value : json_decode((string) $value, true, 512, JSON_THROW_ON_ERROR);
        return is_array($decoded) ? array_values(array_map('strval', $decoded)) : [];
    }

    /** @return array<string, mixed> */
    private static function decodeObject(mixed $value): array
    {
        $decoded = is_array($value) ? $value : json_decode((string) $value, true, 512, JSON_THROW_ON_ERROR);
        return is_array($decoded) ? $decoded : [];
    }
}
