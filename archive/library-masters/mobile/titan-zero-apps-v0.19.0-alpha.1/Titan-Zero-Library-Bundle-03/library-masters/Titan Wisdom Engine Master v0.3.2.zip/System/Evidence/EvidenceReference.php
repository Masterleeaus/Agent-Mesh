<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Evidence;

use DateTimeImmutable;

final readonly class EvidenceReference
{
    public const SCHEMA_VERSION = '1.0';

    public function __construct(
        public string $id,
        public string $evidenceRef,
        public int $companyId,
        public string $sourceEngine,
        public string $sourceType,
        public string $sourceRecordRef,
        public ?string $contentHash,
        public EvidenceValidationState $validationState,
        public bool $authoritativeForFact,
        public DateTimeImmutable $observedAt,
        public ?DateTimeImmutable $validatedAt,
        public ?string $validatorRef,
        public string $payloadHash,
        public string $governanceDecisionId,
        public string $governancePolicyVersion,
        public DateTimeImmutable $createdAt,
    ) {
    }

    /** @return array<string, mixed> */
    public function toContractArray(): array
    {
        return [
            'schema_version' => self::SCHEMA_VERSION,
            'evidence_ref' => $this->evidenceRef,
            'company_id' => $this->companyId,
            'source_engine' => $this->sourceEngine,
            'source_type' => $this->sourceType,
            'source_record_ref' => $this->sourceRecordRef,
            'content_hash' => $this->contentHash,
            'validation_state' => $this->validationState->value,
            'authoritative_for_fact' => $this->authoritativeForFact,
            'observed_at' => $this->observedAt->format(DATE_ATOM),
            'validated_at' => $this->validatedAt?->format(DATE_ATOM),
            'validator_ref' => $this->validatorRef,
        ];
    }

    /** @return array<string, mixed> */
    public function toDatabaseRow(): array
    {
        return [
            'id' => $this->id,
            'schema_version' => self::SCHEMA_VERSION,
            'evidence_ref' => $this->evidenceRef,
            'company_id' => $this->companyId,
            'source_engine' => $this->sourceEngine,
            'source_type' => $this->sourceType,
            'source_record_ref' => $this->sourceRecordRef,
            'content_hash' => $this->contentHash,
            'validation_state' => $this->validationState->value,
            'authoritative_for_fact' => $this->authoritativeForFact,
            'observed_at' => $this->observedAt->format('Y-m-d H:i:s.u'),
            'validated_at' => $this->validatedAt?->format('Y-m-d H:i:s.u'),
            'validator_ref' => $this->validatorRef,
            'payload_hash' => $this->payloadHash,
            'governance_decision_id' => $this->governanceDecisionId,
            'governance_policy_version' => $this->governancePolicyVersion,
            'created_at' => $this->createdAt->format('Y-m-d H:i:s.u'),
        ];
    }

    /** @param array<string, mixed> $row */
    public static function fromDatabaseRow(array $row): self
    {
        return new self(
            id: (string) $row['id'],
            evidenceRef: (string) $row['evidence_ref'],
            companyId: (int) $row['company_id'],
            sourceEngine: (string) $row['source_engine'],
            sourceType: (string) $row['source_type'],
            sourceRecordRef: (string) $row['source_record_ref'],
            contentHash: $row['content_hash'] === null ? null : (string) $row['content_hash'],
            validationState: EvidenceValidationState::from((string) $row['validation_state']),
            authoritativeForFact: (bool) $row['authoritative_for_fact'],
            observedAt: new DateTimeImmutable((string) $row['observed_at']),
            validatedAt: $row['validated_at'] === null ? null : new DateTimeImmutable((string) $row['validated_at']),
            validatorRef: $row['validator_ref'] === null ? null : (string) $row['validator_ref'],
            payloadHash: (string) $row['payload_hash'],
            governanceDecisionId: (string) $row['governance_decision_id'],
            governancePolicyVersion: (string) $row['governance_policy_version'],
            createdAt: new DateTimeImmutable((string) $row['created_at']),
        );
    }
}
