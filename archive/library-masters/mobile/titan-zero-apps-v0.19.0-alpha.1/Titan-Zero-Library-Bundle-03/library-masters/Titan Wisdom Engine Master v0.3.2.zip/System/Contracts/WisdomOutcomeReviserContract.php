<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRevisionDraft;
use DateTimeImmutable;

interface WisdomOutcomeReviserContract
{
    public function revise(
        WisdomExecutionContext $context,
        OutcomeRevisionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt;
}
