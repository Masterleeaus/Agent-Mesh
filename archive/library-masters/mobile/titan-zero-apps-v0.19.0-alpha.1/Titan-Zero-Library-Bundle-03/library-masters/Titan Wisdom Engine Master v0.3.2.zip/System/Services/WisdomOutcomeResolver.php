<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeResolverContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceValidationState;
use App\Extensions\TitanWisdomEngine\System\Exceptions\OutcomeIdempotencyCollisionException;
use App\Extensions\TitanWisdomEngine\System\Exceptions\WisdomGovernanceDeniedException;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionReceipt;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionState;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeTransition;
use App\Extensions\TitanWisdomEngine\System\Support\CanonicalJson;
use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use RuntimeException;

final class WisdomOutcomeResolver implements WisdomOutcomeResolverContract
{
    public function __construct(
        private readonly OutcomeResolutionRepositoryContract $outcomes,
        private readonly EvidenceRepositoryContract $evidence,
        private readonly WisdomGovernanceGateContract $governance,
    ) {
    }

    public function resolve(
        WisdomExecutionContext $context,
        OutcomeResolutionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeResolutionReceipt {
        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $gate = $this->governance->evaluate($context, WisdomGovernedOperation::OUTCOME_RESOLVE, $decision, $now);
        if (!$gate->allowed || $decision === null) {
            throw new WisdomGovernanceDeniedException('Wisdom outcome resolution denied by governance: ' . $gate->reasonCode);
        }

        $payloadHash = CanonicalJson::hash(['context' => $context->toArray(), 'resolution' => $draft->fingerprintPayload()]);
        $existingTransition = $this->outcomes->findTransitionByOperationId($context->companyId, $draft->operationId);
        if ($existingTransition !== null) {
            if (!hash_equals($existingTransition->payloadHash, $payloadHash)) {
                throw new OutcomeIdempotencyCollisionException('Outcome resolution operation_id was reused with a conflicting payload.');
            }
            return new OutcomeResolutionReceipt($this->recordFromSnapshot($existingTransition->recordSnapshot), $existingTransition, true);
        }

        $current = $this->outcomes->findOutcomeById($context->companyId, $draft->outcomeId);
        if ($current === null) {
            throw new InvalidArgumentException('Outcome not found in the active tenant boundary.');
        }
        if ($current->resolutionState->isTerminal()) {
            throw new InvalidArgumentException('Terminal outcomes require an explicit revision/contradiction operation.');
        }

        $linked = $this->evidence->forOutcome($context->companyId, $draft->outcomeId);
        $linkedByRef = [];
        foreach ($linked as $item) {
            $linkedByRef[$item['evidence']->evidenceRef] = $item;
        }

        $authoritative = false;
        foreach ($draft->evidenceRefs as $ref) {
            $item = $linkedByRef[$ref] ?? null;
            if ($item === null) {
                throw new InvalidArgumentException('Resolution evidence must already be linked to the same tenant outcome: ' . $ref);
            }
            if ($item['relationship'] === EvidenceRelationship::SUPPORTS
                && $item['evidence']->validationState === EvidenceValidationState::VALIDATED
                && $item['evidence']->authoritativeForFact) {
                $authoritative = true;
            }
        }
        if (!$authoritative) {
            throw new InvalidArgumentException('Conclusive outcome resolution requires at least one validated authoritative supporting evidence reference.');
        }

        $next = new OutcomeRecord(
            outcomeId: $current->outcomeId,
            companyId: $current->companyId,
            operationId: $current->operationId,
            traceId: $current->traceId,
            correlationId: $current->correlationId,
            causationId: $current->causationId,
            rootCausationId: $current->rootCausationId,
            intent: $current->intent,
            expectedResult: $current->expectedResult,
            actualResult: $draft->actualResult,
            resolutionState: OutcomeResolutionState::RESOLVED,
            classification: $draft->classification,
            confidence: $draft->confidence,
            observationStartedAt: $current->observationStartedAt,
            expectedResolutionAt: $current->expectedResolutionAt,
            observedAt: $draft->observedAt,
            resolvedAt: $draft->resolvedAt,
            evidenceRefs: array_values(array_unique(array_merge($current->evidenceRefs, $draft->evidenceRefs))),
            attributionRefs: $current->attributionRefs,
            contextVersions: $current->contextVersions,
            revisesOutcomeId: $current->revisesOutcomeId,
            idempotencyKey: $current->idempotencyKey,
            payloadHash: $current->payloadHash,
            sourceComponent: $current->sourceComponent,
            sourceRecordRef: $current->sourceRecordRef,
            governanceDecisionId: $current->governanceDecisionId,
            governancePolicyVersion: $current->governancePolicyVersion,
            recordVersion: $current->recordVersion + 1,
            createdAt: $current->createdAt,
            updatedAt: $now,
        );

        $transition = new OutcomeTransition(
            transitionId: Uuid::v4(),
            companyId: $context->companyId,
            outcomeId: $current->outcomeId,
            operationId: $draft->operationId,
            fromState: $current->resolutionState,
            toState: OutcomeResolutionState::RESOLVED,
            classification: $draft->classification,
            evidenceRefs: $draft->evidenceRefs,
            fromRecordVersion: $current->recordVersion,
            toRecordVersion: $next->recordVersion,
            payloadHash: $payloadHash,
            governanceDecisionId: $decision->decisionId,
            governancePolicyVersion: $decision->policyVersion,
            recordSnapshot: $next->toDatabaseRow(),
            createdAt: $now,
        );

        if (!$this->outcomes->compareAndSwap($current, $next, $transition)) {
            $won = $this->outcomes->findTransitionByOperationId($context->companyId, $draft->operationId);
            if ($won !== null && hash_equals($won->payloadHash, $payloadHash)) {
                return new OutcomeResolutionReceipt($this->recordFromSnapshot($won->recordSnapshot), $won, true);
            }
            throw new RuntimeException('Outcome resolution lost optimistic concurrency race; retry with a fresh record version.');
        }

        return new OutcomeResolutionReceipt($next, $transition, false);
    }

    /** @param array<string, mixed> $snapshot */
    private function recordFromSnapshot(array $snapshot): OutcomeRecord
    {
        return OutcomeRecord::fromDatabaseRow($snapshot);
    }
}
