<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Outcomes\DueOutcomeObservation;
use DateTimeImmutable;

interface DueOutcomeScannerContract
{
    /** @return list<DueOutcomeObservation> */
    public function scan(?DateTimeImmutable $now = null, int $limit = 100): array;
}
