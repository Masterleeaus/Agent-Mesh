<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

enum OutcomeClassification: string
{
    case SUCCESS = 'success';
    case PARTIAL_SUCCESS = 'partial_success';
    case FAILURE = 'failure';
    case INCONCLUSIVE = 'inconclusive';
    case CANCELLED = 'cancelled';
    case SUPERSEDED = 'superseded';
}
