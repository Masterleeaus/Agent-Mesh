<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use Throwable;

final class ProviderDiscovery
{
    private const VALID = ['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];

    /** @param object $container @param list<array<string,mixed>> $rules */
    public function __construct(private readonly object $container, private readonly array $rules) {}

    public static function fromContractFile(object $container, string $path): self
    {
        $decoded = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
        $rules = is_array($decoded) ? ($decoded['provider_discovery']['dependencies'] ?? []) : [];
        return new self($container, is_array($rules) ? $rules : []);
    }

    /** @return array<string,array<string,mixed>> */
    public function snapshot(): array
    {
        $result = [];
        foreach ($this->rules as $rule) {
            if (!is_array($rule)) continue;
            $provider = trim((string)($rule['provider'] ?? ''));
            if ($provider === '') continue;
            $requiredFor = (string)($rule['required_for'] ?? 'context');
            $bindings = array_values(array_filter((array)($rule['bindings'] ?? []), 'is_string'));
            $entry = ['status'=>'missing_provider','required_for'=>$requiredFor,'binding'=>null,'reason'=>'no_registered_binding'];
            foreach ($bindings as $binding) {
                try {
                    if (!method_exists($this->container, 'bound') || !$this->container->bound($binding)) continue;
                    $instance = method_exists($this->container, 'make') ? $this->container->make($binding) : null;
                    $status = 'available';
                    $reason = null;
                    if (is_object($instance) && method_exists($instance, 'workforceAvailability')) {
                        $health = $instance->workforceAvailability();
                        if (is_array($health)) { $status = (string)($health['status'] ?? 'unavailable'); $reason = $health['reason'] ?? null; }
                    } elseif (is_object($instance) && method_exists($instance, 'availability')) {
                        $health = $instance->availability([]);
                        if (is_array($health)) { $status = (string)($health['status'] ?? 'unavailable'); $reason = $health['reason'] ?? null; }
                    }
                    if (!in_array($status, self::VALID, true)) $status = 'unavailable';
                    $entry = ['status'=>$status,'required_for'=>$requiredFor,'binding'=>$binding,'reason'=>$reason];
                    break;
                } catch (Throwable $e) {
                    $entry = ['status'=>'unavailable','required_for'=>$requiredFor,'binding'=>$binding,'reason'=>'provider_resolution_failed'];
                    break;
                }
            }
            $result[$provider] = $entry;
        }
        return $result;
    }

    /** @return array<string,string> */
    public function requiredStatuses(string $purpose = 'execution'): array
    {
        $out = [];
        foreach ($this->snapshot() as $provider => $entry) {
            if (($entry['required_for'] ?? null) === $purpose || ($entry['required_for'] ?? null) === 'all') {
                $out[$provider] = (string)($entry['status'] ?? 'unavailable');
            }
        }
        return $out;
    }
}
