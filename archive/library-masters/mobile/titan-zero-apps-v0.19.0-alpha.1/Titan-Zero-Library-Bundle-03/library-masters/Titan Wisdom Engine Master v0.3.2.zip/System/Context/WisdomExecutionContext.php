<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Context;

use InvalidArgumentException;

/**
 * Immutable trace + tenant context required for every future durable Wisdom write.
 *
 * This is deliberately extension-local and dependency-free so callers can adapt
 * their public Titan context contracts without importing another extension's
 * implementation classes.
 */
final readonly class WisdomExecutionContext
{
    public function __construct(
        public int $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
    ) {
        if ($this->companyId <= 0) {
            throw new InvalidArgumentException('company_id must be a positive integer.');
        }

        $this->assertUuid('trace_id', $this->traceId);
        $this->assertUuid('correlation_id', $this->correlationId);
        $this->assertUuid('causation_id', $this->causationId);
        $this->assertUuid('root_causation_id', $this->rootCausationId);
    }

    /** @return array{company_id:int,trace_id:string,correlation_id:string,causation_id:string,root_causation_id:string} */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
        ];
    }

    private function assertUuid(string $field, string $value): void
    {
        if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) !== 1) {
            throw new InvalidArgumentException(sprintf('%s must be a valid UUID.', $field));
        }
    }
}
