<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Repositories;

use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReference;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use Illuminate\Database\ConnectionInterface;
use RuntimeException;

final class DatabaseEvidenceRepository implements EvidenceRepositoryContract
{
    private const EVIDENCE_TABLE = 'titan_wisdom_evidence_references';
    private const LINK_TABLE = 'titan_wisdom_outcome_evidence';

    public function __construct(private readonly ConnectionInterface $database)
    {
    }

    public function findByReference(int $companyId, string $evidenceRef): ?EvidenceReference
    {
        $row = $this->database->table(self::EVIDENCE_TABLE)
            ->where('company_id', $companyId)
            ->where('evidence_ref', $evidenceRef)
            ->first();

        return $row === null ? null : EvidenceReference::fromDatabaseRow((array) $row);
    }

    public function insert(EvidenceReference $evidence, string $outcomeId, EvidenceRelationship $relationship): void
    {
        $this->database->transaction(function () use ($evidence, $outcomeId, $relationship): void {
            $this->database->table(self::EVIDENCE_TABLE)->insert($evidence->toDatabaseRow());
            $this->database->table(self::LINK_TABLE)->insert([
                'company_id' => $evidence->companyId,
                'outcome_id' => $outcomeId,
                'evidence_ref' => $evidence->evidenceRef,
                'relationship' => $relationship->value,
                'created_at' => $evidence->createdAt->format('Y-m-d H:i:s.u'),
            ]);
        });
    }

    public function linkExisting(int $companyId, string $outcomeId, string $evidenceRef, EvidenceRelationship $relationship): void
    {
        $existing = $this->database->table(self::LINK_TABLE)
            ->where('company_id', $companyId)
            ->where('outcome_id', $outcomeId)
            ->where('evidence_ref', $evidenceRef)
            ->first();

        if ($existing !== null) {
            if ((string) $existing->relationship !== $relationship->value) {
                throw new RuntimeException('Evidence relationship collision for the same tenant outcome and evidence_ref.');
            }
            return;
        }

        $this->database->table(self::LINK_TABLE)->insert([
            'company_id' => $companyId,
            'outcome_id' => $outcomeId,
            'evidence_ref' => $evidenceRef,
            'relationship' => $relationship->value,
            'created_at' => now()->format('Y-m-d H:i:s.u'),
        ]);
    }

    public function forOutcome(int $companyId, string $outcomeId): array
    {
        $rows = $this->database->table(self::LINK_TABLE . ' as links')
            ->join(self::EVIDENCE_TABLE . ' as evidence', function ($join): void {
                $join->on('evidence.company_id', '=', 'links.company_id')
                    ->on('evidence.evidence_ref', '=', 'links.evidence_ref');
            })
            ->where('links.company_id', $companyId)
            ->where('links.outcome_id', $outcomeId)
            ->orderBy('links.created_at')
            ->get([
                'evidence.*',
                'links.relationship as link_relationship',
            ]);

        $result = [];
        foreach ($rows as $row) {
            $array = (array) $row;
            $relationship = EvidenceRelationship::from((string) $array['link_relationship']);
            unset($array['link_relationship']);
            $result[] = [
                'evidence' => EvidenceReference::fromDatabaseRow($array),
                'relationship' => $relationship,
            ];
        }

        return $result;
    }
}
