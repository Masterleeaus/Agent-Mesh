<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Evidence;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class EvidenceReferenceDraft
{
    public function __construct(
        public string $evidenceRef,
        public string $sourceEngine,
        public string $sourceType,
        public string $sourceRecordRef,
        public EvidenceValidationState $validationState,
        public bool $authoritativeForFact,
        public DateTimeImmutable $observedAt,
        public ?DateTimeImmutable $validatedAt = null,
        public ?string $validatorRef = null,
        public ?string $contentHash = null,
    ) {
        foreach ([
            'evidence_ref' => $this->evidenceRef,
            'source_engine' => $this->sourceEngine,
            'source_type' => $this->sourceType,
            'source_record_ref' => $this->sourceRecordRef,
        ] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($name . ' is required.');
            }
        }

        if ($this->contentHash !== null && preg_match('/^[a-f0-9]{64}$/', $this->contentHash) !== 1) {
            throw new InvalidArgumentException('content_hash must be a lowercase SHA-256 hex digest.');
        }

        if ($this->validationState === EvidenceValidationState::VALIDATED) {
            if ($this->validatedAt === null || trim((string) $this->validatorRef) === '') {
                throw new InvalidArgumentException('validated evidence requires validated_at and validator_ref.');
            }
            if ($this->validatedAt < $this->observedAt) {
                throw new InvalidArgumentException('validated_at cannot precede observed_at.');
            }
        } elseif ($this->validatedAt !== null || $this->validatorRef !== null) {
            throw new InvalidArgumentException('validation provenance is only valid for validated evidence.');
        }

        if ($this->authoritativeForFact && $this->validationState !== EvidenceValidationState::VALIDATED) {
            throw new InvalidArgumentException('authoritative evidence must be independently validated.');
        }

        $sourceType = strtolower(trim($this->sourceType));
        if (in_array($sourceType, ['agent_self_report', 'ai_self_report', 'model_self_report'], true)
            && ($this->validationState === EvidenceValidationState::VALIDATED || $this->authoritativeForFact)) {
            throw new InvalidArgumentException('self-reported AI/agent evidence cannot self-validate as authoritative truth.');
        }
    }

    /** @return array<string, mixed> */
    public function fingerprintPayload(): array
    {
        return [
            'evidence_ref' => $this->evidenceRef,
            'source_engine' => $this->sourceEngine,
            'source_type' => $this->sourceType,
            'source_record_ref' => $this->sourceRecordRef,
            'content_hash' => $this->contentHash,
            'validation_state' => $this->validationState->value,
            'authoritative_for_fact' => $this->authoritativeForFact,
            'observed_at' => $this->observedAt->format(DATE_ATOM),
            'validated_at' => $this->validatedAt?->format(DATE_ATOM),
            'validator_ref' => $this->validatorRef,
        ];
    }
}
