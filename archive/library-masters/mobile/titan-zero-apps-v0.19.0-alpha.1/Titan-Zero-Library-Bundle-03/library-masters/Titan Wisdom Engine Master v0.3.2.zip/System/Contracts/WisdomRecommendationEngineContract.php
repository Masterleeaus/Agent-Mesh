<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Contracts;
use App\Extensions\TitanWisdomEngine\System\Recommendation\WisdomRecommendation;
interface WisdomRecommendationEngineContract { public function recommend(array $request): WisdomRecommendation; }
