<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeTransition;
use DateTimeImmutable;

interface OutcomeResolutionRepositoryContract
{
    public function findOutcomeById(int $companyId, string $outcomeId): ?OutcomeRecord;

    public function findTransitionByOperationId(int $companyId, string $operationId): ?OutcomeTransition;

    public function compareAndSwap(OutcomeRecord $current, OutcomeRecord $next, OutcomeTransition $transition): bool;

    /** @return list<OutcomeRecord> */
    public function dueForObservation(DateTimeImmutable $now, int $limit): array;
}
