<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use InvalidArgumentException;

final class CrossExtensionOrchestrator
{
    private const REQUIRED = ['company_id','trace_id','correlation_id','causation_id','root_causation_id'];
    private const PRECEDENCE = ['available'=>0,'degraded'=>1,'unavailable'=>2,'missing_provider'=>3,'blocked'=>4,'policy_disabled'=>5];

    public function __construct(private readonly string $sourceExtension) {}

    public function start(array $context, string $workType, string $targetProvider, array $payload = []): array
    {
        $this->assertContext($context);
        return $this->envelope($context, $workType, $targetProvider, $payload, 0, (string)$context['causation_id']);
    }

    public function forward(array $previous, string $workType, string $targetProvider, array $payload = []): array
    {
        $this->assertEnvelope($previous);
        $context = [
            'company_id'=>$previous['company_id'],
            'trace_id'=>$previous['trace_id'],
            'correlation_id'=>$previous['correlation_id'],
            'causation_id'=>$previous['handoff_id'],
            'root_causation_id'=>$previous['root_causation_id'],
        ];
        return $this->envelope($context, $workType, $targetProvider, $payload, ((int)$previous['hop']) + 1, (string)$previous['handoff_id']);
    }

    public function propagateAvailability(array $statuses): array
    {
        $status = 'available'; $reasons = [];
        foreach ($statuses as $provider => $candidate) {
            $candidate = array_key_exists((string)$candidate, self::PRECEDENCE) ? (string)$candidate : 'unavailable';
            if ($candidate !== 'available') $reasons[(string)$provider] = $candidate;
            if (self::PRECEDENCE[$candidate] > self::PRECEDENCE[$status]) $status = $candidate;
        }
        return ['status'=>$status,'fail_closed'=>!in_array($status,['available','degraded'],true),'reasons'=>$reasons];
    }

    public function assertFailoverSafe(array $from, array $to): void
    {
        $fromLevel = (int)($from['authority_level'] ?? 0);
        $toLevel = (int)($to['authority_level'] ?? 0);
        if ($toLevel > $fromLevel) throw new InvalidArgumentException('Provider failover may not increase authority.');
        if (($to['authorization_bypass'] ?? false) === true) throw new InvalidArgumentException('Provider failover may not bypass authorization.');
    }

    public function acceptReceipt(array $envelope, array $receipt): array
    {
        $this->assertEnvelope($envelope);
        foreach (['execution_receipt_id','outcome_id','status'] as $key) {
            if (!isset($receipt[$key]) || trim((string)$receipt[$key]) === '') throw new InvalidArgumentException('Missing receipt field: '.$key);
        }
        return [
            'accepted'=>true,
            'company_id'=>$envelope['company_id'],
            'trace_id'=>$envelope['trace_id'],
            'correlation_id'=>$envelope['correlation_id'],
            'causation_id'=>$envelope['handoff_id'],
            'root_causation_id'=>$envelope['root_causation_id'],
            'execution_receipt_id'=>(string)$receipt['execution_receipt_id'],
            'outcome_id'=>(string)$receipt['outcome_id'],
            'status'=>(string)$receipt['status'],
            'source_extension'=>$this->sourceExtension,
        ];
    }

    private function envelope(array $context, string $workType, string $targetProvider, array $payload, int $hop, string $causation): array
    {
        if (trim($workType)==='' || trim($targetProvider)==='') throw new InvalidArgumentException('workType and targetProvider are required.');
        $payloadHash = hash('sha256', $this->canonicalJson($payload));
        $seed = implode('|', [(string)$context['company_id'],(string)$context['trace_id'],$this->sourceExtension,$targetProvider,$workType,(string)$hop,$payloadHash]);
        $idempotency = hash('sha256', $seed);
        return [
            'schema'=>'titan.cross-extension-handoff.v1',
            'handoff_id'=>'handoff-'.$idempotency,
            'idempotency_key'=>$idempotency,
            'company_id'=>(int)$context['company_id'],
            'trace_id'=>(string)$context['trace_id'],
            'correlation_id'=>(string)$context['correlation_id'],
            'causation_id'=>$causation,
            'root_causation_id'=>(string)$context['root_causation_id'],
            'source_extension'=>$this->sourceExtension,
            'target_provider'=>$targetProvider,
            'work_type'=>$workType,
            'hop'=>$hop,
            'payload'=>$payload,
            'payload_sha256'=>$payloadHash,
            'authority'=>[
                'owner'=>'titan-ai-workforce',
                'authority_neutral'=>true,
                'authorization_required'=>true,
                'may_increase_authority'=>false,
            ],
        ];
    }

    private function assertEnvelope(array $envelope): void
    {
        if (($envelope['schema'] ?? null) !== 'titan.cross-extension-handoff.v1') throw new InvalidArgumentException('Invalid handoff schema.');
        $this->assertContext($envelope);
        if (empty($envelope['handoff_id']) || empty($envelope['idempotency_key'])) throw new InvalidArgumentException('Handoff identity is required.');
    }

    private function assertContext(array $context): void
    {
        foreach (self::REQUIRED as $key) {
            if (!isset($context[$key]) || $context[$key] === '') throw new InvalidArgumentException('Missing orchestration context: '.$key);
        }
        if ((int)$context['company_id'] <= 0) throw new InvalidArgumentException('company_id must be positive.');
        foreach (['tenant_id', 'tenant_company_id', 'tenantId', 'tenant_key'] as $legacyKey) {
            if (array_key_exists($legacyKey, $context) && trim((string) $context[$legacyKey]) !== '' && (string) $context[$legacyKey] !== (string) $context['company_id']) {
                throw new InvalidArgumentException('Legacy tenant compatibility input conflicts with company_id.');
            }
        }
    }

    private function canonicalJson(array $value): string
    {
        ksort($value);
        foreach ($value as &$item) if (is_array($item)) $item = json_decode($this->canonicalJson($item), true);
        unset($item);
        return (string)json_encode($value, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    }
}
