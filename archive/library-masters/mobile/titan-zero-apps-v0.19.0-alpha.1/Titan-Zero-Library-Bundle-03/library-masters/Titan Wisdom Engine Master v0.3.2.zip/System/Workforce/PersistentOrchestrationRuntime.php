<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use InvalidArgumentException;

final class PersistentOrchestrationRuntime
{
    public function __construct(private readonly CrossExtensionOrchestrator $orchestrator, private readonly DurableHandoffStoreContract $store) {}

    public function enqueue(array $envelope): array
    {
        if (($envelope['schema']??null)!=='titan.cross-extension-handoff.v1') throw new InvalidArgumentException('Invalid handoff schema.');
        return $this->store->enqueue($envelope);
    }

    public function claimNext(int $companyId, string $workerId, array $providerStatuses, int $leaseSeconds = 120): ?array
    {
        $row=$this->store->claimNext($companyId,$workerId,$leaseSeconds); if ($row===null) return null;
        $envelope=(array)$row['envelope']; $target=(string)($envelope['target_provider']??'');
        $availability=$this->orchestrator->propagateAvailability([$target=>$providerStatuses[$target]??'missing_provider']);
        if ($availability['fail_closed']) { $this->store->defer((string)$row['handoff_id'],'provider:'.$availability['status']); return null; }
        return $row + ['availability'=>$availability];
    }

    public function recordSuccess(array $claimedRow, array $receipt): array
    {
        $accepted=$this->orchestrator->acceptReceipt((array)$claimedRow['envelope'],$receipt);
        $this->store->markDelivered((string)$claimedRow['handoff_id'],(string)$accepted['execution_receipt_id']);
        return $accepted;
    }

    public function recordFailure(array $claimedRow, string $reason, bool $retryable): array
    { return $this->store->markFailed((string)$claimedRow['handoff_id'],$reason,$retryable); }
    public function replayDeadLetter(string $handoffId): array { return $this->store->redrive($handoffId); }
    public function healthSnapshot(int $companyId): array { return ['schema'=>'titan.orchestration-health.v1','company_id'=>$companyId,'counts'=>$this->store->snapshot($companyId)]; }
}
