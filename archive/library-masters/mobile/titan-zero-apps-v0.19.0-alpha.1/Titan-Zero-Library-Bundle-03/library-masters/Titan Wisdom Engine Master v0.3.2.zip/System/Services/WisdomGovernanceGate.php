<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Services;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDisposition;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceGateResult;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final class WisdomGovernanceGate implements WisdomGovernanceGateContract
{
    /** @var list<WisdomGovernedOperation> */
    private const PERMANENTLY_FORBIDDEN = [
        WisdomGovernedOperation::LEARNING_CANDIDATE_PROMOTE,
        WisdomGovernedOperation::AUTONOMY_GRANT,
        WisdomGovernedOperation::CROSS_DOMAIN_WRITE,
    ];

    public function __construct(private readonly int $maxDecisionAgeSeconds = 300)
    {
        if ($this->maxDecisionAgeSeconds <= 0) {
            throw new InvalidArgumentException('maxDecisionAgeSeconds must be positive.');
        }
    }

    public function evaluate(
        WisdomExecutionContext $context,
        WisdomGovernedOperation $operation,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): GovernanceGateResult {
        if (in_array($operation, self::PERMANENTLY_FORBIDDEN, true)) {
            return $this->deny($operation, 'wisdom_authority_boundary', $decision);
        }

        if ($decision === null) {
            return $this->deny($operation, 'governance_decision_missing');
        }

        if ($decision->companyId !== $context->companyId) {
            return $this->deny($operation, 'governance_tenant_mismatch', $decision);
        }

        if ($decision->operation !== $operation) {
            return $this->deny($operation, 'governance_operation_mismatch', $decision);
        }

        $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));

        if ($decision->evaluatedAt > $now) {
            return $this->deny($operation, 'governance_decision_not_yet_valid', $decision);
        }

        if ($decision->validUntil <= $now) {
            return $this->deny($operation, 'governance_decision_expired', $decision);
        }

        if (($now->getTimestamp() - $decision->evaluatedAt->getTimestamp()) > $this->maxDecisionAgeSeconds) {
            return $this->deny($operation, 'governance_decision_stale', $decision);
        }

        return match ($decision->disposition) {
            GovernanceDisposition::ALLOW => new GovernanceGateResult(
                true,
                'governance_allow',
                $operation,
                $decision->disposition,
                $decision->decisionId,
                $decision->policyVersion,
            ),
            GovernanceDisposition::REQUIRE_APPROVAL => $this->deny($operation, 'approval_required', $decision),
            GovernanceDisposition::HOLD => $this->deny($operation, 'governance_hold', $decision),
            GovernanceDisposition::DENY => $this->deny($operation, 'governance_deny', $decision),
        };
    }

    private function deny(
        WisdomGovernedOperation $operation,
        string $reasonCode,
        ?GovernanceDecision $decision = null,
    ): GovernanceGateResult {
        return new GovernanceGateResult(
            false,
            $reasonCode,
            $operation,
            $decision?->disposition,
            $decision?->decisionId,
            $decision?->policyVersion,
        );
    }
}
