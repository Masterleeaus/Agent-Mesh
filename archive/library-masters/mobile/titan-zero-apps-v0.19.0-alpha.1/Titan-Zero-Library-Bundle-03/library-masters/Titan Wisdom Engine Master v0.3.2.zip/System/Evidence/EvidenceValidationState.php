<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Evidence;

enum EvidenceValidationState: string
{
    case CLAIMED = 'claimed';
    case OBSERVED = 'observed';
    case VALIDATED = 'validated';
    case REJECTED = 'rejected';
    case SUPERSEDED = 'superseded';

    public function canSupportResolution(): bool
    {
        return $this === self::OBSERVED || $this === self::VALIDATED;
    }
}
