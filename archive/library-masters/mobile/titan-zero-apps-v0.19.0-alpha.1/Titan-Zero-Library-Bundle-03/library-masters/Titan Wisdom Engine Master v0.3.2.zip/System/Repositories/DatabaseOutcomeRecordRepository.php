<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Repositories;

use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use Illuminate\Database\ConnectionInterface;

final class DatabaseOutcomeRecordRepository implements OutcomeRecordRepositoryContract
{
    public const TABLE = 'titan_wisdom_outcome_records';

    public function __construct(private readonly ConnectionInterface $database)
    {
    }

    public function findByOperationId(int $companyId, string $operationId): ?OutcomeRecord
    {
        $row = $this->database->table(self::TABLE)
            ->where('company_id', $companyId)
            ->where('operation_id', $operationId)
            ->first();

        if ($row === null) {
            return null;
        }

        return OutcomeRecord::fromDatabaseRow((array) $row);
    }

    public function insert(OutcomeRecord $record): void
    {
        $this->database->table(self::TABLE)->insert($record->toDatabaseRow());
    }
}
