<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Evidence;

final readonly class EvidenceAttachmentReceipt
{
    public function __construct(
        public EvidenceReference $evidence,
        public string $outcomeId,
        public EvidenceRelationship $relationship,
        public bool $duplicate,
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'evidence' => $this->evidence->toContractArray(),
            'outcome_id' => $this->outcomeId,
            'relationship' => $this->relationship->value,
            'duplicate' => $this->duplicate,
        ];
    }
}
