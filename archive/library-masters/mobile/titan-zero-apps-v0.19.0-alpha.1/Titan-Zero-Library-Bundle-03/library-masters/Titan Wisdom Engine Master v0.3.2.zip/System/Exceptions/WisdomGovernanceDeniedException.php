<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Exceptions;

use RuntimeException;

final class WisdomGovernanceDeniedException extends RuntimeException
{
}
