<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Governance;

final readonly class GovernanceGateResult
{
    public function __construct(
        public bool $allowed,
        public string $reasonCode,
        public WisdomGovernedOperation $operation,
        public ?GovernanceDisposition $disposition = null,
        public ?string $decisionId = null,
        public ?string $policyVersion = null,
    ) {
    }

    /** @return array<string, bool|string|null> */
    public function toArray(): array
    {
        return [
            'allowed' => $this->allowed,
            'reason_code' => $this->reasonCode,
            'operation' => $this->operation->value,
            'disposition' => $this->disposition?->value,
            'decision_id' => $this->decisionId,
            'policy_version' => $this->policyVersion,
        ];
    }
}
