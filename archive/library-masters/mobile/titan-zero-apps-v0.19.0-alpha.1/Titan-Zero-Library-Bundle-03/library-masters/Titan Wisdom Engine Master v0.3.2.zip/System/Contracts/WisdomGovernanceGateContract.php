<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceGateResult;
use App\Extensions\TitanWisdomEngine\System\Governance\WisdomGovernedOperation;
use DateTimeImmutable;

interface WisdomGovernanceGateContract
{
    public function evaluate(
        WisdomExecutionContext $context,
        WisdomGovernedOperation $operation,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): GovernanceGateResult;
}
