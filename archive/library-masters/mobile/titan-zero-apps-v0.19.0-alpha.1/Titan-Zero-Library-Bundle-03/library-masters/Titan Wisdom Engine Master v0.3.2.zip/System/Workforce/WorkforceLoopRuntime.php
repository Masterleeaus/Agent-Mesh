<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Workforce;

use InvalidArgumentException;
use RuntimeException;

final class WorkforceLoopRuntime
{
    private const REQUIRED_CONTEXT = ['company_id','trace_id','correlation_id','causation_id','root_causation_id'];
    private const AVAILABILITY = ['available','degraded','unavailable','missing_provider','blocked','policy_disabled'];

    private function __construct(private readonly array $contract) {}

    public static function fromContractFile(string $path): self
    {
        if (!is_file($path)) { throw new RuntimeException('Workforce integration contract missing.'); }
        $decoded = json_decode((string) file_get_contents($path), true);
        if (!is_array($decoded)) { throw new RuntimeException('Workforce integration contract is invalid JSON.'); }
        if (($decoded['tenancy']['canonical_key'] ?? null) !== 'company_id') { throw new RuntimeException('Canonical Workforce tenant key must be company_id.'); }
        return new self($decoded);
    }

    public function tenantKey(): string { return 'company_id'; }

    public function availability(array $dependencies): array
    {
        $status = 'available';
        $reasons = [];
        $precedence = ['available'=>0,'degraded'=>1,'unavailable'=>2,'missing_provider'=>3,'blocked'=>4,'policy_disabled'=>5];
        foreach ($dependencies as $name => $candidate) {
            $candidate = (string) $candidate;
            if (!in_array($candidate, self::AVAILABILITY, true)) { $candidate = 'unavailable'; }
            if ($candidate !== 'available') { $reasons[(string)$name] = $candidate; }
            if (($precedence[$candidate] ?? 2) > ($precedence[$status] ?? 0)) { $status = $candidate; }
        }
        return ['status'=>$status,'fail_closed'=>$status !== 'available' && $status !== 'degraded','reasons'=>$reasons];
    }

    public function prepareHandoff(array $context, string $targetProvider, string $workType): array
    {
        $this->assertContext($context);
        foreach (['tenant_id', 'tenant_company_id', 'tenantId', 'tenant_key'] as $legacyKey) {
            if (! array_key_exists($legacyKey, $context)) {
                continue;
            }
            if (trim((string) $context[$legacyKey]) !== '' && (string) $context[$legacyKey] !== (string) $context['company_id']) {
                throw new InvalidArgumentException('Legacy tenant compatibility input conflicts with company_id.');
            }
            unset($context[$legacyKey]);
        }
        if (trim($targetProvider) === '' || trim($workType) === '') { throw new InvalidArgumentException('Target provider and work type are required.'); }
        return array_merge($context, [
            'target_provider'=>$targetProvider,
            'work_type'=>$workType,
            'provider'=>[
                'extension_key'=>(string)($this->contract['provider']['extension_key'] ?? ''),
                'version'=>(string)($this->contract['provider']['version'] ?? ''),
                'manifest_schema_version'=>(string)($this->contract['provider']['manifest_schema_version'] ?? ''),
            ],
            'authority_neutral'=>true,
            'work_item_owner'=>'titan-ai-workforce',
            'provider_pin_required'=>true,
        ]);
    }

    public function availabilityFromDiscovery(ProviderDiscovery $discovery, string $purpose = 'execution'): array
    {
        return $this->availability($discovery->requiredStatuses($purpose));
    }

    public function workforceAvailability(): array
    {
        return ['status' => 'available', 'provider' => (string)($this->contract['provider']['extension_key'] ?? '')];
    }

    public function acceptOutcome(array $outcome): array
    {
        $this->assertContext($outcome);
        if (empty($outcome['originating_work_item_id']) && empty($outcome['originating_trace_id'])) {
            throw new InvalidArgumentException('Outcome must reference originating work item or trace.');
        }
        if (empty($outcome['execution_receipt_id'])) {
            throw new InvalidArgumentException('Execution receipt is required for accepted outcomes.');
        }
        return ['accepted'=>true,'company_id'=>$outcome['company_id'],'trace_id'=>$outcome['trace_id'],'provider'=>(string)($this->contract['provider']['extension_key'] ?? '')];
    }

    private function assertContext(array $context): void
    {
        foreach (self::REQUIRED_CONTEXT as $key) {
            if (!array_key_exists($key, $context) || $context[$key] === null || $context[$key] === '') {
                throw new InvalidArgumentException('Missing required Workforce loop context: ' . $key);
            }
        }
        if (!is_int($context['company_id']) && !(is_string($context['company_id']) && ctype_digit($context['company_id']))) {
            throw new InvalidArgumentException('company_id must be a positive integer identifier.');
        }
        if ((int)$context['company_id'] <= 0) { throw new InvalidArgumentException('company_id must be positive.'); }
    }
}
