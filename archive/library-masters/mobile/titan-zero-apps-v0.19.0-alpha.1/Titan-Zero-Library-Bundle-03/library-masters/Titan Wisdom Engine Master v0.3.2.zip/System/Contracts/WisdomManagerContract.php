<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

interface WisdomManagerContract
{
    public function isEnabled(): bool;

    /** @return array<string, mixed> */
    public function health(): array;

    /** @return array<string, mixed> */
    public function readiness(): array;

    /** @return list<string> */
    public function declaredCapabilities(): array;
}
