<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

use DateTimeImmutable;

final readonly class DueOutcomeObservation
{
    public function __construct(
        public int $companyId,
        public string $outcomeId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public string $sourceComponent,
        public DateTimeImmutable $expectedResolutionAt,
        public string $idempotencyKey,
    ) {
    }

    public static function fromOutcome(OutcomeRecord $record): self
    {
        if ($record->expectedResolutionAt === null) {
            throw new \InvalidArgumentException('Due observation requires expected_resolution_at.');
        }
        return new self(
            companyId: $record->companyId,
            outcomeId: $record->outcomeId,
            traceId: $record->traceId,
            correlationId: $record->correlationId,
            causationId: $record->causationId,
            rootCausationId: $record->rootCausationId,
            sourceComponent: $record->sourceComponent,
            expectedResolutionAt: $record->expectedResolutionAt,
            idempotencyKey: 'wisdom.observation.due.v1:' . hash('sha256', $record->companyId . '|' . $record->outcomeId . '|' . $record->expectedResolutionAt->format(DATE_ATOM)),
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'outcome_id' => $this->outcomeId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'source_component' => $this->sourceComponent,
            'expected_resolution_at' => $this->expectedResolutionAt->format(DATE_ATOM),
            'idempotency_key' => $this->idempotencyKey,
        ];
    }
}
