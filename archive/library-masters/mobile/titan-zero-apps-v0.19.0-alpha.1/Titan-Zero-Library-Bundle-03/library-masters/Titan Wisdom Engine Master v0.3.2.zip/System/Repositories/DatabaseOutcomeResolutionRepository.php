<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Repositories;

use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecord;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeTransition;
use DateTimeImmutable;
use Illuminate\Database\ConnectionInterface;

final class DatabaseOutcomeResolutionRepository implements OutcomeResolutionRepositoryContract
{
    private const OUTCOME_TABLE = 'titan_wisdom_outcome_records';
    private const TRANSITION_TABLE = 'titan_wisdom_outcome_transitions';

    public function __construct(private readonly ConnectionInterface $database)
    {
    }

    public function findOutcomeById(int $companyId, string $outcomeId): ?OutcomeRecord
    {
        $row = $this->database->table(self::OUTCOME_TABLE)
            ->where('company_id', $companyId)
            ->where('id', $outcomeId)
            ->first();

        return $row === null ? null : OutcomeRecord::fromDatabaseRow((array) $row);
    }

    public function findTransitionByOperationId(int $companyId, string $operationId): ?OutcomeTransition
    {
        $row = $this->database->table(self::TRANSITION_TABLE)
            ->where('company_id', $companyId)
            ->where('operation_id', $operationId)
            ->first();

        return $row === null ? null : OutcomeTransition::fromDatabaseRow((array) $row);
    }

    public function compareAndSwap(OutcomeRecord $current, OutcomeRecord $next, OutcomeTransition $transition): bool
    {
        return $this->database->transaction(function () use ($current, $next, $transition): bool {
            $updated = $this->database->table(self::OUTCOME_TABLE)
                ->where('company_id', $current->companyId)
                ->where('id', $current->outcomeId)
                ->where('record_version', $current->recordVersion)
                ->update($next->toDatabaseRow());

            if ($updated !== 1) {
                return false;
            }

            $this->database->table(self::TRANSITION_TABLE)->insert($transition->toDatabaseRow());
            return true;
        });
    }

    public function dueForObservation(DateTimeImmutable $now, int $limit): array
    {
        $rows = $this->database->table(self::OUTCOME_TABLE)
            ->whereIn('resolution_state', ['pending', 'observing'])
            ->whereNotNull('expected_resolution_at')
            ->where('expected_resolution_at', '<=', $now->format('Y-m-d H:i:s.u'))
            ->orderBy('expected_resolution_at')
            ->limit(max(1, $limit))->get();

        return array_map(
            static fn ($row): OutcomeRecord => OutcomeRecord::fromDatabaseRow((array) $row),
            $rows->all()
        );
    }
}
