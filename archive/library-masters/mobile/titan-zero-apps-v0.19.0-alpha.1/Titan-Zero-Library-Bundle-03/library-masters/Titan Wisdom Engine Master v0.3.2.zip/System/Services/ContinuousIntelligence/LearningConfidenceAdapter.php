<?php
namespace App\Extensions\TitanWisdomEngine\System\Services\ContinuousIntelligence;
final class LearningConfidenceAdapter { public function apply(float $current,array $a): float { return max(0.0,min(1.0,round($current+(float)($a['wisdom']['confidence_delta']??0.0),4))); }}
