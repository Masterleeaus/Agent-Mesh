<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Governance;

enum WisdomGovernedOperation: string
{
    case OUTCOME_RECORD = 'wisdom.outcome.record';
    case EVIDENCE_ATTACH = 'wisdom.evidence.attach';
    case OUTCOME_RESOLVE = 'wisdom.outcome.resolve';
    case OUTCOME_REVISE = 'wisdom.outcome.revise';
    case ATTRIBUTION_CALCULATE = 'wisdom.attribution.calculate';
    case CALIBRATION_EMIT = 'wisdom.calibration.emit';
    case LEARNING_CANDIDATE_PROPOSE = 'wisdom.learning.candidate.propose';

    // Permanently outside Wisdom's authority boundary.
    case LEARNING_CANDIDATE_PROMOTE = 'wisdom.learning.candidate.promote';
    case AUTONOMY_GRANT = 'wisdom.autonomy.grant';
    case CROSS_DOMAIN_WRITE = 'wisdom.cross-domain.write';
}
