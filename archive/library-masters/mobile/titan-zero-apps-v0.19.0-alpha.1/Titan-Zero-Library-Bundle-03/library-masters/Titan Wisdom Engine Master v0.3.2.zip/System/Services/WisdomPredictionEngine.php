<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Services;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomPredictionEngineContract;
use App\Extensions\TitanWisdomEngine\System\Prediction\WisdomPrediction;
use InvalidArgumentException;
final class WisdomPredictionEngine implements WisdomPredictionEngineContract
{
    public function predict(array $request): WisdomPrediction
    {
        foreach(['loop_id','company_id','target','horizon','method'] as $k) if(trim((string)($request[$k]??''))==='') throw new InvalidArgumentException("Missing {$k}");
        if(($request['authority_neutral']??true)!==true) throw new InvalidArgumentException('Prediction inputs must remain authority-neutral.');
        $confidence=max(0,min(1,(float)($request['confidence']??0.5)));
        $unc=(array)($request['uncertainty']??[]); $low=(float)($unc['low']??max(0,$confidence-0.15)); $high=(float)($unc['high']??min(1,$confidence+0.15));
        if($low>$high) throw new InvalidArgumentException('Uncertainty low cannot exceed high.');
        $refs=array_values(array_unique(array_map('strval',(array)($request['hypothesis_refs']??[]))));
        $inputs=(array)($request['inputs']??[]);
        $seed=implode('|',[(string)$request['company_id'],(string)$request['loop_id'],(string)$request['target'],(string)$request['horizon'],(string)$request['method'],json_encode($inputs)]);
        return new WisdomPrediction('wp_'.substr(hash('sha256',$seed),0,24),(string)$request['loop_id'],(string)$request['company_id'],(string)$request['target'],(string)$request['horizon'],round($confidence,4),['low'=>$low,'high'=>$high],(string)$request['method'],$inputs,$refs,'PREDICTED',true);
    }
}
