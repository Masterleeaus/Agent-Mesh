<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceAttachmentReceipt;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceReferenceDraft;
use App\Extensions\TitanWisdomEngine\System\Evidence\EvidenceRelationship;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use DateTimeImmutable;

interface WisdomEvidenceAttacherContract
{
    public function attach(
        WisdomExecutionContext $context,
        string $outcomeId,
        EvidenceReferenceDraft $draft,
        EvidenceRelationship $relationship,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): EvidenceAttachmentReceipt;
}
