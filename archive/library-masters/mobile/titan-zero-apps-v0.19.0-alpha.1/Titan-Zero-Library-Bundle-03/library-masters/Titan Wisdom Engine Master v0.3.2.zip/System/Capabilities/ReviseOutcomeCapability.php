<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Capabilities;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeReviserContract;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRevisionDraft;
use DateTimeImmutable;

final class ReviseOutcomeCapability
{
    public const KEY = 'wisdom.outcome.revise';

    public function __construct(private readonly WisdomOutcomeReviserContract $reviser)
    {
    }

    public function key(): string
    {
        return self::KEY;
    }

    public function execute(
        WisdomExecutionContext $context,
        OutcomeRevisionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt {
        return $this->reviser->revise($context, $draft, $decision, $now);
    }
}
