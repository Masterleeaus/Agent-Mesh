<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Commands;

use App\Extensions\TitanWisdomEngine\System\Capabilities\AttachEvidenceCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\RecordOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\ResolveOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Capabilities\ReviseOutcomeCapability;
use App\Extensions\TitanWisdomEngine\System\Contracts\DueOutcomeScannerContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\EvidenceRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeRecordRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\OutcomeResolutionRepositoryContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomEvidenceAttacherContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomGovernanceGateContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeRecorderContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeResolverContract;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeReviserContract;
use App\Extensions\TitanWisdomEngine\System\TitanWisdomEngineServiceProvider;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-wisdom:certify {--json : Emit JSON evidence only}';
    protected $description = 'Run non-destructive Titan host certification checks for Titan Wisdom.';

    public function handle(): int
    {
        $checks = [];
        $record = static function (string $name, bool $passed, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $name, 'passed' => $passed, 'detail' => $detail];
        };

        $runtimeEnabled = (bool) config('titan-wisdom.enabled', true);
        $record('php', PHP_VERSION_ID >= 80300, PHP_VERSION);
        $record('laravel', version_compare((string) app()->version(), '10.50.0', '>='), (string) app()->version());
        $record('provider_binding', app()->providerIsLoaded(TitanWisdomEngineServiceProvider::class));
        $record('governance_gate_binding', app()->bound(WisdomGovernanceGateContract::class));
        $record('outcome_repository_binding', app()->bound(OutcomeRecordRepositoryContract::class));
        $record('outcome_resolution_repository_binding', app()->bound(OutcomeResolutionRepositoryContract::class));
        $record('evidence_repository_binding', app()->bound(EvidenceRepositoryContract::class));
        $record('outcome_recorder_binding', app()->bound(WisdomOutcomeRecorderContract::class));
        $record('evidence_attacher_binding', app()->bound(WisdomEvidenceAttacherContract::class));
        $record('outcome_resolver_binding', app()->bound(WisdomOutcomeResolverContract::class));
        $record('outcome_reviser_binding', app()->bound(WisdomOutcomeReviserContract::class));
        $record('due_outcome_scanner_binding', app()->bound(DueOutcomeScannerContract::class));
        $record('outcome_capability_binding', app()->bound(RecordOutcomeCapability::class));
        $record('evidence_capability_binding', app()->bound(AttachEvidenceCapability::class));
        $record('resolve_capability_binding', app()->bound(ResolveOutcomeCapability::class));
        $record('revise_capability_binding', app()->bound(ReviseOutcomeCapability::class));
        $record('governance_required_for_mutations', (bool) config('titan-wisdom.governance.required_for_mutations', false));
        $record('governance_fail_closed', (bool) config('titan-wisdom.governance.fail_closed', false));
        $record('governance_decision_ttl', (int) config('titan-wisdom.governance.decision_ttl_seconds', 0) > 0, (string) config('titan-wisdom.governance.decision_ttl_seconds', 0));
        $record('queue_name', trim((string) config('titan-wisdom.queue', '')) !== '', (string) config('titan-wisdom.queue', ''));
        $record('observation_scan_limit', (int) config('titan-wisdom.observations.scan_limit', 0) > 0, (string) config('titan-wisdom.observations.scan_limit', 0));
        $record('runtime_enabled_or_intentionally_disabled', true, $runtimeEnabled ? 'enabled' : 'disabled');
        $record('storage', is_writable(storage_path()), storage_path());

        try {
            DB::connection()->getPdo();
            $record('database', DB::connection()->getDriverName() === 'mysql', DB::connection()->getDriverName());
        } catch (Throwable $e) {
            $record('database', false, $e->getMessage());
        }

        $manifestPath = dirname(__DIR__, 2) . '/extension.manifest.json';
        $manifest = is_file($manifestPath) ? json_decode((string) file_get_contents($manifestPath), true) : null;
        $record('manifest_v2_2', is_array($manifest) && ($manifest['schema_version'] ?? null) === '2.2', $manifestPath);
        $record('canonical_key', is_array($manifest) && ($manifest['key'] ?? null) === 'titan-wisdom', (string) ($manifest['key'] ?? 'missing'));

        if (is_array($manifest)) {
            foreach (($manifest['database']['owned_tables'] ?? []) as $table) {
                $record('table:' . $table, Schema::hasTable((string) $table));
            }
        }

        $record('user_route', !$runtimeEnabled || Route::has('dashboard.user.titan.wisdom.index'), 'dashboard.user.titan.wisdom.index');
        $record('admin_route', !$runtimeEnabled || Route::has('dashboard.admin.titan.wisdom.index'), 'dashboard.admin.titan.wisdom.index');

        $passed = collect($checks)->every(static fn (array $check): bool => $check['passed'] === true);
        $evidence = [
            'schema_version' => '1.0',
            'extension' => 'titan-wisdom',
            'host_certified' => $passed,
            'checked_at' => now()->toIso8601String(),
            'checks' => $checks,
        ];

        $json = json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if (!$this->option('json')) {
            $this->line($passed ? 'Host certification PASS' : 'Host certification FAILED');
        }
        $this->line((string) $json);

        return $passed ? self::SUCCESS : self::FAILURE;
    }
}
