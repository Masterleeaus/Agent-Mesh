<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

final readonly class OutcomeResolutionReceipt
{
    public function __construct(
        public OutcomeRecord $record,
        public OutcomeTransition $transition,
        public bool $duplicate,
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'outcome' => $this->record->toContractArray(),
            'transition_id' => $this->transition->transitionId,
            'operation_id' => $this->transition->operationId,
            'duplicate' => $this->duplicate,
        ];
    }
}
