<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Commands;

use App\Extensions\TitanWisdomEngine\System\Contracts\DueOutcomeScannerContract;
use App\Extensions\TitanWisdomEngine\System\Jobs\ObserveDueOutcomeJob;
use Illuminate\Console\Command;

final class DispatchDueOutcomesCommand extends Command
{
    protected $signature = 'titan:wisdom:dispatch-due-outcomes {--limit=100 : Maximum overdue outcomes to dispatch}';

    protected $description = 'Dispatch tenant-safe observation-due jobs for unresolved Wisdom outcomes.';

    public function handle(DueOutcomeScannerContract $scanner): int
    {
        if (!(bool) config('titan-wisdom.enabled', true)) {
            $this->line('Titan Wisdom is disabled; no due outcomes dispatched.');
            return self::SUCCESS;
        }

        if (!(bool) config('titan-wisdom.observations.dispatch_enabled', true)) {
            $this->line('Titan Wisdom delayed observation dispatch is disabled.');
            return self::SUCCESS;
        }

        $limit = max(1, min((int) $this->option('limit'), 1000));
        $queue = (string) config('titan-wisdom.queue', 'titan-wisdom');
        $observations = $scanner->scan(null, $limit);

        foreach ($observations as $observation) {
            ObserveDueOutcomeJob::dispatch($observation, $observation->idempotencyKey)->onQueue($queue);
        }

        $this->line(sprintf('Dispatched %d overdue Wisdom observation job(s).', count($observations)));
        return self::SUCCESS;
    }
}
