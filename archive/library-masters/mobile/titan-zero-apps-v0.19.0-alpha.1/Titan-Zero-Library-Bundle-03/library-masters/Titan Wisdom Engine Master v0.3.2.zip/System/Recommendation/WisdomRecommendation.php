<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Recommendation;
final class WisdomRecommendation
{
    public function __construct(
        public readonly string $recommendationId, public readonly string $loopId, public readonly string $companyId,
        public readonly string $problem, public readonly string $objective, public readonly array $proposedAction,
        public readonly array $alternatives, public readonly array $expectedBenefit, public readonly array $predictedRisk,
        public readonly array $cost, public readonly string $reversibility, public readonly string $urgency,
        public readonly float $confidence, public readonly string $authorityRequired, public readonly array $successCriteria,
        public readonly array $interpretationRefs, public readonly array $hypothesisRefs, public readonly array $predictionRefs,
        public readonly string $status='RECOMMENDED', public readonly bool $authorityNeutral=true,
    ) {}
    public function toArray(): array { return [
        'recommendation_id'=>$this->recommendationId,'loop_id'=>$this->loopId,'company_id'=>$this->companyId,
        'problem'=>$this->problem,'objective'=>$this->objective,'proposed_action'=>$this->proposedAction,'alternatives'=>$this->alternatives,
        'expected_benefit'=>$this->expectedBenefit,'predicted_risk'=>$this->predictedRisk,'cost'=>$this->cost,
        'reversibility'=>$this->reversibility,'urgency'=>$this->urgency,'confidence'=>$this->confidence,
        'authority_required'=>$this->authorityRequired,'success_criteria'=>$this->successCriteria,
        'interpretation_refs'=>$this->interpretationRefs,'hypothesis_refs'=>$this->hypothesisRefs,'prediction_refs'=>$this->predictionRefs,
        'status'=>$this->status,'authority_neutral'=>$this->authorityNeutral,'decision_state'=>'UNDECIDED'
    ]; }
}
