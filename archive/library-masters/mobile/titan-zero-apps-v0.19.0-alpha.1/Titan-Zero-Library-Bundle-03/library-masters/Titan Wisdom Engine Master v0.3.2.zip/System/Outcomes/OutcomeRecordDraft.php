<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class OutcomeRecordDraft
{
    /**
     * @param array<string, mixed> $intent
     * @param array<string, mixed> $expectedResult
     * @param array<string, mixed>|null $actualResult
     * @param array<string, string|int|float|null> $contextVersions
     */
    public function __construct(
        public string $operationId,
        public array $intent,
        public array $expectedResult,
        public ?array $actualResult,
        public OutcomeResolutionState $resolutionState,
        public OutcomeClassification $classification,
        public float $confidence,
        public string $sourceComponent,
        public string $sourceRecordRef,
        public array $contextVersions = [],
        public ?DateTimeImmutable $observationStartedAt = null,
        public ?DateTimeImmutable $expectedResolutionAt = null,
        public ?DateTimeImmutable $observedAt = null,
        public ?DateTimeImmutable $resolvedAt = null,
        public ?string $revisesOutcomeId = null,
    ) {
        Uuid::assert('operation_id', $this->operationId);

        if ($this->intent === []) {
            throw new InvalidArgumentException('intent must not be empty.');
        }
        if ($this->expectedResult === []) {
            throw new InvalidArgumentException('expected_result must not be empty.');
        }
        if (!is_finite($this->confidence) || $this->confidence < 0.0 || $this->confidence > 1.0) {
            throw new InvalidArgumentException('confidence must be between 0 and 1.');
        }
        if (trim($this->sourceComponent) === '') {
            throw new InvalidArgumentException('source_component is required.');
        }
        if (trim($this->sourceRecordRef) === '') {
            throw new InvalidArgumentException('source_record_ref is required.');
        }

        foreach ($this->contextVersions as $key => $value) {
            if (!is_string($key) || trim($key) === '') {
                throw new InvalidArgumentException('context_versions keys must be non-empty strings.');
            }
            if (!is_string($value) && !is_int($value) && !is_float($value) && $value !== null) {
                throw new InvalidArgumentException('context_versions values must be scalar or null.');
            }
        }

        if ($this->expectedResolutionAt !== null && $this->observationStartedAt !== null && $this->expectedResolutionAt < $this->observationStartedAt) {
            throw new InvalidArgumentException('expected_resolution_at cannot precede observation_started_at.');
        }
        if ($this->observedAt !== null && $this->observationStartedAt !== null && $this->observedAt < $this->observationStartedAt) {
            throw new InvalidArgumentException('observed_at cannot precede observation_started_at.');
        }
        if ($this->resolvedAt !== null && $this->observedAt !== null && $this->resolvedAt < $this->observedAt) {
            throw new InvalidArgumentException('resolved_at cannot precede observed_at.');
        }

        if (!$this->resolutionState->isTerminal()) {
            if ($this->classification !== OutcomeClassification::INCONCLUSIVE) {
                throw new InvalidArgumentException('pending or observing outcomes must be classified as inconclusive.');
            }
            if ($this->resolvedAt !== null) {
                throw new InvalidArgumentException('unresolved outcomes cannot have resolved_at.');
            }
        } else {
            if ($this->actualResult === null) {
                throw new InvalidArgumentException('terminal outcomes require actual_result.');
            }
            if ($this->observedAt === null || $this->resolvedAt === null) {
                throw new InvalidArgumentException('terminal outcomes require observed_at and resolved_at.');
            }
        }

        if (in_array($this->resolutionState, [OutcomeResolutionState::REVISED, OutcomeResolutionState::CONTRADICTED], true)) {
            if ($this->revisesOutcomeId === null) {
                throw new InvalidArgumentException('revised or contradicted outcomes require revises_outcome_id.');
            }
            Uuid::assert('revises_outcome_id', $this->revisesOutcomeId);
        } elseif ($this->revisesOutcomeId !== null) {
            Uuid::assert('revises_outcome_id', $this->revisesOutcomeId);
        }
    }

    /** @return array<string, mixed> */
    public function fingerprintPayload(): array
    {
        return [
            'operation_id' => $this->operationId,
            'intent' => $this->intent,
            'expected_result' => $this->expectedResult,
            'actual_result' => $this->actualResult,
            'resolution_state' => $this->resolutionState->value,
            'classification' => $this->classification->value,
            'confidence' => $this->confidence,
            'source_component' => $this->sourceComponent,
            'source_record_ref' => $this->sourceRecordRef,
            'context_versions' => $this->contextVersions,
            'observation_started_at' => $this->observationStartedAt?->format(DATE_ATOM),
            'expected_resolution_at' => $this->expectedResolutionAt?->format(DATE_ATOM),
            'observed_at' => $this->observedAt?->format(DATE_ATOM),
            'resolved_at' => $this->resolvedAt?->format(DATE_ATOM),
            'revises_outcome_id' => $this->revisesOutcomeId,
        ];
    }
}
