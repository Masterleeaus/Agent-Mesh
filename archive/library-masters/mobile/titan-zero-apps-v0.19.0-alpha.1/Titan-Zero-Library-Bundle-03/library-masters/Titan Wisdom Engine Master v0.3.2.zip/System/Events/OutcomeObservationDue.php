<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Events;

use App\Extensions\TitanWisdomEngine\System\Outcomes\DueOutcomeObservation;

final readonly class OutcomeObservationDue
{
    public const EVENT_KEY = 'wisdom.outcome.observation_due.v1';

    public function __construct(public DueOutcomeObservation $observation)
    {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'event' => self::EVENT_KEY,
            'schema_version' => '1.0',
            ...$this->observation->toArray(),
        ];
    }
}
