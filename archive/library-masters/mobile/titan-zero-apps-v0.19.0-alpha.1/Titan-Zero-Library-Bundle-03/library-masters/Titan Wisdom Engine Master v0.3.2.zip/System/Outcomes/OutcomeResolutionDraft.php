<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

use App\Extensions\TitanWisdomEngine\System\Support\Uuid;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class OutcomeResolutionDraft
{
    /** @param array<string, mixed> $actualResult
     *  @param list<string> $evidenceRefs
     */
    public function __construct(
        public string $operationId,
        public string $outcomeId,
        public array $actualResult,
        public OutcomeClassification $classification,
        public float $confidence,
        public array $evidenceRefs,
        public DateTimeImmutable $observedAt,
        public DateTimeImmutable $resolvedAt,
    ) {
        Uuid::assert('operation_id', $this->operationId);
        Uuid::assert('outcome_id', $this->outcomeId);
        if ($this->actualResult === []) {
            throw new InvalidArgumentException('actual_result must not be empty.');
        }
        if ($this->classification === OutcomeClassification::INCONCLUSIVE) {
            throw new InvalidArgumentException('terminal resolution classification must be conclusive; use explicit revision/expiry handling for inconclusive cases.');
        }
        if (!is_finite($this->confidence) || $this->confidence < 0 || $this->confidence > 1) {
            throw new InvalidArgumentException('confidence must be between 0 and 1.');
        }
        if ($this->evidenceRefs === []) {
            throw new InvalidArgumentException('resolution requires at least one evidence reference.');
        }
        foreach ($this->evidenceRefs as $ref) {
            if (!is_string($ref) || trim($ref) === '') {
                throw new InvalidArgumentException('evidence_refs must contain non-empty strings.');
            }
        }
        if ($this->resolvedAt < $this->observedAt) {
            throw new InvalidArgumentException('resolved_at cannot precede observed_at.');
        }
    }

    /** @return array<string, mixed> */
    public function fingerprintPayload(): array
    {
        return [
            'operation_id' => $this->operationId,
            'outcome_id' => $this->outcomeId,
            'actual_result' => $this->actualResult,
            'classification' => $this->classification->value,
            'confidence' => $this->confidence,
            'evidence_refs' => array_values($this->evidenceRefs),
            'observed_at' => $this->observedAt->format(DATE_ATOM),
            'resolved_at' => $this->resolvedAt->format(DATE_ATOM),
        ];
    }
}
