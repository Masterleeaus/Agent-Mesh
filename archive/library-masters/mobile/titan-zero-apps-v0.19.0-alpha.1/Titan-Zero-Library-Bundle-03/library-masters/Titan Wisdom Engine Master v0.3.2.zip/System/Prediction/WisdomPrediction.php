<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Prediction;
final class WisdomPrediction
{
    public function __construct(
        public readonly string $predictionId, public readonly string $loopId, public readonly string $companyId,
        public readonly string $target, public readonly string $horizon, public readonly float $confidence,
        public readonly array $uncertainty, public readonly string $method, public readonly array $inputs,
        public readonly array $hypothesisRefs, public readonly string $status='PREDICTED', public readonly bool $authorityNeutral=true,
    ) {}
    public function toArray(): array { return [
        'prediction_id'=>$this->predictionId,'loop_id'=>$this->loopId,'company_id'=>$this->companyId,'target'=>$this->target,
        'horizon'=>$this->horizon,'confidence'=>$this->confidence,'uncertainty'=>$this->uncertainty,'method'=>$this->method,
        'inputs'=>$this->inputs,'hypothesis_refs'=>$this->hypothesisRefs,'status'=>$this->status,'authority_neutral'=>$this->authorityNeutral,
        'accuracy_state'=>'UNMEASURED'
    ]; }
}
