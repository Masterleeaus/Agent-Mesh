<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Governance;

enum GovernanceDisposition: string
{
    case ALLOW = 'ALLOW';
    case DENY = 'DENY';
    case HOLD = 'HOLD';
    case REQUIRE_APPROVAL = 'REQUIRE_APPROVAL';
}
