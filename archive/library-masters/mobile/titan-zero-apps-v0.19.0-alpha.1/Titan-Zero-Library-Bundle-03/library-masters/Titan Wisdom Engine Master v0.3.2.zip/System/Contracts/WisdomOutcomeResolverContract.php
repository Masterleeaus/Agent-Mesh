<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Contracts;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeResolutionReceipt;
use DateTimeImmutable;

interface WisdomOutcomeResolverContract
{
    public function resolve(
        WisdomExecutionContext $context,
        OutcomeResolutionDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeResolutionReceipt;
}
