<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

enum OutcomeResolutionState: string
{
    case PENDING = 'pending';
    case OBSERVING = 'observing';
    case RESOLVED = 'resolved';
    case REVISED = 'revised';
    case CONTRADICTED = 'contradicted';

    public function isTerminal(): bool
    {
        return in_array($this, [self::RESOLVED, self::REVISED, self::CONTRADICTED], true);
    }
}
