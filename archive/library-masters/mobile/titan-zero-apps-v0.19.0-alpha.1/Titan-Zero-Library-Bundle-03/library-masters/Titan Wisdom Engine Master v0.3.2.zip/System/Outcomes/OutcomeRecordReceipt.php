<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

final readonly class OutcomeRecordReceipt
{
    public function __construct(
        public OutcomeRecord $record,
        public bool $duplicate,
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'duplicate' => $this->duplicate,
            'record' => $this->record->toContractArray(),
        ];
    }
}
