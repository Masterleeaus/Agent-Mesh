<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Outcomes;

use DateTimeImmutable;
use JsonException;

final readonly class OutcomeRecord
{
    public const SCHEMA_VERSION = '1.0';

    /**
     * @param array<string, mixed> $intent
     * @param array<string, mixed> $expectedResult
     * @param array<string, mixed>|null $actualResult
     * @param list<string> $evidenceRefs
     * @param list<string> $attributionRefs
     * @param array<string, string|int|float|null> $contextVersions
     */
    public function __construct(
        public string $outcomeId,
        public int $companyId,
        public string $operationId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public array $intent,
        public array $expectedResult,
        public ?array $actualResult,
        public OutcomeResolutionState $resolutionState,
        public OutcomeClassification $classification,
        public float $confidence,
        public ?DateTimeImmutable $observationStartedAt,
        public ?DateTimeImmutable $expectedResolutionAt,
        public ?DateTimeImmutable $observedAt,
        public ?DateTimeImmutable $resolvedAt,
        public array $evidenceRefs,
        public array $attributionRefs,
        public array $contextVersions,
        public ?string $revisesOutcomeId,
        public string $idempotencyKey,
        public string $payloadHash,
        public string $sourceComponent,
        public string $sourceRecordRef,
        public string $governanceDecisionId,
        public string $governancePolicyVersion,
        public int $recordVersion,
        public DateTimeImmutable $createdAt,
        public DateTimeImmutable $updatedAt,
    ) {
    }

    /** @return array<string, mixed> */
    public function toContractArray(): array
    {
        return [
            'schema_version' => self::SCHEMA_VERSION,
            'outcome_id' => $this->outcomeId,
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'intent' => $this->intent,
            'expected_result' => $this->expectedResult,
            'actual_result' => $this->actualResult,
            'resolution_state' => $this->resolutionState->value,
            'classification' => $this->classification->value,
            'confidence' => $this->confidence,
            'observation_started_at' => $this->observationStartedAt?->format(DATE_ATOM),
            'expected_resolution_at' => $this->expectedResolutionAt?->format(DATE_ATOM),
            'observed_at' => $this->observedAt?->format(DATE_ATOM),
            'resolved_at' => $this->resolvedAt?->format(DATE_ATOM),
            'evidence_refs' => $this->evidenceRefs,
            'attribution_refs' => $this->attributionRefs,
            'context_versions' => (object) $this->contextVersions,
            'revises_outcome_id' => $this->revisesOutcomeId,
            'idempotency_key' => $this->idempotencyKey,
            'created_at' => $this->createdAt->format(DATE_ATOM),
            'updated_at' => $this->updatedAt->format(DATE_ATOM),
        ];
    }

    /** @return array<string, mixed> */
    public function toDatabaseRow(): array
    {
        return [
            'id' => $this->outcomeId,
            'schema_version' => self::SCHEMA_VERSION,
            'company_id' => $this->companyId,
            'operation_id' => $this->operationId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'intent' => json_encode($this->intent, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'expected_result' => json_encode($this->expectedResult, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'actual_result' => $this->actualResult === null ? null : json_encode($this->actualResult, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'resolution_state' => $this->resolutionState->value,
            'classification' => $this->classification->value,
            'confidence' => $this->confidence,
            'observation_started_at' => $this->observationStartedAt?->format('Y-m-d H:i:s.u'),
            'expected_resolution_at' => $this->expectedResolutionAt?->format('Y-m-d H:i:s.u'),
            'observed_at' => $this->observedAt?->format('Y-m-d H:i:s.u'),
            'resolved_at' => $this->resolvedAt?->format('Y-m-d H:i:s.u'),
            'evidence_refs' => json_encode($this->evidenceRefs, JSON_THROW_ON_ERROR),
            'attribution_refs' => json_encode($this->attributionRefs, JSON_THROW_ON_ERROR),
            'context_versions' => json_encode((object) $this->contextVersions, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'revises_outcome_id' => $this->revisesOutcomeId,
            'idempotency_key' => $this->idempotencyKey,
            'payload_hash' => $this->payloadHash,
            'source_component' => $this->sourceComponent,
            'source_record_ref' => $this->sourceRecordRef,
            'governance_decision_id' => $this->governanceDecisionId,
            'governance_policy_version' => $this->governancePolicyVersion,
            'record_version' => $this->recordVersion,
            'created_at' => $this->createdAt->format('Y-m-d H:i:s.u'),
            'updated_at' => $this->updatedAt->format('Y-m-d H:i:s.u'),
        ];
    }

    /** @param array<string, mixed> $row */
    public static function fromDatabaseRow(array $row): self
    {
        return new self(
            outcomeId: (string) $row['id'],
            companyId: (int) $row['company_id'],
            operationId: (string) $row['operation_id'],
            traceId: (string) $row['trace_id'],
            correlationId: (string) $row['correlation_id'],
            causationId: (string) $row['causation_id'],
            rootCausationId: (string) $row['root_causation_id'],
            intent: self::decodeObject($row['intent']),
            expectedResult: self::decodeObject($row['expected_result']),
            actualResult: $row['actual_result'] === null ? null : self::decodeObject($row['actual_result']),
            resolutionState: OutcomeResolutionState::from((string) $row['resolution_state']),
            classification: OutcomeClassification::from((string) $row['classification']),
            confidence: (float) $row['confidence'],
            observationStartedAt: self::date($row['observation_started_at'] ?? null),
            expectedResolutionAt: self::date($row['expected_resolution_at'] ?? null),
            observedAt: self::date($row['observed_at'] ?? null),
            resolvedAt: self::date($row['resolved_at'] ?? null),
            evidenceRefs: self::decodeList($row['evidence_refs'] ?? '[]'),
            attributionRefs: self::decodeList($row['attribution_refs'] ?? '[]'),
            contextVersions: self::decodeObject($row['context_versions'] ?? '{}'),
            revisesOutcomeId: isset($row['revises_outcome_id']) ? (string) $row['revises_outcome_id'] : null,
            idempotencyKey: (string) $row['idempotency_key'],
            payloadHash: (string) $row['payload_hash'],
            sourceComponent: (string) $row['source_component'],
            sourceRecordRef: (string) $row['source_record_ref'],
            governanceDecisionId: (string) $row['governance_decision_id'],
            governancePolicyVersion: (string) $row['governance_policy_version'],
            recordVersion: (int) $row['record_version'],
            createdAt: new DateTimeImmutable((string) $row['created_at']),
            updatedAt: new DateTimeImmutable((string) $row['updated_at']),
        );
    }

    /** @param mixed $value
     *  @return array<string, mixed>
     */
    private static function decodeObject(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }
        $decoded = json_decode((string) $value, true, 512, JSON_THROW_ON_ERROR);
        return is_array($decoded) ? $decoded : [];
    }

    /** @param mixed $value
     *  @return list<string>
     */
    private static function decodeList(mixed $value): array
    {
        if (is_array($value)) {
            return array_values(array_map('strval', $value));
        }
        $decoded = json_decode((string) $value, true, 512, JSON_THROW_ON_ERROR);
        return is_array($decoded) ? array_values(array_map('strval', $decoded)) : [];
    }

    private static function date(mixed $value): ?DateTimeImmutable
    {
        return $value === null ? null : new DateTimeImmutable((string) $value);
    }
}
