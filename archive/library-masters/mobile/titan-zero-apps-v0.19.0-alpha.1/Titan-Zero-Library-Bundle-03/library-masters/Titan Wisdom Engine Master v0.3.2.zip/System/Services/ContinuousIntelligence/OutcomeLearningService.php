<?php
namespace App\Extensions\TitanWisdomEngine\System\Services\ContinuousIntelligence;

use App\Extensions\TitanWisdomEngine\System\Contracts\ContinuousIntelligence\OutcomeLearningContract;

final class OutcomeLearningService implements OutcomeLearningContract
{
    public function measure(array $recommendation, array $verification, array $baseline, array $observed): array
    {
        $companyId=(string)($recommendation['company_id']??'');
        if($companyId==='') throw new \InvalidArgumentException('company_id required');

        foreach([$verification,$baseline,$observed] as $input){
            if(isset($input['company_id']) && (string)$input['company_id']!==$companyId){
                throw new \DomainException('cross-company outcome input');
            }
        }

        $criteria=$recommendation['success_criteria']??[];
        if(!$criteria) throw new \InvalidArgumentException('success_criteria required');

        $metric=(string)($criteria['metric']??'');
        if($metric==='') throw new \InvalidArgumentException('success_criteria.metric required');

        $before=$baseline['value']??null;
        $after=$observed['value']??null;
        if(!is_numeric($before) || !is_numeric($after)){
            return [
                'learning_id'=>'learn_'.substr(hash('sha256',json_encode([$recommendation,$verification,$baseline,$observed])),0,24),
                'company_id'=>$companyId,
                'recommendation_id'=>$recommendation['recommendation_id']??null,
                'metric'=>$metric,
                'state'=>'INSUFFICIENT_OUTCOME_DATA',
                'effectiveness_score'=>null,
                'confidence'=>0.0,
                'measured_at'=>gmdate('c')
            ];
        }

        $before=(float)$before; $after=(float)$after;
        $direction=strtoupper((string)($criteria['direction']??'INCREASE'));
        $target=$criteria['target']??null;
        $delta=$after-$before;
        $relative=abs($before)>0.000001 ? $delta/abs($before) : null;

        $success = match($direction){
            'DECREASE' => $after < $before,
            'AT_LEAST' => is_numeric($target) ? $after >= (float)$target : false,
            'AT_MOST' => is_numeric($target) ? $after <= (float)$target : false,
            default => $after > $before,
        };

        if(($verification['state']??null)==='BUSINESS_NOT_ACHIEVED') $success=false;
        if(($verification['state']??null)==='TECHNICAL_FAILURE') $success=false;

        $magnitude = $relative===null ? min(1.0,abs($delta)) : min(1.0,abs($relative));
        $score = $success ? round(0.5 + 0.5*$magnitude,4) : round(max(0.0,0.5 - 0.5*$magnitude),4);

        $verificationConfidence = (float)($observed['confidence']??1.0);
        $causalConfidence = (float)($recommendation['confidence']??0.5);
        $confidence = max(0.0,min(1.0,round(($verificationConfidence+$causalConfidence)/2,4)));

        return [
            'learning_id'=>'learn_'.substr(hash('sha256',json_encode([$recommendation,$verification,$baseline,$observed])),0,24),
            'company_id'=>$companyId,
            'loop_id'=>$recommendation['loop_id']??($verification['loop_id']??null),
            'recommendation_id'=>$recommendation['recommendation_id']??null,
            'intervention_key'=>$recommendation['intervention_key']??($recommendation['proposed_action']['capability_id']??null),
            'metric'=>$metric,
            'baseline'=>$before,
            'observed'=>$after,
            'delta'=>round($delta,6),
            'relative_delta'=>$relative===null?null:round($relative,6),
            'success'=>$success,
            'effectiveness_score'=>$score,
            'confidence'=>$confidence,
            'state'=>$success?'EFFECTIVE':'INEFFECTIVE_OR_UNPROVEN',
            'time_to_effect_seconds'=>$observed['time_to_effect_seconds']??null,
            'unintended_consequences'=>array_values($observed['unintended_consequences']??[]),
            'measured_at'=>gmdate('c')
        ];
    }

    public function updateInterventionProfile(array $profile, array $measurement): array
    {
        $companyId=(string)($measurement['company_id']??'');
        if($companyId==='') throw new \InvalidArgumentException('measurement company_id required');
        if(isset($profile['company_id']) && (string)$profile['company_id']!==$companyId)
            throw new \DomainException('cross-company intervention profile');

        $count=(int)($profile['measurement_count']??0);
        $old=(float)($profile['mean_effectiveness']??0.0);
        $score=$measurement['effectiveness_score'];
        if(!is_numeric($score)) return $profile + ['company_id'=>$companyId];

        $newCount=$count+1;
        $mean=(($old*$count)+(float)$score)/$newCount;
        $successes=(int)($profile['success_count']??0)+(($measurement['success']??false)?1:0);
        $failures=(int)($profile['failure_count']??0)+(($measurement['success']??false)?0:1);

        return [
            'company_id'=>$companyId,
            'intervention_key'=>$measurement['intervention_key']??($profile['intervention_key']??null),
            'measurement_count'=>$newCount,
            'success_count'=>$successes,
            'failure_count'=>$failures,
            'mean_effectiveness'=>round($mean,4),
            'empirical_success_rate'=>round($successes/$newCount,4),
            'last_learning_id'=>$measurement['learning_id']??null,
            'outcome_learning_ready'=>$newCount>0,
            'updated_at'=>gmdate('c')
        ];
    }
}
