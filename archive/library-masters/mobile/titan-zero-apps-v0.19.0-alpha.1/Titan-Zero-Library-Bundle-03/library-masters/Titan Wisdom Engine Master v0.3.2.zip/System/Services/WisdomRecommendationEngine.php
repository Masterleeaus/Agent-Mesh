<?php

declare(strict_types=1);
namespace App\Extensions\TitanWisdomEngine\System\Services;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomRecommendationEngineContract;
use App\Extensions\TitanWisdomEngine\System\Recommendation\WisdomRecommendation;
use InvalidArgumentException;
final class WisdomRecommendationEngine implements WisdomRecommendationEngineContract
{
    private const REVERSIBILITY=['REVERSIBLE','PARTIALLY_REVERSIBLE','IRREVERSIBLE','UNKNOWN'];
    private const URGENCY=['LOW','NORMAL','HIGH','CRITICAL'];
    public function recommend(array $request): WisdomRecommendation
    {
        foreach(['loop_id','company_id','problem','objective','authority_required'] as $k) if(trim((string)($request[$k]??''))==='') throw new InvalidArgumentException("Missing {$k}");
        if(($request['authority_neutral']??true)!==true) throw new InvalidArgumentException('Recommendations cannot grant execution authority.');
        $action=(array)($request['proposed_action']??[]); if($action===[]) throw new InvalidArgumentException('Missing proposed_action');
        $criteria=array_values((array)($request['success_criteria']??[])); if($criteria===[]) throw new InvalidArgumentException('At least one measurable success criterion is required.');
        $rev=strtoupper((string)($request['reversibility']??'UNKNOWN')); if(!in_array($rev,self::REVERSIBILITY,true)) throw new InvalidArgumentException('Invalid reversibility');
        $urg=strtoupper((string)($request['urgency']??'NORMAL')); if(!in_array($urg,self::URGENCY,true)) throw new InvalidArgumentException('Invalid urgency');
        $confidence=max(0,min(1,(float)($request['confidence']??0.5)));
        $refs=fn(string $k): array=>array_values(array_unique(array_filter(array_map('strval',(array)($request[$k]??[])))));
        $seed=implode('|',[(string)$request['company_id'],(string)$request['loop_id'],(string)$request['problem'],(string)$request['objective'],json_encode($action),json_encode($criteria)]);
        return new WisdomRecommendation(
            'wr_'.substr(hash('sha256',$seed),0,24),(string)$request['loop_id'],(string)$request['company_id'],(string)$request['problem'],(string)$request['objective'],$action,
            array_values((array)($request['alternatives']??[])),(array)($request['expected_benefit']??[]),(array)($request['predicted_risk']??[]),(array)($request['cost']??[]),
            $rev,$urg,round($confidence,4),(string)$request['authority_required'],$criteria,$refs('interpretation_refs'),$refs('hypothesis_refs'),$refs('prediction_refs'),'RECOMMENDED',true
        );
    }
}
