<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\System\Capabilities;

use App\Extensions\TitanWisdomEngine\System\Context\WisdomExecutionContext;
use App\Extensions\TitanWisdomEngine\System\Contracts\WisdomOutcomeRecorderContract;
use App\Extensions\TitanWisdomEngine\System\Governance\GovernanceDecision;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordDraft;
use App\Extensions\TitanWisdomEngine\System\Outcomes\OutcomeRecordReceipt;
use DateTimeImmutable;

final class RecordOutcomeCapability
{
    public const KEY = 'wisdom.outcome.record';

    public function __construct(private readonly WisdomOutcomeRecorderContract $recorder)
    {
    }

    public function key(): string
    {
        return self::KEY;
    }

    public function execute(
        WisdomExecutionContext $context,
        OutcomeRecordDraft $draft,
        ?GovernanceDecision $decision,
        ?DateTimeImmutable $now = null,
    ): OutcomeRecordReceipt {
        return $this->recorder->record($context, $draft, $decision, $now);
    }
}
