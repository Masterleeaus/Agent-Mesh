<?php

declare(strict_types=1);

namespace App\Extensions\TitanWisdomEngine\Persistence\Workforce;

use App\Extensions\TitanWisdomEngine\System\Workforce\DurableHandoffStoreContract;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

final class DatabaseDurableHandoffStore implements DurableHandoffStoreContract
{
    public function __construct(private readonly string $table = 'titan_wisdom_workforce_handoffs', private readonly int $maxAttempts = 5) {}

    public function enqueue(array $envelope): array
    {
        $id=(string)($envelope['handoff_id']??''); $key=(string)($envelope['idempotency_key']??''); $companyId=(int)($envelope['company_id']??0);
        if ($id==='' || $key==='' || $companyId<=0) throw new InvalidArgumentException('Durable handoff identity and company_id are required.');
        $now=now();
        DB::table($this->table)->insertOrIgnore(['handoff_id'=>$id,'idempotency_key'=>$key,'company_id'=>$companyId,'envelope_json'=>json_encode($envelope, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),'status'=>'pending','attempts'=>0,'available_at'=>$now,'created_at'=>$now,'updated_at'=>$now]);
        return $this->decode((array)DB::table($this->table)->where('company_id',$companyId)->where('idempotency_key',$key)->first());
    }

    public function claimNext(int $companyId, string $workerId, int $leaseSeconds = 120): ?array
    {
        if ($companyId<=0 || trim($workerId)==='') throw new InvalidArgumentException('companyId and workerId are required.');
        return DB::transaction(function () use ($companyId,$workerId,$leaseSeconds): ?array {
            $now=now();
            $row=DB::table($this->table)->where('company_id',$companyId)->where(function($q) use ($now): void {
                $q->where(function($q) use ($now): void { $q->whereIn('status',['pending','retry','deferred'])->where('available_at','<=',$now); })
                  ->orWhere(function($q) use ($now): void { $q->where('status','in_flight')->where('leased_until','<=',$now); });
            })->orderBy('created_at')->lockForUpdate()->first();
            if (!$row) return null;
            DB::table($this->table)->where('handoff_id',$row->handoff_id)->update(['status'=>'in_flight','attempts'=>(int)$row->attempts+1,'worker_id'=>$workerId,'leased_until'=>$now->copy()->addSeconds(max(1,$leaseSeconds)),'updated_at'=>$now]);
            return $this->decode((array)DB::table($this->table)->where('handoff_id',$row->handoff_id)->first());
        });
    }

    public function markDelivered(string $handoffId, string $receiptId): array
    {
        DB::table($this->table)->where('handoff_id',$handoffId)->update(['status'=>'delivered','execution_receipt_id'=>$receiptId,'worker_id'=>null,'leased_until'=>null,'updated_at'=>now()]);
        return $this->fetch($handoffId);
    }

    public function markFailed(string $handoffId, string $reason, bool $retryable, int $delaySeconds = 0): array
    {
        return DB::transaction(function () use ($handoffId,$reason,$retryable,$delaySeconds): array {
            $row=DB::table($this->table)->where('handoff_id',$handoffId)->lockForUpdate()->first(); if (!$row) throw new InvalidArgumentException('Unknown handoff: '.$handoffId);
            $status=$retryable && (int)$row->attempts < $this->maxAttempts ? 'retry' : 'dead_letter';
            DB::table($this->table)->where('handoff_id',$handoffId)->update(['status'=>$status,'last_error'=>$reason,'worker_id'=>null,'leased_until'=>null,'available_at'=>now()->addSeconds(max(0,$delaySeconds)),'updated_at'=>now()]);
            return $this->fetch($handoffId);
        });
    }

    public function defer(string $handoffId, string $reason, int $delaySeconds = 60): array
    {
        return DB::transaction(function () use ($handoffId,$reason,$delaySeconds): array {
            $row=DB::table($this->table)->where('handoff_id',$handoffId)->lockForUpdate()->first(); if (!$row) throw new InvalidArgumentException('Unknown handoff: '.$handoffId);
            DB::table($this->table)->where('handoff_id',$handoffId)->update(['status'=>'deferred','attempts'=>max(0,(int)$row->attempts-1),'last_error'=>$reason,'worker_id'=>null,'leased_until'=>null,'available_at'=>now()->addSeconds(max(1,$delaySeconds)),'updated_at'=>now()]);
            return $this->fetch($handoffId);
        });
    }

    public function redrive(string $handoffId): array
    {
        return DB::transaction(function () use ($handoffId): array {
            $row=DB::table($this->table)->where('handoff_id',$handoffId)->lockForUpdate()->first(); if (!$row || $row->status!=='dead_letter') throw new InvalidArgumentException('Only dead-letter handoffs may be redriven.');
            DB::table($this->table)->where('handoff_id',$handoffId)->update(['status'=>'pending','attempts'=>0,'last_error'=>null,'available_at'=>now(),'updated_at'=>now()]);
            return $this->fetch($handoffId);
        });
    }

    public function snapshot(int $companyId): array
    {
        $counts=['pending'=>0,'in_flight'=>0,'retry'=>0,'deferred'=>0,'delivered'=>0,'dead_letter'=>0];
        foreach (DB::table($this->table)->where('company_id',$companyId)->selectRaw('status, COUNT(*) as aggregate')->groupBy('status')->get() as $row) $counts[(string)$row->status]=(int)$row->aggregate;
        return ['company_id'=>$companyId,'total'=>array_sum($counts)] + $counts;
    }

    public function releaseExpiredLeases(int $companyId): int
    {
        $now=now();
        return DB::table($this->table)->where('company_id',$companyId)->where('status','in_flight')->where('leased_until','<=',$now)->update(['status'=>'retry','worker_id'=>null,'leased_until'=>null,'available_at'=>$now,'updated_at'=>$now]);
    }

    public function listDeadLetters(int $companyId, int $limit = 100): array
    {
        return DB::table($this->table)->where('company_id',$companyId)->where('status','dead_letter')->orderBy('updated_at')->limit(max(1,$limit))->get()->map(fn($r): array => $this->decode((array)$r))->all();
    }

    public function stalledCount(int $companyId, int $olderThanSeconds = 900): int
    {
        return (int)DB::table($this->table)->where('company_id',$companyId)->whereIn('status',['pending','retry','deferred','in_flight'])->where('updated_at','<=',now()->subSeconds(max(1,$olderThanSeconds)))->count();
    }

    public function pruneDeliveredBefore(int $companyId, string $beforeIso8601, int $limit = 1000): int
    {
        try { $before=\Carbon\CarbonImmutable::parse($beforeIso8601); } catch (\Throwable) { throw new InvalidArgumentException('Invalid prune timestamp.'); }
        $ids=DB::table($this->table)->where('company_id',$companyId)->where('status','delivered')->where('updated_at','<',$before)->orderBy('updated_at')->limit(max(1,$limit))->pluck('handoff_id')->all();
        if ($ids===[]) return 0; return DB::table($this->table)->whereIn('handoff_id',$ids)->delete();
    }

    private function fetch(string $handoffId): array
    {
        $row=DB::table($this->table)->where('handoff_id',$handoffId)->first(); if (!$row) throw new InvalidArgumentException('Unknown handoff: '.$handoffId); return $this->decode((array)$row);
    }
    private function decode(array $row): array
    {
        $row['company_id']=(int)$row['company_id']; $row['attempts']=(int)$row['attempts']; $row['envelope']=json_decode((string)$row['envelope_json'],true,512,JSON_THROW_ON_ERROR); unset($row['envelope_json']); return $row;
    }
}
