<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const TABLE = 'titan_wisdom_outcome_transitions';

    public function up(): void
    {
        if (Schema::hasTable(self::TABLE)) {
            foreach ([
                'id', 'company_id', 'outcome_id', 'operation_id', 'from_state', 'to_state',
                'classification', 'evidence_refs', 'from_record_version', 'to_record_version', 'payload_hash',
                'governance_decision_id', 'governance_policy_version', 'record_snapshot', 'created_at',
            ] as $requiredColumn) {
                if (!Schema::hasColumn(self::TABLE, $requiredColumn)) {
                    throw new \RuntimeException(sprintf('%s exists but is missing required column %s.', self::TABLE, $requiredColumn));
                }
            }
            return;
        }

        Schema::create(self::TABLE, static function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->unsignedBigInteger('company_id');
            $table->uuid('outcome_id');
            $table->uuid('operation_id');
            $table->string('from_state', 32);
            $table->string('to_state', 32);
            $table->string('classification', 32);
            $table->json('evidence_refs');
            $table->unsignedInteger('from_record_version');
            $table->unsignedInteger('to_record_version');
            $table->char('payload_hash', 64);
            $table->uuid('governance_decision_id');
            $table->string('governance_policy_version', 128);
            $table->json('record_snapshot');
            $table->dateTime('created_at', 6);

            $table->unique(['company_id', 'operation_id'], 'wisdom_transition_tenant_operation_uq');
            $table->index(['company_id', 'outcome_id', 'created_at'], 'wisdom_transition_outcome_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists(self::TABLE);
    }
};
