<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    private const TABLE = 'titan_wisdom_outcome_records';

    public function up(): void
    {
        if (Schema::hasTable(self::TABLE)) {
            foreach ([
                'id', 'schema_version', 'company_id', 'operation_id', 'trace_id', 'correlation_id',
                'causation_id', 'root_causation_id', 'intent', 'expected_result', 'actual_result',
                'resolution_state', 'classification', 'confidence', 'evidence_refs', 'attribution_refs',
                'context_versions', 'idempotency_key', 'payload_hash', 'source_component', 'source_record_ref',
                'governance_decision_id', 'governance_policy_version', 'record_version', 'created_at', 'updated_at',
            ] as $requiredColumn) {
                if (!Schema::hasColumn(self::TABLE, $requiredColumn)) {
                    throw new \RuntimeException(sprintf('%s exists but is missing required column %s.', self::TABLE, $requiredColumn));
                }
            }
            return;
        }

        Schema::create(self::TABLE, static function (Blueprint $table): void {
            $table->uuid('id')->primary();
            $table->string('schema_version', 16);
            $table->unsignedBigInteger('company_id');
            $table->uuid('operation_id');
            $table->uuid('trace_id');
            $table->uuid('correlation_id');
            $table->uuid('causation_id');
            $table->uuid('root_causation_id');
            $table->json('intent');
            $table->json('expected_result');
            $table->json('actual_result')->nullable();
            $table->string('resolution_state', 32);
            $table->string('classification', 32);
            $table->decimal('confidence', 6, 5);
            $table->dateTime('observation_started_at', 6)->nullable();
            $table->dateTime('expected_resolution_at', 6)->nullable();
            $table->dateTime('observed_at', 6)->nullable();
            $table->dateTime('resolved_at', 6)->nullable();
            $table->json('evidence_refs');
            $table->json('attribution_refs');
            $table->json('context_versions');
            $table->uuid('revises_outcome_id')->nullable();
            $table->string('idempotency_key', 191);
            $table->char('payload_hash', 64);
            $table->string('source_component', 128);
            $table->string('source_record_ref', 191);
            $table->uuid('governance_decision_id');
            $table->string('governance_policy_version', 128);
            $table->unsignedInteger('record_version')->default(1);
            $table->timestamps(6);

            $table->unique(['company_id', 'operation_id'], 'wisdom_outcome_tenant_operation_uq');
            $table->unique(['company_id', 'idempotency_key'], 'wisdom_outcome_tenant_idempotency_uq');
            $table->index(['company_id', 'trace_id'], 'wisdom_outcome_tenant_trace_idx');
            $table->index(['company_id', 'resolution_state'], 'wisdom_outcome_tenant_state_idx');
            $table->index('expected_resolution_at', 'wisdom_outcome_expected_resolution_idx');
            $table->index('revises_outcome_id', 'wisdom_outcome_revision_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists(self::TABLE);
    }
};
