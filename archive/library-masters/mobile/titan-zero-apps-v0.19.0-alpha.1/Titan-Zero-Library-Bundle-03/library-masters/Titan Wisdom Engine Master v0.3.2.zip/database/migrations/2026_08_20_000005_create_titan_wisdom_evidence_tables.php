<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_wisdom_evidence_references')) {
            Schema::create('titan_wisdom_evidence_references', static function (Blueprint $table): void {
                $table->uuid('id')->primary();
                $table->string('schema_version', 16);
                $table->unsignedBigInteger('company_id');
                $table->string('evidence_ref', 191);
                $table->string('source_engine', 128);
                $table->string('source_type', 128);
                $table->string('source_record_ref', 191);
                $table->char('content_hash', 64)->nullable();
                $table->string('validation_state', 32);
                $table->boolean('authoritative_for_fact')->default(false);
                $table->dateTime('observed_at', 6);
                $table->dateTime('validated_at', 6)->nullable();
                $table->string('validator_ref', 191)->nullable();
                $table->char('payload_hash', 64);
                $table->uuid('governance_decision_id');
                $table->string('governance_policy_version', 128);
                $table->dateTime('created_at', 6);

                $table->unique(['company_id', 'evidence_ref'], 'wisdom_evidence_tenant_ref_uq');
                $table->index(['company_id', 'validation_state'], 'wisdom_evidence_tenant_state_idx');
                $table->index(['company_id', 'source_engine', 'source_type'], 'wisdom_evidence_source_idx');
            });
        }

        if (!Schema::hasTable('titan_wisdom_outcome_evidence')) {
            Schema::create('titan_wisdom_outcome_evidence', static function (Blueprint $table): void {
                $table->unsignedBigInteger('company_id');
                $table->uuid('outcome_id');
                $table->string('evidence_ref', 191);
                $table->string('relationship', 32);
                $table->dateTime('created_at', 6);

                $table->primary(['company_id', 'outcome_id', 'evidence_ref'], 'wisdom_outcome_evidence_pk');
                $table->index(['company_id', 'evidence_ref'], 'wisdom_outcome_evidence_ref_idx');
                $table->index(['company_id', 'outcome_id', 'relationship'], 'wisdom_outcome_evidence_rel_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_wisdom_outcome_evidence');
        Schema::dropIfExists('titan_wisdom_evidence_references');
    }
};
