<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_wisdom_workforce_handoffs')) return;
        Schema::create('titan_wisdom_workforce_handoffs', function (Blueprint $table): void {
            $table->string('handoff_id', 80)->primary();
            $table->unsignedBigInteger('company_id');
            $table->string('idempotency_key', 64);
            $table->longText('envelope_json');
            $table->string('status', 32)->default('pending');
            $table->unsignedInteger('attempts')->default(0);
            $table->string('worker_id', 160)->nullable();
            $table->timestamp('leased_until')->nullable();
            $table->timestamp('available_at')->useCurrent();
            $table->text('last_error')->nullable();
            $table->string('execution_receipt_id', 160)->nullable();
            $table->timestamps();
            $table->unique(['company_id','idempotency_key'], 'titan_wisdom_workforce_handoffs_company_idem_uq');
            $table->index(['company_id','status','available_at'], 'titan_wisdom_workforce_handoffs_ready_idx');
        });
    }
    public function down(): void { Schema::dropIfExists('titan_wisdom_workforce_handoffs'); }
};
