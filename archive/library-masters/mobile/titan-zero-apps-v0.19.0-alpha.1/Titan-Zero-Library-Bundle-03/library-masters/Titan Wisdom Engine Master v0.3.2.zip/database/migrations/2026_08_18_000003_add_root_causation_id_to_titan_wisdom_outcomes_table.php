<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_wisdom_outcomes') || Schema::hasColumn('titan_wisdom_outcomes', 'root_causation_id')) {
            return;
        }

        // Compatibility only: historical scaffold rows may not have complete lineage.
        // The canonical OutcomeRecord domain will require full causal context on new writes.
        Schema::table('titan_wisdom_outcomes', function (Blueprint $table): void {
            $table->uuid('root_causation_id')->nullable()->after('causation_id')->index();
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_wisdom_outcomes') || !Schema::hasColumn('titan_wisdom_outcomes', 'root_causation_id')) {
            return;
        }

        Schema::table('titan_wisdom_outcomes', function (Blueprint $table): void {
            $table->dropColumn('root_causation_id');
        });
    }
};
