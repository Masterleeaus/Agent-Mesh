<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('titan_wisdom_outcomes') || Schema::hasColumn('titan_wisdom_outcomes', 'causation_id')) {
            return;
        }

        // Compatibility migration only. The v0.1.0 scaffold allowed incomplete
        // trace context, so this cannot safely force historical rows non-null.
        // All new operational Wisdom records will use WisdomExecutionContext and
        // the canonical OutcomeRecord schema introduced in the next build pass.
        Schema::table('titan_wisdom_outcomes', function (Blueprint $table): void {
            $table->uuid('causation_id')->nullable()->after('correlation_id')->index();
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('titan_wisdom_outcomes') || !Schema::hasColumn('titan_wisdom_outcomes', 'causation_id')) {
            return;
        }

        Schema::table('titan_wisdom_outcomes', function (Blueprint $table): void {
            $table->dropColumn('causation_id');
        });
    }
};
