<?php

declare(strict_types=1);

return [
    // When disabled, runtime routes and schedules are not registered. Installer/migrations and certification remain discoverable.
    'enabled' => env('TITAN_WISDOM_ENGINE_ENABLED', true),

    // Dedicated queue for delayed outcome observation work.
    'queue' => env('TITAN_WISDOM_ENGINE_QUEUE', 'titan-wisdom'),

    // Canonical Titan company boundary. company_id is the sole authority/isolation boundary.
    'company_key' => 'company_id',

    // Compatibility-only metadata alias for older Workforce manifest consumers.
    // Never use this key to resolve, authorize, query, cache, queue, or isolate company data.
    'tenant_key' => 'company_id',

    // Durable Wisdom records and queued observation payloads fail closed without complete trace lineage.
    'require_trace_context' => true,

    // Canonical OutcomeRecord contract. The legacy titan_wisdom_outcomes table is retained but no longer receives writes.
    'outcomes' => [
        'schema_version' => '1.0',
        'table' => 'titan_wisdom_outcome_records',
        'transition_table' => 'titan_wisdom_outcome_transitions',
    ],

    // Evidence remains durable and separate from synthesized outcome interpretation.
    'evidence' => [
        'schema_version' => '1.0',
        'table' => 'titan_wisdom_evidence_references',
        'link_table' => 'titan_wisdom_outcome_evidence',
        'self_report_authoritative' => false,
    ],

    // Scheduler scans only for overdue unresolved outcomes. The queue job emits observation-due work and never fabricates governance.
    'observations' => [
        'dispatch_enabled' => (bool) env('TITAN_WISDOM_OBSERVATION_DISPATCH_ENABLED', true),
        'scan_limit' => (int) env('TITAN_WISDOM_OBSERVATION_SCAN_LIMIT', 250),
    ],

    // All Wisdom mutations require a fresh, tenant- and operation-scoped governance decision.
    'governance' => [
        'required_for_mutations' => true,
        'fail_closed' => true,
        'decision_ttl_seconds' => (int) env('TITAN_WISDOM_GOVERNANCE_DECISION_TTL_SECONDS', 300),
    ],
];
