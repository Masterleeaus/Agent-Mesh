<?php
namespace Titan\InvestigationMission;

final class OpportunityCalculator
{
    public function calculate(array $input): array
    {
        foreach (['baseline_value','expected_change','implementation_cost'] as $field) {
            if (!isset($input[$field]) || !is_numeric($input[$field])) {
                throw new \InvalidArgumentException("numeric-field-required:$field");
            }
        }
        if (!isset($input['assumptions']) || !is_array($input['assumptions'])) {
            throw new \InvalidArgumentException('assumptions-required');
        }

        $gross = (float)$input['baseline_value'] * (float)$input['expected_change'];
        $net = $gross - (float)$input['implementation_cost'];

        return [
            'gross_effect' => $gross,
            'implementation_cost' => (float)$input['implementation_cost'],
            'net_effect' => $net,
            'assumptions' => $input['assumptions'],
            'confidence' => $input['confidence'] ?? 'low',
            'forecast_not_fact' => true
        ];
    }
}
