from pathlib import Path
import json, zipfile
r=Path(__file__).resolve().parents[1]
model=json.loads((r/'mission-model/business-investigation-mission-model.json').read_text())
assert model['company_boundary']=='company_id'
assert len(model['phases'])==13
ids=[p['phase_id'] for p in model['phases']]
assert len(ids)==len(set(ids))
for p in model['phases']:
    assert p['required_outputs']
    assert p['gates']
assert any('environmental' in p['phase_id'] for p in model['phases'])
assert any('opportunity' in p['phase_id'] for p in model['phases'])
for f in [
    'contracts/TransformationFinding.schema.json',
    'contracts/EvidenceRecord.schema.json',
    'contracts/InterviewRecord.schema.json',
    'contracts/OpportunityModel.schema.json',
    'contracts/EnvironmentalBaseline.schema.json',
    'contracts/ProcessMap.schema.json'
]:
    json.loads((r/f).read_text())
parent=list((r/'source-lineage').glob('Titan-Master-Investigation-Workforce-Step24-FINAL.zip'))
assert len(parent)==1
with zipfile.ZipFile(parent[0]) as z:
    assert z.testzip() is None
runtime=''.join(p.read_text() for p in (r/'runtime').glob('*.php'))
assert 'company_id-required' in runtime
assert 'legacy-tenant-boundary-forbidden' in runtime
print('PASS 13-phase mission lifecycle')
print('PASS evidence and finding contracts')
print('PASS environmental measurement model')
print('PASS opportunity calculation model')
print('PASS company_id-only mission creation')
print('PASS exact Step24 parent lineage')
