<?php
spl_autoload_register(function($class){
    $prefix='Titan\\InvestigationMission\\';
    if(!str_starts_with($class,$prefix)) return;
    $file=dirname(__DIR__).'/runtime/'.substr($class,strlen($prefix)).'.php';
    if(is_file($file)) require $file;
});

use Titan\InvestigationMission\BusinessInvestigationMission;
use Titan\InvestigationMission\OpportunityCalculator;
use Titan\InvestigationMission\EnvironmentalIntensity;

$model=BusinessInvestigationMission::fromFile(dirname(__DIR__).'/mission-model/business-investigation-mission-model.json');
$m=$model->create(['company_id'=>'company_001','question'=>'Where are the largest business and environmental improvement opportunities?']);
if($m['company_id']!=='company_001') throw new RuntimeException('company mismatch');
if($m['current_phase']!=='01_scope_and_authority') throw new RuntimeException('wrong first phase');

try{
    $model->create(['company_id'=>'company_001','tenant_id'=>'legacy','question'=>'x']);
    throw new RuntimeException('legacy tenant accepted');
}catch(InvalidArgumentException $e){
    if($e->getMessage()!=='legacy-tenant-boundary-forbidden') throw $e;
}

$calc=(new OpportunityCalculator())->calculate([
    'baseline_value'=>100000,
    'expected_change'=>0.10,
    'implementation_cost'=>2000,
    'assumptions'=>['volume stable'],
    'confidence'=>'medium'
]);
if(abs($calc['net_effect']-8000)>0.001) throw new RuntimeException('opportunity maths');

$env=new EnvironmentalIntensity();
if(abs($env->intensity(1000,200)-5.0)>0.001) throw new RuntimeException('intensity maths');
if(abs($env->variance(6,5)-0.2)>0.001) throw new RuntimeException('variance maths');

echo "PASS mission creation\n";
echo "PASS legacy tenant rejection\n";
echo "PASS opportunity calculation\n";
echo "PASS environmental intensity\n";
