<?php
namespace Titan\InvestigationMission;

final class EnvironmentalIntensity
{
    public function intensity(float $resourceUse, float $activity): float
    {
        if ($activity <= 0) throw new \InvalidArgumentException('positive-activity-denominator-required');
        return $resourceUse / $activity;
    }

    public function variance(float $currentIntensity, float $baselineIntensity): float
    {
        if ($baselineIntensity == 0.0) throw new \InvalidArgumentException('nonzero-baseline-required');
        return ($currentIntensity - $baselineIntensity) / $baselineIntensity;
    }
}
