# Business Investigation Mission Model — Step 25

This package standardises how Titan performs a company investigation before solution design or workforce installation.

It is built on the exact Step 24 parent package:
`Titan-Master-Investigation-Workforce-Step24-FINAL.zip`

## Core principle

An investigation is an evidence-producing mission, not a licence to mutate the client business.

The mission coordinates recovered investigation workers, domain providers, interviews, evidence and analysis. It does not become CRM, finance, jobs, people, environmental, governance or technology authority.

## Canonical flow

1. Scope & authority
2. Discovery & hypotheses
3. Evidence collection
4. People & system interviews
5. Process & information mapping
6. Financial & commercial analysis
7. Operational & workforce analysis
8. Environmental impact & resource analysis
9. Risk, compliance & assurance
10. Gap & root-cause analysis
11. Opportunity calculation & prioritisation
12. Transformation findings
13. Solution-engineering handoff

## Evidence discipline

Facts, hypotheses, findings and recommendations remain separate.
Every material finding references evidence and its verification state.
Interview claims and system outputs are evidence sources, not automatic truth.
Material findings must record alternative explanations and confidence.
Hidden chain-of-thought is never stored as evidence.

## Opportunity discipline

Opportunity calculations record:
- baseline;
- calculation method;
- assumptions;
- implementation cost;
- gross effect;
- net effect;
- evidence;
- confidence.

Forecasts remain forecasts.

## Environmental discipline

Environmental comparisons require activity context. Examples:
- kWh per job;
- litres per service hour;
- fuel per route km;
- waste kg per completed job;
- material loss per unit of output.

A variance is not automatically a cause. Investigators must test workload, equipment, procedure, site, weather, occupancy, metering and other plausible explanations.

## Tenant boundary

`company_id` is the sole canonical company boundary. Legacy tenant identifiers are rejected from mission creation.
