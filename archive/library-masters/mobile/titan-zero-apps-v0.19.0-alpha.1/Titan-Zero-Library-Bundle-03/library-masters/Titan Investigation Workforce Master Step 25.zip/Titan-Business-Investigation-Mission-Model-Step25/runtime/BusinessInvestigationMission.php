<?php
namespace Titan\InvestigationMission;

final class BusinessInvestigationMission
{
    public function __construct(
        private readonly array $model
    ) {}

    public static function fromFile(string $path): self
    {
        return new self(json_decode(file_get_contents($path), true, flags: JSON_THROW_ON_ERROR));
    }

    public function create(array $input): array
    {
        $companyId = trim((string)($input['company_id'] ?? ''));
        if ($companyId === '') throw new \InvalidArgumentException('company_id-required');

        foreach (['tenant_id','tenant_company_id','organisation_id','organization_id','account_id','business_id'] as $legacy) {
            if (array_key_exists($legacy, $input)) {
                throw new \InvalidArgumentException('legacy-tenant-boundary-forbidden');
            }
        }

        $question = trim((string)($input['question'] ?? ''));
        if ($question === '') throw new \InvalidArgumentException('mission-question-required');

        return [
            'mission_id' => $input['mission_id'] ?? self::id('mis'),
            'company_id' => $companyId,
            'mission_type' => $input['mission_type'] ?? 'full_business',
            'question' => $question,
            'state' => 'scoping',
            'current_phase' => $this->model['phases'][0]['phase_id'],
            'phases' => array_map(fn(array $p) => [
                'phase_id' => $p['phase_id'],
                'state' => 'not_started',
                'required_outputs' => $p['required_outputs'],
                'gates' => $p['gates']
            ], $this->model['phases']),
            'evidence_refs' => [],
            'finding_refs' => [],
            'opportunity_refs' => [],
            'open_questions' => [],
            'created_at' => gmdate(DATE_ATOM)
        ];
    }

    public function canAdvance(array $mission, array $completedOutputs, array $passedGates): bool
    {
        $phase = $this->phase($mission['current_phase']);
        foreach ($phase['required_outputs'] as $required) {
            if (!in_array($required, $completedOutputs, true)) return false;
        }
        foreach ($phase['gates'] as $gate) {
            if (!in_array($gate, $passedGates, true)) return false;
        }
        return true;
    }

    public function phase(string $phaseId): array
    {
        foreach ($this->model['phases'] as $phase) {
            if ($phase['phase_id'] === $phaseId) return $phase;
        }
        throw new \OutOfBoundsException('unknown-investigation-phase');
    }

    private static function id(string $prefix): string
    {
        return $prefix . '_' . bin2hex(random_bytes(12));
    }
}
