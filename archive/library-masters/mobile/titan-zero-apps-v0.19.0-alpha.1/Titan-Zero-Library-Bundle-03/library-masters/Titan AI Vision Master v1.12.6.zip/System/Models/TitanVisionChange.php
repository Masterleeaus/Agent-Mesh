<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;
final class TitanVisionChange extends Model
{
    protected $table='titan_vision_changes';protected $guarded=[];
    protected $casts=['metadata'=>'array','requires_human_review'=>'boolean','confidence_score'=>'float','comparability_score'=>'float'];
    public function evidenceSet():BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'evidence_set_id');}
    public function baselineEvidenceSet():BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'baseline_evidence_set_id');}
}
