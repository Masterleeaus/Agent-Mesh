<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class SafetyCompliancePolicyService
{
    private const REGULATED_DOMAINS=['electrical','structural','gas','chemical','fire','biological','working_at_height','confined_space'];
    private const HIGH_CONSEQUENCE=['high','critical'];

    public function evaluate(array $findings):array
    {
        $regulated=[];$blocking=[];$review=[];$summary=[];
        foreach($findings as $finding){
            if(!is_array($finding))continue;
            $domain=$this->domain((string)($finding['domain']??'general'));
            $severity=$this->severity((string)($finding['severity']??'review'));
            $status=strtolower((string)($finding['human_status']??'pending'));
            $confidence=max(0.0,min(1.0,(float)($finding['confidence']??0)));
            $isRegulated=in_array($domain,self::REGULATED_DOMAINS,true);
            $needsAuthority=$isRegulated||in_array($severity,self::HIGH_CONSEQUENCE,true);
            if($isRegulated)$regulated[$domain]=true;
            if($needsAuthority&&$status!=='confirmed')$blocking[]=(string)($finding['hazard_key']??'visual_hazard');
            if($needsAuthority)$review[]=(string)($finding['hazard_key']??'visual_hazard');
            $summary[]=[
                'hazard_key'=>(string)($finding['hazard_key']??'visual_hazard'),
                'domain'=>$domain,
                'severity'=>$severity,
                'confidence'=>$confidence,
                'observation'=>(string)($finding['observation']??''),
                'human_status'=>$status,
                'requires_human_authority'=>$needsAuthority,
                'regulated_domain'=>$isRegulated,
                'evidence_image_indexes'=>array_values(array_map('intval',array_filter((array)($finding['evidence_image_indexes']??[]),'is_numeric'))),
            ];
        }
        $requiresHuman=$review!==[];
        $routing=$requiresHuman?'SAFETY_REVIEW_REQUIRED':'OBSERVATION_RECORDED';
        return [
            'routing_state'=>$routing,
            'requires_human_authority'=>$requiresHuman,
            'regulated_domains'=>array_values(array_keys($regulated)),
            'blocking_hazards'=>array_values(array_unique($blocking)),
            'review_hazards'=>array_values(array_unique($review)),
            'findings'=>$summary,
            'certification_allowed'=>false,
            'prohibited_certifications'=>[
                'electrical_safety',
                'structural_safety',
                'gas_safety',
                'chemical_safety',
                'fire_safety',
                'regulatory_compliance',
            ],
            'authority_boundary'=>'Titan AI Vision may identify visible potential hazards only. Safety/compliance certification and consequential decisions require authorised human/domain review.',
        ];
    }

    private function domain(string $value):string
    {
        $value=strtolower(trim($value));
        return in_array($value,array_merge(['general'],self::REGULATED_DOMAINS),true)?$value:'general';
    }

    private function severity(string $value):string
    {
        $value=strtolower(trim($value));
        return in_array($value,['low','review','medium','high','critical'],true)?$value:'review';
    }
}
