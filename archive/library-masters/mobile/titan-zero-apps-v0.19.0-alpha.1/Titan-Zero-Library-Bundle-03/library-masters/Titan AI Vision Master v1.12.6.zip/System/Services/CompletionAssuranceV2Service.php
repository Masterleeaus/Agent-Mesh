<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class CompletionAssuranceV2Service
{
    public function evaluate(array $base,array $scopeEvidence,array $variationCandidates,array $openFindings):array
    {
        $baseBlockers=array_values((array)($base['blockers']??[]));
        $missingEvidence=array_values(array_intersect($baseBlockers,['missing_required_evidence','more_evidence_requested','before_after_pair_missing','comparison_quality_below_threshold']));
        $pendingVariations=array_values(array_filter($variationCandidates,fn($v)=>in_array(strtolower((string)($v['approval_status']??'pending')),['pending','unapproved','unknown'],true)));
        $blockingFindings=array_values(array_filter($openFindings,function($f){$severity=strtolower((string)($f['severity']??'review'));$status=strtolower((string)($f['human_status']??'pending'));return in_array($severity,['high','critical'],true)&&!in_array($status,['confirmed','rejected'],true);}));
        $unsupported=array_values(array_filter($scopeEvidence,fn($s)=>!in_array(strtolower((string)($s['status']??'unknown')),['supported','not_applicable'],true)));
        if($pendingVariations!==[])$state='BLOCKED_BY_VARIATION';
        elseif($blockingFindings!==[])$state='BLOCKED_BY_OPEN_FINDING';
        elseif($missingEvidence!==[])$state='MORE_EVIDENCE_REQUIRED';
        elseif($unsupported!==[]||($base['eligible_for_assurance']??false)!==true)$state='REVIEW_REQUIRED';
        else $state='READY_FOR_ASSURANCE';
        return [
            'state'=>$state,
            'eligible_for_assurance'=>$state==='READY_FOR_ASSURANCE','evidence_score'=>(float)($base['evidence_score']??0),'capture_coverage'=>(float)($base['capture_coverage']??0),'confirmed_ratio'=>(float)($base['confirmed_ratio']??0),'requires_human_review'=>$state!=='READY_FOR_ASSURANCE'||(bool)($base['requires_human_review']??false),
            'base_assurance'=>$base,
            'scope_evidence'=>$scopeEvidence,
            'scope_coverage'=>['total'=>count($scopeEvidence),'supported'=>count(array_filter($scopeEvidence,fn($s)=>strtolower((string)($s['status']??''))==='supported')),'unsupported'=>count($unsupported)],
            'variation_candidates'=>$variationCandidates,
            'pending_variations'=>$pendingVariations,
            'blocking_open_findings'=>$blockingFindings,
            'blockers'=>array_values(array_unique(array_merge(
                $baseBlockers,
                $pendingVariations!==[]?['unapproved_variation']:[],
                $blockingFindings!==[]?['open_high_risk_finding']:[],
                $unsupported!==[]?['scope_not_visually_supported']:[]
            ))),
            'warnings'=>array_values((array)($base['warnings']??[])),
            'authority_boundary'=>'Visual evidence readiness only. Titan AI Vision does not complete jobs or approve scope/variations.',
        ];
    }
}
