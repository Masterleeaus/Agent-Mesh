<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class VisionChangeDetectionPolicyService
{
    private const TYPES=['new','resolved','improved','worsened','unchanged','uncertain','not_comparable'];
    private const SEVERITY=['low'=>1,'review'=>2,'medium'=>3,'high'=>4,'critical'=>5];

    public function classify(array $input): array
    {
        $comparability=$this->unit($input['comparability_score']??0);
        $confidence=$this->unit($input['confidence']??0);
        $baseline=(bool)($input['baseline_present']??false);
        $current=(bool)($input['current_present']??false);
        $evidenceComplete=(bool)($input['evidence_complete']??false);

        if($comparability<0.60){
            return $this->result('not_comparable',$confidence,$comparability,true,'Baseline and current visual evidence are not sufficiently comparable.');
        }
        if($confidence<0.55){
            return $this->result('uncertain',$confidence,$comparability,true,'Change confidence is below the deterministic classification threshold.');
        }
        if(!$baseline&&$current){
            return $this->result('new',$confidence,$comparability,true,'Finding is present in the current visit and absent from the verified baseline.');
        }
        if($baseline&&!$current){
            if(!$evidenceComplete) return $this->result('uncertain',$confidence,$comparability,true,'Baseline finding is not visible now, but current evidence coverage is incomplete.');
            return $this->result('resolved',$confidence,$comparability,true,'Verified baseline finding is absent from sufficiently complete comparable current evidence.');
        }
        if(!$baseline&&!$current){
            return $this->result('uncertain',$confidence,$comparability,true,'No supported finding is present in either evidence state.');
        }

        $before=$this->severityRank((string)($input['baseline_severity']??'review'));
        $after=$this->severityRank((string)($input['current_severity']??'review'));
        if($after>$before) return $this->result('worsened',$confidence,$comparability,true,'Current visible severity ranks above the verified baseline severity.');
        if($after<$before) return $this->result('improved',$confidence,$comparability,true,'Current visible severity ranks below the verified baseline severity.');
        return $this->result('unchanged',$confidence,$comparability,$confidence<0.85,'Finding remains at the same visible severity classification.');
    }

    public function isCanonical(string $type): bool{return in_array($type,self::TYPES,true);}
    public function canonicalTypes(): array{return self::TYPES;}

    private function severityRank(string $severity): int{return self::SEVERITY[strtolower($severity)]??self::SEVERITY['review'];}
    private function unit(mixed $value): float{return max(0.0,min(1.0,is_numeric($value)?(float)$value:0.0));}
    private function result(string $type,float $confidence,float $comparability,bool $review,string $reason): array{return ['change_type'=>$type,'confidence_score'=>$confidence,'comparability_score'=>$comparability,'requires_human_review'=>$review,'reason'=>$reason];}
}
