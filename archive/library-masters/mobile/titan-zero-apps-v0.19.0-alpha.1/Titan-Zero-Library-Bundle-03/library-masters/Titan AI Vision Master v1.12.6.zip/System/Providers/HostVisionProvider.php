<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Providers;
use App\Extensions\TitanAIVision\System\Contracts\VisionProviderContract;
use Illuminate\Contracts\Container\Container;
final class HostVisionProvider implements VisionProviderContract {
    public function __construct(private readonly Container $container,private readonly string $binding){}
    public function key():string{return 'host:'.$this->binding;}
    public function analyse(string $prompt,array $images,array $context=[]):array{
        $provider=$this->container->make($this->binding);
        if($provider instanceof VisionProviderContract)return $provider->analyse($prompt,$images,$context);
        if(is_object($provider)&&method_exists($provider,'analyse'))return (array)$provider->analyse($prompt,$images,$context);
        if(is_callable($provider))return (array)$provider($prompt,$images,$context);
        throw new \RuntimeException('Host vision binding does not expose an analyse method.');
    }
}
