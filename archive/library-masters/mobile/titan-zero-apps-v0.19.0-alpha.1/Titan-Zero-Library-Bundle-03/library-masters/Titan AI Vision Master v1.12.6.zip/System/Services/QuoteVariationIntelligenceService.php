<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class QuoteVariationIntelligenceService
{
    public function build(array $scopeEvidence,array $variationCandidates,array $missingMeasurements,array $quoteCandidates):array
    {
        $scopeCandidates=[];$materialCandidates=[];$serviceCandidates=[];
        foreach($scopeEvidence as $row){
            if(!is_array($row))continue;
            $scopeCandidates[]=[
                'key'=>(string)($row['key']??''),
                'label'=>(string)($row['label']??''),
                'status'=>(string)($row['status']??'unknown'),
                'confidence'=>max(0.0,min(1.0,(float)($row['confidence']??0))),
                'evidence_image_indexes'=>array_values((array)($row['evidence_image_indexes']??[])),
                'reason'=>(string)($row['reason']??''),
            ];
        }
        foreach($quoteCandidates as $row){
            if(!is_array($row))continue;
            $candidate=[
                'key'=>(string)($row['key']??''),
                'label'=>(string)($row['label']??''),
                'candidate_type'=>(string)($row['candidate_type']??'scope'),
                'confidence'=>max(0.0,min(1.0,(float)($row['confidence']??0))),
                'evidence_image_indexes'=>array_values((array)($row['evidence_image_indexes']??[])),
                'reason'=>(string)($row['reason']??''),
            ];
            if($candidate['candidate_type']==='material')$materialCandidates[]=$candidate;
            elseif($candidate['candidate_type']==='service')$serviceCandidates[]=$candidate;
            else $scopeCandidates[]=$candidate;
        }
        $variations=[];foreach($variationCandidates as $row){if(!is_array($row))continue;$variations[]=[
            'key'=>(string)($row['key']??''),
            'label'=>(string)($row['label']??''),
            'approval_status'=>(string)($row['approval_status']??'pending'),
            'confidence'=>max(0.0,min(1.0,(float)($row['confidence']??0))),
            'reason'=>(string)($row['reason']??''),
            'evidence_image_indexes'=>array_values((array)($row['evidence_image_indexes']??[])),
        ];}
        $measurements=[];foreach($missingMeasurements as $row){if(!is_array($row))continue;$measurements[]=[
            'key'=>(string)($row['key']??''),
            'label'=>(string)($row['label']??''),
            'required_for'=>(string)($row['required_for']??'quote_scope'),
            'reason'=>(string)($row['reason']??''),
        ];}
        return [
            'scope_candidates'=>$scopeCandidates,
            'service_candidates'=>$serviceCandidates,
            'material_candidates'=>$materialCandidates,
            'variation_proposals'=>$variations,
            'missing_measurements'=>$measurements,
            'evidence_references'=>$this->evidenceReferences($scopeCandidates,$serviceCandidates,$materialCandidates,$variations),
            'requires_pricing'=>true,
            'pricing_authority'=>'Authoritative pricing/service catalogue required. Titan AI Vision must not invent price, tax, labour rate, quantity, discount, or total.',
            'authority_boundary'=>'Visual commercial intelligence is proposal-only. Vision cannot approve scope, variations, pricing, or quotes.',
        ];
    }

    private function evidenceReferences(array ...$groups):array
    {
        $refs=[];foreach($groups as $group){foreach($group as $row){foreach((array)($row['evidence_image_indexes']??[]) as $index){if(is_numeric($index))$refs[(int)$index]=true;}}}
        $out=array_keys($refs);sort($out);return array_values($out);
    }
}
