<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Support;
final readonly class VisionResult implements \JsonSerializable {
    public function __construct(public bool $success, public array $data = [], public ?string $errorCode = null, public ?string $errorMessage = null) {}
    public static function success(array $data): self { return new self(true, $data); }
    public static function failure(string $code, string $message, array $data = []): self { return new self(false, $data, $code, $message); }
    public function jsonSerialize(): array { return ['success'=>$this->success,'data'=>$this->data,'error_code'=>$this->errorCode,'error_message'=>$this->errorMessage]; }
}
