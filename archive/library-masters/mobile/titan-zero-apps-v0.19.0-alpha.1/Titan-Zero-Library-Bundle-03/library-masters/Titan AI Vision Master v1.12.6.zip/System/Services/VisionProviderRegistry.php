<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
use App\Extensions\TitanAIVision\System\Contracts\VisionProviderContract;
use App\Extensions\TitanAIVision\System\Providers\HostVisionProvider;
use App\Extensions\TitanAIVision\System\Providers\OpenAIResponsesVisionProvider;
use Illuminate\Contracts\Container\Container;
final class VisionProviderRegistry {
    public function __construct(private readonly Container $container,private readonly OpenAIResponsesVisionProvider $legacyOpenAI){}
    public function resolve():VisionProviderContract{
        $preferred=trim((string)config('titan-ai-vision.provider','canonical'));
        if($preferred!==''&&!in_array($preferred,['canonical','auto'],true)&&$this->container->bound($preferred))return new HostVisionProvider($this->container,$preferred);
        foreach((array)config('titan-ai-vision.provider_bindings',[]) as $binding){
            if(is_string($binding)&&$binding!==''&&$this->container->bound($binding))return new HostVisionProvider($this->container,$binding);
        }
        if((bool)config('titan-ai-vision.legacy_direct_provider_enabled',false))return $this->legacyOpenAI;
        throw new \RuntimeException('TITAN_VISION_CANONICAL_INTELLIGENCE_ROUTER_UNAVAILABLE');
    }
}
