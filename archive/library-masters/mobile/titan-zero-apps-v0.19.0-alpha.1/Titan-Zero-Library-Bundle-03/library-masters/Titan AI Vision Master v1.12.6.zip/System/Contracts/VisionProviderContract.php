<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Contracts;
interface VisionProviderContract {
    public function key(): string;
    public function analyse(string $prompt, array $images, array $context = []): array;
}
