<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
final class TitanVisionEvidenceSet extends Model
{
    protected $table='titan_vision_evidence_sets';
    protected $guarded=[];
    protected $casts=[
        'required_captures'=>'array',
        'coverage'=>'array',
        'context'=>'array',
        'requires_human_confirmation'=>'boolean',
        'baseline_verified_at'=>'datetime',
        'visit_sequence'=>'integer',
        'verification_status'=>'string',
    ];
    public function items():HasMany{return $this->hasMany(TitanVisionEvidenceItem::class,'evidence_set_id');}
    public function comparisons():HasMany{return $this->hasMany(TitanVisionComparison::class,'evidence_set_id');}
    public function lineage():HasMany{return $this->hasMany(TitanVisionEvidenceLineage::class,'evidence_set_id');}
    public function changes():HasMany{return $this->hasMany(TitanVisionChange::class,'evidence_set_id');}
    public function previousVerifiedBaseline():BelongsTo{return $this->belongsTo(self::class,'previous_verified_evidence_set_id');}
}
