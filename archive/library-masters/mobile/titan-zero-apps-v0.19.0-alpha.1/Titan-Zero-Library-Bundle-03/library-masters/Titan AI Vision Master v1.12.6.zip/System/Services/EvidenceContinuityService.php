<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

use App\Extensions\TitanAIVision\System\Models\TitanVisionEvidenceLineage;
use App\Extensions\TitanAIVision\System\Models\TitanVisionEvidenceSet;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use RuntimeException;

final class EvidenceContinuityService
{
    public function __construct(private readonly EvidenceContinuityPolicyService $policy){}

    public function initialise(TitanVisionEvidenceSet $set, array $input): TitanVisionEvidenceSet
    {
        $key=$this->policy->continuityKey([
            'asset_id'=>$set->asset_id,
            'property_id'=>$set->property_id,
            'area_key'=>$input['area_key']??null,
        ]);
        if($key===null) return $set;

        $sequence=$this->scope(TitanVisionEvidenceSet::query(),$set)
            ->where('continuity_key',$key)
            ->where('id','<>',$set->id)
            ->count()+1;

        $set->update(['continuity_key'=>$key,'visit_sequence'=>$sequence]);
        return $this->linkLatestVerifiedBaseline($set->fresh());
    }

    public function linkLatestVerifiedBaseline(TitanVisionEvidenceSet $set): TitanVisionEvidenceSet
    {
        if(!$set->continuity_key) return $set;

        $baseline=$this->scope(TitanVisionEvidenceSet::query(),$set)
            ->where('continuity_key',$set->continuity_key)
            ->where('id','<>',$set->id)
            ->where('verification_status','verified')
            ->where('status','analysed')
            ->whereNotNull('baseline_verified_at')
            ->orderByDesc('baseline_verified_at')
            ->orderByDesc('id')
            ->first();

        if(!$baseline) return $set;
        $set->update(['previous_verified_evidence_set_id'=>$baseline->id]);
        TitanVisionEvidenceLineage::updateOrCreate(
            ['evidence_set_id'=>$set->id,'baseline_evidence_set_id'=>$baseline->id],
            ['user_id'=>$set->user_id,'company_id'=>$set->company_id,'continuity_key'=>$set->continuity_key,'relationship'=>'previous_verified','trust_status'=>'verified','reason'=>'Latest explicitly verified evidence for the same continuity identity.','metadata'=>['baseline_verified_at'=>optional($baseline->baseline_verified_at)->toIso8601String()]]
        );
        return $set->fresh();
    }

    public function verificationAssessment(TitanVisionEvidenceSet $set): array
    {
        $set->loadMissing('items.annotations');
        $annotations=$set->items->flatMap(fn($item)=>$item->annotations);
        $snapshot=[
            'status'=>$set->status,
            'verification_status'=>$set->verification_status??'unverified',
            'items_count'=>$set->items->count(),
            'unavailable_integrity_count'=>$set->items->where('integrity_status','unavailable')->count(),
            'review'=>[
                'pending'=>$annotations->where('human_status','pending')->count(),
                'rejected'=>$annotations->where('human_status','rejected')->count(),
                'needs_more_evidence'=>$annotations->where('human_status','needs_more_evidence')->count(),
            ],
            'missing_capture_keys'=>(array)data_get($set->coverage,'missing_capture_keys',[]),
        ];
        // Eligibility is evaluated as if the explicit verification decision were being applied now.
        $candidate=$snapshot;$candidate['verification_status']='verified';
        return ['eligible'=>$this->policy->canBeBaseline($candidate),'snapshot'=>$snapshot];
    }

    public function verifyAsBaseline(TitanVisionEvidenceSet $set,int $reviewerId,?string $note=null): TitanVisionEvidenceSet
    {
        $assessment=$this->verificationAssessment($set);
        if(!$assessment['eligible']) throw new RuntimeException('Evidence cannot become a historical baseline until required captures are present and all findings are resolved without rejection or additional-evidence requests.');
        if(!$set->continuity_key) throw new RuntimeException('Evidence needs an asset identity or property + area identity before it can become a longitudinal baseline.');

        return DB::transaction(function()use($set,$reviewerId,$note){
            $coverage=(array)$set->coverage;
            $coverage['continuity_review']=['status'=>'verified','verified_by'=>$reviewerId,'verified_at'=>now()->toIso8601String(),'note'=>$note];
            $set->update(['verification_status'=>'verified','baseline_verified_at'=>now(),'baseline_verified_by'=>$reviewerId,'coverage'=>$coverage]);
            return $set->fresh();
        });
    }

    private function scope(Builder $query,TitanVisionEvidenceSet $set): Builder
    {
        if($set->company_id!==null) return $query->where('company_id',$set->company_id);
        return $query->where('user_id',$set->user_id);
    }
}
