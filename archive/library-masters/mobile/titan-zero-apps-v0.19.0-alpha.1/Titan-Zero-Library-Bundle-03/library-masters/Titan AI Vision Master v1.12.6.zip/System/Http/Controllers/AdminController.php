<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Http\Controllers;
use Illuminate\Routing\Controller;
final class AdminController extends Controller{public function index(){return view('titan-ai-vision::admin',['config'=>config('titan-ai-vision')]);}}
