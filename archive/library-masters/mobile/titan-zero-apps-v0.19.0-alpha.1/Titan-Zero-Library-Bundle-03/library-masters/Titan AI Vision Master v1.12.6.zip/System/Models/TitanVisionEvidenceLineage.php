<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
final class TitanVisionEvidenceLineage extends Model
{
    protected $table='titan_vision_evidence_lineage';
    protected $guarded=[];
    protected $casts=['metadata'=>'array'];
    public function evidenceSet(): BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'evidence_set_id');}
    public function baseline(): BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'baseline_evidence_set_id');}
}
