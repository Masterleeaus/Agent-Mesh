<?php
declare(strict_types=1);

namespace App\Extensions\TitanAIVision\System\Services;

final class EvidenceContinuityPolicyService
{
    public function continuityKey(array $context): ?string
    {
        $assetId=trim((string)($context['asset_id']??''));
        if($assetId!==''){
            return 'asset:'.$this->normaliseIdentifier($assetId);
        }

        $propertyId=trim((string)($context['property_id']??''));
        $areaKey=trim((string)($context['area_key']??''));
        if($propertyId!==''&&$areaKey!==''){
            return 'property:'.$this->normaliseIdentifier($propertyId).':area:'.$this->slug($areaKey);
        }

        return null;
    }

    public function canBeBaseline(array $evidence): bool
    {
        if(($evidence['status']??null)!=='analysed') return false;
        if(($evidence['verification_status']??null)!=='verified') return false;
        if((int)($evidence['items_count']??0)<1) return false;
        if((int)($evidence['unavailable_integrity_count']??0)>0) return false;
        if(!empty($evidence['missing_capture_keys'])) return false;

        $review=(array)($evidence['review']??[]);
        if((int)($review['pending']??0)>0) return false;
        if((int)($review['rejected']??0)>0) return false;
        if((int)($review['needs_more_evidence']??0)>0) return false;

        return true;
    }

    private function normaliseIdentifier(string $value): string
    {
        return strtolower(trim($value));
    }

    private function slug(string $value): string
    {
        $value=strtolower(trim($value));
        $value=(string)preg_replace('/[^a-z0-9]+/','-',$value);
        return trim($value,'-');
    }
}
