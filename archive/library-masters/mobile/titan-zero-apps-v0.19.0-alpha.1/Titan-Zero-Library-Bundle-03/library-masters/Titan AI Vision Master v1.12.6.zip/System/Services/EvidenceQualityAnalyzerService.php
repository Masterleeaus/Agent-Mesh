<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class EvidenceQualityAnalyzerService
{
    public function __construct(private readonly EvidenceQualityPolicyService $policy){}
    public function analyse(array $images,array $captureKeys=[]):array
    {
        $seen=[];$reports=[];
        foreach(array_values($images) as $i=>$source){
            $decoded=$this->decode((string)$source);$sha=$decoded!==null?hash('sha256',$decoded):hash('sha256',(string)$source);
            $duplicate=isset($seen[$sha]);$seen[$sha]=true;$metrics=$this->metrics($decoded);
            $captureKey=(string)($captureKeys[$i]??'');$metrics['has_scale_reference']=$this->captureSuggestsScale($captureKey);
            $report=$this->policy->evaluate($metrics,$duplicate,$this->captureRequiresScale($captureKey));
            $report['image_index']=$i;$report['capture_key']=$captureKey!==''?$captureKey:null;$report['sha256']=$sha;$reports[]=$report;
        }
        $ready=!array_filter($reports,fn($r)=>!($r['ready_for_inference']??false));$issueCount=array_sum(array_map(fn($r)=>count($r['issues']??[]),$reports));
        return ['ready_for_inference'=>$ready,'issue_count'=>$issueCount,'reports'=>$reports,'guidance'=>array_values(array_unique(array_merge(...array_map(fn($r)=>(array)($r['guidance']??[]),$reports))))];
    }
    private function decode(string $source):?string
    {
        if(!str_starts_with($source,'data:image/'))return null;$comma=strpos($source,',');if($comma===false)return null;
        $head=substr($source,0,$comma);$body=substr($source,$comma+1);$bytes=str_contains($head,';base64')?base64_decode($body,true):urldecode($body);
        return is_string($bytes)&&$bytes!==''?$bytes:null;
    }
    private function metrics(?string $bytes):array
    {
        $metrics=['width'=>0,'height'=>0,'mean_luminance'=>null,'highlight_ratio'=>null,'sharpness'=>null,'subject_coverage'=>null];
        if($bytes===null)return $metrics;$info=@getimagesizefromstring($bytes);if(is_array($info)){$metrics['width']=(int)($info[0]??0);$metrics['height']=(int)($info[1]??0);}
        if(!function_exists('imagecreatefromstring'))return $metrics;$im=@imagecreatefromstring($bytes);if(!$im)return $metrics;
        $w=imagesx($im);$h=imagesy($im);$stepX=max(1,(int)floor($w/48));$stepY=max(1,(int)floor($h/48));$lumas=[];$high=0;$edge=0.0;$edgeN=0;
        for($y=0;$y<$h;$y+=$stepY){$prev=null;for($x=0;$x<$w;$x+=$stepX){$rgb=imagecolorat($im,$x,$y);$r=($rgb>>16)&255;$g=($rgb>>8)&255;$b=$rgb&255;$l=(0.2126*$r+0.7152*$g+0.0722*$b)/255;$lumas[]=$l;if($l>0.96)$high++;if($prev!==null){$edge+=abs($l-$prev);$edgeN++;}$prev=$l;}}
        imagedestroy($im);$n=count($lumas);if(!$n)return $metrics;$mean=array_sum($lumas)/$n;sort($lumas);$median=$lumas[(int)floor(($n-1)/2)];$deviant=count(array_filter($lumas,fn($v)=>abs($v-$median)>0.09));
        $metrics['mean_luminance']=round($mean,4);$metrics['highlight_ratio']=round($high/$n,4);$metrics['sharpness']=round(min(1.0,($edgeN?$edge/$edgeN:0)*6.0),4);$metrics['subject_coverage']=round($deviant/$n,4);return $metrics;
    }
    private function captureRequiresScale(string $key):bool{return str_contains($key,'measure')||str_contains($key,'scale');}
    private function captureSuggestsScale(string $key):bool{return str_contains($key,'scale_reference');}
}
