<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class CompletionAssuranceRuleService {
    public function evaluate(array $rules,array $captureStats,array $reviewStats,array $comparisonStats): array {
        $blockers=[];$warnings=[];$required=max(0,(int)($captureStats['required']??0));$satisfied=max(0,(int)($captureStats['satisfied']??0));$coverage=$required===0?1.0:$satisfied/$required;$minCoverage=(float)($rules['minimum_capture_coverage']??1.0);
        if($coverage+0.0001<$minCoverage||!empty($captureStats['missing']))$blockers[]='missing_required_evidence';
        $total=max(0,(int)($reviewStats['total']??0));$confirmed=max(0,(int)($reviewStats['confirmed']??0));$confirmedRatio=$total===0?1.0:$confirmed/$total;$minConfirmed=(float)($rules['minimum_confirmed_ratio']??0.0);
        if((int)($reviewStats['rejected']??0)>0)$blockers[]='finding_rejected';
        if((int)($reviewStats['needs_more_evidence']??0)>0)$blockers[]='more_evidence_requested';
        if($confirmedRatio+0.0001<$minConfirmed)$blockers[]='insufficient_confirmed_findings';
        if((int)($reviewStats['pending']??0)>0)$warnings[]='pending_human_review';
        if(($comparisonStats['required']??false)===true){if((int)($comparisonStats['pairs']??0)<1)$blockers[]='before_after_pair_missing';$minScore=(float)($rules['minimum_comparison_score']??0.0);if((float)($comparisonStats['minimum_score']??0.0)+0.0001<$minScore)$blockers[]='comparison_quality_below_threshold';}
        if(($rules['always_human_review']??false)===true)$warnings[]='profile_requires_human_review';
        $blockers=array_values(array_unique($blockers));$warnings=array_values(array_unique($warnings));
        $evidenceScore=round(($coverage*0.45)+($confirmedRatio*0.35)+(min(1.0,max(0.0,(float)($comparisonStats['minimum_score']??1.0)))*0.20),4);
        return ['eligible_for_assurance'=>$blockers===[],'evidence_score'=>$evidenceScore,'capture_coverage'=>round($coverage,4),'confirmed_ratio'=>round($confirmedRatio,4),'blockers'=>$blockers,'warnings'=>$warnings,'requires_human_review'=>($rules['always_human_review']??false)===true||$warnings!==[]];
    }
}
