<?php
declare(strict_types=1);namespace App\Extensions\TitanAIVision\System\Models;use Illuminate\Database\Eloquent\Model;final class TitanVisionAssetIdentityCandidate extends Model{protected $table='titan_vision_asset_identity_candidates';protected $guarded=[];protected $casts=['metadata'=>'array','possible_duplicate'=>'boolean','requires_human_confirmation'=>'boolean'];}
