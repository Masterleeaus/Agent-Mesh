<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Contributions;
final class MenuContribution{public function definition():array{return ['key'=>'titan_ai_vision','label'=>'Titan AI Vision','route'=>'dashboard.user.titan-ai-vision.index','icon'=>'tabler-eye-scan','order'=>70,'group'=>'ai'];}}
