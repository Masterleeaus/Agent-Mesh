<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;
final class TitanVisionWorkflowRequest extends Model{protected $table='titan_vision_workflow_requests';protected $guarded=[];protected $casts=['context'=>'array','findings'=>'array','payload'=>'array','governance'=>'array','action_result'=>'array','routed_at'=>'datetime'];}
