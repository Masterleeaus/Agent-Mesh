<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
use App\Extensions\TitanAIVision\System\Models\TitanVisionEvidenceSet;
final class EvidenceTimelineService {
    public function forUser(int $userId,array $filters=[],int $limit=50): array {
        $q=TitanVisionEvidenceSet::query()->where('user_id',$userId)->withCount(['items','comparisons','changes'])->latest('created_at');
        foreach(['job_id','property_id','customer_id','asset_id'] as $key){$value=$filters[$key]??null;if(is_string($value)&&$value!=='')$q->where($key,$value);}
        return $q->limit(max(1,min(100,$limit)))->get()->map(fn($set)=>['id'=>$set->id,'title'=>$set->title,'mode'=>$set->mode,'profile'=>$set->profile,'status'=>$set->status,'continuity_key'=>$set->continuity_key,'visit_sequence'=>$set->visit_sequence,'verification_status'=>$set->verification_status,'previous_verified_evidence_set_id'=>$set->previous_verified_evidence_set_id,'job_id'=>$set->job_id,'property_id'=>$set->property_id,'asset_id'=>$set->asset_id,'items_count'=>(int)$set->items_count,'comparisons_count'=>(int)$set->comparisons_count,'changes_count'=>(int)$set->changes_count,'change_summary'=>(array)data_get($set->coverage,'change_detection.summary',[]),'evidence_complete'=>(bool)data_get($set->coverage,'evidence_complete',false),'assurance'=>(array)data_get($set->coverage,'assurance',[]),'created_at'=>optional($set->created_at)->toIso8601String()])->all();
    }
}
