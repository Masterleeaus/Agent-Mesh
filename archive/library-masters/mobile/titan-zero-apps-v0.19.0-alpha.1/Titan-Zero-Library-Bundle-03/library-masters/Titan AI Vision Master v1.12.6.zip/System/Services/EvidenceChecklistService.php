<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class EvidenceChecklistService {
    public function __construct(private readonly VisionModeRegistry $modes, private readonly InspectionProfileRegistry $profiles, private readonly VerticalInspectionPackRegistry $packs) {}
    public function required(string $mode, string $profile): array {
        $base = match ($mode) {
            'before_after'=>[['key'=>'before_wide','label'=>'Before — wide context','required'=>true],['key'=>'after_wide','label'=>'After — matching wide context','required'=>true],['key'=>'detail','label'=>'Relevant detail / close-up','required'=>false]],
            'equipment_scan'=>[['key'=>'equipment_wide','label'=>'Whole equipment / installation','required'=>true],['key'=>'nameplate','label'=>'Readable model / serial nameplate','required'=>true],['key'=>'issue_detail','label'=>'Issue / component close-up','required'=>false]],
            'damage_assessment'=>[['key'=>'damage_wide','label'=>'Damage in surrounding context','required'=>true],['key'=>'damage_close','label'=>'Damage close-up','required'=>true],['key'=>'reference','label'=>'Scale / adjacent unaffected area','required'=>false]],
            'safety_evidence'=>[['key'=>'site_wide','label'=>'Work area / site context','required'=>true],['key'=>'hazard_detail','label'=>'Potential hazard close-up','required'=>false],['key'=>'control','label'=>'Relevant control / isolation / barrier','required'=>false]],
            'parts_recognition'=>[['key'=>'part_wide','label'=>'Part in assembly / context','required'=>true],['key'=>'identifier','label'=>'Readable markings / part number','required'=>false],['key'=>'connections','label'=>'Connections / dimensions reference','required'=>false]],
            'completion_assurance','job_check'=>[['key'=>'completed_wide','label'=>'Completed work — wide context','required'=>true],['key'=>'completed_detail','label'=>'Completed work — detail','required'=>true],['key'=>'verification','label'=>'Verification / test evidence if applicable','required'=>false]],
            default=>[['key'=>'site_wide','label'=>'Site / area context','required'=>true],['key'=>'issue_detail','label'=>'Issue / finding detail','required'=>false],['key'=>'additional_angle','label'=>'Additional angle / corroborating view','required'=>false]],
        };
        $vertical=$this->profiles->get($profile);$assetRequired=$mode==='equipment_scan'?$this->profiles->assetCaptureRequirements($profile):[];
        if($this->packs->has($profile)){foreach((array)($this->packs->get($profile)['captures']??[]) as $capture){$key=(string)($capture['key']??'');if($key==='')continue;$matched=false;foreach($base as &$existing){if($existing['key']===$key){$existing['label']=$capture['label']??$existing['label'];$existing['required']=(bool)($capture['required']??$existing['required']);$matched=true;break;}}unset($existing);if(!$matched)$base[]=['key'=>$key,'label'=>(string)($capture['label']??ucwords(str_replace('_',' ',$key))),'required'=>(bool)($capture['required']??false)];}}
        foreach(($vertical['captures']??[]) as $key){
            $exists=false; foreach($base as $x){ if($x['key']===$key){$exists=true;break;} }
            if(!$exists)$base[]=['key'=>$key,'label'=>ucwords(str_replace('_',' ',$key)),'required'=>in_array($key,$assetRequired,true)];
        }
        return $base;
    }
}
