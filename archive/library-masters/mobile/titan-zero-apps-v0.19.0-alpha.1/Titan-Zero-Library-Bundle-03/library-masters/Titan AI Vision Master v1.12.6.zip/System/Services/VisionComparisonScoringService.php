<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class VisionComparisonScoringService {
    public function score(array $factors,float $confidence): array {
        $values=[];foreach(['framing','angle','lighting','coverage'] as $k)$values[$k]=$this->unit($factors[$k]??0.0);
        $score=round(array_sum($values)/4,4);$confidence=round($this->unit($confidence),4);
        return ['comparability_score'=>$score,'confidence_score'=>$confidence,'rating'=>$score>=0.80?'strong':($score>=0.60?'usable':($score>=0.40?'weak':'insufficient')),'factors'=>$values,'requires_human_review'=>$score<0.70||$confidence<0.70];
    }
    private function unit(mixed $v):float{return max(0.0,min(1.0,(float)$v));}
}
