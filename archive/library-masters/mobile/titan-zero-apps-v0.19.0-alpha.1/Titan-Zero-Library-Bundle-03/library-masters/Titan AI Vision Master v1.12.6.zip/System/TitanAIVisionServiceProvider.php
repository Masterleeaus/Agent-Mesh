<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System;
use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;use App\Extensions\TitanAIVision\System\Contracts\TitanAIVisionManagerContract;use App\Extensions\TitanAIVision\System\Commands\CertifyExtensionCommand;use App\Extensions\TitanAIVision\System\Services\TitanAIVisionManager;use App\Extensions\TitanAIVision\System\Workforce\WorkforceProviderRuntimeContract;
use App\Extensions\TitanAIVision\System\Workforce\PackageWorkforceProviderAdapter;
use App\Extensions\TitanAIVision\System\Workforce\ProviderHealthStoreContract;
use App\Extensions\TitanAIVision\System\Workforce\LaravelCacheProviderHealthStore;
use App\Extensions\TitanAIVision\System\Workforce\ProviderHealthRegistry;
use App\Extensions\TitanAIVision\System\Workforce\CapabilityResolver;
use App\Extensions\TitanAIVision\System\Workforce\ProviderSelector;
use App\Extensions\TitanAIVision\System\Workforce\WorkforceProviderContribution;
use App\Extensions\TitanAIVision\System\Workforce\WorkforceProviderEventEmitter;
use App\Extensions\TitanAIVision\System\Workforce\ProviderHealthProbeContract;
use App\Extensions\TitanAIVision\System\Workforce\ProviderHealthProbe;
use App\Extensions\TitanAIVision\System\Workforce\ProviderHealthRefreshService;
use App\Extensions\TitanAIVision\System\Workforce\WorkforceProviderStatusService;
use Illuminate\Contracts\Http\Kernel;use Illuminate\Routing\Router;use Illuminate\Support\Facades\File;use Illuminate\Support\ServiceProvider;
final class TitanAIVisionServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface,UninstallExtensionServiceProviderInterface{
    public function register():void{
        
        $this->app->singleton(ProviderHealthProbeContract::class, fn($app): ProviderHealthProbeContract => new ProviderHealthProbe(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app
        ));
        $this->app->singleton(ProviderHealthRefreshService::class, fn($app): ProviderHealthRefreshService => new ProviderHealthRefreshService(
            $app->make(ProviderHealthProbeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(WorkforceProviderEventEmitter::class),
        ));
        $this->app->singleton(WorkforceProviderStatusService::class, fn($app): WorkforceProviderStatusService => new WorkforceProviderStatusService(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
        ));
// Agent-06 Pass 5: host-facing Workforce provider registration.
        $this->app->singleton(WorkforceProviderRuntimeContract::class, fn(): WorkforceProviderRuntimeContract => PackageWorkforceProviderAdapter::fromPackageRoot(dirname(__DIR__)));
        $this->app->singleton(ProviderHealthStoreContract::class, fn($app): ProviderHealthStoreContract => new LaravelCacheProviderHealthStore($app->make('cache.store')));
        $this->app->singleton(ProviderHealthRegistry::class, fn($app): ProviderHealthRegistry => new ProviderHealthRegistry($app->make(ProviderHealthStoreContract::class)));
        $this->app->singleton(CapabilityResolver::class, fn($app): CapabilityResolver => new CapabilityResolver($app->make(ProviderHealthRegistry::class)));
        $this->app->singleton(ProviderSelector::class);
        $this->app->singleton(WorkforceProviderEventEmitter::class, fn($app): WorkforceProviderEventEmitter => new WorkforceProviderEventEmitter($app->make('events')));
        $this->app->singleton(WorkforceProviderContribution::class, fn($app): WorkforceProviderContribution => new WorkforceProviderContribution(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(CapabilityResolver::class),
            $app->make(ProviderSelector::class),
        ));
        $this->app->tag([WorkforceProviderContribution::class], 'titan.workforce.providers');
$this->mergeConfigFrom(__DIR__.'/../config/titan-ai-vision.php','titan-ai-vision');$this->app->singleton(TitanAIVisionManagerContract::class,TitanAIVisionManager::class);$this->app->alias(TitanAIVisionManagerContract::class,'titan.ai.vision');}
    public function boot(Kernel $kernel):void{$this->loadTranslationsFrom(__DIR__.'/../resources/lang','titan-ai-vision');$this->loadViewsFrom(__DIR__.'/../resources/views','titan-ai-vision');$this->loadMigrationsFrom(__DIR__.'/../database/migrations');$this->publishes([__DIR__.'/../config/titan-ai-vision.php'=>config_path('titan-ai-vision.php')],'extension');$this->registerRoutes();if($this->app->runningInConsole()){$this->commands([CertifyExtensionCommand::class]);}}
    public function registerKey():string{return 'titan-ai-vision';}
    public static function uninstall():void{File::delete(config_path('titan-ai-vision.php'));}
    private function registerRoutes():void{/** @var Router $router */$router=$this->app['router'];$router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-ai-vision','as'=>'dashboard.user.titan-ai-vision.'],static function(Router $router):void{require __DIR__.'/../routes/user.php';});$router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-ai-vision','as'=>'dashboard.admin.titan-ai-vision.'],static function(Router $router):void{require __DIR__.'/../routes/admin.php';});}
}
