<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;use Illuminate\Database\Eloquent\Relations\HasMany;
final class TitanVisionEvidenceItem extends Model{protected $table='titan_vision_evidence_items';protected $guarded=[];protected $casts=['metadata'=>'array'];public function evidenceSet():BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'evidence_set_id');}public function annotations():HasMany{return $this->hasMany(TitanVisionAnnotation::class,'evidence_item_id');}}
