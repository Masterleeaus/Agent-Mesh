<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class BeforeAfterPairingService {
    public function pair(iterable $items): array {
        $before=[];$after=[];
        foreach($items as $item){$a=is_array($item)?$item:(method_exists($item,'toArray')?$item->toArray():(array)$item);$role=(string)($a['role']??'current');if(!in_array($role,['before','after'],true))continue;$key=$this->pairKey((array)($a['metadata']??[]));$entry=['id'=>(int)($a['id']??0),'pair_key'=>$key,'capture_key'=>(string)(($a['metadata']['capture_key']??''))];if($role==='before')$before[$key][]=$entry;else $after[$key][]=$entry;}
        $pairs=[];$keys=array_values(array_unique(array_merge(array_keys($before),array_keys($after))));sort($keys);
        foreach($keys as $key){$b=$before[$key]??[];$a=$after[$key]??[];$n=max(count($b),count($a));for($i=0;$i<$n;$i++)$pairs[]=['pair_key'=>$key,'before_id'=>$b[$i]['id']??null,'after_id'=>$a[$i]['id']??null,'before_capture_key'=>$b[$i]['capture_key']??null,'after_capture_key'=>$a[$i]['capture_key']??null,'complete'=>isset($b[$i],$a[$i])];}
        return $pairs;
    }
    private function pairKey(array $metadata): string {
        $explicit=trim((string)($metadata['pair_key']??''));if($explicit!=='')return $explicit;
        $capture=strtolower(trim((string)($metadata['capture_key']??'unassigned')));$capture=preg_replace('/(^|_)(before|after|current|reference)($|_)/','_',$capture)??$capture;$capture=trim(preg_replace('/_+/','_',$capture)??$capture,'_');return $capture!==''?$capture:'unassigned';
    }
}
