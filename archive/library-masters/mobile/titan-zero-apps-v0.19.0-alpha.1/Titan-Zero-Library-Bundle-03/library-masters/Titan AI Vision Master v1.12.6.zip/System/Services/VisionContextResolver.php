<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
use Illuminate\Contracts\Container\Container;
final class VisionContextResolver {
    public function __construct(private readonly Container $container) {}
    public function resolve(array $ids, array $runtime=[]): array {
        if(!$this->container->bound('titan.assist.context')) return ['resolved'=>[],'missing'=>array_keys(array_filter($ids)),'runtime'=>$runtime];
        try {
            $resolver=$this->container->make('titan.assist.context');
            if(is_object($resolver)&&method_exists($resolver,'resolve')) return (array)$resolver->resolve($ids,$runtime)+['runtime'=>$runtime];
        } catch(\Throwable) {}
        return ['resolved'=>[],'missing'=>array_keys(array_filter($ids)),'runtime'=>$runtime];
    }
}
