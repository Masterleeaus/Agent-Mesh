<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class InspectionProfileRegistry {
    public function __construct(private readonly VerticalInspectionPackRegistry $packs) {}
    public const ASSET_VISUAL_PASSPORT='asset_visual_passport';
    public function all(): array { return [
        'general'=>['label'=>'General Field Service','captures'=>['site_wide','work_detail','additional_angle']],
        'cleaning'=>['label'=>'Cleaning','captures'=>['room_wide','completed_surfaces','problem_area'],'hints'=>['visible residue','missed areas','damage observations','consumables']],
        'window_cleaning'=>['label'=>'Window Cleaning','captures'=>['elevation_wide','glass_detail','frame_track_detail'],'hints'=>['visible residue','streaking','frame condition','access constraints']],
        'carpet_upholstery'=>['label'=>'Carpet & Upholstery','captures'=>['area_wide','stain_detail','completed_surface'],'hints'=>['visible staining','fibre condition','colour variation','completion evidence']],
        'pressure_washing'=>['label'=>'Pressure Washing','captures'=>['area_before','surface_detail','area_after'],'hints'=>['surface condition','visible staining','overspray risk','before/after comparability']],
        'plumbing'=>['label'=>'Plumbing','captures'=>['installation_wide','connection_detail','nameplate_or_fixture'],'hints'=>['visible leaks','corrosion','connections','fixture condition']],
        'electrical'=>['label'=>'Electrical','captures'=>['work_area_wide','panel_or_device','label_detail'],'hints'=>['visible damage','open enclosures','labels','cable condition'],'always_review'=>true],
        'hvac'=>['label'=>'HVAC','captures'=>['unit_wide','nameplate','controls_or_issue'],'hints'=>['nameplate','filter condition','visible damage','installation context']],
        'handyman_property_maintenance'=>['label'=>'Handyman & Property Maintenance','captures'=>['area_wide','defect_detail','completed_work'],'hints'=>['condition','fixing quality','damage','follow-up needs']],
        'roofing_guttering'=>['label'=>'Roofing & Guttering','captures'=>['roof_area_wide','defect_detail','drainage_detail'],'hints'=>['visible damage','debris','flashing','gutter condition'],'always_review'=>true],
        'landscaping'=>['label'=>'Landscaping & Gardening','captures'=>['site_wide','completed_area','issue_detail'],'hints'=>['surface condition','plant condition','edges','irrigation evidence']],
        'arborist'=>['label'=>'Arborist','captures'=>['tree_wide','canopy_or_defect','surrounding_targets'],'hints'=>['visible deadwood','branch condition','targets below','access constraints'],'always_review'=>true],
        'pest_control'=>['label'=>'Pest Control','captures'=>['site_wide','evidence_detail','treatment_area'],'hints'=>['visible pest evidence','entry points','treatment location'],'always_review'=>true],
        'locksmith_security'=>['label'=>'Locksmith & Security','captures'=>['door_or_entry_wide','lock_detail','frame_or_hardware'],'hints'=>['visible hardware condition','alignment','damage','access state']],
        'security_systems'=>['label'=>'Security Systems','captures'=>['system_wide','device_detail','label_or_connection'],'hints'=>['device identity','visible damage','mounting','cabling context'],'always_review'=>true],
        'pool_spa'=>['label'=>'Pool & Spa','captures'=>['system_wide','equipment_nameplate','visible_issue'],'hints'=>['equipment condition','visible leaks','surface condition']],
        'solar'=>['label'=>'Solar','captures'=>['array_wide','inverter_nameplate','visible_issue'],'hints'=>['panel condition','inverter labels','visible cabling'],'always_review'=>true],
        'appliance_repair'=>['label'=>'Appliance Repair','captures'=>['appliance_wide','nameplate','fault_area'],'hints'=>['model identifiers','visible damage','controls','connections']],
        'waste_removal'=>['label'=>'Waste Removal','captures'=>['load_wide','waste_detail','site_after'],'hints'=>['load type','visible hazardous indicators','site clearance','access']],
        'ndis_home_maintenance'=>['label'=>'NDIS Home Maintenance','captures'=>['area_wide','accessibility_detail','completed_work'],'hints'=>['accessibility','trip hazards','visible completion','resident-impact considerations'],'always_review'=>true],
        'facilities_maintenance'=>['label'=>'Facilities Maintenance','captures'=>['asset_or_area_wide','defect_detail','completion_or_label'],'hints'=>['asset identity','visible defects','service evidence','site impacts']],
        'property_maintenance'=>['label'=>'Property Maintenance','captures'=>['area_wide','defect_detail','completed_work'],'hints'=>['condition','damage','completion evidence','follow-up needs']],
    ]; }
    public function get(string $key): array { $all=$this->all(); return $all[$key] ?? $all['general']; }
    public function assetCaptureRequirements(string $key): array { $profile=$this->get($key);$preferred=array_values(array_filter((array)($profile['captures']??[]),fn($v)=>str_contains((string)$v,'nameplate')||str_contains((string)$v,'label')||str_contains((string)$v,'identifier')||str_contains((string)$v,'unit_wide')||str_contains((string)$v,'system_wide')||str_contains((string)$v,'appliance_wide')));return $preferred!==[]?$preferred:['equipment_wide','nameplate']; }
    public function assuranceRules(string $key): array {
        $profile=$this->get($key);$rules=['minimum_capture_coverage'=>1.0,'minimum_confirmed_ratio'=>0.60,'minimum_comparison_score'=>0.65,'always_human_review'=>(bool)($profile['always_review']??false)];
        $overrides=[
            'cleaning'=>['minimum_confirmed_ratio'=>0.50,'minimum_comparison_score'=>0.70],
            'window_cleaning'=>['minimum_comparison_score'=>0.75],
            'pressure_washing'=>['minimum_comparison_score'=>0.75],
            'electrical'=>['minimum_confirmed_ratio'=>0.80,'minimum_comparison_score'=>0.75,'always_human_review'=>true],
            'roofing_guttering'=>['minimum_confirmed_ratio'=>0.75,'minimum_comparison_score'=>0.70,'always_human_review'=>true],
            'arborist'=>['minimum_confirmed_ratio'=>0.75,'always_human_review'=>true],
            'pest_control'=>['minimum_confirmed_ratio'=>0.75,'always_human_review'=>true],
            'security_systems'=>['minimum_confirmed_ratio'=>0.75,'always_human_review'=>true],
            'solar'=>['minimum_confirmed_ratio'=>0.80,'minimum_comparison_score'=>0.75,'always_human_review'=>true],
            'ndis_home_maintenance'=>['minimum_confirmed_ratio'=>0.75,'always_human_review'=>true],
        ];
        $rules=array_replace($rules,$overrides[$key]??[]);$pack=$this->packs->get($key);return array_replace($rules,(array)($pack['completion_rules']??[]));
    }
}
