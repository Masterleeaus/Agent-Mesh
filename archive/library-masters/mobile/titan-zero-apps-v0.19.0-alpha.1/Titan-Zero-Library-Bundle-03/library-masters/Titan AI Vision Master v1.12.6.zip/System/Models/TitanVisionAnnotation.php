<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;use Illuminate\Database\Eloquent\Relations\HasMany;
final class TitanVisionAnnotation extends Model{protected $table='titan_vision_annotations';protected $guarded=[];protected $casts=['metadata'=>'array','geometry'=>'array','requires_human_confirmation'=>'boolean'];public function evidenceItem():BelongsTo{return $this->belongsTo(TitanVisionEvidenceItem::class,'evidence_item_id');}public function parent():BelongsTo{return $this->belongsTo(self::class,'parent_annotation_id');}public function children():HasMany{return $this->hasMany(self::class,'parent_annotation_id');}}
