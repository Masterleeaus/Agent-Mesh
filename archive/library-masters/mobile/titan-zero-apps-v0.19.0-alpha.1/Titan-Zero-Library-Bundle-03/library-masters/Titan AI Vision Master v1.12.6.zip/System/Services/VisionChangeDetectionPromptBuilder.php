<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class VisionChangeDetectionPromptBuilder
{
    public function build(array $pairs,array $baselineFindings,array $currentFindings): string
    {
        $pairText=json_encode($pairs,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        $baselineText=json_encode($baselineFindings,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        $currentText=json_encode($currentFindings,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        return <<<PROMPT
You are Titan AI Vision's longitudinal change comparison worker.
Compare only the supplied explicitly VERIFIED historical baseline images with the current visit images.

AUTHORITY BOUNDARY:
- You provide visual inference only. You do not establish business truth, compliance, safety, completion, liability, pricing, or scope approval.
- Do not infer hidden conditions.
- A missing current finding may be called resolved only when the same subject/area is sufficiently comparable and current evidence coverage supports that conclusion.
- If framing, angle, lighting, coverage, occlusion, or subject identity prevent a reliable comparison, use not_comparable.
- If the evidence is conflicting or confidence is low, use uncertain.
- Preserve stable finding keys when the same finding can be matched across visits.

CANONICAL CHANGE TYPES:
new | resolved | improved | worsened | unchanged | uncertain | not_comparable

IMAGE PAIR MAP (image indices refer to the supplied comparison image array):
{$pairText}

VERIFIED BASELINE FINDINGS:
{$baselineText}

CURRENT VISIT FINDINGS:
{$currentText}

Return ONLY valid JSON:
{
  "changes":[
    {
      "finding_key":"stable_machine_key",
      "label":"human label",
      "baseline_present":true,
      "current_present":true,
      "baseline_severity":"low|review|medium|high|critical",
      "current_severity":"low|review|medium|high|critical",
      "comparability_score":0.0,
      "confidence":0.0,
      "baseline_image_index":0,
      "current_image_index":1,
      "observation":"visible change evidence only",
      "recommended_type":"new|resolved|improved|worsened|unchanged|uncertain|not_comparable"
    }
  ]
}
PROMPT;
    }
}
