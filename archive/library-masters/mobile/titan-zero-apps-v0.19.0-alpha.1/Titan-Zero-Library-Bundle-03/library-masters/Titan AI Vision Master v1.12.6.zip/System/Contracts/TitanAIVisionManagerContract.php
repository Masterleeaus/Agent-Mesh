<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Contracts;
interface TitanAIVisionManagerContract {
    public function modes(): array;
    public function profiles(): array;
    public function analyse(int $userId, array $input): array;
}
