<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Models;
use Illuminate\Database\Eloquent\Model;use Illuminate\Database\Eloquent\Relations\BelongsTo;
final class TitanVisionComparison extends Model{protected $table='titan_vision_comparisons';protected $guarded=[];protected $casts=['factors'=>'array','metadata'=>'array','requires_human_review'=>'boolean'];public function evidenceSet():BelongsTo{return $this->belongsTo(TitanVisionEvidenceSet::class,'evidence_set_id');}}
