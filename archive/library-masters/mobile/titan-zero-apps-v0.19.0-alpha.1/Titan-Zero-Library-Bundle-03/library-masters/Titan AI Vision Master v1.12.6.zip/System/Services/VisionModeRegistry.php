<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
final class VisionModeRegistry {
    public function all(): array { return [
        'job_check'=>['label'=>'Job Check','risk'=>'medium','description'=>'Check visible evidence against the supplied job scope and checklist.'],
        'before_after'=>['label'=>'Before / After','risk'=>'low','description'=>'Compare before and after images without treating visual difference as proof of hidden outcomes.'],
        'site_inspection'=>['label'=>'Site Inspection','risk'=>'medium','description'=>'Structure visible site observations, potential defects and missing evidence.'],
        'equipment_scan'=>['label'=>'Equipment Scan','risk'=>'medium','description'=>'Read visible nameplates and equipment context; never invent model or fault information.'],
        'damage_assessment'=>['label'=>'Damage Assessment','risk'=>'medium','description'=>'Document visible damage, location, evidence coverage and uncertainty.'],
        'safety_evidence'=>['label'=>'Safety Evidence','risk'=>'high','description'=>'Identify visible potential hazards; never certify a site safe from images alone.'],
        'parts_recognition'=>['label'=>'Parts Recognition','risk'=>'medium','description'=>'Identify likely part/component candidates and visible identifiers for human verification.'],
        'completion_assurance'=>['label'=>'Completion Assurance','risk'=>'high','description'=>'Assess evidence coverage and visible discrepancies before governed completion review.'],
    ]; }
    public function get(string $mode): array { $all=$this->all(); return $all[$mode] ?? $all['job_check']; }
}
