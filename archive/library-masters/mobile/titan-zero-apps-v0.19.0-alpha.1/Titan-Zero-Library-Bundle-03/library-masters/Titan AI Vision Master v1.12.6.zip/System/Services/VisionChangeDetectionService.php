<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

use App\Extensions\TitanAIVision\System\Models\TitanVisionChange;
use App\Extensions\TitanAIVision\System\Models\TitanVisionEvidenceSet;
use Throwable;

final class VisionChangeDetectionService
{
    public function __construct(
        private readonly VisionProviderRegistry $providers,
        private readonly VisionChangeDetectionPromptBuilder $prompts,
        private readonly VisionChangeDetectionPolicyService $policy,
    ){}

    public function detect(TitanVisionEvidenceSet $set): array
    {
        $set->loadMissing(['items.annotations','previousVerifiedBaseline.items.annotations']);
        $baseline=$set->previousVerifiedBaseline;
        if(!$baseline||$baseline->verification_status!=='verified'||$baseline->status!=='analysed'||$baseline->baseline_verified_at===null){
            return $this->markCoverage($set,['status'=>'not_available','reason'=>'No explicitly verified historical baseline is linked to this visit.']);
        }

        $pairs=$this->capturePairs($baseline,$set);
        if($pairs===[]){
            return $this->markCoverage($set,['status'=>'not_comparable','reason'=>'No matching capture slots exist between the verified baseline and current visit.','summary'=>['not_comparable'=>1]]);
        }

        $images=[];$pairMap=[];
        foreach($pairs as $pair){
            $baselineIndex=count($images);$images[]=$pair['baseline_source'];
            $currentIndex=count($images);$images[]=$pair['current_source'];
            $pairMap[]=['capture_key'=>$pair['capture_key'],'baseline_image_index'=>$baselineIndex,'current_image_index'=>$currentIndex];
        }
        $baselineFindings=$this->findingSnapshot($baseline);$currentFindings=$this->findingSnapshot($set);
        try{
            $provider=$this->providers->resolve();
            $raw=$provider->analyse($this->prompts->build($pairMap,$baselineFindings,$currentFindings),$images,['user_id'=>$set->user_id,'evidence_set_id'=>$set->id,'baseline_evidence_set_id'=>$baseline->id,'purpose'=>'longitudinal_change_detection']);
            $decoded=$this->decode($raw['text']??$raw);
            $changes=(array)($decoded['changes']??[]);
            if($changes===[]) return $this->markCoverage($set,['status'=>'review_required','reason'=>'Provider returned no structured longitudinal changes.']);
            $summary=[];
            foreach($changes as $i=>$rawChange){
                if(!is_array($rawChange))continue;
                $findingKey=trim((string)($rawChange['finding_key']??''));if($findingKey==='')$findingKey='change-'.$i;
                $candidate=[
                    'comparability_score'=>$rawChange['comparability_score']??0,
                    'confidence'=>$rawChange['confidence']??0,
                    'baseline_present'=>(bool)($rawChange['baseline_present']??false),
                    'current_present'=>(bool)($rawChange['current_present']??false),
                    'baseline_severity'=>$rawChange['baseline_severity']??'review',
                    'current_severity'=>$rawChange['current_severity']??'review',
                    'evidence_complete'=>$this->evidenceComplete($set),
                ];
                $decision=$this->policy->classify($candidate);$type=$decision['change_type'];$summary[$type]=($summary[$type]??0)+1;
                TitanVisionChange::updateOrCreate(
                    ['evidence_set_id'=>$set->id,'baseline_evidence_set_id'=>$baseline->id,'finding_key'=>$findingKey],
                    ['user_id'=>$set->user_id,'company_id'=>$set->company_id,'continuity_key'=>$set->continuity_key,'label'=>$rawChange['label']??null,'change_type'=>$type,'baseline_severity'=>$rawChange['baseline_severity']??null,'current_severity'=>$rawChange['current_severity']??null,'confidence_score'=>$decision['confidence_score'],'comparability_score'=>$decision['comparability_score'],'requires_human_review'=>$decision['requires_human_review'],'human_status'=>'pending','observation'=>$rawChange['observation']??null,'reason'=>$decision['reason'],'metadata'=>['provider_recommended_type'=>$rawChange['recommended_type']??null,'baseline_image_index'=>$rawChange['baseline_image_index']??null,'current_image_index'=>$rawChange['current_image_index']??null,'provider'=>$raw['provider']??$provider->key(),'model'=>$raw['model']??null]]
                );
            }
            return $this->markCoverage($set,['status'=>'analysed','baseline_evidence_set_id'=>$baseline->id,'summary'=>$summary,'requires_human_review'=>collect($summary)->except('unchanged')->sum()>0]);
        }catch(Throwable $e){
            return $this->markCoverage($set,['status'=>'failed','reason'=>$e->getMessage()]);
        }
    }

    private function capturePairs(TitanVisionEvidenceSet $baseline,TitanVisionEvidenceSet $current): array
    {
        $before=[];foreach($baseline->items as $item){$key=trim((string)data_get($item->metadata,'capture_key',''));if($key!=='')$before[$key]=$item;}
        $pairs=[];foreach($current->items as $item){$key=trim((string)data_get($item->metadata,'capture_key',''));if($key!==''&&isset($before[$key]))$pairs[]=['capture_key'=>$key,'baseline_source'=>$before[$key]->source,'current_source'=>$item->source];}
        return $pairs;
    }
    private function findingSnapshot(TitanVisionEvidenceSet $set): array
    {
        $rows=[];foreach($set->items as $item){foreach($item->annotations as $a){if($a->human_status==='rejected')continue;$rows[]=['finding_key'=>$a->finding_key,'label'=>$a->label,'severity'=>$a->severity,'human_status'=>$a->human_status,'confidence'=>$a->confidence,'capture_key'=>data_get($item->metadata,'capture_key')];}}return $rows;
    }
    private function evidenceComplete(TitanVisionEvidenceSet $set): bool{return (array)data_get($set->coverage,'missing_capture_keys',[])===[]&&(array)data_get($set->coverage,'missing_evidence',[])===[];}
    private function decode(mixed $response): array
    {
        if(is_array($response))return $response;$text=trim((string)$response);if($text==='')return [];
        if(preg_match('/```(?:json)?\s*(\{.*\})\s*```/is',$text,$m))$text=$m[1];$decoded=json_decode($text,true);return is_array($decoded)?$decoded:[];
    }
    private function markCoverage(TitanVisionEvidenceSet $set,array $state): array{$coverage=(array)$set->coverage;$coverage['change_detection']=$state;$set->update(['coverage'=>$coverage]);return $state;}
}
