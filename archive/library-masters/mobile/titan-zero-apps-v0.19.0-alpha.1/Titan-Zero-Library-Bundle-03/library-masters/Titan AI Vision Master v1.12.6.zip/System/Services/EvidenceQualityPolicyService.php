<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;

final class EvidenceQualityPolicyService
{
    public function evaluate(array $metrics,bool $duplicate=false,bool $requireScale=false):array
    {
        $issues=[];$guidance=[];$width=(int)($metrics['width']??0);$height=(int)($metrics['height']??0);
        $mean=$this->number($metrics['mean_luminance']??null);$highlights=$this->number($metrics['highlight_ratio']??null);
        $sharpness=$this->number($metrics['sharpness']??null);$coverage=$this->number($metrics['subject_coverage']??null);
        if($width>0&&$height>0&&min($width,$height)<720){$issues[]='low_resolution';$guidance[]='Retake closer or at a higher camera resolution so the important detail is readable.';}
        if($mean!==null&&$mean<0.12){$issues[]='too_dark';$guidance[]='Retake with more light or move the light source so the subject is clearly visible.';}
        if(($mean!==null&&$mean>0.88)||($highlights!==null&&$highlights>0.35)){$issues[]='overexposed';$guidance[]='Retake with less glare or change angle so bright areas retain visible detail.';}
        if($sharpness!==null&&$sharpness<0.18){$issues[]='blurry';$guidance[]='Hold the camera steady, tap to focus, and retake the photo.';}
        if($coverage!==null&&$coverage<0.18){$issues[]='subject_too_small';$guidance[]='Move closer or reframe so the required subject occupies more of the image.';}
        if($duplicate){$issues[]='duplicate';$guidance[]='This appears to duplicate another capture. Take a different required angle or detail instead.';}
        if($requireScale&&!($metrics['has_scale_reference']??false)){$issues[]='missing_scale_reference';$guidance[]='Include an appropriate scale/reference only when size comparison is required by the inspection.';}
        $severe=($width>0&&$height>0&&min($width,$height)<240)||($mean!==null&&$mean<0.025)||($highlights!==null&&$highlights>0.90);
        $score=1.0;$weights=['low_resolution'=>0.15,'too_dark'=>0.22,'overexposed'=>0.22,'blurry'=>0.25,'subject_too_small'=>0.16,'duplicate'=>0.30,'missing_scale_reference'=>0.08];
        foreach($issues as $issue)$score-=$weights[$issue]??0.1;$score=max(0.0,min(1.0,$score));
        return ['acceptable'=>$issues===[],'ready_for_inference'=>!$severe,'quality_score'=>round($score,4),'issues'=>$issues,'guidance'=>array_values(array_unique($guidance)),'metrics'=>$metrics];
    }
    private function number(mixed $value):?float{return is_numeric($value)?max(0.0,min(1.0,(float)$value)):null;}
}
