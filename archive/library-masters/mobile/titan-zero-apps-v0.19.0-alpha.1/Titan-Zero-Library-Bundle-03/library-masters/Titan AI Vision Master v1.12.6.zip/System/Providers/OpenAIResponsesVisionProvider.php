<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Providers;
use App\Extensions\TitanAIVision\System\Contracts\VisionProviderContract;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
final class OpenAIResponsesVisionProvider implements VisionProviderContract {
    public function key():string{return 'openai-responses';}
    public function analyse(string $prompt,array $images,array $context=[]):array{
        $companyId=trim((string)($context['company_id']??''));
        $source=strtoupper(trim((string)($context['intelligence_source']??'BYO')));
        $byoKey=trim((string)($context['provider_api_key']??''));
        $managed=$source==='TITAN_SYSTEM_AI';
        if($source==='DEVICE'||$source==='LOCAL') throw new \RuntimeException('VISION_LOCAL_ROUTE_MUST_EXECUTE_ON_DEVICE_OR_LOCAL_RUNTIME');
        if($managed){
            if($companyId==='') throw new \RuntimeException('TITAN_VISION_CLOUD_REQUIRES_COMPANY_ID');
            if(!(bool)($context['explicit_titan_opt_in']??false)) throw new \RuntimeException('TITAN_VISION_CLOUD_EXPLICIT_OPT_IN_REQUIRED');
            if(!app()->bound('titan.workforce.cost-sovereignty')) throw new \RuntimeException('COST_SOVEREIGNTY_ROUTER_UNAVAILABLE');
            $route=app('titan.workforce.cost-sovereignty')->select((int)$companyId,'vision_cloud',[[
                'id'=>'titan-vision-openai','execution_location'=>'titan_cloud','cost_owner'=>'titan','requires_entitlement'=>'titan.vision.cloud','billing_unit'=>'image','estimated_cost'=>(float)($context['estimated_cost']??0.0),
            ]],[
                'business_capability_tier'=>$context['business_capability_tier']??'free','autonomy_level'=>$context['autonomy_level']??'assist','explicit_titan_managed_opt_in'=>true,'explicit_cost_approval'=>(bool)($context['cost_approval']??false),'estimated_cost'=>(float)($context['estimated_cost']??0.0),
            ]);
            if(($route['status']??null)!=='selected') throw new \RuntimeException((string)($route['reason']??'TITAN_VISION_CLOUD_DENIED'));
            $apiKey=trim((string)config('titan-ai-vision.openai_api_key',''));
        }else{
            if(!in_array($source,['BYO','HYBRID'],true)) throw new \RuntimeException('VISION_INTELLIGENCE_SOURCE_NOT_SUPPORTED_BY_EXTERNAL_GATEWAY');
            $apiKey=$byoKey;
        }
        if($apiKey==='') throw new \RuntimeException($managed?'Titan Vision Cloud credential is not configured.':'Customer BYO vision API key is required.');
        $content=[['type'=>'input_text','text'=>$prompt]];
        foreach($images as $imageSource){$url=$this->imageInput((string)$imageSource);if($url!==null)$content[]=['type'=>'input_image','image_url'=>$url,'detail'=>config('titan-ai-vision.openai_detail','high')];}
        if(count($content)===1)throw new \InvalidArgumentException('No usable image inputs were supplied.');
        $payload=['model'=>config('titan-ai-vision.openai_model','gpt-5-mini'),'input'=>[['role'=>'user','content'=>$content]],'text'=>['format'=>['type'=>'json_object']]];
        $response=Http::withToken($apiKey)->acceptJson()->timeout(180)->post('https://api.openai.com/v1/responses',$payload);
        if(!$response->successful())throw new \RuntimeException('OpenAI vision request failed with HTTP '.$response->status().'.');
        $json=$response->json();
        $result=['provider'=>$this->key(),'model'=>$json['model']??$payload['model'],'request_id'=>$response->header('x-request-id'),'text'=>$this->extractOutputText((array)$json),'raw'=>$json,'intelligence_source'=>$source,'cost_owner'=>$managed?'titan':'customer'];
        if($managed && app()->bound('titan.workforce.cost-sovereignty')){
            $result['resource_cost_receipt']=app('titan.workforce.cost-sovereignty')->commitUsage((int)$companyId,'vision_cloud',['id'=>'titan-vision-openai','execution_location'=>'titan_cloud','cost_owner'=>'titan','requires_entitlement'=>'titan.vision.cloud','billing_unit'=>'image'],['actual_cost'=>(float)($context['actual_cost']??$context['estimated_cost']??0.0),'billing_units'=>count($images),'model'=>$result['model'],'autonomy_level'=>$context['autonomy_level']??'assist']);
        }
        return $result;
    }
    private function imageInput(string $source):?string{
        if(Str::startsWith($source,['https://','http://','data:image/']))return $source;$candidate=ltrim((string)(parse_url($source,PHP_URL_PATH)?:$source),'/');
        foreach([$source,public_path($candidate),base_path($candidate),storage_path('app/'.$candidate)] as $path){if(is_string($path)&&is_file($path)&&is_readable($path)){$bytes=file_get_contents($path);if($bytes===false)return null;$mime=mime_content_type($path)?:'image/jpeg';if(!Str::startsWith($mime,'image/'))return null;return 'data:'.$mime.';base64,'.base64_encode($bytes);}}
        return null;
    }
    private function extractOutputText(array $json):string{$chunks=[];foreach(($json['output']??[]) as $item){foreach(($item['content']??[]) as $content){if(($content['type']??'')==='output_text'&&isset($content['text']))$chunks[]=(string)$content['text'];}}return trim(implode("\n",$chunks));}
}
