<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Services;
use App\Extensions\TitanAIVision\System\Contracts\TitanAIVisionManagerContract;
final class TitanAIVisionManager implements TitanAIVisionManagerContract {
    public function __construct(private readonly VisionModeRegistry $modes,private readonly InspectionProfileRegistry $profiles,private readonly VisionContextResolver $context,private readonly VisionPromptBuilder $prompts,private readonly VisionProviderRegistry $providers,private readonly VisionFindingParser $parser,private readonly VisionEvidenceService $evidence,private readonly EvidenceQualityAnalyzerService $quality,private readonly AssetVisualPassportService $assetPassports){}
    public function modes():array{return $this->modes->all();}public function profiles():array{return $this->profiles->all();}
    public function analyse(int $userId,array $input):array{
        $mode=(string)($input['mode']??'job_check');$profile=(string)($input['profile']??'general');
        $ctx=$this->context->resolve(['customer'=>$input['customer_id']??null,'property'=>$input['property_id']??null,'job'=>$input['job_id']??null,'asset'=>$input['asset_id']??null],['user_id'=>$userId,'source'=>'titan_ai_vision']);
        $quality=$this->quality->analyse((array)($input['images']??[]),(array)($input['capture_keys']??[]));$input['quality_reports']=$quality['reports'];$input['quality_summary']=['ready_for_inference'=>$quality['ready_for_inference'],'issue_count'=>$quality['issue_count'],'guidance'=>$quality['guidance']];
        $set=$this->evidence->create($userId,$input,$ctx);if(!$quality['ready_for_inference']){$set->update(['status'=>'review_required']);return ['success'=>false,'error_code'=>'evidence_quality_unusable','message'=>'One or more images are too poor for reliable visual inference. Retake the flagged evidence before analysis.','evidence_set_id'=>$set->id,'quality'=>$quality];}$prompt=$this->prompts->build($mode,$profile,(string)($input['instruction']??'Analyse the supplied visual evidence.'),$ctx,(array)($input['coverage']??[]));
        try{$provider=$this->providers->resolve();$raw=$provider->analyse($prompt,(array)$input['images'],['user_id'=>$userId,'evidence_set_id'=>$set->id]);$structured=$this->parser->parse($raw['text']??$raw);
            if($structured===[]){$set->update(['status'=>'review_required']);return ['success'=>false,'error_code'=>'invalid_structured_output','message'=>'Vision provider returned no valid structured finding package.','evidence_set_id'=>$set->id];}
            $this->evidence->persistFindings($set,$structured);$assetPassport=$this->assetPassports->observe($set->fresh('items'),$structured);return ['success'=>true,'evidence_set_id'=>$set->id,'provider'=>$raw['provider']??$provider->key(),'model'=>$raw['model']??null,'result'=>$structured,'quality'=>$quality,'asset_visual_passport'=>$assetPassport];
        }catch(\Throwable $e){$set->update(['status'=>'failed']);return ['success'=>false,'error_code'=>'provider_error','message'=>$e->getMessage(),'evidence_set_id'=>$set->id];}
    }
}
