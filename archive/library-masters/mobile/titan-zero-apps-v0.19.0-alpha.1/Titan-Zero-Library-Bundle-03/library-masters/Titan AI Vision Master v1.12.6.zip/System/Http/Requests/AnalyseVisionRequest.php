<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
final class AnalyseVisionRequest extends FormRequest{
    public function authorize():bool{return auth()->check();}
    public function rules():array{return ['mode'=>['required','string','max:64'],'profile'=>['nullable','string','max:64'],'instruction'=>['nullable','string','max:10000'],'images'=>['required','array','min:1','max:12'],'images.*'=>['required','string','max:20000000'],'roles'=>['nullable','array'],'capture_keys'=>['nullable','array'],'pair_keys'=>['nullable','array'],'pair_keys.*'=>['nullable','string','max:96'],'capture_keys.*'=>['nullable','string','max:64'],'coverage'=>['nullable','array'],'quality_reports'=>['nullable','array'],'quality_reports.*'=>['nullable','array'],'customer_id'=>['nullable','string','max:191'],'property_id'=>['nullable','string','max:191'],'job_id'=>['nullable','string','max:191'],'asset_id'=>['nullable','string','max:191'],'area_key'=>['nullable','string','max:191'],'require_review'=>['nullable','boolean'],'title'=>['nullable','string','max:255']];}
}
