<?php
declare(strict_types=1);
namespace App\Extensions\TitanAIVision\System\Commands;
use Illuminate\Console\Command;use Illuminate\Support\Facades\Schema;
final class CertifyExtensionCommand extends Command{protected $signature='titan:titan-ai-vision:certify';protected $description='Run Titan AI Vision readiness checks.';public function handle():int{$tables=['titan_vision_evidence_sets','titan_vision_evidence_items','titan_vision_annotations','titan_vision_workflow_requests'];$missing=array_values(array_filter($tables,fn($t)=>!Schema::hasTable($t)));if($missing!==[]){$this->error('Missing tables: '.implode(', ',$missing));return self::FAILURE;}$this->info('Titan AI Vision readiness checks passed. Exact-host certification remains a separate release stage.');return self::SUCCESS;}}
