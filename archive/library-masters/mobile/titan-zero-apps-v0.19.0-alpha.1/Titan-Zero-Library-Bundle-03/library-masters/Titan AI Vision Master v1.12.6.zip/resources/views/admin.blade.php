@extends('panel.layout.app')
@section('title','Titan AI Vision Settings')
@section('content')
<div class="container-fluid py-6"><h1 class="mb-1 text-2xl font-bold">Titan AI Vision</h1><p class="mb-6 opacity-70">Provider and governance diagnostics.</p><div class="rounded-xl border p-5"><dl class="grid gap-3 md:grid-cols-2"><div><dt class="font-medium">Provider mode</dt><dd>{{ $config['provider'] ?? 'auto' }}</dd></div><div><dt class="font-medium">Legacy direct-provider model</dt><dd>{{ $config['openai_model'] ?? 'gpt-5-mini' }}</dd></div><div><dt class="font-medium">Human review default</dt><dd>{{ !empty($config['require_human_review_by_default']) ? 'Required' : 'Optional' }}</dd></div><div><dt class="font-medium">Evidence policy</dt><dd>Immutable originals / non-destructive annotations</dd></div></dl></div></div>
@endsection
