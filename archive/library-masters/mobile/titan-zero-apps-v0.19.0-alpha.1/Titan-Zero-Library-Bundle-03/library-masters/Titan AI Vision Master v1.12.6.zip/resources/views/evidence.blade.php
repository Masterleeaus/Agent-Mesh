@extends('panel.layout.app')
@section('title','Titan AI Vision Evidence')
@section('content')
<div class="container-fluid py-6">
 <div class="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h1 class="text-2xl font-bold">Evidence Set #{{ $set->id }}</h1><p class="opacity-70">{{ ucfirst(str_replace('_',' ',$set->mode)) }} · {{ ucfirst(str_replace('_',' ',$set->profile ?? 'general')) }}</p></div><a href="{{ route('dashboard.user.titan-ai-vision.index') }}" class="btn btn-outline-secondary">Back to Vision</a></div>
 @php $missingEvidence=(array) data_get($set->coverage,'missing_evidence',[]); @endphp
 @if(count($missingEvidence))<div class="mb-5 rounded-xl border border-warning/30 bg-warning/5 p-4"><b>More evidence requested</b><ul class="mt-2 list-disc pl-5 text-sm">@foreach($missingEvidence as $missing)<li>{{ $missing }}</li>@endforeach</ul></div>@endif
 @php $assuranceData=$assurance ?? (array) data_get($set->coverage,'assurance',[]); @endphp
 <div class="mb-5 rounded-xl border p-4" id="continuityPanel">
  <div class="flex flex-wrap items-start justify-between gap-3"><div><b>Evidence Continuity</b><p class="text-xs opacity-60">Only explicitly verified, fully reviewed evidence can become a historical baseline.</p></div><span id="continuityStatus" class="rounded border px-2 py-1 text-xs">{{ ucfirst($set->verification_status ?? 'unverified') }}</span></div>
  <div class="mt-3 grid gap-2 text-sm md:grid-cols-3"><div><span class="opacity-60">Continuity identity</span><div>{{ $set->continuity_key ?: 'Not linked' }}</div></div><div><span class="opacity-60">Visit</span><div>{{ $set->visit_sequence ?: '—' }}</div></div><div><span class="opacity-60">Previous verified baseline</span><div>@if($set->previousVerifiedBaseline)<a class="underline" href="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->previousVerifiedBaseline->id) }}">Evidence Set #{{ $set->previousVerifiedBaseline->id }}</a>@else None @endif</div></div></div>
  @if(($set->verification_status ?? 'unverified') !== 'verified')
   <div class="mt-3"><button type="button" id="verifyBaselineButton" class="btn btn-sm btn-outline-secondary" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/verify-baseline') }}" @if(!data_get($continuityAssessment,'eligible')) disabled @endif>Verify as Historical Baseline</button>@if(!data_get($continuityAssessment,'eligible'))<span class="ml-2 text-xs opacity-60">Resolve all findings, required captures and evidence integrity issues first.</span>@endif</div>
  @endif
 </div>
 <div class="mb-5 rounded-xl border p-4" id="longitudinalChanges">
  <div class="flex flex-wrap items-start justify-between gap-3"><div><b>Longitudinal Changes</b><p class="text-xs opacity-60">Compared only against the explicitly verified historical baseline. Change labels remain visual inference until reviewed.</p></div><span class="rounded border px-2 py-1 text-xs">{{ count($set->changes) }} changes</span></div>
  @if(count((array)data_get($set->coverage,'change_detection.summary',[])))<div class="mt-3 flex flex-wrap gap-2 text-xs">@foreach((array)data_get($set->coverage,'change_detection.summary',[]) as $type=>$count)<span class="rounded border px-2 py-1">{{ ucwords(str_replace('_',' ',$type)) }}: {{ $count }}</span>@endforeach</div>@endif
  <div class="mt-3 space-y-2">@forelse($set->changes as $change)<div class="rounded border p-3" data-change-id="{{ $change->id }}"><div class="flex flex-wrap justify-between gap-2"><div><b>{{ $change->label ?: $change->finding_key }}</b><span class="ml-2 rounded border px-2 py-0.5 text-xs">{{ ucwords(str_replace('_',' ',$change->change_type)) }}</span></div><span class="text-xs">confidence {{ round(((float)$change->confidence_score)*100) }}% · comparable {{ round(((float)$change->comparability_score)*100) }}%</span></div>@if($change->observation)<p class="mt-1 text-sm">{{ $change->observation }}</p>@endif<p class="mt-1 text-xs opacity-60">{{ $change->reason }}</p><div class="mt-2 flex flex-wrap items-center gap-2"><span class="text-xs">Review: <b class="change_human_status">{{ ucfirst(str_replace('_',' ',$change->human_status)) }}</b></span><button type="button" class="btn btn-sm btn-outline-secondary change-review" data-status="confirmed" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/changes/'.$change->id.'/review') }}">Confirm</button><button type="button" class="btn btn-sm btn-outline-secondary change-review" data-status="rejected" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/changes/'.$change->id.'/review') }}">Reject</button><button type="button" class="btn btn-sm btn-outline-secondary change-review" data-status="needs_more_evidence" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/changes/'.$change->id.'/review') }}">Need More Evidence</button></div></div>@empty<div class="text-sm opacity-60">No longitudinal changes have been recorded for this evidence set.</div>@endforelse</div>
 </div>
 <div class="mb-5 grid gap-4 lg:grid-cols-2">
  <div class="rounded-xl border p-4">
   <div class="flex items-center justify-between gap-3"><div><b>Completion Assurance v2</b><p class="text-xs opacity-60">Scope-to-evidence readiness only — Titan AI Vision cannot complete the job or approve a variation.</p></div><span class="rounded px-2 py-1 text-xs {{ data_get($assuranceData,'state') === 'READY_FOR_ASSURANCE' ? 'bg-success/10' : 'bg-warning/10' }}">{{ ucwords(str_replace('_',' ',data_get($assuranceData,'state','REVIEW_REQUIRED'))) }}</span></div>
   <div class="mt-3 grid grid-cols-3 gap-2 text-center text-xs"><div class="rounded border p-2"><div class="text-lg font-bold">{{ round(((float)data_get($assuranceData,'evidence_score',0))*100) }}%</div>Evidence score</div><div class="rounded border p-2"><div class="text-lg font-bold">{{ round(((float)data_get($assuranceData,'capture_coverage',0))*100) }}%</div>Capture coverage</div><div class="rounded border p-2"><div class="text-lg font-bold">{{ round(((float)data_get($assuranceData,'confirmed_ratio',0))*100) }}%</div>Confirmed findings</div></div>
   @if(count((array)data_get($assuranceData,'scope_evidence',[])))
    <div class="mt-3"><b class="text-sm">Approved scope evidence</b><div class="mt-2 space-y-1">@foreach((array)data_get($assuranceData,'scope_evidence',[]) as $scope)<div class="rounded border p-2 text-xs"><div class="flex justify-between gap-2"><span>{{ $scope['label'] ?: $scope['key'] }}</span><b>{{ ucwords(str_replace('_',' ',$scope['status'] ?? 'unknown')) }}</b></div>@if(!empty($scope['reason']))<div class="mt-1 opacity-60">{{ $scope['reason'] }}</div>@endif</div>@endforeach</div></div>
   @endif
   @if(count((array)data_get($assuranceData,'variation_candidates',[])))
    <div class="mt-3"><b class="text-sm">Variation candidates</b><div class="mt-2 space-y-1">@foreach((array)data_get($assuranceData,'variation_candidates',[]) as $variation)<div class="rounded border p-2 text-xs"><div class="flex justify-between gap-2"><span>{{ $variation['label'] ?: $variation['key'] }}</span><b>{{ ucwords(str_replace('_',' ',$variation['approval_status'] ?? 'pending')) }}</b></div>@if(!empty($variation['reason']))<div class="mt-1 opacity-60">{{ $variation['reason'] }}</div>@endif</div>@endforeach</div></div>
   @endif
   @php $safetyCompliance=(array)data_get($set->coverage,'safety_compliance',[]); @endphp
   @if(count((array)data_get($safetyCompliance,'findings',[])))
    <div class="mt-4 rounded border p-3" id="safetyCompliancePanel">
     <div class="flex flex-wrap items-center justify-between gap-2"><div><b class="text-sm">Safety & Compliance Vision</b><p class="text-[11px] opacity-60">Visible hazard observations only — no safety or compliance certification.</p></div><span class="rounded border px-2 py-1 text-xs">{{ ucwords(str_replace('_',' ',data_get($safetyCompliance,'routing_state','OBSERVATION_RECORDED'))) }}</span></div>
     @if(data_get($safetyCompliance,'requires_human_authority'))<div class="mt-2 rounded border p-2 text-xs"><b>Authorised human review required.</b> Regulated/high-consequence findings cannot be resolved by Vision authority.</div>@endif
     <div class="mt-2 space-y-2">@foreach((array)data_get($safetyCompliance,'findings',[]) as $hazard)<div class="rounded border p-2 text-xs"><div class="flex justify-between gap-2"><span><b>{{ ucwords(str_replace('_',' ',$hazard['hazard_key'] ?? 'visual_hazard')) }}</b> · {{ ucwords(str_replace('_',' ',$hazard['domain'] ?? 'general')) }}</span><span>{{ ucfirst($hazard['severity'] ?? 'review') }}</span></div><div class="mt-1">{{ $hazard['observation'] ?? '' }}</div>@if($hazard['regulated_domain'] ?? false)<div class="mt-1 opacity-60">Regulated domain · human/domain authority required</div>@endif</div>@endforeach</div>
    </div>
   @endif
   @php $quoteIntelligence=(array)data_get($set->coverage,'quote_intelligence',[]); @endphp
   @if($quoteIntelligence)
    <div class="mt-4 rounded border p-3"><div class="flex items-center justify-between gap-2"><b class="text-sm">Quote & Variation Intelligence</b><span class="text-xs opacity-60">Proposal only · pricing required</span></div>
     <div class="mt-2 grid gap-2 md:grid-cols-3 text-xs">
      <div><b>Scope / service candidates</b><div class="mt-1">{{ count((array)data_get($quoteIntelligence,'scope_candidates',[])) + count((array)data_get($quoteIntelligence,'service_candidates',[])) }}</div></div>
      <div><b>Material candidates</b><div class="mt-1">{{ count((array)data_get($quoteIntelligence,'material_candidates',[])) }}</div></div>
      <div><b>Missing measurements</b><div class="mt-1">{{ count((array)data_get($quoteIntelligence,'missing_measurements',[])) }}</div></div>
     </div>
     @if(count((array)data_get($quoteIntelligence,'missing_measurements',[])))<div class="mt-2 text-xs"><b>Measurements required before quoting:</b><ul class="mt-1 list-disc pl-5">@foreach((array)data_get($quoteIntelligence,'missing_measurements',[]) as $measurement)<li>{{ $measurement['label'] ?: $measurement['key'] }}@if(!empty($measurement['reason'])) — {{ $measurement['reason'] }}@endif</li>@endforeach</ul></div>@endif
     <p class="mt-2 text-[11px] opacity-60">{{ data_get($quoteIntelligence,'pricing_authority') }}</p>
    </div>
   @endif
   @if(count((array)data_get($assuranceData,'blockers',[])))<div class="mt-3 text-sm"><b>Blockers:</b> {{ implode(', ',array_map(fn($v)=>ucwords(str_replace('_',' ',$v)),(array)data_get($assuranceData,'blockers',[]))) }}</div>@endif
   @if(count((array)data_get($assuranceData,'warnings',[])))<div class="mt-2 text-xs opacity-70"><b>Warnings:</b> {{ implode(', ',array_map(fn($v)=>ucwords(str_replace('_',' ',$v)),(array)data_get($assuranceData,'warnings',[]))) }}</div>@endif
  </div>
  <div class="rounded-xl border p-4"><b>Before / After Comparisons</b><p class="mb-3 text-xs opacity-60">Pairing and comparability are evidence-quality signals, not proof of hidden condition.</p>
   @forelse($set->comparisons as $comparison)<div class="mb-2 rounded border p-2 text-sm"><div class="flex justify-between gap-2"><span>{{ ucwords(str_replace('_',' ',$comparison->pair_key)) }}</span><b>{{ round(((float)$comparison->comparability_score)*100) }}%</b></div><div class="text-xs opacity-60">{{ ucfirst($comparison->rating) }} · confidence {{ round(((float)$comparison->confidence_score)*100) }}%@if($comparison->requires_human_review) · review required@endif</div>@if($comparison->visible_change_summary)<div class="mt-1 text-xs">{{ $comparison->visible_change_summary }}</div>@endif</div>@empty<div class="text-sm opacity-60">No before/after comparison pairs recorded.</div>@endforelse
  </div>
 </div>
 <div class="grid gap-5 lg:grid-cols-2">
 @foreach($set->items as $item)
  <div class="rounded-xl border p-4">
   <div class="mb-3 flex justify-between gap-3"><div><b>{{ ucfirst($item->role) }}</b>@if(data_get($item->metadata,'capture_key'))<span class="ml-2 text-xs opacity-60">{{ ucwords(str_replace('_',' ',data_get($item->metadata,'capture_key'))) }}</span>@endif</div><span class="text-xs opacity-60">{{ $item->integrity_status }}</span></div>@php $qualityReport=(array)data_get($item->metadata,'quality_report',[]); @endphp
   @if($qualityReport)<div class="mb-3 rounded border p-2 text-xs"><div class="flex justify-between gap-2"><b>Capture quality</b><span>{{ round(((float)data_get($qualityReport,'quality_score',0))*100) }}%</span></div>@if(count((array)data_get($qualityReport,'issues',[])))<div class="mt-1 opacity-70">{{ implode(' · ',array_map(fn($v)=>ucwords(str_replace('_',' ',$v)),(array)data_get($qualityReport,'issues',[]))) }}</div>@else<div class="mt-1 opacity-70">No deterministic quality issues detected.</div>@endif</div>@endif
   @if(str_starts_with($item->source,'data:image/') || str_starts_with($item->source,'http'))
    <div class="relative overflow-hidden rounded-lg bg-black/5">
     <img src="{{ $item->source }}" class="block max-h-[560px] w-full object-contain" alt="Evidence image">
     <div class="pointer-events-none absolute inset-0">
      @foreach($item->annotations as $a)
       @if($a->shape === 'point' && is_numeric(data_get($a->geometry,'x')) && is_numeric(data_get($a->geometry,'y')))
        <div class="absolute h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-current" style="left:{{ ((float)data_get($a->geometry,'x'))/10 }}%;top:{{ ((float)data_get($a->geometry,'y'))/10 }}%" title="{{ $a->label }}"></div>
       @elseif($a->shape === 'polygon' && count((array)data_get($a->geometry,'points',[])) >= 3)
        @php $polygonPoints=implode(' ',array_map(fn($p)=>(((float)($p['x']??0))/10).','.(((float)($p['y']??0))/10),(array)data_get($a->geometry,'points',[]))); @endphp
        <svg class="absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none"><polygon points="{{ $polygonPoints }}" fill="currentColor" fill-opacity="0.12" stroke="currentColor" stroke-width="0.5" vector-effect="non-scaling-stroke" /></svg>
       @elseif(is_numeric($a->x) && is_numeric($a->y) && is_numeric($a->width) && is_numeric($a->height) && $a->width > 0 && $a->height > 0)
        @php
          $left=max(0,min(100,((float)$a->x)/10));$top=max(0,min(100,((float)$a->y)/10));
          $width=max(0,min(100-$left,((float)$a->width)/10));$height=max(0,min(100-$top,((float)$a->height)/10));
        @endphp
        <div class="vision-annotation-box absolute border-2 border-current" style="left:{{ $left }}%;top:{{ $top }}%;width:{{ $width }}%;height:{{ $height }}%"><span class="absolute left-0 top-0 max-w-[220px] -translate-y-full rounded bg-black/80 px-2 py-1 text-[11px] text-white">{{ $a->label }}</span></div>
       @endif
      @endforeach
     </div>
    </div>
   @else<div class="rounded bg-black/5 p-4 text-sm">{{ $item->source }}</div>@endif
   <div class="mt-4 space-y-3">
    @foreach($item->annotations as $a)
     <div class="rounded-lg border p-3" data-annotation-id="{{ $a->id }}">
      <div class="flex flex-wrap justify-between gap-2"><div><b>{{ $a->label }}</b><span class="ml-2 rounded px-2 py-0.5 text-xs opacity-70">{{ ucfirst($a->severity ?? 'review') }}</span></div><span>{{ round(($a->confidence ?? 0)*100) }}%</span></div><div class="mt-1 flex flex-wrap gap-2 text-[11px] opacity-60"><span>shape: {{ $a->shape }}</span>@if($a->region_key)<span>region_key: {{ $a->region_key }}</span>@endif @if($a->group_key)<span>group_key: {{ $a->group_key }}</span>@endif @if($a->parent_annotation_id)<span>parent_annotation_id: {{ $a->parent_annotation_id }}</span>@endif</div>
      <p class="mt-1 text-sm">{{ $a->reason }}</p>
      @if(data_get($a->metadata,'inference'))<p class="mt-2 text-xs opacity-70"><b>Inference:</b> {{ data_get($a->metadata,'inference') }}</p>@endif
      @if(data_get($a->metadata,'next_capture'))<p class="mt-2 text-xs"><b>Next capture:</b> {{ data_get($a->metadata,'next_capture') }}</p>@endif
      <div class="mt-3 flex flex-wrap items-center gap-2">
       <span class="text-xs">Review: <b class="human_status">{{ ucfirst(str_replace('_',' ',$a->human_status ?? 'pending')) }}</b></span>
       <button type="button" class="btn btn-sm btn-outline-secondary annotation-review" data-status="confirmed" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/annotations/'.$a->id.'/review') }}">Confirm</button>
       <button type="button" class="btn btn-sm btn-outline-secondary annotation-review" data-status="rejected" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/annotations/'.$a->id.'/review') }}">Reject</button>
       <button type="button" class="btn btn-sm btn-outline-secondary annotation-review" data-status="needs_more_evidence" data-url="{{ url('/dashboard/user/titan-ai-vision/evidence/'.$set->id.'/annotations/'.$a->id.'/review') }}">Need More Evidence</button>
      </div>
     </div>
    @endforeach
   </div>
  </div>
 @endforeach
 </div>
 <div class="mt-6 rounded-xl border p-5"><h2 class="mb-3 text-lg font-bold">Route findings</h2><p class="mb-3 text-sm opacity-70">Routing uses Titan's governed action layer where available. Vision itself does not silently mutate business records.</p><div class="flex flex-wrap gap-2" id="visionRoutes">@foreach(['job_note'=>'Add to Job Notes','quote_scope'=>'Prepare Quote Scope','asset_update'=>'Update Asset','safety_review'=>'Safety Review','damage_follow_up'=>'Follow-up Work','completion_assurance'=>'Completion Assurance'] as $key=>$label)<button class="btn btn-outline-secondary vision-route" data-destination="{{ $key }}">{{ $label }}</button>@endforeach</div><div id="routeStatus" class="mt-3 text-sm"></div></div>
</div>
@endsection
@push('script')
<script>
(function(){
 const csrf='{{ csrf_token() }}';
 const verifyBaselineButton=document.getElementById('verifyBaselineButton');
 if(verifyBaselineButton){verifyBaselineButton.addEventListener('click',async function(){verifyBaselineButton.disabled=true;try{const res=await fetch(verifyBaselineButton.dataset.url,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'},body:JSON.stringify({})});const data=await res.json();if(!res.ok||!data.success)throw new Error(data.message||'Baseline verification failed');document.getElementById('continuityStatus').textContent='Verified';verifyBaselineButton.remove();}catch(e){alert(e.message||'Baseline verification failed');verifyBaselineButton.disabled=false;}});}
 document.querySelectorAll('.annotation-review').forEach(function(btn){btn.addEventListener('click',async function(){const card=btn.closest('[data-annotation-id]');btn.disabled=true;try{const res=await fetch(btn.dataset.url,{method:'PATCH',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'},body:JSON.stringify({human_status:btn.dataset.status})});const data=await res.json();if(!res.ok||!data.success)throw new Error(data.message||'Review update failed');const label=String(data.human_status||'').replaceAll('_',' ');card.querySelector('.human_status').textContent=label.charAt(0).toUpperCase()+label.slice(1);}catch(e){alert(e.message||'Review update failed');}finally{btn.disabled=false;}});});
 document.querySelectorAll('.change-review').forEach(function(btn){btn.addEventListener('click',async function(){const card=btn.closest('[data-change-id]');btn.disabled=true;try{const res=await fetch(btn.dataset.url,{method:'PATCH',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'},body:JSON.stringify({human_status:btn.dataset.status})});const data=await res.json();if(!res.ok||!data.success)throw new Error(data.message||'Change review failed');const label=String(data.human_status||'').replaceAll('_',' ');card.querySelector('.change_human_status').textContent=label.charAt(0).toUpperCase()+label.slice(1);}catch(e){alert(e.message||'Change review failed');}finally{btn.disabled=false;}});});
 document.querySelectorAll('.vision-route').forEach(function(btn){btn.addEventListener('click',async function(){const res=await fetch('{{ route("dashboard.user.titan-ai-vision.evidence.route",$set->id) }}',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'},body:JSON.stringify({destination:btn.dataset.destination})});const data=await res.json();document.getElementById('routeStatus').textContent=data.message||data.status||'Saved';});});
})();
</script>
@endpush
