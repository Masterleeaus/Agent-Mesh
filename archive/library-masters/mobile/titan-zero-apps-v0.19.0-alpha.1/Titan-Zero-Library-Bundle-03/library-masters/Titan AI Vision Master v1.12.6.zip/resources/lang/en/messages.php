<?php
return ['name'=>'Titan AI Vision','description'=>'Evidence-first field-service visual intelligence.'];
