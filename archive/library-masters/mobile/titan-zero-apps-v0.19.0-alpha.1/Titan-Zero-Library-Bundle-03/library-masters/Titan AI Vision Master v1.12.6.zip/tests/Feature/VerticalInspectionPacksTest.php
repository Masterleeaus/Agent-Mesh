<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$registry=$root.'/System/Services/VerticalInspectionPackRegistry.php';
$prompt=file_get_contents($root.'/System/Services/VisionPromptBuilder.php');
$checklist=file_get_contents($root.'/System/Services/EvidenceChecklistService.php');
$assurance=file_get_contents($root.'/System/Services/InspectionProfileRegistry.php');
if(!is_file($registry)){fwrite(STDERR,"Missing vertical inspection pack registry\n");exit(1);}
require_once $registry;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\VerticalInspectionPackRegistry';
$r=new $cls();
$required=['cleaning','plumbing','electrical','hvac','roofing_guttering','landscaping','pest_control','locksmith_security','pool_spa','solar','appliance_repair','property_maintenance','arborist','pressure_washing','facilities_maintenance'];
foreach($required as $key){
    $pack=$r->get($key);
    foreach(['captures','finding_taxonomy','prohibited_conclusions','risk_classes','workflow_routes','completion_rules'] as $field){
        if(empty($pack[$field])){fwrite(STDERR,"$key missing $field\n");exit(1);}
    }
}
if(!in_array('electrical_safety_certified',$r->get('electrical')['prohibited_conclusions'],true)){fwrite(STDERR,"Electrical prohibited conclusion missing\n");exit(1);}
if(!in_array('hidden_leak_path_confirmed',$r->get('plumbing')['prohibited_conclusions'],true)){fwrite(STDERR,"Plumbing hidden-state prohibition missing\n");exit(1);}
if(strpos($prompt,'PROHIBITED CONCLUSIONS')===false || strpos($prompt,'FINDING TAXONOMY')===false){fwrite(STDERR,"Prompt does not consume vertical packs\n");exit(1);}
if(strpos($checklist,'VerticalInspectionPackRegistry')===false){fwrite(STDERR,"Checklist not driven by vertical pack\n");exit(1);}
if(strpos($assurance,'completion_rules')===false){fwrite(STDERR,"Assurance does not consume pack completion rules\n");exit(1);}
echo "vertical inspection packs ok\n";
