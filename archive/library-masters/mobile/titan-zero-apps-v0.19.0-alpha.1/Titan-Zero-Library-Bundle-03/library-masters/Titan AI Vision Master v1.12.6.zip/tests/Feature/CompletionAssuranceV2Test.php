<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$file=$root.'/System/Services/CompletionAssuranceV2Service.php';
if(!is_file($file)){fwrite(STDERR,"Missing CompletionAssuranceV2Service\n");exit(1);}
require_once $file;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\CompletionAssuranceV2Service';
$svc=new $cls();

$ready=$svc->evaluate(
 ['eligible_for_assurance'=>true,'blockers'=>[],'warnings'=>[],'evidence_score'=>0.91],
 [['key'=>'replace_valve','status'=>'supported'],['key'=>'test_operation','status'=>'supported']],
 [],
 []
);
if($ready['state']!=='READY_FOR_ASSURANCE'){fwrite(STDERR,"Expected READY_FOR_ASSURANCE\n");exit(1);}

$missing=$svc->evaluate(
 ['eligible_for_assurance'=>false,'blockers'=>['missing_required_evidence'],'warnings'=>[]],
 [['key'=>'replace_valve','status'=>'supported']],
 [],
 []
);
if($missing['state']!=='MORE_EVIDENCE_REQUIRED'){fwrite(STDERR,"Expected MORE_EVIDENCE_REQUIRED\n");exit(1);}

$variation=$svc->evaluate(
 ['eligible_for_assurance'=>true,'blockers'=>[],'warnings'=>[]],
 [['key'=>'replace_valve','status'=>'supported']],
 [['key'=>'extra_pipework','approval_status'=>'pending']],
 []
);
if($variation['state']!=='BLOCKED_BY_VARIATION'){fwrite(STDERR,"Expected BLOCKED_BY_VARIATION\n");exit(1);}

$open=$svc->evaluate(
 ['eligible_for_assurance'=>true,'blockers'=>[],'warnings'=>[]],
 [['key'=>'replace_valve','status'=>'supported']],
 [],
 [['severity'=>'high','human_status'=>'pending']]
);
if($open['state']!=='BLOCKED_BY_OPEN_FINDING'){fwrite(STDERR,"Expected BLOCKED_BY_OPEN_FINDING\n");exit(1);}

$scope=$svc->evaluate(
 ['eligible_for_assurance'=>true,'blockers'=>[],'warnings'=>[]],
 [['key'=>'replace_valve','status'=>'unsupported']],
 [],
 []
);
if($scope['state']!=='REVIEW_REQUIRED'){fwrite(STDERR,"Expected REVIEW_REQUIRED for unsupported scope\n");exit(1);}

$router=file_get_contents($root.'/System/Services/VisionWorkflowRouter.php');
if(strpos($router,'READY_FOR_ASSURANCE')===false){fwrite(STDERR,"Router does not enforce v2 state\n");exit(1);}
$parser=file_get_contents($root.'/System/Services/VisionFindingParser.php');
foreach(['scope_evidence','variation_candidates'] as $needle){if(strpos($parser,$needle)===false){fwrite(STDERR,"Parser missing $needle\n");exit(1);}}
echo "completion assurance v2 ok\n";
