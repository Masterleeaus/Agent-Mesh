<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$file=$root.'/System/Services/SafetyCompliancePolicyService.php';
if(!is_file($file)){fwrite(STDERR,"Missing SafetyCompliancePolicyService\n");exit(1);}
require_once $file;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\SafetyCompliancePolicyService';
$svc=new $cls();

$pkg=$svc->evaluate([
 ['hazard_key'=>'exposed_conductor','domain'=>'electrical','severity'=>'high','confidence'=>0.91,'observation'=>'Visible exposed conductor','human_status'=>'pending'],
 ['hazard_key'=>'trip_hazard','domain'=>'general','severity'=>'medium','confidence'=>0.80,'observation'=>'Visible obstruction in walkway','human_status'=>'confirmed'],
]);
if(($pkg['requires_human_authority']??false)!==true){fwrite(STDERR,"Regulated/high-risk finding must require human authority\n");exit(1);}
if(($pkg['certification_allowed']??true)!==false){fwrite(STDERR,"Vision must never certify safety/compliance\n");exit(1);}
if(!in_array('electrical',$pkg['regulated_domains']??[],true)){fwrite(STDERR,"Electrical domain should be regulated\n");exit(1);}
if(($pkg['routing_state']??'')!=='SAFETY_REVIEW_REQUIRED'){fwrite(STDERR,"Expected safety review route\n");exit(1);}

$low=$svc->evaluate([
 ['hazard_key'=>'minor_obstruction','domain'=>'general','severity'=>'low','confidence'=>0.92,'observation'=>'Small visible obstruction','human_status'=>'confirmed'],
]);
if(($low['routing_state']??'')!=='OBSERVATION_RECORDED'){fwrite(STDERR,"Low confirmed general observation should remain observation-only\n");exit(1);}

$parser=file_get_contents($root.'/System/Services/VisionFindingParser.php');
foreach(['safety_findings','hazard_key','regulated_domain'] as $needle){if(strpos($parser,$needle)===false){fwrite(STDERR,"Parser missing $needle\n");exit(1);}}
$prompt=file_get_contents($root.'/System/Services/VisionPromptBuilder.php');
foreach(['SAFETY / COMPLIANCE AUTHORITY BOUNDARY','Never certify electrical safety','Never certify structural safety','Never certify gas safety','Never certify chemical safety','Never certify regulatory compliance'] as $needle){if(strpos($prompt,$needle)===false){fwrite(STDERR,"Prompt missing safety boundary: $needle\n");exit(1);}}
$router=file_get_contents($root.'/System/Services/VisionWorkflowRouter.php');
if(strpos($router,'safety_compliance')===false || strpos($router,'requires_human_authority')===false){fwrite(STDERR,"Safety package not routed\n");exit(1);}
echo "safety compliance vision ok\n";
