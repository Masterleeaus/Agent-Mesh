<?php
$root=dirname(__DIR__,2);
$view=file_get_contents($root.'/resources/views/index.blade.php');
$routes=file_get_contents($root.'/routes/user.php');
assert(str_contains($view,'visionPreviewGrid'));
assert(str_contains($view,'capture_key'));
assert(str_contains($view,'visionChecklist'));
assert(str_contains($routes,"'/checklist'"));
echo "MobileCaptureTest OK\n";
