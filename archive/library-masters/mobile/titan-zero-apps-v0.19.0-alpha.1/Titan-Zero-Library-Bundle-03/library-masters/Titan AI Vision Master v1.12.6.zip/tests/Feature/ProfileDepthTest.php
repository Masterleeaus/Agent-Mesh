<?php
$root=dirname(__DIR__,2);
$file=file_get_contents($root.'/System/Services/InspectionProfileRegistry.php');
foreach(['locksmith_security','handyman_property_maintenance','pressure_washing','waste_removal','window_cleaning','carpet_upholstery','arborist','security_systems','ndis_home_maintenance','facilities_maintenance'] as $key)assert(str_contains($file,"'{$key}'"));
echo "ProfileDepthTest OK\n";
