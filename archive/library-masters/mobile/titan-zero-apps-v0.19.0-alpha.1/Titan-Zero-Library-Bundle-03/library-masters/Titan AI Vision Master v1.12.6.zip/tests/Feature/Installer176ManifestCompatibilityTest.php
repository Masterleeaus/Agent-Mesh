<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$data=json_decode(file_get_contents($root.'/extension.json'),true,512,JSON_THROW_ON_ERROR);
foreach(['name','type','version','description','slug','folder','provider'] as $key){
    if(!isset($data[$key]) || !is_string($data[$key]) || trim($data[$key])===''){
        fwrite(STDERR,"Missing valid extension.json field: {$key}\n");exit(1);
    }
}
if($data['type']!=='extension'){fwrite(STDERR,"Installer 1.7.6 type must be extension\n");exit(1);}
if($data['name']!=='Titan AI Vision'){fwrite(STDERR,"Unexpected extension name\n");exit(1);}
echo "installer 1.7.6 manifest compatibility ok\n";
