<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$policy=$root.'/System/Services/EvidenceQualityPolicyService.php';
$analyser=$root.'/System/Services/EvidenceQualityAnalyzerService.php';
$controller=file_get_contents($root.'/System/Http/Controllers/VisionController.php');
$routes=file_get_contents($root.'/routes/user.php');
$view=file_get_contents($root.'/resources/views/index.blade.php');
$evidence=file_get_contents($root.'/System/Services/VisionEvidenceService.php');
if(!is_file($policy)||!is_file($analyser)){fwrite(STDERR,"Missing evidence quality services\n");exit(1);}
require_once $policy;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\EvidenceQualityPolicyService';
$p=new $cls();
$bad=$p->evaluate(['width'=>320,'height'=>240,'mean_luminance'=>0.03,'highlight_ratio'=>0.0,'sharpness'=>0.08,'subject_coverage'=>0.10,'has_scale_reference'=>false],false);
foreach(['low_resolution','too_dark','blurry','subject_too_small'] as $issue){if(!in_array($issue,$bad['issues'],true)){fwrite(STDERR,"Expected issue $issue\n");exit(1);}}
$good=$p->evaluate(['width'=>1600,'height'=>1200,'mean_luminance'=>0.52,'highlight_ratio'=>0.01,'sharpness'=>0.72,'subject_coverage'=>0.55,'has_scale_reference'=>true],false);
if(!$good['acceptable']||$good['issues']!==[]){fwrite(STDERR,"Good image should be acceptable\n");exit(1);}

require_once $analyser;
$analyserCls='App\\Extensions\\TitanAIVision\\System\\Services\\EvidenceQualityAnalyzerService';
$a=new $analyserCls($p);
$png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZlmcAAAAASUVORK5CYII=';
$preflight=$a->analyse([$png,$png],['overview','detail']);
if(($preflight['ready_for_inference']??true)!==false){fwrite(STDERR,"Tiny evidence should not be inference-ready\n");exit(1);}
if(!in_array('duplicate',$preflight['reports'][1]['issues']??[],true)){fwrite(STDERR,"Duplicate evidence should be detected\n");exit(1);}

if(strpos($controller,'preflight')===false||strpos($routes,'/preflight')===false){fwrite(STDERR,"Missing preflight endpoint\n");exit(1);}
foreach(['visionQuality','Retake guidance','quality_reports'] as $needle){if(strpos($view,$needle)===false){fwrite(STDERR,"Capture UI missing $needle\n");exit(1);}}
if(strpos($evidence,'quality_reports')===false){fwrite(STDERR,"Quality reports are not persisted\n");exit(1);}
echo "evidence quality capture guidance ok\n";
