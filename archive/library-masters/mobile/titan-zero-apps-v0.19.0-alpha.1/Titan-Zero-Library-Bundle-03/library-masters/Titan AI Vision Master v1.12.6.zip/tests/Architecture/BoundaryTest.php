<?php
$root=dirname(__DIR__,2);$provider=$root.'/System/TitanAIVisionServiceProvider.php';assert(is_file($provider));assert(str_contains(file_get_contents($provider),'registerKey'));assert(is_file($root.'/extension.manifest.json'));echo "BoundaryTest OK\n";
