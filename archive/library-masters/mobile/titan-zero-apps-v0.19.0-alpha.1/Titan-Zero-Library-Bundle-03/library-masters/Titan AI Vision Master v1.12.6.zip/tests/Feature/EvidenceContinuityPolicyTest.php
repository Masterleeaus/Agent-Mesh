<?php
require_once __DIR__.'/../../System/Services/EvidenceContinuityPolicyService.php';
use App\Extensions\TitanAIVision\System\Services\EvidenceContinuityPolicyService;

$svc=new EvidenceContinuityPolicyService();

$assetKey=$svc->continuityKey(['asset_id'=>'asset-7','property_id'=>'property-1','area_key'=>'Kitchen Sink']);
if($assetKey!=='asset:asset-7') throw new RuntimeException('Asset identity must take continuity precedence');

$propertyKey=$svc->continuityKey(['property_id'=>'property-1','area_key'=>'Kitchen Sink']);
if($propertyKey!=='property:property-1:area:kitchen-sink') throw new RuntimeException('Property area continuity key mismatch');

if($svc->continuityKey(['job_id'=>'job-1'])!==null) throw new RuntimeException('Job-only context must not create longitudinal continuity');

$trusted=[
    'status'=>'analysed',
    'verification_status'=>'verified',
    'items_count'=>3,
    'unavailable_integrity_count'=>0,
    'review'=>['pending'=>0,'rejected'=>0,'needs_more_evidence'=>0],
    'missing_capture_keys'=>[],
];
if(!$svc->canBeBaseline($trusted)) throw new RuntimeException('Verified reviewed evidence should be baseline eligible');

foreach([
    array_merge($trusted,['verification_status'=>'unverified']),
    array_merge($trusted,['status'=>'analysing']),
    array_merge($trusted,['items_count'=>0]),
    array_merge($trusted,['unavailable_integrity_count'=>1]),
    array_merge($trusted,['review'=>['pending'=>1,'rejected'=>0,'needs_more_evidence'=>0]]),
    array_merge($trusted,['review'=>['pending'=>0,'rejected'=>1,'needs_more_evidence'=>0]]),
    array_merge($trusted,['missing_capture_keys'=>['completed_work']]),
] as $case){
    if($svc->canBeBaseline($case)) throw new RuntimeException('Untrusted evidence incorrectly accepted as baseline');
}

echo "evidence-continuity-policy: OK\n";
