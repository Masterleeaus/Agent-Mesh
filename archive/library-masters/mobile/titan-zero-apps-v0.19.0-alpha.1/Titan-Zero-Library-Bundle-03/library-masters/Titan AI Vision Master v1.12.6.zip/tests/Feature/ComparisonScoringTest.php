<?php
require_once __DIR__.'/../../System/Services/VisionComparisonScoringService.php';
use App\Extensions\TitanAIVision\System\Services\VisionComparisonScoringService;
$svc=new VisionComparisonScoringService();
$result=$svc->score(['framing'=>0.9,'angle'=>0.8,'lighting'=>0.7,'coverage'=>1.0],0.9);
if(abs($result['comparability_score']-0.85)>0.001) throw new RuntimeException('Unexpected weighted comparability score');
if($result['confidence_score']!==0.9) throw new RuntimeException('Confidence not preserved');
if($result['rating']!=='strong') throw new RuntimeException('Expected strong rating');
echo "comparison-scoring: OK\n";
