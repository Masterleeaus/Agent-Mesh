<?php
require_once __DIR__.'/../../System/Services/VisionChangeDetectionPolicyService.php';
use App\Extensions\TitanAIVision\System\Services\VisionChangeDetectionPolicyService;

$svc=new VisionChangeDetectionPolicyService();

$base=['comparability_score'=>0.91,'baseline_present'=>true,'current_present'=>true,'baseline_severity'=>'medium','current_severity'=>'medium','confidence'=>0.9,'evidence_complete'=>true];
if($svc->classify($base)['change_type']!=='unchanged') throw new RuntimeException('Equal severity should classify unchanged');
if($svc->classify(array_merge($base,['current_severity'=>'high']))['change_type']!=='worsened') throw new RuntimeException('Higher current severity should classify worsened');
if($svc->classify(array_merge($base,['baseline_severity'=>'high','current_severity'=>'medium']))['change_type']!=='improved') throw new RuntimeException('Lower current severity should classify improved');
if($svc->classify(array_merge($base,['baseline_present'=>false]))['change_type']!=='new') throw new RuntimeException('Current-only finding should classify new');
if($svc->classify(array_merge($base,['current_present'=>false]))['change_type']!=='resolved') throw new RuntimeException('Baseline-only finding with complete comparable evidence should classify resolved');
if($svc->classify(array_merge($base,['current_present'=>false,'evidence_complete'=>false]))['change_type']!=='uncertain') throw new RuntimeException('Missing current finding without complete evidence must stay uncertain');
if($svc->classify(array_merge($base,['comparability_score'=>0.35]))['change_type']!=='not_comparable') throw new RuntimeException('Low comparability must classify not_comparable');
if($svc->classify(array_merge($base,['confidence'=>0.2]))['change_type']!=='uncertain') throw new RuntimeException('Low confidence must classify uncertain');

foreach(['new','resolved','improved','worsened','unchanged','uncertain','not_comparable'] as $type){
    if(!$svc->isCanonical($type)) throw new RuntimeException('Missing canonical type '.$type);
}

echo "change-detection-policy: OK\n";
