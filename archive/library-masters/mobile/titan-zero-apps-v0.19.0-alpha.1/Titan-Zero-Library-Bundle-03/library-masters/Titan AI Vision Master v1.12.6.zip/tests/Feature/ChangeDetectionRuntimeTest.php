<?php
$root=dirname(__DIR__,2);
foreach([
    $root.'/System/Services/VisionChangeDetectionService.php',
    $root.'/System/Services/VisionChangeDetectionPromptBuilder.php',
    $root.'/System/Models/TitanVisionChange.php',
    $root.'/database/migrations/2026_08_19_010001_create_titan_vision_changes.php',
] as $file){if(!is_file($file)) throw new RuntimeException('Missing change detection runtime file: '.$file);}

$evidence=file_get_contents($root.'/System/Services/VisionEvidenceService.php');
if(!str_contains($evidence,'changeDetection->detect')) throw new RuntimeException('Finding persistence must invoke longitudinal change detection');

$set=file_get_contents($root.'/System/Models/TitanVisionEvidenceSet.php');
if(!str_contains($set,'changes()')) throw new RuntimeException('Evidence sets must expose change history');

$timeline=file_get_contents($root.'/System/Services/EvidenceTimelineService.php');
if(!str_contains($timeline,'change_summary')) throw new RuntimeException('Timeline must expose change summary');

$prompt=file_get_contents($root.'/System/Services/VisionChangeDetectionPromptBuilder.php');
foreach(['new','resolved','improved','worsened','unchanged','uncertain','not_comparable'] as $type){
    if(!str_contains($prompt,$type)) throw new RuntimeException('Change prompt must define '.$type);
}

$service=file_get_contents($root.'/System/Services/VisionChangeDetectionService.php');
if(!str_contains($service,'previousVerifiedBaseline')) throw new RuntimeException('Change detection must use only the explicitly verified baseline relationship');
if(!str_contains($service,'requires_human_review')) throw new RuntimeException('Change records must remain reviewable');

echo "change-detection-runtime: OK\n";
