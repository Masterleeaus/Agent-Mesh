<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$parser=file_get_contents($root.'/System/Services/VisionFindingParser.php');
$service=file_get_contents($root.'/System/Services/VisionEvidenceService.php');
$annotation=file_get_contents($root.'/System/Models/TitanVisionAnnotation.php');
$migration=glob($root.'/database/migrations/*spatial*');
$view=file_get_contents($root.'/resources/views/evidence.blade.php');
$needles=[
 'regions', 'polygon', 'point', 'parent_key', 'group_key', 'region_key',
];
foreach($needles as $needle){if(strpos($parser,$needle)===false){fwrite(STDERR,"Missing parser spatial contract: $needle\n");exit(1);}}
if(strpos($service,'persistRegions')===false){fwrite(STDERR,"Missing region persistence\n");exit(1);}
if(strpos($annotation,"geometry")===false || strpos($annotation,'parent_annotation_id')===false){fwrite(STDERR,"Missing annotation hierarchy support\n");exit(1);}
if(!$migration){fwrite(STDERR,"Missing spatial migration\n");exit(1);}
foreach(['polygon','point','group_key','parent_annotation_id'] as $needle){if(strpos($view,$needle)===false){fwrite(STDERR,"Evidence UI missing $needle\n");exit(1);}}
echo "advanced spatial inspection contract ok\n";
