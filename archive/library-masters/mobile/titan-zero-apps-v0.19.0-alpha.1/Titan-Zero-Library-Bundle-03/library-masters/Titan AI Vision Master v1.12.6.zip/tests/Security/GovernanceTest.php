<?php
$root=dirname(__DIR__,2);$router=file_get_contents($root.'/System/Services/VisionWorkflowRouter.php');assert(str_contains($router,'titan.assist.action-executor'));assert(str_contains($router,'titan.assurance.guard'));assert(str_contains($router,"'completion_assurance'"));assert(!str_contains($router,"execute('crm.job.complete'"));echo "GovernanceTest OK\n";
