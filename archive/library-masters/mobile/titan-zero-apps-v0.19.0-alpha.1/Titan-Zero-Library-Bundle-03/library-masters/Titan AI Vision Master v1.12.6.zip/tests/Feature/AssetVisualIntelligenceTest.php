<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$policy=$root.'/System/Services/AssetVisualIdentityPolicyService.php';
$passport=$root.'/System/Services/AssetVisualPassportService.php';
$prompt=file_get_contents($root.'/System/Services/VisionPromptBuilder.php');
$parser=file_get_contents($root.'/System/Services/VisionFindingParser.php');
$controller=file_get_contents($root.'/System/Http/Controllers/VisionController.php');
$routes=file_get_contents($root.'/routes/user.php');
$profile=file_get_contents($root.'/System/Services/InspectionProfileRegistry.php');
if(!is_file($policy)||!is_file($passport)){fwrite(STDERR,"Missing asset visual intelligence services\n");exit(1);}
require_once $policy;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\AssetVisualIdentityPolicyService';
$p=new $cls();
$exact=$p->compare(['manufacturer'=>'Daikin','model'=>'RXM50','serial'=>'ABC-123'],['manufacturer'=>'DAIKIN','model'=>'rxm50','serial'=>'abc123']);
if(($exact['match_type']??null)!=='exact_serial'||($exact['requires_human_confirmation']??false)!==true){fwrite(STDERR,"Exact serial match must remain reviewable\n");exit(1);}
$probable=$p->compare(['manufacturer'=>'Daikin','model'=>'RXM50','serial'=>null],['manufacturer'=>'daikin','model'=>'RXM50','serial'=>null]);
if(($probable['match_type']??null)!=='manufacturer_model'){fwrite(STDERR,"Manufacturer/model candidate not detected\n");exit(1);}
$none=$p->compare(['manufacturer'=>'Daikin','model'=>'RXM50','serial'=>'A1'],['manufacturer'=>'Mitsubishi','model'=>'MSZ','serial'=>'B2']);
if(($none['match_type']??null)!=='no_match'){fwrite(STDERR,"Conflicting identity should not match\n");exit(1);}
foreach(['asset_identity','nameplate_image_index','condition_summary','condition_severity'] as $needle){if(strpos($prompt,$needle)===false||strpos($parser,$needle)===false){fwrite(STDERR,"Missing asset structured contract: $needle\n");exit(1);}}
foreach(['assetPassports','verifyAssetIdentity','reviewAssetCandidate'] as $needle){if(strpos($controller,$needle)===false){fwrite(STDERR,"Missing asset controller function: $needle\n");exit(1);}}
foreach(['/assets/passports','verify-identity','identity-candidates'] as $needle){if(strpos($routes,$needle)===false){fwrite(STDERR,"Missing asset route: $needle\n");exit(1);}}
foreach(['nameplate','asset_visual_passport'] as $needle){if(strpos($profile,$needle)===false){fwrite(STDERR,"Missing asset capture/profile support: $needle\n");exit(1);}}
$passportSource=file_get_contents($passport);foreach(['possible_duplicate','designated nameplate or identifier evidence capture','conditionTrend'] as $needle){if(strpos($passportSource,$needle)===false){fwrite(STDERR,"Asset trust boundary missing: $needle\n");exit(1);}}
$migrations=glob($root.'/database/migrations/*asset_visual*');if(!$migrations){fwrite(STDERR,"Missing asset visual persistence migration\n");exit(1);}
echo "asset visual intelligence ok\n";
