<?php
require_once __DIR__.'/../../System/Services/CompletionAssuranceRuleService.php';
use App\Extensions\TitanAIVision\System\Services\CompletionAssuranceRuleService;
$svc=new CompletionAssuranceRuleService();
$ready=$svc->evaluate(
 ['minimum_capture_coverage'=>1.0,'minimum_confirmed_ratio'=>0.75,'minimum_comparison_score'=>0.70,'always_human_review'=>false],
 ['required'=>4,'satisfied'=>4,'missing'=>[]],
 ['total'=>4,'confirmed'=>3,'rejected'=>0,'needs_more_evidence'=>0,'pending'=>1],
 ['required'=>true,'pairs'=>2,'minimum_score'=>0.82]
);
if(!$ready['eligible_for_assurance']) throw new RuntimeException('Expected assurance eligibility');
$blocked=$svc->evaluate(
 ['minimum_capture_coverage'=>1.0,'minimum_confirmed_ratio'=>0.75,'minimum_comparison_score'=>0.70,'always_human_review'=>true],
 ['required'=>4,'satisfied'=>3,'missing'=>['completed_work']],
 ['total'=>4,'confirmed'=>2,'rejected'=>1,'needs_more_evidence'=>1,'pending'=>0],
 ['required'=>true,'pairs'=>1,'minimum_score'=>0.55]
);
if($blocked['eligible_for_assurance']) throw new RuntimeException('Expected blocked assurance package');
if(!in_array('missing_required_evidence',$blocked['blockers'],true)) throw new RuntimeException('Missing capture blocker expected');
if(!in_array('finding_rejected',$blocked['blockers'],true)) throw new RuntimeException('Rejected finding blocker expected');
echo "completion-assurance-rules: OK\n";
