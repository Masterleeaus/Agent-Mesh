<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$file=$root.'/System/Services/QuoteVariationIntelligenceService.php';
if(!is_file($file)){fwrite(STDERR,"Missing QuoteVariationIntelligenceService\n");exit(1);}
require_once $file;
$cls='App\\Extensions\\TitanAIVision\\System\\Services\\QuoteVariationIntelligenceService';
$svc=new $cls();
$package=$svc->build(
 [['key'=>'replace_valve','label'=>'Replace inlet valve','status'=>'supported','confidence'=>0.91,'evidence_image_indexes'=>[0,1],'reason'=>'completed valve visible']],
 [['key'=>'corroded_outlet','label'=>'Corroded outlet connection','approval_status'=>'pending','confidence'=>0.82,'evidence_image_indexes'=>[2],'reason'=>'visible corrosion']],
 [['key'=>'measure_pipe','label'=>'Pipe length','required_for'=>'material_quantity']],
 [['key'=>'replace_valve','label'=>'Valve replacement','candidate_type'=>'service','confidence'=>0.88,'evidence_image_indexes'=>[0,1]],
  ['key'=>'outlet_fitting','label'=>'Outlet fitting','candidate_type'=>'material','confidence'=>0.72,'evidence_image_indexes'=>[2]]]
);
if(($package['requires_pricing']??false)!==true){fwrite(STDERR,"Quote package must require authoritative pricing\n");exit(1);}
if(isset($package['price'])||isset($package['total'])||isset($package['amount'])){fwrite(STDERR,"Vision quote package must not contain price fields\n");exit(1);}
if(count($package['scope_candidates']??[])<1||count($package['material_candidates']??[])<1||count($package['service_candidates']??[])<1){fwrite(STDERR,"Candidate split missing\n");exit(1);}
if(count($package['missing_measurements']??[])!==1){fwrite(STDERR,"Missing measurement not preserved\n");exit(1);}
if(count($package['variation_proposals']??[])!==1){fwrite(STDERR,"Variation proposal missing\n");exit(1);}
$parser=file_get_contents($root.'/System/Services/VisionFindingParser.php');
foreach(['quote_candidates','missing_measurements'] as $needle){if(strpos($parser,$needle)===false){fwrite(STDERR,"Parser missing $needle\n");exit(1);}}
$router=file_get_contents($root.'/System/Services/VisionWorkflowRouter.php');
foreach(['quote_intelligence','requires_pricing'] as $needle){if(strpos($router,$needle)===false){fwrite(STDERR,"Router missing $needle\n");exit(1);}}
echo "quote variation intelligence ok\n";
