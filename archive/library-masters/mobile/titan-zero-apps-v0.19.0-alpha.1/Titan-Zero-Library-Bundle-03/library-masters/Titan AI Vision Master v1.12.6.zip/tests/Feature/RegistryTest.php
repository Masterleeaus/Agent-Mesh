<?php
$mode=file_get_contents(dirname(__DIR__,2).'/System/Services/VisionModeRegistry.php');foreach(['job_check','before_after','site_inspection','equipment_scan','damage_assessment','safety_evidence','parts_recognition','completion_assurance'] as $key)assert(str_contains($mode,$key));echo "RegistryTest OK\n";
