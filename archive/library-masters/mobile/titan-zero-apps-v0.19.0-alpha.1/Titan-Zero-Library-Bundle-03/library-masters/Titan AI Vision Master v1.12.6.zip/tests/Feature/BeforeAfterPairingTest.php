<?php
require_once __DIR__.'/../../System/Services/BeforeAfterPairingService.php';
use App\Extensions\TitanAIVision\System\Services\BeforeAfterPairingService;
$svc=new BeforeAfterPairingService();
$items=[
 ['id'=>1,'role'=>'before','metadata'=>['capture_key'=>'area_wide','pair_key'=>'kitchen']],
 ['id'=>2,'role'=>'after','metadata'=>['capture_key'=>'area_wide','pair_key'=>'kitchen']],
 ['id'=>3,'role'=>'before','metadata'=>['capture_key'=>'detail','pair_key'=>'sink']],
 ['id'=>4,'role'=>'after','metadata'=>['capture_key'=>'detail','pair_key'=>'sink']],
];
$pairs=$svc->pair($items);
if(count($pairs)!==2) throw new RuntimeException('Expected two before/after pairs');
if($pairs[0]['before_id']!==1 || $pairs[0]['after_id']!==2) throw new RuntimeException('Kitchen pair mismatch');
if($pairs[1]['pair_key']!=='sink') throw new RuntimeException('Sink pair key missing');
echo "before-after-pairing: OK\n";
