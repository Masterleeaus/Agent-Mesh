<?php
$root=dirname(__DIR__,2);
$required=[
    $root.'/System/Services/EvidenceContinuityService.php',
    $root.'/System/Models/TitanVisionEvidenceLineage.php',
    $root.'/database/migrations/2026_08_19_004001_add_longitudinal_evidence_continuity.php',
];
foreach($required as $file){if(!is_file($file)) throw new RuntimeException('Missing continuity runtime file: '.$file);}

$model=file_get_contents($root.'/System/Models/TitanVisionEvidenceSet.php');
if(!str_contains($model,'verification_status')) throw new RuntimeException('Evidence set model must expose verification status');
if(!str_contains($model,'previousVerifiedBaseline')) throw new RuntimeException('Evidence set model must expose prior verified baseline');

$evidence=file_get_contents($root.'/System/Services/VisionEvidenceService.php');
if(!str_contains($evidence,'continuity->initialise')) throw new RuntimeException('New evidence sets must initialise longitudinal continuity');

$controller=file_get_contents($root.'/System/Http/Controllers/VisionController.php');
if(!str_contains($controller,'verifyBaseline')) throw new RuntimeException('Evidence review must provide explicit baseline verification');

$routes=file_get_contents($root.'/routes/user.php');
if(!str_contains($routes,'verify-baseline')) throw new RuntimeException('Baseline verification route missing');

$timeline=file_get_contents($root.'/System/Services/EvidenceTimelineService.php');
if(!str_contains($timeline,'continuity_key')) throw new RuntimeException('Timeline must expose continuity metadata');

echo "evidence-continuity-runtime: OK\n";
