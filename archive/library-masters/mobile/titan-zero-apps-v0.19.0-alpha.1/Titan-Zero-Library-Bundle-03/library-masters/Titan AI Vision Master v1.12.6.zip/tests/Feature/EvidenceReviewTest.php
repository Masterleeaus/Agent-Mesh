<?php
$root=dirname(__DIR__,2);
$prompt=file_get_contents($root.'/System/Services/VisionPromptBuilder.php');
$service=file_get_contents($root.'/System/Services/VisionEvidenceService.php');
$view=file_get_contents($root.'/resources/views/evidence.blade.php');
$routes=file_get_contents($root.'/routes/user.php');
assert(str_contains($prompt,'image_index'));
assert(str_contains($service, "['image_index']"));
assert(str_contains($view,'vision-annotation-box'));
assert(str_contains($view,'human_status'));
assert(str_contains($routes,'annotations/{annotation}/review'));
echo "EvidenceReviewTest OK\n";
