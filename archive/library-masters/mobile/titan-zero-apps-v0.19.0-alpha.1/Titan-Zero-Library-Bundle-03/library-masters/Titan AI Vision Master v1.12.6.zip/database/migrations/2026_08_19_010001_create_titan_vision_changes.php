<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
    public function up():void{
        if(Schema::hasTable('titan_vision_changes'))return;
        Schema::create('titan_vision_changes',function(Blueprint $table){
            $table->id();$table->unsignedBigInteger('user_id')->index();$table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedBigInteger('evidence_set_id')->index();$table->unsignedBigInteger('baseline_evidence_set_id')->index();
            $table->string('continuity_key',255)->nullable()->index();$table->string('finding_key',191)->index();$table->string('label')->nullable();
            $table->string('change_type',32)->index();$table->string('baseline_severity',32)->nullable();$table->string('current_severity',32)->nullable();
            $table->decimal('confidence_score',5,4)->default(0);$table->decimal('comparability_score',5,4)->default(0);$table->boolean('requires_human_review')->default(true)->index();
            $table->string('human_status',32)->default('pending')->index();$table->text('observation')->nullable();$table->text('reason')->nullable();$table->json('metadata')->nullable();$table->timestamps();
            $table->unique(['evidence_set_id','baseline_evidence_set_id','finding_key'],'titan_vision_changes_unique_finding');
        });
    }
    public function down():void{Schema::dropIfExists('titan_vision_changes');}
};
