<?php
use Illuminate\Database\Migrations\Migration;use Illuminate\Database\Schema\Blueprint;use Illuminate\Support\Facades\Schema;
return new class extends Migration{
 public function up():void{if(!Schema::hasTable('titan_vision_comparisons'))Schema::create('titan_vision_comparisons',function(Blueprint $t){$t->id();$t->unsignedBigInteger('evidence_set_id')->index();$t->unsignedBigInteger('user_id')->index();$t->unsignedBigInteger('company_id')->nullable()->index();$t->string('pair_key',96)->index();$t->unsignedBigInteger('before_evidence_item_id')->nullable()->index();$t->unsignedBigInteger('after_evidence_item_id')->nullable()->index();$t->decimal('comparability_score',5,4)->default(0);$t->decimal('confidence_score',5,4)->default(0);$t->string('rating',24)->default('insufficient')->index();$t->boolean('requires_human_review')->default(true)->index();$t->json('factors')->nullable();$t->text('visible_change_summary')->nullable();$t->json('metadata')->nullable();$t->timestamps();$t->foreign('evidence_set_id')->references('id')->on('titan_vision_evidence_sets')->cascadeOnDelete();});}
 public function down():void{}
};
