<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('titan_vision_evidence_sets')) {
            Schema::table('titan_vision_evidence_sets', function (Blueprint $t): void {
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'continuity_key')) $t->string('continuity_key', 255)->nullable()->index();
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'visit_sequence')) $t->unsignedInteger('visit_sequence')->nullable()->index();
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'verification_status')) $t->string('verification_status', 24)->default('unverified')->index();
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'baseline_verified_at')) $t->timestamp('baseline_verified_at')->nullable()->index();
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'baseline_verified_by')) $t->unsignedBigInteger('baseline_verified_by')->nullable()->index();
                if (!Schema::hasColumn('titan_vision_evidence_sets', 'previous_verified_evidence_set_id')) $t->unsignedBigInteger('previous_verified_evidence_set_id')->nullable()->index();
            });
        }

        if (!Schema::hasTable('titan_vision_evidence_lineage')) {
            Schema::create('titan_vision_evidence_lineage', function (Blueprint $t): void {
                $t->id();
                $t->unsignedBigInteger('user_id')->index();
                $t->unsignedBigInteger('company_id')->nullable()->index();
                $t->unsignedBigInteger('evidence_set_id')->index();
                $t->unsignedBigInteger('baseline_evidence_set_id')->index();
                $t->string('continuity_key', 255)->index();
                $t->string('relationship', 32)->default('previous_verified')->index();
                $t->string('trust_status', 24)->default('verified')->index();
                $t->text('reason')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->unique(['evidence_set_id', 'baseline_evidence_set_id'], 'vision_lineage_set_baseline_unique');
                $t->foreign('evidence_set_id')->references('id')->on('titan_vision_evidence_sets')->cascadeOnDelete();
                $t->foreign('baseline_evidence_set_id')->references('id')->on('titan_vision_evidence_sets')->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_vision_evidence_lineage');
        if (Schema::hasTable('titan_vision_evidence_sets')) {
            $columns=['continuity_key','visit_sequence','verification_status','baseline_verified_at','baseline_verified_by','previous_verified_evidence_set_id'];
            $existing=array_values(array_filter($columns, fn(string $column): bool => Schema::hasColumn('titan_vision_evidence_sets', $column)));
            if ($existing!==[]) Schema::table('titan_vision_evidence_sets', fn(Blueprint $t) => $t->dropColumn($existing));
        }
    }
};
