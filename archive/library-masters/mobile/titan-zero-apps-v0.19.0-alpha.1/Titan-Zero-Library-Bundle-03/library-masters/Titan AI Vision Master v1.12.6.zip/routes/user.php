<?php
use App\Extensions\TitanAIVision\System\Http\Controllers\VisionController;use Illuminate\Support\Facades\Route;
Route::get('/',[VisionController::class,'index'])->name('index');
Route::get('/timeline',[VisionController::class,'timeline'])->name('timeline');
Route::get('/checklist',[VisionController::class,'checklist'])->name('checklist');
Route::post('/preflight',[VisionController::class,'preflight'])->name('preflight');
Route::post('/analyse',[VisionController::class,'analyse'])->name('analyse');
Route::get('/evidence/{id}',[VisionController::class,'evidence'])->whereNumber('id')->name('evidence.show');
Route::patch('/evidence/{id}/annotations/{annotation}/review',[VisionController::class,'reviewAnnotation'])->whereNumber(['id','annotation'])->name('evidence.annotations.review');
Route::patch('/evidence/{id}/changes/{change}/review',[VisionController::class,'reviewChange'])->whereNumber(['id','change'])->name('evidence.changes.review');
Route::post('/evidence/{id}/verify-baseline',[VisionController::class,'verifyBaseline'])->whereNumber('id')->name('evidence.verify-baseline');
Route::post('/evidence/{id}/route',[VisionController::class,'route'])->whereNumber('id')->name('evidence.route');

Route::get('/assets/passports',[VisionController::class,'assetPassports'])->name('assets.passports');
Route::get('/assets/passports/{passport}',[VisionController::class,'assetPassport'])->whereNumber('passport')->name('assets.passports.show');
Route::post('/assets/passports/{passport}/verify-identity',[VisionController::class,'verifyAssetIdentity'])->whereNumber('passport')->name('assets.passports.verify-identity');
Route::patch('/assets/passports/{passport}/identity-candidates/{candidate}',[VisionController::class,'reviewAssetCandidate'])->whereNumber(['passport','candidate'])->name('assets.passports.identity-candidates.review');
