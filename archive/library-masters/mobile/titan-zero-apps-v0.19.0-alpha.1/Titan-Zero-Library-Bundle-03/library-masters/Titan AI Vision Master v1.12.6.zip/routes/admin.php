<?php
use App\Extensions\TitanAIVision\System\Http\Controllers\AdminController;use Illuminate\Support\Facades\Route;
Route::get('/',[AdminController::class,'index'])->name('index');
