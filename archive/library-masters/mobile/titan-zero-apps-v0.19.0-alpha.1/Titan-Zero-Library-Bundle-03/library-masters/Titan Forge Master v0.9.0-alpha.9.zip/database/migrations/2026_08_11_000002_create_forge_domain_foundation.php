<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_forge_builds')) {
            Schema::table('titan_forge_builds', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_forge_builds', 'causation_id')) {
                    $table->uuid('causation_id')->nullable()->index();
                }
                if (! Schema::hasColumn('titan_forge_builds', 'operation_id')) {
                    $table->uuid('operation_id')->nullable()->index();
                }
                if (! Schema::hasColumn('titan_forge_builds', 'actor_id')) {
                    $table->unsignedBigInteger('actor_id')->nullable()->index();
                }
                if (! Schema::hasColumn('titan_forge_builds', 'idempotency_key')) {
                    $table->string('idempotency_key', 190)->nullable();
                }
                if (! Schema::hasColumn('titan_forge_builds', 'spec_fingerprint')) {
                    $table->char('spec_fingerprint', 64)->nullable()->index();
                }
            });
        }

        if (! Schema::hasTable('titan_forge_build_specs')) {
            Schema::create('titan_forge_build_specs', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedSmallInteger('schema_version')->default(1);
                $table->char('fingerprint', 64)->index();
                $table->string('target_type', 80)->index();
                $table->text('instruction');
                $table->json('inputs')->nullable();
                $table->json('context');
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_build_plans')) {
            Schema::create('titan_forge_build_plans', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->unique();
                $table->unsignedBigInteger('company_id')->index();
                $table->char('fingerprint', 64)->index();
                $table->json('steps');
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_artifacts')) {
            Schema::create('titan_forge_artifacts', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('path', 512);
                $table->char('sha256', 64)->index();
                $table->string('type', 80)->index();
                $table->unsignedBigInteger('size_bytes')->default(0);
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['build_id', 'path'], 'titan_forge_artifacts_build_path_unique');
            });
        }

        if (! Schema::hasTable('titan_forge_validation_runs')) {
            Schema::create('titan_forge_validation_runs', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('status', 40)->default('pending')->index();
                $table->json('validator_set')->nullable();
                $table->json('summary')->nullable();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('completed_at')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_validation_findings')) {
            Schema::create('titan_forge_validation_findings', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('validation_run_id')->index();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('severity', 20)->index();
                $table->string('rule', 160)->index();
                $table->text('message');
                $table->string('file', 512)->nullable();
                $table->unsignedInteger('line')->nullable();
                $table->boolean('blocking')->default(false)->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_release_candidates')) {
            Schema::create('titan_forge_release_candidates', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('validation_run_id')->nullable()->index();
                $table->char('artifact_set_hash', 64)->index();
                $table->char('validation_fingerprint', 64)->index();
                $table->string('status', 40)->default('draft')->index();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_approvals')) {
            Schema::create('titan_forge_approvals', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('release_candidate_id')->index();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('actor_id')->index();
                $table->string('decision', 40)->index();
                $table->text('reason')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_releases')) {
            Schema::create('titan_forge_releases', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('release_candidate_id')->index();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->char('digest', 64)->index();
                $table->string('status', 40)->index();
                $table->json('command_receipt')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('titan_forge_receipts')) {
            Schema::create('titan_forge_receipts', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('build_id')->index();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('receipt_type', 80)->index();
                $table->char('receipt_hash', 64)->index();
                $table->json('payload');
                $table->timestamps();
            });
        }

        if (Schema::hasTable('titan_forge_builds') && Schema::hasColumn('titan_forge_builds', 'idempotency_key')) {
            Schema::table('titan_forge_builds', function (Blueprint $table): void {
                $table->unique(['company_id', 'idempotency_key'], 'titan_forge_builds_tenant_idempotency_unique');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_forge_receipts');
        Schema::dropIfExists('titan_forge_releases');
        Schema::dropIfExists('titan_forge_approvals');
        Schema::dropIfExists('titan_forge_release_candidates');
        Schema::dropIfExists('titan_forge_validation_findings');
        Schema::dropIfExists('titan_forge_validation_runs');
        Schema::dropIfExists('titan_forge_artifacts');
        Schema::dropIfExists('titan_forge_build_plans');
        Schema::dropIfExists('titan_forge_build_specs');

        if (Schema::hasTable('titan_forge_builds')) {
            Schema::table('titan_forge_builds', function (Blueprint $table): void {
                $table->dropUnique('titan_forge_builds_tenant_idempotency_unique');
                $table->dropColumn(['causation_id', 'operation_id', 'actor_id', 'idempotency_key', 'spec_fingerprint']);
            });
        }
    }
};
