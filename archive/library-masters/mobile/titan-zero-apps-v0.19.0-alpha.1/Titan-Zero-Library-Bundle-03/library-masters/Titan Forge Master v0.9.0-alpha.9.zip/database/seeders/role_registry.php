<?php

declare(strict_types=1);

$path = dirname(__DIR__, 2) . '/resources/workforce/roles-bootstrap.json';
return json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
