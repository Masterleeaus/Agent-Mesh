<?php

declare(strict_types=1);
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_forge_build_plans')) { return; }
        Schema::table('titan_forge_build_plans', function (Blueprint $table): void {
            if (! Schema::hasColumn('titan_forge_build_plans', 'source')) { $table->string('source', 80)->default('deterministic')->index(); }
            if (! Schema::hasColumn('titan_forge_build_plans', 'source_plan_id')) { $table->string('source_plan_id', 190)->nullable()->index(); }
            if (! Schema::hasColumn('titan_forge_build_plans', 'source_schema_version')) { $table->string('source_schema_version', 40)->nullable(); }
            if (! Schema::hasColumn('titan_forge_build_plans', 'source_runtime_version')) { $table->string('source_runtime_version', 40)->nullable(); }
            if (! Schema::hasColumn('titan_forge_build_plans', 'provenance')) { $table->json('provenance')->nullable(); }
        });
    }
    public function down(): void
    {
        if (! Schema::hasTable('titan_forge_build_plans')) { return; }
        foreach (['provenance','source_runtime_version','source_schema_version','source_plan_id','source'] as $column) {
            if (Schema::hasColumn('titan_forge_build_plans', $column)) {
                Schema::table('titan_forge_build_plans', function (Blueprint $table) use ($column): void { $table->dropColumn($column); });
            }
        }
    }
};
