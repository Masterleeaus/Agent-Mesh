<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_forge_builds') && ! Schema::hasColumn('titan_forge_builds', 'root_causation_id')) {
            Schema::table('titan_forge_builds', function (Blueprint $table): void {
                $table->uuid('root_causation_id')->nullable()->index()->after('causation_id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_forge_builds') && Schema::hasColumn('titan_forge_builds', 'root_causation_id')) {
            Schema::table('titan_forge_builds', function (Blueprint $table): void {
                $table->dropColumn('root_causation_id');
            });
        }
    }
};
