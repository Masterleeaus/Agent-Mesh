<?php

declare(strict_types=1);

return [
    'enabled' => env('TITAN_FORGE_ENABLED', true),
    'queue' => 'titan-forge',
    'tenant_key' => 'company_id',
    'workspace_root' => 'titan-forge/workspaces',
    'role_registry_path' => 'resources/workforce/roles-bootstrap.json',
    'team_compositions_path' => 'resources/workforce/team-compositions.json',
    'role_stub_path' => 'stubs/roles/role.php.stub',
    'max_build_files' => 2000,
    'max_artifact_bytes' => 104857600,
    'council' => [
        // Host-controlled policy only. Forge never selects models dynamically per request.
        'role_models' => [
            'proposer' => env('TITAN_FORGE_COUNCIL_PROPOSER_MODEL'),
            'critic' => env('TITAN_FORGE_COUNCIL_CRITIC_MODEL'),
            'verifier' => env('TITAN_FORGE_COUNCIL_VERIFIER_MODEL'),
            'arbiter' => env('TITAN_FORGE_COUNCIL_ARBITER_MODEL'),
        ],
    ],
];
