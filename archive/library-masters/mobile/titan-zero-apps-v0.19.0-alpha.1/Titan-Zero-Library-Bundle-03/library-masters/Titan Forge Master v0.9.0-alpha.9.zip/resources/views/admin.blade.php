<div class="container py-8">
    <h1>Titan Forge — Admin</h1>
    <p>Deterministic workforce foundation with isolated queued scaffolding. Release/install authority remains disabled.</p>
    <p><a href="{{ route('dashboard.admin.titan.forge.history') }}">View all Forge builds</a></p>
</div>
