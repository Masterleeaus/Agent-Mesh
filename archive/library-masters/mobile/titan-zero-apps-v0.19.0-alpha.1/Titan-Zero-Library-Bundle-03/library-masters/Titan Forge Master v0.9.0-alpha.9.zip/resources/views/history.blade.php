<div class="container py-8">
<h1>Titan Forge — Build History</h1>
<p>Read-only tenant build history. Generated artifacts remain isolated from the live Titan installation.</p>
<div class="overflow-x-auto"><table class="table-auto w-full"><thead><tr><th>ID</th><th>Type</th><th>Status</th><th>Operation</th><th>Created</th></tr></thead><tbody>
@forelse ($builds as $build)
<tr><td>{{ $build->id }}</td><td>{{ $build->type }}</td><td>{{ $build->status }}</td><td><code>{{ $build->operation_id }}</code></td><td>{{ $build->created_at }}</td></tr>
@empty<tr><td colspan="5">No Forge builds yet.</td></tr>@endforelse
</tbody></table></div>
</div>
