<div class="container py-8">
<h1>Titan Forge — Admin Build History</h1>
<p>Read-only cross-tenant Forge operational history.</p>
<div class="overflow-x-auto"><table class="table-auto w-full"><thead><tr><th>ID</th><th>Tenant</th><th>Type</th><th>Status</th><th>Operation</th><th>Created</th></tr></thead><tbody>
@forelse ($builds as $build)
<tr><td>{{ $build->id }}</td><td>{{ $build->company_id }}</td><td>{{ $build->type }}</td><td>{{ $build->status }}</td><td><code>{{ $build->operation_id }}</code></td><td>{{ $build->created_at }}</td></tr>
@empty<tr><td colspan="6">No Forge builds yet.</td></tr>@endforelse
</tbody></table></div>
</div>
