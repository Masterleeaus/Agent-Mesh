<div class="container py-8">
    <h1>Titan Forge</h1>
    <p>Governed system-construction foundation for Titan extensions, workflows, UI, capabilities and vertical assets.</p>
    <p><strong>Release:</strong> v0.6.0-alpha.1 — deterministic workforce scaffolding, sandboxed generation and persisted local artifact validation are active. AI generation and production deployment remain disabled.</p>
    <p><a href="{{ route('dashboard.user.titan.forge.history') }}">View build history</a></p>
</div>
