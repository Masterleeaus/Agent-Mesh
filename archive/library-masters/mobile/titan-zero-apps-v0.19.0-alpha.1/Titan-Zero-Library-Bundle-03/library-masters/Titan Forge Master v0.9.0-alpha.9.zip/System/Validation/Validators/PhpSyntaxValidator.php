<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Validation\Validators;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;
final class PhpSyntaxValidator implements ArtifactValidatorContract
{
    public function id(): string { return 'php-syntax'; }
    public function validate(BuildSpec $spec,SandboxWorkspace $workspace,ArtifactSet $artifacts): array
    {
        $findings=[];
        foreach($artifacts->artifacts as $artifact){
            if($artifact->type!=='php'){continue;}
            $data=file_get_contents($workspace->path($artifact->path)); if(!is_string($data)){continue;}
            try{token_get_all($data,TOKEN_PARSE);}catch(\ParseError $e){$findings[]=new ValidationFinding('critical','php.syntax','Generated PHP is invalid: '.$e->getMessage(),$artifact->path,true,$e->getLine()>0?$e->getLine():null);}
        }
        return $findings;
    }
}
