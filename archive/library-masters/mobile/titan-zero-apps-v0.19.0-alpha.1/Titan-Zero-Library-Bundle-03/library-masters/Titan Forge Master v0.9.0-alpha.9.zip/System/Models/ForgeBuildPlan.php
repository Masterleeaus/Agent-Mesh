<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeBuildPlan extends Model
{
    protected $table = 'titan_forge_build_plans';

    protected $guarded = [];

    protected $casts = [
        'steps' => 'array',
        'provenance' => 'array'
    ];
}
