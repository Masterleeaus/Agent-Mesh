<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation\Validators;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;

final class WorkspaceIntegrityValidator implements ArtifactValidatorContract
{
    public function id(): string { return 'workspace-integrity'; }
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array
    {
        $findings=[];
        foreach ($artifacts->artifacts as $artifact) {
            $path=$workspace->path($artifact->path);
            if (!is_file($path) || is_link($path)) {
                $findings[]=new ValidationFinding('critical','artifact.missing_or_link','Artifact is missing or is a symlink.',$artifact->path,true);
                continue;
            }
            $size=filesize($path); $sha=hash_file('sha256',$path);
            if ($size!==$artifact->sizeBytes || !is_string($sha) || !hash_equals($artifact->sha256,$sha)) {
                $findings[]=new ValidationFinding('critical','artifact.integrity_mismatch','Artifact size or SHA-256 does not match its receipt.',$artifact->path,true);
            }
        }
        return $findings;
    }
}
