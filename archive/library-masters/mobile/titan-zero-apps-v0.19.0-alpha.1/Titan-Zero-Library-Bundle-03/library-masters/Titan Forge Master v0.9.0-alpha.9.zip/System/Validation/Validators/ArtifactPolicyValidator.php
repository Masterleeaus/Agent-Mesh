<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation\Validators;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;
use InvalidArgumentException;

final readonly class ArtifactPolicyValidator implements ArtifactValidatorContract
{
    public function __construct(private int $maxFiles, private int $maxArtifactBytes)
    {
        if ($maxFiles < 1 || $maxArtifactBytes < 1024) { throw new InvalidArgumentException('Artifact policy limits are invalid.'); }
    }
    public function id(): string { return 'artifact-policy'; }
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array
    {
        $findings = [];
        if ($artifacts->count() > $this->maxFiles) {
            $findings[] = new ValidationFinding('critical','artifact.count_limit','Generated artifact count exceeds Forge policy.',blocking:true,metadata:['count'=>$artifacts->count(),'max'=>$this->maxFiles]);
        }
        foreach ($artifacts->artifacts as $artifact) {
            if ($artifact->sizeBytes > $this->maxArtifactBytes) {
                $findings[] = new ValidationFinding('critical','artifact.size_limit','Generated artifact exceeds Forge size policy.',$artifact->path,true,metadata:['bytes'=>$artifact->sizeBytes,'max'=>$this->maxArtifactBytes]);
            }
        }
        return $findings;
    }
}
