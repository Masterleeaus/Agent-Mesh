<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeSignalGatewayContract;
use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;
use Closure;
use Throwable;

final class TitanSignalGateway implements ForgeSignalGatewayContract
{
    public function __construct(
        private readonly Closure $resolver,
        private readonly string $contract = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterContract',
    ) {}

    public function available(): bool
    {
        $peer = $this->resolve();
        return $peer !== null && method_exists($peer, 'emit');
    }

    public function emit(ForgeSignalEvent $event): array
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'emit')) {
            return ['recorded' => false, 'reason' => 'signal.unavailable'];
        }
        try {
            $receipt = $peer->emit($event->toSignalArray());
            $data = is_object($receipt) && method_exists($receipt, 'toArray') ? $receipt->toArray() : [];
            return is_array($data) ? $data + ['recorded' => true] : ['recorded' => true];
        } catch (Throwable $e) {
            return ['recorded' => false, 'reason' => 'signal.error', 'error_class' => $e::class];
        }
    }

    private function resolve(): ?object
    {
        try {
            $peer = ($this->resolver)($this->contract);
            return is_object($peer) ? $peer : null;
        } catch (Throwable) {
            return null;
        }
    }
}
