<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ValidationResult
{
    public function __construct(
        public array $findings = [],
        public ?bool $validOverride = null,
        public array $errors = [],
        public array $warnings = [],
    ) {
        foreach ($findings as $finding) {
            if (! $finding instanceof ValidationFinding) { throw new InvalidArgumentException('ValidationResult accepts ValidationFinding instances only.'); }
        }
    }

    public static function pass(array $warnings = []): self { return new self([], true, [], array_values($warnings)); }
    public static function fail(array $errors, array $warnings = []): self { return new self([], false, array_values($errors), array_values($warnings)); }

    public function passed(): bool
    {
        if ($this->validOverride === false || $this->errors !== []) { return false; }
        foreach ($this->findings as $finding) { if ($finding->blocking) { return false; } }
        return $this->validOverride ?? true;
    }

    public function fingerprint(): string
    {
        if ($this->validOverride === null && $this->errors === [] && $this->warnings === []) {
            $data = array_map(static fn (ValidationFinding $f): array => $f->toArray(), $this->findings);
            return hash('sha256', json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        }
        return hash('sha256', json_encode($this->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    public function __get(string $name): mixed
    {
        if ($name === 'valid') { return $this->passed(); }
        throw new \LogicException("Undefined property {$name}");
    }

    public function toArray(): array
    {
        return [
            'valid'=>$this->passed(),'errors'=>$this->errors,'warnings'=>$this->warnings,
            'findings'=>array_map(static fn(ValidationFinding $f):array=>$f->toArray(),$this->findings),
        ];
    }
}
