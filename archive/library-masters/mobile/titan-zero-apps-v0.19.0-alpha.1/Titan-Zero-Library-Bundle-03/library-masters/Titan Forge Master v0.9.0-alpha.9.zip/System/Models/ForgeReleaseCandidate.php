<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeReleaseCandidate extends Model
{
    protected $table = 'titan_forge_release_candidates';

    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array'
    ];
}
