<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Services;
use App\Extensions\TitanForge\System\Config\ForgeConfiguration;
use App\Extensions\TitanForge\System\Contracts\BuildRepositoryContract;
use App\Extensions\TitanForge\System\Contracts\ForgeAiPlanningGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCommandBusGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeManagerContract;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeSignalGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ReleaseRepositoryContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;
use App\Extensions\TitanForge\System\Domain\ReleaseCandidate;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Events\ForgeBuildStatusChanged;
use App\Extensions\TitanForge\System\Generation\StaticRoleTemplateEngine;
use App\Extensions\TitanForge\System\AI\SandboxedAiArtifactGenerator;
use App\Extensions\TitanForge\System\Governance\ReleaseGovernanceService;
use App\Extensions\TitanForge\System\Jobs\GenerateSkeletonTeam;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use App\Extensions\TitanForge\System\Validation\ArtifactValidationPipeline;
use App\Extensions\TitanForge\System\Workforce\RoleCatalog;
use App\Extensions\TitanForge\System\Workforce\TeamCompositionService;
use App\Extensions\TitanForge\System\Workforce\TierEntitlementPolicy;
use RuntimeException;

final class ForgeManager implements ForgeManagerContract
{
    public function __construct(
        private readonly BuildRepositoryContract $builds,
        private readonly ReleaseRepositoryContract $releases,
        private readonly ForgeConfiguration $configuration,
        private readonly TeamCompositionService $teams,
        private readonly TierEntitlementPolicy $entitlements,
        private readonly RoleCatalog $roles,
        private readonly StaticRoleTemplateEngine $staticRoles,
        private readonly SandboxWorkspaceFactory $workspaces,
        private readonly ArtifactValidationPipeline $artifactValidation,
        private readonly ReleaseGovernanceService $releaseGovernance,
        private readonly ForgeSignalGatewayContract $signalGateway,
        private readonly ForgeRiskGatewayContract $riskGateway,
        private readonly ForgeShieldGatewayContract $shieldGateway,
        private readonly ForgeCouncilGatewayContract $councilGateway,
        private readonly ForgeGovernanceGatewayContract $governanceGateway,
        private readonly ForgeCommandBusGatewayContract $commandBusGateway,
        private readonly ForgeAiPlanningGatewayContract $aiPlanningGateway,
        private readonly SandboxedAiArtifactGenerator $aiArtifacts,
    ) {}

    public function health(): array
    {
        return [
            'engine'=>'titan-forge',
            'status'=>$this->configuration->enabled?'ai-assisted-boundary':'disabled',
            'version'=>'0.9.0-alpha.2',
            'liveness'=>true,
            'readiness'=>$this->configuration->enabled,
            'operational_health'=>$this->configuration->enabled?'DEGRADED':'DISABLED',
            'historical_incidents_separate'=>true,
            'queue'=>['name'=>$this->configuration->queue,'active'=>true],
            'generation'=>[
                'static_role_templates'=>true,
                'ai_planning_contract_available'=>$this->aiPlanningGateway->available(),
                'ai_artifact_gateway_available'=>$this->aiArtifacts->available(),
                'ai_generation'=>false,
                'ai_generation_boundary'=>true,
                'direct_model_provider_calls'=>false,
                'sandboxed_workspace'=>true,
            ],
            'validation'=>['local_pipeline'=>true,'validators'=>$this->artifactValidation->validatorIds()],
            'governance'=>[
                'signal_adapter_available'=>$this->signalGateway->available(),
                'risk_adapter_available'=>$this->riskGateway->available(),
                'shield_adapter_available'=>$this->shieldGateway->available(),
                'council_adapter_available'=>$this->councilGateway->available(),
                'council_governed_deliberation_available'=>$this->councilGateway->governedDeliberationAvailable(),
                'governance_decision_api_available'=>$this->governanceGateway->available(),
                'command_bus_dispatch_api_available'=>$this->commandBusGateway->available(),
                'direct_deployment'=>false,
            ],
        ];
    }

    public function registerBuild(BuildRequest $request): ForgeBuild
    {
        $this->assertEnabled(); return $this->builds->createOrFind($request,BuildSpec::fromRequest($request));
    }

    public function planBuildWithAi(BuildRequest $request): array
    {
        $this->assertEnabled();
        [$build,$spec,$planning]=$this->prepareAiPlan($request);
        return [
            'build_id'=>(int)$build->getKey(),
            'status'=>(string)$build->status,
            'build_spec_fingerprint'=>$spec->fingerprint(),
            'planning'=>$planning->toArray(),
            'deployment_authority'=>'none',
        ];
    }

    public function generateBuildWithAi(BuildRequest $request): array
    {
        $this->assertEnabled();
        [$build,$spec,$planning]=$this->prepareAiPlan($request);
        if (! $planning->usable || $planning->plan===null) {
            return [
                'build_id'=>(int)$build->getKey(),
                'status'=>(string)$build->status,
                'planning'=>$planning->toArray(),
                'generation'=>['available'=>false,'reason_code'=>'ai_planning_not_usable'],
                'release_candidate'=>null,
                'deployment_authority'=>'none',
            ];
        }
        if (! $this->aiArtifacts->available()) {
            $build=$this->builds->markStatus($build,'generation_blocked',[
                'generation_mode'=>'ai-assisted',
                'generation_reason'=>'titan_ai_core_generation_contract_unavailable',
                'build_plan_fingerprint'=>$planning->plan->fingerprint(),
                'deployment_authority'=>'none',
            ]);
            $this->emitStatus($build,'generation_blocked',['generation_mode'=>'ai-assisted','reason_code'=>'titan_ai_core_generation_contract_unavailable']);
            return [
                'build_id'=>(int)$build->getKey(),
                'status'=>'generation_blocked',
                'planning'=>$planning->toArray(),
                'generation'=>['available'=>false,'reason_code'=>'titan_ai_core_generation_contract_unavailable'],
                'release_candidate'=>null,
                'deployment_authority'=>'none',
            ];
        }

        $build=$this->builds->markStatus($build,'generating',['generation_mode'=>'ai-assisted','build_plan_fingerprint'=>$planning->plan->fingerprint()]);
        $this->emitStatus($build,'generating',['generation_mode'=>'ai-assisted','build_plan_fingerprint'=>$planning->plan->fingerprint()]);
        try {
            $result=$this->aiArtifacts->generate($request,$spec,$planning->plan);
            if(!isset($result['artifacts']) || !$result['artifacts'] instanceof ArtifactSet){throw new RuntimeException('Forge AI generator did not return a typed artifact set.');}
            $artifactMetadata=[
                'generation_mode'=>'ai-assisted',
                'planner'=>(array)($result['manifest']['planner']??[]),
                'model'=>(array)($result['manifest']['model']??[]),
                'provenance'=>(array)($result['manifest']['provenance']??[]),
                'build_plan_fingerprint'=>$planning->plan->fingerprint(),
                'generation_manifest_sha256'=>(string)$result['manifest_sha256'],
                'deployment_authority'=>'none',
            ];
            $this->builds->recordArtifacts($build,$result['files'],$artifactMetadata);
            $build=$this->builds->markStatus($build,'generated',[
                'generation_mode'=>'ai-assisted',
                'workspace'=>$result['workspace'],
                'generation_manifest_sha256'=>$result['manifest_sha256'],
                'artifact_set_digest'=>$result['artifacts']->digest(),
                'build_plan_fingerprint'=>$planning->plan->fingerprint(),
            ]);
            $this->emitStatus($build,'generated',['generation_mode'=>'ai-assisted','generation_manifest_sha256'=>$result['manifest_sha256'],'artifact_set_digest'=>$result['artifacts']->digest()]);

            $build=$this->builds->markStatus($build,'validating',['generation_mode'=>'ai-assisted']);
            $this->emitStatus($build,'validating',['generation_mode'=>'ai-assisted']);
            $workspace=$this->workspaces->forContext($request->context);
            $validation=$this->artifactValidation->validate($spec,$workspace,$result['artifacts']);
            $validationRunId=$this->builds->recordValidation($build,$this->artifactValidation->validatorIds(),$validation);
            $status=$validation->passed()?'validated':'validation_failed';
            $build=$this->builds->markStatus($build,$status,[
                'validation_run_id'=>$validationRunId,
                'validation_fingerprint'=>$validation->fingerprint(),
                'validation_valid'=>$validation->passed(),
                'generation_mode'=>'ai-assisted',
            ]);
            $this->emitStatus($build,$status,['generation_mode'=>'ai-assisted','validation_run_id'=>$validationRunId,'validation_fingerprint'=>$validation->fingerprint()]);

            $releaseCandidate=null;
            if ($validation->passed()) {
                $gate=$this->releaseGovernance->evaluate($spec,$result['artifacts'],$validation);
                $candidate=new ReleaseCandidate((int)$build->getKey(),$result['artifacts']->digest(),$validation->fingerprint(),$gate->candidateStatus);
                $storedCandidate=$this->releases->recordCandidate($build,$validationRunId,$candidate,$gate);
                $build=$this->builds->markStatus($build,'validated',[
                    'release_candidate_id'=>(int)$storedCandidate->getKey(),
                    'release_candidate_status'=>$candidate->status,
                    'release_gate_fingerprint'=>$gate->fingerprint(),
                    'generation_mode'=>'ai-assisted',
                ]);
                $releaseCandidate=[
                    'id'=>(int)$storedCandidate->getKey(),
                    'status'=>$candidate->status,
                    'blocked'=>$gate->blocked,
                    'gate_fingerprint'=>$gate->fingerprint(),
                    'gate'=>$gate->toArray(),
                    'deployment_authority'=>'none',
                ];
                $this->emitSignal($build,'forge.release.candidate_created',[
                    'release_candidate_id'=>(int)$storedCandidate->getKey(),
                    'status'=>$candidate->status,
                    'blocked'=>$gate->blocked,
                    'gate_fingerprint'=>$gate->fingerprint(),
                ],['release_candidate'=>true,'generation_mode'=>'ai-assisted']);
            }
            return $result+[
                'build_id'=>(int)$build->getKey(),
                'status'=>$status,
                'planning'=>$planning->toArray(),
                'validation_run_id'=>$validationRunId,
                'validation'=>$validation->toArray(),
                'release_candidate'=>$releaseCandidate,
                'deployment_authority'=>'none',
            ];
        } catch (\Throwable $e) {
            $build=$this->builds->markStatus($build,'failed',['generation_mode'=>'ai-assisted','error_class'=>$e::class]);
            $this->emitStatus($build,'failed',['generation_mode'=>'ai-assisted','error_class'=>$e::class]);
            throw $e;
        }
    }

    public function findBuildForTenant(int $companyId,int $buildId): ?ForgeBuild { return $this->builds->findForTenant($companyId,$buildId); }
    public function getManifestForTier(string $tier): array { return $this->teams->manifestForTier($tier); }

    public function validateBuild(BuildSpec $spec): ValidationResult
    {
        if ($spec->targetType!=='workforce_team') { return ValidationResult::pass(); }
        $entitlement=$this->entitlements->validate($spec->tier,$spec->roleIds);
        if (! $entitlement->passed()) { return $entitlement; }
        $errors=[]; $requested=array_fill_keys($spec->roleIds,true);
        foreach ($spec->roleIds as $roleId) {
            try { $role=$this->roles->get($roleId); } catch (\InvalidArgumentException $e) { $errors[]=$e->getMessage(); continue; }
            foreach (($role['depends_on']??[]) as $dependency) { if (!isset($requested[$dependency])) { $errors[]="Role {$roleId} requires {$dependency}."; } }
        }
        return $errors===[]?ValidationResult::pass():ValidationResult::fail($errors);
    }

    public function queueSkeletonTeam(BuildContext $context,string $tier): ForgeBuild
    {
        $this->assertEnabled(); $manifest=$this->getManifestForTier($tier); [$request,$spec]=$this->workforceRequest($context,$manifest);
        $validation=$this->validateBuild($spec); if(!$validation->passed()){throw new RuntimeException('Forge workforce build rejected: '.implode('; ',$validation->errors));}
        $build=$this->builds->createOrFind($request,$spec);
        $build=$this->builds->markStatus($build,'queued',['tier'=>$manifest['tier'],'role_ids'=>$manifest['role_ids']]);
        GenerateSkeletonTeam::dispatch($context,$manifest['tier']); $this->emitStatus($build,'queued'); return $build;
    }

    public function generateSkeletonTeam(BuildContext $context,string $tier): array
    {
        $this->assertEnabled(); $manifest=$this->getManifestForTier($tier); [$request,$spec]=$this->workforceRequest($context,$manifest);
        $preflight=$this->validateBuild($spec); if(!$preflight->passed()){throw new RuntimeException('Forge workforce build rejected: '.implode('; ',$preflight->errors));}
        $build=$this->builds->createOrFind($request,$spec); $build=$this->builds->markStatus($build,'generating'); $this->emitStatus($build,'generating');
        try {
            $result=$this->staticRoles->generate($spec);
            if(!isset($result['artifacts']) || !$result['artifacts'] instanceof ArtifactSet){throw new RuntimeException('Forge generator did not return a typed artifact set.');}
            $this->builds->recordArtifacts($build,$result['files']);
            $build=$this->builds->markStatus($build,'generated',['tier'=>$manifest['tier'],'role_ids'=>$manifest['role_ids'],'workspace'=>$result['workspace'],'generation_manifest_sha256'=>$result['manifest_sha256'],'artifact_set_digest'=>$result['artifacts']->digest()]);
            $this->emitStatus($build,'generated',['generation_manifest_sha256'=>$result['manifest_sha256'],'artifact_set_digest'=>$result['artifacts']->digest()]);

            $build=$this->builds->markStatus($build,'validating'); $this->emitStatus($build,'validating');
            $workspace=$this->workspaces->forContext($context);
            $validation=$this->artifactValidation->validate($spec,$workspace,$result['artifacts']);
            $validationRunId=$this->builds->recordValidation($build,$this->artifactValidation->validatorIds(),$validation);
            $status=$validation->passed()?'validated':'validation_failed';
            $build=$this->builds->markStatus($build,$status,[
                'validation_run_id'=>$validationRunId,
                'validation_fingerprint'=>$validation->fingerprint(),
                'validation_valid'=>$validation->passed(),
            ]);
            $this->emitStatus($build,$status,['validation_run_id'=>$validationRunId,'validation_fingerprint'=>$validation->fingerprint()]);

            $releaseCandidate = null;
            if ($validation->passed()) {
                $gate = $this->releaseGovernance->evaluate($spec, $result['artifacts'], $validation);
                $candidate = new ReleaseCandidate(
                    (int) $build->getKey(),
                    $result['artifacts']->digest(),
                    $validation->fingerprint(),
                    $gate->candidateStatus,
                );
                $storedCandidate = $this->releases->recordCandidate($build, $validationRunId, $candidate, $gate);
                $build = $this->builds->markStatus($build, 'validated', [
                    'release_candidate_id' => (int) $storedCandidate->getKey(),
                    'release_candidate_status' => $candidate->status,
                    'release_gate_fingerprint' => $gate->fingerprint(),
                ]);
                $releaseCandidate = [
                    'id' => (int) $storedCandidate->getKey(),
                    'status' => $candidate->status,
                    'blocked' => $gate->blocked,
                    'gate_fingerprint' => $gate->fingerprint(),
                    'gate' => $gate->toArray(),
                    'deployment_authority' => 'none',
                ];
                $this->emitSignal($build, 'forge.release.candidate_created', [
                    'release_candidate_id' => (int) $storedCandidate->getKey(),
                    'status' => $candidate->status,
                    'blocked' => $gate->blocked,
                    'gate_fingerprint' => $gate->fingerprint(),
                ], ['release_candidate' => true]);
            }

            return $result+[
                'build_id'=>(int)$build->getKey(),
                'status'=>$status,
                'validation_run_id'=>$validationRunId,
                'validation'=>$validation->toArray(),
                'release_candidate'=>$releaseCandidate,
            ];
        } catch (\Throwable $e) {
            $build=$this->builds->markStatus($build,'failed',['error_class'=>$e::class]); $this->emitStatus($build,'failed',['error_class'=>$e::class]); throw $e;
        }
    }

    private function prepareAiPlan(BuildRequest $request): array
    {
        $spec=BuildSpec::fromRequest($request);
        $build=$this->builds->createOrFind($request,$spec);
        $build=$this->builds->markStatus($build,'planning',['planning_mode'=>'ai-assisted']);
        $this->emitStatus($build,'planning',['planning_mode'=>'ai-assisted']);
        $planning=$this->aiPlanningGateway->plan($request);
        if (! $planning->usable || $planning->plan===null) {
            $build=$this->builds->markStatus($build,'planning_blocked',[
                'planning_mode'=>'ai-assisted',
                'planning_reason'=>$planning->reasonCode,
                'planning_fingerprint'=>$planning->fingerprint(),
                'ai_planning_contract_available'=>$planning->contractAvailable,
                'deployment_authority'=>'none',
            ]);
            $this->emitStatus($build,'planning_blocked',['planning_mode'=>'ai-assisted','reason_code'=>$planning->reasonCode]);
            return [$build,$spec,$planning];
        }
        $buildPlanId=$this->builds->recordPlan($build,$planning->plan,$planning->provenance);
        $build=$this->builds->markStatus($build,'planned',[
            'planning_mode'=>'ai-assisted',
            'build_plan_id'=>$buildPlanId,
            'build_plan_fingerprint'=>$planning->plan->fingerprint(),
            'planning_fingerprint'=>$planning->fingerprint(),
            'source_plan_id'=>(string)($planning->provenance['source_plan_id']??''),
            'ai_core_executable'=>(bool)($planning->provenance['ai_core_executable']??false),
            'deployment_authority'=>'none',
        ]);
        $this->emitStatus($build,'planned',['planning_mode'=>'ai-assisted','build_plan_id'=>$buildPlanId,'build_plan_fingerprint'=>$planning->plan->fingerprint()]);
        return [$build,$spec,$planning];
    }

    private function workforceRequest(BuildContext $context,array $manifest): array
    {
        $roles=array_values($manifest['role_ids']);
        $request=new BuildRequest($context,'workforce_team','Assemble the deterministic Titan AI Workforce skeleton for entitlement tier '.$manifest['tier'].'.',
            ['tier'=>$manifest['tier'],'role_ids'=>$roles,'authority'=>'titan-ai-workforce']);
        $spec=BuildSpec::workforceTeam($context,$manifest['tier'],$roles,['authority'=>'titan-ai-workforce']);
        return [$request,$spec];
    }

    private function assertEnabled(): void { if(!$this->configuration->enabled){throw new RuntimeException('Titan Forge is disabled.');} }

    private function emitStatus(ForgeBuild $build,string $status,array $metadata=[]): void
    {
        event(new ForgeBuildStatusChanged((int)$build->getKey(),(int)$build->company_id,$status,(string)$build->trace_id,(string)$build->correlation_id,
            (string)$build->causation_id,(string)$build->operation_id,$metadata,(string)($build->root_causation_id ?: $build->causation_id)));
        $eventType = match ($status) {
            'queued' => 'forge.build.requested',
            'generating' => 'forge.build.started',
            'generated' => 'forge.artifact.generated',
            'validating' => 'forge.validation.started',
            'validated' => 'forge.validation.passed',
            'validation_failed' => 'forge.validation.failed',
            'failed' => 'forge.build.failed',
            default => 'forge.build.status_changed',
        };
        $this->emitSignal($build, $eventType, ['build_id'=>(int)$build->getKey(),'status'=>$status], $metadata);
    }

    private function emitSignal(ForgeBuild $build, string $eventType, array $payload, array $metadata=[]): void
    {
        $signalKey = substr((string)$build->idempotency_key . ':' . str_replace('.', '_', $eventType), 0, 190);
        $this->signalGateway->emit(new ForgeSignalEvent(
            $eventType,
            (int)$build->company_id,
            (string)$build->trace_id,
            (string)$build->correlation_id,
            (string)$build->causation_id,
            (string)$build->operation_id,
            (int)$build->actor_id ?: null,
            $signalKey,
            $payload,
            $metadata,
            $eventType === 'forge.build.failed' || $eventType === 'forge.validation.failed' ? 'warning' : 'info',
            'forge.lifecycle',
            (string)($build->root_causation_id ?: $build->causation_id),
        ));
    }
}
