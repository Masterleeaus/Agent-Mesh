<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class RiskDeclaration
{
    public function __construct(
        public string $level,
        public bool $blocked,
        public string $provider,
        public array $reasons = [],
        public array $metadata = [],
    ) {
        if (! in_array($level, ['low','medium','high','critical','unavailable'], true)) {
            throw new InvalidArgumentException('Unknown Forge risk level.');
        }
        if ($provider === '') {
            throw new InvalidArgumentException('Risk declaration provider is required.');
        }
    }

    public static function unavailable(string $provider = 'titan-risk'): self
    {
        return new self('unavailable', true, $provider, ['Risk assessment provider is unavailable.']);
    }

    public function toArray(): array
    {
        return ['level'=>$this->level,'blocked'=>$this->blocked,'provider'=>$this->provider,'reasons'=>$this->reasons,'metadata'=>$this->metadata];
    }
}
