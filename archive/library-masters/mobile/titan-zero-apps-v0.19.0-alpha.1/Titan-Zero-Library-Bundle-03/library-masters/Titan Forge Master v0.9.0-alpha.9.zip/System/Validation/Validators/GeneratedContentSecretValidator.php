<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation\Validators;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;

final class GeneratedContentSecretValidator implements ArtifactValidatorContract
{
    private const MAX_SCAN_BYTES=2000000;
    public function id(): string { return 'generated-secret-scan'; }
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array
    {
        $patterns=[
            '/(?<![A-Za-z0-9])sk-(?:proj-)?[A-Za-z0-9_-]{32,}/',
            '/(?<![A-Za-z0-9])sk_live_[A-Za-z0-9]{20,}/',
            '/AKIA[0-9A-Z]{16}/',
            '/gh[pousr]_[A-Za-z0-9]{30,}/',
            '/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/',
        ];
        $findings=[];
        foreach($artifacts->artifacts as $artifact){
            if($artifact->sizeBytes>self::MAX_SCAN_BYTES || !self::textual($artifact->path)){continue;}
            $data=file_get_contents($workspace->path($artifact->path)); if(!is_string($data)){continue;}
            foreach($patterns as $pattern){ if(preg_match($pattern,$data)===1){$findings[]=new ValidationFinding('critical','generated.secret_pattern','Generated content contains a credential/private-key pattern.',$artifact->path,true); break;} }
        }
        return $findings;
    }
    private static function textual(string $path): bool
    {
        $p=strtolower($path); foreach(['.php','.json','.md','.txt','.xml','.yml','.yaml','.js','.ts','.css','.html','.blade.php','.stub'] as $suffix){if(str_ends_with($p,$suffix)){return true;}} return false;
    }
}
