<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Validation\Validators;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;
final class JsonSyntaxValidator implements ArtifactValidatorContract
{
    public function id(): string { return 'json-syntax'; }
    public function validate(BuildSpec $spec,SandboxWorkspace $workspace,ArtifactSet $artifacts): array
    {
        $findings=[];
        foreach($artifacts->artifacts as $artifact){
            if($artifact->type!=='json'){continue;}
            $data=file_get_contents($workspace->path($artifact->path)); if(!is_string($data)){continue;}
            try{json_decode($data,true,512,JSON_THROW_ON_ERROR);}catch(\JsonException $e){$findings[]=new ValidationFinding('critical','json.syntax','Generated JSON is invalid: '.$e->getMessage(),$artifact->path,true);}
        }
        return $findings;
    }
}
