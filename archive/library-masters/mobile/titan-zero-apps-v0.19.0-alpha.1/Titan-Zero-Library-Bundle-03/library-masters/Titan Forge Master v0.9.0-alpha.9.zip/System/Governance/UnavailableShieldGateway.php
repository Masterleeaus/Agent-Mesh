<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Governance;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
final class UnavailableShieldGateway implements ForgeShieldGatewayContract
{
    public function available(): bool { return false; }
    public function inspect(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): ValidationResult
    {
        return new ValidationResult([new ValidationFinding('critical','shield.unavailable','Titan Shield validation provider is unavailable.',blocking:true)]);
    }
}
