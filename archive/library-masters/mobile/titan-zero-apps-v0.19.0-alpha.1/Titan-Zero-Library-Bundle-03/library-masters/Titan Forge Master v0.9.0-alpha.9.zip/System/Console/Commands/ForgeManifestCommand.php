<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Console\Commands;

use App\Extensions\TitanForge\System\Contracts\ForgeManagerContract;
use Illuminate\Console\Command;

final class ForgeManifestCommand extends Command
{
    protected $signature = 'forge:manifest {tier=solo} {--json}';
    protected $description = 'Show the deterministic Titan AI Workforce manifest selected by Forge.';

    public function handle(ForgeManagerContract $forge): int
    {
        try { $manifest=$forge->getManifestForTier((string)$this->argument('tier')); }
        catch (\Throwable $e) { $this->error($e->getMessage()); return self::FAILURE; }
        if ((bool)$this->option('json')) { $this->line(json_encode($manifest,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)); return self::SUCCESS; }
        $this->info(sprintf('Titan Forge workforce tier: %s (%d/%d roles)',$manifest['tier'],count($manifest['roles']),$manifest['role_limit']));
        $this->table(['Canonical Role ID','Capability Count'],array_map(static fn(array $r):array=>[$r['role_definition_id'],count($r['capabilities']??[])],$manifest['roles']));
        return self::SUCCESS;
    }
}
