<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Http\Middleware;

use App\Extensions\TitanForge\System\Support\ForgeTenantResolver;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class RequireForgeTenant
{
    public function __construct(private readonly ForgeTenantResolver $resolver)
    {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_if($user === null, 401);
        try {
            $companyId = $this->resolver->resolveUser($user);
        } catch (\RuntimeException) {
            abort(403, 'Titan Forge tenant context is required.');
        }
        $request->attributes->set('titan_forge_company_id', $companyId);
        return $next($request);
    }
}
