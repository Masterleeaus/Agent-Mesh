<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeValidationRun extends Model
{
    protected $table = 'titan_forge_validation_runs';

    protected $guarded = [];

    protected $casts = [
        'validator_set' => 'array',
        'summary' => 'array',
        'started_at' => 'datetime',
        'completed_at' => 'datetime'
    ];
}
