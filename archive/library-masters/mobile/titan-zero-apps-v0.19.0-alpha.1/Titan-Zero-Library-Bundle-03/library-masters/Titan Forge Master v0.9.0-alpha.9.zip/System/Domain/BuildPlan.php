<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildPlan
{
    /** @param list<BuildStep> $steps */
    public function __construct(public array $steps)
    {
        $seen = [];
        foreach ($steps as $step) {
            if (! $step instanceof BuildStep) {
                throw new InvalidArgumentException('BuildPlan accepts BuildStep instances only.');
            }
            if (isset($seen[$step->id])) {
                throw new InvalidArgumentException('BuildPlan step ids must be unique.');
            }
            foreach ($step->dependsOn as $dependency) {
                if (! isset($seen[$dependency])) {
                    throw new InvalidArgumentException('BuildPlan dependencies must reference an earlier step.');
                }
            }
            $seen[$step->id] = true;
        }
    }

    public function toArray(): array
    {
        return array_map(static fn (BuildStep $step): array => $step->toArray(), $this->steps);
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode($this->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }
}
