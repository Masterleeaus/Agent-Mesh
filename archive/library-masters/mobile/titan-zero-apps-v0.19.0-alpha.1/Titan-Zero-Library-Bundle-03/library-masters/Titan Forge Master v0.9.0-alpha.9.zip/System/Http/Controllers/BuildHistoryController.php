<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Http\Controllers;

use App\Extensions\TitanForge\System\Contracts\BuildRepositoryContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class BuildHistoryController
{
    public function __construct(private readonly BuildRepositoryContract $builds) {}
    public function __invoke(Request $request): View
    {
        $companyId=(int)$request->attributes->get('titan_forge_company_id',0);
        abort_if($companyId<=0,403);
        return view('titan-forge::history',['builds'=>$this->builds->latestForTenant($companyId)]);
    }
}
