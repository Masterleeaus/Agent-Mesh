<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Rewind;

interface ForgeRewindHistoryReaderContract
{
    /** @return iterable<array{kind:string,record_id:string,occurred_at:string,recorded_at:string,data:array<string,mixed>}> */
    public function facts(int $companyId, string $traceId): iterable;
}
