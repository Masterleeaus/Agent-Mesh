<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Support;

use RuntimeException;

final class ForgeTenantResolver
{
    public function __construct(private readonly string $tenantKey = 'company_id')
    {
        if ($this->tenantKey !== 'company_id') {
            throw new RuntimeException('Titan Forge tenant resolver requires company_id.');
        }
    }

    public function resolveUser(object $user): int
    {
        $value = null;
        if (isset($user->{$this->tenantKey})) {
            $value = $user->{$this->tenantKey};
        } elseif (method_exists($user, 'getAttribute')) {
            $value = $user->getAttribute($this->tenantKey);
        }

        if (is_numeric($value) && (int) $value > 0) {
            return (int) $value;
        }

        throw new RuntimeException('Titan Forge requires an authenticated company_id context.');
    }
}
