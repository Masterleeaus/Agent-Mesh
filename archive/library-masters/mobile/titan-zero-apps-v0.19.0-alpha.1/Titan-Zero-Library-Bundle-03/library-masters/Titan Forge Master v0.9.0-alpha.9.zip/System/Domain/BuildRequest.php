<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildRequest
{
    public function __construct(
        public BuildContext $context,
        public string $targetType,
        public string $instruction,
        public array $inputs = [],
    ) {
        if (! preg_match('/^[a-z][a-z0-9._-]{1,79}$/', $targetType)) {
            throw new InvalidArgumentException('targetType must be a stable lowercase identifier.');
        }
        $instruction = trim($instruction);
        if ($instruction === '' || strlen($instruction) > 20000) {
            throw new InvalidArgumentException('instruction must be non-empty and bounded.');
        }
    }

    public function toArray(): array
    {
        return [
            'context' => $this->context->toArray(),
            'target_type' => $this->targetType,
            'instruction' => $this->instruction,
            'inputs' => $this->inputs,
        ];
    }
}
