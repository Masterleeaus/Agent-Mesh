<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeCommandBusGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\ReleaseGateResult;
use App\Extensions\TitanForge\System\Domain\ValidationResult;

final class ReleaseGovernanceService
{
    public function __construct(
        private readonly ForgeRiskGatewayContract $risk,
        private readonly ForgeShieldGatewayContract $shield,
        private readonly ForgeCouncilGatewayContract $council,
        private readonly ForgeGovernanceGatewayContract $governance,
        private readonly ForgeCommandBusGatewayContract $commandBus,
    ) {}

    public function evaluate(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): ReleaseGateResult
    {
        if (! $localValidation->passed()) {
            return new ReleaseGateResult(
                'rejected',
                true,
                $localValidation,
                \App\Extensions\TitanForge\System\Domain\RiskDeclaration::unavailable('titan-risk:not-evaluated'),
                CouncilReview::notRequired(),
                $this->governance->available(),
                $this->commandBus->available(),
                ['local_validation.blocked'],
            );
        }

        $reasons = [];
        $shieldAvailable = $this->shield->available();
        $shieldValidation = $this->shield->inspect($spec, $artifacts, $localValidation);
        if (! $shieldAvailable) {
            $reasons[] = 'shield.unavailable';
        } elseif (! $shieldValidation->passed()) {
            $reasons[] = 'shield.blocked';
        }

        $riskAvailable = $this->risk->available();
        $risk = $this->risk->assess($spec, $artifacts, $localValidation);
        if (! $riskAvailable || $risk->level === 'unavailable') {
            $reasons[] = 'risk.unavailable';
        }

        $directive = strtoupper((string) ($risk->metadata['execution_directive'] ?? ''));
        if ($directive === 'DENY') {
            $reasons[] = 'risk.denied';
        }

        $requiresCouncil = in_array($risk->level, ['high', 'critical'], true);
        $council = CouncilReview::notRequired();
        if ($requiresCouncil) {
            $council = $this->council->available()
                ? $this->council->deliberate($spec, $artifacts, $risk, $shieldValidation)
                : CouncilReview::unavailable();
            if (! $council->available) {
                $reasons[] = 'council.unavailable';
            } elseif ($council->status === 'configuration_required') {
                $reasons[] = 'council.configuration_required';
            } elseif (! $council->satisfied()) {
                $reasons[] = 'council.review_unsatisfied';
            }
        }

        if (! $this->governance->available()) {
            $reasons[] = 'governance.' . ($this->governance->unavailableReason() ?? 'unavailable');
        }
        if (! $this->commandBus->available()) {
            $reasons[] = 'command_bus.' . ($this->commandBus->unavailableReason() ?? 'unavailable');
        }

        $hardReject = ($shieldAvailable && ! $shieldValidation->passed()) || $directive === 'DENY';
        if ($hardReject) {
            $status = 'rejected';
            $blocked = true;
        } else {
            $holds = ! $shieldAvailable
                || ! $riskAvailable
                || $risk->blocked
                || ($requiresCouncil && ! $council->satisfied())
                || ! $this->governance->available()
                || ! $this->commandBus->available();
            $status = $holds ? 'approval_required' : 'validated';
            $blocked = $holds;
        }

        return new ReleaseGateResult(
            $status,
            $blocked,
            $shieldValidation,
            $risk,
            $council,
            $this->governance->available(),
            $this->commandBus->available(),
            array_values(array_unique($reasons)),
        );
    }
}
