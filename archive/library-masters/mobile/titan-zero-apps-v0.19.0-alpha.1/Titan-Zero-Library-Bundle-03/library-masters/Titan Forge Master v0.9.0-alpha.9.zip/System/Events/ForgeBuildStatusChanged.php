<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Events;

final readonly class ForgeBuildStatusChanged
{
    public string $rootCausationId;
    public function __construct(
        public int $buildId,
        public int $companyId,
        public string $status,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $operationId,
        public array $metadata = [],
        ?string $rootCausationId = null,
    ) {
        $this->rootCausationId = $rootCausationId ?? $causationId;
    }
}
