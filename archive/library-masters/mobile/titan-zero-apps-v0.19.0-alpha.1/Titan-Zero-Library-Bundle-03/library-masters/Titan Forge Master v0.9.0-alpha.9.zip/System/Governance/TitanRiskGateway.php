<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use Closure;
use Throwable;

final class TitanRiskGateway implements ForgeRiskGatewayContract
{
    public function __construct(
        private readonly Closure $resolver,
        private readonly string $contract = 'App\\Extensions\\TitanRiskEngine\\System\\Contracts\\RiskGateContract',
        private readonly string $inputClass = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskContextInput',
    ) {}

    public function available(): bool
    {
        $peer = $this->resolve();
        return $peer !== null && method_exists($peer, 'evaluate') && class_exists($this->inputClass);
    }

    public function assess(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): RiskDeclaration
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'evaluate') || ! class_exists($this->inputClass)) {
            return RiskDeclaration::unavailable('titan-risk');
        }

        try {
            $inputClass = $this->inputClass;
            $context = $spec->context;
            $input = new $inputClass(
                $context->companyId,
                $context->traceId,
                $context->correlationId,
                $context->causationId,
                'forge.release_candidate',
                'review',
                'user',
                $context->actorId,
            );
            $result = $peer->evaluate($input);
            $data = is_object($result) && method_exists($result, 'toArray') ? $result->toArray() : [];
            if (! is_array($data)) {
                return RiskDeclaration::unavailable('titan-risk:invalid-result');
            }
            $assessment = is_array($data['assessment'] ?? null) ? $data['assessment'] : [];
            $level = $this->normalizeLevel((string) ($assessment['level'] ?? ''));
            if ($level === 'unavailable') {
                return RiskDeclaration::unavailable('titan-risk:invalid-level');
            }
            $directive = strtoupper(trim((string) ($data['execution_directive'] ?? 'HOLD')));
            $mayDispatch = (bool) ($data['may_dispatch_to_executor'] ?? false);
            $rawReasons = is_array($assessment['reasons'] ?? null) ? $assessment['reasons'] : [];
            $reasons = [];
            foreach ($rawReasons as $reason) {
                if (is_string($reason) && trim($reason) !== '') {
                    $reasons[] = trim($reason);
                    continue;
                }
                if (is_array($reason)) {
                    $code = trim((string) ($reason['code'] ?? ''));
                    $message = trim((string) ($reason['message'] ?? ''));
                    $text = trim(($code !== '' ? $code . ': ' : '') . $message);
                    if ($text !== '') { $reasons[] = $text; }
                }
            }

            return new RiskDeclaration(
                level: $level,
                blocked: ! $mayDispatch,
                provider: 'titan-risk',
                reasons: $reasons,
                metadata: [
                    'execution_directive' => $directive,
                    'may_dispatch_to_executor' => $mayDispatch,
                    'decision' => $assessment['decision'] ?? null,
                    'score' => $assessment['score'] ?? null,
                    'policy_version' => $assessment['policy_version'] ?? null,
                    'remediation' => is_array($assessment['remediation'] ?? null) ? array_values($assessment['remediation']) : [],
                    'artifact_set_hash' => $artifacts->digest(),
                    'validation_fingerprint' => $localValidation->fingerprint(),
                ],
            );
        } catch (Throwable $e) {
            return new RiskDeclaration('unavailable', true, 'titan-risk:error', ['Risk assessment failed closed.'], ['error_class' => $e::class]);
        }
    }

    private function resolve(): ?object
    {
        try {
            $peer = ($this->resolver)($this->contract);
            return is_object($peer) ? $peer : null;
        } catch (Throwable) {
            return null;
        }
    }

    private function normalizeLevel(string $level): string
    {
        return match (strtoupper(trim($level))) {
            'MINIMAL', 'LOW' => 'low',
            'MEDIUM' => 'medium',
            'HIGH' => 'high',
            'EXTREME', 'CRITICAL' => 'critical',
            default => 'unavailable',
        };
    }
}
