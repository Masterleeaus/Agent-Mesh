<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;

final class UnavailableCouncilGateway implements ForgeCouncilGatewayContract
{
    public function available(): bool { return false; }
    public function governedDeliberationAvailable(): bool { return false; }
    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview { return CouncilReview::unavailable(); }
    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview { return CouncilReview::unavailable('governed_deliberation_contract_unavailable'); }
}
