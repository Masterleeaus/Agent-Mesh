<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Generation;

use App\Extensions\TitanForge\System\Domain\BuildArtifact;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use App\Extensions\TitanForge\System\Workforce\RoleCatalog;
use InvalidArgumentException;
use RuntimeException;

final class StaticRoleTemplateEngine
{
    private RoleCatalog $catalog;
    private SandboxWorkspaceFactory $workspaces;

    public function __construct(
        private readonly string $stubPath,
        RoleCatalog $catalog,
        SandboxWorkspaceFactory $workspaces,
    ) {
        if (! is_file($stubPath)) {
            throw new RuntimeException("Role stub not found: {$stubPath}");
        }
        $this->catalog = $catalog;
        $this->workspaces = $workspaces;
    }

    public function generate(BuildSpec $spec): array
    {
        if ($spec->targetType !== 'workforce_team') { throw new InvalidArgumentException('Static role engine supports workforce_team builds only.'); }
        foreach ($spec->roleIds as $roleId) {
            if (! is_string($roleId) || preg_match('/^titan(?:\.[a-z0-9_]+)+$/', $roleId) !== 1) { throw new InvalidArgumentException('Unsafe role ID in build specification.'); }
        }
        $roles=$this->catalog->requireRoles($spec->roleIds);
        $workspace=$this->workspaces->forContext($spec->context);
        $workspace->reset();
        $stub=(string)file_get_contents($this->stubPath);
        foreach($roles as $role){
            $class=$this->className($role['role_definition_id']);
            $php=strtr($stub,['{{ class }}'=>$class,'{{ role_id }}'=>$role['role_definition_id'],'{{ role_php }}'=>var_export($role,true)]);
            $json=json_encode($role,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
            $workspace->write('roles/'.$class.'.php',$php);
            $workspace->write('roles/'.str_replace('.','-',$role['role_definition_id']).'.json',$json);
        }
        $pre=$workspace->snapshot();
        $files=$this->receipts($pre->artifacts);
        $manifest=[
            'schema_version'=>'1.0','generator'=>'titan-forge-static-role-template-engine','build_type'=>$spec->targetType,'tier'=>$spec->tier,
            'company_id'=>$spec->context->companyId,'actor_id'=>$spec->context->actorId,'trace_id'=>$spec->context->traceId,
            'correlation_id'=>$spec->context->correlationId,'causation_id'=>$spec->context->causationId,'root_causation_id'=>$spec->context->rootCausationId,'operation_id'=>$spec->context->operationId,
            'idempotency_key'=>$spec->context->idempotencyKey,'role_ids'=>array_values($spec->roleIds),'files'=>$files,'deployment_authority'=>'none'
        ];
        $manifestSha=hash('sha256',json_encode($manifest,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
        $manifest['manifest_sha256']=$manifestSha;
        $workspace->write('generation_manifest.json',json_encode($manifest,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n");
        $artifacts=$workspace->snapshot();
        return [
            'workspace'=>$workspace->rootPath(),
            'manifest_sha256'=>$manifestSha,
            'files'=>$this->receipts($artifacts->artifacts),
            'manifest'=>$manifest,
            'artifacts'=>$artifacts,
        ];
    }

    private function className(string $roleId): string
    {
        $parts=preg_split('/_+/',substr($roleId,strlen('titan.')))?:[];
        return implode('',array_map(static fn(string $p):string=>ucfirst($p),$parts)).'Role';
    }

    /** @param list<BuildArtifact> $artifacts */
    private function receipts(array $artifacts): array
    {
        $files=array_map(static fn(BuildArtifact $a):array=>['path'=>$a->path,'sha256'=>$a->sha256,'bytes'=>$a->sizeBytes],$artifacts);
        usort($files,static fn(array $a,array $b):int=>$a['path']<=>$b['path']);
        return $files;
    }
}
