<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Persistence;

use App\Extensions\TitanForge\System\Contracts\ReleaseRepositoryContract;
use App\Extensions\TitanForge\System\Domain\ReleaseCandidate;
use App\Extensions\TitanForge\System\Domain\ReleaseGateResult;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
use App\Extensions\TitanForge\System\Models\ForgeReleaseCandidate;
use App\Extensions\TitanForge\System\Models\ForgeReceipt;
use LogicException;

final class EloquentReleaseRepository implements ReleaseRepositoryContract
{
    public function recordCandidate(ForgeBuild $build, int $validationRunId, ReleaseCandidate $candidate, ReleaseGateResult $gate): ForgeReleaseCandidate
    {
        if ($validationRunId <= 0) {
            throw new LogicException('Release candidate requires a persisted validation run.');
        }
        if ((int) $build->getKey() !== $candidate->buildId) {
            throw new LogicException('Release candidate build does not match persistence target.');
        }

        $councilReceiptId = null;
        if ($gate->council->required) {
            $receipt = ForgeReceipt::query()->firstOrCreate(
                [
                    'build_id' => (int) $build->getKey(),
                    'company_id' => (int) $build->company_id,
                    'receipt_type' => 'council.deliberation',
                    'receipt_hash' => $gate->council->fingerprint(),
                ],
                [
                    'payload' => [
                        'schema' => 'titan.forge.council-review-receipt.v1',
                        'council_review' => $gate->council->toArray(),
                        'trace_id' => (string) $build->trace_id,
                        'correlation_id' => (string) $build->correlation_id,
                        'causation_id' => (string) $build->causation_id,
                        'root_causation_id' => (string) ($build->root_causation_id ?: $build->causation_id),
                        'operation_id' => (string) $build->operation_id,
                        'actor_id' => (int) $build->actor_id,
                        'deployment_authority' => 'none',
                    ],
                ],
            );
            $councilReceiptId = (int) $receipt->getKey();
        }

        return ForgeReleaseCandidate::query()->updateOrCreate(
            [
                'build_id' => (int) $build->getKey(),
                'validation_run_id' => $validationRunId,
            ],
            [
                'company_id' => (int) $build->company_id,
                'artifact_set_hash' => $candidate->artifactSetHash,
                'validation_fingerprint' => $candidate->validationFingerprint,
                'status' => $candidate->status,
                'metadata' => [
                    'gate_fingerprint' => $gate->fingerprint(),
                    'gate' => $gate->toArray(),
                    'council_review_receipt_id' => $councilReceiptId,
                    'trace_id' => (string) $build->trace_id,
                    'correlation_id' => (string) $build->correlation_id,
                    'causation_id' => (string) $build->causation_id,
                    'root_causation_id' => (string) ($build->root_causation_id ?: $build->causation_id),
                    'operation_id' => (string) $build->operation_id,
                    'actor_id' => (int) $build->actor_id,
                    'deployment_authority' => 'none',
                ],
            ],
        );
    }

    public function findCandidateForTenant(int $companyId, int $candidateId): ?ForgeReleaseCandidate
    {
        if ($companyId <= 0 || $candidateId <= 0) {
            return null;
        }
        return ForgeReleaseCandidate::query()
            ->where('company_id', $companyId)
            ->whereKey($candidateId)
            ->first();
    }
}
