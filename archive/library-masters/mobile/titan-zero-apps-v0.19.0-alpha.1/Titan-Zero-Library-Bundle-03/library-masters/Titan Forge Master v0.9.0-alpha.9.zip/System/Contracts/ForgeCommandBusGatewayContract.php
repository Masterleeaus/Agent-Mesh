<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

interface ForgeCommandBusGatewayContract
{
    public function available(): bool;

    public function unavailableReason(): ?string;
}
