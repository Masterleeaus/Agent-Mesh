<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Config;

use InvalidArgumentException;

final readonly class ForgeConfiguration
{
    public function __construct(
        public bool $enabled,
        public string $queue,
        public string $tenantKey,
        public int $maxBuildFiles = 2000,
        public int $maxArtifactBytes = 104857600,
    ) {
        if (! preg_match('/^[a-z0-9][a-z0-9._-]{0,63}$/', $queue)) {
            throw new InvalidArgumentException('Forge queue name is invalid.');
        }
        if ($tenantKey !== 'company_id') {
            throw new InvalidArgumentException('Forge tenant key must be company_id.');
        }
        if ($maxBuildFiles < 1 || $maxBuildFiles > 100000) {
            throw new InvalidArgumentException('Forge maxBuildFiles is outside the allowed range.');
        }
        if ($maxArtifactBytes < 1024 || $maxArtifactBytes > 1073741824) {
            throw new InvalidArgumentException('Forge maxArtifactBytes is outside the allowed range.');
        }
    }

    public static function fromArray(array $config): self
    {
        if (! array_key_exists('enabled', $config) || ! is_bool($config['enabled'])) {
            throw new InvalidArgumentException('Forge enabled flag must be boolean.');
        }
        return new self(
            enabled: $config['enabled'],
            queue: (string) ($config['queue'] ?? ''),
            tenantKey: (string) ($config['tenant_key'] ?? ''),
            maxBuildFiles: (int) ($config['max_build_files'] ?? 2000),
            maxArtifactBytes: (int) ($config['max_artifact_bytes'] ?? 104857600),
        );
    }
}
