<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class AiPlanningResult
{
    public function __construct(
        public bool $contractAvailable,
        public bool $usable,
        public string $reasonCode,
        public ?BuildPlan $plan = null,
        public array $validation = [],
        public array $provenance = [],
    ) {
        if (! preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', $reasonCode)) {
            throw new InvalidArgumentException('AI planning reason code must be a stable identifier.');
        }
        if ($usable && $plan === null) {
            throw new InvalidArgumentException('Usable AI planning result requires a BuildPlan.');
        }
        if (self::containsForbiddenReasoningKey($validation) || self::containsForbiddenReasoningKey($provenance)) {
            throw new InvalidArgumentException('Hidden model reasoning must never be persisted in Forge planning results.');
        }
    }

    public function toArray(): array
    {
        return [
            'contract_available' => $this->contractAvailable,
            'usable' => $this->usable,
            'reason_code' => $this->reasonCode,
            'plan' => $this->plan?->toArray(),
            'validation' => $this->validation,
            'provenance' => $this->provenance,
        ];
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode(self::canonicalize($this->toArray()), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function containsForbiddenReasoningKey(mixed $value): bool
    {
        if (! is_array($value)) { return false; }
        foreach ($value as $key => $item) {
            if (is_string($key)) {
                $normalized = strtolower(str_replace(['-', ' '], '_', $key));
                if (in_array($normalized, ['chain_of_thought', 'hidden_reasoning', 'reasoning_trace', 'private_reasoning'], true)) {
                    return true;
                }
            }
            if (self::containsForbiddenReasoningKey($item)) { return true; }
        }
        return false;
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) { return $value; }
        if (array_is_list($value)) { return array_map(self::canonicalize(...), $value); }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) { $value[$key] = self::canonicalize($item); }
        return $value;
    }
}
