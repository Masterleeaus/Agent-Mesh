<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\AI;

use App\Extensions\TitanForge\System\Contracts\ForgeAiArtifactGatewayContract;
use App\Extensions\TitanForge\System\Domain\AiArtifactProposal;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;

final readonly class UnavailableAiArtifactGateway implements ForgeAiArtifactGatewayContract
{
    public function __construct(private string $reason = 'titan_ai_core_generation_contract_unavailable') {}
    public function available(): bool { return false; }
    public function propose(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): AiArtifactProposal
    {
        return AiArtifactProposal::unavailable('titan-ai-core', $plan->fingerprint(), $this->reason);
    }
}
