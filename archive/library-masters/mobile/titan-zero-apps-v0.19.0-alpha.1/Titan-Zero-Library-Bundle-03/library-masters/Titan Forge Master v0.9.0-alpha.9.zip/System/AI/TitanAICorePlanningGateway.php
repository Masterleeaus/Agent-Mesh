<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\AI;

use App\Extensions\TitanForge\System\Contracts\ForgeAiPlanningGatewayContract;
use App\Extensions\TitanForge\System\Domain\AiPlanningResult;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildStep;
use Throwable;

final class TitanAICorePlanningGateway implements ForgeAiPlanningGatewayContract
{
    private const ORCHESTRATOR = 'App\\Extensions\\TitanAICore\\System\\Contracts\\OrchestratorContract';
    private const VALIDATOR = 'App\\Extensions\\TitanAICore\\System\\Contracts\\PlanValidatorContract';
    private const ACTOR = 'App\\Extensions\\TitanAICore\\System\\DTO\\ActorContext';
    private const INTENT = 'App\\Extensions\\TitanAICore\\System\\DTO\\ExecutionIntent';
    private const RUNTIME = 'App\\Extensions\\TitanAICore\\System\\DTO\\RuntimeContext';

    /** @param callable(string):?object $peerResolver */
    public function __construct(private readonly mixed $peerResolver) {}

    public function available(): bool
    {
        if (! is_callable($this->peerResolver)) { return false; }
        foreach ([self::ACTOR, self::INTENT, self::RUNTIME] as $class) {
            if (! class_exists($class)) { return false; }
        }
        return $this->resolve(self::ORCHESTRATOR) !== null && $this->resolve(self::VALIDATOR) !== null;
    }

    public function plan(BuildRequest $request): AiPlanningResult
    {
        if (! $this->available()) {
            return new AiPlanningResult(false, false, 'ai_core_planning_contract_unavailable');
        }

        try {
            $actorClass = self::ACTOR;
            $intentClass = self::INTENT;
            $runtimeClass = self::RUNTIME;
            $context = $request->context;
            $actor = new $actorClass((string) $context->actorId, 'user', (string) $context->companyId, [], 0, true);
            $intent = new $intentClass('forge.build.plan', $request->instruction, [
                'consumer' => 'titan-forge',
                'target_type' => $request->targetType,
                'inputs' => $request->inputs,
                'deployment_authority' => 'none',
                'mutation_boundary' => 'none',
            ]);
            $runtime = new $runtimeClass(
                (string) $context->companyId,
                $actor,
                $context->traceId,
                $context->correlationId,
                $context->causationId,
                $context->rootCausationId,
                $context->operationId,
                $context->idempotencyKey,
                'INTERNAL',
                ['consumer' => 'titan-forge', 'target_type' => $request->targetType],
            );

            $orchestrator = $this->resolve(self::ORCHESTRATOR);
            $validator = $this->resolve(self::VALIDATOR);
            $planEnvelope = $orchestrator?->createPlan($intent, $runtime);
            if (! is_object($planEnvelope) || ! method_exists($planEnvelope, 'toArray')) {
                return new AiPlanningResult(true, false, 'ai_core_plan_invalid_shape');
            }
            $planArray = $planEnvelope->toArray();
            if (! is_array($planArray) || ! $this->contextMatches($planArray, $request)) {
                return new AiPlanningResult(true, false, 'ai_core_plan_context_mismatch');
            }

            $report = $validator?->validate($planEnvelope);
            $validation = is_object($report) && method_exists($report, 'toArray') ? $report->toArray() : [];
            if (! is_array($validation) || ($validation['valid'] ?? false) !== true) {
                return new AiPlanningResult(true, false, 'ai_core_plan_not_valid', null, is_array($validation) ? $validation : [], $this->provenance($planArray, $validation));
            }

            $steps = $planArray['steps'] ?? null;
            if (! is_array($steps) || $steps === []) {
                return new AiPlanningResult(true, false, 'ai_core_plan_empty', null, $validation, $this->provenance($planArray, $validation));
            }

            $buildSteps = [];
            foreach ($steps as $step) {
                if (! is_array($step)) { return new AiPlanningResult(true, false, 'ai_core_plan_mapping_failed', null, $validation, $this->provenance($planArray, $validation)); }
                $dependencies = [];
                foreach ((array) ($step['depends_on'] ?? []) as $dependency) {
                    if (! is_array($dependency) || ! is_string($dependency['step_id'] ?? null)) {
                        return new AiPlanningResult(true, false, 'ai_core_plan_mapping_failed', null, $validation, $this->provenance($planArray, $validation));
                    }
                    $dependencies[] = $dependency['step_id'];
                }
                $buildSteps[] = new BuildStep(
                    (string) ($step['step_id'] ?? ''),
                    (string) ($step['action'] ?? ''),
                    $dependencies,
                    [
                        'name' => (string) ($step['name'] ?? ''),
                        'required_inputs' => (array) ($step['required_inputs'] ?? []),
                        'optional_inputs' => (array) ($step['optional_inputs'] ?? []),
                        'outputs' => (array) ($step['outputs'] ?? []),
                        'timeout_seconds' => (int) ($step['timeout_seconds'] ?? 30),
                        'retry_policy' => (array) ($step['retry_policy'] ?? []),
                        'workforce_assignment' => $step['workforce_assignment'] ?? null,
                        'risk_ceiling' => $step['risk_ceiling'] ?? null,
                        'knowledge_requirements' => (array) ($step['knowledge_requirements'] ?? []),
                    ],
                );
            }
            $plan = new BuildPlan($buildSteps);
            return new AiPlanningResult(true, true, 'ai_core_plan_usable', $plan, $validation, $this->provenance($planArray, $validation) + [
                'forge_build_plan_fingerprint' => $plan->fingerprint(),
            ]);
        } catch (Throwable $e) {
            return new AiPlanningResult(true, false, 'ai_core_plan_mapping_failed', null, [], [
                'source' => 'titan-ai-core',
                'error_class' => $e::class,
                'deployment_authority' => 'none',
            ]);
        }
    }

    private function resolve(string $contract): ?object
    {
        try {
            $resolved = ($this->peerResolver)($contract);
            return is_object($resolved) ? $resolved : null;
        } catch (Throwable) {
            return null;
        }
    }

    private function contextMatches(array $plan, BuildRequest $request): bool
    {
        $runtime = $plan['runtime_context'] ?? null;
        if (! is_array($runtime)) { return false; }
        $context = $request->context;
        return (string) ($runtime['company_id'] ?? '') === (string) $context->companyId
            && (string) ($runtime['trace_id'] ?? '') === $context->traceId
            && (string) ($runtime['correlation_id'] ?? '') === $context->correlationId
            && (string) ($runtime['causation_id'] ?? '') === $context->causationId
            && (string) ($runtime['root_causation_id'] ?? '') === $context->rootCausationId
            && (string) ($runtime['operation_id'] ?? '') === $context->operationId
            && (string) ($runtime['idempotency_key'] ?? '') === $context->idempotencyKey;
    }

    private function provenance(array $plan, array $validation): array
    {
        return [
            'source' => 'titan-ai-core',
            'planning_contract' => 'titan.orchestration-planning.v1',
            'source_plan_id' => (string) ($plan['plan_id'] ?? ''),
            'source_schema_version' => (string) ($plan['plan_schema_version'] ?? $plan['schema_version'] ?? ''),
            'source_runtime_version' => (string) ($plan['runtime_version'] ?? ''),
            'source_plan_sha256' => hash('sha256', json_encode($this->canonicalize($plan), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)),
            'validator_version' => (string) ($validation['validator_version'] ?? ''),
            'ai_core_executable' => (bool) ($validation['executable'] ?? false),
            'deployment_authority' => 'none',
        ];
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) { return $value; }
        if (array_is_list($value)) { return array_map(fn($v) => $this->canonicalize($v), $value); }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) { $value[$key] = $this->canonicalize($item); }
        return $value;
    }
}
