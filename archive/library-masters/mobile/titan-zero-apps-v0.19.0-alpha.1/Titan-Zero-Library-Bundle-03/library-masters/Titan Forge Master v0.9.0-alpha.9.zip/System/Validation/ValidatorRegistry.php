<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation;

use InvalidArgumentException;

final readonly class ValidatorRegistry
{
    /** @var list<ArtifactValidatorContract> */
    private array $validators;

    public function __construct(array $validators)
    {
        $seen = [];
        $normalized = [];
        foreach ($validators as $validator) {
            if (! $validator instanceof ArtifactValidatorContract) {
                throw new InvalidArgumentException('Forge validator registry accepts ArtifactValidatorContract instances only.');
            }
            $id = $validator->id();
            if (preg_match('/^[a-z][a-z0-9._-]{1,79}$/', $id) !== 1) {
                throw new InvalidArgumentException('Forge validator ID is invalid.');
            }
            if (isset($seen[$id])) {
                throw new InvalidArgumentException("Duplicate Forge validator ID: {$id}");
            }
            $seen[$id] = true;
            $normalized[] = $validator;
        }
        if ($normalized === []) {
            throw new InvalidArgumentException('Forge validator registry cannot be empty.');
        }
        $this->validators = $normalized;
    }

    public function all(): array { return $this->validators; }
    public function ids(): array { return array_map(static fn (ArtifactValidatorContract $v): string => $v->id(), $this->validators); }
}
