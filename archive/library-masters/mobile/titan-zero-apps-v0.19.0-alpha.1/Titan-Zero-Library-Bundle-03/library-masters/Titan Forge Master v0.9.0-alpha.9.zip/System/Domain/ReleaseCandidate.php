<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ReleaseCandidate
{
    public function __construct(
        public int $buildId,
        public string $artifactSetHash,
        public string $validationFingerprint,
        public string $status = 'draft',
    ) {
        if ($buildId <= 0) {
            throw new InvalidArgumentException('ReleaseCandidate buildId must be positive.');
        }
        foreach ([$artifactSetHash, $validationFingerprint] as $hash) {
            if (! preg_match('/^[a-f0-9]{64}$/', $hash)) {
                throw new InvalidArgumentException('ReleaseCandidate hashes must be SHA-256 values.');
            }
        }
        if (! in_array($status, ['draft', 'validated', 'approval_required', 'approved', 'rejected', 'released'], true)) {
            throw new InvalidArgumentException('ReleaseCandidate status is invalid.');
        }
    }
}
