<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use Closure;
use Throwable;

final class TitanShieldGateway implements ForgeShieldGatewayContract
{
    private const DEFINITION_KEY = 'forge_artifact_validation';
    private const DEFINITION_VERSION = '1.0.0';

    public function __construct(
        private readonly Closure $resolver,
        private readonly string $contract = 'App\\Extensions\\TitanShield\\System\\Contracts\\ShieldManagerContract',
        private readonly string $contextClass = 'App\\Extensions\\TitanShield\\System\\Context\\ShieldExecutionContext',
    ) {}

    public function available(): bool
    {
        $peer = $this->resolve();
        return $peer !== null
            && method_exists($peer, 'health')
            && method_exists($peer, 'determineGovernanceResponse')
            && class_exists($this->contextClass);
    }

    public function inspect(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): ValidationResult
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'health') || ! method_exists($peer, 'determineGovernanceResponse') || ! class_exists($this->contextClass)) {
            return ValidationResult::fail(['Titan Shield is unavailable for Forge release review.']);
        }

        try {
            $health = $peer->health();
            if (! is_array($health) || in_array(strtolower((string) ($health['status'] ?? '')), ['failed', 'error', 'unavailable'], true)) {
                return ValidationResult::fail(['Titan Shield health gate is unavailable.']);
            }
            if ($localValidation->findings === []) {
                return ValidationResult::pass($localValidation->warnings);
            }

            $contextClass = $this->contextClass;
            $ctx = $spec->context;
            $shieldContext = new $contextClass($ctx->companyId, $ctx->traceId, $ctx->correlationId, $ctx->causationId, $ctx->actorId, 'titan-forge');
            $definitionHash = hash('sha256', self::DEFINITION_KEY . ':' . self::DEFINITION_VERSION);
            $findings = [];
            foreach ($localValidation->findings as $index => $finding) {
                $severity = $this->shieldSeverity($finding->severity);
                $mapped = [
                    'finding_id' => hash('sha256', $spec->fingerprint() . ':' . $index . ':' . $finding->rule),
                    'definition_key' => self::DEFINITION_KEY,
                    'definition_version' => self::DEFINITION_VERSION,
                    'definition_hash' => $definitionHash,
                    'code' => $finding->rule,
                    'severity' => $severity,
                    'outcome' => $finding->blocking ? 'fail' : 'conditional_pass',
                    'subject_type' => 'forge_build',
                    'subject_id' => $ctx->operationId,
                    'reason_codes' => [$finding->rule],
                ];
                $response = $peer->determineGovernanceResponse($mapped, $shieldContext);
                $response = is_array($response) ? $response : [];
                $blocking = $finding->blocking || (bool) ($response['block_progression'] ?? false);
                $findings[] = new ValidationFinding(
                    severity: $blocking ? ($severity === 'critical' ? 'critical' : 'error') : $finding->severity,
                    rule: 'shield.' . $finding->rule,
                    message: $finding->message,
                    file: $finding->file,
                    blocking: $blocking,
                    line: $finding->line,
                    metadata: [
                        'local_rule' => $finding->rule,
                        'shield_governance_response' => $response,
                        'artifact_set_hash' => $artifacts->digest(),
                    ],
                );
            }
            return new ValidationResult($findings, warnings: $localValidation->warnings);
        } catch (Throwable $e) {
            return ValidationResult::fail(['Titan Shield review failed closed: ' . $e::class]);
        }
    }

    private function resolve(): ?object
    {
        try {
            $peer = ($this->resolver)($this->contract);
            return is_object($peer) ? $peer : null;
        } catch (Throwable) {
            return null;
        }
    }

    private function shieldSeverity(string $severity): string
    {
        return match ($severity) {
            'info' => 'info',
            'warning' => 'medium',
            'error' => 'high',
            'critical' => 'critical',
            default => 'medium',
        };
    }
}
