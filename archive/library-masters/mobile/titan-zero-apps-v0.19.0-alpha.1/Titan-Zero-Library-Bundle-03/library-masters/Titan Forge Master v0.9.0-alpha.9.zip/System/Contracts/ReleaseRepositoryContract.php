<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\ReleaseCandidate;
use App\Extensions\TitanForge\System\Domain\ReleaseGateResult;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
use App\Extensions\TitanForge\System\Models\ForgeReleaseCandidate;

interface ReleaseRepositoryContract
{
    public function recordCandidate(ForgeBuild $build, int $validationRunId, ReleaseCandidate $candidate, ReleaseGateResult $gate): ForgeReleaseCandidate;

    public function findCandidateForTenant(int $companyId, int $candidateId): ?ForgeReleaseCandidate;
}
