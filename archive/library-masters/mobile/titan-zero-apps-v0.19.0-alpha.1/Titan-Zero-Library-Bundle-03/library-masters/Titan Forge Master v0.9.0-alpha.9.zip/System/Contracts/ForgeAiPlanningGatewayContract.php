<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\AiPlanningResult;
use App\Extensions\TitanForge\System\Domain\BuildRequest;

interface ForgeAiPlanningGatewayContract
{
    public function available(): bool;
    public function plan(BuildRequest $request): AiPlanningResult;
}
