<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Rewind;

use InvalidArgumentException;
use RuntimeException;

final class ForgeRewindProjector
{
    private const KIND_MAP = [
        'build' => ['event_type' => 'forge.build.registered', 'rank' => 1],
        'plan' => ['event_type' => 'forge.plan.persisted', 'rank' => 2],
        'artifact' => ['event_type' => 'forge.artifact.generated', 'rank' => 3],
        'validation' => ['event_type' => 'forge.validation.completed', 'rank' => 4],
        'shield' => ['event_type' => 'forge.shield.governance_response', 'rank' => 5],
        'risk' => ['event_type' => 'forge.risk.assessed', 'rank' => 6],
        'council' => ['event_type' => 'forge.council.deliberated', 'rank' => 7],
        'governance' => ['event_type' => 'forge.governance.gate', 'rank' => 8],
        'release_candidate' => ['event_type' => 'forge.release.candidate', 'rank' => 9],
        'receipt' => ['event_type' => 'forge.receipt.observed', 'rank' => 10],
    ];

    private const KIND_SEQUENCE_STRIDE = 1_000_000_000_000_000;

    /** @return iterable<array<string,mixed>> */
    public function project(int $companyId, string $traceId, iterable $facts): iterable
    {
        $this->assertScope($companyId, $traceId);
        $previousHash = null;
        $previousSequence = null;

        foreach ($facts as $rawFact) {
            $fact = $this->prepareFact($rawFact);
            $sequence = (int) $fact['sequence'];
            if ($previousSequence !== null && $sequence <= $previousSequence) {
                throw new RuntimeException('Forge Rewind facts must arrive in strictly increasing deterministic source order.');
            }

            $event = $this->eventFromFact($companyId, $traceId, $fact, $previousHash);
            $previousHash = $event['integrity_hash'];
            $previousSequence = $sequence;
            yield $event;
        }
    }

    /** @param array<string,mixed> $event */
    public function verify(array $event): bool
    {
        $expected = (string) ($event['integrity_hash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $expected) !== 1) {
            return false;
        }
        $copy = $event;
        unset($copy['integrity_hash']);
        return hash_equals($expected, self::hashCanonical($copy));
    }

    /** @param array<string,mixed> $fact @return array<string,mixed> */
    private function prepareFact(array $fact): array
    {
        $kind = (string) ($fact['kind'] ?? '');
        if (! isset(self::KIND_MAP[$kind])) {
            throw new InvalidArgumentException('Unknown Forge Rewind fact kind.');
        }
        $recordId = trim((string) ($fact['record_id'] ?? ''));
        if ($recordId === '') {
            throw new InvalidArgumentException('Forge Rewind fact requires a record id.');
        }
        $occurredAt = $this->dateTime((string) ($fact['occurred_at'] ?? ''));
        $recordedAt = $this->dateTime((string) ($fact['recorded_at'] ?? $occurredAt));
        $data = (array) ($fact['data'] ?? []);
        $this->assertSafe($data);
        return [
            'kind' => $kind,
            'record_id' => $recordId,
            'occurred_at' => $occurredAt,
            'recorded_at' => $recordedAt,
            'data' => $data,
            'sequence' => (self::KIND_MAP[$kind]['rank'] * self::KIND_SEQUENCE_STRIDE) + $this->numericRecordSuffix($recordId),
        ];
    }

    /** @param array<string,mixed> $fact @return array<string,mixed> */
    private function eventFromFact(int $companyId, string $traceId, array $fact, ?string $previousHash): array
    {
        $data = $fact['data'];
        $sourceHash = self::hashCanonical([
            'kind' => $fact['kind'],
            'record_id' => $fact['record_id'],
            'occurred_at' => $fact['occurred_at'],
            'recorded_at' => $fact['recorded_at'],
            'data' => $data,
        ]);
        $eventId = $this->deterministicUuid($companyId . '|' . $traceId . '|' . $fact['record_id'] . '|' . $sourceHash);
        $event = [
            'schema_version' => '1.0',
            'company_id' => $companyId,
            'event_id' => $eventId,
            'trace_id' => $traceId,
            'correlation_id' => $this->uuidOrNull($data['correlation_id'] ?? null),
            'causation_id' => $this->uuidOrNull($data['causation_id'] ?? null),
            'source_engine' => 'titan-forge',
            'source_record_id' => $fact['record_id'],
            'event_type' => self::KIND_MAP[$fact['kind']]['event_type'],
            'sequence' => $fact['sequence'],
            'occurred_at' => $fact['occurred_at'],
            'recorded_at' => $fact['recorded_at'],
            'tier' => isset($data['tier']) ? (string) $data['tier'] : null,
            'lane' => isset($data['lane']) ? (string) $data['lane'] : null,
            'actor_type' => isset($data['actor_id']) ? 'user' : null,
            'actor_id' => isset($data['actor_id']) && $data['actor_id'] !== null ? (string) $data['actor_id'] : null,
            'decision_id' => isset($data['decision_id']) && $data['decision_id'] !== null ? (string) $data['decision_id'] : null,
            'policy_version' => null,
            'guide_version' => isset($data['template_version']) ? (string) $data['template_version'] : null,
            'knowledge_version' => null,
            'model_provider' => isset($data['model_provider']) ? (string) $data['model_provider'] : null,
            'model_name' => isset($data['model_name']) ? (string) $data['model_name'] : null,
            'model_version' => isset($data['model_version']) ? (string) $data['model_version'] : null,
            'capability_name' => $this->capabilityForKind((string) $fact['kind']),
            'capability_version' => '1.0',
            'risk_state' => $fact['kind'] === 'risk' ? $this->boundedRisk($data) : null,
            'assurance_state' => null,
            'autonomy_state' => null,
            'governance_state' => $fact['kind'] === 'governance' ? $this->boundedGovernance($data) : null,
            'reason_codes' => $this->reasonCodes($data),
            'evidence_refs' => $this->evidenceRefs($fact['kind'], $data),
            'rationale' => null,
            'payload' => $this->boundedPayload((string) $fact['kind'], $data),
            'source_hash' => $sourceHash,
            'previous_hash' => $previousHash,
        ];
        $event['integrity_hash'] = self::hashCanonical($event);
        return $event;
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    private function boundedPayload(string $kind, array $data): array
    {
        $allowed = match ($kind) {
            'build' => ['build_id','status','target_type','spec_fingerprint','operation_id','root_causation_id'],
            'plan' => ['build_id','fingerprint','source','source_plan_id','source_schema_version','source_runtime_version'],
            'artifact' => ['build_id','path','sha256','type','size_bytes','generation_mode','model_route','prompt_sha256','input_sha256','output_sha256','generation_manifest_sha256','build_plan_fingerprint'],
            'validation' => ['build_id','status','fingerprint','finding_count','blocking_count','validator_count'],
            'shield' => ['build_id','candidate_id','valid','finding_count','blocking_count','fingerprint'],
            'risk' => ['build_id','candidate_id','level','blocked','provider','execution_directive'],
            'council' => ['build_id','candidate_id','status','decision_id','confidence_percent','actual_participant_count','requires_escalation','execution_authority','receipt_hash','final_answer_sha256','role_models_sha256'],
            'governance' => ['build_id','candidate_id','available','reason'],
            'release_candidate' => ['build_id','candidate_id','status','artifact_set_hash','validation_fingerprint','gate_fingerprint','deployment_authority'],
            'receipt' => ['build_id','receipt_id','receipt_type','receipt_hash'],
            default => [],
        };
        $payload = [];
        foreach ($allowed as $key) {
            if (array_key_exists($key, $data)) {
                $payload[$key] = $data[$key];
            }
        }
        foreach (['operation_id','root_causation_id'] as $key) {
            if (array_key_exists($key, $data) && $data[$key] !== null && $data[$key] !== '') {
                $payload[$key] = $data[$key];
            }
        }
        $this->assertSafe($payload);
        return $payload;
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    private function boundedRisk(array $data): array
    {
        return array_filter([
            'level' => $data['level'] ?? null,
            'blocked' => $data['blocked'] ?? null,
            'provider' => $data['provider'] ?? null,
            'execution_directive' => $data['execution_directive'] ?? null,
        ], static fn (mixed $v): bool => $v !== null);
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    private function boundedGovernance(array $data): array
    {
        return array_filter([
            'available' => $data['available'] ?? null,
            'reason' => $data['reason'] ?? null,
        ], static fn (mixed $v): bool => $v !== null);
    }

    /** @param array<string,mixed> $data @return list<string> */
    private function reasonCodes(array $data): array
    {
        $codes = [];
        if (isset($data['reason']) && is_string($data['reason']) && $data['reason'] !== '') {
            $codes[] = $data['reason'];
        }
        if (isset($data['reason_codes']) && is_array($data['reason_codes'])) {
            foreach ($data['reason_codes'] as $code) {
                if (is_string($code) && $code !== '') {
                    $codes[] = $code;
                }
            }
        }
        return array_values(array_unique($codes));
    }

    /** @param array<string,mixed> $data @return list<string> */
    private function evidenceRefs(string $kind, array $data): array
    {
        $refs = [];
        foreach (['spec_fingerprint','fingerprint','sha256','artifact_set_hash','validation_fingerprint','gate_fingerprint','receipt_hash','prompt_sha256','input_sha256','output_sha256','generation_manifest_sha256','build_plan_fingerprint','final_answer_sha256','role_models_sha256'] as $key) {
            $value = $data[$key] ?? null;
            if (is_string($value) && preg_match('/^[a-f0-9]{64}$/', $value) === 1) {
                $refs[] = 'sha256:' . $value;
            }
        }
        if (isset($data['decision_id'])) {
            $refs[] = 'titan-model-council:decision:' . (string) $data['decision_id'];
        }
        if (isset($data['candidate_id'])) {
            $refs[] = 'titan-forge:release-candidate:' . (string) $data['candidate_id'];
        }
        if (isset($data['build_id'])) {
            $refs[] = 'titan-forge:build:' . (string) $data['build_id'];
        }
        return array_values(array_unique($refs));
    }

    private function capabilityForKind(string $kind): string
    {
        return match ($kind) {
            'plan' => 'forge.ai.plan.consume',
            'artifact' => 'forge.ai.artifact.sandbox',
            'validation' => 'forge.validate.artifacts',
            'shield' => 'forge.shield.governance-response',
            'risk' => 'forge.risk.assess',
            'council' => 'forge.council.deliberate',
            'release_candidate' => 'forge.release.candidate',
            default => 'forge.build.inspect',
        };
    }

    private function numericRecordSuffix(string $recordId): int
    {
        if (preg_match('/:(\d+)(?::|$)/', $recordId, $m) === 1) {
            $digits = ltrim($m[1], '0');
            $digits = $digits === '' ? '0' : $digits;
            $max = (string) (self::KIND_SEQUENCE_STRIDE - 1);
            if (strlen($digits) > strlen($max) || (strlen($digits) === strlen($max) && strcmp($digits, $max) > 0)) {
                throw new RuntimeException('Forge Rewind record id exceeds the deterministic sequence range.');
            }
            return (int) $digits;
        }

        $prefix = substr(hash('sha256', $recordId), 0, 12);
        return (int) (hexdec($prefix) % (self::KIND_SEQUENCE_STRIDE - 1));
    }

    private function deterministicUuid(string $seed): string
    {
        $hex = substr(hash('sha256', $seed), 0, 32);
        $hex[12] = '5';
        $variant = hexdec($hex[16]);
        $hex[16] = dechex(($variant & 0x3) | 0x8);
        return substr($hex,0,8).'-'.substr($hex,8,4).'-'.substr($hex,12,4).'-'.substr($hex,16,4).'-'.substr($hex,20,12);
    }

    private function uuidOrNull(mixed $value): ?string
    {
        if (! is_string($value) || $value === '') {
            return null;
        }
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1 ? strtolower($value) : null;
    }

    private function dateTime(string $value): string
    {
        try {
            return (new \DateTimeImmutable($value))->format(DATE_ATOM);
        } catch (\Throwable) {
            throw new InvalidArgumentException('Forge Rewind fact timestamp must be ISO-8601 compatible.');
        }
    }

    private function assertScope(int $companyId, string $traceId): void
    {
        if ($companyId < 1 || preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $traceId) !== 1) {
            throw new InvalidArgumentException('Forge Rewind source requires a positive tenant and UUID trace.');
        }
    }

    private function assertSafe(mixed $value): void
    {
        if (! is_array($value)) {
            return;
        }
        foreach ($value as $key => $child) {
            if (is_string($key) && preg_match('/^(chain[_-]?of[_-]?thought|cot|hidden[_-]?reasoning|private[_-]?reasoning|reasoning[_-]?content)$/i', $key) === 1) {
                throw new RuntimeException('Private reasoning is forbidden in Forge Rewind evidence.');
            }
            $this->assertSafe($child);
        }
    }

    private static function hashCanonical(mixed $value): string
    {
        return hash('sha256', json_encode(self::canonicalize($value), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map([self::class, 'canonicalize'], $value);
        }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $child) {
            $value[$key] = self::canonicalize($child);
        }
        return $value;
    }
}
