<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ValidationFinding
{
    public function __construct(
        public string $severity,
        public string $rule,
        public string $message,
        public ?string $file = null,
        public bool $blocking = false,
        public ?int $line = null,
        public array $metadata = [],
    ) {
        if (! in_array($severity, ['info', 'warning', 'error', 'critical'], true)) {
            throw new InvalidArgumentException('Unknown validation severity.');
        }
        if ($rule === '' || $message === '') {
            throw new InvalidArgumentException('Validation finding requires rule and message.');
        }
        if ($line !== null && $line <= 0) {
            throw new InvalidArgumentException('Validation line must be positive.');
        }
    }

    public function toArray(): array
    {
        return [
            'severity' => $this->severity,
            'rule' => $this->rule,
            'message' => $this->message,
            'file' => $this->file,
            'line' => $this->line,
            'blocking' => $this->blocking,
            'metadata' => $this->metadata,
        ];
    }
}
