<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildArtifact;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use Closure;
use Throwable;

final class TitanCouncilGateway implements ForgeCouncilGatewayContract
{
    private const REQUIRED_ROLES = ['proposer', 'critic', 'verifier', 'arbiter'];

    /** @param array<string,string> $roleModels */
    public function __construct(
        private readonly Closure $resolver,
        private readonly string $contract = 'App\\Extensions\\TitanModelCouncil\\System\\Contracts\\CouncilGatewayContract',
        private readonly string $requestClass = 'App\\Extensions\\TitanModelCouncil\\System\\ValueObjects\\CouncilRequest',
        private readonly array $roleModels = [],
    ) {}

    public function available(): bool
    {
        $peer = $this->resolve();
        return $peer !== null
            && method_exists($peer, 'health')
            && method_exists($peer, 'decideActivation')
            && class_exists($this->requestClass);
    }

    public function governedDeliberationAvailable(): bool
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'health') || ! method_exists($peer, 'runGoverned') || ! class_exists($this->requestClass)) {
            return false;
        }
        try {
            $health = $peer->health();
            return is_array($health) && (($health['governed_deliberation'] ?? false) === true);
        } catch (Throwable) {
            return false;
        }
    }

    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'health') || ! method_exists($peer, 'decideActivation') || ! class_exists($this->requestClass)) {
            return CouncilReview::unavailable();
        }

        try {
            $request = $this->makeRequest($spec, $risk, $shieldValidation, null, 'activation_assessment');
            $activation = $peer->decideActivation($request);
            $activationData = is_object($activation) && method_exists($activation, 'toArray') ? $activation->toArray() : [];
            $health = $peer->health();
            $health = is_array($health) ? $health : [];

            return new CouncilReview(
                required: true,
                available: true,
                status: 'activation_assessed',
                provider: 'titan-model-council',
                metadata: [
                    'activation' => is_array($activationData) ? $activationData : [],
                    'governed_deliberation' => (bool) ($health['governed_deliberation'] ?? false),
                    'health_status' => $health['status'] ?? null,
                    'health_version' => $health['version'] ?? null,
                ],
            );
        } catch (Throwable $e) {
            return new CouncilReview(true, false, 'unavailable', 'titan-model-council', ['error_class' => $e::class]);
        }
    }

    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        $peer = $this->resolve();
        if ($peer === null || ! method_exists($peer, 'health') || ! method_exists($peer, 'decideActivation') || ! method_exists($peer, 'runGoverned') || ! class_exists($this->requestClass)) {
            return CouncilReview::unavailable('governed_deliberation_contract_unavailable');
        }
        if (! $this->trustedRoleModelsConfigured()) {
            return CouncilReview::configurationRequired();
        }

        try {
            $health = $peer->health();
            if (! is_array($health) || (($health['governed_deliberation'] ?? false) !== true)) {
                return CouncilReview::unavailable('peer_governed_deliberation_not_ready');
            }

            $request = $this->makeRequest($spec, $risk, $shieldValidation, $artifacts, 'governed_deliberation');
            $activation = $peer->decideActivation($request);
            $activationData = is_object($activation) && method_exists($activation, 'toArray') ? $activation->toArray() : [];
            if (($activationData['strategy'] ?? null) !== 'governed_deliberation') {
                return new CouncilReview(true, true, 'escalated', 'titan-model-council', [
                    'reason' => 'peer_activation_did_not_select_governed_deliberation',
                    'activation' => $this->boundedActivation($activationData),
                    'execution_authority' => 'advisory_only',
                ]);
            }

            $outcome = $peer->runGoverned($request, $this->canonicalRoleModels());
            return $this->normalizeGovernedOutcome(is_array($outcome) ? $outcome : []);
        } catch (Throwable $e) {
            return new CouncilReview(true, false, 'failed', 'titan-model-council', [
                'reason' => 'governed_deliberation_exception',
                'error_class' => $e::class,
            ]);
        }
    }

    private function makeRequest(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation, ?ArtifactSet $artifacts, string $surface): object
    {
        $ctx = $spec->context;
        $requestClass = $this->requestClass;
        $packet = $this->boundedPacket($spec, $risk, $shieldValidation, $artifacts);
        $prompt = 'Titan Forge governed release candidate review packet. Review only the bounded metadata below. '
            . 'Do not execute, deploy, mutate state, request secrets, or infer hidden chain-of-thought. '
            . 'Return advisory evidence for Governance. Packet=' . json_encode($packet, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);

        return new $requestClass(
            $prompt,
            $ctx->companyId,
            $ctx->actorId,
            $surface === 'governed_deliberation' ? 'governed_deliberation' : null,
            $risk->level,
            [
                'build_spec_fingerprint' => $spec->fingerprint(),
                'validation_fingerprint' => $shieldValidation->fingerprint(),
                'artifact_set_digest' => $artifacts?->digest(),
                'risk_provider' => $risk->provider,
                'risk_directive' => $risk->metadata['execution_directive'] ?? null,
                'request_surface' => 'titan-forge:' . $surface,
                'source' => 'titan-forge',
                'deployment_authority' => 'none',
            ],
            $ctx->traceId,
            $ctx->correlationId,
            $ctx->causationId,
            $ctx->rootCausationId,
        );
    }

    /** @return array<string,mixed> */
    private function boundedPacket(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation, ?ArtifactSet $artifacts): array
    {
        $artifactRows = [];
        if ($artifacts !== null) {
            $rows = $artifacts->artifacts;
            usort($rows, static fn (BuildArtifact $a, BuildArtifact $b): int => strcmp($a->path, $b->path));
            foreach (array_slice($rows, 0, 50) as $artifact) {
                $artifactRows[] = [
                    'path' => $artifact->path,
                    'sha256' => $artifact->sha256,
                    'type' => $artifact->type,
                    'size_bytes' => $artifact->sizeBytes,
                ];
            }
        }

        $riskReasons = [];
        foreach (array_slice($risk->reasons, 0, 10) as $reason) {
            $riskReasons[] = substr(trim((string) $reason), 0, 500);
        }

        return [
            'schema' => 'titan.forge.council-review-packet.v1',
            'target_type' => $spec->targetType,
            'build_spec_fingerprint' => $spec->fingerprint(),
            'artifact_set_digest' => $artifacts?->digest(),
            'artifact_count' => $artifacts?->count() ?? 0,
            'artifacts' => $artifactRows,
            'validation_fingerprint' => $shieldValidation->fingerprint(),
            'validation_passed' => $shieldValidation->passed(),
            'validation_error_count' => count($shieldValidation->errors),
            'validation_warning_count' => count($shieldValidation->warnings),
            'risk' => [
                'level' => $risk->level,
                'provider' => $risk->provider,
                'blocked' => $risk->blocked,
                'execution_directive' => $risk->metadata['execution_directive'] ?? null,
                'reasons' => $riskReasons,
            ],
            'deployment_authority' => 'none',
        ];
    }

    /** @param array<string,mixed> $outcome */
    private function normalizeGovernedOutcome(array $outcome): CouncilReview
    {
        $result = is_array($outcome['result'] ?? null) ? $outcome['result'] : $outcome;
        $outerStatus = strtolower(trim((string) ($outcome['status'] ?? '')));
        $status = strtolower(trim((string) ($result['status'] ?? $outerStatus)));
        $executionAuthority = trim((string) ($result['execution_authority'] ?? 'advisory_only')) ?: 'advisory_only';
        $requiresEscalation = (($result['requires_escalation'] ?? false) === true)
            || (($result['postflight_risk']['requires_escalation'] ?? false) === true);

        if ($executionAuthority !== 'advisory_only') {
            $reviewStatus = 'rejected';
            $reason = 'council_execution_authority_exceeded';
        } elseif ($outerStatus === 'rejected' || $status === 'rejected') {
            $reviewStatus = 'rejected';
            $reason = 'council_rejected_review';
        } elseif ($outerStatus === 'failed' || $status === 'failed') {
            $reviewStatus = 'failed';
            $reason = 'council_deliberation_failed';
        } elseif ($requiresEscalation || in_array($status, ['blocked', 'escalated'], true)) {
            $reviewStatus = 'escalated';
            $reason = 'council_requires_escalation';
        } elseif ($status === 'completed') {
            $reviewStatus = 'deliberated';
            $reason = 'council_deliberation_completed';
        } else {
            $reviewStatus = 'failed';
            $reason = 'council_unrecognized_outcome';
        }

        $finalAnswer = is_string($result['final_answer'] ?? null) ? (string) $result['final_answer'] : '';
        $roleModels = $this->canonicalRoleModels();
        $metadata = [
            'reason' => $reason,
            'decision_id' => isset($outcome['decision_id']) ? (int) $outcome['decision_id'] : null,
            'strategy' => (string) ($result['strategy'] ?? 'governed_deliberation'),
            'requires_escalation' => $requiresEscalation,
            'confidence_percent' => isset($result['confidence_percent']) ? (int) $result['confidence_percent'] : null,
            'actual_participant_count' => isset($result['actual_participant_count']) ? (int) $result['actual_participant_count'] : null,
            'execution_authority' => $executionAuthority,
            'final_answer_sha256' => $finalAnswer !== '' ? hash('sha256', $finalAnswer) : null,
            'role_models_sha256' => hash('sha256', json_encode($roleModels, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES)),
            'postflight_risk_level' => is_array($result['postflight_risk'] ?? null) ? ($result['postflight_risk']['level'] ?? null) : null,
        ];

        return new CouncilReview(true, true, $reviewStatus, 'titan-model-council', $metadata);
    }

    private function trustedRoleModelsConfigured(): bool
    {
        $models = $this->canonicalRoleModels();
        if (array_keys($models) !== self::REQUIRED_ROLES) {
            return false;
        }
        foreach ($models as $model) {
            if ($model === '' || strlen($model) > 160) {
                return false;
            }
        }
        return count(array_unique(array_values($models))) >= 3;
    }

    /** @return array<string,string> */
    private function canonicalRoleModels(): array
    {
        $models = [];
        foreach (self::REQUIRED_ROLES as $role) {
            $models[$role] = trim((string) ($this->roleModels[$role] ?? ''));
        }
        return $models;
    }

    /** @param array<string,mixed> $activation */
    private function boundedActivation(array $activation): array
    {
        return [
            'strategy' => $activation['strategy'] ?? null,
            'activation_reason' => $activation['activation_reason'] ?? null,
            'requested_participant_count' => $activation['requested_participant_count'] ?? null,
        ];
    }

    private function resolve(): ?object
    {
        try {
            $peer = ($this->resolver)($this->contract);
            return is_object($peer) ? $peer : null;
        } catch (Throwable) {
            return null;
        }
    }
}
