<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeApproval extends Model
{
    protected $table = 'titan_forge_approvals';

    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array'
    ];
}
