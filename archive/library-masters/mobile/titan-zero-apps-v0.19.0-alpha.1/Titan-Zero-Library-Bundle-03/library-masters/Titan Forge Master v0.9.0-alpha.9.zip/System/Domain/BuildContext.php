<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildContext
{
    public string $rootCausationId;

    public function __construct(
        public int $companyId,
        public int $actorId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $operationId,
        public string $idempotencyKey,
        ?string $rootCausationId = null,
    ) {
        $this->rootCausationId = $rootCausationId ?? $causationId;
        if ($companyId <= 0) {
            throw new InvalidArgumentException('companyId must be a positive integer.');
        }
        if ($actorId <= 0) {
            throw new InvalidArgumentException('actorId must be a positive integer.');
        }
        foreach (['traceId' => $traceId, 'correlationId' => $correlationId, 'causationId' => $causationId, 'rootCausationId' => $this->rootCausationId, 'operationId' => $operationId] as $name => $value) {
            if (! self::isUuid($value)) {
                throw new InvalidArgumentException($name . ' must be a UUID.');
            }
        }
        if ($idempotencyKey === '' || strlen($idempotencyKey) > 190 || ! preg_match('/^[A-Za-z0-9][A-Za-z0-9:._-]*$/', $idempotencyKey)) {
            throw new InvalidArgumentException('idempotencyKey contains invalid characters or length.');
        }
    }

    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'actor_id' => $this->actorId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'operation_id' => $this->operationId,
            'idempotency_key' => $this->idempotencyKey,
        ];
    }

    private static function isUuid(string $value): bool
    {
        return (bool) preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $value);
    }
}
