<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ArtifactSet
{
    /** @param list<BuildArtifact> $artifacts */
    public function __construct(public array $artifacts)
    {
        $paths = [];
        foreach ($artifacts as $artifact) {
            if (! $artifact instanceof BuildArtifact) {
                throw new InvalidArgumentException('ArtifactSet accepts BuildArtifact instances only.');
            }
            $key = strtolower($artifact->path);
            if (isset($paths[$key])) {
                throw new InvalidArgumentException('Artifact paths must be unique case-insensitively.');
            }
            $paths[$key] = true;
        }
    }

    public function count(): int
    {
        return count($this->artifacts);
    }

    public function digest(): string
    {
        $items = array_map(static fn (BuildArtifact $artifact): array => $artifact->toArray(), $this->artifacts);
        usort($items, static fn (array $a, array $b): int => strcmp($a['path'], $b['path']));
        return hash('sha256', json_encode($items, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }
}
