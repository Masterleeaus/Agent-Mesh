<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation\Validators;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;

final class GeneratedCodeSafetyValidator implements ArtifactValidatorContract
{
    public function id(): string { return 'generated-code-safety'; }
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array
    {
        $findings=[]; $pattern='/\b(?:eval|shell_exec|exec|system|passthru|proc_open|popen)\s*\(/i';
        foreach($artifacts->artifacts as $artifact){
            if($artifact->type!=='php' && $artifact->type!=='blade'){continue;}
            $data=file_get_contents($workspace->path($artifact->path)); if(!is_string($data)){continue;}
            if(preg_match($pattern,$data)===1){$findings[]=new ValidationFinding('critical','generated.unsafe_primitive','Generated PHP contains a forbidden execution primitive.',$artifact->path,true);}
        }
        return $findings;
    }
}
