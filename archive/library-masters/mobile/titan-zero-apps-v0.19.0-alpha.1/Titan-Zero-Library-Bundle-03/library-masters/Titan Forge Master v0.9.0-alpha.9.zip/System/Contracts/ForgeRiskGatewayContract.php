<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Contracts;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
interface ForgeRiskGatewayContract
{
    public function available(): bool;
    public function assess(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): RiskDeclaration;
}
