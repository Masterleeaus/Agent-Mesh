<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildArtifact
{
    public function __construct(
        public string $path,
        public string $sha256,
        public string $type,
        public int $sizeBytes,
        public array $metadata = [],
    ) {
        if (! self::isSafeRelativePath($path)) {
            throw new InvalidArgumentException('Artifact path is unsafe.');
        }
        if (! preg_match('/^[a-f0-9]{64}$/', $sha256)) {
            throw new InvalidArgumentException('Artifact sha256 is invalid.');
        }
        if (! preg_match('/^[a-z][a-z0-9._-]{0,79}$/', $type)) {
            throw new InvalidArgumentException('Artifact type is invalid.');
        }
        if ($sizeBytes < 0) {
            throw new InvalidArgumentException('Artifact size cannot be negative.');
        }
    }

    public function toArray(): array
    {
        return [
            'path' => $this->path,
            'sha256' => $this->sha256,
            'type' => $this->type,
            'size_bytes' => $this->sizeBytes,
            'metadata' => $this->metadata,
        ];
    }

    private static function isSafeRelativePath(string $path): bool
    {
        if ($path === '' || str_contains($path, "\0") || str_contains($path, '\\') || str_starts_with($path, '/')) {
            return false;
        }
        $parts = explode('/', $path);
        foreach ($parts as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                return false;
            }
        }
        return true;
    }
}
