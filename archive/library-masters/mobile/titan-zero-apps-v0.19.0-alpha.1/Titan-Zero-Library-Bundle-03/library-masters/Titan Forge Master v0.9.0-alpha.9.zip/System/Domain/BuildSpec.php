<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildSpec
{
    public string $type;

    public function __construct(
        public BuildContext $context,
        public string $targetType,
        public string $instruction,
        public array $inputs = [],
        public string $tier = 'none',
        public array $roleIds = [],
        public array $metadata = [],
        public int $schemaVersion = 1,
    ) {
        $this->type = $targetType;
        if (! preg_match('/^[a-z][a-z0-9._-]{1,79}$/', $targetType)) { throw new InvalidArgumentException('Build target type is invalid.'); }
        if (trim($instruction) === '' || strlen($instruction) > 20000) { throw new InvalidArgumentException('Build instruction must be non-empty and bounded.'); }
        if ($schemaVersion < 1) { throw new InvalidArgumentException('Build schema version must be positive.'); }
        if ($targetType === 'workforce_team' && ($tier === '' || $tier === 'none' || $roleIds === [])) { throw new InvalidArgumentException('Workforce team tier and roles are required.'); }
        if (count($roleIds) !== count(array_unique($roleIds))) { throw new InvalidArgumentException('Duplicate role IDs are not allowed.'); }
    }

    public static function fromRequest(BuildRequest $request): self
    {
        return new self($request->context, $request->targetType, trim($request->instruction), self::canonicalize($request->inputs));
    }

    public static function workforceTeam(BuildContext $context, string $tier, array $roleIds, array $metadata = []): self
    {
        $roleIds = array_values($roleIds);
        return new self(
            context: $context,
            targetType: 'workforce_team',
            instruction: 'Assemble a deterministic Titan AI Workforce team from canonical role definitions.',
            inputs: ['tier'=>$tier,'role_ids'=>$roleIds],
            tier: $tier,
            roleIds: $roleIds,
            metadata: $metadata,
        );
    }

    public function toArray(): array
    {
        $base = [
            'schema_version' => $this->schemaVersion,
            'target_type' => $this->targetType,
            'instruction' => $this->instruction,
            'inputs' => $this->inputs,
            'context' => $this->context->toArray(),
        ];
        if ($this->targetType !== 'workforce_team') {
            return $base; // preserves the v0.3 BuildSpec fingerprint contract
        }
        return $base + [
            'tier' => $this->tier,
            'role_ids' => $this->roleIds,
            'metadata' => $this->metadata,
        ];
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode(self::canonicalize($this->toArray()), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) { return $value; }
        if (array_is_list($value)) { return array_map(self::canonicalize(...), $value); }
        ksort($value, SORT_STRING);
        foreach ($value as $key=>$item) { $value[$key]=self::canonicalize($item); }
        return $value;
    }
}
