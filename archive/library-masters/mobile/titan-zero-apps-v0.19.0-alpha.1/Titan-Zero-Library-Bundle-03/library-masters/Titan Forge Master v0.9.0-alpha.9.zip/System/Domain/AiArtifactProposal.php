<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class AiArtifactProposal
{
    /** @param list<array{path:string,content:string}> $files */
    public function __construct(
        public bool $usable,
        public string $source,
        public string $sourcePlanId,
        public array $files = [],
        public array $provenance = [],
        public string $reasonCode = 'ai_artifact_proposal_usable',
    ) {
        if (! preg_match('/^[a-z0-9][a-z0-9._-]{1,79}$/', $source)) {
            throw new InvalidArgumentException('AI artifact proposal source is invalid.');
        }
        if ($sourcePlanId === '' || strlen($sourcePlanId) > 190) {
            throw new InvalidArgumentException('AI artifact proposal requires a bounded source plan ID.');
        }
        if (! preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', $reasonCode)) {
            throw new InvalidArgumentException('AI artifact proposal reason code is invalid.');
        }
        if ($usable && $files === []) {
            throw new InvalidArgumentException('Usable AI artifact proposal must contain files.');
        }
        foreach ($files as $file) {
            if (! is_array($file) || ! is_string($file['path'] ?? null) || ! is_string($file['content'] ?? null) || $file['path'] === '') {
                throw new InvalidArgumentException('AI artifact proposal files must contain path and content strings.');
            }
        }
        if (self::containsForbiddenReasoningKey($provenance)) {
            throw new InvalidArgumentException('Hidden model reasoning must never be persisted in Forge artifact provenance.');
        }
        if ($usable) {
            foreach (['model_provider','model_id','model_route','prompt_sha256','input_sha256','output_sha256','template_version'] as $required) {
                if (! is_string($provenance[$required] ?? null) || $provenance[$required] === '') {
                    throw new InvalidArgumentException("AI artifact provenance requires {$required}.");
                }
            }
            foreach (['prompt_sha256','input_sha256','output_sha256'] as $hash) {
                if (preg_match('/^[a-f0-9]{64}$/', (string) $provenance[$hash]) !== 1) {
                    throw new InvalidArgumentException("AI artifact provenance {$hash} must be SHA-256.");
                }
            }
        }
    }

    public static function unavailable(string $source, string $sourcePlanId, string $reasonCode): self
    {
        return new self(false, $source, $sourcePlanId, [], [], $reasonCode);
    }

    public function receipt(): array
    {
        return [
            'usable' => $this->usable,
            'source' => $this->source,
            'source_plan_id' => $this->sourcePlanId,
            'reason_code' => $this->reasonCode,
            'file_count' => count($this->files),
            'files' => array_map(static fn(array $file): array => [
                'path' => $file['path'],
                'sha256' => hash('sha256', $file['content']),
                'bytes' => strlen($file['content']),
            ], $this->files),
            'provenance' => $this->provenance,
        ];
    }

    private static function containsForbiddenReasoningKey(mixed $value): bool
    {
        if (! is_array($value)) { return false; }
        foreach ($value as $key => $item) {
            if (is_string($key)) {
                $normalized = strtolower(str_replace(['-', ' '], '_', $key));
                if (in_array($normalized, ['chain_of_thought','hidden_reasoning','reasoning_trace','private_reasoning'], true)) { return true; }
            }
            if (self::containsForbiddenReasoningKey($item)) { return true; }
        }
        return false;
    }
}
