<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Persistence;

use App\Extensions\TitanForge\System\Contracts\BuildRepositoryContract;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Models\ForgeArtifact;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
use App\Extensions\TitanForge\System\Models\ForgeBuildSpec;
use App\Extensions\TitanForge\System\Models\ForgeBuildPlan;
use App\Extensions\TitanForge\System\Models\ForgeValidationFinding;
use App\Extensions\TitanForge\System\Models\ForgeValidationRun;
use Illuminate\Support\Facades\DB;
use LogicException;

final class EloquentBuildRepository implements BuildRepositoryContract
{
    public function createOrFind(BuildRequest $request, BuildSpec $spec): ForgeBuild
    {
        $context=$request->context; $fingerprint=$spec->fingerprint();
        return DB::transaction(function () use ($request,$spec,$context,$fingerprint): ForgeBuild {
            $build=ForgeBuild::query()->firstOrCreate(
                ['company_id'=>$context->companyId,'idempotency_key'=>$context->idempotencyKey],
                ['trace_id'=>$context->traceId,'correlation_id'=>$context->correlationId,'causation_id'=>$context->causationId,
                 'root_causation_id'=>$context->rootCausationId,'operation_id'=>$context->operationId,'actor_id'=>$context->actorId,'spec_fingerprint'=>$fingerprint,
                 'type'=>$request->targetType,'status'=>'registered','payload'=>['instruction'=>$request->instruction,'inputs'=>$request->inputs]]
            );
            if (! hash_equals((string)$build->spec_fingerprint,$fingerprint)) { throw new LogicException('Idempotency key is already bound to a different Forge build specification.'); }
            $stored=ForgeBuildSpec::query()->firstOrCreate(
                ['build_id'=>$build->getKey()],
                ['company_id'=>$context->companyId,'schema_version'=>$spec->schemaVersion,'fingerprint'=>$fingerprint,
                 'target_type'=>$spec->targetType,'instruction'=>$spec->instruction,'inputs'=>$spec->inputs,'context'=>$spec->context->toArray()]
            );
            if (! hash_equals((string)$stored->fingerprint,$fingerprint)) { throw new LogicException('Stored Forge build specification does not match the idempotent request.'); }
            return $build;
        });
    }

    public function findForTenant(int $companyId,int $buildId): ?ForgeBuild
    {
        if ($companyId<=0 || $buildId<=0) { return null; }
        return ForgeBuild::query()->where('company_id',$companyId)->whereKey($buildId)->first();
    }

    public function latestForTenant(int $companyId,int $limit=50): array
    {
        if ($companyId<=0) { return []; }
        return ForgeBuild::query()->where('company_id',$companyId)->latest('id')->limit(max(1,min($limit,100)))->get()->all();
    }

    public function latest(int $limit=100): array
    {
        return ForgeBuild::query()->latest('id')->limit(max(1,min($limit,200)))->get()->all();
    }

    public function markStatus(ForgeBuild $build,string $status,array $payload=[]): ForgeBuild
    {
        if (! in_array($status,['registered','queued','planning','planning_blocked','planned','generation_blocked','generating','generated','validating','validation_failed','validated','failed'],true)) { throw new LogicException('Unsupported Forge build status transition target.'); }
        $build->status=$status;
        if ($payload!==[]) { $build->payload=array_replace_recursive((array)$build->payload,$payload); }
        $build->save();
        return $build->refresh();
    }

    public function recordPlan(ForgeBuild $build,BuildPlan $plan,array $provenance=[]): int
    {
        $fingerprint=$plan->fingerprint();
        $stored=ForgeBuildPlan::query()->firstOrCreate(
            ['build_id'=>$build->getKey()],
            [
                'company_id'=>(int)$build->company_id,
                'fingerprint'=>$fingerprint,
                'steps'=>$plan->toArray(),
                'source'=>(string)($provenance['source']??'deterministic'),
                'source_plan_id'=>($provenance['source_plan_id']??null) ?: null,
                'source_schema_version'=>($provenance['source_schema_version']??null) ?: null,
                'source_runtime_version'=>($provenance['source_runtime_version']??null) ?: null,
                'provenance'=>$provenance,
            ]
        );
        if (! hash_equals((string)$stored->fingerprint,$fingerprint)) { throw new LogicException('Forge build already has a different persisted plan for this idempotent build.'); }
        return (int)$stored->getKey();
    }

    public function recordArtifacts(ForgeBuild $build,array $files,array $metadata=[]): void
    {
        foreach ($files as $file) {
            $path=(string)($file['path']??''); $sha=(string)($file['sha256']??'');
            if ($path==='' || preg_match('/^[a-f0-9]{64}$/',$sha)!==1) { throw new LogicException('Invalid Forge artifact receipt.'); }
            ForgeArtifact::query()->updateOrCreate(
                ['build_id'=>$build->getKey(),'path'=>$path],
                ['company_id'=>(int)$build->company_id,'sha256'=>$sha,'type'=>str_ends_with($path,'.json')?'json':'php',
                 'size_bytes'=>(int)($file['bytes']??0),'metadata'=>$metadata]
            );
        }
    }

    public function recordValidation(ForgeBuild $build,array $validatorIds,ValidationResult $result): int
    {
        return DB::transaction(function () use ($build,$validatorIds,$result): int {
            $run=ForgeValidationRun::query()->create([
                'build_id'=>$build->getKey(),
                'company_id'=>(int)$build->company_id,
                'status'=>'running',
                'validator_set'=>array_values($validatorIds),
                'summary'=>[],
                'started_at'=>now(),
            ]);
            foreach($result->findings as $finding){
                ForgeValidationFinding::query()->create([
                    'validation_run_id'=>$run->getKey(),
                    'build_id'=>$build->getKey(),
                    'company_id'=>(int)$build->company_id,
                    'severity'=>$finding->severity,
                    'rule'=>$finding->rule,
                    'message'=>$finding->message,
                    'file'=>$finding->file,
                    'line'=>$finding->line,
                    'blocking'=>$finding->blocking,
                    'metadata'=>$finding->metadata,
                ]);
            }
            $blocking=count(array_filter($result->findings,static fn($finding):bool=>$finding->blocking));
            $run->status=$result->passed()?'passed':'failed';
            $run->summary=[
                'valid'=>$result->passed(),
                'fingerprint'=>$result->fingerprint(),
                'finding_count'=>count($result->findings),
                'blocking_count'=>$blocking,
                'errors'=>$result->errors,
                'warnings'=>$result->warnings,
            ];
            $run->completed_at=now();
            $run->save();
            return (int)$run->getKey();
        });
    }

}
