<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Http\Controllers;

use App\Extensions\TitanForge\System\Contracts\BuildRepositoryContract;
use Illuminate\Contracts\View\View;

final class AdminBuildHistoryController
{
    public function __construct(private readonly BuildRepositoryContract $builds) {}
    public function __invoke(): View { return view('titan-forge::admin-history',['builds'=>$this->builds->latest()]); }
}
