<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;

interface ArtifactValidatorContract
{
    public function id(): string;
    /** @return list<\App\Extensions\TitanForge\System\Domain\ValidationFinding> */
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array;
}
