<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeReceipt extends Model
{
    protected $table = 'titan_forge_receipts';

    protected $guarded = [];

    protected $casts = [
        'payload' => 'array'
    ];
}
