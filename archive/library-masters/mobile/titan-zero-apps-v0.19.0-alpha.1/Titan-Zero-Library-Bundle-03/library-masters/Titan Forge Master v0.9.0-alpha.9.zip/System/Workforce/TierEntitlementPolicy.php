<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Workforce;

use App\Extensions\TitanForge\System\Domain\ValidationResult;
use InvalidArgumentException;
use RuntimeException;

final class TierEntitlementPolicy
{
    public function __construct(private readonly array $limits, private readonly array $aliases = []) {}

    public static function fromJsonFile(string $path): self
    {
        if (! is_file($path)) { throw new RuntimeException("Tier policy file not found: {$path}"); }
        $document = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        return new self($document['role_limits'] ?? [], $document['aliases'] ?? []);
    }

    public function maxRoles(string $tier): int
    {
        $tier = $this->normalizeTier($tier);
        if (! isset($this->limits[$tier]) || (int) $this->limits[$tier] <= 0) { throw new InvalidArgumentException("Unknown entitlement tier: {$tier}"); }
        return (int) $this->limits[$tier];
    }

    public function validate(string $tier, array $roleIds): ValidationResult
    {
        try { $limit = $this->maxRoles($tier); } catch (InvalidArgumentException $e) { return ValidationResult::fail([$e->getMessage()]); }
        $errors = [];
        if (count($roleIds) > $limit) { $errors[] = sprintf('Tier %s permits at most %d roles; %d requested.', $this->normalizeTier($tier), $limit, count($roleIds)); }
        if (count($roleIds) !== count(array_unique($roleIds))) { $errors[] = 'Duplicate role IDs are not permitted.'; }
        return $errors === [] ? ValidationResult::pass() : ValidationResult::fail($errors);
    }

    private function normalizeTier(string $tier): string
    {
        $tier = strtolower(trim($tier));
        return (string) (($this->aliases[$tier] ?? null) ?: $tier);
    }
}
