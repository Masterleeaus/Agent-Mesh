<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Rewind;

use App\Support\Extensions\RewindSourceAdapter;
use InvalidArgumentException;
use LogicException;

/**
 * Read-only, authority-neutral Forge contribution to Titan Rewind.
 * It exports bounded durable evidence only; it never mutates Forge, Rewind or domain state.
 */
final class ForgeRewindSource implements RewindSourceAdapter
{
    public function __construct(
        private readonly ForgeRewindHistoryReaderContract $history,
        private readonly ForgeRewindProjector $projector,
    ) {}

    public function sourceKey(): string
    {
        return 'titan-forge.rewind-source';
    }

    public function watermark(int $companyId, string $traceId): array
    {
        $count = 0;
        $observed = null;
        $cursor = null;
        $hashContext = hash_init('sha256');

        foreach ($this->records($companyId, $traceId) as $record) {
            $count++;
            $recordedAt = (string) ($record['recorded_at'] ?? '');
            if ($recordedAt !== '' && ($observed === null || strcmp($recordedAt, $observed) > 0)) {
                $observed = $recordedAt;
            }
            $cursor = $record['source_record_id'] ?? $cursor;
            hash_update($hashContext, ($count === 1 ? '' : "\n") . (string) ($record['integrity_hash'] ?? ''));
        }

        if ($count === 0) {
            return [
                'schema_version' => '1.0',
                'company_id' => $companyId,
                'trace_id' => $traceId,
                'source_engine' => 'titan-forge',
                'source_schema_version' => '1.0',
                'state' => 'UNAVAILABLE',
                'observed_through' => null,
                'cursor' => null,
                'source_lag_ms' => 0,
                'late_event_allowance_ms' => 0,
                'expected_event_count' => null,
                'received_event_count' => 0,
                'authenticity_state' => 'UNVERIFIED',
                'source_hash' => null,
            ];
        }

        $lag = max(0, (int) round((microtime(true) - (new \DateTimeImmutable((string) $observed))->getTimestamp()) * 1000));
        return [
            'schema_version' => '1.0',
            'company_id' => $companyId,
            'trace_id' => $traceId,
            'source_engine' => 'titan-forge',
            'source_schema_version' => '1.0',
            'state' => 'COMPLETE',
            'observed_through' => $observed,
            'cursor' => $cursor,
            'source_lag_ms' => $lag,
            'late_event_allowance_ms' => 0,
            'expected_event_count' => $count,
            'received_event_count' => $count,
            'authenticity_state' => 'VERIFIED',
            'source_hash' => hash_final($hashContext),
        ];
    }

    public function records(int $companyId, string $traceId, ?string $asOf = null): iterable
    {
        if ($companyId < 1 || $traceId === '') {
            throw new InvalidArgumentException('A tenant and trace are required.');
        }
        if ($asOf !== null) {
            throw new LogicException('Forge Rewind as-of reconstruction is not yet supported; mutable build rows prevent a truthful point-in-time claim.');
        }
        foreach ($this->projector->project($companyId, $traceId, $this->history->facts($companyId, $traceId)) as $event) {
            yield $event;
        }
    }
}
