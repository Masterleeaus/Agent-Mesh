<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;

final readonly class ArtifactValidationPipeline
{
    public function __construct(private ValidatorRegistry $registry) {}

    public function validatorIds(): array { return $this->registry->ids(); }

    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): ValidationResult
    {
        $findings = [];
        foreach ($this->registry->all() as $validator) {
            try {
                foreach ($validator->validate($spec, $workspace, $artifacts) as $finding) {
                    if (! $finding instanceof ValidationFinding) {
                        throw new \LogicException('Validator returned a non-finding value.');
                    }
                    $findings[] = $finding;
                }
            } catch (\Throwable $e) {
                $findings[] = new ValidationFinding(
                    'critical',
                    'validator.runtime_failure',
                    'Validator ' . $validator->id() . ' failed closed: ' . $e->getMessage(),
                    blocking: true,
                    metadata: ['validator' => $validator->id(), 'error_class' => $e::class],
                );
            }
        }
        return new ValidationResult($findings);
    }
}
