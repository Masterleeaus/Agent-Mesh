<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Support;

use InvalidArgumentException;

final class ForgeConfigurationValidator
{
    public static function assertValid(array $config): void
    {
        if (! is_bool($config['enabled'] ?? null)) { throw new InvalidArgumentException('titan-forge.enabled must be boolean.'); }
        if (($config['queue'] ?? null) !== 'titan-forge') { throw new InvalidArgumentException('titan-forge.queue must be titan-forge.'); }
        if (($config['tenant_key'] ?? null) !== 'company_id') { throw new InvalidArgumentException('titan-forge.tenant_key must be company_id.'); }
        foreach (['workspace_root','role_registry_path','team_compositions_path','role_stub_path'] as $key) {
            $path = (string) ($config[$key] ?? '');
            $normalized = str_replace('\\', '/', $path);
            if ($path === '' || str_starts_with($normalized, '/') || in_array('..', explode('/', $normalized), true)) {
                throw new InvalidArgumentException("titan-forge.{$key} must be a safe relative path.");
            }
        }

        $council = is_array($config['council'] ?? null) ? $config['council'] : [];
        $models = is_array($council['role_models'] ?? null) ? $council['role_models'] : [];
        $roles = ['proposer', 'critic', 'verifier', 'arbiter'];
        $configured = [];
        foreach ($roles as $role) {
            $value = $models[$role] ?? null;
            if ($value === null || $value === '') {
                continue;
            }
            if (! is_string($value) || strlen(trim($value)) > 160 || trim($value) === '') {
                throw new InvalidArgumentException("titan-forge.council.role_models.{$role} must be a non-empty model slug up to 160 characters.");
            }
            $configured[$role] = trim($value);
        }
        if ($configured !== []) {
            if (count($configured) !== count($roles)) {
                throw new InvalidArgumentException('Titan Forge Council role-model policy must configure all four governed roles or none.');
            }
            if (count(array_unique(array_values($configured))) < 3) {
                throw new InvalidArgumentException('Titan Forge governed Council requires at least three distinct trusted model assignments.');
            }
        }
    }
}
