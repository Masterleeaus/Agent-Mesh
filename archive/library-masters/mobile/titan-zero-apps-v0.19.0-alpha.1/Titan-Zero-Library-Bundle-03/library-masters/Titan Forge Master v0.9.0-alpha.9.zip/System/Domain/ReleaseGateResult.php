<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ReleaseGateResult
{
    /** @param list<string> $reasons */
    public function __construct(
        public string $candidateStatus,
        public bool $blocked,
        public ValidationResult $shieldValidation,
        public RiskDeclaration $risk,
        public CouncilReview $council,
        public bool $governanceAvailable,
        public bool $commandBusAvailable,
        public array $reasons = [],
    ) {
        if (! in_array($candidateStatus, ['validated', 'approval_required', 'rejected'], true)) {
            throw new InvalidArgumentException('Release gate candidate status is invalid.');
        }
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode($this->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'candidate_status' => $this->candidateStatus,
            'blocked' => $this->blocked,
            'shield_validation' => $this->shieldValidation->toArray(),
            'risk' => $this->risk->toArray(),
            'council' => $this->council->toArray(),
            'governance_available' => $this->governanceAvailable,
            'command_bus_available' => $this->commandBusAvailable,
            'reasons' => array_values($this->reasons),
        ];
    }
}
