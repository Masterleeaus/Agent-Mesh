<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

final readonly class GenerationResult
{
    public function __construct(
        public ArtifactSet $artifacts,
        public array $messages = [],
        public bool $complete = true,
    ) {
    }
}
