<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Console\Commands;

use App\Extensions\TitanForge\System\Contracts\ForgeManagerContract;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

final class GenerateSkeletonTeamCommand extends Command
{
    protected $signature = 'forge:generate-skeleton {tier=solo} {--tenant=} {--actor=} {--idempotency=}';
    protected $description = 'Queue a deterministic, non-deploying workforce skeleton build.';

    public function handle(ForgeManagerContract $forge): int
    {
        $tenant=(int)$this->option('tenant'); $actor=(int)$this->option('actor');
        if ($tenant<=0 || $actor<=0) { $this->error('--tenant and --actor must be positive IDs.'); return self::INVALID; }
        $trace=(string)Str::uuid(); $operation=(string)Str::uuid(); $rootCausation=(string)Str::uuid();
        $context=new BuildContext($tenant,$actor,$trace,$trace,$rootCausation,$operation,(string)($this->option('idempotency') ?: 'forge:skeleton:'.$tenant.':'.$operation),$rootCausation);
        try { $build=$forge->queueSkeletonTeam($context,(string)$this->argument('tier')); }
        catch (\Throwable $e) { $this->error($e->getMessage()); return self::FAILURE; }
        $this->info('Queued Forge build #'.$build->getKey().' on titan-forge.');
        return self::SUCCESS;
    }
}
