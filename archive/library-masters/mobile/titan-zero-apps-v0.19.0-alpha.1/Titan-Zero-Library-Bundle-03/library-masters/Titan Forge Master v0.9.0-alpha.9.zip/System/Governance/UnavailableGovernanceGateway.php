<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;

final class UnavailableGovernanceGateway implements ForgeGovernanceGatewayContract
{
    public function __construct(private readonly string $reason = 'health_only_contract') {}
    public function available(): bool { return false; }
    public function unavailableReason(): ?string { return $this->reason; }
}
