<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeBuildSpec extends Model
{
    protected $table = 'titan_forge_build_specs';

    protected $guarded = [];

    protected $casts = [
        'inputs' => 'array',
        'context' => 'array'
    ];
}
