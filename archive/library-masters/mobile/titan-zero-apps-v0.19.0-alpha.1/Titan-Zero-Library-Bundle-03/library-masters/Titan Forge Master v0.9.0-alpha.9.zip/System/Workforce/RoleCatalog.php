<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Workforce;
use InvalidArgumentException; use RuntimeException;
/** Compatibility name: catalogues Forge bindings to Workforce-owned canonical roles; it does not define employees. */
final class RoleCatalog
{
    private array $roles=[];
    private array $aliases=[];
    public function __construct(array $document){
        if(($document['authority']??null)!=='titan-ai-workforce')throw new InvalidArgumentException('Role binding authority must be titan-ai-workforce.');
        if(isset($document['roles']))throw new InvalidArgumentException('Forge must not carry local Workforce employee definitions.');
        foreach($document['bindings']??[] as $binding){$this->assertBinding($binding);$id=(string)$binding['role_definition_id'];if(isset($this->roles[$id]))throw new InvalidArgumentException("Duplicate role_definition_id: {$id}");$this->roles[$id]=$binding;}
        foreach($document['legacy_bootstrap_role_ids']??[] as $alias){$legacy=(string)($alias['legacy_role_id']??'');$canonical=(string)($alias['canonical_role_definition_id']??'');if($legacy!==''&&isset($this->roles[$canonical]))$this->aliases[$legacy]=$canonical;}
        if($this->roles===[])throw new InvalidArgumentException('Forge Workforce binding catalogue cannot be empty.');
    }
    public static function fromJsonFile(string $path):self{if(!is_file($path))throw new RuntimeException("Role binding catalogue not found: {$path}");return new self(json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR));}
    public function all():array{return array_values($this->roles);} public function has(string $roleId):bool{return isset($this->roles[$roleId])||isset($this->aliases[$roleId]);}
    public function get(string $roleId):array{if(isset($this->aliases[$roleId]))$roleId=$this->aliases[$roleId];if(!$this->has($roleId))throw new InvalidArgumentException("Unknown canonical Workforce role binding: {$roleId}");return $this->roles[$roleId];}
    public function requireRoles(array $roleIds):array{return array_map(fn(string $id):array=>$this->get($id),array_values($roleIds));}
    private function assertBinding(mixed $b):void{if(!is_array($b))throw new InvalidArgumentException('Role binding must be an object.');foreach(['role_definition_id','capabilities','authority_inherited'] as $f)if(!array_key_exists($f,$b))throw new InvalidArgumentException("Role binding missing {$f}.");if(preg_match('/^titan(?:\.[a-z0-9_]+)+$/',(string)$b['role_definition_id'])!==1)throw new InvalidArgumentException('Unsafe canonical role ID.');if(($b['authority_inherited']??null)!==false)throw new InvalidArgumentException('Forge bindings must never inherit Workforce authority.');}
}
