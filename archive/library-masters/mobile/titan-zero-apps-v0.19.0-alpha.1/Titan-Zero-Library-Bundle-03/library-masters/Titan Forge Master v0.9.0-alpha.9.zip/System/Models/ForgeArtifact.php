<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeArtifact extends Model
{
    protected $table = 'titan_forge_artifacts';

    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array'
    ];
}
