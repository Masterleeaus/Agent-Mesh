<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeBuild extends Model
{
    protected $table = 'titan_forge_builds';

    protected $guarded = [];

    protected $casts = [
        'payload' => 'array'
    ];
}
