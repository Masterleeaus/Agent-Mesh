<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\AI;

use App\Extensions\TitanForge\System\Contracts\ForgeAiArtifactGatewayContract;
use App\Extensions\TitanForge\System\Domain\BuildArtifact;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use RuntimeException;

final readonly class SandboxedAiArtifactGenerator
{
    public function __construct(
        private ForgeAiArtifactGatewayContract $gateway,
        private SandboxWorkspaceFactory $workspaces,
    ) {}

    public function available(): bool { return $this->gateway->available(); }

    public function generate(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): array
    {
        if (! $this->gateway->available()) {
            throw new RuntimeException('AI artifact generation is unavailable because Titan AI Core exposes no governed artifact-generation contract.');
        }
        if ($request->context->toArray() !== $spec->context->toArray()) {
            throw new RuntimeException('AI generation request/spec context mismatch.');
        }

        $proposal = $this->gateway->propose($request, $spec, $plan);
        if (! $proposal->usable) {
            throw new RuntimeException('AI artifact proposal is not usable: ' . $proposal->reasonCode);
        }

        $workspace = $this->workspaces->forContext($spec->context);
        $workspace->reset();
        foreach ($proposal->files as $file) {
            $workspace->write($file['path'], $file['content']);
        }
        $pre = $workspace->snapshot();
        $files = $this->receipts($pre->artifacts);
        $p = $proposal->provenance;
        $context = $spec->context;
        $manifest = [
            'schema_version' => '2.0',
            'generator' => 'titan-forge-ai-core-artifact-generator',
            'generation_mode' => 'ai-assisted',
            'build_type' => $spec->targetType,
            'build_spec_fingerprint' => $spec->fingerprint(),
            'build_plan_fingerprint' => $plan->fingerprint(),
            'company_id' => $context->companyId,
            'actor_id' => $context->actorId,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'root_causation_id' => $context->rootCausationId,
            'operation_id' => $context->operationId,
            'idempotency_key' => $context->idempotencyKey,
            'context' => $context->toArray(),
            'planner' => [
                'source' => $proposal->source,
                'source_plan_id' => $proposal->sourcePlanId,
                'build_plan_fingerprint' => $plan->fingerprint(),
            ],
            'model' => [
                'provider' => $p['model_provider'],
                'id' => $p['model_id'],
                'route' => $p['model_route'],
            ],
            'provenance' => [
                'prompt_sha256' => $p['prompt_sha256'],
                'input_sha256' => $p['input_sha256'],
                'output_sha256' => $p['output_sha256'],
                'template_version' => $p['template_version'],
                'decision_summary' => $p['decision_summary'] ?? null,
            ],
            'files' => $files,
            'deployment_authority' => 'none',
        ];
        $manifestSha = hash('sha256', json_encode($manifest, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        $manifest['manifest_sha256'] = $manifestSha;
        $workspace->write('generation_manifest.json', json_encode($manifest, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
        $artifacts = $workspace->snapshot();

        return [
            'generation_mode' => 'ai-assisted',
            'workspace' => $workspace->rootPath(),
            'manifest_sha256' => $manifestSha,
            'files' => $this->receipts($artifacts->artifacts),
            'manifest' => $manifest,
            'artifacts' => $artifacts,
            'proposal_receipt' => $proposal->receipt(),
        ];
    }

    /** @param list<BuildArtifact> $artifacts */
    private function receipts(array $artifacts): array
    {
        $files = array_map(static fn(BuildArtifact $artifact): array => [
            'path' => $artifact->path,
            'sha256' => $artifact->sha256,
            'bytes' => $artifact->sizeBytes,
        ], $artifacts);
        usort($files, static fn(array $a, array $b): int => $a['path'] <=> $b['path']);
        return $files;
    }
}
