<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Integration\TitanApps;

/**
 * Provider-owned semantic contributions for the public Titan Apps boundary.
 *
 * This adapter intentionally contains no Interface Runtime, Interaction Engine or Builder
 * implementation and grants no execution authority. Actions remain capability intents.
 */
final class TitanAppsContributionProvider
{
    public const OWNER_EXTENSION = 'titan-forge';
    public const REGISTRY_KEY = 'titan-apps.interface-contributions.' . self::OWNER_EXTENSION;

    /** @return array<int,array<string,mixed>> */
    public function contributions(): array
    {
        return [['contribution_id' => 'forge.build-status', 'owner_extension' => 'titan-forge', 'supported_surfaces' => ['zero'], 'variants' => ['BuildStatus'], 'projection_ids' => ['forge.build.read'], 'action_ids' => ['forge.build.request'], 'capability_ids' => ['forge.build.read', 'forge.build.request'], 'permissions' => ['forge.build.read', 'forge.build.request'], 'sensitivity' => 'internal', 'risk_classification' => 'governed', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability'], ['contribution_id' => 'forge.release-approval', 'owner_extension' => 'titan-forge', 'supported_surfaces' => ['zero'], 'variants' => ['ReleaseApproval'], 'projection_ids' => ['forge.release.read'], 'action_ids' => ['forge.release.approve'], 'capability_ids' => ['forge.release.read', 'forge.release.approve'], 'permissions' => ['forge.release.read', 'forge.release.approve'], 'sensitivity' => 'restricted', 'risk_classification' => 'governed', 'offline_availability' => 'metadata_only', 'data_freshness' => 'runtime', 'fallback_behavior' => 'semantic_text', 'executable_ui' => false, 'grants_authority' => false, 'action_semantics' => 'intent_only', 'execution_boundary' => 'governed_capability']];
    }

    /** @return array<string,mixed> */
    public function contractDescriptor(): array
    {
        return [
            'owner_extension' => self::OWNER_EXTENSION,
            'supported_surfaces' => $this->supportedSurfaces(),
            'canonical_app_boundary' => ['zero', 'go', 'hub'],
            'canonical_surfaces_only' => true,
            'interface_runtime' => 'public_contract_only',
            'interaction_engine' => 'public_contract_only',
            'builder' => 'contribution_registration_only',
            'package_location_independent' => true,
            'authority' => 'none',
        ];
    }
    /** @return array<int,string> */
    private function supportedSurfaces(): array
    {
        $surfaces = [];
        foreach ($this->contributions() as $contribution) {
            foreach (($contribution['supported_surfaces'] ?? []) as $surface) {
                if (is_string($surface) && ! in_array($surface, $surfaces, true)) {
                    $surfaces[] = $surface;
                }
            }
        }

        return $surfaces;
    }

}
