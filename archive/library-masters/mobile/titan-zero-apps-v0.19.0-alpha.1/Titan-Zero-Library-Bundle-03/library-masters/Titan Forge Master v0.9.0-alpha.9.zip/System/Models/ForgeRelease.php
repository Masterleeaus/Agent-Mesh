<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeRelease extends Model
{
    protected $table = 'titan_forge_releases';

    protected $guarded = [];

    protected $casts = [
        'command_receipt' => 'array'
    ];
}
