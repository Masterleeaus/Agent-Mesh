<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Models\ForgeBuild;

interface ForgeManagerContract
{
    public function health(): array;
    public function registerBuild(BuildRequest $request): ForgeBuild;
    public function planBuildWithAi(BuildRequest $request): array;
    public function generateBuildWithAi(BuildRequest $request): array;
    public function findBuildForTenant(int $companyId,int $buildId): ?ForgeBuild;
    public function getManifestForTier(string $tier): array;
    public function validateBuild(BuildSpec $spec): ValidationResult;
    public function queueSkeletonTeam(BuildContext $context,string $tier): ForgeBuild;
    public function generateSkeletonTeam(BuildContext $context,string $tier): array;
}
