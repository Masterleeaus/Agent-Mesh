<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Models;

use Illuminate\Database\Eloquent\Model;

final class ForgeValidationFinding extends Model
{
    protected $table = 'titan_forge_validation_findings';

    protected $guarded = [];

    protected $casts = [
        'blocking' => 'boolean',
        'metadata' => 'array'
    ];
}
