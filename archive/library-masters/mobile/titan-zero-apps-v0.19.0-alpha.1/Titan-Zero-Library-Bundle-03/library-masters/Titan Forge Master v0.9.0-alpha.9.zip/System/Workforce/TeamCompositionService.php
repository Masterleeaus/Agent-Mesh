<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Workforce;

use InvalidArgumentException;
use LogicException;
use RuntimeException;

final class TeamCompositionService
{
    public function __construct(private readonly array $document, private readonly RoleCatalog $catalog)
    {
        if (($document['authority'] ?? null) !== 'titan-ai-workforce') {
            throw new InvalidArgumentException('Team composition authority must be titan-ai-workforce.');
        }
    }

    public static function fromJsonFile(string $path, RoleCatalog $catalog): self
    {
        if (! is_file($path)) { throw new RuntimeException("Team composition file not found: {$path}"); }
        return new self(json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR), $catalog);
    }

    public function manifestForTier(string $tier): array
    {
        $tier = $this->normalizeTier($tier);
        $compositions = $this->document['team_compositions'] ?? [];
        if (! array_key_exists($tier, $compositions)) { throw new InvalidArgumentException("Unknown Forge workforce tier: {$tier}"); }
        $roleIds = $compositions[$tier];
        if (! is_array($roleIds) || $roleIds === []) {
            throw new LogicException("Tier {$tier} is not configured until the canonical Titan AI Workforce mapping is imported.");
        }
        $roles = $this->catalog->requireRoles($roleIds);
        $limit = (int) ($this->document['role_limits'][$tier] ?? 0);
        if ($limit <= 0 || count($roles) > $limit) { throw new LogicException("Tier {$tier} composition exceeds or lacks its entitlement limit."); }
        return ['schema_version'=>'1.0','authority'=>'titan-ai-workforce','tier'=>$tier,'role_limit'=>$limit,'role_ids'=>$roleIds,'roles'=>$roles];
    }

    public function normalizeTier(string $tier): string
    {
        $tier = strtolower(trim($tier));
        return (string) (($this->document['aliases'][$tier] ?? null) ?: $tier);
    }
}
