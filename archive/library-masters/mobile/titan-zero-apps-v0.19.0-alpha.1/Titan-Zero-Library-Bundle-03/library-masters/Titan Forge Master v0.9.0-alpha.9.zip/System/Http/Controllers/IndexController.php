<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Http\Controllers;

use Illuminate\Contracts\View\View;

final class IndexController
{
    public function __invoke(): View
    {
        return view('titan-forge::index');
    }
}
