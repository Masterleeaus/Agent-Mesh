<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Governance;

use App\Extensions\TitanForge\System\Contracts\ForgeSignalGatewayContract;
use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;

final class UnavailableSignalGateway implements ForgeSignalGatewayContract
{
    public function available(): bool { return false; }
    public function emit(ForgeSignalEvent $event): array { return ['recorded' => false, 'reason' => 'signal_gateway_unavailable']; }
}
