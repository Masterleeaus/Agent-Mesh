<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class BuildStep
{
    public function __construct(
        public string $id,
        public string $generator,
        public array $dependsOn = [],
        public array $parameters = [],
    ) {
        if (! preg_match('/^[a-z][a-z0-9._-]{0,79}$/', $id)) {
            throw new InvalidArgumentException('BuildStep id is invalid.');
        }
        if (! preg_match('/^[a-z][a-z0-9._-]{0,79}$/', $generator)) {
            throw new InvalidArgumentException('BuildStep generator is invalid.');
        }
        foreach ($dependsOn as $dependency) {
            if (! is_string($dependency) || $dependency === '') {
                throw new InvalidArgumentException('BuildStep dependencies must be non-empty strings.');
            }
        }
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'generator' => $this->generator,
            'depends_on' => array_values($this->dependsOn),
            'parameters' => $this->parameters,
        ];
    }
}
