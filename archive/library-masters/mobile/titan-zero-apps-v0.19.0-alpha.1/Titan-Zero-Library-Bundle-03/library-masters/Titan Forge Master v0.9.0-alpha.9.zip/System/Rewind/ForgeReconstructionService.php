<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Rewind;

use App\Support\Extensions\RewindSourceAdapter;

final class ForgeReconstructionService
{
    public function __construct(
        private readonly RewindSourceAdapter $source,
        private readonly ForgeRewindProjector $projector,
    ) {}

    /** @return array<string,mixed> */
    public function reconstruct(int $companyId, string $traceId): array
    {
        $timeline = iterator_to_array($this->source->records($companyId, $traceId), false);
        $watermark = $this->source->watermark($companyId, $traceId);
        $integrity = 'VERIFIED';
        $previous = null;
        $nodes = [];
        $edges = [];
        $orphans = [];
        $ids = [];

        foreach ($timeline as $event) {
            $nodes[] = $event['event_id'];
            $ids[$event['event_id']] = true;
            if (! $this->projector->verify($event) || (($event['previous_hash'] ?? null) !== $previous)) {
                $integrity = 'FAILED';
            }
            $previous = $event['integrity_hash'] ?? null;
        }

        foreach ($timeline as $event) {
            $cause = $event['causation_id'] ?? null;
            if (is_string($cause) && isset($ids[$cause])) {
                $edges[] = ['from' => $cause, 'to' => $event['event_id']];
            } else {
                $orphans[] = $event['event_id'];
            }
        }

        $complete = ($watermark['state'] ?? 'UNAVAILABLE') === 'COMPLETE' && $integrity === 'VERIFIED';
        return [
            'schema_version' => '1.0',
            'company_id' => $companyId,
            'trace_id' => $traceId,
            'status' => $complete ? 'COMPLETE' : ($timeline === [] ? 'FAILED' : 'PARTIAL'),
            'completeness' => $watermark['state'] ?? 'UNAVAILABLE',
            'reproducibility' => $timeline === [] ? 'ARTIFACT_UNAVAILABLE' : 'PARTIALLY_REPRODUCIBLE',
            'timeline' => $timeline,
            'causation_graph' => ['nodes' => $nodes, 'edges' => $edges, 'orphans' => $orphans],
            'source_watermarks' => [$watermark],
            'historical_artifacts' => [],
            'integrity_state' => $integrity,
            'root_cause' => null,
            'drift_findings' => [],
            'generated_at' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format(DATE_ATOM),
        ];
    }
}
