<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class ForgeSignalEvent
{
    public string $rootCausationId;
    /** @param array<string,mixed> $payload @param array<string,mixed> $metadata */
    public function __construct(
        public string $eventType,
        public int $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $operationId,
        public ?int $actorId,
        public string $idempotencyKey,
        public array $payload = [],
        public array $metadata = [],
        public string $severity = 'info',
        public string $category = 'forge.lifecycle',
        ?string $rootCausationId = null,
    ) {
        $this->rootCausationId = $rootCausationId ?? $causationId;
        if ($companyId <= 0) {
            throw new InvalidArgumentException('Forge signal companyId must be positive.');
        }
        foreach (['eventType' => $eventType, 'traceId' => $traceId, 'correlationId' => $correlationId, 'causationId' => $causationId, 'rootCausationId' => $this->rootCausationId, 'operationId' => $operationId, 'idempotencyKey' => $idempotencyKey] as $name => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($name . ' is required for Forge Signal emission.');
            }
        }
    }

    /** @return array<string,mixed> */
    public function toSignalArray(): array
    {
        return [
            'event_type' => $this->eventType,
            'scope' => 'tenant',
            'company_id' => $this->companyId,
            'actor_type' => $this->actorId === null ? null : 'user',
            'actor_id' => $this->actorId === null ? null : (string) $this->actorId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'source' => 'titan-forge',
            'source_component' => 'forge-manager',
            'schema_version' => 1,
            'payload' => $this->payload + ['operation_id' => $this->operationId],
            'metadata' => $this->metadata,
            'severity' => $this->severity,
            'category' => $this->category,
            'idempotency_key' => $this->idempotencyKey,
        ];
    }
}
