<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Validation\Validators;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidatorContract;

final class GenerationManifestValidator implements ArtifactValidatorContract
{
    public function id(): string { return 'generation-manifest'; }
    public function validate(BuildSpec $spec, SandboxWorkspace $workspace, ArtifactSet $artifacts): array
    {
        $path=$workspace->path('generation_manifest.json');
        if(!is_file($path) || is_link($path)){return [new ValidationFinding('critical','manifest.missing','generation_manifest.json is required.','generation_manifest.json',true)];}
        try{$manifest=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);}catch(\Throwable $e){return [new ValidationFinding('critical','manifest.invalid_json','Generation manifest is not valid JSON.','generation_manifest.json',true)];}
        if(!is_array($manifest)){return [new ValidationFinding('critical','manifest.invalid_shape','Generation manifest must be an object.','generation_manifest.json',true)];}
        $findings=[];
        $checks=[
            'deployment_authority'=>['none','manifest.deployment_authority','Generated artifacts must never carry direct deployment authority.'],
            'build_type'=>[$spec->targetType,'manifest.build_type','Generation manifest build type does not match BuildSpec.'],
            'company_id'=>[$spec->context->companyId,'manifest.tenant','Generation manifest tenant does not match BuildSpec.'],
            'root_causation_id'=>[$spec->context->rootCausationId,'manifest.root_causation','Generation manifest root causation does not match BuildSpec.'],
            'operation_id'=>[$spec->context->operationId,'manifest.operation','Generation manifest operation does not match BuildSpec.'],
        ];
        foreach($checks as $key=>[$expected,$rule,$message]){if(($manifest[$key]??null)!==$expected){$findings[]=new ValidationFinding('critical',$rule,$message,'generation_manifest.json',true);}}
        if($spec->targetType==='workforce_team' && array_values((array)($manifest['role_ids']??[]))!==array_values($spec->roleIds)){$findings[]=new ValidationFinding('critical','manifest.roles','Generation manifest roles do not match BuildSpec.','generation_manifest.json',true);}
        if (($manifest['generation_mode'] ?? null) === 'ai-assisted') {
            $planner=(array)($manifest['planner']??[]); $model=(array)($manifest['model']??[]); $provenance=(array)($manifest['provenance']??[]);
            $aiValid=(string)($planner['source']??'')==='titan-ai-core'
                && (string)($planner['source_plan_id']??'')!==''
                && preg_match('/^[a-f0-9]{64}$/',(string)($planner['build_plan_fingerprint']??''))===1
                && (string)($model['provider']??'')!==''
                && (string)($model['id']??'')!==''
                && (string)($model['route']??'')==='titan-ai-core'
                && preg_match('/^[a-f0-9]{64}$/',(string)($provenance['prompt_sha256']??''))===1
                && preg_match('/^[a-f0-9]{64}$/',(string)($provenance['input_sha256']??''))===1
                && preg_match('/^[a-f0-9]{64}$/',(string)($provenance['output_sha256']??''))===1
                && (string)($provenance['template_version']??'')!=='';
            if(!$aiValid){$findings[]=new ValidationFinding('critical','manifest.ai_provenance','AI-assisted generation requires complete AI Core planner, model-route, and provenance hashes.','generation_manifest.json',true);}
            if($this->containsForbiddenReasoningKey($manifest)){$findings[]=new ValidationFinding('critical','manifest.ai_reasoning','AI generation manifests must not persist hidden chain-of-thought or private reasoning.','generation_manifest.json',true);}
        }
        $declaredHash=(string)($manifest['manifest_sha256']??''); $hashInput=$manifest; unset($hashInput['manifest_sha256']);
        $computed=hash('sha256',json_encode($hashInput,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));
        if(preg_match('/^[a-f0-9]{64}$/',$declaredHash)!==1 || !hash_equals($computed,$declaredHash)){$findings[]=new ValidationFinding('critical','manifest.fingerprint','Generation manifest fingerprint is invalid.','generation_manifest.json',true);}
        $actual=[]; foreach($artifacts->artifacts as $artifact){if($artifact->path==='generation_manifest.json'){continue;} $actual[$artifact->path]=['sha256'=>$artifact->sha256,'bytes'=>$artifact->sizeBytes];}
        $listed=[]; foreach((array)($manifest['files']??[]) as $file){if(!is_array($file)){continue;} $p=(string)($file['path']??''); if($p===''){continue;} $listed[$p]=['sha256'=>(string)($file['sha256']??''),'bytes'=>(int)($file['bytes']??$file['size_bytes']??-1)];}
        ksort($actual); ksort($listed); if($actual!==$listed){$findings[]=new ValidationFinding('critical','manifest.artifact_set','Generation manifest file receipts do not match the sandbox artifact set.','generation_manifest.json',true);}
        return $findings;
    }

    private function containsForbiddenReasoningKey(mixed $value): bool
    {
        if (! is_array($value)) { return false; }
        foreach ($value as $key=>$item) {
            if (is_string($key)) {
                $normalized=strtolower(str_replace(['-',' '],'_',$key));
                if (in_array($normalized,['chain_of_thought','hidden_reasoning','reasoning_trace','private_reasoning'],true)) { return true; }
            }
            if ($this->containsForbiddenReasoningKey($item)) { return true; }
        }
        return false;
    }
}
