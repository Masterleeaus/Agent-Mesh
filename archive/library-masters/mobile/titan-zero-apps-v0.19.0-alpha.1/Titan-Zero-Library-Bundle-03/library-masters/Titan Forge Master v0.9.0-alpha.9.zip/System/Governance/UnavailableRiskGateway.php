<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Governance;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
final class UnavailableRiskGateway implements ForgeRiskGatewayContract
{
    public function available(): bool { return false; }
    public function assess(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): RiskDeclaration { return RiskDeclaration::unavailable(); }
}
