<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Jobs;

use App\Extensions\TitanForge\System\Contracts\ForgeManagerContract;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

final class GenerateSkeletonTeam implements ShouldQueue, ShouldBeUnique
{
    public bool $afterCommit = true;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $timeout = 120;
    public int $uniqueFor = 3600;
    public readonly int $companyId;
    public readonly int $actorId;
    public readonly string $traceId;
    public readonly string $correlationId;
    public readonly string $causationId;
    public readonly string $rootCausationId;
    public readonly string $operationId;
    public readonly string $idempotencyKey;

    public function __construct(BuildContext $context, public readonly string $tier)
    {
        $this->companyId=$context->companyId;
        $this->actorId=$context->actorId;
        $this->traceId=$context->traceId;
        $this->correlationId=$context->correlationId;
        $this->causationId=$context->causationId;
        $this->rootCausationId=$context->rootCausationId;
        $this->operationId=$context->operationId;
        $this->idempotencyKey=$context->idempotencyKey;
        $this->onQueue('titan-forge');
    }

    public function uniqueId(): string { return $this->companyId . ':' . $this->idempotencyKey; }

    public function handle(ForgeManagerContract $forge): void
    {
        $forge->generateSkeletonTeam(new BuildContext(
            $this->companyId,$this->actorId,$this->traceId,$this->correlationId,$this->causationId,$this->operationId,$this->idempotencyKey,$this->rootCausationId
        ), $this->tier);
    }
}
