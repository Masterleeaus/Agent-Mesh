<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;

interface ForgeSignalGatewayContract
{
    public function available(): bool;

    /** @return array<string,mixed> */
    public function emit(ForgeSignalEvent $event): array;
}
