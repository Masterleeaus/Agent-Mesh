<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\AiArtifactProposal;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;

interface ForgeAiArtifactGatewayContract
{
    public function available(): bool;
    public function propose(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): AiArtifactProposal;
}
