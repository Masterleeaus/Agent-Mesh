<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Sandbox;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildArtifact;
use InvalidArgumentException;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use FilesystemIterator;

final class SandboxWorkspace
{
    public function __construct(
        private readonly string $root,
        public readonly int $companyId,
        public readonly string $operationId,
        private readonly int $maxFiles,
        private readonly int $maxArtifactBytes,
    ) {
        $normalized = self::normalizeRoot($root);
        if ($normalized !== $root) {
            throw new InvalidArgumentException('Sandbox workspace root must be normalized and absolute.');
        }
        if ($companyId <= 0) {
            throw new InvalidArgumentException('Sandbox tenant company ID must be positive.');
        }
        if (! preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $operationId)) {
            throw new InvalidArgumentException('Sandbox operation ID must be a UUID.');
        }
        if ($maxFiles < 1 || $maxArtifactBytes < 1024) {
            throw new InvalidArgumentException('Sandbox limits are invalid.');
        }
    }

    public function rootPath(): string
    {
        return $this->root;
    }

    public function reset(): void
    {
        if (is_link($this->root)) {
            throw new RuntimeException('Sandbox root cannot be a symlink.');
        }
        if (is_dir($this->root)) {
            $this->removeTree($this->root, false);
        } elseif (file_exists($this->root)) {
            throw new RuntimeException('Sandbox root is occupied by a non-directory path.');
        }
        if (! is_dir($this->root) && ! mkdir($this->root, 0770, true) && ! is_dir($this->root)) {
            throw new RuntimeException('Unable to create Forge sandbox workspace.');
        }
    }

    public function destroy(): void
    {
        if (is_link($this->root)) {
            unlink($this->root);
            return;
        }
        if (is_dir($this->root)) {
            $this->removeTree($this->root, true);
        }
    }

    public function path(string $relative): string
    {
        $relative = $this->assertSafeRelativePath($relative);
        return $this->root . '/' . $relative;
    }

    public function write(string $relative, string $contents): void
    {
        if (strlen($contents) > $this->maxArtifactBytes) {
            throw new RuntimeException('Sandbox artifact exceeds the configured maximum size.');
        }
        $path = $this->path($relative);
        $directory = dirname($path);
        $this->assertNoSymlinkParents($directory);
        if (! is_dir($directory) && ! mkdir($directory, 0770, true) && ! is_dir($directory)) {
            throw new RuntimeException('Unable to create sandbox artifact directory.');
        }
        $this->assertNoSymlinkParents($directory);
        if (is_link($path)) {
            throw new RuntimeException('Sandbox artifact path cannot be a symlink.');
        }
        $tmp = $directory . '/.forge-tmp-' . bin2hex(random_bytes(8));
        try {
            $bytes = file_put_contents($tmp, $contents, LOCK_EX);
            if ($bytes === false || $bytes !== strlen($contents)) {
                throw new RuntimeException('Unable to write complete sandbox artifact.');
            }
            if (! rename($tmp, $path)) {
                throw new RuntimeException('Unable to atomically publish sandbox artifact.');
            }
        } finally {
            if (is_file($tmp) || is_link($tmp)) {
                @unlink($tmp);
            }
        }
    }

    public function snapshot(): ArtifactSet
    {
        if (! is_dir($this->root) || is_link($this->root)) {
            throw new RuntimeException('Sandbox workspace is not a valid directory.');
        }
        $artifacts = [];
        $casePaths = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->root, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            $absolute = str_replace('\\', '/', $item->getPathname());
            $relative = ltrim(substr($absolute, strlen($this->root)), '/');
            if ($item->isLink()) {
                throw new RuntimeException("Sandbox snapshot rejected symlink: {$relative}");
            }
            if ($item->isDir()) {
                continue;
            }
            if (! $item->isFile()) {
                throw new RuntimeException("Sandbox snapshot rejected unsupported filesystem entry: {$relative}");
            }
            $relative = $this->assertSafeRelativePath($relative);
            $caseKey = strtolower($relative);
            if (isset($casePaths[$caseKey]) && $casePaths[$caseKey] !== $relative) {
                throw new RuntimeException("Sandbox artifact paths collide case-insensitively: {$casePaths[$caseKey]} <> {$relative}");
            }
            $casePaths[$caseKey] = $relative;
            if (count($artifacts) >= $this->maxFiles) {
                throw new RuntimeException('Sandbox artifact count exceeds the configured maximum.');
            }
            $size = $item->getSize();
            if ($size > $this->maxArtifactBytes) {
                throw new RuntimeException("Sandbox artifact exceeds the configured maximum size: {$relative}");
            }
            $sha = hash_file('sha256', $item->getPathname());
            if (! is_string($sha)) {
                throw new RuntimeException("Unable to hash sandbox artifact: {$relative}");
            }
            $artifacts[] = new BuildArtifact(
                $relative,
                $sha,
                self::artifactType($relative),
                $size,
                ['sandbox' => true],
            );
        }
        usort($artifacts, static fn (BuildArtifact $a, BuildArtifact $b): int => strcmp($a->path, $b->path));
        return new ArtifactSet($artifacts);
    }

    private function assertNoSymlinkParents(string $directory): void
    {
        $root = $this->root;
        $relative = ltrim(substr(str_replace('\\', '/', $directory), strlen($root)), '/');
        $cursor = $root;
        if (is_link($cursor)) {
            throw new RuntimeException('Sandbox root cannot be a symlink.');
        }
        foreach ($relative === '' ? [] : explode('/', $relative) as $part) {
            $cursor .= '/' . $part;
            if (is_link($cursor)) {
                throw new RuntimeException('Sandbox path contains a symlink parent.');
            }
        }
    }

    private function removeTree(string $path, bool $removeRoot): void
    {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $item) {
            $entry = $item->getPathname();
            if ($item->isLink() || $item->isFile()) {
                if (! @unlink($entry)) {
                    throw new RuntimeException('Unable to remove sandbox file.');
                }
            } elseif ($item->isDir() && ! @rmdir($entry)) {
                throw new RuntimeException('Unable to remove sandbox directory.');
            }
        }
        if ($removeRoot && ! @rmdir($path)) {
            throw new RuntimeException('Unable to remove sandbox workspace root.');
        }
    }

    private function assertSafeRelativePath(string $relative): string
    {
        if ($relative === '' || str_contains($relative, "\0") || str_contains($relative, '\\') || str_starts_with($relative, '/') || preg_match('/^[A-Za-z]:/', $relative)) {
            throw new InvalidArgumentException('Sandbox relative path is unsafe.');
        }
        foreach (explode('/', $relative) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                throw new InvalidArgumentException('Sandbox relative path is unsafe.');
            }
        }
        return $relative;
    }

    private static function normalizeRoot(string $root): string
    {
        $root = str_replace('\\', '/', trim($root));
        if ($root === '' || $root === '/' || ! str_starts_with($root, '/') || str_contains($root, "\0") || str_contains($root, '/../') || str_ends_with($root, '/..')) {
            throw new InvalidArgumentException('Sandbox workspace root is unsafe.');
        }
        return rtrim($root, '/');
    }

    private static function artifactType(string $path): string
    {
        $lower = strtolower($path);
        if (str_ends_with($lower, '.blade.php')) { return 'blade'; }
        $ext = strtolower(pathinfo($lower, PATHINFO_EXTENSION));
        return match ($ext) {
            'php' => 'php', 'json' => 'json', 'md' => 'markdown', 'yml', 'yaml' => 'yaml',
            'js' => 'javascript', 'ts' => 'typescript', 'css' => 'css', 'html' => 'html', 'txt' => 'text',
            default => 'artifact',
        };
    }
}
