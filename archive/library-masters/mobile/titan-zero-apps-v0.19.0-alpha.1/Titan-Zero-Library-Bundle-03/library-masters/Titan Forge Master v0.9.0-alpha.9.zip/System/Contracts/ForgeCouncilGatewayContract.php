<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Contracts;

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;

interface ForgeCouncilGatewayContract
{
    public function available(): bool;

    public function governedDeliberationAvailable(): bool;

    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview;

    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview;
}
