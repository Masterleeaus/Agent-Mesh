<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Sandbox;

use App\Extensions\TitanForge\System\Domain\BuildContext;
use InvalidArgumentException;

final readonly class SandboxWorkspaceFactory
{
    public function __construct(private string $workspaceRoot, private int $maxFiles, private int $maxArtifactBytes)
    {
        $normalized=rtrim(str_replace('\\','/',trim($workspaceRoot)),'/');
        if($normalized==='' || $normalized==='/' || !str_starts_with($normalized,'/') || str_contains($normalized,'/../')){throw new InvalidArgumentException('Forge sandbox root is unsafe.');}
        if($normalized!==$workspaceRoot){throw new InvalidArgumentException('Forge sandbox root must be normalized.');}
        if($maxFiles<1 || $maxArtifactBytes<1024){throw new InvalidArgumentException('Forge sandbox limits are invalid.');}
    }

    public function forContext(BuildContext $context): SandboxWorkspace
    {
        return new SandboxWorkspace(
            $this->workspaceRoot.'/'.$context->companyId.'/'.$context->operationId,
            $context->companyId,
            $context->operationId,
            $this->maxFiles,
            $this->maxArtifactBytes,
        );
    }
}
