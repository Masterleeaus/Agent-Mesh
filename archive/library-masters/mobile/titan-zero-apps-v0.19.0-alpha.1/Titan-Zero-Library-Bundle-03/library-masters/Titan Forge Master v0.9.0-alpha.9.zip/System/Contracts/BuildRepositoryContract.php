<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System\Contracts;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
interface BuildRepositoryContract
{
    public function createOrFind(BuildRequest $request, BuildSpec $spec): ForgeBuild;
    public function findForTenant(int $companyId, int $buildId): ?ForgeBuild;
    public function latestForTenant(int $companyId, int $limit = 50): array;
    public function latest(int $limit = 100): array;
    public function markStatus(ForgeBuild $build, string $status, array $payload = []): ForgeBuild;
    public function recordPlan(ForgeBuild $build, BuildPlan $plan, array $provenance = []): int;
    public function recordArtifacts(ForgeBuild $build, array $files, array $metadata = []): void;
    public function recordValidation(ForgeBuild $build, array $validatorIds, ValidationResult $result): int;
}
