<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Queue;

use App\Extensions\TitanForge\System\Domain\BuildContext;
use InvalidArgumentException;

final readonly class BuildJobPayload
{
    public function __construct(public int $buildId, public BuildContext $context)
    {
        if ($buildId <= 0) {
            throw new InvalidArgumentException('buildId must be positive.');
        }
    }

    public function toArray(): array
    {
        return ['build_id' => $this->buildId] + $this->context->toArray();
    }
}
