<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Rewind;

use App\Extensions\TitanForge\System\Models\ForgeArtifact;
use App\Extensions\TitanForge\System\Models\ForgeBuild;
use App\Extensions\TitanForge\System\Models\ForgeBuildPlan;
use App\Extensions\TitanForge\System\Models\ForgeReceipt;
use App\Extensions\TitanForge\System\Models\ForgeReleaseCandidate;
use App\Extensions\TitanForge\System\Models\ForgeValidationRun;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;

final class EloquentForgeRewindHistoryReader implements ForgeRewindHistoryReaderContract
{
    public function facts(int $companyId, string $traceId): iterable
    {
        if ($companyId < 1 || $traceId === '') {
            throw new \InvalidArgumentException('A tenant and trace are required.');
        }

        $buildQuery = ForgeBuild::query()->where('company_id', $companyId)->where('trace_id', $traceId);
        $lineage = [];

        foreach ((clone $buildQuery)->orderBy('id')->cursor() as $build) {
            $buildId = (int) $build->getKey();
            $lineage[$buildId] = [
                'actor_id' => $build->actor_id !== null ? (int) $build->actor_id : null,
                'correlation_id' => (string) $build->correlation_id,
                'causation_id' => (string) $build->causation_id,
                'root_causation_id' => (string) ($build->root_causation_id ?: $build->causation_id),
                'operation_id' => (string) $build->operation_id,
            ];
            yield $this->fact('build', 'build:' . $buildId, $build->created_at, $build->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'status' => (string) $build->status,
                'target_type' => (string) $build->type,
                'spec_fingerprint' => (string) $build->spec_fingerprint,
            ], $lineage[$buildId]));
        }

        $ids = static fn () => (clone $buildQuery)->select('id');

        foreach (ForgeBuildPlan::query()->where('company_id', $companyId)->whereIn('build_id', $ids())->orderBy('id')->cursor() as $plan) {
            $buildId = (int) $plan->build_id;
            yield $this->fact('plan', 'plan:' . $plan->getKey(), $plan->created_at, $plan->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'fingerprint' => (string) $plan->fingerprint,
                'source' => (string) ($plan->source ?: 'deterministic'),
                'source_plan_id' => $plan->source_plan_id !== null ? (string) $plan->source_plan_id : null,
                'source_schema_version' => $plan->source_schema_version !== null ? (string) $plan->source_schema_version : null,
                'source_runtime_version' => $plan->source_runtime_version !== null ? (string) $plan->source_runtime_version : null,
            ], $lineage[$buildId] ?? []));
        }

        foreach (ForgeArtifact::query()->where('company_id', $companyId)->whereIn('build_id', $ids())->orderBy('id')->cursor() as $artifact) {
            $buildId = (int) $artifact->build_id;
            $meta = (array) $artifact->metadata;
            $planner = (array) ($meta['planner'] ?? []);
            $model = (array) ($meta['model'] ?? []);
            $prov = (array) ($meta['provenance'] ?? []);
            yield $this->fact('artifact', 'artifact:' . $artifact->getKey(), $artifact->created_at, $artifact->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'path' => (string) $artifact->path,
                'sha256' => (string) $artifact->sha256,
                'type' => (string) $artifact->type,
                'size_bytes' => (int) $artifact->size_bytes,
                'generation_mode' => (string) ($meta['generation_mode'] ?? 'deterministic'),
                'model_provider' => $model['provider'] ?? null,
                'model_name' => $model['model_id'] ?? null,
                'model_route' => $model['route'] ?? null,
                'prompt_sha256' => $prov['prompt_sha256'] ?? null,
                'input_sha256' => $prov['input_sha256'] ?? null,
                'output_sha256' => $prov['output_sha256'] ?? null,
                'template_version' => $prov['template_version'] ?? null,
                'generation_manifest_sha256' => $meta['generation_manifest_sha256'] ?? null,
                'build_plan_fingerprint' => $meta['build_plan_fingerprint'] ?? ($planner['build_plan_fingerprint'] ?? null),
            ], $lineage[$buildId] ?? []));
        }

        foreach (ForgeValidationRun::query()->where('company_id', $companyId)->whereIn('build_id', $ids())->orderBy('id')->cursor() as $run) {
            $buildId = (int) $run->build_id;
            $summary = (array) $run->summary;
            yield $this->fact('validation', 'validation:' . $run->getKey(), $run->started_at ?: $run->created_at, $run->completed_at ?: $run->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'status' => (string) $run->status,
                'fingerprint' => (string) ($summary['fingerprint'] ?? ''),
                'finding_count' => (int) ($summary['finding_count'] ?? 0),
                'blocking_count' => (int) ($summary['blocking_count'] ?? 0),
                'validator_count' => count((array) $run->validator_set),
            ], $lineage[$buildId] ?? []));
        }

        foreach (ForgeReleaseCandidate::query()->where('company_id', $companyId)->whereIn('build_id', $ids())->orderBy('id')->cursor() as $candidate) {
            $buildId = (int) $candidate->build_id;
            $inherit = $lineage[$buildId] ?? [];
            $meta = (array) $candidate->metadata;
            $gate = (array) ($meta['gate'] ?? []);
            $when = $candidate->created_at;
            $shield = (array) ($gate['shield_validation'] ?? []);
            yield $this->fact('shield', 'candidate:' . $candidate->getKey() . ':shield', $when, $candidate->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'candidate_id' => (int) $candidate->getKey(),
                'valid' => (bool) ($shield['valid'] ?? false),
                'finding_count' => count((array) ($shield['findings'] ?? [])),
                'blocking_count' => count(array_filter((array) ($shield['findings'] ?? []), static fn (mixed $f): bool => is_array($f) && (bool) ($f['blocking'] ?? false))),
                'fingerprint' => $this->hashSafe($shield),
            ], $inherit));

            $risk = (array) ($gate['risk'] ?? []);
            yield $this->fact('risk', 'candidate:' . $candidate->getKey() . ':risk', $when, $candidate->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'candidate_id' => (int) $candidate->getKey(),
                'level' => (string) ($risk['level'] ?? 'unavailable'),
                'blocked' => (bool) ($risk['blocked'] ?? true),
                'provider' => (string) ($risk['provider'] ?? 'titan-risk'),
                'execution_directive' => (string) (($risk['metadata']['execution_directive'] ?? '') ?: ''),
            ], $inherit));

            $council = (array) ($gate['council'] ?? []);
            $cmeta = (array) ($council['metadata'] ?? []);
            if ((bool) ($council['required'] ?? false)) {
                yield $this->fact('council', 'candidate:' . $candidate->getKey() . ':council', $when, $candidate->updated_at, $this->withLineage([
                    'build_id' => $buildId,
                    'candidate_id' => (int) $candidate->getKey(),
                    'status' => (string) ($council['status'] ?? 'unavailable'),
                    'decision_id' => $cmeta['decision_id'] ?? null,
                    'confidence_percent' => $cmeta['confidence_percent'] ?? null,
                    'actual_participant_count' => $cmeta['actual_participant_count'] ?? null,
                    'requires_escalation' => $cmeta['requires_escalation'] ?? null,
                    'execution_authority' => $cmeta['execution_authority'] ?? 'advisory_only',
                    'final_answer_sha256' => $cmeta['final_answer_sha256'] ?? null,
                    'role_models_sha256' => $cmeta['role_models_sha256'] ?? null,
                ], $inherit));
            }

            $reasons = array_values(array_filter((array) ($gate['reasons'] ?? []), static fn (mixed $v): bool => is_string($v) && str_starts_with($v, 'governance.')));
            yield $this->fact('governance', 'candidate:' . $candidate->getKey() . ':governance', $when, $candidate->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'candidate_id' => (int) $candidate->getKey(),
                'available' => (bool) ($gate['governance_available'] ?? false),
                'reason' => $reasons[0] ?? null,
                'reason_codes' => $reasons,
            ], $inherit));

            yield $this->fact('release_candidate', 'candidate:' . $candidate->getKey(), $when, $candidate->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'candidate_id' => (int) $candidate->getKey(),
                'status' => (string) $candidate->status,
                'artifact_set_hash' => (string) $candidate->artifact_set_hash,
                'validation_fingerprint' => (string) $candidate->validation_fingerprint,
                'gate_fingerprint' => (string) ($meta['gate_fingerprint'] ?? ''),
                'deployment_authority' => 'none',
            ], $inherit));
        }

        foreach (ForgeReceipt::query()->where('company_id', $companyId)->whereIn('build_id', $ids())->orderBy('id')->cursor() as $receipt) {
            $buildId = (int) $receipt->build_id;
            yield $this->fact('receipt', 'receipt:' . $receipt->getKey(), $receipt->created_at, $receipt->updated_at, $this->withLineage([
                'build_id' => $buildId,
                'receipt_id' => (int) $receipt->getKey(),
                'receipt_type' => (string) $receipt->receipt_type,
                'receipt_hash' => (string) $receipt->receipt_hash,
            ], $lineage[$buildId] ?? []));
        }
    }

    /** @param array<string,mixed> $data @param array<string,mixed> $lineage @return array<string,mixed> */
    private function withLineage(array $data, array $lineage): array
    {
        return array_replace($lineage, $data);
    }

    /** @param array<string,mixed> $data @return array{kind:string,record_id:string,occurred_at:string,recorded_at:string,data:array<string,mixed>} */
    private function fact(string $kind, string $recordId, mixed $occurredAt, mixed $recordedAt, array $data): array
    {
        return [
            'kind' => $kind,
            'record_id' => $recordId,
            'occurred_at' => $this->timestamp($occurredAt),
            'recorded_at' => $this->timestamp($recordedAt),
            'data' => $data,
        ];
    }

    private function timestamp(mixed $value): string
    {
        if ($value instanceof DateTimeInterface) {
            return $value->format(DATE_ATOM);
        }
        if (is_string($value) && $value !== '') {
            return (new DateTimeImmutable($value))->format(DATE_ATOM);
        }
        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format(DATE_ATOM);
    }

    /** @param array<string,mixed> $value */
    private function hashSafe(array $value): string
    {
        $bounded = [
            'valid' => (bool) ($value['valid'] ?? false),
            'finding_count' => count((array) ($value['findings'] ?? [])),
            'error_count' => count((array) ($value['errors'] ?? [])),
            'warning_count' => count((array) ($value['warnings'] ?? [])),
        ];
        ksort($bounded, SORT_STRING);
        return hash('sha256', json_encode($bounded, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }
}
