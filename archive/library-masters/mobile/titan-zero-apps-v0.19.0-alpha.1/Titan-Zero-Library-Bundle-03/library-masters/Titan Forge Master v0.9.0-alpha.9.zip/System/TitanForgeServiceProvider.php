<?php

declare(strict_types=1);
namespace App\Extensions\TitanForge\System;
use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanForge\System\Config\ForgeConfiguration;
use App\Extensions\TitanForge\System\Console\Commands\ForgeManifestCommand;
use App\Extensions\TitanForge\System\Console\Commands\GenerateSkeletonTeamCommand;
use App\Extensions\TitanForge\System\Contracts\BuildRepositoryContract;
use App\Extensions\TitanForge\System\Contracts\ForgeAiArtifactGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeAiPlanningGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCommandBusGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeManagerContract;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeSignalGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ReleaseRepositoryContract;
use App\Extensions\TitanForge\System\Generation\StaticRoleTemplateEngine;
use App\Extensions\TitanForge\System\AI\TitanAICorePlanningGateway;
use App\Extensions\TitanForge\System\AI\UnavailableAiArtifactGateway;
use App\Extensions\TitanForge\System\AI\SandboxedAiArtifactGenerator;
use App\Extensions\TitanForge\System\Governance\ReleaseGovernanceService;
use App\Extensions\TitanForge\System\Governance\TitanCouncilGateway;
use App\Extensions\TitanForge\System\Governance\TitanRiskGateway;
use App\Extensions\TitanForge\System\Governance\TitanShieldGateway;
use App\Extensions\TitanForge\System\Governance\TitanSignalGateway;
use App\Extensions\TitanForge\System\Governance\UnavailableCommandBusGateway;
use App\Extensions\TitanForge\System\Governance\UnavailableGovernanceGateway;
use App\Extensions\TitanForge\System\Http\Middleware\RequireForgeTenant;
use App\Extensions\TitanForge\System\Persistence\EloquentBuildRepository;
use App\Extensions\TitanForge\System\Persistence\EloquentReleaseRepository;
use App\Extensions\TitanForge\System\Rewind\EloquentForgeRewindHistoryReader;
use App\Extensions\TitanForge\System\Rewind\ForgeReconstructionService;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindHistoryReaderContract;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindProjector;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindSource;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use App\Extensions\TitanForge\System\Services\ForgeManager;
use App\Extensions\TitanForge\System\Support\ForgeConfigurationValidator;
use App\Extensions\TitanForge\System\Support\ForgeTenantResolver;
use App\Extensions\TitanForge\System\Validation\ArtifactValidationPipeline;
use App\Extensions\TitanForge\System\Validation\ValidatorRegistry;
use App\Extensions\TitanForge\System\Validation\Validators\ArtifactPolicyValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GeneratedCodeSafetyValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GeneratedContentSecretValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GenerationManifestValidator;
use App\Extensions\TitanForge\System\Validation\Validators\JsonSyntaxValidator;
use App\Extensions\TitanForge\System\Validation\Validators\PhpSyntaxValidator;
use App\Extensions\TitanForge\System\Validation\Validators\WorkspaceIntegrityValidator;
use App\Extensions\TitanForge\System\Workforce\RoleCatalog;
use App\Extensions\TitanForge\System\Workforce\TeamCompositionService;
use App\Extensions\TitanForge\System\Workforce\TierEntitlementPolicy;
use App\Extensions\TitanForge\System\Workforce\WorkforceProviderRuntimeContract;
use App\Extensions\TitanForge\System\Workforce\PackageWorkforceProviderAdapter;
use App\Extensions\TitanForge\System\Workforce\ProviderHealthStoreContract;
use App\Extensions\TitanForge\System\Workforce\LaravelCacheProviderHealthStore;
use App\Extensions\TitanForge\System\Workforce\ProviderHealthRegistry;
use App\Extensions\TitanForge\System\Workforce\CapabilityResolver;
use App\Extensions\TitanForge\System\Workforce\ProviderSelector;
use App\Extensions\TitanForge\System\Workforce\WorkforceProviderContribution;
use App\Extensions\TitanForge\System\Workforce\WorkforceProviderEventEmitter;
use App\Extensions\TitanForge\System\Workforce\ProviderHealthProbeContract;
use App\Extensions\TitanForge\System\Workforce\ProviderHealthProbe;
use App\Extensions\TitanForge\System\Workforce\ProviderHealthRefreshService;
use App\Extensions\TitanForge\System\Workforce\WorkforceProviderStatusService;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanForgeServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        
        $this->app->singleton('titan-apps.interface-contributions.titan-forge', \App\Extensions\TitanForge\System\Integration\TitanApps\TitanAppsContributionProvider::class);
        $this->app->singleton(ProviderHealthProbeContract::class, fn($app): ProviderHealthProbeContract => new ProviderHealthProbe(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app
        ));
        $this->app->singleton(ProviderHealthRefreshService::class, fn($app): ProviderHealthRefreshService => new ProviderHealthRefreshService(
            $app->make(ProviderHealthProbeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(WorkforceProviderEventEmitter::class),
        ));
        $this->app->singleton(WorkforceProviderStatusService::class, fn($app): WorkforceProviderStatusService => new WorkforceProviderStatusService(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
        ));
// Agent-06 Pass 5: host-facing Workforce provider registration.
        $this->app->singleton(WorkforceProviderRuntimeContract::class, fn(): WorkforceProviderRuntimeContract => PackageWorkforceProviderAdapter::fromPackageRoot(dirname(__DIR__)));
        $this->app->singleton(ProviderHealthStoreContract::class, fn($app): ProviderHealthStoreContract => new LaravelCacheProviderHealthStore($app->make('cache.store')));
        $this->app->singleton(ProviderHealthRegistry::class, fn($app): ProviderHealthRegistry => new ProviderHealthRegistry($app->make(ProviderHealthStoreContract::class)));
        $this->app->singleton(CapabilityResolver::class, fn($app): CapabilityResolver => new CapabilityResolver($app->make(ProviderHealthRegistry::class)));
        $this->app->singleton(ProviderSelector::class);
        $this->app->singleton(WorkforceProviderEventEmitter::class, fn($app): WorkforceProviderEventEmitter => new WorkforceProviderEventEmitter($app->make('events')));
        $this->app->singleton(WorkforceProviderContribution::class, fn($app): WorkforceProviderContribution => new WorkforceProviderContribution(
            $app->make(WorkforceProviderRuntimeContract::class),
            $app->make(ProviderHealthStoreContract::class),
            $app->make(CapabilityResolver::class),
            $app->make(ProviderSelector::class),
        ));
        $this->app->tag([WorkforceProviderContribution::class], 'titan.workforce.providers');

        $this->mergeConfigFrom(__DIR__ . '/../config/titan-forge.php', 'titan-forge');
        $rawConfig=(array)config('titan-forge',[]); ForgeConfigurationValidator::assertValid($rawConfig);
        $configuration=ForgeConfiguration::fromArray($rawConfig); $this->app->instance(ForgeConfiguration::class,$configuration);
        $this->app->singleton(BuildRepositoryContract::class,EloquentBuildRepository::class);
        $this->app->singleton(ReleaseRepositoryContract::class,EloquentReleaseRepository::class);
        $this->app->singleton(ForgeRewindHistoryReaderContract::class,EloquentForgeRewindHistoryReader::class);
        $this->app->singleton(ForgeRewindProjector::class);
        $this->app->singleton(ForgeRewindSource::class,fn($app):ForgeRewindSource=>new ForgeRewindSource($app->make(ForgeRewindHistoryReaderContract::class),$app->make(ForgeRewindProjector::class)));
        $this->app->singleton(ForgeReconstructionService::class,fn($app):ForgeReconstructionService=>new ForgeReconstructionService($app->make(ForgeRewindSource::class),$app->make(ForgeRewindProjector::class)));
        $this->app->singleton(ForgeTenantResolver::class,fn():ForgeTenantResolver=>new ForgeTenantResolver($configuration->tenantKey));
        $this->app->singleton(RoleCatalog::class,fn():RoleCatalog=>RoleCatalog::fromJsonFile($this->extensionPath((string)config('titan-forge.role_registry_path'))));
        $this->app->singleton(TeamCompositionService::class,fn($app):TeamCompositionService=>TeamCompositionService::fromJsonFile($this->extensionPath((string)config('titan-forge.team_compositions_path')),$app->make(RoleCatalog::class)));
        $this->app->singleton(TierEntitlementPolicy::class,fn():TierEntitlementPolicy=>TierEntitlementPolicy::fromJsonFile($this->extensionPath((string)config('titan-forge.team_compositions_path'))));
        $this->app->singleton('titan-forge.workforce-capability-binding',fn():array=>json_decode((string)file_get_contents($this->extensionPath('resources/workforce/capability-bindings.json')),true,512,JSON_THROW_ON_ERROR));
        $this->app->singleton(SandboxWorkspaceFactory::class,fn():SandboxWorkspaceFactory=>new SandboxWorkspaceFactory(
            storage_path('app/'.trim((string)config('titan-forge.workspace_root'),'/')),
            $configuration->maxBuildFiles,
            $configuration->maxArtifactBytes,
        ));
        $this->app->singleton(StaticRoleTemplateEngine::class,fn($app):StaticRoleTemplateEngine=>new StaticRoleTemplateEngine(
            $this->extensionPath((string)config('titan-forge.role_stub_path')),
            $app->make(RoleCatalog::class),
            $app->make(SandboxWorkspaceFactory::class),
        ));
        $this->app->singleton(ValidatorRegistry::class,fn():ValidatorRegistry=>new ValidatorRegistry([
            new ArtifactPolicyValidator($configuration->maxBuildFiles,$configuration->maxArtifactBytes),
            new WorkspaceIntegrityValidator(),
            new GeneratedContentSecretValidator(),
            new GenerationManifestValidator(),
            new GeneratedCodeSafetyValidator(),
            new JsonSyntaxValidator(),
            new PhpSyntaxValidator(),
        ]));
        $this->app->singleton(ArtifactValidationPipeline::class,fn($app):ArtifactValidationPipeline=>new ArtifactValidationPipeline($app->make(ValidatorRegistry::class)));

        $peerResolver = fn(string $contract): ?object => $this->app->bound($contract) ? $this->app->make($contract) : null;
        $this->app->singleton(ForgeAiPlanningGatewayContract::class,fn():ForgeAiPlanningGatewayContract=>new TitanAICorePlanningGateway($peerResolver));
        // Titan AI Core v0.3.0 publishes typed planning only; it does not yet publish a governed artifact-generation contract.
        // Forge therefore exposes the sandbox boundary but keeps the production AI artifact gateway fail-closed.
        $this->app->singleton(ForgeAiArtifactGatewayContract::class,fn():ForgeAiArtifactGatewayContract=>new UnavailableAiArtifactGateway('titan_ai_core_generation_contract_unavailable'));
        $this->app->singleton(SandboxedAiArtifactGenerator::class,fn($app):SandboxedAiArtifactGenerator=>new SandboxedAiArtifactGenerator(
            $app->make(ForgeAiArtifactGatewayContract::class),
            $app->make(SandboxWorkspaceFactory::class),
        ));
        $this->app->singleton(ForgeSignalGatewayContract::class,fn():ForgeSignalGatewayContract=>new TitanSignalGateway($peerResolver));
        $this->app->singleton(ForgeRiskGatewayContract::class,fn():ForgeRiskGatewayContract=>new TitanRiskGateway($peerResolver));
        $this->app->singleton(ForgeShieldGatewayContract::class,fn():ForgeShieldGatewayContract=>new TitanShieldGateway($peerResolver));
        $this->app->singleton(ForgeCouncilGatewayContract::class,fn():ForgeCouncilGatewayContract=>new TitanCouncilGateway($peerResolver, roleModels:(array)config('titan-forge.council.role_models',[])));

        // Current Titan Governance v0.1.0 and Command Bus v0.1.0 expose health-only public contracts.
        // Forge must not fabricate release/dispatch APIs; these gates remain fail-closed until owners publish them.
        $this->app->singleton(ForgeGovernanceGatewayContract::class,fn():ForgeGovernanceGatewayContract=>new UnavailableGovernanceGateway('health_only_contract'));
        $this->app->singleton(ForgeCommandBusGatewayContract::class,fn():ForgeCommandBusGatewayContract=>new UnavailableCommandBusGateway('health_only_contract'));
        $this->app->singleton(ReleaseGovernanceService::class);
        $this->app->singleton(ForgeManagerContract::class,ForgeManager::class);
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__.'/../resources/views','titan-forge');
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->publishes([__DIR__.'/../config/titan-forge.php'=>config_path('titan-forge.php')],'titan-forge-config');
        /** @var Router $router */ $router=$this->app['router']; $router->aliasMiddleware('titan.forge.tenant',RequireForgeTenant::class);
        if($this->app->runningInConsole()){$this->commands([ForgeManifestCommand::class,GenerateSkeletonTeamCommand::class]);}
        $this->registerRoutes();
    }
    public function registerKey(): string{return 'titan-forge';}
    public static function uninstall(): void{File::delete(config_path('titan-forge.php'));}
    private function registerRoutes(): void
    {
        /** @var Router $router */ $router=$this->app['router'];
        $router->group(['middleware'=>['web','auth','titan.forge.tenant'],'prefix'=>'dashboard/user/titan-forge','as'=>'dashboard.user.titan.forge.'],static function(Router $router):void{require __DIR__.'/../routes/user.php';});
        $router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-forge','as'=>'dashboard.admin.titan.forge.'],static function(Router $router):void{require __DIR__.'/../routes/admin.php';});
    }
    private function extensionPath(string $relative): string{return dirname(__DIR__).'/'.ltrim(str_replace('\\','/',$relative),'/');}
}
