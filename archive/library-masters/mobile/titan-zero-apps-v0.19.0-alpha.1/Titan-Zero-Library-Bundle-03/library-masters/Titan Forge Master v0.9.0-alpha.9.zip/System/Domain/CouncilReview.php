<?php

declare(strict_types=1);

namespace App\Extensions\TitanForge\System\Domain;

use InvalidArgumentException;

final readonly class CouncilReview
{
    /** @param array<string,mixed> $metadata */
    public function __construct(
        public bool $required,
        public bool $available,
        public string $status,
        public string $provider = 'titan-model-council',
        public array $metadata = [],
    ) {
        if (! in_array($status, [
            'not_required',
            'activation_assessed',
            'deliberated',
            'escalated',
            'rejected',
            'failed',
            'configuration_required',
            'unavailable',
        ], true)) {
            throw new InvalidArgumentException('Unknown Council review status.');
        }
        if (trim($provider) === '') {
            throw new InvalidArgumentException('Council review provider is required.');
        }
        if (! $required && $status !== 'not_required') {
            throw new InvalidArgumentException('Non-required Council review must use not_required status.');
        }
    }

    public static function notRequired(): self
    {
        return new self(false, true, 'not_required');
    }

    public static function unavailable(string $reason = 'council_gateway_unavailable'): self
    {
        return new self(true, false, 'unavailable', 'titan-model-council', ['reason' => $reason]);
    }

    public static function configurationRequired(string $reason = 'trusted_role_models_not_configured'): self
    {
        return new self(true, true, 'configuration_required', 'titan-model-council', ['reason' => $reason]);
    }

    public function satisfied(): bool
    {
        return $this->status === 'not_required'
            || ($this->required && $this->available && $this->status === 'deliberated' && (($this->metadata['execution_authority'] ?? 'advisory_only') === 'advisory_only'));
    }

    public function fingerprint(): string
    {
        return hash('sha256', json_encode($this->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'required' => $this->required,
            'available' => $this->available,
            'status' => $this->status,
            'provider' => $this->provider,
            'metadata' => $this->metadata,
        ];
    }
}
