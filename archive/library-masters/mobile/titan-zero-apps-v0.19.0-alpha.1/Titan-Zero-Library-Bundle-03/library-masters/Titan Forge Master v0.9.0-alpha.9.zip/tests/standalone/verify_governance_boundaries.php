<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach([
'System/Domain/BuildContext.php','System/Domain/BuildSpec.php','System/Domain/BuildArtifact.php','System/Domain/ArtifactSet.php','System/Domain/ValidationFinding.php','System/Domain/ValidationResult.php','System/Domain/RiskDeclaration.php',
'System/Contracts/ForgeRiskGatewayContract.php','System/Contracts/ForgeShieldGatewayContract.php','System/Governance/UnavailableRiskGateway.php','System/Governance/UnavailableShieldGateway.php'
] as $f){require_once $root.'/'.$f;}
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Governance\UnavailableRiskGateway;
use App\Extensions\TitanForge\System\Governance\UnavailableShieldGateway;
function c3(bool $c,string $m):void{if(!$c)throw new RuntimeException($m);}
$context=new BuildContext(1,2,'11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','44444444-4444-4444-8444-444444444444','gov-boundary');
$spec=BuildSpec::workforceTeam($context,'solo',['titan.operations_manager']);
$artifacts=new ArtifactSet([]); $local=ValidationResult::pass();
$risk=new UnavailableRiskGateway(); c3(!$risk->available(),'Unavailable risk gateway must report unavailable.');
$declaration=$risk->assess($spec,$artifacts,$local); c3($declaration->level==='unavailable','Unavailable risk declaration level mismatch.'); c3($declaration->blocked,'Unavailable risk gateway must fail closed when invoked.');
$shield=new UnavailableShieldGateway(); c3(!$shield->available(),'Unavailable Shield gateway must report unavailable.');
$shieldResult=$shield->inspect($spec,$artifacts,$local); c3(!$shieldResult->passed(),'Unavailable Shield gateway must fail closed when invoked.');
c3(count(array_filter($shieldResult->findings,static fn($f):bool=>$f->rule==='shield.unavailable'))===1,'Shield unavailable finding missing.');
echo "governance-boundaries: PASS\n";
