<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once $root . '/System/Support/ForgeConfigurationValidator.php';

use App\Extensions\TitanForge\System\Support\ForgeConfigurationValidator;

function p18_cfg_base(): array
{
    return [
        'enabled' => true,
        'queue' => 'titan-forge',
        'tenant_key' => 'company_id',
        'workspace_root' => 'titan-forge/workspaces',
        'role_registry_path' => 'resources/workforce/roles-bootstrap.json',
        'team_compositions_path' => 'resources/workforce/team-compositions.json',
        'role_stub_path' => 'stubs/roles/role.php.stub',
        'max_build_files' => 2000,
        'max_artifact_bytes' => 104857600,
    ];
}
function p18_cfg_assert_throws(array $config, string $message): void
{
    try { ForgeConfigurationValidator::assertValid($config); }
    catch (InvalidArgumentException) { return; }
    throw new RuntimeException($message);
}

$config = p18_cfg_base();
$config['council'] = ['role_models' => ['proposer'=>null,'critic'=>null,'verifier'=>null,'arbiter'=>null]];
ForgeConfigurationValidator::assertValid($config);

$config = p18_cfg_base();
$config['council'] = ['role_models' => ['proposer'=>'a','critic'=>'b','verifier'=>'c','arbiter'=>'a']];
ForgeConfigurationValidator::assertValid($config);

$config = p18_cfg_base();
$config['council'] = ['role_models' => ['proposer'=>'a','critic'=>null,'verifier'=>'c','arbiter'=>'a']];
p18_cfg_assert_throws($config, 'Partial Council role-model configuration must fail closed.');

$config = p18_cfg_base();
$config['council'] = ['role_models' => ['proposer'=>'a','critic'=>'a','verifier'=>'a','arbiter'=>'a']];
p18_cfg_assert_throws($config, 'Governed Council requires at least three distinct trusted models.');

$config = p18_cfg_base();
$config['council'] = ['role_models' => ['proposer'=>'a','critic'=>'b','verifier'=>'c','arbiter'=>str_repeat('x',161)]];
p18_cfg_assert_throws($config, 'Council model slug length must be bounded.');

print "council-configuration-pass18: PASS\n";
