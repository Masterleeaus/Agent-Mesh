<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class BuildDomainTest extends TestCase
{
    public static function setUpBeforeClass(): void
    {
        $root = dirname(__DIR__, 2);
        require_once $root . '/System/Domain/BuildContext.php';
        require_once $root . '/System/Domain/BuildRequest.php';
        require_once $root . '/System/Domain/BuildSpec.php';
    }

    public function test_build_spec_fingerprint_is_deterministic_across_input_key_order(): void
    {
        $context = $this->context();
        $a = BuildSpec::fromRequest(new BuildRequest($context, 'extension', 'demo', ['b' => 2, 'a' => 1]));
        $b = BuildSpec::fromRequest(new BuildRequest($context, 'extension', 'demo', ['a' => 1, 'b' => 2]));
        self::assertSame($a->fingerprint(), $b->fingerprint());
    }

    public function test_build_context_rejects_zero_tenant(): void
    {
        $this->expectException(InvalidArgumentException::class);
        new BuildContext(0, 9, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', '44444444-4444-4444-8444-444444444444', 'forge:test');
    }

    private function context(): BuildContext
    {
        return new BuildContext(42, 9, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', '44444444-4444-4444-8444-444444444444', 'forge:test:42');
    }
}
