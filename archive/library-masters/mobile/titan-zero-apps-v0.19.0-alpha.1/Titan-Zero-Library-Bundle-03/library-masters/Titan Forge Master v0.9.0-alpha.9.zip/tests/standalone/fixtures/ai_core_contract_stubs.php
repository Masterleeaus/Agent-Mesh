<?php

declare(strict_types=1);

namespace App\Extensions\TitanAICore\System\DTO {
    final readonly class ActorContext {
        public function __construct(public string $actorId, public string $actorType, public string $companyId, public array $permissions = [], public int $authorityLevel = 0, public bool $trusted = false) {}
        public function toArray(): array { return ['actor_id'=>$this->actorId,'actor_type'=>$this->actorType,'company_id'=>$this->companyId,'permissions'=>$this->permissions,'authority_level'=>$this->authorityLevel,'trusted'=>$this->trusted]; }
    }
    final readonly class ExecutionIntent {
        public function __construct(public string $type, public string $objective, public array $parameters = []) {}
        public function toArray(): array { return ['type'=>$this->type,'objective'=>$this->objective,'parameters'=>$this->parameters]; }
    }
    final readonly class RuntimeContext {
        public function __construct(public string $companyId, public ActorContext $actor, public string $traceId, public string $correlationId, public string $causationId, public string $rootCausationId, public string $operationId, public string $idempotencyKey, public string $privacyClass = 'INTERNAL', public array $routingHints = []) {}
        public function toArray(): array { return ['company_id'=>$this->companyId,'actor'=>$this->actor->toArray(),'trace_id'=>$this->traceId,'correlation_id'=>$this->correlationId,'causation_id'=>$this->causationId,'root_causation_id'=>$this->rootCausationId,'operation_id'=>$this->operationId,'idempotency_key'=>$this->idempotencyKey,'privacy_class'=>$this->privacyClass,'routing_hints'=>$this->routingHints]; }
    }
    final readonly class PlanDependency { public function __construct(public string $stepId, public string $type='hard') {} public function toArray(): array { return ['step_id'=>$this->stepId,'type'=>$this->type]; } }
    final readonly class RetryPolicy { public function __construct(public int $maxAttempts=1, public string $backoff='none') {} public function toArray(): array { return ['max_attempts'=>$this->maxAttempts,'backoff'=>$this->backoff]; } }
    final readonly class PlanStep {
        public function __construct(public string $stepId, public string $name, public string $action, public array $dependsOn=[], public array $requiredInputs=[], public array $optionalInputs=[], public array $outputs=[], public int $timeoutSeconds=30, public RetryPolicy $retryPolicy=new RetryPolicy(), public mixed $workforceAssignment=null, public ?string $riskCeiling=null, public array $knowledgeRequirements=[]) {}
        public function toArray(): array { return ['step_id'=>$this->stepId,'name'=>$this->name,'action'=>$this->action,'depends_on'=>array_map(fn($v)=>$v->toArray(),$this->dependsOn),'required_inputs'=>$this->requiredInputs,'optional_inputs'=>$this->optionalInputs,'outputs'=>$this->outputs,'timeout_seconds'=>$this->timeoutSeconds,'retry_policy'=>$this->retryPolicy->toArray(),'workforce_assignment'=>$this->workforceAssignment,'risk_ceiling'=>$this->riskCeiling,'knowledge_requirements'=>$this->knowledgeRequirements]; }
    }
    final readonly class PlanEnvelope {
        public function __construct(public string $planId, public RuntimeContext $runtimeContext, public ExecutionIntent $intent, public array $steps=[], public array $constraints=[], public string $schemaVersion='1.0', public string $planSchemaVersion='1.0', public string $runtimeVersion='0.3.0') {}
        public function toArray(): array { return ['plan_id'=>$this->planId,'runtime_context'=>$this->runtimeContext->toArray(),'intent'=>$this->intent->toArray(),'steps'=>array_map(fn($v)=>$v->toArray(),$this->steps),'constraints'=>$this->constraints,'schema_version'=>$this->schemaVersion,'plan_schema_version'=>$this->planSchemaVersion,'runtime_version'=>$this->runtimeVersion]; }
    }
    final readonly class ValidationIssue { public function __construct(public string $severity, public string $code, public string $message, public ?string $stepId=null) {} public function toArray(): array { return ['severity'=>$this->severity,'code'=>$this->code,'message'=>$this->message,'step_id'=>$this->stepId]; } }
    final readonly class ValidationReport {
        public function __construct(public bool $valid, public bool $executable, public array $errors=[], public array $warnings=[], public array $suggestions=[], public string $validatorVersion='0.3.0') {}
        public function toArray(): array { return ['valid'=>$this->valid,'executable'=>$this->executable,'errors'=>array_map(fn($v)=>$v->toArray(),$this->errors),'warnings'=>array_map(fn($v)=>$v->toArray(),$this->warnings),'suggestions'=>array_map(fn($v)=>$v->toArray(),$this->suggestions),'validator_version'=>$this->validatorVersion]; }
    }
}
