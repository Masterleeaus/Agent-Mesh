<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
foreach([
 'System/Domain/BuildContext.php','System/Domain/BuildRequest.php','System/Domain/BuildSpec.php','System/Domain/BuildStep.php','System/Domain/BuildPlan.php','System/Domain/BuildArtifact.php','System/Domain/ArtifactSet.php','System/Domain/AiArtifactProposal.php','System/Domain/ValidationFinding.php',
 'System/Contracts/ForgeAiArtifactGatewayContract.php','System/Sandbox/SandboxWorkspace.php','System/Sandbox/SandboxWorkspaceFactory.php','System/AI/SandboxedAiArtifactGenerator.php','System/Validation/ArtifactValidatorContract.php','System/Validation/Validators/GenerationManifestValidator.php'
] as $file){require_once $root.'/'.$file;}
use App\Extensions\TitanForge\System\AI\SandboxedAiArtifactGenerator;
use App\Extensions\TitanForge\System\Contracts\ForgeAiArtifactGatewayContract;
use App\Extensions\TitanForge\System\Domain\AiArtifactProposal;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\BuildStep;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use App\Extensions\TitanForge\System\Validation\Validators\GenerationManifestValidator;
function fail4(string $m):never{fwrite(STDERR,"FAIL: {$m}\n");exit(1);} function ok4(bool $c,string $m):void{if(!$c)fail4($m);}
$base=sys_get_temp_dir().'/titan-forge-ai-manifest-'.bin2hex(random_bytes(4));
$ctx=new BuildContext(42,7,'11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','44444444-4444-4444-8444-444444444444','forge:ai:manifest:1','55555555-5555-4555-8555-555555555555');
$request=new BuildRequest($ctx,'extension','Create a safe extension.'); $spec=BuildSpec::fromRequest($request); $plan=new BuildPlan([new BuildStep('provider','forge.generate.provider')]);
$gateway=new class implements ForgeAiArtifactGatewayContract{public function available():bool{return true;} public function propose(BuildRequest $request,BuildSpec $spec,BuildPlan $plan):AiArtifactProposal{return new AiArtifactProposal(true,'titan-ai-core','plan-1',[['path'=>'safe.php','content'=>"<?php declare(strict_types=1);\n"]],[ 'model_provider'=>'provider','model_id'=>'model','model_route'=>'titan-ai-core','prompt_sha256'=>str_repeat('a',64),'input_sha256'=>str_repeat('b',64),'output_sha256'=>str_repeat('c',64),'template_version'=>'forge-ai-v1']);}};
$factory=new SandboxWorkspaceFactory($base,20,1024*1024); $generator=new SandboxedAiArtifactGenerator($gateway,$factory); $result=$generator->generate($request,$spec,$plan); $workspace=$factory->forContext($ctx); $validator=new GenerationManifestValidator();
ok4($validator->validate($spec,$workspace,$result['artifacts'])===[],'Complete AI generation manifest must validate.');
$path=$workspace->path('generation_manifest.json'); $manifest=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR); unset($manifest['model']['route'],$manifest['manifest_sha256']); $manifest['manifest_sha256']=hash('sha256',json_encode($manifest,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)); $workspace->write('generation_manifest.json',json_encode($manifest,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n"); $artifacts=$workspace->snapshot(); $findings=$validator->validate($spec,$workspace,$artifacts);
$rules=array_map(static fn($f)=>$f->rule,$findings); ok4(in_array('manifest.ai_provenance',$rules,true),'AI manifest missing model route must be rejected by manifest.ai_provenance.');
$workspace->destroy(); @rmdir($base.'/42'); @rmdir($base); fwrite(STDOUT,"PASS: AI generation manifest validation\n");
