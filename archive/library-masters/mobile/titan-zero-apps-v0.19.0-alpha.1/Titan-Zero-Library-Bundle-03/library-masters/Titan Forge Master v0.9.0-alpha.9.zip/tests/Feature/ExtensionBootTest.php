<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_manifest_resolves_the_exact_provider_and_release_identity(): void
    {
        $root = dirname(__DIR__, 2);
        $manifest = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);

        self::assertSame('titan-extension-v1', $manifest['schema']);
        self::assertSame('titan-forge', $manifest['slug']);
        self::assertSame('0.6.0-alpha.1', $manifest['version']);
        self::assertSame('TitanForge', $manifest['folder']);
        self::assertSame('App\\Extensions\\TitanForge\\System\\TitanForgeServiceProvider', $manifest['provider']);
        self::assertFileExists($root . '/System/TitanForgeServiceProvider.php');
    }

    public function test_provider_registers_config_repository_and_manager_without_eager_domain_execution(): void
    {
        $source = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanForgeServiceProvider.php');
        self::assertStringContainsString('ForgeConfiguration::fromArray', $source);
        self::assertStringContainsString('BuildRepositoryContract::class', $source);
        self::assertStringContainsString('ForgeManagerContract::class', $source);
        self::assertStringNotContainsString('registerBuild(', $source);
    }
}
