<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
foreach ([
    'System/Domain/BuildContext.php',
    'System/Domain/BuildArtifact.php',
    'System/Domain/ArtifactSet.php',
    'System/Domain/BuildRequest.php',
    'System/Domain/BuildSpec.php',
    'System/Domain/RiskDeclaration.php',
    'System/Domain/ValidationFinding.php',
    'System/Domain/ValidationResult.php',
    'System/Domain/CouncilReview.php',
    'System/Domain/ReleaseGateResult.php',
    'System/Contracts/ForgeRiskGatewayContract.php',
    'System/Contracts/ForgeShieldGatewayContract.php',
    'System/Contracts/ForgeCouncilGatewayContract.php',
    'System/Contracts/ForgeGovernanceGatewayContract.php',
    'System/Contracts/ForgeCommandBusGatewayContract.php',
    'System/Governance/ReleaseGovernanceService.php',
] as $file) require_once $root . '/' . $file;

use App\Extensions\TitanForge\System\Contracts\ForgeCommandBusGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Governance\ReleaseGovernanceService;

function p18_gate_assert(bool $condition, string $message): void { if (! $condition) throw new RuntimeException($message); }

final class P18Risk implements ForgeRiskGatewayContract {
    public function available(): bool { return true; }
    public function assess(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): RiskDeclaration {
        return new RiskDeclaration('high', false, 'titan-risk', [], ['execution_directive' => 'EXECUTE_MONITORED']);
    }
}
final class P18Shield implements ForgeShieldGatewayContract {
    public function available(): bool { return true; }
    public function inspect(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): ValidationResult { return ValidationResult::pass(); }
}
final class P18Governance implements ForgeGovernanceGatewayContract { public function available(): bool { return true; } public function unavailableReason(): ?string { return null; } }
final class P18Command implements ForgeCommandBusGatewayContract { public function available(): bool { return true; } public function unavailableReason(): ?string { return null; } }
final class P18Council implements ForgeCouncilGatewayContract {
    public function __construct(private readonly CouncilReview $review) {}
    public function available(): bool { return true; }
    public function governedDeliberationAvailable(): bool { return true; }
    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview { return $this->review; }
    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview { return $this->review; }
}

$context = new BuildContext(42, 7, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', '44444444-4444-4444-8444-444444444444', 'forge:pass18:gate', '55555555-5555-4555-8555-555555555555');
$spec = new BuildSpec($context, 'extension', 'Build a governed extension.');
$artifacts = new ArtifactSet([]);
$local = ValidationResult::pass();

$deliberated = new CouncilReview(true, true, 'deliberated', 'titan-model-council', ['decision_id' => 77, 'execution_authority' => 'advisory_only']);
$service = new ReleaseGovernanceService(new P18Risk(), new P18Shield(), new P18Council($deliberated), new P18Governance(), new P18Command());
$gate = $service->evaluate($spec, $artifacts, $local);
p18_gate_assert($gate->candidateStatus === 'validated' && ! $gate->blocked, 'Successful governed Council review must satisfy the Council portion of the gate.');
p18_gate_assert(! in_array('council.review_unsatisfied', $gate->reasons, true), 'Successful Council review must not add a Council hold reason.');

$escalated = new CouncilReview(true, true, 'escalated', 'titan-model-council', ['decision_id' => 78, 'execution_authority' => 'advisory_only']);
$service = new ReleaseGovernanceService(new P18Risk(), new P18Shield(), new P18Council($escalated), new P18Governance(), new P18Command());
$gate = $service->evaluate($spec, $artifacts, $local);
p18_gate_assert($gate->candidateStatus === 'approval_required' && $gate->blocked, 'Council escalation must hold release progression.');
p18_gate_assert(in_array('council.review_unsatisfied', $gate->reasons, true), 'Council escalation hold reason missing.');

$configuration = new CouncilReview(true, true, 'configuration_required', 'titan-model-council', ['reason' => 'trusted_role_models_not_configured']);
$service = new ReleaseGovernanceService(new P18Risk(), new P18Shield(), new P18Council($configuration), new P18Governance(), new P18Command());
$gate = $service->evaluate($spec, $artifacts, $local);
p18_gate_assert($gate->blocked && in_array('council.configuration_required', $gate->reasons, true), 'Missing trusted Council role-model policy must be explicit.');

print "council-release-gate-pass18: PASS\n";
