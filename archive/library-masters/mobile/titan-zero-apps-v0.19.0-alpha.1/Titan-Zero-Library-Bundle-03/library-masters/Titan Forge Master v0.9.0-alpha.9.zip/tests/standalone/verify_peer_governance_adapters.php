<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
foreach ([
    'System/Domain/BuildContext.php','System/Domain/BuildRequest.php','System/Domain/BuildSpec.php','System/Domain/BuildArtifact.php','System/Domain/ArtifactSet.php',
    'System/Domain/ValidationFinding.php','System/Domain/ValidationResult.php','System/Domain/RiskDeclaration.php','System/Domain/CouncilReview.php','System/Domain/ForgeSignalEvent.php',
    'System/Contracts/ForgeRiskGatewayContract.php','System/Contracts/ForgeShieldGatewayContract.php','System/Contracts/ForgeCouncilGatewayContract.php','System/Contracts/ForgeSignalGatewayContract.php',
    'System/Governance/TitanRiskGateway.php','System/Governance/TitanShieldGateway.php','System/Governance/TitanCouncilGateway.php','System/Governance/TitanSignalGateway.php',
] as $relative) {
    if (! is_file($root.'/'.$relative)) { throw new RuntimeException('Missing peer adapter file: '.$relative); }
    require_once $root.'/'.$relative;
}

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\ForgeSignalEvent;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Governance\TitanCouncilGateway;
use App\Extensions\TitanForge\System\Governance\TitanRiskGateway;
use App\Extensions\TitanForge\System\Governance\TitanShieldGateway;
use App\Extensions\TitanForge\System\Governance\TitanSignalGateway;

function peer_assert(bool $condition,string $message):void{if(!$condition){throw new RuntimeException($message);}}

final class FakeRiskInput {
    public array $args;
    public function __construct(...$args){$this->args=$args;}
}
final class FakeRiskResult {
    public function toArray():array{return ['assessment'=>['level'=>'HIGH','score'=>73,'decision'=>'REVIEW','reasons'=>[['code'=>'risk.high','message'=>'consequential generation','contribution'=>0.6]],'remediation'=>[['code'=>'approve','message'=>'human approval']],'policy_version'=>'risk-2.1'],'execution_directive'=>'HOLD_FOR_APPROVAL','may_dispatch_to_executor'=>false];}
}
final class FakeRiskPeer { public ?FakeRiskInput $input=null; public function evaluate(FakeRiskInput $input):FakeRiskResult{$this->input=$input;return new FakeRiskResult();} }

final class FakeShieldContext { public array $args; public function __construct(...$args){$this->args=$args;} }
final class FakeShieldPeer {
    public array $findings=[];
    public function health():array{return ['status'=>'inspection-foundation'];}
    public function determineGovernanceResponse(array $finding,FakeShieldContext $context):array{
        $this->findings[]=$finding;
        return ['block_progression'=>($finding['severity']==='critical'),'requires_human_review'=>($finding['severity']==='critical'),'request_risk'=>true,'request_assurance'=>false,'request_command_bus'=>false,'request_council'=>false,'reason_codes'=>['shield.reviewed']];
    }
}

final class FakeCouncilRequest { public array $args; public function __construct(...$args){$this->args=$args;} }
final class FakeActivation { public function toArray():array{return ['strategy'=>'parallel_consensus','activation_reason'=>'high_risk','requested_participant_count'=>3];} }
final class FakeCouncilPeer {
    public ?FakeCouncilRequest $request=null;
    public function health():array{return ['status'=>'risk-integrated','governed_deliberation'=>false];}
    public function decideActivation(FakeCouncilRequest $request):FakeActivation{$this->request=$request;return new FakeActivation();}
}

final class FakeSignalReceipt { public function toArray():array{return ['event_id'=>'evt-1','recorded_at'=>'2026-08-11T00:00:00+00:00','duplicate'=>false];} }
final class FakeSignalPeer { public array $signals=[]; public function emit(array $signal):FakeSignalReceipt{$this->signals[]=$signal;return new FakeSignalReceipt();} }

$context=new BuildContext(42,7,'11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','44444444-4444-4444-8444-444444444444','forge:peer:test');
$spec=BuildSpec::workforceTeam($context,'solo',['titan.operations_manager']);
$artifacts=new ArtifactSet([]);
$local=ValidationResult::pass();

$riskPeer=new FakeRiskPeer();
$risk=new TitanRiskGateway(fn(string $contract):?object=>$contract==='risk.contract'?$riskPeer:null,'risk.contract',FakeRiskInput::class);
peer_assert($risk->available(),'Risk adapter should be available when the contract resolves.');
$riskResult=$risk->assess($spec,$artifacts,$local);
peer_assert($riskResult->level==='high','Risk HIGH must normalize to Forge high.');
peer_assert($riskResult->blocked,'Risk HOLD_FOR_APPROVAL must block release progression.');
peer_assert(($riskResult->metadata['execution_directive']??null)==='HOLD_FOR_APPROVAL','Risk directive metadata missing.');
peer_assert(($riskResult->reasons[0]??null)==='risk.high: consequential generation','Structured Risk reason was not normalized.');
peer_assert(($riskResult->metadata['remediation'][0]['code']??null)==='approve','Structured Risk remediation must be preserved.');
peer_assert($riskPeer->input instanceof FakeRiskInput,'Risk peer input was not constructed.');
peer_assert(($riskPeer->input->args[0]??null)===42,'Risk tenant context was not preserved.');
peer_assert(($riskPeer->input->args[4]??null)==='forge.release_candidate','Risk capability mismatch.');

$shieldPeer=new FakeShieldPeer();
$shield=new TitanShieldGateway(fn(string $contract):?object=>$contract==='shield.contract'?$shieldPeer:null,'shield.contract',FakeShieldContext::class);
peer_assert($shield->available(),'Shield adapter should be available when manager resolves.');
$pass=$shield->inspect($spec,$artifacts,$local);
peer_assert($pass->passed(),'Shield should pass when local validation has no findings and health is available.');
$criticalLocal=new ValidationResult([new ValidationFinding('critical','forge.secret','Secret-like material detected','Generated/Bad.php',true)]);
$shieldFail=$shield->inspect($spec,$artifacts,$criticalLocal);
peer_assert(!$shieldFail->passed(),'Shield governance response must preserve blocking critical findings.');
peer_assert(count($shieldPeer->findings)===1,'Shield adapter must map local findings exactly once.');
peer_assert(($shieldPeer->findings[0]['definition_key']??null)==='forge_artifact_validation','Shield definition key mismatch.');
peer_assert(isset($shieldPeer->findings[0]['definition_hash']),'Shield definition hash missing.');

$councilPeer=new FakeCouncilPeer();
$council=new TitanCouncilGateway(fn(string $contract):?object=>$contract==='council.contract'?$councilPeer:null,'council.contract',FakeCouncilRequest::class);
peer_assert($council->available(),'Council adapter should be available when gateway resolves.');
$review=$council->assess($spec,$riskResult,$pass);
peer_assert($review->required && $review->available,'High-risk Council activation assessment should be recorded.');
peer_assert($review->status==='activation_assessed','Council adapter must not claim governed deliberation completion.');
peer_assert(($review->metadata['governed_deliberation']??true)===false,'Council governed_deliberation=false must be preserved.');
peer_assert(str_contains((string)($councilPeer->request->args[0]??''),'release candidate'),'Council prompt should be bounded release metadata, not source code.');

$signalPeer=new FakeSignalPeer();
$signal=new TitanSignalGateway(fn(string $contract):?object=>$contract==='signal.contract'?$signalPeer:null,'signal.contract');
peer_assert($signal->available(),'Signal adapter should be available when emitter resolves.');
$event=new ForgeSignalEvent('forge.validation.passed',42,$context->traceId,$context->correlationId,$context->causationId,$context->operationId,7,$context->idempotencyKey,['build_id'=>99]);
$receipt=$signal->emit($event);
peer_assert(($receipt['event_id']??null)==='evt-1','Signal receipt was not normalized.');
peer_assert(($signalPeer->signals[0]['company_id']??null)===42,'Signal tenant context missing.');
peer_assert(($signalPeer->signals[0]['event_type']??null)==='forge.validation.passed','Signal event type mismatch.');
peer_assert(($signalPeer->signals[0]['source']??null)==='titan-forge','Signal source mismatch.');

$missing=new TitanRiskGateway(fn(string $contract):?object=>null,'risk.contract',FakeRiskInput::class);
peer_assert(!$missing->available(),'Missing peer contract must report unavailable.');
peer_assert($missing->assess($spec,$artifacts,$local)->level==='unavailable','Missing Risk must fail closed.');

echo "peer-governance-adapters: PASS\n";
