<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) {
        $errors[] = $message;
    }
};

$migration = $root . '/database/migrations/2026_08_11_000002_create_forge_domain_foundation.php';
$check(is_file($migration), 'missing forward domain migration');
if (is_file($migration)) {
    $source = (string) file_get_contents($migration);
    foreach (['causation_id', 'operation_id', 'actor_id', 'idempotency_key', 'spec_fingerprint'] as $column) {
        $check(str_contains($source, "'{$column}'"), 'missing build trace column: ' . $column);
    }
    foreach ([
        'titan_forge_build_specs',
        'titan_forge_build_plans',
        'titan_forge_artifacts',
        'titan_forge_validation_runs',
        'titan_forge_validation_findings',
        'titan_forge_release_candidates',
        'titan_forge_approvals',
        'titan_forge_releases',
        'titan_forge_receipts',
    ] as $table) {
        $check(str_contains($source, "'{$table}'"), 'missing normalized table: ' . $table);
    }
    $check(str_contains($source, 'function down('), 'forward domain migration missing down()');
}

$modelFiles = [
    'System/Models/ForgeBuild.php',
    'System/Models/ForgeBuildSpec.php',
    'System/Models/ForgeBuildPlan.php',
    'System/Models/ForgeArtifact.php',
    'System/Models/ForgeValidationRun.php',
    'System/Models/ForgeValidationFinding.php',
    'System/Models/ForgeReleaseCandidate.php',
    'System/Models/ForgeApproval.php',
    'System/Models/ForgeRelease.php',
    'System/Models/ForgeReceipt.php',
];
foreach ($modelFiles as $file) {
    $check(is_file($root . '/' . $file), 'missing persistence model: ' . $file);
}

$repository = $root . '/System/Persistence/EloquentBuildRepository.php';
$check(is_file($repository), 'missing EloquentBuildRepository');
if (is_file($repository)) {
    $source = (string) file_get_contents($repository);
    $check(str_contains($source, "where('company_id'"), 'repository tenant filter missing');
    $check(str_contains($source, "'idempotency_key'") && str_contains($source, 'firstOrCreate'), 'repository idempotency lookup missing');
    $check(str_contains($source, 'spec_fingerprint'), 'repository idempotency fingerprint guard missing');
}

if ($errors !== []) {
    fwrite(STDERR, "Titan Forge persistence contract FAIL\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "Titan Forge persistence contract PASS\n";
