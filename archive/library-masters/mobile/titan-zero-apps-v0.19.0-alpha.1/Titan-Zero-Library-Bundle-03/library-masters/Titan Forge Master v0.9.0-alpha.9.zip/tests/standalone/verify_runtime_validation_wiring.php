<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function mustContain(string $file,array $needles):void{$s=file_get_contents($file);if(!is_string($s))throw new RuntimeException('Cannot read '.$file);foreach($needles as $n){if(!str_contains($s,$n))throw new RuntimeException(basename($file).' missing: '.$n);}}
mustContain($root.'/System/Contracts/BuildRepositoryContract.php',['recordValidation(','ValidationResult $result']);
mustContain($root.'/System/Persistence/EloquentBuildRepository.php',['ForgeValidationRun','ForgeValidationFinding','recordValidation(','validator_set','validation_run_id']);
mustContain($root.'/System/Services/ForgeManager.php',['ArtifactValidationPipeline','SandboxWorkspaceFactory','markStatus($build,\'validating\'','recordValidation(','validation_failed','validatorIds()','ReleaseGovernanceService','ReleaseRepositoryContract','ForgeSignalGatewayContract','recordCandidate(','forge.release.candidate_created']);
mustContain($root.'/System/TitanForgeServiceProvider.php',['SandboxWorkspaceFactory','ValidatorRegistry','ArtifactValidationPipeline','ArtifactPolicyValidator','WorkspaceIntegrityValidator','GeneratedContentSecretValidator','GenerationManifestValidator','GeneratedCodeSafetyValidator','JsonSyntaxValidator','PhpSyntaxValidator','EloquentReleaseRepository','TitanRiskGateway','TitanShieldGateway','TitanCouncilGateway','TitanSignalGateway','UnavailableGovernanceGateway','UnavailableCommandBusGateway','ReleaseGovernanceService']);
echo "runtime-validation-wiring: PASS\n";
