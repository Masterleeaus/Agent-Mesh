<?php

declare(strict_types=1);

$root=dirname(__DIR__,2);
foreach([
'System/Domain/BuildContext.php','System/Domain/BuildSpec.php','System/Domain/BuildArtifact.php','System/Domain/ArtifactSet.php',
'System/Workforce/RoleCatalog.php','System/Sandbox/SandboxWorkspace.php','System/Sandbox/SandboxWorkspaceFactory.php','System/Generation/StaticRoleTemplateEngine.php'
] as $f){require_once $root.'/'.$f;}

use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Generation\StaticRoleTemplateEngine;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;
use App\Extensions\TitanForge\System\Workforce\RoleCatalog;

function check2(bool $c,string $m):void{if(!$c)throw new RuntimeException($m);}
$tmp=sys_get_temp_dir().'/titan-forge-generation-'.bin2hex(random_bytes(6));
$catalog=RoleCatalog::fromJsonFile($root.'/resources/workforce/roles-bootstrap.json');
$roles=['titan.operations_manager','titan.receptionist','titan.booking_coordinator','titan.scheduler','titan.job_coordinator','titan.billing_coordinator'];
$rootCause='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
$context=new BuildContext(9,3,'11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333','44444444-4444-4444-8444-444444444444','generation-sandbox-test',$rootCause);
$spec=BuildSpec::workforceTeam($context,'solo',$roles,['authority'=>'titan-ai-workforce']);
$factory=new SandboxWorkspaceFactory($tmp,100,500000);
$engine=new StaticRoleTemplateEngine($root.'/stubs/roles/role.php.stub',$catalog,$factory);
$first=$engine->generate($spec);
check2(isset($first['artifacts']) && $first['artifacts'] instanceof App\Extensions\TitanForge\System\Domain\ArtifactSet,'Generation must return ArtifactSet.');
check2($first['artifacts']->count()===13,'Six roles should create 12 role files plus generation manifest.');
check2(str_starts_with($first['workspace'],$tmp.'/9/'),'Workspace must be tenant-scoped under configured sandbox root.');
check2(($first['manifest']['deployment_authority']??null)==='none','Generated manifest must deny deployment authority.');
check2(($first['manifest']['root_causation_id']??null)===$rootCause,'Generation manifest must preserve root_causation_id.');
$digest=$first['artifacts']->digest();
$workspace=$factory->forContext($context);
$workspace->write('stale.txt','stale');
check2(is_file($workspace->path('stale.txt')),'Test stale file should exist before repeat generation.');
$second=$engine->generate($spec);
check2(!is_file($workspace->path('stale.txt')),'Generation must reset its sandbox and remove stale artifacts.');
check2($second['artifacts']->digest()===$digest,'Deterministic repeat generation must produce same artifact digest.');
$factory->forContext($context)->destroy();
@rmdir($tmp.'/9'); @rmdir($tmp);
echo "sandbox-generation: PASS\n";
