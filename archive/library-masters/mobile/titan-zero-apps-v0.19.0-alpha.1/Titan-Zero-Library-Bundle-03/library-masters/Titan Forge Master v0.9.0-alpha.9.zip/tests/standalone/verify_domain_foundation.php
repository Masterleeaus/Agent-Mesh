<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) {
        $errors[] = $message;
    }
};

$files = [
    'System/Domain/BuildContext.php',
    'System/Domain/BuildRequest.php',
    'System/Domain/BuildSpec.php',
    'System/Domain/BuildStep.php',
    'System/Domain/BuildPlan.php',
    'System/Domain/BuildArtifact.php',
    'System/Domain/ArtifactSet.php',
    'System/Domain/GenerationResult.php',
    'System/Domain/ValidationFinding.php',
    'System/Domain/ValidationResult.php',
    'System/Domain/ReleaseCandidate.php',
    'System/Config/ForgeConfiguration.php',
    'System/Queue/BuildJobPayload.php',
];
foreach ($files as $file) {
    $check(is_file($root . '/' . $file), 'missing domain file: ' . $file);
}

if ($errors === []) {
    foreach ($files as $file) {
        require_once $root . '/' . $file;
    }

    $context = new \App\Extensions\TitanForge\System\Domain\BuildContext(
        companyId: 42,
        actorId: 7,
        traceId: '11111111-1111-4111-8111-111111111111',
        correlationId: '22222222-2222-4222-8222-222222222222',
        causationId: '33333333-3333-4333-8333-333333333333',
        operationId: '44444444-4444-4444-8444-444444444444',
        idempotencyKey: 'forge:test:42:request-1',
    );
    $check($context->companyId === 42, 'BuildContext tenant mismatch');

    $threw = false;
    try {
        new \App\Extensions\TitanForge\System\Domain\BuildContext(0, 7, 't', 'c', 'a', 'o', 'i');
    } catch (InvalidArgumentException) {
        $threw = true;
    }
    $check($threw, 'BuildContext must reject missing/invalid tenant');

    $request = new \App\Extensions\TitanForge\System\Domain\BuildRequest($context, 'extension', 'Create a governed test extension', ['slug' => 'demo']);
    $specA = \App\Extensions\TitanForge\System\Domain\BuildSpec::fromRequest($request);
    $specB = \App\Extensions\TitanForge\System\Domain\BuildSpec::fromRequest($request);
    $check($specA->fingerprint() === $specB->fingerprint(), 'BuildSpec fingerprint must be deterministic');

    $plan = new \App\Extensions\TitanForge\System\Domain\BuildPlan([
        new \App\Extensions\TitanForge\System\Domain\BuildStep('manifest', 'manifest'),
        new \App\Extensions\TitanForge\System\Domain\BuildStep('provider', 'provider', ['manifest']),
    ]);
    $check(count($plan->steps) === 2, 'BuildPlan step count mismatch');

    $artifact = new \App\Extensions\TitanForge\System\Domain\BuildArtifact('System/Demo.php', hash('sha256', 'demo'), 'php', 4);
    $set = new \App\Extensions\TitanForge\System\Domain\ArtifactSet([$artifact]);
    $check($set->count() === 1, 'ArtifactSet count mismatch');

    $unsafe = false;
    try {
        new \App\Extensions\TitanForge\System\Domain\BuildArtifact('../escape.php', hash('sha256', 'x'), 'php', 1);
    } catch (InvalidArgumentException) {
        $unsafe = true;
    }
    $check($unsafe, 'BuildArtifact must reject traversal paths');

    $validation = new \App\Extensions\TitanForge\System\Domain\ValidationResult([
        new \App\Extensions\TitanForge\System\Domain\ValidationFinding('warning', 'forge.example', 'non-blocking example', null, false),
    ]);
    $check($validation->passed(), 'non-blocking validation should pass');

    $blocking = new \App\Extensions\TitanForge\System\Domain\ValidationResult([
        new \App\Extensions\TitanForge\System\Domain\ValidationFinding('critical', 'forge.block', 'blocking example', 'System/Demo.php', true),
    ]);
    $check(! $blocking->passed(), 'blocking validation must fail');

    $config = \App\Extensions\TitanForge\System\Config\ForgeConfiguration::fromArray([
        'enabled' => true,
        'queue' => 'titan-forge',
        'tenant_key' => 'company_id',
    ]);
    $check($config->queue === 'titan-forge', 'ForgeConfiguration queue mismatch');
    $payload = new \App\Extensions\TitanForge\System\Queue\BuildJobPayload(10, $context);
    $payloadData = $payload->toArray();
    $check(($payloadData['company_id'] ?? null) === 42, 'queued payload must preserve tenant');
    $check(($payloadData['causation_id'] ?? null) === $context->causationId, 'queued payload must preserve causation');
    $check(($payloadData['idempotency_key'] ?? null) === $context->idempotencyKey, 'queued payload must preserve idempotency');


    $badConfig = false;
    try {
        \App\Extensions\TitanForge\System\Config\ForgeConfiguration::fromArray(['enabled' => true, 'queue' => '../bad', 'tenant_key' => 'tenant_id']);
    } catch (InvalidArgumentException) {
        $badConfig = true;
    }
    $check($badConfig, 'ForgeConfiguration must fail closed on invalid tenant/queue config');
}

if ($errors !== []) {
    fwrite(STDERR, "Titan Forge domain foundation FAIL\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "Titan Forge domain foundation PASS\n";
