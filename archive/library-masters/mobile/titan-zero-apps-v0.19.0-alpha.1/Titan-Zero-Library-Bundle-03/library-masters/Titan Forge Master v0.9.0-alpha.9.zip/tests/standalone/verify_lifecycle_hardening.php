<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $ok, string $message) use (&$errors): void {
    if (! $ok) {
        $errors[] = $message;
    }
};

$provider = (string) file_get_contents($root . '/System/TitanForgeServiceProvider.php');
$check(substr_count($provider, "return 'titan-forge';") === 1, 'registerKey is not stable');
$check(str_contains($provider, "'titan-forge-config'"), 'scoped publish tag missing');
$check(str_contains($provider, 'ForgeConfiguration::fromArray'), 'fail-fast ForgeConfiguration validation missing');
$check(str_contains($provider, 'RequireForgeTenant::class'), 'runtime tenant middleware missing from user Forge routes');
$check(str_contains($provider, 'ForgeTenantResolver::class'), 'strict Forge tenant resolver binding missing');
$check(str_contains($provider, 'File::delete(config_path'), 'owned config uninstall missing');
$check(! str_contains($provider, 'Schema::drop'), 'provider uninstall must not drop retained Forge data');

$forward = (string) file_get_contents($root . '/database/migrations/2026_08_11_000002_create_forge_domain_foundation.php');
$check(str_contains($forward, "unique(['company_id', 'idempotency_key']"), 'database idempotency uniqueness gate missing');

$tests = '';
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/tests', FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $tests .= (string) file_get_contents($file->getPathname());
    }
}
$placeholder = 'assertTrue' . '(true)';
$check(! str_contains($tests, $placeholder), 'placeholder test remains');

if ($errors !== []) {
    fwrite(STDERR, "Titan Forge lifecycle hardening FAIL\n - " . implode("\n - ", $errors) . "\n");
    exit(1);
}

echo "Titan Forge lifecycle hardening PASS\n";
