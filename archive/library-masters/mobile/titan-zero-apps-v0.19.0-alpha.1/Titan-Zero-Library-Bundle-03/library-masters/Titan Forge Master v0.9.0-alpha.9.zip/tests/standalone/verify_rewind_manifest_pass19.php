<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);$m=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
function p19m(bool $c,string $m):void{if(!$c)throw new RuntimeException($m);}
p19m(in_array('forge.rewind.source',$m['capabilities']??[],true),'forge.rewind.source capability missing.');
p19m(in_array('rewind-source-contributor',$m['architecture']['modifiers']??[],true),'rewind-source-contributor modifier missing.');
$c=null;foreach($m['contributions']??[] as $x){if(($x['type']??null)==='rewind-source'){$c=$x;break;}}
p19m(is_array($c),'rewind-source contribution missing.');
p19m(($c['key']??null)==='titan-forge.rewind-source','Wrong Rewind contribution key.');
p19m(($c['registry']??null)==='titan.rewind.sources.v1','Wrong Rewind registry.');
p19m(($c['authority_neutral']??null)===true,'Rewind contribution must be authority-neutral.');
p19m(($c['consumer_contract']['write_policy']??null)==='read-only','Rewind consumer must be read-only.');
$r=null;foreach($m['rewind_sources']??[] as $x){if(($x['id']??null)==='titan-forge.rewind-source'){$r=$x;break;}}
p19m(is_array($r),'rewind_sources declaration missing.');
p19m(($r['tenant_key']??null)==='company_id','Rewind source tenant key mismatch.');
p19m(($r['historical_retrieval']??null)===true,'Historical retrieval declaration required.');
p19m(($r['supports_as_of']??null)===false,'Forge must not claim unsupported point-in-time reconstruction.');
p19m(($r['ordering_guarantee']??null)==='causation-aware','Ordering guarantee mismatch.');
p19m(($r['source_hash_support']??null)===true,'Source hash support required.');
p19m(($r['completeness_states']??[])===['COMPLETE','PARTIAL','STALE','UNAVAILABLE'],'Completeness states mismatch.');
echo "rewind-manifest-pass19: PASS\n";
