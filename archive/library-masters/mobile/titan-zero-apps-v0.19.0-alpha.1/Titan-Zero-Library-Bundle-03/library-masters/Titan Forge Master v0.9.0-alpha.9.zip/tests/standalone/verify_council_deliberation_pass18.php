<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);

foreach ([
    'System/Domain/BuildContext.php',
    'System/Domain/BuildArtifact.php',
    'System/Domain/ArtifactSet.php',
    'System/Domain/BuildRequest.php',
    'System/Domain/BuildSpec.php',
    'System/Domain/RiskDeclaration.php',
    'System/Domain/ValidationFinding.php',
    'System/Domain/ValidationResult.php',
    'System/Domain/CouncilReview.php',
    'System/Contracts/ForgeCouncilGatewayContract.php',
    'System/Governance/TitanCouncilGateway.php',
] as $file) {
    require_once $root . '/' . $file;
}

use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildArtifact;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Governance\TitanCouncilGateway;

function p18_assert(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

final class P18CouncilRequest
{
    public array $args;
    public function __construct(...$args) { $this->args = $args; }
}

final class P18Activation
{
    public function toArray(): array
    {
        return [
            'strategy' => 'governed_deliberation',
            'activation_reason' => 'high_risk',
            'requested_participant_count' => 4,
        ];
    }
}

class P18CouncilPeer
{
    public ?P18CouncilRequest $request = null;
    public array $roleModels = [];

    public function health(): array
    {
        return [
            'status' => 'governed-deliberation-ready',
            'version' => '0.7.0',
            'governed_deliberation' => true,
        ];
    }

    public function decideActivation(P18CouncilRequest $request): P18Activation
    {
        $this->request = $request;
        return new P18Activation();
    }

    public function runGoverned(P18CouncilRequest $request, array $roleModels): array
    {
        $this->request = $request;
        $this->roleModels = $roleModels;
        return [
            'decision_id' => 77,
            'billing' => ['reservation_id' => 'owned-by-council'],
            'result' => [
                'status' => 'completed',
                'strategy' => 'governed_deliberation',
                'final_answer' => 'Advisory recommendation: revise one high-risk boundary before release.',
                'participants' => [
                    'proposer' => ['model_slug' => 'model-a', 'response_text' => 'private participant text A'],
                    'critic' => ['model_slug' => 'model-b', 'response_text' => 'private participant text B'],
                    'verifier' => ['model_slug' => 'model-c', 'response_text' => 'private participant text C'],
                    'arbiter' => ['model_slug' => 'model-a', 'response_text' => 'private participant text D'],
                ],
                'actual_participant_count' => 4,
                'requires_escalation' => false,
                'confidence_percent' => 88,
                'execution_authority' => 'advisory_only',
                'postflight_risk' => ['level' => 'high', 'requires_escalation' => false],
            ],
        ];
    }
}

$context = new BuildContext(
    42,
    7,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    '44444444-4444-4444-8444-444444444444',
    'forge:pass18:test',
    '55555555-5555-4555-8555-555555555555',
);
$spec = new BuildSpec($context, 'extension', 'Generate sensitive source that must never be copied into Council prompts.', ['secret_input' => 'do-not-send']);
$artifact = new BuildArtifact(
    'System/Sensitive.php',
    str_repeat('a', 64),
    'php',
    123,
    ['content' => '<?php $secret = "do-not-send";'],
);
$artifacts = new ArtifactSet([$artifact]);
$risk = new RiskDeclaration('high', false, 'titan-risk', ['High consequence architecture change.'], ['execution_directive' => 'EXECUTE_MONITORED']);
$shield = ValidationResult::pass(['One non-blocking warning.']);
$models = [
    'proposer' => 'model-a',
    'critic' => 'model-b',
    'verifier' => 'model-c',
    'arbiter' => 'model-a',
];

$peer = new P18CouncilPeer();
$gateway = new TitanCouncilGateway(
    fn (string $contract): ?object => $contract === 'council.contract' ? $peer : null,
    'council.contract',
    P18CouncilRequest::class,
    $models,
);

p18_assert($gateway->available(), 'Council peer should resolve.');
p18_assert($gateway->governedDeliberationAvailable(), 'Council v0.7 governed deliberation should be detected.');
$review = $gateway->deliberate($spec, $artifacts, $risk, $shield);
p18_assert($review->required && $review->available, 'High-risk Council review must be required and available.');
p18_assert($review->status === 'deliberated', 'Successful governed Council review must map to deliberated status.');
p18_assert($review->satisfied(), 'Successful governed advisory review should satisfy the Council gate.');
p18_assert(($review->metadata['decision_id'] ?? null) === 77, 'Council decision id must be retained as a receipt pointer.');
p18_assert(($review->metadata['execution_authority'] ?? null) === 'advisory_only', 'Council execution authority must remain advisory_only.');
p18_assert(($review->metadata['confidence_percent'] ?? null) === 88, 'Council confidence must be retained.');
p18_assert(($review->metadata['actual_participant_count'] ?? null) === 4, 'Participant count must be retained.');
p18_assert(isset($review->metadata['final_answer_sha256']), 'Council final answer must be represented by a hash receipt.');
p18_assert(($review->metadata['role_models_sha256'] ?? null) === hash('sha256', json_encode($models, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES)), 'Role assignment hash mismatch.');

$encoded = json_encode($review->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
p18_assert(! str_contains($encoded, 'private participant text'), 'Forge must not persist participant response text.');
p18_assert(! str_contains($encoded, 'Advisory recommendation:'), 'Forge must not persist the raw Council final answer.');
p18_assert(! str_contains($encoded, 'response_text'), 'Forge review receipt must not carry participant response_text fields.');

p18_assert($peer->request instanceof P18CouncilRequest, 'Council request must be constructed.');
p18_assert(($peer->request->args[3] ?? null) === 'governed_deliberation', 'Forge must explicitly request governed_deliberation.');
p18_assert(($peer->request->args[9] ?? null) === $context->rootCausationId, 'root_causation_id must reach Council.');
p18_assert($peer->roleModels === $models, 'Trusted role-model policy must be passed unchanged to Council.');
$prompt = (string) ($peer->request->args[0] ?? '');
p18_assert(str_contains($prompt, $artifacts->digest()), 'Bounded Council packet must include artifact-set digest.');
p18_assert(str_contains($prompt, 'System/Sensitive.php'), 'Bounded Council packet may include artifact paths.');
p18_assert(! str_contains($prompt, 'do-not-send'), 'Build instruction/input secrets must not be copied to Council.');
p18_assert(! str_contains($prompt, '<?php'), 'Artifact contents must not be copied to Council.');

$missingConfig = new TitanCouncilGateway(
    fn (string $contract): ?object => $peer,
    'council.contract',
    P18CouncilRequest::class,
    [],
);
$configReview = $missingConfig->deliberate($spec, $artifacts, $risk, $shield);
p18_assert($configReview->status === 'configuration_required', 'Missing trusted role-model policy must fail closed as configuration_required.');
p18_assert(! $configReview->satisfied(), 'configuration_required cannot satisfy Council gate.');

final class P18EscalatingPeer extends P18CouncilPeer
{
    public function runGoverned(P18CouncilRequest $request, array $roleModels): array
    {
        $base = parent::runGoverned($request, $roleModels);
        $base['result']['requires_escalation'] = true;
        return $base;
    }
}
$escalating = new P18EscalatingPeer();
$escalationGateway = new TitanCouncilGateway(fn (string $contract): ?object => $escalating, 'council.contract', P18CouncilRequest::class, $models);
$escalated = $escalationGateway->deliberate($spec, $artifacts, $risk, $shield);
p18_assert($escalated->status === 'escalated' && ! $escalated->satisfied(), 'Council escalation must remain a release hold.');

final class P18AuthorityPeer extends P18CouncilPeer
{
    public function runGoverned(P18CouncilRequest $request, array $roleModels): array
    {
        $base = parent::runGoverned($request, $roleModels);
        $base['result']['execution_authority'] = 'mutation_allowed';
        return $base;
    }
}
$authorityPeer = new P18AuthorityPeer();
$authorityGateway = new TitanCouncilGateway(fn (string $contract): ?object => $authorityPeer, 'council.contract', P18CouncilRequest::class, $models);
$authorityReview = $authorityGateway->deliberate($spec, $artifacts, $risk, $shield);
p18_assert($authorityReview->status === 'rejected', 'Any Council result claiming mutation authority must be rejected by Forge.');

$legacyPeer = new class {
    public function health(): array { return ['governed_deliberation' => false]; }
    public function decideActivation(P18CouncilRequest $request): P18Activation { return new P18Activation(); }
};
$legacy = new TitanCouncilGateway(fn (string $contract): ?object => $legacyPeer, 'council.contract', P18CouncilRequest::class, $models);
p18_assert(! $legacy->governedDeliberationAvailable(), 'Activation-only Council must not be mistaken for governed deliberation.');

print "council-deliberation-pass18: PASS\n";
