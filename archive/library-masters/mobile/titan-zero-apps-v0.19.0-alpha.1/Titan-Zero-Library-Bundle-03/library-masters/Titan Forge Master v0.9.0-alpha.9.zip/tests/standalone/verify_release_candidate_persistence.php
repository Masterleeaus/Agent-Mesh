<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function rc_need(string $file,array $needles):void{
    $text=file_get_contents($file); if(!is_string($text))throw new RuntimeException('Cannot read '.$file);
    foreach($needles as $needle){if(!str_contains($text,$needle))throw new RuntimeException(basename($file).' missing: '.$needle);}
}
rc_need($root.'/System/Persistence/EloquentReleaseRepository.php',[
    'implements ReleaseRepositoryContract','updateOrCreate(','validation_run_id','company_id','artifact_set_hash','validation_fingerprint',
    '\'gate_fingerprint\' => $gate->fingerprint()', "'root_causation_id'", "'deployment_authority' => 'none'", "where('company_id'"
]);
rc_need($root.'/System/Services/ForgeManager.php',[
    'new ReleaseCandidate(','recordCandidate(','release_candidate_id','release_candidate_status','release_gate_fingerprint',"'deployment_authority' => 'none'"
]);
rc_need($root.'/database/migrations/2026_08_11_000002_create_forge_domain_foundation.php',[
    "Schema::create('titan_forge_release_candidates'", "'validation_run_id'", "'artifact_set_hash'", "'validation_fingerprint'"
]);
$manifest=json_decode((string)file_get_contents($root.'/extension.manifest.json'),true,512,JSON_THROW_ON_ERROR);
if(!in_array('titan_forge_release_candidates',$manifest['database']['owned_tables']??[],true))throw new RuntimeException('Release candidate table ownership missing.');
if(in_array('forge.release.execute',$manifest['capabilities']??[],true))throw new RuntimeException('Forge must not claim release execution capability.');
if(($manifest['authority']['cross_domain_write_policy']??null)!=='command-bus-only')throw new RuntimeException('Release execution must remain outside Forge behind Command Bus authority.');
if(($manifest['governance']['command_bus']??null)!=='required')throw new RuntimeException('Command Bus must remain required for release execution.');
echo "release-candidate-persistence: PASS\n";
