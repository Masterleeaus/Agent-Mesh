<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function fail3(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok3(bool $condition, string $message): void { if (!$condition) fail3($message); }

$contract = (string) file_get_contents($root . '/System/Contracts/BuildRepositoryContract.php');
ok3(str_contains($contract, 'recordPlan('), 'Build repository must persist typed build plans.');
ok3(str_contains($contract, 'array $metadata = []'), 'Artifact persistence must accept provenance metadata without breaking static generators.');

$repo = (string) file_get_contents($root . '/System/Persistence/EloquentBuildRepository.php');
foreach (['source_plan_id','source_runtime_version','provenance','recordPlan'] as $needle) {
    ok3(str_contains($repo, $needle), "Eloquent repository missing AI planning persistence field: {$needle}");
}
ok3(str_contains($repo, "'metadata'=>\$metadata"), 'Artifact metadata must persist AI provenance.');

$migrations = glob($root . '/database/migrations/*ai_planning*forge_build_plans*.php');
ok3(is_array($migrations) && count($migrations) === 1, 'Exactly one forward AI planning provenance migration is required.');
$migration = (string) file_get_contents($migrations[0]);
foreach (['source','source_plan_id','source_schema_version','source_runtime_version','provenance'] as $column) {
    ok3(str_contains($migration, "'{$column}'") || str_contains($migration, '"'.$column.'"'), "Migration missing {$column}.");
}
ok3(str_contains($migration, 'function down()'), 'AI planning provenance migration must be reversible.');

$provider = (string) file_get_contents($root . '/System/TitanForgeServiceProvider.php');
foreach (['ForgeAiPlanningGatewayContract','TitanAICorePlanningGateway','ForgeAiArtifactGatewayContract','UnavailableAiArtifactGateway','SandboxedAiArtifactGenerator'] as $binding) {
    ok3(str_contains($provider, $binding), "Provider missing AI boundary binding: {$binding}");
}

$managerContract = (string) file_get_contents($root . '/System/Contracts/ForgeManagerContract.php');
ok3(str_contains($managerContract, 'planBuildWithAi'), 'Forge manager must expose typed AI planning.');
ok3(str_contains($managerContract, 'generateBuildWithAi'), 'Forge manager must expose sandboxed AI generation boundary.');

$manager = (string) file_get_contents($root . '/System/Services/ForgeManager.php');
foreach (['planning_blocked','planned','generation_blocked','ai_planning_contract_available','ai_artifact_gateway_available'] as $state) {
    ok3(str_contains($manager, $state), "Forge manager missing AI lifecycle state/health field: {$state}");
}
ok3(!preg_match('/OpenAI|Anthropic|Gemini|curl_exec\s*\(|file_get_contents\s*\(\s*[\'\"]https?:/i', $manager), 'Forge manager must not call model providers directly.');

$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$optional = array_column((array)($installer['optional_dependencies'] ?? []), 'slug');
ok3(in_array('titan-ai-core', $optional, true), 'Installer must declare Titan AI Core as optional dependency.');

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
ok3(in_array('ai-enabled', $manifest['architecture']['modifiers'] ?? [], true), 'Forge must declare ai-enabled once AI Core consumption exists.');
$optionalKeys = array_column((array)($manifest['dependencies']['optional'] ?? []), 'key');
ok3(in_array('titan-ai-core', $optionalKeys, true), 'Blueprint sidecar must declare Titan AI Core optional dependency.');
ok3(in_array('forge.ai.plan.consume', $manifest['capabilities'] ?? [], true), 'Manifest must declare AI planning consumer capability.');
ok3(in_array('forge.ai.artifact.sandbox', $manifest['capabilities'] ?? [], true), 'Manifest must declare sandboxed AI artifact capability boundary.');
ok3(($manifest['external_hosts'] ?? null) === [], 'Forge AI integration must not add direct model-provider hosts.');

fwrite(STDOUT, "PASS: AI persistence and provider wiring\n");
