<?php

declare(strict_types=1);
$root=dirname(__DIR__,2);
function need19(string $file,array $needles):void{$t=file_get_contents($file);if(!is_string($t))throw new RuntimeException('Cannot read '.$file);foreach($needles as $n)if(!str_contains($t,$n))throw new RuntimeException(basename($file).' missing: '.$n);}
need19($root.'/System/Rewind/EloquentForgeRewindHistoryReader.php',["where('company_id'","where('trace_id'","cursor()","ForgeBuildPlan::query()","ForgeArtifact::query()","ForgeValidationRun::query()","ForgeReleaseCandidate::query()","ForgeReceipt::query()","withLineage("]);
need19($root.'/System/TitanForgeServiceProvider.php',['ForgeRewindHistoryReaderContract::class','EloquentForgeRewindHistoryReader::class','ForgeRewindProjector::class','ForgeRewindSource::class']);
need19($root.'/System/Rewind/ForgeRewindSource.php',['implements RewindSourceAdapter',"return 'titan-forge.rewind-source'",'authority-neutral']);
$arch=file_get_contents($root.'/tests/Architecture/BoundaryTest.php');
if(!is_string($arch))throw new RuntimeException('Architecture test unreadable.');
need19($root.'/tests/Architecture/BoundaryTest.php',['RewindSourceAdapter','titan-forge.rewind-source']);
echo "rewind-persistence-wiring-pass19: PASS\n";
