<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use FilesystemIterator;

final class BoundaryTest extends TestCase
{
    public function test_forge_has_no_direct_process_execution_or_external_provider_calls(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $source = '';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $source .= (string) file_get_contents($file->getPathname()) . "\n";
            }
        }

        foreach (['shell_' . 'exec(', 'proc_' . 'open(', 'po' . 'pen(', 'curl_' . 'exec(', 'api.openai.com', 'api.anthropic.com'] as $forbidden) {
            self::assertStringNotContainsString($forbidden, $source, 'Forbidden Forge boundary token found: ' . $forbidden);
        }
    }

    public function test_forge_repository_reads_are_tenant_scoped(): void
    {
        $source = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Persistence/EloquentBuildRepository.php');
        self::assertStringContainsString("where('company_id'", $source);
        self::assertStringContainsString("'company_id' => \$context->companyId", $source);
    }

    public function test_rewind_contribution_is_read_only_and_decoupled_from_rewind_internals(): void
    {
        $root = dirname(__DIR__, 2);
        $source = (string) file_get_contents($root . '/System/Rewind/ForgeRewindSource.php');
        $reader = (string) file_get_contents($root . '/System/Rewind/EloquentForgeRewindHistoryReader.php');
        self::assertStringContainsString('RewindSourceAdapter', $source);
        self::assertStringContainsString('titan-forge.rewind-source', $source);
        self::assertStringNotContainsString('App\\Extensions\\TitanRewind', $source . $reader);
        self::assertStringContainsString("where('company_id'", $reader);
        self::assertStringContainsString("where('trace_id'", $reader);
        self::assertStringContainsString('cursor()', $reader);
    }
}
