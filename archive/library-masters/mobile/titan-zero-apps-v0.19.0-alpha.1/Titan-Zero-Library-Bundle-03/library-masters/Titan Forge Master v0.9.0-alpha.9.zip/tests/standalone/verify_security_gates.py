#!/usr/bin/env python3
import importlib.util
import pathlib
import stat
import tempfile
import zipfile

root = pathlib.Path(__file__).resolve().parents[2]
verifier_path = root / 'bin' / 'release_security.py'
if not verifier_path.exists():
    raise SystemExit('missing bin/release_security.py')

spec = importlib.util.spec_from_file_location('release_security', verifier_path)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

with tempfile.TemporaryDirectory() as td:
    td = pathlib.Path(td)

    traversal = td / 'traversal.zip'
    with zipfile.ZipFile(traversal, 'w') as z:
        z.writestr('../escape.php', '<?php')
    assert any('unsafe path' in e for e in mod.inspect_archive(traversal)), 'traversal ZIP was accepted'

    collision = td / 'collision.zip'
    with zipfile.ZipFile(collision, 'w') as z:
        z.writestr('System/Test.php', '<?php')
        z.writestr('system/test.php', '<?php')
    assert any('case collision' in e for e in mod.inspect_archive(collision)), 'case collision ZIP was accepted'

    symlink = td / 'symlink.zip'
    with zipfile.ZipFile(symlink, 'w') as z:
        info = zipfile.ZipInfo('System/link.php')
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        z.writestr(info, '../../outside.php')
    assert any('symlink' in e for e in mod.inspect_archive(symlink)), 'symlink ZIP was accepted'

    secret = td / 'secret.zip'
    token = 'sk-' + 'proj-' + ('A' * 40)
    with zipfile.ZipFile(secret, 'w') as z:
        z.writestr('config/demo.php', 'OPENAI_API_KEY=' + token)
    assert any('secret pattern' in e for e in mod.inspect_archive(secret)), 'secret-bearing ZIP was accepted'

print('Titan Forge security gates PASS')
