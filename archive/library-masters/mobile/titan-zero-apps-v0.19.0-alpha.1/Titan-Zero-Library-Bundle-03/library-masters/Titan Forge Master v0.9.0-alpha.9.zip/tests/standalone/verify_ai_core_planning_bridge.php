<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
require_once __DIR__ . '/fixtures/ai_core_contract_stubs.php';
foreach ([
    'System/Domain/BuildContext.php','System/Domain/BuildRequest.php','System/Domain/BuildSpec.php','System/Domain/BuildStep.php','System/Domain/BuildPlan.php',
    'System/Domain/AiPlanningResult.php','System/Contracts/ForgeAiPlanningGatewayContract.php','System/AI/TitanAICorePlanningGateway.php',
] as $file) { require_once $root . '/' . $file; }

use App\Extensions\TitanForge\System\AI\TitanAICorePlanningGateway;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanAICore\System\DTO\PlanDependency;
use App\Extensions\TitanAICore\System\DTO\PlanEnvelope;
use App\Extensions\TitanAICore\System\DTO\PlanStep;
use App\Extensions\TitanAICore\System\DTO\ValidationIssue;
use App\Extensions\TitanAICore\System\DTO\ValidationReport;

function fail(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok(bool $condition, string $message): void { if (!$condition) fail($message); }

$ctx = new BuildContext(42, 7, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', '44444444-4444-4444-8444-444444444444', 'forge:ai:plan:1', '55555555-5555-4555-8555-555555555555');
$request = new BuildRequest($ctx, 'extension', 'Create a tenant-safe inspection extension.', ['domain'=>'inspection']);

$orchestrator = new class {
    public function createPlan($intent, $runtime): PlanEnvelope {
        return new PlanEnvelope('plan-forge-1', $runtime, $intent, [
            new PlanStep('schema', 'Create schema', 'forge.generate.schema'),
            new PlanStep('service', 'Create service', 'forge.generate.service', [new PlanDependency('schema')], riskCeiling: 'MEDIUM', knowledgeRequirements: ['titan-extension-blueprint-v4.2']),
        ]);
    }
};
$validator = new class { public function validate($plan): ValidationReport { return new ValidationReport(true, false, [], [], [], '0.4.0-test'); } };
$resolver = static fn(string $contract): ?object => str_contains($contract, 'OrchestratorContract') ? $orchestrator : (str_contains($contract, 'PlanValidatorContract') ? $validator : null);
$gateway = new TitanAICorePlanningGateway($resolver);
$result = $gateway->plan($request);
ok($gateway->available(), 'AI Core planning contract should be available when both peer contracts resolve.');
ok($result->usable, 'A valid typed AI Core plan must be usable by Forge even when it is not executable by AI Core.');
ok($result->plan !== null && count($result->plan->steps) === 2, 'AI Core plan must map to a typed Forge BuildPlan.');
ok($result->plan->steps[1]->dependsOn === ['schema'], 'AI Core dependencies must survive mapping.');
ok(($result->provenance['source_plan_id'] ?? null) === 'plan-forge-1', 'AI Core plan ID must be retained as provenance.');
ok(($result->provenance['deployment_authority'] ?? null) === 'none', 'AI planning must never grant deployment authority.');
ok(!array_key_exists('chain_of_thought', $result->toArray()), 'Planning result must not expose chain-of-thought.');

$blockedValidator = new class { public function validate($plan): ValidationReport { return new ValidationReport(false, false, [new ValidationIssue('error','DAG_CYCLE_DETECTED','blocked')]); } };
$blockedResolver = static fn(string $contract): ?object => str_contains($contract, 'OrchestratorContract') ? $orchestrator : (str_contains($contract, 'PlanValidatorContract') ? $blockedValidator : null);
$blocked = (new TitanAICorePlanningGateway($blockedResolver))->plan($request);
ok(!$blocked->usable && $blocked->reasonCode === 'ai_core_plan_not_valid', 'Invalid AI Core validation must block Forge AI planning.');

$emptyOrchestrator = new class { public function createPlan($intent, $runtime): PlanEnvelope { return new PlanEnvelope('plan-empty', $runtime, $intent, []); } };
$emptyResolver = static fn(string $contract): ?object => str_contains($contract, 'OrchestratorContract') ? $emptyOrchestrator : (str_contains($contract, 'PlanValidatorContract') ? $validator : null);
$empty = (new TitanAICorePlanningGateway($emptyResolver))->plan($request);
ok(!$empty->usable && $empty->reasonCode === 'ai_core_plan_empty', 'Empty AI Core plan must fail closed.');

fwrite(STDOUT, "PASS: AI Core planning bridge\n");
