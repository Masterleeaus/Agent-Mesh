<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$errors = [];
$check = static function (bool $condition, string $message) use (&$errors): void {
    if (! $condition) {
        $errors[] = $message;
    }
};

$manifestPath = $root . '/extension.json';
$raw = @file_get_contents($manifestPath);
$check($raw !== false, 'missing extension.json');
$check($raw === false || ! str_starts_with($raw, "\xEF\xBB\xBF"), 'extension.json contains UTF-8 BOM');
$manifest = is_string($raw) ? json_decode($raw, true) : null;
$check(is_array($manifest), 'extension.json is invalid JSON');

if (is_array($manifest)) {
    $expected = [
        'schema' => 'titan-extension-v1',
        'slug' => 'titan-forge',
        'version' => '0.9.0-alpha.9',
        'folder' => 'TitanForge',
        'provider' => 'App\\Extensions\\TitanForge\\System\\TitanForgeServiceProvider',
        'migrations' => true,
    ];
    foreach ($expected as $key => $value) {
        $check(($manifest[$key] ?? null) === $value, "manifest {$key} mismatch");
    }
    $check(array_is_list($manifest['dependencies'] ?? null), 'dependencies must be an array');
    $check(array_is_list($manifest['optional_dependencies'] ?? null), 'optional_dependencies must be an array');
    $check(($manifest['requires']['php'] ?? null) === '>=8.2', 'requires.php mismatch');
    $check(($manifest['requires']['magicai'] ?? null) === '>=10.91', 'requires.magicai mismatch');
    $check(($manifest['requires']['laravel'] ?? null) === '^10.0', 'requires.laravel mismatch');
    $check(! isset($manifest['requires']['titan_platform']), 'requires.titan_platform is not valid in Installer 1.7.8 root manifest');
    foreach (['name','type','description','publishes'] as $legacyKey) { $check(! array_key_exists($legacyKey, $manifest), 'legacy root field remains: ' . $legacyKey); }
    $check(($manifest['uninstall']['preserve_data'] ?? null) === true, 'uninstall.preserve_data mismatch');
}

$providerPath = $root . '/System/TitanForgeServiceProvider.php';
$provider = @file_get_contents($providerPath);
$check(is_string($provider), 'provider file missing');
if (is_string($provider)) {
    $check(str_contains($provider, 'namespace App\\Extensions\\TitanForge\\System;'), 'provider namespace mismatch');
    $check(str_contains($provider, 'final class TitanForgeServiceProvider'), 'provider class mismatch');
    $check(str_contains($provider, "'titan-forge-config'"), 'extension-owned publish tag missing');
    $check(! str_contains($provider, "'extension'"), 'generic extension publish tag remains');
    $check(! str_contains($provider, 'Kernel $kernel'), 'unused HTTP Kernel boot injection remains');
}

$sidecarPath = $root . '/extension.manifest.json';
$sidecar = json_decode((string) @file_get_contents($sidecarPath), true);
$check(is_array($sidecar), 'extension.manifest.json invalid');
if (is_array($sidecar)) {
    $check(($sidecar['schema_version'] ?? null) === '2.2', 'sidecar schema mismatch');
    $check(($sidecar['version'] ?? null) === '0.9.0-alpha.9', 'sidecar version mismatch');
    $check(($sidecar['compatibility']['magicai'] ?? null) === '>=10.91', 'sidecar MagicAI requirement mismatch');
    $check(($sidecar['compatibility']['laravel'] ?? null) === '^10.0', 'sidecar Laravel requirement mismatch');
    $check(($sidecar['queues']['used'] ?? null) === true, 'sidecar queue runtime must be active');
    $check(($sidecar['queues']['queue_names'] ?? null) === ['titan-forge'], 'sidecar queue name mismatch');
    $active = $sidecar['capabilities'] ?? [];
    foreach (['forge.build', 'forge.scaffold', 'forge.validate', 'forge.generate'] as $unimplemented) {
        $check(! in_array($unimplemented, $active, true), "unimplemented capability advertised: {$unimplemented}");
    }
}

$migrations = glob($root . '/database/migrations/*.php') ?: [];
$check($migrations !== [], 'migrations flag true but no migrations found');
foreach ($migrations as $migration) {
    $source = (string) file_get_contents($migration);
    $check(str_contains($source, 'function down('), 'migration missing down(): ' . basename($migration));
}

$forbiddenNames = ['.env', '.DS_Store'];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($iterator as $file) {
    $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
    $parts = explode('/', $relative);
    $check(! in_array($file->getFilename(), $forbiddenNames, true), 'forbidden file: ' . $relative);
    foreach (['.git', '__MACOSX', 'node_modules', 'vendor'] as $forbiddenPart) {
        $check(! in_array($forbiddenPart, $parts, true), 'forbidden path: ' . $relative);
    }
}

if (is_array($manifest)) {
    $integrity = $manifest['integrity']['files'] ?? null;
    $check(is_array($integrity), 'integrity.files missing');
    if (is_array($integrity)) {
        $actual = [];
        foreach ($iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)) as $file) {
            if (! $file->isFile()) {
                continue;
            }
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
            if ($relative === 'extension.json') {
                continue;
            }
            $actual[$relative] = hash_file('sha256', $file->getPathname());
        }
        ksort($actual);
        ksort($integrity);
        $check(array_keys($integrity) === array_keys($actual), 'integrity.files path set mismatch');
        foreach ($actual as $relative => $hash) {
            $check(($integrity[$relative] ?? null) === $hash, 'integrity mismatch: ' . $relative);
        }
    }
}

if ($errors !== []) {
    fwrite(STDERR, "Titan Forge installer contract FAIL\n - " . implode("\n - ", array_values(array_unique($errors))) . "\n");
    exit(1);
}

echo "Titan Forge installer contract PASS\n";
