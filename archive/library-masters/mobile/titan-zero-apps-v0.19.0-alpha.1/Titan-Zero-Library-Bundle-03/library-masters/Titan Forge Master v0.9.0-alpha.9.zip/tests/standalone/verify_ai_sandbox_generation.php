<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
foreach ([
    'System/Domain/BuildContext.php','System/Domain/BuildRequest.php','System/Domain/BuildSpec.php','System/Domain/BuildStep.php','System/Domain/BuildPlan.php','System/Domain/BuildArtifact.php','System/Domain/ArtifactSet.php',
    'System/Domain/AiArtifactProposal.php','System/Contracts/ForgeAiArtifactGatewayContract.php','System/Sandbox/SandboxWorkspace.php','System/Sandbox/SandboxWorkspaceFactory.php','System/AI/SandboxedAiArtifactGenerator.php',
] as $file) { require_once $root . '/' . $file; }

use App\Extensions\TitanForge\System\AI\SandboxedAiArtifactGenerator;
use App\Extensions\TitanForge\System\Contracts\ForgeAiArtifactGatewayContract;
use App\Extensions\TitanForge\System\Domain\AiArtifactProposal;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildPlan;
use App\Extensions\TitanForge\System\Domain\BuildRequest;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\BuildStep;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspaceFactory;

function fail2(string $message): never { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
function ok2(bool $condition, string $message): void { if (!$condition) fail2($message); }

$base = sys_get_temp_dir() . '/titan-forge-ai-test-' . bin2hex(random_bytes(4));
$ctx = new BuildContext(42, 7, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', '44444444-4444-4444-8444-444444444444', 'forge:ai:generate:1', '55555555-5555-4555-8555-555555555555');
$request = new BuildRequest($ctx, 'extension', 'Create a safe extension.', ['domain'=>'inspection']);
$spec = BuildSpec::fromRequest($request);
$plan = new BuildPlan([new BuildStep('provider','forge.generate.provider')]);

$gateway = new class implements ForgeAiArtifactGatewayContract {
    public function available(): bool { return true; }
    public function propose(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): AiArtifactProposal {
        return new AiArtifactProposal(
            true,
            'titan-ai-core',
            'plan-forge-1',
            [
                ['path'=>'System/GeneratedService.php','content'=>"<?php\ndeclare(strict_types=1);\nfinal class GeneratedService {}\n"],
                ['path'=>'resources/generated.json','content'=>'{"ok":true}'],
            ],
            [
                'model_provider'=>'openai-compatible',
                'model_id'=>'governed-model',
                'model_route'=>'titan-ai-core',
                'prompt_sha256'=>str_repeat('a',64),
                'input_sha256'=>str_repeat('b',64),
                'output_sha256'=>str_repeat('c',64),
                'template_version'=>'forge-ai-v1',
                'decision_summary'=>'Generated bounded extension scaffolding.',
            ],
        );
    }
};
$factory = new SandboxWorkspaceFactory($base, 50, 1024 * 1024);
$generator = new SandboxedAiArtifactGenerator($gateway, $factory);
$result = $generator->generate($request, $spec, $plan);
ok2(($result['generation_mode'] ?? null) === 'ai-assisted', 'AI generator must report ai-assisted mode.');
ok2(($result['artifacts'] ?? null)?->count() === 3, 'AI generator must include two files plus generation manifest.');
ok2(is_file($result['workspace'] . '/System/GeneratedService.php'), 'AI artifact must be written inside Forge workspace.');
$manifest = json_decode((string) file_get_contents($result['workspace'] . '/generation_manifest.json'), true, 512, JSON_THROW_ON_ERROR);
ok2(($manifest['deployment_authority'] ?? null) === 'none', 'AI generation manifest must deny deployment authority.');
ok2(($manifest['generation_mode'] ?? null) === 'ai-assisted', 'Generation manifest must identify AI-assisted mode.');
ok2(($manifest['planner']['source_plan_id'] ?? null) === 'plan-forge-1', 'AI source plan ID must be preserved.');
ok2(($manifest['model']['route'] ?? null) === 'titan-ai-core', 'AI model route must be attributed to AI Core.');
ok2(($manifest['context']['root_causation_id'] ?? null) === $ctx->rootCausationId, 'AI generation provenance must preserve root causation.');
ok2(!isset($manifest['chain_of_thought']), 'AI manifest must never persist chain-of-thought.');

$badGateway = new class implements ForgeAiArtifactGatewayContract {
    public function available(): bool { return true; }
    public function propose(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): AiArtifactProposal {
        return new AiArtifactProposal(true, 'titan-ai-core', 'plan-bad', [['path'=>'../escape.php','content'=>'bad']], [
            'model_provider'=>'x','model_id'=>'y','model_route'=>'titan-ai-core','prompt_sha256'=>str_repeat('a',64),'input_sha256'=>str_repeat('b',64),'output_sha256'=>str_repeat('c',64),'template_version'=>'v1'
        ]);
    }
};
$escaped = false;
try { (new SandboxedAiArtifactGenerator($badGateway, $factory))->generate($request, $spec, $plan); } catch (Throwable) { $escaped = true; }
ok2($escaped, 'Unsafe AI artifact paths must be rejected by the Forge sandbox.');

$cotGateway = new class implements ForgeAiArtifactGatewayContract {
    public function available(): bool { return true; }
    public function propose(BuildRequest $request, BuildSpec $spec, BuildPlan $plan): AiArtifactProposal {
        return new AiArtifactProposal(true, 'titan-ai-core', 'plan-cot', [['path'=>'safe.txt','content'=>'safe']], [
            'model_provider'=>'x','model_id'=>'y','model_route'=>'titan-ai-core','prompt_sha256'=>str_repeat('a',64),'input_sha256'=>str_repeat('b',64),'output_sha256'=>str_repeat('c',64),'template_version'=>'v1','chain_of_thought'=>'forbidden'
        ]);
    }
};
$blocked = false;
try { (new SandboxedAiArtifactGenerator($cotGateway, $factory))->generate($request, $spec, $plan); } catch (Throwable) { $blocked = true; }
ok2($blocked, 'Chain-of-thought-shaped provenance must be rejected before persistence.');

$factory->forContext($ctx)->destroy();
@rmdir($base . '/42'); @rmdir($base);
fwrite(STDOUT, "PASS: sandboxed AI artifact generation\n");
