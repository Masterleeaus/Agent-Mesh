#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import stat
import tempfile
import zipfile

root = Path(__file__).resolve().parents[2]
module_path = root / 'bin' / 'verify-release-zip.py'
spec = importlib.util.spec_from_file_location('forge_verifier', module_path)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)

source = module_path.read_text()
assert "'version':'0.9.0-alpha.2'" in source, 'Bundled verifier must target the current cumulative release.'
assert "requires.get('laravel')" in source, 'Bundled verifier must enforce canonical Laravel compatibility.'
assert "requires.titan_platform mismatch" not in source, 'Bundled verifier must not require obsolete titan_platform metadata.'
assert "publishes mismatch" not in source, 'Bundled verifier must not require obsolete publishes metadata.'
assert "'name':'Titan Forge'" not in source, 'Installer 1.7.8 root manifest must not require legacy name metadata.'


def build_zip(path: Path, entries: dict[str, bytes], symlink: str | None = None):
    with zipfile.ZipFile(path, 'w') as archive:
        for name, data in entries.items(): archive.writestr(name, data)
        if symlink:
            info = zipfile.ZipInfo(symlink); info.create_system = 3; info.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(info, b'target')

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    secret = b'sk_' + b'live_' + (b'1' * 24)
    cases = {
        'traversal.zip': ({'../escape.php': b'<?php'}, 'unsafe path'),
        'secret.zip': ({'secret.txt': secret}, 'secret'),
        'collision.zip': ({'A.php': b'<?php', 'a.php': b'<?php'}, 'case collision'),
    }
    for filename, (entries, needle) in cases.items():
        path = tmp / filename; build_zip(path, entries)
        errors = module.inspect_archive_security(path)
        assert any(needle.lower() in error.lower() for error in errors), (filename, errors)
    path = tmp / 'symlink.zip'; build_zip(path, {}, symlink='linked.php')
    assert any('symlink' in error.lower() for error in module.inspect_archive_security(path))

print('Release verifier adversarial tests PASS')
