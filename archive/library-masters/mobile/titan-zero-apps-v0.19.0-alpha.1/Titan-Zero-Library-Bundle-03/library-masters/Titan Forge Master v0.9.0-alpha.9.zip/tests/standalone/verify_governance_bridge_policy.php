<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);

$required = [
    'System/Contracts/ForgeCouncilGatewayContract.php',
    'System/Contracts/ForgeGovernanceGatewayContract.php',
    'System/Contracts/ForgeCommandBusGatewayContract.php',
    'System/Contracts/ForgeSignalGatewayContract.php',
    'System/Contracts/ReleaseRepositoryContract.php',
    'System/Domain/CouncilReview.php',
    'System/Domain/ReleaseGateResult.php',
    'System/Governance/ReleaseGovernanceService.php',
];
foreach ($required as $relative) {
    if (! is_file($root . '/' . $relative)) {
        throw new RuntimeException('Missing governance bridge file: ' . $relative);
    }
}

foreach ([
    'System/Domain/BuildContext.php',
    'System/Domain/BuildRequest.php',
    'System/Domain/BuildSpec.php',
    'System/Domain/BuildArtifact.php',
    'System/Domain/ArtifactSet.php',
    'System/Domain/ValidationFinding.php',
    'System/Domain/ValidationResult.php',
    'System/Domain/RiskDeclaration.php',
    'System/Domain/CouncilReview.php',
    'System/Domain/ReleaseGateResult.php',
    'System/Contracts/ForgeRiskGatewayContract.php',
    'System/Contracts/ForgeShieldGatewayContract.php',
    'System/Contracts/ForgeCouncilGatewayContract.php',
    'System/Contracts/ForgeGovernanceGatewayContract.php',
    'System/Contracts/ForgeCommandBusGatewayContract.php',
    'System/Governance/ReleaseGovernanceService.php',
] as $relative) {
    require_once $root . '/' . $relative;
}

use App\Extensions\TitanForge\System\Contracts\ForgeCommandBusGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeCouncilGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeGovernanceGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeRiskGatewayContract;
use App\Extensions\TitanForge\System\Contracts\ForgeShieldGatewayContract;
use App\Extensions\TitanForge\System\Domain\ArtifactSet;
use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Domain\CouncilReview;
use App\Extensions\TitanForge\System\Domain\RiskDeclaration;
use App\Extensions\TitanForge\System\Domain\ValidationFinding;
use App\Extensions\TitanForge\System\Domain\ValidationResult;
use App\Extensions\TitanForge\System\Governance\ReleaseGovernanceService;

function bridge_assert(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

final class FakeRisk implements ForgeRiskGatewayContract
{
    public function __construct(private readonly RiskDeclaration $declaration, private readonly bool $isAvailable = true) {}
    public function available(): bool { return $this->isAvailable; }
    public function assess(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): RiskDeclaration { return $this->declaration; }
}

final class FakeShield implements ForgeShieldGatewayContract
{
    public function __construct(private readonly ValidationResult $result, private readonly bool $isAvailable = true) {}
    public function available(): bool { return $this->isAvailable; }
    public function inspect(BuildSpec $spec, ArtifactSet $artifacts, ValidationResult $localValidation): ValidationResult { return $this->result; }
}

final class FakeCouncil implements ForgeCouncilGatewayContract
{
    public int $calls = 0;
    public function __construct(private readonly bool $isAvailable = true) {}
    public function available(): bool { return $this->isAvailable; }
    public function governedDeliberationAvailable(): bool { return $this->isAvailable; }
    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        return $this->isAvailable
            ? new CouncilReview(true, true, 'activation_assessed', 'titan-model-council', ['governed_deliberation' => true])
            : CouncilReview::unavailable();
    }
    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        $this->calls++;
        return $this->isAvailable
            ? new CouncilReview(true, true, 'deliberated', 'titan-model-council', ['decision_id' => 99, 'execution_authority' => 'advisory_only'])
            : CouncilReview::unavailable();
    }
}

final class FakeGovernance implements ForgeGovernanceGatewayContract
{
    public function __construct(private readonly bool $isAvailable) {}
    public function available(): bool { return $this->isAvailable; }
    public function unavailableReason(): ?string { return $this->isAvailable ? null : 'health_only_contract'; }
}

final class FakeCommandBus implements ForgeCommandBusGatewayContract
{
    public function __construct(private readonly bool $isAvailable) {}
    public function available(): bool { return $this->isAvailable; }
    public function unavailableReason(): ?string { return $this->isAvailable ? null : 'health_only_contract'; }
}

$context = new BuildContext(
    42,
    7,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    '44444444-4444-4444-8444-444444444444',
    'forge:governance:test',
);
$spec = BuildSpec::workforceTeam($context, 'solo', ['titan.operations_manager']);
$artifacts = new ArtifactSet([]);
$pass = ValidationResult::pass();

$council = new FakeCouncil(true);
$service = new ReleaseGovernanceService(
    new FakeRisk(new RiskDeclaration('low', false, 'titan-risk', ['baseline'], ['execution_directive' => 'EXECUTE'])),
    new FakeShield($pass),
    $council,
    new FakeGovernance(false),
    new FakeCommandBus(false),
);
$low = $service->evaluate($spec, $artifacts, $pass);
bridge_assert($low->candidateStatus === 'approval_required', 'Missing Governance decision API must hold a candidate for approval.');
bridge_assert($low->blocked, 'Unavailable Governance must fail closed for release progression.');
bridge_assert($council->calls === 0, 'Low-risk build must not invoke Model Council.');
bridge_assert(in_array('governance.health_only_contract', $low->reasons, true), 'Governance health-only reason missing.');

$highCouncil = new FakeCouncil(true);
$highService = new ReleaseGovernanceService(
    new FakeRisk(new RiskDeclaration('high', true, 'titan-risk', ['approval required'], ['execution_directive' => 'HOLD_FOR_APPROVAL'])),
    new FakeShield($pass),
    $highCouncil,
    new FakeGovernance(false),
    new FakeCommandBus(false),
);
$high = $highService->evaluate($spec, $artifacts, $pass);
bridge_assert($highCouncil->calls === 1, 'High-risk candidate must request governed Model Council deliberation.');
bridge_assert($high->council->required, 'High-risk candidate must mark Council as required.');
bridge_assert($high->candidateStatus === 'approval_required', 'High-risk hold must require approval rather than auto-release.');

$denyService = new ReleaseGovernanceService(
    new FakeRisk(new RiskDeclaration('critical', true, 'titan-risk', ['blocked'], ['execution_directive' => 'DENY'])),
    new FakeShield($pass),
    new FakeCouncil(true),
    new FakeGovernance(true),
    new FakeCommandBus(true),
);
$deny = $denyService->evaluate($spec, $artifacts, $pass);
bridge_assert($deny->candidateStatus === 'rejected', 'Risk DENY must reject the release candidate.');
bridge_assert(in_array('risk.denied', $deny->reasons, true), 'Risk denial reason missing.');

$shieldFail = new ValidationResult([
    new ValidationFinding('critical', 'shield.test', 'critical finding', blocking: true),
]);
$shieldService = new ReleaseGovernanceService(
    new FakeRisk(new RiskDeclaration('low', false, 'titan-risk', [], ['execution_directive' => 'EXECUTE'])),
    new FakeShield($shieldFail),
    new FakeCouncil(true),
    new FakeGovernance(true),
    new FakeCommandBus(true),
);
$shield = $shieldService->evaluate($spec, $artifacts, $pass);
bridge_assert($shield->candidateStatus === 'rejected', 'Blocking Shield finding must reject the candidate.');
bridge_assert(in_array('shield.blocked', $shield->reasons, true), 'Shield rejection reason missing.');

$missingRisk = new ReleaseGovernanceService(
    new FakeRisk(RiskDeclaration::unavailable(), false),
    new FakeShield($pass),
    new FakeCouncil(false),
    new FakeGovernance(false),
    new FakeCommandBus(false),
);
$missing = $missingRisk->evaluate($spec, $artifacts, $pass);
bridge_assert($missing->candidateStatus === 'approval_required', 'Unavailable Risk must hold rather than fabricate a release decision.');
bridge_assert($missing->blocked, 'Unavailable Risk must block release progression.');
bridge_assert(in_array('risk.unavailable', $missing->reasons, true), 'Risk unavailable reason missing.');


$activationOnlyCouncil = new class implements ForgeCouncilGatewayContract {
    public function available(): bool { return true; }
    public function governedDeliberationAvailable(): bool { return false; }
    public function assess(BuildSpec $spec, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        return new CouncilReview(true, true, 'activation_assessed', 'titan-model-council', ['governed_deliberation' => false]);
    }
    public function deliberate(BuildSpec $spec, ArtifactSet $artifacts, RiskDeclaration $risk, ValidationResult $shieldValidation): CouncilReview
    {
        return CouncilReview::unavailable('governed_deliberation_contract_unavailable');
    }
};
$activationOnlyService = new ReleaseGovernanceService(
    new FakeRisk(new RiskDeclaration('high', false, 'titan-risk', [], ['execution_directive' => 'EXECUTE_MONITORED'])),
    new FakeShield($pass),
    $activationOnlyCouncil,
    new FakeGovernance(true),
    new FakeCommandBus(true),
);
$activationOnly = $activationOnlyService->evaluate($spec, $artifacts, $pass);
bridge_assert($activationOnly->candidateStatus === 'approval_required', 'Council activation assessment alone must not clear a high-risk release.');
bridge_assert(in_array('council.unavailable', $activationOnly->reasons, true), 'Council governed-deliberation unavailable reason missing.');

echo "governance-bridge-policy: PASS\n";
