<?php

declare(strict_types=1);

namespace App\Support\Extensions {
    interface RewindSourceAdapter {
        public function sourceKey(): string;
        public function watermark(int $companyId, string $traceId): array;
        public function records(int $companyId, string $traceId, ?string $asOf = null): iterable;
    }
}

namespace {
$root=dirname(__DIR__,2);
foreach ([
    'System/Rewind/ForgeRewindHistoryReaderContract.php',
    'System/Rewind/ForgeRewindProjector.php',
    'System/Rewind/ForgeRewindSource.php',
    'System/Rewind/ForgeReconstructionService.php',
] as $file) {
    if (!is_file($root.'/'.$file)) { throw new RuntimeException('Missing Pass 19 file: '.$file); }
    require_once $root.'/'.$file;
}

use App\Extensions\TitanForge\System\Rewind\ForgeReconstructionService;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindHistoryReaderContract;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindProjector;
use App\Extensions\TitanForge\System\Rewind\ForgeRewindSource;

function p19_assert(bool $c,string $m):void{if(!$c)throw new RuntimeException($m);}

$trace='11111111-1111-4111-8111-111111111111';
$reader=new class implements ForgeRewindHistoryReaderContract {
    public function facts(int $companyId,string $traceId): iterable {
        yield ['kind'=>'build','record_id'=>'build:7','occurred_at'=>'2026-08-19T10:00:00+00:00','recorded_at'=>'2026-08-19T10:00:01+00:00','data'=>[
            'build_id'=>7,'status'=>'validated','target_type'=>'extension','spec_fingerprint'=>str_repeat('a',64),'actor_id'=>9,
            'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555'
        ]];
        yield ['kind'=>'plan','record_id'=>'plan:3','occurred_at'=>'2026-08-19T10:01:00+00:00','recorded_at'=>'2026-08-19T10:01:00+00:00','data'=>[
            'build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'fingerprint'=>str_repeat('b',64),'source'=>'titan-ai-core','source_plan_id'=>'plan-1','source_runtime_version'=>'0.3.0'
        ]];
        yield ['kind'=>'artifact','record_id'=>'artifact:4','occurred_at'=>'2026-08-19T10:02:00+00:00','recorded_at'=>'2026-08-19T10:02:00+00:00','data'=>[
            'build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'path'=>'System/Generated.php','sha256'=>str_repeat('c',64),'type'=>'php','size_bytes'=>123,
            'generation_mode'=>'ai-assisted','model_provider'=>'provider','model_name'=>'model','model_route'=>'route','prompt_sha256'=>str_repeat('d',64),'output_sha256'=>str_repeat('e',64)
        ]];
        yield ['kind'=>'validation','record_id'=>'validation:5','occurred_at'=>'2026-08-19T10:03:00+00:00','recorded_at'=>'2026-08-19T10:03:01+00:00','data'=>[
            'build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'status'=>'passed','fingerprint'=>str_repeat('f',64),'finding_count'=>1,'blocking_count'=>0,'validator_count'=>7
        ]];
        yield ['kind'=>'shield','record_id'=>'candidate:6:shield','occurred_at'=>'2026-08-19T10:04:00+00:00','recorded_at'=>'2026-08-19T10:04:00+00:00','data'=>['build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'candidate_id'=>6,'valid'=>true,'finding_count'=>0]];
        yield ['kind'=>'risk','record_id'=>'candidate:6:risk','occurred_at'=>'2026-08-19T10:04:00+00:00','recorded_at'=>'2026-08-19T10:04:00+00:00','data'=>['build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'candidate_id'=>6,'level'=>'high','blocked'=>false,'provider'=>'titan-risk','execution_directive'=>'EXECUTE_MONITORED']];
        yield ['kind'=>'council','record_id'=>'candidate:6:council','occurred_at'=>'2026-08-19T10:04:00+00:00','recorded_at'=>'2026-08-19T10:04:00+00:00','data'=>['build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'candidate_id'=>6,'status'=>'deliberated','decision_id'=>77,'confidence_percent'=>88,'execution_authority'=>'advisory_only','receipt_hash'=>str_repeat('1',64)]];
        yield ['kind'=>'governance','record_id'=>'candidate:6:governance','occurred_at'=>'2026-08-19T10:04:00+00:00','recorded_at'=>'2026-08-19T10:04:00+00:00','data'=>['build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'candidate_id'=>6,'available'=>false,'reason'=>'health_only_contract']];
        yield ['kind'=>'release_candidate','record_id'=>'candidate:6','occurred_at'=>'2026-08-19T10:04:00+00:00','recorded_at'=>'2026-08-19T10:04:00+00:00','data'=>['build_id'=>7,'correlation_id'=>'22222222-2222-4222-8222-222222222222','causation_id'=>'33333333-3333-4333-8333-333333333333','root_causation_id'=>'44444444-4444-4444-8444-444444444444','operation_id'=>'55555555-5555-4555-8555-555555555555','actor_id'=>9,'candidate_id'=>6,'status'=>'approval_required','artifact_set_hash'=>str_repeat('2',64),'validation_fingerprint'=>str_repeat('f',64),'gate_fingerprint'=>str_repeat('3',64),'deployment_authority'=>'none']];
    }
};
$projector=new ForgeRewindProjector();
$source=new ForgeRewindSource($reader,$projector);
p19_assert($source->sourceKey()==='titan-forge.rewind-source','Wrong source key.');
$records=iterator_to_array($source->records(42,$trace),false);
p19_assert(count($records)===9,'Expected all Forge reconstruction phases.');
$seq=array_column($records,'sequence'); $sorted=$seq; sort($sorted,SORT_NUMERIC); p19_assert($seq===$sorted,'Events must be deterministic sequence ordered.');
$required=['schema_version','company_id','event_id','trace_id','source_engine','source_record_id','event_type','sequence','occurred_at','recorded_at','integrity_hash'];
foreach($records as $i=>$event){foreach($required as $key)p19_assert(array_key_exists($key,$event),'Missing event key '.$key);p19_assert(preg_match('/^[a-f0-9]{64}$/',$event['integrity_hash'])===1,'Invalid integrity hash.');if($i>0)p19_assert($event['previous_hash']===$records[$i-1]['integrity_hash'],'Integrity chain mismatch.');}
$encoded=json_encode($records,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);
p19_assert(!str_contains($encoded,'instruction'),'Rewind export must not contain raw build instruction.');
p19_assert(!str_contains($encoded,'content'),'Rewind export must not contain artifact content.');
p19_assert(!str_contains($encoded,'chain_of_thought'),'Private reasoning must never be exported.');
p19_assert(($records[1]['correlation_id'] ?? null)==='22222222-2222-4222-8222-222222222222','Child evidence must inherit build correlation lineage.');
p19_assert(str_contains($encoded,'forge.plan.persisted') && str_contains($encoded,'forge.artifact.generated') && str_contains($encoded,'forge.validation.completed'),'Core Forge phases missing.');
p19_assert(str_contains($encoded,'forge.shield.governance_response') && str_contains($encoded,'forge.risk.assessed') && str_contains($encoded,'forge.council.deliberated') && str_contains($encoded,'forge.governance.gate') && str_contains($encoded,'forge.release.candidate'),'Governance phases missing.');

$projectorSource=file_get_contents($root.'/System/Rewind/ForgeRewindProjector.php');
$rewindSourceCode=file_get_contents($root.'/System/Rewind/ForgeRewindSource.php');
p19_assert(!str_contains($projectorSource,'usort('),'Pass 19 projection must stream in deterministic reader order, not materialize and sort the full trace.');
p19_assert(!str_contains($projectorSource,'$prepared = []'),'Pass 19 projector must not buffer the full trace.');
p19_assert(!str_contains($rewindSourceCode,'iterator_to_array($this->records'),'Pass 19 watermark must aggregate records as a stream.');
$largeFactReader=new class implements ForgeRewindHistoryReaderContract {
    public function facts(int $companyId,string $traceId): iterable {
        yield ['kind'=>'build','record_id'=>'build:1000001','occurred_at'=>'2026-08-19T10:00:00+00:00','recorded_at'=>'2026-08-19T10:00:00+00:00','data'=>['build_id'=>1000001]];
        yield ['kind'=>'plan','record_id'=>'plan:1000002','occurred_at'=>'2026-08-19T10:01:00+00:00','recorded_at'=>'2026-08-19T10:01:00+00:00','data'=>['build_id'=>1000001,'fingerprint'=>str_repeat('a',64)]];
    }
};
$largeRecords=iterator_to_array((new ForgeRewindSource($largeFactReader,$projector))->records(42,$trace),false);
p19_assert($largeRecords[0]['sequence'] < $largeRecords[1]['sequence'],'Large record IDs must not collide across Rewind evidence phases.');
p19_assert($largeRecords[0]['sequence'] > 1000000000000,'Sequence spacing must preserve large record IDs without the legacy one-million cap.');
$watermark=$source->watermark(42,$trace);
p19_assert($watermark['schema_version']==='1.0' && $watermark['state']==='COMPLETE','Watermark must report complete bounded source read.');
p19_assert($watermark['received_event_count']===9,'Watermark event count mismatch.');
p19_assert(preg_match('/^[a-f0-9]{64}$/',$watermark['source_hash'])===1,'Watermark source hash required.');
try{iterator_to_array($source->records(42,$trace,'2026-08-19T10:02:00+00:00'),false);throw new RuntimeException('As-of must fail closed.');}catch(LogicException $e){p19_assert(str_contains($e->getMessage(),'as-of'),'Wrong as-of failure.');}
$recon=(new ForgeReconstructionService($source,$projector))->reconstruct(42,$trace);
p19_assert($recon['status']==='COMPLETE' && $recon['completeness']==='COMPLETE','Reconstruction completeness mismatch.');
p19_assert($recon['reproducibility']==='PARTIALLY_REPRODUCIBLE','Without immutable as-of support reconstruction must be partial reproducibility.');
p19_assert($recon['integrity_state']==='VERIFIED','Reconstruction integrity should verify.');
p19_assert(count($recon['timeline'])===9,'Reconstruction timeline mismatch.');
$tamperedSource=new class($records) implements \App\Support\Extensions\RewindSourceAdapter {
    public function __construct(private array $records) {}
    public function sourceKey(): string { return 'tampered'; }
    public function watermark(int $companyId,string $traceId): array { return ['state'=>'COMPLETE']; }
    public function records(int $companyId,string $traceId,?string $asOf=null): iterable { $copy=$this->records; $copy[0]['integrity_hash']=str_repeat('0',64); foreach($copy as $r) yield $r; }
};
$tampered=(new ForgeReconstructionService($tamperedSource,$projector))->reconstruct(42,$trace);
p19_assert($tampered['integrity_state']==='FAILED' && $tampered['status']==='PARTIAL','Reconstruction must recompute and reject tampered event integrity.');

echo "rewind-source-projection-pass19: PASS\n";
}
