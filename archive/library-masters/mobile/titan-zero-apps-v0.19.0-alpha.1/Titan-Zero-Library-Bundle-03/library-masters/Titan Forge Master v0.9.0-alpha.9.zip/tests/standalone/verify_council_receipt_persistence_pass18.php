<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);

function p18_receipt_need(string $file, array $needles): void
{
    $text = file_get_contents($file);
    if (! is_string($text)) throw new RuntimeException('Cannot read ' . $file);
    foreach ($needles as $needle) {
        if (! str_contains($text, $needle)) throw new RuntimeException(basename($file) . ' missing: ' . $needle);
    }
}

p18_receipt_need($root . '/System/Persistence/EloquentReleaseRepository.php', [
    'ForgeReceipt',
    "'receipt_type' => 'council.deliberation'",
    '\'receipt_hash\' => $gate->council->fingerprint()',
    '\'council_review\' => $gate->council->toArray()',
    "'council_review_receipt_id'",
    "'deployment_authority' => 'none'",
]);

p18_receipt_need($root . '/System/Domain/CouncilReview.php', [
    'public function fingerprint(): string',
    "'deliberated'",
    "'configuration_required'",
    'public function satisfied(): bool',
]);

$repo = (string) file_get_contents($root . '/System/Persistence/EloquentReleaseRepository.php');
if (str_contains($repo, "'response_text'")) throw new RuntimeException('Forge receipt persistence must not persist Council participant response_text.');
if (str_contains($repo, "'final_answer'")) throw new RuntimeException('Forge receipt persistence must not persist raw Council final_answer.');

print "council-receipt-persistence-pass18: PASS\n";
