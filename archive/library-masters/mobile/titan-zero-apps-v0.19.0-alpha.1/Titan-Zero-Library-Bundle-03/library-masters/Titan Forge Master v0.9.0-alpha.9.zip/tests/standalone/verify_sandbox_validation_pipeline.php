<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$requires = [
    'System/Domain/BuildContext.php',
    'System/Domain/BuildSpec.php',
    'System/Domain/BuildArtifact.php',
    'System/Domain/ArtifactSet.php',
    'System/Domain/ValidationFinding.php',
    'System/Domain/ValidationResult.php',
    'System/Sandbox/SandboxWorkspace.php',
    'System/Validation/ArtifactValidatorContract.php',
    'System/Validation/ValidatorRegistry.php',
    'System/Validation/ArtifactValidationPipeline.php',
    'System/Validation/Validators/ArtifactPolicyValidator.php',
    'System/Validation/Validators/WorkspaceIntegrityValidator.php',
    'System/Validation/Validators/GeneratedContentSecretValidator.php',
    'System/Validation/Validators/GenerationManifestValidator.php',
    'System/Validation/Validators/GeneratedCodeSafetyValidator.php',
    'System/Validation/Validators/JsonSyntaxValidator.php',
    'System/Validation/Validators/PhpSyntaxValidator.php',
];
foreach ($requires as $file) { require_once $root . '/' . $file; }

use App\Extensions\TitanForge\System\Domain\BuildContext;
use App\Extensions\TitanForge\System\Domain\BuildSpec;
use App\Extensions\TitanForge\System\Sandbox\SandboxWorkspace;
use App\Extensions\TitanForge\System\Validation\ArtifactValidationPipeline;
use App\Extensions\TitanForge\System\Validation\ValidatorRegistry;
use App\Extensions\TitanForge\System\Validation\Validators\ArtifactPolicyValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GeneratedCodeSafetyValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GeneratedContentSecretValidator;
use App\Extensions\TitanForge\System\Validation\Validators\JsonSyntaxValidator;
use App\Extensions\TitanForge\System\Validation\Validators\PhpSyntaxValidator;
use App\Extensions\TitanForge\System\Validation\Validators\GenerationManifestValidator;
use App\Extensions\TitanForge\System\Validation\Validators\WorkspaceIntegrityValidator;

function check(bool $condition, string $message): void { if (! $condition) { throw new RuntimeException($message); } }
function expectException(callable $fn, string $contains): void {
    try { $fn(); } catch (Throwable $e) { check(str_contains($e->getMessage(), $contains), "Unexpected exception: {$e->getMessage()}"); return; }
    throw new RuntimeException('Expected exception containing: ' . $contains);
}

$tmp = sys_get_temp_dir() . '/titan-forge-sandbox-' . bin2hex(random_bytes(6));
$workspace = new SandboxWorkspace($tmp, 44, '11111111-1111-4111-8111-111111111111', 20, 200000);
$workspace->reset();
check(is_dir($workspace->rootPath()), 'Sandbox root should exist after reset.');
expectException(fn () => $workspace->write('../escape.txt', 'bad'), 'unsafe');
expectException(fn () => $workspace->write('/absolute.txt', 'bad'), 'unsafe');
$workspace->write('roles/SafeRole.php', "<?php\nreturn ['ok' => true];\n");
$workspace->write('roles/titan-safe.json', "{\"role_id\":\"titan.safe\"}\n");

$context = new BuildContext(
    44,
    7,
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    '44444444-4444-4444-8444-444444444444',
    '11111111-1111-4111-8111-111111111111',
    'sandbox-validation-test',
    'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
);
$spec = BuildSpec::workforceTeam($context, 'solo', ['titan.safe'], ['authority' => 'titan-ai-workforce']);

$preManifest = $workspace->snapshot();
$listed = array_map(static fn ($a): array => $a->toArray(), $preManifest->artifacts);
$manifest = [
    'schema_version' => '1.0',
    'generator' => 'test-generator',
    'build_type' => 'workforce_team',
    'tier' => 'solo',
    'company_id' => 44,
    'actor_id' => 7,
    'trace_id' => $context->traceId,
    'correlation_id' => $context->correlationId,
    'causation_id' => $context->causationId,
    'root_causation_id' => $context->rootCausationId,
    'operation_id' => $context->operationId,
    'idempotency_key' => $context->idempotencyKey,
    'role_ids' => ['titan.safe'],
    'files' => $listed,
    'deployment_authority' => 'none',
];
$manifest['manifest_sha256'] = hash('sha256', json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
$workspace->write('generation_manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
$artifacts = $workspace->snapshot();
check($artifacts->count() === 3, 'Snapshot should contain three generated artifacts.');

$registry = new ValidatorRegistry([
    new ArtifactPolicyValidator(20, 200000),
    new WorkspaceIntegrityValidator(),
    new GeneratedContentSecretValidator(),
    new GenerationManifestValidator(),
    new GeneratedCodeSafetyValidator(),
    new JsonSyntaxValidator(),
    new PhpSyntaxValidator(),
]);
check($registry->ids() === ['artifact-policy', 'workspace-integrity', 'generated-secret-scan', 'generation-manifest', 'generated-code-safety', 'json-syntax', 'php-syntax'], 'Validator order should be deterministic.');
$pipeline = new ArtifactValidationPipeline($registry);
$result = $pipeline->validate($spec, $workspace, $artifacts);
check($result->passed(), 'Clean sandbox artifacts should pass the validation pipeline: ' . json_encode($result->toArray()));

$badRoot = $manifest;
$badRoot['root_causation_id'] = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
unset($badRoot['manifest_sha256']);
$badRoot['manifest_sha256'] = hash('sha256', json_encode($badRoot, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
$workspace->write('generation_manifest.json', json_encode($badRoot, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");
$badRootArtifacts = $workspace->snapshot();
$badRootResult = $pipeline->validate($spec, $workspace, $badRootArtifacts);
$badRootRules = array_map(static fn ($f): string => $f->rule, $badRootResult->findings);
check(in_array('manifest.root_causation', $badRootRules, true), 'Mismatched root causation must be blocked by generation-manifest validation.');
$workspace->write('generation_manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n");

$fakeSecret = 'sk-' . 'proj-' . 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
$workspace->write('roles/Leak.php', "<?php\n\$key='" . $fakeSecret . "';\n");
$leaky = $workspace->snapshot();
$leakResult = $pipeline->validate($spec, $workspace, $leaky);
check(! $leakResult->passed(), 'Secret-bearing generated content must fail validation.');
check(count(array_filter($leakResult->findings, static fn ($f): bool => $f->rule === 'generated.secret_pattern')) >= 1, 'Secret scan finding should be present.');

$workspace->reset();
$workspace->write('Unsafe.php', "<?php\neval(\$payload);\n");
$unsafeArtifacts = $workspace->snapshot();
$unsafeResult = $pipeline->validate($spec, $workspace, $unsafeArtifacts);
check(! $unsafeResult->passed(), 'Unsafe generated code primitive must fail validation.');
check(count(array_filter($unsafeResult->findings, static fn ($f): bool => $f->rule === 'generated.unsafe_primitive')) >= 1, 'Unsafe primitive finding should be present.');


$workspace->reset();
$workspace->write('broken.json', "{invalid\n");
$brokenJson=$pipeline->validate($spec,$workspace,$workspace->snapshot());
check(! $brokenJson->passed(), 'Invalid generated JSON must fail validation.');
check(count(array_filter($brokenJson->findings, static fn ($f): bool => $f->rule === 'json.syntax')) >= 1, 'JSON syntax finding should be present.');

$workspace->reset();
$workspace->write('Broken.php', "<?php\nfunction broken( {\n");
$brokenPhp=$pipeline->validate($spec,$workspace,$workspace->snapshot());
check(! $brokenPhp->passed(), 'Invalid generated PHP must fail validation.');
check(count(array_filter($brokenPhp->findings, static fn ($f): bool => $f->rule === 'php.syntax')) >= 1, 'PHP syntax finding should be present.');

$workspace->reset();
$workspace->write('A.txt', 'one');
if (function_exists('symlink')) {
    @symlink($workspace->path('A.txt'), $workspace->path('alias.txt'));
    if (is_link($workspace->path('alias.txt'))) {
        expectException(fn () => $workspace->snapshot(), 'symlink');
    }
}

$workspace->reset();
$workspace->write('Case.txt', 'one');
$workspace->write('case.txt', 'two');
expectException(fn () => $workspace->snapshot(), 'case-insensitive');

$workspace->destroy();
check(! is_dir($workspace->rootPath()), 'Sandbox destroy should remove the workspace.');

echo "sandbox-validation-pipeline: PASS\n";
