<?php
use App\Extensions\TitanForge\System\Http\Controllers\AdminBuildHistoryController;
use App\Extensions\TitanForge\System\Http\Controllers\AdminController;
use Illuminate\Routing\Router;
/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
$router->get('/history', AdminBuildHistoryController::class)->name('history');
