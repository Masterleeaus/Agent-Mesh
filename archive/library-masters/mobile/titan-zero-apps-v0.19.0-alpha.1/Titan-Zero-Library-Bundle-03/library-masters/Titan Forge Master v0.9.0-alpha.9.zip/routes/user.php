<?php
use App\Extensions\TitanForge\System\Http\Controllers\BuildHistoryController;
use App\Extensions\TitanForge\System\Http\Controllers\IndexController;
use Illuminate\Routing\Router;
/** @var Router $router */
$router->get('/', IndexController::class)->name('index');
$router->get('/history', BuildHistoryController::class)->name('history');
