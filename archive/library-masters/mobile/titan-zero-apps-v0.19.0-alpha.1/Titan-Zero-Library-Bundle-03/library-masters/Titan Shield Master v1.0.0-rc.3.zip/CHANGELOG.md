# Changelog

## 1.0.0-rc.2

- Deep-scan remediation hotfix.
- Required evidence requirements now fail closed as INCONCLUSIVE when minimum counts are not met.
- HIGH/CRITICAL Assurance requests now receive exact definition evidence requirements, Knowledge Authority references, vertical and jurisdiction context.
- Reinspection, Assurance clearance, Knowledge binding and remediation intent persistence reject immutable identity conflicts instead of silently ignoring divergent retries.
- Capability metadata now advertises `assurance_evidence` only on reinspection, where it is actually accepted.
- Host PHPUnit release assertions advanced from stale v0.5.0 expectations.
- Evidence capture can persist immutable evidence manifests through the Shield runtime store.
- Definition registry can persist immutable definitions when a trusted execution context is supplied.
- Added root-causation lineage migration for durable inspection definitions.

## 1.0.0-rc.1
- Final production-convergence pass: MagicAI host-compatible Blade layout, finding access/customer redaction policy, vertical-pack certification, expanded non-destructive host certification, peer failure-matrix regression, and upgrade/uninstall release gates.
- No direct business mutation, bulk reinspection, or safety-critical AI-only closure authority introduced.

## 0.8.0

- Added fail-closed Knowledge Authority binding preflight.
- Added exact authority version/hash pins, jurisdiction and vertical applicability.
- Added durable `titan_shield_knowledge_bindings` receipts with full causal lineage.
- Added explicit PINNED vs LIVE authority modes; no internal Knowledge Authority APIs are consumed.
- Required unresolved authority now yields INCONCLUSIVE before rule conclusions.

## 0.7.0
- Added independent normalized Assurance clearance for HIGH/CRITICAL closure.
- Added exact evidence ID+SHA-256 binding, policy/subject/tenant validation, and ALLOW/HOLD/DENY normalization.
- Added durable `titan_shield_assurance_clearances` persistence and Assurance clearance receipts.

## 0.6.0
- Added single-finding reinspection requests pinned to the original inspection definition key/version/hash.
- Added durable reinspection records and append-only finding lifecycle transitions.
- Added row-locked finding closure transitions and immutable closure linkage.
- Added deterministic closure policy: exact PASS closes INFO/LOW/MEDIUM; HIGH/CRITICAL remain held pending independent Assurance clearance.
- Added `shield.reinspection.evaluate` capability and versioned reinspection/closure Signal schemas.
- Kept remediation execution outside Shield while the verified Command Bus peer remains health-only.

## 0.5.0
- Rebased to Titan Extension Blueprint v4.2.0 / Manifest v2.2.
- Converted installer manifest to `titan-extension-v1` and flat-root packaging.
- Added full root-causation lineage.
- Added Shield governance-authority-constraint export.
- Added host certification command, capability/event schemas, navigation and production metadata.

## 0.4.0
- Added durable governed inspection runtime, findings, human review, remediation intents and integration receipts.

## Workforce Runtime Integration Pass 2 — 2026-08-22
- Added deterministic runtime discovery/provider fingerprint contract.
- Added fail-closed request/decision/response envelopes, idempotency, audit and health semantics.
- Added executable runtime descriptor regression coverage without granting authority on registration.
