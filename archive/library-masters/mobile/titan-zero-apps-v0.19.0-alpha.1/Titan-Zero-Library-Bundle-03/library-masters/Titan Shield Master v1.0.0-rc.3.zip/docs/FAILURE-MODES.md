# Failure Modes

- Missing tenant/trace context: fail closed.
- Unresolved authoritative knowledge: do not fabricate compliance truth; return unresolved/review requirement.
- Signal unavailable: persist local integration receipt; do not lose inspection truth.
- Risk/Assurance unavailable for a finding that requires them: block/hold rather than self-approve.
- Command Bus unavailable: remediation remains PREPARED; Shield does not mutate the foreign domain directly.
- Evidence hash mismatch: evidence integrity fails and the inspection cannot rely on the modified bytes.
- Duplicate immutable identity with conflicting payload: reject.
