# Titan Shield v0.3.0 Inspection Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build a deterministic, versioned inspection foundation with evidence integrity and governed finding responses while preserving Shield's strict cross-engine boundaries.

**Architecture:** Introduce immutable domain value objects and pure deterministic services first, then add forward-only persistence schemas and public capability metadata. Cross-engine behavior is represented as structured export/intent contracts, not direct imports or authoritative mutations.

**Tech Stack:** PHP 8.2, Laravel 10 extension packaging/migrations, JSON Schema, SHA-256, PHPUnit-compatible tests plus hostless standalone PHP regression tests.

## Global Constraints

- Preserve the existing `TitanShield` folder, namespace, service provider, routes and migration history.
- Use `company_id`, `trace_id`, `correlation_id`, and `causation_id` on durable Shield state.
- Do not import another Titan extension's internal implementation classes.
- Do not execute arbitrary PHP, shell commands, raw SQL, callbacks or configurable filesystem paths from inspection rules.
- Do not directly mutate authoritative CRM/job/business state.
- Do not persist unrestricted hidden chain-of-thought.
- Offline authority must never increase.
- AI Vision, storage optimization, CDN/recompression and bulk historical reinspection are out of scope.

---

### Task 1: Standalone regression harness and InspectionDefinition registry

**Files:**
- Create: `tests/Standalone/bootstrap.php`
- Create: `tests/Standalone/InspectionDefinitionTest.php`
- Create: `System/Domain/Definitions/InspectionDefinition.php`
- Create: `System/Domain/Definitions/InspectionRule.php`
- Create: `System/Domain/Definitions/EvidenceRequirement.php`
- Create: `System/Domain/Definitions/KnowledgeReference.php`
- Create: `System/Services/InspectionDefinitionValidator.php`
- Create: `System/Services/InspectionDefinitionRegistry.php`
- Create: `schemas/inspection-definition.schema.json`

**Interfaces:**
- Produces `InspectionDefinition::fromArray(array $payload): InspectionDefinition`
- Produces `InspectionDefinitionRegistry::register(InspectionDefinition $definition): void`
- Produces `InspectionDefinitionRegistry::find(string $key, string $version): ?InspectionDefinition`
- Produces `InspectionDefinitionRegistry::latest(string $key): ?InspectionDefinition`

- [x] Write a failing standalone test covering semver validation, immutable same-version registration and definition hashing.
- [x] Run `php tests/Standalone/InspectionDefinitionTest.php`; expect failure because production classes do not exist.
- [x] Implement the minimal domain objects, validator, registry and JSON Schema.
- [x] Re-run the standalone test; expect PASS.

### Task 2: Deterministic RuleEngine

**Files:**
- Create: `tests/Standalone/RuleEngineTest.php`
- Create: `System/Domain/Rules/RuleEvaluation.php`
- Create: `System/Domain/Rules/RuleEvaluationStatus.php`
- Create: `System/Services/DeterministicRuleEngine.php`

**Interfaces:**
- Consumes `InspectionRule`
- Produces `DeterministicRuleEngine::evaluate(InspectionRule $rule, array $facts): RuleEvaluation`

- [x] Write failing tests for evidence presence, file size, MIME allowlist, metadata presence, regex, numeric comparison and checklist aggregation.
- [x] Run the test and confirm RED.
- [x] Implement only the allowlisted rule types with bounded parameter validation.
- [x] Run the test and confirm GREEN.

### Task 3: Evidence hashing and provenance

**Files:**
- Create: `tests/Standalone/EvidenceIntegrityTest.php`
- Create: `System/Domain/Evidence/EvidenceManifest.php`
- Create: `System/Domain/Evidence/EvidenceCaptureRequest.php`
- Create: `System/Services/EvidenceCaptureService.php`

**Interfaces:**
- Produces `EvidenceCaptureService::capture(EvidenceCaptureRequest $request, ShieldExecutionContext $context): EvidenceManifest`
- Produces `EvidenceCaptureService::verify(EvidenceManifest $manifest, string $filePath): bool`

- [x] Write a failing test that hashes a temporary file, verifies it, mutates the file and verifies tamper detection fails.
- [x] Run the test and confirm RED.
- [x] Implement SHA-256 capture, bounded provenance validation and constant-time hash comparison.
- [x] Run the test and confirm GREEN.

### Task 4: Finding severity and governance response

**Files:**
- Create: `tests/Standalone/GovernanceResponseTest.php`
- Create: `System/Domain/Findings/FindingSeverity.php`
- Create: `System/Domain/Findings/InspectionOutcome.php`
- Create: `System/Domain/Findings/Finding.php`
- Create: `System/Domain/Governance/GovernanceAction.php`
- Create: `System/Domain/Governance/GovernanceResponse.php`
- Create: `System/Services/GovernanceResponseResolver.php`
- Create: `System/Contracts/ShieldFindingFeedContract.php`
- Create: `System/Contracts/ShieldIntegrationEnvelopeExporterContract.php`
- Create: `System/Services/ShieldIntegrationEnvelopeExporter.php`

**Interfaces:**
- Produces deterministic `GovernanceResponseResolver::resolve(Finding $finding): GovernanceResponse`
- Produces structured Risk/Assurance/Command/Council envelopes without executing other engines.

- [x] Write failing tests for LOW, MEDIUM, HIGH, CRITICAL and INCONCLUSIVE responses.
- [x] Run the test and confirm RED.
- [x] Implement severity/outcome value objects and fail-closed governance mapping.
- [x] Run the test and confirm GREEN.

### Task 5: Persistence schema and pack contract

**Files:**
- Create: `tests/Standalone/PackageContractTest.php`
- Create: `database/migrations/2026_08_11_000003_create_titan_shield_definition_and_evidence_tables.php`
- Create: `database/migrations/2026_08_11_000004_create_titan_shield_findings_table.php`
- Create: `schemas/shield-pack-selection.schema.json`
- Create: `resources/inspection-packs/field-home-services/basic-job-completion.v1.json`
- Modify: `extension.manifest.json`

**Interfaces:**
- Adds durable definition/evidence/finding tables.
- Defines future Forge/Nexus input `shield_packs[]` without binding to Forge internals.

- [x] Write a failing package contract test for required tables/schema/pack files and manifest ownership.
- [x] Run and confirm RED.
- [x] Add forward-only restart-safe migrations and pack schema/seed.
- [x] Run and confirm GREEN.

### Task 6: Public Shield services and truthful capabilities

**Files:**
- Create: `tests/Standalone/ManagerCapabilityTest.php`
- Modify: `System/Contracts/ShieldManagerContract.php`
- Modify: `System/Services/ShieldManager.php`
- Modify: `System/Capabilities/ShieldCapabilityRegistry.php`
- Modify: `System/TitanShieldServiceProvider.php`
- Modify: `config/titan-shield.php`
- Modify: `extension.json`
- Modify: `extension.manifest.json`

**Interfaces:**
- Add pure capabilities `shield.definition.validate`, `shield.rule.evaluate`, and `shield.governance.response` only if manager methods actually implement them.
- Keep evidence file capture internal; do not expose arbitrary filesystem access as a public capability.

- [x] Write failing capability/manager tests.
- [x] Run and confirm RED.
- [x] Bind services and implement public pure methods.
- [x] Update version to `0.3.0` and manifest capability claims.
- [x] Run and confirm GREEN.

### Task 7: Security, design documentation and production-backdoor prevention

**Files:**
- Create: `tests/Standalone/SecurityBoundaryTest.php`
- Create: `tests/Support/ForcedFindingFactory.php`
- Create: `docs/INSPECTION-ENGINE-DESIGN.md`
- Modify: `README.md`
- Modify: `TITAN-SHIELD-UPGRADE-PROMPT.md`

**Interfaces:**
- Test-only finding forcing exists only under `tests/Support`.
- Production capabilities never include `test.override`.

- [x] Write security test first for forbidden execution primitives, cross-extension imports and production test override.
- [x] Run it against current source and record baseline.
- [x] Add test-only fixture and design docs covering AI Vision, chain of custody, severity, human review, performance targets, vertical packs and integration boundaries.
- [x] Run the complete standalone suite.

### Task 8: Exact-package verification

**Files:**
- Create: `PASS-2-INSPECTION-FOUNDATION.md`
- Create release ZIP and SHA-256 file in `/mnt/data`.

- [x] PHP-lint every packaged PHP file.
- [x] Parse every JSON file.
- [x] Run all standalone tests.
- [x] Validate ZIP CRC, traversal/backslash paths, duplicates, symlinks, case collisions and junk paths.
- [x] Verify manifest/version/capability/table truthfulness against exact packaged bytes.
- [x] Produce the cumulative v0.3.0 ZIP and checksum.
