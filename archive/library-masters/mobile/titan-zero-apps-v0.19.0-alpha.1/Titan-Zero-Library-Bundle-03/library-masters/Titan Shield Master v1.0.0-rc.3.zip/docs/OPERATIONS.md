# Operations

Use `php artisan titan:titan-shield:certify` for non-destructive host certification. Keep `titan-shield.enabled` available as the kill switch. Queue execution remains disabled in v1.0.0-rc.2. Reinspection is synchronous/deterministic in this release and operates on one finding at a time. Inspect health separately from historical incidents. Do not promote the development package to production until the exact ZIP SHA completes Installer, migration, boot, navigation, authorization, runtime, concurrency, upgrade and uninstall certification.


For regulated inspections, monitor `knowledge_bindings` for `UNRESOLVED`/blocking states. A PINNED binding proves exact version/hash identity but is not a freshness or contradiction-resolution claim.
