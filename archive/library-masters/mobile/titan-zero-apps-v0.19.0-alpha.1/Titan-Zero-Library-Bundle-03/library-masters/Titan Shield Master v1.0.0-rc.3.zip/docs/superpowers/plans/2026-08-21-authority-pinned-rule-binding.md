# Titan Shield Authority-Pinned Rule Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Shield inspections pin and prove the exact Knowledge Authority reference used for authoritative rules while failing closed when required authority is unavailable.

**Architecture:** Add a strict authority-binding domain/policy, durable binding receipts, and a runtime preflight before inspection rule evaluation. Use the public Knowledge Authority contract only when a future `resolve()` method exists; otherwise exact version/hash metadata supplied by the definition is treated as a pinned reference, never as a live authority resolution.

**Tech Stack:** PHP 8.2+, Laravel 10, MySQL, JSON Schema, Titan Extension Blueprint Manifest v2.2.

**Spec:** `docs/superpowers/specs/2026-08-21-authority-pinned-rule-binding-design.md`

## Global Constraints
- Preserve `titan-extension-v1` flat-root Installer 1.7.8 package shape.
- Preserve Blueprint Manifest v2.2 and production-core inheritance.
- Never import Knowledge Authority internal repositories/read services.
- Required unresolved authority fails closed to INCONCLUSIVE.
- Shield stores references/receipts only, not authoritative source content.
- All new tables use `titan_shield_*`, tenant context and full causal lineage.

---

### Task 1: Strict knowledge reference and binding policy
**Files:**
- Modify: `System/Domain/Definitions/KnowledgeReference.php`
- Modify: `System/Domain/Knowledge/KnowledgeResolution.php`
- Create: `System/Domain/Knowledge/KnowledgeBindingReceipt.php`
- Create: `System/Services/KnowledgeBindingPolicy.php`
- Test: `tests/Standalone/KnowledgeBindingPolicyTest.php`

**Interfaces:**
- Produces: `KnowledgeBindingPolicy::bind(KnowledgeReference $reference, KnowledgeResolution $resolution, string $jurisdiction): array`

- [ ] Write a failing test proving exact pinned version/hash binds and required unresolved authority blocks.
- [ ] Run the test and confirm it fails because the new policy does not exist.
- [ ] Implement the minimum domain/policy.
- [ ] Run the test and confirm PASS.

### Task 2: Durable binding receipts
**Files:**
- Create: `database/migrations/2026_08_21_000009_create_titan_shield_knowledge_bindings_table.php`
- Modify: `System/Contracts/ShieldRuntimeStoreContract.php`
- Modify: `System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php`
- Test: `tests/Standalone/KnowledgeBindingPersistenceContractTest.php`

**Interfaces:**
- Produces: `ShieldRuntimeStoreContract::recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void`

- [ ] Write failing persistence-contract test.
- [ ] Run and confirm RED.
- [ ] Add migration/store method using tenant and trace/correlation/causation/root-causation fields.
- [ ] Run and confirm GREEN.

### Task 3: Runtime authority preflight
**Files:**
- Modify: `System/Integrations/KnowledgeAuthorityAdapter.php`
- Modify: `System/Services/InspectionRuntimeCoordinator.php`
- Modify: `System/Services/ShieldManager.php`
- Test: `tests/Standalone/KnowledgeBoundInspectionTest.php`

**Interfaces:**
- Consumes: `KnowledgeBindingPolicy`, `KnowledgeAuthorityAdapter`, runtime store.
- Produces: inspection output field `knowledge_bindings`; unresolved required authority returns `INCONCLUSIVE` with reason `KNOWLEDGE_AUTHORITY_UNRESOLVED` before normal rule conclusions.

- [ ] Write failing runtime test for required unresolved and exact pinned authority.
- [ ] Run and confirm RED.
- [ ] Add preflight binding and receipt recording.
- [ ] Run and confirm GREEN plus existing runtime tests.

### Task 4: Schemas, pack binding, release metadata and verification
**Files:**
- Modify: `schemas/inspection-definition.schema.json`
- Create: `schemas/knowledge-binding-receipt.schema.json`
- Modify: `schemas/capabilities/shield-inspection-evaluate.output.json`
- Modify: `README.md`, `CHANGELOG.md`, capability docs, manifest/installer metadata.
- Create: `PASS-7-KNOWLEDGE-AUTHORITY-BINDING.md`

**Interfaces:**
- Produces release v0.8.0.

- [ ] Update schemas/docs/version and integrity map.
- [ ] Run all standalone tests.
- [ ] Lint every PHP file and parse every JSON file.
- [ ] Verify every migration has `down()` and MySQL identifiers remain valid.
- [ ] Run Blueprint/installer validators available in package.
- [ ] Build flat-root cumulative ZIP, clean-extract, rerun tests/lint/JSON/integrity, and compute SHA-256.
