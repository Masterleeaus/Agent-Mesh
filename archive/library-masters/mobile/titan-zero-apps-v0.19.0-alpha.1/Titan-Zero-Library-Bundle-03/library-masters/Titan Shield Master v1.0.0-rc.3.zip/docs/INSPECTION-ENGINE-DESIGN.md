# Titan Shield Inspection Engine Design — v0.3.0

## Purpose

Titan Shield is the independent inspection/verification layer. It decides whether supplied evidence and normalized facts satisfy a versioned inspection definition. It does not become Titan Risk, Titan Assurance, Knowledge Authority, Model Council, Command Bus or CRM.

## Versioned inspection definitions

Every definition is pinned by `definition_key`, semantic `version`, and SHA-256 `definition_hash`. Re-registering identical bytes/meaning under the same key/version is idempotent; changing meaning under the same key/version fails closed. Historical inspection results must retain the exact version/hash they used.

Knowledge references use stable `knowledge_key` plus resolved version/hash where available. `vertical_key` controls applicability only; it is not itself authoritative regulatory evidence.

## Deterministic-first evaluation

The v0.3 engine supports only allowlisted pure rules:

- evidence present
- minimum file size
- MIME allowlist
- metadata presence
- bounded anchored regex
- numeric comparison
- checklist all/any/minimum

No rule can execute PHP expressions, callbacks, shell commands, SQL, HTTP requests or configurable filesystem paths.

## Evidence chain of custody

At trusted capture time Shield records:

- evidence ID/key
- tenant
- original filename
- MIME type
- byte size
- SHA-256 of the original bytes
- capture time
- optional device ID
- private storage reference
- bounded metadata
- trace/correlation/causation IDs
- actor/source provenance

Integrity is rechecked by hashing the candidate bytes and using constant-time comparison with the stored digest. A changed file no longer matches the original manifest.

v0.3 does not optimize, compress or CDN-transform evidence and does not bulk-reinspect historical jobs.

## Outcome and severity

Inspection outcomes:

- `pass`
- `conditional_pass`
- `fail`
- `inconclusive`

Shield-local severity:

- `info`
- `low`
- `medium`
- `high`
- `critical`

This severity is evidence/inspection classification only. Titan Risk remains authoritative for contextual/cumulative operational risk.

Default response:

| Result | Shield response |
|---|---|
| Pass | Continue |
| Info | Continue |
| Low | Record and continue |
| Medium | Request remediation; conditional pass may continue only when definition policy permits |
| High | Block and request Risk + Assurance evaluation |
| Critical | Fail closed; Risk + Assurance + human review required |
| Inconclusive | Block for more evidence or review; Assurance requested |

Model Council is never the automatic MEDIUM path. It is eligible only after deterministic checks and ordinary Assurance leave a genuine unresolved ambiguity/disagreement, and only once Council exposes a suitable deliberation API.

## Cross-engine envelopes

Shield exports idempotent envelopes for:

- Risk evaluation
- Assurance verification
- Command Bus remediation request
- Model Council escalation request

These envelopes retain tenant + trace/correlation/causation context and explicitly declare `direct_mutation=false`. The target engine remains authoritative for its own decision/execution.

## Command Bus remediation

Shield may request remediation, but cannot directly create a CRM job, schedule a crew, send a consequential customer message, change job completion state or modify another engine's tables. Those changes must traverse the owning domain and Titan Command Bus.

## Human review

Critical findings always require human review and cannot be autonomously overridden. High findings block pending configured governance evaluation. Any later human override must record actor, reason code, evidence references, trace chain and resulting disposition. Hidden chain-of-thought must never be stored.

### Access-control intent

- founder/authorized owner: all findings for own tenant
- admin/compliance role: full tenant findings/evidence per policy
- crew member: findings relevant to authorized assigned work
- customer: only explicitly published customer-safe outcome/summary

Host permission/capability mappings must be verified before this matrix is enforced in routes; role names are not hard-coded into v0.3 domain code.

## AI Vision scope

AI Vision is deliberately disabled in v0.3. When added:

1. AI Core/Vision produces structured observations from evidence.
2. Shield applies inspection rules to those observations.
3. Assurance evaluates confidence/evidence quality when policy requires it.
4. Safety-critical findings cannot be autonomously closed by Vision alone.

Initial Vision targets may include job-completion quality, obvious damage/defect observations and safety-hazard flagging. It must not claim regulatory compliance from image inference alone.

## Performance targets

These are engineering targets, not certified SLAs:

- deterministic inspection: target under 5 seconds end-to-end in normal host conditions
- future Vision inspection: target under 30 seconds
- future full compliance inspection: target under 60 seconds

Production SLOs must be measured before contractual claims are made.

## Vertical packs

Pack selection is represented by a `shield_packs[]` BuildSpec fragment. Forge/Nexus requests pack keys/version constraints; Shield owns pack resolution and definition content.

Initial examples:

- Field/Home Services: job-completion evidence, basic site-restoration/quality checks
- Cleaning: room/area completion evidence and before/after requirements
- HVAC: job evidence and equipment-result checks, with regulatory knowledge referenced through Knowledge Authority rather than embedded as uncontrolled rules
- Landscaping: site-restoration and evidence packs; safety rules only after authoritative knowledge sources are resolved

The included `field-home-services/basic-job-completion` pack is explicitly non-regulatory.

## Forge boundary

Current Forge does not yet advertise a live generation capability, so Shield v0.3 ships only the pack-selection schema. Forge injection must wait for Forge's generation contract rather than coupling Shield to an unfinished implementation.
