# Engine Ownership

Canonical Shield domain: `quality-safety-verification`. Shield is authoritative for inspection definitions, inspection outcomes/findings and Shield evidence verification metadata. Titan Risk owns contextual risk, Titan Assurance owns independent assurance, Titan Autonomy owns effective authority, Titan Knowledge Authority owns authoritative knowledge, and Titan Command Bus owns consequential cross-domain mutation dispatch.
