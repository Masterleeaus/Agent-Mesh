# Titan Shield Pass 7 — Authority-Pinned Rule Binding Design

## Goal
Bind Shield inspection definitions and runs to exact authoritative knowledge references without bypassing Titan Knowledge Authority ownership or inventing a public resolver that does not yet exist.

## Current peer constraint
Titan Knowledge Authority v0.4.0 exposes health and internal scoped catalog reads, but deliberately does not expose `knowledge.resolve`, authority precedence resolution, jurisdiction inheritance, or a public applicability API. Titan Shield therefore must not import internal Knowledge Authority repository/read contracts.

## Architecture
1. Extend Shield `KnowledgeReference` with explicit authority metadata: `authority_domain`, `jurisdiction`, `applicability`, and `required` while retaining `knowledge_key`, exact `version`, and exact SHA-256 `content_hash`.
2. Introduce `KnowledgeBindingPolicy` that classifies each reference as `PINNED`, `RESOLVED`, or `UNRESOLVED`. A required reference may authorize compliance evaluation only when an exact version/hash exists and jurisdiction/applicability match the inspection context, or when a future public Knowledge Authority resolver returns an exact matching version/hash.
3. Introduce an immutable `KnowledgeBindingReceipt` per inspection definition/run reference. Receipts retain tenant, run, definition key/version/hash, vertical, jurisdiction, knowledge key, source version/hash, binding mode, status, reason codes, and causal lineage.
4. Extend the runtime store with `recordKnowledgeBindingReceipt()` and a new `titan_shield_knowledge_bindings` table. This is Shield-owned evidence of what authority was used, not a copy of Knowledge Authority content.
5. Before deterministic rule evaluation, `InspectionRuntimeCoordinator` binds every knowledge reference. Any unresolved required reference causes the inspection to return `INCONCLUSIVE`/authority hold rather than a compliance pass/fail. Optional unresolved references are recorded but do not block.
6. Pack selection remains deterministic by `vertical_key`; jurisdiction is an applicability constraint, not an authority source. Shield never selects a different jurisdiction silently.

## Boundaries
- Titan Knowledge Authority remains canonical owner of authoritative knowledge, precedence, freshness, applicability and contradiction resolution.
- Shield stores only references and resolution receipts, never authoritative source content.
- Shield never imports Knowledge Authority internal repositories/services.
- No LLM may upgrade an unresolved authority reference.
- No unresolved required authority may yield PASS/CONDITIONAL_PASS/FAIL as a compliance conclusion; result is INCONCLUSIVE with `KNOWLEDGE_AUTHORITY_UNRESOLVED`.
- Existing definitions with empty `knowledge_references` remain valid for non-authoritative deterministic inspections.

## Testing
- RED/GREEN tests for pinned reference validation and exact SHA/version enforcement.
- Required unresolved authority blocks inspection as INCONCLUSIVE.
- Optional unresolved authority does not block but emits a receipt.
- Jurisdiction mismatch fails closed.
- Future public resolver result must match pinned version/hash when both are supplied.
- Persistence test requires only `titan_shield_*` tables and causal lineage.
- Package regression, manifest, schema, migration, PHP lint, JSON and exact-ZIP verification remain mandatory.
