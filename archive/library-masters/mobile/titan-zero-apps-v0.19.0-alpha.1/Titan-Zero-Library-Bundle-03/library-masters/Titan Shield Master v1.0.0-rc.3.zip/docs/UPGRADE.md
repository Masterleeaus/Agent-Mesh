# Upgrade

Migrations are forward-only compatible and historical migrations remain frozen. v0.5.0 added `root_causation_id` using an additive restart-safe migration. v0.7.0 adds reinspection/transition tables and closure linkage through migration `2026_08_19_000007_create_titan_shield_reinspection_lifecycle_tables.php`; it does not rewrite prior inspection/finding migrations. Upgrade must preserve old/new worker compatibility, immutable inspection/finding identity and existing open findings.


v0.8.0 adds `2026_08_21_000009_create_titan_shield_knowledge_bindings_table.php` for immutable authority-binding receipts. It does not modify historical migrations or copy Knowledge Authority content.
