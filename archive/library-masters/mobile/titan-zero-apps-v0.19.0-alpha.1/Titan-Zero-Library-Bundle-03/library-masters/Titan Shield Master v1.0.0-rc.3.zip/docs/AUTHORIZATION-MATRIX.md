# Authorization Matrix

| Capability/surface | Required permission | Boundary |
|---|---|---|
| Shield dashboard | `shield.view` | tenant scoped |
| Inspection evaluation | `shield.inspect` | tenant + subject scope |
| Human review | `shield.review` | tenant + reviewer policy |
| Remediation preparation | `shield.remediation.prepare` | prepare-only; no foreign mutation |
| Reinspection evaluation | `shield.reinspection` | tenant + original finding + exact definition identity; single finding only |
| Admin surface | `shield.admin` | platform/super-admin policy |

Authentication alone is insufficient for consequential capability execution. Super Admin bypass and delegated administration are host-policy concerns; tenant object scope remains mandatory. HIGH/CRITICAL closure requires independent Assurance clearance and cannot be granted by the reinspection permission alone.
