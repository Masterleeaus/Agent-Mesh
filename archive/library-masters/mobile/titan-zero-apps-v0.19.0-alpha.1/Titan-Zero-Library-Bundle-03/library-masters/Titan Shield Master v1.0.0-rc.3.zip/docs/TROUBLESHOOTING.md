# Troubleshooting

1. Run `php artisan titan:titan-shield:certify --json`.
2. Verify migrations and all `titan_shield_*` tables.
3. Confirm routes `dashboard.user.titan.shield.index` and `dashboard.admin.titan.shield.index`.
4. Confirm required Titan Signal and Command Bus dependencies are installed.
5. For DEGRADED integration receipts, inspect reason codes without exposing tokens/secrets.
6. If evidence fails integrity, compare the stored SHA-256 manifest against original bytes; do not overwrite the historical manifest.
