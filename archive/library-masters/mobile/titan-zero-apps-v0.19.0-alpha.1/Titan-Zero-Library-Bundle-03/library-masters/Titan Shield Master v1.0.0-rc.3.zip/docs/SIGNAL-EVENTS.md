# Signal Events

Shield emits versioned Signal-aware events with tenant and full causal lineage:
- `shield.inspection.completed`
- `shield.finding.recorded`
- `shield.finding.risk_evaluation_requested`
- `shield.finding.assurance_requested`
- `shield.reinspection.completed`
- `shield.finding.closed`
- `shield.finding.closure_held`

Signal observations do not become business truth or execution authority. Closure events describe Shield-owned finding state only; they do not imply that a CRM job or other foreign-domain record was completed or released.
