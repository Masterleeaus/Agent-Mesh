# Security

Shield forbids arbitrary code execution and public arbitrary filesystem-path rules. Evidence capture accepts trusted regular non-symlink files and hashes original bytes with SHA-256. No credentials are stored by Shield. Sensitive fields and evidence bytes are excluded from Signal payloads/logs. Tenant scope and causal context fail closed. Direct foreign-domain writes are prohibited.
