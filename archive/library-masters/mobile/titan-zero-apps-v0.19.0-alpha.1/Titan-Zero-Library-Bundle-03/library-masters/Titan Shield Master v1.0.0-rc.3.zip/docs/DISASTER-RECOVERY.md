# Disaster Recovery

RPO target: 60 minutes. RTO target: 240 minutes. Restore `titan_shield_*` durable tables together with evidence storage objects/references, then verify definition hashes, evidence SHA-256 manifests, tenant boundaries and integration-receipt continuity before re-enabling inspection execution. Reconcile prepared remediation intents before any Command Bus continuation.
