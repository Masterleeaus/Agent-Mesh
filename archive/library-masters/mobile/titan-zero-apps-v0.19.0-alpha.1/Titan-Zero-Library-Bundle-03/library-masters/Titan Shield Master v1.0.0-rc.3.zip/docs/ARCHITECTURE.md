# Titan Shield Architecture

Titan Shield is the canonical owner of `quality-safety-verification`. It owns inspection definitions, deterministic inspection execution, evidence manifests, findings, reviews, remediation intents, single-finding reinspections, Shield finding lifecycle/closure and Shield integration receipts. It does not own CRM/business truth, Risk, Assurance, Autonomy, Knowledge Authority or Command Bus execution.

Primary profile: `governance-engine`. Modifiers: `regulated`, `safety-critical`, `signal-aware`. Cross-domain state changes are prepared as intents and delegated to Titan Command Bus. Shield authority constraints are upper bounds only.

## Reinspection lifecycle

A reinspection is a new inspection run linked to one original Shield finding. It must use the same tenant, subject, definition key, definition version and definition content hash as the finding being re-evaluated. A deterministic `PASS` is necessary for closure. INFO/LOW/MEDIUM may close after that pass; HIGH/CRITICAL are held pending independent Assurance clearance. Finding transitions are append-only and the current finding row is changed under a tenant-scoped database lock.
