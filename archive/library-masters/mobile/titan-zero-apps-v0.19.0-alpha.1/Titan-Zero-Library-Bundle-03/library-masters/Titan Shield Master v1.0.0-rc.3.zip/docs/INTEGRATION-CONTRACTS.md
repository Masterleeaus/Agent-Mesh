# Integration Contracts

Required runtime dependencies: Titan Signal and Titan Command Bus. Optional guarded integrations: Titan Risk, Titan Assurance, Titan Autonomy, Titan Rewind, Titan Knowledge Authority and Titan Model Council. Integrations use public contracts/envelopes only. Failure to resolve an optional governance engine never silently counts as approval. Full causal lineage is `trace_id`, `correlation_id`, `causation_id`, `root_causation_id`.

## Reinspection boundary

Shield owns reinspection evaluation and its own finding lifecycle. It may close an INFO/LOW/MEDIUM Shield finding after an exact-definition deterministic `PASS`. HIGH/CRITICAL findings remain held pending independent Assurance clearance. Shield does not infer that clearance from peer absence or from its own pass result.

## Command Bus

The currently verified Command Bus peer is health-only and has no callable dispatch/execute contract. Shield therefore emits/retains prepare-only remediation intent and never invents a command method. `shield.remediation.execute` remains absent.

## Knowledge Authority

The currently verified Knowledge Authority public surface is health-only. Shield stores authoritative references but returns unresolved applicability when a resolver contract is unavailable.

## Rewind

Shield writes structured local reconstruction receipts with reason codes, definition/evidence/finding identifiers and full causal lineage. Hidden chain-of-thought is never persisted. A future public Rewind ingest contract may receive these receipts without changing Shield finding semantics.

## Titan Knowledge Authority

Shield consumes only the public Knowledge Authority contract. v0.8.0 does not import internal catalog/read repositories. Until a public `resolve()` exists, exact version/hash references may bind as `PINNED`; they are never labeled `LIVE`. Required references configured with `require_live_resolution=true` fail closed while the public resolver is unavailable.
