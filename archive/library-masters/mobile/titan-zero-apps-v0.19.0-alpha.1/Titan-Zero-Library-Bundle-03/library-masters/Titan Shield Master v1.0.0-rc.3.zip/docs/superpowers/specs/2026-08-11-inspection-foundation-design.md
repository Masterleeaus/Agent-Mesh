# Titan Shield v0.3.0 Inspection Foundation Design

## Goal

Turn Titan Shield from a truthful foundation into a useful deterministic inspection governor without introducing AI Vision, direct business mutation, or hidden test backdoors.

## Ownership boundary

Titan Shield owns inspection definitions, deterministic evaluation, evidence-integrity metadata, findings, inspection-local severity, and governance-response recommendations.

Titan Shield does not own contextual risk scoring, assurance scoring, regulatory truth, model orchestration, autonomy grants, authoritative CRM/job mutation, or workflow execution. It exports structured findings/evidence to those engines through public ports/envelopes.

## InspectionDefinition

Definitions are immutable versioned assets identified by `definition_key` + semantic `version`. Historical runs remain pinned to the exact `definition_hash` used. A new definition revision creates a new version; it never mutates the meaning of an older version.

Required definition fields:

- `definition_key`
- `version`
- `name`
- `description`
- `vertical_key`
- `inspection_type`
- `scope`
- `status`
- `rules[]`
- `evidence_requirements[]`
- `pass_policy`
- `conditional_pass_policy`
- `review_policy`
- `remediation_policy`
- `knowledge_references[]`
- `source_pack`
- `effective_from`
- `supersedes_version`
- `definition_hash`

Knowledge references use stable knowledge/policy identifiers plus optional resolved version/hash. `vertical_key` selects applicability but is not itself proof of an authoritative rule source.

## Deterministic Rule Engine

The engine accepts normalized facts/evidence manifests and supports an allowlist of rule types only:

- `evidence_present`
- `min_file_size`
- `mime_allowed`
- `metadata_present`
- `regex_match`
- `numeric_compare`
- `checklist_all`
- `checklist_any`
- `checklist_minimum`

No arbitrary PHP expressions, callbacks, shell commands, raw SQL, or configurable filesystem paths are executable by rule definitions.

## Evidence integrity

Evidence content is hashed at capture using SHA-256 before any later inspection. Shield stores metadata/provenance and a storage reference, not a public URL or embedded unrestricted binary payload.

An evidence manifest records evidence ID, original filename, MIME type, byte size, SHA-256, captured time, optional capture device ID, source, storage reference, trace chain, tenant and bounded metadata. Changing content changes the hash and therefore invalidates integrity verification against the original manifest.

Storage optimization, CDN strategy, image recompression, and bulk historical reinspection are explicitly out of scope for v0.3.0.

## Severity and outcomes

Shield-local severity is distinct from Titan Risk:

`INFO -> LOW -> MEDIUM -> HIGH -> CRITICAL`

Inspection outcomes are:

- `PASS`
- `CONDITIONAL_PASS`
- `FAIL`
- `INCONCLUSIVE`

Default governance response:

- PASS/INFO: continue and record
- LOW: continue and record
- MEDIUM: remediation or conditional pass according to definition policy
- HIGH: block progression and request Risk + Assurance evaluation
- CRITICAL: fail closed and require human review; autonomous override is prohibited
- INCONCLUSIVE: require more evidence or human/Assurance review

Model Council is not the default MEDIUM path. Council escalation is reserved for unresolved ambiguity/disagreement after deterministic evaluation and normal Assurance handling.

## Cross-engine integration

Shield exports structured, idempotent envelopes rather than importing engine internals.

- Risk consumes finding summaries/evidence metadata and remains authoritative for contextual/cumulative risk.
- Assurance consumes evidence/finding envelopes and remains authoritative for assurance/confidence.
- Command Bus receives remediation intents; Shield never directly creates jobs, schedules crews, or mutates authoritative CRM state.
- Model Council receives an escalation intent only when policy selects council escalation and an appropriate council deliberation API exists.
- Knowledge Authority supplies/version-resolves authoritative knowledge references.
- Forge/Nexus may request `shield_packs[]`; Shield remains authoritative for the actual pack/version resolved.

## Forge pack contract

A BuildSpec may request `shield_packs` by stable pack key/version constraint. Forge must not embed a separate copy of Shield rules as a second authority. Pack injection is contract-only in v0.3.0 because the current Forge build does not yet expose a production generation capability.

## AI Vision scope

AI Vision is deferred. When added, Vision produces structured observations/evidence through AI Core/Vision. Shield owns deterministic verification against inspection definitions. AI Vision alone cannot autonomously close or override safety-critical findings.

## Human review

Critical findings always require human review. High findings block progression pending configured review/Risk/Assurance handling. Human overrides must record actor, reason code, evidence references, trace chain and resulting disposition. No hidden chain-of-thought is persisted.

## Testing

v0.3.0 must provide executable standalone regression tests for:

- immutable definition registry/version pinning
- strict definition validation
- deterministic rule success/failure
- evidence hash integrity/tamper detection
- severity/governance response
- fail-closed tenant/trace context
- security boundary scan
- no production `test.override` capability
- migration/manifest truthfulness

