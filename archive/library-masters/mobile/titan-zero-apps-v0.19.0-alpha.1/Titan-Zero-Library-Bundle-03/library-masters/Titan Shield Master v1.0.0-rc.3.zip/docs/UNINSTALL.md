# Uninstall

Uninstall is idempotent and removes only published `config/titan-shield.php`. Durable Shield tables/evidence metadata are retained by default (`preserve_data=true`). Tenant data deletion is a separate governed retention operation and must not be coupled to code uninstall.
