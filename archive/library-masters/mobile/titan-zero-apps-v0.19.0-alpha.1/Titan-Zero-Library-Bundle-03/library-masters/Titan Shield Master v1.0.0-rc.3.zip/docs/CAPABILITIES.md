# Capabilities

- `shield.health` — liveness/readiness summary.
- `shield.definition.validate` — validates immutable versioned inspection definitions.
- `shield.rule.evaluate` — deterministic rule evaluation.
- `shield.governance.response` — maps findings to bounded governance responses.
- `shield.inspection.evaluate` — persists governed inspection runs/findings and prepares integration work.
- `shield.review.determine` — creates immutable human-review requests.
- `shield.authority.constraint` — exports `governance-authority-constraint` v1.0 records that can only contract/block authority.
- `shield.remediation.prepare` — prepares remediation intent; never directly mutates a foreign domain.
- `shield.reinspection.evaluate` — executes a single-finding deterministic reinspection pinned to the original definition and applies Shield-owned finding closure policy.

There is no public bulk-reinspection or remediation-execution capability in v1.0.0-rc.2.

## Knowledge binding

`shield.inspection.evaluate` and `shield.reinspection.evaluate` accept optional `jurisdiction`. Their runtime output includes `knowledge_bindings`. `PINNED` means an immutable version/hash was supplied by the definition; `LIVE` is reserved for a future public Knowledge Authority resolver. Required unresolved authority returns INCONCLUSIVE.
