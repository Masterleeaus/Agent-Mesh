# Titan Shield Pass 5 Reinspection & Finding Closure Implementation Plan

**Goal:** Add a single-finding reinspection and governed closure lifecycle without expanding Shield into Command Bus, Risk, Assurance, or CRM authority.

**Architecture:** Reinspection remains Shield-owned because it validates Shield findings against the exact original inspection definition hash. A new coordinator executes the reinspection through the existing governed runtime, records the linkage, and applies deterministic closure policy. HIGH/CRITICAL findings remain held until a future normalized Assurance clearance contract exists; no external engine absence can release a finding.

**Tech Stack:** PHP 8.2+, Laravel 10 migrations/persistence, Titan Extension Blueprint v4.2.0 / Manifest v2.2.

## Global Constraints
- Tenant key remains `company_id`.
- Preserve trace/correlation/causation/root-causation lineage.
- Reinspection is one finding at a time; no bulk reinspection.
- Reinspection closure requires exact original `definition_key`, `version`, and `definition_hash`.
- Only exact `PASS` may satisfy deterministic closure.
- HIGH/CRITICAL findings cannot auto-close in this pass.
- Shield never directly mutates CRM/job state.
- Command Bus execution is not fabricated while the peer exposes health only.
- Significant lifecycle changes emit Signal attempts and durable Rewind-compatible receipts.

## Tasks
1. Add failing standalone tests for reinspection identity, exact-definition pinning, PASS-only closure, and HIGH/CRITICAL hold behavior.
2. Add reinspection/closure domain objects and deterministic policy service.
3. Add forward-only persistence for reinspection records, lifecycle transitions, and finding closure columns.
4. Add governed reinspection coordinator, Signal events, Rewind-compatible receipts, and Shield-owned status updates.
5. Add truthful public capabilities/schemas, provider bindings, manifest metadata and documentation.
6. Run exact-source and exact-ZIP regression, lint, JSON, migration, security, path and integrity verification.
