# Titan Shield Pass 3 Governed Runtime Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Shield inspection outcomes durable and connect them to the existing Titan governance spine without giving Shield authority owned by Risk, Assurance, Command Bus, Knowledge Authority, Signal or Rewind.

**Architecture:** Shield owns inspection runs, item results, findings, human-review state and remediation intents. Cross-engine integration is through optional adapters that resolve existing public contracts dynamically and fail closed or return explicit unavailable receipts rather than importing optional engine internals. Signal receives state-change events when available; Rewind receives reconstruction-compatible receipts through Shield-owned durable records because the current Rewind foundation exposes read adapters, not a write API.

**Tech Stack:** PHP 8.2, Laravel 10 service container/query builder, JSON, SHA-256, existing Titan extension contracts.

## Global Constraints

- Preserve `TitanShield` extension identity, registration key, routes and existing migrations.
- `company_id`, `trace_id`, `correlation_id`, and `causation_id` remain mandatory on governed operations.
- Shield determines inspection findings only; Titan Risk determines contextual risk.
- Titan Assurance independently evaluates evidence confidence/quality.
- Consequential remediation is prepared as a Command Bus intent; Shield never mutates CRM/job truth directly.
- Knowledge Authority is authoritative for governed knowledge; when its current public contract cannot resolve rules, Shield must return `UNRESOLVED` rather than invent authority.
- Rewind stores no hidden chain-of-thought; only structured reason codes, evidence references, policy/definition versions and receipts.
- Offline/unavailable integrations never increase authority.

---

### Task 1: Durable inspection lifecycle

**Files:**
- Create `System/Domain/Inspections/InspectionRunStatus.php`
- Create `System/Domain/Inspections/InspectionItemResult.php`
- Create `System/Domain/Inspections/InspectionRun.php`
- Create `System/Services/InspectionRunEvaluator.php`
- Create `database/migrations/2026_08_11_000005_create_titan_shield_inspection_runtime_tables.php`
- Test `tests/Standalone/InspectionRunLifecycleTest.php`

**Interfaces:**
- Consumes `InspectionDefinition`, `DeterministicRuleEngine`, `ShieldExecutionContext`.
- Produces `InspectionRunEvaluator::evaluate(...) : InspectionRun` with immutable item results and a final Shield outcome.

### Task 2: Human review and remediation intents

**Files:**
- Create `System/Domain/Review/HumanReviewDecision.php`
- Create `System/Domain/Review/HumanReviewRequest.php`
- Create `System/Domain/Remediation/RemediationIntent.php`
- Create `System/Services/HumanReviewWorkflow.php`
- Test `tests/Standalone/HumanReviewWorkflowTest.php`

**Interfaces:**
- Human review supports `PENDING`, `CONFIRM_FINDING`, `OVERRIDE_FINDING`, `MORE_EVIDENCE_REQUIRED` and preserves the original Shield finding.
- Remediation intents are prepare-only, idempotent and explicitly `direct_mutation=false`.

### Task 3: Risk and Assurance adapters

**Files:**
- Create `System/Integrations/RiskEngineAdapter.php`
- Create `System/Integrations/AssuranceEngineAdapter.php`
- Test `tests/Standalone/GovernanceAdaptersTest.php`

**Interfaces:**
- Risk adapter targets current `RiskGateContract` + `RiskContextInput` when available, falling back to `RiskManagerContract` only if the gate is absent.
- Assurance adapter targets current `EvidenceAssuranceEngine::assess(array)` when available.
- Both return normalized receipts and never reinterpret the owning engine's decision.

### Task 4: Signal and Rewind receipts

**Files:**
- Create `System/Integrations/SignalEngineAdapter.php`
- Create `System/Domain/Receipts/RewindReceipt.php`
- Create `System/Services/RewindReceiptFactory.php`
- Test `tests/Standalone/SignalRewindReceiptTest.php`

**Interfaces:**
- Signal adapter emits through `SignalEmitterContract::emit()` if bound; unavailable integrations return explicit `UNAVAILABLE` receipt.
- Rewind receipt contains tenant/trace chain, definition hash, run/finding/evidence IDs, structured reason codes and no chain-of-thought.

### Task 5: Knowledge Authority resolution boundary

**Files:**
- Create `System/Domain/Knowledge/KnowledgeResolution.php`
- Create `System/Integrations/KnowledgeAuthorityAdapter.php`
- Test `tests/Standalone/KnowledgeAuthorityAdapterTest.php`

**Interfaces:**
- Current Knowledge Authority Pass 1 exposes health only. Adapter verifies availability but returns `UNRESOLVED` for rule resolution until a resolver capability is published; it never fabricates authoritative content.

### Task 6: Provider, manifest, capabilities and package verification

**Files:**
- Modify `System/TitanShieldServiceProvider.php`
- Modify `System/Services/ShieldManager.php`
- Modify `System/Contracts/ShieldManagerContract.php`
- Modify `System/Capabilities/ShieldCapabilityRegistry.php`
- Modify `extension.json`
- Modify `extension.manifest.json`
- Modify `README.md`
- Create `PASS-3-GOVERNED-RUNTIME.md`
- Test existing standalone suites plus new Pass 3 suites.

**Interfaces:**
- Version becomes `0.4.0`.
- New truthful public capabilities are limited to behavior executable within Shield: `shield.inspection.evaluate`, `shield.review.determine`, `shield.remediation.prepare` in addition to existing capabilities.
- External engine calls remain internal adapters, not public authority-granting Shield capabilities.
