# Pass 6 — Independent Assurance Clearance

Titan Shield v0.7.0 adds fail-closed independent Assurance clearance for HIGH and CRITICAL finding closure. A successful exact-definition reinspection alone is insufficient. Shield calls the public `EvidenceAssuranceEngine` through an optional port, normalizes the result, requires GREEN status, score >= 80, matching tenant/subject/capability, non-empty policy version, no missing/stale/contradictory evidence, and an exact evidence ID + SHA-256 set match.

Clearance decisions are normalized to ALLOW / HOLD / DENY. Only ALLOW permits closure. Unavailable, malformed, AMBER, mismatched or stale Assurance results remain held. The normalized clearance is durably persisted in `titan_shield_assurance_clearances` and mirrored into an integration receipt. Shield does not inherit Assurance authority and still does not execute external business mutations.
