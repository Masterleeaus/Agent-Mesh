<?php

declare(strict_types=1);

return [
    'enabled' => true,

    // Queue execution is intentionally disabled until Shield ships a real,
    // tenant-restoring job implementation.
    'queue' => [
        'enabled' => false,
        'name' => 'titan-shield',
    ],

    'deterministic_rules' => [
        'allow_arbitrary_code' => false,
        'allow_filesystem_paths' => false,
        'ai_vision_enabled' => false,
    ],

    'authority_constraints' => [
        'source' => 'titan-shield',
        'medium_ceiling_score' => 50,
        'high_disposition' => 'REQUIRE_APPROVAL',
        'critical_disposition' => 'HOLD',
        'can_raise_authority' => false,
    ],

    'integrations' => [
        'direct_business_mutation' => false,
        'council_is_default_medium_path' => false,
        'critical_human_review_required' => true,
    ],

    'context' => [
        'tenant_key' => 'company_id',
        'trace_key' => 'trace_id',
        'correlation_key' => 'correlation_id',
        'causation_key' => 'causation_id',
        'fail_closed' => true,
    ],

    // These route shells are read-only. Consequential Shield capabilities must
    // apply capability/policy authorization in their own boundary when added.
    'routes' => [
        'user_middleware' => ['web', 'auth'],
        'admin_middleware' => ['web', 'auth', 'admin'],
    ],
];
