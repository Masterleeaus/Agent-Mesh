@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-6">
    <div class="mb-6">
        <h1 class="mb-2">Titan Shield</h1>
        <p class="text-muted mb-0">Governed quality, inspection, safety and compliance verification.</p>
    </div>

    <div class="row g-4">
        @foreach ([
            ['Inspection Engine', 'Versioned deterministic inspections with immutable evidence provenance.'],
            ['Findings', 'Structured INFO–CRITICAL findings with governed responses.'],
            ['Reinspection', 'Single-finding closure pinned to the original definition identity.'],
            ['Assurance', 'HIGH/CRITICAL closure requires independent Assurance clearance.'],
            ['Knowledge Authority', 'Rules bind to exact authority version/hash and jurisdiction.'],
            ['Remediation', 'Shield prepares requests; authoritative mutation remains outside Shield.'],
        ] as [$title, $description])
            <div class="col-12 col-md-6 col-xl-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">{{ $title }}</h5>
                        <p class="card-text text-muted mb-0">{{ $description }}</p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
