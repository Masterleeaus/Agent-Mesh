@extends('panel.layout.app')

@section('content')
<div class="container-fluid py-6">
    <div class="mb-6">
        <h1 class="mb-2">Titan Shield — Administration</h1>
        <p class="text-muted mb-0">Production governance, certification and policy status.</p>
    </div>

    <div class="row g-4">
        @foreach ([
            ['Direct business mutation', 'Disabled', 'Consequential external writes must use the owning governed execution path.'],
            ['AI Vision closure authority', 'Disabled', 'Model observations cannot independently close safety-critical findings.'],
            ['Queue execution', 'Disabled', 'No queue is advertised until tenant-restoring jobs are implemented.'],
            ['HIGH/CRITICAL closure', 'Assurance required', 'Exact PASS plus normalized independent Assurance ALLOW is mandatory.'],
            ['Knowledge resolution', 'Fail closed', 'Pinned authority is explicit; live resolution requires a public Knowledge Authority resolver.'],
            ['Host certification', 'Available', 'Run titan:titan-shield:certify for non-destructive host evidence.'],
        ] as [$title, $status, $description])
            <div class="col-12 col-md-6 col-xl-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">{{ $title }}</h5>
                        <div class="fw-semibold mb-2">{{ $status }}</div>
                        <p class="card-text text-muted mb-0">{{ $description }}</p>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
