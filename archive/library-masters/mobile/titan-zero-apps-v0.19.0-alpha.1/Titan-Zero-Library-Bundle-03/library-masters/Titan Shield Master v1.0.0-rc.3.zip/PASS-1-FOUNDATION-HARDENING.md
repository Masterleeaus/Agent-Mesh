# Titan Shield v0.2.0 — Pass 1 Foundation Hardening

## Completed

- Manifest capability truthfulness: removed unimplemented `shield.inspect`, `shield.verify`, `shield.remediate`, and `shield.compliance` claims.
- Queue truthfulness: `queues.used=false` until a real worker exists.
- Added a canonical execution context requiring `company_id`, `trace_id`, `correlation_id`, and `causation_id`.
- Added explicit capability metadata for `shield.health` including schemas, low risk, read-only idempotency and no approval requirement.
- Added forward migration `000002` for causation, actor and source provenance without rewriting the v0.1 migration.
- Made routes configurable while retaining existing MagicAI middleware defaults.
- Preserved shared `extension` publish tag and idempotent uninstall behavior.
- Replaced placeholder tests with executable architecture, packaging and unit contract tests.

## Intentionally not implemented yet

- inspection/evidence/findings domain
- Titan Signal/Risk/Assurance/Knowledge/Rewind/Command Bus adapters
- queue workers
- AI/Vision execution
- remediation mutations
- compliance rule packs

Those belong to later passes and therefore are not declared as live capabilities in v0.2.0.
