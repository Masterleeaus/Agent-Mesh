# Titan Shield v1.0.0-rc.2 — Deep-Scan Remediation Hotfix

This post-plan hotfix remediates confirmed defects found after the eight-pass production-candidate audit.

## Fixed

- Required `evidence_requirements` are now enforced before a PASS can be issued. Missing mandatory evidence produces `INCONCLUSIVE`.
- HIGH/CRITICAL reinspection Assurance receives the exact definition evidence requirements, Knowledge Authority references, vertical and jurisdiction.
- Reinspection, Assurance clearance, Knowledge binding and remediation intent persistence reject divergent retries instead of silently accepting `insertOrIgnore()` conflicts.
- `assurance_evidence` capability metadata is attached to `shield.reinspection.evaluate`, not initial inspection evaluation.
- Stale host PHPUnit expectations from v0.5.0 are advanced to the current RC contract.
- Evidence capture can durably persist the immutable evidence manifest through `ShieldRuntimeStoreContract`.
- Inspection-definition registration can durably persist immutable definition/version/hash records when trusted execution context is supplied.
- Definition persistence receives root-causation lineage through additive migration `000010`.

## Intentionally not fabricated

Route permission enforcement remains a live-host integration gate because the package cannot safely assume which host permission/Gate provider owns `shield.view` and `shield.admin`. Existing `auth` / `admin` middleware remains intact. No unverified permission middleware was invented in this hotfix.

The legacy `titan_shield_inspections` scaffold table remains retained/no-new-writes for upgrade safety. It is not reactivated as a canonical runtime table.
