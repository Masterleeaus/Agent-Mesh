# Titan Shield v0.8.0 — Pass 7: Knowledge Authority Binding

Pass 7 adds fail-closed authority binding for inspection definitions without crossing Titan Knowledge Authority ownership boundaries.

## Implemented
- Enriched `KnowledgeReference` with authority domain, jurisdiction, vertical applicability, required/optional semantics and `require_live_resolution`.
- `KnowledgeBindingPolicy` with explicit `LIVE`, `PINNED` and `NONE` binding modes.
- Exact version + SHA-256 pin enforcement.
- Jurisdiction and vertical mismatch rejection.
- Future public `knowledge.resolve` compatibility without importing Knowledge Authority internal catalog/repository contracts.
- `KnowledgeBindingReceipt` and durable `titan_shield_knowledge_bindings` persistence.
- Inspection runtime preflight before deterministic rules.
- Required unresolved/live-required authority produces `INCONCLUSIVE` + `awaiting_review` and no fabricated findings.
- Optional unresolved authority is recorded without blocking.
- `jurisdiction` added to inspection and reinspection public inputs.

## Peer contract boundary
The latest inspected Titan Knowledge Authority v0.4.0 intentionally keeps `knowledge.resolve`, authority precedence and public applicability APIs disabled. Shield therefore treats an exact package reference as `PINNED`, never `LIVE`. `LIVE` is used only when a future public resolver returns an exact version/hash compatible with any configured pin.

## Security/authority rule
Shield owns the inspection decision and its binding receipt. Titan Knowledge Authority owns authoritative content, scope, precedence, freshness, contradictions and applicability. Shield stores no authoritative source content and never calls Knowledge Authority internal repositories.
