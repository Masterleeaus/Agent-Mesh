# Pass 5 — Reinspection & Finding Closure

## Goal

Complete the Shield-owned lifecycle from an existing finding through a single-finding reinspection to a deterministic, traceable closure decision without taking over Risk, Assurance, Knowledge Authority or Command Bus responsibilities.

## Implemented

- `ReinspectionRequest` pins the original inspection definition key, semantic version and content hash.
- `ReinspectionClosurePolicy` requires exact tenant/subject/definition continuity and an exact `PASS` outcome.
- `ReinspectionService` prepares and completes a reinspection without mutating foreign business state.
- `ReinspectionCoordinator` reuses the deterministic inspection runtime, persists the reinspection, applies the Shield finding lifecycle and records Signal/Rewind-compatible receipts.
- `FindingLifecycleStatus` defines the Shield-owned lifecycle states.
- `DatabaseShieldRuntimeStore::applyFindingLifecycle()` performs tenant-scoped `lockForUpdate()` closure transitions and writes append-only transition evidence.
- New durable tables: `titan_shield_reinspections` and `titan_shield_finding_transitions`.
- Existing findings receive additive closure linkage: `closed_at`, `closure_reinspection_id`, `closure_run_id`.
- New public capability: `shield.reinspection.evaluate`.
- New Signal schemas: `shield.reinspection.completed`, `shield.finding.closed`, `shield.finding.closure_held`.

## Closure policy

- INFO / LOW / MEDIUM: exact-definition `PASS` may close the finding.
- HIGH / CRITICAL: exact-definition `PASS` is necessary but not sufficient; closure remains `HELD` until independent Assurance clearance is available through a stable public contract.
- `CONDITIONAL_PASS`, `FAIL`, `INCONCLUSIVE`: finding remains remediation-required.
- Definition drift, tenant drift or subject drift: fail closed / held for review.
- Closed findings cannot be silently reopened by this lifecycle.

## Deliberate exclusions

- no bulk reinspection
- no direct CRM/job mutation
- no fabricated Command Bus dispatch/execute call
- no fabricated Knowledge Authority resolution
- no AI Vision requirement for closure
- no HIGH/CRITICAL auto-clear based on Shield alone

## Verification target

The release must pass all standalone Shield regression tests, PHP/JSON validation, migration checks, Blueprint v4.2.0 canonical manifest/production gates and exact-ZIP Installer 1.7.8 integrity verification before the pass is certified.
