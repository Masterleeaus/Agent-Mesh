<?php

declare(strict_types=1);

namespace Tests\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_required_extension_files_and_manifest_contract_are_packaged(): void
    {
        $root = dirname(__DIR__, 2);

        foreach ([
            'extension.json',
            'extension.manifest.json',
            'System/TitanShieldServiceProvider.php',
            'System/Contracts/ShieldManagerContract.php',
            'System/Context/ShieldExecutionContext.php',
            'config/titan-shield.php',
            'routes/user.php',
            'routes/admin.php',
        ] as $relative) {
            self::assertFileExists($root . '/' . $relative);
        }

        $legacy = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
        $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

        self::assertSame('1.0.0-rc.2', $legacy['version']);
        self::assertSame($legacy['version'], $manifest['version']);
        self::assertSame('titan-shield', $manifest['key']);
        self::assertSame('App\\Extensions\\TitanShield\\System\\TitanShieldServiceProvider', $manifest['provider']);
        self::assertSame('company_id', $manifest['data']['tenant_key']);
        self::assertTrue($manifest['lifecycle']['register_key']);
        self::assertTrue($manifest['lifecycle']['uninstall']);
        self::assertTrue($manifest['lifecycle']['idempotent']);
    }

    public function test_provider_keeps_magicai_registration_and_extension_publish_contract(): void
    {
        $root = dirname(__DIR__, 2);
        $provider = (string) file_get_contents($root . '/System/TitanShieldServiceProvider.php');

        self::assertStringContainsString("return 'titan-shield';", $provider);
        self::assertStringContainsString("], 'titan-shield-config');", $provider);
        self::assertStringContainsString('UninstallExtensionServiceProviderInterface', $provider);
    }
}
