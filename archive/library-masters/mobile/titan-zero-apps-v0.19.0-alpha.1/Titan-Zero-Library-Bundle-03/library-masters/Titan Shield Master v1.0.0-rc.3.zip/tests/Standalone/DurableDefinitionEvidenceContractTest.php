<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$contract = (string) file_get_contents($root . '/System/Contracts/ShieldRuntimeStoreContract.php');
$store = (string) file_get_contents($root . '/System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php');
$evidence = (string) file_get_contents($root . '/System/Services/EvidenceCaptureService.php');
$registry = (string) file_get_contents($root . '/System/Services/InspectionDefinitionRegistry.php');
shield_assert(str_contains($contract, 'recordDefinition'), 'Store contract must support durable definition registration.');
shield_assert(str_contains($contract, 'recordEvidence'), 'Store contract must support durable evidence manifests.');
shield_assert(str_contains($store, 'titan_shield_inspection_definitions'), 'Runtime store must persist definitions.');
shield_assert(str_contains($store, 'titan_shield_evidence'), 'Runtime store must persist evidence manifests.');
shield_assert(str_contains($evidence, 'recordEvidence($manifest)'), 'Evidence capture must persist the immutable manifest when a runtime store is wired.');
shield_assert(str_contains($registry, 'recordDefinition($definition, $context)'), 'Definition registry must support durable registration when trusted context is supplied.');
shield_assert(is_file($root . '/database/migrations/2026_08_21_000010_add_root_causation_to_titan_shield_definitions_table.php'), 'Durable definitions must carry root causation lineage.');

echo "DurableDefinitionEvidenceContractTest PASS\n";
