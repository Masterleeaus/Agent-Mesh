<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$feature = (string) file_get_contents($root . '/tests/Feature/ExtensionBootTest.php');
$unit = (string) file_get_contents($root . '/tests/Unit/ScaffoldContractTest.php');
shield_assert(str_contains($feature, "1.0.0-rc.2"), 'Host Feature test must pin the current RC version.');
shield_assert(str_contains($unit, "production-candidate"), 'Host Unit test must pin the current health status.');
shield_assert(str_contains($unit, "1.0.0-rc.2"), 'Host Unit test must pin the current RC version.');
shield_assert(! str_contains($feature, "assertSame('0.5.0'"), 'Stale v0.5.0 Feature assertion must not remain.');
shield_assert(! str_contains($unit, "assertSame('0.5.0'"), 'Stale v0.5.0 Unit assertion must not remain.');

echo "HostTestDriftRegressionTest PASS\n";
