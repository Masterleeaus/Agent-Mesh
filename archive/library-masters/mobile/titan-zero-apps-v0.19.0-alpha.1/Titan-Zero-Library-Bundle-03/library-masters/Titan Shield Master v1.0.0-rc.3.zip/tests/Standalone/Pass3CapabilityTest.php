<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Capabilities\ShieldCapabilityRegistry;

$registry = new ShieldCapabilityRegistry();
$capabilities = array_keys($registry->all());
foreach (['shield.inspection.evaluate', 'shield.review.determine', 'shield.remediation.prepare'] as $expected) {
    shield_assert(in_array($expected, $capabilities, true), 'Missing Pass 3 capability: ' . $expected);
}
shield_assert(! in_array('shield.remediation.execute', $capabilities, true), 'Shield must not claim direct remediation execution authority.');
$inspection = $registry->find('shield.inspection.evaluate')->toArray();
shield_assert(in_array('run', $inspection['output_schema']['required'], true), 'Inspection capability output must expose the durable run envelope.');
shield_assert(in_array('authority', $inspection['output_schema']['required'], true), 'Inspection capability output must expose the authority boundary.');
shield_assert_same(true, $inspection['mutation'], 'Inspection evaluation is a Shield-owned persistence mutation.');

echo "Pass3CapabilityTest PASS\n";
