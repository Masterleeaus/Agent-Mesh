<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRunStatus;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;

$definition = InspectionDefinition::fromArray(json_decode(
    file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'),
    true,
    512,
    JSON_THROW_ON_ERROR,
));

$context = new ShieldExecutionContext(
    companyId: 42,
    traceId: '11111111-1111-4111-8111-111111111111',
    correlationId: '22222222-2222-4222-8222-222222222222',
    causationId: '33333333-3333-4333-8333-333333333333',
    actorUserId: 7,
    source: 'titan-go',
);

$run = (new InspectionRunEvaluator(new DeterministicRuleEngine()))->evaluate(
    runId: '44444444-4444-4444-8444-444444444444',
    definition: $definition,
    subjectType: 'job',
    subjectId: 'job-123',
    facts: [
        'evidence' => [
            'completion_photo' => [[
                'size_bytes' => 5000,
                'mime_type' => 'image/jpeg',
                'metadata' => [],
                'evidence_id' => 'ev-1',
            ]],
        ],
    ],
    context: $context,
    startedAt: '2026-08-11T23:00:00+10:00',
    completedAt: '2026-08-11T23:00:01+10:00',
);

shield_assert_same(InspectionRunStatus::Completed, $run->status, 'Run should complete deterministically.');
shield_assert_same(InspectionOutcome::ConditionalPass, $run->outcome, 'Low-severity required failure should use the definition conditional-pass policy.');
shield_assert_same(3, count($run->itemResults), 'Each definition rule must have one durable item result.');
shield_assert_same('completion-photo-min-size', $run->failedItems()[0]->ruleKey, 'Expected min-size rule to fail.');
shield_assert_same(['ev-1'], $run->failedItems()[0]->evidenceIds, 'Failed result should retain evidence linkage.');
shield_assert_same($definition->definitionHash(), $run->definitionHash, 'Run must pin exact definition hash.');
shield_assert_same(42, $run->context->companyId, 'Run must retain tenant execution context.');

echo "InspectionRunLifecycleTest PASS\n";
