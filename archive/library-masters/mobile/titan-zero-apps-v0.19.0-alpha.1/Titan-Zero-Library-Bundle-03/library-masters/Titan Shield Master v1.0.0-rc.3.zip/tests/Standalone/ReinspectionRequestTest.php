<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Services\ReinspectionService;

$definitionPayload = json_decode(file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, 512, JSON_THROW_ON_ERROR);
$definition = InspectionDefinition::fromArray($definitionPayload);
$context = new ShieldExecutionContext(
    42,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    7,
    'titan-go',
    '44444444-4444-4444-8444-444444444444',
);
$finding = new Finding(
    'finding-1',
    $definition->key(),
    $definition->version(),
    $definition->definitionHash(),
    'completion-photo-min-size',
    FindingSeverity::Medium,
    InspectionOutcome::ConditionalPass,
    'job',
    'job-123',
    ['ev-1'],
    ['RULE_FAILED'],
    $context,
);

$service = new ReinspectionService();
$request = $service->prepare('reinspect-1', 'run-original-1', $finding, $definition);
shield_assert_same('reinspect-1', $request->reinspectionId, 'Reinspection ID must be preserved.');
shield_assert_same('finding-1', $request->findingId, 'Reinspection must link exactly one finding.');
shield_assert_same($definition->definitionHash(), $request->definitionHash, 'Reinspection must pin original definition hash.');
shield_assert_same('REQUESTED', $request->status, 'New reinspection must start REQUESTED.');

$modified = $definitionPayload;
$modified['version'] = '1.0.1';
$modifiedDefinition = InspectionDefinition::fromArray($modified);
shield_expect_exception(
    static fn () => $service->prepare('reinspect-2', 'run-original-1', $finding, $modifiedDefinition),
    LogicException::class,
    'A changed definition must not be accepted as a closure reinspection for the original finding.',
);

echo "ReinspectionRequestTest PASS\n";
