<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
require_once $root.'/System/Workforce/CircuitBreaker.php';
use App\Extensions\TitanShield\System\Workforce\CircuitBreaker;
use App\Extensions\TitanShield\System\Workforce\CommandBusAdapter;
$c=new CircuitBreaker(2,10);
if(!$c->allow(100)) exit(1); $c->failure(100); if(!$c->allow(101)) exit(2); $c->failure(102); if($c->allow(103)) exit(3); if(!$c->allow(112)) exit(4);
$j=json_decode(file_get_contents($root.'/resources/workforce/workforce-integration.json'),true,512,JSON_THROW_ON_ERROR);
if(($j['schema_version']??null)!=='1.2') exit(5); if(($j['live_execution_runtime']['protocol']??null)!=='titan.workforce-live-execution-runtime.v2') exit(6); if(($j['tenancy']['canonical_context_key']??null)!=='company_id') exit(7);
if(($j['live_execution_runtime']['mutation_adapter_state']??null)!=='host_adapter_required') exit(8);
echo "PASS5_DURABLE_EXECUTION_RUNTIME: PASS\n";
