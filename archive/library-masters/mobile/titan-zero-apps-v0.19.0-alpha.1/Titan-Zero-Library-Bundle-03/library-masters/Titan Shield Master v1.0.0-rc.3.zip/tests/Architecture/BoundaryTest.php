<?php

declare(strict_types=1);

namespace Tests\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RegexIterator;

final class BoundaryTest extends TestCase
{
    public function test_system_code_does_not_import_other_extension_internals_or_use_unsafe_execution_primitives(): void
    {
        $root = dirname(__DIR__, 2);
        $iterator = new RegexIterator(
            new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/System')),
            '/\.php$/i'
        );

        $forbidden = [
            '/use\s+App\\\\Extensions\\\\(?!TitanShield\\\\)/',
            '/\\bDB::/',
            '/\\bHttp::/',
            '/\\beval\s*\(/i',
            '/\\bunserialize\s*\(/i',
            '/\\bshell_exec\s*\(/i',
            '/\\bexec\s*\(/i',
            '/\\bsystem\s*\(/i',
            '/\\bpassthru\s*\(/i',
        ];

        $violations = [];

        foreach ($iterator as $file) {
            $contents = file_get_contents($file->getPathname());
            self::assertIsString($contents);

            foreach ($forbidden as $pattern) {
                if (preg_match($pattern, $contents) === 1) {
                    $violations[] = $file->getPathname() . ' matched ' . $pattern;
                }
            }
        }

        self::assertSame([], $violations, implode(PHP_EOL, $violations));
    }

    public function test_manifest_does_not_claim_unimplemented_mutation_capabilities_or_queue_workers(): void
    {
        $root = dirname(__DIR__, 2);
        $manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

        self::assertSame(['shield.health', 'shield.definition.validate', 'shield.rule.evaluate', 'shield.governance.response'], $manifest['capabilities']);
        self::assertFalse($manifest['queues']['used']);
        self::assertSame([], $manifest['queues']['queue_names']);
    }
}
