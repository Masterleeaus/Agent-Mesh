<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;
use App\Extensions\TitanShield\System\Services\InspectionRuntimeCoordinator;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;

final class FakeShieldRuntimeStore implements ShieldRuntimeStoreContract
{
    public function recordDefinition(\App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition $definition, ShieldExecutionContext $context): void {}
    public function recordEvidence(\App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest $manifest): void {}

    public array $runs = [];
    public array $findings = [];
    public array $reviews = [];
    public array $remediations = [];
    public array $receipts = [];

    public function recordRun(InspectionRun $run): void { $this->runs[] = $run; }
    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void { $this->findings[] = [$finding, $governanceResponse]; }
    public function recordReview(HumanReviewRequest $review): void { $this->reviews[] = $review; }
    public function recordRemediationIntent(RemediationIntent $intent): void { $this->remediations[] = $intent; }
    public function recordReinspection(ReinspectionRecord $reinspection): void {}
    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void {}
    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void {}
    public function applyFindingLifecycle(string $findingId, FindingLifecycleStatus $targetStatus, array $reasonCodes, ShieldExecutionContext $context, ?string $reinspectionId = null, ?string $reinspectionRunId = null): void {}
    public function recordIntegrationReceipt(array $receipt): void { $this->receipts[] = $receipt; }
}

$definition = InspectionDefinition::fromArray(json_decode(
    file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'),
    true,
    512,
    JSON_THROW_ON_ERROR,
));
$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'titan-go');
$store = new FakeShieldRuntimeStore();
$coordinator = new InspectionRuntimeCoordinator(
    new InspectionRunEvaluator(new DeterministicRuleEngine()),
    $store,
    new GovernanceResponseResolver(),
    new HumanReviewWorkflow(),
    new RemediationIntentFactory(),
    new RewindReceiptFactory(),
    new SignalEngineAdapter(),
    new RiskEngineAdapter(),
    new AssuranceEngineAdapter(),
);

$result = $coordinator->execute(
    runId: '55555555-5555-4555-8555-555555555555',
    definition: $definition,
    subjectType: 'job',
    subjectId: 'job-200',
    facts: ['evidence' => ['completion_photo' => [[
        'evidence_id' => 'ev-runtime-1',
        'size_bytes' => 100,
        'mime_type' => 'text/plain',
        'metadata' => [],
    ]]]],
    context: $context,
    startedAt: '2026-08-11T23:45:00+10:00',
    completedAt: '2026-08-11T23:45:01+10:00',
);

shield_assert_same(1, count($store->runs), 'Coordinator must durably record the inspection run once.');
shield_assert(count($store->findings) >= 1, 'Failed required rules must produce durable findings.');
shield_assert(count($store->remediations) >= 1, 'Medium failed findings must prepare remediation intents.');
shield_assert(count($store->receipts) >= 2, 'Coordinator must retain integration/Rewind receipts even when optional engines are unavailable.');
shield_assert_same(false, $store->remediations[0]->directMutation, 'Coordinator must never turn a remediation intent into direct domain mutation.');
shield_assert_same('conditional_pass', $result['run']['outcome'], 'Starter policy should produce conditional pass for medium-or-lower failures.');
shield_assert_same(false, $result['authority']['direct_business_mutation'], 'Runtime result must explicitly deny direct business mutation.');

echo "InspectionRuntimeCoordinatorTest PASS\n";
