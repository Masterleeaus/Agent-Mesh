<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceCaptureRequest;
use App\Extensions\TitanShield\System\Services\EvidenceCaptureService;

$tmp = tempnam(sys_get_temp_dir(), 'shield-evidence-');
if ($tmp === false) {
    throw new RuntimeException('Could not create temp evidence file.');
}
file_put_contents($tmp, str_repeat('evidence-', 200));

$context = new ShieldExecutionContext(
    companyId: 42,
    traceId: '018f1f52-71f2-7cc0-8c2b-f3e7070a1b21',
    correlationId: '018f1f52-71f2-7cc0-9c2b-f3e7070a1b22',
    causationId: '018f1f52-71f2-7cc0-ac2b-f3e7070a1b23',
    actorUserId: 7,
    source: 'titan-go',
);

$service = new EvidenceCaptureService();
$request = new EvidenceCaptureRequest(
    evidenceId: 'ev-001',
    evidenceKey: 'completion_photo',
    filePath: $tmp,
    originalFilename: 'completion.jpg',
    mimeType: 'image/jpeg',
    capturedAt: '2026-08-11T12:00:00+10:00',
    captureDeviceId: 'device-abc',
    storageReference: 'private://tenant-42/jobs/123/completion.jpg',
    metadata: ['gps' => '-37.81,144.96'],
);

$manifest = $service->capture($request, $context);
shield_assert((bool) preg_match('/^[a-f0-9]{64}$/', $manifest->sha256), 'Evidence SHA-256 must be present.');
shield_assert_same(filesize($tmp), $manifest->sizeBytes, 'Evidence size should be captured from original bytes.');
shield_assert($service->verify($manifest, $tmp), 'Original evidence should verify against the manifest.');

file_put_contents($tmp, 'tampered', FILE_APPEND);
shield_assert(! $service->verify($manifest, $tmp), 'Modified evidence must fail integrity verification.');

@unlink($tmp);
echo "EvidenceIntegrityTest PASS\n";
