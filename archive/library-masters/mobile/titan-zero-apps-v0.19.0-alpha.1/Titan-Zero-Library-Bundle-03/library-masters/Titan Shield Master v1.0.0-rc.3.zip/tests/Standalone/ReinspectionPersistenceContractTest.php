<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$contract = file_get_contents($root . '/System/Contracts/ShieldRuntimeStoreContract.php');
$store = file_get_contents($root . '/System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php');
$migration = $root . '/database/migrations/2026_08_19_000007_create_titan_shield_reinspection_lifecycle_tables.php';

shield_assert(str_contains($contract, 'recordReinspection'), 'Runtime store contract must expose reinspection persistence.');
shield_assert(str_contains($contract, 'applyFindingLifecycle'), 'Runtime store contract must expose finding lifecycle persistence.');
shield_assert(is_file($migration), 'Pass 5 must use a forward-only additive migration.');
$migrationSource = is_file($migration) ? file_get_contents($migration) : '';
shield_assert(str_contains($migrationSource, "titan_shield_reinspections"), 'Migration must create the reinspection table.');
shield_assert(str_contains($migrationSource, "titan_shield_finding_transitions"), 'Migration must create append-only finding transitions.');
shield_assert(str_contains($migrationSource, "closure_reinspection_id"), 'Findings must expose current closure linkage.');
shield_assert(str_contains($store, "lockForUpdate()"), 'Finding lifecycle updates must serialize concurrent transitions.');
shield_assert(str_contains($store, "titan_shield_reinspections"), 'Runtime store must persist reinspection records.');
shield_assert(str_contains($store, "titan_shield_finding_transitions"), 'Runtime store must persist append-only transitions.');

echo "ReinspectionPersistenceContractTest PASS\n";
