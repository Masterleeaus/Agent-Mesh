<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$provider = (string) file_get_contents(dirname(__DIR__, 2) . '/System/TitanShieldServiceProvider.php');
foreach ([
    'ShieldRuntimeStoreContract::class, DatabaseShieldRuntimeStore::class',
    'InspectionRunEvaluator::class',
    'InspectionRuntimeCoordinator::class',
    'HumanReviewWorkflow::class',
    'RemediationIntentFactory::class',
    'RewindReceiptFactory::class',
    'RiskEngineAdapter::class',
    'AssuranceEngineAdapter::class',
    'SignalEngineAdapter::class',
    'KnowledgeAuthorityAdapter::class',
    'KnowledgeBindingPolicy::class',
] as $binding) {
    shield_assert(str_contains($provider, $binding), 'Provider must bind governed runtime dependency: ' . $binding);
}
shield_assert(str_contains($provider, "], 'titan-shield-config');"), 'Published config must use an extension-owned scoped tag.');
shield_assert(! str_contains($provider, "], 'extension');"), 'Generic extension publish tag must not remain in v0.5.0.');

echo "ProviderBindingContractTest PASS\n";
