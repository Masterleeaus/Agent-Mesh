<?php

declare(strict_types=1);

namespace Tests\Support;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;

/**
 * Test-only fixture factory. It is intentionally outside System/ and is never
 * registered as a production capability or service provider binding.
 */
final class ForcedFindingFactory
{
    public static function fail(string $severity, ShieldExecutionContext $context): Finding
    {
        return new Finding(
            findingId: 'test-forced-' . $severity,
            definitionKey: 'test_definition',
            definitionVersion: '1.0.0',
            definitionHash: str_repeat('f', 64),
            code: 'test.forced_failure',
            severity: FindingSeverity::from($severity),
            outcome: InspectionOutcome::Fail,
            subjectType: 'test_subject',
            subjectId: 'test-1',
            evidenceIds: [],
            reasonCodes: ['test_fixture'],
            context: $context,
        );
    }
}
