<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\AssuranceClearancePortContract;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Services\AssuranceClearanceNormalizer;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;
use App\Extensions\TitanShield\System\Services\InspectionRuntimeCoordinator;
use App\Extensions\TitanShield\System\Services\ReinspectionClosurePolicy;
use App\Extensions\TitanShield\System\Services\ReinspectionCoordinator;
use App\Extensions\TitanShield\System\Services\ReinspectionService;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;

final class Pass6Store implements ShieldRuntimeStoreContract
{
    public function recordDefinition(\App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition $definition, ShieldExecutionContext $context): void {}
    public function recordEvidence(\App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest $manifest): void {}

    public array $transitions = [];
    public array $clearances = [];
    public array $receipts = [];
    public function recordRun(InspectionRun $run): void {}
    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void {}
    public function recordReview(HumanReviewRequest $review): void {}
    public function recordRemediationIntent(RemediationIntent $intent): void {}
    public function recordReinspection(ReinspectionRecord $reinspection): void {}
    public function recordIntegrationReceipt(array $receipt): void { $this->receipts[] = $receipt; }
    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void { $this->clearances[] = $clearance; }
    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void {}
    public function applyFindingLifecycle(string $findingId, FindingLifecycleStatus $targetStatus, array $reasonCodes, ShieldExecutionContext $context, ?string $reinspectionId = null, ?string $reinspectionRunId = null): void { $this->transitions[] = [$targetStatus, $reasonCodes]; }
}

final class GreenAssurancePort implements AssuranceClearancePortContract
{
    public function assess(Finding $finding, array $evidence = [], array $requirements = [], array $knowledgeReferences = [], ?string $vertical = null, ?string $jurisdiction = null): array
    {
        return [
            'status' => 'OK',
            'engine' => 'titan-assurance',
            'contract' => 'EvidenceAssuranceEngine',
            'result' => [
                'uuid' => 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
                'company_id' => (string) $finding->context->companyId,
                'subject' => ['type' => $finding->subjectType, 'id' => $finding->subjectId],
                'capability' => 'shield.finding.verify_assurance',
                'status' => 'GREEN',
                'score' => 95.0,
                'policy_version' => 'titan-assurance-v2.1',
                'evidence_used' => array_map(static fn (EvidenceManifest $item): array => ['evidence_id' => $item->evidenceId, 'hash' => $item->sha256], $evidence),
                'missing_evidence' => [],
                'stale_evidence' => [],
                'contradictory_evidence' => [],
                'reason_codes' => ['EVIDENCE_SUPPORTS_ACTION'],
            ],
        ];
    }
}

$definition = InspectionDefinition::fromArray(json_decode(file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, 512, JSON_THROW_ON_ERROR));
$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'titan-go', '44444444-4444-4444-8444-444444444444');
$finding = new Finding('finding-high', $definition->key(), $definition->version(), $definition->definitionHash(), 'completion-photo-min-size', FindingSeverity::High, InspectionOutcome::Fail, 'job', 'job-901', ['ev-new'], ['RULE_FAILED'], $context);
$evidence = new EvidenceManifest('ev-new', 'completion_photo', 'photo.jpg', 'image/jpeg', 20000, str_repeat('d', 64), '2026-08-20T22:10:00+10:00', 'device-1', 'private://shield/ev-new', [], $context);
$store = new Pass6Store();
$runtime = new InspectionRuntimeCoordinator(new InspectionRunEvaluator(new DeterministicRuleEngine()), $store, new GovernanceResponseResolver(), new HumanReviewWorkflow(), new RemediationIntentFactory(), new RewindReceiptFactory(), new SignalEngineAdapter(), new RiskEngineAdapter(), new AssuranceEngineAdapter());
$coordinator = new ReinspectionCoordinator($runtime, new ReinspectionService(new ReinspectionClosurePolicy()), $store, new SignalEngineAdapter(), new GreenAssurancePort(), new AssuranceClearanceNormalizer());

$result = $coordinator->execute('reinspect-high', 'run-original-high', 'run-reinspect-high', $finding, $definition, [
    'evidence' => ['completion_photo' => [['size_bytes' => 20000, 'mime_type' => 'image/jpeg', 'metadata' => [], 'evidence_id' => 'ev-new']]],
], $context, '2026-08-20T22:10:00+10:00', '2026-08-20T22:10:02+10:00', [$evidence]);

shield_assert_same('ALLOW', $result['assurance_clearance']['decision'], 'Independent GREEN exact-evidence assurance must clear a passed HIGH reinspection.');
shield_assert_same(FindingLifecycleStatus::Closed, $store->transitions[0][0], 'HIGH finding must close only after normalized Assurance ALLOW.');
shield_assert_same(1, count($store->clearances), 'Assurance clearance must be persisted once.');
shield_assert_same('closed', $result['closure_decision']['target_status'], 'Final closure decision must reflect Assurance-approved closure.');

echo "HighSeverityAssuranceClosureTest PASS\n";
