<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\KnowledgeAuthorityAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;

$context = new ShieldExecutionContext(1, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', null, 'test', '44444444-4444-4444-8444-444444444444');
$finding = new Finding('finding-1', 'def', '1.0.0', str_repeat('a', 64), 'CODE', FindingSeverity::High, InspectionOutcome::Fail, 'job', 'job-1', [], ['TEST'], $context);

$risk = (new RiskEngineAdapter())->assess($finding);
shield_assert_same('UNAVAILABLE', $risk['status'], 'Risk adapter must fail closed without Laravel peer container.');

$assurance = (new AssuranceEngineAdapter())->assess($finding);
shield_assert_same('UNAVAILABLE', $assurance['status'], 'Assurance adapter must fail closed without Laravel peer container.');

$signal = (new SignalEngineAdapter())->emit(['event_type' => 'shield.test']);
shield_assert_same('UNAVAILABLE', $signal['status'], 'Signal adapter must return durable failure semantics when peer unavailable.');

$knowledge = (new KnowledgeAuthorityAdapter())->resolve(['knowledge_key' => 'test.ref']);
shield_assert_same('UNRESOLVED', $knowledge->status, 'Knowledge adapter must fail closed without public resolver.');

echo "PeerFailureMatrixTest PASS\n";
