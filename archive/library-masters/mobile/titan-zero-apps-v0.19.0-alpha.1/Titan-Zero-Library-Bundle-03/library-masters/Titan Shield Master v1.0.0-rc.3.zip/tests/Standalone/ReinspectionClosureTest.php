<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRunStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Services\ReinspectionClosurePolicy;

$context = new ShieldExecutionContext(
    companyId: 42,
    traceId: '11111111-1111-4111-8111-111111111111',
    correlationId: '22222222-2222-4222-8222-222222222222',
    causationId: '33333333-3333-4333-8333-333333333333',
    actorUserId: 7,
    source: 'titan-go',
    rootCausationId: '44444444-4444-4444-8444-444444444444',
);

$finding = new Finding(
    findingId: 'finding-1',
    definitionKey: 'job-completion',
    definitionVersion: '1.0.0',
    definitionHash: str_repeat('a', 64),
    code: 'completion-photo',
    severity: FindingSeverity::Medium,
    outcome: InspectionOutcome::Fail,
    subjectType: 'job',
    subjectId: 'job-10',
    evidenceIds: ['ev-1'],
    reasonCodes: ['PHOTO_FAILED'],
    context: $context,
);

$passingRun = new InspectionRun(
    runId: 're-run-1',
    definitionKey: 'job-completion',
    definitionVersion: '1.0.0',
    definitionHash: str_repeat('a', 64),
    subjectType: 'job',
    subjectId: 'job-10',
    status: InspectionRunStatus::Completed,
    outcome: InspectionOutcome::Pass,
    itemResults: [],
    startedAt: '2026-08-19T00:00:00+10:00',
    completedAt: '2026-08-19T00:00:02+10:00',
    context: $context,
);

$policy = new ReinspectionClosurePolicy();
$decision = $policy->evaluate($finding, $passingRun);
shield_assert($decision->mayClose, 'MEDIUM finding should close after exact-definition PASS reinspection.');
shield_assert_same(FindingLifecycleStatus::Closed, $decision->targetStatus, 'Successful closure should target CLOSED.');

$wrongDefinitionRun = new InspectionRun(
    runId: 're-run-2',
    definitionKey: 'job-completion',
    definitionVersion: '1.0.1',
    definitionHash: str_repeat('b', 64),
    subjectType: 'job',
    subjectId: 'job-10',
    status: InspectionRunStatus::Completed,
    outcome: InspectionOutcome::Pass,
    itemResults: [],
    startedAt: '2026-08-19T00:01:00+10:00',
    completedAt: '2026-08-19T00:01:02+10:00',
    context: $context,
);
$wrong = $policy->evaluate($finding, $wrongDefinitionRun);
shield_assert_same(false, $wrong->mayClose, 'A different definition/version/hash must not close the original finding.');
shield_assert_same('REINSPECTION_DEFINITION_MISMATCH', $wrong->reasonCodes[0], 'Definition mismatch reason must be explicit.');

$conditionalRun = new InspectionRun(
    runId: 're-run-3',
    definitionKey: 'job-completion',
    definitionVersion: '1.0.0',
    definitionHash: str_repeat('a', 64),
    subjectType: 'job',
    subjectId: 'job-10',
    status: InspectionRunStatus::Completed,
    outcome: InspectionOutcome::ConditionalPass,
    itemResults: [],
    startedAt: '2026-08-19T00:02:00+10:00',
    completedAt: '2026-08-19T00:02:02+10:00',
    context: $context,
);
$conditional = $policy->evaluate($finding, $conditionalRun);
shield_assert_same(false, $conditional->mayClose, 'CONDITIONAL_PASS must not close a prior finding.');
shield_assert_same(FindingLifecycleStatus::RemediationRequired, $conditional->targetStatus, 'Conditional reinspection remains remediation-required.');

$criticalFinding = new Finding(
    findingId: 'finding-critical',
    definitionKey: 'job-completion',
    definitionVersion: '1.0.0',
    definitionHash: str_repeat('a', 64),
    code: 'safety',
    severity: FindingSeverity::Critical,
    outcome: InspectionOutcome::Fail,
    subjectType: 'job',
    subjectId: 'job-10',
    evidenceIds: ['ev-2'],
    reasonCodes: ['SAFETY_FAILURE'],
    context: $context,
);
$critical = $policy->evaluate($criticalFinding, $passingRun);
shield_assert_same(false, $critical->mayClose, 'CRITICAL finding must not auto-close without normalized Assurance clearance.');
shield_assert_same(FindingLifecycleStatus::Held, $critical->targetStatus, 'CRITICAL closure must remain held.');
shield_assert($critical->requiresAssurance, 'CRITICAL closure must require Assurance.');

echo "ReinspectionClosureTest PASS\n";
