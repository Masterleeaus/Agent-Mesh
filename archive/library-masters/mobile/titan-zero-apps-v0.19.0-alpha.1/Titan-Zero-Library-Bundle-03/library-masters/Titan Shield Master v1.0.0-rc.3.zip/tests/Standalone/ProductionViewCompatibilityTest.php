<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
foreach (['resources/views/index.blade.php', 'resources/views/admin.blade.php'] as $relative) {
    $view = (string) file_get_contents($root . '/' . $relative);
    shield_assert(str_contains($view, "@extends('panel.layout.app')"), $relative . ' must use the MagicAI panel layout.');
    shield_assert(! str_contains($view, '<x-layouts.app>'), $relative . ' must not require unavailable x-layouts.app.');
    shield_assert(! str_contains($view, 'v0.2.0'), $relative . ' must not ship stale foundation copy.');
}

echo "ProductionViewCompatibilityTest PASS\n";
