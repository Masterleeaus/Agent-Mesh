<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Services\InspectionDefinitionRegistry;

$payload = [
    'definition_key' => 'field_job_completion_basic',
    'version' => '1.0.0',
    'name' => 'Basic Job Completion',
    'description' => 'Deterministic evidence checks for basic field job completion.',
    'vertical_key' => 'field-home-services',
    'inspection_type' => 'quality',
    'scope' => 'tenant',
    'status' => 'active',
    'rules' => [
        [
            'rule_key' => 'photo-present',
            'rule_type' => 'evidence_present',
            'parameters' => ['evidence_key' => 'completion_photo'],
            'required' => true,
            'failure_severity' => 'medium',
        ],
    ],
    'evidence_requirements' => [
        ['evidence_key' => 'completion_photo', 'type' => 'photo', 'required' => true],
    ],
    'pass_policy' => ['mode' => 'all_required_rules_pass'],
    'conditional_pass_policy' => ['allowed' => true, 'max_severity' => 'medium'],
    'review_policy' => ['human_review_at_or_above' => 'high'],
    'remediation_policy' => ['mode' => 'request_only'],
    'knowledge_references' => [],
    'source_pack' => 'field-home-services/basic-job-completion',
    'effective_from' => '2026-08-11T00:00:00+10:00',
    'supersedes_version' => null,
];

$definition = InspectionDefinition::fromArray($payload);
shield_assert_same('field_job_completion_basic', $definition->key(), 'Definition key should round-trip.');
shield_assert_same('1.0.0', $definition->version(), 'Definition version should round-trip.');
shield_assert((bool) preg_match('/^[a-f0-9]{64}$/', $definition->definitionHash()), 'Definition hash must be SHA-256 hex.');

$registry = new InspectionDefinitionRegistry();
$registry->register($definition);
$registry->register(InspectionDefinition::fromArray($payload));
shield_assert_same($definition->definitionHash(), $registry->find('field_job_completion_basic', '1.0.0')?->definitionHash(), 'Idempotent re-registration should be accepted.');

$mutated = $payload;
$mutated['description'] = 'Changed meaning under the same version.';
shield_expect_exception(
    static fn () => $registry->register(InspectionDefinition::fromArray($mutated)),
    \LogicException::class,
    'Same key/version with different content must fail closed.'
);

$badVersion = $payload;
$badVersion['version'] = 'v1';
shield_expect_exception(
    static fn () => InspectionDefinition::fromArray($badVersion),
    \InvalidArgumentException::class,
    'Definitions must use semantic versions.'
);

$badKnowledge = $payload;
$badKnowledge['rules'][0]['knowledge_reference'] = 'missing-authority-ref';
shield_expect_exception(
    static fn () => InspectionDefinition::fromArray($badKnowledge),
    \InvalidArgumentException::class,
    'Rules must not reference undeclared knowledge authority keys.'
);

echo "InspectionDefinitionTest PASS\n";
