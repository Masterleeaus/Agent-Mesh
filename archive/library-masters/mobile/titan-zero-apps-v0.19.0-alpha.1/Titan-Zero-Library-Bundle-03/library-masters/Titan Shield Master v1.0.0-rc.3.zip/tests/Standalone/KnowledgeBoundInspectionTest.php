<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\KnowledgeAuthorityAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;
use App\Extensions\TitanShield\System\Services\InspectionRuntimeCoordinator;
use App\Extensions\TitanShield\System\Services\KnowledgeBindingPolicy;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;

final class KnowledgeBindingStore implements ShieldRuntimeStoreContract
{
    public function recordDefinition(\App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition $definition, ShieldExecutionContext $context): void {}
    public function recordEvidence(\App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest $manifest): void {}

    public array $runs = [];
    public array $bindings = [];
    public function recordRun(InspectionRun $run): void { $this->runs[] = $run; }
    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void {}
    public function recordReview(HumanReviewRequest $review): void {}
    public function recordRemediationIntent(RemediationIntent $intent): void {}
    public function recordReinspection(ReinspectionRecord $reinspection): void {}
    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void {}
    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void { $this->bindings[] = $receipt; }
    public function applyFindingLifecycle(string $findingId, FindingLifecycleStatus $targetStatus, array $reasonCodes, ShieldExecutionContext $context, ?string $reinspectionId = null, ?string $reinspectionRunId = null): void {}
    public function recordIntegrationReceipt(array $receipt): void {}
}

$base = json_decode(file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, 512, JSON_THROW_ON_ERROR);
$base['knowledge_references'] = [[
    'knowledge_key' => 'au.vic.working-at-heights.anchor',
    'version' => '2026.08.1',
    'content_hash' => str_repeat('a', 64),
    'authority_domain' => 'regulatory-safety',
    'jurisdiction' => 'AU-VIC',
    'vertical_key' => 'field-home-services',
    'required' => true,
    'require_live_resolution' => false,
]];
$pinnedDefinition = InspectionDefinition::fromArray($base);
$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'titan-go');
$store = new KnowledgeBindingStore();
$coordinator = new InspectionRuntimeCoordinator(
    new InspectionRunEvaluator(new DeterministicRuleEngine()),
    $store,
    new GovernanceResponseResolver(),
    new HumanReviewWorkflow(),
    new RemediationIntentFactory(),
    new RewindReceiptFactory(),
    new SignalEngineAdapter(),
    new RiskEngineAdapter(),
    new AssuranceEngineAdapter(),
    new KnowledgeAuthorityAdapter(),
    new KnowledgeBindingPolicy(),
);

$pinned = $coordinator->execute(
    runId: 'run-pinned-1',
    definition: $pinnedDefinition,
    subjectType: 'job',
    subjectId: 'job-1',
    facts: ['evidence' => ['completion_photo' => [[
        'evidence_id' => 'ev-kb-1', 'size_bytes' => 100, 'mime_type' => 'text/plain', 'metadata' => [],
    ]]]],
    context: $context,
    jurisdiction: 'AU-VIC',
);
shield_assert_same('conditional_pass', $pinned['run']['outcome'], 'Valid pinned authority should allow deterministic inspection to run.');
shield_assert_same('PINNED', $pinned['knowledge_bindings'][0]['binding_mode'], 'Runtime must surface pinned authority mode.');
shield_assert_same(1, count($store->bindings), 'Runtime must durably record the authority binding.');

$liveRequired = $base;
$liveRequired['knowledge_references'][0]['require_live_resolution'] = true;
$blockedDefinition = InspectionDefinition::fromArray($liveRequired);
$blockedStore = new KnowledgeBindingStore();
$blockedCoordinator = new InspectionRuntimeCoordinator(
    new InspectionRunEvaluator(new DeterministicRuleEngine()),
    $blockedStore,
    new GovernanceResponseResolver(),
    new HumanReviewWorkflow(),
    new RemediationIntentFactory(),
    new RewindReceiptFactory(),
    new SignalEngineAdapter(),
    new RiskEngineAdapter(),
    new AssuranceEngineAdapter(),
    new KnowledgeAuthorityAdapter(),
    new KnowledgeBindingPolicy(),
);
$blocked = $blockedCoordinator->execute(
    runId: 'run-live-required-1',
    definition: $blockedDefinition,
    subjectType: 'job',
    subjectId: 'job-2',
    facts: ['evidence' => []],
    context: $context,
    jurisdiction: 'AU-VIC',
);
shield_assert_same('inconclusive', $blocked['run']['outcome'], 'Required unresolved live authority must block normal compliance conclusion.');
shield_assert_same('awaiting_review', $blocked['run']['status'], 'Authority-blocked inspection must remain awaiting review.');
shield_assert_same(true, $blocked['knowledge_bindings'][0]['blocking'], 'Blocked binding must be explicit.');
shield_assert_same('KNOWLEDGE_AUTHORITY_UNRESOLVED', $blocked['knowledge_bindings'][0]['reason_codes'][0], 'Authority block must use stable reason code.');
shield_assert_same(0, count($blocked['findings']), 'Authority-unresolved run must not fabricate deterministic findings.');

echo "KnowledgeBoundInspectionTest PASS\n";
