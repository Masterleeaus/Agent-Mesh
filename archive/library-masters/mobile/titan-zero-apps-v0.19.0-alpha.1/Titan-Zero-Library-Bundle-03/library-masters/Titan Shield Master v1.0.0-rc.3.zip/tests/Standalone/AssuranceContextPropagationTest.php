<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$source = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/ReinspectionCoordinator.php');
shield_assert(str_contains($source, '$definition->evidenceRequirements'), 'Reinspection Assurance must derive requirements from the exact inspection definition.');
shield_assert(str_contains($source, '$definition->knowledgeReferences'), 'Reinspection Assurance must derive Knowledge Authority references from the exact inspection definition.');
shield_assert(str_contains($source, 'jurisdiction: $jurisdiction'), 'Reinspection Assurance must receive the reinspection jurisdiction.');

echo "AssuranceContextPropagationTest PASS\n";
