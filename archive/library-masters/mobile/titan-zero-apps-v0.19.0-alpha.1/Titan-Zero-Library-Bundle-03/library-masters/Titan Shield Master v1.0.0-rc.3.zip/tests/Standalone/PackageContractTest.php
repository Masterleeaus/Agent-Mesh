<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
foreach ([
    'schemas/inspection-definition.schema.json',
    'schemas/shield-pack-selection.schema.json',
    'resources/inspection-packs/field-home-services/basic-job-completion.v1.json',
    'database/migrations/2026_08_11_000003_create_titan_shield_definition_and_evidence_tables.php',
    'database/migrations/2026_08_11_000004_create_titan_shield_findings_table.php',
    'database/migrations/2026_08_11_000005_create_titan_shield_inspection_runtime_tables.php',
    'database/migrations/2026_08_19_000007_create_titan_shield_reinspection_lifecycle_tables.php',
] as $relative) {
    shield_assert(is_file($root . '/' . $relative), 'Missing package contract file: ' . $relative);
}

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);
$expectedTables = [
    'titan_shield_inspections',
    'titan_shield_inspection_definitions',
    'titan_shield_evidence',
    'titan_shield_findings',
    'titan_shield_inspection_runs',
    'titan_shield_inspection_item_results',
    'titan_shield_human_reviews',
    'titan_shield_remediation_intents',
    'titan_shield_integration_receipts',
    'titan_shield_reinspections',
    'titan_shield_finding_transitions',
    'titan_shield_assurance_clearances',
    'titan_shield_knowledge_bindings',
];
foreach ($expectedTables as $table) {
    shield_assert(in_array($table, $manifest['database']['owned_tables'], true), 'Manifest must declare owned table ' . $table);
}
shield_assert_same('1.0.0-rc.2', $manifest['version'], 'Sidecar version must advance to 1.0.0-rc.2.');
foreach (['shield.inspection.evaluate', 'shield.review.determine', 'shield.authority.constraint', 'shield.remediation.prepare', 'shield.reinspection.evaluate'] as $capability) {
    shield_assert(in_array($capability, $manifest['capabilities'], true), 'Manifest must declare implemented capability ' . $capability);
}
shield_assert(! in_array('shield.remediation.execute', $manifest['capabilities'], true), 'Shield must not claim Command Bus execution authority.');

$pack = json_decode((string) file_get_contents($root . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, flags: JSON_THROW_ON_ERROR);
shield_assert_same('field_job_completion_basic', $pack['definition_key'], 'Seed pack key mismatch.');
shield_assert_same('1.0.0', $pack['version'], 'Seed pack version mismatch.');
shield_assert_same('global', $pack['scope'], 'Seed pack must be explicitly global rather than using a null tenant implicitly.');

echo "PackageContractTest PASS\n";
