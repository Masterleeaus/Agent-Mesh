<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionRule;
use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluationStatus;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;

$engine = new DeterministicRuleEngine();
$facts = [
    'evidence' => [
        'completion_photo' => [[
            'size_bytes' => 600000,
            'mime_type' => 'image/jpeg',
            'metadata' => ['gps' => '-37.81,144.96', 'timestamp' => '2026-08-11T12:00:00+10:00'],
        ]],
    ],
    'fields' => [
        'job_reference' => 'ABC-123',
        'temperature_c' => 22.5,
    ],
    'checklists' => [
        'finish' => ['floor' => true, 'bench' => true, 'sink' => false],
    ],
];

$cases = [
    ['evidence_present', ['evidence_key' => 'completion_photo'], RuleEvaluationStatus::Pass],
    ['min_file_size', ['evidence_key' => 'completion_photo', 'min_bytes' => 500000], RuleEvaluationStatus::Pass],
    ['min_file_size', ['evidence_key' => 'completion_photo', 'min_bytes' => 700000], RuleEvaluationStatus::Fail],
    ['mime_allowed', ['evidence_key' => 'completion_photo', 'allowed' => ['image/jpeg', 'image/png']], RuleEvaluationStatus::Pass],
    ['metadata_present', ['evidence_key' => 'completion_photo', 'keys' => ['gps', 'timestamp']], RuleEvaluationStatus::Pass],
    ['regex_match', ['field' => 'job_reference', 'pattern' => '^ABC-[0-9]+$'], RuleEvaluationStatus::Pass],
    ['numeric_compare', ['field' => 'temperature_c', 'operator' => '>=', 'value' => 20], RuleEvaluationStatus::Pass],
    ['checklist_all', ['checklist_key' => 'finish'], RuleEvaluationStatus::Fail],
    ['checklist_any', ['checklist_key' => 'finish'], RuleEvaluationStatus::Pass],
    ['checklist_minimum', ['checklist_key' => 'finish', 'minimum' => 2], RuleEvaluationStatus::Pass],
];

foreach ($cases as $index => [$type, $parameters, $expected]) {
    $rule = new InspectionRule(
        ruleKey: 'rule-' . $index,
        ruleType: $type,
        parameters: $parameters,
        required: true,
        failureSeverity: 'medium',
    );
    $result = $engine->evaluate($rule, $facts);
    shield_assert_same($expected, $result->status, 'Unexpected result for rule type ' . $type);
}

echo "RuleEngineTest PASS\n";
