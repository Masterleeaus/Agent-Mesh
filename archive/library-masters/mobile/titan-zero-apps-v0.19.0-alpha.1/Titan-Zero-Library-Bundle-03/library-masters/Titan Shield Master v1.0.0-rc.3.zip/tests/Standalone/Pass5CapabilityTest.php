<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$managerContract = file_get_contents($root . '/System/Contracts/ShieldManagerContract.php');
$manager = file_get_contents($root . '/System/Services/ShieldManager.php');
$registry = file_get_contents($root . '/System/Capabilities/ShieldCapabilityRegistry.php');
$provider = file_get_contents($root . '/System/TitanShieldServiceProvider.php');
$manifest = json_decode(file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

shield_assert(str_contains($managerContract, 'reinspectFinding'), 'Manager contract must expose governed single-finding reinspection.');
shield_assert(str_contains($manager, 'ReinspectionCoordinator'), 'ShieldManager must delegate reinspection to the dedicated coordinator.');
shield_assert(str_contains($provider, 'ReinspectionCoordinator::class'), 'Provider must bind the reinspection coordinator.');
shield_assert(str_contains($registry, "'shield.reinspection.evaluate'"), 'Capability registry must advertise reinspection only once implemented.');
shield_assert(in_array('shield.reinspection.evaluate', $manifest['capabilities'] ?? [], true), 'Manifest must truthfully advertise reinspection capability.');
shield_assert(is_file($root . '/schemas/capabilities/shield-reinspection-evaluate.input.json'), 'Capability input schema must exist.');
shield_assert(is_file($root . '/schemas/capabilities/shield-reinspection-evaluate.output.json'), 'Capability output schema must exist.');
foreach (['shield.reinspection.completed', 'shield.finding.closed', 'shield.finding.closure_held'] as $event) {
    shield_assert(is_file($root . '/schemas/events/' . $event . '.schema.json'), 'Missing event schema: ' . $event);
}

echo "Pass5CapabilityTest PASS\n";
