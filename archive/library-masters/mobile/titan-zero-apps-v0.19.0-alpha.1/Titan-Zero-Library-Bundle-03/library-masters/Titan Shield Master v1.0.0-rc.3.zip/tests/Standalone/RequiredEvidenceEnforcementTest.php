<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;

$payload = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, 512, JSON_THROW_ON_ERROR);
$payload['rules'] = [[
    'rule_key' => 'always-pass-number',
    'rule_type' => 'numeric_compare',
    'parameters' => ['field' => 'score', 'operator' => '>=', 'value' => 1],
    'required' => true,
    'failure_severity' => 'low',
    'knowledge_reference' => null,
]];
$definition = InspectionDefinition::fromArray($payload);
$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'test');
$run = (new InspectionRunEvaluator(new DeterministicRuleEngine()))->evaluate('run-required-evidence', $definition, 'job', 'job-1', ['fields' => ['score' => 2], 'evidence' => []], $context);

shield_assert_same(InspectionOutcome::Inconclusive, $run->outcome, 'Missing required evidence must never produce PASS.');

echo "RequiredEvidenceEnforcementTest PASS\n";
