<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, flags: JSON_THROW_ON_ERROR);
$sidecar = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, flags: JSON_THROW_ON_ERROR);

shield_assert_same('titan-extension-v1', $installer['schema'] ?? null, 'Blueprint v4.2 requires Titan Installer 1.7.8 root manifest.');
shield_assert_same('titan-shield', $installer['slug'] ?? null, 'Installer slug mismatch.');
shield_assert_same('TitanShield', $installer['folder'] ?? null, 'Installer folder mismatch.');
shield_assert_same('2.2', $sidecar['schema_version'] ?? null, 'Blueprint v4.2 requires sidecar schema v2.2.');
shield_assert_same('governance-engine', $sidecar['architecture']['profile'] ?? null, 'Shield must use governance-engine profile.');
shield_assert(in_array('signal-aware', $sidecar['architecture']['modifiers'] ?? [], true), 'Shield must be signal-aware.');
shield_assert(in_array('safety-critical', $sidecar['architecture']['modifiers'] ?? [], true), 'Shield must declare safety-critical modifier.');
shield_assert(in_array('regulated', $sidecar['architecture']['modifiers'] ?? [], true), 'Shield must declare regulated modifier.');
shield_assert_same(true, $sidecar['authority']['canonical_owner'] ?? null, 'Shield must be canonical quality/safety owner.');
shield_assert(in_array('quality-safety-verification', $sidecar['authority']['owns'] ?? [], true), 'Shield ownership domain missing.');
shield_assert(in_array('root_causation_id', $sidecar['signal']['causal_context'] ?? [], true), 'Signal causal context must include root_causation_id.');
shield_assert(is_file($root . '/System/Commands/CertifyExtensionCommand.php'), 'Host certification command missing.');
shield_assert(is_file($root . '/System/Services/ShieldAuthorityConstraintFactory.php'), 'Authority constraint factory missing.');
shield_assert(is_file($root . '/schemas/governance-authority-constraint.schema.json'), 'Shield authority constraint schema missing.');

$context = new App\Extensions\TitanShield\System\Context\ShieldExecutionContext(
    companyId: 10,
    traceId: '11111111-1111-4111-8111-111111111111',
    correlationId: '22222222-2222-4222-8222-222222222222',
    causationId: '33333333-3333-4333-8333-333333333333',
);
shield_assert_same('33333333-3333-4333-8333-333333333333', $context->toArray()['root_causation_id'] ?? null, 'Root causation must default safely to causation ID.');

echo "BlueprintV42ContractTest PASS\n";
