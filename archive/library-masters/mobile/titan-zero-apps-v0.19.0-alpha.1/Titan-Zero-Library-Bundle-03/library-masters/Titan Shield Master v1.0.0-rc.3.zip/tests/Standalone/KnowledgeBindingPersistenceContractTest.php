<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;

$root = dirname(__DIR__, 2);
$contract = file_get_contents($root . '/System/Contracts/ShieldRuntimeStoreContract.php');
$store = file_get_contents($root . '/System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php');
$migration = $root . '/database/migrations/2026_08_21_000009_create_titan_shield_knowledge_bindings_table.php';

shield_assert(str_contains($contract, 'recordKnowledgeBindingReceipt'), 'Runtime store contract must expose durable knowledge binding receipts.');
shield_assert(is_file($migration), 'Pass 7 must add a forward migration for durable knowledge bindings.');
$migrationSource = file_get_contents($migration);
foreach (['titan_shield_knowledge_bindings', 'company_id', 'binding_id', 'run_id', 'definition_hash', 'knowledge_key', 'authority_domain', 'jurisdiction', 'binding_mode', 'resolved_version', 'resolved_hash', 'trace_id', 'correlation_id', 'causation_id', 'root_causation_id'] as $needle) {
    shield_assert(str_contains($migrationSource, $needle), 'Knowledge binding migration missing: ' . $needle);
}
shield_assert(str_contains($migrationSource, 'function down()'), 'Knowledge binding migration must be reversible.');
shield_assert(str_contains($store, "'titan_shield_knowledge_bindings'"), 'Database runtime store must reference only the Shield-owned knowledge binding table.');
shield_assert(str_contains($store, 'recordKnowledgeBindingReceipt'), 'Database runtime store must implement receipt persistence.');

echo "KnowledgeBindingPersistenceContractTest PASS\n";
