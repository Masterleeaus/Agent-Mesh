<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Capabilities\ShieldCapabilityRegistry;
use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\InspectionDefinitionValidator;
use App\Extensions\TitanShield\System\Services\ShieldManager;

$manager = new ShieldManager(
    new ShieldCapabilityRegistry(),
    new InspectionDefinitionValidator(),
    new DeterministicRuleEngine(),
    new GovernanceResponseResolver(),
);

$health = $manager->health();
shield_assert_same('1.0.0-rc.2', $health['version'], 'Manager version must advance to 1.0.0-rc.2.');
shield_assert_same('production-candidate', $health['status'], 'Manager health should report the active knowledge-binding milestone.');

$capabilities = array_keys($manager->capabilities());
shield_assert_same([
    'shield.health',
    'shield.definition.validate',
    'shield.rule.evaluate',
    'shield.governance.response',
    'shield.inspection.evaluate',
    'shield.review.determine',
    'shield.authority.constraint',
    'shield.remediation.prepare',
    'shield.reinspection.evaluate',
], $capabilities, 'Only implemented Shield-owned capabilities may be declared.');

$definition = json_decode((string) file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, flags: JSON_THROW_ON_ERROR);
$validation = $manager->validateDefinition($definition);
shield_assert_same(true, $validation['valid'], 'Seed inspection definition should validate.');
shield_assert((bool) preg_match('/^[a-f0-9]{64}$/', $validation['definition_hash']), 'Validated definition should expose deterministic hash.');

$evaluation = $manager->evaluateRule([
    'rule_key' => 'photo-present',
    'rule_type' => 'evidence_present',
    'parameters' => ['evidence_key' => 'completion_photo'],
    'required' => true,
    'failure_severity' => 'medium',
], ['evidence' => ['completion_photo' => [['size_bytes' => 100]]]]);
shield_assert_same('pass', $evaluation['status'], 'Manager rule evaluation should call the deterministic engine.');

$context = new ShieldExecutionContext(
    companyId: 42,
    traceId: '018f1f52-71f2-7cc0-8c2b-f3e7070a1b21',
    correlationId: '018f1f52-71f2-7cc0-9c2b-f3e7070a1b22',
    causationId: '018f1f52-71f2-7cc0-ac2b-f3e7070a1b23',
);
$response = $manager->determineGovernanceResponse([
    'finding_id' => 'finding-1',
    'definition_key' => 'field_job_completion_basic',
    'definition_version' => '1.0.0',
    'definition_hash' => str_repeat('a', 64),
    'code' => 'required_rule_failed',
    'severity' => 'critical',
    'outcome' => 'fail',
    'subject_type' => 'job',
    'subject_id' => 'job-123',
    'evidence_ids' => ['ev-001'],
    'reason_codes' => ['required_rule_failed'],
], $context);
shield_assert_same(true, $response['block_progression'], 'Critical governance response must block.');
shield_assert_same(true, $response['requires_human_review'], 'Critical governance response must require human review.');

echo "ManagerCapabilityTest PASS\n";
