<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;
use App\Extensions\TitanShield\System\Services\InspectionRuntimeCoordinator;
use App\Extensions\TitanShield\System\Services\ReinspectionClosurePolicy;
use App\Extensions\TitanShield\System\Services\ReinspectionCoordinator;
use App\Extensions\TitanShield\System\Services\ReinspectionService;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;

final class ReinspectionFakeStore implements ShieldRuntimeStoreContract
{
    public function recordDefinition(\App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition $definition, ShieldExecutionContext $context): void {}
    public function recordEvidence(\App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest $manifest): void {}

    public array $runs = [];
    public array $findings = [];
    public array $reviews = [];
    public array $remediations = [];
    public array $receipts = [];
    public array $reinspections = [];
    public array $transitions = [];

    public function recordRun(InspectionRun $run): void { $this->runs[] = $run; }
    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void { $this->findings[] = [$finding, $governanceResponse]; }
    public function recordReview(HumanReviewRequest $review): void { $this->reviews[] = $review; }
    public function recordRemediationIntent(RemediationIntent $intent): void { $this->remediations[] = $intent; }
    public function recordIntegrationReceipt(array $receipt): void { $this->receipts[] = $receipt; }
    public function recordReinspection(ReinspectionRecord $reinspection): void { $this->reinspections[] = $reinspection; }
    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void {}
    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void {}
    public function applyFindingLifecycle(string $findingId, FindingLifecycleStatus $targetStatus, array $reasonCodes, ShieldExecutionContext $context, ?string $reinspectionId = null, ?string $reinspectionRunId = null): void
    {
        $this->transitions[] = compact('findingId', 'targetStatus', 'reasonCodes', 'reinspectionId', 'reinspectionRunId');
    }
}

$definition = InspectionDefinition::fromArray(json_decode(
    file_get_contents(dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'),
    true,
    512,
    JSON_THROW_ON_ERROR,
));
$context = new ShieldExecutionContext(
    42,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    7,
    'titan-go',
    '44444444-4444-4444-8444-444444444444',
);
$finding = new Finding(
    'finding-original',
    $definition->key(),
    $definition->version(),
    $definition->definitionHash(),
    'completion-photo-min-size',
    FindingSeverity::Medium,
    InspectionOutcome::ConditionalPass,
    'job',
    'job-500',
    ['ev-old'],
    ['RULE_FAILED'],
    $context,
);
$store = new ReinspectionFakeStore();
$runtime = new InspectionRuntimeCoordinator(
    new InspectionRunEvaluator(new DeterministicRuleEngine()),
    $store,
    new GovernanceResponseResolver(),
    new HumanReviewWorkflow(),
    new RemediationIntentFactory(),
    new RewindReceiptFactory(),
    new SignalEngineAdapter(),
    new RiskEngineAdapter(),
    new AssuranceEngineAdapter(),
);
$coordinator = new ReinspectionCoordinator(
    runtime: $runtime,
    service: new ReinspectionService(new ReinspectionClosurePolicy()),
    store: $store,
    signal: new SignalEngineAdapter(),
);

$result = $coordinator->execute(
    reinspectionId: 'reinspect-500',
    originalRunId: 'run-original-500',
    reinspectionRunId: 'run-reinspect-500',
    finding: $finding,
    definition: $definition,
    facts: [
        'evidence' => [
            'completion_photo' => [[
                'size_bytes' => 20000,
                'mime_type' => 'image/jpeg',
                'metadata' => [],
                'evidence_id' => 'ev-new',
            ]],
        ],
    ],
    context: $context,
    startedAt: '2026-08-19T00:10:00+10:00',
    completedAt: '2026-08-19T00:10:02+10:00',
);

shield_assert_same('pass', $result['runtime']['run']['outcome'], 'Reinspection runtime must execute the deterministic definition.');
shield_assert_same(1, count($store->reinspections), 'Reinspection linkage must be persisted once.');
shield_assert_same(FindingLifecycleStatus::Closed, $store->transitions[0]['targetStatus'], 'Passing MEDIUM reinspection must close the Shield finding.');
shield_assert_same('reinspect-500', $store->transitions[0]['reinspectionId'], 'Closure transition must link the reinspection ID.');
shield_assert_same('run-reinspect-500', $store->transitions[0]['reinspectionRunId'], 'Closure transition must link the reinspection run.');
shield_assert(count($store->receipts) >= 1, 'Reinspection lifecycle must retain integration/Rewind-compatible receipts.');
shield_assert_same(false, $result['authority']['direct_business_mutation'], 'Reinspection must never mutate foreign business state.');

echo "ReinspectionCoordinatorTest PASS\n";
