<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$systemRoot = $root . '/System';
$forbidden = [
    '/use\s+App\\\\Extensions\\\\(?!TitanShield\\\\)/',
    '/\\bHttp::/',
    '/\\beval\s*\(/i',
    '/\\bunserialize\s*\(/i',
    '/\\bshell_exec\s*\(/i',
    '/\\bexec\s*\(/i',
    '/\\bsystem\s*\(/i',
    '/\\bpassthru\s*\(/i',
    '/\\bproc_open\s*\(/i',
    '/\\bpopen\s*\(/i',
];

$violations = [];
$dbUsers = [];
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($systemRoot));
foreach ($iterator as $file) {
    if (! $file->isFile() || strtolower($file->getExtension()) !== 'php') {
        continue;
    }
    $contents = (string) file_get_contents($file->getPathname());
    foreach ($forbidden as $pattern) {
        if (preg_match($pattern, $contents) === 1) {
            $violations[] = $file->getPathname() . ' matched ' . $pattern;
        }
    }
    if (str_contains($contents, 'DB::')) {
        $dbUsers[] = str_replace($systemRoot . '/', '', $file->getPathname());
    }
}
shield_assert_same([], $violations, 'System security boundary violations found: ' . implode('; ', $violations));
sort($dbUsers);
shield_assert_same(
    ['Commands/CertifyExtensionCommand.php', 'Infrastructure/Persistence/DatabaseShieldRuntimeStore.php'],
    $dbUsers,
    'Database facade access is limited to Shield persistence plus read-only host certification.',
);

$certify = (string) file_get_contents($systemRoot . '/Commands/CertifyExtensionCommand.php');
shield_assert(! str_contains($certify, 'DB::' . 'table('), 'Certification command must not read or write domain tables directly.');
shield_assert(! str_contains($certify, 'DB::' . 'statement('), 'Certification command must not execute raw SQL.');

$store = (string) file_get_contents($systemRoot . '/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php');
preg_match_all("/DB::table\\('([^']+)'\\)/", $store, $matches);
foreach (array_unique($matches[1] ?? []) as $table) {
    shield_assert(str_starts_with($table, 'titan_shield_'), 'Shield persistence adapter may only target titan_shield_* tables; found ' . $table);
}
shield_assert(($matches[1] ?? []) !== [], 'Shield persistence adapter must have explicit owned-table targets.');

$manifest = (string) file_get_contents($root . '/extension.manifest.json');
$registry = (string) file_get_contents($root . '/System/Capabilities/ShieldCapabilityRegistry.php');
shield_assert(! str_contains($manifest, 'test.override'), 'Production manifest must never expose test.override.');
shield_assert(! str_contains($registry, 'test.override'), 'Production capability registry must never expose test.override.');
shield_assert(! str_contains($registry, 'filePath'), 'Public capability registry must not expose raw filesystem path inputs.');

echo "SecurityBoundaryTest PASS\n";
