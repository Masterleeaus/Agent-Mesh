<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$source = (string) file_get_contents(dirname(__DIR__, 2) . '/System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php');
foreach (['Reinspection identity is immutable', 'Assurance clearance identity is immutable', 'Knowledge binding identity is immutable', 'Remediation intent identity is immutable'] as $needle) {
    shield_assert(str_contains($source, $needle), 'Missing immutable persistence guard: ' . $needle);
}

echo "ImmutablePersistenceHotfixTest PASS\n";
