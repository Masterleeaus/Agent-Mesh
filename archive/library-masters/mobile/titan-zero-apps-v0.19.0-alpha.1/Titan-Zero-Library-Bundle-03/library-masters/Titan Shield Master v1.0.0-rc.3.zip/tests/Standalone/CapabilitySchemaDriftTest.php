<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Capabilities\ShieldCapabilityRegistry;

$registry = new ShieldCapabilityRegistry();
$inspection = $registry->find('shield.inspection.evaluate')->toArray();
$reinspection = $registry->find('shield.reinspection.evaluate')->toArray();
shield_assert(! array_key_exists('assurance_evidence', $inspection['input_schema']['properties']), 'Initial inspection must not advertise unsupported assurance_evidence.');
shield_assert(array_key_exists('assurance_evidence', $reinspection['input_schema']['properties']), 'Reinspection must advertise supported assurance_evidence.');

echo "CapabilitySchemaDriftTest PASS\n";
