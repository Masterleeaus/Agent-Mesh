<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Integrations\KnowledgeAuthorityAdapter;

$adapter = new KnowledgeAuthorityAdapter();
$resolution = $adapter->resolve([
    'reference_key' => 'vic.safety.harness.anchor',
    'vertical_key' => 'field-home-services',
    'jurisdiction' => 'AU-VIC',
]);

shield_assert_same('UNRESOLVED', $resolution->status, 'Shield must not invent authoritative knowledge when resolver capability is unavailable.');
shield_assert_same('KNOWLEDGE_RESOLVER_CAPABILITY_UNAVAILABLE', $resolution->reasonCode, 'Unresolved knowledge must have a stable reason code.');
shield_assert_same(null, $resolution->resolvedVersion, 'Unresolved reference cannot claim a resolved version.');

echo "KnowledgeAuthorityAdapterTest PASS\n";
