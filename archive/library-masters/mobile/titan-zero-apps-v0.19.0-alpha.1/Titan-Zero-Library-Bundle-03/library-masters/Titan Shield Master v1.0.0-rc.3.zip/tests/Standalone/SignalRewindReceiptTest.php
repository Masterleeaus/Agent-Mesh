<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;

$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'system');
$finding = new Finding('finding-2', 'job-finish', '1.0.0', str_repeat('d', 64), 'bad-finish', FindingSeverity::Medium, InspectionOutcome::ConditionalPass, 'job', 'job-5', ['ev-2'], ['FINISH_REWORK'], $context);

$rewind = (new RewindReceiptFactory())->forFinding($finding, ['request_command_bus' => true], '2026-08-11T23:40:00+10:00');
$payload = $rewind->jsonSerialize();
shield_assert_same('shield.finding.recorded', $payload['event_type'], 'Rewind receipt needs a stable event type.');
shield_assert_same(['FINISH_REWORK'], $payload['reason_codes'], 'Rewind receipt must retain structured reason codes.');
shield_assert_same(false, array_key_exists('chain_of_thought', $payload), 'Rewind receipt must never expose hidden chain-of-thought.');
shield_assert_same(str_repeat('d', 64), $payload['definition_hash'], 'Rewind receipt must pin definition hash.');

$signal = new SignalEngineAdapter();
$signalPayload = $signal->buildSignal('shield.finding.recorded', $payload, $context, 'finding-2');
shield_assert_same('shield.finding.recorded', $signalPayload['event_type'], 'Signal event type must be stable.');
shield_assert_same(42, $signalPayload['company_id'], 'Signal must retain tenant context.');
shield_assert_same('UNAVAILABLE', $signal->emit($signalPayload)['status'], 'Missing Signal Engine must be explicit, not silently successful.');

echo "SignalRewindReceiptTest PASS\n";
