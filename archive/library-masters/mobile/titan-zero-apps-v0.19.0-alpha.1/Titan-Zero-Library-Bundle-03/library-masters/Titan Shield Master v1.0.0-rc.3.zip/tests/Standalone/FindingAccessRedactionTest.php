<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Services\FindingAccessRedactionPolicy;

$policy = new FindingAccessRedactionPolicy();
$finding = [
    'finding_id' => 'finding-1',
    'outcome' => 'fail',
    'severity' => 'high',
    'code' => 'SAFETY_HARNESS',
    'reason_codes' => ['HARNESS_MISSING'],
    'evidence_ids' => ['ev-1'],
    'evidence_hashes' => ['abc'],
    'internal_notes' => 'operator-only',
];

$customer = $policy->redactFinding($finding, 'customer', false);
shield_assert_same(['finding_id' => 'finding-1', 'outcome' => 'fail'], $customer, 'Customer view must expose summary only.');

$workerDenied = $policy->redactFinding($finding, 'worker', false);
shield_assert_same([], $workerDenied, 'Unassigned worker must not receive finding details.');

$worker = $policy->redactFinding($finding, 'worker', true);
shield_assert(isset($worker['code'], $worker['reason_codes']), 'Assigned worker needs operational finding details.');
shield_assert(! isset($worker['evidence_hashes'], $worker['internal_notes']), 'Assigned worker must not receive integrity hashes/internal notes.');

$manager = $policy->redactFinding($finding, 'manager', true);
shield_assert_same($finding, $manager, 'Tenant manager must receive full tenant-scoped finding data after host authorization.');

shield_assert_same([], $policy->redactFinding($finding, 'unknown', true), 'Unknown audience must fail closed.');

echo "FindingAccessRedactionTest PASS\n";
