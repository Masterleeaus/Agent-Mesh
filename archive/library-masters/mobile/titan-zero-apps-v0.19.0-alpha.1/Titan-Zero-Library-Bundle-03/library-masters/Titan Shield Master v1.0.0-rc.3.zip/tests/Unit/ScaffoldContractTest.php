<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Extensions\TitanShield\System\Capabilities\ShieldCapabilityRegistry;
use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Services\ShieldManager;
use App\Extensions\TitanShield\System\Services\InspectionDefinitionValidator;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_health_capability_is_truthful_and_read_only(): void
    {
        $registry = new ShieldCapabilityRegistry();
        $manager = new ShieldManager($registry, new InspectionDefinitionValidator(), new DeterministicRuleEngine(), new GovernanceResponseResolver());
        $health = $manager->health();
        $definition = $registry->find('shield.health');

        self::assertSame('titan-shield', $health['engine']);
        self::assertSame('production-candidate', $health['status']);
        self::assertSame('1.0.0-rc.2', $health['version']);
        self::assertFalse($health['queue_enabled']);
        self::assertNotNull($definition);
        self::assertFalse($definition->mutation);
        self::assertSame('read-only', $definition->idempotency);
        self::assertSame('none', $definition->approvalMode);
    }

    public function test_execution_context_requires_complete_tenant_and_trace_chain(): void
    {
        $context = new ShieldExecutionContext(
            companyId: 42,
            traceId: '018f1f52-71f2-7cc0-8c2b-f3e7070a1b21',
            correlationId: '018f1f52-71f2-7cc0-9c2b-f3e7070a1b22',
            causationId: '018f1f52-71f2-7cc0-ac2b-f3e7070a1b23',
            actorUserId: 7,
            source: 'test',
        );

        self::assertSame(42, $context->toArray()['company_id']);
        self::assertSame('018f1f52-71f2-7cc0-ac2b-f3e7070a1b23', $context->toArray()['causation_id']);
    }

    public function test_execution_context_rejects_missing_tenant_scope(): void
    {
        $this->expectException(InvalidArgumentException::class);

        new ShieldExecutionContext(
            companyId: 0,
            traceId: '018f1f52-71f2-7cc0-8c2b-f3e7070a1b21',
            correlationId: '018f1f52-71f2-7cc0-9c2b-f3e7070a1b22',
            causationId: '018f1f52-71f2-7cc0-ac2b-f3e7070a1b23',
        );
    }
}
