<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\ShieldAuthorityConstraintFactory;

$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'test');
$finding = new Finding('f-1', 'safety_harness', '1.0.0', str_repeat('a', 64), 'anchor_missing', FindingSeverity::Critical, InspectionOutcome::Fail, 'job', 'job-9', ['ev-1'], ['ANCHOR_MISSING'], $context);
$resolver = new GovernanceResponseResolver();
$response = $resolver->resolve($finding);
$constraint = (new ShieldAuthorityConstraintFactory())->fromFinding($finding, $response, 'agent-1', 'crm.job.complete', workflow: 'job_completion');

shield_assert_same('titan-shield', $constraint['source'], 'Constraint source mismatch.');
shield_assert_same('HOLD', $constraint['disposition'], 'Critical Shield finding must HOLD authority.');
shield_assert_same(0.0, $constraint['ceiling_score'], 'Critical HOLD must set ceiling to zero.');
shield_assert_same(42, $constraint['autonomy_key']['company_id'], 'Tenant must propagate.');
shield_assert_same('crm.job.complete', $constraint['autonomy_key']['capability'], 'Capability key must propagate.');
shield_assert(! array_key_exists('desired_score', $constraint), 'Shield constraint must not mint desired authority.');
shield_assert(! array_key_exists('earned_score', $constraint), 'Shield constraint must not mint earned authority.');

echo "AuthorityConstraintTest PASS\n";
