<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;

$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'system');
$finding = new Finding('finding-rem-1', 'job-finish', '1.0.0', str_repeat('e', 64), 'finish-rework', FindingSeverity::Medium, InspectionOutcome::ConditionalPass, 'job', 'job-10', ['ev-1'], ['REWORK_REQUIRED'], $context);

$factory = new RemediationIntentFactory();
$one = $factory->prepare('rem-1', $finding, 'rework', null, ['note' => 'reinspect after correction']);
$two = $factory->prepare('rem-2', $finding, 'rework', null, ['note' => 'reinspect after correction']);

shield_assert_same(false, $one->directMutation, 'Shield remediation intents must never directly mutate authoritative business state.');
shield_assert_same('PREPARED', $one->status, 'Remediation must be prepare-only until Command Bus routes an owning-domain capability.');
shield_assert_same(null, $one->requestedCapability, 'Shield must not invent an owning-domain capability when none was resolved.');
shield_assert_same($one->idempotencyKey, $two->idempotencyKey, 'Equivalent remediation intent content must produce a stable idempotency key.');

echo "RemediationIntentTest PASS\n";
