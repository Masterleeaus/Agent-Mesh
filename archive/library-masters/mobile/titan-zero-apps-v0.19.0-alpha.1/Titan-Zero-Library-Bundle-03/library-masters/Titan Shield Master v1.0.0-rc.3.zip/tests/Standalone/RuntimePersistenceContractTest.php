<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$migration = $root . '/database/migrations/2026_08_11_000005_create_titan_shield_inspection_runtime_tables.php';
shield_assert(is_file($migration), 'Pass 3 runtime migration must exist.');
$source = file_get_contents($migration);
foreach ([
    'titan_shield_inspection_runs',
    'titan_shield_inspection_item_results',
    'titan_shield_human_reviews',
    'titan_shield_remediation_intents',
    'titan_shield_integration_receipts',
] as $table) {
    shield_assert(str_contains($source, $table), 'Runtime migration missing table ' . $table);
}
foreach (['company_id', 'trace_id', 'correlation_id', 'causation_id'] as $field) {
    shield_assert(substr_count($source, $field) >= 4, 'Governed runtime tables must carry ' . $field . ' context.');
}

$store = $root . '/System/Infrastructure/Persistence/DatabaseShieldRuntimeStore.php';
shield_assert(is_file($store), 'Database Shield runtime store must exist.');
$storeSource = file_get_contents($store);
shield_assert(str_contains($storeSource, 'recordRun'), 'Runtime store must persist inspection runs.');
shield_assert(str_contains($storeSource, 'recordReview'), 'Runtime store must persist human reviews.');
shield_assert(str_contains($storeSource, 'recordRemediationIntent'), 'Runtime store must persist remediation intents.');
shield_assert(str_contains($storeSource, 'Human review identity is immutable'), 'Runtime store must reject review-ID reuse against a different finding snapshot.');

echo "RuntimePersistenceContractTest PASS\n";
