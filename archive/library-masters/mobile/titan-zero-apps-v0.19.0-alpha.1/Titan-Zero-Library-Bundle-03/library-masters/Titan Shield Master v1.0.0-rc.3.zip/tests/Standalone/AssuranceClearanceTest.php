<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Services\AssuranceClearanceNormalizer;

$context = new ShieldExecutionContext(
    42,
    '11111111-1111-4111-8111-111111111111',
    '22222222-2222-4222-8222-222222222222',
    '33333333-3333-4333-8333-333333333333',
    7,
    'titan-go',
    '44444444-4444-4444-8444-444444444444',
);
$finding = new Finding(
    'finding-high-1',
    'job-completion-basic',
    '1.0.0',
    str_repeat('a', 64),
    'safety-critical-check',
    FindingSeverity::High,
    InspectionOutcome::Fail,
    'job',
    'job-900',
    ['evidence-1'],
    ['SAFETY_RULE_FAILED'],
    $context,
);
$evidence = new EvidenceManifest(
    evidenceId: 'evidence-1',
    evidenceKey: 'completion_photo',
    originalFilename: 'photo.jpg',
    mimeType: 'image/jpeg',
    sizeBytes: 500000,
    sha256: str_repeat('b', 64),
    capturedAt: '2026-08-20T22:00:00+10:00',
    captureDeviceId: 'device-1',
    storageReference: 'private://shield/evidence-1',
    metadata: ['gps' => '-37.81,144.96'],
    context: $context,
);

$normalizer = new AssuranceClearanceNormalizer();
$green = $normalizer->normalize($finding, [$evidence], [
    'status' => 'OK',
    'engine' => 'titan-assurance',
    'contract' => 'EvidenceAssuranceEngine',
    'result' => [
        'uuid' => 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
        'company_id' => '42',
        'subject' => ['type' => 'job', 'id' => 'job-900'],
        'capability' => 'shield.finding.verify_assurance',
        'status' => 'GREEN',
        'score' => 91.5,
        'policy_version' => 'titan-assurance-v2.1',
        'evidence_used' => [[
            'evidence_id' => 'evidence-1',
            'hash' => str_repeat('b', 64),
        ]],
        'missing_evidence' => [],
        'stale_evidence' => [],
        'contradictory_evidence' => [],
        'reason_codes' => ['EVIDENCE_SUPPORTS_ACTION'],
    ],
]);
shield_assert_same('ALLOW', $green->decision, 'Exact GREEN assurance evidence must normalize to ALLOW.');
shield_assert_same(true, $green->mayClose, 'ALLOW must permit high-severity Shield closure.');
shield_assert_same(91.5, $green->score, 'Assurance score must be retained.');

$mismatch = $normalizer->normalize($finding, [$evidence], [
    'status' => 'OK',
    'engine' => 'titan-assurance',
    'result' => [
        'company_id' => '42',
        'subject' => ['type' => 'job', 'id' => 'job-900'],
        'capability' => 'shield.finding.verify_assurance',
        'status' => 'GREEN',
        'score' => 99,
        'policy_version' => 'titan-assurance-v2.1',
        'evidence_used' => [['evidence_id' => 'evidence-1', 'hash' => str_repeat('c', 64)]],
        'missing_evidence' => [],
        'stale_evidence' => [],
        'contradictory_evidence' => [],
    ],
]);
shield_assert_same('HOLD', $mismatch->decision, 'Evidence hash mismatch must fail closed to HOLD.');
shield_assert_same(false, $mismatch->mayClose, 'Evidence mismatch must not close a finding.');
shield_assert(in_array('ASSURANCE_EVIDENCE_SET_MISMATCH', $mismatch->reasonCodes, true), 'Mismatch reason must be explicit.');

$red = $normalizer->normalize($finding, [$evidence], [
    'status' => 'OK',
    'engine' => 'titan-assurance',
    'result' => [
        'company_id' => '42',
        'subject' => ['type' => 'job', 'id' => 'job-900'],
        'capability' => 'shield.finding.verify_assurance',
        'status' => 'RED',
        'score' => 40,
        'policy_version' => 'titan-assurance-v2.1',
        'evidence_used' => [['evidence_id' => 'evidence-1', 'hash' => str_repeat('b', 64)]],
        'missing_evidence' => [],
        'stale_evidence' => [],
        'contradictory_evidence' => [],
    ],
]);
shield_assert_same('DENY', $red->decision, 'RED assurance must normalize to DENY.');
shield_assert_same(false, $red->mayClose, 'DENY must never close a finding.');

$unavailable = $normalizer->normalize($finding, [$evidence], [
    'status' => 'UNAVAILABLE',
    'engine' => 'titan-assurance',
    'reason_code' => 'ASSURANCE_PUBLIC_CONTRACT_UNAVAILABLE',
]);
shield_assert_same('HOLD', $unavailable->decision, 'Unavailable Assurance must fail closed to HOLD.');
shield_assert_same(false, $unavailable->mayClose, 'Unavailable Assurance must not clear high severity closure.');

echo "AssuranceClearanceTest PASS\n";
