<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Services\InspectionDefinitionValidator;
use App\Extensions\TitanShield\System\Services\VerticalPackCertificationService;

$root = dirname(__DIR__, 2);
$definition = json_decode((string) file_get_contents($root . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json'), true, 512, JSON_THROW_ON_ERROR);
$service = new VerticalPackCertificationService(new InspectionDefinitionValidator());
$result = $service->certify($definition);
shield_assert_same('CERTIFIED', $result['status'], 'Built-in field/home-service pack must certify.');
shield_assert_same('field-home-services', $result['vertical_key'], 'Pack vertical must be preserved.');
shield_assert_same(false, $result['regulatory_claim'], 'Basic completion pack must not claim regulatory authority.');
shield_assert(preg_match('/^[a-f0-9]{64}$/', $result['definition_hash']) === 1, 'Certified pack must expose deterministic hash.');

$unsafe = $definition;
$unsafe['inspection_type'] = 'safety';
$unsafe['knowledge_references'] = [];
$unsafeResult = $service->certify($unsafe);
shield_assert_same('REJECTED', $unsafeResult['status'], 'Safety pack without authority references must fail closed.');
shield_assert(in_array('AUTHORITY_REFERENCE_REQUIRED', $unsafeResult['reason_codes'], true), 'Safety rejection must explain missing authority reference.');

echo "VerticalPackCertificationTest PASS\n";
