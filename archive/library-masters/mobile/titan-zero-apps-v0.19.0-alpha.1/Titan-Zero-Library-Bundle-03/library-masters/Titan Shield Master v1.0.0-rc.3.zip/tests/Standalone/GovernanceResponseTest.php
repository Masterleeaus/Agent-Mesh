<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceAction;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\ShieldIntegrationEnvelopeExporter;

$context = new ShieldExecutionContext(
    companyId: 42,
    traceId: '018f1f52-71f2-7cc0-8c2b-f3e7070a1b21',
    correlationId: '018f1f52-71f2-7cc0-9c2b-f3e7070a1b22',
    causationId: '018f1f52-71f2-7cc0-ac2b-f3e7070a1b23',
    actorUserId: 7,
    source: 'test',
);

$make = static function (FindingSeverity $severity, InspectionOutcome $outcome) use ($context): Finding {
    return new Finding(
        findingId: 'finding-' . $severity->value . '-' . $outcome->value,
        definitionKey: 'field_job_completion_basic',
        definitionVersion: '1.0.0',
        definitionHash: str_repeat('a', 64),
        code: 'rule.failed',
        severity: $severity,
        outcome: $outcome,
        subjectType: 'job',
        subjectId: 'job-123',
        evidenceIds: ['ev-001'],
        reasonCodes: ['required_rule_failed'],
        context: $context,
    );
};

$resolver = new GovernanceResponseResolver();

$low = $resolver->resolve($make(FindingSeverity::Low, InspectionOutcome::Fail));
shield_assert_same([GovernanceAction::RecordAndContinue], $low->actions, 'LOW finding should record and continue.');
shield_assert(! $low->blockProgression, 'LOW finding must not block by default.');

$medium = $resolver->resolve($make(FindingSeverity::Medium, InspectionOutcome::Fail));
shield_assert(in_array(GovernanceAction::RequestRemediation, $medium->actions, true), 'MEDIUM finding should request remediation.');
shield_assert(! $medium->requestCouncil, 'MEDIUM finding must not automatically invoke Model Council.');

$high = $resolver->resolve($make(FindingSeverity::High, InspectionOutcome::Fail));
shield_assert($high->blockProgression, 'HIGH finding must block progression.');
shield_assert($high->requestRisk && $high->requestAssurance, 'HIGH finding must request Risk and Assurance evaluation.');

$critical = $resolver->resolve($make(FindingSeverity::Critical, InspectionOutcome::Fail));
shield_assert($critical->blockProgression && $critical->requiresHumanReview, 'CRITICAL finding must fail closed for human review.');
shield_assert(! $critical->requestCouncil, 'CRITICAL does not delegate final authority to Model Council.');

$inconclusive = $resolver->resolve($make(FindingSeverity::Medium, InspectionOutcome::Inconclusive));
shield_assert(in_array(GovernanceAction::RequireMoreEvidence, $inconclusive->actions, true), 'INCONCLUSIVE must request more evidence/review.');

$exporter = new ShieldIntegrationEnvelopeExporter();
$riskEnvelope = $exporter->forRisk($make(FindingSeverity::High, InspectionOutcome::Fail), $high);
shield_assert_same('risk', $riskEnvelope['target'], 'Risk export should target Risk.');
shield_assert_same(42, $riskEnvelope['company_id'], 'Risk export must preserve tenant scope.');
shield_assert_same('high', $riskEnvelope['finding']['severity'], 'Risk export should carry Shield-local severity without pretending it is a Risk score.');

echo "GovernanceResponseTest PASS\n";
