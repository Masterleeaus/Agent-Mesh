<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;

$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'titan-go');
$finding = new Finding('finding-1', 'job-finish', '1.0.0', str_repeat('b', 64), 'photo-missing', FindingSeverity::High, InspectionOutcome::Fail, 'job', 'job-77', ['ev-1'], ['PHOTO_MISSING'], $context);

$risk = new RiskEngineAdapter();
$riskRequest = $risk->buildRequest($finding, ['safety' => 80, 'operational' => 70], 'field-home-services', 'AU-VIC');
shield_assert_same('shield.finding.evaluate', $riskRequest['capability'], 'Risk request capability must be explicit.');
shield_assert_same('finding-1', $riskRequest['resource_id'], 'Risk request must target the finding.');
shield_assert_same(80.0, $riskRequest['impact']['safety'], 'Impact hints must be preserved without Shield producing a risk decision.');
shield_assert_same('UNAVAILABLE', $risk->assess($finding)['status'], 'Adapter must explicitly report unavailable when Risk is not installed in standalone tests.');

$manifest = new EvidenceManifest(
    evidenceId: 'ev-1',
    evidenceKey: 'completion_photo',
    originalFilename: 'photo.jpg',
    mimeType: 'image/jpeg',
    sizeBytes: 12345,
    sha256: str_repeat('c', 64),
    capturedAt: '2026-08-11T22:00:00+10:00',
    captureDeviceId: 'device-1',
    storageReference: 'private://shield/ev-1',
    metadata: ['gps' => '-37.81,144.96'],
    context: $context,
);
$assurance = new AssuranceEngineAdapter();
$assuranceRequest = $assurance->buildRequest($finding, [$manifest], [['key' => 'completion_photo', 'evidence_type' => 'photo', 'required' => true]], [], 'field-home-services', 'AU-VIC');
shield_assert_same('shield_finding', $assuranceRequest['decision_type'], 'Assurance decision type must be Shield-specific.');
shield_assert_same('ev-1', $assuranceRequest['evidence'][0]['evidence_id'], 'Assurance request must retain evidence identity.');
shield_assert_same(str_repeat('c', 64), $assuranceRequest['evidence'][0]['hash'], 'Assurance request must retain evidence integrity hash.');
shield_assert_same('UNAVAILABLE', $assurance->assess($finding, [$manifest])['status'], 'Adapter must explicitly report unavailable when Assurance is not installed in standalone tests.');

echo "GovernanceAdaptersTest PASS\n";
