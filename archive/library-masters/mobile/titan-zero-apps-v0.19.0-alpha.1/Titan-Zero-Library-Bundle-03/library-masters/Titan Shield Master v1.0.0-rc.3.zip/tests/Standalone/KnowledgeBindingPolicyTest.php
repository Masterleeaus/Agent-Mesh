<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Domain\Definitions\KnowledgeReference;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeResolution;
use App\Extensions\TitanShield\System\Services\KnowledgeBindingPolicy;

$hash = str_repeat('a', 64);
$reference = new KnowledgeReference(
    knowledgeKey: 'au.vic.working-at-heights.anchor',
    version: '2026.08.1',
    contentHash: $hash,
    authorityDomain: 'regulatory-safety',
    jurisdiction: 'AU-VIC',
    verticalKey: 'field-home-services',
    required: true,
    requireLiveResolution: false,
);
$policy = new KnowledgeBindingPolicy();
$pinned = $policy->bind(
    $reference,
    new KnowledgeResolution('UNRESOLVED', $reference->jsonSerialize(), 'KNOWLEDGE_RESOLVER_CAPABILITY_UNAVAILABLE'),
    'AU-VIC',
    'field-home-services',
);
shield_assert_same('BOUND', $pinned['status'], 'Exact immutable authority pin should be usable when live resolution is not required.');
shield_assert_same('PINNED', $pinned['binding_mode'], 'Pinned fallback must be explicit, never mislabeled as live resolution.');
shield_assert_same(false, $pinned['blocking'], 'Valid pinned reference must not block.');

$liveRequired = new KnowledgeReference(
    knowledgeKey: 'au.vic.working-at-heights.anchor',
    version: '2026.08.1',
    contentHash: $hash,
    authorityDomain: 'regulatory-safety',
    jurisdiction: 'AU-VIC',
    verticalKey: 'field-home-services',
    required: true,
    requireLiveResolution: true,
);
$blocked = $policy->bind(
    $liveRequired,
    new KnowledgeResolution('UNRESOLVED', $liveRequired->jsonSerialize(), 'KNOWLEDGE_RESOLVER_CAPABILITY_UNAVAILABLE'),
    'AU-VIC',
    'field-home-services',
);
shield_assert_same(true, $blocked['blocking'], 'Live-required unresolved authority must fail closed.');
shield_assert_same('KNOWLEDGE_AUTHORITY_UNRESOLVED', $blocked['reason_code'], 'Blocked authority requires stable reason code.');

$mismatch = $policy->bind(
    $reference,
    new KnowledgeResolution('UNRESOLVED', $reference->jsonSerialize(), 'KNOWLEDGE_RESOLVER_CAPABILITY_UNAVAILABLE'),
    'AU-NSW',
    'field-home-services',
);
shield_assert_same(true, $mismatch['blocking'], 'Jurisdiction mismatch must fail closed.');
shield_assert_same('KNOWLEDGE_JURISDICTION_MISMATCH', $mismatch['reason_code'], 'Jurisdiction mismatch reason must be explicit.');

$resolvedMismatch = $policy->bind(
    $reference,
    new KnowledgeResolution('RESOLVED', $reference->jsonSerialize(), 'KNOWLEDGE_RESOLVED', '2026.08.2', str_repeat('b', 64), []),
    'AU-VIC',
    'field-home-services',
);
shield_assert_same(true, $resolvedMismatch['blocking'], 'Live resolver may not silently substitute a different pinned version/hash.');
shield_assert_same('KNOWLEDGE_PIN_MISMATCH', $resolvedMismatch['reason_code'], 'Pin mismatch reason must be explicit.');

echo "KnowledgeBindingPolicyTest PASS\n";
