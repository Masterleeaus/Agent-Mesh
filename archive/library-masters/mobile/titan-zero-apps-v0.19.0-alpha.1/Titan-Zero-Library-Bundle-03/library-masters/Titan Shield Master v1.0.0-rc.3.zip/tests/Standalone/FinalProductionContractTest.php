<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$root = dirname(__DIR__, 2);
$provider = (string) file_get_contents($root . '/System/TitanShieldServiceProvider.php');
$certify = (string) file_get_contents($root . '/System/Commands/CertifyExtensionCommand.php');
$uninstall = $provider;

foreach (['FindingAccessRedactionPolicy::class', 'VerticalPackCertificationService::class'] as $binding) {
    shield_assert(str_contains($provider, $binding), 'Provider must register ' . $binding);
}
foreach (['view:panel.layout.app', 'dashboard.user.titan.shield.index', 'dashboard.admin.titan.shield.index', 'pack:field-home-services/basic-job-completion'] as $probe) {
    shield_assert(str_contains($certify, $probe), 'Host certification must probe ' . $probe);
}
shield_assert(str_contains($uninstall, "File::delete(config_path('titan-shield.php'))"), 'Uninstall must remain config-only/idempotent.');
shield_assert(! str_contains($uninstall, 'Schema::drop'), 'Uninstall must not drop retained Shield evidence tables.');
shield_assert(! str_contains($uninstall, 'dropIfExists'), 'Uninstall must not drop retained Shield evidence tables.');

echo "FinalProductionContractTest PASS\n";
