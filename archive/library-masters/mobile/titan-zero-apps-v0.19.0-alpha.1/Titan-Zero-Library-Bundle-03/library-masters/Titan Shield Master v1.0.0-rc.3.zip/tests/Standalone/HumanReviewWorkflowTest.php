<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewDecision;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;

$context = new ShieldExecutionContext(42, '11111111-1111-4111-8111-111111111111', '22222222-2222-4222-8222-222222222222', '33333333-3333-4333-8333-333333333333', 7, 'system');
$finding = new Finding(
    findingId: 'finding-critical-1',
    definitionKey: 'safety-harness',
    definitionVersion: '1.0.0',
    definitionHash: str_repeat('a', 64),
    code: 'anchor-point-missing',
    severity: FindingSeverity::Critical,
    outcome: InspectionOutcome::Fail,
    subjectType: 'job',
    subjectId: 'job-9',
    evidenceIds: ['ev-9'],
    reasonCodes: ['ANCHOR_POINT_MISSING'],
    context: $context,
);

$workflow = new HumanReviewWorkflow();
$request = $workflow->request('review-1', $finding, 'manager', '2026-08-12T12:00:00+10:00');
shield_assert_same(HumanReviewDecision::Pending, $request->decision, 'New review must begin pending.');

$reviewed = $workflow->decide($request, HumanReviewDecision::OverrideFinding, 88, 'FIELD_SUPERVISOR_OVERRIDE', '2026-08-11T23:30:00+10:00');
shield_assert_same('finding-critical-1', $reviewed->findingId, 'Review must preserve immutable original finding reference.');
shield_assert_same(false, $reviewed->mayProceed, 'A human override alone must not release a CRITICAL finding.');
shield_assert_same(true, $reviewed->requiresAssurance, 'Critical override requires independent Assurance.');
shield_assert_same(88, $reviewed->reviewedBy, 'Reviewer identity must be retained.');

shield_expect_exception(
    fn () => $workflow->decide($request, HumanReviewDecision::OverrideFinding, 88, '', '2026-08-11T23:30:00+10:00'),
    InvalidArgumentException::class,
    'Override without a structured reason code must fail closed.',
);

echo "HumanReviewWorkflowTest PASS\n";
