<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Capabilities;

use App\Extensions\TitanShield\System\Contracts\ShieldCapabilityRegistryContract;

final class ShieldCapabilityRegistry implements ShieldCapabilityRegistryContract
{
    /** @var array<string,CapabilityDefinition>|null */
    private ?array $definitions = null;

    public function all(): array
    {
        if ($this->definitions !== null) {
            return $this->definitions;
        }

        return $this->definitions = [
            'shield.health' => new CapabilityDefinition(
                name: 'shield.health',
                inputSchema: ['type' => 'object', 'properties' => [], 'additionalProperties' => false],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['engine', 'status', 'version', 'capabilities'],
                    'properties' => [
                        'engine' => ['type' => 'string'],
                        'status' => ['type' => 'string'],
                        'version' => ['type' => 'string'],
                        'capabilities' => ['type' => 'array', 'items' => ['type' => 'string']],
                    ],
                    'additionalProperties' => true,
                ],
                riskClass: 'low',
                idempotency: 'read-only',
                approvalMode: 'none',
                mutation: false,
            ),
            'shield.definition.validate' => new CapabilityDefinition(
                name: 'shield.definition.validate',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['definition'],
                    'properties' => ['definition' => ['type' => 'object']],
                    'additionalProperties' => false,
                ],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['valid', 'definition_key', 'version', 'definition_hash'],
                    'properties' => [
                        'valid' => ['type' => 'boolean'],
                        'definition_key' => ['type' => 'string'],
                        'version' => ['type' => 'string'],
                        'definition_hash' => ['type' => 'string'],
                    ],
                    'additionalProperties' => false,
                ],
                riskClass: 'low',
                idempotency: 'deterministic-read-only',
                approvalMode: 'none',
                mutation: false,
            ),
            'shield.rule.evaluate' => new CapabilityDefinition(
                name: 'shield.rule.evaluate',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['rule', 'facts'],
                    'properties' => ['rule' => ['type' => 'object'], 'facts' => ['type' => 'object']],
                    'additionalProperties' => false,
                ],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['rule_key', 'status', 'failure_severity', 'details'],
                    'properties' => [
                        'rule_key' => ['type' => 'string'],
                        'status' => ['enum' => ['pass', 'fail']],
                        'failure_severity' => ['type' => 'string'],
                        'details' => ['type' => 'object'],
                    ],
                    'additionalProperties' => false,
                ],
                riskClass: 'medium',
                idempotency: 'deterministic-read-only',
                approvalMode: 'none',
                mutation: false,
            ),
            'shield.governance.response' => new CapabilityDefinition(
                name: 'shield.governance.response',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['finding'],
                    'properties' => ['finding' => ['type' => 'object']],
                    'additionalProperties' => false,
                ],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['actions', 'block_progression', 'requires_human_review', 'request_risk', 'request_assurance', 'request_command_bus', 'request_council', 'reason_codes'],
                    'properties' => [
                        'actions' => ['type' => 'array', 'items' => ['type' => 'string']],
                        'block_progression' => ['type' => 'boolean'],
                        'requires_human_review' => ['type' => 'boolean'],
                        'request_risk' => ['type' => 'boolean'],
                        'request_assurance' => ['type' => 'boolean'],
                        'request_command_bus' => ['type' => 'boolean'],
                        'request_council' => ['type' => 'boolean'],
                        'reason_codes' => ['type' => 'array', 'items' => ['type' => 'string']],
                    ],
                    'additionalProperties' => false,
                ],
                riskClass: 'high',
                idempotency: 'deterministic-read-only',
                approvalMode: 'none',
                mutation: false,
            ),
            'shield.inspection.evaluate' => new CapabilityDefinition(
                name: 'shield.inspection.evaluate',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['run_id', 'definition', 'subject_type', 'subject_id', 'facts'],
                    'properties' => [
                        'run_id' => ['type' => 'string'],
                        'definition' => ['type' => 'object'],
                        'subject_type' => ['type' => 'string'],
                        'subject_id' => ['type' => 'string'],
                        'facts' => ['type' => 'object'],
                        'jurisdiction' => ['type' => ['string', 'null']],
                    ],
                    'additionalProperties' => false,
                ],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['run', 'knowledge_bindings', 'findings', 'governance', 'human_reviews', 'remediation_intents', 'integration_receipts', 'authority'],
                    'properties' => [
                        'run' => ['type' => 'object'],
                        'knowledge_bindings' => ['type' => 'array'],
                        'findings' => ['type' => 'array'],
                        'governance' => ['type' => 'array'],
                        'human_reviews' => ['type' => 'array'],
                        'remediation_intents' => ['type' => 'array'],
                        'integration_receipts' => ['type' => 'array'],
                        'authority' => ['type' => 'object'],
                    ],
                    'additionalProperties' => false,
                ],
                riskClass: 'medium',
                idempotency: 'run-id',
                approvalMode: 'none',
                mutation: true,
            ),
            'shield.review.determine' => new CapabilityDefinition(
                name: 'shield.review.determine',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['review_id', 'finding'],
                    'properties' => [
                        'review_id' => ['type' => 'string'],
                        'finding' => ['type' => 'object'],
                        'reviewer_role' => ['type' => 'string'],
                        'due_at' => ['type' => ['string', 'null']],
                    ],
                    'additionalProperties' => false,
                ],
                outputSchema: ['type' => 'object', 'additionalProperties' => true],
                riskClass: 'high',
                idempotency: 'review-id',
                approvalMode: 'human-review-record',
                mutation: true,
            ),
            'shield.authority.constraint' => new CapabilityDefinition(
                name: 'shield.authority.constraint',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['finding', 'agent_id', 'capability'],
                    'properties' => [
                        'finding' => ['type' => 'object'],
                        'agent_id' => ['type' => 'string'],
                        'capability' => ['type' => 'string'],
                        'capability_variant' => ['type' => ['string', 'null']],
                        'vertical' => ['type' => ['string', 'null']],
                        'workflow' => ['type' => ['string', 'null']],
                        'context' => ['type' => ['string', 'null']],
                        'policy_version' => ['type' => 'string'],
                    ],
                    'additionalProperties' => false,
                ],
                outputSchema: ['type' => 'object', 'additionalProperties' => true],
                riskClass: 'high',
                idempotency: 'deterministic-content-hash',
                approvalMode: 'constraint-only',
                mutation: false,
            ),
            'shield.remediation.prepare' => new CapabilityDefinition(
                name: 'shield.remediation.prepare',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['intent_id', 'finding', 'remediation_type'],
                    'properties' => [
                        'intent_id' => ['type' => 'string'],
                        'finding' => ['type' => 'object'],
                        'remediation_type' => ['type' => 'string'],
                        'requested_capability' => ['type' => ['string', 'null']],
                        'payload' => ['type' => 'object'],
                    ],
                    'additionalProperties' => false,
                ],
                outputSchema: ['type' => 'object', 'additionalProperties' => true],
                riskClass: 'medium',
                idempotency: 'content-hash',
                approvalMode: 'prepare-only',
                mutation: true,
            ),
            'shield.reinspection.evaluate' => new CapabilityDefinition(
                name: 'shield.reinspection.evaluate',
                inputSchema: [
                    'type' => 'object',
                    'required' => ['reinspection_id', 'original_run_id', 'reinspection_run_id', 'finding', 'definition', 'facts'],
                    'properties' => [
                        'reinspection_id' => ['type' => 'string'],
                        'original_run_id' => ['type' => 'string'],
                        'reinspection_run_id' => ['type' => 'string'],
                        'finding' => ['type' => 'object'],
                        'definition' => ['type' => 'object'],
                        'facts' => ['type' => 'object'],
                        'jurisdiction' => ['type' => ['string', 'null']],
                        'assurance_evidence' => ['type' => 'array', 'items' => ['type' => 'object']],
                    ],
                    'additionalProperties' => false,
                ],
                outputSchema: [
                    'type' => 'object',
                    'required' => ['request', 'runtime', 'reinspection', 'closure_decision', 'authority'],
                    'properties' => [
                        'request' => ['type' => 'object'],
                        'runtime' => ['type' => 'object'],
                        'reinspection' => ['type' => 'object'],
                        'closure_decision' => ['type' => 'object'],
                        'assurance_clearance' => ['type' => ['object', 'null']],
                        'authority' => ['type' => 'object'],
                    ],
                    'additionalProperties' => false,
                ],
                riskClass: 'high',
                idempotency: 'tenant+reinspection-id',
                approvalMode: 'policy-bound-closure',
                mutation: true,
            ),
        ];
    }

    public function find(string $name): ?CapabilityDefinition
    {
        return $this->all()[$name] ?? null;
    }
}
