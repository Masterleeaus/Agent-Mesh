<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Reinspection;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use InvalidArgumentException;
use JsonSerializable;

final readonly class ReinspectionRecord implements JsonSerializable
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $reinspectionId,
        public string $findingId,
        public string $originalRunId,
        public string $reinspectionRunId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public string $subjectType,
        public string $subjectId,
        public InspectionOutcome $outcome,
        public FindingLifecycleStatus $closureStatus,
        public bool $mayClose,
        public bool $requiresAssurance,
        public bool $requiresHumanReview,
        public array $reasonCodes,
        public string $completedAt,
        public ShieldExecutionContext $context,
    ) {
        foreach ([
            'reinspectionId' => $this->reinspectionId,
            'findingId' => $this->findingId,
            'originalRunId' => $this->originalRunId,
            'reinspectionRunId' => $this->reinspectionRunId,
            'definitionKey' => $this->definitionKey,
            'definitionVersion' => $this->definitionVersion,
            'subjectType' => $this->subjectType,
            'subjectId' => $this->subjectId,
            'completedAt' => $this->completedAt,
        ] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $this->definitionHash) !== 1) {
            throw new InvalidArgumentException('definitionHash must be SHA-256 hex.');
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'reinspection_id' => $this->reinspectionId,
            'finding_id' => $this->findingId,
            'original_run_id' => $this->originalRunId,
            'reinspection_run_id' => $this->reinspectionRunId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'outcome' => $this->outcome->value,
            'closure_status' => $this->closureStatus->value,
            'may_close' => $this->mayClose,
            'requires_assurance' => $this->requiresAssurance,
            'requires_human_review' => $this->requiresHumanReview,
            'reason_codes' => $this->reasonCodes,
            'completed_at' => $this->completedAt,
            'context' => $this->context->toArray(),
        ];
    }
}
