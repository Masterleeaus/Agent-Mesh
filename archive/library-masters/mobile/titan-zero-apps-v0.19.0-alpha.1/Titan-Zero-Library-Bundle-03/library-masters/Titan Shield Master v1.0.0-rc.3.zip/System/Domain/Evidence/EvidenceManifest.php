<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Evidence;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use JsonSerializable;

final readonly class EvidenceManifest implements JsonSerializable
{
    /** @param array<string,scalar|null> $metadata */
    public function __construct(
        public string $evidenceId,
        public string $evidenceKey,
        public string $originalFilename,
        public string $mimeType,
        public int $sizeBytes,
        public string $sha256,
        public string $capturedAt,
        public ?string $captureDeviceId,
        public string $storageReference,
        public array $metadata,
        public ShieldExecutionContext $context,
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'evidence_id' => $this->evidenceId,
            'evidence_key' => $this->evidenceKey,
            'original_filename' => $this->originalFilename,
            'mime_type' => $this->mimeType,
            'size_bytes' => $this->sizeBytes,
            'sha256' => $this->sha256,
            'captured_at' => $this->capturedAt,
            'capture_device_id' => $this->captureDeviceId,
            'storage_reference' => $this->storageReference,
            'metadata' => $this->metadata,
            'context' => $this->context->toArray(),
        ];
    }
}
