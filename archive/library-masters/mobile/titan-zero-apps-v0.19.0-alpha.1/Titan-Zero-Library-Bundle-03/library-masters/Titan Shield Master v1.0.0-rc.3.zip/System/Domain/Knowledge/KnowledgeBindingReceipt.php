<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Knowledge;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use InvalidArgumentException;
use JsonSerializable;

final readonly class KnowledgeBindingReceipt implements JsonSerializable
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $bindingId,
        public string $runId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public string $verticalKey,
        public string $jurisdiction,
        public string $knowledgeKey,
        public string $authorityDomain,
        public string $status,
        public string $bindingMode,
        public bool $blocking,
        public ?string $resolvedVersion,
        public ?string $resolvedHash,
        public array $reasonCodes,
        public ShieldExecutionContext $context,
    ) {
        foreach (['bindingId' => $bindingId, 'runId' => $runId, 'definitionKey' => $definitionKey, 'definitionVersion' => $definitionVersion, 'definitionHash' => $definitionHash, 'verticalKey' => $verticalKey, 'jurisdiction' => $jurisdiction, 'knowledgeKey' => $knowledgeKey, 'authorityDomain' => $authorityDomain] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (! in_array($status, ['BOUND', 'UNRESOLVED'], true)) {
            throw new InvalidArgumentException('Knowledge binding status is invalid.');
        }
        if (! in_array($bindingMode, ['LIVE', 'PINNED', 'NONE'], true)) {
            throw new InvalidArgumentException('Knowledge binding mode is invalid.');
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $definitionHash) !== 1) {
            throw new InvalidArgumentException('definitionHash must be SHA-256 hex.');
        }
        if ($resolvedHash !== null && preg_match('/^[a-f0-9]{64}$/i', $resolvedHash) !== 1) {
            throw new InvalidArgumentException('resolvedHash must be SHA-256 hex when supplied.');
        }
        if ($reasonCodes === []) {
            throw new InvalidArgumentException('Knowledge binding receipt requires reason codes.');
        }
    }

    public function jsonSerialize(): array
    {
        return [
            'binding_id' => $this->bindingId,
            'run_id' => $this->runId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'vertical_key' => $this->verticalKey,
            'jurisdiction' => $this->jurisdiction,
            'knowledge_key' => $this->knowledgeKey,
            'authority_domain' => $this->authorityDomain,
            'status' => $this->status,
            'binding_mode' => $this->bindingMode,
            'blocking' => $this->blocking,
            'resolved_version' => $this->resolvedVersion,
            'resolved_hash' => $this->resolvedHash,
            'reason_codes' => $this->reasonCodes,
            'context' => $this->context->toArray(),
        ];
    }
}
