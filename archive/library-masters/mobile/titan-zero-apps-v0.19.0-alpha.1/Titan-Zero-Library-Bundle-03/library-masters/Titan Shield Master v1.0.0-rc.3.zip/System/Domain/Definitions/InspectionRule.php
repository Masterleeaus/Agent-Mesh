<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Definitions;

use InvalidArgumentException;
use JsonSerializable;

final readonly class InspectionRule implements JsonSerializable
{
    public const TYPES = [
        'evidence_present',
        'min_file_size',
        'mime_allowed',
        'metadata_present',
        'regex_match',
        'numeric_compare',
        'checklist_all',
        'checklist_any',
        'checklist_minimum',
    ];

    public const SEVERITIES = ['info', 'low', 'medium', 'high', 'critical'];

    /** @param array<string,mixed> $parameters */
    public function __construct(
        public string $ruleKey,
        public string $ruleType,
        public array $parameters,
        public bool $required,
        public string $failureSeverity,
        public ?string $knowledgeReference = null,
    ) {
        if (preg_match('/^[a-z0-9][a-z0-9._-]{0,119}$/', $this->ruleKey) !== 1) {
            throw new InvalidArgumentException('rule_key must be a stable lowercase identifier.');
        }
        if (! in_array($this->ruleType, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported deterministic rule_type: ' . $this->ruleType);
        }
        if (! in_array($this->failureSeverity, self::SEVERITIES, true)) {
            throw new InvalidArgumentException('failure_severity is invalid.');
        }
        if ($this->knowledgeReference !== null && trim($this->knowledgeReference) === '') {
            throw new InvalidArgumentException('knowledge_reference must be non-empty when supplied.');
        }
    }

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        return new self(
            ruleKey: (string) ($payload['rule_key'] ?? ''),
            ruleType: (string) ($payload['rule_type'] ?? ''),
            parameters: is_array($payload['parameters'] ?? null) ? $payload['parameters'] : [],
            required: (bool) ($payload['required'] ?? false),
            failureSeverity: (string) ($payload['failure_severity'] ?? ''),
            knowledgeReference: isset($payload['knowledge_reference']) ? (string) $payload['knowledge_reference'] : null,
        );
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'rule_key' => $this->ruleKey,
            'rule_type' => $this->ruleType,
            'parameters' => $this->parameters,
            'required' => $this->required,
            'failure_severity' => $this->failureSeverity,
            'knowledge_reference' => $this->knowledgeReference,
        ];
    }
}
