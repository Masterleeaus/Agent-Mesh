<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;

interface ShieldFindingFeedContract
{
    /** @return array<string,mixed> */
    public function forRisk(Finding $finding, GovernanceResponse $response): array;

    /** @return array<string,mixed> */
    public function forAssurance(Finding $finding, GovernanceResponse $response): array;
}
