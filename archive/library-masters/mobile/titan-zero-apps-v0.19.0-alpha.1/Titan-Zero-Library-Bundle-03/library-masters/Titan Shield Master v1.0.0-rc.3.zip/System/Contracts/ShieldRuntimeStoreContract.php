<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;

interface ShieldRuntimeStoreContract
{
    public function recordDefinition(InspectionDefinition $definition, ShieldExecutionContext $context): void;

    public function recordEvidence(EvidenceManifest $manifest): void;

    public function recordRun(InspectionRun $run): void;

    /** @param array<string,mixed>|null $governanceResponse */
    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void;

    public function recordReview(HumanReviewRequest $review): void;

    public function recordRemediationIntent(RemediationIntent $intent): void;

    public function recordReinspection(ReinspectionRecord $reinspection): void;

    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void;

    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void;

    /** @param list<string> $reasonCodes */
    public function applyFindingLifecycle(
        string $findingId,
        FindingLifecycleStatus $targetStatus,
        array $reasonCodes,
        ShieldExecutionContext $context,
        ?string $reinspectionId = null,
        ?string $reinspectionRunId = null,
    ): void;

    /** @param array<string,mixed> $receipt */
    public function recordIntegrationReceipt(array $receipt): void;
}
