<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Contracts\AssuranceClearancePortContract;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use LogicException;

final class ReinspectionCoordinator
{
    public function __construct(
        private readonly InspectionRuntimeCoordinator $runtime,
        private readonly ReinspectionService $service,
        private readonly ShieldRuntimeStoreContract $store,
        private readonly SignalEngineAdapter $signal,
        private readonly ?AssuranceClearancePortContract $assurance = null,
        private readonly ?AssuranceClearanceNormalizer $assuranceNormalizer = null,
    ) {}

    /** @param array<string,mixed> $facts @return array<string,mixed> */
    public function execute(
        string $reinspectionId,
        string $originalRunId,
        string $reinspectionRunId,
        Finding $finding,
        InspectionDefinition $definition,
        array $facts,
        ShieldExecutionContext $context,
        ?string $startedAt = null,
        ?string $completedAt = null,
        array $assuranceEvidence = [],
        ?string $jurisdiction = null,
    ): array {
        if ($finding->context->companyId !== $context->companyId) {
            throw new LogicException('Reinspection tenant context must match the original finding tenant.');
        }

        $request = $this->service->prepare($reinspectionId, $originalRunId, $finding, $definition);
        $runtime = $this->runtime->execute(
            runId: $reinspectionRunId,
            definition: $definition,
            subjectType: $finding->subjectType,
            subjectId: $finding->subjectId,
            facts: $facts,
            context: $context,
            startedAt: $startedAt,
            completedAt: $completedAt,
            jurisdiction: $jurisdiction,
        );

        $runPayload = is_array($runtime['run'] ?? null) ? $runtime['run'] : [];
        $record = $this->service->complete($request, $finding, $runPayload);
        $assuranceClearance = null;
        $assuranceResponse = null;

        if ($record->requiresAssurance) {
            $assuranceResponse = $this->assurance?->assess(
                finding: $finding,
                evidence: $assuranceEvidence,
                requirements: array_map(static fn ($requirement): array => $requirement->jsonSerialize(), $definition->evidenceRequirements),
                knowledgeReferences: array_map(static fn ($reference): array => $reference->jsonSerialize(), $definition->knowledgeReferences),
                vertical: $definition->verticalKey,
                jurisdiction: $jurisdiction,
            ) ?? [
                'status' => 'UNAVAILABLE',
                'engine' => 'titan-assurance',
                'reason_code' => 'ASSURANCE_CLEARANCE_PORT_UNAVAILABLE',
            ];

            $normalizer = $this->assuranceNormalizer ?? new AssuranceClearanceNormalizer();
            $assuranceClearance = $normalizer->normalize(
                finding: $finding,
                evidence: $assuranceEvidence,
                response: $assuranceResponse,
                reinspectionId: $record->reinspectionId,
                reinspectionRunId: $record->reinspectionRunId,
                assessedAt: $record->completedAt,
            );
            $this->store->recordAssuranceClearance($assuranceClearance, $context);

            $assuranceReceipt = $this->integrationReceipt(
                target: 'titan-assurance',
                eventType: 'shield.finding.assurance_clearance',
                payload: [
                    'finding_id' => $record->findingId,
                    'reinspection_id' => $record->reinspectionId,
                    'reinspection_run_id' => $record->reinspectionRunId,
                    'evidence_fingerprint' => $assuranceClearance->evidenceFingerprint,
                ],
                response: $assuranceClearance->jsonSerialize(),
                context: $context,
                seed: $assuranceClearance->clearanceId,
                status: $assuranceClearance->decision,
            );
            $this->store->recordIntegrationReceipt($assuranceReceipt);

            $finalStatus = $assuranceClearance->mayClose ? FindingLifecycleStatus::Closed : FindingLifecycleStatus::Held;
            $finalReasons = array_values(array_unique(array_merge($record->reasonCodes, $assuranceClearance->reasonCodes)));
            $record = new ReinspectionRecord(
                reinspectionId: $record->reinspectionId,
                findingId: $record->findingId,
                originalRunId: $record->originalRunId,
                reinspectionRunId: $record->reinspectionRunId,
                definitionKey: $record->definitionKey,
                definitionVersion: $record->definitionVersion,
                definitionHash: $record->definitionHash,
                subjectType: $record->subjectType,
                subjectId: $record->subjectId,
                outcome: $record->outcome,
                closureStatus: $finalStatus,
                mayClose: $assuranceClearance->mayClose,
                requiresAssurance: true,
                requiresHumanReview: $record->requiresHumanReview,
                reasonCodes: $finalReasons,
                completedAt: $record->completedAt,
                context: $record->context,
            );
        }

        $this->store->recordReinspection($record);
        $this->store->applyFindingLifecycle(
            findingId: $finding->findingId,
            targetStatus: $record->closureStatus,
            reasonCodes: $record->reasonCodes,
            context: $context,
            reinspectionId: $record->reinspectionId,
            reinspectionRunId: $record->reinspectionRunId,
        );

        $eventType = $record->mayClose ? 'shield.finding.closed' : 'shield.finding.closure_held';
        $signal = $this->signal->buildSignal(
            eventType: 'shield.reinspection.completed',
            payload: [
                'reinspection_id' => $record->reinspectionId,
                'finding_id' => $record->findingId,
                'original_run_id' => $record->originalRunId,
                'reinspection_run_id' => $record->reinspectionRunId,
                'definition_key' => $record->definitionKey,
                'definition_version' => $record->definitionVersion,
                'definition_hash' => $record->definitionHash,
                'subject_type' => $record->subjectType,
                'subject_id' => $record->subjectId,
                'outcome' => $record->outcome->value,
                'closure_status' => $record->closureStatus->value,
                'may_close' => $record->mayClose,
                'requires_assurance' => $record->requiresAssurance,
                'requires_human_review' => $record->requiresHumanReview,
                'reason_codes' => $record->reasonCodes,
                'occurred_at' => $record->completedAt,
            ],
            context: $context,
            subjectId: $record->subjectId,
            verticalKey: $definition->verticalKey,
        );
        $signalResponse = $this->signal->emit($signal);
        $signalReceipt = $this->integrationReceipt(
            target: 'titan-signal',
            eventType: 'shield.reinspection.completed',
            payload: $signal,
            response: $signalResponse,
            context: $context,
            seed: $record->reinspectionId,
        );
        $this->store->recordIntegrationReceipt($signalReceipt);

        $closureSignal = $this->signal->buildSignal(
            eventType: $eventType,
            payload: [
                'reinspection_id' => $record->reinspectionId,
                'finding_id' => $record->findingId,
                'reinspection_run_id' => $record->reinspectionRunId,
                'status' => $record->closureStatus->value,
                'reason_codes' => $record->reasonCodes,
                'occurred_at' => $record->completedAt,
            ],
            context: $context,
            subjectId: $record->subjectId,
            verticalKey: $definition->verticalKey,
        );
        $closureSignalResponse = $this->signal->emit($closureSignal);
        $closureSignalReceipt = $this->integrationReceipt(
            target: 'titan-signal',
            eventType: $eventType,
            payload: $closureSignal,
            response: $closureSignalResponse,
            context: $context,
            seed: $record->findingId . '|' . $record->reinspectionId,
        );
        $this->store->recordIntegrationReceipt($closureSignalReceipt);

        $rewindPayload = [
            'receipt_type' => 'shield.finding.lifecycle',
            'finding_id' => $record->findingId,
            'reinspection_id' => $record->reinspectionId,
            'original_run_id' => $record->originalRunId,
            'reinspection_run_id' => $record->reinspectionRunId,
            'definition_key' => $record->definitionKey,
            'definition_version' => $record->definitionVersion,
            'definition_hash' => $record->definitionHash,
            'outcome' => $record->outcome->value,
            'target_status' => $record->closureStatus->value,
            'reason_codes' => $record->reasonCodes,
            'hidden_chain_of_thought_included' => false,
        ];
        $rewindReceipt = $this->integrationReceipt(
            target: 'titan-rewind',
            eventType: $eventType,
            payload: $rewindPayload,
            response: [
                'status' => 'RECORDED_LOCAL',
                'reason_code' => 'REWIND_PUBLIC_WRITE_CONTRACT_UNAVAILABLE',
            ],
            context: $context,
            seed: $record->findingId . '|' . $record->reinspectionId . '|rewind',
            status: 'RECORDED_LOCAL',
        );
        $this->store->recordIntegrationReceipt($rewindReceipt);

        return [
            'request' => $request->jsonSerialize(),
            'runtime' => $runtime,
            'reinspection' => $record->jsonSerialize(),
            'closure_decision' => [
                'may_close' => $record->mayClose,
                'target_status' => $record->closureStatus->value,
                'requires_assurance' => $record->requiresAssurance,
                'requires_human_review' => $record->requiresHumanReview,
                'reason_codes' => $record->reasonCodes,
            ],
            'assurance_clearance' => $assuranceClearance?->jsonSerialize(),
            'authority' => [
                'direct_business_mutation' => false,
                'finding_state_authority' => 'titan-shield',
                'command_execution_authority' => 'titan-command-bus',
                'high_critical_closure_mode' => 'held_until_normalized_assurance_clearance',
            ],
        ];
    }

    /** @param array<string,mixed> $payload @param array<string,mixed> $response @return array<string,mixed> */
    private function integrationReceipt(
        string $target,
        string $eventType,
        array $payload,
        array $response,
        ShieldExecutionContext $context,
        string $seed,
        ?string $status = null,
    ): array {
        $status ??= (string) ($response['status'] ?? 'UNKNOWN');
        $idempotencyKey = hash('sha256', implode('|', [$target, $eventType, $seed, $context->traceId]));

        return [
            'receipt_id' => hash('sha256', 'receipt|' . $idempotencyKey),
            'target' => $target,
            'event_type' => $eventType,
            'status' => $status,
            'idempotency_key' => $idempotencyKey,
            'payload' => $payload,
            'response' => $response,
            'company_id' => $context->companyId,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'root_causation_id' => $context->rootCausationId ?? $context->causationId,
            'actor_user_id' => $context->actorUserId,
            'source' => $context->source,
        ];
    }
}
