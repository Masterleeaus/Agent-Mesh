<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use LogicException;

final class InspectionDefinitionRegistry
{
    /** @var array<string,array<string,InspectionDefinition>> */
    private array $definitions = [];

    public function __construct(private readonly ?ShieldRuntimeStoreContract $store = null) {}

    public function register(InspectionDefinition $definition, ?ShieldExecutionContext $context = null): void
    {
        $existing = $this->definitions[$definition->key()][$definition->version()] ?? null;
        if ($existing !== null) {
            if (! hash_equals($existing->definitionHash(), $definition->definitionHash())) {
                throw new LogicException('Inspection definition key/version is immutable once registered.');
            }
            if ($context !== null) {
                $this->store?->recordDefinition($definition, $context);
            }
            return;
        }

        $this->definitions[$definition->key()][$definition->version()] = $definition;
        if ($context !== null) {
            $this->store?->recordDefinition($definition, $context);
        }
    }

    public function find(string $key, string $version): ?InspectionDefinition
    {
        return $this->definitions[$key][$version] ?? null;
    }

    public function latest(string $key): ?InspectionDefinition
    {
        $versions = $this->definitions[$key] ?? [];
        if ($versions === []) {
            return null;
        }

        uksort($versions, static fn (string $left, string $right): int => version_compare($right, $left));
        return reset($versions) ?: null;
    }

    /** @return list<InspectionDefinition> */
    public function all(): array
    {
        $result = [];
        foreach ($this->definitions as $versions) {
            foreach ($versions as $definition) {
                $result[] = $definition;
            }
        }
        return $result;
    }
}
