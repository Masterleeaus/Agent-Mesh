<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Reinspection;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use InvalidArgumentException;
use JsonSerializable;

final readonly class ReinspectionRequest implements JsonSerializable
{
    public function __construct(
        public string $reinspectionId,
        public string $findingId,
        public string $originalRunId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public string $subjectType,
        public string $subjectId,
        public string $status,
        public ShieldExecutionContext $context,
    ) {
        foreach ([
            'reinspectionId' => $this->reinspectionId,
            'findingId' => $this->findingId,
            'originalRunId' => $this->originalRunId,
            'definitionKey' => $this->definitionKey,
            'definitionVersion' => $this->definitionVersion,
            'subjectType' => $this->subjectType,
            'subjectId' => $this->subjectId,
        ] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $this->definitionHash) !== 1) {
            throw new InvalidArgumentException('definitionHash must be SHA-256 hex.');
        }
        if ($this->status !== 'REQUESTED') {
            throw new InvalidArgumentException('ReinspectionRequest status must be REQUESTED.');
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'reinspection_id' => $this->reinspectionId,
            'finding_id' => $this->findingId,
            'original_run_id' => $this->originalRunId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'status' => $this->status,
            'context' => $this->context->toArray(),
        ];
    }
}
