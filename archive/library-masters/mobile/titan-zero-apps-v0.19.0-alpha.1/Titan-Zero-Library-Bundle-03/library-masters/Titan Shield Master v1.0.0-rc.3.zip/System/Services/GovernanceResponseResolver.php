<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceAction;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;

final class GovernanceResponseResolver
{
    public function resolve(Finding $finding): GovernanceResponse
    {
        if ($finding->outcome === InspectionOutcome::Pass) {
            return new GovernanceResponse(
                actions: [GovernanceAction::Continue],
                blockProgression: false,
                requiresHumanReview: false,
                requestRisk: false,
                requestAssurance: false,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['inspection_passed'],
            );
        }

        if ($finding->outcome === InspectionOutcome::Inconclusive) {
            return new GovernanceResponse(
                actions: [GovernanceAction::RequireMoreEvidence],
                blockProgression: true,
                requiresHumanReview: $finding->severity->rank() >= FindingSeverity::High->rank(),
                requestRisk: $finding->severity->rank() >= FindingSeverity::High->rank(),
                requestAssurance: true,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['inspection_inconclusive'],
            );
        }

        return match ($finding->severity) {
            FindingSeverity::Info => new GovernanceResponse(
                actions: [GovernanceAction::Continue],
                blockProgression: false,
                requiresHumanReview: false,
                requestRisk: false,
                requestAssurance: false,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['informational_finding'],
            ),
            FindingSeverity::Low => new GovernanceResponse(
                actions: [GovernanceAction::RecordAndContinue],
                blockProgression: false,
                requiresHumanReview: false,
                requestRisk: false,
                requestAssurance: false,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['low_severity_finding'],
            ),
            FindingSeverity::Medium => new GovernanceResponse(
                actions: [GovernanceAction::RequestRemediation],
                blockProgression: $finding->outcome !== InspectionOutcome::ConditionalPass,
                requiresHumanReview: false,
                requestRisk: false,
                requestAssurance: false,
                requestCommandBus: true,
                requestCouncil: false,
                reasonCodes: ['medium_finding_requires_remediation'],
            ),
            FindingSeverity::High => new GovernanceResponse(
                actions: [GovernanceAction::BlockForRiskAssurance],
                blockProgression: true,
                requiresHumanReview: false,
                requestRisk: true,
                requestAssurance: true,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['high_finding_requires_governance_evaluation'],
            ),
            FindingSeverity::Critical => new GovernanceResponse(
                actions: [GovernanceAction::RequireHumanReview],
                blockProgression: true,
                requiresHumanReview: true,
                requestRisk: true,
                requestAssurance: true,
                requestCommandBus: false,
                requestCouncil: false,
                reasonCodes: ['critical_finding_fail_closed'],
            ),
        };
    }
}
