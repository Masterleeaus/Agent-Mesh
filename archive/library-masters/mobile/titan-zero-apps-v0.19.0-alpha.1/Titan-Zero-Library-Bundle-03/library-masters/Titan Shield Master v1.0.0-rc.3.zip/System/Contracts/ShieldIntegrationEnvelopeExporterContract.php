<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;

interface ShieldIntegrationEnvelopeExporterContract extends ShieldFindingFeedContract
{
    /** @return array<string,mixed> */
    public function forCommandBus(Finding $finding, GovernanceResponse $response): array;

    /** @return array<string,mixed> */
    public function forCouncil(Finding $finding, GovernanceResponse $response): array;
}
