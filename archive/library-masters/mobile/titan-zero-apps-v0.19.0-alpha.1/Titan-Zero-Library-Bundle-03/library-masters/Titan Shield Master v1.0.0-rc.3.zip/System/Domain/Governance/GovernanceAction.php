<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Governance;

enum GovernanceAction: string
{
    case Continue = 'continue';
    case RecordAndContinue = 'record_and_continue';
    case RequestRemediation = 'request_remediation';
    case BlockForRiskAssurance = 'block_for_risk_assurance';
    case RequireHumanReview = 'require_human_review';
    case RequireMoreEvidence = 'require_more_evidence';
    case CouncilEscalationEligible = 'council_escalation_eligible';
}
