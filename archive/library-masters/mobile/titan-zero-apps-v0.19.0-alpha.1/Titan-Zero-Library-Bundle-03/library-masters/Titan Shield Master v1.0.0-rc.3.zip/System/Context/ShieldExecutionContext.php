<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Context;

use InvalidArgumentException;

final readonly class ShieldExecutionContext
{
    public function __construct(
        public int $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public ?int $actorUserId = null,
        public string $source = 'system',
        public ?string $rootCausationId = null,
    ) {
        if ($this->companyId <= 0) {
            throw new InvalidArgumentException('company_id must be a positive integer.');
        }

        foreach ([
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId ?? $this->causationId,
        ] as $field => $value) {
            if (! self::isUuid($value)) {
                throw new InvalidArgumentException($field . ' must be a valid UUID.');
            }
        }

        if ($this->actorUserId !== null && $this->actorUserId <= 0) {
            throw new InvalidArgumentException('actor_user_id must be positive when supplied.');
        }

        if (trim($this->source) === '') {
            throw new InvalidArgumentException('source must not be empty.');
        }
    }

    /** @return array{company_id:int,trace_id:string,correlation_id:string,causation_id:string,root_causation_id:string,actor_user_id:?int,source:string} */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId ?? $this->causationId,
            'actor_user_id' => $this->actorUserId,
            'source' => $this->source,
        ];
    }

    private static function isUuid(string $value): bool
    {
        return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $value) === 1;
    }
}
