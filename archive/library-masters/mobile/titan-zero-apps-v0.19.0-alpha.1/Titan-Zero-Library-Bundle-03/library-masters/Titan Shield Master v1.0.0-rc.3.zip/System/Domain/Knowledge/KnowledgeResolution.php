<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Knowledge;

use JsonSerializable;

final readonly class KnowledgeResolution implements JsonSerializable
{
    /** @param array<string,mixed> $reference @param array<string,mixed>|null $authorityResponse */
    public function __construct(
        public string $status,
        public array $reference,
        public string $reasonCode,
        public ?string $resolvedVersion = null,
        public ?string $resolvedHash = null,
        public ?array $authorityResponse = null,
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'status' => $this->status,
            'reference' => $this->reference,
            'reason_code' => $this->reasonCode,
            'resolved_version' => $this->resolvedVersion,
            'resolved_hash' => $this->resolvedHash,
            'authority_response' => $this->authorityResponse,
        ];
    }
}
