<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Integrations;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;

final class RiskEngineAdapter
{
    /** @param array<string,int|float> $impactHints @return array<string,mixed> */
    public function buildRequest(Finding $finding, array $impactHints = [], ?string $verticalKey = null, ?string $jurisdiction = null): array
    {
        $impact = [
            'financial' => 0.0,
            'safety' => 0.0,
            'privacy' => 0.0,
            'legal' => 0.0,
            'operational' => $this->severityOperationalHint($finding),
            'reputation' => 0.0,
        ];

        foreach ($impactHints as $dimension => $value) {
            if (array_key_exists($dimension, $impact) && is_numeric($value)) {
                $impact[$dimension] = max(0.0, min(100.0, (float) $value));
            }
        }

        $context = $finding->context;

        return [
            'company_id' => $context->companyId,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'capability' => 'shield.finding.evaluate',
            'action' => 'shield_finding_governance',
            'actor_type' => $context->actorUserId !== null ? 'user' : 'system',
            'claimed_actor_id' => $context->actorUserId,
            'resource_type' => 'shield_finding',
            'resource_id' => $finding->findingId,
            'vertical_key' => $verticalKey,
            'jurisdiction' => $jurisdiction,
            'impact' => $impact,
            'reversibility' => 'REVERSIBLE',
            'connectivity' => 'ONLINE',
            'metadata' => [
                'source' => 'titan-shield',
                'shield_severity' => $finding->severity->value,
                'shield_outcome' => $finding->outcome->value,
                'definition_key' => $finding->definitionKey,
                'definition_version' => $finding->definitionVersion,
                'definition_hash' => $finding->definitionHash,
                'reason_codes' => $finding->reasonCodes,
                'evidence_ids' => $finding->evidenceIds,
                'shield_severity_is_not_risk_level' => true,
            ],
        ];
    }

    /** @param array<string,int|float> $impactHints @return array<string,mixed> */
    public function assess(Finding $finding, array $impactHints = [], ?string $verticalKey = null, ?string $jurisdiction = null): array
    {
        $request = $this->buildRequest($finding, $impactHints, $verticalKey, $jurisdiction);
        if (! function_exists('app')) {
            return $this->unavailable($request, 'LARAVEL_CONTAINER_UNAVAILABLE');
        }

        try {
            $container = app();
            $gateContract = 'App\\Extensions\\TitanRiskEngine\\System\\Contracts\\RiskGateContract';
            $inputClass = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskContextInput';
            if (method_exists($container, 'bound') && $container->bound($gateContract) && class_exists($inputClass)) {
                $input = $this->newRiskInput($request, $inputClass);
                $result = $container->make($gateContract)->evaluate($input);

                return [
                    'status' => 'OK',
                    'engine' => 'titan-risk',
                    'contract' => 'RiskGateContract',
                    'request' => $request,
                    'result' => method_exists($result, 'toArray') ? $result->toArray() : ['value' => $result],
                ];
            }

            $managerContract = 'App\\Extensions\\TitanRiskEngine\\System\\Contracts\\RiskManagerContract';
            $contextClass = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskContext';
            if (method_exists($container, 'bound') && $container->bound($managerContract) && class_exists($contextClass)) {
                $riskContext = $this->newRiskContext($request, $contextClass);
                $result = $container->make($managerContract)->assess($riskContext);

                return [
                    'status' => 'OK',
                    'engine' => 'titan-risk',
                    'contract' => 'RiskManagerContract',
                    'request' => $request,
                    'result' => method_exists($result, 'toArray') ? $result->toArray() : ['value' => $result],
                ];
            }
        } catch (\Throwable $exception) {
            return [
                'status' => 'ERROR',
                'engine' => 'titan-risk',
                'reason_code' => 'RISK_ADAPTER_FAILURE',
                'error_type' => $exception::class,
                'request' => $request,
            ];
        }

        return $this->unavailable($request, 'RISK_PUBLIC_CONTRACT_UNAVAILABLE');
    }

    /** @param array<string,mixed> $request */
    private function newRiskInput(array $request, string $inputClass): object
    {
        $impactClass = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskImpactVector';
        $reversibilityClass = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\Reversibility';
        $connectivityClass = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\ConnectivityState';
        $impact = new $impactClass(
            $request['impact']['financial'],
            $request['impact']['safety'],
            $request['impact']['privacy'],
            $request['impact']['legal'],
            $request['impact']['operational'],
            $request['impact']['reputation'],
        );

        return new $inputClass(
            $request['company_id'],
            $request['trace_id'],
            $request['correlation_id'],
            $request['causation_id'],
            $request['capability'],
            $request['action'],
            $request['actor_type'],
            $request['claimed_actor_id'],
            $request['resource_type'],
            $request['resource_id'],
            $request['vertical_key'],
            $request['jurisdiction'],
            $impact,
            $reversibilityClass::REVERSIBLE,
            $connectivityClass::ONLINE,
            $request['metadata'],
        );
    }

    /** @param array<string,mixed> $request */
    private function newRiskContext(array $request, string $contextClass): object
    {
        $impactClass = 'App\\Extensions\\TitanRiskEngine\\System\\ValueObjects\\RiskImpactVector';
        $reversibilityClass = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\Reversibility';
        $connectivityClass = 'App\\Extensions\\TitanRiskEngine\\System\\Enums\\ConnectivityState';
        $impact = new $impactClass(
            $request['impact']['financial'],
            $request['impact']['safety'],
            $request['impact']['privacy'],
            $request['impact']['legal'],
            $request['impact']['operational'],
            $request['impact']['reputation'],
        );

        return new $contextClass(
            $request['company_id'],
            $request['trace_id'],
            $request['correlation_id'],
            $request['causation_id'],
            $request['capability'],
            $request['action'],
            $request['actor_type'],
            $request['claimed_actor_id'],
            $request['resource_type'],
            $request['resource_id'],
            $request['vertical_key'],
            $request['jurisdiction'],
            $impact,
            $reversibilityClass::REVERSIBLE,
            $connectivityClass::ONLINE,
            [],
            $request['metadata'],
        );
    }

    private function severityOperationalHint(Finding $finding): float
    {
        return match ($finding->severity->value) {
            'info' => 5.0,
            'low' => 15.0,
            'medium' => 35.0,
            'high' => 70.0,
            'critical' => 100.0,
        };
    }

    /** @param array<string,mixed> $request @return array<string,mixed> */
    private function unavailable(array $request, string $reason): array
    {
        return [
            'status' => 'UNAVAILABLE',
            'engine' => 'titan-risk',
            'reason_code' => $reason,
            'request' => $request,
        ];
    }
}
