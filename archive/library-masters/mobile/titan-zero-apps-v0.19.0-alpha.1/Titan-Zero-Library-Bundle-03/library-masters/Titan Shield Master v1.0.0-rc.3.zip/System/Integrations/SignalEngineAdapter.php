<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Integrations;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;

final class SignalEngineAdapter
{
    /** @param array<string,mixed> $payload @return array<string,mixed> */
    public function buildSignal(string $eventType, array $payload, ShieldExecutionContext $context, string $subjectId, ?string $verticalKey = null): array
    {
        $severity = strtolower((string) ($payload['severity'] ?? $payload['finding_severity'] ?? 'info'));
        if (! in_array($severity, ['info', 'low', 'medium', 'high', 'critical'], true)) {
            $severity = 'info';
        }

        return [
            'event_type' => $eventType,
            'occurred_at' => (string) ($payload['occurred_at'] ?? date(DATE_ATOM)),
            'scope' => 'tenant',
            'company_id' => $context->companyId,
            'actor_type' => $context->actorUserId !== null ? 'user' : 'system',
            'actor_id' => $context->actorUserId !== null ? (string) $context->actorUserId : null,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'root_causation_id' => $context->rootCausationId ?? $context->causationId,
            'source' => 'titan-shield',
            'source_component' => 'shield-runtime',
            'schema_version' => 1,
            'payload' => $payload,
            'metadata' => [
                'subject_id' => $subjectId,
                'source_context' => $context->source,
                'hidden_chain_of_thought_included' => false,
            ],
            'severity' => $severity,
            'category' => 'inspection',
            'idempotency_key' => hash('sha256', $eventType . '|' . $subjectId . '|' . $context->traceId),
            'vertical_key' => $verticalKey,
        ];
    }

    /** @param array<string,mixed> $signal @return array<string,mixed> */
    public function emit(array $signal): array
    {
        if (! function_exists('app')) {
            return $this->unavailable($signal, 'LARAVEL_CONTAINER_UNAVAILABLE');
        }

        $contract = 'App\\Extensions\\TitanSignalEngine\\System\\Contracts\\SignalEmitterContract';
        try {
            $container = app();
            if (method_exists($container, 'bound') && $container->bound($contract)) {
                $receipt = $container->make($contract)->emit($signal);
                return [
                    'status' => 'OK',
                    'engine' => 'titan-signal',
                    'contract' => 'SignalEmitterContract',
                    'receipt' => method_exists($receipt, 'toArray') ? $receipt->toArray() : ['event_id' => $receipt->eventId ?? null],
                ];
            }
        } catch (\Throwable $exception) {
            return [
                'status' => 'ERROR',
                'engine' => 'titan-signal',
                'reason_code' => 'SIGNAL_ADAPTER_FAILURE',
                'error_type' => $exception::class,
                'signal' => $signal,
            ];
        }

        return $this->unavailable($signal, 'SIGNAL_PUBLIC_CONTRACT_UNAVAILABLE');
    }

    /** @param array<string,mixed> $signal @return array<string,mixed> */
    private function unavailable(array $signal, string $reason): array
    {
        return [
            'status' => 'UNAVAILABLE',
            'engine' => 'titan-signal',
            'reason_code' => $reason,
            'signal' => $signal,
        ];
    }
}
