<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Receipts\RewindReceipt;

final class RewindReceiptFactory
{
    /** @param array<string,mixed> $governance */
    public function forFinding(Finding $finding, array $governance, ?string $occurredAt = null, ?string $runId = null): RewindReceipt
    {
        $occurredAt ??= date(DATE_ATOM);
        $receiptId = hash('sha256', implode('|', [
            'shield.finding.recorded',
            $finding->findingId,
            $finding->definitionHash,
            $finding->context->traceId,
        ]));

        return new RewindReceipt(
            receiptId: $receiptId,
            eventType: 'shield.finding.recorded',
            subjectType: $finding->subjectType,
            subjectId: $finding->subjectId,
            runId: $runId,
            findingId: $finding->findingId,
            definitionKey: $finding->definitionKey,
            definitionVersion: $finding->definitionVersion,
            definitionHash: $finding->definitionHash,
            evidenceIds: $finding->evidenceIds,
            reasonCodes: $finding->reasonCodes,
            governance: $governance,
            occurredAt: $occurredAt,
            context: $finding->context,
        );
    }
}
