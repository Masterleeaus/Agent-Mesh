<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Receipts;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use JsonSerializable;

final readonly class RewindReceipt implements JsonSerializable
{
    /**
     * @param list<string> $evidenceIds
     * @param list<string> $reasonCodes
     * @param array<string,mixed> $governance
     */
    public function __construct(
        public string $receiptId,
        public string $eventType,
        public string $subjectType,
        public string $subjectId,
        public ?string $runId,
        public ?string $findingId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public array $evidenceIds,
        public array $reasonCodes,
        public array $governance,
        public string $occurredAt,
        public ShieldExecutionContext $context,
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'receipt_id' => $this->receiptId,
            'event_type' => $this->eventType,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'run_id' => $this->runId,
            'finding_id' => $this->findingId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'evidence_ids' => $this->evidenceIds,
            'reason_codes' => $this->reasonCodes,
            'governance' => $this->governance,
            'occurred_at' => $this->occurredAt,
            'context' => $this->context->toArray(),
            'rationale_policy' => 'structured_reason_codes_only',
            'hidden_chain_of_thought_included' => false,
        ];
    }
}
