<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingClosureDecision;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;

final class ReinspectionClosurePolicy
{
    /** @param array<string,mixed> $run */
    public function evaluateSerialized(Finding $finding, array $run, \App\Extensions\TitanShield\System\Context\ShieldExecutionContext $context): FindingClosureDecision
    {
        $scopeMismatch = $finding->context->companyId !== $context->companyId
            || $finding->subjectType !== (string) ($run['subject_type'] ?? '')
            || $finding->subjectId !== (string) ($run['subject_id'] ?? '');
        if ($scopeMismatch) {
            return new FindingClosureDecision(false, FindingLifecycleStatus::Held, false, true, ['REINSPECTION_SCOPE_MISMATCH']);
        }

        if (
            $finding->definitionKey !== (string) ($run['definition_key'] ?? '')
            || $finding->definitionVersion !== (string) ($run['definition_version'] ?? '')
            || preg_match('/^[a-f0-9]{64}$/i', (string) ($run['definition_hash'] ?? '')) !== 1
            || ! hash_equals(strtolower($finding->definitionHash), strtolower((string) $run['definition_hash']))
        ) {
            return new FindingClosureDecision(false, FindingLifecycleStatus::Held, false, true, ['REINSPECTION_DEFINITION_MISMATCH']);
        }

        $outcome = InspectionOutcome::tryFrom(strtolower((string) ($run['outcome'] ?? '')));
        if ($outcome !== InspectionOutcome::Pass) {
            return new FindingClosureDecision(
                false,
                FindingLifecycleStatus::RemediationRequired,
                $finding->severity->rank() >= FindingSeverity::High->rank(),
                $finding->severity === FindingSeverity::Critical,
                ['REINSPECTION_NOT_PASSED'],
            );
        }

        if ($finding->severity->rank() >= FindingSeverity::High->rank()) {
            return new FindingClosureDecision(
                false,
                FindingLifecycleStatus::Held,
                true,
                $finding->severity === FindingSeverity::Critical,
                ['ASSURANCE_CLEARANCE_REQUIRED_FOR_HIGH_SEVERITY_CLOSURE'],
            );
        }

        return new FindingClosureDecision(true, FindingLifecycleStatus::Closed, false, false, ['REINSPECTION_PASSED_EXACT_DEFINITION']);
    }

    public function evaluate(Finding $finding, InspectionRun $reinspectionRun): FindingClosureDecision
    {
        if (
            $finding->context->companyId !== $reinspectionRun->context->companyId
            || $finding->subjectType !== $reinspectionRun->subjectType
            || $finding->subjectId !== $reinspectionRun->subjectId
        ) {
            return new FindingClosureDecision(
                mayClose: false,
                targetStatus: FindingLifecycleStatus::Held,
                requiresAssurance: false,
                requiresHumanReview: true,
                reasonCodes: ['REINSPECTION_SCOPE_MISMATCH'],
            );
        }

        if (
            $finding->definitionKey !== $reinspectionRun->definitionKey
            || $finding->definitionVersion !== $reinspectionRun->definitionVersion
            || ! hash_equals(strtolower($finding->definitionHash), strtolower($reinspectionRun->definitionHash))
        ) {
            return new FindingClosureDecision(
                mayClose: false,
                targetStatus: FindingLifecycleStatus::Held,
                requiresAssurance: false,
                requiresHumanReview: true,
                reasonCodes: ['REINSPECTION_DEFINITION_MISMATCH'],
            );
        }

        if ($reinspectionRun->outcome !== InspectionOutcome::Pass) {
            return new FindingClosureDecision(
                mayClose: false,
                targetStatus: FindingLifecycleStatus::RemediationRequired,
                requiresAssurance: $finding->severity->rank() >= FindingSeverity::High->rank(),
                requiresHumanReview: $finding->severity === FindingSeverity::Critical,
                reasonCodes: ['REINSPECTION_NOT_PASSED'],
            );
        }

        if ($finding->severity->rank() >= FindingSeverity::High->rank()) {
            return new FindingClosureDecision(
                mayClose: false,
                targetStatus: FindingLifecycleStatus::Held,
                requiresAssurance: true,
                requiresHumanReview: $finding->severity === FindingSeverity::Critical,
                reasonCodes: ['ASSURANCE_CLEARANCE_REQUIRED_FOR_HIGH_SEVERITY_CLOSURE'],
            );
        }

        return new FindingClosureDecision(
            mayClose: true,
            targetStatus: FindingLifecycleStatus::Closed,
            requiresAssurance: false,
            requiresHumanReview: false,
            reasonCodes: ['REINSPECTION_PASSED_EXACT_DEFINITION'],
        );
    }
}
