<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Assurance;

use InvalidArgumentException;
use JsonSerializable;

final readonly class AssuranceClearanceDecision implements JsonSerializable
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $clearanceId,
        public string $findingId,
        public string $reinspectionId,
        public string $reinspectionRunId,
        public string $decision,
        public bool $mayClose,
        public ?float $score,
        public ?string $policyVersion,
        public string $evidenceFingerprint,
        public array $reasonCodes,
        public string $assessedAt,
        public array $rawSummary = [],
    ) {
        if (! in_array($this->decision, ['ALLOW', 'HOLD', 'DENY'], true)) {
            throw new InvalidArgumentException('Assurance clearance decision must be ALLOW, HOLD, or DENY.');
        }
        foreach (['clearanceId' => $this->clearanceId, 'findingId' => $this->findingId, 'reinspectionId' => $this->reinspectionId, 'reinspectionRunId' => $this->reinspectionRunId, 'evidenceFingerprint' => $this->evidenceFingerprint, 'assessedAt' => $this->assessedAt] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $this->evidenceFingerprint) !== 1) {
            throw new InvalidArgumentException('evidenceFingerprint must be SHA-256 hex.');
        }
        if ($this->mayClose !== ($this->decision === 'ALLOW')) {
            throw new InvalidArgumentException('mayClose must be true only for ALLOW.');
        }
        if ($this->reasonCodes === []) {
            throw new InvalidArgumentException('Assurance clearance requires reason codes.');
        }
    }

    public function jsonSerialize(): array
    {
        return [
            'clearance_id' => $this->clearanceId,
            'finding_id' => $this->findingId,
            'reinspection_id' => $this->reinspectionId,
            'reinspection_run_id' => $this->reinspectionRunId,
            'decision' => $this->decision,
            'may_close' => $this->mayClose,
            'score' => $this->score,
            'policy_version' => $this->policyVersion,
            'evidence_fingerprint' => $this->evidenceFingerprint,
            'reason_codes' => $this->reasonCodes,
            'assessed_at' => $this->assessedAt,
            'raw_summary' => $this->rawSummary,
        ];
    }
}
