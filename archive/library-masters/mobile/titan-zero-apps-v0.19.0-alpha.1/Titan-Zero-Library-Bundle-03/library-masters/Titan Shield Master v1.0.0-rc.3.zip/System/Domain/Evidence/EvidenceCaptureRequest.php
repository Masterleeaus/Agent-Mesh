<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Evidence;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class EvidenceCaptureRequest
{
    /** @param array<string,scalar|null> $metadata */
    public function __construct(
        public string $evidenceId,
        public string $evidenceKey,
        public string $filePath,
        public string $originalFilename,
        public string $mimeType,
        public string $capturedAt,
        public ?string $captureDeviceId,
        public string $storageReference,
        public array $metadata = [],
    ) {
        foreach (['evidenceId' => $this->evidenceId, 'evidenceKey' => $this->evidenceKey, 'originalFilename' => $this->originalFilename, 'storageReference' => $this->storageReference] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-z0-9][a-z0-9._-]{0,119}$/', $this->evidenceKey) !== 1) {
            throw new InvalidArgumentException('evidenceKey must be a stable lowercase identifier.');
        }
        if (preg_match('#^[a-z0-9.+-]+/[a-z0-9.+-]+$#i', $this->mimeType) !== 1) {
            throw new InvalidArgumentException('mimeType is invalid.');
        }
        try {
            new DateTimeImmutable($this->capturedAt);
        } catch (\Throwable $e) {
            throw new InvalidArgumentException('capturedAt must be an ISO-8601 compatible datetime.', 0, $e);
        }
        if ($this->captureDeviceId !== null && trim($this->captureDeviceId) === '') {
            throw new InvalidArgumentException('captureDeviceId must be non-empty when supplied.');
        }
        if (count($this->metadata) > 100) {
            throw new InvalidArgumentException('Evidence metadata is too large.');
        }
    }
}
