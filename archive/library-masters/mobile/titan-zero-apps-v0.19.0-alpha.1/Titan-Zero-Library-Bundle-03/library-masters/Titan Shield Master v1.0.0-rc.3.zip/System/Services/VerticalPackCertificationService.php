<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use Throwable;

final class VerticalPackCertificationService
{
    public function __construct(private readonly InspectionDefinitionValidator $validator) {}

    /** @param array<string,mixed> $definition @return array<string,mixed> */
    public function certify(array $definition): array
    {
        try {
            $this->validator->validate($definition);
            $parsed = InspectionDefinition::fromArray($definition);
        } catch (Throwable $e) {
            return [
                'status' => 'REJECTED',
                'reason_codes' => ['DEFINITION_INVALID'],
                'error_type' => $e::class,
            ];
        }

        $type = strtolower((string) ($definition['inspection_type'] ?? ''));
        $regulatory = in_array($type, ['safety', 'compliance', 'regulatory'], true);
        $references = array_values(array_filter($definition['knowledge_references'] ?? [], 'is_array'));

        if ($regulatory && $references === []) {
            return [
                'status' => 'REJECTED',
                'definition_key' => $parsed->key(),
                'version' => $parsed->version(),
                'definition_hash' => $parsed->definitionHash(),
                'vertical_key' => (string) ($definition['vertical_key'] ?? ''),
                'regulatory_claim' => true,
                'reason_codes' => ['AUTHORITY_REFERENCE_REQUIRED'],
            ];
        }

        return [
            'status' => 'CERTIFIED',
            'definition_key' => $parsed->key(),
            'version' => $parsed->version(),
            'definition_hash' => $parsed->definitionHash(),
            'vertical_key' => (string) ($definition['vertical_key'] ?? ''),
            'source_pack' => (string) ($definition['source_pack'] ?? ''),
            'regulatory_claim' => $regulatory,
            'reason_codes' => [],
        ];
    }
}
