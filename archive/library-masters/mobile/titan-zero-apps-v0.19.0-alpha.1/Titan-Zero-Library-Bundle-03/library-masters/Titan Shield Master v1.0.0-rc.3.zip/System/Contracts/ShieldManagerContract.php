<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;

interface ShieldManagerContract
{
    /** @return array<string,mixed> */
    public function health(): array;

    /** @return array<string,array<string,mixed>> */
    public function capabilities(): array;


    /** @param array<string,mixed> $finding @return array<string,mixed> */
    public function buildAuthorityConstraint(array $finding, ShieldExecutionContext $context, string $agentId, string $capability, ?string $capabilityVariant = null, ?string $vertical = null, ?string $workflow = null, ?string $authorityContext = null, string $policyVersion = 'shield-governance-v1', ?string $evaluatedAt = null, ?string $expiresAt = null): array;

    /** @param array<string,mixed> $definition @return array{valid:bool,definition_key:string,version:string,definition_hash:string} */
    public function validateDefinition(array $definition): array;

    /** @param array<string,mixed> $rule @param array<string,mixed> $facts @return array<string,mixed> */
    public function evaluateRule(array $rule, array $facts): array;

    /** @param array<string,mixed> $finding @return array<string,mixed> */
    public function determineGovernanceResponse(array $finding, ShieldExecutionContext $context): array;

    /** @param array<string,mixed> $definition @param array<string,mixed> $facts @return array<string,mixed> */
    public function evaluateInspection(string $runId, array $definition, string $subjectType, string $subjectId, array $facts, ShieldExecutionContext $context, ?string $jurisdiction = null): array;

    /** @param array<string,mixed> $finding @return array<string,mixed> */
    public function determineHumanReview(string $reviewId, array $finding, ShieldExecutionContext $context, string $reviewerRole = 'manager', ?string $dueAt = null): array;

    /** @param array<string,mixed> $finding @param array<string,mixed> $payload @return array<string,mixed> */
    public function prepareRemediation(string $intentId, array $finding, ShieldExecutionContext $context, string $remediationType, ?string $requestedCapability = null, array $payload = []): array;

    /** @param array<string,mixed> $finding @param array<string,mixed> $definition @param array<string,mixed> $facts @return array<string,mixed> */
    public function reinspectFinding(
        string $reinspectionId,
        string $originalRunId,
        string $reinspectionRunId,
        array $finding,
        array $definition,
        array $facts,
        ShieldExecutionContext $context,
        array $assuranceEvidence = [],
        ?string $jurisdiction = null,
    ): array;
}
