<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;

final class AssuranceClearanceNormalizer
{
    /**
     * @param list<EvidenceManifest> $evidence
     * @param array<string,mixed> $response
     */
    public function normalize(
        Finding $finding,
        array $evidence,
        array $response,
        string $reinspectionId = 'unbound-reinspection',
        string $reinspectionRunId = 'unbound-run',
        ?string $assessedAt = null,
    ): AssuranceClearanceDecision {
        $assessedAt ??= gmdate('c');
        $expectedEvidence = $this->evidenceMap($evidence);
        $fingerprint = $this->fingerprint($expectedEvidence);
        $evidenceMissing = $expectedEvidence === [];
        $result = is_array($response['result'] ?? null) ? $response['result'] : [];
        $score = is_numeric($result['score'] ?? null) ? (float) $result['score'] : null;
        $policyVersion = $this->nonEmpty($result['policy_version'] ?? null);
        $reasonCodes = [];
        $decision = 'HOLD';

        if ($evidenceMissing) {
            $reasonCodes[] = 'ASSURANCE_EVIDENCE_REQUIRED';
        }

        if (($response['status'] ?? null) !== 'OK' || ($response['engine'] ?? null) !== 'titan-assurance') {
            $reasonCodes[] = (string) ($response['reason_code'] ?? 'ASSURANCE_UNAVAILABLE_OR_ERROR');
            return $this->decision($finding, $reinspectionId, $reinspectionRunId, $decision, $score, $policyVersion, $fingerprint, $reasonCodes, $assessedAt, $response, $result);
        }

        if ((string) ($result['company_id'] ?? '') !== (string) $finding->context->companyId) {
            $reasonCodes[] = 'ASSURANCE_TENANT_MISMATCH';
        }
        $subject = is_array($result['subject'] ?? null) ? $result['subject'] : [];
        if ((string) ($subject['type'] ?? '') !== $finding->subjectType || (string) ($subject['id'] ?? '') !== $finding->subjectId) {
            $reasonCodes[] = 'ASSURANCE_SUBJECT_MISMATCH';
        }
        if ((string) ($result['capability'] ?? '') !== 'shield.finding.verify_assurance') {
            $reasonCodes[] = 'ASSURANCE_CAPABILITY_MISMATCH';
        }
        if ($policyVersion === null) {
            $reasonCodes[] = 'ASSURANCE_POLICY_VERSION_MISSING';
        }

        $actualEvidence = [];
        foreach ((array) ($result['evidence_used'] ?? []) as $item) {
            if (! is_array($item)) {
                continue;
            }
            $id = trim((string) ($item['evidence_id'] ?? ''));
            $hash = strtolower(trim((string) ($item['hash'] ?? '')));
            if ($id !== '' && preg_match('/^[a-f0-9]{64}$/', $hash) === 1) {
                $actualEvidence[$id] = $hash;
            }
        }
        ksort($actualEvidence);
        if ($actualEvidence !== $expectedEvidence) {
            $reasonCodes[] = 'ASSURANCE_EVIDENCE_SET_MISMATCH';
        }

        if ((array) ($result['missing_evidence'] ?? []) !== []) {
            $reasonCodes[] = 'ASSURANCE_MISSING_EVIDENCE';
        }
        if ((array) ($result['stale_evidence'] ?? []) !== []) {
            $reasonCodes[] = 'ASSURANCE_STALE_EVIDENCE';
        }
        if ((array) ($result['contradictory_evidence'] ?? []) !== []) {
            $reasonCodes[] = 'ASSURANCE_CONTRADICTORY_EVIDENCE';
        }

        $band = strtoupper(trim((string) ($result['status'] ?? '')));
        if ($band === 'RED') {
            $decision = 'DENY';
            $reasonCodes[] = 'ASSURANCE_RED';
        } elseif ($band !== 'GREEN') {
            $reasonCodes[] = $band === 'AMBER' ? 'ASSURANCE_AMBER' : 'ASSURANCE_STATUS_NOT_GREEN';
        } elseif ($score === null || $score < 80.0) {
            $reasonCodes[] = 'ASSURANCE_SCORE_BELOW_GREEN_THRESHOLD';
        } elseif ($reasonCodes === []) {
            $decision = 'ALLOW';
            $reasonCodes[] = 'ASSURANCE_GREEN_EXACT_EVIDENCE_CLEARANCE';
        }

        return $this->decision($finding, $reinspectionId, $reinspectionRunId, $decision, $score, $policyVersion, $fingerprint, array_values(array_unique($reasonCodes)), $assessedAt, $response, $result);
    }

    /** @param list<EvidenceManifest> $evidence @return array<string,string> */
    private function evidenceMap(array $evidence): array
    {
        $map = [];
        foreach ($evidence as $manifest) {
            if (! $manifest instanceof EvidenceManifest) {
                continue;
            }
            $map[$manifest->evidenceId] = strtolower($manifest->sha256);
        }
        ksort($map);
        return $map;
    }

    /** @param array<string,string> $map */
    private function fingerprint(array $map): string
    {
        return hash('sha256', json_encode($map, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private function nonEmpty(mixed $value): ?string
    {
        if (! is_scalar($value)) {
            return null;
        }
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }

    /** @param list<string> $reasonCodes @param array<string,mixed> $response @param array<string,mixed> $result */
    private function decision(Finding $finding, string $reinspectionId, string $reinspectionRunId, string $decision, ?float $score, ?string $policyVersion, string $fingerprint, array $reasonCodes, string $assessedAt, array $response, array $result): AssuranceClearanceDecision
    {
        $clearanceId = hash('sha256', implode('|', [
            (string) $finding->context->companyId,
            $finding->findingId,
            $reinspectionId,
            $reinspectionRunId,
            $fingerprint,
            $policyVersion ?? 'no-policy',
        ]));

        return new AssuranceClearanceDecision(
            clearanceId: $clearanceId,
            findingId: $finding->findingId,
            reinspectionId: $reinspectionId,
            reinspectionRunId: $reinspectionRunId,
            decision: $decision,
            mayClose: $decision === 'ALLOW',
            score: $score,
            policyVersion: $policyVersion,
            evidenceFingerprint: $fingerprint,
            reasonCodes: $reasonCodes,
            assessedAt: $assessedAt,
            rawSummary: [
                'engine' => $response['engine'] ?? null,
                'adapter_status' => $response['status'] ?? null,
                'assessment_uuid' => $result['uuid'] ?? null,
                'assurance_status' => $result['status'] ?? null,
            ],
        );
    }
}
