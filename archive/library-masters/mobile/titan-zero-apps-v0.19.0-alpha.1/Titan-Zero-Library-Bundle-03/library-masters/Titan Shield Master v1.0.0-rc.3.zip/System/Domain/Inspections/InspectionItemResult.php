<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Inspections;

use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluationStatus;
use InvalidArgumentException;
use JsonSerializable;

final readonly class InspectionItemResult implements JsonSerializable
{
    /**
     * @param list<string> $evidenceIds
     * @param list<string> $reasonCodes
     * @param array<string,mixed> $details
     */
    public function __construct(
        public string $ruleKey,
        public string $ruleType,
        public RuleEvaluationStatus $status,
        public string $failureSeverity,
        public array $evidenceIds,
        public array $reasonCodes,
        public array $details = [],
    ) {
        if (trim($this->ruleKey) === '' || trim($this->ruleType) === '') {
            throw new InvalidArgumentException('Inspection item rule identity must not be empty.');
        }

        foreach (array_merge($this->evidenceIds, $this->reasonCodes) as $value) {
            if (! is_string($value) || trim($value) === '') {
                throw new InvalidArgumentException('Inspection item evidence IDs and reason codes must be non-empty strings.');
            }
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'rule_key' => $this->ruleKey,
            'rule_type' => $this->ruleType,
            'status' => $this->status->value,
            'failure_severity' => $this->failureSeverity,
            'evidence_ids' => $this->evidenceIds,
            'reason_codes' => $this->reasonCodes,
            'details' => $this->details,
        ];
    }
}
