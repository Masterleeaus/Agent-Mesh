<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Governance;

use JsonSerializable;

final readonly class GovernanceResponse implements JsonSerializable
{
    /** @param list<GovernanceAction> $actions @param list<string> $reasonCodes */
    public function __construct(
        public array $actions,
        public bool $blockProgression,
        public bool $requiresHumanReview,
        public bool $requestRisk,
        public bool $requestAssurance,
        public bool $requestCommandBus,
        public bool $requestCouncil,
        public array $reasonCodes,
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'actions' => array_map(static fn (GovernanceAction $action): string => $action->value, $this->actions),
            'block_progression' => $this->blockProgression,
            'requires_human_review' => $this->requiresHumanReview,
            'request_risk' => $this->requestRisk,
            'request_assurance' => $this->requestAssurance,
            'request_command_bus' => $this->requestCommandBus,
            'request_council' => $this->requestCouncil,
            'reason_codes' => $this->reasonCodes,
        ];
    }
}
