<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Workforce;

use RuntimeException;

final class WorkforceIntegrationDescriptor
{
    public function __construct(private readonly string $extensionRoot) {}

    public function manifestPath(): string
    {
        return rtrim($this->extensionRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'workforce-integration.json';
    }

    /** @return array<string,mixed> */
    public function manifest(): array
    {
        $path = $this->manifestPath();
        if (!is_file($path)) {
            throw new RuntimeException('Workforce integration manifest is unavailable.');
        }
        $decoded = json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($decoded)) {
            throw new RuntimeException('Workforce integration manifest is invalid.');
        }
        return $decoded;
    }

    /** @return array<string,mixed> */
    public function provider(): array
    {
        $manifest = $this->manifest();
        return is_array($manifest['provider'] ?? null) ? $manifest['provider'] : [];
    }

    public function providerFingerprint(): string
    {
        $manifest = $this->manifest();
        return (string)($manifest['runtime_discovery']['provider_fingerprint'] ?? '');
    }

    public function supportsCapability(string $capabilityId): bool
    {
        foreach (($this->manifest()['capabilities'] ?? []) as $capability) {
            if (is_array($capability) && ($capability['id'] ?? null) === $capabilityId) {
                return true;
            }
        }
        return false;
    }

    /** @return array{availability:string,decision:string,reason_codes:list<string>} */
    public function failClosedDecision(string $reason): array
    {
        return [
            'availability' => 'blocked',
            'decision' => 'deny',
            'reason_codes' => [$reason],
        ];
    }
}
