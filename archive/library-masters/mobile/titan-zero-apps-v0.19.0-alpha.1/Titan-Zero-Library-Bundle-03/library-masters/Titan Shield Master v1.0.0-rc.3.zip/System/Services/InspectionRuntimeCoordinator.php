<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRunStatus;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\KnowledgeAuthorityAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;

final class InspectionRuntimeCoordinator
{
    public function __construct(
        private readonly InspectionRunEvaluator $evaluator,
        private readonly ShieldRuntimeStoreContract $store,
        private readonly GovernanceResponseResolver $governance,
        private readonly HumanReviewWorkflow $reviews,
        private readonly RemediationIntentFactory $remediation,
        private readonly RewindReceiptFactory $rewind,
        private readonly SignalEngineAdapter $signal,
        private readonly RiskEngineAdapter $risk,
        private readonly AssuranceEngineAdapter $assurance,
        private readonly ?KnowledgeAuthorityAdapter $knowledge = null,
        private readonly ?KnowledgeBindingPolicy $knowledgeBindingPolicy = null,
    ) {}

    /**
     * @param array<string,mixed> $facts
     * @return array<string,mixed>
     */
    public function execute(
        string $runId,
        InspectionDefinition $definition,
        string $subjectType,
        string $subjectId,
        array $facts,
        ShieldExecutionContext $context,
        ?string $startedAt = null,
        ?string $completedAt = null,
        ?string $jurisdiction = null,
    ): array {
        $startedAt ??= date(DATE_ATOM);
        $completedAt ??= date(DATE_ATOM);
        $knowledgeBindings = $this->bindKnowledge($runId, $definition, $context, $jurisdiction);
        if ($knowledgeBindings['blocking']) {
            $run = new InspectionRun(
                runId: $runId,
                definitionKey: $definition->key(),
                definitionVersion: $definition->version(),
                definitionHash: $definition->definitionHash(),
                subjectType: $subjectType,
                subjectId: $subjectId,
                status: InspectionRunStatus::AwaitingReview,
                outcome: InspectionOutcome::Inconclusive,
                itemResults: [],
                startedAt: $startedAt,
                completedAt: $completedAt,
                context: $context,
            );
            $this->store->recordRun($run);
            return [
                'run' => $run->jsonSerialize(),
                'knowledge_bindings' => $knowledgeBindings['receipts'],
                'findings' => [],
                'governance' => [],
                'human_reviews' => [],
                'remediation_intents' => [],
                'integration_receipts' => [],
                'authority' => [
                    'direct_business_mutation' => false,
                    'knowledge_authority' => 'titan-knowledge-authority',
                    'knowledge_conclusion' => 'held',
                    'risk_authority' => 'titan-risk',
                    'assurance_authority' => 'titan-assurance',
                    'command_execution_authority' => 'titan-command-bus',
                    'rewind_write_mode' => 'local_compatible_receipt',
                ],
            ];
        }

        $run = $this->evaluator->evaluate(
            runId: $runId,
            definition: $definition,
            subjectType: $subjectType,
            subjectId: $subjectId,
            facts: $facts,
            context: $context,
            startedAt: $startedAt,
            completedAt: $completedAt,
        );
        $this->store->recordRun($run);

        $findings = [];
        $governanceResponses = [];
        $humanReviews = [];
        $remediationIntents = [];
        $integrationReceipts = [];

        $completionSignal = $this->signal->buildSignal(
            eventType: 'shield.inspection.completed',
            payload: [
                'run_id' => $run->runId,
                'definition_key' => $run->definitionKey,
                'definition_version' => $run->definitionVersion,
                'definition_hash' => $run->definitionHash,
                'subject_type' => $run->subjectType,
                'subject_id' => $run->subjectId,
                'outcome' => $run->outcome->value,
                'failed_item_count' => count($run->failedItems()),
                'occurred_at' => $run->completedAt,
            ],
            context: $context,
            subjectId: $subjectId,
            verticalKey: $definition->verticalKey,
        );
        $completionResponse = $this->signal->emit($completionSignal);
        $completionReceipt = $this->integrationReceipt(
            target: 'titan-signal',
            eventType: 'shield.inspection.completed',
            payload: $completionSignal,
            response: $completionResponse,
            context: $context,
            seed: $runId,
        );
        $this->store->recordIntegrationReceipt($completionReceipt);
        $integrationReceipts[] = $completionReceipt;

        foreach ($run->failedItems() as $item) {
            $finding = new Finding(
                findingId: $this->stableId('finding', [$runId, $item->ruleKey, $run->definitionHash]),
                definitionKey: $run->definitionKey,
                definitionVersion: $run->definitionVersion,
                definitionHash: $run->definitionHash,
                code: $item->ruleKey,
                severity: FindingSeverity::from(strtolower($item->failureSeverity)),
                outcome: $run->outcome,
                subjectType: $run->subjectType,
                subjectId: $run->subjectId,
                evidenceIds: $item->evidenceIds,
                reasonCodes: $item->reasonCodes,
                context: $context,
            );
            $response = $this->governance->resolve($finding);
            $governanceArray = $response->jsonSerialize();

            $this->store->recordFinding($finding, $governanceArray);
            $findings[] = $finding->jsonSerialize();
            $governanceResponses[] = [
                'finding_id' => $finding->findingId,
                ...$governanceArray,
            ];

            $rewind = $this->rewind->forFinding(
                finding: $finding,
                governance: $governanceArray,
                occurredAt: $run->completedAt,
                runId: $run->runId,
            );
            $rewindPayload = $rewind->jsonSerialize();
            $rewindReceipt = $this->integrationReceipt(
                target: 'titan-rewind',
                eventType: 'shield.finding.recorded',
                payload: $rewindPayload,
                response: [
                    'status' => 'RECORDED_LOCAL',
                    'reason_code' => 'REWIND_PUBLIC_WRITE_CONTRACT_UNAVAILABLE',
                ],
                context: $context,
                seed: $finding->findingId . '|rewind',
                status: 'RECORDED_LOCAL',
            );
            $this->store->recordIntegrationReceipt($rewindReceipt);
            $integrationReceipts[] = $rewindReceipt;

            $findingSignal = $this->signal->buildSignal(
                eventType: 'shield.finding.recorded',
                payload: [
                    'run_id' => $run->runId,
                    'finding_id' => $finding->findingId,
                    'definition_key' => $finding->definitionKey,
                    'definition_version' => $finding->definitionVersion,
                    'definition_hash' => $finding->definitionHash,
                    'subject_type' => $finding->subjectType,
                    'subject_id' => $finding->subjectId,
                    'finding_severity' => $finding->severity->value,
                    'outcome' => $finding->outcome->value,
                    'reason_codes' => $finding->reasonCodes,
                    'governance' => $governanceArray,
                    'occurred_at' => $run->completedAt,
                ],
                context: $context,
                subjectId: $finding->subjectId,
                verticalKey: $definition->verticalKey,
            );
            $findingSignalResponse = $this->signal->emit($findingSignal);
            $signalReceipt = $this->integrationReceipt(
                target: 'titan-signal',
                eventType: 'shield.finding.recorded',
                payload: $findingSignal,
                response: $findingSignalResponse,
                context: $context,
                seed: $finding->findingId . '|signal',
            );
            $this->store->recordIntegrationReceipt($signalReceipt);
            $integrationReceipts[] = $signalReceipt;

            if ($response->requestCommandBus) {
                $intent = $this->remediation->prepare(
                    intentId: $this->stableId('remediation', [$finding->findingId, $finding->definitionHash]),
                    finding: $finding,
                    remediationType: 'inspection_rework',
                    requestedCapability: null,
                    payload: [
                        'run_id' => $run->runId,
                        'rule_key' => $item->ruleKey,
                        'reason_codes' => $item->reasonCodes,
                        'governance_reason_codes' => $response->reasonCodes,
                    ],
                );
                $this->store->recordRemediationIntent($intent);
                $remediationIntents[] = $intent->jsonSerialize();
            }

            if ($response->requiresHumanReview) {
                $review = $this->reviews->request(
                    reviewId: $this->stableId('review', [$finding->findingId, $context->traceId]),
                    finding: $finding,
                    reviewerRole: 'manager',
                    dueAt: null,
                );
                $this->store->recordReview($review);
                $humanReviews[] = $review->jsonSerialize();
            }

            if ($response->requestRisk) {
                $riskResponse = $this->risk->assess($finding);
                $riskReceipt = $this->integrationReceipt(
                    target: 'titan-risk',
                    eventType: 'shield.finding.risk_evaluation_requested',
                    payload: $this->risk->buildRequest($finding),
                    response: $riskResponse,
                    context: $context,
                    seed: $finding->findingId . '|risk',
                );
                $this->store->recordIntegrationReceipt($riskReceipt);
                $integrationReceipts[] = $riskReceipt;
            }

            if ($response->requestAssurance) {
                $assuranceResponse = $this->assurance->assess($finding, []);
                $assuranceReceipt = $this->integrationReceipt(
                    target: 'titan-assurance',
                    eventType: 'shield.finding.assurance_requested',
                    payload: $this->assurance->buildRequest($finding, []),
                    response: $assuranceResponse,
                    context: $context,
                    seed: $finding->findingId . '|assurance',
                );
                $this->store->recordIntegrationReceipt($assuranceReceipt);
                $integrationReceipts[] = $assuranceReceipt;
            }
        }

        return [
            'run' => $run->jsonSerialize(),
            'knowledge_bindings' => $knowledgeBindings['receipts'],
            'findings' => $findings,
            'governance' => $governanceResponses,
            'human_reviews' => $humanReviews,
            'remediation_intents' => $remediationIntents,
            'integration_receipts' => $integrationReceipts,
            'authority' => [
                'direct_business_mutation' => false,
                'knowledge_authority' => 'titan-knowledge-authority',
                'knowledge_conclusion' => 'bound',
                'risk_authority' => 'titan-risk',
                'assurance_authority' => 'titan-assurance',
                'command_execution_authority' => 'titan-command-bus',
                'rewind_write_mode' => 'local_compatible_receipt',
            ],
        ];
    }


    /** @return array{blocking:bool,receipts:list<array<string,mixed>>} */
    private function bindKnowledge(string $runId, InspectionDefinition $definition, ShieldExecutionContext $context, ?string $jurisdiction): array
    {
        if ($definition->knowledgeReferences === []) {
            return ['blocking' => false, 'receipts' => []];
        }

        $jurisdiction = trim((string) $jurisdiction);
        $adapter = $this->knowledge ?? new KnowledgeAuthorityAdapter();
        $policy = $this->knowledgeBindingPolicy ?? new KnowledgeBindingPolicy();
        $receipts = [];
        $blocking = false;

        foreach ($definition->knowledgeReferences as $reference) {
            $resolution = $adapter->resolve($reference->jsonSerialize());
            $decision = $policy->bind($reference, $resolution, $jurisdiction, $definition->verticalKey);
            $receipt = new KnowledgeBindingReceipt(
                bindingId: hash('sha256', implode('|', [
                    (string) $context->companyId, $runId, $definition->definitionHash(),
                    $reference->knowledgeKey, $reference->jurisdiction,
                ])),
                runId: $runId,
                definitionKey: $definition->key(),
                definitionVersion: $definition->version(),
                definitionHash: $definition->definitionHash(),
                verticalKey: $definition->verticalKey,
                jurisdiction: $reference->jurisdiction,
                knowledgeKey: $reference->knowledgeKey,
                authorityDomain: $reference->authorityDomain,
                status: $decision['status'],
                bindingMode: $decision['binding_mode'],
                blocking: $decision['blocking'],
                resolvedVersion: $decision['resolved_version'],
                resolvedHash: $decision['resolved_hash'],
                reasonCodes: [$decision['reason_code']],
                context: $context,
            );
            $this->store->recordKnowledgeBindingReceipt($receipt);
            $receipts[] = $receipt->jsonSerialize();
            $blocking = $blocking || $receipt->blocking;
        }

        return ['blocking' => $blocking, 'receipts' => $receipts];
    }

    /**
     * @param array<string,mixed> $payload
     * @param array<string,mixed> $response
     * @return array<string,mixed>
     */
    private function integrationReceipt(
        string $target,
        string $eventType,
        array $payload,
        array $response,
        ShieldExecutionContext $context,
        string $seed,
        ?string $status = null,
    ): array {
        $status ??= (string) ($response['status'] ?? 'UNKNOWN');
        $idempotencyKey = hash('sha256', implode('|', [$target, $eventType, $seed, $context->traceId]));

        return [
            'receipt_id' => hash('sha256', 'receipt|' . $idempotencyKey),
            'target' => $target,
            'event_type' => $eventType,
            'status' => $status,
            'idempotency_key' => $idempotencyKey,
            'payload' => $payload,
            'response' => $response,
            'company_id' => $context->companyId,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'root_causation_id' => $context->rootCausationId ?? $context->causationId,
            'actor_user_id' => $context->actorUserId,
            'source' => $context->source,
        ];
    }

    /** @param list<string> $parts */
    private function stableId(string $prefix, array $parts): string
    {
        return $prefix . '-' . substr(hash('sha256', implode('|', $parts)), 0, 40);
    }
}
