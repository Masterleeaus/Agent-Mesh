<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionRule;
use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluation;
use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluationStatus;
use InvalidArgumentException;

final class DeterministicRuleEngine
{
    /** @param array<string,mixed> $facts */
    public function evaluate(InspectionRule $rule, array $facts): RuleEvaluation
    {
        $passed = match ($rule->ruleType) {
            'evidence_present' => $this->evidencePresent($rule->parameters, $facts),
            'min_file_size' => $this->minFileSize($rule->parameters, $facts),
            'mime_allowed' => $this->mimeAllowed($rule->parameters, $facts),
            'metadata_present' => $this->metadataPresent($rule->parameters, $facts),
            'regex_match' => $this->regexMatch($rule->parameters, $facts),
            'numeric_compare' => $this->numericCompare($rule->parameters, $facts),
            'checklist_all' => $this->checklistAll($rule->parameters, $facts),
            'checklist_any' => $this->checklistAny($rule->parameters, $facts),
            'checklist_minimum' => $this->checklistMinimum($rule->parameters, $facts),
            default => throw new InvalidArgumentException('Unsupported rule type.'),
        };

        return new RuleEvaluation(
            ruleKey: $rule->ruleKey,
            status: $passed ? RuleEvaluationStatus::Pass : RuleEvaluationStatus::Fail,
            failureSeverity: $rule->failureSeverity,
            details: ['rule_type' => $rule->ruleType],
        );
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function evidencePresent(array $parameters, array $facts): bool
    {
        $key = $this->requiredString($parameters, 'evidence_key');
        $items = $facts['evidence'][$key] ?? null;
        return is_array($items) && $items !== [];
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function minFileSize(array $parameters, array $facts): bool
    {
        $key = $this->requiredString($parameters, 'evidence_key');
        $minimum = $parameters['min_bytes'] ?? null;
        if (! is_int($minimum) || $minimum < 0) {
            throw new InvalidArgumentException('min_bytes must be a non-negative integer.');
        }

        foreach ($this->evidenceItems($facts, $key) as $item) {
            if ((int) ($item['size_bytes'] ?? -1) >= $minimum) {
                return true;
            }
        }
        return false;
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function mimeAllowed(array $parameters, array $facts): bool
    {
        $key = $this->requiredString($parameters, 'evidence_key');
        $allowed = $parameters['allowed'] ?? null;
        if (! is_array($allowed) || $allowed === [] || count($allowed) > 50) {
            throw new InvalidArgumentException('allowed must be a non-empty MIME allowlist.');
        }
        foreach ($allowed as $mime) {
            if (! is_string($mime) || preg_match('#^[a-z0-9.+-]+/[a-z0-9.+-]+$#i', $mime) !== 1) {
                throw new InvalidArgumentException('Invalid MIME type in allowlist.');
            }
        }

        foreach ($this->evidenceItems($facts, $key) as $item) {
            if (in_array($item['mime_type'] ?? null, $allowed, true)) {
                return true;
            }
        }
        return false;
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function metadataPresent(array $parameters, array $facts): bool
    {
        $key = $this->requiredString($parameters, 'evidence_key');
        $keys = $parameters['keys'] ?? null;
        if (! is_array($keys) || $keys === [] || count($keys) > 50) {
            throw new InvalidArgumentException('keys must be a non-empty metadata key list.');
        }

        foreach ($this->evidenceItems($facts, $key) as $item) {
            $metadata = is_array($item['metadata'] ?? null) ? $item['metadata'] : [];
            $allPresent = true;
            foreach ($keys as $metadataKey) {
                if (! is_string($metadataKey) || trim($metadataKey) === '' || ! array_key_exists($metadataKey, $metadata)) {
                    $allPresent = false;
                    break;
                }
            }
            if ($allPresent) {
                return true;
            }
        }
        return false;
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function regexMatch(array $parameters, array $facts): bool
    {
        $field = $this->requiredString($parameters, 'field');
        $pattern = $this->requiredString($parameters, 'pattern');
        if (strlen($pattern) > 200 || ! str_starts_with($pattern, '^') || ! str_ends_with($pattern, '$')) {
            throw new InvalidArgumentException('regex pattern must be anchored and at most 200 bytes.');
        }
        if (str_contains($pattern, '(?') || preg_match('/\\\\[1-9]/', $pattern) === 1) {
            throw new InvalidArgumentException('regex lookarounds and backreferences are not allowed.');
        }

        $value = $facts['fields'][$field] ?? null;
        if (! is_scalar($value) && $value !== null) {
            return false;
        }

        $delimiter = '~';
        $safePattern = $delimiter . str_replace($delimiter, '\\' . $delimiter, $pattern) . $delimiter . 'uD';
        $result = preg_match($safePattern, (string) $value);
        if ($result === false) {
            throw new InvalidArgumentException('regex pattern is invalid.');
        }
        return $result === 1;
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function numericCompare(array $parameters, array $facts): bool
    {
        $field = $this->requiredString($parameters, 'field');
        $operator = $this->requiredString($parameters, 'operator');
        $expected = $parameters['value'] ?? null;
        $actual = $facts['fields'][$field] ?? null;
        if (! is_numeric($expected) || ! is_numeric($actual)) {
            return false;
        }
        $left = (float) $actual;
        $right = (float) $expected;
        return match ($operator) {
            '>' => $left > $right,
            '>=' => $left >= $right,
            '<' => $left < $right,
            '<=' => $left <= $right,
            '==' => $left === $right,
            '!=' => $left !== $right,
            default => throw new InvalidArgumentException('Unsupported numeric operator.'),
        };
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function checklistAll(array $parameters, array $facts): bool
    {
        $values = $this->checklistValues($parameters, $facts);
        return $values !== [] && ! in_array(false, $values, true);
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function checklistAny(array $parameters, array $facts): bool
    {
        return in_array(true, $this->checklistValues($parameters, $facts), true);
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts */
    private function checklistMinimum(array $parameters, array $facts): bool
    {
        $minimum = $parameters['minimum'] ?? null;
        if (! is_int($minimum) || $minimum < 0) {
            throw new InvalidArgumentException('minimum must be a non-negative integer.');
        }
        return count(array_filter($this->checklistValues($parameters, $facts), static fn (bool $value): bool => $value)) >= $minimum;
    }

    /** @param array<string,mixed> $parameters @param array<string,mixed> $facts @return list<bool> */
    private function checklistValues(array $parameters, array $facts): array
    {
        $key = $this->requiredString($parameters, 'checklist_key');
        $checklist = $facts['checklists'][$key] ?? null;
        if (! is_array($checklist)) {
            return [];
        }
        $values = [];
        foreach ($checklist as $value) {
            if (! is_bool($value)) {
                throw new InvalidArgumentException('Checklist values must be boolean.');
            }
            $values[] = $value;
        }
        return $values;
    }

    /** @param array<string,mixed> $parameters */
    private function requiredString(array $parameters, string $key): string
    {
        $value = $parameters[$key] ?? null;
        if (! is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException($key . ' must be a non-empty string.');
        }
        return $value;
    }

    /** @param array<string,mixed> $facts @return list<array<string,mixed>> */
    private function evidenceItems(array $facts, string $key): array
    {
        $items = $facts['evidence'][$key] ?? null;
        if (! is_array($items)) {
            return [];
        }
        $result = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $result[] = $item;
            }
        }
        return $result;
    }
}
