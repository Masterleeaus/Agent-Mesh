<?php
declare(strict_types=1);
namespace App\Extensions\TitanShield\System\Workforce;
final class HostCommandBusAdapter implements CommandBusAdapter { public function __construct(private \Closure $readyFn,private \Closure $executeFn) {} public function ready(): bool { return (bool)($this->readyFn)(); } public function execute(array $commandEnvelope): array { $r=($this->executeFn)($commandEnvelope); return is_array($r)?$r:['status'=>'failed','reason'=>'invalid_host_response']; } }
