<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Findings;

enum InspectionOutcome: string
{
    case Pass = 'pass';
    case ConditionalPass = 'conditional_pass';
    case Fail = 'fail';
    case Inconclusive = 'inconclusive';
}
