<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Definitions;

use InvalidArgumentException;
use JsonSerializable;

final readonly class EvidenceRequirement implements JsonSerializable
{
    public const TYPES = ['photo', 'video', 'document', 'checklist', 'sensor', 'signature', 'text', 'other'];

    public function __construct(
        public string $evidenceKey,
        public string $type,
        public bool $required,
        public int $minimumCount = 1,
    ) {
        if (preg_match('/^[a-z0-9][a-z0-9._-]{0,119}$/', $this->evidenceKey) !== 1) {
            throw new InvalidArgumentException('evidence_key must be a stable lowercase identifier.');
        }
        if (! in_array($this->type, self::TYPES, true)) {
            throw new InvalidArgumentException('Evidence type is invalid.');
        }
        if ($this->minimumCount < 0 || $this->minimumCount > 100) {
            throw new InvalidArgumentException('minimum_count must be between 0 and 100.');
        }
    }

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        return new self(
            evidenceKey: (string) ($payload['evidence_key'] ?? ''),
            type: (string) ($payload['type'] ?? ''),
            required: (bool) ($payload['required'] ?? false),
            minimumCount: isset($payload['minimum_count']) ? (int) $payload['minimum_count'] : 1,
        );
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'evidence_key' => $this->evidenceKey,
            'type' => $this->type,
            'required' => $this->required,
            'minimum_count' => $this->minimumCount,
        ];
    }
}
