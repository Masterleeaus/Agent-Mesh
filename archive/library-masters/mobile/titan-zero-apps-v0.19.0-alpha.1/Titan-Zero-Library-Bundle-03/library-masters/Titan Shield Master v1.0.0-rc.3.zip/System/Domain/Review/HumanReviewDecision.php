<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Review;

enum HumanReviewDecision: string
{
    case Pending = 'pending';
    case ConfirmFinding = 'confirm_finding';
    case OverrideFinding = 'override_finding';
    case MoreEvidenceRequired = 'more_evidence_required';
}
