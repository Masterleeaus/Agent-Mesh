<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingClosureDecision;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRequest;
use LogicException;

final class ReinspectionService
{
    public function __construct(private readonly ?ReinspectionClosurePolicy $closurePolicy = null) {}

    public function prepare(
        string $reinspectionId,
        string $originalRunId,
        Finding $finding,
        InspectionDefinition $definition,
    ): ReinspectionRequest {
        if (
            $finding->definitionKey !== $definition->key()
            || $finding->definitionVersion !== $definition->version()
            || ! hash_equals(strtolower($finding->definitionHash), strtolower($definition->definitionHash()))
        ) {
            throw new LogicException('Reinspection must use the exact definition key, version and hash that produced the original finding.');
        }

        return new ReinspectionRequest(
            reinspectionId: $reinspectionId,
            findingId: $finding->findingId,
            originalRunId: $originalRunId,
            definitionKey: $finding->definitionKey,
            definitionVersion: $finding->definitionVersion,
            definitionHash: $finding->definitionHash,
            subjectType: $finding->subjectType,
            subjectId: $finding->subjectId,
            status: 'REQUESTED',
            context: $finding->context,
        );
    }

    /** @param array<string,mixed> $run */
    public function complete(ReinspectionRequest $request, Finding $finding, array $run): ReinspectionRecord
    {
        $policy = $this->closurePolicy ?? new ReinspectionClosurePolicy();
        $decision = $policy->evaluateSerialized($finding, $run, $request->context);

        return new ReinspectionRecord(
            reinspectionId: $request->reinspectionId,
            findingId: $request->findingId,
            originalRunId: $request->originalRunId,
            reinspectionRunId: (string) ($run['run_id'] ?? ''),
            definitionKey: (string) ($run['definition_key'] ?? ''),
            definitionVersion: (string) ($run['definition_version'] ?? ''),
            definitionHash: (string) ($run['definition_hash'] ?? ''),
            subjectType: (string) ($run['subject_type'] ?? ''),
            subjectId: (string) ($run['subject_id'] ?? ''),
            outcome: InspectionOutcome::from(strtolower((string) ($run['outcome'] ?? ''))),
            closureStatus: $decision->targetStatus,
            mayClose: $decision->mayClose,
            requiresAssurance: $decision->requiresAssurance,
            requiresHumanReview: $decision->requiresHumanReview,
            reasonCodes: $decision->reasonCodes,
            completedAt: (string) ($run['completed_at'] ?? ''),
            context: $request->context,
        );
    }
}
