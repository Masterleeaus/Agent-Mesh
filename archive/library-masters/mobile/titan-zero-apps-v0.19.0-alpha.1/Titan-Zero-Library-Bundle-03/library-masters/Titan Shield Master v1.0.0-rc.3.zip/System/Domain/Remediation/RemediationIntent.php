<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Remediation;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use InvalidArgumentException;
use JsonSerializable;

final readonly class RemediationIntent implements JsonSerializable
{
    /** @param array<string,mixed> $payload */
    public function __construct(
        public string $intentId,
        public string $findingId,
        public string $subjectType,
        public string $subjectId,
        public string $remediationType,
        public ?string $requestedCapability,
        public array $payload,
        public string $idempotencyKey,
        public string $status,
        public bool $directMutation,
        public ShieldExecutionContext $context,
    ) {
        foreach (['intentId' => $this->intentId, 'findingId' => $this->findingId, 'subjectType' => $this->subjectType, 'subjectId' => $this->subjectId, 'remediationType' => $this->remediationType, 'idempotencyKey' => $this->idempotencyKey] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if ($this->requestedCapability !== null && trim($this->requestedCapability) === '') {
            throw new InvalidArgumentException('requestedCapability must be null or non-empty.');
        }
        if ($this->directMutation) {
            throw new InvalidArgumentException('Titan Shield remediation intents cannot directly mutate authoritative business state.');
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'intent_id' => $this->intentId,
            'finding_id' => $this->findingId,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'remediation_type' => $this->remediationType,
            'requested_capability' => $this->requestedCapability,
            'payload' => $this->payload,
            'idempotency_key' => $this->idempotencyKey,
            'status' => $this->status,
            'direct_mutation' => $this->directMutation,
            'context' => $this->context->toArray(),
        ];
    }
}
