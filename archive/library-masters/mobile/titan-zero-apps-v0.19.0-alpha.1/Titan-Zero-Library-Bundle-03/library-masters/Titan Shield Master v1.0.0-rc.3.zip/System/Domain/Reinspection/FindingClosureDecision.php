<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Reinspection;

use JsonSerializable;

final readonly class FindingClosureDecision implements JsonSerializable
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public bool $mayClose,
        public FindingLifecycleStatus $targetStatus,
        public bool $requiresAssurance,
        public bool $requiresHumanReview,
        public array $reasonCodes,
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'may_close' => $this->mayClose,
            'target_status' => $this->targetStatus->value,
            'requires_assurance' => $this->requiresAssurance,
            'requires_human_review' => $this->requiresHumanReview,
            'reason_codes' => $this->reasonCodes,
        ];
    }
}
