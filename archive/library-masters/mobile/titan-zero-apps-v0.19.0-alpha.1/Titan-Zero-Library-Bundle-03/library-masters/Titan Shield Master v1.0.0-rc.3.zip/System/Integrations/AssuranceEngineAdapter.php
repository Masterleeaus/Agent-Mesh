<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Integrations;

use App\Extensions\TitanShield\System\Contracts\AssuranceClearancePortContract;

use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;

final class AssuranceEngineAdapter implements AssuranceClearancePortContract
{
    /**
     * @param list<EvidenceManifest> $evidence
     * @param list<array<string,mixed>> $requirements
     * @param list<array<string,mixed>> $knowledgeReferences
     * @return array<string,mixed>
     */
    public function buildRequest(
        Finding $finding,
        array $evidence = [],
        array $requirements = [],
        array $knowledgeReferences = [],
        ?string $vertical = null,
        ?string $jurisdiction = null,
    ): array {
        $context = $finding->context;
        $subject = ['type' => $finding->subjectType, 'id' => $finding->subjectId];

        return [
            'idempotency_key' => hash('sha256', 'shield-assurance|' . $finding->findingId . '|' . $finding->definitionHash),
            'subject' => $subject,
            'decision_type' => 'shield_finding',
            'capability' => 'shield.finding.verify_assurance',
            'capability_variant' => $finding->code,
            'workflow_key' => 'shield.finding.assurance',
            'vertical' => $vertical,
            'jurisdiction' => $jurisdiction,
            'evidence' => array_map(fn (EvidenceManifest $manifest): array => $this->evidenceRecord($manifest, $subject, $vertical, $jurisdiction), $evidence),
            'requirements' => $requirements,
            'knowledge_references' => $knowledgeReferences,
            'trace' => [
                'trace_id' => $context->traceId,
                'correlation_id' => $context->correlationId,
                'causation_id' => $context->causationId,
            ],
            'shield_context' => [
                'company_id' => $context->companyId,
                'finding_id' => $finding->findingId,
                'severity' => $finding->severity->value,
                'outcome' => $finding->outcome->value,
                'definition_key' => $finding->definitionKey,
                'definition_version' => $finding->definitionVersion,
                'definition_hash' => $finding->definitionHash,
                'reason_codes' => $finding->reasonCodes,
            ],
        ];
    }

    /** @param list<EvidenceManifest> $evidence @return array<string,mixed> */
    public function assess(Finding $finding, array $evidence = [], array $requirements = [], array $knowledgeReferences = [], ?string $vertical = null, ?string $jurisdiction = null): array
    {
        $request = $this->buildRequest($finding, $evidence, $requirements, $knowledgeReferences, $vertical, $jurisdiction);
        if (! function_exists('app')) {
            return $this->unavailable($request, 'LARAVEL_CONTAINER_UNAVAILABLE');
        }

        $contract = 'App\\Extensions\\ModelCouncil\\System\\Contracts\\EvidenceAssuranceEngine';
        try {
            $container = app();
            if (method_exists($container, 'bound') && $container->bound($contract)) {
                $assessment = $container->make($contract)->assess($request);

                return [
                    'status' => 'OK',
                    'engine' => 'titan-assurance',
                    'contract' => 'EvidenceAssuranceEngine',
                    'request' => $request,
                    'result' => method_exists($assessment, 'toArray') ? $assessment->toArray() : ['id' => $assessment->id ?? null],
                ];
            }
        } catch (\Throwable $exception) {
            return [
                'status' => 'ERROR',
                'engine' => 'titan-assurance',
                'reason_code' => 'ASSURANCE_ADAPTER_FAILURE',
                'error_type' => $exception::class,
                'request' => $request,
            ];
        }

        return $this->unavailable($request, 'ASSURANCE_PUBLIC_CONTRACT_UNAVAILABLE');
    }

    /** @param array<string,mixed> $subject @return array<string,mixed> */
    private function evidenceRecord(EvidenceManifest $manifest, array $subject, ?string $vertical, ?string $jurisdiction): array
    {
        return [
            'evidence_id' => $manifest->evidenceId,
            'evidence_type' => str_starts_with(strtolower($manifest->mimeType), 'image/') ? 'photo' : 'file',
            'subject' => $subject,
            'source' => 'titan_shield',
            'provenance' => [
                'evidence_key' => $manifest->evidenceKey,
                'original_filename' => $manifest->originalFilename,
                'capture_device_id' => $manifest->captureDeviceId,
                'storage_reference' => $manifest->storageReference,
                'company_id' => $manifest->context->companyId,
                'trace_id' => $manifest->context->traceId,
                'correlation_id' => $manifest->context->correlationId,
                'causation_id' => $manifest->context->causationId,
            ],
            'captured_at' => $manifest->capturedAt,
            'confidence' => 1.0,
            'authority' => 'primary',
            'jurisdiction' => $jurisdiction,
            'vertical' => $vertical,
            'hash' => $manifest->sha256,
            'verification_state' => 'verified',
            'content' => [
                'mime_type' => $manifest->mimeType,
                'size_bytes' => $manifest->sizeBytes,
                'metadata' => $manifest->metadata,
            ],
        ];
    }

    /** @param array<string,mixed> $request @return array<string,mixed> */
    private function unavailable(array $request, string $reason): array
    {
        return [
            'status' => 'UNAVAILABLE',
            'engine' => 'titan-assurance',
            'reason_code' => $reason,
            'request' => $request,
        ];
    }
}
