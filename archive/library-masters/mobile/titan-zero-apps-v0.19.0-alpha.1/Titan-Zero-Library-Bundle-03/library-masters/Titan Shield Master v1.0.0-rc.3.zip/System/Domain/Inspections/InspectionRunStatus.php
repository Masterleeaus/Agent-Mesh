<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Inspections;

enum InspectionRunStatus: string
{
    case Pending = 'pending';
    case Running = 'running';
    case Completed = 'completed';
    case AwaitingReview = 'awaiting_review';
    case Closed = 'closed';
}
