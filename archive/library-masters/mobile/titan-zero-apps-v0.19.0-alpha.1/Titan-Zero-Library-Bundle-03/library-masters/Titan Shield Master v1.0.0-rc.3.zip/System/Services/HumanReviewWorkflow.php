<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewDecision;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use InvalidArgumentException;

final class HumanReviewWorkflow
{
    public function request(string $reviewId, Finding $finding, string $reviewerRole = 'manager', ?string $dueAt = null): HumanReviewRequest
    {
        return new HumanReviewRequest(
            reviewId: $reviewId,
            findingId: $finding->findingId,
            findingSeverity: $finding->severity,
            findingSnapshot: $finding->jsonSerialize(),
            reviewerRole: $reviewerRole,
            dueAt: $dueAt,
            decision: HumanReviewDecision::Pending,
            reviewedBy: null,
            reasonCode: null,
            reviewedAt: null,
            mayProceed: false,
            requiresAssurance: $finding->severity === FindingSeverity::Critical,
            context: $finding->context,
        );
    }

    public function decide(
        HumanReviewRequest $request,
        HumanReviewDecision $decision,
        int $reviewedBy,
        string $reasonCode,
        string $reviewedAt,
    ): HumanReviewRequest {
        if ($decision === HumanReviewDecision::Pending) {
            throw new InvalidArgumentException('A completed review cannot remain pending.');
        }
        if ($reviewedBy <= 0) {
            throw new InvalidArgumentException('reviewedBy must be positive.');
        }
        if (trim($reviewedAt) === '') {
            throw new InvalidArgumentException('reviewedAt is required.');
        }
        if ($decision === HumanReviewDecision::OverrideFinding && trim($reasonCode) === '') {
            throw new InvalidArgumentException('A structured reason code is required to override a finding.');
        }

        $critical = $request->findingSeverity === FindingSeverity::Critical;
        $mayProceed = $decision === HumanReviewDecision::OverrideFinding && ! $critical;
        $requiresAssurance = $critical && $decision === HumanReviewDecision::OverrideFinding;

        return new HumanReviewRequest(
            reviewId: $request->reviewId,
            findingId: $request->findingId,
            findingSeverity: $request->findingSeverity,
            findingSnapshot: $request->findingSnapshot,
            reviewerRole: $request->reviewerRole,
            dueAt: $request->dueAt,
            decision: $decision,
            reviewedBy: $reviewedBy,
            reasonCode: trim($reasonCode) !== '' ? trim($reasonCode) : null,
            reviewedAt: $reviewedAt,
            mayProceed: $mayProceed,
            requiresAssurance: $requiresAssurance,
            context: $request->context,
        );
    }
}
