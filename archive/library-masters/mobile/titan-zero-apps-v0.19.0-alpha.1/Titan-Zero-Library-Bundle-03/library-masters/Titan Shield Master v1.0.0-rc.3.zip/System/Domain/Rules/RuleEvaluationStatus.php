<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Rules;

enum RuleEvaluationStatus: string
{
    case Pass = 'pass';
    case Fail = 'fail';
}
