<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Capabilities\CapabilityDefinition;

interface ShieldCapabilityRegistryContract
{
    /** @return array<string,CapabilityDefinition> */
    public function all(): array;

    public function find(string $name): ?CapabilityDefinition;
}
