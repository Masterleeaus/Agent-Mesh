<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Review;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use InvalidArgumentException;
use JsonSerializable;

final readonly class HumanReviewRequest implements JsonSerializable
{
    /** @param array<string,mixed> $findingSnapshot */
    public function __construct(
        public string $reviewId,
        public string $findingId,
        public FindingSeverity $findingSeverity,
        public array $findingSnapshot,
        public string $reviewerRole,
        public ?string $dueAt,
        public HumanReviewDecision $decision,
        public ?int $reviewedBy,
        public ?string $reasonCode,
        public ?string $reviewedAt,
        public bool $mayProceed,
        public bool $requiresAssurance,
        public ShieldExecutionContext $context,
    ) {
        foreach (['reviewId' => $this->reviewId, 'findingId' => $this->findingId, 'reviewerRole' => $this->reviewerRole] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if ($this->reviewedBy !== null && $this->reviewedBy <= 0) {
            throw new InvalidArgumentException('reviewedBy must be positive when supplied.');
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'review_id' => $this->reviewId,
            'finding_id' => $this->findingId,
            'finding_severity' => $this->findingSeverity->value,
            'finding_snapshot' => $this->findingSnapshot,
            'reviewer_role' => $this->reviewerRole,
            'due_at' => $this->dueAt,
            'decision' => $this->decision->value,
            'reviewed_by' => $this->reviewedBy,
            'reason_code' => $this->reasonCode,
            'reviewed_at' => $this->reviewedAt,
            'may_proceed' => $this->mayProceed,
            'requires_assurance' => $this->requiresAssurance,
            'context' => $this->context->toArray(),
        ];
    }
}
