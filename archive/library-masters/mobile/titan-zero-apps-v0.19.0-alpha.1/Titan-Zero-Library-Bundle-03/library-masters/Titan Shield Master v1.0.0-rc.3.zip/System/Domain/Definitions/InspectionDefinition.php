<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Definitions;

use App\Extensions\TitanShield\System\Services\InspectionDefinitionValidator;
use JsonSerializable;

final readonly class InspectionDefinition implements JsonSerializable
{
    /**
     * @param list<InspectionRule> $rules
     * @param list<EvidenceRequirement> $evidenceRequirements
     * @param array<string,mixed> $passPolicy
     * @param array<string,mixed> $conditionalPassPolicy
     * @param array<string,mixed> $reviewPolicy
     * @param array<string,mixed> $remediationPolicy
     * @param list<KnowledgeReference> $knowledgeReferences
     */
    private function __construct(
        private string $definitionKey,
        private string $definitionVersion,
        private string $definitionName,
        public string $description,
        public string $verticalKey,
        public string $inspectionType,
        public string $scope,
        public string $status,
        public array $rules,
        public array $evidenceRequirements,
        public array $passPolicy,
        public array $conditionalPassPolicy,
        public array $reviewPolicy,
        public array $remediationPolicy,
        public array $knowledgeReferences,
        public string $sourcePack,
        public string $effectiveFrom,
        public ?string $supersedesVersion,
        private string $hash,
    ) {}

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        (new InspectionDefinitionValidator())->validate($payload);

        $normalized = $payload;
        unset($normalized['definition_hash']);
        $hash = hash('sha256', self::canonicalJson($normalized));

        return new self(
            definitionKey: (string) $payload['definition_key'],
            definitionVersion: (string) $payload['version'],
            definitionName: (string) $payload['name'],
            description: (string) $payload['description'],
            verticalKey: (string) $payload['vertical_key'],
            inspectionType: (string) $payload['inspection_type'],
            scope: (string) $payload['scope'],
            status: (string) $payload['status'],
            rules: array_map(static fn (array $rule): InspectionRule => InspectionRule::fromArray($rule), $payload['rules']),
            evidenceRequirements: array_map(static fn (array $item): EvidenceRequirement => EvidenceRequirement::fromArray($item), $payload['evidence_requirements']),
            passPolicy: $payload['pass_policy'],
            conditionalPassPolicy: $payload['conditional_pass_policy'],
            reviewPolicy: $payload['review_policy'],
            remediationPolicy: $payload['remediation_policy'],
            knowledgeReferences: array_map(static fn (array $item): KnowledgeReference => KnowledgeReference::fromArray($item), $payload['knowledge_references']),
            sourcePack: (string) $payload['source_pack'],
            effectiveFrom: (string) $payload['effective_from'],
            supersedesVersion: $payload['supersedes_version'] !== null ? (string) $payload['supersedes_version'] : null,
            hash: $hash,
        );
    }

    public function key(): string { return $this->definitionKey; }
    public function version(): string { return $this->definitionVersion; }
    public function name(): string { return $this->definitionName; }
    public function definitionHash(): string { return $this->hash; }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'definition_key' => $this->definitionKey,
            'version' => $this->definitionVersion,
            'name' => $this->definitionName,
            'description' => $this->description,
            'vertical_key' => $this->verticalKey,
            'inspection_type' => $this->inspectionType,
            'scope' => $this->scope,
            'status' => $this->status,
            'rules' => array_map(static fn (InspectionRule $rule): array => $rule->jsonSerialize(), $this->rules),
            'evidence_requirements' => array_map(static fn (EvidenceRequirement $requirement): array => $requirement->jsonSerialize(), $this->evidenceRequirements),
            'pass_policy' => $this->passPolicy,
            'conditional_pass_policy' => $this->conditionalPassPolicy,
            'review_policy' => $this->reviewPolicy,
            'remediation_policy' => $this->remediationPolicy,
            'knowledge_references' => array_map(static fn (KnowledgeReference $reference): array => $reference->jsonSerialize(), $this->knowledgeReferences),
            'source_pack' => $this->sourcePack,
            'effective_from' => $this->effectiveFrom,
            'supersedes_version' => $this->supersedesVersion,
            'definition_hash' => $this->hash,
        ];
    }

    /** @param mixed $value */
    private static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map(self::canonicalize(...), $value);
        }

        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) {
            $value[$key] = self::canonicalize($item);
        }

        return $value;
    }

    /** @param array<string,mixed> $payload */
    private static function canonicalJson(array $payload): string
    {
        return json_encode(self::canonicalize($payload), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
