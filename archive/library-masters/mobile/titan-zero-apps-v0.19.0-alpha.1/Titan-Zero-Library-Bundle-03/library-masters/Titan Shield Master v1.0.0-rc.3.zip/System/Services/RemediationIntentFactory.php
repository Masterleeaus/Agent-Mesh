<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;

final class RemediationIntentFactory
{
    /** @param array<string,mixed> $payload */
    public function prepare(
        string $intentId,
        Finding $finding,
        string $remediationType,
        ?string $requestedCapability = null,
        array $payload = [],
    ): RemediationIntent {
        $canonical = $this->canonicalize([
            'finding_id' => $finding->findingId,
            'definition_hash' => $finding->definitionHash,
            'subject_type' => $finding->subjectType,
            'subject_id' => $finding->subjectId,
            'remediation_type' => $remediationType,
            'requested_capability' => $requestedCapability,
            'payload' => $payload,
        ]);
        $idempotencyKey = hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));

        return new RemediationIntent(
            intentId: $intentId,
            findingId: $finding->findingId,
            subjectType: $finding->subjectType,
            subjectId: $finding->subjectId,
            remediationType: $remediationType,
            requestedCapability: $requestedCapability,
            payload: $payload,
            idempotencyKey: $idempotencyKey,
            status: 'PREPARED',
            directMutation: false,
            context: $finding->context,
        );
    }

    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(fn (mixed $item): mixed => $this->canonicalize($item), $value);
        }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) {
            $value[$key] = $this->canonicalize($item);
        }
        return $value;
    }
}
