<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Reinspection;

enum FindingLifecycleStatus: string
{
    case Open = 'open';
    case RemediationRequired = 'remediation_required';
    case ReadyForReinspection = 'ready_for_reinspection';
    case ReinspectionInProgress = 'reinspection_in_progress';
    case Resolved = 'resolved';
    case Closed = 'closed';
    case Held = 'held';
}
