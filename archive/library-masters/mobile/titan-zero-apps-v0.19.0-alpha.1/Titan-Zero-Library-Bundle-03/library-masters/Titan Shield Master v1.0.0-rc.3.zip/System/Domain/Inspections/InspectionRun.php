<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Inspections;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluationStatus;
use InvalidArgumentException;
use JsonSerializable;

final readonly class InspectionRun implements JsonSerializable
{
    /** @param list<InspectionItemResult> $itemResults */
    public function __construct(
        public string $runId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public string $subjectType,
        public string $subjectId,
        public InspectionRunStatus $status,
        public InspectionOutcome $outcome,
        public array $itemResults,
        public string $startedAt,
        public string $completedAt,
        public ShieldExecutionContext $context,
    ) {
        foreach (['runId' => $this->runId, 'definitionKey' => $this->definitionKey, 'definitionVersion' => $this->definitionVersion, 'subjectType' => $this->subjectType, 'subjectId' => $this->subjectId, 'startedAt' => $this->startedAt, 'completedAt' => $this->completedAt] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $this->definitionHash) !== 1) {
            throw new InvalidArgumentException('definitionHash must be SHA-256 hex.');
        }
    }

    /** @return list<InspectionItemResult> */
    public function failedItems(): array
    {
        return array_values(array_filter(
            $this->itemResults,
            static fn (InspectionItemResult $item): bool => $item->status === RuleEvaluationStatus::Fail,
        ));
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'run_id' => $this->runId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'status' => $this->status->value,
            'outcome' => $this->outcome->value,
            'item_results' => array_map(static fn (InspectionItemResult $item): array => $item->jsonSerialize(), $this->itemResults),
            'started_at' => $this->startedAt,
            'completed_at' => $this->completedAt,
            'context' => $this->context->toArray(),
        ];
    }
}
