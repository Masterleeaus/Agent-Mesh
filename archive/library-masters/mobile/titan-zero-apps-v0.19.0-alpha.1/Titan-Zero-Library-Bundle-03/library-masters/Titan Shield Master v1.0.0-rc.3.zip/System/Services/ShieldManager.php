<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldCapabilityRegistryContract;
use App\Extensions\TitanShield\System\Contracts\ShieldManagerContract;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionRule;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use InvalidArgumentException;
use LogicException;

final class ShieldManager implements ShieldManagerContract
{
    public function __construct(
        private readonly ShieldCapabilityRegistryContract $capabilities,
        private readonly InspectionDefinitionValidator $definitionValidator,
        private readonly DeterministicRuleEngine $ruleEngine,
        private readonly GovernanceResponseResolver $governanceResolver,
        private readonly ?InspectionRuntimeCoordinator $runtimeCoordinator = null,
        private readonly ?HumanReviewWorkflow $humanReviewWorkflow = null,
        private readonly ?RemediationIntentFactory $remediationIntentFactory = null,
        private readonly ?ShieldRuntimeStoreContract $runtimeStore = null,
        private readonly ?ShieldAuthorityConstraintFactory $authorityConstraintFactory = null,
        private readonly ?ReinspectionCoordinator $reinspectionCoordinator = null,
    ) {}

    public function health(): array
    {
        return [
            'engine' => 'titan-shield',
            'status' => 'production-candidate',
            'version' => '1.0.0-rc.2',
            'capabilities' => array_keys($this->capabilities->all()),
            'queue_enabled' => false,
            'ai_vision_enabled' => false,
            'direct_business_mutation' => false,
            'knowledge_resolution' => 'pinned-or-public-resolver-fail-closed',
        ];
    }

    public function capabilities(): array
    {
        $result = [];
        foreach ($this->capabilities->all() as $name => $definition) {
            $result[$name] = $definition->toArray();
        }
        return $result;
    }

    public function validateDefinition(array $definition): array
    {
        $this->definitionValidator->validate($definition);
        $parsed = InspectionDefinition::fromArray($definition);

        return [
            'valid' => true,
            'definition_key' => $parsed->key(),
            'version' => $parsed->version(),
            'definition_hash' => $parsed->definitionHash(),
        ];
    }

    public function evaluateRule(array $rule, array $facts): array
    {
        return $this->ruleEngine->evaluate(InspectionRule::fromArray($rule), $facts)->jsonSerialize();
    }

    public function determineGovernanceResponse(array $finding, ShieldExecutionContext $context): array
    {
        return $this->governanceResolver->resolve($this->findingFromArray($finding, $context))->jsonSerialize();
    }


    public function buildAuthorityConstraint(array $finding, ShieldExecutionContext $context, string $agentId, string $capability, ?string $capabilityVariant = null, ?string $vertical = null, ?string $workflow = null, ?string $authorityContext = null, string $policyVersion = 'shield-governance-v1', ?string $evaluatedAt = null, ?string $expiresAt = null): array
    {
        if ($this->authorityConstraintFactory === null) {
            throw new LogicException('Shield authority-constraint runtime is not bound.');
        }

        $parsed = $this->findingFromArray($finding, $context);
        $response = $this->governanceResolver->resolve($parsed);

        return $this->authorityConstraintFactory->fromFinding(
            finding: $parsed,
            response: $response,
            agentId: $agentId,
            capability: $capability,
            capabilityVariant: $capabilityVariant,
            vertical: $vertical,
            workflow: $workflow,
            authorityContext: $authorityContext,
            policyVersion: $policyVersion,
            evaluatedAt: $evaluatedAt,
            expiresAt: $expiresAt,
        );
    }

    public function evaluateInspection(string $runId, array $definition, string $subjectType, string $subjectId, array $facts, ShieldExecutionContext $context, ?string $jurisdiction = null): array
    {
        if ($this->runtimeCoordinator === null) {
            throw new LogicException('Shield governed runtime is not bound.');
        }
        $this->definitionValidator->validate($definition);

        return $this->runtimeCoordinator->execute(
            runId: $runId,
            definition: InspectionDefinition::fromArray($definition),
            subjectType: $subjectType,
            subjectId: $subjectId,
            facts: $facts,
            context: $context,
            jurisdiction: $jurisdiction,
        );
    }

    public function determineHumanReview(string $reviewId, array $finding, ShieldExecutionContext $context, string $reviewerRole = 'manager', ?string $dueAt = null): array
    {
        if ($this->humanReviewWorkflow === null || $this->runtimeStore === null) {
            throw new LogicException('Shield human-review runtime is not bound.');
        }
        $review = $this->humanReviewWorkflow->request($reviewId, $this->findingFromArray($finding, $context), $reviewerRole, $dueAt);
        $this->runtimeStore->recordReview($review);

        return $review->jsonSerialize();
    }

    public function prepareRemediation(string $intentId, array $finding, ShieldExecutionContext $context, string $remediationType, ?string $requestedCapability = null, array $payload = []): array
    {
        if ($this->remediationIntentFactory === null || $this->runtimeStore === null) {
            throw new LogicException('Shield remediation runtime is not bound.');
        }
        $intent = $this->remediationIntentFactory->prepare(
            intentId: $intentId,
            finding: $this->findingFromArray($finding, $context),
            remediationType: $remediationType,
            requestedCapability: $requestedCapability,
            payload: $payload,
        );
        $this->runtimeStore->recordRemediationIntent($intent);

        return $intent->jsonSerialize();
    }

    public function reinspectFinding(
        string $reinspectionId,
        string $originalRunId,
        string $reinspectionRunId,
        array $finding,
        array $definition,
        array $facts,
        ShieldExecutionContext $context,
        array $assuranceEvidence = [],
        ?string $jurisdiction = null,
    ): array {
        if ($this->reinspectionCoordinator === null) {
            throw new LogicException('Shield reinspection runtime is not bound.');
        }
        $this->definitionValidator->validate($definition);

        return $this->reinspectionCoordinator->execute(
            reinspectionId: $reinspectionId,
            originalRunId: $originalRunId,
            reinspectionRunId: $reinspectionRunId,
            finding: $this->findingFromArray($finding, $context),
            definition: InspectionDefinition::fromArray($definition),
            facts: $facts,
            context: $context,
            assuranceEvidence: array_map(fn (array $item): EvidenceManifest => $this->evidenceFromArray($item, $context), array_values(array_filter($assuranceEvidence, 'is_array'))),
            jurisdiction: $jurisdiction,
        );
    }

    /** @param array<string,mixed> $item */
    private function evidenceFromArray(array $item, ShieldExecutionContext $context): EvidenceManifest
    {
        foreach (['evidence_id', 'evidence_key', 'original_filename', 'mime_type', 'size_bytes', 'sha256', 'captured_at', 'storage_reference'] as $required) {
            if (! array_key_exists($required, $item)) {
                throw new InvalidArgumentException('Missing assurance evidence field: ' . $required);
            }
        }
        $sha = strtolower((string) $item['sha256']);
        if (preg_match('/^[a-f0-9]{64}$/', $sha) !== 1) {
            throw new InvalidArgumentException('Assurance evidence sha256 must be SHA-256 hex.');
        }
        return new EvidenceManifest(
            evidenceId: (string) $item['evidence_id'],
            evidenceKey: (string) $item['evidence_key'],
            originalFilename: (string) $item['original_filename'],
            mimeType: (string) $item['mime_type'],
            sizeBytes: (int) $item['size_bytes'],
            sha256: $sha,
            capturedAt: (string) $item['captured_at'],
            captureDeviceId: isset($item['capture_device_id']) ? (string) $item['capture_device_id'] : null,
            storageReference: (string) $item['storage_reference'],
            metadata: is_array($item['metadata'] ?? null) ? $item['metadata'] : [],
            context: $context,
        );
    }

    /** @param array<string,mixed> $finding */
    private function findingFromArray(array $finding, ShieldExecutionContext $context): Finding
    {
        foreach (['finding_id', 'definition_key', 'definition_version', 'definition_hash', 'code', 'severity', 'outcome', 'subject_type', 'subject_id'] as $required) {
            if (! array_key_exists($required, $finding)) {
                throw new InvalidArgumentException('Missing finding field: ' . $required);
            }
        }

        return new Finding(
            findingId: (string) $finding['finding_id'],
            definitionKey: (string) $finding['definition_key'],
            definitionVersion: (string) $finding['definition_version'],
            definitionHash: (string) $finding['definition_hash'],
            code: (string) $finding['code'],
            severity: FindingSeverity::from(strtolower((string) $finding['severity'])),
            outcome: InspectionOutcome::from(strtolower((string) $finding['outcome'])),
            subjectType: (string) $finding['subject_type'],
            subjectId: (string) $finding['subject_id'],
            evidenceIds: array_values(array_filter($finding['evidence_ids'] ?? [], 'is_string')),
            reasonCodes: array_values(array_filter($finding['reason_codes'] ?? [], 'is_string')),
            context: $context,
        );
    }
}
