<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionRule;
use App\Extensions\TitanShield\System\Domain\Findings\FindingSeverity;
use App\Extensions\TitanShield\System\Domain\Findings\InspectionOutcome;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionItemResult;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRunStatus;
use App\Extensions\TitanShield\System\Domain\Rules\RuleEvaluationStatus;

final class InspectionRunEvaluator
{
    public function __construct(private readonly DeterministicRuleEngine $rules) {}

    /** @param array<string,mixed> $facts */
    public function evaluate(
        string $runId,
        InspectionDefinition $definition,
        string $subjectType,
        string $subjectId,
        array $facts,
        ShieldExecutionContext $context,
        ?string $startedAt = null,
        ?string $completedAt = null,
    ): InspectionRun {
        $startedAt ??= date(DATE_ATOM);
        $completedAt ??= date(DATE_ATOM);
        $items = [];
        $requiredFailures = [];
        $missingRequiredEvidence = $this->hasMissingRequiredEvidence($definition, $facts);

        foreach ($definition->rules as $rule) {
            $evaluation = $this->rules->evaluate($rule, $facts);
            $evidenceIds = $this->evidenceIdsForRule($rule, $facts);
            $reasonCodes = [$evaluation->status === RuleEvaluationStatus::Pass ? 'RULE_PASSED' : 'RULE_FAILED'];
            if ($evaluation->status === RuleEvaluationStatus::Fail) {
                $reasonCodes[] = strtoupper(str_replace(['.', '-'], '_', $rule->ruleKey));
                if ($rule->required) {
                    $requiredFailures[] = $rule->failureSeverity;
                }
            }

            $items[] = new InspectionItemResult(
                ruleKey: $rule->ruleKey,
                ruleType: $rule->ruleType,
                status: $evaluation->status,
                failureSeverity: $rule->failureSeverity,
                evidenceIds: $evidenceIds,
                reasonCodes: $reasonCodes,
                details: $evaluation->details,
            );
        }

        return new InspectionRun(
            runId: $runId,
            definitionKey: $definition->key(),
            definitionVersion: $definition->version(),
            definitionHash: $definition->definitionHash(),
            subjectType: $subjectType,
            subjectId: $subjectId,
            status: InspectionRunStatus::Completed,
            outcome: $this->outcome($definition, $requiredFailures, $missingRequiredEvidence),
            itemResults: $items,
            startedAt: $startedAt,
            completedAt: $completedAt,
            context: $context,
        );
    }

    /** @param list<string> $requiredFailures */
    private function outcome(InspectionDefinition $definition, array $requiredFailures, bool $missingRequiredEvidence): InspectionOutcome
    {
        if ($missingRequiredEvidence) {
            return InspectionOutcome::Inconclusive;
        }

        if ($requiredFailures === []) {
            return InspectionOutcome::Pass;
        }

        $highest = FindingSeverity::Info;
        foreach ($requiredFailures as $severity) {
            $candidate = FindingSeverity::from(strtolower($severity));
            if ($candidate->rank() > $highest->rank()) {
                $highest = $candidate;
            }
        }

        $policy = $definition->conditionalPassPolicy;
        $allowed = ($policy['allowed'] ?? false) === true;
        $maxSeverity = strtolower((string) ($policy['max_severity'] ?? 'info'));
        $max = FindingSeverity::tryFrom($maxSeverity) ?? FindingSeverity::Info;

        if ($allowed && $highest->rank() <= $max->rank()) {
            return InspectionOutcome::ConditionalPass;
        }

        return InspectionOutcome::Fail;
    }

    /** @param array<string,mixed> $facts */
    private function hasMissingRequiredEvidence(InspectionDefinition $definition, array $facts): bool
    {
        $evidence = $facts['evidence'] ?? [];
        if (! is_array($evidence)) {
            $evidence = [];
        }

        foreach ($definition->evidenceRequirements as $requirement) {
            if (! $requirement->required) {
                continue;
            }
            $records = $evidence[$requirement->evidenceKey] ?? [];
            $count = is_array($records) ? count(array_filter($records, static fn (mixed $record): bool => is_array($record))) : 0;
            if ($count < $requirement->minimumCount) {
                return true;
            }
        }

        return false;
    }

    /** @param array<string,mixed> $facts @return list<string> */
    private function evidenceIdsForRule(InspectionRule $rule, array $facts): array
    {
        $key = trim((string) ($rule->parameters['evidence_key'] ?? ''));
        if ($key === '') {
            return [];
        }

        $records = $facts['evidence'][$key] ?? [];
        if (! is_array($records)) {
            return [];
        }

        $ids = [];
        foreach ($records as $record) {
            if (! is_array($record)) {
                continue;
            }
            $id = trim((string) ($record['evidence_id'] ?? ''));
            if ($id !== '') {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }
}
