<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Contracts;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;

interface AssuranceClearancePortContract
{
    /** @return array<string,mixed> */
    public function assess(Finding $finding, array $evidence = [], array $requirements = [], array $knowledgeReferences = [], ?string $vertical = null, ?string $jurisdiction = null): array;
}
