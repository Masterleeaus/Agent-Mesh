<?php
declare(strict_types=1);
namespace App\Extensions\TitanShield\System\Workforce;
final class CallableGuardrailDecisionAdapter implements GuardrailDecisionAdapter {
 public function __construct(private string $stage,private \Closure $resolver) {}
 public function stage(): string { return $this->stage; }
 public function decide(array $request): array { $result=($this->resolver)($request); if(!is_array($result)) return ['decision'=>'deny','reason_codes'=>['adapter.invalid_response']]; return $result; }
}
