<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

final class FindingAccessRedactionPolicy
{
    /** @param array<string,mixed> $finding @return array<string,mixed> */
    public function redactFinding(array $finding, string $audience, bool $isSubjectParticipant): array
    {
        $audience = strtolower(trim($audience));

        if (in_array($audience, ['platform_admin', 'compliance_officer', 'tenant_owner', 'manager'], true)) {
            return $finding;
        }

        if ($audience === 'worker') {
            if (! $isSubjectParticipant) {
                return [];
            }

            return array_intersect_key($finding, array_flip([
                'finding_id', 'outcome', 'severity', 'code', 'reason_codes', 'status', 'subject_type', 'subject_id',
            ]));
        }

        if ($audience === 'customer') {
            return array_intersect_key($finding, array_flip(['finding_id', 'outcome']));
        }

        return [];
    }
}
