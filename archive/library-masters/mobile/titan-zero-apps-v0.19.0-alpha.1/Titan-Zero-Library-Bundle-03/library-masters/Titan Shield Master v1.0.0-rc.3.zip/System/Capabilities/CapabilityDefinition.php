<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Capabilities;

final readonly class CapabilityDefinition
{
    /**
     * @param array<string,mixed> $inputSchema
     * @param array<string,mixed> $outputSchema
     */
    public function __construct(
        public string $name,
        public array $inputSchema,
        public array $outputSchema,
        public string $riskClass,
        public string $idempotency,
        public string $approvalMode,
        public bool $mutation,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'name' => $this->name,
            'input_schema' => $this->inputSchema,
            'output_schema' => $this->outputSchema,
            'risk_class' => $this->riskClass,
            'idempotency' => $this->idempotency,
            'approval_mode' => $this->approvalMode,
            'mutation' => $this->mutation,
        ];
    }
}
