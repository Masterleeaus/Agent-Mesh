<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Infrastructure\Persistence;

use App\Extensions\TitanShield\System\Domain\Assurance\AssuranceClearanceDecision;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeBindingReceipt;

use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionDefinition;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Inspections\InspectionRun;
use App\Extensions\TitanShield\System\Domain\Remediation\RemediationIntent;
use App\Extensions\TitanShield\System\Domain\Review\HumanReviewRequest;
use App\Extensions\TitanShield\System\Domain\Reinspection\FindingLifecycleStatus;
use App\Extensions\TitanShield\System\Domain\Reinspection\ReinspectionRecord;
use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use Illuminate\Support\Facades\DB;
use LogicException;

final class DatabaseShieldRuntimeStore implements ShieldRuntimeStoreContract
{

    public function recordDefinition(InspectionDefinition $definition, ShieldExecutionContext $context): void
    {
        $scopeKey = $definition->scope === 'global' ? 'global' : 'tenant:' . $context->companyId;
        $tenantId = $definition->scope === 'global' ? null : $context->companyId;
        $existing = DB::table('titan_shield_inspection_definitions')
            ->where('scope_key', $scopeKey)
            ->where('definition_key', $definition->key())
            ->where('version', $definition->version())
            ->first();
        if ($existing !== null) {
            if ((string) $existing->definition_hash !== $definition->definitionHash()) {
                throw new LogicException('Inspection definition identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_inspection_definitions')->insert([
            'company_id' => $tenantId,
            'scope_key' => $scopeKey,
            'definition_key' => $definition->key(),
            'version' => $definition->version(),
            'definition_hash' => $definition->definitionHash(),
            'name' => $definition->name(),
            'vertical_key' => $definition->verticalKey,
            'inspection_type' => $definition->inspectionType,
            'scope' => $definition->scope,
            'status' => $definition->status,
            'definition_json' => $this->json($definition->jsonSerialize()),
            'source_pack' => $definition->sourcePack,
            'effective_from' => $definition->effectiveFrom,
            'supersedes_version' => $definition->supersedesVersion,
            ...$this->contextColumns($context->toArray()),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function recordEvidence(EvidenceManifest $manifest): void
    {
        $context = $manifest->context->toArray();
        $existing = DB::table('titan_shield_evidence')
            ->where('company_id', $context['company_id'])
            ->where('evidence_id', $manifest->evidenceId)
            ->first();
        if ($existing !== null) {
            if ((string) $existing->sha256 !== $manifest->sha256 || (string) $existing->storage_reference !== $manifest->storageReference) {
                throw new LogicException('Evidence identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_evidence')->insert([
            'company_id' => $context['company_id'],
            'evidence_id' => $manifest->evidenceId,
            'evidence_key' => $manifest->evidenceKey,
            'inspection_id' => null,
            'subject_type' => null,
            'subject_id' => null,
            'original_filename' => $manifest->originalFilename,
            'mime_type' => $manifest->mimeType,
            'size_bytes' => $manifest->sizeBytes,
            'sha256' => $manifest->sha256,
            'captured_at' => $manifest->capturedAt,
            'capture_device_id' => $manifest->captureDeviceId,
            'storage_reference' => $manifest->storageReference,
            'metadata' => $this->json($manifest->metadata),
            ...$this->contextColumns($context),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }
    public function recordRun(InspectionRun $run): void
    {
        DB::transaction(function () use ($run): void {
            $existing = DB::table('titan_shield_inspection_runs')
                ->where('company_id', $run->context->companyId)
                ->where('run_id', $run->runId)
                ->first();

            if ($existing !== null) {
                if ((string) $existing->definition_hash !== $run->definitionHash || (string) $existing->subject_id !== $run->subjectId) {
                    throw new LogicException('Inspection run identity is immutable and conflicts with an existing record.');
                }
                return;
            }

            $now = now();
            DB::table('titan_shield_inspection_runs')->insert([
                'company_id' => $run->context->companyId,
                'run_id' => $run->runId,
                'definition_key' => $run->definitionKey,
                'definition_version' => $run->definitionVersion,
                'definition_hash' => $run->definitionHash,
                'subject_type' => $run->subjectType,
                'subject_id' => $run->subjectId,
                'status' => $run->status->value,
                'outcome' => $run->outcome->value,
                'started_at' => $run->startedAt,
                'completed_at' => $run->completedAt,
                ...$this->contextColumns($run->context->toArray()),
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            foreach ($run->itemResults as $item) {
                DB::table('titan_shield_inspection_item_results')->insert([
                    'company_id' => $run->context->companyId,
                    'run_id' => $run->runId,
                    'rule_key' => $item->ruleKey,
                    'rule_type' => $item->ruleType,
                    'status' => $item->status->value,
                    'failure_severity' => $item->failureSeverity,
                    'evidence_ids' => $this->json($item->evidenceIds),
                    'reason_codes' => $this->json($item->reasonCodes),
                    'details' => $this->json($item->details),
                    ...$this->contextColumns($run->context->toArray()),
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            }
        });
    }

    public function recordFinding(Finding $finding, ?array $governanceResponse = null): void
    {
        $context = $finding->context->toArray();
        $existing = DB::table('titan_shield_findings')
            ->where('company_id', $context['company_id'])
            ->where('finding_id', $finding->findingId)
            ->first();
        if ($existing !== null) {
            if ((string) $existing->definition_hash !== $finding->definitionHash || (string) $existing->code !== $finding->code) {
                throw new LogicException('Finding identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_findings')->insert([
            'company_id' => $context['company_id'],
            'finding_id' => $finding->findingId,
            'inspection_id' => null,
            'definition_key' => $finding->definitionKey,
            'definition_version' => $finding->definitionVersion,
            'definition_hash' => $finding->definitionHash,
            'code' => $finding->code,
            'severity' => $finding->severity->value,
            'outcome' => $finding->outcome->value,
            'status' => 'open',
            'subject_type' => $finding->subjectType,
            'subject_id' => $finding->subjectId,
            'evidence_ids' => $this->json($finding->evidenceIds),
            'reason_codes' => $this->json($finding->reasonCodes),
            'governance_response' => $governanceResponse !== null ? $this->json($governanceResponse) : null,
            ...$this->contextColumns($context),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function recordReview(HumanReviewRequest $review): void
    {
        $context = $review->context->toArray();
        $snapshot = $this->json($review->findingSnapshot);

        DB::transaction(function () use ($review, $context, $snapshot): void {
            $existing = DB::table('titan_shield_human_reviews')
                ->where('company_id', $context['company_id'])
                ->where('review_id', $review->reviewId)
                ->first();

            if ($existing !== null) {
                if ((string) $existing->finding_id !== $review->findingId || (string) $existing->finding_snapshot !== $snapshot) {
                    throw new LogicException('Human review identity is immutable and conflicts with the original finding snapshot.');
                }

                DB::table('titan_shield_human_reviews')
                    ->where('company_id', $context['company_id'])
                    ->where('review_id', $review->reviewId)
                    ->update([
                        'decision' => $review->decision->value,
                        'reviewed_by' => $review->reviewedBy,
                        'reason_code' => $review->reasonCode,
                        'reviewed_at' => $review->reviewedAt,
                        'may_proceed' => $review->mayProceed,
                        'requires_assurance' => $review->requiresAssurance,
                        'updated_at' => now(),
                    ]);
                return;
            }

            $now = now();
            DB::table('titan_shield_human_reviews')->insert([
                'company_id' => $context['company_id'],
                'review_id' => $review->reviewId,
                'finding_id' => $review->findingId,
                'finding_severity' => $review->findingSeverity->value,
                'finding_snapshot' => $snapshot,
                'reviewer_role' => $review->reviewerRole,
                'due_at' => $review->dueAt,
                'decision' => $review->decision->value,
                'reviewed_by' => $review->reviewedBy,
                'reason_code' => $review->reasonCode,
                'reviewed_at' => $review->reviewedAt,
                'may_proceed' => $review->mayProceed,
                'requires_assurance' => $review->requiresAssurance,
                ...$this->contextColumns($context),
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        });
    }

    public function recordRemediationIntent(RemediationIntent $intent): void
    {
        $context = $intent->context->toArray();
        $existing = DB::table('titan_shield_remediation_intents')
            ->where('company_id', $context['company_id'])
            ->where('intent_id', $intent->intentId)
            ->first();
        if ($existing !== null) {
            if ((string) $existing->finding_id !== $intent->findingId || (string) $existing->idempotency_key !== $intent->idempotencyKey) {
                throw new LogicException('Remediation intent identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_remediation_intents')->insert([
            'company_id' => $context['company_id'],
            'intent_id' => $intent->intentId,
            'finding_id' => $intent->findingId,
            'subject_type' => $intent->subjectType,
            'subject_id' => $intent->subjectId,
            'remediation_type' => $intent->remediationType,
            'requested_capability' => $intent->requestedCapability,
            'payload' => $this->json($intent->payload),
            'idempotency_key' => $intent->idempotencyKey,
            'status' => $intent->status,
            'direct_mutation' => false,
            ...$this->contextColumns($context),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function recordReinspection(ReinspectionRecord $reinspection): void
    {
        $context = $reinspection->context->toArray();
        $existing = DB::table('titan_shield_reinspections')
            ->where('company_id', $context['company_id'])
            ->where('reinspection_id', $reinspection->reinspectionId)
            ->first();
        if ($existing !== null) {
            if (
                (string) $existing->finding_id !== $reinspection->findingId
                || (string) $existing->reinspection_run_id !== $reinspection->reinspectionRunId
                || (string) $existing->definition_hash !== $reinspection->definitionHash
                || (string) $existing->outcome !== $reinspection->outcome->value
                || (string) $existing->closure_status !== $reinspection->closureStatus->value
                || (bool) $existing->may_close !== $reinspection->mayClose
                || (bool) $existing->requires_assurance !== $reinspection->requiresAssurance
                || (string) $existing->reason_codes !== $this->json($reinspection->reasonCodes)
            ) {
                throw new LogicException('Reinspection identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_reinspections')->insert([
            'company_id' => $context['company_id'],
            'reinspection_id' => $reinspection->reinspectionId,
            'finding_id' => $reinspection->findingId,
            'original_run_id' => $reinspection->originalRunId,
            'reinspection_run_id' => $reinspection->reinspectionRunId,
            'definition_key' => $reinspection->definitionKey,
            'definition_version' => $reinspection->definitionVersion,
            'definition_hash' => $reinspection->definitionHash,
            'subject_type' => $reinspection->subjectType,
            'subject_id' => $reinspection->subjectId,
            'outcome' => $reinspection->outcome->value,
            'closure_status' => $reinspection->closureStatus->value,
            'may_close' => $reinspection->mayClose,
            'requires_assurance' => $reinspection->requiresAssurance,
            'requires_human_review' => $reinspection->requiresHumanReview,
            'reason_codes' => $this->json($reinspection->reasonCodes),
            'completed_at' => $reinspection->completedAt,
            ...$this->contextColumns($context),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function recordAssuranceClearance(AssuranceClearanceDecision $clearance, ShieldExecutionContext $context): void
    {
        $existing = DB::table('titan_shield_assurance_clearances')
            ->where('company_id', $context->companyId)
            ->where('clearance_id', $clearance->clearanceId)
            ->first();
        if ($existing !== null) {
            if ((string) $existing->finding_id !== $clearance->findingId || (string) $existing->reinspection_id !== $clearance->reinspectionId || (string) $existing->decision !== $clearance->decision || (string) $existing->evidence_fingerprint !== $clearance->evidenceFingerprint || (string) $existing->policy_version !== (string) $clearance->policyVersion) {
                throw new LogicException('Assurance clearance identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_assurance_clearances')->insert([
            'company_id' => $context->companyId,
            'clearance_id' => $clearance->clearanceId,
            'finding_id' => $clearance->findingId,
            'reinspection_id' => $clearance->reinspectionId,
            'reinspection_run_id' => $clearance->reinspectionRunId,
            'decision' => $clearance->decision,
            'may_close' => $clearance->mayClose,
            'score' => $clearance->score,
            'policy_version' => $clearance->policyVersion,
            'evidence_fingerprint' => $clearance->evidenceFingerprint,
            'reason_codes' => $this->json($clearance->reasonCodes),
            'raw_summary' => $this->json($clearance->rawSummary),
            'assessed_at' => $clearance->assessedAt,
            ...$this->contextColumns($context->toArray()),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function recordKnowledgeBindingReceipt(KnowledgeBindingReceipt $receipt): void
    {
        $context = $receipt->context->toArray();
        $existing = DB::table('titan_shield_knowledge_bindings')
            ->where('company_id', $context['company_id'])
            ->where('binding_id', $receipt->bindingId)
            ->first();
        if ($existing !== null) {
            if ((string) $existing->run_id !== $receipt->runId || (string) $existing->knowledge_key !== $receipt->knowledgeKey || (string) $existing->status !== $receipt->status || (string) $existing->binding_mode !== $receipt->bindingMode || (string) ($existing->resolved_hash ?? '') !== (string) ($receipt->resolvedHash ?? '')) {
                throw new LogicException('Knowledge binding identity is immutable and conflicts with an existing record.');
            }
            return;
        }

        $now = now();
        DB::table('titan_shield_knowledge_bindings')->insert([
            'company_id' => $context['company_id'],
            'binding_id' => $receipt->bindingId,
            'run_id' => $receipt->runId,
            'definition_key' => $receipt->definitionKey,
            'definition_version' => $receipt->definitionVersion,
            'definition_hash' => $receipt->definitionHash,
            'vertical_key' => $receipt->verticalKey,
            'jurisdiction' => $receipt->jurisdiction,
            'knowledge_key' => $receipt->knowledgeKey,
            'authority_domain' => $receipt->authorityDomain,
            'status' => $receipt->status,
            'binding_mode' => $receipt->bindingMode,
            'blocking' => $receipt->blocking,
            'resolved_version' => $receipt->resolvedVersion,
            'resolved_hash' => $receipt->resolvedHash,
            'reason_codes' => $this->json($receipt->reasonCodes),
            ...$this->contextColumns($context),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function applyFindingLifecycle(
        string $findingId,
        FindingLifecycleStatus $targetStatus,
        array $reasonCodes,
        ShieldExecutionContext $context,
        ?string $reinspectionId = null,
        ?string $reinspectionRunId = null,
    ): void {
        if (trim($findingId) === '') {
            throw new LogicException('findingId must not be empty.');
        }
        if ($reasonCodes === []) {
            throw new LogicException('Finding lifecycle transition requires at least one reason code.');
        }

        DB::transaction(function () use ($findingId, $targetStatus, $reasonCodes, $context, $reinspectionId, $reinspectionRunId): void {
            $finding = DB::table('titan_shield_findings')
                ->where('company_id', $context->companyId)
                ->where('finding_id', $findingId)
                ->lockForUpdate()
                ->first();

            if ($finding === null) {
                throw new LogicException('Finding does not exist in the active tenant scope.');
            }

            $fromStatus = (string) $finding->status;
            if ($fromStatus === $targetStatus->value) {
                return;
            }
            if ($fromStatus === FindingLifecycleStatus::Closed->value && $targetStatus !== FindingLifecycleStatus::Closed) {
                throw new LogicException('Closed findings cannot be reopened through the reinspection lifecycle.');
            }

            $transitionSeed = implode('|', [
                (string) $context->companyId,
                $findingId,
                $fromStatus,
                $targetStatus->value,
                $reinspectionId ?? '',
                $reinspectionRunId ?? '',
                $context->traceId,
            ]);
            $transitionId = hash('sha256', $transitionSeed);
            $now = now();

            DB::table('titan_shield_finding_transitions')->insertOrIgnore([
                'company_id' => $context->companyId,
                'transition_id' => $transitionId,
                'finding_id' => $findingId,
                'from_status' => $fromStatus,
                'to_status' => $targetStatus->value,
                'reason_codes' => $this->json($reasonCodes),
                'reinspection_id' => $reinspectionId,
                'reinspection_run_id' => $reinspectionRunId,
                ...$this->contextColumns($context->toArray()),
                'occurred_at' => $now,
            ]);

            $update = [
                'status' => $targetStatus->value,
                'updated_at' => $now,
            ];
            if ($targetStatus === FindingLifecycleStatus::Closed) {
                $update['closed_at'] = $now;
                $update['closure_reinspection_id'] = $reinspectionId;
                $update['closure_run_id'] = $reinspectionRunId;
            }

            DB::table('titan_shield_findings')
                ->where('company_id', $context->companyId)
                ->where('finding_id', $findingId)
                ->update($update);
        });
    }

    public function recordIntegrationReceipt(array $receipt): void
    {
        foreach (['receipt_id', 'target', 'event_type', 'status', 'payload', 'company_id', 'trace_id', 'correlation_id', 'causation_id', 'root_causation_id'] as $required) {
            if (! array_key_exists($required, $receipt)) {
                throw new LogicException('Integration receipt missing field: ' . $required);
            }
        }

        $payload = is_array($receipt['payload']) ? $receipt['payload'] : ['value' => $receipt['payload']];
        $now = now();
        DB::table('titan_shield_integration_receipts')->insertOrIgnore([
            'company_id' => $receipt['company_id'],
            'receipt_id' => (string) $receipt['receipt_id'],
            'target' => (string) $receipt['target'],
            'event_type' => (string) $receipt['event_type'],
            'status' => (string) $receipt['status'],
            'idempotency_key' => isset($receipt['idempotency_key']) ? (string) $receipt['idempotency_key'] : null,
            'payload_hash' => hash('sha256', $this->json($payload)),
            'payload' => $this->json($payload),
            'response' => isset($receipt['response']) ? $this->json((array) $receipt['response']) : null,
            'trace_id' => (string) $receipt['trace_id'],
            'correlation_id' => (string) $receipt['correlation_id'],
            'causation_id' => (string) $receipt['causation_id'],
            'root_causation_id' => (string) $receipt['root_causation_id'],
            'actor_user_id' => $receipt['actor_user_id'] ?? null,
            'source' => (string) ($receipt['source'] ?? 'system'),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    /** @param array<string,mixed> $context @return array<string,mixed> */
    private function contextColumns(array $context): array
    {
        return [
            'trace_id' => $context['trace_id'],
            'correlation_id' => $context['correlation_id'],
            'causation_id' => $context['causation_id'],
            'root_causation_id' => $context['root_causation_id'],
            'actor_user_id' => $context['actor_user_id'],
            'source' => $context['source'],
        ];
    }

    private function json(array $value): string
    {
        return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
}
