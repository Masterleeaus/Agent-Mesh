<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanShield\System\Capabilities\ShieldCapabilityRegistry;
use App\Extensions\TitanShield\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanShield\System\Contracts\ShieldCapabilityRegistryContract;
use App\Extensions\TitanShield\System\Contracts\AssuranceClearancePortContract;
use App\Extensions\TitanShield\System\Contracts\ShieldFindingFeedContract;
use App\Extensions\TitanShield\System\Contracts\ShieldIntegrationEnvelopeExporterContract;
use App\Extensions\TitanShield\System\Contracts\ShieldManagerContract;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Integrations\AssuranceEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\KnowledgeAuthorityAdapter;
use App\Extensions\TitanShield\System\Integrations\RiskEngineAdapter;
use App\Extensions\TitanShield\System\Integrations\SignalEngineAdapter;
use App\Extensions\TitanShield\System\Infrastructure\Persistence\DatabaseShieldRuntimeStore;
use App\Extensions\TitanShield\System\Services\DeterministicRuleEngine;
use App\Extensions\TitanShield\System\Services\AssuranceClearanceNormalizer;
use App\Extensions\TitanShield\System\Services\EvidenceCaptureService;
use App\Extensions\TitanShield\System\Services\GovernanceResponseResolver;
use App\Extensions\TitanShield\System\Services\HumanReviewWorkflow;
use App\Extensions\TitanShield\System\Services\FindingAccessRedactionPolicy;
use App\Extensions\TitanShield\System\Services\VerticalPackCertificationService;
use App\Extensions\TitanShield\System\Services\InspectionDefinitionRegistry;
use App\Extensions\TitanShield\System\Services\InspectionDefinitionValidator;
use App\Extensions\TitanShield\System\Services\InspectionRunEvaluator;
use App\Extensions\TitanShield\System\Services\KnowledgeBindingPolicy;
use App\Extensions\TitanShield\System\Services\InspectionRuntimeCoordinator;
use App\Extensions\TitanShield\System\Services\RemediationIntentFactory;
use App\Extensions\TitanShield\System\Services\ReinspectionClosurePolicy;
use App\Extensions\TitanShield\System\Services\ReinspectionCoordinator;
use App\Extensions\TitanShield\System\Services\ReinspectionService;
use App\Extensions\TitanShield\System\Services\RewindReceiptFactory;
use App\Extensions\TitanShield\System\Services\ShieldIntegrationEnvelopeExporter;
use App\Extensions\TitanShield\System\Services\ShieldAuthorityConstraintFactory;
use App\Extensions\TitanShield\System\Services\ShieldManager;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanShieldServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-shield.php', 'titan-shield');

        $this->app->singleton(ShieldCapabilityRegistryContract::class, ShieldCapabilityRegistry::class);
        $this->app->singleton(InspectionDefinitionValidator::class);
        $this->app->singleton(InspectionDefinitionRegistry::class, static fn ($app): InspectionDefinitionRegistry => new InspectionDefinitionRegistry($app->make(ShieldRuntimeStoreContract::class)));
        $this->app->singleton(DeterministicRuleEngine::class);
        $this->app->singleton(EvidenceCaptureService::class, static fn ($app): EvidenceCaptureService => new EvidenceCaptureService($app->make(ShieldRuntimeStoreContract::class)));
        $this->app->singleton(GovernanceResponseResolver::class);
        $this->app->singleton(ShieldAuthorityConstraintFactory::class);
        $this->app->singleton(InspectionRunEvaluator::class);
        $this->app->singleton(KnowledgeBindingPolicy::class);
        $this->app->singleton(HumanReviewWorkflow::class);
        $this->app->singleton(FindingAccessRedactionPolicy::class);
        $this->app->singleton(VerticalPackCertificationService::class);
        $this->app->singleton(RemediationIntentFactory::class);
        $this->app->singleton(ReinspectionClosurePolicy::class);
        $this->app->singleton(ReinspectionService::class);
        $this->app->singleton(RewindReceiptFactory::class);
        $this->app->singleton(RiskEngineAdapter::class);
        $this->app->singleton(AssuranceEngineAdapter::class);
        $this->app->alias(AssuranceEngineAdapter::class, AssuranceClearancePortContract::class);
        $this->app->singleton(AssuranceClearanceNormalizer::class);
        $this->app->singleton(SignalEngineAdapter::class);
        $this->app->singleton(KnowledgeAuthorityAdapter::class);
        $this->app->singleton(ShieldRuntimeStoreContract::class, DatabaseShieldRuntimeStore::class);
        $this->app->singleton(InspectionRuntimeCoordinator::class);
        $this->app->singleton(ReinspectionCoordinator::class, static function ($app): ReinspectionCoordinator {
            return new ReinspectionCoordinator(
                runtime: $app->make(InspectionRuntimeCoordinator::class),
                service: $app->make(ReinspectionService::class),
                store: $app->make(ShieldRuntimeStoreContract::class),
                signal: $app->make(SignalEngineAdapter::class),
                assurance: $app->make(AssuranceClearancePortContract::class),
                assuranceNormalizer: $app->make(AssuranceClearanceNormalizer::class),
            );
        });
        $this->app->singleton(ShieldIntegrationEnvelopeExporterContract::class, ShieldIntegrationEnvelopeExporter::class);
        $this->app->alias(ShieldIntegrationEnvelopeExporterContract::class, ShieldFindingFeedContract::class);

        $this->app->singleton(ShieldManagerContract::class, static function ($app): ShieldManager {
            return new ShieldManager(
                capabilities: $app->make(ShieldCapabilityRegistryContract::class),
                definitionValidator: $app->make(InspectionDefinitionValidator::class),
                ruleEngine: $app->make(DeterministicRuleEngine::class),
                governanceResolver: $app->make(GovernanceResponseResolver::class),
                runtimeCoordinator: $app->make(InspectionRuntimeCoordinator::class),
                humanReviewWorkflow: $app->make(HumanReviewWorkflow::class),
                remediationIntentFactory: $app->make(RemediationIntentFactory::class),
                runtimeStore: $app->make(ShieldRuntimeStoreContract::class),
                authorityConstraintFactory: $app->make(ShieldAuthorityConstraintFactory::class),
                reinspectionCoordinator: $app->make(ReinspectionCoordinator::class),
            );
        });
    }

    public function boot(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-shield');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([
            __DIR__ . '/../config/titan-shield.php' => config_path('titan-shield.php'),
        ], 'titan-shield-config');

        if ((bool) config('titan-shield.enabled', true)) {
            $this->registerRoutes();
        }

        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class]);
        }
    }

    public function registerKey(): string
    {
        return 'titan-shield';
    }

    public static function uninstall(): void
    {
        // Data is retained by default. Uninstall only removes the owned published
        // configuration file and remains safe to run repeatedly.
        File::delete(config_path('titan-shield.php'));
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];

        $router->group([
            'middleware' => config('titan-shield.routes.user_middleware', ['web', 'auth']),
            'prefix' => 'dashboard/user/titan-shield',
            'as' => 'dashboard.user.titan.shield.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/user.php';
        });

        $router->group([
            'middleware' => config('titan-shield.routes.admin_middleware', ['web', 'auth', 'admin']),
            'prefix' => 'dashboard/admin/titan-shield',
            'as' => 'dashboard.admin.titan.shield.',
        ], static function (Router $router): void {
            require __DIR__ . '/../routes/admin.php';
        });
    }
}
