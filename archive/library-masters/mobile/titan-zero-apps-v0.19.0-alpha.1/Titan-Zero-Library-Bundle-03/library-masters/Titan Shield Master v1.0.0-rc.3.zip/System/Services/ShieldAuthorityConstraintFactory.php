<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;
use InvalidArgumentException;

final class ShieldAuthorityConstraintFactory
{
    /**
     * Build a Titan governance-authority-constraint v1.0 upper-bound record.
     * Shield can contract or block authority; it can never increase desired or earned authority.
     *
     * @return array<string,mixed>
     */
    public function fromFinding(
        Finding $finding,
        GovernanceResponse $response,
        string $agentId,
        string $capability,
        ?string $capabilityVariant = null,
        ?string $vertical = null,
        ?string $workflow = null,
        ?string $authorityContext = null,
        string $policyVersion = 'shield-governance-v1',
        ?string $evaluatedAt = null,
        ?string $expiresAt = null,
    ): array {
        if (trim($agentId) === '' || trim($capability) === '' || trim($policyVersion) === '') {
            throw new InvalidArgumentException('agent_id, capability and policy_version are required.');
        }

        [$disposition, $ceiling] = match ($finding->severity->value) {
            'critical' => ['HOLD', 0.0],
            'high' => ['REQUIRE_APPROVAL', null],
            'medium' => ['CONTRACT', 50.0],
            default => ['PASS', null],
        };

        if ($finding->outcome->value === 'inconclusive') {
            $disposition = 'REQUIRE_APPROVAL';
            $ceiling = null;
        }

        if ($response->blockProgression && $finding->severity->value === 'critical') {
            $disposition = 'HOLD';
            $ceiling = 0.0;
        }

        $evaluatedAt ??= date(DATE_ATOM);
        $context = $finding->context->toArray();
        $reasonCodes = array_values(array_unique(array_merge(
            ['SHIELD_' . strtoupper($finding->severity->value)],
            $finding->reasonCodes,
            $response->reasonCodes,
        )));

        return [
            'schema_version' => '1.0',
            'constraint_id' => hash('sha256', implode('|', [
                'titan-shield',
                $finding->findingId,
                $agentId,
                $capability,
                (string) $capabilityVariant,
                $policyVersion,
                $finding->definitionHash,
            ])),
            'autonomy_key' => [
                'company_id' => $context['company_id'],
                'agent_id' => $agentId,
                'capability' => $capability,
                'capability_variant' => $capabilityVariant,
                'vertical' => $vertical,
                'workflow' => $workflow,
                'context' => $authorityContext,
            ],
            'source' => 'titan-shield',
            'disposition' => $disposition,
            'ceiling_score' => $ceiling,
            'reason_codes' => $reasonCodes,
            'evidence_refs' => $finding->evidenceIds,
            'policy_version' => $policyVersion,
            'evaluated_at' => $evaluatedAt,
            'expires_at' => $expiresAt,
            'trace_id' => $context['trace_id'],
        ];
    }
}
