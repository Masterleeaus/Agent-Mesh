<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Rules;

use JsonSerializable;

final readonly class RuleEvaluation implements JsonSerializable
{
    /** @param array<string,mixed> $details */
    public function __construct(
        public string $ruleKey,
        public RuleEvaluationStatus $status,
        public string $failureSeverity,
        public array $details = [],
    ) {}

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'rule_key' => $this->ruleKey,
            'status' => $this->status->value,
            'failure_severity' => $this->failureSeverity,
            'details' => $this->details,
        ];
    }
}
