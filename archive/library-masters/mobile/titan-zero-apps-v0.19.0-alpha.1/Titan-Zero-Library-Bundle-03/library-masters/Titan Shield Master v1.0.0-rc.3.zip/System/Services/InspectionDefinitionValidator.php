<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Definitions\EvidenceRequirement;
use App\Extensions\TitanShield\System\Domain\Definitions\InspectionRule;
use App\Extensions\TitanShield\System\Domain\Definitions\KnowledgeReference;
use DateTimeImmutable;
use InvalidArgumentException;

final class InspectionDefinitionValidator
{
    private const REQUIRED = [
        'definition_key', 'version', 'name', 'description', 'vertical_key',
        'inspection_type', 'scope', 'status', 'rules', 'evidence_requirements',
        'pass_policy', 'conditional_pass_policy', 'review_policy', 'remediation_policy',
        'knowledge_references', 'source_pack', 'effective_from', 'supersedes_version',
    ];

    private const ALLOWED = [
        'definition_key', 'version', 'name', 'description', 'vertical_key',
        'inspection_type', 'scope', 'status', 'rules', 'evidence_requirements',
        'pass_policy', 'conditional_pass_policy', 'review_policy', 'remediation_policy',
        'knowledge_references', 'source_pack', 'effective_from', 'supersedes_version', 'definition_hash',
    ];

    /** @param array<string,mixed> $payload */
    public function validate(array $payload): void
    {
        foreach (self::REQUIRED as $key) {
            if (! array_key_exists($key, $payload)) {
                throw new InvalidArgumentException('Missing required inspection definition field: ' . $key);
            }
        }

        foreach (array_keys($payload) as $key) {
            if (! in_array($key, self::ALLOWED, true)) {
                throw new InvalidArgumentException('Unknown inspection definition field: ' . $key);
            }
        }

        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', (string) $payload['definition_key']) !== 1) {
            throw new InvalidArgumentException('definition_key is invalid.');
        }
        if (preg_match('/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$/', (string) $payload['version']) !== 1) {
            throw new InvalidArgumentException('version must be semantic version format.');
        }
        if (trim((string) $payload['name']) === '' || strlen((string) $payload['name']) > 180) {
            throw new InvalidArgumentException('name is invalid.');
        }
        if (strlen((string) $payload['description']) > 2000) {
            throw new InvalidArgumentException('description is too long.');
        }
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', (string) $payload['vertical_key']) !== 1) {
            throw new InvalidArgumentException('vertical_key is invalid.');
        }
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,79}$/', (string) $payload['inspection_type']) !== 1) {
            throw new InvalidArgumentException('inspection_type is invalid.');
        }
        if (! in_array($payload['scope'], ['global', 'tenant'], true)) {
            throw new InvalidArgumentException('scope must be global or tenant.');
        }
        if (! in_array($payload['status'], ['draft', 'active', 'deprecated'], true)) {
            throw new InvalidArgumentException('status is invalid.');
        }
        if (! is_array($payload['rules']) || $payload['rules'] === []) {
            throw new InvalidArgumentException('rules must contain at least one deterministic rule.');
        }
        foreach ($payload['rules'] as $rule) {
            if (! is_array($rule)) {
                throw new InvalidArgumentException('Each rule must be an object.');
            }
            InspectionRule::fromArray($rule);
        }
        if (! is_array($payload['evidence_requirements'])) {
            throw new InvalidArgumentException('evidence_requirements must be an array.');
        }
        foreach ($payload['evidence_requirements'] as $requirement) {
            if (! is_array($requirement)) {
                throw new InvalidArgumentException('Each evidence requirement must be an object.');
            }
            EvidenceRequirement::fromArray($requirement);
        }
        foreach (['pass_policy', 'conditional_pass_policy', 'review_policy', 'remediation_policy'] as $policyKey) {
            if (! is_array($payload[$policyKey])) {
                throw new InvalidArgumentException($policyKey . ' must be an object.');
            }
        }
        if (! is_array($payload['knowledge_references'])) {
            throw new InvalidArgumentException('knowledge_references must be an array.');
        }
        $knowledgeKeys = [];
        foreach ($payload['knowledge_references'] as $reference) {
            if (! is_array($reference)) {
                throw new InvalidArgumentException('Each knowledge reference must be an object.');
            }
            $parsedReference = KnowledgeReference::fromArray($reference);
            $knowledgeKeys[$parsedReference->knowledgeKey] = true;
        }
        foreach ($payload['rules'] as $rule) {
            $referenceKey = is_array($rule) ? trim((string) ($rule['knowledge_reference'] ?? '')) : '';
            if ($referenceKey !== '' && ! isset($knowledgeKeys[$referenceKey])) {
                throw new InvalidArgumentException('Rule knowledge_reference must match a declared knowledge reference: ' . $referenceKey);
            }
        }
        if (preg_match('/^[a-z0-9][a-z0-9._\/-]{1,179}$/', (string) $payload['source_pack']) !== 1) {
            throw new InvalidArgumentException('source_pack is invalid.');
        }
        try {
            new DateTimeImmutable((string) $payload['effective_from']);
        } catch (\Throwable $e) {
            throw new InvalidArgumentException('effective_from must be an ISO-8601 compatible datetime.', 0, $e);
        }
        if ($payload['supersedes_version'] !== null
            && preg_match('/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?$/', (string) $payload['supersedes_version']) !== 1) {
            throw new InvalidArgumentException('supersedes_version must be semantic version format when supplied.');
        }
    }
}
