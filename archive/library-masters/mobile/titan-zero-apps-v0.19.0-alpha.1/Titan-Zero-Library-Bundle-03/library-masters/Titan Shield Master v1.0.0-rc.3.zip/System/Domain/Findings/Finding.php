<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Findings;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use InvalidArgumentException;
use JsonSerializable;

final readonly class Finding implements JsonSerializable
{
    /** @param list<string> $evidenceIds @param list<string> $reasonCodes */
    public function __construct(
        public string $findingId,
        public string $definitionKey,
        public string $definitionVersion,
        public string $definitionHash,
        public string $code,
        public FindingSeverity $severity,
        public InspectionOutcome $outcome,
        public string $subjectType,
        public string $subjectId,
        public array $evidenceIds,
        public array $reasonCodes,
        public ShieldExecutionContext $context,
    ) {
        foreach (['findingId' => $this->findingId, 'definitionKey' => $this->definitionKey, 'definitionVersion' => $this->definitionVersion, 'code' => $this->code, 'subjectType' => $this->subjectType, 'subjectId' => $this->subjectId] as $field => $value) {
            if (trim($value) === '') {
                throw new InvalidArgumentException($field . ' must not be empty.');
            }
        }
        if (preg_match('/^[a-f0-9]{64}$/i', $this->definitionHash) !== 1) {
            throw new InvalidArgumentException('definitionHash must be SHA-256 hex.');
        }
        foreach (array_merge($this->evidenceIds, $this->reasonCodes) as $value) {
            if (! is_string($value) || trim($value) === '') {
                throw new InvalidArgumentException('Evidence IDs and reason codes must be non-empty strings.');
            }
        }
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'finding_id' => $this->findingId,
            'definition_key' => $this->definitionKey,
            'definition_version' => $this->definitionVersion,
            'definition_hash' => $this->definitionHash,
            'code' => $this->code,
            'severity' => $this->severity->value,
            'outcome' => $this->outcome->value,
            'subject_type' => $this->subjectType,
            'subject_id' => $this->subjectId,
            'evidence_ids' => $this->evidenceIds,
            'reason_codes' => $this->reasonCodes,
            'context' => $this->context->toArray(),
        ];
    }
}
