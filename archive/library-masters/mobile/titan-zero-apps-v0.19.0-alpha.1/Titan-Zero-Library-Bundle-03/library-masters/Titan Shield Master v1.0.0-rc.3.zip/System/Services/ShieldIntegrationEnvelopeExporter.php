<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Contracts\ShieldIntegrationEnvelopeExporterContract;
use App\Extensions\TitanShield\System\Domain\Findings\Finding;
use App\Extensions\TitanShield\System\Domain\Governance\GovernanceResponse;

final class ShieldIntegrationEnvelopeExporter implements ShieldIntegrationEnvelopeExporterContract
{
    public function forRisk(Finding $finding, GovernanceResponse $response): array
    {
        return $this->envelope('risk', 'shield.finding.evaluate_risk', $finding, $response);
    }

    public function forAssurance(Finding $finding, GovernanceResponse $response): array
    {
        return $this->envelope('assurance', 'shield.finding.verify_assurance', $finding, $response);
    }

    public function forCommandBus(Finding $finding, GovernanceResponse $response): array
    {
        return $this->envelope('command_bus', 'shield.remediation.request', $finding, $response);
    }

    public function forCouncil(Finding $finding, GovernanceResponse $response): array
    {
        return $this->envelope('model_council', 'shield.finding.escalation_request', $finding, $response);
    }

    /** @return array<string,mixed> */
    private function envelope(string $target, string $operation, Finding $finding, GovernanceResponse $response): array
    {
        $context = $finding->context->toArray();
        return [
            'envelope_version' => '1.0',
            'target' => $target,
            'operation' => $operation,
            'idempotency_key' => hash('sha256', implode('|', [$target, $operation, $finding->findingId, $finding->definitionHash])),
            'company_id' => $context['company_id'],
            'trace_id' => $context['trace_id'],
            'correlation_id' => $context['correlation_id'],
            'causation_id' => $context['causation_id'],
            'root_causation_id' => $context['root_causation_id'],
            'finding' => $finding->jsonSerialize(),
            'governance_response' => $response->jsonSerialize(),
            'authority' => [
                'shield_local_severity_only' => true,
                'direct_mutation' => false,
                'hidden_chain_of_thought_included' => false,
            ],
        ];
    }
}
