<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Context\ShieldExecutionContext;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceCaptureRequest;
use App\Extensions\TitanShield\System\Domain\Evidence\EvidenceManifest;
use InvalidArgumentException;
use RuntimeException;

final class EvidenceCaptureService
{
    public function __construct(private readonly ?ShieldRuntimeStoreContract $store = null) {}

    public function capture(EvidenceCaptureRequest $request, ShieldExecutionContext $context): EvidenceManifest
    {
        $this->assertReadableRegularFile($request->filePath);
        $hash = hash_file('sha256', $request->filePath);
        if (! is_string($hash)) {
            throw new RuntimeException('Unable to hash evidence file.');
        }
        $size = filesize($request->filePath);
        if (! is_int($size) || $size < 0) {
            throw new RuntimeException('Unable to determine evidence size.');
        }

        $manifest = new EvidenceManifest(
            evidenceId: $request->evidenceId,
            evidenceKey: $request->evidenceKey,
            originalFilename: $request->originalFilename,
            mimeType: $request->mimeType,
            sizeBytes: $size,
            sha256: $hash,
            capturedAt: $request->capturedAt,
            captureDeviceId: $request->captureDeviceId,
            storageReference: $request->storageReference,
            metadata: $request->metadata,
            context: $context,
        );

        $this->store?->recordEvidence($manifest);

        return $manifest;
    }

    public function verify(EvidenceManifest $manifest, string $filePath): bool
    {
        $this->assertReadableRegularFile($filePath);
        $hash = hash_file('sha256', $filePath);
        return is_string($hash) && hash_equals($manifest->sha256, $hash);
    }

    private function assertReadableRegularFile(string $filePath): void
    {
        if (trim($filePath) === '' || ! is_file($filePath) || ! is_readable($filePath) || is_link($filePath)) {
            throw new InvalidArgumentException('Evidence source must be a readable regular non-symlink file supplied by trusted capture code.');
        }
    }
}
