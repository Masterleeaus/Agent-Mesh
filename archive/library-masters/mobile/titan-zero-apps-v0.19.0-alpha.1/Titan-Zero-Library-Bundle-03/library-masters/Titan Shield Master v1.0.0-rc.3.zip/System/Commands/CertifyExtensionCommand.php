<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Commands;

use App\Extensions\TitanShield\System\Contracts\AssuranceClearancePortContract;
use App\Extensions\TitanShield\System\Contracts\ShieldCapabilityRegistryContract;
use App\Extensions\TitanShield\System\Contracts\ShieldManagerContract;
use App\Extensions\TitanShield\System\Contracts\ShieldRuntimeStoreContract;
use App\Extensions\TitanShield\System\Services\FindingAccessRedactionPolicy;
use App\Extensions\TitanShield\System\Services\VerticalPackCertificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-shield:certify {--json : Emit JSON evidence only}';
    protected $description = 'Run non-destructive Titan host certification checks for titan-shield.';

    public function handle(): int
    {
        $checks = [];
        $record = static function (string $name, bool $passed, string $detail = '') use (&$checks): void {
            $checks[] = ['check' => $name, 'passed' => $passed, 'detail' => $detail];
        };

        $record('php', PHP_VERSION_ID >= 80300, PHP_VERSION);
        $record('laravel', str_starts_with((string) app()->version(), '10.'), (string) app()->version());
        $record('provider_binding', app()->providerIsLoaded(\App\Extensions\TitanShield\System\TitanShieldServiceProvider::class));
        $record('storage', is_writable(storage_path()), storage_path());

        foreach ([
            ShieldManagerContract::class,
            ShieldCapabilityRegistryContract::class,
            ShieldRuntimeStoreContract::class,
            AssuranceClearancePortContract::class,
            FindingAccessRedactionPolicy::class,
            VerticalPackCertificationService::class,
        ] as $binding) {
            $record('binding:' . $binding, app()->bound($binding));
        }

        try {
            DB::connection()->getPdo();
            $record('database', DB::connection()->getDriverName() === 'mysql', DB::connection()->getDriverName());
        } catch (Throwable $e) {
            $record('database', false, $e->getMessage());
        }

        $manifestPath = dirname(__DIR__, 2) . '/extension.manifest.json';
        $manifest = is_file($manifestPath) ? json_decode((string) file_get_contents($manifestPath), true) : null;
        $record('manifest', is_array($manifest), $manifestPath);

        if (is_array($manifest)) {
            foreach (($manifest['database']['owned_tables'] ?? []) as $table) {
                $record('table:' . $table, Schema::hasTable((string) $table));
            }
        }

        foreach (['dashboard.user.titan.shield.index', 'dashboard.admin.titan.shield.index'] as $routeName) {
            $record('route:' . $routeName, Route::has($routeName));
        }

        $record('view:panel.layout.app', view()->exists('panel.layout.app'));
        $record('view:titan-shield::index', view()->exists('titan-shield::index'));
        $record('view:titan-shield::admin', view()->exists('titan-shield::admin'));
        $record('config:direct_business_mutation', config('titan-shield.integrations.direct_business_mutation') === false);
        $record('config:ai_vision_closure_authority', config('titan-shield.deterministic_rules.ai_vision_enabled') === false);
        $record('config:queue_disabled', config('titan-shield.queue.enabled') === false);

        $packPath = dirname(__DIR__, 2) . '/resources/inspection-packs/field-home-services/basic-job-completion.v1.json';
        try {
            $pack = json_decode((string) file_get_contents($packPath), true, 512, JSON_THROW_ON_ERROR);
            $certification = app()->make(VerticalPackCertificationService::class)->certify($pack);
            $record('pack:field-home-services/basic-job-completion', ($certification['status'] ?? null) === 'CERTIFIED', (string) ($certification['definition_hash'] ?? ''));
        } catch (Throwable $e) {
            $record('pack:field-home-services/basic-job-completion', false, $e->getMessage());
        }

        $passed = collect($checks)->every(static fn (array $check): bool => $check['passed'] === true);
        $evidence = [
            'schema_version' => '1.1',
            'extension' => 'titan-shield',
            'extension_version' => '1.0.0-rc.2',
            'host_certified' => $passed,
            'checked_at' => now()->toIso8601String(),
            'checks' => $checks,
        ];

        $json = json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($this->option('json')) {
            $this->line((string) $json);
        } else {
            $this->info($passed ? 'Host certification PASS' : 'Host certification FAILED');
            $this->line((string) $json);
        }

        return $passed ? self::SUCCESS : self::FAILURE;
    }
}
