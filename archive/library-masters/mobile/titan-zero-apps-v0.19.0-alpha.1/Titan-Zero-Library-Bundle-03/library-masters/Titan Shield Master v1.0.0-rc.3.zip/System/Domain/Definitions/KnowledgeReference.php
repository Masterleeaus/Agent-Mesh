<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Domain\Definitions;

use InvalidArgumentException;
use JsonSerializable;

final readonly class KnowledgeReference implements JsonSerializable
{
    public function __construct(
        public string $knowledgeKey,
        public ?string $version = null,
        public ?string $contentHash = null,
        public string $authorityDomain = 'regulatory-safety',
        public string $jurisdiction = 'GLOBAL',
        public ?string $verticalKey = null,
        public bool $required = true,
        public bool $requireLiveResolution = false,
    ) {
        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9._:-]{0,179}$/', $this->knowledgeKey) !== 1) {
            throw new InvalidArgumentException('knowledge_key is invalid.');
        }
        if ($this->version !== null && trim($this->version) === '') {
            throw new InvalidArgumentException('Knowledge version must be non-empty when supplied.');
        }
        if ($this->contentHash !== null && preg_match('/^[a-f0-9]{64}$/i', $this->contentHash) !== 1) {
            throw new InvalidArgumentException('Knowledge content_hash must be SHA-256 hex when supplied.');
        }
        if (preg_match('/^[a-z0-9][a-z0-9._-]{1,79}$/', $this->authorityDomain) !== 1) {
            throw new InvalidArgumentException('authority_domain is invalid.');
        }
        if (preg_match('/^(GLOBAL|[A-Z]{2}(?:-[A-Z0-9]{1,12}){0,3})$/', $this->jurisdiction) !== 1) {
            throw new InvalidArgumentException('jurisdiction must be GLOBAL or a canonical uppercase jurisdiction code.');
        }
        if ($this->verticalKey !== null && preg_match('/^[a-z0-9][a-z0-9._-]{1,119}$/', $this->verticalKey) !== 1) {
            throw new InvalidArgumentException('vertical_key is invalid when supplied on a knowledge reference.');
        }
        if ($this->requireLiveResolution && ! $this->required) {
            throw new InvalidArgumentException('require_live_resolution is meaningful only for required knowledge references.');
        }
    }

    /** @param array<string,mixed> $payload */
    public static function fromArray(array $payload): self
    {
        foreach (['knowledge_key', 'authority_domain', 'jurisdiction', 'required', 'require_live_resolution'] as $requiredField) {
            if (! array_key_exists($requiredField, $payload)) {
                throw new InvalidArgumentException('Knowledge reference missing required field: ' . $requiredField);
            }
        }

        return new self(
            knowledgeKey: (string) ($payload['knowledge_key'] ?? ''),
            version: isset($payload['version']) ? (string) $payload['version'] : null,
            contentHash: isset($payload['content_hash']) ? strtolower((string) $payload['content_hash']) : null,
            authorityDomain: (string) ($payload['authority_domain'] ?? 'regulatory-safety'),
            jurisdiction: (string) ($payload['jurisdiction'] ?? 'GLOBAL'),
            verticalKey: isset($payload['vertical_key']) ? (string) $payload['vertical_key'] : null,
            required: array_key_exists('required', $payload) ? (bool) $payload['required'] : true,
            requireLiveResolution: (bool) ($payload['require_live_resolution'] ?? false),
        );
    }

    public function isExactlyPinned(): bool
    {
        return $this->version !== null && $this->contentHash !== null;
    }

    /** @return array<string,mixed> */
    public function jsonSerialize(): array
    {
        return [
            'knowledge_key' => $this->knowledgeKey,
            'version' => $this->version,
            'content_hash' => $this->contentHash,
            'authority_domain' => $this->authorityDomain,
            'jurisdiction' => $this->jurisdiction,
            'vertical_key' => $this->verticalKey,
            'required' => $this->required,
            'require_live_resolution' => $this->requireLiveResolution,
        ];
    }
}
