<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Services;

use App\Extensions\TitanShield\System\Domain\Definitions\KnowledgeReference;
use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeResolution;

final class KnowledgeBindingPolicy
{
    /** @return array{status:string,binding_mode:string,blocking:bool,reason_code:string,resolved_version:?string,resolved_hash:?string} */
    public function bind(KnowledgeReference $reference, KnowledgeResolution $resolution, string $jurisdiction, string $verticalKey): array
    {
        $jurisdiction = trim($jurisdiction);
        if ($reference->jurisdiction !== 'GLOBAL' && $jurisdiction !== $reference->jurisdiction) {
            return $this->blocked($reference, 'KNOWLEDGE_JURISDICTION_MISMATCH');
        }
        if ($reference->verticalKey !== null && $reference->verticalKey !== $verticalKey) {
            return $this->blocked($reference, 'KNOWLEDGE_VERTICAL_MISMATCH');
        }

        if ($resolution->status === 'RESOLVED') {
            $version = $resolution->resolvedVersion;
            $hash = $resolution->resolvedHash !== null ? strtolower($resolution->resolvedHash) : null;
            if ($version === null || $hash === null || preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
                return $this->blocked($reference, 'KNOWLEDGE_RESOLUTION_INCOMPLETE');
            }
            if ($reference->version !== null && $reference->version !== $version) {
                return $this->blocked($reference, 'KNOWLEDGE_PIN_MISMATCH');
            }
            if ($reference->contentHash !== null && ! hash_equals(strtolower($reference->contentHash), $hash)) {
                return $this->blocked($reference, 'KNOWLEDGE_PIN_MISMATCH');
            }

            return [
                'status' => 'BOUND',
                'binding_mode' => 'LIVE',
                'blocking' => false,
                'reason_code' => 'KNOWLEDGE_AUTHORITY_RESOLVED',
                'resolved_version' => $version,
                'resolved_hash' => $hash,
            ];
        }

        if ($reference->isExactlyPinned() && ! $reference->requireLiveResolution) {
            return [
                'status' => 'BOUND',
                'binding_mode' => 'PINNED',
                'blocking' => false,
                'reason_code' => 'KNOWLEDGE_REFERENCE_PINNED',
                'resolved_version' => $reference->version,
                'resolved_hash' => strtolower((string) $reference->contentHash),
            ];
        }

        if (! $reference->required) {
            return [
                'status' => 'UNRESOLVED',
                'binding_mode' => 'NONE',
                'blocking' => false,
                'reason_code' => 'OPTIONAL_KNOWLEDGE_UNRESOLVED',
                'resolved_version' => null,
                'resolved_hash' => null,
            ];
        }

        return $this->blocked($reference, 'KNOWLEDGE_AUTHORITY_UNRESOLVED');
    }

    /** @return array{status:string,binding_mode:string,blocking:bool,reason_code:string,resolved_version:?string,resolved_hash:?string} */
    private function blocked(KnowledgeReference $reference, string $reasonCode): array
    {
        return [
            'status' => 'UNRESOLVED',
            'binding_mode' => 'NONE',
            'blocking' => $reference->required,
            'reason_code' => $reasonCode,
            'resolved_version' => null,
            'resolved_hash' => null,
        ];
    }
}
