<?php

declare(strict_types=1);

namespace App\Extensions\TitanShield\System\Integrations;

use App\Extensions\TitanShield\System\Domain\Knowledge\KnowledgeResolution;
use InvalidArgumentException;

final class KnowledgeAuthorityAdapter
{
    /** @param array<string,mixed> $reference */
    public function resolve(array $reference): KnowledgeResolution
    {
        $key = trim((string) ($reference['knowledge_key'] ?? $reference['reference_key'] ?? $reference['key'] ?? ''));
        if ($key === '') {
            throw new InvalidArgumentException('Knowledge reference_key is required.');
        }
        $reference['knowledge_key'] = $key;
        $reference['reference_key'] = $key;

        if (! function_exists('app')) {
            return $this->unresolved($reference, null);
        }

        $contract = 'App\\Extensions\\TitanKnowledgeAuthority\\System\\Contracts\\KnowledgeAuthorityContract';
        try {
            $container = app();
            if (method_exists($container, 'bound') && $container->bound($contract)) {
                $authority = $container->make($contract);
                $health = method_exists($authority, 'health') ? $authority->health() : null;

                // Pass 1 of Knowledge Authority intentionally exposes health only.
                // If a future release adds a resolver to the same public contract,
                // Shield can consume it without changing inspection-domain ownership.
                if (method_exists($authority, 'resolve')) {
                    $result = $authority->resolve($reference);
                    $array = is_array($result) ? $result : (method_exists($result, 'toArray') ? $result->toArray() : []);
                    $version = trim((string) ($array['version'] ?? $array['resolved_version'] ?? $array['source_version'] ?? ''));
                    $hash = trim((string) ($array['hash'] ?? $array['resolved_hash'] ?? $array['content_hash'] ?? ''));
                    if ($version !== '' && preg_match('/^[a-f0-9]{64}$/i', $hash) === 1) {
                        return new KnowledgeResolution('RESOLVED', $reference, 'KNOWLEDGE_RESOLVED', $version, strtolower($hash), $array);
                    }
                }

                return $this->unresolved($reference, is_array($health) ? $health : null);
            }
        } catch (\Throwable $exception) {
            return new KnowledgeResolution(
                status: 'UNRESOLVED',
                reference: $reference,
                reasonCode: 'KNOWLEDGE_AUTHORITY_ADAPTER_FAILURE',
                authorityResponse: ['error_type' => $exception::class],
            );
        }

        return $this->unresolved($reference, null);
    }

    /** @param array<string,mixed> $reference @param array<string,mixed>|null $health */
    private function unresolved(array $reference, ?array $health): KnowledgeResolution
    {
        return new KnowledgeResolution(
            status: 'UNRESOLVED',
            reference: $reference,
            reasonCode: 'KNOWLEDGE_RESOLVER_CAPABILITY_UNAVAILABLE',
            resolvedVersion: null,
            resolvedHash: null,
            authorityResponse: $health,
        );
    }
}
