<?php

use App\Extensions\TitanShield\System\Http\Controllers\AdminController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', AdminController::class)->name('index');
