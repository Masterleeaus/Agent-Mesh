<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_shield_inspection_definitions') && ! Schema::hasColumn('titan_shield_inspection_definitions', 'root_causation_id')) {
            Schema::table('titan_shield_inspection_definitions', static function (Blueprint $table): void {
                $table->uuid('root_causation_id')->nullable()->index('ts_def_root_caus_idx');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_shield_inspection_definitions') && Schema::hasColumn('titan_shield_inspection_definitions', 'root_causation_id')) {
            Schema::table('titan_shield_inspection_definitions', static function (Blueprint $table): void {
                $table->dropIndex('ts_def_root_caus_idx');
                $table->dropColumn('root_causation_id');
            });
        }
    }
};
