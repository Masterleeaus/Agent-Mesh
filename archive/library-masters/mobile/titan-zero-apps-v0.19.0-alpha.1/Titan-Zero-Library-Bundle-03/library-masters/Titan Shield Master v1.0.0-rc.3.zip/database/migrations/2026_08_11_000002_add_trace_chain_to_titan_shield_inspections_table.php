<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_inspections')) {
            return;
        }

        $addCausation = ! Schema::hasColumn('titan_shield_inspections', 'causation_id');
        $addActor = ! Schema::hasColumn('titan_shield_inspections', 'actor_user_id');
        $addSource = ! Schema::hasColumn('titan_shield_inspections', 'source');

        if (! $addCausation && ! $addActor && ! $addSource) {
            return;
        }

        Schema::table('titan_shield_inspections', function (Blueprint $table) use ($addCausation, $addActor, $addSource): void {
            if ($addCausation) {
                $table->uuid('causation_id')->nullable()->index('ts_inspections_causation_idx');
            }

            if ($addActor) {
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_inspections_actor_idx');
            }

            if ($addSource) {
                $table->string('source', 80)->default('system')->index('ts_inspections_source_idx');
            }
        });
    }

    public function down(): void
    {
        if (! Schema::hasTable('titan_shield_inspections')) {
            return;
        }

        foreach (['causation_id', 'actor_user_id', 'source'] as $column) {
            if (Schema::hasColumn('titan_shield_inspections', $column)) {
                Schema::table('titan_shield_inspections', static function (Blueprint $table) use ($column): void {
                    $table->dropColumn($column);
                });
            }
        }
    }
};
