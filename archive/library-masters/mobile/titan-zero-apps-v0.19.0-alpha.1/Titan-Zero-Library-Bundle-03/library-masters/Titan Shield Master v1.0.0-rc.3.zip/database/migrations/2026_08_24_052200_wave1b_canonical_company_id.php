<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Wave 1B canonical tenant-boundary migration.
     * company_id is the sole Titan business/tenant boundary.
     * If both columns are present we fail closed rather than guess semantics.
     */
    public function up(): void
    {
        foreach ($this->tables() as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'tenant_company_id')) {
                continue;
            }
            if (Schema::hasColumn($table, 'company_id')) {
                throw new RuntimeException("Wave 1B cannot canonicalize {$table}: both tenant_company_id and company_id exist; resolve semantic collision explicitly.");
            }
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('tenant_company_id', 'company_id');
            });
        }
    }

    public function down(): void
    {
        foreach (array_reverse($this->tables()) as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id') || Schema::hasColumn($table, 'tenant_company_id')) {
                continue;
            }
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('company_id', 'tenant_company_id');
            });
        }
    }

    /** @return list<string> */
    private function tables(): array
    {
        return [
            'titan_shield_assurance_clearances',
            'titan_shield_evidence',
            'titan_shield_finding_transitions',
            'titan_shield_findings',
            'titan_shield_human_reviews',
            'titan_shield_inspection_definitions',
            'titan_shield_inspection_item_results',
            'titan_shield_inspection_runs',
            'titan_shield_inspections',
            'titan_shield_integration_receipts',
            'titan_shield_knowledge_bindings',
            'titan_shield_reinspections',
            'titan_shield_remediation_intents'
        ];
    }
};
