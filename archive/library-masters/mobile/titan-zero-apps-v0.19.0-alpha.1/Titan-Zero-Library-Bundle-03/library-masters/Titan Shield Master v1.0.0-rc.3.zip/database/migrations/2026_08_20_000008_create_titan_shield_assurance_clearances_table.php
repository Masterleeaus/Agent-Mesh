<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_assurance_clearances')) {
            Schema::create('titan_shield_assurance_clearances', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_acl_tenant_idx');
                $table->char('clearance_id', 64);
                $table->string('finding_id', 180)->index('ts_acl_finding_idx');
                $table->string('reinspection_id', 64)->index('ts_acl_rein_idx');
                $table->string('reinspection_run_id', 64)->index('ts_acl_run_idx');
                $table->string('decision', 16)->index('ts_acl_decision_idx');
                $table->boolean('may_close')->default(false);
                $table->decimal('score', 6, 2)->nullable();
                $table->string('policy_version', 120)->nullable();
                $table->char('evidence_fingerprint', 64);
                $table->json('reason_codes');
                $table->json('raw_summary')->nullable();
                $table->timestampTz('assessed_at');
                $table->uuid('trace_id')->index('ts_acl_trace_idx');
                $table->uuid('correlation_id')->index('ts_acl_corr_idx');
                $table->uuid('causation_id')->index('ts_acl_cause_idx');
                $table->uuid('root_causation_id')->index('ts_acl_root_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_acl_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_acl_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'clearance_id'], 'ts_acl_tenant_id_uq');
                $table->unique(['company_id', 'reinspection_id'], 'ts_acl_tenant_rein_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_shield_assurance_clearances');
    }
};
