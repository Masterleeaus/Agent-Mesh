<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_knowledge_bindings')) {
            Schema::create('titan_shield_knowledge_bindings', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_kb_tenant_idx');
                $table->char('binding_id', 64);
                $table->string('run_id', 180)->index('ts_kb_run_idx');
                $table->string('definition_key', 120)->index('ts_kb_def_idx');
                $table->string('definition_version', 80);
                $table->char('definition_hash', 64);
                $table->string('vertical_key', 120)->index('ts_kb_vert_idx');
                $table->string('jurisdiction', 40)->index('ts_kb_juris_idx');
                $table->string('knowledge_key', 180)->index('ts_kb_key_idx');
                $table->string('authority_domain', 80)->index('ts_kb_auth_idx');
                $table->string('status', 24)->index('ts_kb_status_idx');
                $table->string('binding_mode', 16)->index('ts_kb_mode_idx');
                $table->boolean('blocking')->default(false);
                $table->string('resolved_version', 180)->nullable();
                $table->char('resolved_hash', 64)->nullable();
                $table->json('reason_codes');
                $table->uuid('trace_id')->index('ts_kb_trace_idx');
                $table->uuid('correlation_id')->index('ts_kb_corr_idx');
                $table->uuid('causation_id')->index('ts_kb_cause_idx');
                $table->uuid('root_causation_id')->index('ts_kb_root_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_kb_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_kb_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'binding_id'], 'ts_kb_tenant_id_uq');
                $table->index(['company_id', 'definition_key', 'knowledge_key'], 'ts_kb_def_key_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_shield_knowledge_bindings');
    }
};
