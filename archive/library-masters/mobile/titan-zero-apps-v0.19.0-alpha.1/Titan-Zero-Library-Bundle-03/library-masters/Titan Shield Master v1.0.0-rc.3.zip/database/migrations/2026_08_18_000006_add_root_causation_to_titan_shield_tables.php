<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** @var array<string,string> */
    private array $tables = [
        'titan_shield_records' => 'ts_records_root_caus_idx',
        'titan_shield_inspections' => 'ts_inspections_root_caus_idx',
        'titan_shield_evidence' => 'ts_evidence_root_caus_idx',
        'titan_shield_findings' => 'ts_findings_root_caus_idx',
        'titan_shield_inspection_runs' => 'ts_runs_root_caus_idx',
        'titan_shield_inspection_item_results' => 'ts_item_results_root_caus_idx',
        'titan_shield_human_reviews' => 'ts_reviews_root_caus_idx',
        'titan_shield_remediation_intents' => 'ts_remediation_root_caus_idx',
        'titan_shield_integration_receipts' => 'ts_receipts_root_caus_idx',
    ];

    public function up(): void
    {
        foreach ($this->tables as $tableName => $indexName) {
            if (! Schema::hasTable($tableName) || Schema::hasColumn($tableName, 'root_causation_id')) {
                continue;
            }

            Schema::table($tableName, static function (Blueprint $table) use ($indexName): void {
                $table->uuid('root_causation_id')->nullable()->index($indexName);
            });
        }
    }

    public function down(): void
    {
        foreach ($this->tables as $tableName => $indexName) {
            if (! Schema::hasTable($tableName) || ! Schema::hasColumn($tableName, 'root_causation_id')) {
                continue;
            }

            Schema::table($tableName, static function (Blueprint $table) use ($indexName): void {
                $table->dropIndex($indexName);
                $table->dropColumn('root_causation_id');
            });
        }
    }
};
