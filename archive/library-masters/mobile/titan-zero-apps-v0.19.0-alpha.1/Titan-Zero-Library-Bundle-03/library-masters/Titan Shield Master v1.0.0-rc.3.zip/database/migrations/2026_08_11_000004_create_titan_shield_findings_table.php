<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_shield_findings')) {
            return;
        }

        Schema::create('titan_shield_findings', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('company_id')->index('ts_find_tenant_idx');
            $table->string('finding_id', 180);
            $table->unsignedBigInteger('inspection_id')->nullable()->index('ts_find_inspection_idx');
            $table->string('definition_key', 120)->index('ts_find_def_key_idx');
            $table->string('definition_version', 60);
            $table->char('definition_hash', 64);
            $table->string('code', 120)->index('ts_find_code_idx');
            $table->string('severity', 20)->index('ts_find_severity_idx');
            $table->string('outcome', 30)->index('ts_find_outcome_idx');
            $table->string('status', 30)->default('open')->index('ts_find_status_idx');
            $table->string('subject_type', 80)->index('ts_find_subject_type_idx');
            $table->string('subject_id', 180)->index('ts_find_subject_id_idx');
            $table->json('evidence_ids')->nullable();
            $table->json('reason_codes');
            $table->json('governance_response')->nullable();
            $table->uuid('trace_id')->index('ts_find_trace_idx');
            $table->uuid('correlation_id')->index('ts_find_corr_idx');
            $table->uuid('causation_id')->index('ts_find_cause_idx');
            $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_find_actor_idx');
            $table->string('source', 80)->default('system')->index('ts_find_source_idx');
            $table->timestamps();
            $table->unique(['company_id', 'finding_id'], 'ts_find_tenant_finding_uq');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_shield_findings');
    }
};
