<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_inspection_definitions')) {
            Schema::create('titan_shield_inspection_definitions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->nullable()->index('ts_def_tenant_idx');
                $table->string('scope_key', 120)->index('ts_def_scope_idx');
                $table->string('definition_key', 120);
                $table->string('version', 60);
                $table->char('definition_hash', 64);
                $table->string('name', 180);
                $table->string('vertical_key', 120)->index('ts_def_vertical_idx');
                $table->string('inspection_type', 80)->index('ts_def_type_idx');
                $table->string('scope', 20)->index('ts_def_scope_type_idx');
                $table->string('status', 20)->default('draft')->index('ts_def_status_idx');
                $table->json('definition_json');
                $table->string('source_pack', 180)->index('ts_def_pack_idx');
                $table->timestampTz('effective_from');
                $table->string('supersedes_version', 60)->nullable();
                $table->uuid('trace_id')->index('ts_def_trace_idx');
                $table->uuid('correlation_id')->index('ts_def_corr_idx');
                $table->uuid('causation_id')->index('ts_def_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_def_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_def_source_idx');
                $table->timestamps();
                $table->unique(['scope_key', 'definition_key', 'version'], 'ts_def_scope_key_ver_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_evidence')) {
            Schema::create('titan_shield_evidence', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_ev_tenant_idx');
                $table->string('evidence_id', 180);
                $table->string('evidence_key', 120)->index('ts_ev_key_idx');
                $table->unsignedBigInteger('inspection_id')->nullable()->index('ts_ev_inspection_idx');
                $table->string('subject_type', 80)->nullable()->index('ts_ev_subject_type_idx');
                $table->string('subject_id', 180)->nullable()->index('ts_ev_subject_id_idx');
                $table->string('original_filename', 255);
                $table->string('mime_type', 120)->index('ts_ev_mime_idx');
                $table->unsignedBigInteger('size_bytes');
                $table->char('sha256', 64)->index('ts_ev_sha_idx');
                $table->timestampTz('captured_at')->index('ts_ev_captured_idx');
                $table->string('capture_device_id', 180)->nullable();
                $table->string('storage_reference', 500);
                $table->json('metadata')->nullable();
                $table->uuid('trace_id')->index('ts_ev_trace_idx');
                $table->uuid('correlation_id')->index('ts_ev_corr_idx');
                $table->uuid('causation_id')->index('ts_ev_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_ev_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_ev_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'evidence_id'], 'ts_ev_tenant_evidence_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_shield_evidence');
        Schema::dropIfExists('titan_shield_inspection_definitions');
    }
};
