<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_inspection_runs')) {
            Schema::create('titan_shield_inspection_runs', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_run_tenant_idx');
                $table->string('run_id', 64);
                $table->string('definition_key', 120)->index('ts_run_def_key_idx');
                $table->string('definition_version', 60);
                $table->char('definition_hash', 64);
                $table->string('subject_type', 80)->index('ts_run_subject_type_idx');
                $table->string('subject_id', 180)->index('ts_run_subject_id_idx');
                $table->string('status', 30)->index('ts_run_status_idx');
                $table->string('outcome', 30)->index('ts_run_outcome_idx');
                $table->timestampTz('started_at');
                $table->timestampTz('completed_at');
                $table->uuid('trace_id')->index('ts_run_trace_idx');
                $table->uuid('correlation_id')->index('ts_run_corr_idx');
                $table->uuid('causation_id')->index('ts_run_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_run_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_run_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'run_id'], 'ts_run_tenant_run_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_inspection_item_results')) {
            Schema::create('titan_shield_inspection_item_results', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_item_tenant_idx');
                $table->string('run_id', 64)->index('ts_item_run_idx');
                $table->string('rule_key', 120)->index('ts_item_rule_idx');
                $table->string('rule_type', 80);
                $table->string('status', 20)->index('ts_item_status_idx');
                $table->string('failure_severity', 20)->index('ts_item_sev_idx');
                $table->json('evidence_ids')->nullable();
                $table->json('reason_codes');
                $table->json('details')->nullable();
                $table->uuid('trace_id')->index('ts_item_trace_idx');
                $table->uuid('correlation_id')->index('ts_item_corr_idx');
                $table->uuid('causation_id')->index('ts_item_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_item_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_item_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'run_id', 'rule_key'], 'ts_item_run_rule_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_human_reviews')) {
            Schema::create('titan_shield_human_reviews', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_review_tenant_idx');
                $table->string('review_id', 64);
                $table->string('finding_id', 180)->index('ts_review_finding_idx');
                $table->string('finding_severity', 20)->index('ts_review_sev_idx');
                $table->json('finding_snapshot');
                $table->string('reviewer_role', 80)->index('ts_review_role_idx');
                $table->timestampTz('due_at')->nullable();
                $table->string('decision', 40)->index('ts_review_decision_idx');
                $table->unsignedBigInteger('reviewed_by')->nullable()->index('ts_review_by_idx');
                $table->string('reason_code', 160)->nullable();
                $table->timestampTz('reviewed_at')->nullable();
                $table->boolean('may_proceed')->default(false);
                $table->boolean('requires_assurance')->default(false);
                $table->uuid('trace_id')->index('ts_review_trace_idx');
                $table->uuid('correlation_id')->index('ts_review_corr_idx');
                $table->uuid('causation_id')->index('ts_review_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_review_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_review_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'review_id'], 'ts_review_tenant_review_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_remediation_intents')) {
            Schema::create('titan_shield_remediation_intents', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_rem_tenant_idx');
                $table->string('intent_id', 64);
                $table->string('finding_id', 180)->index('ts_rem_finding_idx');
                $table->string('subject_type', 80)->index('ts_rem_subject_type_idx');
                $table->string('subject_id', 180)->index('ts_rem_subject_id_idx');
                $table->string('remediation_type', 120)->index('ts_rem_type_idx');
                $table->string('requested_capability', 180)->nullable()->index('ts_rem_cap_idx');
                $table->json('payload')->nullable();
                $table->char('idempotency_key', 64);
                $table->string('status', 30)->default('PREPARED')->index('ts_rem_status_idx');
                $table->boolean('direct_mutation')->default(false);
                $table->uuid('trace_id')->index('ts_rem_trace_idx');
                $table->uuid('correlation_id')->index('ts_rem_corr_idx');
                $table->uuid('causation_id')->index('ts_rem_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_rem_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_rem_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'intent_id'], 'ts_rem_tenant_intent_uq');
                $table->unique(['company_id', 'idempotency_key'], 'ts_rem_tenant_idem_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_integration_receipts')) {
            Schema::create('titan_shield_integration_receipts', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_int_tenant_idx');
                $table->string('receipt_id', 96);
                $table->string('target', 80)->index('ts_int_target_idx');
                $table->string('event_type', 160)->index('ts_int_event_idx');
                $table->string('status', 30)->index('ts_int_status_idx');
                $table->char('idempotency_key', 64)->nullable();
                $table->char('payload_hash', 64);
                $table->json('payload');
                $table->json('response')->nullable();
                $table->uuid('trace_id')->index('ts_int_trace_idx');
                $table->uuid('correlation_id')->index('ts_int_corr_idx');
                $table->uuid('causation_id')->index('ts_int_cause_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_int_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_int_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'receipt_id'], 'ts_int_tenant_receipt_uq');
                $table->unique(['company_id', 'idempotency_key'], 'ts_int_tenant_idem_uq');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_shield_integration_receipts');
        Schema::dropIfExists('titan_shield_remediation_intents');
        Schema::dropIfExists('titan_shield_human_reviews');
        Schema::dropIfExists('titan_shield_inspection_item_results');
        Schema::dropIfExists('titan_shield_inspection_runs');
    }
};
