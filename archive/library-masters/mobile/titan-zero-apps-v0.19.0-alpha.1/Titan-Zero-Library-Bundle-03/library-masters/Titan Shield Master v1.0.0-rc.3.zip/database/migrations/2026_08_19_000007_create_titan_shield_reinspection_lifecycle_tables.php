<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('titan_shield_reinspections')) {
            Schema::create('titan_shield_reinspections', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_rein_tenant_idx');
                $table->string('reinspection_id', 64);
                $table->string('finding_id', 180)->index('ts_rein_finding_idx');
                $table->string('original_run_id', 64)->index('ts_rein_orig_run_idx');
                $table->string('reinspection_run_id', 64)->index('ts_rein_run_idx');
                $table->string('definition_key', 120)->index('ts_rein_def_idx');
                $table->string('definition_version', 60);
                $table->char('definition_hash', 64);
                $table->string('subject_type', 80)->index('ts_rein_sub_type_idx');
                $table->string('subject_id', 180)->index('ts_rein_sub_id_idx');
                $table->string('outcome', 30)->index('ts_rein_outcome_idx');
                $table->string('closure_status', 40)->index('ts_rein_close_idx');
                $table->boolean('may_close')->default(false);
                $table->boolean('requires_assurance')->default(false);
                $table->boolean('requires_human_review')->default(false);
                $table->json('reason_codes');
                $table->timestampTz('completed_at');
                $table->uuid('trace_id')->index('ts_rein_trace_idx');
                $table->uuid('correlation_id')->index('ts_rein_corr_idx');
                $table->uuid('causation_id')->index('ts_rein_cause_idx');
                $table->uuid('root_causation_id')->index('ts_rein_root_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_rein_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_rein_source_idx');
                $table->timestamps();
                $table->unique(['company_id', 'reinspection_id'], 'ts_rein_tenant_id_uq');
                $table->unique(['company_id', 'reinspection_run_id'], 'ts_rein_tenant_run_uq');
            });
        }

        if (! Schema::hasTable('titan_shield_finding_transitions')) {
            Schema::create('titan_shield_finding_transitions', function (Blueprint $table): void {
                $table->id();
                $table->unsignedBigInteger('company_id')->index('ts_ftr_tenant_idx');
                $table->char('transition_id', 64);
                $table->string('finding_id', 180)->index('ts_ftr_finding_idx');
                $table->string('from_status', 40)->nullable()->index('ts_ftr_from_idx');
                $table->string('to_status', 40)->index('ts_ftr_to_idx');
                $table->json('reason_codes');
                $table->string('reinspection_id', 64)->nullable()->index('ts_ftr_rein_idx');
                $table->string('reinspection_run_id', 64)->nullable()->index('ts_ftr_run_idx');
                $table->uuid('trace_id')->index('ts_ftr_trace_idx');
                $table->uuid('correlation_id')->index('ts_ftr_corr_idx');
                $table->uuid('causation_id')->index('ts_ftr_cause_idx');
                $table->uuid('root_causation_id')->index('ts_ftr_root_idx');
                $table->unsignedBigInteger('actor_user_id')->nullable()->index('ts_ftr_actor_idx');
                $table->string('source', 80)->default('system')->index('ts_ftr_source_idx');
                $table->timestampTz('occurred_at');
                $table->unique(['company_id', 'transition_id'], 'ts_ftr_tenant_id_uq');
            });
        }

        if (Schema::hasTable('titan_shield_findings')) {
            Schema::table('titan_shield_findings', function (Blueprint $table): void {
                if (! Schema::hasColumn('titan_shield_findings', 'closed_at')) {
                    $table->timestampTz('closed_at')->nullable()->after('status');
                }
                if (! Schema::hasColumn('titan_shield_findings', 'closure_reinspection_id')) {
                    $table->string('closure_reinspection_id', 64)->nullable()->after('closed_at');
                }
                if (! Schema::hasColumn('titan_shield_findings', 'closure_run_id')) {
                    $table->string('closure_run_id', 64)->nullable()->after('closure_reinspection_id');
                }
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('titan_shield_findings')) {
            Schema::table('titan_shield_findings', function (Blueprint $table): void {
                $columns = [];
                foreach (['closed_at', 'closure_reinspection_id', 'closure_run_id'] as $column) {
                    if (Schema::hasColumn('titan_shield_findings', $column)) {
                        $columns[] = $column;
                    }
                }
                if ($columns !== []) {
                    $table->dropColumn($columns);
                }
            });
        }

        Schema::dropIfExists('titan_shield_finding_transitions');
        Schema::dropIfExists('titan_shield_reinspections');
    }
};
