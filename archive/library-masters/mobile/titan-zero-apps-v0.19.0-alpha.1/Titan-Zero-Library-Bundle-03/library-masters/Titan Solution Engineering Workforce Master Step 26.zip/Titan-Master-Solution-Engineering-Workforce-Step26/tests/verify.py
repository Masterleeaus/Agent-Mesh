from pathlib import Path
import json,zipfile
r=Path(__file__).resolve().parents[1]
cat=json.loads((r/'catalogue/master-solution-engineering-workforce.json').read_text())
assert cat['company_boundary']=='company_id'
assert cat['source_role_catalogue_count']>=115
assert cat['recovered_historical_profiles']>=20
assert cat['gap_fill_composite_profiles']>=10
ids=[p['profile_id'] for p in cat['profiles']]
assert len(ids)==len(set(ids))
disc=set(d for p in cat['profiles'] for d in p['disciplines'])
for req in ['target_workflow','software_architecture','integration_planning','knowledge_model','permissions_governance','automation_boundary','human_approvals','ui_requirements','workforce_composition']:
    assert req in disc,req
for p in cat['profiles']:
    assert p['execution_authority'] is False
    assert p['company_boundary']=='company_id'
for s in (r/'contracts').glob('*.json'): json.loads(s.read_text())
parents=list((r/'source-lineage').glob('*.zip'))
assert len(parents)==2
for z in parents:
    with zipfile.ZipFile(z) as q: assert q.testzip() is None
runtime=''.join(p.read_text() for p in (r/'runtime').glob('*.php'))
assert 'company_id-required' in runtime
assert 'legacy-tenant-boundary-forbidden' in runtime
assert 'solution-blueprint-cannot-carry-execution-authority' in runtime
print('PASS engineering workforce catalogue')
print('PASS all required engineering disciplines')
print('PASS solution contracts')
print('PASS execution authority separation')
print('PASS company_id-only boundary')
print('PASS exact Step24/25 parent lineage')
