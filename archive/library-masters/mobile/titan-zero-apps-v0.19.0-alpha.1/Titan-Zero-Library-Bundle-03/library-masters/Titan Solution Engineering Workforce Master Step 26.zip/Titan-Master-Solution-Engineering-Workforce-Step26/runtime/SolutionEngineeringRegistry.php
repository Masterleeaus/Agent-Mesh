<?php
namespace Titan\SolutionEngineering;

final class SolutionEngineeringRegistry
{
    public function __construct(private readonly array $catalogue) {}

    public static function fromFile(string $path): self
    {
        return new self(json_decode(file_get_contents($path), true, flags: JSON_THROW_ON_ERROR));
    }

    public function all(): array
    {
        return $this->catalogue['profiles'];
    }

    public function forDiscipline(string $discipline): array
    {
        return array_values(array_filter(
            $this->all(),
            fn(array $p) => in_array($discipline, $p['disciplines'], true)
        ));
    }

    public function assertCompanyContext(array $context): string
    {
        $companyId = trim((string)($context['company_id'] ?? ''));
        if ($companyId === '') throw new \InvalidArgumentException('company_id-required');

        foreach (['tenant_id','tenant_company_id','organisation_id','organization_id','account_id','business_id'] as $legacy) {
            if (array_key_exists($legacy, $context)) {
                throw new \InvalidArgumentException('legacy-tenant-boundary-forbidden');
            }
        }
        return $companyId;
    }
}
