<?php
namespace Titan\SolutionEngineering;

final class SolutionBlueprintValidator
{
    public function validate(array $blueprint): array
    {
        $errors = [];

        if (trim((string)($blueprint['company_id'] ?? '')) === '') {
            $errors[] = 'company_id-required';
        }

        if (empty($blueprint['source_finding_refs'])) {
            $errors[] = 'source-findings-required';
        }

        if (($blueprint['execution_authority'] ?? false) !== false) {
            $errors[] = 'solution-blueprint-cannot-carry-execution-authority';
        }

        foreach (['tenant_id','tenant_company_id','organisation_id','organization_id'] as $legacy) {
            if (array_key_exists($legacy, $blueprint)) {
                $errors[] = 'legacy-tenant-boundary-forbidden';
            }
        }

        $required = [
            'target_operating_model','workflow_refs','architecture_ref','integration_refs',
            'knowledge_model_ref','permission_model_ref','approval_model_ref',
            'ui_requirement_refs','workforce_composition_ref','migration_plan_ref'
        ];
        foreach ($required as $field) {
            if (!array_key_exists($field, $blueprint)) $errors[] = "missing:$field";
        }

        return ['valid' => $errors === [], 'errors' => $errors];
    }
}
