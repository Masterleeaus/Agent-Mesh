<?php
spl_autoload_register(function($class){
    $prefix='Titan\\SolutionEngineering\\';
    if(!str_starts_with($class,$prefix)) return;
    $file=dirname(__DIR__).'/runtime/'.substr($class,strlen($prefix)).'.php';
    if(is_file($file)) require $file;
});

use Titan\SolutionEngineering\SolutionEngineeringRegistry;
use Titan\SolutionEngineering\SolutionBlueprintValidator;
use Titan\SolutionEngineering\AutomationBoundaryResolver;

$registry=SolutionEngineeringRegistry::fromFile(dirname(__DIR__).'/catalogue/master-solution-engineering-workforce.json');
if(count($registry->forDiscipline('software_architecture'))<2) throw new RuntimeException('architecture crew too small');
if($registry->assertCompanyContext(['company_id'=>'company_1'])!=='company_1') throw new RuntimeException('company context');

try{
    $registry->assertCompanyContext(['company_id'=>'company_1','tenant_id'=>'legacy']);
    throw new RuntimeException('legacy accepted');
}catch(InvalidArgumentException $e){
    if($e->getMessage()!=='legacy-tenant-boundary-forbidden') throw $e;
}

$v=(new SolutionBlueprintValidator())->validate([
    'company_id'=>'company_1',
    'source_finding_refs'=>['finding_1'],
    'target_operating_model'=>[],
    'workflow_refs'=>[],
    'architecture_ref'=>'arch_1',
    'integration_refs'=>[],
    'knowledge_model_ref'=>'knowledge_1',
    'permission_model_ref'=>'permissions_1',
    'approval_model_ref'=>'approvals_1',
    'ui_requirement_refs'=>[],
    'workforce_composition_ref'=>'workforce_1',
    'migration_plan_ref'=>'migration_1',
    'execution_authority'=>false
]);
if(!$v['valid']) throw new RuntimeException('valid blueprint rejected');

$v2=(new SolutionBlueprintValidator())->validate([
    'company_id'=>'company_1',
    'source_finding_refs'=>['finding_1'],
    'execution_authority'=>true
]);
if($v2['valid'] || !in_array('solution-blueprint-cannot-carry-execution-authority',$v2['errors'],true)) throw new RuntimeException('authority leak');

$resolver=new AutomationBoundaryResolver();
if($resolver->cap('autonomous','high',true,true)!=='approval_gated') throw new RuntimeException('high risk cap');
if($resolver->cap('proactive','low',false,true)!=='assist') throw new RuntimeException('evidence cap');

echo "PASS registry discipline resolution\n";
echo "PASS company boundary rejection\n";
echo "PASS solution blueprint validation\n";
echo "PASS execution authority rejection\n";
echo "PASS automation boundary caps\n";
