<?php
namespace Titan\SolutionEngineering;

final class AutomationBoundaryResolver
{
    private const ORDER = ['observe'=>0,'assist'=>1,'proactive'=>2,'approval_gated'=>3,'autonomous'=>4];

    public function cap(string $desiredMode, string $riskClass, bool $evidenceReady, bool $governanceReady): string
    {
        if (!isset(self::ORDER[$desiredMode])) throw new \InvalidArgumentException('invalid-automation-mode');

        if (!$evidenceReady || !$governanceReady) {
            return self::ORDER[$desiredMode] > self::ORDER['assist'] ? 'assist' : $desiredMode;
        }

        if (in_array(strtolower($riskClass), ['high','critical'], true) && self::ORDER[$desiredMode] > self::ORDER['approval_gated']) {
            return 'approval_gated';
        }

        return $desiredMode;
    }
}
