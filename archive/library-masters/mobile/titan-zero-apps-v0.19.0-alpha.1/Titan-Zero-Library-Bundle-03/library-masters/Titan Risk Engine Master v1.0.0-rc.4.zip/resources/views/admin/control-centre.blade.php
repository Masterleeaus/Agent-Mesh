@extends('panel.layout.app')

@section('title', 'Titan Risk Control Centre')

@section('content')
@php
    $fmt = static fn($v, $d = 1) => number_format((float)($v ?? 0), $d);
    $rowLimit = 12;
@endphp
<style>
    .tre-shell{max-width:1500px;margin:0 auto;padding:24px 16px 48px}.tre-hero{display:flex;gap:16px;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;margin-bottom:20px}.tre-title{margin:0;font-size:28px;font-weight:750}.tre-sub{opacity:.72;margin-top:6px;max-width:860px}.tre-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}.tre-card{border:1px solid rgba(127,127,127,.18);border-radius:14px;background:var(--bs-body-bg,#fff);box-shadow:0 8px 24px rgba(0,0,0,.04)}.tre-card-body{padding:18px}.tre-kicker{font-size:12px;text-transform:uppercase;letter-spacing:.08em;opacity:.62}.tre-value{font-size:28px;font-weight:760;margin-top:6px}.tre-meta{font-size:12px;opacity:.66;margin-top:4px}.tre-section{margin-top:18px}.tre-section h2{font-size:18px;margin:0 0 12px}.tre-two{display:grid;grid-template-columns:1fr 1fr;gap:16px}.tre-three{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.tre-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.tre-form-grid .wide{grid-column:1/-1}.tre-table-wrap{overflow:auto}.tre-table{width:100%;border-collapse:collapse;font-size:13px}.tre-table th,.tre-table td{padding:9px 10px;border-bottom:1px solid rgba(127,127,127,.15);text-align:left;white-space:nowrap}.tre-table th{font-size:11px;text-transform:uppercase;letter-spacing:.06em;opacity:.7}.tre-pill{display:inline-flex;padding:3px 8px;border-radius:999px;font-size:11px;font-weight:700;background:rgba(127,127,127,.14)}.tre-danger{background:rgba(220,53,69,.15);color:#b02a37}.tre-warn{background:rgba(255,193,7,.18);color:#946200}.tre-ok{background:rgba(25,135,84,.14);color:#146c43}.tre-note{padding:12px 14px;border-left:3px solid var(--bs-primary,#6f42c1);background:rgba(127,127,127,.07);border-radius:8px;font-size:13px}.tre-filter{display:flex;gap:8px;align-items:end;flex-wrap:wrap}.tre-filter>div{min-width:180px}.tre-divider{height:1px;background:rgba(127,127,127,.14);margin:14px 0}.tre-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;word-break:break-all;white-space:normal}@media(max-width:1100px){.tre-grid{grid-template-columns:repeat(2,1fr)}.tre-three{grid-template-columns:1fr}.tre-two{grid-template-columns:1fr}}@media(max-width:640px){.tre-grid{grid-template-columns:1fr}.tre-form-grid{grid-template-columns:1fr}.tre-form-grid .wide{grid-column:auto}}
</style>

<div class="tre-shell">
    <div class="tre-hero">
        <div>
            <h1 class="tre-title">Titan Risk Control Centre</h1>
            <div class="tre-sub">Operational risk exposure, governed budgets, effective policy, circuit state, Signal delivery and enforcement evidence. Policy changes are immutable and prospective.</div>
        </div>
        @if($snapshot)
            <span class="tre-pill">Tenant {{ $snapshot->companyId }} · {{ $snapshot->generatedAt->format('Y-m-d H:i:s') }} UTC</span>
        @endif
    </div>

    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if(session('error'))<div class="alert alert-danger">{{ session('error') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger"><strong>Validation failed.</strong><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif

    <div class="tre-card">
        <div class="tre-card-body">
            <form method="GET" action="{{ route('dashboard.admin.titan.risk.engine.control-centre') }}" class="tre-filter">
                <div><label class="form-label">Tenant company ID</label><input class="form-control" type="number" min="1" name="company_id" value="{{ $companyId }}" required></div>
                <div><label class="form-label">Capability filter</label><input class="form-control" name="capability" maxlength="160" value="{{ $capability }}" placeholder="e.g. invoice.send"></div>
                <button class="btn btn-primary" type="submit">Load Risk state</button>
            </form>
        </div>
    </div>

    @if(!$snapshot)
        <div class="tre-note tre-section">Enter a tenant company ID to load the governed Risk state. No cross-tenant data is shown without an explicit admin tenant selection.</div>
    @else
        @php
            $exp = $snapshot->exposure;
            $vel = $snapshot->velocity;
            $budget = $snapshot->budget;
            $policy = $snapshot->effectivePolicy;
            $maxDaily = (float)($policy['max_daily_risk_exposure'] ?? $budget['max_daily_risk_exposure'] ?? 0);
            $util = $maxDaily > 0 ? min(999, ((float)($exp['score_sum'] ?? 0) / $maxDaily) * 100) : 0;
        @endphp

        <div class="tre-grid">
            <div class="tre-card"><div class="tre-card-body"><div class="tre-kicker">24h Exposure</div><div class="tre-value">{{ $fmt($exp['score_sum'] ?? 0, 1) }}</div><div class="tre-meta">{{ $exp['assessment_count'] ?? 0 }} assessments · {{ $exp['high_or_extreme_count'] ?? 0 }} HIGH/EXTREME</div></div></div>
            <div class="tre-card"><div class="tre-card-body"><div class="tre-kicker">Risk Budget</div><div class="tre-value">{{ $fmt($util, 1) }}%</div><div class="tre-meta">{{ $fmt($maxDaily, 0) }} daily exposure · {{ $budget['version'] ?? 'default-v1' }}</div></div></div>
            <div class="tre-card"><div class="tre-card-body"><div class="tre-kicker">Circuits</div><div class="tre-value">{{ $snapshot->circuitSummary['open'] ?? 0 }} open</div><div class="tre-meta">{{ $snapshot->circuitSummary['half_open'] ?? 0 }} half-open · {{ $snapshot->circuitSummary['closed'] ?? 0 }} closed</div></div></div>
            <div class="tre-card"><div class="tre-card-body"><div class="tre-kicker">Signal Delivery</div><div class="tre-value">{{ $snapshot->signalSummary['pending'] ?? 0 }} pending</div><div class="tre-meta">{{ $snapshot->signalSummary['failed'] ?? 0 }} failed · {{ $snapshot->signalSummary['published_24h'] ?? 0 }} published 24h</div></div></div>
        </div>

        <div class="tre-two tre-section">
            <div class="tre-card"><div class="tre-card-body">
                <h2>Current intelligence</h2>
                <div class="tre-table-wrap"><table class="tre-table"><tbody>
                    <tr><th>Scope</th><td>{{ $exp['scope'] ?? 'TENANT' }}</td></tr>
                    <tr><th>Capability</th><td>{{ $snapshot->capability ?? 'All capabilities' }}</td></tr>
                    <tr><th>Average score</th><td>{{ $fmt($exp['score_average'] ?? 0, 1) }}</td></tr>
                    <tr><th>Maximum score</th><td>{{ $fmt($exp['score_maximum'] ?? 0, 1) }}</td></tr>
                    <tr><th>Blocked</th><td>{{ $exp['blocked_count'] ?? 0 }}</td></tr>
                    <tr><th>15m velocity</th><td><span class="tre-pill {{ in_array(($vel['level'] ?? ''), ['HIGH','CRITICAL'], true) ? 'tre-danger' : (($vel['level'] ?? '') === 'ELEVATED' ? 'tre-warn' : 'tre-ok') }}">{{ $vel['level'] ?? 'NORMAL' }}</span></td></tr>
                    <tr><th>Actions/min</th><td>{{ $fmt($vel['actions_per_minute'] ?? 0, 2) }}</td></tr>
                    <tr><th>Score points/min</th><td>{{ $fmt($vel['score_points_per_minute'] ?? 0, 2) }}</td></tr>
                </tbody></table></div>
            </div></div>
            <div class="tre-card"><div class="tre-card-body">
                <h2>Effective policy</h2>
                @if($policy)
                    <div class="tre-table-wrap"><table class="tre-table"><tbody>
                        <tr><th>Capability</th><td>{{ $policy['capability'] }}</td></tr>
                        <tr><th>Daily exposure ceiling</th><td>{{ $fmt($policy['max_daily_risk_exposure'], 0) }}</td></tr>
                        <tr><th>Autonomous action ceiling</th><td>{{ $policy['max_autonomous_single_action_level'] }}</td></tr>
                        <tr><th>Monitoring threshold</th><td>{{ $fmt(((float)$policy['monitoring_threshold_ratio']) * 100, 1) }}%</td></tr>
                        <tr><th>Hard block level</th><td>{{ $policy['hard_block_level'] }}</td></tr>
                        <tr><th>Applied versions</th><td>{{ implode(', ', $policy['applied_versions'] ?? []) }}</td></tr>
                        <tr><th>Digest</th><td class="tre-code">{{ $policy['content_digest'] }}</td></tr>
                    </tbody></table></div>
                @else
                    <div class="tre-note">Select a capability to resolve and display its exact effective policy lineage.</div>
                @endif
            </div></div>
        </div>

        <div class="tre-section tre-card"><div class="tre-card-body">
            <h2>Recent assessments</h2>
            <div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>When UTC</th><th>Capability</th><th>Action</th><th>Score</th><th>Level</th><th>Decision</th><th>Connectivity</th><th>Actor</th></tr></thead><tbody>
            @forelse(array_slice($snapshot->recentAssessments,0,$rowLimit) as $row)
                <tr><td>{{ $row['assessed_at'] ?? '—' }}</td><td>{{ $row['capability'] ?? '—' }}</td><td>{{ $row['action'] ?? '—' }}</td><td>{{ $row['score'] ?? '—' }}</td><td><span class="tre-pill">{{ $row['level'] ?? '—' }}</span></td><td>{{ $row['decision'] ?? '—' }}</td><td>{{ $row['connectivity'] ?? '—' }}</td><td>{{ ($row['actor_type'] ?? '—').' '.($row['actor_id'] ?? '') }}</td></tr>
            @empty<tr><td colspan="8">No persisted assessments for this selection.</td></tr>@endforelse
            </tbody></table></div>
        </div></div>

        <div class="tre-two tre-section">
            <div class="tre-card"><div class="tre-card-body"><h2>Circuits</h2><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>Scope</th><th>Capability</th><th>State</th><th>Version</th><th>Last transition</th></tr></thead><tbody>
                @forelse(array_slice($snapshot->recentCircuits,0,$rowLimit) as $row)<tr><td>{{ $row['scope'] }}</td><td>{{ $row['capability'] ?? 'tenant-wide' }}</td><td><span class="tre-pill {{ ($row['state'] ?? '') === 'OPEN' ? 'tre-danger' : (($row['state'] ?? '') === 'HALF_OPEN' ? 'tre-warn' : 'tre-ok') }}">{{ $row['state'] }}</span></td><td>{{ $row['version'] }}</td><td>{{ $row['last_transition_at'] }}</td></tr>@empty<tr><td colspan="5">No circuit state recorded.</td></tr>@endforelse
            </tbody></table></div></div></div>
            <div class="tre-card"><div class="tre-card-body"><h2>Enforcement Receipts</h2><div class="tre-meta mb-2">{{ $snapshot->receiptSummary['issued_24h'] ?? 0 }} issued · {{ $snapshot->receiptSummary['held_or_denied_24h'] ?? 0 }} held/denied in 24h</div><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>When UTC</th><th>Capability</th><th>Directive</th><th>Risk</th><th>Dispatch</th></tr></thead><tbody>
                @forelse(array_slice($snapshot->recentReceipts,0,$rowLimit) as $row)<tr><td>{{ $row['issued_at'] }}</td><td>{{ $row['capability'] }}</td><td>{{ $row['execution_directive'] }}</td><td>{{ $row['risk_level'] }} / {{ $row['risk_score'] }}</td><td>{{ $row['may_dispatch'] ? 'YES' : 'NO' }}</td></tr>@empty<tr><td colspan="5">No enforcement receipts recorded.</td></tr>@endforelse
            </tbody></table></div></div></div>
        </div>

        <div class="tre-two tre-section">
            <div class="tre-card"><div class="tre-card-body"><h2>Signal outbox</h2><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>When UTC</th><th>Type</th><th>Severity</th><th>Attempts</th><th>Status</th></tr></thead><tbody>
                @forelse(array_slice($snapshot->recentSignals,0,$rowLimit) as $row)<tr><td>{{ $row['occurred_at'] }}</td><td>{{ $row['event_type'] }}</td><td>{{ $row['severity'] }}</td><td>{{ $row['attempts'] }}</td><td>{{ $row['published_at'] ? 'Published' : (($row['last_error'] ?? null) ? 'Failed / pending' : 'Pending') }}</td></tr>@empty<tr><td colspan="5">No Signal outbox events recorded.</td></tr>@endforelse
            </tbody></table></div><div class="tre-divider"></div>
                <form method="POST" action="{{ route('dashboard.admin.titan.risk.engine.signals.dispatch') }}">@csrf<input type="hidden" name="company_id" value="{{ $snapshot->companyId }}"><input type="hidden" name="limit" value="100"><button class="btn btn-outline-primary btn-sm" type="submit">Retry pending Signal delivery</button></form>
            </div></div>
            <div class="tre-card"><div class="tre-card-body"><h2>Policy change history</h2><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>When UTC</th><th>Action</th><th>Policy</th><th>Version</th><th>Actor</th></tr></thead><tbody>
                @forelse(array_slice($snapshot->policyChanges,0,$rowLimit) as $row)<tr><td>{{ $row['changed_at'] }}</td><td>{{ $row['action'] }}</td><td>{{ $row['policy_key'] }}</td><td>{{ $row['version'] }}</td><td>{{ ($row['actor_type'] ?? '—').' '.($row['actor_id'] ?? '') }}</td></tr>@empty<tr><td colspan="5">No policy changes recorded.</td></tr>@endforelse
            </tbody></table></div></div></div>
        </div>

        <div class="tre-section"><h2>Policy Operations</h2><div class="tre-note mb-3"><strong>Governance invariant:</strong> these controls create new immutable versions only. They cannot edit historical versions, lower the engine's hard safety floor, or override an OPEN circuit.</div></div>
        <div class="tre-two">
            <div class="tre-card"><div class="tre-card-body"><h2>Schedule Risk Budget</h2>
                <form method="POST" action="{{ route('dashboard.admin.titan.risk.engine.policy.budget.schedule') }}">@csrf
                    <input type="hidden" name="company_id" value="{{ $snapshot->companyId }}">
                    <div class="tre-form-grid">
                        <div><label class="form-label">Version</label><input class="form-control" name="version" maxlength="80" placeholder="budget-v2" required></div>
                        <div><label class="form-label">Effective at</label><input class="form-control" type="datetime-local" name="effective_at" required></div>
                        <div><label class="form-label">Max daily exposure</label><input class="form-control" type="number" step="0.01" min="0.01" name="max_daily_risk_exposure" value="{{ $budget['max_daily_risk_exposure'] ?? 5000 }}" required></div>
                        <div><label class="form-label">Autonomous ceiling</label><select class="form-select" name="max_autonomous_single_action_level">@foreach(['MINIMAL','LOW','MEDIUM','HIGH','EXTREME'] as $level)<option {{ ($budget['max_autonomous_single_action_level'] ?? 'MEDIUM') === $level ? 'selected' : '' }}>{{ $level }}</option>@endforeach</select></div>
                        <div><label class="form-label">Monitoring ratio</label><input class="form-control" type="number" step="0.01" min="0.01" max="1" name="monitoring_threshold_ratio" value="{{ $budget['monitoring_threshold_ratio'] ?? 0.8 }}" required></div>
                        <div class="wide"><label class="form-label">Reason</label><textarea class="form-control" name="reason" maxlength="1000" required></textarea></div>
                    </div><button class="btn btn-primary mt-3" type="submit">Schedule budget version</button>
                </form>
            </div></div>
            <div class="tre-card"><div class="tre-card-body"><h2>Schedule Policy Overlay</h2>
                <form method="POST" action="{{ route('dashboard.admin.titan.risk.engine.policy.overlay.schedule') }}">@csrf
                    <input type="hidden" name="company_id" value="{{ $snapshot->companyId }}">
                    <div class="tre-form-grid">
                        <div><label class="form-label">Policy key</label><input class="form-control" name="policy_key" maxlength="120" placeholder="operations.safety" required></div>
                        <div><label class="form-label">Version</label><input class="form-control" name="version" maxlength="80" placeholder="policy-v2" required></div>
                        <div><label class="form-label">Scope</label><select class="form-select" name="scope"><option>TENANT</option><option>TENANT_CAPABILITY</option><option>CAPABILITY</option><option>GLOBAL</option></select></div>
                        <div><label class="form-label">Capability</label><input class="form-control" name="capability" maxlength="160" value="{{ $snapshot->capability }}" placeholder="required for capability scope"></div>
                        <div><label class="form-label">Daily exposure ceiling</label><input class="form-control" type="number" step="0.01" min="0.01" name="max_daily_risk_exposure"></div>
                        <div><label class="form-label">Monitoring ratio</label><input class="form-control" type="number" step="0.01" min="0.01" max="1" name="monitoring_threshold_ratio"></div>
                        <div><label class="form-label">Autonomous ceiling</label><select class="form-select" name="max_autonomous_single_action_level"><option value="">No override</option>@foreach(['MINIMAL','LOW','MEDIUM','HIGH','EXTREME'] as $level)<option>{{ $level }}</option>@endforeach</select></div>
                        <div><label class="form-label">Hard block level</label><select class="form-select" name="hard_block_level"><option value="">No override</option>@foreach(['MINIMAL','LOW','MEDIUM','HIGH','EXTREME'] as $level)<option>{{ $level }}</option>@endforeach</select></div>
                        <div><label class="form-label">Effective at</label><input class="form-control" type="datetime-local" name="effective_at" required></div>
                        <div class="wide"><label class="form-label">Reason</label><textarea class="form-control" name="reason" maxlength="1000" required></textarea></div>
                    </div><button class="btn btn-primary mt-3" type="submit">Schedule overlay</button>
                </form>
            </div></div>
        </div>

        <div class="tre-two tre-section">
            <div class="tre-card"><div class="tre-card-body"><h2>Schedule Budget Rollback</h2>
                <form method="POST" action="{{ route('dashboard.admin.titan.risk.engine.policy.budget.rollback') }}">@csrf<input type="hidden" name="company_id" value="{{ $snapshot->companyId }}"><div class="tre-form-grid">
                    <div><label class="form-label">Target historical version</label><input class="form-control" name="target_version" required></div><div><label class="form-label">New rollback version</label><input class="form-control" name="new_version" required></div><div><label class="form-label">Effective at</label><input class="form-control" type="datetime-local" name="effective_at" required></div><div class="wide"><label class="form-label">Reason</label><textarea class="form-control" name="reason" required></textarea></div>
                </div><button class="btn btn-outline-primary mt-3" type="submit">Schedule immutable rollback</button></form>
            </div></div>
            <div class="tre-card"><div class="tre-card-body"><h2>Schedule Overlay Rollback</h2>
                <form method="POST" action="{{ route('dashboard.admin.titan.risk.engine.policy.overlay.rollback') }}">@csrf<input type="hidden" name="company_id" value="{{ $snapshot->companyId }}"><div class="tre-form-grid">
                    <div><label class="form-label">Policy key</label><input class="form-control" name="policy_key" required></div><div><label class="form-label">Scope</label><select class="form-select" name="scope"><option>TENANT</option><option>TENANT_CAPABILITY</option><option>CAPABILITY</option><option>GLOBAL</option></select></div><div><label class="form-label">Capability</label><input class="form-control" name="capability" value="{{ $snapshot->capability }}"></div><div><label class="form-label">Target version</label><input class="form-control" name="target_version" required></div><div><label class="form-label">New rollback version</label><input class="form-control" name="new_version" required></div><div><label class="form-label">Effective at</label><input class="form-control" type="datetime-local" name="effective_at" required></div><div class="wide"><label class="form-label">Reason</label><textarea class="form-control" name="reason" required></textarea></div>
                </div><button class="btn btn-outline-primary mt-3" type="submit">Schedule overlay rollback</button></form>
            </div></div>
        </div>

        <div class="tre-two tre-section">
            <div class="tre-card"><div class="tre-card-body"><h2>Budget versions</h2><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>Version</th><th>Daily</th><th>Autonomy</th><th>Effective</th><th>Source</th></tr></thead><tbody>@forelse(array_slice($snapshot->budgetVersions,0,$rowLimit) as $row)<tr><td>{{ $row['version'] }}</td><td>{{ $row['max_daily_risk_exposure'] }}</td><td>{{ $row['max_autonomous_single_action_level'] }}</td><td>{{ $row['effective_at'] }}</td><td>{{ $row['source'] }}</td></tr>@empty<tr><td colspan="5">No governed tenant budget versions.</td></tr>@endforelse</tbody></table></div></div></div>
            <div class="tre-card"><div class="tre-card-body"><h2>Policy overlays</h2><div class="tre-table-wrap"><table class="tre-table"><thead><tr><th>Policy</th><th>Version</th><th>Scope</th><th>Capability</th><th>Effective</th></tr></thead><tbody>@forelse(array_slice($snapshot->policyOverlays,0,$rowLimit) as $row)<tr><td>{{ $row['policy_key'] }}</td><td>{{ $row['version'] }}</td><td>{{ $row['scope'] }}</td><td>{{ $row['capability'] ?? '—' }}</td><td>{{ $row['effective_at'] }}</td></tr>@empty<tr><td colspan="5">No applicable overlays.</td></tr>@endforelse</tbody></table></div></div></div>
        </div>
    @endif
</div>
@endsection
