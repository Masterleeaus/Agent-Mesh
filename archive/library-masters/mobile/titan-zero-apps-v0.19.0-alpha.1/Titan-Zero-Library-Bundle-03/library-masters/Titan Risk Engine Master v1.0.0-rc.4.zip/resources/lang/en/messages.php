<?php

declare(strict_types=1);

return [
    'title' => 'Titan Risk Engine',
    'description' => 'Deterministic contextual risk assessment and pre-execution governance.',
];
