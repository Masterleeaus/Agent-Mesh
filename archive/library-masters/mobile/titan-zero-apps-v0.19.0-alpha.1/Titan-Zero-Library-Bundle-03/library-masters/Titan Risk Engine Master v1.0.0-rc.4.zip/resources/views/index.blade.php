@extends('panel.layout.app')

@section('title', 'Titan Risk Engine')

@section('content')
<style>
    .tre-user{max-width:1200px;margin:0 auto;padding:24px 16px 48px}.tre-u-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.tre-u-card{border:1px solid rgba(127,127,127,.18);border-radius:14px;background:var(--bs-body-bg,#fff);padding:18px}.tre-u-k{font-size:12px;text-transform:uppercase;letter-spacing:.08em;opacity:.65}.tre-u-v{font-size:26px;font-weight:750;margin-top:6px}.tre-u-table{width:100%;border-collapse:collapse;font-size:13px}.tre-u-table th,.tre-u-table td{padding:9px;border-bottom:1px solid rgba(127,127,127,.14);text-align:left}.tre-u-note{padding:12px 14px;border-left:3px solid var(--bs-primary,#6f42c1);background:rgba(127,127,127,.07);border-radius:8px}@media(max-width:900px){.tre-u-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:520px){.tre-u-grid{grid-template-columns:1fr}}
</style>
<div class="tre-user">
    <h1>Titan Risk Engine</h1>
    <p class="text-muted">Read-only operational Risk view. Policy changes and circuit recovery controls are restricted to governed administrator workflows.</p>
    @if(!$snapshot)
        <div class="tre-u-note">No tenant context could be resolved from the authenticated account, so Risk data is not displayed.</div>
    @else
        @php $exp=$snapshot->exposure; $vel=$snapshot->velocity; $budget=$snapshot->budget; $max=(float)($budget['max_daily_risk_exposure']??0); $util=$max>0?min(999,((float)($exp['score_sum']??0)/$max)*100):0; @endphp
        <div class="tre-u-grid">
            <div class="tre-u-card"><div class="tre-u-k">24h exposure</div><div class="tre-u-v">{{ number_format((float)($exp['score_sum']??0),1) }}</div><small>{{ $exp['assessment_count']??0 }} assessments</small></div>
            <div class="tre-u-card"><div class="tre-u-k">Budget used</div><div class="tre-u-v">{{ number_format($util,1) }}%</div><small>{{ $budget['version']??'default-v1' }}</small></div>
            <div class="tre-u-card"><div class="tre-u-k">15m pressure</div><div class="tre-u-v">{{ $vel['level']??'NORMAL' }}</div><small>{{ number_format((float)($vel['actions_per_minute']??0),2) }} actions/min</small></div>
            <div class="tre-u-card"><div class="tre-u-k">Open circuits</div><div class="tre-u-v">{{ $snapshot->circuitSummary['open']??0 }}</div><small>{{ $snapshot->circuitSummary['half_open']??0 }} recovering</small></div>
        </div>
        <div class="tre-u-card">
            <h3>Recent Risk assessments</h3>
            <div style="overflow:auto"><table class="tre-u-table"><thead><tr><th>When UTC</th><th>Capability</th><th>Score</th><th>Level</th><th>Decision</th></tr></thead><tbody>
            @forelse(array_slice($snapshot->recentAssessments,0,12) as $row)<tr><td>{{ $row['assessed_at']??'—' }}</td><td>{{ $row['capability']??'—' }}</td><td>{{ $row['score']??'—' }}</td><td>{{ $row['level']??'—' }}</td><td>{{ $row['decision']??'—' }}</td></tr>@empty<tr><td colspan="5">No recent Risk assessments.</td></tr>@endforelse
            </tbody></table></div>
        </div>
        <div class="tre-u-note mt-3">Risk is an upper-bound governance layer. This view explains current constraints; it does not grant authority or provide a way to bypass approval, Assurance, Shield, or circuit decisions.</div>
    @endif
</div>
@endsection
