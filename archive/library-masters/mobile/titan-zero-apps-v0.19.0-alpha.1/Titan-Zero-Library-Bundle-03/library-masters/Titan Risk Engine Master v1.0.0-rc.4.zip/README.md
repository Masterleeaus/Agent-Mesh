# Titan Risk Engine v1.0.0-rc.3

Deterministic action risk, historical exposure intelligence, stateful circuit enforcement, cross-engine governance evidence, governed risk budgets, and an operational Risk Control Centre for Titan Zero.

## v1.0.0-rc.3 Installer 1.7.6 Navigation Compatibility

This RC adds active host navigation synchronization. `extension.manifest.json` remains the canonical declaration, while provider boot now projects one top-level `Titan Risk` parent and nests `Risk Control Centre` beneath it using `MenuContributionRegistry` when available or the MagicAI `menus` table + `MenuService::regenerate()` fallback on Installer 1.7.6. Existing rc.2 rows are repaired in place by resolving the parent menu database ID from its canonical route. A repair command is also available: `php artisan titan:titan-risk-engine:sync-navigation --json`.
Navigation rows are removed idempotently during extension uninstall so stale sidebar links are not left behind.

## Operational capabilities

- `risk.assess` — deterministic 0–100 single-action assessment
- `risk.gate` — fresh pre-execution directive with circuits, budgets, policy and enforcement receipt
- `risk.aggregate` — durable 1h / 4h / 24h historical exposure
- `risk.velocity` — 5m / 15m / 60m operational-pressure intelligence
- `risk.circuit` — persistent CLOSED / OPEN / HALF_OPEN tenant and capability circuits
- `risk.feedback` — governed Model Council / Assurance / Shield evidence handoff



## v1.0.0-rc.3 Final Production Hardening & Host-Ready Certification

Pass 9 closes release drift rather than changing the core scoring model. It enforces the configured disabled state as fail-closed, removes the deprecated request-tenant admin controller, publishes canonical user/admin navigation contributions, upgrades the host certification command from binding-presence checks to real container resolution plus table/column/route/view/package-integrity checks, and ships an exact live-host acceptance checklist/report template. The release remains an RC until the target MagicAI host completes Installer 1.7.6 install/upgrade, migration, boot, navigation, authorization, runtime and retain-data uninstall certification.

## v0.9.0 Security, Abuse-Case & Fuzz Hardening

Pass 8 hardens every authority-bearing boundary against hostile or malformed input. It adds semantic idempotency fingerprints, full authorization-bound enforcement receipt verification, governance-evidence lineage matching, policy/budget content-digest verification on hydration, bounded/canonical metadata handling, finite-number validation, trusted server-side governance lineage, and a deterministic 500-case fuzz corpus. These controls fail closed without changing the deterministic scoring model.

## v0.8.0 Performance, Concurrency & Failure-Mode Hardening

Pass 7 adds a fail-closed `RiskGateContract` decorator, runtime latency/degradation telemetry, asynchronous-by-default Signal delivery with retry backpressure, soft recent-activity cache degradation, classified idempotency collision handling, configurable row-lock transaction retries, atomic policy/evidence transactions, a 100-request contention model, and a package-level deterministic scorer benchmark. Existing risk scoring semantics are unchanged.

## v0.7.0 Risk Control Centre

Administrator UI: `/dashboard/admin/titan-risk-engine/control-centre`

Authenticated read-only UI: `/dashboard/user/titan-risk-engine`

The Control Centre exposes:

- 24-hour exposure and assessment severity;
- operational budget utilization;
- 15-minute velocity/pressure;
- tenant and capability circuit state;
- effective policy lineage and content digest;
- enforcement receipts and dispatch authority;
- Risk Signal outbox health and retry;
- immutable policy change history;
- budget versions and policy overlays.

Policy operations do not edit database rows directly. Budget/policy scheduling and rollback flow through `RiskPolicyGovernanceService` and create causal `RiskPolicyChangeEvidence`.

The authenticated user surface is read-only and derives its tenant boundary from the authenticated account. If tenant context is unavailable, no Risk data is shown.

## Safety invariants

- Offline operation never increases authority.
- HIGH/EXTREME impact cannot be averaged away.
- OPEN circuits deny normal execution.
- HALF_OPEN circuits require supervised recovery.
- Tenant/commercial budgets constrain autonomy but cannot weaken hard safety ceilings.
- Historical policy versions are immutable; rollback creates a new prospective version.
- External evidence is an upper-bound constraint except the narrow Assurance monitored-release handshake.
- Assurance cannot override BLOCK/DENY, approval requirements, reduced-authority holds, or non-CLOSED circuits.
- Signal delivery failure never erases governance evidence; events remain in the outbox.
- UI controls cannot bypass Risk, Assurance, Shield, Autonomy or Command Bus enforcement.
- Risk never executes the underlying business mutation.
- Idempotency keys cannot be replayed across different semantic actions/resources/actors.
- Enforcement receipts are bound to the exact authorization context and are independently digest-verifiable.
- Persisted governed budget/policy content is digest-verified before becoming effective.

## Policy lineage

- `baseline-v1` — single-action assessment
- `intelligence-v1` — aggregate and velocity semantics
- `circuit-v1` — circuit hysteresis and recovery
- `integration-v1` — cross-engine feedback, Signal, and enforcement-receipt semantics
- `operational-governance-v1` — budgets and immutable policy overlays

## Durable evidence

Risk owns and retains:

- `titan_risk_assessments`
- `titan_risk_circuits`
- `titan_risk_circuit_transitions`
- `titan_risk_signal_outbox`
- `titan_risk_enforcement_receipts`
- `titan_risk_governance_feedback`
- `titan_risk_policy_overlays`
- `titan_risk_budget_versions`
- `titan_risk_policy_changes`

## Blueprint alignment

Installer 1.7.8 flat-root package; canonical Titan Extension Blueprint v4.2 manifest schema 2.2. See `docs/BLUEPRINT-v4.2-ALIGNMENT.md`, `docs/PASS-5-GOVERNED-RISK-BUDGETS-POLICY-REGISTRY.md`, and `docs/PASS-8-SECURITY-ABUSE-FUZZ-HARDENING.md`.
