<?php

use App\Extensions\TitanRiskEngine\System\Http\Controllers\IndexController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', IndexController::class)->name('index');
