<?php

use App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin\RiskControlCentreController;
use App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin\RiskPolicyOperationsController;
use App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin\RiskSignalOperationsController;
use Illuminate\Routing\Router;

/** @var Router $router */
$router->get('/', static fn () => redirect()->route('dashboard.admin.titan.risk.engine.control-centre'))->name('index');
$router->get('/control-centre', RiskControlCentreController::class)->name('control-centre');
$router->post('/policy/budget', [RiskPolicyOperationsController::class, 'scheduleBudget'])->name('policy.budget.schedule');
$router->post('/policy/budget/rollback', [RiskPolicyOperationsController::class, 'rollbackBudget'])->name('policy.budget.rollback');
$router->post('/policy/overlay', [RiskPolicyOperationsController::class, 'scheduleOverlay'])->name('policy.overlay.schedule');
$router->post('/policy/overlay/rollback', [RiskPolicyOperationsController::class, 'rollbackOverlay'])->name('policy.overlay.rollback');
$router->post('/signals/dispatch', [RiskSignalOperationsController::class, 'dispatch'])->name('signals.dispatch');
