# Changelog

## 1.0.0-rc.3 — Single-Parent Navigation Hierarchy Hotfix

- Collapses Risk navigation to one top-level `Titan Risk` parent.
- Nests `Risk Control Centre` beneath the parent on Installer 1.7.6/MagicAI menus using a resolved physical parent id.
- Repairs existing rc.2 menu rows on provider boot and via `titan:titan-risk-engine:sync-navigation`.
- Retains the admin root URL as a redirect to the canonical Control Centre page.
- Removes the orphan `resources/views/admin.blade.php` view so every rendered Risk page is represented exactly once in navigation.

## 1.0.0-rc.2 — Installer 1.7.6 Navigation Self-Heal Hotfix

- Added `TitanMenuCompatibilityAdapter` with modern `MenuContributionRegistry` support and MagicAI `menus` table fallback.
- Provider boot now synchronizes Titan Risk user/admin navigation automatically and preserves existing administrator order/enabled state.
- Added `titan:titan-risk-engine:sync-navigation` for explicit repair/synchronization.
- Calls `App\Services\Common\MenuService::regenerate()` after legacy synchronization so host menu caches refresh.
- Uses the Blueprint-proven `tabler-folders` safe fallback icon to avoid dynamic Blade component failures.
- Host certification now verifies that both Risk navigation routes are actually registered.
- Uninstall now removes Risk-owned host navigation contributions and regenerates host menu cache without touching retained Risk data.
- Retains the Installer 1.7.6 legacy root-manifest compatibility surface and optional Titan Signal dependency hotfix.

## 1.0.0-rc.2 — Pass 9 Final Production Hardening & Host-Ready Certification

- Enforced `enabled=false` as a fail-closed runtime state for both `risk.assess` and `risk.gate`.
- Removed the deprecated `AdminController` compatibility entry point that accepted request-controlled tenant context.
- Added canonical user/admin navigation contributions for the read-only Risk page and admin Risk Control Centre.
- Upgraded `titan:titan-risk-engine:certify` to resolve all public Risk contracts and verify MySQL driver, owned tables/critical columns, registered routes, views, canonical folder identity, PHP/Laravel floors and package integrity.
- Corrected verification metadata to reflect existing performance and fault-injection coverage.
- Removed the unused uploads ownership declaration.
- Added final production contract audits, host certification checklist/report template and release-candidate evidence.
- No baseline risk-score thresholds were weakened.


## 0.9.0 — Pass 8 Security, Abuse-Case & Fuzz Hardening

- Added strict UTF-8/control-character/length/positive-ID validation to authority-bearing Risk context and governance evidence fields.
- Added finite-number rejection for impact, budget, policy and cross-engine confidence inputs.
- Added byte-bounded canonical metadata sanitization, reserved-key alias stripping and canonical-key collision detection.
- Added semantic authorization fingerprinting for idempotency so a prior safe request key cannot authorize a different capability, action, actor or resource.
- Expanded enforcement receipts to bind action, actor, resource and request fingerprint; added public receipt integrity verifier with context/replay checks.
- Added trusted governance-lineage handling: raw caller trace headers are ignored for admin policy changes and cross-engine feedback must exactly match the gated action lineage.
- Added persisted policy/budget digest verification on hydration so database-side policy tampering fails closed.
- Added hardened receipt persistence fields and forward migration.
- Added deterministic 500-case metadata fuzzing plus tenant/replay/tamper/oversize/non-finite security regression suites.
- Preserved all prior scoring, circuit, budget and execution-boundary semantics.

## 0.8.0 — Pass 7 Performance, Concurrency & Failure-Mode Hardening

- Added `FailClosedRiskGate` around the normal gate: authoritative dependency exceptions resolve to `EXTREME / BLOCK / DENY` without leaking raw exception messages or trusting claimed actor identity.
- Added host runtime event sink for gate latency, SLA breach and degraded/fail-closed events.
- Disabled inline Signal delivery by default; Signal publication is now outbox-first and worker/command driven.
- Added bounded Signal batch size, retry delay, maximum attempts and non-acknowledgement failure accounting.
- Cache failures degrade recent-activity telemetry without weakening durable aggregate/velocity authority.
- Signal staging failure can no longer roll back a persisted assessment, circuit transition or governance feedback solely because the secondary integration is unavailable.
- Added database unique-error classification before idempotency collision recovery.
- Made circuit transaction retry count configurable while retaining row locks and stale-version rejection.
- Added production transaction runner so policy/budget mutations and change evidence are atomic.
- Fixed an implementation defect found by Pass 7 tests where a void transaction callback could execute twice through null-coalescing fallback.
- Added 100-request same-key contention model and pure deterministic scorer p99 benchmark.

## 0.7.0 — Pass 6 Risk Control Centre & Policy Operations UI
- Replaced scaffold views with a MagicAI-host-compatible Risk Control Centre using `panel.layout.app`.
- Added tenant-scoped operational cards for 24h exposure, budget utilization, circuit state, Signal delivery and enforcement receipts.
- Added bounded read models for recent assessments, circuits, Signals, receipts, policy changes, budgets and overlays.
- Added capability-specific effective policy and policy-digest visibility.
- Added governed admin workflows for prospective budget/policy scheduling and rollback-by-new-version.
- Added manual Signal outbox retry through the durable Risk Signal dispatcher.
- Added a strictly read-only authenticated tenant Risk view.
- Added tenant resolution compatible with `company_id` and host `company_id`.
- Fixed the stale capability-shape/version assertions in the extension boot test.

## 0.5.0
- Activated `risk.feedback` for typed Model Council, Assurance, and Shield governance evidence.
- Added durable Signal outbox and acknowledgement-based `titan.signal.ingest` bridge.
- Added `risk.assessed`, threshold, exposure, circuit-transition, and governance-feedback Signal schemas.
- Added tamper-evident, tenant-bound pre-execution enforcement receipts.
- Added durable governance-feedback evidence with tenant/source/evidence idempotency.
- Added separate Forge pre-generation and post-generated-artifact Risk gates.
- Added Signal recovery command and provider/runtime certification checks.
- Corrected manifest ownership for circuit, transition, outbox, receipt, and feedback tables.
- Preserved no-cross-extension-implementation coupling and Command Bus execution ownership.

## 0.3.0
- Activated `risk.aggregate` over durable 1h / 4h / 24h historical windows.
- Activated `risk.velocity` over 5m / 15m / 60m windows with deterministic operational-pressure levels.
- Added tenant/capability/actor/resource/actor+capability query scopes.
- Added production `DatabaseRiskHistoryReader` and actor+capability+time index.
- Added immutable `baseline-v1` and `intelligence-v1` policy registry contracts.
- Added typed `CLOSED / OPEN / HALF_OPEN` circuit contract without advertising `risk.circuit`.
- Prevented runtime velocity configuration from weakening the built-in intelligence-v1 safety floor.
- Formalized Model Council, Forge, Assurance, Shield and Command Bus Risk handshakes.

## 0.2.3
- Rebased packaging to Titan Extension Manager 1.7.8 flat-root `titan-extension-v1`.
- Upgraded governance manifest to canonical Blueprint v4.2 schema 2.2.
- Added capability schemas, production documentation and certification command.
- Fixed MySQL strict-mode `assessed_at` precision declaration for the unreleased alpha migration.
- Preserved RiskGate's no-Command-Bus-cycle boundary.

## 0.2.2
- Durable tenant-bound risk ledger and idempotency foundation.

## 0.4.0

- Activated `risk.circuit` with persistent CLOSED/OPEN/HALF_OPEN state.
- Added tenant and tenant+capability circuit scopes.
- Added row-locked, version-checked atomic circuit transitions.
- Added append-only causal transition evidence.
- Added hysteresis, recovery cooldown, HALF_OPEN expiry, and supervised recovery probes.
- Integrated circuit enforcement into RiskGate without granting Risk domain execution authority.
- Added `circuit-v1` immutable policy lineage and production certification checks.

## 0.6.0 — Pass 5 Governed Risk Budgets & Policy Registry
- Added immutable tenant operational budget versions with prospective activation and rollback-by-new-version.
- Added scoped governed policy overlays with deterministic latest-effective resolution.
- Added non-weakenable engine defaults and hard block ceilings.
- Added 24-hour budget governance to `risk.gate` without changing intrinsic assessment scores/levels.
- Added policy/budget lineage to enforcement receipts.
- Added append-only policy-change evidence and three Risk-owned governance tables.

## Workforce Runtime Integration Pass 2 — 2026-08-22
- Added deterministic runtime discovery/provider fingerprint contract.
- Added fail-closed request/decision/response envelopes, idempotency, audit and health semantics.
- Added executable runtime descriptor regression coverage without granting authority on registration.
