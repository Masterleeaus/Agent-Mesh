# Workforce Runtime Pass 4 — Live Execution Protocol

Provider: `titan-risk-engine`

Added portable live-execution safety primitives: decision-adapter contract, provider health gate, immutable receipt registry contract, idempotency replay protection, governed command envelope and execution coordinator.

Mutation state: **POLICY-GATED — requires an adapter that explicitly reports ready**.

No installation, discovery, health state, cached receipt, retry, or signal may grant authority. `company_id` remains canonical.
