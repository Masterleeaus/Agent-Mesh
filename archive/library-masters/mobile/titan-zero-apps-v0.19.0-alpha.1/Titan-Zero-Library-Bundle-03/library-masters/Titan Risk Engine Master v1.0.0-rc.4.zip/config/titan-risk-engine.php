<?php

declare(strict_types=1);

return [
    'enabled' => true,
    'rollout_stage' => 'GENERAL',
    'queue' => 'titan-risk-engine',
    'tenant_key' => 'company_id',

    'ledger' => [
        'table' => 'titan_risk_assessments',
        'required' => true,
    ],

    'recent_activity' => [
        'limit' => 10,
        'ttl_seconds' => 86400,
    ],

    'aggregate' => [
        'windows_minutes' => [60, 240, 1440],
        'policy_version' => 'intelligence-v1',
    ],

    'velocity' => [
        'windows_minutes' => [5, 15, 60],
        'policy_version' => 'intelligence-v1',
        'thresholds' => [
            'elevated' => [
                'actions_per_minute' => 2.0,
                'score_points_per_minute' => 50.0,
                'severe_count' => 1,
            ],
            'high' => [
                'actions_per_minute' => 4.0,
                'score_points_per_minute' => 100.0,
                'severe_count' => 2,
            ],
            'critical' => [
                'actions_per_minute' => 8.0,
                'score_points_per_minute' => 200.0,
                'severe_count' => 3,
            ],
        ],
    ],

    'circuit' => [
        'table' => 'titan_risk_circuits',
        'transition_table' => 'titan_risk_circuit_transitions',
        'policy_version' => 'circuit-v1',
        'states' => ['CLOSED', 'OPEN', 'HALF_OPEN'],
        // Runtime configuration may make recovery stricter, never weaker than circuit-v1.
        'open_cooldown_seconds' => 300,
        'half_open_timeout_seconds' => 300,
        'required_successful_probes' => 2,
        'hysteresis_required' => true,
        'recovery_probe_required' => true,
        'normal_dispatch_allowed_states' => ['CLOSED'],
    ],



    'policy' => [
        'budget_table' => 'titan_risk_budget_versions',
        'overlay_table' => 'titan_risk_policy_overlays',
        'change_table' => 'titan_risk_policy_changes',
        'hard_block_level' => 'EXTREME',
        'default_budget' => [
            'version' => 'default-v1',
            'max_daily_risk_exposure' => 5000.0,
            'max_autonomous_single_action_level' => 'MEDIUM',
            'monitoring_threshold_ratio' => 0.80,
        ],
        // Governed overlays may tighten these ceilings or restore a prior governed version,
        // but can never resolve to weaker authority than the built-in defaults above.
        'allowed_constraints' => [
            'max_daily_risk_exposure',
            'max_autonomous_single_action_level',
            'monitoring_threshold_ratio',
            'hard_block_level',
        ],
    ],

    'runtime' => [
        'risk_assess_target_ms' => 50.0,
        'risk_gate_target_ms' => 100.0,
        'database_transaction_attempts' => 3,
    ],

    'integration' => [
        'inline_signal_dispatch' => false,
        'signal_dispatch_max_batch' => 100,
        'signal_retry_delay_seconds' => 30,
        'signal_max_attempts' => 20,
        'signal_outbox_table' => 'titan_risk_signal_outbox',
        'enforcement_receipt_table' => 'titan_risk_enforcement_receipts',
        'governance_feedback_table' => 'titan_risk_governance_feedback',
        'signal_event_name' => 'titan.signal.ingest',
    ],

    'metadata' => [
        'max_depth' => 4,
        'max_entries' => 100,
        'max_string_length' => 2000,
        'max_total_bytes' => 32768,
    ],
];
