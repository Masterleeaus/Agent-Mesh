<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Services\StaticRiskPolicyRegistry;
use PHPUnit\Framework\TestCase;

final class RiskPolicyRegistryTest extends TestCase
{
    public function test_builtin_policy_versions_are_immutable_and_resolvable(): void
    {
        $registry = new StaticRiskPolicyRegistry();
        self::assertSame('baseline-v1', $registry->current('single-action')->version);
        self::assertSame('intelligence-v1', $registry->current('historical-intelligence')->version);
        self::assertSame('baseline-v1', $registry->find('single-action', 'baseline-v1')?->version);
        self::assertSame('operational-governance-v1', $registry->current('operational-governance')->version);
    }
}
