<?php

declare(strict_types=1);

use App\Extensions\TitanRiskEngine\System\Workforce\WorkforceIntegrationDescriptor;

$root = dirname(__DIR__, 2);
require_once $root . '/System/Workforce/WorkforceIntegrationDescriptor.php';

$failures = [];
$assert = static function (bool $ok, string $message) use (&$failures): void { if (!$ok) $failures[] = $message; };

$d = new WorkforceIntegrationDescriptor($root);
$m = $d->manifest();
$assert(in_array(($m['schema_version'] ?? null), ['1.1','1.2'], true), 'schema_version');
$assert(($m['tenancy']['canonical_context_key'] ?? null) === 'company_id', 'company_id');
$assert(($m['runtime_discovery']['registration_grants_authority'] ?? null) === false, 'registration authority');
$assert(($m['runtime_discovery']['duplicate_provider_behavior'] ?? null) === 'blocked', 'duplicate provider');
$assert(($m['decision_pipeline']['missing_decision'] ?? null) === 'deny', 'missing decision');
$assert(($m['decision_pipeline']['short_circuit_on_deny'] ?? null) === true, 'deny short circuit');
$assert(($m['execution_safety']['partial_failure_behavior'] ?? null) === 'fail_closed', 'partial failure');
$assert(($m['execution_safety']['offline_behavior'] ?? null) === 'no_authority_escalation', 'offline authority');
$assert(($m['request_envelope']['provider_pin_required'] ?? null) === true, 'provider pin');
$assert(($m['response_envelope']['provider_provenance_required'] ?? null) === true, 'response provenance');
$assert(strlen($d->providerFingerprint()) === 64, 'fingerprint');
$deny = $d->failClosedDecision('test');
$assert($deny['decision'] === 'deny' && $deny['availability'] === 'blocked', 'fail closed decision');
foreach (($m['capabilities'] ?? []) as $c) { if (is_array($c) && isset($c['id'])) $assert($d->supportsCapability((string)$c['id']), 'capability lookup'); }
$assert(($m['ownership']['extension_may_create_workforce_identity'] ?? null) === false, 'identity ownership');

if ($failures) { fwrite(STDERR, 'WORKFORCE_RUNTIME_CONTRACT_TEST: FAIL ' . implode(', ', $failures) . PHP_EOL); exit(1); }
echo 'WORKFORCE_RUNTIME_CONTRACT_TEST: PASS 14/14' . PHP_EOL;
