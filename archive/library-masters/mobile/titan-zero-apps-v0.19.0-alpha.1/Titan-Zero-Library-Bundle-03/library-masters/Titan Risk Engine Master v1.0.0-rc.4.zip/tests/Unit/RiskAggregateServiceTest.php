<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Services\RiskAggregateService;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRiskHistoryReader;

final class RiskAggregateServiceTest extends TestCase
{
    public function test_four_hour_capability_query_has_exact_bounds_and_scope(): void
    {
        $asOf = new DateTimeImmutable('2026-08-19T00:00:00+00:00');
        $query = RiskHistoryQuery::forAggregateWindow(42, RiskAggregateScope::TENANT_CAPABILITY, RiskAggregateWindow::HOURS_4, $asOf, capability: 'invoice.send');
        $reader = new InMemoryRiskHistoryReader(new RiskExposureSnapshot(42, RiskAggregateScope::TENANT, $query->from, $query->to, 4, 100, 25, 40, 0, 0, 0));

        $result = (new RiskAggregateService($reader))->aggregate($query);

        self::assertSame('2026-08-18T20:00:00+00:00', $result->from->format(DATE_ATOM));
        self::assertSame(RiskAggregateScope::TENANT_CAPABILITY, $result->scope);
        self::assertSame('invoice.send', $result->capability);
    }
}
