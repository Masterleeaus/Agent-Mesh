<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\Services\DefaultRiskCircuitPolicy;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

final class RiskCircuitContractTest extends TestCase
{
    public function test_open_circuit_enters_half_open_only_after_cooldown_and_normalized_pressure(): void
    {
        $now = new DateTimeImmutable('2026-08-20T00:00:00+00:00');
        $key = new RiskCircuitKey(42, RiskCircuitScope::TENANT_CAPABILITY, 'invoice.send');
        $open = new RiskCircuitSnapshot($key, RiskCircuitState::OPEN, 2, ['CIRCUIT_SEVERE_PRESSURE'], 'circuit-v1', $now, $now, null, $now->modify('+5 minutes'), $now->modify('+1 hour'));
        $at = $now->modify('+6 minutes');
        $exposure = new RiskExposureSnapshot(42, RiskAggregateScope::TENANT_CAPABILITY, $at->modify('-1 hour'), $at, 1, 10, 10, 10, 0, 0, 0, 'invoice.send');
        $velocity = new RiskVelocityAssessment($exposure, RiskVelocityWindow::MINUTES_5, RiskVelocityLevel::NORMAL, 0.2, 2.0, []);

        $transition = (new DefaultRiskCircuitPolicy())->recommend($open, $exposure, $velocity, $at);

        self::assertSame(RiskCircuitState::HALF_OPEN, $transition->recommendedState);
        self::assertContains('PRESSURE_NORMALIZED', $transition->reasonCodes);
    }
}
