<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

final class RiskContextValidationTest extends TestCase
{
    public function test_invalid_tenant_is_rejected_before_persistence(): void
    {
        $this->expectException(InvalidArgumentException::class);
        new RiskContext(0, 'trace', 'corr', 'cause', 'x', 'y', 'user');
    }

    public function test_blank_idempotency_key_is_rejected(): void
    {
        $this->expectException(InvalidArgumentException::class);
        new RiskContext(42, 'trace', 'corr', 'cause', 'x', 'y', 'user', idempotencyKey: '   ');
    }
}
