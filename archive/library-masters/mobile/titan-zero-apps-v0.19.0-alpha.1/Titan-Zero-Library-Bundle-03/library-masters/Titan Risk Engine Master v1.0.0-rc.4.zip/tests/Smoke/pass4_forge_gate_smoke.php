<?php

declare(strict_types=1);
spl_autoload_register(static function (string $class): void { $prefix='App\\Extensions\\TitanRiskEngine\\'; if(!str_starts_with($class,$prefix))return; $p=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php'; if(is_file($p))require_once $p; });
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\ForgeRiskGate;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
function f4(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);} 
final class CaptureGate implements RiskGateContract { public ?RiskContextInput $last=null; public function evaluate(RiskContextInput $input): RiskGateResult{$this->last=$input; $c=new RiskContext($input->companyId,$input->traceId,$input->correlationId,$input->causationId,$input->capability,$input->action,$input->actorType,$input->claimedActorId,$input->resourceType,$input->resourceId,$input->verticalKey,$input->jurisdiction,$input->impact,$input->reversibility,$input->connectivity,[],$input->metadata,$input->idempotencyKey); return new RiskGateResult(new RiskAssessment($c,10,RiskLevel::MINIMAL,RiskDecision::ALLOW,[],'baseline-v1',new DateTimeImmutable()),RiskExecutionDirective::EXECUTE);}}
$capture=new CaptureGate(); $forge=new ForgeRiskGate($capture); $base=new RiskContextInput(42,'t','c','z','forge.generate','generate','agent',12);
$forge->preGeneration($base); f4($capture->last?->resourceType==='forge_build_spec','Forge pre-generation gate must force build-spec resource type.'); f4(($capture->last?->metadata['forge_phase']??null)==='pre_generation','Forge pre-generation phase must be explicit.');
$forge->postGeneration($base,'generated_code','artifact-1'); f4($capture->last?->resourceType==='generated_code','Forge post-generation gate must identify generated artifact type.'); f4($capture->last?->resourceId==='artifact-1','Forge post-generation gate must bind generated artifact id.');
$bad=false; try{$forge->postGeneration($base,'database_record','x');}catch(InvalidArgumentException){$bad=true;} f4($bad,'Forge post-generation must reject ungoverned artifact types.');
echo "PASS pass4_forge_gate_smoke\n";
