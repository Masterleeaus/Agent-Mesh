<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix='App\\Extensions\\TitanRiskEngine\\';
    if(!str_starts_with($class,$prefix)) return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';
    if(is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskSignalType;
use App\Extensions\TitanRiskEngine\System\Services\RiskSignalDispatcher;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;

function p7sd(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);}
final class O7sd implements RiskSignalOutboxContract {
    public array $events=[]; public int $asked=0; public array $failed=[]; public array $published=[];
    public function stage(RiskSignalEvent $event):void{$this->events[]=$event;}
    public function pending(int $limit=100):array{$this->asked=$limit;return array_slice($this->events,0,$limit);}
    public function markPublished(string $eventId,DateTimeImmutable $publishedAt):void{$this->published[]=$eventId;}
    public function markFailed(string $eventId,string $error,DateTimeImmutable $failedAt):void{$this->failed[$eventId]=$error;}
}
final class P7sd implements RiskSignalPublisherContract { public function __construct(private bool $ack){} public function publish(RiskSignalEvent $event):bool{return $this->ack;} }
$event=new RiskSignalEvent('e1',RiskSignalType::RISK_ASSESSED,42,'tr','co','ca','ca',new DateTimeImmutable('2026-08-21T00:00:00+00:00'),'INFO',[]);
$out=new O7sd();$out->events=[$event,$event,$event];
$d=new RiskSignalDispatcher($out,new P7sd(false),2);
$count=$d->dispatchPending(100);
p7sd($out->asked===2,'Signal dispatcher must clamp caller batch to configured max.');
p7sd($count===0&&($out->failed['e1']??null)==='publisher_not_acknowledged','Non-acknowledgement must count as a failed attempt.');
$out2=new O7sd();$out2->events=[$event];
$count2=(new RiskSignalDispatcher($out2,new P7sd(true),2))->dispatchPending(100);
p7sd($count2===1&&$out2->published===['e1'],'Acknowledged Signal must be marked published.');
echo "PASS Pass7 SignalDispatcherBehaviorSmokeTest\n";
