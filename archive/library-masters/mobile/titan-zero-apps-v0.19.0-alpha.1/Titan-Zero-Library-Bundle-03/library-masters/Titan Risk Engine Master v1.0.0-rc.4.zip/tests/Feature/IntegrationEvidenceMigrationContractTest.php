<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Feature;

use PHPUnit\Framework\TestCase;

final class IntegrationEvidenceMigrationContractTest extends TestCase
{
    public function test_pass4_integration_evidence_tables_are_declared_and_retained(): void
    {
        $path = dirname(__DIR__, 2) . '/database/migrations/2026_08_20_000005_create_risk_integration_evidence_tables.php';
        self::assertFileExists($path);
        $source = (string) file_get_contents($path);
        foreach (['titan_risk_signal_outbox','titan_risk_enforcement_receipts','titan_risk_governance_feedback'] as $table) self::assertStringContainsString($table, $source);
        self::assertStringContainsString('insert', (string) file_get_contents(dirname(__DIR__, 2) . '/System/Services/DatabaseRiskSignalOutbox.php'));
        self::assertStringNotContainsString('dropIfExists', $source);
    }
}
