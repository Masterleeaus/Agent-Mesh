<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix='App\\Extensions\\TitanRiskEngine\\'; if(!str_starts_with($class,$prefix)) return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php'; if(is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Services\RiskContextFingerprint;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptVerifier;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Services\RiskFeedbackCoordinator;
use App\Extensions\TitanRiskEngine\System\Services\RiskDirectivePolicy;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ModelCouncilRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\AssuranceRiskEvidence;

function p8b(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);} function t8b(callable $f,string $m):void{try{$f();}catch(Throwable){return;}throw new RuntimeException($m);}

// Policy/circuit evidence cannot carry oversized or control-character lineage.
t8b(fn()=>new RiskPolicyChangeEvidence('chg','BUDGET_SCHEDULED',42,'operational-budget','v1',str_repeat('t',300),'c','k',new DateTimeImmutable(),'reason'),'Oversized policy lineage must be rejected.');
t8b(fn()=>new RiskPolicyChangeEvidence('chg','BUDGET_SCHEDULED',42,'operational-budget','v1',"trace\0evil",'c','k',new DateTimeImmutable(),'reason'),'Control-character policy lineage must be rejected.');
t8b(fn()=>new RiskCircuitTransitionEvidence(str_repeat('t',300),'c','k',new DateTimeImmutable(),'circuit-v1'),'Oversized circuit lineage must be rejected.');
t8b(fn()=>new RiskCircuitKey(42,RiskCircuitScope::TENANT_CAPABILITY,str_repeat('c',300)),'Oversized circuit capability must be rejected.');

// Receipt verifier must reject replay against another tenant or resource even when the original receipt is intact.
$fp=new RiskContextFingerprint(); $factory=new RiskEnforcementReceiptFactory($fp); $verify=new RiskEnforcementReceiptVerifier($fp);
$ctx=new RiskContext(42,'t','c','k','invoice.send','send','user',7,resourceType:'invoice',resourceId:99);
$receipt=$factory->make(new RiskGateResult((new BaselineRiskScorer())->assess($ctx),RiskExecutionDirective::EXECUTE),new DateTimeImmutable('2026-08-21T00:00:00+00:00'));
p8b($verify->verify($receipt,$ctx),'Receipt must verify against its originating context.');
$otherTenant=new RiskContext(43,'t2','c2','k2','invoice.send','send','user',7,resourceType:'invoice',resourceId:99);
p8b(!$verify->verify($receipt,$otherTenant),'Receipt must not authorize another tenant.');
$otherResource=new RiskContext(42,'t3','c3','k3','invoice.send','send','user',7,resourceType:'invoice',resourceId:100);
p8b(!$verify->verify($receipt,$otherResource),'Receipt must not authorize another resource.');

// Cross-action governance evidence must be lineage-bound and non-finite confidence is invalid.
t8b(fn()=>new ModelCouncilRiskEvidence('ev-nan','t','c','k',new DateTimeImmutable(),NAN,10.0,3),'NaN Council disagreement must be rejected.');
t8b(fn()=>new AssuranceRiskEvidence('ev-inf','t','c','k',new DateTimeImmutable(),true,INF),'Infinite Assurance score must be rejected.');
$feedback=new RiskFeedbackCoordinator(new RiskDirectivePolicy());
t8b(fn()=>$feedback->applyModelCouncil(new RiskGateResult((new BaselineRiskScorer())->assess($ctx),RiskExecutionDirective::HOLD_FOR_ASSURANCE),new ModelCouncilRiskEvidence('ev-cross','other-trace','c','k',new DateTimeImmutable(),80.0,80.0,3)),'Feedback from another trace must not be attachable to this gate.');

// Provider/routes must retain authenticated admin boundary and user tenant derivation.
p8b(interface_exists('App\\Extensions\\TitanRiskEngine\\System\\Contracts\\RiskEnforcementReceiptVerifierContract'), 'Receipt verifier must expose a stable public contract.');
$provider=file_get_contents(dirname(__DIR__,2).'/System/TitanRiskEngineServiceProvider.php');
p8b(str_contains($provider,"['web','auth','admin']"),'Admin operations must remain behind web+auth+admin middleware.');
$userController=file_get_contents(dirname(__DIR__,2).'/System/Http/Controllers/IndexController.php');
p8b(str_contains($userController,'AuthenticatedTenantResolver') && !str_contains($userController,"integer('company_id')"),'User surface must derive tenant server-side, not from request tenant parameters.');
$policyController=file_get_contents(dirname(__DIR__,2).'/System/Http/Controllers/Admin/RiskPolicyOperationsController.php');
p8b(!str_contains($policyController, "header('X-Titan-Trace-Id'") && str_contains($policyController, "attributes->get('titan_trace_id'"), 'Policy lineage must come from trusted request attributes or server-generated IDs, never caller headers.');

echo "PASS Pass8 SecurityBoundarySmokeTest\n";
