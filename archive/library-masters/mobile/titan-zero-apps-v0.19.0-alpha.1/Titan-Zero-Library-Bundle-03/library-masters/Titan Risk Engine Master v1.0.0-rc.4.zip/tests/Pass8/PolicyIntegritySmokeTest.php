<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix='App\\Extensions\\TitanRiskEngine\\'; if(!str_starts_with($class,$prefix)) return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php'; if(is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyIntegrityVerifier;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;

function p8pi(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);} function t8pi(callable $f,string $m):void{try{$f();}catch(Throwable){return;}throw new RuntimeException($m);}

$at=new DateTimeImmutable('2026-08-21T00:00:00+00:00');
$budget=new RiskOperationalBudget(42,'budget-v1',500.0,RiskLevel::MEDIUM,0.8,$at);
$overlay=new RiskPolicyOverlay('ops','overlay-v1',RiskPolicyScope::TENANT,['max_daily_risk_exposure'=>400.0],$at,42);
t8pi(fn()=>new RiskOperationalBudget('-1','budget-negative',500.0,RiskLevel::MEDIUM,0.8,$at),'Negative numeric-string tenant budget must be rejected.');
t8pi(fn()=>new RiskPolicyOverlay("ops\0evil",'overlay-control',RiskPolicyScope::TENANT,['max_daily_risk_exposure'=>400.0],$at,42),'Control-character policy key must be rejected.');
t8pi(fn()=>new RiskPolicyOverlay('ops','overlay-cap-control',RiskPolicyScope::TENANT_CAPABILITY,['max_daily_risk_exposure'=>400.0],$at,42,"dispatch\0evil"),'Control-character capability must be rejected.');
$v=new RiskPolicyIntegrityVerifier();
$v->assertBudgetDigest($budget,$budget->contentDigest());
$v->assertOverlayDigest($overlay,$overlay->contentDigest());
t8pi(fn()=>$v->assertBudgetDigest($budget,str_repeat('0',64)),'Tampered budget digest must be rejected.');
t8pi(fn()=>$v->assertOverlayDigest($overlay,str_repeat('f',64)),'Tampered policy overlay digest must be rejected.');

$root=dirname(__DIR__,2);
$budgetStore=file_get_contents($root.'/System/Services/DatabaseRiskBudgetStore.php');
$overlayStore=file_get_contents($root.'/System/Services/DatabaseRiskPolicyOverlayStore.php');
p8pi(str_contains($budgetStore,'assertBudgetDigest'), 'Budget store hydration must verify persisted digest.');
p8pi(str_contains($overlayStore,'assertOverlayDigest'), 'Policy overlay hydration must verify persisted digest.');

echo "PASS Pass8 PolicyIntegritySmokeTest\n";
