<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Feature;

use PHPUnit\Framework\TestCase;

final class ExtensionBootTest extends TestCase
{
    public function test_manifest_only_advertises_operational_risk_capabilities(): void
    {
        $manifest = json_decode(
            (string) file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'),
            true,
            512,
            JSON_THROW_ON_ERROR,
        );

        self::assertSame('1.0.0-rc.3', $manifest['version']);
        $capabilityIds = array_values(array_map(static fn (array $capability): string => (string) $capability['id'], $manifest['capabilities']));
        foreach (['risk.assess', 'risk.gate', 'risk.aggregate', 'risk.velocity', 'risk.circuit', 'risk.feedback'] as $capability) {
            self::assertContains($capability, $capabilityIds);
        }
        self::assertFalse($manifest['queues']['used']);
    }
}
