<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/System/Host/RiskNavigationDefinitions.php';

use App\Extensions\TitanRiskEngine\System\Host\RiskNavigationDefinitions;

$definitions = RiskNavigationDefinitions::all();
$failures = [];
$check = static function (bool $ok, string $message) use (&$failures): void {
    if (!$ok) $failures[] = $message;
};

$parents = array_values(array_filter($definitions, static fn(array $row): bool => empty($row['parent_route'])));
$children = array_values(array_filter($definitions, static fn(array $row): bool => !empty($row['parent_route'])));

$check(count($parents) === 1, 'Risk navigation must expose exactly one parent menu item');
$check(($parents[0]['id'] ?? null) === 'titan-risk-engine-root', 'canonical parent id must be titan-risk-engine-root');
$check(($parents[0]['label'] ?? null) === 'Titan Risk', 'canonical parent label must be Titan Risk');
$check(($parents[0]['route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'parent must open the tenant Risk page');
$check(count($children) === 1, 'Risk navigation must expose exactly one child page link');
$check(($children[0]['route'] ?? null) === 'dashboard.admin.titan.risk.engine.control-centre', 'Control Centre child route drift');
$check(($children[0]['parent_route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'Control Centre must be nested under Titan Risk');

$routes = array_values(array_map(static fn(array $row): string => (string) ($row['route'] ?? ''), $definitions));
$check(count($routes) === count(array_unique($routes)), 'navigation routes must be unique');
$check(in_array('dashboard.user.titan.risk.engine.index', $routes, true), 'tenant Risk page must be linked');
$check(in_array('dashboard.admin.titan.risk.engine.control-centre', $routes, true), 'Control Centre page must be linked');

$adminRoutes = (string) file_get_contents(dirname(__DIR__, 2) . '/routes/admin.php');
$check(str_contains($adminRoutes, "redirect()->route('dashboard.admin.titan.risk.engine.control-centre')"), 'admin index alias must redirect to canonical Control Centre page');
$check(!is_file(dirname(__DIR__, 2) . '/resources/views/admin.blade.php'), 'orphan admin.blade.php must be removed');

if ($failures !== []) {
    fwrite(STDERR, "NAVIGATION_HIERARCHY_SMOKE: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "NAVIGATION_HIERARCHY_SMOKE: PASS\n";
