<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskLedgerWriteResult;

function p7id(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

final class Ledger7id implements RiskAssessmentLedgerContract {
    public array $byKey=[]; public int $created=0;
    public function findByIdempotencyKey(int|string $companyId,string $idempotencyKey): ?RiskAssessment { return $this->byKey[(string)$companyId.'|'.$idempotencyKey]??null; }
    public function persist(RiskAssessment $assessment): RiskLedgerWriteResult {
        $key=(string)$assessment->context->companyId.'|'.$assessment->context->idempotencyKey;
        if(isset($this->byKey[$key])) return new RiskLedgerWriteResult($this->byKey[$key],false,null);
        $this->byKey[$key]=$assessment; $this->created++;
        return new RiskLedgerWriteResult($assessment,true,$this->created);
    }
}
final class Recent7id implements RecentActivityProviderContract { public int $records=0; public function recentFor(int|string $companyId,string $actorType,int|string|null $actorId,int $limit=10): array{return [];} public function record(RiskAssessment $assessment): void{$this->records++;} }

$ledger=new Ledger7id(); $recent=new Recent7id();
$manager=new RiskManager(new BaselineRiskScorer(),$recent,new RiskMetadataSanitizer(),10,$ledger);
$first=null;
for($i=0;$i<100;$i++){
    $result=$manager->assess(new RiskContext(42,'trace-contention','corr-contention','cause-contention','invoice.send','send','user',7,idempotencyKey:'same-request'));
    $first ??= $result;
    p7id($result->assessedAt == $first->assessedAt && $result->score === $first->score,'All 100 retry/contention requests must resolve to the canonical assessment.');
}
p7id($ledger->created===1,'100 same-key requests must create exactly one assessment.');
p7id($recent->records===1,'100 same-key requests must update recent activity exactly once.');
echo "PASS Pass7 IdempotencyContentionModelSmokeTest requests=100 created=1\n";
