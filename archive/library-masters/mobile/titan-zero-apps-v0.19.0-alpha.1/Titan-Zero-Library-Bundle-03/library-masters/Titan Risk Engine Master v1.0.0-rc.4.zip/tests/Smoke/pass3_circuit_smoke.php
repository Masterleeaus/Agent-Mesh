<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\Services\DefaultRiskCircuitPolicy;
use App\Extensions\TitanRiskEngine\System\Services\RiskCircuitManager;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;

function ensure3(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

final class InMemoryCircuitStore implements RiskCircuitStoreContract
{
    /** @var array<string,RiskCircuitSnapshot> */
    public array $rows = [];
    /** @var list<RiskCircuitTransitionEvidence> */
    public array $events = [];

    private function k(RiskCircuitKey $key): string { return $key->storageKey(); }

    public function get(RiskCircuitKey $key): ?RiskCircuitSnapshot { return $this->rows[$this->k($key)] ?? null; }

    public function getOrCreate(RiskCircuitKey $key, DateTimeImmutable $at, string $policyVersion): RiskCircuitSnapshot
    {
        return $this->rows[$this->k($key)] ??= RiskCircuitSnapshot::closed($key, $at, $policyVersion);
    }

    public function apply(
        RiskCircuitSnapshot $expected,
        RiskCircuitState $nextState,
        array $reasonCodes,
        DateTimeImmutable $at,
        ?DateTimeImmutable $probeAfter,
        ?DateTimeImmutable $expiresAt,
        int $successfulProbeCount,
        RiskCircuitTransitionEvidence $evidence,
    ): RiskCircuitSnapshot {
        $key = $this->k($expected->key);
        $current = $this->rows[$key] ?? null;
        if ($current === null || $current->version !== $expected->version || $current->state !== $expected->state) {
            throw new RuntimeException('STALE_CIRCUIT_VERSION');
        }
        $next = $expected->transitioned($nextState, $reasonCodes, $at, $probeAfter, $expiresAt, $successfulProbeCount);
        $this->rows[$key] = $next;
        $this->events[] = $evidence->withStates($expected->state, $nextState, $next->version);
        return $next;
    }
}

$now = new DateTimeImmutable('2026-08-20T07:00:00+00:00');
$key = new RiskCircuitKey(42, RiskCircuitScope::TENANT_CAPABILITY, 'invoice.send');
$store = new InMemoryCircuitStore();
$policy = new DefaultRiskCircuitPolicy();
$manager = new RiskCircuitManager($store, $policy, requiredSuccessfulProbes: 2);

$closed = $store->getOrCreate($key, $now, 'circuit-v1');
ensure3($closed->state === RiskCircuitState::CLOSED, 'New circuit must start CLOSED.');

$criticalExposure = new RiskExposureSnapshot(
    companyId: 42,
    scope: RiskAggregateScope::TENANT_CAPABILITY,
    from: $now->modify('-60 minutes'),
    to: $now,
    assessmentCount: 8,
    scoreSum: 510.0,
    scoreAverage: 63.75,
    scoreMaximum: 100.0,
    highOrExtremeCount: 3,
    extremeCount: 1,
    blockedCount: 1,
    capability: 'invoice.send',
);
$criticalVelocity = new RiskVelocityAssessment(
    exposure: $criticalExposure,
    window: RiskVelocityWindow::MINUTES_5,
    level: RiskVelocityLevel::CRITICAL,
    actionsPerMinute: 8.0,
    scorePointsPerMinute: 200.0,
    reasonCodes: ['CRITICAL_ACTIVITY_PRESSURE'],
);
$evidence = new RiskCircuitTransitionEvidence('trace-1','corr-1','cause-1',$now,'circuit-v1');
$opened = $manager->reconcile($closed, $criticalExposure, $criticalVelocity, $evidence);
ensure3($opened->state === RiskCircuitState::OPEN, 'Critical pressure must OPEN a CLOSED circuit.');
ensure3($opened->probeAfter?->getTimestamp() >= $now->modify('+5 minutes')->getTimestamp(), 'OPEN circuit must enforce cooldown.');
ensure3($manager->mayDispatch($opened) === false, 'OPEN circuit must deny executor dispatch.');

$beforeCooldown = $manager->reconcile($opened, $criticalExposure, $criticalVelocity, new RiskCircuitTransitionEvidence('trace-2','corr-2','cause-2',$now->modify('+2 minutes'),'circuit-v1'));
ensure3($beforeCooldown->state === RiskCircuitState::OPEN, 'OPEN circuit cannot enter HALF_OPEN before cooldown.');

$recoveryAt = $now->modify('+6 minutes');
$normalExposure = new RiskExposureSnapshot(42, RiskAggregateScope::TENANT_CAPABILITY, $recoveryAt->modify('-60 minutes'), $recoveryAt, 1, 10.0, 10.0, 10.0, 0, 0, 0, 'invoice.send');
$normalVelocity = new RiskVelocityAssessment($normalExposure, RiskVelocityWindow::MINUTES_5, RiskVelocityLevel::NORMAL, 0.2, 2.0, []);
$halfOpen = $manager->reconcile($beforeCooldown, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-3','corr-3','cause-3',$recoveryAt,'circuit-v1'));
ensure3($halfOpen->state === RiskCircuitState::HALF_OPEN, 'Normalized pressure after cooldown must enter HALF_OPEN.');
ensure3($manager->mayDispatch($halfOpen) === false, 'HALF_OPEN must not permit normal executor dispatch.');

$probe1 = $manager->recordProbe($halfOpen, true, true, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-4','corr-4','cause-4',$recoveryAt->modify('+10 seconds'),'circuit-v1'));
ensure3($probe1->state === RiskCircuitState::HALF_OPEN && $probe1->successfulProbeCount === 1, 'First supervised successful probe must remain HALF_OPEN.');
$probe2 = $manager->recordProbe($probe1, true, true, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-5','corr-5','cause-5',$recoveryAt->modify('+20 seconds'),'circuit-v1'));
ensure3($probe2->state === RiskCircuitState::CLOSED, 'Required supervised successful probes must CLOSE circuit.');

$openedAgain = $manager->reconcile($probe2, $criticalExposure, $criticalVelocity, new RiskCircuitTransitionEvidence('trace-6','corr-6','cause-6',$recoveryAt->modify('+30 seconds'),'circuit-v1'));
$halfAgain = $manager->reconcile($openedAgain, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-7','corr-7','cause-7',$recoveryAt->modify('+6 minutes'),'circuit-v1'));
$failedProbe = $manager->recordProbe($halfAgain, false, true, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-8','corr-8','cause-8',$recoveryAt->modify('+6 minutes 10 seconds'),'circuit-v1'));
ensure3($failedProbe->state === RiskCircuitState::OPEN, 'Failed recovery probe must reopen circuit.');

$unsupervisedRejected = false;
try {
    $manager->recordProbe($halfAgain, true, false, $normalExposure, $normalVelocity, new RiskCircuitTransitionEvidence('trace-9','corr-9','cause-9',$recoveryAt->modify('+6 minutes 20 seconds'),'circuit-v1'));
} catch (InvalidArgumentException) { $unsupervisedRejected = true; }
ensure3($unsupervisedRejected, 'Recovery probes must be supervised.');

// Tenant-wide circuits require stronger evidence than one blocked capability action.
$tenantKey = new RiskCircuitKey(99, RiskCircuitScope::TENANT);
$tenantStore = new InMemoryCircuitStore();
$tenantManager = new RiskCircuitManager($tenantStore, $policy, requiredSuccessfulProbes: 2);
$tenantClosed = $tenantStore->getOrCreate($tenantKey, $now, 'circuit-v1');
$oneBlockedTenant = new RiskExposureSnapshot(99, RiskAggregateScope::TENANT, $now->modify('-60 minutes'), $now, 1, 100.0, 100.0, 100.0, 1, 1, 1);
$normalTenantVelocity = new RiskVelocityAssessment($oneBlockedTenant, RiskVelocityWindow::MINUTES_5, RiskVelocityLevel::NORMAL, 0.2, 5.0, []);
$tenantStillClosed = $tenantManager->reconcile($tenantClosed, $oneBlockedTenant, $normalTenantVelocity, new RiskCircuitTransitionEvidence('trace-t1','corr-t1','cause-t1',$now,'circuit-v1'));
ensure3($tenantStillClosed->state === RiskCircuitState::CLOSED, 'One blocked action must not globally open a tenant circuit.');
$clusteredTenant = new RiskExposureSnapshot(99, RiskAggregateScope::TENANT, $now->modify('-60 minutes'), $now, 4, 300.0, 75.0, 100.0, 3, 2, 3);
$tenantOpened = $tenantManager->reconcile($tenantStillClosed, $clusteredTenant, $normalTenantVelocity, new RiskCircuitTransitionEvidence('trace-t2','corr-t2','cause-t2',$now->modify('+1 second'),'circuit-v1'));
ensure3($tenantOpened->state === RiskCircuitState::OPEN, 'Clustered tenant-wide severe events must open the tenant circuit.');

// HALF_OPEN expiry fails closed by reopening; time alone never closes the circuit.
$expiredHalf = new RiskCircuitSnapshot($key, RiskCircuitState::HALF_OPEN, 20, ['AWAITING_SUPERVISED_PROBE'], 'circuit-v1', $now, $now->modify('-10 minutes'), $now->modify('-6 minutes'), $now->modify('-5 minutes'), $now->modify('-1 second'), 0);
$expiryRecommendation = $policy->recommend($expiredHalf, $normalExposure, $normalVelocity, $now);
ensure3($expiryRecommendation->recommendedState === RiskCircuitState::OPEN, 'Expired HALF_OPEN probe window must reopen, never auto-close.');

$staleRejected = false;
try {
    $store->apply($closed, RiskCircuitState::OPEN, ['STALE'], $now, null, null, 0, $evidence);
} catch (RuntimeException $e) { $staleRejected = $e->getMessage() === 'STALE_CIRCUIT_VERSION'; }
ensure3($staleRejected, 'Circuit store must reject stale expected versions.');

$manifest = json_decode(file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, 64, JSON_THROW_ON_ERROR);
ensure3(in_array('risk.circuit', $manifest['capabilities'] ?? [], true), 'Pass 3 manifest must advertise risk.circuit.');

$migration = dirname(__DIR__, 2) . '/database/migrations/2026_08_20_000004_create_titan_risk_circuits.php';
ensure3(is_file($migration), 'Pass 3 circuit migration must exist.');
$migrationText = file_get_contents($migration);
ensure3(str_contains($migrationText, 'lockForUpdate') === false, 'Migration should only define schema, not runtime locking.');
ensure3(str_contains($migrationText, 'titan_risk_circuit_transitions'), 'Circuit transition evidence table must be persisted.');

$storeSource = dirname(__DIR__, 2) . '/System/Services/DatabaseRiskCircuitStore.php';
ensure3(is_file($storeSource), 'Production database circuit store must exist.');
$storeText = file_get_contents($storeSource);
ensure3(str_contains($storeText, 'lockForUpdate()'), 'Production circuit state mutation must use row locking.');
ensure3(str_contains($storeText, "STALE_CIRCUIT_VERSION"), 'Production circuit store must reject stale state/version writes.');

echo "PASS pass3_circuit_smoke\n";
