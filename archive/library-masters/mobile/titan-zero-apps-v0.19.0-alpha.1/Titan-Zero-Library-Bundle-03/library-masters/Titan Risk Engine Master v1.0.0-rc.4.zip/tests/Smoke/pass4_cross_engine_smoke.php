<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskSignalType;
use App\Extensions\TitanRiskEngine\System\Services\RiskDirectivePolicy;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskFeedbackCoordinator;
use App\Extensions\TitanRiskEngine\System\Services\RiskSignalDispatcher;
use App\Extensions\TitanRiskEngine\System\ValueObjects\AssuranceRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ModelCouncilRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ShieldRiskEvidence;

function ensure4(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

final class MemorySignalOutbox implements RiskSignalOutboxContract
{
    /** @var array<string,RiskSignalEvent> */
    public array $events = [];
    /** @var array<string,bool> */
    public array $published = [];
    public function stage(RiskSignalEvent $event): void { $this->events[$event->eventId] = $event; }
    public function pending(int $limit = 100): array {
        return array_slice(array_values(array_filter($this->events, fn ($e) => !($this->published[$e->eventId] ?? false))), 0, $limit);
    }
    public function markPublished(string $eventId, DateTimeImmutable $publishedAt): void { $this->published[$eventId] = true; }
    public function markFailed(string $eventId, string $error, DateTimeImmutable $failedAt): void {}
}

final class MemorySignalPublisher implements RiskSignalPublisherContract
{
    public bool $available = true;
    /** @var list<string> */ public array $published = [];
    public function publish(RiskSignalEvent $event): bool {
        if (!$this->available) return false;
        $this->published[] = $event->eventId;
        return true;
    }
}

final class MemoryReceiptStore implements RiskEnforcementReceiptStoreContract
{
    /** @var array<string,RiskEnforcementReceipt> */ public array $receipts = [];
    public function persist(RiskEnforcementReceipt $receipt): void { $this->receipts[$receipt->receiptId] = $receipt; }
}

$at = new DateTimeImmutable('2026-08-20T08:00:00+00:00');
$context = new RiskContext(
    companyId: 42,
    traceId: 'trace-4',
    correlationId: 'corr-4',
    causationId: 'cause-4',
    capability: 'invoice.send',
    action: 'send',
    actorType: 'user',
    actorId: 7,
);
$assessment = new RiskAssessment($context, 52.0, RiskLevel::MEDIUM, RiskDecision::REQUIRE_ASSURANCE, [], 'baseline-v1', $at);
$closed = new RiskCircuitSnapshot(new RiskCircuitKey(42, RiskCircuitScope::TENANT_CAPABILITY, 'invoice.send'), RiskCircuitState::CLOSED, 3, [], 'circuit-v1', $at);
$gate = new RiskGateResult($assessment, RiskExecutionDirective::HOLD_FOR_ASSURANCE, [$closed]);

// Council uncertainty can tighten but never loosen governance.
$feedback = new RiskFeedbackCoordinator(new RiskDirectivePolicy());
$council = $feedback->applyModelCouncil($gate, new ModelCouncilRiskEvidence('council-1', 'trace-4', 'corr-4', 'cause-4', $at, 91.0, 88.0, 3, ['HIGH_DISAGREEMENT']));
ensure4($council->directive === RiskExecutionDirective::HOLD_FOR_APPROVAL, 'Very high Council disagreement must tighten to HOLD_FOR_APPROVAL.');
$alreadyDenied = new RiskGateResult($assessment, RiskExecutionDirective::DENY, [$closed]);
$deniedCouncil = $feedback->applyModelCouncil($alreadyDenied, new ModelCouncilRiskEvidence('council-2', 'trace-4', 'corr-4', 'cause-4', $at, 5.0, 5.0, 3));
ensure4($deniedCouncil->directive === RiskExecutionDirective::DENY, 'Council feedback must never loosen DENY.');

// Assurance may release only its own assurance hold, and only to monitored execution.
$assured = $feedback->applyAssurance($gate, new AssuranceRiskEvidence('assurance-1', 'trace-4', 'corr-4', 'cause-4', $at, true, 95.0, ['CHECKS_PASSED']));
ensure4($assured->directive === RiskExecutionDirective::EXECUTE_MONITORED, 'Passing Assurance should release REQUIRE_ASSURANCE only to monitored execution.');
$blockedAssessment = new RiskAssessment($context, 100.0, RiskLevel::EXTREME, RiskDecision::BLOCK, [], 'baseline-v1', $at);
$blockedGate = new RiskGateResult($blockedAssessment, RiskExecutionDirective::DENY, [$closed]);
$blockedAssured = $feedback->applyAssurance($blockedGate, new AssuranceRiskEvidence('assurance-2', 'trace-4', 'corr-4', 'cause-4', $at, true, 100.0));
ensure4($blockedAssured->directive === RiskExecutionDirective::DENY, 'Assurance must never override a Risk BLOCK/DENY.');

// Shield may only constrain.
$shielded = $feedback->applyShield($gate, new ShieldRiskEvidence('shield-1', 'trace-4', 'corr-4', 'cause-4', $at, false, true, ['UNSAFE_ARTIFACT']));
ensure4($shielded->directive === RiskExecutionDirective::DENY, 'Blocking Shield evidence must DENY.');

// Enforcement receipt proves the exact authority handed to Command Bus.
$factory = new RiskEnforcementReceiptFactory();
$receipt = $factory->make($gate, $at);
ensure4($receipt->companyId === 42, 'Receipt must retain tenant identity.');
ensure4($receipt->directive === RiskExecutionDirective::HOLD_FOR_ASSURANCE, 'Receipt must retain gate directive.');
ensure4($receipt->mayDispatch === false, 'Non-dispatchable gate must produce non-dispatchable receipt.');
ensure4(count($receipt->circuits) === 1 && $receipt->circuits[0]['version'] === 3, 'Receipt must pin circuit state/version.');
$receiptStore = new MemoryReceiptStore();
$receiptStore->persist($receipt);
ensure4(isset($receiptStore->receipts[$receipt->receiptId]), 'Enforcement receipt must be persistable.');

// Signal outbox is durable/idempotent and delivery is acknowledgement-based.
$outbox = new MemorySignalOutbox();
$publisher = new MemorySignalPublisher();
$dispatcher = new RiskSignalDispatcher($outbox, $publisher);
$event = RiskSignalEvent::forAssessment($assessment, RiskSignalType::RISK_ASSESSED);
$outbox->stage($event);
$outbox->stage($event);
ensure4(count($outbox->events) === 1, 'Signal event identity must support idempotent staging.');
$publisher->available = false;
ensure4($dispatcher->dispatchPending() === 0, 'Unavailable Signal publisher must leave outbox pending.');
ensure4(count($outbox->pending()) === 1, 'Unacknowledged event must remain pending.');
$publisher->available = true;
ensure4($dispatcher->dispatchPending() === 1, 'Available publisher must deliver pending Signal event.');
ensure4(count($outbox->pending()) === 0, 'Acknowledged event must leave pending set.');

// Manifest/migration requirements for production integration evidence.
$root = dirname(__DIR__, 2);
$manifest = json_decode(file_get_contents($root . '/extension.manifest.json'), true, 64, JSON_THROW_ON_ERROR);
ensure4(in_array('risk.feedback', $manifest['capabilities'] ?? [], true), 'Pass 4 manifest must advertise risk.feedback.');
ensure4(($manifest['observability']['signal_events'] ?? false) === true, 'Pass 4 must declare production Signal events.');
$owned = $manifest['database']['owned_tables'] ?? [];
foreach (['titan_risk_assessments','titan_risk_circuits','titan_risk_circuit_transitions','titan_risk_signal_outbox','titan_risk_enforcement_receipts'] as $table) {
    ensure4(in_array($table, $owned, true), 'Manifest must declare owned table ' . $table);
}
ensure4(is_file($root . '/database/migrations/2026_08_20_000005_create_risk_integration_evidence_tables.php'), 'Pass 4 integration migration must exist.');

echo "PASS pass4_cross_engine_smoke\n";
