<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\RiskDecisionRouter;
use App\Extensions\TitanRiskEngine\System\Services\RiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\Services\TrustedRiskContextFactory;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;

function ensureGate(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

final class GateActorResolver implements ActorIdentityResolverContract
{
    public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity
    {
        return new ActorIdentity($actorType, 7, true);
    }
}

final class GateRecentActivity implements RecentActivityProviderContract
{
    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array { return []; }
    public function record(RiskAssessment $assessment): void {}
}

final class AllowRiskManager implements RiskManagerContract
{
    public function health(): array { return ['engine'=>'titan-risk-engine','status'=>'operational','version'=>'0.4.0','capabilities'=>['risk.assess','risk.gate','risk.aggregate','risk.velocity','risk.circuit']]; }
    public function assess(RiskContext $context): RiskAssessment
    {
        return new RiskAssessment($context, 10.0, RiskLevel::MINIMAL, RiskDecision::ALLOW, [], 'baseline-v1', new DateTimeImmutable('2026-08-20T07:00:00+00:00'));
    }
}

final class FixedCircuitService implements RiskCircuitContract
{
    public function __construct(private RiskCircuitState $state) {}
    public function status(RiskCircuitKey $key, DateTimeImmutable $asOf): RiskCircuitSnapshot { return new RiskCircuitSnapshot($key, $this->state, 2, [], 'circuit-v1', $asOf); }
    public function evaluate(RiskCircuitKey $key, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot { return $this->status($key, $evidence->occurredAt); }
    public function recordProbe(RiskCircuitKey $key, bool $successful, bool $supervised, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot { return $this->status($key, $evidence->occurredAt); }
}

$factory = new TrustedRiskContextFactory(new GateActorResolver(), new GateRecentActivity(), new RiskMetadataSanitizer(), 10);
$input = new RiskContextInput(42, 'trace', 'corr', 'cause', 'invoice.send', 'send', 'user', 7);

$openGate = new RiskGate($factory, new AllowRiskManager(), new RiskDecisionRouter(), new FixedCircuitService(RiskCircuitState::OPEN));
$open = $openGate->evaluate($input);
ensureGate($open->directive === RiskExecutionDirective::DENY, 'OPEN circuit must override ALLOW to DENY.');
ensureGate(!$open->mayDispatchToExecutor(), 'OPEN circuit must prevent executor dispatch.');
ensureGate(count($open->circuits) === 2, 'RiskGate must evaluate tenant and tenant+capability circuits.');

$halfGate = new RiskGate($factory, new AllowRiskManager(), new RiskDecisionRouter(), new FixedCircuitService(RiskCircuitState::HALF_OPEN));
$half = $halfGate->evaluate($input);
ensureGate($half->directive === RiskExecutionDirective::HOLD_FOR_ASSURANCE, 'HALF_OPEN circuit must hold normal action for assurance.');
ensureGate(!$half->mayDispatchToExecutor(), 'HALF_OPEN circuit must not dispatch normal actions.');

$closedGate = new RiskGate($factory, new AllowRiskManager(), new RiskDecisionRouter(), new FixedCircuitService(RiskCircuitState::CLOSED));
$closed = $closedGate->evaluate($input);
ensureGate($closed->directive === RiskExecutionDirective::EXECUTE, 'CLOSED circuits must preserve normal ALLOW routing.');
ensureGate($closed->mayDispatchToExecutor(), 'CLOSED circuits must preserve dispatch permission for ALLOW.');

echo "PASS pass3_gate_circuit_smoke\n";
