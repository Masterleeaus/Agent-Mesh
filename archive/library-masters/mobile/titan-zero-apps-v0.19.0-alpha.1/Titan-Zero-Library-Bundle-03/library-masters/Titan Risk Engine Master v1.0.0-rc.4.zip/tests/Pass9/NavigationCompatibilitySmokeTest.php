<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$provider = (string) file_get_contents($root . '/System/TitanRiskEngineServiceProvider.php');
$adapterPath = $root . '/System/Host/TitanMenuCompatibilityAdapter.php';
$commandPath = $root . '/System/Commands/SyncRiskNavigationCommand.php';
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) $failures[] = $message;
};

$assert(is_file($adapterPath), 'host menu compatibility adapter must exist');
$assert(is_file($commandPath), 'navigation sync command must exist');
$assert(str_contains($provider, 'TitanMenuCompatibilityAdapter'), 'provider must use host menu adapter');
$assert(str_contains($provider, 'syncNavigation'), 'provider must self-heal navigation on boot');
$assert(str_contains($provider, 'SyncRiskNavigationCommand::class'), 'provider must register manual sync command');
$assert(str_contains($provider, 'removeNavigation'), 'provider uninstall must remove host navigation contributions');
$assert(($manifest['navigation']['host_sync'] ?? false) === true, 'manifest must require host navigation sync');
$assert(($manifest['navigation']['user'][0]['route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'user route drift');
$assert(($manifest['navigation']['admin'][0]['route'] ?? null) === 'dashboard.admin.titan.risk.engine.control-centre', 'admin route drift');
$assert(($manifest['navigation']['admin'][0]['parent_route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'Control Centre must be a child of Titan Risk');
$assert(($manifest['navigation']['single_parent'] ?? false) === true, 'manifest must declare single-parent hierarchy');

if ($failures !== []) {
    fwrite(STDERR, "NAVIGATION_COMPATIBILITY_SMOKE: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "NAVIGATION_COMPATIBILITY_SMOKE: PASS\n";
