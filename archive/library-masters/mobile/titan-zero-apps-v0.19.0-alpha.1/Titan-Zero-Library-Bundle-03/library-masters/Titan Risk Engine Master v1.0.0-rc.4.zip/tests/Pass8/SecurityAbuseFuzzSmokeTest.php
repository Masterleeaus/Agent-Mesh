<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\RiskContextFingerprint;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptVerifier;
use App\Extensions\TitanRiskEngine\System\Services\RiskIdempotencyGuard;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskLedgerWriteResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;

function p8(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }
function throws8(callable $fn, string $message): void { try { $fn(); } catch (Throwable) { return; } throw new RuntimeException($message); }

// Non-finite risk inputs must never enter scoring/persistence.
throws8(fn() => new RiskImpactVector(financial: NAN), 'NaN impact must be rejected.');
throws8(fn() => new RiskImpactVector(safety: INF), 'Infinite impact must be rejected.');
throws8(fn() => new RiskOperationalBudget(42, 'bad', INF, RiskLevel::LOW, 0.8, new DateTimeImmutable()), 'Infinite budget must be rejected.');
throws8(fn() => new RiskPolicyOverlay('p', 'v', RiskPolicyScope::TENANT, ['monitoring_threshold_ratio' => NAN], new DateTimeImmutable(), 42), 'NaN policy constraint must be rejected.');

// Hostile/oversized identifiers and lineage must be bounded and control-character free.
throws8(fn() => new RiskContextInput(42, str_repeat('x', 300), 'c', 'k', 'invoice.send', 'send', 'user'), 'Oversized trace id must be rejected.');
throws8(fn() => new RiskContextInput(42, "trace\0evil", 'c', 'k', 'invoice.send', 'send', 'user'), 'Control characters in trace id must be rejected.');
throws8(fn() => new RiskContextInput(42, 't', 'c', 'k', str_repeat('a', 300), 'send', 'user'), 'Oversized capability must be rejected.');
throws8(fn() => new RiskContextInput('-1', 't', 'c', 'k', 'invoice.send', 'send', 'user'), 'Negative numeric-string tenant ids must be rejected.');

// Metadata sanitizer must strip reserved-key aliases, non-finite values and enforce a total byte budget.
$san = new RiskMetadataSanitizer(maxDepth: 4, maxEntries: 100, maxStringLength: 2000, maxTotalBytes: 4096);
$clean = $san->sanitize([
    'Risk Score' => 1,
    'risk-score' => 2,
    'execution.directive' => 'ALLOW',
    'companyId' => 999,
    'ok' => 'value',
    'nan' => NAN,
    'huge' => str_repeat('z', 10000),
]);
p8(!isset($clean['Risk Score']) && !isset($clean['risk-score']) && !isset($clean['execution.directive']) && !isset($clean['companyId']), 'Reserved metadata aliases must be stripped.');
p8(!isset($clean['nan']), 'Non-finite metadata numbers must be stripped.');
p8(strlen(json_encode($clean, JSON_THROW_ON_ERROR)) <= 5000, 'Sanitized metadata must stay within bounded serialized size.');

// Same tenant+idempotency key cannot be replayed for a different semantic request.
final class Ledger8 implements RiskAssessmentLedgerContract {
    public ?RiskAssessment $existing = null;
    public function findByIdempotencyKey(int|string $companyId, string $idempotencyKey): ?RiskAssessment { return $this->existing; }
    public function persist(RiskAssessment $assessment): RiskLedgerWriteResult { return $this->existing ? new RiskLedgerWriteResult($this->existing, false) : new RiskLedgerWriteResult($assessment, true, 1); }
}
final class Recent8 implements RecentActivityProviderContract {
    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array { return []; }
    public function record(RiskAssessment $assessment): void {}
}
$ledger = new Ledger8();
$fingerprint = new RiskContextFingerprint();
$guard = new RiskIdempotencyGuard($fingerprint);
$manager = new RiskManager(new BaselineRiskScorer(), new Recent8(), new RiskMetadataSanitizer(), 10, $ledger, idempotencyGuard: $guard);
$first = new RiskContext(42, 't1', 'c1', 'k1', 'invoice.send', 'send', 'user', 7, resourceType:'invoice', resourceId:99, impact:new RiskImpactVector(financial:10), idempotencyKey:'idem-1');
$ledger->existing = (new BaselineRiskScorer())->assess($first);
$retrySame = new RiskContext(42, 't2', 'c2', 'k2', 'invoice.send', 'send', 'user', 7, resourceType:'invoice', resourceId:99, impact:new RiskImpactVector(financial:10), idempotencyKey:'idem-1');
p8($manager->assess($retrySame) === $ledger->existing, 'Semantically identical retry may reuse canonical assessment.');
$collision = new RiskContext(42, 't3', 'c3', 'k3', 'customer.delete', 'delete', 'user', 7, resourceType:'customer', resourceId:99, impact:new RiskImpactVector(financial:10), idempotencyKey:'idem-1');
throws8(fn() => $manager->assess($collision), 'Idempotency key reuse across semantic requests must fail closed.');

// Enforcement receipt must bind the exact action/resource/actor request and verify tamper evidence.
$assessment = (new BaselineRiskScorer())->assess($first);
$gate = new RiskGateResult($assessment, RiskExecutionDirective::EXECUTE);
$factory = new RiskEnforcementReceiptFactory($fingerprint);
$receipt = $factory->make($gate, new DateTimeImmutable('2026-08-21T00:00:00+00:00'));
$verifier = new RiskEnforcementReceiptVerifier($fingerprint);
p8($verifier->verify($receipt), 'Fresh receipt must verify.');
p8($receipt->action === 'send' && $receipt->resourceType === 'invoice' && (string)$receipt->resourceId === '99', 'Receipt must bind exact action/resource.');
p8($receipt->requestFingerprint === $fingerprint->authorization($first), 'Receipt must pin authorization fingerprint.');
$tampered = new RiskEnforcementReceipt(
    receiptId:$receipt->receiptId, contentDigest:$receipt->contentDigest, companyId:$receipt->companyId,
    traceId:$receipt->traceId, correlationId:$receipt->correlationId, causationId:$receipt->causationId,
    capability:$receipt->capability, action:'delete', actorType:$receipt->actorType, actorId:$receipt->actorId,
    resourceType:$receipt->resourceType, resourceId:$receipt->resourceId, requestFingerprint:$receipt->requestFingerprint,
    directive:$receipt->directive, mayDispatch:$receipt->mayDispatch, riskScore:$receipt->riskScore, riskLevel:$receipt->riskLevel,
    assessmentPolicyVersion:$receipt->assessmentPolicyVersion, circuits:$receipt->circuits, issuedAt:$receipt->issuedAt,
    governanceSource:$receipt->governanceSource, evidenceId:$receipt->evidenceId, effectivePolicyDigest:$receipt->effectivePolicyDigest,
    budgetVersion:$receipt->budgetVersion, budgetUtilizationRatio:$receipt->budgetUtilizationRatio,
);
p8(!$verifier->verify($tampered), 'Tampered receipt action must fail verification.');

// Deterministic metadata fuzz corpus: sanitized output must always JSON encode and stay bounded.
for ($i = 0; $i < 500; $i++) {
    $payload = [
        "key-$i" => str_repeat(chr(65 + ($i % 26)), ($i * 37) % 5000),
        ($i % 3 === 0 ? 'risk score' : "safe_$i") => $i % 7 === 0 ? INF : $i,
        'nested' => ['x' => ['y' => ['z' => ['too_deep' => 'drop']]]],
    ];
    $out = $san->sanitize($payload);
    $encoded = json_encode($out, JSON_THROW_ON_ERROR);
    p8(strlen($encoded) <= 5000, 'Fuzzed metadata escaped byte budget.');
}

echo "PASS Pass8 SecurityAbuseFuzzSmokeTest fuzz_cases=500\n";
