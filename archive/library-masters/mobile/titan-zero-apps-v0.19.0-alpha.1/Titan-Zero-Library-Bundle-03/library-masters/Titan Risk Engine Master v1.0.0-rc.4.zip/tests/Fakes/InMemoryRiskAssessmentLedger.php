<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Fakes;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskLedgerWriteResult;

final class InMemoryRiskAssessmentLedger implements RiskAssessmentLedgerContract
{
    /** @var array<string, RiskAssessment> */
    private array $byIdempotency = [];
    /** @var list<RiskAssessment> */
    private array $all = [];

    public function findByIdempotencyKey(int|string $companyId, string $idempotencyKey): ?RiskAssessment
    {
        return $this->byIdempotency[$this->key($companyId, $idempotencyKey)] ?? null;
    }

    public function persist(RiskAssessment $assessment): RiskLedgerWriteResult
    {
        $key = $assessment->context->idempotencyKey;
        if ($key !== null) {
            $lookup = $this->key($assessment->context->companyId, $key);
            if (isset($this->byIdempotency[$lookup])) {
                return new RiskLedgerWriteResult($this->byIdempotency[$lookup], false, null);
            }
            $this->byIdempotency[$lookup] = $assessment;
        }

        $this->all[] = $assessment;
        return new RiskLedgerWriteResult($assessment, true, count($this->all));
    }

    /** @return list<RiskAssessment> */
    public function all(): array
    {
        return $this->all;
    }

    private function key(int|string $companyId, string $idempotencyKey): string
    {
        return (string) $companyId . '|' . $idempotencyKey;
    }
}
