<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\RiskLedgerRowMapper;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use PHPUnit\Framework\TestCase;

final class RiskLedgerRowMapperTest extends TestCase
{
    public function test_row_contains_queryable_lineage_buckets_and_structured_evidence(): void
    {
        $assessment = (new BaselineRiskScorer())->assess(new RiskContext(
            companyId: 42,
            traceId: '11111111-1111-4111-8111-111111111111',
            correlationId: '22222222-2222-4222-8222-222222222222',
            causationId: '33333333-3333-4333-8333-333333333333',
            capability: 'invoice.send',
            action: 'send',
            actorType: 'user',
            actorId: 7,
            resourceType: 'invoice',
            resourceId: 99,
            impact: new RiskImpactVector(financial: 50),
            metadata: ['source' => 'command-bus'],
            idempotencyKey: 'command-123',
        ));

        $mapper = new RiskLedgerRowMapper();
        $row = $mapper->toRow($assessment);

        self::assertSame(42, $row['company_id']);
        self::assertSame('command-123', $row['idempotency_key']);
        self::assertSame('invoice.send', $row['capability']);
        self::assertSame('invoice', $row['resource_type']);
        self::assertMatchesRegularExpression('/^\\d{4}-\\d{2}-\\d{2}-\\d{2}$/', $row['hour_bucket']);
        self::assertMatchesRegularExpression('/^\\d{4}-\\d{2}-\\d{2}$/', $row['day_bucket']);
        self::assertNotSame('[]', $row['reason_codes']);
        self::assertSame($assessment->toArray(), $mapper->fromPayload($row['payload'])->toArray());
    }
}
