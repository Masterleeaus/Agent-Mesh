<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function p7cc(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

$classifier = $root . '/System/Services/RiskDatabaseErrorClassifier.php';
$runner = $root . '/System/Services/LaravelRiskTransactionRunner.php';
p7cc(is_file($classifier), 'Database error classifier must exist.');
p7cc(is_file($runner), 'Laravel transaction runner must exist.');

$ledger = file_get_contents($root . '/System/Services/DatabaseRiskAssessmentLedger.php');
$circuit = file_get_contents($root . '/System/Services/DatabaseRiskCircuitStore.php');
$governance = file_get_contents($root . '/System/Services/RiskPolicyGovernanceService.php');
$provider = file_get_contents($root . '/System/TitanRiskEngineServiceProvider.php');
$migration = file_get_contents($root . '/database/migrations/2026_08_11_000002_upgrade_titan_risk_assessments_to_ledger.php');

p7cc(str_contains($ledger, 'isUniqueViolation'), 'Ledger must classify duplicate-key contention before returning existing idempotent result.');
p7cc(str_contains($circuit, 'transactionAttempts'), 'Circuit transaction retry count must be configurable.');
p7cc(str_contains($circuit, 'lockForUpdate()'), 'Circuit mutation must retain row locking.');
p7cc(str_contains($governance, 'RiskTransactionRunnerContract'), 'Policy governance must use a transaction runner.');
p7cc(str_contains($provider, 'LaravelRiskTransactionRunner'), 'Production provider must bind Laravel transaction runner.');
p7cc(str_contains($migration, 'idempotency_key') && str_contains($migration, 'unique'), 'Ledger migration must retain tenant idempotency uniqueness.');

echo "PASS Pass7 ConcurrencyHardeningSmokeTest\n";
