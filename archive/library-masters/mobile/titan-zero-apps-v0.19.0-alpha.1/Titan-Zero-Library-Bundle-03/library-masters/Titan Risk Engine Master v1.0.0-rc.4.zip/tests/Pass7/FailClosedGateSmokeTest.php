<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\FailClosedRiskGate;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;

function p7fc(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

final class ThrowingGate7 implements RiskGateContract { public function evaluate(RiskContextInput $input): RiskGateResult { throw new RuntimeException('database unavailable secret=abc'); } }
final class Sink7 implements RiskRuntimeEventSinkContract { public array $events=[]; public function record(RiskRuntimeEvent $event): void { $this->events[]=$event; } }
final class ThrowSink7 implements RiskRuntimeEventSinkContract { public function record(RiskRuntimeEvent $event): void { throw new RuntimeException('telemetry down'); } }

$sink = new Sink7();
$gate = new FailClosedRiskGate(new ThrowingGate7(), $sink);
$result = $gate->evaluate(new RiskContextInput(42, 'trace-fc', 'corr-fc', 'cause-fc', 'customer.delete', 'delete', 'user', 999));
p7fc($result->directive === RiskExecutionDirective::DENY, 'Dependency failure must return DENY.');
p7fc($result->assessment->decision === RiskDecision::BLOCK, 'Dependency failure must create BLOCK assessment.');
p7fc($result->assessment->level === RiskLevel::EXTREME && $result->assessment->score === 100.0, 'Dependency failure must be EXTREME/100.');
p7fc($result->assessment->context->actorId === null, 'Fallback context must not trust claimed actor ID.');
p7fc($result->mayDispatchToExecutor() === false, 'Fail-closed result must never dispatch.');
p7fc(($result->assessment->reasons[0]->code ?? null) === 'RISK_ENGINE_DEPENDENCY_UNAVAILABLE', 'Fail-closed result must carry structured reason.');
p7fc(!str_contains(json_encode($result->toArray(), JSON_THROW_ON_ERROR), 'secret=abc'), 'Raw dependency exception details must not leak into result.');
p7fc(count($sink->events) === 1 && $sink->events[0]->outcome === 'FAIL_CLOSED', 'Runtime telemetry must record fail-closed outcome.');
$telemetryFailureResult = (new FailClosedRiskGate(new ThrowingGate7(), new ThrowSink7()))->evaluate(new RiskContextInput(42, 'trace-fc2', 'corr-fc2', 'cause-fc2', 'customer.delete', 'delete', 'user', 999));
p7fc($telemetryFailureResult->directive === RiskExecutionDirective::DENY, 'Telemetry failure must never break fail-closed Risk authority.');

echo "PASS Pass7 FailClosedGateSmokeTest\n";
