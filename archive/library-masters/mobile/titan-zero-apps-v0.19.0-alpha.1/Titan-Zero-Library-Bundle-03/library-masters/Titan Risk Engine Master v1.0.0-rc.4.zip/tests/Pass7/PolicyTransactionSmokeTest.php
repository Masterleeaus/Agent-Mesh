<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix='App\\Extensions\\TitanRiskEngine\\';
    if(!str_starts_with($class,$prefix)) return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';
    if(is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskTransactionRunnerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyGovernanceService;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;

function p7pt(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);}
final class B7 implements RiskBudgetStoreContract {public int $writes=0;public function effectiveFor(int|string $companyId,DateTimeImmutable $asOf):?RiskOperationalBudget{return null;}public function register(RiskOperationalBudget $budget):void{$this->writes++;}public function versionsFor(int|string $companyId):array{return [];}}
final class O7 implements RiskPolicyOverlayStoreContract {public function effectiveFor(int|string $companyId,string $capability,DateTimeImmutable $asOf):array{return [];}public function register(RiskPolicyOverlay $overlay):void{}public function versionsFor(string $policyKey,RiskPolicyScope $scope,int|string|null $companyId,?string $capability):array{return [];}}
final class C7 implements RiskPolicyChangeStoreContract {public int $writes=0;public function persist(RiskPolicyChangeEvidence $evidence):void{$this->writes++;}}
final class T7 implements RiskTransactionRunnerContract {public int $runs=0;public function run(callable $callback):mixed{$this->runs++;return $callback();}}
$b=new B7();$o=new O7();$c=new C7();$t=new T7();
$svc=new RiskPolicyGovernanceService($b,$o,$c,$t);
$at=new DateTimeImmutable('2026-08-21T00:00:00+00:00');
$budget=new RiskOperationalBudget(42,'v2',1000,RiskLevel::MEDIUM,0.8,$at,'GOVERNED');
$e=new RiskPolicyChangeEvidence('chg-1','BUDGET_SCHEDULED',42,'risk-budget','v2','tr','co','ca',$at,'test');
$svc->scheduleBudget($budget,$e);
p7pt($t->runs===1,'Budget+evidence mutation must run in one transaction boundary.');
p7pt($b->writes===1&&$c->writes===1,'Transaction boundary must include both budget and evidence writes.');
echo "PASS Pass7 PolicyTransactionSmokeTest\n";
