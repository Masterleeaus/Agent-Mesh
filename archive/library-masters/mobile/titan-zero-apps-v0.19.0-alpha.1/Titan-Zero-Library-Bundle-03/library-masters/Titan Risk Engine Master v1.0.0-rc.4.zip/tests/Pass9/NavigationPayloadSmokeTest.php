<?php

declare(strict_types=1);

function now(): string { return '2026-08-21 01:30:00'; }

require_once dirname(__DIR__, 2) . '/System/Host/TitanMenuCompatibilityAdapter.php';

use App\Extensions\TitanRiskEngine\System\Host\TitanMenuCompatibilityAdapter;

$definition = [
    'id' => 'titan-risk-engine-control-centre',
    'area' => 'admin',
    'label' => 'Risk Control Centre',
    'route' => 'dashboard.admin.titan.risk.engine.control-centre',
    'permission' => null,
    'icon' => 'tabler-folders',
    'order' => 180,
    'enabled' => true,
];
$columns = ['name','label','title','icon','permission','slug','scope','order','enabled'];
$new = TitanMenuCompatibilityAdapter::buildLegacyPayload($columns, $definition, false);
$existing = TitanMenuCompatibilityAdapter::buildLegacyPayload($columns, $definition, true);

$failures=[];
$check=static function(bool $ok,string $msg) use (&$failures): void { if(!$ok)$failures[]=$msg; };
$check(($new['name'] ?? null) === 'Risk Control Centre', 'name must map label');
$check(($new['label'] ?? null) === 'Risk Control Centre', 'label must map label');
$check(($new['title'] ?? null) === 'Risk Control Centre', 'title must map label');
$check(($new['icon'] ?? null) === 'tabler-folders', 'safe icon must persist');
$check(($new['slug'] ?? null) === 'titan-risk-engine-control-centre', 'stable slug must persist');
$check(($new['scope'] ?? null) === 'admin', 'scope must map area');
$check(($new['order'] ?? null) === 180, 'new menu gets default order');
$check(($new['enabled'] ?? null) === 1, 'new menu gets enabled state');
$check(!array_key_exists('order', $existing), 'existing order must be preserved');
$check(!array_key_exists('enabled', $existing), 'existing enabled state must be preserved');

if($failures){fwrite(STDERR,"NAVIGATION_PAYLOAD_SMOKE: FAIL\n - ".implode("\n - ",$failures)."\n"); exit(1);} 
echo "NAVIGATION_PAYLOAD_SMOKE: PASS\n";
