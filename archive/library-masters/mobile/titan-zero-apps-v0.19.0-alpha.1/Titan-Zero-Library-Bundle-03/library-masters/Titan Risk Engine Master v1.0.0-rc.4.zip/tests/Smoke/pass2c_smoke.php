<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Services\RiskAggregateService;
use App\Extensions\TitanRiskEngine\System\Services\RiskVelocityService;
use App\Extensions\TitanRiskEngine\System\Services\StaticRiskPolicyRegistry;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransition;

function ensure(bool $condition, string $message): void {
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

final class SmokeHistoryReader implements RiskHistoryReaderContract
{
    public function __construct(private RiskExposureSnapshot $snapshot) {}

    public function summarize(RiskHistoryQuery $query): RiskExposureSnapshot
    {
        return new RiskExposureSnapshot(
            companyId: $query->companyId,
            scope: $query->scope,
            from: $query->from,
            to: $query->to,
            assessmentCount: $this->snapshot->assessmentCount,
            scoreSum: $this->snapshot->scoreSum,
            scoreAverage: $this->snapshot->scoreAverage,
            scoreMaximum: $this->snapshot->scoreMaximum,
            highOrExtremeCount: $this->snapshot->highOrExtremeCount,
            extremeCount: $this->snapshot->extremeCount,
            blockedCount: $this->snapshot->blockedCount,
            capability: $query->capability,
            actorType: $query->actorType,
            actorId: $query->actorId,
            resourceType: $query->resourceType,
            resourceId: $query->resourceId,
        );
    }
}

$asOf = new DateTimeImmutable('2026-08-19T00:00:00+00:00');
$query = RiskHistoryQuery::forAggregateWindow(
    companyId: 42,
    scope: RiskAggregateScope::TENANT_CAPABILITY,
    window: RiskAggregateWindow::HOURS_4,
    asOf: $asOf,
    capability: 'invoice.send',
);
ensure($query->from->format(DATE_ATOM) === '2026-08-18T20:00:00+00:00', '4h aggregate window must be exact UTC bounds.');
ensure($query->to->format(DATE_ATOM) === '2026-08-19T00:00:00+00:00', 'Aggregate window end must equal asOf.');

$base = new RiskExposureSnapshot(
    companyId: 42,
    scope: RiskAggregateScope::TENANT,
    from: $query->from,
    to: $query->to,
    assessmentCount: 10,
    scoreSum: 420.0,
    scoreAverage: 42.0,
    scoreMaximum: 79.2,
    highOrExtremeCount: 1,
    extremeCount: 0,
    blockedCount: 0,
);
$aggregate = (new RiskAggregateService(new SmokeHistoryReader($base)))->aggregate($query);
ensure($aggregate->assessmentCount === 10, 'Aggregate service must return durable history snapshot.');
ensure($aggregate->scope === RiskAggregateScope::TENANT_CAPABILITY, 'Aggregate service must preserve query scope.');
ensure($aggregate->policyVersion === 'intelligence-v1', 'Aggregate interpretation must carry intelligence-v1 policy lineage.');

$velocityQuery = RiskHistoryQuery::forVelocityWindow(
    companyId: 42,
    scope: RiskAggregateScope::TENANT,
    window: RiskVelocityWindow::MINUTES_5,
    asOf: $asOf,
);
$criticalSnapshot = new RiskExposureSnapshot(
    companyId: 42,
    scope: RiskAggregateScope::TENANT,
    from: $velocityQuery->from,
    to: $velocityQuery->to,
    assessmentCount: 40,
    scoreSum: 1000.0,
    scoreAverage: 25.0,
    scoreMaximum: 90.0,
    highOrExtremeCount: 3,
    extremeCount: 1,
    blockedCount: 1,
);
$velocity = (new RiskVelocityService(new SmokeHistoryReader($criticalSnapshot)))->assess($velocityQuery);
ensure($velocity->level === RiskVelocityLevel::CRITICAL, 'Severe clustered activity must classify as CRITICAL pressure.');
ensure(!str_contains(strtolower(json_encode($velocity->toArray(), JSON_THROW_ON_ERROR)), 'attack'), 'Velocity output must not infer attack intent.');
ensure($velocityQuery->velocityWindow === RiskVelocityWindow::MINUTES_5, 'Velocity query must retain canonical window.');

$weakened = (new RiskVelocityService(new SmokeHistoryReader($criticalSnapshot), [
    'elevated' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
    'high' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
    'critical' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
]))->assess($velocityQuery);
ensure($weakened->level === RiskVelocityLevel::CRITICAL, 'Runtime configuration must not weaken intelligence-v1 safety thresholds.');


$registry = new StaticRiskPolicyRegistry();
ensure($registry->current('single-action')->version === 'baseline-v1', 'Single-action policy must remain baseline-v1.');
ensure($registry->current('historical-intelligence')->version === 'intelligence-v1', 'Historical intelligence policy must be versioned.');
$transition = new RiskCircuitTransition(
    currentState: RiskCircuitState::OPEN,
    recommendedState: RiskCircuitState::HALF_OPEN,
    reasonCodes: ['RECOVERY_WINDOW_ELAPSED'],
    probeAfter: new DateTimeImmutable('2026-08-19T00:05:00+00:00'),
);
ensure($transition->currentState === RiskCircuitState::OPEN, 'Circuit transition must not mutate current state.');
ensure($transition->recommendedState === RiskCircuitState::HALF_OPEN, 'Circuit contract must support HALF_OPEN recovery recommendation.');

$historyReaderSource = dirname(__DIR__, 2) . '/System/Services/DatabaseRiskHistoryReader.php';
ensure(is_file($historyReaderSource), 'DatabaseRiskHistoryReader must exist for production history queries.');
$historyReaderText = file_get_contents($historyReaderSource);
ensure(str_contains($historyReaderText, 'titan_risk_assessments'), 'History reader must read only the owned Risk ledger by default.');
$migration = dirname(__DIR__, 2) . '/database/migrations/2026_08_19_000003_add_risk_history_query_index.php';
ensure(is_file($migration), 'Pass 2C history index migration must exist.');
ensure(str_contains(file_get_contents($migration), 'titan_risk_actor_cap_time_idx'), 'Actor+capability+time index must be declared.');


$providerText = file_get_contents(dirname(__DIR__, 2) . '/System/TitanRiskEngineServiceProvider.php');
ensure(str_contains($providerText, 'RiskHistoryReaderContract::class'), 'Provider must bind RiskHistoryReaderContract.');
ensure(str_contains($providerText, 'RiskAggregateContract::class'), 'Provider must bind RiskAggregateContract.');
ensure(str_contains($providerText, 'RiskVelocityContract::class'), 'Provider must bind RiskVelocityContract.');
ensure(str_contains($providerText, 'RiskPolicyRegistryContract::class'), 'Provider must bind RiskPolicyRegistryContract.');

$manifest = json_decode(file_get_contents(dirname(__DIR__, 2) . '/extension.manifest.json'), true, 64, JSON_THROW_ON_ERROR);
ensure(in_array('risk.aggregate', $manifest['capabilities'] ?? [], true), 'Manifest must advertise risk.aggregate after implementation.');
ensure(in_array('risk.velocity', $manifest['capabilities'] ?? [], true), 'Manifest must advertise risk.velocity after implementation.');
ensure(in_array('risk.aggregate', $manifest['capabilities'] ?? [], true) && in_array('risk.velocity', $manifest['capabilities'] ?? [], true), 'Historical intelligence capabilities must remain advertised after later passes.');

echo "PASS pass2c_smoke\n";
