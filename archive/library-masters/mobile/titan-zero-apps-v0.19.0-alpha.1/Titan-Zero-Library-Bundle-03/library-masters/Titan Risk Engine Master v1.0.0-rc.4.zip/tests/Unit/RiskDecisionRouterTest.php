<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Services\RiskDecisionRouter;
use PHPUnit\Framework\TestCase;

final class RiskDecisionRouterTest extends TestCase
{
    public function test_block_maps_to_deny_and_cannot_dispatch(): void
    {
        $directive = (new RiskDecisionRouter())->route(RiskDecision::BLOCK);

        self::assertSame(RiskExecutionDirective::DENY, $directive);
        self::assertFalse($directive->mayDispatchToExecutor());
    }

    public function test_assurance_and_approval_are_holds_not_execution(): void
    {
        $router = new RiskDecisionRouter();

        self::assertSame(RiskExecutionDirective::HOLD_FOR_ASSURANCE, $router->route(RiskDecision::REQUIRE_ASSURANCE));
        self::assertSame(RiskExecutionDirective::HOLD_FOR_APPROVAL, $router->route(RiskDecision::REQUIRE_APPROVAL));
        self::assertFalse($router->route(RiskDecision::REQUIRE_ASSURANCE)->mayDispatchToExecutor());
        self::assertFalse($router->route(RiskDecision::REQUIRE_APPROVAL)->mayDispatchToExecutor());
    }
}
