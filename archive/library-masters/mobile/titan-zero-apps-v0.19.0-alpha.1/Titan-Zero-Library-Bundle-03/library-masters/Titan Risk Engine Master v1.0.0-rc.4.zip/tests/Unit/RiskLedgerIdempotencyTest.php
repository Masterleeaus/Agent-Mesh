<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use PHPUnit\Framework\TestCase;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRecentActivityProvider;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRiskAssessmentLedger;

final class RiskLedgerIdempotencyTest extends TestCase
{
    public function test_duplicate_idempotency_key_returns_original_assessment_without_second_history_write(): void
    {
        $recent = new InMemoryRecentActivityProvider();
        $ledger = new InMemoryRiskAssessmentLedger();
        $manager = new RiskManager(
            new BaselineRiskScorer(),
            $recent,
            new RiskMetadataSanitizer(),
            10,
            $ledger,
        );

        $first = $manager->assess($this->context('trace-1', 20));
        $duplicate = $manager->assess($this->context('trace-2', 100));

        self::assertSame($first->toArray(), $duplicate->toArray());
        self::assertCount(1, $ledger->all());
        self::assertCount(1, $recent->recentFor(42, 'user', 7));
    }

    private function context(string $traceId, float $financial): RiskContext
    {
        return new RiskContext(
            companyId: 42,
            traceId: $traceId,
            correlationId: 'corr-1',
            causationId: 'cause-1',
            capability: 'invoice.send',
            action: 'send',
            actorType: 'user',
            actorId: 7,
            impact: new RiskImpactVector(financial: $financial),
            idempotencyKey: 'command-123',
        );
    }
}
