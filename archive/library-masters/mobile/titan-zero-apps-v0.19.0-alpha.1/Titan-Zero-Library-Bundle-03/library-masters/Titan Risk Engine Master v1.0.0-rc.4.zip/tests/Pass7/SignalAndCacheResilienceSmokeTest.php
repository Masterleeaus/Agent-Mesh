<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$manager = file_get_contents($root . '/System/Services/RiskManager.php');
$outbox = file_get_contents($root . '/System/Services/DatabaseRiskSignalOutbox.php');
$cache = file_get_contents($root . '/System/Services/CachedRecentActivityProvider.php');
$circuitStore = file_get_contents($root . '/System/Services/DatabaseRiskCircuitStore.php');
$feedback = file_get_contents($root . '/System/Services/RiskFeedbackCoordinator.php');
$config = require $root . '/config/titan-risk-engine.php';

function p7sc(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

p7sc(str_contains($manager, 'inlineSignalDispatch'), 'RiskManager must expose an explicit inline Signal dispatch control.');
p7sc(str_contains($manager, 'if ($this->inlineSignalDispatch'), 'RiskManager must not dispatch Signals inline unless explicitly enabled.');
p7sc(str_contains($manager, 'SIGNAL_OUTBOX_DEGRADED') && str_contains($manager, 'catch (Throwable'), 'Signal outbox staging failure must degrade softly and be observable.');
p7sc(($config['integration']['inline_signal_dispatch'] ?? null) === false, 'Inline Signal dispatch must default OFF.');
p7sc(($config['integration']['signal_retry_delay_seconds'] ?? 0) >= 30, 'Signal retry delay must be at least 30 seconds.');
p7sc(($config['integration']['signal_max_attempts'] ?? 0) > 0, 'Signal retries must be bounded.');
p7sc(str_contains($outbox, "where('attempts', '<'"), 'Outbox pending query must exclude exhausted attempts.');
p7sc(str_contains($outbox, 'last_attempt_at'), 'Outbox pending query must implement retry delay/backpressure.');
p7sc(str_contains($cache, 'catch (Throwable'), 'Recent-activity cache failures must degrade softly.');
p7sc(str_contains($circuitStore, 'stageCircuitSignal') && str_contains($circuitStore, 'CIRCUIT_SIGNAL_OUTBOX_DEGRADED'), 'Circuit transition persistence must not roll back because Signal outbox staging failed.');
p7sc(str_contains($feedback, 'GOVERNANCE_SIGNAL_OUTBOX_DEGRADED') && str_contains($feedback, 'catch (Throwable'), 'Governance feedback must not be invalidated by Signal delivery degradation.');

echo "PASS Pass7 SignalAndCacheResilienceSmokeTest\n";
