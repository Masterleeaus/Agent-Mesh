<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Architecture;

use PHPUnit\Framework\TestCase;

final class HistoryReaderBoundaryTest extends TestCase
{
    public function test_history_reader_only_reads_owned_risk_table(): void
    {
        $source = file_get_contents(dirname(__DIR__, 2) . '/System/Services/DatabaseRiskHistoryReader.php');
        self::assertIsString($source);
        self::assertStringContainsString("titan_risk_assessments", $source);
        self::assertStringNotContainsString('App\\Extensions\\TitanCommandBus', $source);
        self::assertStringNotContainsString('App\\Extensions\\TitanModelCouncil', $source);
    }
}
