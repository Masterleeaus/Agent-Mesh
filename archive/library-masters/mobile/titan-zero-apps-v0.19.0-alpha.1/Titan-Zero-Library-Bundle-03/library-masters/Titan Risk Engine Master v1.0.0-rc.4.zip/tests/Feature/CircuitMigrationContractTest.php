<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Feature;

use PHPUnit\Framework\TestCase;

final class CircuitMigrationContractTest extends TestCase
{
    public function test_circuit_schema_is_tenant_scoped_versioned_and_evidenced(): void
    {
        $path = dirname(__DIR__, 2) . '/database/migrations/2026_08_20_000004_create_titan_risk_circuits.php';
        $source = (string) file_get_contents($path);

        self::assertStringContainsString("Schema::create('titan_risk_circuits'", $source);
        self::assertStringContainsString("Schema::create('titan_risk_circuit_transitions'", $source);
        self::assertStringContainsString("'company_id', 'scope', 'capability_key'", $source);
        self::assertStringContainsString("\$table->unsignedBigInteger('version')", $source);
        self::assertStringContainsString("\$table->string('trace_id'", $source);
        self::assertStringContainsString("\$table->string('correlation_id'", $source);
        self::assertStringContainsString("\$table->string('causation_id'", $source);
        self::assertStringNotContainsString('dropIfExists', $source);
    }
}
