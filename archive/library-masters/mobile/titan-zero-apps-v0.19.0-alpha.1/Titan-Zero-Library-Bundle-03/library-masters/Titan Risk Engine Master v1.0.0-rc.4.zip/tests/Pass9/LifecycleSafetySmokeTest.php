<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function p9l(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);
$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$provider = (string) file_get_contents($root . '/System/TitanRiskEngineServiceProvider.php');

p9l(($installer['uninstall']['preserve_data'] ?? null) === true, 'Installer uninstall policy must preserve Risk data.');
p9l(($manifest['data']['default_uninstall_policy'] ?? null) === 'retain', 'Canonical uninstall policy must retain Risk data.');
p9l(str_contains($provider, "File::delete(config_path('titan-risk-engine.php'))"), 'Uninstall must remove only published Risk configuration.');
p9l(!str_contains($provider, 'dropIfExists') && !str_contains($provider, 'Schema::drop'), 'Provider uninstall must never drop Risk-owned tables.');
p9l(($manifest['lifecycle']['upgrade_strategy'] ?? null) === 'forward-only migrations', 'Upgrade strategy must remain forward-only.');
p9l(($manifest['database']['interrupted_migration_recovery'] ?? null) === false, 'Release candidate must not overclaim automatic interrupted-DDL recovery.');
p9l(($manifest['database']['owned_tables'] ?? []) !== [], 'Retained durable ownership must be explicit.');

echo "PASS Pass9 LifecycleSafetySmokeTest\n";
