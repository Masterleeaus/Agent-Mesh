<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\Services\RiskVelocityService;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRiskHistoryReader;

final class RiskVelocityServiceTest extends TestCase
{
    public function test_severe_cluster_is_critical_pressure_without_attack_inference(): void
    {
        $query = RiskHistoryQuery::forVelocityWindow(42, RiskAggregateScope::TENANT, RiskVelocityWindow::MINUTES_5, new DateTimeImmutable('2026-08-19T00:00:00+00:00'));
        $snapshot = new RiskExposureSnapshot(42, RiskAggregateScope::TENANT, $query->from, $query->to, 40, 1000, 25, 90, 3, 1, 1);

        $result = (new RiskVelocityService(new InMemoryRiskHistoryReader($snapshot)))->assess($query);

        self::assertSame(RiskVelocityLevel::CRITICAL, $result->level);
        self::assertStringNotContainsString('attack', strtolower(json_encode($result->toArray(), JSON_THROW_ON_ERROR)));
    }
    public function test_runtime_thresholds_cannot_weaken_intelligence_v1_floor(): void
    {
        $query = RiskHistoryQuery::forVelocityWindow(42, RiskAggregateScope::TENANT, RiskVelocityWindow::MINUTES_5, new DateTimeImmutable('2026-08-19T00:00:00+00:00'));
        $snapshot = new RiskExposureSnapshot(42, RiskAggregateScope::TENANT, $query->from, $query->to, 40, 1000, 25, 90, 3, 1, 1);
        $thresholds = [
            'elevated' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
            'high' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
            'critical' => ['actions_per_minute' => 999.0, 'score_points_per_minute' => 99999.0, 'severe_count' => 999],
        ];

        $result = (new RiskVelocityService(new InMemoryRiskHistoryReader($snapshot), $thresholds))->assess($query);

        self::assertSame(RiskVelocityLevel::CRITICAL, $result->level);
    }

}
