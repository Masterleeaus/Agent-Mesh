<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix='App\\Extensions\\TitanRiskEngine\\';
    if(!str_starts_with($class,$prefix)) return;
    $path=dirname(__DIR__,2).'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';
    if(is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\InstrumentedRiskManager;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;

function p7im(bool $ok,string $m):void{if(!$ok)throw new RuntimeException($m);}
final class M7im implements RiskManagerContract { public function health():array{return ['x'=>1];} public function assess(RiskContext $c):RiskAssessment{return new RiskAssessment($c,10,RiskLevel::MINIMAL,RiskDecision::ALLOW,[],'baseline-v1',new DateTimeImmutable());} }
final class S7im implements RiskRuntimeEventSinkContract { public array $events=[]; public function record(RiskRuntimeEvent $event):void{$this->events[]=$event;} }
$s=new S7im();$m=new InstrumentedRiskManager(new M7im(),$s,50.0);
$c=new RiskContext(42,'tr','co','ca','invoice.send','send','user',7);
$r=$m->assess($c);
p7im($r->score===10.0,'Instrumented manager must preserve assessment result.');
p7im(count($s->events)===1&&$s->events[0]->operation==='risk.assess','Instrumented manager must emit risk.assess runtime event.');
p7im($m->health()===['x'=>1],'Instrumented manager must preserve health contract.');
echo "PASS Pass7 InstrumentedRiskManagerSmokeTest\n";
