<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Services\DeterministicRiskPolicyResolver;
use App\Extensions\TitanRiskEngine\System\Services\RiskAggregateService;
use App\Extensions\TitanRiskEngine\System\Services\RiskBudgetEvaluator;
use App\Extensions\TitanRiskEngine\System\Services\RiskDecisionRouter;
use App\Extensions\TitanRiskEngine\System\Services\RiskDirectivePolicy;
use App\Extensions\TitanRiskEngine\System\Services\RiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\Services\TrustedRiskContextFactory;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;

function ensure5g(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }

final class Actor5g implements ActorIdentityResolverContract { public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity { return new ActorIdentity($actorType, $claimedActorId); } }
final class Recent5g implements RecentActivityProviderContract { public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array { return []; } public function record(RiskAssessment $assessment): void {} }
final class Manager5g implements RiskManagerContract {
    public function health(): array { return ['engine'=>'titan-risk-engine','status'=>'operational','version'=>'0.6.0','capabilities'=>['risk.gate']]; }
    public function assess(RiskContext $context): RiskAssessment { return new RiskAssessment($context, 35.0, RiskLevel::LOW, RiskDecision::ALLOW, [], 'baseline-v1', new DateTimeImmutable('2026-08-20T09:00:00+00:00')); }
}
final class BudgetStore5g implements RiskBudgetStoreContract { public function effectiveFor(int|string $companyId, DateTimeImmutable $asOf): ?RiskOperationalBudget { return null; } public function register(RiskOperationalBudget $budget): void {} public function versionsFor(int|string $companyId): array { return []; } }
final class OverlayStore5g implements RiskPolicyOverlayStoreContract { public function effectiveFor(int|string $companyId, string $capability, DateTimeImmutable $asOf): array { return []; } public function register(RiskPolicyOverlay $overlay): void {} public function versionsFor(string $policyKey, RiskPolicyScope $scope, int|string|null $companyId, ?string $capability): array { return []; } }
final class Aggregate5g implements RiskAggregateContract {
    public function aggregate(RiskHistoryQuery $query): RiskExposureSnapshot { return new RiskExposureSnapshot($query->companyId, RiskAggregateScope::TENANT, $query->from, $query->to, 15, 850.0, 56.67, 70.0, 3, 0, 0); }
}

$recent = new Recent5g();
$factory = new TrustedRiskContextFactory(new Actor5g(), $recent, new RiskMetadataSanitizer());
$defaultBudget = new RiskOperationalBudget(0, 'default-v1', 1000.0, RiskLevel::MEDIUM, 0.80, new DateTimeImmutable('2026-01-01T00:00:00+00:00'), 'DEFAULT');
$resolver = new DeterministicRiskPolicyResolver(new BudgetStore5g(), new OverlayStore5g(), $defaultBudget, RiskLevel::EXTREME);
$budgetEvaluator = new RiskBudgetEvaluator(new Aggregate5g(), $resolver, new RiskDirectivePolicy());
$gate = new RiskGate(
    contextFactory: $factory,
    riskManager: new Manager5g(),
    decisionRouter: new RiskDecisionRouter(),
    budgetEvaluator: $budgetEvaluator,
);
$result = $gate->evaluate(new RiskContextInput(42, 'trace-budget', 'corr-budget', 'cause-budget', 'invoice.send', 'send', 'user', 7));
ensure5g($result->directive === RiskExecutionDirective::EXECUTE_MONITORED, 'Budget monitoring threshold must tighten risk.gate.');
ensure5g($result->budgetEvaluation !== null, 'risk.gate must return budget evaluation evidence.');
ensure5g($result->budgetEvaluation->policy->contentDigest !== '', 'Gate budget evaluation must pin effective policy digest.');
$receipt = (new RiskEnforcementReceiptFactory())->make($result, new DateTimeImmutable('2026-08-20T09:01:00+00:00'));
ensure5g($receipt->effectivePolicyDigest === $result->budgetEvaluation->policy->contentDigest, 'Enforcement receipt must pin effective policy digest.');
ensure5g($receipt->budgetVersion === 'default-v1', 'Enforcement receipt must pin effective budget version.');
ensure5g(abs(($receipt->budgetUtilizationRatio ?? 0.0) - 0.85) < 0.0001, 'Enforcement receipt must pin budget utilization.');

echo "PASS pass5_gate_budget_smoke\n";
