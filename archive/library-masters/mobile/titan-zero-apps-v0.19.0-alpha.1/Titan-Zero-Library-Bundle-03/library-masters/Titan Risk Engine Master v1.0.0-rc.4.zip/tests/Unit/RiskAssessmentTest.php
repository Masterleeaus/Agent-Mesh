<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Enums\ConnectivityState;
use App\Extensions\TitanRiskEngine\System\Enums\Reversibility;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use PHPUnit\Framework\TestCase;

final class RiskAssessmentTest extends TestCase
{
    public function test_minimal_reversible_online_action_is_allowed(): void
    {
        $assessment = (new BaselineRiskScorer())->assess($this->context(
            impact: new RiskImpactVector(financial: 5, operational: 5),
        ));

        self::assertSame(RiskLevel::MINIMAL, $assessment->level);
        self::assertSame(RiskDecision::ALLOW, $assessment->decision);
        self::assertTrue($assessment->canProceedWithoutEscalation());
    }

    public function test_99_point_severe_dimension_has_79_2_floor_and_is_high(): void
    {
        $assessment = (new BaselineRiskScorer())->assess($this->context(
            impact: new RiskImpactVector(safety: 99),
        ));

        self::assertSame(79.2, $assessment->score);
        self::assertSame(RiskLevel::HIGH, $assessment->level);
        self::assertSame(RiskDecision::REQUIRE_APPROVAL, $assessment->decision);
    }

    public function test_100_point_severe_dimension_is_extreme_and_blocked(): void
    {
        $assessment = (new BaselineRiskScorer())->assess($this->context(
            impact: new RiskImpactVector(safety: 100),
        ));

        self::assertSame(80.0, $assessment->score);
        self::assertSame(RiskLevel::EXTREME, $assessment->level);
        self::assertSame(RiskDecision::BLOCK, $assessment->decision);
        self::assertTrue($assessment->isBlocked());
    }

    public function test_irreversibility_increases_risk_and_returns_remediation(): void
    {
        $scorer = new BaselineRiskScorer();
        $reversible = $scorer->assess($this->context(
            impact: new RiskImpactVector(financial: 40),
            reversibility: Reversibility::REVERSIBLE,
        ));
        $irreversible = $scorer->assess($this->context(
            impact: new RiskImpactVector(financial: 40),
            reversibility: Reversibility::IRREVERSIBLE,
        ));

        self::assertGreaterThan($reversible->score, $irreversible->score);
        self::assertContains('ADD_REVIEW_OR_REVERSAL_PATH', array_column($irreversible->toArray()['remediation'], 'code'));
    }

    public function test_offline_state_never_increases_execution_authority(): void
    {
        $scorer = new BaselineRiskScorer();
        $online = $scorer->assess($this->context(
            impact: new RiskImpactVector(financial: 20),
            connectivity: ConnectivityState::ONLINE,
        ));
        $offline = $scorer->assess($this->context(
            impact: new RiskImpactVector(financial: 20),
            connectivity: ConnectivityState::OFFLINE,
        ));

        self::assertGreaterThanOrEqual($online->score, $offline->score);
        self::assertSame(RiskDecision::REDUCE_AUTHORITY, $offline->decision);
        self::assertFalse($offline->canProceedWithoutEscalation());
        self::assertContains('RESTORE_CONNECTIVITY', array_column($offline->toArray()['remediation'], 'code'));
    }

    private function context(
        RiskImpactVector $impact,
        Reversibility $reversibility = Reversibility::REVERSIBLE,
        ConnectivityState $connectivity = ConnectivityState::ONLINE,
    ): RiskContext {
        return new RiskContext(
            companyId: 42,
            traceId: 'trace-1',
            correlationId: 'corr-1',
            causationId: 'cause-1',
            capability: 'example.capability',
            action: 'example.action',
            actorType: 'user',
            actorId: 7,
            impact: $impact,
            reversibility: $reversibility,
            connectivity: $connectivity,
        );
    }
}
