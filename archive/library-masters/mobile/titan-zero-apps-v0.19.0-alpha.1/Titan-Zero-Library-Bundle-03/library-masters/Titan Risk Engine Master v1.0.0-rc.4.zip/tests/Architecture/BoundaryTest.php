<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Architecture;

use PHPUnit\Framework\TestCase;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;

final class BoundaryTest extends TestCase
{
    public function test_engine_does_not_import_other_extension_implementation_classes(): void
    {
        $root = dirname(__DIR__, 2) . '/System';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root));

        foreach ($iterator as $file) {
            if (!$file instanceof SplFileInfo || !$file->isFile() || $file->getExtension() !== 'php') {
                continue;
            }

            $contents = (string) file_get_contents($file->getPathname());
            self::assertDoesNotMatchRegularExpression(
                '/use App\\\\Extensions\\\\(?!TitanRiskEngine\\\\)[^;]+\\\\(?:Models|Services|Repositories|Http)\\\\/i',
                $contents,
                sprintf('Cross-extension implementation coupling detected in %s', $file->getPathname()),
            );
        }
    }
}
