<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Feature;

use PHPUnit\Framework\TestCase;

final class LedgerMigrationContractTest extends TestCase
{
    public function test_forward_migration_declares_historical_query_and_idempotency_fields(): void
    {
        $migration = (string) file_get_contents(
            dirname(__DIR__, 2) . '/database/migrations/2026_08_11_000002_upgrade_titan_risk_assessments_to_ledger.php'
        );

        foreach ([
            'causation_id', 'idempotency_key', 'capability', 'actor_id', 'resource_id',
            'score', 'level', 'decision', 'policy_version', 'hour_bucket', 'day_bucket',
            'reason_codes', 'context_snapshot', 'assessed_at',
        ] as $field) {
            self::assertStringContainsString($field, $migration);
        }

        self::assertStringContainsString('titan_risk_tenant_idem_unique', $migration);
        self::assertStringContainsString('company_id', $migration);
    }
}
