<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Feature;

use PHPUnit\Framework\TestCase;

final class HistoryMigrationContractTest extends TestCase
{
    public function test_actor_capability_time_index_is_declared(): void
    {
        $source = file_get_contents(dirname(__DIR__, 2) . '/database/migrations/2026_08_19_000003_add_risk_history_query_index.php');
        self::assertIsString($source);
        self::assertStringContainsString('titan_risk_actor_cap_time_idx', $source);
        self::assertStringContainsString("'capability'", $source);
        self::assertStringContainsString("'assessed_at'", $source);
    }
}
