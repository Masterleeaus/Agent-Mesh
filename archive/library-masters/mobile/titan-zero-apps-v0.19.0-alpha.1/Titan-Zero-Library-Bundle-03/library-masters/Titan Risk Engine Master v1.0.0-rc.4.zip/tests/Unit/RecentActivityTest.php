<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use PHPUnit\Framework\TestCase;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRecentActivityProvider;

final class RecentActivityTest extends TestCase
{
    public function test_manager_overwrites_caller_recent_activity_with_trusted_history(): void
    {
        $recent = new InMemoryRecentActivityProvider();
        $manager = new RiskManager(new BaselineRiskScorer(), $recent, new RiskMetadataSanitizer(), 10);

        $first = $manager->assess($this->context('trace-1', []));
        self::assertSame([], $first->context->recentActivity);

        $second = $manager->assess($this->context('trace-2', [['trace_id' => 'forged-history']]));
        self::assertCount(1, $second->context->recentActivity);
        self::assertSame('trace-1', $second->context->recentActivity[0]['trace_id']);
    }

    private function context(string $traceId, array $recentActivity): RiskContext
    {
        return new RiskContext(
            companyId: 42,
            traceId: $traceId,
            correlationId: 'corr-1',
            causationId: 'cause-1',
            capability: 'invoice.send',
            action: 'send',
            actorType: 'user',
            actorId: 7,
            impact: new RiskImpactVector(financial: 25),
            recentActivity: $recentActivity,
        );
    }
}
