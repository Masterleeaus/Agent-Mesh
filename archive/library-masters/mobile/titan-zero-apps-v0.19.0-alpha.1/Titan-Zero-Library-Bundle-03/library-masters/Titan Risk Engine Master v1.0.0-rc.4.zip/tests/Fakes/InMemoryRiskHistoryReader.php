<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Fakes;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;

final class InMemoryRiskHistoryReader implements RiskHistoryReaderContract
{
    public function __construct(private RiskExposureSnapshot $snapshot) {}

    public function summarize(RiskHistoryQuery $query): RiskExposureSnapshot
    {
        return new RiskExposureSnapshot(
            companyId: $query->companyId,
            scope: $query->scope,
            from: $query->from,
            to: $query->to,
            assessmentCount: $this->snapshot->assessmentCount,
            scoreSum: $this->snapshot->scoreSum,
            scoreAverage: $this->snapshot->scoreAverage,
            scoreMaximum: $this->snapshot->scoreMaximum,
            highOrExtremeCount: $this->snapshot->highOrExtremeCount,
            extremeCount: $this->snapshot->extremeCount,
            blockedCount: $this->snapshot->blockedCount,
            capability: $query->capability,
            actorType: $query->actorType,
            actorId: $query->actorId,
            resourceType: $query->resourceType,
            resourceId: $query->resourceId,
        );
    }
}
