<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = substr($class, strlen($prefix));
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Services\DeterministicRiskPolicyResolver;
use App\Extensions\TitanRiskEngine\System\Services\RiskBudgetEvaluator;
use App\Extensions\TitanRiskEngine\System\Services\RiskDirectivePolicy;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;



// Governance service records immutable prospective changes and rollback as a new version.
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyGovernanceService;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;

final class MemoryChangeStore5 implements RiskPolicyChangeStoreContract
{
    /** @var list<RiskPolicyChangeEvidence> */ public array $changes = [];
    public function persist(RiskPolicyChangeEvidence $evidence): void { $this->changes[] = $evidence; }
}

function ensure5(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}

final class MemoryBudgetStore5 implements RiskBudgetStoreContract
{
    /** @var list<RiskOperationalBudget> */
    public array $budgets = [];
    public function effectiveFor(int|string $companyId, DateTimeImmutable $asOf): ?RiskOperationalBudget {
        $matches = array_values(array_filter($this->budgets, fn ($b) => (string) $b->companyId === (string) $companyId && $b->effectiveAt <= $asOf));
        usort($matches, fn ($a, $b) => $a->effectiveAt <=> $b->effectiveAt);
        return $matches === [] ? null : $matches[count($matches)-1];
    }
    public function register(RiskOperationalBudget $budget): void { $this->budgets[] = $budget; }
    public function versionsFor(int|string $companyId): array { return array_values(array_filter($this->budgets, fn ($b) => (string) $b->companyId === (string) $companyId)); }
}

final class MemoryOverlayStore5 implements RiskPolicyOverlayStoreContract
{
    /** @var list<RiskPolicyOverlay> */
    public array $overlays = [];
    public function effectiveFor(int|string $companyId, string $capability, DateTimeImmutable $asOf): array {
        return array_values(array_filter($this->overlays, function ($o) use ($companyId, $capability, $asOf) {
            if ($o->effectiveAt > $asOf) return false;
            return match ($o->scope) {
                RiskPolicyScope::GLOBAL => true,
                RiskPolicyScope::TENANT => (string) $o->companyId === (string) $companyId,
                RiskPolicyScope::CAPABILITY => $o->capability === $capability,
                RiskPolicyScope::TENANT_CAPABILITY => (string) $o->companyId === (string) $companyId && $o->capability === $capability,
            };
        }));
    }
    public function register(RiskPolicyOverlay $overlay): void { $this->overlays[] = $overlay; }
    public function versionsFor(string $policyKey, RiskPolicyScope $scope, int|string|null $companyId, ?string $capability): array {
        return array_values(array_filter($this->overlays, fn ($o) => $o->policyKey === $policyKey && $o->scope === $scope && (string) $o->companyId === (string) $companyId && $o->capability === $capability));
    }
}

final class FixedAggregate5 implements RiskAggregateContract
{
    public function __construct(private float $scoreSum) {}
    public function aggregate(RiskHistoryQuery $query): RiskExposureSnapshot {
        return new RiskExposureSnapshot($query->companyId, $query->scope, $query->from, $query->to, 10, $this->scoreSum, $this->scoreSum / 10, 70, 2, 0, 0);
    }
}

$at = new DateTimeImmutable('2026-08-20T09:00:00+00:00');
$budgets = new MemoryBudgetStore5();
$overlays = new MemoryOverlayStore5();
$defaultBudget = new RiskOperationalBudget(0, 'default-v1', 1000.0, RiskLevel::MEDIUM, 0.80, new DateTimeImmutable('2026-01-01T00:00:00+00:00'), 'DEFAULT');
$resolver = new DeterministicRiskPolicyResolver($budgets, $overlays, $defaultBudget, RiskLevel::EXTREME);

// Default policy is deterministic and contains the non-purchasable hard block ceiling.
$policy = $resolver->resolve(42, 'invoice.send', $at);
ensure5($policy->maxDailyRiskExposure === 1000.0, 'Default daily budget must resolve deterministically.');
ensure5($policy->maxAutonomousSingleActionLevel === RiskLevel::MEDIUM, 'Default autonomous single-action ceiling must be MEDIUM.');
ensure5($policy->hardBlockLevel === RiskLevel::EXTREME, 'Hard block ceiling must default to EXTREME.');

// A weaker overlay is ignored; a stricter overlay is applied.
$overlays->register(new RiskPolicyOverlay('operational-governance', 'weak-v1', RiskPolicyScope::TENANT, ['max_daily_risk_exposure' => 2000.0, 'max_autonomous_single_action_level' => 'HIGH', 'monitoring_threshold_ratio' => 0.95], $at->modify('-1 minute'), 42));
$weakResolved = $resolver->resolve(42, 'invoice.send', $at);
ensure5($weakResolved->maxDailyRiskExposure === 1000.0, 'Tenant overlay must not raise daily exposure limit.');
ensure5($weakResolved->maxAutonomousSingleActionLevel === RiskLevel::MEDIUM, 'Tenant overlay must not raise autonomous action level.');
ensure5(abs($weakResolved->monitoringThresholdRatio - 0.80) < 0.0001, 'Tenant overlay must not delay monitoring.');

$overlays->register(new RiskPolicyOverlay('operational-governance', 'strict-v2', RiskPolicyScope::TENANT_CAPABILITY, ['max_daily_risk_exposure' => 700.0, 'max_autonomous_single_action_level' => 'LOW', 'monitoring_threshold_ratio' => 0.70, 'hard_block_level' => 'HIGH'], $at, 42, 'invoice.send'));
$strict = $resolver->resolve(42, 'invoice.send', $at);
ensure5($strict->maxDailyRiskExposure === 700.0, 'Stricter daily exposure override must apply.');
ensure5($strict->maxAutonomousSingleActionLevel === RiskLevel::LOW, 'Stricter action ceiling must apply.');
ensure5($strict->hardBlockLevel === RiskLevel::HIGH, 'Hard ceiling may be tightened.');

// Prospective immutable tenant budget versions activate only at their effective time.
$budgets->register(new RiskOperationalBudget(42, 'budget-v1', 900.0, RiskLevel::MEDIUM, 0.75, $at->modify('+1 hour'), 'GOVERNED'));
$before = $resolver->resolve(42, 'customer.update', $at);
$after = $resolver->resolve(42, 'customer.update', $at->modify('+2 hours'));
ensure5($before->maxDailyRiskExposure === 1000.0, 'Future budget must not activate early.');
ensure5($after->maxDailyRiskExposure === 900.0, 'Scheduled budget must activate prospectively.');
ensure5(in_array('budget:budget-v1', $after->appliedVersions, true), 'Effective policy must expose budget lineage.');

// Budget evaluation tightens authority without changing intrinsic assessment score/level.
$context = new RiskContext(42, 'trace-5', 'corr-5', 'cause-5', 'customer.update', 'update', 'user', 7);
$assessment = new RiskAssessment($context, 52.0, RiskLevel::MEDIUM, RiskDecision::REQUIRE_ASSURANCE, [], 'baseline-v1', $at);
$evaluator = new RiskBudgetEvaluator(new FixedAggregate5(850.0), $resolver, new RiskDirectivePolicy());
$evaluation = $evaluator->evaluate($assessment, RiskExecutionDirective::EXECUTE, $at);
ensure5($evaluation->directive === RiskExecutionDirective::EXECUTE_MONITORED, 'Crossing monitoring threshold must tighten EXECUTE to EXECUTE_MONITORED.');
ensure5($assessment->score === 52.0 && $assessment->level === RiskLevel::MEDIUM, 'Budget governance must not rewrite intrinsic risk.');

$overBudget = (new RiskBudgetEvaluator(new FixedAggregate5(1200.0), $resolver, new RiskDirectivePolicy()))->evaluate($assessment, RiskExecutionDirective::EXECUTE, $at);
ensure5($overBudget->directive === RiskExecutionDirective::HOLD_FOR_APPROVAL, 'Daily exposure over budget must require approval.');

$highAssessment = new RiskAssessment($context, 75.0, RiskLevel::HIGH, RiskDecision::REQUIRE_APPROVAL, [], 'baseline-v1', $at);
$singleLimit = (new RiskBudgetEvaluator(new FixedAggregate5(100.0), $resolver, new RiskDirectivePolicy()))->evaluate($highAssessment, RiskExecutionDirective::EXECUTE, $at);
ensure5($singleLimit->directive === RiskExecutionDirective::HOLD_FOR_APPROVAL, 'Single-action level over autonomous ceiling must require approval.');

$extremeAssessment = new RiskAssessment($context, 90.0, RiskLevel::EXTREME, RiskDecision::BLOCK, [], 'baseline-v1', $at);
$hard = (new RiskBudgetEvaluator(new FixedAggregate5(100.0), $resolver, new RiskDirectivePolicy()))->evaluate($extremeAssessment, RiskExecutionDirective::EXECUTE, $at);
ensure5($hard->directive === RiskExecutionDirective::DENY, 'Hard block ceiling must DENY regardless of tenant budget.');


$changes = new MemoryChangeStore5();
$governance = new RiskPolicyGovernanceService($budgets, $overlays, $changes);
$futureBudget = new RiskOperationalBudget(42, 'budget-v2', 800.0, RiskLevel::LOW, 0.70, $at->modify('+3 hours'), 'GOVERNED', 'budget-v1');
$change = new RiskPolicyChangeEvidence('chg-budget-v2', 'BUDGET_SCHEDULED', 42, 'operational-budget', 'budget-v2', 'trace-policy', 'corr-policy', 'cause-policy', $at, 'tighten autonomous exposure');
$governance->scheduleBudget($futureBudget, $change);
ensure5(count($changes->changes) === 1, 'Scheduling budget must append policy-change evidence.');
ensure5($resolver->resolve(42, 'customer.update', $at->modify('+4 hours'))->maxDailyRiskExposure === 800.0, 'Scheduled governed budget must become effective prospectively.');

$rollbackEvidence = new RiskPolicyChangeEvidence('chg-budget-rb', 'BUDGET_ROLLBACK_SCHEDULED', 42, 'operational-budget', 'budget-v3-rollback', 'trace-policy-rb', 'corr-policy-rb', 'cause-policy-rb', $at->modify('+4 hours'), 'rollback to budget-v1');
$rolled = $governance->rollbackBudget(42, 'budget-v1', 'budget-v3-rollback', $at->modify('+5 hours'), $rollbackEvidence);
ensure5($rolled->source === 'ROLLBACK' && $rolled->supersedesVersion === 'budget-v2', 'Rollback must create a new immutable budget version rather than mutate history.');
ensure5($resolver->resolve(42, 'customer.update', $at->modify('+6 hours'))->maxDailyRiskExposure === 900.0, 'Rollback version must restore the target budget prospectively.');
ensure5(count($changes->changes) === 2, 'Rollback must append independent policy-change evidence.');

$temporaryOverlay = new RiskPolicyOverlay('operational-governance', 'temporary-v3', RiskPolicyScope::TENANT_CAPABILITY, ['max_daily_risk_exposure' => 500.0, 'max_autonomous_single_action_level' => 'MINIMAL', 'monitoring_threshold_ratio' => 0.60, 'hard_block_level' => 'MEDIUM'], $at->modify('+7 hours'), 42, 'invoice.send', 'strict-v2');
$governance->scheduleOverlay($temporaryOverlay, new RiskPolicyChangeEvidence('chg-overlay-v3', 'POLICY_SCHEDULED', 42, 'operational-governance', 'temporary-v3', 'trace-overlay', 'corr-overlay', 'cause-overlay', $at->modify('+6 hours'), 'temporary incident policy'));
ensure5($resolver->resolve(42, 'invoice.send', $at->modify('+7 hours 30 minutes'))->hardBlockLevel === RiskLevel::MEDIUM, 'Scheduled stricter overlay must activate prospectively.');
$overlayRollback = $governance->rollbackOverlay('operational-governance', RiskPolicyScope::TENANT_CAPABILITY, 42, 'invoice.send', 'strict-v2', 'rollback-v4', $at->modify('+8 hours'), new RiskPolicyChangeEvidence('chg-overlay-rb', 'POLICY_ROLLBACK_SCHEDULED', 42, 'operational-governance', 'rollback-v4', 'trace-overlay-rb', 'corr-overlay-rb', 'cause-overlay-rb', $at->modify('+7 hours 45 minutes'), 'restore pre-incident policy'));
ensure5($overlayRollback->supersedesVersion === 'temporary-v3', 'Policy rollback must supersede the current binding version without mutating it.');
ensure5($resolver->resolve(42, 'invoice.send', $at->modify('+9 hours'))->hardBlockLevel === RiskLevel::HIGH, 'Policy rollback must restore target constraints prospectively.');
ensure5(count($changes->changes) === 4, 'Policy schedule and rollback must append evidence records.');

// Release contract/migration must expose the governed policy tables once production wiring lands.
$root = dirname(__DIR__, 2);
$manifest = json_decode(file_get_contents($root . '/extension.manifest.json'), true, 64, JSON_THROW_ON_ERROR);
foreach (['titan_risk_policy_overlays','titan_risk_budget_versions','titan_risk_policy_changes'] as $table) {
    ensure5(in_array($table, $manifest['database']['owned_tables'] ?? [], true), 'Manifest must declare owned table ' . $table);
}
ensure5(is_file($root . '/database/migrations/2026_08_20_000006_create_risk_policy_budget_tables.php'), 'Pass 5 policy/budget migration must exist.');

echo "PASS pass5_policy_budget_smoke\n";
