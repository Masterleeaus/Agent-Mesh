<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/System/Services/AuthenticatedTenantResolver.php';

use App\Extensions\TitanRiskEngine\System\Services\AuthenticatedTenantResolver;

$r = new AuthenticatedTenantResolver();
$cases = [
    [null, null],
    [(object)['company_id' => 17, 'company_id' => 99], 17],
    [(object)['company_id' => null, 'company_id' => 42], 42],
    [(object)['company_id' => '', 'company_id' => '84'], '84'],
    [(object)['company_id' => 0, 'company_id' => null], null],
];
foreach ($cases as [$user, $expected]) {
    $actual = $r->resolve($user);
    if ($actual !== $expected) {
        fwrite(STDERR, 'TENANT_RESOLVER: FAIL expected ' . var_export($expected, true) . ' got ' . var_export($actual, true) . "\n");
        exit(1);
    }
}
echo "TENANT_RESOLVER: PASS\n";
