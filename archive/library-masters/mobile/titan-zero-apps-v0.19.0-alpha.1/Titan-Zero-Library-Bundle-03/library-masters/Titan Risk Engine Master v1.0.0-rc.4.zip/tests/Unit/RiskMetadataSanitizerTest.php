<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use PHPUnit\Framework\TestCase;
use stdClass;

final class RiskMetadataSanitizerTest extends TestCase
{
    public function test_reserved_and_malformed_metadata_cannot_override_risk_fields(): void
    {
        $sanitized = (new RiskMetadataSanitizer(maxDepth: 3, maxEntries: 10, maxStringLength: 20))->sanitize([
            'risk_score' => 0,
            'decision' => 'ALLOW',
            'company_id' => 999,
            'safe_note' => str_repeat('x', 100),
            'object' => new stdClass(),
            'nested' => ['ok' => true],
        ]);

        self::assertArrayNotHasKey('risk_score', $sanitized);
        self::assertArrayNotHasKey('decision', $sanitized);
        self::assertArrayNotHasKey('company_id', $sanitized);
        self::assertArrayNotHasKey('object', $sanitized);
        self::assertSame(20, strlen($sanitized['safe_note']));
        self::assertTrue($sanitized['nested']['ok']);
    }
}
