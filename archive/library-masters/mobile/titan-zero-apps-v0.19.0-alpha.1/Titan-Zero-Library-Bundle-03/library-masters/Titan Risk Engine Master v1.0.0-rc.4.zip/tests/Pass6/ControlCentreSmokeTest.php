<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) $failures[] = $message;
};
$read = static function (string $path) use ($root): string {
    $full = $root . '/' . $path;
    return is_file($full) ? (string) file_get_contents($full) : '';
};

$required = [
    'System/Contracts/RiskControlCentreContract.php',
    'System/Services/DatabaseRiskControlCentre.php',
    'System/Services/AuthenticatedTenantResolver.php',
    'System/ValueObjects/RiskControlCentreSnapshot.php',
    'System/Http/Controllers/Admin/RiskControlCentreController.php',
    'System/Http/Controllers/Admin/RiskPolicyOperationsController.php',
    'System/Http/Controllers/Admin/RiskSignalOperationsController.php',
    'resources/views/admin/control-centre.blade.php',
    'resources/views/index.blade.php',
    'docs/PASS-6-RISK-CONTROL-CENTRE.md',
];
foreach ($required as $file) $assert(is_file($root . '/' . $file), "missing:$file");

$adminRoutes = $read('routes/admin.php');
foreach (['control-centre', 'policy/budget', 'policy/overlay', 'rollback', 'signals/dispatch'] as $needle) {
    $assert(str_contains($adminRoutes, $needle), "admin-route-missing:$needle");
}

$controller = $read('System/Http/Controllers/Admin/RiskPolicyOperationsController.php');
$assert(!str_contains($controller, "->table("), 'controller-must-not-query-tables-directly');
$assert(str_contains($controller, 'RiskPolicyGovernanceService'), 'controller-must-use-governance-service');

$readModel = $read('System/Services/DatabaseRiskControlCentre.php');
foreach (['limit(', 'titan_risk_assessments', 'titan_risk_circuits', 'titan_risk_signal_outbox', 'titan_risk_enforcement_receipts', 'titan_risk_policy_changes'] as $needle) {
    $assert(str_contains($readModel, $needle), "read-model-missing:$needle");
}
foreach (preg_split('/\R/', $readModel) as $i => $line) {
    if (!str_contains($line, '->get(')) continue;
    $context = implode(' ', array_slice(preg_split('/\R/', $readModel), max(0, $i - 2), 3));
    $assert(str_contains($context, 'limit('), 'read-model-unbounded-get-line:' . ($i + 1));
}


$provider = $read('System/TitanRiskEngineServiceProvider.php');
$assert(str_contains($provider, 'RiskControlCentreContract'), 'provider-missing-control-centre-contract');
$assert(str_contains($provider, 'DatabaseRiskControlCentre'), 'provider-missing-control-centre-service');
$assert(str_contains($provider, 'AuthenticatedTenantResolver'), 'provider-missing-tenant-resolver');

$adminView = $read('resources/views/admin/control-centre.blade.php');
foreach (['24h Exposure', 'Risk Budget', 'Circuits', 'Signal Delivery', 'Enforcement Receipts', 'Policy Operations'] as $needle) {
    $assert(str_contains($adminView, $needle), "admin-view-missing:$needle");
}
$userView = $read('resources/views/index.blade.php');
$assert(str_contains($userView, 'Read-only'), 'user-view-must-be-read-only');
$assert(!str_contains($userView, '<form'), 'user-view-must-not-have-mutation-forms');

if ($failures !== []) {
    fwrite(STDERR, "PASS6_CONTROL_CENTRE_SMOKE: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "PASS6_CONTROL_CENTRE_SMOKE: PASS\n";
