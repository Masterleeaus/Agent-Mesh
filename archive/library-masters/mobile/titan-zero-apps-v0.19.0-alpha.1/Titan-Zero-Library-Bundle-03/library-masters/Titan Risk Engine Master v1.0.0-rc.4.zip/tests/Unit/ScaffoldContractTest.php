<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyRegistryContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Services\RiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use PHPUnit\Framework\TestCase;

final class ScaffoldContractTest extends TestCase
{
    public function test_public_risk_contracts_are_implemented(): void
    {
        self::assertContains(RiskManagerContract::class, class_implements(RiskManager::class));
        self::assertContains(RiskGateContract::class, class_implements(RiskGate::class));
        self::assertTrue(method_exists(RiskManagerContract::class, 'assess'));
        self::assertTrue(method_exists(RiskGateContract::class, 'evaluate'));
        self::assertTrue(method_exists(RiskAssessmentLedgerContract::class, 'persist'));
        self::assertTrue(method_exists(RiskAssessmentLedgerContract::class, 'findByIdempotencyKey'));
        self::assertTrue(method_exists(RiskAggregateContract::class, 'aggregate'));
        self::assertTrue(method_exists(RiskVelocityContract::class, 'assess'));
        self::assertTrue(method_exists(RiskHistoryReaderContract::class, 'summarize'));
        self::assertTrue(method_exists(RiskPolicyRegistryContract::class, 'current'));
    }
}
