<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Unit;

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\Services\TrustedRiskContextFactory;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use PHPUnit\Framework\TestCase;
use Tests\Extensions\TitanRiskEngine\Fakes\InMemoryRecentActivityProvider;

final class TrustedRiskContextFactoryTest extends TestCase
{
    public function test_factory_uses_resolved_actor_and_sanitized_metadata(): void
    {
        $resolver = new class implements ActorIdentityResolverContract {
            public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity
            {
                return new ActorIdentity('user', 77);
            }
        };

        $factory = new TrustedRiskContextFactory(
            $resolver,
            new InMemoryRecentActivityProvider(),
            new RiskMetadataSanitizer(),
            10,
        );

        $context = $factory->make(new RiskContextInput(
            companyId: 42,
            traceId: 'trace-1',
            correlationId: 'corr-1',
            causationId: 'cause-1',
            capability: 'forge.generate',
            action: 'generate',
            actorType: 'user',
            claimedActorId: 999,
            impact: new RiskImpactVector(operational: 20),
            metadata: ['risk_score' => 0, 'source' => 'forge'],
        ));

        self::assertSame(77, $context->actorId);
        self::assertSame('user', $context->actorType);
        self::assertArrayNotHasKey('risk_score', $context->metadata);
        self::assertSame('forge', $context->metadata['source']);
    }
}
