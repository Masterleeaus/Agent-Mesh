<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\FailClosedRiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;

function p9d(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

final class ExplodingRecentActivity9 implements RecentActivityProviderContract {
    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array { throw new RuntimeException('must not be called while disabled'); }
    public function record(RiskAssessment $assessment): void { throw new RuntimeException('must not record while disabled'); }
}
final class ExplodingGate9 implements RiskGateContract { public function evaluate(RiskContextInput $input): RiskGateResult { throw new RuntimeException('inner gate must not run while disabled'); } }
final class Sink9 implements RiskRuntimeEventSinkContract { public array $events=[]; public function record(RiskRuntimeEvent $event): void { $this->events[]=$event; } }

$manager = new RiskManager(
    scorer: new BaselineRiskScorer(),
    recentActivity: new ExplodingRecentActivity9(),
    metadataSanitizer: new RiskMetadataSanitizer(),
    enabled: false,
);
$health = $manager->health();
p9d(($health['status'] ?? null) === 'DISABLED', 'Disabled health state must use canonical DISABLED status.');
p9d(($health['version'] ?? null) === '1.0.0-rc.3', 'Health must report the release-candidate version.');
$assessment = $manager->assess(new RiskContext(42, 'trace-disabled', 'corr-disabled', 'cause-disabled', 'invoice.send', 'send', 'user', 7));
p9d($assessment->score === 100.0 && $assessment->level === RiskLevel::EXTREME, 'Disabled risk.assess must return EXTREME/100.');
p9d($assessment->decision === RiskDecision::BLOCK, 'Disabled risk.assess must BLOCK.');
p9d($assessment->policyVersion === 'disabled-v1', 'Disabled assessment must carry disabled policy lineage.');
p9d(($assessment->reasons[0]->code ?? null) === 'RISK_ENGINE_DISABLED', 'Disabled assessment must carry structured disabled reason.');

$sink = new Sink9();
$gate = new FailClosedRiskGate(new ExplodingGate9(), $sink, enabled: false);
$result = $gate->evaluate(new RiskContextInput(42, 'trace-disabled-gate', 'corr-disabled-gate', 'cause-disabled-gate', 'invoice.send', 'send', 'user', 7));
p9d($result->directive === RiskExecutionDirective::DENY, 'Disabled risk.gate must DENY.');
p9d($result->assessment->policyVersion === 'disabled-v1', 'Disabled gate result must carry disabled policy lineage.');
p9d(($result->assessment->reasons[0]->code ?? null) === 'RISK_ENGINE_DISABLED', 'Disabled gate must expose structured disabled reason.');
p9d(count($sink->events) === 1 && $sink->events[0]->outcome === 'DISABLED', 'Disabled gate must emit a non-authorizing runtime event.');

echo "PASS Pass9 DisabledModeSmokeTest\n";
