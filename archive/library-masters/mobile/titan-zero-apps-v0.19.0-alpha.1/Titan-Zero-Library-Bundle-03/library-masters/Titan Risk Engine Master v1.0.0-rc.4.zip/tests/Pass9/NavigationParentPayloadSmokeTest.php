<?php

declare(strict_types=1);

function now(): string { return '2026-08-21 02:00:00'; }

require_once dirname(__DIR__, 2) . '/System/Host/TitanMenuCompatibilityAdapter.php';

use App\Extensions\TitanRiskEngine\System\Host\TitanMenuCompatibilityAdapter;

$failures = [];
$check = static function (bool $ok, string $message) use (&$failures): void { if (!$ok) $failures[] = $message; };
$columns = ['id', 'route', 'name', 'parent_id', 'order', 'enabled'];

$parent = [
    'id' => 'titan-risk-engine-root',
    'route' => 'dashboard.user.titan.risk.engine.index',
    'label' => 'Titan Risk',
];
$child = [
    'id' => 'titan-risk-engine-control-centre',
    'route' => 'dashboard.admin.titan.risk.engine.control-centre',
    'label' => 'Risk Control Centre',
    'parent_route' => 'dashboard.user.titan.risk.engine.index',
];

$parentPayload = TitanMenuCompatibilityAdapter::applyLegacyParentReference($columns, $parent, [], null);
$childPayload = TitanMenuCompatibilityAdapter::applyLegacyParentReference($columns, $child, [], 42);

$check(($parentPayload['parent_id'] ?? null) === 0, 'parent row must be forced to top level');
$check(($childPayload['parent_id'] ?? null) === 42, 'child row must reference resolved parent database id');

if ($failures !== []) {
    fwrite(STDERR, "NAVIGATION_PARENT_PAYLOAD_SMOKE: FAIL\n - " . implode("\n - ", $failures) . "\n");
    exit(1);
}

echo "NAVIGATION_PARENT_PAYLOAD_SMOKE: PASS\n";
