<?php

declare(strict_types=1);

namespace Tests\Extensions\TitanRiskEngine\Fakes;

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;

final class InMemoryRecentActivityProvider implements RecentActivityProviderContract
{
    /** @var array<string, list<array<string, scalar|null>>> */
    private array $items = [];

    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array
    {
        return array_values(array_slice($this->items[$this->key($companyId, $actorType, $actorId)] ?? [], -$limit));
    }

    public function record(RiskAssessment $assessment): void
    {
        $context = $assessment->context;
        $key = $this->key($context->companyId, $context->actorType, $context->actorId);
        $this->items[$key][] = [
            'trace_id' => $context->traceId,
            'capability' => $context->capability,
            'action' => $context->action,
            'score' => $assessment->score,
            'level' => $assessment->level->value,
            'decision' => $assessment->decision->value,
            'assessed_at' => $assessment->assessedAt->format(DATE_ATOM),
        ];
        $this->items[$key] = array_values(array_slice($this->items[$key], -10));
    }

    private function key(int|string $companyId, string $actorType, int|string|null $actorId): string
    {
        return implode('|', [(string) $companyId, $actorType, (string) ($actorId ?? 'anonymous')]);
    }
}
