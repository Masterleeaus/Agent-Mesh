<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Services\RiskDecisionRouter;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\Services\TrustedRiskContextFactory;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;

function e4(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }
final class Actor4 implements ActorIdentityResolverContract { public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity { return new ActorIdentity($actorType, 7, true); } }
final class Recent4 implements RecentActivityProviderContract { public function recentFor(int|string $companyId,string $actorType,int|string|null $actorId,int $limit=10): array{return [];} public function record(RiskAssessment $assessment): void{} }
final class Manager4 implements RiskManagerContract {
 public function health(): array{return ['engine'=>'titan-risk-engine','status'=>'operational','version'=>'0.5.0','capabilities'=>['risk.assess','risk.gate','risk.aggregate','risk.velocity','risk.circuit','risk.feedback']];}
 public function assess(RiskContext $context): RiskAssessment{return new RiskAssessment($context,10,RiskLevel::MINIMAL,RiskDecision::ALLOW,[],'baseline-v1',new DateTimeImmutable('2026-08-20T08:00:00+00:00'));}
}
final class Circuit4 implements RiskCircuitContract {
 public function status(RiskCircuitKey $key, DateTimeImmutable $asOf): RiskCircuitSnapshot{return new RiskCircuitSnapshot($key,RiskCircuitState::CLOSED,4,[],'circuit-v1',$asOf);}
 public function evaluate(RiskCircuitKey $key,RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot{return $this->status($key,$evidence->occurredAt);}
 public function recordProbe(RiskCircuitKey $key,bool $successful,bool $supervised,RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot{return $this->status($key,$evidence->occurredAt);}
}
final class Receipt4 implements RiskEnforcementReceiptStoreContract { public array $items=[]; public function persist(RiskEnforcementReceipt $receipt): void{$this->items[$receipt->receiptId]=$receipt;} }

$store=new Receipt4();
$gate=new RiskGate(new TrustedRiskContextFactory(new Actor4(),new Recent4(),new RiskMetadataSanitizer(),10),new Manager4(),new RiskDecisionRouter(),new Circuit4(),new RiskEnforcementReceiptFactory(),$store);
$result=$gate->evaluate(new RiskContextInput(42,'trace-r','corr-r','cause-r','invoice.send','send','user',7));
e4($result->enforcementReceipt!==null,'Provider-grade RiskGate must return an enforcement receipt.');
e4(count($store->items)===1,'RiskGate must persist the enforcement receipt before returning.');
e4($result->enforcementReceipt->mayDispatch===true,'ALLOW receipt must authorize dispatch.');
e4(count($result->enforcementReceipt->circuits)===2,'Receipt must pin both tenant and capability circuit states.');
$payload=$result->toArray();
e4(isset($payload['execution_directive'],$payload['enforcement_receipt']),'Gate serialization must expose execution directive and receipt.');
e4(!isset($payload['directive']),'Gate serialization must not expose obsolete schema key directive.');
echo "PASS pass4_gate_receipt_smoke\n";
