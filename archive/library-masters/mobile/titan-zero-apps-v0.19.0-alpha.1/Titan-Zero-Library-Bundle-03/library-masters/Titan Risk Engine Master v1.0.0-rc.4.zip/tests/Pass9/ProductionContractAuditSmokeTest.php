<?php

declare(strict_types=1);

$root = dirname(__DIR__, 2);
function p9a(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }

$manifest = json_decode((string) file_get_contents($root . '/extension.manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$installer = json_decode((string) file_get_contents($root . '/extension.json'), true, 512, JSON_THROW_ON_ERROR);

p9a(($installer['version'] ?? null) === '1.0.0-rc.3', 'Installer manifest must be final host-ready release candidate version.');
p9a(($manifest['version'] ?? null) === '1.0.0-rc.3', 'Canonical manifest must be final host-ready release candidate version.');
p9a(($manifest['navigation']['user'][0]['route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'User Risk page must be discoverable in host navigation.');
p9a(($manifest['navigation']['admin'][0]['route'] ?? null) === 'dashboard.admin.titan.risk.engine.control-centre', 'Risk Control Centre must be discoverable in admin navigation.');
p9a(($manifest['navigation']['admin'][0]['parent_route'] ?? null) === 'dashboard.user.titan.risk.engine.index', 'Risk Control Centre must be nested beneath the single Titan Risk parent.');
p9a(($manifest['navigation']['single_parent'] ?? false) === true, 'Risk navigation must declare exactly one parent hierarchy.');
p9a(!is_file($root . '/System/Http/Controllers/AdminController.php'), 'Deprecated request-tenant AdminController must be removed.');

$provider = (string) file_get_contents($root . '/System/TitanRiskEngineServiceProvider.php');
p9a(str_contains($provider, "config('titan-risk-engine.enabled', true)"), 'Provider must inject enabled/disabled state into runtime authority.');
p9a(str_contains($provider, 'RiskEnforcementReceiptVerifierContract::class'), 'Receipt verifier contract must remain bound.');
p9a(str_contains($provider, 'RiskEnforcementReceiptVerifier::class'), 'Receipt verifier implementation must remain registered.');

$certify = (string) file_get_contents($root . '/System/Commands/CertifyExtensionCommand.php');
p9a(str_contains($certify, 'app()->make($contract)'), 'Host certification must resolve bindings, not merely check bound().');
p9a(str_contains($certify, 'dashboard.user.titan.risk.engine.index'), 'Host certification must verify user route registration.');
p9a(str_contains($certify, 'dashboard.admin.titan.risk.engine.control-centre'), 'Host certification must verify admin route registration.');
p9a(str_contains($certify, 'RiskEnforcementReceiptVerifierContract::class'), 'Host certification must include receipt verifier binding.');

$owned = array_values($manifest['database']['owned_tables'] ?? []);
sort($owned);
$expected = [
    'titan_risk_assessments','titan_risk_budget_versions','titan_risk_circuits','titan_risk_circuit_transitions',
    'titan_risk_enforcement_receipts','titan_risk_governance_feedback','titan_risk_policy_changes',
    'titan_risk_policy_overlays','titan_risk_signal_outbox',
];
sort($expected);
p9a($owned === $expected, 'Owned-table manifest must exactly match Risk durable ownership.');
p9a(($manifest['database']['interrupted_migration_recovery'] ?? null) === false, 'Manifest must not overclaim automatic interrupted-DDL recovery.');

p9a(is_file($root . '/docs/PASS-9-FINAL-PRODUCTION-HARDENING.md'), 'Pass 9 production hardening evidence doc must ship.');
p9a(is_file($root . '/release/HOST-CERTIFICATION-CHECKLIST.md'), 'Host certification checklist must ship.');
p9a(is_file($root . '/release/HOST-CERTIFICATION-REPORT.example.json'), 'Machine-readable host certification report example must ship.');

echo "PASS Pass9 ProductionContractAuditSmokeTest\n";
