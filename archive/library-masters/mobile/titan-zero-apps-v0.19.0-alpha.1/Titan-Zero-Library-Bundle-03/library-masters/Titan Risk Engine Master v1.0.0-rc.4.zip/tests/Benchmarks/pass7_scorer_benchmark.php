<?php

declare(strict_types=1);

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\Extensions\\TitanRiskEngine\\';
    if (!str_starts_with($class, $prefix)) return;
    $path = dirname(__DIR__, 2) . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($path)) require_once $path;
});

use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;

$scorer = new BaselineRiskScorer();
$durations=[];
for ($i=0; $i<2000; $i++) {
    $ctx = new RiskContext(42, 't'.$i, 'c'.$i, 'z'.$i, 'invoice.send', 'send', 'user', 7, impact: new RiskImpactVector(financial: 50, operational: 30));
    $start=hrtime(true);
    $scorer->assess($ctx);
    $durations[]=(hrtime(true)-$start)/1_000_000;
}
sort($durations);
$p99=$durations[(int) floor((count($durations)-1)*0.99)];
if ($p99 > 5.0) throw new RuntimeException(sprintf('Pure scorer p99 %.4fms exceeds 5ms package benchmark budget.', $p99));
printf("PASS pass7_scorer_benchmark p99=%.4fms iterations=%d\n", $p99, count($durations));
