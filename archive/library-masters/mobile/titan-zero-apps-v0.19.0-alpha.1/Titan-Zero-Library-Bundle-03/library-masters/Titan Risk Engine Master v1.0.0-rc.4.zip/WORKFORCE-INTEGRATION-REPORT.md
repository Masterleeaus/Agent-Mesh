# Workforce Integration Report

Generated: 2026-08-22T08:06:00+10:00

## Result

This package now publishes `workforce-integration.json` and `resources/workforce/workforce-integration.json` as a stable Workforce-facing discovery contract. Titan AI Workforce remains the sole owner of employee identity, organisational roles, hierarchy, teams, responsibilities, assignments, work items and orchestration. This extension retains only its authoritative domain/control-plane data and execution/evidence surfaces.

## Canonical boundary

- New Workforce tenancy context: `company_id`.
- Existing `company_id` references are retained only as legacy package/storage compatibility and are explicitly non-authoritative for the new Workforce contract.
- Installation never grants authority. Availability, authorization, Governance, Risk, Assurance and Autonomy remain independent decisions.
- Missing policy/provider/health/authorization fails closed.
- Provider version/provenance is pinned for executable work.
- No active extension-owned Workforce employee or role definitions were found or introduced.

## Published surfaces

- Capabilities: 7
- Read/evaluate tools: 5
- Governed commands: 1
- Signals discovered from packaged event schemas: 8
- Work-type bindings: 3
- Evidence/outcome surfaces: 3

## Verification

The cumulative package is verified after packaging using PHP syntax lint, JSON parsing, the executable Workforce contract verifier, and available package-native standalone tests. Exact counts and final SHA-256 are recorded in the batch report generated beside the output ZIPs.

## Pass 2 — Runtime Discovery & Fail-Closed Execution

- Integration schema upgraded to `1.1`.
- Runtime discovery is read-only and never grants authority.
- Provider fingerprint: `cc985bea477b61c0baa94159f152afdda8b4a4e0131fac563e40802c7eb5656d`.
- Duplicate providers and version mismatches resolve to `blocked`.
- Missing decisions resolve to `deny`; deny short-circuits the pipeline.
- Mutation requests require provider pinning, idempotency and governed Command Bus execution.
- Guardrail decisions/mutations require auditable receipts; timeout/partial failure cannot resolve to allow.
- Offline operation cannot increase authority; fallback providers require explicit reauthorization and repinning.
