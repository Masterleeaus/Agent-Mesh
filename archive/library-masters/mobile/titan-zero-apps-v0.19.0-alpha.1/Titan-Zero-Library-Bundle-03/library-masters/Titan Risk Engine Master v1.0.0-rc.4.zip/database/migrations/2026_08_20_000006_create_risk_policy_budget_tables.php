<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_risk_budget_versions')) {
            Schema::create('titan_risk_budget_versions', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('company_id');
                $table->string('version', 80);
                $table->decimal('max_daily_risk_exposure', 14, 2);
                $table->string('max_autonomous_single_action_level', 20);
                $table->decimal('monitoring_threshold_ratio', 8, 6);
                $table->dateTime('effective_at', 6)->index();
                $table->string('source', 20);
                $table->string('supersedes_version', 80)->nullable();
                $table->string('content_digest', 64)->index();
                $table->timestamps(6);
                $table->unique(['company_id', 'version'], 'titan_risk_budget_tenant_version_unique');
                $table->index(['company_id', 'effective_at'], 'titan_risk_budget_tenant_effective_idx');
            });
        }

        if (!Schema::hasTable('titan_risk_policy_overlays')) {
            Schema::create('titan_risk_policy_overlays', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->string('binding_key', 64)->index();
                $table->string('policy_key', 120)->index();
                $table->string('version', 80);
                $table->string('scope', 32)->index();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('capability', 160)->nullable()->index();
                $table->json('constraints');
                $table->dateTime('effective_at', 6)->index();
                $table->string('supersedes_version', 80)->nullable();
                $table->string('content_digest', 64)->index();
                $table->timestamps(6);
                $table->unique(['binding_key', 'version'], 'titan_risk_policy_binding_version_unique');
                $table->index(['binding_key', 'effective_at'], 'titan_risk_policy_binding_effective_idx');
            });
        }

        if (!Schema::hasTable('titan_risk_policy_changes')) {
            Schema::create('titan_risk_policy_changes', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->string('change_id', 191)->unique();
                $table->string('action', 40)->index();
                $table->unsignedBigInteger('company_id')->nullable()->index();
                $table->string('policy_key', 120)->index();
                $table->string('version', 80);
                $table->string('previous_version', 80)->nullable();
                $table->string('trace_id', 191)->index();
                $table->string('correlation_id', 191)->index();
                $table->string('causation_id', 191)->index();
                $table->string('actor_type', 40)->nullable();
                $table->string('actor_id', 191)->nullable();
                $table->text('reason');
                $table->json('change_payload');
                $table->dateTime('changed_at', 6)->index();
                $table->timestamps(6);
                $table->index(['company_id', 'policy_key', 'changed_at'], 'titan_risk_policy_change_tenant_time_idx');
            });
        }

        if (Schema::hasTable('titan_risk_enforcement_receipts')) {
            Schema::table('titan_risk_enforcement_receipts', function (Blueprint $table): void {
                if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'effective_policy_digest')) {
                    $table->string('effective_policy_digest', 64)->nullable()->index();
                }
                if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'budget_version')) {
                    $table->string('budget_version', 80)->nullable()->index();
                }
                if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'budget_utilization_ratio')) {
                    $table->decimal('budget_utilization_ratio', 10, 6)->nullable();
                }
            });
        }
    }

    public function down(): void
    {
        // Governed policy/budget history and enforcement evidence are retained by design.
    }
};
