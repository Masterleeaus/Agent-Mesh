<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_risk_assessments', function (Blueprint $table): void {
            $table->uuid('causation_id')->nullable()->index();
            $table->string('idempotency_key', 191)->nullable();
            $table->string('capability', 160)->nullable()->index();
            $table->string('action', 160)->nullable()->index();
            $table->string('actor_type', 80)->nullable()->index();
            $table->string('actor_id', 191)->nullable()->index();
            $table->string('resource_type', 120)->nullable()->index();
            $table->string('resource_id', 191)->nullable()->index();
            $table->string('vertical_key', 120)->nullable()->index();
            $table->string('jurisdiction', 120)->nullable()->index();
            $table->decimal('score', 5, 2)->nullable()->index();
            $table->string('level', 20)->nullable()->index();
            $table->string('decision', 40)->nullable()->index();
            $table->string('policy_version', 80)->nullable()->index();
            $table->string('reversibility', 32)->nullable()->index();
            $table->string('connectivity', 24)->nullable()->index();
            $table->decimal('impact_financial', 5, 2)->nullable();
            $table->decimal('impact_safety', 5, 2)->nullable();
            $table->decimal('impact_privacy', 5, 2)->nullable();
            $table->decimal('impact_legal', 5, 2)->nullable();
            $table->decimal('impact_operational', 5, 2)->nullable();
            $table->decimal('impact_reputation', 5, 2)->nullable();
            $table->string('hour_bucket', 13)->nullable()->index();
            $table->date('day_bucket')->nullable()->index();
            $table->json('reason_codes')->nullable();
            $table->json('reasons')->nullable();
            $table->json('remediation')->nullable();
            $table->json('recent_activity')->nullable();
            $table->json('metadata')->nullable();
            $table->json('context_snapshot')->nullable();
            $table->dateTime('assessed_at', 6)->nullable()->index();

            $table->unique(['company_id', 'idempotency_key'], 'titan_risk_tenant_idem_unique');
            $table->index(['company_id', 'assessed_at'], 'titan_risk_tenant_time_idx');
            $table->index(['company_id', 'capability', 'assessed_at'], 'titan_risk_tenant_cap_time_idx');
            $table->index(['company_id', 'actor_type', 'actor_id', 'assessed_at'], 'titan_risk_tenant_actor_time_idx');
            $table->index(['company_id', 'resource_type', 'resource_id', 'assessed_at'], 'titan_risk_tenant_resource_time_idx');
        });
    }

    public function down(): void
    {
        Schema::table('titan_risk_assessments', function (Blueprint $table): void {
            $table->dropUnique('titan_risk_tenant_idem_unique');
            $table->dropIndex('titan_risk_tenant_time_idx');
            $table->dropIndex('titan_risk_tenant_cap_time_idx');
            $table->dropIndex('titan_risk_tenant_actor_time_idx');
            $table->dropIndex('titan_risk_tenant_resource_time_idx');

            $table->dropColumn([
                'causation_id', 'idempotency_key', 'capability', 'action', 'actor_type', 'actor_id',
                'resource_type', 'resource_id', 'vertical_key', 'jurisdiction', 'score', 'level',
                'decision', 'policy_version', 'reversibility', 'connectivity', 'impact_financial',
                'impact_safety', 'impact_privacy', 'impact_legal', 'impact_operational', 'impact_reputation',
                'hour_bucket', 'day_bucket', 'reason_codes', 'reasons', 'remediation', 'recent_activity',
                'metadata', 'context_snapshot', 'assessed_at',
            ]);
        });
    }
};
