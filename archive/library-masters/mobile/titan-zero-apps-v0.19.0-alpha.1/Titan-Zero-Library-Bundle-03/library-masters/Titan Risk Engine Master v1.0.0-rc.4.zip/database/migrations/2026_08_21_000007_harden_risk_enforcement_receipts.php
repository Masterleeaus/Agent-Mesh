<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_risk_enforcement_receipts')) return;
        Schema::table('titan_risk_enforcement_receipts', function (Blueprint $table): void {
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'action')) $table->string('action', 160)->nullable()->after('capability');
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'actor_type')) $table->string('actor_type', 80)->nullable()->after('action');
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'actor_id')) $table->string('actor_id', 191)->nullable()->after('actor_type');
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'resource_type')) $table->string('resource_type', 120)->nullable()->after('actor_id');
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'resource_id')) $table->string('resource_id', 191)->nullable()->after('resource_type');
            if (!Schema::hasColumn('titan_risk_enforcement_receipts', 'request_fingerprint')) $table->string('request_fingerprint', 64)->nullable()->index()->after('resource_id');
        });
    }

    public function down(): void
    {
        // Risk enforcement receipts are retained governance evidence; destructive rollback is explicit operator action.
    }
};
