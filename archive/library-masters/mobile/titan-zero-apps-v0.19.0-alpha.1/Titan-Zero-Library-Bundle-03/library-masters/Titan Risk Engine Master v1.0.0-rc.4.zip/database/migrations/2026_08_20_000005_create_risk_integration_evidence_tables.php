<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_risk_signal_outbox')) {
            Schema::create('titan_risk_signal_outbox', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->string('event_id', 64)->unique();
                $table->string('event_type', 120)->index();
                $table->unsignedBigInteger('company_id');
                $table->string('trace_id', 191)->index();
                $table->string('correlation_id', 191)->index();
                $table->string('causation_id', 191)->index();
                $table->string('root_causation_id', 191)->index();
                $table->string('severity', 20)->index();
                $table->json('event_payload');
                $table->dateTime('occurred_at', 6)->index();
                $table->dateTime('published_at', 6)->nullable()->index();
                $table->dateTime('last_attempt_at', 6)->nullable();
                $table->unsignedInteger('attempts')->default(0);
                $table->text('last_error')->nullable();
                $table->timestamps(6);
                $table->index(['company_id', 'published_at', 'occurred_at'], 'titan_risk_signal_pending_idx');
            });
        }

        if (!Schema::hasTable('titan_risk_enforcement_receipts')) {
            Schema::create('titan_risk_enforcement_receipts', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->string('receipt_id', 64)->unique();
                $table->string('content_digest', 64)->index();
                $table->unsignedBigInteger('company_id');
                $table->string('trace_id', 191)->index();
                $table->string('correlation_id', 191)->index();
                $table->string('causation_id', 191)->index();
                $table->string('capability', 160)->index();
                $table->string('execution_directive', 40)->index();
                $table->boolean('may_dispatch')->index();
                $table->decimal('risk_score', 5, 2);
                $table->string('risk_level', 20)->index();
                $table->string('assessment_policy_version', 80);
                $table->string('governance_source', 40)->nullable()->index();
                $table->string('evidence_id', 191)->nullable()->index();
                $table->json('receipt_payload');
                $table->dateTime('issued_at', 6)->index();
                $table->timestamps(6);
                $table->index(['company_id', 'capability', 'issued_at'], 'titan_risk_receipt_tenant_cap_time_idx');
            });
        }

        if (!Schema::hasTable('titan_risk_governance_feedback')) {
            Schema::create('titan_risk_governance_feedback', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('company_id');
                $table->string('source', 40);
                $table->string('evidence_id', 191);
                $table->string('trace_id', 191)->index();
                $table->string('correlation_id', 191)->index();
                $table->string('causation_id', 191)->index();
                $table->string('original_directive', 40);
                $table->string('execution_directive', 40)->index();
                $table->boolean('may_dispatch')->index();
                $table->json('reason_codes')->nullable();
                $table->json('feedback_payload');
                $table->dateTime('applied_at', 6)->index();
                $table->timestamps(6);
                $table->unique(['company_id', 'source', 'evidence_id'], 'titan_risk_feedback_evidence_unique');
                $table->index(['company_id', 'source', 'applied_at'], 'titan_risk_feedback_tenant_source_time_idx');
            });
        }
    }

    public function down(): void
    {
        // Cross-engine governance evidence follows the Risk retain-data policy.
        // Destructive rollback is an explicit operator-owned data action.
    }
};
