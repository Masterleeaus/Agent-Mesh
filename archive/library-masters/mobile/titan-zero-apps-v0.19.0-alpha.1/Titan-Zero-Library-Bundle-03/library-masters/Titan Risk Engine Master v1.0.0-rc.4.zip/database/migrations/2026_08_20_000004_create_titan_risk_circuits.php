<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('titan_risk_circuits')) {
            Schema::create('titan_risk_circuits', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('company_id');
                $table->string('scope', 40);
                $table->string('capability', 191)->nullable();
                $table->string('capability_key', 191);
                $table->string('state', 20)->default('CLOSED');
                $table->unsignedBigInteger('version')->default(1);
                $table->json('reason_codes')->nullable();
                $table->string('policy_version', 80);
                $table->unsignedInteger('successful_probe_count')->default(0);
                $table->dateTime('opened_at', 6)->nullable();
                $table->dateTime('half_opened_at', 6)->nullable();
                $table->dateTime('probe_after', 6)->nullable();
                $table->dateTime('expires_at', 6)->nullable();
                $table->dateTime('last_transition_at', 6);
                $table->timestamps(6);
                $table->unique(['company_id', 'scope', 'capability_key'], 'titan_risk_circuit_scope_unique');
                $table->index(['company_id', 'state'], 'titan_risk_circuit_tenant_state_idx');
                $table->index(['company_id', 'capability_key', 'state'], 'titan_risk_circuit_cap_state_idx');
                $table->index(['state', 'probe_after'], 'titan_risk_circuit_probe_idx');
            });
        }

        if (!Schema::hasTable('titan_risk_circuit_transitions')) {
            Schema::create('titan_risk_circuit_transitions', function (Blueprint $table): void {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('circuit_id');
                $table->unsignedBigInteger('company_id');
                $table->string('scope', 40);
                $table->string('capability', 191)->nullable();
                $table->string('from_state', 20);
                $table->string('to_state', 20);
                $table->unsignedBigInteger('resulting_version');
                $table->json('reason_codes')->nullable();
                $table->string('policy_version', 80);
                $table->string('trace_id', 191);
                $table->string('correlation_id', 191);
                $table->string('causation_id', 191);
                $table->dateTime('occurred_at', 6);
                $table->timestamps(6);
                $table->index(['circuit_id', 'resulting_version'], 'titan_risk_circuit_event_version_idx');
                $table->index(['company_id', 'occurred_at'], 'titan_risk_circuit_event_tenant_time_idx');
                $table->index(['trace_id'], 'titan_risk_circuit_event_trace_idx');
            });
        }
    }

    public function down(): void
    {
        // Risk governance evidence follows retain-data uninstall policy.
        // Destructive rollback requires an explicit operator-owned data action.
    }
};
