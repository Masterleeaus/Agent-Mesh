<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Wave 1B canonical tenant-boundary migration.
     * company_id is the sole Titan business/tenant boundary.
     * If both columns are present we fail closed rather than guess semantics.
     */
    public function up(): void
    {
        foreach ($this->tables() as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'tenant_company_id')) {
                continue;
            }
            if (Schema::hasColumn($table, 'company_id')) {
                throw new RuntimeException("Wave 1B cannot canonicalize {$table}: both tenant_company_id and company_id exist; resolve semantic collision explicitly.");
            }
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('tenant_company_id', 'company_id');
            });
        }
    }

    public function down(): void
    {
        foreach (array_reverse($this->tables()) as $table) {
            if (! Schema::hasTable($table) || ! Schema::hasColumn($table, 'company_id') || Schema::hasColumn($table, 'tenant_company_id')) {
                continue;
            }
            Schema::table($table, static function (Blueprint $blueprint): void {
                $blueprint->renameColumn('company_id', 'tenant_company_id');
            });
        }
    }

    /** @return list<string> */
    private function tables(): array
    {
        return [
            'titan_risk_assessments',
            'titan_risk_budget_versions',
            'titan_risk_circuit_transitions',
            'titan_risk_circuits',
            'titan_risk_enforcement_receipts',
            'titan_risk_governance_feedback',
            'titan_risk_policy_changes',
            'titan_risk_policy_overlays',
            'titan_risk_signal_outbox'
        ];
    }
};
