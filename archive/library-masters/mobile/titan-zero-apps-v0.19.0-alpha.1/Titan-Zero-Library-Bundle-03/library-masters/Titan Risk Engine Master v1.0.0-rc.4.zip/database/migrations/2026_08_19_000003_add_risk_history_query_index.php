<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('titan_risk_assessments', function (Blueprint $table): void {
            $table->index(
                ['company_id', 'actor_type', 'actor_id', 'capability', 'assessed_at'],
                'titan_risk_actor_cap_time_idx'
            );
        });
    }

    public function down(): void
    {
        Schema::table('titan_risk_assessments', function (Blueprint $table): void {
            $table->dropIndex('titan_risk_actor_cap_time_idx');
        });
    }
};
