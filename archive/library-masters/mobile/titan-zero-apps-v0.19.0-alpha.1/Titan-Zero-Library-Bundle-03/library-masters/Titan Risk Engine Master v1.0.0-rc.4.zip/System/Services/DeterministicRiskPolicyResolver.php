<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEffectivePolicyResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEffectivePolicy;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use DateTimeImmutable;
use InvalidArgumentException;

final class DeterministicRiskPolicyResolver implements RiskEffectivePolicyResolverContract
{
    public function __construct(
        private readonly RiskBudgetStoreContract $budgets,
        private readonly RiskPolicyOverlayStoreContract $overlays,
        private readonly RiskOperationalBudget $defaultBudget,
        private readonly RiskLevel $defaultHardBlockLevel = RiskLevel::EXTREME,
    ) {}

    public function resolve(int|string $companyId, string $capability, DateTimeImmutable $asOf): RiskEffectivePolicy
    {
        if ((is_int($companyId) && $companyId <= 0) || trim((string) $companyId) === '') {
            throw new InvalidArgumentException('Effective Risk policy requires company_id.');
        }
        if (trim($capability) === '') {
            throw new InvalidArgumentException('Effective Risk policy requires capability.');
        }

        $budget = $this->budgets->effectiveFor($companyId, $asOf) ?? $this->defaultBudget;
        $maxDaily = min($this->defaultBudget->maxDailyRiskExposure, $budget->maxDailyRiskExposure);
        $maxSingle = $this->stricterLevel($this->defaultBudget->maxAutonomousSingleActionLevel, $budget->maxAutonomousSingleActionLevel);
        $monitoring = min($this->defaultBudget->monitoringThresholdRatio, $budget->monitoringThresholdRatio);
        $hardBlock = $this->defaultHardBlockLevel;
        $versions = ['policy:operational-governance-v1'];
        if ($budget !== $this->defaultBudget) {
            $versions[] = 'budget:' . $budget->version;
        } else {
            $versions[] = 'budget:' . $this->defaultBudget->version;
        }

        $candidateOverlays = $this->overlays->effectiveFor($companyId, $capability, $asOf);
        $latestByBinding = [];
        foreach ($candidateOverlays as $overlay) {
            $binding = implode('|', [$overlay->policyKey, $overlay->scope->value, (string) ($overlay->companyId ?? ''), (string) ($overlay->capability ?? '')]);
            $current = $latestByBinding[$binding] ?? null;
            if ($current === null || $overlay->effectiveAt > $current->effectiveAt || ($overlay->effectiveAt == $current->effectiveAt && strcmp($overlay->version, $current->version) > 0)) {
                $latestByBinding[$binding] = $overlay;
            }
        }
        $overlays = array_values($latestByBinding);
        usort($overlays, static fn ($a, $b): int => [$a->scope->value, $a->policyKey, $a->version] <=> [$b->scope->value, $b->policyKey, $b->version]);
        foreach ($overlays as $overlay) {
            $c = $overlay->constraints;
            if (isset($c['max_daily_risk_exposure'])) {
                $candidate = (float) $c['max_daily_risk_exposure'];
                if ($candidate > 0.0) $maxDaily = min($maxDaily, $candidate);
            }
            if (isset($c['max_autonomous_single_action_level'])) {
                $maxSingle = $this->stricterLevel($maxSingle, RiskLevel::from((string) $c['max_autonomous_single_action_level']));
            }
            if (isset($c['monitoring_threshold_ratio'])) {
                $candidate = (float) $c['monitoring_threshold_ratio'];
                if ($candidate > 0.0 && $candidate <= 1.0) $monitoring = min($monitoring, $candidate);
            }
            if (isset($c['hard_block_level'])) {
                $hardBlock = $this->stricterLevel($hardBlock, RiskLevel::from((string) $c['hard_block_level']));
            }
            $versions[] = sprintf('overlay:%s:%s', $overlay->policyKey, $overlay->version);
        }

        $canonical = [
            'company_id' => (string) $companyId,
            'capability' => $capability,
            'max_daily_risk_exposure' => round($maxDaily, 2),
            'max_autonomous_single_action_level' => $maxSingle->value,
            'monitoring_threshold_ratio' => round($monitoring, 6),
            'hard_block_level' => $hardBlock->value,
            'applied_versions' => $versions,
            'resolved_at' => $asOf->format('Y-m-d\\TH:i:s.uP'),
        ];
        $digest = hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));

        return new RiskEffectivePolicy($companyId, $capability, round($maxDaily, 2), $maxSingle, $monitoring, $hardBlock, $versions, $asOf, $digest);
    }

    private function stricterLevel(RiskLevel $current, RiskLevel $candidate): RiskLevel
    {
        return $this->rank($candidate) < $this->rank($current) ? $candidate : $current;
    }

    private function rank(RiskLevel $level): int
    {
        return match ($level) {
            RiskLevel::MINIMAL => 0,
            RiskLevel::LOW => 1,
            RiskLevel::MEDIUM => 2,
            RiskLevel::HIGH => 3,
            RiskLevel::EXTREME => 4,
        };
    }
}
