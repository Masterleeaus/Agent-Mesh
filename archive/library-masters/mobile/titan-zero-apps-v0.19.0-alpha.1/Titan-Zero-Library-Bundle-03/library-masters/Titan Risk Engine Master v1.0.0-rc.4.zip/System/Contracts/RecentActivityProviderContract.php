<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;

interface RecentActivityProviderContract
{
    /** @return list<array<string, scalar|null>> */
    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array;

    public function record(RiskAssessment $assessment): void;
}
