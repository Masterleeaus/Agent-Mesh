<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;

final readonly class RiskGateResult
{
    /** @param list<RiskCircuitSnapshot> $circuits */
    public function __construct(
        public RiskAssessment $assessment,
        public RiskExecutionDirective $directive,
        public array $circuits = [],
        public ?RiskEnforcementReceipt $enforcementReceipt = null,
        public ?RiskBudgetEvaluation $budgetEvaluation = null,
    ) {}

    public function mayDispatchToExecutor(): bool
    {
        return $this->directive->mayDispatchToExecutor();
    }

    public function withEnforcementReceipt(RiskEnforcementReceipt $receipt): self
    {
        return new self($this->assessment, $this->directive, $this->circuits, $receipt, $this->budgetEvaluation);
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'assessment' => $this->assessment->toArray(),
            'execution_directive' => $this->directive->value,
            'may_dispatch_to_executor' => $this->mayDispatchToExecutor(),
            'circuits' => array_map(static fn (RiskCircuitSnapshot $circuit): array => $circuit->toArray(), $this->circuits),
            'enforcement_receipt' => $this->enforcementReceipt?->toArray(),
            'budget_evaluation' => $this->budgetEvaluation?->toArray(),
        ];
    }
}
