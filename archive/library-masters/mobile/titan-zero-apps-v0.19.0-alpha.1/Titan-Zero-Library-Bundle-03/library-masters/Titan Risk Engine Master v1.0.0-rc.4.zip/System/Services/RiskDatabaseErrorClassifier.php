<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use Throwable;

final class RiskDatabaseErrorClassifier
{
    public function isUniqueViolation(Throwable $error): bool
    {
        $code = strtoupper((string) $error->getCode());
        if (in_array($code, ['23000', '23505'], true)) return true;
        $message = strtolower($error->getMessage());
        return str_contains($message, 'duplicate entry')
            || str_contains($message, 'unique constraint')
            || str_contains($message, 'unique violation');
    }

    public function isRetryableConcurrencyFailure(Throwable $error): bool
    {
        $code = strtoupper((string) $error->getCode());
        if (in_array($code, ['40001', '40P01'], true)) return true;
        $message = strtolower($error->getMessage());
        return str_contains($message, 'deadlock found')
            || str_contains($message, 'lock wait timeout')
            || str_contains($message, 'serialization failure');
    }
}
