<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskLedgerWriteResult;

interface RiskAssessmentLedgerContract
{
    public function findByIdempotencyKey(
        int|string $companyId,
        string $idempotencyKey,
    ): ?RiskAssessment;

    public function persist(RiskAssessment $assessment): RiskLedgerWriteResult;
}
