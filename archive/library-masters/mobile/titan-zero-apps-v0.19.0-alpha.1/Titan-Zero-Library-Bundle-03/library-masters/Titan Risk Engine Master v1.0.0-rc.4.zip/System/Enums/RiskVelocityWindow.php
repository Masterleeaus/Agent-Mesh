<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskVelocityWindow: int
{
    case MINUTES_5 = 5;
    case MINUTES_15 = 15;
    case MINUTES_60 = 60;

    public function minutes(): int
    {
        return $this->value;
    }
}
