<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

final class AuthenticatedTenantResolver
{
    public function resolve(?object $user): int|string|null
    {
        if ($user === null) return null;
        foreach (['company_id'] as $field) {
            $value = $user->{$field} ?? null;
            if (is_int($value) && $value > 0) return $value;
            if (is_string($value) && trim($value) !== '' && trim($value) !== '0') return trim($value);
        }
        return null;
    }
}
