<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;
use InvalidArgumentException;

final class RiskVelocityService implements RiskVelocityContract
{
    /**
     * @param array<string,array{actions_per_minute:float,score_points_per_minute:float,severe_count:int}>|null $thresholds
     */
    public function __construct(
        private readonly RiskHistoryReaderContract $history,
        private readonly ?array $thresholds = null,
    ) {}

    public function assess(RiskHistoryQuery $query): RiskVelocityAssessment
    {
        if ($query->velocityWindow === null) {
            throw new InvalidArgumentException('risk.velocity requires a canonical velocity window.');
        }

        $snapshot = $this->history->summarize($query);
        $minutes = max(1.0, $query->durationMinutes());
        $actionsPerMinute = round($snapshot->assessmentCount / $minutes, 4);
        $scorePointsPerMinute = round($snapshot->scoreSum / $minutes, 4);
        $thresholds = $this->effectiveThresholds();

        $level = RiskVelocityLevel::NORMAL;
        $reasonCodes = [];

        if ($this->crosses($thresholds['critical'], $actionsPerMinute, $scorePointsPerMinute, $snapshot->highOrExtremeCount)) {
            $level = RiskVelocityLevel::CRITICAL;
            $reasonCodes[] = 'CRITICAL_ACTIVITY_PRESSURE';
        } elseif ($this->crosses($thresholds['high'], $actionsPerMinute, $scorePointsPerMinute, $snapshot->highOrExtremeCount)) {
            $level = RiskVelocityLevel::HIGH;
            $reasonCodes[] = 'HIGH_ACTIVITY_PRESSURE';
        } elseif ($this->crosses($thresholds['elevated'], $actionsPerMinute, $scorePointsPerMinute, $snapshot->highOrExtremeCount)) {
            $level = RiskVelocityLevel::ELEVATED;
            $reasonCodes[] = 'ELEVATED_ACTIVITY_PRESSURE';
        }

        if ($snapshot->highOrExtremeCount > 0) {
            $reasonCodes[] = 'SEVERE_ACTION_CLUSTER';
        }
        if ($actionsPerMinute >= $thresholds['elevated']['actions_per_minute']) {
            $reasonCodes[] = 'ACTION_RATE_ELEVATED';
        }
        if ($scorePointsPerMinute >= $thresholds['elevated']['score_points_per_minute']) {
            $reasonCodes[] = 'RISK_SCORE_RATE_ELEVATED';
        }

        return new RiskVelocityAssessment(
            exposure: $snapshot,
            window: $query->velocityWindow,
            level: $level,
            actionsPerMinute: $actionsPerMinute,
            scorePointsPerMinute: $scorePointsPerMinute,
            reasonCodes: array_values(array_unique($reasonCodes)),
        );
    }

    /** @return array<string,array{actions_per_minute:float,score_points_per_minute:float,severe_count:int}> */
    private function effectiveThresholds(): array
    {
        $defaults = self::defaultThresholds();
        if ($this->thresholds === null) {
            return $defaults;
        }

        $effective = $defaults;
        foreach ($defaults as $level => $baseline) {
            $candidate = is_array($this->thresholds[$level] ?? null) ? $this->thresholds[$level] : [];
            $effective[$level] = [
                'actions_per_minute' => min(
                    $baseline['actions_per_minute'],
                    max(0.01, is_numeric($candidate['actions_per_minute'] ?? null) ? (float) $candidate['actions_per_minute'] : $baseline['actions_per_minute']),
                ),
                'score_points_per_minute' => min(
                    $baseline['score_points_per_minute'],
                    max(0.01, is_numeric($candidate['score_points_per_minute'] ?? null) ? (float) $candidate['score_points_per_minute'] : $baseline['score_points_per_minute']),
                ),
                'severe_count' => min(
                    $baseline['severe_count'],
                    max(1, is_numeric($candidate['severe_count'] ?? null) ? (int) $candidate['severe_count'] : $baseline['severe_count']),
                ),
            ];
        }

        return $effective;
    }

    /** @return array<string,array{actions_per_minute:float,score_points_per_minute:float,severe_count:int}> */
    public static function defaultThresholds(): array
    {
        return [
            'elevated' => ['actions_per_minute' => 2.0, 'score_points_per_minute' => 50.0, 'severe_count' => 1],
            'high' => ['actions_per_minute' => 4.0, 'score_points_per_minute' => 100.0, 'severe_count' => 2],
            'critical' => ['actions_per_minute' => 8.0, 'score_points_per_minute' => 200.0, 'severe_count' => 3],
        ];
    }

    /** @param array{actions_per_minute:float,score_points_per_minute:float,severe_count:int} $threshold */
    private function crosses(array $threshold, float $actionsPerMinute, float $scorePointsPerMinute, int $severeCount): bool
    {
        return $actionsPerMinute >= $threshold['actions_per_minute']
            || $scorePointsPerMinute >= $threshold['score_points_per_minute']
            || $severeCount >= $threshold['severe_count'];
    }
}
