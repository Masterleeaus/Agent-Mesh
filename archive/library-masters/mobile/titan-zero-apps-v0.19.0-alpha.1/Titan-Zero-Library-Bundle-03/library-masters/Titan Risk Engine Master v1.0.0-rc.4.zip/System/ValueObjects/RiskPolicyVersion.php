<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use DateTimeImmutable;

final readonly class RiskPolicyVersion
{
    public function __construct(
        public string $policy,
        public string $version,
        public DateTimeImmutable $effectiveAt,
        public string $status = 'ACTIVE',
    ) {}

    /** @return array<string, string> */
    public function toArray(): array
    {
        return [
            'policy' => $this->policy,
            'version' => $this->version,
            'effective_at' => $this->effectiveAt->format(DATE_ATOM),
            'status' => $this->status,
        ];
    }
}
