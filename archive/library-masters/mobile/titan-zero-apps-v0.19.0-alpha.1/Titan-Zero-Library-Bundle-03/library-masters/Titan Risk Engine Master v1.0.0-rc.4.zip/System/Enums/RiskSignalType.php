<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskSignalType: string
{
    case RISK_ASSESSED = 'risk.assessed';
    case THRESHOLD_CROSSED = 'risk.threshold.crossed';
    case EXPOSURE_INCREASED = 'risk.exposure.increased';
    case VELOCITY_ELEVATED = 'risk.velocity.elevated';
    case CIRCUIT_OPENED = 'risk.circuit.opened';
    case CIRCUIT_HALF_OPENED = 'risk.circuit.half_opened';
    case CIRCUIT_CLOSED = 'risk.circuit.closed';
    case CIRCUIT_PROBE_FAILED = 'risk.circuit.probe_failed';
    case GOVERNANCE_FEEDBACK_APPLIED = 'risk.governance.feedback.applied';
}
