<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

final readonly class RiskLedgerWriteResult
{
    public function __construct(
        public RiskAssessment $assessment,
        public bool $created,
        public int|string|null $ledgerId = null,
    ) {}
}
