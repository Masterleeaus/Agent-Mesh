<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use Illuminate\Contracts\Cache\Repository as CacheRepository;
use Throwable;

/**
 * Lightweight recent-activity telemetry. It is deliberately not used as an
 * authoritative aggregate/velocity score until those engines are implemented.
 */
final class CachedRecentActivityProvider implements RecentActivityProviderContract
{
    public function __construct(
        private readonly CacheRepository $cache,
        private readonly int $defaultLimit = 10,
        private readonly int $ttlSeconds = 86400,
    ) {}

    public function recentFor(int|string $companyId, string $actorType, int|string|null $actorId, int $limit = 10): array
    {
        $limit = max(1, min($limit, $this->defaultLimit));
        try {
            $items = $this->cache->get($this->key($companyId, $actorType, $actorId), []);
            if (!is_array($items)) return [];
            return array_values(array_slice($items, -$limit));
        } catch (Throwable) {
            // Recent activity is telemetry only; durable aggregate/velocity remains authoritative.
            return [];
        }
    }

    public function record(RiskAssessment $assessment): void
    {
        $context = $assessment->context;
        $key = $this->key($context->companyId, $context->actorType, $context->actorId);
        try {
            $items = $this->cache->get($key, []);
            $items = is_array($items) ? $items : [];

            $items[] = [
            'trace_id' => $context->traceId,
            'capability' => $context->capability,
            'action' => $context->action,
            'score' => $assessment->score,
            'level' => $assessment->level->value,
            'decision' => $assessment->decision->value,
            'assessed_at' => $assessment->assessedAt->format(DATE_ATOM),
        ];

            $items = array_values(array_slice($items, -$this->defaultLimit));
            $this->cache->put($key, $items, $this->ttlSeconds);
        } catch (Throwable) {
            // Cache failure must not interrupt or weaken durable Risk evaluation.
        }
    }

    private function key(int|string $companyId, string $actorType, int|string|null $actorId): string
    {
        return 'titan-risk-engine:recent:' . hash('sha256', implode('|', [
            (string) $companyId,
            strtolower($actorType),
            (string) ($actorId ?? 'anonymous'),
        ]));
    }
}
