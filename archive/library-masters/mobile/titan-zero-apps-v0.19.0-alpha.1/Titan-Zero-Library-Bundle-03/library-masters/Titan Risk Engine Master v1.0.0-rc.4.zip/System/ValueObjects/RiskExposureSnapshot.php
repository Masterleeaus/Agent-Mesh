<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskExposureSnapshot
{
    public function __construct(
        public int|string $companyId,
        public RiskAggregateScope $scope,
        public DateTimeImmutable $from,
        public DateTimeImmutable $to,
        public int $assessmentCount,
        public float $scoreSum,
        public float $scoreAverage,
        public float $scoreMaximum,
        public int $highOrExtremeCount,
        public int $extremeCount,
        public int $blockedCount,
        public ?string $capability = null,
        public ?string $actorType = null,
        public int|string|null $actorId = null,
        public ?string $resourceType = null,
        public int|string|null $resourceId = null,
        public string $policyVersion = 'intelligence-v1',
    ) {
        foreach ([$this->assessmentCount, $this->highOrExtremeCount, $this->extremeCount, $this->blockedCount] as $count) {
            if ($count < 0) {
                throw new InvalidArgumentException('Risk exposure counts cannot be negative.');
            }
        }
        foreach ([$this->scoreSum, $this->scoreAverage, $this->scoreMaximum] as $score) {
            if ($score < 0) {
                throw new InvalidArgumentException('Risk exposure scores cannot be negative.');
            }
        }
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'scope' => $this->scope->value,
            'from' => $this->from->format(DATE_ATOM),
            'to' => $this->to->format(DATE_ATOM),
            'assessment_count' => $this->assessmentCount,
            'score_sum' => $this->scoreSum,
            'score_average' => $this->scoreAverage,
            'score_maximum' => $this->scoreMaximum,
            'high_or_extreme_count' => $this->highOrExtremeCount,
            'extreme_count' => $this->extremeCount,
            'blocked_count' => $this->blockedCount,
            'capability' => $this->capability,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'resource_type' => $this->resourceType,
            'resource_id' => $this->resourceId,
            'policy_version' => $this->policyVersion,
        ];
    }
}
