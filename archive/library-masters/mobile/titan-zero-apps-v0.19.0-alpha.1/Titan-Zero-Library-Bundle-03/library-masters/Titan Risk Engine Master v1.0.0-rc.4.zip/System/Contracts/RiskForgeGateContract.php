<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;

interface RiskForgeGateContract
{
    public function preGeneration(RiskContextInput $input): RiskGateResult;

    public function postGeneration(RiskContextInput $input, string $artifactType, int|string $artifactId): RiskGateResult;
}
