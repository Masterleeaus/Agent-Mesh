<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use InvalidArgumentException;

final class RiskAggregateService implements RiskAggregateContract
{
    public function __construct(private readonly RiskHistoryReaderContract $history) {}

    public function aggregate(RiskHistoryQuery $query): RiskExposureSnapshot
    {
        if ($query->aggregateWindow === null) {
            throw new InvalidArgumentException('risk.aggregate requires a canonical aggregate window.');
        }

        return $this->history->summarize($query);
    }
}
