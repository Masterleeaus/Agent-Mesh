<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskOperationalBudget
{
    public function __construct(
        public int|string $companyId,
        public string $version,
        public float $maxDailyRiskExposure,
        public RiskLevel $maxAutonomousSingleActionLevel,
        public float $monitoringThresholdRatio,
        public DateTimeImmutable $effectiveAt,
        public string $source = 'GOVERNED',
        public ?string $supersedesVersion = null,
    ) {
        if ((is_int($this->companyId) && $this->companyId < 0)
            || (is_string($this->companyId) && (trim($this->companyId) === '' || (is_numeric(trim($this->companyId)) && (float) trim($this->companyId) <= 0.0)))) {
            throw new InvalidArgumentException('Risk budget requires a valid company_id; integer 0 is reserved for the engine default.');
        }
        if (is_string($this->companyId)) RiskFieldConstraints::text('company_id', $this->companyId, 64, false);
        RiskFieldConstraints::text('version', $this->version, 80, false);
        RiskFieldConstraints::text('source', $this->source, 20, false);
        RiskFieldConstraints::text('supersedes_version', $this->supersedesVersion, 80);
        if (!is_finite($this->maxDailyRiskExposure) || $this->maxDailyRiskExposure <= 0.0) {
            throw new InvalidArgumentException('max_daily_risk_exposure must be greater than zero.');
        }
        if (!is_finite($this->monitoringThresholdRatio) || $this->monitoringThresholdRatio <= 0.0 || $this->monitoringThresholdRatio > 1.0) {
            throw new InvalidArgumentException('monitoring_threshold_ratio must be > 0 and <= 1.');
        }
        if (!in_array($this->source, ['DEFAULT', 'GOVERNED', 'ROLLBACK'], true)) {
            throw new InvalidArgumentException('Risk budget source must be DEFAULT, GOVERNED, or ROLLBACK.');
        }
    }

    public function contentDigest(): string
    {
        return hash('sha256', json_encode($this->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'version' => $this->version,
            'max_daily_risk_exposure' => $this->maxDailyRiskExposure,
            'max_autonomous_single_action_level' => $this->maxAutonomousSingleActionLevel->value,
            'monitoring_threshold_ratio' => $this->monitoringThresholdRatio,
            'effective_at' => $this->effectiveAt->format(DATE_ATOM),
            'source' => $this->source,
            'supersedes_version' => $this->supersedesVersion,
        ];
    }
}
