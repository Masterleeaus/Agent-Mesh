<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use DateTimeImmutable;

final readonly class RiskEnforcementReceipt
{
    /** @param list<array{scope:string,capability:?string,state:string,version:int,policy_version:string}> $circuits */
    public function __construct(
        public string $receiptId,
        public string $contentDigest,
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $capability,
        public RiskExecutionDirective $directive,
        public bool $mayDispatch,
        public float $riskScore,
        public RiskLevel $riskLevel,
        public string $assessmentPolicyVersion,
        public array $circuits,
        public DateTimeImmutable $issuedAt,
        public ?string $governanceSource = null,
        public ?string $evidenceId = null,
        public ?string $effectivePolicyDigest = null,
        public ?string $budgetVersion = null,
        public ?float $budgetUtilizationRatio = null,
        public ?string $action = null,
        public ?string $actorType = null,
        public int|string|null $actorId = null,
        public ?string $resourceType = null,
        public int|string|null $resourceId = null,
        public ?string $requestFingerprint = null,
    ) {}

    /** @return array<string,mixed> */
    public function authorizationPayload(): array
    {
        return [
            'company_id' => (string) $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'capability' => $this->capability,
            'action' => $this->action,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId === null ? null : (string) $this->actorId,
            'resource_type' => $this->resourceType,
            'resource_id' => $this->resourceId === null ? null : (string) $this->resourceId,
            'request_fingerprint' => $this->requestFingerprint,
            'directive' => $this->directive->value,
            'may_dispatch_to_executor' => $this->mayDispatch,
            'risk_score' => $this->riskScore,
            'risk_level' => $this->riskLevel->value,
            'assessment_policy_version' => $this->assessmentPolicyVersion,
            'circuits' => $this->circuits,
            'governance_source' => $this->governanceSource,
            'evidence_id' => $this->evidenceId,
            'effective_policy_digest' => $this->effectivePolicyDigest,
            'budget_version' => $this->budgetVersion,
            'budget_utilization_ratio' => $this->budgetUtilizationRatio,
            'issued_at' => $this->issuedAt->format('Y-m-d\\TH:i:s.uP'),
        ];
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return ['receipt_id' => $this->receiptId, 'content_digest' => $this->contentDigest] + $this->authorizationPayload();
    }
}
