<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin;

use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyGovernanceService;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Throwable;

final class RiskPolicyOperationsController
{
    public function scheduleBudget(Request $request, RiskPolicyGovernanceService $governance): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'version' => ['required', 'string', 'max:80'],
            'max_daily_risk_exposure' => ['required', 'numeric', 'gt:0'],
            'max_autonomous_single_action_level' => ['required', 'in:MINIMAL,LOW,MEDIUM,HIGH,EXTREME'],
            'monitoring_threshold_ratio' => ['required', 'numeric', 'gt:0', 'lte:1'],
            'effective_at' => ['required', 'date', 'after_or_equal:now'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);
        $tenant = (int) $data['company_id'];
        $version = trim((string) $data['version']);
        $effectiveAt = $this->utc((string) $data['effective_at']);
        $budget = new RiskOperationalBudget(
            companyId: $tenant,
            version: $version,
            maxDailyRiskExposure: (float) $data['max_daily_risk_exposure'],
            maxAutonomousSingleActionLevel: RiskLevel::from((string) $data['max_autonomous_single_action_level']),
            monitoringThresholdRatio: (float) $data['monitoring_threshold_ratio'],
            effectiveAt: $effectiveAt,
        );

        try {
            $governance->scheduleBudget($budget, $this->evidence($request, 'BUDGET_SCHEDULED', $tenant, 'operational-budget', $version, (string) $data['reason']));
        } catch (Throwable $e) {
            report($e);
            return $this->backToCentre($tenant)->with('error', 'Risk budget was not scheduled. Check version uniqueness and policy values.');
        }
        return $this->backToCentre($tenant)->with('success', 'Risk budget version scheduled.');
    }

    public function scheduleOverlay(Request $request, RiskPolicyGovernanceService $governance): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'policy_key' => ['required', 'string', 'max:120'],
            'version' => ['required', 'string', 'max:80'],
            'scope' => ['required', 'in:GLOBAL,TENANT,CAPABILITY,TENANT_CAPABILITY'],
            'capability' => ['nullable', 'string', 'max:160'],
            'max_daily_risk_exposure' => ['nullable', 'numeric', 'gt:0'],
            'max_autonomous_single_action_level' => ['nullable', 'in:MINIMAL,LOW,MEDIUM,HIGH,EXTREME'],
            'monitoring_threshold_ratio' => ['nullable', 'numeric', 'gt:0', 'lte:1'],
            'hard_block_level' => ['nullable', 'in:MINIMAL,LOW,MEDIUM,HIGH,EXTREME'],
            'effective_at' => ['required', 'date', 'after_or_equal:now'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);
        $scope = RiskPolicyScope::from((string) $data['scope']);
        $tenant = (int) $data['company_id'];
        $capability = isset($data['capability']) && trim((string) $data['capability']) !== '' ? trim((string) $data['capability']) : null;
        $constraints = [];
        foreach (['max_daily_risk_exposure','max_autonomous_single_action_level','monitoring_threshold_ratio','hard_block_level'] as $key) {
            if (array_key_exists($key, $data) && $data[$key] !== null && $data[$key] !== '') $constraints[$key] = $data[$key];
        }
        if ($constraints === []) return $this->backToCentre($tenant)->with('error', 'At least one governed policy constraint is required.');

        $overlay = new RiskPolicyOverlay(
            policyKey: trim((string) $data['policy_key']),
            version: trim((string) $data['version']),
            scope: $scope,
            constraints: $constraints,
            effectiveAt: $this->utc((string) $data['effective_at']),
            companyId: in_array($scope, [RiskPolicyScope::TENANT, RiskPolicyScope::TENANT_CAPABILITY], true) ? $tenant : null,
            capability: in_array($scope, [RiskPolicyScope::CAPABILITY, RiskPolicyScope::TENANT_CAPABILITY], true) ? $capability : null,
        );

        try {
            $governance->scheduleOverlay($overlay, $this->evidence($request, 'POLICY_SCHEDULED', $overlay->companyId, $overlay->policyKey, $overlay->version, (string) $data['reason']));
        } catch (Throwable $e) {
            report($e);
            return $this->backToCentre($tenant)->with('error', 'Risk policy overlay was not scheduled. Check scope, capability, version and constraints.');
        }
        return $this->backToCentre($tenant)->with('success', 'Risk policy overlay scheduled.');
    }

    public function rollbackBudget(Request $request, RiskPolicyGovernanceService $governance): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'target_version' => ['required', 'string', 'max:80'],
            'new_version' => ['required', 'string', 'max:80', 'different:target_version'],
            'effective_at' => ['required', 'date', 'after_or_equal:now'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);
        $tenant = (int) $data['company_id'];
        try {
            $governance->rollbackBudget(
                companyId: $tenant,
                targetVersion: (string) $data['target_version'],
                newVersion: (string) $data['new_version'],
                effectiveAt: $this->utc((string) $data['effective_at']),
                evidence: $this->evidence($request, 'BUDGET_ROLLBACK_SCHEDULED', $tenant, 'operational-budget', (string) $data['new_version'], (string) $data['reason'], (string) $data['target_version']),
            );
        } catch (Throwable $e) {
            report($e);
            return $this->backToCentre($tenant)->with('error', 'Risk budget rollback was not scheduled.');
        }
        return $this->backToCentre($tenant)->with('success', 'Risk budget rollback scheduled as a new immutable version.');
    }

    public function rollbackOverlay(Request $request, RiskPolicyGovernanceService $governance): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'policy_key' => ['required', 'string', 'max:120'],
            'scope' => ['required', 'in:GLOBAL,TENANT,CAPABILITY,TENANT_CAPABILITY'],
            'capability' => ['nullable', 'string', 'max:160'],
            'target_version' => ['required', 'string', 'max:80'],
            'new_version' => ['required', 'string', 'max:80', 'different:target_version'],
            'effective_at' => ['required', 'date', 'after_or_equal:now'],
            'reason' => ['required', 'string', 'max:1000'],
        ]);
        $tenant = (int) $data['company_id'];
        $scope = RiskPolicyScope::from((string) $data['scope']);
        $scopedTenant = in_array($scope, [RiskPolicyScope::TENANT, RiskPolicyScope::TENANT_CAPABILITY], true) ? $tenant : null;
        $capability = in_array($scope, [RiskPolicyScope::CAPABILITY, RiskPolicyScope::TENANT_CAPABILITY], true) ? trim((string) ($data['capability'] ?? '')) : null;
        try {
            $governance->rollbackOverlay(
                policyKey: (string) $data['policy_key'],
                scope: $scope,
                companyId: $scopedTenant,
                capability: $capability === '' ? null : $capability,
                targetVersion: (string) $data['target_version'],
                newVersion: (string) $data['new_version'],
                effectiveAt: $this->utc((string) $data['effective_at']),
                evidence: $this->evidence($request, 'POLICY_ROLLBACK_SCHEDULED', $scopedTenant, (string) $data['policy_key'], (string) $data['new_version'], (string) $data['reason'], (string) $data['target_version']),
            );
        } catch (Throwable $e) {
            report($e);
            return $this->backToCentre($tenant)->with('error', 'Risk policy rollback was not scheduled.');
        }
        return $this->backToCentre($tenant)->with('success', 'Risk policy rollback scheduled as a new immutable version.');
    }

    private function evidence(Request $request, string $action, int|string|null $tenant, string $policyKey, string $version, string $reason, ?string $previousVersion = null): RiskPolicyChangeEvidence
    {
        // Causal lineage is trusted only when host middleware has resolved it into request attributes.
        // Raw client headers are deliberately ignored to prevent forged governance lineage.
        $trace = trim((string) $request->attributes->get('titan_trace_id', '')) ?: 'trace_' . Str::uuid()->toString();
        $correlation = trim((string) $request->attributes->get('titan_correlation_id', '')) ?: 'corr_' . Str::uuid()->toString();
        $causation = trim((string) $request->attributes->get('titan_causation_id', '')) ?: 'cause_' . Str::uuid()->toString();
        return new RiskPolicyChangeEvidence(
            changeId: 'riskchg_' . str_replace('-', '', Str::uuid()->toString()),
            action: $action,
            companyId: $tenant,
            policyKey: $policyKey,
            version: $version,
            traceId: $trace,
            correlationId: $correlation,
            causationId: $causation,
            changedAt: new DateTimeImmutable('now', new DateTimeZone('UTC')),
            reason: trim($reason),
            actorType: 'USER',
            actorId: $request->user()?->getAuthIdentifier(),
            previousVersion: $previousVersion,
        );
    }

    private function utc(string $value): DateTimeImmutable
    {
        return (new DateTimeImmutable($value))->setTimezone(new DateTimeZone('UTC'));
    }

    private function backToCentre(int $tenant): RedirectResponse
    {
        return redirect()->route('dashboard.admin.titan.risk.engine.control-centre', ['company_id' => $tenant]);
    }
}
