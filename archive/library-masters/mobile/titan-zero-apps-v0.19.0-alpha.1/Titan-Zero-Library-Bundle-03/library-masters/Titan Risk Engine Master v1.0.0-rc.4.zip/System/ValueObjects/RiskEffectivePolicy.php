<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use DateTimeImmutable;

final readonly class RiskEffectivePolicy
{
    /** @param list<string> $appliedVersions */
    public function __construct(
        public int|string $companyId,
        public string $capability,
        public float $maxDailyRiskExposure,
        public RiskLevel $maxAutonomousSingleActionLevel,
        public float $monitoringThresholdRatio,
        public RiskLevel $hardBlockLevel,
        public array $appliedVersions,
        public DateTimeImmutable $resolvedAt,
        public string $contentDigest,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'capability' => $this->capability,
            'max_daily_risk_exposure' => $this->maxDailyRiskExposure,
            'max_autonomous_single_action_level' => $this->maxAutonomousSingleActionLevel->value,
            'monitoring_threshold_ratio' => $this->monitoringThresholdRatio,
            'hard_block_level' => $this->hardBlockLevel->value,
            'applied_versions' => $this->appliedVersions,
            'resolved_at' => $this->resolvedAt->format(DATE_ATOM),
            'content_digest' => $this->contentDigest,
        ];
    }
}
