<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGovernanceFeedbackResult;

interface RiskGovernanceFeedbackStoreContract
{
    public function persist(RiskGovernanceFeedbackResult $result): void;
}
