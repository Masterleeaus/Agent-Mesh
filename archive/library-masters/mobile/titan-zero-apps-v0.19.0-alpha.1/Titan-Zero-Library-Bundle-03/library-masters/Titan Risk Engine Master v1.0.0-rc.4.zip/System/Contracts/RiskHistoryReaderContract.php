<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;

interface RiskHistoryReaderContract
{
    public function summarize(RiskHistoryQuery $query): RiskExposureSnapshot;
}
