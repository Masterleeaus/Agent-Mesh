<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use DateTimeImmutable;

final readonly class RiskGovernanceFeedbackResult
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $source,
        public string $evidenceId,
        public RiskExecutionDirective $originalDirective,
        public RiskExecutionDirective $directive,
        public array $reasonCodes,
        public DateTimeImmutable $appliedAt,
        public ?RiskEnforcementReceipt $enforcementReceipt = null,
    ) {}

    public function mayDispatchToExecutor(): bool { return $this->directive->mayDispatchToExecutor(); }

    public function withReceipt(RiskEnforcementReceipt $receipt): self
    {
        return new self(
            $this->companyId, $this->traceId, $this->correlationId, $this->causationId,
            $this->source, $this->evidenceId, $this->originalDirective, $this->directive,
            $this->reasonCodes, $this->appliedAt, $receipt,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'source' => $this->source,
            'evidence_id' => $this->evidenceId,
            'original_directive' => $this->originalDirective->value,
            'execution_directive' => $this->directive->value,
            'may_dispatch_to_executor' => $this->mayDispatchToExecutor(),
            'reason_codes' => $this->reasonCodes,
            'applied_at' => $this->appliedAt->format(DATE_ATOM),
            'enforcement_receipt' => $this->enforcementReceipt?->toArray(),
        ];
    }
}
