<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskVelocityLevel: string
{
    case NORMAL = 'NORMAL';
    case ELEVATED = 'ELEVATED';
    case HIGH = 'HIGH';
    case CRITICAL = 'CRITICAL';
}
