<?php
declare(strict_types=1);
namespace App\Extensions\TitanRiskEngine\System\Workforce;
interface DurableIdempotencyRegistry { public function claim(string $companyId,string $key,string $fingerprint): array; public function complete(string $companyId,string $key,array $receipt): void; public function fail(string $companyId,string $key,string $reason): void; }
