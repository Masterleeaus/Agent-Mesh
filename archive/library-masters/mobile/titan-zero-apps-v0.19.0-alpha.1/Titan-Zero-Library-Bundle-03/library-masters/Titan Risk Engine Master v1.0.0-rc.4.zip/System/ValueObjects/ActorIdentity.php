<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use InvalidArgumentException;

final readonly class ActorIdentity
{
    public function __construct(
        public string $type,
        public int|string $id,
    ) {
        if (trim($this->type) === '' || trim((string) $this->id) === '') {
            throw new InvalidArgumentException('Trusted actor type and id are required.');
        }
    }
}
