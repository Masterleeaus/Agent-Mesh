<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Commands;

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitPolicyContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskDecisionRouterContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEffectivePolicyResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptVerifierContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskFeedbackContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskForgeGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGovernanceFeedbackStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyRegistryContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskTransactionRunnerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Host\TitanMenuCompatibilityAdapter;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Throwable;

final class CertifyExtensionCommand extends Command
{
    protected $signature = 'titan:titan-risk-engine:certify {--json : Emit JSON evidence}';
    protected $description = 'Run Titan Risk Engine host-ready runtime certification checks.';

    public function handle(): int
    {
        $checks = [];

        foreach ($this->bindingContracts() as $name => $contract) {
            $checks[$name . '_bound'] = app()->bound($contract);
            if (!$checks[$name . '_bound']) {
                $checks[$name . '_resolves'] = false;
                continue;
            }

            try {
                app()->make($contract);
                $checks[$name . '_resolves'] = true;
            } catch (Throwable) {
                $checks[$name . '_resolves'] = false;
            }
        }

        try {
            $connection = app('db')->connection();
            $checks['database_driver_mysql'] = strtolower((string) $connection->getDriverName()) === 'mysql';
        } catch (Throwable) {
            $checks['database_driver_mysql'] = false;
        }

        foreach ($this->requiredTableColumns() as $table => $columns) {
            try {
                $checks['table_' . $table] = Schema::hasTable($table);
                $checks['columns_' . $table] = $checks['table_' . $table] && Schema::hasColumns($table, $columns);
            } catch (Throwable) {
                $checks['table_' . $table] = false;
                $checks['columns_' . $table] = false;
            }
        }

        $checks['enabled_config_present'] = config('titan-risk-engine.enabled') !== null;
        $checks['php_82_or_newer'] = version_compare(PHP_VERSION, '8.2.0', '>=');
        $checks['laravel_10_or_newer'] = $this->laravelVersionAtLeast10();
        $checks['canonical_extension_folder'] = basename(dirname(__DIR__, 2)) === 'TitanRiskEngine';
        $checks['package_integrity'] = $this->verifyPackageIntegrity();
        $checks['admin_control_centre_view'] = view()->exists('titan-risk-engine::admin.control-centre');
        $checks['user_risk_view'] = view()->exists('titan-risk-engine::index');

        $routes = app('router')->getRoutes();
        foreach ([
            'user_route' => 'dashboard.user.titan.risk.engine.index',
            'admin_control_centre_route' => 'dashboard.admin.titan.risk.engine.control-centre',
            'admin_budget_schedule_route' => 'dashboard.admin.titan.risk.engine.policy.budget.schedule',
            'admin_budget_rollback_route' => 'dashboard.admin.titan.risk.engine.policy.budget.rollback',
            'admin_overlay_schedule_route' => 'dashboard.admin.titan.risk.engine.policy.overlay.schedule',
            'admin_overlay_rollback_route' => 'dashboard.admin.titan.risk.engine.policy.overlay.rollback',
            'admin_signal_dispatch_route' => 'dashboard.admin.titan.risk.engine.signals.dispatch',
        ] as $check => $routeName) {
            $checks[$check] = $routes->getByName($routeName) !== null;
        }

        try {
            $menus = app()->make(TitanMenuCompatibilityAdapter::class);
            $checks['user_navigation_registered'] = $menus->isRegistered('dashboard.user.titan.risk.engine.index');
            $checks['admin_navigation_registered'] = $menus->isRegistered('dashboard.admin.titan.risk.engine.control-centre');
        } catch (Throwable) {
            $checks['user_navigation_registered'] = false;
            $checks['admin_navigation_registered'] = false;
        }

        $passed = !in_array(false, $checks, true);
        $evidence = [
            'contract' => 'titan.release-certification.v1',
            'extension' => 'titan-risk-engine',
            'version' => '1.0.0-rc.3',
            'passed' => $passed,
            'host_facts' => [
                'php' => PHP_VERSION,
                'laravel' => method_exists(app(), 'version') ? app()->version() : 'unknown',
                'database_driver' => $this->databaseDriver(),
                'enabled' => (bool) config('titan-risk-engine.enabled', true),
            ],
            'checks' => $checks,
        ];

        if ($this->option('json')) {
            $this->line((string) json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        } else {
            foreach ($checks as $name => $ok) {
                $this->line(sprintf('%s %s', $ok ? 'PASS' : 'FAIL', $name));
            }
        }

        return $passed ? self::SUCCESS : self::FAILURE;
    }

    /** @return array<string, class-string> */
    private function bindingContracts(): array
    {
        return [
            'actor_identity_resolver' => ActorIdentityResolverContract::class,
            'recent_activity_provider' => RecentActivityProviderContract::class,
            'assessment_ledger' => RiskAssessmentLedgerContract::class,
            'manager' => RiskManagerContract::class,
            'decision_router' => RiskDecisionRouterContract::class,
            'gate' => RiskGateContract::class,
            'aggregate' => RiskAggregateContract::class,
            'velocity' => RiskVelocityContract::class,
            'history_reader' => RiskHistoryReaderContract::class,
            'circuit_policy' => RiskCircuitPolicyContract::class,
            'circuit_store' => RiskCircuitStoreContract::class,
            'circuit' => RiskCircuitContract::class,
            'budget_store' => RiskBudgetStoreContract::class,
            'policy_overlay_store' => RiskPolicyOverlayStoreContract::class,
            'policy_change_store' => RiskPolicyChangeStoreContract::class,
            'effective_policy_resolver' => RiskEffectivePolicyResolverContract::class,
            'policy_registry' => RiskPolicyRegistryContract::class,
            'control_centre' => RiskControlCentreContract::class,
            'feedback' => RiskFeedbackContract::class,
            'forge_gate' => RiskForgeGateContract::class,
            'signal_outbox' => RiskSignalOutboxContract::class,
            'signal_publisher' => RiskSignalPublisherContract::class,
            'receipt_store' => RiskEnforcementReceiptStoreContract::class,
            'receipt_verifier' => RiskEnforcementReceiptVerifierContract::class,
            'governance_feedback_store' => RiskGovernanceFeedbackStoreContract::class,
            'runtime_event_sink' => RiskRuntimeEventSinkContract::class,
            'transaction_runner' => RiskTransactionRunnerContract::class,
        ];
    }

    /** @return array<string, list<string>> */
    private function requiredTableColumns(): array
    {
        return [
            'titan_risk_assessments' => ['company_id', 'trace_id', 'correlation_id', 'causation_id', 'capability', 'score', 'level', 'decision', 'policy_version', 'assessed_at'],
            'titan_risk_circuits' => ['company_id', 'scope', 'state', 'version', 'policy_version'],
            'titan_risk_circuit_transitions' => ['company_id', 'from_state', 'to_state', 'trace_id', 'correlation_id', 'causation_id'],
            'titan_risk_signal_outbox' => ['event_id', 'event_type', 'company_id', 'event_payload', 'occurred_at', 'attempts'],
            'titan_risk_enforcement_receipts' => ['receipt_id', 'content_digest', 'company_id', 'capability', 'action', 'request_fingerprint', 'execution_directive', 'may_dispatch'],
            'titan_risk_governance_feedback' => ['company_id', 'source', 'evidence_id', 'execution_directive', 'feedback_payload'],
            'titan_risk_budget_versions' => ['company_id', 'version', 'effective_at', 'content_digest'],
            'titan_risk_policy_overlays' => ['binding_key', 'policy_key', 'version', 'scope', 'constraints', 'effective_at', 'content_digest'],
            'titan_risk_policy_changes' => ['change_id', 'action', 'policy_key', 'version', 'trace_id', 'correlation_id', 'causation_id', 'change_payload'],
        ];
    }

    private function verifyPackageIntegrity(): bool
    {
        try {
            $root = dirname(__DIR__, 2);
            $manifestPath = $root . '/extension.json';
            if (!is_file($manifestPath)) return false;
            $manifest = json_decode((string) file_get_contents($manifestPath), true, 512, JSON_THROW_ON_ERROR);
            $files = $manifest['integrity']['files'] ?? null;
            if (!is_array($files) || $files === []) return false;

            foreach ($files as $relative => $expected) {
                if (!is_string($relative) || !is_string($expected) || str_contains($relative, '..') || str_starts_with($relative, '/')) return false;
                $path = $root . '/' . $relative;
                if (!is_file($path)) return false;
                $actual = hash_file('sha256', $path);
                if (!is_string($actual) || !hash_equals(strtolower($expected), strtolower($actual))) return false;
            }
            return true;
        } catch (Throwable) {
            return false;
        }
    }

    private function laravelVersionAtLeast10(): bool
    {
        try {
            $version = method_exists(app(), 'version') ? (string) app()->version() : '';
            if (!preg_match('/^(\\d+)(?:\\.|$)/', $version, $match)) return false;
            return (int) $match[1] >= 10;
        } catch (Throwable) {
            return false;
        }
    }

    private function databaseDriver(): string
    {
        try {
            return (string) app('db')->connection()->getDriverName();
        } catch (Throwable) {
            return 'unavailable';
        }
    }
}
