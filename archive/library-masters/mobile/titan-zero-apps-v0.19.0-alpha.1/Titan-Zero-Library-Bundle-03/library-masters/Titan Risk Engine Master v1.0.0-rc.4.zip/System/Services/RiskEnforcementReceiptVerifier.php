<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptVerifierContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;

final class RiskEnforcementReceiptVerifier implements RiskEnforcementReceiptVerifierContract
{
    public function __construct(private readonly RiskContextFingerprint $fingerprint = new RiskContextFingerprint()) {}

    public function verify(RiskEnforcementReceipt $receipt, ?RiskContext $expectedContext = null): bool
    {
        $digest = hash('sha256', json_encode($receipt->authorizationPayload(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        if (!hash_equals($receipt->contentDigest, $digest)) return false;
        if ($receipt->receiptId !== 'riskrcpt_' . substr($digest, 0, 40)) return false;
        if ($receipt->mayDispatch !== $receipt->directive->mayDispatchToExecutor()) return false;
        if ($receipt->requestFingerprint === null || strlen($receipt->requestFingerprint) !== 64) return false;
        if ($expectedContext !== null && !hash_equals($receipt->requestFingerprint, $this->fingerprint->authorization($expectedContext))) return false;
        return true;
    }
}
