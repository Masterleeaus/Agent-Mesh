<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

final readonly class RiskReason
{
    public function __construct(
        public string $code,
        public string $message,
        public float $contribution = 0.0,
    ) {}

    /** @return array{code:string,message:string,contribution:float} */
    public function toArray(): array
    {
        return [
            'code' => $this->code,
            'message' => $this->message,
            'contribution' => $this->contribution,
        ];
    }
}
