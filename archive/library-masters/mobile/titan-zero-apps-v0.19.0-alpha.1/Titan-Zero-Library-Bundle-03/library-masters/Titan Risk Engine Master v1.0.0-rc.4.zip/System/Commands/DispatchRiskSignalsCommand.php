<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Commands;

use App\Extensions\TitanRiskEngine\System\Services\RiskSignalDispatcher;
use Illuminate\Console\Command;

final class DispatchRiskSignalsCommand extends Command
{
    protected $signature = 'titan:titan-risk-engine:dispatch-signals {--limit=100 : Maximum pending events to attempt}';
    protected $description = 'Dispatch pending Titan Risk Signal outbox events through the governed Signal bridge.';

    public function handle(RiskSignalDispatcher $dispatcher): int
    {
        $limit = max(1, min(1000, (int) $this->option('limit')));
        $delivered = $dispatcher->dispatchPending($limit);
        $this->info(sprintf('Titan Risk Signal dispatch delivered %d event(s).', $delivered));
        return self::SUCCESS;
    }
}
