<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskBudgetStore implements RiskBudgetStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_budget_versions',
        private readonly ?RiskPolicyIntegrityVerifier $integrity = null,
    ) {}

    public function effectiveFor(int|string $companyId, DateTimeImmutable $asOf): ?RiskOperationalBudget
    {
        $row = $this->database->table($this->table)
            ->where('company_id', $companyId)
            ->where('effective_at', '<=', $this->stamp($asOf))
            ->orderByDesc('effective_at')
            ->orderByDesc('id')
            ->first();
        return $row === null ? null : $this->hydrate($row);
    }

    public function register(RiskOperationalBudget $budget): void
    {
        $now = $this->stamp(new DateTimeImmutable('now', new DateTimeZone('UTC')));
        $this->database->table($this->table)->insert([
            'company_id' => $budget->companyId,
            'version' => $budget->version,
            'max_daily_risk_exposure' => $budget->maxDailyRiskExposure,
            'max_autonomous_single_action_level' => $budget->maxAutonomousSingleActionLevel->value,
            'monitoring_threshold_ratio' => $budget->monitoringThresholdRatio,
            'effective_at' => $this->stamp($budget->effectiveAt),
            'source' => $budget->source,
            'supersedes_version' => $budget->supersedesVersion,
            'content_digest' => $budget->contentDigest(),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }

    public function versionsFor(int|string $companyId): array
    {
        return array_map(fn ($row): RiskOperationalBudget => $this->hydrate($row), $this->database->table($this->table)
            ->where('company_id', $companyId)
            ->orderBy('effective_at')
            ->orderBy('id')
            ->limit(1000)->get()->all());
    }

    private function hydrate(object $row): RiskOperationalBudget
    {
        $budget = new RiskOperationalBudget(
            companyId: $row->company_id,
            version: (string) $row->version,
            maxDailyRiskExposure: (float) $row->max_daily_risk_exposure,
            maxAutonomousSingleActionLevel: RiskLevel::from((string) $row->max_autonomous_single_action_level),
            monitoringThresholdRatio: (float) $row->monitoring_threshold_ratio,
            effectiveAt: new DateTimeImmutable((string) $row->effective_at, new DateTimeZone('UTC')),
            source: (string) $row->source,
            supersedesVersion: $row->supersedes_version === null ? null : (string) $row->supersedes_version,
        );
        ($this->integrity ?? new RiskPolicyIntegrityVerifier())->assertBudgetDigest($budget, (string) $row->content_digest);

        return $budget;
    }

    private function stamp(DateTimeImmutable $at): string
    {
        return $at->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
    }
}
