<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;
use Illuminate\Contracts\Auth\Factory as AuthFactory;
use Illuminate\Http\Request;
use RuntimeException;

/**
 * Default fail-closed actor resolver.
 *
 * Trusted middleware/orchestrators may place titan_actor_type + titan_actor_id
 * on request attributes. Otherwise an authenticated user identity is used.
 * Service/agent integrations without either signal must bind their own resolver.
 */
final class AuthenticatedActorIdentityResolver implements ActorIdentityResolverContract
{
    public function __construct(
        private readonly AuthFactory $auth,
        private readonly Request $request,
    ) {}

    public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity
    {
        $trustedType = $this->request->attributes->get('titan_actor_type');
        $trustedId = $this->request->attributes->get('titan_actor_id');

        if (is_string($trustedType) && trim($trustedType) !== '' && (is_int($trustedId) || is_string($trustedId))) {
            $this->assertClaimMatches($actorType, $claimedActorId, $trustedType, $trustedId);

            return new ActorIdentity($trustedType, $trustedId);
        }

        $user = $this->auth->guard()->user();
        if ($user === null) {
            throw new RuntimeException('Risk actor identity could not be resolved from a trusted source.');
        }

        $actualId = $user->getAuthIdentifier();
        $actualType = 'user';
        $this->assertClaimMatches($actorType, $claimedActorId, $actualType, $actualId);

        return new ActorIdentity($actualType, $actualId);
    }

    private function assertClaimMatches(
        string $claimedType,
        int|string|null $claimedId,
        string $trustedType,
        int|string $trustedId,
    ): void {
        if (strtolower(trim($claimedType)) !== strtolower(trim($trustedType))) {
            throw new RuntimeException('Claimed risk actor type does not match trusted actor identity.');
        }

        if ($claimedId !== null && (string) $claimedId !== (string) $trustedId) {
            throw new RuntimeException('Claimed risk actor id does not match trusted actor identity.');
        }
    }
}
