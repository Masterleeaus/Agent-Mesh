<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitPolicyContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;
use InvalidArgumentException;

final class RiskCircuitManager
{
    public function __construct(
        private readonly RiskCircuitStoreContract $store,
        private readonly RiskCircuitPolicyContract $policy,
        private readonly int $requiredSuccessfulProbes = 2,
    ) {}

    public function reconcile(
        RiskCircuitSnapshot $current,
        RiskExposureSnapshot $exposure,
        RiskVelocityAssessment $velocity,
        RiskCircuitTransitionEvidence $evidence,
    ): RiskCircuitSnapshot {
        $recommended = $this->policy->recommend($current, $exposure, $velocity, $evidence->occurredAt);
        if ($recommended->recommendedState === $current->state
            && $recommended->probeAfter == $current->probeAfter
            && $recommended->expiresAt == $current->expiresAt) {
            return $current;
        }

        return $this->store->apply(
            $current,
            $recommended->recommendedState,
            $recommended->reasonCodes,
            $evidence->occurredAt,
            $recommended->probeAfter,
            $recommended->expiresAt,
            $recommended->recommendedState === RiskCircuitState::HALF_OPEN ? $current->successfulProbeCount : 0,
            $evidence,
        );
    }

    public function recordProbe(
        RiskCircuitSnapshot $current,
        bool $successful,
        bool $supervised,
        RiskExposureSnapshot $exposure,
        RiskVelocityAssessment $velocity,
        RiskCircuitTransitionEvidence $evidence,
    ): RiskCircuitSnapshot {
        if (!$supervised) throw new InvalidArgumentException('Risk circuit recovery probes must be supervised.');
        if ($current->state !== RiskCircuitState::HALF_OPEN) throw new InvalidArgumentException('Risk circuit recovery probes are only valid in HALF_OPEN state.');

        $health = $this->policy->recommend($current, $exposure, $velocity, $evidence->occurredAt);
        if ($health->recommendedState === RiskCircuitState::OPEN || !$successful) {
            $reasons = !$successful ? ['RECOVERY_PROBE_FAILED'] : $health->reasonCodes;
            $probeAfter = $health->probeAfter ?? $evidence->occurredAt->modify('+300 seconds');
            $expiresAt = $health->expiresAt ?? $evidence->occurredAt->modify('+3600 seconds');
            return $this->store->apply($current, RiskCircuitState::OPEN, $reasons, $evidence->occurredAt, $probeAfter, $expiresAt, 0, $evidence);
        }

        if ($velocity->level === RiskVelocityLevel::HIGH || $velocity->level === RiskVelocityLevel::CRITICAL || $exposure->blockedCount > 0 || $exposure->extremeCount > 0) {
            return $this->store->apply($current, RiskCircuitState::OPEN, ['RECOVERY_PRESSURE_REGRESSION'], $evidence->occurredAt, $evidence->occurredAt->modify('+300 seconds'), $evidence->occurredAt->modify('+3600 seconds'), 0, $evidence);
        }

        $count = $current->successfulProbeCount + 1;
        if ($count >= max(2, $this->requiredSuccessfulProbes)) {
            return $this->store->apply($current, RiskCircuitState::CLOSED, ['RECOVERY_PROBES_SATISFIED'], $evidence->occurredAt, null, null, 0, $evidence);
        }

        return $this->store->apply($current, RiskCircuitState::HALF_OPEN, ['RECOVERY_PROBE_SUCCEEDED'], $evidence->occurredAt, $current->probeAfter, $current->expiresAt, $count, $evidence);
    }

    public function mayDispatch(RiskCircuitSnapshot $circuit): bool
    {
        return $circuit->state === RiskCircuitState::CLOSED;
    }
}
