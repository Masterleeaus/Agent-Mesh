<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\ActorIdentity;

interface ActorIdentityResolverContract
{
    public function resolve(string $actorType, int|string|null $claimedActorId = null): ActorIdentity;
}
