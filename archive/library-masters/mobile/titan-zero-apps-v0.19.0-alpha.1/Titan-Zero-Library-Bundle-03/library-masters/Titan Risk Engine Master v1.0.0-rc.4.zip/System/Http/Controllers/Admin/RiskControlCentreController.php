<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

final class RiskControlCentreController
{
    public function __invoke(Request $request, RiskControlCentreContract $controlCentre): View
    {
        $validated = $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'capability' => ['nullable', 'string', 'max:160'],
        ]);
        $companyId = isset($validated['company_id']) ? (int) $validated['company_id'] : null;
        $capability = isset($validated['capability']) && trim((string) $validated['capability']) !== '' ? trim((string) $validated['capability']) : null;
        $snapshot = $companyId === null ? null : $controlCentre->snapshot($companyId, $capability);

        return view('titan-risk-engine::admin.control-centre', [
            'snapshot' => $snapshot,
            'companyId' => $companyId,
            'capability' => $capability,
        ]);
    }
}
