<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use DateTimeImmutable;

interface RiskCircuitStoreContract
{
    public function get(RiskCircuitKey $key): ?RiskCircuitSnapshot;

    public function getOrCreate(RiskCircuitKey $key, DateTimeImmutable $at, string $policyVersion): RiskCircuitSnapshot;

    /** @param list<string> $reasonCodes */
    public function apply(
        RiskCircuitSnapshot $expected,
        RiskCircuitState $nextState,
        array $reasonCodes,
        DateTimeImmutable $at,
        ?DateTimeImmutable $probeAfter,
        ?DateTimeImmutable $expiresAt,
        int $successfulProbeCount,
        RiskCircuitTransitionEvidence $evidence,
    ): RiskCircuitSnapshot;
}
