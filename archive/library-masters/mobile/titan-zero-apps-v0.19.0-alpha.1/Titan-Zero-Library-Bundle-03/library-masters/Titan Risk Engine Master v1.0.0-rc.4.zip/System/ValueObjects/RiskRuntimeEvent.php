<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

final readonly class RiskRuntimeEvent
{
    public function __construct(
        public string $operation,
        public string $outcome,
        public float $elapsedMilliseconds,
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $capability,
        public ?string $errorClass = null,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'operation' => $this->operation,
            'outcome' => $this->outcome,
            'elapsed_ms' => round($this->elapsedMilliseconds, 4),
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'capability' => $this->capability,
            'error_class' => $this->errorClass,
        ];
    }
}
