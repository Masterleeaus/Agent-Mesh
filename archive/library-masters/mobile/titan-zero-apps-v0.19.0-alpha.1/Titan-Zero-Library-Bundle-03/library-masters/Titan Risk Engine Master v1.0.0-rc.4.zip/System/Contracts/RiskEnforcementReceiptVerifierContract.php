<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;

interface RiskEnforcementReceiptVerifierContract
{
    public function verify(RiskEnforcementReceipt $receipt, ?RiskContext $expectedContext = null): bool;
}
