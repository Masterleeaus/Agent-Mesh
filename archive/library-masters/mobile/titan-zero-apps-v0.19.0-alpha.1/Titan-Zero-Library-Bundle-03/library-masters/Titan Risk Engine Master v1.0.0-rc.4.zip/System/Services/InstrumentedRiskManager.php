<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use Throwable;

final class InstrumentedRiskManager implements RiskManagerContract
{
    public function __construct(
        private readonly RiskManagerContract $inner,
        private readonly RiskRuntimeEventSinkContract $runtimeEvents,
        private readonly float $targetMilliseconds = 50.0,
    ) {}

    public function health(): array
    {
        return $this->inner->health();
    }

    public function assess(RiskContext $context): RiskAssessment
    {
        $started = hrtime(true);
        try {
            $assessment = $this->inner->assess($context);
            $elapsed = $this->elapsed($started);
            $this->record($context, $elapsed > $this->targetMilliseconds ? 'SLA_BREACH' : 'OK', $elapsed, null);
            return $assessment;
        } catch (Throwable $failure) {
            $this->record($context, 'FAILED', $this->elapsed($started), $failure::class);
            throw $failure;
        }
    }

    private function elapsed(int $started): float
    {
        return (hrtime(true) - $started) / 1_000_000;
    }

    private function record(RiskContext $context, string $outcome, float $elapsed, ?string $errorClass): void
    {
        try {
            $this->runtimeEvents->record(new RiskRuntimeEvent(
                operation: 'risk.assess',
                outcome: $outcome,
                elapsedMilliseconds: $elapsed,
                companyId: $context->companyId,
                traceId: $context->traceId,
                correlationId: $context->correlationId,
                causationId: $context->causationId,
                capability: $context->capability,
                errorClass: $errorClass,
            ));
        } catch (Throwable) {
            // Instrumentation is non-authoritative and must not change the Risk result.
        }
    }
}
