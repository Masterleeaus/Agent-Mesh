<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use InvalidArgumentException;

final readonly class RiskImpactVector
{
    public function __construct(
        public float $financial = 0.0,
        public float $safety = 0.0,
        public float $privacy = 0.0,
        public float $legal = 0.0,
        public float $operational = 0.0,
        public float $reputation = 0.0,
    ) {
        foreach ($this->toArray() as $dimension => $value) {
            if (!is_finite($value) || $value < 0.0 || $value > 100.0) {
                throw new InvalidArgumentException(sprintf('%s impact must be between 0 and 100.', $dimension));
            }
        }
    }

    /** @return array<string, float> */
    public function toArray(): array
    {
        return [
            'financial' => $this->financial,
            'safety' => $this->safety,
            'privacy' => $this->privacy,
            'legal' => $this->legal,
            'operational' => $this->operational,
            'reputation' => $this->reputation,
        ];
    }

    public function maximum(): float
    {
        return max($this->toArray());
    }
}
