<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;
use RuntimeException;
use Throwable;

final class DatabaseRiskCircuitStore implements RiskCircuitStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_circuits',
        private readonly string $transitionTable = 'titan_risk_circuit_transitions',
        private readonly ?RiskSignalOutboxContract $signalOutbox = null,
        private readonly int $transactionAttempts = 3,
        private readonly ?RiskRuntimeEventSinkContract $runtimeEvents = null,
    ) {}

    public function get(RiskCircuitKey $key): ?RiskCircuitSnapshot
    {
        $row = $this->database->table($this->table)
            ->where('company_id', $key->companyId)
            ->where('scope', $key->scope->value)
            ->where('capability_key', $key->capabilityKey())
            ->first();
        return $row === null ? null : $this->map($row);
    }

    public function getOrCreate(RiskCircuitKey $key, DateTimeImmutable $at, string $policyVersion): RiskCircuitSnapshot
    {
        $existing = $this->get($key);
        if ($existing !== null) return $existing;

        $utc = new DateTimeZone('UTC');
        $stamp = $at->setTimezone($utc)->format('Y-m-d H:i:s.u');
        try {
            $this->database->table($this->table)->insert([
                'company_id' => $key->companyId,
                'scope' => $key->scope->value,
                'capability' => $key->capability,
                'capability_key' => $key->capabilityKey(),
                'state' => RiskCircuitState::CLOSED->value,
                'version' => 1,
                'reason_codes' => json_encode([], JSON_THROW_ON_ERROR),
                'policy_version' => $policyVersion,
                'successful_probe_count' => 0,
                'last_transition_at' => $stamp,
                'created_at' => $stamp,
                'updated_at' => $stamp,
            ]);
        } catch (QueryException) {
            // Concurrent getOrCreate is expected; canonical row wins.
        }

        $created = $this->get($key);
        if ($created === null) throw new RuntimeException('RISK_CIRCUIT_CREATE_FAILED');
        return $created;
    }

    public function apply(
        RiskCircuitSnapshot $expected,
        RiskCircuitState $nextState,
        array $reasonCodes,
        DateTimeImmutable $at,
        ?DateTimeImmutable $probeAfter,
        ?DateTimeImmutable $expiresAt,
        int $successfulProbeCount,
        RiskCircuitTransitionEvidence $evidence,
    ): RiskCircuitSnapshot {
        $persisted = $this->database->transaction(function () use ($expected, $nextState, $reasonCodes, $at, $probeAfter, $expiresAt, $successfulProbeCount, $evidence): RiskCircuitSnapshot {
            $builder = $this->database->table($this->table)
                ->where('company_id', $expected->key->companyId)
                ->where('scope', $expected->key->scope->value)
                ->where('capability_key', $expected->key->capabilityKey());
            $row = $builder->lockForUpdate()->first();
            if ($row === null || (int) $row->version !== $expected->version || (string) $row->state !== $expected->state->value) {
                throw new RuntimeException('STALE_CIRCUIT_VERSION');
            }

            $next = $expected->transitioned($nextState, $reasonCodes, $at, $probeAfter, $expiresAt, $successfulProbeCount);
            $utc = new DateTimeZone('UTC');
            $format = static fn (?DateTimeImmutable $value): ?string => $value?->setTimezone($utc)->format('Y-m-d H:i:s.u');

            $builder->update([
                'state' => $next->state->value,
                'version' => $next->version,
                'reason_codes' => json_encode($next->reasonCodes, JSON_THROW_ON_ERROR),
                'policy_version' => $next->policyVersion,
                'opened_at' => $format($next->openedAt),
                'half_opened_at' => $format($next->halfOpenedAt),
                'probe_after' => $format($next->probeAfter),
                'expires_at' => $format($next->expiresAt),
                'successful_probe_count' => $next->successfulProbeCount,
                'last_transition_at' => $format($next->lastTransitionAt),
                'updated_at' => $format($at),
            ]);

            $this->database->table($this->transitionTable)->insert([
                'circuit_id' => $row->id,
                'company_id' => $expected->key->companyId,
                'scope' => $expected->key->scope->value,
                'capability' => $expected->key->capability,
                'from_state' => $expected->state->value,
                'to_state' => $nextState->value,
                'resulting_version' => $next->version,
                'reason_codes' => json_encode(array_values(array_unique($reasonCodes)), JSON_THROW_ON_ERROR),
                'policy_version' => $evidence->policyVersion,
                'trace_id' => $evidence->traceId,
                'correlation_id' => $evidence->correlationId,
                'causation_id' => $evidence->causationId,
                'occurred_at' => $format($evidence->occurredAt),
                'created_at' => $format($evidence->occurredAt),
                'updated_at' => $format($evidence->occurredAt),
            ]);

            return new RiskCircuitSnapshot(
                $next->key, $next->state, $next->version, $next->reasonCodes, $next->policyVersion,
                $next->lastTransitionAt, $next->openedAt, $next->halfOpenedAt, $next->probeAfter,
                $next->expiresAt, $next->successfulProbeCount, $row->id,
            );
        }, max(1, min(5, $this->transactionAttempts)));

        $this->stageCircuitSignal($expected, $persisted, $evidence);
        return $persisted;
    }

    private function stageCircuitSignal(RiskCircuitSnapshot $before, RiskCircuitSnapshot $after, RiskCircuitTransitionEvidence $evidence): void
    {
        if ($this->signalOutbox === null) return;
        try {
            $signal = RiskSignalEvent::forCircuitTransition($before, $after, $evidence);
            if ($signal !== null) $this->signalOutbox->stage($signal);
        } catch (Throwable $failure) {
            if ($this->runtimeEvents === null) return;
            try {
                $this->runtimeEvents->record(new RiskRuntimeEvent(
                    operation: 'risk.circuit',
                    outcome: 'CIRCUIT_SIGNAL_OUTBOX_DEGRADED',
                    elapsedMilliseconds: 0.0,
                    companyId: $after->key->companyId,
                    traceId: $evidence->traceId,
                    correlationId: $evidence->correlationId,
                    causationId: $evidence->causationId,
                    capability: $after->key->capability ?? 'tenant',
                    errorClass: $failure::class,
                ));
            } catch (Throwable) {
                // Telemetry failure cannot change circuit state or authority.
            }
        }
    }

    private function map(object $row): RiskCircuitSnapshot
    {
        $utc = new DateTimeZone('UTC');
        $date = static fn ($value): ?DateTimeImmutable => $value === null ? null : new DateTimeImmutable((string) $value, $utc);
        $reasons = json_decode((string) ($row->reason_codes ?? '[]'), true);
        return new RiskCircuitSnapshot(
            new RiskCircuitKey(
                $row->company_id,
                RiskCircuitScope::from((string) $row->scope),
                (string) $row->scope === RiskCircuitScope::TENANT->value ? null : (string) $row->capability,
            ),
            RiskCircuitState::from((string) $row->state),
            (int) $row->version,
            is_array($reasons) ? array_values(array_map('strval', $reasons)) : [],
            (string) $row->policy_version,
            $date($row->last_transition_at) ?? new DateTimeImmutable('now', $utc),
            $date($row->opened_at ?? null),
            $date($row->half_opened_at ?? null),
            $date($row->probe_after ?? null),
            $date($row->expires_at ?? null),
            (int) ($row->successful_probe_count ?? 0),
            $row->id ?? null,
        );
    }
}
