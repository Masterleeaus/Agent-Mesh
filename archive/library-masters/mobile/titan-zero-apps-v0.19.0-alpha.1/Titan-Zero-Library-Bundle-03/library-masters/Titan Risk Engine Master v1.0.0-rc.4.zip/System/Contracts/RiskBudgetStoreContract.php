<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use DateTimeImmutable;

interface RiskBudgetStoreContract
{
    public function effectiveFor(int|string $companyId, DateTimeImmutable $asOf): ?RiskOperationalBudget;

    public function register(RiskOperationalBudget $budget): void;

    /** @return list<RiskOperationalBudget> */
    public function versionsFor(int|string $companyId): array;
}
