<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskAggregateScope: string
{
    case TENANT = 'TENANT';
    case TENANT_CAPABILITY = 'TENANT_CAPABILITY';
    case TENANT_ACTOR = 'TENANT_ACTOR';
    case TENANT_RESOURCE = 'TENANT_RESOURCE';
    case ACTOR_CAPABILITY = 'ACTOR_CAPABILITY';
}
