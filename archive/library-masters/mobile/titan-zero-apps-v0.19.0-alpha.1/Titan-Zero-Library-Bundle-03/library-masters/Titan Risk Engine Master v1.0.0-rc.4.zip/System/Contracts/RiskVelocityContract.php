<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;

interface RiskVelocityContract
{
    public function assess(RiskHistoryQuery $query): RiskVelocityAssessment;
}
