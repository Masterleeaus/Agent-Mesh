<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransition;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;
use DateTimeImmutable;

interface RiskCircuitPolicyContract
{
    public function recommend(
        RiskCircuitSnapshot $circuit,
        RiskExposureSnapshot $exposure,
        RiskVelocityAssessment $velocity,
        DateTimeImmutable $asOf,
    ): RiskCircuitTransition;
}
