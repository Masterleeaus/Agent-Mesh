<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskSignalType;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskReason;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRemediation;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use DateTimeImmutable;
use DateTimeZone;
use Throwable;

final class RiskManager implements RiskManagerContract
{
    public function __construct(
        private readonly BaselineRiskScorer $scorer,
        private readonly RecentActivityProviderContract $recentActivity,
        private readonly RiskMetadataSanitizer $metadataSanitizer,
        private readonly int $recentActivityLimit = 10,
        private readonly ?RiskAssessmentLedgerContract $ledger = null,
        private readonly ?RiskSignalOutboxContract $signalOutbox = null,
        private readonly ?RiskSignalDispatcher $signalDispatcher = null,
        private readonly bool $inlineSignalDispatch = false,
        private readonly ?RiskRuntimeEventSinkContract $runtimeEvents = null,
        private readonly ?RiskIdempotencyGuard $idempotencyGuard = null,
        private readonly bool $enabled = true,
    ) {}

    public function health(): array
    {
        return [
            'engine' => 'titan-risk-engine',
            'status' => $this->enabled ? 'HEALTHY' : 'DISABLED',
            'version' => '1.0.0-rc.3',
            'capabilities' => ['risk.assess', 'risk.gate', 'risk.aggregate', 'risk.velocity', 'risk.circuit', 'risk.feedback'],
        ];
    }

    public function assess(RiskContext $context): RiskAssessment
    {
        if (!$this->enabled) {
            return new RiskAssessment(
                context: $context->withRecentActivity([])->withMetadata([]),
                score: 100.0,
                level: RiskLevel::EXTREME,
                decision: RiskDecision::BLOCK,
                reasons: [new RiskReason('RISK_ENGINE_DISABLED', 'Titan Risk Engine is disabled; autonomous execution is not authorized.')],
                policyVersion: 'disabled-v1',
                assessedAt: new DateTimeImmutable('now', new DateTimeZone('UTC')),
                remediation: [new RiskRemediation('ENABLE_RISK_ENGINE', 'Enable Titan Risk Engine through governed host configuration before retrying.')],
            );
        }

        $trustedContext = $context
            ->withRecentActivity($this->recentActivity->recentFor(
                $context->companyId,
                $context->actorType,
                $context->actorId,
                $this->recentActivityLimit,
            ))
            ->withMetadata($this->metadataSanitizer->sanitize($context->metadata));

        if ($trustedContext->idempotencyKey !== null && $this->ledger !== null) {
            $existing = $this->ledger->findByIdempotencyKey($trustedContext->companyId, $trustedContext->idempotencyKey);
            if ($existing !== null) {
                ($this->idempotencyGuard ?? new RiskIdempotencyGuard())->assertCompatible($trustedContext, $existing);
                $this->stageSignals($existing, false);
                return $existing;
            }
        }

        $assessment = $this->scorer->assess($trustedContext);
        $created = true;
        if ($this->ledger !== null) {
            $write = $this->ledger->persist($assessment);
            $assessment = $write->assessment;
            $created = $write->created;
            if (!$created && $trustedContext->idempotencyKey !== null) {
                ($this->idempotencyGuard ?? new RiskIdempotencyGuard())->assertCompatible($trustedContext, $assessment);
            }
            if ($created) $this->recentActivity->record($assessment);
        } else {
            $this->recentActivity->record($assessment);
        }

        $this->stageSignals($assessment, $created);
        return $assessment;
    }

    private function stageSignals(RiskAssessment $assessment, bool $created): void
    {
        if ($this->signalOutbox === null) return;
        try {
            $this->signalOutbox->stage(RiskSignalEvent::forAssessment($assessment, RiskSignalType::RISK_ASSESSED));
            if ($created) {
                $this->signalOutbox->stage(RiskSignalEvent::forAssessment($assessment, RiskSignalType::EXPOSURE_INCREASED));
            }
            if (in_array($assessment->level, [RiskLevel::HIGH, RiskLevel::EXTREME], true)) {
                $this->signalOutbox->stage(RiskSignalEvent::forAssessment($assessment, RiskSignalType::THRESHOLD_CROSSED));
            }
            if ($this->inlineSignalDispatch) {
                $this->signalDispatcher?->dispatchPending(10);
            }
        } catch (Throwable $failure) {
            // Signal transport is secondary evidence delivery; durable Risk authority must remain available.
            $this->recordRuntime($assessment, 'SIGNAL_OUTBOX_DEGRADED', $failure::class);
        }
    }

    private function recordRuntime(RiskAssessment $assessment, string $outcome, ?string $errorClass): void
    {
        if ($this->runtimeEvents === null) return;
        try {
            $context = $assessment->context;
            $this->runtimeEvents->record(new RiskRuntimeEvent(
                operation: 'risk.assess',
                outcome: $outcome,
                elapsedMilliseconds: 0.0,
                companyId: $context->companyId,
                traceId: $context->traceId,
                correlationId: $context->correlationId,
                causationId: $context->causationId,
                capability: $context->capability,
                errorClass: $errorClass,
            ));
        } catch (Throwable) {
            // Telemetry failure cannot change Risk authority.
        }
    }
}
