<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;

interface RiskSignalPublisherContract
{
    /** Returns true only when a downstream Signal listener accepted dispatch. */
    public function publish(RiskSignalEvent $event): bool;
}
