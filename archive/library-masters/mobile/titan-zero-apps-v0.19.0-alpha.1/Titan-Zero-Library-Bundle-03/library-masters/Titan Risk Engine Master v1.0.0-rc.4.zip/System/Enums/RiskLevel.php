<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskLevel: string
{
    case MINIMAL = 'MINIMAL';
    case LOW = 'LOW';
    case MEDIUM = 'MEDIUM';
    case HIGH = 'HIGH';
    case EXTREME = 'EXTREME';

    public static function fromScore(float $score): self
    {
        return match (true) {
            $score < 20.0 => self::MINIMAL,
            $score < 40.0 => self::LOW,
            $score < 60.0 => self::MEDIUM,
            $score < 80.0 => self::HIGH,
            default => self::EXTREME,
        };
    }
}
