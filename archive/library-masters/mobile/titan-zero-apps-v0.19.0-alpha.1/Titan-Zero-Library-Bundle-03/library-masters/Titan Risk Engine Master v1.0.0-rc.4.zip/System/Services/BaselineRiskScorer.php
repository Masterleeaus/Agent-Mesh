<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Enums\ConnectivityState;
use App\Extensions\TitanRiskEngine\System\Enums\Reversibility;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskReason;
use DateTimeImmutable;

final class BaselineRiskScorer
{
    private const POLICY_VERSION = 'baseline-v1';

    public function __construct(
        private readonly MitigationSuggestionGenerator $mitigations = new MitigationSuggestionGenerator(),
    ) {}

    public function assess(RiskContext $context): RiskAssessment
    {
        $impact = $context->impact;
        $weighted = ($impact->financial * 0.20)
            + ($impact->safety * 0.25)
            + ($impact->privacy * 0.20)
            + ($impact->legal * 0.20)
            + ($impact->operational * 0.10)
            + ($impact->reputation * 0.05);

        // A single severe impact dimension must not be hidden by averaging.
        $score = max($weighted, $impact->maximum() * 0.80);
        $reasons = $this->impactReasons($context);

        if ($context->reversibility === Reversibility::PARTIALLY_REVERSIBLE) {
            $score += 5.0;
            $reasons[] = new RiskReason('PARTIAL_REVERSIBILITY', 'Action is only partially reversible.', 5.0);
        } elseif ($context->reversibility === Reversibility::IRREVERSIBLE) {
            $score += 12.0;
            $reasons[] = new RiskReason('IRREVERSIBLE_ACTION', 'Action is irreversible.', 12.0);
        }

        if ($context->connectivity === ConnectivityState::DEGRADED) {
            $score += 5.0;
            $reasons[] = new RiskReason('DEGRADED_CONNECTIVITY', 'Connectivity is degraded; authority must not increase.', 5.0);
        } elseif ($context->connectivity === ConnectivityState::OFFLINE) {
            $score += 12.0;
            $reasons[] = new RiskReason('OFFLINE_EXECUTION', 'Execution is offline; authority must not increase.', 12.0);
        }

        $score = round(min(100.0, max(0.0, $score)), 2);
        $level = RiskLevel::fromScore($score);
        $decision = $this->decisionFor($level, $context);

        if ($reasons === []) {
            $reasons[] = new RiskReason('NO_MATERIAL_RISK_SIGNAL', 'No material baseline risk signal detected.', 0.0);
        }

        return new RiskAssessment(
            context: $context,
            score: $score,
            level: $level,
            decision: $decision,
            reasons: $reasons,
            policyVersion: self::POLICY_VERSION,
            assessedAt: new DateTimeImmutable(),
            remediation: $this->mitigations->for($reasons, $decision),
        );
    }

    /** @return list<RiskReason> */
    private function impactReasons(RiskContext $context): array
    {
        $reasons = [];

        foreach ($context->impact->toArray() as $dimension => $value) {
            if ($value >= 40.0) {
                $reasons[] = new RiskReason(
                    'IMPACT_' . strtoupper($dimension),
                    sprintf('%s impact is material.', ucfirst($dimension)),
                    round($value, 2),
                );
            }
        }

        return $reasons;
    }

    private function decisionFor(RiskLevel $level, RiskContext $context): RiskDecision
    {
        if ($context->connectivity === ConnectivityState::OFFLINE && $level !== RiskLevel::MINIMAL) {
            return RiskDecision::REDUCE_AUTHORITY;
        }

        return match ($level) {
            RiskLevel::MINIMAL => RiskDecision::ALLOW,
            RiskLevel::LOW => RiskDecision::ALLOW_WITH_MONITORING,
            RiskLevel::MEDIUM => RiskDecision::REQUIRE_ASSURANCE,
            RiskLevel::HIGH => RiskDecision::REQUIRE_APPROVAL,
            RiskLevel::EXTREME => RiskDecision::BLOCK,
        };
    }
}
