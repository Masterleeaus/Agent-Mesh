<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;

interface RiskRuntimeEventSinkContract
{
    public function record(RiskRuntimeEvent $event): void;
}
