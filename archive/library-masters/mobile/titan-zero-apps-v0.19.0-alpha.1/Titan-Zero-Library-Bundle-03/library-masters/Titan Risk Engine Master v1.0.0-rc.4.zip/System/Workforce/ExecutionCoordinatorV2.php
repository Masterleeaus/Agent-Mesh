<?php
declare(strict_types=1);
namespace App\Extensions\TitanRiskEngine\System\Workforce;
final class ExecutionCoordinatorV2 {
 public function __construct(private ReceiptRegistry $receipts,private DurableIdempotencyRegistry $idempotency,private CircuitBreaker $circuit,private ExecutionTelemetrySink $telemetry) {}
 public function execute(array $request,array $health,array $decision,CommandBusAdapter $adapter,int $now): array {
  foreach(['company_id','correlation_id','idempotency_key','provider','provider_version','capability_id'] as $k) if(empty($request[$k])) return $this->deny('request.'.$k.'.missing',$request);
  if(!$this->circuit->allow($now)) return $this->deny('circuit.open',$request);
  if(($health['decision']??'deny')!=='allow') return $this->deny('provider.unhealthy',$request);
  if(($decision['decision']??'deny')!=='allow') return $this->deny('guardrail.not_allowed',$request);
  if(!$adapter->ready()) return $this->deny('command_bus.adapter_unavailable',$request);
  $fingerprint=hash('sha256',json_encode([$request['company_id'],$request['provider'],$request['provider_version'],$request['capability_id'],$request['idempotency_key']],JSON_UNESCAPED_SLASHES));
  $claim=$this->idempotency->claim((string)$request['company_id'],(string)$request['idempotency_key'],$fingerprint);
  if(($claim['state']??'')==='completed' && isset($claim['receipt']) && is_array($claim['receipt'])) return ['decision'=>'replay','receipt'=>$claim['receipt'],'reason_codes'=>['idempotency.replay']];
  if(($claim['state']??'')!=='claimed') return $this->deny('idempotency.conflict_or_inflight',$request);
  try {
   $outcome=$adapter->execute($request);
   if(($outcome['status']??'failed')!=='succeeded') { $this->circuit->failure($now); $this->idempotency->fail((string)$request['company_id'],(string)$request['idempotency_key'],'command.failed'); return $this->deny('command.failed',$request); }
   $receipt=['receipt_id'=>(string)($outcome['receipt_id']??hash('sha256',$fingerprint.'|'.$request['correlation_id'])),'company_id'=>(string)$request['company_id'],'correlation_id'=>(string)$request['correlation_id'],'idempotency_key'=>(string)$request['idempotency_key'],'provider'=>(string)$request['provider'],'provider_version'=>(string)$request['provider_version'],'capability_id'=>(string)$request['capability_id'],'outcome'=>$outcome];
   $this->receipts->store($receipt); $this->idempotency->complete((string)$request['company_id'],(string)$request['idempotency_key'],$receipt); $this->circuit->success(); $this->telemetry->record(['event'=>'workforce.command.succeeded','company_id'=>$request['company_id'],'correlation_id'=>$request['correlation_id'],'capability_id'=>$request['capability_id']]);
   return ['decision'=>'executed','receipt'=>$receipt,'reason_codes'=>[]];
  } catch(\Throwable $e) { $this->circuit->failure($now); $this->idempotency->fail((string)$request['company_id'],(string)$request['idempotency_key'],'command.exception'); $this->telemetry->record(['event'=>'workforce.command.failed','company_id'=>$request['company_id'],'correlation_id'=>$request['correlation_id'],'reason'=>'exception']); return $this->deny('command.exception',$request); }
 }
 private function deny(string $reason,array $request): array { $this->telemetry->record(['event'=>'workforce.command.denied','company_id'=>(string)($request['company_id']??''),'correlation_id'=>(string)($request['correlation_id']??''),'reason'=>$reason]); return ['decision'=>'deny','reason_codes'=>[$reason]]; }
}
