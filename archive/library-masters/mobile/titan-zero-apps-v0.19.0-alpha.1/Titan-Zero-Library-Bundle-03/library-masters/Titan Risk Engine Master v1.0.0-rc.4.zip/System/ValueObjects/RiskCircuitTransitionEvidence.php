<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskCircuitTransitionEvidence
{
    public function __construct(
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public DateTimeImmutable $occurredAt,
        public string $policyVersion,
        public ?RiskCircuitState $fromState = null,
        public ?RiskCircuitState $toState = null,
        public ?int $resultingVersion = null,
    ) {
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        RiskFieldConstraints::text('policyVersion', $this->policyVersion, 80, false);
        if ($this->resultingVersion !== null && $this->resultingVersion <= 0) {
            throw new InvalidArgumentException('Circuit resulting version must be positive.');
        }
    }

    public function withStates(RiskCircuitState $from, RiskCircuitState $to, int $version): self
    {
        return new self($this->traceId, $this->correlationId, $this->causationId, $this->occurredAt, $this->policyVersion, $from, $to, $version);
    }
}
