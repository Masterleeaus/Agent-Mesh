<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use RuntimeException;

final class RiskPolicyIntegrityVerifier
{
    public function assertBudgetDigest(RiskOperationalBudget $budget, string $expectedDigest): void
    {
        $this->assertDigest($budget->contentDigest(), $expectedDigest);
    }

    public function assertOverlayDigest(RiskPolicyOverlay $overlay, string $expectedDigest): void
    {
        $this->assertDigest($overlay->contentDigest(), $expectedDigest);
    }

    private function assertDigest(string $actualDigest, string $expectedDigest): void
    {
        if (strlen($expectedDigest) !== 64 || !ctype_xdigit($expectedDigest) || !hash_equals(strtolower($expectedDigest), strtolower($actualDigest))) {
            throw new RuntimeException('RISK_POLICY_INTEGRITY_MISMATCH');
        }
    }
}
