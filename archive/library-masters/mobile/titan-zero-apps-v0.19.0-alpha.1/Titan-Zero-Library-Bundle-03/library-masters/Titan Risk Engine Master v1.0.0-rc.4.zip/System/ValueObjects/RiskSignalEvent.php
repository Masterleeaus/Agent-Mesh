<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskSignalType;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskSignalEvent
{
    /** @param array<string,mixed> $payload */
    public function __construct(
        public string $eventId,
        public RiskSignalType $type,
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $rootCausationId,
        public DateTimeImmutable $occurredAt,
        public string $severity,
        public array $payload,
    ) {
        foreach ([$eventId, $traceId, $correlationId, $causationId, $rootCausationId, $severity] as $value) {
            if (trim($value) === '') throw new InvalidArgumentException('Risk Signal event requires identity, causal lineage and severity.');
        }
    }

    public static function forAssessment(RiskAssessment $assessment, RiskSignalType $type): self
    {
        $context = $assessment->context;
        $payload = [
            'capability' => $context->capability,
            'action' => $context->action,
            'actor_type' => $context->actorType,
            'resource_type' => $context->resourceType,
            'resource_id' => $context->resourceId === null ? null : (string) $context->resourceId,
            'score' => $assessment->score,
            'level' => $assessment->level->value,
            'decision' => $assessment->decision->value,
            'policy_version' => $assessment->policyVersion,
            'reversibility' => $context->reversibility->value,
            'connectivity' => $context->connectivity->value,
            'reason_codes' => array_map(static fn (RiskReason $reason): string => $reason->code, $assessment->reasons),
        ];
        return self::make($type, $context->companyId, $context->traceId, $context->correlationId, $context->causationId, $assessment->assessedAt, self::severityForLevel($assessment->level), $payload);
    }

    public static function forCircuitTransition(
        RiskCircuitSnapshot $before,
        RiskCircuitSnapshot $after,
        RiskCircuitTransitionEvidence $evidence,
    ): ?self {
        $type = null;
        if (in_array('RECOVERY_PROBE_FAILED', $after->reasonCodes, true)) {
            $type = RiskSignalType::CIRCUIT_PROBE_FAILED;
        } elseif ($before->state !== $after->state) {
            $type = match ($after->state) {
                RiskCircuitState::OPEN => RiskSignalType::CIRCUIT_OPENED,
                RiskCircuitState::HALF_OPEN => RiskSignalType::CIRCUIT_HALF_OPENED,
                RiskCircuitState::CLOSED => RiskSignalType::CIRCUIT_CLOSED,
            };
        }
        if ($type === null) return null;
        $payload = [
            'scope' => $after->key->scope->value,
            'capability' => $after->key->capability,
            'from_state' => $before->state->value,
            'to_state' => $after->state->value,
            'resulting_version' => $after->version,
            'reason_codes' => $after->reasonCodes,
            'policy_version' => $after->policyVersion,
        ];
        $severity = $after->state === RiskCircuitState::OPEN ? 'HIGH' : ($after->state === RiskCircuitState::HALF_OPEN ? 'MEDIUM' : 'INFO');
        return self::make($type, $after->key->companyId, $evidence->traceId, $evidence->correlationId, $evidence->causationId, $evidence->occurredAt, $severity, $payload);
    }

    public static function forFeedback(RiskGateResult $gate, RiskGovernanceFeedbackResult $feedback): self
    {
        $payload = [
            'capability' => $gate->assessment->context->capability,
            'source' => $feedback->source,
            'evidence_id' => $feedback->evidenceId,
            'original_directive' => $feedback->originalDirective->value,
            'execution_directive' => $feedback->directive->value,
            'reason_codes' => $feedback->reasonCodes,
        ];
        return self::make(
            RiskSignalType::GOVERNANCE_FEEDBACK_APPLIED,
            $feedback->companyId,
            $feedback->traceId,
            $feedback->correlationId,
            $feedback->causationId,
            $feedback->appliedAt,
            $feedback->directive->mayDispatchToExecutor() ? 'INFO' : 'MEDIUM',
            $payload,
        );
    }

    /** @param array<string,mixed> $payload */
    private static function make(RiskSignalType $type, int|string $companyId, string $traceId, string $correlationId, string $causationId, DateTimeImmutable $occurredAt, string $severity, array $payload): self
    {
        $identity = [
            'type' => $type->value,
            'tenant' => (string) $companyId,
            'trace' => $traceId,
            'correlation' => $correlationId,
            'causation' => $causationId,
            'occurred_at' => $occurredAt->format('Y-m-d\\TH:i:s.uP'),
            'payload' => $payload,
        ];
        $eventId = hash('sha256', json_encode($identity, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        return new self($eventId, $type, $companyId, $traceId, $correlationId, $causationId, $causationId, $occurredAt, $severity, $payload);
    }

    private static function severityForLevel(RiskLevel $level): string
    {
        return match ($level) {
            RiskLevel::MINIMAL, RiskLevel::LOW => 'INFO',
            RiskLevel::MEDIUM => 'MEDIUM',
            RiskLevel::HIGH => 'HIGH',
            RiskLevel::EXTREME => 'CRITICAL',
        };
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'event_id' => $this->eventId,
            'event_type' => $this->type->value,
            'source_extension' => 'titan-risk-engine',
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'root_causation_id' => $this->rootCausationId,
            'occurred_at' => $this->occurredAt->format(DATE_ATOM),
            'severity' => $this->severity,
            'payload' => $this->payload,
        ];
    }

    /** @param array<string,mixed> $data */
    public static function fromArray(array $data): self
    {
        return new self(
            eventId: (string) ($data['event_id'] ?? ''),
            type: RiskSignalType::from((string) ($data['event_type'] ?? '')),
            companyId: $data['company_id'] ?? '',
            traceId: (string) ($data['trace_id'] ?? ''),
            correlationId: (string) ($data['correlation_id'] ?? ''),
            causationId: (string) ($data['causation_id'] ?? ''),
            rootCausationId: (string) ($data['root_causation_id'] ?? ($data['causation_id'] ?? '')),
            occurredAt: new DateTimeImmutable((string) ($data['occurred_at'] ?? 'now')),
            severity: (string) ($data['severity'] ?? 'INFO'),
            payload: is_array($data['payload'] ?? null) ? $data['payload'] : [],
        );
    }
}
