<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskForgeGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use InvalidArgumentException;

final class ForgeRiskGate implements RiskForgeGateContract
{
    private const POST_ARTIFACT_TYPES = ['generated_code', 'generated_workflow', 'generated_extension', 'generated_artifact'];

    public function __construct(private readonly RiskGateContract $gate) {}

    public function preGeneration(RiskContextInput $input): RiskGateResult
    {
        return $this->gate->evaluate($this->copy($input, 'forge_build_spec', $input->resourceId, 'pre_generation'));
    }

    public function postGeneration(RiskContextInput $input, string $artifactType, int|string $artifactId): RiskGateResult
    {
        if (!in_array($artifactType, self::POST_ARTIFACT_TYPES, true)) {
            throw new InvalidArgumentException('Unsupported Forge generated artifact risk type.');
        }
        if (trim((string) $artifactId) === '') throw new InvalidArgumentException('Forge artifact id is required.');
        return $this->gate->evaluate($this->copy($input, $artifactType, $artifactId, 'post_generation'));
    }

    private function copy(RiskContextInput $input, string $resourceType, int|string|null $resourceId, string $phase): RiskContextInput
    {
        return new RiskContextInput(
            companyId: $input->companyId,
            traceId: $input->traceId,
            correlationId: $input->correlationId,
            causationId: $input->causationId,
            capability: $input->capability,
            action: $input->action,
            actorType: $input->actorType,
            claimedActorId: $input->claimedActorId,
            resourceType: $resourceType,
            resourceId: $resourceId,
            verticalKey: $input->verticalKey,
            jurisdiction: $input->jurisdiction,
            impact: $input->impact,
            reversibility: $input->reversibility,
            connectivity: $input->connectivity,
            metadata: [...$input->metadata, 'forge_phase' => $phase],
            idempotencyKey: $input->idempotencyKey,
        );
    }
}
