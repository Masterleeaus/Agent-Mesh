<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskGovernanceFeedbackStoreContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGovernanceFeedbackResult;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskGovernanceFeedbackStore implements RiskGovernanceFeedbackStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_governance_feedback',
    ) {}

    public function persist(RiskGovernanceFeedbackResult $result): void
    {
        $stamp = $result->appliedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        $this->database->table($this->table)->insertOrIgnore([
            'company_id' => $result->companyId,
            'source' => $result->source,
            'evidence_id' => $result->evidenceId,
            'trace_id' => $result->traceId,
            'correlation_id' => $result->correlationId,
            'causation_id' => $result->causationId,
            'original_directive' => $result->originalDirective->value,
            'execution_directive' => $result->directive->value,
            'may_dispatch' => $result->mayDispatchToExecutor(),
            'reason_codes' => json_encode($result->reasonCodes, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'feedback_payload' => json_encode($result->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'applied_at' => $stamp,
            'created_at' => $stamp,
            'updated_at' => $stamp,
        ]);
    }
}
