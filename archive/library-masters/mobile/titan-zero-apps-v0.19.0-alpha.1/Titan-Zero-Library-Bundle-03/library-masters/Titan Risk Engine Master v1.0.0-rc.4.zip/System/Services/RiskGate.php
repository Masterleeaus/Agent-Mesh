<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskDecisionRouterContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use DateTimeImmutable;
use DateTimeZone;

final class RiskGate implements RiskGateContract
{
    public function __construct(
        private readonly TrustedRiskContextFactory $contextFactory,
        private readonly RiskManagerContract $riskManager,
        private readonly RiskDecisionRouterContract $decisionRouter,
        private readonly ?RiskCircuitContract $circuits = null,
        private readonly ?RiskEnforcementReceiptFactory $receiptFactory = null,
        private readonly ?RiskEnforcementReceiptStoreContract $receiptStore = null,
        private readonly ?RiskBudgetEvaluator $budgetEvaluator = null,
    ) {}

    public function evaluate(RiskContextInput $input): RiskGateResult
    {
        $evaluatedAt = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $assessment = $this->riskManager->assess($this->contextFactory->make($input));
        $directive = $this->decisionRouter->route($assessment->decision);
        $circuitSnapshots = [];

        if ($this->circuits !== null) {
            // Gate governance is always evaluated at call time, including idempotent assessment retries.
            $evidence = new RiskCircuitTransitionEvidence(
                $assessment->context->traceId,
                $assessment->context->correlationId,
                $assessment->context->causationId,
                $evaluatedAt,
                DefaultRiskCircuitPolicy::POLICY_VERSION,
            );
            $keys = [
                new RiskCircuitKey($assessment->context->companyId, RiskCircuitScope::TENANT),
                new RiskCircuitKey($assessment->context->companyId, RiskCircuitScope::TENANT_CAPABILITY, $assessment->context->capability),
            ];
            foreach ($keys as $key) {
                $circuit = $this->circuits->evaluate($key, $evidence);
                $circuitSnapshots[] = $circuit;
                if ($circuit->state === RiskCircuitState::OPEN) {
                    $directive = RiskExecutionDirective::DENY;
                } elseif ($circuit->state === RiskCircuitState::HALF_OPEN && $directive !== RiskExecutionDirective::DENY) {
                    $directive = RiskExecutionDirective::HOLD_FOR_ASSURANCE;
                }
            }
        }

        $budgetEvaluation = null;
        if ($this->budgetEvaluator !== null) {
            $budgetEvaluation = $this->budgetEvaluator->evaluate($assessment, $directive, $evaluatedAt);
            $directive = $budgetEvaluation->directive;
        }

        $result = new RiskGateResult($assessment, $directive, $circuitSnapshots, null, $budgetEvaluation);
        if ($this->receiptFactory !== null && $this->receiptStore !== null) {
            $receipt = $this->receiptFactory->make($result, $evaluatedAt);
            $this->receiptStore->persist($receipt);
            $result = $result->withEnforcementReceipt($receipt);
        }
        return $result;
    }
}
