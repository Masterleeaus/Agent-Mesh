<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEffectivePolicyResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskControlCentreSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;
use InvalidArgumentException;

final class DatabaseRiskControlCentre implements RiskControlCentreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly RiskAggregateContract $aggregate,
        private readonly RiskVelocityContract $velocity,
        private readonly RiskBudgetStoreContract $budgets,
        private readonly RiskEffectivePolicyResolverContract $policies,
    ) {}

    public function snapshot(int|string $companyId, ?string $capability = null, int $limit = 20, ?DateTimeImmutable $asOf = null): RiskControlCentreSnapshot
    {
        if ((is_int($companyId) && $companyId <= 0) || trim((string) $companyId) === '') {
            throw new InvalidArgumentException('Risk Control Centre requires company_id.');
        }
        $limit = max(5, min(50, $limit));
        $now = ($asOf ?? new DateTimeImmutable('now', new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('UTC'));
        $capability = $capability === null || trim($capability) === '' ? null : trim($capability);
        $scope = $capability === null ? RiskAggregateScope::TENANT : RiskAggregateScope::TENANT_CAPABILITY;
        $historyQuery = RiskHistoryQuery::forAggregateWindow(
            companyId: $companyId,
            scope: $scope,
            window: RiskAggregateWindow::HOURS_24,
            asOf: $now,
            capability: $capability,
        );
        $velocityQuery = RiskHistoryQuery::forVelocityWindow(
            companyId: $companyId,
            scope: $scope,
            window: RiskVelocityWindow::MINUTES_15,
            asOf: $now,
            capability: $capability,
        );
        $exposure = $this->aggregate->aggregate($historyQuery)->toArray();
        $velocity = $this->velocity->assess($velocityQuery)->toArray();
        $budget = $this->budgets->effectiveFor($companyId, $now)?->toArray();
        $effectivePolicy = $capability === null ? null : $this->policies->resolve($companyId, $capability, $now)->toArray();

        $circuitsBase = $this->database->table('titan_risk_circuits')->where('company_id', $companyId);
        $circuitSummary = [
            'open' => (clone $circuitsBase)->where('state', 'OPEN')->count(),
            'half_open' => (clone $circuitsBase)->where('state', 'HALF_OPEN')->count(),
            'closed' => (clone $circuitsBase)->where('state', 'CLOSED')->count(),
        ];
        $recentCircuits = $this->rows((clone $circuitsBase)
            ->orderByDesc('last_transition_at')->limit($limit)
            ->get(['scope','capability','state','version','reason_codes','policy_version','probe_after','expires_at','last_transition_at'])->all());

        $signalBase = $this->database->table('titan_risk_signal_outbox')->where('company_id', $companyId);
        $signalSummary = [
            'pending' => (clone $signalBase)->whereNull('published_at')->count(),
            'failed' => (clone $signalBase)->whereNull('published_at')->whereNotNull('last_error')->count(),
            'published_24h' => (clone $signalBase)->whereNotNull('published_at')->where('published_at', '>=', $this->stamp($now->modify('-24 hours')))->count(),
        ];
        $recentSignals = $this->rows((clone $signalBase)
            ->orderByDesc('occurred_at')->limit($limit)
            ->get(['event_id','event_type','severity','attempts','last_error','occurred_at','published_at'])->all());

        $receiptBase = $this->database->table('titan_risk_enforcement_receipts')
            ->where('company_id', $companyId)
            ->where('issued_at', '>=', $this->stamp($now->modify('-24 hours')));
        $receiptSummary = [
            'issued_24h' => (clone $receiptBase)->count(),
            'dispatchable_24h' => (clone $receiptBase)->where('may_dispatch', true)->count(),
            'held_or_denied_24h' => (clone $receiptBase)->where('may_dispatch', false)->count(),
        ];
        $recentReceipts = $this->rows($this->database->table('titan_risk_enforcement_receipts')
            ->where('company_id', $companyId)
            ->orderByDesc('issued_at')->limit($limit)
            ->get(['receipt_id','content_digest','capability','execution_directive','may_dispatch','risk_score','risk_level','governance_source','issued_at'])->all());

        $recentAssessments = $this->rows($this->database->table('titan_risk_assessments')
            ->where('company_id', $companyId)
            ->whereNotNull('score')
            ->when($capability !== null, static fn ($q) => $q->where('capability', $capability))
            ->orderByDesc('assessed_at')->limit($limit)
            ->get(['capability','action','actor_type','actor_id','resource_type','resource_id','score','level','decision','policy_version','connectivity','assessed_at'])->all());

        $policyChanges = $this->rows($this->database->table('titan_risk_policy_changes')
            ->where(function ($q) use ($companyId): void {
                $q->whereNull('company_id')->orWhere('company_id', $companyId);
            })
            ->orderByDesc('changed_at')->limit($limit)
            ->get(['change_id','action','company_id','policy_key','version','previous_version','actor_type','actor_id','reason','changed_at'])->all());

        $budgetVersions = $this->rows($this->database->table('titan_risk_budget_versions')
            ->where('company_id', $companyId)
            ->orderByDesc('effective_at')->limit($limit)
            ->get(['version','max_daily_risk_exposure','max_autonomous_single_action_level','monitoring_threshold_ratio','effective_at','source','supersedes_version','content_digest'])->all());

        $policyOverlays = $this->rows($this->database->table('titan_risk_policy_overlays')
            ->where(function ($q) use ($companyId): void {
                $q->whereNull('company_id')->orWhere('company_id', $companyId);
            })
            ->when($capability !== null, static fn ($q) => $q->where(function ($q) use ($capability): void {
                $q->whereNull('capability')->orWhere('capability', $capability);
            }))
            ->orderByDesc('effective_at')->limit($limit)
            ->get(['policy_key','version','scope','company_id','capability','constraints','effective_at','supersedes_version','content_digest'])->all());

        $capabilityRows = $this->database->table('titan_risk_assessments')
            ->where('company_id', $companyId)
            ->whereNotNull('capability')->where('capability', '<>', '')
            ->select('capability')->distinct()->orderBy('capability')->limit(50)->get()->all();
        $capabilities = array_values(array_filter(array_map(static fn ($row): string => trim((string) $row->capability), $capabilityRows)));

        return new RiskControlCentreSnapshot(
            companyId: $companyId,
            generatedAt: $now,
            capability: $capability,
            exposure: $exposure,
            velocity: $velocity,
            budget: $budget,
            effectivePolicy: $effectivePolicy,
            circuitSummary: $circuitSummary,
            signalSummary: $signalSummary,
            receiptSummary: $receiptSummary,
            recentAssessments: $recentAssessments,
            recentCircuits: $recentCircuits,
            recentSignals: $recentSignals,
            recentReceipts: $recentReceipts,
            policyChanges: $policyChanges,
            budgetVersions: $budgetVersions,
            policyOverlays: $policyOverlays,
            capabilities: $capabilities,
        );
    }

    /** @param list<object> $rows @return list<array<string,mixed>> */
    private function rows(array $rows): array
    {
        return array_map(static fn (object $row): array => get_object_vars($row), $rows);
    }

    private function stamp(DateTimeImmutable $at): string
    {
        return $at->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
    }
}
