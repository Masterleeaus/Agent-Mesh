<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class ModelCouncilRiskEvidence
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $evidenceId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public DateTimeImmutable $occurredAt,
        public float $disagreementScore,
        public float $uncertaintyScore,
        public int $modelCount,
        public array $reasonCodes = [],
    ) {
        RiskFieldConstraints::text('evidenceId', $this->evidenceId, 191, false);
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        foreach ([$this->disagreementScore, $this->uncertaintyScore] as $score) {
            if (!is_finite($score) || $score < 0.0 || $score > 100.0) throw new InvalidArgumentException('Council risk evidence scores must be finite and between 0 and 100.');
        }
        if ($this->modelCount < 1 || $this->modelCount > 100) throw new InvalidArgumentException('Council modelCount must be between 1 and 100.');
        $this->validateReasons();
    }

    public function source(): string { return 'MODEL_COUNCIL'; }

    private function validateReasons(): void
    {
        if (count($this->reasonCodes) > 50) throw new InvalidArgumentException('Council reasonCodes must contain at most 50 entries.');
        foreach ($this->reasonCodes as $reason) RiskFieldConstraints::text('reasonCode', $reason, 120, false);
    }
}
