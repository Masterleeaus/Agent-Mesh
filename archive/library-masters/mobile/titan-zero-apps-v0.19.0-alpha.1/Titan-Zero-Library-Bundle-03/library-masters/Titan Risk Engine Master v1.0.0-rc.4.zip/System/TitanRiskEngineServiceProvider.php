<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System;

use App\Domains\Marketplace\Contracts\ExtensionRegisterKeyProviderInterface;
use App\Domains\Marketplace\Contracts\UninstallExtensionServiceProviderInterface;
use App\Extensions\TitanRiskEngine\System\Commands\CertifyExtensionCommand;
use App\Extensions\TitanRiskEngine\System\Commands\DispatchRiskSignalsCommand;
use App\Extensions\TitanRiskEngine\System\Commands\SyncRiskNavigationCommand;
use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEffectivePolicyResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskControlCentreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitPolicyContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskDecisionRouterContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptVerifierContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskFeedbackContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskForgeGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGovernanceFeedbackStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskManagerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskTransactionRunnerContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyRegistryContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Services\AuthenticatedActorIdentityResolver;
use App\Extensions\TitanRiskEngine\System\Services\AuthenticatedTenantResolver;
use App\Extensions\TitanRiskEngine\System\Services\BaselineRiskScorer;
use App\Extensions\TitanRiskEngine\System\Services\CachedRecentActivityProvider;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskAssessmentLedger;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskControlCentre;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyGovernanceService;
use App\Extensions\TitanRiskEngine\System\Services\RiskBudgetEvaluator;
use App\Extensions\TitanRiskEngine\System\Services\DeterministicRiskPolicyResolver;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskPolicyOverlayStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskPolicyChangeStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskBudgetStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskCircuitStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskEnforcementReceiptStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskGovernanceFeedbackStore;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskHistoryReader;
use App\Extensions\TitanRiskEngine\System\Services\DatabaseRiskSignalOutbox;
use App\Extensions\TitanRiskEngine\System\Services\DefaultRiskCircuitPolicy;
use App\Extensions\TitanRiskEngine\System\Services\ForgeRiskGate;
use App\Extensions\TitanRiskEngine\System\Services\FailClosedRiskGate;
use App\Extensions\TitanRiskEngine\System\Services\LaravelRiskRuntimeEventSink;
use App\Extensions\TitanRiskEngine\System\Services\LaravelRiskTransactionRunner;
use App\Extensions\TitanRiskEngine\System\Services\InstrumentedRiskManager;
use App\Extensions\TitanRiskEngine\System\Services\LaravelRiskSignalPublisher;
use App\Extensions\TitanRiskEngine\System\Services\RiskAggregateService;
use App\Extensions\TitanRiskEngine\System\Services\RiskCircuitManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskCircuitService;
use App\Extensions\TitanRiskEngine\System\Services\RiskDatabaseErrorClassifier;
use App\Extensions\TitanRiskEngine\System\Services\RiskDecisionRouter;
use App\Extensions\TitanRiskEngine\System\Services\RiskDirectivePolicy;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptFactory;
use App\Extensions\TitanRiskEngine\System\Services\RiskIdempotencyGuard;
use App\Extensions\TitanRiskEngine\System\Services\RiskEnforcementReceiptVerifier;
use App\Extensions\TitanRiskEngine\System\Services\RiskContextFingerprint;
use App\Extensions\TitanRiskEngine\System\Services\RiskFeedbackCoordinator;
use App\Extensions\TitanRiskEngine\System\Services\RiskGate;
use App\Extensions\TitanRiskEngine\System\Services\RiskLedgerRowMapper;
use App\Extensions\TitanRiskEngine\System\Services\RiskManager;
use App\Extensions\TitanRiskEngine\System\Services\RiskMetadataSanitizer;
use App\Extensions\TitanRiskEngine\System\Services\RiskPolicyIntegrityVerifier;
use App\Extensions\TitanRiskEngine\System\Services\RiskSignalDispatcher;
use App\Extensions\TitanRiskEngine\System\Services\RiskVelocityService;
use App\Extensions\TitanRiskEngine\System\Services\StaticRiskPolicyRegistry;
use App\Extensions\TitanRiskEngine\System\Services\TrustedRiskContextFactory;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\Host\RiskNavigationDefinitions;
use App\Extensions\TitanRiskEngine\System\Host\TitanMenuCompatibilityAdapter;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use DateTimeImmutable;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Routing\Router;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

final class TitanRiskEngineServiceProvider extends ServiceProvider implements ExtensionRegisterKeyProviderInterface, UninstallExtensionServiceProviderInterface
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/titan-risk-engine.php', 'titan-risk-engine');

        $this->app->singleton(TitanMenuCompatibilityAdapter::class);
        $this->app->singleton(BaselineRiskScorer::class);
        $this->app->singleton(ActorIdentityResolverContract::class, AuthenticatedActorIdentityResolver::class);
        $this->app->singleton(RiskDecisionRouterContract::class, RiskDecisionRouter::class);
        $this->app->singleton(RiskDirectivePolicy::class);
        $this->app->singleton(RiskLedgerRowMapper::class);
        $this->app->singleton(RiskContextFingerprint::class);
        $this->app->singleton(RiskIdempotencyGuard::class);
        $this->app->singleton(RiskPolicyIntegrityVerifier::class);
        $this->app->singleton(RiskEnforcementReceiptFactory::class);
        $this->app->singleton(RiskEnforcementReceiptVerifier::class);
        $this->app->singleton(RiskEnforcementReceiptVerifierContract::class, fn ($app): RiskEnforcementReceiptVerifier => $app->make(RiskEnforcementReceiptVerifier::class));
        $this->app->singleton(RiskDatabaseErrorClassifier::class);
        $this->app->singleton(RiskRuntimeEventSinkContract::class, fn ($app): LaravelRiskRuntimeEventSink => new LaravelRiskRuntimeEventSink($app['log']));
        $this->app->singleton(RiskTransactionRunnerContract::class, fn ($app): LaravelRiskTransactionRunner => new LaravelRiskTransactionRunner(
            database: $app['db']->connection(),
            attempts: (int) config('titan-risk-engine.runtime.database_transaction_attempts', 3),
        ));

        $this->app->singleton(RiskSignalOutboxContract::class, function ($app): DatabaseRiskSignalOutbox {
            return new DatabaseRiskSignalOutbox(
                database: $app['db']->connection(),
                table: (string) config('titan-risk-engine.integration.signal_outbox_table', 'titan_risk_signal_outbox'),
                maxAttempts: (int) config('titan-risk-engine.integration.signal_max_attempts', 20),
                retryDelaySeconds: (int) config('titan-risk-engine.integration.signal_retry_delay_seconds', 30),
            );
        });
        $this->app->singleton(RiskSignalPublisherContract::class, function ($app): LaravelRiskSignalPublisher {
            return new LaravelRiskSignalPublisher(
                events: $app['events'],
                eventName: (string) config('titan-risk-engine.integration.signal_event_name', 'titan.signal.ingest'),
            );
        });
        $this->app->singleton(RiskSignalDispatcher::class, fn ($app) => new RiskSignalDispatcher(
            $app->make(RiskSignalOutboxContract::class),
            $app->make(RiskSignalPublisherContract::class),
            (int) config('titan-risk-engine.integration.signal_dispatch_max_batch', 100),
        ));
        $this->app->singleton(RiskEnforcementReceiptStoreContract::class, function ($app): DatabaseRiskEnforcementReceiptStore {
            return new DatabaseRiskEnforcementReceiptStore(
                database: $app['db']->connection(),
                table: (string) config('titan-risk-engine.integration.enforcement_receipt_table', 'titan_risk_enforcement_receipts'),
            );
        });
        $this->app->singleton(RiskGovernanceFeedbackStoreContract::class, function ($app): DatabaseRiskGovernanceFeedbackStore {
            return new DatabaseRiskGovernanceFeedbackStore(
                database: $app['db']->connection(),
                table: (string) config('titan-risk-engine.integration.governance_feedback_table', 'titan_risk_governance_feedback'),
            );
        });

        $this->app->singleton(RiskAssessmentLedgerContract::class, function ($app): DatabaseRiskAssessmentLedger {
            return new DatabaseRiskAssessmentLedger(
                database: $app['db']->connection(),
                mapper: $app->make(RiskLedgerRowMapper::class),
                table: (string) config('titan-risk-engine.ledger.table', 'titan_risk_assessments'),
                errors: $app->make(RiskDatabaseErrorClassifier::class),
            );
        });
        $this->app->singleton(RiskHistoryReaderContract::class, function ($app): DatabaseRiskHistoryReader {
            return new DatabaseRiskHistoryReader(
                database: $app['db']->connection(),
                table: (string) config('titan-risk-engine.ledger.table', 'titan_risk_assessments'),
            );
        });
        $this->app->singleton(RiskAggregateContract::class, RiskAggregateService::class);
        $this->app->singleton(AuthenticatedTenantResolver::class);
        $this->app->singleton(RiskControlCentreContract::class, fn ($app): DatabaseRiskControlCentre => new DatabaseRiskControlCentre(
            database: $app['db']->connection(),
            aggregate: $app->make(RiskAggregateContract::class),
            velocity: $app->make(RiskVelocityContract::class),
            budgets: $app->make(RiskBudgetStoreContract::class),
            policies: $app->make(RiskEffectivePolicyResolverContract::class),
        ));
        $this->app->singleton(RiskVelocityContract::class, function ($app): RiskVelocityService {
            $thresholds = (array) config('titan-risk-engine.velocity.thresholds', RiskVelocityService::defaultThresholds());
            return new RiskVelocityService($app->make(RiskHistoryReaderContract::class), $thresholds);
        });
        $this->app->singleton(RiskBudgetStoreContract::class, fn ($app): DatabaseRiskBudgetStore => new DatabaseRiskBudgetStore(
            database: $app['db']->connection(),
            table: (string) config('titan-risk-engine.policy.budget_table', 'titan_risk_budget_versions'),
            integrity: $app->make(RiskPolicyIntegrityVerifier::class),
        ));
        $this->app->singleton(RiskPolicyOverlayStoreContract::class, fn ($app): DatabaseRiskPolicyOverlayStore => new DatabaseRiskPolicyOverlayStore(
            database: $app['db']->connection(),
            table: (string) config('titan-risk-engine.policy.overlay_table', 'titan_risk_policy_overlays'),
            integrity: $app->make(RiskPolicyIntegrityVerifier::class),
        ));
        $this->app->singleton(RiskPolicyChangeStoreContract::class, fn ($app): DatabaseRiskPolicyChangeStore => new DatabaseRiskPolicyChangeStore(
            database: $app['db']->connection(),
            table: (string) config('titan-risk-engine.policy.change_table', 'titan_risk_policy_changes'),
        ));
        $this->app->singleton(RiskEffectivePolicyResolverContract::class, function ($app): DeterministicRiskPolicyResolver {
            $level = RiskLevel::from((string) config('titan-risk-engine.policy.default_budget.max_autonomous_single_action_level', 'MEDIUM'));
            $hard = RiskLevel::from((string) config('titan-risk-engine.policy.hard_block_level', 'EXTREME'));
            $default = new RiskOperationalBudget(
                companyId: 0,
                version: (string) config('titan-risk-engine.policy.default_budget.version', 'default-v1'),
                maxDailyRiskExposure: (float) config('titan-risk-engine.policy.default_budget.max_daily_risk_exposure', 5000.0),
                maxAutonomousSingleActionLevel: $level,
                monitoringThresholdRatio: (float) config('titan-risk-engine.policy.default_budget.monitoring_threshold_ratio', 0.80),
                effectiveAt: new DateTimeImmutable('2026-01-01T00:00:00+00:00'),
                source: 'DEFAULT',
            );
            return new DeterministicRiskPolicyResolver(
                budgets: $app->make(RiskBudgetStoreContract::class),
                overlays: $app->make(RiskPolicyOverlayStoreContract::class),
                defaultBudget: $default,
                defaultHardBlockLevel: $hard,
            );
        });
        $this->app->singleton(RiskBudgetEvaluator::class, fn ($app): RiskBudgetEvaluator => new RiskBudgetEvaluator(
            aggregate: $app->make(RiskAggregateContract::class),
            policies: $app->make(RiskEffectivePolicyResolverContract::class),
            directivePolicy: $app->make(RiskDirectivePolicy::class),
        ));
        $this->app->singleton(RiskPolicyGovernanceService::class, fn ($app): RiskPolicyGovernanceService => new RiskPolicyGovernanceService(
            budgets: $app->make(RiskBudgetStoreContract::class),
            overlays: $app->make(RiskPolicyOverlayStoreContract::class),
            changes: $app->make(RiskPolicyChangeStoreContract::class),
            transactions: $app->make(RiskTransactionRunnerContract::class),
        ));
        $this->app->singleton(RiskPolicyRegistryContract::class, StaticRiskPolicyRegistry::class);
        $this->app->singleton(RiskCircuitPolicyContract::class, fn (): DefaultRiskCircuitPolicy => new DefaultRiskCircuitPolicy(
            openCooldownSeconds: (int) config('titan-risk-engine.circuit.open_cooldown_seconds', 300),
            halfOpenTimeoutSeconds: (int) config('titan-risk-engine.circuit.half_open_timeout_seconds', 300),
        ));
        $this->app->singleton(RiskCircuitStoreContract::class, function ($app): DatabaseRiskCircuitStore {
            return new DatabaseRiskCircuitStore(
                database: $app['db']->connection(),
                table: (string) config('titan-risk-engine.circuit.table', 'titan_risk_circuits'),
                transitionTable: (string) config('titan-risk-engine.circuit.transition_table', 'titan_risk_circuit_transitions'),
                signalOutbox: $app->make(RiskSignalOutboxContract::class),
                transactionAttempts: (int) config('titan-risk-engine.runtime.database_transaction_attempts', 3),
                runtimeEvents: $app->make(RiskRuntimeEventSinkContract::class),
            );
        });
        $this->app->singleton(RiskCircuitManager::class, fn ($app): RiskCircuitManager => new RiskCircuitManager(
            store: $app->make(RiskCircuitStoreContract::class),
            policy: $app->make(RiskCircuitPolicyContract::class),
            requiredSuccessfulProbes: (int) config('titan-risk-engine.circuit.required_successful_probes', 2),
        ));
        $this->app->singleton(RiskCircuitContract::class, fn ($app): RiskCircuitService => new RiskCircuitService(
            store: $app->make(RiskCircuitStoreContract::class),
            manager: $app->make(RiskCircuitManager::class),
            aggregate: $app->make(RiskAggregateContract::class),
            velocity: $app->make(RiskVelocityContract::class),
            policyVersion: DefaultRiskCircuitPolicy::POLICY_VERSION,
            signalDispatcher: $app->make(RiskSignalDispatcher::class),
            inlineSignalDispatch: (bool) config('titan-risk-engine.integration.inline_signal_dispatch', false),
        ));

        $this->app->singleton(RiskMetadataSanitizer::class, fn (): RiskMetadataSanitizer => new RiskMetadataSanitizer(
            maxDepth: (int) config('titan-risk-engine.metadata.max_depth', 4),
            maxEntries: (int) config('titan-risk-engine.metadata.max_entries', 100),
            maxStringLength: (int) config('titan-risk-engine.metadata.max_string_length', 2000),
            maxTotalBytes: (int) config('titan-risk-engine.metadata.max_total_bytes', 32768),
        ));
        $this->app->singleton(RecentActivityProviderContract::class, fn ($app): CachedRecentActivityProvider => new CachedRecentActivityProvider(
            cache: $app['cache']->store(),
            defaultLimit: (int) config('titan-risk-engine.recent_activity.limit', 10),
            ttlSeconds: (int) config('titan-risk-engine.recent_activity.ttl_seconds', 86400),
        ));
        $this->app->singleton(TrustedRiskContextFactory::class, fn ($app): TrustedRiskContextFactory => new TrustedRiskContextFactory(
            actorResolver: $app->make(ActorIdentityResolverContract::class),
            recentActivity: $app->make(RecentActivityProviderContract::class),
            metadataSanitizer: $app->make(RiskMetadataSanitizer::class),
            recentActivityLimit: (int) config('titan-risk-engine.recent_activity.limit', 10),
        ));
        $this->app->singleton(RiskManager::class, fn ($app): RiskManager => new RiskManager(
            scorer: $app->make(BaselineRiskScorer::class),
            recentActivity: $app->make(RecentActivityProviderContract::class),
            metadataSanitizer: $app->make(RiskMetadataSanitizer::class),
            recentActivityLimit: (int) config('titan-risk-engine.recent_activity.limit', 10),
            ledger: $app->make(RiskAssessmentLedgerContract::class),
            signalOutbox: $app->make(RiskSignalOutboxContract::class),
            signalDispatcher: $app->make(RiskSignalDispatcher::class),
            inlineSignalDispatch: (bool) config('titan-risk-engine.integration.inline_signal_dispatch', false),
            runtimeEvents: $app->make(RiskRuntimeEventSinkContract::class),
            idempotencyGuard: $app->make(RiskIdempotencyGuard::class),
            enabled: (bool) config('titan-risk-engine.enabled', true),
        ));
        $this->app->singleton(RiskManagerContract::class, fn ($app): InstrumentedRiskManager => new InstrumentedRiskManager(
            inner: $app->make(RiskManager::class),
            runtimeEvents: $app->make(RiskRuntimeEventSinkContract::class),
            targetMilliseconds: (float) config('titan-risk-engine.runtime.risk_assess_target_ms', 50.0),
        ));
        $this->app->singleton(RiskGate::class, fn ($app): RiskGate => new RiskGate(
            contextFactory: $app->make(TrustedRiskContextFactory::class),
            riskManager: $app->make(RiskManagerContract::class),
            decisionRouter: $app->make(RiskDecisionRouterContract::class),
            circuits: $app->make(RiskCircuitContract::class),
            receiptFactory: $app->make(RiskEnforcementReceiptFactory::class),
            receiptStore: $app->make(RiskEnforcementReceiptStoreContract::class),
            budgetEvaluator: $app->make(RiskBudgetEvaluator::class),
        ));
        $this->app->singleton(RiskGateContract::class, fn ($app): FailClosedRiskGate => new FailClosedRiskGate(
            inner: $app->make(RiskGate::class),
            runtimeEvents: $app->make(RiskRuntimeEventSinkContract::class),
            receiptFactory: $app->make(RiskEnforcementReceiptFactory::class),
            receiptStore: $app->make(RiskEnforcementReceiptStoreContract::class),
            targetMilliseconds: (float) config('titan-risk-engine.runtime.risk_gate_target_ms', 100.0),
            enabled: (bool) config('titan-risk-engine.enabled', true),
        ));
        $this->app->singleton(RiskFeedbackContract::class, fn ($app): RiskFeedbackCoordinator => new RiskFeedbackCoordinator(
            policy: $app->make(RiskDirectivePolicy::class),
            store: $app->make(RiskGovernanceFeedbackStoreContract::class),
            receiptFactory: $app->make(RiskEnforcementReceiptFactory::class),
            receiptStore: $app->make(RiskEnforcementReceiptStoreContract::class),
            signalOutbox: $app->make(RiskSignalOutboxContract::class),
            signalDispatcher: $app->make(RiskSignalDispatcher::class),
            inlineSignalDispatch: (bool) config('titan-risk-engine.integration.inline_signal_dispatch', false),
            runtimeEvents: $app->make(RiskRuntimeEventSinkContract::class),
        ));
        $this->app->singleton(RiskForgeGateContract::class, ForgeRiskGate::class);
    }

    public function boot(Kernel $kernel): void
    {
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'titan-risk-engine');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->publishes([__DIR__ . '/../config/titan-risk-engine.php' => config_path('titan-risk-engine.php')], 'extension');
        $this->registerRoutes();
        $this->app->booted(function (): void {
            $this->syncNavigation();
        });
        if ($this->app->runningInConsole()) {
            $this->commands([CertifyExtensionCommand::class, DispatchRiskSignalsCommand::class, SyncRiskNavigationCommand::class]);
        }
    }

    public function registerKey(): string { return 'titan-risk-engine'; }

    public static function uninstall(): void
    {
        self::removeNavigation();
        File::delete(config_path('titan-risk-engine.php'));
    }

    private static function removeNavigation(): void
    {
        try {
            app()->make(TitanMenuCompatibilityAdapter::class)->remove(RiskNavigationDefinitions::all());
        } catch (\Throwable) {
            // Uninstall must remain idempotent even when host navigation is unavailable.
        }
    }

    private function syncNavigation(): void
    {
        try {
            $this->app->make(TitanMenuCompatibilityAdapter::class)->sync(RiskNavigationDefinitions::all());
        } catch (\Throwable $exception) {
            try {
                $this->app['log']->warning('Titan Risk navigation synchronization failed.', [
                    'extension' => 'titan-risk-engine',
                    'exception' => $exception::class,
                ]);
            } catch (\Throwable) {
                // Navigation must never make the authoritative Risk engine fail to boot.
            }
        }
    }

    private function registerRoutes(): void
    {
        /** @var Router $router */
        $router = $this->app['router'];
        $router->group(['middleware'=>['web','auth'],'prefix'=>'dashboard/user/titan-risk-engine','as'=>'dashboard.user.titan.risk.engine.'], static function (Router $router): void { require __DIR__ . '/../routes/user.php'; });
        $router->group(['middleware'=>['web','auth','admin'],'prefix'=>'dashboard/admin/titan-risk-engine','as'=>'dashboard.admin.titan.risk.engine.'], static function (Router $router): void { require __DIR__ . '/../routes/admin.php'; });
    }
}
