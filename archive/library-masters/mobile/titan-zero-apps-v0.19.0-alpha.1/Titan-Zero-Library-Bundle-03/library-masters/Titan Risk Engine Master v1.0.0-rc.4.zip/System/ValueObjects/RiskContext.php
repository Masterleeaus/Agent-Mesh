<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\ConnectivityState;
use App\Extensions\TitanRiskEngine\System\Enums\Reversibility;
use InvalidArgumentException;

final readonly class RiskContext
{
    /**
     * @param list<array<string, scalar|null>> $recentActivity
     * @param array<string, mixed> $metadata
     */
    public function __construct(
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $capability,
        public string $action,
        public string $actorType,
        public int|string|null $actorId = null,
        public ?string $resourceType = null,
        public int|string|null $resourceId = null,
        public ?string $verticalKey = null,
        public ?string $jurisdiction = null,
        public RiskImpactVector $impact = new RiskImpactVector(),
        public Reversibility $reversibility = Reversibility::REVERSIBLE,
        public ConnectivityState $connectivity = ConnectivityState::ONLINE,
        public array $recentActivity = [],
        public array $metadata = [],
        public ?string $idempotencyKey = null,
    ) {
        RiskFieldConstraints::required('companyId', $this->companyId, 64);
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        RiskFieldConstraints::text('capability', $this->capability, 160, false);
        RiskFieldConstraints::text('action', $this->action, 160, false);
        RiskFieldConstraints::text('actorType', $this->actorType, 80, false);
        RiskFieldConstraints::scalarId('actorId', $this->actorId);
        RiskFieldConstraints::text('resourceType', $this->resourceType, 120);
        RiskFieldConstraints::scalarId('resourceId', $this->resourceId);
        RiskFieldConstraints::text('verticalKey', $this->verticalKey, 120);
        RiskFieldConstraints::text('jurisdiction', $this->jurisdiction, 80);
        RiskFieldConstraints::text('idempotencyKey', $this->idempotencyKey, 191);
        if ($this->idempotencyKey !== null && trim($this->idempotencyKey) === '') {
            throw new InvalidArgumentException('idempotencyKey, when provided, must not be blank.');
        }
    }

    /** @param list<array<string, scalar|null>> $recentActivity */
    public function withRecentActivity(array $recentActivity): self
    {
        return new self(
            companyId: $this->companyId,
            traceId: $this->traceId,
            correlationId: $this->correlationId,
            causationId: $this->causationId,
            capability: $this->capability,
            action: $this->action,
            actorType: $this->actorType,
            actorId: $this->actorId,
            resourceType: $this->resourceType,
            resourceId: $this->resourceId,
            verticalKey: $this->verticalKey,
            jurisdiction: $this->jurisdiction,
            impact: $this->impact,
            reversibility: $this->reversibility,
            connectivity: $this->connectivity,
            recentActivity: $recentActivity,
            metadata: $this->metadata,
            idempotencyKey: $this->idempotencyKey,
        );
    }

    /** @param array<string, mixed> $metadata */
    public function withMetadata(array $metadata): self
    {
        return new self(
            companyId: $this->companyId,
            traceId: $this->traceId,
            correlationId: $this->correlationId,
            causationId: $this->causationId,
            capability: $this->capability,
            action: $this->action,
            actorType: $this->actorType,
            actorId: $this->actorId,
            resourceType: $this->resourceType,
            resourceId: $this->resourceId,
            verticalKey: $this->verticalKey,
            jurisdiction: $this->jurisdiction,
            impact: $this->impact,
            reversibility: $this->reversibility,
            connectivity: $this->connectivity,
            recentActivity: $this->recentActivity,
            metadata: $metadata,
            idempotencyKey: $this->idempotencyKey,
        );
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'idempotency_key' => $this->idempotencyKey,
            'capability' => $this->capability,
            'action' => $this->action,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'resource_type' => $this->resourceType,
            'resource_id' => $this->resourceId,
            'vertical_key' => $this->verticalKey,
            'jurisdiction' => $this->jurisdiction,
            'impact' => $this->impact->toArray(),
            'reversibility' => $this->reversibility->value,
            'connectivity' => $this->connectivity->value,
            'recent_activity' => $this->recentActivity,
            'metadata' => $this->metadata,
        ];
    }
}
