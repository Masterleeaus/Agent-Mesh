<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskEffectivePolicyResolverContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskBudgetEvaluation;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeImmutable;

final class RiskBudgetEvaluator
{
    public function __construct(
        private readonly RiskAggregateContract $aggregate,
        private readonly RiskEffectivePolicyResolverContract $policies,
        private readonly RiskDirectivePolicy $directivePolicy,
    ) {}

    public function evaluate(RiskAssessment $assessment, RiskExecutionDirective $currentDirective, DateTimeImmutable $asOf): RiskBudgetEvaluation
    {
        $context = $assessment->context;
        $policy = $this->policies->resolve($context->companyId, $context->capability, $asOf);
        $snapshot = $this->aggregate->aggregate(RiskHistoryQuery::forAggregateWindow(
            $context->companyId,
            RiskAggregateScope::TENANT,
            RiskAggregateWindow::HOURS_24,
            $asOf,
        ));

        $dailyExposure = max(0.0, $snapshot->scoreSum);
        $utilization = $policy->maxDailyRiskExposure > 0.0 ? $dailyExposure / $policy->maxDailyRiskExposure : 1.0;
        $monitoring = $utilization >= $policy->monitoringThresholdRatio;
        $dailyExceeded = $dailyExposure > $policy->maxDailyRiskExposure;
        $singleExceeded = $this->rank($assessment->level) > $this->rank($policy->maxAutonomousSingleActionLevel);
        $hardTriggered = $this->rank($assessment->level) >= $this->rank($policy->hardBlockLevel);

        $candidate = RiskExecutionDirective::EXECUTE;
        if ($monitoring) $candidate = RiskExecutionDirective::EXECUTE_MONITORED;
        if ($singleExceeded || $dailyExceeded) $candidate = RiskExecutionDirective::HOLD_FOR_APPROVAL;
        if ($hardTriggered) $candidate = RiskExecutionDirective::DENY;

        return new RiskBudgetEvaluation(
            policy: $policy,
            dailyExposure: round($dailyExposure, 2),
            utilizationRatio: round($utilization, 6),
            monitoringThresholdReached: $monitoring,
            dailyLimitExceeded: $dailyExceeded,
            singleActionLimitExceeded: $singleExceeded,
            hardCeilingTriggered: $hardTriggered,
            directive: $this->directivePolicy->stricter($currentDirective, $candidate),
        );
    }

    private function rank(RiskLevel $level): int
    {
        return match ($level) {
            RiskLevel::MINIMAL => 0,
            RiskLevel::LOW => 1,
            RiskLevel::MEDIUM => 2,
            RiskLevel::HIGH => 3,
            RiskLevel::EXTREME => 4,
        };
    }
}
