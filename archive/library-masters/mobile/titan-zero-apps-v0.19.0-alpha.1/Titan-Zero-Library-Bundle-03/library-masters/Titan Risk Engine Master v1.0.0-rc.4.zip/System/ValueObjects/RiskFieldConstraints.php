<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use InvalidArgumentException;

final class RiskFieldConstraints
{
    public static function required(string $name, int|string $value, int $maxLength): void
    {
        $text = (string) $value;
        self::text($name, $text, $maxLength, false);
        if ((is_int($value) && $value <= 0) || (is_string($value) && is_numeric(trim($value)) && (float) trim($value) <= 0.0)) {
            throw new InvalidArgumentException(sprintf('%s must be positive.', $name));
        }
    }

    public static function text(string $name, ?string $value, int $maxLength, bool $nullable = true): void
    {
        if ($value === null) {
            if ($nullable) return;
            throw new InvalidArgumentException(sprintf('%s is required.', $name));
        }
        if (!$nullable && trim($value) === '') {
            throw new InvalidArgumentException(sprintf('%s is required.', $name));
        }
        if ($value !== '' && preg_match('//u', $value) !== 1) {
            throw new InvalidArgumentException(sprintf('%s must be valid UTF-8.', $name));
        }
        if (strlen($value) > $maxLength) {
            throw new InvalidArgumentException(sprintf('%s must be <= %d bytes.', $name, $maxLength));
        }
        if (preg_match('/[\x00-\x1F\x7F]/', $value) === 1) {
            throw new InvalidArgumentException(sprintf('%s contains control characters.', $name));
        }
    }

    public static function scalarId(string $name, int|string|null $value, int $maxLength = 191): void
    {
        if ($value === null) return;
        if (is_int($value)) {
            if ($value <= 0) throw new InvalidArgumentException(sprintf('%s must be positive.', $name));
            return;
        }
        self::text($name, $value, $maxLength, false);
        if (is_numeric(trim($value)) && (float) trim($value) <= 0.0) throw new InvalidArgumentException(sprintf('%s must be valid.', $name));
    }
}
