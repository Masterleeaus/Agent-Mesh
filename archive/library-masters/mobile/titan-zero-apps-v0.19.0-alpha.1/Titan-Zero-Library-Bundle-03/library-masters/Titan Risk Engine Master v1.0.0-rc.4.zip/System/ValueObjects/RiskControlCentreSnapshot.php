<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use DateTimeImmutable;

final readonly class RiskControlCentreSnapshot
{
    /**
     * @param array<string,mixed> $exposure
     * @param array<string,mixed> $velocity
     * @param array<string,mixed>|null $budget
     * @param array<string,mixed>|null $effectivePolicy
     * @param array<string,int|float|string|null> $circuitSummary
     * @param array<string,int|float|string|null> $signalSummary
     * @param array<string,int|float|string|null> $receiptSummary
     * @param list<array<string,mixed>> $recentAssessments
     * @param list<array<string,mixed>> $recentCircuits
     * @param list<array<string,mixed>> $recentSignals
     * @param list<array<string,mixed>> $recentReceipts
     * @param list<array<string,mixed>> $policyChanges
     * @param list<array<string,mixed>> $budgetVersions
     * @param list<array<string,mixed>> $policyOverlays
     * @param list<string> $capabilities
     */
    public function __construct(
        public int|string $companyId,
        public DateTimeImmutable $generatedAt,
        public ?string $capability,
        public array $exposure,
        public array $velocity,
        public ?array $budget,
        public ?array $effectivePolicy,
        public array $circuitSummary,
        public array $signalSummary,
        public array $receiptSummary,
        public array $recentAssessments,
        public array $recentCircuits,
        public array $recentSignals,
        public array $recentReceipts,
        public array $policyChanges,
        public array $budgetVersions,
        public array $policyOverlays,
        public array $capabilities,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
