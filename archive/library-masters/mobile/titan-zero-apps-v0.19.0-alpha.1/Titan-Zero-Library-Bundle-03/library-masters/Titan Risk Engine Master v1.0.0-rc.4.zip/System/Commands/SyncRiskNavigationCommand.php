<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Commands;

use App\Extensions\TitanRiskEngine\System\Host\RiskNavigationDefinitions;
use App\Extensions\TitanRiskEngine\System\Host\TitanMenuCompatibilityAdapter;
use Illuminate\Console\Command;

final class SyncRiskNavigationCommand extends Command
{
    protected $signature = 'titan:titan-risk-engine:sync-navigation {--json : Emit JSON evidence}';
    protected $description = 'Synchronize Titan Risk navigation with the active Titan/MagicAI host menu system.';

    public function handle(TitanMenuCompatibilityAdapter $menus): int
    {
        $results = $menus->sync(RiskNavigationDefinitions::all());
        $passed = $results !== [] && !in_array(false, $results, true);
        $evidence = [
            'extension' => 'titan-risk-engine',
            'version' => '1.0.0-rc.3',
            'passed' => $passed,
            'routes' => $results,
        ];

        if ($this->option('json')) {
            $this->line((string) json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        } else {
            foreach ($results as $route => $ok) {
                $this->line(sprintf('%s %s', $ok ? 'PASS' : 'FAIL', $route));
            }
        }

        return $passed ? self::SUCCESS : self::FAILURE;
    }
}
