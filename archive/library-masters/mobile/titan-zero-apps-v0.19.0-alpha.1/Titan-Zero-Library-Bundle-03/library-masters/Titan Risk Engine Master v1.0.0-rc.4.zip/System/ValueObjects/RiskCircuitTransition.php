<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use DateTimeImmutable;

final readonly class RiskCircuitTransition
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public RiskCircuitState $currentState,
        public RiskCircuitState $recommendedState,
        public array $reasonCodes,
        public ?DateTimeImmutable $probeAfter = null,
        public ?DateTimeImmutable $expiresAt = null,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'current_state' => $this->currentState->value,
            'recommended_state' => $this->recommendedState->value,
            'reason_codes' => $this->reasonCodes,
            'probe_after' => $this->probeAfter?->format(DATE_ATOM),
            'expires_at' => $this->expiresAt?->format(DATE_ATOM),
        ];
    }
}
