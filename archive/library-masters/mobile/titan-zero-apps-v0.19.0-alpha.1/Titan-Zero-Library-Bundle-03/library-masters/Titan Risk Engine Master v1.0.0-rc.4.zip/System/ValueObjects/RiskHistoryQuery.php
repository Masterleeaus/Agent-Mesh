<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;

final readonly class RiskHistoryQuery
{
    public function __construct(
        public int|string $companyId,
        public RiskAggregateScope $scope,
        public DateTimeImmutable $from,
        public DateTimeImmutable $to,
        public ?string $capability = null,
        public ?string $actorType = null,
        public int|string|null $actorId = null,
        public ?string $resourceType = null,
        public int|string|null $resourceId = null,
        public ?RiskAggregateWindow $aggregateWindow = null,
        public ?RiskVelocityWindow $velocityWindow = null,
    ) {
        if ((is_int($this->companyId) && $this->companyId <= 0)
            || (is_string($this->companyId) && trim($this->companyId) === '')) {
            throw new InvalidArgumentException('A valid company_id is required for Risk history queries.');
        }

        if ($this->from >= $this->to) {
            throw new InvalidArgumentException('Risk history query from must be earlier than to.');
        }

        match ($this->scope) {
            RiskAggregateScope::TENANT => null,
            RiskAggregateScope::TENANT_CAPABILITY => $this->requireCapability(),
            RiskAggregateScope::TENANT_ACTOR => $this->requireActor(),
            RiskAggregateScope::TENANT_RESOURCE => $this->requireResource(),
            RiskAggregateScope::ACTOR_CAPABILITY => $this->requireActorAndCapability(),
        };
    }

    public static function forAggregateWindow(
        int|string $companyId,
        RiskAggregateScope $scope,
        RiskAggregateWindow $window,
        DateTimeImmutable $asOf,
        ?string $capability = null,
        ?string $actorType = null,
        int|string|null $actorId = null,
        ?string $resourceType = null,
        int|string|null $resourceId = null,
    ): self {
        $to = $asOf->setTimezone(new DateTimeZone('UTC'));
        $from = $to->modify(sprintf('-%d minutes', $window->minutes()));

        return new self(
            companyId: $companyId,
            scope: $scope,
            from: $from,
            to: $to,
            capability: $capability,
            actorType: $actorType,
            actorId: $actorId,
            resourceType: $resourceType,
            resourceId: $resourceId,
            aggregateWindow: $window,
        );
    }

    public static function forVelocityWindow(
        int|string $companyId,
        RiskAggregateScope $scope,
        RiskVelocityWindow $window,
        DateTimeImmutable $asOf,
        ?string $capability = null,
        ?string $actorType = null,
        int|string|null $actorId = null,
        ?string $resourceType = null,
        int|string|null $resourceId = null,
    ): self {
        $to = $asOf->setTimezone(new DateTimeZone('UTC'));
        $from = $to->modify(sprintf('-%d minutes', $window->minutes()));

        return new self(
            companyId: $companyId,
            scope: $scope,
            from: $from,
            to: $to,
            capability: $capability,
            actorType: $actorType,
            actorId: $actorId,
            resourceType: $resourceType,
            resourceId: $resourceId,
            velocityWindow: $window,
        );
    }

    public function durationMinutes(): float
    {
        return max(1.0, ($this->to->getTimestamp() - $this->from->getTimestamp()) / 60.0);
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'scope' => $this->scope->value,
            'from' => $this->from->format(DATE_ATOM),
            'to' => $this->to->format(DATE_ATOM),
            'capability' => $this->capability,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'resource_type' => $this->resourceType,
            'resource_id' => $this->resourceId,
            'aggregate_window_minutes' => $this->aggregateWindow?->minutes(),
            'velocity_window_minutes' => $this->velocityWindow?->minutes(),
        ];
    }

    private function requireCapability(): void
    {
        if ($this->capability === null || trim($this->capability) === '') {
            throw new InvalidArgumentException('capability is required for capability-scoped Risk history queries.');
        }
    }

    private function requireActor(): void
    {
        if ($this->actorType === null || trim($this->actorType) === '' || $this->actorId === null || trim((string) $this->actorId) === '') {
            throw new InvalidArgumentException('actor_type and actor_id are required for actor-scoped Risk history queries.');
        }
    }

    private function requireResource(): void
    {
        if ($this->resourceType === null || trim($this->resourceType) === '' || $this->resourceId === null || trim((string) $this->resourceId) === '') {
            throw new InvalidArgumentException('resource_type and resource_id are required for resource-scoped Risk history queries.');
        }
    }

    private function requireActorAndCapability(): void
    {
        $this->requireActor();
        $this->requireCapability();
    }
}
