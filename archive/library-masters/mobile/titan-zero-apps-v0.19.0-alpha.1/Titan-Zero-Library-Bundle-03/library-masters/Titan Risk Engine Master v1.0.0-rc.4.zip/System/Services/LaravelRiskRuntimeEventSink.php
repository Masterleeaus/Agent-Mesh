<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use Psr\Log\LoggerInterface;
use Throwable;

final class LaravelRiskRuntimeEventSink implements RiskRuntimeEventSinkContract
{
    public function __construct(private readonly LoggerInterface $logger) {}

    public function record(RiskRuntimeEvent $event): void
    {
        try {
            $level = $event->outcome === 'OK' ? 'debug' : 'warning';
            $this->logger->{$level}('Titan Risk runtime event', $event->toArray());
        } catch (Throwable) {
            // Runtime telemetry must never change Risk authority or availability.
        }
    }
}
