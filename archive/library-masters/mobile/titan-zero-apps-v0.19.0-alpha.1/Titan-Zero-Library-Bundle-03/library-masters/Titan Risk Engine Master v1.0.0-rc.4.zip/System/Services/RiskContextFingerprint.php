<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;

final class RiskContextFingerprint
{
    public function authorization(RiskContext $context): string
    {
        $metadata = $this->canonicalize($context->metadata);
        $payload = [
            'company_id' => (string) $context->companyId,
            'capability' => $context->capability,
            'action' => $context->action,
            'actor_type' => strtolower($context->actorType),
            'actor_id' => $context->actorId === null ? null : (string) $context->actorId,
            'resource_type' => $context->resourceType,
            'resource_id' => $context->resourceId === null ? null : (string) $context->resourceId,
            'vertical_key' => $context->verticalKey,
            'jurisdiction' => $context->jurisdiction,
            'impact' => $context->impact->toArray(),
            'reversibility' => $context->reversibility->value,
            'connectivity' => $context->connectivity->value,
            'metadata' => $metadata,
        ];
        return hash('sha256', json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private function canonicalize(mixed $value): mixed
    {
        if (!is_array($value)) return $value;
        $isList = array_is_list($value);
        if (!$isList) ksort($value, SORT_STRING);
        foreach ($value as $key => $item) $value[$key] = $this->canonicalize($item);
        return $value;
    }
}
