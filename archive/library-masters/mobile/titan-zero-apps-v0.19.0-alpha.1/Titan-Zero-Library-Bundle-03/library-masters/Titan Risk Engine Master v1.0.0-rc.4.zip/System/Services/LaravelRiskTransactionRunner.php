<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskTransactionRunnerContract;
use Illuminate\Database\ConnectionInterface;

final class LaravelRiskTransactionRunner implements RiskTransactionRunnerContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly int $attempts = 3,
    ) {}

    public function run(callable $callback): mixed
    {
        return $this->database->transaction($callback, max(1, min(5, $this->attempts)));
    }
}
