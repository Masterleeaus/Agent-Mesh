<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;

interface RiskPolicyChangeStoreContract
{
    public function persist(RiskPolicyChangeEvidence $evidence): void;
}
