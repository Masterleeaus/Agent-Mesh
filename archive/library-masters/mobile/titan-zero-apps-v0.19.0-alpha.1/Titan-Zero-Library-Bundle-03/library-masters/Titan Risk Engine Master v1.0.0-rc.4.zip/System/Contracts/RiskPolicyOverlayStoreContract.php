<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use DateTimeImmutable;

interface RiskPolicyOverlayStoreContract
{
    /** @return list<RiskPolicyOverlay> */
    public function effectiveFor(int|string $companyId, string $capability, DateTimeImmutable $asOf): array;

    public function register(RiskPolicyOverlay $overlay): void;

    /** @return list<RiskPolicyOverlay> */
    public function versionsFor(string $policyKey, \App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope $scope, int|string|null $companyId, ?string $capability): array;
}

