<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskReason;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRemediation;

final class MitigationSuggestionGenerator
{
    /** @param list<RiskReason> $reasons @return list<RiskRemediation> */
    public function for(array $reasons, RiskDecision $decision): array
    {
        $codes = array_fill_keys(array_map(static fn (RiskReason $reason): string => $reason->code, $reasons), true);
        $items = [];

        if (isset($codes['OFFLINE_EXECUTION'])) {
            $items[] = new RiskRemediation(
                'RESTORE_CONNECTIVITY',
                'Reconnect to restore the online checks and authority required for consequential execution.',
            );
        }

        if (isset($codes['DEGRADED_CONNECTIVITY'])) {
            $items[] = new RiskRemediation(
                'STABILISE_CONNECTIVITY',
                'Restore stable connectivity before relying on full autonomous authority.',
            );
        }

        if (isset($codes['IRREVERSIBLE_ACTION'])) {
            $items[] = new RiskRemediation(
                'ADD_REVIEW_OR_REVERSAL_PATH',
                'Add an approval/review step or a compensating rollback path before execution.',
            );
        }

        if ($decision === RiskDecision::REQUIRE_ASSURANCE) {
            $items[] = new RiskRemediation('RUN_ASSURANCE', 'Run Titan Assurance before execution.');
        } elseif ($decision === RiskDecision::REQUIRE_APPROVAL) {
            $items[] = new RiskRemediation('OBTAIN_APPROVAL', 'Obtain the required human or governance approval before execution.');
        } elseif ($decision === RiskDecision::BLOCK) {
            $items[] = new RiskRemediation('REDESIGN_ACTION', 'Reduce the material impact or split the operation into safer, reversible steps before reassessment.');
        }

        $unique = [];
        foreach ($items as $item) {
            $unique[$item->code] = $item;
        }

        return array_values($unique);
    }
}
