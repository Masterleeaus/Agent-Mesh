<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskFeedbackContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGovernanceFeedbackStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\ValueObjects\AssuranceRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ModelCouncilRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGovernanceFeedbackResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ShieldRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use Throwable;

final class RiskFeedbackCoordinator implements RiskFeedbackContract
{
    public function __construct(
        private readonly RiskDirectivePolicy $policy,
        private readonly ?RiskGovernanceFeedbackStoreContract $store = null,
        private readonly ?RiskEnforcementReceiptFactory $receiptFactory = null,
        private readonly ?RiskEnforcementReceiptStoreContract $receiptStore = null,
        private readonly ?RiskSignalOutboxContract $signalOutbox = null,
        private readonly ?RiskSignalDispatcher $signalDispatcher = null,
        private readonly bool $inlineSignalDispatch = false,
        private readonly ?RiskRuntimeEventSinkContract $runtimeEvents = null,
    ) {}

    public function apply(RiskGateResult $current, ModelCouncilRiskEvidence|AssuranceRiskEvidence|ShieldRiskEvidence $evidence): RiskGovernanceFeedbackResult
    {
        return match (true) {
            $evidence instanceof ModelCouncilRiskEvidence => $this->applyModelCouncil($current, $evidence),
            $evidence instanceof AssuranceRiskEvidence => $this->applyAssurance($current, $evidence),
            $evidence instanceof ShieldRiskEvidence => $this->applyShield($current, $evidence),
        };
    }

    public function applyModelCouncil(RiskGateResult $current, ModelCouncilRiskEvidence $evidence): RiskGovernanceFeedbackResult
    {
        $this->assertEvidenceLineage($current, $evidence->traceId, $evidence->correlationId, $evidence->causationId);
        $pressure = max($evidence->disagreementScore, $evidence->uncertaintyScore);
        $candidate = $pressure >= 90.0
            ? RiskExecutionDirective::HOLD_FOR_APPROVAL
            : ($pressure >= 70.0 ? RiskExecutionDirective::HOLD_FOR_ASSURANCE : $current->directive);
        $reasons = $evidence->reasonCodes;
        if ($pressure >= 90.0) $reasons[] = 'COUNCIL_CRITICAL_UNCERTAINTY';
        elseif ($pressure >= 70.0) $reasons[] = 'COUNCIL_HIGH_UNCERTAINTY';
        return $this->finalize($current, $evidence->source(), $evidence->evidenceId, $evidence->traceId, $evidence->correlationId, $evidence->causationId, $evidence->occurredAt, $this->policy->stricter($current->directive, $candidate), $reasons);
    }

    public function applyAssurance(RiskGateResult $current, AssuranceRiskEvidence $evidence): RiskGovernanceFeedbackResult
    {
        $this->assertEvidenceLineage($current, $evidence->traceId, $evidence->correlationId, $evidence->causationId);
        $directive = $current->directive;
        $reasons = $evidence->reasonCodes;
        if (!$evidence->passed) {
            $directive = $this->policy->stricter($directive, RiskExecutionDirective::HOLD_FOR_APPROVAL);
            $reasons[] = 'ASSURANCE_NOT_SATISFIED';
        } elseif ($this->canAssuranceRelease($current, $evidence)) {
            $directive = RiskExecutionDirective::EXECUTE_MONITORED;
            $reasons[] = 'ASSURANCE_SATISFIED_MONITORED_RELEASE';
        } else {
            $reasons[] = 'ASSURANCE_CANNOT_OVERRIDE_EXISTING_CONSTRAINT';
        }
        return $this->finalize($current, $evidence->source(), $evidence->evidenceId, $evidence->traceId, $evidence->correlationId, $evidence->causationId, $evidence->occurredAt, $directive, $reasons);
    }

    public function applyShield(RiskGateResult $current, ShieldRiskEvidence $evidence): RiskGovernanceFeedbackResult
    {
        $this->assertEvidenceLineage($current, $evidence->traceId, $evidence->correlationId, $evidence->causationId);
        $candidate = $evidence->blocking
            ? RiskExecutionDirective::DENY
            : (!$evidence->passed ? RiskExecutionDirective::HOLD_FOR_APPROVAL : $current->directive);
        $reasons = $evidence->reasonCodes;
        if ($evidence->blocking) $reasons[] = 'SHIELD_BLOCKING_CONSTRAINT';
        elseif (!$evidence->passed) $reasons[] = 'SHIELD_VALIDATION_NOT_SATISFIED';
        return $this->finalize($current, $evidence->source(), $evidence->evidenceId, $evidence->traceId, $evidence->correlationId, $evidence->causationId, $evidence->occurredAt, $this->policy->stricter($current->directive, $candidate), $reasons);
    }


    private function assertEvidenceLineage(RiskGateResult $current, string $traceId, string $correlationId, string $causationId): void
    {
        $context = $current->assessment->context;
        if (!hash_equals($context->traceId, $traceId)
            || !hash_equals($context->correlationId, $correlationId)
            || !hash_equals($context->causationId, $causationId)) {
            throw new \RuntimeException('RISK_GOVERNANCE_EVIDENCE_LINEAGE_MISMATCH');
        }
    }

    private function canAssuranceRelease(RiskGateResult $current, AssuranceRiskEvidence $evidence): bool
    {
        if ($current->directive !== RiskExecutionDirective::HOLD_FOR_ASSURANCE) return false;
        if ($current->assessment->decision !== RiskDecision::REQUIRE_ASSURANCE) return false;
        if ($current->assessment->isBlocked() || $evidence->assuranceScore < 80.0) return false;
        foreach ($current->circuits as $circuit) {
            if ($circuit->state !== RiskCircuitState::CLOSED) return false;
        }
        return true;
    }

    /** @param list<string> $reasonCodes */
    private function finalize(RiskGateResult $current, string $source, string $evidenceId, string $traceId, string $correlationId, string $causationId, \DateTimeImmutable $at, RiskExecutionDirective $directive, array $reasonCodes): RiskGovernanceFeedbackResult
    {
        $result = new RiskGovernanceFeedbackResult(
            companyId: $current->assessment->context->companyId,
            traceId: $traceId,
            correlationId: $correlationId,
            causationId: $causationId,
            source: $source,
            evidenceId: $evidenceId,
            originalDirective: $current->directive,
            directive: $directive,
            reasonCodes: array_values(array_unique($reasonCodes)),
            appliedAt: $at,
        );
        if ($this->receiptFactory !== null && $this->receiptStore !== null) {
            $receipt = $this->receiptFactory->makeForFeedback($current, $result);
            $this->receiptStore->persist($receipt);
            $result = $result->withReceipt($receipt);
        }
        $this->store?->persist($result);
        if ($this->signalOutbox !== null) {
            try {
                $this->signalOutbox->stage(RiskSignalEvent::forFeedback($current, $result));
                if ($this->inlineSignalDispatch) $this->signalDispatcher?->dispatchPending(10);
            } catch (Throwable $failure) {
                if ($this->runtimeEvents !== null) {
                    try {
                        $context = $current->assessment->context;
                        $this->runtimeEvents->record(new RiskRuntimeEvent(
                            operation: 'risk.feedback',
                            outcome: 'GOVERNANCE_SIGNAL_OUTBOX_DEGRADED',
                            elapsedMilliseconds: 0.0,
                            companyId: $context->companyId,
                            traceId: $traceId,
                            correlationId: $correlationId,
                            causationId: $causationId,
                            capability: $context->capability,
                            errorClass: $failure::class,
                        ));
                    } catch (Throwable) {
                        // Telemetry failure cannot alter feedback authority.
                    }
                }
            }
        }
        return $result;
    }
}
