<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class AssuranceRiskEvidence
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public string $evidenceId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public DateTimeImmutable $occurredAt,
        public bool $passed,
        public float $assuranceScore,
        public array $reasonCodes = [],
    ) {
        RiskFieldConstraints::text('evidenceId', $this->evidenceId, 191, false);
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        if (!is_finite($this->assuranceScore) || $this->assuranceScore < 0.0 || $this->assuranceScore > 100.0) throw new InvalidArgumentException('Assurance score must be finite and between 0 and 100.');
        if (count($this->reasonCodes) > 50) throw new InvalidArgumentException('Assurance reasonCodes must contain at most 50 entries.');
        foreach ($this->reasonCodes as $reason) RiskFieldConstraints::text('reasonCode', $reason, 120, false);
    }

    public function source(): string { return 'ASSURANCE'; }
}
