<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\AssuranceRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ModelCouncilRiskEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGovernanceFeedbackResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\ShieldRiskEvidence;

interface RiskFeedbackContract
{
    public function apply(
        RiskGateResult $current,
        ModelCouncilRiskEvidence|AssuranceRiskEvidence|ShieldRiskEvidence $evidence,
    ): RiskGovernanceFeedbackResult;
}
