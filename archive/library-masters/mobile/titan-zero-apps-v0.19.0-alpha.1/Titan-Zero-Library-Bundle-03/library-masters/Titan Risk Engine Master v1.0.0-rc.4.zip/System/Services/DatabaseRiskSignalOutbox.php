<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use DateTimeImmutable;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;
use RuntimeException;

final class DatabaseRiskSignalOutbox implements RiskSignalOutboxContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_signal_outbox',
        private readonly int $maxAttempts = 20,
        private readonly int $retryDelaySeconds = 30,
    ) {}

    public function stage(RiskSignalEvent $event): void
    {
        $utc = new DateTimeZone('UTC');
        $stamp = $event->occurredAt->setTimezone($utc)->format('Y-m-d H:i:s.u');
        $payload = json_encode($event->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        $this->database->table($this->table)->insertOrIgnore([
            'event_id' => $event->eventId,
            'event_type' => $event->type->value,
            'company_id' => $event->companyId,
            'trace_id' => $event->traceId,
            'correlation_id' => $event->correlationId,
            'causation_id' => $event->causationId,
            'root_causation_id' => $event->rootCausationId,
            'severity' => $event->severity,
            'event_payload' => $payload,
            'occurred_at' => $stamp,
            'attempts' => 0,
            'created_at' => $stamp,
            'updated_at' => $stamp,
        ]);
    }

    public function pending(int $limit = 100): array
    {
        $cutoff = (new DateTimeImmutable('now', new DateTimeZone('UTC')))
            ->modify('-' . max(30, $this->retryDelaySeconds) . ' seconds')
            ->format('Y-m-d H:i:s.u');
        $rows = $this->database->table($this->table)
            ->whereNull('published_at')
            ->where('attempts', '<', max(1, $this->maxAttempts))
            ->where(function ($query) use ($cutoff): void {
                $query->whereNull('last_attempt_at')->orWhere('last_attempt_at', '<=', $cutoff);
            })
            ->orderBy('occurred_at')
            ->orderBy('id')
            ->limit(max(1, min(1000, $limit)))
            ->get(['event_payload']);
        $events = [];
        foreach ($rows as $row) {
            $decoded = json_decode((string) $row->event_payload, true, 64, JSON_THROW_ON_ERROR);
            if (!is_array($decoded)) throw new RuntimeException('RISK_SIGNAL_OUTBOX_PAYLOAD_INVALID');
            $events[] = RiskSignalEvent::fromArray($decoded);
        }
        return $events;
    }

    public function markPublished(string $eventId, DateTimeImmutable $publishedAt): void
    {
        $stamp = $publishedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        $this->database->table($this->table)->where('event_id', $eventId)->whereNull('published_at')->update([
            'published_at' => $stamp,
            'last_attempt_at' => $stamp,
            'last_error' => null,
            'updated_at' => $stamp,
        ]);
    }

    public function markFailed(string $eventId, string $error, DateTimeImmutable $failedAt): void
    {
        $stamp = $failedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        $this->database->table($this->table)->where('event_id', $eventId)->whereNull('published_at')->increment('attempts', 1, [
            'last_attempt_at' => $stamp,
            'last_error' => mb_substr($error, 0, 2000),
            'updated_at' => $stamp,
        ]);
    }
}
