<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use Illuminate\Contracts\Events\Dispatcher;

final class LaravelRiskSignalPublisher implements RiskSignalPublisherContract
{
    public function __construct(
        private readonly Dispatcher $events,
        private readonly string $eventName = 'titan.signal.ingest',
    ) {}

    public function publish(RiskSignalEvent $event): bool
    {
        if (!$this->events->hasListeners($this->eventName)) return false;
        $this->events->dispatch($this->eventName, [$event->toArray()]);
        return true;
    }
}
