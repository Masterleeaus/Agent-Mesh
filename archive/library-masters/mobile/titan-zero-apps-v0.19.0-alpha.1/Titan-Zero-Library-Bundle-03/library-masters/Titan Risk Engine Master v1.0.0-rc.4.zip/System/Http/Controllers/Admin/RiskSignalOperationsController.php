<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Http\Controllers\Admin;

use App\Extensions\TitanRiskEngine\System\Services\RiskSignalDispatcher;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

final class RiskSignalOperationsController
{
    public function dispatch(Request $request, RiskSignalDispatcher $dispatcher): RedirectResponse
    {
        $data = $request->validate([
            'company_id' => ['required', 'integer', 'min:1'],
            'limit' => ['nullable', 'integer', 'min:1', 'max:500'],
        ]);
        $delivered = $dispatcher->dispatchPending((int) ($data['limit'] ?? 100));
        return redirect()->route('dashboard.admin.titan.risk.engine.control-centre', ['company_id' => (int) $data['company_id']])
            ->with('success', sprintf('Signal dispatch completed: %d event(s) acknowledged.', $delivered));
    }
}
