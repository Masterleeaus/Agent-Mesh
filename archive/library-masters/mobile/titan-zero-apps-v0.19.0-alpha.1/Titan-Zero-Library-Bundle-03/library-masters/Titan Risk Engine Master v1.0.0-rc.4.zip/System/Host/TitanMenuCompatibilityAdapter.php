<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Host;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Host navigation bridge.
 *
 * Uses Titan's modern MenuContributionRegistry when present. Installer 1.7.6 /
 * MagicAI hosts fall back to the canonical `menus` table followed by
 * App\Services\Common\MenuService::regenerate(). Existing order/enabled state
 * is never overwritten when a row already exists.
 */
final class TitanMenuCompatibilityAdapter
{
    /** @param list<array<string, mixed>> $definitions
     *  @return array<string, bool>
     */
    public function remove(array $definitions): array
    {
        $results = [];
        foreach ($definitions as $definition) {
            $route = trim((string) ($definition['route'] ?? ''));
            if ($route === '') continue;
            $removed = $this->removeModern($definition);
            $removed = $this->removeLegacy($route) || $removed;
            $results[$route] = $removed;
        }

        if (in_array(true, $results, true)) {
            $this->regenerateLegacyMenuCache();
        }

        return $results;
    }

    /** @param list<array<string, mixed>> $definitions
     *  @return array<string, bool>
     */
    public function sync(array $definitions): array
    {
        $results = [];
        foreach ($definitions as $definition) {
            $route = (string) ($definition['route'] ?? '');
            if ($route === '') continue;
            $results[$route] = $this->register($definition);
        }

        if (in_array(true, $results, true)) {
            $this->regenerateLegacyMenuCache();
        }

        return $results;
    }

    /** @param array<string, mixed> $definition */
    public function register(array $definition): bool
    {
        if ($this->registerModern($definition)) return true;
        return $this->registerLegacy($definition);
    }

    public function isRegistered(string $route): bool
    {
        if ($route === '') return false;

        try {
            if (app()->bound('MenuContributionRegistry')) {
                $registry = app('MenuContributionRegistry');
                foreach (['hasRoute', 'has', 'contains'] as $method) {
                    if (method_exists($registry, $method)) {
                        return (bool) $registry->{$method}($route);
                    }
                }
            }

            if (!Schema::hasTable('menus')) return false;
            $columns = Schema::getColumnListing('menus');
            $routeColumn = $this->firstExistingColumn($columns, ['route', 'route_name']);
            if ($routeColumn === null) return false;

            return DB::table('menus')->where($routeColumn, $route)->exists();
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Pure column-aware payload builder used by the legacy adapter and tests.
     *
     * @param list<string> $columns
     * @param array<string, mixed> $definition
     * @return array<string, mixed>
     */
    public static function buildLegacyPayload(array $columns, array $definition, bool $existing): array
    {
        $has = static fn (string $column): bool => in_array($column, $columns, true);
        $payload = [];
        $label = (string) ($definition['label'] ?? 'Titan Risk');
        $icon = (string) ($definition['icon'] ?? 'tabler-folders');
        $area = (string) ($definition['area'] ?? 'user');
        $order = (int) ($definition['order'] ?? 180);
        $enabled = (bool) ($definition['enabled'] ?? true);
        $id = (string) ($definition['id'] ?? ('titan-risk-engine-' . $area));

        foreach (['name', 'label', 'title'] as $column) {
            if ($has($column)) $payload[$column] = $label;
        }
        if ($has('icon')) $payload['icon'] = $icon;
        if ($has('permission')) $payload['permission'] = $definition['permission'] ?? null;
        if ($has('permission_name')) $payload['permission_name'] = $definition['permission'] ?? null;
        foreach (['slug', 'key', 'code'] as $column) {
            if ($has($column)) $payload[$column] = $id;
        }
        foreach (['menu_type', 'scope', 'section', 'area'] as $column) {
            if ($has($column)) $payload[$column] = $area;
        }

        if (!$existing) {
            foreach (['order', 'sort', 'position'] as $column) {
                if ($has($column)) $payload[$column] = $order;
            }
            foreach (['enabled', 'status', 'is_active'] as $column) {
                if ($has($column)) $payload[$column] = $enabled ? 1 : 0;
            }
        }

        if ($has('updated_at')) $payload['updated_at'] = now();
        if (!$existing && $has('created_at')) $payload['created_at'] = now();

        return $payload;
    }

    /** @param array<string, mixed> $definition */
    private function removeModern(array $definition): bool
    {
        try {
            if (!app()->bound('MenuContributionRegistry')) return false;
            $registry = app('MenuContributionRegistry');
            foreach (['unregister', 'remove'] as $method) {
                if (!method_exists($registry, $method)) continue;
                try {
                    $registry->{$method}($definition);
                } catch (Throwable) {
                    $registry->{$method}((string) ($definition['route'] ?? ''));
                }
                return true;
            }
            return false;
        } catch (Throwable) {
            return false;
        }
    }

    private function removeLegacy(string $route): bool
    {
        try {
            if (!Schema::hasTable('menus')) return false;
            $columns = Schema::getColumnListing('menus');
            $routeColumn = $this->firstExistingColumn($columns, ['route', 'route_name']);
            if ($routeColumn === null) return false;
            DB::table('menus')->where($routeColumn, $route)->delete();
            return true;
        } catch (Throwable $exception) {
            $this->logWarning('Titan Risk navigation legacy removal failed.', $exception);
            return false;
        }
    }

    /** @param array<string, mixed> $definition */
    private function registerModern(array $definition): bool
    {
        try {
            if (!app()->bound('MenuContributionRegistry')) return false;
            $registry = app('MenuContributionRegistry');
            if (!method_exists($registry, 'register')) return false;
            $registry->register($definition);
            return true;
        } catch (Throwable) {
            return false;
        }
    }

    /** @param array<string, mixed> $definition */
    private function registerLegacy(array $definition): bool
    {
        try {
            if (!Schema::hasTable('menus')) return false;
            $columns = Schema::getColumnListing('menus');
            $routeColumn = $this->firstExistingColumn($columns, ['route', 'route_name']);
            if ($routeColumn === null) return false;

            $route = trim((string) ($definition['route'] ?? ''));
            if ($route === '') return false;

            $query = DB::table('menus')->where($routeColumn, $route);
            $existing = $query->first();
            $payload = self::buildLegacyPayload($columns, $definition, $existing !== null);
            $parentDatabaseId = $this->resolveLegacyParentDatabaseId($columns, $definition, $routeColumn);
            if (!empty($definition['parent_route']) && $parentDatabaseId === null) {
                $this->logWarningMessage('Titan Risk navigation child parent could not be resolved.', [
                    'route' => $route,
                    'parent_route' => (string) $definition['parent_route'],
                ]);
                return false;
            }
            $payload = self::applyLegacyParentReference($columns, $definition, $payload, $parentDatabaseId);

            if ($existing !== null) {
                if ($payload !== []) $query->update($payload);
                return true;
            }

            $row = array_merge([$routeColumn => $route], $payload);
            $row = $this->copyHostPlacementColumns($row, $columns, $definition, $routeColumn);
            $row = $this->completeRequiredLegacyColumns($row, $columns, $definition, $routeColumn);
            DB::table('menus')->insert($row);
            return true;
        } catch (Throwable $exception) {
            $this->logWarning('Titan Risk navigation legacy registration failed.', $exception);
            return false;
        }
    }


    /**
     * Apply the host's physical parent reference without trusting a caller-
     * supplied database id. Parent ids are resolved from the registered
     * parent route by resolveLegacyParentDatabaseId().
     *
     * @param list<string> $columns
     * @param array<string, mixed> $definition
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public static function applyLegacyParentReference(array $columns, array $definition, array $payload, ?int $parentDatabaseId): array
    {
        $parentColumn = null;
        foreach (['parent_id', 'parent_menu_id'] as $candidate) {
            if (in_array($candidate, $columns, true)) {
                $parentColumn = $candidate;
                break;
            }
        }
        if ($parentColumn === null) return $payload;

        if (!empty($definition['parent_route'])) {
            if ($parentDatabaseId !== null && $parentDatabaseId > 0) {
                $payload[$parentColumn] = $parentDatabaseId;
            }
            return $payload;
        }

        // Canonical Risk parent is always top-level. This also repairs an
        // accidentally nested parent row from an earlier host customization.
        $payload[$parentColumn] = 0;
        return $payload;
    }

    /** @param list<string> $columns
     *  @param array<string, mixed> $definition
     */
    private function resolveLegacyParentDatabaseId(array $columns, array $definition, string $routeColumn): ?int
    {
        $parentRoute = trim((string) ($definition['parent_route'] ?? ''));
        if ($parentRoute === '') return null;

        $idColumn = $this->firstExistingColumn($columns, ['id', 'menu_id']);
        if ($idColumn === null) return null;

        try {
            $value = DB::table('menus')->where($routeColumn, $parentRoute)->value($idColumn);
            return is_numeric($value) && (int) $value > 0 ? (int) $value : null;
        } catch (Throwable) {
            return null;
        }
    }

    /**
     * Copy host-specific placement/role fields from an existing menu in the
     * same area when those columns exist. This avoids assuming the host's
     * internal values for fields such as `type`, `role` or `menu_group`.
     *
     * @param array<string, mixed> $row
     * @param list<string> $columns
     * @param array<string, mixed> $definition
     * @return array<string, mixed>
     */
    private function copyHostPlacementColumns(array $row, array $columns, array $definition, string $routeColumn): array
    {
        $area = (string) ($definition['area'] ?? 'user');
        $donor = $this->legacyDonorRow($routeColumn, $area);
        if ($donor === null) return $row;

        foreach (['type', 'user_type', 'role', 'role_type', 'guard', 'menu_group', 'group', 'location'] as $field) {
            if (!in_array($field, $columns, true) || array_key_exists($field, $row)) continue;
            if (array_key_exists($field, $donor) && $donor[$field] !== null) $row[$field] = $donor[$field];
        }

        return $row;
    }

    /**
     * Fill only host-required columns that lack defaults. Where the table has
     * host-specific required fields, copy them from a nearby existing menu row
     * (prefer the same admin/user area) rather than guessing host semantics.
     *
     * @param array<string, mixed> $row
     * @param list<string> $columns
     * @param array<string, mixed> $definition
     * @return array<string, mixed>
     */
    private function completeRequiredLegacyColumns(array $row, array $columns, array $definition, string $routeColumn): array
    {
        $metadata = [];
        try {
            foreach (DB::select('SHOW COLUMNS FROM `menus`') as $column) {
                $data = (array) $column;
                $field = (string) ($data['Field'] ?? $data['field'] ?? '');
                if ($field !== '') $metadata[$field] = $data;
            }
        } catch (Throwable) {
            return $row;
        }

        $area = (string) ($definition['area'] ?? 'user');
        $donor = $this->legacyDonorRow($routeColumn, $area);
        foreach ($metadata as $field => $column) {
            if (array_key_exists($field, $row)) continue;
            $nullable = strtoupper((string) ($column['Null'] ?? $column['null'] ?? 'YES')) === 'YES';
            $defaultExists = array_key_exists('Default', $column) || array_key_exists('default', $column);
            $default = $column['Default'] ?? $column['default'] ?? null;
            $extra = strtolower((string) ($column['Extra'] ?? $column['extra'] ?? ''));
            if (str_contains($extra, 'auto_increment') || $nullable || ($defaultExists && $default !== null)) continue;

            if (is_array($donor) && array_key_exists($field, $donor) && $donor[$field] !== null) {
                $row[$field] = $donor[$field];
                continue;
            }

            $type = strtolower((string) ($column['Type'] ?? $column['type'] ?? ''));
            $row[$field] = $this->fallbackRequiredValue($field, $type, $definition);
        }

        return $row;
    }

    /** @return array<string, mixed>|null */
    private function legacyDonorRow(string $routeColumn, string $area): ?array
    {
        try {
            $prefix = $area === 'admin' ? 'dashboard.admin.%' : 'dashboard.user.%';
            $donor = DB::table('menus')->where($routeColumn, 'like', $prefix)->first();
            if ($donor === null) $donor = DB::table('menus')->first();
            return $donor === null ? null : (array) $donor;
        } catch (Throwable) {
            return null;
        }
    }

    /** @param array<string, mixed> $definition */
    private function fallbackRequiredValue(string $field, string $type, array $definition): mixed
    {
        $area = (string) ($definition['area'] ?? 'user');
        $label = (string) ($definition['label'] ?? 'Titan Risk');
        $id = (string) ($definition['id'] ?? ('titan-risk-engine-' . $area));

        return match ($field) {
            'name', 'label', 'title' => $label,
            'icon' => (string) ($definition['icon'] ?? 'tabler-folders'),
            'slug', 'key', 'code' => $id,
            'menu_type', 'scope', 'section', 'area' => $area,
            'order', 'sort', 'position', 'parent_id' => 0,
            'enabled', 'status', 'is_active' => 1,
            'created_at', 'updated_at' => now(),
            default => str_contains($type, 'int') || str_contains($type, 'decimal') || str_contains($type, 'float') || str_contains($type, 'double')
                ? 0
                : (str_contains($type, 'json') ? '[]' : ''),
        };
    }

    /** @param list<string> $columns
     *  @param list<string> $candidates
     */
    private function firstExistingColumn(array $columns, array $candidates): ?string
    {
        foreach ($candidates as $candidate) {
            if (in_array($candidate, $columns, true)) return $candidate;
        }
        return null;
    }

    private function regenerateLegacyMenuCache(): void
    {
        try {
            $class = 'App\\Services\\Common\\MenuService';
            if (!class_exists($class)) return;
            $service = app($class);
            if (method_exists($service, 'regenerate')) $service->regenerate();
        } catch (Throwable $exception) {
            $this->logWarning('Titan Risk navigation cache regeneration failed.', $exception);
        }
    }

    /** @param array<string, mixed> $context */
    private function logWarningMessage(string $message, array $context = []): void
    {
        try {
            app('log')->warning($message, array_merge(['extension' => 'titan-risk-engine'], $context));
        } catch (Throwable) {
            // Navigation is non-authoritative; never break host boot for logging.
        }
    }

    private function logWarning(string $message, Throwable $exception): void
    {
        try {
            app('log')->warning($message, [
                'extension' => 'titan-risk-engine',
                'exception' => $exception::class,
            ]);
        } catch (Throwable) {
            // Navigation is non-authoritative; never break host boot for logging.
        }
    }
}
