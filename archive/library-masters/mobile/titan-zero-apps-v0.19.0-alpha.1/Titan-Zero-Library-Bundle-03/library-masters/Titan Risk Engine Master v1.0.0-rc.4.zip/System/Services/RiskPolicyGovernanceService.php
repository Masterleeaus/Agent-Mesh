<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskBudgetStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyOverlayStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskTransactionRunnerContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskOperationalBudget;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyOverlay;
use DateTimeImmutable;
use InvalidArgumentException;

final class RiskPolicyGovernanceService
{
    public function __construct(
        private readonly RiskBudgetStoreContract $budgets,
        private readonly RiskPolicyOverlayStoreContract $overlays,
        private readonly RiskPolicyChangeStoreContract $changes,
        private readonly ?RiskTransactionRunnerContract $transactions = null,
    ) {}

    public function scheduleBudget(RiskOperationalBudget $budget, RiskPolicyChangeEvidence $evidence): void
    {
        if ($evidence->action !== 'BUDGET_SCHEDULED') throw new InvalidArgumentException('Budget scheduling requires BUDGET_SCHEDULED evidence.');
        if ((string) $evidence->companyId !== (string) $budget->companyId || $evidence->version !== $budget->version) {
            throw new InvalidArgumentException('Budget evidence must match tenant and version.');
        }
        $this->atomic(function () use ($budget, $evidence): void {
            $this->budgets->register($budget);
            $this->changes->persist($evidence);
        });
    }

    public function scheduleOverlay(RiskPolicyOverlay $overlay, RiskPolicyChangeEvidence $evidence): void
    {
        if ($evidence->action !== 'POLICY_SCHEDULED') throw new InvalidArgumentException('Policy scheduling requires POLICY_SCHEDULED evidence.');
        if ($evidence->policyKey !== $overlay->policyKey || $evidence->version !== $overlay->version) {
            throw new InvalidArgumentException('Policy evidence must match policy key and version.');
        }
        if ($overlay->companyId !== null && (string) $evidence->companyId !== (string) $overlay->companyId) {
            throw new InvalidArgumentException('Policy evidence tenant does not match overlay tenant.');
        }
        $this->atomic(function () use ($overlay, $evidence): void {
            $this->overlays->register($overlay);
            $this->changes->persist($evidence);
        });
    }

    public function rollbackBudget(int|string $companyId, string $targetVersion, string $newVersion, DateTimeImmutable $effectiveAt, RiskPolicyChangeEvidence $evidence): RiskOperationalBudget
    {
        if ($evidence->action !== 'BUDGET_ROLLBACK_SCHEDULED' || $evidence->version !== $newVersion) {
            throw new InvalidArgumentException('Budget rollback requires matching BUDGET_ROLLBACK_SCHEDULED evidence.');
        }
        return $this->atomic(function () use ($companyId, $targetVersion, $newVersion, $effectiveAt, $evidence): RiskOperationalBudget {
            $versions = $this->budgets->versionsFor($companyId);
            $target = null; $current = null;
            foreach ($versions as $candidate) {
                if ($candidate->version === $targetVersion) $target = $candidate;
                if ($candidate->effectiveAt <= $effectiveAt && ($current === null || $candidate->effectiveAt > $current->effectiveAt)) $current = $candidate;
            }
            if ($target === null) throw new InvalidArgumentException('Risk budget rollback target version does not exist.');
            if ($target->effectiveAt > $effectiveAt) throw new InvalidArgumentException('Risk budget rollback target cannot originate in the future.');
            $rollback = new RiskOperationalBudget(
                companyId: $companyId,
                version: $newVersion,
                maxDailyRiskExposure: $target->maxDailyRiskExposure,
                maxAutonomousSingleActionLevel: $target->maxAutonomousSingleActionLevel,
                monitoringThresholdRatio: $target->monitoringThresholdRatio,
                effectiveAt: $effectiveAt,
                source: 'ROLLBACK',
                supersedesVersion: $current?->version,
            );
            $this->budgets->register($rollback);
            $this->changes->persist($evidence);
            return $rollback;
        });
    }

    public function rollbackOverlay(string $policyKey, RiskPolicyScope $scope, int|string|null $companyId, ?string $capability, string $targetVersion, string $newVersion, DateTimeImmutable $effectiveAt, RiskPolicyChangeEvidence $evidence): RiskPolicyOverlay
    {
        if ($evidence->action !== 'POLICY_ROLLBACK_SCHEDULED' || $evidence->policyKey !== $policyKey || $evidence->version !== $newVersion) {
            throw new InvalidArgumentException('Policy rollback requires matching POLICY_ROLLBACK_SCHEDULED evidence.');
        }
        return $this->atomic(function () use ($policyKey, $scope, $companyId, $capability, $targetVersion, $newVersion, $effectiveAt, $evidence): RiskPolicyOverlay {
            $versions = $this->overlays->versionsFor($policyKey, $scope, $companyId, $capability);
            $target = null; $current = null;
            foreach ($versions as $candidate) {
                if ($candidate->version === $targetVersion) $target = $candidate;
                if ($candidate->effectiveAt <= $effectiveAt && ($current === null || $candidate->effectiveAt > $current->effectiveAt)) $current = $candidate;
            }
            if ($target === null) throw new InvalidArgumentException('Risk policy rollback target version does not exist.');
            if ($target->effectiveAt > $effectiveAt) throw new InvalidArgumentException('Risk policy rollback target cannot originate in the future.');
            $rollback = new RiskPolicyOverlay(
                policyKey: $policyKey,
                version: $newVersion,
                scope: $scope,
                constraints: $target->constraints,
                effectiveAt: $effectiveAt,
                companyId: $companyId,
                capability: $capability,
                supersedesVersion: $current?->version,
            );
            $this->overlays->register($rollback);
            $this->changes->persist($evidence);
            return $rollback;
        });
    }

    private function atomic(callable $callback): mixed
    {
        if ($this->transactions !== null) {
            return $this->transactions->run($callback);
        }
        return $callback();
    }
}
