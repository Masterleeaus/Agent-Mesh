<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskCircuitScope: string
{
    case TENANT = 'TENANT';
    case TENANT_CAPABILITY = 'TENANT_CAPABILITY';
}
