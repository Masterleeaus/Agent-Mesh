<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyVersion;

interface RiskPolicyRegistryContract
{
    public function current(string $policy): RiskPolicyVersion;

    public function find(string $policy, string $version): ?RiskPolicyVersion;

    /** @return list<RiskPolicyVersion> */
    public function all(): array;
}
