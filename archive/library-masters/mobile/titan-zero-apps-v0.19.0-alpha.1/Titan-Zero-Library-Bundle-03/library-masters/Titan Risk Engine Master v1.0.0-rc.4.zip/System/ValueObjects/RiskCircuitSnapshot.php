<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use DateTimeImmutable;

final readonly class RiskCircuitSnapshot
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public RiskCircuitKey $key,
        public RiskCircuitState $state,
        public int $version,
        public array $reasonCodes,
        public string $policyVersion,
        public DateTimeImmutable $lastTransitionAt,
        public ?DateTimeImmutable $openedAt = null,
        public ?DateTimeImmutable $halfOpenedAt = null,
        public ?DateTimeImmutable $probeAfter = null,
        public ?DateTimeImmutable $expiresAt = null,
        public int $successfulProbeCount = 0,
        public int|string|null $storageId = null,
    ) {}

    public static function closed(RiskCircuitKey $key, DateTimeImmutable $at, string $policyVersion, int|string|null $storageId = null): self
    {
        return new self($key, RiskCircuitState::CLOSED, 1, [], $policyVersion, $at, null, null, null, null, 0, $storageId);
    }

    /** @param list<string> $reasonCodes */
    public function transitioned(
        RiskCircuitState $nextState,
        array $reasonCodes,
        DateTimeImmutable $at,
        ?DateTimeImmutable $probeAfter,
        ?DateTimeImmutable $expiresAt,
        int $successfulProbeCount,
    ): self {
        $openedAt = $this->openedAt;
        $halfOpenedAt = $this->halfOpenedAt;
        if ($nextState === RiskCircuitState::OPEN) {
            $openedAt = $this->state === RiskCircuitState::OPEN ? $this->openedAt : $at;
            $halfOpenedAt = null;
        } elseif ($nextState === RiskCircuitState::HALF_OPEN) {
            $halfOpenedAt = $this->state === RiskCircuitState::HALF_OPEN ? $this->halfOpenedAt : $at;
        } elseif ($nextState === RiskCircuitState::CLOSED) {
            $openedAt = null;
            $halfOpenedAt = null;
            $probeAfter = null;
            $expiresAt = null;
            $successfulProbeCount = 0;
        }

        return new self(
            $this->key,
            $nextState,
            $this->version + 1,
            array_values(array_unique($reasonCodes)),
            $this->policyVersion,
            $at,
            $openedAt,
            $halfOpenedAt,
            $probeAfter,
            $expiresAt,
            $successfulProbeCount,
            $this->storageId,
        );
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            ...$this->key->toArray(),
            'state' => $this->state->value,
            'version' => $this->version,
            'reason_codes' => $this->reasonCodes,
            'policy_version' => $this->policyVersion,
            'last_transition_at' => $this->lastTransitionAt->format(DATE_ATOM),
            'opened_at' => $this->openedAt?->format(DATE_ATOM),
            'half_opened_at' => $this->halfOpenedAt?->format(DATE_ATOM),
            'probe_after' => $this->probeAfter?->format(DATE_ATOM),
            'expires_at' => $this->expiresAt?->format(DATE_ATOM),
            'successful_probe_count' => $this->successfulProbeCount,
            'normal_dispatch_allowed' => $this->state === RiskCircuitState::CLOSED,
        ];
    }
}
