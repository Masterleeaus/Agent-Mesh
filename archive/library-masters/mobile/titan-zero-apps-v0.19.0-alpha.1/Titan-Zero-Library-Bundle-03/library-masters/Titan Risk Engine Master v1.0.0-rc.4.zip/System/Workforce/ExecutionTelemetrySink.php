<?php
declare(strict_types=1);
namespace App\Extensions\TitanRiskEngine\System\Workforce;
interface ExecutionTelemetrySink { public function record(array $event): void; }
