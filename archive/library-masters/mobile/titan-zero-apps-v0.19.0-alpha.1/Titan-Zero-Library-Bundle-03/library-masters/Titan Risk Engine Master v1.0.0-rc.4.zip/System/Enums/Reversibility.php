<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum Reversibility: string
{
    case REVERSIBLE = 'REVERSIBLE';
    case PARTIALLY_REVERSIBLE = 'PARTIALLY_REVERSIBLE';
    case IRREVERSIBLE = 'IRREVERSIBLE';
}
