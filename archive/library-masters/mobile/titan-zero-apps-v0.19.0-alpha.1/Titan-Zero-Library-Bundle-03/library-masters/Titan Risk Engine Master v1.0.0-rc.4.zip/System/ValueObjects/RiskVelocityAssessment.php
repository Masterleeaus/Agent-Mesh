<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;

final readonly class RiskVelocityAssessment
{
    /** @param list<string> $reasonCodes */
    public function __construct(
        public RiskExposureSnapshot $exposure,
        public RiskVelocityWindow $window,
        public RiskVelocityLevel $level,
        public float $actionsPerMinute,
        public float $scorePointsPerMinute,
        public array $reasonCodes,
        public string $policyVersion = 'intelligence-v1',
    ) {}

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'exposure' => $this->exposure->toArray(),
            'window_minutes' => $this->window->minutes(),
            'level' => $this->level->value,
            'actions_per_minute' => $this->actionsPerMinute,
            'score_points_per_minute' => $this->scorePointsPerMinute,
            'reason_codes' => $this->reasonCodes,
            'policy_version' => $this->policyVersion,
            'interpretation' => 'operational_pressure_only',
        ];
    }
}
