<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Host;

final class RiskNavigationDefinitions
{
    /** @return list<array<string, mixed>> */
    public static function all(): array
    {
        return [
            [
                'id' => 'titan-risk-engine-root',
                'area' => 'user',
                'label' => 'Titan Risk',
                'route' => 'dashboard.user.titan.risk.engine.index',
                'permission' => null,
                'icon' => 'tabler-folders',
                'order' => 180,
                'enabled' => true,
                'visibility' => 'tenant-user',
                'parent_route' => null,
            ],
            [
                'id' => 'titan-risk-engine-control-centre',
                'area' => 'admin',
                'label' => 'Risk Control Centre',
                'route' => 'dashboard.admin.titan.risk.engine.control-centre',
                'permission' => null,
                'icon' => 'tabler-folders',
                'order' => 181,
                'enabled' => true,
                'visibility' => 'platform-admin',
                // Keep both identifiers for modern registries while the
                // legacy adapter resolves the physical menus.id by route.
                'parent' => 'titan-risk-engine-root',
                'parent_route' => 'dashboard.user.titan.risk.engine.index',
            ],
        ];
    }
}
