<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;

final readonly class RiskBudgetEvaluation
{
    public function __construct(
        public RiskEffectivePolicy $policy,
        public float $dailyExposure,
        public float $utilizationRatio,
        public bool $monitoringThresholdReached,
        public bool $dailyLimitExceeded,
        public bool $singleActionLimitExceeded,
        public bool $hardCeilingTriggered,
        public RiskExecutionDirective $directive,
    ) {}

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'effective_policy' => $this->policy->toArray(),
            'daily_exposure' => $this->dailyExposure,
            'utilization_ratio' => $this->utilizationRatio,
            'monitoring_threshold_reached' => $this->monitoringThresholdReached,
            'daily_limit_exceeded' => $this->dailyLimitExceeded,
            'single_action_limit_exceeded' => $this->singleActionLimitExceeded,
            'hard_ceiling_triggered' => $this->hardCeilingTriggered,
            'execution_directive' => $this->directive->value,
        ];
    }
}
