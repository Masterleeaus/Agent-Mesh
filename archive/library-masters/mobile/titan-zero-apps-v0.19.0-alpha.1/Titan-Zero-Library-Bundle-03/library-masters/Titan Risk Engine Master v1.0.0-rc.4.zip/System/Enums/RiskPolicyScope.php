<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskPolicyScope: string
{
    case GLOBAL = 'GLOBAL';
    case TENANT = 'TENANT';
    case CAPABILITY = 'CAPABILITY';
    case TENANT_CAPABILITY = 'TENANT_CAPABILITY';
}
