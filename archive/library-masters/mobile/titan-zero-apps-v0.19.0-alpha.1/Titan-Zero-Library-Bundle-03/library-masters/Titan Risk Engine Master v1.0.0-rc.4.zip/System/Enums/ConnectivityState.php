<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum ConnectivityState: string
{
    case ONLINE = 'ONLINE';
    case DEGRADED = 'DEGRADED';
    case OFFLINE = 'OFFLINE';
}
