<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Enums\ConnectivityState;
use App\Extensions\TitanRiskEngine\System\Enums\Reversibility;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskImpactVector;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskReason;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRemediation;
use DateTimeImmutable;
use DateTimeZone;
use InvalidArgumentException;
use JsonException;

final class RiskLedgerRowMapper
{
    /** @return array<string, mixed> */
    public function toRow(RiskAssessment $assessment): array
    {
        $context = $assessment->context;
        $impact = $context->impact;
        $utc = $assessment->assessedAt->setTimezone(new DateTimeZone('UTC'));
        $reasonCodes = array_values(array_map(
            static fn (RiskReason $reason): string => $reason->code,
            $assessment->reasons,
        ));

        return [
            'company_id' => $context->companyId,
            'trace_id' => $context->traceId,
            'correlation_id' => $context->correlationId,
            'causation_id' => $context->causationId,
            'idempotency_key' => $context->idempotencyKey,
            'capability' => $context->capability,
            'action' => $context->action,
            'actor_type' => $context->actorType,
            'actor_id' => $context->actorId === null ? null : (string) $context->actorId,
            'resource_type' => $context->resourceType,
            'resource_id' => $context->resourceId === null ? null : (string) $context->resourceId,
            'vertical_key' => $context->verticalKey,
            'jurisdiction' => $context->jurisdiction,
            'score' => $assessment->score,
            'level' => $assessment->level->value,
            'decision' => $assessment->decision->value,
            'policy_version' => $assessment->policyVersion,
            'reversibility' => $context->reversibility->value,
            'connectivity' => $context->connectivity->value,
            'impact_financial' => $impact->financial,
            'impact_safety' => $impact->safety,
            'impact_privacy' => $impact->privacy,
            'impact_legal' => $impact->legal,
            'impact_operational' => $impact->operational,
            'impact_reputation' => $impact->reputation,
            'hour_bucket' => $utc->format('Y-m-d-H'),
            'day_bucket' => $utc->format('Y-m-d'),
            'reason_codes' => $this->encode($reasonCodes),
            'reasons' => $this->encode(array_map(static fn (RiskReason $reason): array => $reason->toArray(), $assessment->reasons)),
            'remediation' => $this->encode(array_map(static fn (RiskRemediation $item): array => $item->toArray(), $assessment->remediation)),
            'recent_activity' => $this->encode($context->recentActivity),
            'metadata' => $this->encode($context->metadata),
            'context_snapshot' => $this->encode($context->toArray()),
            'assessed_at' => $utc->format('Y-m-d H:i:s.u'),
            'type' => 'assessment',
            'status' => 'assessed',
            'payload' => $this->encode($assessment->toArray()),
            'created_at' => $utc->format('Y-m-d H:i:s.u'),
            'updated_at' => $utc->format('Y-m-d H:i:s.u'),
        ];
    }

    public function fromPayload(array|string $payload): RiskAssessment
    {
        $data = is_array($payload) ? $payload : $this->decode($payload);
        $contextData = $data['context'] ?? null;

        if (!is_array($contextData)) {
            throw new InvalidArgumentException('Risk ledger payload is missing a valid context snapshot.');
        }

        $impactData = is_array($contextData['impact'] ?? null) ? $contextData['impact'] : [];
        $context = new RiskContext(
            companyId: $contextData['company_id'] ?? '',
            traceId: (string) ($contextData['trace_id'] ?? ''),
            correlationId: (string) ($contextData['correlation_id'] ?? ''),
            causationId: (string) ($contextData['causation_id'] ?? ''),
            capability: (string) ($contextData['capability'] ?? ''),
            action: (string) ($contextData['action'] ?? ''),
            actorType: (string) ($contextData['actor_type'] ?? ''),
            actorId: $contextData['actor_id'] ?? null,
            resourceType: isset($contextData['resource_type']) ? (string) $contextData['resource_type'] : null,
            resourceId: $contextData['resource_id'] ?? null,
            verticalKey: isset($contextData['vertical_key']) ? (string) $contextData['vertical_key'] : null,
            jurisdiction: isset($contextData['jurisdiction']) ? (string) $contextData['jurisdiction'] : null,
            impact: new RiskImpactVector(
                financial: (float) ($impactData['financial'] ?? 0.0),
                safety: (float) ($impactData['safety'] ?? 0.0),
                privacy: (float) ($impactData['privacy'] ?? 0.0),
                legal: (float) ($impactData['legal'] ?? 0.0),
                operational: (float) ($impactData['operational'] ?? 0.0),
                reputation: (float) ($impactData['reputation'] ?? 0.0),
            ),
            reversibility: Reversibility::from((string) ($contextData['reversibility'] ?? Reversibility::REVERSIBLE->value)),
            connectivity: ConnectivityState::from((string) ($contextData['connectivity'] ?? ConnectivityState::ONLINE->value)),
            recentActivity: is_array($contextData['recent_activity'] ?? null) ? $contextData['recent_activity'] : [],
            metadata: is_array($contextData['metadata'] ?? null) ? $contextData['metadata'] : [],
            idempotencyKey: isset($contextData['idempotency_key']) ? (string) $contextData['idempotency_key'] : null,
        );

        $reasons = [];
        foreach (($data['reasons'] ?? []) as $reason) {
            if (!is_array($reason)) {
                continue;
            }
            $reasons[] = new RiskReason(
                code: (string) ($reason['code'] ?? 'UNKNOWN'),
                message: (string) ($reason['message'] ?? ''),
                contribution: (float) ($reason['contribution'] ?? 0.0),
            );
        }

        $remediation = [];
        foreach (($data['remediation'] ?? []) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $remediation[] = new RiskRemediation(
                code: (string) ($item['code'] ?? 'UNKNOWN'),
                message: (string) ($item['message'] ?? ''),
            );
        }

        return new RiskAssessment(
            context: $context,
            score: (float) ($data['score'] ?? 0.0),
            level: RiskLevel::from((string) ($data['level'] ?? RiskLevel::MINIMAL->value)),
            decision: RiskDecision::from((string) ($data['decision'] ?? RiskDecision::ALLOW->value)),
            reasons: $reasons,
            policyVersion: (string) ($data['policy_version'] ?? 'unknown'),
            assessedAt: new DateTimeImmutable((string) ($data['assessed_at'] ?? 'now')),
            remediation: $remediation,
        );
    }

    /** @return array<mixed> */
    private function decode(string $payload): array
    {
        try {
            $decoded = json_decode($payload, true, 64, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            throw new InvalidArgumentException('Risk ledger payload is invalid JSON.', previous: $e);
        }

        if (!is_array($decoded)) {
            throw new InvalidArgumentException('Risk ledger payload must decode to an array.');
        }

        return $decoded;
    }

    private function encode(mixed $value): string
    {
        try {
            return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        } catch (JsonException $e) {
            throw new InvalidArgumentException('Risk ledger value cannot be encoded as JSON.', previous: $e);
        }
    }
}
