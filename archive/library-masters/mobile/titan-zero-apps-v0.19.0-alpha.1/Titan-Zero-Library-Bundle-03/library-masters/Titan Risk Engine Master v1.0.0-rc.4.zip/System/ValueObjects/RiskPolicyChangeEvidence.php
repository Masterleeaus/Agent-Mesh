<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskPolicyChangeEvidence
{
    public function __construct(
        public string $changeId,
        public string $action,
        public int|string|null $companyId,
        public string $policyKey,
        public string $version,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public DateTimeImmutable $changedAt,
        public string $reason,
        public ?string $actorType = null,
        public int|string|null $actorId = null,
        public ?string $previousVersion = null,
    ) {
        RiskFieldConstraints::text('changeId', $this->changeId, 191, false);
        RiskFieldConstraints::text('action', $this->action, 80, false);
        RiskFieldConstraints::text('policyKey', $this->policyKey, 120, false);
        RiskFieldConstraints::text('version', $this->version, 80, false);
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        RiskFieldConstraints::text('reason', $this->reason, 1000, false);
        RiskFieldConstraints::text('actorType', $this->actorType, 80);
        RiskFieldConstraints::scalarId('actorId', $this->actorId);
        RiskFieldConstraints::text('previousVersion', $this->previousVersion, 80);
        if ($this->companyId !== null) RiskFieldConstraints::scalarId('companyId', $this->companyId, 64);
        if (!in_array($this->action, ['BUDGET_SCHEDULED', 'BUDGET_ROLLBACK_SCHEDULED', 'POLICY_SCHEDULED', 'POLICY_ROLLBACK_SCHEDULED'], true)) {
            throw new InvalidArgumentException('Unsupported Risk policy change action.');
        }
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'change_id' => $this->changeId,
            'action' => $this->action,
            'company_id' => $this->companyId,
            'policy_key' => $this->policyKey,
            'version' => $this->version,
            'trace_id' => $this->traceId,
            'correlation_id' => $this->correlationId,
            'causation_id' => $this->causationId,
            'changed_at' => $this->changedAt->format(DATE_ATOM),
            'reason' => $this->reason,
            'actor_type' => $this->actorType,
            'actor_id' => $this->actorId,
            'previous_version' => $this->previousVersion,
        ];
    }
}
