<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskAggregateWindow: int
{
    case HOUR_1 = 60;
    case HOURS_4 = 240;
    case HOURS_24 = 1440;

    public function minutes(): int
    {
        return $this->value;
    }
}
