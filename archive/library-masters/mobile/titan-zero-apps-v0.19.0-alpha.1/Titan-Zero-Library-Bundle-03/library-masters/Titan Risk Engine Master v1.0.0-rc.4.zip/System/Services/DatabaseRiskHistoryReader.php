<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskHistoryReaderContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskHistoryReader implements RiskHistoryReaderContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_assessments',
    ) {}

    public function summarize(RiskHistoryQuery $query): RiskExposureSnapshot
    {
        $utc = new DateTimeZone('UTC');
        $builder = $this->database->table($this->table)
            ->where('company_id', $query->companyId)
            ->where('assessed_at', '>=', $query->from->setTimezone($utc)->format('Y-m-d H:i:s.u'))
            ->where('assessed_at', '<', $query->to->setTimezone($utc)->format('Y-m-d H:i:s.u'))
            ->whereNotNull('score');

        match ($query->scope) {
            RiskAggregateScope::TENANT => null,
            RiskAggregateScope::TENANT_CAPABILITY => $builder->where('capability', $query->capability),
            RiskAggregateScope::TENANT_ACTOR => $builder
                ->where('actor_type', $query->actorType)
                ->where('actor_id', (string) $query->actorId),
            RiskAggregateScope::TENANT_RESOURCE => $builder
                ->where('resource_type', $query->resourceType)
                ->where('resource_id', (string) $query->resourceId),
            RiskAggregateScope::ACTOR_CAPABILITY => $builder
                ->where('actor_type', $query->actorType)
                ->where('actor_id', (string) $query->actorId)
                ->where('capability', $query->capability),
        };

        $row = $builder->selectRaw(
            "COUNT(*) AS assessment_count, " .
            "COALESCE(SUM(score), 0) AS score_sum, " .
            "COALESCE(AVG(score), 0) AS score_average, " .
            "COALESCE(MAX(score), 0) AS score_maximum, " .
            "COALESCE(SUM(CASE WHEN level IN ('HIGH','EXTREME') THEN 1 ELSE 0 END), 0) AS high_or_extreme_count, " .
            "COALESCE(SUM(CASE WHEN level = 'EXTREME' THEN 1 ELSE 0 END), 0) AS extreme_count, " .
            "COALESCE(SUM(CASE WHEN decision = 'BLOCK' THEN 1 ELSE 0 END), 0) AS blocked_count"
        )->first();

        return new RiskExposureSnapshot(
            companyId: $query->companyId,
            scope: $query->scope,
            from: $query->from,
            to: $query->to,
            assessmentCount: (int) ($row->assessment_count ?? 0),
            scoreSum: round((float) ($row->score_sum ?? 0.0), 2),
            scoreAverage: round((float) ($row->score_average ?? 0.0), 2),
            scoreMaximum: round((float) ($row->score_maximum ?? 0.0), 2),
            highOrExtremeCount: (int) ($row->high_or_extreme_count ?? 0),
            extremeCount: (int) ($row->extreme_count ?? 0),
            blockedCount: (int) ($row->blocked_count ?? 0),
            capability: $query->capability,
            actorType: $query->actorType,
            actorId: $query->actorId,
            resourceType: $query->resourceType,
            resourceId: $query->resourceId,
        );
    }
}
