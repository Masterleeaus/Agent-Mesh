<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalOutboxContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskSignalPublisherContract;
use DateTimeImmutable;
use DateTimeZone;
use Throwable;

final class RiskSignalDispatcher
{
    public function __construct(
        private readonly RiskSignalOutboxContract $outbox,
        private readonly RiskSignalPublisherContract $publisher,
        private readonly int $maxBatch = 100,
    ) {}

    public function dispatchPending(int $limit = 100): int
    {
        $delivered = 0;
        foreach ($this->outbox->pending(max(1, min($this->maxBatch, $limit))) as $event) {
            $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            try {
                if (!$this->publisher->publish($event)) {
                    $this->outbox->markFailed($event->eventId, 'publisher_not_acknowledged', $now);
                    continue;
                }
                $this->outbox->markPublished($event->eventId, $now);
                $delivered++;
            } catch (Throwable $e) {
                $this->outbox->markFailed($event->eventId, $e->getMessage(), $now);
            }
        }
        return $delivered;
    }
}
