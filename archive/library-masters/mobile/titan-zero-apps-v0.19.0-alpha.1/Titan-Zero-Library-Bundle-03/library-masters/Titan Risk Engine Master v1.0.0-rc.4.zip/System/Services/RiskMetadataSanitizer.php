<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

final class RiskMetadataSanitizer
{
    /** @var array<string, true> */
    private array $reserved;

    /** @param list<string> $reservedKeys */
    public function __construct(
        private readonly int $maxDepth = 4,
        private readonly int $maxEntries = 100,
        private readonly int $maxStringLength = 2000,
        array $reservedKeys = [
            'company_id', 'trace_id', 'correlation_id', 'causation_id',
            'actor_id', 'actor_type', 'recent_activity', 'risk_score', 'risk_level',
            'decision', 'execution_directive', 'policy_version',
        ],
        private readonly int $maxTotalBytes = 32768,
    ) {
        $this->reserved = [];
        foreach ($reservedKeys as $key) {
            $this->reserved[$this->canonicalKey($key)] = true;
        }
    }

    /** @param array<string, mixed> $metadata @return array<string, mixed> */
    public function sanitize(array $metadata): array
    {
        $count = 0;
        $bytes = 0;
        $normalized = $this->sanitizeArray($metadata, 0, $count, $bytes);
        return is_array($normalized) ? $normalized : [];
    }

    /** @param array<mixed> $value @return array<mixed> */
    private function sanitizeArray(array $value, int $depth, int &$count, int &$bytes): array
    {
        if ($depth >= $this->maxDepth || $count >= $this->maxEntries || $bytes >= $this->maxTotalBytes) {
            return [];
        }

        $result = [];
        $seenCanonical = [];
        foreach ($value as $key => $item) {
            if ($count >= $this->maxEntries || $bytes >= $this->maxTotalBytes) break;

            if (is_int($key)) {
                $keyString = $key;
                $keyBytes = 0;
            } else {
                $rawKey = trim((string) $key);
                if ($rawKey === '' || preg_match('//u', $rawKey) !== 1 || preg_match('/[\x00-\x1F\x7F]/', $rawKey) === 1) continue;
                $keyString = substr($rawKey, 0, 80);
                $canonical = $this->canonicalKey($keyString);
                if ($canonical === '' || isset($this->reserved[$canonical]) || isset($seenCanonical[$canonical])) continue;
                $seenCanonical[$canonical] = true;
                $keyBytes = strlen($keyString);
            }

            if ($bytes + $keyBytes > $this->maxTotalBytes) break;
            $normalized = $this->normalizeValue($item, $depth + 1, $count, $bytes);
            if ($normalized === null && $item !== null) continue;

            $estimated = $keyBytes + $this->estimateBytes($normalized);
            if ($bytes + $estimated > $this->maxTotalBytes) continue;
            $bytes += $estimated;
            $result[$keyString] = $normalized;
            $count++;
        }

        return $result;
    }

    private function normalizeValue(mixed $value, int $depth, int &$count, int &$bytes): mixed
    {
        if ($value === null || is_bool($value) || is_int($value)) return $value;
        if (is_float($value)) return is_finite($value) ? $value : null;
        if (is_string($value)) {
            if (preg_match('//u', $value) !== 1) return null;
            $limit = min($this->maxStringLength, max(0, $this->maxTotalBytes - $bytes));
            return strlen($value) <= $limit ? $value : substr($value, 0, $limit);
        }
        if (is_array($value)) return $this->sanitizeArray($value, $depth, $count, $bytes);
        return null;
    }

    private function canonicalKey(string $key): string
    {
        $key = strtolower(trim($key));
        return preg_replace('/[^a-z0-9]+/', '', $key) ?? '';
    }

    private function estimateBytes(mixed $value): int
    {
        if ($value === null) return 4;
        if (is_bool($value)) return $value ? 4 : 5;
        if (is_int($value) || is_float($value)) return strlen((string) $value);
        if (is_string($value)) return strlen($value);
        if (is_array($value)) {
            try { return strlen(json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES)); }
            catch (\Throwable) { return $this->maxTotalBytes + 1; }
        }
        return $this->maxTotalBytes + 1;
    }
}
