<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskDecisionRouterContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;

final class RiskDecisionRouter implements RiskDecisionRouterContract
{
    public function route(RiskDecision $decision): RiskExecutionDirective
    {
        return match ($decision) {
            RiskDecision::ALLOW => RiskExecutionDirective::EXECUTE,
            RiskDecision::ALLOW_WITH_MONITORING => RiskExecutionDirective::EXECUTE_MONITORED,
            RiskDecision::REQUIRE_ASSURANCE => RiskExecutionDirective::HOLD_FOR_ASSURANCE,
            RiskDecision::REQUIRE_APPROVAL => RiskExecutionDirective::HOLD_FOR_APPROVAL,
            RiskDecision::REDUCE_AUTHORITY => RiskExecutionDirective::HOLD_REDUCED_AUTHORITY,
            RiskDecision::DEFER => RiskExecutionDirective::HOLD,
            RiskDecision::BLOCK => RiskExecutionDirective::DENY,
        };
    }
}
