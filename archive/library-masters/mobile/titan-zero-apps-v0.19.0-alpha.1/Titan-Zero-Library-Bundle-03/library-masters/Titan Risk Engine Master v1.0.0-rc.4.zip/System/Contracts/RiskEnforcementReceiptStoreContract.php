<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;

interface RiskEnforcementReceiptStoreContract
{
    public function persist(RiskEnforcementReceipt $receipt): void;
}
