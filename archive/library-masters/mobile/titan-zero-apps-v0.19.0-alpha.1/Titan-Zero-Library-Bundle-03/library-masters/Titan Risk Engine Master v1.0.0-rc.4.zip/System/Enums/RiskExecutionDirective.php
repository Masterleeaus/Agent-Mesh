<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskExecutionDirective: string
{
    case EXECUTE = 'EXECUTE';
    case EXECUTE_MONITORED = 'EXECUTE_MONITORED';
    case HOLD_FOR_ASSURANCE = 'HOLD_FOR_ASSURANCE';
    case HOLD_FOR_APPROVAL = 'HOLD_FOR_APPROVAL';
    case HOLD_REDUCED_AUTHORITY = 'HOLD_REDUCED_AUTHORITY';
    case HOLD = 'HOLD';
    case DENY = 'DENY';

    public function mayDispatchToExecutor(): bool
    {
        return in_array($this, [self::EXECUTE, self::EXECUTE_MONITORED], true);
    }
}
