<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskControlCentreSnapshot;
use DateTimeImmutable;

interface RiskControlCentreContract
{
    public function snapshot(
        int|string $companyId,
        ?string $capability = null,
        int $limit = 20,
        ?DateTimeImmutable $asOf = null,
    ): RiskControlCentreSnapshot;
}
