<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use RuntimeException;

final class RiskIdempotencyGuard
{
    public function __construct(private readonly RiskContextFingerprint $fingerprint = new RiskContextFingerprint()) {}

    public function assertCompatible(RiskContext $requested, RiskAssessment $existing): void
    {
        if ($this->fingerprint->authorization($requested) !== $this->fingerprint->authorization($existing->context)) {
            throw new RuntimeException('RISK_IDEMPOTENCY_CONTEXT_COLLISION');
        }
    }
}
