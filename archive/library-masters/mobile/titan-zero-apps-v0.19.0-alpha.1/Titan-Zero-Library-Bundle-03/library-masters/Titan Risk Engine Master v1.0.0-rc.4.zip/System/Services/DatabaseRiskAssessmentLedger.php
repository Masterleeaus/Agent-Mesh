<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAssessmentLedgerContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskLedgerWriteResult;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;
use InvalidArgumentException;

final class DatabaseRiskAssessmentLedger implements RiskAssessmentLedgerContract
{
    private RiskDatabaseErrorClassifier $errors;

    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly RiskLedgerRowMapper $mapper,
        private readonly string $table = 'titan_risk_assessments',
        ?RiskDatabaseErrorClassifier $errors = null,
    ) {
        $this->errors = $errors ?? new RiskDatabaseErrorClassifier();
    }

    public function findByIdempotencyKey(int|string $companyId, string $idempotencyKey): ?RiskAssessment
    {
        $this->assertTenant($companyId);
        $this->assertIdempotencyKey($idempotencyKey);

        $row = $this->database->table($this->table)
            ->where('company_id', $companyId)
            ->where('idempotency_key', $idempotencyKey)
            ->first(['id', 'payload']);

        if ($row === null || !isset($row->payload)) {
            return null;
        }

        return $this->mapper->fromPayload($row->payload);
    }

    public function persist(RiskAssessment $assessment): RiskLedgerWriteResult
    {
        $context = $assessment->context;
        $this->assertTenant($context->companyId);

        if ($context->idempotencyKey !== null) {
            $existing = $this->findByIdempotencyKey($context->companyId, $context->idempotencyKey);
            if ($existing !== null) {
                return new RiskLedgerWriteResult($existing, false, null);
            }
        }

        try {
            $id = $this->database->table($this->table)->insertGetId($this->mapper->toRow($assessment));
            return new RiskLedgerWriteResult($assessment, true, $id);
        } catch (QueryException $e) {
            // A concurrent request may win the tenant + idempotency unique key race.
            if ($context->idempotencyKey !== null && $this->errors->isUniqueViolation($e)) {
                $existing = $this->findByIdempotencyKey($context->companyId, $context->idempotencyKey);
                if ($existing !== null) {
                    return new RiskLedgerWriteResult($existing, false, null);
                }
            }

            throw $e;
        }
    }

    private function assertTenant(int|string $companyId): void
    {
        if ((is_int($companyId) && $companyId <= 0)
            || (is_string($companyId) && trim($companyId) === '')) {
            throw new InvalidArgumentException('A valid company_id is required for Risk ledger persistence.');
        }
    }

    private function assertIdempotencyKey(string $idempotencyKey): void
    {
        if (trim($idempotencyKey) === '' || strlen($idempotencyKey) > 191) {
            throw new InvalidArgumentException('Risk idempotency key must contain 1-191 characters.');
        }
    }
}
