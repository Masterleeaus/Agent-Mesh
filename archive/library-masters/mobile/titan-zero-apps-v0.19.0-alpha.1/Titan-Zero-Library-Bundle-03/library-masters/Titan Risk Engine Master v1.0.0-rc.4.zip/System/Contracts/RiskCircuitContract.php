<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use DateTimeImmutable;

interface RiskCircuitContract
{
    public function status(RiskCircuitKey $key, DateTimeImmutable $asOf): RiskCircuitSnapshot;

    public function evaluate(RiskCircuitKey $key, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot;

    public function recordProbe(RiskCircuitKey $key, bool $successful, bool $supervised, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot;
}
