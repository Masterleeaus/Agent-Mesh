<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskPolicyScope;
use DateTimeImmutable;
use InvalidArgumentException;

final readonly class RiskPolicyOverlay
{
    private const ALLOWED_CONSTRAINTS = [
        'max_daily_risk_exposure',
        'max_autonomous_single_action_level',
        'monitoring_threshold_ratio',
        'hard_block_level',
    ];

    /** @param array<string,mixed> $constraints */
    public function __construct(
        public string $policyKey,
        public string $version,
        public RiskPolicyScope $scope,
        public array $constraints,
        public DateTimeImmutable $effectiveAt,
        public int|string|null $companyId = null,
        public ?string $capability = null,
        public ?string $supersedesVersion = null,
    ) {
        RiskFieldConstraints::text('policy_key', $this->policyKey, 120, false);
        RiskFieldConstraints::text('version', $this->version, 80, false);
        RiskFieldConstraints::text('capability', $this->capability, 160);
        RiskFieldConstraints::text('supersedes_version', $this->supersedesVersion, 80);
        if ($this->companyId !== null) RiskFieldConstraints::scalarId('company_id', $this->companyId, 64);
        foreach (array_keys($this->constraints) as $key) {
            if (!in_array($key, self::ALLOWED_CONSTRAINTS, true)) {
                throw new InvalidArgumentException(sprintf('Unsupported Risk policy constraint: %s', $key));
            }
        }
        foreach ($this->constraints as $key => $value) {
            if (in_array($key, ['max_daily_risk_exposure', 'monitoring_threshold_ratio'], true)) {
                if (!is_int($value) && !is_float($value) && !(is_string($value) && is_numeric($value))) {
                    throw new InvalidArgumentException(sprintf('%s must be numeric.', $key));
                }
                $number = (float) $value;
                if (!is_finite($number) || $number <= 0.0 || ($key === 'monitoring_threshold_ratio' && $number > 1.0)) {
                    throw new InvalidArgumentException(sprintf('%s contains an invalid numeric value.', $key));
                }
            }
            if (in_array($key, ['max_autonomous_single_action_level', 'hard_block_level'], true)) {
                \App\Extensions\TitanRiskEngine\System\Enums\RiskLevel::from((string) $value);
            }
        }
        match ($this->scope) {
            RiskPolicyScope::GLOBAL => null,
            RiskPolicyScope::TENANT => $this->requireTenant(),
            RiskPolicyScope::CAPABILITY => $this->requireCapability(),
            RiskPolicyScope::TENANT_CAPABILITY => $this->requireTenantAndCapability(),
        };
    }

    public function contentDigest(): string
    {
        $canonical = $this->toArray();
        ksort($canonical['constraints']);
        return hash('sha256', json_encode($canonical, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed> */
    public function toArray(): array
    {
        return [
            'policy_key' => $this->policyKey,
            'version' => $this->version,
            'scope' => $this->scope->value,
            'company_id' => $this->companyId,
            'capability' => $this->capability,
            'constraints' => $this->constraints,
            'effective_at' => $this->effectiveAt->format(DATE_ATOM),
            'supersedes_version' => $this->supersedesVersion,
        ];
    }

    private function requireTenant(): void
    {
        if ($this->companyId === null || trim((string) $this->companyId) === '' || (is_int($this->companyId) && $this->companyId <= 0)) {
            throw new InvalidArgumentException('Tenant-scoped Risk policy overlay requires company_id.');
        }
    }

    private function requireCapability(): void
    {
        if ($this->capability === null || trim($this->capability) === '') {
            throw new InvalidArgumentException('Capability-scoped Risk policy overlay requires capability.');
        }
    }

    private function requireTenantAndCapability(): void
    {
        $this->requireTenant();
        $this->requireCapability();
    }
}
