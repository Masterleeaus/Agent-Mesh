<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

interface RiskTransactionRunnerContract
{
    public function run(callable $callback): mixed;
}
