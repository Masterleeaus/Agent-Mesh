<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskGateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskRuntimeEventSinkContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskReason;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRemediation;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskRuntimeEvent;
use DateTimeImmutable;
use DateTimeZone;
use Throwable;

final class FailClosedRiskGate implements RiskGateContract
{
    public const POLICY_VERSION = 'fail-closed-v1';

    public function __construct(
        private readonly RiskGateContract $inner,
        private readonly RiskRuntimeEventSinkContract $runtimeEvents,
        private readonly ?RiskEnforcementReceiptFactory $receiptFactory = null,
        private readonly ?RiskEnforcementReceiptStoreContract $receiptStore = null,
        private readonly float $targetMilliseconds = 100.0,
        private readonly bool $enabled = true,
    ) {}

    public function evaluate(RiskContextInput $input): RiskGateResult
    {
        $started = hrtime(true);
        if (!$this->enabled) {
            $result = $this->denyResult(
                input: $input,
                policyVersion: 'disabled-v1',
                reasonCode: 'RISK_ENGINE_DISABLED',
                reasonMessage: 'Titan Risk Engine is disabled; execution is denied until governance is enabled.',
                remediationCode: 'ENABLE_RISK_ENGINE',
                remediationMessage: 'Enable Titan Risk Engine through governed host configuration before retrying.',
            );
            $this->record($input, 'DISABLED', $this->elapsed($started), null);
            return $result;
        }

        try {
            $result = $this->inner->evaluate($input);
            $elapsed = $this->elapsed($started);
            $this->record($input, $elapsed > $this->targetMilliseconds ? 'SLA_BREACH' : 'OK', $elapsed, null);
            return $result;
        } catch (Throwable $failure) {
            $result = $this->denyResult(
                input: $input,
                policyVersion: self::POLICY_VERSION,
                reasonCode: 'RISK_ENGINE_DEPENDENCY_UNAVAILABLE',
                reasonMessage: 'Risk authority is unavailable; execution is denied until governance can be evaluated.',
                remediationCode: 'RETRY_AFTER_RECOVERY',
                remediationMessage: 'Retry only after Titan Risk dependencies are healthy.',
            );
            $elapsed = $this->elapsed($started);
            $this->record($input, 'FAIL_CLOSED', $elapsed, $failure::class);
            return $result;
        }
    }

    private function denyResult(
        RiskContextInput $input,
        string $policyVersion,
        string $reasonCode,
        string $reasonMessage,
        string $remediationCode,
        string $remediationMessage,
    ): RiskGateResult {
        $at = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $context = new RiskContext(
            companyId: $input->companyId,
            traceId: $input->traceId,
            correlationId: $input->correlationId,
            causationId: $input->causationId,
            capability: $input->capability,
            action: $input->action,
            actorType: $input->actorType,
            actorId: null,
            resourceType: $input->resourceType,
            resourceId: $input->resourceId,
            verticalKey: $input->verticalKey,
            jurisdiction: $input->jurisdiction,
            impact: $input->impact,
            reversibility: $input->reversibility,
            connectivity: $input->connectivity,
            recentActivity: [],
            metadata: [],
            idempotencyKey: $input->idempotencyKey,
        );
        $assessment = new RiskAssessment(
            context: $context,
            score: 100.0,
            level: RiskLevel::EXTREME,
            decision: RiskDecision::BLOCK,
            reasons: [new RiskReason($reasonCode, $reasonMessage)],
            policyVersion: $policyVersion,
            assessedAt: $at,
            remediation: [new RiskRemediation($remediationCode, $remediationMessage)],
        );
        $result = new RiskGateResult($assessment, RiskExecutionDirective::DENY);

        // Best-effort durable evidence. Failure here cannot weaken the DENY result.
        if ($this->receiptFactory !== null && $this->receiptStore !== null) {
            try {
                $receipt = $this->receiptFactory->make($result, $at);
                $this->receiptStore->persist($receipt);
                $result = $result->withEnforcementReceipt($receipt);
            } catch (Throwable) {
                // The absence of a durable receipt is itself non-authorizing: mayDispatch remains false.
            }
        }

        return $result;
    }

    private function elapsed(int $started): float
    {
        return (hrtime(true) - $started) / 1_000_000;
    }

    private function record(RiskContextInput $input, string $outcome, float $elapsed, ?string $errorClass): void
    {
        try {
            $this->runtimeEvents->record(new RiskRuntimeEvent(
                operation: 'risk.gate',
                outcome: $outcome,
                elapsedMilliseconds: $elapsed,
                companyId: $input->companyId,
                traceId: $input->traceId,
                correlationId: $input->correlationId,
                causationId: $input->causationId,
                capability: $input->capability,
                errorClass: $errorClass,
            ));
        } catch (Throwable) {
            // Telemetry failure must never alter Risk authority.
        }
    }
}
