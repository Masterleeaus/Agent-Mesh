<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskSignalEvent;
use DateTimeImmutable;

interface RiskSignalOutboxContract
{
    public function stage(RiskSignalEvent $event): void;

    /** @return list<RiskSignalEvent> */
    public function pending(int $limit = 100): array;

    public function markPublished(string $eventId, DateTimeImmutable $publishedAt): void;

    public function markFailed(string $eventId, string $error, DateTimeImmutable $failedAt): void;
}
