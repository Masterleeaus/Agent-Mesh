<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyRegistryContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyVersion;
use DateTimeImmutable;
use InvalidArgumentException;

final class StaticRiskPolicyRegistry implements RiskPolicyRegistryContract
{
    /** @var array<string,array<string,RiskPolicyVersion>> */
    private array $policies;

    public function __construct()
    {
        $this->policies = [
            'single-action' => [
                'baseline-v1' => new RiskPolicyVersion('single-action', 'baseline-v1', new DateTimeImmutable('2026-08-11T00:00:00+00:00')),
            ],
            'historical-intelligence' => [
                'intelligence-v1' => new RiskPolicyVersion('historical-intelligence', 'intelligence-v1', new DateTimeImmutable('2026-08-19T00:00:00+00:00')),
            ],
            'circuit-control' => [
                'circuit-v1' => new RiskPolicyVersion('circuit-control', 'circuit-v1', new DateTimeImmutable('2026-08-20T00:00:00+00:00')),
            ],
            'operational-governance' => [
                'operational-governance-v1' => new RiskPolicyVersion('operational-governance', 'operational-governance-v1', new DateTimeImmutable('2026-08-20T00:00:00+00:00')),
            ],
        ];
    }

    public function current(string $policy): RiskPolicyVersion
    {
        $versions = $this->policies[$policy] ?? null;
        if ($versions === null || $versions === []) {
            throw new InvalidArgumentException(sprintf('Unknown Risk policy: %s', $policy));
        }

        $ordered = array_values($versions);
        return $ordered[count($ordered) - 1];
    }

    public function find(string $policy, string $version): ?RiskPolicyVersion
    {
        return $this->policies[$policy][$version] ?? null;
    }

    public function all(): array
    {
        $all = [];
        foreach ($this->policies as $versions) {
            foreach ($versions as $version) {
                $all[] = $version;
            }
        }
        return $all;
    }
}
