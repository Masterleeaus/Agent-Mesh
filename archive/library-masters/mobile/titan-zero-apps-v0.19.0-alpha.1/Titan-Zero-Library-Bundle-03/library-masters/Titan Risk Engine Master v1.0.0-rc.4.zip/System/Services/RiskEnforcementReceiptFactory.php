<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGateResult;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskGovernanceFeedbackResult;
use DateTimeImmutable;

final class RiskEnforcementReceiptFactory
{
    public function __construct(private readonly RiskContextFingerprint $fingerprint = new RiskContextFingerprint()) {}

    public function make(RiskGateResult $gate, DateTimeImmutable $issuedAt): RiskEnforcementReceipt
    {
        return $this->build($gate, $gate->directive, $issuedAt, null, null);
    }

    public function makeForFeedback(RiskGateResult $gate, RiskGovernanceFeedbackResult $feedback): RiskEnforcementReceipt
    {
        return $this->build($gate, $feedback->directive, $feedback->appliedAt, $feedback->source, $feedback->evidenceId);
    }

    private function build(RiskGateResult $gate, RiskExecutionDirective $directive, DateTimeImmutable $issuedAt, ?string $source, ?string $evidenceId): RiskEnforcementReceipt
    {
        $assessment = $gate->assessment;
        $context = $assessment->context;
        $circuits = array_map(static fn ($c): array => [
            'scope' => $c->key->scope->value,
            'capability' => $c->key->capability,
            'state' => $c->state->value,
            'version' => $c->version,
            'policy_version' => $c->policyVersion,
        ], $gate->circuits);
        $budget = $gate->budgetEvaluation;
        $budgetVersion = null;
        if ($budget !== null) {
            foreach ($budget->policy->appliedVersions as $version) {
                if (str_starts_with($version, 'budget:')) { $budgetVersion = substr($version, 7); break; }
            }
        }

        $fields = [
            'companyId' => $context->companyId,
            'traceId' => $context->traceId,
            'correlationId' => $context->correlationId,
            'causationId' => $context->causationId,
            'capability' => $context->capability,
            'directive' => $directive,
            'mayDispatch' => $directive->mayDispatchToExecutor(),
            'riskScore' => $assessment->score,
            'riskLevel' => $assessment->level,
            'assessmentPolicyVersion' => $assessment->policyVersion,
            'circuits' => $circuits,
            'issuedAt' => $issuedAt,
            'governanceSource' => $source,
            'evidenceId' => $evidenceId,
            'effectivePolicyDigest' => $budget?->policy->contentDigest,
            'budgetVersion' => $budgetVersion,
            'budgetUtilizationRatio' => $budget?->utilizationRatio,
            'action' => $context->action,
            'actorType' => $context->actorType,
            'actorId' => $context->actorId,
            'resourceType' => $context->resourceType,
            'resourceId' => $context->resourceId,
            'requestFingerprint' => $this->fingerprint->authorization($context),
        ];

        $temporary = new RiskEnforcementReceipt('pending', 'pending', ...$fields);
        $digest = hash('sha256', json_encode($temporary->authorizationPayload(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        return new RiskEnforcementReceipt('riskrcpt_' . substr($digest, 0, 40), $digest, ...$fields);
    }
}
