<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;

final class RiskDirectivePolicy
{
    public function stricter(RiskExecutionDirective $current, RiskExecutionDirective $candidate): RiskExecutionDirective
    {
        return $this->rank($candidate) > $this->rank($current) ? $candidate : $current;
    }

    private function rank(RiskExecutionDirective $directive): int
    {
        return match ($directive) {
            RiskExecutionDirective::EXECUTE => 0,
            RiskExecutionDirective::EXECUTE_MONITORED => 1,
            RiskExecutionDirective::HOLD_FOR_ASSURANCE => 2,
            RiskExecutionDirective::HOLD_REDUCED_AUTHORITY => 3,
            RiskExecutionDirective::HOLD_FOR_APPROVAL => 4,
            RiskExecutionDirective::HOLD => 5,
            RiskExecutionDirective::DENY => 6,
        };
    }
}
