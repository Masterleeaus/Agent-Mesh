<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEffectivePolicy;
use DateTimeImmutable;

interface RiskEffectivePolicyResolverContract
{
    public function resolve(int|string $companyId, string $capability, DateTimeImmutable $asOf): RiskEffectivePolicy;
}
