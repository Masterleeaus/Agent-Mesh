<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\ActorIdentityResolverContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RecentActivityProviderContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContextInput;

final class TrustedRiskContextFactory
{
    public function __construct(
        private readonly ActorIdentityResolverContract $actorResolver,
        RecentActivityProviderContract $recentActivity,
        private readonly RiskMetadataSanitizer $metadataSanitizer,
        private readonly int $recentActivityLimit = 10,
    ) {}

    public function make(RiskContextInput $input): RiskContext
    {
        $actor = $this->actorResolver->resolve($input->actorType, $input->claimedActorId);
        return new RiskContext(
            companyId: $input->companyId,
            traceId: $input->traceId,
            correlationId: $input->correlationId,
            causationId: $input->causationId,
            capability: $input->capability,
            action: $input->action,
            actorType: $actor->type,
            actorId: $actor->id,
            resourceType: $input->resourceType,
            resourceId: $input->resourceId,
            verticalKey: $input->verticalKey,
            jurisdiction: $input->jurisdiction,
            impact: $input->impact,
            reversibility: $input->reversibility,
            connectivity: $input->connectivity,
            recentActivity: [],
            metadata: $this->metadataSanitizer->sanitize($input->metadata),
            idempotencyKey: $input->idempotencyKey,
        );
    }
}
