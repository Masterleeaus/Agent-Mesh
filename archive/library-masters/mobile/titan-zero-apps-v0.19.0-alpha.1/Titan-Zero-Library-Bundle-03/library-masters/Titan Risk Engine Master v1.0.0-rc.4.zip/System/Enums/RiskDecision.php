<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Enums;

enum RiskDecision: string
{
    case ALLOW = 'ALLOW';
    case ALLOW_WITH_MONITORING = 'ALLOW_WITH_MONITORING';
    case REQUIRE_ASSURANCE = 'REQUIRE_ASSURANCE';
    case REQUIRE_APPROVAL = 'REQUIRE_APPROVAL';
    case REDUCE_AUTHORITY = 'REDUCE_AUTHORITY';
    case DEFER = 'DEFER';
    case BLOCK = 'BLOCK';
}
