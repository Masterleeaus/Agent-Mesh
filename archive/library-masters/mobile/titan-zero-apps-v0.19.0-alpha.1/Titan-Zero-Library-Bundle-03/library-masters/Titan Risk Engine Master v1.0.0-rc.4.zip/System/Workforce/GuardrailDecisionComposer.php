<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Workforce;

final class GuardrailDecisionComposer
{
    private const ORDER = ['authorization', 'governance', 'risk', 'assurance', 'autonomy'];

    /** @param array<string,array<string,mixed>> $decisions @return array<string,mixed> */
    public function compose(array $decisions, string $companyId, string $correlationId): array
    {
        if ($companyId === '' || $correlationId === '') {
            return $this->deny('missing_required_context', $companyId, $correlationId);
        }
        $providers = [];
        foreach (self::ORDER as $stage) {
            $decision = $decisions[$stage] ?? null;
            if (!is_array($decision)) {
                return $this->deny('missing_stage:' . $stage, $companyId, $correlationId);
            }
            if (($decision['company_id'] ?? null) !== $companyId || ($decision['correlation_id'] ?? null) !== $correlationId) {
                return $this->deny('context_mismatch:' . $stage, $companyId, $correlationId);
            }
            $provider = (string)($decision['provider'] ?? '');
            $version = (string)($decision['provider_version'] ?? '');
            if ($provider === '' || $version === '') {
                return $this->deny('missing_provenance:' . $stage, $companyId, $correlationId);
            }
            $providers[$stage] = $provider . '@' . $version;
            $value = strtolower((string)($decision['decision'] ?? 'deny'));
            if ($value !== 'allow') {
                return $this->deny('stage_' . $stage . ':' . $value, $companyId, $correlationId, $providers);
            }
        }
        return ['decision'=>'allow','company_id'=>$companyId,'correlation_id'=>$correlationId,'providers'=>$providers,'reason_codes'=>[]];
    }

    /** @param array<string,string> $providers @return array<string,mixed> */
    private function deny(string $reason, string $companyId, string $correlationId, array $providers = []): array
    {
        return ['decision'=>'deny','company_id'=>$companyId,'correlation_id'=>$correlationId,'providers'=>$providers,'reason_codes'=>[$reason]];
    }
}
