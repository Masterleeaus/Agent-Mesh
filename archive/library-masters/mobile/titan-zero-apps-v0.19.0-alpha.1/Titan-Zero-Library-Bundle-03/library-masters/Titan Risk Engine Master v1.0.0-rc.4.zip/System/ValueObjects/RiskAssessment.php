<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskLevel;
use DateTimeImmutable;

final readonly class RiskAssessment
{
    /**
     * @param list<RiskReason> $reasons
     * @param list<RiskRemediation> $remediation
     */
    public function __construct(
        public RiskContext $context,
        public float $score,
        public RiskLevel $level,
        public RiskDecision $decision,
        public array $reasons,
        public string $policyVersion,
        public DateTimeImmutable $assessedAt,
        public array $remediation = [],
    ) {}

    public function canProceedWithoutEscalation(): bool
    {
        return in_array($this->decision, [RiskDecision::ALLOW, RiskDecision::ALLOW_WITH_MONITORING], true);
    }

    public function isBlocked(): bool
    {
        return $this->decision === RiskDecision::BLOCK;
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'context' => $this->context->toArray(),
            'score' => $this->score,
            'level' => $this->level->value,
            'decision' => $this->decision->value,
            'reasons' => array_map(static fn (RiskReason $reason): array => $reason->toArray(), $this->reasons),
            'remediation' => array_map(static fn (RiskRemediation $item): array => $item->toArray(), $this->remediation),
            'policy_version' => $this->policyVersion,
            'assessed_at' => $this->assessedAt->format(DATE_ATOM),
        ];
    }
}
