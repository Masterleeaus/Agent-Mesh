<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitPolicyContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitState;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityLevel;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransition;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment;
use DateTimeImmutable;

final class DefaultRiskCircuitPolicy implements RiskCircuitPolicyContract
{
    public const POLICY_VERSION = 'circuit-v1';
    public const MIN_OPEN_COOLDOWN_SECONDS = 300;
    public const MAX_HALF_OPEN_TIMEOUT_SECONDS = 300;

    public function __construct(
        private readonly int $openCooldownSeconds = self::MIN_OPEN_COOLDOWN_SECONDS,
        private readonly int $halfOpenTimeoutSeconds = self::MAX_HALF_OPEN_TIMEOUT_SECONDS,
    ) {}

    public function recommend(
        RiskCircuitSnapshot $circuit,
        RiskExposureSnapshot $exposure,
        RiskVelocityAssessment $velocity,
        DateTimeImmutable $asOf,
    ): RiskCircuitTransition {
        $openCooldown = max(self::MIN_OPEN_COOLDOWN_SECONDS, $this->openCooldownSeconds);
        $halfOpenTimeout = min(self::MAX_HALF_OPEN_TIMEOUT_SECONDS, max(30, $this->halfOpenTimeoutSeconds));
        $tenantWide = $exposure->scope === RiskAggregateScope::TENANT;
        $severe = $velocity->level === RiskVelocityLevel::CRITICAL
            || ($tenantWide
                ? ($exposure->extremeCount >= 2 || $exposure->blockedCount >= 3)
                : ($exposure->extremeCount >= 1 || $exposure->blockedCount >= 1));
        $unhealthy = $severe || $velocity->level === RiskVelocityLevel::HIGH;

        if ($circuit->state === RiskCircuitState::CLOSED) {
            if ($severe) {
                return new RiskCircuitTransition(
                    RiskCircuitState::CLOSED,
                    RiskCircuitState::OPEN,
                    ['CIRCUIT_SEVERE_PRESSURE'],
                    $asOf->modify(sprintf('+%d seconds', $openCooldown)),
                    $asOf->modify(sprintf('+%d seconds', $openCooldown * 12)),
                );
            }
            return new RiskCircuitTransition(RiskCircuitState::CLOSED, RiskCircuitState::CLOSED, []);
        }

        if ($circuit->state === RiskCircuitState::OPEN) {
            if ($circuit->probeAfter !== null && $asOf < $circuit->probeAfter) {
                return new RiskCircuitTransition(RiskCircuitState::OPEN, RiskCircuitState::OPEN, ['CIRCUIT_COOLDOWN_ACTIVE'], $circuit->probeAfter, $circuit->expiresAt);
            }
            if ($unhealthy) {
                return new RiskCircuitTransition(
                    RiskCircuitState::OPEN,
                    RiskCircuitState::OPEN,
                    ['CIRCUIT_RECOVERY_DEFERRED'],
                    $asOf->modify(sprintf('+%d seconds', $openCooldown)),
                    $asOf->modify(sprintf('+%d seconds', $openCooldown * 12)),
                );
            }
            return new RiskCircuitTransition(
                RiskCircuitState::OPEN,
                RiskCircuitState::HALF_OPEN,
                ['RECOVERY_WINDOW_ELAPSED', 'PRESSURE_NORMALIZED'],
                $asOf,
                $asOf->modify(sprintf('+%d seconds', $halfOpenTimeout)),
            );
        }

        // HALF_OPEN is deliberately fragile: fresh severe pressure or an expired
        // probe window re-opens it; otherwise it waits for supervised probes.
        if ($unhealthy || ($circuit->expiresAt !== null && $asOf >= $circuit->expiresAt)) {
            return new RiskCircuitTransition(
                RiskCircuitState::HALF_OPEN,
                RiskCircuitState::OPEN,
                [$unhealthy ? 'RECOVERY_PRESSURE_REGRESSION' : 'RECOVERY_PROBE_WINDOW_EXPIRED'],
                $asOf->modify(sprintf('+%d seconds', $openCooldown)),
                $asOf->modify(sprintf('+%d seconds', $openCooldown * 12)),
            );
        }

        return new RiskCircuitTransition(RiskCircuitState::HALF_OPEN, RiskCircuitState::HALF_OPEN, ['AWAITING_SUPERVISED_PROBE'], $circuit->probeAfter, $circuit->expiresAt);
    }
}
