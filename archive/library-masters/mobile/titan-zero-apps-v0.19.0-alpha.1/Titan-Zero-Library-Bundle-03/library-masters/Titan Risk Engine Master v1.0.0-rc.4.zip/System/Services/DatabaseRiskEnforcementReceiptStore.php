<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskEnforcementReceiptStoreContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskEnforcementReceipt;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskEnforcementReceiptStore implements RiskEnforcementReceiptStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_enforcement_receipts',
    ) {}

    public function persist(RiskEnforcementReceipt $receipt): void
    {
        $stamp = $receipt->issuedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        $this->database->table($this->table)->insertOrIgnore([
            'receipt_id' => $receipt->receiptId,
            'content_digest' => $receipt->contentDigest,
            'company_id' => $receipt->companyId,
            'trace_id' => $receipt->traceId,
            'correlation_id' => $receipt->correlationId,
            'causation_id' => $receipt->causationId,
            'capability' => $receipt->capability,
            'action' => $receipt->action,
            'actor_type' => $receipt->actorType,
            'actor_id' => $receipt->actorId === null ? null : (string) $receipt->actorId,
            'resource_type' => $receipt->resourceType,
            'resource_id' => $receipt->resourceId === null ? null : (string) $receipt->resourceId,
            'request_fingerprint' => $receipt->requestFingerprint,
            'execution_directive' => $receipt->directive->value,
            'may_dispatch' => $receipt->mayDispatch,
            'risk_score' => $receipt->riskScore,
            'risk_level' => $receipt->riskLevel->value,
            'assessment_policy_version' => $receipt->assessmentPolicyVersion,
            'governance_source' => $receipt->governanceSource,
            'evidence_id' => $receipt->evidenceId,
            'effective_policy_digest' => $receipt->effectivePolicyDigest,
            'budget_version' => $receipt->budgetVersion,
            'budget_utilization_ratio' => $receipt->budgetUtilizationRatio,
            'receipt_payload' => json_encode($receipt->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'issued_at' => $stamp,
            'created_at' => $stamp,
            'updated_at' => $stamp,
        ]);
    }
}
