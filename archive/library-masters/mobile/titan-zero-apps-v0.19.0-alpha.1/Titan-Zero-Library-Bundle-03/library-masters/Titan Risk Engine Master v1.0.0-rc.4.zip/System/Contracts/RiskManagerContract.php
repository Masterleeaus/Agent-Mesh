<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskAssessment;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskContext;

interface RiskManagerContract
{
    /** @return array{engine:string,status:string,version:string,capabilities:list<string>} */
    public function health(): array;

    public function assess(RiskContext $context): RiskAssessment;
}
