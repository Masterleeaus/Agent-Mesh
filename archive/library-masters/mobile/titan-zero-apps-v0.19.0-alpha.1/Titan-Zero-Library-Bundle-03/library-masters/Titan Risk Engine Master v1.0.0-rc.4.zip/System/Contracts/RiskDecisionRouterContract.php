<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Contracts;

use App\Extensions\TitanRiskEngine\System\Enums\RiskDecision;
use App\Extensions\TitanRiskEngine\System\Enums\RiskExecutionDirective;

interface RiskDecisionRouterContract
{
    public function route(RiskDecision $decision): RiskExecutionDirective;
}
