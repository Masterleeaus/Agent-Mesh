<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\ValueObjects;

use App\Extensions\TitanRiskEngine\System\Enums\ConnectivityState;
use App\Extensions\TitanRiskEngine\System\Enums\Reversibility;
use InvalidArgumentException;

/** Untrusted/pre-resolution request to the RiskGate. */
final readonly class RiskContextInput
{
    /** @param array<string, mixed> $metadata */
    public function __construct(
        public int|string $companyId,
        public string $traceId,
        public string $correlationId,
        public string $causationId,
        public string $capability,
        public string $action,
        public string $actorType,
        public int|string|null $claimedActorId = null,
        public ?string $resourceType = null,
        public int|string|null $resourceId = null,
        public ?string $verticalKey = null,
        public ?string $jurisdiction = null,
        public RiskImpactVector $impact = new RiskImpactVector(),
        public Reversibility $reversibility = Reversibility::REVERSIBLE,
        public ConnectivityState $connectivity = ConnectivityState::ONLINE,
        public array $metadata = [],
        public ?string $idempotencyKey = null,
    ) {
        RiskFieldConstraints::required('companyId', $this->companyId, 64);
        RiskFieldConstraints::text('traceId', $this->traceId, 191, false);
        RiskFieldConstraints::text('correlationId', $this->correlationId, 191, false);
        RiskFieldConstraints::text('causationId', $this->causationId, 191, false);
        RiskFieldConstraints::text('capability', $this->capability, 160, false);
        RiskFieldConstraints::text('action', $this->action, 160, false);
        RiskFieldConstraints::text('actorType', $this->actorType, 80, false);
        RiskFieldConstraints::scalarId('claimedActorId', $this->claimedActorId);
        RiskFieldConstraints::text('resourceType', $this->resourceType, 120);
        RiskFieldConstraints::scalarId('resourceId', $this->resourceId);
        RiskFieldConstraints::text('verticalKey', $this->verticalKey, 120);
        RiskFieldConstraints::text('jurisdiction', $this->jurisdiction, 80);
        RiskFieldConstraints::text('idempotencyKey', $this->idempotencyKey, 191);
        if ($this->idempotencyKey !== null && trim($this->idempotencyKey) === '') {
            throw new InvalidArgumentException('idempotencyKey, when provided, must not be blank.');
        }
    }
}
