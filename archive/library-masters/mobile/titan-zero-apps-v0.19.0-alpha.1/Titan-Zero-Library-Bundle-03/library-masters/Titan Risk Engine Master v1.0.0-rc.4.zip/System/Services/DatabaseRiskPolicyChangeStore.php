<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskPolicyChangeStoreContract;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskPolicyChangeEvidence;
use DateTimeZone;
use Illuminate\Database\ConnectionInterface;

final class DatabaseRiskPolicyChangeStore implements RiskPolicyChangeStoreContract
{
    public function __construct(
        private readonly ConnectionInterface $database,
        private readonly string $table = 'titan_risk_policy_changes',
    ) {}

    public function persist(RiskPolicyChangeEvidence $evidence): void
    {
        $stamp = $evidence->changedAt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        $this->database->table($this->table)->insertOrIgnore([
            'change_id' => $evidence->changeId,
            'action' => $evidence->action,
            'company_id' => $evidence->companyId,
            'policy_key' => $evidence->policyKey,
            'version' => $evidence->version,
            'previous_version' => $evidence->previousVersion,
            'trace_id' => $evidence->traceId,
            'correlation_id' => $evidence->correlationId,
            'causation_id' => $evidence->causationId,
            'actor_type' => $evidence->actorType,
            'actor_id' => $evidence->actorId === null ? null : (string) $evidence->actorId,
            'reason' => $evidence->reason,
            'change_payload' => json_encode($evidence->toArray(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES),
            'changed_at' => $stamp,
            'created_at' => $stamp,
            'updated_at' => $stamp,
        ]);
    }
}
