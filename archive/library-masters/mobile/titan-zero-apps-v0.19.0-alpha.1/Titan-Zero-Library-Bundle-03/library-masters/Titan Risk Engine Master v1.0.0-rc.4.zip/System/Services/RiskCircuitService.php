<?php

declare(strict_types=1);

namespace App\Extensions\TitanRiskEngine\System\Services;

use App\Extensions\TitanRiskEngine\System\Contracts\RiskAggregateContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskCircuitStoreContract;
use App\Extensions\TitanRiskEngine\System\Contracts\RiskVelocityContract;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskAggregateWindow;
use App\Extensions\TitanRiskEngine\System\Enums\RiskCircuitScope;
use App\Extensions\TitanRiskEngine\System\Enums\RiskVelocityWindow;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitKey;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitSnapshot;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskCircuitTransitionEvidence;
use App\Extensions\TitanRiskEngine\System\ValueObjects\RiskHistoryQuery;
use DateTimeImmutable;

final class RiskCircuitService implements RiskCircuitContract
{
    public function __construct(
        private readonly RiskCircuitStoreContract $store,
        private readonly RiskCircuitManager $manager,
        private readonly RiskAggregateContract $aggregate,
        private readonly RiskVelocityContract $velocity,
        private readonly string $policyVersion = DefaultRiskCircuitPolicy::POLICY_VERSION,
        private readonly ?RiskSignalDispatcher $signalDispatcher = null,
        private readonly bool $inlineSignalDispatch = false,
    ) {}

    public function status(RiskCircuitKey $key, DateTimeImmutable $asOf): RiskCircuitSnapshot
    {
        return $this->store->getOrCreate($key, $asOf, $this->policyVersion);
    }

    public function evaluate(RiskCircuitKey $key, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot
    {
        $current = $this->store->getOrCreate($key, $evidence->occurredAt, $this->policyVersion);
        [$exposure, $velocity] = $this->history($key, $evidence->occurredAt);
        $result = $this->manager->reconcile($current, $exposure, $velocity, $evidence);
        if ($this->inlineSignalDispatch) $this->signalDispatcher?->dispatchPending(10);
        return $result;
    }

    public function recordProbe(RiskCircuitKey $key, bool $successful, bool $supervised, RiskCircuitTransitionEvidence $evidence): RiskCircuitSnapshot
    {
        $current = $this->store->getOrCreate($key, $evidence->occurredAt, $this->policyVersion);
        [$exposure, $velocity] = $this->history($key, $evidence->occurredAt);
        $result = $this->manager->recordProbe($current, $successful, $supervised, $exposure, $velocity, $evidence);
        if ($this->inlineSignalDispatch) $this->signalDispatcher?->dispatchPending(10);
        return $result;
    }

    /** @return array{0:\App\Extensions\TitanRiskEngine\System\ValueObjects\RiskExposureSnapshot,1:\App\Extensions\TitanRiskEngine\System\ValueObjects\RiskVelocityAssessment} */
    private function history(RiskCircuitKey $key, DateTimeImmutable $asOf): array
    {
        $scope = $key->scope === RiskCircuitScope::TENANT ? RiskAggregateScope::TENANT : RiskAggregateScope::TENANT_CAPABILITY;
        $aggregateQuery = RiskHistoryQuery::forAggregateWindow(
            companyId: $key->companyId,
            scope: $scope,
            window: RiskAggregateWindow::HOURS_1,
            asOf: $asOf,
            capability: $key->capability,
        );
        $velocityQuery = RiskHistoryQuery::forVelocityWindow(
            companyId: $key->companyId,
            scope: $scope,
            window: RiskVelocityWindow::MINUTES_5,
            asOf: $asOf,
            capability: $key->capability,
        );
        return [$this->aggregate->aggregate($aggregateQuery), $this->velocity->assess($velocityQuery)];
    }
}
