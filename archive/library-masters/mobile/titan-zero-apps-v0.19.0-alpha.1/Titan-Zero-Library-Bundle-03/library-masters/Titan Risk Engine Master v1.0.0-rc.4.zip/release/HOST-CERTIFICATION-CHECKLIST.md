# Titan Risk Engine — Exact Host Certification Checklist

Target host profile: `titan.host.magicai.installer-1.7.8.v1`.

Run this against the exact final ZIP on the target MagicAI/Titan host. Do not promote `1.0.0-rc.3` to final `1.0.0` until every required stage is PASS.

1. **PACKAGE_CERTIFIED** — verify the published ZIP SHA-256, flat root, `extension.json`, and Installer integrity map before upload.
2. **INSTALLER_CERTIFIED** — install the exact ZIP through Installer 1.7.8; record install ID and confirm dependency/provider registration succeeds without manual file edits.
3. **MIGRATION_CERTIFIED** — confirm all seven forward migrations apply on the target MySQL version; verify all nine Risk-owned tables and critical columns exist.
4. **BOOT_CERTIFIED** — run `php artisan titan:titan-risk-engine:certify --json`; every check must be `true`, including actual Laravel container resolution of public contracts.
5. **NAVIGATION_CERTIFIED** — confirm exactly one top-level `Titan Risk` link is rendered, `Risk Control Centre` is nested beneath it, both routes open correctly, and host navigation customization is preserved.
   - Run `php artisan titan:titan-risk-engine:sync-navigation --json` if either link is absent, then confirm both returned routes are `true`.
6. **AUTHORIZATION_CERTIFIED** — tenant user can only view their own tenant Risk data; non-admin cannot invoke admin policy/signal mutation routes; admin routes remain behind `web`, `auth`, `admin`.
7. **RUNTIME_CERTIFIED** — execute representative `risk.assess`, `risk.gate`, aggregate, velocity, circuit and feedback flows; verify receipts/signals and fail-closed behavior; capture live p99 against the declared SLO targets.
8. **UPGRADE_CERTIFIED** — upgrade from the latest deployed Risk version using the exact ZIP; verify old/new data remains readable, migrations are idempotent, and no retained evidence is lost.
9. **UNINSTALL_CERTIFIED** — uninstall through the host extension lifecycle; confirm published config is removed while all Risk-owned audit/evidence tables remain intact under the retain-data policy.

Store evidence for each stage in a report conforming to Blueprint v4.2 `host-certification-report.schema.json`.
