# Security

Tenant boundary is `company_id`. TrustedRiskContextFactory resolves actor identity; caller-supplied recent activity is overwritten; metadata is bounded and protected fields are stripped. Risk outputs constrain authority and never grant business mutation authority. Secrets are not stored by this extension.
## Pass 8 authority-boundary hardening

- Authority-bearing strings/IDs are UTF-8, control-character and size validated.
- Idempotency is semantic, not merely key-based.
- Enforcement receipts are context-bound and digest-verifiable.
- Policy/budget content digests are verified on database hydration.
- Admin causal lineage comes from trusted host request attributes, not caller headers.
- Cross-engine feedback lineage must exactly match the gated operation.
- Metadata is canonicalized and bounded to prevent authority-key alias injection and oversized payload abuse.

