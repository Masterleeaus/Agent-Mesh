# Engine ownership

Titan Risk Engine is the intended canonical owner of contextual/cumulative risk assessment and risk constraints. Current Blueprint v4.2.0 uses legacy logical id `titan-risk` in some ownership registries while its architecture example uses `titan-risk-engine`; the companion Blueprint delta reconciles those identifiers without changing business-domain ownership.
