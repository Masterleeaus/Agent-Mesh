# Pass 8 — Security, Abuse-Case & Fuzz Hardening

## Objective

Harden every Risk authority-bearing input, replay, persistence and evidence boundary without changing the deterministic risk-scoring semantics.

## Security invariants

1. **Tenant isolation:** tenant identifiers are validated at value-object boundaries; user-facing tenant context remains server-resolved.
2. **Semantic idempotency:** an idempotency key is reusable only for the same trusted semantic operation. Causal lineage may change on retry; capability, action, actor, resource, impacts, reversibility, connectivity and sanitized metadata may not.
3. **Receipt anti-replay:** enforcement receipts bind the exact action, trusted actor, resource, request fingerprint, policy digest, budget state, circuit versions, directive and dispatch authority.
4. **Governance evidence binding:** Model Council, Assurance and Shield feedback must carry the exact trace/correlation/causation lineage of the Risk gate being modified.
5. **Trusted policy lineage:** admin policy operations accept causal lineage only from host-resolved request attributes; raw client trace headers are ignored.
6. **Policy integrity:** persisted risk budget and policy overlay content digests are verified on hydration. A mismatch raises `RISK_POLICY_INTEGRITY_MISMATCH`.
7. **Metadata containment:** metadata is depth-, count-, string- and total-byte bounded; reserved authority aliases and canonical-key collisions cannot override risk state.
8. **Numerical safety:** NaN and infinity are invalid for impacts, policy numbers, budgets and external confidence values.
9. **Fail closed:** authoritative integrity, replay or dependency failures cannot increase execution authority.

## New/changed components

- `RiskFieldConstraints` — reusable UTF-8, control-character, length and identifier validation.
- `RiskContextFingerprint` — deterministic authorization-semantic SHA-256 fingerprint.
- `RiskIdempotencyGuard` — prevents idempotency-key reuse across different semantic operations.
- `RiskEnforcementReceiptVerifier` / contract — verifies receipt digest, identity, dispatch consistency and optional expected context.
- `RiskPolicyIntegrityVerifier` — validates persisted budget/overlay content digests before use.
- `RiskMetadataSanitizer` — canonical reserved-key filtering, canonical-key collision detection and 32 KiB default total metadata cap.
- Forward migration `2026_08_21_000007_harden_risk_enforcement_receipts.php` adds action/actor/resource/request-fingerprint columns to durable receipts.

## Abuse/fuzz coverage

Package-level deterministic tests cover:

- non-finite impact/policy/budget/confidence values;
- oversized and control-character causal identifiers;
- malformed tenant identifiers;
- reserved metadata aliases and canonical collisions;
- metadata byte bounds;
- semantic idempotency collision/replay;
- receipt tampering and cross-tenant/cross-resource replay;
- cross-action governance evidence replay;
- policy/budget database-content tampering;
- a deterministic 500-case hostile metadata fuzz corpus.

## Explicit non-goals

Pass 8 does not claim live-host penetration testing, real parallel MySQL stress, browser authorization testing, or production WAF/network validation. Those require the target Titan/MagicAI runtime and remain host certification work.
