# Pass 2C — Historical Risk Intelligence

## Delivered

- operational `risk.aggregate`
- operational `risk.velocity`
- durable history reader
- canonical historical scopes
- exact 1h / 4h / 24h aggregate windows
- exact 5m / 15m / 60m velocity windows
- `NORMAL / ELEVATED / HIGH / CRITICAL` pressure levels
- structured pressure reason codes
- policy registry (`baseline-v1`, `intelligence-v1`)
- circuit state and policy contract (`CLOSED / OPEN / HALF_OPEN`) without state mutation
- actor+capability+time composite index
- cross-engine integration design for Council, Forge, Assurance, Shield and Command Bus
- operational-risk-budget boundary

## Aggregate semantics

`RiskExposureSnapshot` returns assessment count, score sum, score average, score maximum, HIGH-or-EXTREME count, EXTREME count and BLOCK count for an exact UTC interval.

Scopes are enforced by `RiskHistoryQuery`; actor/capability/resource selectors are mandatory when their scope requires them.

## Velocity semantics

Velocity derives from durable ledger exposure. Default `intelligence-v1` thresholds:

| Level | Actions/min | Risk points/min | HIGH/EXTREME count |
|---|---:|---:|---:|
| ELEVATED | 2 | 50 | 1 |
| HIGH | 4 | 100 | 2 |
| CRITICAL | 8 | 200 | 3 |

Crossing any threshold for a level is sufficient. Runtime configuration can lower these thresholds (more conservative) but is clamped so it cannot raise them above the built-in safety floor.

No output field or reason code claims attack, abuse or malicious intent. Those require independent security evidence.

## Circuit boundary

Pass 2C intentionally stops before stateful circuit enforcement. `RiskCircuitPolicyContract` can recommend a transition, but no persistence, atomic state transition, probe executor or manifest capability exists yet. `risk.circuit` therefore remains unavailable.

## Policy lifecycle

Old assessments are never re-written when policy changes. New policy versions apply prospectively. A requested reassessment creates new evidence with new lineage.
