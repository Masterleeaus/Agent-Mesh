# Pass 9 — Final Production Hardening & Host-Ready Certification

## Purpose

Pass 9 closes package-side release drift and prepares Titan Risk Engine for exact-host certification. It does not weaken or materially change the established deterministic scoring, aggregate, velocity, circuit, governance-feedback, budget, policy, or receipt semantics.

## Release state

Version `1.0.0-rc.3` is a release candidate. Package-side verification can prove archive integrity, static architecture, migrations, contracts and executable standalone behavior. It cannot prove that a specific deployed MagicAI host completed installer registration, migrations, provider boot, route middleware, navigation synchronization, authorization, live MySQL concurrency, live SLOs, upgrade or uninstall behavior.

Promotion to final `1.0.0` requires the target host to complete `release/HOST-CERTIFICATION-CHECKLIST.md` and record the result using the bundled host certification report contract.

## Final hardening changes

1. `enabled=false` is now authoritative and fail-closed. `risk.assess` returns `EXTREME / BLOCK / disabled-v1`; `risk.gate` returns `DENY / disabled-v1` without invoking the inner governance path.
2. The deprecated `System/Http/Controllers/AdminController.php` was removed. It was unreachable from current routes and accepted `company_id` from request input, which was incompatible with the trusted-tenant boundary.
3. Canonical navigation now exposes the read-only tenant Risk page and admin Risk Control Centre through Blueprint v4.2 navigation contributions.
4. Runtime certification now resolves every public Risk contract through the Laravel container rather than checking only `bound()`. It also validates critical database columns, canonical routes/views, MySQL, runtime version floors, canonical extension folder and the installer integrity map.
5. Manifest drift was corrected: performance/fault-injection verification are true because those suites already exist; unused upload path ownership was removed.
6. Final standalone audits assert version, navigation, owned tables, disabled-state enforcement, provider wiring and host-certification artifacts.

## Non-negotiable authority rules

- Disabled or unavailable Risk never increases authority.
- `BLOCK`/`DENY` cannot be relaxed by Council, Assurance, Shield, commercial tier, policy rollback or UI configuration.
- Tenant identity is resolved from trusted host context for user-facing surfaces.
- Risk produces constraints and evidence; Command Bus remains the executor.
- Durable audit/evidence tables are retained on uninstall unless a separately governed destructive process is explicitly authorized.
