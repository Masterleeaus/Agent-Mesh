# Signal Events

Pass 4 activates production event envelopes. Every event carries tenant, trace, correlation, causation, root-causation fallback, severity, event ID, occurrence time, and a bounded structured payload. Raw metadata, credentials, tokens, secrets, authorization headers, and signatures are excluded.

Emitted events:

- `risk.assessed`
- `risk.threshold.crossed`
- `risk.exposure.increased`
- `risk.circuit.opened`
- `risk.circuit.half_opened`
- `risk.circuit.closed`
- `risk.circuit.probe_failed`
- `risk.governance.feedback.applied`

Events are first written idempotently to `titan_risk_signal_outbox`. `LaravelRiskSignalPublisher` dispatches them through `titan.signal.ingest`. If no listener is present or publishing fails, the event stays pending and can be retried.
