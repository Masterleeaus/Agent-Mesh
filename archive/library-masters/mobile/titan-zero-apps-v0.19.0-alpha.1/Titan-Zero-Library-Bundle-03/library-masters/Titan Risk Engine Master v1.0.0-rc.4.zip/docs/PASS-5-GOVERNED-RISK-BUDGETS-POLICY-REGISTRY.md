# Pass 5 — Governed Risk Budgets & Policy Registry

Titan Risk Engine v0.6.0 adds deterministic operational exposure budgets and immutable policy overlays.

## Invariants

- Budgets constrain autonomous execution; they never rewrite intrinsic assessment score or level.
- Built-in safety ceilings are non-weakenable. Tenant or capability configuration can only retain or tighten them.
- Policy/budget activation is prospective via `effective_at`; no historical assessment is rewritten.
- Rollback creates a new immutable version pointing back to the target policy/budget. Existing records are never edited or deleted.
- Effective policy resolution is deterministic for `GLOBAL`, `TENANT`, `CAPABILITY`, and `TENANT_CAPABILITY` scopes.
- Only allow-listed constraints are accepted: daily exposure, autonomous single-action level, monitoring threshold, and hard block level.
- Every governance change carries trace/correlation/causation evidence in `titan_risk_policy_changes`.

## Gate behavior

The 24-hour tenant exposure is evaluated after the intrinsic Risk decision and circuit state:

- monitoring threshold reached → at least `EXECUTE_MONITORED`
- daily exposure budget exceeded → at least `HOLD_FOR_APPROVAL`
- autonomous single-action ceiling exceeded → at least `HOLD_FOR_APPROVAL`
- hard block ceiling reached → `DENY`

Existing stricter decisions or circuit constraints always win.

## Durable ownership

- `titan_risk_budget_versions`
- `titan_risk_policy_overlays`
- `titan_risk_policy_changes`

Enforcement receipts now pin effective policy digest, effective budget version, and utilization ratio.
