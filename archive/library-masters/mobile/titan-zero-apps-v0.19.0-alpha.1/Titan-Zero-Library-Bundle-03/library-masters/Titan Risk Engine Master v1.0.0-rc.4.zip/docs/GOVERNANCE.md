# Governance

Risk asks what could go wrong and returns an upper-bound constraint. It does not own effective autonomy and cannot increase authority. Offline operation preserves or reduces authority.

`baseline-v1` governs single-action scoring. `intelligence-v1` governs aggregate/velocity semantics. Historical evidence is immutable under the policy version originally used.

Commercial tier may affect operational exposure budgets, monitoring and approval cadence, but cannot weaken hard safety, legal, privacy or compliance ceilings. Runtime velocity configuration may tighten built-in thresholds only; weakening requires a future governed policy-version change.
