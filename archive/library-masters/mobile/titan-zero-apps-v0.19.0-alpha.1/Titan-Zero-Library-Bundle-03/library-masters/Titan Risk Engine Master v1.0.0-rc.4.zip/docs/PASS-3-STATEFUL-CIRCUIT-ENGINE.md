# Pass 3 — Stateful Circuit Engine

Titan Risk Engine v0.4.0 makes `risk.circuit` operational.

## Scope

Circuits are canonical Risk-owned governance state at either `TENANT` or `TENANT_CAPABILITY` scope. They do not mutate CRM, billing, job, customer, or other domain-owner state.

## State machine

- `CLOSED`: normal RiskGate routing applies.
- `OPEN`: normal executor dispatch is denied.
- `HALF_OPEN`: normal executor dispatch remains held; only supervised recovery probes may advance recovery.

`CLOSED -> OPEN` occurs under severe historical pressure. Capability circuits may open on a single EXTREME/BLOCK observation; tenant-wide circuits require stronger evidence (critical velocity, at least two EXTREME observations, or at least three BLOCK observations).

`OPEN -> HALF_OPEN` requires the minimum cooldown to elapse and historical pressure to normalize. Timeout never auto-closes a circuit.

`HALF_OPEN -> CLOSED` requires at least two supervised successful recovery probes under healthy historical conditions. A failed probe, renewed HIGH/CRITICAL velocity, fresh EXTREME/BLOCK pressure, or an expired half-open probe window returns the circuit to `OPEN`.

## Concurrency and evidence

`titan_risk_circuits` is unique on tenant + scope + capability key. Every mutation executes inside a database transaction with `lockForUpdate()` and an expected state/version check. Stale writers fail closed with `STALE_CIRCUIT_VERSION`.

Every transition is appended to `titan_risk_circuit_transitions` with trace, correlation, causation, policy version, reason codes, and resulting circuit version.

## Policy hardening

`circuit-v1` establishes non-weakenable defaults:

- minimum OPEN cooldown: 300 seconds
- maximum HALF_OPEN probe window: 300 seconds
- minimum successful supervised probes: 2

Runtime configuration may make recovery more conservative but cannot reduce these floors.

## RiskGate integration

RiskGate evaluates both tenant and tenant+capability circuits after persisting the current action assessment:

- any `OPEN` circuit -> `DENY`
- any `HALF_OPEN` circuit -> `HOLD_FOR_ASSURANCE`
- all `CLOSED` -> preserve normal risk decision routing

Command Bus or another authoritative executor remains responsible for obeying the returned directive.
