# Troubleshooting

If RiskGate is unavailable, consequential callers should fail closed or reduce authority. Check database connectivity, cache connectivity, provider registration, migrations, tenant context, and duplicate idempotency keys. Never bypass Risk by directly executing a blocked action.
