# Capabilities

## `risk.assess`
Deterministic score, level, decision, reasons, remediation and policy lineage. Emits durable assessment/exposure/threshold events without executing domain state.

## `risk.gate`
Fresh pre-execution governance with tenant + capability circuit checks. Returns an execution directive and a persisted enforcement receipt.

## `risk.aggregate`
Read-only historical exposure over exactly 1h, 4h or 24h across tenant/capability/actor/resource scopes.

## `risk.velocity`
Read-only operational-pressure analysis over exactly 5m, 15m or 60m. It never infers attacker intent.

## `risk.circuit`
Persistent CLOSED / OPEN / HALF_OPEN circuits with row locking, optimistic version checks, hysteresis, cooldown, supervised probes and append-only transition evidence.

## `risk.feedback`
Applies typed Model Council, Assurance or Shield evidence to an existing gate result. Feedback is persisted, Signal-emitted, and receives a replacement enforcement receipt. External evidence cannot weaken hard Risk constraints.

## Pass 7 runtime semantics

- `risk.assess` stages Signal evidence durably but does not publish Signals inline by default. Target-host p99 objective: <=50ms.
- `risk.gate` is exposed through a fail-closed decorator. Unhandled authoritative dependency failure returns `EXTREME / BLOCK / DENY` under `fail-closed-v1`; it never converts failure into execution authority. Target-host p99 objective: <=100ms.
- Runtime telemetry and recent-activity cache are non-authoritative. Their failure cannot increase or invalidate Risk authority.
