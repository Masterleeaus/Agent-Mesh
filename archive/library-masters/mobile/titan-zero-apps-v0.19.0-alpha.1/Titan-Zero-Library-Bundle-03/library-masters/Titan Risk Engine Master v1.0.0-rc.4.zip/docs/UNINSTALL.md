# Uninstall

Default policy is retain-data. Provider uninstall removes published configuration only. Durable risk/audit data is preserved unless a separate governed deletion process is explicitly authorized.
