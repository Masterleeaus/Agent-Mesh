# Architecture

Titan Risk Engine is a `governance-engine` that owns deterministic risk assessments, historical exposure, circuit constraints, governance feedback evidence and execution-authority receipts. It never owns business truth or performs authoritative domain mutation.

Canonical pre-execution path:

`proposal -> risk.gate -> enforcement receipt -> Assurance/Autonomy as required -> Command Bus -> domain owner`

Historical intelligence path:

`titan_risk_assessments -> RiskHistoryReader -> risk.aggregate / risk.velocity -> circuit policy -> governance consumer`

Cross-engine feedback path:

`Model Council / Assurance / Shield -> risk.feedback -> stricter-or-governed directive -> replacement enforcement receipt -> Signal outbox`

Forge path:

`BuildSpec -> pre-generation Risk gate -> generation -> generated artifact -> post-generation Risk gate + Shield -> deployment authority`

The durable ledger, not caller-provided recent activity, is the source of historical truth. Command Bus remains optional from Risk's dependency side to avoid a Risk <-> Command Bus cycle. Titan Signal is a required peer; Risk writes its own durable outbox and never writes Signal's internal tables.
