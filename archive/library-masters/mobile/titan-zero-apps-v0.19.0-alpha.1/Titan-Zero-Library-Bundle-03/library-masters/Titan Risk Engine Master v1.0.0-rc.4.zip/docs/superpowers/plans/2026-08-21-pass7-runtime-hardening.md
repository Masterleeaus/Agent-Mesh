# Pass 7 Runtime Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Titan Risk fail closed under dependency outages and remain predictable under contention/load.

**Architecture:** Keep the existing deterministic Risk core. Add a fail-closed `RiskGateContract` decorator, soft-failure cache decorator behavior, durable-outbox retry controls, bounded transaction policy, and atomic policy-governance transaction runner. No direct cross-engine dependencies are added.

**Tech Stack:** PHP 8.2+, Laravel 10 query/cache contracts, MySQL, Blueprint v4.2 manifest schema 2.2.

**Spec:** `docs/superpowers/specs/2026-08-21-pass7-runtime-hardening-design.md`

## Global Constraints
- Risk must never increase execution authority when a dependency is unavailable.
- Command Bus remains the executor.
- Hard safety/compliance ceilings remain non-weakenable.
- No synchronous Signal dependency is required for `risk.assess` success.
- Standalone package must not claim host DB/network concurrency benchmarks as host-certified.

---

### Task 1: Fail-closed RiskGate decorator
**Files:** create runtime telemetry contract/value/service and fail-closed gate; bind decorator in provider; add smoke test.

### Task 2: Signal backpressure and cache degradation
**Files:** update RiskManager, CachedRecentActivityProvider, DatabaseRiskSignalOutbox, config; add smoke test.

### Task 3: Database concurrency hardening
**Files:** add database error classifier and transaction runner; update ledger, circuit store, policy governance provider/service; add smoke test.

### Task 4: Performance benchmark and release certification
**Files:** add pure scorer benchmark, Pass 7 docs, version/manifests/release evidence; run all regression and Blueprint/Installer gates.
