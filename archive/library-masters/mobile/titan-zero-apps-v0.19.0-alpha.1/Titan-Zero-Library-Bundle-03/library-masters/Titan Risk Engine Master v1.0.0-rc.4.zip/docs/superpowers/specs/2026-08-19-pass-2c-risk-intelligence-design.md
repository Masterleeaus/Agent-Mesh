# Titan Risk Engine Pass 2C — Risk Intelligence Design

## Goal
Activate deterministic, tenant-scoped historical risk intelligence without prematurely enabling circuit enforcement.

## Scope
Pass 2C makes `risk.aggregate` and `risk.velocity` operational. It adds typed circuit and policy-lifecycle contracts for the next pass, and documents the Model Council, Forge, Assurance, Shield, Command Bus, and operational-risk-budget handshakes.

## Historical source of truth
All aggregate and velocity calculations read the durable `titan_risk_assessments` ledger. Caller-provided `recent_activity` remains non-authoritative and is never used as the source of aggregate/velocity truth.

## Aggregate semantics
Supported scopes:
- TENANT
- TENANT_CAPABILITY
- TENANT_ACTOR
- TENANT_RESOURCE
- ACTOR_CAPABILITY

Supported windows:
- 1 hour
- 4 hours
- 24 hours

Each snapshot returns assessment count, score sum, average, maximum, HIGH-or-EXTREME count, EXTREME count, BLOCK count, scope, and exact UTC window bounds.

## Velocity semantics
Supported windows:
- 5 minutes
- 15 minutes
- 60 minutes

Velocity derives from the durable aggregate snapshot and reports:
- actions per minute
- accumulated risk-score points per minute
- HIGH/EXTREME concentration
- deterministic pressure level: NORMAL, ELEVATED, HIGH, CRITICAL
- structured reason codes

Velocity is an operational-pressure detector, not an attack classifier. No reason code or API output may assert malicious intent.

Default pressure thresholds are configuration-driven and may only make decisions more conservative without a governed policy-version change.

## Circuit boundary
Pass 2C introduces `CLOSED`, `OPEN`, and `HALF_OPEN` as canonical circuit states plus a `RiskCircuitPolicyContract` and typed transition recommendation. It does not persist or mutate circuit state and therefore does not advertise `risk.circuit` yet.

Future circuit rules must use hysteresis: OPEN requires CRITICAL pressure or policy-defined extreme exposure; recovery first moves to HALF_OPEN, and CLOSED requires a successful governed probe plus lower recovery threshold.

## Policy lifecycle
Historical assessments are immutable and retain the policy version used when created. New policy versions apply prospectively. Reassessment creates a new assessment/receipt and never rewrites historical outcomes.

`RiskPolicyRegistryContract` exposes current and named policy versions. The built-in registry publishes `baseline-v1` (single-action scoring) and `intelligence-v1` (aggregate/velocity semantics).

## Cross-engine handshakes
- Model Council: pre-deliberation RiskGate first; disagreement returns afterward as uncertainty evidence before autonomous execution. High disagreement reduces authority but does not automatically reduce deliberation breadth.
- Forge: pre-generation RiskGate on BuildSpec; post-generation Risk/Shield assessment on generated artifact. Generation and deployment are separate authority points.
- Assurance: REQUIRE_ASSURANCE invokes Assurance; its result can trigger reassessment but cannot directly raise Risk authority beyond hard policy ceilings.
- Shield: Shield can add constraints/findings; it cannot turn Risk BLOCK into ALLOW.
- Command Bus: consumes final RiskGate directive; Risk never performs authoritative domain mutation.

## Operational risk budgets
Commercial/tenant budgets govern cumulative autonomous exposure and monitoring/approval thresholds. They never weaken hard safety, legal, privacy, or compliance ceilings. Paying for a higher tier cannot purchase permission around an EXTREME hard-risk block.

## Data and performance
A forward migration adds an actor+capability+time composite index for historical queries. Aggregate/velocity are read-only and use indexed UTC `assessed_at` boundaries. No historical backfill is required because Pass 2B already persisted first-class score/scope fields.

## Failure behavior
Missing/invalid tenant or required scope selectors fail validation. Storage failure propagates as unavailable intelligence; callers must not interpret unavailable Risk intelligence as ALLOW.

## Capability advertising
`risk.aggregate` and `risk.velocity` are advertised only after production services, contracts, schemas, provider bindings, and tests exist. `risk.circuit` remains unadvertised until state persistence and transition enforcement are implemented.
