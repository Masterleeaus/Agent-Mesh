# Pass 2B — Durable Risk Ledger

## Purpose

Turn each Risk assessment into durable, tenant-bound governance evidence without coupling Risk to authoritative business state.

## Persistence invariants

1. Every persisted assessment has a non-empty `company_id`.
2. Trace, correlation and causation lineage are persisted as first-class fields.
3. `company_id + idempotency_key` is unique when a key is supplied.
4. Duplicate idempotent evaluations return the canonical original assessment and do not inflate recent activity.
5. Important query dimensions are indexed independently; historical analytics are not locked behind a single hash key.
6. UTC hour/day buckets are derived from `assessed_at` and never accepted from caller metadata.
7. Structured reason/remediation evidence is stored; unrestricted hidden reasoning is never persisted.
8. Risk still does not execute or mutate authoritative domain state.

## Historical fields

The ledger now records capability/action, actor, resource, vertical/jurisdiction, score/level/decision, policy version, reversibility/connectivity, six impact dimensions, UTC hour/day buckets, reason codes, full reasons, remediation, recent activity, sanitized metadata and a canonical context snapshot.

## Future aggregate/velocity readiness

The index strategy supports independent windows across tenant, capability, actor and resource. Pass 2C defines how these dimensions become effective risk rather than activating scoring prematurely.
