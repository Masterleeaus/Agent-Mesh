# Titan Risk Engine Pass 2C Risk Intelligence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Activate tenant-scoped `risk.aggregate` and `risk.velocity` while introducing non-operational circuit and policy-lifecycle contracts.

**Architecture:** Durable ledger history is accessed through a read-only `RiskHistoryReaderContract`. Aggregate returns typed exposure snapshots for canonical scopes/windows; Velocity converts those snapshots into deterministic pressure levels without inferring intent. Circuit contracts are defined but not advertised until a later stateful pass.

**Tech Stack:** PHP 8.2+, Laravel 10 query builder, MySQL, PHPUnit-compatible tests, Blueprint v4.2 canonical extension schema.

**Spec:** `docs/superpowers/specs/2026-08-19-pass-2c-risk-intelligence-design.md`

## Global Constraints

- `company_id` is mandatory for every historical query.
- Aggregate windows are exactly 1h, 4h, and 24h.
- Velocity windows are exactly 5m, 15m, and 60m.
- Velocity reports pressure, never malicious intent.
- Circuit state is typed but not persisted or advertised in Pass 2C.
- Historical assessments remain immutable across policy changes.
- Offline/unavailable Risk must never increase authority.

---

### Task 1: Historical Query Model and Aggregate Capability

**Files:**
- Create: `System/Enums/RiskAggregateScope.php`
- Create: `System/Enums/RiskAggregateWindow.php`
- Create: `System/ValueObjects/RiskHistoryQuery.php`
- Create: `System/ValueObjects/RiskExposureSnapshot.php`
- Create: `System/Contracts/RiskHistoryReaderContract.php`
- Create: `System/Contracts/RiskAggregateContract.php`
- Create: `System/Services/RiskAggregateService.php`
- Create: `tests/Fakes/InMemoryRiskHistoryReader.php`
- Create: `tests/Unit/RiskAggregateServiceTest.php`

**Interfaces:**
- Produces: `RiskAggregateContract::aggregate(RiskHistoryQuery): RiskExposureSnapshot`
- Produces: `RiskHistoryReaderContract::summarize(RiskHistoryQuery): RiskExposureSnapshot`

- [ ] Write failing aggregate tests for canonical 1h/4h/24h bounds and scope validation.
- [ ] Run the direct Pass 2C smoke harness and confirm missing aggregate classes fail.
- [ ] Implement the minimal enums/value objects/contracts/service/fake.
- [ ] Re-run aggregate tests and smoke assertions to green.

### Task 2: Durable Database History Reader and Index

**Files:**
- Create: `System/Services/DatabaseRiskHistoryReader.php`
- Create: `database/migrations/2026_08_19_000003_add_risk_history_query_index.php`
- Create: `tests/Feature/HistoryMigrationContractTest.php`
- Create: `tests/Architecture/HistoryReaderBoundaryTest.php`

**Interfaces:**
- Implements: `RiskHistoryReaderContract::summarize(RiskHistoryQuery): RiskExposureSnapshot`

- [ ] Write failing contract tests for tenant/time filters, scope filters, and actor+capability index declaration.
- [ ] Run tests and verify RED.
- [ ] Implement the indexed query reader and forward migration.
- [ ] Re-run tests and verify GREEN.

### Task 3: Velocity Capability

**Files:**
- Create: `System/Enums/RiskVelocityLevel.php`
- Create: `System/Enums/RiskVelocityWindow.php`
- Create: `System/ValueObjects/RiskVelocityAssessment.php`
- Create: `System/Contracts/RiskVelocityContract.php`
- Create: `System/Services/RiskVelocityService.php`
- Create: `tests/Unit/RiskVelocityServiceTest.php`

**Interfaces:**
- Produces: `RiskVelocityContract::assess(RiskHistoryQuery): RiskVelocityAssessment`
- Consumes: `RiskHistoryReaderContract::summarize(...)`

- [ ] Write failing tests for NORMAL/ELEVATED/HIGH/CRITICAL pressure and no attack-intent labels.
- [ ] Run tests and verify RED.
- [ ] Implement deterministic threshold classification and reason codes.
- [ ] Re-run tests and verify GREEN.

### Task 4: Circuit and Policy Lifecycle Contracts

**Files:**
- Create: `System/Enums/RiskCircuitState.php`
- Create: `System/ValueObjects/RiskCircuitTransition.php`
- Create: `System/Contracts/RiskCircuitPolicyContract.php`
- Create: `System/ValueObjects/RiskPolicyVersion.php`
- Create: `System/Contracts/RiskPolicyRegistryContract.php`
- Create: `System/Services/StaticRiskPolicyRegistry.php`
- Create: `tests/Unit/RiskPolicyRegistryTest.php`
- Create: `tests/Unit/RiskCircuitContractTest.php`

**Interfaces:**
- Produces: typed circuit transition recommendation only; no mutation.
- Produces: current/named immutable policy versions.

- [ ] Write failing tests proving canonical circuit states, hysteresis fields, and immutable policy-version lookup.
- [ ] Run tests and verify RED.
- [ ] Implement types/contracts/registry.
- [ ] Re-run tests and verify GREEN.

### Task 5: Laravel Wiring, Capability Schemas, Manifest and Documentation

**Files:**
- Modify: `System/TitanRiskEngineServiceProvider.php`
- Modify: `System/Services/RiskManager.php`
- Modify: `config/titan-risk-engine.php`
- Create: `schemas/capabilities/risk.aggregate.input.json`
- Create: `schemas/capabilities/risk.aggregate.output.json`
- Create: `schemas/capabilities/risk.velocity.input.json`
- Create: `schemas/capabilities/risk.velocity.output.json`
- Modify: `extension.manifest.json`
- Modify: `README.md`
- Modify: `CHANGELOG.md`
- Modify: `docs/CAPABILITIES.md`
- Modify: `docs/ARCHITECTURE.md`
- Create: `docs/PASS-2C-RISK-INTELLIGENCE.md`

**Interfaces:**
- Container bindings expose `RiskAggregateContract`, `RiskVelocityContract`, `RiskPolicyRegistryContract`, and `RiskHistoryReaderContract`.
- Manifest advertises `risk.aggregate` and `risk.velocity`; does not advertise `risk.circuit`.

- [ ] Write failing manifest/provider assertions.
- [ ] Run assertions and verify RED.
- [ ] Wire services/config/schemas/docs and bump version to `0.3.0`.
- [ ] Re-run assertions and verify GREEN.

### Task 6: Certification and Cumulative Packaging

**Files:**
- Modify: `release/CERTIFICATION.json`
- Modify: `release/PROVENANCE.json`
- Modify: `release/SBOM.json`
- Regenerate: `release/FILES.sha256`
- Regenerate: `extension.json` integrity map

**Interfaces:**
- Produces Installer 1.7.8 flat-root cumulative ZIP.

- [ ] Run all PHP lint and JSON parsing checks.
- [ ] Run direct Pass 2C executable smoke tests.
- [ ] Run Blueprint v4.2 canonical/production/migration/package gates.
- [ ] Recompute per-file hashes and release metadata.
- [ ] Build ZIP, re-extract, and repeat integrity/canonical validation.
