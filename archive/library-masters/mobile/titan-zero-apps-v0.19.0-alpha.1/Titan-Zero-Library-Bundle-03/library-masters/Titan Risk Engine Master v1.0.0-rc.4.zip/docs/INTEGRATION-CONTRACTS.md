# Integration contracts

## Model Council
Use `risk.gate` before consequential deliberation. Feed disagreement/uncertainty back through `risk.feedback`; Council evidence may tighten authority but cannot loosen it.

## Forge
Use `RiskForgeGateContract::preGeneration()` for BuildSpec governance and `postGeneration()` for generated code/workflow/extension/artifact governance. Generation permission never implies deployment permission.

## Assurance
`REQUIRE_ASSURANCE` routes to Assurance. Passing trusted evidence may release only that exact hold to `EXECUTE_MONITORED` when all circuits remain CLOSED. Risk BLOCK/DENY and stronger constraints remain absolute.

## Shield
Shield evidence is an upper-bound constraint. Blocking evidence produces DENY; failed validation requires at least approval. Shield cannot weaken Risk.

## Command Bus
Command Bus consumes the final execution directive plus `RiskEnforcementReceipt`. `may_dispatch_to_executor=false` means the authoritative executor must not be called. Risk never performs the business mutation and does not require Command Bus to boot.

## Signal
Risk stages canonical events in a durable outbox and dispatches them through the host event contract `titan.signal.ingest`. Delivery is acknowledgement-based by listener presence; missing listeners leave events pending for retry.

## Operational risk budgets
Commercial tiers may affect autonomous exposure or approval cadence but cannot weaken hard safety, legal, privacy, compliance, circuit, or Shield constraints.
