# Blueprint v4.2 alignment report

Baseline: Titan Risk Engine v0.2.2.

Resolved in v0.2.3:
1. Legacy five-field root manifest → Installer 1.7.8 `titan-extension-v1`.
2. Wrapper package → flat-root install ZIP.
3. Governance sidecar schema 1.0 → canonical v2.2.
4. Added explicit architecture/governance/authority/data/service/signal/navigation contracts.
5. Added capability input/output schemas and production documentation.
6. Added `titan:titan-risk-engine:certify` command.
7. Rebased unreleased alpha TIMESTAMP(6) migration to DATETIME(6) for certified MySQL strict mode.
8. Preserved Command Bus as optional consumer-side integration to avoid a circular hard dependency.

Blueprint gaps exported in the companion delta:
- canonical Risk owner identifier drift (`titan-risk` vs `titan-risk-engine`);
- `governance.risk` cannot express `self`;
- generic governed-engine recipe incorrectly hard-wires Command Bus for canonical Risk;
- no dedicated Risk template/recipe despite a Risk architecture profile example.
