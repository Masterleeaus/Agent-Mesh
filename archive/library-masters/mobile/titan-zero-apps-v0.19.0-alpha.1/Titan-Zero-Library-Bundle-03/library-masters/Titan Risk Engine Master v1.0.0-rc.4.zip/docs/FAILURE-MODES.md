# Failure modes

Critical failures include missing trusted tenant/actor context, ledger persistence failure, malformed context, unavailable database, malformed historical scope selectors, invalid time windows, or package integrity mismatch.

Aggregate/velocity storage failure is not a zero-risk result. Consequential consumers must fail closed or reduce authority according to their capability contract.

Velocity reports pressure only. Traffic anomalies must not be promoted to claims of malicious intent without independent evidence from the appropriate security/assurance system.

## Pass 7 runtime isolation

- **Authoritative gate dependency unavailable:** `FailClosedRiskGate` returns `DENY` with `RISK_ENGINE_DEPENDENCY_UNAVAILABLE`; no claimed actor ID is trusted.
- **Recent-activity cache unavailable:** continue with empty telemetry history; durable aggregate/velocity remains authoritative.
- **Signal publisher unavailable/non-acknowledging:** assessment/circuit/feedback remains valid; outbox retries are delayed and bounded.
- **Signal outbox staging unavailable:** do not roll back already-persisted Risk authority/evidence solely for secondary Signal delivery; emit degraded runtime telemetry when possible.
- **Circuit write contention:** row lock + expected state/version check; stale callers fail closed with `STALE_CIRCUIT_VERSION`.
- **Policy write failure:** budget/policy mutation and audit evidence share one transaction on the production binding.
