# Pass 4 — Cross-Engine Governance Integration

## Purpose

Pass 4 makes Risk decisions consumable by the rest of Titan without importing another extension's implementation classes or allowing external systems to weaken hard Risk constraints.

## Integration flow

1. A caller invokes `risk.gate`.
2. Risk performs fresh assessment and circuit evaluation.
3. Risk persists an enforcement receipt before returning.
4. Command Bus or another executor consumes the directive and receipt.
5. Model Council, Assurance, or Shield may return typed evidence through `risk.feedback`.
6. Risk applies deterministic upper-bound rules, persists feedback evidence, issues a replacement enforcement receipt, and stages a Signal event.

## Authority rules

### Model Council
- 70+ disagreement/uncertainty => at least `HOLD_FOR_ASSURANCE`.
- 90+ => at least `HOLD_FOR_APPROVAL`.
- Council never loosens an existing directive.

### Assurance
A passing Assurance result may release only an original `HOLD_FOR_ASSURANCE` caused by `REQUIRE_ASSURANCE`; score must be >=80 and every circuit must remain CLOSED. Release is only to `EXECUTE_MONITORED`. BLOCK/DENY, approval, reduced-authority, and circuit holds remain intact.

### Shield
A blocking Shield result => DENY. A failed non-blocking validation => at least HOLD_FOR_APPROVAL. Shield never loosens Risk.

### Forge
`RiskForgeGateContract` provides:
- `preGeneration()` with `resource_type=forge_build_spec`
- `postGeneration()` restricted to `generated_code`, `generated_workflow`, `generated_extension`, or `generated_artifact`
Generation permission never implies deployment permission.

## Signal delivery

Signal events are staged first in `titan_risk_signal_outbox` with deterministic event IDs. `LaravelRiskSignalPublisher` dispatches to `titan.signal.ingest` only when a listener exists. Unacknowledged events remain pending and can be retried with `titan:titan-risk-engine:dispatch-signals`.

No secret-like metadata or raw caller metadata is copied into Signal payloads.

## Enforcement receipts

`titan_risk_enforcement_receipts` records the tenant, causal lineage, capability, final execution directive, risk score/level, assessment policy, and exact circuit states/versions. `content_digest` provides tamper-evident canonical content identity; it is not a cryptographic signature.

## Failure posture

- Signal unavailable: governance proceeds, event remains pending.
- Receipt persistence failure: provider-grade gate fails rather than returning unrecorded authority.
- Feedback persistence failure: feedback call fails rather than returning unrecorded authority.
- Unknown Forge artifact type: rejected.
- External evidence conflict: stricter directive wins, except the narrow Assurance monitored-release rule.
