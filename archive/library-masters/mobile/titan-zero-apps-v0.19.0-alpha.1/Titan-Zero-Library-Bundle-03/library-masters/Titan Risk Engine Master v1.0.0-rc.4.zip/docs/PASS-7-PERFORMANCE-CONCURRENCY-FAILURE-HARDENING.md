# Pass 7 — Performance, Concurrency & Failure-Mode Hardening

Titan Risk Engine v0.8.0 hardens the runtime path without changing the meaning of existing risk scores, budgets, circuits or governance decisions.

## Fail-closed gate
`RiskGateContract` is now bound to `FailClosedRiskGate`, which decorates the normal gate. Any unhandled authoritative dependency failure produces a deterministic `EXTREME / BLOCK / DENY` result using policy `fail-closed-v1`. Claimed actor identity is not trusted in the fallback result, raw exception messages are not exposed, and a durable DENY receipt is attempted on a best-effort basis.

## Runtime telemetry
Risk gate wall-clock duration and fail-closed events are emitted to a host logger through `RiskRuntimeEventSinkContract`. Telemetry is non-authoritative: logger failure cannot change the decision.

Standalone package benchmark: pure deterministic scorer p99 must be <=5ms. Target-host SLAs are p99 <=50ms for `risk.assess` and p99 <=100ms for `risk.gate`; these remain host-runtime certification items.

## Signal isolation and backpressure
Signal events remain durable through `titan_risk_signal_outbox`, but inline delivery defaults OFF. Publisher non-acknowledgement is recorded as a failed attempt. Pending delivery is bounded by configured batch size, maximum attempts and retry delay so a failed consumer cannot create a hot retry loop.

Signal staging failures do not undo a persisted assessment, circuit transition or governance feedback result. Those failures are recorded as degraded runtime events where a telemetry sink is available.

## Cache degradation
The recent-activity cache is telemetry only. Cache read/write failures return an empty ring buffer or skip the cache write. Aggregate and velocity authority continue to use the durable assessment ledger.

## Concurrency
- Assessment idempotency remains enforced by tenant + idempotency unique constraint; duplicate-key exceptions are explicitly classified before canonical result recovery.
- Circuit writes retain `lockForUpdate()`, optimistic version/state checks and bounded transaction retries.
- Policy/budget write plus policy-change evidence write now run under a shared production transaction runner.
- Transaction retry attempts are configuration bounded to 1–5.
- A 100-request same-idempotency contention model verifies one canonical assessment and one recent-activity write.

## Failure hierarchy
1. Core Risk/ledger/circuit/policy failure: fail closed or throw before authority can be granted.
2. Signal/cache/logging degradation: preserve existing Risk authority, record degradation when possible, retry asynchronously.
3. Command Bus still must never execute without an authorizing Risk result/receipt according to its own integration contract.
