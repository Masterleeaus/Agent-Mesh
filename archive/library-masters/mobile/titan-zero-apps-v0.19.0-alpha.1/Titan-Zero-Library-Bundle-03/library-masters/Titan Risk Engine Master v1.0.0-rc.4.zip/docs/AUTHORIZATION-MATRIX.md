# Authorization matrix

| Surface | Authentication | Authorization | Tenant scope |
|---|---|---|---|
| User overview | `web`,`auth` | authenticated tenant user | derived server-side |
| Admin overview | `web`,`auth`,`admin` | host admin | platform diagnostic |
| `risk.assess` | trusted service/actor context | caller capability policy | mandatory `company_id` |
| `risk.gate` | trusted service/actor context | caller capability policy | mandatory `company_id` |
| `risk.aggregate` / `risk.velocity` | trusted service | read-governance policy | mandatory tenant scope |
| `risk.circuit` | trusted governance service | circuit policy | mandatory tenant/capability scope |
| `risk.feedback` | trusted Council/Assurance/Shield adapter | evidence-source policy | tenant bound to original gate |
| Forge pre/post gates | trusted Forge adapter | same RiskGate policy | mandatory tenant scope |

Actor and tenant authority are resolved server-side; caller metadata cannot mint identity or authority. Feedback evidence cannot weaken hard Risk constraints.
