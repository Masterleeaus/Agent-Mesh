# Data ownership

Titan Risk Engine canonically owns only Risk governance evidence:

- `titan_risk_assessments` — immutable assessment ledger
- `titan_risk_circuits` — current circuit projections
- `titan_risk_circuit_transitions` — append-only circuit evidence
- `titan_risk_signal_outbox` — pending/published Risk Signal envelopes
- `titan_risk_enforcement_receipts` — pre-execution authority evidence
- `titan_risk_governance_feedback` — Council/Assurance/Shield feedback evidence

It does not own business records, Assurance state, Autonomy state, Shield state, Model Council state, Forge artifacts, Signal's canonical event store, or Command Bus execution state. Cross-domain writes are forbidden.

All owned records are tenant-scoped and retained by default on uninstall.
