# Pass 2A — Safety Enforcement Architecture

## Purpose

This pass bridges deterministic single-action scoring to governed pre-execution integration without prematurely implementing aggregate, velocity or circuit-breaker scoring.

## Trusted context boundary

External callers should prefer `RiskGateContract::evaluate(RiskContextInput)`.

`RiskContextInput` is explicitly untrusted. `TrustedRiskContextFactory` resolves:

- actor identity from trusted middleware/authentication
- recent activity from the Risk-owned activity provider
- sanitised metadata with reserved risk/governance keys removed

`RiskManager` re-fetches recent activity and re-sanitises metadata even when an internal caller supplies a `RiskContext`, so caller-provided recent history cannot become authoritative.

## Enforcement routing

Risk does not execute business mutations. It returns a directive:

| Risk decision | Execution directive | Executor dispatch? |
|---|---|---|
| ALLOW | EXECUTE | yes |
| ALLOW_WITH_MONITORING | EXECUTE_MONITORED | yes |
| REQUIRE_ASSURANCE | HOLD_FOR_ASSURANCE | no |
| REQUIRE_APPROVAL | HOLD_FOR_APPROVAL | no |
| REDUCE_AUTHORITY | HOLD_REDUCED_AUTHORITY | no |
| DEFER | HOLD | no |
| BLOCK | DENY | no |

Command Bus remains the authoritative enforcement point.

## Model Council integration shape

Council integration should be two-stage:

1. Pre-deliberation RiskGate evaluates the proposed capability/action.
2. Council deliberates only within the authority allowed by the gate.
3. Council disagreement/uncertainty becomes a structured post-deliberation risk input.
4. Risk/Assurance determine final execution authority.
5. Command Bus enforces the final directive.

This prevents a circular dependency where Risk requires Council output before deciding whether Council may run.

## Forge integration shape

Forge should use two gates:

1. Pre-generation: assess BuildSpec and requested authority/scope.
2. Post-generation: assess the generated artifact together with Shield/Assurance results before deployment/provisioning.

Generation itself does not imply permission to deploy.

## Recent activity

The provider records the last N assessments per tenant + actor with:

- trace_id
- capability
- action
- score
- level
- decision
- assessed_at

This history is telemetry only in v0.2.1. It is intentionally excluded from scoring until aggregate/velocity policy is implemented and tested.

## Metadata safety

Risk metadata cannot override authoritative fields such as:

- company_id
- actor identity
- trace lineage
- recent activity
- risk score/level
- decision/directive
- policy version

Objects/resources are discarded, strings are bounded, nesting is bounded and total entries are capped.

## Deferred to Pass 2B+

- durable risk ledger expansion
- idempotency key
- hour/day query buckets
- aggregate exposure
- velocity intelligence
- circuit state
- Council disagreement adapter
- Command Bus cross-extension enforcement test
- Forge cross-extension feedback test
- Assurance/Shield handshake adapters
