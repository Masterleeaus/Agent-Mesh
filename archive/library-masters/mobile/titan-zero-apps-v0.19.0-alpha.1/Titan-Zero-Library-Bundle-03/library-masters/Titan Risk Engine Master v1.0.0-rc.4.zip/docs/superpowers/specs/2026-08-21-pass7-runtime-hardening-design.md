# Titan Risk Engine Pass 7 Runtime Hardening Design

## Goal
Harden Risk v0.7.0 for load, concurrency and dependency failure without weakening governance semantics.

## Runtime invariants
1. `risk.gate` fails closed when an internal dependency throws: directive `DENY`, score 100, level `EXTREME`, decision `BLOCK`, structured `RISK_ENGINE_DEPENDENCY_UNAVAILABLE` reason.
2. Fail-closed fallback never trusts claimed actor identity to grant authority; fallback actor ID is null.
3. Signal delivery is off the synchronous assessment path by default. Assessments stage the durable outbox only; delivery is command/worker driven unless an explicit opt-in enables inline dispatch.
4. Signal retries are bounded and delayed. Non-acknowledgement counts as a failed attempt rather than immediate hot-loop retry.
5. Cache/recent-activity failure is soft because aggregate/velocity authority comes from the durable ledger; cache failure returns no recent telemetry and never increases authority.
6. Circuit mutation remains row-locked and transaction retry count becomes governed configuration.
7. Policy/budget write + policy-change evidence write execute in one database transaction on the production binding.
8. Idempotency unique-key contention is distinguished from unrelated database errors before returning an existing result.
9. Engine-internal deterministic scoring benchmark is measured independently of host DB/network latency. Host SLA remains a host-runtime certification gate.

## Performance budgets
- Pure deterministic scorer p99 target: <= 5 ms on certification host used for package build.
- `risk.assess` host target: p99 <= 50 ms, measured on target host (NOT_RUN in standalone package).
- `risk.gate` host target: p99 <= 100 ms, measured on target host (NOT_RUN in standalone package).
- Signal inline delivery default: disabled.
- Signal dispatch batch: <= 100; retry delay >= 30 seconds; max attempts <= 20 by default.

## Concurrency strategy
- Assessment idempotency: database unique key is authoritative; duplicate-key collision returns canonical existing assessment.
- Circuit state: `lockForUpdate()` + optimistic state/version check + bounded DB transaction retries.
- Policy governance: shared connection transaction wraps policy/budget record and evidence write.
- No semantic retry of business execution is introduced by Risk.
