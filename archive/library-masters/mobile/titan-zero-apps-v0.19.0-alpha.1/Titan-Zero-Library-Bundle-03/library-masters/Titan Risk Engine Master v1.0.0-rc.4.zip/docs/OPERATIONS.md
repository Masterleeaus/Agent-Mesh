# Operations

Single-action assessment, gate evaluation, feedback application, and circuit transitions are synchronous governance operations. Aggregate and velocity are synchronous read-only queries against `titan_risk_assessments` using indexed UTC `assessed_at` boundaries.

Canonical aggregate windows: 60, 240 and 1440 minutes. Canonical velocity windows: 5, 15 and 60 minutes.

Recent activity in cache is non-authoritative enrichment only; aggregate/velocity never trust caller-submitted activity history. The extension has no queue consumers or schedules in v0.5.0. Circuit transitions use database row locking and optimistic version checks.

Signal events are staged durably in `titan_risk_signal_outbox`. Normal calls attempt a small synchronous flush; operators may retry pending delivery with:

`php artisan titan:titan-risk-engine:dispatch-signals --limit=100`

A missing `titan.signal.ingest` listener leaves events pending rather than discarding them.

If ledger history is unavailable, consequential consumers must treat historical Risk intelligence as unavailable/fail-closed or reduce authority according to capability policy. If enforcement-receipt persistence fails, a provider-grade gate must fail rather than return unrecorded execution authority.

## Pass 7 runtime controls

`config/titan-risk-engine.php` now exposes:

- `runtime.risk_assess_target_ms = 50`
- `runtime.risk_gate_target_ms = 100`
- `runtime.database_transaction_attempts = 3` (bounded 1–5)
- `integration.inline_signal_dispatch = false`
- `integration.signal_dispatch_max_batch = 100`
- `integration.signal_retry_delay_seconds = 30`
- `integration.signal_max_attempts = 20`

Keep inline Signal dispatch disabled in production unless the Signal consumer is explicitly proven to be local, bounded and non-blocking. The recommended operational path is durable outbox staging plus `titan:titan-risk-engine:dispatch-signals` from a controlled worker/schedule.
