# Pass 6 — Risk Control Centre & Policy Operations UI

Titan Risk Engine v0.7.0 introduces a host-facing operational console without moving governance authority into the UI layer.

## Read boundary

`RiskControlCentreContract` provides bounded, tenant-scoped read models for:

- 24-hour aggregate exposure;
- 15-minute operational velocity;
- current operational budget;
- capability-specific effective policy and policy digest;
- circuit state;
- Signal outbox health;
- enforcement receipts;
- recent assessments;
- immutable policy change history;
- budget versions and policy overlays.

`DatabaseRiskControlCentre` is the only UI read service that queries Risk-owned tables. Every list query is explicitly bounded. Controllers do not query tables.

## Tenant isolation

The administrator console requires an explicit `company_id`. The authenticated-user console derives tenant context from `company_id` or, for host compatibility, `company_id` on the authenticated user. If no tenant context can be resolved, no Risk data is displayed.

The user console is read-only.

## Policy operations

Administrator forms invoke `RiskPolicyGovernanceService` for:

- scheduling a new immutable budget version;
- scheduling a governed policy overlay;
- scheduling a budget rollback as a new version;
- scheduling a policy rollback as a new version.

Historical versions are never edited in place. Each operation creates `RiskPolicyChangeEvidence` with actor identity, reason, trace, correlation and causation IDs.

The UI cannot lower the engine's hard safety floor because effective policy resolution retains the non-weakenable baseline from Pass 5.

## Signal recovery

The administrator can request delivery of pending Risk Signal outbox records through `RiskSignalDispatcher`. Failed or unacknowledged events remain durable in the outbox.

## Host view compatibility

Risk views extend `panel.layout.app` instead of relying on a `<x-layouts.app>` component. This matches the MagicAI panel layout pattern used by Titan host-compatible extensions.

## Enforcement boundary

The Control Centre is not an execution authority. It cannot:

- bypass an OPEN circuit;
- convert a Risk denial into an allow;
- mutate business-domain records;
- edit historical policy versions;
- grant autonomy or Assurance.

Command Bus remains the executor, while Risk remains the source of risk constraints and enforcement receipts.
