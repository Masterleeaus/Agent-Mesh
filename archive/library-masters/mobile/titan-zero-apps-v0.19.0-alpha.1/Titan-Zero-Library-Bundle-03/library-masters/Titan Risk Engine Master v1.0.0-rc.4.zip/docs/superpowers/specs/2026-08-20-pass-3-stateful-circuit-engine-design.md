# Pass 3 Stateful Circuit Engine Design

## Goal

Make `risk.circuit` a real Risk-owned governance capability without granting Risk authority to execute business mutations.

## Boundaries

- State scopes: tenant and tenant+capability.
- Source data: durable Risk assessment history only.
- States: CLOSED, OPEN, HALF_OPEN.
- Normal executor dispatch: CLOSED only.
- Recovery: supervised probes only; two successes minimum.
- Concurrency: transaction + row lock + expected state/version.
- Evidence: append-only transition record with trace/correlation/causation lineage.
- Timeout semantics: never auto-close; HALF_OPEN expiry re-opens.
- Tenant-wide opening uses a stronger threshold than capability-scoped opening.

## Enforcement

RiskGate evaluates tenant and tenant+capability circuits after the current assessment is durably recorded. OPEN maps to DENY. HALF_OPEN maps to HOLD_FOR_ASSURANCE. Command Bus remains responsible for obeying the directive and performing any authoritative domain mutation.
