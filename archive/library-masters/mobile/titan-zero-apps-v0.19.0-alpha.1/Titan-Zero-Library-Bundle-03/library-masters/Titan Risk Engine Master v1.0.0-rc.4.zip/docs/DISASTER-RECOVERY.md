# Disaster recovery

Back up `titan_risk_assessments` with the host database. Target RPO: 60 minutes; RTO: 240 minutes. After restore, verify tenant isolation, idempotency uniqueness, row counts, latest policy versions and ledger hydration before returning RiskGate to readiness.
