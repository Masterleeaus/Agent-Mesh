# Pass 3 Stateful Circuit Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Activate persistent, concurrency-safe Risk circuits and integrate them into RiskGate.

**Architecture:** Risk owns circuit state and transition evidence; aggregate/velocity supply trusted historical pressure; RiskGate consumes circuit state; Command Bus remains the executor. Recovery is hysteretic and supervised.

**Tech Stack:** PHP 8.2+, Laravel 10 database/query builder, MySQL-compatible migrations, JSON Schema 2020-12.

**Spec:** `docs/superpowers/specs/2026-08-20-pass-3-stateful-circuit-engine-design.md`

## Global Constraints

- Preserve `company_id` tenant boundary.
- Never infer malicious intent from velocity.
- Never auto-close an OPEN/HALF_OPEN circuit due only to elapsed time.
- Do not introduce required Command Bus dependency.
- Persist full trace/correlation/causation transition evidence.
- Keep normal business-state mutation outside Risk.

---

### Task 1: Circuit state domain model
- [x] Add circuit scope/key/snapshot/evidence types.
- [x] Add deterministic `circuit-v1` hysteresis policy.
- [x] Prove CLOSED→OPEN→HALF_OPEN→CLOSED and failure paths in executable smoke tests.

### Task 2: Durable atomic store
- [x] Add circuit and transition-evidence tables.
- [x] Add unique tenant/scope/capability identity.
- [x] Use transaction + `lockForUpdate()` + version/state comparison.
- [x] Fail stale writers with `STALE_CIRCUIT_VERSION`.

### Task 3: Public capability and RiskGate enforcement
- [x] Add `RiskCircuitContract`/service backed by aggregate+velocity history.
- [x] Add schemas and advertise `risk.circuit`.
- [x] Map OPEN to DENY and HALF_OPEN to HOLD_FOR_ASSURANCE.
- [x] Keep Command Bus optional.

### Task 4: Certification
- [x] Update provider/config/version/docs/certification command.
- [x] Run Pass 2C regression and Pass 3 smoke tests.
- [x] Run PHP lint, JSON parse, Blueprint canonical validator, package scan, architecture scan, MySQL scan and migration-stability scan.
- [x] Seal final ZIP, regenerate Installer integrity map and verify the re-extracted archive.
