# Upgrade

## v1.0.0-rc.3 navigation hierarchy rule

Upgrade from rc.2 to rc.3 to collapse Titan Risk navigation to one top-level parent. Provider boot re-synchronizes the existing host rows so `Titan Risk` remains the only top-level item and `Risk Control Centre` becomes its child. The legacy admin root URL remains a redirect to the canonical Control Centre route.

Use forward-compatible expand/migrate/contract migrations. Existing applied migrations are frozen after production release. v0.2.3 rebases the unreleased alpha migration timestamp precision from `timestamp(...,6)` to `dateTime(...,6)` for certified MySQL strict-mode compatibility.

## v1.0.0-rc.2 host-upgrade rule

The release candidate deliberately does **not** claim automatic recovery from an arbitrary interrupted MySQL DDL sequence (`database.interrupted_migration_recovery=false`). Installer 1.7.8 must run under its migration lock. If the host reports a mid-migration interruption, inspect the exact schema state before retrying rather than repeatedly invoking the migration blindly. The bundled certification command verifies the resulting nine-table/critical-column contract after migration.
