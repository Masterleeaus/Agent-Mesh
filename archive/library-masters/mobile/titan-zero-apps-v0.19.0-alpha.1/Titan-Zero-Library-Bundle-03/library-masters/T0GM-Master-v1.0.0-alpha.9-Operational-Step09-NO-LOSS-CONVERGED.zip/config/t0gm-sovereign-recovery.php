<?php
return [
    'enabled' => true,
    'authority' => 'titan.god_mode',
    'principal_id' => 'OWNER_CONTROL_PLANE_PRINCIPAL',
    'quorum' => 2,
    'clock_skew_seconds' => 30,
    'recovery_root_purpose' => 'sovereign_recovery_only',
    'witness_role' => 'recovery_witness',
    'ai_can_count_toward_quorum' => false,
    'result' => 'replacement-device-binding-only',
    'requires_normal_identity_proof_after_enrollment' => true,
    'authority_semantics' => 'recovery-restores-access-but-never-transfers-sovereignty',
];
