<?php
return [
    'enabled'=>true,
    'fail_closed_for_current_use'=>true,
    'preserve_pre_quarantine_history'=>true,
    'sibling_devices_inherit_quarantine'=>false,
    'quarantine_destroys_sovereign_identity'=>false,
    'continuance_effect'=>'terminate-originating-device-authority',
];
