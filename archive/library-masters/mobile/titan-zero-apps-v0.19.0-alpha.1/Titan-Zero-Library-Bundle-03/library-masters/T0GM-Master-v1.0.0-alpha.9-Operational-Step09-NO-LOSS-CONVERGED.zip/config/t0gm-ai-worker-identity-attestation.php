<?php
return [
    'schema' => 'titan.t0gm.ai-worker-identity-attestation.v1',
    'company_boundary' => 'company_id',
    'canonical_registry' => 'Titan\\GodMode\\Workforce\\T0gmCanonicalAiWorkforceRegistry',
    'attestor' => 'Titan\\GodMode\\Workforce\\T0gmAiWorkerIdentityAttestor',
    'requires_cryptographic_workload_identity' => true,
    'requires_runtime_integrity_valid' => true,
    'binds_model_provider_to_registry' => true,
    'identity_evidence_only' => true,
    'authority_granted' => false,
    'execution_authority_granted' => false,
    't0gm_authority_granted' => false,
];
