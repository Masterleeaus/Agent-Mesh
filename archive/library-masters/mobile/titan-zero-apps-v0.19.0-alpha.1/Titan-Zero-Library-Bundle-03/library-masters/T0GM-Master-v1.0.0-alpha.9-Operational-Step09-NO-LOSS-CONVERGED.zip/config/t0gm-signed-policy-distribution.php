<?php
return [
    'schema'=>'titan.t0gm.signed-policy-distribution.config.v1',
    'supported_policy_classes'=>['constitution','policy','overlay','configuration'],
    'signature_suite'=>'ed25519',
    'anti_rollback'=>true,
    'same_revision_equivocation'=>'deny',
    'company_scope_boundary'=>'company_id',
    'network_location_is_authority'=>false,
    'signature_grants_authority'=>false,
    'verified_distribution_is_policy_authority'=>false,
    'notes'=>[
        'A valid signature establishes origin and integrity only.',
        'Policy scope, constitutional precedence, capability authority and execution authority remain independently governed.',
        'Retired verification keys may preserve historical verification only inside their trusted evidence interval.',
    ],
];
