<?php
return [
    'enabled'=>true,
    'production_require_provenance'=>true,
    'signing_purpose'=>'event_provenance',
    'required_suites'=>['ed25519'],
    'trust_store_source'=>'deployment-managed',
    'authority_semantics'=>'provenance-only-not-execution-authority',
];
