<?php
return [
  'schema'=>'titan.t0gm.causal-blast-radius.config.v1',
  'enabled'=>true,
  'causal_edge_types'=>['causes','parent_of','depends_on','triggers','propagates_to'],
  'non_causal_edge_types'=>['correlates_with'],
  'max_depth'=>64,
  'analysis_only'=>true,
  'invariants'=>[
    'forecast_and_observation_remain_distinct',
    'correlation_does_not_propagate_blast_radius',
    'causal_cycles_fail_closed',
    'cross_company_analysis_does_not_create_cross_company_authority',
    'blast_radius_analysis_does_not_grant_t0gm_company_or_execution_authority',
  ],
];
