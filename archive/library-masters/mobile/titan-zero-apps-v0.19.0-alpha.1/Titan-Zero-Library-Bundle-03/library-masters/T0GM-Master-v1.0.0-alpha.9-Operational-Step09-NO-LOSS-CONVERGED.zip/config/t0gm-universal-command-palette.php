<?php
return ['schema'=>'titan.t0gm.command_palette.config.v1','target_types'=>['company','system','agent','workflow','infrastructure'],'company_boundary'=>'company_id','inspection'=>'projection_only','command_issue'=>'governed_intent_only','execution_authority_granted'=>false];
