<?php
return [
    'profile'=>'t0gm-hybrid-pqc-v1',
    'required_kem'=>'ml-kem-768',
    'production'=>[
        'classical_only_fallback'=>false,
        'unknown_kem_fail_closed'=>true,
        'private_kem_material_in_application_payloads'=>false,
        'company_authority_from_channel_crypto'=>false,
    ],
    'provider'=>[
        'type'=>'openssl-3.5+-adapter',
        'private_key_reference_only'=>true,
        'recommended_production_custody'=>'HSM/OS-brokered opaque reference',
    ],
];
