<?php
return [
    'schema' => 'titan.t0gm.sovereign-audit-store-config.v1',
    'backend' => 'independent-append-only-filesystem',
    'log_name' => 'sovereign-audit.jsonl',
    'checkpoint_directory' => 'checkpoints',
    'record_signature_suite' => 'ed25519',
    'checkpoint_policy' => 'signed-create-only-per-record',
    'required_semantics' => [
        'application_database_is_not_audit_authority' => true,
        'sequence_owned_by_audit_store' => true,
        'hash_chain_required' => true,
        'signed_record_provenance_required' => true,
        'tail_truncation_detection_required' => true,
        'audit_evidence_grants_authority' => false,
    ],
];
