<?php
return [
    'profile'=>'t0gm-hybrid-pqc-v1',
    'required_classical_kex'=>'x25519',
    'required_pq_kem'=>'ml-kem-768',
    'combiner'=>'hkdf-sha256-transcript-bound-v1',
    'production'=>[
        'fail_closed'=>true,
        'classical_only_allowed'=>false,
        'pq_only_allowed'=>false,
        'silent_downgrade_allowed'=>false,
        'session_crypto_grants_authority'=>false,
    ],
];
