<?php
return [
    /*
     * Titan God Mode is a separate non-tenant principal class.
     * No private signing key is configured here or anywhere in the normal tenant runtime.
     */
    'authority' => 'titan.god_mode',
    'principal_class' => 'builder_control_plane_principal',
    'principal_id' => getenv('TITAN_GOD_MODE_PRINCIPAL_ID') ?: 'OWNER_CONTROL_PLANE_PRINCIPAL',
    'audience' => getenv('TITAN_GOD_MODE_AUDIENCE') ?: 'titan-builder-control-plane',
    'clock_skew_seconds' => 30,

    /*
     * Public verification keys only.
     * Production keys should come from an isolated root/HSM/offline control-plane process.
     * Never put root/device private keys in Laravel env, DB, queue payloads, sessions, logs or code.
     */
    'root_public_keys' => [
        // 'gm-root-2026-01' => 'BASE64_ED25519_PUBLIC_KEY'
    ],

    /*
     * Optional allow-list for explicitly registered God Mode devices.
     * A root-signed device certificate is still mandatory even when listed here.
     */
    'allowed_device_key_ids' => [],



    /*
     * Step 11 verifier-only T0GM cryptographic identity roots.
     * Entries are public verification material plus explicit algorithm metadata.
     * Example: 't0gm-root-01' => ['suite'=>'ed25519','public_key'=>'BASE64_PUBLIC_KEY']
     */
    'identity_root_verifiers' => [],

    /*
     * Independently trusted hardware-attestation verifier keys.
     * A device assertion is not hardware-backed merely because application code says it is.
     */
    'hardware_attestation_verifiers' => [],

    'crypto_suites' => [
        'active_reference' => 'ed25519',
        'unknown_suite_policy' => 'fail_closed',
        'future_hybrid_and_pqc_adapters' => true,
    ],

    'forbidden_role_markers' => [
        'titan.god_mode',
        'god_mode',
        'god-mode',
        'godmode',
        'builder_control_plane',
        'builder-control-plane'
    ],

    /*
     * Company-affecting God Mode actions must explicitly name company_id.
     * Platform-global operations may use a purpose-bound global scope instead.
     */
    'require_company_target_for_company_actions' => true,
];
