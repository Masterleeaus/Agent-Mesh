<?php
return [
 'schema'=>'titan.t0gm.live-capability-reevaluation.config.v1',
 'mode'=>'world-state-driven',
 'reevaluate_all_non_terminated'=>true,
 'time_is_evidence_not_authority'=>true,
 'allowed_outcomes'=>['continue','narrow','pause','transform','terminate'],
 'transformation_requires_fresh_sovereign_authorization'=>true,
 'authority_expansion_by_reevaluator'=>false,
 'company_boundary'=>'company_id',
 'legacy_tenant_boundaries_forbidden'=>true,
];
