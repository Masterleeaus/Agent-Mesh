<?php
return [
    'schema' => 'titan.t0gm.dynamic_intelligence_view.v1',
    'canonical_persistent_views' => ['security','money','workforce','environment','customers','infrastructure','critical'],
    'temporary_views_require_extinction_conditions' => true,
    'company_boundary' => 'company_id',
    'projection_only' => true,
    'execution_authority_granted' => false,
];
