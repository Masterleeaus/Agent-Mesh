<?php
return [
 'schema'=>'titan.t0gm.ai-workforce-capability-manifest.v1',
 'company_boundary'=>'company_id',
 'capability_classes'=>['observe','reason','recommend','request','execute'],
 'self_modifiable'=>false,
 'authority_self_escalation_allowed'=>false,
 'execution_requires_governed_authorization'=>true,
 'manifest_is_declarative'=>true,
];
