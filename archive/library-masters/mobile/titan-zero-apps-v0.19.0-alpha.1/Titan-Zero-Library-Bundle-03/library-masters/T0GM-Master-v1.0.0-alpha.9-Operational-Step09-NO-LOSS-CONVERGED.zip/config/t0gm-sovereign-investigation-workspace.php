<?php
return [
    'schema' => 'titan.t0gm.sovereign-investigation-workspace.v1',
    'company_boundary' => 'company_id',
    'sections' => ['timeline','evidence','causal_graph','decisions','identities','capabilities','current_state'],
    'projection_only' => true,
    'grants_authority' => false,
    'execution_authority_granted' => false,
    'modifies_source_state' => false,
];
