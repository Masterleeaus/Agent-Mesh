<?php
return [
    'enabled'=>true,
    'production_require_for_privileged_execution'=>true,
    'identity_source'=>'cryptographic-workload-identity',
    'trust_network_location'=>false,
    'required_measurements'=>['code_digest','config_digest','environment_digest'],
    'attestation_purpose'=>'runtime_integrity_attestation',
    'fail_closed_on'=>['unknown_policy','policy_revision_mismatch','code_drift','config_drift','environment_drift','required_claim_mismatch','signature_failure','replay','workload_binding_mismatch'],
    'authority_semantics'=>'integrity-evidence-only-not-sovereign-or-company-authority',
];
