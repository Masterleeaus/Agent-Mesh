<?php
return [
    'schema' => 'titan.t0gm.canonical-ai-workforce-registry.v1',
    'company_boundary' => 'company_id',
    'canonical_owner' => 'Titan\\GodMode\\Workforce\\T0gmCanonicalAiWorkforceRegistry',
    'entity_kinds' => ['worker','specialist','team','model','autonomous_service'],
    'lifecycle_states' => ['registered','active','restricted','quarantined','suspended','retired'],
    'identity_catalog_only' => true,
    'authority_granted' => false,
    'execution_authority_granted' => false,
    'legacy_sources' => [
        'Titan\\GodMode\\Oversight\\T0gmOversightSpecialist' => 'specialist taxonomy compatibility source only',
        'Titan\\GodMode\\Workload\\T0gmWorkloadIdentityRegistry' => 'workload cryptographic identity evidence source only',
        'Titan\\GodMode\\Command\\T0gmCommandTargetRegistry' => 'command target discovery source only',
    ],
];
