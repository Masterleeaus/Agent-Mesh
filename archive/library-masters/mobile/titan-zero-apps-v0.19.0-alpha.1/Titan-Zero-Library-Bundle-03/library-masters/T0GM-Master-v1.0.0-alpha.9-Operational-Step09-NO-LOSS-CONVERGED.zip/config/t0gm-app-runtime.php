<?php
return [
 'app_id'=>'t0gm',
 'app_class'=>'sovereign_advanced_intelligence_control_plane',
 'command_types'=>['inspect','propose','execute_request','supersede_request','contain_request'],
 'navigation'=>[
  ['route_id'=>'home','label'=>'Home','path'=>'/','requires'=>[]],
  ['route_id'=>'activity','label'=>'Activity','path'=>'/activity','requires'=>['feed.read']],
  ['route_id'=>'investigate','label'=>'Investigate','path'=>'/investigate','requires'=>['investigation.read']],
  ['route_id'=>'workforce','label'=>'AI Workforce','path'=>'/workforce','requires'=>['workforce.read']],
  ['route_id'=>'infrastructure','label'=>'Infrastructure','path'=>'/infrastructure','requires'=>['infrastructure.read']],
 ],
 'invariants'=>[
  'company_id_is_only_company_boundary'=>true,
  'session_does_not_grant_execution_authority'=>true,
  'command_surface_emits_intent_only'=>true,
  'quarantined_device_blocks_commands'=>true,
 ],
];
