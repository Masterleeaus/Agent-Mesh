<?php
return [
    // Must identify the same logical replay domain on every accepting node.
    'replay_domain' => getenv('T0GM_REPLAY_DOMAIN') ?: 't0gm-sovereign-global-v1',
    // Production requires >=32 bytes of secret material distributed consistently
    // through an approved secret/KMS mechanism. Never commit the real value.
    'digest_pepper_env' => 'T0GM_NONCE_DIGEST_PEPPER',
    'require_distributed_backend' => true,
    'production_backend' => 'pdo-shared-strong-consistency',
    'table' => 't0gm_nonce_claims',
    'fail_closed_on_backend_error' => true,
    'raw_nonce_persistence' => false,
];
