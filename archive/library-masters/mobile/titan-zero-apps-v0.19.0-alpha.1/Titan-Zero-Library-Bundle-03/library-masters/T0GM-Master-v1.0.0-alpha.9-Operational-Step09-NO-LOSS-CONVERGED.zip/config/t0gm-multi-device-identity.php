<?php
return [
    'schema' => 'titan.t0gm.multi_device_identity.v1',
    'authority_class' => 'titan.god_mode',
    'membership_is_identity_evidence_only' => true,
    'company_authority_embedded' => false,
    'application_role_authority' => false,
    'require_independent_device_public_key' => true,
    'require_hardware_attestation_per_device' => true,
    'require_unique_binding_id' => true,
    'statuses' => ['active','retired','revoked'],
    'historical_verification' => [
        'retired_bindings' => 'allowed-before-retirement-boundary',
        'revoked_bindings' => 'allowed-before-revocation-boundary',
    ],
];
