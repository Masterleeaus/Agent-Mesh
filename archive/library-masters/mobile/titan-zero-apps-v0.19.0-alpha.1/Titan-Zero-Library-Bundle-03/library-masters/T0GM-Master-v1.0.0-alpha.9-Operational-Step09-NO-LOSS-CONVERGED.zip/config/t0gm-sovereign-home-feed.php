<?php
return [
    'schema' => 'titan.t0gm.sovereign_home_feed.v1',
    'sovereign_only' => true,
    'rank_factors' => ['risk','consequence','anomaly','confidence','urgency'],
    'default_limit' => 100,
    'maximum_limit' => 1000,
    'live_cursor' => 'audit_sequence',
    'projection_only' => true,
    'execution_authority_granted' => false,
    'invariants' => [
        'all_governed_activity_visible_to_t0gm' => true,
        'company_id_is_only_company_boundary' => true,
        'ranking_never_mutates_source_event' => true,
        'ranking_never_grants_authority' => true,
        'low_confidence_cannot_suppress_material_risk' => true,
    ],
];
