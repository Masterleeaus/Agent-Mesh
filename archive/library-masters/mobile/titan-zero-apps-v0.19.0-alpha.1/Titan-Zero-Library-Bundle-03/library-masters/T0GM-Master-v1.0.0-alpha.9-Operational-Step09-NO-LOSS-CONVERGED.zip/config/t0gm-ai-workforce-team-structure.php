<?php
return [
 'schema'=>'titan.t0gm.ai-workforce-team.v1',
 'roles'=>['specialist','supervisor','challenger','investigator','coordinator','member'],
 'team_types'=>['persistent','temporary_mission'],
 'authority_aggregated'=>false,
 'member_authority_transferred'=>false,
 'temporary_missions_require_extinction_conditions'=>true,
];
