<?php
return [
    'schema'=>'titan.t0gm.independent-evidence-anchoring.config.v1',
    'enabled'=>true,
    'criticality_policy'=>[
        'anchor_levels'=>['critical','extreme'],
        'anchor_on'=>['sovereign_decision','privileged_execution','device_compromise','recovery','policy_change','irreversible_action'],
        'batching_allowed_for_below_critical'=>true,
    ],
    'provider'=>[
        'contract'=>'Titan\\GodMode\\Anchor\\IndependentEvidenceAnchorProvider',
        'reference_adapter'=>'Titan\\GodMode\\Anchor\\FileIndependentEvidenceAnchorProvider',
        'production_requirement'=>'Use an independently administered trust/storage domain; do not colocate authority for Titan audit mutation and external anchor mutation.',
    ],
    'receipt'=>[
        'signature_suite'=>'ed25519',
        'binds'=>['provider_id','audit_sequence','record_hash','checkpoint_digest','checkpoint_signature_digest','previous_anchor_hash'],
        'authority_semantics'=>'evidence-only',
    ],
    'invariants'=>[
        'external_anchor_does_not_grant_t0gm_authority',
        'external_anchor_does_not_grant_company_authority',
        'external_anchor_does_not_grant_execution_authority',
        'network_location_is_not_anchor_trust',
        'anchor_signing_key_is_distinct_from_titan_audit_signing_key',
        'historical_verification_survives_titan_application_or_database_compromise',
    ],
];
