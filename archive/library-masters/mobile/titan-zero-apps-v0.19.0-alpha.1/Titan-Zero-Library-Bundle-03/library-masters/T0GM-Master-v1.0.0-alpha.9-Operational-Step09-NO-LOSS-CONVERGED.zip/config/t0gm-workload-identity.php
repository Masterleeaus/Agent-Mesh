<?php
return [
    'enabled'=>true,
    'identity_classes'=>['server','service','container','workload'],
    'network_location_is_identity'=>false,
    'require_self_signature'=>true,
    'require_independent_attestation'=>true,
    'require_replay_protection'=>true,
    'authority_semantics'=>'identity-evidence-only-not-t0gm-or-company-authority',
];
