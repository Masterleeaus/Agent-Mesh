-- T0GM Step 02 distributed replay claim store.
-- Deploy this table into ONE logically shared, strongly consistent database
-- visible to every T0GM proof-verification node/region.
CREATE TABLE t0gm_nonce_claims (
    nonce_key CHAR(64) PRIMARY KEY,
    expires_at BIGINT NOT NULL,
    claimed_at BIGINT NOT NULL,
    metadata_json TEXT NOT NULL
);
CREATE INDEX t0gm_nonce_claims_expires_idx ON t0gm_nonce_claims (expires_at);
