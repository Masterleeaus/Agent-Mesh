CREATE TABLE IF NOT EXISTS t0gm_feed_events (
    audit_sequence INTEGER PRIMARY KEY,
    event_id VARCHAR(160) NOT NULL UNIQUE,
    event_hash CHAR(64) NOT NULL,
    previous_record_hash CHAR(64) NULL,
    record_hash CHAR(64) NOT NULL UNIQUE,
    company_scope VARCHAR(32) NOT NULL,
    company_id VARCHAR(160) NULL,
    event_kind VARCHAR(64) NOT NULL,
    trace_id VARCHAR(160) NOT NULL,
    correlation_id VARCHAR(160) NOT NULL,
    attention_tier VARCHAR(32) NOT NULL,
    event_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_t0gm_feed_company ON t0gm_feed_events(company_scope, company_id, audit_sequence);
CREATE INDEX IF NOT EXISTS idx_t0gm_feed_corr ON t0gm_feed_events(correlation_id, audit_sequence);
CREATE INDEX IF NOT EXISTS idx_t0gm_feed_trace ON t0gm_feed_events(trace_id, audit_sequence);
CREATE INDEX IF NOT EXISTS idx_t0gm_feed_kind ON t0gm_feed_events(event_kind, audit_sequence);
CREATE INDEX IF NOT EXISTS idx_t0gm_feed_attention ON t0gm_feed_events(attention_tier, audit_sequence);

CREATE TABLE IF NOT EXISTS t0gm_feed_causal_edges (
    edge_id CHAR(64) PRIMARY KEY,
    from_event_id VARCHAR(160) NOT NULL,
    to_event_id VARCHAR(160) NOT NULL,
    edge_type VARCHAR(32) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_t0gm_causal_from ON t0gm_feed_causal_edges(from_event_id, edge_type);
CREATE INDEX IF NOT EXISTS idx_t0gm_causal_to ON t0gm_feed_causal_edges(to_event_id, edge_type);

CREATE TABLE IF NOT EXISTS t0gm_feed_evidence_refs (
    event_id VARCHAR(160) NOT NULL,
    evidence_id VARCHAR(200) NOT NULL,
    evidence_type VARCHAR(120) NOT NULL,
    source VARCHAR(200) NOT NULL,
    content_hash VARCHAR(200) NULL,
    provenance_ref VARCHAR(500) NULL,
    PRIMARY KEY (event_id, evidence_id)
);
CREATE INDEX IF NOT EXISTS idx_t0gm_evidence_id ON t0gm_feed_evidence_refs(evidence_id, event_id);
