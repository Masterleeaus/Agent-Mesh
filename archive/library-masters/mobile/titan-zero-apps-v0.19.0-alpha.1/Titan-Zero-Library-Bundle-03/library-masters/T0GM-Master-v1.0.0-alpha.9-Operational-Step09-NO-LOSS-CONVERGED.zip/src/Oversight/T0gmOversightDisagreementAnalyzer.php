<?php
namespace Titan\GodMode\Oversight;
use Titan\GodMode\Security\CanonicalJson;
final class T0gmOversightDisagreementAnalyzer
{
    public function analyze(T0gmOversightReviewSet $set): array {
        $a=$set->assessments; $groups=[]; $fingerprints=[];
        foreach($a as $x){$groups[$x->disposition][]=$x->specialist; $fp=hash('sha256',CanonicalJson::encode([$x->disposition,$x->reasonCodes,$x->evidenceRefs])); $fingerprints[$fp][]=$x->specialist;}
        $material=count($groups)>1; $collusion=[]; foreach($fingerprints as $fp=>$members) if(count($members)>=3) $collusion[]=['fingerprint'=>$fp,'specialists'=>$members,'reason'=>'suspiciously-identical-independent-review-output'];
        return ['schema'=>'titan.t0gm.oversight-disagreement-analysis.v1','event_id'=>$set->eventId,'material_disagreement'=>$material,'disposition_groups'=>$groups,'minority_positions'=>array_values(array_filter($groups,fn($g)=>count($g)<count($a)/2)),'collusion_signals'=>$collusion,'consensus_does_not_create_authority'=>true,'disagreement_preserved'=>true];
    }
}
