<?php
namespace Titan\GodMode\Recovery;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

/**
 * Sovereign recovery restores device access to the SAME T0GM principal.
 * Recovery witnesses attest to the recovery event but never receive or exercise
 * T0GM sovereignty. A separately registered user-controlled recovery root must
 * prove continuity before a replacement device binding can be authorized.
 */
final class T0gmSovereignRecoveryService
{
    private array $recoveryRoots=[];
    private array $participants=[];

    public function __construct(
        private readonly T0gmCryptoSuiteRegistry $crypto,
        private readonly NonceStore $nonces,
        private readonly array $policy,
        array $recoveryRoots,
        array $participants
    ) {
        $quorum=(int)($policy['quorum']??0);
        if($quorum<1) throw new \InvalidArgumentException('invalid-sovereign-recovery-quorum');
        foreach(['authority','principal_id'] as $required){
            if(trim((string)($policy[$required]??''))==='') throw new \InvalidArgumentException('invalid-sovereign-recovery-policy:'.$required);
        }

        foreach($recoveryRoots as $keyId=>$entry){
            $raw=base64_decode((string)($entry['public_key']??''),true);
            if($raw===false||$raw===''||trim((string)($entry['suite']??''))===''||trim((string)($entry['principal_id']??''))===''){
                throw new \InvalidArgumentException('invalid-sovereign-recovery-root:'.$keyId);
            }
            if((string)($entry['purpose']??'')!=='sovereign_recovery_only') throw new \InvalidArgumentException('invalid-sovereign-recovery-root-purpose:'.$keyId);
            foreach(['company_id','tenant_id','tenant_company_id','capability_id','role_id','permission_id'] as $forbidden){
                if(array_key_exists($forbidden,$entry)) throw new \InvalidArgumentException('authority-bearing-recovery-root-forbidden:'.$keyId.':'.$forbidden);
            }
            $this->recoveryRoots[(string)$keyId]=[
                'key_id'=>(string)$keyId,
                'suite'=>(string)$entry['suite'],
                'public_key'=>$raw,
                'principal_id'=>(string)$entry['principal_id'],
                'purpose'=>'sovereign_recovery_only',
                'status'=>(string)($entry['status']??'active'),
                'trusted_from'=>isset($entry['trusted_from'])?(int)$entry['trusted_from']:null,
                'retired_at'=>isset($entry['retired_at'])?(int)$entry['retired_at']:null,
                'revoked_at'=>isset($entry['revoked_at'])?(int)$entry['revoked_at']:null,
            ];
        }

        $participantIds=[];
        foreach($participants as $keyId=>$entry){
            $participantId=trim((string)($entry['participant_id']??''));
            $actorType=(string)($entry['actor_type']??'');
            $role=(string)($entry['role']??'');
            $raw=base64_decode((string)($entry['public_key']??''),true);
            if($participantId===''||$raw===false||$raw===''||trim((string)($entry['suite']??''))===''||$role!=='recovery_witness'){
                throw new \InvalidArgumentException('invalid-recovery-participant:'.$keyId);
            }
            if($actorType==='advanced_intelligence'||$actorType==='ai'||$actorType==='agent'){
                throw new \InvalidArgumentException('recovery-ai-participant-forbidden:'.$participantId);
            }
            if(isset($participantIds[$participantId])) throw new \InvalidArgumentException('duplicate-recovery-participant-registration:'.$participantId);
            $participantIds[$participantId]=true;
            foreach(['company_id','tenant_id','tenant_company_id','capability_id','authority_class','permission_id'] as $forbidden){
                if(array_key_exists($forbidden,$entry)) throw new \InvalidArgumentException('authority-bearing-recovery-participant-forbidden:'.$participantId.':'.$forbidden);
            }
            $this->participants[(string)$keyId]=[
                'key_id'=>(string)$keyId,
                'participant_id'=>$participantId,
                'actor_type'=>$actorType,
                'role'=>'recovery_witness',
                'suite'=>(string)$entry['suite'],
                'public_key'=>$raw,
                'status'=>(string)($entry['status']??'active'),
                'trusted_from'=>isset($entry['trusted_from'])?(int)$entry['trusted_from']:null,
                'retired_at'=>isset($entry['retired_at'])?(int)$entry['retired_at']:null,
                'revoked_at'=>isset($entry['revoked_at'])?(int)$entry['revoked_at']:null,
            ];
        }
        if(count($this->participants)<$quorum) throw new \InvalidArgumentException('recovery-quorum-exceeds-registered-participants');
    }

    public function authorizeDeviceRecovery(array $request, ?int $now=null):array
    {
        $now??=time();
        if(!isset($request['payload'])||!is_array($request['payload'])) throw new GodModeException('sovereign-recovery-payload-missing');
        $p=$request['payload'];
        foreach(['schema','recovery_id','authority','principal_id','new_device_key_id','new_device_public_key','new_device_binding_id','challenge','requested_at','recovery_expires_at','purpose','non_tenant'] as $f){
            if(!array_key_exists($f,$p)) throw new GodModeException('sovereign-recovery-payload-missing:'.$f);
        }
        if((string)$p['schema']!=='titan.t0gm.sovereign_recovery_request.v1') throw new GodModeException('wrong-sovereign-recovery-schema');
        if((string)$p['authority']!==(string)$this->policy['authority']) throw new GodModeException('wrong-sovereign-recovery-authority');
        if((string)$p['principal_id']!==(string)$this->policy['principal_id']) throw new GodModeException('wrong-sovereign-recovery-principal');
        if((string)$p['purpose']!=='restore-device-access-to-existing-sovereign-identity') throw new GodModeException('wrong-sovereign-recovery-purpose');
        if($p['non_tenant']!==true) throw new GodModeException('sovereign-recovery-must-be-non-tenant');
        foreach(['company_id','tenant_id','tenant_company_id','role_id','user_id','permission_id','capability_id','execution_id'] as $forbidden){
            if(array_key_exists($forbidden,$p)) throw new GodModeException('application-authority-binding-forbidden:'.$forbidden);
        }
        if(trim((string)$p['recovery_id'])===''||trim((string)$p['challenge'])===''||trim((string)$p['new_device_key_id'])===''||trim((string)$p['new_device_binding_id'])===''){
            throw new GodModeException('sovereign-recovery-binding-incomplete');
        }
        $skew=(int)($this->policy['clock_skew_seconds']??30);
        if($now+$skew < (int)$p['requested_at'] || $now-$skew > (int)$p['recovery_expires_at']) throw new GodModeException('sovereign-recovery-outside-verification-window');
        if((int)$p['recovery_expires_at'] <= (int)$p['requested_at']) throw new GodModeException('invalid-sovereign-recovery-window');
        $devicePublic=base64_decode((string)$p['new_device_public_key'],true);
        if($devicePublic===false||$devicePublic==='') throw new GodModeException('invalid-recovery-device-public-key');

        if(!array_key_exists('sovereign_recovery_proof',$request)||!is_array($request['sovereign_recovery_proof'])){
            throw new GodModeException('sovereign-recovery-proof-missing');
        }
        $approvals=(array)($request['participant_approvals']??[]);
        $required=(int)$this->policy['quorum'];
        if(count($approvals)<$required) throw new GodModeException('recovery-quorum-not-satisfied');

        $payloadHash=hash('sha256',CanonicalJson::encode($p));
        $verifiedParticipants=[];
        foreach($approvals as $approval){
            if(!is_array($approval)) throw new GodModeException('invalid-recovery-participant-approval');
            foreach(['participant_id','key_id','suite','statement','signature'] as $f){
                if(!array_key_exists($f,$approval)) throw new GodModeException('recovery-participant-approval-missing:'.$f);
            }
            $participantId=(string)$approval['participant_id'];
            if(isset($verifiedParticipants[$participantId])) throw new GodModeException('duplicate-recovery-participant');
            $keyId=(string)$approval['key_id'];
            $participant=$this->participantForVerification($keyId,(int)$p['requested_at']);
            if(!hash_equals($participant['participant_id'],$participantId)) throw new GodModeException('recovery-participant-key-mismatch');
            if($participant['suite']!==(string)$approval['suite']) throw new GodModeException('recovery-participant-suite-mismatch');
            $expectedStatement=[
                'schema'=>'titan.t0gm.sovereign_recovery_witness.v1',
                'payload_hash'=>$payloadHash,
                'participant_id'=>$participantId,
                'claim'=>'recovery-witness-only-no-sovereignty',
            ];
            if(CanonicalJson::encode((array)$approval['statement'])!==CanonicalJson::encode($expectedStatement)) throw new GodModeException('invalid-recovery-witness-statement');
            $signature=base64_decode((string)$approval['signature'],true);
            if($signature===false||!$this->crypto->verify($participant['suite'],$signature,CanonicalJson::encode($expectedStatement),$participant['public_key'])){
                throw new GodModeException('invalid-recovery-witness-signature:'.$participantId);
            }
            $verifiedParticipants[$participantId]=[
                'participant_id'=>$participantId,
                'key_id'=>$keyId,
                'actor_type'=>$participant['actor_type'],
                'role'=>'recovery_witness',
                'attests_recovery_only'=>true,
                'grants_t0gm_sovereignty'=>false,
            ];
        }
        if(count($verifiedParticipants)<$required) throw new GodModeException('recovery-quorum-not-satisfied');

        $rootProof=$request['sovereign_recovery_proof'];
        foreach(['key_id','suite','statement','signature'] as $f){
            if(!array_key_exists($f,$rootProof)) throw new GodModeException('sovereign-recovery-proof-missing:'.$f);
        }
        $root=$this->recoveryRootForVerification((string)$rootProof['key_id'],(int)$p['requested_at']);
        if(!hash_equals($root['principal_id'],(string)$p['principal_id'])) throw new GodModeException('sovereign-recovery-root-principal-mismatch');
        if($root['suite']!==(string)$rootProof['suite']) throw new GodModeException('sovereign-recovery-root-suite-mismatch');
        $expectedRootStatement=[
            'schema'=>'titan.t0gm.sovereign_recovery_continuity.v1',
            'payload_hash'=>$payloadHash,
            'principal_id'=>(string)$p['principal_id'],
            'claim'=>'same-sovereign-principal-recovery-continuity',
        ];
        if(CanonicalJson::encode((array)$rootProof['statement'])!==CanonicalJson::encode($expectedRootStatement)) throw new GodModeException('invalid-sovereign-recovery-continuity-statement');
        $rootSignature=base64_decode((string)$rootProof['signature'],true);
        if($rootSignature===false||!$this->crypto->verify($root['suite'],$rootSignature,CanonicalJson::encode($expectedRootStatement),$root['public_key'])){
            throw new GodModeException('invalid-sovereign-recovery-continuity-signature');
        }

        if(!$this->nonces->consume('t0gm-sovereign-recovery:'.(string)$p['principal_id'],(string)$p['challenge'],(int)$p['recovery_expires_at'])){
            throw new GodModeException('sovereign-recovery-replay-detected');
        }

        return [
            'schema'=>'titan.t0gm.recovery_enrollment_authorization.v1',
            'recovery_id'=>(string)$p['recovery_id'],
            'principal_id'=>(string)$p['principal_id'],
            'authority'=>(string)$p['authority'],
            'payload_hash'=>$payloadHash,
            'authorized_at'=>$now,
            'quorum'=>[
                'required'=>$required,
                'verified_participants'=>count($verifiedParticipants),
                'participants'=>array_values($verifiedParticipants),
            ],
            'sovereign_recovery_continuity_verified'=>true,
            'recovery_root_key_id'=>$root['key_id'],
            'device_binding_entry'=>[
                'principal_id'=>(string)$p['principal_id'],
                'device_public_key_hash'=>hash('sha256',$devicePublic),
                'binding_id'=>(string)$p['new_device_binding_id'],
                'status'=>'active',
                'bound_from'=>$now,
                'provenance'=>[
                    'enrollment'=>'sovereign-recovery',
                    'recovery_id'=>(string)$p['recovery_id'],
                    'recovery_payload_hash'=>$payloadHash,
                    'recovery_root_key_id'=>$root['key_id'],
                    'witness_participant_ids'=>array_keys($verifiedParticipants),
                ],
            ],
            'grants_t0gm_sovereignty'=>false,
            'transfers_sovereignty'=>false,
            'application_role_authority'=>false,
            'company_authority_embedded'=>false,
            'execution_authority_granted'=>false,
            'capability_granted'=>false,
            'requires_normal_identity_proof_after_enrollment'=>true,
        ];
    }

    private function participantForVerification(string $keyId,int $at):array
    {
        if(!isset($this->participants[$keyId])) throw new GodModeException('unknown-recovery-participant-key');
        $p=$this->participants[$keyId];
        if($p['status']!=='active') throw new GodModeException('recovery-participant-not-active');
        if($p['trusted_from']!==null&&$at<$p['trusted_from']) throw new GodModeException('recovery-participant-not-trusted-at');
        if($p['retired_at']!==null&&$at>=$p['retired_at']) throw new GodModeException('recovery-participant-retired-at');
        if($p['revoked_at']!==null&&$at>=$p['revoked_at']) throw new GodModeException('recovery-participant-revoked-at');
        return $p;
    }

    private function recoveryRootForVerification(string $keyId,int $at):array
    {
        if(!isset($this->recoveryRoots[$keyId])) throw new GodModeException('unknown-sovereign-recovery-root');
        $r=$this->recoveryRoots[$keyId];
        if($r['status']!=='active') throw new GodModeException('sovereign-recovery-root-not-active');
        if($r['trusted_from']!==null&&$at<$r['trusted_from']) throw new GodModeException('sovereign-recovery-root-not-trusted-at');
        if($r['retired_at']!==null&&$at>=$r['retired_at']) throw new GodModeException('sovereign-recovery-root-retired-at');
        if($r['revoked_at']!==null&&$at>=$r['revoked_at']) throw new GodModeException('sovereign-recovery-root-revoked-at');
        return $r;
    }
}
