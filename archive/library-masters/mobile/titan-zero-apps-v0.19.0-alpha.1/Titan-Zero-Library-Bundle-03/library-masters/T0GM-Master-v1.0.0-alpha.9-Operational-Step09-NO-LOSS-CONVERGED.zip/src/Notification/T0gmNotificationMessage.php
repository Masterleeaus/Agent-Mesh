<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationMessage
{
    public function __construct(
        public readonly string $notificationId,
        public readonly string $eventId,
        public readonly string $tier,
        public readonly string $title,
        public readonly string $summary,
        public readonly string $companyScope,
        public readonly ?string $companyId,
        public readonly array $reasonCodes,
        public readonly string $correlationId,
        public readonly string $createdAt,
    ) {}
    public function toArray(): array { return get_object_vars($this); }
}
