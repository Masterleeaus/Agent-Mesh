<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\GodModeException;

final class BrokeredSecureEnclaveCustodyProvider implements SovereignKeyCustodyProvider
{
    /** @param array<string,array> $keys */
    public function __construct(private readonly string $id,private readonly array $keys,private readonly SecureEnclaveBroker $broker) {}
    public function providerId(): string { return $this->id; }
    public function describe(string $keyId): SovereignKeyHandle {
        if(!isset($this->keys[$keyId])) throw new GodModeException('unknown-secure-enclave-key:' . $keyId); $c=(array)$this->keys[$keyId];
        $pub=base64_decode((string)($c['public_key']??''),true); if($pub===false||$pub==='') throw new GodModeException('invalid-secure-enclave-public-key:' . $keyId);
        return new SovereignKeyHandle($keyId,(string)$c['suite'],$this->id,'secure_enclave',(string)$c['custody_domain'],$pub,true,false,(array)($c['purposes']??[]),(string)$c['attestation_evidence_hash'],['broker_key_reference_hash'=>hash('sha256',(string)($c['broker_key_reference']??$keyId))]);
    }
    public function sign(string $keyId,string $suite,string $message,array $context=[]): string {
        $h=$this->describe($keyId); if($h->suite!==$suite) throw new GodModeException('secure-enclave-signature-suite-mismatch');
        $sig=$this->broker->sign($this->id,$keyId,$suite,$message,$context); if($sig==='') throw new GodModeException('secure-enclave-empty-signature'); return $sig;
    }
}
