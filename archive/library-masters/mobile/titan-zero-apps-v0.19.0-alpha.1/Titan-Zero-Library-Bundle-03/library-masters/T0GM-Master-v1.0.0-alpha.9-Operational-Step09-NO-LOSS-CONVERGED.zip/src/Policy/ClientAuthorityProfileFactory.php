<?php
namespace Titan\GodMode\Policy;

use Titan\GodMode\Security\CanonicalJson;

final class ClientAuthorityProfileFactory
{
    public function create(string $profileType, string $companyId, string $basisId, array $overrides = []): array
    {
        if (!in_array($profileType, ClientAuthorityProfileType::all(), true)) throw new \InvalidArgumentException('unknown-client-authority-profile');
        if ($companyId === '' || $companyId === '*' || strtolower($companyId) === 'all') throw new \InvalidArgumentException('invalid-profile-company-id');
        $defaults = $this->defaults($profileType);
        $profile = array_replace_recursive($defaults, $overrides, [
            'schema'=>'titan.t0gm.client-authority-profile.v1',
            'profile_id'=>'caprof_'.bin2hex(random_bytes(12)),
            'policy_version'=>'t0gm.client-authority.v1',
            'profile_type'=>$profileType,
            'company_id'=>$companyId,
            'authority_basis_id'=>$basisId,
            'created_at'=>gmdate('c'),
        ]);
        $profile['integrity']=['algorithm'=>'sha256','digest'=>$this->digest($profile)];
        return $profile;
    }

    public function verify(array $profile): bool
    {
        return ($profile['integrity']['algorithm'] ?? null)==='sha256'
            && is_string($profile['integrity']['digest'] ?? null)
            && hash_equals($profile['integrity']['digest'], $this->digest($profile));
    }

    private function digest(array $profile): string
    {
        unset($profile['integrity']);
        return hash('sha256', CanonicalJson::encode($profile));
    }

    private function defaults(string $type): array
    {
        $targets=['laravel_application','database','linux_server','browser_extension','pwa','cloud_api','ai_worker'];
        $base=[
            'allowed_target_types'=>$targets,
            'allowed_operations'=>[],
            'denied_operations'=>['delete_everything','grant_god_mode','increase_authority'],
            'allowed_action_classes'=>['observe','diagnostic','mutation','recovery'],
            'client_approval'=>['mode'=>'none','required_for'=>[]],
            'execution_mode'=>'execute',
        ];
        if ($type===ClientAuthorityProfileType::CO_MANAGED) {
            $base['client_approval']=['mode'=>'conditional','required_for'=>['mutation','recovery','destructive']];
        } elseif ($type===ClientAuthorityProfileType::CLIENT_CONTROLLED) {
            $base['client_approval']=['mode'=>'required','required_for'=>['mutation','recovery','destructive']];
            $base['execution_mode']='request_until_approved';
        } elseif ($type===ClientAuthorityProfileType::RESTRICTED) {
            $base['allowed_target_types']=[];
            $base['allowed_action_classes']=['observe','diagnostic'];
            $base['execution_mode']='allowlist_only';
        } elseif ($type===ClientAuthorityProfileType::OBSERVATION_ONLY) {
            $base['allowed_action_classes']=['observe','diagnostic'];
            $base['execution_mode']='observe_only';
        }
        return $base;
    }
}
