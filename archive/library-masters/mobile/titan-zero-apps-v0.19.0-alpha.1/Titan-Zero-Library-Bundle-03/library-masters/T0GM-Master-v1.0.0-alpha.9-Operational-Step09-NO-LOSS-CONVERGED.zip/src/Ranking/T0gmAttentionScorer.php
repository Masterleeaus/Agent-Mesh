<?php
namespace Titan\GodMode\Ranking;

final class T0gmAttentionScorer
{
    private const WEIGHTS = [
        'risk'=>0.24,
        'significance'=>0.14,
        'anomaly'=>0.12,
        'urgency'=>0.12,
        'irreversibility'=>0.10,
        'financial_exposure'=>0.08,
        'physical_impact'=>0.08,
        'environmental_impact'=>0.06,
        'dependency'=>0.06,
    ];

    public function score(array $event): T0gmAttentionScore
    {
        $s = T0gmAttentionSignals::fromEvent($event);
        $values = $s->toArray();
        $raw = 0.0; $contributions = [];
        foreach (self::WEIGHTS as $factor => $weight) {
            $value = (int)$values[$factor];
            $part = $value * $weight;
            $raw += $part;
            $contributions[$factor] = round($part, 2);
        }

        // Uncertainty increases investigative attention but can never reduce a safety floor.
        $uncertainty = 100 - $s->confidence;
        $uncertaintyBoost = ($s->risk >= 50 || $s->anomaly >= 50 || $s->significance >= 60)
            ? min(8.0, $uncertainty * 0.08)
            : min(3.0, $uncertainty * 0.03);
        $raw += $uncertaintyBoost;
        $contributions['uncertainty_boost'] = round($uncertaintyBoost, 2);

        $score = (int)round(min(100, $raw));
        $reasons = [];

        // Non-averaging floors. Critical domain hazards remain critical regardless of benign dimensions.
        $criticalFloor = max($s->risk, $s->physicalImpact);
        if ($criticalFloor >= 95) { $score = max($score, 95); $reasons[] = 'CRITICAL_DOMAIN_FLOOR'; }
        if ($s->physicalImpact >= 90) { $score = max($score, 92); $reasons[] = 'PHYSICAL_SAFETY_CRITICAL'; }
        if ($s->risk >= 90) { $score = max($score, 90); $reasons[] = 'EXTREME_RISK'; }
        if ($s->irreversibility() >= 90 && max($s->financialExposure,$s->physicalImpact,$s->environmentalImpact,$s->significance) >= 70) {
            $score = max($score, 90); $reasons[] = 'IRREVERSIBLE_MATERIAL_EFFECT';
        }
        if ($s->financialExposure >= 90) { $score = max($score, 85); $reasons[] = 'EXTREME_FINANCIAL_EXPOSURE'; }
        if ($s->environmentalImpact >= 90) { $score = max($score, 85); $reasons[] = 'EXTREME_ENVIRONMENTAL_IMPACT'; }
        if ($s->anomaly >= 90) { $score = max($score, 85); $reasons[] = 'SEVERE_ANOMALY'; }
        if ($s->urgency >= 90) { $score = max($score, 85); $reasons[] = 'IMMEDIATE_URGENCY'; }
        if ($s->dependency >= 90) { $reasons[] = 'HIGH_DEPENDENCY_BLAST_RADIUS'; }
        if ($s->confidence < 35 && max($s->risk,$s->significance,$s->anomaly) >= 60) { $reasons[] = 'MATERIAL_UNCERTAINTY'; }

        $tier = match (true) {
            $score >= 90 => 'critical',
            $score >= 75 => 'urgent',
            $score >= 55 => 'important',
            $score >= 30 => 'watch',
            default => 'routine',
        };
        if (($event['oversight']['attention_tier'] ?? null) === 'critical') {
            $tier = 'critical'; $score = max($score, 90); $reasons[] = 'SOURCE_CRITICAL_ATTENTION';
        }

        return new T0gmAttentionScore($score,$tier,$s,$contributions,array_values(array_unique($reasons)));
    }
}
