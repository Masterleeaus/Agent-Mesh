<?php
namespace Titan\GodMode\App;
use Titan\GodMode\Security\GodModeException;
final class T0gmAppRuntime
{
    public function __construct(private readonly T0gmSovereignSessionContext $session,private readonly T0gmDeviceState $device,private readonly T0gmNavigationRegistry $navigation,private readonly T0gmCommandSurface $commands)
    {
        if($session->toArray()['device_binding_id']!==$device->toArray()['device_binding_id'])throw new GodModeException('session-device-binding-mismatch');
    }
    public function boot(array $navigationGrants=[]):array
    {
        return ['schema'=>'titan.t0gm.app_runtime.v1','app_id'=>'t0gm','app_class'=>'sovereign_advanced_intelligence_control_plane','session'=>$this->session->toArray(),'device'=>$this->device->toArray(),'navigation'=>$this->navigation->visibleRoutes($navigationGrants),'command_surface'=>'governed_intent_only','execution_authority_granted'=>false];
    }
    public function submitCommand(array $command):array
    {
        if(!$this->device->commandEligible())throw new GodModeException('t0gm-device-not-command-eligible');
        return $this->commands->createIntent($command,$this->session->toArray(),$this->device->toArray());
    }
}
