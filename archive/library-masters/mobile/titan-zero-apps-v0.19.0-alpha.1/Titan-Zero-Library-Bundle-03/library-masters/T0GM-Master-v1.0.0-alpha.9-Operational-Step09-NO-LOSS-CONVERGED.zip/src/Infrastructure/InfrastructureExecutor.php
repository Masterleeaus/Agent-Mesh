<?php
namespace Titan\GodMode\Infrastructure;

interface InfrastructureExecutor
{
    public function transport(): string;
    public function observe(array $nativeOperation): array;
    public function execute(array $nativeOperation): InfrastructureExecutionResult;
}
