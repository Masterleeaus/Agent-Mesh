<?php
namespace Titan\GodMode\Infrastructure;

/** Provider authentication is injected out-of-band; credentials are forbidden in sovereign operation payloads. */
final class CloudProviderExecutor implements InfrastructureExecutor
{
    public function __construct(private readonly mixed $client, private readonly mixed $observer){}
    public function transport():string{return 'cloud_provider_api';}
    public function observe(array $n):array{return ($this->observer)($this->client,$n);}
    public function execute(array $n):InfrastructureExecutionResult
    {
        $p=$n['parameters']??[]; foreach(['access_key','secret','bearer_token','credential','credentials'] as $k) if(isset($p[$k])) throw new \RuntimeException('embedded-cloud-credential-forbidden');
        $r=($this->client)($n); if(!is_array($r))$r=['result'=>$r];
        return new InfrastructureExecutionResult(($r['succeeded']??true)===true,$this->transport(),$this->observe($n),$r,$r['evidence']??[],($r['errors']??[]));
    }
}
