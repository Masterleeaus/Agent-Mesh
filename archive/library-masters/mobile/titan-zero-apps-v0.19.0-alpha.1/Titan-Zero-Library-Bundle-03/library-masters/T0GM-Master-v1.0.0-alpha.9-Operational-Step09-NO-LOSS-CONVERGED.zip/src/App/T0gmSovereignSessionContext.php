<?php
namespace Titan\GodMode\App;
use Titan\GodMode\Security\GodModeException;
final class T0gmSovereignSessionContext
{
    private array $data;
    public function __construct(array $data)
    {
        foreach(['session_id','identity_id','authority_class','actor_type','identity_proof_digest','device_binding_id','created_at'] as $f){if(trim((string)($data[$f]??''))==='')throw new GodModeException('t0gm-session-field-required:'.$f);}
        if($data['authority_class']!=='titan.god_mode'||$data['actor_type']!=='human') throw new GodModeException('t0gm-sovereign-human-session-required');
        if(!preg_match('/^[a-f0-9]{64}$/',(string)$data['identity_proof_digest'])) throw new GodModeException('invalid-t0gm-identity-proof-digest');
        foreach(['company_id','tenant_id','tenant_company_id','role_id','permission_id','capability_id'] as $forbidden){if(array_key_exists($forbidden,$data))throw new GodModeException('session-authority-scope-forbidden:'.$forbidden);}
        $this->data=[
            'schema'=>'titan.t0gm.sovereign_session.v1','session_id'=>(string)$data['session_id'],'identity_id'=>(string)$data['identity_id'],
            'authority_class'=>'titan.god_mode','actor_type'=>'human','identity_proof_digest'=>(string)$data['identity_proof_digest'],
            'device_binding_id'=>(string)$data['device_binding_id'],'created_at'=>(string)$data['created_at'],
            'sovereign_identity_verified'=>true,'execution_authority_granted'=>false,'company_authority_granted'=>false,
        ];
    }
    public function toArray():array{return $this->data;}
}
