<?php
namespace Titan\GodMode\Oversight;

use Titan\GodMode\Security\CanonicalJson;

final class ModelBackedOversightReviewer implements T0gmOversightReviewer
{
    public function __construct(
        private readonly string $specialistId,
        private readonly \Closure $model,
        private readonly string $modelId,
    ) {
        if (!in_array($specialistId, T0gmOversightSpecialist::all(), true)) throw new \InvalidArgumentException('unknown-oversight-specialist');
        if (trim($modelId) === '') throw new \InvalidArgumentException('model-id-required');
    }

    public function specialist(): string { return $this->specialistId; }

    public function review(array $event, array $attentionProjection): T0gmOversightAssessment
    {
        $response = ($this->model)([
            'specialist'=>$this->specialistId,
            'event'=>$event,
            'attention'=>$attentionProjection,
            'instruction'=>'Assess independently. Never grant authority. Preserve uncertainty and contrary evidence.',
        ]);
        if (!is_array($response)) throw new \RuntimeException('oversight-model-response-invalid');
        $disposition=(string)($response['disposition'] ?? T0gmOversightDisposition::UNCERTAIN);
        if (!in_array($disposition,T0gmOversightDisposition::all(),true)) throw new \RuntimeException('oversight-model-disposition-invalid');
        $confidence=max(0,min(100,(int)($response['confidence'] ?? 50)));
        $reasons=array_values(array_map('strval',(array)($response['reason_codes'] ?? ['MODEL_ASSESSMENT'])));
        $evidence=array_values(array_map('strval',(array)($response['evidence_refs'] ?? [])));
        $actions=array_values(array_map('strval',(array)($response['recommended_actions'] ?? [])));
        $limitations=array_values(array_map('strval',(array)($response['limitations'] ?? [])));
        $id='oa_model_'.substr(hash('sha256',$this->specialistId.'|'.($event['event_id']??'').'|'.$this->modelId.'|'.CanonicalJson::encode([$disposition,$reasons,$evidence,$confidence])),0,24);
        $limitations[]='MODEL_OUTPUT_IS_ADVISORY_AND_NON_AUTHORITATIVE';
        return new T0gmOversightAssessment(
            $id,(string)($event['event_id']??''),$this->specialistId,$disposition,$confidence,$reasons,$evidence,$actions,$limitations,$this->modelId
        );
    }
}
