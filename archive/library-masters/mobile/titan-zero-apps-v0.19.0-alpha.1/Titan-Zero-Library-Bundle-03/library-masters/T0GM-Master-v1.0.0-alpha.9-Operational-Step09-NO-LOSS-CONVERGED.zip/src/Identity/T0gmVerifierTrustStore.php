<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

final class T0gmVerifierTrustStore
{
    private array $keys=[];
    public function __construct(array $entries)
    {
        foreach($entries as $keyId=>$entry){
            if(is_string($entry)) $entry=['suite'=>T0gmCryptoSuiteRegistry::ED25519,'public_key'=>$entry];
            $suite=(string)($entry['suite']??'');$raw=base64_decode((string)($entry['public_key']??''),true);
            if($suite===''||$raw===false||$raw==='') throw new \InvalidArgumentException("invalid-verifier-key:$keyId");
            $this->keys[(string)$keyId]=[
                'suite'=>$suite,'public_key'=>$raw,'status'=>(string)($entry['status']??'active'),
                'trusted_from'=>isset($entry['trusted_from'])?(int)$entry['trusted_from']:null,
                'retired_at'=>isset($entry['retired_at'])?(int)$entry['retired_at']:null,
                'revoked_at'=>isset($entry['revoked_at'])?(int)$entry['revoked_at']:null,
                'provider_id'=>$entry['provider_id']??null,
            ];
        }
    }
    public function key(string $keyId): array { if(!isset($this->keys[$keyId])) throw new GodModeException('unknown-verifier-key:'.$keyId); return $this->keys[$keyId]; }
    public function keyForVerification(string $keyId,int $evidenceTime): array
    {
        $k=$this->key($keyId);
        if($k['trusted_from']!==null && $evidenceTime<$k['trusted_from']) throw new GodModeException('verifier-key-not-trusted-at:'.$keyId);
        if($k['revoked_at']!==null && $evidenceTime>=$k['revoked_at']) throw new GodModeException('verifier-key-revoked-at:'.$keyId);
        if($k['retired_at']!==null && $evidenceTime>=$k['retired_at']) throw new GodModeException('verifier-key-not-trusted-at:'.$keyId);
        return $k;
    }
}
