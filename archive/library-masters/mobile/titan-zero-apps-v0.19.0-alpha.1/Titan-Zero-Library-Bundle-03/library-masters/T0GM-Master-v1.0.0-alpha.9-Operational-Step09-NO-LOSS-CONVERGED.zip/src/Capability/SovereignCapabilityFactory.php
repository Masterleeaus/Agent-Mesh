<?php
namespace Titan\GodMode\Capability;

final class SovereignCapabilityFactory
{
    public function __construct(private readonly SovereignCapabilityHasher $hasher = new SovereignCapabilityHasher()) {}

    public function create(array $fields): array
    {
        $capability = array_merge([
            'schema' => 'titan.t0gm.sovereign-capability.v1',
            'capability_id' => self::id('cap'),
            'constitution_version' => 't0gm.constitution.v1',
            'created_at' => gmdate('c'),
        ], $fields);
        $capability['integrity'] = ['algorithm' => 'sha256', 'digest' => $this->hasher->digest($capability)];
        return $capability;
    }

    private static function id(string $prefix): string
    {
        return $prefix . '_' . bin2hex(random_bytes(16));
    }
}
