<?php
namespace Titan\GodMode\Adapter;

final class CloudApiAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'cloud_api'; }
    public function supports(array $target): bool { return ($target['target_type'] ?? '') === 'cloud_api'; }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_resource','read_health','restart_resource','scale_resource','apply_named_configuration','collect_diagnostics'
        ]);
        $params = $request['parameters'] ?? [];
        if (isset($params['access_key']) || isset($params['secret']) || isset($params['bearer_token'])) throw new TargetAdapterException('embedded_cloud_credentials_forbidden');
        return [
            'transport' => 'cloud_provider_api',
            'company_id' => $request['company_id'],
            'provider' => $request['target']['system'],
            'resource' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'parameters' => $params,
            'credential_source' => 'external_scoped_provider',
        ];
    }
}
