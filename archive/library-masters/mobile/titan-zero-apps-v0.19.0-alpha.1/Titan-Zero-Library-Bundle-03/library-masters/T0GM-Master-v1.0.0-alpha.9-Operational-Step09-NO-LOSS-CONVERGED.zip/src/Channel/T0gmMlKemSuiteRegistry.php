<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Security\GodModeException;

final class T0gmMlKemSuiteRegistry
{
    public const ML_KEM_512 = 'ml-kem-512';
    public const ML_KEM_768 = 'ml-kem-768';
    public const ML_KEM_1024 = 'ml-kem-1024';

    private array $suites;

    public function __construct(?array $suites = null)
    {
        $this->suites = $suites ?? [
            self::ML_KEM_512 => ['openssl_name'=>'ML-KEM-512','security_category'=>1],
            self::ML_KEM_768 => ['openssl_name'=>'ML-KEM-768','security_category'=>3],
            self::ML_KEM_1024 => ['openssl_name'=>'ML-KEM-1024','security_category'=>5],
        ];
    }

    public function suite(string $algorithm): array
    {
        if (!isset($this->suites[$algorithm])) {
            throw new GodModeException('unsupported-ml-kem-suite:' . $algorithm);
        }
        return $this->suites[$algorithm] + ['algorithm'=>$algorithm];
    }
}
