<?php
namespace Titan\GodMode\Security;

final class GodModeKeyRegistry
{
    /** @var array<string,string> raw Ed25519 public keys */
    private array $rootKeys = [];

    public function __construct(array $base64RootKeys)
    {
        foreach ($base64RootKeys as $kid => $encoded) {
            $raw = base64_decode((string) $encoded, true);
            if ($raw === false || strlen($raw) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
                throw new \InvalidArgumentException("invalid-root-public-key:$kid");
            }
            $this->rootKeys[(string) $kid] = $raw;
        }
    }

    public function rootPublicKey(string $kid): string
    {
        if (!isset($this->rootKeys[$kid])) {
            throw new GodModeException('unknown-root-key');
        }
        return $this->rootKeys[$kid];
    }
}
