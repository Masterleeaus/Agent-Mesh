<?php
namespace Titan\GodMode\Runtime;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmRuntimeIntegrityVerifier
{
    public function __construct(private readonly T0gmRuntimeIntegrityPolicyRegistry $policies,private readonly T0gmRuntimeIntegrityTrustStore $trust,private readonly T0gmCryptoSuiteRegistry $crypto,private readonly NonceStore $nonces){}
    public function verify(array $evidence,array $workloadIdentity,?int $now=null):array
    {
        $now??=time();
        if(($workloadIdentity['cryptographic_workload_identity']??null)!==true) throw new GodModeException('cryptographic-workload-identity-required');
        foreach(['workload_id','workload_class','binding_id'] as $f) if(!isset($workloadIdentity[$f])||trim((string)$workloadIdentity[$f])==='') throw new GodModeException('workload-identity-field-required:'.$f);
        foreach(['payload','attestor_key_id','signature_suite','signature'] as $f) if(!array_key_exists($f,$evidence)) throw new GodModeException('runtime-integrity-evidence-missing:'.$f);
        $p=(array)$evidence['payload'];
        foreach(['schema','workload_id','workload_class','workload_binding_id','policy_id','policy_revision','code_digest','config_digest','environment_digest','runtime_claims','nonce','issued_at','evidence_expires_at','non_authority_evidence'] as $f) if(!array_key_exists($f,$p)) throw new GodModeException('runtime-integrity-payload-missing:'.$f);
        if($p['schema']!=='titan.t0gm.runtime_integrity_attestation.v1') throw new GodModeException('wrong-runtime-integrity-schema');
        if($p['non_authority_evidence']!==true) throw new GodModeException('runtime-integrity-must-be-non-authority-evidence');
        foreach(['company_id','tenant_id','tenant_company_id','capability_id','authority','permission','role_id'] as $f) if(array_key_exists($f,$p)) throw new GodModeException('authority-bearing-runtime-integrity-forbidden:'.$f);
        if((string)$p['workload_id']!==(string)$workloadIdentity['workload_id']||(string)$p['workload_class']!==(string)$workloadIdentity['workload_class']||(string)$p['workload_binding_id']!==(string)$workloadIdentity['binding_id']) throw new GodModeException('runtime-workload-binding-mismatch');
        if($now < (int)$p['issued_at']-30 || $now > (int)$p['evidence_expires_at']+30) throw new GodModeException('runtime-integrity-evidence-outside-verification-window');
        $policy=$this->policies->active((string)$p['workload_id'],(string)$p['workload_class'],(string)$p['policy_id'],(int)$p['policy_revision']);
        if(!in_array((string)$p['code_digest'],$policy['trusted_code_digests'],true)) throw new GodModeException('runtime-code-digest-untrusted');
        if(!in_array((string)$p['config_digest'],$policy['trusted_config_digests'],true)) throw new GodModeException('runtime-config-digest-untrusted');
        if(!in_array((string)$p['environment_digest'],$policy['trusted_environment_digests'],true)) throw new GodModeException('runtime-environment-digest-untrusted');
        $claims=(array)$p['runtime_claims'];
        foreach($policy['required_claims'] as $k=>$expected) if(!array_key_exists($k,$claims)||$claims[$k]!==$expected) throw new GodModeException('runtime-required-claim-mismatch:'.$k);
        $key=$this->trust->key((string)$evidence['attestor_key_id'],'runtime_integrity_attestation');
        if($key['suite']!==(string)$evidence['signature_suite']) throw new GodModeException('runtime-integrity-attestor-suite-key-mismatch');
        $sig=base64_decode((string)$evidence['signature'],true);
        if($sig===false||!$this->crypto->verify((string)$evidence['signature_suite'],$sig,CanonicalJson::encode($p),$key['public_key'])) throw new GodModeException('invalid-runtime-integrity-attestation-signature');
        if(!$this->nonces->consume('t0gm-runtime-integrity:'.(string)$p['workload_id'],(string)$p['nonce'],(int)$p['evidence_expires_at'])) throw new GodModeException('runtime-integrity-replay-detected');
        $measurementHash=hash('sha256',CanonicalJson::encode(['code_digest'=>$p['code_digest'],'config_digest'=>$p['config_digest'],'environment_digest'=>$p['environment_digest'],'runtime_claims'=>$claims]));
        return [
            'runtime_integrity_valid'=>true,'workload_id'=>(string)$p['workload_id'],'workload_class'=>(string)$p['workload_class'],'workload_binding_id'=>(string)$p['workload_binding_id'],
            'policy_id'=>(string)$p['policy_id'],'policy_revision'=>(int)$p['policy_revision'],'measurement_hash'=>$measurementHash,'attestor_key_id'=>(string)$evidence['attestor_key_id'],
            'network_observation'=>is_array($p['network_observation']??null)?$p['network_observation']:[],'network_location_trusted'=>false,
            'authority_granted'=>false,'company_authority_granted'=>false,'t0gm_authority_granted'=>false,'evidence_only'=>true,
        ];
    }
}
