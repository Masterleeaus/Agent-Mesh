<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\ZeroKnowledgeProver;
use Titan\GodMode\Contracts\ZeroKnowledgeProverBroker;
use Titan\GodMode\Security\GodModeException;

final class BrokeredRistretto255SchnorrProver implements ZeroKnowledgeProver
{
    public function __construct(
        private readonly ZeroKnowledgeProverBroker $broker,
        private readonly string $providerId,
        private readonly string $witnessRef,
    ) {
        if ($this->providerId === '') throw new GodModeException('zk-provider-id-required');
        if ($this->witnessRef === '') throw new GodModeException('zk-witness-reference-required');
    }

    public function prove(array $publicStatement, array $context = []): string
    {
        if (isset($context['witness']) || isset($context['secret']) || isset($context['private_key'])) {
            throw new GodModeException('zk-secret-material-in-application-context-forbidden');
        }
        return $this->broker->prove($this->providerId, $this->witnessRef, $publicStatement, $context);
    }
}
