<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\ZeroKnowledgeVerifier;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmZeroKnowledgeProofGate
{
    /** @param array<string,ZeroKnowledgeVerifier> $verifiers */
    public function __construct(private readonly array $verifiers) {}

    public function verify(array $envelope, array $expectedStatement, array $allowedSystems): array
    {
        foreach (['proof_system','proof','public_statement'] as $f) {
            if (!array_key_exists($f,$envelope)) throw new GodModeException('zk-proof-missing:' . $f);
        }
        $system=(string)$envelope['proof_system'];
        if (!in_array($system,$allowedSystems,true)) throw new GodModeException('zk-proof-system-not-allowed:' . $system);
        if (!isset($this->verifiers[$system])) throw new GodModeException('zk-verifier-unavailable:' . $system);
        $statement=(array)$envelope['public_statement'];
        if (!hash_equals(hash('sha256',CanonicalJson::encode($expectedStatement)),hash('sha256',CanonicalJson::encode($statement)))) {
            throw new GodModeException('zk-public-statement-mismatch');
        }
        $proof=base64_decode((string)$envelope['proof'],true);
        if ($proof===false || $proof==='') throw new GodModeException('invalid-zk-proof-encoding');
        $result=$this->verifiers[$system]->verify($proof,$statement,['proof_system'=>$system]);
        if (($result['verified']??false)!==true) throw new GodModeException('zero-knowledge-proof-invalid');
        if (($result['proof_system']??'')!==$system) throw new GodModeException('zk-verifier-system-mismatch');
        $expectedHash=hash('sha256',CanonicalJson::encode($statement));
        if (!hash_equals($expectedHash,(string)($result['statement_hash']??''))) throw new GodModeException('zk-verifier-statement-hash-mismatch');
        return $result;
    }
}
