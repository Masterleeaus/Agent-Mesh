<?php
namespace Titan\GodMode\View;

use Titan\GodMode\Ranking\T0gmAttentionScore;

final class T0gmRankedFeedItem
{
    public function __construct(
        public readonly array $record,
        public readonly T0gmAttentionScore $attention,
        public readonly array $viewReasons = [],
        public readonly bool $superseded = false,
        public readonly array $supersededBy = [],
    ) {}

    public function toArray(): array
    {
        return [
            'record'=>$this->record,
            'attention'=>$this->attention->toArray(),
            'view_reasons'=>$this->viewReasons,
            'superseded'=>$this->superseded,
            'superseded_by'=>$this->supersededBy,
        ];
    }
}
