<?php
namespace Titan\GodMode\Event;

use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmEventProvenanceVerifier
{
    public function __construct(
        private readonly T0gmEventProvenanceTrustStore $trust,
        private readonly T0gmCryptoSuiteRegistry $crypto=new T0gmCryptoSuiteRegistry(),
        private readonly T0gmEventProvenanceSigner $statementBuilder,
    ) {}

    public function verify(array $event,array $requiredSuites=[]): bool
    {
        $p=$event['provenance']??null;
        if(!is_array($p)) throw new GodModeException('event-provenance-missing');
        if(($p['schema']??null)!=='titan.t0gm.event-provenance.v1') throw new GodModeException('invalid-event-provenance-schema');
        if(($p['semantics']['grants_authority']??null)!==false || ($p['semantics']['constitutes_t0gm_approval']??null)!==false) {
            throw new GodModeException('event-provenance-authority-semantics-invalid');
        }
        $statement=$this->statementBuilder->statement($event);
        $encoded=CanonicalJson::encode($statement);
        $statementHash=hash('sha256',$encoded);
        foreach(['event_hash','lineage_hash','evidence_hash'] as $f) {
            if(!is_string($p[$f]??null)||!hash_equals((string)$p[$f],(string)$statement[$f])) throw new GodModeException('event-provenance-binding-invalid:'.$f);
        }
        if(!is_string($p['statement_hash']??null)||!hash_equals($p['statement_hash'],$statementHash)) throw new GodModeException('event-provenance-statement-hash-invalid');
        $signatures=$p['signatures']??null;
        if(!is_array($signatures)||$signatures===[]) throw new GodModeException('event-provenance-signatures-missing');
        $seen=[];
        foreach($signatures as $sig){
            if(!is_array($sig)) throw new GodModeException('invalid-event-provenance-signature');
            $keyId=(string)($sig['key_id']??'');$suite=(string)($sig['suite']??'');
            $raw=base64_decode((string)($sig['signature']??''),true);
            if($keyId===''||$suite===''||$raw===false) throw new GodModeException('invalid-event-provenance-signature');
            $eventTime=strtotime((string)($event['occurred_at']??''));
            if($eventTime===false) throw new GodModeException('event-provenance-time-invalid');
            $trusted=$this->trust->keyForVerification($keyId,$eventTime);
            if($trusted['suite']!==$suite) throw new GodModeException('event-provenance-suite-mismatch:'.$keyId);
            if(!$this->crypto->verify($suite,$raw,$encoded,$trusted['public_key'])) throw new GodModeException('event-provenance-signature-invalid:'.$keyId);
            $seen[$suite]=true;
        }
        foreach($requiredSuites as $suite) if(!isset($seen[$suite])) throw new GodModeException('required-event-provenance-suite-missing:'.$suite);
        return true;
    }
}
