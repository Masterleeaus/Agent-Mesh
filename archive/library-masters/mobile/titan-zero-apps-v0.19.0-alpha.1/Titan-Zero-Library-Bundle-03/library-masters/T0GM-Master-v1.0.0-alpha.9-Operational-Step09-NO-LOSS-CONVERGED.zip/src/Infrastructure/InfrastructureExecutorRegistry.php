<?php
namespace Titan\GodMode\Infrastructure;

final class InfrastructureExecutorRegistry
{
    /** @var array<string,InfrastructureExecutor> */
    private array $executors=[];
    public function __construct(array $executors=[]){foreach($executors as $e)$this->register($e);}
    public function register(InfrastructureExecutor $executor):void
    { $t=$executor->transport(); if(isset($this->executors[$t])) throw new \RuntimeException('duplicate-infrastructure-transport'); $this->executors[$t]=$executor; }
    public function resolve(string $transport):InfrastructureExecutor
    { if(!isset($this->executors[$transport])) throw new \RuntimeException('infrastructure-transport-not-registered'); return $this->executors[$transport]; }
    public function transports():array { return array_keys($this->executors); }
}
