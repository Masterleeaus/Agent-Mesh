<?php
namespace Titan\GodMode\Recovery;
final class T0gmStateTransitionException extends \RuntimeException {}
