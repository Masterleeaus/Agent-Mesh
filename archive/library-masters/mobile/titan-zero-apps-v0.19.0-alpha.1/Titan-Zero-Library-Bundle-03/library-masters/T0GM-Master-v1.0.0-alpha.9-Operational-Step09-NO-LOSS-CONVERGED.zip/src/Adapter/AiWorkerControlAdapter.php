<?php
namespace Titan\GodMode\Adapter;

final class AiWorkerControlAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'ai_worker_control'; }
    public function supports(array $target): bool { return ($target['target_type'] ?? '') === 'ai_worker'; }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_worker_state','pause_worker','resume_worker','terminate_worker_execution',
            'quarantine_worker','replace_worker_policy','collect_worker_evidence','revoke_delegated_capability'
        ]);
        $params = $request['parameters'] ?? [];
        foreach (['grant_capability','increase_authority','authority_class','god_mode'] as $field) {
            if (array_key_exists($field, $params)) throw new TargetAdapterException('ai_worker_authority_mutation_forbidden');
        }
        return [
            'transport' => 'titan_ai_worker_control_plane',
            'company_id' => $request['company_id'],
            'worker_id' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'parameters' => $params,
        ];
    }
}
