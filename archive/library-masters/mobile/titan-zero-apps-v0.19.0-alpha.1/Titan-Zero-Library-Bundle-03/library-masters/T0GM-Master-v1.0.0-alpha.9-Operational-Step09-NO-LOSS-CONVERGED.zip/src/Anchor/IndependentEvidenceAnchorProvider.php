<?php
namespace Titan\GodMode\Anchor;

interface IndependentEvidenceAnchorProvider
{
    public function providerId(): string;
    /** @return array<string,mixed> */
    public function anchor(array $commitment, array $context = []): array;
}
