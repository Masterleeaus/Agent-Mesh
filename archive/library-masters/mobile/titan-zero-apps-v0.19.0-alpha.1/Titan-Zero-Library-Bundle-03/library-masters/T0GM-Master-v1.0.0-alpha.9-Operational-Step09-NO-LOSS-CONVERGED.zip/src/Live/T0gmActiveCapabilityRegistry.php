<?php
namespace Titan\GodMode\Live;

use Titan\GodMode\Capability\SovereignCapabilityHasher;
use Titan\GodMode\Capability\SovereignCapabilityValidator;
use Titan\GodMode\Continuance\AuthorityContinuanceDecision;
use Titan\GodMode\Continuance\AuthorityContinuanceOutcome;

final class T0gmActiveCapabilityRegistry
{
    private array $states=[];
    private array $history=[];
    public function __construct(
        private readonly SovereignCapabilityValidator $validator=new SovereignCapabilityValidator(),
        private readonly SovereignCapabilityHasher $hasher=new SovereignCapabilityHasher(),
    ){}
    public function activate(array $capability): array
    {
        $this->validator->validate($capability);
        if(!$this->hasher->verify($capability)) throw new \RuntimeException('capability-integrity-failed');
        $id=$capability['capability_id'];
        if(isset($this->states[$id])) throw new \RuntimeException('capability-already-registered');
        return $this->states[$id]=[
            'capability'=>$capability,'status'=>'active','retained_effect_ids'=>array_values(array_map(fn($e)=>$e['effect_id'],$capability['permitted_effects'])),
            'last_reevaluation'=>null,'transformation_request'=>null,
        ];
    }
    public function state(string $id): array
    { if(!isset($this->states[$id]))throw new \RuntimeException('capability-not-found'); return $this->states[$id]; }
    public function evaluable(): array
    { return array_filter($this->states,fn($s)=>$s['status']!=='terminated'); }
    public function apply(string $id,AuthorityContinuanceDecision $decision,array $record): array
    {
        $state=$this->state($id);
        if($state['status']==='terminated') throw new \RuntimeException('terminated-capability-cannot-be-reevaluated');
        $state['last_reevaluation']=$record;
        $state['transformation_request']=$decision->transformationRequest;
        switch($decision->outcome){
            case AuthorityContinuanceOutcome::CONTINUE: $state['status']='active'; break;
            case AuthorityContinuanceOutcome::PAUSE: $state['status']='paused'; break;
            case AuthorityContinuanceOutcome::NARROW: $state['status']='narrowed'; $state['retained_effect_ids']=$decision->retainedEffectIds; break;
            case AuthorityContinuanceOutcome::TRANSFORM: $state['status']='transformation_required'; break;
            case AuthorityContinuanceOutcome::TERMINATE: $state['status']='terminated'; $state['retained_effect_ids']=[]; break;
        }
        $this->states[$id]=$state;
        $this->history[$id][]=$record;
        return $state;
    }
    public function history(string $id): array { return $this->history[$id]??[]; }
}
