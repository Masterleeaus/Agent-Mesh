<?php
namespace Titan\GodMode\Recovery;

final class T0gmStateTransitionValidator
{
    private const FORBIDDEN=['tenant_id','tenant_company_id','tenantId','tenantCompanyId'];
    public function validate(array $t): array
    {
        $this->rejectLegacy($t);
        if(($t['schema']??null)!=='titan.t0gm.state-transition.v1') throw new T0gmStateTransitionException('invalid-transition-schema');
        foreach(['transition_id','company_id','source_event_id','purpose'] as $k) $this->str($t,$k);
        foreach(['subject','pre_state','intended_result','actual_result','reversibility'] as $k) if(!isset($t[$k])||!is_array($t[$k])) throw new T0gmStateTransitionException('invalid-'.$k);
        foreach(['subject_type','subject_id'] as $k) $this->str($t['subject'],$k);
        foreach(['pre_state','intended_result','actual_result'] as $k) {
            if(!isset($t[$k]['state'])||!is_array($t[$k]['state'])) throw new T0gmStateTransitionException('invalid-'.$k.'-state');
            $this->str($t[$k],'hash');
        }
        $r=$t['reversibility'];
        if(!isset($r['score'])||!is_int($r['score'])||$r['score']<0||$r['score']>100) throw new T0gmStateTransitionException('invalid-reversibility-score');
        if(!in_array($r['mode']??null,['direct','compensating','recompute_only','irreversible'],true)) throw new T0gmStateTransitionException('invalid-reversibility-mode');
        if(($r['mode']??null)==='direct') $this->str($r,'inverse_effect');
        if(($r['mode']??null)==='compensating') $this->str($r,'compensating_effect');
        if(!isset($t['dependencies'])||!is_array($t['dependencies'])) throw new T0gmStateTransitionException('invalid-dependencies');
        foreach($t['dependencies'] as $d){ if(!is_array($d)) throw new T0gmStateTransitionException('invalid-dependency'); $this->str($d,'dependency_id'); $this->str($d,'required_state'); }
        if(!isset($t['evidence'])||!is_array($t['evidence'])) throw new T0gmStateTransitionException('invalid-evidence');
        return $t;
    }
    private function str(array $a,string $k):void { if(!isset($a[$k])||!is_string($a[$k])||trim($a[$k])==='') throw new T0gmStateTransitionException('invalid-'.$k); }
    private function rejectLegacy(array $a):void { foreach($a as $k=>$v){ if(in_array((string)$k,self::FORBIDDEN,true)) throw new T0gmStateTransitionException('legacy-tenant-boundary-forbidden'); if(is_array($v))$this->rejectLegacy($v); } }
}
