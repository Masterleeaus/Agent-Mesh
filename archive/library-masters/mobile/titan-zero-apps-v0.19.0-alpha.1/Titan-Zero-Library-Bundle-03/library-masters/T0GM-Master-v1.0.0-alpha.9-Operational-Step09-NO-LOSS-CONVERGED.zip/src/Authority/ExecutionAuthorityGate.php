<?php
namespace Titan\GodMode\Authority;

use Titan\GodMode\Capability\SovereignCapabilityEvaluator;

/**
 * Constitutional stage gate: intent and planning explain or propose an effect;
 * only an independently validated execution capability may authorize the effect.
 */
final class ExecutionAuthorityGate
{
    private const NON_EXECUTION_AUTHORITY_TYPES = [
        'intent', 'plan', 'planning', 'recommendation', 'decision', 'discovery',
        'analysis', 'reasoning', 'proposal', 'approval_score', 'confidence'
    ];

    public function __construct(
        private readonly AuthorityArtifactValidator $artifactValidator = new AuthorityArtifactValidator(),
        private readonly SovereignCapabilityEvaluator $capabilityEvaluator = new SovereignCapabilityEvaluator(),
    ) {}

    public function evaluate(array $intent, array $plan, array $executionRequest): ExecutionAuthorityDecision
    {
        $reasons = [];
        try { $this->artifactValidator->validate($intent); } catch (\Throwable $e) { $reasons[] = 'invalid_intent_artifact'; }
        try { $this->artifactValidator->validate($plan); } catch (\Throwable $e) { $reasons[] = 'invalid_planning_artifact'; }
        if (($intent['stage'] ?? null) !== AuthorityStage::INTENT) $reasons[] = 'intent_stage_required';
        if (($plan['stage'] ?? null) !== AuthorityStage::PLANNING) $reasons[] = 'planning_stage_required';

        if (($plan['intent_id'] ?? null) !== ($intent['artifact_id'] ?? null)) $reasons[] = 'plan_not_bound_to_intent';
        foreach (['company_id'] as $field) {
            if (($plan[$field] ?? null) !== ($intent[$field] ?? null)) $reasons[] = 'intent_plan_company_mismatch';
            if (($executionRequest[$field] ?? null) !== ($intent[$field] ?? null)) $reasons[] = 'execution_company_mismatch';
        }
        foreach (['target_type','target_id','system','environment'] as $field) {
            if (($plan['target'][$field] ?? null) !== ($intent['target'][$field] ?? null)) $reasons[] = 'intent_plan_target_mismatch:' . $field;
            if (($executionRequest['target'][$field] ?? null) !== ($intent['target'][$field] ?? null)) $reasons[] = 'execution_target_mismatch:' . $field;
        }

        $operation = strtolower(trim((string)($executionRequest['operation'] ?? '')));
        if ($operation === '') $reasons[] = 'execution_operation_required';
        if ($operation !== strtolower(trim((string)($intent['requested_operation'] ?? '')))) $reasons[] = 'execution_not_requested_by_intent';
        $plannedOperations = [];
        foreach (($plan['steps'] ?? []) as $step) $plannedOperations[] = strtolower(trim((string)($step['operation'] ?? '')));
        if (!in_array($operation, $plannedOperations, true)) $reasons[] = 'execution_not_present_in_plan';

        $authority = $executionRequest['execution_authority'] ?? null;
        if (!is_array($authority)) {
            $reasons[] = 'independent_execution_authority_required';
            return new ExecutionAuthorityDecision(false, array_values(array_unique($reasons)), null, $this->lineage($intent, $plan));
        }
        $authorityType = strtolower(trim((string)($authority['authority_type'] ?? '')));
        if (in_array($authorityType, self::NON_EXECUTION_AUTHORITY_TYPES, true)) {
            $reasons[] = 'reasoning_or_decision_is_not_execution_authority';
            return new ExecutionAuthorityDecision(false, array_values(array_unique($reasons)), null, $this->lineage($intent, $plan));
        }
        if ($authorityType !== 'sovereign_capability') {
            $reasons[] = 'unsupported_execution_authority_type';
            return new ExecutionAuthorityDecision(false, array_values(array_unique($reasons)), null, $this->lineage($intent, $plan));
        }
        $capability = $authority['capability'] ?? null;
        if (!is_array($capability)) {
            $reasons[] = 'sovereign_capability_required';
            return new ExecutionAuthorityDecision(false, array_values(array_unique($reasons)), null, $this->lineage($intent, $plan));
        }


        if (($executionRequest['runtime_integrity_required'] ?? false) === true) {
            $receipt = $executionRequest['runtime_integrity_receipt'] ?? null;
            $workload = $executionRequest['workload_identity'] ?? null;
            if (!is_array($receipt) || ($receipt['runtime_integrity_valid'] ?? null) !== true) {
                $reasons[] = 'runtime_integrity_evidence_required';
            } elseif (!is_array($workload)) {
                $reasons[] = 'runtime_integrity_workload_identity_required';
            } else {
                if (($receipt['workload_id'] ?? null) !== ($workload['workload_id'] ?? null)) $reasons[] = 'runtime_integrity_workload_id_mismatch';
                if (($receipt['workload_binding_id'] ?? null) !== ($workload['binding_id'] ?? null)) $reasons[] = 'runtime_integrity_workload_binding_mismatch';
                if (($receipt['evidence_only'] ?? null) !== true || ($receipt['authority_granted'] ?? null) !== false) $reasons[] = 'runtime_integrity_receipt_authority_confusion';
            }
        }

        $actor = $executionRequest['actor'] ?? [];
        if (($actor['actor_type'] ?? null) !== 'human') $reasons[] = 'advanced_intelligence_cannot_inherit_t0gm_execution_authority';
        if (($actor['actor_id'] ?? null) !== ($capability['authority_holder']['identity_id'] ?? null)) $reasons[] = 'execution_actor_not_capability_holder';

        $capabilityRequest = [
            'company_id' => $executionRequest['company_id'] ?? null,
            'target' => $executionRequest['target'] ?? [],
            'operation' => $executionRequest['operation'] ?? null,
            'resource_id' => $executionRequest['resource_id'] ?? null,
            'risk' => $executionRequest['risk'] ?? [],
            'evidence_ids' => $executionRequest['evidence_ids'] ?? [],
            'triggered_extinction_conditions' => $executionRequest['triggered_extinction_conditions'] ?? [],
        ];
        $capabilityDecision = $this->capabilityEvaluator->evaluate($capability, $capabilityRequest);
        if (!$capabilityDecision->allowed) {
            foreach ($capabilityDecision->reasons as $reason) $reasons[] = 'execution_capability_denied:' . $reason;
        }

        return new ExecutionAuthorityDecision(
            $reasons === [],
            array_values(array_unique($reasons)),
            $capabilityDecision->matchedEffectId,
            $this->lineage($intent, $plan, $capability['capability_id'] ?? null),
        );
    }

    private function lineage(array $intent, array $plan, ?string $capabilityId = null): array
    {
        return array_filter([
            'intent_id' => $intent['artifact_id'] ?? null,
            'plan_id' => $plan['artifact_id'] ?? null,
            'execution_capability_id' => $capabilityId,
        ], static fn($v) => $v !== null);
    }
}
