<?php
namespace Titan\GodMode\Custody;

interface SecureEnclaveBroker
{
    /** Signing happens outside the Titan PHP process; only detached signature bytes return. */
    public function sign(string $providerId,string $keyId,string $suite,string $message,array $context=[]): string;
}
