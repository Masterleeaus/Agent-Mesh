<?php
namespace Titan\GodMode\Adapter;

final class TargetAdapterRegistry
{
    /** @var TargetAdapter[] */
    private array $adapters;

    public function __construct(?array $adapters = null)
    {
        $this->adapters = $adapters ?? [
            new LaravelApplicationAdapter(),
            new DatabaseAdapter(),
            new LinuxServerAdapter(),
            new BrowserPwaAdapter(),
            new CloudApiAdapter(),
            new AiWorkerControlAdapter(),
        ];
    }

    public function resolve(array $target): TargetAdapter
    {
        $matches = array_values(array_filter($this->adapters, static fn(TargetAdapter $adapter) => $adapter->supports($target)));
        if (count($matches) !== 1) throw new TargetAdapterException(count($matches) === 0 ? 'no_target_adapter' : 'ambiguous_target_adapter');
        return $matches[0];
    }

    public function types(): array { return array_map(static fn(TargetAdapter $a) => $a->adapterType(), $this->adapters); }
}
