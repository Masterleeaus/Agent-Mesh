<?php
namespace Titan\GodMode\Notification;

use Titan\GodMode\Security\CanonicalJson;

final class FilePersistentNotificationStateStore
{
    public function __construct(private readonly string $directory)
    {
        if(!is_dir($directory) && !mkdir($directory,0700,true) && !is_dir($directory)) throw new \RuntimeException('notification-state-directory-create-failed');
    }
    public function create(array $state): array
    {
        foreach(['notification_id','event_id','company_id','severity','endpoints','created_at'] as $f) if(!array_key_exists($f,$state)) throw new \RuntimeException('notification-state-field-required:'.$f);
        $id=trim((string)$state['notification_id']); if($id==='') throw new \RuntimeException('notification-id-required');
        $path=$this->path($id);
        if(is_file($path)) { $existing=$this->get($id); if(($existing['registration_digest']??'')===($this->registrationDigest($state))) return $existing; throw new \RuntimeException('notification-id-conflict'); }
        $state['schema']='titan.t0gm.persistent-notification-state.v1';
        $state['status']='pending'; $state['attempts']=$state['attempts']??[]; $state['acknowledgements']=$state['acknowledgements']??[]; $state['escalations']=$state['escalations']??[];
        $state['next_attempt_at']=$state['next_attempt_at']??$state['created_at']; $state['escalation_level']=$state['escalation_level']??0;
        $state['registration_digest']=$this->registrationDigest($state); $state['grants_authority']=false;
        return $this->write($id,$state,false);
    }
    public function get(string $id): array { $p=$this->path($id); if(!is_file($p)) throw new \RuntimeException('notification-state-not-found'); $v=json_decode((string)file_get_contents($p),true,512,JSON_THROW_ON_ERROR); return $v; }
    public function save(array $state): array { return $this->write((string)$state['notification_id'],$state,true); }
    public function all(): array { $out=[]; foreach(glob($this->directory.'/*.json')?:[] as $p) $out[]=json_decode((string)file_get_contents($p),true,512,JSON_THROW_ON_ERROR); return $out; }
    private function write(string $id,array $state,bool $overwrite): array { $path=$this->path($id); $tmp=$path.'.tmp.'.bin2hex(random_bytes(4)); file_put_contents($tmp,CanonicalJson::encode($state),LOCK_EX); @chmod($tmp,0600); if(!$overwrite && is_file($path)){@unlink($tmp); throw new \RuntimeException('notification-state-exists');} if(!rename($tmp,$path)) throw new \RuntimeException('notification-state-write-failed'); return $state; }
    private function path(string $id): string { if(!preg_match('/^[A-Za-z0-9._:-]+$/',$id)) throw new \RuntimeException('notification-id-invalid'); return rtrim($this->directory,'/').'/'.$id.'.json'; }
    private function registrationDigest(array $s): string { foreach(['schema','status','attempts','acknowledgements','escalations','next_attempt_at','escalation_level','registration_digest','grants_authority'] as $k) unset($s[$k]); return 'sha256:'.hash('sha256',CanonicalJson::encode($s)); }
}
