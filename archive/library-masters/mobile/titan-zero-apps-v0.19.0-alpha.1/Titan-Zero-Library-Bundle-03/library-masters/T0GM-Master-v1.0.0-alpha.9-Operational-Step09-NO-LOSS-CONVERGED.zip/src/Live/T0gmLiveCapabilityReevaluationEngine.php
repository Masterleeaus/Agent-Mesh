<?php
namespace Titan\GodMode\Live;

use Titan\GodMode\Continuance\AuthorityContinuanceEngine;

/**
 * Continuously converts fresh world evidence into a continuance decision.
 * This engine can reduce or extinguish existing authority, but never mint or expand it.
 */
final class T0gmLiveCapabilityReevaluationEngine
{
    private const FORBIDDEN_WORLD_KEYS=['tenant_id','tenant_company_id','tenantId','tenantCompanyId'];
    public function __construct(
        private readonly T0gmActiveCapabilityRegistry $registry,
        private readonly T0gmWorldStateProvider $world,
        private readonly AuthorityContinuanceEngine $continuance=new AuthorityContinuanceEngine(),
        private readonly T0gmWorldStateDigest $digest=new T0gmWorldStateDigest(),
    ){}
    public function reevaluateAll(): array
    {
        $out=[];
        foreach($this->registry->evaluable() as $id=>$state) $out[$id]=$this->reevaluate($id);
        return $out;
    }
    public function reevaluate(string $capabilityId): array
    {
        $state=$this->registry->state($capabilityId);
        if($state['status']==='terminated') throw new \RuntimeException('terminated-capability-cannot-be-reevaluated');
        $capability=$state['capability'];
        $world=$this->world->currentFor($capability);
        $this->validateWorld($world);
        $decision=$this->continuance->evaluate($capability,$world);
        $record=[
            'schema'=>'titan.t0gm.live-capability-reevaluation.v1',
            'reevaluation_id'=>'t0gm_lcr_'.bin2hex(random_bytes(12)),
            'capability_id'=>$capabilityId,
            'company_id'=>$capability['company_id'],
            'world_revision'=>(string)($world['world_revision']??''),
            'observed_at'=>(string)($world['observed_at']??''),
            'world_state_digest'=>$this->digest->digest($world),
            'outcome'=>$decision->outcome,
            'reasons'=>$decision->reasons,
            'retained_effect_ids'=>$decision->retainedEffectIds,
            'transformation_request'=>$decision->transformationRequest,
            'authority_granted'=>false,
            'company_authority_granted'=>false,
            't0gm_authority_granted'=>false,
            'authority_expanded'=>false,
            'time_is_authority_source'=>false,
        ];
        $this->registry->apply($capabilityId,$decision,$record);
        return $record;
    }
    private function validateWorld(array $world): void
    {
        if(trim((string)($world['world_revision']??''))==='') throw new \RuntimeException('world-revision-required');
        if(trim((string)($world['observed_at']??''))==='') throw new \RuntimeException('world-observation-time-required');
        $this->rejectLegacyTenantKeys($world);
    }
    private function rejectLegacyTenantKeys(array $value,string $path=''): void
    {
        foreach($value as $key=>$child){
            $p=$path===''?(string)$key:$path.'.'.$key;
            if(in_array((string)$key,self::FORBIDDEN_WORLD_KEYS,true)) throw new \RuntimeException('legacy-tenant-boundary-forbidden:'.$p);
            if(is_array($child))$this->rejectLegacyTenantKeys($child,$p);
        }
    }
}
