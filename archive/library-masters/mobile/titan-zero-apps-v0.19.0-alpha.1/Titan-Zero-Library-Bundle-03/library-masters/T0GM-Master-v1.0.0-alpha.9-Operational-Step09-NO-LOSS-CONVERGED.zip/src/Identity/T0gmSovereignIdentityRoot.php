<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

/**
 * Step 25 hybrid sovereign identity verifier.
 * Identity proof remains non-tenant. Business/company authority is evaluated later
 * by the Sovereign Capability Fabric and client/jurisdiction overlays.
 */
final class T0gmSovereignIdentityRoot
{
    public function __construct(
        private readonly T0gmVerifierTrustStore $identityRoots,
        private readonly T0gmHardwareAttestation $hardware,
        private readonly T0gmCryptoSuiteRegistry $crypto,
        private readonly T0gmCryptoProfileRegistry $profiles,
        private readonly T0gmZeroKnowledgeProofGate $zk,
        private readonly NonceStore $nonces,
        private readonly array $policy,
        private readonly ?T0gmDeviceTrustRegistry $devices = null
    ) {}

    public function verify(array $proof, ?int $now=null): array
    {
        $now??=time();
        foreach (['payload','signatures','hardware_attestation','zero_knowledge_proof'] as $f) {
            if (!array_key_exists($f,$proof)) throw new GodModeException('sovereign-identity-proof-missing:' . $f);
        }
        $p=(array)$proof['payload'];
        foreach (['schema','authority','principal_class','principal_id','device_key_id','device_public_key','audience','challenge','issued_at','proof_expires_at','non_tenant','crypto_profile_id'] as $f) {
            if (!array_key_exists($f,$p)) throw new GodModeException('sovereign-identity-payload-missing:' . $f);
        }
        if ($p['schema']!=='titan.t0gm.sovereign_identity_proof.v2') throw new GodModeException('wrong-sovereign-identity-schema');
        foreach (['authority','principal_class','principal_id','audience'] as $f) {
            if ((string)$p[$f] !== (string)$this->policy[$f]) throw new GodModeException('wrong-' . str_replace('_','-',$f));
        }
        if ($p['non_tenant']!==true) throw new GodModeException('t0gm-identity-must-be-non-tenant');
        foreach (['company_id','tenant_id','tenant_company_id','role_id','user_id','permission_id'] as $forbidden) {
            if (array_key_exists($forbidden,$p)) throw new GodModeException('application-identity-binding-forbidden:' . $forbidden);
        }
        $skew=(int)($this->policy['clock_skew_seconds']??30);
        if ($now+$skew < (int)$p['issued_at'] || $now-$skew > (int)$p['proof_expires_at']) throw new GodModeException('sovereign-identity-proof-outside-verification-window');
        if (trim((string)$p['challenge'])==='' || trim((string)$p['device_key_id'])==='') throw new GodModeException('sovereign-identity-binding-incomplete');
        $devicePublic=base64_decode((string)$p['device_public_key'],true);
        if ($devicePublic===false || $devicePublic==='') throw new GodModeException('invalid-identity-device-public-key');

        $profile=$this->profiles->profile((string)$p['crypto_profile_id']);
        $zkPublicKeyField=(string)($profile['zk_public_key_payload_field']??'');
        if ($zkPublicKeyField!=='' && (!array_key_exists($zkPublicKeyField,$p) || trim((string)$p[$zkPublicKeyField])==='')) {
            throw new GodModeException('sovereign-identity-payload-missing:' . $zkPublicKeyField);
        }
        $verifiedSuites=[]; $verifiedKeys=[];
        foreach ((array)$proof['signatures'] as $sigEntry) {
            if (!is_array($sigEntry)) continue;
            foreach (['key_id','suite','signature'] as $f) if (!array_key_exists($f,$sigEntry)) throw new GodModeException('sovereign-signature-missing:' . $f);
            $key=$this->identityRoots->keyForVerification((string)$sigEntry['key_id'],(int)$p['issued_at']);
            if ($key['suite']!==(string)$sigEntry['suite']) throw new GodModeException('sovereign-signature-suite-key-mismatch');
            $sig=base64_decode((string)$sigEntry['signature'],true);
            if ($sig===false || !$this->crypto->verify((string)$sigEntry['suite'],$sig,CanonicalJson::encode($p),$key['public_key'])) throw new GodModeException('invalid-sovereign-signature:' . $sigEntry['suite']);
            $verifiedSuites[(string)$sigEntry['suite']]=true; $verifiedKeys[(string)$sigEntry['key_id']]=true;
        }
        foreach ($profile['required_signature_suites'] as $suite) if (!isset($verifiedSuites[$suite])) throw new GodModeException('required-sovereign-signature-missing:' . $suite);
        if (count($verifiedKeys)<(int)$profile['required_distinct_key_ids']) throw new GodModeException('insufficient-distinct-sovereign-signing-keys');

        $att=$this->hardware->verify((array)$proof['hardware_attestation'],[
            'device_key_id'=>(string)$p['device_key_id'],
            'device_public_key_hash'=>hash('sha256',$devicePublic),
            'challenge'=>(string)$p['challenge'],
        ],$now,$skew);

        if (($profile['zk_statement_policy']??null)==='minimal-authorization-v1') {
            $statement=(new T0gmZkStatementMinimizer())->fromSovereignIdentity([
                'authority'=>(string)$p['authority'],
                'principal_class'=>(string)$p['principal_class'],
                'principal_id'=>(string)$p['principal_id'],
                'device_key_id'=>(string)$p['device_key_id'],
                'device_public_key_hash'=>hash('sha256',$devicePublic),
                'audience'=>(string)$p['audience'],
                'challenge'=>(string)$p['challenge'],
                'crypto_profile_id'=>(string)$p['crypto_profile_id'],
                $zkPublicKeyField=>(string)$p[$zkPublicKeyField],
            ],$zkPublicKeyField);
        } else {
            $statement=[
                'authority'=>(string)$p['authority'],
                'principal_class'=>(string)$p['principal_class'],
                'principal_id'=>(string)$p['principal_id'],
                'device_key_id'=>(string)$p['device_key_id'],
                'device_public_key_hash'=>hash('sha256',$devicePublic),
                'audience'=>(string)$p['audience'],
                'challenge'=>(string)$p['challenge'],
                'crypto_profile_id'=>(string)$p['crypto_profile_id'],
                'claim'=>'sovereign-secret-possession-without-secret-disclosure',
            ];
            if ($zkPublicKeyField!=='') $statement['possession_public_key']=(string)$p[$zkPublicKeyField];
        }
        $zk=$this->zk->verify((array)$proof['zero_knowledge_proof'],$statement,(array)$profile['allowed_zk_systems']);

        $deviceBinding=$this->devices?->bindingForCurrentUse((string)$p['device_key_id'],(string)$p['principal_id'],$devicePublic,$now);

        if (!$this->nonces->consume('t0gm-sovereign-identity:' . $p['device_key_id'],(string)$p['challenge'],(int)$p['proof_expires_at'])) throw new GodModeException('sovereign-identity-proof-replay-detected');

        return [
            'authority'=>(string)$p['authority'],
            'authority_class'=>'titan.god_mode',
            'principal_class'=>(string)$p['principal_class'],
            'principal_id'=>(string)$p['principal_id'],
            'device_key_id'=>(string)$p['device_key_id'],
            'device_public_key_raw'=>$devicePublic,
            'hardware_attestation'=>$att,
            'device_binding'=>$deviceBinding,
            'crypto_profile_id'=>(string)$p['crypto_profile_id'],
            'verified_signature_suites'=>array_keys($verifiedSuites),
            'verified_signature_key_ids'=>array_keys($verifiedKeys),
            'zero_knowledge'=>$zk,
            'kem_preferences'=>(array)$profile['kem_preferences'],
            'identity_schema'=>(string)$p['schema'],
            'cryptographic_identity'=>true,
            'post_quantum_identity'=>in_array('ml-dsa-65',array_keys($verifiedSuites),true),
            'application_role_authority'=>false,
            'company_authority_embedded'=>false,
        ];
    }
}
