<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\ZeroKnowledgeVerifier;
use Titan\GodMode\Security\GodModeException;

final class T0gmZeroKnowledgeProviderRegistry
{
    /** @var array<string,ZeroKnowledgeVerifier> */
    private array $providers;

    /** @param array<string,ZeroKnowledgeVerifier> $providers */
    public function __construct(array $providers)
    {
        if ($providers === []) throw new GodModeException('zk-provider-registry-empty');
        foreach ($providers as $system => $provider) {
            if (!is_string($system) || $system === '') throw new GodModeException('zk-proof-system-id-invalid');
            if (!$provider instanceof ZeroKnowledgeVerifier) throw new GodModeException('zk-provider-invalid:' . $system);
        }
        $this->providers = $providers;
    }

    /** @return array<string,ZeroKnowledgeVerifier> */
    public function verifiers(): array { return $this->providers; }

    public function verifier(string $system): ZeroKnowledgeVerifier
    {
        if (!isset($this->providers[$system])) throw new GodModeException('zk-verifier-unavailable:' . $system);
        return $this->providers[$system];
    }
}
