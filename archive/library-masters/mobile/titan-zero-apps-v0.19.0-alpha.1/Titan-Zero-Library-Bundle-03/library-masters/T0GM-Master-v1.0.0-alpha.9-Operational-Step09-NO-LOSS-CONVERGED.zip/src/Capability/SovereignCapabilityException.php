<?php
namespace Titan\GodMode\Capability;

final class SovereignCapabilityException extends \RuntimeException
{
    public function __construct(string $reason, public readonly ?string $path = null)
    {
        parent::__construct($path === null ? $reason : $reason . ':' . $path);
    }
}
