<?php
namespace Titan\GodMode\Notification;

interface T0gmNotificationTransport
{
    public function channel(): string;
    public function deliver(T0gmNotificationMessage $message,T0gmNotificationEndpoint $endpoint): T0gmNotificationDeliveryReceipt;
}
