<?php
namespace Titan\GodMode\Command;
use Titan\GodMode\Security\GodModeException;
final class T0gmCommandTargetRegistry
{
    private array $targets=[];
    public function __construct(array $targets=[]){foreach($targets as $t)$this->register($t);}
    public function register(array $t):void
    {
        foreach(['target_type','target_id','company_id','label'] as $f)if(trim((string)($t[$f]??''))==='')throw new GodModeException('palette-target-field-required:'.$f);
        foreach(['tenant_id','tenant_company_id'] as $f)if(array_key_exists($f,$t))throw new GodModeException('legacy-tenant-boundary-forbidden:'.$f);
        if(!in_array($t['target_type'],['company','system','agent','workflow','infrastructure'],true))throw new GodModeException('unsupported-palette-target-type');
        $key=$this->key($t['target_type'],$t['target_id'],$t['company_id']); if(isset($this->targets[$key]))throw new GodModeException('duplicate-palette-target');
        $this->targets[$key]=['schema'=>'titan.t0gm.command_target.v1','target_type'=>(string)$t['target_type'],'target_id'=>(string)$t['target_id'],'company_id'=>(string)$t['company_id'],'label'=>(string)$t['label'],'keywords'=>array_values(array_unique(array_map('strval',(array)($t['keywords']??[])))),'metadata'=>(array)($t['metadata']??[]),'projection_only'=>true,'authority_granted'=>false];
    }
    public function search(string $query,int $limit=50):array
    {
        $q=strtolower(trim($query)); if($limit<1||$limit>500)throw new GodModeException('invalid-palette-search-limit'); $out=[];
        foreach($this->targets as $t){$hay=strtolower(implode(' ',array_merge([$t['target_type'],$t['target_id'],$t['company_id'],$t['label']],$t['keywords']))); if($q===''||str_contains($hay,$q))$out[]=$t;}
        usort($out,fn($a,$b)=>[$a['label'],$a['target_id']]<=>[$b['label'],$b['target_id']]); return array_slice($out,0,$limit);
    }
    public function get(string $type,string $id,string $companyId):array
    { $key=$this->key($type,$id,$companyId); if(!isset($this->targets[$key]))throw new GodModeException('palette-target-not-found'); return $this->targets[$key]; }
    public function resolveAnyCompany(string $type,string $id):array
    { $found=[]; foreach($this->targets as $t)if($t['target_type']===$type&&$t['target_id']===$id)$found[]=$t; if(count($found)!==1)throw new GodModeException(count($found)?'palette-target-company-ambiguous':'palette-target-not-found'); return $found[0]; }
    private function key(string $type,string $id,string $company):string{return $type.'|'.$id.'|'.$company;}
}
