<?php
namespace Titan\GodMode\Security;

final class CanonicalJson
{
    public static function encode(mixed $value): string
    {
        return json_encode(
            self::sort($value),
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
        );
    }

    private static function sort(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map([self::class, 'sort'], $value);
        }

        ksort($value, SORT_STRING);
        foreach ($value as $k => $v) {
            $value[$k] = self::sort($v);
        }
        return $value;
    }
}
