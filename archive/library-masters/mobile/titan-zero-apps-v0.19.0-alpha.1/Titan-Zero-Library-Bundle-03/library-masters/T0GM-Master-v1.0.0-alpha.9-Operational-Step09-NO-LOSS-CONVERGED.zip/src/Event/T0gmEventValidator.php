<?php
namespace Titan\GodMode\Event;

final class T0gmEventValidator
{
    private const LEGACY_TENANT_KEYS = ['tenant_id', 'tenant_company_id', 'tenantId', 'tenantCompanyId'];
    private const ACTOR_TYPES = ['human', 'advanced_intelligence', 'system', 'device', 'workload', 'external'];
    private const RISK_BANDS = ['minimal', 'low', 'medium', 'high', 'extreme', 'unknown'];
    private const ATTENTION_TIERS = ['routine', 'watch', 'important', 'urgent', 'critical'];

    public function validate(array $event): array
    {
        $this->rejectLegacyTenantKeys($event);

        $this->requireExact($event, 'schema', 'titan.t0gm.event.v1');
        $this->requireString($event, 'event_id');
        $this->requireEnum($event, 'event_kind', T0gmEventKind::all());
        $this->requireString($event, 'occurred_at');
        $this->requireString($event, 'recorded_at');
        $this->requireArray($event, 'company_context');
        $this->requireArray($event, 'actor');
        $this->requireArray($event, 'source');
        $this->requireArray($event, 'subject');
        $this->requireArray($event, 'lineage');
        $this->requireArray($event, 'risk');
        $this->requireArray($event, 'oversight');
        $this->requireArray($event, 'evidence');

        $company = $event['company_context'];
        if (($company['scope'] ?? null) === 'company') {
            $this->requireString($company, 'company_id', 'company_context.company_id');
        } elseif (($company['scope'] ?? null) !== 'platform') {
            throw new T0gmEventException('invalid-company-scope');
        }

        $actor = $event['actor'];
        $this->requireEnum($actor, 'actor_type', self::ACTOR_TYPES, 'actor.actor_type');
        $this->requireString($actor, 'actor_id', 'actor.actor_id');

        $source = $event['source'];
        $this->requireString($source, 'system', 'source.system');
        $this->requireString($source, 'component', 'source.component');

        $subject = $event['subject'];
        $this->requireString($subject, 'subject_type', 'subject.subject_type');
        $this->requireString($subject, 'subject_id', 'subject.subject_id');

        $lineage = $event['lineage'];
        $this->requireString($lineage, 'trace_id', 'lineage.trace_id');
        $this->requireString($lineage, 'correlation_id', 'lineage.correlation_id');
        if (isset($lineage['causation_id']) && !is_string($lineage['causation_id'])) {
            throw new T0gmEventException('invalid-causation-id');
        }
        foreach (($lineage['parent_event_ids'] ?? []) as $parent) {
            if (!is_string($parent) || $parent === '') throw new T0gmEventException('invalid-parent-event-id');
        }

        $risk = $event['risk'];
        if (!isset($risk['score']) || !is_int($risk['score']) || $risk['score'] < 0 || $risk['score'] > 100) {
            throw new T0gmEventException('invalid-risk-score');
        }
        $this->requireEnum($risk, 'band', self::RISK_BANDS, 'risk.band');
        if (isset($risk['dimensions']) && !is_array($risk['dimensions'])) {
            throw new T0gmEventException('invalid-risk-dimensions');
        }

        $oversight = $event['oversight'];
        $this->requireExact($oversight, 'visibility', 't0gm_sovereign', 'oversight.visibility');
        $this->requireEnum($oversight, 'attention_tier', self::ATTENTION_TIERS, 'oversight.attention_tier');
        if (!isset($oversight['review_required']) || !is_bool($oversight['review_required'])) {
            throw new T0gmEventException('invalid-review-required');
        }

        foreach ($event['evidence'] as $i => $evidence) {
            if (!is_array($evidence)) throw new T0gmEventException('invalid-evidence-ref');
            $this->requireString($evidence, 'evidence_id', "evidence.$i.evidence_id");
            $this->requireString($evidence, 'evidence_type', "evidence.$i.evidence_type");
            $this->requireString($evidence, 'source', "evidence.$i.source");
        }

        if (isset($event['attention_signals'])) {
            if (!is_array($event['attention_signals'])) throw new T0gmEventException('invalid-attention-signals');
            foreach (['significance','anomaly','urgency','reversibility','financial_exposure','physical_impact','environmental_impact','confidence','dependency'] as $field) {
                if (!array_key_exists($field, $event['attention_signals'])) continue;
                $value = $event['attention_signals'][$field];
                if (!is_int($value) || $value < 0 || $value > 100) throw new T0gmEventException('invalid-attention-signal', 'attention_signals.' . $field);
            }
            if (isset($event['attention_signals']['domains'])) {
                if (!is_array($event['attention_signals']['domains'])) throw new T0gmEventException('invalid-attention-domains');
                foreach ($event['attention_signals']['domains'] as $domain) {
                    if (!is_string($domain) || trim($domain) === '') throw new T0gmEventException('invalid-attention-domain');
                }
            }
        }

        $this->validateKindSpecific($event);
        return $event;
    }

    private function validateKindSpecific(array $event): void
    {
        $kind = $event['event_kind'];
        if ($kind === T0gmEventKind::OBSERVATION) {
            $this->requireArray($event, 'observation');
            $this->requireString($event['observation'], 'summary', 'observation.summary');
        }
        if ($kind === T0gmEventKind::AI_DECISION) {
            $this->requireArray($event, 'decision');
            $this->requireString($event['decision'], 'decision_id', 'decision.decision_id');
            $this->requireString($event['decision'], 'determination', 'decision.determination');
            $this->requireArray($event['decision'], 'reason_codes', 'decision.reason_codes');
        }
        if ($kind === T0gmEventKind::HUMAN_ACTION) {
            if (($event['actor']['actor_type'] ?? null) !== 'human') throw new T0gmEventException('human-action-requires-human-actor');
            $this->requireArray($event, 'action');
            $this->requireString($event['action'], 'action', 'action.action');
        }
        if ($kind === T0gmEventKind::AUTHORITY_USE) {
            $this->requireArray($event, 'authority');
            $this->requireString($event['authority'], 'authority_class', 'authority.authority_class');
            $this->requireString($event['authority'], 'authority_basis', 'authority.authority_basis');
            if (($event['authority']['authority_class'] ?? null) === 'titan.god_mode') {
                $this->requireString($event['authority'], 'capability_id', 'authority.capability_id');
            }
        }
        if ($kind === T0gmEventKind::EXECUTION) {
            $this->requireArray($event, 'execution');
            $this->requireString($event['execution'], 'execution_id', 'execution.execution_id');
            $this->requireString($event['execution'], 'state', 'execution.state');
            $this->requireString($event['execution'], 'adapter', 'execution.adapter');
        }
        if ($kind === T0gmEventKind::RESULT) {
            $this->requireArray($event, 'result');
            $this->requireString($event['result'], 'result_state', 'result.result_state');
            $this->requireString($event['result'], 'verification_state', 'result.verification_state');
        }
        if ($kind === T0gmEventKind::ANOMALY) {
            $this->requireArray($event, 'anomaly');
            $this->requireString($event['anomaly'], 'anomaly_type', 'anomaly.anomaly_type');
            $this->requireString($event['anomaly'], 'summary', 'anomaly.summary');
        }
        if ($kind === T0gmEventKind::INTERVENTION) {
            $this->requireArray($event, 'intervention');
            $this->requireString($event['intervention'], 'intervention_id', 'intervention.intervention_id');
            $this->requireString($event['intervention'], 'directive', 'intervention.directive');
        }
        if ($kind === T0gmEventKind::SUPERSESSION) {
            $this->requireArray($event, 'supersession');
            $this->requireString($event['supersession'], 'supersession_id', 'supersession.supersession_id');
            $ids = $event['supersession']['supersedes_event_ids'] ?? null;
            if (!is_array($ids) || $ids === []) throw new T0gmEventException('supersession-requires-targets');
            foreach ($ids as $id) if (!is_string($id) || $id === '') throw new T0gmEventException('invalid-supersession-target');
            if (($event['actor']['authority_class'] ?? null) !== 'titan.god_mode') {
                throw new T0gmEventException('sovereign-supersession-requires-t0gm');
            }
        }
    }

    private function rejectLegacyTenantKeys(array $value, string $path = ''): void
    {
        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string)$key : $path . '.' . $key;
            if (in_array((string)$key, self::LEGACY_TENANT_KEYS, true)) {
                throw new T0gmEventException('legacy-tenant-boundary-forbidden', $childPath);
            }
            if (is_array($child)) $this->rejectLegacyTenantKeys($child, $childPath);
        }
    }

    private function requireString(array $a, string $key, ?string $path = null): void
    {
        if (!isset($a[$key]) || !is_string($a[$key]) || trim($a[$key]) === '') {
            throw new T0gmEventException('missing-or-invalid-field', $path ?? $key);
        }
    }
    private function requireArray(array $a, string $key, ?string $path = null): void
    {
        if (!array_key_exists($key, $a) || !is_array($a[$key])) {
            throw new T0gmEventException('missing-or-invalid-field', $path ?? $key);
        }
    }
    private function requireExact(array $a, string $key, string $expected, ?string $path = null): void
    {
        if (($a[$key] ?? null) !== $expected) throw new T0gmEventException('invalid-fixed-field', $path ?? $key);
    }
    private function requireEnum(array $a, string $key, array $allowed, ?string $path = null): void
    {
        if (!isset($a[$key]) || !in_array($a[$key], $allowed, true)) {
            throw new T0gmEventException('invalid-enum-field', $path ?? $key);
        }
    }
}
