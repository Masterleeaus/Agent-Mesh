<?php
namespace Titan\GodMode\PolicyDistribution;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmPolicyBundleVerifier
{
    public function __construct(private readonly T0gmSignedPolicyTrustStore $trust,private readonly T0gmPolicyAcceptanceStore $acceptance){}
    public function verifyAndAccept(array $envelope,int $now,array $expect=[]):array
    {
        if(($envelope['schema']??null)!=='titan.t0gm.signed-policy-envelope.v1'||!is_array($envelope['bundle']??null))throw new GodModeException('signed-policy-envelope-invalid');
        $b=$envelope['bundle'];
        foreach(['schema','policy_class','policy_id','scope','revision','issued_at','effective_from','content','content_digest','semantics'] as $f)if(!array_key_exists($f,$b))throw new GodModeException('signed-policy-missing-field:'.$f);
        if($b['schema']!=='titan.t0gm.signed-policy-bundle.v1'||!in_array($b['policy_class'],['constitution','policy','overlay','configuration'],true))throw new GodModeException('signed-policy-bundle-invalid');
        if(!is_array($b['content'])||!is_array($b['scope']))throw new GodModeException('signed-policy-structure-invalid');
        $expectedDigest='sha256:'.hash('sha256',CanonicalJson::encode($b['content']));
        if(!hash_equals($expectedDigest,(string)$b['content_digest']))throw new GodModeException('signed-policy-content-digest-mismatch');
        $issued=(int)$b['issued_at'];$effective=(int)$b['effective_from'];
        if($issued<=0||$effective<=0||$now<$effective)throw new GodModeException('signed-policy-not-effective');
        $keyId=(string)($envelope['signer_key_id']??'');$suite=(string)($envelope['signature_suite']??'');
        if($suite!=='ed25519')throw new GodModeException('signed-policy-suite-not-supported');
        $key=$this->trust->keyForVerification($keyId,(string)$b['policy_class'],$issued);
        $sig=base64_decode((string)($envelope['signature']??''),true);
        if($sig===false||strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES||!sodium_crypto_sign_verify_detached($sig,CanonicalJson::encode($b),$key['public_key']))throw new GodModeException('signed-policy-signature-invalid');
        $scopeType=(string)($b['scope']['scope_type']??'');$companyId=$b['scope']['company_id']??null;
        if(!in_array($scopeType,['platform','company','jurisdiction','industry'],true))throw new GodModeException('signed-policy-scope-invalid');
        if($scopeType==='company'&&(!is_string($companyId)||$companyId===''))throw new GodModeException('signed-policy-company-id-required');
        if($scopeType!=='company'&&$companyId!==null)throw new GodModeException('signed-policy-company-id-unexpected');
        if(isset($expect['expected_policy_class'])&&$expect['expected_policy_class']!==$b['policy_class'])throw new GodModeException('signed-policy-class-mismatch');
        if(array_key_exists('expected_company_id',$expect)&&$expect['expected_company_id']!==$companyId)throw new GodModeException('signed-policy-company-scope-mismatch');
        $revision=(int)$b['revision'];$sup=$b['supersedes_revision']??null;
        if($sup!==null&&((int)$sup>=$revision||(int)$sup<1))throw new GodModeException('signed-policy-supersession-invalid');
        $stream=hash('sha256',CanonicalJson::encode(['policy_class'=>$b['policy_class'],'policy_id'=>$b['policy_id'],'scope'=>$b['scope']]));
        $this->acceptance->accept($stream,$revision,$expectedDigest);
        return [
            'accepted'=>true,'policy_class'=>$b['policy_class'],'policy_id'=>$b['policy_id'],'revision'=>$revision,'company_id'=>$companyId,
            'content_digest'=>substr($expectedDigest,7),'signer_key_id'=>$keyId,'signature_valid'=>true,'signature_grants_authority'=>false,
            'authority_granted'=>false,'company_authority_granted'=>false,'t0gm_authority_granted'=>false,'governance_eligibility'=>'verified_distribution_only',
        ];
    }
}
