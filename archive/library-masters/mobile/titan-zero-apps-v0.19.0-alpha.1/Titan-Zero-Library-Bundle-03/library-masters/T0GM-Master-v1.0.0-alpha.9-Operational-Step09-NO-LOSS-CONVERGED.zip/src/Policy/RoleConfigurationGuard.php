<?php
namespace Titan\GodMode\Policy;

use Titan\GodMode\Security\GodModeException;

final class RoleConfigurationGuard
{
    public function __construct(private readonly array $forbiddenMarkers) {}

    public function validateRoleDefinition(array $role): void
    {
        $flatten = $this->flatten($role);
        foreach ($flatten as $value) {
            $v = strtolower($value);
            foreach ($this->forbiddenMarkers as $marker) {
                if (str_contains($v, strtolower((string) $marker))) {
                    throw new GodModeException('god-mode-role-recreation-forbidden');
                }
            }
        }
    }

    public function validatePromotion(array $fromRoles, array $toRoles): void
    {
        foreach (array_merge($fromRoles, $toRoles) as $role) {
            $this->validateRoleDefinition(is_array($role) ? $role : ['name' => (string) $role]);
        }
    }

    private function flatten(mixed $value): array
    {
        if (is_scalar($value)) return [(string) $value];
        if (!is_array($value)) return [];
        $out = [];
        foreach ($value as $v) $out = array_merge($out, $this->flatten($v));
        return $out;
    }
}
