<?php
namespace Titan\GodMode\Recovery;

use Titan\GodMode\Security\CanonicalJson;

final class T0gmStateTransitionHasher
{
    public function hashState(array $state): string { return hash('sha256', CanonicalJson::encode($state)); }
    public function seal(array $transition): array
    {
        unset($transition['integrity']);
        $transition['integrity']=['algorithm'=>'sha256','canonical_hash'=>hash('sha256',CanonicalJson::encode($transition))];
        return $transition;
    }
    public function verify(array $transition): bool
    {
        $expected=$transition['integrity']['canonical_hash']??''; if(!is_string($expected)||$expected==='') return false;
        unset($transition['integrity']);
        return hash_equals($expected,hash('sha256',CanonicalJson::encode($transition)));
    }
}
