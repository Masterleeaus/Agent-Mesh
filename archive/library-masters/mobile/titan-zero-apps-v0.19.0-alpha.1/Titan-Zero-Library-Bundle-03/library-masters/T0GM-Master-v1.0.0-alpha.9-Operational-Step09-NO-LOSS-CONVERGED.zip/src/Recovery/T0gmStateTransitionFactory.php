<?php
namespace Titan\GodMode\Recovery;

final class T0gmStateTransitionFactory
{
    public function __construct(private readonly T0gmStateTransitionHasher $hasher=new T0gmStateTransitionHasher(),private readonly T0gmStateTransitionValidator $validator=new T0gmStateTransitionValidator()){}
    public function make(string $companyId,string $sourceEventId,string $purpose,array $subject,array $preState,array $intended,array $actual,array $dependencies,array $reversibility,array $evidence=[]):array
    {
        $t=['schema'=>'titan.t0gm.state-transition.v1','transition_id'=>'t0gm_tr_'.bin2hex(random_bytes(12)),'company_id'=>$companyId,'source_event_id'=>$sourceEventId,'purpose'=>$purpose,'subject'=>$subject,
            'pre_state'=>['state'=>$preState,'hash'=>$this->hasher->hashState($preState)],
            'intended_result'=>['state'=>$intended,'hash'=>$this->hasher->hashState($intended)],
            'actual_result'=>['state'=>$actual,'hash'=>$this->hasher->hashState($actual)],
            'dependencies'=>$dependencies,'reversibility'=>$reversibility,'evidence'=>$evidence];
        return $this->hasher->seal($this->validator->validate($t));
    }
}
