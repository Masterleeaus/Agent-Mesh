<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

/** Crypto policy is versioned independently from authority/capability semantics. */
final class T0gmCryptoProfileRegistry
{
    public const HYBRID_PQC_V1 = 't0gm-hybrid-pqc-v1';
    public const HYBRID_PQC_ZK_V2 = 't0gm-hybrid-pqc-zk-v2';
    public const HYBRID_PQC_ZK_MIN_V3 = 't0gm-hybrid-pqc-zk-min-v3';

    private array $profiles;

    public function __construct(?array $profiles = null)
    {
        $this->profiles = $profiles ?? [
            self::HYBRID_PQC_V1 => [
                'required_signature_suites'=>['ed25519','ml-dsa-65'],
                'required_distinct_key_ids'=>2,
                'zero_knowledge_required'=>true,
                'allowed_zk_systems'=>['t0gm-zk-sovereign-possession-v1'],
                'kem_preferences'=>['ml-kem-768'],
                'backup_kem_status'=>['hqc'=>'selected-not-yet-finalized-standard'],
                'classical_only_allowed'=>false,
            ],
            self::HYBRID_PQC_ZK_V2 => [
                'required_signature_suites'=>['ed25519','ml-dsa-65'],
                'required_distinct_key_ids'=>2,
                'zero_knowledge_required'=>true,
                'allowed_zk_systems'=>['t0gm-zk-ristretto255-schnorr-v1'],
                'zk_public_key_payload_field'=>'zk_possession_public_key',
                'kem_preferences'=>['ml-kem-768'],
                'backup_kem_status'=>['hqc'=>'selected-not-yet-finalized-standard'],
                'classical_only_allowed'=>false,
            ],
            self::HYBRID_PQC_ZK_MIN_V3 => [
                'required_signature_suites'=>['ed25519','ml-dsa-65'],
                'required_distinct_key_ids'=>2,
                'zero_knowledge_required'=>true,
                'allowed_zk_systems'=>['t0gm-zk-ristretto255-schnorr-v1'],
                'zk_public_key_payload_field'=>'zk_possession_public_key',
                'zk_statement_policy'=>'minimal-authorization-v1',
                'kem_preferences'=>['ml-kem-768'],
                'backup_kem_status'=>['hqc'=>'selected-not-yet-finalized-standard'],
                'classical_only_allowed'=>false,
            ],
        ];
    }

    public function profile(string $id): array
    {
        if (!isset($this->profiles[$id])) throw new GodModeException('unknown-crypto-profile:' . $id);
        return $this->profiles[$id] + ['profile_id'=>$id];
    }
}
