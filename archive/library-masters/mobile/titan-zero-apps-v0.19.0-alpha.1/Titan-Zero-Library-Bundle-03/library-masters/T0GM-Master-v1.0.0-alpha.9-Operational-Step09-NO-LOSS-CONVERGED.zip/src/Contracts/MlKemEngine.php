<?php
namespace Titan\GodMode\Contracts;

interface MlKemEngine
{
    /** @return array{ciphertext:string,shared_secret:string,provider_id:string} */
    public function encapsulate(string $algorithm, string $peerPublicKeyPem): array;

    public function decapsulate(string $algorithm, string $privateKeyReference, string $ciphertext): string;
}
