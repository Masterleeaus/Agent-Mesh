<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Contracts\ClassicalKeyAgreement;
use Titan\GodMode\Contracts\MlKemEngine;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmHybridSessionEstablisher
{
    public function __construct(
        private ClassicalKeyAgreement $classical,
        private MlKemEngine $pq,
        private ?T0gmHybridSessionNegotiator $negotiator=null,
    ){ $this->negotiator ??= new T0gmHybridSessionNegotiator(); }

    public function initiate(array $context, array $offer, string $responderMlKemPublicKeyPem): array
    {
        $neg=$this->negotiator->negotiate($offer);
        $transcript=$this->buildTranscript($context,$neg);
        $classical=$this->classical->generateEphemeral($neg['classical_kex']);
        $pq=$this->pq->encapsulate($neg['pq_kem'],$responderMlKemPublicKeyPem);
        $state=[
            'transcript'=>$transcript,
            'negotiation'=>$neg,
            'initiator_classical_private'=>$classical['private_key'],
            'initiator_classical_public'=>base64_encode($classical['public_key']),
            'pq_ciphertext'=>base64_encode($pq['ciphertext']),
            'pq_shared_secret'=>$pq['shared_secret'],
            'classical_provider_id'=>$classical['provider_id'],
            'pq_provider_id'=>$pq['provider_id'],
            'authority_granted'=>false,
            'company_authority_granted'=>false,
        ];
        return $state;
    }

    public function accept(array $context, array $offer, string $responderMlKemPrivateKeyReference, string $initiatorClassicalPublicB64, string $pqCiphertextB64): array
    {
        $neg=$this->negotiator->negotiate($offer);
        $transcript=$this->buildTranscript($context,$neg);
        $peer=$this->b64($initiatorClassicalPublicB64,'hybrid-classical-public-invalid');
        $cipher=$this->b64($pqCiphertextB64,'hybrid-pq-ciphertext-invalid');
        $classical=$this->classical->generateEphemeral($neg['classical_kex']);
        $classicalSecret=$this->classical->derive($neg['classical_kex'],$classical['private_key'],$peer);
        $pqSecret=$this->pq->decapsulate($neg['pq_kem'],$responderMlKemPrivateKeyReference,$cipher);
        $session=$this->combine($classicalSecret,$pqSecret,$transcript['transcript_hash'],$neg['negotiation_hash']);
        return [
            'transcript'=>$transcript,
            'negotiation'=>$neg,
            'responder_classical_public'=>base64_encode($classical['public_key']),
            'session_key'=>$session,
            'session_key_hash'=>hash('sha256',$session),
            'classical_component_hash'=>hash('sha256',$classicalSecret),
            'pq_component_hash'=>hash('sha256',$pqSecret),
            'authority_granted'=>false,
            'company_authority_granted'=>false,
        ];
    }

    public function finalizeInitiator(array $initState, string $responderClassicalPublicB64): array
    {
        foreach(['transcript','negotiation','initiator_classical_private','pq_shared_secret'] as $f) if(!isset($initState[$f])) throw new GodModeException('hybrid-init-state-missing:'.$f);
        $peer=$this->b64($responderClassicalPublicB64,'hybrid-classical-public-invalid');
        $classicalSecret=$this->classical->derive((string)$initState['negotiation']['classical_kex'],$initState['initiator_classical_private'],$peer);
        $session=$this->combine($classicalSecret,$initState['pq_shared_secret'],$initState['transcript']['transcript_hash'],$initState['negotiation']['negotiation_hash']);
        return [
            'transcript'=>$initState['transcript'],
            'negotiation'=>$initState['negotiation'],
            'session_key'=>$session,
            'session_key_hash'=>hash('sha256',$session),
            'classical_component_hash'=>hash('sha256',$classicalSecret),
            'pq_component_hash'=>hash('sha256',$initState['pq_shared_secret']),
            'authority_granted'=>false,
            'company_authority_granted'=>false,
        ];
    }

    private function buildTranscript(array $context,array $neg): array
    {
        foreach(['session_id','initiator','responder','purpose'] as $f) if(!isset($context[$f]) || !is_string($context[$f]) || trim($context[$f])==='') throw new GodModeException('hybrid-session-context-missing:'.$f);
        foreach(['company_id','tenant_id','tenant_company_id','capability_id','authority'] as $forbidden) if(array_key_exists($forbidden,$context)) throw new GodModeException('hybrid-session-must-not-embed-authority:'.$forbidden);
        $p=[
            'schema'=>'titan.t0gm.hybrid_session_transcript.v1',
            'session_id'=>$context['session_id'],
            'initiator'=>$context['initiator'],
            'responder'=>$context['responder'],
            'purpose'=>$context['purpose'],
            'crypto_profile_id'=>$neg['crypto_profile_id'],
            'classical_kex'=>$neg['classical_kex'],
            'pq_kem'=>$neg['pq_kem'],
            'combiner'=>$neg['combiner'],
            'negotiation_hash'=>$neg['negotiation_hash'],
        ];
        return $p+['transcript_hash'=>hash('sha256',CanonicalJson::encode($p))];
    }

    private function combine(string $classical,string $pq,string $transcriptHash,string $negotiationHash): string
    {
        if(strlen($classical)<32) throw new GodModeException('hybrid-classical-secret-too-short');
        if(strlen($pq)<32) throw new GodModeException('hybrid-pq-secret-too-short');
        $ikm=hash('sha256',"T0GM-HYBRID-V1\0".$classical."\0".$pq,true);
        $salt=hash('sha256',"T0GM-HYBRID-SALT\0".$transcriptHash."\0".$negotiationHash,true);
        return hash_hkdf('sha256',$ikm,32,'t0gm-hybrid-session-key-v1',$salt);
    }

    private function b64(string $value,string $reason): string
    {
        $decoded=base64_decode($value,true);
        if($decoded===false || $decoded==='') throw new GodModeException($reason);
        return $decoded;
    }
}
