<?php
namespace Titan\GodMode\View;

final class T0gmFeedView
{
    public const CRITICAL_NOW = 'critical_now';
    public const AI_DECISIONS = 'ai_decisions';
    public const SECURITY = 'security';
    public const MONEY = 'money';
    public const ENVIRONMENT = 'environment';
    public const CROSS_COMPANY = 'cross_company';
    public const SUPERSEDED = 'superseded';
    public const IRREVERSIBLE = 'irreversible';
    public const EVERYTHING = 'everything';

    public static function all(): array
    {
        return [self::CRITICAL_NOW,self::AI_DECISIONS,self::SECURITY,self::MONEY,self::ENVIRONMENT,self::CROSS_COMPANY,self::SUPERSEDED,self::IRREVERSIBLE,self::EVERYTHING];
    }
}
