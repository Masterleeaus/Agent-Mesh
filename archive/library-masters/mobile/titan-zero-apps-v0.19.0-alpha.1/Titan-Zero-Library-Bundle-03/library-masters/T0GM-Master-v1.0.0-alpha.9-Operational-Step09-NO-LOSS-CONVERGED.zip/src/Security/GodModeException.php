<?php
namespace Titan\GodMode\Security;

final class GodModeException extends \RuntimeException
{
    public function __construct(
        public readonly string $reason,
        string $message = ''
    ) {
        parent::__construct($message ?: $reason);
    }
}
