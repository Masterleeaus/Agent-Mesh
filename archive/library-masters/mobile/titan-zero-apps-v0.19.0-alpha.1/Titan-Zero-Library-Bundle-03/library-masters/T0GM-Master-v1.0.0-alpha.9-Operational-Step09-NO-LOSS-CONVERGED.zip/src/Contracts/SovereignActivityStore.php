<?php
namespace Titan\GodMode\Contracts;

use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedQuery;

interface SovereignActivityStore
{
    /** Append one validated canonical event. Same event_id+hash is idempotent; conflicting reuse must fail. */
    public function append(array $event): array;

    /** Return the immutable stored record for one event or null. */
    public function get(string $eventId, T0gmFeedAccessContext $access): ?array;

    /** Query through the visibility policy; callers never receive raw unfiltered rows. */
    public function query(T0gmFeedQuery $query, T0gmFeedAccessContext $access): array;

    /** Direct causal neighbours represented as typed edges. */
    public function causalEdges(string $eventId, T0gmFeedAccessContext $access): array;

    /** Events referencing the supplied evidence identifier. */
    public function byEvidence(string $evidenceId, T0gmFeedAccessContext $access): array;

    /** Events in one correlation group. */
    public function byCorrelation(string $correlationId, T0gmFeedAccessContext $access): array;

    /** Last immutable audit record, or null for an empty store. */
    public function auditHead(): ?array;

    /** Verify chained record hashes and event payload hashes. */
    public function verifyAuditLineage(): bool;
}
