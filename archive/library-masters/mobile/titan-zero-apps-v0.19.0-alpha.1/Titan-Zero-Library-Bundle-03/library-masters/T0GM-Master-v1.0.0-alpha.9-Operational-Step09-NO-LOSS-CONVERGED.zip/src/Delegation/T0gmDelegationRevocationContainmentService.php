<?php
namespace Titan\GodMode\Delegation;

final class T0gmDelegationRevocationContainmentService
{
    public function __construct(
        private readonly T0gmDelegatedCapabilityRegistry $registry,
        private readonly T0gmDelegationContainmentPlanner $planner=new T0gmDelegationContainmentPlanner(),
    ){}

    public function revoke(string $delegationId,array $revocation): array
    {
        foreach(['revocation_id','revoked_by','reason','world_revision','observed_at'] as $field){
            if(trim((string)($revocation[$field]??''))==='') throw new \RuntimeException('revocation-field-required:'.$field);
        }
        $state=$this->registry->state($delegationId);
        if($state['status']==='revoked'){
            return $this->registry->revoke($delegationId,$revocation,[]);
        }
        $containment=$this->planner->plan($this->registry->dependents($delegationId));
        return $this->registry->revoke($delegationId,$revocation,$containment);
    }
}
