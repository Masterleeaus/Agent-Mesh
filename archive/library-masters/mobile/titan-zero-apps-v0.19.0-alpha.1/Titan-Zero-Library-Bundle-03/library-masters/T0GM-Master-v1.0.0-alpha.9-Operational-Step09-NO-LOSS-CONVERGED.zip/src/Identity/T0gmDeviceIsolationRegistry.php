<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

/**
 * Dynamic device-specific isolation state for T0GM devices.
 * Quarantine blocks current use of one device without revoking the sovereign
 * principal or unrelated sibling devices, and without erasing history.
 */
final class T0gmDeviceIsolationRegistry
{
    private array $records=[];

    public function __construct(array $entries=[])
    {
        foreach($entries as $deviceKeyId=>$entry){
            $principalId=trim((string)($entry['principal_id']??''));
            $bindingId=trim((string)($entry['binding_id']??''));
            $status=(string)($entry['status']??'quarantined');
            $quarantinedAt=isset($entry['quarantined_at'])?(int)$entry['quarantined_at']:null;
            if($principalId===''||$bindingId===''||$status!=='quarantined'||$quarantinedAt===null){
                throw new \InvalidArgumentException('invalid-device-isolation-record:'.$deviceKeyId);
            }
            foreach(['company_id','tenant_id','tenant_company_id','capability_id','role_id'] as $forbidden){
                if(array_key_exists($forbidden,$entry)) throw new \InvalidArgumentException('authority-bearing-device-isolation-forbidden:'.$deviceKeyId.':'.$forbidden);
            }
            $this->records[(string)$deviceKeyId]=[
                'device_key_id'=>(string)$deviceKeyId,
                'principal_id'=>$principalId,
                'binding_id'=>$bindingId,
                'status'=>'quarantined',
                'quarantined_at'=>$quarantinedAt,
                'reason'=>trim((string)($entry['reason']??'unspecified-compromise-signal')),
                'evidence_ref'=>trim((string)($entry['evidence_ref']??'')),
                'provenance'=>is_array($entry['provenance']??null)?$entry['provenance']:[],
            ];
        }
    }

    public function quarantineFor(string $deviceKeyId,string $principalId,string $bindingId,int $at):?array
    {
        if(!isset($this->records[$deviceKeyId])) return null;
        $r=$this->records[$deviceKeyId];
        if(!hash_equals($r['principal_id'],$principalId)) throw new GodModeException('device-isolation-principal-mismatch');
        if(!hash_equals($r['binding_id'],$bindingId)) throw new GodModeException('device-isolation-binding-mismatch');
        if($at < $r['quarantined_at']) return null;
        return $this->publicRecord($r);
    }

    public function assertCurrentUseAllowed(string $deviceKeyId,string $principalId,string $bindingId,int $now):void
    {
        if($this->quarantineFor($deviceKeyId,$principalId,$bindingId,$now)!==null){
            throw new GodModeException('device-binding-quarantined');
        }
    }

    public function assertHistoricalUseAllowed(string $deviceKeyId,string $principalId,string $bindingId,int $evidenceTime):void
    {
        if($this->quarantineFor($deviceKeyId,$principalId,$bindingId,$evidenceTime)!==null){
            throw new GodModeException('device-binding-quarantined-at');
        }
    }

    public function continuanceFactsFor(string $deviceKeyId,string $principalId,string $bindingId,int $now):array
    {
        $q=$this->quarantineFor($deviceKeyId,$principalId,$bindingId,$now);
        return [
            'device_quarantined'=>$q!==null,
            'device_key_id'=>$deviceKeyId,
            'device_binding_id'=>$bindingId,
            'device_isolation_evidence_ref'=>$q['evidence_ref']??null,
            'device_isolation_reason'=>$q['reason']??null,
        ];
    }

    private function publicRecord(array $r):array
    {
        return [
            ...$r,
            'blocks_current_device_use'=>true,
            'destroys_sovereign_identity'=>false,
            'affects_sibling_devices'=>false,
            'application_role_authority'=>false,
            'company_authority_embedded'=>false,
            'execution_authority_granted'=>false,
        ];
    }
}
