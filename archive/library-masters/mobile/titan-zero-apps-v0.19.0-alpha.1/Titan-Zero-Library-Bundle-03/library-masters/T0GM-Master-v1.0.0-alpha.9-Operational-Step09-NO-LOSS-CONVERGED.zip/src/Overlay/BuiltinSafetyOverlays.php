<?php
namespace Titan\GodMode\Overlay;

final class BuiltinSafetyOverlays
{
    public function __construct(private readonly SafetyOverlayFactory $factory=new SafetyOverlayFactory()){}

    public function industry(string $industry,string $companyId): array
    {
        $industry=strtolower(trim($industry));
        $constraints=match($industry){
            'healthcare'=>[
                'prohibited_action_classes'=>['physical_clinical_control'],
                'human_approval_operations'=>['modify_health_record','release_health_record','clinical_action'],
                'required_evidence_types'=>['purpose','identity','authorization'],
                'max_physical_impact'=>20,
                'forbid_ai_only_approval'=>true,
            ],
            'finance'=>[
                'human_approval_operations'=>['funds_transfer','payment_release','change_beneficiary','ledger_adjustment'],
                'dual_control_operations'=>['funds_transfer','payment_release','change_beneficiary'],
                'required_evidence_types'=>['purpose','identity','authorization'],
                'max_financial_exposure'=>70,
                'forbid_ai_only_approval'=>true,
            ],
            'manufacturing'=>[
                'human_approval_action_classes'=>['physical_control','safety_critical'],
                'required_controls'=>['safety_interlock_verified','equipment_state_verified'],
                'max_physical_impact'=>40,
                'forbid_ai_only_approval'=>true,
            ],
            'environmental_operations'=>[
                'human_approval_operations'=>['discharge','emission_release','waste_release','environmental_override'],
                'required_controls'=>['environmental_state_verified'],
                'required_evidence_types'=>['purpose','environmental'],
                'max_environmental_impact'=>40,
                'forbid_ai_only_approval'=>true,
            ],
            default=>[
                'required_evidence_types'=>['purpose','identity'],
                'forbid_ai_only_approval'=>false,
            ],
        };
        return $this->factory->create(['company_id'=>$companyId,'kind'=>'industry','code'=>$industry,'constraints'=>$constraints]);
    }

    public function jurisdiction(string $jurisdiction,string $companyId,array $constraints=[]): array
    {
        $jurisdiction=strtoupper(trim($jurisdiction));
        // Jurisdiction overlays intentionally carry machine-readable constraints rather than
        // hard-coding legal conclusions. Current legal/regulatory authority can populate them.
        $base=[
            'required_evidence_types'=>['purpose','identity','authorization'],
            'forbid_cross_company_data'=>true,
        ];
        return $this->factory->create([
            'company_id'=>$companyId,
            'kind'=>'jurisdiction',
            'code'=>$jurisdiction,
            'constraints'=>array_replace($base,$constraints),
        ]);
    }
}
