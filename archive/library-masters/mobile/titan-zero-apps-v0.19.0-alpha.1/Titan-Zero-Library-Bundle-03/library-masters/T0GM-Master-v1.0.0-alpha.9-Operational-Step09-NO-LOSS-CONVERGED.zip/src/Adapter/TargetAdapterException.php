<?php
namespace Titan\GodMode\Adapter;

final class TargetAdapterException extends \RuntimeException {}
