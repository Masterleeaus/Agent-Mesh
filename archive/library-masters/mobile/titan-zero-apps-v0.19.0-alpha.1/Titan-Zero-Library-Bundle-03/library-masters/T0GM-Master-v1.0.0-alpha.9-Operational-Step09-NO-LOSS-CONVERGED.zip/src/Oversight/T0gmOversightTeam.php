<?php
namespace Titan\GodMode\Oversight;

use Titan\GodMode\Ranking\T0gmAttentionScorer;

final class T0gmOversightTeam
{
    /** @var array<string,T0gmOversightReviewer> */
    private array $reviewers=[];
    public function __construct(iterable $reviewers = [], private readonly T0gmAttentionScorer $scorer = new T0gmAttentionScorer())
    {
        foreach($reviewers as $reviewer) $this->register($reviewer);
        if (!$this->reviewers) foreach(T0gmOversightSpecialist::all() as $s) $this->register(new DeterministicSpecialistReviewer($s));
    }
    public function register(T0gmOversightReviewer $reviewer): void
    {
        $s=$reviewer->specialist();
        if (isset($this->reviewers[$s])) throw new \InvalidArgumentException('duplicate-specialist-reviewer');
        $this->reviewers[$s]=$reviewer;
    }
    public function review(array $event): T0gmOversightReviewSet
    {
        $attention=$this->scorer->score($event)->toArray();
        $assessments=[]; $byDisposition=[]; $material=[];
        foreach(T0gmOversightSpecialist::all() as $specialist){
            if (!isset($this->reviewers[$specialist])) throw new \RuntimeException('missing-specialist-reviewer:'.$specialist);
            $a=$this->reviewers[$specialist]->review($event,$attention); $assessments[]=$a; $byDisposition[$a->disposition][]=$a->specialist;
            if (in_array($a->disposition,[T0gmOversightDisposition::OBJECT,T0gmOversightDisposition::CONTAIN],true)) $material[]=['specialist'=>$a->specialist,'disposition'=>$a->disposition,'reason_codes'=>$a->reasonCodes];
        }
        $disagreements=[];
        if (count($byDisposition)>1) {
            foreach($byDisposition as $d=>$specialists) $disagreements[]=['disposition'=>$d,'specialists'=>$specialists];
        }
        return new T0gmOversightReviewSet((string)($event['event_id']??''),$assessments,$disagreements,$material);
    }
}
