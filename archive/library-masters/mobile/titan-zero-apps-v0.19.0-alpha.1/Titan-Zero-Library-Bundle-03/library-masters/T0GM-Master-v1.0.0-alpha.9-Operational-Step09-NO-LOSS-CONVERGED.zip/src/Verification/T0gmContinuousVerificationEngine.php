<?php
namespace Titan\GodMode\Verification;

use Titan\GodMode\Event\T0gmEventFactory;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedIngestor;
use Titan\GodMode\Recovery\T0gmStateTransitionHasher;
use Titan\GodMode\Recovery\T0gmStateTransitionValidator;

final class T0gmContinuousVerificationEngine
{
    public function __construct(
        private readonly T0gmVerificationCaseStore $cases,
        private readonly T0gmFeedIngestor $feed,
        private readonly T0gmStateTransitionHasher $hasher=new T0gmStateTransitionHasher(),
        private readonly T0gmStateTransitionValidator $validator=new T0gmStateTransitionValidator(),
        private readonly T0gmEventFactory $events=new T0gmEventFactory(),
    ){}

    public function observe(array $transition,array $observedState,array $dependencyStates=[],array $evidence=[],?string $causationId=null):array
    {
        $this->validator->validate($transition);
        if(!$this->hasher->verify($transition)) throw new \RuntimeException('transition-integrity-invalid');
        $id=$transition['transition_id'];
        $case=$this->cases->get($id)??[
            'schema'=>'titan.t0gm.continuous-verification.v1','verification_id'=>'t0gm_ver_'.bin2hex(random_bytes(12)),
            'transition_id'=>$id,'company_id'=>$transition['company_id'],'source_event_id'=>$transition['source_event_id'],
            'subject'=>$transition['subject'],'intended_result_hash'=>$transition['intended_result']['hash'],'status'=>T0gmVerificationStatus::PENDING,
            'attempt'=>0,'observations'=>[],'investigation_open'=>false,'resolution'=>null,
        ];
        if(in_array($case['status'],[T0gmVerificationStatus::CONVERGED,T0gmVerificationStatus::SUPERSEDED,T0gmVerificationStatus::ACCEPTED_VARIANCE],true)) return $case;

        $observedHash=$this->hasher->hashState($observedState);
        $stateMatches=hash_equals($transition['intended_result']['hash'],$observedHash);
        $dependencyMismatches=[];
        foreach($transition['dependencies'] as $d){$actual=$dependencyStates[$d['dependency_id']]??null;if($actual!==null && $actual!==$d['required_state'])$dependencyMismatches[]=['dependency_id'=>$d['dependency_id'],'required'=>$d['required_state'],'observed'=>$actual];}
        $case['attempt']++;
        $obs=['attempt'=>$case['attempt'],'observed_state'=>$observedState,'observed_state_hash'=>$observedHash,'state_matches_intent'=>$stateMatches,'dependency_mismatches'=>$dependencyMismatches,'evidence'=>$evidence,'causation_id'=>$causationId];
        $case['observations'][]=$obs;
        if($stateMatches && $dependencyMismatches===[]){$case['status']=T0gmVerificationStatus::CONVERGED;$case['investigation_open']=false;$case['resolution']=['type'=>'observed_convergence','attempt'=>$case['attempt']];$kind=T0gmEventKind::RESULT;$tier='important';$score=20;$band='low';}
        else {$case['status']=T0gmVerificationStatus::INVESTIGATING;$case['investigation_open']=true;$case['resolution']=null;$kind=T0gmEventKind::ANOMALY;$tier='urgent';$score=80;$band='high';}
        $this->cases->put($case);
        $details=['verification'=>['verification_id'=>$case['verification_id'],'transition_id'=>$id,'attempt'=>$case['attempt'],'status'=>$case['status'],'intended_result_hash'=>$transition['intended_result']['hash'],'observed_state_hash'=>$observedHash,'dependency_mismatches'=>$dependencyMismatches,'investigation_open'=>$case['investigation_open']]];
        if($kind===T0gmEventKind::RESULT)$details['result']=['result_state'=>'observed_convergence','verification_state'=>'verified'];
        else $details['anomaly']=['anomaly_type'=>'state_convergence_failure','summary'=>'Observed state or dependencies differ from the intended transition result'];
        $event=$this->events->make($kind,['scope'=>'company','company_id'=>$transition['company_id']],['actor_type'=>'advanced_intelligence','actor_id'=>'t0gm-continuous-verifier','authority_class'=>'oversight_ai'],['system'=>'titan.t0gm','component'=>'continuous-verification'], $transition['subject'],['trace_id'=>'verify-'.$id,'correlation_id'=>'verify-'.$id,'causation_id'=>$causationId??$transition['source_event_id'],'parent_event_ids'=>array_values(array_filter([$causationId??$transition['source_event_id']]))],['score'=>$score,'band'=>$band,'dimensions'=>['state_divergence'=>$stateMatches?0:100,'dependency_divergence'=>$dependencyMismatches===[]?0:100]],['visibility'=>'t0gm_sovereign','attention_tier'=>$tier,'review_required'=>!$stateMatches||$dependencyMismatches!==[],'review_team'=>['operational','causal']],$evidence,$details);
        $this->feed->ingest($event);
        return $case;
    }

    public function supersede(string $transitionId,string $supersessionEventId):array
    { $case=$this->requiredOpen($transitionId);$case['status']=T0gmVerificationStatus::SUPERSEDED;$case['investigation_open']=false;$case['resolution']=['type'=>'superseded','event_id'=>$supersessionEventId];return $this->cases->put($case); }

    public function acceptVariance(string $transitionId,string $actorAuthorityClass,string $reason):array
    { if($actorAuthorityClass!=='titan.god_mode') throw new \RuntimeException('t0gm-required-to-accept-variance');$case=$this->requiredOpen($transitionId);if(trim($reason)==='')throw new \RuntimeException('acceptance-reason-required');$case['status']=T0gmVerificationStatus::ACCEPTED_VARIANCE;$case['investigation_open']=false;$case['resolution']=['type'=>'t0gm_accepted_variance','reason'=>$reason];return $this->cases->put($case); }

    private function requiredOpen(string $id):array
    { $c=$this->cases->get($id);if(!$c)throw new \RuntimeException('verification-case-not-found');if(!$c['investigation_open'])throw new \RuntimeException('verification-case-not-open');return $c; }
}
