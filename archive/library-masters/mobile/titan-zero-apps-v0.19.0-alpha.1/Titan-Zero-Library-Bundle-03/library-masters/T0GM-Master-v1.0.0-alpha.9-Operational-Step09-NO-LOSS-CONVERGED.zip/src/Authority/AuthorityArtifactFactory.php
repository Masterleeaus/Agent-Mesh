<?php
namespace Titan\GodMode\Authority;

final class AuthorityArtifactFactory
{
    public function __construct(private readonly AuthorityArtifactHasher $hasher = new AuthorityArtifactHasher()) {}

    public function intent(array $fields): array
    {
        return $this->seal(array_merge([
            'schema' => 'titan.t0gm.authority-artifact.v1',
            'artifact_id' => $this->id('intent'),
            'stage' => AuthorityStage::INTENT,
            'created_at' => gmdate('c'),
        ], $fields));
    }

    public function plan(array $fields): array
    {
        return $this->seal(array_merge([
            'schema' => 'titan.t0gm.authority-artifact.v1',
            'artifact_id' => $this->id('plan'),
            'stage' => AuthorityStage::PLANNING,
            'created_at' => gmdate('c'),
        ], $fields));
    }

    private function seal(array $artifact): array
    {
        $artifact['integrity'] = ['algorithm' => 'sha256', 'digest' => $this->hasher->digest($artifact)];
        return $artifact;
    }

    private function id(string $prefix): string
    {
        return $prefix . '_' . bin2hex(random_bytes(16));
    }
}
