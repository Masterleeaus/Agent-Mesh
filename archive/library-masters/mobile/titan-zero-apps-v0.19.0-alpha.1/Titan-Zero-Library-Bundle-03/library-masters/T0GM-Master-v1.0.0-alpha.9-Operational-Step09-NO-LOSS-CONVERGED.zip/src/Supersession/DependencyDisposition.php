<?php
namespace Titan\GodMode\Supersession;

final class DependencyDisposition
{
    public const STOP = 'stop';
    public const REVERSE = 'reverse';
    public const RECOMPUTE = 'recompute';
    public const REMAIN_INTACT = 'remain_intact';
    public static function all(): array { return [self::STOP,self::REVERSE,self::RECOMPUTE,self::REMAIN_INTACT]; }
}
