<?php
namespace Titan\GodMode\Authority;

final class AuthoritySeparationException extends \RuntimeException
{
    public function __construct(string $message, public readonly ?string $path = null)
    {
        parent::__construct($path === null ? $message : $message . ':' . $path);
    }
}
