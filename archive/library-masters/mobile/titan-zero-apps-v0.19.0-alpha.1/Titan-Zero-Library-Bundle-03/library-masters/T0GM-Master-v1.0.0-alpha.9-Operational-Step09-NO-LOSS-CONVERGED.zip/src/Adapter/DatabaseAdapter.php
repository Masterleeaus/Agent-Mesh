<?php
namespace Titan\GodMode\Adapter;

final class DatabaseAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'database'; }
    public function supports(array $target): bool { return ($target['target_type'] ?? '') === 'database'; }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_record','read_schema','verify_integrity','restore_record','apply_named_migration','create_verified_backup'
        ]);
        $params = $request['parameters'] ?? [];
        if (isset($params['sql'])) throw new TargetAdapterException('raw_sql_not_accepted_by_sovereign_adapter');
        return [
            'transport' => 'database_native_protocol',
            'company_id' => $request['company_id'],
            'database' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'resource_id' => $request['resource_id'] ?? null,
            'parameters' => $params,
        ];
    }
}
