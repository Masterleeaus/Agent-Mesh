<?php
namespace Titan\GodMode\Delegation;

final class T0gmDelegationContainmentPlanner
{
    public function plan(array $dependentActions): array
    {
        $plan=[];
        foreach($dependentActions as $id=>$action){
            $kind=strtolower((string)($action['kind']??''));
            $state=strtolower((string)($action['state']??''));
            $reversibility=max(0,min(100,(int)($action['reversibility']??0)));
            if($kind==='evidence'||$kind==='observation') $disposition='preserve';
            elseif($kind==='decision') $disposition='recompute';
            elseif(in_array($state,['queued','pending','planned'],true)) $disposition='cancel';
            elseif(in_array($state,['running','in_progress'],true)) $disposition='stop';
            elseif(in_array($state,['completed','committed','applied'],true)) $disposition=$reversibility>=50?'reverse':'recompute';
            else $disposition='recompute';
            $plan[$id]=[
                'action_id'=>$id,
                'disposition'=>$disposition,
                'reason'=>'delegated_authority_revoked',
                'preserve_evidence'=>true,
                'requires_fresh_authority_for_new_execution'=>true,
                'authority_granted'=>false,
            ];
        }
        return $plan;
    }
}
