<?php
namespace Titan\GodMode\Event;

use Titan\GodMode\Security\CanonicalJson;

final class T0gmCanonicalHasher
{
    public function hash(array $event): string
    {
        $copy = $event;
        unset($copy['integrity'], $copy['provenance']);
        return hash('sha256', CanonicalJson::encode($copy));
    }

    public function seal(array $event, ?string $previousEventHash = null): array
    {
        $event['integrity'] = [
            'algorithm' => 'sha256',
            'canonical_hash' => $this->hash($event),
            'previous_event_hash' => $previousEventHash,
        ];
        return $event;
    }

    public function verify(array $event): bool
    {
        $stored = $event['integrity']['canonical_hash'] ?? null;
        return is_string($stored) && hash_equals($stored, $this->hash($event));
    }
}
