<?php
namespace Titan\GodMode\Capability;

final class SovereignCapabilityValidator
{
    private const LEGACY_TENANT_KEYS = ['tenant_id', 'tenant_company_id', 'tenantId', 'tenantCompanyId'];
    private const UNBOUNDED_EFFECTS = ['*', 'all', 'admin', 'administrator', 'root', 'super_admin', 'god_mode'];
    private const RISK_BANDS = ['minimal', 'low', 'medium', 'high', 'extreme', 'unknown'];
    private const EXTINCTION_TYPES = [
        'purpose_satisfied', 'purpose_invalid', 'authority_revoked', 'authority_basis_invalid',
        'company_changed', 'target_changed', 'evidence_invalid', 'risk_constraint_breached',
        'safety_interlock', 'execution_complete', 'execution_path_deviation', 'anomaly_detected',
        'superseded', 't0gm_extinguish'
    ];

    public function validate(array $capability): array
    {
        $this->rejectLegacyTenantKeys($capability);
        $this->requireExact($capability, 'schema', 'titan.t0gm.sovereign-capability.v1');
        $this->requireString($capability, 'capability_id');
        $this->requireString($capability, 'constitution_version');
        $this->requireString($capability, 'created_at');
        if (isset($capability['expires_at']) || isset($capability['ttl']) || isset($capability['valid_for_seconds'])) {
            throw new SovereignCapabilityException('time-must-not-be-authority-duration');
        }

        $this->requireArray($capability, 'authority_holder');
        $holder = $capability['authority_holder'];
        $this->requireString($holder, 'identity_id', 'authority_holder.identity_id');
        $this->requireExact($holder, 'authority_class', 'titan.god_mode', 'authority_holder.authority_class');
        if (($holder['actor_type'] ?? null) !== 'human') {
            throw new SovereignCapabilityException('sovereign-capability-requires-human-t0gm', 'authority_holder.actor_type');
        }

        $this->requireArray($capability, 'authority_basis');
        $basis = $capability['authority_basis'];
        $this->requireString($basis, 'basis_type', 'authority_basis.basis_type');
        $this->requireString($basis, 'basis_id', 'authority_basis.basis_id');
        $this->requireString($basis, 'description', 'authority_basis.description');

        $this->requireString($capability, 'company_id');
        if ($capability['company_id'] === '*' || strtolower($capability['company_id']) === 'all') {
            throw new SovereignCapabilityException('wildcard-company-scope-forbidden', 'company_id');
        }

        $this->requireArray($capability, 'purpose');
        $this->requireString($capability['purpose'], 'purpose_id', 'purpose.purpose_id');
        $this->requireString($capability['purpose'], 'statement', 'purpose.statement');
        $this->requireString($capability['purpose'], 'intended_outcome', 'purpose.intended_outcome');

        $this->requireArray($capability, 'target');
        foreach (['target_type','target_id','system','environment'] as $field) {
            $this->requireString($capability['target'], $field, 'target.' . $field);
        }
        foreach ($capability['target']['resource_ids'] ?? [] as $resourceId) {
            if (!is_string($resourceId) || trim($resourceId) === '' || $resourceId === '*') {
                throw new SovereignCapabilityException('invalid-target-resource', 'target.resource_ids');
            }
        }

        $permitted = $capability['permitted_effects'] ?? null;
        if (!is_array($permitted) || $permitted === []) {
            throw new SovereignCapabilityException('permitted-effects-required', 'permitted_effects');
        }
        $effectIds = [];
        foreach ($permitted as $i => $effect) {
            if (!is_array($effect)) throw new SovereignCapabilityException('invalid-permitted-effect', "permitted_effects.$i");
            foreach (['effect_id','operation','resource_type'] as $field) {
                $this->requireString($effect, $field, "permitted_effects.$i.$field");
            }
            $op = strtolower(trim($effect['operation']));
            if (in_array($op, self::UNBOUNDED_EFFECTS, true) || str_contains($op, '*')) {
                throw new SovereignCapabilityException('unbounded-effect-forbidden', "permitted_effects.$i.operation");
            }
            if (isset($effectIds[$effect['effect_id']])) throw new SovereignCapabilityException('duplicate-effect-id', "permitted_effects.$i.effect_id");
            $effectIds[$effect['effect_id']] = true;
            if (isset($effect['resource_ids'])) {
                if (!is_array($effect['resource_ids']) || $effect['resource_ids'] === []) throw new SovereignCapabilityException('invalid-effect-resource-ids', "permitted_effects.$i.resource_ids");
                foreach ($effect['resource_ids'] as $id) {
                    if (!is_string($id) || trim($id) === '' || $id === '*') throw new SovereignCapabilityException('wildcard-effect-resource-forbidden', "permitted_effects.$i.resource_ids");
                }
            }
        }

        $prohibited = $capability['prohibited_effects'] ?? null;
        if (!is_array($prohibited) || $prohibited === []) {
            throw new SovereignCapabilityException('prohibited-effects-required', 'prohibited_effects');
        }
        foreach ($prohibited as $i => $effect) {
            if (!is_array($effect)) throw new SovereignCapabilityException('invalid-prohibited-effect', "prohibited_effects.$i");
            $this->requireString($effect, 'operation', "prohibited_effects.$i.operation");
            $this->requireString($effect, 'reason', "prohibited_effects.$i.reason");
        }

        $evidence = $capability['evidence'] ?? null;
        if (!is_array($evidence) || $evidence === []) throw new SovereignCapabilityException('evidence-required', 'evidence');
        foreach ($evidence as $i => $ref) {
            if (!is_array($ref)) throw new SovereignCapabilityException('invalid-evidence-ref', "evidence.$i");
            foreach (['evidence_id','evidence_type','source','integrity_ref'] as $field) {
                $this->requireString($ref, $field, "evidence.$i.$field");
            }
        }

        $this->requireArray($capability, 'risk_constraints');
        $risk = $capability['risk_constraints'];
        foreach (['max_risk_score','max_financial_exposure','max_physical_impact','max_environmental_impact'] as $field) {
            if (!array_key_exists($field, $risk) || !is_int($risk[$field]) || $risk[$field] < 0 || $risk[$field] > 100) {
                throw new SovereignCapabilityException('invalid-risk-constraint', 'risk_constraints.' . $field);
            }
        }
        if (isset($risk['prohibited_risk_bands'])) {
            if (!is_array($risk['prohibited_risk_bands'])) throw new SovereignCapabilityException('invalid-prohibited-risk-bands');
            foreach ($risk['prohibited_risk_bands'] as $band) {
                if (!in_array($band, self::RISK_BANDS, true)) throw new SovereignCapabilityException('invalid-risk-band');
            }
        }

        $conditions = $capability['extinction_conditions'] ?? null;
        if (!is_array($conditions) || $conditions === []) throw new SovereignCapabilityException('extinction-conditions-required');
        $requiredTypes = ['purpose_invalid','authority_revoked','company_changed','target_changed','risk_constraint_breached','safety_interlock','superseded','t0gm_extinguish'];
        $seen = [];
        foreach ($conditions as $i => $condition) {
            if (!is_array($condition)) throw new SovereignCapabilityException('invalid-extinction-condition', "extinction_conditions.$i");
            $this->requireString($condition, 'condition_id', "extinction_conditions.$i.condition_id");
            $this->requireString($condition, 'condition_type', "extinction_conditions.$i.condition_type");
            $this->requireString($condition, 'description', "extinction_conditions.$i.description");
            if (!in_array($condition['condition_type'], self::EXTINCTION_TYPES, true)) throw new SovereignCapabilityException('unknown-extinction-condition', "extinction_conditions.$i.condition_type");
            $seen[$condition['condition_type']] = true;
        }
        foreach ($requiredTypes as $type) {
            if (!isset($seen[$type])) throw new SovereignCapabilityException('mandatory-extinction-condition-missing', $type);
        }

        $this->requireArray($capability, 'integrity');
        $this->requireString($capability['integrity'], 'algorithm', 'integrity.algorithm');
        $this->requireString($capability['integrity'], 'digest', 'integrity.digest');

        return $capability;
    }

    private function rejectLegacyTenantKeys(array $value, string $path = ''): void
    {
        foreach ($value as $key => $child) {
            $childPath = $path === '' ? (string)$key : $path . '.' . $key;
            if (in_array((string)$key, self::LEGACY_TENANT_KEYS, true)) throw new SovereignCapabilityException('legacy-tenant-boundary-forbidden', $childPath);
            if (is_array($child)) $this->rejectLegacyTenantKeys($child, $childPath);
        }
    }
    private function requireString(array $a, string $key, ?string $path = null): void
    {
        if (!isset($a[$key]) || !is_string($a[$key]) || trim($a[$key]) === '') throw new SovereignCapabilityException('missing-or-invalid-field', $path ?? $key);
    }
    private function requireArray(array $a, string $key, ?string $path = null): void
    {
        if (!array_key_exists($key, $a) || !is_array($a[$key])) throw new SovereignCapabilityException('missing-or-invalid-field', $path ?? $key);
    }
    private function requireExact(array $a, string $key, string $expected, ?string $path = null): void
    {
        if (($a[$key] ?? null) !== $expected) throw new SovereignCapabilityException('invalid-fixed-field', $path ?? $key);
    }
}
