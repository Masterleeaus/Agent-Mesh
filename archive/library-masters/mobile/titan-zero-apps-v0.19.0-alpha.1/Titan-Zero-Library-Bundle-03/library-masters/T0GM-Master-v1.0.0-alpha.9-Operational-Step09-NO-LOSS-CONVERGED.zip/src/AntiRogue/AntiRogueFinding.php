<?php
namespace Titan\GodMode\AntiRogue;

final class AntiRogueFinding
{
    public function __construct(
        public readonly string $findingId,
        public readonly string $attackClass,
        public readonly string $disposition,
        public readonly int $severity,
        public readonly array $reasonCodes,
        public readonly array $actors,
        public readonly array $evidenceRefs,
        public readonly array $requiredActions,
        public readonly bool $godModeRecoveryProtected = true,
    ) {}
    public function toArray(): array { return get_object_vars($this); }
}
