<?php
namespace Titan\GodMode\Feed;

final class T0gmFeedVisibilityPolicy
{
    /**
     * T0GM sovereign authority sees every governed event. Any non-sovereign reader is fail-closed:
     * company events require an explicit company_id grant and platform events require an explicit
     * platformVisibility grant. Merely being an oversight AI does not create cross-company authority.
     */
    public function canView(array $event, T0gmFeedAccessContext $access): bool
    {
        if ($access->isSovereign()) return true;

        $ctx = $event['company_context'] ?? [];
        $scope = $ctx['scope'] ?? null;
        if ($scope === 'platform') return $access->platformVisibility;
        if ($scope !== 'company') return false;

        $companyId = $ctx['company_id'] ?? null;
        return is_string($companyId) && in_array($companyId, $access->companyIds, true);
    }

    public function assertCanView(array $event, T0gmFeedAccessContext $access): void
    {
        if (!$this->canView($event, $access)) {
            throw new T0gmFeedException('feed-visibility-denied');
        }
    }
}
