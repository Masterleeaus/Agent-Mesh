<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Contracts\ZeroKnowledgeVerifier;
use Titan\GodMode\Security\CanonicalJson;

final class Ristretto255SchnorrVerifier implements ZeroKnowledgeVerifier
{
    public function __construct(private readonly string $verifierId = 'libsodium-ristretto255-schnorr-v1') {}

    public function verify(string $proof, array $publicStatement, array $context = []): array
    {
        $statementHash = hash('sha256', CanonicalJson::encode($publicStatement));
        $publicKey = base64_decode((string)($publicStatement['possession_public_key'] ?? ''), true);
        $keyId = is_string($publicKey) && $publicKey !== '' ? 'ristretto255:' . hash('sha256', $publicKey) : 'ristretto255:invalid';
        return [
            'verified' => Ristretto255SchnorrProof::verify($proof, $publicStatement, $context),
            'verifier_id' => $this->verifierId,
            'verification_key_id' => $keyId,
            'proof_system' => (string)($context['proof_system'] ?? ''),
            'statement_hash' => $statementHash,
            'proof_format' => Ristretto255SchnorrProof::FORMAT,
            'authority_granted' => false,
        ];
    }
}
