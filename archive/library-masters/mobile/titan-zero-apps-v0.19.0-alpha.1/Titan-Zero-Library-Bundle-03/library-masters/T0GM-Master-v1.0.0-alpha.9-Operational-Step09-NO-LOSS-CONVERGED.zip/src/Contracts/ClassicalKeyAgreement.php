<?php
namespace Titan\GodMode\Contracts;

interface ClassicalKeyAgreement
{
    /** @return array{public_key:string,private_key:string,provider_id:string} */
    public function generateEphemeral(string $algorithm): array;
    public function derive(string $algorithm, string $privateKey, string $peerPublicKey): string;
}
