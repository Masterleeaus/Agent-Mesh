<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Contracts\ClassicalKeyAgreement;
use Titan\GodMode\Security\GodModeException;

final class SodiumX25519Engine implements ClassicalKeyAgreement
{
    public function generateEphemeral(string $algorithm): array
    {
        $this->assertAlgorithm($algorithm);
        $private=random_bytes(SODIUM_CRYPTO_BOX_SECRETKEYBYTES);
        $public=sodium_crypto_scalarmult_base($private);
        return ['public_key'=>$public,'private_key'=>$private,'provider_id'=>'libsodium-x25519'];
    }

    public function derive(string $algorithm, string $privateKey, string $peerPublicKey): string
    {
        $this->assertAlgorithm($algorithm);
        if(strlen($privateKey)!==SODIUM_CRYPTO_BOX_SECRETKEYBYTES) throw new GodModeException('x25519-private-key-invalid');
        if(strlen($peerPublicKey)!==SODIUM_CRYPTO_BOX_PUBLICKEYBYTES) throw new GodModeException('x25519-public-key-invalid');
        $secret=sodium_crypto_scalarmult($privateKey,$peerPublicKey);
        if($secret===false || strlen($secret)<32) throw new GodModeException('x25519-derivation-failed');
        return $secret;
    }

    private function assertAlgorithm(string $algorithm): void
    {
        if($algorithm!=='x25519') throw new GodModeException('unsupported-classical-kex:'.$algorithm);
    }
}
