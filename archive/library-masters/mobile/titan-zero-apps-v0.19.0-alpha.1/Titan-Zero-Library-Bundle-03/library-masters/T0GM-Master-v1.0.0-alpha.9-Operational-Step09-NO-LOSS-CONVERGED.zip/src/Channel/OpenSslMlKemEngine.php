<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Contracts\MlKemEngine;
use Titan\GodMode\Security\GodModeException;

/**
 * OpenSSL 3.5+ ML-KEM adapter.
 * Private key input is a reference/path consumed by OpenSSL; Titan does not parse private KEM material.
 * Production deployments should place that reference behind OS/HSM/broker controls.
 */
final class OpenSslMlKemEngine implements MlKemEngine
{
    public function __construct(private ?string $opensslBinary = 'openssl') {}

    public function encapsulate(string $algorithm, string $peerPublicKeyPem): array
    {
        $suite=(new T0gmMlKemSuiteRegistry())->suite($algorithm);
        if ($peerPublicKeyPem === '') throw new GodModeException('ml-kem-peer-public-key-missing');
        $dir=$this->tempDir();
        try {
            $pub="$dir/peer-public.pem"; $ct="$dir/ciphertext.bin"; $secret="$dir/shared.bin";
            file_put_contents($pub,$peerPublicKeyPem); chmod($pub,0600);
            $this->run([$this->opensslBinary,'pkeyutl','-encap','-pubin','-inkey',$pub,'-out',$ct,'-secret',$secret]);
            $cipher=file_get_contents($ct); $shared=file_get_contents($secret);
            if ($cipher===false || $cipher==='' || $shared===false || $shared==='') throw new GodModeException('ml-kem-encapsulation-empty-result');
            return ['ciphertext'=>$cipher,'shared_secret'=>$shared,'provider_id'=>'openssl-pkeyutl'];
        } finally { $this->cleanup($dir); }
    }

    public function decapsulate(string $algorithm, string $privateKeyReference, string $ciphertext): string
    {
        (new T0gmMlKemSuiteRegistry())->suite($algorithm);
        if ($privateKeyReference==='' || !is_file($privateKeyReference)) throw new GodModeException('ml-kem-private-key-reference-invalid');
        if ($ciphertext==='') throw new GodModeException('ml-kem-ciphertext-missing');
        $dir=$this->tempDir();
        try {
            $ct="$dir/ciphertext.bin"; $secret="$dir/shared.bin";
            file_put_contents($ct,$ciphertext); chmod($ct,0600);
            $this->run([$this->opensslBinary,'pkeyutl','-decap','-inkey',$privateKeyReference,'-in',$ct,'-secret',$secret]);
            $shared=file_get_contents($secret);
            if ($shared===false || $shared==='') throw new GodModeException('ml-kem-decapsulation-empty-result');
            return $shared;
        } finally { $this->cleanup($dir); }
    }

    private function run(array $cmd): void
    {
        $spec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
        $p=proc_open($cmd,$spec,$pipes);
        if(!is_resource($p)) throw new GodModeException('ml-kem-provider-unavailable');
        fclose($pipes[0]); stream_get_contents($pipes[1]); fclose($pipes[1]); $err=stream_get_contents($pipes[2]); fclose($pipes[2]);
        $code=proc_close($p);
        if($code!==0) throw new GodModeException('ml-kem-provider-operation-failed'.($err!==''?':'.trim($err):''));
    }

    private function tempDir(): string
    {
        $dir=sys_get_temp_dir().'/t0gm-mlkem-'.bin2hex(random_bytes(12));
        if(!mkdir($dir,0700,true) && !is_dir($dir)) throw new GodModeException('ml-kem-tempdir-failed');
        return $dir;
    }

    private function cleanup(string $dir): void
    {
        foreach(glob($dir.'/*') ?: [] as $file){ if(is_file($file)){ @file_put_contents($file,''); @unlink($file); } }
        @rmdir($dir);
    }
}
