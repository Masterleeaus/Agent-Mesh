<?php
namespace Titan\GodMode\Prototype;

final class InMemoryServiceBusinessState
{
    private array $state=['crm'=>[],'bookings'=>[],'money'=>[],'staff'=>[],'communications'=>[],'ai_activity'=>[]];
    public function __construct(public readonly string $companyId)
    {
        if(trim($companyId)==='' || str_contains($companyId,'*')) throw new \InvalidArgumentException('invalid-company-id');
    }
    public function domain(string $name): array { return $this->state[$name] ?? []; }
    public function snapshot(): array { return $this->state; }
    public function put(string $domain,string $id,array $record): void
    {
        if(!array_key_exists($domain,$this->state)) throw new \InvalidArgumentException('unknown-domain');
        $this->state[$domain][$id]=$record;
    }
    public function get(string $domain,string $id): ?array { return $this->state[$domain][$id] ?? null; }
}
