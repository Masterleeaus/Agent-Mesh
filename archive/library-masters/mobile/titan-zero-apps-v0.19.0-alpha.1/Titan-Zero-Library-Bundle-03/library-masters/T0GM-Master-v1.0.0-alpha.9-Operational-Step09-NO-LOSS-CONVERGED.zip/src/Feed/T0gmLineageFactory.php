<?php
namespace Titan\GodMode\Feed;

final class T0gmLineageFactory
{
    public function create(?string $traceId = null, ?string $correlationId = null, ?string $causationId = null, array $parentEventIds = []): array
    {
        foreach ($parentEventIds as $id) {
            if (!is_string($id) || $id === '') throw new T0gmFeedException('invalid-parent-event-id');
        }
        return [
            'trace_id' => $traceId ?? self::id('trace'),
            'correlation_id' => $correlationId ?? self::id('corr'),
            'causation_id' => $causationId,
            'parent_event_ids' => array_values(array_unique($parentEventIds)),
        ];
    }

    private static function id(string $prefix): string
    {
        return 't0gm_' . $prefix . '_' . bin2hex(random_bytes(16));
    }
}
