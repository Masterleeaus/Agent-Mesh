<?php
namespace Titan\GodMode\Policy;

final class ClientAuthorityProfileType
{
    public const TITAN_MANAGED = 'titan_managed';
    public const CO_MANAGED = 'co_managed';
    public const CLIENT_CONTROLLED = 'client_controlled';
    public const RESTRICTED = 'restricted';
    public const OBSERVATION_ONLY = 'observation_only';

    public static function all(): array
    {
        return [self::TITAN_MANAGED,self::CO_MANAGED,self::CLIENT_CONTROLLED,self::RESTRICTED,self::OBSERVATION_ONLY];
    }
}
