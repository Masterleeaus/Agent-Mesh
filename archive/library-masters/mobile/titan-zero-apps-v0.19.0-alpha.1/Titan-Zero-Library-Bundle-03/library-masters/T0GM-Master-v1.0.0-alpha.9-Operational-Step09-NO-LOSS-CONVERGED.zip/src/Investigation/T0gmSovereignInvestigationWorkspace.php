<?php
namespace Titan\GodMode\Investigation;

use Titan\GodMode\Security\GodModeException;

/**
 * Projection-only sovereign investigation surface. It correlates authoritative
 * source projections without becoming an authority, execution, identity,
 * evidence, causal, capability, or state owner itself.
 */
final class T0gmSovereignInvestigationWorkspace
{
    private const LEGACY_BOUNDARIES = ['tenant_id','tenant_company_id','tenant'];

    public function compose(array $input): array
    {
        foreach (self::LEGACY_BOUNDARIES as $legacy) {
            if (array_key_exists($legacy, $input)) {
                throw new GodModeException('legacy-tenant-boundary-forbidden:'.$legacy);
            }
        }

        $investigationId = trim((string)($input['investigation_id'] ?? ''));
        if ($investigationId === '') throw new GodModeException('investigation-id-required');
        $companyId = trim((string)($input['company_id'] ?? ''));
        if ($companyId === '') throw new GodModeException('investigation-company-id-required');
        $title = trim((string)($input['title'] ?? ''));
        if ($title === '') throw new GodModeException('investigation-title-required');
        $openedAt = trim((string)($input['opened_at'] ?? ''));
        if ($openedAt === '' || strtotime($openedAt) === false) throw new GodModeException('investigation-opened-at-invalid');

        $timeline = $this->list($input, 'timeline');
        usort($timeline, static function(array $a, array $b): int {
            $as = (int)($a['sequence'] ?? PHP_INT_MAX);
            $bs = (int)($b['sequence'] ?? PHP_INT_MAX);
            if ($as !== $bs) return $as <=> $bs;
            return strcmp((string)($a['occurred_at'] ?? ''), (string)($b['occurred_at'] ?? ''));
        });
        $evidence = $this->list($input, 'evidence');
        $decisions = $this->list($input, 'decisions');
        $identities = $this->list($input, 'identities');
        $capabilities = $this->list($input, 'capabilities');
        $causal = $input['causal_graph'] ?? ['nodes'=>[], 'edges'=>[]];
        if (!is_array($causal)) throw new GodModeException('investigation-causal-graph-invalid');
        $causal += ['nodes'=>[], 'edges'=>[]];
        if (!is_array($causal['nodes']) || !is_array($causal['edges'])) throw new GodModeException('investigation-causal-graph-invalid');
        $currentState = $input['current_state'] ?? [];
        if (!is_array($currentState)) throw new GodModeException('investigation-current-state-invalid');

        $verifiedEvidence = count(array_filter($evidence, static fn(array $e): bool => ($e['verified'] ?? false) === true));
        $activeCapabilities = count(array_filter($capabilities, static fn(array $c): bool => in_array(($c['status'] ?? null), ['active','narrowed'], true)));
        $supersededDecisions = count(array_filter($decisions, static fn(array $d): bool => ($d['superseded'] ?? false) === true));

        return [
            'schema' => 'titan.t0gm.sovereign-investigation-workspace.v1',
            'investigation_id' => $investigationId,
            'company_id' => $companyId,
            'title' => $title,
            'opened_at' => $openedAt,
            'timeline' => $timeline,
            'evidence' => $evidence,
            'causal_graph' => ['nodes'=>array_values($causal['nodes']), 'edges'=>array_values($causal['edges'])],
            'decisions' => $decisions,
            'identities' => $identities,
            'capabilities' => $capabilities,
            'current_state' => $currentState,
            'summary' => [
                'timeline_events' => count($timeline),
                'evidence_items' => count($evidence),
                'verified_evidence_items' => $verifiedEvidence,
                'causal_nodes' => count($causal['nodes']),
                'causal_edges' => count($causal['edges']),
                'decisions' => count($decisions),
                'superseded_decisions' => $supersededDecisions,
                'identities' => count($identities),
                'capabilities' => count($capabilities),
                'active_capabilities' => $activeCapabilities,
                'current_state_fields' => count($currentState),
            ],
            'source_ownership' => [
                'timeline' => 'sovereign-audit/feed',
                'evidence' => 'sovereign-audit/evidence-anchor',
                'causal_graph' => 'causal-analysis',
                'decisions' => 'decision-authority/oversight',
                'identities' => 'identity/workload registries',
                'capabilities' => 'capability/live registries',
                'current_state' => 'world-state providers',
            ],
            'projection_only' => true,
            'authority' => [
                'grants_authority' => false,
                'execution_authority_granted' => false,
                'constitutes_t0gm_approval' => false,
                'modifies_source_state' => false,
            ],
        ];
    }

    /** @return list<array<string,mixed>> */
    private function list(array $input, string $key): array
    {
        $value = $input[$key] ?? [];
        if (!is_array($value)) throw new GodModeException('investigation-'.$key.'-invalid');
        foreach ($value as $row) if (!is_array($row)) throw new GodModeException('investigation-'.$key.'-invalid');
        return array_values($value);
    }
}
