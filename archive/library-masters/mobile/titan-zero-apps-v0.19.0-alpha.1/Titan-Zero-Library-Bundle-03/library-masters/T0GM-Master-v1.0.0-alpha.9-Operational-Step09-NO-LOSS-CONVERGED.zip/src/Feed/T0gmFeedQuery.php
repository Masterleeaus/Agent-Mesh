<?php
namespace Titan\GodMode\Feed;

final class T0gmFeedQuery
{
    public function __construct(
        public readonly ?array $eventKinds = null,
        public readonly ?array $companyIds = null,
        public readonly ?string $correlationId = null,
        public readonly ?string $traceId = null,
        public readonly ?string $evidenceId = null,
        public readonly ?string $attentionAtLeast = null,
        public readonly int $limit = 100,
        public readonly int $afterSequence = 0,
    ) {
        if ($limit < 1 || $limit > 1000) throw new T0gmFeedException('invalid-feed-limit');
        if ($afterSequence < 0) throw new T0gmFeedException('invalid-feed-sequence');
    }
}
