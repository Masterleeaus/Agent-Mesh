<?php
namespace Titan\GodMode\Continuance;

final class AuthorityContinuanceOutcome
{
    public const CONTINUE = 'continue';
    public const NARROW = 'narrow';
    public const PAUSE = 'pause';
    public const TRANSFORM = 'transform';
    public const TERMINATE = 'terminate';

    public static function all(): array { return [self::CONTINUE,self::NARROW,self::PAUSE,self::TRANSFORM,self::TERMINATE]; }
}
