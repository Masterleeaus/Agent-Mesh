<?php
namespace Titan\GodMode\Capability;

use Titan\GodMode\Security\CanonicalJson;

final class SovereignCapabilityHasher
{
    public function unsignedPayload(array $capability): array
    {
        $copy = $capability;
        unset($copy['integrity']);
        return $copy;
    }

    public function digest(array $capability): string
    {
        return hash('sha256', CanonicalJson::encode($this->unsignedPayload($capability)));
    }

    public function verify(array $capability): bool
    {
        return ($capability['integrity']['algorithm'] ?? null) === 'sha256'
            && hash_equals((string)($capability['integrity']['digest'] ?? ''), $this->digest($capability));
    }
}
