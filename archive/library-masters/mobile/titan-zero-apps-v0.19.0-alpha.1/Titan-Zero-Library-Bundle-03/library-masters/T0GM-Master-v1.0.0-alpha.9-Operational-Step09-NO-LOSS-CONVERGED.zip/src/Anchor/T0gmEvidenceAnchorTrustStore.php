<?php
namespace Titan\GodMode\Anchor;

use Titan\GodMode\Security\GodModeException;

final class T0gmEvidenceAnchorTrustStore
{
    private array $keys=[];
    public function __construct(array $keys=[]){foreach($keys as $keyId=>$data)$this->register((string)$keyId,$data);}

    public function register(string $keyId,array $data):void
    {
        $suite=(string)($data['suite']??'');
        $pub=base64_decode((string)($data['public_key']??''),true);
        $purposes=$data['purposes']??[];
        $provider=(string)($data['provider_id']??'');
        if($keyId===''||$suite!=='ed25519'||$provider===''||$pub===false||strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES||!is_array($purposes)||!in_array('independent_evidence_anchor',$purposes,true)){
            throw new GodModeException('invalid-independent-anchor-trust-key');
        }
        $this->keys[$keyId]=[
            'suite'=>$suite,'public_key'=>$pub,'provider_id'=>$provider,'purposes'=>array_values(array_unique($purposes)),
            'trusted_from'=>isset($data['trusted_from'])?(int)$data['trusted_from']:null,
            'retired_at'=>isset($data['retired_at'])?(int)$data['retired_at']:null,
            'revoked_at'=>isset($data['revoked_at'])?(int)$data['revoked_at']:null,
        ];
    }

    public function keyForVerification(string $keyId,string $providerId,int $evidenceTime):array
    {
        if(!isset($this->keys[$keyId]))throw new GodModeException('untrusted-independent-anchor-key:'.$keyId);
        $k=$this->keys[$keyId];
        if(!hash_equals($k['provider_id'],$providerId))throw new GodModeException('independent-anchor-provider-key-mismatch');
        if($k['trusted_from']!==null&&$evidenceTime<$k['trusted_from'])throw new GodModeException('independent-anchor-key-not-trusted-at:'.$keyId);
        if($k['revoked_at']!==null&&$evidenceTime>=$k['revoked_at'])throw new GodModeException('independent-anchor-key-revoked-at:'.$keyId);
        if($k['retired_at']!==null&&$evidenceTime>=$k['retired_at'])throw new GodModeException('independent-anchor-key-retired-at:'.$keyId);
        return $k;
    }
}
