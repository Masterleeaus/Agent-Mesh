<?php
namespace Titan\GodMode\Overlay;

final class SafetyOverlayEngine
{
    public function __construct(private readonly SafetyOverlayFactory $factory=new SafetyOverlayFactory()){}

    public function evaluate(array $overlays,array $capability,array $request): SafetyOverlayDecision
    {
        $reasons=[]; $controls=[]; $ids=[];
        foreach($overlays as $overlay){
            if(!is_array($overlay)){ $reasons[]='invalid_overlay'; continue; }
            $ids[]=(string)($overlay['overlay_id']??'unknown');
            if(($overlay['schema']??null)!=='titan.t0gm.safety-overlay.v1') $reasons[]='invalid_overlay_schema';
            if(!$this->factory->verify($overlay)) $reasons[]='overlay_integrity_invalid';
            if(($overlay['company_id']??null)!==($capability['company_id']??null) || ($overlay['company_id']??null)!==($request['company_id']??null)) $reasons[]='overlay_company_mismatch';
            $c=$overlay['constraints']??[];
            $operation=strtolower((string)($request['operation']??''));
            $actionClass=strtolower((string)($request['action_class']??'mutation'));
            if(in_array($operation,array_map('strtolower',$c['prohibited_operations']??[]),true)) $reasons[]='operation_prohibited_by_overlay';
            if(in_array($actionClass,array_map('strtolower',$c['prohibited_action_classes']??[]),true)) $reasons[]='action_class_prohibited_by_overlay';
            if(in_array($operation,array_map('strtolower',$c['human_approval_operations']??[]),true) || in_array($actionClass,array_map('strtolower',$c['human_approval_action_classes']??[]),true)){
                $controls[]='human_approval';
                if(!$this->hasHumanApproval($request)) $reasons[]='human_approval_required_by_overlay';
            }
            if(in_array($operation,array_map('strtolower',$c['dual_control_operations']??[]),true)){
                $controls[]='dual_control';
                if(!$this->hasDualControl($request)) $reasons[]='dual_control_required_by_overlay';
            }
            foreach($c['required_controls']??[] as $control){
                $controls[]=$control;
                if(($request['controls'][$control]??false)!==true) $reasons[]='required_control_missing:'.$control;
            }
            foreach($c['required_evidence_types']??[] as $type){
                if(!$this->hasEvidenceType($request,$type)) $reasons[]='required_evidence_missing:'.$type;
            }
            $risk=$request['risk']??[];
            foreach(['financial_exposure'=>'max_financial_exposure','physical_impact'=>'max_physical_impact','environmental_impact'=>'max_environmental_impact'] as $field=>$limit){
                if(isset($c[$limit]) && (float)($risk[$field]??0)>(float)$c[$limit]) $reasons[]=$field.'_exceeds_overlay_limit';
            }
            if(($c['forbid_ai_only_approval']??false)===true && ($request['approval_actor']['actor_type']??null)==='ai_worker') $reasons[]='ai_only_approval_forbidden_by_overlay';
            if(($c['forbid_cross_company_data']??false)===true){
                foreach($request['data_company_ids']??[] as $cid){ if($cid!==($request['company_id']??null)) $reasons[]='cross_company_data_forbidden_by_overlay'; }
            }
            if(isset($c['allowed_data_regions']) && isset($request['data_region']) && !in_array($request['data_region'],$c['allowed_data_regions'],true)) $reasons[]='data_region_not_allowed_by_overlay';
        }
        return new SafetyOverlayDecision($reasons===[],array_values(array_unique($reasons)),array_values(array_unique($controls)),array_values(array_unique($ids)));
    }

    private function hasEvidenceType(array $request,string $type): bool
    {
        foreach($request['execution_evidence']??[] as $e){ if(is_array($e)&&($e['evidence_type']??null)===$type) return true; }
        return false;
    }
    private function hasHumanApproval(array $request): bool
    {
        $a=$request['human_approval']??null;
        return is_array($a)&&($a['approved']??false)===true&&($a['actor_type']??null)==='human'&&is_string($a['approval_id']??null)&&$a['approval_id']!=='';
    }
    private function hasDualControl(array $request): bool
    {
        $approvals=$request['dual_control_approvals']??[]; $ids=[];
        foreach($approvals as $a){ if(is_array($a)&&($a['approved']??false)===true&&($a['actor_type']??null)==='human'&&isset($a['actor_id'])) $ids[(string)$a['actor_id']]=true; }
        return count($ids)>=2;
    }
}
