<?php
namespace Titan\GodMode\Authority;

final class AuthorityStage
{
    public const INTENT = 'intent';
    public const PLANNING = 'planning';
    public const EXECUTION = 'execution';

    private function __construct() {}
}
