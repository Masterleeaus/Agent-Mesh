<?php
namespace Titan\GodMode\View;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Event\T0gmEventKind;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;
use Titan\GodMode\Feed\T0gmFeedQuery;
use Titan\GodMode\Ranking\T0gmAttentionScorer;

final class T0gmFeedViewService
{
    public function __construct(
        private readonly SovereignActivityStore $store,
        private readonly T0gmAttentionScorer $scorer = new T0gmAttentionScorer(),
    ) {}

    /**
     * Returns a ranked projection without mutating immutable event records.
     * Candidate reads remain constrained by the store visibility policy.
     */
    public function view(string $view, T0gmFeedAccessContext $access, int $limit = 100, int $afterSequence = 0): array
    {
        if (!in_array($view, T0gmFeedView::all(), true)) throw new T0gmFeedException('unknown-feed-view');
        if ($limit < 1 || $limit > 1000) throw new T0gmFeedException('invalid-view-limit');

        $records = $this->visibleRecords($access, $afterSequence);
        $supersessionMap = $this->supersessionMap($records);
        $correlationCompanies = $this->correlationCompanies($records);
        $items = [];
        foreach ($records as $record) {
            $event = $record['event'];
            $attention = $this->scorer->score($event);
            [$matches,$reasons] = $this->matches($view,$event,$attention->toArray(),$correlationCompanies,$supersessionMap);
            if (!$matches) continue;
            $eventId = (string)$event['event_id'];
            $items[] = new T0gmRankedFeedItem($record,$attention,$reasons,isset($supersessionMap[$eventId]),$supersessionMap[$eventId] ?? []);
        }

        usort($items, static function(T0gmRankedFeedItem $a, T0gmRankedFeedItem $b): int {
            $score = $b->attention->score <=> $a->attention->score;
            if ($score !== 0) return $score;
            return ($b->record['audit_sequence'] ?? 0) <=> ($a->record['audit_sequence'] ?? 0);
        });
        return array_map(static fn(T0gmRankedFeedItem $item) => $item->toArray(), array_slice($items,0,$limit));
    }


    /** Read all currently visible candidates in bounded pages so ranking/correlation cannot miss later rows. */
    private function visibleRecords(T0gmFeedAccessContext $access, int $afterSequence): array
    {
        $records = []; $cursor = $afterSequence;
        do {
            $page = $this->store->query(new T0gmFeedQuery(limit:1000, afterSequence:$cursor), $access);
            foreach ($page as $record) {
                $records[] = $record;
                $cursor = max($cursor, (int)($record['audit_sequence'] ?? $cursor));
            }
        } while (count($page) === 1000);
        return $records;
    }

    private function matches(string $view, array $event, array $attention, array $correlationCompanies, array $supersessionMap): array
    {
        $signals = $attention['signals'];
        $eventId = (string)$event['event_id'];
        $kind = (string)$event['event_kind'];
        $domains = array_map('strtolower',$signals['domains'] ?? []);
        $dimensions = array_map('strtolower', array_keys($event['risk']['dimensions'] ?? []));
        $tags = array_values(array_unique(array_merge($domains,$dimensions)));
        $corr = (string)($event['lineage']['correlation_id'] ?? '');

        return match ($view) {
            T0gmFeedView::EVERYTHING => [true,['EVERYTHING']],
            T0gmFeedView::CRITICAL_NOW => [$attention['tier'] === 'critical', $attention['tier'] === 'critical' ? ['CRITICAL_ATTENTION'] : []],
            T0gmFeedView::AI_DECISIONS => [$kind === T0gmEventKind::AI_DECISION, $kind === T0gmEventKind::AI_DECISION ? ['AI_DECISION'] : []],
            T0gmFeedView::SECURITY => $this->factorMatch($this->hasAny($tags,['security','cyber','identity','authority','privacy','fraud','access','credential','authentication']), ['SECURITY_RISK']),
            T0gmFeedView::MONEY => $this->factorMatch($signals['financial_exposure'] > 0 || $this->hasAny($tags,['financial','finance','money','economic','revenue','payment','ledger']), ['FINANCIAL_EXPOSURE']),
            T0gmFeedView::ENVIRONMENT => $this->factorMatch($signals['environmental_impact'] > 0 || $this->hasAny($tags,['environmental','environment','ecological','resource','water','energy','waste','emissions']), ['ENVIRONMENTAL_IMPACT']),
            T0gmFeedView::CROSS_COMPANY => $this->crossCompanyMatch($event,$corr,$correlationCompanies),
            T0gmFeedView::SUPERSEDED => $this->supersededMatch($kind,$eventId,$supersessionMap),
            T0gmFeedView::IRREVERSIBLE => $this->factorMatch($signals['irreversibility'] >= 70, ['IRREVERSIBILITY_'.(string)$signals['irreversibility']]),
            default => [false,[]],
        };
    }

    private function crossCompanyMatch(array $event, string $corr, array $groups): array
    {
        if (($event['company_context']['scope'] ?? null) === 'platform') return [true,['PLATFORM_SCOPE']];
        if ($corr !== '' && count($groups[$corr] ?? []) > 1) return [true,['MULTI_COMPANY_CORRELATION']];
        return [false,[]];
    }

    private function supersededMatch(string $kind, string $eventId, array $map): array
    {
        if ($kind === T0gmEventKind::SUPERSESSION) return [true,['SUPERSESSION_EVENT']];
        if (isset($map[$eventId])) return [true,['SUPERSEDED_TARGET']];
        return [false,[]];
    }

    private function factorMatch(bool $match, array $reasons): array { return [$match,$match ? $reasons : []]; }
    private function hasAny(array $haystack, array $needles): bool { foreach ($needles as $n) if (in_array($n,$haystack,true)) return true; return false; }

    private function supersessionMap(array $records): array
    {
        $map = [];
        foreach ($records as $record) {
            $event = $record['event'];
            if (($event['event_kind'] ?? null) !== T0gmEventKind::SUPERSESSION) continue;
            foreach (($event['supersession']['supersedes_event_ids'] ?? []) as $target) {
                if (!is_string($target) || $target === '') continue;
                $map[$target][] = (string)$event['event_id'];
            }
        }
        return $map;
    }

    private function correlationCompanies(array $records): array
    {
        $out = [];
        foreach ($records as $record) {
            $event = $record['event'];
            $corr = $event['lineage']['correlation_id'] ?? null;
            $company = $event['company_context']['company_id'] ?? null;
            if (!is_string($corr) || $corr === '' || !is_string($company) || $company === '') continue;
            $out[$corr][$company] = true;
        }
        foreach ($out as $corr => $companies) $out[$corr] = array_keys($companies);
        return $out;
    }
}
