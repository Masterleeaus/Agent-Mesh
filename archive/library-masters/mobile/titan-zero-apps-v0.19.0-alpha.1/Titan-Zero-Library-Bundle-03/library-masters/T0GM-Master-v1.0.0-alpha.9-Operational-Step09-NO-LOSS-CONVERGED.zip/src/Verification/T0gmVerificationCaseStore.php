<?php
namespace Titan\GodMode\Verification;

final class T0gmVerificationCaseStore
{
    private array $cases=[];
    public function get(string $transitionId):?array{return $this->cases[$transitionId]??null;}
    public function put(array $case):array{$this->cases[$case['transition_id']]=$case;return $case;}
    public function all():array{return array_values($this->cases);}
}
