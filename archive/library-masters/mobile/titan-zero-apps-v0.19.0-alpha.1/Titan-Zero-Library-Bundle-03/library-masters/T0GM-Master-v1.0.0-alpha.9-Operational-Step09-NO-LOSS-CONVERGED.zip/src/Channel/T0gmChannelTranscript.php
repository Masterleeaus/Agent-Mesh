<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmChannelTranscript
{
    public static function build(array $context): array
    {
        foreach(['channel_id','crypto_profile_id','kem_algorithm','initiator','responder','purpose'] as $field){
            if(!isset($context[$field]) || !is_string($context[$field]) || trim($context[$field])==='') throw new GodModeException('channel-context-missing:'.$field);
        }
        if(isset($context['company_id']) || isset($context['tenant_id']) || isset($context['tenant_company_id'])) {
            throw new GodModeException('channel-crypto-must-not-embed-company-authority');
        }
        $payload=[
            'schema'=>'titan.t0gm.mlkem_channel_transcript.v1',
            'channel_id'=>$context['channel_id'],
            'crypto_profile_id'=>$context['crypto_profile_id'],
            'kem_algorithm'=>$context['kem_algorithm'],
            'initiator'=>$context['initiator'],
            'responder'=>$context['responder'],
            'purpose'=>$context['purpose'],
        ];
        return $payload + ['transcript_hash'=>hash('sha256',CanonicalJson::encode($payload))];
    }
}
