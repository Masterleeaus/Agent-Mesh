<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationDeliveryReceipt
{
    public function __construct(
        public readonly string $notificationId,
        public readonly string $endpointId,
        public readonly string $channel,
        public readonly string $state,
        public readonly string $attemptedAt,
        public readonly ?string $providerReceipt=null,
        public readonly ?string $failureCode=null,
    ) {}
    public function toArray(): array { return get_object_vars($this); }
}
