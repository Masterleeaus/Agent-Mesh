<?php
namespace Titan\GodMode\Notification;

final class InMemoryNotificationTransport implements T0gmNotificationTransport
{
    public array $deliveries=[];
    public function __construct(private readonly string $forChannel,private readonly bool $fail=false) {
        if (!in_array($forChannel,T0gmNotificationChannel::all(),true)) throw new \InvalidArgumentException('invalid-notification-channel');
    }
    public function channel(): string { return $this->forChannel; }
    public function deliver(T0gmNotificationMessage $message,T0gmNotificationEndpoint $endpoint): T0gmNotificationDeliveryReceipt {
        $at=gmdate('Y-m-d\TH:i:s\Z');
        $receipt=new T0gmNotificationDeliveryReceipt($message->notificationId,$endpoint->endpointId,$endpoint->channel,$this->fail?'failed':'delivered',$at,$this->fail?null:'mem_'.bin2hex(random_bytes(6)),$this->fail?'transport-failure':null);
        $this->deliveries[]=['message'=>$message->toArray(),'endpoint'=>$endpoint,'receipt'=>$receipt->toArray()];
        return $receipt;
    }
}
