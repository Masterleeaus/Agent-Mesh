<?php
namespace Titan\GodMode\Feed;

final class T0gmFeedAccessContext
{
    public function __construct(
        public readonly string $actorId,
        public readonly string $authorityClass,
        public readonly array $companyIds = [],
        public readonly bool $platformVisibility = false,
    ) {}

    public static function sovereign(string $actorId = 'T0GM_OWNER'): self
    {
        return new self($actorId, 'titan.god_mode', [], true);
    }

    public function isSovereign(): bool
    {
        return $this->authorityClass === 'titan.god_mode';
    }
}
