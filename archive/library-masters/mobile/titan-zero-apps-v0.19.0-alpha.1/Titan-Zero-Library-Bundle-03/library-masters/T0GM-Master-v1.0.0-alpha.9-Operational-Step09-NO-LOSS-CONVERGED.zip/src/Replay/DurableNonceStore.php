<?php
namespace Titan\GodMode\Replay;

use Closure;
use InvalidArgumentException;
use Titan\GodMode\Contracts\AtomicNonceBackend;
use Titan\GodMode\Contracts\NonceStore;

/**
 * Durable, privacy-preserving nonce/replay store.
 *
 * The storage key intentionally excludes namespace/device/server/region so a
 * nonce consumed anywhere in the configured replay domain is consumed
 * everywhere. Namespace is retained only as hashed audit metadata.
 */
final class DurableNonceStore implements NonceStore
{
    private readonly Closure $clock;

    public function __construct(
        private readonly AtomicNonceBackend $backend,
        private readonly string $replayDomain,
        private readonly string $digestPepper,
        ?Closure $clock = null,
        private readonly bool $requireDistributedBackend = true,
    ) {
        if (trim($this->replayDomain) === '') {
            throw new InvalidArgumentException('replay-domain-required');
        }
        if (strlen($this->digestPepper) < 32) {
            throw new InvalidArgumentException('nonce-digest-pepper-too-short');
        }
        if ($this->requireDistributedBackend && !$this->backend->distributedCapable()) {
            throw new InvalidArgumentException('distributed-nonce-backend-required');
        }
        $this->clock = $clock ?? static fn(): int => time();
    }

    public function consume(string $namespace, string $nonce, int $expiresAt): bool
    {
        $namespace = trim($namespace);
        $nonce = trim($nonce);
        $now = ($this->clock)();

        if ($namespace === '' || $nonce === '') {
            return false;
        }
        if (strlen($namespace) > 256 || strlen($nonce) < 16 || strlen($nonce) > 1024) {
            return false;
        }
        // Never record already-invalid proofs as successful claims.
        if ($expiresAt <= $now) {
            return false;
        }

        // Global within the replay domain: a nonce cannot be reused by changing
        // device, namespace, server or region labels.
        $nonceKey = hash_hmac('sha256', $this->replayDomain . "\0" . $nonce, $this->digestPepper);
        $metadata = [
            'namespace_hash' => hash('sha256', $namespace),
            'replay_domain_hash' => hash('sha256', $this->replayDomain),
            'backend_domain' => $this->backend->consistencyDomain(),
        ];

        return $this->backend->claim($nonceKey, $expiresAt, $now, $metadata);
    }

    public function purgeExpired(int $limit = 1000): int
    {
        return $this->backend->purgeExpired(($this->clock)(), $limit);
    }
}
