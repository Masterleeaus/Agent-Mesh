<?php
namespace Titan\GodMode\Event;

use RuntimeException;

final class T0gmEventException extends RuntimeException
{
    public function __construct(public readonly string $reason, string $message = '')
    {
        parent::__construct($message !== '' ? $message : $reason);
    }
}
