<?php
namespace Titan\GodMode\Workload;

use Titan\GodMode\Contracts\NonceStore;
use Titan\GodMode\Identity\T0gmCryptoSuiteRegistry;
use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class T0gmWorkloadIdentityVerifier
{
    public function __construct(private readonly T0gmWorkloadIdentityRegistry $registry,private readonly T0gmWorkloadTrustStore $trust,private readonly T0gmCryptoSuiteRegistry $crypto,private readonly NonceStore $nonces){}
    public function verify(array $proof,?int $now=null):array
    {
        $now??=time();
        foreach(['claim','workload_signature','workload_signature_suite','attestation'] as $f) if(!array_key_exists($f,$proof)) throw new GodModeException('workload-proof-missing:'.$f);
        $c=(array)$proof['claim'];
        foreach(['schema','workload_id','workload_class','public_key','measurement','nonce','issued_at','evidence_expires_at','non_authority_identity'] as $f) if(!array_key_exists($f,$c)) throw new GodModeException('workload-claim-missing:'.$f);
        if($c['schema']!=='titan.t0gm.workload_identity.v1') throw new GodModeException('wrong-workload-identity-schema');
        if($c['non_authority_identity']!==true) throw new GodModeException('workload-identity-must-be-non-authority');
        foreach(['company_id','tenant_id','tenant_company_id','capability_id','authority','permission','role_id'] as $f) if(array_key_exists($f,$c)) throw new GodModeException('authority-bearing-workload-claim-forbidden:'.$f);
        if($now < (int)$c['issued_at']-30 || $now > (int)$c['evidence_expires_at']+30) throw new GodModeException('workload-evidence-outside-verification-window');
        $pub=base64_decode((string)$c['public_key'],true); if($pub===false||$pub==='') throw new GodModeException('invalid-workload-public-key');
        $sig=base64_decode((string)$proof['workload_signature'],true); if($sig===false||!$this->crypto->verify((string)$proof['workload_signature_suite'],$sig,CanonicalJson::encode($c),$pub)) throw new GodModeException('invalid-workload-self-signature');
        $binding=$this->registry->bindingForCurrentUse((string)$c['workload_id'],(string)$c['workload_class'],$pub,(string)$c['measurement'],$now);
        $a=(array)$proof['attestation']; foreach(['payload','attestor_key_id','signature_suite','signature'] as $f) if(!array_key_exists($f,$a)) throw new GodModeException('workload-attestation-missing:'.$f);
        $p=(array)$a['payload']; foreach(['schema','workload_id','workload_class','public_key_hash','measurement','nonce','issued_at','evidence_hash'] as $f) if(!array_key_exists($f,$p)) throw new GodModeException('workload-attestation-payload-missing:'.$f);
        if($p['schema']!=='titan.t0gm.workload_attestation.v1') throw new GodModeException('wrong-workload-attestation-schema');
        foreach(['workload_id','workload_class','measurement','nonce'] as $f) if((string)$p[$f] !== (string)$c[$f]) throw new GodModeException('workload-attestation-binding-mismatch:'.$f);
        if(!hash_equals((string)$p['public_key_hash'],hash('sha256',$pub))) throw new GodModeException('workload-attestation-key-mismatch');
        $key=$this->trust->key((string)$a['attestor_key_id'],'workload_attestation'); if($key['suite']!==(string)$a['signature_suite']) throw new GodModeException('workload-attestor-suite-key-mismatch');
        $attSig=base64_decode((string)$a['signature'],true); if($attSig===false||!$this->crypto->verify((string)$a['signature_suite'],$attSig,CanonicalJson::encode($p),$key['public_key'])) throw new GodModeException('invalid-workload-attestation-signature');
        if(!$this->nonces->consume('t0gm-workload:'.(string)$c['workload_id'],(string)$c['nonce'],(int)$c['evidence_expires_at'])) throw new GodModeException('workload-identity-replay-detected');
        return ['workload_id'=>(string)$c['workload_id'],'workload_class'=>(string)$c['workload_class'],'binding'=>$binding,'measurement'=>(string)$c['measurement'],'attestor_key_id'=>(string)$a['attestor_key_id'],'network_observation'=>is_array($c['network_observation']??null)?$c['network_observation']:[],'network_location_trusted'=>false,'cryptographic_workload_identity'=>true,'authority_granted'=>false,'company_authority_granted'=>false,'t0gm_authority_granted'=>false];
    }
}
