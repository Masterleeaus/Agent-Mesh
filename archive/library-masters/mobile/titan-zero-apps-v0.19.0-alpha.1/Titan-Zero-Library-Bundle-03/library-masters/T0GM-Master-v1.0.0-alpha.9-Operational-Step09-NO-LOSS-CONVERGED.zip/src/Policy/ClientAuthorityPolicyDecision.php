<?php
namespace Titan\GodMode\Policy;

final class ClientAuthorityPolicyDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly string $executionMode,
        public readonly array $reasons = [],
    ) {}
}
