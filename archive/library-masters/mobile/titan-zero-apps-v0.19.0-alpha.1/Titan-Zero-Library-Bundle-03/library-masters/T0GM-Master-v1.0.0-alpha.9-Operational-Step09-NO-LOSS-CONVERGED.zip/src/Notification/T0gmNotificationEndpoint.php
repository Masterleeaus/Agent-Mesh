<?php
namespace Titan\GodMode\Notification;

final class T0gmNotificationEndpoint
{
    public function __construct(
        public readonly string $endpointId,
        public readonly string $channel,
        public readonly string $recipientId,
        public readonly bool $enabled=true,
        public readonly bool $selectedExternal=false,
        public readonly array $metadata=[],
    ) {
        if ($endpointId==='' || $recipientId==='') throw new \InvalidArgumentException('invalid-notification-endpoint');
        if (!in_array($channel,T0gmNotificationChannel::all(),true)) throw new \InvalidArgumentException('invalid-notification-channel');
        if ($channel===T0gmNotificationChannel::EXTERNAL && !$selectedExternal) throw new \InvalidArgumentException('external-channel-must-be-explicitly-selected');
    }
}
