<?php
namespace Titan\GodMode\Supersession;

use Titan\GodMode\Contracts\SovereignActivityStore;
use Titan\GodMode\Feed\T0gmFeedAccessContext;

/** Discovers only forward causal descendants. Correlation is not dependency. */
final class T0gmCausalDependencyDiscovery
{
    public function __construct(private readonly SovereignActivityStore $store) {}

    /** @return array<int,array{event_id:string,depth:int,event:?array}> */
    public function descendants(string $rootEventId, T0gmFeedAccessContext $access, int $maxDepth = 64): array
    {
        $seen = [$rootEventId => true];
        $queue = [[$rootEventId,0]];
        $out = [];
        while ($queue !== []) {
            [$current,$depth] = array_shift($queue);
            if ($depth >= $maxDepth) continue;
            foreach ($this->store->causalEdges($current, $access) as $edge) {
                if (!in_array($edge['edge_type'], ['causes','parent_of'], true)) continue;
                if (($edge['from_event_id'] ?? null) !== $current) continue;
                $next = (string)$edge['to_event_id'];
                if ($next === '' || isset($seen[$next])) continue;
                $seen[$next] = true;
                $record = $this->store->get($next, $access);
                $out[] = ['event_id'=>$next,'depth'=>$depth+1,'event'=>$record['event'] ?? null];
                $queue[] = [$next,$depth+1];
            }
        }
        return $out;
    }
}
