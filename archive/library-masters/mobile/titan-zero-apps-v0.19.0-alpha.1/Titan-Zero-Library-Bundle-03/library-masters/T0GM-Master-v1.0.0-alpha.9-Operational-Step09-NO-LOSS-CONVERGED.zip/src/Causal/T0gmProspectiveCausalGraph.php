<?php
namespace Titan\GodMode\Causal;

use InvalidArgumentException;
use RuntimeException;

/**
 * Prospective causal graph used for pre-action consequence analysis.
 * Correlation edges are retained as context but never propagate blast radius.
 */
final class T0gmProspectiveCausalGraph
{
    private const CAUSAL_EDGE_TYPES = ['causes','parent_of','depends_on','triggers','propagates_to'];

    /** @var array<string,array<string,mixed>> */
    private array $nodes = [];
    /** @var list<array{from:string,to:string,type:string,confidence:float}> */
    private array $edges = [];

    public function addNode(array $node): void
    {
        $id = trim((string)($node['node_id'] ?? ''));
        if ($id === '') throw new InvalidArgumentException('causal-node-id-required');
        $type = trim((string)($node['node_type'] ?? ''));
        if ($type === '') throw new InvalidArgumentException('causal-node-type-required');
        if (isset($this->nodes[$id]) && $this->nodes[$id] !== $node) {
            throw new RuntimeException('causal-node-conflicting-redefinition');
        }
        $node['node_id'] = $id;
        $node['node_type'] = $type;
        $node['risk_score'] = max(0, min(100, (int)($node['risk_score'] ?? 0)));
        $this->nodes[$id] = $node;
    }

    public function addEdge(string $from, string $to, string $type, float $confidence = 1.0): void
    {
        if (!isset($this->nodes[$from], $this->nodes[$to])) throw new InvalidArgumentException('causal-edge-node-missing');
        if ($from === $to && $this->isCausalType($type)) throw new RuntimeException('causal-cycle-detected');
        $confidence = max(0.0, min(1.0, $confidence));
        if ($this->isCausalType($type) && $this->hasCausalPath($to, $from)) {
            throw new RuntimeException('causal-cycle-detected');
        }
        foreach ($this->edges as $edge) {
            if ($edge['from'] === $from && $edge['to'] === $to && $edge['type'] === $type) return;
        }
        $this->edges[] = compact('from','to','type','confidence');
    }

    public function node(string $id): ?array { return $this->nodes[$id] ?? null; }

    /** @return list<array{from:string,to:string,type:string,confidence:float}> */
    public function outgoingCausal(string $id): array
    {
        return array_values(array_filter($this->edges, fn(array $e): bool => $e['from'] === $id && $this->isCausalType($e['type'])));
    }

    /** @return array<string,array<string,mixed>> */
    public function nodes(): array { return $this->nodes; }

    private function isCausalType(string $type): bool { return in_array($type, self::CAUSAL_EDGE_TYPES, true); }

    private function hasCausalPath(string $from, string $target): bool
    {
        $seen = [];
        $queue = [$from];
        while ($queue !== []) {
            $current = array_shift($queue);
            if ($current === $target) return true;
            if (isset($seen[$current])) continue;
            $seen[$current] = true;
            foreach ($this->outgoingCausal($current) as $edge) $queue[] = $edge['to'];
        }
        return false;
    }
}
