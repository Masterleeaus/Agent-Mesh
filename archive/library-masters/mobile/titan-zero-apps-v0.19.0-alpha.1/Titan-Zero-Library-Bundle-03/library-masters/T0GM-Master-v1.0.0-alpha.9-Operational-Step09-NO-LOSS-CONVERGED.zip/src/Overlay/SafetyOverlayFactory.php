<?php
namespace Titan\GodMode\Overlay;

use Titan\GodMode\Security\CanonicalJson;

final class SafetyOverlayFactory
{
    public function create(array $fields): array
    {
        $overlay=array_merge([
            'schema'=>'titan.t0gm.safety-overlay.v1',
            'overlay_id'=>'overlay_'.bin2hex(random_bytes(12)),
            'company_id'=>null,
            'kind'=>'industry',
            'code'=>'generic',
            'version'=>'1',
            'constraints'=>[],
            'created_at'=>gmdate('c'),
        ],$fields);
        $overlay['integrity']=['algorithm'=>'sha256','digest'=>$this->digest($overlay)];
        return $overlay;
    }

    public function verify(array $overlay): bool
    {
        $integrity=$overlay['integrity']??null;
        return is_array($integrity)
            && ($integrity['algorithm']??null)==='sha256'
            && is_string($integrity['digest']??null)
            && hash_equals($integrity['digest'],$this->digest($overlay));
    }

    private function digest(array $overlay): string
    {
        unset($overlay['integrity']);
        return hash('sha256',CanonicalJson::encode($overlay));
    }
}
