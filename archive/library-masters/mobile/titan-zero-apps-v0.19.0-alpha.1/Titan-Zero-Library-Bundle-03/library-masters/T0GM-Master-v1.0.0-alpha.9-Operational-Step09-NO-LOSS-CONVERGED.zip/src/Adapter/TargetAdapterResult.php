<?php
namespace Titan\GodMode\Adapter;

final class TargetAdapterResult
{
    public function __construct(
        public readonly bool $allowed,
        public readonly string $adapterType,
        public readonly array $reasons,
        public readonly ?array $nativeOperation = null,
        public readonly array $authorityLineage = [],
    ) {}
}
