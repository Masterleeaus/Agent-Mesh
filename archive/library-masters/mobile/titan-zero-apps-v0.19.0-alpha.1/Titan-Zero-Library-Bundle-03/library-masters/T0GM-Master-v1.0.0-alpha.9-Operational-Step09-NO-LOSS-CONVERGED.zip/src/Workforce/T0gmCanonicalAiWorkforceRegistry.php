<?php
namespace Titan\GodMode\Workforce;

use Titan\GodMode\Security\GodModeException;

final class T0gmCanonicalAiWorkforceRegistry
{
    private const KINDS = ['worker','specialist','team','model','autonomous_service'];
    private const STATES = ['registered','active','restricted','quarantined','suspended','retired'];

    /** @var array<string,array<string,array>> */
    private array $entries = [];

    public function __construct(iterable $entries = [])
    {
        foreach ($entries as $entry) {
            if (!is_array($entry)) throw new GodModeException('invalid-workforce-registry-entry');
            $this->register($entry);
        }
    }

    public function register(array $entry): array
    {
        foreach (['tenant_id','tenant_company_id'] as $legacy) {
            if (array_key_exists($legacy,$entry)) throw new GodModeException('legacy-tenant-boundary-forbidden:'.$legacy);
        }
        foreach (['authority','authority_class','permission','permissions','capability','capabilities','execution_authority','sovereign_authority'] as $field) {
            if (array_key_exists($field,$entry)) throw new GodModeException('authority-bearing-workforce-registry-field-forbidden:'.$field);
        }

        $id = trim((string)($entry['registry_id'] ?? ''));
        $companyId = trim((string)($entry['company_id'] ?? ''));
        $kind = trim((string)($entry['kind'] ?? ''));
        $name = trim((string)($entry['name'] ?? ''));
        if ($id==='') throw new GodModeException('workforce-registry-id-required');
        if ($companyId==='') throw new GodModeException('workforce-registry-company-id-required');
        if ($name==='') throw new GodModeException('workforce-registry-name-required');
        if (!in_array($kind,self::KINDS,true)) throw new GodModeException('unsupported-workforce-registry-kind:'.$kind);
        if (isset($this->entries[$companyId][$id])) throw new GodModeException('duplicate-workforce-registry-id:'.$id);

        $references = [
            'model_ids' => $this->normaliseIds($entry['model_ids'] ?? []),
            'specialist_ids' => $this->normaliseIds($entry['specialist_ids'] ?? []),
            'service_ids' => $this->normaliseIds($entry['service_ids'] ?? []),
            'member_ids' => $this->normaliseIds($entry['member_ids'] ?? []),
        ];
        $this->validateReferences($companyId,$references);

        $state = (string)($entry['lifecycle_state'] ?? 'registered');
        if (!in_array($state,self::STATES,true)) throw new GodModeException('invalid-workforce-lifecycle-state:'.$state);

        $record = [
            'schema' => 'titan.t0gm.canonical-ai-workforce-registry-entry.v1',
            'registry_id' => $id,
            'company_id' => $companyId,
            'kind' => $kind,
            'name' => $name,
            'lifecycle_state' => $state,
            'lifecycle_revision' => 1,
            'provider' => $this->nullableString($entry['provider'] ?? null),
            'model_ref' => $this->nullableString($entry['model_ref'] ?? null),
            'specialty' => $this->nullableString($entry['specialty'] ?? null),
            'model_ids' => $references['model_ids'],
            'specialist_ids' => $references['specialist_ids'],
            'service_ids' => $references['service_ids'],
            'member_ids' => $references['member_ids'],
            'labels' => $this->normaliseStrings($entry['labels'] ?? []),
            'metadata' => is_array($entry['metadata'] ?? null) ? $entry['metadata'] : [],
            'provenance' => is_array($entry['provenance'] ?? null) ? $entry['provenance'] : [],
            'registered_at' => $this->nullableString($entry['registered_at'] ?? null),
            'updated_at' => $this->nullableString($entry['updated_at'] ?? null),
            'canonical_registry' => true,
            'identity_catalog_only' => true,
            'authority_granted' => false,
            'execution_authority_granted' => false,
            'sovereign_authority_inherited' => false,
        ];
        $record['integrity_digest'] = $this->digest($record);
        $this->entries[$companyId][$id] = $record;
        return $record;
    }

    public function get(string $companyId,string $registryId): array
    {
        if (!isset($this->entries[$companyId][$registryId])) throw new GodModeException('workforce-registry-entry-not-found:'.$registryId);
        return $this->entries[$companyId][$registryId];
    }

    public function all(string $companyId): array
    {
        $items = array_values($this->entries[$companyId] ?? []);
        usort($items,fn(array $a,array $b)=>[$a['kind'],$a['name'],$a['registry_id']] <=> [$b['kind'],$b['name'],$b['registry_id']]);
        return $items;
    }

    public function byKind(string $companyId,string $kind): array
    {
        if (!in_array($kind,self::KINDS,true)) throw new GodModeException('unsupported-workforce-registry-kind:'.$kind);
        return array_values(array_filter($this->all($companyId),fn(array $e)=>$e['kind']===$kind));
    }

    public function count(string $companyId): int
    {
        return count($this->entries[$companyId] ?? []);
    }

    public function search(string $companyId,string $query,int $limit=100): array
    {
        if ($limit<1 || $limit>1000) throw new GodModeException('invalid-workforce-registry-search-limit');
        $q = strtolower(trim($query));
        $result = [];
        foreach ($this->all($companyId) as $e) {
            $hay = strtolower(implode(' ',array_filter([
                $e['registry_id'],$e['kind'],$e['name'],$e['provider'],$e['model_ref'],$e['specialty'],
                implode(' ',$e['labels'])
            ],fn($v)=>$v!==null && $v!=='')));
            if ($q==='' || str_contains($hay,$q)) $result[]=$e;
        }
        return array_slice($result,0,$limit);
    }

    public function transition(string $companyId,string $registryId,string $state,array $provenance=[]): array
    {
        if (!in_array($state,self::STATES,true)) throw new GodModeException('invalid-workforce-lifecycle-state:'.$state);
        $current = $this->get($companyId,$registryId);
        if ($current['lifecycle_state']==='retired' && $state!=='retired') throw new GodModeException('retired-workforce-entry-is-terminal');
        if ($current['lifecycle_state']===$state) return $current;

        $current['lifecycle_state']=$state;
        $current['lifecycle_revision']=(int)$current['lifecycle_revision']+1;
        $current['updated_at']=$this->nullableString($provenance['at'] ?? $current['updated_at']);
        $current['lifecycle_provenance'][]=[
            'revision'=>$current['lifecycle_revision'],
            'state'=>$state,
            'reason'=>$this->nullableString($provenance['reason'] ?? null),
            'actor_id'=>$this->nullableString($provenance['actor_id'] ?? null),
            'at'=>$this->nullableString($provenance['at'] ?? null),
        ];
        $current['integrity_digest']=$this->digest($current);
        $this->entries[$companyId][$registryId]=$current;
        return $current;
    }

    public static function kinds(): array { return self::KINDS; }
    public static function lifecycleStates(): array { return self::STATES; }

    private function validateReferences(string $companyId,array $groups): void
    {
        foreach ($groups as $ids) {
            foreach ($ids as $id) {
                if (!isset($this->entries[$companyId][$id])) throw new GodModeException('workforce-registry-reference-not-found:'.$id);
            }
        }
    }

    private function normaliseIds(mixed $value): array
    {
        if (!is_array($value)) throw new GodModeException('workforce-registry-reference-list-required');
        $ids=[];
        foreach ($value as $id) {
            $id=trim((string)$id);
            if ($id==='') throw new GodModeException('workforce-registry-reference-id-required');
            $ids[$id]=true;
        }
        return array_keys($ids);
    }

    private function normaliseStrings(mixed $value): array
    {
        if (!is_array($value)) throw new GodModeException('workforce-registry-string-list-required');
        $out=[];
        foreach($value as $v){$v=trim((string)$v); if($v!=='')$out[$v]=true;}
        return array_keys($out);
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value===null) return null;
        $value=trim((string)$value);
        return $value===''?null:$value;
    }

    private function digest(array $record): string
    {
        $copy=$record;
        unset($copy['integrity_digest']);
        return hash('sha256',json_encode($copy,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION));
    }
}
