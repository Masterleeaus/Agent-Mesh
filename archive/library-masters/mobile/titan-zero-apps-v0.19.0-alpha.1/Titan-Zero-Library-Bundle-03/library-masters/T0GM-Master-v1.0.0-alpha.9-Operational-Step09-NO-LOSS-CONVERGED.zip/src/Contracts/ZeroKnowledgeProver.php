<?php
namespace Titan\GodMode\Contracts;

interface ZeroKnowledgeProver
{
    /**
     * Produce an opaque zero-knowledge proof for the supplied public statement.
     * Implementations MUST NOT embed the witness in the returned proof.
     */
    public function prove(array $publicStatement, array $context = []): string;
}
