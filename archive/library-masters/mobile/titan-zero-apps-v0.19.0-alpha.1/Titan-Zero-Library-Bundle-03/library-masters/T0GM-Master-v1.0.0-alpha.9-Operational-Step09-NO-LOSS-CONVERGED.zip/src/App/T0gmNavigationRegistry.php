<?php
namespace Titan\GodMode\App;
use Titan\GodMode\Security\GodModeException;
final class T0gmNavigationRegistry
{
    private array $routes=[];
    public function __construct(array $routes)
    {
        foreach($routes as $r){
            foreach(['route_id','label','path'] as $f)if(trim((string)($r[$f]??''))==='')throw new GodModeException('navigation-field-required:'.$f);
            foreach(['company_id','tenant_id','tenant_company_id','authority','role_id','permission_id'] as $f)if(array_key_exists($f,$r))throw new GodModeException('navigation-authority-scope-forbidden:'.$f);
            $id=(string)$r['route_id']; if(isset($this->routes[$id]))throw new GodModeException('duplicate-navigation-route');
            $this->routes[$id]=['route_id'=>$id,'label'=>(string)$r['label'],'path'=>(string)$r['path'],'requires'=>array_values(array_unique(array_map('strval',(array)($r['requires']??[]))))];
        }
    }
    public function visibleRoutes(array $grants):array
    {
        $grants=array_values(array_unique(array_map('strval',$grants)));$out=[];
        foreach($this->routes as $route){if(array_diff($route['requires'],$grants)===[])$out[]=$route;}
        return $out;
    }
}
