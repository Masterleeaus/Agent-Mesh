<?php
namespace Titan\GodMode\Adapter;

final class LinuxServerAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'linux_server'; }
    public function supports(array $target): bool { return in_array($target['target_type'] ?? '', ['linux_server','server'], true) && strtolower((string)($target['system'] ?? '')) === 'linux'; }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_service_status','read_logs','restart_named_service','start_named_service','stop_named_service',
            'read_file_hash','verify_package','apply_named_remediation'
        ]);
        $params = $request['parameters'] ?? [];
        foreach (['shell','command','script'] as $raw) if (isset($params[$raw])) throw new TargetAdapterException('arbitrary_shell_not_accepted_by_sovereign_adapter');
        return [
            'transport' => 'linux_native_management',
            'company_id' => $request['company_id'],
            'host' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'parameters' => $params,
        ];
    }
}
