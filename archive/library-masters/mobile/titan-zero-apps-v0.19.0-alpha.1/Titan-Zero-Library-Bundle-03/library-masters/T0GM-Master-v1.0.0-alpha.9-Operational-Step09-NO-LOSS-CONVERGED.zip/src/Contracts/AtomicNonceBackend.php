<?php
namespace Titan\GodMode\Contracts;

/**
 * Atomic persistence boundary for replay claims.
 *
 * Implementations MUST make claim() linearizable for a nonce key: exactly one
 * concurrent claimant may receive true for the same key. Production multi-node
 * deployments must use one logically shared backend across every region that
 * accepts T0GM proofs.
 */
interface AtomicNonceBackend
{
    public function claim(string $nonceKey, int $expiresAt, int $claimedAt, array $metadata = []): bool;

    public function purgeExpired(int $now, int $limit = 1000): int;

    /** Stable identifier describing the logical replay-consistency domain. */
    public function consistencyDomain(): string;

    /** Whether this backend can coordinate more than one host/process. */
    public function distributedCapable(): bool;
}
