<?php
namespace Titan\GodMode\Replay;

use RuntimeException;
use Titan\GodMode\Contracts\AtomicNonceBackend;

/**
 * Restart-durable single-host backend for contained/offline deployments.
 * It is intentionally NOT advertised as distributed-capable.
 */
final class FileAtomicNonceBackend implements AtomicNonceBackend
{
    public function __construct(
        private readonly string $path,
        private readonly string $domainId = 'single-host-file',
    ) {}

    public function claim(string $nonceKey, int $expiresAt, int $claimedAt, array $metadata = []): bool
    {
        $dir = dirname($this->path);
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('nonce-store-directory-unavailable');
        }
        $fh = fopen($this->path, 'c+');
        if ($fh === false) {
            throw new RuntimeException('nonce-store-open-failed');
        }
        try {
            if (!flock($fh, LOCK_EX)) {
                throw new RuntimeException('nonce-store-lock-failed');
            }
            $claims = $this->readClaims($fh);
            foreach ($claims as $key => $record) {
                if (($record['expires_at'] ?? 0) <= $claimedAt) {
                    unset($claims[$key]);
                }
            }
            if (isset($claims[$nonceKey])) {
                return false;
            }
            $claims[$nonceKey] = [
                'expires_at' => $expiresAt,
                'claimed_at' => $claimedAt,
                'metadata' => $metadata,
            ];
            $this->writeClaims($fh, $claims);
            return true;
        } finally {
            flock($fh, LOCK_UN);
            fclose($fh);
        }
    }

    public function purgeExpired(int $now, int $limit = 1000): int
    {
        $fh = fopen($this->path, 'c+');
        if ($fh === false) {
            return 0;
        }
        try {
            if (!flock($fh, LOCK_EX)) {
                throw new RuntimeException('nonce-store-lock-failed');
            }
            $claims = $this->readClaims($fh);
            $removed = 0;
            foreach ($claims as $key => $record) {
                if ($removed >= $limit) break;
                if (($record['expires_at'] ?? 0) <= $now) {
                    unset($claims[$key]);
                    $removed++;
                }
            }
            if ($removed > 0) {
                $this->writeClaims($fh, $claims);
            }
            return $removed;
        } finally {
            flock($fh, LOCK_UN);
            fclose($fh);
        }
    }

    public function consistencyDomain(): string { return $this->domainId; }
    public function distributedCapable(): bool { return false; }

    private function readClaims($fh): array
    {
        rewind($fh);
        $raw = stream_get_contents($fh);
        if ($raw === false || trim($raw) === '') return [];
        $decoded = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($decoded)) throw new RuntimeException('nonce-store-corrupt');
        return $decoded;
    }

    private function writeClaims($fh, array $claims): void
    {
        $json = json_encode($claims, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        rewind($fh);
        if (!ftruncate($fh, 0) || fwrite($fh, $json) === false || !fflush($fh)) {
            throw new RuntimeException('nonce-store-write-failed');
        }
        @chmod($this->path, 0600);
    }
}
