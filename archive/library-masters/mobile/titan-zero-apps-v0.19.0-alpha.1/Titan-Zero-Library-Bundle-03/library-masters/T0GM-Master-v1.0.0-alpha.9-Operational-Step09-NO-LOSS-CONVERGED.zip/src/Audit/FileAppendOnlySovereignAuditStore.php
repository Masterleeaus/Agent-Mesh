<?php
namespace Titan\GodMode\Audit;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

final class FileAppendOnlySovereignAuditStore
{
    private string $logPath;
    private string $checkpointDir;
    private string $lockPath;

    public function __construct(
        private readonly string $directory,
        private readonly T0gmSovereignAuditTrustStore $trust,
        private readonly string $signerKeyId,
        private readonly string $signerSecretKey,
    ) {
        if(strlen($signerSecretKey)!==SODIUM_CRYPTO_SIGN_SECRETKEYBYTES)throw new GodModeException('invalid-sovereign-audit-signing-key');
        if(!is_dir($directory)&&!mkdir($directory,0700,true)&&!is_dir($directory))throw new GodModeException('sovereign-audit-directory-unavailable');
        @chmod($directory,0700);
        $this->checkpointDir=$directory.'/checkpoints';
        if(!is_dir($this->checkpointDir)&&!mkdir($this->checkpointDir,0700,true)&&!is_dir($this->checkpointDir))throw new GodModeException('sovereign-audit-checkpoint-directory-unavailable');
        @chmod($this->checkpointDir,0700);
        $this->logPath=$directory.'/sovereign-audit.jsonl';
        $this->lockPath=$directory.'/.append.lock';
        if(!is_file($this->logPath))file_put_contents($this->logPath,'');
        @chmod($this->logPath,0600);
    }

    public function append(array $evidence):array
    {
        $lock=fopen($this->lockPath,'c+');
        if($lock===false||!flock($lock,LOCK_EX))throw new GodModeException('sovereign-audit-lock-failed');
        try {
            $records=$this->verifyStateOrFail();
            foreach($records as $r){
                if(($r['evidence_id']??null)===($evidence['evidence_id']??null)){
                    $digest=hash('sha256',CanonicalJson::encode($evidence['payload']??[]));
                    if(($r['evidence_digest']??null)===$digest)return $r;
                    throw new GodModeException('sovereign-audit-evidence-id-conflict');
                }
            }
            $this->validateEvidence($evidence);
            $previous=end($records)?:null;
            $sequence=$previous===null?1:((int)$previous['audit_sequence']+1);
            $record=[
                'schema'=>'titan.t0gm.sovereign-audit-record.v1',
                'audit_sequence'=>$sequence,
                'record_id'=>'sar-'.str_pad((string)$sequence,12,'0',STR_PAD_LEFT).'-'.substr(hash('sha256',(string)$evidence['evidence_id']),0,16),
                'evidence_id'=>(string)$evidence['evidence_id'],
                'evidence_type'=>(string)$evidence['evidence_type'],
                'occurred_at'=>(string)$evidence['occurred_at'],
                'source'=>(string)$evidence['source'],
                'company_id'=>$evidence['company_id']??null,
                'payload'=>$evidence['payload'],
                'evidence_digest'=>hash('sha256',CanonicalJson::encode($evidence['payload'])),
                'previous_record_hash'=>$previous['record_hash']??null,
                'semantics'=>[
                    'append_only'=>true,'grants_authority'=>false,'constitutes_t0gm_approval'=>false,
                    'company_authority_embedded'=>false,'execution_authority_embedded'=>false,
                ],
            ];
            $record['record_hash']=$this->recordHash($record);
            $record['signature']=$this->signRecord($record);
            $encoded=CanonicalJson::encode($record)."\n";
            $fh=fopen($this->logPath,'ab');
            if($fh===false)throw new GodModeException('sovereign-audit-log-open-failed');
            if(fwrite($fh,$encoded)!==strlen($encoded)){fclose($fh);throw new GodModeException('sovereign-audit-append-failed');}
            fflush($fh); if(function_exists('fsync'))@fsync($fh); fclose($fh);
            $this->writeCheckpoint($record);
            return $record;
        } finally {
            flock($lock,LOCK_UN);fclose($lock);
        }
    }

    public function verify():bool
    {
        try{$this->verifyOrFail();return true;}catch(\Throwable){return false;}
    }

    public function verifyOrFail():void
    {
        $lock=fopen($this->lockPath,'c+');
        if($lock===false||!flock($lock,LOCK_SH))throw new GodModeException('sovereign-audit-lock-failed');
        try{$this->verifyStateOrFail();}finally{flock($lock,LOCK_UN);fclose($lock);}
    }

    /** @return array<int,array> */
    private function verifyStateOrFail():array
    {
        $records=$this->readRecords();
        $previous=null;$expected=1;
        foreach($records as $record){
            if(($record['schema']??null)!=='titan.t0gm.sovereign-audit-record.v1')throw new GodModeException('sovereign-audit-schema-invalid');
            if((int)($record['audit_sequence']??0)!==$expected)throw new GodModeException('sovereign-audit-sequence-gap');
            if(($record['previous_record_hash']??null)!==$previous)throw new GodModeException('sovereign-audit-chain-invalid');
            if(($record['semantics']['grants_authority']??null)!==false||($record['semantics']['constitutes_t0gm_approval']??null)!==false)throw new GodModeException('sovereign-audit-authority-semantics-invalid');
            $digest=hash('sha256',CanonicalJson::encode($record['payload']??null));
            if(!is_string($record['evidence_digest']??null)||!hash_equals($record['evidence_digest'],$digest))throw new GodModeException('sovereign-audit-evidence-digest-invalid');
            $computed=$this->recordHash($record);
            if(!is_string($record['record_hash']??null)||!hash_equals($record['record_hash'],$computed))throw new GodModeException('sovereign-audit-record-hash-invalid');
            $this->verifySignature($record);
            $previous=$record['record_hash'];$expected++;
        }
        $this->verifyCheckpointHead($records);
        return $records;
    }

    private function validateEvidence(array $e):void
    {
        foreach(['evidence_id','evidence_type','occurred_at','source','payload'] as $f)if(!array_key_exists($f,$e))throw new GodModeException('sovereign-audit-evidence-missing:'.$f);
        foreach(['evidence_id','evidence_type','occurred_at','source'] as $f)if(!is_string($e[$f])||$e[$f]==='')throw new GodModeException('sovereign-audit-evidence-invalid:'.$f);
        if(strtotime($e['occurred_at'])===false)throw new GodModeException('sovereign-audit-evidence-time-invalid');
        if(isset($e['company_id'])&&!is_string($e['company_id']))throw new GodModeException('sovereign-audit-company-id-invalid');
        if(!is_array($e['payload']))throw new GodModeException('sovereign-audit-payload-invalid');
    }

    private function recordHash(array $record):string
    {
        $copy=$record;unset($copy['record_hash'],$copy['signature']);
        return hash('sha256',CanonicalJson::encode($copy));
    }

    private function signatureStatement(array $record):array
    {
        return [
            'schema'=>'titan.t0gm.sovereign-audit-signature-statement.v1',
            'audit_sequence'=>(int)$record['audit_sequence'],'record_id'=>(string)$record['record_id'],
            'record_hash'=>(string)$record['record_hash'],'previous_record_hash'=>$record['previous_record_hash']??null,
            'evidence_digest'=>(string)$record['evidence_digest'],'claim'=>'durable-sovereign-audit-origin-and-integrity-without-authority-grant',
        ];
    }

    private function signRecord(array $record):array
    {
        $payload=CanonicalJson::encode($this->signatureStatement($record));
        return ['suite'=>'ed25519','key_id'=>$this->signerKeyId,'signature'=>base64_encode(sodium_crypto_sign_detached($payload,$this->signerSecretKey))];
    }

    private function verifySignature(array $record):void
    {
        $sig=$record['signature']??null;if(!is_array($sig))throw new GodModeException('sovereign-audit-signature-missing');
        if(($sig['suite']??null)!=='ed25519')throw new GodModeException('sovereign-audit-signature-suite-invalid');
        $time=strtotime((string)($record['occurred_at']??''));if($time===false)throw new GodModeException('sovereign-audit-record-time-invalid');
        $key=$this->trust->keyForVerification((string)($sig['key_id']??''),$time);
        $raw=base64_decode((string)($sig['signature']??''),true);if($raw===false)throw new GodModeException('sovereign-audit-signature-invalid');
        if(!sodium_crypto_sign_verify_detached($raw,CanonicalJson::encode($this->signatureStatement($record)),$key['public_key']))throw new GodModeException('sovereign-audit-signature-invalid');
    }

    private function writeCheckpoint(array $record):void
    {
        $checkpoint=[
            'schema'=>'titan.t0gm.sovereign-audit-checkpoint.v1','audit_sequence'=>$record['audit_sequence'],'record_hash'=>$record['record_hash'],
            'created_at'=>gmdate('c'),'semantics'=>['create_only'=>true,'grants_authority'=>false],
        ];
        $statement=CanonicalJson::encode($checkpoint);
        $checkpoint['signature']=['suite'=>'ed25519','key_id'=>$this->signerKeyId,'signature'=>base64_encode(sodium_crypto_sign_detached($statement,$this->signerSecretKey))];
        $name=sprintf('%020d-%s.checkpoint.json',(int)$record['audit_sequence'],$record['record_hash']);
        $path=$this->checkpointDir.'/'.$name;
        $fh=@fopen($path,'x');if($fh===false)throw new GodModeException('sovereign-audit-checkpoint-create-failed');
        $encoded=CanonicalJson::encode($checkpoint);if(fwrite($fh,$encoded)!==strlen($encoded)){fclose($fh);throw new GodModeException('sovereign-audit-checkpoint-write-failed');}
        fflush($fh);if(function_exists('fsync'))@fsync($fh);fclose($fh);@chmod($path,0400);
    }

    private function verifyCheckpointHead(array $records):void
    {
        $files=glob($this->checkpointDir.'/*.checkpoint.json')?:[];
        if($records===[]){if($files!==[])throw new GodModeException('sovereign-audit-checkpoint-head-mismatch');return;}
        if($files===[])throw new GodModeException('sovereign-audit-checkpoint-missing');
        sort($files,SORT_STRING);$path=end($files);
        $checkpoint=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);
        $head=end($records);
        if((int)($checkpoint['audit_sequence']??0)!==(int)$head['audit_sequence']||!hash_equals((string)($checkpoint['record_hash']??''),(string)$head['record_hash']))throw new GodModeException('sovereign-audit-checkpoint-head-mismatch');
        $sig=$checkpoint['signature']??null;if(!is_array($sig))throw new GodModeException('sovereign-audit-checkpoint-signature-missing');
        $copy=$checkpoint;unset($copy['signature']);
        $raw=base64_decode((string)($sig['signature']??''),true);if($raw===false)throw new GodModeException('sovereign-audit-checkpoint-signature-invalid');
        $time=strtotime((string)($checkpoint['created_at']??''));if($time===false)throw new GodModeException('sovereign-audit-checkpoint-time-invalid');
        $key=$this->trust->keyForVerification((string)($sig['key_id']??''),$time);
        if(!sodium_crypto_sign_verify_detached($raw,CanonicalJson::encode($copy),$key['public_key']))throw new GodModeException('sovereign-audit-checkpoint-signature-invalid');
    }

    /** @return array<int,array> */
    private function readRecords():array
    {
        $lines=file($this->logPath,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);if($lines===false)throw new GodModeException('sovereign-audit-read-failed');
        $out=[];foreach($lines as $line){try{$r=json_decode($line,true,512,JSON_THROW_ON_ERROR);}catch(\Throwable){throw new GodModeException('sovereign-audit-record-json-invalid');}if(!is_array($r))throw new GodModeException('sovereign-audit-record-json-invalid');$out[]=$r;}return $out;
    }
}
