<?php
namespace Titan\GodMode\Channel;

use Titan\GodMode\Contracts\MlKemEngine;
use Titan\GodMode\Identity\T0gmCryptoProfileRegistry;
use Titan\GodMode\Security\GodModeException;

final class T0gmMlKemChannelEstablisher
{
    public function __construct(
        private MlKemEngine $engine,
        private ?T0gmCryptoProfileRegistry $profiles = null,
        private ?T0gmMlKemSuiteRegistry $suites = null,
    ) { $this->profiles ??= new T0gmCryptoProfileRegistry(); $this->suites ??= new T0gmMlKemSuiteRegistry(); }

    /** Initiator-side KEM encapsulation. Raw secret is returned only to the channel layer for Step 05 key derivation. */
    public function initiate(array $context, string $responderPublicKeyPem): array
    {
        $transcript=T0gmChannelTranscript::build($context);
        $algorithm=$transcript['kem_algorithm'];
        $this->assertAllowedByProfile($transcript['crypto_profile_id'],$algorithm);
        $this->suites->suite($algorithm);
        $result=$this->engine->encapsulate($algorithm,$responderPublicKeyPem);
        if(strlen($result['shared_secret'])<32) throw new GodModeException('ml-kem-shared-secret-too-short');
        return [
            'transcript'=>$transcript,
            'ciphertext'=>base64_encode($result['ciphertext']),
            'shared_secret'=>$result['shared_secret'],
            'shared_secret_hash'=>hash('sha256',$result['shared_secret']),
            'provider_id'=>$result['provider_id'],
            'authority_granted'=>false,
            'company_authority_granted'=>false,
        ];
    }

    /** Responder-side KEM decapsulation. */
    public function accept(array $context, string $privateKeyReference, string $ciphertextB64): array
    {
        $transcript=T0gmChannelTranscript::build($context);
        $algorithm=$transcript['kem_algorithm'];
        $this->assertAllowedByProfile($transcript['crypto_profile_id'],$algorithm);
        $this->suites->suite($algorithm);
        $cipher=base64_decode($ciphertextB64,true);
        if($cipher===false || $cipher==='') throw new GodModeException('ml-kem-ciphertext-invalid');
        $secret=$this->engine->decapsulate($algorithm,$privateKeyReference,$cipher);
        if(strlen($secret)<32) throw new GodModeException('ml-kem-shared-secret-too-short');
        return [
            'transcript'=>$transcript,
            'shared_secret'=>$secret,
            'shared_secret_hash'=>hash('sha256',$secret),
            'authority_granted'=>false,
            'company_authority_granted'=>false,
        ];
    }

    private function assertAllowedByProfile(string $profileId,string $algorithm): void
    {
        $profile=$this->profiles->profile($profileId);
        $allowed=$profile['kem_preferences'] ?? [];
        if(!in_array($algorithm,$allowed,true)) throw new GodModeException('ml-kem-not-allowed-by-crypto-profile:'.$algorithm);
        if(($profile['classical_only_allowed'] ?? true)===true) throw new GodModeException('crypto-profile-does-not-enforce-pqc');
    }
}
