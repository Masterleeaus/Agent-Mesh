<?php
namespace Titan\GodMode\Contracts;

interface ZeroKnowledgeVerifier
{
    /**
     * Verify an opaque proof against a public statement. Implementations MUST NOT
     * infer or grant business authority; they only attest that the proof is valid
     * for the supplied statement and verification key/configuration.
     *
     * @return array{verified:bool,verifier_id:string,verification_key_id:string,proof_system:string,statement_hash:string}
     */
    public function verify(string $proof, array $publicStatement, array $context = []): array;
}
