<?php
namespace Titan\GodMode\Workload;

use Titan\GodMode\Security\GodModeException;

final class T0gmWorkloadIdentityRegistry
{
    private array $entries=[];
    public function __construct(array $entries)
    {
        $bindingIds=[];
        foreach($entries as $workloadId=>$entry){
            $class=(string)($entry['class']??'');
            $hash=strtolower(trim((string)($entry['public_key_hash']??'')));
            $bindingId=trim((string)($entry['binding_id']??''));
            $status=(string)($entry['status']??'active');
            if(!in_array($class,['server','service','container','workload'],true) || !preg_match('/^[a-f0-9]{64}$/',$hash) || $bindingId==='') throw new \InvalidArgumentException('invalid-workload-binding:'.$workloadId);
            if(!in_array($status,['active','retired','revoked'],true)) throw new \InvalidArgumentException('invalid-workload-binding-status:'.$workloadId);
            if(isset($bindingIds[$bindingId])) throw new \InvalidArgumentException('duplicate-workload-binding-id:'.$bindingId);
            $bindingIds[$bindingId]=true;
            foreach(['company_id','tenant_id','tenant_company_id','capability_id','role_id','authority','permission'] as $forbidden){
                if(array_key_exists($forbidden,$entry)) throw new \InvalidArgumentException('authority-bearing-workload-binding-forbidden:'.$workloadId.':'.$forbidden);
            }
            $this->entries[(string)$workloadId]=[
                'workload_id'=>(string)$workloadId,'class'=>$class,'public_key_hash'=>$hash,'binding_id'=>$bindingId,'status'=>$status,
                'bound_from'=>isset($entry['bound_from'])?(int)$entry['bound_from']:null,
                'retired_at'=>isset($entry['retired_at'])?(int)$entry['retired_at']:null,
                'revoked_at'=>isset($entry['revoked_at'])?(int)$entry['revoked_at']:null,
                'expected_measurement'=>isset($entry['expected_measurement'])?trim((string)$entry['expected_measurement']):null,
                'provenance'=>is_array($entry['provenance']??null)?$entry['provenance']:[],
            ];
        }
    }

    public function bindingForCurrentUse(string $workloadId,string $class,string $publicKeyRaw,string $measurement,int $now):array
    {
        if(!isset($this->entries[$workloadId])) throw new GodModeException('unknown-workload-identity');
        $r=$this->entries[$workloadId];
        if($r['class']!==$class) throw new GodModeException('workload-class-mismatch');
        if(!hash_equals($r['public_key_hash'],hash('sha256',$publicKeyRaw))) throw new GodModeException('workload-public-key-mismatch');
        if($r['expected_measurement']!==null && !hash_equals($r['expected_measurement'],$measurement)) throw new GodModeException('workload-measurement-mismatch');
        if($r['bound_from']!==null && $now<$r['bound_from']) throw new GodModeException('workload-binding-not-yet-active');
        if($r['status']==='revoked' || ($r['revoked_at']!==null && $now >= $r['revoked_at'])) throw new GodModeException('workload-binding-revoked');
        if($r['status']==='retired' || ($r['retired_at']!==null && $now >= $r['retired_at'])) throw new GodModeException('workload-binding-retired');
        return [...$r,'identity_evidence_only'=>true,'company_authority_granted'=>false,'execution_authority_granted'=>false];
    }
}
