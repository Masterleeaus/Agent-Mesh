<?php
namespace Titan\GodMode\Prototype;

final class ContainedServiceBusinessProfile
{
    public const ID='titan.service-business.contained.v1';
    private const ACTIONS=[
        'crm.lead.create'=>'crm',
        'crm.customer.update'=>'crm',
        'booking.create'=>'bookings',
        'job.status.set'=>'bookings',
        'finance.invoice.issue'=>'money',
        'finance.payment.record'=>'money',
        'staff.assign'=>'staff',
        'communication.send'=>'communications',
        'ai.recommendation.record'=>'ai_activity',
    ];
    private const FORBIDDEN_PREFIXES=['ot.','iot.','robot.','robotics.','vehicle.','physical_control.','industrial_control.'];

    public static function domains(): array { return array_values(array_unique(array_values(self::ACTIONS))); }
    public static function domainFor(string $action): string
    {
        foreach(self::FORBIDDEN_PREFIXES as $p) if(str_starts_with($action,$p)) throw new \InvalidArgumentException('physical-control-not-permitted-in-contained-prototype');
        if(!isset(self::ACTIONS[$action])) throw new \InvalidArgumentException('unsupported-contained-service-action');
        return self::ACTIONS[$action];
    }
    public static function isStateChanging(string $action): bool { return $action!=='ai.recommendation.record'; }
}
