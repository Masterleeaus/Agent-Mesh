<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\CanonicalJson;
use Titan\GodMode\Security\GodModeException;

/**
 * Produces a deliberately minimal public statement for sovereign ZK proofs.
 * Raw identity/device/context values remain in the signed identity payload and
 * are represented here only by opaque digests, except for the proof public key
 * required by the current Schnorr verifier.
 */
final class T0gmZkStatementMinimizer
{
    private const CONTEXT_DOMAIN = "TITAN-T0GM-ZK-AUTHORIZATION-CONTEXT-V1\0";
    private const FRESHNESS_DOMAIN = "TITAN-T0GM-ZK-FRESHNESS-V1\0";

    public function fromSovereignIdentity(array $binding, string $zkPublicKeyField): array
    {
        foreach (['authority','principal_class','principal_id','device_key_id','device_public_key_hash','audience','challenge','crypto_profile_id'] as $field) {
            if (!array_key_exists($field,$binding) || trim((string)$binding[$field])==='') {
                throw new GodModeException('zk-minimization-binding-missing:' . $field);
            }
        }
        if ($zkPublicKeyField==='' || !array_key_exists($zkPublicKeyField,$binding) || trim((string)$binding[$zkPublicKeyField])==='') {
            throw new GodModeException('zk-minimization-possession-key-missing');
        }

        $context=[
            'authority'=>(string)$binding['authority'],
            'principal_class'=>(string)$binding['principal_class'],
            'principal_id'=>(string)$binding['principal_id'],
            'device_key_id'=>(string)$binding['device_key_id'],
            'device_public_key_hash'=>(string)$binding['device_public_key_hash'],
            'audience'=>(string)$binding['audience'],
            'crypto_profile_id'=>(string)$binding['crypto_profile_id'],
        ];

        return [
            'schema'=>'titan.t0gm.zk.minimal_authorization_statement.v1',
            'claim'=>'sovereign-secret-possession-without-secret-disclosure',
            'authorization_context_digest'=>hash('sha256',self::CONTEXT_DOMAIN . CanonicalJson::encode($context)),
            'freshness_digest'=>hash('sha256',self::FRESHNESS_DOMAIN . (string)$binding['challenge']),
            'possession_public_key'=>(string)$binding[$zkPublicKeyField],
        ];
    }
}
