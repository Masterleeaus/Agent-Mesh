<?php
namespace Titan\GodMode\View;

use Titan\GodMode\App\T0gmSovereignHomeFeed;
use Titan\GodMode\Feed\T0gmFeedAccessContext;
use Titan\GodMode\Feed\T0gmFeedException;

final class T0gmDynamicIntelligenceViewGenerator
{
    private const CATEGORIES = ['security','money','workforce','environment','customers','infrastructure','critical'];
    private const LEGACY_TENANT_KEYS = ['tenant_id','tenant_company_id','tenantId','tenantCompanyId'];

    public function __construct(
        private readonly T0gmSovereignHomeFeed $homeFeed,
        private readonly FileDynamicIntelligenceViewStore $store,
    ) {}

    public function ensureCanonicalPersistentViews(string $createdBy, string $createdAt): array
    {
        $names = [
            'security'=>'Security','money'=>'Money','workforce'=>'Workforce','environment'=>'Environment',
            'customers'=>'Customers','infrastructure'=>'Infrastructure','critical'=>'Critical Activity',
        ];
        $out=[];
        foreach (self::CATEGORIES as $category) {
            $existing = $this->store->get($category);
            if ($existing !== null) { $out[]=$existing; continue; }
            $out[]=$this->store->upsert([
                'schema'=>'titan.t0gm.dynamic_intelligence_view.v1',
                'view_id'=>$category,
                'name'=>$names[$category],
                'category'=>$category,
                'lifecycle'=>'persistent',
                'status'=>'active',
                'filters'=>[],
                'extinction_conditions'=>[],
                'reason'=>'Canonical T0GM '.$names[$category].' intelligence view',
                'created_by'=>$createdBy,
                'created_at'=>$createdAt,
                'authority_granted'=>false,
            ]);
        }
        return $out;
    }

    public function createTemporaryView(array $definition, string $createdBy, string $createdAt): array
    {
        $this->rejectLegacyTenantKeys($definition);
        $viewId = trim((string)($definition['view_id'] ?? ''));
        $name = trim((string)($definition['name'] ?? ''));
        $category = strtolower(trim((string)($definition['category'] ?? '')));
        $extinction = array_values(array_filter($definition['extinction_conditions'] ?? [], fn($v)=>is_string($v)&&trim($v)!==''));
        if ($viewId === '' || $name === '') throw new T0gmFeedException('dynamic-view-definition-invalid');
        if (!in_array($category,self::CATEGORIES,true)) throw new T0gmFeedException('dynamic-view-category-invalid');
        if ($extinction === []) throw new T0gmFeedException('temporary-view-extinction-required');
        if ($this->store->get($viewId) !== null) throw new T0gmFeedException('dynamic-view-id-conflict');
        $filters = is_array($definition['filters'] ?? null) ? $definition['filters'] : [];
        $this->validateFilters($filters);
        return $this->store->upsert([
            'schema'=>'titan.t0gm.dynamic_intelligence_view.v1',
            'view_id'=>$viewId,
            'name'=>$name,
            'category'=>$category,
            'lifecycle'=>'temporary',
            'status'=>'active',
            'filters'=>$filters,
            'extinction_conditions'=>$extinction,
            'reason'=>(string)($definition['reason'] ?? 'Temporary intelligence view'),
            'created_by'=>$createdBy,
            'created_at'=>$createdAt,
            'authority_granted'=>false,
        ]);
    }

    public function extinguishTemporaryView(string $viewId,string $condition,string $actorId,string $observedAt): array
    {
        $view=$this->store->get($viewId);
        if ($view===null) throw new T0gmFeedException('dynamic-view-not-found');
        if (($view['lifecycle']??null)!=='temporary') throw new T0gmFeedException('persistent-view-cannot-extinguish');
        if (($view['status']??null)!=='active') return $view;
        if (!in_array($condition,$view['extinction_conditions']??[],true)) throw new T0gmFeedException('dynamic-view-extinction-condition-invalid');
        $view['status']='extinguished';
        $view['extinguished_by']=$actorId;
        $view['extinguished_at']=$observedAt;
        $view['extinction_condition']=$condition;
        return $this->store->upsert($view);
    }

    public function render(string $viewId,T0gmFeedAccessContext $access,int $limit=100,int $afterSequence=0): array
    {
        $view=$this->store->get($viewId);
        if ($view===null) throw new T0gmFeedException('dynamic-view-not-found');
        if (($view['status']??null)!=='active') throw new T0gmFeedException('dynamic-view-inactive');
        $snapshot=$this->homeFeed->snapshot($access,1000,$afterSequence);
        $items=[];
        foreach ($snapshot['items'] as $item) {
            if (!$this->categoryMatches((string)$view['category'],$item)) continue;
            if (!$this->filtersMatch($view['filters']??[],$item)) continue;
            $items[]=$item;
            if (count($items)>=$limit) break;
        }
        return [
            'schema'=>'titan.t0gm.dynamic_intelligence_view_projection.v1',
            'view'=>$view,
            'after_sequence'=>$afterSequence,
            'next_sequence'=>$snapshot['next_sequence'],
            'audit_head'=>$snapshot['audit_head'],
            'items'=>$items,
            'projection_only'=>true,
            'execution_authority_granted'=>false,
        ];
    }

    private function categoryMatches(string $category,array $item): bool
    {
        $tokens=array_map('strtolower',$item['classification']['tokens']??[]);
        $subject=strtolower((string)($item['subject']['subject_type']??''));
        $component=strtolower((string)($item['source']['component']??''));
        $summary=strtolower((string)($item['summary']??''));
        $haystack=array_values(array_unique(array_merge($tokens,[$subject,$component],preg_split('/[^a-z0-9_]+/',$summary,-1,PREG_SPLIT_NO_EMPTY)?:[])));
        return match($category){
            'security'=>$this->hasAny($haystack,['security','cyber','identity','authority','privacy','fraud','access','credential','credentials','authentication']),
            'money'=>$this->hasAny($haystack,['financial','finance','money','revenue','payment','invoice','ledger','billing','cash','cost']),
            'workforce'=>$this->hasAny($haystack,['workforce','worker','staff','employee','people','schedule','dispatch','crew','agent']),
            'environment'=>$this->hasAny($haystack,['environmental','environment','ecological','resource','water','energy','waste','emissions','carbon']),
            'customers'=>$this->hasAny($haystack,['customer','customers','client','clients','crm','complaint','lead','quote','booking']),
            'infrastructure'=>$this->hasAny($haystack,['infrastructure','server','database','network','cloud','kubernetes','container','runtime','deployment','host']),
            'critical'=>$this->isCritical($item),
            default=>false,
        };
    }

    private function isCritical(array $item): bool
    {
        $f=$item['rank']['factors']??[];
        return (int)($item['rank']['score']??0)>=75
            || (int)($f['risk']??0)>=80 || (int)($f['consequence']??0)>=80
            || (int)($f['anomaly']??0)>=85 || (int)($f['urgency']??0)>=85;
    }

    private function filtersMatch(array $filters,array $item): bool
    {
        if (($filters['company_ids']??[])!==[] && !in_array($item['company_id']??null,$filters['company_ids'],true)) return false;
        $f=$item['rank']['factors']??[];
        foreach (['risk','consequence','anomaly','confidence','urgency'] as $factor) {
            $key='min_'.$factor;
            if (array_key_exists($key,$filters) && (int)($f[$factor]??0)<(int)$filters[$key]) return false;
        }
        if (($filters['event_kinds']??[])!==[] && !in_array($item['event_kind']??null,$filters['event_kinds'],true)) return false;
        return true;
    }

    private function validateFilters(array $filters): void
    {
        $allowed=['company_ids','min_risk','min_consequence','min_anomaly','min_confidence','min_urgency','event_kinds'];
        foreach (array_keys($filters) as $key) if (!in_array($key,$allowed,true)) throw new T0gmFeedException('dynamic-view-filter-invalid');
        if (isset($filters['company_ids']) && !is_array($filters['company_ids'])) throw new T0gmFeedException('dynamic-view-filter-invalid');
        foreach (['min_risk','min_consequence','min_anomaly','min_confidence','min_urgency'] as $key) {
            if (!array_key_exists($key,$filters)) continue;
            $v=$filters[$key]; if (!is_int($v) && !is_float($v)) throw new T0gmFeedException('dynamic-view-filter-invalid');
            if ($v<0 || $v>100) throw new T0gmFeedException('dynamic-view-filter-invalid');
        }
    }

    private function rejectLegacyTenantKeys(mixed $value): void
    {
        if (!is_array($value)) return;
        foreach ($value as $k=>$v) {
            if (is_string($k) && in_array($k,self::LEGACY_TENANT_KEYS,true)) throw new T0gmFeedException('legacy-tenant-boundary-forbidden');
            $this->rejectLegacyTenantKeys($v);
        }
    }

    private function hasAny(array $haystack,array $needles): bool
    {
        foreach ($needles as $n) if (in_array($n,$haystack,true)) return true;
        return false;
    }
}
