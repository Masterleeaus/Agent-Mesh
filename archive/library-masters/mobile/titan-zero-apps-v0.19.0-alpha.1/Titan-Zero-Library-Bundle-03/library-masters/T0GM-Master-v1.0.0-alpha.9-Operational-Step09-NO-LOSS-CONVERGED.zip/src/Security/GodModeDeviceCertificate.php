<?php
namespace Titan\GodMode\Security;

final class GodModeDeviceCertificate
{
    public function __construct(
        public readonly array $payload,
        public readonly string $rootKeyId,
        public readonly string $signature
    ) {}

    public static function fromArray(array $input): self
    {
        foreach (['payload','root_key_id','signature'] as $field) {
            if (!array_key_exists($field, $input)) {
                throw new GodModeException("device-certificate-missing:$field");
            }
        }

        return new self(
            (array) $input['payload'],
            (string) $input['root_key_id'],
            (string) $input['signature']
        );
    }

    public function verify(GodModeKeyRegistry $keys, array $policy, int $now): array
    {
        $p = $this->payload;
        $required = [
            'schema','authority','principal_class','principal_id','device_key_id',
            'device_public_key','issued_at','not_before','expires_at','audience','non_tenant'
        ];
        foreach ($required as $field) {
            if (!array_key_exists($field, $p)) {
                throw new GodModeException("device-certificate-payload-missing:$field");
            }
        }

        if ($p['schema'] !== 'titan.god_mode.device_certificate.v1') {
            throw new GodModeException('wrong-device-certificate-schema');
        }
        if ($p['authority'] !== $policy['authority']) {
            throw new GodModeException('wrong-authority');
        }
        if ($p['principal_class'] !== $policy['principal_class']) {
            throw new GodModeException('wrong-principal-class');
        }
        if ($p['principal_id'] !== $policy['principal_id']) {
            throw new GodModeException('wrong-principal-id');
        }
        if ($p['audience'] !== $policy['audience']) {
            throw new GodModeException('wrong-audience');
        }
        if ($p['non_tenant'] !== true) {
            throw new GodModeException('god-mode-must-be-non-tenant');
        }
        if (array_key_exists('company_id', $p) || array_key_exists('tenant_id', $p) || array_key_exists('tenant_company_id', $p)) {
            throw new GodModeException('tenant-bound-credential-forbidden');
        }

        $skew = (int) ($policy['clock_skew_seconds'] ?? 30);
        if ($now + $skew < (int) $p['not_before']) {
            throw new GodModeException('device-certificate-not-yet-valid');
        }
        if ($now - $skew > (int) $p['expires_at']) {
            throw new GodModeException('device-certificate-expired');
        }

        $devicePublicKey = base64_decode((string) $p['device_public_key'], true);
        if ($devicePublicKey === false || strlen($devicePublicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            throw new GodModeException('invalid-device-public-key');
        }

        $sig = base64_decode($this->signature, true);
        if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) {
            throw new GodModeException('invalid-root-signature-encoding');
        }

        $message = CanonicalJson::encode($p);
        if (!sodium_crypto_sign_verify_detached($sig, $message, $keys->rootPublicKey($this->rootKeyId))) {
            throw new GodModeException('invalid-root-signature');
        }

        $allow = $policy['allowed_device_key_ids'] ?? [];
        if ($allow && !in_array((string) $p['device_key_id'], $allow, true)) {
            throw new GodModeException('device-not-allowlisted');
        }

        return [
            'principal_id' => (string) $p['principal_id'],
            'device_key_id' => (string) $p['device_key_id'],
            'device_public_key_raw' => $devicePublicKey,
            'certificate_expires_at' => (int) $p['expires_at'],
        ];
    }
}
