<?php
namespace Titan\GodMode\Contracts;

interface T0gmEventSink
{
    /** Persist/publish the canonical T0GM envelope without granting authority. */
    public function append(array $event): void;
}
