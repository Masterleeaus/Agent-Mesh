<?php
namespace Titan\GodMode\Oversight;

final class T0gmOversightReviewSet
{
    public function __construct(
        public readonly string $eventId,
        public readonly array $assessments,
        public readonly array $disagreements,
        public readonly array $materialObjections,
        public readonly string $teamVersion = 't0gm.oversight-team.v1',
    ) {}
    public function toArray(): array {
        return [
            'team_version'=>$this->teamVersion,
            'event_id'=>$this->eventId,
            'assessments'=>array_map(static fn(T0gmOversightAssessment $a)=>$a->toArray(),$this->assessments),
            'disagreements'=>$this->disagreements,
            'material_objections'=>$this->materialObjections,
            'consensus_score'=>null,
            'sovereign_authority_inherited'=>false,
        ];
    }
}
