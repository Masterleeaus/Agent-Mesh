<?php
namespace Titan\GodMode\Custody;

use Titan\GodMode\Security\GodModeException;

final class SovereignKeyHandle
{
    public function __construct(
        public readonly string $keyId,
        public readonly string $suite,
        public readonly string $providerId,
        public readonly string $custodyClass,
        public readonly string $custodyDomain,
        public readonly string $publicKey,
        public readonly bool $hardwareBacked,
        public readonly bool $exportable,
        public readonly array $purposes,
        public readonly string $attestationEvidenceHash,
        public readonly array $metadata = [],
    ) {
        foreach ([$keyId,$suite,$providerId,$custodyClass,$custodyDomain,$publicKey,$attestationEvidenceHash] as $v) {
            if (trim($v)==='') throw new GodModeException('invalid-sovereign-key-handle');
        }
        if (!$hardwareBacked) throw new GodModeException('sovereign-key-must-be-hardware-backed');
        if ($exportable) throw new GodModeException('sovereign-private-key-must-be-non-exportable');
        if ($purposes===[]) throw new GodModeException('sovereign-key-purpose-required');
        foreach (['private_key','private_key_pem','secret','seed','pin','pin_value'] as $forbidden) {
            if (array_key_exists($forbidden,$metadata)) throw new GodModeException('private-key-material-forbidden-in-handle:' . $forbidden);
        }
    }

    public function publicDescriptor(): array
    {
        return [
            'key_id'=>$this->keyId,'suite'=>$this->suite,'provider_id'=>$this->providerId,
            'custody_class'=>$this->custodyClass,'custody_domain'=>$this->custodyDomain,
            'public_key'=>base64_encode($this->publicKey),'hardware_backed'=>$this->hardwareBacked,
            'exportable'=>$this->exportable,'purposes'=>$this->purposes,
            'attestation_evidence_hash'=>$this->attestationEvidenceHash,'metadata'=>$this->metadata,
        ];
    }
}
