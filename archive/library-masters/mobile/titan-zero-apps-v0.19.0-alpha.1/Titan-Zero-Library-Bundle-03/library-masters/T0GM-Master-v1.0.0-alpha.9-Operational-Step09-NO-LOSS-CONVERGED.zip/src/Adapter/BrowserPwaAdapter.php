<?php
namespace Titan\GodMode\Adapter;

final class BrowserPwaAdapter extends AbstractCapabilityTargetAdapter
{
    public function adapterType(): string { return 'browser_pwa'; }
    public function supports(array $target): bool { return in_array($target['target_type'] ?? '', ['browser_extension','pwa'], true); }

    protected function mapAuthorizedOperation(array $request): array
    {
        $op = $this->allowedOperation($request, [
            'read_runtime_state','reload_runtime','clear_scoped_cache','apply_signed_configuration',
            'pause_scoped_automation','resume_scoped_automation','collect_diagnostics'
        ]);
        return [
            'transport' => 'titan_browser_bridge',
            'company_id' => $request['company_id'],
            'surface' => $request['target']['target_id'],
            'environment' => $request['target']['environment'],
            'operation' => $op,
            'parameters' => $request['parameters'] ?? [],
        ];
    }
}
