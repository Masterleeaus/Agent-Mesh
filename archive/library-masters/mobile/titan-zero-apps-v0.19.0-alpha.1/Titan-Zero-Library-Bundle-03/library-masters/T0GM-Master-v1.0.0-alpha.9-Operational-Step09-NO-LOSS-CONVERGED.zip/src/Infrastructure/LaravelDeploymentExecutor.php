<?php
namespace Titan\GodMode\Infrastructure;

/** Uses an injected Laravel/deployment control client; no arbitrary Artisan or shell text is accepted. */
final class LaravelDeploymentExecutor implements InfrastructureExecutor
{
    public function __construct(private readonly mixed $client, private readonly mixed $observer){}
    public function transport():string{return 'laravel_control_plane';}
    public function observe(array $n):array{return ($this->observer)($this->client,$n);}
    public function execute(array $n):InfrastructureExecutionResult
    {
        $p=$n['parameters']??[];
        foreach(['shell','script','raw_command','artisan'] as $k) if(isset($p[$k])) throw new \RuntimeException('raw-deployment-command-forbidden');
        $r=($this->client)($n); if(!is_array($r))$r=['result'=>$r];
        return new InfrastructureExecutionResult(($r['succeeded']??true)===true,$this->transport(),$this->observe($n),$r,$r['evidence']??[],($r['errors']??[]));
    }
}
