<?php
namespace Titan\GodMode\Oversight;

final class T0gmOversightAssessment
{
    public function __construct(
        public readonly string $assessmentId,
        public readonly string $eventId,
        public readonly string $specialist,
        public readonly string $disposition,
        public readonly int $confidence,
        public readonly array $reasonCodes,
        public readonly array $evidenceRefs = [],
        public readonly array $recommendedActions = [],
        public readonly array $limitations = [],
        public readonly string $reviewModelVersion = 't0gm.oversight.v1',
    ) {
        if (!in_array($specialist,T0gmOversightSpecialist::all(),true)) throw new \InvalidArgumentException('invalid-specialist');
        if (!in_array($disposition,T0gmOversightDisposition::all(),true)) throw new \InvalidArgumentException('invalid-disposition');
        if ($confidence < 0 || $confidence > 100) throw new \InvalidArgumentException('invalid-confidence');
    }

    public function toArray(): array
    {
        return [
            'assessment_id'=>$this->assessmentId,
            'event_id'=>$this->eventId,
            'specialist'=>$this->specialist,
            'disposition'=>$this->disposition,
            'confidence'=>$this->confidence,
            'reason_codes'=>$this->reasonCodes,
            'evidence_refs'=>$this->evidenceRefs,
            'recommended_actions'=>$this->recommendedActions,
            'limitations'=>$this->limitations,
            'review_model_version'=>$this->reviewModelVersion,
        ];
    }
}
