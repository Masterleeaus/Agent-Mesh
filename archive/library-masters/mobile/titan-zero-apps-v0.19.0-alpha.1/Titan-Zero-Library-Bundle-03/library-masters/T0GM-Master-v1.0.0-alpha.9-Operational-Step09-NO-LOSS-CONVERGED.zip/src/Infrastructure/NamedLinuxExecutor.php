<?php
namespace Titan\GodMode\Infrastructure;

/**
 * Executes only pre-registered server operations. Request data can select a name and
 * supply bounded arguments, but can never supply shell/script text.
 */
final class NamedLinuxExecutor implements InfrastructureExecutor
{
    /** @param array<string,callable> $operations @param callable $observer */
    public function __construct(private readonly array $operations, private readonly mixed $observer){}
    public function transport():string{return 'linux_native_management';}
    public function observe(array $n):array{return ($this->observer)($n);}
    public function execute(array $n):InfrastructureExecutionResult
    {
        $op=(string)($n['operation']??'');
        if(!isset($this->operations[$op])) return new InfrastructureExecutionResult(false,$this->transport(),$this->observe($n),[],[],['named-server-operation-not-registered']);
        foreach(['shell','command','script'] as $k) if(isset(($n['parameters']??[])[$k])) throw new \RuntimeException('raw-server-command-forbidden');
        $receipt=($this->operations[$op])($n);
        if(!is_array($receipt))$receipt=['result'=>$receipt];
        return new InfrastructureExecutionResult(true,$this->transport(),$this->observe($n),$receipt,$receipt['evidence']??[]);
    }
}
