<?php
namespace Titan\GodMode\Audit;

use Titan\GodMode\Security\GodModeException;

final class T0gmSovereignAuditTrustStore
{
    private array $keys=[];
    public function __construct(array $keys=[]){foreach($keys as $keyId=>$d)$this->register((string)$keyId,$d);}
    public function register(string $keyId,array $d):void
    {
        $suite=(string)($d['suite']??'');
        $pub=base64_decode((string)($d['public_key']??''),true);
        $purposes=$d['purposes']??[];
        if($keyId===''||$suite!=='ed25519'||$pub===false||strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES||!is_array($purposes)||!in_array('sovereign_audit_record',$purposes,true)) {
            throw new GodModeException('invalid-sovereign-audit-trust-key');
        }
        $this->keys[$keyId]=[
            'suite'=>$suite,'public_key'=>$pub,'purposes'=>array_values(array_unique($purposes)),
            'status'=>(string)($d['status']??'active'),'trusted_from'=>isset($d['trusted_from'])?(int)$d['trusted_from']:null,
            'retired_at'=>isset($d['retired_at'])?(int)$d['retired_at']:null,'revoked_at'=>isset($d['revoked_at'])?(int)$d['revoked_at']:null,
        ];
    }
    public function keyForVerification(string $keyId,int $evidenceTime):array
    {
        if(!isset($this->keys[$keyId]))throw new GodModeException('untrusted-sovereign-audit-key:'.$keyId);
        $k=$this->keys[$keyId];
        if($k['trusted_from']!==null&&$evidenceTime<$k['trusted_from'])throw new GodModeException('sovereign-audit-key-not-trusted-at:'.$keyId);
        if($k['revoked_at']!==null&&$evidenceTime>=$k['revoked_at'])throw new GodModeException('sovereign-audit-key-revoked-at:'.$keyId);
        if($k['retired_at']!==null&&$evidenceTime>=$k['retired_at'])throw new GodModeException('sovereign-audit-key-retired-at:'.$keyId);
        return $k;
    }
}
