<?php
namespace Titan\GodMode\Capability;

final class SovereignCapabilityEvaluator
{
    public function __construct(
        private readonly SovereignCapabilityValidator $validator = new SovereignCapabilityValidator(),
        private readonly SovereignCapabilityHasher $hasher = new SovereignCapabilityHasher(),
    ) {}

    public function evaluate(array $capability, array $request): SovereignCapabilityDecision
    {
        try {
            $this->validator->validate($capability);
        } catch (SovereignCapabilityException $e) {
            return new SovereignCapabilityDecision(false, ['invalid_capability:' . $e->getMessage()]);
        }
        if (!$this->hasher->verify($capability)) return new SovereignCapabilityDecision(false, ['integrity_verification_failed']);

        $reasons = [];
        if (($request['company_id'] ?? null) !== $capability['company_id']) $reasons[] = 'company_mismatch';
        foreach (['target_type','target_id','system','environment'] as $field) {
            if (($request['target'][$field] ?? null) !== $capability['target'][$field]) $reasons[] = 'target_mismatch:' . $field;
        }

        $requestedOperation = strtolower(trim((string)($request['operation'] ?? '')));
        $resourceId = $request['resource_id'] ?? null;
        foreach ($capability['prohibited_effects'] as $prohibited) {
            if (strtolower(trim($prohibited['operation'])) === $requestedOperation) $reasons[] = 'effect_explicitly_prohibited';
        }

        $matched = null;
        foreach ($capability['permitted_effects'] as $effect) {
            if (strtolower(trim($effect['operation'])) !== $requestedOperation) continue;
            if (isset($effect['resource_ids']) && !in_array($resourceId, $effect['resource_ids'], true)) continue;
            $matched = $effect['effect_id'];
            break;
        }
        if ($matched === null) $reasons[] = 'effect_not_permitted';

        $risk = $request['risk'] ?? [];
        $constraints = $capability['risk_constraints'];
        $checks = [
            'score' => 'max_risk_score',
            'financial_exposure' => 'max_financial_exposure',
            'physical_impact' => 'max_physical_impact',
            'environmental_impact' => 'max_environmental_impact',
        ];
        foreach ($checks as $requestKey => $constraintKey) {
            $value = $risk[$requestKey] ?? null;
            if (!is_int($value) || $value < 0 || $value > 100) $reasons[] = 'risk_evidence_missing_or_invalid:' . $requestKey;
            elseif ($value > $constraints[$constraintKey]) $reasons[] = 'risk_constraint_breached:' . $requestKey;
        }
        if (isset($risk['band']) && in_array($risk['band'], $constraints['prohibited_risk_bands'] ?? [], true)) $reasons[] = 'prohibited_risk_band';

        $presentEvidence = array_fill_keys($request['evidence_ids'] ?? [], true);
        foreach ($capability['evidence'] as $evidence) {
            if (!isset($presentEvidence[$evidence['evidence_id']])) $reasons[] = 'required_evidence_missing:' . $evidence['evidence_id'];
        }

        foreach (($request['triggered_extinction_conditions'] ?? []) as $conditionType) {
            foreach ($capability['extinction_conditions'] as $condition) {
                if ($condition['condition_type'] === $conditionType) $reasons[] = 'extinction_condition_triggered:' . $conditionType;
            }
        }

        return new SovereignCapabilityDecision($reasons === [], array_values(array_unique($reasons)), $matched);
    }
}
