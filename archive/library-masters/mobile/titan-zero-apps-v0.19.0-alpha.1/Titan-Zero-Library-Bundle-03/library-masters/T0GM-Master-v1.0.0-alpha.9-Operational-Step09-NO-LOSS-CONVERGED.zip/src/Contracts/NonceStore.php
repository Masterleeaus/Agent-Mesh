<?php
namespace Titan\GodMode\Contracts;

interface NonceStore
{
    public function consume(string $namespace, string $nonce, int $expiresAt): bool;
}
