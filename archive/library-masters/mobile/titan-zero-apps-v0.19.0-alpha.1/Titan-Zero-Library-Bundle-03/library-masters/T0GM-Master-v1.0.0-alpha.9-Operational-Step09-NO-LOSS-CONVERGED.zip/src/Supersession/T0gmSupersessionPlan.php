<?php
namespace Titan\GodMode\Supersession;

final class T0gmSupersessionPlan
{
    /** @param T0gmDependencyAction[] $actions */
    public function __construct(
        public readonly string $supersessionEventId,
        public readonly string $supersededEventId,
        public readonly array $actions,
        public readonly array $unresolvedEventIds = [],
    ) {}

    public function byDisposition(string $disposition): array { return array_values(array_filter($this->actions, fn($a) => $a->disposition === $disposition)); }
    public function toArray(): array { return ['supersession_event_id'=>$this->supersessionEventId,'superseded_event_id'=>$this->supersededEventId,'actions'=>array_map(fn($a)=>$a->toArray(),$this->actions),'unresolved_event_ids'=>$this->unresolvedEventIds]; }
}
