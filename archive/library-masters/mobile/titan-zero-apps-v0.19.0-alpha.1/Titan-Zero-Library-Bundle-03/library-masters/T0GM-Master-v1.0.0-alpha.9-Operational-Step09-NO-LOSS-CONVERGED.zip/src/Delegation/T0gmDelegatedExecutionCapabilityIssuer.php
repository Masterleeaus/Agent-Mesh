<?php
namespace Titan\GodMode\Delegation;
use Titan\GodMode\Capability\SovereignCapabilityHasher;
use Titan\GodMode\Capability\SovereignCapabilityValidator;
final class T0gmDelegatedExecutionCapabilityIssuer
{
    public function __construct(private readonly T0gmDelegatedCapabilityRegistry $registry=new T0gmDelegatedCapabilityRegistry(),private readonly SovereignCapabilityValidator $validator=new SovereignCapabilityValidator(),private readonly SovereignCapabilityHasher $hasher=new SovereignCapabilityHasher()){}
    public function issue(array $sovereign,array $request): array {
        $this->validator->validate($sovereign); if(!$this->hasher->verify($sovereign)) throw new \RuntimeException('source-sovereign-capability-integrity-failed');
        if(($request['company_id']??null)!==$sovereign['company_id']) throw new \RuntimeException('delegation-company-mismatch');
        $allowed=array_column($sovereign['permitted_effects'],'effect_id'); foreach((array)($request['permitted_effects']??[]) as $e) if(!in_array($e['effect_id']??null,$allowed,true)) throw new \RuntimeException('delegation-effect-exceeds-sovereign-capability');
        if(($request['recipient_authorized']??false)!==true) throw new \RuntimeException('delegation-recipient-not-authorized');
        $d=$request; unset($d['recipient_authorized']); $d['issuer_authority_class']='titan.god_mode'; $d['issuer_identity_id']=$request['issuer_identity_id']??'t0gm'; $d['sovereignty_transferred']=false; $d['recipient_may_delegate']=false; $d['recipient_may_expand_authority']=false; $d['source_capability_id']=$sovereign['capability_id']; $d['source_capability_digest']=$sovereign['integrity']['digest'];
        return $this->registry->register($d);
    }
    public function registry(): T0gmDelegatedCapabilityRegistry { return $this->registry; }
}
