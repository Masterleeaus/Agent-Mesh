<?php
namespace Titan\GodMode\Ranking;

use Titan\GodMode\Feed\T0gmFeedException;

/**
 * Deterministic T0GM Home Feed ranker.
 * Ranking is an attention projection only. It never creates or expands authority.
 */
final class T0gmHomeFeedRanker
{
    private const WEIGHTS = [
        'risk' => 0.30,
        'consequence' => 0.25,
        'anomaly' => 0.20,
        'confidence' => 0.10,
        'urgency' => 0.15,
    ];

    public function rank(array $event): array
    {
        $attention = T0gmAttentionSignals::fromEvent($event);
        $explicit = is_array($event['attention_signals'] ?? null) ? $event['attention_signals'] : [];
        $consequence = $this->score($explicit['consequence'] ?? $attention->significance);

        $factors = [
            'risk' => $attention->risk,
            'consequence' => $consequence,
            'anomaly' => $attention->anomaly,
            'confidence' => $attention->confidence,
            'urgency' => $attention->urgency,
        ];

        $contributions = [];
        $raw = 0.0;
        foreach (self::WEIGHTS as $factor => $weight) {
            $part = $factors[$factor] * $weight;
            $raw += $part;
            $contributions[$factor] = round($part, 2);
        }

        // Low confidence must not hide a material risk/anomaly. Uncertainty is surfaced as an
        // investigative concern, while the public five-factor contract remains stable.
        $confidenceConcern = 100 - $factors['confidence'];
        $uncertaintyBoost = max($factors['risk'], $factors['consequence'], $factors['anomaly']) >= 60
            ? min(10.0, $confidenceConcern * 0.10)
            : 0.0;
        $raw += $uncertaintyBoost;

        $score = (int) round(min(100, $raw));
        $reasons = [];

        // Non-averaging floors preserve material hazards from being diluted by benign factors.
        if ($factors['risk'] >= 95) { $score = max($score, 95); $reasons[] = 'CRITICAL_RISK'; }
        if ($factors['consequence'] >= 95) { $score = max($score, 92); $reasons[] = 'CRITICAL_CONSEQUENCE'; }
        if ($factors['anomaly'] >= 95) { $score = max($score, 90); $reasons[] = 'SEVERE_ANOMALY'; }
        if ($factors['urgency'] >= 95) { $score = max($score, 90); $reasons[] = 'IMMEDIATE_URGENCY'; }
        if ($confidenceConcern >= 60 && max($factors['risk'], $factors['consequence'], $factors['anomaly']) >= 60) {
            $reasons[] = 'MATERIAL_UNCERTAINTY';
        }

        $tier = match (true) {
            $score >= 90 => 'critical',
            $score >= 75 => 'urgent',
            $score >= 55 => 'important',
            $score >= 30 => 'watch',
            default => 'routine',
        };

        return [
            'score' => $score,
            'tier' => $tier,
            'factors' => $factors,
            'confidence_concern' => $confidenceConcern,
            'contributions' => $contributions,
            'uncertainty_boost' => round($uncertaintyBoost, 2),
            'reason_codes' => array_values(array_unique($reasons)),
        ];
    }

    private function score(mixed $value): int
    {
        if (is_float($value)) $value = (int) round($value);
        if (!is_int($value) || $value < 0 || $value > 100) {
            throw new T0gmFeedException('invalid-home-feed-factor');
        }
        return $value;
    }
}
