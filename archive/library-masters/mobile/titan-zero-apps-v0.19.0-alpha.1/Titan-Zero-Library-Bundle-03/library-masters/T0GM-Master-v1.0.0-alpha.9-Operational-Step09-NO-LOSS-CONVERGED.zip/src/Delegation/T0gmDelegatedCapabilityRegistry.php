<?php
namespace Titan\GodMode\Delegation;

use Titan\GodMode\Security\CanonicalJson;

final class T0gmDelegatedCapabilityRegistry
{
    private const LEGACY_TENANT_KEYS=['tenant_id','tenant_company_id','tenantId','tenantCompanyId'];
    private array $delegations=[];
    private array $dependents=[];
    private array $revocations=[];

    public function register(array $delegation): array
    {
        $this->rejectLegacyTenantKeys($delegation);
        foreach(['delegation_id','issuer_authority_class','issuer_identity_id','recipient','company_id','target','purpose','permitted_effects','prohibited_effects','conditions','evidence_requirements','sovereignty_transferred','recipient_may_delegate','recipient_may_expand_authority'] as $field){
            if(!array_key_exists($field,$delegation)) throw new \RuntimeException('delegation-field-required:'.$field);
        }
        $id=trim((string)$delegation['delegation_id']);
        if($id==='') throw new \RuntimeException('delegation-id-required');
        if(isset($this->delegations[$id])) throw new \RuntimeException('delegation-already-registered');
        if(($delegation['issuer_authority_class']??'')!=='titan.god_mode') throw new \RuntimeException('delegation-sovereign-issuer-required');
        if(($delegation['sovereignty_transferred']??null)!==false) throw new \RuntimeException('delegation-sovereignty-transfer-forbidden');
        if(($delegation['recipient_may_delegate']??null)!==false) throw new \RuntimeException('delegation-redelegation-forbidden');
        if(($delegation['recipient_may_expand_authority']??null)!==false) throw new \RuntimeException('delegation-authority-expansion-forbidden');
        if(trim((string)($delegation['company_id']??''))==='') throw new \RuntimeException('delegation-company-id-required');
        $recipient=$delegation['recipient'];
        if(!is_array($recipient)||!in_array($recipient['recipient_type']??null,['human','service','advanced_intelligence'],true)||trim((string)($recipient['recipient_id']??''))==='') throw new \RuntimeException('delegation-recipient-invalid');
        if(!is_array($delegation['permitted_effects'])||$delegation['permitted_effects']===[]) throw new \RuntimeException('delegation-permitted-effects-required');
        $effectIds=[];
        foreach($delegation['permitted_effects'] as $effect){
            $effectId=trim((string)($effect['effect_id']??''));
            $operation=trim((string)($effect['operation']??''));
            if($effectId===''||$operation==='') throw new \RuntimeException('delegation-effect-invalid');
            if(isset($effectIds[$effectId])) throw new \RuntimeException('delegation-effect-id-duplicate');
            $effectIds[$effectId]=true;
        }
        $delegation['schema']='titan.t0gm.delegated-execution-capability.v1';
        $delegation['status']='active';
        $delegation['retained_effect_ids']=array_keys($effectIds);
        $delegation['authority_class']='delegated_execution_only';
        $delegation['t0gm_authority_transferred']=false;
        $delegation['authority_may_self_expand']=false;
        $delegation['delegation_digest']='sha256:'.hash('sha256',CanonicalJson::encode($this->digestMaterial($delegation)));
        return $this->delegations[$id]=$delegation;
    }

    public function state(string $delegationId): array
    {
        if(!isset($this->delegations[$delegationId])) throw new \RuntimeException('delegation-not-found');
        return $this->delegations[$delegationId];
    }

    public function recordDependentAction(string $delegationId,array $action): array
    {
        $delegation=$this->state($delegationId);
        if($delegation['status']==='revoked') throw new \RuntimeException('delegation-revoked');
        $this->rejectLegacyTenantKeys($action);
        foreach(['action_id','company_id','kind','state','reversibility'] as $field) if(!array_key_exists($field,$action)) throw new \RuntimeException('delegated-action-field-required:'.$field);
        if(($action['company_id']??null)!==$delegation['company_id']) throw new \RuntimeException('delegated-action-company-mismatch');
        $id=trim((string)$action['action_id']);
        if($id==='') throw new \RuntimeException('delegated-action-id-required');
        if(isset($this->dependents[$delegationId][$id])){
            if(CanonicalJson::encode($this->dependents[$delegationId][$id])===CanonicalJson::encode($action)) return $action;
            throw new \RuntimeException('delegated-action-equivocation');
        }
        $action['delegation_id']=$delegationId;
        $action['authority_source']='delegated_execution_capability';
        return $this->dependents[$delegationId][$id]=$action;
    }

    public function dependents(string $delegationId): array
    {
        $this->state($delegationId);
        return $this->dependents[$delegationId]??[];
    }

    public function revoke(string $delegationId,array $revocation,array $containment): array
    {
        $delegation=$this->state($delegationId);
        if($delegation['status']==='revoked'){
            $existing=$this->revocations[$delegationId]??null;
            if(is_array($existing)&&($existing['revocation_id']??null)===($revocation['revocation_id']??null)) return $existing;
            throw new \RuntimeException('delegation-already-revoked');
        }
        $delegation['status']='revoked';
        $delegation['retained_effect_ids']=[];
        $delegation['revoked_by']=$revocation['revoked_by'];
        $delegation['revocation_id']=$revocation['revocation_id'];
        $this->delegations[$delegationId]=$delegation;
        $receipt=[
            'schema'=>'titan.t0gm.delegation-revocation-receipt.v1',
            'revocation_id'=>$revocation['revocation_id'],
            'delegation_id'=>$delegationId,
            'company_id'=>$delegation['company_id'],
            'recipient'=>$delegation['recipient'],
            'revoked_by'=>$revocation['revoked_by'],
            'reason'=>$revocation['reason'],
            'world_revision'=>$revocation['world_revision'],
            'observed_at'=>$revocation['observed_at'],
            'revoked'=>true,
            'retained_effect_ids'=>[],
            'containment'=>$containment,
            'containment_complete'=>count($containment)===count($this->dependents[$delegationId]??[]),
            'authority_granted'=>false,
            'company_authority_granted'=>false,
            't0gm_authority_granted'=>false,
            't0gm_authority_transferred'=>false,
            'sovereignty_transferred'=>false,
        ];
        $receipt['receipt_digest']='sha256:'.hash('sha256',CanonicalJson::encode($receipt));
        return $this->revocations[$delegationId]=$receipt;
    }

    private function digestMaterial(array $delegation): array
    {
        unset($delegation['delegation_digest']);
        return $delegation;
    }
    private function rejectLegacyTenantKeys(array $value,string $path=''): void
    {
        foreach($value as $key=>$child){
            $p=$path===''?(string)$key:$path.'.'.$key;
            if(in_array((string)$key,self::LEGACY_TENANT_KEYS,true)) throw new \RuntimeException('legacy-tenant-boundary-forbidden:'.$p);
            if(is_array($child)) $this->rejectLegacyTenantKeys($child,$p);
        }
    }
}
