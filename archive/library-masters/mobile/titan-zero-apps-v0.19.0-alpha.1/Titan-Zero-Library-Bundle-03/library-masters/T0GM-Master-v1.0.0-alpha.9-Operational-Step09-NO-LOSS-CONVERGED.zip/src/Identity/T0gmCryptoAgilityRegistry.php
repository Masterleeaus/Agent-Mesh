<?php
namespace Titan\GodMode\Identity;

use Titan\GodMode\Security\GodModeException;

final class T0gmCryptoAgilityRegistry
{
    public function __construct(private readonly T0gmCryptoProfileRegistry $profiles,private readonly string $activeProfileId,private readonly array $states=[]){
        if(($this->states[$activeProfileId]??'active')!=='active') throw new GodModeException('active-crypto-profile-state-invalid');
        $this->profiles->profile($activeProfileId);
    }
    public function activeProfile():array{return $this->profiles->profile($this->activeProfileId);}
    public function issuanceProfile(string $id):array{if(($this->states[$id]??($id===$this->activeProfileId?'active':'verify-only'))!=='active')throw new GodModeException('crypto-profile-not-active-for-issuance:'.$id);return $this->profiles->profile($id);}
    public function verificationProfile(string $id):array{$state=$this->states[$id]??($id===$this->activeProfileId?'active':'verify-only');if($state==='disabled')throw new GodModeException('crypto-profile-disabled:'.$id);return $this->profiles->profile($id);}
}
