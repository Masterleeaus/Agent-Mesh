<?php
namespace Titan\GodMode\View;

use Titan\GodMode\Feed\T0gmFeedException;

final class FileDynamicIntelligenceViewStore
{
    public function __construct(private readonly string $path) {}

    public function all(): array
    {
        if (!is_file($this->path)) return [];
        $raw = file_get_contents($this->path);
        if ($raw === false || trim($raw) === '') return [];
        $decoded = json_decode($raw,true);
        if (!is_array($decoded)) throw new T0gmFeedException('dynamic-view-store-corrupt');
        return array_values($decoded);
    }

    public function get(string $viewId): ?array
    {
        foreach ($this->all() as $view) if (($view['view_id'] ?? null) === $viewId) return $view;
        return null;
    }

    public function upsert(array $view): array
    {
        $viewId = (string)($view['view_id'] ?? '');
        if ($viewId === '') throw new T0gmFeedException('dynamic-view-id-required');
        $all = $this->all();
        $replaced = false;
        foreach ($all as $i => $existing) {
            if (($existing['view_id'] ?? null) !== $viewId) continue;
            $all[$i] = $view;
            $replaced = true;
            break;
        }
        if (!$replaced) $all[] = $view;
        $this->write($all);
        return $view;
    }

    private function write(array $views): void
    {
        $dir = dirname($this->path);
        if (!is_dir($dir) && !mkdir($dir,0770,true) && !is_dir($dir)) throw new T0gmFeedException('dynamic-view-store-unavailable');
        $tmp = $this->path.'.tmp.'.bin2hex(random_bytes(6));
        $json = json_encode(array_values($views),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        if (file_put_contents($tmp,$json."\n",LOCK_EX) === false) throw new T0gmFeedException('dynamic-view-store-write-failed');
        if (!rename($tmp,$this->path)) { @unlink($tmp); throw new T0gmFeedException('dynamic-view-store-write-failed'); }
    }
}
