<?php
namespace Titan\GodMode\PolicyDistribution;

use Titan\GodMode\Security\GodModeException;

final class T0gmPolicyAcceptanceStore
{
    private array $accepted=[];
    public function accept(string $streamKey,int $revision,string $digest):void
    {
        if($revision<1)throw new GodModeException('signed-policy-revision-invalid');
        $prior=$this->accepted[$streamKey]??null;
        if($prior!==null){
            if($revision<$prior['revision'])throw new GodModeException('signed-policy-rollback-detected');
            if($revision===$prior['revision']&&$digest!==$prior['digest'])throw new GodModeException('signed-policy-revision-equivocation');
            if($revision===$prior['revision'])return;
        }
        $this->accepted[$streamKey]=['revision'=>$revision,'digest'=>$digest];
    }
    public function current(string $streamKey):?array{return $this->accepted[$streamKey]??null;}
}
