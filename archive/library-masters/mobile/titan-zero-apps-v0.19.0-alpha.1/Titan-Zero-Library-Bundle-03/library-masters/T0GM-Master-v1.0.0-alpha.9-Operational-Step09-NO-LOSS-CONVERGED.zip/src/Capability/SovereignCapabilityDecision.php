<?php
namespace Titan\GodMode\Capability;

final class SovereignCapabilityDecision
{
    public function __construct(
        public readonly bool $allowed,
        public readonly array $reasons,
        public readonly ?string $matchedEffectId = null,
    ) {}

    public function toArray(): array
    {
        return ['allowed' => $this->allowed, 'reasons' => $this->reasons, 'matched_effect_id' => $this->matchedEffectId];
    }
}
